package com.eyob.prayeralarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import java.util.Calendar;

/**
 * Schedules every enabled alarm with AlarmManager.setAlarmClock() (the most reliable alarm type:
 * wakes the phone from Doze). Times always follow the PHONE's current clock / time zone.
 * If that is refused, it falls back to other exact alarms, and the problem is shown on the home page.
 */
final class Scheduler {
    static final int TEST_ID = 998;

    /** (Re)arms every enabled alarm and cancels the disabled ones. */
    static void scheduleAll(Context c) {
        Store.prefs(c).edit().remove("st_err").apply();
        for (Store.Entry e : Store.all(c)) {
            if (Store.isEnabled(c, e.id)) setClockAlarm(c, e.id, nextTime(e, 0), e.id, e.title);
            else cancel(c, e.id);
        }
    }

    /** Next ring of one daily alarm; it must be at least minLeadMs in the future. */
    static void scheduleNext(Context c, Store.Entry e, long minLeadMs) {
        if (!Store.isEnabled(c, e.id)) { cancel(c, e.id); return; }
        setClockAlarm(c, e.id, nextTime(e, minLeadMs), e.id, e.title);
    }

    static long nextTime(Store.Entry e, long minLeadMs) {
        Calendar cal = Calendar.getInstance();   // phone's own time zone
        long now = cal.getTimeInMillis();
        cal.set(Calendar.HOUR_OF_DAY, e.hour);
        cal.set(Calendar.MINUTE, e.minute);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= now + minLeadMs) cal.add(Calendar.DAY_OF_YEAR, 1);
        return cal.getTimeInMillis();
    }

    static void snooze(Context c, int refId, String title, int minutes) {
        setClockAlarm(c, Store.SNOOZE_ID, System.currentTimeMillis() + minutes * 60000L, refId, title);
    }

    static void testIn(Context c, int seconds) {
        setClockAlarm(c, TEST_ID, System.currentTimeMillis() + seconds * 1000L, -1, "የማንቂያ ሙከራ");
    }

    static void cancel(Context c, int id) {
        PendingIntent pi = PendingIntent.getBroadcast(c, id, new Intent(c, AlarmReceiver.class),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pi != null) {
            ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(pi);
            pi.cancel();
        }
    }

    private static void setClockAlarm(Context c, int id, long whenMs, int refId, String title) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.putExtra("alarmId", id);
        i.putExtra("refId", refId);
        i.putExtra("title", title);
        PendingIntent fire = PendingIntent.getBroadcast(c, id, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent show = PendingIntent.getActivity(c, 1, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        String err = null;
        try {
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(whenMs, show), fire);
        } catch (Exception e1) {
            try {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, fire);
            } catch (Exception e2) {
                try {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, fire);
                    err = "ትክክለኛ ሰዓት ማንቂያ አልተፈቀደም — ማንቂያው ከጥቂት ደቂቃ ሊዘገይ ይችላል። «የአፕ ቅንብር» ውስጥ Alarms & reminders ፍቀዱ።";
                } catch (Exception e3) {
                    err = "ማንቂያ ማስቀመጥ አልተቻለም (" + e3.getClass().getSimpleName() + ")";
                }
            }
        }
        if (err != null) Store.prefs(c).edit().putString("st_err", err).apply();
    }
}
