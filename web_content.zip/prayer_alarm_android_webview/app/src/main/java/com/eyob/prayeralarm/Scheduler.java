package com.eyob.prayeralarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import java.util.Calendar;

/**
 * Uses AlarmManager.setAlarmClock(): the most reliable alarm type on Android.
 * It wakes the phone from Doze, needs no "exact alarm" permission and is exempt from
 * most background restrictions. Times always follow the PHONE's current clock / time zone.
 */
final class Scheduler {

    static void scheduleAll(Context c) {
        for (Store.Entry e : Store.all(c)) scheduleNext(c, e, 0);
    }

    /** Next ring of this daily alarm; it must be at least minLeadMs in the future. */
    static void scheduleNext(Context c, Store.Entry e, long minLeadMs) {
        Calendar cal = Calendar.getInstance();   // phone's own time zone
        long now = cal.getTimeInMillis();
        cal.set(Calendar.HOUR_OF_DAY, e.hour);
        cal.set(Calendar.MINUTE, e.minute);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= now + minLeadMs) cal.add(Calendar.DAY_OF_YEAR, 1);
        setClockAlarm(c, e.id, cal.getTimeInMillis(), e.id, e.title);
    }

    static void snooze(Context c, int refId, String title, int minutes) {
        setClockAlarm(c, Store.SNOOZE_ID, System.currentTimeMillis() + minutes * 60000L, refId, title);
    }

    static void cancel(Context c, int id) {
        PendingIntent pi = PendingIntent.getBroadcast(c, id, new Intent(c, AlarmReceiver.class),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pi != null) {
            ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(pi);
            pi.cancel();
        }
    }

    private static void setClockAlarm(Context c, int id, long whenMs, int refId, String title) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.putExtra("alarmId", id);
        i.putExtra("refId", refId);
        i.putExtra("title", title);
        PendingIntent fire = PendingIntent.getBroadcast(c, id, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent show = PendingIntent.getActivity(c, 1, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.setAlarmClock(new AlarmManager.AlarmClockInfo(whenMs, show), fire);
    }
}
