package com.eyob.prayeralarm;

import android.app.Activity;
import android.content.Intent;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/** Functions the HTML/JS pages can call as AndroidAlarm.xxx(). */
final class Bridge {
    private final Activity act;
    private final boolean alarmScreen;

    Bridge(Activity act, boolean alarmScreen) { this.act = act; this.alarmScreen = alarmScreen; }

    @JavascriptInterface public String getPrayersJson() { return Store.prayersJson(act); }
    @JavascriptInterface public String getPersonalJson() { return Store.personalJson(act); }

    /** Returns the new alarm id, or -1 on error. */
    @JavascriptInterface public int addPersonalAlarm(String title, String hhmm) {
        try {
            String[] p = hhmm.split(":");
            int h = Integer.parseInt(p[0]), m = Integer.parseInt(p[1]);
            int id = Store.PERSONAL_BASE + (int) (System.currentTimeMillis() % 900000L);
            JSONArray a = new JSONArray(Store.personalJson(act));
            a.put(new JSONObject().put("id", id).put("name", title)
                    .put("time", String.format(Locale.US, "%02d:%02d", h, m)));
            Store.savePersonal(act, a);
            Scheduler.scheduleNext(act, new Store.Entry(id, title, h, m), 0);
            return id;
        } catch (Exception e) {
            return -1;
        }
    }

    @JavascriptInterface public void removePersonalAlarm(int id) {
        try {
            JSONArray a = new JSONArray(Store.personalJson(act));
            JSONArray keep = new JSONArray();
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                if (o.getInt("id") != id) keep.put(o);
            }
            Store.savePersonal(act, keep);
            Scheduler.cancel(act, id);
        } catch (Exception ignored) { }
    }

    @JavascriptInterface public void stopAlarm() {
        act.stopService(new Intent(act, AlarmPlaybackService.class));
        if (alarmScreen) act.runOnUiThread(() -> act.finish());
    }

    @JavascriptInterface public void snoozeAlarm(int refId, String title) {
        act.stopService(new Intent(act, AlarmPlaybackService.class));
        Scheduler.snooze(act, refId, title, 5);
        if (alarmScreen) act.runOnUiThread(() -> act.finish());
    }
}
