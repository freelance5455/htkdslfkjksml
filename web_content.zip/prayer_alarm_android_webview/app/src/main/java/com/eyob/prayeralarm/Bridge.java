package com.eyob.prayeralarm;

import android.app.Activity;
import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/** Functions the HTML/JS pages can call as AndroidAlarm.xxx(). */
final class Bridge {
    private final Activity act;
    private final boolean alarmScreen;

    Bridge(Activity act, boolean alarmScreen) { this.act = act; this.alarmScreen = alarmScreen; }

    @JavascriptInterface public String getPrayersJson() { return Store.prayersJson(act); }
    @JavascriptInterface public String getPersonalJson() { return Store.personalJson(act); }

    /** Returns the new alarm id, or -1 on error. */
    @JavascriptInterface public int addPersonalAlarm(String title, String hhmm) {
        try {
            String[] p = hhmm.split(":");
            int h = Integer.parseInt(p[0]), m = Integer.parseInt(p[1]);
            int id = Store.PERSONAL_BASE + (int) (System.currentTimeMillis() % 900000L);
            JSONArray a = new JSONArray(Store.personalJson(act));
            a.put(new JSONObject().put("id", id).put("name", title)
                    .put("time", String.format(Locale.US, "%02d:%02d", h, m)));
            Store.savePersonal(act, a);
            Scheduler.scheduleAll(act);
            return id;
        } catch (Exception e) {
            return -1;
        }
    }

    @JavascriptInterface public void removePersonalAlarm(int id) {
        try {
            JSONArray a = new JSONArray(Store.personalJson(act));
            JSONArray keep = new JSONArray();
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                if (o.getInt("id") != id) keep.put(o);
            }
            Store.savePersonal(act, keep);
            Scheduler.cancel(act, id);
        } catch (Exception ignored) { }
    }

    // ---- master switch / day-night / per-hour choices ----
    @JavascriptInterface public String getSettingsJson() {
        try {
            return new JSONObject().put("on", Store.masterOn(act))
                    .put("off", new JSONArray(Store.offJson(act))).toString();
        } catch (Exception e) {
            return "{\"on\":true,\"off\":[]}";
        }
    }

    @JavascriptInterface public void setSettings(boolean on, String offJson) {
        Store.saveSettings(act, on, offJson);
        Scheduler.scheduleAll(act);
    }

    // ---- status + test buttons ----
    @JavascriptInterface public String getStatusJson() {
        try {
            long best = 0;
            String title = "";
            if (Store.masterOn(act)) {
                for (Store.Entry e : Store.all(act)) {
                    if (!Store.isEnabled(act, e.id)) continue;
                    long t = Scheduler.nextTime(e, 0);
                    if (best == 0 || t < best) { best = t; title = e.title; }
                }
            }
            boolean exact = true;
            if (Build.VERSION.SDK_INT >= 31) {
                exact = ((AlarmManager) act.getSystemService(Context.ALARM_SERVICE)).canScheduleExactAlarms();
            }
            return new JSONObject().put("err", Store.prefs(act).getString("st_err", ""))
                    .put("next", best).put("title", title).put("exact", exact).toString();
        } catch (Exception e) {
            return "{\"err\":\"\",\"next\":0,\"title\":\"\",\"exact\":true}";
        }
    }

    /** Rings immediately (tests the sound + screen). */
    @JavascriptInterface public void ringNow() {
        Intent s = new Intent(act, AlarmPlaybackService.class);
        s.putExtra("alarmId", Scheduler.TEST_ID);
        s.putExtra("refId", -1);
        s.putExtra("title", "የማንቂያ ሙከራ");
        try { ContextCompat.startForegroundService(act, s); } catch (Exception ignored) { }
    }

    /** Schedules a real alarm 10 seconds from now (tests the scheduling path). */
    @JavascriptInterface public void testIn10s() { Scheduler.testIn(act, 10); }

    @JavascriptInterface public void openBatterySettings() {
        act.runOnUiThread(() -> {
            try {
                act.startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + act.getPackageName())));
            } catch (Exception e) {
                try { act.startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
                catch (Exception ignored) { }
            }
        });
    }

    @JavascriptInterface public void openAppSettings() {
        act.runOnUiThread(() -> {
            try {
                act.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + act.getPackageName())));
            } catch (Exception ignored) { }
        });
    }

    // ---- alarm screen buttons ----
    @JavascriptInterface public void stopAlarm() {
        act.stopService(new Intent(act, AlarmPlaybackService.class));
        if (alarmScreen) act.runOnUiThread(() -> act.finish());
    }

    @JavascriptInterface public void snoozeAlarm(int refId, String title) {
        act.stopService(new Intent(act, AlarmPlaybackService.class));
        Scheduler.snooze(act, refId, title, 5);
        if (alarmScreen) act.runOnUiThread(() -> act.finish());
    }
}
