package com.eyob.prayeralarm;

import android.app.Activity;
import android.view.View;
import android.widget.FrameLayout;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

final class Ui {
    static final int WINE = 0xFF3A0A14;

    static WebView createWebView(Activity a, Object bridge) {
        WebView w = new WebView(a);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);                 // needed for file:///android_asset
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        w.setBackgroundColor(WINE);
        w.addJavascriptInterface(bridge, "AndroidAlarm");
        w.setWebViewClient(new WebViewClient());
        return w;
    }

    /** Keeps the page clear of the status bar / navigation bar / keyboard (Android 15 is edge-to-edge). */
    static FrameLayout wrap(Activity a, View content) {
        FrameLayout root = new FrameLayout(a);
        root.setBackgroundColor(WINE);
        root.addView(content, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars()
                    | WindowInsetsCompat.Type.displayCutout());
            Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
            v.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
            return WindowInsetsCompat.CONSUMED;
        });
        return root;
    }
}
