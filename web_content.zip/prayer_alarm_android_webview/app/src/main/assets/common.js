/* Shared helpers for index.html and alarm.html */
var pad = function (n) { return String(n).padStart(2, '0'); };

/* Ethiopian clock = phone time - 6 hours, shown on a 12 hour dial. */
function ethParts(h, m) {
  var eh = (h + 6) % 12;
  if (eh === 0) eh = 12;
  return { h: eh, m: m, period: (h >= 6 && h < 18) ? 'ቀን' : 'ሌሊት' };
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}

function loadPrayers() { return window.PRAYERS || []; }

/* Ethiopian hour (1-12) + day/night -> phone 24h hour.
   Day starts at 6:00 phone time (= Ethiopian 12:00), night starts at 18:00. */
function ethTo24(eh, night) {
  eh = eh % 12;
  return night ? (18 + eh) % 24 : 6 + eh;
}
function getLS(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
function setLS(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }

var CROSS = '<img src="cross.png" alt="">';
Array.prototype.forEach.call(document.querySelectorAll('[data-cross]'), function (e) { e.innerHTML = CROSS; });
