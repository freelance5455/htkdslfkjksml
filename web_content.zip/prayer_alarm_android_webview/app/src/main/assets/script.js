(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var bridge = window.AndroidAlarm || null;
  var prayers = loadPrayers();
  var mode = getLS('clockMode') || 'eth';   // 'eth' = Ethiopian main clock, 'phone' = phone clock main

  function hm(t) { var p = t.split(':'); return [parseInt(p[0], 10), parseInt(p[1], 10)]; }
  function ethClock(t) { var x = hm(t), e = ethParts(x[0], x[1]); return e.h + ':' + pad(x[1]) + ' ' + e.period; }
  function ethFor(p) { return p.eth || ethClock(p.time); }

  /* ---------- clock (always read from the phone's clock) ---------- */
  function nextPrayer(now) {
    var best = null;
    prayers.forEach(function (p) {
      var x = hm(p.time), t = new Date(now);
      t.setHours(x[0], x[1], 0, 0);
      if (t <= now) t.setDate(t.getDate() + 1);
      var d = t - now;
      if (!best || d < best.d) best = { p: p, d: d };
    });
    return best;
  }
  function fmtDur(ms) {
    var mins = Math.max(1, Math.ceil(ms / 60000)), h = Math.floor(mins / 60), m = mins % 60;
    return (h ? h + ' ሰዓት ' : '') + (m ? m + ' ደቂቃ' : '');
  }
  function tick() {
    var n = new Date(), h = n.getHours(), m = n.getMinutes(), e = ethParts(h, m);
    var eth = pad(e.h) + ':' + pad(m), phone = pad(h) + ':' + pad(m);
    if (mode === 'eth') {
      $('clock').textContent = eth;
      $('period').textContent = 'የኢትዮጵያ ሰዓት · ' + e.period;
      $('sub').textContent = 'የስልክ ሰዓት: ' + phone;
    } else {
      $('clock').textContent = phone;
      $('period').textContent = 'የስልክ ሰዓት';
      $('sub').textContent = 'የኢትዮጵያ ሰዓት: ' + eth + ' ' + e.period;
    }
    var nx = nextPrayer(n);
    $('nextLine').textContent = nx ? ('ቀጣይ: ' + nx.p.name + ' · በ' + fmtDur(nx.d) + ' ውስጥ') : '';
  }
  $('swap').onclick = function () { mode = (mode === 'eth') ? 'phone' : 'eth'; setLS('clockMode', mode); tick(); };

  /* ---------- prayer hours as buttons: tap one -> its meaning opens ---------- */
  function renderList() {
    var nx = nextPrayer(new Date());
    $('prayerList').innerHTML = prayers.map(function (p) {
      var cls = 'accbtn' + ((nx && nx.p.id === p.id) ? ' next' : '');
      return '<div class="acc">' +
        '<button type="button" class="' + cls + '" data-id="' + p.id + '" aria-expanded="false">' +
        '<span><b>' + esc(p.name) + '</b><small>ኢትዮጵያ ' + esc(ethFor(p)) + ' · ስልክ ' + esc(p.time) + '</small></span>' +
        '<i class="chev">⌄</i></button>' +
        '<div class="accbody" hidden><h4>ትርጉም</h4><p class="note-text">' + esc(p.note) + '</p>' +
        '<h4>የሚጸለዩ መጻሕፍት</h4><ul class="books-list">' +
        p.books.map(function (b) { return '<li>' + esc(b) + '</li>'; }).join('') + '</ul></div></div>';
    }).join('');
  }
  $('prayerList').addEventListener('click', function (ev) {
    var btn = ev.target.closest ? ev.target.closest('.accbtn') : null;
    if (!btn) return;
    var wasOpen = btn.getAttribute('aria-expanded') === 'true';
    Array.prototype.forEach.call(document.querySelectorAll('.accbtn'), function (b) {
      b.setAttribute('aria-expanded', 'false'); b.nextSibling.hidden = true; b.parentNode.classList.remove('open');
    });
    if (!wasOpen) {
      btn.setAttribute('aria-expanded', 'true'); btn.nextSibling.hidden = false; btn.parentNode.classList.add('open');
      setTimeout(function () { btn.scrollIntoView({ block: 'start', behavior: 'smooth' }); }, 30);
    }
  });

  /* ---------- personal alarms: time is entered in Ethiopian reckoning ---------- */
  function personalList() {
    if (bridge) { try { return JSON.parse(bridge.getPersonalJson()); } catch (e) { return []; } }
    try { return JSON.parse(getLS('personalAlarms') || '[]'); } catch (e) { return []; }
  }
  function personalAdd(title, time) {
    if (bridge) { try { return bridge.addPersonalAlarm(title, time); } catch (e) { return -1; } }
    var l = personalList(), id = 1000 + Date.now() % 900000;
    l.push({ id: id, name: title, time: time }); setLS('personalAlarms', JSON.stringify(l)); return id;
  }
  function personalDel(id) {
    if (bridge) { try { bridge.removePersonalAlarm(id); } catch (e) {} return; }
    setLS('personalAlarms', JSON.stringify(personalList().filter(function (a) { return a.id !== id; })));
  }
  var eh = $('eHour'), em = $('eMin'), ep = $('ePeriod'), i;
  for (i = 1; i <= 12; i++) eh.add(new Option(i, i));
  for (i = 0; i < 60; i++) em.add(new Option(pad(i), i));
  (function presetNow() { var n = new Date(), e = ethParts(n.getHours(), n.getMinutes());
    eh.value = e.h; em.value = n.getMinutes(); ep.value = (e.period === 'ሌሊት') ? 'night' : 'day'; })();
  function pickedPhone() {
    return pad(ethTo24(parseInt(eh.value, 10), ep.value === 'night')) + ':' + pad(parseInt(em.value, 10));
  }
  function preview() { $('alarmPreview').textContent = 'በስልክ ሰዓት ' + pickedPhone() + ' · በየቀኑ በዚህ ሰዓት ይጮኻል'; }
  [eh, em, ep].forEach(function (el) { el.onchange = preview; });
  preview();
  if (!bridge) $('noBridge').hidden = false;

  function renderPersonal() {
    var list = personalList();
    $('personalList').innerHTML = list.length ? list.map(function (a) {
      return '<div class="row static"><div><b>' + esc(a.name) + '</b><small>ኢትዮጵያ ' + esc(ethClock(a.time)) +
        ' · ስልክ ' + esc(a.time) + ' · በየቀኑ</small></div>' +
        '<button class="del" type="button" data-id="' + a.id + '" aria-label="ሰርዝ">✕</button></div>';
    }).join('') : '<p class="muted">ምንም የግል ማንቂያ የለም።</p>';
  }
  $('personalList').addEventListener('click', function (ev) {
    var id = ev.target && ev.target.getAttribute && ev.target.getAttribute('data-id');
    if (id && confirm('ይህ ማንቂያ ይሰረዝ?')) { personalDel(parseInt(id, 10)); renderPersonal(); }
  });
  $('addAlarm').onclick = function () {
    var title = $('alarmTitle').value.trim() || 'የግል ማንቂያ';
    if (personalAdd(title, pickedPhone()) < 0) { alert('ማንቂያውን ማስቀመጥ አልተቻለም'); return; }
    $('alarmTitle').value = '';
    renderPersonal();
  };

  /* ---------- personal notes: any number of notes ---------- */
  function notes() { try { return JSON.parse(getLS('notesList') || '[]'); } catch (e) { return []; } }
  (function migrate() {   // the single old note becomes the first note in the list
    var old = getLS('prayerNote');
    if (old && old.trim() && !getLS('notesList')) setLS('notesList', JSON.stringify([{ id: Date.now(), text: old }]));
  })();
  var editing = null;
  function renderNotes() {
    var l = notes();
    $('noteList').innerHTML = l.length ? l.map(function (n) {
      return '<div class="note-card"><p>' + esc(n.text).replace(/\n/g, '<br>') + '</p><div class="note-actions">' +
        '<button type="button" data-edit="' + n.id + '">✎ አስተካክል</button>' +
        '<button type="button" data-del="' + n.id + '">✕ ሰርዝ</button></div></div>';
    }).join('') : '<p class="muted">ምንም ማስታወሻ የለም።</p>';
  }
  $('saveNote').onclick = function () {
    var t = $('note').value.trim();
    if (!t) return;
    var l = notes();
    if (editing !== null) { l = l.map(function (n) { return n.id === editing ? { id: n.id, text: t } : n; }); editing = null; }
    else l.unshift({ id: Date.now(), text: t });
    setLS('notesList', JSON.stringify(l));
    $('note').value = ''; $('saveNote').textContent = 'ማስታወሻ ጨምር';
    $('saved').textContent = 'ተቀምጧል ✓ — ሌላ ማስታወሻ መጻፍ ይችላሉ';
    renderNotes();
  };
  $('noteList').addEventListener('click', function (ev) {
    var t = ev.target, ed = t.getAttribute && t.getAttribute('data-edit'), dl = t.getAttribute && t.getAttribute('data-del');
    if (ed) {
      var n = notes().filter(function (x) { return x.id === parseInt(ed, 10); })[0];
      if (n) { editing = n.id; $('note').value = n.text; $('saveNote').textContent = 'ለውጡን አስቀምጥ'; $('note').focus(); window.scrollTo(0, 0); }
    } else if (dl && confirm('ይህ ማስታወሻ ይሰረዝ?')) {
      setLS('notesList', JSON.stringify(notes().filter(function (x) { return x.id !== parseInt(dl, 10); })));
      renderNotes();
    }
  });

  /* ---------- tiny hash router (Android back button works through WebView history) ---------- */
  function route() {
    var h = location.hash || '#/', view = 'home';
    if (h === '#/prayers') view = 'prayers';
    else if (h === '#/alarms') view = 'alarms';
    else if (h === '#/notes') view = 'notes';
    Array.prototype.forEach.call(document.querySelectorAll('.view'), function (v) { v.hidden = (v.id !== 'v-' + view); });
    if (view === 'prayers') renderList();
    if (view === 'alarms') renderPersonal();
    if (view === 'notes') { renderNotes(); $('saved').textContent = ''; }
    window.scrollTo(0, 0);
  }
  window.addEventListener('hashchange', route);

  tick(); setInterval(tick, 1000); route();
})();
