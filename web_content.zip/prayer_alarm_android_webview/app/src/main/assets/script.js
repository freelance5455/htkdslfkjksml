(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var bridge = window.AndroidAlarm || null;
  var prayers = loadPrayers();
  var DAY = prayers.filter(function (p) { return p.group === 'day'; }).map(function (p) { return p.id; });
  var NIGHT = prayers.filter(function (p) { return p.group === 'night'; }).map(function (p) { return p.id; });

  function hm(t) { var p = t.split(':'); return [parseInt(p[0], 10), parseInt(p[1], 10)]; }
  function ethText(t) { var x = hm(t), e = ethParts(x[0], x[1]); return e.h + ':' + pad(x[1]); }
  function untilText(ms) {
    var mins = Math.max(1, Math.ceil(ms / 60000)), h = Math.floor(mins / 60), m = mins % 60;
    return (h ? h + ' ሰዓት ' : '') + (m ? m + ' ደቂቃ' : '');
  }

  /* ---------- small in-page toast + confirm (WebView ignores alert/confirm) ---------- */
  var toastTimer = null;
  function toast(msg) {
    var t = $('toast'); t.textContent = msg; t.hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.hidden = true; }, 4000);
  }
  function ask(msg, yes) {
    $('dlgMsg').textContent = msg; $('dlg').hidden = false;
    $('dlgYes').onclick = function () { $('dlg').hidden = true; yes(); };
    $('dlgNo').onclick = function () { $('dlg').hidden = true; };
  }

  /* ---------- settings: master switch + hours switched off ---------- */
  var st = { on: true, off: [] };
  (function loadState() {
    try {
      st = JSON.parse(bridge ? bridge.getSettingsJson() : (getLS('settings') || '{"on":true,"off":[]}'));
    } catch (e) { st = { on: true, off: [] }; }
  })();
  function saveState() {
    if (bridge) { try { bridge.setSettings(st.on, JSON.stringify(st.off)); } catch (e) {} }
    else setLS('settings', JSON.stringify(st));
    renderAlarmCard(); renderStatus(); tick();
  }
  function isOn(id) { return st.on && st.off.indexOf(id) < 0; }
  function sameSet(a, b) { return a.length === b.length && a.every(function (x) { return b.indexOf(x) >= 0; }); }

  function renderAlarmCard() {
    var g = st.off.length === 0 ? 'both' : sameSet(st.off, NIGHT) ? 'day' : sameSet(st.off, DAY) ? 'night' : '';
    Array.prototype.forEach.call(document.querySelectorAll('#seg button'), function (b) {
      b.classList.toggle('on', b.getAttribute('data-g') === g);
    });
    $('master').checked = st.on;
    $('alarmCard').classList.toggle('off', !st.on);
    function names(ids) { return prayers.filter(function (p) { return ids.indexOf(p.id) >= 0; }).map(function (p) { return p.name; }).join('፣ '); }
    $('segHint').textContent = 'ቀን፦ ' + names(DAY) + ' · ሌሊት፦ ' + names(NIGHT);
  }
  $('master').onchange = function () { st.on = $('master').checked; saveState(); toast(st.on ? 'ማንቂያ በርቷል' : 'ማንቂያ ጠፍቷል'); };
  $('seg').addEventListener('click', function (ev) {
    var g = ev.target.getAttribute && ev.target.getAttribute('data-g');
    if (!g) return;
    st.off = g === 'day' ? NIGHT.slice() : g === 'night' ? DAY.slice() : [];
    st.on = true; saveState();
  });

  /* ---------- clock: Ethiopian time only, 12-hour ---------- */
  function nextPrayer(now) {
    var best = null;
    prayers.forEach(function (p) {
      if (!isOn(p.id)) return;
      var x = hm(p.time), t = new Date(now);
      t.setHours(x[0], x[1], 0, 0);
      if (t <= now) t.setDate(t.getDate() + 1);
      var d = t - now;
      if (!best || d < best.d) best = { p: p, d: d };
    });
    return best;
  }
  function tick() {
    var n = new Date(), e = ethParts(n.getHours(), n.getMinutes());
    $('clock').textContent = e.h + ':' + pad(n.getMinutes());
    var nx = nextPrayer(n);
    $('nextLine').textContent = !st.on ? 'ማንቂያ ጠፍቷል' :
      nx ? ('ቀጣይ: ' + nx.p.name + ' · በ' + untilText(nx.d) + ' ውስጥ') : 'ምንም የተመረጠ ሰዓት የለም';
  }

  /* ---------- status line + test buttons ---------- */
  function renderStatus() {
    var el = $('status'), s = null;
    if (!bridge) { el.className = 'status bad'; el.textContent = '⚠ ይህ ገጽ በስልክ ላይ በተጫነው አፕ ውስጥ አልተከፈተም፤ ማንቂያ አይጮህም።'; return; }
    try { s = JSON.parse(bridge.getStatusJson()); } catch (e) {}
    if (!s) { el.className = 'status bad'; el.textContent = '⚠ ሁኔታውን ማንበብ አልተቻለም'; return; }
    if (s.err) { el.className = 'status bad'; el.textContent = '⚠ ' + s.err; return; }
    if (!s.exact) { el.className = 'status bad'; el.textContent = '⚠ «የአፕ ቅንብር» ውስጥ "Alarms & reminders" ፍቀዱ።'; return; }
    if (!st.on) { el.className = 'status'; el.textContent = 'ማንቂያ ጠፍቷል'; return; }
    el.className = 'status good';
    el.textContent = s.next ? ('✓ ማንቂያ ተዘጋጅቷል · ቀጣይ: ' + s.title + ' · በ' + untilText(s.next - Date.now()) + ' ውስጥ') : 'ምንም የተመረጠ ሰዓት የለም';
  }
  function needApk() { toast('ይህ በስልክ ላይ በተጫነው አፕ ውስጥ ብቻ ይሰራል'); }
  $('tRing').onclick = function () { if (!bridge) return needApk(); try { bridge.ringNow(); } catch (e) { toast('አልተሳካም'); } };
  $('tSched').onclick = function () {
    if (!bridge) return needApk();
    try { bridge.testIn10s(); toast('በ10 ሴኮንድ ውስጥ ይጮኻል። አፑን ዘግተው ስልኩን ቆልፉ።'); } catch (e) { toast('አልተሳካም'); }
  };
  $('bBatt').onclick = function () { if (!bridge) return needApk(); try { bridge.openBatterySettings(); } catch (e) {} };
  $('bApp').onclick = function () { if (!bridge) return needApk(); try { bridge.openAppSettings(); } catch (e) {} };

  /* ---------- prayer hours as buttons: tap one -> its meaning opens ---------- */
  function renderList() {
    var nx = nextPrayer(new Date());
    $('prayerList').innerHTML = prayers.map(function (p) {
      var cls = 'accbtn' + ((nx && nx.p.id === p.id) ? ' next' : '');
      return '<div class="acc">' +
        '<button type="button" class="' + cls + '" aria-expanded="false">' +
        '<span><b>' + esc(p.name) + '</b><small>' + esc(p.eth || ethText(p.time)) + '</small></span>' +
        '<i class="bell" id="bell' + p.id + '">' + (isOn(p.id) ? '🔔' : '🔕') + '</i><i class="chev">⌄</i></button>' +
        '<div class="accbody" hidden>' +
        '<div class="rowline"><span>ይህ ሰዓት ይጮኽ</span><label class="switch"><input type="checkbox" data-sw="' + p.id + '"' +
        (st.off.indexOf(p.id) < 0 ? ' checked' : '') + '><span></span></label></div>' +
        '<h4>ትርጉም</h4><p class="note-text">' + esc(p.note) + '</p>' +
        '<h4>የሚጸለዩ መጻሕፍት</h4><ul class="books-list">' +
        p.books.map(function (b) { return '<li>' + esc(b) + '</li>'; }).join('') + '</ul></div></div>';
    }).join('');
  }
  $('prayerList').addEventListener('click', function (ev) {
    var btn = ev.target.closest ? ev.target.closest('.accbtn') : null;
    if (!btn) return;
    var wasOpen = btn.getAttribute('aria-expanded') === 'true';
    Array.prototype.forEach.call(document.querySelectorAll('.accbtn'), function (b) {
      b.setAttribute('aria-expanded', 'false'); b.nextSibling.hidden = true; b.parentNode.classList.remove('open');
    });
    if (!wasOpen) {
      btn.setAttribute('aria-expanded', 'true'); btn.nextSibling.hidden = false; btn.parentNode.classList.add('open');
      setTimeout(function () { btn.scrollIntoView({ block: 'start', behavior: 'smooth' }); }, 30);
    }
  });
  $('prayerList').addEventListener('change', function (ev) {
    var id = ev.target.getAttribute && ev.target.getAttribute('data-sw');
    if (id === null || id === undefined) return;
    id = parseInt(id, 10);
    var i = st.off.indexOf(id);
    if (ev.target.checked && i >= 0) st.off.splice(i, 1);
    if (!ev.target.checked && i < 0) st.off.push(id);
    saveState();
    var bell = $('bell' + id); if (bell) bell.textContent = isOn(id) ? '🔔' : '🔕';
  });

  /* ---------- personal alarms: time is entered in Ethiopian reckoning (12-hour) ---------- */
  function personalList() {
    if (bridge) { try { return JSON.parse(bridge.getPersonalJson()); } catch (e) { return []; } }
    try { return JSON.parse(getLS('personalAlarms') || '[]'); } catch (e) { return []; }
  }
  function personalAdd(title, time) {
    if (bridge) { try { return bridge.addPersonalAlarm(title, time); } catch (e) { return -1; } }
    var l = personalList(), id = 1000 + Date.now() % 900000;
    l.push({ id: id, name: title, time: time }); setLS('personalAlarms', JSON.stringify(l)); return id;
  }
  function personalDel(id) {
    if (bridge) { try { bridge.removePersonalAlarm(id); } catch (e) {} return; }
    setLS('personalAlarms', JSON.stringify(personalList().filter(function (a) { return a.id !== id; })));
  }
  var eh = $('eHour'), em = $('eMin'), ep = $('ePeriod'), i;
  for (i = 1; i <= 12; i++) eh.add(new Option(i, i));
  for (i = 0; i < 60; i++) em.add(new Option(pad(i), i));
  (function presetNow() {
    var n = new Date(), e = ethParts(n.getHours(), n.getMinutes());
    eh.value = e.h; em.value = n.getMinutes(); ep.value = (n.getHours() >= 6 && n.getHours() < 18) ? 'day' : 'night';
  })();
  function pickedPhone() {
    return pad(ethTo24(parseInt(eh.value, 10), ep.value === 'night')) + ':' + pad(parseInt(em.value, 10));
  }
  function preview() {
    var x = hm(pickedPhone()), t = new Date();
    t.setHours(x[0], x[1], 0, 0);
    if (t <= new Date()) t.setDate(t.getDate() + 1);
    $('alarmPreview').textContent = 'ይህ ማንቂያ በ' + untilText(t - new Date()) + ' ውስጥ ይጮኻል፤ ከዚያ በየቀኑ በዚህ ሰዓት ይጮኻል።';
  }
  [eh, em, ep].forEach(function (el) { el.onchange = preview; });
  preview();
  if (!bridge) $('noBridge').hidden = false;

  function renderPersonal() {
    var list = personalList();
    $('personalList').innerHTML = list.length ? list.map(function (a) {
      var x = hm(a.time), night = !(x[0] >= 6 && x[0] < 18);
      return '<div class="row static"><div><b>' + esc(a.name) + '</b><small>' + esc(ethText(a.time)) +
        (night ? ' ሌሊት' : '') + ' · በየቀኑ</small></div>' +
        '<button class="del" type="button" data-id="' + a.id + '" aria-label="ሰርዝ">✕</button></div>';
    }).join('') : '<p class="muted">ምንም የግል ማንቂያ የለም።</p>';
  }
  $('personalList').addEventListener('click', function (ev) {
    var id = ev.target && ev.target.getAttribute && ev.target.getAttribute('data-id');
    if (id) ask('ይህ ማንቂያ ይሰረዝ?', function () { personalDel(parseInt(id, 10)); renderPersonal(); renderStatus(); });
  });
  $('addAlarm').onclick = function () {
    var title = $('alarmTitle').value.trim() || 'የግል ማንቂያ';
    if (personalAdd(title, pickedPhone()) < 0) { toast('ማንቂያውን ማስቀመጥ አልተቻለም'); return; }
    $('alarmTitle').value = '';
    renderPersonal(); renderStatus();
    toast('ተቀምጧል ✓ ' + $('alarmPreview').textContent);
  };

  /* ---------- personal notes: any number of notes ---------- */
  function notes() { try { return JSON.parse(getLS('notesList') || '[]'); } catch (e) { return []; } }
  (function migrate() {
    var old = getLS('prayerNote');
    if (old && old.trim() && !getLS('notesList')) setLS('notesList', JSON.stringify([{ id: Date.now(), text: old }]));
  })();
  var editing = null;
  function renderNotes() {
    var l = notes();
    $('noteList').innerHTML = l.length ? l.map(function (n) {
      return '<div class="note-card"><p>' + esc(n.text).replace(/\n/g, '<br>') + '</p><div class="note-actions">' +
        '<button type="button" data-edit="' + n.id + '">✎ አስተካክል</button>' +
        '<button type="button" data-del="' + n.id + '">✕ ሰርዝ</button></div></div>';
    }).join('') : '<p class="muted">ምንም ማስታወሻ የለም።</p>';
  }
  $('saveNote').onclick = function () {
    var t = $('note').value.trim();
    if (!t) return;
    var l = notes();
    if (editing !== null) { l = l.map(function (n) { return n.id === editing ? { id: n.id, text: t } : n; }); editing = null; }
    else l.unshift({ id: Date.now(), text: t });
    setLS('notesList', JSON.stringify(l));
    $('note').value = ''; $('saveNote').textContent = 'ማስታወሻ ጨምር';
    $('saved').textContent = 'ተቀምጧል ✓ — ሌላ ማስታወሻ መጻፍ ይችላሉ';
    renderNotes();
  };
  $('noteList').addEventListener('click', function (ev) {
    var t = ev.target, ed = t.getAttribute && t.getAttribute('data-edit'), dl = t.getAttribute && t.getAttribute('data-del');
    if (ed) {
      var n = notes().filter(function (x) { return x.id === parseInt(ed, 10); })[0];
      if (n) { editing = n.id; $('note').value = n.text; $('saveNote').textContent = 'ለውጡን አስቀምጥ'; $('note').focus(); window.scrollTo(0, 0); }
    } else if (dl) {
      ask('ይህ ማስታወሻ ይሰረዝ?', function () {
        setLS('notesList', JSON.stringify(notes().filter(function (x) { return x.id !== parseInt(dl, 10); })));
        renderNotes();
      });
    }
  });

  /* ---------- tiny hash router (Android back button works through WebView history) ---------- */
  function route() {
    var h = location.hash || '#/', view = 'home';
    if (h === '#/prayers') view = 'prayers';
    else if (h === '#/alarms') view = 'alarms';
    else if (h === '#/notes') view = 'notes';
    Array.prototype.forEach.call(document.querySelectorAll('.view'), function (v) { v.hidden = (v.id !== 'v-' + view); });
    if (view === 'home') { renderAlarmCard(); renderStatus(); }
    if (view === 'prayers') renderList();
    if (view === 'alarms') renderPersonal();
    if (view === 'notes') { renderNotes(); $('saved').textContent = ''; }
    window.scrollTo(0, 0);
  }
  window.addEventListener('hashchange', route);

  renderAlarmCard(); tick(); setInterval(tick, 1000); setInterval(renderStatus, 30000); route();
})();
