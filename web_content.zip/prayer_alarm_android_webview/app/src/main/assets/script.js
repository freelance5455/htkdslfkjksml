
function updateClocks(){
  const now=new Date();
  const localHour=now.getHours();
  // Ethiopian clock is six hours behind the local 24-hour clock, shown on a 12-hour dial.
  let ethHour=(localHour+6)%12;
  if(ethHour===0) ethHour=12;
  const minute=String(now.getMinutes()).padStart(2,'0');
  const ethPeriod=(localHour>=6 && localHour<18)?'ቀን':'ሌሊት';
  document.getElementById('ethiopianClock').textContent=String(ethHour).padStart(2,'0')+':'+minute;
  document.getElementById('ethiopianPeriod').textContent=ethPeriod;
  document.getElementById('internationalClock').textContent=
    String(localHour).padStart(2,'0')+':'+minute;
}
updateClocks();
setInterval(updateClocks,1000);
const prayers=[
['ነግሕ','05:00','ውዳሴ ማርያም፣ ይዌድስዋ መላእክት፣ ሠይፈ ሥላሴ፣ ሠይፈ መለኮት'],
['ሦስት ሰዓት','09:00','አርጋኖን፣ መልክአ ገብርኤል፣ መዝሙረ ዳዊት'],
['ስድስት ሰዓት (ቀትር)','12:00','መልክአ ሚካኤል፣ መልክአ ሥላሴ'],
['ዘጠኝ ሰዓት','15:00','መልክአ መድኃኔዓለም፣ መልክአ ዑራኤል'],
['ሰርክ','17:00','መልክአ ፋኑኤል፣ ውዳሴ ማርያም፣ ሰኔ ጎለጎታ፣ የሠርክ ጸሎት፣ የምኅላ ጸሎት'],
['ጸሎተ ንዋም','21:00','አርጋኖን፣ መልክአ ሩፋኤል'],
['እኩለ ሌሊት','00:00','መዝሙረ ዳዊት፣ መልክአ ሥላሴ፣ መልክአ ሚካኤል፣ ሰይፈ ሥላሴ ዘወትር']
];
document.getElementById('times').innerHTML=prayers.map(p=>`<div class="time"><div><b>${p[0]}</b><small>${p[2]}</small></div><strong>${p[1]}</strong></div>`).join('');
const note=document.getElementById('note');note.value=localStorage.getItem('prayerNote')||'';
document.getElementById('saveNote').onclick=()=>{localStorage.setItem('prayerNote',note.value);document.getElementById('saved').textContent='ተቀምጧል ✓'};
let personal=JSON.parse(localStorage.getItem('personalAlarms')||'[]');
function renderPersonal(){document.getElementById('personal').innerHTML=personal.map(a=>`<div class="time"><b>${a.title}</b><strong>${a.time}</strong></div>`).join('')}
renderPersonal();
document.getElementById('addAlarm').onclick=()=>{const title=document.getElementById('alarmTitle').value.trim(),time=document.getElementById('alarmTime').value;if(!title||!time){alert('ስምና ሰዓት ያስገቡ');return}const id=Date.now()%1000000;personal.push({id,title,time});localStorage.setItem('personalAlarms',JSON.stringify(personal));if(window.AndroidAlarm)AndroidAlarm.addPersonalAlarm(id,title,time);renderPersonal();document.getElementById('alarmTitle').value='';};
