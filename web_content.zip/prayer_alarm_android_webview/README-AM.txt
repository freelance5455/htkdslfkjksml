የፀሎት ማንቂያ — Android WebView + HTML/CSS/JavaScript

ይህ ፕሮጀክት ስልኩ ተቆልፎ ወይም WebView ገጹ ከፊት ላይ ባይሆንም ማንቂያ እንዲነሳ የAndroid AlarmManager እና Foreground Service ይጠቀማል።

አስፈላጊ የድምፅ ፋይል:
1) የእርስዎን MP3 በዚህ ቦታ ያስቀምጡ:
   app/src/main/res/raw/prayer_alarm.mp3
2) የፋይሉ ስም በትንሽ ፊደል እና underscore ብቻ ይሁን: prayer_alarm.mp3
3) በዚህ የስራ ክፍለ-ጊዜ የቀድሞው MP3 ፋይል በማውጫው ውስጥ ስላልተገኘ በZIP ውስጥ አልተካተተም።

መገንባት:
- Android Studio ውስጥ ይህን ፎልደር Open ያድርጉ።
- ከላይ ያለውን MP3 ወደ res/raw ያስገቡ።
- Gradle Sync ያድርጉ፣ ከዚያ Build > Build APK(s)።
- በAndroid 13+ ላይ Notifications ፍቃድ ይፍቀዱ።
- በAndroid 12+ ላይ Alarms & reminders / exact alarm ፍቃድ ካስፈለገ በSettings ውስጥ ይፍቀዱ።
- የስልኩን Alarm volume ከፍ ያድርጉ። አፑ የስልኩን የድምፅ ገደብ ማለፍ አይችልም።

ማስታወሻ:
- ዋናው የሰዓት ማሳያ የኢትዮጵያ ነው፤ ከታች የስልኩ/ዓለም አቀፍ ሰዓት በትንሽ ይታያል።
- የማንቂያ ሰዓቶቹ በስልኩ አካባቢያዊ ሰዓት ይቀጠራሉ: 05:00, 09:00, 12:00, 15:00, 17:00, 21:00, 00:00።
- የኢትዮጵያ ሰዓት ማሳያ ከስልኩ ሰዓት 6 ሰዓት በመቀየር ይታያል።
- በMainActivity.java ውስጥ ያሉት የጸሎት ሰዓቶች ከፈለጉ ሊቀየሩ ይችላሉ።
- የAndroid አምራቾች እንደ battery optimization የተለያዩ ገደቦች ሊኖራቸው ይችላል።
