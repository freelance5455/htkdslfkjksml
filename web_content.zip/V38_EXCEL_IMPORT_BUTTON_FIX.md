# V38 Excel Import Button Fix

V38 fixes Excel import controls in both Web and Android builds.

- Download Excel Template uses a bundled .xlsx template.
- Android uses a native Save dialog for the template.
- Android WebView implements the file chooser required by `<input type=file>`.
- Choose File opens the native picker.
- File text/arrayBuffer reading has compatibility fallbacks.
- Import Items remains batch insert to Supabase and keeps the existing schema.
