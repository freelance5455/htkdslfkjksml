# Eyebook SSLCommerz payment integration (starter)

## কী আছে
- Updated Eyebook HTML with checkout button and fixed-price package choices.
- Supabase Edge Function `sslcommerz-init` creates a pending payment server-side and starts SSLCommerz checkout.
- Supabase Edge Function `sslcommerz-ipn` validates the transaction with SSLCommerz before marking it paid.
- SQL migration for payment records with RLS.

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি integration starter, live payment is not enabled until your SSLCommerz merchant account is approved and secrets/URLs are configured. The payment callback should be tested thoroughly in sandbox before live. The sample currently records a successful payment; it does not automatically activate ad inventory or send creator payouts. Implement a server-side fulfillment ledger before offering paid services. Never put store password or Supabase service-role key in HTML.

## Setup (Supabase project)
1. Copy `supabase/migrations/20261024_eyebook_payments.sql` into Supabase SQL Editor and run it.
2. Deploy both functions using Supabase CLI from the project folder:
   `supabase functions deploy sslcommerz-init`
   `supabase functions deploy sslcommerz-ipn --no-verify-jwt`
   The IPN endpoint must accept the provider callback without a user JWT; it validates payment server-side.
3. Set function secrets in Supabase Dashboard or CLI:
   - `SSLCOMMERZ_STORE_ID`
   - `SSLCOMMERZ_STORE_PASSWORD`
   - `SSLCOMMERZ_SANDBOX=true` (keep true for testing; set false only for approved live account)
   - `EYebook_SITE_URL` (your actual HTTPS site origin)
   Supabase supplies `SUPABASE_URL`, `SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY`; never expose the service-role key to the browser.
4. Ensure the deployed frontend uses the same Supabase project and the authenticated user has a valid session.
5. Run sandbox tests for success, failed, cancelled, duplicate callback, amount mismatch, and unauthenticated requests. Review SSLCommerz's current merchant documentation and your callback/redirect configuration before live launch.

## Package prices
The server enforces the sample prices: Banner ৳500, Video ৳1000, Creator Plus ৳300. Change these in the `PLANS` map only after deciding your actual pricing. Do not trust amounts sent by the browser.

## Production work still needed
- Real business/merchant approval and verified business details.
- A fulfillment table/job that activates the purchased ad package exactly once after `paid`.
- Admin refunds, disputes, audit logs, fraud checks, rate limiting, webhook monitoring, and retention policy.
- Separate payout provider/API and identity verification if paying creators. Do not treat ad impressions/clicks in localStorage as billable evidence.
