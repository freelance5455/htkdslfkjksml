create table if not exists public.eyebook_payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  tran_id text not null unique,
  plan text not null check (plan in ('banner_basic', 'video_basic', 'creator_plus')),
  amount numeric(12,2) not null check (amount > 0),
  currency text not null default 'BDT' check (currency = 'BDT'),
  status text not null default 'pending' check (status in ('pending', 'paid', 'failed', 'cancelled', 'verification_failed')),
  provider_status text, val_id text, paid_at timestamptz, created_at timestamptz not null default now()
);
alter table public.eyebook_payments enable row level security;
drop policy if exists "Users can read own Eyebook payments" on public.eyebook_payments;
create policy "Users can read own Eyebook payments" on public.eyebook_payments for select to authenticated using (auth.uid() = user_id);
-- No client insert/update/delete policies: Edge Functions handle writes; service-role key stays server-side.
