import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, GET, OPTIONS", "Content-Type": "text/plain; charset=utf-8" };
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const form = req.method === "GET" ? new URL(req.url).searchParams : new URLSearchParams(await req.text());
    const tranId = form.get("tran_id");
    const valId = form.get("val_id");
    const status = form.get("status");
    if (!tranId) return new Response("Missing transaction id", { status: 400, headers: cors });
    const service = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: payment, error } = await service.from("eyebook_payments").select("*").eq("tran_id", tranId).maybeSingle();
    if (error || !payment) return new Response("Unknown transaction", { status: 404, headers: cors });
    if (payment.status === "paid") return new Response("Payment already verified", { headers: cors });
    if (status !== "VALID" || !valId) {
      await service.from("eyebook_payments").update({ status: status === "CANCELLED" ? "cancelled" : "failed", provider_status: status || "unknown" }).eq("tran_id", tranId);
      return new Response("Payment not successful", { headers: cors });
    }
    const storeId = Deno.env.get("SSLCOMMERZ_STORE_ID")!;
    const storePassword = Deno.env.get("SSLCOMMERZ_STORE_PASSWORD")!;
    const sandbox = Deno.env.get("SSLCOMMERZ_SANDBOX") !== "false";
    const validationUrl = sandbox ? "https://sandbox.sslcommerz.com/validator/api/validationserverAPI.php" : "https://securepay.sslcommerz.com/validator/api/validationserverAPI.php";
    const validation = await fetch(`${validationUrl}?val_id=${encodeURIComponent(valId)}&store_id=${encodeURIComponent(storeId)}&store_passwd=${encodeURIComponent(storePassword)}&format=json`);
    const verified = await validation.json();
    const amount = Number(verified.amount);
    if (!validation.ok || verified.status !== "VALID" || verified.tran_id !== tranId || verified.currency !== "BDT" || amount !== Number(payment.amount)) {
      await service.from("eyebook_payments").update({ status: "verification_failed", provider_status: String(verified.status || "invalid") }).eq("tran_id", tranId);
      return new Response("Payment verification failed", { status: 400, headers: cors });
    }
    const { error: updateError } = await service.from("eyebook_payments").update({ status: "paid", provider_status: "VALID", val_id: valId, paid_at: new Date().toISOString() }).eq("tran_id", tranId).eq("status", "pending");
    if (updateError) throw updateError;
    // Grant the purchased service only after this server-side verification succeeds.
    const site = Deno.env.get("EYebook_SITE_URL") || "https://example.com";
    return Response.redirect(`${site}/?payment=success&tran_id=${encodeURIComponent(tranId)}`, 303);
  } catch (e) { console.error(e); return new Response("Payment callback error", { status: 500, headers: cors }); }
});
