import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS", "Content-Type": "application/json" };
const PLANS: Record<string, { amount: number; name: string }> = {
  banner_basic: { amount: 500, name: "Eyebook Banner Ad" },
  video_basic: { amount: 1000, name: "Eyebook Video Ad" },
  creator_plus: { amount: 300, name: "Eyebook Creator Plus" },
};
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return new Response(JSON.stringify({ error: "POST required" }), { status: 405, headers: cors });
  try {
    const auth = req.headers.get("Authorization") || "";
    if (!auth.startsWith("Bearer ")) return new Response(JSON.stringify({ error: "Login required" }), { status: 401, headers: cors });
    const url = Deno.env.get("SUPABASE_URL")!;
    const anon = Deno.env.get("SUPABASE_ANON_KEY")!;
    const supabase = createClient(url, anon, { global: { headers: { Authorization: auth } } });
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) return new Response(JSON.stringify({ error: "Invalid session" }), { status: 401, headers: cors });
    const body = await req.json();
    const plan = PLANS[String(body.plan || "")];
    if (!plan) return new Response(JSON.stringify({ error: "Unknown plan" }), { status: 400, headers: cors });
    const storeId = Deno.env.get("SSLCOMMERZ_STORE_ID");
    const storePassword = Deno.env.get("SSLCOMMERZ_STORE_PASSWORD");
    const siteUrl = Deno.env.get("EYebook_SITE_URL");
    if (!storeId || !storePassword || !siteUrl) return new Response(JSON.stringify({ error: "Payment provider is not configured. Set SSLCommerz secrets and EYebook_SITE_URL." }), { status: 503, headers: cors });
    const tranId = crypto.randomUUID().replaceAll("-", "");
    const { error: insertError } = await supabase.from("eyebook_payments").insert({ user_id: user.id, tran_id: tranId, plan: String(body.plan), amount: plan.amount, currency: "BDT", status: "pending" });
    if (insertError) throw insertError;
    const sandbox = Deno.env.get("SSLCOMMERZ_SANDBOX") !== "false";
    const gateway = sandbox ? "https://sandbox.sslcommerz.com/gwprocess/v4/api.php" : "https://securepay.sslcommerz.com/gwprocess/v4/api.php";
    const form = new URLSearchParams({ store_id: storeId, store_passwd: storePassword, total_amount: String(plan.amount), currency: "BDT", tran_id: tranId, success_url: `${url}/functions/v1/sslcommerz-ipn?result=success`, fail_url: `${url}/functions/v1/sslcommerz-ipn?result=fail`, cancel_url: `${url}/functions/v1/sslcommerz-ipn?result=cancel`, ipn_url: `${url}/functions/v1/sslcommerz-ipn`, shipping_method: "NO", product_name: plan.name, product_category: "Digital Service", product_profile: "non-physical-goods", cus_name: String(user.user_metadata?.full_name || "Eyebook User").slice(0, 50), cus_email: user.email || "customer@example.com", cus_add1: "Bangladesh", cus_city: "Dhaka", cus_postcode: "1200", cus_country: "Bangladesh", cus_phone: String(user.user_metadata?.phone || "01700000000") });
    const response = await fetch(gateway, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: form });
    const data = await response.json();
    if (!response.ok || data.status !== "SUCCESS" || !data.GatewayPageURL) throw new Error("SSLCommerz did not return a checkout URL");
    return new Response(JSON.stringify({ gateway_url: data.GatewayPageURL, tran_id: tranId }), { headers: cors });
  } catch (e) { console.error(e); return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Payment initialization failed" }), { status: 500, headers: cors }); }
});
