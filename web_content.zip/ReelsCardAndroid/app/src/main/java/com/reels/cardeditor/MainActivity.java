package com.reels.cardeditor;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.graphics.Color;
import android.os.Build;
import android.util.Base64;
import android.view.View;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final String ORIGIN = "https://appassets.androidplatform.net";
    private static final int PICK = 101, SAVE = 102;
    private ValueCallback<Uri[]> fileCallback;
    private NativeVideoExporter nativeExporter;
    private byte[] pendingData;
    private java.io.File pendingFile;
    private java.io.FileOutputStream uploadStream;
    private String uploadName, uploadMime;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Color.WHITE);
        WebView web = new WebView(this);
        frame.addView(web, new FrameLayout.LayoutParams(-1, -1));
        frame.setOnApplyWindowInsetsListener((view, insets) -> {
            int top, bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                top = bars.top;
                bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            view.setPadding(0, top, 0, bottom);
            return insets;
        });
        setContentView(frame);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        nativeExporter = new NativeVideoExporter(this, web);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !ORIGIN.equals(request.getUrl().getScheme() + "://" + request.getUrl().getHost());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!ORIGIN.equals(uri.getScheme() + "://" + uri.getHost())) return null;
                String path = uri.getPath();
                if (path == null || !path.startsWith("/assets/") || path.contains("..")) return null;
                try {
                    InputStream stream = getAssets().open(path.substring(8));
                    String mime = path.endsWith(".html") ? "text/html" : path.endsWith(".png") ? "image/png" : path.endsWith(".js") ? "application/javascript" : "text/plain";
                    return new WebResourceResponse(mime, "UTF-8", stream);
                } catch (Exception e) { return null; }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try { startActivityForResult(params.createIntent(), PICK); return true; }
                catch (Exception e) { fileCallback = null; callback.onReceiveValue(null); return false; }
            }
        });
        web.loadUrl(ORIGIN + "/assets/index.html");
    }

    @Override protected void onDestroy() {
        if (nativeExporter != null) nativeExporter.destroy();
        super.onDestroy();
    }

    private class Bridge {
        @JavascriptInterface public String nativeExportVersion() { return "native-mp4-v2"; }
        @JavascriptInterface public void beginNativeVideo(long bytes) throws Exception { nativeExporter.begin(bytes); }
        @JavascriptInterface public void appendNativeVideo(String base64) throws Exception { nativeExporter.append(base64); }
        @JavascriptInterface public void encodeNativeVideo(String overlay, long startMs, long targetMs, boolean repeat, boolean sound, double zoom, double position) throws Exception {
            nativeExporter.start(overlay, startMs, targetMs, repeat, sound, zoom, position);
        }
        @JavascriptInterface public void cancelNativeVideo() { nativeExporter.cancel(); }
        @JavascriptInterface public synchronized void beginFile(String name, String mime) throws java.io.IOException {
            cancelFile();
            uploadName = name; uploadMime = mime;
            pendingFile = java.io.File.createTempFile("reels-export-", ".tmp", getCacheDir());
            uploadStream = new java.io.FileOutputStream(pendingFile);
        }
        @JavascriptInterface public synchronized void appendFile(String base64) throws java.io.IOException {
            if (uploadStream == null) throw new java.io.IOException("No export in progress");
            uploadStream.write(Base64.decode(base64, Base64.DEFAULT));
        }
        @JavascriptInterface public synchronized void cancelFile() {
            try { if (uploadStream != null) uploadStream.close(); } catch (Exception ignored) {}
            uploadStream = null;
            if (pendingFile != null) pendingFile.delete();
            pendingFile = null;
        }
        @JavascriptInterface public synchronized void finishFile() throws java.io.IOException {
            if (uploadStream == null) throw new java.io.IOException("No export in progress");
            uploadStream.close(); uploadStream = null;
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(uploadMime);
                intent.putExtra(Intent.EXTRA_TITLE, uploadName);
                try { startActivityForResult(intent, SAVE); }
                catch (Exception e) { cancelFile(); android.widget.Toast.makeText(MainActivity.this, "저장 화면을 열 수 없습니다.", android.widget.Toast.LENGTH_LONG).show(); }
            });
        }
        @JavascriptInterface public void saveDataUrl(String dataUrl, String name, String mime) {
            try {
                byte[] bytes = Base64.decode(dataUrl.substring(dataUrl.indexOf(',') + 1), Base64.DEFAULT);
                runOnUiThread(() -> {
                    pendingData = bytes;
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(mime);
                    intent.putExtra(Intent.EXTRA_TITLE, name);
                    try { startActivityForResult(intent, SAVE); }
                    catch (Exception e) { pendingData = null; }
                });
            } catch (Exception ignored) { }
        }
    }

    @Override protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (nativeExporter != null && nativeExporter.onActivityResult(code, result, data)) return;
        if (code == PICK && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            fileCallback = null;
        } else if (code == SAVE) {
            if (result == RESULT_OK && data != null && data.getData() != null && (pendingData != null || pendingFile != null)) {
                try (OutputStream stream = getContentResolver().openOutputStream(data.getData())) {
                    if (stream != null) {
                        if (pendingFile != null) {
                            try (InputStream input = new java.io.FileInputStream(pendingFile)) {
                                byte[] buffer = new byte[65536]; int count;
                                while ((count = input.read(buffer)) != -1) stream.write(buffer, 0, count);
                            }
                        } else stream.write(pendingData);
                        android.widget.Toast.makeText(this, "저장했습니다.", android.widget.Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception error) { android.widget.Toast.makeText(this, "저장 실패: 저장 공간을 확인하세요.", android.widget.Toast.LENGTH_LONG).show(); }
            }
            if (pendingFile != null) pendingFile.delete();
            pendingFile = null;
            pendingData = null;
        }
    }
}
