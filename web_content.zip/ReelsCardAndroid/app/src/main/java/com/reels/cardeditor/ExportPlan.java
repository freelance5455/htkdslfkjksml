package com.reels.cardeditor;

import java.util.ArrayList;
import java.util.List;

/** Uses integer milliseconds; the scheduled clip durations must sum exactly to the request. */
public final class ExportPlan {
    private ExportPlan() {}
    public static List<Long> segmentLengths(long sourceMs, long startMs, long targetMs, boolean repeat) {
        if (sourceMs <= 0 || startMs < 0 || startMs >= sourceMs) throw new IllegalArgumentException("시작 지점이 원본 길이를 벗어났습니다.");
        if (targetMs < 30000 || targetMs > 60000) throw new IllegalArgumentException("저장 길이는 30~60초로 설정하세요.");
        long available = sourceMs - startMs;
        if (available < targetMs && !repeat) throw new IllegalArgumentException("원본의 남은 길이가 부족합니다. 반복을 켜거나 시작 지점을 앞당기세요.");
        List<Long> result = new ArrayList<>();
        long remaining = targetMs;
        while (remaining > 0) {
            if (result.size() >= 600) throw new IllegalArgumentException("원본 구간이 너무 짧습니다. 0.1초 이상의 구간을 선택하세요.");
            long next = Math.min(available, remaining);
            result.add(next); remaining -= next;
        }
        return result;
    }
}
