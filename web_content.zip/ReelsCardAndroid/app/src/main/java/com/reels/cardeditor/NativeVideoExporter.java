package com.reels.cardeditor;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.WebView;
import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.effect.BitmapOverlay;
import androidx.media3.effect.Crop;
import androidx.media3.effect.OverlayEffect;
import androidx.media3.effect.Presentation;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.EditedMediaItemSequence;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.Transformer;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;

/** File-to-file MP4 encoder. Never records the WebView or uses a wall-clock recording. */
public final class NativeVideoExporter {
    public static final int SAVE_VIDEO = 203;
    private final Activity activity;
    private final WebView web;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private File source, output;
    private FileOutputStream upload;
    private long uploaded, expectedBytes, targetMs;
    private Transformer transformer;
    private Bitmap overlay;
    private volatile boolean active, cancelled, destroyed;
    private volatile int generation;

    public NativeVideoExporter(Activity activity, WebView web) { this.activity = activity; this.web = web; }

    public synchronized void begin(long bytes) throws Exception {
        if (active) throw new IllegalStateException("이미 저장 중입니다.");
        cleanup();
        if (bytes <= 0 || bytes > 2_000_000_000L) throw new IllegalArgumentException("지원 가능한 원본 크기는 2GB 이하입니다.");
        cancelled = false; active = true; generation++;
        source = File.createTempFile("reels-input-", ".media", activity.getCacheDir());
        expectedBytes = bytes; uploaded = 0;
        upload = new FileOutputStream(source);
    }
    public synchronized void append(String base64) throws Exception {
        if (upload == null || cancelled) throw new IllegalStateException("원본 전송이 시작되지 않았습니다.");
        byte[] chunk = Base64.decode(base64, Base64.DEFAULT);
        if (uploaded + chunk.length > expectedBytes) throw new IllegalArgumentException("원본 크기가 일치하지 않습니다.");
        upload.write(chunk); uploaded += chunk.length;
    }
    public synchronized void start(String pngDataUrl, long startMs, long requestedMs, boolean repeat, boolean sound, double zoom, double position) throws Exception {
        if (upload == null) throw new IllegalStateException("원본이 없습니다.");
        upload.close(); upload = null;
        if (uploaded != expectedBytes) { cancel(); throw new IllegalStateException("원본 전송이 완료되지 않았습니다."); }
        byte[] png = Base64.decode(pngDataUrl.substring(pngDataUrl.indexOf(',') + 1), Base64.DEFAULT);
        overlay = BitmapFactory.decodeByteArray(png, 0, png.length);
        if (overlay == null || overlay.getWidth() != 1080 || overlay.getHeight() != 1920) { cancel(); throw new IllegalArgumentException("카드 디자인을 읽지 못했습니다."); }
        targetMs = requestedMs;
        final int job = generation;
        worker.execute(() -> {
            try {
                long duration; int width, height, rotation;
                try (MediaMetadataRetriever retriever = new MediaMetadataRetriever()) {
                    retriever.setDataSource(source.getAbsolutePath());
                    duration = Long.parseLong(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
                    width = Integer.parseInt(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
                    height = Integer.parseInt(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
                    String r = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);
                    rotation = r == null ? 0 : Integer.parseInt(r);
                }
                if (rotation == 90 || rotation == 270) { int temp = width; width = height; height = temp; }
                List<Long> segments = ExportPlan.segmentLengths(duration, startMs, requestedMs, repeat);
                final int w = width, h = height;
                handler.post(() -> {
                    if (cancelled || destroyed || job != generation) return;
                    try { encode(startMs, segments, sound, zoom, position, w, h); }
                    catch (Exception e) { fail(e.getMessage()); }
                });
            } catch (Exception e) { handler.post(() -> { if (job == generation && !cancelled && !destroyed) fail(e.getMessage()); }); }
        });
    }
    private void encode(long startMs, List<Long> segments, boolean sound, double zoomValue, double positionValue, int width, int height) throws Exception {
        activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        double zoom = Math.max(1, Math.min(2, zoomValue));
        double position = Math.max(0, Math.min(1, positionValue));
        double scale = Math.max(1080.0 / width, 1920.0 / height) * zoom;
        double cropWidth = 1080.0 / scale, cropHeight = 1920.0 / scale;
        double leftPx = (width - cropWidth) / 2, topPx = (height - cropHeight) * position;
        float left = (float) (2 * leftPx / width - 1);
        float right = (float) (2 * (leftPx + cropWidth) / width - 1);
        float top = (float) (1 - 2 * topPx / height);
        float bottom = (float) (1 - 2 * (topPx + cropHeight) / height);
        List<Effect> effects = new ArrayList<>();
        effects.add(new Crop(left, right, bottom, top));
        effects.add(Presentation.createForWidthAndHeight(1080, 1920, Presentation.LAYOUT_SCALE_TO_FIT));
        effects.add(new OverlayEffect(Collections.singletonList(BitmapOverlay.createStaticBitmapOverlay(overlay))));
        Effects videoEffects = new Effects(Collections.emptyList(), effects);
        List<EditedMediaItem> items = new ArrayList<>();
        for (long length : segments) {
            MediaItem item = new MediaItem.Builder().setUri(Uri.fromFile(source))
                .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs).setEndPositionMs(startMs + length).build()).build();
            items.add(new EditedMediaItem.Builder(item).setRemoveAudio(!sound).setEffects(videoEffects).build());
        }
        Composition composition = new Composition.Builder(new EditedMediaItemSequence.Builder(items).build())
            .setHdrMode(Composition.HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_OPEN_GL).build();
        output = new File(activity.getCacheDir(), "reels-output-" + System.nanoTime() + ".mp4");
        final int job = generation;
        transformer = new Transformer.Builder(activity).setVideoMimeType(MimeTypes.VIDEO_H264).setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(new Transformer.Listener() {
                @Override public void onCompleted(Composition c, ExportResult result) {
                    if (cancelled || destroyed || job != generation) return;
                    transformer = null;
                    event("checking", "MP4 실제 길이 확인 중…", 100, 0);
                    final File candidate = output;
                    worker.execute(() -> {
                        try {
                            long duration = verify(candidate, targetMs);
                            handler.post(() -> { if (!cancelled && !destroyed && job == generation) chooseSave(duration); });
                        } catch (Exception e) { handler.post(() -> { if (!cancelled && !destroyed && job == generation) fail(e.getMessage()); }); }
                    });
                }
                @Override public void onError(Composition c, ExportResult result, ExportException error) { if (job == generation && !cancelled && !destroyed) fail("MP4 변환 실패: " + error.getMessage()); }
            }).build();
        event("encoding", "MP4 직접 변환 중 · 목표 " + (targetMs / 1000.0) + "초", 0, 0);
        transformer.start(composition, output.getAbsolutePath());
        poll(job);
    }
    private void poll(int job) {
        if (transformer == null || cancelled || destroyed || job != generation) return;
        ProgressHolder progress = new ProgressHolder();
        int state = transformer.getProgress(progress);
        event("encoding", "MP4 직접 변환 중 · 목표 " + (targetMs / 1000.0) + "초", state == Transformer.PROGRESS_STATE_AVAILABLE ? progress.progress : -1, 0);
        handler.postDelayed(() -> poll(job), 500);
    }
    /** Check BOTH container duration and real video sample timestamps; no successful 3s output for a 30s request. */
    static long verify(File file, long requested) throws Exception {
        long duration;
        try (MediaMetadataRetriever retriever = new MediaMetadataRetriever()) {
            retriever.setDataSource(file.getAbsolutePath());
            duration = Long.parseLong(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
        }
        DurationGuard.checkContainer(requested, duration);
        MediaExtractor extractor = new MediaExtractor();
        try {
            extractor.setDataSource(file.getAbsolutePath());
            int videoTrack = -1;
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat f = extractor.getTrackFormat(i);
                if (f.getString(MediaFormat.KEY_MIME).startsWith("video/")) { videoTrack = i; break; }
            }
            if (videoTrack < 0) throw new IllegalStateException("출력 영상 트랙이 없습니다.");
            extractor.selectTrack(videoTrack);
            // Start near the end; if there is only one keyframe this scans the whole file.
            extractor.seekTo(Math.max(0, requested - 2000) * 1000, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            long lastUs = -1;
            while (extractor.getSampleTime() >= 0) { lastUs = Math.max(lastUs, extractor.getSampleTime()); if (!extractor.advance()) break; }
            DurationGuard.checkLastFrame(requested, lastUs);
        } finally { extractor.release(); }
        return duration;
    }
    private void chooseSave(long duration) {
        activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        event("ready", "검증 완료 · " + duration / 1000.0 + "초 MP4 · 저장 위치를 선택하세요", 100, duration);
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("video/mp4");
        intent.putExtra(Intent.EXTRA_TITLE, "릴스_카드_" + targetMs / 1000 + "초_" + System.currentTimeMillis() + ".mp4");
        try { activity.startActivityForResult(intent, SAVE_VIDEO); } catch (Exception e) { fail("파일 저장 화면을 열 수 없습니다."); }
    }
    public boolean onActivityResult(int code, int result, Intent data) {
        if (code != SAVE_VIDEO) return false;
        if (result != Activity.RESULT_OK || data == null || data.getData() == null) { finish("cancelled", "파일 저장을 취소했습니다."); return true; }
        final Uri destination = data.getData(); final File candidate = output;
        event("saving", "MP4 파일 저장 중…", 100, 0);
        worker.execute(() -> {
            try (InputStream in = new java.io.FileInputStream(candidate); OutputStream out = activity.getContentResolver().openOutputStream(destination)) {
                if (out == null) throw new IllegalStateException("저장 위치를 열 수 없습니다.");
                byte[] buffer = new byte[65536]; int count;
                while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                out.flush(); handler.post(() -> finish("saved", "저장 완료 · " + targetMs / 1000 + "초 MP4"));
            } catch (Exception e) { handler.post(() -> fail("파일 저장 실패: " + e.getMessage())); }
        });
        return true;
    }
    public void cancel() {
        cancelled = true; generation++;
        handler.post(() -> { if (transformer != null) { transformer.cancel(); transformer = null; } finish("cancelled", "저장을 취소했습니다."); });
    }
    private void fail(String message) { finish("error", message == null ? "MP4 저장에 실패했습니다." : message); }
    private void finish(String state, String message) {
        if (destroyed) return;
        activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        worker.execute(() -> { synchronized (this) { cleanup(); active = false; } event(state, message, -1, 0); });
    }
    private synchronized void cleanup() {
        try { if (upload != null) upload.close(); } catch (Exception ignored) {}
        upload = null;
        if (source != null) source.delete(); source = null;
        if (output != null) output.delete(); output = null;
        if (overlay != null && !overlay.isRecycled()) overlay.recycle(); overlay = null;
    }
    private void event(String state, String message, int progress, long actualMs) {
        if (destroyed) return;
        try {
            JSONObject json = new JSONObject().put("state", state).put("message", message).put("progress", progress).put("actualMs", actualMs);
            handler.post(() -> { if (!destroyed) web.evaluateJavascript("window.onReelsNativeExport&&window.onReelsNativeExport(" + json + ")", null); });
        } catch (Exception ignored) {}
    }
    public void destroy() {
        destroyed = true; cancelled = true; generation++;
        if (transformer != null) { transformer.cancel(); transformer = null; }
        worker.execute(() -> { cleanup(); active = false; });
        worker.shutdown();
    }
}
