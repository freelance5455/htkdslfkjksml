package com.reels.cardeditor;

public final class DurationGuard {
    private DurationGuard() {}
    public static void checkContainer(long requestedMs, long actualMs) {
        if (actualMs <= 0 || Math.abs(actualMs - requestedMs) > 250)
            throw new IllegalStateException("길이 불일치: 설정 " + requestedMs / 1000.0 + "초 / 출력 " + actualMs / 1000.0 + "초. 잘못된 파일은 저장하지 않았습니다.");
    }
    public static void checkLastFrame(long requestedMs, long lastPresentationUs) {
        if (lastPresentationUs < (requestedMs - 250) * 1000 || lastPresentationUs > (requestedMs + 250) * 1000)
            throw new IllegalStateException("실제 영상 프레임 길이가 설정과 다릅니다. 파일을 저장하지 않았습니다.");
    }
}
