/* Additive extension: original editor remains unmodified. */
(() => {
'use strict';
const photoPanel=$('photo-panel'), head=$('headline');
head.maxLength=1000;
head.insertAdjacentHTML('afterend','<p>색상: ("문장"[#FF0000])<br>색상·굵게: ("문장"[#FF0000,bold])<br>굵기만: ("문장"[bold]) · 보통: ("문장"[normal])<br>기본 제목은 굵게 유지됩니다. 코드는 결과에 표시되지 않습니다.</p>');
photoPanel.insertAdjacentHTML('afterbegin',`<div class="group"><h2>동영상 배경</h2><label class="filebtn">동영상 선택<input id="video-file" type="file" accept="video/*"></label><p id="video-info">사진 카드 배치 위에 동영상을 넣습니다.</p><label for="clip-start">시작 지점 (초)</label><input id="clip-start" type="number" min="0" step="0.1" value="0" style="width:100%;min-height:48px"><label for="clip-length">길이 <span id="clip-label">30초</span></label><input id="clip-length" type="range" min="30" max="60" value="30"><label><input id="clip-repeat" type="checkbox" checked> 짧은 원본을 반복해 설정 길이 채우기</label><p id="clip-summary" role="status"></p><label><input id="clip-audio" type="checkbox" checked> 원본 소리 포함</label><button id="video-play" class="secondary">재생 / 일시정지</button> <button id="video-remove" class="secondary">동영상 해제</button><p>반복을 켜면 짧은 원본도 선택한 길이로 저장합니다. 내보내는 동안 화면을 켜 두세요.</p></div>`);
$('save-panel').insertAdjacentHTML('afterbegin','<div class="group"><h2>동영상 저장</h2><button class="primary" id="video-export">동영상 다운로드</button> <button class="secondary" id="video-cancel" hidden>취소</button><p id="video-progress" role="status"></p><p>지원되면 MP4로, 그 외에는 WebM으로 저장합니다. PNG 저장도 계속 사용할 수 있습니다.</p></div>');
const video=document.createElement('video');video.playsInline=true;video.preload='auto';video.muted=true;
let file=null,url=null,raf=0,busy=false,cancelled=false;
const say=t=>$('video-progress').textContent=t;
let renderingOverlay=false,nativeEncoding=false;
const versionBadge=document.createElement('small');versionBadge.textContent='v1.3.0 · MP4 직접 변환';versionBadge.style.cssText='display:block;font-size:11px';document.querySelector('.top strong').append(versionBadge);
$('video-export').textContent='설정 길이로 MP4 저장';
$('save-panel').querySelector('.group p:last-child').textContent='원본 파일을 MP4로 직접 변환합니다. 설정한 길이와 실제 프레임 길이를 검사한 뒤 저장합니다.';

const pattern=/\("([^"\n]*)"\[((?:#[0-9a-fA-F]{6})(?:,(?:bold|normal|[1-9]00))?|bold|normal|[1-9]00)\]\)/g;
function runs(text){let out=[],end=0;for(const m of text.matchAll(pattern)){if(m.index>end)out.push({text:text.slice(end,m.index)});const [a,b]=m[2].split(',');out.push({text:m[1],color:a[0]==='#'?a:null,weight:a[0]==='#'?b:a});end=m.index+m[0].length}if(end<text.length)out.push({text:text.slice(end)});return out}
function styledFont(base,weight){return weight?base.replace(/^\d+/,weight==='bold'?'800':weight==='normal'?'500':weight):base}
const measure=ctx.measureText.bind(ctx),fill=ctx.fillText.bind(ctx),image=ctx.drawImage.bind(ctx);
function width(text){const base=ctx.font;let total=0;for(const r of runs(text)){ctx.font=styledFont(base,r.weight);total+=measure(r.text).width}ctx.font=base;return total}
ctx.measureText=function(t){if(typeof t==='string'&&t.includes('("'))return {width:width(t)};return measure(t)};
ctx.fillText=function(text,x,y,max){if(y<1275||!String(text).includes('("'))return max===undefined?fill(text,x,y):fill(text,x,y,max);const base=ctx.font,total=width(text),factor=max&&total>max?max/total:1;ctx.save();ctx.translate(x,y);ctx.scale(factor,1);let dx=0;for(const r of runs(text)){ctx.font=styledFont(base,r.weight);ctx.fillStyle=r.color||'white';fill(r.text,dx,0);dx+=measure(r.text).width}ctx.restore()};
ctx.drawImage=function(im,...args){if(renderingOverlay&&(im===uploaded||im===background))return;if(file&&video.readyState>=2&&(im===uploaded||im===background)){const s=Math.max(1080/video.videoWidth,1920/video.videoHeight)*Number($('zoom').value)/100;return image(video,(1080-video.videoWidth*s)/2,(1920-video.videoHeight*s)*Number($('position').value)/100,video.videoWidth*s,video.videoHeight*s)}return image(im,...args)};
const fillRectangle=ctx.fillRect.bind(ctx);
ctx.fillRect=function(x,y,w,h){if(renderingOverlay&&x===0&&y===0&&w===1080&&h===1920&&typeof ctx.fillStyle==='string'&&['#111111','#111'].includes(ctx.fillStyle)){ctx.clearRect(0,0,1080,1920);return}return fillRectangle(x,y,w,h)};
function overlayPNG(){renderingOverlay=true;try{draw();return canvas.toDataURL('image/png')}finally{renderingOverlay=false;draw()}}
const oldUpdate=update;update=function(){oldUpdate();$('count').textContent=runs(head.value).map(r=>r.text).join('').length+'자 · 두 줄'};
function clipPlan(duration,startInput,target,repeat){
 if(!Number.isFinite(duration)||duration<=0)throw Error('원본 영상 길이를 읽지 못했습니다. 다른 원본 파일을 선택하세요.');
 const start=Math.max(0,Math.min(Number(startInput)||0,Math.max(0,duration-.1)));
 const requested=Math.max(30,Math.min(60,Number(target)||30));
 const available=duration-start;
 return {start,requested,available,length:repeat?requested:Math.min(requested,available),repeat:!!repeat};
}
function bounds(){return clipPlan(video.duration,$('clip-start').value,$('clip-length').value,$('clip-repeat').checked)}
function summary(){if(!file){$('clip-summary').textContent='';return}try{const b=bounds();$('clip-summary').textContent=`원본 ${video.duration.toFixed(1)}초 · 시작 ${b.start.toFixed(1)}초 · 저장 목표 ${b.requested.toFixed(1)}초`+(b.available<b.requested?(b.repeat?' · 짧은 원본 반복':' · 원본 부족: 반복을 켜야 저장할 수 있습니다'):'')}catch(e){$('clip-summary').textContent=e.message}}
function tick(){draw();if(!busy&&file){const b=bounds();if(video.currentTime>=Math.min(video.duration,b.start+b.length)){video.pause();video.currentTime=b.start}}if(busy||!video.paused)raf=requestAnimationFrame(tick)}
function clearVideo(){video.pause();cancelAnimationFrame(raf);video.removeAttribute('src');video.load();if(url)URL.revokeObjectURL(url);url=null;file=null;$('video-file').value='';$('video-info').textContent='사진 배경 사용 중';summary();draw()}
async function applyVideo(blob){clearVideo();if(!blob)return;file=blob;url=URL.createObjectURL(blob);video.src=url;await new Promise((ok,bad)=>{video.onloadeddata=ok;video.onerror=()=>bad(Error('동영상을 재생할 수 없습니다. MP4(H.264) 파일로 시도하세요.'))});$('clip-start').max=Math.max(0,video.duration-.1);$('video-info').textContent=`${blob.name||'저장된 동영상'} · ${video.duration.toFixed(1)}초`;video.playbackRate=1;summary();draw()}
$('video-file').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{await applyVideo(f);$('clip-start').value=0;summary();await saveCurrent()}catch(err){clearVideo();say(err.message)}};
$('video-remove').onclick=()=>{clearVideo();queueSave()};
for(const id of ['clip-start','clip-length','clip-audio','clip-repeat'])$(id).oninput=()=>{$('clip-label').textContent=$('clip-length').value+'초';video.pause();if(file)video.currentTime=bounds().start;summary();queueSave()};
video.onseeked=()=>draw();
$('video-play').onclick=async()=>{if(!file){say('먼저 동영상을 선택하세요.');return}if(!video.paused){video.pause();return}try{const b=bounds();if(video.currentTime<b.start||video.currentTime>=b.start+b.length)await seek(b.start);await video.play();tick()}catch(e){say(e.message)}};
function seek(t){return new Promise((ok,bad)=>{if(Math.abs(video.currentTime-t)<.02){ok();return}const timer=setTimeout(()=>{video.removeEventListener('seeked',done);bad(Error('시작 지점 이동에 실패했습니다.'))},10000);function done(){clearTimeout(timer);ok()}video.addEventListener('seeked',done,{once:true});video.currentTime=t})}
const oldSave=saveCurrent;saveCurrent=async function(){await oldSave();if(db&&currentId){const d=await getDraft(currentId);if(d)try{await putDraft({...d,video:file,clipStart:Number($('clip-start').value),clipLength:Number($('clip-length').value),clipAudio:$('clip-audio').checked,clipRepeat:$('clip-repeat').checked})}catch(e){say('동영상 임시 저장 실패: 기기 여유 공간을 확인하고 원본을 따로 보관하세요.')}}};
const oldLoad=loadDraft;loadDraft=async function(d){clearVideo();await oldLoad(d);try{await applyVideo(d.video||null)}catch(e){say(e.message)}$('clip-start').value=d.clipStart||0;$('clip-length').value=d.clipLength||30;$('clip-audio').checked=d.clipAudio!==false;$('clip-repeat').checked=d.clipRepeat!==false;$('clip-label').textContent=$('clip-length').value+'초';if(file)await seek(bounds().start);summary();update()};
for(const id of ['new-card','reset']){const old=$(id).onclick;$(id).onclick=async function(e){await old.call(this,e);clearVideo();await saveCurrent()}}
// Preserve video bytes in portable drafts; accept original v1 files too.
$('export-drafts').onclick=async()=>{try{await saveCurrent();const cards=[];for(const d of await listDrafts())cards.push({...d,photo:d.photo?await blobToDataURL(d.photo):null,video:d.video?await blobToDataURL(d.video):null});await download(new Blob([JSON.stringify({format:'reels-drafts-v2',cards})],{type:'application/json'}),'릴스_보관함.json')}catch(e){say('보관함 내보내기 실패: '+e.message)}};
$('import-drafts').onchange=async e=>{try{const data=JSON.parse(await e.target.files[0].text());if(!['reels-drafts-v1','reels-drafts-v2'].includes(data.format)||!Array.isArray(data.cards)||data.cards.length>200)throw Error('보관함 형식 오류');for(const d of data.cards){if(typeof d.headline!=='string'||typeof d.category!=='string')continue;const decode=async(x,type)=>typeof x==='string'&&x.startsWith('data:'+type+'/')?await(await fetch(x)).blob():null;await putDraft({...d,id:makeId(),headline:d.headline.slice(0,1000),category:d.category.slice(0,16),photo:await decode(d.photo,'image'),video:await decode(d.video,'video'),updated:Date.now()})}await showLibrary()}catch(err){say('가져오기 실패: '+err.message)}e.target.value=''};
async function download(blob,name){if(window.Android){if(Android.beginFile){Android.beginFile(name,blob.type);try{const chunk=192*1024;for(let i=0;i<blob.size;i+=chunk){const data=await blobToDataURL(blob.slice(i,i+chunk));Android.appendFile(data.split(',')[1])}Android.finishFile()}catch(e){Android.cancelFile();throw e}}else Android.saveDataUrl(await blobToDataURL(blob),name,blob.type)}else{const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),60000)}}
function lock(on){for(const el of document.querySelectorAll('button,input,textarea,select')){if(el.id!=='video-cancel'){if(on){el.dataset.wasDisabled=el.disabled?'1':'0';el.disabled=true}else{el.disabled=el.dataset.wasDisabled==='1'}}}$('video-cancel').hidden=!on}
window.onReelsNativeExport=e=>{
 say(e.message+(e.progress>=0&&e.progress<100?' · '+e.progress+'%':''));
 if(['saved','cancelled','error'].includes(e.state)){busy=false;nativeEncoding=false;lock(false);draw()}
 if(e.state==='ready'||e.state==='saving')$('video-cancel').disabled=true;
};
$('video-cancel').onclick=()=>{cancelled=true;if(nativeEncoding)Android.cancelNativeVideo()};
$('video-export').onclick=async()=>{
 if(busy)return;
 if(!file){say('먼저 동영상을 선택하세요.');return}
 if(!window.Android||typeof Android.nativeExportVersion!=='function'||Android.nativeExportVersion()!=='native-mp4-v2'){
  say('앱 업데이트가 필요합니다. v1.3.0 전체 프로젝트로 다시 설치하세요. 이전 녹화 방식으로 저장하지 않습니다.');return;
 }
 try{
  const b=bounds();
  if(!b.repeat&&b.available<b.requested){say('원본의 남은 길이가 부족합니다. 반복을 켜거나 시작 지점을 앞당기세요.');return}
  busy=true;cancelled=false;lock(true);$('video-cancel').disabled=false;video.pause();cancelAnimationFrame(raf);
  await document.fonts.ready;
  const png=overlayPNG(),snapshot=file;
  Android.beginNativeVideo(snapshot.size);nativeEncoding=true;
  const chunk=192*1024;
  for(let offset=0;offset<snapshot.size;offset+=chunk){
   if(cancelled)return;
   const data=await blobToDataURL(snapshot.slice(offset,offset+chunk));
   if(cancelled)return;
   Android.appendNativeVideo(data.split(',')[1]);
   say('원본 준비 중 · '+Math.min(100,Math.round((offset+chunk)/snapshot.size*100))+'%');
  }
  if(cancelled)return;
  say('안드로이드 MP4 변환 시작 · 목표 '+b.requested+'초');
  Android.encodeNativeVideo(png,Math.round(b.start*1000),Math.round(b.requested*1000),b.repeat,$('clip-audio').checked,Number($('zoom').value)/100,Number($('position').value)/100);
 }catch(e){
  if(nativeEncoding)Android.cancelNativeVideo();
  else{busy=false;lock(false)}
  say('저장 시작 실패: '+e.message);
 }
};
})();
