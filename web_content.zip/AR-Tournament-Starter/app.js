import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, updateProfile } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getFirestore, collection, doc, addDoc, getDoc, setDoc, updateDoc, query, where, orderBy, limit, onSnapshot, serverTimestamp, Timestamp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

const $ = id => document.getElementById(id);
const app = initializeApp(firebaseConfig), auth = getAuth(app), db = getFirestore(app);
let authMode = "login", currentUser = null, isAdmin = false, profile = null, allTournaments = [], stopChat = null, stopTours = null, stopRegs = null, stopAdminRegs = null, stopResults = null;
const show = el => el.classList.remove("hidden"), hide = el => el.classList.add("hidden");
const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c]));
const notify = (message, type="") => { const el=$("toast"); el.textContent=message; el.className=`toast ${type}`; setTimeout(()=>el.classList.add("hidden"),3500); };
const setNotice = (id, message, type="") => { const el=$(id); el.textContent=message; el.className=`notice ${type}`; show(el); };
const niceDate = ts => { try { const d=ts?.toDate ? ts.toDate() : new Date(ts); return d.toLocaleString([], {dateStyle:"medium",timeStyle:"short"}); } catch { return "Date TBA"; } };
const asDate = val => val ? new Date(val) : null;
$("year").textContent = new Date().getFullYear();
document.querySelectorAll("[data-auth-tab]").forEach(b=>b.addEventListener("click",()=>setAuthMode(b.dataset.authTab)));
function setAuthMode(mode){ authMode=mode; document.querySelectorAll("[data-auth-tab]").forEach(b=>b.classList.toggle("active",b.dataset.authTab===mode)); $("signupFields").classList.toggle("hidden",mode!=="signup"); $("authSubmit").innerHTML=mode==="signup"?'CREATE PLAYER ACCOUNT <span>↗</span>':'ENTER THE ARENA <span>↗</span>'; $("passwordInput").autocomplete=mode==="signup"?"new-password":"current-password"; $("authMessage").classList.add("hidden"); }
$("authForm").addEventListener("submit",async e=>{
  e.preventDefault(); const email=$("emailInput").value.trim(), password=$("passwordInput").value;
  $("authSubmit").disabled=true;
  try{
    if(authMode==="signup"){
      const gamerName=$("gamerNameInput").value.trim(), uid=$("uidInput").value.trim();
      if(gamerName.length<2) throw new Error("Gamer name must be at least 2 characters.");
      const cred=await createUserWithEmailAndPassword(auth,email,password);
      await updateProfile(cred.user,{displayName:gamerName});
      await setDoc(doc(db,"users",cred.user.uid),{gamerName,freeFireUid:uid,email,role:"player",createdAt:serverTimestamp(),updatedAt:serverTimestamp()});
      notify("Account created. Welcome to the arena!","success");
    }else{ await signInWithEmailAndPassword(auth,email,password); }
  }catch(err){ setNotice("authMessage",friendlyError(err),"error"); }
  finally{$("authSubmit").disabled=false;}
});
function friendlyError(err){ const code=err?.code||""; const map={"auth/email-already-in-use":"This email already has an account.","auth/invalid-email":"Enter a valid email address.","auth/weak-password":"Use a stronger password (at least 6 characters).","auth/invalid-credential":"Email or password is incorrect.","auth/too-many-requests":"Too many attempts. Try again later.","permission-denied":"Permission denied. Check your Firebase setup and account permissions."}; return map[code]||err.message||"Something went wrong."; }
$("signOutBtn").addEventListener("click",()=>signOut(auth));
onAuthStateChanged(auth, async user=>{
  cleanupListeners(); currentUser=user;
  if(!user){isAdmin=false;profile=null;show($("authView"));hide($("appView"));hide($("signOutBtn"));$("connectionBadge").textContent="SIGNED OUT";return;}
  try{
    await user.getIdToken(true);
    const token=await user.getIdTokenResult(); isAdmin=token.claims.admin===true;
    const snap=await getDoc(doc(db,"users",user.uid));
    profile=snap.exists()?snap.data():{gamerName:user.displayName||"Player",freeFireUid:""};
    show($("appView"));hide($("authView"));show($("signOutBtn"));$("connectionBadge").textContent="CONNECTED";
    $("welcomeName").textContent=profile.gamerName||"Player";$("profileGamerName").textContent=profile.gamerName||"Player";$("avatarInitials").textContent=(profile.gamerName||"P").slice(0,1).toUpperCase();$("profileRole").textContent=isAdmin?"ADMIN":"PLAYER";
    $("adminNav").classList.toggle("hidden",!isAdmin);$("editGamerName").value=profile.gamerName||"";$("editUid").value=profile.freeFireUid||"";$("editEmail").value=user.email||"";
    startTournamentListener();startChatListener();startMyRegistrations();if(isAdmin){startAdminListeners();}else{stopAdminListeners();}
  }catch(err){notify(friendlyError(err),"error");}
});
function cleanupListeners(){[stopChat,stopTours,stopRegs,stopAdminRegs,stopResults].forEach(fn=>{if(fn)fn()});stopChat=stopTours=stopRegs=stopAdminRegs=stopResults=null;}
function stopAdminListeners(){if(stopAdminRegs)stopAdminRegs();if(stopResults)stopResults();stopAdminRegs=stopResults=null;}
document.querySelectorAll(".nav-tab[data-view]").forEach(btn=>btn.addEventListener("click",()=>switchView(btn.dataset.view)));
function switchView(name){document.querySelectorAll(".nav-tab").forEach(b=>b.classList.toggle("active",b.dataset.view===name));["tournaments","chat","profile","admin"].forEach(n=>$(n+"Section").classList.toggle("hidden",n!==name));if(name==="admin"&&!isAdmin){switchView("tournaments");notify("Admin access required.","error");}}
function startTournamentListener(){
  if(stopTours)stopTours();
  stopTours=onSnapshot(query(collection(db,"tournaments"),orderBy("startAt","asc"),limit(100)),snap=>{allTournaments=snap.docs.map(d=>({id:d.id,...d.data()}));renderTournaments();renderResultTournamentOptions();},err=>notify(friendlyError(err),"error"));
}
$("refreshTournaments").addEventListener("click",()=>{if(stopTours)stopTours();startTournamentListener();notify("Refreshing tournaments…");});
function renderTournaments(){
  const grid=$("tournamentGrid"); if(!allTournaments.length){grid.innerHTML='<div class="empty-state">No tournaments yet. Check back soon.</div>';return;}
  grid.innerHTML=allTournaments.map(t=>`<article class="tour-card"><div class="tour-card-top"><span class="mode-tag">${esc((t.mode||"Solo").toUpperCase())}</span><span class="entry-tag ${t.entryType==="paid"?"paid":"free"}">${t.entryType==="paid"?"₹"+Number(t.entryFee||0)+" ENTRY":"FREE ENTRY"}</span></div><h4>${esc(t.title)}</h4><p class="prize">${esc(t.prizeDetails||"Compete for the top spot")}</p><div class="tour-meta"><div><span>MATCH START</span><b>${esc(niceDate(t.startAt))}</b></div><div><span>PLAYER SLOTS</span><b>${Number(t.registeredCount||0)} / ${Number(t.slots||0)}</b></div></div><p class="tour-rules">${esc(t.rules||"Follow tournament admin instructions.")}</p><button class="btn btn-primary" data-register="${esc(t.id)}">${t.status==="cancelled"?"CANCELLED":"REGISTER NOW ↗"}</button></article>`).join("");
  grid.querySelectorAll("[data-register]").forEach(btn=>btn.addEventListener("click",()=>registerForTournament(btn.dataset.register,btn)));
}
async function registerForTournament(id,btn){
  if(!currentUser)return; const t=allTournaments.find(x=>x.id===id); if(!t||t.status==="cancelled")return notify("This tournament is not accepting registrations.","error");
  btn.disabled=true;
  try{
    const ref=doc(db,"tournaments",id,"registrations",currentUser.uid), existing=await getDoc(ref);
    if(existing.exists())return notify("You are already registered for this tournament.");
    const regStatus=t.entryType==="paid"?"payment_pending":"pending";
    await setDoc(ref,{uid:currentUser.uid,gamerName:profile?.gamerName||currentUser.displayName||"Player",freeFireUid:profile?.freeFireUid||"",email:currentUser.email||"",status:regStatus,entryType:t.entryType,entryFee:Number(t.entryFee||0),createdAt:serverTimestamp()});
    notify(t.entryType==="paid"?"Registration saved. Follow the official payment instructions; your spot is pending payment verification.":"Registration submitted. Wait for admin confirmation.","success");
  }catch(err){notify(friendlyError(err),"error");}finally{btn.disabled=false;}
}
function startMyRegistrations(){
  if(stopRegs)stopRegs();
  stopRegs=onSnapshot(query(collection(db,"users",currentUser.uid,"registrations"),orderBy("createdAt","desc"),limit(50)),snap=>{
    const rows=snap.docs.map(d=>({id:d.id,...d.data()})); $("myRegistrations").innerHTML=rows.length?rows.map(r=>`<div class="registration-item"><div><b>${esc(r.tournamentTitle||"Tournament")}</b><small>${esc(r.mode||"")} · ${esc(r.entryType||"free")} · ${esc(niceDate(r.createdAt))}</small></div><span class="status ${esc(r.status||"pending")}">${esc((r.status||"pending").replaceAll("_"," ").toUpperCase())}</span></div>`).join(""):'<div class="empty-state">Your registrations will appear here.</div>';
  },err=>{ $("myRegistrations").innerHTML='<div class="empty-state">Could not load registrations. Check Firestore rules.</div>';});
}
// Cloud Function or a trusted server must mirror registration into users/{uid}/registrations and increment counts.
// Client cannot write that mirror or change counts; this starter keeps registration state canonical in each tournament.
function startChatListener(){
  if(stopChat)stopChat();
  stopChat=onSnapshot(query(collection(db,"chatMessages"),orderBy("createdAt","asc"),limit(100)),snap=>{
    const box=$("chatMessages");box.innerHTML=snap.docs.map(d=>{const m=d.data(),mine=m.uid===currentUser.uid;return `<div class="chat-message ${mine?"mine":""}"><b>${esc(m.gamerName||"Player")}</b><p>${esc(m.text||"")}</p><small>${esc(niceDate(m.createdAt))}</small></div>`}).join("")||'<div class="empty-state">Be the first to say hello.</div>';box.scrollTop=box.scrollHeight;
  },err=>{$("chatMessages").innerHTML='<div class="empty-state">Chat unavailable. Check Firestore rules.</div>';});
}
$("chatForm").addEventListener("submit",async e=>{e.preventDefault();const textVal=$("chatInput").value.trim();if(!textVal||textVal.length>500)return;try{await addDoc(collection(db,"chatMessages"),{uid:currentUser.uid,gamerName:profile?.gamerName||"Player",text:textVal,createdAt:serverTimestamp()});$("chatInput").value="";}catch(err){notify(friendlyError(err),"error");}});
$("profileForm").addEventListener("submit",async e=>{e.preventDefault();const gamerName=$("editGamerName").value.trim(),freeFireUid=$("editUid").value.trim();if(gamerName.length<2)return setNotice("profileMessage","Gamer name must be at least 2 characters.","error");try{await updateDoc(doc(db,"users",currentUser.uid),{gamerName,freeFireUid,updatedAt:serverTimestamp()});await updateProfile(currentUser,{displayName:gamerName});profile={...profile,gamerName,freeFireUid};$("welcomeName").textContent=gamerName;$("profileGamerName").textContent=gamerName;$("avatarInitials").textContent=gamerName.slice(0,1).toUpperCase();setNotice("profileMessage","Profile saved.","success");}catch(err){setNotice("profileMessage",friendlyError(err),"error");}});
async function requireAdmin(){if(!isAdmin)throw new Error("Admin permission required.");}
$("createTournamentForm").addEventListener("submit",async e=>{
  e.preventDefault();try{await requireAdmin();const entryType=$("tourEntry").value,entryFee=entryType==="paid"?Number($("tourFee").value):0;if(entryType==="paid"&&entryFee<=0)throw new Error("Paid tournaments must have a fee above ₹0.");const startAt=asDate($("tourStart").value);if(!startAt||Number.isNaN(startAt.getTime()))throw new Error("Choose a valid start time.");
    await addDoc(collection(db,"tournaments"),{title:$("tourTitle").value.trim(),mode:$("tourMode").value,entryType,entryFee,slots:Number($("tourSlots").value),registeredCount:0,prizeDetails:$("tourPrize").value.trim(),startAt:Timestamp.fromDate(startAt),rules:$("tourRules").value.trim(),status:"open",createdBy:currentUser.uid,createdAt:serverTimestamp(),updatedAt:serverTimestamp()});
    $("createTournamentForm").reset();$("tourFee").value="0";$("tourSlots").value="48";notify("Tournament published!","success");
  }catch(err){notify(friendlyError(err),"error");}
});
function startAdminListeners(){
  if(stopAdminRegs)stopAdminRegs();
  // Firestore collection-group query needs a collection-group index if you add filters/order.
  stopAdminRegs=onSnapshot(collection(db,"tournaments"),async snap=>{
    const chunks=[];
    for(const tdoc of snap.docs){const t=tdoc.data();try{const rs=await getDoc(doc(db,"tournaments",tdoc.id,"_meta","registrations"));}catch{}}
    // Load registrations across tournament subcollections with collectionGroup in the admin-ready variant.
    const {collectionGroup}=await import("https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js");
    const regs=await importCollectionGroup(collectionGroup);
    $("adminRegistrations").innerHTML=regs.length?regs.map(r=>`<div class="admin-item"><div><b>${esc(r.gamerName||r.email||r.uid)}</b><small>${esc(r.tournamentTitle||"Tournament")} · ${esc(r.entryType||"free")} · ${esc(r.status||"pending")}</small></div><div class="item-actions"><button class="btn btn-ghost btn-small" data-reg-action="approved" data-tour="${esc(r.tournamentId)}" data-uid="${esc(r.uid)}">Approve</button><button class="btn btn-ghost btn-small" data-reg-action="payment_confirmed" data-tour="${esc(r.tournamentId)}" data-uid="${esc(r.uid)}">Payment OK</button><button class="btn btn-ghost btn-small" data-reg-action="rejected" data-tour="${esc(r.tournamentId)}" data-uid="${esc(r.uid)}">Reject</button></div></div>`).join(""):'<div class="empty-state">No registrations yet.</div>';
    $("adminRegistrations").querySelectorAll("[data-reg-action]").forEach(b=>b.addEventListener("click",()=>updateRegistration(b.dataset.tour,b.dataset.uid,b.dataset.regAction)));
  },err=>{$("adminRegistrations").textContent="Could not load registrations: "+friendlyError(err);});
  if(stopResults)stopResults();
  stopResults=onSnapshot(query(collection(db,"results"),orderBy("createdAt","desc"),limit(30)),snap=>{$("adminResults").innerHTML=snap.docs.map(d=>{const r=d.data();return `<div class="admin-item"><div><b>#${Number(r.placement)} · ${esc(r.playerName)}</b><small>${esc(r.tournamentTitle||"Tournament")} · ${Number(r.points)} pts</small></div><span class="status confirmed">PUBLISHED</span></div>`}).join("")||'<div class="empty-state">No results published yet.</div>';},err=>{$("adminResults").textContent="Results unavailable.";});
}
async function importCollectionGroup(collectionGroupFn){
  const snap=await import("https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js").then(async fs=>await fs.getDocs(fs.query(fs.collectionGroup(db,"registrations"),fs.limit(200))));
  const rows=[];
  for(const d of snap.docs){const r=d.data();if(d.ref.path.split("/").length===4){const tid=d.ref.parent.parent?.id;const t=allTournaments.find(t=>t.id===tid);rows.push({id:d.id,tournamentId:tid,tournamentTitle:t?.title||"Tournament",...r});}}
  return rows;
}
async function updateRegistration(tournamentId,uid,status){
  try{await requireAdmin();await updateDoc(doc(db,"tournaments",tournamentId,"registrations",uid),{status,reviewedBy:currentUser.uid,reviewedAt:serverTimestamp()});notify("Registration updated. Player-facing mirror may require a trusted backend sync.","success");}catch(err){notify(friendlyError(err),"error");}
}
function renderResultTournamentOptions(){const sel=$("resultTournament"),old=sel.value;sel.innerHTML='<option value="">Select tournament</option>'+allTournaments.map(t=>`<option value="${esc(t.id)}">${esc(t.title)}</option>`).join("");if(old)sel.value=old;}
$("resultForm").addEventListener("submit",async e=>{e.preventDefault();try{await requireAdmin();const t=allTournaments.find(x=>x.id===$("resultTournament").value);if(!t)throw new Error("Select a tournament.");await addDoc(collection(db,"results"),{tournamentId:t.id,tournamentTitle:t.title,playerName:$("resultPlayer").value.trim(),placement:Number($("resultPlacement").value),points:Number($("resultPoints").value),notes:$("resultNotes").value.trim(),createdBy:currentUser.uid,createdAt:serverTimestamp()});$("resultForm").reset();notify("Result published.","success");}catch(err){notify(friendlyError(err),"error");}});
