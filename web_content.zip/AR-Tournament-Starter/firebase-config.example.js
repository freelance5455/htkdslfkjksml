// Copy this file to firebase-config.js and paste your Firebase Web App config.
// Firebase Console > Project settings > General > Your apps > SDK setup.
// These values identify your project; security must come from Authentication and Security Rules.
export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};
