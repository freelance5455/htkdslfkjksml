# AR-Tournament — Starter Project

A mobile-first red-neon esports tournament starter built with HTML, CSS, JavaScript, Firebase Authentication and Cloud Firestore. Capacitor wraps the web app into an Android project. This is a **starter**, not a production-ready tournament/payment platform.

## Included
- Email/password account creation and sign-in
- Player profile (gamer name and optional Free Fire UID)
- Tournament listing and player registration
- Free and paid tournament metadata
- Real-time community chat
- Admin-only tournament creation and results publishing
- Registration review controls
- Firestore and Storage security rules
- Capacitor Android wrapper configuration

## 1. Create Firebase project
1. Open https://console.firebase.google.com/ and create a project.
2. Add a **Web app** in Project settings.
3. Copy `firebase-config.example.js` to `firebase-config.js` and replace every `YOUR_...` value with your Firebase Web App config.
4. In Firebase Console > Authentication > Sign-in method, enable **Email/Password**.
5. Create a Cloud Firestore database.
6. In Firestore > Rules, paste `firestore.rules` and publish.
7. In Storage > Rules, paste `storage.rules` and publish if you enable Storage.
8. For production, enable Firebase App Check and set up monitoring and backups.

The Firebase web config is not a server secret. Do not put service-account JSON, private keys, or payment provider secrets in frontend files.

## 2. Run the website locally
Requires Node.js 20+ recommended.
```bash
npm install
cp firebase-config.example.js firebase-config.js
# Edit firebase-config.js with your Firebase config
npm run serve
```
Open http://localhost:8080. Do not open `index.html` as a `file://` URL; ES modules need a local web server.

## 3. Make your account an admin
Admin status is a **Firebase custom claim**, not a profile field. Never let a user set their own admin flag from the app.

On a trusted computer with Node.js, create a separate private admin-tools folder:
```bash
mkdir admin-tools && cd admin-tools
npm init -y
npm install firebase-admin
```
Download a service account key from Firebase Console > Project settings > Service accounts and store it securely as `serviceAccountKey.json` in this private folder. Never upload it to the website or share it.
Create `make-admin.cjs`:
```js
const admin = require('firebase-admin');
const serviceAccount = require('./serviceAccountKey.json');
admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });

const email = process.argv[2];
if (!email) throw new Error('Usage: node make-admin.cjs you@example.com');

(async () => {
  const user = await admin.auth().getUserByEmail(email);
  await admin.auth().setCustomUserClaims(user.uid, { admin: true });
  console.log(`Admin claim set for ${email}. Sign out and sign back in.`);
  process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
```
Run `node make-admin.cjs your-email@example.com`. Restart your session/sign out and back in so the refreshed token contains `admin: true`. Do not commit the service account key to Git.

## 4. Build Android APK with Capacitor
Install:
- Node.js LTS
- Android Studio and Android SDK
- A JDK version supported by your installed Android Gradle plugin (Android Studio bundled JDK is generally easiest)

From the project root:
```bash
npm install
cp firebase-config.example.js firebase-config.js
# Edit firebase-config.js first
npx cap add android
npx cap sync android
npx cap open android
```
In Android Studio, wait for Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Android Studio will show the APK output path. For release, configure a signing key and build a signed APK/AAB. Keep the signing key private.

**Note:** Capacitor `webDir` is set to the project root for this starter. If you reorganize files into a `www/` folder, update `webDir` and copy the app files there before running `cap sync`.

## 5. Important limitations before public launch
- **Paid entries are not processed by this starter.** The paid option only records the fee and puts the registration into `payment_pending`. Add a compliant payment provider (for example, a provider available to your business and region) with server-side verification and webhooks before marking payments confirmed. Never trust a screenshot or a client-side “payment successful” button. Check applicable Indian laws, platform policies, age restrictions, refund rules, and provider terms.
- The starter admin registration screen reads a collection-group query. For a production app, add a trusted Cloud Function to mirror registrations into a queryable admin collection and to maintain slot counts atomically. Firestore does not allow the player to write the user registration mirror.
- This demo's registration UI stores the canonical registration under `tournaments/{tournamentId}/registrations/{uid}`. A backend sync is recommended for a fully polished “My registrations” view and reliable slot-limit enforcement. Do not rely on client-side slot counts to prevent overbooking.
- Chat is a shared community room, not private one-to-one messaging. Add report/block/moderation workflows, rate limiting, and retention controls before launch.
- Tournament result entries are public to signed-in users. Admin claims and Firestore rules enforce write permissions.
- Add account deletion, email verification, abuse reporting, privacy policy, terms, and data protection disclosures before public release.
- Use your own original branding/artwork. Free Fire is a third-party game; this project is not affiliated with or endorsed by its publisher.

## Data model
- `users/{uid}` — player profile
- `tournaments/{tournamentId}` — tournament details
- `tournaments/{tournamentId}/registrations/{uid}` — registration and admin review status
- `chatMessages/{messageId}` — community messages
- `results/{resultId}` — published results

## Troubleshooting
- `Missing or insufficient permissions`: publish the included rules, ensure signed-in state, and confirm admin custom claim if using admin features.
- Sign-in fails: enable Email/Password in Firebase Authentication and verify the config values.
- Blank page in Android: run `npx cap sync android`, confirm `firebase-config.js` exists, and inspect Android Studio Logcat.
- Admin tab missing: sign out/in after setting the custom claim and verify the account email.
