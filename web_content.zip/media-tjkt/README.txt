MEDIA BELAJAR TJKT FASE F - SMK NEGERI 1 LAMBOYA
Dibuat oleh: Agustinus Lay Rihi, ST

CARA MEMAKAI
1. Ekstrak (extract) file zip ini sampai semua folder terlihat.
2. Buka file index.html dengan Chrome, Edge, atau Firefox (tidak perlu internet).
3. Klik "Mulai Belajar" agar musik latar menyala.
   Musik dan efek suara dapat dimatikan di pojok kanan atas.

ISI MEDIA
- CP dan TP, Materi Ajar (3 modul, 29 subbab), Latihan Soal, Kuis,
  Praktik (6 lembar kerja + simulator terminal Linux), dan LKPD (3 lembar).
- Alat bantu: alat peraga topologi, kalkulator subnet, alat bantu VLSM,
  kalkulator arus dan MCB.

UNTUK GURU
- Isi materi: js/data.js. Soal, praktik, dan LKPD: js/data2.js.
- Logo: assets/logo.png (ganti dengan nama file yang sama bila perlu).
- Progres, skor, dan jawaban LKPD tersimpan di peramban masing-masing murid.
