/* Aplikasi utama: routing, halaman, latihan, kuis, praktik, LKPD. */
(function () {
  'use strict';
  const D = DATA;
  const view = document.getElementById('view');
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const mod = id => D.modules.find(m => m.id === id);
  const reduceMotion = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  const sfx = n => { try { Snd.play(n); } catch (e) { /* abaikan */ } };

  /* ---------- penyimpanan ---------- */
  const KEY = 'media-tjkt-lamboya-v1';
  let S = { read: {}, best: {}, lat: {}, prak: {}, lkpd: {}, name: '' };
  try { S = Object.assign(S, JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (e) { /* abaikan */ }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { /* abaikan */ } }

  /* ---------- util ---------- */
  function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
  function toast(msg) {
    const t = document.createElement('div'); t.className = 'toast noprint'; t.setAttribute('role', 'status'); t.textContent = msg;
    document.body.appendChild(t); setTimeout(() => t.remove(), 2600);
  }
  const readCount = m => m.sections.filter(s => S.read[s.id]).length;
  const totalSections = D.modules.reduce((n, m) => n + m.sections.length, 0);
  function modChips(route, cur) {
    return '<div class="chips">' + D.modules.map((m, i) => '<a class="chip ' + (m.id === cur ? 'on' : '') + '" href="#/' + route + '/' + m.id + '">' + (i + 1) + '. ' + esc(m.short) + '</a>').join('') + '</div>';
  }

  /* ---------- navigasi ---------- */
  const TABS = [['beranda', '🏠', 'Beranda'], ['cp', '🎯', 'CP & TP'], ['materi', '📚', 'Materi'], ['latihan', '✏️', 'Latihan'], ['kuis', '🏆', 'Kuis'], ['praktik', '🛠️', 'Praktik'], ['lkpd', '📝', 'LKPD']];
  const tabsEl = document.getElementById('tabs');
  tabsEl.innerHTML = TABS.map(t => '<a href="#/' + t[0] + '" data-id="' + t[0] + '"><span class="ic" aria-hidden="true">' + t[1] + '</span><span>' + t[2] + '</span></a>').join('');

  /* ---------- Beranda ---------- */
  function pageBeranda() {
    const nSoal = Object.values(D.latihan).reduce((n, a) => n + a.length, 0) + Object.values(D.kuis).reduce((n, a) => n + a.length, 0);
    const done = D.modules.reduce((n, m) => n + readCount(m), 0);
    view.innerHTML =
      '<section class="hero"><div><h2>Belajar jaringan dari kabel sampai server</h2>' +
      '<p class="lead">Media interaktif untuk murid TJKT Fase F SMK Negeri 1 Lamboya. Pelajari tiga materi, berlatih soal, ikuti kuis, kerjakan praktik, dan isi LKPD di satu tempat.</p>' +
      '<div class="row mt"><a class="btn gold" href="#/materi">Mulai dari materi</a><a class="btn" href="#/cp">Lihat CP dan TP</a></div>' +
      '<p class="hint">Progres membaca: ' + done + ' dari ' + totalSections + ' subbab selesai.</p></div>' +
      '<div class="hero-logo"><img src="assets/logo.png" alt="Logo SMK Negeri 1 Lamboya"></div></section>' +
      '<h3 class="mt">Tiga materi</h3><div class="grid g3">' + D.modules.map(modCard).join('') + '</div>' +
      '<h3 class="mt">Menu belajar</h3><div class="menu">' +
      '<a href="#/cp"><b>CP dan TP</b><span>Capaian dan tujuan pembelajaran</span></a>' +
      '<a href="#/materi"><b>Materi Ajar</b><span>' + totalSections + ' subbab dengan alat peraga</span></a>' +
      '<a href="#/latihan"><b>Latihan Soal</b><span>Jawaban dan pembahasan langsung</span></a>' +
      '<a href="#/kuis"><b>Kuis</b><span>' + nSoal + ' soal tersedia, ada penghitung waktu</span></a>' +
      '<a href="#/praktik"><b>Praktik</b><span>' + D.praktek.length + ' lembar kerja dan terminal simulasi</span></a>' +
      '<a href="#/lkpd"><b>LKPD</b><span>Isi dan cetak lembar kerja</span></a></div>' + bestBox();
  }
  function bestBox() {
    const k = Object.keys(S.best);
    if (!k.length) return '';
    const lab = { m1: 'Modul 1', m2: 'Modul 2', m3: 'Modul 3', mix: 'Campuran' };
    return '<div class="panel mt"><h3>Skor kuis terbaikmu</h3><div class="row">' + k.map(x => '<span class="chip on">' + (lab[x] || x) + ': ' + S.best[x] + '</span>').join('') + '</div></div>';
  }
  function modCard(m, i) {
    const n = m.sections.length, d = readCount(m), pct = Math.round(100 * d / n);
    return '<a class="mcard" href="#/materi/' + m.id + '/0" style="--c:' + m.color + '"><div class="mi" aria-hidden="true">' + m.icon + '</div><h3>' + (i + 1) + '. ' + esc(m.title) + '</h3><p>' + esc(m.desc) + '</p><div class="prog" aria-hidden="true"><i style="width:' + pct + '%"></i></div><small>' + d + ' dari ' + n + ' subbab selesai</small></a>';
  }

  /* ---------- CP & TP ---------- */
  function pageCP() {
    view.innerHTML = '<h2>Capaian dan Tujuan Pembelajaran</h2>' +
      '<div class="panel"><h3>Capaian Pembelajaran (CP) Fase F</h3><p>' + esc(D.cp.umum) + '</p>' +
      D.cp.elemen.map((e, i) => '<h4>Elemen ' + (i + 1) + ': ' + esc(e.n) + '</h4><p>' + esc(e.t) + '</p>').join('') +
      '<p class="hint">' + esc(D.cp.catatan) + '</p></div>' +
      '<h3 class="mt">Tujuan Pembelajaran (TP)</h3><div class="grid g3">' +
      D.modules.map((m, i) => '<div class="panel" style="border-top:4px solid ' + m.color + '"><h3>' + (i + 1) + '. ' + esc(m.title) + '</h3><p>Setelah mempelajari materi ini, kamu mampu:</p><ul>' + m.tp.map(t => '<li>' + esc(t) + '</li>').join('') + '</ul></div>').join('') + '</div>';
  }

  /* ---------- Materi ---------- */
  function pageMateri(p) {
    const mid = p[0];
    if (!mid || !mod(mid)) {
      view.innerHTML = '<h2>Materi Ajar</h2><p class="lead">Pilih satu materi. Setiap materi terdiri dari beberapa subbab dan sebagian memiliki alat bantu interaktif.</p><div class="grid g3 mt">' + D.modules.map(modCard).join('') + '</div>';
      return;
    }
    const m = mod(mid), si = Math.min(Math.max(parseInt(p[1], 10) || 0, 0), m.sections.length - 1), s = m.sections[si];
    const chips = m.sections.map((x, i) => '<a class="chip ' + (i === si ? 'on' : '') + ' ' + (S.read[x.id] ? 'done' : '') + '" href="#/materi/' + m.id + '/' + i + '">' + (i + 1) + '. ' + esc(x.title) + '</a>').join('');
    const prev = si > 0 ? '<a class="btn" href="#/materi/' + m.id + '/' + (si - 1) + '">Sebelumnya</a>' : '<span></span>';
    const next = si < m.sections.length - 1 ? '<a class="btn gold" href="#/materi/' + m.id + '/' + (si + 1) + '">Berikutnya</a>' : '<a class="btn gold" href="#/latihan/' + m.id + '">Latihan soal materi ini</a>';
    view.innerHTML = '<p class="row"><a class="chip" href="#/materi">Semua materi</a> <b>' + esc(m.title) + '</b></p><div class="chips scroll">' + chips + '</div>' +
      '<article class="panel prose"><h2>' + esc(s.title) + '</h2>' + s.html + (s.tool ? '<div class="tool" id="tool"></div>' : '') + '</article>' +
      '<div class="pager"><div>' + prev + '</div><button class="btn ' + (S.read[s.id] ? '' : 'ghost') + '" type="button" data-act="read" data-id="' + s.id + '" aria-pressed="' + (!!S.read[s.id]) + '">' + (S.read[s.id] ? '✔ Sudah paham' : 'Tandai sudah paham') + '</button><div>' + next + '</div></div>';
    if (s.tool && TOOLS[s.tool]) TOOLS[s.tool]($('#tool'));
  }

  /* ---------- Latihan ---------- */
  let lat = null;
  function pageLatihan(p) {
    const mid = mod(p[0]) ? p[0] : 'm1', qs = D.latihan[mid];
    lat = { mid, n: 0, ok: 0 };
    view.innerHTML = '<h2>Latihan Soal</h2><p class="lead">Pilih materi, jawab soal, dan lihat pembahasan langsung. Latihan bisa diulang kapan saja.</p>' + modChips('latihan', mid) +
      '<div class="score noprint" aria-live="polite"><span id="latBenar">Benar: 0</span><span>Dijawab: <b id="latN">0</b> / ' + qs.length + '</span></div>' +
      qs.map((q, i) => '<div class="panel q" id="lq' + i + '"><h4>' + (i + 1) + '. ' + esc(q.q) + '</h4><div class="opts">' +
        q.o.map((o, j) => '<button class="opt" type="button" data-act="lat" data-i="' + i + '" data-j="' + j + '"><b>' + 'ABCD'[j] + '.</b><span>' + esc(o) + '</span></button>').join('') +
        '</div><div class="expl" hidden></div></div>').join('') +
      '<div class="row"><a class="btn ghost" href="#/latihan/' + mid + '" data-act="again">Ulangi latihan</a></div>';
  }
  function actLat(t) {
    const i = +t.dataset.i, j = +t.dataset.j, q = D.latihan[lat.mid][i], card = $('#lq' + i);
    if (card.dataset.done) return;
    card.dataset.done = '1';
    const ok = j === q.a; lat.n++; if (ok) lat.ok++;
    $$('.opt', card).forEach((b, k) => { b.disabled = true; if (k === q.a) b.classList.add('ok'); else if (k === j) b.classList.add('bad'); });
    const ex = $('.expl', card); ex.hidden = false; ex.innerHTML = '<b>' + (ok ? 'Benar. ' : 'Belum tepat. ') + '</b>' + esc(q.e);
    $('#latBenar').textContent = 'Benar: ' + lat.ok; $('#latN').textContent = lat.n;
    sfx(ok ? 'ok' : 'bad');
    if (lat.n === D.latihan[lat.mid].length) {
      S.lat[lat.mid] = Math.max(S.lat[lat.mid] || 0, lat.ok); save();
      toast('Latihan selesai: ' + lat.ok + ' dari ' + lat.n + ' benar'); sfx(lat.ok >= lat.n * 0.7 ? 'win' : 'lose');
    }
  }

  /* ---------- Kuis ---------- */
  const TLIM = 40;
  let quiz = null;
  function stopTimer() { if (quiz && quiz.timer) { clearInterval(quiz.timer); quiz.timer = null; } }
  function shuffleOpts(q) {
    const idx = shuffle(q.o.map((_, i) => i));
    return { q: q.q, o: idx.map(i => q.o[i]), a: idx.indexOf(q.a), e: q.e };
  }
  function buildQuiz(mode) {
    let pool = [];
    if (mode === 'mix') ['m1', 'm2', 'm3'].forEach(k => { pool = pool.concat(shuffle(D.kuis[k].slice()).slice(0, 4)); });
    else pool = D.kuis[mode].slice();
    return { mode, qs: shuffle(pool).map(shuffleOpts), i: 0, score: 0, log: [], done: false, answered: false, timer: null };
  }
  function pageKuis() {
    stopTimer();
    if (!quiz) return kuisMenu();
    if (quiz.done) return kuisResult();
    kuisQuestion();
  }
  function kuisMenu() {
    const lab = [['m1', 'Modul 1: Administrasi Sistem Jaringan', '8 soal'], ['m2', 'Modul 2: Perencanaan dan Pengalamatan Jaringan', '8 soal'], ['m3', 'Modul 3: Teknik Instalasi Tenaga Listrik', '8 soal'], ['mix', 'Campuran semua modul', '12 soal acak']];
    view.innerHTML = '<h2>Kuis</h2><p class="lead">Setiap soal punya waktu ' + TLIM + ' detik. Urutan soal dan pilihan jawaban diacak setiap kali kuis dimulai.</p>' +
      '<div class="panel"><div class="field" style="max-width:420px"><label for="qName">Nama kamu</label><input id="qName" type="text" value="' + esc(S.name) + '" placeholder="Tulis namamu" autocomplete="name"></div>' +
      '<div class="grid g2 mt">' + lab.map(l => '<button class="mcard" style="text-align:left;font:inherit;cursor:pointer;--c:var(--gold)" type="button" data-act="kuis-start" data-mode="' + l[0] + '"><h3>' + l[1] + '</h3><small>' + l[2] + (S.best[l[0]] != null ? '. Skor terbaik: ' + S.best[l[0]] : '') + '</small></button>').join('') + '</div></div>';
  }
  function kuisQuestion() {
    const q = quiz.qs[quiz.i], n = quiz.qs.length;
    quiz.answered = false; quiz.t0 = Date.now();
    view.innerHTML = '<h2>Kuis</h2><div class="score" aria-live="polite"><span>Soal <b>' + (quiz.i + 1) + '</b> dari ' + n + '</span><span>Benar: ' + quiz.score + '</span></div>' +
      '<div class="timer" aria-hidden="true"><i id="qBar"></i></div>' +
      '<div class="panel q"><h4>' + esc(q.q) + '</h4><div class="opts" id="qOpts">' +
      q.o.map((o, j) => '<button class="opt" type="button" data-act="kuis-pick" data-j="' + j + '"><b>' + 'ABCD'[j] + '.</b><span>' + esc(o) + '</span></button>').join('') +
      '</div><div id="qFb"></div></div>';
    const bar = $('#qBar');
    quiz.timer = setInterval(() => {
      const left = TLIM - (Date.now() - quiz.t0) / 1000;
      if (left <= 0) { kuisAnswer(-1); return; }
      bar.style.width = (100 * left / TLIM) + '%';
      bar.style.background = left < 10 ? 'var(--red)' : left < 20 ? 'var(--gold)' : 'var(--green)';
    }, 100);
  }
  function kuisAnswer(j) {
    if (!quiz || quiz.answered) return;
    quiz.answered = true; stopTimer();
    const q = quiz.qs[quiz.i], ok = j === q.a;
    if (ok) quiz.score++;
    quiz.log.push({ q: q.q, chosen: j < 0 ? 'Tidak dijawab (waktu habis)' : q.o[j], right: q.o[q.a], ok });
    $$('#qOpts .opt').forEach((b, k) => { b.disabled = true; if (k === q.a) b.classList.add('ok'); else if (k === j) b.classList.add('bad'); });
    const last = quiz.i === quiz.qs.length - 1;
    $('#qFb').innerHTML = '<div class="expl"><b>' + (j < 0 ? 'Waktu habis. ' : ok ? 'Benar. ' : 'Belum tepat. ') + '</b>' + esc(q.e) + '</div><div class="row mt"><button class="btn gold" type="button" data-act="kuis-next">' + (last ? 'Lihat hasil' : 'Soal berikutnya') + '</button></div>';
    sfx(ok ? 'ok' : 'bad');
  }
  function kuisNext() {
    quiz.i++;
    if (quiz.i >= quiz.qs.length) {
      quiz.done = true;
      const sc = Math.round(100 * quiz.score / quiz.qs.length);
      S.best[quiz.mode] = Math.max(S.best[quiz.mode] || 0, sc); save();
      sfx(sc >= 70 ? 'win' : 'lose');
    }
    pageKuis();
  }
  function kuisResult() {
    const n = quiz.qs.length, sc = Math.round(100 * quiz.score / n);
    const msg = sc >= 85 ? 'Luar biasa! Kamu menguasai materi ini.' : sc >= 70 ? 'Bagus. Pertahankan dan perdalam bagian yang masih salah.' : sc >= 55 ? 'Cukup. Baca ulang materinya, lalu coba lagi.' : 'Ayo pelajari lagi materinya, lalu ulangi kuis.';
    view.innerHTML = '<h2>Hasil Kuis</h2><div class="panel" style="text-align:center"><p>' + (S.name ? esc(S.name) : 'Peserta') + '</p><div class="big-score">' + sc + '</div><p>' + quiz.score + ' dari ' + n + ' soal benar</p><p><b>' + msg + '</b></p>' +
      '<div class="row noprint" style="justify-content:center"><button class="btn gold" type="button" data-act="kuis-start" data-mode="' + quiz.mode + '">Ulangi kuis</button><button class="btn" type="button" data-act="kuis-menu">Pilih kuis lain</button><button class="btn ghost" type="button" data-act="print">Cetak hasil</button></div></div>' +
      '<h3 class="mt">Tinjauan jawaban</h3>' + quiz.log.map((l, i) => '<div class="review ' + (l.ok ? 'ok' : 'bad') + '"><b>' + (i + 1) + '. ' + esc(l.q) + '</b><br>Jawabanmu: ' + esc(l.chosen) + (l.ok ? '' : '<br>Jawaban benar: ' + esc(l.right)) + '</div>').join('');
  }

  /* ---------- Praktik ---------- */
  function pagePraktik() {
    view.innerHTML = '<h2>Praktik</h2><p class="lead">Ikuti lembar kerja langkah demi langkah dan centang setiap langkah yang sudah selesai. Gunakan simulator terminal di bawah untuk berlatih perintah Linux dengan aman.</p>' +
      D.praktek.map((j, n) => {
        const st = S.prak[j.id] || [], d = j.langkah.filter((_, i) => st[i]).length;
        return '<details class="job" id="job-' + j.id + '"><summary><span>' + esc(j.title) + '</span><small id="jp-' + j.id + '">' + d + '/' + j.langkah.length + ' langkah</small></summary><div class="jobbody">' +
          '<p><b>Tujuan:</b> ' + esc(j.tujuan) + '</p><p><b>Alat dan bahan:</b> ' + esc(j.alat) + '</p><p><b>Alokasi waktu:</b> ' + esc(j.durasi) + '</p>' +
          '<h4>Langkah kerja</h4><ul class="steps">' + j.langkah.map((l, i) => '<li class="' + (st[i] ? 'done' : '') + '"><input type="checkbox" id="st-' + j.id + '-' + i + '" data-act-change="step" data-p="' + j.id + '" data-i="' + i + '"' + (st[i] ? ' checked' : '') + '><label for="st-' + j.id + '-' + i + '"><span>' + esc(l) + '</span></label></li>').join('') + '</ul>' +
          '<div class="tip"><b>Hasil yang diharapkan:</b> ' + esc(j.hasil) + '</div>' + (j.mod === 'm3' ? '<div class="warn">Praktik listrik hanya dilakukan di bawah pengawasan guru dan dengan sumber tegangan dalam keadaan mati saat merangkai.</div>' : '') + '</div></details>';
      }).join('') + '<h3 class="mt">Simulator terminal Linux</h3><div id="termBox"></div>';
    TOOLS.terminal($('#termBox'), ok => { sfx('ok'); if (ok) { sfx('win'); toast('Semua misi terminal selesai!'); } });
  }
  function actStep(t) {
    const id = t.dataset.p, i = +t.dataset.i, j = D.praktek.find(x => x.id === id);
    const st = S.prak[id] || (S.prak[id] = []); st[i] = t.checked; save();
    t.closest('li').classList.toggle('done', t.checked);
    const d = j.langkah.filter((_, k) => st[k]).length;
    $('#jp-' + id).textContent = d + '/' + j.langkah.length + ' langkah';
    sfx(t.checked ? 'click' : 'nav');
    if (d === j.langkah.length && t.checked) { toast('Lembar kerja selesai!'); sfx('win'); }
  }

  /* ---------- LKPD ---------- */
  function pageLKPD(p) {
    const l = D.lkpd.find(x => x.id === p[0]) || D.lkpd[0], rec = S.lkpd[l.id] || (S.lkpd[l.id] = { nama: S.name || '', kelas: '', kelompok: '', a: [] });
    view.innerHTML = '<h2>LKPD</h2><p class="lead noprint">Isi jawabanmu, lalu cetak atau simpan sebagai PDF, atau unduh sebagai file teks. Jawaban tersimpan otomatis di peramban ini.</p>' +
      '<div class="chips noprint">' + D.lkpd.map(x => '<a class="chip ' + (x.id === l.id ? 'on' : '') + '" href="#/lkpd/' + x.id + '">' + esc(x.title) + '</a>').join('') + '</div>' +
      '<div class="panel"><div class="row" style="align-items:center;gap:12px"><img src="assets/logo.png" alt="" width="56" height="56"><div><b>SMK Negeri 1 Lamboya</b><br>Teknik Jaringan Komputer dan Telekomunikasi, Fase F</div></div>' +
      '<h3 class="mt">' + esc(l.title) + '</h3><p>' + esc(l.petunjuk) + '</p>' +
      '<div class="row"><div class="field"><label for="lkNama">Nama</label><input id="lkNama" type="text" data-lk="nama" value="' + esc(rec.nama) + '"></div><div class="field"><label for="lkKelas">Kelas</label><input id="lkKelas" type="text" data-lk="kelas" value="' + esc(rec.kelas) + '"></div><div class="field"><label for="lkKel">Kelompok</label><input id="lkKel" type="text" data-lk="kelompok" value="' + esc(rec.kelompok) + '"></div></div>' +
      l.items.map((it, i) => '<div class="lk-item"><label for="lk' + i + '">' + (i + 1) + '. ' + esc(it.t) + '</label><textarea id="lk' + i + '" data-lk="a" data-i="' + i + '" placeholder="Tulis jawabanmu di sini">' + esc(rec.a[i] || '') + '</textarea><div class="ans-print"></div><div class="hint">Petunjuk: ' + esc(it.hint) + '</div></div>').join('') +
      '</div><div class="row mt noprint"><button class="btn gold" type="button" data-act="lk-print">Cetak / simpan PDF</button><button class="btn" type="button" data-act="lk-txt" data-id="' + l.id + '">Unduh .txt</button><button class="btn ghost" type="button" data-act="lk-reset" data-id="' + l.id + '">Hapus jawaban</button></div>';
  }
  function lkEntry(t) {
    const id = (location.hash.split('/')[2]) || D.lkpd[0].id, rec = S.lkpd[id]; if (!rec) return;
    if (t.dataset.lk === 'a') rec.a[+t.dataset.i] = t.value; else rec[t.dataset.lk] = t.value;
    if (t.dataset.lk === 'nama') S.name = t.value;
    save();
  }
  function lkPrint() {
    $$('.lk-item').forEach(it => { $('.ans-print', it).textContent = $('textarea', it).value || '(belum dijawab)'; });
    window.print();
  }
  function lkTxt(id) {
    const l = D.lkpd.find(x => x.id === id), rec = S.lkpd[id] || { a: [] };
    let t = 'SMK Negeri 1 Lamboya\n' + l.title + '\nNama: ' + (rec.nama || '') + '\nKelas: ' + (rec.kelas || '') + '\nKelompok: ' + (rec.kelompok || '') + '\n\n';
    l.items.forEach((it, i) => { t += (i + 1) + '. ' + it.t + '\nJawab: ' + (rec.a[i] || '') + '\n\n'; });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([t], { type: 'text/plain;charset=utf-8' }));
    a.download = 'LKPD-' + id + '-' + ((rec.nama || 'murid').replace(/[^\w-]+/g, '_')) + '.txt';
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }

  /* ---------- router ---------- */
  const ROUTES = { beranda: pageBeranda, cp: pageCP, materi: pageMateri, latihan: pageLatihan, kuis: pageKuis, praktik: pagePraktik, lkpd: pageLKPD };
  function pageTitleOf(r) { const t = TABS.find(x => x[0] === r); return (t ? t[2] + ' - ' : '') + 'Media Belajar TJKT'; }
  function go(keep) {
    const parts = (location.hash.replace(/^#\/?/, '') || 'beranda').split('/');
    const r = ROUTES[parts[0]] ? parts[0] : 'beranda';
    if (r !== 'kuis') { stopTimer(); quiz = null; }
    const y = window.scrollY;
    ROUTES[r](parts.slice(1));
    $$('#tabs a').forEach(a => { const on = a.dataset.id === r; a.classList.toggle('on', on); if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
    document.title = pageTitleOf(r);
    window.scrollTo(0, keep === true ? y : 0);
  }
  window.addEventListener('hashchange', () => { sfx('nav'); go(); });

  /* ---------- delegasi event ---------- */
  view.addEventListener('click', e => {
    const t = e.target.closest('[data-act]'); if (!t) return;
    switch (t.dataset.act) {
      case 'read': S.read[t.dataset.id] = !S.read[t.dataset.id]; save(); if (S.read[t.dataset.id]) { sfx('ok'); toast('Subbab ditandai sudah paham'); } go(true); break;
      case 'lat': actLat(t); break;
      case 'again': e.preventDefault(); go(); break;
      case 'kuis-start': {
        const nm = $('#qName'); if (nm) { S.name = nm.value.trim(); save(); }
        quiz = buildQuiz(t.dataset.mode); pageKuis(); window.scrollTo(0, 0); break;
      }
      case 'kuis-pick': kuisAnswer(+t.dataset.j); break;
      case 'kuis-next': kuisNext(); window.scrollTo(0, 0); break;
      case 'kuis-menu': quiz = null; pageKuis(); window.scrollTo(0, 0); break;
      case 'print': window.print(); break;
      case 'lk-print': lkPrint(); break;
      case 'lk-txt': lkTxt(t.dataset.id); break;
      case 'lk-reset': if (confirm('Hapus semua jawaban pada LKPD ini?')) { delete S.lkpd[t.dataset.id]; save(); go(true); } break;
    }
  });
  view.addEventListener('change', e => { const t = e.target; if (t.dataset && t.dataset.actChange === 'step') actStep(t); });
  view.addEventListener('input', e => { const t = e.target; if (t.dataset && t.dataset.lk) lkEntry(t); });
  document.addEventListener('click', e => {
    if (e.target.closest('.opt')) return;
    if (e.target.closest('button, .chip, .mcard, .menu a, .tabs a, .btn')) sfx('click');
  });

  /* ---------- kontrol audio ---------- */
  const btnMusic = $('#btnMusic'), btnSfx = $('#btnSfx'), vol = $('#vol');
  btnMusic.addEventListener('click', () => { const on = btnMusic.getAttribute('aria-pressed') !== 'true'; btnMusic.setAttribute('aria-pressed', on); Snd.setMusic(on); });
  btnSfx.addEventListener('click', () => { const on = btnSfx.getAttribute('aria-pressed') !== 'true'; btnSfx.setAttribute('aria-pressed', on); Snd.setSfx(on); if (on) Snd.play('ok'); });
  vol.addEventListener('input', () => Snd.setVol(vol.value / 100));

  /* ---------- splash ---------- */
  const splash = $('#splash'), term = $('#splashTerm');
  const LINES = ['$ ping lamboya.sch.id', '64 bytes: icmp_seq=1 ttl=64 time=1 ms', '$ systemctl start belajar', 'belajar.service: active (running)'];
  (function typeSplash() {
    if (reduceMotion) { term.textContent = LINES.join('\n'); return; }
    let li = 0, ci = 0, txt = '';
    const iv = setInterval(() => {
      if (li >= LINES.length) { clearInterval(iv); return; }
      const line = LINES[li];
      if (ci < line.length) { txt += line[ci++]; } else { txt += '\n'; li++; ci = 0; }
      term.textContent = txt;
    }, 28);
  })();
  $('#btnStart').addEventListener('click', () => {
    Snd.start(); Snd.setVol(vol.value / 100); sfx('win');
    splash.classList.add('hide');
    setTimeout(() => { splash.style.display = 'none'; view.focus({ preventScroll: true }); }, 700);
  });

  go();
})();
