/* Alat bantu interaktif. */
const TOOLS = (function () {
  'use strict';
  const $ = (s, r) => (r || document).querySelector(s);

  /* ---------- util IP ---------- */
  function ip2n(s) {
    const p = String(s).trim().split('.');
    if (p.length !== 4) return null;
    let n = 0;
    for (const x of p) {
      if (!/^\d{1,3}$/.test(x) || +x > 255) return null;
      n = n * 256 + (+x);
    }
    return n;
  }
  function n2ip(n) { return [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255].join('.'); }
  function maskN(p) { return p === 0 ? 0 : (0xFFFFFFFF << (32 - p)) >>> 0; }
  function bin(n) { return [24, 16, 8, 0].map(s => ((n >>> s) & 255).toString(2).padStart(8, '0')).join('.'); }
  function binMark(n, p) {
    const raw = bin(n).replace(/\./g, '');
    let s = '', u = false;
    for (let i = 0; i < 32; i++) {
      if (i > 0 && i % 8 === 0) s += '.';
      if (i === p) { s += '<u>'; u = true; }
      s += raw[i];
    }
    return u ? s + '</u>' : s;
  }
  function info(ipn, p) {
    const m = maskN(p), net = (ipn & m) >>> 0, bc = (net | (~m >>> 0)) >>> 0;
    const size = Math.pow(2, 32 - p);
    let hosts = size - 2, first = net + 1, last = bc - 1;
    if (p === 31) { hosts = 2; first = net; last = bc; }
    if (p === 32) { hosts = 1; first = net; last = net; }
    return { m, net, bc, size, hosts, first, last };
  }
  function kelas(n) {
    const o = n >>> 24;
    if (o === 127) return 'Loopback';
    if (o < 128) return 'A'; if (o < 192) return 'B'; if (o < 224) return 'C'; if (o < 240) return 'D (multicast)'; return 'E (eksperimen)';
  }
  function privat(n) {
    return (n >>> 24) === 10 || (n >>> 20) === 0xAC1 || (n >>> 16) === 0xC0A8;
  }
  const fmt = n => n.toLocaleString('id-ID');

  /* ---------- topologi ---------- */
  const TOPO = {
    star: { n: 'Star (bintang)', pro: 'Mudah dipasang dan dikelola; kerusakan satu kabel tidak mematikan jaringan lain.', kon: 'Bergantung pada switch pusat; jika switch mati, seluruh jaringan terputus; butuh banyak kabel.', pakai: 'LAN sekolah, kantor, dan lab komputer (paling umum).' },
    bus: { n: 'Bus', pro: 'Hemat kabel dan murah.', kon: 'Kabel utama putus = jaringan terputus; sulit dilacak; performa turun saat node banyak.', pakai: 'Jaringan lama berbasis kabel koaksial.' },
    ring: { n: 'Ring (cincin)', pro: 'Aliran data teratur; tidak banyak tabrakan.', kon: 'Satu node atau kabel putus dapat mengganggu seluruh cincin.', pakai: 'Jaringan serat optik tertentu (FDDI, SONET).' },
    mesh: { n: 'Mesh (jala)', pro: 'Sangat andal karena banyak jalur alternatif.', kon: 'Mahal dan rumit karena jumlah kabel sangat banyak.', pakai: 'Backbone antar router, jaringan kritis, jaringan internet.' },
    tree: { n: 'Tree (pohon)', pro: 'Mudah dikembangkan secara bertingkat; cocok untuk gedung berlantai banyak.', kon: 'Jika switch induk mati, cabang di bawahnya terputus.', pakai: 'Jaringan kampus dengan switch inti, distribusi, dan akses.' }
  };
  function topoSVG(t) {
    const cx = 180, cy = 110, R = 82;
    let lines = '', nodes = '';
    const pt = (i, n) => [cx + R * Math.cos(2 * Math.PI * i / n - Math.PI / 2), cy + R * Math.sin(2 * Math.PI * i / n - Math.PI / 2)];
    const L = (a, b, col) => '<line x1="' + a[0] + '" y1="' + a[1] + '" x2="' + b[0] + '" y2="' + b[1] + '" stroke="' + (col || '#56d6ff') + '" stroke-width="2"/>';
    const N = (p, lab, hub) => '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="' + (hub ? 15 : 11) + '" fill="' + (hub ? '#f5b81c' : '#0d2150') + '" stroke="' + (hub ? '#fff' : '#56d6ff') + '" stroke-width="2"/><text x="' + p[0] + '" y="' + (p[1] + 4) + '" fill="' + (hub ? '#071026' : '#fff') + '" font-size="10" text-anchor="middle" font-family="sans-serif" font-weight="700">' + lab + '</text>';
    if (t === 'star') {
      for (let i = 0; i < 6; i++) { const p = pt(i, 6); lines += L([cx, cy], p); nodes += N(p, 'PC'); }
      nodes += N([cx, cy], 'SW', true);
    } else if (t === 'ring') {
      const ps = []; for (let i = 0; i < 6; i++) ps.push(pt(i, 6));
      for (let i = 0; i < 6; i++) lines += L(ps[i], ps[(i + 1) % 6]);
      ps.forEach(p => nodes += N(p, 'PC'));
    } else if (t === 'mesh') {
      const ps = []; for (let i = 0; i < 5; i++) ps.push(pt(i, 5));
      for (let i = 0; i < 5; i++) for (let j = i + 1; j < 5; j++) lines += L(ps[i], ps[j]);
      ps.forEach(p => nodes += N(p, 'R'));
    } else if (t === 'bus') {
      lines += '<line x1="20" y1="110" x2="340" y2="110" stroke="#f5b81c" stroke-width="4"/>';
      for (let i = 0; i < 5; i++) {
        const x = 55 + i * 62, up = i % 2 === 0, y = up ? 50 : 170;
        lines += L([x, 110], [x, y]); nodes += N([x, y], 'PC');
      }
    } else if (t === 'tree') {
      const root = [180, 30], mid = [[95, 105], [265, 105]];
      nodes += '';
      mid.forEach((m, i) => {
        lines += L(root, m);
        for (let k = 0; k < 2; k++) { const lf = [m[0] + (k ? 42 : -42), 185]; lines += L(m, lf); nodes += N(lf, 'PC'); }
        nodes += N(m, 'SW', true);
      });
      nodes += N(root, 'CORE', true);
    }
    return '<svg viewBox="0 0 360 220" width="420" role="img" aria-label="Topologi ' + TOPO[t].n + '"><rect width="360" height="220" fill="#030a1c"/>' + lines + nodes + '</svg>';
  }
  function topology(box) {
    box.innerHTML = '<h3>Alat peraga topologi</h3><div class="chips" id="tpChips"></div><div class="svgbox" id="tpSvg"></div><div id="tpInfo"></div>';
    const chips = $('#tpChips', box);
    function show(k) {
      chips.querySelectorAll('.chip').forEach(c => c.classList.toggle('on', c.dataset.k === k));
      $('#tpSvg', box).innerHTML = topoSVG(k);
      const o = TOPO[k];
      $('#tpInfo', box).innerHTML = '<p><b>' + o.n + '</b></p><ul><li><b>Kelebihan:</b> ' + o.pro + '</li><li><b>Kekurangan:</b> ' + o.kon + '</li><li><b>Contoh pemakaian:</b> ' + o.pakai + '</li></ul>';
    }
    Object.keys(TOPO).forEach(k => {
      const b = document.createElement('button'); b.type = 'button'; b.className = 'chip'; b.dataset.k = k; b.textContent = TOPO[k].n;
      b.addEventListener('click', () => show(k)); chips.appendChild(b);
    });
    show('star');
  }

  /* ---------- kalkulator subnet ---------- */
  function subnet(box) {
    let opts = ''; for (let p = 8; p <= 32; p++) opts += '<option value="' + p + '"' + (p === 26 ? ' selected' : '') + '>/' + p + '</option>';
    box.innerHTML = '<h3>Kalkulator subnet</h3><div class="row"><div class="field"><label for="sIp">Alamat IP</label><input id="sIp" type="text" value="192.168.1.77" inputmode="decimal" autocomplete="off"></div><div class="field" style="max-width:130px"><label for="sP">Prefix</label><select id="sP">' + opts + '</select></div><button class="btn gold" id="sGo" type="button">Hitung</button></div><div class="out" id="sOut"></div>';
    function calc() {
      const n = ip2n($('#sIp', box).value), p = +$('#sP', box).value, out = $('#sOut', box);
      if (n === null) { out.innerHTML = '<p class="res-bad">Alamat IP tidak valid. Contoh yang benar: 192.168.1.77</p>'; return; }
      const r = info(n, p);
      out.innerHTML = '<div class="tblw"><table class="tbl"><tr><th>Hasil</th><th>Nilai</th></tr>' +
        '<tr><td>Subnet mask</td><td>' + n2ip(r.m) + ' (/' + p + ')</td></tr>' +
        '<tr><td>Network address</td><td>' + n2ip(r.net) + '</td></tr>' +
        '<tr><td>Host pertama</td><td>' + n2ip(r.first) + '</td></tr>' +
        '<tr><td>Host terakhir</td><td>' + n2ip(r.last) + '</td></tr>' +
        '<tr><td>Broadcast</td><td>' + n2ip(r.bc) + '</td></tr>' +
        '<tr><td>Jumlah host valid</td><td>' + fmt(r.hosts) + '</td></tr>' +
        '<tr><td>Ukuran blok</td><td>' + fmt(r.size) + ' alamat</td></tr>' +
        '<tr><td>Kelas / jenis</td><td>' + kelas(n) + ', ' + (privat(n) ? 'privat' : 'publik/khusus') + '</td></tr></table></div>' +
        '<p>IP biner:<br><span class="bits">' + binMark(n, p) + '</span></p><p>Mask biner:<br><span class="bits">' + bin(r.m) + '</span></p><p class="hint">Bagian bergaris adalah bit host. Bagian sebelumnya adalah bit network.</p>';
    }
    $('#sGo', box).addEventListener('click', calc);
    box.querySelectorAll('input,select').forEach(e => e.addEventListener('change', calc));
    calc();
  }

  /* ---------- VLSM ---------- */
  function vlsm(box) {
    box.innerHTML = '<h3>Alat bantu VLSM</h3><div class="row"><div class="field"><label for="vNet">Jaringan awal (CIDR)</label><input id="vNet" type="text" value="192.168.10.0/24" autocomplete="off"></div><div class="field"><label for="vNeed">Kebutuhan host, pisahkan dengan koma</label><input id="vNeed" type="text" value="100, 50, 25, 2" autocomplete="off"></div><button class="btn gold" id="vGo" type="button">Hitung</button></div><div class="out" id="vOut"></div>';
    function calc() {
      const out = $('#vOut', box);
      const m = $('#vNet', box).value.trim().match(/^(\d+\.\d+\.\d+\.\d+)\/(\d{1,2})$/);
      if (!m || ip2n(m[1]) === null || +m[2] > 30) { out.innerHTML = '<p class="res-bad">Format jaringan salah. Contoh: 192.168.10.0/24</p>'; return; }
      const needs = $('#vNeed', box).value.split(',').map(s => parseInt(s, 10)).filter(x => x > 0);
      if (!needs.length) { out.innerHTML = '<p class="res-bad">Isi kebutuhan host dengan angka, misalnya 100, 50, 25.</p>'; return; }
      const p0 = +m[2], base = (ip2n(m[1]) & maskN(p0)) >>> 0, end = base + Math.pow(2, 32 - p0) - 1;
      needs.sort((a, b) => b - a);
      let cur = base, rows = '', fail = '';
      needs.forEach(need => {
        let bits = 2; while (Math.pow(2, bits) - 2 < need) bits++;
        const size = Math.pow(2, bits), p = 32 - bits;
        cur = Math.ceil(cur / size) * size;
        if (cur + size - 1 > end) { fail += '<p class="res-bad">Kebutuhan ' + need + ' host tidak muat di jaringan awal. Gunakan jaringan yang lebih besar.</p>'; return; }
        rows += '<tr><td>' + need + '</td><td>/' + p + '</td><td>' + n2ip(maskN(p)) + '</td><td>' + n2ip(cur) + '</td><td>' + n2ip(cur + 1) + ' - ' + n2ip(cur + size - 2) + '</td><td>' + n2ip(cur + size - 1) + '</td><td>' + (size - 2) + '</td></tr>';
        cur += size;
      });
      const left = end - cur + 1;
      out.innerHTML = '<div class="tblw"><table class="tbl"><tr><th>Butuh</th><th>Prefix</th><th>Mask</th><th>Network</th><th>Host valid</th><th>Broadcast</th><th>Kapasitas</th></tr>' + rows + '</table></div>' + fail + (left > 0 ? '<p class="hint">Sisa alamat yang belum terpakai: ' + left + ' (mulai ' + n2ip(cur) + ').</p>' : '');
    }
    $('#vGo', box).addEventListener('click', calc);
    calc();
  }

  /* ---------- kalkulator listrik ---------- */
  function listrik(box) {
    box.innerHTML = '<h3>Kalkulator arus, daya, dan MCB</h3><div class="row"><div class="field"><label for="lP">Daya total (watt)</label><input id="lP" type="number" min="1" value="1025"></div><div class="field"><label for="lV">Tegangan (volt)</label><input id="lV" type="number" min="1" value="220"></div><div class="field"><label for="lC">Faktor daya (cos φ)</label><input id="lC" type="number" min="0.1" max="1" step="0.05" value="1"></div><div class="field"><label for="lH">Pemakaian (jam/hari)</label><input id="lH" type="number" min="0" max="24" step="0.5" value="6"></div><button class="btn gold" id="lGo" type="button">Hitung</button></div><div class="out" id="lOut"></div>';
    const STD = [2, 4, 6, 10, 16, 20, 25, 32, 40, 50, 63];
    function calc() {
      const P = +$('#lP', box).value, V = +$('#lV', box).value, C = +$('#lC', box).value, H = +$('#lH', box).value, out = $('#lOut', box);
      if (!(P > 0 && V > 0 && C > 0 && C <= 1)) { out.innerHTML = '<p class="res-bad">Isi daya, tegangan, dan cos φ (0,1 sampai 1) dengan benar.</p>'; return; }
      const I = P / (V * C), mcb = STD.find(x => x >= I), kwh = P / 1000 * H * 30;
      out.innerHTML = '<div class="tblw"><table class="tbl"><tr><th>Hasil</th><th>Nilai</th></tr><tr><td>Arus beban I = P / (V x cos φ)</td><td>' + I.toFixed(2).replace('.', ',') + ' A</td></tr><tr><td>MCB standar yang disarankan</td><td>' + (mcb ? mcb + ' A' : 'lebih dari 63 A, pecah menjadi beberapa grup') + '</td></tr><tr><td>Energi per bulan (30 hari)</td><td>' + kwh.toFixed(1).replace('.', ',') + ' kWh</td></tr></table></div><p class="hint">Pastikan kemampuan hantar arus kabel tidak lebih kecil dari nilai MCB.</p>';
    }
    $('#lGo', box).addEventListener('click', calc);
    calc();
  }

  /* ---------- simulator terminal Linux ---------- */
  function terminal(box, onMission) {
    const st = { inst: {}, run: {}, en: {} };
    const known = ['apache2', 'bind9', 'isc-dhcp-server', 'vsftpd', 'samba', 'mariadb-server', 'postfix', 'dovecot-imapd', 'openssh-server'];
    const svcName = { 'mariadb-server': 'mariadb', samba: 'smbd', 'dovecot-imapd': 'dovecot' };
    const sv = n => svcName[n] || n;
    const missions = [
      { id: 'a', t: 'Perbarui daftar paket (apt update)', ok: false },
      { id: 'b', t: 'Pasang apache2 (apt install apache2)', ok: false },
      { id: 'c', t: 'Jalankan layanan apache2 (systemctl start apache2)', ok: false },
      { id: 'd', t: 'Cek status apache2 (systemctl status apache2)', ok: false },
      { id: 'e', t: 'Pasang dan jalankan bind9, lalu uji nslookup www.tjkt.local', ok: false }
    ];
    box.innerHTML = '<div class="term"><div class="term-bar"><i></i><i></i><i></i><span>&nbsp;siswa@srv-tjkt: ~</span></div><div class="term-out" id="tOut" aria-live="polite"></div><div class="term-in"><span>siswa@srv-tjkt:~$</span><input id="tIn" type="text" autocomplete="off" autocapitalize="off" spellcheck="false" aria-label="Ketik perintah"></div></div><div id="tMis" style="margin-top:10px"></div>';
    const out = $('#tOut', box), inp = $('#tIn', box), mis = $('#tMis', box);
    const hist = []; let hp = 0;
    function print(t, cls) { const d = document.createElement('div'); if (cls) d.className = cls; d.textContent = t; out.appendChild(d); out.scrollTop = out.scrollHeight; }
    function drawMis() {
      mis.innerHTML = '<p><b>Misi latihan</b></p>' + missions.map(m => '<div class="mission ' + (m.ok ? 'ok' : '') + '">' + (m.ok ? '✔' : '○') + ' ' + m.t + '</div>').join('');
    }
    function done(id) { const m = missions.find(x => x.id === id); if (m && !m.ok) { m.ok = true; drawMis(); if (onMission) onMission(missions.every(x => x.ok)); } }
    function run(line) {
      let c = line.trim().replace(/\s+/g, ' ');
      if (c.startsWith('sudo ')) c = c.slice(5);
      const [cmd, ...a] = c.split(' ');
      switch (cmd) {
        case '': return;
        case 'help': print('Perintah: help, pwd, ls, whoami, hostname, ip a, ping, uname -a, df -h, free -m, clear,\napt update, apt install <paket>, systemctl <start|stop|restart|enable|status> <layanan>, nslookup <nama>\nPaket yang tersedia: ' + known.join(', ')); return;
        case 'pwd': print('/home/siswa'); return;
        case 'whoami': print('siswa'); return;
        case 'hostname': print('srv-tjkt'); return;
        case 'ls': print('Desktop  Documents  Downloads  tjkt'); return;
        case 'clear': out.innerHTML = ''; return;
        case 'uname': print('Linux srv-tjkt 6.1.0-18-amd64 #1 SMP Debian x86_64 GNU/Linux'); return;
        case 'df': print('Filesystem      Size  Used Avail Use% Mounted on\n/dev/sda1        19G  3.1G   15G  18% /'); return;
        case 'free': print('              total        used        free\nMem:           1005         212         593'); return;
        case 'ip': print('2: enp0s3: <BROADCAST,MULTICAST,UP,LOWER_UP>\n    inet 192.168.10.2/24 brd 192.168.10.255 scope global enp0s3'); return;
        case 'ping': {
          if (!a[0]) { print('ping: tujuan belum diisi', 'err'); return; }
          print('PING ' + a[0] + ': 56 bytes data');
          for (let i = 1; i <= 4; i++) print('64 bytes from ' + a[0] + ': icmp_seq=' + i + ' ttl=64 time=' + (0.4 + Math.random()).toFixed(2) + ' ms');
          print('4 packets transmitted, 4 received, 0% packet loss'); return;
        }
        case 'apt': case 'apt-get': {
          if (a[0] === 'update') { print('Hit:1 http://deb.debian.org/debian bookworm InRelease\nReading package lists... Done'); done('a'); return; }
          if (a[0] === 'install') {
            const pk = a.filter(x => x[0] !== '-' && x !== 'install');
            if (!pk.length) { print('E: Tentukan nama paket', 'err'); return; }
            pk.forEach(p => {
              if (known.indexOf(p) < 0) { print('E: Unable to locate package ' + p, 'err'); return; }
              st.inst[p] = true;
              print('Reading package lists... Done\nSetting up ' + p + ' ... Done');
              if (p === 'apache2') done('b');
            });
            return;
          }
          print('Perintah apt yang didukung: update, install', 'err'); return;
        }
        case 'systemctl': {
          const act = a[0], name = a[1];
          if (!act || !name) { print('Format: systemctl <start|stop|restart|enable|status> <layanan>', 'err'); return; }
          const pk = known.find(k => sv(k) === name);
          if (!pk || !st.inst[pk]) { print('Unit ' + name + '.service could not be found.', 'err'); return; }
          if (act === 'start' || act === 'restart') { st.run[name] = true; if (name === 'apache2' && act === 'start') done('c'); return; }
          if (act === 'stop') { st.run[name] = false; return; }
          if (act === 'enable') { st.en[name] = true; print('Created symlink /etc/systemd/system/multi-user.target.wants/' + name + '.service'); return; }
          if (act === 'status') {
            print('● ' + name + '.service\n     Loaded: loaded (' + (st.en[name] ? 'enabled' : 'disabled') + ')\n     Active: ' + (st.run[name] ? 'active (running)' : 'inactive (dead)'));
            if (name === 'apache2') done('d');
            return;
          }
          print('Aksi tidak dikenal: ' + act, 'err'); return;
        }
        case 'nslookup': case 'dig': {
          const q = a[0];
          if (!q) { print('Format: nslookup <nama>', 'err'); return; }
          if (!st.run.bind9) { print(';; connection timed out; no servers could be reached', 'err'); return; }
          if (q === 'www.tjkt.local' || q === 'tjkt.local') { print('Server:  192.168.10.2\nName:    ' + q + '\nAddress: 192.168.10.2'); done('e'); return; }
          print('** server can\'t find ' + q + ': NXDOMAIN', 'err'); return;
        }
        default: print(cmd + ': perintah tidak ditemukan. Ketik help untuk daftar perintah.', 'err');
      }
    }
    inp.addEventListener('keydown', e => {
      if (e.key === 'Enter') {
        const v = inp.value; print('siswa@srv-tjkt:~$ ' + v, 'cmd'); hist.push(v); hp = hist.length; inp.value = ''; run(v);
        if (window.Snd) Snd.play('click');
      } else if (e.key === 'ArrowUp') { if (hp > 0) { hp--; inp.value = hist[hp]; } e.preventDefault(); }
      else if (e.key === 'ArrowDown') { if (hp < hist.length - 1) { hp++; inp.value = hist[hp]; } else { hp = hist.length; inp.value = ''; } e.preventDefault(); }
    });
    print('Simulator terminal Linux. Ketik help untuk melihat perintah. Ini hanya simulasi untuk latihan.');
    drawMis();
  }

  return { topology, subnet, vlsm, listrik, terminal };
})();
