/* Data isi media: CP, TP, dan materi ajar. */
const DATA = {
  cp: {
    umum: 'Pada akhir Fase F, peserta didik mampu merencanakan, membangun, mengelola, dan mengamankan jaringan komputer beserta layanannya, serta memahami dasar instalasi tenaga listrik yang mendukung infrastruktur jaringan, dengan memperhatikan keselamatan dan kesehatan kerja (K3).',
    elemen: [
      { n: 'Administrasi Sistem Jaringan', t: 'Peserta didik mampu memahami sistem operasi jaringan (Linux), virtualisasi, serta menginstal dan mengonfigurasi layanan server (DHCP, DNS, FTP, file, web, mail, database), memahami control panel hosting, sistem kontrol dan monitoring, jenis hosting (shared, dedicated, VPS), serta VPN server.' },
      { n: 'Perencanaan dan Pengalamatan Jaringan', t: 'Peserta didik mampu menganalisis kebutuhan teknis pengguna, merancang topologi dan arsitektur jaringan, memilih perangkat jaringan, serta menetapkan pengalamatan jaringan menggunakan subnetting, CIDR, dan VLSM.' },
      { n: 'Teknik Instalasi Tenaga Listrik', t: 'Peserta didik mampu memahami PUIL, merancang dan memasang instalasi listrik 1 fasa, serta mengenal peralatan mesin listrik dengan menerapkan prosedur K3.' }
    ],
    catatan: 'Rumusan CP ini diringkas agar mudah dibaca murid. Guru dapat menyesuaikannya dengan CP resmi dari Badan Standar, Kurikulum, dan Asesmen Pendidikan (BSKAP) yang berlaku.'
  },

  modules: [
    {
      id: 'm1', icon: '🖧', color: '#3b82f6', short: 'Administrasi Sistem Jaringan',
      title: 'Administrasi Sistem Jaringan',
      desc: 'Linux, virtualisasi, server (DHCP, DNS, FTP, file, web, mail, database), hosting, monitoring, dan VPN.',
      tp: [
        'Menjelaskan fungsi sistem operasi jaringan dan menggunakan perintah dasar Linux.',
        'Membuat mesin virtual dan memilih mode jaringan virtualisasi yang sesuai.',
        'Menginstal dan mengonfigurasi server DHCP, DNS, FTP, file, web, mail, dan database.',
        'Membedakan control panel hosting, shared hosting, dedicated server, dan VPS.',
        'Menerapkan monitoring sederhana dan menjelaskan cara kerja VPN server.'
      ],
      sections: [
        {
          id: 'm1s1', title: 'Sistem Operasi Jaringan',
          html: `
<p><b>Sistem operasi jaringan</b> (<i>Network Operating System</i>, NOS) adalah sistem operasi yang dirancang untuk mengelola sumber daya jaringan dan melayani banyak pengguna sekaligus.</p>
<h4>Fungsi utama</h4>
<ul><li>Mengelola akun pengguna dan hak akses.</li><li>Berbagi file, printer, dan aplikasi.</li><li>Menjalankan layanan jaringan seperti web, DNS, DHCP, dan email.</li><li>Menjaga keamanan dan mencatat aktivitas (log).</li></ul>
<h4>Contoh sistem operasi jaringan</h4>
<div class="tblw"><table class="tbl"><tr><th>Sistem</th><th>Ciri</th></tr>
<tr><td>Windows Server</td><td>Tampilan grafis, Active Directory, berlisensi.</td></tr>
<tr><td>Linux (Debian, Ubuntu Server, Rocky Linux)</td><td>Gratis, open source, stabil, ringan, dikendalikan lewat perintah (CLI).</td></tr>
<tr><td>FreeBSD</td><td>Dikenal aman dan andal untuk router dan firewall.</td></tr></table></div>
<div class="note">Di kelas TJKT kita memakai Debian atau Ubuntu Server karena gratis, ringan, dan banyak dipakai di dunia industri.</div>`
        },
        {
          id: 'm1s2', title: 'Dasar Linux',
          html: `
<p>Linux memakai struktur direktori berbentuk pohon yang berawal dari <code>/</code> (root).</p>
<div class="tblw"><table class="tbl"><tr><th>Direktori</th><th>Isi</th></tr>
<tr><td><code>/etc</code></td><td>File konfigurasi sistem dan layanan</td></tr>
<tr><td><code>/home</code></td><td>Folder pribadi pengguna</td></tr>
<tr><td><code>/var</code></td><td>Data yang berubah: log, web, mail</td></tr>
<tr><td><code>/bin</code>, <code>/usr</code></td><td>Program dan perintah</td></tr>
<tr><td><code>/root</code></td><td>Folder pribadi administrator (root)</td></tr></table></div>
<h4>Perintah dasar</h4>
<div class="tblw"><table class="tbl"><tr><th>Perintah</th><th>Fungsi</th></tr>
<tr><td><code>pwd</code></td><td>Menampilkan lokasi folder saat ini</td></tr>
<tr><td><code>ls -l</code></td><td>Melihat isi folder lengkap</td></tr>
<tr><td><code>cd /etc</code></td><td>Pindah folder</td></tr>
<tr><td><code>mkdir, cp, mv, rm</code></td><td>Buat folder, salin, pindah/ganti nama, hapus</td></tr>
<tr><td><code>cat, nano</code></td><td>Membaca dan mengedit file</td></tr>
<tr><td><code>sudo</code></td><td>Menjalankan perintah sebagai administrator</td></tr>
<tr><td><code>apt update / apt install</code></td><td>Memperbarui daftar paket / memasang aplikasi (Debian, Ubuntu)</td></tr>
<tr><td><code>ip a</code></td><td>Melihat alamat IP</td></tr>
<tr><td><code>systemctl</code></td><td>Mengatur layanan (start, stop, restart, enable, status)</td></tr></table></div>
<h4>Hak akses file</h4>
<p>Setiap file punya tiga kelompok hak: pemilik, grup, dan lainnya. Nilainya r=4 (baca), w=2 (tulis), x=1 (jalankan). Contoh <code>chmod 755 file</code> berarti pemilik <b>rwx</b> (7), grup <b>r-x</b> (5), lainnya <b>r-x</b> (5).</p>`
        },
        {
          id: 'm1s3', title: 'Virtualisasi',
          html: `
<p><b>Virtualisasi</b> adalah teknik menjalankan beberapa sistem operasi (mesin virtual, VM) di atas satu perangkat keras fisik. Pengelolanya disebut <i>hypervisor</i>.</p>
<div class="tblw"><table class="tbl"><tr><th>Tipe</th><th>Cara kerja</th><th>Contoh</th></tr>
<tr><td>Tipe 1 (bare-metal)</td><td>Langsung di atas perangkat keras, cocok untuk server</td><td>Proxmox VE, VMware ESXi, KVM, Hyper-V</td></tr>
<tr><td>Tipe 2 (hosted)</td><td>Berjalan sebagai aplikasi di atas sistem operasi, cocok untuk belajar</td><td>VirtualBox, VMware Workstation</td></tr></table></div>
<h4>Mode jaringan VirtualBox</h4>
<div class="tblw"><table class="tbl"><tr><th>Mode</th><th>Akibat</th></tr>
<tr><td>NAT</td><td>VM bisa ke internet, tetapi tidak bisa diakses dari luar</td></tr>
<tr><td>Bridged Adapter</td><td>VM mendapat IP sejaringan dengan komputer fisik (seperti perangkat sendiri di LAN)</td></tr>
<tr><td>Host-only</td><td>VM hanya terhubung dengan komputer induk</td></tr>
<tr><td>Internal Network</td><td>VM hanya saling terhubung dengan VM lain pada jaringan internal yang sama</td></tr></table></div>
<h4>Manfaat</h4>
<ul><li>Hemat biaya perangkat dan listrik.</li><li>Aman untuk percobaan: VM rusak tinggal dihapus atau dikembalikan lewat snapshot.</li><li>Mudah membuat lab server di satu laptop.</li></ul>
<div class="tip">Untuk VM server Linux, 1 GB RAM dan disk 10 sampai 20 GB sudah cukup.</div>`
        },
        {
          id: 'm1s4', title: 'Konsep dan Instalasi Services',
          html: `
<p>Layanan jaringan bekerja dengan model <b>client-server</b>: klien meminta, server melayani. Program server yang berjalan di latar belakang disebut <i>service</i> atau <i>daemon</i>, dan setiap layanan memakai nomor <b>port</b>.</p>
<div class="tblw"><table class="tbl"><tr><th>Layanan</th><th>Port</th><th>Paket Debian/Ubuntu</th></tr>
<tr><td>SSH</td><td>22/TCP</td><td>openssh-server</td></tr>
<tr><td>DHCP</td><td>67-68/UDP</td><td>isc-dhcp-server</td></tr>
<tr><td>DNS</td><td>53/UDP dan TCP</td><td>bind9</td></tr>
<tr><td>FTP</td><td>21/TCP</td><td>vsftpd</td></tr>
<tr><td>File (SMB)</td><td>445/TCP</td><td>samba</td></tr>
<tr><td>HTTP / HTTPS</td><td>80 / 443</td><td>apache2 atau nginx</td></tr>
<tr><td>SMTP / IMAP / POP3</td><td>25 / 143 / 110</td><td>postfix, dovecot</td></tr>
<tr><td>MySQL/MariaDB</td><td>3306/TCP</td><td>mariadb-server</td></tr></table></div>
<h4>Pola instalasi semua layanan</h4>
<pre class="code">sudo apt update
sudo apt install nama-paket -y
sudo systemctl enable nama-layanan   <b># aktif otomatis saat boot</b>
sudo systemctl restart nama-layanan  <b># muat ulang setelah ubah konfigurasi</b>
sudo systemctl status nama-layanan   <b># cek berjalan atau error</b>
sudo journalctl -u nama-layanan -n 30 <b># baca log jika error</b></pre>
<div class="warn">Selalu cek status layanan setelah mengubah konfigurasi. Salah satu tanda baca saja dapat membuat layanan gagal berjalan.</div>`
        },
        {
          id: 'm1s5', title: 'DHCP Server',
          html: `
<p><b>DHCP</b> (<i>Dynamic Host Configuration Protocol</i>) membagikan alamat IP, gateway, dan DNS kepada klien secara otomatis. Prosesnya disebut <b>DORA</b>:</p>
<ol><li><b>Discover</b>: klien berteriak mencari server DHCP.</li><li><b>Offer</b>: server menawarkan alamat IP.</li><li><b>Request</b>: klien meminta alamat yang ditawarkan.</li><li><b>Acknowledge</b>: server menyetujui dan klien memakai alamat itu.</li></ol>
<h4>Konfigurasi (isc-dhcp-server)</h4>
<pre class="code">sudo apt install isc-dhcp-server -y
sudo nano /etc/default/isc-dhcp-server
<b># isi:</b> INTERFACESv4="enp0s3"     <b># nama kartu jaringan, cek dengan ip a</b>

sudo nano /etc/dhcp/dhcpd.conf
subnet 192.168.10.0 netmask 255.255.255.0 {
  range 192.168.10.100 192.168.10.200;
  option routers 192.168.10.1;
  option domain-name-servers 192.168.10.2, 8.8.8.8;
  option domain-name "tjkt.local";
  default-lease-time 600;
  max-lease-time 7200;
}

sudo systemctl restart isc-dhcp-server
sudo systemctl status isc-dhcp-server</pre>
<div class="note">Server DHCP harus memakai IP statis. Pengujian: atur klien ke "Obtain IP automatically", lalu cek dengan <code>ip a</code> atau <code>ipconfig</code>.</div>`
        },
        {
          id: 'm1s6', title: 'DNS Server',
          html: `
<p><b>DNS</b> (<i>Domain Name System</i>) menerjemahkan nama domain menjadi alamat IP. Di Linux kita memakai <b>BIND9</b>.</p>
<div class="tblw"><table class="tbl"><tr><th>Record</th><th>Fungsi</th></tr>
<tr><td>A</td><td>Nama ke alamat IPv4</td></tr><tr><td>AAAA</td><td>Nama ke alamat IPv6</td></tr>
<tr><td>CNAME</td><td>Nama alias ke nama lain</td></tr><tr><td>MX</td><td>Server email untuk domain</td></tr>
<tr><td>NS</td><td>Server DNS yang berwenang</td></tr><tr><td>PTR</td><td>Alamat IP ke nama (reverse)</td></tr></table></div>
<h4>Konfigurasi zona domain tjkt.local</h4>
<pre class="code">sudo apt install bind9 dnsutils -y
sudo nano /etc/bind/named.conf.local
zone "tjkt.local" {
  type master;
  file "/etc/bind/db.tjkt";
};

sudo cp /etc/bind/db.local /etc/bind/db.tjkt
sudo nano /etc/bind/db.tjkt
$TTL 604800
@     IN SOA ns1.tjkt.local. admin.tjkt.local. (
            2        ; Serial
            604800   ; Refresh
            86400    ; Retry
            2419200  ; Expire
            604800 ) ; Negative cache
@     IN NS   ns1.tjkt.local.
ns1   IN A    192.168.10.2
www   IN A    192.168.10.2
mail  IN A    192.168.10.2
@     IN MX 10 mail.tjkt.local.
ftp   IN CNAME www

sudo named-checkzone tjkt.local /etc/bind/db.tjkt
sudo systemctl restart bind9</pre>
<h4>Pengujian</h4>
<pre class="code">nslookup www.tjkt.local 192.168.10.2
dig @192.168.10.2 tjkt.local MX</pre>
<div class="tip">Setiap kali mengubah file zona, naikkan angka <b>Serial</b> (misal 2 menjadi 3) lalu restart bind9.</div>`
        },
        {
          id: 'm1s7', title: 'FTP Server',
          html: `
<p><b>FTP</b> (<i>File Transfer Protocol</i>) dipakai untuk mengunggah dan mengunduh file. Port 21 untuk perintah, port 20 untuk data (mode aktif). Di Linux kita memakai <b>vsftpd</b>.</p>
<pre class="code">sudo apt install vsftpd -y
sudo nano /etc/vsftpd.conf
anonymous_enable=NO
local_enable=YES
write_enable=YES
chroot_local_user=YES
allow_writeable_chroot=YES

sudo systemctl restart vsftpd</pre>
<p>Pengujian dari klien: <code>ftp 192.168.10.2</code> atau gunakan aplikasi FileZilla dengan akun pengguna Linux.</p>
<div class="warn">FTP biasa mengirim kata sandi tanpa enkripsi. Untuk jaringan nyata, gunakan <b>SFTP</b> (lewat SSH, port 22) atau FTPS.</div>`
        },
        {
          id: 'm1s8', title: 'File Server',
          html: `
<p><b>File server</b> menyimpan file bersama yang dapat diakses banyak komputer. <b>Samba</b> memakai protokol SMB sehingga Linux dapat berbagi dengan Windows. Untuk Linux ke Linux dapat memakai <b>NFS</b>.</p>
<pre class="code">sudo apt install samba -y
sudo mkdir -p /srv/samba/data
sudo chmod 770 /srv/samba/data
sudo nano /etc/samba/smb.conf
<b># tambahkan di akhir file:</b>
[data]
   path = /srv/samba/data
   browseable = yes
   writable = yes
   valid users = siswa

sudo smbpasswd -a siswa       <b># buat sandi Samba untuk pengguna siswa</b>
sudo systemctl restart smbd</pre>
<p>Akses dari Windows: tekan <code>Win + R</code>, ketik <code>\\\\192.168.10.2\\data</code>.</p>`
        },
        {
          id: 'm1s9', title: 'Web Server',
          html: `
<p><b>Web server</b> melayani halaman web melalui HTTP/HTTPS. Yang populer: <b>Apache2</b> dan <b>Nginx</b>. Satu server dapat melayani banyak situs dengan <i>virtual host</i>.</p>
<pre class="code">sudo apt install apache2 -y
sudo mkdir /var/www/tjkt
echo "&lt;h1&gt;Selamat datang di web TJKT&lt;/h1&gt;" | sudo tee /var/www/tjkt/index.html

sudo nano /etc/apache2/sites-available/tjkt.conf
&lt;VirtualHost *:80&gt;
    ServerName www.tjkt.local
    DocumentRoot /var/www/tjkt
&lt;/VirtualHost&gt;

sudo a2ensite tjkt.conf
sudo systemctl reload apache2</pre>
<p>Buka peramban dan akses <code>http://www.tjkt.local</code>. Untuk situs dinamis (PHP, WordPress), tambahkan paket <code>php</code> dan database server.</p>
<div class="note">Folder bawaan situs ada di <code>/var/www/html</code>. Log kesalahan ada di <code>/var/log/apache2/error.log</code>.</div>`
        },
        {
          id: 'm1s10', title: 'Mail Server',
          html: `
<p>Sistem email terdiri dari tiga peran:</p>
<div class="tblw"><table class="tbl"><tr><th>Peran</th><th>Tugas</th><th>Contoh</th></tr>
<tr><td>MTA</td><td>Mengirim dan meneruskan email antar server (SMTP, port 25/587)</td><td>Postfix</td></tr>
<tr><td>MDA/IMAP/POP3</td><td>Menyimpan dan mengantar email ke kotak masuk (143/110, 993/995 aman)</td><td>Dovecot</td></tr>
<tr><td>MUA</td><td>Aplikasi pembaca email milik pengguna</td><td>Thunderbird, Roundcube</td></tr></table></div>
<pre class="code">sudo apt install postfix dovecot-imapd dovecot-pop3d -y
<b># pilih "Internet Site", system mail name: tjkt.local</b>
sudo postconf -e "home_mailbox = Maildir/"
sudo systemctl restart postfix dovecot</pre>
<div class="note">Agar domain bisa menerima email, DNS harus punya record <b>MX</b> yang menunjuk ke server email (lihat materi DNS).</div>`
        },
        {
          id: 'm1s11', title: 'Database Server',
          html: `
<p><b>Database server</b> menyimpan data terstruktur untuk aplikasi (misalnya website sekolah). Yang umum dipakai: <b>MariaDB/MySQL</b> (port 3306).</p>
<pre class="code">sudo apt install mariadb-server -y
sudo mysql_secure_installation
sudo mysql

CREATE DATABASE sekolah;
CREATE USER 'siswa'@'localhost' IDENTIFIED BY 'KataSandiKuat123!';
GRANT ALL PRIVILEGES ON sekolah.* TO 'siswa'@'localhost';
FLUSH PRIVILEGES;
EXIT;</pre>
<div class="warn">Jangan membuka database ke internet tanpa alasan. Biarkan <code>bind-address = 127.0.0.1</code> kecuali memang perlu akses jarak jauh, dan selalu gunakan kata sandi kuat.</div>`
        },
        {
          id: 'm1s12', title: 'Control Panel Hosting',
          html: `
<p><b>Control panel</b> adalah antarmuka web untuk mengelola server tanpa banyak mengetik perintah: domain, email, database, file, sertifikat SSL, dan backup.</p>
<div class="tblw"><table class="tbl"><tr><th>Control panel</th><th>Keterangan</th></tr>
<tr><td>cPanel/WHM</td><td>Paling populer di hosting komersial, berlisensi</td></tr>
<tr><td>Plesk</td><td>Mendukung Linux dan Windows, berlisensi</td></tr>
<tr><td>Webmin</td><td>Gratis, mengelola sistem Linux, port 10000</td></tr>
<tr><td>aaPanel, CyberPanel, HestiaCP</td><td>Gratis atau open source, ringan untuk VPS</td></tr></table></div>
<ul><li>Pengguna hosting biasanya memakai panel tingkat akun (cPanel).</li><li>Administrator server memakai panel tingkat server (WHM) untuk membuat akun dan paket hosting.</li></ul>`
        },
        {
          id: 'm1s13', title: 'Sistem Kontrol dan Monitoring',
          html: `
<p><b>Monitoring</b> memantau kondisi perangkat dan layanan agar masalah ditemukan sebelum pengguna mengeluh.</p>
<h4>Perintah pemantauan di Linux</h4>
<div class="tblw"><table class="tbl"><tr><th>Perintah</th><th>Memeriksa</th></tr>
<tr><td><code>ping, traceroute</code></td><td>Koneksi dan jalur jaringan</td></tr>
<tr><td><code>top / htop</code></td><td>CPU dan proses</td></tr>
<tr><td><code>free -m</code></td><td>Penggunaan RAM</td></tr>
<tr><td><code>df -h</code></td><td>Ruang disk</td></tr>
<tr><td><code>ss -tulpn</code></td><td>Port yang sedang terbuka</td></tr>
<tr><td><code>journalctl -u layanan</code></td><td>Log layanan</td></tr></table></div>
<h4>Aplikasi monitoring</h4>
<p>Zabbix, Nagios, LibreNMS, Cacti, PRTG, serta Prometheus dengan Grafana. Banyak yang memakai protokol <b>SNMP</b> (port 161/UDP) untuk membaca data dari router, switch, dan server.</p>
<div class="tip">Hal yang biasa dipantau: ketersediaan (up/down), beban CPU, RAM, ruang disk, trafik bandwidth, dan suhu perangkat.</div>`
        },
        {
          id: 'm1s14', title: 'Jenis Hosting',
          html: `
<div class="tblw"><table class="tbl"><tr><th>Jenis</th><th>Cara kerja</th><th>Biaya</th><th>Kontrol</th><th>Cocok untuk</th></tr>
<tr><td><b>Shared hosting</b></td><td>Satu server dipakai banyak situs bersama</td><td>Murah</td><td>Terbatas</td><td>Blog, profil sekolah kecil</td></tr>
<tr><td><b>VPS</b> (Virtual Private Server)</td><td>Satu server fisik dipecah menjadi beberapa server virtual terpisah</td><td>Menengah</td><td>Akses root penuh</td><td>Aplikasi web, toko online</td></tr>
<tr><td><b>Dedicated server</b></td><td>Satu server fisik khusus untuk satu pelanggan</td><td>Mahal</td><td>Penuh, termasuk perangkat keras</td><td>Trafik tinggi, kebutuhan khusus</td></tr></table></div>
<p>Pilihan bergantung pada jumlah pengunjung, anggaran, dan kemampuan administrator. Mulailah dari yang kecil, lalu naik kelas saat kebutuhan bertambah.</p>`
        },
        {
          id: 'm1s15', title: 'VPN Server',
          html: `
<p><b>VPN</b> (<i>Virtual Private Network</i>) membuat jalur pribadi terenkripsi (<i>tunnel</i>) melalui internet sehingga pengguna dapat mengakses jaringan kantor atau sekolah dengan aman dari mana saja.</p>
<ul><li><b>Remote access</b>: satu pengguna terhubung ke jaringan pusat.</li><li><b>Site-to-site</b>: dua jaringan cabang dihubungkan.</li></ul>
<div class="tblw"><table class="tbl"><tr><th>Protokol</th><th>Catatan</th></tr>
<tr><td>PPTP</td><td>Sudah usang dan tidak aman</td></tr>
<tr><td>L2TP/IPsec</td><td>Umum dan didukung banyak perangkat</td></tr>
<tr><td>OpenVPN</td><td>Fleksibel, port 1194 (UDP/TCP)</td></tr>
<tr><td>WireGuard</td><td>Modern, ringan dan cepat, port 51820/UDP</td></tr></table></div>
<h4>Contoh konfigurasi WireGuard sisi server</h4>
<pre class="code">sudo apt install wireguard -y
wg genkey | tee privatekey | wg pubkey &gt; publickey

sudo nano /etc/wireguard/wg0.conf
[Interface]
Address = 10.8.0.1/24
ListenPort = 51820
PrivateKey = &lt;isi kunci privat server&gt;

[Peer]
PublicKey = &lt;isi kunci publik klien&gt;
AllowedIPs = 10.8.0.2/32

sudo wg-quick up wg0</pre>
<div class="warn">Kunci privat tidak boleh dibagikan. Hanya kunci publik yang dipertukarkan.</div>`
        }
      ]
    },

    {
      id: 'm2', icon: '🗺️', color: '#f5b81c', short: 'Perencanaan dan Pengalamatan Jaringan',
      title: 'Perencanaan dan Pengalamatan Jaringan',
      desc: 'Topologi, arsitektur, kebutuhan pengguna, perangkat, pengalamatan IP, subnetting, CIDR, dan VLSM.',
      tp: [
        'Membedakan topologi dan arsitektur jaringan beserta kelebihan dan kekurangannya.',
        'Menganalisis kebutuhan teknis pengguna jaringan.',
        'Memilih peralatan jaringan sesuai kebutuhan.',
        'Menetapkan pengalamatan IP dan melakukan subnetting.',
        'Menerapkan CIDR dan VLSM untuk merancang jaringan yang efisien.'
      ],
      sections: [
        {
          id: 'm2s1', title: 'Topologi Jaringan', tool: 'topology',
          html: `
<p><b>Topologi</b> adalah bentuk susunan penghubung antar perangkat dalam jaringan. Ada topologi <i>fisik</i> (susunan kabel dan perangkat) dan topologi <i>logika</i> (jalur aliran data).</p>
<p>Gunakan alat peraga di bawah untuk melihat tiap topologi.</p>`
        },
        {
          id: 'm2s2', title: 'Arsitektur Jaringan',
          html: `
<h4>Berdasarkan hubungan komputer</h4>
<div class="tblw"><table class="tbl"><tr><th>Arsitektur</th><th>Ciri</th></tr>
<tr><td>Client-server</td><td>Ada server pusat yang melayani klien. Pengelolaan dan keamanan terpusat. Cocok untuk sekolah dan perusahaan.</td></tr>
<tr><td>Peer-to-peer</td><td>Setiap komputer bisa menjadi klien sekaligus server. Murah dan sederhana, tetapi sulit dikelola jika besar.</td></tr></table></div>
<h4>Berdasarkan jangkauan</h4>
<p><b>PAN</b> (pribadi), <b>LAN</b> (satu gedung atau kampus), <b>MAN</b> (satu kota), <b>WAN</b> (antar kota atau negara, contohnya internet).</p>
<h4>Model hierarki tiga lapis</h4>
<div class="tblw"><table class="tbl"><tr><th>Lapisan</th><th>Tugas</th></tr>
<tr><td>Core</td><td>Tulang punggung berkecepatan tinggi, menghubungkan antar distribusi</td></tr>
<tr><td>Distribution</td><td>Pengaturan kebijakan, routing antar VLAN, penyaringan</td></tr>
<tr><td>Access</td><td>Titik sambungan perangkat pengguna (switch lantai, access point)</td></tr></table></div>
<div class="note">Jaringan sekolah kecil sering memakai dua lapis saja (collapsed core): router/switch layer 3 sebagai inti, lalu switch akses di tiap ruangan.</div>`
        },
        {
          id: 'm2s3', title: 'Kebutuhan Teknis Pengguna',
          html: `
<p>Sebelum membeli perangkat, lakukan <b>analisis kebutuhan</b>. Pertanyaan yang harus dijawab:</p>
<ul>
<li><b>Berapa pengguna dan perangkat?</b> Termasuk rencana pertambahan 3 sampai 5 tahun ke depan.</li>
<li><b>Aplikasi apa yang dipakai?</b> Email dan web membutuhkan bandwidth kecil, video conference dan CCTV membutuhkan jauh lebih besar.</li>
<li><b>Di mana lokasi?</b> Survei gedung: jarak antar ruangan, plafon, jalur kabel, sumber listrik.</li>
<li><b>Seberapa penting ketersediaan?</b> Perlukah jalur cadangan dan UPS?</li>
<li><b>Bagaimana keamanan?</b> Perlu pemisahan jaringan (VLAN), firewall, atau pembatasan akses?</li>
<li><b>Berapa anggaran?</b> Sesuaikan prioritas dengan dana.</li></ul>
<div class="tip">Hasil analisis dituangkan dalam dokumen: daftar kebutuhan, gambar denah, topologi, daftar perangkat, dan rencana alamat IP.</div>`
        },
        {
          id: 'm2s4', title: 'Peralatan Jaringan',
          html: `
<div class="tblw"><table class="tbl"><tr><th>Perangkat</th><th>Fungsi</th></tr>
<tr><td>NIC (kartu jaringan)</td><td>Antarmuka jaringan pada komputer, punya alamat MAC unik</td></tr>
<tr><td>Hub</td><td>Mengulang sinyal ke semua port (sudah jarang dipakai)</td></tr>
<tr><td>Switch</td><td>Meneruskan frame ke port tujuan berdasarkan alamat MAC (layer 2)</td></tr>
<tr><td>Router</td><td>Menghubungkan jaringan berbeda berdasarkan alamat IP (layer 3)</td></tr>
<tr><td>Access Point</td><td>Menyediakan jaringan nirkabel (Wi-Fi)</td></tr>
<tr><td>Modem / ONT</td><td>Menghubungkan jaringan ke penyedia layanan internet</td></tr>
<tr><td>Firewall</td><td>Menyaring lalu lintas berdasarkan aturan keamanan</td></tr>
<tr><td>Patch panel dan rak</td><td>Merapikan dan mengorganisasi kabel di ruang server</td></tr></table></div>
<h4>Media transmisi</h4>
<ul><li><b>Kabel UTP</b> Cat5e (hingga 1 Gbps) dan Cat6 (hingga 10 Gbps pada jarak pendek), panjang maksimum 100 meter per segmen.</li><li><b>Fiber optic</b>: jarak jauh, kecepatan tinggi, kebal gangguan elektromagnetik.</li></ul>
<h4>Urutan warna kabel RJ45</h4>
<div class="tblw"><table class="tbl"><tr><th>Pin</th><th>1</th><th>2</th><th>3</th><th>4</th><th>5</th><th>6</th><th>7</th><th>8</th></tr>
<tr><td><b>T568A</b></td><td>putih hijau</td><td>hijau</td><td>putih oranye</td><td>biru</td><td>putih biru</td><td>oranye</td><td>putih coklat</td><td>coklat</td></tr>
<tr><td><b>T568B</b></td><td>putih oranye</td><td>oranye</td><td>putih hijau</td><td>biru</td><td>putih biru</td><td>hijau</td><td>putih coklat</td><td>coklat</td></tr></table></div>
<p><b>Straight</b>: kedua ujung memakai standar yang sama (PC ke switch). <b>Crossover</b>: satu ujung T568A dan ujung lain T568B (PC ke PC, perangkat sejenis).</p>`
        },
        {
          id: 'm2s5', title: 'Pengalamatan IP',
          html: `
<p>Alamat <b>IPv4</b> terdiri dari 32 bit, ditulis empat bagian desimal (oktet) seperti <code>192.168.10.5</code>. Setiap alamat terdiri dari bagian <b>network</b> dan bagian <b>host</b>, dipisahkan oleh <i>subnet mask</i>.</p>
<div class="tblw"><table class="tbl"><tr><th>Kelas</th><th>Oktet pertama</th><th>Mask bawaan</th><th>Keterangan</th></tr>
<tr><td>A</td><td>1 - 126</td><td>255.0.0.0 (/8)</td><td>Jaringan sangat besar</td></tr>
<tr><td>B</td><td>128 - 191</td><td>255.255.0.0 (/16)</td><td>Jaringan menengah</td></tr>
<tr><td>C</td><td>192 - 223</td><td>255.255.255.0 (/24)</td><td>Jaringan kecil, 254 host</td></tr>
<tr><td>D</td><td>224 - 239</td><td>-</td><td>Multicast</td></tr>
<tr><td>E</td><td>240 - 255</td><td>-</td><td>Eksperimen</td></tr></table></div>
<h4>Alamat privat (tidak dirutekan di internet)</h4>
<ul><li><code>10.0.0.0</code> sampai <code>10.255.255.255</code> (10.0.0.0/8)</li><li><code>172.16.0.0</code> sampai <code>172.31.255.255</code> (172.16.0.0/12)</li><li><code>192.168.0.0</code> sampai <code>192.168.255.255</code> (192.168.0.0/16)</li></ul>
<p>Alamat khusus: <code>127.0.0.1</code> (loopback, komputer sendiri), <code>169.254.x.x</code> (APIPA, muncul saat DHCP gagal).</p>
<h4>Alamat penting dalam satu jaringan</h4>
<ul><li><b>Network address</b>: alamat pertama, nama jaringan itu sendiri.</li><li><b>Broadcast address</b>: alamat terakhir, ditujukan ke semua host.</li><li><b>Host valid</b>: alamat di antara keduanya.</li></ul>
<p><b>IPv6</b> memakai 128 bit dalam notasi heksadesimal, misalnya <code>2001:db8::1</code>, untuk mengatasi kehabisan alamat IPv4.</p>`
        },
        {
          id: 'm2s6', title: 'Subnetting', tool: 'subnet',
          html: `
<p><b>Subnetting</b> adalah membagi satu jaringan besar menjadi beberapa jaringan kecil (subnet) dengan meminjam bit dari bagian host.</p>
<h4>Langkah cepat</h4>
<ol>
<li>Tentukan jumlah subnet atau jumlah host yang dibutuhkan.</li>
<li>Pinjam <i>n</i> bit dari bagian host: jumlah subnet = 2<sup>n</sup>.</li>
<li>Prefix baru = prefix lama + n. Sisa bit host = 32 - prefix baru.</li>
<li>Jumlah host per subnet = 2<sup>bit host</sup> - 2.</li>
<li>Ukuran blok = 2<sup>bit host</sup> (pada oktet yang berubah).</li>
</ol>
<h4>Contoh: 192.168.1.0/24 dibagi 4 subnet</h4>
<p>Pinjam 2 bit sehingga prefix menjadi /26, mask 255.255.255.192, blok 64, host per subnet 62.</p>
<div class="tblw"><table class="tbl"><tr><th>Subnet</th><th>Network</th><th>Host valid</th><th>Broadcast</th></tr>
<tr><td>1</td><td>192.168.1.0</td><td>.1 - .62</td><td>192.168.1.63</td></tr>
<tr><td>2</td><td>192.168.1.64</td><td>.65 - .126</td><td>192.168.1.127</td></tr>
<tr><td>3</td><td>192.168.1.128</td><td>.129 - .190</td><td>192.168.1.191</td></tr>
<tr><td>4</td><td>192.168.1.192</td><td>.193 - .254</td><td>192.168.1.255</td></tr></table></div>
<p>Coba hitung sendiri dengan kalkulator di bawah, lalu bandingkan hasilnya.</p>`
        },
        {
          id: 'm2s7', title: 'CIDR',
          html: `
<p><b>CIDR</b> (<i>Classless Inter-Domain Routing</i>) menulis subnet mask dalam bentuk <b>/prefix</b>, yaitu jumlah bit 1 pada mask. Contoh <code>192.168.1.0/24</code> sama dengan mask 255.255.255.0. CIDR tidak lagi terikat kelas A, B, atau C.</p>
<div class="tblw"><table class="tbl"><tr><th>CIDR</th><th>Subnet mask</th><th>Blok</th><th>Host valid</th></tr>
<tr><td>/8</td><td>255.0.0.0</td><td>-</td><td>16.777.214</td></tr>
<tr><td>/16</td><td>255.255.0.0</td><td>-</td><td>65.534</td></tr>
<tr><td>/24</td><td>255.255.255.0</td><td>256</td><td>254</td></tr>
<tr><td>/25</td><td>255.255.255.128</td><td>128</td><td>126</td></tr>
<tr><td>/26</td><td>255.255.255.192</td><td>64</td><td>62</td></tr>
<tr><td>/27</td><td>255.255.255.224</td><td>32</td><td>30</td></tr>
<tr><td>/28</td><td>255.255.255.240</td><td>16</td><td>14</td></tr>
<tr><td>/29</td><td>255.255.255.248</td><td>8</td><td>6</td></tr>
<tr><td>/30</td><td>255.255.255.252</td><td>4</td><td>2</td></tr></table></div>
<div class="tip">Hafalkan pola oktet terakhir: 128, 192, 224, 240, 248, 252. Setiap tambah 1 bit prefix, jumlah host turun separuh.</div>`
        },
        {
          id: 'm2s8', title: 'VLSM', tool: 'vlsm',
          html: `
<p><b>VLSM</b> (<i>Variable Length Subnet Mask</i>) membagi jaringan menjadi subnet dengan <b>ukuran berbeda</b> sesuai kebutuhan host masing-masing, sehingga alamat IP tidak terbuang.</p>
<h4>Langkah</h4>
<ol><li>Urutkan kebutuhan dari host <b>terbanyak</b> ke tersedikit.</li><li>Untuk tiap kebutuhan, cari prefix terkecil yang muat: host + 2 (network dan broadcast).</li><li>Alokasikan berurutan mulai dari alamat awal, tanpa tumpang tindih.</li></ol>
<h4>Contoh: 192.168.10.0/24</h4>
<div class="tblw"><table class="tbl"><tr><th>Kebutuhan</th><th>Prefix</th><th>Network</th><th>Host valid</th><th>Broadcast</th></tr>
<tr><td>LAN A: 100 host</td><td>/25</td><td>192.168.10.0</td><td>.1 - .126</td><td>.127</td></tr>
<tr><td>LAN B: 50 host</td><td>/26</td><td>192.168.10.128</td><td>.129 - .190</td><td>.191</td></tr>
<tr><td>LAN C: 25 host</td><td>/27</td><td>192.168.10.192</td><td>.193 - .222</td><td>.223</td></tr>
<tr><td>Link router: 2 host</td><td>/30</td><td>192.168.10.224</td><td>.225 - .226</td><td>.227</td></tr></table></div>
<p>Masih tersisa alamat dari 192.168.10.228 sampai .255 untuk pengembangan. Coba sendiri dengan alat bantu di bawah.</p>`
        }
      ]
    },

    {
      id: 'm3', icon: '⚡', color: '#4cc35a', short: 'Teknik Instalasi Tenaga Listrik',
      title: 'Teknik Instalasi Tenaga Listrik',
      desc: 'PUIL, K3, instalasi listrik 1 fasa, hukum Ohm dan daya, serta peralatan mesin listrik.',
      tp: [
        'Menjelaskan tujuan PUIL dan menerapkan prinsip K3 kelistrikan.',
        'Mengenali komponen dan simbol instalasi listrik.',
        'Merancang dan memasang instalasi listrik 1 fasa sederhana.',
        'Menghitung arus, daya, dan memilih pengaman (MCB).',
        'Menjelaskan fungsi motor listrik, transformator, dan peralatan kendali.'
      ],
      sections: [
        {
          id: 'm3s1', title: 'PUIL dan K3 Listrik',
          html: `
<p><b>PUIL</b> adalah <i>Persyaratan Umum Instalasi Listrik</i>, acuan nasional untuk perancangan, pemasangan, dan pemeriksaan instalasi listrik (edisi terbaru: PUIL 2011, SNI 0225:2011).</p>
<h4>Tujuan PUIL</h4>
<ul><li>Melindungi manusia dari bahaya sengatan listrik.</li><li>Melindungi instalasi, peralatan, dan bangunan dari kebakaran dan kerusakan.</li><li>Menjamin instalasi bekerja baik, andal, dan ekonomis.</li><li>Melindungi lingkungan.</li></ul>
<h4>Warna penghantar</h4>
<div class="tblw"><table class="tbl"><tr><th>Fungsi</th><th>Warna</th></tr>
<tr><td>Netral (N)</td><td>Biru</td></tr>
<tr><td>Pembumian / pelindung (PE)</td><td>Hijau-kuning</td></tr>
<tr><td>Fasa (L)</td><td>Bergantung edisi standar (instalasi lama merah, kuning, hitam; standar IEC coklat, hitam, abu-abu). Ikuti ketentuan yang berlaku.</td></tr></table></div>
<h4>Prinsip K3 listrik</h4>
<ol><li>Matikan sumber (MCB/saklar utama) sebelum bekerja, lalu pasang tanda peringatan.</li><li>Pastikan tidak ada tegangan menggunakan tespen atau multimeter.</li><li>Gunakan alat pelindung diri: sepatu isolasi, sarung tangan, kacamata.</li><li>Gunakan perkakas berisolasi dan jangan bekerja pada kondisi basah.</li><li>Jangan bekerja sendirian pada pekerjaan berisiko.</li></ol>
<div class="warn">Arus yang melewati tubuh dapat berbahaya. Jangan pernah menyentuh bagian instalasi yang masih bertegangan. Praktik dilakukan di bawah pengawasan guru.</div>`
        },
        {
          id: 'm3s2', title: 'Komponen Instalasi Listrik',
          html: `
<div class="tblw"><table class="tbl"><tr><th>Komponen</th><th>Fungsi</th></tr>
<tr><td>kWh meter</td><td>Mengukur energi listrik yang dipakai (kilowatt-jam)</td></tr>
<tr><td>MCB (Miniature Circuit Breaker)</td><td>Memutus rangkaian otomatis saat arus lebih atau hubung singkat</td></tr>
<tr><td>RCD/ELCB</td><td>Memutus saat ada arus bocor ke tanah, melindungi dari sengatan (umumnya sensitivitas 30 mA)</td></tr>
<tr><td>Saklar tunggal, seri, tukar</td><td>Menghubungkan atau memutus beban</td></tr>
<tr><td>Stop kontak</td><td>Titik pengambilan daya untuk peralatan, sebaiknya berpembumian</td></tr>
<tr><td>Fitting dan lampu</td><td>Beban penerangan</td></tr>
<tr><td>Kabel NYA</td><td>Inti tunggal tanpa selubung, dipasang di dalam pipa</td></tr>
<tr><td>Kabel NYM</td><td>Inti banyak dengan selubung PVC, untuk instalasi tetap di dalam bangunan</td></tr>
<tr><td>Pipa conduit, kotak sambung</td><td>Pelindung kabel dan tempat sambungan</td></tr></table></div>
<h4>Jenis saklar</h4>
<ul><li><b>Saklar tunggal</b>: satu lampu dari satu tempat.</li><li><b>Saklar seri</b> (ganda): dua lampu dikendalikan terpisah dari satu tempat.</li><li><b>Saklar tukar</b> (hotel): satu lampu dikendalikan dari dua tempat, misalnya dua ujung lorong.</li></ul>
<p>Ukuran kabel yang umum dipakai: 1,5 mm² untuk penerangan dan 2,5 mm² untuk stop kontak. Pemilihan akhir mengikuti kemampuan hantar arus (KHA) pada tabel PUIL.</p>`
        },
        {
          id: 'm3s3', title: 'Instalasi Listrik 1 Fasa',
          html: `
<p>Instalasi 1 fasa memakai satu penghantar fasa (L) dan satu netral (N) dengan tegangan nominal sekitar 220/230 volt. Inilah instalasi rumah dan ruang kelas.</p>
<h4>Diagram saklar tunggal dan lampu</h4>
<div class="svgbox"><svg viewBox="0 0 520 230" role="img" aria-label="Diagram instalasi saklar tunggal dan lampu">
<rect width="520" height="230" fill="#030a1c"/>
<text x="14" y="38" fill="#ff9aa6" font-size="14" font-family="sans-serif">Fasa (L)</text>
<text x="14" y="198" fill="#7fb5ff" font-size="14" font-family="sans-serif">Netral (N)</text>
<line x1="80" y1="34" x2="150" y2="34" stroke="#ff6b7a" stroke-width="3"/>
<rect x="150" y="18" width="56" height="32" rx="4" fill="#0d2150" stroke="#56d6ff"/><text x="162" y="39" fill="#fff" font-size="13" font-family="sans-serif">MCB</text>
<line x1="206" y1="34" x2="300" y2="34" stroke="#ff6b7a" stroke-width="3"/>
<circle cx="300" cy="34" r="4" fill="#f5b81c"/><line x1="300" y1="34" x2="334" y2="14" stroke="#f5b81c" stroke-width="3"/><circle cx="350" cy="34" r="4" fill="#f5b81c"/>
<text x="296" y="64" fill="#fff" font-size="13" font-family="sans-serif">Saklar</text>
<line x1="350" y1="34" x2="440" y2="34" stroke="#ff6b7a" stroke-width="3"/>
<line x1="440" y1="34" x2="440" y2="95" stroke="#ff6b7a" stroke-width="3"/>
<circle cx="440" cy="120" r="26" fill="none" stroke="#f5b81c" stroke-width="3"/>
<line x1="422" y1="102" x2="458" y2="138" stroke="#f5b81c" stroke-width="3"/><line x1="458" y1="102" x2="422" y2="138" stroke="#f5b81c" stroke-width="3"/>
<text x="400" y="170" fill="#fff" font-size="13" font-family="sans-serif">Lampu</text>
<line x1="440" y1="146" x2="440" y2="196" stroke="#4aa3ff" stroke-width="3"/>
<line x1="80" y1="196" x2="440" y2="196" stroke="#4aa3ff" stroke-width="3"/>
</svg></div>
<h4>Aturan pemasangan</h4>
<ul><li>Saklar dipasang pada penghantar <b>fasa</b>, bukan netral, sehingga lampu tidak bertegangan saat saklar mati.</li><li>Netral disambung langsung ke fitting lampu.</li><li>Stop kontak berpembumian: L ke lubang kanan, N ke kiri, PE ke kontak pembumian.</li><li>Setiap sambungan kabel dilakukan di kotak sambung, bukan di dalam pipa.</li><li>Pasang MCB sebelum beban sebagai pengaman.</li></ul>
<h4>Urutan kerja</h4>
<ol><li>Rancang gambar instalasi dan hitung kebutuhan bahan.</li><li>Matikan sumber dan pasang tanda peringatan.</li><li>Pasang pipa, kotak sambung, saklar, dan fitting.</li><li>Tarik dan sambung kabel sesuai gambar.</li><li>Periksa sambungan, ukur dengan multimeter (tanpa tegangan).</li><li>Nyalakan dan uji, lalu catat hasil.</li></ol>`
        },
        {
          id: 'm3s4', title: 'Hukum Ohm, Daya, dan MCB', tool: 'listrik',
          html: `
<h4>Hukum Ohm</h4>
<p><b>V = I × R</b>, dengan V tegangan (volt), I arus (ampere), R hambatan (ohm). Contoh: R = 44 Ω pada 220 V mengalirkan arus 220 / 44 = 5 A.</p>
<h4>Daya listrik</h4>
<ul><li>Beban resistif (lampu pijar, pemanas): <b>P = V × I</b> (watt).</li><li>Beban induktif (motor, AC, kipas): <b>P = V × I × cos φ</b>, cos φ adalah faktor daya (0 sampai 1).</li><li>Energi: <b>kWh = daya (kW) × waktu (jam)</b>.</li></ul>
<h4>Memilih MCB</h4>
<p>Hitung arus total beban: <b>I = P / (V × cos φ)</b>. Pilih MCB standar yang nilainya sedikit di atas arus beban dan <b>tidak melebihi kemampuan hantar arus kabel</b>. Nilai MCB yang umum: 2, 4, 6, 10, 16, 20, 25, 32 A.</p>
<p>Contoh: beban total 1.025 W pada 220 V (cos φ = 1) menghasilkan arus 4,66 A, maka dipilih MCB 6 A.</p>
<p>Gunakan kalkulator di bawah untuk berlatih.</p>`
        },
        {
          id: 'm3s5', title: 'Peralatan Mesin Listrik',
          html: `
<h4>Motor listrik</h4>
<p>Motor mengubah energi listrik menjadi energi gerak.</p>
<div class="tblw"><table class="tbl"><tr><th>Jenis</th><th>Ciri</th></tr>
<tr><td>Motor induksi 3 fasa</td><td>Kokoh dan paling banyak dipakai di industri. Medan putar stator membuat rotor berputar sendiri.</td></tr>
<tr><td>Motor induksi 1 fasa</td><td>Dipakai di peralatan rumah (pompa air, kipas). Membutuhkan kapasitor untuk starting atau running.</td></tr>
<tr><td>Motor DC</td><td>Kecepatan mudah diatur, dipakai pada alat bergerak dan robot.</td></tr></table></div>
<p>Bagian utama: <b>stator</b> (diam) dan <b>rotor</b> (berputar). Kecepatan sinkron: n = 120 × f / p. Pada 50 Hz dengan 4 kutub, n = 1.500 rpm.</p>
<h4>Transformator</h4>
<p>Mengubah tegangan AC tanpa mengubah frekuensi. Hubungan: <b>Vp / Vs = Np / Ns</b>. Transformator <i>step-up</i> menaikkan tegangan (Ns &gt; Np), <i>step-down</i> menurunkan tegangan (Ns &lt; Np). Contoh adaptor charger adalah transformator step-down.</p>
<h4>Generator</h4>
<p>Mengubah energi gerak menjadi energi listrik berdasarkan induksi elektromagnetik. Contoh: genset cadangan sekolah.</p>
<h4>Peralatan kendali motor</h4>
<div class="tblw"><table class="tbl"><tr><th>Alat</th><th>Fungsi</th></tr>
<tr><td>Kontaktor</td><td>Saklar elektromagnetik untuk menghubungkan daya ke motor</td></tr>
<tr><td>Thermal overload relay (TOR)</td><td>Melindungi motor dari beban lebih</td></tr>
<tr><td>Push button ON/OFF</td><td>Perintah menyalakan dan mematikan</td></tr>
<tr><td>Relay dan timer</td><td>Pengendali dan pengatur waktu</td></tr></table></div>`
        },
        {
          id: 'm3s6', title: 'Alat Ukur Listrik',
          html: `
<div class="tblw"><table class="tbl"><tr><th>Alat</th><th>Fungsi</th></tr>
<tr><td>Tespen</td><td>Memeriksa ada tidaknya tegangan pada penghantar fasa</td></tr>
<tr><td>Multimeter</td><td>Mengukur tegangan AC/DC, arus, hambatan, dan kontinuitas</td></tr>
<tr><td>Tang ampere (clamp meter)</td><td>Mengukur arus tanpa memutus kabel</td></tr>
<tr><td>Megger (insulation tester)</td><td>Mengukur tahanan isolasi kabel dan motor</td></tr>
<tr><td>Earth tester</td><td>Mengukur tahanan pembumian</td></tr>
<tr><td>Wattmeter, kWh meter</td><td>Mengukur daya dan energi</td></tr></table></div>
<h4>Tips pengukuran aman</h4>
<ul><li>Pilih jenis dan batas ukur yang tepat sebelum menyentuhkan probe.</li><li>Mengukur tegangan dipasang <b>paralel</b>, mengukur arus dipasang <b>seri</b> (atau pakai tang ampere).</li><li>Mengukur hambatan dan kontinuitas hanya pada rangkaian <b>tanpa tegangan</b>.</li><li>Periksa kondisi kabel probe sebelum dipakai.</li></ul>`
        }
      ]
    }
  ]
};
