/* Latar jaringan komputer: node, link, dan paket data yang bergerak. */
(function () {
  'use strict';
  const cv = document.getElementById('bg');
  if (!cv) return;
  const c = cv.getContext('2d');
  const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  let W = 0, H = 0, dpr = 1, nodes = [], links = [], packets = [], raf = 0;

  function build() {
    dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    W = window.innerWidth; H = window.innerHeight;
    cv.width = W * dpr; cv.height = H * dpr;
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    const n = Math.max(22, Math.min(70, Math.floor(W * H / 24000)));
    nodes = []; links = []; packets = [];
    for (let i = 0; i < n; i++) {
      const hub = Math.random() < 0.14;
      nodes.push({
        x: Math.random() * W, y: Math.random() * H,
        vx: (Math.random() - .5) * .18, vy: (Math.random() - .5) * .18,
        r: hub ? 4.2 : 2.2, hub
      });
    }
  }

  function relink() {
    links = [];
    const max = Math.min(190, Math.max(120, W / 7));
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const dx = nodes[i].x - nodes[j].x, dy = nodes[i].y - nodes[j].y;
        const d = Math.sqrt(dx * dx + dy * dy);
        if (d < max) links.push([i, j, d, max]);
      }
    }
  }

  function spawn() {
    if (!links.length || packets.length > 26) return;
    const l = links[Math.floor(Math.random() * links.length)];
    const rev = Math.random() < .5;
    packets.push({ a: rev ? l[1] : l[0], b: rev ? l[0] : l[1], t: 0, sp: .008 + Math.random() * .012, gold: Math.random() < .25 });
  }

  let frame = 0;
  function draw() {
    c.clearRect(0, 0, W, H);
    if (!reduce) {
      nodes.forEach(n => {
        n.x += n.vx; n.y += n.vy;
        if (n.x < -20) n.x = W + 20; if (n.x > W + 20) n.x = -20;
        if (n.y < -20) n.y = H + 20; if (n.y > H + 20) n.y = -20;
      });
      if (frame % 12 === 0) relink();
      if (frame % 18 === 0) spawn();
    }
    frame++;
    c.lineWidth = 1;
    links.forEach(l => {
      const a = nodes[l[0]], b = nodes[l[1]];
      const al = (1 - l[2] / l[3]) * .38;
      c.strokeStyle = 'rgba(86,170,255,' + al.toFixed(3) + ')';
      c.beginPath(); c.moveTo(a.x, a.y); c.lineTo(b.x, b.y); c.stroke();
    });
    nodes.forEach(n => {
      c.beginPath(); c.arc(n.x, n.y, n.r, 0, 6.2832);
      c.fillStyle = n.hub ? 'rgba(245,184,28,.9)' : 'rgba(120,190,255,.75)';
      c.fill();
      if (n.hub) {
        c.beginPath(); c.arc(n.x, n.y, n.r + 5, 0, 6.2832);
        c.strokeStyle = 'rgba(245,184,28,.22)'; c.stroke();
      }
    });
    packets = packets.filter(p => {
      p.t += p.sp;
      if (p.t >= 1) return false;
      const a = nodes[p.a], b = nodes[p.b];
      const x = a.x + (b.x - a.x) * p.t, y = a.y + (b.y - a.y) * p.t;
      c.beginPath(); c.arc(x, y, 2.6, 0, 6.2832);
      c.fillStyle = p.gold ? '#ffd45e' : '#7fe3ff';
      c.shadowColor = p.gold ? '#f5b81c' : '#56d6ff'; c.shadowBlur = 10;
      c.fill(); c.shadowBlur = 0;
      return true;
    });
    if (!reduce) raf = requestAnimationFrame(draw);
  }

  function start() {
    cancelAnimationFrame(raf);
    build(); relink(); draw();
  }
  let rt;
  window.addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(start, 200); });
  document.addEventListener('visibilitychange', () => {
    if (reduce) return;
    if (document.hidden) cancelAnimationFrame(raf); else { cancelAnimationFrame(raf); raf = requestAnimationFrame(draw); }
  });
  start();
})();
