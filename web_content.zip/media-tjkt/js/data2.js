/* Data soal, praktik, dan LKPD. Format soal: q, o (opsi), a (indeks jawaban benar), e (pembahasan). */
Object.assign(DATA, {
  latihan: {
    m1: [
      { q: 'Sistem operasi yang dirancang untuk mengelola sumber daya dan melayani banyak klien di jaringan disebut ...', o: ['Sistem operasi jaringan (NOS)', 'Firmware BIOS', 'Bootloader', 'Driver perangkat'], a: 0, e: 'NOS mengelola pengguna, file, printer, dan layanan jaringan untuk banyak klien sekaligus.' },
      { q: 'Perintah Linux untuk menampilkan lokasi folder kerja saat ini adalah ...', o: ['ls', 'cd', 'pwd', 'mkdir'], a: 2, e: 'pwd (print working directory) menampilkan lokasi folder saat ini.' },
      { q: 'File konfigurasi sistem dan layanan di Linux umumnya disimpan pada direktori ...', o: ['/home', '/etc', '/var', '/root'], a: 1, e: '/etc berisi file konfigurasi, misalnya /etc/dhcp/dhcpd.conf dan /etc/bind.' },
      { q: 'Contoh hypervisor tipe 1 (bare-metal) adalah ...', o: ['VirtualBox', 'VMware Workstation', 'Proxmox VE', 'Windows Notepad'], a: 2, e: 'Proxmox VE berjalan langsung di atas perangkat keras. VirtualBox dan Workstation adalah tipe 2.' },
      { q: 'Urutan proses DHCP yang benar adalah ...', o: ['Offer, Discover, Request, Acknowledge', 'Discover, Offer, Request, Acknowledge', 'Request, Discover, Acknowledge, Offer', 'Discover, Request, Offer, Acknowledge'], a: 1, e: 'DORA: Discover, Offer, Request, Acknowledge.' },
      { q: 'Port default layanan DNS adalah ...', o: ['21', '53', '80', '110'], a: 1, e: 'DNS memakai port 53. Port 21 FTP, 80 HTTP, 110 POP3.' },
      { q: 'Record DNS yang memetakan nama domain ke alamat IPv4 adalah ...', o: ['A', 'MX', 'CNAME', 'PTR'], a: 0, e: 'Record A memetakan nama ke IPv4. MX untuk email, CNAME alias, PTR reverse.' },
      { q: 'Paket yang dipasang untuk web server Apache di Debian/Ubuntu adalah ...', o: ['bind9', 'vsftpd', 'samba', 'apache2'], a: 3, e: 'Perintahnya: sudo apt install apache2.' }
    ],
    m2: [
      { q: 'Topologi yang semua perangkatnya terhubung ke satu perangkat pusat (switch) adalah topologi ...', o: ['Bus', 'Star', 'Ring', 'Mesh'], a: 1, e: 'Pada topologi star, semua node terhubung ke switch atau hub pusat.' },
      { q: 'Alamat IPv4 memiliki panjang ... bit.', o: ['8', '16', '32', '128'], a: 2, e: 'IPv4 = 32 bit (4 oktet). IPv6 = 128 bit.' },
      { q: 'Rentang alamat IP privat yang sering dipakai pada jaringan kecil adalah ...', o: ['1.0.0.0 - 1.255.255.255', '172.15.0.0 - 172.15.255.255', '192.168.0.0 - 192.168.255.255', '224.0.0.0 - 239.255.255.255'], a: 2, e: '192.168.0.0/16 adalah blok privat. Rentang 224-239 adalah multicast.' },
      { q: 'Subnet mask untuk prefix /24 adalah ...', o: ['255.255.255.0', '255.255.0.0', '255.255.255.128', '255.255.255.192'], a: 0, e: '/24 berarti 24 bit pertama bernilai 1, yaitu 255.255.255.0.' },
      { q: 'Jumlah host valid pada jaringan /26 adalah ...', o: ['30', '62', '64', '126'], a: 1, e: 'Bit host = 32 - 26 = 6, sehingga 2^6 - 2 = 62.' },
      { q: 'Alamat network dari 192.168.10.77/26 adalah ...', o: ['192.168.10.0', '192.168.10.64', '192.168.10.72', '192.168.10.76'], a: 1, e: 'Blok /26 = 64: 0, 64, 128, 192. Angka 77 berada di blok 64, jadi network 192.168.10.64.' },
      { q: 'Tujuan utama VLSM adalah ...', o: ['Mempercepat kabel', 'Membagi jaringan menjadi subnet berukuran berbeda sesuai kebutuhan', 'Mengubah IP publik menjadi privat', 'Mengenkripsi data'], a: 1, e: 'VLSM menyesuaikan ukuran subnet dengan jumlah host agar alamat IP tidak terbuang.' },
      { q: 'Perangkat layer 3 yang meneruskan paket antar jaringan berbeda adalah ...', o: ['Hub', 'Repeater', 'Router', 'Patch panel'], a: 2, e: 'Router bekerja berdasarkan alamat IP untuk menghubungkan jaringan.' }
    ],
    m3: [
      { q: 'PUIL adalah singkatan dari ...', o: ['Persyaratan Umum Instalasi Listrik', 'Pedoman Utama Instalasi Lampu', 'Peraturan Umum Industri Listrik', 'Panduan Umum Isolasi Listrik'], a: 0, e: 'PUIL = Persyaratan Umum Instalasi Listrik (SNI 0225).' },
      { q: 'Warna isolasi penghantar netral adalah ...', o: ['Merah', 'Hijau-kuning', 'Biru', 'Hitam'], a: 2, e: 'Netral berwarna biru. Hijau-kuning dipakai untuk pembumian (PE).' },
      { q: 'Warna isolasi penghantar pembumian (PE) adalah ...', o: ['Hijau-kuning', 'Biru', 'Putih', 'Merah'], a: 0, e: 'Penghantar pembumian berwarna hijau-kuning.' },
      { q: 'Alat proteksi yang memutus rangkaian saat terjadi arus lebih atau hubung singkat di rumah adalah ...', o: ['kWh meter', 'MCB', 'Fitting', 'Saklar tunggal'], a: 1, e: 'MCB memutus otomatis ketika arus melebihi batas.' },
      { q: 'Saklar pada instalasi lampu harus dipasang pada penghantar ...', o: ['Netral', 'Pembumian', 'Fasa', 'Bebas'], a: 2, e: 'Agar saat saklar mati, lampu tidak bertegangan.' },
      { q: 'Beban resistif 220 V mengalirkan arus 5 A. Dayanya adalah ...', o: ['44 W', '225 W', '1.100 W', '1.760 W'], a: 2, e: 'P = V x I = 220 x 5 = 1.100 W.' },
      { q: 'Rumus hukum Ohm yang benar adalah ...', o: ['V = I / R', 'V = I x R', 'I = V x R', 'R = I / V'], a: 1, e: 'V = I x R.' },
      { q: 'Alat yang mengukur energi listrik (kWh) yang dipakai pelanggan adalah ...', o: ['Megger', 'Tespen', 'kWh meter', 'Tang ampere'], a: 2, e: 'kWh meter mencatat energi listrik dalam kilowatt-jam.' }
    ]
  },

  kuis: {
    m1: [
      { q: 'Port yang dipakai kanal perintah (control) pada FTP adalah ...', o: ['20', '21', '22', '25'], a: 1, e: 'FTP memakai port 21 untuk perintah dan 20 untuk data (mode aktif).' },
      { q: 'Aplikasi untuk berbagi file antara Linux dan Windows adalah ...', o: ['Postfix', 'Samba', 'BIND9', 'Dovecot'], a: 1, e: 'Samba memakai protokol SMB yang dikenal Windows.' },
      { q: 'Protokol yang digunakan untuk mengirim email antar server adalah ...', o: ['IMAP', 'POP3', 'SMTP', 'SNMP'], a: 2, e: 'SMTP untuk mengirim. IMAP dan POP3 untuk mengambil email.' },
      { q: 'Perintah agar layanan apache2 aktif otomatis saat komputer menyala adalah ...', o: ['systemctl enable apache2', 'systemctl status apache2', 'systemctl stop apache2', 'apt remove apache2'], a: 0, e: 'enable mengaktifkan layanan saat boot.' },
      { q: 'Satu server dipakai banyak situs bersama dengan biaya murah dan kontrol terbatas. Ini adalah ...', o: ['Dedicated server', 'VPS', 'Shared hosting', 'Colocation'], a: 2, e: 'Shared hosting berbagi sumber daya antar banyak pelanggan.' },
      { q: 'Contoh aplikasi monitoring jaringan adalah ...', o: ['Zabbix', 'Dovecot', 'MariaDB', 'Samba'], a: 0, e: 'Zabbix memantau perangkat dan layanan. Yang lain adalah server layanan.' },
      { q: 'Protokol VPN modern yang ringan dan memakai port UDP 51820 adalah ...', o: ['PPTP', 'WireGuard', 'Telnet', 'SNMP'], a: 1, e: 'WireGuard default berjalan di UDP 51820.' },
      { q: 'Mode jaringan VirtualBox yang membuat VM mendapat IP sejaringan dengan komputer fisik adalah ...', o: ['NAT', 'Bridged Adapter', 'Host-only', 'Internal Network'], a: 1, e: 'Bridged Adapter menyambungkan VM langsung ke jaringan fisik.' }
    ],
    m2: [
      { q: 'Pada standar T568B, kabel pin 1 dan pin 2 berwarna ...', o: ['putih hijau, hijau', 'putih oranye, oranye', 'putih biru, biru', 'putih coklat, coklat'], a: 1, e: 'T568B: pin 1 putih oranye, pin 2 oranye.' },
      { q: 'Jumlah host valid pada jaringan /28 adalah ...', o: ['6', '14', '30', '16'], a: 1, e: '2^4 - 2 = 14.' },
      { q: 'Subnet mask untuk /27 adalah ...', o: ['255.255.255.192', '255.255.255.224', '255.255.255.240', '255.255.255.248'], a: 1, e: '/27 = 3 bit di oktet terakhir: 128+64+32 = 224.' },
      { q: 'Pada VLSM, alokasi pertama diberikan kepada kebutuhan ...', o: ['Host paling sedikit', 'Host paling banyak', 'Urutan acak', 'Subnet paling akhir'], a: 1, e: 'Urutkan dari host terbanyak agar blok besar tidak terpecah.' },
      { q: 'Tiga lapisan model hierarki jaringan adalah ...', o: ['Core, Distribution, Access', 'Input, Process, Output', 'Physical, Data Link, Network', 'Client, Server, Peer'], a: 0, e: 'Model hierarki: Core, Distribution, Access.' },
      { q: 'Alamat broadcast dari 192.168.1.0/25 adalah ...', o: ['192.168.1.63', '192.168.1.127', '192.168.1.128', '192.168.1.255'], a: 1, e: 'Blok /25 = 128, sehingga broadcast jaringan pertama adalah .127.' },
      { q: 'Pada arsitektur peer-to-peer ...', o: ['Ada satu server pusat saja', 'Setiap komputer dapat menjadi klien sekaligus server', 'Hanya dipakai di WAN', 'Tidak butuh perangkat jaringan'], a: 1, e: 'Peer-to-peer: semua komputer setara dan dapat berbagi sumber daya.' },
      { q: 'Media transmisi yang kebal gangguan elektromagnetik dan berjarak jauh adalah ...', o: ['Kabel UTP', 'Kabel koaksial', 'Fiber optic', 'Kabel telepon'], a: 2, e: 'Fiber optic memakai cahaya sehingga kebal gangguan elektromagnetik.' }
    ],
    m3: [
      { q: 'Tegangan nominal instalasi listrik 1 fasa di Indonesia adalah ...', o: ['12 V', '110 V', '220/230 V', '380 V'], a: 2, e: 'Tegangan 1 fasa sekitar 220/230 V. 380/400 V adalah antar fasa 3 fasa.' },
      { q: 'Beban 1.100 W pada 220 V (cos φ = 1) mengalirkan arus ...', o: ['2 A', '5 A', '10 A', '24 A'], a: 1, e: 'I = P / V = 1.100 / 220 = 5 A.' },
      { q: 'Bagian motor induksi yang berputar disebut ...', o: ['Stator', 'Rotor', 'Terminal', 'Kapasitor'], a: 1, e: 'Rotor berputar, stator diam.' },
      { q: 'Transformator step-down memiliki ...', o: ['Ns lebih besar dari Np', 'Ns sama dengan Np', 'Ns lebih kecil dari Np', 'Tidak punya lilitan'], a: 2, e: 'Step-down menurunkan tegangan sehingga lilitan sekunder lebih sedikit.' },
      { q: 'Alat untuk mengukur tahanan isolasi kabel adalah ...', o: ['Megger', 'Tespen', 'Amperemeter', 'Termometer'], a: 0, e: 'Megger (insulation tester) mengukur tahanan isolasi.' },
      { q: 'Fungsi thermal overload relay pada rangkaian motor adalah ...', o: ['Menaikkan tegangan', 'Melindungi motor dari beban lebih', 'Mengubah putaran', 'Mengukur daya'], a: 1, e: 'TOR membuka rangkaian kendali saat arus motor berlebih terlalu lama.' },
      { q: 'Saklar tukar (hotel) dipakai untuk ...', o: ['Menyalakan dua lampu terpisah', 'Mengendalikan satu lampu dari dua tempat', 'Menyalakan motor 3 fasa', 'Mengukur arus'], a: 1, e: 'Dua saklar tukar memungkinkan satu lampu dikendalikan dari dua lokasi.' },
      { q: 'Langkah pertama sebelum bekerja pada instalasi listrik adalah ...', o: ['Menyentuh kabel untuk mengecek', 'Mematikan sumber dan memastikan tidak ada tegangan', 'Memakai kabel terbuka', 'Mengganti MCB dengan yang lebih besar'], a: 1, e: 'Matikan sumber, beri tanda peringatan, lalu cek dengan tespen atau multimeter.' }
    ]
  },

  praktek: [
    {
      id: 'p1', title: 'Instalasi Debian/Ubuntu Server di VirtualBox', durasi: '2 x 45 menit', mod: 'm1',
      tujuan: 'Murid mampu membuat mesin virtual dan menginstal sistem operasi server Linux.',
      alat: 'Laptop/PC (RAM 8 GB atau lebih), VirtualBox, file ISO Debian atau Ubuntu Server.',
      langkah: [
        'Buka VirtualBox, klik New. Beri nama "SRV-TJKT", pilih tipe Linux dan versi Debian/Ubuntu 64-bit.',
        'Atur RAM 1024 MB dan buat disk virtual 20 GB (VDI, dynamically allocated).',
        'Pada Settings > Storage, pasang file ISO pada optical drive.',
        'Pada Settings > Network, pilih Bridged Adapter (atau NAT jika bridged tidak tersedia).',
        'Jalankan VM. Pilih bahasa, lokasi, dan nama host "srv-tjkt".',
        'Buat pengguna "siswa" dan kata sandi yang kamu ingat.',
        'Pada pilihan software, centang hanya "SSH server" dan "standard system utilities".',
        'Selesaikan instalasi, lepaskan ISO, restart, lalu login.',
        'Cek alamat IP dengan perintah ip a dan catat hasilnya.',
        'Uji koneksi dengan ping 8.8.8.8 lalu ambil snapshot VM.'
      ],
      hasil: 'VM server berjalan, bisa login, memiliki alamat IP, dan snapshot tersimpan.'
    },
    {
      id: 'p2', title: 'Konfigurasi DHCP Server', durasi: '2 x 45 menit', mod: 'm1',
      tujuan: 'Murid mampu mengonfigurasi DHCP server dan menguji pembagian IP otomatis ke klien.',
      alat: 'Dua VM (server dan klien), mode jaringan Internal Network yang sama.',
      langkah: [
        'Di server, atur IP statis 192.168.10.2/24 pada interface jaringan internal.',
        'Pasang paket: sudo apt install isc-dhcp-server -y.',
        'Edit /etc/default/isc-dhcp-server dan isi INTERFACESv4 dengan nama interface yang benar.',
        'Edit /etc/dhcp/dhcpd.conf: buat subnet 192.168.10.0, range .100 sampai .200, router .1.',
        'Jalankan sudo systemctl restart isc-dhcp-server lalu cek statusnya.',
        'Di klien, atur interface ke DHCP lalu nyalakan ulang jaringan.',
        'Cek IP klien dengan ip a. Pastikan berada pada rentang .100 sampai .200.',
        'Lihat catatan lease di server: cat /var/lib/dhcp/dhcpd.leases.',
        'Dokumentasikan hasil dengan tangkapan layar.'
      ],
      hasil: 'Klien mendapat IP otomatis dari server DHCP, dibuktikan dengan tangkapan layar.'
    },
    {
      id: 'p3', title: 'Konfigurasi DNS Server (BIND9)', durasi: '2 x 45 menit', mod: 'm1',
      tujuan: 'Murid mampu membuat zona DNS dan menguji resolusi nama.',
      alat: 'VM server dengan IP 192.168.10.2, VM klien.',
      langkah: [
        'Pasang paket: sudo apt install bind9 dnsutils -y.',
        'Tambahkan zona "tjkt.local" pada /etc/bind/named.conf.local.',
        'Salin db.local menjadi db.tjkt lalu isi record NS, A (ns1, www, mail), dan CNAME ftp.',
        'Periksa sintaks: sudo named-checkzone tjkt.local /etc/bind/db.tjkt.',
        'Restart bind9 dan pastikan statusnya active (running).',
        'Pada klien, atur DNS ke 192.168.10.2.',
        'Uji: nslookup www.tjkt.local dan dig tjkt.local MX.',
        'Catat hasil dan jelaskan apa yang terjadi bila server DNS dimatikan.'
      ],
      hasil: 'Nama www.tjkt.local dapat diterjemahkan menjadi 192.168.10.2 pada klien.'
    },
    {
      id: 'p4', title: 'Web Server dan Virtual Host', durasi: '2 x 45 menit', mod: 'm1',
      tujuan: 'Murid mampu memasang web server dan membuat situs dengan virtual host.',
      alat: 'VM server (sudah ada DNS), VM klien, peramban.',
      langkah: [
        'Pasang Apache: sudo apt install apache2 -y.',
        'Dari klien, buka http://192.168.10.2 dan pastikan halaman default muncul.',
        'Buat folder situs: sudo mkdir /var/www/tjkt.',
        'Buat file index.html berisi nama dan kelas kamu.',
        'Buat file /etc/apache2/sites-available/tjkt.conf dengan ServerName www.tjkt.local.',
        'Aktifkan: sudo a2ensite tjkt.conf lalu sudo systemctl reload apache2.',
        'Buka http://www.tjkt.local dari klien.',
        'Tangkap layar hasilnya untuk laporan.'
      ],
      hasil: 'Situs buatan murid tampil melalui nama www.tjkt.local.'
    },
    {
      id: 'p5', title: 'Perancangan VLSM di Cisco Packet Tracer', durasi: '2 x 45 menit', mod: 'm2',
      tujuan: 'Murid mampu merancang pengalamatan VLSM dan mengimplementasikannya pada simulator.',
      alat: 'Cisco Packet Tracer, kertas rancangan alamat.',
      langkah: [
        'Hitung VLSM untuk 192.168.10.0/24: LAN A 100 host, LAN B 50 host, LAN C 25 host, link router 2 host.',
        'Buat tabel: network, prefix, mask, rentang host, broadcast.',
        'Di Packet Tracer, pasang 1 router, 3 switch, dan beberapa PC pada tiap LAN.',
        'Atur IP gateway pada interface router untuk tiap LAN.',
        'Atur IP, mask, dan gateway tiap PC sesuai tabel.',
        'Uji ping antar PC pada LAN yang sama.',
        'Uji ping antar PC pada LAN berbeda.',
        'Simpan berkas .pkt dan tabel hitungan sebagai laporan.'
      ],
      hasil: 'Seluruh PC saling terhubung (ping berhasil) sesuai rancangan VLSM.'
    },
    {
      id: 'p6', title: 'Instalasi Listrik 1 Fasa: Lampu, Saklar, Stop Kontak', durasi: '3 x 45 menit', mod: 'm3',
      tujuan: 'Murid mampu memasang instalasi 1 fasa sederhana dengan menerapkan K3.',
      alat: 'Papan praktik, MCB 1 fasa, saklar tunggal, fitting dan lampu, stop kontak, kabel NYA/NYM, tespen, multimeter, tang, obeng, sepatu isolasi.',
      langkah: [
        'Pakai alat pelindung diri dan pastikan sumber listrik utama dalam keadaan mati.',
        'Periksa alat dan bahan, lalu gambar rencana instalasi (MCB, saklar, lampu, stop kontak).',
        'Pasang komponen pada papan praktik sesuai tata letak.',
        'Pasang kabel fasa dari MCB ke saklar, lalu dari saklar ke fitting lampu.',
        'Sambungkan netral langsung ke fitting lampu dan ke stop kontak.',
        'Sambungkan stop kontak: fasa, netral, dan pembumian (jika tersedia).',
        'Periksa dengan multimeter (mode kontinuitas) tanpa tegangan: tidak boleh ada hubung singkat antara fasa dan netral.',
        'Minta guru memeriksa pekerjaan sebelum dinyalakan.',
        'Nyalakan MCB. Uji saklar dan stop kontak, lalu catat hasilnya.',
        'Matikan MCB, rapikan alat, dan bersihkan area kerja.'
      ],
      hasil: 'Lampu menyala dengan saklar, stop kontak berfungsi, dan tidak ada MCB yang trip.'
    }
  ],

  lkpd: [
    {
      id: 'l1', mod: 'm1', title: 'LKPD 1: Administrasi Sistem Jaringan',
      petunjuk: 'Kerjakan secara berkelompok. Jawab dengan kalimat sendiri. Gunakan materi dan hasil praktik sebagai acuan.',
      items: [
        { t: 'Jelaskan perbedaan hypervisor tipe 1 dan tipe 2 beserta masing-masing dua contohnya.', hint: 'Lihat materi Virtualisasi.' },
        { t: 'Tuliskan port default untuk: DNS, FTP, HTTP, HTTPS, SMTP, IMAP, SSH, dan MariaDB.', hint: 'Lihat tabel port pada materi Konsep dan Instalasi Services.' },
        { t: 'Tuliskan tahapan proses DHCP (DORA) dan jelaskan fungsi tiap tahap.', hint: 'Discover, Offer, Request, Acknowledge.' },
        { t: 'Tulis konfigurasi dhcpd.conf untuk jaringan 192.168.20.0/24 dengan rentang IP .50 sampai .150, gateway .1, dan DNS 192.168.20.2.', hint: 'Gunakan blok subnet seperti contoh di materi DHCP.' },
        { t: 'Bandingkan shared hosting, VPS, dan dedicated server. Mana yang kamu sarankan untuk website sekolah dengan 500 pengunjung per hari? Berikan alasan.', hint: 'Pertimbangkan biaya, kontrol, dan trafik.' }
      ]
    },
    {
      id: 'l2', mod: 'm2', title: 'LKPD 2: Perencanaan dan Pengalamatan Jaringan',
      petunjuk: 'Kerjakan dengan teliti. Tunjukkan langkah perhitungan.',
      items: [
        { t: 'Sebutkan tiga topologi jaringan, gambarkan sketsanya, dan tuliskan satu kelebihan serta satu kekurangan masing-masing.', hint: 'Gunakan alat peraga topologi pada materi.' },
        { t: 'Sebuah lab komputer berisi 30 PC, 1 server, dan 1 printer jaringan. Tuliskan analisis kebutuhan dan daftar perangkat jaringan yang dibutuhkan (minimal 5 jenis).', hint: 'Switch, kabel UTP, router, access point, patch panel, UPS, dan sebagainya.' },
        { t: 'Bagi jaringan 192.168.50.0/24 menjadi 4 subnet sama besar. Tuliskan prefix, subnet mask, network, rentang host, dan broadcast tiap subnet.', hint: '4 subnet berarti pinjam 2 bit, hasilnya /26 dengan blok 64.' },
        { t: 'Rancang VLSM dari 172.16.0.0/24 untuk: Lab 100 host, Guru 50 host, TU 20 host, Server 10 host. Buat tabel alokasinya.', hint: 'Urutkan dari terbanyak: /25, /26, /27, /28.' },
        { t: 'Ubah ke bentuk CIDR: 255.255.255.224 dan 255.255.240.0. Berapa jumlah host valid masing-masing?', hint: 'Hitung jumlah bit 1 pada mask.' }
      ]
    },
    {
      id: 'l3', mod: 'm3', title: 'LKPD 3: Teknik Instalasi Tenaga Listrik',
      petunjuk: 'Kerjakan dengan memperhatikan prinsip K3 dan ketentuan PUIL.',
      items: [
        { t: 'Sebutkan lima prinsip K3 yang harus dilakukan sebelum dan saat bekerja pada instalasi listrik.', hint: 'Matikan sumber, cek tegangan, APD, perkakas berisolasi.' },
        { t: 'Gambarkan diagram instalasi 1 lampu dengan saklar tunggal dan sebutkan penghantar mana yang melalui saklar.', hint: 'Saklar pada fasa.' },
        { t: 'Sebuah rumah memiliki beban: AC 800 W, kulkas 150 W, dan 5 lampu 15 W (tegangan 220 V, cos φ = 1). Hitung daya total, arus total, dan pilih MCB yang sesuai.', hint: 'I = P / V. Pilih MCB standar di atas arus beban.' },
        { t: 'Jelaskan fungsi motor listrik, transformator, kontaktor, dan thermal overload relay.', hint: 'Lihat materi Peralatan Mesin Listrik.' },
        { t: 'Sebuah transformator mengubah 220 V menjadi 12 V. Jika lilitan primer 1.100, berapa lilitan sekunder? Tergolong step-up atau step-down?', hint: 'Vp / Vs = Np / Ns.' }
      ]
    }
  ]
});
