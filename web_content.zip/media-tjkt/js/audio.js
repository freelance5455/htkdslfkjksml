/* Audio: musik latar dan efek suara dibuat langsung dengan Web Audio (tanpa file mp3). */
const Snd = (function () {
  'use strict';
  let ctx = null, master = null, music = null, sfx = null, lp = null;
  let timer = null, step = 0, nextT = 0;
  let musicOn = true, sfxOn = true, vol = 0.45, started = false;

  const BPM = 100, SIX = 60 / BPM / 4;
  const mf = m => 440 * Math.pow(2, (m - 69) / 12);
  const PROG = [
    { b: 45, pad: [57, 60, 64], arp: [69, 72, 76] },   // Am
    { b: 41, pad: [53, 57, 60], arp: [65, 69, 72] },   // F
    { b: 48, pad: [55, 60, 64], arp: [67, 72, 76] },   // C
    { b: 43, pad: [55, 59, 62], arp: [67, 71, 74] }    // G
  ];
  const ARP = [0, 2, 1, 2, 0, 2, 1, 2, 0, 2, 1, 2, 0, 1, 2, 1];

  function init() {
    if (ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    ctx = new AC();
    master = ctx.createGain(); master.gain.value = 1; master.connect(ctx.destination);
    music = ctx.createGain(); music.gain.value = vol * 0.5;
    lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 1800; lp.Q.value = 2;
    music.connect(lp); lp.connect(master);
    sfx = ctx.createGain(); sfx.gain.value = 0.5; sfx.connect(master);
  }

  function tone(type, freq, t, dur, gain, dest, attack, glideTo) {
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t);
    if (glideTo) o.frequency.exponentialRampToValueAtTime(glideTo, t + dur);
    const a = attack || 0.005;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(dest);
    o.start(t); o.stop(t + dur + 0.05);
  }

  function noise(t, dur, gain, dest) {
    const n = Math.floor(ctx.sampleRate * dur);
    const buf = ctx.createBuffer(1, n, ctx.sampleRate), d = buf.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    const s = ctx.createBufferSource(); s.buffer = buf;
    const hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 7000;
    const g = ctx.createGain();
    g.gain.setValueAtTime(gain, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(hp); hp.connect(g); g.connect(dest); s.start(t);
  }

  function schedule(s, t) {
    const bar = Math.floor(s / 16) % 4, st = s % 16, ch = PROG[bar];
    if (st === 0) {
      ch.pad.forEach(m => { tone('triangle', mf(m), t, SIX * 16, 0.22, music, 0.5); });
    }
    if (st === 0 || st === 6 || st === 8 || st === 14) tone('sawtooth', mf(ch.b), t, SIX * 2.4, 0.5, music, 0.01);
    tone('square', mf(ch.arp[ARP[st]]), t, SIX * 1.5, 0.16, music, 0.005);
    if (st % 4 === 0) tone('sine', 120, t, 0.18, 0.9, music, 0.002, 42);
    if (st % 4 === 2) noise(t, 0.05, 0.25, music);
    // lead sederhana tiap 2 bar
    if (Math.floor(s / 16) % 2 === 1 && (st === 0 || st === 6 || st === 10)) {
      tone('triangle', mf(ch.arp[2] + 12), t, SIX * 4, 0.2, music, 0.02);
    }
  }

  function tick() {
    if (!ctx) return;
    while (nextT < ctx.currentTime + 0.25) {
      schedule(step, nextT);
      nextT += SIX; step++;
    }
  }

  function startMusic() {
    if (!ctx || !musicOn || timer) return;
    if (ctx.state === 'suspended') ctx.resume();
    nextT = ctx.currentTime + 0.08;
    timer = setInterval(tick, 60);
  }
  function stopMusic() { if (timer) { clearInterval(timer); timer = null; } }

  function play(name) {
    if (!ctx || !sfxOn) return;
    if (ctx.state === 'suspended') ctx.resume();
    const t = ctx.currentTime + 0.01;
    switch (name) {
      case 'click': tone('square', 880, t, 0.06, 0.25, sfx, 0.003, 1320); break;
      case 'nav': tone('sine', 400, t, 0.18, 0.3, sfx, 0.01, 900); break;
      case 'ok': tone('triangle', 660, t, 0.14, 0.45, sfx); tone('triangle', 990, t + 0.1, 0.22, 0.45, sfx); break;
      case 'bad': tone('sawtooth', 220, t, 0.28, 0.35, sfx, 0.005, 110); break;
      case 'win': [523, 659, 784, 1047].forEach((f, i) => tone('triangle', f, t + i * 0.11, 0.3, 0.45, sfx)); break;
      case 'lose': [392, 330, 262].forEach((f, i) => tone('sine', f, t + i * 0.15, 0.3, 0.45, sfx)); break;
      case 'type': tone('square', 1500 + Math.random() * 300, t, 0.025, 0.08, sfx); break;
    }
  }

  function setVol(v) { vol = v; if (music) music.gain.setTargetAtTime(vol * 0.5, ctx.currentTime, 0.05); }
  function setMusic(on) { musicOn = on; if (on) startMusic(); else stopMusic(); }
  function setSfx(on) { sfxOn = on; }

  document.addEventListener('visibilitychange', () => {
    if (!ctx) return;
    if (document.hidden) { stopMusic(); ctx.suspend(); }
    else if (musicOn && started) { ctx.resume(); startMusic(); }
  });

  return {
    start() { init(); started = true; startMusic(); },
    play, setVol, setMusic, setSfx,
    get music() { return musicOn; }, get sfx() { return sfxOn; }
  };
})();
