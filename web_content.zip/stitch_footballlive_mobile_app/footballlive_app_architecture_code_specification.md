# FootballLive - Flutter Mobile App Architecture & Full Technical Specification

## Overview
FootballLive is a production-grade Flutter (Android & iOS) sports live streaming and live score tracking mobile application built with Clean Architecture, Riverpod, API-Football proxying, and secure HLS video playback.

---

## 1. Project Architecture (Clean Architecture + Riverpod)

```
football_live/
├── android/
├── ios/
├── assets/
│   ├── icons/
│   └── images/
├── lib/
│   ├── main.dart
│   ├── app.dart
│   ├── core/
│   │   ├── constants/
│   │   │   ├── api_endpoints.dart
│   │   │   └── app_colors.dart
│   │   ├── theme/
│   │   │   └── app_theme.dart (Material 3 Dark/Light)
│   │   ├── network/
│   │   │   ├── dio_client.dart
│   │   │   └── api_interceptors.dart (Cache & Rate limit control)
│   │   ├── localization/
│   │   │   ├── l10n.dart
│   │   │   ├── app_en.arb
│   │   │   └── app_bn.arb (বাংলা ও ইংরেজি সাপোর্ট)
│   │   └── utils/
│   │       ├── date_formatter.dart
│   │       └── signed_url_helper.dart
│   ├── data/
│   │   ├── models/
│   │   │   ├── match_model.dart
│   │   │   ├── league_model.dart
│   │   │   ├── standings_model.dart
│   │   │   ├── stats_model.dart
│   │   │   └── stream_token_model.dart
│   │   └── repositories/
│   │       ├── match_repository_impl.dart
│   │       └── auth_repository_impl.dart
│   └── features/
│       ├── home/
│       │   ├── presentation/
│       │   │   ├── controllers/matches_provider.dart
│       │   │   └── screens/home_screen.dart
│       ├── match_detail/
│       │   ├── presentation/
│       │   │   ├── controllers/live_stream_controller.dart
│       │   │   ├── widgets/hls_video_player_widget.dart
│       │   │   ├── widgets/timeline_tab_view.dart
│       │   │   ├── widgets/match_stats_tab_view.dart
│       │   │   └── screens/match_detail_screen.dart
│       ├── standings/
│       │   ├── presentation/
│       │   │   └── screens/standings_screen.dart
│       ├── favorites/
│       │   └── screens/favorites_screen.dart
│       └── auth/
│           ├── presentation/
│           │   ├── controllers/auth_provider.dart
│           │   └── screens/login_screen.dart
```

---

## 2. Dependencies (`pubspec.yaml`)

```yaml
name: football_live
description: "Live Football Scores & HLS Stream Player in Flutter"
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.2.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  flutter_localizations:
    sdk: flutter
  intl: ^0.19.0
  
  # State Management & DI
  flutter_riverpod: ^2.5.1
  riverpod_annotation: ^2.3.5

  # Networking & Caching
  dio: ^5.4.3
  dio_cache_interceptor: ^3.5.0
  web_socket_channel: ^2.4.5

  # Video Streaming (HLS & Quality Selector)
  video_player: ^2.8.6
  chewie: ^1.8.1
  wakelock_plus: ^1.2.2

  # Firebase Suite
  firebase_core: ^2.31.0
  firebase_auth: ^4.19.5
  firebase_messaging: ^14.9.2
  google_sign_in: ^6.2.1

  # UI Polish & Animation
  cached_network_image: ^3.3.1
  shimmer: ^3.0.0
  flutter_svg: ^2.0.10
  google_fonts: ^6.2.1

dev_dependencies:
  flutter_test:
    sdk: flutter
  build_runner: ^2.4.9
  freezed: ^2.5.2
  freezed_annotation: ^2.4.1
  json_serializable: ^6.8.0
```

---

## 3. Video Player Implementation (Chewie + HLS + Dynamic Backend Stream API)

```dart
// lib/features/match_detail/presentation/widgets/hls_video_player_widget.dart
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';

class HlsVideoPlayerWidget extends StatefulWidget {
  final String streamApiEndpoint;
  final String matchId;

  const HlsVideoPlayerWidget({
    super.key,
    required this.streamApiEndpoint,
    required this.matchId,
  });

  @override
  State<HlsVideoPlayerWidget> createState() => _HlsVideoPlayerWidgetState();
}

class _HlsVideoPlayerWidgetState extends State<HlsVideoPlayerWidget> {
  VideoPlayerController? _videoPlayerController;
  ChewieController? _chewieController;
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _fetchStreamAndInitialize();
  }

  Future<void> _fetchStreamAndInitialize() async {
    try {
      // 1. Fetch authorized HLS URL from secure backend proxy
      final secureStreamUrl = await ApiService.fetchSignedStreamUrl(widget.matchId);
      
      if (secureStreamUrl == null || secureStreamUrl.isEmpty) {
        setState(() {
          _isLoading = false;
          _errorMessage = "এই ম্যাচের লাইভ ভিডিও উপলব্ধ নয়";
        });
        return;
      }

      // 2. Initialize video_player with HLS stream
      _videoPlayerController = VideoPlayerController.networkUrl(
        Uri.parse(secureStreamUrl),
        formatHint: VideoFormat.hls,
      );

      await _videoPlayerController!.initialize();

      // 3. Configure Chewie with fullscreen, landscape, and controls
      _chewieController = ChewieController(
        videoPlayerController: _videoPlayerController!,
        autoPlay: true,
        looping: false,
        aspectRatio: 16 / 9,
        allowFullScreen: true,
        allowPlaybackSpeedChanging: false,
        deviceOrientationsOnEnterFullScreen: [
          DeviceOrientation.landscapeLeft,
          DeviceOrientation.landscapeRight,
        ],
        deviceOrientationsAfterFullScreen: [
          DeviceOrientation.portraitUp,
        ],
        errorBuilder: (context, errorMessage) {
          return Center(
            child: Text(
              'ভিডিও লোড করা যায়নি: $errorMessage',
              style: const TextStyle(color: Colors.white70),
            ),
          );
        },
      );

      setState(() => _isLoading = false);
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMessage = "লাইভ স্ট্রিম সংযোগ করা সম্ভব হয়নি";
      });
    }
  }

  @override
  void dispose() {
    _videoPlayerController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Container(
        height: 220,
        color: const Color(0xFF0E131F),
        child: const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(color: Color(0xFF00FF66)),
              SizedBox(height: 12),
              Text('স্ট্রিম লোড হচ্ছে...', style: TextStyle(color: Colors.white70, fontSize: 13)),
            ],
          ),
        ),
      );
    }

    if (_errorMessage != null) {
      return Container(
        height: 200,
        decoration: BoxDecoration(
          color: const Color(0xFF161F30),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white10),
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.videocam_off_outlined, color: Colors.orangeAccent, size: 40),
              const SizedBox(height: 10),
              Text(
                _errorMessage!,
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 4),
              const Text(
                'নিচে লাইভ কমেন্ট্রি ও স্কোর ট্র্যাক করুন',
                style: TextStyle(color: Colors.white54, fontSize: 12),
              ),
            ],
          ),
        ),
      );
    }

    return AspectRatio(
      aspectRatio: 16 / 9,
      child: Chewie(controller: _chewieController!),
    );
  }
}
```

---

## 4. Node.js Backend Proxy (Express + API-Football + Redis/In-Memory Cache)

```javascript
// server/index.js
const express = require('express');
const axios = require('axios');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = process.env.PORT || 4000;
const API_FOOTBALL_KEY = process.env.API_FOOTBALL_KEY;
const STREAM_SECRET = process.env.STREAM_SECRET || 'secret-jwt-key';

// Cache in-memory
const cache = new Map();

// 1. Live fixtures proxy with 20s TTL cache
app.get('/api/matches/live', async (req, res) => {
  const cacheKey = 'matches_live';
  const now = Date.now();
  if (cache.has(cacheKey) && (now - cache.get(cacheKey).time < 20000)) {
    return res.json(cache.get(cacheKey).data);
  }

  try {
    const response = await axios.get('https://v3.football.api-sports.io/fixtures?live=all', {
      headers: { 'x-apisports-key': API_FOOTBALL_KEY }
    });
    cache.set(cacheKey, { time: now, data: response.data.response });
    res.json(response.data.response);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch live matches' });
  }
});

// 2. Token-authorized HLS stream endpoint
app.get('/api/stream/:matchId', (req, res) => {
  const { matchId } = req.params;
  const userToken = req.headers['authorization'];

  if (!userToken) return res.status(401).json({ error: 'Unauthorized' });

  // Generate signed HLS stream link (with 2-hour expiration)
  const streamToken = jwt.sign({ matchId, access: true }, STREAM_SECRET, { expiresIn: '2h' });
  const signedStreamUrl = `https://stream-cdn.footballlive.com/hls/${matchId}/master.m3u8?token=${streamToken}`;

  res.json({
    available: true,
    hlsUrl: signedStreamUrl,
    qualities: ['1080p', '720p', '480p', 'Auto']
  });
});

app.listen(PORT, () => console.log(`FootballLive backend listening on ${PORT}`));
```

---

## 5. FCM Push Notifications Setup
- Configured in `core/services/notification_service.dart`.
- Listens to Firebase Cloud Messaging topic for followed teams: `teams_{teamId}_goals`.
- Shows heads-up notifications with team crests and goal scorers.
