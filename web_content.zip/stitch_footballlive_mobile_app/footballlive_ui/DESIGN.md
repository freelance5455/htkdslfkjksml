---
name: FootballLive UI
colors:
  surface: '#051424'
  surface-dim: '#051424'
  surface-bright: '#2c3a4c'
  surface-container-lowest: '#010f1f'
  surface-container-low: '#0d1c2d'
  surface-container: '#122131'
  surface-container-high: '#1c2b3c'
  surface-container-highest: '#273647'
  on-surface: '#d4e4fa'
  on-surface-variant: '#b9ccb5'
  inverse-surface: '#d4e4fa'
  inverse-on-surface: '#233143'
  outline: '#849581'
  outline-variant: '#3b4b3a'
  surface-tint: '#00e55b'
  primary: '#edffe8'
  on-primary: '#003911'
  primary-container: '#00ff66'
  on-primary-container: '#007128'
  inverse-primary: '#006e27'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#f6faff'
  on-tertiary: '#00354a'
  tertiary-container: '#b8e3ff'
  on-tertiary-container: '#00688e'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6bff83'
  primary-fixed-dim: '#00e55b'
  on-primary-fixed: '#002107'
  on-primary-fixed-variant: '#00531b'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#c4e7ff'
  tertiary-fixed-dim: '#7bd0ff'
  on-tertiary-fixed: '#001e2c'
  on-tertiary-fixed-variant: '#004c69'
  background: '#051424'
  on-background: '#d4e4fa'
  surface-variant: '#273647'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
  display-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-lg:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  title-md:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  body-lg:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
  label-md:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
  score-display:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 52px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.25rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system embodies the high-octane, precision-driven world of modern football telemetry and live broadcasting. It delivers an immersive, dark-room stadium atmosphere directly to mobile devices. Designed for football enthusiasts, analytical tacticians, and live bettors who demand instantaneous updates, the interface creates an emotional state of anticipation, hyper-focus, and kinetic energy.

The aesthetic fuses **Modern Dark Sports Telemetry** with **Tactile Glassmorphism and Neon Accents**:
- **Stadium Immersion:** Deep pitch-midnight charcoal backgrounds reduce eye strain during evening matches and accentuate bright streaming video content and field positions.
- **Electric Telemetry:** High-visibility electric lime green accents are used strategically for active events, live pulses, match timers, and critical callouts, echoing broadcast scorebug graphics and tactical heads-up displays.
- **Data Clarity:** Dense match statistics, timeline ribbons, and lineup matrices are balanced with crisp structure, ensuring instant legibility in bilingual environments (English and Bengali).

## Colors

The color palette is calibrated for high dynamic contrast in dark mode, optimizing visual hierarchy during live-action streaming and tracking:

- **Primary (`#00FF66` - Electric Stadium Lime):** Reserved exclusively for live match states, active time ticks, possession indicators, high-priority interactive CTAs, and active navigation nodes.
- **Secondary (`#10B981` - Pitch Emerald):** Used for supporting affirmative actions, successful pass metrics, confirmed goals, and secondary active pills.
- **Tertiary (`#38BDF8` - Broadcast Cyan):** Dedicated to technical telemetry, VAR reviews, tactical substitution indicators, and secondary data visualizations.
- **Neutral (`#94A3B8` - Slate Gray):** Governs structural borders, deactivated icons, and secondary informational copy.

### Tonal Foundations & Surfaces
- **Canvas Base:** `#0A0E17` (Deep Void Pitch)
- **Surface Container Low:** `#0E131F` (Midnight Slate Base for background panels)
- **Surface Container:** `#161F30` (Tactical Elevation for scorecards and list cells)
- **Surface Container High:** `#1E293B` (Interactive sheets, dropdowns, and overlays)
- **Critical & Hazard:** `#EF4444` (Direct Red Cards, missed penalties, live hazards)
- **Caution:** `#F59E0B` (Yellow Cards, stoppage time alerts)

## Typography

The type system pairs the technical, broadcast-grade geometry of **Space Grotesk** with the human-centric, fluid legibility of **Manrope**.

- **Display & Numerical Telemetry (Space Grotesk):** Provides athletic authority for live scores, match timers (e.g., `87:14`), stats bars, and scoreboard counters. Tabular numeric figures are mandatory for all timers and scores to avoid layout shifting during live ticks.
- **Match Tracking & Editorial (Manrope):** Delivers clean readability for player profiles, live minute-by-minute text commentary, match previews, and settings.
- **Bilingual Bengali Adaptation:** Bengali glyphs render alongside English using Manrope-compatible vertical baselines and weight mappings. For Bengali headings and live commentary, line heights are increased by `15%` to prevent conjunct clipping, while keeping font weights matched at 600 (Semibold) and 400 (Regular).

## Layout & Spacing

The layout model is built around a mobile-first, 4-column layout on phones scaling to an 8-column layout on tablets, optimized for one-thumb navigational zones and live stream PIP views.

### Structure & Rhythms
- **Canvas Margins:** Mobile uses `margin-mobile` (16px) to maximize horizontal real estate for timeline heatmaps and stats tables. Tablet interfaces use `margin` (20px).
- **Match Grids:** A 4-column fluid layout with an 8px base module ensures elements stack predictably. Scorecards conform to horizontal full-width blocks or split split-column team comparisons.
- **Safe Areas & Streaming Overlays:** Top safe area factors in persistent match pin bars (`44px` top offset). Bottom navigation features an anchored thumb-reach layout (`64px` height plus device safe area insert).
- **Reflow Logic:** On landscape or tablet screens, video streaming and tactical telemetry shift from stacked vertical panes into a 60/40 side-by-side split screen.

## Elevation & Depth

Visual hierarchy uses a refined **Material 3 Tonal Elevation** combined with **Ambient Neon Luminescence**, avoiding heavy opaque drop shadows in favor of luminous depth:

- **Level 0 (Pitch Foundation):** Pure background `#0A0E17`. Elements here feel recessed (e.g., empty field pitch diagrams, scrollable commentary channels).
- **Level 1 (Card Baseline - Surface Low):** `#0E131F` background with a subtle `1px` inner stroke of `rgba(255, 255, 255, 0.05)`. Used for pre-match listings, league table rows, and article cards.
- **Level 2 (Active Scorecards & Match Hub - Surface Medium):** `#161F30` with a sharp `1px` border of `rgba(255, 255, 255, 0.08)`. Features an ambient ground reflection shadow: `0px 8px 24px -4px rgba(0, 0, 0, 0.6)`.
- **Level 3 (Live Telemetry & Floating Bars - Surface High):** `#1E293B` with glassmorphic backdrop-filter (`blur(16px)` at `85%` opacity). Borders feature an electric tint: `1px solid rgba(0, 255, 102, 0.2)`.
- **Live Match Halo:** Active live badges and in-play score blocks emit an ambient neon blur: `0px 0px 16px rgba(0, 255, 102, 0.35)`.

## Shapes

The design system employs a **Rounded** profile (`roundedness: 2` / base `8px`) with specific performance-driven shape expressions:

- **Cards & Scoreboards:** `8px` (`0.5rem`) for compact mobile cards, creating a disciplined, technical silhouette reminiscent of high-end sports instruments.
- **Pills & Status Indicators:** Fully rounded (`9999px`) for `LIVE` status flags, period tags (e.g., `HT`, `ET`, `90+4'`), and floating action chips.
- **Team Shields & Badges:** Squircle containers (`8px` radius) with `1px` high-contrast outer rims ensure club crests stand out against dark panels.
- **Interactive Buttons:** `8px` radius maintains cohesion with cards, avoiding overly bubbly forms to preserve an authoritative broadcast aesthetic.

## Components

### 1. Scoreboards & Match Tracker Cards
- **Structure:** Anchored container in `#161F30` with `1px` border `rgba(255, 255, 255, 0.08)`.
- **Layout:** Horizontal split. Home Team (Left), Match Score & Time (Center), Away Team (Right).
- **Score Counters:** Space Grotesk `score-display` (`48px`). The leading team's score is rendered in `#FFFFFF`, the trailing team in `#64748B`. In a draw, both display `#E2E8F0`.
- **Time/Status Node:** Centered directly below the score. Live matches display in electric lime `#00FF66` with a minute tick mark (e.g., `64'`).

### 2. Live Badges & Pulse Animations
- **Style:** Compact pill badge (`roundedness: 3`, height `20px`, padding `0 8px`).
- **Visuals:** Surface `#00FF66` with `10%` alpha background and `#00FF66` solid border. Text is `label-sm` in `#00FF66`.
- **Pulse Dot:** `6px` circular beacon placed before the text. Uses a dual-ring animation: a solid `#00FF66` core surrounded by an expanding ripple ring animating from `1.0` to `2.2` scale with opacity fading from `0.8` to `0.0` over `1.5s` linear loop.

### 3. Match Status Indicators & Pitch Timeline
- **Timeline Strip:** `4px` continuous track in `#1E293B` representing 90 minutes. 
- **Event Markers:** Yellow cards (`#F59E0B`), red cards (`#EF4444`), goals (`#00FF66` with soccer icon), and VAR checks (`#38BDF8`) pinned dynamically along the progress line.
- **Active Progress:** Filled portion of the timeline uses a gradient from `#10B981` to `#00FF66`.

### 4. Interactive Tabs & Filters
- **Pill Segmented Controls:** Surface `#0E131F`. Inactive pills feature transparent backgrounds with `#94A3B8` label text.
- **Selected Tab:** Elevated background `#1E293B` with high-contrast text `#FFFFFF` and a glowing bottom underline in `#00FF66` (`2px` height, rounded edges).

### 5. Buttons & Actions
- **Primary CTA:** Background `#00FF66`, text `#0A0E17` (Space Grotesk `label-lg`, weight 700). Hover/Active state applies brightness boost (`110%`) and subtle neon shadow.
- **Secondary / Telemetry Action:** Background `#161F30`, border `1px solid rgba(255, 255, 255, 0.1)`, text `#FFFFFF`.
- **Stream Overlay Icon Buttons:** Circular (`40px`), background `rgba(14, 19, 31, 0.7)` with `backdrop-filter: blur(8px)`. Icon in `#00FF66`.

### 6. Input Fields & Search Bars
- **Surface:** `#0E131F` background, `1px` border `#1E293B`, rounded `8px`.
- **Typography:** Manrope `body-md` in `#FFFFFF`. Placeholder in `#64748B`.
- **Focus State:** Border transitions to `#00FF66` with a soft outer ring `0 0 0 2px rgba(0, 255, 102, 0.2)`.

### 7. Bilingual Match Commentary Feed
- **Cell Structure:** Alternating subtle dark rows. Timestamp aligned to the left in Space Grotesk `label-md` (`#00FF66`).
- **Body Copy:** Manrope `body-md` in English or Bengali. Key player names, card events, and goal notifications are highlighted in bold `#FFFFFF` or contextual event colors.