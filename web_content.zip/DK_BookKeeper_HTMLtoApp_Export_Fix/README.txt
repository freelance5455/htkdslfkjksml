DK BookKeeper — HTML-to-App export compatibility patch

This package is intended for the existing HTML to App builder. It contains an updated index.html only; it does not require Android Studio or Kotlin integration.

What changed:
- Keeps the existing voucher, account-search, voice and backup/restore code unchanged.
- Excel export first tries a real Android Web Share file handoff (when supported by the app WebView).
- If file sharing is unavailable, it falls back to a standard Blob download.
- Status messages no longer claim that a file was saved merely because export was requested.

How to use:
1. Open your existing DK BookKeeper project in HTML to App.
2. In the Bundled content/start page step, replace the existing index.html with this package's index.html (or replace the current bundled source file with it).
3. Keep your existing Package ID. Increase version code by one if the builder requires it.
4. Build/rebuild the APK and install/update it.
5. Test with one small voucher export. If Android shows a share sheet, choose Save to device / Files and select Downloads.

Important limitation:
HTML alone cannot force a WebView to save files if the HTML-to-App wrapper blocks downloads and does not expose Android's file chooser/share interface. This patch uses the browser-level share API if available, then normal download fallback. If neither is supported by this wrapper, a wrapper setting or builder update is required; no HTML-only change can guarantee Downloads access.

The Excel engine remains loaded from the existing SheetJS CDN, so internet access is required unless the builder bundles that library locally.
