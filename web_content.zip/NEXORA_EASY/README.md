# NEXORA AI - Versão Fácil (Auto-atualizável)

Versão simples, sem Cloudflare, pronta para usar em 2 minutos.

## Como publicar (super fácil)

### Opção 1 - Netlify Drop (recomendado)

1. Entre em: **https://app.netlify.com/drop**
2. Arraste a pasta **NEXORA_EASY** inteira para a área de drop
3. Pronto! Você recebe um link (ex: `https://algo-aleatorio.netlify.app`)

Pode usar no celular e no computador.

### Opção 2 - Abrir direto no celular

1. Extraia a pasta
2. Abra o arquivo `index.html` no Chrome ou Firefox

(Algumas funções de IA precisam de internet)

---

## Como pegar a chave gratuita da Groq (IA real)

1. Entre em **https://console.groq.com**
2. Faça login com Google (ou crie conta)
3. No menu lateral clique em **API Keys**
4. Clique em **Create API Key**
5. Copie a chave (começa com `gsk_...`)
6. Cole na tela inicial da NEXORA

É grátis e não pede cartão.

---

## Sistema de Auto-Atualização

Você pode falar com a NEXORA:

> "NEXORA, adicione a capacidade de eu te enviar fotos"

Ela vai responder e mostrar um botão **Atualizar agora**.

Quando você clicar, a função nova é adicionada (aparece o botão de foto, por exemplo).

Outros exemplos que funcionam:

- "Adicione um botão de gerar código Minecraft"
- "Quero que você sempre lembre que meu nome é João"
- "Adicione instrução permanente: responda de forma divertida"

As atualizações ficam salvas no seu dispositivo.

---

## O que tem nesta versão

- Interface dark futurista (igual a outra)
- Chat com IA real (Groq)
- Memória local (conversas + fatos)
- Geração de arquivos: TXT, HTML, CSS, JS, JSON, ZIP, MCADDON
- Sistema de auto-atualização
- Funciona no Android
- Zero configuração de servidor

---

## Limitações

- A memória fica só no dispositivo (não sincroniza entre celular e PC)
- Depende da chave gratuita da Groq (limites diários generosos)
- Atualizações são limitadas ao que o sistema consegue aplicar dinamicamente

---

Feito para você conseguir usar sem dor de cabeça.
