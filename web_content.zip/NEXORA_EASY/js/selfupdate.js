/**
 * Sistema de Auto-Atualização da NEXORA
 * Detecta [UPDATE] nas respostas e aplica features
 */

const SelfUpdate = {
  parseUpdateBlock(text) {
    const match = text.match(/\[UPDATE\]([\s\S]*?)\[\/UPDATE\]/i);
    if (!match) return null;

    const block = match[1];
    const result = { raw: block };

    const tipo = block.match(/tipo:\s*(.+)/i);
    const nome = block.match(/nome:\s*(.+)/i);
    const descricao = block.match(/descricao:\s*(.+)/i);
    const codigo = block.match(/codigo:\s*(.+)/i);

    result.tipo = tipo ? tipo[1].trim() : 'feature';
    result.nome = nome ? nome[1].trim() : 'atualizacao';
    result.descricao = descricao ? descricao[1].trim() : 'Nova funcionalidade';
    result.codigo = codigo ? codigo[1].trim() : '';

    return result;
  },

  applyUpdate(update) {
    const features = Storage.getFeatures();

    if (!update || !update.codigo) return false;

    const code = update.codigo.toLowerCase();

    // acceptImages=true
    if (code.includes('acceptimages=true') || code.includes('acceptimages: true')) {
      features.acceptImages = true;
      features.systemAdditions = features.systemAdditions || [];
      if (!features.systemAdditions.includes('Usuário pode enviar fotos')) {
        features.systemAdditions.push('Usuário pode enviar fotos');
      }
    }

    // systemAdd:texto
    if (code.startsWith('systemadd:')) {
      const text = update.codigo.slice(10).trim();
      features.systemAdditions = features.systemAdditions || [];
      features.systemAdditions.push(text);
    }

    // addButton:Nome|acao
    if (code.startsWith('addbutton:')) {
      const parts = update.codigo.slice(10).split('|');
      const btnName = parts[0]?.trim() || 'Novo Botão';
      const action = parts[1]?.trim() || 'custom';
      features.customButtons = features.customButtons || [];
      features.customButtons.push({ name: btnName, action });
    }

    // custom
    if (code.startsWith('custom:')) {
      features.systemAdditions = features.systemAdditions || [];
      features.systemAdditions.push(update.descricao || update.codigo);
    }

    // Marca a feature
    features.list = features.list || [];
    features.list.push({
      nome: update.nome,
      descricao: update.descricao,
      codigo: update.codigo,
      appliedAt: new Date().toISOString()
    });

    features.version = (features.version || 1) + 1;
    Storage.saveFeatures(features);
    Storage.setPendingUpdate(null);

    return true;
  },

  // Aplica visualmente as features ativas
  applyUIFeatures() {
    const features = Storage.getFeatures();
    const container = document.getElementById('extra-actions');
    if (!container) return;

    container.innerHTML = '';

    // Botão de foto
    if (features.acceptImages) {
      const label = document.createElement('label');
      label.className = 'btn-secondary small';
      label.style.cursor = 'pointer';
      label.innerHTML = '📷 Enviar Foto';
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.hidden = true;
      input.onchange = (e) => {
        const file = e.target.files[0];
        if (file) handleImageUpload(file);
      };
      label.appendChild(input);
      container.appendChild(label);
    }

    // Botões customizados
    (features.customButtons || []).forEach(btn => {
      const b = document.createElement('button');
      b.className = 'btn-secondary small';
      b.textContent = btn.name;
      b.onclick = () => {
        if (btn.action === 'minecraft') {
          document.getElementById('message-input').value = 'Quero criar um addon de Minecraft Bedrock. Me ajude passo a passo.';
        } else {
          document.getElementById('message-input').value = `Execute a ação: ${btn.name}`;
        }
        document.getElementById('message-input').focus();
      };
      container.appendChild(b);
    });
  },

  renderFeaturesList() {
    const list = document.getElementById('features-list');
    if (!list) return;

    const features = Storage.getFeatures();
    const items = features.list || [];

    if (items.length === 0) {
      list.innerHTML = '<p style="color:var(--text-muted);font-size:0.9rem">Nenhuma atualização aplicada ainda.<br>Peça para a NEXORA se modificar no chat!</p>';
      return;
    }

    list.innerHTML = items.map(f => `
      <div class="feature-item">
        <div>
          <strong>${escapeHtml(f.nome)}</strong><br>
          <span style="font-size:0.8rem;color:var(--text-muted)">${escapeHtml(f.descricao)}</span>
        </div>
        <span>Ativo</span>
      </div>
    `).join('');
  }
};

function escapeHtml(t) {
  if (!t) return '';
  return t.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// Função global para upload de imagem
function handleImageUpload(file) {
  const reader = new FileReader();
  reader.onload = (e) => {
    const base64 = e.target.result;
    // Mostra a imagem no chat
    const messagesEl = document.getElementById('messages');
    const div = document.createElement('div');
    div.className = 'message user';
    div.innerHTML = `<img src="${base64}" class="image-preview" alt="Foto enviada"><br><small>Foto enviada</small>`;
    messagesEl.appendChild(div);
    messagesEl.scrollTop = messagesEl.scrollHeight;

    // Envia mensagem automática
    document.getElementById('message-input').value = '[O usuário enviou uma foto] Por favor, descreva o que você vê e ajude com o que for possível.';
    // O usuário pode editar e enviar
  };
  reader.readAsDataURL(file);
}
