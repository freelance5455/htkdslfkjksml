/**
 * NEXORA AI - Comunicação com Groq (ou modo demo)
 */

const AI = {
  async chat(messages, config) {
    if (config.demoMode || !config.apiKey) {
      return this.demoReply(messages);
    }

    const systemPrompt = this.buildSystemPrompt(config);

    const body = {
      model: config.model || 'llama-3.3-70b-versatile',
      messages: [
        { role: 'system', content: systemPrompt },
        ...messages
      ],
      temperature: 0.7,
      max_tokens: 2048
    };

    try {
      const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${config.apiKey}`
        },
        body: JSON.stringify(body)
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error?.message || `Erro ${res.status}`);
      }

      const data = await res.json();
      return data.choices?.[0]?.message?.content || 'Não consegui gerar resposta.';
    } catch (err) {
      console.error(err);
      throw err;
    }
  },

  buildSystemPrompt(config) {
    const features = Storage.getFeatures();
    let extra = '';

    if (features.systemAdditions && features.systemAdditions.length) {
      extra = '\n\n### Instruções adicionais da NEXORA (atualizações):\n' +
        features.systemAdditions.map(s => '- ' + s).join('\n');
    }

    if (features.acceptImages) {
      extra += '\n- Você pode receber e analisar fotos enviadas pelo usuário.';
    }

    const name = config.aiName || 'NEXORA';
    const custom = config.customInstructions || '';

    return `Você é a ${name}, uma inteligência artificial avançada, útil, criativa e profissional.
Responda sempre em português brasileiro.
Você ajuda com programação (HTML, CSS, JavaScript, Python), criação de jogos, addons de Minecraft Bedrock, análise de código e muito mais.
Quando o usuário pedir para você se atualizar ou adicionar uma funcionalidade nova (ex: "adicione botão de foto", "quero que você lembre X"), responda de forma clara e no FINAL da sua mensagem coloque exatamente este bloco:

[UPDATE]
tipo: feature
nome: nome_curto_da_feature
descricao: descrição do que foi adicionado
codigo: acceptImages=true   (ou outro código de feature)
[/UPDATE]

Tipos possíveis de codigo:
- acceptImages=true
- addButton:Nome do Botão|acao
- systemAdd:texto da instrução permanente
- custom:qualquer outra coisa

Só use o bloco [UPDATE] quando o usuário realmente pedir uma mudança em você mesma.
${custom ? '\nInstruções personalizadas do usuário:\n' + custom : ''}
${extra}`;
  },

  demoReply(messages) {
    const last = messages[messages.length - 1]?.content?.toLowerCase() || '';
    
    if (last.includes('atualiz') || last.includes('adicion') || last.includes('botão') || last.includes('foto')) {
      return `Entendi! Você quer que eu me atualize.

Posso adicionar a capacidade de receber fotos.

[UPDATE]
tipo: feature
nome: receber_fotos
descricao: Agora você pode me enviar fotos pelo botão que vai aparecer
codigo: acceptImages=true
[/UPDATE]

Clique no botão "Atualizar agora" que vai aparecer abaixo para aplicar.`;
    }

    if (last.includes('minecraft') || last.includes('addon') || last.includes('mcaddon')) {
      return `Posso te ajudar a criar addons de Minecraft Bedrock!

Me diga o que você quer (ex: um item novo, um mob, uma estrutura) e eu monto o conteúdo do MCADDON para você baixar.

Use o botão **Gerar Arquivo** → escolha MCADDON e cole a estrutura que eu te passar.`;
    }

    if (last.includes('olá') || last.includes('oi') || last.includes('eae')) {
      return `Olá! Eu sou a NEXORA AI (modo demonstração).

Estou funcionando sem chave de API no momento. Para ter respostas reais e inteligentes, coloque uma chave gratuita da Groq nas configurações.

Enquanto isso, posso te mostrar como funciona o sistema de atualização. Experimente falar:
"NEXORA, adicione a capacidade de eu te enviar fotos"`;
    }

    return `Estou em modo demonstração (sem chave de API real).

Para eu responder de verdade:
1. Entre em console.groq.com
2. Crie uma chave gratuita
3. Cole em Configuração

Enquanto isso, experimente pedir para eu me atualizar, por exemplo:
"Adicione um botão de gerar código Minecraft"`;
  }
};
