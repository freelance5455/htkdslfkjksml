/**
 * NEXORA AI - App principal (versão fácil + auto-update)
 */

let currentConvId = null;
let isSending = false;
let pendingUpdate = null;

document.addEventListener('DOMContentLoaded', () => {
  const config = Storage.getConfig();

  if (config.apiKey || config.demoMode) {
    showApp();
  }

  // Setup
  document.getElementById('btn-save-key').onclick = () => {
    const key = document.getElementById('api-key-input').value.trim();
    if (!key) return alert('Cole a chave da Groq');
    const cfg = Storage.getConfig();
    cfg.apiKey = key;
    cfg.demoMode = false;
    Storage.saveConfig(cfg);
    showApp();
  };

  document.getElementById('btn-skip-demo').onclick = () => {
    const cfg = Storage.getConfig();
    cfg.demoMode = true;
    Storage.saveConfig(cfg);
    showApp();
  };

  // UI
  document.getElementById('btn-new-chat').onclick = newChat;
  document.getElementById('btn-new-chat-mobile')?.addEventListener('click', newChat);
  document.getElementById('btn-send').onclick = sendMessage;
  document.getElementById('message-input').addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });
  document.getElementById('btn-menu').onclick = () => {
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('sidebar-overlay').classList.toggle('open');
  };
  document.getElementById('sidebar-overlay').onclick = closeSidebar;

  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.onclick = () => switchView(btn.dataset.view);
  });

  document.getElementById('btn-generate-file').onclick = () => {
    document.getElementById('modal-file').classList.remove('hidden');
  };
  document.getElementById('btn-cancel-file').onclick = () => {
    document.getElementById('modal-file').classList.add('hidden');
  };
  document.getElementById('btn-do-generate').onclick = doGenerateFile;

  document.getElementById('btn-apply-update').onclick = applyPendingUpdate;
  document.getElementById('btn-dismiss-update').onclick = () => {
    document.getElementById('update-banner').classList.add('hidden');
    Storage.setPendingUpdate(null);
    pendingUpdate = null;
  };

  document.getElementById('btn-save-config').onclick = saveConfig;
  document.getElementById('btn-change-key').onclick = () => {
    document.getElementById('app').classList.remove('active');
    document.getElementById('setup-screen').classList.add('active');
  };
  document.getElementById('btn-clear-memory').onclick = () => {
    if (confirm('Apagar todas as memórias?')) {
      Storage.saveMemories([]);
      loadMemory();
    }
  };
  document.getElementById('btn-reset-features').onclick = () => {
    if (confirm('Resetar todas as atualizações da NEXORA?')) {
      Storage.saveFeatures({ acceptImages: false, customButtons: [], systemAdditions: [], list: [], version: 1 });
      SelfUpdate.applyUIFeatures();
      SelfUpdate.renderFeaturesList();
      alert('Atualizações resetadas.');
    }
  };

  // Auto resize
  const ta = document.getElementById('message-input');
  ta.addEventListener('input', () => {
    ta.style.height = 'auto';
    ta.style.height = Math.min(ta.scrollHeight, 120) + 'px';
  });
});

function showApp() {
  document.getElementById('setup-screen').classList.remove('active');
  document.getElementById('app').classList.add('active');
  
  // Carrega config na tela
  const cfg = Storage.getConfig();
  document.getElementById('model-select').value = cfg.model || 'llama-3.3-70b-versatile';
  document.getElementById('ai-name').value = cfg.aiName || 'NEXORA';
  document.getElementById('custom-instructions').value = cfg.customInstructions || '';

  SelfUpdate.applyUIFeatures();
  loadConversations();
  newChat();

  // Verifica se tem update pendente
  const pending = Storage.getPendingUpdate();
  if (pending) {
    pendingUpdate = pending;
    showUpdateBanner(pending);
  }
}

function closeSidebar() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sidebar-overlay').classList.remove('open');
}

function switchView(name) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(`view-${name}`)?.classList.add('active');
  document.querySelector(`.nav-btn[data-view="${name}"]`)?.classList.add('active');
  closeSidebar();

  if (name === 'memory') loadMemory();
  if (name === 'files') loadFiles();
  if (name === 'update') SelfUpdate.renderFeaturesList();
}

function newChat() {
  currentConvId = crypto.randomUUID();
  const convs = Storage.getConversations();
  convs.unshift({
    id: currentConvId,
    title: 'Nova conversa',
    updated_at: new Date().toISOString()
  });
  Storage.saveConversations(convs.slice(0, 50));
  Storage.saveMessages(currentConvId, []);
  
  document.getElementById('messages').innerHTML = `
    <div class="message system">Nova conversa. Como posso ajudar?<br><br>
    <small>Dica: você pode pedir "NEXORA, adicione a capacidade de eu te enviar fotos"</small></div>
  `;
  loadConversations();
  closeSidebar();
  switchView('chat');
}

async function sendMessage() {
  if (isSending) return;
  const input = document.getElementById('message-input');
  const text = input.value.trim();
  if (!text) return;

  isSending = true;
  document.getElementById('btn-send').disabled = true;
  input.value = '';
  input.style.height = 'auto';

  appendMessage('user', text);

  // Salva mensagem
  let messages = Storage.getMessages(currentConvId);
  messages.push({ role: 'user', content: text });
  Storage.saveMessages(currentConvId, messages);

  // Atualiza título se for a primeira
  const convs = Storage.getConversations();
  const conv = convs.find(c => c.id === currentConvId);
  if (conv && conv.title === 'Nova conversa') {
    conv.title = text.slice(0, 40) + (text.length > 40 ? '...' : '');
    conv.updated_at = new Date().toISOString();
    Storage.saveConversations(convs);
    loadConversations();
  }

  const typing = document.createElement('div');
  typing.className = 'typing';
  typing.id = 'typing';
  typing.textContent = 'NEXORA está pensando...';
  document.getElementById('messages').appendChild(typing);
  scrollMessages();

  try {
    const config = Storage.getConfig();
    // Histórico recente
    const history = messages.slice(-10).map(m => ({ role: m.role, content: m.content }));
    
    const reply = await AI.chat(history, config);
    
    document.getElementById('typing')?.remove();
    appendMessage('assistant', reply);

    // Salva resposta
    messages.push({ role: 'assistant', content: reply });
    Storage.saveMessages(currentConvId, messages);

    // Detecta update
    const update = SelfUpdate.parseUpdateBlock(reply);
    if (update) {
      pendingUpdate = update;
      Storage.setPendingUpdate(update);
      showUpdateBanner(update);
    }

    // Heurística de memória
    if (/lembre|guarde|meu nome|eu gosto|prefiro/i.test(text)) {
      Storage.addMemory({
        type: 'fact',
        title: text.slice(0, 60),
        content: text
      });
    }

  } catch (err) {
    document.getElementById('typing')?.remove();
    appendMessage('assistant', 'Erro: ' + err.message + '\n\nVerifique sua chave da API em Configuração.');
  } finally {
    isSending = false;
    document.getElementById('btn-send').disabled = false;
  }
}

function appendMessage(role, content) {
  const div = document.createElement('div');
  div.className = `message ${role}`;
  let html = escapeHtml(content)
    .replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>')
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\n/g, '<br>');
  // Remove o bloco [UPDATE] da visualização limpa
  html = html.replace(/\[UPDATE\][\s\S]*?\[\/UPDATE\]/gi, '<em style="color:var(--purple)">[Proposta de atualização detectada]</em>');
  div.innerHTML = html;
  document.getElementById('messages').appendChild(div);
  scrollMessages();
}

function escapeHtml(t) {
  return t.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function scrollMessages() {
  const el = document.getElementById('messages');
  el.scrollTop = el.scrollHeight;
}

function showUpdateBanner(update) {
  document.getElementById('update-description').textContent = update.descricao || 'Nova funcionalidade disponível';
  document.getElementById('update-banner').classList.remove('hidden');
}

function applyPendingUpdate() {
  if (!pendingUpdate) return;
  const ok = SelfUpdate.applyUpdate(pendingUpdate);
  if (ok) {
    document.getElementById('update-banner').classList.add('hidden');
    SelfUpdate.applyUIFeatures();
    alert('NEXORA atualizada com sucesso!\n\n' + (pendingUpdate.descricao || ''));
    pendingUpdate = null;
  } else {
    alert('Não foi possível aplicar a atualização.');
  }
}

function loadConversations() {
  const list = document.getElementById('conversation-list');
  const convs = Storage.getConversations();
  list.innerHTML = '';
  convs.forEach(c => {
    const el = document.createElement('div');
    el.className = 'conv-item' + (c.id === currentConvId ? ' active' : '');
    el.textContent = c.title;
    el.onclick = () => openConversation(c.id);
    list.appendChild(el);
  });
}

function openConversation(id) {
  currentConvId = id;
  const messages = Storage.getMessages(id);
  document.getElementById('messages').innerHTML = '';
  messages.forEach(m => appendMessage(m.role, m.content));
  loadConversations();
  closeSidebar();
  switchView('chat');
}

function loadMemory() {
  const list = document.getElementById('memory-list');
  const memories = Storage.getMemories();
  if (!memories.length) {
    list.innerHTML = '<div class="empty">Nenhuma memória salva ainda.<br>A NEXORA guarda quando você pede para lembrar.</div>';
    return;
  }
  list.innerHTML = memories.map(m => `
    <div class="card">
      <h4>${escapeHtml(m.title || m.type)}</h4>
      <p>${escapeHtml((m.content || '').slice(0, 180))}</p>
      <div class="meta">${new Date(m.created_at).toLocaleString('pt-BR')}</div>
    </div>
  `).join('');
}

function loadFiles() {
  const list = document.getElementById('file-list');
  const files = Storage.getFiles();
  if (!files.length) {
    list.innerHTML = '<div class="empty">Nenhum arquivo gerado ainda.</div>';
    return;
  }
  list.innerHTML = files.map(f => `
    <div class="card">
      <h4>${escapeHtml(f.name)}</h4>
      <p>Tipo: ${f.type} · ${(f.size/1024).toFixed(1)} KB</p>
      <div class="meta">${new Date(f.created_at).toLocaleString('pt-BR')}</div>
    </div>
  `).join('');
}

function saveConfig() {
  const cfg = Storage.getConfig();
  cfg.model = document.getElementById('model-select').value;
  cfg.aiName = document.getElementById('ai-name').value.trim() || 'NEXORA';
  cfg.customInstructions = document.getElementById('custom-instructions').value;
  Storage.saveConfig(cfg);
  alert('Configurações salvas!');
}

async function doGenerateFile() {
  const type = document.getElementById('file-type').value;
  const name = document.getElementById('file-name').value.trim() || 'arquivo';
  const content = document.getElementById('file-content').value;

  try {
    await Files.generate({ type, name, content });
    document.getElementById('modal-file').classList.add('hidden');
    alert('Arquivo baixado!');
  } catch (e) {
    alert('Erro: ' + e.message);
  }
}
