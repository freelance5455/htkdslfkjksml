/**
 * Geração de arquivos no navegador (JSZip)
 */

const Files = {
  async generate({ type, name, content }) {
    let blob;
    let filename = name || 'arquivo';

    if (type === 'txt' || type === 'html' || type === 'css' || type === 'js' || type === 'json') {
      const mime = {
        txt: 'text/plain',
        html: 'text/html',
        css: 'text/css',
        js: 'application/javascript',
        json: 'application/json'
      }[type];
      blob = new Blob([content || ''], { type: mime + ';charset=utf-8' });
      if (!filename.endsWith('.' + type)) filename += '.' + type;
    }
    else if (type === 'zip' || type === 'mcaddon') {
      const zip = new JSZip();
      let structure = {};
      try {
        structure = typeof content === 'string' ? JSON.parse(content || '{}') : (content || {});
      } catch {
        structure = { 'README.txt': content || 'Arquivo gerado pela NEXORA AI' };
      }

      function addToZip(obj, path = '') {
        for (const [key, value] of Object.entries(obj)) {
          const full = path ? path + '/' + key : key;
          if (typeof value === 'object' && value !== null) {
            addToZip(value, full);
          } else {
            zip.file(full, value);
          }
        }
      }
      addToZip(structure);

      blob = await zip.generateAsync({ type: 'blob' });
      if (type === 'mcaddon' && !filename.endsWith('.mcaddon')) filename += '.mcaddon';
      else if (!filename.endsWith('.zip')) filename += '.zip';
    }
    else {
      throw new Error('Tipo não suportado');
    }

    // Salva metadado
    const list = Storage.getFiles();
    list.unshift({
      id: crypto.randomUUID(),
      name: filename,
      type,
      size: blob.size,
      created_at: new Date().toISOString()
    });
    Storage.saveFiles(list.slice(0, 50));

    // Download
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);

    return filename;
  }
};
