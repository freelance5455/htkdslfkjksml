/**
 * NEXORA Storage - localStorage + IndexedDB básico
 */

const Storage = {
  // Configurações gerais
  getConfig() {
    const raw = localStorage.getItem('nexora_config');
    return raw ? JSON.parse(raw) : {
      apiKey: '',
      model: 'llama-3.3-70b-versatile',
      aiName: 'NEXORA',
      customInstructions: '',
      demoMode: false
    };
  },
  saveConfig(cfg) {
    localStorage.setItem('nexora_config', JSON.stringify(cfg));
  },

  // Features (atualizações da própria NEXORA)
  getFeatures() {
    const raw = localStorage.getItem('nexora_features');
    return raw ? JSON.parse(raw) : {
      acceptImages: false,
      darkThemeOnly: true,
      customButtons: [],
      systemAdditions: [],
      version: 1
    };
  },
  saveFeatures(features) {
    localStorage.setItem('nexora_features', JSON.stringify(features));
  },

  // Conversas
  getConversations() {
    const raw = localStorage.getItem('nexora_conversations');
    return raw ? JSON.parse(raw) : [];
  },
  saveConversations(list) {
    localStorage.setItem('nexora_conversations', JSON.stringify(list));
  },
  getMessages(convId) {
    const raw = localStorage.getItem('nexora_messages_' + convId);
    return raw ? JSON.parse(raw) : [];
  },
  saveMessages(convId, messages) {
    localStorage.setItem('nexora_messages_' + convId, JSON.stringify(messages));
  },

  // Memórias de longo prazo
  getMemories() {
    const raw = localStorage.getItem('nexora_memories');
    return raw ? JSON.parse(raw) : [];
  },
  saveMemories(list) {
    localStorage.setItem('nexora_memories', JSON.stringify(list));
  },
  addMemory(mem) {
    const list = this.getMemories();
    list.unshift({
      id: crypto.randomUUID(),
      ...mem,
      created_at: new Date().toISOString()
    });
    this.saveMemories(list.slice(0, 200)); // limita
  },

  // Arquivos gerados (metadados)
  getFiles() {
    const raw = localStorage.getItem('nexora_files');
    return raw ? JSON.parse(raw) : [];
  },
  saveFiles(list) {
    localStorage.setItem('nexora_files', JSON.stringify(list));
  },

  // Pending update
  getPendingUpdate() {
    const raw = localStorage.getItem('nexora_pending_update');
    return raw ? JSON.parse(raw) : null;
  },
  setPendingUpdate(update) {
    if (update) localStorage.setItem('nexora_pending_update', JSON.stringify(update));
    else localStorage.removeItem('nexora_pending_update');
  }
};
