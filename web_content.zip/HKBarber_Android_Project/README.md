# HK Barber — Android starter project

This is an editable Android Studio project for HK Barber. It is a native Android WebView shell around a responsive app UI. The included demo queue works locally on one device.

## Important limitation
The queue is **not yet synchronized between different phones**. Cross-device live updates need a shared backend (for example Firebase Realtime Database) and project-specific configuration. This project intentionally does not contain Firebase secrets or pretend that cross-device sync is already active.

## Build the APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select this folder (`HKBarber_Android_Project`).
4. Wait for Gradle sync. If prompted, install the Android SDK/platform tools requested by Android Studio.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. When it finishes, choose **locate**. The debug APK is normally under `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer that APK to your Android phone and open it to install. If Android asks, allow installation from that file manager for this one install. Only install APKs you built or trust.
8. To make a shareable release, use **Build > Generate Signed Bundle / APK** and keep your signing key safe.

## Edit the app
- UI: `app/src/main/assets/index.html`
- App name: `app/src/main/res/values/strings.xml`
- Android package/application ID: `app/build.gradle`
- Launcher icon: `app/src/main/res/drawable/ic_launcher.xml` (simple vector placeholder)

## Live multi-phone queue
To make multiple phones see the same queue, create a Firebase project and add an Android app with package ID `com.hkbarber.app`. Enable Realtime Database and set database rules so only authenticated shop staff can change queue entries. Then add the Firebase Android SDK and authentication/database calls. Never put admin/service-account credentials in the app. The current app is a prototype, not a production-ready booking/payment system.
