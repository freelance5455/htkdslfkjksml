
(() => {
  const grid = document.getElementById('mods-grid');
  const status = document.getElementById('status');
  const count = document.getElementById('mod-count');
  const search = document.getElementById('search');
  const category = document.getElementById('category');

  const API_URL =
    window.OSAMA_MODS_API ||
    'https://osama-mods-api.omhj123456.workers.dev/api/mods';

  let mods = [];

  // تبديل المظهر مع حفظ الاختيار على نفس الجهاز
  const savedTheme = (() => {
    try {
      return localStorage.getItem('osama-mods-theme');
    } catch (_) {
      return null;
    }
  })();

  const validThemes = ['normal', 'light', 'pink'];

  function setTheme(theme) {
    if (!validThemes.includes(theme)) theme = 'normal';

    document.body.dataset.theme = theme;

    document.querySelectorAll('[data-theme-choice]').forEach(button => {
      button.setAttribute(
        'aria-pressed',
        String(button.dataset.themeChoice === theme)
      );
    });

    try {
      localStorage.setItem('osama-mods-theme', theme);
    } catch (_) {}
  }

  document.querySelectorAll('[data-theme-choice]').forEach(button => {
    button.addEventListener('click', () => {
      setTheme(button.dataset.themeChoice);
    });
  });

  setTheme(savedTheme || 'normal');

  function safeText(value, fallback = '') {
    return typeof value === 'string' ? value.trim() : fallback;
  }

  function showStatus(message, isError = false) {
    status.hidden = false;
    status.className = isError ? 'status error' : 'status';
    status.textContent = message;
  }

  function makeCard(mod) {
    const card = document.createElement('article');
    card.className = 'mod-card';

    const imageUrl = safeText(mod.image);

    if (imageUrl && /^https?:\/\//i.test(imageUrl)) {
      const image = document.createElement('img');

      image.className = 'mod-image';
      image.referrerPolicy = 'no-referrer';
      image.src = imageUrl;
      image.alt = safeText(mod.name, 'صورة المود');
      image.loading = 'lazy';

      image.onerror = () => {
        const placeholder = document.createElement('div');
        placeholder.className = 'mod-image-placeholder';
        placeholder.textContent = 'OM';
        image.replaceWith(placeholder);
      };

      card.appendChild(image);
    } else {
      const placeholder = document.createElement('div');
      placeholder.className = 'mod-image-placeholder';
      placeholder.textContent = 'OM';
      card.appendChild(placeholder);
    }

    const content = document.createElement('div');
    content.className = 'mod-content';

    const badge = document.createElement('span');
    badge.className = 'mod-category';
    badge.textContent = safeText(mod.category, 'عام') || 'عام';

    const title = document.createElement('h3');
    title.textContent = safeText(mod.name, 'مود بدون اسم');

    const description = document.createElement('p');
    description.textContent = safeText(
      mod.description,
      'لا يوجد وصف لهذا المود.'
    );

    content.append(badge, title, description);

    const downloadUrl = safeText(mod.download);
    const link = document.createElement('a');

    link.className = 'download';
    link.textContent = 'تحميل المود';

    if (downloadUrl && /^https?:\/\//i.test(downloadUrl)) {
      link.href = downloadUrl;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
    } else {
      link.href = '#';
      link.setAttribute('aria-disabled', 'true');
      link.style.opacity = '.55';

      link.addEventListener('click', event => {
        event.preventDefault();
        showStatus(
          'رابط التحميل لهذا المود غير صحيح. عدّل رابط download من لوحة المشرفين.',
          true
        );
      });
    }

    content.appendChild(link);
    card.appendChild(content);

    return card;
  }

  function updateCategories() {
    const previousCategory = category.value;

    // إعادة بناء التصنيفات لمنع تكرارها أو إبقاء تصنيف محذوف
    category.replaceChildren();

    const allOption = document.createElement('option');
    allOption.value = '';
    allOption.textContent = 'كل التصنيفات';
    category.appendChild(allOption);

    const categories = [
      ...new Set(
        mods
          .map(mod => safeText(mod.category, 'عام') || 'عام')
          .filter(Boolean)
      )
    ].sort((a, b) => a.localeCompare(b));

    categories.forEach(name => {
      const option = document.createElement('option');
      option.value = name;
      option.textContent = name;
      category.appendChild(option);
    });

    // الاحتفاظ بالتصنيف المختار إذا كان ما زال موجودًا
    if (categories.includes(previousCategory)) {
      category.value = previousCategory;
    }
  }

  function render() {
    const query = search.value.trim().toLocaleLowerCase();
    const selectedCategory = category.value;

    const filtered = mods.filter(mod => {
      const haystack = [
        mod.name,
        mod.description,
        mod.category
      ]
        .map(value => safeText(value).toLocaleLowerCase())
        .join(' ');

      const modCategory = safeText(mod.category, 'عام') || 'عام';

      return (
        haystack.includes(query) &&
        (!selectedCategory || modCategory === selectedCategory)
      );
    });

    grid.replaceChildren();

    filtered.forEach(mod => {
      grid.appendChild(makeCard(mod));
    });

    count.textContent = `${filtered.length} مود`;

    if (!filtered.length) {
      const empty = document.createElement('div');
      empty.className = 'empty';

      empty.textContent = mods.length
        ? 'ما لقينا مود يطابق بحثك.'
        : 'لا توجد مودات منشورة حاليًا.';

      grid.appendChild(empty);
    }
  }

  async function loadMods() {
    count.textContent = 'جارٍ التحميل…';
    showStatus('جارٍ تحميل أحدث الإضافات...');

    try {
      const response = await fetch(API_URL, {
        method: 'GET',
        cache: 'no-store',
        headers: {
          Accept: 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data = await response.json();

      if (!Array.isArray(data)) {
        throw new Error('استجابة API ليست قائمة مودات صحيحة.');
      }

      // البيانات تأتي مباشرة من قاعدة بيانات المتجر
      mods = data.filter(
        item => item &&
          typeof item === 'object' &&
          !Array.isArray(item)
      );

      updateCategories();
      render();

      if (mods.length) {
        status.hidden = true;
      } else {
        showStatus('لا توجد مودات منشورة حاليًا.');
      }
    } catch (error) {
      count.textContent = 'تعذّر التحميل';

      showStatus(
        'تعذّر تحميل المودات من الخادم. تحقق من الإنترنت وإعدادات CORS ورابط API، ثم أعد تحميل الصفحة.',
        true
      );

      console.error('OSAMA MODS: failed to load API data', error);
    }
  }

  search.addEventListener('input', render);
  category.addEventListener('change', render);

  // تحميل البيانات عند فتح المتجر
  loadMods();

  // تحديث البيانات عند العودة إلى صفحة المتجر
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) loadMods();
  });

  // إتاحة إعادة التحميل يدويًا من أدوات المتصفح عند الحاجة
  window.refreshOsamaMods = loadMods;
})();
