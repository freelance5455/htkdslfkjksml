(() => {
  const API = 'https://osama-mods-api.omhj123456.workers.dev';
  const $ = id => document.getElementById(id);
  let mods = [];
  const password = () => $('password').value;
  const status = (msg, error=false) => { $('status').textContent = msg; $('status').style.border = error ? '1px solid #ff6464' : '1px solid #2a3730'; };
  async function request(url, options={}) {
    const headers = Object.assign({'Content-Type':'application/json','X-Admin-Password':password()}, options.headers || {});
    let res;
    try { res = await fetch(url, {...options, headers}); }
    catch(e) { throw new Error('تعذّر الاتصال بالـ API. تأكد من الإنترنت وإعدادات CORS في Worker.'); }
    const body = await res.text();
    let data; try { data = body ? JSON.parse(body) : {}; } catch { data = {message:body}; }
    if (!res.ok) throw new Error(data.error || data.message || `فشل الطلب (HTTP ${res.status}). تحقق من كلمة المرور ومسار API.`);
    return data;
  }
  async function loadMods() {
    status('جارٍ تحميل المودات...');
    try {
      const res = await fetch(`${API}/api/mods`);
      if (!res.ok) throw new Error(`فشل تحميل المودات (HTTP ${res.status})`);
      mods = await res.json();
      if (!Array.isArray(mods)) throw new Error('استجابة API ليست قائمة مودات.');
      $('login-panel').classList.add('hidden'); $('app').classList.remove('hidden');
      renderMods(); status(`تم تحميل ${mods.length} مود.`);
    } catch(e) { status(e.message, true); }
  }
  function renderMods() {
    const root = $('mods-list'); root.replaceChildren();
    if (!mods.length) { root.textContent = 'لا توجد مودات في قاعدة البيانات حتى الآن.'; return; }
    mods.forEach(mod => {
      const card = document.createElement('article'); card.className='mod';
      const row = document.createElement('div'); row.className='modrow';
      const img = document.createElement('img'); img.alt='صورة '+(mod.name||'المود'); img.src=mod.image||''; img.onerror=()=>{img.style.visibility='hidden';};
      const details = document.createElement('div'); details.style.flex='1';
      const title = document.createElement('h3'); title.textContent=mod.name||'بدون اسم';
      const cat = document.createElement('p'); cat.textContent='التصنيف: '+(mod.category||'غير محدد');
      const desc = document.createElement('p'); desc.textContent=mod.description||'';
      details.append(title,cat,desc); row.append(img,details); card.append(row);
      const edit=document.createElement('button'); edit.className='secondary'; edit.textContent='تعديل'; edit.onclick=()=>fillForm(mod);
      const del=document.createElement('button'); del.className='delete'; del.textContent='حذف'; del.onclick=()=>deleteMod(mod);
      card.append(edit,del); root.append(card);
    });
  }
  function fillForm(m) {
    $('mod-id').value=m.id; $('name').value=m.name||''; $('category').value=m.category||'';
    $('description').value=m.description||''; $('image').value=m.image||''; $('download').value=m.download||'';
    $('form-title').textContent='تعديل المود'; $('save').textContent='حفظ التعديلات'; previewImage(); window.scrollTo({top:0,behavior:'smooth'});
  }
  function clearForm() {
    $('mod-form').reset(); $('mod-id').value=''; $('form-title').textContent='إضافة مود جديد'; $('save').textContent='نشر المود';
    $('preview-wrap').classList.add('hidden');
  }
  function previewImage() {
    const url=$('image').value.trim();
    if(!url){$('preview-wrap').classList.add('hidden');return;}
    $('preview').src=url; $('preview-wrap').classList.remove('hidden');
  }
  async function deleteMod(m) {
    if(!confirm(`حذف المود «${m.name}» نهائيًا؟`)) return;
    status('جارٍ الحذف...');
    try { await request(`${API}/api/admin/mods/${encodeURIComponent(m.id)}`,{method:'DELETE'}); status('تم حذف المود.'); await loadMods(); }
    catch(e){status(e.message,true);}
  }
  $('login').addEventListener('click',loadMods);
  $('refresh').addEventListener('click',loadMods);
  $('image').addEventListener('input',previewImage);
  $('cancel-edit').addEventListener('click',clearForm);
  $('mod-form').addEventListener('submit',async e=>{
    e.preventDefault();
    const id=$('mod-id').value;
    const payload={name:$('name').value.trim(),category:$('category').value.trim(),description:$('description').value.trim(),image:$('image').value.trim(),download:$('download').value.trim()};
    if(!/^https?:\/\//i.test(payload.image)||!/^https?:\/\//i.test(payload.download)){status('تأكد أن رابط الصورة ورابط التحميل يبدأان بـ https:// أو http://',true);return;}
    status(id?'جارٍ حفظ التعديلات...':'جارٍ نشر المود...');
    try {
      if(id) await request(`${API}/api/admin/mods`,{method:'PUT',body:JSON.stringify({...payload,id:Number(id)})});
      else await request(`${API}/api/admin/mods`,{method:'POST',body:JSON.stringify(payload)});
      status(id?'تم حفظ التعديلات.':'تم إرسال المود للنشر.'); clearForm(); await loadMods();
    } catch(e){status(e.message,true);}
  });
})();
