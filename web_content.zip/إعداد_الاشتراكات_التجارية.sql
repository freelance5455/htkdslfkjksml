-- SHABAKATY commercial license system
-- Run once in Supabase SQL Editor. Admin UUID is the account owner supplied by the user.
create table if not exists public.shabakaty_licenses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  code_hash text not null unique,
  duration_days integer not null check (duration_days in (30,180,365)),
  activated_at timestamptz not null default now(),
  expires_at timestamptz not null,
  device_hash text not null,
  created_at timestamptz not null default now()
);
create table if not exists public.shabakaty_license_codes (
  id uuid primary key default gen_random_uuid(),
  code_hash text not null unique,
  duration_days integer not null check (duration_days in (30,180,365)),
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  redeemed_by uuid references auth.users(id),
  redeemed_at timestamptz
);
alter table public.shabakaty_licenses enable row level security;
alter table public.shabakaty_license_codes enable row level security;
drop policy if exists "license owner reads own" on public.shabakaty_licenses;
create policy "license owner reads own" on public.shabakaty_licenses for select to authenticated using (auth.uid()=user_id);
-- No direct client access to code inventory; all mutations occur through restricted RPCs.
revoke all on public.shabakaty_license_codes from anon, authenticated;
revoke all on public.shabakaty_licenses from anon, authenticated;
grant select on public.shabakaty_licenses to authenticated;
create or replace function public.get_my_shabakaty_license()
returns table(active boolean, expires_at timestamptz, duration_days integer)
language sql security definer set search_path=''
as $$ select (l.expires_at > now()), l.expires_at, l.duration_days from public.shabakaty_licenses l where l.user_id=auth.uid() $$;
revoke all on function public.get_my_shabakaty_license() from public, anon;
grant execute on function public.get_my_shabakaty_license() to authenticated;
create or replace function public.activate_my_shabakaty_license(p_code text,p_device_hash text)
returns timestamptz language plpgsql security definer set search_path=''
as $$
declare u uuid:=auth.uid(); c public.shabakaty_license_codes%rowtype; exp timestamptz;
begin
 if u is null then raise exception 'يجب تسجيل الدخول'; end if;
 if p_device_hash !~ '^[0-9a-f]{64}$' then raise exception 'معرف الجهاز غير صالح'; end if;
 select * into c from public.shabakaty_license_codes where code_hash=encode(extensions.digest(convert_to(upper(trim(p_code)),'UTF8'),'sha256'),'hex') and redeemed_at is null for update;
 if not found then raise exception 'الكود غير صحيح أو مستخدم'; end if;
 if exists(select 1 from public.shabakaty_licenses where user_id=u and device_hash<>p_device_hash) then raise exception 'الحساب مرتبط بجهاز آخر'; end if;
 select greatest(coalesce(max(expires_at),now()),now()) + make_interval(days=>c.duration_days) into exp from public.shabakaty_licenses where user_id=u;
 insert into public.shabakaty_licenses(user_id,code_hash,duration_days,expires_at,device_hash) values(u,c.code_hash,c.duration_days,exp,p_device_hash)
 on conflict(user_id) do update set code_hash=excluded.code_hash,duration_days=excluded.duration_days,expires_at=excluded.expires_at,device_hash=excluded.device_hash;
 update public.shabakaty_license_codes set redeemed_by=u,redeemed_at=now() where id=c.id;
 return exp;
end $$;
revoke all on function public.activate_my_shabakaty_license(text,text) from public,anon;
grant execute on function public.activate_my_shabakaty_license(text,text) to authenticated;
create or replace function public.admin_issue_shabakaty_license(p_duration_days integer default 365)
returns text language plpgsql security definer set search_path=''
as $$
declare code text; admin_id uuid:='b4223be6-910a-42b1-bc1c-a0f638750e6d';
begin
 if auth.uid() is distinct from admin_id then raise exception 'غير مصرح: المدير فقط'; end if;
 if p_duration_days not in (30,180,365) then raise exception 'مدة غير مدعومة'; end if;
 code:=upper(encode(extensions.gen_random_bytes(12),'hex'));
 insert into public.shabakaty_license_codes(code_hash,duration_days,created_by) values(encode(extensions.digest(convert_to(code,'UTF8'),'sha256'),'hex'),p_duration_days,auth.uid());
 return code;
end $$;
revoke all on function public.admin_issue_shabakaty_license(integer) from public,anon;
grant execute on function public.admin_issue_shabakaty_license(integer) to authenticated;
