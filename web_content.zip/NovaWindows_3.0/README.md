# NovaWindows 3.0 — projeto Android

Este é um projeto Android com uma área de trabalho web local (HTML/CSS/JavaScript) exibida em Android WebView.

## O que está incluído
- Desktop futurista com barra de tarefas centralizada.
- Janelas internas que podem ser movidas, minimizadas, restauradas e maximizadas.
- Navegador interno baseado no Chromium WebView do Android.
- Arquivos locais virtuais, notas, calculadora, configurações e gerenciador de tarefas.
- Central com miniaplicativos e jogos HTML5 locais (Snake e jogo de toque).
- Seletor Android para importar arquivos de texto/imagem selecionados pelo usuário.

## Abrir no AndroidIDE
1. Extraia o ZIP para uma pasta do telefone.
2. Abra o AndroidIDE e escolha **Open Project** (Abrir projeto).
3. Selecione a pasta `NovaWindows_3.0` extraída (a pasta que contém `settings.gradle`).
4. Aguarde a sincronização Gradle. Se o AndroidIDE pedir para instalar componentes do SDK, aceite os componentes compatíveis.
5. Use **Build > Assemble Debug** (ou o botão Build) para gerar o APK de teste.
6. O APK de depuração costuma ficar em `app/build/outputs/apk/debug/app-debug.apk`.

## Limitações honestas
- Este projeto é um desktop/shell Android, não substitui o sistema operacional Android.
- O navegador usa Android System WebView (tecnologia Chromium); não é o app Google Chrome completo.
- Alguns sites bloqueiam exibição dentro de janelas incorporadas. O navegador interno não consegue contornar essas políticas.
- Aplicativos Android externos precisam de seus próprios APKs legítimos e da confirmação do usuário para instalar.
- Não inclui APK do Minecraft nem arquivos proprietários. Use uma cópia licenciada obtida por meios oficiais.
- Programas Windows `.exe` não executam diretamente no Android. Precisam de uma camada de compatibilidade separada e nem todos funcionam.

## Requisitos
- Android 6.0 ou superior (API 23+).
- AndroidIDE com suporte ao Android Gradle Plugin 8.6.1, Kotlin 2.0.20 e SDK 35.
- Internet necessária para páginas web; o desktop e os miniapps locais abrem sem conexão.
