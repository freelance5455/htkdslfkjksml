1) ارفع كل الملفات دي (مع مجلد .github) على مستودع GitHub جديد.
2) افتح تبويب Actions وانتظر دقيقتين لحد ما يخلص Build APK.
3) افتح آخر تشغيل ونزّل MADASAT-APK من Artifacts، فك الضغط، وثبّت ملف app-debug.apk.
