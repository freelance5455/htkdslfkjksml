# Release obfuscation is enabled. Web game assets remain local inside the APK.
-keepclassmembers class * { @android.webkit.JavascriptInterface <methods>; }
