package com.lilamohamadi.sarzamin

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<Button>(R.id.btnB).setOnClickListener {
            startActivity(Intent(this, GameActivity::class.java).putExtra("game", "neshane_b.html"))
        }
    }
}
