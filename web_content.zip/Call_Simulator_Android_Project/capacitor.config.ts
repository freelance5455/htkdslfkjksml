import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.callsimulator.app',
  appName: 'Call Simulator',
  webDir: 'dist/public',
  android: {
    backgroundColor: '#000000',
    allowMixedContent: false,
  },
};

export default config;