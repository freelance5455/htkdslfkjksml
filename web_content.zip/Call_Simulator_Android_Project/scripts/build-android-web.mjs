import { build } from 'vite';

process.env.CAPACITOR_BUILD = '1';

await build({ configFile: 'vite.config.ts' });