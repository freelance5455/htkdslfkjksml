import { spawnSync } from 'node:child_process';

const windows = process.platform === 'win32';
const result = spawnSync(
  windows ? 'gradlew.bat' : './gradlew',
  process.argv.slice(2),
  {
    cwd: new URL('../android/', import.meta.url),
    shell: windows,
    stdio: 'inherit',
  },
);

if (result.error) {
  console.error(`Could not start the Gradle wrapper: ${result.error.message}`);
  process.exitCode = 1;
} else {
  process.exitCode = result.status ?? 1;
}