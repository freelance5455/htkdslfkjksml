# Call Simulator — Android Project

A standalone Capacitor Android project for an offline simulated call screen. The app does not place, receive, or end real calls and does not request telephony, microphone, camera, or contacts access.

## Build a debug APK

Build from this extracted folder (the folder containing this `README.md`), not from another workspace:

1. Install Node.js 22.12 or newer and pnpm 10 or newer.
2. Install Android Studio with Android SDK Platform 36 and Android Build Tools. Use Android Studio's bundled JDK 17 or install JDK 17 or newer.
3. Open a terminal in this folder and run:

   ```sh
   pnpm install
   pnpm run android:debug
   ```

The first build needs internet access to download Gradle and Android dependencies. The installed app runs from bundled assets and works offline.

The installable debug APK is created at:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

The command builds the web assets with Android-compatible relative paths, syncs them into the Capacitor Android project, then runs the Gradle wrapper. The included wrapper uses Gradle 8.14.3 and Android Gradle Plugin 8.13.0. The app compiles against SDK 36 and supports Android API 24 and newer. No global Gradle installation is needed.

## Build with Android Studio

From this folder, run:

```sh
pnpm install
pnpm run sync:android
pnpm run android:open
```

In Android Studio, select a device or emulator and choose **Build > Build APK(s)**. This option also works on Windows if you prefer not to build from a terminal.

## Release build

`pnpm run android:release` creates an unsigned release build. Configure an Android signing key in Android Studio/Gradle before distributing a release APK.

## Project layout

```text
Call_Simulator_Android_Project/
├── android/                 Capacitor Android project, Gradle wrapper, launcher art
├── public/                  Local favicon and static assets
├── scripts/                 Web build and cross-platform Gradle launcher
├── src/                     Call screen JavaScript and CSS
├── capacitor.config.ts      Capacitor app configuration
├── index.html               Web entry point
├── package.json             Standalone commands and pinned dependencies
└── pnpm-lock.yaml           Independent dependency lockfile
```

Caller name and optional background image are stored locally on the device. Call controls are visual simulation toggles only.

Icon refinement v4: End-call handset orientation and Record icon refined to supplied reference.
