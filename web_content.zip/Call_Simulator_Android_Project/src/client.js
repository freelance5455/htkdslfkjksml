const NAME_KEY = 'call-simulator.saved-name';
const NAME_OPT_IN_KEY = 'call-simulator.save-name';
const SESSION_KEY = 'call-simulator.active-session';
const BG_DB = 'call-simulator-local';
const BG_STORE = 'preferences';
let initialized = false;
let timerHandle = 0;
let backgroundUrl = '';
const userAgent = navigator.userAgent;
if (/Android/i.test(userAgent) && (/\bwv\b/i.test(userAgent) || /Capacitor/i.test(userAgent))) {
  document.documentElement.classList.add('native-android');
}
function refreshTimerAfterResume() {
  const session = parseSession(localStorage.getItem(SESSION_KEY));
  const display = document.getElementById('elapsed-time');
  if (session && display) display.textContent = formatElapsed(session.startedAt);
}
window.addEventListener('pageshow', refreshTimerAfterResume);
window.addEventListener('focus', refreshTimerAfterResume);
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') refreshTimerAfterResume();
});

const icons = {
  phone: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M6.62 10.79a15.05 15.05 0 0 0 6.59 6.59l2.2-2.2a1 1 0 0 1 1.02-.24c1.12.37 2.33.56 3.57.56a1 1 0 0 1 1 1V20a1 1 0 0 1-1 1C10.61 21 3 13.39 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.24.19 2.45.56 3.57a1 1 0 0 1-.25 1.02l-2.19 2.2Z"/></svg>',
  recording: '<svg class="control-icon icon-rec" viewBox="0 0 48 36" aria-hidden="true"><rect x="4" y="5" width="40" height="26" rx="4" fill="currentColor"/><path fill="var(--icon-cutout, #292929)" d="M11 18c0-4.7 3.3-7.6 7.2-7.6 2.1 0 3.8.8 5.8 2.8 2-2 3.7-2.8 5.8-2.8 3.9 0 7.2 2.9 7.2 7.6s-3.3 7.6-7.2 7.6c-2.1 0-3.8-.8-5.8-2.8-2 2-3.7 2.8-5.8 2.8-3.9 0-7.2-2.9-7.2-7.6Z"/><circle cx="18.2" cy="18" r="3.1" fill="currentColor"/><circle cx="29.8" cy="18" r="3.1" fill="currentColor"/></svg>',
  hold: '<svg class="control-icon icon-hold" viewBox="0 0 36 36" aria-hidden="true"><path fill="currentColor" d="M9 4h7v28H9zM21 4h7v28h-7z"/></svg>',
  add: '<svg class="control-icon" viewBox="0 0 36 36" aria-hidden="true"><path d="M18 4v28M4 18h28" stroke="currentColor" stroke-width="3.5" stroke-linecap="square"/></svg>',
  mute: '<svg class="control-icon icon-mute" viewBox="0 0 36 36" aria-hidden="true"><rect x="13" y="4" width="10" height="18" rx="5" fill="currentColor"/><path d="M8 17a10 10 0 0 0 20 0" fill="none" stroke="currentColor" stroke-width="2.7" stroke-linecap="round"/><path d="M18 27v5M13 32h10" fill="none" stroke="currentColor" stroke-width="2.7" stroke-linecap="round"/><path d="M5 5 31 31" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round"/></svg>',
  video: '<svg class="control-icon icon-video" viewBox="0 0 36 32" aria-hidden="true"><path fill="currentColor" d="M3 7a3 3 0 0 1 3-3h18a3 3 0 0 1 3 3v4l7-5v20l-7-5v4a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V7Z"/></svg>',
  speaker: '<svg class="control-icon icon-speaker" viewBox="0 0 40 36" aria-hidden="true"><path fill="currentColor" d="M3 13h7l9-7v24l-9-7H3z"/><path d="M24 11c4 4 4 10 0 14M28.5 7c6.5 6.5 6.5 15.5 0 22" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>',
  end: '<svg class="control-icon icon-end" viewBox="0 0 24 24" aria-hidden="true"><g transform="rotate(135 12 12)"><path fill="currentColor" d="M6.62 10.79a15.05 15.05 0 0 0 6.59 6.59l2.2-2.2a1 1 0 0 1 1.02-.24c1.12.37 2.33.56 3.57.56a1 1 0 0 1 1 1V20a1 1 0 0 1-1 1C10.61 21 3 13.39 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.24.19 2.45.56 3.57a1 1 0 0 1-.25 1.02l-2.19 2.2Z"/></g></svg>',
  dial: '<svg class="control-icon icon-dial" viewBox="0 0 32 36" aria-hidden="true"><g fill="currentColor"><circle cx="6" cy="6" r="2.4"/><circle cx="16" cy="6" r="2.4"/><circle cx="26" cy="6" r="2.4"/><circle cx="6" cy="14" r="2.4"/><circle cx="16" cy="14" r="2.4"/><circle cx="26" cy="14" r="2.4"/><circle cx="6" cy="22" r="2.4"/><circle cx="16" cy="22" r="2.4"/><circle cx="26" cy="22" r="2.4"/><circle cx="11" cy="30" r="2.4"/><circle cx="21" cy="30" r="2.4"/></g></svg>',
  hd: '<span class="duration-phone"><svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M6.62 10.79a15.05 15.05 0 0 0 6.59 6.59l2.2-2.2a1 1 0 0 1 1.02-.24c1.12.37 2.33.56 3.57.56a1 1 0 0 1 1 1V20a1 1 0 0 1-1 1C10.61 21 3 13.39 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.24.19 2.45.56 3.57a1 1 0 0 1-.25 1.02l-2.19 2.2Z"/></svg><b>HD</b></span>',
};

function openImageDb() {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) return reject(new Error('Local image storage is unavailable.'));
    const request = indexedDB.open(BG_DB, 1);
    request.onupgradeneeded = () => request.result.createObjectStore(BG_STORE);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function imageDb(action, value) {
  const db = await openImageDb();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(BG_STORE, 'readwrite');
    const store = transaction.objectStore(BG_STORE);
    const request = action === 'put' ? store.put(value, 'background') : store.get('background');
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
    transaction.oncomplete = () => db.close();
    transaction.onerror = () => reject(transaction.error);
  });
}

function applyBackground(root, blob) {
  if (backgroundUrl) URL.revokeObjectURL(backgroundUrl);
  backgroundUrl = blob ? URL.createObjectURL(blob) : '';
  root.querySelector('.app-bg').style.backgroundImage = backgroundUrl ? `url("${backgroundUrl}")` : 'none';
  const preview = root.querySelector('.image-preview');
  if (preview) preview.style.backgroundImage = backgroundUrl ? `url("${backgroundUrl}")` : 'none';
}

function screenSetup(root) {
  window.clearInterval(timerHandle);
  const saved = localStorage.getItem(NAME_KEY) || '';
  const opted = localStorage.getItem(NAME_OPT_IN_KEY) === 'true';
  root.innerHTML = `
    <div class="app-bg"></div><div class="app-shade"></div>
    <main class="app-root">
      <section class="setup-view" aria-labelledby="setup-title">
        <div class="setup-mark" aria-hidden="true">${icons.phone}</div>
        <h1 id="setup-title">Call Simulator</h1>
        <form class="setup-form" id="setup-form">
          <div>
            <label class="field-label" for="caller-name">Caller name</label>
            <input class="name-input" id="caller-name" name="caller-name" maxlength="32" placeholder="For example, Maa" autocomplete="off" value="${escapeAttribute(saved)}">
          </div>
          <label class="check-row" for="save-name"><input id="save-name" type="checkbox" ${opted ? 'checked' : ''}><span>Save this name</span></label>
          <div>
            <span class="field-label">Call background</span>
            <div class="image-row">
              <div class="image-preview" aria-hidden="true"></div>
              <div class="image-copy"><strong>Personalize your screen</strong><span id="image-status">Stored only on this device</span></div>
              <button type="button" class="choose-image" id="choose-image">Choose Background Image</button>
              <input id="background-file" type="file" accept="image/*" hidden>
            </div>
          </div>
          <button class="start-call" type="submit">Call</button>
        </form>
        <p class="simulation-note">Simulation only. No real call is placed and no device hardware is accessed.</p>
      </section>
    </main>`;
  const nameInput = root.querySelector('#caller-name');
  const saveCheckbox = root.querySelector('#save-name');
  root.querySelector('#setup-form').addEventListener('submit', (event) => {
    event.preventDefault();
    const name = nameInput.value.trim() || 'Unknown caller';
    if (saveCheckbox.checked) localStorage.setItem(NAME_KEY, name);
    const session = { name, number: randomIndianNumber(), startedAt: Date.now(), states: {} };
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    screenCall(root, session);
  });
  nameInput.addEventListener('input', () => {
    if (saveCheckbox.checked) localStorage.setItem(NAME_KEY, nameInput.value);
  });
  saveCheckbox.addEventListener('change', () => {
    localStorage.setItem(NAME_OPT_IN_KEY, String(saveCheckbox.checked));
    if (saveCheckbox.checked) localStorage.setItem(NAME_KEY, nameInput.value);
    else localStorage.removeItem(NAME_KEY);
  });
  const fileInput = root.querySelector('#background-file');
  root.querySelector('#choose-image').addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', async () => {
    const file = fileInput.files && fileInput.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) return;
    const status = root.querySelector('#image-status');
    status.textContent = 'Saving image locally…';
    try {
      await imageDb('put', file);
      applyBackground(root, file);
      status.textContent = 'Background saved on this device';
    } catch {
      status.textContent = 'Could not save image. Try a smaller file.';
    }
  });
  imageDb('get').then((blob) => {
    if (blob && root.isConnected) {
      applyBackground(root, blob);
      const status = root.querySelector('#image-status');
      if (status) status.textContent = 'Background saved on this device';
    }
  }).catch(() => {});
}

function screenCall(root, session) {
  window.clearInterval(timerHandle);
  root.innerHTML = `
    <div class="app-bg"></div><div class="app-shade"></div>
    <main class="app-root call-app-root">
      <section class="call-screen" aria-label="Simulated call">
         <div class="status-bar"><span>9:07</span><span class="status-right" aria-label="Simulation active"><svg viewBox="0 0 16 16" aria-hidden="true"><path fill="white" d="M8 10.25A2.25 2.25 0 0 0 10.25 8V4a2.25 2.25 0 0 0-4.5 0v4A2.25 2.25 0 0 0 8 10.25Zm4.25-2.5a4.25 4.25 0 0 1-8.5 0h-1.5A5.76 5.76 0 0 0 7.25 13.4V15h1.5v-1.6a5.76 5.76 0 0 0 5-5.65h-1.5Z"/></svg></span></div>
        <div class="caller-info">
          <h1 class="caller-name">${escapeHtml(session.name)}</h1>
          <div class="caller-number">${session.number} India</div>
          <div class="elapsed">${icons.hd}<span id="elapsed-time">00:00</span></div>
        </div>
        <div class="dialpad-panel" id="dialpad-panel" hidden>
          <div class="dialpad-display" id="dialpad-display"></div>
          <div class="dialpad-keys">
            ${[['1',''],['2','ABC'],['3','DEF'],['4','GHI'],['5','JKL'],['6','MNO'],['7','PQRS'],['8','TUV'],['9','WXYZ'],['*',''],['0','+'],['#','']].map(([digit,hint]) => `<button class="dial-key" type="button" data-digit="${digit}">${digit}${hint ? `<span class="key-hint">${hint}</span>` : ''}</button>`).join('')}
          </div>
        </div>
        <div class="call-controls" role="group" aria-label="Call controls">
          ${control('record', 'Record', icons.recording)}
          ${control('hold', 'Hold', icons.hold)}
          ${control('add', 'Add call', icons.add)}
          ${control('mute', 'Mute', icons.mute)}
          ${control('video', 'Video call', icons.video)}
          <span aria-hidden="true"></span>
          ${control('speaker', 'Speaker', icons.speaker)}
          ${control('end', 'End', icons.end, true)}
          ${control('dial', 'Dial pad', icons.dial)}
        </div>
      </section>
    </main>`;
  const callScreen = root.querySelector('.call-screen');
  const updateTimer = () => {
    const display = root.querySelector('#elapsed-time');
    if (!display) return;
    display.textContent = formatElapsed(session.startedAt);
  };
  updateTimer();
  timerHandle = window.setInterval(updateTimer, 1000);
  const panel = root.querySelector('#dialpad-panel');
  const dialDisplay = root.querySelector('#dialpad-display');
  let dialText = '';
  root.querySelectorAll('.control').forEach((button) => {
    button.addEventListener('click', () => {
      if (button.dataset.control === 'end') {
        localStorage.removeItem(SESSION_KEY);
        screenSetup(root);
        return;
      }
      const selected = button.classList.toggle('is-selected');
      button.setAttribute('aria-pressed', String(selected));
      const nextStates = { ...(session.states || {}), [button.dataset.control]: selected };
      session.states = nextStates;
      localStorage.setItem(SESSION_KEY, JSON.stringify(session));
      if (button.dataset.control === 'dial') {
        panel.hidden = !selected;
        callScreen.classList.toggle('has-dialpad', selected);
        if (!selected) {
          dialText = '';
          dialDisplay.textContent = '';
        }
      }
    });
  });
  root.querySelectorAll('.dial-key').forEach((key) => key.addEventListener('click', () => {
    if (dialText.length < 20) dialText += key.dataset.digit;
    dialDisplay.textContent = dialText;
  }));
  for (const [key, selected] of Object.entries(session.states || {})) {
    const button = root.querySelector(`[data-control="${key}"]`);
    if (button && selected) {
      button.classList.add('is-selected');
      button.setAttribute('aria-pressed', 'true');
      if (key === 'dial') {
        panel.hidden = false;
        callScreen.classList.add('has-dialpad');
      }
    }
  }
  imageDb('get').then((blob) => {
    if (blob && root.isConnected) applyBackground(root, blob);
  }).catch(() => {});
}

function control(key, label, svg, isEnd = false) {
  return `<button type="button" class="control${isEnd ? ' is-end' : ''}" data-control="${key}" aria-label="${label}" aria-pressed="false"><span class="control-circle">${svg}</span><span class="control-label">${label}</span></button>`;
}
function randomIndianNumber() {
  const firstDigit = 6 + Math.floor(Math.random() * 4);
  const remainingDigits = Array.from({ length: 9 }, () => Math.floor(Math.random() * 10)).join('');
  const digits = `${firstDigit}${remainingDigits}`;
  return `+91 ${digits.slice(0, 5)} ${digits.slice(5)}`;
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
}
function escapeAttribute(value) { return escapeHtml(value); }
function formatElapsed(startedAt) {
  const seconds = Math.max(0, Math.floor((Date.now() - startedAt) / 1000));
  return `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
}

export function bootCallSimulator() {
  if (initialized) return;
  initialized = true;
  const mount = document.getElementById('root');
  if (!mount) return;
  const root = mount;
  const session = parseSession(localStorage.getItem(SESSION_KEY));
  if (session) screenCall(root, session);
  else screenSetup(root);
}

function parseSession(serialized) {
  try {
    const session = serialized ? JSON.parse(serialized) : null;
    return session && typeof session.name === 'string' && typeof session.startedAt === 'number' ? session : null;
  } catch { return null; }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', bootCallSimulator, { once: true });
} else {
  bootCallSimulator();
}