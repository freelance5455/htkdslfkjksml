MOBILE CHART SIGNAL HELPER — PROJECT ZIP

Yeh ready-made APK nahi hai. Is ZIP ko seedhe APK ki tarah install nahi kiya ja sakta. Yeh HTML/PWA project hai.

KYA KARTA HAI:
- Mobile par Binomo chart ka screenshot select karke preview kar sakte hain.
- Recent closing prices manually enter karne par EMA, momentum aur RSI indicators calculate karta hai.
- UP BIAS / DOWN BIAS / WAIT estimate dikhata hai.

KYA NAHI KARTA:
- Binomo se connect nahi hota; official live data/API integration shamil nahi hai.
- Screenshot ko AI vision se automatically analyze nahi karta.
- Automatic trade place nahi karta.
- Profit ya signal accuracy guarantee nahi hai.

MOBILE PAR TEST:
1. ZIP extract karein.
2. index.html ko browser mein kholkar test karein. Local file par kuch browser PWA features support nahi karte.
3. Installable home-screen app ke liye files ko HTTPS hosting par publish karein aur Chrome mein kholkar Add to Home screen chunein.
4. APK ke liye compatible HTML-to-Android WebView wrapper/build service ya Android build environment zaroori hai. ZIP ko generic converter par upload karne se valid APK ki guarantee nahi hoti.

LIVE SIGNAL KI LIMIT:
Binomo ka live chart automatically read karne ke liye supported, authorized live data feed ya screen-capture/vision implementation chahiye. Is project mein woh connection nahi hai. OTC prices ko third-party feed se match karna aksar mumkin nahi hota.
