/* MR,KHORASANI local Supabase bridge
 * Classic-script, same-origin, ZIP→APK safe.
 * Implements only the subset used by this application.
 */
(function(g){
  'use strict';
  function makeError(message,status,code){return {message:String(message||'خطای ارتباط با سرویس'),status:status||0,code:code||null};}
  async function readResponse(res){
    let body=null; try{body=await res.json()}catch(_){body=null}
    if(!res.ok){
      const msg=body&&(body.msg||body.message||body.error_description||body.error)||('HTTP '+res.status);
      throw makeError(msg,res.status,body&&(body.code||body.error_code));
    }
    return body;
  }
  function clone(x){return x==null?x:JSON.parse(JSON.stringify(x));}
  function createLocalSupabaseClient(url,key){
    const base=String(url).replace(/\/$/,'');
    const apiBase=base+'/rest/v1';
    const authBase=base+'/auth/v1';
    const SESSION_KEY='mrk_supabase_session_v2';
    let session=null;
    try{session=JSON.parse(localStorage.getItem(SESSION_KEY)||'null')}catch(_){session=null}
    function saveSession(s){session=s||null;try{if(s)localStorage.setItem(SESSION_KEY,JSON.stringify(s));else localStorage.removeItem(SESSION_KEY)}catch(_){} }
    function headers(extra){
      const h={'apikey':key,'Content-Type':'application/json','Accept':'application/json'};
      if(session&&session.access_token)h.Authorization='Bearer '+session.access_token;
      for(const k in (extra||{}))h[k]=extra[k];
      return h;
    }
    async function request(path,opts){
      const res=await fetch(path,{method:opts.method||'GET',headers:headers(opts.headers),body:opts.body===undefined?undefined:JSON.stringify(opts.body)});
      return readResponse(res);
    }
    function normalize(data,mode){
      if(mode==='maybeSingle'){if(data==null)return null;if(Array.isArray(data))return data.length?data[0]:null;return data}
      if(mode==='single'){if(Array.isArray(data))return data[0]||null;return data}
      return data;
    }
    class Query{
      constructor(table){this.table=table;this.method='GET';this.payload=null;this.params=[];this.returnSelect=null;this.mode=null;this.conflict=null;}
      select(cols){this.returnSelect=cols||'*';return this}
      eq(col,val){this.params.push(''+encodeURIComponent(col)+'=eq.'+encodeURIComponent(String(val)));return this}
      order(col,opt){this.params.push('order='+encodeURIComponent(col)+'.'+(opt&&opt.ascending===false?'desc':'asc'));return this}
      limit(n){this.params.push('limit='+encodeURIComponent(String(n)));return this}
      update(payload){this.method='PATCH';this.payload=payload;return this}
      insert(payload){this.method='POST';this.payload=payload;return this}
      upsert(payload,opt){this.method='POST';this.payload=payload;this.conflict=opt&&opt.onConflict||null;return this}
      single(){this.mode='single';return this._run()}
      maybeSingle(){this.mode='maybeSingle';return this._run()}
      then(resolve,reject){return this._run().then(resolve,reject)}
      async _run(){
        let qs=this.params.slice();
        let h={};
        if(this.returnSelect) { qs.push('select='+encodeURIComponent(this.returnSelect)); h.Prefer='return=representation'; }
        else if(this.method==='POST'||this.method==='PATCH') h.Prefer='return=minimal';
        if(this.conflict) qs.push('on_conflict='+encodeURIComponent(this.conflict));
        if(this.mode) h.Accept='application/json';
        const q=qs.length?'?'+qs.join('&'):'';
        try{
          let data=await request(apiBase+'/'+encodeURIComponent(this.table)+q,{method:this.method,headers:h,body:this.payload});
          data=normalize(data,this.mode);
          return {data,error:null};
        }catch(error){return {data:null,error}};
      }
    }
    const auth={
      async signUp({email,password,options}){
        try{
          const body={email,password,data:clone(options&&options.data)||{}};
          const data=await request(authBase+'/signup',{method:'POST',body});
          const sess=data&&data.access_token?data:null;
          if(sess)saveSession(sess); else if(data&&data.session)saveSession(data.session);
          return {data:{user:data&&data.user||null,session:data&&data.session||sess||null},error:null};
        }catch(error){return {data:{user:null,session:null},error}}
      },
      async signInWithPassword({email,password}){
        try{
          const data=await request(authBase+'/token?grant_type=password',{method:'POST',body:{email,password}});
          saveSession(data);
          return {data:{user:data.user||null,session:data},error:null};
        }catch(error){return {data:{user:null,session:null},error}}
      },
      async getSession(){return {data:{session:clone(session)},error:null}},
      async getUser(){
        if(!session||!session.access_token)return {data:{user:null},error:null};
        try{const user=await request(authBase+'/user',{method:'GET'});return {data:{user},error:null}}catch(error){return {data:{user:null},error}}
      },
      async signOut(){
        try{if(session&&session.access_token){await request(authBase+'/logout',{method:'POST'})}}catch(_){ }
        saveSession(null);return {error:null};
      },
      onAuthStateChange(){return {data:{subscription:{unsubscribe(){}}},error:null}} 
    };
    async function rpc(name,args){
      try{const data=await request(apiBase+'/rpc/'+encodeURIComponent(name),{method:'POST',body:args||{}});return {data,error:null}}catch(error){return {data:null,error}};
    }
    function from(table){return new Query(table)}
    function removeChannel(ch){try{if(ch&&ch.stop)ch.stop()}catch(_){} }
    function channel(){
      return {on(){return this},subscribe(){return this},stop(){}};
    }
    return {from,rpc,auth,channel,removeChannel};
  }
  g.createLocalSupabaseClient=createLocalSupabaseClient;
})(window);
