package com.rnenterprises.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import android.util.Base64;
import android.os.Handler;
import android.os.Looper;

public class MainActivity extends Activity {
    WebView web;
    @Override public void onCreate(Bundle b){ super.onCreate(b);
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient()); web.addJavascriptInterface(new ShareBridge(), "AndroidShare");
        web.loadUrl("file:///android_asset/index.html");
    }
    class ShareBridge {
        @JavascriptInterface public void sharePdf(String base64,String filename){
            try{
                byte[] data=Base64.decode(base64,Base64.DEFAULT);
                File dir=new File(getCacheDir(), "shared_pdfs");
                if(!dir.exists()) dir.mkdirs();
                File f=new File(dir, filename.replaceAll("[^A-Za-z0-9._-]","_") );
                FileOutputStream out=new FileOutputStream(f); out.write(data); out.close();
                Uri uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".provider",f);
                Intent i=new Intent(Intent.ACTION_SEND);
                i.setType("application/pdf");
                i.putExtra(Intent.EXTRA_STREAM,uri);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Intent chooser=Intent.createChooser(i,"Share PDF");
                new Handler(Looper.getMainLooper()).post(() -> startActivity(chooser));
            }catch(Exception e){ Toast.makeText(MainActivity.this,"PDF share failed: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
        }
    }
}
