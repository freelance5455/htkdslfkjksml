# NøddeSalg – version 1.1

Færdig første version af salgsoptællingsappen til brændte mandler/nødder.

## Indeholder
- Salgssted kan vælges fra en liste.
- Nye salgssteder kan tastes ind og gemmes automatisk til senere brug.
- Almindelige brændte mandler: 35 kr./stk., 2 for 60 kr.
- Specialudgaver: 40 kr./stk. med mængdepriser: 1=40, 2=80, 3=100, 4=140, 5=180, 6=200 kr. og samme 6-stk.-pakker ved større antal.
- Specialudgaver kan blandes i samme køb, fx 2 lakrids + 1 chilli = 100 kr.
- Specialudgaver: hasselnødder, cashewnødder, lakrids, chilli, sesam og kokos.
- Kandiserede æbler: 35 kr./stk. og kan registreres i valgfrit antal.
- Dagens omsætning.
- Historik over alle registrerede salg.
- CSV-eksport.
- Data gemmes lokalt på telefonen.

## Byg APK
Åbn mappen i Android Studio og vælg Build > Build APK(s). Projektet bruger kun Androids egen WebView og har ingen eksterne app-biblioteker.
