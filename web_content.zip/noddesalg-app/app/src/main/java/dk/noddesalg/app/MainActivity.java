package dk.noddesalg.app;
import android.app.*; import android.os.*; import android.webkit.*; import android.view.*; import android.content.*;
public class MainActivity extends Activity {
  WebView w;
  @Override public void onCreate(Bundle b){super.onCreate(b); w=new WebView(this); w.getSettings().setJavaScriptEnabled(true); w.getSettings().setDomStorageEnabled(true); w.setOverScrollMode(View.OVER_SCROLL_NEVER); w.addJavascriptInterface(new Bridge(this), "Android"); w.setDownloadListener((url,userAgent,contentDisposition,mimeType,contentLength)->{ }); w.loadUrl("file:///android_asset/index.html"); setContentView(w);}
  public static class Bridge { private final Activity a; Bridge(Activity a){this.a=a;}
    @JavascriptInterface public void shareCsv(String csv){
      Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/csv"); i.putExtra(Intent.EXTRA_SUBJECT,"NøddeSalg – salg"); i.putExtra(Intent.EXTRA_TEXT,csv); a.startActivity(Intent.createChooser(i,"Eksportér salg"));
    }
    @JavascriptInterface public void sendReport(String body){
      Intent i=new Intent(Intent.ACTION_SENDTO); i.setData(android.net.Uri.parse("mailto:nissenodder@gmail.com")); i.putExtra(Intent.EXTRA_SUBJECT,"NøddeSalg – dagsrapport"); i.putExtra(Intent.EXTRA_TEXT,body); a.startActivity(Intent.createChooser(i,"Send dagsrapport"));
    }
  }
}
