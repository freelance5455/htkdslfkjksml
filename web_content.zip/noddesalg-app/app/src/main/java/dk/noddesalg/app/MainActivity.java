package dk.noddesalg.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.net.Uri;
import android.provider.Settings;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView w;
    private String pendingCsv = null;
    private static final int CREATE_CSV = 1001;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        w = new WebView(this);
        w.getSettings().setJavaScriptEnabled(true);
        w.getSettings().setDomStorageEnabled(true);
        w.setOverScrollMode(View.OVER_SCROLL_NEVER);
        w.setWebViewClient(new WebViewClient());
        w.addJavascriptInterface(new Bridge(), "Android");
        w.loadUrl("file:///android_asset/index.html");
        setContentView(w);
    }

    public class Bridge {
        @JavascriptInterface public void exportCsv(String csv) {
            pendingCsv = csv;
            try {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("text/csv");
                i.putExtra(Intent.EXTRA_TITLE, "noddesalg.csv");
                startActivityForResult(i, CREATE_CSV);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(MainActivity.this, "Telefonen kan ikke åbne filvælgeren.", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Fejl ved eksport: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }

        @JavascriptInterface public void sendReport(String body) {
            final String to = "nissenodder@gmail.com";
            final String subject = "NøddeSalg – dagsrapport";
            try {
                // Åbn Gmail direkte, hvis Gmail er installeret.
                Intent gmail = new Intent(Intent.ACTION_SENDTO);
                gmail.setData(Uri.parse("mailto:" + to));
                gmail.putExtra(Intent.EXTRA_SUBJECT, subject);
                gmail.putExtra(Intent.EXTRA_TEXT, body);
                gmail.setPackage("com.google.android.gm");
                startActivity(gmail);
                return;
            } catch (Exception ignored) { }

            try {
                // Fallback: vis telefonens mail-apps.
                Intent mail = new Intent(Intent.ACTION_SENDTO);
                mail.setData(Uri.parse("mailto:" + to));
                mail.putExtra(Intent.EXTRA_SUBJECT, subject);
                mail.putExtra(Intent.EXTRA_TEXT, body);
                startActivity(Intent.createChooser(mail, "Send dagsrapport"));
            } catch (Exception e) {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_EMAIL, new String[]{to});
                    send.putExtra(Intent.EXTRA_SUBJECT, subject);
                    send.putExtra(Intent.EXTRA_TEXT, body);
                    startActivity(Intent.createChooser(send, "Send dagsrapport"));
                } catch (Exception e2) {
                    Toast.makeText(MainActivity.this, "Kunne ikke åbne Gmail eller en mail-app. Kontrollér at Gmail er installeret.", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_CSV) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingCsv != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new Exception("Kunne ikke åbne filen");
                    out.write(pendingCsv.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "CSV-filen er gemt.", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Fejl ved gemning af CSV: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            } else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(this, "Eksport annulleret.", Toast.LENGTH_SHORT).show();
            }
            pendingCsv = null;
        }
    }
}
