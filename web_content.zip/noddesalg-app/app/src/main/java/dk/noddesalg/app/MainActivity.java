package dk.noddesalg.app;
import android.app.*; import android.os.*; import android.webkit.*; import android.view.*; import java.io.*;
public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b){super.onCreate(b); WebView w=new WebView(this); w.getSettings().setJavaScriptEnabled(true); w.getSettings().setDomStorageEnabled(true); w.setOverScrollMode(View.OVER_SCROLL_NEVER); w.loadUrl("file:///android_asset/index.html"); setContentView(w);}
}
