// HUD wiring: level label, counters, the pause/win/game-over panels, and
// the mute button. This file only touches the DOM — no game rules live here.
window.Game = window.Game || {};

(function(){
  const el = id => document.getElementById(id);
  const els = {
    star: el('cStar'), tomato: el('cTomato'), berry: el('cBerry'),
    levelPill: el('levelPill'),
    settingsOverlay: el('settingsOverlay'),
    winOverlay: el('winOverlay'),
    winMessage: el('winMessage'),
    gameOverOverlay: el('gameOverOverlay'),
    settingsBtn: el('settingsBtn'), resumeBtn: el('resumeBtn'),
    restartBtn: el('restartBtn'), playAgainBtn: el('playAgainBtn'),
    gameOverRetryBtn: el('gameOverRetryBtn'),
    muteBtn: el('muteBtn'),
    hintPill: el('hintPill'), timerPill: el('timerPill'), timerText: el('timerText'),
    toast: el('toast'), gameOverMsg: el('gameOverMsg')
  };

  function setLevelLabel(text){ els.levelPill.textContent = text; }

  // The win screen's button/message change depending on whether there's
  // a next level to go to — call this whenever a level (re)loads so it's
  // always ready by the time the player actually finishes it.
  function setWinMessage(text){ els.winMessage.textContent = text; }
  function setWinButton(label, handler){
    els.playAgainBtn.textContent = label;
    if(els.playAgainBtn._handler){
      els.playAgainBtn.removeEventListener('click', els.playAgainBtn._handler);
    }
    els.playAgainBtn.addEventListener('click', handler);
    els.playAgainBtn._handler = handler;
  }

  function setHint(text){
    els.hintPill.hidden = !text;
    els.hintPill.textContent = text || '';
  }

  let shownSecs = null, toastTimer = null;
  function setTimer(seconds){
    if(seconds === null || seconds === undefined){
      els.timerPill.hidden = true; shownSecs = null; return;
    }
    const s = Math.max(0, Math.ceil(seconds));
    els.timerPill.hidden = false;
    if(s === shownSecs) return;
    shownSecs = s;
    els.timerText.textContent = Math.floor(s/60) + ':' + String(s%60).padStart(2,'0');
    els.timerPill.classList.toggle('warn', s <= 5);
  }

  function toast(text){
    els.toast.textContent = text;
    els.toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(()=> els.toast.classList.remove('show'), 1400);
  }

  function setGameOverMessage(text){ els.gameOverMsg.textContent = text; }

  function updateCounters(counts){
    els.star.textContent   = (counts.star   ?? 0) + '/3';
    els.tomato.textContent = (counts.tomato ?? 0) + '/3';
    els.berry.textContent  = (counts.berry  ?? 0) + '/3';
  }

  function showSettings(){ els.settingsOverlay.classList.add('show'); }
  function hideSettings(){ els.settingsOverlay.classList.remove('show'); }
  function showWin(){ els.winOverlay.classList.add('show'); }
  function hideWin(){ els.winOverlay.classList.remove('show'); }
  function showGameOver(){ els.gameOverOverlay.classList.add('show'); }
  function hideGameOver(){ els.gameOverOverlay.classList.remove('show'); }

  function refreshMuteBtn(){
    els.muteBtn.textContent = Game.audio.isMuted() ? '🔇' : '🔊';
  }

  function bind({ onSettings, onResume, onRestart }){
    els.settingsBtn.addEventListener('click', ()=>{ onSettings(); showSettings(); });
    els.resumeBtn.addEventListener('click', ()=>{ onResume(); hideSettings(); });
    els.restartBtn.addEventListener('click', onRestart);
    els.gameOverRetryBtn.addEventListener('click', onRestart);
    els.muteBtn.addEventListener('click', ()=>{ Game.audio.toggleMute(); refreshMuteBtn(); });
    refreshMuteBtn();
  }

  Game.ui = {
    setLevelLabel, updateCounters, setHint, setTimer, toast, setGameOverMessage,
    showSettings, hideSettings,
    showWin, hideWin, setWinMessage, setWinButton,
    showGameOver, hideGameOver,
    bind
  };
})();
