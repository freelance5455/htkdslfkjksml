// Shared constants for the whole game. Change values here and every
// other file (physics, items, rendering) picks them up automatically.
window.Game = window.Game || {};

Game.config = {
  W: 960, H: 540,          // fixed virtual game world (16:9)
  GROUND_FRAC: 0.60,        // ground line as a fraction of H
  SPEED: 4.2,               // left/right move speed
  GRAVITY: 0.62,
  JUMP_V: -11,               // jump strength (more negative = higher jump)
  MARGIN_X: 40              // how close to the screen edge the player can go
};
