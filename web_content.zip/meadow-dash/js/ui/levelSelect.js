// Level Select screen: a map with a chain of level nodes that slides along
// a fixed path. Swipe left/right and the chain moves: Level 1 slides under
// the island at the start, Level 11, 12... appear from the right edge.
// Opens from the top-left "Level N" button. Done levels get a tick, the
// furthest level glows, everything beyond it is locked.
// Progress comes from core/progress.js.
window.Game = window.Game || {};

(function(){
  const TOTAL = 30;      // how many level nodes the map holds
  const SLOTS = 10;      // how many fit on screen at once
  const T0 = 0.09;       // where the first slot sits along the path (0 = start, 1 = end)
  const STEP = (0.93 - T0) / (SLOTS - 1);   // path distance between two levels
  const DRAG_PX = 0.093; // one level step = this fraction of the stage width

  // The sand path of assets/levelselect/map.jpg as [x%, y%] points, left to right.
  const PATH = [
    [0.0, 86.6],
    [1.4, 81.0],
    [2.8, 75.6],
    [5.4, 71.4],
    [8.3, 68.2],
    [10.9, 64.2],
    [12.9, 59.3],
    [14.3, 53.6],
    [15.8, 48.2],
    [18.5, 44.6],
    [21.9, 43.8],
    [25.2, 45.2],
    [28.5, 47.1],
    [31.8, 48.4],
    [35.2, 47.3],
    [38.0, 43.7],
    [40.4, 39.4],
    [43.1, 35.5],
    [46.1, 32.7],
    [49.5, 31.5],
    [52.9, 32.1],
    [55.9, 35.0],
    [58.2, 39.5],
    [60.0, 44.7],
    [61.8, 49.9],
    [63.7, 55.0],
    [65.8, 59.9],
    [68.2, 64.1],
    [71.2, 67.1],
    [74.6, 68.3],
    [78.1, 68.1],
    [81.2, 66.0],
    [83.8, 62.0],
    [85.5, 56.6],
    [86.5, 50.8],
    [87.4, 44.9],
    [88.7, 39.3],
    [91.3, 35.5],
    [94.7, 34.6],
    [98.0, 35.9],
    [100.0, 40.7]
  ];

  // Real length of every path piece (x% and y% are different scales: 16:9).
  const CUM = [0];
  for(let i = 1; i < PATH.length; i++){
    CUM.push(CUM[i-1] + Math.hypot((PATH[i][0]-PATH[i-1][0]) * 16, (PATH[i][1]-PATH[i-1][1]) * 9));
  }
  const LEN = CUM[CUM.length - 1];

  function pointAt(t){
    const d = Math.min(1, Math.max(0, t)) * LEN;
    let i = 1;
    while(i < CUM.length - 1 && CUM[i] < d) i++;
    const f = (d - CUM[i-1]) / ((CUM[i] - CUM[i-1]) || 1);
    return [PATH[i-1][0] + (PATH[i][0]-PATH[i-1][0]) * f,
            PATH[i-1][1] + (PATH[i][1]-PATH[i-1][1]) * f];
  }

  const el = id => document.getElementById(id);
  const root = el('levelSelect');
  const nodesBox = el('lsNodes');
  const stage = el('stage');
  let handlers = { onOpen(){}, onClose(){}, onPick(){} };

  let nodes = [];        // [{ level, btn }]
  let scroll = 0;        // how many levels the chain has slid (fractional while dragging)
  const maxScroll = () => TOTAL - SLOTS;
  const clamp = v => Math.min(maxScroll(), Math.max(0, v));

  function setUnit(){
    root.style.setProperty('--u', (stage.offsetWidth / 100) + 'px');
  }

  // Put every node where it belongs on the path for the current scroll.
  function layout(){
    nodes.forEach(({ level, btn })=>{
      const t = T0 + STEP * (level - 1 - scroll);
      if(t < -0.02 || t > 1.03){ btn.style.display = 'none'; return; }
      const p = pointAt(t);
      btn.style.display = 'flex';
      btn.style.left = p[0] + '%';
      btn.style.top  = p[1] + '%';
    });
  }

  function build(){
    // Reuse the HUD's gear icon so it always matches.
    el('lsSettingsBtn').innerHTML = el('settingsBtn').innerHTML;

    nodesBox.innerHTML = '';
    nodes = [];
    const reached = Game.progress.get();
    for(let n = 1; n <= TOTAL; n++){
      const btn = document.createElement('button');
      btn.className = 'ls-node';
      btn.dataset.level = n;
      btn.setAttribute('aria-label', 'Level ' + n);

      const num = '<span class="n">' + n + '</span>';
      if(n < reached){
        btn.classList.add('done');
        btn.innerHTML = num + '<span class="ck">✓</span>';
      } else if(n === reached){
        btn.classList.add('current');
        btn.innerHTML = '<span class="arrow">▼</span>' + num;
      } else {
        btn.classList.add('locked');
        btn.innerHTML = num + '<span class="lk">🔒</span>';
      }
      btn.addEventListener('click', ()=> tapNode(btn, n));
      nodesBox.appendChild(btn);
      nodes.push({ level: n, btn });
    }
    // Start with the current level near the middle of the screen.
    scroll = clamp(reached - 5);
    layout();
  }

  let suppressClick = false;

  function tapNode(btn, n){
    if(suppressClick) return;
    if(btn.classList.contains('locked') || !Game.LEVELS[n]){
      btn.classList.remove('shake');
      void btn.offsetWidth;
      btn.classList.add('shake');
      return;
    }
    hide();
    handlers.onPick(n);
  }

  // ---- swipe to slide the chain ----------------------------------
  let down = null;

  // Finger movement in game pixels (also right when the stage is rotated
  // 90deg by the portrait fallback in portrait.css).
  function gameDx(e){
    const r = stage.getBoundingClientRect();
    const rotated = r.width < r.height && stage.offsetWidth > stage.offsetHeight;
    return rotated
      ? (e.clientY - down.y) * (stage.offsetWidth / r.height)
      : (e.clientX - down.x) * (stage.offsetWidth / r.width);
  }

  function onDown(e){
    down = { x: e.clientX, y: e.clientY, scroll, moved: false };
    root.classList.remove('snap');
  }
  function onMove(e){
    if(!down) return;
    const dx = gameDx(e);
    if(!down.moved && Math.abs(dx) < 6) return;
    down.moved = true;
    scroll = clamp(down.scroll - dx / (stage.offsetWidth * DRAG_PX));
    layout();
  }
  function onUp(){
    if(!down) return;
    if(down.moved){
      suppressClick = true;
      setTimeout(()=>{ suppressClick = false; }, 0);
      scroll = clamp(Math.round(scroll));
      root.classList.add('snap');
      layout();
      setTimeout(()=> root.classList.remove('snap'), 260);
    }
    down = null;
  }
  function onWheel(e){
    e.preventDefault();
    scroll = clamp(Math.round(scroll + (e.deltaY > 0 ? 1 : -1)));
    root.classList.add('snap');
    layout();
  }

  function show(){
    setUnit();
    root.classList.remove('snap');
    build();
    root.classList.add('show');
    handlers.onOpen();
  }

  // hide() only hides the screen; close() also tells the game to resume.
  function hide(){ root.classList.remove('show'); }
  function close(){ hide(); handlers.onClose(); }
  function isOpen(){ return root.classList.contains('show'); }

  function bind(h){
    handlers = Object.assign(handlers, h);
    el('levelPill').addEventListener('click', show);
    el('lsBackBtn').addEventListener('click', close);
    el('lsSettingsBtn').addEventListener('click', ()=> Game.ui.showSettings());
    root.addEventListener('pointerdown', onDown);
    root.addEventListener('pointermove', onMove);
    root.addEventListener('pointerup', onUp);
    root.addEventListener('pointercancel', onUp);
    root.addEventListener('wheel', onWheel, { passive: false });
    window.addEventListener('resize', setUnit);
    window.addEventListener('orientationchange', ()=> setTimeout(setUnit, 60));
  }

  Game.levelSelect = { bind, show, hide, close, isOpen };
})();
