// HUD wiring: level label, counters, the settings/win/game-over panels
// and the settings toggles. This file only touches the DOM — no game rules live here.
window.Game = window.Game || {};

(function(){
  const el = id => document.getElementById(id);
  const els = {
    star: el('cStar'), tomato: el('cTomato'), berry: el('cBerry'),
    levelPill: el('levelPill'),
    settingsOverlay: el('settingsOverlay'),
    winOverlay: el('winOverlay'),
    winMessage: el('winMessage'),
    gameOverOverlay: el('gameOverOverlay'),
    settingsBtn: el('settingsBtn'), resumeBtn: el('resumeBtn'),
    restartBtn: el('restartBtn'), playAgainBtn: el('playAgainBtn'),
    gameOverRetryBtn: el('gameOverRetryBtn'),
    closeBtn: el('closeSettingsBtn'), resetBtn: el('resetBtn'),
    langSelect: el('langSelect'),
    toggles: { sfx: el('sfxToggle'), music: el('musicToggle'), vibration: el('vibrationToggle') }
  };

  function setLevelLabel(text){ els.levelPill.textContent = text; }

  // The win screen's button/message change depending on whether there's
  // a next level to go to — call this whenever a level (re)loads so it's
  // always ready by the time the player actually finishes it.
  function setWinMessage(text){ els.winMessage.textContent = text; }
  function setWinButton(label, handler){
    els.playAgainBtn.textContent = label;
    if(els.playAgainBtn._handler){
      els.playAgainBtn.removeEventListener('click', els.playAgainBtn._handler);
    }
    els.playAgainBtn.addEventListener('click', handler);
    els.playAgainBtn._handler = handler;
  }

  function updateCounters(counts){
    els.star.textContent   = (counts.star   ?? 0) + '/3';
    els.tomato.textContent = (counts.tomato ?? 0) + '/3';
    els.berry.textContent  = (counts.berry  ?? 0) + '/3';
  }

  function showSettings(){ els.settingsOverlay.classList.add('show'); }
  function hideSettings(){ els.settingsOverlay.classList.remove('show'); }
  function showWin(){ els.winOverlay.classList.add('show'); }
  function hideWin(){ els.winOverlay.classList.remove('show'); }
  function showGameOver(){ els.gameOverOverlay.classList.add('show'); }
  function hideGameOver(){ els.gameOverOverlay.classList.remove('show'); }

  function refreshToggles(){
    Object.keys(els.toggles).forEach(key=>{
      const on = Game.settings.get(key);
      const btn = els.toggles[key];
      btn.classList.toggle('on', on);
      btn.setAttribute('aria-checked', on ? 'true' : 'false');
      btn.querySelector('span').textContent = on ? 'ON' : 'OFF';
    });
  }

  function bind({ onSettings, onResume, onRestart, onReset }){
    const resume = ()=>{ onResume(); hideSettings(); };
    els.settingsBtn.addEventListener('click', ()=>{ onSettings(); showSettings(); });
    els.resumeBtn.addEventListener('click', resume);
    els.closeBtn.addEventListener('click', resume);
    els.restartBtn.addEventListener('click', onRestart);
    els.gameOverRetryBtn.addEventListener('click', onRestart);

    Object.keys(els.toggles).forEach(key=>{
      els.toggles[key].addEventListener('click', ()=>{
        Game.settings.set(key, !Game.settings.get(key));
        refreshToggles();
        if(key === 'vibration') Game.settings.vibrate(20);
      });
    });

    els.langSelect.value = Game.settings.get('language');
    els.langSelect.addEventListener('change', ()=> Game.settings.set('language', els.langSelect.value));

    // Reset Progress needs a second tap within 3 seconds to confirm.
    const resetLabel = els.resetBtn.textContent;
    let armed = false, armTimer = null;
    els.resetBtn.addEventListener('click', ()=>{
      if(!armed){
        armed = true;
        els.resetBtn.textContent = 'Pakka? Dobara tap karo';
        armTimer = setTimeout(()=>{ armed = false; els.resetBtn.textContent = resetLabel; }, 3000);
        return;
      }
      clearTimeout(armTimer);
      armed = false;
      els.resetBtn.textContent = resetLabel;
      onReset();
    });

    refreshToggles();
  }

  Game.ui = {
    setLevelLabel, updateCounters,
    showSettings, hideSettings,
    showWin, hideWin, setWinMessage, setWinButton,
    showGameOver, hideGameOver,
    bind
  };
})();
