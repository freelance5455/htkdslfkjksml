// HUD wiring: level label, counters, the settings/win/game-over panels
// and the settings toggles. This file only touches the DOM — no game rules live here.
window.Game = window.Game || {};

(function(){
  const el = id => document.getElementById(id);
  const els = {
    star: el('cStar'), tomato: el('cTomato'), berry: el('cBerry'),
    levelPill: el('levelPill'),
    settingsOverlay: el('settingsOverlay'),
    winOverlay: el('winOverlay'),
    winStars: el('winStars'), winTime: el('winTime'), winBest: el('winBest'),
    replayBtn: el('replayBtn'), winConfetti: el('winConfetti'),
    gameOverOverlay: el('gameOverOverlay'),
    settingsBtn: el('settingsBtn'), resumeBtn: el('resumeBtn'),
    restartBtn: el('restartBtn'), playAgainBtn: el('playAgainBtn'),
    gameOverRetryBtn: el('gameOverRetryBtn'),
    goMsg: el('goMsg'),
    timerPill: el('timerPill'), timerText: el('timerText'),
    closeBtn: el('closeSettingsBtn'), resetBtn: el('resetBtn'),
    resetOverlay: el('resetOverlay'), resetCancelBtn: el('resetCancelBtn'),
    resetCloseBtn: el('resetCloseBtn'), resetConfirmBtn: el('resetConfirmBtn'),
    langOpts: el('langOpts'),
    toggles: { sfx: el('sfxToggle'), music: el('musicToggle'), vibration: el('vibrationToggle') }
  };

  function setLevelLabel(text){ els.levelPill.textContent = text; }

  // The win screen's button/message change depending on whether there's
  // a next level to go to — call this whenever a level (re)loads so it's
  // always ready by the time the player actually finishes it.
  function setWinButton(label, handler, showReplay){
    els.playAgainBtn.textContent = label;
    els.replayBtn.hidden = !showReplay;
    if(els.playAgainBtn._handler){
      els.playAgainBtn.removeEventListener('click', els.playAgainBtn._handler);
    }
    els.playAgainBtn.addEventListener('click', handler);
    els.playAgainBtn._handler = handler;
  }

  // seconds = null hides the timer. Turns red and pulses in the last 5 s.
  let shownSecs = null;
  function setTimer(seconds){
    if(seconds === null || seconds === undefined){
      els.timerPill.hidden = true; shownSecs = null; return;
    }
    const s = Math.max(0, Math.ceil(seconds));
    els.timerPill.hidden = false;
    if(s === shownSecs) return;
    shownSecs = s;
    els.timerText.textContent = Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
    els.timerPill.classList.toggle('warn', s <= 5);
  }

  function updateCounters(counts){
    els.star.textContent   = (counts.star   ?? 0) + '/3';
    els.tomato.textContent = (counts.tomato ?? 0) + '/3';
    els.berry.textContent  = (counts.berry  ?? 0) + '/3';
  }

  function showSettings(){ els.settingsOverlay.classList.add('show'); }
  function hideSettings(){ els.settingsOverlay.classList.remove('show'); }
  const fmtTime = s => Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');
  // Bright confetti that falls over the dimmed game (DOM, so it isn't darkened).
  function burstConfetti(){
    const colors = ['#ffd23f','#ff5a4a','#ff6f91','#4fc3f7','#7bd957','#c792ea'];
    els.winConfetti.innerHTML = '';
    for(let i = 0; i < 40; i++){
      const b = document.createElement('b');
      b.style.cssText = 'left:' + (Math.random() * 100) + '%;background:' + colors[i % colors.length] +
        ';animation-delay:' + (Math.random() * 0.9) + 's;animation-duration:' + (1.8 + Math.random() * 1.6) +
        's;--r:' + Math.round(Math.random() * 360) + 'deg';
      els.winConfetti.appendChild(b);
    }
  }
  // stats = { stars: 1-3, time, best } (seconds). Stars restart their pop-in each time.
  function showWin(stats){
    if(stats){
      els.winTime.textContent = fmtTime(stats.time);
      els.winBest.textContent = fmtTime(stats.best);
      const kids = [...els.winStars.children];
      kids.forEach(s => s.classList.remove('on'));
      void els.winStars.offsetWidth;
      kids.forEach((s, i) => s.classList.toggle('on', i < stats.stars));
    }
    burstConfetti();
    els.winOverlay.classList.add('show');
  }
  function hideWin(){ els.winOverlay.classList.remove('show'); }
  // Every Game Over shows a different line: the list is shuffled and used
  // up one by one, then reshuffled (never the same line twice in a row).
  let bag = [], lastMsg = null;
  function nextGameOverMessage(){
    const all = Game.gameOverMessages || [];
    if(!all.length) return null;
    if(!bag.length){
      bag = all.slice();
      for(let i = bag.length - 1; i > 0; i--){
        const j = Math.floor(Math.random() * (i + 1));
        [bag[i], bag[j]] = [bag[j], bag[i]];
      }
      if(bag.length > 1 && bag[bag.length - 1] === lastMsg) bag.unshift(bag.pop());
    }
    lastMsg = bag.pop();
    return lastMsg;
  }

  function showGameOver(){
    const msg = nextGameOverMessage();
    if(msg) els.goMsg.textContent = msg;
    els.gameOverOverlay.classList.add('show');
  }
  function hideGameOver(){ els.gameOverOverlay.classList.remove('show'); }

  function refreshToggles(){
    Object.keys(els.toggles).forEach(key=>{
      const on = Game.settings.get(key);
      const btn = els.toggles[key];
      btn.classList.toggle('on', on);
      btn.setAttribute('aria-checked', on ? 'true' : 'false');
      btn.querySelector('span').textContent = on ? 'ON' : 'OFF';
    });
  }

  function bind({ onSettings, onResume, onRestart, onReset }){
    const resume = ()=>{
      if(!(Game.levelSelect && Game.levelSelect.isOpen())) onResume();
      hideSettings();
    };
    els.settingsBtn.addEventListener('click', ()=>{ onSettings(); showSettings(); });
    els.resumeBtn.addEventListener('click', resume);
    els.closeBtn.addEventListener('click', resume);
    els.restartBtn.addEventListener('click', onRestart);
    els.gameOverRetryBtn.addEventListener('click', onRestart);
    els.replayBtn.addEventListener('click', onRestart);

    Object.keys(els.toggles).forEach(key=>{
      els.toggles[key].addEventListener('click', ()=>{
        Game.settings.set(key, !Game.settings.get(key));
        refreshToggles();
        if(key === 'vibration') Game.settings.vibrate(20);
      });
    });

    const langBtns = [...els.langOpts.querySelectorAll('.lang-opt')];
    const refreshLang = ()=>{
      const cur = Game.settings.get('language');
      langBtns.forEach(b=>{
        const on = b.dataset.lang === cur;
        b.classList.toggle('on', on);
        b.setAttribute('aria-checked', on ? 'true' : 'false');
      });
    };
    langBtns.forEach(b=> b.addEventListener('click', ()=>{
      Game.settings.set('language', b.dataset.lang);
      refreshLang();
    }));
    refreshLang();

    // Reset Progress asks for confirmation in its own dialog first.
    const closeReset = ()=> els.resetOverlay.classList.remove('show');
    els.resetBtn.addEventListener('click', ()=> els.resetOverlay.classList.add('show'));
    els.resetCancelBtn.addEventListener('click', closeReset);
    els.resetCloseBtn.addEventListener('click', closeReset);
    els.resetConfirmBtn.addEventListener('click', ()=>{ closeReset(); onReset(); });

    refreshToggles();
  }

  Game.ui = {
    setLevelLabel, updateCounters, setTimer,
    showSettings, hideSettings,
    showWin, hideWin, setWinButton,
    showGameOver, hideGameOver,
    bind
  };
})();
