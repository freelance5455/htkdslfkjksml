// A rule-set decides two things for a level:
//   onTouch(type, counts, targets)  -> 'collect' | 'locked' | 'gameover'
//   isComplete(counts, targets)     -> true once the level is finished
// Levels pick one of these by name in levels.js. Add a new named
// rule-set here only when a future level needs genuinely different
// behaviour than what already exists below.
window.Game = window.Game || {};

Game.RULES = {

  // Level 1: every item is always collectible, in any order.
  classic: {
    onTouch(type){
      return 'collect';
    },
    isComplete(counts, targets){
      return Object.keys(targets).every(t => counts[t] >= targets[t]);
    }
  },

  // Level 2: tomatoes must come first.
  //  - Tomato: always collects.
  //  - Star:   collects once all tomatoes are in, otherwise instant game over.
  //  - Berry:  collects once all tomatoes are in, otherwise just locked
  //            (harmless to touch, simply doesn't register yet).
  level2: {
    onTouch(type, counts, targets){
      const tomatoDone = counts.tomato >= targets.tomato;
      if(type === 'tomato') return 'collect';
      if(type === 'star')   return tomatoDone ? 'collect' : 'gameover';
      if(type === 'berry')  return tomatoDone ? 'collect' : 'locked';
      return 'collect';
    },
    isComplete(counts, targets){
      return Object.keys(targets).every(t => counts[t] >= targets[t]);
    }
  },

  // Level 3: berries first, this time. Both tomato and star are deadly
  // until every berry is in — only berry is ever safe on first touch.
  //  - Berry:  always collects.
  //  - Tomato: collects once all berries are in, otherwise instant game over.
  //  - Star:   collects once all berries are in, otherwise instant game over.
  level3: {
  onTouch(type, counts, targets){
    const berryDone = counts.berry >= targets.berry;
    const starDone = counts.star >= targets.star;
    if(type === 'berry')  return 'collect';
    if(type === 'star')   return berryDone ? 'collect' : 'gameover';
    if(type === 'tomato') return starDone ? 'collect' : 'gameover';
    return 'collect';
  },
    isComplete(counts, targets){
      return Object.keys(targets).every(t => counts[t] >= targets[t]);
    }
  }
};
