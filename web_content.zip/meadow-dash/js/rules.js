// A rule-set decides two things for a level:
//   onTouch(type, counts, targets)  -> 'collect' | 'locked' | 'gameover'
//   isComplete(counts, targets)     -> true once the level is finished
// Levels pick one of these by name in levels.js. Add a new named
// rule-set here only when a future level needs genuinely different
// behaviour than what already exists below.
window.Game = window.Game || {};

Game.RULES = {

  // Level 1: every item is always collectible, in any order.
  classic: {
    onTouch(type){
      return 'collect';
    },
    isComplete(counts, targets){
      return Object.keys(targets).every(t => counts[t] >= targets[t]);
    }
  },

  // Level 2: tomatoes must come first.
  //  - Tomato: always collects.
  //  - Star:   collects once all tomatoes are in, otherwise instant game over.
  //  - Berry:  collects once all tomatoes are in, otherwise just locked
  //            (harmless to touch, simply doesn't register yet).
  level2: {
    onTouch(type, counts, targets){
      const tomatoDone = counts.tomato >= targets.tomato;
      if(type === 'tomato') return 'collect';
      if(type === 'star')   return tomatoDone ? 'collect' : 'gameover';
      if(type === 'berry')  return tomatoDone ? 'collect' : 'locked';
      return 'collect';
    },
    isComplete(counts, targets){
      return Object.keys(targets).every(t => counts[t] >= targets[t]);
    }
  },

  // Level 3: items must be collected in level.order. Touching any other
  // item returns 'reset' (game.js clears all counters and restores items).
  order: {
    onTouch(type, counts, targets, level){
      const current = level.order.find(t => counts[t] < targets[t]);
      return type === current ? 'collect' : 'reset';
    },
    isComplete(counts, targets){
      return Object.keys(targets).every(t => counts[t] >= targets[t]);
    }
  }
};
