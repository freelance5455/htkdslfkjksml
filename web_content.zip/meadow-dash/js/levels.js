// All level-specific data lives here: item layout, how many of each type
// are needed, the pickup radius, and which rule-set (see rules.js)
// governs it. To add Level 3, just add a new numbered entry below —
// nothing in game.js, player.js or items.js needs to change.
//
// Note: this is written as plain JS (not a .json file) on purpose —
// opening index.html directly by double-click uses the file:// protocol,
// and browsers block fetch()-ing local JSON files from there. Keeping it
// as a script tag means the game still works with zero setup. If you
// later serve this folder from a real web server, the object below is
// already valid JSON — you can drop it straight into levels.json and
// swap this file for a fetch() call.
window.Game = window.Game || {};

Game.LEVELS = {
  1: {
    id: 1,
    label: 'Level 1',
    targets: { star: 3, tomato: 3, berry: 3 },
    pickupRadius: 46,
    rules: 'classic',
    layout: [
      ['berry',128,false], ['star',216,true],  ['tomato',304,false],
      ['star',392,true],   ['berry',480,false],['tomato',568,true],
      ['star',656,false],  ['tomato',744,false],['berry',832,true]
    ]
  },

  2: {
    id: 2,
    label: 'Level 2',
    targets: { tomato: 3, star: 3, berry: 3 },
    pickupRadius: 32,
    rules: 'level2',
    // Tomatoes and stars sit close together on purpose — the player has
    // to thread between them carefully before the stars unlock.
    layout: [
      ['tomato',128,false], ['star',216,true],  ['tomato',304,false],
      ['berry',392,false],  ['star',480,true],  ['tomato',568,false],
      ['berry',656,false],  ['star',744,true],  ['berry',832,false]
    ]
  },

  3: {
    id: 3,
    label: 'Level 3',
    targets: { berry: 3, tomato: 3, star: 3 },
    pickupRadius: 32,
    rules: 'level3',
    // Reverse of Level 2: berries are the safe item this time. Tomatoes
    // AND stars are both live wires until every berry is collected.
    layout: [
      ['berry',128,false],  ['tomato',216,true], ['berry',304,false],
      ['star',392,true],    ['tomato',480,false],['berry',568,true],
      ['star',656,false],   ['tomato',744,true], ['star',832,true]
    ]
  }
};
