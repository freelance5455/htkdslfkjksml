// Player settings (sound effects, music, vibration, language), saved on
// this device. Other files only call get / set / vibrate.
window.Game = window.Game || {};

(function(){
  const KEY = 'ferg_settings';
  const defaults = { sfx: true, music: true, vibration: true, language: 'hinglish' };
  let data = Object.assign({}, defaults);

  try{
    const saved = JSON.parse(localStorage.getItem(KEY));
    if(saved && typeof saved === 'object') Object.assign(data, saved);
  }catch(e){}

  function get(key){ return data[key]; }

  function set(key, value){
    data[key] = value;
    try{ localStorage.setItem(KEY, JSON.stringify(data)); }catch(e){}
  }

  // Short buzz on supported phones; does nothing if vibration is off.
  function vibrate(pattern){
    if(!data.vibration) return;
    try{ if(navigator.vibrate) navigator.vibrate(pattern); }catch(e){}
  }

  Game.settings = { get, set, vibrate };
})();
