// Main orchestrator: figures out which level to load, applies that
// level's rule-set (rules.js) on every item touch, and runs the
// update -> draw loop. Character physics live in player.js, item
// collision/drawing in items.js, sound in audio.js — this file only
// wires them together and owns win/pause/game-over state.
window.Game = window.Game || {};

(function(){
  const cfg = Game.config;
  const { ctx, resize, drawBackground } = Game.render;
  const player = Game.player;
  const items = Game.items;
  const ui = Game.ui;
  const audio = Game.audio;

  let level, rule, counts;
  let paused = false, won = false, gameOver = false;
  let timeLeft = null, timerRunning = false, lastT = performance.now();
  let elapsed = 0, started = false;   // real play time (counts up), starts on first move

  function loadLevel(n){
    level = Game.LEVELS[n] || Game.LEVELS[1];
    Game.progress.save(level.id);
    Game.effects.clear();
    rule = Game.RULES[level.rules] || Game.RULES.classic;
    counts = {};
    Object.keys(level.targets).forEach(t => counts[t] = 0);

    items.make(level.layout, level.pickupRadius);
    player.reset();
    paused = false; won = false; gameOver = false;
    timeLeft = level.timeLimit || null; timerRunning = false;
    elapsed = 0; started = false;
    ui.setTimer(timeLeft);

    ui.setLevelLabel(level.label);
    ui.updateCounters(counts);
    ui.hideSettings();
    Game.levelSelect.hide();
    ui.hideWin();
    ui.hideGameOver();

    // Decide right now what the win screen should do once this level is
    // finished — go to the next level if one exists, else just replay.
    const nextId = level.id + 1;
    if(Game.LEVELS[nextId]){
      ui.setWinButton('Next Level', ()=> loadLevel(nextId), true);
    } else {
      ui.setWinButton('Play Again', ()=> loadLevel(level.id), false);   // Replay would be a duplicate
    }
  }
  Game.loadLevel = loadLevel;

  // Audio needs a user gesture to start, and landscape-lock only works
  // after one too — both are attempted on the very first tap.
  document.addEventListener('pointerdown', function once(){
    audio.unlock();
    if(screen.orientation && screen.orientation.lock){
      screen.orientation.lock('landscape').catch(()=>{});
    }
    document.removeEventListener('pointerdown', once);
  }, { once: true });

  resize();
  loadLevel(Game.progress.startLevel());

  ui.bind({
    onSettings: ()=>{ paused = true; },
    onResume: ()=>{ paused = false; },
    onRestart: ()=> loadLevel(level.id),
    onReset: ()=>{ Game.progress.reset(); loadLevel(1); }
  });

  Game.levelSelect.bind({
    onOpen:  ()=>{ paused = true; },
    onClose: ()=>{ paused = false; },
    onPick:  n =>{ if(n === level.id) paused = false; else loadLevel(n); }
  });

  function triggerGameOver(){
    gameOver = true;
    player.reset();          // character turant starting point par wapas
    audio.playGameOver();
    Game.settings.vibrate([60,40,60]);
    Game.effects.shake();
    setTimeout(ui.showGameOver, 150);
  }

  // 3 stars = fast. A level can set its own starTimes: [t3, t2] (seconds);
  // timed levels default to 60% / 90% of their time limit, others use cfg.STAR_TIMES.
  function starsFor(secs){
    const t = level.starTimes ||
      (level.timeLimit ? [level.timeLimit * 0.6, level.timeLimit * 0.9] : cfg.STAR_TIMES);
    return secs <= t[0] ? 3 : secs <= t[1] ? 2 : 1;
  }

  // Saves the best time and returns what the win screen shows.
  function finishStats(){
    const prev = Game.progress.getBest(level.id);
    const best = prev === null ? elapsed : Math.min(prev, elapsed);
    Game.progress.saveBest(level.id, best);
    return { stars: starsFor(elapsed), time: elapsed, best };
  }

  function handleTouch(type){
    const def = Game.itemTypes[type] || { kind: 'goal' };
    let outcome;
    if(def.kind === 'hazard')     outcome = 'gameover';   // e.g. mushroom
    else if(def.kind === 'bonus') outcome = 'bonus';      // e.g. clock
    else outcome = rule.onTouch(type, counts, level.targets, level);

    if(outcome === 'bonus'){
      if(timeLeft !== null){ timeLeft += def.seconds || 0; ui.setTimer(timeLeft); }
      audio.playCollect(type);
      return 'collect';
    }

    if(outcome === 'collect'){
      counts[type]++;
      ui.updateCounters(counts);
      audio.playCollect(type);
      Game.settings.vibrate(15);
      if(rule.isComplete(counts, level.targets)){
        won = true;
        const stats = finishStats();
        audio.playWin();
        Game.settings.vibrate([30,40,30]);
        Game.effects.confetti();
        setTimeout(()=> ui.showWin(stats), 250);
      }
    } else if(outcome === 'gameover'){
      triggerGameOver();
    }
    // 'locked' -> no state change, item stays for later.

    return outcome;
  }

  function update(){
  const now = performance.now();
  const dt = Math.min(100, now - lastT) / 1000;
  lastT = now;
  if(paused) return;
  Game.effects.update();
  player.update();
  if(won || gameOver) return;

  if(!started && (player.obj.moving || !player.obj.onGround)) started = true;
  if(started) elapsed += dt;

  // Timed levels: the countdown starts on the first move or jump.
  if(timeLeft !== null){
    if(!timerRunning && (player.obj.moving || !player.obj.onGround)) timerRunning = true;
    if(timerRunning){
      timeLeft -= dt;
      ui.setTimer(timeLeft);
      if(timeLeft <= 0){ timeLeft = 0; ui.setTimer(0); triggerGameOver(); return; }
    }
  }
  items.update(handleTouch);
}

  function draw(){
    ctx.clearRect(0, 0, cfg.W, cfg.H);
    ctx.save();
    Game.effects.applyShake();
    drawBackground();
    items.draw();
    player.draw();
    Game.effects.draw();
    ctx.restore();
  }

  function loop(){
    update();
    draw();
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
})();
