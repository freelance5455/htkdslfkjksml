// Main orchestrator: figures out which level to load, applies that
// level's rule-set (rules.js) on every item touch, and runs the
// update -> draw loop. Character physics live in player.js, item
// collision/drawing in items.js, sound in audio.js — this file only
// wires them together and owns win/pause/game-over state.
window.Game = window.Game || {};

(function(){
  const cfg = Game.config;
  const { ctx, resize, drawBackground } = Game.render;
  const player = Game.player;
  const items = Game.items;
  const ui = Game.ui;
  const audio = Game.audio;

  let level, rule, counts;
  let paused = false, won = false, gameOver = false;

  function loadLevel(n){
    level = Game.LEVELS[n] || Game.LEVELS[1];
    Game.progress.save(level.id);
    rule = Game.RULES[level.rules] || Game.RULES.classic;
    counts = {};
    Object.keys(level.targets).forEach(t => counts[t] = 0);

    items.make(level.layout, level.pickupRadius);
    player.reset();
    paused = false; won = false; gameOver = false;

    ui.setLevelLabel(level.label);
    ui.updateCounters(counts);
    ui.hideSettings();
    ui.hideWin();
    ui.hideGameOver();

    // Decide right now what the win screen should do once this level is
    // finished — go to the next level if one exists, else just replay.
    const nextId = level.id + 1;
    if(Game.LEVELS[nextId]){
      ui.setWinMessage(level.label + ' complete! Get ready for ' + Game.LEVELS[nextId].label + '.');
      ui.setWinButton('Next Level ▶', ()=> loadLevel(nextId));
    } else {
      ui.setWinMessage('You gathered everything in the meadow.');
      ui.setWinButton('Play Again', ()=> loadLevel(level.id));
    }
  }
  Game.loadLevel = loadLevel;

  // Audio needs a user gesture to start, and landscape-lock only works
  // after one too — both are attempted on the very first tap.
  document.addEventListener('pointerdown', function once(){
    audio.unlock();
    if(screen.orientation && screen.orientation.lock){
      screen.orientation.lock('landscape').catch(()=>{});
    }
    document.removeEventListener('pointerdown', once);
  }, { once: true });

  resize();
  loadLevel(Game.progress.startLevel());

  ui.bind({
    onSettings: ()=>{ paused = true; },
    onResume: ()=>{ paused = false; },
    onRestart: ()=> loadLevel(level.id),
    onReset: ()=>{ Game.progress.reset(); loadLevel(1); }
  });

  function handleTouch(type){
    const outcome = rule.onTouch(type, counts, level.targets);

    if(outcome === 'collect'){
      counts[type]++;
      ui.updateCounters(counts);
      audio.playCollect(type);
      Game.settings.vibrate(15);
      if(rule.isComplete(counts, level.targets)){
        won = true;
        audio.playWin();
        Game.settings.vibrate([30,40,30]);
        setTimeout(ui.showWin, 250);
      }
    } else if(outcome === 'gameover'){
      gameOver = true;
      player.reset();          // character turant starting point par wapas
      audio.playGameOver();
      Game.settings.vibrate([60,40,60]);
      setTimeout(ui.showGameOver, 150);
    }
    // 'locked' -> no state change, item stays for later.

    return outcome;
  }

  function update(){
  if(paused) return;
  player.update();
  if(won || gameOver) return;
  items.update(handleTouch);
}

  function draw(){
    ctx.clearRect(0, 0, cfg.W, cfg.H);
    drawBackground();
    items.draw();
    player.draw();
  }

  function loop(){
    update();
    draw();
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
})();
