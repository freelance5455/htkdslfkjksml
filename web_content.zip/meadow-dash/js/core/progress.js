// Saves/loads the player's furthest level on this device (localStorage).
// Everything about progress lives here; game.js only calls these.
window.Game = window.Game || {};

(function(){
  const SAVE_KEY = 'ferg_level';

  // Furthest level reached. If the saved level no longer exists, falls
  // back to the highest level that does.
  function get(){
    try{
      const n = parseInt(localStorage.getItem(SAVE_KEY), 10);
      if(Game.LEVELS[n]) return n;
      return n > 1 ? Math.max(...Object.keys(Game.LEVELS).map(Number)) : 1;
    }catch(e){ return 1; }
  }

  // Only ever moves forward.
  function save(n){
    try{
      if(n > get()) localStorage.setItem(SAVE_KEY, String(n));
    }catch(e){}
  }

  // ?level=N in the URL wins (for testing), else the saved level.
  function startLevel(){
    const n = parseInt(new URLSearchParams(location.search).get('level'), 10);
    return Game.LEVELS[n] ? n : get();
  }

  // Back to Level 1 (used by Reset Progress in settings).
  function reset(){
    try{ localStorage.removeItem(SAVE_KEY); }catch(e){}
  }

  Game.progress = { get, save, startLevel, reset };
})();
