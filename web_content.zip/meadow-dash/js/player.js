// Everything about the character: input, physics/movement, and drawing.
window.Game = window.Game || {};

(function(){
  const cfg = Game.config;
  const ctx = Game.render.ctx;
  const GROUND_Y = cfg.H * cfg.GROUND_FRAC;

  const player = {
    x: 60, footY: GROUND_Y, vy: 0, onGround: true,
    facing: 1, moving: false
  };

  let heldLeft = false, heldRight = false;

  // --- Sprite sheets (Idle / Walk / Jump) -----------------------------
  // Each sheet is a horizontal strip of square frames, all the same
  // size. Jump isn't time-looped — its 4 frames map directly to the
  // player's vertical speed, so the pose always matches what's actually
  // happening physically (launch / rising / floaty / falling).
  const SHEETS = {
    idle: { img: new Image(), frames: 6 },
    walk: { img: new Image(), frames: 6 },
    jump: { img: new Image(), frames: 4 }
  };
  SHEETS.idle.img.src = 'assets/character/idle_sheet.png';
  SHEETS.walk.img.src = 'assets/character/walk_sheet.png';
  SHEETS.jump.img.src = 'assets/character/jump_sheet.png';

  const FRAME_SRC     = 300;   // native px per frame inside each sheet
  const DISPLAY_SIZE   = 100;  // drawn size in game-world units (matches the old vector character's scale)
  const FEET_FRACTION  = 0.90; // each frame's feet sit 90% of the way down
  const ANIM_HOLD      = 6;    // game-loop ticks per idle/walk animation frame

  let animFrame = 0, animCounter = 0;

  function pickSheet(){
    if(!player.onGround){
      const vy = player.vy;
      let idx;
      if(vy <= -6.5) idx = 0;       // explosive launch
      else if(vy <= 0) idx = 1;     // still rising, slowing down
      else if(vy <= 6.5) idx = 2;   // floaty apex
      else idx = 3;                 // falling toward the ground
      return { sheet: SHEETS.jump, idx };
    }
    if(player.moving) return { sheet: SHEETS.walk, idx: animFrame % SHEETS.walk.frames };
    return { sheet: SHEETS.idle, idx: animFrame % SHEETS.idle.frames };
  }

  function jump(){
    if(player.onGround){
      player.vy = cfg.JUMP_V;
      player.onGround = false;
      Game.audio.playJump();
    }
  }

  function bindHold(el, onDown, onUp){
    const down = e=>{
      e.preventDefault();
      el.setPointerCapture(e.pointerId);
      onDown();
    };
    const up = e=>{ e.preventDefault(); onUp(); };
    el.addEventListener('pointerdown', down);
    el.addEventListener('pointerup', up);
    el.addEventListener('pointercancel', up);
  }
  bindHold(document.getElementById('btnLeft'), ()=>heldLeft=true, ()=>heldLeft=false);
  bindHold(document.getElementById('btnRight'), ()=>heldRight=true, ()=>heldRight=false);
  document.getElementById('btnJump').addEventListener('pointerdown', e=>{ e.preventDefault(); jump(); });

  window.addEventListener('keydown', e=>{
    if(['ArrowLeft','a','A'].includes(e.key)) heldLeft = true;
    if(['ArrowRight','d','D'].includes(e.key)) heldRight = true;
    if(['ArrowUp','w','W',' '].includes(e.key)){ e.preventDefault(); jump(); }
  });
  window.addEventListener('keyup', e=>{
    if(['ArrowLeft','a','A'].includes(e.key)) heldLeft = false;
    if(['ArrowRight','d','D'].includes(e.key)) heldRight = false;
  });

  function update(){
    if(heldLeft && !heldRight){ player.x -= cfg.SPEED; player.facing = -1; player.moving = true; }
    else if(heldRight && !heldLeft){ player.x += cfg.SPEED; player.facing = 1; player.moving = true; }
    else { player.moving = false; }
    player.x = Math.max(cfg.MARGIN_X, Math.min(cfg.W - cfg.MARGIN_X, player.x));

    player.vy += cfg.GRAVITY;
    player.footY += player.vy;
    if(player.footY >= GROUND_Y){
      player.footY = GROUND_Y;
      player.vy = 0;
      player.onGround = true;
    }

    animCounter++;
    if(animCounter >= ANIM_HOLD){
      animCounter = 0;
      animFrame++;
    }
  }

  // World-space Y of the player's body center, used for item collision.
  function centerY(){
    const jumpOffset = GROUND_Y - player.footY;
    return (GROUND_Y - jumpOffset) - 34;
  }

  function reset(){
    player.x = 60;
    player.footY = GROUND_Y;
    player.vy = 0;
    player.onGround = true;
  }

  function draw(){
    const jumpOffset = GROUND_Y - player.footY;
    ctx.save();
    ctx.translate(player.x, player.footY);
    ctx.scale(player.facing, 1);

    // ground shadow (still drawn procedurally — no sprite needed for this)
    ctx.save();
    const shadowScale = Math.max(0.35, 1 - jumpOffset/160);
    ctx.globalAlpha = 0.25 * shadowScale;
    ctx.fillStyle = '#1f3f2b';
    ctx.beginPath();
    ctx.ellipse(0, 2, 22*shadowScale, 6*shadowScale, 0, 0, Math.PI*2);
    ctx.fill();
    ctx.restore();

    ctx.translate(0, -jumpOffset);

    const { sheet, idx } = pickSheet();
    if(sheet.img.complete && sheet.img.naturalWidth){
      ctx.drawImage(
        sheet.img,
        idx * FRAME_SRC, 0, FRAME_SRC, FRAME_SRC,
        -DISPLAY_SIZE / 2, -DISPLAY_SIZE * FEET_FRACTION, DISPLAY_SIZE, DISPLAY_SIZE
      );
    }

    ctx.restore();
  }

  Game.player = { obj: player, GROUND_Y, jump, update, draw, centerY, reset };
})();
