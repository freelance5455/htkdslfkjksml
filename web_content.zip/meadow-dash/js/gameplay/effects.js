// Visual effects (particles drawn on the game canvas):
//   dust     - small puffs when the player jumps or lands
//   confetti - falling confetti when a level is completed
//   shake    - short screen shake on Game Over
// Everything is frame-based, like the rest of the game, and capped so it
// stays smooth on low-end phones.
window.Game = window.Game || {};

(function(){
  const cfg = Game.config;
  const { ctx } = Game.render;
  const MAX = 260;

  const CONFETTI = ['#ffd23f','#ff5a4a','#ff6f91','#4fc3f7','#7bd957','#c792ea'];

  let parts = [];
  let shakeLeft = 0, shakeMag = 0;

  const rand = (a, b) => a + Math.random() * (b - a);
  function add(p){ if(parts.length < MAX) parts.push(p); }

  function dust(x, y, n){
    for(let i = 0; i < (n || 6); i++){
      add({ kind:'dot', x:x + rand(-8, 8), y:y - 2,
            vx:rand(-1.8, 1.8), vy:rand(-0.9, -0.2), g:0,
            size:rand(3, 6), life:rand(18, 28), max:28, color:'#efe6cf' });
    }
  }

  function confetti(){
    for(let i = 0; i < 80; i++){
      add({ kind:'rect', x:rand(0, cfg.W), y:rand(-80, -10),
            vx:rand(-1.2, 1.2), vy:rand(2, 4.2), g:0.02,
            size:rand(5, 9), rot:rand(0, 6.28), vr:rand(-0.2, 0.2),
            life:rand(110, 170), max:170, color:CONFETTI[(Math.random()*CONFETTI.length)|0] });
    }
  }

  function shake(frames, mag){ shakeLeft = frames || 14; shakeMag = mag || 7; }
  function clear(){ parts = []; shakeLeft = 0; }

  function update(){
    for(const p of parts){
      p.life--;
      p.x += p.vx; p.y += p.vy; p.vy += p.g;
      if(p.kind === 'rect') p.rot += p.vr;
    }
    parts = parts.filter(p => p.life > 0);
    if(shakeLeft > 0) shakeLeft--;
  }

  // Call between ctx.save() and drawing the scene.
  function applyShake(){
    if(shakeLeft <= 0) return;
    const m = shakeMag * (shakeLeft / 14);
    ctx.translate(rand(-m, m), rand(-m, m));
  }

  function draw(){
    for(const p of parts){
      ctx.globalAlpha = Math.max(0, Math.min(1, p.life / p.max));
      ctx.fillStyle = p.color;
      if(p.kind === 'dot'){
        ctx.beginPath(); ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2); ctx.fill();
      } else if(p.kind === 'rect'){
        ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
        ctx.fillRect(-p.size / 2, -p.size / 3, p.size, p.size * 0.66);
        ctx.restore();
      }
    }
    ctx.globalAlpha = 1;
  }

  Game.effects = { dust, confetti, shake, clear, update, applyShake, draw };
})();
