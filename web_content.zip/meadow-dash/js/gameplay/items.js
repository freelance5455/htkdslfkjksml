// Collectible items: collision with the player, and drawing them (emoji
// + a soft glow so they read clearly). The actual layout/pickup-radius
// come from whichever level is currently loaded (see levels.js) — this
// file has no level-specific data of its own.
window.Game = window.Game || {};

(function(){
  const ctx = Game.render.ctx;
  const GROUND_Y = Game.player.GROUND_Y;
  const TYPES = Game.itemTypes;

  let items = [];
  let pickupRadius = 46;

  function make(layout, radius){
    pickupRadius = radius || 46;
    // layout entry: [type, x, elevated, opts]  where opts (optional) is
    //   { move:  { axis:'x'|'y', range, speed, phase } }  -> item slides back and forth
    //   { blink: { on, off, phase } }                      -> item appears / disappears (frames)
    items = layout.map(([type,x,elevated,opts], i)=> {
      const y = GROUND_Y - (elevated ? 112 : 34);
      return {
        id: i, type, x, elevated, y,
        baseX: x, baseY: y, t: 0, visible: true,
        move: opts && opts.move, blink: opts && opts.blink,
        collected: false,
        bob: Math.random() * Math.PI * 2
      };
    });
    return items;
  }

  // onTouch(type) must return 'collect' | 'locked' | 'gameover'.
  // Only 'collect' actually removes the item — 'locked' leaves it
  // exactly where it is so it can still be collected later once the
  // current level's rules allow it (e.g. after tomatoes unlock stars).
  function update(onTouch){
    const pCenterY = Game.player.centerY();
    const px = Game.player.obj.x;
    for(const it of items){
      if(it.collected) continue;
      it.bob += 0.08;
      it.t++;
      if(it.move){
        const m = it.move, a = it.t * m.speed + (m.phase || 0);
        if(m.axis === 'x') it.x = it.baseX + Math.sin(a) * m.range;
        else               it.y = it.baseY + Math.sin(a) * m.range;
      }
      if(it.blink){
        const b = it.blink;
        it.visible = ((it.t + (b.phase || 0)) % (b.on + b.off)) < b.on;
        if(!it.visible) continue;      // hidden items can't be touched
      }
      const dx = px - it.x, dy = pCenterY - it.y;
      if(Math.sqrt(dx*dx + dy*dy) < pickupRadius){
        const outcome = onTouch(it.type, it);
        if(outcome === 'collect') it.collected = true;
      }
    }
  }

  function draw(){
    for(const it of items){
      if(it.collected) continue;
      const cx = it.x, cy = it.y + Math.sin(it.bob) * 4;
      const def = TYPES[it.type];

      if(!it.visible){            // blinking item that is currently hidden: faint ghost
        ctx.save();
        ctx.globalAlpha = 0.25;
        ctx.beginPath(); ctx.arc(cx, cy, 19, 0, Math.PI*2);
        ctx.fillStyle = '#fff'; ctx.fill();
        ctx.restore();
        continue;
      }

      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, 19, 0, Math.PI*2);
      ctx.fillStyle = def.glow || 'rgba(255,255,255,0.65)';
      ctx.shadowColor = 'rgba(0,0,0,.18)';
      ctx.shadowBlur = 6;
      ctx.shadowOffsetY = 2;
      ctx.fill();
      ctx.restore();

      ctx.save();
      ctx.font = '30px serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(def.emoji, cx, cy + 1);
      ctx.restore();
    }
  }

  Game.items = { make, update, draw };
})();
