// Everything about the character: input, physics/movement, and drawing.
window.Game = window.Game || {};

(function(){
  const cfg = Game.config;
  const ctx = Game.render.ctx;
  const GROUND_Y = cfg.H * cfg.GROUND_FRAC;

  const player = {
    x: 60, footY: GROUND_Y, vy: 0, onGround: true,
    facing: 1, moving: false
  };

  let heldLeft = false, heldRight = false;

  function jump(){
    if(player.onGround){
      player.vy = cfg.JUMP_V;
      player.onGround = false;
      Game.audio.playJump();
      Game.effects && Game.effects.dust(player.x, player.footY);
    }
  }

  function bindHold(el, onDown, onUp){
    const down = e=>{
      e.preventDefault();
      el.setPointerCapture(e.pointerId);
      onDown();
    };
    const up = e=>{ e.preventDefault(); onUp(); };
    el.addEventListener('pointerdown', down);
    el.addEventListener('pointerup', up);
    el.addEventListener('pointercancel', up);
  }
  bindHold(document.getElementById('btnLeft'), ()=>heldLeft=true, ()=>heldLeft=false);
  bindHold(document.getElementById('btnRight'), ()=>heldRight=true, ()=>heldRight=false);
  document.getElementById('btnJump').addEventListener('pointerdown', e=>{ e.preventDefault(); jump(); });

  window.addEventListener('keydown', e=>{
    if(['ArrowLeft','a','A'].includes(e.key)) heldLeft = true;
    if(['ArrowRight','d','D'].includes(e.key)) heldRight = true;
    if(['ArrowUp','w','W',' '].includes(e.key)){ e.preventDefault(); jump(); }
  });
  window.addEventListener('keyup', e=>{
    if(['ArrowLeft','a','A'].includes(e.key)) heldLeft = false;
    if(['ArrowRight','d','D'].includes(e.key)) heldRight = false;
  });

  function update(){
    if(heldLeft && !heldRight){ player.x -= cfg.SPEED; player.facing = -1; player.moving = true; }
    else if(heldRight && !heldLeft){ player.x += cfg.SPEED; player.facing = 1; player.moving = true; }
    else { player.moving = false; }
    player.x = Math.max(cfg.MARGIN_X, Math.min(cfg.W - cfg.MARGIN_X, player.x));

    const wasOnGround = player.onGround;
    player.vy += cfg.GRAVITY;
    player.footY += player.vy;
    if(player.footY >= GROUND_Y){
      player.footY = GROUND_Y;
      player.vy = 0;
      player.onGround = true;
      if(!wasOnGround && Game.effects) Game.effects.dust(player.x, player.footY, 8);
    }
  }

  // World-space Y of the player's body center, used for item collision.
  function centerY(){
    const jumpOffset = GROUND_Y - player.footY;
    return (GROUND_Y - jumpOffset) - 34;
  }

  function reset(){
    player.x = 60;
    player.footY = GROUND_Y;
    player.vy = 0;
    player.onGround = true;
  }

  function draw(){
    const jumpOffset = GROUND_Y - player.footY;
    const squash = player.onGround ? (player.moving ? 1 + Math.sin(Date.now()/90)*0.03 : 1) : 1.06;
    ctx.save();
    ctx.translate(player.x, player.footY);
    ctx.scale(player.facing * (1/squash), squash);

    // ground shadow
    ctx.save();
    const shadowScale = Math.max(0.35, 1 - jumpOffset/160);
    ctx.globalAlpha = 0.25 * shadowScale;
    ctx.fillStyle = '#1f3f2b';
    ctx.beginPath();
    ctx.ellipse(0, 2, 22*shadowScale, 6*shadowScale, 0, 0, Math.PI*2);
    ctx.fill();
    ctx.restore();

    ctx.translate(0, -jumpOffset);

    // legs
    ctx.fillStyle = '#e8974e';
    ctx.beginPath();
    ctx.roundRect(-14,-14,10,16,4);
    ctx.roundRect(4,-14,10,16,4);
    ctx.fill();

    // body
    ctx.fillStyle = '#ffb066';
    ctx.strokeStyle = '#a85c22';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.ellipse(0,-40,26,30,0,0,Math.PI*2);
    ctx.fill(); ctx.stroke();

    // belly
    ctx.fillStyle = '#fff3df';
    ctx.beginPath();
    ctx.ellipse(0,-32,15,16,0,0,Math.PI*2);
    ctx.fill();

    // arms
    ctx.fillStyle = '#ffb066';
    ctx.strokeStyle = '#a85c22';
    ctx.beginPath();
    ctx.ellipse(-24,-38,7,12, 0.4, 0, Math.PI*2);
    ctx.fill(); ctx.stroke();
    ctx.beginPath();
    ctx.ellipse(24,-38,7,12, -0.4, 0, Math.PI*2);
    ctx.fill(); ctx.stroke();

    // eyes
    ctx.fillStyle = '#2b2b2b';
    ctx.beginPath();
    ctx.arc(9,-46,3.2,0,Math.PI*2);
    ctx.fill();

    // cheek
    ctx.fillStyle = 'rgba(255,110,90,.55)';
    ctx.beginPath();
    ctx.arc(2,-38,4,0,Math.PI*2);
    ctx.fill();

    // leaf on head
    ctx.fillStyle = '#5fae5a';
    ctx.strokeStyle = '#2f5c3f';
    ctx.beginPath();
    ctx.ellipse(-4,-66,8,12,-0.3,0,Math.PI*2);
    ctx.fill(); ctx.stroke();

    ctx.restore();
  }

  Game.player = { obj: player, GROUND_Y, jump, update, draw, centerY, reset };
})();
