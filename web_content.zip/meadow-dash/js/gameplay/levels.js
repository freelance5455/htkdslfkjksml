// All level-specific data lives here: item layout, how many of each type
// are needed, the pickup radius, and which rule-set (see rules.js)
// governs it. To add Level 3, just add a new numbered entry below —
// nothing in game.js, player.js or items.js needs to change.
//
// Note: this is written as plain JS (not a .json file) on purpose —
// opening index.html directly by double-click uses the file:// protocol,
// and browsers block fetch()-ing local JSON files from there. Keeping it
// as a script tag means the game still works with zero setup. If you
// later serve this folder from a real web server, the object below is
// already valid JSON — you can drop it straight into levels.json and
// swap this file for a fetch() call.
window.Game = window.Game || {};

Game.LEVELS = {
  1: {
    id: 1,
    label: 'Level 1',
    targets: { star: 3, tomato: 3, berry: 3 },
    pickupRadius: 46,
    rules: 'classic',
    layout: [
      ['berry',128,false], ['star',216,true],  ['tomato',304,false],
      ['star',392,true],   ['berry',480,false],['tomato',568,true],
      ['star',656,false],  ['tomato',744,false],['berry',832,true]
    ]
  },

  2: {
    id: 2,
    label: 'Level 2',
    targets: { tomato: 3, star: 3, berry: 3 },
    pickupRadius: 32,
    rules: 'level2',
    // Tomatoes and stars sit close together on purpose — the player has
    // to thread between them carefully before the stars unlock.
    layout: [
      ['tomato',128,false], ['star',216,true],  ['tomato',304,false],
      ['berry',392,false],  ['star',480,true],  ['tomato',568,false],
      ['berry',656,false],  ['star',744,true],  ['berry',832,false]
    ]
  },

  3: {
    id: 3,
    label: 'Level 3',
    targets: { berry: 3, tomato: 3, star: 3 },
    pickupRadius: 32,
    rules: 'level3',
    // Reverse of Level 2: berries are the safe item this time. Stars and
    // tomatoes are live wires until unlocked: all berries unlock stars,
    // and all stars unlock tomatoes (berry -> star -> tomato).
    layout: [
      ['berry',128,false],  ['tomato',216,true], ['berry',304,false],
      ['star',392,true],    ['tomato',480,false],['berry',568,true],
      ['star',656,false],   ['tomato',744,true], ['star',832,true]
    ]
  },

  // Level 4: Poison. Normal collecting, but the 🍄 mushrooms on the ground
  // are Game Over. Jump over them.
  4: {
    id: 4, label: 'Level 4',
    targets: { star: 3, tomato: 3, berry: 3 },
    pickupRadius: 32,
    rules: 'classic',
    layout: [
      ['berry',128,false],   ['mushroom',172,false], ['star',216,true],
      ['tomato',304,false],  ['star',392,true],      ['berry',480,false],
      ['mushroom',524,false],['tomato',568,true],    ['star',656,false],
      ['tomato',744,false],  ['mushroom',788,false], ['berry',832,true]
    ]
  },

  // Level 5: Time Attack. Collect everything before the timer runs out.
  // The timer starts on the first move.
  5: {
    id: 5, label: 'Level 5',
    targets: { tomato: 3, star: 3, berry: 3 },
    pickupRadius: 32,
    rules: 'classic',
    timeLimit: 12,
    layout: [
      ['tomato',128,false], ['star',216,true],   ['berry',304,false],
      ['tomato',392,true],  ['star',480,false],  ['berry',568,true],
      ['tomato',656,false], ['star',744,true],   ['berry',832,false]
    ]
  },

  // Level 6: Moving Items. Stars bob up and down, berries slide sideways.
  6: {
    id: 6, label: 'Level 6',
    targets: { tomato: 3, star: 3, berry: 3 },
    pickupRadius: 34,
    rules: 'classic',
    layout: [
      ['tomato',128,false],
      ['star',216,true,  { move:{ axis:'y', range:22, speed:0.05,  phase:0 } }],
      ['berry',304,false,{ move:{ axis:'x', range:40, speed:0.03,  phase:0 } }],
      ['tomato',392,true],
      ['star',480,true,  { move:{ axis:'y', range:22, speed:0.045, phase:1 } }],
      ['berry',568,false,{ move:{ axis:'x', range:40, speed:0.032, phase:2 } }],
      ['tomato',656,false],
      ['star',744,true,  { move:{ axis:'y', range:22, speed:0.05,  phase:3 } }],
      ['berry',832,true, { move:{ axis:'y', range:20, speed:0.04,  phase:0 } }]
    ]
  },

  // Level 7: Blinking. Tomatoes and berries appear and disappear.
  // A faint ghost circle shows where a hidden item will come back.
  7: {
    id: 7, label: 'Level 7',
    targets: { tomato: 3, star: 3, berry: 3 },
    pickupRadius: 32,
    rules: 'classic',
    layout: [
      ['berry',128,false, { blink:{ on:100, off:70, phase:0   } }],
      ['star',216,true],
      ['tomato',304,false,{ blink:{ on:100, off:70, phase:40  } }],
      ['star',392,true],
      ['berry',480,false, { blink:{ on:100, off:70, phase:80  } }],
      ['tomato',568,true, { blink:{ on:100, off:70, phase:120 } }],
      ['star',656,false],
      ['tomato',744,false,{ blink:{ on:100, off:70, phase:20  } }],
      ['berry',832,true,  { blink:{ on:100, off:70, phase:60  } }]
    ]
  },

  // Level 8: Order + Poison. 🍅 first, then ⭐, then 🍓. Wrong order or a
  // mushroom is Game Over. The order is not shown on screen.
  8: {
    id: 8, label: 'Level 8',
    targets: { tomato: 3, star: 3, berry: 3 },
    pickupRadius: 32,
    rules: 'order',
    order: ['tomato', 'star', 'berry'],
    layout: [
      ['tomato',128,false],  ['star',216,true],      ['berry',304,true],
      ['tomato',392,true],   ['mushroom',418,false], ['star',480,false],
      ['berry',568,true],    ['tomato',656,false],   ['star',744,true],
      ['mushroom',748,false],['berry',832,false]
    ]
  },

  // Level 9: Time + Moving + Poison. A ⏰ clock gives +5 seconds.
  9: {
    id: 9, label: 'Level 9',
    targets: { tomato: 3, star: 3, berry: 3 },
    pickupRadius: 32,
    rules: 'classic',
    timeLimit: 14,
    layout: [
      ['tomato',128,false,{ move:{ axis:'x', range:30, speed:0.03, phase:0 } }],
      ['star',216,true,   { move:{ axis:'y', range:20, speed:0.05, phase:1 } }],
      ['berry',304,false],
      ['mushroom',348,false],
      ['tomato',392,true],
      ['star',480,true,   { move:{ axis:'y', range:20, speed:0.045,phase:2 } }],
      ['mushroom',524,false],
      ['berry',568,false],
      ['tomato',656,false],
      ['clock',700,true],
      ['star',744,true,   { move:{ axis:'y', range:20, speed:0.05, phase:3 } }],
      ['mushroom',788,false],
      ['berry',832,false]
    ]
  },

  // Level 10: Finale. Order 🍓 → 🍅 → ⭐, mushrooms, moving stars and a timer.
  // ⏰ clocks give +5 seconds.
  10: {
    id: 10, label: 'Level 10',
    targets: { berry: 3, tomato: 3, star: 3 },
    pickupRadius: 32,
    rules: 'order',
    order: ['berry', 'tomato', 'star'],
    timeLimit: 28,
    layout: [
      ['berry',128,false],   ['tomato',216,true],
      ['star',304,true,   { move:{ axis:'y', range:20, speed:0.05, phase:0 } }],
      ['berry',392,true],    ['mushroom',430,false], ['tomato',480,false],
      ['star',568,true,   { move:{ axis:'y', range:20, speed:0.045,phase:2 } }],
      ['clock',612,true],    ['berry',656,false],    ['tomato',744,true],
      ['mushroom',782,false],['star',832,false]
    ]
  }
};
