// Every kind of object that can appear in a level.
//   goal   - counts toward the level targets (star, tomato, berry)
//   hazard - touching it is Game Over (mushroom)
//   bonus  - optional pickup; a clock adds seconds in timed levels
window.Game = window.Game || {};

Game.itemTypes = {
  star:     { emoji:'⭐', kind:'goal' },
  tomato:   { emoji:'🍅', kind:'goal' },
  berry:    { emoji:'🍓', kind:'goal' },
  mushroom: { emoji:'🍄', kind:'hazard', glow:'rgba(255,90,90,.65)' },
  clock:    { emoji:'⏰', kind:'bonus', seconds:5, glow:'rgba(120,190,255,.8)' }
};
