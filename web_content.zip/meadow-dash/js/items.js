// Collectible items: collision with the player, and drawing them (emoji
// + a soft glow so they read clearly). The actual layout/pickup-radius
// come from whichever level is currently loaded (see levels.js) — this
// file has no level-specific data of its own.
window.Game = window.Game || {};

(function(){
  const ctx = Game.render.ctx;
  const GROUND_Y = Game.player.GROUND_Y;
  const EMOJI = { star:'⭐', tomato:'🍅', berry:'🍓' };

  let items = [];
  let pickupRadius = 46;

  function make(layout, radius){
    pickupRadius = radius || 46;
    items = layout.map(([type,x,elevated], i)=> ({
      id: i, type, x, elevated,
      y: GROUND_Y - (elevated ? 112 : 34),
      collected: false,
      bob: Math.random() * Math.PI * 2
    }));
    return items;
  }

  // onTouch(type) must return 'collect' | 'locked' | 'gameover'.
  // Only 'collect' actually removes the item — 'locked' leaves it
  // exactly where it is so it can still be collected later once the
  // current level's rules allow it (e.g. after tomatoes unlock stars).
  function update(onTouch){
    const pCenterY = Game.player.centerY();
    const px = Game.player.obj.x;
    for(const it of items){
      if(it.collected) continue;
      it.bob += 0.08;
      const dx = px - it.x, dy = pCenterY - it.y;
      if(Math.sqrt(dx*dx + dy*dy) < pickupRadius){
        const outcome = onTouch(it.type, it);
        if(outcome === 'collect') it.collected = true;
      }
    }
  }

  function draw(){
    for(const it of items){
      if(it.collected) continue;
      const cx = it.x, cy = it.y + Math.sin(it.bob) * 4;

      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, 19, 0, Math.PI*2);
      ctx.fillStyle = 'rgba(255,255,255,0.65)';
      ctx.shadowColor = 'rgba(0,0,0,.18)';
      ctx.shadowBlur = 6;
      ctx.shadowOffsetY = 2;
      ctx.fill();
      ctx.restore();

      ctx.save();
      ctx.font = '30px serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(EMOJI[it.type], cx, cy + 1);
      ctx.restore();
    }
  }

  Game.items = { make, update, draw };
})();
