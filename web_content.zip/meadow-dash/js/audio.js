// All sound effects + background music are synthesized with the Web
// Audio API (no sound files needed). One mute flag controls everything.
window.Game = window.Game || {};

(function(){
  let ctx = null;
  let muted = false;
  let musicRunning = false;
  let musicTimer = null;
  let nextNoteTime = 0;
  let step = 0;

  function ensureCtx(){
    if(!ctx){
      const AC = window.AudioContext || window.webkitAudioContext;
      ctx = new AC();
    }
    if(ctx.state === 'suspended') ctx.resume();
    return ctx;
  }

  function tone(freq, duration, type, startTime, peak){
    const ac = ensureCtx();
    const osc = ac.createOscillator();
    const gain = ac.createGain();
    osc.type = type || 'sine';
    osc.frequency.setValueAtTime(freq, startTime);
    gain.gain.setValueAtTime(0, startTime);
    gain.gain.linearRampToValueAtTime(peak || 0.2, startTime + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);
    osc.connect(gain).connect(ac.destination);
    osc.start(startTime);
    osc.stop(startTime + duration + 0.02);
  }

  function playJump(){
    if(muted) return;
    const t = ensureCtx().currentTime;
    tone(440, 0.12, 'triangle', t, 0.18);
    tone(660, 0.10, 'triangle', t + 0.05, 0.12);
  }

  function playCollect(type){
    if(muted) return;
    const t = ensureCtx().currentTime;
    const notes = { star:[880,1320], tomato:[660,990], berry:[740,1108] };
    const pair = notes[type] || [700,1000];
    tone(pair[0], 0.10, 'sine', t, 0.2);
    tone(pair[1], 0.14, 'sine', t + 0.06, 0.18);
  }

  function playWin(){
    if(muted) return;
    const t = ensureCtx().currentTime;
    [523,659,784,1047].forEach((f,i)=> tone(f, 0.22, 'triangle', t + i*0.12, 0.2));
  }

  function playGameOver(){
    if(muted) return;
    const t = ensureCtx().currentTime;
    [392,349,293].forEach((f,i)=> tone(f, 0.28, 'sawtooth', t + i*0.15, 0.16));
  }

  // Gentle looping pentatonic arpeggio, scheduled a bit ahead of time so
  // it stays smooth even if the browser throttles background tabs.
  const SCALE = [392, 440, 523, 587, 659, 784];

  function scheduler(){
    if(!musicRunning) return;
    const ac = ensureCtx();
    while(nextNoteTime < ac.currentTime + 0.6){
      if(!muted){
        tone(SCALE[step % SCALE.length] / 2, 0.5, 'sine', nextNoteTime, 0.05);
      }
      nextNoteTime += 0.55;
      step++;
    }
    musicTimer = setTimeout(scheduler, 150);
  }

  function startMusic(){
    if(musicRunning) return;
    musicRunning = true;
    nextNoteTime = ensureCtx().currentTime + 0.1;
    step = 0;
    scheduler();
  }

  function stopMusic(){
    musicRunning = false;
    clearTimeout(musicTimer);
  }

  function toggleMute(){
    muted = !muted;
    return muted;
  }

  function isMuted(){ return muted; }

  // Browsers block audio before a user gesture — call this on first tap.
  function unlock(){
    ensureCtx();
    startMusic();
  }

  // --- UI click sound -----------------------------------------------
  // Every on-screen button (settings, resume, restart, next level/play
  // again, try again, mute, and the left/right/jump controls) uses this
  // one real audio file instead of a synthesized tone. cloneNode() lets
  // fast repeated taps overlap instead of cutting each other off.
  const clickSound = new Audio('assets/audio/button_click.mp3');
  clickSound.preload = 'auto';

  function playClick(){
    if(muted) return;
    const node = clickSound.cloneNode(true);
    node.volume = 0.55;
    node.play().catch(()=>{});
  }

  // Wire it to every menu/HUD button (settings, resume, restart, next
  // level/play again, try again, mute) — NOT the left/right/jump move
  // controls, which stay as they were. Buttons are already in the DOM
  // by the time this script runs (it's loaded at the bottom of
  // index.html), and this also automatically covers any new menu
  // button added later without needing to touch this file again.
  function bindClickSounds(){
    document.querySelectorAll('button:not(#btnLeft):not(#btnRight):not(#btnJump)').forEach(btn=>{
      btn.addEventListener('pointerdown', playClick);
    });
  }
  bindClickSounds();

  Game.audio = { playJump, playCollect, playWin, playGameOver, playClick, toggleMute, isMuted, unlock, startMusic, stopMusic };
})();
