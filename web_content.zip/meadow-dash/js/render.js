// Canvas setup + the "cover fit" math that scales the fixed 960x540
// world onto any real screen size without ever stretching the art.
window.Game = window.Game || {};

(function(){
  const cfg = Game.config;
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  const stage = document.getElementById('stage');

  const bg = new Image();
  bg.src = 'assets/background.png';

  function resize(){
    const rect = stage.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    const dispW = rect.width, dispH = rect.height;
    canvas.width = Math.round(dispW * dpr);
    canvas.height = Math.round(dispH * dpr);
    const scale = Math.max(dispW / cfg.W, dispH / cfg.H);
    const offX = (dispW - cfg.W * scale) / 2;
    const offY = (dispH - cfg.H * scale) / 2;
    ctx.setTransform(dpr * scale, 0, 0, dpr * scale, dpr * offX, dpr * offY);
  }
  window.addEventListener('resize', resize);
  window.addEventListener('orientationchange', ()=> setTimeout(resize, 60));

  function drawBackground(){
    if(bg.complete && bg.naturalWidth){
      ctx.drawImage(bg, 0, 0, cfg.W, cfg.H);
    } else {
      ctx.fillStyle = '#8fd3ef';
      ctx.fillRect(0, 0, cfg.W, cfg.H);
    }
  }

  Game.render = { ctx, canvas, resize, drawBackground };
})();
