// Main orchestrator: figures out which level to load, applies that
// level's rule-set (rules.js) on every item touch, and runs the
// update -> draw loop. Character physics live in player.js, item
// collision/drawing in items.js, sound in audio.js — this file only
// wires them together and owns win/pause/game-over state.
window.Game = window.Game || {};

(function(){
  const cfg = Game.config;
  const { ctx, resize, drawBackground } = Game.render;
  const player = Game.player;
  const items = Game.items;
  const ui = Game.ui;
  const audio = Game.audio;

  let level, rule, counts;
  let paused = false, won = false, gameOver = false;
  let timeLeft = null, timerRunning = false, resetCooldown = 0;

  // Level 1 is the default. Test/play another level with ?level=2 in
  // the URL, or call Game.loadLevel(2) from the console.
  function paramLevel(){
    const n = parseInt(new URLSearchParams(location.search).get('level'), 10);
    return Game.LEVELS[n] ? n : 1;
  }

  function loadLevel(n){
    level = Game.LEVELS[n] || Game.LEVELS[1];
    rule = Game.RULES[level.rules] || Game.RULES.classic;
    counts = {};
    Object.keys(level.targets).forEach(t => counts[t] = 0);

    items.make(level.layout, level.pickupRadius);
    player.reset();
    paused = false; won = false; gameOver = false;
    timeLeft = level.timeLimit || null; timerRunning = false; resetCooldown = 0;
    ui.setHint(level.hint || null);
    ui.setTimer(timeLeft);

    ui.setLevelLabel(level.label);
    ui.updateCounters(counts);
    ui.hideSettings();
    ui.hideWin();
    ui.hideGameOver();

    // Decide right now what the win screen should do once this level is
    // finished — go to the next level if one exists, else just replay.
    const nextId = level.id + 1;
    if(Game.LEVELS[nextId]){
      ui.setWinMessage(level.label + ' complete! Get ready for ' + Game.LEVELS[nextId].label + '.');
      ui.setWinButton('Next Level ▶', ()=> loadLevel(nextId));
    } else {
      ui.setWinMessage('You gathered everything in the meadow.');
      ui.setWinButton('Play Again', ()=> loadLevel(level.id));
    }
  }
  Game.loadLevel = loadLevel;

  // Audio needs a user gesture to start, and landscape-lock only works
  // after one too — both are attempted on the very first tap.
  document.addEventListener('pointerdown', function once(){
    audio.unlock();
    if(screen.orientation && screen.orientation.lock){
      screen.orientation.lock('landscape').catch(()=>{});
    }
    document.removeEventListener('pointerdown', once);
  }, { once: true });

  resize();
  loadLevel(paramLevel());

  ui.bind({
    onSettings: ()=>{ paused = true; },
    onResume: ()=>{ paused = false; },
    onRestart: ()=> loadLevel(level.id)
  });

  function handleTouch(type){
    const outcome = rule.onTouch(type, counts, level.targets, level);

    if(outcome === 'collect'){
      counts[type]++;
      ui.updateCounters(counts);
      audio.playCollect(type);
      if(rule.isComplete(counts, level.targets)){
        won = true;
        audio.playWin();
        setTimeout(ui.showWin, 250);
      }
    } else if(outcome === 'reset'){
      // Wrong order: clear progress, but ignore repeat touches for a moment
      // so standing on the wrong item doesn't reset every single frame.
      if(resetCooldown > 0) return 'locked';
      resetCooldown = 50;
      Object.keys(counts).forEach(t => counts[t] = 0);
      items.restoreAll();
      ui.updateCounters(counts);
      ui.toast('Galat order! Phir se shuru');
      audio.playGameOver();
    } else if(outcome === 'gameover'){
      ui.setGameOverMessage('Star ko chhoo liya — pehle saare tomato collect karo.');
      gameOver = true;
      player.reset();          // character turant starting point par wapas
      audio.playGameOver();
      setTimeout(ui.showGameOver, 150);
    }
    // 'locked' -> no state change, item stays for later.

    return outcome;
  }

  function update(dt){
    if(paused) return;
    player.update();
    if(won || gameOver) return;
    if(resetCooldown > 0) resetCooldown--;

    // Timer starts on the player's first move or jump, and only ticks
    // while the game is actually running (not paused).
    if(timeLeft !== null){
      if(!timerRunning && (player.obj.moving || !player.obj.onGround)) timerRunning = true;
      if(timerRunning){
        timeLeft -= dt;
        ui.setTimer(timeLeft);
        if(timeLeft <= 0){
          timeLeft = 0;
          ui.setTimer(0);
          gameOver = true;
          ui.setGameOverMessage("Time's up! Jaldi karo agli baar.");
          audio.playGameOver();
          setTimeout(ui.showGameOver, 150);
          return;
        }
      }
    }
    items.update(handleTouch);
  }

  function draw(){
    ctx.clearRect(0, 0, cfg.W, cfg.H);
    drawBackground();
    items.draw();
    player.draw();
  }

  let lastT = performance.now();
  function loop(now){
    const dt = Math.min(0.1, (now - lastT) / 1000);
    lastT = now;
    update(dt);
    draw();
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
})();
