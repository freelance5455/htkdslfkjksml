# 🍓 Meadow Dash

Aapke diye gaye reference image aur asset folder se banaya gaya ek 2D side-view collector platformer game. Neeche poori planning, folder structure aur game design ka breakdown hai.

---

## 📁 Folder Structure

```
meadow-dash/
├── index.html            → Game ka entry point (isi file ko browser mein kholna hai)
├── css/
│   ├── style.css          → Layout/positioning styling (HUD, overlays, page)
│   └── controls.css       → Sirf buttons ka look (move/jump/settings/mute) — pure CSS + SVG, koi image nahi
├── js/
│   ├── config.js          → Sab tunable numbers ek hi jagah (speed, gravity, jump, ground line)
│   ├── render.js          → Canvas setup + screen-fit scaling + background draw
│   ├── audio.js           → Sound effects + background music + button click sound
│   ├── player.js          → Sirf character: input, physics/movement, drawing
│   ├── items.js           → Sirf collectibles: position, collision, drawing
│   ├── levels.js          → Har level ka data (layout, targets, pickup radius, rule-set)
│   ├── rules.js           → Rule-sets: touch par collect/locked/game-over decide karte hain
│   ├── ui.js               → HUD counters, pause/win/game-over panels, mute button
│   └── game.js             → Sabko jodta hai: har frame par update + draw chalata hai
├── assets/
│   ├── background.png
│   ├── audio/
│   │   └── button_click.mp3
│   └── character/
│       ├── idle_sheet.png   → 6 frames, 300×300 each
│       ├── walk_sheet.png   → 6 frames, 300×300 each
│       └── jump_sheet.png   → 4 frames, 300×300 each
└── README.md              → Yeh file
```

**Kyun alag files?** Pehle sab ek hi `game.js` mein tha, isliye character dhoondhna ho ya physics change karni ho, sabkuch scroll karke dhoondhna padta tha. Ab har cheez apni file mein hai:
- Character/movement change karna hai → sirf `player.js` kholein
- Speed/jump/gravity number badalne hain → sirf `config.js` kholein (sab constants top par hain)
- Item position ya collect-logic → sirf `items.js`
- Sound/music → sirf `audio.js`
- Pause/win screen ka text ya button → sirf `ui.js`

Har file `window.Game` naam ki ek shared object mein apna hissa daalti hai (jaise `Game.player`, `Game.items`), isliye files ek dusre se seedha connect ho jaati hain bina kisi build-tool/bundler ke — bas `index.html` mein sahi order mein load hoti hain.

---

## 🔊 Sound Effects & Music
Zyadatar sounds **code se hi real-time banaye jaate hain** (Web Audio API, koi file nahi chahiye):
- **Jump** → chhota "boop" sound
- **Collect** → item type ke hisaab se alag pitch ka "ding" (star/tomato/berry teeno ka sound thoda different hai)
- **Level Complete** → 4-note chhota fanfare
- **Game Over** → descending "buzz" sound
- **Background music** → dheema, looping pentatonic tune jo game shuru hote hi bajta hai

Ek real audio file bhi hai — `assets/audio/button_click.mp3` — jo har menu/HUD button (settings, resume, restart, next level/play again, try again, mute) par bajta hai. Move/jump control buttons is se alag hain, unka apna synthesized sound hai.

Top-right mein 🔊/🔇 button se poora sound (music + saare effects, click sound bhi) mute/unmute ho sakta hai.

**Note:** Browsers user ke pehle tap/click se pehle audio allow nahi karte, isliye music screen par pehli baar touch karte hi shuru hoga (turant page load par nahi) — yeh normal browser rule hai.

**Naye sounds/music style badalne ho** → `js/audio.js` kholein, `tone()` function ko alag frequency/duration values ke saath call karein, ya `SCALE` array badal kar music ka mood change karein.

---

## 🖼️ Character Animation (Sprite Sheets)
Character ab canvas-shapes ki jagah **sprite sheets** se banta hai — 3 PNG files, har ek apni animation ke saare frames ek row mein:

| File | Frames | Kab chalta hai |
|---|---|---|
| `idle_sheet.png` | 6 | Character khada hai (na move, na jump) |
| `walk_sheet.png` | 6 | Left/right move ho raha hai |
| `jump_sheet.png` | 4 | Hawa mein hai — frame **time se nahi, physics se** chunta hai (launch → rising → floaty apex → falling), isliye pose hamesha actual movement se match karta hai |

Abhi ke frames **maine khud code se (Python/PIL) generate kiye hain** — same style/colors jo pehle canvas-shapes wale character mein the (orange body, cream belly, green leaf). Ye ek placeholder hai jab tak aap apni khud ki artwork nahi bana lete.

**Apni asli artwork se replace karna ho** → bas teeno files ko same naam se `assets/character/` mein replace kar dein, in specs ke saath:
- Har frame **exactly 300×300px**, sab frames ek row mein side-by-side (sprite sheet), same order jaisa upar table mein hai
- Character ke **feet frame ke 90% neeche** (upar se 270px) par fixed rahein — har frame mein same jagah, warna animation jitter karega
- **Transparent background** (PNG alpha)
- Sirf **right-facing** — game khud left ke liye flip karta hai
- Frame count same rakhein (Idle 6, Walk 6, Jump 4) — kam/zyada frames chahiye ho to `js/player.js` mein `SHEETS.<name>.frames` number bhi update karna hoga

**Animation speed/timing badalni ho** → `js/player.js` mein `ANIM_HOLD` (idle/walk speed) ya jump ke `pickSheet()` ke andar vy ranges (`-6.5`, `0`, `6.5`) edit karein.

---

## 🎮 Game Design Planning

### Concept
Ek chhota character meadow (ghaas ke maidan) mein ghoom kar 3 tarah ke items collect karta hai — matches reference image ke HUD counters se (⭐ star, 🍅 tomato, 🍓 strawberry, har ek 0/3 se 3/3 tak).

### Core Loop
1. Player left/right button dabakar move karta hai
2. Kuch items zameen par hain (seedha chal kar milte hain), kuch hawa mein floating hain (jump button se lene padte hain)
3. Har item collect hone par top HUD ka counter update hota hai
4. Jab sab 9 items (3+3+3) collect ho jaate hain → "Level Complete" screen aata hai

### Controls
| Input | Action |
|---|---|
| Left button / ⬅️ Arrow key / A | Character left move |
| Right button / ➡️ Arrow key / D | Character right move |
| Jump button / ⬆️ Arrow / Space / W | Character jump |
| Settings (gear icon) | Game pause + restart option |

### HUD Layout (reference image se match)
- **Top-left**: "Level 1" pill
- **Top-center**: 3 counter pills (star / tomato / strawberry)
- **Top-right**: Settings gear button
- **Bottom-left**: Left + Right movement buttons
- **Bottom-right**: Jump button

### Physics
- Simple gravity + jump velocity system
- Character zameen ki line (ground Y) par khada rehta hai, jump lagane par upar uchalta hai aur wapas neeche aata hai
- Floating items sirf jump ke peak ke time collect ho sakte hain — thoda timing/skill chahiye

### Player Character
Ek cute orange "leaf-creature" character — round body, chhote haath-pair, ek patti (leaf) sar par, left/right dekhne par flip ho jaata hai. Ab isme **real Idle/Walk/Jump animation** hai (sprite sheets se) — upar "Character Animation" section dekhein.

### Win State
Jab teeno counters 3/3 ho jaate hain, ek overlay panel aata hai: "Level Complete!" + "Play Again" button jo poora level reset kar deta hai.

---

## 📱 Landscape Mode
Game ab **sirf landscape** mein khelne ke liye bana hai:
- Phone **portrait** mein ho → poori screen par "Apna phone ghumayein" wala rotate-prompt dikhega
- Phone **landscape** mein ghumate hi → game turant poori screen (edge-to-edge, full width/height) mein khul jaayega, koi black margin nahi

Yeh pure CSS (`orientation` media query) se hota hai, isliye har browser mein reliably kaam karta hai. Ek chhota JS attempt bhi hai (`screen.orientation.lock`) jo kuch browsers mein automatically landscape lock kar deta hai — na chale to bhi rotate-prompt hamesha kaam karega.

## 🖥️ No More Stretching (Responsive Fix)
Pehle full-screen landscape mein background/character thoda stretch/squish ho rahe the (kyunki canvas ko seedha device ki screen size par force kiya ja raha tha). Ab game hamesha ek fixed 960×540 "virtual world" mein chalta hai aur render karte waqt us world ko screen par **cover-fit** kiya jaata hai (jaise CSS `background-size:cover`) — matlab kisi bhi phone ki screen ratio ho, art kabhi distort nahi hoga, bas thoda sky/dirt crop ho sakta hai edges par. Character bhi ab ground par thoda upar, grass band ke center ke kareeb khada hota hai. Items ko clearly dikhane ke liye unke peeche ek halka white glow circle bhi add kiya hai.

## 🗺️ Level System (Level 1 + Level 2 + Level 3)
Ab game mein ek **modular level engine** hai — Level 1 aur Level 2 bilkul waise hi hain jaise pehle the (koi gameplay change nahi), aur Level 3 naya add hua hai. Future mein Level 4, 5... 100 bhi isi tarah add ho sakte hain, bina character/physics/controls chhue.

```
js/levels.js   → Har level ka data: item positions, target counts, pickup radius, konsa rule-set use hoga
js/rules.js    → Rule-sets: item touch hone par kya hota hai (collect / locked / game-over), aur level kab complete hota hai
```

**Level 2 ke rules** (`js/rules.js` mein `level2`):
1. Shuru mein sirf 🍅 Tomato collect karna safe hai (3 chahiye)
2. Jab tak 3/3 Tomato nahi hue: ⭐ Star **screen par dikhta rahega** (hide/remove nahi hota) lekin usse chhoote hi **turant Game Over**
3. 3/3 Tomato hote hi Star automatically unlock — ab wahi Star normally collect ho sakta hai
4. 🍓 Berry unlock se pehle bilkul harmless hai — usse touch karne se kuch nahi hota, bas collect nahi hota; unlock ke baad normally collect hoga
5. Teeno (3 Tomato + 3 Star + 3 Berry) poore hote hi Level Complete

Level 2 mein items ka **pickup radius chhota (32px)** rakha hai (Level 1 ka 46px hi wahi hai) taaki tomato/star ke beech carefully move/jump karna pade — bina koi naya game rule banaye, sirf placement aur precision se difficulty badhi hai.

**Level 3 ke rules** (`js/rules.js` mein `level3`) — Level 2 ka ulta:
1. Shuru mein sirf 🍓 Berry collect karna safe hai (3 chahiye)
2. Jab tak 3/3 Berry nahi hue: **🍅 Tomato AUR ⭐ Star dono hi khatarnaak hain** — dono screen par dikhte rahenge, lekin dono mein se kisi ko bhi chhoote hi **turant Game Over** (Level 2 mein sirf Star khatarnaak tha, Berry sirf locked/harmless tha — Level 3 mein dono hi deadly hain)
3. 3/3 Berry hote hi Tomato aur Star dono ek saath unlock — ab dono normally collect ho sakte hain
4. Teeno (3 Berry + 3 Tomato + 3 Star) poore hote hi Level Complete

Level 3 ka pickup radius bhi **32px** rakha hai (Level 2 jaisa hi) — is baare mein aapne kuch bataya nahi tha, toh maine Level 2 wali precision-based difficulty consistent rakhi; chahein to `js/levels.js` mein Level 3 ki `pickupRadius` value badal sakte hain.

**Kisi bhi level ko test karna ho:** browser mein URL ke end mein `?level=` laga kar number de dein —
```
index.html?level=2
index.html?level=3
```
`?level` na diya jaaye to Level 1 hi normally chalta hai (default). Developer console se bhi `Game.loadLevel(3)` chala kar switch kar sakte hain.

**Ek level complete hone ke baad agla level automatically aata hai** — win screen par "Play Again" ki jagah "Next Level ▶" dikhta hai jab tak agla level maujood ho. Yeh `js/game.js` mein `loadLevel()` khud check karta hai (`Game.LEVELS[level.id + 1]` maujood hai ya nahi), isliye Level 3 add hote hi Level 2 khatam hone par apne aap "Next Level ▶" dikhne laga — is feature mein kuch bhi badalna nahi pada. Level 3 ke baad abhi Level 4 nahi hai, toh Level 3 complete hone par "Play Again" usi level ko restart karega.

**Naya Level 4 add karna ho** → `js/levels.js` mein ek naya `4: {...}` entry add karein (layout + targets + pickup radius + koi existing rule-set jaise `'classic'`/`'level2'`/`'level3'`), aur agar uske rules bilkul alag hain to `js/rules.js` mein ek naya named rule-set likh dein — baaki poora engine (`game.js`, `player.js`, `items.js`) bina chhue kaam karega.

**Note on `levels.json`:** Aapne `levels.json` maanga tha, lekin `index.html` ko seedha double-click karke (`file://`) kholne par browsers local `.json` file ko `fetch()` karne nahi dete (CORS block) — isliye data ko `levels.js` (ek script tag) mein rakha hai jo bina kisi server ke turant chal jaata hai. Andar ka object hu-ba-hu JSON jaisa hi likha hai — agar kabhi is folder ko real web server se serve karein, isi object ko `levels.json` mein copy karke `fetch()` se load karwa sakte hain.

---

## ▶️ Game Kaise Chalayein

**Sabse aasan tareeka:**
`index.html` file ko seedha double-click karke kisi bhi browser (Chrome/Edge/Safari) mein khol dein.

**Agar images load na ho (kuch browsers local file se images block karte hain), to local server chalayein:**

```bash
# Folder ke andar jaake:
python3 -m http.server 8000
```
Fir browser mein kholein: `http://localhost:8000`

---

## 🛠️ Customization Guide

- **Speed/jump height/gravity badalni ho** → `js/config.js` (sab ek jagah, top par comments ke saath)
- **Items ki position/type badalni ho (kisi bhi level ki)** → `js/levels.js` mein us level ke `layout` array ko edit karein (x position aur `true/false` for elevated)
- **Character ka design/animation** → naya artwork "Character Animation" section ke specs follow karke `assets/character/` mein daalein; frame-picking/timing logic `js/player.js` mein hai
- **Sounds/music** → `js/audio.js` (upar "Sound Effects & Music" section dekhein)
- **Colors/HUD look badalna ho** → `css/style.css` mein `:root` ke variables (`--cream`, `--forest`, etc.) edit karein
- **Button ka shape/color/size badalna ho (move/jump/settings/mute)** → `css/controls.css` kholein — sab kuch pure CSS + SVG hai, koi image file dhoondhne ki zaroorat nahi
- **Naya level banana ho** → upar "Level System" section dekhein (`js/levels.js` mein naya entry add karein)

---

## ✅ Assets Used
- `background.png` — original file, bina compress kiye.
- `assets/audio/button_click.mp3` — menu/HUD buttons ka click sound.
- Move/jump/settings/mute buttons **ab image nahi hain** — pure CSS shapes + inline SVG icons se bane hain (`css/controls.css` + `index.html`). Isse zip aur chhota ho gaya, aur button ka color/size/style badalna sirf ek CSS file edit karna hai, koi image editor nahi chahiye.
- Player character aur collectible icons (⭐🍅🍓) bhi code se generate kiye gaye hain.
