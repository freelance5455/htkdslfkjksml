JESOSY MAMONJY — kinova fanombohana
Mpamorona: Mitia Finaritra

Ity dia application web tsotra azo sokafana amin'ny Android na solosaina. Ahitana fikarohana araka ny laharana/lohateny/tononkira, fanampiana sy fanovana hira, ary famoahana/fampidirana tahiry JSON.

ZAVA-DEHIBE:
- Tsy APK Android izy ity.
- Tsy mbola tafiditra ny tononkira feno rehetra; ireo lohateny fantatra ihany no napetraka, ary misy laharana 1–65 vonona hamenoana.
- Tehirizina ao amin'ny navigateur ampiasaina ny fanovana. Ampiasao ny “Hamoaka tahiry” mba hanaovana kopia fiarovana.
- Sokafy ny index.html amin'ny navigateur. Mety tsy ho afaka “Add to Home Screen” amin'ny fomba PWA ny rakitra HTML eo an-toerana; mila ampiantranoina amin'ny HTTPS izany.
