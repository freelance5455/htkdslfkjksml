# Smart 11.0 Final Status

This package is a native Android Gradle project.

- Application ID: com.app.smarty
- Version name: 11.0
- Version code: 11
- Compile/target SDK: 35
- Java/Kotlin toolchain: 17
- GitHub Actions workflow included
- Native voice foreground service included
- Accessibility service included
- Notification listener included
- Phone command engine included
- First-run permission setup included

Important Android behavior: the user must grant Android permissions/accessibility/overlay access. A normal app cannot silently grant these permissions to itself.

The open-ended AI backend URL is intentionally not hard-coded with a secret. It must be deployed/configured separately before unrestricted AI chat can work.
