/* RubAI 4.0 — локальные правила. Это не нейросеть и не вызов внешней модели. */
(function (root) {
  "use strict";

  const SYSTEMS = root.RubAITemplates.SYSTEMS;
  const MODES = {
    rubdefault: { id: "rubdefault", label: "RubDefault", depth: 1, blurb: "Обычные ответы, скрипты и проверка." },
    rubpremium: { id: "rubpremium", label: "RubPremium", depth: 2, blurb: "Глубже разбор, связанные системы и оптимизация." },
    rubultimate: { id: "rubultimate", label: "RubUltimate", depth: 3, blurb: "Архитектура, несколько систем и подробная проверка." },
  };
  const ORDER = ["admin", "pets", "inventory", "quests", "npc", "rounds", "teleport", "shop", "rp", "base", "gui", "datastore", "money", "leaderstats"];

  function modeInfo(mode) {
    return MODES[mode] || MODES.rubdefault;
  }

  function detectFeatures(text) {
    const source = String(text || "");
    return {
      admin: /(админ|admin|модерац|\bkick\b)/i.test(source),
      pets: /(питом|pet\b|яйц|egg\b)/i.test(source),
      inventory: /(инвентар|inventory|рюкзак)/i.test(source),
      quests: /(квест|quest|задани[ея]|поручен)/i.test(source),
      npc: /(\bnpc\b|неигров|патрул|бот[а-я]*|торговец)/i.test(source),
      rounds: /(раунд|round|волн[аы]|лобби|матч)/i.test(source),
      teleport: /(телепорт|teleport|портал)/i.test(source),
      shop: /(магазин|shop\b|покупк|purchase|ларек|ларек)/i.test(source),
      rp: /(\brp\b|ролев|roleplay|роль игрок|професси)/i.test(source),
      base: /(база игрок|базы игрок|tycoon|плот|участ[оа]к|player base)/i.test(source),
      gui: /(\bgui\b|интерфейс|screen\s?gui|меню|кнопк)/i.test(source),
      datastore: /(datastore|data store|сохранен|сохранён|сохраня|прогресс)/i.test(source),
      money: /(деньг|монет|валют|\bcash\b|\bcoins\b|экономик)/i.test(source),
      leaderstats: /(leaderstats|лидерборд|таблиц[аы]\s+лидер)/i.test(source),
      remote: /(remoteevent|remotefunction|remote event)/i.test(source),
      module: /(modulescript|модул[ья])/i.test(source),
    };
  }

  function projectContext(project) {
    if (!project) return "";
    return [project.name, project.task, project.constraints, project.notes, project.requirements, project.decisions]
      .filter(Boolean)
      .join("\n")
      .slice(0, 9000);
  }

  function chosenKeys(features, depth) {
    let keys = ORDER.filter((key) => features[key]);
    if (keys.includes("datastore")) keys = keys.filter((key) => key !== "leaderstats");
    if (keys.includes("money") && keys.includes("leaderstats")) keys = keys.filter((key) => key !== "leaderstats");
    if (!keys.length) keys = ["scaffold"];
    const limit = depth >= 3 ? 3 : depth === 2 ? 2 : 1;
    return keys.slice(0, limit);
  }

  function classifyPrompt(prompt) {
    const lower = String(prompt || "").toLowerCase();
    const hasCode = /(game\s*:\s*GetService|Instance\.new|OnServerEvent|FireServer|local\s+\w+\s*=|function\s+\w+|-->|end\b)/.test(prompt);
    if (/(creator store|тулбокс|toolbox|rbxassetid|найди (модель|ассет|asset)|поиск (модел|ассет|asset))/.test(lower)) return "store";
    if (/(проверь|найди ошибки|исправ|отлад|ревью|аудит|debug|review)/.test(lower) || (hasCode && /(ошиб|скрипт|luau|local )/.test(lower))) {
      if (hasCode || /(проверь|ошиб|ревью|аудит|debug)/.test(lower)) return "analysis";
    }
    if (/(где разме|куда (класть|помест)|что такое|объясни|зачем|чем отличается|как работает)/.test(lower) && !/(напиши|создай|сделай|сгенерир)/.test(lower)) return "explain";
    if (/(спланируй|архитектур|техническое задание|\bтз\b|разбей на этапы)/.test(lower)) return "plan";
    if (/(напиши|создай|сделай|сгенерир|реализуй|скрипт|систем|код\b)/.test(lower)) return "generate";
    if (hasCode && prompt.length > 40) return "analysis";
    return "answer";
  }

  function extractSearchQuery(prompt) {
    const text = String(prompt || "").trim();
    const quoted = text.match(/["«]([^"»]{1,60})["»]/);
    if (quoted) return quoted[1].trim();
    const found = text.match(/(?:найди|найти|поиск|search|ищи)\s+([^\n]{1,60})/i);
    if (found) {
      return found[1].replace(/\b(в|creator|store|тулбоксе|модели|модель|ассет|asset)\b/gi, " ").replace(/\s+/g, " ").trim();
    }
    if (text.split(/\s+/).length <= 4) return text.slice(0, 60);
    return "";
  }

  function stripLua(code) {
    return String(code || "")
      .replace(/--\[\[[\s\S]*?\]\]/g, " ")
      .replace(/--[^\n]*/g, " ")
      .replace(/\[(=*)\[[\s\S]*?\]\1\]/g, " ")
      .replace(/"(?:\\.|[^"\\])*"/g, " ")
      .replace(/'(?:\\.|[^'\\])*'/g, " ");
  }

  function blockBalance(code) {
    const tokens = stripLua(code).match(/\b(function|if|for|while|repeat|until|end|do)\b/g) || [];
    let depth = 0;
    let min = 0;
    let expectDo = false;
    for (const token of tokens) {
      if (token === "for" || token === "while") {
        depth += 1;
        expectDo = true;
      } else if (token === "do") {
        if (expectDo) expectDo = false;
        else depth += 1;
      } else if (token === "function" || token === "if" || token === "repeat") {
        depth += 1;
        expectDo = false;
      } else if (token === "end" || token === "until") {
        depth -= 1;
        expectDo = false;
      }
      if (depth < min) min = depth;
    }
    return { depth, min };
  }

  function analyzeCode(source) {
    const code = String(source || "");
    const findings = [];
    const examples = {
      "remote-types": `purchaseEvent.OnServerEvent:Connect(function(player, itemName)\n\tif typeof(itemName) ~= "string" or #itemName > 40 then\n\t\treturn\n\tend\nend)`,
      "datastore-pcall": `local ok, result = pcall(function()\n\treturn playerStore:GetAsync("player_" .. player.UserId)\nend)\nif not ok then\n\twarn(result)\n\treturn\nend`,
      "loop-yield": `while condition do\n\ttask.wait(1)\nend`,
    };
    const add = (id, title, severity, description, fix) => {
      if (!findings.some((item) => item.id === id)) {
        findings.push({ id, title, severity, description, fix: fix || "", fixCode: examples[id] || "" });
      }
    };
    const serverRemote = /OnServerEvent|OnServerInvoke/.test(code);
    const remoteUse = /FireServer|OnServerEvent|OnServerInvoke/.test(code);
    if (/loadstring\s*\(|getfenv\s*\(|setfenv\s*\(/i.test(code)) add("loadstring", "Опасное динамическое выполнение", "Высокий", "loadstring, getfenv и setfenv не стоит использовать в игровой логике Roblox.", "Удалите вызов и оставьте обычные функции.");
    if (/require\s*\(\s*\d+\s*\)/i.test(code)) add("asset-require", "require по числовому ID", "Высокий", "Так можно выполнить чужой модуль. Подключайте ModuleScript своей игры.", "require(ReplicatedStorage.Modules.TrustedModule)");
    if (remoteUse && serverRemote && !/typeof\s*\(/.test(code)) add("remote-types", "Нет проверки типов RemoteEvent", "Высокий", "Сервер принимает аргументы клиента без typeof.", "Проверяйте тип, длину, права и состояние на сервере.");
    if (remoteUse && serverRemote && !/(cooldown|lastRequest|os\.clock)/i.test(code)) add("remote-rate", "Нет ограничения частоты", "Средний", "Обработчик можно заспамить.", "Храните os.clock() последнего запроса и очищайте его в PlayerRemoving.");
    if (/DataStoreService|:GetAsync\s*\(|:SetAsync\s*\(|:UpdateAsync\s*\(/.test(code) && !/pcall\s*\(/.test(code)) add("datastore-pcall", "DataStore без pcall", "Высокий", "GetAsync, SetAsync и UpdateAsync могут выбросить ошибку.", "Оберните вызов в pcall и проверьте формат данных.");
    if (/:GetAsync\s*\(|:SetAsync\s*\(|:UpdateAsync\s*\(/.test(code) && /player\.Name/.test(code)) {
      add("datastore-name", "В сохранении встречается имя игрока", /UserId/.test(code) ? "Средний" : "Высокий", "Ключ DataStore нужно строить из UserId. Имя не постоянно.", "Используйте player_ и player.UserId.");
    }
    if (/(while\s+true\s+do|while\s+[^\n]+do)/i.test(code) && !/\b(task\.wait|Heartbeat|Stepped)\b/.test(code)) add("loop-yield", "Цикл может не отдавать управление", "Высокий", "Цикл без ожидания блокирует поток.", "Добавьте task.wait или событие.");
    if (/(?<![\w.])(wait|spawn|delay)\s*\(/.test(code)) add("legacy-yield", "Устаревшие wait, spawn или delay", "Низкий", "В новом коде используют task.wait, task.spawn и task.delay.", "Замените на функции сервиса task.");
    if (/FireServer\s*\(/.test(code) && !serverRemote) add("client-authority", "FireServer нужно проверять на сервере", "Средний", "По этому фрагменту не видно серверной проверки цены, урона или награды.", "В Script внутри ServerScriptService проверьте аргументы и состояние.");
    if (/(Coins|Cash|Money|Currency)\s*\.\s*Value\s*[+\-]=/.test(code) && !/OnServerEvent|ServerScriptService/.test(code)) add("client-currency", "Валюта меняется вне явного серверного скрипта", "Высокий", "Если это LocalScript, игрок сможет накрутить значение у себя на экране, а сервер его не подтвердит.", "Меняйте IntValue только на сервере.");
    if (/HttpService/.test(code) && /GetAsync|PostAsync|RequestAsync/.test(code) && !/pcall\s*\(/.test(code)) add("http-pcall", "HttpService без pcall", "Высокий", "Сетевой запрос может упасть. HttpService ещё нужно включить в настройках опыта.", "Оберните запрос в pcall. Не отдавайте клиенту секреты.");
    if (/\btick\s*\(/.test(code)) add("tick", "Используется tick()", "Низкий", "tick устарел.", "Для интервалов берите os.clock(), для даты os.time().");
    if (/Instance\.new\s*\(\s*["'][^"']+["']\s*,/.test(code)) add("instance-parent", "Родитель передан сразу в Instance.new", "Низкий", "Второй аргумент раньше подключает объект до настройки свойств.", "Сначала создайте объект, задайте свойства, потом Parent.");
    if (/:\s*Remove\s*\(/.test(code)) add("remove", "Устаревший Remove", "Низкий", "Вместо Remove используйте Destroy.", "Вызовите Destroy().");
    if (/PromptProductPurchase/.test(code) && !/ProcessReceipt/.test(code)) add("process-receipt", "Нет ProcessReceipt", "Высокий", "Награду за Developer Product выдают на сервере в MarketplaceService.ProcessReceipt, а не после кнопки на клиенте.", "Назначьте ProcessReceipt в серверном Script и возвращайте Enum.ProductPurchaseDecision.");
    if (/FireServer\s*\([^)]*\b(price|coins|amount|reward)\b/i.test(code)) add("client-price", "На сервер уходит цена или награда", "Высокий", "Клиент может подменить число.", "Отправляйте только id действия. Цену храните в серверной таблице.");
    const balance = blockBalance(code);
    if (balance.depth !== 0 || balance.min < 0) add("structure", "Похоже, не сходятся блоки end", "Средний", `Грубая проверка скобок Lua: баланс ${balance.depth}. Строки и комментарии пропущены, это не компилятор Luau.`, "Сверьте function, if, for, while и do с end, а repeat с until.");
    if (!findings.length) {
      findings.push({
        id: "no-known-rule",
        title: "Явных совпадений с правилами нет",
        severity: "Низкий",
        description: "Это не доказательство, что код верен. Шаблоны RubAI не запускают и не компилируют Luau.",
        fix: "",
        fixCode: "",
      });
    }
    return findings;
  }

  function optimizationNotes(code) {
    const notes = [];
    if (/task\.wait\(\s*0\s*\)/.test(code)) notes.push("task.wait(0) почти не разгружает плотный цикл. Лучше событие или более редкий интервал.");
    if (/GetChildren\s*\(/.test(code) && /while\b/.test(code)) notes.push("Не собирайте GetChildren в тесном цикле, если состав объектов не меняется каждый кадр.");
    if (/Instance\.new\(/.test(code)) notes.push("Задавайте свойства до Parent: так объект меньше раз будит движок.");
    if (/Heartbeat/.test(code)) notes.push("В Heartbeat не ищите объекты заново. Кэшируйте ссылки и отключайте соединение, когда оно больше не нужно.");
    if (/FireAllClients/.test(code)) notes.push("В FireAllClients не кладите секреты экономики. Клиенту достаточно состояния для интерфейса.");
    return notes;
  }

  const KNOWLEDGE = [
    {
      re: /localscript|local script|клиентск/i,
      title: "Куда класть LocalScript",
      body: "LocalScript выполняется у игрока: StarterPlayerScripts, StarterCharacterScripts или интерфейс в PlayerGui. Им рисуют GUI и читают ввод. Награды, деньги, урон и сохранения отсюда не назначают.",
      extra: "ResetOnSpawn у ScreenGui выключают, если меню должно пережить респавн. WaitForChild нужен для объектов, которые сервер создаёт чуть позже.",
    },
    {
      re: /modulescript|модул/i,
      title: "ModuleScript",
      body: "ModuleScript возвращает значение через return и подключается require. Общие чистые функции можно держать в ReplicatedStorage. Серверные правила и данные игроков — в ServerScriptService, чтобы клиент не мог их прочитать.",
      extra: "Один ModuleScript выполняется один раз на той стороне, где его впервые подключили. Не кладите в ReplicatedStorage секреты и полные таблицы цен, если не хотите отдавать их клиенту. Цены магазина надёжнее оставить на сервере.",
    },
    {
      re: /remoteevent|remote function|remote/i,
      title: "RemoteEvent",
      body: "RemoteEvent кладут в ReplicatedStorage, обычно в папку Remotes. Клиент вызывает FireServer, сервер слушает OnServerEvent. Первый аргумент на сервере — игрок, его не присылают руками. Каждый следующий аргумент проверяйте через typeof.",
      extra: "Не принимайте цену, урон и награду. Добавьте cooldown через os.clock и очищайте таблицу в PlayerRemoving. RemoteFunction держит вызывающую сторону, пока не вернётся ответ, поэтому на сервере не делайте в ней долгих ожиданий.",
    },
    {
      re: /datastore|сохран/i,
      title: "DataStore",
      body: "DataStoreService доступен только серверному Script. Вызовы GetAsync, SetAsync и UpdateAsync оборачивайте в pcall. Ключ стройте из UserId. В Studio включите API Services только у тестового места и не ждите, что локальный файл сам сохранит данные.",
      extra: "UpdateAsync лучше SetAsync, если несколько серверов могут писать одну запись. При выходе сохраняйте в PlayerRemoving и BindToClose. Это не ProfileService: тот модуль в RubAI не встроен, его подключают отдельно, если он вам действительно нужен.",
    },
    {
      re: /leaderstats|лидерборд/i,
      title: "Leaderstats",
      body: "Папка должна называться leaderstats и лежать в Player. Внутри обычно IntValue, например Coins. Создаёт её сервер в PlayerAdded. Табло Roblox само показывает числовые значения.",
      extra: "Не меняйте Value из LocalScript. Если нужно сохранение, соседний серверный Script читает тот же IntValue и пишет его в DataStore.",
    },
    {
      re: /gui|интерфейс|screengui/i,
      title: "Интерфейс",
      body: "ScreenGui можно собрать в StarterGui или создать из LocalScript и положить в PlayerGui. Для кнопок используйте Activated, а не только MouseButton1Click: так работает и касание.",
      extra: "Размеры лучше смешивать: Scale для растяжения и Offset для минимальной высоты около 44 пикселей. Клиент после нажатия только сообщает намерение.",
    },
    {
      re: /телепорт|teleport/i,
      title: "Телепорт",
      body: "Внутри одного места перемещайте HumanoidRootPart через CFrame. Для другого опыта есть TeleportService:TeleportAsync, но PlaceId должен быть вашим настоящим числом. RubAI его не выдумывает.",
      extra: "На Touched ставьте короткую блокировку повторного срабатывания, иначе игрок зациклится между площадками.",
    },
    {
      re: /pathfinding|поиск пути|\bnpc\b/i,
      title: "NPC",
      body: "Живой риг с Humanoid и HumanoidRootPart может идти через Humanoid:MoveTo. PathfindingService:CreatePath и ComputeAsync строят путь, статус сравнивают с Enum.PathStatus.Success.",
      extra: "Без рига шаблон RubAI ставит закреплённую деталь и двигает её TweenService. Это видимый маршрут, а не полноценный персонаж. Риг собирают в Studio через Rig Builder и называют RubNPC.",
    },
  ];

  function explainPrompt(prompt, depth) {
    for (const entry of KNOWLEDGE) {
      if (entry.re.test(prompt)) {
        return entry.title + "\n\n" + entry.body + (depth >= 2 && entry.extra ? "\n\n" + entry.extra : "");
      }
    }
    return "Локальные правила покрывают Script и LocalScript, RemoteEvent, DataStore, leaderstats, GUI, магазин, инвентарь, питомцев, базы, NPC, раунды, телепорты, квесты, админку, RP и деньги.\n\nУточните механику или вставьте код. Я не выдумываю Asset ID и не называю этот ответ нейросетью.";
  }

  function makePlan(prompt, project) {
    const features = detectFeatures(`${prompt}\n${projectContext(project)}`);
    const keys = chosenKeys(features, 3).filter((key) => key !== "scaffold");
    const steps = [
      "Зафиксировать правила в заметках проекта: что игрок может, а что решает только сервер.",
      "Разложить сервер, клиент и общие модули по разным объектам Explorer.",
    ];
    const files = [];
    const selected = keys.length ? keys : ["scaffold"];
    for (const key of selected) {
      const system = SYSTEMS[key];
      files.push(system.studio);
      for (const item of system.scripts) files.push(`${item.path} (${item.type})`);
      steps.push(`Собрать систему «${system.title}» и проверить её в Studio на двух клиентах.`);
    }
    if (features.datastore || features.money) steps.push("Обернуть сохранения в pcall и не писать ключ по имени игрока.");
    steps.push("Прогнать статический разбор RubAI и отдельно воспроизвести читерский запрос: подмена цены, спам RemoteEvent, выход в момент сохранения.");
    return { steps, files, features };
  }

  function placementText(scripts) {
    return scripts.map((item) => `• ${item.type}: ${item.path}`).join("\n");
  }

  function prepareResponse(prompt, mode, project) {
    const info = modeInfo(mode);
    const context = projectContext(project);
    const features = detectFeatures(`${prompt}\n${context}`);
    let kind = classifyPrompt(prompt);
    const featureNames = ORDER.filter((key) => features[key]).map((key) => SYSTEMS[key].title);
    if (kind === "answer" && featureNames.length) kind = "generate";
    const summary = `Режим ${info.label}. Проект: ${project?.name || "без имени"}. ${featureNames.length ? "Темы: " + featureNames.join(", ") + "." : "Общий запрос."} Это локальные правила, не нейросеть.`;

    if (kind === "store") {
      const storeQuery = extractSearchQuery(prompt);
      return {
        content: "Поиск моделей, декалей и других публичных ассетов находится в разделе Creator Store.\n\nRubAI запросит официальный Roblox Toolbox Service через server.js и покажет только те ID, которые реально пришли в ответе. Если сервер не запущен или Roblox ничего не вернул, список останется пустым — номер не будет выдуман." + (storeQuery ? `\n\nМожно сразу искать: ${storeQuery}` : ""),
        summary,
        openStore: true,
        storeQuery,
      };
    }

    if (kind === "analysis") {
      if (!/(function\b|local\s|Instance\.|game\s*:|end\b)/.test(prompt)) {
        return {
          content: "В сообщении нет самого скрипта. Вставьте Luau в чат или откройте RubAI Code → Проверка. Без кода я не отмечаю его как правильный и не запускаю проверку вхолостую.",
          summary,
        };
      }
      const findings = analyzeCode(prompt);
      const active = findings.filter((item) => item.id !== "no-known-rule");
      let content = active.length
        ? `Проверил текст локальными правилами, без запуска Luau.\n\n${active.map((item, index) => `${index + 1}. ${item.severity}: ${item.title}. ${item.description}${item.fix ? " Исправление: " + item.fix : ""}`).join("\n")}`
        : "Явных совпадений с известными ошибками нет. Это не значит, что скрипт компилируется или безопасен. Проверьте его в Roblox Studio.";
      if (info.depth >= 2) {
        const notes = optimizationNotes(prompt);
        if (notes.length) content += `\n\nОптимизация и устройство:\n${notes.map((note) => `• ${note}`).join("\n")}`;
        content += "\n\nОтдельно сверьте: сервер ли это, не читается ли цена с клиента, очищается ли состояние в PlayerRemoving.";
      }
      if (info.depth >= 3) {
        const balance = blockBalance(prompt);
        content += `\n\nСтруктура: грубый баланс блоков ${balance.depth} (0 — похоже на парные end). Минимальная глубина ${balance.min}. Это эвристика, не парсер Luau.\nКуда обычно класть такой код: серверные правила в ServerScriptService, интерфейс в StarterPlayerScripts или StarterGui, общие модули без секретов в ReplicatedStorage.`;
      }
      return { content, summary, findings };
    }

    if (kind === "explain") {
      let content = explainPrompt(`${prompt}\n${context}`, info.depth);
      if (project?.decisions) content += `\n\nУже записанные решения проекта:\n${project.decisions}`;
      return { content, summary };
    }

    if (kind === "plan") {
      const plan = makePlan(prompt, project);
      let content = `План для «${project?.name || "проекта"}»\n\nЭтапы:\n${plan.steps.map((step, index) => `${index + 1}. ${step}`).join("\n")}\n\nКуда класть в Roblox Studio:\n${plan.files.map((file) => `• ${file}`).join("\n")}`;
      if (info.depth >= 2) content += "\n\nРиски: клиент не источник денег и наград; DataStore может отказать; повторный RemoteEvent не должен применять действие дважды.";
      if (info.depth >= 3) content += "\n\nПроверка архитектуры: у каждой системы есть серверный источник правды, клиент только показывает состояние, сохранение не блокирует весь сервер надолго, а тестовый прогон включает двух игроков и выход в момент записи.";
      content += "\n\nПлан собран правилами RubAI, не нейросетью.";
      return { content, summary, plan: true };
    }

    const keys = chosenKeys(features, info.depth);
    const scripts = keys.flatMap((key) => SYSTEMS[key].scripts);
    const titles = keys.map((key) => SYSTEMS[key].title).join(", ");
    let content = `Подготовил локальные скрипты: ${titles}.\n\nКуда поместить в Explorer:\n${placementText(scripts)}`;
    keys.forEach((key) => {
      content += `\n\n${SYSTEMS[key].title}: ${SYSTEMS[key].studio}`;
    });
    if (keys.includes("scaffold")) {
      content += "\n\nНе увидел отдельную механику. Напишите, например: магазин, инвентарь, питомцы, база, NPC, раунды, телепорт, квест, DataStore, GUI, админка, RP или деньги.";
    }
    const missed = ORDER.filter((key) => features[key] && !keys.includes(key));
    if (missed.length) {
      content += `\n\nЕщё в запросе есть: ${missed.map((key) => SYSTEMS[key].title).join(", ")}. RubPremium добавит вторую систему, RubUltimate — до трёх. Переключение бесплатное, код заново не блокируется.`;
    }
    if (info.depth >= 2) {
      content += "\n\nПроверка решения: аргументы RemoteEvent фильтруются на сервере, цены не приходят от клиента, DataStore пишет UserId и ловит ошибки через pcall. Замените демо-предметы и пустой список админов на свои.";
      const notes = optimizationNotes(scripts.map((item) => item.source).join("\n"));
      if (notes.length) content += `\n\n${notes.map((note) => `• ${note}`).join("\n")}`;
    }
    if (info.depth >= 3) {
      content += "\n\nАрхитектура: ServerScriptService держит состояние, ReplicatedStorage хранит только RemoteEvent, StarterPlayerScripts рисует интерфейс. Не дублируйте создание leaderstats в двух скриптах без проверки FindFirstChild. Перед публикацией пройдите сценарии: нет денег, спам кнопки, выход игрока, повторный заход, два клиента одновременно.";
    }
    content += "\n\nЭто шаблоны правил RubAI. Они не скомпилированы в Studio и не являются ответом нейросети.";
    if (project?.decisions) content += `\n\nУчитываю прошлые решения:\n${String(project.decisions).slice(0, 700)}`;
    return {
      content,
      summary,
      codes: scripts,
      decision: `Скрипты (${info.label}): ${scripts.map((item) => `${item.name} → ${item.path}`).join("; ")}`,
    };
  }

  function buildSpec(project) {
    const task = project.task || project.requirements || "Уточните цель проекта.";
    const plan = makePlan(task, project);
    return `# Техническое задание Roblox — ${project.name}

## Цель
${task}

## Заметки
${project.notes || "Нет"}

## Требования
${project.requirements || project.constraints || "Не заданы"}

## Принятые решения
${project.decisions || "Пока нет"}

## Структура Explorer
${plan.files.map((file) => `- ${file}`).join("\n")}

## Этапы
${plan.steps.map((step, index) => `${index + 1}. ${step}`).join("\n")}

## Проверки
- Клиент не назначает валюту, награду и урон.
- RemoteEvent проверяет типы и частоту.
- DataStore использует pcall и UserId.
- Код прогнан в Studio минимум на двух клиентах.

Собрано локальными правилами RubAI 4.0, не нейросетью.
`;
  }

  function makeHandoff(project, chat) {
    const messages = chat && Array.isArray(chat.messages) ? chat.messages.slice(-8) : [];
    return `ЗАДАЧА ДЛЯ РАЗРАБОТЧИКА ИЛИ ВНЕШНЕЙ МОДЕЛИ

Проект: ${project.name}
Режим RubAI: локальные правила, нейросеть внутри RubAI не подключена.
Задача: ${project.task || "Сформулируйте цель"}
Требования: ${project.requirements || project.constraints || "Не заданы"}
Заметки: ${project.notes || "Нет"}
Решения: ${project.decisions || "Нет"}

Последние сообщения:
${messages.length ? messages.map((message) => `${message.role === "user" ? "Пользователь" : "RubAI"}: ${message.content}`).join("\n\n") : "Нет активного чата."}

ТЗ:
${project.spec || "Пока не собрано."}

Не используйте выдуманные Asset ID. Цены и сохранения оставляйте на сервере.`;
  }

  root.RubAIEngine = {
    MODES,
    modeInfo,
    detectFeatures,
    classifyPrompt,
    analyzeCode,
    blockBalance,
    prepareResponse,
    buildSpec,
    makeHandoff,
    makePlan,
    SYSTEMS,
  };
})(globalThis);
