# HANDOFF: GEMINI — RubAI Part 2

You are the second developer on the SAME RubAI application. This is a continuation task, not a rewrite.

Read `README.md`, `docs/PRODUCT_SPEC.md`, and all source files first.

## Your role
Independent code reviewer and reliability engineer. Review Part 1, then implement the next layer without breaking existing functionality.

## Required work
1. Audit `index.html` for HTML/CSS/JS bugs, accessibility and mobile layout.
2. Fix genuine bugs and document changes.
3. Add a robust project import/export workflow if feasible without unsafe client-side secrets. If ZIP handling needs a library, use a reputable pinned browser library and document its source/license, or leave a clearly designed adapter point rather than silently depending on an unavailable CDN.
4. Add a project file manifest / version metadata and changelog.
5. Improve the task brief so it captures Roblox hierarchy, script type (Script/LocalScript/ModuleScript), dependencies, remotes, DataStore needs, and testing checklist.
6. Add a strong review workflow: allow the user to paste Gemini review findings and track each as open/fixed/wont-fix.
7. Preserve the ChatGPT/Gemini/Grok role model and current handoff.
8. Do not add fake API calls. If you add provider integration, it must use a documented backend endpoint and never expose keys in browser code.
9. Return a complete updated ZIP with every file, not just snippets.
