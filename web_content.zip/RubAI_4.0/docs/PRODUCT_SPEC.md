# RubAI Product Specification

## Vision
RubAI is one application built in sequential contributions by three AI systems. It is not three separate chatbots. The user passes the evolving project archive from one model to the next. The final product should provide a unified workflow for Roblox game development.

## Model responsibilities
- ChatGPT: primary software engineer; architecture, Luau implementation, debugging and integration.
- Gemini: independent reviewer; static analysis, bug finding, security review, compatibility review and test plan.
- Grok: UI/UX specialist; visual design and interface improvements, including Roblox UI assets/scripts when required by the task.

## Current stage (Part 3 — RubAI 3.0)
Part 3 retains the Part 2 multi-project manager, Roblox Studio task specification, review tracker, settings foundation and handoff. It adds a local chat history per project, contextual notes and requirements, deterministic Roblox/Luau templates, rule-based planning and static code checks, a script editor with version history, JSON backup/import and an updated responsive interface.

RubAI 3.0 runs local rules and templates only. It does not call ChatGPT, Gemini, Grok or another model. Static checks do not execute or compile Luau. A true model connection requires a separately secured backend; no API secret belongs in browser code or localStorage.

## Security
- Never put API keys in frontend code, localStorage, exported ZIPs or client-visible config.
- Use backend auth, rate limiting, input size limits and per-user quotas.
- Treat model output and uploaded project files as untrusted data.
- Require user confirmation before destructive file operations or publishing.
