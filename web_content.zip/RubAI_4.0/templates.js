/* RubAI 4.0 — детерминированные шаблоны Luau.
   Только реальные API Roblox. Числовые Asset ID здесь не выдумываются. */
(function (root) {
  "use strict";

  const leaderstats = `-- ServerScriptService/LeaderstatsServer
local Players = game:GetService("Players")

local function setupLeaderstats(player)
\tlocal leaderstats = player:FindFirstChild("leaderstats")
\tif not leaderstats then
\t\tleaderstats = Instance.new("Folder")
\t\tleaderstats.Name = "leaderstats"
\t\tleaderstats.Parent = player
\tend

\tlocal coins = leaderstats:FindFirstChild("Coins")
\tif not coins then
\t\tcoins = Instance.new("IntValue")
\t\tcoins.Name = "Coins"
\t\tcoins.Value = 0
\t\tcoins.Parent = leaderstats
\tend
end

Players.PlayerAdded:Connect(setupLeaderstats)

for _, player in Players:GetPlayers() do
\ttask.spawn(setupLeaderstats, player)
end
`;

  const money = `-- ServerScriptService/MoneyServer
-- Валюту меняет только сервер. Клиент не присылает сумму награды.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local remotes = ReplicatedStorage:FindFirstChild("Remotes")
if not remotes then
\tremotes = Instance.new("Folder")
\tremotes.Name = "Remotes"
\tremotes.Parent = ReplicatedStorage
end

local function ensureRemote(name)
\tlocal existing = remotes:FindFirstChild(name)
\tif existing and existing:IsA("RemoteEvent") then
\t\treturn existing
\tend
\tlocal remote = Instance.new("RemoteEvent")
\tremote.Name = name
\tremote.Parent = remotes
\treturn remote
end

local moneyChanged = ensureRemote("MoneyChanged")

local function coinsOf(player)
\tlocal leaderstats = player:FindFirstChild("leaderstats")
\tif not leaderstats then
\t\tleaderstats = Instance.new("Folder")
\t\tleaderstats.Name = "leaderstats"
\t\tleaderstats.Parent = player
\tend
\tlocal coins = leaderstats:FindFirstChild("Coins")
\tif not coins then
\t\tcoins = Instance.new("IntValue")
\t\tcoins.Name = "Coins"
\t\tcoins.Value = 0
\t\tcoins.Parent = leaderstats
\tend
\treturn coins
end

local Money = {}

function Money.Add(player, amount, reason)
\tif typeof(amount) ~= "number" then
\t\treturn false
\tend
\tamount = math.floor(amount)
\tif amount == 0 then
\t\treturn false
\tend
\tlocal coins = coinsOf(player)
\tlocal nextValue = coins.Value + amount
\tif nextValue < 0 then
\t\treturn false
\tend
\tcoins.Value = nextValue
\tmoneyChanged:FireClient(player, coins.Value, tostring(reason or ""))
\treturn true
end

Players.PlayerAdded:Connect(function(player)
\tcoinsOf(player)
end)

for _, player in Players:GetPlayers() do
\ttask.spawn(coinsOf, player)
end

-- Другие серверные скрипты могут вызвать _G только если вы сами так решите.
-- Надёжнее вынести Money в ModuleScript и подключать его через require.
_G.RubAIMoney = Money
`;

  const datastore = `-- ServerScriptService/PlayerDataServer
-- Включите Studio Access to API Services только у тестовой копии опыта.
-- Ключ сохранения — UserId, не имя. Имя игрок может сменить.
local Players = game:GetService("Players")
local DataStoreService = game:GetService("DataStoreService")

local playerStore = DataStoreService:GetDataStore("PlayerData_v1")
local session = {}

local function defaultData()
\treturn { Coins = 0 }
end

local function withRetry(callback)
\tlocal lastError = nil
\tfor attempt = 1, 3 do
\t\tlocal ok, result = pcall(callback)
\t\tif ok then
\t\t\treturn true, result
\t\tend
\t\tlastError = result
\t\ttask.wait(attempt)
\tend
\treturn false, lastError
end

local function ensureCoins(player, amount)
\tlocal leaderstats = player:FindFirstChild("leaderstats")
\tif not leaderstats then
\t\tleaderstats = Instance.new("Folder")
\t\tleaderstats.Name = "leaderstats"
\t\tleaderstats.Parent = player
\tend
\tlocal coins = leaderstats:FindFirstChild("Coins")
\tif not coins then
\t\tcoins = Instance.new("IntValue")
\t\tcoins.Name = "Coins"
\t\tcoins.Parent = leaderstats
\tend
\tcoins.Value = math.max(0, math.floor(amount))
\treturn coins
end

local function loadPlayer(player)
\tlocal key = "player_" .. player.UserId
\tlocal ok, data = withRetry(function()
\t\treturn playerStore:GetAsync(key)
\tend)
\tlocal coins = 0
\tif ok and typeof(data) == "table" and typeof(data.Coins) == "number" then
\t\tcoins = data.Coins
\telseif not ok then
\t\twarn("Не удалось загрузить данные:", player.UserId, data)
\tend
\tensureCoins(player, coins)
\tsession[player] = true
end

local function savePlayer(player)
\tif not session[player] then
\t\treturn
\tend
\tlocal leaderstats = player:FindFirstChild("leaderstats")
\tlocal coins = leaderstats and leaderstats:FindFirstChild("Coins")
\tif not coins or not coins:IsA("IntValue") then
\t\treturn
\tend
\tlocal key = "player_" .. player.UserId
\tlocal payloadCoins = coins.Value
\tlocal ok, err = withRetry(function()
\t\treturn playerStore:UpdateAsync(key, function(oldValue)
\t\t\tlocal previous = {}\n\t\t\tif typeof(oldValue) == "table" then\n\t\t\t\tprevious = table.clone(oldValue)\n\t\t\tend
\t\t\tprevious.Coins = payloadCoins
\t\t\tprevious.UpdatedAt = os.time()
\t\t\treturn previous
\t\tend)
\tend)
\tif not ok then
\t\twarn("Не удалось сохранить данные:", player.UserId, err)
\tend
end

Players.PlayerAdded:Connect(loadPlayer)
Players.PlayerRemoving:Connect(function(player)
\tsavePlayer(player)
\tsession[player] = nil
end)

game:BindToClose(function()
\tlocal pending = 0
\tfor _, player in Players:GetPlayers() do
\t\tpending += 1
\t\ttask.spawn(function()
\t\t\tsavePlayer(player)
\t\t\tpending -= 1
\t\tend)
\tend
\tlocal started = os.clock()
\twhile pending > 0 and os.clock() - started < 20 do
\t\ttask.wait(0.1)
\tend
end)

for _, player in Players:GetPlayers() do
\ttask.spawn(loadPlayer, player)
end
`;

  const shopServer = `-- ServerScriptService/ShopServer
-- Клиент передаёт только имя предмета. Цена проверяется здесь.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local ITEMS = {
\tSpeedCoil = { price = 100 },
\tJumpCoil = { price = 150 },
}

local remotes = ReplicatedStorage:FindFirstChild("Remotes")
if not remotes then
\tremotes = Instance.new("Folder")
\tremotes.Name = "Remotes"
\tremotes.Parent = ReplicatedStorage
end

local function ensureRemote(name)
\tlocal existing = remotes:FindFirstChild(name)
\tif existing and existing:IsA("RemoteEvent") then
\t\treturn existing
\tend
\tlocal remote = Instance.new("RemoteEvent")
\tremote.Name = name
\tremote.Parent = remotes
\treturn remote
end

local purchaseEvent = ensureRemote("PurchaseItem")
local lastRequest = {}
local COOLDOWN_SECONDS = 0.35

local function ensureCoins(player)
\tlocal leaderstats = player:FindFirstChild("leaderstats")
\tif not leaderstats then
\t\tleaderstats = Instance.new("Folder")
\t\tleaderstats.Name = "leaderstats"
\t\tleaderstats.Parent = player
\tend
\tlocal coins = leaderstats:FindFirstChild("Coins")
\tif not coins then
\t\tcoins = Instance.new("IntValue")
\t\tcoins.Name = "Coins"
\t\tcoins.Value = 0
\t\tcoins.Parent = leaderstats
\tend
\treturn coins
end

local function grantItem(player, itemName)
\tlocal folder = ServerStorage:FindFirstChild("ShopTools")
\tlocal template = folder and folder:FindFirstChild(itemName)
\tlocal tool
\tif template and template:IsA("Tool") then
\t\ttool = template:Clone()
\telse
\t\ttool = Instance.new("Tool")
\t\ttool.Name = itemName
\t\ttool.RequiresHandle = true
\t\tlocal handle = Instance.new("Part")
\t\thandle.Name = "Handle"
\t\thandle.Size = Vector3.new(1, 1, 3)
\t\thandle.Parent = tool
\tend
\tlocal backpack = player:FindFirstChildOfClass("Backpack")
\tif backpack then
\t\ttool.Parent = backpack
\tend
end

purchaseEvent.OnServerEvent:Connect(function(player, itemName)
\tif typeof(itemName) ~= "string" or #itemName > 40 then
\t\treturn
\tend
\tlocal now = os.clock()
\tif now - (lastRequest[player] or 0) < COOLDOWN_SECONDS then
\t\treturn
\tend
\tlastRequest[player] = now

\tlocal item = ITEMS[itemName]
\tif not item then
\t\treturn
\tend
\tlocal coins = ensureCoins(player)
\tif coins.Value < item.price then
\t\treturn
\tend
\tcoins.Value -= item.price
\tgrantItem(player, itemName)
end)

Players.PlayerAdded:Connect(function(player)
\tensureCoins(player)
end)

for _, player in Players:GetPlayers() do
\ttask.spawn(ensureCoins, player)
end

Players.PlayerRemoving:Connect(function(player)
\tlastRequest[player] = nil
end)
`;

  const shopClient = `-- StarterPlayer/StarterPlayerScripts/ShopClient
-- Надпись с ценой только для игрока. Списывает монеты сервер.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local player = Players.LocalPlayer
local purchaseEvent = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("PurchaseItem")

local gui = Instance.new("ScreenGui")
gui.Name = "RubAIShopGui"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local frame = Instance.new("Frame")
frame.Name = "Panel"
frame.Size = UDim2.fromOffset(230, 160)
frame.Position = UDim2.new(0, 16, 1, -180)
frame.BackgroundColor3 = Color3.fromRGB(28, 30, 34)
frame.Parent = gui

local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 12)
corner.Parent = frame

local layout = Instance.new("UIListLayout")
layout.Padding = UDim.new(0, 8)
layout.Parent = frame

local padding = Instance.new("UIPadding")
padding.PaddingTop = UDim.new(0, 10)
padding.PaddingLeft = UDim.new(0, 10)
padding.PaddingRight = UDim.new(0, 10)
padding.Parent = frame

local function addButton(itemName, label)
\tlocal button = Instance.new("TextButton")
\tbutton.Size = UDim2.new(1, 0, 0, 44)
\tbutton.BackgroundColor3 = Color3.fromRGB(166, 230, 90)
\tbutton.TextColor3 = Color3.fromRGB(20, 28, 10)
\tbutton.Font = Enum.Font.GothamMedium
\tbutton.TextSize = 16
\tbutton.Text = label
\tbutton.Parent = frame
\tlocal buttonCorner = Instance.new("UICorner")
\tbuttonCorner.CornerRadius = UDim.new(0, 8)
\tbuttonCorner.Parent = button
\tbutton.Activated:Connect(function()
\t\tpurchaseEvent:FireServer(itemName)
\tend)
end

addButton("SpeedCoil", "Speed Coil")
addButton("JumpCoil", "Jump Coil")
`;

  const inventoryServer = `-- ServerScriptService/InventoryServer
-- Содержимое инвентаря меняется только на сервере и уходит владельцу.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local remotes = ReplicatedStorage:FindFirstChild("Remotes")
if not remotes then
\tremotes = Instance.new("Folder")
\tremotes.Name = "Remotes"
\tremotes.Parent = ReplicatedStorage
end

local function ensureRemote(name)
\tlocal existing = remotes:FindFirstChild(name)
\tif existing and existing:IsA("RemoteEvent") then
\t\treturn existing
\tend
\tlocal remote = Instance.new("RemoteEvent")
\tremote.Name = name
\tremote.Parent = remotes
\treturn remote
end

local requestInventory = ensureRemote("RequestInventory")
local inventoryChanged = ensureRemote("InventoryChanged")
local useItem = ensureRemote("UseItem")
local inventories = {}

local function snapshot(player)
\tlocal list = {}
\tlocal data = inventories[player]
\tif data then
\t\tfor itemId, count in data do
\t\t\ttable.insert(list, { id = itemId, count = count })
\t\tend
\tend
\treturn list
end

local function push(player)
\tif player.Parent then
\t\tinventoryChanged:FireClient(player, snapshot(player))
\tend
end

local function addItem(player, itemId, count)
\tif typeof(itemId) ~= "string" or #itemId == 0 or #itemId > 40 then
\t\treturn false
\tend
\tif string.find(itemId, "[^%w_]") then
\t\treturn false
\tend
\tcount = math.floor(tonumber(count) or 0)
\tif count == 0 then
\t\treturn false
\tend
\tlocal data = inventories[player]
\tif not data then
\t\treturn false
\tend
\tlocal nextCount = (data[itemId] or 0) + count
\tif nextCount < 0 then
\t\treturn false
\tend
\tif nextCount == 0 then
\t\tdata[itemId] = nil
\telse
\t\tdata[itemId] = nextCount
\tend
\tpush(player)
\treturn true
end

local function setup(player)
\tinventories[player] = { Wood = 3, Stone = 1 }
\tpush(player)
end

Players.PlayerAdded:Connect(setup)
Players.PlayerRemoving:Connect(function(player)
\tinventories[player] = nil
end)
for _, player in Players:GetPlayers() do
\tif not inventories[player] then
\t\ttask.spawn(setup, player)
\tend
end

requestInventory.OnServerEvent:Connect(function(player)
\tpush(player)
end)

useItem.OnServerEvent:Connect(function(player, itemId)
\tif typeof(itemId) ~= "string" then
\t\treturn
\tend
\tlocal data = inventories[player]
\tif not data or (data[itemId] or 0) <= 0 then
\t\treturn
\tend
\taddItem(player, itemId, -1)
end)
`;

  const inventoryClient = `-- StarterPlayer/StarterPlayerScripts/InventoryClient
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local player = Players.LocalPlayer
local remotes = ReplicatedStorage:WaitForChild("Remotes")
local requestInventory = remotes:WaitForChild("RequestInventory")
local inventoryChanged = remotes:WaitForChild("InventoryChanged")
local useItem = remotes:WaitForChild("UseItem")

local gui = Instance.new("ScreenGui")
gui.Name = "RubAIInventoryGui"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local frame = Instance.new("Frame")
frame.Size = UDim2.fromOffset(240, 220)
frame.Position = UDim2.new(1, -256, 0, 16)
frame.BackgroundColor3 = Color3.fromRGB(28, 30, 34)
frame.Parent = gui
local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 12)
corner.Parent = frame

local list = Instance.new("Frame")
list.Name = "List"
list.Size = UDim2.new(1, -16, 1, -16)
list.Position = UDim2.fromOffset(8, 8)
list.BackgroundTransparency = 1
list.Parent = frame
local layout = Instance.new("UIListLayout")
layout.Padding = UDim.new(0, 6)
layout.Parent = list

local function draw(items)
\tfor _, child in list:GetChildren() do
\t\tif child:IsA("TextButton") then
\t\t\tchild:Destroy()
\t\tend
\tend
\tif typeof(items) ~= "table" then
\t\treturn
\tend
\tfor _, item in items do
\t\tif typeof(item) == "table" and typeof(item.id) == "string" then
\t\t\tlocal button = Instance.new("TextButton")
\t\t\tbutton.Size = UDim2.new(1, 0, 0, 36)
\t\t\tbutton.BackgroundColor3 = Color3.fromRGB(48, 52, 58)
\t\t\tbutton.TextColor3 = Color3.fromRGB(236, 236, 236)
\t\t\tbutton.Font = Enum.Font.Gotham
\t\t\tbutton.TextSize = 14
\t\t\tbutton.Text = item.id .. "  x" .. tostring(item.count or 0)
\t\t\tbutton.Parent = list
\t\t\tlocal id = item.id
\t\t\tbutton.Activated:Connect(function()
\t\t\t\tuseItem:FireServer(id)
\t\t\tend)
\t\tend
\tend
end

inventoryChanged.OnClientEvent:Connect(draw)
requestInventory:FireServer()
`;

  const pets = `-- ServerScriptService/PetServer
-- Если в ServerStorage есть Model или BasePart с именем PetTemplate, клонируется он.
-- Иначе создаётся простая деталь-спутник, без чужого Asset ID.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local ServerStorage = game:GetService("ServerStorage")

local remotes = ReplicatedStorage:FindFirstChild("Remotes")
if not remotes then
\tremotes = Instance.new("Folder")
\tremotes.Name = "Remotes"
\tremotes.Parent = ReplicatedStorage
end

local function ensureRemote(name)
\tlocal existing = remotes:FindFirstChild(name)
\tif existing and existing:IsA("RemoteEvent") then
\t\treturn existing
\tend
\tlocal remote = Instance.new("RemoteEvent")
\tremote.Name = name
\tremote.Parent = remotes
\treturn remote
end

local togglePet = ensureRemote("TogglePet")
local equipped = {}

local function destroyPet(player)
\tlocal pet = equipped[player]
\tif pet then
\t\tpet:Destroy()
\tend
\tequipped[player] = nil
end

local function createPet(player)
\tdestroyPet(player)
\tlocal template = ServerStorage:FindFirstChild("PetTemplate")
\tlocal pet
\tif template and (template:IsA("Model") or template:IsA("BasePart")) then
\t\tpet = template:Clone()
\telse
\t\tpet = Instance.new("Part")
\t\tpet.Size = Vector3.new(2, 2, 2)
\t\tpet.Color = Color3.fromRGB(255, 196, 64)
\t\tpet.Material = Enum.Material.SmoothPlastic
\tend
\tpet.Name = "Pet_" .. player.UserId
\tif pet:IsA("BasePart") then
\t\tpet.Anchored = true
\t\tpet.CanCollide = false
\telseif pet:IsA("Model") then
\t\tfor _, descendant in pet:GetDescendants() do
\t\t\tif descendant:IsA("BasePart") then
\t\t\t\tdescendant.Anchored = true
\t\t\t\tdescendant.CanCollide = false
\t\t\tend
\t\tend
\tend
\tpet.Parent = workspace
\tequipped[player] = pet
end

togglePet.OnServerEvent:Connect(function(player)
\tif equipped[player] then
\t\tdestroyPet(player)
\telse
\t\tcreatePet(player)
\tend
end)

Players.PlayerAdded:Connect(function(player)
\tcreatePet(player)
end)

Players.PlayerRemoving:Connect(destroyPet)

for _, player in Players:GetPlayers() do
\ttask.spawn(createPet, player)
end

RunService.Heartbeat:Connect(function()
\tfor player, pet in equipped do
\t\tlocal character = player.Character
\t\tlocal root = character and character:FindFirstChild("HumanoidRootPart")
\t\tif root and pet.Parent then
\t\t\tlocal goal = root.CFrame * CFrame.new(3, 2, 3)
\t\t\tif pet:IsA("Model") then
\t\t\t\tpet:PivotTo(pet:GetPivot():Lerp(goal, 0.18))
\t\t\telseif pet:IsA("BasePart") then
\t\t\t\tpet.CFrame = pet.CFrame:Lerp(goal, 0.18)
\t\t\tend
\t\tend
\tend
end)
`;

  const bases = `-- ServerScriptService/PlayerBaseServer
-- Создаёт два участка, если их ещё нет. Игрок занимает свободный ClaimPad.
local Players = game:GetService("Players")

local plotsFolder = workspace:FindFirstChild("PlayerPlots")
if not plotsFolder then
\tplotsFolder = Instance.new("Folder")
\tplotsFolder.Name = "PlayerPlots"
\tplotsFolder.Parent = workspace
end

local owners = {}

local function makePlot(index)
\tlocal name = "Plot" .. index
\tlocal plot = plotsFolder:FindFirstChild(name)
\tif not plot then
\t\tplot = Instance.new("Part")
\t\tplot.Name = name
\t\tplot.Anchored = true
\t\tplot.Size = Vector3.new(40, 1, 40)
\t\tplot.Position = Vector3.new((index - 1) * 52, 0.5, 0)
\t\tplot.Color = Color3.fromRGB(70, 78, 70)
\t\tplot.Parent = plotsFolder
\tend
\tlocal pad = plot:FindFirstChild("ClaimPad")
\tif not pad then
\t\tpad = Instance.new("Part")
\t\tpad.Name = "ClaimPad"
\t\tpad.Anchored = true
\t\tpad.Size = Vector3.new(6, 1, 6)
\t\tpad.Color = Color3.fromRGB(80, 200, 120)
\t\tpad.Parent = plot
\tend
\tpad.CFrame = plot.CFrame * CFrame.new(0, 1.5, -16)
\treturn plot, pad
end

local function releasePlayer(player)
\tfor plot, userId in owners do
\t\tif userId == player.UserId then
\t\t\towners[plot] = nil
\t\t\tplot:SetAttribute("OwnerUserId", nil)
\t\t\tlocal pad = plot:FindFirstChild("ClaimPad")
\t\t\tif pad and pad:IsA("BasePart") then
\t\t\t\tpad.Color = Color3.fromRGB(80, 200, 120)
\t\t\tend
\t\tend
\tend
end

local function hook(plot, pad)
\tlocal busy = false
\tpad.Touched:Connect(function(hit)
\t\tif busy then
\t\t\treturn
\t\tend
\t\tlocal character = hit:FindFirstAncestorOfClass("Model")
\t\tlocal player = character and Players:GetPlayerFromCharacter(character)
\t\tif not player then
\t\t\treturn
\t\tend
\t\tlocal current = owners[plot]
\t\tif current and current ~= player.UserId then
\t\t\treturn
\t\tend
\t\tbusy = true
\t\towners[plot] = player.UserId
\t\tplot:SetAttribute("OwnerUserId", player.UserId)
\t\tpad.Color = Color3.fromRGB(90, 160, 255)
\t\ttask.delay(1, function()
\t\t\tbusy = false
\t\tend)
\tend)
end

for index = 1, 2 do
\tlocal plot, pad = makePlot(index)
\thook(plot, pad)
end

Players.PlayerRemoving:Connect(releasePlayer)
`;

  const npc = `-- ServerScriptService/NpcPatrol
-- Если в Workspace есть модель RubNPC с Humanoid, используется PathfindingService.
-- Иначе скрипт создаёт видимую деталь и ведёт её через TweenService.
local PathfindingService = game:GetService("PathfindingService")
local TweenService = game:GetService("TweenService")

local points = {
\tVector3.new(0, 3, 0),
\tVector3.new(24, 3, 0),
\tVector3.new(24, 3, 24),
\tVector3.new(0, 3, 24),
}

local function existingRig()
\tlocal model = workspace:FindFirstChild("RubNPC")
\tif model and model:IsA("Model") and model:FindFirstChildOfClass("Humanoid") then
\t\treturn model
\tend
\treturn nil
end

local function patrolHumanoid(model)
\tlocal humanoid = model:FindFirstChildOfClass("Humanoid")
\tlocal root = model:FindFirstChild("HumanoidRootPart")
\tif not humanoid or not root then
\t\treturn false
\tend
\twhile model.Parent do
\t\tfor _, point in points do
\t\t\tlocal path = PathfindingService:CreatePath({
\t\t\t\tAgentRadius = 2,
\t\t\t\tAgentHeight = 5,
\t\t\t\tAgentCanJump = true,
\t\t\t})
\t\t\tlocal computed = pcall(function()
\t\t\t\tpath:ComputeAsync(root.Position, point)
\t\t\tend)
\t\t\tif computed and path.Status == Enum.PathStatus.Success then
\t\t\t\tfor _, waypoint in path:GetWaypoints() do
\t\t\t\t\thumanoid:MoveTo(waypoint.Position)
\t\t\t\t\tlocal finished = false
\t\t\t\t\tlocal connection = humanoid.MoveToFinished:Connect(function()
\t\t\t\t\t\tfinished = true
\t\t\t\t\tend)
\t\t\t\t\tlocal started = os.clock()
\t\t\t\t\twhile not finished and os.clock() - started < 6 and model.Parent do
\t\t\t\t\t\ttask.wait(0.1)
\t\t\t\t\tend
\t\t\t\t\tif connection.Connected then
\t\t\t\t\t\tconnection:Disconnect()
\t\t\t\t\tend
\t\t\t\tend
\t\t\telse
\t\t\t\thumanoid:MoveTo(point)
\t\t\t\ttask.wait(1)
\t\t\tend
\t\tend
\tend
\treturn true
end

local function patrolMarker()
\tlocal marker = workspace:FindFirstChild("RubNPCMarker")
\tif not (marker and marker:IsA("BasePart")) then
\t\tmarker = Instance.new("Part")
\t\tmarker.Name = "RubNPCMarker"
\t\tmarker.Size = Vector3.new(2, 5, 2)
\t\tmarker.Color = Color3.fromRGB(90, 160, 255)
\t\tmarker.Anchored = true
\t\tmarker.CanCollide = false
\t\tmarker.Position = points[1]
\t\tmarker.Parent = workspace
\t\tlocal billboard = Instance.new("BillboardGui")
\t\tbillboard.Size = UDim2.fromOffset(80, 24)
\t\tbillboard.StudsOffset = Vector3.new(0, 3, 0)
\t\tbillboard.AlwaysOnTop = true
\t\tbillboard.Parent = marker
\t\tlocal label = Instance.new("TextLabel")
\t\tlabel.Size = UDim2.fromScale(1, 1)
\t\tlabel.BackgroundTransparency = 1
\t\tlabel.Text = "NPC"
\t\tlabel.TextColor3 = Color3.new(1, 1, 1)
\t\tlabel.Font = Enum.Font.GothamBold
\t\tlabel.TextSize = 14
\t\tlabel.Parent = billboard
\tend
\tlocal index = 1
\twhile marker.Parent do
\t\tindex = index % #points + 1
\t\tlocal tween = TweenService:Create(marker, TweenInfo.new(2, Enum.EasingStyle.Linear), {
\t\t\tPosition = points[index],
\t\t})
\t\ttween:Play()
\t\ttween.Completed:Wait()
\tend
end

local rig = existingRig()
if rig then
\ttask.spawn(patrolHumanoid, rig)
else
\ttask.spawn(patrolMarker)
end
`;

  const roundsServer = `-- ServerScriptService/RoundServer
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local MIN_PLAYERS = 2
local INTERMISSION_SECONDS = 15
local ROUND_SECONDS = 90

local remotes = ReplicatedStorage:FindFirstChild("Remotes")
if not remotes then
\tremotes = Instance.new("Folder")
\tremotes.Name = "Remotes"
\tremotes.Parent = ReplicatedStorage
end
local stateEvent = remotes:FindFirstChild("RoundState")
if not (stateEvent and stateEvent:IsA("RemoteEvent")) then
\tstateEvent = Instance.new("RemoteEvent")
\tstateEvent.Name = "RoundState"
\tstateEvent.Parent = remotes
end

local function setState(stateName, seconds)
\tstateEvent:FireAllClients(stateName, seconds)
end

while true do
\twhile #Players:GetPlayers() < MIN_PLAYERS do
\t\tsetState("Waiting", 0)
\t\ttask.wait(2)
\tend
\tfor second = INTERMISSION_SECONDS, 1, -1 do
\t\tsetState("Intermission", second)
\t\ttask.wait(1)
\tend
\tif #Players:GetPlayers() >= MIN_PLAYERS then
\t\tfor second = ROUND_SECONDS, 1, -1 do
\t\t\tsetState("Active", second)
\t\t\ttask.wait(1)
\t\tend
\t\tsetState("Results", 5)
\t\ttask.wait(5)
\tend
end
`;

  const roundsClient = `-- StarterPlayer/StarterPlayerScripts/RoundClient
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local player = Players.LocalPlayer
local stateEvent = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("RoundState")
local gui = Instance.new("ScreenGui")
gui.Name = "RoundGui"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local label = Instance.new("TextLabel")
label.Size = UDim2.fromOffset(280, 40)
label.Position = UDim2.new(0.5, -140, 0, 12)
label.BackgroundColor3 = Color3.fromRGB(20, 22, 26)
label.TextColor3 = Color3.new(1, 1, 1)
label.Font = Enum.Font.GothamMedium
label.TextSize = 16
label.Text = "Ожидание"
label.Parent = gui
local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 10)
corner.Parent = label

stateEvent.OnClientEvent:Connect(function(stateName, seconds)
\tif typeof(stateName) ~= "string" then
\t\treturn
\tend
\tlocal names = {
\t\tWaiting = "Ждём игроков",
\t\tIntermission = "Пауза",
\t\tActive = "Раунд",
\t\tResults = "Итог",
\t}
\tlocal title = names[stateName] or stateName
\tif typeof(seconds) == "number" and seconds > 0 then
\t\tlabel.Text = title .. ": " .. tostring(math.floor(seconds))
\telse
\t\tlabel.Text = title
\tend
end)
`;

  const teleport = `-- ServerScriptService/TeleportPads
-- Телепорт внутри этого места через CFrame. Чужой PlaceId здесь не подставлен.
-- Для перехода в другой опыт используйте TeleportService:TeleportAsync
-- только со своим реальным PlaceId.
local Players = game:GetService("Players")

local function ensurePad(name, position, color)
\tlocal pad = workspace:FindFirstChild(name)
\tif pad and pad:IsA("BasePart") then
\t\treturn pad
\tend
\tpad = Instance.new("Part")
\tpad.Name = name
\tpad.Anchored = true
\tpad.Size = Vector3.new(6, 1, 6)
\tpad.Position = position
\tpad.Color = color
\tpad.Parent = workspace
\treturn pad
end

local padA = ensurePad("TeleportA", Vector3.new(0, 1, 0), Color3.fromRGB(90, 170, 255))
local padB = ensurePad("TeleportB", Vector3.new(0, 1, 80), Color3.fromRGB(255, 170, 90))
local locked = {}

local function hook(fromPad, toPad)
\tfromPad.Touched:Connect(function(hit)
\t\tlocal character = hit:FindFirstAncestorOfClass("Model")
\t\tlocal player = character and Players:GetPlayerFromCharacter(character)
\t\tif not player or locked[player] then
\t\t\treturn
\t\tend
\t\tlocal root = character:FindFirstChild("HumanoidRootPart")
\t\tif not root or not root:IsA("BasePart") then
\t\t\treturn
\t\tend
\t\tlocked[player] = true
\t\troot.CFrame = toPad.CFrame + Vector3.new(0, 4, 0)
\t\ttask.delay(1, function()
\t\t\tlocked[player] = nil
\t\tend)
\tend)
end

hook(padA, padB)
hook(padB, padA)

Players.PlayerRemoving:Connect(function(player)
\tlocked[player] = nil
end)
`;

  const questsServer = `-- ServerScriptService/QuestServer
-- Клиент не может сам отметить квест выполненным.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local QUESTS = {
\tFirstCoins = { title = "Собери монеты", target = 10 },
}

local remotes = ReplicatedStorage:FindFirstChild("Remotes")
if not remotes then
\tremotes = Instance.new("Folder")
\tremotes.Name = "Remotes"
\tremotes.Parent = ReplicatedStorage
end

local function ensureRemote(name)
\tlocal existing = remotes:FindFirstChild(name)
\tif existing and existing:IsA("RemoteEvent") then
\t\treturn existing
\tend
\tlocal remote = Instance.new("RemoteEvent")
\tremote.Name = name
\tremote.Parent = remotes
\treturn remote
end

local questState = ensureRemote("QuestState")
local questRefresh = ensureRemote("QuestRefresh")
local progress = {}

local function coinsOf(player)
\tlocal leaderstats = player:FindFirstChild("leaderstats")
\tlocal coins = leaderstats and leaderstats:FindFirstChild("Coins")
\tif coins and coins:IsA("IntValue") then
\t\treturn coins.Value
\tend
\treturn 0
end

local function snapshot(player)
\tlocal state = progress[player] or {}
\tlocal list = {}
\tfor id, quest in QUESTS do
\t\ttable.insert(list, {
\t\t\tid = id,
\t\t\ttitle = quest.title,
\t\t\ttarget = quest.target,
\t\t\tcurrent = coinsOf(player),
\t\t\tdone = state[id] == true,
\t\t})
\tend
\treturn list
end

local function evaluate(player)
\tlocal state = progress[player]
\tif not state then
\t\treturn
\tend
\tlocal coins = coinsOf(player)
\tfor id, quest in QUESTS do
\t\tif coins >= quest.target then
\t\t\tstate[id] = true
\t\tend
\tend
\tquestState:FireClient(player, snapshot(player))
end

Players.PlayerAdded:Connect(function(player)
\tprogress[player] = {}
\tevaluate(player)
end)

Players.PlayerRemoving:Connect(function(player)
\tprogress[player] = nil
end)

questRefresh.OnServerEvent:Connect(function(player)
\tevaluate(player)
end)

for _, player in Players:GetPlayers() do
\tif not progress[player] then
\t\tprogress[player] = {}
\t\ttask.spawn(evaluate, player)
\tend
end
`;

  const questsClient = `-- StarterPlayer/StarterPlayerScripts/QuestClient
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local player = Players.LocalPlayer
local remotes = ReplicatedStorage:WaitForChild("Remotes")
local questState = remotes:WaitForChild("QuestState")
local questRefresh = remotes:WaitForChild("QuestRefresh")

local gui = Instance.new("ScreenGui")
gui.Name = "QuestGui"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local label = Instance.new("TextLabel")
label.Size = UDim2.fromOffset(260, 72)
label.Position = UDim2.new(0, 16, 0, 16)
label.BackgroundColor3 = Color3.fromRGB(20, 22, 26)
label.TextColor3 = Color3.new(1, 1, 1)
label.Font = Enum.Font.Gotham
label.TextSize = 14
label.TextWrapped = true
label.Text = "Квесты загружаются"
label.Parent = gui

questState.OnClientEvent:Connect(function(items)
\tif typeof(items) ~= "table" or typeof(items[1]) ~= "table" then
\t\tlabel.Text = "Квестов нет"
\t\treturn
\tend
\tlocal quest = items[1]
\tlocal mark = tostring(quest.current or 0) .. "/" .. tostring(quest.target or 0)\n\tif quest.done then\n\t\tmark = "готово"\n\tend
\tlabel.Text = tostring(quest.title or "Квест") .. " — " .. mark
end)

task.spawn(function()
\twhile gui.Parent do
\t\tquestRefresh:FireServer()
\t\ttask.wait(2)
\tend
end)
`;

  const gui = `-- StarterPlayer/StarterPlayerScripts/MainMenuClient
local Players = game:GetService("Players")

local player = Players.LocalPlayer
local gui = Instance.new("ScreenGui")
gui.Name = "MainMenu"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local frame = Instance.new("Frame")
frame.AnchorPoint = Vector2.new(0.5, 0.5)
frame.Position = UDim2.fromScale(0.5, 0.5)
frame.Size = UDim2.fromOffset(320, 180)
frame.BackgroundColor3 = Color3.fromRGB(24, 26, 30)
frame.Parent = gui

local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 14)
corner.Parent = frame

local title = Instance.new("TextLabel")
title.BackgroundTransparency = 1
title.Size = UDim2.new(1, -24, 0, 40)
title.Position = UDim2.fromOffset(12, 16)
title.Font = Enum.Font.GothamBold
title.TextSize = 22
title.TextXAlignment = Enum.TextXAlignment.Left
title.TextColor3 = Color3.new(1, 1, 1)
title.Text = "Меню"
title.Parent = frame

local play = Instance.new("TextButton")
play.Size = UDim2.new(1, -24, 0, 44)
play.Position = UDim2.fromOffset(12, 112)
play.BackgroundColor3 = Color3.fromRGB(166, 230, 90)
play.TextColor3 = Color3.fromRGB(20, 28, 10)
play.Font = Enum.Font.GothamMedium
play.TextSize = 16
play.Text = "Играть"
play.Parent = frame

play.Activated:Connect(function()
\tframe.Visible = false
end)
`;

  const adminServer = `-- ServerScriptService/AdminServer
-- Вставьте свой UserId. Пустой список значит, что команд нет ни у кого.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local ADMIN_USER_IDS = {
\t-- [000000] = true,
}

local function isAdmin(player)
\treturn ADMIN_USER_IDS[player.UserId] == true
end

local remotes = ReplicatedStorage:FindFirstChild("Remotes")
if not remotes then
\tremotes = Instance.new("Folder")
\tremotes.Name = "Remotes"
\tremotes.Parent = ReplicatedStorage
end
local commandEvent = remotes:FindFirstChild("AdminCommand")
if not (commandEvent and commandEvent:IsA("RemoteEvent")) then
\tcommandEvent = Instance.new("RemoteEvent")
\tcommandEvent.Name = "AdminCommand"
\tcommandEvent.Parent = remotes
end

local function findPlayer(name)
\tlocal lowered = string.lower(name)
\tfor _, player in Players:GetPlayers() do
\t\tif string.lower(player.Name) == lowered then
\t\t\treturn player
\t\tend
\tend
\treturn nil
end

commandEvent.OnServerEvent:Connect(function(player, rawText)
\tif not isAdmin(player) or typeof(rawText) ~= "string" or #rawText > 120 then
\t\treturn
\tend
\tlocal action, targetName, extra = string.match(rawText, "^(%w+)%s+(%w+)%s*(.*)$")
\tif not action or not targetName then
\t\treturn
\tend
\taction = string.lower(action)
\tlocal target = findPlayer(targetName)
\tif not target then
\t\treturn
\tend
\tif action == "kick" then
\t\tif target ~= player then
\t\t\ttarget:Kick(extra ~= "" and extra or "Кикнут администратором")
\t\tend
\telseif action == "coins" then
\t\tlocal amount = tonumber(extra)
\t\tif not amount then
\t\t\treturn
\t\tend
\t\tamount = math.clamp(math.floor(amount), -100000, 100000)
\t\tlocal leaderstats = target:FindFirstChild("leaderstats")
\t\tlocal coins = leaderstats and leaderstats:FindFirstChild("Coins")
\t\tif coins and coins:IsA("IntValue") then
\t\t\tcoins.Value = math.max(0, coins.Value + amount)
\t\tend
\tend
end)
`;

  const adminClient = `-- StarterPlayer/StarterPlayerScripts/AdminClient
-- Панель видна всем, но сервер выполняет команду только для UserId из списка.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local player = Players.LocalPlayer
local commandEvent = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("AdminCommand")

local gui = Instance.new("ScreenGui")
gui.Name = "AdminPanel"
gui.ResetOnSpawn = false
gui.Enabled = false
gui.Parent = player:WaitForChild("PlayerGui")

local frame = Instance.new("Frame")
frame.Size = UDim2.fromOffset(320, 120)
frame.Position = UDim2.new(0.5, -160, 1, -150)
frame.BackgroundColor3 = Color3.fromRGB(24, 26, 30)
frame.Parent = gui

local box = Instance.new("TextBox")
box.Size = UDim2.new(1, -20, 0, 36)
box.Position = UDim2.fromOffset(10, 16)
box.PlaceholderText = "coins Имя 10"
box.Text = ""
box.ClearTextOnFocus = false
box.Font = Enum.Font.Gotham
box.TextSize = 14
box.TextColor3 = Color3.new(1, 1, 1)
box.BackgroundColor3 = Color3.fromRGB(40, 42, 48)
box.Parent = frame

local send = Instance.new("TextButton")
send.Size = UDim2.new(1, -20, 0, 36)
send.Position = UDim2.fromOffset(10, 64)
send.Text = "Выполнить"
send.Font = Enum.Font.GothamMedium
send.TextSize = 15
send.BackgroundColor3 = Color3.fromRGB(166, 230, 90)
send.TextColor3 = Color3.fromRGB(20, 28, 10)
send.Parent = frame

send.Activated:Connect(function()
\tcommandEvent:FireServer(box.Text)
\tbox.Text = ""
end)

-- Открытие панели не даёт прав. Права проверяет AdminServer.
game:GetService("UserInputService").InputBegan:Connect(function(input, processed)
\tif processed then
\t\treturn
\tend
\tif input.KeyCode == Enum.KeyCode.F8 then
\t\tgui.Enabled = not gui.Enabled
\tend
end)
`;

  const rpServer = `-- ServerScriptService/RoleplayServer
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local ROLES = {
\tCitizen = "Гражданин",
\tPolice = "Полиция",
\tMedic = "Медик",
\tSeller = "Продавец",
}

local remotes = ReplicatedStorage:FindFirstChild("Remotes")
if not remotes then
\tremotes = Instance.new("Folder")
\tremotes.Name = "Remotes"
\tremotes.Parent = ReplicatedStorage
end
local setRole = remotes:FindFirstChild("SetRole")
if not (setRole and setRole:IsA("RemoteEvent")) then
\tsetRole = Instance.new("RemoteEvent")
\tsetRole.Name = "SetRole"
\tsetRole.Parent = remotes
end

local function applyRole(player, roleId)
\tlocal label = ROLES[roleId]
\tif not label then
\t\treturn
\tend
\tplayer:SetAttribute("RoleId", roleId)
\tlocal roleValue = player:FindFirstChild("Role")
\tif not roleValue then
\t\troleValue = Instance.new("StringValue")
\t\troleValue.Name = "Role"
\t\troleValue.Parent = player
\tend
\troleValue.Value = label
end

Players.PlayerAdded:Connect(function(player)
\tapplyRole(player, "Citizen")
end)

setRole.OnServerEvent:Connect(function(player, roleId)
\tif typeof(roleId) ~= "string" then
\t\treturn
\tend
\tapplyRole(player, roleId)
end)

for _, player in Players:GetPlayers() do
\tif player:GetAttribute("RoleId") == nil then
\t\tapplyRole(player, "Citizen")
\tend
end
`;

  const rpClient = `-- StarterPlayer/StarterPlayerScripts/RoleplayClient
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local player = Players.LocalPlayer
local setRole = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("SetRole")
local gui = Instance.new("ScreenGui")
gui.Name = "RoleGui"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local frame = Instance.new("Frame")
frame.Size = UDim2.fromOffset(180, 210)
frame.Position = UDim2.new(0, 12, 0.5, -105)
frame.BackgroundColor3 = Color3.fromRGB(24, 26, 30)
frame.Parent = gui
local layout = Instance.new("UIListLayout")
layout.Padding = UDim.new(0, 6)
layout.Parent = frame
local padding = Instance.new("UIPadding")
padding.PaddingTop = UDim.new(0, 8)
padding.PaddingLeft = UDim.new(0, 8)
padding.PaddingRight = UDim.new(0, 8)
padding.Parent = frame

local roles = {
\t{ id = "Citizen", label = "Гражданин" },
\t{ id = "Police", label = "Полиция" },
\t{ id = "Medic", label = "Медик" },
\t{ id = "Seller", label = "Продавец" },
}

for _, role in roles do
\tlocal button = Instance.new("TextButton")
\tbutton.Size = UDim2.new(1, 0, 0, 40)
\tbutton.BackgroundColor3 = Color3.fromRGB(48, 52, 58)
\tbutton.TextColor3 = Color3.new(1, 1, 1)
\tbutton.Font = Enum.Font.Gotham
\tbutton.TextSize = 14
\tbutton.Text = role.label
\tbutton.Parent = frame
\tlocal roleId = role.id
\tbutton.Activated:Connect(function()
\t\tsetRole:FireServer(roleId)
\tend)
end
`;

  const scaffold = `-- ServerScriptService/FeatureServer
local Players = game:GetService("Players")

local function onPlayerAdded(player)
\t-- Серверное состояние игрока. Награды и валюту здесь, не на клиенте.
\tprint("Игрок подключился:", player.Name)
end

Players.PlayerAdded:Connect(onPlayerAdded)

for _, player in Players:GetPlayers() do
\ttask.spawn(onPlayerAdded, player)
end
`;

  const script = (name, type, path, source) => ({ name, type, path, source });

  root.RubAITemplates = {
    SYSTEMS: {
      admin: {
        title: "Админ-панель",
        studio: "Script в ServerScriptService и LocalScript в StarterPlayerScripts. Свой UserId впишите в ADMIN_USER_IDS.",
        scripts: [
          script("AdminServer", "Script", "ServerScriptService/AdminServer", adminServer),
          script("AdminClient", "LocalScript", "StarterPlayer/StarterPlayerScripts/AdminClient", adminClient),
        ],
      },
      pets: {
        title: "Питомцы",
        studio: "Один Script в ServerScriptService. Свою модель можно положить в ServerStorage под именем PetTemplate.",
        scripts: [script("PetServer", "Script", "ServerScriptService/PetServer", pets)],
      },
      inventory: {
        title: "Инвентарь",
        studio: "Script в ServerScriptService и LocalScript в StarterPlayerScripts. Предметы не создаются из чужих Asset ID.",
        scripts: [
          script("InventoryServer", "Script", "ServerScriptService/InventoryServer", inventoryServer),
          script("InventoryClient", "LocalScript", "StarterPlayer/StarterPlayerScripts/InventoryClient", inventoryClient),
        ],
      },
      quests: {
        title: "Квесты",
        studio: "Прогресс считает сервер. LocalScript только показывает состояние и просит обновить его.",
        scripts: [
          script("QuestServer", "Script", "ServerScriptService/QuestServer", questsServer),
          script("QuestClient", "LocalScript", "StarterPlayer/StarterPlayerScripts/QuestClient", questsClient),
        ],
      },
      npc: {
        title: "NPC",
        studio: "Script в ServerScriptService. Настоящий риг из Rig Builder назовите RubNPC и поставьте HumanoidRootPart.",
        scripts: [script("NpcPatrol", "Script", "ServerScriptService/NpcPatrol", npc)],
      },
      rounds: {
        title: "Раунды",
        studio: "Серверный цикл в ServerScriptService. Надпись раунда — LocalScript, он не решает победителя.",
        scripts: [
          script("RoundServer", "Script", "ServerScriptService/RoundServer", roundsServer),
          script("RoundClient", "LocalScript", "StarterPlayer/StarterPlayerScripts/RoundClient", roundsClient),
        ],
      },
      teleport: {
        title: "Телепорты",
        studio: "Script в ServerScriptService создаёт TeleportA и TeleportB в Workspace, если их нет.",
        scripts: [script("TeleportPads", "Script", "ServerScriptService/TeleportPads", teleport)],
      },
      shop: {
        title: "Магазин",
        studio: "Покупка в ServerScriptService. Кнопки — LocalScript. Готовые Tool можно положить в ServerStorage/ShopTools.",
        scripts: [
          script("ShopServer", "Script", "ServerScriptService/ShopServer", shopServer),
          script("ShopClient", "LocalScript", "StarterPlayer/StarterPlayerScripts/ShopClient", shopClient),
        ],
      },
      rp: {
        title: "RP-роли",
        studio: "Роль записывает только сервер. Клиент присылает id роли из фиксированного списка.",
        scripts: [
          script("RoleplayServer", "Script", "ServerScriptService/RoleplayServer", rpServer),
          script("RoleplayClient", "LocalScript", "StarterPlayer/StarterPlayerScripts/RoleplayClient", rpClient),
        ],
      },
      base: {
        title: "Базы игроков",
        studio: "Script в ServerScriptService. Участки появляются в Workspace/PlayerPlots.",
        scripts: [script("PlayerBaseServer", "Script", "ServerScriptService/PlayerBaseServer", bases)],
      },
      gui: {
        title: "GUI",
        studio: "LocalScript в StarterPlayerScripts. Не выдавайте награды из этого скрипта.",
        scripts: [script("MainMenuClient", "LocalScript", "StarterPlayer/StarterPlayerScripts/MainMenuClient", gui)],
      },
      datastore: {
        title: "DataStore и сохранение",
        studio: "Только Script в ServerScriptService. Не копируйте этот код в LocalScript.",
        scripts: [script("PlayerDataServer", "Script", "ServerScriptService/PlayerDataServer", datastore)],
      },
      money: {
        title: "Деньги",
        studio: "Script в ServerScriptService. Функция Money.Add вызывается другими серверными скриптами, не клиентом.",
        scripts: [script("MoneyServer", "Script", "ServerScriptService/MoneyServer", money)],
      },
      leaderstats: {
        title: "Leaderstats",
        studio: "Script в ServerScriptService. Папка должна называться именно leaderstats.",
        scripts: [script("LeaderstatsServer", "Script", "ServerScriptService/LeaderstatsServer", leaderstats)],
      },
      scaffold: {
        title: "Каркас сервера",
        studio: "Положите Script в ServerScriptService и опишите механику точнее, чтобы получить профильный шаблон.",
        scripts: [script("FeatureServer", "Script", "ServerScriptService/FeatureServer", scaffold)],
      },
    },
  };
})(globalThis);
