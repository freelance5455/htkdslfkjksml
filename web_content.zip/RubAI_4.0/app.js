/* RubAI 4.0 UI. Сеть только для Creator Store и явной проверки backend. */
(() => {
  "use strict";

  const Engine = globalThis.RubAIEngine;
  if (!Engine) throw new Error("RubAI engine missing");

  const $ = (id) => document.getElementById(id);
  const STORE_KEY = "rubai_v4_data";
  const PREVIOUS_KEY = "rubai_v3_data";
  const LEGACY_PROJECTS = "rubai_projects";
  const LEGACY_CURRENT = "rubai_current_project";
  const LEGACY_SETTINGS = "rubai_settings";
  const views = ["studio", "store", "code", "projects", "review", "workflow", "settings"];
  const viewNames = {
    studio: "Студия",
    store: "Creator Store",
    code: "RubAI Code",
    projects: "Проекты",
    review: "Ревью",
    workflow: "Процесс",
    settings: "Настройки",
  };
  const scriptTypes = ["Script", "LocalScript", "ModuleScript"];
  let selectedView = "studio";
  let selectedScriptId = null;
  let pendingFindings = [];
  let isBusy = false;
  let modalResolver = null;
  let storageWarningShown = false;
  let recognition = null;
  let listening = false;
  let speaking = false;
  let storeCategory = "model";
  let storeResults = [];
  let storeCursor = "";
  let storeQuery = "";

  const makeId = () => (globalThis.crypto && crypto.randomUUID)
    ? crypto.randomUUID()
    : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
  const safeText = (value, max = 12000) => String(value == null ? "" : value).slice(0, max);
  const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (ch) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[ch]);
  const parseJson = (value, fallback) => {
    try { return value ? JSON.parse(value) : fallback; } catch { return fallback; }
  };
  const formatDate = (value) => {
    const date = new Date(value || Date.now());
    return Number.isNaN(date.getTime()) ? "сейчас" : date.toLocaleString("ru-RU", { dateStyle: "short", timeStyle: "short" });
  };
  const storageGet = (key) => { try { return localStorage.getItem(key); } catch { return null; } };
  const storageRemove = (key) => { try { localStorage.removeItem(key); } catch { /* ignore */ } };

  function defaultProject() {
    return {
      id: makeId(), name: "Мой Roblox-проект", task: "", constraints: "", spec: "",
      notes: "", requirements: "", decisions: "", reviews: [], scripts: [], chats: [],
      currentChatId: null, createdAt: Date.now(),
    };
  }
  function normalizeCode(code) {
    if (!code || typeof code !== "object") return null;
    const type = scriptTypes.includes(code.type) ? code.type : "Script";
    return {
      id: String(code.id || makeId()),
      name: safeText(code.name || "Script", 80),
      type,
      path: safeText(code.path || "ServerScriptService", 180),
      source: safeText(code.source || code.code, 30000),
    };
  }
  function normalizeProject(raw) {
    const project = raw && typeof raw === "object" ? raw : {};
    const normalized = {
      id: String(project.id || makeId()),
      name: safeText(project.name || "Roblox-проект", 80),
      task: safeText(project.task, 5000),
      constraints: safeText(project.constraints, 3000),
      spec: safeText(project.spec, 20000),
      notes: safeText(project.notes, 5000),
      requirements: safeText(project.requirements, 5000),
      decisions: safeText(project.decisions, 5000),
      reviews: Array.isArray(project.reviews) ? project.reviews.map((review) => ({
        id: String(review.id || makeId()),
        text: safeText(review.text || review.title, 500),
        severity: ["Высокий", "Средний", "Низкий"].includes(review.severity) ? review.severity : "Средний",
        status: ["open", "fixed", "wont"].includes(review.status) ? review.status : "open",
        createdAt: review.createdAt || Date.now(),
      })) : [],
      scripts: Array.isArray(project.scripts) ? project.scripts.map((script) => ({
        id: String(script.id || makeId()),
        name: safeText(script.name || "NewScript", 80),
        type: scriptTypes.includes(script.type) ? script.type : "Script",
        path: safeText(script.path || "ServerScriptService", 180),
        code: safeText(script.code, 50000),
        versions: Array.isArray(script.versions) ? script.versions.slice(-20).map((version) => ({
          id: String(version.id || makeId()),
          code: safeText(version.code, 50000),
          createdAt: version.createdAt || Date.now(),
        })) : [],
        updatedAt: script.updatedAt || Date.now(),
      })) : [],
      chats: Array.isArray(project.chats) ? project.chats.map((chat) => ({
        id: String(chat.id || makeId()),
        title: safeText(chat.title || "Новый чат", 90),
        createdAt: chat.createdAt || Date.now(),
        updatedAt: chat.updatedAt || Date.now(),
        messages: Array.isArray(chat.messages) ? chat.messages.slice(-250).map((message) => {
          const codes = Array.isArray(message.codes)
            ? message.codes.map(normalizeCode).filter(Boolean)
            : (normalizeCode(message.code) ? [normalizeCode(message.code)] : []);
          return {
            id: String(message.id || makeId()),
            role: message.role === "user" ? "user" : "assistant",
            content: safeText(message.content, 16000),
            codes,
            plan: message.plan === true,
            openStore: message.openStore === true,
            storeQuery: safeText(message.storeQuery, 60),
            summary: safeText(message.summary, 800),
          };
        }) : [],
      })) : [],
      currentChatId: project.currentChatId ? String(project.currentChatId) : null,
      createdAt: project.createdAt || Date.now(),
    };
    if (normalized.currentChatId && !normalized.chats.some((chat) => chat.id === normalized.currentChatId)) {
      normalized.currentChatId = null;
    }
    return normalized;
  }
  function normalizeSettings(raw) {
    const settings = raw && typeof raw === "object" ? raw : {};
    const mode = Engine.MODES[settings.mode] ? settings.mode : "rubdefault";
    const rate = Number(settings.voiceRate);
    return {
      apiEndpoint: safeText(settings.apiEndpoint, 500),
      mode,
      autoSpeak: settings.autoSpeak === true,
      voiceRate: [0.9, 1, 1.15].includes(rate) ? rate : 1,
    };
  }
  function loadInitialData() {
    const stored = parseJson(storageGet(STORE_KEY), null) || parseJson(storageGet(PREVIOUS_KEY), null);
    if (stored && Array.isArray(stored.projects) && stored.projects.length) {
      const projects = stored.projects.map(normalizeProject);
      const activeId = String(stored.currentProjectId || projects[0].id);
      return {
        version: 4,
        projects,
        currentProjectId: projects.some((project) => project.id === activeId) ? activeId : projects[0].id,
        settings: normalizeSettings(stored.settings),
      };
    }
    const legacyProjects = parseJson(storageGet(LEGACY_PROJECTS), null);
    const projects = Array.isArray(legacyProjects) && legacyProjects.length
      ? legacyProjects.map(normalizeProject)
      : [defaultProject()];
    const oldActive = String(storageGet(LEGACY_CURRENT) || projects[0].id);
    const legacySettings = parseJson(storageGet(LEGACY_SETTINGS), {});
    return {
      version: 4,
      projects,
      currentProjectId: projects.some((project) => project.id === oldActive) ? oldActive : projects[0].id,
      settings: normalizeSettings(legacySettings),
    };
  }

  let data = loadInitialData();
  function currentProject() {
    let project = data.projects.find((item) => item.id === data.currentProjectId);
    if (!project) {
      project = data.projects[0] || defaultProject();
      if (!data.projects.length) data.projects.push(project);
      data.currentProjectId = project.id;
    }
    return project;
  }
  function currentChat(project = currentProject()) {
    return project.chats.find((chat) => chat.id === project.currentChatId) || null;
  }
  function saveData() {
    data.version = 4;
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify(data));
      localStorage.setItem(LEGACY_PROJECTS, JSON.stringify(data.projects.map((project) => ({
        id: project.id, name: project.name, task: project.task, constraints: project.constraints,
        spec: project.spec, reviews: project.reviews, notes: project.notes,
        requirements: project.requirements, decisions: project.decisions,
      }))));
      localStorage.setItem(LEGACY_CURRENT, data.currentProjectId);
      localStorage.setItem(LEGACY_SETTINGS, JSON.stringify({ apiEndpoint: data.settings.apiEndpoint || "" }));
      storageWarningShown = false;
      return true;
    } catch {
      if (!storageWarningShown) {
        storageWarningShown = true;
        toast("Браузер не сохранил данные. Экспортируйте проект, пока вкладка открыта.", "warn");
      }
      return false;
    }
  }

  function toast(message, type = "info") {
    const container = $("toastContainer");
    if (!container) return;
    const node = document.createElement("div");
    node.className = `toast ${type}`;
    const text = document.createElement("span");
    text.textContent = message;
    const close = document.createElement("button");
    close.type = "button";
    close.setAttribute("aria-label", "Закрыть");
    close.textContent = "×";
    close.addEventListener("click", () => node.remove());
    node.append(text, close);
    container.appendChild(node);
    window.setTimeout(() => node.remove(), 4200);
  }
  function openModal({ title, description = "", input = false, inputValue = "", inputLabel = "", multiline = false, buttons = [] }) {
    $("modalTitle").textContent = title;
    $("modalDesc").textContent = description;
    const body = $("modalBody");
    body.replaceChildren();
    let inputNode = null;
    if (input) {
      if (inputLabel) {
        const label = document.createElement("label");
        label.className = "field-label";
        label.textContent = inputLabel;
        body.appendChild(label);
      }
      inputNode = multiline ? document.createElement("textarea") : document.createElement("input");
      inputNode.className = "field";
      inputNode.value = inputValue;
      if (!multiline) inputNode.maxLength = 120;
      body.appendChild(inputNode);
    }
    const actions = $("modalActions");
    actions.replaceChildren();
    $("modalBack").classList.add("open");
    return new Promise((resolve) => {
      modalResolver = resolve;
      buttons.forEach((button) => {
        const element = document.createElement("button");
        element.type = "button";
        element.className = `btn ${button.primary ? "primary" : ""} ${button.danger ? "danger" : ""}`;
        element.textContent = button.label;
        element.addEventListener("click", () => closeModal(button.value === "input" ? (inputNode ? inputNode.value.trim() : "") : button.value));
        actions.appendChild(element);
      });
      if (inputNode) window.setTimeout(() => inputNode.focus(), 30);
    });
  }
  function closeModal(result = null) {
    $("modalBack").classList.remove("open");
    if (modalResolver) {
      const resolve = modalResolver;
      modalResolver = null;
      resolve(result);
    }
  }
  const askText = (title, description, defaultValue = "") => openModal({
    title, description, input: true, inputValue: defaultValue,
    buttons: [{ label: "Отмена", value: null }, { label: "Сохранить", value: "input", primary: true }],
  });
  const askConfirm = (title, description) => openModal({
    title, description,
    buttons: [{ label: "Отмена", value: false }, { label: "Удалить", value: true, danger: true }],
  });

  function downloadFile(filename, content, mime = "text/plain;charset=utf-8") {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename.replace(/[\\/:*?"<>|]+/g, "_");
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  async function copyText(text) {
    try {
      if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(text);
      else {
        const helper = document.createElement("textarea");
        helper.value = text;
        helper.style.position = "fixed";
        helper.style.left = "-999px";
        document.body.appendChild(helper);
        helper.select();
        const copied = document.execCommand("copy");
        helper.remove();
        if (!copied) throw new Error("copy");
      }
      toast("Скопировано.", "success");
    } catch {
      toast("Не удалось скопировать. Выделите текст вручную.", "warn");
    }
  }

  function highlightLuau(source) {
    const pattern = /(--\[\[[\s\S]*?\]\]|--[^\n]*|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\b(?:and|break|do|else|elseif|end|false|for|function|if|in|local|nil|not|or|repeat|return|then|true|until|while|continue|export|type)\b|\b(?:game|workspace|script|Instance|Players|DataStoreService|ReplicatedStorage|ServerScriptService|ServerStorage|StarterGui|StarterPlayer|RunService|PathfindingService|TweenService|UserInputService|TeleportService|MarketplaceService|task|math|string|table|os|Vector3|CFrame|Color3|UDim2|Enum|warn|print|require|typeof)\b|\b\d+(?:\.\d+)?\b|[=<>~+*/%-]+)/g;
    let html = "";
    let last = 0;
    let match = pattern.exec(source);
    while (match) {
      html += escapeHtml(source.slice(last, match.index));
      const token = match[0];
      let cls = "tok-operator";
      if (token.startsWith("--")) cls = "tok-comment";
      else if (/^["']/.test(token)) cls = "tok-string";
      else if (/^\d/.test(token)) cls = "tok-number";
      else if (/^(and|break|do|else|elseif|end|false|for|function|if|in|local|nil|not|or|repeat|return|then|true|until|while|continue|export|type)$/.test(token)) cls = "tok-key";
      else cls = "tok-builtin";
      html += `<span class="${cls}">${escapeHtml(token)}</span>`;
      last = pattern.lastIndex;
      match = pattern.exec(source);
    }
    return html + escapeHtml(source.slice(last)) + "\n";
  }

  function setMode(mode) {
    if (!Engine.MODES[mode]) return;
    data.settings.mode = mode;
    document.querySelectorAll("[data-mode]").forEach((button) => {
      button.setAttribute("aria-pressed", String(button.dataset.mode === mode));
    });
    saveData();
  }
  function closeSidebar() {
    $("sidebar").classList.remove("open");
    $("mobileScrim").classList.remove("open");
  }
  function openSidebar() {
    $("sidebar").classList.add("open");
    $("mobileScrim").classList.add("open");
  }
  function setView(name) {
    if (!views.includes(name)) return;
    selectedView = name;
    views.forEach((view) => {
      const section = $(`${view}View`);
      if (section) section.classList.toggle("active", view === name);
    });
    document.querySelectorAll("[data-view]").forEach((button) => button.classList.toggle("active", button.dataset.view === name));
    $("pageTitle").textContent = viewNames[name];
    closeSidebar();
    if (name === "projects") renderProjects();
    if (name === "code") renderScripts();
    if (name === "review") renderReviews();
    if (name === "settings") renderSettings();
  }

  function createChat(project = currentProject()) {
    const chat = { id: makeId(), title: "Новый чат", createdAt: Date.now(), updatedAt: Date.now(), messages: [] };
    project.chats.unshift(chat);
    project.currentChatId = chat.id;
    saveData();
    renderSidebar();
    renderChat();
    setView("studio");
    $("chatInput").focus();
    return chat;
  }
  function renderSidebar() {
    const project = currentProject();
    const selector = $("projectSelector");
    selector.replaceChildren();
    data.projects.forEach((item) => {
      const option = document.createElement("option");
      option.value = item.id;
      option.textContent = item.name;
      option.selected = item.id === project.id;
      selector.appendChild(option);
    });
    $("activeProjectChip").textContent = project.name;
    const list = $("chatHistoryList");
    list.replaceChildren();
    if (!project.chats.length) {
      const empty = document.createElement("div");
      empty.className = "hint";
      empty.textContent = "Чатов пока нет";
      list.appendChild(empty);
    }
    project.chats.forEach((chat) => {
      const row = document.createElement("div");
      row.className = "chat-row";
      const button = document.createElement("button");
      button.type = "button";
      button.className = `chat-item${chat.id === project.currentChatId ? " active" : ""}`;
      button.dataset.chatId = chat.id;
      const title = document.createElement("span");
      title.textContent = chat.title || "Новый чат";
      button.appendChild(title);
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "chat-delete";
      remove.dataset.deleteChat = chat.id;
      remove.setAttribute("aria-label", "Удалить чат");
      remove.textContent = "×";
      row.append(button, remove);
      list.appendChild(row);
    });
  }

  function renderCodeCard(code) {
    const card = document.createElement("div");
    card.className = "code-card";
    const head = document.createElement("div");
    head.className = "code-card-head";
    const meta = document.createElement("div");
    const filename = document.createElement("strong");
    filename.textContent = code.name;
    const tag = document.createElement("span");
    tag.className = "code-tag";
    tag.textContent = code.type;
    meta.append(filename, document.createTextNode(" "), tag);
    const actions = document.createElement("div");
    actions.className = "code-actions";
    const copy = document.createElement("button");
    copy.type = "button";
    copy.className = "code-action";
    copy.textContent = "Копировать";
    copy.addEventListener("click", () => copyText(code.source));
    const save = document.createElement("button");
    save.type = "button";
    save.className = "code-action";
    save.textContent = "В Code";
    save.addEventListener("click", () => saveGeneratedScript(code));
    actions.append(copy, save);
    head.append(meta, actions);
    const pre = document.createElement("pre");
    pre.className = "code-block";
    pre.innerHTML = highlightLuau(code.source);
    const path = document.createElement("div");
    path.className = "path-line";
    path.textContent = `Explorer: ${code.path}`;
    card.append(head, pre, path);
    return card;
  }
  function renderChat() {
    const chat = currentChat();
    const list = $("messageList");
    list.replaceChildren();
    const messages = chat ? chat.messages : [];
    $("welcomePanel").classList.toggle("hidden", messages.length > 0);
    messages.forEach((message) => {
      const row = document.createElement("article");
      row.className = `message ${message.role}`;
      const body = document.createElement("div");
      body.className = "message-body";
      if (message.role === "assistant") {
        const avatar = document.createElement("div");
        avatar.className = "avatar";
        avatar.textContent = "R";
        const role = document.createElement("div");
        role.className = "message-role";
        role.textContent = `${Engine.modeInfo(data.settings.mode).label} · локальные правила`;
        body.appendChild(role);
        row.append(avatar, body);
      } else row.appendChild(body);
      const text = document.createElement("div");
      text.className = "message-text";
      text.textContent = message.content;
      body.appendChild(text);
      (message.codes || []).forEach((code) => body.appendChild(renderCodeCard(code)));
      if (message.summary) {
        const note = document.createElement("div");
        note.className = "reasoning-note";
        note.textContent = message.summary;
        body.appendChild(note);
      }
      const actions = document.createElement("div");
      actions.className = "message-actions";
      if (message.role === "assistant") {
        const speak = document.createElement("button");
        speak.type = "button";
        speak.className = "mini-btn";
        speak.textContent = "Озвучить";
        speak.addEventListener("click", () => speakText(message.content));
        actions.appendChild(speak);
      }
      if (message.plan) {
        const plan = document.createElement("button");
        plan.type = "button";
        plan.className = "mini-btn";
        plan.textContent = "Собрать скрипт по плану";
        plan.addEventListener("click", () => {
          const latest = [...(currentChat()?.messages || [])].reverse().find((item) => item.role === "user");
          sendPrompt(`Напиши Luau по плану для задачи: ${latest ? latest.content : currentProject().task}`);
        });
        actions.appendChild(plan);
      }
      if (message.openStore) {
        const open = document.createElement("button");
        open.type = "button";
        open.className = "mini-btn";
        open.textContent = "Открыть Creator Store";
        open.addEventListener("click", () => {
          if (message.storeQuery) $("storeInput").value = message.storeQuery;
          setView("store");
          if (message.storeQuery) searchStore(false);
        });
        actions.appendChild(open);
      }
      if (actions.childNodes.length) body.appendChild(actions);
      list.appendChild(row);
    });
    requestAnimationFrame(() => { $("chatScroll").scrollTop = $("chatScroll").scrollHeight; });
  }
  function addMessage(role, content, extras = {}) {
    const project = currentProject();
    let chat = currentChat(project);
    if (!chat) chat = createChat(project);
    const message = {
      id: makeId(),
      role,
      content: safeText(content, 16000),
      codes: extras.codes || [],
      plan: extras.plan === true,
      openStore: extras.openStore === true,
      storeQuery: safeText(extras.storeQuery, 60),
      summary: safeText(extras.summary, 800),
    };
    chat.messages.push(message);
    if (role === "user" && chat.messages.filter((item) => item.role === "user").length === 1) {
      chat.title = safeText(content.replace(/\s+/g, " ").trim(), 42) || "Новый чат";
    }
    chat.updatedAt = Date.now();
    saveData();
    renderChat();
    return message;
  }
  function appendDecision(line) {
    if (!line) return;
    const project = currentProject();
    const stamp = `${formatDate(Date.now())}: ${line}`;
    project.decisions = safeText(`${project.decisions ? `${project.decisions}\n` : ""}${stamp}`, 5000);
    if ($("projectDecisions")) $("projectDecisions").value = project.decisions;
  }

  function createProgress() {
    const card = document.createElement("div");
    card.className = "progress-card";
    ["Смотрю запрос и проект", "Сопоставляю с правилами Roblox", "Собираю ответ без внешней модели"].forEach((label, index) => {
      const row = document.createElement("div");
      row.className = "step";
      row.dataset.step = String(index);
      row.textContent = `○ ${label}`;
      card.appendChild(row);
    });
    $("messageList").appendChild(card);
    $("chatScroll").scrollTop = $("chatScroll").scrollHeight;
    return card;
  }
  async function animateProgress(card) {
    const rows = [...card.querySelectorAll(".step")];
    for (let index = 0; index < rows.length; index += 1) {
      rows.forEach((row, position) => {
        row.classList.toggle("done", position <= index);
        row.textContent = `${position <= index ? "✓" : "○"} ${row.textContent.slice(2)}`;
      });
      await new Promise((resolve) => window.setTimeout(resolve, 90));
    }
  }
  async function sendPrompt(raw) {
    const prompt = safeText(String(raw || "").trim(), 12000);
    if (!prompt || isBusy) return;
    if (!currentChat()) createChat();
    addMessage("user", prompt);
    $("chatInput").value = "";
    resizeComposer();
    isBusy = true;
    $("sendBtn").disabled = true;
    const progress = createProgress();
    try {
      await animateProgress(progress);
      progress.remove();
      const project = currentProject();
      const result = Engine.prepareResponse(prompt, data.settings.mode, project);
      if (result.plan) project.task = safeText(prompt, 5000);
      if (result.decision) appendDecision(result.decision);
      pendingFindings = result.findings || [];
      addMessage("assistant", result.content, result);
      saveData();
      if (data.settings.autoSpeak) speakText(result.content);
      if (result.findings && result.findings.some((item) => item.severity === "Высокий")) {
        toast("Есть замечания высокой важности.", "warn");
      }
    } catch (error) {
      progress.remove();
      addMessage("assistant", "Локальная обработка остановилась. Укоротите текст или экспортируйте проект.");
      console.error(error);
    } finally {
      isBusy = false;
      $("sendBtn").disabled = false;
    }
  }

  function updateEditorHighlight() {
    const editor = $("scriptEditor");
    const preview = $("scriptHighlight");
    preview.innerHTML = highlightLuau(editor.value || " ");
    preview.scrollTop = editor.scrollTop;
    preview.scrollLeft = editor.scrollLeft;
  }
  function renderVersions(script) {
    const list = $("versionList");
    list.replaceChildren();
    if (!script.versions.length) {
      const note = document.createElement("div");
      note.className = "hint";
      note.textContent = "Истории пока нет";
      list.appendChild(note);
      return;
    }
    script.versions.slice().reverse().slice(0, 6).forEach((version) => {
      const row = document.createElement("button");
      row.type = "button";
      row.className = "version-row";
      row.dataset.versionId = version.id;
      row.textContent = formatDate(version.createdAt);
      list.appendChild(row);
    });
  }
  function renderScripts() {
    const project = currentProject();
    const list = $("scriptList");
    list.replaceChildren();
    $("scriptCount").textContent = `${project.scripts.length} скриптов`;
    if (!project.scripts.length) {
      const empty = document.createElement("div");
      empty.className = "empty-state";
      empty.textContent = "Скриптов пока нет.";
      list.appendChild(empty);
    }
    project.scripts.forEach((script) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = `script-item${script.id === selectedScriptId ? " active" : ""}`;
      button.dataset.scriptId = script.id;
      const name = document.createElement("b");
      name.textContent = script.name;
      const meta = document.createElement("small");
      meta.textContent = `${script.type} · ${script.path}`;
      button.append(name, meta);
      list.appendChild(button);
    });
    const active = project.scripts.find((script) => script.id === selectedScriptId) || null;
    if (active) {
      $("editorTitle").textContent = active.name;
      $("editorSubtitle").textContent = `Обновлено ${formatDate(active.updatedAt)}`;
      $("scriptName").value = active.name;
      $("scriptType").value = active.type;
      $("scriptPath").value = active.path;
      $("scriptEditor").value = active.code;
      updateEditorHighlight();
      renderVersions(active);
    } else {
      selectedScriptId = null;
      $("editorTitle").textContent = "Выберите скрипт";
      $("editorSubtitle").textContent = "Код хранится в этом браузере";
      ["scriptName", "scriptPath", "scriptEditor"].forEach((id) => { $(id).value = ""; });
      $("scriptType").value = "Script";
      updateEditorHighlight();
      $("versionList").replaceChildren();
    }
    $("versionDiff").classList.add("hidden");
  }
  function saveCurrentScript() {
    const script = currentProject().scripts.find((item) => item.id === selectedScriptId);
    if (!script) { toast("Сначала выберите скрипт.", "warn"); return; }
    const source = safeText($("scriptEditor").value, 50000);
    if (script.code !== source) {
      script.versions.push({ id: makeId(), code: script.code, createdAt: script.updatedAt || Date.now() });
      script.versions = script.versions.slice(-20);
    }
    script.code = source;
    script.name = safeText($("scriptName").value.trim() || "NewScript", 80);
    script.type = scriptTypes.includes($("scriptType").value) ? $("scriptType").value : "Script";
    script.path = safeText($("scriptPath").value.trim() || "ServerScriptService", 180);
    script.updatedAt = Date.now();
    saveData();
    renderScripts();
    toast("Версия сохранена.", "success");
  }
  function saveGeneratedScript(code) {
    const script = {
      id: makeId(), name: code.name, type: code.type, path: code.path,
      code: code.source, versions: [], updatedAt: Date.now(),
    };
    currentProject().scripts.unshift(script);
    selectedScriptId = script.id;
    saveData();
    toast("Скрипт добавлен в RubAI Code.", "success");
    setView("code");
  }
  function renderFindings(target, findings) {
    target.replaceChildren();
    const wrapper = document.createElement("div");
    wrapper.className = "finding-list";
    findings.forEach((finding) => {
      const card = document.createElement("article");
      card.className = "finding";
      const head = document.createElement("div");
      head.className = "code-card-head";
      const title = document.createElement("strong");
      title.textContent = finding.title;
      const severity = document.createElement("span");
      severity.className = `severity ${finding.severity === "Средний" ? "medium" : finding.severity === "Низкий" ? "low" : ""}`;
      severity.textContent = finding.severity;
      head.append(title, severity);
      const description = document.createElement("p");
      description.textContent = finding.description;
      card.append(head, description);
      if (finding.fix) {
        const fix = document.createElement("p");
        fix.textContent = finding.fix;
        card.appendChild(fix);
      }
      if (finding.fixCode) {
        const pre = document.createElement("pre");
        pre.className = "code-block";
        pre.innerHTML = highlightLuau(finding.fixCode);
        const copy = document.createElement("button");
        copy.type = "button";
        copy.className = "mini-btn";
        copy.textContent = "Копировать пример";
        copy.addEventListener("click", () => copyText(finding.fixCode));
        card.append(pre, copy);
      }
      if (finding.id !== "no-known-rule") {
        const add = document.createElement("button");
        add.type = "button";
        add.className = "mini-btn";
        add.textContent = "В трекер";
        add.addEventListener("click", () => addFindingsToTracker([finding]));
        card.appendChild(add);
      }
      wrapper.appendChild(card);
    });
    target.appendChild(wrapper);
  }
  function addFindingsToTracker(findings) {
    const project = currentProject();
    const items = findings.filter((finding) => finding.id !== "no-known-rule");
    if (!items.length) { toast("Нет замечаний для трекера.", "info"); return; }
    items.forEach((finding) => {
      project.reviews.unshift({
        id: makeId(),
        text: `${finding.title}: ${finding.description}`,
        severity: finding.severity,
        status: "open",
        createdAt: Date.now(),
      });
    });
    saveData();
    renderReviews();
    toast("Замечания добавлены.", "success");
  }
  function renderReviews() {
    const project = currentProject();
    const filter = $("reviewFilter").value;
    const reviews = project.reviews.filter((item) => filter === "all" || item.status === filter);
    $("reviewCount").textContent = `${project.reviews.length} замечаний`;
    const list = $("reviewList");
    list.replaceChildren();
    if (!reviews.length) {
      const empty = document.createElement("div");
      empty.className = "empty-state";
      empty.textContent = "Замечаний нет.";
      list.appendChild(empty);
      return;
    }
    reviews.forEach((review) => {
      const row = document.createElement("article");
      row.className = "review-row";
      const info = document.createElement("div");
      const title = document.createElement("strong");
      title.textContent = review.text;
      const meta = document.createElement("div");
      meta.className = "hint";
      meta.textContent = `${review.severity} · ${formatDate(review.createdAt)}`;
      info.append(title, meta);
      const actions = document.createElement("div");
      actions.className = "btn-group";
      const state = document.createElement("span");
      state.className = `badge ${review.status}`;
      state.textContent = review.status === "fixed" ? "Исправлено" : review.status === "wont" ? "Не исправлять" : "Открыто";
      const cycle = document.createElement("button");
      cycle.type = "button";
      cycle.className = "btn";
      cycle.textContent = "Статус";
      cycle.addEventListener("click", () => {
        review.status = review.status === "open" ? "fixed" : review.status === "fixed" ? "wont" : "open";
        saveData();
        renderReviews();
      });
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "btn danger";
      remove.textContent = "Удалить";
      remove.addEventListener("click", async () => {
        if (!await askConfirm("Удалить замечание?", "Запись исчезнет из этого браузера.")) return;
        project.reviews = project.reviews.filter((item) => item.id !== review.id);
        saveData();
        renderReviews();
      });
      actions.append(state, cycle, remove);
      row.append(info, actions);
      list.appendChild(row);
    });
  }
  function renderProjects() {
    const grid = $("projectsList");
    grid.replaceChildren();
    data.projects.forEach((project) => {
      const card = document.createElement("article");
      card.className = `project-card${project.id === data.currentProjectId ? " active" : ""}`;
      const title = document.createElement("h3");
      title.textContent = project.name;
      const desc = document.createElement("p");
      desc.textContent = `${project.chats.length} чатов · ${project.scripts.length} скриптов · ${project.reviews.length} замечаний`;
      const actions = document.createElement("div");
      actions.className = "btn-group";
      const open = document.createElement("button");
      open.type = "button";
      open.className = project.id === data.currentProjectId ? "btn primary" : "btn";
      open.textContent = project.id === data.currentProjectId ? "Активный" : "Открыть";
      open.addEventListener("click", () => updateProject(project.id));
      const rename = document.createElement("button");
      rename.type = "button";
      rename.className = "btn";
      rename.textContent = "Переименовать";
      rename.addEventListener("click", () => renameProject(project.id));
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "btn danger";
      remove.textContent = "Удалить";
      remove.addEventListener("click", () => deleteProject(project.id));
      actions.append(open, rename, remove);
      card.append(title, desc, actions);
      grid.appendChild(card);
    });
    const project = currentProject();
    $("projectNotes").value = project.notes || "";
    $("projectRequirements").value = project.requirements || "";
    $("projectDecisions").value = project.decisions || "";
  }
  function renderSettings() {
    $("modelEndpoint").value = data.settings.apiEndpoint || "";
    $("autoSpeak").checked = data.settings.autoSpeak === true;
    $("voiceRate").value = String(data.settings.voiceRate || 1);
    setMode(data.settings.mode);
  }
  function updateProject(projectId) {
    if (!data.projects.some((project) => project.id === projectId)) return;
    data.currentProjectId = projectId;
    selectedScriptId = null;
    saveData();
    renderSidebar();
    renderChat();
    if (selectedView === "projects") renderProjects();
    if (selectedView === "code") renderScripts();
    if (selectedView === "review") renderReviews();
  }
  async function renameProject(id) {
    const project = data.projects.find((item) => item.id === id);
    if (!project) return;
    const name = await askText("Переименовать", "Новое имя проекта.", project.name);
    if (!name) return;
    project.name = safeText(name, 80);
    saveData();
    renderSidebar();
    renderProjects();
  }
  async function deleteProject(id) {
    if (data.projects.length < 2) { toast("Последний проект удалять нельзя.", "warn"); return; }
    const project = data.projects.find((item) => item.id === id);
    if (!project || !await askConfirm("Удалить проект?", `«${project.name}» и его чаты будут стёрты из браузера.`)) return;
    data.projects = data.projects.filter((item) => item.id !== id);
    if (data.currentProjectId === id) data.currentProjectId = data.projects[0].id;
    selectedScriptId = null;
    saveData();
    renderSidebar();
    renderProjects();
    renderChat();
  }
  function resizeComposer() {
    const input = $("chatInput");
    input.style.height = "auto";
    input.style.height = `${Math.min(input.scrollHeight, 180)}px`;
  }

  function safeHttpUrl(value) {
    const text = String(value || "").trim();
    if (!text) return "/api/ai";
    if (text.startsWith("/")) return text;
    try {
      const url = new URL(text);
      if (url.protocol === "https:" || url.protocol === "http:") return url.toString();
    } catch { /* ignore */ }
    return "";
  }
  async function checkBackend() {
    const endpoint = safeHttpUrl($("modelEndpoint").value);
    $("backendStatus").textContent = "Проверяю…";
    if (!endpoint) {
      $("backendStatus").textContent = "Нужен адрес /api/ai или http(s). Чат туда не отправляется.";
      return;
    }
    try {
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ping: true }),
      });
      const payload = await response.json().catch(() => ({}));
      $("backendStatus").textContent = payload.message || `Ответ ${response.status}. Нейросеть ${payload.connected ? "подключена" : "не подключена"}.`;
    } catch {
      $("backendStatus").textContent = "Backend не ответил. Локальные режимы при этом работают. Диалог не отправлялся.";
    }
  }

  function setSpeaking(state) {
    speaking = state;
    $("stopSpeakBtn").hidden = !state;
  }
  function speakText(text) {
    if (!window.speechSynthesis) {
      toast("Этот браузер не умеет озвучивать.", "warn");
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(String(text || "").replace(/\s+/g, " ").slice(0, 700));
    utterance.lang = "ru-RU";
    utterance.rate = Number(data.settings.voiceRate) || 1;
    const voice = speechSynthesis.getVoices().find((item) => /^ru/i.test(item.lang || ""));
    if (voice) utterance.voice = voice;
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => {
      setSpeaking(false);
      toast("Не удалось озвучить ответ.", "error");
    };
    setSpeaking(true);
    speechSynthesis.speak(utterance);
  }
  function stopSpeaking() {
    if (window.speechSynthesis) speechSynthesis.cancel();
    setSpeaking(false);
  }
  function voiceError(code) {
    const messages = {
      "not-allowed": "Доступ к микрофону запрещён. Разрешите его в настройках браузера.",
      "service-not-allowed": "Браузер запретил распознавание речи.",
      "audio-capture": "Микрофон не найден.",
      "no-speech": "Речь не услышана. Попробуйте ещё раз.",
      network: "Сервис распознавания браузера недоступен. Текст можно ввести вручную.",
      "language-not-supported": "Русский язык распознавания в этом браузере недоступен.",
    };
    if (code === "aborted") return;
    toast(messages[code] || "Микрофон не сработал. Можно продолжить текстом.", "warn");
  }
  function toggleMic() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      toast("Голосовой ввод не поддерживается. Подойдут Chrome или Edge, лучше через server.js.", "warn");
      return;
    }
    if (!window.isSecureContext) {
      toast("Микрофон обычно доступен на localhost через server.js, а не при открытии файла с диска.", "warn");
    }
    if (listening && recognition) {
      recognition.stop();
      return;
    }
    recognition = new SpeechRecognition();
    recognition.lang = "ru-RU";
    recognition.interimResults = true;
    recognition.continuous = false;
    listening = true;
    $("micBtn").setAttribute("aria-pressed", "true");
    $("voiceCaption").hidden = false;
    $("voiceCaption").textContent = "Слушаю…";
    recognition.onresult = (event) => {
      let finalText = "";
      let interim = "";
      for (let index = event.resultIndex; index < event.results.length; index += 1) {
        const piece = event.results[index][0].transcript;
        if (event.results[index].isFinal) finalText += piece;
        else interim += piece;
      }
      if (finalText) {
        const input = $("chatInput");
        const prefix = input.value && !/\s$/.test(input.value) ? `${input.value} ` : input.value;
        input.value = safeText(`${prefix}${finalText}`, 12000);
        resizeComposer();
      }
      $("voiceCaption").textContent = interim ? `Слушаю: ${interim}` : "Слушаю…";
    };
    recognition.onerror = (event) => voiceError(event.error);
    recognition.onend = () => {
      listening = false;
      $("micBtn").setAttribute("aria-pressed", "false");
      $("voiceCaption").hidden = true;
    };
    try {
      recognition.start();
    } catch {
      listening = false;
      $("micBtn").setAttribute("aria-pressed", "false");
      toast("Не удалось включить микрофон.", "error");
    }
  }

  function safePreview(url) {
    try {
      const parsed = new URL(url);
      const host = parsed.hostname.toLowerCase();
      if (parsed.protocol !== "https:") return "";
      if (!(host.endsWith(".rbxcdn.com") || host.endsWith(".roblox.com") || host === "roblox.com")) return "";
      return parsed.toString();
    } catch {
      return "";
    }
  }
  function renderStore() {
    const grid = $("storeResults");
    grid.replaceChildren();
    $("storeMoreBtn").hidden = !storeCursor;
    storeResults.forEach((asset) => {
      if (!Number.isInteger(asset.id) || asset.id <= 0 || !asset.name) return;
      const card = document.createElement("article");
      card.className = "asset-card";
      const preview = safePreview(asset.previewUrl);
      if (preview) {
        const image = document.createElement("img");
        image.alt = "";
        image.referrerPolicy = "no-referrer";
        image.src = preview;
        image.addEventListener("error", () => {
          const fallback = document.createElement("div");
          fallback.className = "asset-fallback";
          fallback.textContent = "Превью недоступно";
          image.replaceWith(fallback);
        });
        card.appendChild(image);
      } else {
        const fallback = document.createElement("div");
        fallback.className = "asset-fallback";
        fallback.textContent = "Превью нет в ответе";
        card.appendChild(fallback);
      }
      const body = document.createElement("div");
      body.className = "asset-body";
      const title = document.createElement("h3");
      title.textContent = asset.name;
      const meta = document.createElement("div");
      meta.className = "hint";
      meta.textContent = [asset.creatorName, asset.assetType, asset.isFree ? "отмечен бесплатным" : "цена не указана как бесплатная", asset.hasScripts ? "есть скрипты" : ""].filter(Boolean).join(" · ");
      const idLine = document.createElement("div");
      idLine.className = "asset-id";
      idLine.textContent = String(asset.id);
      const rbx = document.createElement("div");
      rbx.className = "asset-id";
      rbx.textContent = `rbxassetid://${asset.id}`;
      const actions = document.createElement("div");
      actions.className = "btn-group";
      const copyId = document.createElement("button");
      copyId.type = "button";
      copyId.className = "btn";
      copyId.textContent = "Копировать ID";
      copyId.addEventListener("click", () => copyText(String(asset.id)));
      const copyRbx = document.createElement("button");
      copyRbx.type = "button";
      copyRbx.className = "btn";
      copyRbx.textContent = "rbxassetid";
      copyRbx.addEventListener("click", () => copyText(`rbxassetid://${asset.id}`));
      const link = document.createElement("a");
      link.className = "btn";
      link.textContent = "Страница";
      link.href = `https://create.roblox.com/store/asset/${asset.id}`;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      actions.append(copyId, copyRbx, link);
      body.append(title, meta, idLine, rbx, actions);
      card.appendChild(body);
      grid.appendChild(card);
    });
  }
  async function searchStore(append) {
    const query = $("storeInput").value.trim();
    if (!query) { toast("Введите название.", "warn"); return; }
    $("storeStatus").textContent = "Запрашиваю Roblox Creator Store…";
    $("storeSearchBtn").disabled = true;
    try {
      const params = new URLSearchParams({ q: query, category: storeCategory });
      if (append && storeCursor) params.set("cursor", storeCursor);
      const response = await fetch(`/api/roblox/search?${params}`);
      const payload = await response.json().catch(() => null);
      if (!response.ok || !payload || payload.ok === false || !Array.isArray(payload.results)) {
        throw new Error((payload && payload.message) || "Поиск не вернул данные.");
      }
      const incoming = payload.results.filter((asset) => Number.isInteger(asset.id) && asset.name);
      if (append) {
        const seen = new Set(storeResults.map((asset) => asset.id));
        incoming.forEach((asset) => { if (!seen.has(asset.id)) storeResults.push(asset); });
      } else storeResults = incoming;
      storeCursor = payload.nextCursor || "";
      storeQuery = query;
      renderStore();
      $("storeStatus").textContent = storeResults.length
        ? `Показано ${storeResults.length}. Источник: официальный Toolbox Service, без выдуманных ID.`
        : "Roblox не вернул ассетов с названием. Список пуст специально.";
    } catch (error) {
      if (!append) {
        storeResults = [];
        storeCursor = "";
        renderStore();
      }
      const offline = error instanceof TypeError;
      $("storeStatus").textContent = offline
        ? "Поиск доступен через server.js. С диска браузер блокирует Roblox, поэтому ID не подставляются."
        : error.message;
    } finally {
      $("storeSearchBtn").disabled = false;
    }
  }

  function exportCurrentProject() {
    const project = currentProject();
    downloadFile(`${project.name}_RubAI_4.json`, JSON.stringify({ format: "RubAIProject", version: 4, project }, null, 2), "application/json");
    toast("JSON проекта сохранён.", "success");
  }
  async function showHandoff() {
    const text = Engine.makeHandoff(currentProject(), currentChat());
    const result = await openModal({
      title: "Передача",
      description: "RubAI никуда это сам не отправляет.",
      input: true,
      multiline: true,
      inputValue: text,
      buttons: [{ label: "Закрыть", value: null }, { label: "Копировать", value: "copy", primary: true }],
    });
    if (result === "copy") await copyText(text);
  }

  document.querySelectorAll("[data-view]").forEach((button) => button.addEventListener("click", () => setView(button.dataset.view)));
  document.querySelectorAll("[data-mode]").forEach((button) => button.addEventListener("click", () => {
    setMode(button.dataset.mode);
    toast(`${Engine.modeInfo(button.dataset.mode).label} включён. Оплаты нет.`, "success");
  }));
  $("newChatBtn").addEventListener("click", () => createChat());
  $("menuBtn").addEventListener("click", openSidebar);
  $("tabMenuBtn").addEventListener("click", openSidebar);
  $("mobileScrim").addEventListener("click", closeSidebar);
  $("projectSelector").addEventListener("change", (event) => updateProject(event.target.value));
  $("chatForm").addEventListener("submit", (event) => {
    event.preventDefault();
    sendPrompt($("chatInput").value);
  });
  $("chatInput").addEventListener("input", resizeComposer);
  $("chatInput").addEventListener("keydown", (event) => {
    const mobile = window.matchMedia("(max-width: 900px)").matches;
    if (event.key === "Enter" && !event.shiftKey && !mobile && !event.isComposing) {
      event.preventDefault();
      $("chatForm").requestSubmit();
    }
  });
  document.querySelectorAll("[data-prompt]").forEach((button) => button.addEventListener("click", () => {
    $("chatInput").value = button.dataset.prompt;
    resizeComposer();
    $("chatInput").focus();
  }));
  $("micBtn").addEventListener("click", toggleMic);
  $("stopSpeakBtn").addEventListener("click", stopSpeaking);
  $("exportProjectBtn").addEventListener("click", exportCurrentProject);
  $("exportSidebarBtn").addEventListener("click", exportCurrentProject);
  $("exportProjectJsonBtn").addEventListener("click", exportCurrentProject);
  $("handoffBtn").addEventListener("click", showHandoff);
  $("handoffSidebarBtn").addEventListener("click", showHandoff);
  $("workflowHandoffBtn").addEventListener("click", showHandoff);
  $("chatHistoryList").addEventListener("click", async (event) => {
    const remove = event.target.closest("[data-delete-chat]");
    if (remove) {
      const project = currentProject();
      const chat = project.chats.find((item) => item.id === remove.dataset.deleteChat);
      if (!chat || !await askConfirm("Удалить чат?", "Сообщения этого чата исчезнут из браузера.")) return;
      project.chats = project.chats.filter((item) => item.id !== chat.id);
      if (project.currentChatId === chat.id) project.currentChatId = project.chats[0] ? project.chats[0].id : null;
      saveData();
      renderSidebar();
      renderChat();
      return;
    }
    const button = event.target.closest("[data-chat-id]");
    if (!button) return;
    currentProject().currentChatId = button.dataset.chatId;
    saveData();
    renderChat();
    renderSidebar();
    closeSidebar();
    setView("studio");
  });

  $("storeForm").addEventListener("submit", (event) => {
    event.preventDefault();
    storeCursor = "";
    searchStore(false);
  });
  $("storeCategory").addEventListener("click", (event) => {
    const chip = event.target.closest("[data-category]");
    if (!chip) return;
    storeCategory = chip.dataset.category;
    $("storeCategory").querySelectorAll(".chip").forEach((item) => item.classList.toggle("active", item === chip));
  });
  $("storeMoreBtn").addEventListener("click", () => searchStore(true));

  $("newScriptBtn").addEventListener("click", () => {
    const script = {
      id: makeId(),
      name: "NewScript",
      type: "Script",
      path: "ServerScriptService/NewScript",
      code: "-- ServerScriptService/NewScript\nlocal Players = game:GetService(\"Players\")\n",
      versions: [],
      updatedAt: Date.now(),
    };
    currentProject().scripts.unshift(script);
    selectedScriptId = script.id;
    saveData();
    renderScripts();
  });
  $("saveScriptBtn").addEventListener("click", saveCurrentScript);
  $("copyScriptBtn").addEventListener("click", () => copyText($("scriptEditor").value));
  $("compareVersionsBtn").addEventListener("click", () => {
    const script = currentProject().scripts.find((item) => item.id === selectedScriptId);
    if (!script || !script.versions.length) { toast("Нет предыдущей версии.", "info"); return; }
    const previous = script.versions[script.versions.length - 1].code.split("\n");
    const current = $("scriptEditor").value.split("\n");
    const lines = [];
    const max = Math.max(previous.length, current.length);
    for (let index = 0; index < max; index += 1) {
      if (previous[index] === current[index]) lines.push(`  ${previous[index] || ""}`);
      else {
        if (previous[index] !== undefined) lines.push(`- ${previous[index]}`);
        if (current[index] !== undefined) lines.push(`+ ${current[index]}`);
      }
    }
    $("versionDiff").textContent = lines.join("\n");
    $("versionDiff").classList.remove("hidden");
  });
  $("deleteScriptBtn").addEventListener("click", async () => {
    const project = currentProject();
    const script = project.scripts.find((item) => item.id === selectedScriptId);
    if (!script || !await askConfirm("Удалить скрипт?", `«${script.name}» будет удалён из проекта.`)) return;
    project.scripts = project.scripts.filter((item) => item.id !== script.id);
    selectedScriptId = null;
    saveData();
    renderScripts();
  });
  $("scriptList").addEventListener("click", (event) => {
    const item = event.target.closest("[data-script-id]");
    if (!item) return;
    selectedScriptId = item.dataset.scriptId;
    renderScripts();
  });
  $("scriptEditor").addEventListener("input", updateEditorHighlight);
  $("scriptEditor").addEventListener("scroll", updateEditorHighlight);
  $("versionList").addEventListener("click", (event) => {
    const row = event.target.closest("[data-version-id]");
    if (!row) return;
    const script = currentProject().scripts.find((item) => item.id === selectedScriptId);
    const version = script && script.versions.find((item) => item.id === row.dataset.versionId);
    if (!version) return;
    $("scriptEditor").value = version.code;
    updateEditorHighlight();
  });
  document.querySelectorAll("[data-code-tab]").forEach((button) => button.addEventListener("click", () => {
    const audit = button.dataset.codeTab === "audit";
    document.querySelectorAll("[data-code-tab]").forEach((tab) => tab.classList.toggle("active", tab === button));
    $("scriptsTab").classList.toggle("hidden", audit);
    $("auditTab").classList.toggle("hidden", !audit);
  }));
  $("analyzeCodeBtn").addEventListener("click", () => {
    const source = $("reviewCodeInput").value.trim();
    if (!source) { toast("Вставьте код.", "warn"); return; }
    const findings = Engine.analyzeCode(source);
    pendingFindings = findings;
    renderFindings($("analysisResults"), findings);
  });
  $("loadSelectedScriptBtn").addEventListener("click", () => {
    const script = currentProject().scripts.find((item) => item.id === selectedScriptId);
    if (!script) { toast("Выберите скрипт во вкладке «Скрипты».", "info"); return; }
    $("reviewCodeInput").value = script.code;
    toast("Скрипт загружен в проверку.", "success");
  });
  $("saveFindingsBtn").addEventListener("click", () => addFindingsToTracker(pendingFindings));
  $("addReviewBtn").addEventListener("click", () => {
    const text = $("newReviewTitle").value.trim();
    if (!text) { toast("Опишите замечание.", "warn"); return; }
    currentProject().reviews.unshift({
      id: makeId(), text: safeText(text, 500), severity: $("newReviewSeverity").value, status: "open", createdAt: Date.now(),
    });
    $("newReviewTitle").value = "";
    saveData();
    renderReviews();
  });
  $("reviewFilter").addEventListener("change", renderReviews);
  $("createProjectBtn").addEventListener("click", async () => {
    const name = await askText("Новый проект", "Короткое название.", `Игра ${data.projects.length + 1}`);
    if (!name) return;
    const project = normalizeProject({ id: makeId(), name, createdAt: Date.now() });
    data.projects.unshift(project);
    data.currentProjectId = project.id;
    selectedScriptId = null;
    saveData();
    renderSidebar();
    renderChat();
    renderProjects();
  });
  $("saveContextBtn").addEventListener("click", () => {
    const project = currentProject();
    project.notes = safeText($("projectNotes").value, 5000);
    project.requirements = safeText($("projectRequirements").value, 5000);
    project.decisions = safeText($("projectDecisions").value, 5000);
    saveData();
    toast("Контекст сохранён и будет учитываться в ответах.", "success");
  });
  $("importProjectJsonBtn").addEventListener("click", () => $("importFileInput").click());
  $("importFileInput").addEventListener("change", async (event) => {
    const file = event.target.files && event.target.files[0];
    event.target.value = "";
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) { toast("Файл больше 3 МБ.", "warn"); return; }
    try {
      const parsed = JSON.parse(await file.text());
      const raw = parsed.project || parsed;
      if (!raw || typeof raw !== "object" || !raw.name) throw new Error("format");
      const imported = normalizeProject({ ...raw, id: makeId(), name: `${safeText(raw.name, 70)} (импорт)` });
      data.projects.unshift(imported);
      data.currentProjectId = imported.id;
      saveData();
      renderSidebar();
      renderChat();
      renderProjects();
      toast("Проект импортирован.", "success");
    } catch {
      toast("Этот JSON не похож на проект RubAI.", "error");
    }
  });
  $("exportSpecBtn").addEventListener("click", () => {
    const project = currentProject();
    if (!project.task) {
      const latest = currentChat() && [...currentChat().messages].reverse().find((message) => message.role === "user");
      project.task = latest ? latest.content : project.requirements || project.name;
    }
    project.spec = Engine.buildSpec(project);
    saveData();
    downloadFile(`${project.name}_TZ.md`, project.spec, "text/markdown;charset=utf-8");
    toast("ТЗ собрано из контекста проекта.", "success");
  });
  $("saveSettingsBtn").addEventListener("click", () => {
    data.settings.apiEndpoint = safeText($("modelEndpoint").value.trim(), 500);
    data.settings.autoSpeak = $("autoSpeak").checked;
    data.settings.voiceRate = Number($("voiceRate").value) || 1;
    saveData();
    toast("Настройки сохранены. Запросы к модели не включены.", "success");
  });
  $("autoSpeak").addEventListener("change", () => {
    data.settings.autoSpeak = $("autoSpeak").checked;
    saveData();
  });
  $("voiceRate").addEventListener("change", () => {
    data.settings.voiceRate = Number($("voiceRate").value) || 1;
    saveData();
  });
  $("checkBackendBtn").addEventListener("click", checkBackend);
  $("downloadAllDataBtn").addEventListener("click", () => {
    downloadFile("RubAI_4_All_Data.json", JSON.stringify(data, null, 2), "application/json");
    toast("Все локальные данные выгружены.", "success");
  });
  $("clearAllDataBtn").addEventListener("click", async () => {
    if (!await askConfirm("Сбросить данные?", "Проекты, чаты и скрипты этого браузера будут удалены.")) return;
    [STORE_KEY, PREVIOUS_KEY, LEGACY_PROJECTS, LEGACY_CURRENT, LEGACY_SETTINGS].forEach(storageRemove);
    data = { version: 4, projects: [defaultProject()], currentProjectId: "", settings: normalizeSettings({}) };
    data.currentProjectId = data.projects[0].id;
    selectedScriptId = null;
    saveData();
    renderSidebar();
    renderChat();
    renderProjects();
    renderScripts();
    renderReviews();
    renderSettings();
    toast("Данные сброшены.", "success");
  });
  $("modalBack").addEventListener("click", (event) => { if (event.target === $("modalBack")) closeModal(null); });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      if ($("modalBack").classList.contains("open")) closeModal(null);
      closeSidebar();
      stopSpeaking();
    }
  });
  if (window.speechSynthesis) {
    speechSynthesis.addEventListener("voiceschanged", () => speechSynthesis.getVoices());
  }

  setMode(data.settings.mode);
  renderSidebar();
  renderChat();
  renderProjects();
  renderScripts();
  renderReviews();
  renderSettings();
  saveData();
})();
