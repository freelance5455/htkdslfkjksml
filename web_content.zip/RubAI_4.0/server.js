/* RubAI 4.0 — local static server and public Roblox Creator Store proxy.
   No Roblox passwords, cookies, .ROBLOSECURITY or API keys are read or sent. */
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)));
const HOST = "0.0.0.0";
const PORT = Number(process.env.PORT || 8080);

const CATEGORIES = {
  model: { id: "10", label: "Model" },
  decal: { id: "13", label: "Decal" },
  audio: { id: "3", label: "Audio" },
  mesh: { id: "40", label: "Mesh" },
  plugin: { id: "38", label: "Plugin" },
};

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".txt": "text/plain; charset=utf-8",
  ".md": "text/markdown; charset=utf-8",
  ".ico": "image/x-icon",
};

const hits = new Map();

function rateLimit(ip) {
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter((stamp) => now - stamp < 60_000);
  if (recent.length >= 30) {
    hits.set(ip, recent);
    return false;
  }
  recent.push(now);
  hits.set(ip, recent);
  return true;
}

function send(res, status, body, headers = {}) {
  res.writeHead(status, {
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
    ...headers,
  });
  res.end(body);
}

function sendJson(res, status, payload) {
  send(res, status, JSON.stringify(payload), { "Content-Type": "application/json; charset=utf-8" });
}

function safePath(urlPath) {
  let decoded;
  try {
    decoded = decodeURIComponent(urlPath.split("?")[0]);
  } catch {
    return null;
  }
  const rel = decoded === "/" ? "index.html" : decoded.replace(/^\/+/, "");
  if (!rel || rel.includes("\0")) return null;
  const full = path.resolve(ROOT, rel);
  const relative = path.relative(ROOT, full);
  if (!relative || relative.startsWith("..") || path.isAbsolute(relative)) return null;
  return full;
}

async function fetchJson(url) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12_000);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        Accept: "application/json",
        "User-Agent": "RubAI/4.0 (public Creator Store search; no account token)",
      },
    });
    const text = await response.text();
    let json = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch {
      json = null;
    }
    return { ok: response.ok, status: response.status, json };
  } finally {
    clearTimeout(timer);
  }
}

function chunk(list, size) {
  const groups = [];
  for (let index = 0; index < list.length; index += size) groups.push(list.slice(index, index + size));
  return groups;
}

function safePreview(url) {
  if (typeof url !== "string" || !url) return "";
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== "https:") return "";
    const host = parsed.hostname.toLowerCase();
    if (!(host === "roblox.com" || host.endsWith(".roblox.com") || host.endsWith(".rbxcdn.com"))) return "";
    return parsed.toString();
  } catch {
    return "";
  }
}

async function searchCreatorStore(keyword, categoryKey, cursor) {
  const category = CATEGORIES[categoryKey] || CATEGORIES.model;
  const params = new URLSearchParams({ keyword, limit: "30" });
  if (cursor) params.set("cursor", cursor);
  const searchUrl = `https://apis.roblox.com/toolbox-service/v1/marketplace/${category.id}?${params}`;
  const search = await fetchJson(searchUrl);
  if (!search.ok || !search.json || !Array.isArray(search.json.data)) {
    const message = search.json?.errors?.[0]?.message || `Roblox ответил статусом ${search.status || "нет соединения"}`;
    const error = new Error(message);
    error.statusCode = 502;
    throw error;
  }

  const ids = [];
  for (const item of search.json.data) {
    const id = Number(item && item.id);
    if (Number.isInteger(id) && id > 0 && !ids.includes(id)) ids.push(id);
  }

  const detailsById = new Map();
  for (const group of chunk(ids, 30)) {
    const details = await fetchJson(
      `https://apis.roblox.com/toolbox-service/v1/items/details?assetIds=${group.join(",")}`,
    );
    if (details.ok && Array.isArray(details.json?.data)) {
      for (const entry of details.json.data) {
        const id = Number(entry?.asset?.id);
        if (Number.isInteger(id) && id > 0) detailsById.set(id, entry);
      }
    }
  }

  const thumbs = new Map();
  for (const group of chunk(ids, 50)) {
    const thumb = await fetchJson(
      `https://thumbnails.roblox.com/v1/assets?assetIds=${group.join(",")}&size=150x150&format=Png&isCircular=false`,
    );
    if (thumb.ok && Array.isArray(thumb.json?.data)) {
      for (const entry of thumb.json.data) {
        const id = Number(entry.targetId);
        if (entry.state === "Completed" && Number.isInteger(id)) {
          const preview = safePreview(entry.imageUrl);
          if (preview) thumbs.set(id, preview);
        }
      }
    }
  }

  const results = [];
  for (const id of ids) {
    const entry = detailsById.get(id);
    const name = typeof entry?.asset?.name === "string" ? entry.asset.name.trim() : "";
    if (!name) continue;
    results.push({
      id,
      name,
      description: typeof entry.asset.description === "string" ? entry.asset.description.slice(0, 280) : "",
      assetTypeId: Number(entry.asset.typeId) || Number(category.id),
      assetType: category.label,
      creatorName: typeof entry.creator?.name === "string" ? entry.creator.name : "",
      isFree: entry.fiatProduct?.isFree === true,
      hasScripts: entry.asset.hasScripts === true,
      upVotes: Number(entry.voting?.upVotes) || 0,
      previewUrl: thumbs.get(id) || "",
      pageUrl: `https://create.roblox.com/store/asset/${id}`,
      libraryUrl: `https://www.roblox.com/library/${id}`,
      rbxassetid: `rbxassetid://${id}`,
    });
  }

  return {
    ok: true,
    query: keyword,
    category: category.label,
    source: "https://apis.roblox.com/toolbox-service/v1/marketplace",
    detailsSource: "https://apis.roblox.com/toolbox-service/v1/items/details",
    nextCursor: typeof search.json.nextPageCursor === "string" ? search.json.nextPageCursor : "",
    totalHint: Number(search.json.totalResults) || results.length,
    results,
  };
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > 32_000) {
        reject(new Error("too-large"));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url || "/", `http://${req.headers.host || "localhost"}`);
  const ip = String(req.socket.remoteAddress || "local");

  if (req.method === "GET" && url.pathname === "/api/health") {
    sendJson(res, 200, { ok: true, name: "RubAI 4.0", ai: false });
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/ai") {
    await readBody(req).catch(() => "");
    sendJson(res, 501, {
      ok: false,
      connected: false,
      message:
        "Нейросеть не подключена. RubAI не хранит API-ключи и не отправляет диалог во внешнюю модель. Локальные режимы работают на правилах и шаблонах. Архитектура backend описана в docs/BACKEND_AI.md.",
    });
    return;
  }

  if (req.method === "GET" && url.pathname === "/api/roblox/search") {
    if (!rateLimit(ip)) {
      sendJson(res, 429, { ok: false, message: "Слишком много запросов. Подождите минуту и повторите поиск." });
      return;
    }
    const keyword = String(url.searchParams.get("q") || "").replace(/\s+/g, " ").trim();
    if (!keyword || keyword.length > 60) {
      sendJson(res, 400, { ok: false, message: "Введите название от 1 до 60 символов." });
      return;
    }
    const category = String(url.searchParams.get("category") || "model");
    if (!CATEGORIES[category]) {
      sendJson(res, 400, { ok: false, message: "Неизвестная категория Creator Store." });
      return;
    }
    const cursor = String(url.searchParams.get("cursor") || "");
    if (cursor && !/^[A-Za-z0-9_=+/-]{8,200}$/.test(cursor)) {
      sendJson(res, 400, { ok: false, message: "Некорректная страница результатов." });
      return;
    }
    try {
      const payload = await searchCreatorStore(keyword, category, cursor);
      sendJson(res, 200, payload);
    } catch (error) {
      sendJson(res, error.statusCode || 502, {
        ok: false,
        message: error.name === "AbortError" ? "Roblox не ответил вовремя." : error.message || "Ошибка поиска Roblox.",
      });
    }
    return;
  }

  if (req.method !== "GET" && req.method !== "HEAD") {
    send(res, 405, "Method Not Allowed", { Allow: "GET, HEAD, POST" });
    return;
  }

  const filePath = safePath(url.pathname);
  if (!filePath) {
    send(res, 400, "Bad path");
    return;
  }
  fs.stat(filePath, (error, stat) => {
    if (error || !stat.isFile()) {
      send(res, 404, "Not found");
      return;
    }
    const type = MIME[path.extname(filePath).toLowerCase()] || "application/octet-stream";
    res.writeHead(200, { "Content-Type": type, "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" });
    if (req.method === "HEAD") {
      res.end();
      return;
    }
    fs.createReadStream(filePath).pipe(res);
  });
});

server.listen(PORT, HOST, () => {
  console.log(`RubAI 4.0 http://${HOST}:${PORT}`);
});
