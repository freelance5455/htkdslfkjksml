# Nexus AI — projeto inicial completo

Assistente pessoal em português, com interface PWA, modo local, tarefas, notas/memória local, exportação de dados e backend opcional para conversar com um modelo de IA.

## O que funciona sem pagar

- Interface responsiva para Android e computador.
- Modo local básico sem API.
- Lista de tarefas: adicionar, concluir e excluir.
- Notas locais controladas pelo usuário.
- Confirmação antes de criar uma tarefa ou salvar uma nota sugerida no chat.
- Exportação dos dados em JSON e opção de apagar os dados locais.
- PWA instalável e cache básico para abrir a interface offline depois da primeira visita.
- Backend opcional que mantém a chave de API no servidor.

## Limites importantes

A versão local não é um modelo de linguagem e não aprende como uma pessoa. Ela usa respostas simples para demonstrar a estrutura. Para conversa inteligente, conecte o backend a um provedor de modelo. Cotas gratuitas, nomes de modelos e condições mudam; confira a disponibilidade atual do provedor. Hospedagem gratuita também pode ter limites, suspender serviços ou exigir conta.

Este projeto não executa ações externas autônomas. Não envia mensagens, não compra, não acessa contas pessoais nem controla o celular. Isso é intencional: ações externas exigem integrações específicas, permissões e uma camada de aprovação.

## Testar a interface no Android

1. Extraia o ZIP usando um gerenciador de arquivos.
2. Para testar como site, publique os arquivos da pasta raiz em um host estático HTTPS. O GitHub Pages é uma opção para arquivos estáticos.
3. Abra o endereço no Chrome Android.
4. Use o menu do navegador e escolha “Adicionar à tela inicial” ou “Instalar app”, se a opção aparecer.

Abrir `index.html` diretamente como arquivo pode limitar o service worker e a instalação PWA. Use HTTPS para testar a experiência completa.

## Conectar o backend (opcional)

Requisitos: Node.js 18 ou superior e uma chave de API de provedor.

1. Entre na pasta `backend`.
2. Instale dependências com `npm install`.
3. Copie `.env.example` para `.env`.
4. Coloque sua chave em `GEMINI_API_KEY` no ambiente privado do servidor.
5. Rode `npm start`.
6. Configure o endpoint da interface como `https://seu-servidor/api/chat`.

Nunca coloque a chave no JavaScript do frontend, em `index.html`, nem em repositório público. Para publicação real, configure `ALLOWED_ORIGIN` com o domínio exato do frontend, adicione limites de requisições e autenticação apropriada.

## Arquitetura

- `index.html`: estrutura da interface.
- `styles.css`: visual responsivo.
- `app.js`: chat, tarefas, notas e armazenamento local.
- `manifest.webmanifest` e `sw.js`: suporte PWA.
- `backend/server.js`: API Node/Express para o provedor Gemini.
- `backend/.env.example`: variáveis de ambiente de exemplo.

## Próximas melhorias recomendadas

1. Persistência e exportação mais robustas.
2. Autenticação e limites de uso no backend.
3. Ferramentas explícitas com validação de argumentos.
4. Tela de aprovação de cada ação externa.
5. Pesquisa web via API apropriada, com fontes citadas.
6. Entrada e saída de voz.
7. Testes de segurança, privacidade e acessibilidade.

## Segurança

Este é um projeto inicial para aprendizado. Revise antes de uso público. Não envie dados sensíveis ao provedor sem entender sua política de privacidade. O backend envia o histórico recente, as tarefas e as notas que o frontend fornece para contextualizar a resposta.
