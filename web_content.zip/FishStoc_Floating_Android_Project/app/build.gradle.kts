plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.fishstoc.floating"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.fishstoc.floating"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
