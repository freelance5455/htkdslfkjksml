package com.fishstoc.floating

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            setBackgroundColor(Color.rgb(3, 19, 29))
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
        maybeStartShortcut()
    }

    private fun maybeStartShortcut() {
        if (Settings.canDrawOverlays(this)) {
            startFloatingService()
        } else {
            val root = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(28, 28, 28, 28)
                setBackgroundColor(Color.rgb(3, 19, 29))
            }
            val message = TextView(this).apply {
                text = "Allow FishStoc to display its small round FS shortcut over other apps. Your chart will open here, on Chart home."
                textSize = 16f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
            }
            val allow = Button(this).apply {
                text = "Enable floating FS shortcut"
                setOnClickListener {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
            root.addView(message, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            root.addView(allow, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            val wrapper = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(root)
                addView(web, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            }
            setContentView(wrapper)
        }
    }

    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this)) startFloatingService()
    }

    private fun startFloatingService() {
        startForegroundService(Intent(this, FloatingChartService::class.java))
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }
}
