# FishStoc Floating Shortcut — Android Studio source

This revision implements the requested **small round FS shortcut only**. It does not attempt to show a chart in the floating bubble.

## Intended behavior
- Open FishStoc: the chart opens directly on Chart home.
- Grant Android's “Display over other apps” permission when prompted.
- A small round `FS` bubble remains over other apps while the foreground service is active.
- Drag the bubble anywhere on the screen.
- Tap the bubble to return to FishStoc Chart home.
- Use Android Back/Home to leave FishStoc and return to the app you were using; the shortcut remains active.
- The persistent notification indicates the shortcut service is running.

## Build/install
Open this project in Android Studio with Android SDK Platform 35 and build a debug APK using Build > Build APK(s). Install that APK, open FishStoc Floating, and grant overlay permission.

## Limitations / honesty
- This ZIP is Android Studio source, not an installable APK.
- This environment cannot compile or test an APK because Android SDK/Gradle build tools are unavailable.
- Android may restrict overlays on secure screens or some system dialogs. Battery optimization can also stop background services on some devices.
- Internet is needed for the existing public candle feed and chart library CDN.
