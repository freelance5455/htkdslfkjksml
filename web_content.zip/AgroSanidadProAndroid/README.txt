AgroSanidad Pro para Android — proyecto fuente

Este proyecto empaqueta el archivo HTML como una aplicación Android con WebView.
Incluye JavaScript y almacenamiento local para que la app conserve los registros en el dispositivo. Los enlaces web abren el navegador externo y el selector de archivos permite importar copias JSON.

CÓMO GENERAR EL APK
1. Instala Android Studio en un computador: https://developer.android.com/studio
2. Descomprime esta carpeta.
3. En Android Studio selecciona Open y abre la carpeta AgroSanidadProAndroid.
4. Espera a que termine la sincronización de Gradle e instala el SDK Android 35 si lo solicita.
5. Ve a Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio mostrará un aviso con la opción Locate. El APK de depuración suele quedar en app/build/outputs/apk/debug/app-debug.apk.
7. Copia el APK al celular y ábrelo para instalar. Puede ser necesario permitir instalar aplicaciones desde esa fuente.

IMPORTANTE
- Este entorno no tiene Android SDK/Gradle instalado, por eso aquí se entrega el proyecto listo para abrir y compilar, no un APK ya compilado.
- Los registros guardados dentro de la app viven en el almacenamiento local de esa instalación. Usa periódicamente la sección Copias de seguridad para exportar JSON.
- No desinstales la app ni borres sus datos antes de exportar una copia si necesitas conservar tus registros.
