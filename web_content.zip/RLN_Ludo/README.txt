RLN Ludo - Offline HTML Prototype

Files:
- index.html: open this file in an Android browser to try the game.
- This is a starter prototype, not a fully verified commercial Ludo implementation.
- Basic offline local pass-and-play and computer opponent modes are included.
- Some traditional Ludo rules, safe squares, and exact finishing behavior may need further testing/improvement.
- Internet is not required to play once the HTML file is on the phone.
- Internet may be required by an online HTML-to-APK service to package the file.
- Do not install APKs from unknown sources unless you trust the provider.

Try on Android:
1. Extract the ZIP.
2. Open index.html with Chrome or another browser.
3. For APK packaging, visit https://www.htmltoapp.dev/ and check current service requirements.
4. Upload index.html (or a ZIP if the service accepts it), set app name to RLN Ludo, build APK, then test offline.
