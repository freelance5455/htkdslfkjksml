# Emberfall v1.8.4 — Fullscreen + HUD Modes

## Added
- FOCUS HUD: hides large quest and character panels on mobile for more visible world space.
- CLASSIC HUD: brings back the quest and character panels.
- FULLSCREEN: requests browser fullscreen when supported. Some mobile browsers block fullscreen from local `content://` files; if so, use Chrome's menu and try Add to Home screen.
- The chosen HUD mode is saved locally when browser storage is available.
- All existing game systems are retained from v1.8.3.

## Run
Open `emberfall_rpg_v184_fullscreen_hud_modes.html` in a modern browser. Use the three display buttons at the top to change view modes.
Static source checks only; full playtesting on a physical phone is still recommended.
