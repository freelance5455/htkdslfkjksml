# APPRECIATE OS v1.45 — Cloud Exposure Hardening Update

## Implemented in this source update

- Deployment configuration: app and cloud-control host ports bind to loopback by default; the owner control plane is no longer published on all host interfaces by default.
- Installation guidance: clarified reverse-proxy routing and private owner-portal access through SSH tunnel or administrator VPN.

- APPRECIATE CODE: local bare Git repositories, repository creation, ZIP source upload and Git commit.
- APPRECIATE BUILD: Dockerfile-based builds from a repository branch.
- APPRECIATE DEPLOY: deploy built images as containers with memory, CPU, process-count and no-new-privileges limits.
- APPRECIATE DEPLOY: default application port bindings are loopback-only (`127.0.0.1`) until a managed HTTPS gateway is installed.
- APPRECIATE DEPLOY: restart, stop, delete and retrieve recent container logs.
- APPRECIATE MONITOR: query live container state and reconcile stored application status.
- APPRECIATE CLOUD: PostgreSQL-backed application/deployment records and audit events.
- Dashboard: added runtime monitoring and application lifecycle controls.
- No GitLab, Render, Forgejo or Coolify service is defined in the active Compose project.

## Checks performed for this update

- Compose exposure review: both host-published services use loopback bindings by default; database remains internal-only.

- Node.js syntax checks: passed for cloud server and browser client.
- Built-in validation test suite: 9 tests passed.
- Native Git smoke test: previously verified in v1.43 source.
- Docker image build, Docker container deployment, PostgreSQL integration, and browser end-to-end checks were not run: Docker daemon is not available in this workspace and npm dependencies could not be installed offline.

## Still missing before this is a complete public hosting platform

1. Git smart-HTTP/SSH push and clone; current source intake is ZIP upload only.
2. Managed build queue/workers, cancellation, streaming logs and retry policy.
3. Deployment rollback and release history tied to immutable image digests.
4. APPRECIATE gateway with custom domains, HTTPS certificates and public routing.
5. Per-project database provisioning, credentials, quotas and backups/restore.
6. Private object/file storage, retention policy and restore testing.
7. Encrypted secrets vault and key rotation.
8. Customer accounts, tenant isolation, role permissions, quotas and billing/usage metering.
9. Image vulnerability scanning, SBOM, signing, sandboxing and independent security review.
10. Live integration tests on a dedicated host with Docker Engine and PostgreSQL.

## Important operational security note

The control-plane container currently mounts the Docker socket. Anyone who obtains its owner API key can control the host's containers and potentially the host itself. Keep the management API private, protect the owner key, and do not expose port 3100 directly to the public internet. The default app binding is loopback-only.

This is a self-hosted owner-operated development release, not yet a public multi-tenant PaaS. A real server with internet access, persistent storage, DNS and TLS is still required to run it.
