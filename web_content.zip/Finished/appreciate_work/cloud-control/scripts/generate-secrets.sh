#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"
if [ -e .env ]; then echo "Refusing to overwrite existing .env"; exit 1; fi
cp .env.example .env
python3 - <<'PYSECRETS'
from pathlib import Path
import secrets, re
p=Path('.env'); s=p.read_text()
for key in ['POSTGRES_PASSWORD','APP_SECRET','VOUCHER_CODE_PEPPER','CLOUD_ADMIN_KEY']:
    s=re.sub(rf'^{key}=.*$',f'{key}={secrets.token_urlsafe(48)}',s,flags=re.M)
p.write_text(s)
PYSECRETS
chmod 600 .env
echo 'Created root .env with unique secrets. Keep it private and back it up securely.'
