require('dotenv').config();
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const db = require('./db');
const paypal = require('./paypal');
const bankProvider = require('./bank-provider');
const { createSession, requireAuth, requireRole, requireCsrf, revokeSession } = require('./auth');
const { issueVoucher } = require('./vouchers');
const { partnerSecretEnvName, verifyReportSignature, validatePartnerReport, isValidDate } = require('./reporting');
const partnerConnectors = require('./partner-connectors');
const { ALLOWED_EXTERNAL_METHODS, ALLOWED_REPORT_SCOPES, isCurrentExternalAuthorisation } = require('./partner-authorisation');
const { createPayment, recordVerifiedPayment, BANK_METHODS } = require('./payments');
const privateStorage = require('./private-storage');

if (!process.env.APP_SECRET || process.env.APP_SECRET.length < 32 || process.env.APP_SECRET.includes('REPLACE') || process.env.APP_SECRET.includes('change_me')) {
  throw new Error('APP_SECRET must be replaced with a unique secret of at least 32 random characters.');
}

const app = express();
let mediaStorageOrigin = null;
try { if (process.env.MEDIA_STORAGE_ENDPOINT) mediaStorageOrigin = new URL(process.env.MEDIA_STORAGE_ENDPOINT).origin; } catch {}
const port = Number(process.env.PORT || 8080);
const allowedOrigins = (process.env.CORS_ORIGIN || process.env.APP_BASE_URL || `http://localhost:${port}`).split(',').map((x) => x.trim()).filter(Boolean);
app.set('trust proxy', process.env.TRUST_PROXY === 'true' ? 1 : false);
app.disable('x-powered-by');
const cspDirectives = {
      defaultSrc: ["'self'"],
      baseUri: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"],
      imgSrc: ["'self'", 'data:', 'blob:'],
      mediaSrc: ["'self'", 'blob:', ...(mediaStorageOrigin ? [mediaStorageOrigin] : [])],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'"],
      connectSrc: ["'self'", ...(mediaStorageOrigin ? [mediaStorageOrigin] : [])],
      formAction: ["'self'"],
};
if (process.env.NODE_ENV === 'production') cspDirectives.upgradeInsecureRequests = [];
app.use(helmet({ contentSecurityPolicy: { directives: cspDirectives } }));
app.use(cors({
  origin(origin, callback) {
    if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
    return callback(new Error('Origin is not allowed by APPRECIATE CORS policy.'));
  },
  credentials: true
}));
app.use(express.json({ limit: '1mb', verify: (req, _res, buffer) => { req.rawBody = Buffer.from(buffer); } }));
app.use(cookieParser());
app.use('/api/v1', requireCsrf);
app.use(express.static(path.join(__dirname, '..', 'public'), { extensions: ['html'] }));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 12, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Too many account attempts. Please wait and try again.' } });
const paymentLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Too many payment requests. Please wait and try again.' } });
const reportLimiter = rateLimit({ windowMs: 60 * 1000, limit: 60, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Too many report deliveries. Please retry later.' } });
const asyncRoute = (handler) => (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);
const textValue = (value, max = 2000) => String(value ?? '').trim().slice(0, max);
const validEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254;
const minor = (amount) => {
  const n = Number(amount);
  if (!Number.isFinite(n) || n <= 0 || n > 100000000) { const error = new Error('Enter a valid positive amount.'); error.status = 400; throw error; }
  return Math.round(n * 100);
};
const reference = (prefix) => `${prefix}-${crypto.randomUUID()}`;

const EVIDENCE_MIME_TYPES = new Set(['application/pdf','image/jpeg','image/png']);
const EVIDENCE_MAX_BYTES = 10 * 1024 * 1024;
const EVIDENCE_TYPES = new Set(['identity','recording_rights','partner_authorisation']);
const evidencePrefix = (type) => ({ identity:'identity', recording_rights:'recording-rights', partner_authorisation:'partner-authorisations' })[type];
function httpError(message, status = 400) { const error = new Error(message); error.status = status; return error; }
async function attachPrivateEvidence(client, ownerId, uploadId, evidenceType) {
  const result = await client.query(
    `SELECT id,object_key,content_type,expected_size_bytes,status,expires_at
     FROM private_evidence_uploads
     WHERE id=$1 AND owner_user_id=$2 AND evidence_type=$3
     FOR UPDATE`, [uploadId, ownerId, evidenceType]
  );
  if (!result.rowCount) throw httpError('Private evidence upload was not found for this account and evidence type.', 404);
  const upload = result.rows[0];
  if (upload.status !== 'uploaded' || new Date(upload.expires_at) <= new Date()) throw httpError('Complete the private evidence upload before submitting it for review.', 409);
  return upload;
}

async function audit(actorId, eventType, entityType, entityId, details = {}) {
  await db.query(
    `INSERT INTO audit_log(actor_user_id,event_type,entity_type,entity_id,details)
     VALUES($1,$2,$3,$4,$5::jsonb)`,
    [actorId || null, eventType, entityType, entityId == null ? null : String(entityId), JSON.stringify(details)]
  );
}

app.get('/health', asyncRoute(async (_req, res) => {
  await db.query('SELECT 1');
  res.json({ ok: true, service: 'APPRECIATE self-hosted API', database: 'connected', version: '1.41.2' });
}));

// --------------------------- Secure accounts ---------------------------
app.post('/api/v1/auth/register', authLimiter, asyncRoute(async (req, res) => {
  const email = textValue(req.body?.email, 254).toLowerCase();
  const displayName = textValue(req.body?.displayName, 100);
  const password = String(req.body?.password || '');
  const requestedType = textValue(req.body?.accountType || 'member', 20);
  const allowedTypes = new Set(['member', 'creator', 'artist', 'seller', 'company']);
  if (!validEmail(email)) return res.status(400).json({ error: 'Enter a valid email address.' });
  if (password.length < 10 || password.length > 128) return res.status(400).json({ error: 'Use a password between 10 and 128 characters.' });
  if (displayName.length < 2) return res.status(400).json({ error: 'Enter your display name.' });
  if (!allowedTypes.has(requestedType)) return res.status(400).json({ error: 'That account type cannot be selected at registration.' });
  // Public registration never grants manager/admin privileges. Promote the owner from the trusted server shell after registration.
  const accountType = requestedType;
  const passwordHash = await bcrypt.hash(password, 12);
  const client = await db.pool.connect();
  try {
    await client.query('BEGIN');
    const inserted = await client.query(
      'INSERT INTO users(email,password_hash,account_type) VALUES($1,$2,$3) RETURNING id,email,account_type',
      [email, passwordHash, accountType]
    );
    const user = inserted.rows[0];
    await client.query('INSERT INTO profiles(user_id,display_name) VALUES($1,$2)', [user.id, displayName]);
    if (accountType === 'company') {
      await client.query('INSERT INTO company_profiles(user_id,company_name,contact_name) VALUES($1,$2,$3)', [user.id, displayName, displayName]);
    }
    await client.query('COMMIT');
    const token = await createSession(user, res, req.get('x-client-type'));
    await audit(user.id, 'account_registered', 'user', user.id, { accountType });
    res.status(201).json({ user: { id: user.id, email: user.email, accountType: user.account_type, displayName }, ...(token ? { accessToken: token } : {}) });
  } catch (error) {
    await client.query('ROLLBACK');
    if (error.code === '23505') return res.status(409).json({ error: 'An account with this email already exists.' });
    throw error;
  } finally {
    client.release();
  }
}));

app.post('/api/v1/auth/login', authLimiter, asyncRoute(async (req, res) => {
  const email = textValue(req.body?.email, 254).toLowerCase();
  const password = String(req.body?.password || '');
  const result = await db.query('SELECT id,email,password_hash,account_type,is_active FROM users WHERE email=$1', [email]);
  if (!result.rowCount || !result.rows[0].is_active || !(await bcrypt.compare(password, result.rows[0].password_hash))) {
    return res.status(401).json({ error: 'Email or password is incorrect.' });
  }
  const user = result.rows[0];
  await db.query('UPDATE users SET last_login_at=NOW() WHERE id=$1', [user.id]);
  const profile = await db.query('SELECT display_name FROM profiles WHERE user_id=$1', [user.id]);
  const token = await createSession(user, res, req.get('x-client-type'));
  await audit(user.id, 'account_login', 'user', user.id);
  res.json({ user: { id: user.id, email: user.email, accountType: user.account_type, displayName: profile.rows[0]?.display_name || '' }, ...(token ? { accessToken: token } : {}) });
}));

app.post('/api/v1/auth/logout', requireAuth, asyncRoute(async (req, res) => {
  await revokeSession(req, res);
  await audit(req.user.id, 'account_logout', 'user', req.user.id);
  res.json({ ok: true });
}));

app.get('/api/v1/me', requireAuth, asyncRoute(async (req, res) => {
  res.json({ user: req.user });
}));

app.patch('/api/v1/profile', requireAuth, asyncRoute(async (req, res) => {
  const displayName = textValue(req.body?.displayName, 100);
  const username = textValue(req.body?.username, 40).replace(/^@/, '').toLowerCase();
  const bio = textValue(req.body?.bio, 1200);
  if (displayName.length < 2) return res.status(400).json({ error: 'Display name is required.' });
  try {
    const result = await db.query(
      `UPDATE profiles SET display_name=$1,username=NULLIF($2,''),bio=$3,updated_at=NOW()
       WHERE user_id=$4 RETURNING display_name,username,bio`,
      [displayName, username, bio, req.user.id]
    );
    res.json({ profile: result.rows[0] });
  } catch (error) {
    if (error.code === '23505') return res.status(409).json({ error: 'That username is already in use.' });
    throw error;
  }
}));

// Server-side health check for the independently hosted APPRECIATE CLOUD portal.
// The shared key remains on the server and is never returned to the browser.
app.get('/api/v1/cloud/platform', requireAuth, asyncRoute(async (_req, res) => {
  const cloudUrl = String(process.env.APPRECIATE_CLOUD_URL || '').trim().replace(/\/$/, '');
  const cloudKey = String(process.env.APPRECIATE_CLOUD_API_KEY || '').trim();
  if (!cloudUrl || !cloudKey) return res.json({ configured: false, connected: false, url: null, message: 'APPRECIATE CLOUD connection details are not configured yet.' });
  let connected = false;
  try { const response = await fetch(`${cloudUrl}/api/v1/status`, { headers: { Authorization: `Bearer ${cloudKey}` }, signal: AbortSignal.timeout(5000) }); if (response.ok) connected = (await response.json()).ok === true; } catch {}
  res.json({ configured: true, connected, url: cloudUrl, message: connected ? 'Your APPRECIATE CLOUD server is responding.' : 'Cloud URL and key are configured, but the cloud server is not responding.' });
}));

// --------------------------- APPRECIATE Cloud Services ---------------------------
// Customer project and deployment request records are stored here. A saved request
// is not a live deployment; live resource management is performed in APPRECIATE CLOUD.
app.get('/api/v1/cloud/projects', requireAuth, asyncRoute(async (req, res) => {
  const result = await db.query(
    `SELECT p.id,p.name,p.repository_url,p.framework,p.region,p.created_at,p.updated_at,
       (SELECT COUNT(*)::int FROM cloud_deployment_requests d WHERE d.project_id=p.id) AS deployment_count,
       (SELECT d.status FROM cloud_deployment_requests d WHERE d.project_id=p.id ORDER BY d.created_at DESC LIMIT 1) AS latest_deployment_status,
       (SELECT d.created_at FROM cloud_deployment_requests d WHERE d.project_id=p.id ORDER BY d.created_at DESC LIMIT 1) AS latest_deployment_at
     FROM cloud_projects p WHERE p.owner_user_id=$1 ORDER BY p.updated_at DESC`, [req.user.id]
  );
  res.json({ projects: result.rows, providerStatus: 'not_configured', message: 'Project records are active. Live repository sync and deployments require verified provider credentials.' });
}));

app.post('/api/v1/cloud/projects', requireAuth, asyncRoute(async (req, res) => {
  const name = textValue(req.body?.name, 80);
  const framework = textValue(req.body?.framework || 'other', 40);
  const repositoryUrl = textValue(req.body?.repositoryUrl, 500);
  const region = textValue(req.body?.region || 'za', 12).toLowerCase();
  const allowedFrameworks = new Set(['node','static','react','nextjs','python','php','other']);
  if (name.length < 2) return res.status(400).json({ error: 'Project name must be at least 2 characters.' });
  if (!allowedFrameworks.has(framework)) return res.status(400).json({ error: 'Choose a supported project type.' });
  if (repositoryUrl) {
    let parsed;
    try { parsed = new URL(repositoryUrl); } catch { return res.status(400).json({ error: 'Enter a valid HTTPS Git repository URL.' }); }
    if (parsed.protocol !== 'https:' || parsed.username || parsed.password || !/^[A-Za-z0-9_.-]+(?:\/[A-Za-z0-9_.-]+){1,3}(?:\.git)?$/.test(parsed.pathname.replace(/^\//,''))) {
      return res.status(400).json({ error: 'Use a public HTTPS Git repository URL without embedded credentials.' });
    }
  }
  if (!['za','eu','us'].includes(region)) return res.status(400).json({ error: 'Choose an available region.' });
  const result = await db.query(
    `INSERT INTO cloud_projects(owner_user_id,name,repository_url,framework,region)
     VALUES($1,$2,NULLIF($3,''),$4,$5) RETURNING id,name,repository_url,framework,region,created_at`,
    [req.user.id,name,repositoryUrl,framework,region]
  );
  await audit(req.user.id, 'cloud_project_created', 'cloud_project', result.rows[0].id, { framework, region, repositoryLinked: Boolean(repositoryUrl) });
  res.status(201).json({ project: result.rows[0], providerStatus: 'not_configured', message: 'Project created. Connect and verify the hosting provider before deploying.' });
}));

app.post('/api/v1/cloud/projects/:id/deployments', requireAuth, asyncRoute(async (req, res) => {
  const project = await db.query('SELECT id,repository_url FROM cloud_projects WHERE id=$1 AND owner_user_id=$2', [req.params.id,req.user.id]);
  if (!project.rowCount) return res.status(404).json({ error: 'Project not found in your workspace.' });
  if (!project.rows[0].repository_url) return res.status(400).json({ error: 'Add an APPRECIATE CODE HTTPS repository URL to this project before requesting deployment.' });
  const branch = textValue(req.body?.branch || 'main', 100);
  if (!/^[A-Za-z0-9._/-]{1,100}$/.test(branch) || branch.includes('..')) return res.status(400).json({ error: 'Enter a valid Git branch name.' });
  const result = await db.query(
    `INSERT INTO cloud_deployment_requests(project_id,owner_user_id,branch,status,provider,details)
     VALUES($1,$2,$3,'awaiting_provider_setup','appreciate_cloud','{}'::jsonb)
     RETURNING id,project_id,branch,status,provider,created_at`,
    [project.rows[0].id,req.user.id,branch]
  );
  await audit(req.user.id, 'cloud_deployment_requested', 'cloud_deployment', result.rows[0].id, { provider: 'appreciate_cloud', status: 'awaiting_provider_setup' });
  res.status(202).json({ deployment: result.rows[0], message: 'Deployment request saved. This is an APPRECIATE deployment request record. Open APPRECIATE CLOUD to configure the live application resource and deployment connection.' });
}));

// --------------------------- Marketplace and orders ---------------------------
app.get('/api/v1/products', asyncRoute(async (req, res) => {
  const q = textValue(req.query.q, 100);
  const result = await db.query(
    `SELECT p.id,p.seller_id,p.kind,p.category,p.title,p.description,p.price_minor,p.currency,p.stock_quantity,p.image_storage_key,p.created_at,pr.display_name AS seller_name
     FROM products p JOIN profiles pr ON pr.user_id=p.seller_id
     WHERE p.status='published' AND ($1='' OR p.title ILIKE '%'||$1||'%' OR p.description ILIKE '%'||$1||'%')
     ORDER BY p.created_at DESC LIMIT 100`, [q]
  );
  res.json({ products: result.rows });
}));

app.post('/api/v1/products', requireAuth, requireRole('creator','artist','seller','manager','admin'), asyncRoute(async (req, res) => {
  const kind = textValue(req.body?.kind || 'physical', 20);
  const category = textValue(req.body?.category || 'Other', 60);
  const title = textValue(req.body?.title, 120);
  const description = textValue(req.body?.description, 2000);
  const priceMinor = minor(req.body?.price);
  const stock = req.body?.stockQuantity === '' || req.body?.stockQuantity == null ? null : Number(req.body.stockQuantity);
  const status = req.body?.status === 'draft' ? 'draft' : 'published';
  if (!['physical','service','digital'].includes(kind)) return res.status(400).json({ error: 'Use the music release endpoint for music listings.' });
  if (title.length < 2) return res.status(400).json({ error: 'Product title is too short.' });
  if (stock !== null && (!Number.isInteger(stock) || stock < 0)) return res.status(400).json({ error: 'Stock quantity must be a non-negative whole number.' });
  const result = await db.query(
    `INSERT INTO products(seller_id,kind,category,title,description,price_minor,stock_quantity,status)
     VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [req.user.id, kind, category, title, description, priceMinor, stock, status]
  );
  await audit(req.user.id, 'product_created', 'product', result.rows[0].id, { kind, status });
  res.status(201).json({ product: result.rows[0] });
}));

app.get('/api/v1/orders', requireAuth, asyncRoute(async (req, res) => {
  const result = await db.query(
    `SELECT o.*,COALESCE(json_agg(json_build_object('title',oi.title_snapshot,'quantity',oi.quantity,'lineTotalMinor',oi.line_total_minor,'sellerId',oi.seller_id)) FILTER (WHERE oi.id IS NOT NULL),'[]') AS items
     FROM orders o LEFT JOIN order_items oi ON oi.order_id=o.id
     WHERE o.buyer_id=$1 GROUP BY o.id ORDER BY o.created_at DESC LIMIT 100`, [req.user.id]
  );
  res.json({ orders: result.rows });
}));

app.post('/api/v1/orders', requireAuth, asyncRoute(async (req, res) => {
  const items = Array.isArray(req.body?.items) ? req.body.items.slice(0, 20) : [];
  if (!items.length) return res.status(400).json({ error: 'Add at least one product to the order.' });
  const client = await db.pool.connect();
  try {
    await client.query('BEGIN');
    const prepared = [];
    let total = 0;
    for (const entry of items) {
      const productId = textValue(entry.productId, 64);
      const quantity = Number(entry.quantity || 1);
      if (!Number.isInteger(quantity) || quantity < 1 || quantity > 25) throw new Error('Each product quantity must be between 1 and 25.');
      const product = await client.query("SELECT * FROM products WHERE id=$1 AND status='published' FOR SHARE", [productId]);
      if (!product.rowCount) throw new Error('A selected product is no longer available.');
      const p = product.rows[0];
      if (p.stock_quantity !== null && Number(p.stock_quantity) < quantity) throw new Error(`Not enough stock for ${p.title}.`);
      const line = Number(p.price_minor) * quantity;
      total += line;
      prepared.push({ product: p, quantity, line });
    }
    if (prepared.some((x) => x.product.currency !== prepared[0].product.currency)) throw new Error('All products in one order must use the same currency.');
    const order = await client.query(
      "INSERT INTO orders(buyer_id,currency,total_minor,state) VALUES($1,$2,$3,'pending') RETURNING *",
      [req.user.id, prepared[0].product.currency, total]
    );
    for (const item of prepared) {
      await client.query(
        `INSERT INTO order_items(order_id,product_id,seller_id,product_kind,title_snapshot,quantity,unit_price_minor,line_total_minor)
         VALUES($1,$2,$3,$4,$5,$6,$7,$8)`,
        [order.rows[0].id, item.product.id, item.product.seller_id, item.product.kind, item.product.title, item.quantity, item.product.price_minor, item.line]
      );
    }
    await client.query('COMMIT');
    await audit(req.user.id, 'order_created', 'order', order.rows[0].id, { totalMinor: total });
    res.status(201).json({ order: order.rows[0] });
  } catch (error) {
    await client.query('ROLLBACK');
    res.status(400).json({ error: error.message });
  } finally {
    client.release();
  }
}));

app.post('/api/v1/orders/:id/refund-request', requireAuth, asyncRoute(async (req, res) => {
  const reason = textValue(req.body?.reason, 1000);
  if (reason.length < 5) return res.status(400).json({ error: 'Please provide a short reason for the refund request.' });
  const order = await db.query("SELECT id,state FROM orders WHERE id=$1 AND buyer_id=$2", [req.params.id, req.user.id]);
  if (!order.rowCount || !['paid','fulfilled'].includes(order.rows[0].state)) return res.status(404).json({ error: 'Paid order not found.' });
  const result = await db.query('INSERT INTO refund_requests(order_id,requested_by,reason) VALUES($1,$2,$3) RETURNING *', [req.params.id, req.user.id, reason]);
  await audit(req.user.id, 'refund_requested', 'refund_request', result.rows[0].id);
  res.status(201).json({ refundRequest: result.rows[0], message: 'Refund request recorded. It is not yet a provider-issued refund.' });
}));

// --------------------------- Client bookings and priced booking invoices ---------------------------
const BOOKING_TYPES = new Set(['artist_performance','artist_appearance','artist_consultation','artist_development','music_production','video_content','brand_campaign','other']);
app.get('/api/v1/bookings', requireAuth, asyncRoute(async (req, res) => {
  const isManager = ['admin','manager'].includes(req.user.account_type);
  const own = await db.query(
    `SELECT b.*,i.reference AS invoice_reference,i.status AS invoice_status,p.display_name
     FROM client_bookings b LEFT JOIN payment_invoices i ON i.id=b.invoice_id
     LEFT JOIN profiles p ON p.user_id=b.client_user_id
     WHERE b.client_user_id=$1 ORDER BY b.created_at DESC LIMIT 100`, [req.user.id]
  );
  if (!isManager) return res.json({ bookings: own.rows, allBookings: [] });
  const all = await db.query(
    `SELECT b.*,i.reference AS invoice_reference,i.status AS invoice_status,p.display_name
     FROM client_bookings b LEFT JOIN payment_invoices i ON i.id=b.invoice_id
     LEFT JOIN profiles p ON p.user_id=b.client_user_id
     ORDER BY CASE b.status WHEN 'requested' THEN 0 ELSE 1 END,b.booking_date,b.start_time LIMIT 200`
  );
  res.json({ bookings: own.rows, allBookings: all.rows });
}));

app.post('/api/v1/bookings', requireAuth, asyncRoute(async (req, res) => {
  const serviceType = textValue(req.body?.serviceType, 40);
  const bookingDate = textValue(req.body?.bookingDate, 10);
  const startTime = textValue(req.body?.startTime, 5);
  const duration = Number(req.body?.durationMinutes || 60);
  const location = textValue(req.body?.location, 240);
  const notes = textValue(req.body?.notes, 2000);
  if (!BOOKING_TYPES.has(serviceType)) return res.status(400).json({error:'Choose a valid booking service.'});
  if (!/^\d{4}-\d{2}-\d{2}$/.test(bookingDate) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(startTime)) return res.status(400).json({error:'Choose a valid booking date and time.'});
  const parsedDate = new Date(`${bookingDate}T00:00:00Z`);
  if (Number.isNaN(parsedDate.getTime()) || parsedDate.toISOString().slice(0,10) !== bookingDate) return res.status(400).json({error:'Choose a real calendar date.'});
  const localNow = new Intl.DateTimeFormat('en-CA',{timeZone:'Africa/Johannesburg',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(new Date()).reduce((o,p)=>{o[p.type]=p.value;return o;},{});
  const todayLocal = `${localNow.year}-${localNow.month}-${localNow.day}`;
  const currentLocalTime = `${localNow.hour}:${localNow.minute}`;
  if (bookingDate < todayLocal || (bookingDate === todayLocal && startTime <= currentLocalTime)) return res.status(400).json({error:'Choose a future booking date and time in South African local time.'});
  if (!Number.isInteger(duration) || duration < 15 || duration > 1440) return res.status(400).json({error:'Choose a valid booking duration.'});
  if (location.length < 2) return res.status(400).json({error:'Enter the venue, area or online meeting location.'});
  const result = await db.query(
    `INSERT INTO client_bookings(reference,client_user_id,service_type,booking_date,start_time,duration_minutes,location,notes)
     VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id,reference,service_type,booking_date,start_time,duration_minutes,location,status,created_at`,
    [reference('BOOK'),req.user.id,serviceType,bookingDate,startTime,duration,location,notes]
  );
  await audit(req.user.id,'booking.requested','client_booking',result.rows[0].id,{serviceType,bookingDate});
  res.status(201).json({booking:result.rows[0],message:'Booking request received. It is not confirmed and no payment has been taken.'});
}));

app.patch('/api/v1/bookings/:id/decision', requireAuth, requireRole('manager','admin'), asyncRoute(async (req, res) => {
  const decision = textValue(req.body?.decision, 20);
  if (!['accept','decline'].includes(decision)) return res.status(400).json({error:'Choose accept or decline.'});
  const client = await db.pool.connect();
  try {
    await client.query('BEGIN');
    const found = await client.query('SELECT * FROM client_bookings WHERE id=$1 FOR UPDATE',[req.params.id]);
    if (!found.rowCount) { await client.query('ROLLBACK'); return res.status(404).json({error:'Booking not found.'}); }
    const booking = found.rows[0];
    if (booking.status !== 'requested') { await client.query('ROLLBACK'); return res.status(409).json({error:'Only new booking requests can be reviewed.'}); }
    if (decision === 'decline') {
      await client.query("UPDATE client_bookings SET status='declined',reviewed_by=$1,reviewed_at=NOW(),updated_at=NOW() WHERE id=$2",[req.user.id,booking.id]);
      await client.query('COMMIT');
      await audit(req.user.id,'booking.declined','client_booking',booking.id,{});
      return res.json({message:'Booking request declined.'});
    }
    const amountMinor = minor(req.body?.amount);
    const invoice = await client.query(
      `INSERT INTO payment_invoices(bill_to_user_id,payee_user_id,created_by,reference,amount_minor,currency,description,due_at)
       VALUES($1,$2,$2,$3,$4,'ZAR',$5,NOW()+INTERVAL '7 days') RETURNING id,reference`,
      [booking.client_user_id,req.user.id,reference('INV'),amountMinor,`APPRECIATE booking ${booking.reference}`]
    );
    await client.query(
      `UPDATE client_bookings SET status='accepted_pending_payment',amount_minor=$1,invoice_id=$2,reviewed_by=$3,reviewed_at=NOW(),updated_at=NOW() WHERE id=$4`,
      [amountMinor,invoice.rows[0].id,req.user.id,booking.id]
    );
    await client.query('COMMIT');
    await audit(req.user.id,'booking.accepted','client_booking',booking.id,{invoiceReference:invoice.rows[0].reference,amountMinor});
    res.json({message:`Booking accepted subject to payment. Invoice ${invoice.rows[0].reference} created for the client; the booking is confirmed only after payment is verified.`,invoiceReference:invoice.rows[0].reference});
  } catch(error) { await client.query('ROLLBACK'); throw error; }
  finally { client.release(); }
}));

app.post('/api/v1/bookings/:id/cancel', requireAuth, asyncRoute(async (req, res) => {
  const result = await db.query(
    `UPDATE client_bookings SET status='cancelled',updated_at=NOW()
     WHERE id=$1 AND client_user_id=$2 AND status IN ('requested','accepted_pending_payment') RETURNING id,invoice_id`,
    [req.params.id,req.user.id]
  );
  if (!result.rowCount) return res.status(404).json({error:'Booking cannot be cancelled from this account or is no longer cancellable.'});
  if (result.rows[0].invoice_id) await db.query("UPDATE payment_invoices SET status='void' WHERE id=$1 AND status='pending'",[result.rows[0].invoice_id]);
  await audit(req.user.id,'booking.cancelled','client_booking',result.rows[0].id,{});
  res.json({message:'Booking cancelled. Any unpaid booking invoice has been voided.'});
}));

// --------------------------- Payment methods, checkout and ledger ---------------------------
app.get('/api/v1/payment-methods', (_req, res) => {
  const voucherPepper = process.env.VOUCHER_CODE_PEPPER || '';
  const voucherEnabled = process.env.PAYMENT_VOUCHER_AUTHORISED === 'true' && voucherPepper.length >= 32 && !voucherPepper.includes('REPLACE') && !voucherPepper.includes('change_me');
  const paypalEnabled = process.env.PAYMENT_PAYPAL_AUTHORISED === 'true' && !!process.env.PAYPAL_CLIENT_ID && !!process.env.PAYPAL_CLIENT_SECRET && !!process.env.PAYPAL_WEBHOOK_ID;
  const methods = [
    { id: 'voucher', name: 'APPRECIATE voucher', enabled: voucherEnabled, reason: voucherEnabled ? 'Internal voucher redemption is configured.' : 'Voucher authorisation or secure code secret is missing.' },
    { id: 'paypal', name: 'PayPal', enabled: paypalEnabled, reason: paypalEnabled ? `PayPal ${process.env.PAYPAL_MODE || 'sandbox'} credentials and webhook ID are configured.` : 'PayPal merchant credentials and verified webhook setup are required.' },
    ...[...BANK_METHODS].map((id) => {
      const ready = bankProvider.readiness(id);
      return { id, name: ({capitec:'Capitec',fnb:'FNB',tymebank:'TymeBank',standard_bank:'Standard Bank',absa:'Absa'})[id], enabled: ready.ready, reason: ready.reason };
    })
  ];
  res.json({ methods, note: 'Bank names identify customer account routes. Actual checkout is provided by a contracted South African PSP/aggregator, not by storing bank login credentials.' });
});

app.post('/api/v1/payments', requireAuth, paymentLimiter, asyncRoute(async (req, res) => {
  const result = await createPayment({
    userId: req.user.id,
    orderId: req.body?.orderId || null,
    invoiceId: req.body?.invoiceId || null,
    method: textValue(req.body?.method, 30),
    voucherCode: req.body?.voucherCode,
    bankChannel: req.body?.bankChannel,
    returnUrl: undefined,
    cancelUrl: undefined
  });
  res.status(201).json(result);
}));

app.get('/api/v1/payments', requireAuth, asyncRoute(async (req, res) => {
  const result = await db.query(
    `SELECT reference,amount_minor,currency,method,status,provider,provider_reference,created_at,paid_at
     FROM payment_transactions WHERE customer_id=$1 ORDER BY created_at DESC LIMIT 100`, [req.user.id]
  );
  res.json({ payments: result.rows });
}));

app.post('/api/v1/payments/:reference/capture', requireAuth, paymentLimiter, asyncRoute(async (req, res) => {
  const result = await db.query(
    `SELECT pt.* FROM payment_transactions pt
     LEFT JOIN orders o ON o.id=pt.order_id
     LEFT JOIN payment_invoices i ON i.id=pt.invoice_id
     WHERE pt.reference=$1 AND pt.method='paypal'
       AND (o.buyer_id=$2 OR i.bill_to_user_id=$2)`, [req.params.reference, req.user.id]
  );
  if (!result.rowCount || !result.rows[0].provider_reference) return res.status(404).json({ error: 'PayPal order not found for this account.' });
  const payment = result.rows[0];
  const captured = await paypal.captureOrder(payment.provider_reference);
  const capture = captured.purchase_units?.[0]?.payments?.captures?.find((x) => x.status === 'COMPLETED');
  if (capture) {
    const verified = await recordVerifiedPayment({
      reference: payment.reference,
      provider: 'paypal',
      providerReference: payment.provider_reference,
      amountMinor: Math.round(Number(capture.amount.value) * 100),
      currency: capture.amount.currency_code,
      rawEvent: captured,
      eventType: 'PAYMENT.CAPTURE.COMPLETED'
    });
    return res.json({ providerStatus: captured.status, payment: verified });
  }
  res.json({ providerStatus: captured.status, paymentStatus: 'pending' });
}));

app.post('/api/v1/webhooks/paypal', asyncRoute(async (req, res) => {
  const verified = await paypal.verifyWebhook(req.headers, req.body);
  if (!verified) return res.status(400).json({ error: 'Invalid PayPal webhook signature.' });
  if (req.body?.event_type === 'PAYMENT.CAPTURE.COMPLETED') {
    const resource = req.body.resource || {};
    const orderId = resource.supplementary_data?.related_ids?.order_id || null;
    const referenceValue = resource.custom_id || resource.invoice_id || null;
    await recordVerifiedPayment({
      reference: referenceValue,
      provider: 'paypal',
      providerReference: orderId,
      amountMinor: Math.round(Number(resource.amount?.value) * 100),
      currency: resource.amount?.currency_code,
      rawEvent: req.body,
      providerEventId: req.body.id,
      eventType: req.body.event_type
    });
  }
  res.json({ received: true });
}));

app.post('/api/v1/webhooks/bank', asyncRoute(async (req, res) => {
  const event = await bankProvider.verifyWebhook(req.headers, req.body);
  if (!event || !event.reference || !event.providerReference || !event.amountMinor || !event.currency || !event.eventId) {
    return res.status(400).json({ error: 'Bank PSP webhook could not be verified or normalised.' });
  }
  const result = await recordVerifiedPayment({
    reference: event.reference,
    provider: process.env.BANK_PAYMENT_PROVIDER,
    providerReference: event.providerReference,
    amountMinor: event.amountMinor,
    currency: event.currency,
    rawEvent: event.rawEvent || req.body,
    providerEventId: event.eventId,
    eventType: event.eventType || 'payment.completed'
  });
  res.json({ received: true, payment: result });
}));

app.patch('/api/v1/admin/users/:userId/role', requireAuth, requireRole('admin'), asyncRoute(async (req, res) => {
  const role = textValue(req.body?.accountType,20);
  const allowed = new Set(['member','creator','artist','seller','company','manager']);
  if (!allowed.has(role)) return res.status(400).json({ error: 'Invalid or protected account type.' });
  if (req.params.userId === req.user.id) return res.status(400).json({ error: 'An administrator cannot change their own role.' });
  const result = await db.query('UPDATE users SET account_type=$1 WHERE id=$2 RETURNING id,email,account_type', [role,req.params.userId]);
  if (!result.rowCount) return res.status(404).json({ error: 'User not found.' });
  if (role === 'company') {
    const profile = await db.query('SELECT display_name FROM profiles WHERE user_id=$1', [req.params.userId]);
    await db.query('INSERT INTO company_profiles(user_id,company_name,contact_name) VALUES($1,$2,$2) ON CONFLICT(user_id) DO NOTHING', [req.params.userId,profile.rows[0]?.display_name || 'Company account']);
  }
  await audit(req.user.id, 'account_role_changed', 'user', req.params.userId, { accountType:role });
  res.json({ user:result.rows[0], message:'Role updated. The user should sign out and sign back in to refresh the interface.' });
}));

app.post('/api/v1/admin/vouchers', requireAuth, requireRole('admin'), asyncRoute(async (req, res) => {
  const result = await issueVoucher({ amount: req.body?.amount, currency: req.body?.currency || 'ZAR', expiresAt: req.body?.expiresAt || null, createdBy: req.user.id });
  await audit(req.user.id, 'voucher_issued', 'voucher', result.voucher.id, { amountMinor: result.voucher.amount_minor });
  res.status(201).json(result);
}));

app.get('/api/v1/admin/transactions', requireAuth, requireRole('admin','manager'), asyncRoute(async (_req, res) => {
  const result = await db.query(
    `SELECT id,reference,customer_id,amount_minor,currency,method,status,provider,provider_reference,created_at,paid_at
     FROM payment_transactions ORDER BY created_at DESC LIMIT 500`
  );
  res.json({ transactions: result.rows });
}));

app.post('/api/v1/admin/payouts', requireAuth, requireRole('admin','manager'), asyncRoute(async (req, res) => {
  const artistId = textValue(req.body?.artistId, 64);
  const amountMinor = minor(req.body?.amount);
  const payoutReference = textValue(req.body?.reference || reference('PAY'), 100);
  const result = await db.query(
    `INSERT INTO artist_payouts(artist_id,amount_minor,currency,reference,status,notes)
     VALUES($1,$2,$3,$4,'queued',$5) RETURNING *`,
    [artistId, amountMinor, req.body?.currency || 'ZAR', payoutReference, textValue(req.body?.notes, 1000)]
  );
  res.status(201).json({ payout: result.rows[0], message: 'Payout recorded as queued. No bank transfer has been sent.' });
}));

app.post('/api/v1/admin/payouts/:id/mark-paid', requireAuth, requireRole('admin'), asyncRoute(async (req, res) => {
  const providerReference = textValue(req.body?.providerReference, 120);
  if (!providerReference) return res.status(400).json({ error: 'A real provider/bank reference is required.' });
  const result = await db.query(
    `UPDATE artist_payouts SET status='paid',provider_reference=$1,paid_at=NOW()
     WHERE id=$2 AND status IN ('queued','processing') RETURNING *`, [providerReference, req.params.id]
  );
  if (!result.rowCount) return res.status(404).json({ error: 'Queued payout not found.' });
  await audit(req.user.id, 'payout_marked_paid', 'artist_payout', result.rows[0].id, { providerReference });
  res.json({ payout: result.rows[0], message: 'Payout record updated. This endpoint does not initiate a bank transfer.' });
}));

// --------------------------- Creator, artist and rights reporting ---------------------------
app.post('/api/v1/artist/apply', requireAuth, asyncRoute(async (req, res) => {
  const stageName = textValue(req.body?.stageName || req.user.display_name, 100);
  const genre = textValue(req.body?.genre, 80);
  const biography = textValue(req.body?.biography, 1200);
  if (stageName.length < 2) return res.status(400).json({ error: 'Artist or stage name is required.' });
  const result = await db.query(
    `INSERT INTO artist_profiles(user_id,stage_name,genre,biography)
     VALUES($1,$2,$3,$4) ON CONFLICT(user_id) DO UPDATE SET stage_name=EXCLUDED.stage_name,genre=EXCLUDED.genre,biography=EXCLUDED.biography
     RETURNING *`, [req.user.id, stageName, genre, biography]
  );
  await audit(req.user.id, 'artist_application_submitted', 'artist_profile', result.rows[0].id);
  res.status(201).json({ artistProfile: result.rows[0], message: 'Artist application submitted for review. Reporting is not activated automatically.' });
}));

app.get('/api/v1/artist/dashboard', requireAuth, asyncRoute(async (req, res) => {
  const sales = await db.query(
    `SELECT COUNT(DISTINCT o.id)::int AS order_count,COALESCE(SUM(oi.line_total_minor),0)::bigint AS gross_sales_minor
     FROM orders o JOIN order_items oi ON oi.order_id=o.id WHERE oi.seller_id=$1 AND o.state IN ('paid','fulfilled')`, [req.user.id]
  );
  const ledger = await db.query(
    `SELECT COALESCE(SUM(amount_minor),0)::bigint AS ledger_total_minor,COUNT(*)::int AS ledger_entries
     FROM ledger_entries WHERE owner_user_id=$1`, [req.user.id]
  );
  const royalties = await db.query(
    `SELECT p.display_name,pur.usage_type,pur.usage_count,pur.gross_amount_minor,pur.net_amount_minor,pur.currency,pur.amount_status,pur.usage_period_start,pur.usage_period_end
     FROM partner_usage_royalty_rows pur
     JOIN partner_report_deliveries d ON d.id=pur.delivery_id AND d.status='processed'
     JOIN reporting_partners p ON p.id=d.partner_id AND p.agreement_status='approved' AND p.endpoint_status='active' AND p.connection_verified=TRUE
     JOIN artist_partner_authorisations a ON a.artist_id=pur.artist_id AND a.partner_id=p.id AND a.status='active' AND a.revoked_at IS NULL AND (a.expires_at IS NULL OR a.expires_at>NOW())
     WHERE pur.artist_id=$1 AND pur.match_status='matched'
     ORDER BY pur.usage_period_end DESC NULLS LAST LIMIT 100`, [req.user.id]
  );
  const artistProfile = await db.query('SELECT * FROM artist_profiles WHERE user_id=$1', [req.user.id]);
  const payout = await db.query("SELECT COALESCE(SUM(amount_minor),0)::bigint AS queued_minor FROM artist_payouts WHERE artist_id=$1 AND status IN ('queued','processing')", [req.user.id]);
  res.json({
    artistProfile: artistProfile.rows[0] || null,
    sales: sales.rows[0],
    ledger: ledger.rows[0],
    queuedPayoutMinor: payout.rows[0].queued_minor,
    royaltyReports: royalties.rows,
    royaltyStatus: royalties.rowCount ? 'Authorised partner report rows available; reported amounts are not automatically proof of payment.' : 'Awaiting authorised report'
  });
}));

app.post('/api/v1/artists/me/evidence-uploads', requireAuth, requireRole('artist','creator'), asyncRoute(async (req, res) => {
  const evidenceType = textValue(req.body?.evidenceType,40);
  const contentType = textValue(req.body?.contentType,100).toLowerCase();
  const sizeBytes = Number(req.body?.sizeBytes);
  if (!EVIDENCE_TYPES.has(evidenceType)) return res.status(400).json({ error:'Choose identity, recording_rights or partner_authorisation evidence.' });
  if (!EVIDENCE_MIME_TYPES.has(contentType)) return res.status(400).json({ error:'Evidence must be a PDF, JPEG or PNG file.' });
  if (!Number.isSafeInteger(sizeBytes) || sizeBytes < 1 || sizeBytes > EVIDENCE_MAX_BYTES) return res.status(400).json({ error:'Evidence file must be between 1 byte and 10 MB.' });
  if (!privateStorage.storageConfig()) return res.status(503).json({ error:'Private S3-compatible storage is not configured. No evidence upload URL was issued.' });
  const id = crypto.randomUUID();
  const objectKey = `private/${evidencePrefix(evidenceType)}/${req.user.id}/${id}`;
  const expiresAt = new Date(Date.now()+10*60*1000);
  await db.query(
    `INSERT INTO private_evidence_uploads(id,owner_user_id,evidence_type,object_key,content_type,expected_size_bytes,status,expires_at)
     VALUES($1,$2,$3,$4,$5,$6,'pending',$7)`, [id,req.user.id,evidenceType,objectKey,contentType,sizeBytes,expiresAt]
  );
  await audit(req.user.id,'private_evidence_upload_intent_created','private_evidence_upload',id,{evidenceType,contentType,sizeBytes});
  res.status(201).json({ upload:{id,path:`/api/v1/artists/me/evidence-uploads/${id}/content`,method:'PUT',contentType,expiresAt:expiresAt.toISOString(),maxBytes:EVIDENCE_MAX_BYTES},message:'Upload the file through this authenticated API path, then call the completion endpoint. The evidence is not submitted for review until the private object is verified.' });
}));

app.put('/api/v1/artists/me/evidence-uploads/:id/content', requireAuth, requireRole('artist','creator'), express.raw({type:['application/pdf','image/jpeg','image/png'],limit:'10mb'}), asyncRoute(async (req,res) => {
  if (!Buffer.isBuffer(req.body)) return res.status(415).json({error:'Send a PDF, JPEG or PNG file as the raw request body.'});
  const client = await db.pool.connect();
  try {
    await client.query('BEGIN');
    const result = await client.query('SELECT * FROM private_evidence_uploads WHERE id=$1 AND owner_user_id=$2 FOR UPDATE',[req.params.id,req.user.id]);
    if (!result.rowCount) { await client.query('ROLLBACK'); return res.status(404).json({error:'Evidence upload was not found.'}); }
    const upload = result.rows[0];
    if (upload.status !== 'pending' || new Date(upload.expires_at) <= new Date()) { await client.query('ROLLBACK'); return res.status(410).json({error:'Evidence upload intent expired or is no longer pending.'}); }
    if (upload.uploaded_at) { await client.query('ROLLBACK'); return res.status(409).json({error:'Evidence bytes were already uploaded. Complete verification instead of uploading again.'}); }
    const contentType = String(req.get('content-type')||'').split(';')[0].trim().toLowerCase();
    if (contentType !== upload.content_type || req.body.length !== Number(upload.expected_size_bytes) || req.body.length > EVIDENCE_MAX_BYTES) { await client.query('ROLLBACK'); return res.status(400).json({error:'Uploaded file size or content type does not match the upload intent.'}); }
    const stored = await privateStorage.putObject(upload.object_key,req.body,contentType);
    await client.query('UPDATE private_evidence_uploads SET uploaded_at=NOW(),updated_at=NOW() WHERE id=$1 AND status=\'pending\'',[upload.id]);
    await client.query('COMMIT');
    await audit(req.user.id,'private_evidence_object_stored','private_evidence_upload',upload.id,{contentType,sizeBytes:req.body.length,payloadSha256:stored.payloadHash,etag:stored.etag||null});
    res.status(201).json({uploaded:true,uploadId:upload.id,message:'Evidence bytes were stored in the configured private bucket. Complete the upload to verify the object before submitting it.'});
  } catch(error) { await client.query('ROLLBACK'); throw error; }
  finally { client.release(); }
}));

app.post('/api/v1/artists/me/evidence-uploads/:id/complete', requireAuth, requireRole('artist','creator'), asyncRoute(async (req,res) => {
  const result = await db.query('SELECT * FROM private_evidence_uploads WHERE id=$1 AND owner_user_id=$2',[req.params.id,req.user.id]);
  if (!result.rowCount) return res.status(404).json({error:'Evidence upload was not found.'});
  const upload = result.rows[0];
  if (upload.status === 'uploaded' || upload.status === 'attached') return res.json({upload:{id:upload.id,status:upload.status,contentType:upload.content_type,sizeBytes:Number(upload.expected_size_bytes)},duplicate:true});
  if (upload.status !== 'pending' || new Date(upload.expires_at) <= new Date()) {
    await db.query("UPDATE private_evidence_uploads SET status='expired',updated_at=NOW() WHERE id=$1 AND status='pending'",[upload.id]);
    return res.status(410).json({error:'Evidence upload expired. Create a new upload intent.'});
  }
  if (!upload.uploaded_at) return res.status(409).json({error:'Upload the evidence file bytes before completing verification.'});
  const object = await privateStorage.headObject(upload.object_key);
  if (object.sizeBytes !== Number(upload.expected_size_bytes) || object.contentType !== upload.content_type || object.sizeBytes < 1 || object.sizeBytes > EVIDENCE_MAX_BYTES) {
    await db.query("UPDATE private_evidence_uploads SET status='rejected',updated_at=NOW() WHERE id=$1",[upload.id]);
    return res.status(400).json({error:'Uploaded evidence size or content type did not match the approved upload intent. The object was rejected.'});
  }
  const saved = await db.query("UPDATE private_evidence_uploads SET status='uploaded',last_verified_at=NOW(),updated_at=NOW() WHERE id=$1 AND status='pending' AND uploaded_at IS NOT NULL RETURNING id,status,content_type,expected_size_bytes,uploaded_at",[upload.id]);
  if (!saved.rowCount) return res.status(409).json({error:'Evidence upload changed while verification was running. Refresh the evidence queue and try again.'});
  await audit(req.user.id,'private_evidence_object_verified','private_evidence_upload',upload.id,{contentType:object.contentType,sizeBytes:object.sizeBytes,etag:object.etag||null});
  res.json({upload:{...saved.rows[0],sizeBytes:Number(saved.rows[0].expected_size_bytes)},message:'Private storage confirmed the uploaded object. It can now be attached to an identity, recording-rights or partner-authorisation submission.'});
}));

app.post('/api/v1/artists/me/identity-submissions', requireAuth, requireRole('artist','creator'), asyncRoute(async (req, res) => {
  const client = await db.pool.connect();
  try {
    await client.query('BEGIN');
    const upload = await attachPrivateEvidence(client,req.user.id,textValue(req.body?.evidenceUploadId,80),'identity');
    const result = await client.query(
      `INSERT INTO artist_identity_verifications(artist_id,evidence_storage_key,evidence_upload_id,status)
       VALUES($1,$2,$3,'pending') RETURNING id,status,created_at`, [req.user.id,upload.object_key,upload.id]
    );
    await client.query("UPDATE private_evidence_uploads SET status='attached',attached_at=NOW(),updated_at=NOW() WHERE id=$1",[upload.id]);
    await client.query('COMMIT');
    await audit(req.user.id,'artist_identity_submitted','artist_identity_verification',result.rows[0].id,{evidenceUploadId:upload.id});
    res.status(202).json({verification:result.rows[0],message:'Private identity evidence was attached and submitted for human review. This does not automatically verify identity.'});
  } catch(error) { await client.query('ROLLBACK'); throw error; }
  finally { client.release(); }
}));

app.post('/api/v1/artists/me/recordings', requireAuth, requireRole('artist','creator'), asyncRoute(async (req, res) => {
  const identity = await db.query("SELECT id FROM artist_identity_verifications WHERE artist_id=$1 AND status='verified' ORDER BY reviewed_at DESC NULLS LAST,created_at DESC LIMIT 1", [req.user.id]);
  if (!identity.rowCount) return res.status(403).json({ error: 'Identity must be verified before submitting recording ownership.' });
  const title = textValue(req.body?.title,200);
  const isrc = textValue(req.body?.isrc,12).toUpperCase();
  const role = textValue(req.body?.ownershipRole,80);
  const share = req.body?.ownershipShare == null ? null : Number(req.body.ownershipShare);
  if (title.length < 2 || !/^[A-Z]{2}[A-Z0-9]{3}\d{7}$/.test(isrc)) return res.status(400).json({ error: 'A track title and valid ISRC are required.' });
  if (share !== null && (!Number.isFinite(share) || share < 0 || share > 100)) return res.status(400).json({ error: 'Ownership share must be between 0 and 100.' });
  const client = await db.pool.connect();
  try {
    await client.query('BEGIN');
    const upload = await attachPrivateEvidence(client,req.user.id,textValue(req.body?.evidenceUploadId,80),'recording_rights');
    const result = await client.query(
      `INSERT INTO artist_recordings(artist_id,title,isrc,upc,iswc,ownership_role,ownership_share,evidence_storage_key,evidence_upload_id,verification_status)
       VALUES($1,$2,$3,NULLIF($4,''),NULLIF($5,''),NULLIF($6,''),$7,$8,$9,'pending') RETURNING id,title,isrc,verification_status,created_at`,
      [req.user.id,title,isrc,textValue(req.body?.upc,20),textValue(req.body?.iswc,20),role,share,upload.object_key,upload.id]
    );
    await client.query("UPDATE private_evidence_uploads SET status='attached',attached_at=NOW(),updated_at=NOW() WHERE id=$1",[upload.id]);
    await client.query('COMMIT');
    await audit(req.user.id,'recording_ownership_submitted','artist_recording',result.rows[0].id,{isrc,evidenceUploadId:upload.id});
    res.status(202).json({recording:result.rows[0],message:'Private recording-rights evidence was attached. Ownership remains pending until an administrator reviews it.'});
  } catch(error) { await client.query('ROLLBACK'); throw error; }
  finally { client.release(); }
}));

app.get('/api/v1/admin/evidence-uploads/:id/view', requireAuth, requireRole('admin'), asyncRoute(async (req,res) => {
  const result = await db.query("SELECT id,object_key,status,content_type FROM private_evidence_uploads WHERE id=$1 AND status='attached'",[req.params.id]);
  if (!result.rowCount) return res.status(404).json({error:'Attached private evidence was not found.'});
  const object = await privateStorage.headObject(result.rows[0].object_key);
  if (object.contentType !== result.rows[0].content_type || !Number.isSafeInteger(object.sizeBytes) || object.sizeBytes < 1 || object.sizeBytes > EVIDENCE_MAX_BYTES) return res.status(409).json({error:'Private evidence object no longer matches its verified upload metadata.'});
  const signed = privateStorage.createDownloadUrl(result.rows[0].object_key);
  await audit(req.user.id,'private_evidence_view_link_issued','private_evidence_upload',result.rows[0].id,{expiresAt:signed.expiresAt});
  res.json({url:signed.url,expiresAt:signed.expiresAt,contentType:object.contentType,sizeBytes:object.sizeBytes,message:'This private evidence link expires after 60 seconds. Do not share it.'});
}));

app.get('/api/v1/admin/identity-verifications', requireAuth, requireRole('admin'), asyncRoute(async (req, res) => {
  const status = textValue(req.query.status || 'pending',30);
  if (!['pending','verified','rejected','needs_resubmission','all'].includes(status)) return res.status(400).json({ error: 'Invalid status filter.' });
  const result = await db.query(
    `SELECT v.id,v.artist_id,v.evidence_storage_key,v.evidence_upload_id,v.status,v.created_at,v.reviewed_at,p.display_name,u.email
     FROM artist_identity_verifications v JOIN users u ON u.id=v.artist_id LEFT JOIN profiles p ON p.user_id=u.id
     WHERE ($1='all' OR v.status=$1) ORDER BY v.created_at ASC LIMIT 200`, [status]
  );
  res.json({ verifications: result.rows });
}));

app.get('/api/v1/admin/recording-ownership', requireAuth, requireRole('admin'), asyncRoute(async (req, res) => {
  const status = textValue(req.query.status || 'pending',30);
  if (!['pending','verified','rejected','disputed','all'].includes(status)) return res.status(400).json({ error: 'Invalid status filter.' });
  const result = await db.query(
    `SELECT r.id,r.artist_id,r.title,r.isrc,r.ownership_role,r.ownership_share,r.evidence_storage_key,r.evidence_upload_id,r.verification_status,r.created_at,p.display_name,u.email
     FROM artist_recordings r JOIN users u ON u.id=r.artist_id LEFT JOIN profiles p ON p.user_id=u.id
     WHERE ($1='all' OR r.verification_status=$1) ORDER BY r.created_at ASC LIMIT 300`, [status]
  );
  res.json({ recordings: result.rows });
}));

app.patch('/api/v1/admin/artists/:artistId/identity-verifications/:verificationId', requireAuth, requireRole('admin'), asyncRoute(async (req, res) => {
  const status = textValue(req.body?.status,30);
  if (!['verified','rejected','needs_resubmission'].includes(status)) return res.status(400).json({ error: 'Invalid identity review decision.' });
  const evidence = await db.query(
    `SELECT v.evidence_upload_id,u.object_key,u.content_type,u.status AS upload_status
     FROM artist_identity_verifications v LEFT JOIN private_evidence_uploads u ON u.id=v.evidence_upload_id
     WHERE v.id=$1 AND v.artist_id=$2`, [req.params.verificationId,req.params.artistId]
  );
  if (!evidence.rowCount) return res.status(404).json({ error: 'Identity verification record not found.' });
  if (!evidence.rows[0].evidence_upload_id || evidence.rows[0].upload_status !== 'attached') return res.status(409).json({error:'Identity evidence must be uploaded to private storage and attached before review.'});
  const object = await privateStorage.headObject(evidence.rows[0].object_key);
  if (object.contentType !== evidence.rows[0].content_type || !Number.isSafeInteger(object.sizeBytes) || object.sizeBytes < 1 || object.sizeBytes > EVIDENCE_MAX_BYTES) return res.status(409).json({error:'Identity evidence object failed private storage verification.'});
  const result = await db.query(
    `UPDATE artist_identity_verifications SET status=$1,reviewed_by=$2,reviewed_at=NOW(),review_notes=$3,updated_at=NOW()
     WHERE id=$4 AND artist_id=$5 RETURNING id,artist_id,status,reviewed_at`,
    [status,req.user.id,textValue(req.body?.notes,1500),req.params.verificationId,req.params.artistId]
  );
  if (!result.rowCount) return res.status(404).json({ error: 'Identity verification record not found.' });
  await audit(req.user.id, 'artist_identity_reviewed', 'artist_identity_verification', result.rows[0].id, { status, artistId: req.params.artistId });
  res.json({ verification: result.rows[0] });
}));

app.patch('/api/v1/admin/recordings/:recordingId/ownership', requireAuth, requireRole('admin'), asyncRoute(async (req, res) => {
  const status = textValue(req.body?.status,30);
  if (!['verified','rejected','disputed'].includes(status)) return res.status(400).json({ error: 'Invalid ownership decision.' });
  const evidence = await db.query(
    `SELECT r.evidence_upload_id,u.object_key,u.content_type,u.status AS upload_status
     FROM artist_recordings r LEFT JOIN private_evidence_uploads u ON u.id=r.evidence_upload_id WHERE r.id=$1`,[req.params.recordingId]
  );
  if (!evidence.rowCount) return res.status(404).json({ error: 'Recording claim not found.' });
  if (!evidence.rows[0].evidence_upload_id || evidence.rows[0].upload_status !== 'attached') return res.status(409).json({error:'Recording-rights evidence must be uploaded to private storage and attached before review.'});
  const object = await privateStorage.headObject(evidence.rows[0].object_key);
  if (object.contentType !== evidence.rows[0].content_type || !Number.isSafeInteger(object.sizeBytes) || object.sizeBytes < 1 || object.sizeBytes > EVIDENCE_MAX_BYTES) return res.status(409).json({error:'Recording-rights evidence object failed private storage verification.'});
  const result = await db.query('UPDATE artist_recordings SET verification_status=$1 WHERE id=$2 RETURNING id,artist_id,isrc,verification_status', [status,req.params.recordingId]);
  await audit(req.user.id, 'recording_ownership_reviewed', 'artist_recording', result.rows[0].id, { status, isrc: result.rows[0].isrc });
  res.json({ recording: result.rows[0] });
}));

app.get('/api/v1/partners/status', requireAuth, asyncRoute(async (req, res) => {
  const result = await db.query(
    `SELECT p.code,p.display_name AS name,p.partner_type,p.agreement_status,p.endpoint_status,
       COALESCE(a.status,'not_authorised') AS artist_authorisation_status,
       COALESCE(ea.status,'not_authorised') AS external_authorisation_status,ea.authorisation_method AS external_authorisation_method,ea.expires_at AS external_authorisation_expires_at,
       p.connection_verified
     FROM reporting_partners p
     LEFT JOIN artist_partner_authorisations a ON a.partner_id=p.id AND a.artist_id=$1
     LEFT JOIN artist_partner_external_authorisations ea ON ea.partner_id=p.id AND ea.artist_id=$1
     ORDER BY p.display_name`, [req.user.id]
  );
  res.json({ partners: result.rows });
}));

const CONSENT_VERSION = '2026-11-08-v1';
const CONSENT_TEXT = 'I authorise APPRECIATE to submit reporting and statement requests to this named partner on my behalf, only for the selected scopes and only where the partner has approved the route. I understand that this consent does not itself grant APPRECIATE partner access or guarantee a report. I may revoke this permission at any time.';

app.post('/api/v1/partners/:code/authorisations', requireAuth, requireRole('artist','creator'), asyncRoute(async (req, res) => {
  if (req.body?.consentConfirmed !== true) return res.status(400).json({ error: 'Explicit consent confirmation is required.' });
  const identity = await db.query("SELECT id FROM artist_identity_verifications WHERE artist_id=$1 AND status='verified' ORDER BY reviewed_at DESC NULLS LAST,created_at DESC LIMIT 1", [req.user.id]);
  if (!identity.rowCount) return res.status(403).json({ error: 'Identity must be verified before partner consent can be recorded.' });
  const partner = await db.query('SELECT id,display_name FROM reporting_partners WHERE code=$1', [req.params.code]);
  if (!partner.rowCount) return res.status(404).json({ error: 'Partner is not in the directory.' });
  const scopes = Array.isArray(req.body?.scope) ? [...new Set(req.body.scope.map((x) => textValue(x,80)).filter(Boolean))].slice(0,20) : [];
  if (!scopes.length) return res.status(400).json({ error: 'Select at least one reporting scope.' });
  const consentHash = crypto.createHash('sha256').update(`${CONSENT_VERSION}\n${CONSENT_TEXT}\n${req.params.code}\n${scopes.join(',')}`).digest('hex');
  const ipHash = crypto.createHash('sha256').update(`${process.env.APP_SECRET}:${req.ip || 'unknown'}`).digest('hex');
  const client = await db.pool.connect();
  try {
    await client.query('BEGIN');
    const previous = await client.query('SELECT id,status FROM artist_partner_authorisations WHERE artist_id=$1 AND partner_id=$2 FOR UPDATE', [req.user.id, partner.rows[0].id]);
    const result = await client.query(
      `INSERT INTO artist_partner_authorisations(artist_id,partner_id,scope,authorisation_method,status,consent_version,consent_text,consent_sha256,consent_granted_at,consent_ip_hash,granted_at,revoked_at)
       VALUES($1,$2,$3,'appreciate_consent','active',$4,$5,$6,NOW(),$7,NOW(),NULL)
       ON CONFLICT(artist_id,partner_id) DO UPDATE SET scope=EXCLUDED.scope,authorisation_method=EXCLUDED.authorisation_method,status='active',consent_version=EXCLUDED.consent_version,consent_text=EXCLUDED.consent_text,consent_sha256=EXCLUDED.consent_sha256,consent_granted_at=NOW(),consent_ip_hash=EXCLUDED.consent_ip_hash,granted_at=NOW(),revoked_at=NULL,updated_at=NOW()
       RETURNING *`, [req.user.id, partner.rows[0].id, scopes, CONSENT_VERSION, CONSENT_TEXT, consentHash, ipHash]
    );
    await client.query(
      `INSERT INTO artist_partner_authorisation_events(authorisation_id,artist_id,partner_id,event_type,scope,consent_version,consent_sha256,method,ip_hash)
       VALUES($1,$2,$3,$4,$5,$6,$7,'appreciate_consent',$8)`,
      [result.rows[0].id, req.user.id, partner.rows[0].id, previous.rowCount ? 'consent_updated' : 'consent_granted', scopes, CONSENT_VERSION, consentHash, ipHash]
    );
    await client.query('COMMIT');
    await audit(req.user.id, 'partner_consent_recorded', 'artist_partner_authorisation', result.rows[0].id, { partner: req.params.code, scopes, consentVersion: CONSENT_VERSION });
    res.status(201).json({ authorisation: { id: result.rows[0].id, status: result.rows[0].status, scope: result.rows[0].scope, consentVersion: CONSENT_VERSION, consentGrantedAt: result.rows[0].consent_granted_at }, message: 'Your APPRECIATE consent is recorded. This is not proof of approval by the external partner or a live data connection.' });
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally { client.release(); }
}));

app.delete('/api/v1/partners/:code/authorisations', requireAuth, requireRole('artist','creator'), asyncRoute(async (req, res) => {
  const partner = await db.query('SELECT id FROM reporting_partners WHERE code=$1', [req.params.code]);
  if (!partner.rowCount) return res.status(404).json({ error: 'Partner is not in the directory.' });
  const client = await db.pool.connect();
  try {
    await client.query('BEGIN');
    const result = await client.query(
      `UPDATE artist_partner_authorisations SET status='revoked',revoked_at=NOW(),updated_at=NOW()
       WHERE artist_id=$1 AND partner_id=$2 AND status='active' RETURNING id,scope,consent_version,consent_sha256`, [req.user.id, partner.rows[0].id]
    );
    if (result.rowCount) {
      await client.query(
        `INSERT INTO artist_partner_authorisation_events(authorisation_id,artist_id,partner_id,event_type,scope,consent_version,consent_sha256,method)
         VALUES($1,$2,$3,'consent_revoked',$4,$5,$6,'artist_revocation')`,
        [result.rows[0].id, req.user.id, partner.rows[0].id, result.rows[0].scope, result.rows[0].consent_version || CONSENT_VERSION, result.rows[0].consent_sha256 || 'revoked']
      );
    }
    await client.query('COMMIT');
    if (result.rowCount) await audit(req.user.id, 'partner_consent_revoked', 'artist_partner_authorisation', result.rows[0].id, { partner: req.params.code });
    res.json({ revoked: result.rowCount === 1, message: result.rowCount ? 'APPRECIATE consent revoked. New report rows will no longer be attributed to this account.' : 'No active consent was found for this partner.' });
  } catch (error) { await client.query('ROLLBACK'); throw error; }
  finally { client.release(); }
}));


app.post('/api/v1/partners/:code/external-authorisations', requireAuth, requireRole('artist','creator'), asyncRoute(async (req, res) => {
  const code = textValue(req.params.code,80).toLowerCase();
  const method = textValue(req.body?.method,40);
  const externalReference = textValue(req.body?.externalAuthorisationReference,200);
  const accountRef = textValue(req.body?.externalAccountRef,200);
  const scopes = Array.isArray(req.body?.scope) ? [...new Set(req.body.scope.map((x) => textValue(x,80)).filter(Boolean))].slice(0,20) : [];
  if (!scopes.length || scopes.some((scope) => !ALLOWED_REPORT_SCOPES.has(scope))) return res.status(400).json({ error: 'Select at least one supported reporting scope.' });
  if (!ALLOWED_EXTERNAL_METHODS.has(method)) return res.status(400).json({ error: 'Choose a recognised external partner authorisation method.' });
  if (!externalReference || externalReference.length < 3) return res.status(400).json({ error: 'A partner-issued authorisation or mandate reference is required.' });
  const partner = await db.query('SELECT id FROM reporting_partners WHERE code=$1',[code]);
  if (!partner.rowCount) return res.status(404).json({ error: 'Partner is not in the directory.' });
  const identity = await db.query("SELECT id FROM artist_identity_verifications WHERE artist_id=$1 AND status='verified' ORDER BY reviewed_at DESC NULLS LAST,created_at DESC LIMIT 1",[req.user.id]);
  if (!identity.rowCount) return res.status(403).json({ error: 'Identity verification is required before submitting an external partner mandate.' });
  const consent = await db.query("SELECT id FROM artist_partner_authorisations WHERE artist_id=$1 AND partner_id=$2 AND status='active' AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at>NOW())",[req.user.id,partner.rows[0].id]);
  if (!consent.rowCount) return res.status(403).json({ error: 'Record APPRECIATE consent for this partner before submitting the separate external authorisation.' });
  const expiry = req.body?.expiresAt ? new Date(req.body.expiresAt) : null;
  if (expiry && (!Number.isFinite(expiry.getTime()) || expiry <= new Date())) return res.status(400).json({ error: 'External authorisation expiry must be a future date.' });
  const client = await db.pool.connect();
  try {
    await client.query('BEGIN');
    const upload = await attachPrivateEvidence(client,req.user.id,textValue(req.body?.evidenceUploadId,80),'partner_authorisation');
    const saved = await client.query(
      `INSERT INTO artist_partner_external_authorisations(artist_id,partner_id,authorisation_method,status,external_account_ref,external_authorisation_reference,external_scope,evidence_storage_key,evidence_upload_id,expires_at)
       VALUES($1,$2,$3,'pending',NULLIF($4,''),$5,$6,$7,$8,$9)
       ON CONFLICT(artist_id,partner_id) DO UPDATE SET authorisation_method=EXCLUDED.authorisation_method,status='pending',external_account_ref=EXCLUDED.external_account_ref,external_authorisation_reference=EXCLUDED.external_authorisation_reference,external_scope=EXCLUDED.external_scope,evidence_storage_key=EXCLUDED.evidence_storage_key,evidence_upload_id=EXCLUDED.evidence_upload_id,submitted_at=NOW(),verified_by=NULL,verified_at=NULL,expires_at=EXCLUDED.expires_at,review_notes=NULL,updated_at=NOW()
       RETURNING id,status,authorisation_method,external_authorisation_reference,submitted_at`,
      [req.user.id,partner.rows[0].id,method,accountRef,externalReference,scopes,upload.object_key,upload.id,expiry]
    );
    await client.query("UPDATE private_evidence_uploads SET status='attached',attached_at=NOW(),updated_at=NOW() WHERE id=$1",[upload.id]);
    await client.query(
      `INSERT INTO artist_partner_external_authorisation_events(external_authorisation_id,artist_id,partner_id,event_type,actor_user_id,details)
       VALUES($1,$2,$3,'submitted',$2,$4::jsonb)`,
      [saved.rows[0].id,req.user.id,partner.rows[0].id,JSON.stringify({method,scope:scopes,reference:externalReference,evidenceUploadId:upload.id})]
    );
    await client.query('COMMIT');
    await audit(req.user.id,'external_partner_authorisation_submitted','artist_partner_external_authorisation',saved.rows[0].id,{partnerCode:code,method,scope:scopes,evidenceUploadId:upload.id});
    res.status(202).json({externalAuthorisation:saved.rows[0],message:'Verified private evidence was attached. The external partner mandate remains pending until a human reviewer confirms the partner-issued document.'});
  } catch(error) { await client.query('ROLLBACK'); throw error; }
  finally { client.release(); }
}));

app.get('/api/v1/admin/partner-external-authorisations', requireAuth, requireRole('admin'), asyncRoute(async (req,res) => {
  const status = textValue(req.query.status || 'pending',30);
  if (!['pending','verified','rejected','expired','action_required','all'].includes(status)) return res.status(400).json({error:'Invalid external mandate status filter.'});
  const result = await db.query(
    `SELECT ea.id,ea.artist_id,ea.external_authorisation_reference,ea.authorisation_method,ea.external_scope,ea.status,ea.evidence_upload_id,ea.submitted_at,ea.expires_at,
       rp.display_name AS artist_name,u.email,p.code AS partner_code,p.display_name AS partner_name
     FROM artist_partner_external_authorisations ea JOIN reporting_partners p ON p.id=ea.partner_id
     JOIN users u ON u.id=ea.artist_id LEFT JOIN profiles rp ON rp.user_id=ea.artist_id
     WHERE ($1='all' OR ea.status=$1) ORDER BY ea.submitted_at ASC LIMIT 200`,[status]
  );
  res.json({authorisations:result.rows});
}));

app.patch('/api/v1/admin/partners/:code/external-authorisations/:artistId', requireAuth, requireRole('admin'), asyncRoute(async (req, res) => {
  const code = textValue(req.params.code,80).toLowerCase();
  const status = textValue(req.body?.status,30);
  if (!['verified','rejected','expired','action_required'].includes(status)) return res.status(400).json({ error:'Invalid external authorisation review decision.' });
  const partner = await db.query('SELECT id FROM reporting_partners WHERE code=$1',[code]);
  if (!partner.rowCount) return res.status(404).json({ error:'Partner not found.' });
  const evidence = await db.query(
    `SELECT ea.evidence_upload_id,u.object_key,u.content_type,u.status AS upload_status
     FROM artist_partner_external_authorisations ea LEFT JOIN private_evidence_uploads u ON u.id=ea.evidence_upload_id
     WHERE ea.artist_id=$1 AND ea.partner_id=$2`,[req.params.artistId,partner.rows[0].id]
  );
  if (!evidence.rowCount || !evidence.rows[0].evidence_upload_id || evidence.rows[0].upload_status !== 'attached') return res.status(409).json({error:'External partner mandate evidence must be uploaded to private storage and attached before review.'});
  const object = await privateStorage.headObject(evidence.rows[0].object_key);
  if (object.contentType !== evidence.rows[0].content_type || !Number.isSafeInteger(object.sizeBytes) || object.sizeBytes < 1 || object.sizeBytes > EVIDENCE_MAX_BYTES) return res.status(409).json({error:'External mandate evidence object failed private storage verification.'});
  const client = await db.pool.connect();
  try {
    await client.query('BEGIN');
    const saved = await client.query(
      `UPDATE artist_partner_external_authorisations SET status=$1,verified_by=CASE WHEN $1='verified' THEN $2 ELSE NULL END,verified_at=CASE WHEN $1='verified' THEN NOW() ELSE NULL END,review_notes=$3,updated_at=NOW()
       WHERE artist_id=$4 AND partner_id=$5 AND evidence_upload_id=$6 AND external_authorisation_reference IS NOT NULL
       RETURNING id,artist_id,partner_id,status,authorisation_method,external_authorisation_reference,verified_by,verified_at,expires_at`,
      [status,req.user.id,textValue(req.body?.notes,1500),req.params.artistId,partner.rows[0].id,evidence.rows[0].evidence_upload_id]
    );
    if (!saved.rowCount) { await client.query('ROLLBACK'); return res.status(404).json({error:'External authorisation submission not found.'}); }
    await client.query(
      `INSERT INTO artist_partner_external_authorisation_events(external_authorisation_id,artist_id,partner_id,event_type,actor_user_id,details)
       VALUES($1,$2,$3,$4,$5,$6::jsonb)`,
      [saved.rows[0].id,saved.rows[0].artist_id,saved.rows[0].partner_id,status,req.user.id,JSON.stringify({notes:textValue(req.body?.notes,1500)})]
    );
    await client.query('COMMIT');
    await audit(req.user.id,'external_partner_authorisation_reviewed','artist_partner_external_authorisation',saved.rows[0].id,{status,partnerCode:code,artistId:req.params.artistId});
    res.json({externalAuthorisation:saved.rows[0],message:status==='verified'?'External partner mandate marked verified after administrator evidence review.':'External partner mandate review status updated.'});
  } catch (error) { await client.query('ROLLBACK'); throw error; }
  finally { client.release(); }
}));

app.patch('/api/v1/admin/partners/:code/status', requireAuth, requireRole('admin'), asyncRoute(async (req, res) => {
  const agreementStatus = textValue(req.body?.agreementStatus,30);
  const endpointStatus = textValue(req.body?.endpointStatus,30);
  const validAgreement = new Set(['not_contacted','contacted','under_review','approved','rejected','suspended']);
  const validEndpoint = new Set(['not_configured','testing','paused','failed']);
  if (!validAgreement.has(agreementStatus) || !validEndpoint.has(endpointStatus) || req.body?.connectionVerified === true) {
    return res.status(409).json({ error: 'Administrators may record contact/agreement status, but cannot manually mark a partner connection active or verified. A provider-specific live adapter test is required.' });
  }
  const result = await db.query(
    `UPDATE reporting_partners SET agreement_status=$1,endpoint_status=$2,connection_verified=FALSE,
       connection_test_reference=NULL,connection_tested_at=NULL,connection_tested_by=NULL,updated_at=NOW()
     WHERE code=$3 RETURNING *`, [agreementStatus,endpointStatus,req.params.code]
  );
  if (!result.rowCount) return res.status(404).json({ error: 'Partner not found.' });
  await audit(req.user.id, 'partner_agreement_status_updated', 'reporting_partner', result.rows[0].id, { agreementStatus,endpointStatus,connectionVerified:false });
  res.json({ partner: result.rows[0], message: 'Partner status saved. Connection remains inactive until a provider-specific live test succeeds.' });
}));

app.post('/api/v1/admin/partners/:code/test-connection', requireAuth, requireRole('admin'), asyncRoute(async (req, res) => {
  const code = textValue(req.params.code,80).toLowerCase();
  const partner = await db.query('SELECT id,code,display_name,agreement_status FROM reporting_partners WHERE code=$1', [code]);
  if (!partner.rowCount) return res.status(404).json({ error: 'Partner not found.' });
  if (partner.rows[0].agreement_status !== 'approved') return res.status(409).json({ error: 'A real partner agreement must be approved before testing a reporting connection.' });
  let test;
  try { test = await partnerConnectors.testConnection(code, { partner: partner.rows[0] }); }
  catch (_error) { return res.status(502).json({ error: 'The provider-specific connection test failed. The partner remains inactive.' }); }
  if (!test.ok) return res.status(503).json({ error: test.reason, connectionVerified: false });
  const testReference = `${test.providerApprovalReference}:${test.externalTestReference}`.slice(0,200);
  const updated = await db.query(
    `UPDATE reporting_partners SET endpoint_status='active',connection_verified=TRUE,connection_test_reference=$1,connection_tested_at=NOW(),connection_tested_by=$2,updated_at=NOW()
     WHERE id=$3 AND agreement_status='approved' RETURNING id,code,display_name,agreement_status,endpoint_status,connection_verified,connection_test_reference,connection_tested_at`,
    [testReference,req.user.id,partner.rows[0].id]
  );
  await audit(req.user.id, 'partner_live_connection_test_passed', 'reporting_partner', partner.rows[0].id, { providerApprovalReference:test.providerApprovalReference, externalTestReference:test.externalTestReference, responseSha256:test.responseSha256 });
  res.json({ partner: updated.rows[0], message: 'Provider-specific connection test passed. This does not mean any artist report has been received.' });
}));

app.patch('/api/v1/admin/partners/:code/authorisations/:artistId', requireAuth, requireRole('admin'), asyncRoute(async (req, res) => {
  const status = textValue(req.body?.status,30);
  if (!['expired','rejected','action_required'].includes(status)) return res.status(400).json({ error: 'Administrators may flag or reject consent, but only the artist can grant or revoke it.' });
  const partner = await db.query('SELECT id FROM reporting_partners WHERE code=$1', [req.params.code]);
  if (!partner.rowCount) return res.status(404).json({ error: 'Partner not found.' });
  const evidence = textValue(req.body?.evidenceStorageKey,500);
  const externalRef = textValue(req.body?.externalAccountRef,200);
  const result = await db.query(
    `UPDATE artist_partner_authorisations SET status=$1,evidence_storage_key=COALESCE(NULLIF($2,''),evidence_storage_key),external_account_ref=COALESCE(NULLIF($3,''),external_account_ref),updated_at=NOW()
     WHERE partner_id=$4 AND artist_id=$5 RETURNING *`,
    [status,evidence,externalRef,partner.rows[0].id,req.params.artistId]
  );
  if (!result.rowCount) return res.status(404).json({ error: 'Artist authorisation request not found.' });
  await db.query(
    `INSERT INTO artist_partner_authorisation_events(authorisation_id,artist_id,partner_id,event_type,scope,consent_version,consent_sha256,method)
     VALUES($1,$2,$3,$4,$5,$6,$7,'admin_review')`,
    [result.rows[0].id,req.params.artistId,partner.rows[0].id,status === 'rejected' ? 'admin_rejected' : 'admin_flagged',result.rows[0].scope,result.rows[0].consent_version || CONSENT_VERSION,result.rows[0].consent_sha256 || 'legacy']
  );
  await audit(req.user.id, 'artist_partner_authorisation_reviewed', 'artist_partner_authorisation', result.rows[0].id, { status });
  res.json({ authorisation: result.rows[0] });
}));

app.post('/api/v1/partners/requests/all', requireAuth, requireRole('artist','creator'), asyncRoute(async (req, res) => {
  const identity = await db.query("SELECT id FROM artist_identity_verifications WHERE artist_id=$1 AND status='verified' ORDER BY reviewed_at DESC NULLS LAST,created_at DESC LIMIT 1", [req.user.id]);
  if (!identity.rowCount) return res.status(403).json({ error: 'Identity verification is required before requesting reports.' });
  const catalogue = await db.query("SELECT COUNT(*)::int AS n FROM artist_recordings WHERE artist_id=$1 AND verification_status='verified'", [req.user.id]);
  if (!catalogue.rows[0].n) return res.status(403).json({ error: 'At least one verified recording is required before requesting reports.' });
  const today = new Date();
  const firstThisMonth = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), 1));
  const endPreviousMonth = new Date(firstThisMonth.getTime() - 86400000);
  const defaultStart = new Date(Date.UTC(endPreviousMonth.getUTCFullYear(), endPreviousMonth.getUTCMonth(), 1)).toISOString().slice(0,10);
  const defaultEnd = endPreviousMonth.toISOString().slice(0,10);
  const periodStart = String(req.body?.periodStart || defaultStart).trim();
  const periodEnd = String(req.body?.periodEnd || defaultEnd).trim();
  if (!isValidDate(periodStart) || !isValidDate(periodEnd) || periodStart > periodEnd) return res.status(400).json({ error: 'Provide a valid reporting period.' });
  const partners = await db.query(
    `SELECT p.id,p.code,p.display_name,a.id AS authorisation_id,a.scope AS consent_scope,ea.external_scope AS external_authorisation_scope,ea.authorisation_method AS external_authorisation_method,ea.external_authorisation_reference,ea.evidence_storage_key AS external_authorisation_evidence,ea.verified_at AS external_authorisation_verified_at,ea.expires_at AS external_authorisation_expires_at FROM reporting_partners p
     JOIN artist_partner_authorisations a ON a.partner_id=p.id AND a.artist_id=$1 AND a.status='active' AND a.revoked_at IS NULL AND (a.expires_at IS NULL OR a.expires_at>NOW())
     JOIN artist_partner_external_authorisations ea ON ea.partner_id=p.id AND ea.artist_id=$1 AND ea.status='verified' AND ea.verified_at IS NOT NULL AND ea.external_authorisation_reference IS NOT NULL AND (ea.expires_at IS NULL OR ea.expires_at>NOW())
     WHERE p.agreement_status='approved' AND p.endpoint_status='active' AND p.connection_verified=TRUE
       AND p.connection_test_reference IS NOT NULL AND p.connection_tested_at IS NOT NULL
     ORDER BY p.display_name`, [req.user.id]
  );
  const batch = reference('REPORT-BATCH');
  const recordings = await db.query("SELECT id,title,isrc,ownership_role,ownership_share FROM artist_recordings WHERE artist_id=$1 AND verification_status='verified' ORDER BY title", [req.user.id]);
  const created = [];
  let submittedCount = 0;
  for (const partner of partners.rows) {
    const row = await db.query(
      `INSERT INTO artist_reporting_requests(artist_id,partner_id,status,notes,reporting_period_start,reporting_period_end,batch_reference,dispatch_status)
       VALUES($1,$2,'ready',$3,$4,$5,$6,'prepared')
       ON CONFLICT (artist_id,partner_id,reporting_period_start,reporting_period_end) WHERE reporting_period_start IS NOT NULL AND reporting_period_end IS NOT NULL
       DO NOTHING RETURNING id,partner_id,status,dispatch_status`,
      [req.user.id, partner.id, 'Request created; dispatch is permitted only through the installed partner-specific adapter.', periodStart, periodEnd, batch]
    );
    if (!row.rowCount) continue;
    let dispatch;
    try {
      dispatch = await partnerConnectors.requestReport(partner.code, {
        artistId:req.user.id,partnerCode:partner.code,consentRecordId:partner.authorisation_id,
        externalAuthorisation:{status:'verified',authorisation_method:partner.external_authorisation_method,external_authorisation_reference:partner.external_authorisation_reference,evidence_storage_key:partner.external_authorisation_evidence,external_scope:partner.external_authorisation_scope || [],verified_at:partner.external_authorisation_verified_at,expires_at:partner.external_authorisation_expires_at},
        scopes:(partner.consent_scope || []).filter((scope) => (partner.external_authorisation_scope || []).includes(scope)),reportingPeriod:{start:periodStart,end:periodEnd},recordings:recordings.rows
      });
    } catch (_error) { dispatch = {ok:false,dispatchStatus:'failed',reason:'Provider adapter call failed. No acknowledgement was recorded.'}; }
    const dispatchStatus = dispatch.ok ? 'submitted' : (dispatch.dispatchStatus || 'failed');
    const requestStatus = dispatch.ok ? 'submitted' : 'follow_up_due';
    await db.query(
      `UPDATE artist_reporting_requests SET status=$1,dispatch_status=$2,external_case_ref=$3,submitted_at=CASE WHEN $2='submitted' THEN NOW() ELSE submitted_at END,notes=$4,updated_at=NOW() WHERE id=$5`,
      [requestStatus,dispatchStatus,dispatch.externalRequestReference || null,dispatch.ok ? 'Provider acknowledged the one-off request.' : dispatch.reason || 'Provider request was not dispatched.',row.rows[0].id]
    );
    if (dispatch.ok) submittedCount++;
    created.push({requestId:row.rows[0].id,partnerCode:partner.code,partnerName:partner.display_name,dispatchStatus,externalRequestReference:dispatch.externalRequestReference || null});
  }
  const all = await db.query('SELECT COUNT(*)::int AS total FROM reporting_partners');
  const notDispatchedCount = created.length - submittedCount;
  const response = {
    batchReference: batch, periodStart, periodEnd, preparedCount: created.length, submittedCount, notDispatchedCount,
    blockedCount: Math.max(0, Number(all.rows[0].total) - created.length), requests: created,
    message: submittedCount
      ? `${submittedCount} provider request(s) were acknowledged. Acknowledgement is not proof that a royalty statement has arrived.`
      : created.length
        ? 'Requests were recorded, but none was dispatched. Provider-specific adapters are missing or failed.'
        : 'No partner currently meets the external agreement, tested connection and artist-consent requirements. No external report was requested.'
  };
  await audit(req.user.id, 'all_partner_report_requests_processed', 'report_batch', batch, { preparedCount: response.preparedCount, submittedCount, notDispatchedCount, blockedCount: response.blockedCount, periodStart, periodEnd });
  res.status(201).json(response);
}));

app.post('/api/v1/partners/:code/request', requireAuth, requireRole('artist','creator'), asyncRoute(async (req, res) => {
  const partner = await db.query(
    `SELECT p.id,p.display_name,p.agreement_status,p.endpoint_status,p.connection_verified,p.connection_test_reference,
       a.id AS authorisation_id,a.scope AS consent_scope,a.status AS consent_status,a.expires_at,a.revoked_at,
       ea.status AS external_authorisation_status,ea.external_scope AS external_authorisation_scope,ea.authorisation_method AS external_authorisation_method,ea.external_authorisation_reference,ea.evidence_storage_key AS external_authorisation_evidence,ea.verified_at AS external_authorisation_verified_at,ea.expires_at AS external_authorisation_expires_at
     FROM reporting_partners p LEFT JOIN artist_partner_authorisations a ON a.partner_id=p.id AND a.artist_id=$1
     LEFT JOIN artist_partner_external_authorisations ea ON ea.partner_id=p.id AND ea.artist_id=$1
     WHERE p.code=$2`, [req.user.id, req.params.code]
  );
  if (!partner.rowCount) return res.status(404).json({ error: 'Partner is not in the directory.' });
  const p = partner.rows[0];
  if (p.agreement_status !== 'approved' || p.endpoint_status !== 'active' || !p.connection_verified || !p.connection_test_reference || p.consent_status !== 'active' || p.revoked_at || (p.expires_at && new Date(p.expires_at) <= new Date()) || !isCurrentExternalAuthorisation({status:p.external_authorisation_status,authorisation_method:p.external_authorisation_method,external_authorisation_reference:p.external_authorisation_reference,evidence_storage_key:p.external_authorisation_evidence,external_scope:p.external_authorisation_scope || [],verified_at:p.external_authorisation_verified_at,expires_at:p.external_authorisation_expires_at})) {
    return res.status(409).json({ error: 'This partner is not ready for a report request. External approval, a tested connection and active artist consent are all required.' });
  }
  const identity = await db.query("SELECT 1 FROM artist_identity_verifications WHERE artist_id=$1 AND status='verified' LIMIT 1", [req.user.id]);
  const catalogue = await db.query("SELECT 1 FROM artist_recordings WHERE artist_id=$1 AND verification_status='verified' LIMIT 1", [req.user.id]);
  if (!identity.rowCount || !catalogue.rowCount) return res.status(403).json({ error: 'Verified artist identity and at least one verified recording are required.' });
  const today = new Date(); const first = new Date(Date.UTC(today.getUTCFullYear(),today.getUTCMonth(),1)); const prev = new Date(first.getTime()-86400000);
  const defaultStart = new Date(Date.UTC(prev.getUTCFullYear(),prev.getUTCMonth(),1)).toISOString().slice(0,10);
  const defaultEnd = prev.toISOString().slice(0,10);
  const periodStart = String(req.body?.periodStart || defaultStart).trim(); const periodEnd = String(req.body?.periodEnd || defaultEnd).trim();
  if (!isValidDate(periodStart) || !isValidDate(periodEnd) || periodStart > periodEnd) return res.status(400).json({ error: 'Provide a valid reporting period.' });
  const result = await db.query(
    `INSERT INTO artist_reporting_requests(artist_id,partner_id,status,notes,reporting_period_start,reporting_period_end,dispatch_status)
     VALUES($1,$2,'ready',$3,$4,$5,'prepared')
     ON CONFLICT (artist_id,partner_id,reporting_period_start,reporting_period_end) WHERE reporting_period_start IS NOT NULL AND reporting_period_end IS NOT NULL
     DO NOTHING RETURNING *`,
    [req.user.id, p.id, 'Request created; provider dispatch will occur only through the installed partner-specific adapter.', periodStart, periodEnd]
  );
  if (!result.rowCount) {
    const existing = await db.query('SELECT id,status,dispatch_status,external_case_ref FROM artist_reporting_requests WHERE artist_id=$1 AND partner_id=$2 AND reporting_period_start=$3 AND reporting_period_end=$4', [req.user.id,p.id,periodStart,periodEnd]);
    return res.status(200).json({ request: existing.rows[0] || null, duplicate: true, message: 'A request for this partner and reporting period already exists; it was not sent again.' });
  }
  const recordings = await db.query("SELECT id,title,isrc,ownership_role,ownership_share FROM artist_recordings WHERE artist_id=$1 AND verification_status='verified' ORDER BY title", [req.user.id]);
  let dispatch;
  try {
    dispatch = await partnerConnectors.requestReport(req.params.code, {
      artistId:req.user.id, partnerCode:req.params.code, consentRecordId:p.authorisation_id,
      externalAuthorisation:{status:p.external_authorisation_status,authorisation_method:p.external_authorisation_method,external_authorisation_reference:p.external_authorisation_reference,evidence_storage_key:p.external_authorisation_evidence,external_scope:p.external_authorisation_scope || [],verified_at:p.external_authorisation_verified_at,expires_at:p.external_authorisation_expires_at},
      scopes:(p.consent_scope || []).filter((scope) => (p.external_authorisation_scope || []).includes(scope)), reportingPeriod:{ start:periodStart, end:periodEnd }, recordings:recordings.rows
    });
  } catch (_error) { dispatch = { ok:false, dispatchStatus:'failed', reason:'Provider adapter call failed. No acknowledgement was recorded.' }; }
  const nextStatus = dispatch.ok ? 'submitted' : 'follow_up_due';
  const dispatchStatus = dispatch.ok ? 'submitted' : (dispatch.dispatchStatus || 'failed');
  const saved = await db.query(
    `UPDATE artist_reporting_requests SET status=$1,dispatch_status=$2,external_case_ref=$3,submitted_at=CASE WHEN $2='submitted' THEN NOW() ELSE submitted_at END,notes=$4,updated_at=NOW() WHERE id=$5 RETURNING id,status,dispatch_status,external_case_ref,reporting_period_start,reporting_period_end`,
    [nextStatus,dispatchStatus,dispatch.externalRequestReference || null,dispatch.ok ? 'Provider acknowledged the one-off request.' : dispatch.reason || 'Provider request was not dispatched.',result.rows[0].id]
  );
  await audit(req.user.id, dispatch.ok ? 'partner_report_request_dispatched' : 'partner_report_request_not_dispatched', 'artist_reporting_request', result.rows[0].id, { partner:req.params.code,periodStart,periodEnd,dispatchStatus,externalRequestReference:dispatch.externalRequestReference || null,responseSha256:dispatch.responseSha256 || null });
  res.status(dispatch.ok ? 201 : 202).json({ request:saved.rows[0],duplicate:false,dispatchStatus,message:dispatch.ok ? 'The provider-specific adapter acknowledged the one-off report request.' : `The request is recorded but was not sent. ${dispatch.reason || 'Provider dispatch is unavailable.'}` });
}));

app.post('/api/v1/partners/:code/reports', reportLimiter, asyncRoute(async (req, res) => {
  const code = textValue(req.params.code,80).toLowerCase();
  if (!/^[a-z0-9_]{2,80}$/.test(code)) return res.status(400).json({ error: 'Invalid partner code.' });
  const partner = await db.query(
    `SELECT id,code,agreement_status,endpoint_status,connection_verified,connection_test_reference
     FROM reporting_partners WHERE code=$1`, [code]
  );
  if (!partner.rowCount) return res.status(404).json({ error: 'Partner is not registered.' });
  const p = partner.rows[0];
  if (p.agreement_status !== 'approved' || p.endpoint_status !== 'active' || !p.connection_verified || !p.connection_test_reference) return res.status(403).json({ error: 'Partner reporting endpoint is not approved and verified.' });
  const secretName = partnerSecretEnvName(code);
  const timestamp = req.get('x-appreciate-timestamp');
  const signature = req.get('x-appreciate-signature');
  const nonce = req.get('x-appreciate-nonce');
  if (!/^[A-Za-z0-9_-]{16,120}$/.test(String(nonce || ''))) return res.status(400).json({ error: 'A unique X-APPRECIATE-Nonce header is required.' });
  if (!verifyReportSignature({ secret: process.env[secretName], timestamp, rawBody: req.rawBody, signature })) return res.status(401).json({ error: 'Partner report signature is invalid or outside the allowed time window.' });
  const validation = validatePartnerReport(req.body);
  if (!validation.ok) return res.status(400).json({ error: 'Partner report payload is invalid.', details: validation.errors });
  const payloadHash = crypto.createHash('sha256').update(req.rawBody).digest('hex');
  const client = await db.pool.connect();
  try {
    await client.query('BEGIN');
    const nonceInsert = await client.query(
      'INSERT INTO partner_webhook_nonces(partner_id,nonce,signed_timestamp) VALUES($1,$2,$3) ON CONFLICT(partner_id,nonce) DO NOTHING RETURNING id',
      [p.id,nonce,Number(timestamp)]
    );
    if (!nonceInsert.rowCount) { await client.query('ROLLBACK'); return res.status(409).json({ error: 'Replay detected: this nonce has already been used.' }); }
    const delivery = await client.query(
      `INSERT INTO partner_report_deliveries(partner_id,partner_delivery_id,payload_sha256,reporting_period_start,reporting_period_end,currency,status)
       VALUES($1,$2,$3,$4,$5,$6,'processing') ON CONFLICT(partner_id,partner_delivery_id) DO NOTHING RETURNING id`,
      [p.id,req.body.deliveryId,payloadHash,req.body.periodStart,req.body.periodEnd,req.body.currency]
    );
    if (!delivery.rowCount) { await client.query('COMMIT'); return res.status(202).json({ accepted: true, duplicateDelivery: true, message: 'This partner delivery ID was already received.' }); }
    let matched = 0; let unmatched = 0; let ambiguous = 0;
    for (const row of req.body.rows) {
      const isrc = row.isrc.toUpperCase();
      const candidates = await client.query(
        `SELECT DISTINCT ar.id,ar.artist_id FROM artist_recordings ar
         JOIN artist_partner_authorisations a ON a.artist_id=ar.artist_id AND a.partner_id=$2
         JOIN artist_partner_external_authorisations ea ON ea.artist_id=ar.artist_id AND ea.partner_id=$2 AND ea.status='verified' AND ea.verified_at IS NOT NULL AND ea.external_authorisation_reference IS NOT NULL AND (ea.expires_at IS NULL OR ea.expires_at>NOW())
         WHERE ar.isrc=$1 AND ar.verification_status='verified' AND a.status='active' AND a.revoked_at IS NULL
           AND (a.expires_at IS NULL OR a.expires_at>NOW())
           AND (NOT $3::boolean OR 'usage_reports'=ANY(a.scope) AND 'usage_reports'=ANY(ea.external_scope))
           AND (NOT $4::boolean OR 'royalty_statements'=ANY(a.scope) AND 'royalty_statements'=ANY(ea.external_scope))
           AND EXISTS (SELECT 1 FROM artist_identity_verifications iv WHERE iv.artist_id=ar.artist_id AND iv.status='verified')`, [isrc,p.id,row.usageCount != null,row.grossAmountMinor != null || row.netAmountMinor != null]
      );
      let artistId = null; let recordingId = null; let matchStatus = 'unmatched';
      const artistIds = [...new Set(candidates.rows.map(x => x.artist_id))];
      if (artistIds.length === 1) {
        const candidate = candidates.rows.find(x => x.artist_id === artistIds[0]);
        artistId = candidate.artist_id; recordingId = candidate.id; matchStatus = 'matched'; matched++;
      } else if (artistIds.length > 1) { matchStatus = 'ambiguous'; ambiguous++; }
      else unmatched++;
      const amountStatus = row.amountStatus || 'reported';
      await client.query(
        `INSERT INTO partner_usage_royalty_rows(delivery_id,artist_id,recording_id,external_asset_ref,isrc,usage_type,territory,usage_count,gross_amount_minor,net_amount_minor,currency,amount_status,usage_period_start,usage_period_end,match_status,source_row_ref,settlement_reference,payment_confirmed_at)
         VALUES($1,$2,$3,NULLIF($4,''),$5,$6,NULLIF($7,''),$8,$9,$10,$11,$12,$13,$14,$15,NULLIF($16,''),NULLIF($17,''),$18)`,
        [delivery.rows[0].id,artistId,recordingId,textValue(row.externalAssetRef,200),isrc,textValue(row.usageType,80),textValue(row.territory,8),row.usageCount ?? null,row.grossAmountMinor ?? null,row.netAmountMinor ?? null,req.body.currency,amountStatus,row.usagePeriodStart || req.body.periodStart,row.usagePeriodEnd || req.body.periodEnd,matchStatus,textValue(row.sourceRowRef,200),row.settlementReference || null,row.paymentConfirmedAt || null]
      );
    }
    const deliveryStatus = unmatched || ambiguous ? 'needs_review' : 'processed';
    await client.query('UPDATE partner_report_deliveries SET status=$1 WHERE id=$2', [deliveryStatus,delivery.rows[0].id]);
    await client.query(
      `INSERT INTO audit_log(actor_user_id,event_type,entity_type,entity_id,details)
       VALUES(NULL,'partner_report_ingested','partner_report_delivery',$1,$2::jsonb)`,
      [delivery.rows[0].id,JSON.stringify({ partnerCode: code, deliveryId: req.body.deliveryId, payloadSha256: payloadHash, rows: req.body.rows.length, matched, unmatched, ambiguous, status: deliveryStatus })]
    );
    await client.query('COMMIT');
    res.status(202).json({ accepted: true, deliveryId: req.body.deliveryId, status: deliveryStatus, rows: req.body.rows.length, matched, unmatched, ambiguous, message: 'Signed report received. Only rows matched to verified ISRC ownership and active artist consent are visible in artist dashboards.' });
  } catch (error) { await client.query('ROLLBACK'); throw error; }
  finally { client.release(); }
}));

app.get('/api/v1/artists/me/reporting/dashboard', requireAuth, requireRole('artist','creator'), asyncRoute(async (req, res) => {
  const base = `FROM partner_usage_royalty_rows r
    JOIN partner_report_deliveries d ON d.id=r.delivery_id AND d.status IN ('processed','needs_review')
    JOIN reporting_partners p ON p.id=d.partner_id AND p.agreement_status='approved' AND p.endpoint_status='active' AND p.connection_verified=TRUE
    JOIN artist_partner_authorisations a ON a.artist_id=r.artist_id AND a.partner_id=p.id AND a.status='active' AND a.revoked_at IS NULL AND (a.expires_at IS NULL OR a.expires_at>NOW())
    JOIN artist_partner_external_authorisations ea ON ea.artist_id=r.artist_id AND ea.partner_id=p.id AND ea.status='verified' AND ea.verified_at IS NOT NULL AND ea.external_authorisation_reference IS NOT NULL AND (ea.expires_at IS NULL OR ea.expires_at>NOW())
    WHERE r.artist_id=$1 AND r.match_status='matched'`;
  const usage = await db.query(`SELECT p.code,p.display_name,r.usage_type,r.territory,r.currency,COALESCE(SUM(r.usage_count),0)::bigint AS usage_count,MIN(r.usage_period_start) AS period_start,MAX(r.usage_period_end) AS period_end ${base} AND 'usage_reports'=ANY(a.scope) AND 'usage_reports'=ANY(ea.external_scope) GROUP BY p.code,p.display_name,r.usage_type,r.territory,r.currency ORDER BY period_end DESC NULLS LAST`, [req.user.id]);
  const estimates = await db.query(`SELECT r.currency,COALESCE(SUM(r.net_amount_minor),0)::bigint AS amount_minor,COUNT(*)::int AS rows ${base} AND 'royalty_statements'=ANY(a.scope) AND 'royalty_statements'=ANY(ea.external_scope) AND r.amount_status='estimated' GROUP BY r.currency`, [req.user.id]);
  const reported = await db.query(`SELECT r.currency,COALESCE(SUM(r.net_amount_minor),0)::bigint AS amount_minor,COUNT(*)::int AS rows ${base} AND 'royalty_statements'=ANY(a.scope) AND 'royalty_statements'=ANY(ea.external_scope) AND r.amount_status IN ('reported','adjusted') GROUP BY r.currency`, [req.user.id]);
  const paid = await db.query(`SELECT r.currency,COALESCE(SUM(r.net_amount_minor),0)::bigint AS amount_minor,COUNT(*)::int AS rows ${base} AND 'royalty_statements'=ANY(a.scope) AND 'royalty_statements'=ANY(ea.external_scope) AND r.amount_status='paid' AND r.settlement_reference IS NOT NULL AND r.payment_confirmed_at IS NOT NULL GROUP BY r.currency`, [req.user.id]);
  res.json({ usage: usage.rows, estimates: estimates.rows, reportedRoyalties: reported.rows, confirmedPaid: paid.rows, status: usage.rowCount || estimates.rowCount || reported.rowCount || paid.rowCount ? 'Authorised partner report rows available.' : 'Awaiting authorised report. No royalty amount is assumed.' });
}));

app.get('/api/v1/social/connections', requireAuth, asyncRoute(async (req, res) => {
  const result = await db.query('SELECT platform,status,scopes,connected_at,expires_at FROM social_connections WHERE user_id=$1 ORDER BY platform', [req.user.id]);
  res.json({ connections: result.rows });
}));

app.post('/api/v1/social/connections/:platform/start', requireAuth, asyncRoute(async (req, res) => {
  const platform = textValue(req.params.platform, 40).toLowerCase();
  const allowed = new Set(['youtube','tiktok','instagram','facebook','x','pinterest','linkedin','whatsapp','telegram','spotify','apple_music']);
  if (!allowed.has(platform)) return res.status(400).json({ error: 'Unsupported platform.' });
  await db.query(
    `INSERT INTO social_connections(user_id,platform,status)
     VALUES($1,$2,'pending_approval') ON CONFLICT(user_id,platform) DO UPDATE SET status='pending_approval'`,
    [req.user.id, platform]
  );
  await audit(req.user.id, 'social_connection_requested', 'social_connection', platform);
  res.json({ status: 'pending_approval', message: 'No account has been connected. Official OAuth app registration, approval and provider credentials are required.' });
}));

app.post('/api/v1/campaigns', requireAuth, asyncRoute(async (req, res) => {
  const title = textValue(req.body?.title, 120);
  const caption = textValue(req.body?.caption, 3000);
  const destinations = Array.isArray(req.body?.destinations) ? [...new Set(req.body.destinations.map((x) => textValue(x, 40).toLowerCase()))].slice(0, 12) : [];
  if (title.length < 2) return res.status(400).json({ error: 'Campaign title is required.' });
  const client = await db.pool.connect();
  try {
    await client.query('BEGIN');
    const campaign = await client.query(
      `INSERT INTO campaigns(owner_id,title,caption,product_id,status)
       VALUES($1,$2,$3,$4,$5) RETURNING *`,
      [req.user.id, title, caption, req.body?.productId || null, destinations.length ? 'prepared' : 'draft']
    );
    for (const platform of destinations) {
      await client.query(
        `INSERT INTO campaign_destinations(campaign_id,platform,status)
         VALUES($1,$2,'awaiting_oauth') ON CONFLICT(campaign_id,platform) DO NOTHING`,
        [campaign.rows[0].id, platform]
      );
    }
    await client.query('COMMIT');
    res.status(201).json({ campaign: campaign.rows[0], message: 'Campaign prepared. No social platform post has been published.' });
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally { client.release(); }
}));

app.get('/api/v1/creator/dashboard', requireAuth, asyncRoute(async (req, res) => {
  const [products,campaigns,sales,ledger,connections] = await Promise.all([
    db.query('SELECT COUNT(*)::int AS count FROM products WHERE seller_id=$1', [req.user.id]),
    db.query('SELECT COUNT(*)::int AS count FROM campaigns WHERE owner_id=$1', [req.user.id]),
    db.query(`SELECT COUNT(DISTINCT o.id)::int AS orders,COALESCE(SUM(oi.line_total_minor),0)::bigint AS sales_minor
      FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.seller_id=$1 AND o.state IN ('paid','fulfilled')`, [req.user.id]),
    db.query('SELECT COALESCE(SUM(amount_minor),0)::bigint AS earnings_minor FROM ledger_entries WHERE owner_user_id=$1', [req.user.id]),
    db.query("SELECT COUNT(*) FILTER (WHERE status='connected')::int AS connected,COUNT(*)::int AS total FROM social_connections WHERE user_id=$1", [req.user.id])
  ]);
  res.json({ products:products.rows[0].count, campaigns:campaigns.rows[0].count, paidOrders:sales.rows[0].orders, salesMinor:sales.rows[0].sales_minor, ledgerMinor:ledger.rows[0].earnings_minor, socialConnections:connections.rows[0] });
}));

app.get('/api/v1/campaigns', requireAuth, asyncRoute(async (req, res) => {
  const result = await db.query(
    `SELECT c.*,COALESCE(json_agg(json_build_object('platform',d.platform,'status',d.status,'responseNote',d.response_note)) FILTER (WHERE d.id IS NOT NULL),'[]') AS destinations
     FROM campaigns c LEFT JOIN campaign_destinations d ON d.campaign_id=c.id
     WHERE c.owner_id=$1 GROUP BY c.id ORDER BY c.created_at DESC LIMIT 100`, [req.user.id]
  );
  res.json({ campaigns: result.rows });
}));

// --------------------------- Announcements ---------------------------
app.get('/api/v1/announcements', asyncRoute(async (_req, res) => {
  const result = await db.query(
    `SELECT a.id,a.title,a.body,a.audience,a.publish_at,a.created_at,p.display_name AS author
     FROM announcements a JOIN profiles p ON p.user_id=a.author_id
     WHERE a.status='published' AND (a.publish_at IS NULL OR a.publish_at<=NOW()) AND a.audience='public'
     ORDER BY COALESCE(a.publish_at,a.created_at) DESC LIMIT 50`
  );
  res.json({ announcements: result.rows });
}));

app.get('/api/v1/management/announcements', requireAuth, requireRole('manager','admin'), asyncRoute(async (_req, res) => {
  const result = await db.query(
    `SELECT a.*,p.display_name AS author FROM announcements a JOIN profiles p ON p.user_id=a.author_id
     ORDER BY a.created_at DESC LIMIT 200`
  );
  res.json({ announcements: result.rows });
}));

app.post('/api/v1/announcements', requireAuth, requireRole('artist','creator','manager','admin'), asyncRoute(async (req, res) => {
  const title = textValue(req.body?.title, 160);
  const body = textValue(req.body?.body, 5000);
  const audience = textValue(req.body?.audience || 'public', 20);
  if (title.length < 2 || body.length < 3) return res.status(400).json({ error: 'Announcement title and message are required.' });
  if (!['public','creators','artists','partners','internal'].includes(audience)) return res.status(400).json({ error: 'Invalid announcement audience.' });
  const result = await db.query(
    `INSERT INTO announcements(author_id,title,body,audience,status,publish_at)
     VALUES($1,$2,$3,$4,'draft',$5) RETURNING *`,
    [req.user.id, title, body, audience, req.body?.publishAt || null]
  );
  res.status(201).json({ announcement: result.rows[0] });
}));

app.post('/api/v1/announcements/:id/publish', requireAuth, requireRole('manager','admin'), asyncRoute(async (req, res) => {
  const result = await db.query("UPDATE announcements SET status='published',publish_at=COALESCE(publish_at,NOW()) WHERE id=$1 RETURNING *", [req.params.id]);
  if (!result.rowCount) return res.status(404).json({ error: 'Announcement not found.' });
  await audit(req.user.id, 'announcement_published_in_app', 'announcement', req.params.id);
  res.json({ announcement: result.rows[0], message: 'Published inside APPRECIATE only. External social posting requires official integrations.' });
}));

// --------------------------- Corporate and management portal ---------------------------
app.post('/api/v1/corporate/enquiries', requireAuth, requireRole('company'), asyncRoute(async (req, res) => {
  const subject = textValue(req.body?.subject, 180);
  const brief = textValue(req.body?.brief, 5000);
  const artistUserId = req.body?.artistUserId || null;
  const budgetMinor = req.body?.budget ? minor(req.body.budget) : null;
  if (subject.length < 3 || brief.length < 10) return res.status(400).json({ error: 'Provide a subject and a useful project brief.' });
  const result = await db.query(
    `INSERT INTO corporate_enquiries(company_user_id,artist_user_id,subject,brief,budget_minor)
     VALUES($1,$2,$3,$4,$5) RETURNING *`,
    [req.user.id, artistUserId, subject, brief, budgetMinor]
  );
  await audit(req.user.id, 'corporate_enquiry_submitted', 'corporate_enquiry', result.rows[0].id);
  res.status(201).json({ enquiry: result.rows[0] });
}));

app.get('/api/v1/corporate/enquiries', requireAuth, requireRole('company','manager','admin'), asyncRoute(async (req, res) => {
  const sql = ['manager','admin'].includes(req.user.account_type)
    ? `SELECT e.*,p.display_name AS company_name FROM corporate_enquiries e JOIN profiles p ON p.user_id=e.company_user_id ORDER BY e.created_at DESC LIMIT 200`
    : `SELECT * FROM corporate_enquiries WHERE company_user_id=$1 ORDER BY created_at DESC LIMIT 100`;
  const result = await db.query(sql, ['manager','admin'].includes(req.user.account_type) ? [] : [req.user.id]);
  res.json({ enquiries: result.rows });
}));

app.post('/api/v1/management/enquiries/:id/proposals', requireAuth, requireRole('manager','admin'), asyncRoute(async (req, res) => {
  const amountMinor = minor(req.body?.amount);
  const terms = textValue(req.body?.terms, 6000);
  if (terms.length < 10) return res.status(400).json({ error: 'Proposal terms are required.' });
  const enquiry = await db.query("SELECT * FROM corporate_enquiries WHERE id=$1 AND status NOT IN ('declined','closed')", [req.params.id]);
  if (!enquiry.rowCount) return res.status(404).json({ error: 'Open corporate enquiry not found.' });
  const result = await db.query(
    `INSERT INTO proposals(enquiry_id,created_by,amount_minor,currency,terms,valid_until,status)
     VALUES($1,$2,$3,$4,$5,$6,'sent') RETURNING *`,
    [req.params.id, req.user.id, amountMinor, req.body?.currency || 'ZAR', terms, req.body?.validUntil || null]
  );
  await db.query("UPDATE corporate_enquiries SET status='proposal_sent' WHERE id=$1", [req.params.id]);
  await audit(req.user.id, 'proposal_sent', 'proposal', result.rows[0].id);
  res.status(201).json({ proposal: result.rows[0] });
}));

app.get('/api/v1/corporate/proposals', requireAuth, requireRole('company'), asyncRoute(async (req, res) => {
  const result = await db.query(
    `SELECT p.*,e.subject,e.company_user_id,e.artist_user_id
     FROM proposals p JOIN corporate_enquiries e ON e.id=p.enquiry_id
     WHERE e.company_user_id=$1 ORDER BY p.created_at DESC`, [req.user.id]
  );
  res.json({ proposals: result.rows });
}));

app.post('/api/v1/corporate/proposals/:id/respond', requireAuth, requireRole('company'), asyncRoute(async (req, res) => {
  const decision = req.body?.decision === 'accept' ? 'accepted' : req.body?.decision === 'reject' ? 'rejected' : null;
  if (!decision) return res.status(400).json({ error: 'Choose accept or reject.' });
  const result = await db.query(
    `UPDATE proposals p SET status=$1,responded_at=NOW()
     FROM corporate_enquiries e
     WHERE p.id=$2 AND p.enquiry_id=e.id AND e.company_user_id=$3 AND p.status='sent'
     RETURNING p.*`, [decision, req.params.id, req.user.id]
  );
  if (!result.rowCount) return res.status(404).json({ error: 'Proposal not found or already answered.' });
  await db.query('UPDATE corporate_enquiries SET status=$1 WHERE id=(SELECT enquiry_id FROM proposals WHERE id=$2)', [decision === 'rejected' ? 'declined' : decision, req.params.id]);
  res.json({ proposal: result.rows[0] });
}));

app.post('/api/v1/management/proposals/:id/agreement', requireAuth, requireRole('manager','admin'), asyncRoute(async (req, res) => {
  const proposal = await db.query(
    `SELECT p.*,e.company_user_id,e.artist_user_id FROM proposals p JOIN corporate_enquiries e ON e.id=p.enquiry_id
     WHERE p.id=$1 AND p.status='accepted'`, [req.params.id]
  );
  if (!proposal.rowCount) return res.status(404).json({ error: 'Accepted proposal not found.' });
  const p = proposal.rows[0];
  const agreement = await db.query(
    `INSERT INTO agreements(proposal_id,agreement_type,reference,company_user_id,artist_user_id,manager_user_id,terms,status)
     VALUES($1,'sponsorship',$2,$3,$4,$5,$6,'awaiting_signatures') RETURNING *`,
    [p.id, reference('AGR'), p.company_user_id, p.artist_user_id, req.user.id, p.terms]
  );
  await audit(req.user.id, 'agreement_created', 'agreement', agreement.rows[0].id);
  res.status(201).json({ agreement: agreement.rows[0], message: 'Agreement created. Each required party must review and sign.' });
}));

app.post('/api/v1/management/agreements', requireAuth, requireRole('manager','admin'), asyncRoute(async (req, res) => {
  const artistUserId = textValue(req.body?.artistUserId, 64);
  const terms = textValue(req.body?.terms, 6000);
  const rate = Number(req.body?.commissionRateBps || 0);
  if (!artistUserId || terms.length < 10 || !Number.isInteger(rate) || rate < 0 || rate > 10000) return res.status(400).json({ error: 'Artist, terms and a valid commission rate (basis points) are required.' });
  const artist = await db.query("SELECT user_id FROM artist_profiles WHERE user_id=$1 AND status='approved'", [artistUserId]);
  if (!artist.rowCount) return res.status(400).json({ error: 'Artist must have an approved artist profile before a management agreement is created.' });
  const result = await db.query(
    `INSERT INTO agreements(agreement_type,reference,artist_user_id,manager_user_id,terms,commission_rate_bps,status)
     VALUES('artist_management',$1,$2,$3,$4,$5,'awaiting_signatures') RETURNING *`,
    [reference('AGR'), artistUserId, req.user.id, terms, rate]
  );
  res.status(201).json({ agreement: result.rows[0] });
}));

app.get('/api/v1/agreements', requireAuth, asyncRoute(async (req, res) => {
  const result = await db.query(
    `SELECT * FROM agreements WHERE company_user_id=$1 OR artist_user_id=$1 OR manager_user_id=$1 ORDER BY created_at DESC LIMIT 100`, [req.user.id]
  );
  res.json({ agreements: result.rows });
}));

app.post('/api/v1/agreements/:id/sign', requireAuth, asyncRoute(async (req, res) => {
  const agreement = await db.query('SELECT * FROM agreements WHERE id=$1', [req.params.id]);
  if (!agreement.rowCount) return res.status(404).json({ error: 'Agreement not found.' });
  const a = agreement.rows[0];
  if (a.status !== 'awaiting_signatures') return res.status(409).json({ error: 'This agreement is not awaiting signatures.' });
  let signerRole = null;
  if (a.company_user_id === req.user.id) signerRole = 'company';
  else if (a.artist_user_id === req.user.id) signerRole = 'artist';
  else if (a.manager_user_id === req.user.id && ['manager','admin'].includes(req.user.account_type)) signerRole = 'manager';
  if (!signerRole) return res.status(403).json({ error: 'You are not a signing party on this agreement.' });
  const signatureName = textValue(req.body?.signatureName, 120);
  if (signatureName.length < 2) return res.status(400).json({ error: 'Enter the name of the authorised signer.' });
  await db.query(
    `INSERT INTO agreement_signatures(agreement_id,signer_user_id,signer_role,signature_name)
     VALUES($1,$2,$3,$4) ON CONFLICT(agreement_id,signer_user_id) DO NOTHING`,
    [a.id, req.user.id, signerRole, signatureName]
  );
  const signatures = await db.query('SELECT signer_role FROM agreement_signatures WHERE agreement_id=$1', [a.id]);
  const roles = new Set(signatures.rows.map((x) => x.signer_role));
  const required = a.agreement_type === 'artist_management'
    ? ['artist','manager']
    : a.artist_user_id ? ['company','artist','manager'] : ['company','manager'];
  const active = required.every((role) => roles.has(role));
  if (active) await db.query("UPDATE agreements SET status='active',activated_at=NOW() WHERE id=$1", [a.id]);
  await audit(req.user.id, 'agreement_signed', 'agreement', a.id, { signerRole, active });
  res.json({ agreementId: a.id, signatures: [...roles], status: active ? 'active' : 'awaiting_signatures', note: 'This is an in-app acceptance record, not a substitute for legal advice or a qualified electronic-signature service.' });
}));

app.post('/api/v1/management/agreements/:id/deliverables', requireAuth, requireRole('manager','admin'), asyncRoute(async (req, res) => {
  const title = textValue(req.body?.title, 180);
  const description = textValue(req.body?.description, 3000);
  const ownerUserId = textValue(req.body?.ownerUserId, 64);
  if (title.length < 2 || !ownerUserId) return res.status(400).json({ error: 'Deliverable title and owner are required.' });
  const agreement = await db.query('SELECT * FROM agreements WHERE id=$1', [req.params.id]);
  if (!agreement.rowCount) return res.status(404).json({ error: 'Agreement not found.' });
  const agreementRecord = agreement.rows[0];
  if (agreementRecord.manager_user_id !== req.user.id && req.user.account_type !== 'admin') return res.status(403).json({ error: 'Only the assigned manager can add deliverables.' });
  if (agreementRecord.status !== 'active') return res.status(409).json({ error: 'Deliverables can be assigned only after the agreement is active.' });
  const result = await db.query(
    `INSERT INTO deliverables(agreement_id,owner_user_id,title,description,due_at)
     VALUES($1,$2,$3,$4,$5) RETURNING *`,
    [req.params.id, ownerUserId, title, description, req.body?.dueAt || null]
  );
  res.status(201).json({ deliverable: result.rows[0] });
}));

app.get('/api/v1/agreements/:id/deliverables', requireAuth, asyncRoute(async (req, res) => {
  const agreement = await db.query('SELECT * FROM agreements WHERE id=$1 AND (company_user_id=$2 OR artist_user_id=$2 OR manager_user_id=$2)', [req.params.id, req.user.id]);
  if (!agreement.rowCount && !['manager','admin'].includes(req.user.account_type)) return res.status(404).json({ error: 'Agreement not found.' });
  const result = await db.query('SELECT * FROM deliverables WHERE agreement_id=$1 ORDER BY due_at NULLS LAST,created_at', [req.params.id]);
  res.json({ deliverables: result.rows });
}));

app.patch('/api/v1/deliverables/:id', requireAuth, asyncRoute(async (req, res) => {
  const current = await db.query(
    `SELECT d.*,a.manager_user_id FROM deliverables d JOIN agreements a ON a.id=d.agreement_id WHERE d.id=$1`, [req.params.id]
  );
  if (!current.rowCount) return res.status(404).json({ error: 'Deliverable not found.' });
  const d = current.rows[0];
  if (d.owner_user_id !== req.user.id && d.manager_user_id !== req.user.id && !['manager','admin'].includes(req.user.account_type)) return res.status(403).json({ error: 'You cannot update this deliverable.' });
  const status = textValue(req.body?.status || d.status, 30);
  if (!['pending','in_progress','submitted','accepted','rejected','overdue'].includes(status)) return res.status(400).json({ error: 'Invalid deliverable status.' });
  const proofUrl = textValue(req.body?.proofUrl || d.proof_url, 1000);
  const result = await db.query(
    `UPDATE deliverables SET status=$1,proof_url=NULLIF($2,''),submitted_at=CASE WHEN $1='submitted' THEN NOW() ELSE submitted_at END,
       accepted_at=CASE WHEN $1='accepted' THEN NOW() ELSE accepted_at END WHERE id=$3 RETURNING *`,
    [status, proofUrl, d.id]
  );
  res.json({ deliverable: result.rows[0] });
}));

app.post('/api/v1/management/agreements/:id/invoices', requireAuth, requireRole('manager','admin'), asyncRoute(async (req, res) => {
  const agreement = await db.query('SELECT * FROM agreements WHERE id=$1', [req.params.id]);
  if (!agreement.rowCount) return res.status(404).json({ error: 'Agreement not found.' });
  const a = agreement.rows[0];
  if (a.manager_user_id !== req.user.id && req.user.account_type !== 'admin') return res.status(403).json({ error: 'Only the agreement manager can issue this invoice.' });
  if (a.status !== 'active') return res.status(409).json({ error: 'Invoices can be issued only after the agreement is active.' });
  if (!a.company_user_id) return res.status(400).json({ error: 'This agreement has no company billing account.' });
  const amountMinor = minor(req.body?.amount);
  const result = await db.query(
    `INSERT INTO payment_invoices(agreement_id,bill_to_user_id,payee_user_id,created_by,reference,amount_minor,currency,description,due_at)
     VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
    [a.id, a.company_user_id, a.manager_user_id, req.user.id, reference('INV'), amountMinor, req.body?.currency || 'ZAR', textValue(req.body?.description || 'APPRECIATE partnership invoice', 500), req.body?.dueAt || null]
  );
  res.status(201).json({ invoice: result.rows[0], message: 'Invoice created. Payment is pending until a provider confirms it.' });
}));

app.get('/api/v1/invoices', requireAuth, asyncRoute(async (req, res) => {
  const result = await db.query(
    'SELECT * FROM payment_invoices WHERE bill_to_user_id=$1 OR payee_user_id=$1 ORDER BY created_at DESC LIMIT 100', [req.user.id]
  );
  res.json({ invoices: result.rows });
}));

app.get('/api/v1/management/overview', requireAuth, requireRole('manager','admin'), asyncRoute(async (_req, res) => {
  const [artists, enquiries, proposals, agreements, deliverables] = await Promise.all([
    db.query('SELECT ap.*,p.display_name,u.email FROM artist_profiles ap JOIN profiles p ON p.user_id=ap.user_id JOIN users u ON u.id=ap.user_id ORDER BY ap.created_at DESC LIMIT 200'),
    db.query('SELECT e.*,p.display_name AS company_name FROM corporate_enquiries e JOIN profiles p ON p.user_id=e.company_user_id ORDER BY e.created_at DESC LIMIT 200'),
    db.query(`SELECT pr.*,e.subject,p.display_name AS company_name FROM proposals pr JOIN corporate_enquiries e ON e.id=pr.enquiry_id JOIN profiles p ON p.user_id=e.company_user_id ORDER BY pr.created_at DESC LIMIT 200`),
    db.query('SELECT * FROM agreements ORDER BY created_at DESC LIMIT 200'),
    db.query("SELECT status,COUNT(*)::int AS count FROM deliverables GROUP BY status")
  ]);
  res.json({ artists: artists.rows, enquiries: enquiries.rows, proposals: proposals.rows, agreements: agreements.rows, deliverableCounts: deliverables.rows });
}));

app.patch('/api/v1/management/artists/:userId/approve', requireAuth, requireRole('manager','admin'), asyncRoute(async (req, res) => {
  const status = req.body?.status === 'rejected' ? 'rejected' : 'approved';
  const result = await db.query(
    `UPDATE artist_profiles SET status=$1,approved_by=$2,approved_at=CASE WHEN $1='approved' THEN NOW() ELSE NULL END
     WHERE user_id=$3 RETURNING *`, [status, req.user.id, req.params.userId]
  );
  if (!result.rowCount) return res.status(404).json({ error: 'Artist application not found.' });
  if (status === 'approved') await db.query("UPDATE users SET account_type='artist' WHERE id=$1 AND account_type='member'", [req.params.userId]);
  await audit(req.user.id, `artist_${status}`, 'artist_profile', result.rows[0].id);
  res.json({ artistProfile: result.rows[0] });
}));

app.post('/api/v1/agreements/:id/reports', requireAuth, asyncRoute(async (req, res) => {
  const agreement = await db.query('SELECT * FROM agreements WHERE id=$1', [req.params.id]);
  if (!agreement.rowCount) return res.status(404).json({ error: 'Agreement not found.' });
  const reportAgreement = agreement.rows[0];
  const isParty = [reportAgreement.company_user_id,reportAgreement.artist_user_id,reportAgreement.manager_user_id].includes(req.user.id);
  if (!isParty && !['manager','admin'].includes(req.user.account_type)) return res.status(403).json({ error: 'You cannot report on this agreement.' });
  if (!['active','completed'].includes(reportAgreement.status)) return res.status(409).json({ error: 'Reports can be issued only for active or completed agreements.' });
  const reportType = textValue(req.body?.reportType || 'campaign_performance', 80);
  const reportData = req.body?.reportData && typeof req.body.reportData === 'object' ? req.body.reportData : {};
  const result = await db.query(
    `INSERT INTO agreement_reports(agreement_id,created_by,report_type,period_start,period_end,report_data,status)
     VALUES($1,$2,$3,$4,$5,$6::jsonb,'issued') RETURNING *`,
    [req.params.id, req.user.id, reportType, req.body?.periodStart || null, req.body?.periodEnd || null, JSON.stringify(reportData)]
  );
  res.status(201).json({ report: result.rows[0] });
}));


// --------------------------- Music releases and offline entitlement sync ---------------------------
app.post('/api/v1/music/releases', requireAuth, requireRole('creator','artist','seller','manager','admin'), asyncRoute(async (req, res) => {
  const title = textValue(req.body?.title, 120);
  const priceMinor = minor(req.body?.price);
  const declaration = textValue(req.body?.ownershipDeclaration, 2000);
  const rightsConfirmed = req.body?.rightsConfirmed === true;
  if (title.length < 2 || declaration.length < 15) return res.status(400).json({ error: 'Track title and ownership declaration are required.' });
  const client = await db.pool.connect();
  try {
    await client.query('BEGIN');
    const product = await client.query(
      `INSERT INTO products(seller_id,kind,category,title,description,price_minor,status)
       VALUES($1,'music','Music',$2,$3,$4,$5) RETURNING *`,
      [req.user.id, title, textValue(req.body?.description, 2000), priceMinor, rightsConfirmed ? 'published' : 'draft']
    );
    const release = await client.query(
      `INSERT INTO music_releases(artist_id,product_id,title,artist_display_name,isrc,upc,ownership_declaration,rights_confirmed)
       VALUES($1,$2,$3,$4,NULLIF($5,''),NULLIF($6,''),$7,$8) RETURNING *`,
      [req.user.id, product.rows[0].id, title, textValue(req.body?.artistDisplayName || req.user.display_name, 100), textValue(req.body?.isrc, 20), textValue(req.body?.upc, 20), declaration, rightsConfirmed]
    );
    await client.query('COMMIT');
    res.status(201).json({ product: product.rows[0], release: release.rows[0], message: rightsConfirmed ? 'Release metadata saved. Audio upload and rights evidence storage are not active.' : 'Release saved as a draft until ownership is confirmed.' });
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally { client.release(); }
}));


const AUDIO_MAX_BYTES = 50 * 1024 * 1024;
const AUDIO_TYPES = new Set(['audio/mpeg','audio/mp4','audio/wav','audio/x-wav','audio/ogg','audio/flac']);
app.post('/api/v1/music/releases/:releaseId/audio-upload', requireAuth, requireRole('creator','artist','seller','manager','admin'), asyncRoute(async (req,res) => {
  const size = Number(req.body?.sizeBytes);
  const contentType = String(req.body?.contentType || '').toLowerCase().trim();
  const fileName = String(req.body?.fileName || '').slice(0,180);
  const extension = (fileName.split('.').pop() || '').toLowerCase();
  const allowedExtensions = new Set(['mp3','m4a','wav','ogg','flac']);
  if (!Number.isSafeInteger(size) || size < 1 || size > AUDIO_MAX_BYTES || !AUDIO_TYPES.has(contentType) || !allowedExtensions.has(extension)) {
    return res.status(400).json({error:'Choose an MP3, M4A, WAV, OGG or FLAC audio file no larger than 50 MB.'});
  }
  const release = await db.query('SELECT id FROM music_releases WHERE id=$1 AND artist_id=$2',[req.params.releaseId,req.user.id]);
  if (!release.rowCount) return res.status(404).json({error:'That release does not belong to your account.'});
  const key = `private/music/${req.user.id}/${release.rows[0].id}/${crypto.randomUUID()}.${extension}`;
  const signed = privateStorage.presignRequest({method:'PUT',key,expiresSeconds:600,contentType});
  res.json({uploadUrl:signed.url,headers:signed.headers,objectKey:key,expiresAt:signed.expiresAt,message:'Upload URL prepared.'});
}));
app.post('/api/v1/music/releases/:releaseId/audio-upload/complete', requireAuth, requireRole('creator','artist','seller','manager','admin'), asyncRoute(async (req,res) => {
  const key = String(req.body?.objectKey || '');
  if (!key.startsWith(`private/music/${req.user.id}/${req.params.releaseId}/`) || key.includes('..')) return res.status(400).json({error:'Audio object reference is invalid.'});
  const release = await db.query('SELECT id FROM music_releases WHERE id=$1 AND artist_id=$2',[req.params.releaseId,req.user.id]);
  if (!release.rowCount) return res.status(404).json({error:'Release not found for this account.'});
  const object = await privateStorage.headObject(key);
  if (!object.sizeBytes || object.sizeBytes > AUDIO_MAX_BYTES || !AUDIO_TYPES.has(object.contentType)) return res.status(400).json({error:'Stored audio failed size or media-type verification.'});
  await db.query('UPDATE music_releases SET audio_storage_key=$1 WHERE id=$2 AND artist_id=$3',[key,req.params.releaseId,req.user.id]);
  res.json({message:'Audio uploaded and verified in private storage.'});
}));
app.get('/api/v1/music/my-releases', requireAuth, asyncRoute(async (req,res) => {
  const result = await db.query('SELECT id,title,artist_display_name,isrc,rights_confirmed,audio_storage_key,created_at FROM music_releases WHERE artist_id=$1 ORDER BY created_at DESC',[req.user.id]);
  res.json({releases:result.rows});
}));
app.get('/api/v1/music/:releaseId/play', requireAuth, asyncRoute(async (req,res) => {
  const result = await db.query(`SELECT r.audio_storage_key FROM music_releases r JOIN products p ON p.id=r.product_id
    WHERE r.id=$1 AND r.audio_storage_key IS NOT NULL AND (
      r.artist_id=$2 OR (r.rights_confirmed=TRUE AND p.status='published' AND EXISTS(
        SELECT 1 FROM music_entitlements e WHERE e.release_id=r.id AND e.buyer_id=$2
      ))
    )`,[req.params.releaseId,req.user.id]);
  if (!result.rowCount) return res.status(403).json({error:'Playback requires the artist account or a verified paid music entitlement.'});
  const signed = privateStorage.createDownloadUrl(result.rows[0].audio_storage_key);
  res.redirect(302,signed.url);
}));

app.get('/api/v1/music/releases', asyncRoute(async (_req, res) => {
  const result = await db.query(
    `SELECT r.id,r.title,r.artist_display_name,r.isrc,r.upc,r.created_at,(r.audio_storage_key IS NOT NULL) AS has_audio,p.price_minor,p.currency,p.id AS product_id
     FROM music_releases r JOIN products p ON p.id=r.product_id
     WHERE r.rights_confirmed=TRUE AND p.status='published' ORDER BY r.created_at DESC LIMIT 100`
  );
  res.json({ releases: result.rows });
}));

app.get('/api/v1/music/:releaseId/download', requireAuth, asyncRoute(async (req, res) => {
  const entitlement = await db.query(
    `SELECT r.id,r.audio_storage_key FROM music_entitlements e JOIN music_releases r ON r.id=e.release_id
     WHERE e.release_id=$1 AND e.buyer_id=$2`, [req.params.releaseId, req.user.id]
  );
  if (!entitlement.rowCount) return res.status(403).json({ error: 'A paid music entitlement is required.' });
  if (process.env.MEDIA_STORAGE_DRIVER !== 's3' || !entitlement.rows[0].audio_storage_key) {
    return res.status(503).json({ error: 'Secure audio storage is not configured. Your purchase entitlement is recorded, but no download URL can be issued yet.' });
  }
  return res.status(503).json({ error: 'The private-storage signed-URL adapter still needs to be installed and security-tested.' });
}));

app.post('/api/v1/music/play-events/sync', requireAuth, asyncRoute(async (req, res) => {
  const events = Array.isArray(req.body?.events) ? req.body.events.slice(0, 100) : [];
  let accepted = 0;
  for (const event of events) {
    const releaseId = textValue(event.releaseId, 64);
    const offlineEventId = textValue(event.eventId, 120);
    const playedAt = event.playedAt ? new Date(event.playedAt) : new Date();
    if (!releaseId || !offlineEventId || Number.isNaN(playedAt.getTime())) continue;
    const entitlement = await db.query('SELECT 1 FROM music_entitlements WHERE buyer_id=$1 AND release_id=$2', [req.user.id, releaseId]);
    if (!entitlement.rowCount) continue;
    const inserted = await db.query(
      `INSERT INTO music_play_events(buyer_id,release_id,offline_event_id,played_at)
       VALUES($1,$2,$3,$4) ON CONFLICT(buyer_id,offline_event_id) DO NOTHING RETURNING id`,
      [req.user.id, releaseId, offlineEventId, playedAt]
    );
    accepted += inserted.rowCount;
  }
  res.json({ accepted, received: events.length, note: 'Offline play events are usage logs only. They do not automatically create streaming royalties.' });
}));

// --------------------------- Trusted delivery and buyer protection ---------------------------
app.post('/api/v1/orders/:id/shipments', requireAuth, requireRole('seller','creator','artist','manager','admin'), asyncRoute(async (req, res) => {
  const order = await db.query("SELECT * FROM orders WHERE id=$1 AND state IN ('paid','fulfilled')", [req.params.id]);
  if (!order.rowCount) return res.status(404).json({ error: 'Paid order not found.' });
  const item = await db.query('SELECT 1 FROM order_items WHERE order_id=$1 AND seller_id=$2 LIMIT 1', [req.params.id, req.user.id]);
  if (!item.rowCount && !['manager','admin'].includes(req.user.account_type)) return res.status(403).json({ error: 'This account is not a seller on the order.' });
  const shipment = await db.query(
    `INSERT INTO shipments(order_id,seller_id,buyer_id,courier_provider,tracking_url,delivery_contact_name,delivery_contact_phone,status)
     VALUES($1,$2,$3,NULLIF($4,''),NULLIF($5,''),NULLIF($6,''),NULLIF($7,''),'awaiting_dispatch')
     ON CONFLICT(order_id,seller_id) DO UPDATE SET tracking_url=EXCLUDED.tracking_url
     RETURNING *`,
    [req.params.id, req.user.id, order.rows[0].buyer_id, textValue(req.body?.courierProvider,80), textValue(req.body?.trackingUrl,1000), textValue(req.body?.deliveryContactName,120), textValue(req.body?.deliveryContactPhone,40)]
  );
  await db.query("INSERT INTO shipment_events(shipment_id,status,source,note) VALUES($1,'awaiting_dispatch','manual','Shipment record created')", [shipment.rows[0].id]);
  res.status(201).json({ shipment: shipment.rows[0], message: 'Shipment record created. Automatic courier assignment and tracking require a contracted courier API.' });
}));

app.get('/api/v1/orders/:id/shipments', requireAuth, asyncRoute(async (req, res) => {
  const access = await db.query(
    `SELECT o.buyer_id,EXISTS(SELECT 1 FROM order_items oi WHERE oi.order_id=o.id AND oi.seller_id=$2) AS is_seller
     FROM orders o WHERE o.id=$1`, [req.params.id, req.user.id]
  );
  if (!access.rowCount || (access.rows[0].buyer_id !== req.user.id && !access.rows[0].is_seller && !['manager','admin'].includes(req.user.account_type))) return res.status(404).json({ error: 'Order not found.' });
  const result = await db.query(
    `SELECT s.*,COALESCE(json_agg(json_build_object('status',e.status,'source',e.source,'note',e.note,'occurredAt',e.occurred_at)) FILTER (WHERE e.id IS NOT NULL),'[]') AS events
     FROM shipments s LEFT JOIN shipment_events e ON e.shipment_id=s.id WHERE s.order_id=$1 GROUP BY s.id ORDER BY s.created_at`, [req.params.id]
  );
  res.json({ shipments: result.rows });
}));

app.patch('/api/v1/shipments/:id/status', requireAuth, asyncRoute(async (req, res) => {
  const current = await db.query('SELECT * FROM shipments WHERE id=$1', [req.params.id]);
  if (!current.rowCount) return res.status(404).json({ error: 'Shipment not found.' });
  const shipment = current.rows[0];
  if (shipment.seller_id !== req.user.id && !['manager','admin'].includes(req.user.account_type)) return res.status(403).json({ error: 'Only the seller or authorised management can update this shipment.' });
  const status = textValue(req.body?.status,40);
  const allowed = new Set(['awaiting_dispatch','dispatched','in_transit','out_for_delivery','delivered','failed','returned']);
  if (!allowed.has(status)) return res.status(400).json({ error: 'Invalid shipment status.' });
  const proofUrl = textValue(req.body?.proofUrl || shipment.proof_url,1000);
  const proofKey = textValue(req.body?.proofStorageKey || shipment.proof_storage_key,500);
  if (status === 'delivered' && !proofUrl && !proofKey) return res.status(400).json({ error: 'Proof of delivery is required before marking a shipment delivered.' });
  const result = await db.query(
    `UPDATE shipments SET status=$1,proof_url=NULLIF($2,''),proof_storage_key=NULLIF($3,''),
      dispatched_at=CASE WHEN $1='dispatched' AND dispatched_at IS NULL THEN NOW() ELSE dispatched_at END,
      delivered_at=CASE WHEN $1='delivered' THEN NOW() ELSE delivered_at END WHERE id=$4 RETURNING *`,
    [status,proofUrl,proofKey,shipment.id]
  );
  await db.query('INSERT INTO shipment_events(shipment_id,status,source,note,proof_storage_key) VALUES($1,$2,\'manual\',$3,NULLIF($4,\'\'))', [shipment.id,status,textValue(req.body?.note,1000),proofKey]);
  if (status === 'delivered') {
    const remaining = await db.query("SELECT COUNT(*)::int AS n FROM shipments WHERE order_id=$1 AND status<>'delivered'", [shipment.order_id]);
    if (remaining.rows[0].n === 0) await db.query("UPDATE orders SET state='fulfilled' WHERE id=$1 AND state='paid'", [shipment.order_id]);
  }
  res.json({ shipment: result.rows[0], message: 'Shipment status recorded. This is a manual update until a courier webhook is connected.' });
}));

app.post('/api/v1/shipments/:id/confirm', requireAuth, asyncRoute(async (req, res) => {
  const result = await db.query(
    `UPDATE shipments SET buyer_confirmed_at=NOW() WHERE id=$1 AND buyer_id=$2 AND status='delivered' RETURNING *`,
    [req.params.id, req.user.id]
  );
  if (!result.rowCount) return res.status(404).json({ error: 'Delivered shipment not found for this buyer.' });
  await db.query("INSERT INTO shipment_events(shipment_id,status,source,note) VALUES($1,'buyer_confirmed','system','Buyer confirmed delivery')", [req.params.id]);
  res.json({ shipment: result.rows[0] });
}));

app.post('/api/v1/shipments/:id/dispute', requireAuth, asyncRoute(async (req, res) => {
  const reason = textValue(req.body?.reason,1500);
  if (reason.length < 5) return res.status(400).json({ error: 'Explain the delivery problem.' });
  const shipment = await db.query('SELECT * FROM shipments WHERE id=$1 AND buyer_id=$2', [req.params.id, req.user.id]);
  if (!shipment.rowCount) return res.status(404).json({ error: 'Shipment not found for this buyer.' });
  const dispute = await db.query('INSERT INTO delivery_disputes(shipment_id,opened_by,reason) VALUES($1,$2,$3) RETURNING *', [req.params.id, req.user.id, reason]);
  await db.query("UPDATE shipments SET status='disputed' WHERE id=$1", [req.params.id]);
  await db.query("INSERT INTO shipment_events(shipment_id,status,source,note) VALUES($1,'disputed','system',$2)", [req.params.id, reason]);
  res.status(201).json({ dispute: dispute.rows[0], message: 'Delivery dispute opened for management review.' });
}));

app.get('/api/v1/management/delivery-disputes', requireAuth, requireRole('manager','admin'), asyncRoute(async (_req, res) => {
  const result = await db.query(
    `SELECT d.*,s.order_id,s.seller_id,s.buyer_id,s.status AS shipment_status FROM delivery_disputes d
     JOIN shipments s ON s.id=d.shipment_id ORDER BY d.created_at DESC LIMIT 200`
  );
  res.json({ disputes: result.rows });
}));

app.patch('/api/v1/management/delivery-disputes/:id', requireAuth, requireRole('manager','admin'), asyncRoute(async (req, res) => {
  const status = textValue(req.body?.status,30);
  if (!['investigating','resolved_buyer','resolved_seller','closed'].includes(status)) return res.status(400).json({ error: 'Invalid dispute status.' });
  const result = await db.query(
    `UPDATE delivery_disputes SET status=$1,resolution=NULLIF($2,''),resolved_at=CASE WHEN $1 IN ('resolved_buyer','resolved_seller','closed') THEN NOW() ELSE NULL END
     WHERE id=$3 RETURNING *`, [status,textValue(req.body?.resolution,2000),req.params.id]
  );
  if (!result.rowCount) return res.status(404).json({ error: 'Delivery dispute not found.' });
  res.json({ dispute: result.rows[0] });
}));

app.use('/api/v1', (_req, res) => res.status(404).json({ error: 'APPRECIATE API route not found.' }));

app.use((error, _req, res, _next) => {
  console.error('APPRECIATE API error:', error.message);
  if (res.headersSent) return;
  const status = Number.isInteger(error.status) && error.status >= 400 && error.status < 600 ? error.status : 500;
  res.status(status).json({ error: process.env.NODE_ENV === 'production' && status >= 500 ? 'Internal server error.' : error.message });
});

const server = app.listen(port, () => {
  console.log(`APPRECIATE v1.40 API listening on port ${port}`);
});
const shutdown = (signal) => {
  console.log(`APPRECIATE received ${signal}; closing connections.`);
  server.close(() => db.pool.end().finally(() => process.exit(0)));
  setTimeout(() => process.exit(1), 10000).unref();
};
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
