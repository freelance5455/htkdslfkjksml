// ===== Data =====
const PAYMENT = {
  bkash: {
    name: "bKash",
    number: "01939466141",
    theme: "bkash-theme",
    color: "#e2136e",
    steps: [
      "bKash অ্যাপে যান → Send Money",
      "উপরের নাম্বারে টাকা পাঠান",
      "Amount = প্যাকেজের দাম",
      "Reference এ লিখুন: RabbiTopUp",
      "TrxID কপি করে নিচে দিন"
    ]
  },
  nagad: {
    name: "Nagad",
    number: "01917017133",
    theme: "nagad-theme",
    color: "#f15a22",
    steps: [
      "Nagad অ্যাপে যান → Send Money",
      "উপরের নাম্বারে টাকা পাঠান",
      "Amount = প্যাকেজের দাম",
      "Reference এ লিখুন: RabbiTopUp",
      "TrxID কপি করে নিচে দিন"
    ]
  },
  rocket: {
    name: "Rocket",
    number: "01342060958",
    theme: "rocket-theme",
    color: "#8a2be2",
    steps: [
      "Rocket (*322#) বা অ্যাপে যান → Send Money",
      "উপরের নাম্বারে টাকা পাঠান",
      "Amount = প্যাকেজের দাম",
      "Reference এ লিখুন: RabbiTopUp",
      "TrxID কপি করে নিচে দিন"
    ]
  }
};

const DEMO_ORDERS = [
  { name: "রাকিব হাসান", pkg: "Weekly Membership", price: 20, status: "done" },
  { name: "সাদিয়া আক্তার", pkg: "115 Diamonds", price: 68, status: "done" },
  { name: "তানভীর আহমেদ", pkg: "2x Weekly", price: 38, status: "done" },
  { name: "নাফিসা ইসলাম", pkg: "240 Diamonds", price: 135, status: "done" },
  { name: "আরিফ খান", pkg: "Monthly Membership", price: 95, status: "progress" },
  { name: "মেহেদী হাসান", pkg: "505 Diamonds", price: 275, status: "done" },
  { name: "ফাহমিদা খাতুন", pkg: "35 Diamonds", price: 25, status: "done" },
  { name: "শাহরিয়ার", pkg: "1090 Diamonds", price: 580, status: "done" }
];

// ===== State =====
let selectedPkg = null;
let selectedMethod = null;

// ===== DOM =====
const orderModal = document.getElementById("orderModal");
const successModal = document.getElementById("successModal");
const modalClose = document.getElementById("modalClose");
const successClose = document.getElementById("successClose");
const modalTitle = document.getElementById("modalTitle");
const modalPkgName = document.getElementById("modalPkgName");
const modalPkgPrice = document.getElementById("modalPkgPrice");
const playerIdInput = document.getElementById("playerId");
const trxIdInput = document.getElementById("trxId");
const senderNumberInput = document.getElementById("senderNumber");
const payInstruction = document.getElementById("payInstruction");
const payBox = document.getElementById("payBox");
const submitOrderBtn = document.getElementById("submitOrder");
const orderList = document.getElementById("orderList");
const menuBtn = document.getElementById("menuBtn");
const mobileNav = document.getElementById("mobileNav");

// ===== Init =====
document.addEventListener("DOMContentLoaded", () => {
  renderOrders();
  bindPackageButtons();
  bindPayButtons();
  bindModalControls();
  bindFormValidation();
  menuBtn.addEventListener("click", () => {
    mobileNav.classList.toggle("open");
  });
  // Close mobile nav on link click
  mobileNav.querySelectorAll("a").forEach(a => {
    a.addEventListener("click", () => mobileNav.classList.remove("open"));
  });
});

// ===== Render Recent Orders =====
function renderOrders() {
  orderList.innerHTML = DEMO_ORDERS.map(o => `
    <div class="order-item">
      <div>
        <div class="name">${o.name}</div>
        <div class="pkg">${o.pkg} · ৳${o.price}</div>
      </div>
      <span class="status ${o.status}">${o.status === "done" ? "Completed" : "In Progress"}</span>
    </div>
  `).join("");
}

// ===== Package Buy Buttons =====
function bindPackageButtons() {
  document.querySelectorAll(".buy-btn").forEach(btn => {
    btn.addEventListener("click", (e) => {
      const card = e.target.closest(".pkg-card");
      selectedPkg = {
        name: card.dataset.name,
        price: card.dataset.price,
        dia: card.dataset.dia
      };
      openOrderModal();
    });
  });
}

function openOrderModal() {
  modalPkgName.textContent = selectedPkg.name;
  modalPkgPrice.textContent = `৳ ${selectedPkg.price}`;
  modalTitle.textContent = "অর্ডার করুন";
  // Reset form
  playerIdInput.value = "";
  trxIdInput.value = "";
  senderNumberInput.value = "";
  selectedMethod = null;
  payInstruction.style.display = "none";
  document.querySelectorAll(".pay-btn").forEach(b => b.classList.remove("active"));
  submitOrderBtn.disabled = true;
  orderModal.classList.add("open");
  document.body.style.overflow = "hidden";
}

// ===== Payment Method Select =====
function bindPayButtons() {
  document.querySelectorAll(".pay-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const method = btn.dataset.method;
      selectedMethod = method;
      document.querySelectorAll(".pay-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      showPayInstruction(method);
      validateForm();
    });
  });
}

function showPayInstruction(method) {
  const p = PAYMENT[method];
  payBox.className = `pay-box ${p.theme}`;
  payBox.innerHTML = `
    <div class="pay-title">${p.name} তে সেন্ড মানি করুন</div>
    <div>নাম্বার:</div>
    <div class="pay-number" id="payNumber">${p.number}</div>
    <button type="button" class="copy-btn" onclick="copyNumber('${p.number}')">📋 নাম্বার কপি করুন</button>
    <div class="pay-steps">
      ${p.steps.map((s, i) => `${i + 1}. ${s}`).join("<br>")}
    </div>
  `;
  payInstruction.style.display = "block";
}

function copyNumber(num) {
  navigator.clipboard.writeText(num).then(() => {
    const btn = document.querySelector(".copy-btn");
    if (btn) {
      btn.textContent = "✅ কপি হয়েছে!";
      setTimeout(() => { btn.textContent = "📋 নাম্বার কপি করুন"; }, 2000);
    }
  }).catch(() => {
    alert("নাম্বার: " + num);
  });
}

// ===== Form Validation =====
function bindFormValidation() {
  [playerIdInput, trxIdInput, senderNumberInput].forEach(input => {
    input.addEventListener("input", validateForm);
  });
}

function validateForm() {
  const pid = playerIdInput.value.trim();
  const trx = trxIdInput.value.trim();
  const hasMethod = !!selectedMethod;
  // Basic check: Player ID at least 6 digits, TrxID at least 5 chars when method selected
  const valid = pid.length >= 6 && /^\d+$/.test(pid) && hasMethod && trx.length >= 5;
  submitOrderBtn.disabled = !valid;
}

// ===== Submit Order =====
function bindModalControls() {
  modalClose.addEventListener("click", closeOrderModal);
  successClose.addEventListener("click", () => {
    successModal.classList.remove("open");
    document.body.style.overflow = "";
  });
  orderModal.addEventListener("click", (e) => {
    if (e.target === orderModal) closeOrderModal();
  });
  successModal.addEventListener("click", (e) => {
    if (e.target === successModal) {
      successModal.classList.remove("open");
      document.body.style.overflow = "";
    }
  });
  submitOrderBtn.addEventListener("click", handleSubmit);
}

function closeOrderModal() {
  orderModal.classList.remove("open");
  document.body.style.overflow = "";
}

function handleSubmit() {
  const pid = playerIdInput.value.trim();
  const trx = trxIdInput.value.trim();
  const sender = senderNumberInput.value.trim();

  if (!selectedPkg || !selectedMethod) return;

  // Generate fake order ID
  const orderId = "RT" + Date.now().toString().slice(-8);

  // In a real site you would send this to backend
  console.log("Order submitted:", {
    package: selectedPkg.name,
    price: selectedPkg.price,
    playerId: pid,
    method: selectedMethod,
    trxId: trx,
    senderNumber: sender,
    orderId
  });

  closeOrderModal();

  // Show success
  document.getElementById("orderIdShow").textContent = orderId;
  document.getElementById("successMsg").textContent =
    `${selectedPkg.name} (৳${selectedPkg.price}) অর্ডারটি গ্রহণ করা হয়েছে। Player ID: ${pid}। ১-৫ মিনিটের মধ্যে ডেলিভারি হবে।`;
  successModal.classList.add("open");
  document.body.style.overflow = "hidden";

  // Optionally add to recent orders (demo)
  DEMO_ORDERS.unshift({
    name: "আপনি",
    pkg: selectedPkg.name,
    price: selectedPkg.price,
    status: "progress"
  });
  if (DEMO_ORDERS.length > 8) DEMO_ORDERS.pop();
  renderOrders();
}

// Make copyNumber available globally for onclick
window.copyNumber = copyNumber;
