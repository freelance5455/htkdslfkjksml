# دليل الإدارة v0.2 (عربي)

## 1) إعداد Supabase المجاني (تنفّذه بنفسك — لم يُنشأ أي خادم)
1. سجّل في supabase.com ثم **New project** (اختر منطقة قريبة وكلمة مرور قاعدة قوية واحفظها).
2. **SQL Editor** ← الصق `schema.sql` كاملاً ← Run. (يمكن إعادة تشغيله بأمان.)
3. **Authentication › Users › Add user**: أنشئ حسابك. ثم شغّل في SQL Editor:
   `insert into admins select id from auth.users where email='بريدك';`
   وفي Authentication › Sign In / Providers عطّل **Allow new users to sign up** حتى لا يسجّل غريب حساباً (وهو على أي حال لا يصبح مسؤولاً دون سطر admins).
4. نشر الوظيفة (على جهازك، يلزم Node):
   `npm i -g supabase` ← `supabase login` ← `supabase link --project-ref <REF>` ← انسخ `.env.example` إلى `.env` وغيّر القيمة ← `supabase secrets set --env-file .env` ← `supabase functions deploy device-api --no-verify-jwt`
   (مفتاح service_role يحقنه Supabase تلقائياً داخل الوظيفة؛ لا تنسخه إلى أي ملف.)
5. افتح `idara.html` وأدخل Project URL ومفتاح **anon** فقط.
6. اختبار الاتصال:
   `curl -X POST https://<REF>.supabase.co/functions/v1/device-api -H "content-type: application/json" -d '{"action":"check","product_slug":"x-x-x","license_key":"AAAAAAAAAAAAAAAAAAAAAAAA","install_id":"0000000000000000"}'`
   المتوقع: `{"ok":false,"status":"invalid"}` (يعني أن الوظيفة تعمل).

**حدود المجاني (راجعها على supabase.com/pricing فهي تتغير):** مشروعان، قاعدة 500MB، تخزين 1GB، **إيقاف المشروع بعد أسبوع بلا نشاط**. انتقل لخطة Pro عند اقتراب القاعدة من 500MB، أو عند بيع تطبيقات يعتمد عملاؤك فيها على التحقق باستمرار، أو عندما لا يكفيك إيقاف المشروع الدوري.

## 2) ربط أول تطبيق
1. من «الإدارة» سجّل المنتج (المعرّف مثل `my-store`)، أنشئ عميلاً ثم ترخيصاً.
2. انسخ `sdk/idara-sdk.js` إلى تطبيقك وحمّله بـ `<script>`، وانسخ نمط `examples/example-app.html` (endpoint = رابط الوظيفة).
3. أرسل المفتاح للعميل؛ يدخله مرة واحدة فيتم التفعيل ويُسجَّل أول تفعيل وآخر اتصال.
- **بلا إنترنت:** SDK يحفظ آخر حالة معروفة ويمنحك `mode`: `valid` / `offline_grace` / `needs_verification`، و`localDataAccess` دائماً true. لا تحذف بيانات العميل ولا تمنع تصديرها.
- **إيقاف الترخيص لا يسري فوراً على جهاز غير متصل**؛ يسري عند أول اتصال، أو بعد انتهاء فترة السماح (grace_days).
- التطبيقات القديمة التي لا تحوي SDK لا يمكن التحكم بها عن بُعد.
- الأوامر: `pending → delivered → acknowledged/failed`؛ لا تُعد منفذة إلا بتأكيد التطبيق. لا يوجد أي تنفيذ لكود عن بُعد؛ الأنواع محددة: refresh_settings, show_notice, check_update, recheck_license.

## 3) تحويل «الإدارة» إلى APK (Capacitor — لم يُنفَّذ هنا)
يلزم Node وAndroid Studio:
`mkdir idara-app && cd idara-app && npm init -y && npm i @capacitor/core @capacitor/cli @capacitor/android`
`npx cap init "الإدارة" com.mohamedjamal.idara --web-dir=www` ← ضع `idara.html` باسم `www/index.html` ← **ضع مكتبة supabase-js محلياً في www** وغيّر وسم script إليها (حتى يعمل التطبيق دون CDN)
`npx cap add android && npx cap sync` ← `npx cap open android` ← Build › Generate Signed Bundle/APK (أنشئ keystore واحفظه واحتفظ بنسخة؛ فقدانه يمنع التحديثات).
HTML وحده ليس APK؛ الغلاف هو ما يصنع التطبيق.

## 4) حالة الاختبار (صادقة)
| البند | النتيجة |
|---|---|
| صياغة JS في idara.html وSDK | ✅ فُحصت |
| منطق SDK (تفعيل، انقطاع، فترة سماح، تأكيد الأوامر، الإيقاف) | ✅ 9/9 باختبار محاكاة |
| schema.sql وdevice-api وواجهة الإدارة مع Supabase حي | ⏳ لم تُختبر: لا بيئة Postgres/Deno ولا اتصال خادم هنا |
| تسجيل الدخول، منع غير المسؤول، RLS، تفعيل جهاز حقيقي، حد الأجهزة | ⏳ تحتاج مشروعك |
| الأمان: لا service_role في الواجهة/SDK، لا سياسات لـ anon | ✅ بالمراجعة (وليس بالاختبار) |

**مشكلات معروفة:** سباق نظري عند تفعيل جهازين في اللحظة نفسها قد يتجاوز حد الأجهزة بجهاز (يُعالج لاحقاً بدالة SQL ذرّية)؛ جدول activation_attempts يحتاج تنظيفاً دورياً؛ واجهة idara.html لم تُوسَّع بعد (الأجهزة، الأوامر، الإعدادات عن بُعد، تفاصيل العميل/التطبيق، لوحة موسّعة) وتبقى متوافقة مع المخطط الجديد.
