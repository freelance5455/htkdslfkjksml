// device-api: نقطة الاتصال الوحيدة لتطبيقات العملاء. تعمل بمفتاح service_role الذي يحقنه Supabase في الخادم فقط.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";
const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
const cors = { "access-control-allow-origin": "*", "access-control-allow-headers": "content-type,authorization,apikey", "access-control-allow-methods": "POST,OPTIONS" };
const J = (b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { ...cors, "content-type": "application/json" } });
const sha = async (s: string) => [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s)))].map(x => x.toString(16).padStart(2, "0")).join("");
const UUID = /^[0-9a-f-]{36}$/i;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });
  if (req.method !== "POST") return J({ ok: false, status: "bad_method" }, 405);
  let b: any; try { b = await req.json(); } catch { return J({ ok: false, status: "bad_json" }, 400); }
  const { action, product_slug: slug, license_key: key, install_id: iid, app_version: ver = "", acks = [] } = b ?? {};
  if (!(["activate", "check"].includes(action) && /^[a-z0-9-]{3,40}$/.test(slug ?? "") && /^[A-Z0-9]{24}$/.test(key ?? "")
    && /^[A-Za-z0-9-]{16,64}$/.test(iid ?? "") && String(ver).length <= 20)) return J({ ok: false, status: "bad_request" }, 400);

  const ip = await sha((req.headers.get("x-forwarded-for") ?? "").split(",")[0] + (Deno.env.get("IP_SALT") ?? ""));
  const { count: fails } = await sb.from("activation_attempts").select("*", { count: "exact", head: true })
    .eq("ip_hash", ip).eq("ok", false).gte("created_at", new Date(Date.now() - 600000).toISOString());
  if ((fails ?? 0) >= 20) return J({ ok: false, status: "rate_limited" }, 429);
  const log = (ok: boolean, reason: string) => sb.from("activation_attempts").insert({ ip_hash: ip, ok, reason });

  const { data: lic } = await sb.from("licenses")
    .select("id,status,expires_at,max_devices,grace_days,products!inner(id,slug,status,version,min_version)")
    .eq("license_key", key).eq("products.slug", slug).maybeSingle();
  if (!lic) { await log(false, "not_found"); return J({ ok: false, status: "invalid" }); }
  const p: any = lic.products;
  let status = "active";
  if (lic.status !== "active") status = "suspended";
  else if (lic.expires_at && new Date(lic.expires_at) < new Date()) status = "expired";
  else if (p.status !== "active") status = "product_disabled";

  let { data: inst } = await sb.from("installations").select("id").eq("license_id", lic.id).eq("install_id", iid).maybeSingle();
  if (!inst) {
    if (action !== "activate" || status !== "active") { await log(false, "not_activated"); return J({ ok: false, status: action === "activate" ? status : "not_activated" }); }
    const { count } = await sb.from("installations").select("*", { count: "exact", head: true }).eq("license_id", lic.id);
    if ((count ?? 0) >= lic.max_devices) { await log(false, "device_limit"); return J({ ok: false, status: "device_limit" }); }
    const ins = await sb.from("installations").insert({ license_id: lic.id, install_id: iid, app_version: ver, last_result: status }).select("id").single();
    if (ins.error) return J({ ok: false, status: "server_error" }, 500);
    inst = ins.data; await sb.from("audit_logs").insert({ action: "device.activate", entity: "installation", entity_id: inst.id, details: { slug } });
  } else await sb.from("installations").update({ last_seen: new Date().toISOString(), app_version: ver, last_result: status }).eq("id", inst.id);
  await log(true, status);

  for (const a of (Array.isArray(acks) ? acks.slice(0, 20) : [])) {
    if (UUID.test(a?.id ?? "") && ["acknowledged", "failed"].includes(a.status))
      await sb.from("commands").update({ status: a.status, acked_at: new Date().toISOString(), error: a.status === "failed" ? String(a.error ?? "").slice(0, 200) : null })
        .eq("id", a.id).eq("installation_id", inst!.id).in("status", ["pending", "delivered"]);
  }
  const base = { server_time: new Date().toISOString(), expires_at: lic.expires_at, grace_days: lic.grace_days };
  if (status !== "active") return J({ ok: false, status, ...base });

  const now = new Date().toISOString();
  const [st, nt, cm] = await Promise.all([
    sb.from("app_settings").select("key,value").eq("product_id", p.id),
    sb.from("notifications").select("id,title,body").eq("product_id", p.id).or(`expires_at.is.null,expires_at.gt.${now}`).order("created_at", { ascending: false }).limit(10),
    sb.from("commands").select("id,type,payload,status").eq("installation_id", inst!.id).in("status", ["pending", "delivered"]).order("created_at").limit(20)]);
  const pend = (cm.data ?? []).filter((c) => c.status === "pending").map((c) => c.id);
  if (pend.length) await sb.from("commands").update({ status: "delivered", delivered_at: now }).in("id", pend);
  return J({ ok: true, status, ...base, latest_version: p.version, min_version: p.min_version,
    settings: Object.fromEntries((st.data ?? []).map((s) => [s.key, s.value])), notices: nt.data ?? [],
    commands: (cm.data ?? []).map(({ id, type, payload }) => ({ id, type, payload })) });
});
