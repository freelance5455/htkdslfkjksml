/* Idara SDK v0.2 — يُضمَّن في تطبيقات HTML. لا يحتوي أي أسرار؛ يحفظ معرّف تثبيت عشوائياً لكل نسخة. */
(function (g) {
  class Idara {
    constructor(o) { this.ep = o.endpoint; this.slug = o.productSlug; this.ver = o.appVersion; this.p = 'idara:' + o.productSlug + ':'; this.h = {}; }
    _g(k, d) { try { return JSON.parse(localStorage.getItem(this.p + k)) ?? d; } catch (e) { return d; } }
    _s(k, v) { try { localStorage.setItem(this.p + k, JSON.stringify(v)); } catch (e) { } }
    get installId() { let i = this._g('iid'); if (!i) { i = crypto.randomUUID(); this._s('iid', i); } return i; }
    on(type, fn) { this.h[type] = fn; return this; }           // fn(payload) تُرجع true/Promise عند النجاح
    async activate(key) { this._s('key', String(key).trim().toUpperCase().replace(/\s/g, '')); return this.check('activate'); }
    async check(action = 'check') {
      const key = this._g('key'); if (!key) return this.state();
      const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), 10000);
      try {
        const r = await fetch(this.ep, { method: 'POST', signal: ctl.signal, headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ action, product_slug: this.slug, license_key: key, install_id: this.installId, app_version: this.ver, acks: this._g('acks', []) }) });
        const d = await r.json(); this._s('acks', []);
        this._s('last', { ok: !!d.ok, status: d.status, at: Date.now(), grace_days: d.grace_days ?? 7, expires_at: d.expires_at });
        this._s('net', true);
        if (d.ok) {
          this._s('settings', d.settings); this._s('notices', d.notices); this._s('versions', { latest: d.latest_version, min: d.min_version });
          const acks = [];
          for (const c of d.commands || []) {
            try { await (this.h[c.type] ? this.h[c.type](c.payload) : Promise.reject(new Error('unsupported'))); acks.push({ id: c.id, status: 'acknowledged' }); }
            catch (e) { acks.push({ id: c.id, status: 'failed', error: String(e.message || e) }); }
          }
          this._s('acks', acks);                               // تُرسل مع الاتصال التالي (آمن عند الانقطاع)
        }
      } catch (e) { this._s('net', false); } finally { clearTimeout(t); }
      return this.state();
    }
    settings() { return this._g('settings', {}); }
    notices() { return this._g('notices', []); }
    state() {
      const l = this._g('last'), net = this._g('net', false);
      if (!l) return { mode: 'unactivated', localDataAccess: true };
      const age = Date.now() - l.at, out = { lastVerifiedAt: new Date(l.at).toISOString(), localDataAccess: true };
      if (!l.ok) return { ...out, mode: l.status };                 // suspended | expired | device_limit | invalid ...
      if (net) return { ...out, mode: 'valid' };
      return { ...out, mode: age <= l.grace_days * 864e5 ? 'offline_grace' : 'needs_verification',
        note: 'هذه آخر حالة معروفة وليست الحالة الحالية؛ الإيقاف لا يُطبَّق على جهاز غير متصل قبل أن يتحقق من الخادم.' };
    }
  }
  g.Idara = Idara;
})(window);
/* ملاحظة: localDataAccess دائماً true — لا تحذف بيانات العميل ولا تمنع تصديرها بسبب حالة الترخيص. */
