-- الإدارة v0.2 — مخطط كامل وقابل لإعادة التشغيل. الصقه في Supabase > SQL Editor ثم Run.
create table if not exists admins(user_id uuid primary key references auth.users on delete cascade);
create table if not exists products(
 id uuid primary key default gen_random_uuid(), slug text unique not null check(slug ~ '^[a-z0-9-]{3,40}$'),
 name text not null, type text not null default 'app' check(type in('app','game','tool','store','accounts')),
 description text, version text default '1.0.0', min_version text, icon_url text,
 status text not null default 'active' check(status in('active','suspended')), notes text, created_at timestamptz default now());
create table if not exists product_versions(
 id uuid primary key default gen_random_uuid(), product_id uuid not null references products on delete cascade,
 version text not null, notes text, released_at timestamptz default now(), unique(product_id,version));
create table if not exists customers(
 id uuid primary key default gen_random_uuid(), name text not null, contact text, notes text, created_at timestamptz default now());
create table if not exists licenses(
 id uuid primary key default gen_random_uuid(),
 product_id uuid not null references products on delete restrict,
 customer_id uuid not null references customers on delete restrict,
 license_key text unique not null default upper(substr(replace(gen_random_uuid()::text||gen_random_uuid()::text,'-',''),1,24)),
 kind text not null default 'perpetual' check(kind in('perpetual','timed')),
 expires_at timestamptz, max_devices int not null default 1 check(max_devices>0),
 status text not null default 'active' check(status in('active','suspended')),
 sold_at date default current_date, notes text,
 created_at timestamptz default now(), updated_at timestamptz default now(),
 check(kind='perpetual' or expires_at is not null));
alter table licenses add column if not exists grace_days int not null default 7 check(grace_days between 0 and 90);
alter table licenses add column if not exists suspend_reason text;
alter table licenses add column if not exists suspended_at timestamptz;
alter table licenses add column if not exists suspended_by uuid;
create table if not exists installations(
 id uuid primary key default gen_random_uuid(), license_id uuid not null references licenses on delete cascade,
 install_id text not null, app_version text, last_seen timestamptz default now(), unique(license_id,install_id));
alter table installations add column if not exists first_activated_at timestamptz not null default now();
alter table installations add column if not exists last_result text;
create table if not exists app_users(
 id uuid primary key default gen_random_uuid(), product_id uuid not null references products on delete cascade,
 customer_id uuid references customers on delete set null, external_ref text, display_name text,
 created_at timestamptz default now(), unique(product_id,external_ref));
create table if not exists app_settings(
 id uuid primary key default gen_random_uuid(), product_id uuid not null references products on delete cascade,
 key text not null check(key ~ '^[a-z][a-z0-9_.]{1,48}$'), value_type text not null check(value_type in('string','boolean','number')),
 value jsonb not null, updated_at timestamptz default now(), unique(product_id,key),
 check((value_type='string' and jsonb_typeof(value)='string' and length(value::text)<=600)
    or (value_type='boolean' and jsonb_typeof(value)='boolean') or (value_type='number' and jsonb_typeof(value)='number')));
create table if not exists notifications(
 id uuid primary key default gen_random_uuid(), product_id uuid not null references products on delete cascade,
 title text not null check(length(title)<=80), body text check(length(body)<=500),
 created_at timestamptz default now(), expires_at timestamptz);
create table if not exists commands(
 id uuid primary key default gen_random_uuid(), installation_id uuid not null references installations on delete cascade,
 type text not null check(type in('refresh_settings','show_notice','check_update','recheck_license')),
 payload jsonb not null default '{}', status text not null default 'pending' check(status in('pending','delivered','acknowledged','failed')),
 created_by uuid default auth.uid(), created_at timestamptz default now(), delivered_at timestamptz, acked_at timestamptz, error text);
create table if not exists activation_attempts(
 id bigserial primary key, ip_hash text not null, ok boolean not null, reason text, created_at timestamptz default now());
create table if not exists audit_logs(
 id bigserial primary key, actor uuid default auth.uid(), action text not null, entity text, entity_id text,
 details jsonb, created_at timestamptz default now());
create index if not exists i_lic_prod on licenses(product_id); create index if not exists i_lic_cust on licenses(customer_id);
create index if not exists i_inst_lic on installations(license_id); create index if not exists i_inst_seen on installations(last_seen desc);
create index if not exists i_cmd_inst on commands(installation_id,status); create index if not exists i_att on activation_attempts(ip_hash,created_at desc);

create or replace function is_admin() returns boolean language sql security definer stable set search_path=public as
$$ select exists(select 1 from admins where user_id=auth.uid()) $$;
create or replace function lic_before_update() returns trigger language plpgsql security definer set search_path=public as $$
begin
 new.updated_at=now();
 if new.status is distinct from old.status then
  if new.status='suspended' then new.suspended_at=now(); new.suspended_by=auth.uid(); new.suspend_reason=coalesce(new.suspend_reason,'غير محدد');
  else new.suspended_at=null; new.suspended_by=null; new.suspend_reason=null; end if;
  insert into audit_logs(action,entity,entity_id,details) values('license.status','license',new.id::text,jsonb_build_object('from',old.status,'to',new.status,'reason',new.suspend_reason));
 end if; return new; end $$;
drop trigger if exists t_lic on licenses; create trigger t_lic before update on licenses for each row execute function lic_before_update();
create or replace function dashboard_stats() returns jsonb language sql security definer stable set search_path=public as $$
 select case when not is_admin() then null else jsonb_build_object(
  'products',(select count(*) from products),
  'by_type',(select coalesce(jsonb_object_agg(type,c),'{}'::jsonb) from (select type,count(*) c from products group by type) t),
  'customers',(select count(*) from customers),'app_users',(select count(*) from app_users),
  'installations',(select count(*) from installations),
  'seen_24h',(select count(*) from installations where last_seen>now()-interval '24 hours'),
  'seen_7d',(select count(*) from installations where last_seen>now()-interval '7 days'),
  'seen_30d',(select count(*) from installations where last_seen>now()-interval '30 days'),
  'lic_active',(select count(*) from licenses where status='active' and (expires_at is null or expires_at>now())),
  'lic_suspended',(select count(*) from licenses where status='suspended'),
  'lic_expired',(select count(*) from licenses where status='active' and expires_at<=now())) end $$;
revoke all on function dashboard_stats() from public, anon; grant execute on function dashboard_stats() to authenticated;

do $$ declare t text; begin
 foreach t in array array['admins','products','product_versions','customers','licenses','installations','app_users','app_settings','notifications','commands','activation_attempts','audit_logs'] loop
  execute format('alter table %I enable row level security',t); execute format('drop policy if exists adm on %I',t);
  if t='audit_logs' or t='activation_attempts' then
   execute format('create policy adm on %I for select to authenticated using(is_admin())',t);
   if t='audit_logs' then execute 'drop policy if exists adm_ins on audit_logs'; execute 'create policy adm_ins on audit_logs for insert to authenticated with check(is_admin())'; end if;
  else execute format('create policy adm on %I for all to authenticated using(is_admin()) with check(is_admin())',t); end if;
 end loop; end $$;
-- لا توجد أي سياسة لـ anon: تطبيقات العملاء لا تصل للجداول إطلاقاً، بل عبر الدالة device-api (service_role داخل الخادم فقط).
-- بعد إنشاء حسابك من Authentication > Users:  insert into admins select id from auth.users where email='you@example.com';
