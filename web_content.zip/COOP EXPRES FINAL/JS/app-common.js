// ============================================================
// Coop Express - Fungsi kongsi (helper)
// ============================================================

/** Elak XSS + elak tanda kutip memecahkan atribut HTML */
export function esc(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function rm(value) {
  return 'RM ' + Number(value || 0).toFixed(2);
}

export function tarikhSekarang() {
  const d = new Date();
  return d.toLocaleDateString('ms-MY', { day: 'numeric', month: 'short', year: 'numeric' }) +
    ', ' + d.toLocaleTimeString('ms-MY', { hour: '2-digit', minute: '2-digit' });
}

/** Tema gelap global - panggil seawal mungkin pada setiap halaman */
export function applyTheme() {
  const run = () => {
    if (localStorage.getItem('theme') === 'dark') document.body.classList.add('dark-mode');
    else document.body.classList.remove('dark-mode');
  };
  if (document.body) run();
  else document.addEventListener('DOMContentLoaded', run);
}

/** Notifikasi ringkas (ganti alert yang menjengkelkan) */
export function toast(message, type = 'info') {
  let host = document.getElementById('coop-toast-host');
  if (!host) {
    host = document.createElement('div');
    host.id = 'coop-toast-host';
    host.style.cssText = 'position:fixed;left:50%;transform:translateX(-50%);bottom:84px;z-index:9999;display:flex;flex-direction:column;gap:8px;align-items:center;pointer-events:none;width:calc(100% - 32px);max-width:420px;';
    document.body.appendChild(host);
  }
  const el = document.createElement('div');
  const bg = type === 'error' ? '#b91c1c' : (type === 'success' ? '#15803d' : '#0f172a');
  el.style.cssText = `background:${bg};color:#fff;padding:11px 16px;border-radius:12px;font-size:0.85rem;font-weight:600;box-shadow:0 6px 18px rgba(0,0,0,.18);opacity:0;transition:opacity .2s;text-align:center;`;
  el.textContent = message;
  host.appendChild(el);
  requestAnimationFrame(() => { el.style.opacity = '1'; });
  setTimeout(() => {
    el.style.opacity = '0';
    setTimeout(() => el.remove(), 250);
  }, 2600);
}

/** Satu sumber kebenaran untuk status pesanan */
export const STATUS = {
  menunggu: { label: 'Menunggu pengesahan koperasi', badge: 'badge-menunggu' },
  diproses: { label: 'Sedang disediakan', badge: 'badge-diproses' },
  dihantar: { label: 'Dalam perjalanan bersama runner', badge: 'badge-dihantar' },
  ambil: { label: 'Sedia diambil di kaunter', badge: 'badge-ambil' },
  selesai: { label: 'Pesanan selesai', badge: 'badge-selesai' },
  ditolak: { label: 'Pesanan ditolak', badge: 'badge-ditolak' }
};

export function statusLabel(key) {
  return (STATUS[key] || STATUS.menunggu).label;
}
export function statusBadge(key) {
  return (STATUS[key] || STATUS.menunggu).badge;
}

/** Kecilkan & mampatkan gambar sebelum simpan ke Firestore (had dokumen 1 MB) */
export function compressImage(file, maxSize = 900, quality = 0.6) {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error('Hanya fail gambar (JPG/PNG) dibenarkan.'));
      return;
    }
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Gagal membaca fail.'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Fail gambar rosak.'));
      img.onload = () => {
        let { width, height } = img;
        const scale = Math.min(1, maxSize / Math.max(width, height));
        width = Math.round(width * scale);
        height = Math.round(height * scale);

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);

        let out = canvas.toDataURL('image/jpeg', quality);
        if (out.length > 700000) out = canvas.toDataURL('image/jpeg', 0.4);
        if (out.length > 700000) {
          reject(new Error('Gambar terlalu besar. Sila guna gambar yang lebih kecil.'));
          return;
        }
        resolve(out);
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

/** Papar gambar resit dalam tetingkap penuh */
export function showImageOverlay(dataUrl) {
  const wrap = document.createElement('div');
  wrap.style.cssText = 'position:fixed;inset:0;background:rgba(15,23,42,.9);z-index:10000;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:20px;gap:14px;';
  wrap.innerHTML = `
    <img src="${dataUrl}" alt="Resit pembayaran" style="max-width:100%;max-height:80vh;border-radius:12px;background:#fff;">
    <button type="button" style="background:#fff;border:none;padding:10px 22px;border-radius:20px;font-weight:700;cursor:pointer;">Tutup</button>`;
  wrap.addEventListener('click', () => wrap.remove());
  document.body.appendChild(wrap);
}
