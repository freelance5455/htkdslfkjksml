import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCA-2ebYul0Rkuyb3bBH8sRYmnk5JMB6JQ",
  authDomain: "coop-express-c28ed.firebaseapp.com",
  projectId: "coop-express-c28ed",
  storageBucket: "coop-express-c28ed.appspot.com",
  messagingSenderId: "741935921962",
  appId: "1:741935921962:web:2a0a1b4f94cf5befa87c53"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);