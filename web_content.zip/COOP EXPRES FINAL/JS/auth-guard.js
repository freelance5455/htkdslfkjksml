import { db, auth } from './firebase-config.js';
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

export function homeFor(role) {
  if (role === 'admin') return 'admin.html';
  if (role === 'runner') return 'runner.html';
  return 'menu.html';
}

export async function logout() {
  try {
    await signOut(auth);
    localStorage.clear();
    location.replace('login.html');
  } catch (e) {
    console.error("Ralat log keluar:", e);
  }
}

export async function guard(allowedRoles = []) {
  return new Promise((resolve) => {
    onAuthStateChanged(auth, async (user) => {
      if (!user) {
        location.replace('login.html');
        return;
      }
      try {
        const snap = await getDoc(doc(db, 'users', user.uid));
        if (!snap.exists()) {
          location.replace('login.html');
          return;
        }
        const data = snap.data();
        const role = data.role || 'pelajar';
        if (allowedRoles.length > 0 && !allowedRoles.includes(role)) {
          location.replace(homeFor(role));
          return;
        }
        resolve({ uid: user.uid, email: user.email, ...data });
      } catch (err) {
        console.error("Gagal baca profil:", err);
        alert("Gagal menghubungi pangkalan data.");
      }
    });
  });
}