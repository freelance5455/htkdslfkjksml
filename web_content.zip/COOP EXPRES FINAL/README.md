# Coop Express — versi dibaiki

Aplikasi web koperasi kampus (pelajar, runner, admin) menggunakan Firebase Auth + Firestore.

## Struktur fail

```
index.html              Splash + pengalihan ikut peranan (titik masuk)
splashscreen.html       Pengalihan ke index.html (untuk pautan lama)
login.html              Log masuk
register.html           Pendaftaran pelajar
forgot-password.html    Pemulihan kata laluan
menu.html               Katalog pelajar (stok masa nyata)
cart.html               Troli
payment.html            Checkout + resit + potongan stok
orders.html             Status pesanan pelajar
profile.html            Profil pelajar
settings.html           Tetapan (semua peranan)
change-password.html    Tukar kata laluan (Firebase sebenar)
admin.html              Papan pemuka admin
admin-stock.html        Inventori (tambah / sunting / padam / stok)
admin-profile.html      Profil admin + arkib + senarai pasukan
runner.html             Tugasan runner
runner-history.html     Sejarah & upah runner
runner-profile.html     Profil runner
firestore.rules         Peraturan keselamatan (WAJIB dipasang)
JS/firebase-config.js   Konfigurasi Firebase (isi kunci anda)
JS/auth-guard.js        Kawalan akses ikut peranan
JS/app-common.js        Helper: escape, wang, tema, toast, mampat gambar
```

## Langkah pemasangan

1. **Firebase Console → Project settings → Web app** — salin config, tampal ke `JS/firebase-config.js`.
2. **Authentication → Sign-in method** — hidupkan *Email/Password*.
3. **Firestore Database** — cipta pangkalan data (mod production).
4. **Firestore → Rules** — tampal isi `firestore.rules`, tekan *Publish*.
5. Jalankan projek melalui pelayan HTTP (modul ES tidak berfungsi dengan `file://`):
   - VS Code: sambungan **Live Server**, atau
   - `python3 -m http.server 8000` kemudian buka `http://localhost:8000`
   - atau `firebase deploy --only hosting`
6. Daftar satu akaun melalui `register.html` (jadi **pelajar** secara automatik).
7. Untuk akaun **admin** / **runner**: daftar akaun biasa, kemudian di Firestore Console
   buka `users/{uid}` dan tukar medan `role` kepada `admin` atau `runner`.
8. Log masuk sebagai admin → `admin-stock.html` → **Isi menu contoh** untuk data permulaan.

## Model data

**users/{uid}** — `nama, noMatrik, phone, email, avatar, role, createdAt`

**menuItems/{id}** — `name, price, stock, category (makanan|alat-tulis|air), catGroup (food|mart), icon`

**orders/{id}** — `studentUid, studentEmail, studentName, studentPhone, items[], subtotal,
deliveryFee, totalAmount, deliveryType (cod|pickup), address, paymentMethod (qr|cod),
receiptImage, verified, status, statusLabel, badgeClass, rejectReason, runnerUid, runnerName,
archived, date, createdAt, verifiedAt, claimedAt, completedAt, rejectedAt`

## Aliran status pesanan

```
menunggu ──(admin sahkan)──> diproses ──┬─ pickup ─> ambil ─> selesai ─> arkib
    │                                    └─ cod ────> dihantar ─> selesai ─> arkib
    └──(admin tolak, stok dipulangkan)──> ditolak
```

## Apa yang dibaiki berbanding versi lama

| Masalah lama | Penyelesaian |
|---|---|
| Bayar satu kategori tetapi semua barang troli masuk pesanan | `cart.html` menghantar senarai ID terpilih; `payment.html` hanya memproses ID itu |
| Resit tidak pernah disimpan | Gambar dimampatkan dan disimpan dalam dokumen pesanan; admin & pelajar boleh melihatnya |
| Tukar kata laluan palsu (OTP terima apa-apa) | `reauthenticateWithCredential` + `updatePassword` sebenar |
| Tiada kawalan akses | `JS/auth-guard.js` pada setiap halaman + `firestore.rules` |
| Logout tidak `signOut()` | `logout()` memanggil `signOut()` dan mengosongkan localStorage |
| Tukar e-mel memutuskan sejarah pesanan | Pesanan dikaitkan dengan `studentUid`; e-mel kini baca sahaja |
| Dua runner boleh ambil pesanan sama | Tuntutan tugasan melalui `runTransaction` + `runnerUid` |
| Stok boleh jadi negatif | Potongan stok dalam `runTransaction` dengan semakan baki |
| Harga troli boleh basi/diubah | Harga dan subtotal dikira semula daripada Firestore semasa transaksi |
| Pesanan ditolak terus dipadam | Status `ditolak` + sebab dipaparkan kepada pelajar, stok dipulangkan |
| WhatsApp tanpa nombor | Nombor telefon pelajar disimpan dalam pesanan; butang WhatsApp & telefon berfungsi |
| Sejarah/profil runner & admin data palsu | Semua daripada Firestore, termasuk pengiraan upah |
| Stok hanya boleh naik/turun | CRUD penuh: tambah, sunting, padam barang |
| Mod gelap hanya di tetapan | `applyTheme()` pada semua halaman |
| Perlu tekan "Segar semula" | `onSnapshot` — kemas kini masa nyata |
| Nama barang dengan `'` memecahkan butang | Semua output melalui `esc()` |
| Kategori "Makanan" sebenarnya "Semua" | Tab berasingan: Semua / Makanan / Alat tulis / Air |

## Had yang masih ada (bukan pepijat, tetapi baik untuk diketahui)

- Resit disimpan sebagai base64 di dalam dokumen Firestore (had 1 MB sedokumen). Untuk
  penggunaan sebenar, Firebase Storage lebih sesuai.
- Kod QR dijana melalui `api.qrserver.com` dan bukan QR DuitNow rasmi. Ganti dengan imej
  QR sebenar koperasi apabila ada.
- Tiada pemberitahuan tolak (push notification); status hanya dikemas kini semasa aplikasi dibuka.
- Peranan admin/runner ditetapkan secara manual di Console. Untuk pengurusan peranan dalam
  aplikasi, perlukan Cloud Functions dengan custom claims.
