AUTO TEXT COLOR - Final ZIP

এই ZIP-এ সম্পূর্ণ HTML/CSS/JavaScript app source আছে।
মূল ফাইল: index.html
ছবি: assets/profile.jpg

ফিচার:
- Text Input / Paste Area
- AUTO: Word / Letter-Character / Line / Custom styles
- 1,000 fixed vivid text colors
- 25 light/pastel background colors
- Text Size: Small / Medium / Large
- Day / Night
- History: open/delete
- Auto Save ON/OFF
- SAVE: HTML result file
- PDF: Android/browser Print -> Save as PDF
- SHARE: Android Web Share API; fallback copy
- Bengali Unicode / grapheme-safe character coloring

ব্যবহার:
HTML-to-APK converter-এ ZIP/HTML project হিসেবে index.html ব্যবহার করুন।
Internet ছাড়া মূল color engine ও settings কাজ করবে; Share/PDF আচরণ WebView/converter-এর support-এর ওপর নির্ভর করতে পারে।
