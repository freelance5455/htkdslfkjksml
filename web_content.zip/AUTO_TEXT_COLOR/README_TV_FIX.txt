AUTO TEXT COLOR — TV FIXED V7

এই V7 সংস্করণ Android 7.1.2 TV Box / পুরোনো WebView-এর জন্য ঠিক করা হয়েছে।

যা ঠিক করা হয়েছে:
• TV remote Arrow + OK/Enter navigation আরও নির্ভরযোগ্য
• Settings খুললে প্রথম অপশনে focus যায়
• Settings বন্ধ করলে focus আবার Settings বোতামে ফেরে
• Remote দিয়ে অপশন নির্বাচন করলে স্ক্রিনে scroll করে দেখায়
• পুরোনো WebView-এ focusable element শনাক্তকরণ নিরাপদ করা হয়েছে
• Touch/click অপশনগুলো রাখা হয়েছে
• মোবাইলের আগের মূল ফিচারগুলো রাখা হয়েছে

নোট: ZIP-টি HTML/Web App প্যাকেজ। Android 7.1.2-তে চালাতে এমন WebView/HTML-to-APK wrapper ব্যবহার করুন যা local HTML ও JavaScript সমর্থন করে।
