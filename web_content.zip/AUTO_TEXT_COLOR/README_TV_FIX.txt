AUTO TEXT COLOR — TV FIXED V8

Android 7.1.2 TV Box / পুরোনো WebView-এর জন্য V7-এর সমস্যাগুলো ঠিক করা হয়েছে।

মূল সংশোধন:
• TV-তে নিচের AUTO / SAVE / PDF / SHARE বাটন এখন পুরো প্রস্থে থাকবে—একটির ওপর আরেকটি চাপবে না।
• পুরোনো WebView-এর CSS min() নির্ভরতা সরানো হয়েছে।
• TV remote Arrow + OK/Enter navigation আরও স্থির করা হয়েছে।
• Settings খুললে Settings-এর ভিতরের অপশনগুলোতে focus যাবে।
• Touch/click বাটন রাখা হয়েছে।
• মোবাইলের মূল ফিচারগুলো রাখা হয়েছে।

নোট: এটি HTML/Web App ZIP। APK বানানোর সময় local HTML + JavaScript সমর্থনকারী WebView wrapper ব্যবহার করতে হবে।
