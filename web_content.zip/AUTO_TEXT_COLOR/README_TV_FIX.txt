AUTO TEXT COLOR — TV Settings Fix V13

V12-এর সব মূল ফিচার ও ফরম্যাট রাখা হয়েছে। Settings-এর remote/TV interaction শক্ত করা হয়েছে: click, touch এবং pointer interaction; Save Settings-এ সরাসরি event handling; localStorage-এর পাশাপাশি session fallback।

TV Box-এ Settings খুলে Color Style, Text Color, Background Color, Text Size, Day/Night, Auto Save এবং Save Settings পরীক্ষা করুন।
