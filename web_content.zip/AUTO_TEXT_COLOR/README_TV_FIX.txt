AUTO TEXT COLOR – TV BOX FIX

This version adds Android TV / D-pad remote support.
Use the remote Arrow keys to move focus and OK/Enter to activate buttons.
Settings can be opened with the gear button and all visible controls are keyboard/remote accessible.
Designed for older Android WebView devices such as Android 7.1.2 TV boxes.
