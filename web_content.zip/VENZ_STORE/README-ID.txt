VENZ STORE — Paket website Supabase
===================================

Desain mobile mengikuti referensi: banner biru, panel transaksi aman/garansi/bantuan, pilihan game, katalog kartu produk, pencarian dan navigasi bawah.

AKTIFKAN DATABASE (dari HP Android)
1. Buka https://supabase.com/dashboard dan buat project baru.
2. Di project, buka SQL Editor, buat query baru, salin semua isi file supabase-setup.sql, lalu Run.
3. Buka Project Settings > API (atau Data API), salin Project URL dan publishable key/anon key.
4. Isi nilai pada supabase-config.js. Jangan pernah memasukkan service_role/secret key ke website.
5. Buka Authentication > Users, buat user admin dengan email/password.
6. Salin UUID user admin dari daftar Users. Di SQL Editor jalankan:
   insert into public.admin_users(user_id) values ('UUID_ADMIN_ANDA');
   Ganti UUID_ADMIN_ANDA dengan UUID sebenarnya.
7. Hosting harus HTTPS. Anda dapat menggunakan hosting statis yang mendukung file JavaScript module; setelah upload folder, buka URL website.
8. Tekan ikon roda gigi di pojok bawah, login admin, lalu tambah produk.

CATATAN
- Sebelum konfigurasi Supabase, halaman memakai produk CONTOH lokal.
- Pesanan membuka WhatsApp tanpa nomor toko yang sudah ditentukan. Edit app.js, ganti https://wa.me/?text= dengan https://wa.me/62NOMORANDA?text= (nomor internasional tanpa +).
- Foto produk diunggah langsung lewat panel admin ke bucket Supabase Storage product-images. Jangan menaruh data sensitif pelanggan di katalog.
- Jangan pernah menaruh service_role key di kode frontend.
- Jalankan SQL sekali saja. Jika policy dengan nama sama sudah ada, hapus policy lama atau sesuaikan query.
\nPESAN WHATSAPP: tombol Pesan mengarah ke admin 6282372499032 dan otomatis mengisi nama produk serta harga.\nUPLOAD FOTO: admin dapat memilih foto FF/ML dari HP ketika menambahkan produk; foto disimpan di Supabase Storage.\n