VENZ STORE — Website katalog game dengan Firebase
=================================================

PENTING
- Website ini sudah punya tampilan responsif mirip referensi: banner biru, kartu transaksi aman/garansi/bantuan, kategori game, kartu produk dan navigasi bawah.
- Sebelum konfigurasi Firebase diisi, website menampilkan DATA CONTOH lokal. Data contoh bukan produk asli.
- Agar database sungguhan bekerja, Anda perlu membuat project Firebase sendiri dan mengisi firebase-config.js.
- Foto produk memakai URL gambar. Unggah gambar ke Firebase Storage (atau layanan gambar yang Anda kendalikan), lalu tempel URL-nya.
- Tombol Pesan membuka WhatsApp dengan teks pesanan. Nomor WhatsApp toko bisa diatur di app.js dengan mengganti https://wa.me/?text= menjadi https://wa.me/62NOMORANDA?text= (gunakan format nomor internasional tanpa +).

CARA SETUP DARI HP ANDROID
1. Buka https://console.firebase.google.com/ di Chrome dan login akun Google.
2. Tekan Add project / Tambahkan project, beri nama misalnya venz-store.
3. Di project, buka Build > Firestore Database > Create database. Pilih lokasi terdekat yang tersedia.
4. Buka Build > Authentication > Get started > Sign-in method, aktifkan Email/Password.
5. Buka Users lalu tambahkan akun admin dengan email dan password milikmu.
6. Di Project settings (ikon roda gigi) > General > Your apps, tambahkan aplikasi Web (ikon </>).
7. Salin konfigurasi Web dari Firebase ke file firebase-config.js, ganti semua nilai ISI_... dengan nilai asli. Jangan kirim password admin ke siapa pun.
8. Pasang aturan Firestore yang aman. File firestore.rules.example hanya contoh awal; pastikan klaim admin benar-benar disetel melalui backend tepercaya sebelum memakai aturan tersebut. Jangan pernah memberi izin write kepada semua orang.
9. Hosting: cara termudah adalah gunakan Firebase Hosting melalui Firebase CLI di komputer, atau unggah folder ini ke hosting statis yang mendukung HTTPS dan module JavaScript. Untuk HP saja, layanan hosting web berbasis Git juga bisa dipakai, tetapi proses pengaturan dilakukan di browser.
10. Buka website dengan HTTPS, lalu login melalui tombol roda gigi di kanan bawah untuk menambah produk. Produk disimpan di koleksi Firestore bernama products.

STRUKTUR
- index.html: struktur halaman
- style.css: desain
- app.js: katalog, pencarian, Firestore, login admin
- firebase-config.js: konfigurasi Firebase milikmu
- firestore.rules.example: contoh aturan keamanan

CATATAN KEAMANAN
Website belum terhubung ke project Firebase Anda karena konfigurasi Firebase bersifat unik untuk setiap pemilik. Jangan masukkan data pelanggan atau transaksi sungguhan sebelum Authentication, Firestore Rules, dan akses admin diuji. Untuk jual beli akun game, patuhi aturan game dan hukum yang berlaku.
