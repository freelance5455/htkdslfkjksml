import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { SUPABASE_URL, SUPABASE_ANON_KEY } from "./supabase-config.js";

const $ = id => document.getElementById(id);
let supabase=null, allProducts=[], activeCategory="Semua", currentUser=null;
const sampleProducts=[
 {id:"demo1",name:"AKUN FF — KOLEKSI ELITE",category:"Free Fire",price:50000,description:"Contoh tampilan produk. Ganti dengan produk milikmu.",image_url:"",demo:true},
 {id:"demo2",name:"AKUN FF — SKIN PREMIUM",category:"Free Fire",price:170000,description:"Contoh tampilan produk. Ganti dengan produk milikmu.",image_url:"",demo:true},
 {id:"demo3",name:"AKUN MOBILE LEGENDS",category:"Mobile Legends",price:95000,description:"Contoh tampilan produk. Ganti dengan produk milikmu.",image_url:"",demo:true},
 {id:"demo4",name:"FLASH SALE AKUN GAME",category:"Flash Sale",price:25000,description:"Contoh tampilan produk. Ganti dengan produk milikmu.",image_url:"",demo:true}
];
function rupiah(n){return new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(Number(n)||0)}
function safe(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function render(){
 const term=($("searchInput").value||"").toLowerCase();
 const list=allProducts.filter(p=>(activeCategory==="Semua"||p.category===activeCategory)&&(`${p.name} ${p.category} ${p.description||""}`).toLowerCase().includes(term));
 $("catalogTitle").textContent=activeCategory==="Semua"?"Semua Produk":activeCategory==="Free Fire"?"Akun Free Fire":activeCategory;
 $("products").innerHTML=list.map(p=>`<article class="product-card"><div class="product-image">${p.image_url?`<img src="${safe(p.image_url)}" alt="${safe(p.name)}" loading="lazy" onerror="this.remove()">`:`<div class="placeholder-art">✦</div>`}<span class="tag">${p.demo?"CONTOH":"VENZ STORE"}</span></div><div class="product-info"><div class="product-category">${safe(p.category)}</div><div class="product-name">${safe(p.name)}</div><div class="price">${rupiah(p.price)}</div><div class="product-actions"><button class="buy-btn" data-buy="${safe(p.id)}">Pesan</button><button class="detail-btn" data-detail="${safe(p.id)}">Detail</button></div></div></article>`).join("");
 $("empty").classList.toggle("hidden",list.length>0);
 $("products").querySelectorAll("[data-buy]").forEach(b=>b.onclick=()=>order(allProducts.find(p=>String(p.id)===b.dataset.buy)));
 $("products").querySelectorAll("[data-detail]").forEach(b=>b.onclick=()=>{const p=allProducts.find(x=>String(x.id)===b.dataset.detail);if(p)alert(`${p.name}\n${rupiah(p.price)}\n\n${p.description||"Hubungi admin untuk detail."}`)});
}
function order(p){if(!p)return;const msg=`Halo VENZ STORE, saya tertarik dengan produk: ${p.name} (${rupiah(p.price)}). Apakah masih tersedia?`;window.open("https://wa.me/6282372499032?text="+encodeURIComponent(msg),"_blank","noopener")}
$("searchToggle").onclick=()=>$("searchWrap").classList.toggle("show");
$("searchBtn").onclick=render;$("searchInput").addEventListener("input",render);
$("categories").querySelectorAll("button").forEach(b=>b.onclick=()=>{activeCategory=b.dataset.category;$("categories").querySelectorAll("button").forEach(x=>x.classList.toggle("active",x===b));render()});
$("seeAll").onclick=()=>{activeCategory="Semua";$("categories").querySelectorAll("button").forEach(x=>x.classList.toggle("active",x.dataset.category==="Semua"));render()};
$("adminOpen").onclick=()=>$("adminModal").classList.remove("hidden");$("adminClose").onclick=()=>$("adminModal").classList.add("hidden");
function configured(){return SUPABASE_URL.startsWith("https://")&&!SUPABASE_URL.includes("PROJECT_ID")&&SUPABASE_ANON_KEY!=="ISI_SUPABASE_PUBLISHABLE_OR_ANON_KEY"}
async function loadProducts(){
 if(!configured()){allProducts=sampleProducts;render();$("adminStatus").textContent="Isi supabase-config.js untuk mengaktifkan database.";return}
 try{
  const {data,error}=await supabase.from("products").select("*").order("created_at",{ascending:false});
  if(error)throw error;
  allProducts=data||[];render();
 }catch(e){allProducts=sampleProducts;render();$("adminStatus").textContent="Belum bisa memuat database: "+e.message}
}
$("loginBtn").onclick=async()=>{
 if(!configured()){ $("adminStatus").textContent="Isi konfigurasi Supabase dahulu.";return}
 const {data,error}=await supabase.auth.signInWithPassword({email:$("adminEmail").value,password:$("adminPassword").value});
 if(error){$("adminStatus").textContent="Login gagal: "+error.message;return}
 currentUser=data.user; $("productForm").classList.remove("hidden");$("loginBtn").classList.add("hidden");$("adminStatus").textContent="Login admin berhasil.";
};
$("logoutBtn").onclick=async()=>{await supabase.auth.signOut();currentUser=null;$("productForm").classList.add("hidden");$("loginBtn").classList.remove("hidden");$("adminStatus").textContent="Sudah keluar."};
$("saveProduct").onclick=async()=>{
 const name=$("pName").value.trim(),price=Number($("pPrice").value),category=$("pCategory").value;
 if(!currentUser){$("saveStatus").textContent="Login admin terlebih dahulu.";return}
 if(!name||!Number.isFinite(price)||price<0){$("saveStatus").textContent="Isi nama dan harga dengan benar.";return}
 let image_url=null;
 const file=$("pImage").files?.[0];
 if(file){
  if(!file.type.startsWith("image/")){$("saveStatus").textContent="Pilih file gambar yang benar.";return}
  if(file.size>5*1024*1024){$("saveStatus").textContent="Ukuran foto maksimal 5 MB.";return}
  const safeName=file.name.replace(/[^a-zA-Z0-9._-]/g,"_");
  const path=`${currentUser.id}/${Date.now()}-${safeName}`;
  const {error:uploadError}=await supabase.storage.from("product-images").upload(path,file,{upsert:false,contentType:file.type});
  if(uploadError){$("saveStatus").textContent="Upload foto gagal: "+uploadError.message+" — pastikan bucket dan policy Storage sudah dibuat.";return}
  const {data:publicData}=supabase.storage.from("product-images").getPublicUrl(path);
  image_url=publicData.publicUrl;
 }
 const {error}=await supabase.from("products").insert({name,price,category,image_url,description:$("pDescription").value.trim()||null,created_by:currentUser.id});
 if(error){$("saveStatus").textContent="Gagal menyimpan: "+error.message;return}
 $("saveStatus").textContent="Produk dan foto berhasil disimpan ke Supabase.";
 ["pName","pPrice","pDescription"].forEach(id=>$(id).value="");$("pImage").value="";await loadProducts();
};
$("socialNav").onclick=e=>{e.preventDefault();alert("Tambahkan tautan sosial media VENZ STORE pada website.")};
$("testimonialNav").onclick=e=>{e.preventDefault();alert("Testimoni pelanggan VENZ STORE akan ditampilkan di sini.")};
$("helpNav").onclick=e=>{e.preventDefault();order({name:"Bantuan / konsultasi",price:0})};
if(configured()){supabase=createClient(SUPABASE_URL,SUPABASE_ANON_KEY);supabase.auth.onAuthStateChange((_event,session)=>{currentUser=session?.user||null;if(currentUser){$("productForm").classList.remove("hidden");$("loginBtn").classList.add("hidden")}else{$("productForm").classList.add("hidden");$("loginBtn").classList.remove("hidden")}})}
loadProducts();
