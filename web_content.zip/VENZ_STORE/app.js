import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js";
import { getFirestore, collection, getDocs, addDoc, query, orderBy, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";
import { getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js";
import { firebaseConfig } from "./firebase-config.js";

const $ = id => document.getElementById(id);
let db=null, auth=null, allProducts=[], activeCategory="Semua", isDemo=true;
const sampleProducts=[
 {id:"demo1",name:"AKUN FF — KOLEKSI ELITE",category:"Free Fire",price:50000,description:"Contoh tampilan produk. Ganti dengan produk milikmu.",image:"",demo:true},
 {id:"demo2",name:"AKUN FF — SKIN PREMIUM",category:"Free Fire",price:170000,description:"Contoh tampilan produk. Ganti dengan produk milikmu.",image:"",demo:true},
 {id:"demo3",name:"AKUN MOBILE LEGENDS",category:"Mobile Legends",price:95000,description:"Contoh tampilan produk. Ganti dengan produk milikmu.",image:"",demo:true},
 {id:"demo4",name:"PAKET TOP UP GAME",category:"Top Up",price:25000,description:"Contoh tampilan produk. Ganti dengan produk milikmu.",image:"",demo:true}
];
function rupiah(n){return new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(Number(n)||0)}
function safe(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function render(){
 const list=allProducts.filter(p=>(activeCategory==="Semua"||p.category===activeCategory)&&(`${p.name} ${p.category} ${p.description||""}`).toLowerCase().includes(($("searchInput").value||"").toLowerCase()));
 $("catalogTitle").textContent=activeCategory==="Semua"?"Semua Produk":activeCategory==="Free Fire"?"Akun Free Fire":activeCategory;
 $("products").innerHTML=list.map(p=>`<article class="product-card"><div class="product-image">${p.image?`<img src="${safe(p.image)}" alt="${safe(p.name)}" loading="lazy" onerror="this.remove()">`:`<div class="placeholder-art">✦</div>`}<span class="tag">${p.demo?"CONTOH":"VENZ STORE"}</span></div><div class="product-info"><div class="product-category">${safe(p.category)}</div><div class="product-name">${safe(p.name)}</div><div class="price">${rupiah(p.price)}</div><div class="product-actions"><button class="buy-btn" data-buy="${safe(p.id)}">Pesan</button><button class="detail-btn" data-detail="${safe(p.id)}">Detail</button></div></div></article>`).join("");
 $("empty").classList.toggle("hidden",list.length>0);
 $("products").querySelectorAll("[data-buy]").forEach(b=>b.onclick=()=>order(allProducts.find(p=>p.id===b.dataset.buy)));
 $("products").querySelectorAll("[data-detail]").forEach(b=>b.onclick=()=>{const p=allProducts.find(x=>x.id===b.dataset.detail);if(p)alert(`${p.name}\n${rupiah(p.price)}\n\n${p.description||"Hubungi admin untuk detail."}`)});
}
function order(p){if(!p)return;const msg=`Halo VENZ STORE, saya tertarik dengan produk: ${p.name} (${rupiah(p.price)}). Apakah masih tersedia?`;window.open("https://wa.me/?text="+encodeURIComponent(msg),"_blank","noopener")}
$("searchToggle").onclick=()=>$("searchWrap").classList.toggle("show");
$("searchBtn").onclick=render;$("searchInput").addEventListener("input",render);
$("categories").querySelectorAll("button").forEach(b=>b.onclick=()=>{activeCategory=b.dataset.category;$("categories").querySelectorAll("button").forEach(x=>x.classList.toggle("active",x===b));render();});
$("seeAll").onclick=()=>{activeCategory="Semua";$("categories").querySelectorAll("button").forEach(x=>x.classList.toggle("active",x.dataset.category==="Semua"));render()};
$("adminOpen").onclick=()=>$("adminModal").classList.remove("hidden");$("adminClose").onclick=()=>$("adminModal").classList.add("hidden");
function configured(){return firebaseConfig.apiKey!=="ISI_API_KEY"&&firebaseConfig.projectId!=="ISI_PROJECT_ID"}
async function loadProducts(){
 if(!configured()){allProducts=sampleProducts;isDemo=true;render();return}
 try{const app=initializeApp(firebaseConfig);db=getFirestore(app);auth=getAuth(app);const snap=await getDocs(query(collection(db,"products"),orderBy("createdAt","desc")));allProducts=snap.docs.map(d=>({id:d.id,...d.data()}));isDemo=false;render();onAuthStateChanged(auth,user=>{$("productForm").classList.toggle("hidden",!user);$("loginBtn").classList.toggle("hidden",!!user);$("adminStatus").textContent=user?`Login sebagai ${user.email}`:"";});}
 catch(e){allProducts=sampleProducts;render();$("adminStatus").textContent="Firebase belum siap: "+e.message}
}
$("loginBtn").onclick=async()=>{if(!configured()){ $("adminStatus").textContent="Isi konfigurasi Firebase di firebase-config.js dahulu.";return}try{await signInWithEmailAndPassword(auth,$("adminEmail").value,$("adminPassword").value)}catch(e){$("adminStatus").textContent="Login gagal: "+e.message}};
$("logoutBtn").onclick=()=>signOut(auth);
$("saveProduct").onclick=async()=>{const name=$("pName").value.trim(),price=Number($("pPrice").value),category=$("pCategory").value;if(!name||!Number.isFinite(price)||price<0){$("saveStatus").textContent="Isi nama dan harga yang benar.";return}try{await addDoc(collection(db,"products"),{name,price,category,image:$("pImage").value.trim(),description:$("pDescription").value.trim(),createdAt:serverTimestamp()});$("saveStatus").textContent="Produk tersimpan!";$("pName").value=$("pPrice").value=$("pImage").value=$("pDescription").value="";await loadProducts()}catch(e){$("saveStatus").textContent="Gagal menyimpan: "+e.message}};
$("socialNav").onclick=e=>{e.preventDefault();alert("Tambahkan tautan sosial media VENZ STORE pada website.");};
$("testimonialNav").onclick=e=>{e.preventDefault();alert("Testimoni pelanggan VENZ STORE akan ditampilkan di sini.");};
$("helpNav").onclick=e=>{e.preventDefault();order({name:"Bantuan / konsultasi",price:0});};
loadProducts();
