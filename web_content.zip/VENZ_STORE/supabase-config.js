// Isi dari Supabase Dashboard > Project Settings > API
export const SUPABASE_URL = "https://PROJECT_ID.supabase.co";
export const SUPABASE_ANON_KEY = "ISI_SUPABASE_PUBLISHABLE_OR_ANON_KEY";
