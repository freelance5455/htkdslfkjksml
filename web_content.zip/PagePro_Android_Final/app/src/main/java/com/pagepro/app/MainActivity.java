package com.pagepro.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.net.ConnectivityManager;
import android.net.Network;
import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    WebView web;

    private boolean hasInternet() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        Network n = cm.getActiveNetwork();
        return n != null && cm.getNetworkCapabilities(n) != null;
    }

    private void showOffline() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(40, 40, 40, 40);
        box.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("Page pro");
        title.setTextSize(30);
        title.setTextColor(Color.rgb(40, 95, 210));
        title.setGravity(Gravity.CENTER);

        TextView msg = new TextView(this);
        msg.setText("Connexion Internet requise.\n\nVeuillez activer les données mobiles ou le Wi‑Fi, puis rouvrir Page pro.");
        msg.setTextSize(18);
        msg.setTextColor(Color.DKGRAY);
        msg.setGravity(Gravity.CENTER);
        msg.setPadding(0, 25, 0, 0);

        box.addView(title);
        box.addView(msg);
        setContentView(box);
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        if (!hasInternet()) {
            showOffline();
            return;
        }
        setContentView(com.pagepro.app.R.layout.activity_main);
        web = findViewById(R.id.webview);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onResume() {
        super.onResume();
        if (web == null && hasInternet()) recreate();
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
