PAGE PRO — ONLINE READY

Ity projet ity dia nohavaozina mba hitaky connexion Internet vao misokatra.

ZAVA-DEHIBE:
- Ny version ao anatiny mbola UI/local prototype.
- Mba hahitan'ny olona rehetra ny Page pro sy publication dia mila backend/base de donnees online (ohatra Firebase) ampifandraisina amin'ity projet ity.
- Tsy nampidirina fake server na fake data online, mba tsy hilazana fa online nefa tsy tena izy.

DINGANA MANARAKA:
1. Mamorona Firebase project ho an'ny Page pro.
2. Ampifandraisina amin'ny Android app ny Firebase Authentication, Firestore ary Storage.
3. Avadika ho APK rehefa vita ny connexion backend.

Tsy mila Play Store ny APK.
