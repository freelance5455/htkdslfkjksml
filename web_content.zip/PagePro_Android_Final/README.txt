PAGE PRO — VERSION 2.0

Ity no version nohavaozina amin'ilay projet Page pro.

ASA MANDEHA:
- Pejy pro fa tsy profil utilisateur tsotra.
- Anarana / activité / description azo ovaina.
- Fil d'actualité.
- Mamorona publication amin'ny soratra.
- Mamorona publication misy sary avy amin'ny téléphone.
- J'aime.
- Commentaire.
- Publications sy profil voatahiry amin'ny téléphone (localStorage).
- Malagasy / Français.
- Tsy mila Play Store vao afaka mandeha rehefa voa-build ho APK.

ZAVA-DEHIBE:
Ity version 2.0 ity dia tena azo ampiasaina ho application offline/local. Ny publication dia voatahiry ao amin'ilay téléphone.
Mbola tsy “réseau social en ligne” misy serveur sy mpampiasa maro izy. Raha tiana ho toy ny Facebook tena izy ka afaka miditra amin'ny téléphone samihafa, mila backend/serveur, compte, base de données, upload sary online, sécurité, sns.

BUILD:
- Sokafy amin'ny AndroidIDE na Android Studio.
- Import/Open ny dossier PagePro_Android_Final.
- Sync Gradle.
- Build APK.
- Install amin'ny téléphone.

Application ID: com.pagepro.app
Version: 2.0
