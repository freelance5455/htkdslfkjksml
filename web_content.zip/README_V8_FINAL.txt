NASH UNIVERSE v8 FINAL

Зміни:
1. Чат: текстові повідомлення + фото, прозоре скло, повний екран.
2. Нотатки та Наші розділи винесені окремими кнопками нижньої навігації.
3. Push: Firebase Messaging підключений, VAPID key заданий, Service Worker доданий, FCM token зберігається у Realtime Database.
4. Кнопка/системна кнопка Назад: навігація через history/popstate.
5. Фон чату повністю прибраний. Використовується тільки фон застосунку. У Налаштуваннях залишена тільки зміна фону застосунку.
6. Firebase config повний: apiKey/authDomain/databaseURL/projectId/storageBucket/messagingSenderId/appId/measurementId.

ВАЖЛИВО ПРО PUSH:
Для Web Push потрібен HTTPS (Firebase Hosting) і підтримка Service Worker/Notifications середовищем.
Для Android WebView/PWA фонова доставка залежить від способу пакування. Якщо APK є звичайним WebView, для гарантованих push у закритому APK потрібна нативна Android FCM інтеграція.

VAPID public key:
BLh9eylc5G0E3oc6ziL1s_UF8Bt-VdbqRfBqDFt3H4TdFqrIlJ4iKBOFt6W6wD1MF2blu2RFWe_jk4AnCadbo4w
