const { chromium } = require('playwright');
const path = require('path');
const URL = 'file://' + require('path').resolve(process.argv[2] || 'www/index.html');
const results = [];
const ok = (name, cond, extra='') => { results.push([cond ? 'PASS' : 'FAIL', name, extra]); };
(async () => {
  const browser = await chromium.launch();
  // Scenario A: fresh install
  let ctx = await browser.newContext({ locale: 'ar-SA' });
  let page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', e => errs.push(String(e)));
  await page.goto(URL);
  await page.waitForTimeout(500);
  let g = await page.textContent('#greetingText');
  ok('A1 fresh install greeting uses أبا يزيد', g.includes('أبا يزيد'), g);
  // assistant: add task, list tasks, save note
  await page.fill('#assistantInput', 'اضف مهمة اختبار الدواء');
  await page.click('#assistantSend');
  await page.waitForTimeout(400);
  let reply = await page.textContent('#assistantReply');
  ok('A2 add task via assistant', reply.includes('تمت إضافة المهمة'), reply);
  await page.fill('#assistantInput', 'احفظ ملاحظة اشتري الماء');
  await page.click('#assistantSend');
  await page.waitForTimeout(400);
  reply = await page.textContent('#assistantReply');
  ok('A3 save note via assistant', reply.includes('تم حفظ الملاحظة'), reply);
  await page.fill('#assistantInput', 'اعرض المهام');
  await page.click('#assistantSend');
  await page.waitForTimeout(400);
  reply = await page.textContent('#assistantReply');
  ok('A4 list tasks shows added task', reply.includes('اختبار الدواء'), reply);
  // persistence & timestamps
  const stored = await page.evaluate(() => JSON.parse(localStorage.getItem('janni.v1')));
  ok('A5 storage key janni.v1 kept', !!stored && stored.tasks.length === 1 && stored.notes.length === 1);
  ok('A6 createdAt present on task/note', !!stored.tasks[0].createdAt && !!stored.notes[0].updatedAt);
  // reload persists
  await page.reload(); await page.waitForTimeout(400);
  const after = await page.evaluate(() => JSON.parse(localStorage.getItem('janni.v1')));
  ok('A7 data survives reload', after.tasks.length === 1 && after.notes.length === 1);
  // settings: http rejected, https accepted
  await page.evaluate(() => document.getElementById('openSettings').click());
  await page.waitForTimeout(200);
  await page.fill('#setAiUrl', 'http://insecure.example/x');
  await page.click('#setSaveProfile');
  await page.waitForTimeout(300);
  let alertTxt = await page.textContent('#askText').catch(()=> '');
  let saved1 = await page.evaluate(() => JSON.parse(localStorage.getItem('janni.v1')).settings.aiUrl);
  ok('B1 http:// AI url rejected (not saved)', saved1 === '', 'saved=' + saved1);
  // dismiss ask overlay if open
  await page.evaluate(() => { const o=document.querySelector('.overlay.show, #askOverlay.show'); if(o) o.classList.remove('show'); });
  await page.fill('#setAiUrl', 'https://example.com/janni');
  await page.click('#setSaveProfile');
  await page.waitForTimeout(300);
  let saved2 = await page.evaluate(() => JSON.parse(localStorage.getItem('janni.v1')).settings.aiUrl);
  ok('B2 https AI url saved', saved2 === 'https://example.com/janni', saved2);
  const diag = await page.textContent('#diagBox');
  ok('B3 diagnostics states speaker verification NOT implemented', diag.includes('غير مُنفَّذ'), diag.slice(-80));
  await ctx.close();

  // Scenario C: legacy data migration (old default name + notes without timestamps)
  ctx = await browser.newContext({ locale: 'ar-SA' });
  page = await ctx.newPage();
  const errs2 = []; page.on('pageerror', e => errs2.push(String(e)));
  await page.addInitScript(() => {
    if (!sessionStorage.getItem('seeded')) {
      sessionStorage.setItem('seeded','1');
      localStorage.setItem('janni.v1', JSON.stringify({ settings: { name: 'صديقي', aiUrl: '' },
        tasks: [{ id: 't1', title: 'قديمة', done: false, date: '', created: 1700000000000 }],
        notes: [{ id: 'n1', title: 'n', text: 'ملاحظة قديمة', created: 1700000000000, updated: 1700000100000 }],
        reminders: [], contacts: [] }));
    }
  });
  await page.goto(URL); await page.waitForTimeout(500);
  const mig = await page.evaluate(() => JSON.parse(localStorage.getItem('janni.v1')));
  ok('C1 old default name migrated', mig.settings.name === 'أبا يزيد', mig.settings.name);
  ok('C2 old task kept (not deleted)', mig.tasks.length === 1 && mig.tasks[0].title === 'قديمة');
  ok('C3 old note kept with old fields + ISO timestamp', mig.notes[0].text === 'ملاحظة قديمة' && mig.notes[0].updated === 1700000100000 && typeof mig.notes[0].updatedAt === 'string');
  // Scenario D: reminder assistant still works (non-native path)
  await page.fill('#assistantInput', 'ذكرني بالدواء بعد دقيقتين');
  await page.click('#assistantSend');
  await page.waitForTimeout(600);
  const rem = await page.evaluate(() => JSON.parse(localStorage.getItem('janni.v1')).reminders.length);
  const rr = await page.textContent('#assistantReply');
  ok('D1 reminder created from voice/text command', rem === 1, rr);
  const bak = await page.evaluate(() => localStorage.getItem('janni.v1.backup-0.4'));
  ok('C5 original data backed up before migration', !!bak && bak.includes('صديقي'));
  // Scenario E: corrupt stored data must NOT be overwritten
  const ctxE = await browser.newContext({ locale: 'ar-SA' });
  const pE = await ctxE.newPage(); const errsE = []; pE.on('pageerror', e => errsE.push(String(e)));
  await pE.addInitScript(() => { if (!sessionStorage.getItem('s')) { sessionStorage.setItem('s','1'); localStorage.setItem('janni.v1', '{broken json'); } });
  await pE.goto(URL); await pE.waitForTimeout(400);
  await pE.fill('#assistantInput', 'اضف مهمة لن تحفظ'); await pE.click('#assistantSend'); await pE.waitForTimeout(300);
  const rawE = await pE.evaluate(() => localStorage.getItem('janni.v1'));
  ok('E1 corrupt data left untouched', rawE === '{broken json', rawE);
  ok('E2 no JS errors on corrupt data', errsE.length === 0, errsE.join(' | '));
  await ctxE.close();
  ok('C4 no JS page errors (migration scenario)', errs2.length === 0, errs2.join(' | '));
  ok('A8 no JS page errors (fresh scenario)', errs.length === 0, errs.join(' | '));
  await browser.close();
  for (const r of results) console.log(r[0], r[1], r[2] ? '-- ' + r[2] : '');
  const fails = results.filter(r => r[0] === 'FAIL').length;
  console.log(`\n${results.length - fails}/${results.length} passed`);
})().catch(e => { console.error('RUNNER ERROR', e); process.exit(1); });
