# LaunchKit — Digital Product Launch Planner

A complete, offline-ready web app for planning and tracking digital product launches.

## How to Use

### Option A — Open directly (simplest)
1. Unzip the folder
2. Open `index.html` in any modern browser (Chrome, Firefox, Safari, Edge)
3. That's it — no installation, no server needed

### Option B — React version (for developers)
1. Install Node.js from https://nodejs.org
2. Open terminal in the `launchkit-react/` folder
3. Run: `npm install`
4. Run: `npm start`
5. Opens at http://localhost:3000

## Features

- Create unlimited product launches
- 5-phase guided checklist (25+ tasks)
- Add custom tasks per phase
- Notes + due dates on every task
- Phase collapse/expand
- Progress tracking per phase and overall
- Days-until-launch countdown
- Auto status: Planning → In Progress → Ready to Launch → Launched
- Archive and restore launches
- Export/import data as JSON backup
- All data saved in browser (localStorage)
- Works fully offline after first load
- Mobile-first responsive design

## Data & Privacy
All data is stored only in your browser's localStorage.
Nothing is sent to any server. Use Export to back up your data.

## Browser Support
Works in all modern browsers. Requires JavaScript enabled.
