import React, { useState, useEffect, useCallback } from 'react';
import { loadData, saveData, generateId, buildInitialTasks, calcProgress, autoStatus, LAUNCH_PHASES } from './data';
import Dashboard from './components/Dashboard';
import MyLaunches from './components/MyLaunches';
import Workspace from './components/Workspace';
import NewLaunchModal from './components/NewLaunchModal';
import BottomNav from './components/BottomNav';
import Sidebar from './components/Sidebar';
import SettingsModal from './components/SettingsModal';

export default function App() {
  const [data, setData] = useState(() => loadData());
  const [view, setView] = useState('dashboard');
  const [workspaceId, setWorkspaceId] = useState(null);
  const [showNewLaunch, setShowNewLaunch] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  // persist
  useEffect(() => { saveData(data); }, [data]);

  const launches = data.launches;
  const activeLaunch = launches.find(l => l.id === (workspaceId || data.activeId)) || launches[0] || null;

  const setLaunches = useCallback((updater) => {
    setData(prev => {
      const next = typeof updater === 'function' ? updater(prev.launches) : updater;
      return { ...prev, launches: next };
    });
  }, []);

  function createLaunch(form) {
    const id = generateId();
    const tasks = buildInitialTasks();
    const newLaunch = {
      id,
      name: form.name,
      productType: form.productType,
      audience: form.audience,
      launchDate: form.launchDate,
      salesUrl: form.salesUrl,
      status: 'Planning',
      tasks,
      collapsedPhases: {},
      createdAt: new Date().toISOString(),
      archived: false,
    };
    setData(prev => ({ ...prev, launches: [newLaunch, ...prev.launches], activeId: id }));
    setWorkspaceId(id);
    setView('workspace');
    setShowNewLaunch(false);
  }

  function updateLaunch(id, updater) {
    setLaunches(prev => prev.map(l => {
      if (l.id !== id) return l;
      const updated = typeof updater === 'function' ? updater(l) : { ...l, ...updater };
      // Auto-update status unless archived or manually launched
      if (!updated.archived && updated.status !== 'Launched') {
        updated.status = autoStatus(updated.tasks, updated.launchDate);
      }
      return updated;
    }));
  }

  function deleteLaunch(id) {
    setData(prev => {
      const launches = prev.launches.filter(l => l.id !== id);
      const activeId = prev.activeId === id ? (launches[0]?.id || null) : prev.activeId;
      return { ...prev, launches, activeId };
    });
    if (workspaceId === id) { setWorkspaceId(null); setView('dashboard'); }
  }

  function openWorkspace(id) {
    setWorkspaceId(id);
    setData(prev => ({ ...prev, activeId: id }));
    setView('workspace');
  }

  function exportData() {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url;
    a.download = `launchkit-backup-${new Date().toISOString().slice(0,10)}.json`;
    a.click(); URL.revokeObjectURL(url);
  }

  function importData(jsonStr) {
    try {
      const parsed = JSON.parse(jsonStr);
      if (!parsed.launches) throw new Error('Invalid format');
      setData(parsed);
    } catch { alert('Invalid backup file. Please use a LaunchKit JSON export.'); }
  }

  const currentWorkspace = launches.find(l => l.id === workspaceId);

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      {/* Desktop Sidebar */}
      <Sidebar
        view={view} setView={setView}
        onNewLaunch={() => setShowNewLaunch(true)}
        onSettings={() => setShowSettings(true)}
      />

      {/* Main content */}
      <div style={{
        flex: 1,
        marginLeft: 0,
        paddingBottom: 80,
        minHeight: '100vh',
      }} className="main-content">
        <style>{`
          @media (min-width: 768px) {
            .main-content { margin-left: 220px !important; padding-bottom: 24px !important; }
          }
        `}</style>

        {view === 'dashboard' && (
          <Dashboard
            launches={launches}
            onNewLaunch={() => setShowNewLaunch(true)}
            onOpenWorkspace={openWorkspace}
            activeLaunch={activeLaunch}
          />
        )}
        {view === 'launches' && (
          <MyLaunches
            launches={launches}
            onOpen={openWorkspace}
            onDelete={deleteLaunch}
            onUpdate={updateLaunch}
            onNewLaunch={() => setShowNewLaunch(true)}
          />
        )}
        {view === 'workspace' && currentWorkspace && (
          <Workspace
            launch={currentWorkspace}
            onUpdate={(upd) => updateLaunch(currentWorkspace.id, upd)}
            onBack={() => setView('launches')}
          />
        )}
        {view === 'workspace' && !currentWorkspace && (
          <div style={{ padding: 32, textAlign: 'center' }}>
            <p style={{ color: 'var(--text-secondary)', marginBottom: 16 }}>No launch selected.</p>
            <button className="btn btn-primary" onClick={() => setShowNewLaunch(true)}>
              Create Your First Launch
            </button>
          </div>
        )}
      </div>

      {/* Mobile Nav */}
      <BottomNav
        view={view} setView={setView}
        onNewLaunch={() => setShowNewLaunch(true)}
      />

      {/* Modals */}
      {showNewLaunch && (
        <NewLaunchModal onClose={() => setShowNewLaunch(false)} onCreate={createLaunch} />
      )}
      {showSettings && (
        <SettingsModal
          onClose={() => setShowSettings(false)}
          onExport={exportData}
          onImport={importData}
          launchCount={launches.length}
        />
      )}
    </div>
  );
}
