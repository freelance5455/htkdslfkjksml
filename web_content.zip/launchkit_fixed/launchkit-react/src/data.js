export const PRODUCT_TYPES = [
  'Ebook', 'Planner', 'Template', 'Prompt Pack', 'Course', 'Other'
];

export const STATUSES = ['Planning', 'In Progress', 'Ready to Launch', 'Launched', 'Archived'];

export const LAUNCH_PHASES = [
  {
    id: 'phase1',
    title: 'Product Preparation',
    emoji: '📦',
    tasks: [
      { id: 'p1t1', label: 'Define the audience and problem' },
      { id: 'p1t2', label: 'Finalize the product content' },
      { id: 'p1t3', label: 'Proofread and quality-check the product' },
      { id: 'p1t4', label: 'Export and test the final files' },
      { id: 'p1t5', label: 'Prepare a delivery file or download link' },
    ]
  },
  {
    id: 'phase2',
    title: 'Product Presentation',
    emoji: '🎨',
    tasks: [
      { id: 'p2t1', label: 'Create a product title' },
      { id: 'p2t2', label: 'Write the product description' },
      { id: 'p2t3', label: 'List the key benefits and features' },
      { id: 'p2t4', label: 'Design the cover and product images' },
      { id: 'p2t5', label: 'Prepare preview images or sample pages' },
    ]
  },
  {
    id: 'phase3',
    title: 'Sales Page',
    emoji: '🛒',
    tasks: [
      { id: 'p3t1', label: 'Choose a selling platform' },
      { id: 'p3t2', label: 'Add the product title and description' },
      { id: 'p3t3', label: 'Set the price' },
      { id: 'p3t4', label: 'Add product images' },
      { id: 'p3t5', label: 'Test the sales page and checkout process' },
    ]
  },
  {
    id: 'phase4',
    title: 'Marketing',
    emoji: '📣',
    tasks: [
      { id: 'p4t1', label: 'Define the target audience' },
      { id: 'p4t2', label: 'Create 10 content ideas' },
      { id: 'p4t3', label: 'Prepare 5 promotional hooks' },
      { id: 'p4t4', label: 'Draft 3 promotional posts' },
      { id: 'p4t5', label: 'Prepare a launch announcement' },
      { id: 'p4t6', label: 'Schedule launch content' },
    ]
  },
  {
    id: 'phase5',
    title: 'Launch & Review',
    emoji: '🚀',
    tasks: [
      { id: 'p5t1', label: 'Publish the product' },
      { id: 'p5t2', label: 'Test the live product page' },
      { id: 'p5t3', label: 'Publish the launch announcement' },
      { id: 'p5t4', label: 'Track views, clicks, and sales manually' },
      { id: 'p5t5', label: 'Review results and record improvements' },
    ]
  }
];

export function buildInitialTasks() {
  const tasks = {};
  LAUNCH_PHASES.forEach(phase => {
    phase.tasks.forEach(t => {
      tasks[t.id] = { done: false, dueDate: '', notes: '', label: t.label, phaseId: phase.id, custom: false };
    });
  });
  return tasks;
}

export function calcProgress(tasks) {
  const all = Object.values(tasks);
  if (!all.length) return 0;
  return Math.round((all.filter(t => t.done).length / all.length) * 100);
}

export function daysUntil(dateStr) {
  if (!dateStr) return null;
  const today = new Date(); today.setHours(0,0,0,0);
  const target = new Date(dateStr + 'T00:00:00');
  const diff = Math.ceil((target - today) / 86400000);
  return diff;
}

export function formatDate(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export function autoStatus(tasks, launchDate) {
  const progress = calcProgress(tasks);
  const days = daysUntil(launchDate);
  if (progress === 0) return 'Planning';
  if (progress === 100) return 'Launched';
  if (days !== null && days <= 3) return 'Ready to Launch';
  return 'In Progress';
}

export const STORAGE_KEY = 'launchkit_v2';

export function loadData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { launches: [], activeId: null };
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') return { launches: [], activeId: null };
    return { launches: Array.isArray(parsed.launches) ? parsed.launches : [], activeId: parsed.activeId || null };
  } catch { return { launches: [], activeId: null }; }
}

export function saveData(data) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); } catch {}
}

export function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}
