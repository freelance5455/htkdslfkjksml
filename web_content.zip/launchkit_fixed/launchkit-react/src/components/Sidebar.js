import React from 'react';

const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: '⊞' },
  { id: 'workspace', label: 'Workspace', icon: '✦' },
  { id: 'launches', label: 'My Launches', icon: '◈' },
];

export default function Sidebar({ view, setView, onNewLaunch, onSettings }) {
  return (
    <aside style={{
      position: 'fixed', top: 0, left: 0,
      width: 220, height: '100vh',
      background: 'rgba(8,9,26,0.95)',
      borderRight: '1px solid var(--glass-border)',
      backdropFilter: 'blur(20px)',
      display: 'flex', flexDirection: 'column',
      padding: '28px 0',
      zIndex: 200,
    }} className="sidebar-desktop">
      <style>{`
        @media (max-width: 767px) { .sidebar-desktop { display: none !important; } }
      `}</style>

      {/* Logo */}
      <div style={{ padding: '0 24px 28px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 32, height: 32,
            background: 'linear-gradient(135deg, var(--violet), var(--blue-dim))',
            borderRadius: 8,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 16,
          }}>🚀</div>
          <span style={{ fontSize: 16, fontWeight: 700, color: 'var(--text-primary)' }}>LaunchKit</span>
        </div>
      </div>

      {/* New Launch */}
      <div style={{ padding: '0 16px 20px' }}>
        <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }} onClick={onNewLaunch}>
          + New Launch
        </button>
      </div>

      <div style={{ height: 1, background: 'var(--glass-border)', margin: '0 16px 16px' }} />

      {/* Nav */}
      <nav style={{ flex: 1, padding: '0 8px' }}>
        {navItems.map(item => (
          <button
            key={item.id}
            onClick={() => setView(item.id)}
            style={{
              width: '100%', display: 'flex', alignItems: 'center', gap: 10,
              padding: '10px 16px', borderRadius: 'var(--radius-sm)',
              border: 'none', cursor: 'pointer', textAlign: 'left',
              fontSize: 14, fontWeight: 500,
              background: view === item.id ? 'rgba(124,92,191,0.15)' : 'transparent',
              color: view === item.id ? 'var(--violet-light)' : 'var(--text-secondary)',
              borderLeft: view === item.id ? '2px solid var(--violet-light)' : '2px solid transparent',
              marginBottom: 2,
            }}
          >
            <span style={{ fontSize: 16 }}>{item.icon}</span>
            {item.label}
          </button>
        ))}
      </nav>

      {/* Settings */}
      <div style={{ padding: '0 8px' }}>
        <button
          onClick={onSettings}
          style={{
            width: '100%', display: 'flex', alignItems: 'center', gap: 10,
            padding: '10px 16px', borderRadius: 'var(--radius-sm)',
            border: 'none', cursor: 'pointer',
            fontSize: 14, fontWeight: 500,
            background: 'transparent',
            color: 'var(--text-secondary)',
          }}
        >
          <span style={{ fontSize: 16 }}>⚙</span>
          Settings & Backup
        </button>
      </div>
    </aside>
  );
}
