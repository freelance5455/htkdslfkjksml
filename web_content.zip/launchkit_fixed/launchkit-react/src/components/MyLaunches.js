import React, { useState } from 'react';
import { calcProgress, daysUntil, formatDate, PRODUCT_TYPES, STATUSES } from '../data';

function statusBadgeClass(status) {
  if (status === 'Planning') return 'badge badge-planning';
  if (status === 'In Progress') return 'badge badge-progress';
  if (status === 'Ready to Launch') return 'badge badge-ready';
  if (status === 'Launched') return 'badge badge-launched';
  if (status === 'Archived') return 'badge badge-archived';
  return 'badge';
}

function EditModal({ launch, onClose, onSave }) {
  const [form, setForm] = useState({
    name: launch.name,
    productType: launch.productType,
    audience: launch.audience || '',
    launchDate: launch.launchDate || '',
    salesUrl: launch.salesUrl || '',
    status: launch.status,
  });

  function set(k, v) { setForm(p => ({ ...p, [k]: v })); }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <h2 style={{ fontSize: 18, fontWeight: 700 }}>Edit Launch</h2>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', fontSize: 20, cursor: 'pointer' }}>✕</button>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div>
            <label className="form-label">Product Name</label>
            <input className="input" value={form.name} onChange={e => set('name', e.target.value)} />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <div>
              <label className="form-label">Type</label>
              <select className="input" value={form.productType} onChange={e => set('productType', e.target.value)}>
                {PRODUCT_TYPES.map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className="form-label">Status</label>
              <select className="input" value={form.status} onChange={e => set('status', e.target.value)}>
                {STATUSES.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="form-label">Target Audience</label>
            <input className="input" value={form.audience} onChange={e => set('audience', e.target.value)} />
          </div>
          <div>
            <label className="form-label">Launch Date</label>
            <input className="input" type="date" value={form.launchDate} onChange={e => set('launchDate', e.target.value)} />
          </div>
          <div>
            <label className="form-label">Sales Page URL</label>
            <input className="input" type="url" value={form.salesUrl} onChange={e => set('salesUrl', e.target.value)} />
          </div>
        </div>

        <div style={{ display: 'flex', gap: 10, marginTop: 20 }}>
          <button className="btn btn-ghost" style={{ flex: 1, justifyContent: 'center' }} onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" style={{ flex: 1, justifyContent: 'center' }} onClick={() => onSave(form)}>Save Changes</button>
        </div>
      </div>
    </div>
  );
}

function LaunchCard({ launch, onOpen, onEdit, onDelete, onArchive, onUnarchive }) {
  const progress = calcProgress(launch.tasks);
  const days = launch.launchDate ? daysUntil(launch.launchDate) : null;
  const [confirmDelete, setConfirmDelete] = useState(false);

  return (
    <div className="glass" style={{ padding: 18, marginBottom: 12 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12, marginBottom: 12 }}>
        <div style={{ minWidth: 0, flex: 1 }}>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 4, flexWrap: 'wrap' }}>
            <span className={statusBadgeClass(launch.status)}>{launch.status}</span>
            <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{launch.productType}</span>
          </div>
          <h3 style={{ fontSize: 16, fontWeight: 600, wordBreak: 'break-word' }}>{launch.name}</h3>
          {launch.audience && (
            <p style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 3 }}>
              {launch.audience}
            </p>
          )}
          {launch.launchDate && (
            <p style={{ fontSize: 12, marginTop: 4, color: days !== null && days < 0 ? 'var(--danger)' : 'var(--text-muted)' }}>
              📅 {formatDate(launch.launchDate)}
              {days !== null && ` · ${days < 0 ? `${Math.abs(days)}d overdue` : days === 0 ? 'Today!' : `${days}d left`}`}
            </p>
          )}
        </div>
        <div style={{ textAlign: 'right', flexShrink: 0 }}>
          <div style={{ fontSize: 22, fontWeight: 700, color: 'var(--violet-light)' }}>{progress}%</div>
          <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>
            {Object.values(launch.tasks).filter(t => t.done).length}/{Object.values(launch.tasks).length}
          </div>
        </div>
      </div>

      <div className="progress-bar" style={{ marginBottom: 14 }}>
        <div className="progress-fill" style={{ width: `${progress}%` }} />
      </div>

      {/* Actions */}
      {confirmDelete ? (
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <span style={{ fontSize: 13, color: 'var(--text-secondary)', flex: 1 }}>
            Delete this launch permanently?
          </span>
          <button className="btn btn-ghost btn-sm" onClick={() => setConfirmDelete(false)}>Cancel</button>
          <button className="btn btn-danger btn-sm" onClick={() => onDelete(launch.id)}>Delete</button>
        </div>
      ) : (
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <button className="btn btn-primary btn-sm" onClick={() => onOpen(launch.id)}>Open</button>
          <button className="btn btn-ghost btn-sm" onClick={() => onEdit(launch)}>Edit</button>
          {launch.archived ? (
            <button className="btn btn-ghost btn-sm" onClick={() => onUnarchive(launch.id)}>Unarchive</button>
          ) : (
            <button className="btn btn-ghost btn-sm" onClick={() => onArchive(launch.id)}>Archive</button>
          )}
          <button className="btn btn-ghost btn-sm"
            style={{ marginLeft: 'auto', color: 'var(--danger)', borderColor: 'rgba(248,113,113,0.2)' }}
            onClick={() => setConfirmDelete(true)}>✕</button>
        </div>
      )}
    </div>
  );
}

export default function MyLaunches({ launches, onOpen, onDelete, onUpdate, onNewLaunch }) {
  const [editTarget, setEditTarget] = useState(null);
  const [filter, setFilter] = useState('active'); // 'active' | 'archived' | 'all'

  const filtered = launches.filter(l => {
    if (filter === 'active') return !l.archived;
    if (filter === 'archived') return l.archived;
    return true;
  });

  function handleSaveEdit(form) {
    onUpdate(editTarget.id, l => ({
      ...l,
      name: form.name,
      productType: form.productType,
      audience: form.audience,
      launchDate: form.launchDate,
      salesUrl: form.salesUrl,
      status: form.status,
    }));
    setEditTarget(null);
  }

  function archiveLaunch(id) {
    onUpdate(id, l => ({ ...l, archived: true, status: 'Archived' }));
  }

  function unarchiveLaunch(id) {
    onUpdate(id, l => ({ ...l, archived: false }));
  }

  return (
    <div style={{ padding: '24px 16px', maxWidth: 700, margin: '0 auto' }} className="fade-in">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <h1 style={{ fontSize: 22, fontWeight: 700 }}>My Launches</h1>
        <button className="btn btn-primary" onClick={onNewLaunch}>+ New</button>
      </div>

      {/* Filter tabs */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 20 }}>
        {[['active', 'Active'], ['archived', 'Archived'], ['all', 'All']].map(([val, label]) => (
          <button key={val}
            onClick={() => setFilter(val)}
            style={{
              padding: '6px 14px', borderRadius: 99, fontSize: 13, fontWeight: 500,
              border: filter === val ? 'none' : '1px solid var(--glass-border)',
              background: filter === val ? 'rgba(124,92,191,0.25)' : 'var(--glass-bg)',
              color: filter === val ? 'var(--violet-light)' : 'var(--text-secondary)',
              cursor: 'pointer',
            }}
          >
            {label} {val === 'active' ? launches.filter(l => !l.archived).length : val === 'archived' ? launches.filter(l => l.archived).length : launches.length}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="glass" style={{ padding: 32, textAlign: 'center' }}>
          <div style={{ fontSize: 32, marginBottom: 12 }}>📭</div>
          <p style={{ color: 'var(--text-secondary)', fontSize: 15 }}>
            {filter === 'archived' ? 'No archived launches.' : 'No launches yet.'}
          </p>
          {filter !== 'archived' && (
            <button className="btn btn-primary" style={{ marginTop: 16 }} onClick={onNewLaunch}>
              Create Your First Launch
            </button>
          )}
        </div>
      ) : (
        filtered.map(l => (
          <LaunchCard
            key={l.id}
            launch={l}
            onOpen={onOpen}
            onEdit={setEditTarget}
            onDelete={onDelete}
            onArchive={archiveLaunch}
            onUnarchive={unarchiveLaunch}
          />
        ))
      )}

      {editTarget && (
        <EditModal
          launch={editTarget}
          onClose={() => setEditTarget(null)}
          onSave={handleSaveEdit}
        />
      )}
    </div>
  );
}
