import React, { useState } from 'react';
import { PRODUCT_TYPES } from '../data';

export default function NewLaunchModal({ onClose, onCreate }) {
  const [form, setForm] = useState({
    name: '', productType: 'Ebook', audience: '', launchDate: '', salesUrl: ''
  });
  const [errors, setErrors] = useState({});

  function set(k, v) { setForm(p => ({ ...p, [k]: v })); if (errors[k]) setErrors(p => ({ ...p, [k]: '' })); }

  function validate() {
    const e = {};
    if (!form.name.trim()) e.name = 'Product name is required';
    if (!form.launchDate) e.launchDate = 'Launch date is required';
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function handleCreate() {
    if (!validate()) return;
    onCreate(form);
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
          <div>
            <h2 style={{ fontSize: 20, fontWeight: 700 }}>New Launch</h2>
            <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 4 }}>
              Set up your product launch in seconds.
            </p>
          </div>
          <button onClick={onClose} style={{
            background: 'none', border: 'none', color: 'var(--text-muted)',
            fontSize: 20, cursor: 'pointer', padding: 4,
          }}>✕</button>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div>
            <label className="form-label">Product Name *</label>
            <input className="input" placeholder="e.g. Ultimate Content Calendar" value={form.name}
              onChange={e => set('name', e.target.value)} />
            {errors.name && <p style={{ fontSize: 12, color: 'var(--danger)', marginTop: 4 }}>{errors.name}</p>}
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div>
              <label className="form-label">Product Type</label>
              <select className="input" value={form.productType} onChange={e => set('productType', e.target.value)}>
                {PRODUCT_TYPES.map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className="form-label">Launch Date *</label>
              <input className="input" type="date" value={form.launchDate}
                onChange={e => set('launchDate', e.target.value)} />
              {errors.launchDate && <p style={{ fontSize: 12, color: 'var(--danger)', marginTop: 4 }}>{errors.launchDate}</p>}
            </div>
          </div>

          <div>
            <label className="form-label">Target Audience</label>
            <input className="input" placeholder="e.g. Beginner content creators" value={form.audience}
              onChange={e => set('audience', e.target.value)} />
          </div>

          <div>
            <label className="form-label">Sales Page URL (optional)</label>
            <input className="input" type="url" placeholder="https://yourstore.com/product" value={form.salesUrl}
              onChange={e => set('salesUrl', e.target.value)} />
          </div>
        </div>

        <div style={{ display: 'flex', gap: 10, marginTop: 24 }}>
          <button className="btn btn-ghost" style={{ flex: 1, justifyContent: 'center' }} onClick={onClose}>
            Cancel
          </button>
          <button className="btn btn-primary" style={{ flex: 1, justifyContent: 'center' }} onClick={handleCreate}>
            Create Launch →
          </button>
        </div>
      </div>
    </div>
  );
}
