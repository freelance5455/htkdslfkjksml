import React, { useState, useCallback } from 'react';
import { LAUNCH_PHASES, calcProgress, daysUntil, formatDate, generateId } from '../data';

function TaskRow({ taskId, task, onToggle, onUpdate, onDelete, isCustom }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div>
      <div className={`task-item${task.done ? ' completed' : ''}`}>
        <input type="checkbox" checked={task.done} onChange={() => onToggle(taskId)}
          style={{ marginTop: 2, flexShrink: 0, width: 16, height: 16 }} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
            <span className="task-label" style={{ fontSize: 14, lineHeight: 1.4 }}>{task.label}</span>
            <div style={{ display: 'flex', gap: 4, flexShrink: 0 }}>
              <button onClick={() => setExpanded(!expanded)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', fontSize: 14, padding: '0 2px' }}
                title="Add notes or due date">
                {expanded ? '↑' : '↓'}
              </button>
              {isCustom && (
                <button onClick={() => { if (window.confirm('Delete this task?')) onDelete(taskId); }}
                  style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--danger)', fontSize: 13, padding: '0 2px' }}
                  title="Delete task">✕</button>
              )}
            </div>
          </div>
          {task.dueDate && !expanded && (
            <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 3 }}>
              Due: {formatDate(task.dueDate)}
            </div>
          )}
        </div>
      </div>

      {expanded && (
        <div style={{
          marginLeft: 28, padding: '10px 12px 12px',
          background: 'rgba(255,255,255,0.02)', borderRadius: 8,
          marginBottom: 4, border: '1px solid var(--glass-border)',
        }} className="fade-in">
          {isCustom && (
            <div style={{ marginBottom: 8 }}>
              <label className="form-label">Task label</label>
              <input className="input" value={task.label}
                onChange={e => onUpdate(taskId, { label: e.target.value })} />
            </div>
          )}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: 8 }}>
            <div>
              <label className="form-label">Due date</label>
              <input className="input" type="date" value={task.dueDate}
                onChange={e => onUpdate(taskId, { dueDate: e.target.value })} />
            </div>
            <div>
              <label className="form-label">Notes</label>
              <textarea className="input" placeholder="Any notes for this task..."
                value={task.notes} onChange={e => onUpdate(taskId, { notes: e.target.value })} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function PhaseCard({ phase, tasks, collapsed, onToggleCollapse, onToggleTask, onUpdateTask, onDeleteTask, onAddTask }) {
  const [showAdd, setShowAdd] = useState(false);
  const [newTaskLabel, setNewTaskLabel] = useState('');

  const phaseTasks = Object.entries(tasks).filter(([, t]) => t.phaseId === phase.id);
  const done = phaseTasks.filter(([, t]) => t.done).length;
  const total = phaseTasks.length;
  const pct = total ? Math.round((done / total) * 100) : 0;

  function addTask() {
    if (!newTaskLabel.trim()) return;
    onAddTask(phase.id, newTaskLabel.trim());
    setNewTaskLabel('');
    setShowAdd(false);
  }

  return (
    <div className="glass" style={{ marginBottom: 12, overflow: 'hidden' }}>
      {/* Phase header */}
      <button
        onClick={() => onToggleCollapse(phase.id)}
        style={{
          width: '100%', background: 'none', border: 'none', cursor: 'pointer',
          padding: '16px 18px', display: 'flex', alignItems: 'center', gap: 10,
          textAlign: 'left',
        }}
      >
        <span style={{ fontSize: 18 }}>{phase.emoji}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: 15, fontWeight: 600 }}>{phase.title}</span>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{
                fontSize: 12, fontWeight: 600,
                color: pct === 100 ? 'var(--success)' : 'var(--text-secondary)',
              }}>{done}/{total}</span>
              <span style={{ color: 'var(--text-muted)', fontSize: 14 }}>{collapsed ? '▼' : '▲'}</span>
            </div>
          </div>
          <div className="progress-bar" style={{ marginTop: 6 }}>
            <div className="progress-fill" style={{ width: `${pct}%` }} />
          </div>
        </div>
      </button>

      {/* Tasks */}
      {!collapsed && (
        <div style={{ borderTop: '1px solid var(--glass-border)', padding: '8px 12px 12px' }} className="fade-in">
          {phaseTasks.map(([id, task]) => (
            <TaskRow
              key={id} taskId={id} task={task}
              onToggle={onToggleTask}
              onUpdate={onUpdateTask}
              onDelete={onDeleteTask}
              isCustom={task.custom}
            />
          ))}

          {/* Add custom task */}
          {showAdd ? (
            <div style={{ display: 'flex', gap: 8, marginTop: 8, padding: '0 12px' }}>
              <input className="input" placeholder="New task..." value={newTaskLabel}
                onChange={e => setNewTaskLabel(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') addTask(); if (e.key === 'Escape') { setShowAdd(false); setNewTaskLabel(''); }}}
                autoFocus />
              <button className="btn btn-primary btn-sm" onClick={addTask}>Add</button>
              <button className="btn btn-ghost btn-sm" onClick={() => { setShowAdd(false); setNewTaskLabel(''); }}>✕</button>
            </div>
          ) : (
            <button onClick={() => setShowAdd(true)}
              style={{
                background: 'none', border: '1px dashed var(--glass-border)',
                color: 'var(--text-muted)', cursor: 'pointer', borderRadius: 8,
                padding: '8px 16px', marginTop: 8, width: '100%', fontSize: 13,
              }}>
              + Add task
            </button>
          )}
        </div>
      )}
    </div>
  );
}

export default function Workspace({ launch, onUpdate, onBack }) {
  const progress = calcProgress(launch.tasks);
  const days = launch.launchDate ? daysUntil(launch.launchDate) : null;
  const allDone = progress === 100;
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const toggleTask = useCallback((taskId) => {
    onUpdate(l => ({
      ...l,
      tasks: { ...l.tasks, [taskId]: { ...l.tasks[taskId], done: !l.tasks[taskId].done } }
    }));
  }, [onUpdate]);

  const updateTask = useCallback((taskId, patch) => {
    onUpdate(l => ({
      ...l,
      tasks: { ...l.tasks, [taskId]: { ...l.tasks[taskId], ...patch } }
    }));
  }, [onUpdate]);

  const deleteTask = useCallback((taskId) => {
    onUpdate(l => {
      const tasks = { ...l.tasks };
      delete tasks[taskId];
      return { ...l, tasks };
    });
  }, [onUpdate]);

  const addTask = useCallback((phaseId, label) => {
    const id = 'custom_' + generateId();
    onUpdate(l => ({
      ...l,
      tasks: {
        ...l.tasks,
        [id]: { done: false, dueDate: '', notes: '', label, phaseId, custom: true }
      }
    }));
  }, [onUpdate]);

  const toggleCollapse = useCallback((phaseId) => {
    onUpdate(l => ({
      ...l,
      collapsedPhases: { ...l.collapsedPhases, [phaseId]: !l.collapsedPhases?.[phaseId] }
    }));
  }, [onUpdate]);

  function resetChecklist() {
    onUpdate(l => ({
      ...l,
      tasks: Object.fromEntries(
        Object.entries(l.tasks).map(([k, v]) => [k, { ...v, done: false }])
      )
    }));
    setShowResetConfirm(false);
  }

  return (
    <div style={{ padding: '20px 16px', maxWidth: 700, margin: '0 auto' }} className="fade-in">
      {/* Header */}
      <div style={{ marginBottom: 20 }}>
        <button onClick={onBack} style={{
          background: 'none', border: 'none', cursor: 'pointer',
          color: 'var(--text-muted)', fontSize: 13, padding: 0, marginBottom: 12,
          display: 'flex', alignItems: 'center', gap: 4,
        }}>← Back to Launches</button>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}>
          <div style={{ minWidth: 0 }}>
            <h1 style={{ fontSize: 20, fontWeight: 700, wordBreak: 'break-word' }}>{launch.name}</h1>
            <div style={{ display: 'flex', gap: 10, marginTop: 6, flexWrap: 'wrap', alignItems: 'center' }}>
              <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{launch.productType}</span>
              {launch.audience && <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>· {launch.audience}</span>}
              {launch.launchDate && (
                <span style={{
                  fontSize: 12,
                  color: days !== null && days < 0 ? 'var(--danger)' : days !== null && days <= 7 ? 'var(--warning)' : 'var(--text-muted)',
                }}>
                  · {formatDate(launch.launchDate)}
                  {days !== null && ` (${days < 0 ? `${Math.abs(days)}d late` : days === 0 ? 'Today!' : `${days}d left`})`}
                </span>
              )}
            </div>
          </div>
          <div style={{ textAlign: 'right', flexShrink: 0 }}>
            <div style={{ fontSize: 26, fontWeight: 700, color: 'var(--violet-light)' }}>{progress}%</div>
          </div>
        </div>

        <div className="progress-bar" style={{ marginTop: 12 }}>
          <div className="progress-fill" style={{ width: `${progress}%` }} />
        </div>
      </div>

      {/* Celebration */}
      {allDone && (
        <div className="glass celebrate" style={{
          padding: '20px 24px', marginBottom: 20, textAlign: 'center',
          border: '1px solid rgba(52,211,153,0.3)',
          background: 'rgba(52,211,153,0.06)',
        }}>
          <div style={{ fontSize: 28, marginBottom: 8 }}>🎉</div>
          <div style={{ fontSize: 18, fontWeight: 700, color: 'var(--success)' }}>
            All tasks complete!
          </div>
          <p style={{ fontSize: 14, color: 'var(--text-secondary)', marginTop: 4 }}>
            Your product is ready to launch. Time to go live!
          </p>
          {launch.salesUrl && (
            <a href={launch.salesUrl} target="_blank" rel="noreferrer"
              className="btn btn-primary" style={{ marginTop: 12, display: 'inline-flex' }}>
              View Sales Page ↗
            </a>
          )}
        </div>
      )}

      {/* Phases */}
      {LAUNCH_PHASES.map(phase => (
        <PhaseCard
          key={phase.id}
          phase={phase}
          tasks={launch.tasks}
          collapsed={launch.collapsedPhases?.[phase.id] || false}
          onToggleCollapse={toggleCollapse}
          onToggleTask={toggleTask}
          onUpdateTask={updateTask}
          onDeleteTask={deleteTask}
          onAddTask={addTask}
        />
      ))}

      {/* Reset */}
      <div style={{ marginTop: 12, textAlign: 'center' }}>
        {showResetConfirm ? (
          <div className="glass" style={{ padding: 16 }}>
            <p style={{ fontSize: 14, marginBottom: 12 }}>
              Reset all task checkboxes? This cannot be undone.
            </p>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'center' }}>
              <button className="btn btn-ghost btn-sm" onClick={() => setShowResetConfirm(false)}>Cancel</button>
              <button className="btn btn-danger btn-sm" onClick={resetChecklist}>Yes, Reset</button>
            </div>
          </div>
        ) : (
          <button className="btn btn-ghost btn-sm" onClick={() => setShowResetConfirm(true)}
            style={{ fontSize: 12, color: 'var(--text-muted)' }}>
            Reset Checklist
          </button>
        )}
      </div>
    </div>
  );
}
