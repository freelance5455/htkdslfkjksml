import React from 'react';

export default function BottomNav({ view, setView, onNewLaunch }) {
  const items = [
    { id: 'dashboard', label: 'Home', svg: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg> },
    { id: 'workspace', label: 'Tasks', svg: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 11l3 3 8-8"/><path d="M20 12v7a2 2 0 01-2 2H6a2 2 0 01-2-2V5a2 2 0 012-2h9"/></svg> },
    { id: 'new', label: 'New', svg: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M12 5v14M5 12h14"/></svg> },
    { id: 'launches', label: 'Launches', svg: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 6h16M4 10h16M4 14h8M4 18h8"/></svg> },
  ];

  return (
    <nav className="bottom-nav">
      {items.map(item => {
        if (item.id === 'new') {
          return (
            <button key="new" className="nav-item" onClick={onNewLaunch}
              style={{ color: 'var(--violet-light)' }}>
              <div style={{
                width: 38, height: 38,
                background: 'linear-gradient(135deg, var(--violet), var(--blue-dim))',
                borderRadius: '50%',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                boxShadow: '0 4px 16px rgba(124,92,191,0.4)',
              }}>
                {item.svg}
              </div>
              {item.label}
            </button>
          );
        }
        return (
          <button key={item.id} className={`nav-item${view === item.id ? ' active' : ''}`}
            onClick={() => setView(item.id)}>
            {item.svg}
            {item.label}
          </button>
        );
      })}
    </nav>
  );
}
