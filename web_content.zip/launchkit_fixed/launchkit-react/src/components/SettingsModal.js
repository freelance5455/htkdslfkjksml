import React, { useRef } from 'react';

export default function SettingsModal({ onClose, onExport, onImport, launchCount }) {
  const fileRef = useRef();

  function handleImportFile(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = evt => {
      onImport(evt.target.result);
      onClose();
    };
    reader.readAsText(file);
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()} style={{ maxWidth: 440 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <h2 style={{ fontSize: 18, fontWeight: 700 }}>Settings & Backup</h2>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', fontSize: 20, cursor: 'pointer' }}>✕</button>
        </div>

        {/* Storage info */}
        <div className="glass" style={{ padding: 16, marginBottom: 20 }}>
          <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 6 }}>STORAGE</div>
          <p style={{ fontSize: 14, color: 'var(--text-secondary)' }}>
            All data is stored locally in your browser. You have{' '}
            <span style={{ color: 'var(--text-primary)', fontWeight: 600 }}>{launchCount} launch{launchCount !== 1 ? 'es' : ''}</span>{' '}
            saved. Data persists after closing or refreshing the browser tab.
          </p>
        </div>

        {/* Export */}
        <div style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Export Backup</div>
          <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginBottom: 10 }}>
            Download all your launch data as a JSON file.
          </p>
          <button className="btn btn-ghost" style={{ width: '100%', justifyContent: 'center' }} onClick={onExport}>
            ↓ Download Backup
          </button>
        </div>

        <div className="divider" />

        {/* Import */}
        <div>
          <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Import Backup</div>
          <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginBottom: 10 }}>
            Restore data from a LaunchKit JSON backup. This will replace all current data.
          </p>
          <input ref={fileRef} type="file" accept=".json" style={{ display: 'none' }}
            onChange={handleImportFile} />
          <button className="btn btn-ghost" style={{ width: '100%', justifyContent: 'center' }}
            onClick={() => fileRef.current.click()}>
            ↑ Import Backup
          </button>
        </div>

        <div className="divider" />

        <p style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'center' }}>
          LaunchKit v1.0 · All data stays on your device
        </p>
      </div>
    </div>
  );
}
