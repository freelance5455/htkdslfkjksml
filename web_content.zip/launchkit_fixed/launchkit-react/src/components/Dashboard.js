import React from 'react';
import { calcProgress, daysUntil, formatDate } from '../data';

function StatCard({ label, value, color }) {
  return (
    <div className="glass" style={{ padding: '16px 20px', flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 22, fontWeight: 700, color: color || 'var(--text-primary)' }}>{value}</div>
      <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 3 }}>{label}</div>
    </div>
  );
}

export default function Dashboard({ launches, onNewLaunch, onOpenWorkspace, activeLaunch }) {
  const activeLaunches = launches.filter(l => !l.archived);
  const progress = activeLaunch ? calcProgress(activeLaunch.tasks) : 0;
  const days = activeLaunch?.launchDate ? daysUntil(activeLaunch.launchDate) : null;
  const allTasks = activeLaunch ? Object.values(activeLaunch.tasks) : [];
  const doneTasks = allTasks.filter(t => t.done).length;
  const remaining = allTasks.length - doneTasks;

  // Recent activity: last 5 completed tasks
  const recentDone = activeLaunch
    ? Object.entries(activeLaunch.tasks)
        .filter(([, t]) => t.done)
        .slice(-5).reverse()
    : [];

  // Upcoming: first 5 undone tasks
  const upcoming = activeLaunch
    ? Object.entries(activeLaunch.tasks)
        .filter(([, t]) => !t.done)
        .slice(0, 5)
    : [];

  return (
    <div style={{ padding: '24px 20px', maxWidth: 720, margin: '0 auto' }} className="fade-in">
      {/* Header */}
      <div style={{ marginBottom: 28 }}>
        <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 6, letterSpacing: 1 }}>
          LAUNCHKIT
        </p>
        <h1 style={{ fontSize: 26, fontWeight: 700, lineHeight: 1.2 }}>
          Let's launch something great.
        </h1>
        {activeLaunches.length === 0 && (
          <p style={{ color: 'var(--text-secondary)', fontSize: 14, marginTop: 8 }}>
            Start by creating your first product launch.
          </p>
        )}
      </div>

      {/* CTA */}
      <button className="btn btn-primary" onClick={onNewLaunch}
        style={{ marginBottom: 28, gap: 8 }}>
        <span style={{ fontSize: 18, lineHeight: 1 }}>+</span>
        Create New Launch
      </button>

      {/* Active launch card */}
      {activeLaunch ? (
        <div className="glass" style={{ padding: 24, marginBottom: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16, gap: 12 }}>
            <div style={{ minWidth: 0 }}>
              <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 4 }}>ACTIVE LAUNCH</div>
              <h2 style={{ fontSize: 18, fontWeight: 600, marginBottom: 4, wordBreak: 'break-word' }}>
                {activeLaunch.name}
              </h2>
              {activeLaunch.launchDate && (
                <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>
                  📅 {formatDate(activeLaunch.launchDate)}
                  {days !== null && (
                    <span style={{
                      marginLeft: 8, fontSize: 12,
                      color: days < 0 ? 'var(--danger)' : days <= 7 ? 'var(--warning)' : 'var(--success)',
                    }}>
                      {days < 0 ? `${Math.abs(days)}d overdue` : days === 0 ? 'Today!' : `${days}d left`}
                    </span>
                  )}
                </div>
              )}
            </div>
            <div style={{ textAlign: 'right', flexShrink: 0 }}>
              <div style={{ fontSize: 28, fontWeight: 700, color: 'var(--violet-light)' }}>{progress}%</div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>complete</div>
            </div>
          </div>

          <div className="progress-bar" style={{ marginBottom: 20 }}>
            <div className="progress-fill" style={{ width: `${progress}%` }} />
          </div>

          {/* Stats row */}
          <div style={{ display: 'flex', gap: 10, marginBottom: 20 }}>
            <StatCard label="Done" value={doneTasks} color="var(--success)" />
            <StatCard label="Remaining" value={remaining} color="var(--warning)" />
            {days !== null && <StatCard label="Days left" value={days < 0 ? '—' : days} />}
          </div>

          <button className="btn btn-ghost" style={{ width: '100%', justifyContent: 'center' }}
            onClick={() => onOpenWorkspace(activeLaunch.id)}>
            Open Workspace →
          </button>
        </div>
      ) : (
        <div className="glass" style={{ padding: 32, textAlign: 'center', marginBottom: 20 }}>
          <div style={{ fontSize: 32, marginBottom: 12 }}>🚀</div>
          <p style={{ color: 'var(--text-secondary)', fontSize: 15 }}>
            No active launch yet. Create one to get started.
          </p>
        </div>
      )}

      {/* Two-col upcoming + recent */}
      {activeLaunch && (upcoming.length > 0 || recentDone.length > 0) && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          {upcoming.length > 0 && (
            <div className="glass" style={{ padding: 18 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-muted)', marginBottom: 12, letterSpacing: 0.5 }}>
                UP NEXT
              </div>
              {upcoming.map(([id, t]) => (
                <div key={id} style={{
                  fontSize: 13, color: 'var(--text-secondary)',
                  padding: '6px 0', borderBottom: '1px solid rgba(255,255,255,0.04)',
                  lineHeight: 1.4,
                }}>
                  ○ {t.label}
                </div>
              ))}
            </div>
          )}
          {recentDone.length > 0 && (
            <div className="glass" style={{ padding: 18 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-muted)', marginBottom: 12, letterSpacing: 0.5 }}>
                COMPLETED
              </div>
              {recentDone.map(([id, t]) => (
                <div key={id} style={{
                  fontSize: 13, color: 'var(--success)',
                  padding: '6px 0', borderBottom: '1px solid rgba(255,255,255,0.04)',
                  lineHeight: 1.4, opacity: 0.8,
                }}>
                  ✓ {t.label}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Other launches */}
      {activeLaunches.length > 1 && (
        <div style={{ marginTop: 20 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-muted)', marginBottom: 12, letterSpacing: 0.5 }}>
            OTHER LAUNCHES
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {activeLaunches.filter(l => l.id !== activeLaunch?.id).slice(0, 3).map(l => (
              <button key={l.id} className="glass btn btn-ghost"
                style={{ justifyContent: 'space-between', padding: '12px 16px' }}
                onClick={() => onOpenWorkspace(l.id)}>
                <span style={{ fontSize: 14, fontWeight: 500 }}>{l.name}</span>
                <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>
                  {calcProgress(l.tasks)}%
                </span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
