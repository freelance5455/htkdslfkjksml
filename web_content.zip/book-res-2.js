/* JOSTECH — MANUEL 06 : RÉSEAUX & MAINTENANCE NIVEAU 2 */
registerLessonDetail(6, 2, "res-2-1-1", {
  title: "Leçon 1 : Modèles OSI & TCP/IP, Encapsulation, Switch et Routeur",
  duration: "45 min (Manuel complet)",
  objectives: [
    "Maîtriser les 7 couches du modèle OSI et leurs correspondances avec TCP/IP.",
    "Comprendre l'encapsulation descendante des données (PDU : Donnée → Segment → Paquet → Trame → Bits).",
    "Distinguer Switch (Couche 2 / MAC), Routeur (Couche 3 / IP), Protocole ARP et TCP vs UDP."
  ],
  prerequisites: ["Niveau 1 et notions de binaire/hexadécimal."],
  sections: [
    {
      type: "theory",
      title: "1. Pourquoi un modèle en couches (OSI et TCP/IP) ?",
      text: "Envoyer une page Web d'un serveur à votre smartphone implique des dizaines de problèmes différents : câbles/ondes radio, adressage local, routage mondial, perte de paquets et affichage HTTP. Le modèle théorique OSI (7 couches) et le modèle pratique d'Internet TCP/IP (4 couches) découpent cette complexité : chaque couche rend un service à celle du dessus en ajoutant son propre en-tête (Encapsulation)."
    },
    {
      type: "table",
      title: "2. Les 7 Couches OSI, Unités (PDU) et Équipements",
      headers: ["Couche OSI", "PDU / Adresse", "Protocoles & Équipements"],
      rows: [
        ["7-5. Application / Prés. / Sess.", "Données", "HTTP/HTTPS (80/443), DNS (53), SSH (22), SMTP."],
        ["4. Transport", "Segment (Port)", "TCP (fiable, accusés) et UDP (rapide, streaming/DNS)."],
        ["3. Réseau", "Paquet (Adresse IP)", "IPv4/IPv6, ICMP (ping), Routeur (interconnecte les réseaux)."],
        ["2. Liaison de données", "Trame (Adresse MAC)", "Ethernet, Wi-Fi, Switch (commute dans le réseau local), ARP."],
        ["1. Physique", "Bits (0 et 1)", "Câble RJ45, Fibre optique, Ondes radio, Répéteur."]
      ]
    },
    {
      type: "definition",
      term: "Protocole ARP et Poignée de main TCP (3-Way Handshake)",
      text: "• ARP (Address Resolution Protocol) : permet à un PC connaissant l'IP du routeur (ex. 192.168.1.1) de crier en broadcast sur le réseau local « Qui a cette IP ? Donnez-moi sa carte MAC ! ».\n• TCP (Transmission Control Protocol) : avant d'envoyer un fichier, client et serveur établissent un canal fiable en 3 étapes : SYN → SYN-ACK → ACK, et réexpédient tout segment perdu.\n• UDP : envoie sans établir de connexion ni vérifier l'arrivée — idéal pour les appels vidéo temps réel où attendre un vieux paquet ferait saccader la voix."
    },
    {
      type: "warning",
      title: "Différence Switch vs Routeur (Question classique d'examen)",
      text: "Un Switch (Couche 2) relie des machines au sein d'un MÊME réseau local (LAN) grâce à sa table d'adresses MAC physiques (48 bits en hexa, ex: 00:1A:2B:3C:4D:5E). Un Routeur (Couche 3) relie PLUSIEURS réseaux différents (ex: votre LAN vers Internet) grâce aux adresses IP logiques et à sa table de routage."
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Encapsulation réseau",
      question: "Classez du haut vers le bas (couche 7 → couche 1) l'unité de données manipulée : Trame, Segment, Bits, Paquet, Donnée HTTP.",
      solution: "Donnée HTTP (Couche 7) → Segment TCP (Couche 4) → Paquet IP (Couche 3) → Trame Ethernet (Couche 2) → Bits (Couche 1)."
    },
    {
      title: "Exercice 2 — Ports réseau bien connus",
      question: "Sur un serveur Linux JOSTECH, un pare-feu bloque tout sauf les ports TCP 22 et 443. Quels deux services restent accessibles ?",
      solution: "Port 22 = SSH (administration à distance chiffrée) et Port 443 = HTTPS (site Web sécurisé)."
    }
  ],
  summary: "L'encapsulation OSI structure les communications : les applications utilisent des ports en couche 4 (TCP fiable / UDP rapide), les routeurs acheminent les paquets IP (couche 3) et les switches livrent les trames MAC (couche 2).",
  references: ["Tanenbaum, A. — Réseaux (5e éd.), Pearson.", "Kurose & Ross — Computer Networking: A Top-Down Approach."]
});