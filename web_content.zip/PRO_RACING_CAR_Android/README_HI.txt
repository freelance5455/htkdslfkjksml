PRO RACING CAR — Android Studio Project

यह एक Android WebView ऐप प्रोजेक्ट है जो आपके दिए गए index.html गेम को Android ऐप में चलाता है।

APK बनाने के लिए:
1. Android Studio इंस्टॉल करें।
2. इस ZIP को Extract करें।
3. Android Studio में Extract किया हुआ PRO_RACING_CAR_Android फ़ोल्डर Open करें।
4. Gradle Sync पूरा होने दें (Android SDK Platform 35 आवश्यक हो सकता है)।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. APK यहाँ मिलेगा: app/build/outputs/apk/debug/app-debug.apk

ध्यान दें:
- इस प्रोजेक्ट में स्थानीय 2D गेम शामिल है।
- Online Mode अभी lobby preview/local practice ही है; असली multiplayer server इसमें शामिल नहीं है।
- Owner फोटो के लिए अस्थायी PK Gaming चित्र है। अपनी फोटो लगाने के लिए app/src/main/assets/owner-photo.png बदलें।
- यह source project है, पहले से compiled/signed APK नहीं।
