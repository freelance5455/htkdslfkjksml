#!/bin/sh
cd /sdcard/toancube
shizuku exec node aim.js &
node vnp.js &
node shizuku_bridge.js &
echo "Toan Cube AIM+VNP started" > log.txt