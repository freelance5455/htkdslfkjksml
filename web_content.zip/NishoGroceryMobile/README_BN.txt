NISHO GROCERY — মোবাইল থেকে শুরু করার প্যাকেজ

public/index.html হলো ইনস্টলযোগ্য ওয়েব অ্যাপের প্রথম UI প্রোটোটাইপ। এতে পণ্যের তালিকা, কার্ট, COD checkout, অর্ডার তালিকা এবং নির্ধারিত delivery charge-এর হিসাব আছে।

গুরুত্বপূর্ণ সীমাবদ্ধতা:
- এই সংস্করণে অর্ডার শুধু সেই ফোনের browser localStorage-এ থাকে। দোকানদার/অ্যাডমিন/অন্য গ্রাহক দেখতে পারবেন না।
- এটি লাইভ production app বা APK নয়। দামগুলো নমুনা; দোকানদারকে প্রকৃত দাম ও স্টক বসাতে হবে।
- বাস্তব ব্যবহারকারীর জন্য HTTPS hosting, secure authentication, shared online database, role-based permissions, server-side order creation, privacy policy ও testing আবশ্যক।

শুধু Android মোবাইল দিয়ে পরের ধাপ:
1. ZIP ফাইল Extract করুন (Files app বা ZArchiver ব্যবহার করা যায়)।
2. public ফোল্ডারের ফাইলগুলো অনলাইন hosting-এ প্রকাশ করতে হবে। শুধু HTML ফাইল WhatsApp-এ পাঠালে বহু-ব্যবহারকারীর সিস্টেম হবে না।
3. Firebase/সমমানের backend project তৈরি করে authentication, database rules, hosting ও app configuration করতে হবে। Firebase configuration না থাকায় এখানে তা যোগ করা হয়নি।
4. লাইভ URL HTTPS-এ খুলে Chrome menu > Add to Home screen / Install app দিয়ে PWA হিসেবে ইনস্টল করা যায়।
5. APK চাইলে Android build service বা কম্পিউটার/ডেভেলপার দিয়ে WebView/Capacitor wrapper build, sign ও test করতে হবে।

ডেলিভারি চার্জ: ১ কিমি ₹১০; এরপর প্রতি অতিরিক্ত কিমি ₹৫; সর্বোচ্চ ৫ কিমি। UI-তে দূরত্বের অপশন দেওয়া আছে; বাস্তবে দোকান থেকে রুটের দূরত্ব backend-এ যাচাই করতে হবে।
