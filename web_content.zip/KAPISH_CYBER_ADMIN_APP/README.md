# KAPISH CYBER ADMIN APP

Android Studio project for wrapping the KAPISH CYBER Admin Panel in an Android app.

## Important
The bundled admin page is a WebView shell. For true online real-time Add/Edit/Delete, the app must load the deployed KAPISH CYBER server URL instead of the local `file:///android_asset/admin.html` page. Do not put admin passwords or API secrets directly in the APK.

## Build
Open this folder in Android Studio, let Gradle sync, then Build > Build APK(s).
