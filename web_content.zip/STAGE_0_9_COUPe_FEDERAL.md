# CGD V117 — Socle 0.9 : Coupe Fédéral

## Décision
Ajout de la huitième compétition, **Coupe Fédéral**, à côté des sept compétitions historiques qui restent distinctes et conservées.

## Format adapté de la Carabao Cup
- Tous les clubs des divisions actives participent.
- Élimination directe, match unique par confrontation.
- Tirage au sort reproductible par saison.
- En cas d'égalité, départage aux tirs au but.
- Finale sur terrain neutre.
- Pas de match retour.
- Les rencontres utilisent le moteur commun de dames et sont enregistrées dans le calendrier central.
- Les statistiques de Coupe Fédéral sont séparées des statistiques du championnat.
- Le tableau progresse automatiquement jusqu'au champion.

## Vérifications
- 64 tests réussis, 0 échec.
- Vérification syntaxique de tous les modules JavaScript et tests.
- Les tests couvrent la conservation des sept anciennes compétitions, l'ajout de la huitième, la migration d'une sauvegarde à sept compétitions, les 36 participants initiaux, le déroulement complet jusqu'au champion, la finale neutre, les tirs au but, la séparation des statistiques et la simulation IA par le moteur de dames.
- Le test navigateur réel n'a pas été validé dans cet environnement ; la vérification repose sur les tests automatisés et la syntaxe.
