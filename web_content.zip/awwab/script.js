(function () {
    'use strict';

    // الحالة: 0 = كل الصور، 1 = المفضلة، 2 = الألبومات
    var state = {
        photos: [],              // { id, name, url }
        favorites: new Set(),    // معرّفات الصور المفضلة
        tab: 0,
        query: '',
        selected: null
    };

    var FAV_KEY = 'awwb.favorites';
    var DB_NAME = 'awwb';
    var STORE = 'photos';

    var listView = document.getElementById('list-view');
    var detailView = document.getElementById('detail');
    var content = document.getElementById('content');
    var search = document.getElementById('search');
    var picker = document.getElementById('picker');
    var detailImg = document.getElementById('detailImg');
    var favBtn = document.getElementById('favBtn');
    var favText = document.getElementById('favText');
    var backBtn = document.getElementById('backBtn');
    var deleteBtn = document.getElementById('deleteBtn');
    var tabButtons = document.querySelectorAll('[data-tab]');

    // ---------- أيقونات مدمجة (تعمل بدون إنترنت) ----------
    var ICONS = {
        star: 'M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z',
        search: 'M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z',
        home: 'M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z',
        folder: 'M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z',
        favorite: 'M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z',
        delete: 'M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z',
        check: 'M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z',
        add_photo_alternate: 'M14 10h-3V7h-2v3H6v2h3v3h2v-3h3v-2zm5-7H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zM2 6v14c0 1.1.9 2 2 2h14v-2H4V6H2z',
        folder_open: 'M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z'
    };

    function iconSvg(name) {
        var p = ICONS[name];
        return p ? '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="' + p + '"/></svg>' : '';
    }

    function fillIcons(root) {
        (root || document).querySelectorAll('.material-icons').forEach(function (n) {
            var name = n.textContent.trim();
            if (ICONS[name]) n.innerHTML = iconSvg(name);
        });
    }

    // ---------- أدوات مساعدة ----------
    function el(tag, cls, text) {
        var n = document.createElement(tag);
        if (cls) n.className = cls;
        if (text !== undefined) n.textContent = text;
        return n;
    }

    function icon(name, cls) {
        var i = el('span', 'material-icons' + (cls ? ' ' + cls : ''));
        i.innerHTML = iconSvg(name);
        i.setAttribute('aria-hidden', 'true');
        return i;
    }

    // ---------- التخزين ----------
    function loadFavorites() {
        try {
            var arr = JSON.parse(localStorage.getItem(FAV_KEY) || '[]');
            if (Array.isArray(arr)) arr.forEach(function (id) { state.favorites.add(id); });
        } catch (e) { /* تجاهل */ }
    }

    function saveFavorites() {
        try {
            localStorage.setItem(FAV_KEY, JSON.stringify(Array.from(state.favorites)));
        } catch (e) { /* تجاهل */ }
    }

    var dbPromise = null;
    function openDB() {
        if (!dbPromise) {
            dbPromise = new Promise(function (resolve, reject) {
                var req = indexedDB.open(DB_NAME, 1);
                req.onupgradeneeded = function () {
                    req.result.createObjectStore(STORE, { keyPath: 'id' });
                };
                req.onsuccess = function () { resolve(req.result); };
                req.onerror = function () { reject(req.error); };
            });
        }
        return dbPromise;
    }

    function dbGetAll() {
        return openDB().then(function (db) {
            return new Promise(function (resolve, reject) {
                var r = db.transaction(STORE, 'readonly').objectStore(STORE).getAll();
                r.onsuccess = function () { resolve(r.result); };
                r.onerror = function () { reject(r.error); };
            });
        });
    }

    function dbPut(rec) {
        return openDB().then(function (db) {
            return new Promise(function (resolve, reject) {
                var tx = db.transaction(STORE, 'readwrite');
                tx.objectStore(STORE).put(rec);
                tx.oncomplete = function () { resolve(); };
                tx.onerror = function () { reject(tx.error); };
            });
        });
    }

    function dbDelete(id) {
        return openDB().then(function (db) {
            return new Promise(function (resolve, reject) {
                var tx = db.transaction(STORE, 'readwrite');
                tx.objectStore(STORE).delete(id);
                tx.oncomplete = function () { resolve(); };
                tx.onerror = function () { reject(tx.error); };
            });
        });
    }

    // ---------- المنطق ----------
    function sourcePhotos() {
        if (state.tab === 1) {
            return state.photos.filter(function (p) { return state.favorites.has(p.id); });
        }
        if (state.tab === 2) return [];
        return state.photos;
    }

    function toggleFavorite(id) {
        if (state.favorites.has(id)) state.favorites.delete(id);
        else state.favorites.add(id);
        saveFavorites();
    }

    // ---------- العرض ----------
    function render() {
        var sel = state.photos.find(function (p) { return p.id === state.selected; });
        if (state.selected && !sel) state.selected = null;

        if (state.selected) {
            listView.hidden = true;
            detailView.hidden = false;
            detailImg.src = sel.url;
            detailImg.alt = '';
            favText.textContent = state.favorites.has(sel.id)
                ? 'إزالة من المفضلة'
                : 'إضافة إلى المفضلة';
            return;
        }

        detailView.hidden = true;
        listView.hidden = false;

        tabButtons.forEach(function (btn) {
            btn.classList.toggle('selected', Number(btn.dataset.tab) === state.tab);
        });

        renderContent();
    }

    function renderContent() {
        content.replaceChildren();

        if (state.tab === 2) {
            content.append(albumEmptyState());
            return;
        }

        var source = sourcePhotos();
        if (source.length === 0) {
            content.append(emptyState());
            return;
        }

        var q = state.query.toLowerCase();
        var items = state.query.trim() === ''
            ? source
            : source.filter(function (p) { return p.name.toLowerCase().includes(q); });

        var grid = el('div', 'grid');
        items.forEach(function (p) {
            var img = el('img', 'thumb');
            img.src = p.url;
            img.alt = 'صورة محفوظة';
            img.loading = 'lazy';
            img.addEventListener('click', function () {
                state.selected = p.id;
                render();
            });
            grid.append(img);
        });
        content.append(grid);
    }

    function emptyState() {
        var wrap = el('div', 'empty');
        wrap.append(icon('star', 'gold icon-xl'));
        wrap.append(el('h2', 'empty-title', 'مرحباً بك في أواب'));
        wrap.append(el('p', 'empty-sub', 'أضف صورك لتبدأ بتنظيم ذكرياتك'));

        var btn = el('button', 'btn-gold');
        btn.type = 'button';
        btn.append(icon('add_photo_alternate'), el('span', null, 'إضافة صور'));
        btn.addEventListener('click', function () { picker.click(); });
        wrap.append(btn);
        return wrap;
    }

    function albumEmptyState() {
        var wrap = el('div', 'album');
        wrap.append(icon('folder', 'gold icon-lg'));
        wrap.append(el('h2', null, 'الألبومات'));
        wrap.append(el('p', null, 'يمكنك إضافة الصور الآن، وإنشاء ألبومات مخصصة في إصدار قادم.'));

        var btn = el('button', 'btn-text', 'اختيار صور');
        btn.type = 'button';
        btn.addEventListener('click', function () { picker.click(); });
        wrap.append(btn);
        return wrap;
    }

    // ---------- الأحداث ----------
    picker.addEventListener('change', async function () {
        var files = Array.from(picker.files || []);
        picker.value = '';

        for (var i = 0; i < files.length; i++) {
            var file = files[i];
            var id = file.name + '|' + file.size + '|' + file.lastModified;
            if (state.photos.some(function (p) { return p.id === id; })) continue;

            // نسخ محتوى الصورة داخل التطبيق حتى لا تفقد الإشارة إلى الملف الأصلي بعد إغلاق التطبيق
            var blob;
            try {
                blob = new Blob([await file.arrayBuffer()], { type: file.type || 'image/jpeg' });
            } catch (e) { continue; }

            state.photos.push({ id: id, name: file.name, url: URL.createObjectURL(blob) });
            try {
                await dbPut({ id: id, name: file.name, blob: blob });
            } catch (e) { /* الصورة تبقى ظاهرة في هذه الجلسة */ }
        }
        render();
    });

    tabButtons.forEach(function (btn) {
        btn.addEventListener('click', function () {
            state.tab = Number(btn.dataset.tab);
            render();
        });
    });

    search.addEventListener('input', function () {
        state.query = search.value;
        renderContent();
    });

    backBtn.addEventListener('click', function () {
        state.selected = null;
        render();
    });

    favBtn.addEventListener('click', function () {
        if (!state.selected) return;
        toggleFavorite(state.selected);
        render();
    });

    // حذف من التطبيق فقط (لا يُحذف من الهاتف أو المعرض)
    deleteBtn.addEventListener('click', function () {
        var id = state.selected;
        if (!id) return;
        if (!window.confirm('حذف هذه الصورة من التطبيق فقط؟\nلن تُحذف من الهاتف أو المعرض.')) return;

        var photo = state.photos.find(function (p) { return p.id === id; });
        if (photo) URL.revokeObjectURL(photo.url);

        state.photos = state.photos.filter(function (p) { return p.id !== id; });
        if (state.favorites.delete(id)) saveFavorites();
        state.selected = null;

        dbDelete(id).catch(function () { /* تجاهل */ });
        render();
    });

    // ---------- التشغيل ----------
    async function init() {
        loadFavorites();
        try {
            var records = await dbGetAll();
            state.photos = records.map(function (r) {
                return { id: r.id, name: r.name, url: URL.createObjectURL(r.blob) };
            });
        } catch (e) {
            state.photos = [];
        }
        render();
    }

    fillIcons();
    render();
    init();
})();
