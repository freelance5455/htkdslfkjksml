/* =========================================================
   MUEEN - GRADES
   دفتر الدرجات
========================================================= */

"use strict";


/* =========================================================
   HELPERS
========================================================= */

const $ = (id) => document.getElementById(id);


function safeParse(key, fallback = []) {

    try {

        const value =
            localStorage.getItem(key);

        if (!value) {
            return fallback;
        }

        const parsed =
            JSON.parse(value);

        return parsed ?? fallback;

    } catch (error) {

        console.warn(
            "Mueen: تعذر قراءة",
            key,
            error
        );

        return fallback;
    }
}


function saveJSON(key, value) {

    try {

        localStorage.setItem(
            key,
            JSON.stringify(value)
        );

        return true;

    } catch (error) {

        console.error(
            "Mueen: تعذر الحفظ",
            error
        );

        return false;
    }
}


function escapeHtml(value) {

    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}


function normalizeText(value) {

    return String(value ?? "")
        .trim()
        .replace(/\s+/g, " ");
}


function getNumber(value, fallback = 0) {

    const number =
        Number(value);

    return Number.isFinite(number)
        ? number
        : fallback;
}


function formatNumber(value) {

    const number =
        Number(value);

    if (!Number.isFinite(number)) {
        return "0";
    }

    if (Number.isInteger(number)) {
        return String(number);
    }

    return String(
        Math.round(number * 100) / 100
    );
}


function formatGrade(value) {

    if (
        value === "" ||
        value === null ||
        value === undefined
    ) {
        return "—";
    }

    const number =
        Number(value);

    if (!Number.isFinite(number)) {
        return "—";
    }

    return formatNumber(number);
}


function showMessage(message) {

    alert(message);
}


/* =========================================================
   STORAGE
========================================================= */

const STORAGE = {

    weeks:
        "mueen_school_weeks",

    subjects:
        "mueen_subjects",

    classes:
        "mueen_classes",

    records:
        "mueen_grade_records",

    evaluations:
        "mueen_grade_evaluations",

    exportContext:
        "mueen_grades_export_context",

    attendanceRecords:
        "mueen_attendance_records",

    attendanceSettings:
        "mueen_attendance_grade_settings",

    attendanceGrades:
        "mueen_attendance_grade_records"

};


/* =========================================================
   STATE
========================================================= */

const state = {

    weeks: [],

    subjects: [],

    classes: [],

    records: {},

    evaluations: [],

    attendanceRecords: [],

    attendanceSettings: {},

    attendanceGrades: {},

    selectedWeekId: "",

    selectedSubjectId: "",

    selectedClassId: "",

    activeFilter: {
        type: "all",
        id: ""
    },

    search: "",

    editingEvaluationId: null

};


/* =========================================================
   LOAD DATA
========================================================= */

function loadData() {

    state.weeks =
        safeParse(
            STORAGE.weeks,
            []
        );

    state.subjects =
        safeParse(
            STORAGE.subjects,
            []
        );

    state.classes =
        safeParse(
            STORAGE.classes,
            []
        );

    state.records =
        safeParse(
            STORAGE.records,
            {}
        );

    state.evaluations =
        safeParse(
            STORAGE.evaluations,
            []
        );

    state.attendanceRecords =
        safeParse(
            STORAGE.attendanceRecords,
            []
        );

    state.attendanceSettings =
        safeParse(
            STORAGE.attendanceSettings,
            {}
        );

    state.attendanceGrades =
        safeParse(
            STORAGE.attendanceGrades,
            {}
        );


    if (
        !Array.isArray(state.weeks)
    ) {

        state.weeks = [];
    }


    if (
        !Array.isArray(state.subjects)
    ) {

        state.subjects = [];
    }


    if (
        !Array.isArray(state.classes)
    ) {

        state.classes = [];
    }


    if (
        !Array.isArray(state.evaluations)
    ) {

        state.evaluations = [];
    }


    if (
        !Array.isArray(state.attendanceRecords)
    ) {

        state.attendanceRecords = [];
    }


    if (
        !state.records ||
        typeof state.records !== "object"
    ) {

        state.records = {};
    }


    if (
        !state.attendanceSettings ||
        typeof state.attendanceSettings !== "object"
    ) {

        state.attendanceSettings = {};
    }


    if (
        !state.attendanceGrades ||
        typeof state.attendanceGrades !== "object"
    ) {

        state.attendanceGrades = {};
    }

    // استرجاع بيانات النسخة الموحدة إذا كانت موجودة، ثم مزامنتها
    // مع المفاتيح القديمة حتى تبقى كل صفحات مُعين متوافقة.
    try {
        const modern = safeParse(
            localStorage.getItem("mueen_grades_data") || "",
            null
        );

        if (modern && typeof modern === "object") {
            if (!state.weeks.length && Array.isArray(modern.weeks)) {
                state.weeks = modern.weeks;
            }
            if (!state.evaluations.length && Array.isArray(modern.evaluations)) {
                state.evaluations = modern.evaluations;
            }
            if ((!state.records || !Object.keys(state.records).length) && modern.records && typeof modern.records === "object") {
                state.records = modern.records;
            }
        }
    } catch (_) {}
}


/* =========================================================
   GENERAL ID / NAME
========================================================= */

function getId(item) {

    if (!item) {
        return "";
    }

    return String(
        item.id ??
        item._id ??
        item.key ??
        ""
    );
}


function getName(item) {

    if (!item) {
        return "";
    }

    return normalizeText(
        item.name ??
        item.title ??
        item.label ??
        item.subjectName ??
        ""
    );
}


/* =========================================================
   WEEK HELPERS
========================================================= */

function getWeekName(week) {

    if (!week) {
        return "";
    }

    return normalizeText(
        week.name ??
        week.title ??
        week.label ??
        week.weekName ??
        `الأسبوع ${week.number ?? ""}`
    );
}


function getWeekNumber(week) {

    if (!week) {
        return "";
    }

    return (
        week.number ??
        week.weekNumber ??
        week.index ??
        ""
    );
}


function getDateFromObject(
    object,
    keys
) {

    if (!object) {
        return "";
    }

    for (const key of keys) {

        if (
            object[key] !== undefined &&
            object[key] !== null &&
            String(object[key]).trim() !== ""
        ) {

            return String(
                object[key]
            );
        }
    }

    return "";
}


function formatDateArabic(value) {

    if (!value) {
        return "";
    }

    const date =
        new Date(value);

    if (
        Number.isNaN(
            date.getTime()
        )
    ) {

        return String(value);
    }

    return new Intl.DateTimeFormat(
        "ar-EG",
        {
            day: "numeric",
            month: "long",
            year: "numeric"
        }
    ).format(date);
}


function getWeekDates(week) {

    if (!week) {

        return {
            start: "",
            end: "",
            text: "—"
        };
    }


    const start =
        getDateFromObject(
            week,
            [
                "startDate",
                "fromDate",
                "dateFrom",
                "start",
                "from",
                "beginDate",
                "begin"
            ]
        );


    const end =
        getDateFromObject(
            week,
            [
                "endDate",
                "toDate",
                "dateTo",
                "end",
                "to",
                "finishDate",
                "finish"
            ]
        );


    const startText =
        formatDateArabic(start);

    const endText =
        formatDateArabic(end);


    let text = "—";


    if (
        startText &&
        endText
    ) {

        text =
            `${startText} — ${endText}`;

    } else if (startText) {

        text =
            startText;

    } else if (endText) {

        text =
            endText;

    } else {

        const direct =
            getDateFromObject(
                week,
                [
                    "date",
                    "weekDate",
                    "dateText"
                ]
            );


        if (direct) {

            text =
                formatDateArabic(direct);

        } else {

            const textValue =
                getDateFromObject(
                    week,
                    [
                        "dates",
                        "dateRange",
                        "period"
                    ]
                );


            if (textValue) {

                text =
                    textValue;
            }
        }
    }


    return {
        start,
        end,
        text
    };
}


/* =========================================================
   SUBJECT / CLASS HELPERS
========================================================= */

function getSubjectName(subject) {

    return getName(subject);
}


function getClassName(classItem) {

    if (!classItem) {
        return "";
    }


    const direct =
        normalizeText(
            classItem.name ??
            classItem.title ??
            ""
        );


    if (direct) {
        return direct;
    }


    const grade =
        classItem.grade ??
        classItem.gradeName ??
        classItem.level ??
        "";


    const section =
        classItem.section ??
        classItem.sectionNumber ??
        classItem.classNumber ??
        "";


    if (
        grade !== "" &&
        section !== ""
    ) {

        return `${grade} / ${section}`;
    }


    return normalizeText(
        classItem.code ??
        classItem.classCode ??
        ""
    );
}


function getClassCode(classItem) {

    if (!classItem) {
        return "";
    }

    return normalizeText(
        classItem.code ??
        classItem.classCode ??
        classItem.slug ??
        getClassName(classItem)
    );
}


function getStudentsFromClass(classItem) {

    if (!classItem) {
        return [];
    }


    const possible =
        classItem.students ??
        classItem.studentList ??
        classItem.children ??
        classItem.members ??
        [];


    if (!Array.isArray(possible)) {
        return [];
    }


    return possible;
}


function getStudentId(
    student,
    index = 0
) {

    if (!student) {
        return `student-${index + 1}`;
    }


    const id =
        student.id ??
        student.studentId ??
        student._id ??
        student.key;


    if (
        id !== undefined &&
        id !== null &&
        String(id).trim() !== ""
    ) {

        return String(id);
    }


    const name =
        normalizeText(
            student.name ??
            student.studentName ??
            student.fullName ??
            student.title ??
            ""
        );


    if (name) {
        return `name-${name}`;
    }


    return `student-${index + 1}`;
}


function getStudentName(student) {

    return normalizeText(
        student?.name ??
        student?.studentName ??
        student?.fullName ??
        student?.title ??
        "طالب"
    );
}


/* =========================================================
   SELECTION
========================================================= */

function populateWeeks() {

    const select =
        $("weekSelect");

    if (!select) {
        return;
    }


    select.innerHTML =
        `<option value="">اختر الأسبوع</option>`;


    state.weeks.forEach(
        (week, index) => {

            const id =
                getId(week) ||
                String(index);


            const option =
                document.createElement(
                    "option"
                );


            option.value =
                id;


            const number =
                getWeekNumber(week);


            const name =
                getWeekName(week);


            option.textContent =
                name ||
                (
                    number !== ""
                        ? `الأسبوع ${number}`
                        : `الأسبوع ${index + 1}`
                );


            select.appendChild(
                option
            );
        }
    );


    if (
        state.selectedWeekId
    ) {

        select.value =
            state.selectedWeekId;
    }
}


function populateSubjects() {

    const select =
        $("gradeSubjectSelect");

    if (!select) {
        return;
    }


    select.innerHTML =
        `<option value="">اختر المادة</option>`;


    state.subjects.forEach(
        (subject, index) => {

            const id =
                getId(subject) ||
                String(index);


            const option =
                document.createElement(
                    "option"
                );


            option.value =
                id;


            option.textContent =
                getSubjectName(subject) ||
                `المادة ${index + 1}`;


            select.appendChild(
                option
            );
        }
    );


    if (
        state.selectedSubjectId
    ) {

        select.value =
            state.selectedSubjectId;
    }
}


function populateClasses() {

    const select =
        $("gradeClassSelect");

    if (!select) {
        return;
    }


    select.innerHTML =
        `<option value="">اختر الصف</option>`;


    state.classes.forEach(
        (classItem, index) => {

            const id =
                getId(classItem) ||
                String(index);


            const option =
                document.createElement(
                    "option"
                );


            option.value =
                id;


            option.textContent =
                getClassName(classItem) ||
                `الصف ${index + 1}`;


            select.appendChild(
                option
            );
        }
    );


    if (
        state.selectedClassId
    ) {

        select.value =
            state.selectedClassId;
    }
}


function getSelectedWeek() {

    return state.weeks.find(
        (week, index) =>
            (
                getId(week) ||
                String(index)
            ) ===
            String(
                state.selectedWeekId
            )
    );
}


function getSelectedSubject() {

    return state.subjects.find(
        (subject, index) =>
            (
                getId(subject) ||
                String(index)
            ) ===
            String(
                state.selectedSubjectId
            )
    );
}


function getSelectedClass() {

    return state.classes.find(
        (classItem, index) =>
            (
                getId(classItem) ||
                String(index)
            ) ===
            String(
                state.selectedClassId
            )
    );
}


/* =========================================================
   WEEK INFO
========================================================= */

function renderSelectionInfo() {

    const week =
        getSelectedWeek();


    const classItem =
        getSelectedClass();


    const weekInfo =
        $("weekSelectedInfo");


    const weekText =
        $("weekSelectedText");


    const weekDates =
        $("weekSelectedDates");


    const classCode =
        $("selectedClassCode");


    if (
        week &&
        weekInfo
    ) {

        const dates =
            getWeekDates(week);


        weekText.textContent =
            getWeekName(week) ||
            "الأسبوع";


        weekDates.textContent =
            dates.text;


        weekInfo.classList.remove(
            "hidden"
        );

    } else if (weekInfo) {

        weekInfo.classList.add(
            "hidden"
        );
    }


    if (
        classItem &&
        classCode
    ) {

        classCode.textContent =
            `الصف المحدد: ${getClassName(classItem)}`;


        classCode.classList.remove(
            "hidden"
        );

    } else if (classCode) {

        classCode.classList.add(
            "hidden"
        );
    }
}


/* =========================================================
   EVALUATION HELPERS
========================================================= */

function getCurrentEvaluationList() {

    const weekId =
        String(
            state.selectedWeekId
        );


    const subjectId =
        String(
            state.selectedSubjectId
        );


    const classId =
        String(
            state.selectedClassId
        );


    return state.evaluations
        .filter(
            (evaluation) => {

                const evaluationWeek =
                    String(
                        evaluation.weekId ??
                        evaluation.week ??
                        ""
                    );


                const evaluationSubject =
                    String(
                        evaluation.subjectId ??
                        evaluation.subject ??
                        ""
                    );


                const evaluationClass =
                    String(
                        evaluation.classId ??
                        evaluation.class ??
                        ""
                    );


                return (
                    evaluationWeek === weekId &&
                    evaluationSubject === subjectId &&
                    evaluationClass === classId
                );
            }
        )
        .sort(
            (a, b) =>
                getNumber(
                    a.order ??
                    a.index,
                    0
                ) -
                getNumber(
                    b.order ??
                    b.index,
                    0
                )
        );
}


function getEvaluationId(
    evaluation,
    index = 0
) {

    return String(
        evaluation?.id ??
        evaluation?._id ??
        evaluation?.key ??
        `evaluation-${index + 1}`
    );
}


function getEvaluationName(
    evaluation
) {

    return normalizeText(
        evaluation?.name ??
        evaluation?.title ??
        evaluation?.label ??
        "تقييم"
    );
}


function getEvaluationMax(
    evaluation
) {

    return getNumber(
        evaluation?.max ??
        evaluation?.maxGrade ??
        evaluation?.total ??
        evaluation?.fullMark,
        0
    );
}


/* =========================================================
   RECORD HELPERS
========================================================= */

function makeRecordKey(
    weekId,
    subjectId,
    classId,
    studentId,
    evaluationId
) {

    return [
        String(weekId),
        String(subjectId),
        String(classId),
        String(studentId),
        String(evaluationId)
    ].join("::");
}


function getGrade(
    studentId,
    evaluationId
) {

    const weekId =
        state.selectedWeekId;


    const subjectId =
        state.selectedSubjectId;


    const classId =
        state.selectedClassId;


    const key =
        makeRecordKey(
            weekId,
            subjectId,
            classId,
            studentId,
            evaluationId
        );


    if (
        Object.prototype.hasOwnProperty.call(
            state.records,
            key
        )
    ) {

        return state.records[key];
    }


    const nested =
        state.records?.[
            weekId
        ]?.[
            subjectId
        ]?.[
            classId
        ]?.[
            studentId
        ]?.[
            evaluationId
        ];


    if (nested !== undefined) {
        return nested;
    }

    // توافق إضافي مع السجلات القديمة التي استخدمت اسم التقييم
    // بدل معرفه داخل مفتاح التخزين.
    const evaluation = state.evaluations.find(item =>
        String(getEvaluationId(item)) === String(evaluationId)
    );
    const evaluationNameValue = normalizeText(evaluation?.name ?? evaluation?.title ?? evaluation?.label ?? "");
    const wantedStudent = String(studentId);
    const wantedStudentName = (() => {
        const student = getStudentsFromClass(getSelectedClass()).find((item, index) => getStudentId(item, index) === wantedStudent);
        return normalizeText(student?.name ?? student?.studentName ?? student?.fullName ?? "");
    })();
    const wantedParts = [String(weekId), String(subjectId), String(classId)];

    for (const [rawKey, rawValue] of Object.entries(state.records || {})) {
        const parts = String(rawKey).includes("::") ? String(rawKey).split("::") : String(rawKey).split("|||");
        if (parts.length < 5) continue;
        const [rw, rs, rc, rst, re] = parts;
        if (String(rw) !== wantedParts[0] || String(rs) !== wantedParts[1] || String(rc) !== wantedParts[2]) continue;
        const studentMatches = String(rst) === wantedStudent || (wantedStudentName && normalizeText(rst) === wantedStudentName);
        if (!studentMatches) continue;
        if (String(re) === String(evaluationId) || (evaluationNameValue && normalizeText(re) === evaluationNameValue)) return rawValue;
    }

    return "";
}


function syncUnifiedGradeStorage() {

    try {
        const unified = {
            version: 1,
            updatedAt: Date.now(),
            weeks: Array.isArray(state.weeks) ? state.weeks : [],
            evaluations: Array.isArray(state.evaluations) ? state.evaluations : [],
            records: state.records && typeof state.records === "object" ? state.records : {}
        };

        localStorage.setItem(
            "mueen_grades_data",
            JSON.stringify(unified)
        );

        return true;
    } catch (error) {
        console.warn("MUEEN: تعذر مزامنة سجل الدرجات الموحد:", error);
        return false;
    }
}


function saveGrade(
    studentId,
    evaluationId,
    value
) {

    const key =
        makeRecordKey(
            state.selectedWeekId,
            state.selectedSubjectId,
            state.selectedClassId,
            studentId,
            evaluationId
        );


    if (
        value === "" ||
        value === null ||
        value === undefined
    ) {

        delete state.records[key];

    } else {

        state.records[key] =
            Number(value);
    }


    saveJSON(
        STORAGE.records,
        state.records
    );

    syncUnifiedGradeStorage();
}


/* =========================================================
   ATTENDANCE HELPERS
========================================================= */

function makeAttendanceContextKey() {

    return [
        String(state.selectedWeekId),
        String(state.selectedSubjectId),
        String(state.selectedClassId)
    ].join("::");
}


function makeAttendanceGradeKey(
    studentId
) {

    return [
        makeAttendanceContextKey(),
        String(studentId)
    ].join("::");
}


function getAttendanceMax() {

    const key =
        makeAttendanceContextKey();


    const saved =
        state.attendanceSettings?.[key];


    const number =
        Number(saved);


    if (
        Number.isFinite(number) &&
        number > 0
    ) {

        return number;
    }


    return 10;
}


function saveAttendanceMax(
    value
) {

    const number =
        Number(value);


    if (
        !Number.isFinite(number) ||
        number <= 0
    ) {

        return false;
    }


    const key =
        makeAttendanceContextKey();


    state.attendanceSettings[key] =
        number;


    return saveJSON(
        STORAGE.attendanceSettings,
        state.attendanceSettings
    );
}


/* =========================================================
   ATTENDANCE WEEK MATCHING
========================================================= */

function isDateInsideWeek(
    date,
    week
) {

    if (!date || !week) {
        return false;
    }


    const dates =
        getWeekDates(week);


    if (
        !dates.start ||
        !dates.end
    ) {

        return false;
    }


    const target =
        String(date)
            .slice(0, 10);


    const start =
        String(dates.start)
            .slice(0, 10);


    const end =
        String(dates.end)
            .slice(0, 10);


    return (
        target >= start &&
        target <= end
    );
}


/*
   الحصول على سجلات الحضور الخاصة
   بالأسبوع + المادة + الصف.

   في الحالة الطبيعية نعتمد على weekId.
   وإذا كان السجل القديم لا يحتوي weekId،
   نستخدم تاريخ السجل داخل فترة الأسبوع.
*/

function getCurrentAttendanceRecords() {

    const weekId =
        String(
            state.selectedWeekId
        );


    const subjectId =
        String(
            state.selectedSubjectId
        );


    const classId =
        String(
            state.selectedClassId
        );


    if (
        !weekId ||
        !subjectId ||
        !classId
    ) {

        return [];
    }


    const week =
        getSelectedWeek();


    return state.attendanceRecords
        .filter(
            (record) => {

                if (!record) {
                    return false;
                }


                const recordSubject =
                    String(
                        record.subjectId ??
                        ""
                    );


                const recordClass =
                    String(
                        record.classId ??
                        ""
                    );


                if (
                    recordSubject !== subjectId ||
                    recordClass !== classId
                ) {

                    return false;
                }


                const recordWeek =
                    String(
                        record.weekId ??
                        ""
                    );


                if (
                    recordWeek === weekId
                ) {

                    return true;
                }


                /*
                   دعم السجلات القديمة
                   التي لا تحتوي weekId.
                */

                if (
                    !recordWeek &&
                    week
                ) {

                    return isDateInsideWeek(
                        record.date,
                        week
                    );
                }


                return false;
            }
        );
}


/* =========================================================
   ATTENDANCE STUDENT HELPERS
========================================================= */

function getAttendanceStudentId(
    student,
    index = 0
) {

    if (!student) {
        return `student-${index + 1}`;
    }


    const id =
        student.id ??
        student.studentId ??
        student._id ??
        student.key;


    if (
        id !== undefined &&
        id !== null &&
        String(id).trim() !== ""
    ) {

        return String(id);
    }


    const name =
        normalizeText(
            student.name ??
            student.studentName ??
            student.fullName ??
            student.title ??
            ""
        );


    if (name) {
        return `name-${name}`;
    }


    return `student-${index + 1}`;
}


function attendanceRecordContainsStudentAbsence(
    record,
    studentId,
    student
) {

    const absentStudents =
        Array.isArray(
            record?.absentStudents
        )
            ? record.absentStudents
            : [];


    const wantedId =
        String(studentId);


    const studentName =
        normalizeText(
            getStudentName(student)
        );


    return absentStudents.some(
        (absentStudent, index) => {

            const absentId =
                getAttendanceStudentId(
                    absentStudent,
                    index
                );


            if (
                String(absentId) ===
                wantedId
            ) {

                return true;
            }


            const absentName =
                normalizeText(
                    absentStudent?.name ??
                    absentStudent?.studentName ??
                    absentStudent?.fullName ??
                    ""
                );


            if (
                studentName &&
                absentName &&
                studentName === absentName
            ) {

                return true;
            }


            return false;
        }
    );
}


function getStudentAbsenceCount(
    student,
    studentId
) {

    const records =
        getCurrentAttendanceRecords();


    if (
        records.length === 0
    ) {

        return 0;
    }


    let count =
        0;


    records.forEach(
        (record) => {

            if (
                attendanceRecordContainsStudentAbsence(
                    record,
                    studentId,
                    student
                )
            ) {

                count += 1;
            }
        }
    );


    return count;
}


function getTotalAttendanceDays() {

    return getCurrentAttendanceRecords()
        .length;
}


/*
   حساب درجة الحضور تلقائيًا:

   أيام الحضور =
   إجمالي الأيام المسجلة - أيام الغياب

   درجة الحضور =
   (أيام الحضور / إجمالي الأيام)
   × الدرجة النهائية
*/

function calculateAttendanceGrade(
    student,
    studentId
) {

    const recordsCount =
        getTotalAttendanceDays();


    const max =
        getAttendanceMax();


    if (
        recordsCount <= 0 ||
        max <= 0
    ) {

        return "";
    }


    const absenceCount =
        getStudentAbsenceCount(
            student,
            studentId
        );


    const presentDays =
        Math.max(
            0,
            recordsCount - absenceCount
        );


    const grade =
    (
        presentDays /
        recordsCount
    ) *
    max;


return Math.round(
    grade
);
}


function getManualAttendanceGrade(
    studentId
) {

    const key =
        makeAttendanceGradeKey(
            studentId
        );


    if (
        Object.prototype.hasOwnProperty.call(
            state.attendanceGrades,
            key
        )
    ) {

        return state.attendanceGrades[key];
    }


    return "";
}


function getAttendanceGrade(
    student,
    studentId
) {

    const manual =
        getManualAttendanceGrade(
            studentId
        );


    if (
        manual !== "" &&
        manual !== null &&
        manual !== undefined
    ) {

        return manual;
    }


    return calculateAttendanceGrade(
        student,
        studentId
    );
}


function saveAttendanceGrade(
    studentId,
    value
) {

    const key =
        makeAttendanceGradeKey(
            studentId
        );


    if (
        value === "" ||
        value === null ||
        value === undefined
    ) {

        delete state.attendanceGrades[key];

    } else {

        state.attendanceGrades[key] =
            Number(value);
    }


    saveJSON(
        STORAGE.attendanceGrades,
        state.attendanceGrades
    );
}


/* =========================================================
   TABLE FILTER
========================================================= */

function getVisibleEvaluations() {

    const evaluations =
        getCurrentEvaluationList();


    if (
        state.activeFilter.type ===
        "evaluation"
    ) {

        return evaluations.filter(
            (evaluation, index) =>
                getEvaluationId(
                    evaluation,
                    index
                ) ===
                String(
                    state.activeFilter.id
                )
        );
    }


    if (
        state.activeFilter.type ===
        "total"
    ) {

        return [];
    }


    return evaluations;
}


function renderActiveFilterLabel() {

    const label =
        $("activeFilterLabel");


    if (!label) {
        return;
    }


    if (
        state.activeFilter.type ===
        "total"
    ) {

        label.textContent =
            "المجموع فقط";

        return;
    }


    if (
        state.activeFilter.type ===
        "evaluation"
    ) {

        const evaluation =
            getCurrentEvaluationList()
                .find(
                    (item, index) =>
                        getEvaluationId(
                            item,
                            index
                        ) ===
                        String(
                            state.activeFilter.id
                        )
                );


        label.textContent =
            evaluation
                ? getEvaluationName(evaluation)
                : "التقييم";

        return;
    }


    label.textContent =
        "كل التقييمات";
}


/* =========================================================
   RENDER FILTERS
========================================================= */

function renderEvaluationFilters() {

    const container =
        $("evaluationFilterList");


    if (!container) {
        return;
    }


    container.innerHTML =
        "";


    const evaluations =
        getCurrentEvaluationList();


    evaluations.forEach(
        (evaluation, index) => {

            const id =
                getEvaluationId(
                    evaluation,
                    index
                );


            const button =
                document.createElement(
                    "button"
                );


            button.type =
                "button";


            button.className =
                "filter-option";


            button.dataset.filter =
                "evaluation";


            button.dataset.id =
                id;


            button.textContent =
                getEvaluationName(
                    evaluation
                );


            if (
                state.activeFilter.type ===
                    "evaluation" &&
                String(
                    state.activeFilter.id
                ) === id
            ) {

                button.classList.add(
                    "active"
                );
            }


            container.appendChild(
                button
            );
        }
    );


    updateFilterButtons();
}


function updateFilterButtons() {

    const all =
        $("filterAllButton");


    const total =
        $("filterTotalButton");


    if (all) {

        all.classList.toggle(
            "active",
            state.activeFilter.type === "all"
        );
    }


    if (total) {

        total.classList.toggle(
            "active",
            state.activeFilter.type === "total"
        );
    }


    document
        .querySelectorAll(
            ".evaluation-filter-list .filter-option"
        )
        .forEach(
            (button) => {

                button.classList.toggle(
                    "active",
                    state.activeFilter.type ===
                        "evaluation" &&
                    String(
                        state.activeFilter.id
                    ) ===
                    String(
                        button.dataset.id
                    )
                );
            }
        );
}


/* =========================================================
   TABLE
========================================================= */

function renderGradeTable() {

    const card =
        $("gradesCard");


    const initial =
        $("initialEmpty");


    const toolbar =
        $("gradesToolbar");


    if (
        !state.selectedWeekId ||
        !state.selectedSubjectId ||
        !state.selectedClassId
    ) {

        card?.classList.add(
            "hidden"
        );


        toolbar?.classList.add(
            "hidden"
        );


        initial?.classList.remove(
            "hidden"
        );


        return;
    }


    const classItem =
        getSelectedClass();


    const students =
        getStudentsFromClass(
            classItem
        );


    /*
       التقييمات الظاهرة فقط.
       المجموع لاحقًا سيستخدم القائمة الكاملة
       بشكل مستقل عن الفلترة.
    */

    const visibleEvaluations =
        getVisibleEvaluations();


    /*
       جميع التقييمات للمجموع الكامل.
    */

    const allEvaluations =
        getCurrentEvaluationList();


    const attendanceMax =
        getAttendanceMax();


    card?.classList.remove(
        "hidden"
    );


    toolbar?.classList.remove(
        "hidden"
    );


    initial?.classList.add(
        "hidden"
    );


    renderEvaluationFilters();

    renderActiveFilterLabel();


    const head =
        $("gradesTableHead");


    const body =
        $("gradesTableBody");


    const empty =
        $("gradesEmpty");


    if (!head || !body) {
        return;
    }


    let filteredStudents =
        students.map(
            (student, index) => ({
                student,
                originalIndex: index
            })
        );


    const query =
        normalizeText(
            state.search
        ).toLowerCase();


    if (query) {

        filteredStudents =
            filteredStudents.filter(
                (item) =>
                    getStudentName(
                        item.student
                    )
                        .toLowerCase()
                        .includes(query)
            );
    }


    /* =====================================================
       HEADER

       الترتيب:
       م
       اسم الطالب
       أيام الغياب
       الحضور
       التقييمات
       المجموع
    ===================================================== */

    let headerHtml = `
        <tr>

            <th>م</th>

            <th>اسم الطالب</th>

            <th class="absence-column">
                أيام الغياب
            </th>

            <th class="attendance-column">

                <div class="attendance-head">

                    <div class="attendance-head-title">
                        الحضور
                    </div>

                    <div class="attendance-head-max-wrap">

                        <input
                            class="attendance-max-input"
                            type="number"
                            min="0.5"
                            step="0.5"
                            inputmode="decimal"
                            value="${escapeHtml(
                                attendanceMax
                            )}"
                            aria-label="الدرجة النهائية للحضور"
                            title="الدرجة النهائية للحضور"
                        >

                    </div>

                </div>

            </th>
    `;


    /*
       التقييمات الظاهرة فقط.
    */

    if (
        state.activeFilter.type !==
        "total"
    ) {

        visibleEvaluations.forEach(
            (evaluation, index) => {

                const evaluationId =
                    getEvaluationId(
                        evaluation,
                        index
                    );


                const evaluationName =
                    getEvaluationName(
                        evaluation
                    );


                const max =
                    getEvaluationMax(
                        evaluation
                    );


                headerHtml += `
                    <th>

                        <div class="evaluation-head">

                            <div class="evaluation-head-name">
                                ${escapeHtml(evaluationName)}
                            </div>

                            <div class="evaluation-head-max">
                                من ${escapeHtml(formatNumber(max))}
                            </div>

                            <div class="evaluation-head-actions">

                                <button
                                    type="button"
                                    class="evaluation-action"
                                    data-action="edit-evaluation"
                                    data-id="${escapeHtml(evaluationId)}"
                                    title="تعديل"
                                >
                                    ✎
                                </button>

                                <button
                                    type="button"
                                    class="evaluation-action"
                                    data-action="delete-evaluation"
                                    data-id="${escapeHtml(evaluationId)}"
                                    title="حذف"
                                >
                                    ×
                                </button>

                            </div>

                        </div>

                    </th>
                `;
            }
        );
    }


    headerHtml += `
            <th>المجموع</th>

        </tr>
    `;


    head.innerHTML =
        headerHtml;


    if (
        filteredStudents.length === 0
    ) {

        body.innerHTML =
            "";


        empty?.classList.remove(
            "hidden"
        );


        return;

    } else {

        empty?.classList.add(
            "hidden"
        );
    }


    let bodyHtml =
        "";


    filteredStudents.forEach(
        (item, visibleIndex) => {

            const student =
                item.student;


            const studentId =
                getStudentId(
                    student,
                    item.originalIndex
                );


            /*
               ==============================================
               حساب المجموع الكامل

               مهم:
               لا يعتمد على الفلتر.

               دائمًا:
               الحضور + جميع التقييمات.
               ==============================================
            */

            let total =
                0;


            let maxTotal =
                attendanceMax;


            /*
               الحضور
            */

            const attendanceGrade =
                getAttendanceGrade(
                    student,
                    studentId
                );


            const attendanceNumeric =
                Number(
                    attendanceGrade
                );


            if (
                attendanceGrade !== "" &&
                Number.isFinite(
                    attendanceNumeric
                )
            ) {

                total +=
                    attendanceNumeric;
            }


            /*
               جميع التقييمات تدخل في المجموع
               مهما كان الفلتر المختار.
            */

            allEvaluations.forEach(
                (evaluation, evaluationIndex) => {

                    const evaluationId =
                        getEvaluationId(
                            evaluation,
                            evaluationIndex
                        );


                    const max =
                        getEvaluationMax(
                            evaluation
                        );


                    const value =
                        getGrade(
                            studentId,
                            evaluationId
                        );


                    if (
                        value !== "" &&
                        value !== null &&
                        value !== undefined
                    ) {

                        const numeric =
                            Number(value);


                        if (
                            Number.isFinite(
                                numeric
                            )
                        ) {

                            total +=
                                numeric;
                        }
                    }


                    maxTotal +=
                        max;
                }
            );


            /*
               عدد أيام الغياب مستقل عن درجة الحضور.
            */

            const absenceCount =
                getStudentAbsenceCount(
                    student,
                    studentId
                );


            bodyHtml += `
                <tr>

                    <!-- الترقيم -->

                    <td class="student-number-cell">

                        <span class="student-number">
                            ${visibleIndex + 1}
                        </span>

                    </td>


                    <!-- اسم الطالب -->

                    <td class="student-name-cell">
                        ${escapeHtml(
                            getStudentName(student)
                        )}
                    </td>


                    <!-- أيام الغياب -->

                    <td class="absence-cell">

                        <span class="student-absence-count">
                            ${absenceCount}
                        </span>

                    </td>


                    <!-- درجة الحضور -->

                    <td class="attendance-cell">

                        <input
                            class="grade-input attendance-input"
                            type="number"
                            min="0"
                            max="${escapeHtml(attendanceMax)}"
                            step="0.01"
                            inputmode="decimal"
                            value="${
                                attendanceGrade === "" ||
                                attendanceGrade === null ||
                                attendanceGrade === undefined
                                    ? ""
                                    : escapeHtml(attendanceGrade)
                            }"
                            data-student-id="${escapeHtml(studentId)}"
                            data-attendance="true"
                            aria-label="درجة حضور ${escapeHtml(
                                getStudentName(student)
                            )}"
                        >

                    </td>
            `;


            /*
               التقييمات الظاهرة فقط.
               لا تؤثر على المجموع.
            */

            if (
                state.activeFilter.type !==
                "total"
            ) {

                visibleEvaluations.forEach(
                    (evaluation, evaluationIndex) => {

                        const evaluationId =
                            getEvaluationId(
                                evaluation,
                                evaluationIndex
                            );


                        const value =
                            getGrade(
                                studentId,
                                evaluationId
                            );


                        bodyHtml += `
                            <td>

                                <input
                                    class="grade-input"
                                    type="number"
                                    min="0"
                                    max="${escapeHtml(
                                        getEvaluationMax(evaluation)
                                    )}"
                                    step="0.5"
                                    inputmode="decimal"
                                    value="${
                                        value === "" ||
                                        value === null ||
                                        value === undefined
                                            ? ""
                                            : escapeHtml(value)
                                    }"
                                    data-student-id="${escapeHtml(studentId)}"
                                    data-evaluation-id="${escapeHtml(evaluationId)}"
                                    aria-label="${escapeHtml(
                                        getEvaluationName(evaluation)
                                    )}"
                                >

                            </td>
                        `;
                    }
                );
            }


            /*
               المجموع الكامل دائمًا.
            */

            bodyHtml += `
                    <td class="total-cell">

                        <span class="total-value">
                            ${formatNumber(total)}
                            /
                            ${formatNumber(maxTotal)}
                        </span>

                    </td>

                </tr>
            `;
        }
    );


    body.innerHTML =
        bodyHtml;


    const count =
        $("studentCount");


    if (count) {

        count.textContent =
            `${filteredStudents.length} طالب`;
    }


    const context =
        $("gradesContextText");


    if (context) {

        const week =
            getSelectedWeek();


        const subject =
            getSelectedSubject();


        const dates =
            getWeekDates(week);


        context.textContent =
            `${getWeekName(week)} • ${getSubjectName(subject)} • ${dates.text}`;
    }
}


/* =========================================================
   UPDATE TOTAL AFTER GRADE
========================================================= */

function updateStudentTotal(
    input
) {

    const row =
        input.closest("tr");


    if (!row) {
        return;
    }


    const studentId =
        input.dataset.studentId;


    /*
       مهم:
       المجموع يعتمد على جميع التقييمات،
       وليس التقييمات الظاهرة بعد الفلترة.
    */

    const evaluations =
        getCurrentEvaluationList();


    const attendanceMax =
        getAttendanceMax();


    let total =
        0;


    let maxTotal =
        attendanceMax;


    /*
       الحضور
    */

    const attendanceGrade =
        getManualAttendanceGrade(
            studentId
        );


    if (
        attendanceGrade !== "" &&
        attendanceGrade !== null &&
        attendanceGrade !== undefined
    ) {

        const attendanceNumber =
            Number(
                attendanceGrade
            );


        if (
            Number.isFinite(
                attendanceNumber
            )
        ) {

            total +=
                attendanceNumber;
        }

    } else {

        const classItem =
            getSelectedClass();


        const students =
            getStudentsFromClass(
                classItem
            );


        const student =
            students.find(
                (item, index) =>
                    getStudentId(
                        item,
                        index
                    ) ===
                    String(studentId)
            );


        if (student) {

            const calculated =
                calculateAttendanceGrade(
                    student,
                    studentId
                );


            const calculatedNumber =
                Number(
                    calculated
                );


            if (
                Number.isFinite(
                    calculatedNumber
                )
            ) {

                total +=
                    calculatedNumber;
            }
        }
    }


    /*
       جميع التقييمات، وليس التقييم المفلتر فقط.
    */

    evaluations.forEach(
        (evaluation, index) => {

            const evaluationId =
                getEvaluationId(
                    evaluation,
                    index
                );


            const max =
                getEvaluationMax(
                    evaluation
                );


            maxTotal +=
                max;


            const value =
                getGrade(
                    studentId,
                    evaluationId
                );


            const number =
                Number(value);


            if (
                value !== "" &&
                Number.isFinite(number)
            ) {

                total +=
                    number;
            }
        }
    );


    const totalElement =
        row.querySelector(
            ".total-value"
        );


    if (totalElement) {

        totalElement.textContent =
            `${formatNumber(total)} / ${formatNumber(maxTotal)}`;
    }
}


/* =========================================================
   EVALUATION MODAL
========================================================= */

function openEvaluationModal(
    evaluation = null
) {

    const modal =
        $("evaluationModal");


    const title =
        $("evaluationModalTitle");


    const nameInput =
        $("evaluationNameInput");


    const maxInput =
        $("evaluationMaxInput");


    if (!modal) {
        return;
    }


    if (evaluation) {

        state.editingEvaluationId =
            getEvaluationId(
                evaluation
            );


        if (title) {

            title.textContent =
                "تعديل التقييم";
        }


        if (nameInput) {

            nameInput.value =
                getEvaluationName(
                    evaluation
                );
        }


        if (maxInput) {

            maxInput.value =
                getEvaluationMax(
                    evaluation
                );
        }

    } else {

        state.editingEvaluationId =
            null;


        if (title) {

            title.textContent =
                "إضافة تقييم";
        }


        if (nameInput) {

            nameInput.value =
                "";
        }


        if (maxInput) {

            maxInput.value =
                "";
        }
    }


    modal.classList.remove(
        "hidden"
    );


    setTimeout(
        () =>
            nameInput?.focus(),
        80
    );
}


function closeEvaluationModal() {

    $("evaluationModal")
        ?.classList.add(
            "hidden"
        );


    state.editingEvaluationId =
        null;
}


function saveEvaluationFromModal() {

    const nameInput =
        $("evaluationNameInput");


    const maxInput =
        $("evaluationMaxInput");


    const name =
        normalizeText(
            nameInput?.value
        );


    const max =
        Number(
            maxInput?.value
        );


    if (!name) {

        showMessage(
            "اكتب اسم التقييم أولًا."
        );


        nameInput?.focus();


        return;
    }


    if (
        !Number.isFinite(max) ||
        max <= 0
    ) {

        showMessage(
            "أدخل الدرجة النهائية للتقييم بشكل صحيح."
        );


        maxInput?.focus();


        return;
    }


    if (
        state.editingEvaluationId
    ) {

        const evaluation =
            state.evaluations.find(
                (item, index) =>
                    getEvaluationId(
                        item,
                        index
                    ) ===
                    String(
                        state.editingEvaluationId
                    )
            );


        if (evaluation) {

            evaluation.name =
                name;


            evaluation.max =
                max;
        }

    } else {

        const current =
            getCurrentEvaluationList();


        const evaluation = {

            id:
                `evaluation-${Date.now()}-${Math.random()
                    .toString(36)
                    .slice(2, 8)}`,

            weekId:
                state.selectedWeekId,

            subjectId:
                state.selectedSubjectId,

            classId:
                state.selectedClassId,

            name,

            max,

            order:
                current.length

        };


        state.evaluations.push(
            evaluation
        );
    }


    saveJSON(
        STORAGE.evaluations,
        state.evaluations
    );

    syncUnifiedGradeStorage();

    closeEvaluationModal();


    renderGradeTable();
}


/* =========================================================
   DELETE EVALUATION
========================================================= */

function deleteEvaluation(
    evaluationId
) {

    const evaluation =
        getCurrentEvaluationList()
            .find(
                (item, index) =>
                    getEvaluationId(
                        item,
                        index
                    ) ===
                    String(evaluationId)
            );


    if (!evaluation) {
        return;
    }


    const confirmed =
        confirm(
            `هل تريد حذف التقييم "${getEvaluationName(evaluation)}"؟\n\nسيتم حذف التقييم من السجل، ولن يتم حذف بيانات الطلاب الآخرين.`
        );


    if (!confirmed) {
        return;
    }


    state.evaluations =
        state.evaluations.filter(
            (item, index) =>
                getEvaluationId(
                    item,
                    index
                ) !==
                String(evaluationId)
        );


    saveJSON(
        STORAGE.evaluations,
        state.evaluations
    );


    const suffix =
        `::${String(evaluationId)}`;


    Object.keys(
        state.records
    ).forEach(
        (key) => {

            if (
                key.endsWith(
                    suffix
                )
            ) {

                delete state.records[key];
            }
        }
    );


    saveJSON(
        STORAGE.records,
        state.records
    );


    if (
        state.activeFilter.type ===
            "evaluation" &&
        String(
            state.activeFilter.id
        ) ===
        String(evaluationId)
    ) {

        state.activeFilter = {
            type: "all",
            id: ""
        };
    }


    renderGradeTable();
}


/* =========================================================
   BUILD EXPORT DATA
========================================================= */

function getExportData() {

    const week =
        getSelectedWeek();


    const subject =
        getSelectedSubject();


    const classItem =
        getSelectedClass();


    if (
        !week ||
        !subject ||
        !classItem
    ) {

        return null;
    }


    /*
       التصدير يستخدم جميع التقييمات،
       وليس التقييمات الظاهرة بعد الفلترة.
    */

    const evaluations =
        getCurrentEvaluationList();


    const students =
        getStudentsFromClass(
            classItem
        );


    const attendanceMax =
        getAttendanceMax();


    const rows =
        students.map(
            (student, index) => {

                const studentId =
                    getStudentId(
                        student,
                        index
                    );


                const grades =
                    [];


                let total =
                    0;


                let maxTotal =
                    attendanceMax;


                const attendanceGrade =
                    getAttendanceGrade(
                        student,
                        studentId
                    );


                grades.push(
                    attendanceGrade
                );


                if (
                    attendanceGrade !== "" &&
                    attendanceGrade !== null &&
                    attendanceGrade !== undefined
                ) {

                    const attendanceNumeric =
                        Number(
                            attendanceGrade
                        );


                    if (
                        Number.isFinite(
                            attendanceNumeric
                        )
                    ) {

                        total +=
                            attendanceNumeric;
                    }
                }


                evaluations.forEach(
                    (evaluation, evaluationIndex) => {

                        const evaluationId =
                            getEvaluationId(
                                evaluation,
                                evaluationIndex
                            );


                        const max =
                            getEvaluationMax(
                                evaluation
                            );


                        const grade =
                            getGrade(
                                studentId,
                                evaluationId
                            );


                        grades.push(
                            grade
                        );


                        maxTotal +=
                            max;


                        if (
                            grade !== "" &&
                            grade !== null &&
                            grade !== undefined
                        ) {

                            const numeric =
                                Number(grade);


                            if (
                                Number.isFinite(
                                    numeric
                                )
                            ) {

                                total +=
                                    numeric;
                            }
                        }
                    }
                );


                return {

                    number:
                        index + 1,

                    studentId:
                        studentId,

                    name:
                        getStudentName(
                            student
                        ),

                    grades,

                    attendanceGrade,

                    absenceCount:
                        getStudentAbsenceCount(
                            student,
                            studentId
                        ),

                    attendanceMax,

                    total,

                    maxTotal

                };
            }
        );


    return {

        week,

        subject,

        classItem,

        dates:
            getWeekDates(week),

        evaluations,

        attendance: {

            name:
                "الحضور",

            max:
                attendanceMax,

            recordedDays:
                getTotalAttendanceDays()

        },

        students,

        rows

    };
}


/* =========================================================
   OPEN EXPORT PAGE
========================================================= */

function openExportPage() {

    if (
        !state.selectedWeekId ||
        !state.selectedSubjectId ||
        !state.selectedClassId
    ) {

        showMessage(
            "اختر الأسبوع والمادة والصف أولًا."
        );

        return;
    }


    const data =
        getExportData();


    if (!data) {

        showMessage(
            "تعذر تجهيز بيانات سجل الدرجات."
        );

        return;
    }


    if (
        !Array.isArray(data.students) ||
        data.students.length === 0
    ) {

        showMessage(
            "لا يوجد طلاب في الصف المحدد للتصدير."
        );

        return;
    }


    const exportContext = {

        version:
            2,

        createdAt:
            Date.now(),

        weekId:
            String(
                state.selectedWeekId
            ),

        subjectId:
            String(
                state.selectedSubjectId
            ),

        classId:
            String(
                state.selectedClassId
            ),

        weekName:
            getWeekName(
                data.week
            ) || "—",

        subjectName:
            getSubjectName(
                data.subject
            ) || "—",

        className:
            getClassName(
                data.classItem
            ) || "—",

        weekDates:
            data.dates?.text ||
            "—",

        attendance:
            data.attendance || {
                name: "الحضور",
                max: 10,
                recordedDays: 0
            },

        evaluations:
            data.evaluations || [],

        rows:
            data.rows || []

    };


    const saved =
        saveJSON(
            STORAGE.exportContext,
            exportContext
        );


    if (!saved) {

        showMessage(
            "تعذر تجهيز سجل التصدير. حاول مرة أخرى."
        );

        return;
    }


    window.location.href =
        "export.html";
}


/* =========================================================
   NAVIGATION
========================================================= */

function goMain(page) {

    const currentPage =
        window.location.pathname
            .split("/")
            .pop()
            .toLowerCase();


    if (
        currentPage === "home.html" ||
        currentPage === ""
    ) {

        window.location.href =
            page;

        return;
    }


    window.location.replace(
        page
    );
}


function setupNavigation() {

    $("homeButton")
        ?.addEventListener(
            "click",
            () => {

                goMain(
                    "home.html"
                );
            }
        );


    $("homeNavigation")
        ?.addEventListener(
            "click",
            () => {

                goMain(
                    "home.html"
                );
            }
        );


    $("attendanceNavigation")
        ?.addEventListener(
            "click",
            () => {

                goMain(
                    "attendance.html"
                );
            }
        );


    $("studentsNavigation")
        ?.addEventListener(
            "click",
            () => {

                goMain(
                    "students.html"
                );
            }
        );


    $("scheduleNavigation")
        ?.addEventListener(
            "click",
            () => {

                goMain(
                    "schedule.html"
                );
            }
        );


    $("gradesNavigation")
        ?.addEventListener(
            "click",
            () => {

                goMain(
                    "grades.html"
                );
            }
        );


    $("reportsNavigation")
        ?.addEventListener(
            "click",
            () => {

                goMain(
                    "reports.html"
                );
            }
        );
}


/* =========================================================
   EVENTS
========================================================= */

function setupEvents() {

    /*
       Selection
    */

    $("weekSelect")
        ?.addEventListener(
            "change",
            (event) => {

                state.selectedWeekId =
                    event.target.value;


                state.activeFilter = {
                    type: "all",
                    id: ""
                };


                renderSelectionInfo();

                renderGradeTable();
            }
        );


    $("gradeSubjectSelect")
        ?.addEventListener(
            "change",
            (event) => {

                state.selectedSubjectId =
                    event.target.value;


                state.activeFilter = {
                    type: "all",
                    id: ""
                };


                renderGradeTable();
            }
        );


    $("gradeClassSelect")
        ?.addEventListener(
            "change",
            (event) => {

                state.selectedClassId =
                    event.target.value;


                state.activeFilter = {
                    type: "all",
                    id: ""
                };


                renderSelectionInfo();

                renderGradeTable();
            }
        );


    /*
       Add evaluation
    */

    $("addEvaluationButton")
        ?.addEventListener(
            "click",
            () => {

                if (
                    !state.selectedWeekId ||
                    !state.selectedSubjectId ||
                    !state.selectedClassId
                ) {

                    showMessage(
                        "اختر الأسبوع والمادة والصف أولًا."
                    );

                    return;
                }


                openEvaluationModal();
            }
        );


    /*
       Evaluation modal
    */

    $("closeEvaluationModal")
        ?.addEventListener(
            "click",
            closeEvaluationModal
        );


    $("cancelEvaluationButton")
        ?.addEventListener(
            "click",
            closeEvaluationModal
        );


    $("saveEvaluationButton")
        ?.addEventListener(
            "click",
            saveEvaluationFromModal
        );


    $("evaluationModal")
        ?.addEventListener(
            "click",
            (event) => {

                if (
                    event.target ===
                    $("evaluationModal")
                ) {

                    closeEvaluationModal();
                }
            }
        );


    /*
       Grade input
       الحفظ الآن يتم فور الكتابة أيضًا، دون انتظار مغادرة الخانة.
    */

    $("gradesTableBody")
        ?.addEventListener(
            "input",
            (event) => {

                const input =
                    event.target.closest(".grade-input");

                if (!input || input.dataset.attendance === "true") {
                    return;
                }

                const studentId = input.dataset.studentId;
                const evaluationId = input.dataset.evaluationId;
                const value = input.value.trim();

                if (value === "") {
                    saveGrade(studentId, evaluationId, "");
                    updateStudentTotal(input);
                    return;
                }

                const number = Number(value);
                const evaluation =
                    getCurrentEvaluationList().find(
                        (item, index) =>
                            getEvaluationId(item, index) === String(evaluationId)
                    );
                const max = getEvaluationMax(evaluation);

                if (
                    !Number.isFinite(number) ||
                    number < 0 ||
                    number > max
                ) {
                    return;
                }

                saveGrade(studentId, evaluationId, number);
                updateStudentTotal(input);
            }
        );

    $("gradesTableBody")
        ?.addEventListener(
            "input",
            (event) => {

                const input =
                    event.target.closest(".attendance-input");

                if (!input) {
                    return;
                }

                const studentId = input.dataset.studentId;
                const value = input.value.trim();
                const max = getAttendanceMax();

                if (value === "") {
                    saveAttendanceGrade(studentId, "");
                    updateStudentTotal(input);
                    return;
                }

                const number = Number(value);

                if (
                    !Number.isFinite(number) ||
                    number < 0 ||
                    number > max
                ) {
                    return;
                }

                saveAttendanceGrade(studentId, number);
                updateStudentTotal(input);
            }
        );

    $("gradesTableBody")
        ?.addEventListener(
            "change",
            (event) => {

                /*
                   ==========================================
                   الحضور
                   ==========================================
                */

                const attendanceInput =
                    event.target.closest(
                        ".attendance-input"
                    );


                if (attendanceInput) {

                    const studentId =
                        attendanceInput.dataset.studentId;


                    const value =
                        attendanceInput.value.trim();


                    const max =
                        getAttendanceMax();


                    if (
                        value === ""
                    ) {

                        /*
                           حذف التعديل اليدوي
                           والعودة للحساب التلقائي.
                        */

                        saveAttendanceGrade(
                            studentId,
                            ""
                        );


                        renderGradeTable();

                        return;
                    }


                    const number =
                        Number(value);


                    if (
                        !Number.isFinite(number) ||
                        number < 0 ||
                        number > max
                    ) {

                        attendanceInput.classList.add(
                            "invalid"
                        );


                        showMessage(
                            `درجة الحضور يجب أن تكون بين 0 و ${formatNumber(max)}.`
                        );


                        setTimeout(
                            () =>
                                attendanceInput.classList.remove(
                                    "invalid"
                                ),
                            800
                        );


                        return;
                    }


                    attendanceInput.classList.remove(
                        "invalid"
                    );


                    saveAttendanceGrade(
                        studentId,
                        number
                    );


                    updateStudentTotal(
                        attendanceInput
                    );


                    return;
                }


                /*
                   ==========================================
                   التقييمات العادية
                   ==========================================
                */

                const input =
                    event.target.closest(
                        ".grade-input"
                    );


                if (!input) {
                    return;
                }


                if (
                    input.dataset.attendance ===
                    "true"
                ) {

                    return;
                }


                const studentId =
                    input.dataset.studentId;


                const evaluationId =
                    input.dataset.evaluationId;


                const value =
                    input.value.trim();


                if (
                    value === ""
                ) {

                    saveGrade(
                        studentId,
                        evaluationId,
                        ""
                    );


                    updateStudentTotal(
                        input
                    );


                    return;
                }


                const number =
                    Number(value);


                const evaluation =
                    getCurrentEvaluationList()
                        .find(
                            (item, index) =>
                                getEvaluationId(
                                    item,
                                    index
                                ) ===
                                String(
                                    evaluationId
                                )
                        );


                const max =
                    getEvaluationMax(
                        evaluation
                    );


                if (
                    !Number.isFinite(number) ||
                    number < 0 ||
                    number > max
                ) {

                    input.classList.add(
                        "invalid"
                    );


                    showMessage(
                        `الدرجة يجب أن تكون بين 0 و ${formatNumber(max)}.`
                    );


                    setTimeout(
                        () =>
                            input.classList.remove(
                                "invalid"
                            ),
                        800
                    );


                    return;
                }


                input.classList.remove(
                    "invalid"
                );


                saveGrade(
                    studentId,
                    evaluationId,
                    number
                );


                updateStudentTotal(
                    input
                );
            }
        );


    /*
       تغيير الدرجة النهائية للحضور
    */

    $("gradesTableHead")
        ?.addEventListener(
            "change",
            (event) => {

                const input =
                    event.target.closest(
                        ".attendance-max-input"
                    );


                if (!input) {
                    return;
                }


                const value =
                    input.value.trim();


                const number =
                    Number(value);


                if (
                    !Number.isFinite(number) ||
                    number <= 0
                ) {

                    showMessage(
                        "أدخل الدرجة النهائية للحضور بشكل صحيح."
                    );


                    input.value =
                        getAttendanceMax();


                    return;
                }


                saveAttendanceMax(
                    number
                );


                /*
                   إعادة بناء الجدول:
                   - تحديث الدرجة النهائية
                   - إعادة حساب الحضور التلقائي
                   - تحديث المجموع
                */

                renderGradeTable();
            }
        );


    /*
       Evaluation edit/delete
    */

    $("gradesTableHead")
        ?.addEventListener(
            "click",
            (event) => {

                const button =
                    event.target.closest(
                        ".evaluation-action"
                    );


                if (!button) {
                    return;
                }


                const action =
                    button.dataset.action;


                const id =
                    button.dataset.id;


                const evaluation =
                    getCurrentEvaluationList()
                        .find(
                            (item, index) =>
                                getEvaluationId(
                                    item,
                                    index
                                ) ===
                                String(id)
                        );


                if (!evaluation) {
                    return;
                }


                if (
                    action ===
                    "edit-evaluation"
                ) {

                    openEvaluationModal(
                        evaluation
                    );

                } else if (
                    action ===
                    "delete-evaluation"
                ) {

                    deleteEvaluation(
                        id
                    );
                }
            }
        );


    /*
       Search
    */

    $("studentSearch")
        ?.addEventListener(
            "input",
            (event) => {

                state.search =
                    event.target.value;


                const clear =
                    $("clearSearchButton");


                clear?.classList.toggle(
                    "hidden",
                    !state.search
                );


                renderGradeTable();
            }
        );


    $("clearSearchButton")
        ?.addEventListener(
            "click",
            () => {

                const search =
                    $("studentSearch");


                if (search) {

                    search.value =
                        "";
                }


                state.search =
                    "";


                $("clearSearchButton")
                    ?.classList.add(
                        "hidden"
                    );


                renderGradeTable();
            }
        );


    /*
       Filter open/close
    */

    $("filterButton")
        ?.addEventListener(
            "click",
            () => {

                $("filterPanel")
                    ?.classList.toggle(
                        "hidden"
                    );
            }
        );


    $("closeFilterButton")
        ?.addEventListener(
            "click",
            () => {

                $("filterPanel")
                    ?.classList.add(
                        "hidden"
                    );
            }
        );


    $("filterAllButton")
        ?.addEventListener(
            "click",
            () => {

                state.activeFilter = {
                    type: "all",
                    id: ""
                };


                updateFilterButtons();

                renderGradeTable();
            }
        );


    $("filterTotalButton")
        ?.addEventListener(
            "click",
            () => {

                state.activeFilter = {
                    type: "total",
                    id: ""
                };


                updateFilterButtons();

                renderGradeTable();
            }
        );


    $("evaluationFilterList")
        ?.addEventListener(
            "click",
            (event) => {

                const button =
                    event.target.closest(
                        ".filter-option"
                    );


                if (!button) {
                    return;
                }


                state.activeFilter = {

                    type:
                        "evaluation",

                    id:
                        button.dataset.id

                };


                updateFilterButtons();

                renderGradeTable();
            }
        );


    /*
       فتح صفحة التصدير المستقلة
    */

    $("gradeRegisterButton")
        ?.addEventListener(
            "click",
            openExportPage
        );


    /*
       Escape
    */

    document.addEventListener(
        "keydown",
        (event) => {

            if (
                event.key !==
                "Escape"
            ) {
                return;
            }


            closeEvaluationModal();


            $("filterPanel")
                ?.classList.add(
                    "hidden"
                );
        }
    );
}


/* =========================================================
   INITIALIZE
========================================================= */

function refreshPage() {

    loadData();


    populateWeeks();


    populateSubjects();


    populateClasses();


    renderSelectionInfo();


    renderGradeTable();
}


/* =========================================================
   DOM READY
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        setupNavigation();

        setupEvents();

        refreshPage();
    }
);


/* =========================================================
   PAGE SHOW
========================================================= */

window.addEventListener(
    "pageshow",
    () => {

        if (
            document.readyState ===
            "complete"
        ) {

            refreshPage();
        }
    }
);