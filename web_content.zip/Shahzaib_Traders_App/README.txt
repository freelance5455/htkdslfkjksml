SHAHZAIB TRADERS — STOCK & SALES APP
=====================================

Files:
- index.html: complete offline-first app
- logo.svg: Shahzaib Traders logo
- capacitor.config.json and package.json: starter configuration for Android packaging

FEATURES
- Add/edit/delete stock items, item code, unit, quantity, purchase price, sale price, low-stock alert
- Automatic stock quantity reduction when a sale is saved
- Multi-item bills, auto totals, discount, received amount, due/change
- Invoice preview and Print / Save PDF
- Sales history, CSV export, stock valuation and estimated gross profit
- JSON backup and restore for moving records manually to another phone
- Contact shortcuts for WhatsApp and email

IMPORTANT DATA / ONLINE SYNC
This version stores records locally in the browser/app on this device. It does NOT automatically sync with a second phone. For multi-device sync, configure a secure cloud backend (e.g. Firebase Authentication + Firestore), access rules, and sync code before using it as a shared business database. Do not rely on this offline version as the only copy of important business records; export backups regularly.

OPEN / TEST
Open index.html in a modern browser. Add a few sample products and make a test sale.

ANDROID APK
This ZIP is a web-app source project, not a compiled APK. A native APK must be built with Android tooling. Capacitor's official docs: https://capacitorjs.com/docs/getting-started
Typical setup on a computer with Node.js and Android Studio:
  npm install
  npm install @capacitor/core @capacitor/android
  npm install --save-dev @capacitor/cli
  npx cap add android
  npx cap sync android
  npx cap open android
Then use Android Studio to build an APK. This project uses the root folder as webDir; review capacitor config if your chosen builder requires a www/dist folder.
