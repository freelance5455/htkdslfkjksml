# 킹 레거시 모바일 피싱 도우미

첨부된 화면 흐름을 바탕으로 만든 Android WebView 프로젝트입니다. 메인 UI는 `index.html`이며 Android 권한/화면 공유 기능은 Java 네이티브 브리지로 연결됩니다.

## 현재 구현된 기능

1. **오버레이 권한** — Android의 `ACTION_MANAGE_OVERLAY_PERMISSION` 설정 화면을 엽니다.
2. **접근성 설정** — Android 접근성 설정 화면을 엽니다. 앱이 설정 목록에 표시되도록 최소 접근성 서비스를 선언했습니다.
3. **화면 공유** — Android `MediaProjection` 시스템 동의 창을 띄웁니다. 동의하면 포그라운드 서비스가 화면 프레임을 수신하고 게임 위에 작은 상태 패널을 표시합니다.
4. **캡처 종료** — 앱 화면 또는 플로팅 패널에서 캡처를 종료할 수 있습니다.
5. **낚시 가이드/어종 도감** — Basic Rod 제작 재료, 낚시 순서, 어종 분류, Update 10 낚시 확률 및 Serpent 회오리 정보를 포함합니다.

## 중요: 자동 낚시 기능에 관해

이 ZIP의 현재 버전은 **권한 설정 + 화면 캡처 + 낚시 정보 안내까지** 구현되어 있습니다. 게임 화면의 낚시 게이지를 자동 판독하거나 Roblox에 자동 터치/클릭을 보내는 기능은 포함하지 않습니다.

접근성 서비스는 Android 설정 목록에 앱을 노출하기 위한 설정용 서비스이며, 코드상 다음 기능을 수행하지 않습니다.

- 다른 앱의 화면 텍스트/노드 트리 읽기
- 화면 내용 저장 또는 서버 전송
- 터치 제스처 실행
- 자동 클릭 및 게임 조작

화면 캡처 프레임은 수신 여부만 확인한 다음 즉시 닫습니다. 이미지 파일로 저장하거나 외부 서버로 전송하지 않습니다. 화면 공유 세션은 사용자가 Android 시스템 창에서 명시적으로 허용해야 합니다.

## Android Studio에서 APK 만들기

### 준비물

- Android Studio
- JDK 17 이상 (Android Studio의 Gradle JDK 17 권장)
- 첫 동기화/빌드 시 Gradle 배포판 및 Android SDK를 내려받을 수 있는 인터넷 연결

### 빌드 순서

1. ZIP 압축을 풉니다.
2. Android Studio에서 압축 해제한 `KingLegacy_Fishing_Assistant` 폴더를 **Open**으로 엽니다.
3. Gradle 동기화가 끝나면 **Build → Build Bundle(s) / APK(s) → Build APK(s)** 를 선택합니다.
4. 디버그 APK는 `app/build/outputs/apk/debug/app-debug.apk`에 생성됩니다.
5. APK를 Galaxy Z Fold6에 설치합니다. 설치 과정에서 출처를 알 수 없는 앱 설치 확인이 표시될 수 있습니다.

또는 프로젝트 루트에서 아래 명령을 실행할 수 있습니다.

- Windows: `gradlew.bat assembleDebug`
- macOS/Linux: `./gradlew assembleDebug`

포함된 `gradlew` 스크립트는 표준 Gradle Wrapper JAR에 의존하지 않고 Gradle 8.13 배포판을 사용자 Gradle 캐시에 준비한 뒤 실행하는 간단한 부트스트랩 스크립트입니다.

## 기기에서 실행

1. 앱을 열고 **1. 오버레이 권한 허용**을 누릅니다.
2. Android 설정에서 `킹 레거시 피싱 도우미`의 **다른 앱 위에 표시 허용**을 켜고 앱으로 돌아옵니다.
3. **2. 접근성 설정 열기**는 요청한 화면 흐름을 위해 제공됩니다. 접근성 기능은 이 버전에서 필수가 아니며, 서비스를 켜더라도 앱은 화면을 읽거나 자동 입력하지 않습니다.
4. **3. 화면 캡처 시작**을 누릅니다.
5. Android 시스템의 화면 공유 창에서 Roblox 앱 화면 또는 전체 화면을 선택하고 **지금 시작**을 승인합니다.
6. 게임 위에 `피싱 화면 캡처` 상태 패널이 표시됩니다. 패널의 **캡처 종료**를 누르면 공유 세션이 종료됩니다.

오버레이가 거부되면 3번을 누르기 전에 1번 설정을 완료해야 합니다. Android 버전과 제조사 설정에 따라 권한 화면의 문구/배치는 달라질 수 있습니다.

## 기술 구성

- UI: `index.html`, CSS, Vanilla JavaScript
- Android 컨테이너: WebView / Java
- 오버레이: `WindowManager` + `TYPE_APPLICATION_OVERLAY`
- 화면 캡처: `MediaProjectionManager` + Foreground Service + `VirtualDisplay` + `ImageReader`
- 접근성: 기능 동작 없는 최소 설정용 `AccessibilityService`
- 최소 SDK: 26 / Target SDK: 35 / Compile SDK: 35
- Android Gradle Plugin: 8.13.2 / Gradle: 8.13

## 프로젝트 구조

```text
KingLegacy_Fishing_Assistant/
├── index.html
├── README.md
├── gradlew
├── gradlew.bat
├── settings.gradle
├── build.gradle
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/index.html
        ├── java/com/jungeon/kinglegacyfishing/
        │   ├── MainActivity.java
        │   ├── CaptureService.java
        │   └── SetupAccessibilityService.java
        └── res/
            ├── values/strings.xml
            ├── values/styles.xml
            └── xml/accessibility_service_config.xml
```

## 낚시 데이터 출처

앱에 반영된 게임 정보는 2026-11-21 기준으로 아래 자료를 확인해 정리했습니다. 게임 업데이트 이후에는 수치/위치가 변경될 수 있습니다.

- Pro Game Guides, [King Legacy Update 10 Full Patch Notes](https://progameguides.com/roblox/king-legacy-update-10-patch-notes/) — 2026-03-13 업데이트 확률표, 낚시 EXP 안내, Serpent 회오리 이벤트
- Pro Game Guides, [King Legacy Fishing Guide](https://progameguides.com/roblox/king-legacy-fishing-guide-rods-fishes-and-location/) — Basic Rod 제작 재료, 낚시 단계, 판매 및 Drop Boost 활용
- [KingLegacy.app Fishing Guide](https://kinglegacy.app/fishing/) — 어종별 희귀도 목록, NPC 및 낚시 요약
- [King Legacy Community Wiki: Fishing](https://king-legacy-official.fandom.com/wiki/Fishing) — 물고기 사용 관련 보조 참고

확률표에 공개되지 않은 Common/Uncommon 확률은 임의로 계산하거나 표시하지 않았습니다.

## 주의 사항

Roblox/게임 운영 정책은 바뀔 수 있습니다. 게임 내 자동화 기능을 추가하거나 사용할 때는 해당 게임의 이용 약관 및 운영 정책을 먼저 확인하세요. 본 프로젝트는 권한 설정과 화면 캡처 세션 예제이며, 게임 입력 자동화나 제재 회피 기능을 제공하지 않습니다.
