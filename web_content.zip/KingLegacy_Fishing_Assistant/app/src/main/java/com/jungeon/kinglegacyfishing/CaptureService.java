package com.jungeon.kinglegacyfishing;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class CaptureService extends Service {
    public static final String EXTRA_RESULT_CODE = "projection_result_code";
    public static final String EXTRA_RESULT_DATA = "projection_result_data";
    private static final String CHANNEL_ID = "king_legacy_capture";
    private static final int NOTIFICATION_ID = 7401;
    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);

    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private HandlerThread imageThread;
    private Handler imageHandler;
    private WindowManager windowManager;
    private LinearLayout overlay;
    private TextView overlayStatus;
    private final AtomicInteger frameCount = new AtomicInteger(0);
    private final Handler mainHandler = new Handler();
    private final AtomicBoolean stopped = new AtomicBoolean(false);

    public static boolean isRunning() {
        return RUNNING.get();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || stopped.get()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent resultData = getResultData(intent);
        if (resultCode == 0 || resultData == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, buildNotification(),
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                startForeground(NOTIFICATION_ID, buildNotification());
            }

            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(resultCode, resultData);
            if (projection == null) throw new IllegalStateException("MediaProjection unavailable");

            projection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    stopCaptureAndService();
                }
            }, mainHandler);

            DisplayMetrics metrics = getResources().getDisplayMetrics();
            int width = Math.max(1, metrics.widthPixels);
            int height = Math.max(1, metrics.heightPixels);
            int density = metrics.densityDpi;

            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
            imageThread = new HandlerThread("FishingScreenCapture");
            imageThread.start();
            imageHandler = new Handler(imageThread.getLooper());
            imageReader.setOnImageAvailableListener(reader -> {
                Image image = null;
                try {
                    image = reader.acquireLatestImage();
                    if (image != null) {
                        int count = frameCount.incrementAndGet();
                        if (count % 30 == 0) {
                            mainHandler.post(() -> updateOverlayStatus(count));
                        }
                    }
                } catch (IllegalStateException ignored) {
                } finally {
                    if (image != null) image.close();
                }
            }, imageHandler);

            virtualDisplay = projection.createVirtualDisplay(
                    "KingLegacyFishingCapture",
                    width,
                    height,
                    density,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.getSurface(),
                    null,
                    imageHandler
            );

            RUNNING.set(true);
            showOverlay();
            updateOverlayStatus(frameCount.get());
            return START_NOT_STICKY;
        } catch (SecurityException | IllegalStateException e) {
            stopCaptureAndService();
            return START_NOT_STICKY;
        }
    }

    private Intent getResultData(Intent intent) {
        if (Build.VERSION.SDK_INT >= 33) {
            return intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
        }
        //noinspection deprecation
        return intent.getParcelableExtra(EXTRA_RESULT_DATA);
    }

    private Notification buildNotification() {
        Intent openApp = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 1, openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return builder
                .setContentTitle("킹 레거시 화면 캡처 실행 중")
                .setContentText("화면은 기기 내부에서만 처리되며 저장하거나 전송하지 않습니다.")
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "게임 화면 캡처", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("사용자가 허용한 화면 공유 세션의 실행 상태를 표시합니다.");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void showOverlay() {
        if (Build.VERSION.SDK_INT < 23 || !android.provider.Settings.canDrawOverlays(this) || overlay != null) return;

        overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setPadding(dp(12), dp(9), dp(12), dp(9));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xEE171B25);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), 0xFF3B82F6);
        overlay.setBackground(bg);
        overlay.setElevation(dp(8));

        TextView title = new TextView(this);
        title.setText("🎣  피싱 화면 캡처");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(13);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        overlay.addView(title);

        overlayStatus = new TextView(this);
        overlayStatus.setText("캡처 연결 중…");
        overlayStatus.setTextColor(0xFFD6DCE8);
        overlayStatus.setTextSize(11);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.topMargin = dp(4);
        overlay.addView(overlayStatus, statusParams);

        Button stop = new Button(this);
        stop.setText("캡처 종료");
        stop.setTextSize(11);
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, dp(38));
        buttonParams.topMargin = dp(5);
        overlay.addView(stop, buttonParams);
        stop.setOnClickListener(v -> stopCaptureAndService());

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                dp(190),
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.END;
        params.x = dp(12);
        params.y = dp(100);

        try {
            windowManager.addView(overlay, params);
        } catch (Exception e) {
            overlay = null;
            overlayStatus = null;
        }
    }

    private void updateOverlayStatus(int count) {
        if (overlayStatus != null) {
            overlayStatus.setText("화면 캡처 중 · 수신 프레임 " + count + "개");
        }
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void stopCaptureAndService() {
        if (!stopped.compareAndSet(false, true)) return;
        RUNNING.set(false);
        try {
            if (overlay != null && windowManager != null) {
                windowManager.removeView(overlay);
            }
        } catch (Exception ignored) { }
        overlay = null;
        overlayStatus = null;
        try { if (virtualDisplay != null) virtualDisplay.release(); } catch (Exception ignored) { }
        virtualDisplay = null;
        try { if (imageReader != null) imageReader.close(); } catch (Exception ignored) { }
        imageReader = null;
        try { if (projection != null) projection.stop(); } catch (Exception ignored) { }
        projection = null;
        try {
            if (imageThread != null) imageThread.quitSafely();
        } catch (Exception ignored) { }
        imageThread = null;
        imageHandler = null;
        stopForeground(true);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        if (!stopped.get()) stopCaptureAndService();
        RUNNING.set(false);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
