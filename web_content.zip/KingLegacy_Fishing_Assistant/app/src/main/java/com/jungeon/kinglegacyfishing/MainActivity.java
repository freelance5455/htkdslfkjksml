package com.jungeon.kinglegacyfishing;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 4107;
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(false);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("http".equals(uri.getScheme()) || "https".equals(uri.getScheme())) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (ActivityNotFoundException ignored) {
                        Toast.makeText(MainActivity.this, "링크를 열 브라우저가 없습니다.", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
                return false;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onResume() {
        super.onResume();
        pushStatusToWeb();
    }

    private void pushStatusToWeb() {
        if (webView == null) return;
        webView.postDelayed(() -> {
            if (webView != null) {
                String json = buildStatusJson();
                webView.evaluateJavascript("window.applyNativeState && window.applyNativeState(" + json + ");", null);
            }
        }, 250);
    }

    private String buildStatusJson() {
        JSONObject obj = new JSONObject();
        try {
            obj.put("native", true);
            obj.put("overlay", Settings.canDrawOverlays(this));
            obj.put("accessibility", isOurAccessibilityEnabled());
            obj.put("capturing", CaptureService.isRunning());
        } catch (Exception ignored) { }
        return obj.toString();
    }

    private boolean isOurAccessibilityEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null || enabled.isEmpty()) return false;
        ComponentName component = new ComponentName(this, SetupAccessibilityService.class);
        String expectedShort = component.flattenToShortString();
        String expectedFlat = component.flattenToString();
        for (String item : enabled.split(":")) {
            if (item.equalsIgnoreCase(expectedShort) || item.equalsIgnoreCase(expectedFlat)) {
                return true;
            }
        }
        return false;
    }

    private void openOverlaySettings() {
        if (Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "오버레이 권한이 이미 허용되어 있습니다.", Toast.LENGTH_SHORT).show();
            pushStatusToWeb();
            return;
        }
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
        }
    }

    private void openAccessibilitySettings() {
        try {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "접근성 설정을 열 수 없습니다.", Toast.LENGTH_LONG).show();
        }
    }

    private void requestCapturePermission() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "먼저 1번에서 다른 앱 위에 표시 권한을 허용해 주세요.", Toast.LENGTH_LONG).show();
            openOverlaySettings();
            return;
        }
        if (CaptureService.isRunning()) {
            Toast.makeText(this, "화면 캡처가 이미 실행 중입니다.", Toast.LENGTH_SHORT).show();
            pushStatusToWeb();
            return;
        }
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (manager == null) {
            Toast.makeText(this, "이 기기에서 화면 공유 기능을 사용할 수 없습니다.", Toast.LENGTH_LONG).show();
            return;
        }
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent service = new Intent(this, CaptureService.class);
                service.putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode);
                service.putExtra(CaptureService.EXTRA_RESULT_DATA, data);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
                else startService(service);
                Toast.makeText(this, "화면 캡처가 시작되었습니다.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "화면 공유가 취소되었습니다.", Toast.LENGTH_SHORT).show();
            }
            pushStatusToWeb();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    private class AndroidBridge {
        @JavascriptInterface
        public String getStatusJson() {
            return buildStatusJson();
        }

        @JavascriptInterface
        public void openOverlaySettings() {
            runOnUiThread(() -> MainActivity.this.openOverlaySettings());
        }

        @JavascriptInterface
        public void openAccessibilitySettings() {
            runOnUiThread(() -> MainActivity.this.openAccessibilitySettings());
        }

        @JavascriptInterface
        public void startScreenCapture() {
            runOnUiThread(() -> requestCapturePermission());
        }

        @JavascriptInterface
        public void stopScreenCapture() {
            runOnUiThread(() -> {
                stopService(new Intent(MainActivity.this, CaptureService.class));
                Toast.makeText(MainActivity.this, "화면 캡처 종료 요청을 보냈습니다.", Toast.LENGTH_SHORT).show();
                pushStatusToWeb();
            });
        }
    }
}
