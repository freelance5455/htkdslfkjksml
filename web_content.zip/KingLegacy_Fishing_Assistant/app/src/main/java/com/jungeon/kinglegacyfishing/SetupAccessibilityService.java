package com.jungeon.kinglegacyfishing;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

/**
 * Setup-only service. It intentionally performs no screen reading, no node inspection,
 * no gesture dispatch and no automated input. The screen-capture feature does not depend on it.
 */
public class SetupAccessibilityService extends AccessibilityService {
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Intentionally empty.
    }

    @Override
    public void onInterrupt() {
        // Intentionally empty.
    }
}
