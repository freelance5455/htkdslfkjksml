@echo off
cd /d "%~dp0"
if not exist .venv (
  echo First run: setting things up, this takes a minute...
  python -m venv .venv
  call .venv\Scripts\activate
  pip install -r requirements.txt
) else (
  call .venv\Scripts\activate
)
python app.py
pause
