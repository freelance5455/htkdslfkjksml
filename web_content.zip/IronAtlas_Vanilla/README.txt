IRON ATLAS — Vanilla JavaScript Edition

This edition removes React and TypeScript from the runtime and uses:
- HTML
- CSS
- Plain JavaScript

Contents:
- index.html: application entry point
- app.js: application logic (bundled, no module imports)
- styles.css and vanilla.css: styling
- uploads/: supplied anatomy illustrations

Run:
Open index.html in a modern browser. The app logic and exercise data are local.
Google Fonts are loaded online; system fallbacks are included in CSS.

Android:
This folder can be placed in an Android WebView project's assets/www folder,
or wrapped with Capacitor. This ZIP is a source project, not a compiled APK.

Note:
The original uploaded source included a Three.js / React Three Fiber anatomy
component. This vanilla edition currently uses the supplied anatomy illustrations
and muscle selection list rather than the original interactive 3D renderer.
