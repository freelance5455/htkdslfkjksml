# Security Model

1. Login is a UI gate only in this browser-only prototype.
2. Owner Approval is a local OTP simulation.
3. WAF, XSS/CSRF and AES-256 references are represented as product controls; they are not cryptographic proof.
4. Never treat browser storage or client-side JavaScript as a trusted security boundary.
5. A real deployment must move identity, authorization, OTP, encryption keys and audit verification to a trusted server.
6. File uploads should be validated by MIME, magic bytes, size limits and malware scanning before production storage.
