# Notice de provenance et de droits — Louis Segond 1910

## Corpus intégré

L’application incorpore le texte français Louis Segond 1910 publié dans le paquet HTML de eBible.org : [page de l’édition](https://ebible.org/fraLSG/) et [page des droits](https://ebible.org/fraLSG/copyright.htm). La page des droits nomme la traduction « Louis Segond 1910 » et déclare : « Cette Bible est dans le domaine public. Il n'est pas protégé par copyright. » La même page anglaise dit que cette Bible est dans le domaine public et n’est pas protégée par copyright.

Le paquet source utilisé est [fraLSG_html.zip](https://ebible.org/Scriptures/fraLSG_html.zip), téléchargé le 27 novembre 2026. Les fichiers source eBible.org indiquent une génération datée du 30 octobre 2026. Empreinte SHA-256 de l’archive téléchargée :

```text
a7be2868faa2cc453f8c94458b4c7b3835b17d21ad28ac6e59347ed61c6dab5f
```

Le corpus embarqué est issu des pages chapitre du paquet HTML. L’extraction conserve le texte des versets et écarte les ancres/repères de notes et de renvois qui ne font pas partie du texte des versets. Les contrôles ont vérifié 66 livres, 1 189 chapitres, des références uniques et des marqueurs de verset numérotés sans trou dans chaque chapitre. Le paquet donne 31 170 marqueurs de verset dans cette édition ; ce nombre reflète le comptage de ses marqueurs HTML, et non une promesse que toutes les éditions françaises ont la même versification. Les détails du comptage par livre sont dans [`LSG1910-PROVENANCE.json`](LSG1910-PROVENANCE.json).

## Distribution distincte non utilisée

Le catalogue [GetBible v2 `translations.json`](https://github.com/getbible/v2/blob/master/translations.json) décrit une distribution LS1910 distincte, version 4.0, dont la source est un paquet OSIS de concordance.bible et dont la notice indique « Copyrighted; Permission to distribute granted to CrossWire ». L’application n’utilise ni ce paquet GetBible, ni l’API GetBible, ni la distribution CrossWire. La seule affirmation de droits reproduite ici pour le texte intégré est celle associée au paquet eBible.org exact cité ci-dessus.

## Avant commercialisation

La notice d’eBible.org est une preuve utile de provenance, mais cette application ne fournit pas un avis juridique ni une garantie que toutes les règles nationales, contractuelles ou de magasin sont satisfaites. Avant de vendre ou de distribuer l’application dans un pays, faites confirmer par un juriste compétent que l’édition et les fichiers redistribués sont utilisables comme prévu dans ce territoire. Conservez cette notice et l’archive source avec les dossiers de publication. N’attribuez pas au texte une licence distincte non indiquée par eBible.org.
