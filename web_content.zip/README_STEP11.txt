STEP 11 – Vorrat erweitert: Lebensmittel + Haushalt + Tierbedarf

Erweitert wurden:
- Kategorien für Körperpflege, Haarpflege, Zahnpflege, Toilettenartikel, Papierwaren, Waschmittel, Reinigung, Haushaltsbedarf, Tiernahrung, Tierbedarf, Baby & Kinder, Gesundheit & Apotheke sowie weitere Lebensmittelbereiche.
- Lagerorte um Bad, Putzschrank, Tierbedarf und Haushaltslager.
- Produktdatenbank-Kategorie-Mapping für typische Haushalts- und Tierprodukte (z.B. Klopapier, Shampoo, Waschmittel, Tierfutter).
- Bestehende Funktionen und das kompakte Vorratsdesign bleiben erhalten.
