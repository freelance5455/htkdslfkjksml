# Installing Dawitai on Android

You have three ways to install Dawitai on your Android phone:

## Option 1: Direct Install from Chrome (Fastest — No Computer Needed)
1. Open https://ais-dev-je2apqdnr3xo6rbfkb5n5h-736842031258.europe-west1.run.app in **Google Chrome** on your Android phone.
2. Tap **Get App** inside Dawitai (or tap Chrome's **⋮** menu -> **Install app**).
3. Confirm **Install**. Dawitai will appear in your Android app drawer with its own icon and full-screen window.

## Option 2: Build a Standalone .APK Using Bubblewrap (Recommended for APK)
Requires Node.js 18+ and Java JDK 17 + Android Command Line Tools (Bubblewrap can download them automatically):
```bash
npm install -g @bubblewrap/cli
bubblewrap init --manifest=https://ais-dev-je2apqdnr3xo6rbfkb5n5h-736842031258.europe-west1.run.app/manifest.webmanifest
bubblewrap build
```
Or use the included `twa-manifest.json` directly:
```bash
bubblewrap update
bubblewrap build
```
This outputs `app-release-signed.apk` which you can transfer to your Android phone and install.

## Option 3: Build an Android Studio / Capacitor Project
This archive includes the full Dawitai app source code and `capacitor.config.json` pointing to `https://ais-dev-je2apqdnr3xo6rbfkb5n5h-736842031258.europe-west1.run.app` (so AI requests continue to work securely through your hosted server).
```bash
chmod +x build-android-apk.sh
./build-android-apk.sh
cd android && ./gradlew assembleDebug
```
Your debug APK will be created at:
`android/app/build/outputs/apk/debug/app-debug.apk`
