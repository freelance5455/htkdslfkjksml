// ZiyoKutub - Professional Demo v2
// Improved data persistence, likes, comments, weekly tests, gifts

const STORAGE_KEYS = {
    USERS: 'ziyo_users',
    BOOKS: 'ziyo_books',
    CURRENT_USER: 'ziyo_current_user',
    FAVORITES: 'ziyo_favorites',
    PROGRESS: 'ziyo_progress',
    TEST_RESULTS: 'ziyo_test_results',
    POINTS: 'ziyo_points',
    LIKES: 'ziyo_likes',
    COMMENTS: 'ziyo_comments',
    WEEKLY_TESTS: 'ziyo_weekly_tests',
    GIFTS: 'ziyo_gifts',
    SUGGESTIONS: 'ziyo_suggestions',
    STREAKS: 'ziyo_streaks',
    ACTIVITY: 'ziyo_activity'
};

const ADMIN_CREDENTIALS = {
    username: 'Adminastor',
    password: 'ZiyoKutubAdmin123'
};

const CATEGORIES = [
    'Jadidlar',
    'Badiiy adabiyotlar',
    'Tarixiy kitoblar',
    'Ilm-fan',
    'Maktab darsliklari',
    'Shaxsiy rivojlanish',
    'Bolalar adabiyoti'
];

let currentUser = null;
let isAdmin = false;
let books = [];
let currentPage = 'home';

// ===== DARK MODE =====
function initTheme() {
    const saved = localStorage.getItem('ziyo_theme') || 'light';
    document.documentElement.setAttribute('data-theme', saved);
    updateThemeButton(saved);
}

function updateThemeButton(theme) {
    const btn = document.getElementById('theme-toggle');
    if (btn) btn.textContent = theme === 'dark' ? '☀️' : '🌙';
}

function toggleTheme() {
    const current = document.documentElement.getAttribute('data-theme') || 'light';
    const next = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('ziyo_theme', next);
    updateThemeButton(next);
    playSound('switch');
}

// ===== IMPROVED SOUNDS =====
function playSound(type = 'click') {
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);

        if (type === 'click') {
            osc.type = 'sine';
            osc.frequency.setValueAtTime(600, ctx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(200, ctx.currentTime + 0.08);
            gain.gain.setValueAtTime(0.15, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1);
            osc.start(); osc.stop(ctx.currentTime + 0.1);
        } else if (type === 'success') {
            osc.type = 'sine';
            osc.frequency.setValueAtTime(523, ctx.currentTime);
            osc.frequency.setValueAtTime(659, ctx.currentTime + 0.1);
            osc.frequency.setValueAtTime(784, ctx.currentTime + 0.2);
            gain.gain.setValueAtTime(0.2, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4);
            osc.start(); osc.stop(ctx.currentTime + 0.4);
        } else if (type === 'open') {
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(300, ctx.currentTime);
            osc.frequency.linearRampToValueAtTime(150, ctx.currentTime + 0.15);
            gain.gain.setValueAtTime(0.12, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
            osc.start(); osc.stop(ctx.currentTime + 0.2);
        } else if (type === 'switch') {
            osc.type = 'sine';
            osc.frequency.setValueAtTime(440, ctx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.12);
            gain.gain.setValueAtTime(0.1, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.15);
            osc.start(); osc.stop(ctx.currentTime + 0.15);
        } else if (type === 'gift') {
            osc.type = 'square';
            osc.frequency.setValueAtTime(800, ctx.currentTime);
            osc.frequency.setValueAtTime(1000, ctx.currentTime + 0.1);
            osc.frequency.setValueAtTime(1200, ctx.currentTime + 0.2);
            gain.gain.setValueAtTime(0.18, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.35);
            osc.start(); osc.stop(ctx.currentTime + 0.35);
        }
    } catch (e) {}
}

// Replace old playClickSound
function playClickSound() { playSound('click'); }


// Initialize

// Button click sound (stronger)

// Attach sound to all buttons dynamically
document.addEventListener('click', (e) => {
    if (e.target.closest('.book-card')) {
        playSound('open');
    } else if (e.target.closest('.gift-card')) {
        playSound('gift');
    } else if (e.target.tagName === 'BUTTON' || e.target.closest('button')) {
        playSound('click');
    }
});

document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    document.getElementById('theme-toggle')?.addEventListener('click', toggleTheme);
    // Background music
    const bgMusic = document.getElementById('bg-music');
    const musicToggle = document.getElementById('music-toggle');
    const volumeSlider = document.getElementById('volume-slider');
    if (bgMusic && musicToggle && volumeSlider) {
        bgMusic.volume = 0.3;
        volumeSlider.addEventListener('input', (e) => {
            bgMusic.volume = parseFloat(e.target.value);
            playSound('switch');
        });
        musicToggle.addEventListener('click', () => {
            if (bgMusic.paused) {
                bgMusic.play().catch(() => {});
                musicToggle.textContent = '⏸️';
            } else {
                bgMusic.pause();
                musicToggle.textContent = '▶️';
            }
            playSound('switch');
        });
        // Auto play attempt (may be blocked by browser)
        setTimeout(() => bgMusic.play().catch(() => {}), 1000);
    }

    loadData();
    seedDefaultGifts();
    setupEventListeners();
    checkAuth();
    navigateTo('home');
});


function seedDefaultGifts() {
    const stored = localStorage.getItem(STORAGE_KEYS.GIFTS);
    if (!stored || JSON.parse(stored).length === 0) {
        const gifts = [
            {
                id: 1,
                title: 'Amir Temur kitobi',
                description: 'Buyuk sarkarda Amir Temur haqidagi qiziqarli tarixiy kitob. 100 kitobcha evaziga.',
                requiredPoints: 100,
                image: 'assets/temur.jpg'
            },
            {
                id: 2,
                title: 'Ertak kitobi',
                description: 'Bolalar uchun sevimli ertaklar to‘plami. 25 kitobcha evaziga.',
                requiredPoints: 25,
                image: 'assets/ertak.jpg'
            }
        ];
        localStorage.setItem(STORAGE_KEYS.GIFTS, JSON.stringify(gifts));
    }
}

function loadData() {
    // Premium v3: force new books if version mismatch
    const version = localStorage.getItem('ziyo_version');
    if (version !== 'premium_v3') {
        localStorage.removeItem(STORAGE_KEYS.BOOKS);
        localStorage.setItem('ziyo_version', 'premium_v3');
    }
    try {
        const storedBooks = localStorage.getItem(STORAGE_KEYS.BOOKS);
        if (storedBooks) {
            books = JSON.parse(storedBooks);
        } else {
            seedDefaultBooks();
        }
    } catch (e) {
        console.error('Load error:', e);
        seedDefaultBooks();
    }
}

function seedDefaultBooks() {
    books = [
        {
            id: 1,
            title: 'Jadidlar: Mahmudxo‘ja Behbudiy',
            author: 'Zaynobiddin Abdirashidov',
            category: 'Jadidlar',
            description: 'Jadidchilik harakatining yetakchisi, o‘zbek dramaturgiyasi asoschisi Mahmudxo‘ja Behbudiyning hayoti, faoliyati va asarlari haqida batafsil risola. Yoshlar ishlari agentligi tomonidan nashr etilgan.',
            cover: 'assets/behbudiy.jpg',
            text: `Mahmudxo‘ja Behbudiy (1875–1919) — Turkiston jadidchilik harakatining eng yirik namoyandasi, ma’rifatparvar, dramaturg va jamoat arbobi.

U yangi usuldagi maktablar ochish, gazeta va jurnallar nashr etish, teatr asoslash bilan shug‘ullangan. “Oyina” jurnali va “Samarqand” gazetasini asos solgan.

Eng mashhur asari — “Padarkush” dramasi (1911) o‘zbek milliy dramaturgiyasining ilk namunalaridan biridir. Unda ma’rifatsizlik oqibatlari tasvirlangan.

Behbudiy shunday degan: “Bolalarga otalardan ilmi din va ilmi zamon meros qolsun.”

Uning faoliyati milliy uyg‘onish, ta’lim islohoti va madaniyat rivojiga katta hissa qo‘shgan. (Demo matn — to‘liq asar admin tomonidan qo‘shilishi mumkin.)`,
            isDemo: true
        },
        {
            id: 2,
            title: 'Jadidlar: Abdulla Avloniy',
            author: 'Oltinbek Olim',
            category: 'Jadidlar',
            description: 'Ma’rifatparvar shoir, pedagog va dramaturg Abdulla Avloniyning hayoti va ijodi. “Turkiy Guliston yoxud Axloq” asari va yangi maktablar tashkil etishdagi xizmatlari.',
            cover: 'assets/avloniy.jpg',
            text: `Abdulla Avloniy (1878–1934) — o‘zbek jadidchilik harakatining yirik vakili, shoir, dramaturg va pedagog.

U “Turkiy Guliston yoxud Axloq” asarida axloqiy tarbiya, ilm va ma’rifat g‘oyalarini ilgari surgan. Yangi usuldagi maktablar ochib, o‘quvchilarni zamonaviy bilimlarga o‘rgatgan.

Avloniy shunday yozgan: “Ilm insonlarning madori hayoti, rahbari, najotidur.”

Uning she’rlari va dramalari milliy uyg‘onish ruhida yozilgan. (Demo matn)`,
            isDemo: true
        },
        {
            id: 3,
            title: 'Jadidlar: Abdurauf Fitrat',
            author: 'Hamidulla Boltaboyev',
            category: 'Jadidlar',
            description: 'Abdurauf Fitratning hayoti, siyosiy va adabiy faoliyati. “Munozara”, “Hind sayyohi” kabi asarlari va milliy mustaqillik g‘oyalari haqida.',
            cover: 'assets/fitrat.jpg',
            text: `Abdurauf Fitrat (1886–1938) — o‘zbek adabiyoti va jadidchilikning yirik namoyandasi, olim va siyosatchi.

Uning “Munozara” asari yangi va eski ta’lim usullari o‘rtasidagi bahsni tasvirlaydi. Fitrat milliy madaniyat va tilni rivojlantirish uchun kurashgan.

U shunday degan: “Har bir millat taraqqiysi uchun asosiy sabab ilmdir.”

Fitratning ijodiy merosi bugungi kunda ham dolzarb. (Demo matn)`,
            isDemo: true
        },
        {
            id: 4,
            title: 'Amir Temur',
            author: 'Tarixiy tadqiqot',
            category: 'Tarixiy kitoblar',
            description: 'Buyuk sarkarda, davlat arbobi Amir Temurning hayoti, yurishlari va Temuriylar davlati haqida qiziqarli tarixiy kitob.',
            cover: 'assets/temur.jpg',
            text: `Amir Temur (1336–1405) — buyuk o‘zbek sarkardasi, Temuriylar saltanatining asoschisi.

U Samarqandni poytaxt qilib, ilm-fan, san’at va me’morchilikni rivojlantirgan. “Kuch adolatdadir” degan mashhur iborasi bugungi kunda ham eslanadi.

Temur yurishlari Osiyo va Yevropa tarixiga katta ta’sir ko‘rsatgan. (Demo matn — to‘liq tarixiy matn qo‘shilishi mumkin.)`,
            isDemo: true
        },
        {
            id: 5,
            title: 'Shum bola',
            author: 'G‘afur G‘ulom',
            category: 'Bolalar adabiyoti',
            description: 'G‘afur G‘ulomning mashhur qissasi. Sho‘x va topqir bola Qoravoyning sarguzashtlari haqida kulgili va ibratli hikoya.',
            cover: 'assets/shumbola.jpg',
            text: `“Shum bola” — G‘afur G‘ulomning 1936-yilda yozilgan mashhur qissasi.

Asarda XX asr boshidagi Toshkent hayoti, sho‘x bola Qoravoyning sarguzashtlari tasvirlangan. Qoravoy topqirligi va zukkoligi bilan turli vaziyatlardan chiqib ketadi.

Qissa BBC tomonidan dunyoning eng yaxshi bolalar kitoblari qatoriga kiritilgan. (Demo matn)`,
            isDemo: true
        }
    ];
    saveBooks();
}

function saveBooks() {
    try {
        localStorage.setItem(STORAGE_KEYS.BOOKS, JSON.stringify(books));
        return true;
    } catch (e) {
        alert('Saqlashda xatolik! Rasm juda katta bo‘lishi mumkin. Kichikroq rasm yuklang.');
        console.error(e);
        return false;
    }
}

function reloadBooks() {
    const stored = localStorage.getItem(STORAGE_KEYS.BOOKS);
    if (stored) books = JSON.parse(stored);
}

function setupEventListeners() {
    document.querySelectorAll('nav a').forEach(a => {
        a.addEventListener('click', (e) => {
            e.preventDefault();
            const page = a.dataset.page;
            navigateTo(page);
            document.querySelectorAll('nav a').forEach(link => link.classList.remove('active'));
            a.classList.add('active');
            if (window.innerWidth <= 768) document.getElementById('nav').classList.remove('active');
        });
    });

    document.getElementById('menu-toggle').addEventListener('click', () => {
        document.getElementById('nav').classList.toggle('active');
    });

    document.getElementById('login-btn').addEventListener('click', showAuthModal);
    document.getElementById('admin-btn').addEventListener('click', () => navigateTo('admin'));

    document.getElementById('modal').addEventListener('click', (e) => {
        if (e.target.id === 'modal') closeModal();
    });
}

function checkAuth() {
    const userData = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    if (userData) {
        currentUser = JSON.parse(userData);
        isAdmin = currentUser.isAdmin || false;
        updateHeader();
    }
}

function updateHeader() {
    const loginBtn = document.getElementById('login-btn');
    const adminBtn = document.getElementById('admin-btn');
    if (currentUser) {
        loginBtn.textContent = currentUser.name || 'Profil';
        loginBtn.onclick = () => navigateTo('profile');
        if (isAdmin) adminBtn.style.display = 'inline-block';
    } else {
        loginBtn.textContent = 'Kirish';
        loginBtn.onclick = showAuthModal;
        adminBtn.style.display = 'none';
    }
}

function navigateTo(page) {
    reloadBooks(); // Always reload fresh data
    currentPage = page;
    const main = document.getElementById('main-content');
    switch(page) {
        case 'home': renderHome(main); break;
        case 'books': renderBooks(main); break;
        case 'categories': renderCategories(main); break;
        case 'ziyoai': renderZiyoAI(main); break;
        case 'tests': renderTests(main); break;
        case 'kitobcha': renderKitobcha(main); break;
        case 'takliflar': renderTakliflar(main); break;
        case 'profile': renderProfile(main); break;
        case 'admin': renderAdmin(main); break;
        default: renderHome(main);
    }
}

function renderHome(container) {
    const stats = {
        books: books.length,
        users: JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]').length,
        tests: JSON.parse(localStorage.getItem(STORAGE_KEYS.TEST_RESULTS) || '[]').length
    };
    container.innerHTML = `
        <div class="container">
            <div class="hero">
                <h1>Bilimlar olamiga xush kelibsiz!</h1>
                <p>Sevimli kitoblaringizni o‘qing, yangi bilimlarni kashf eting va ZiyoAI bilan o‘rganing.</p>
                <div class="search-bar">
                    <input type="text" id="home-search" placeholder="Kitob qidiring...">
                    <button class="btn-primary" onclick="searchBooks()">Qidirish</button>
                </div>
                <div style="margin-top: 20px;">
                    <button class="btn-primary" onclick="navigateTo('books')">Kitoblarni ko‘rish</button>
                    <button class="btn-outline" onclick="navigateTo('ziyoai')" style="margin-left: 10px;">ZiyoAI bilan tanishish</button>
                </div>
            </div>
            <div class="stats">
                <div class="stat-card"><h3>${stats.books}</h3><p>Kitoblar</p></div>
                <div class="stat-card"><h3>${stats.users}</h3><p>Foydalanuvchilar</p></div>
                <div class="stat-card"><h3>${stats.tests}</h3><p>O‘tkazilgan testlar</p></div>
                <div class="stat-card"><h3>36-maktab</h3><p>Quyi Chirchiq</p></div>
            </div>
            <div id="class-stats" style="margin: 30px 0;"></div>
            <div id="top-students" style="margin: 30px 0;"></div>
            <h2>Mashhur kitoblar</h2>
            <div class="books-grid" id="popular-books"></div>
            <h2 style="margin-top: 40px;">Kategoriyalar</h2>
            <div class="categories-grid" id="home-categories"></div>
        </div>
    `;
    renderBookCards(document.getElementById('popular-books'), books.slice(0, 4));
    renderCategoryCards(document.getElementById('home-categories'));
    // Class and top students
    const classStats = getClassStats();
    const topStudents = getTopStudents();
    const classEl = document.getElementById('class-stats');
    if (classEl) {
        if (classStats.length) {
            classEl.innerHTML = `<h2>🏆 Eng faol sinflar</h2><div class="stats">${classStats.slice(0,3).map((c,i) => `<div class="stat-card"><h3>${i===0?'🥇 ':i===1?'🥈 ':i===2?'🥉 ':''}${c.cls}</h3><p>${c.reads} o‘qish • ${c.tests} test</p></div>`).join('')}</div>`;
        } else {
            classEl.innerHTML = `<h2>🏆 Eng faol sinflar</h2><p style="color:#888;">Hali ma’lumot yo‘q. Kitob o‘qing va test ishlang!</p>`;
        }
    }
    const topEl = document.getElementById('top-students');
    if (topEl) {
        if (topStudents.length) {
            topEl.innerHTML = `<h2>⭐ Haftalik eng faol o‘quvchilar</h2>
                <p style="color:#666; margin-bottom:12px;">1-o‘rin avtomatik +3 kitobcha oladi. Haftalik testlarda 100% → +5 bonus.</p>
                ${topStudents.map((s,i) => `<div class="stat-card" style="margin:8px 0; display:flex; justify-content:space-between; align-items:center;">
                    <span>${i===0?'🥇':i===1?'🥈':i===2?'🥉':(i+1)+'.'} <strong>${s.name}</strong></span>
                    <span>${s.reads} kitob • ${s.tests} test • ${s.score} ball</span>
                </div>`).join('')}`;
        } else {
            topEl.innerHTML = `<h2>⭐ Haftalik eng faol o‘quvchilar</h2><p style="color:#888;">Hali reyting yo‘q.</p>`;
        }
    }
    // Kunlik maqsad / streak banner
    if (currentUser) {
        const streak = (JSON.parse(localStorage.getItem(STORAGE_KEYS.STREAKS) || '{}')[currentUser.id] || {count: 0}).count;
        const hero = container.querySelector('.hero');
        if (hero) {
            const badge = document.createElement('div');
            badge.className = 'streak-badge';
            badge.style.margin = '16px auto 0';
            badge.style.display = 'inline-flex';
            badge.innerHTML = streak > 0 ? `🔥 ${streak} kunlik streak — bugun ham o‘qing!` : `🎯 Kunlik maqsad: 1 kitob o‘qing`;
            hero.appendChild(badge);
        }
    }
    const searchEl = document.getElementById('home-search');
    if (searchEl) searchEl.addEventListener('keypress', (e) => { if (e.key === 'Enter') searchBooks(); });
}

function renderBooks(container, filtered = null) {
    const list = filtered || books;
    container.innerHTML = `
        <div class="container">
            <h1>Elektron kutubxona</h1>
            <div style="display: flex; gap: 12px; margin: 20px 0; flex-wrap: wrap;">
                <input type="text" id="book-search" placeholder="Qidirish..." style="flex: 1; min-width: 200px; padding: 12px; border-radius: 10px; border: 1.5px solid #E0E0E0;">
                <select id="category-filter" style="padding: 12px; border-radius: 10px; border: 1.5px solid #E0E0E0;">
                    <option value="">Barcha kategoriyalar</option>
                    ${CATEGORIES.map(c => `<option value="${c}">${c}</option>`).join('')}
                </select>
                <select id="sort-select" style="padding: 12px; border-radius: 10px; border: 1.5px solid #E0E0E0;">
                    <option value="title">Nom bo‘yicha</option>
                    <option value="author">Muallif bo‘yicha</option>
                </select>
            </div>
            <div class="books-grid" id="books-list"></div>
        </div>
    `;
    renderBookCards(document.getElementById('books-list'), list);
    document.getElementById('book-search').addEventListener('input', filterBooks);
    document.getElementById('category-filter').addEventListener('change', filterBooks);
    document.getElementById('sort-select').addEventListener('change', filterBooks);
}

function filterBooks() {
    const search = (document.getElementById('book-search')?.value || '').toLowerCase();
    const cat = document.getElementById('category-filter')?.value || '';
    const sort = document.getElementById('sort-select')?.value || 'title';
    let filtered = books.filter(b => 
        (b.title.toLowerCase().includes(search) || b.author.toLowerCase().includes(search)) &&
        (!cat || b.category === cat)
    );
    if (sort === 'title') filtered.sort((a,b) => a.title.localeCompare(b.title));
    if (sort === 'author') filtered.sort((a,b) => a.author.localeCompare(b.author));
    renderBookCards(document.getElementById('books-list'), filtered);
}

function getLikes(bookId) {
    const likes = JSON.parse(localStorage.getItem(STORAGE_KEYS.LIKES) || '{}');
    return likes[bookId] || [];
}

function toggleLike(bookId) {
    if (!currentUser) { alert('Avval tizimga kiring'); return; }
    let likes = JSON.parse(localStorage.getItem(STORAGE_KEYS.LIKES) || '{}');
    if (!likes[bookId]) likes[bookId] = [];
    const idx = likes[bookId].indexOf(currentUser.id);
    if (idx === -1) likes[bookId].push(currentUser.id);
    else likes[bookId].splice(idx, 1);
    localStorage.setItem(STORAGE_KEYS.LIKES, JSON.stringify(likes));
    // Refresh current view
    if (currentPage === 'books') filterBooks();
    else if (currentPage === 'home') navigateTo('home');
}

function getComments(bookId) {
    const comments = JSON.parse(localStorage.getItem(STORAGE_KEYS.COMMENTS) || '{}');
    return comments[bookId] || [];
}

function addComment(bookId) {
    if (!currentUser) { alert('Avval tizimga kiring'); return; }
    const text = prompt('Izoh yozing:');
    if (!text || !text.trim()) return;
    let comments = JSON.parse(localStorage.getItem(STORAGE_KEYS.COMMENTS) || '{}');
    if (!comments[bookId]) comments[bookId] = [];
    comments[bookId].push({
        user: currentUser.name,
        text: text.trim(),
        date: new Date().toLocaleString()
    });
    localStorage.setItem(STORAGE_KEYS.COMMENTS, JSON.stringify(comments));
    openBook(bookId); // Refresh modal
}

function renderBookCards(container, bookList) {
    if (!container) return;
    if (bookList.length === 0) {
        container.innerHTML = '<p style="grid-column: 1/-1; text-align:center; padding:40px;">Kitoblar topilmadi. Admin panel orqali qo‘shing.</p>';
        return;
    }
    container.innerHTML = bookList.map(book => {
        const likes = getLikes(book.id);
        const liked = currentUser && likes.includes(currentUser.id);
        const progress = getProgressPercent(book.id);
        return `
        <div class="book-card">
            <img src="${book.cover}" alt="${book.title}" onerror="this.src='https://via.placeholder.com/220x280/1B5E20/FFFFFF?text=Muqova'">
            <div class="info">
                <h3>${book.title}</h3>
                <div class="author">${book.author}</div>
                <div class="progress-bar"><div class="progress-fill" style="width: ${progress}%"></div></div>
                <small style="color:#666;">${progress}% o‘qildi</small>
                <p style="font-size: 0.85rem; color: #666; margin: 6px 0;">${(book.description || '').substring(0, 70)}...</p>
                <div class="book-actions">
                    <button class="like-btn ${liked ? 'liked' : ''}" onclick="toggleLike(${book.id})">
                        ♥ ${likes.length}
                    </button>
                    <button class="btn-outline" style="padding: 6px 12px; font-size: 0.85rem;" onclick="openBook(${book.id})">Batafsil</button>
                    <button class="btn-primary" style="padding: 6px 12px; font-size: 0.85rem;" onclick="openReader(${book.id})">O‘qish</button>
                </div>
            </div>
        </div>`;
    }).join('');
}

function openBook(id) {
    playSound('open');
    const book = books.find(b => b.id == id);
    if (!book) return;
    const comments = getComments(id);
    const likes = getLikes(id);
    const liked = currentUser && likes.includes(currentUser.id);
    showModal(`
        <h2>${book.title}</h2>
        <p><strong>Muallif:</strong> ${book.author}</p>
        <p><strong>Kategoriya:</strong> ${book.category}</p>
        <p>${book.description}</p>
        ${book.isDemo ? '<p style="color: #FF6F00; margin-top: 10px;"><em>Demo material — to‘liq matn admin tomonidan qo‘shiladi.</em></p>' : ''}
        <div style="margin: 16px 0; display: flex; gap: 10px; align-items: center;">
            <button class="like-btn ${liked ? 'liked' : ''}" onclick="toggleLike(${book.id}); closeModal(); openBook(${book.id});">♥ ${likes.length}</button>
            <button class="btn-primary" onclick="openReader(${book.id}); closeModal();">O‘qish</button>
            <button class="btn-outline" onclick="addToFavorites(${book.id});">Sevimlilarga</button>
        </div>
        <div class="comments-section">
            <h4>Izohlar (${comments.length})</h4>
            ${comments.length ? comments.map(c => `<div class="comment"><strong>${c.user}</strong> <small>${c.date}</small><br>${c.text}</div>`).join('') : '<p>Hali izoh yo‘q</p>'}
            <button class="btn-outline" style="margin-top: 10px;" onclick="addComment(${book.id})">Izoh qoldirish</button>
        </div>
    `);
}

// Click sound (Web Audio API)

// Attach click sound to all buttons
document.addEventListener('click', (e) => {
    if (e.target.matches('button, .btn, .btn-primary, .btn-outline, .like-btn, .book-card, .category-card')) {
        playClickSound();
    }
});

function speakBook(id) {
    const book = books.find(b => b.id == id);
    if (!book) return;
    // If admin uploaded audio
    if (book.audio) {
        if (window.currentAudio) { window.currentAudio.pause(); window.currentAudio = null; }
        const audio = new Audio(book.audio);
        window.currentAudio = audio;
        audio.play();
        return;
    }
    // Fallback to TTS
    if (!book.text) return alert('Matn mavjud emas');
    if (!window.speechSynthesis) return alert('Brauzeringiz ovozli o‘qishni qo‘llab-quvvatlamaydi');
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(book.text);
    utterance.lang = 'uz-UZ';
    utterance.rate = 0.9;
    window.speechSynthesis.speak(utterance);
}

function stopSpeech() {
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    if (window.currentAudio) { window.currentAudio.pause(); window.currentAudio = null; }
}

function showCelebration() {
    const overlay = document.createElement('div');
    overlay.className = 'celebration-overlay';
    overlay.innerHTML = `
        <div class="celebration-box">
            <h2>🎉 Tabriklaymiz!</h2>
            <p style="font-size:1.2rem; margin:10px 0;">Kitobni muvaffaqiyatli tugatdingiz!</p>
            <p>🔥 Streak yangilandi</p>
        </div>
    `;
    document.body.appendChild(overlay);
    setTimeout(() => overlay.remove(), 5000);
}

function openReader(id) {
    const book = books.find(b => b.id == id);
    if (!book) return;
    // O‘qishni boshlaganida kamida 15%
    if (currentUser) {
        const p = getProgressPercent(id);
        if (p < 15) setProgress(id, 15);
    }
    const progress = getProgressPercent(id);
    document.getElementById('main-content').innerHTML = `
        <div class="container">
            <button class="btn-outline" onclick="navigateTo('books')" style="margin-bottom: 20px;">← Orqaga</button>
            <div class="reader">
                <h1>${book.title}</h1>
                <p style="color: #666; margin-bottom: 20px;">${book.author} • ${book.category}</p>
                ${book.isDemo ? '<div style="background: #FFF3E0; padding: 12px; border-radius: 8px; margin-bottom: 20px;"><strong>Demo rejim:</strong> Bu qisqa matn. To‘liq kitob admin tomonidan qo‘shiladi.</div>' : ''}
                <div style="margin-bottom: 16px; display:flex; flex-wrap:wrap; gap:8px; align-items:center;">
                    <label>Matn o‘lchami: <input type="range" id="font-size" min="14" max="24" value="18" oninput="document.getElementById('book-text').style.fontSize = this.value + 'px'"></label>
                    <button class="btn-outline" onclick="addToFavorites(${id})">Sevimlilarga</button>
                    <button class="btn-primary" onclick="speakBook(${id})">🔊 Ovozli o‘qish</button>
                    <button class="btn-outline" onclick="stopSpeech()">⏹ To‘xtatish</button>
                </div>
                <p style="margin-bottom:6px;"><strong>O‘qish holati: ${progress}%</strong></p>
                <div class="progress-bar" style="margin-bottom: 12px; height:10px;"><div class="progress-fill" id="reader-progress" style="width: ${progress}%"></div></div>
                <div style="margin-bottom: 16px; display:flex; flex-wrap:wrap; gap:8px;">
                    <button class="btn-outline" onclick="setProgress(${id}, 25)">25%</button>
                    <button class="btn-outline" onclick="setProgress(${id}, 50)">50%</button>
                    <button class="btn-outline" onclick="setProgress(${id}, 75)">75%</button>
                    <button class="btn-primary" onclick="setProgress(${id}, 100)">100% (tugatdim)</button>
                </div>
                <div class="reader-text" id="book-text" style="font-size: 18px;">${(book.text || 'Matn mavjud emas').replace(/\n/g, '<br>')}</div>
                <div style="margin-top: 30px;">
                    <button class="btn-primary" onclick="startTestForBook(${id})">Kitob bo‘yicha test (demo)</button>
                    <button class="btn-outline" onclick="askAIAboutBook(${id})">ZiyoAI ga savol</button>
                </div>
            </div>
        </div>
    `;
}

function setProgress(bookId, percent) {
    if (!currentUser) { alert('Iltimos, avval tizimga kiring.'); return; }
    const progresses = JSON.parse(localStorage.getItem(STORAGE_KEYS.PROGRESS) || '{}');
    const key = `${currentUser.id}_${bookId}`;
    const prev = progresses[key] || 0;
    progresses[key] = Math.max(prev, percent);
    localStorage.setItem(STORAGE_KEYS.PROGRESS, JSON.stringify(progresses));
    if (percent >= 100 && prev < 100) {
        recordActivity('read');
        showCelebration();
    }
    const bar = document.getElementById('reader-progress');
    if (bar) bar.style.width = progresses[key] + '%';
    // Qayta chizish uchun
    openReader(bookId);
}

function saveProgress(bookId) {
    if (!currentUser) { alert('Iltimos, avval tizimga kiring.'); return; }
    const progresses = JSON.parse(localStorage.getItem(STORAGE_KEYS.PROGRESS) || '{}');
    progresses[`${currentUser.id}_${bookId}`] = 100;
    localStorage.setItem(STORAGE_KEYS.PROGRESS, JSON.stringify(progresses));
    recordActivity('read');
    alert('O‘qish holati saqlandi! Streak yangilandi.');
}

function getProgressPercent(bookId) {
    if (!currentUser) return 0;
    const progresses = JSON.parse(localStorage.getItem(STORAGE_KEYS.PROGRESS) || '{}');
    return progresses[`${currentUser.id}_${bookId}`] || 0;
}

function updateStreak() {
    if (!currentUser) return;
    const today = new Date().toDateString();
    let streaks = JSON.parse(localStorage.getItem(STORAGE_KEYS.STREAKS) || '{}');
    if (!streaks[currentUser.id]) streaks[currentUser.id] = { count: 0, lastDate: '' };
    const userStreak = streaks[currentUser.id];
    if (userStreak.lastDate !== today) {
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        if (userStreak.lastDate === yesterday.toDateString()) {
            userStreak.count += 1;
        } else {
            userStreak.count = 1;
        }
        userStreak.lastDate = today;
        streaks[currentUser.id] = userStreak;
        localStorage.setItem(STORAGE_KEYS.STREAKS, JSON.stringify(streaks));
    }
}

function recordActivity(type = 'read') {
    if (!currentUser) return;
    updateStreak();
    let activity = JSON.parse(localStorage.getItem(STORAGE_KEYS.ACTIVITY) || '{}');
    if (!activity[currentUser.id]) activity[currentUser.id] = { reads: 0, tests: 0, class: currentUser.class || 'Noma’lum' };
    if (type === 'read') activity[currentUser.id].reads += 1;
    if (type === 'test') activity[currentUser.id].tests += 1;
    activity[currentUser.id].class = currentUser.class || 'Noma’lum';
    localStorage.setItem(STORAGE_KEYS.ACTIVITY, JSON.stringify(activity));
}

function getClassStats() {
    const activity = JSON.parse(localStorage.getItem(STORAGE_KEYS.ACTIVITY) || '{}');
    const classMap = {};
    Object.values(activity).forEach(a => {
        const cls = a.class || 'Noma’lum';
        if (!classMap[cls]) classMap[cls] = { reads: 0, tests: 0, students: 0 };
        classMap[cls].reads += a.reads || 0;
        classMap[cls].tests += a.tests || 0;
        classMap[cls].students += 1;
    });
    return Object.entries(classMap).map(([cls, data]) => ({ cls, ...data })).sort((a, b) => b.reads - a.reads);
}

function getTopStudents() {
    const activity = JSON.parse(localStorage.getItem(STORAGE_KEYS.ACTIVITY) || '{}');
    const users = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    return Object.entries(activity).map(([id, a]) => {
        const user = users.find(u => u.id == id) || { name: 'Noma’lum' };
        return { name: user.name, reads: a.reads || 0, tests: a.tests || 0, score: (a.reads || 0) * 10 + (a.tests || 0) * 5 };
    }).sort((a, b) => b.score - a.score).slice(0, 5);
}

function addToFavorites(bookId) {
    if (!currentUser) { alert('Iltimos, avval tizimga kiring.'); showAuthModal(); return; }
    let favs = JSON.parse(localStorage.getItem(STORAGE_KEYS.FAVORITES) || '{}');
    if (!favs[currentUser.id]) favs[currentUser.id] = [];
    if (!favs[currentUser.id].includes(bookId)) {
        favs[currentUser.id].push(bookId);
        localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(favs));
        alert('Sevimlilarga qo‘shildi!');
    } else {
        alert('Allaqachon sevimlilarda.');
    }
}

function renderCategories(container) {
    container.innerHTML = `
        <div class="container">
            <h1>Kategoriyalar</h1>
            <div class="categories-grid" id="cat-list"></div>
        </div>
    `;
    renderCategoryCards(document.getElementById('cat-list'), true);
}

function renderCategoryCards(container, clickable = false) {
    if (!container) return;
    container.innerHTML = CATEGORIES.map(cat => `
        <div class="category-card" ${clickable ? `onclick="filterByCategory('${cat}')"` : ''}>
            <h3>${cat}</h3>
            <p>${books.filter(b => b.category === cat).length} kitob</p>
        </div>
    `).join('');
}

function filterByCategory(cat) {
    navigateTo('books');
    setTimeout(() => {
        const filter = document.getElementById('category-filter');
        if (filter) {
            filter.value = cat;
            filterBooks();
        }
    }, 150);
}

// ZiyoAI (demo)
function renderZiyoAI(container) {
    container.innerHTML = `
        <div class="container">
            <h1>ZiyoAI — Aqlli yordamchi</h1>
            <div class="ziyo-character" id="ziyo-char">
                <div class="eyes"><div class="eye"></div><div class="eye"></div></div>
                <div class="mouth"></div>
            </div>
            <p style="color: #666; margin-bottom: 20px; text-align:center;">Demo rejim: Haqiqiy AI API ulanmagan. Oddiy javoblar beriladi.</p>
            <div class="chat-container">
                <div class="chat-messages" id="chat-messages">
                    <div class="message ai">Salom! Men ZiyoAI. Kitoblar yoki mavzular haqida savol bering.</div>
                </div>
                <div class="chat-input">
                    <input type="text" id="chat-input" placeholder="Savolingizni yozing...">
                    <button class="btn-primary" onclick="sendChat()">Yuborish</button>
                    <button class="btn-outline" onclick="clearChat()">Tozalash</button>
                </div>
            </div>
        </div>
    `;
    document.getElementById('chat-input')?.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendChat();
    });
}

function sendChat() {
    const char = document.getElementById('ziyo-char');
    if (char) {
        char.classList.add('talking', 'happy');
        setTimeout(() => char.classList.remove('talking'), 2000);
        setTimeout(() => char.classList.remove('happy'), 2500);
    }
    playSound('success');
    const input = document.getElementById('chat-input');
    const text = input?.value.trim();
    if (!text) return;
    const messages = document.getElementById('chat-messages');
    messages.innerHTML += `<div class="message user">${text}</div>`;
    input.value = '';
    setTimeout(() => {
        const response = generateAIResponse(text);
        messages.innerHTML += `<div class="message ai">${response}</div>`;
        messages.scrollTop = messages.scrollHeight;
    }, 500);
}

function generateAIResponse(query) {
    const q = query.toLowerCase();
    if (q.includes('alpomish')) return 'Alpomish — o‘zbek xalq doston. Qahramonlik, sadoqat va jasorat haqida.';
    if (q.includes('o‘tgan kunlar') || q.includes('qodiriy')) return 'O‘tgan kunlar Abdulla Qodiriyning mashhur roman.';
    if (q.includes('kitob')) return 'Kutubxonada kitoblar bor. Qaysi biri haqida so‘ramoqchisiz?';
    return 'Demo rejimda ishlayman. Ko‘proq kitob o‘qing va bilimingizni oshiring!';
}

function clearChat() {
    document.getElementById('chat-messages').innerHTML = '<div class="message ai">Suhbat tozalandi.</div>';
}

function askAIAboutBook(id) {
    const book = books.find(b => b.id == id);
    navigateTo('ziyoai');
    setTimeout(() => {
        const input = document.getElementById('chat-input');
        if (input) {
            input.value = `${book.title} kitobi haqida gapirib ber`;
            sendChat();
        }
    }, 300);
}

// Tests
function renderTests(container) {
    const weekly = JSON.parse(localStorage.getItem(STORAGE_KEYS.WEEKLY_TESTS) || '[]');
    container.innerHTML = `
        <div class="container">
            <h1>Testlar</h1>
            <p>Demo testlar ball bermaydi. Faqat admin tomonidan yaratilgan haftalik testlar ball beradi.</p>
            <div style="margin: 20px 0;">
                <h3>Haftalik testlar (ball beradi)</h3>
                ${weekly.length ? weekly.map((t, i) => `<button class="btn-primary" style="margin: 5px;" onclick="startWeeklyTest(${i})">${t.title || 'Haftalik test ' + (i+1)}</button>`).join('') : '<p>Hali haftalik test yo‘q. Admin qo‘shadi.</p>'}
                <h3 style="margin-top: 20px;">Demo testlar (ball bermaydi)</h3>
                <button class="btn-outline" onclick="startDemoTest()">Umumiy demo test</button>
                ${books.map(b => `<button class="btn-outline" style="margin: 5px;" onclick="startTestForBook(${b.id})">${b.title}</button>`).join('')}
            </div>
            <div id="test-area"></div>
            <h2 style="margin-top: 40px;">Top reyting (haftalik testlar)</h2>
            <div id="leaderboard"></div>
        </div>
    `;
    renderLeaderboard();
}

function startDemoTest() {
    const questions = [
        { q: 'Alpomish qanday asar?', options: ['Roman', 'Doston', 'She’r'], correct: 1 },
        { q: 'O‘tgan kunlar muallifi kim?', options: ['Oybek', 'Abdulla Qodiriy', 'G‘afur G‘ulom'], correct: 1 }
    ];
    runTest(questions, false);
}

function startTestForBook(id) {
    const book = books.find(b => b.id == id);
    const questions = [
        { q: `${book.title} muallifi kim?`, options: [book.author, 'Boshqa', 'Noma’lum'], correct: 0 },
        { q: `Kategoriya?`, options: CATEGORIES, correct: CATEGORIES.indexOf(book.category) }
    ];
    runTest(questions, false);
}

function startWeeklyTest(index) {
    const weekly = JSON.parse(localStorage.getItem(STORAGE_KEYS.WEEKLY_TESTS) || '[]');
    const test = weekly[index];
    if (!test || !test.questions) return alert('Test mavjud emas');
    runTest(test.questions, true, test.title);
}

function runTest(questions, givesPoints, title = 'Test') {
    let current = 0;
    let answers = [];
    const area = document.getElementById('test-area');
    function showQuestion() {
        if (current >= questions.length) {
            finishTest(questions, answers, givesPoints, title);
            return;
        }
        const q = questions[current];
        area.innerHTML = `
            <div class="question-card">
                <h3>${title} — Savol ${current+1}/${questions.length}</h3>
                <p>${q.q}</p>
                <div class="options">
                    ${q.options.map((opt, i) => `<label><input type="radio" name="opt" value="${i}"> ${opt}</label>`).join('')}
                </div>
                <button class="btn-primary" style="margin-top: 16px;" onclick="window.nextQ()">Keyingi</button>
            </div>
        `;
    }
    window.nextQ = () => {
        const selected = document.querySelector('input[name="opt"]:checked');
        if (!selected) { alert('Javob tanlang'); return; }
        answers.push(parseInt(selected.value));
        current++;
        showQuestion();
    };
    showQuestion();
}

function finishTest(questions, answers, givesPoints, title) {
    let correct = 0;
    questions.forEach((q, i) => { if (answers[i] === q.correct) correct++; });
    const percent = Math.round((correct / questions.length) * 100);
    let pointsAwarded = 0;
    if (currentUser) {
        recordActivity('test');
    }
    if (givesPoints && currentUser) {
        pointsAwarded = Math.floor(percent / 4); // 100% = 25 kitobcha
        // Bonus: agar 100% bo‘lsa +5 kitobcha
        if (percent === 100) pointsAwarded += 5;
        let pointsData = JSON.parse(localStorage.getItem(STORAGE_KEYS.POINTS) || '{}');
        pointsData[currentUser.id] = (pointsData[currentUser.id] || 0) + pointsAwarded;
        localStorage.setItem(STORAGE_KEYS.POINTS, JSON.stringify(pointsData));
        let results = JSON.parse(localStorage.getItem(STORAGE_KEYS.TEST_RESULTS) || '[]');
        results.push({ userId: currentUser.id, name: currentUser.name, score: percent, date: new Date().toISOString(), type: title });
        localStorage.setItem(STORAGE_KEYS.TEST_RESULTS, JSON.stringify(results));
        // Eng faol o‘quvchiga avtomatik bonus (1-o‘rin)
        const top = getTopStudents();
        if (top.length && top[0].name === currentUser.name && top[0].score > 0) {
            pointsData[currentUser.id] = (pointsData[currentUser.id] || 0) + 3;
            localStorage.setItem(STORAGE_KEYS.POINTS, JSON.stringify(pointsData));
            pointsAwarded += 3;
        }
    }
    document.getElementById('test-area').innerHTML = `
        <div class="test-card">
            <h2>Natija: ${title}</h2>
            <p>To‘g‘ri: ${correct} / ${questions.length}</p>
            <p>Foiz: ${percent}%</p>
            ${givesPoints ? `<p style="color: green;">Sizga <strong>${pointsAwarded}</strong> kitobcha berildi!</p>` : '<p style="color: orange;">Bu demo test — ball berilmaydi.</p>'}
            <button class="btn-primary" onclick="navigateTo('tests')">Orqaga</button>
        </div>
    `;
    renderLeaderboard();
}

function renderLeaderboard() {
    const results = JSON.parse(localStorage.getItem(STORAGE_KEYS.TEST_RESULTS) || '[]');
    const top = results.sort((a,b) => b.score - a.score).slice(0, 5);
    const el = document.getElementById('leaderboard');
    if (el) {
        el.innerHTML = top.length ? top.map((r, i) => `<div class="stat-card" style="margin: 8px 0;">${i+1}. ${r.name} — ${r.score} ball</div>`).join('') : '<p>Hali natijalar yo‘q</p>';
    }
}

// Takliflar (Suggestions)
function renderTakliflar(container) {
    const suggestions = JSON.parse(localStorage.getItem(STORAGE_KEYS.SUGGESTIONS) || '[]');
    container.innerHTML = `
        <div class="container">
            <h1>Takliflar</h1>
            <p>Saytni yaxshilash uchun o‘z takliflaringizni yuboring. Admin ularni ko‘rib chiqadi.</p>
            ${currentUser ? `
                <div class="test-card" style="margin: 20px 0;">
                    <h3>Yangi taklif yuborish</h3>
                    <textarea id="suggestion-text" rows="4" placeholder="Taklifingizni yozing..." style="width:100%; padding:12px; border-radius:10px; border:1.5px solid #E0E0E0; margin:10px 0;"></textarea>
                    <button class="btn-primary" onclick="submitSuggestion()">Yuborish</button>
                </div>
            ` : '<p style="color:orange;">Taklif yuborish uchun tizimga kiring.</p>'}
            <h2 style="margin-top:30px;">Barcha takliflar</h2>
            <div id="suggestions-list">
                ${suggestions.length ? suggestions.slice().reverse().map(s => `
                    <div class="stat-card" style="margin:10px 0; text-align:left;">
                        <strong>${s.user}</strong> <small style="color:#888;">${s.date}</small>
                        <p style="margin-top:8px;">${s.text}</p>
                        ${isAdmin ? `<button class="btn-outline" style="margin-top:8px;" onclick="deleteSuggestion('${s.id}')">O‘chirish</button>` : ''}
                    </div>
                `).join('') : '<p>Hali takliflar yo‘q.</p>'}
            </div>
        </div>
    `;
}

function submitSuggestion() {
    if (!currentUser) return alert('Avval kiring');
    const text = document.getElementById('suggestion-text')?.value.trim();
    if (!text) return alert('Taklif yozing');
    let suggestions = JSON.parse(localStorage.getItem(STORAGE_KEYS.SUGGESTIONS) || '[]');
    suggestions.push({
        id: Date.now(),
        user: currentUser.name,
        text,
        date: new Date().toLocaleString()
    });
    localStorage.setItem(STORAGE_KEYS.SUGGESTIONS, JSON.stringify(suggestions));
    alert('Taklif yuborildi! Rahmat.');
    navigateTo('takliflar');
}

function deleteSuggestion(id) {
    if (!isAdmin) return;
    if (!confirm('O‘chirish?')) return;
    let suggestions = JSON.parse(localStorage.getItem(STORAGE_KEYS.SUGGESTIONS) || '[]');
    suggestions = suggestions.filter(s => s.id != id);
    localStorage.setItem(STORAGE_KEYS.SUGGESTIONS, JSON.stringify(suggestions));
    navigateTo('takliflar');
}

// Kitobcha / Sovg'alar
function renderKitobcha(container) {
    const gifts = JSON.parse(localStorage.getItem(STORAGE_KEYS.GIFTS) || '[]');
    const userPoints = currentUser ? (JSON.parse(localStorage.getItem(STORAGE_KEYS.POINTS) || '{}')[currentUser.id] || 0) : 0;
    container.innerHTML = `
        <div class="container">
            <h1>Kitobcha — Sovg‘alar</h1>
            <div class="stat-card" style="margin-bottom: 24px;">
                <h2>Sizning kitobchangiz: <span style="color: var(--orange);">${userPoints}</span></h2>
                <p>Maktab tomonidan ballarga sovg‘alar beriladi. 100 ball ≈ 25 kitobcha.</p>
            </div>
            <div class="books-grid">
                ${gifts.length ? gifts.map(g => `
                    <div class="gift-card">
                        <img src="${g.image || 'https://via.placeholder.com/300x180/FF6F00/FFFFFF?text=Sovg\'a'}" alt="${g.title}">
                        <h3>${g.title}</h3>
                        <p>${g.description || ''}</p>
                        <div class="points-badge">${g.requiredPoints} kitobcha</div>
                        ${currentUser && userPoints >= g.requiredPoints ? '<p style="color: green; margin-top: 8px;">Siz olishingiz mumkin!</p>' : ''}
                    </div>
                `).join('') : '<p style="grid-column:1/-1; text-align:center;">Hali sovg‘alar qo‘shilmagan. Admin qo‘shadi.</p>'}
            </div>
        </div>
    `;
}

// Profile
function renderProfile(container) {
    if (!currentUser) {
        container.innerHTML = '<div class="container"><p>Iltimos, tizimga kiring.</p><button class="btn-primary" onclick="showAuthModal()">Kirish</button></div>';
        return;
    }
    const favs = JSON.parse(localStorage.getItem(STORAGE_KEYS.FAVORITES) || '{}')[currentUser.id] || [];
    const favBooks = books.filter(b => favs.includes(b.id));
    const points = JSON.parse(localStorage.getItem(STORAGE_KEYS.POINTS) || '{}')[currentUser.id] || 0;
    const results = JSON.parse(localStorage.getItem(STORAGE_KEYS.TEST_RESULTS) || '[]').filter(r => r.userId === currentUser.id);
    const streak = (JSON.parse(localStorage.getItem(STORAGE_KEYS.STREAKS) || '{}')[currentUser.id] || {count: 0}).count;
    container.innerHTML = `
        <div class="container">
            <h1>Shaxsiy kabinet</h1>
            <div class="stat-card" style="margin-bottom: 20px;">
                <h2>${currentUser.name}</h2>
                <p>Sinf: ${currentUser.class || 'Noma’lum'}</p>
                <p>Kitobcha: <strong>${points}</strong> ta</p>
                <div class="streak-badge" style="margin-top: 10px;">🔥 ${streak} kunlik streak</div>
            </div>
            <h2>Sevimli kitoblar</h2>
            <div class="books-grid" id="fav-books"></div>
            <h2 style="margin-top: 30px;">Test natijalari</h2>
            <div>${results.map(r => `<p>${new Date(r.date).toLocaleDateString()} — ${r.score}% (${r.type})</p>`).join('') || 'Hali yo‘q'}</div>
            <button class="btn-outline" style="margin-top: 20px;" onclick="logout()">Chiqish</button>
        </div>
    `;
    renderBookCards(document.getElementById('fav-books'), favBooks);
}

// Admin
function renderAdmin(container) {
    if (!isAdmin) {
        container.innerHTML = '<div class="container"><p>Admin kirish talab qilinadi.</p></div>';
        return;
    }
    const weekly = JSON.parse(localStorage.getItem(STORAGE_KEYS.WEEKLY_TESTS) || '[]');
    const gifts = JSON.parse(localStorage.getItem(STORAGE_KEYS.GIFTS) || '[]');
    container.innerHTML = `
        <div class="container">
            <h1>Admin paneli</h1>
            <div style="display: flex; gap: 12px; flex-wrap: wrap; margin: 20px 0;">
                <button class="btn-primary" onclick="showAddBook()">Yangi kitob qo‘shish</button>
                <button class="btn-primary" onclick="showAddWeeklyTest()">Haftalik test qo‘shish</button>
                <button class="btn-primary" onclick="showAddGift()">Sovg‘a qo‘shish</button>
            </div>
            <h2>Kitoblar</h2>
            <div id="admin-books" class="books-grid"></div>
            <h2 style="margin-top: 40px;">Haftalik testlar</h2>
            <div>${weekly.map((t, i) => `<div class="stat-card" style="margin: 8px 0;">${t.title} <button class="btn-outline" onclick="deleteWeekly(${i})">O‘chirish</button></div>`).join('') || 'Yo‘q'}</div>
            <h2 style="margin-top: 40px;">Sovg‘alar</h2>
            <div class="books-grid">${gifts.map((g, i) => `<div class="gift-card"><h3>${g.title}</h3><p>${g.requiredPoints} kitobcha</p><button class="btn-outline" onclick="deleteGift(${i})">O‘chirish</button></div>`).join('') || 'Yo‘q'}</div>
        </div>
    `;
    const adminBooks = document.getElementById('admin-books');
    adminBooks.innerHTML = books.map(b => `
        <div class="book-card">
            <img src="${b.cover}" alt="">
            <div class="info">
                <h3>${b.title}</h3>
                <button class="btn-outline" onclick="editBook(${b.id})">Tahrirlash</button>
                <button class="btn-outline" onclick="deleteBook(${b.id})" style="margin-top: 6px;">O‘chirish</button>
            </div>
        </div>
    `).join('');
}

function showAddBook() {
    showModal(`
        <h2>Yangi kitob</h2>
        <div class="form-group"><label>Nomi</label><input id="b-title"></div>
        <div class="form-group"><label>Muallif</label><input id="b-author"></div>
        <div class="form-group"><label>Kategoriya</label><select id="b-cat">${CATEGORIES.map(c => `<option>${c}</option>`).join('')}</select></div>
        <div class="form-group"><label>Tavsif</label><textarea id="b-desc" rows="3"></textarea></div>
        <div class="form-group"><label>Matn</label><textarea id="b-text" rows="4"></textarea></div>
        <div class="form-group"><label>Muqova rasm (kichik bo‘lsin)</label><input type="file" id="b-cover" accept="image/*"></div>
        <button class="btn-primary" onclick="saveNewBook()">Saqlash</button>
    `);
}

function saveNewBook() {
    const title = document.getElementById('b-title').value.trim();
    const author = document.getElementById('b-author').value.trim();
    if (!title) return alert('Nom kiriting');
    const newBook = {
        id: Date.now(),
        title,
        author,
        category: document.getElementById('b-cat').value,
        description: document.getElementById('b-desc').value,
        text: document.getElementById('b-text').value || 'Demo matn',
        cover: 'assets/hp2ve.jpg',
        isDemo: true
    };
    const file = document.getElementById('b-cover').files[0];
    if (file) {
        if (file.size > 800000) return alert('Rasm juda katta (max ~800KB). Kichikroq rasm tanlang.');
        const reader = new FileReader();
        reader.onload = (e) => {
            newBook.cover = e.target.result;
            books.push(newBook);
            if (saveBooks()) {
                closeModal();
                alert('Kitob qo‘shildi!');
                navigateTo('admin');
            }
        };
        reader.readAsDataURL(file);
    } else {
        books.push(newBook);
        if (saveBooks()) {
            closeModal();
            alert('Kitob qo‘shildi!');
            navigateTo('admin');
        }
    }
}

function editBook(id) {
    const book = books.find(b => b.id == id);
    if (!book) return;
    showModal(`
        <h2>Tahrirlash: ${book.title}</h2>
        <div class="form-group"><label>Nomi</label><input id="e-title" value="${book.title}"></div>
        <div class="form-group"><label>Muallif</label><input id="e-author" value="${book.author}"></div>
        <div class="form-group"><label>Tavsif</label><textarea id="e-desc">${book.description}</textarea></div>
        <div class="form-group"><label>Matn</label><textarea id="e-text" rows="4">${book.text}</textarea></div>
        <div class="form-group"><label>Yangi muqova</label><input type="file" id="e-cover" accept="image/*"></div>
        <button class="btn-primary" onclick="updateBook(${id})">Yangilash</button>
    `);
}

function updateBook(id) {
    const book = books.find(b => b.id == id);
    if (!book) return;
    book.title = document.getElementById('e-title').value;
    book.author = document.getElementById('e-author').value;
    book.description = document.getElementById('e-desc').value;
    book.text = document.getElementById('e-text').value;
    const file = document.getElementById('e-cover').files[0];
    if (file) {
        if (file.size > 800000) return alert('Rasm juda katta.');
        const reader = new FileReader();
        reader.onload = (e) => {
            book.cover = e.target.result;
            if (saveBooks()) { closeModal(); navigateTo('admin'); }
        };
        reader.readAsDataURL(file);
    } else {
        if (saveBooks()) { closeModal(); navigateTo('admin'); }
    }
}

function deleteBook(id) {
    if (confirm('O‘chirishni tasdiqlaysizmi?')) {
        books = books.filter(b => b.id != id);
        saveBooks();
        navigateTo('admin');
    }
}

function showAddWeeklyTest() {
    showModal(`
        <h2>Haftalik test qo‘shish</h2>
        <div class="form-group"><label>Test nomi</label><input id="wt-title" placeholder="Masalan: 1-hafta testi"></div>
        <p>Savollar (har biri alohida):</p>
        <div id="questions-container">
            <div class="question-input">
                <input placeholder="Savol" class="q-text">
                <input placeholder="Variant 1" class="opt">
                <input placeholder="Variant 2" class="opt">
                <input placeholder="Variant 3" class="opt">
                <input type="number" placeholder="To‘g‘ri (0,1,2)" class="correct" min="0" max="2">
            </div>
        </div>
        <button class="btn-outline" onclick="addQuestionField()">+ Savol qo‘shish</button>
        <button class="btn-primary" style="margin-top: 10px;" onclick="saveWeeklyTest()">Saqlash</button>
    `);
}

function addQuestionField() {
    const container = document.getElementById('questions-container');
    container.innerHTML += `
        <div class="question-input" style="margin-top: 12px; border-top: 1px solid #EEE; padding-top: 12px;">
            <input placeholder="Savol" class="q-text">
            <input placeholder="Variant 1" class="opt">
            <input placeholder="Variant 2" class="opt">
            <input placeholder="Variant 3" class="opt">
            <input type="number" placeholder="To‘g‘ri (0,1,2)" class="correct" min="0" max="2">
        </div>
    `;
}

function saveWeeklyTest() {
    const title = document.getElementById('wt-title').value.trim();
    if (!title) return alert('Nom kiriting');
    const qDivs = document.querySelectorAll('.question-input');
    const questions = [];
    qDivs.forEach(div => {
        const q = div.querySelector('.q-text').value.trim();
        const opts = Array.from(div.querySelectorAll('.opt')).map(i => i.value.trim()).filter(Boolean);
        const correct = parseInt(div.querySelector('.correct').value);
        if (q && opts.length >= 2 && !isNaN(correct)) {
            questions.push({ q, options: opts, correct });
        }
    });
    if (questions.length === 0) return alert('Kamida 1 savol kiriting');
    let weekly = JSON.parse(localStorage.getItem(STORAGE_KEYS.WEEKLY_TESTS) || '[]');
    weekly.push({ title, questions, created: new Date().toISOString() });
    localStorage.setItem(STORAGE_KEYS.WEEKLY_TESTS, JSON.stringify(weekly));
    closeModal();
    alert('Haftalik test qo‘shildi!');
    navigateTo('admin');
}

function deleteWeekly(index) {
    if (!confirm('O‘chirish?')) return;
    let weekly = JSON.parse(localStorage.getItem(STORAGE_KEYS.WEEKLY_TESTS) || '[]');
    weekly.splice(index, 1);
    localStorage.setItem(STORAGE_KEYS.WEEKLY_TESTS, JSON.stringify(weekly));
    navigateTo('admin');
}

function showAddGift() {
    showModal(`
        <h2>Yangi sovg‘a</h2>
        <div class="form-group"><label>Nomi</label><input id="g-title"></div>
        <div class="form-group"><label>Tavsif</label><textarea id="g-desc" rows="2"></textarea></div>
        <div class="form-group"><label>Kerakli kitobcha soni</label><input type="number" id="g-points" min="1" value="5"></div>
        <div class="form-group"><label>Rasm</label><input type="file" id="g-image" accept="image/*"></div>
        <button class="btn-primary" onclick="saveGift()">Saqlash</button>
    `);
}

function saveGift() {
    const title = document.getElementById('g-title').value.trim();
    if (!title) return alert('Nom kiriting');
    const gift = {
        title,
        description: document.getElementById('g-desc').value,
        requiredPoints: parseInt(document.getElementById('g-points').value) || 5,
        image: ''
    };
    const file = document.getElementById('g-image').files[0];
    if (file) {
        if (file.size > 500000) return alert('Rasm katta.');
        const reader = new FileReader();
        reader.onload = (e) => {
            gift.image = e.target.result;
            let gifts = JSON.parse(localStorage.getItem(STORAGE_KEYS.GIFTS) || '[]');
            gifts.push(gift);
            localStorage.setItem(STORAGE_KEYS.GIFTS, JSON.stringify(gifts));
            closeModal();
            alert('Sovg‘a qo‘shildi!');
            navigateTo('admin');
        };
        reader.readAsDataURL(file);
    } else {
        let gifts = JSON.parse(localStorage.getItem(STORAGE_KEYS.GIFTS) || '[]');
        gifts.push(gift);
        localStorage.setItem(STORAGE_KEYS.GIFTS, JSON.stringify(gifts));
        closeModal();
        alert('Sovg‘a qo‘shildi!');
        navigateTo('admin');
    }
}

function deleteGift(index) {
    if (!confirm('O‘chirish?')) return;
    let gifts = JSON.parse(localStorage.getItem(STORAGE_KEYS.GIFTS) || '[]');
    gifts.splice(index, 1);
    localStorage.setItem(STORAGE_KEYS.GIFTS, JSON.stringify(gifts));
    navigateTo('admin');
}

// Auth functions (same as before, shortened for space)
function showAuthModal() {
    showModal(`
        <h2>Kirish / Ro‘yxatdan o‘tish</h2>
        <div style="margin-bottom: 16px;">
            <button class="btn-outline" onclick="showLoginForm()">Kirish</button>
            <button class="btn-outline" onclick="showRegisterForm()">Ro‘yxatdan o‘tish</button>
            <button class="btn-outline" onclick="showAdminLogin()">Admin</button>
        </div>
        <div id="auth-form"></div>
    `);
    showLoginForm();
}

function showLoginForm() {
    document.getElementById('auth-form').innerHTML = `
        <div class="form-group"><label>Ism</label><input id="login-name"></div>
        <div class="form-group"><label>Parol</label><input type="password" id="login-pass"></div>
        <button class="btn-primary" onclick="doLogin()">Kirish</button>
    `;
}

function showRegisterForm() {
    document.getElementById('auth-form').innerHTML = `
        <div class="form-group"><label>Ism</label><input id="reg-name"></div>
        <div class="form-group"><label>Parol</label><input type="password" id="reg-pass"></div>
        <div class="form-group"><label>Sinf</label><input id="reg-class" placeholder="7-A"></div>
        <button class="btn-primary" onclick="doRegister()">Ro‘yxatdan o‘tish</button>
    `;
}

function showAdminLogin() {
    document.getElementById('auth-form').innerHTML = `
        <div class="form-group"><label>Admin ism</label><input id="admin-name" value="Adminastor"></div>
        <div class="form-group"><label>Parol</label><input type="password" id="admin-pass"></div>
        <button class="btn-primary" onclick="doAdminLogin()">Admin kirish</button>
    `;
}

function doRegister() {
    const name = document.getElementById('reg-name').value.trim();
    const pass = document.getElementById('reg-pass').value;
    const cls = document.getElementById('reg-class').value;
    if (!name || !pass) return alert('To‘ldiring');
    let users = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    if (users.find(u => u.name === name)) return alert('Bu ism band');
    const user = { id: Date.now(), name, password: pass, class: cls };
    users.push(user);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    currentUser = user;
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    updateHeader();
    closeModal();
    alert('Muvaffaqiyatli!');
    navigateTo('profile');
}

function doLogin() {
    const name = document.getElementById('login-name').value.trim();
    const pass = document.getElementById('login-pass').value;
    let users = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    const user = users.find(u => u.name === name && u.password === pass);
    if (user) {
        currentUser = user;
        localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
        updateHeader();
        closeModal();
        navigateTo('profile');
    } else alert('Noto‘g‘ri ma’lumot');
}

function doAdminLogin() {
    const name = document.getElementById('admin-name').value;
    const pass = document.getElementById('admin-pass').value;
    if (name === ADMIN_CREDENTIALS.username && pass === ADMIN_CREDENTIALS.password) {
        currentUser = { id: 'admin', name: 'Administrator', isAdmin: true };
        isAdmin = true;
        localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(currentUser));
        updateHeader();
        closeModal();
        navigateTo('admin');
    } else alert('Noto‘g‘ri');
}

function logout() {
    currentUser = null;
    isAdmin = false;
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    updateHeader();
    navigateTo('home');
}

function showModal(html) {
    document.getElementById('modal-body').innerHTML = html + '<button class="btn-outline" style="margin-top: 16px; width:100%;" onclick="closeModal()">Yopish</button>';
    document.getElementById('modal').classList.add('active');
}

function closeModal() {
    document.getElementById('modal').classList.remove('active');
}

function searchBooks() {
    const q = document.getElementById('home-search')?.value || '';
    navigateTo('books');
    setTimeout(() => {
        const searchInput = document.getElementById('book-search');
        if (searchInput) {
            searchInput.value = q;
            filterBooks();
        }
    }, 100);
}

// Expose globals
window.navigateTo = navigateTo;
window.openBook = openBook;
window.openReader = openReader;
window.addToFavorites = addToFavorites;
window.saveProgress = saveProgress;
window.sendChat = sendChat;
window.clearChat = clearChat;
window.startDemoTest = startDemoTest;
window.startTestForBook = startTestForBook;
window.startWeeklyTest = startWeeklyTest;
window.filterByCategory = filterByCategory;
window.showAuthModal = showAuthModal;
window.logout = logout;
window.showAddBook = showAddBook;
window.saveNewBook = saveNewBook;
window.editBook = editBook;
window.updateBook = updateBook;
window.deleteBook = deleteBook;
window.showAddWeeklyTest = showAddWeeklyTest;
window.addQuestionField = addQuestionField;
window.saveWeeklyTest = saveWeeklyTest;
window.deleteWeekly = deleteWeekly;
window.showAddGift = showAddGift;
window.saveGift = saveGift;
window.deleteGift = deleteGift;
window.toggleLike = toggleLike;
window.addComment = addComment;
window.submitSuggestion = submitSuggestion;
window.deleteSuggestion = deleteSuggestion;
window.showLoginForm = showLoginForm;
window.showRegisterForm = showRegisterForm;
window.showAdminLogin = showAdminLogin;
window.doLogin = doLogin;
window.doRegister = doRegister;
window.doAdminLogin = doAdminLogin;
window.searchBooks = searchBooks;
window.closeModal = closeModal;
window.speakBook = speakBook;
window.stopSpeech = stopSpeech;
window.showCelebration = showCelebration;
window.playClickSound = playClickSound;
window.setProgress = setProgress;