# ZiyoKutub — AI bilan ishlaydigan elektron kutubxona (Premium v3)

**Quyi Chirchiq tumani 36-maktab** uchun IT, ta’lim va sun’iy intellekt loyihasi.

Shiori: “Har bir kitob — yangi imkoniyat.”

## Yangiliklar (Premium daraja)
- Premium UI va silliq animatsiyalar
- Tugmalar bosilganda qattiqroq ovoz
- 3 ta Jadidlar kitobi (Behbudiy, Avloniy, Fitrat) + batafsil matn
- Amir Temur tarix kitobi va Shum bola
- Sovg‘alar: Amir Temur kitobi (100 kitobcha), Ertak kitobi (25 kitobcha) — rasmlar bilan
- Barcha ma’lumotlar localStorage da saqlanadi (kirish, kitoblar, progress)

## Ishga tushirish
1. `index.html` faylini brauzerda oching.
2. Demo rejim — barcha funksiyalar localStorage orqali.

## Admin kirish
- Ism: **Adminastor**
- Parol: **ZiyoKutubAdmin123**

**ZiyoKutub jamoasi**

## Yangi premium xususiyatlar
- **Dark Mode**: Headerdagi 🌙/☀️ tugmasi orqali o‘tish. Tanlov saqlanadi.
- **Yaxshilangan ovozlar**: Click, kitob ochish, success, gift, theme switch ovozlari.
- **Animatsiyalar**: Hover, button press, badge pop, page transitions, dark mode smooth.


## Eng yangi xususiyatlar (WOW daraja)
- Saytga kirganda 'Mening O‘zbekistonim' fon musiqasi (assets/mening_ozbekistonim.mp3 faylini qo‘ying)
- Musiqa play/pause va ovoz balandligi tugmalari headerda
- ZiyoAI’da dumaloq ko‘k personaj (ko‘z va og‘iz animatsiyali). Yozganda kuladi va og‘zi harakatlanadi
- Yanada zo‘r tugma ovozlari va hover animatsiyalar (shine, float, wow enter)

