Place your 'Mening O‘zbekistonim' MP3 file here named mening_ozbekistonim.mp3
