# قواعد ProGuard/R8 الأساسية للمرحلة 1
# ملاحظة: قواعد Anti-Tampering و Hardening الإضافية تُضاف في مرحلة التحصين الأمني (3.4)

-keep class com.legalassistant.app.data.local.entity.** { *; }
-keepattributes *Annotation*

# SQLCipher
-keep class net.sqlcipher.** { *; }
-keep class net.sqlcipher.database.* { *; }
