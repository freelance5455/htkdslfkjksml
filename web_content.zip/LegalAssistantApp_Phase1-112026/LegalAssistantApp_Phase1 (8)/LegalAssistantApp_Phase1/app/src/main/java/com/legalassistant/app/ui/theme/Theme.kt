package com.legalassistant.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection

private val LegalLightColors = lightColorScheme(
    primary = Color(0xFF1B4332),   // أخضر داكن رصين يوحي بالثقة القانونية
    secondary = Color(0xFFB08968),
    background = Color(0xFFFAF9F6)
)

private val LegalDarkColors = darkColorScheme(
    primary = Color(0xFF52B788),
    secondary = Color(0xFFD4A373)
)

@Composable
fun LegalAssistantTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // فرض اتجاه RTL على كامل التطبيق بغض النظر عن لغة النظام
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = if (darkTheme) LegalDarkColors else LegalLightColors,
            typography = ArabicTypography,
            content = content
        )
    }
}
