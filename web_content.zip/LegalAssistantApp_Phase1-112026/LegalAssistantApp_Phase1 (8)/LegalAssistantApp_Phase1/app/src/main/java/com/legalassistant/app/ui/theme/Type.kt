package com.legalassistant.app.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * ملاحظة: نستخدم FontFamily.Default مؤقتاً.
 * الخطوة التالية (المرحلة 2): إضافة ملفات خط Tajawal/Cairo الفعلية
 * في res/font/ وربطها هنا لتحسين وضوح النصوص القانونية الطويلة.
 */
private val arabicFontFamily = FontFamily.Default

val ArabicTypography = Typography(
    bodyLarge = TextStyle(
        fontFamily = arabicFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 26.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = arabicFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 22.sp
    ),
    titleLarge = TextStyle(
        fontFamily = arabicFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp
    ),
    titleMedium = TextStyle(
        fontFamily = arabicFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp
    )
)
