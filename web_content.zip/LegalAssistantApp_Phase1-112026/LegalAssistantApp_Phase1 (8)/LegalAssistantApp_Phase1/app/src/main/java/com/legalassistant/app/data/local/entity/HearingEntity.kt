package com.legalassistant.app.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(
    tableName = "hearings",
    foreignKeys = [
        ForeignKey(
            entity = CaseEntity::class,
            parentColumns = ["id"],
            childColumns = ["caseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("caseId")]
)
data class HearingEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val caseId: String,
    val date: Long,
    val location: String,
    val reminderMinutesBefore: Int = 60,
    val notifyViaWhatsApp: Boolean = false, // قناة تنبيه إضافية — ميزة تنافسية من التحليل السابق
    val notes: String = ""
)
