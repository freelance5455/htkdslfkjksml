package com.legalassistant.app.ui.cases

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.legalassistant.app.data.local.entity.CaseEntity
import com.legalassistant.app.data.repository.CaseRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CaseListViewModel @Inject constructor(
    private val repository: CaseRepository
) : ViewModel() {

    private val searchQuery = MutableStateFlow("")

    val cases: StateFlow<List<CaseEntity>> = searchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) repository.getAllCases()
            else repository.searchCases(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun onSearchQueryChanged(query: String) {
        searchQuery.value = query
    }

    fun saveCase(case: CaseEntity) {
        viewModelScope.launch { repository.saveCase(case) }
    }

    fun deleteCase(case: CaseEntity) {
        viewModelScope.launch { repository.deleteCase(case) }
    }
}
