package com.legalassistant.app.di

import android.content.Context
import com.legalassistant.app.data.local.dao.CaseDao
import com.legalassistant.app.data.local.dao.HearingDao
import com.legalassistant.app.data.local.db.AppDatabase
import com.legalassistant.app.security.SecureStorageManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideSecureStorageManager(@ApplicationContext context: Context): SecureStorageManager =
        SecureStorageManager(context)

    @Provides
    @Singleton
    fun provideAppDatabase(
        @ApplicationContext context: Context,
        secureStorageManager: SecureStorageManager
    ): AppDatabase = AppDatabase.build(context, secureStorageManager)

    @Provides
    fun provideCaseDao(db: AppDatabase): CaseDao = db.caseDao()

    @Provides
    fun provideHearingDao(db: AppDatabase): HearingDao = db.hearingDao()
}
