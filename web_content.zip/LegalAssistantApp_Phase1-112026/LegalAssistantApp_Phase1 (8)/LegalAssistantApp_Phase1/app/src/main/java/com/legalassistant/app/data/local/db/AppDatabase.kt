package com.legalassistant.app.data.local.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.legalassistant.app.data.local.dao.CaseDao
import com.legalassistant.app.data.local.dao.HearingDao
import com.legalassistant.app.data.local.entity.CaseEntity
import com.legalassistant.app.data.local.entity.HearingEntity
import com.legalassistant.app.security.SecureStorageManager
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SupportFactory

@Database(
    entities = [CaseEntity::class, HearingEntity::class],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun caseDao(): CaseDao
    abstract fun hearingDao(): HearingDao

    companion object {
        private const val DB_NAME = "legal_assistant_encrypted.db"

        fun build(context: Context, secureStorageManager: SecureStorageManager): AppDatabase {
            // تحميل مكتبة SQLCipher الأصلية
            SQLiteDatabase.loadLibs(context)

            val passphrase = secureStorageManager.getOrCreateDatabasePassphrase()
            val factory = SupportFactory(SQLiteDatabase.getBytes(passphrase))

            return Room.databaseBuilder(context, AppDatabase::class.java, DB_NAME)
                .openHelperFactory(factory)
                .fallbackToDestructiveMigration() // يُستبدل بخطة Migration حقيقية بعد المرحلة 1
                .build()
        }
    }
}
