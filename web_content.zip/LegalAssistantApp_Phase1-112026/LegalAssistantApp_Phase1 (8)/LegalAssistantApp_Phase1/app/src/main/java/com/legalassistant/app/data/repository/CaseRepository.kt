package com.legalassistant.app.data.repository

import com.legalassistant.app.data.local.dao.CaseDao
import com.legalassistant.app.data.local.entity.CaseEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CaseRepository @Inject constructor(
    private val caseDao: CaseDao
) {
    fun getAllCases(): Flow<List<CaseEntity>> = caseDao.getAllCases()

    fun searchCases(query: String): Flow<List<CaseEntity>> = caseDao.searchCases(query)

    suspend fun getCaseById(id: String): CaseEntity? = caseDao.getCaseById(id)

    suspend fun saveCase(case: CaseEntity) = caseDao.upsertCase(case)

    suspend fun deleteCase(case: CaseEntity) = caseDao.deleteCase(case)
}
