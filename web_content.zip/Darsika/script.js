// ============ دیتای پیش‌فرض ============
let data = JSON.parse(localStorage.getItem("studyData")) || defaultData();
let purchases = JSON.parse(localStorage.getItem("purchases")) || []; // آرایه اطلاعات کامل
let current = { grade: null, lesson: null };

// اگه دیتا خالیه، مقادیر نمونه بساز
if (!localStorage.getItem("studyData")) {
  localStorage.setItem("studyData", JSON.stringify(data));
}

function defaultData() {
  return {
    7: {
      "ریاضی": { chapters: [
        { title: "فصل ۱: راهبردهای حل مسئله", content: "📘 راهبردهای حل مسئله:\n\n۱. رسم شکل\n۲. الگوسازی\n۳. حذف حالت‌های نامطلوب\n۴. زیرمسئله‌سازی\n\n(این فصل رایگان است)", free: true },
        { title: "فصل ۲: عددهای صحیح", content: "محتوای این فصل پس از خرید نمایش داده می‌شود.", free: false },
        { title: "فصل ۳: جبر و معادله", content: "محتوای این فصل پس از خرید نمایش داده می‌شود.", free: false }
      ]},
      "علوم": { chapters: [
        { title: "فصل ۱: تجربه و تفکر", content: "📗 علوم تجربی هفتم\n\nفصل اول: تجربه و تفکر\n(رایگان)", free: true },
        { title: "فصل ۲: اندازه‌گیری", content: "محتوای پولی", free: false }
      ]},
      "فارسی": { chapters: [
        { title: "فصل ۱: ستایش", content: "📕 فارسی هفتم - فصل اول (رایگان)", free: true }
      ]}
    },
    8: {
      "ریاضی": { chapters: [
        { title: "فصل ۱: عددهای صحیح", content: "📘 ریاضی هشتم - فصل اول (رایگان)", free: true },
        { title: "فصل ۲: عددهای اول", content: "محتوای پولی", free: false }
      ]}
    },
    9: {
      "ریاضی": { chapters: [
        { title: "فصل ۱: مجموعه‌ها", content: "📘 ریاضی نهم - فصل اول (رایگان)", free: true }
      ]},
      "علوم": { chapters: [
        { title: "فصل ۱: مواد و نقش آنها", content: "📗 علوم نهم - فصل اول (رایگان)", free: true }
      ]}
    }
  };
}

// ============ راه‌اندازی ============
document.addEventListener("DOMContentLoaded", () => {
  loadTheme();
  updateStats();
});

// ============ ناوبری ============
function showScreen(id, el) {
  document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
  document.getElementById(id).classList.add("active");
  if (el) {
    document.querySelectorAll(".nav-item").forEach(n => n.classList.remove("active"));
    el.classList.add("active");
  }
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function goBack(id) {
  showScreen(id);
}

function selectGrade(g) {
  current.grade = g;
  document.getElementById("gradeTitle").textContent = "📖 پایه " + numToFa(g);
  const lessons = Object.keys(data[g] || {});
  const list = document.getElementById("lessonList");
  list.innerHTML = "";

  if (lessons.length === 0) {
    list.innerHTML = '<div class="empty-state"><span class="emoji">📭</span>هنوز درسی اضافه نشده</div>';
  }

  const emojiMap = { "ریاضی": "🔢", "علوم": "🔬", "فارسی": "📖", "عربی": "🕌", "انگلیسی": "🌍", "مطالعات": "🗺️", "قرآن": "📗", "کاروفناوری": "🛠️", "تفکر": "💡", "هنر": "🎨", "تربیت": "🕊️", "ورزش": "⚽", "املا": "✍️" };
  const bgMap = ["#6a11cb", "#2575fc", "#ff6a88", "#f5576c", "#4facfe", "#22c55e", "#f59e0b"];

  lessons.forEach((name, idx) => {
    const d = document.createElement("div");
    d.className = "lesson-card";
    const emoji = emojiMap[name] || "📚";
    const count = data[g][name].chapters.length;
    d.innerHTML = `
      <span class="lesson-emoji">${emoji}</span>
      <h4>${name}</h4>
      <p>${count} فصل</p>
    `;
    d.onclick = () => selectLesson(name);
    list.appendChild(d);
  });
  showScreen("lessonScreen");
}

function selectLesson(name) {
  current.lesson = name;
  document.getElementById("lessonTitle").textContent = "📖 " + name + " - پایه " + numToFa(current.grade);
  const chapters = data[current.grade][name].chapters;
  const list = document.getElementById("chapterList");
  list.innerHTML = "";

  if (chapters.length === 0) {
    list.innerHTML = '<div class="empty-state"><span class="emoji">📭</span>هنوز فصلی اضافه نشده</div>';
  }

  chapters.forEach((ch, i) => {
    const key = current.grade + "|" + name + "|" + i;
    const isFree = ch.free || i === 0;
    const bought = purchases.some(p => p.key === key);
    const unlocked = isFree || bought;

    const div = document.createElement("div");
    div.className = "chapter-item " + (unlocked ? "free" : "locked");
    div.innerHTML = `
      <div class="chapter-info">
        <h4>${ch.title}</h4>
        <span class="badge ${unlocked ? "free" : "locked"}">${unlocked ? "✅ باز" : "🔒 قفل"}</span>
      </div>
      <button class="chapter-btn">${unlocked ? "مطالعه" : "خرید"}</button>
    `;
    div.querySelector("button").onclick = () => {
      if (unlocked) openChapter(i);
      else openPayModal(i, key, ch.title);
    };
    list.appendChild(div);
  });
  showScreen("chapterScreen");
}

function openChapter(i) {
  const ch = data[current.grade][current.lesson].chapters[i];
  document.getElementById("chapterTitle").textContent = ch.title;
  document.getElementById("chapterContent").textContent = ch.content;
  showScreen("contentScreen");
}

// ============ پرداخت ============
let pendingPay = null;

function openPayModal(i, key, title) {
  pendingPay = { i, key, title };
  document.getElementById("payInfo").textContent = title;
  document.getElementById("payModal").classList.add("show");
}

function closeModal() {
  document.getElementById("payModal").classList.remove("show");
  pendingPay = null;
}

function confirmPayment() {
  showToast("⏳ در حال اتصال به درگاه...");

  // شبیه‌سازی پرداخت
  setTimeout(() => {
    if (!purchases.some(p => p.key === pendingPay.key)) {
      const record = {
        key: pendingPay.key,
        grade: current.grade,
        lesson: current.lesson,
        title: pendingPay.title,
        price: 10000,
        date: new Date().toISOString()
      };
      purchases.push(record);
      localStorage.setItem("purchases", JSON.stringify(purchases));
    }
    const idx = pendingPay.i;
    closeModal();
    showToast("✅ پرداخت با موفقیت انجام شد!");
    updateStats();
    setTimeout(() => openChapter(idx), 400);
    selectLesson(current.lesson);
  }, 1200);
}

// ============ تاریخچه خرید ============
function showPurchaseHistory() {
  const list = document.getElementById("historyList");
  list.innerHTML = "";

  if (purchases.length === 0) {
    list.innerHTML = `
      <div class="empty-state">
        <span class="emoji">🛍️</span>
        هنوز خریدی انجام ندادی<br>
        <small>با خرید فصل‌ها به جزوه‌های کامل دسترسی پیدا می‌کنی</small>
      </div>
    `;
  } else {
    // مرتب‌سازی از جدید به قدیم
    const sorted = [...purchases].sort((a,b) => new Date(b.date) - new Date(a.date));
    sorted.forEach(p => {
      const div = document.createElement("div");
      div.className = "history-item";
      div.innerHTML = `
        <div class="history-icon">✅</div>
        <div class="history-info">
          <h4>${p.lesson} - پایه ${numToFa(p.grade)}</h4>
          <p>${p.title}</p>
          <p style="font-size:10px;margin-top:4px;">📅 ${formatDate(p.date)}</p>
        </div>
        <div class="history-price">${numToFa(p.price.toLocaleString())} تومان</div>
      `;
      list.appendChild(div);
    });
  }
  showScreen("historyScreen");
  document.querySelectorAll(".nav-item").forEach(n => n.classList.remove("active"));
  document.querySelectorAll(".nav-item")[1].classList.add("active");
}

function formatDate(iso) {
  const d = new Date(iso);
  const fa = ["فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"];
  // تبدیل ساده به تاریخ شمسی (تقریبی)
  const g = d.toLocaleDateString("fa-IR");
  return g + " - " + d.toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" });
}

// ============ درباره ============
function showAbout() {
  showScreen("aboutScreen");
}

// ============ آمار ============
function updateStats() {
  let lessons = 0, chapters = 0;
  [7,8,9].forEach(g => {
    if (data[g]) {
      lessons += Object.keys(data[g]).length;
      Object.values(data[g]).forEach(l => chapters += l.chapters.length);
    }
  });
  document.getElementById("statLessons").textContent = numToFa(lessons);
  document.getElementById("statChapters").textContent = numToFa(chapters);
  document.getElementById("statPurchases").textContent = numToFa(purchases.length);
}

// ============ تم ============
function toggleTheme() {
  document.body.classList.toggle("dark");
  const isDark = document.body.classList.contains("dark");
  document.getElementById("themeIcon").textContent = isDark ? "☀️" : "🌙";
  localStorage.setItem("theme", isDark ? "dark" : "light");
}

function loadTheme() {
  const saved = localStorage.getItem("theme");
  if (saved === "dark" || (!saved && window.matchMedia("(prefers-color-scheme: dark)").matches)) {
    document.body.classList.add("dark");
    document.getElementById("themeIcon").textContent = "☀️";
  }
}

// ============ Toast ============
function showToast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove("show"), 2500);
}

// ============ ابزار ============
function numToFa(n) {
  const fa = ["۰","۱","۲","۳","۴","۵","۶","۷","۸","۹"];
  return String(n).split("").map(c => fa[+c] || c).join("");
}

// بارگذاری مجدد بعد از برگشت از پنل ادمین
window.addEventListener("focus", () => {
  data = JSON.parse(localStorage.getItem("studyData")) || defaultData();
  updateStats();
});