BABY MILK TRACKER — SIMPLE INSTALLABLE WEB APP

Included:
- index.html: the app
- manifest.json: install metadata
- sw.js: offline cache for supported browsers
- icon-192.png and icon-512.png: app icons

IMPORTANT:
This is a small browser-based app, not a compiled native Android APK. It has not been compiled as an APK. The source is provided so it can be hosted and installed as an app-like shortcut.

EASIEST WAY TO GET A HOME-SCREEN ICON:
1. On a computer, unzip this folder.
2. Upload the contents of this folder to a static HTTPS hosting service that supports a simple website (for example, Netlify Drop, or another hosting provider you trust). Upload the folder contents, not the ZIP itself, and ensure index.html is at the site root.
3. Open the resulting HTTPS website address in Chrome on your Android phone.
4. Tap Chrome's three-dot menu (⋮).
5. Tap "Install app" if offered, or "Add to Home screen".
6. Confirm. An icon should appear on the home screen or in the app drawer. Tap it to open the tracker.
7. Open the app once while online so it can cache the files; after that, its interface can work offline.

DATA WARNING:
Feeding records are stored in browser local storage on that device/browser. They are not automatically synced to the hosting service or another phone. Use Reports > Download full backup (JSON) regularly. Do not clear the browser's site data. If the app is installed from one website URL, keep using the same URL to access the same records.

HOW TO USE:
- Choose Mother's milk or Formula milk.
- Tap +10, +30, +60, or +90, or type a custom quantity.
- Optional: open More details to change time or add notes.
- Tap Save feed.
- History allows editing/deleting records; Reports shows daily summaries and export; Profile stores baby's nickname and date of birth.

LIMITATIONS:
- This version includes milk records, daily totals, history, editing/deleting, basic reports, CSV/JSON export/restore, baby profile, and a simple diaper log.
- Reminder notifications, PDF reports, growth charts, and a native Android APK are not included.
- Browser storage is not as robust as a native database. Export backups regularly.
- This app is a record-keeping tool, not medical advice.
