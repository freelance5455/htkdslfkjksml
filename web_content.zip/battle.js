var mv={x:0,y:0},aim=0,drg=0,rev=0,jm=document.getElementById("jm"),km=document.getElementById("km"),js=document.getElementById("js"),ks=document.getElementById("ks");
function autoAim(){
  var bd=460,tx=null,ty=null;
  bot.forEach(function(o){var d=Math.hypot(o.x-p.x,o.y-p.y),h=bus.some(function(b){return Math.hypot(o.x-b.x,o.y-b.y)<50});if(d<bd&&(!h||d<75)){bd=d;tx=o.x;ty=o.y}});
  if(tx===null&&p2&&p2.hp>0&&(!p2.b||Math.hypot(p2.x-p.x,p2.y-p.y)<75)){var d2=Math.hypot(p2.x-p.x,p2.y-p.y);if(d2<bd){bd=d2;tx=p2.x;ty=p2.y}}
  if(tx===null)box.forEach(function(x){var d=Math.hypot(x.x+20-p.x,x.y+20-p.y);if(d<bd){bd=d;tx=x.x+20;ty=x.y+20}});
  if(tx!==null)p.a=Math.atan2(ty-p.y,tx-p.x);
}
function joy(el,kb,s){
  el.ontouchstart=function(e){e.preventDefault();if(!run||paused)return;if(s){aim=1;drg=0}var t=e.targetTouches.item(0),r=el.getBoundingClientRect(),dx=t.clientX-(r.left+r.width/2),dy=t.clientY-(r.top+r.height/2),d=Math.hypot(dx,dy);if(!s&&d>5){mv={x:dx/35,y:dy/35};if(!aim)p.a=Math.atan2(dy,dx)}};
  el.ontouchmove=function(e){e.preventDefault();if(!run||paused)return;var t=e.targetTouches.item(0),r=el.getBoundingClientRect(),dx=t.clientX-(r.left+r.width/2),dy=t.clientY-(r.top+r.height/2),d=Math.hypot(dx,dy);if(d>35){dx=dx/d*35;dy=dy/d*35}kb.style.transform="translate("+dx+"px,"+dy+"px)";if(s){if(d>10){drg=1;p.a=Math.atan2(dy,dx)}}else{mv={x:dx/35,y:dy/35};if(!aim&&d>5)p.a=Math.atan2(dy,dx)}};
  el.ontouchend=function(e){e.preventDefault();kb.style.transform="translate(0,0)";if(s){if(aim&&run&&!paused){if(!drg)autoAim();shoot()}aim=0;drg=0}else mv={x:0,y:0}};
}
joy(jm,km,0);joy(js,ks,1);

function wpnSfx(){var w=Math.min(4,p.wpn);if(w==1){if(p.type==0)sfx(440,130,.12,"square",.12);else if(p.type==1)sfx(820,340,.08,"triangle",.12);else if(p.type==2)sfx(180,55,.22,"sawtooth",.16);else if(p.type==3)sfx(1200,400,.1,"sine",.14);else sfx(600,900,.18,"triangle",.14)}else if(w==2){sfx(950,260,.14,"sawtooth",.13);setTimeout(function(){sfx(1200,480,.09,"sine",.08)},35)}else if(w==3){sfx(1350,320,.15,"square",.12);setTimeout(function(){sfx(1600,420,.12,"triangle",.11)},45)}else{sfx(220,45,.28,"sawtooth",.18);sfx(1500,190,.22,"square",.12)}}
function shoot(){if(p.am<1||!run||paused)return;p.am--;rev=90;wpnSfx();var mult=1+(p.wpn-1)*.35,d=(p.dmg+p.cb*55)*mult,wCol=p.wpn>=3?"#00d2d3":(p.wpn==2?"#ff6b81":"#ff9f43"),nb=[];
  if(p.type==0){var angs=p.wpn>=3?new Array(-.22,-.11,0,.11,.22):new Array(-.13,0,.13);angs.forEach(function(s){nb.push({x:p.x+Math.cos(p.a)*25,y:p.y+Math.sin(p.a)*25,vx:Math.cos(p.a+s)*(13+p.wpn),vy:Math.sin(p.a+s)*(13+p.wpn),d:d,p:1,s:p.fu>0,l:32+p.wpn*2,r:6+Math.min(3,p.wpn-1),col:wCol})})}
  else if(p.type==1){var n=Math.min(5,1+p.wpn);for(var k=0;k<n;k++)nb.push({x:p.x+Math.cos(p.a)*(25+k*13),y:p.y+Math.sin(p.a)*(25+k*13),vx:Math.cos(p.a)*(16+p.wpn),vy:Math.sin(p.a)*(16+p.wpn),d:d,p:1,s:p.fu>0,l:30+p.wpn*2,r:5+Math.min(3,p.wpn-1),col:wCol})}
  else if(p.type==2){nb.push({x:p.x+Math.cos(p.a)*25,y:p.y+Math.sin(p.a)*25,vx:Math.cos(p.a)*(10+p.wpn),vy:Math.sin(p.a)*(10+p.wpn),d:d,p:1,s:p.fu>0,l:38+p.wpn*2,r:11+Math.min(5,p.wpn*2),col:wCol})}
  else if(p.type==3){new Array(-.06,.06).forEach(function(off){nb.push({x:p.x+Math.cos(p.a)*25,y:p.y+Math.sin(p.a)*25,vx:Math.cos(p.a+off)*(18+p.wpn),vy:Math.sin(p.a+off)*(18+p.wpn),d:d,p:1,s:p.fu>0,l:35+p.wpn*2,r:5,col:"#00a8ff"})})}
  else{new Array(-.18,0,.18).forEach(function(off){nb.push({x:p.x+Math.cos(p.a)*25,y:p.y+Math.sin(p.a)*25,vx:Math.cos(p.a+off)*(11+p.wpn),vy:Math.sin(p.a+off)*(11+p.wpn),d:d,p:1,s:p.fu>0,l:36+p.wpn*2,r:9,col:"#e056fd"})})}
  nb.forEach(function(b){bul.push(b)});if(isOnline&&conn){var rem=nb.map(function(b){return{x:b.x,y:b.y,vx:b.vx,vy:b.vy,d:b.d,p:0,s:b.s,l:b.l,r:b.r,col:"#00a8ff"}});conn.send({t:"bul",b:rem})}
}
function furia(){
  if(p.sp>=100&&run&&!paused){
    p.sp=0;p.fu=300;rev=90;
    sfx(250,900,.35,"sawtooth",.18);
    document.getElementById("sup").className="";
    if(p.type==1||p.type==4){p.hp=Math.min(p.mhp,p.hp+(p.type==4?p.mhp:1600));sfx(600,1200,.25,"sine",.2)}
    var nb=[];
    for(var k=0;k<12;k++){
      var a=k*.52;
      nb.push({x:p.x,y:p.y,vx:Math.cos(a)*14,vy:Math.sin(a)*14,d:750+p.wpn*150,p:1,s:1,l:30,r:p.type==2?13:8,col:"#fbc531"});
    }
    nb.forEach(function(b){bul.push(b)});
    if(isOnline&&conn){
      var rem=nb.map(function(b){return{x:b.x,y:b.y,vx:b.vx,vy:b.vy,d:b.d,p:0,s:1,l:30,r:8,col:"#00a8ff"}});
      conn.send({t:"bul",b:rem});
    }
  }
}

function hitW(x,y){if(x<24||x>M-24||y<24||y>M-24)return 1;for(var i=0;i<wal.length;i++)if(x+18>wal.at(i).x&&x-18<wal.at(i).x+70&&y+18>wal.at(i).y&&y-18<wal.at(i).y+70)return 1;return 0}
function outSafe(x,y){return Math.abs(x-st.x)>st.r||Math.abs(y-st.y)>st.r}
function sepCats(){var all=[p].concat(bot);if(p2&&p2.hp>0)all.push(p2);for(var i=0;i<all.length;i++)for(var j=i+1;j<all.length;j++){var a=all.at(i),b=all.at(j),minD=(a.boss||b.boss)?52:38,dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy);if(d<minD){if(d<.1){dx=1;dy=0;d=1}var ov=(minD-d)/2,nx=(dx/d)*ov,ny=(dy/d)*ov;if(!hitW(a.x-nx,a.y))a.x-=nx;if(!hitW(a.x,a.y-ny))a.y-=ny;if(!hitW(b.x+nx,b.y))b.x+=nx;if(!hitW(b.x,b.y+ny))b.y+=ny}}}

var netTick=0;
setInterval(function(){
  if(over||!run||paused)return;
  if(p.hp<=0){over=1;sfx(250,80,.4,"sine",.2);setTimeout(function(){alert("MIAO... SCONFITTO AL LIVELLO "+lvl+"!");location.reload()},80);return}
  var p2Alive=isOnline&&p2&&p2.hp>0;
  if(bot.length==0&&!p2Alive){run=0;sfx(400,900,.35,"sine",.2);var nw=WPN_NAMES.at(Math.min(3,p.wpn));document.getElementById("nxtTitle").innerText="LIVELLO "+lvl+" COMPLETATO!";document.getElementById("nxtDesc").innerText="Sbloccata: "+nw+" Lv."+(p.wpn+1)+" (+35% Danno, +400 Vita)!";document.getElementById("scrNext").style.display="flex";return}
  if(p.fu>0)p.fu--;if(rev>0)rev--;if(p.am<3&&++p.rt>(p.fu>0?p.rel*.55:Math.max(25,p.rel-p.wpn*2))){p.am++;p.rt=0}
  var spd=p.fu>0?p.spd*1.45:p.spd,nx=p.x+mv.x*spd,ny=p.y+mv.y*spd;
  if(!hitW(nx,p.y))p.x=nx;if(!hitW(p.x,ny))p.y=ny;
  var inBush=bus.some(function(b){return Math.hypot(p.x-b.x,p.y-b.y)<50});
  p.b=(inBush&&rev<=0)?1:0;
  if(st.r>120)st.r-=(.15+Math.min(.25,lvl*.025));if(outSafe(p.x,p.y))p.hp-=(10+lvl*3);
  for(var i=cub.length-1;i>=0;i--){if(Math.hypot(p.x-cub.at(i).x,p.y-cub.at(i).y)<35){p.cb++;tunaBank++;saveAll();p.mhp+=300;p.hp=Math.min(p.mhp,p.hp+500);sfx(520,880,.15,"sine",.15);cub.splice(i,1);continue}for(var j=0;j<bot.length;j++)if(Math.hypot(bot.at(j).x-cub.at(i).x,bot.at(j).y-cub.at(i).y)<35){bot.at(j).cb++;bot.at(j).mhp+=600;bot.at(j).hp=Math.min(bot.at(j).mhp,bot.at(j).hp+800);cub.splice(i,1);break}}
  for(var i=fish.length-1;i>=0;i--){if(Math.hypot(p.x-fish.at(i).x,p.y-fish.at(i).y)<35){p.hp=Math.min(p.mhp,p.hp+1300);sfx(650,1100,.18,"sine",.18);fish.splice(i,1)}}
  for(var i=bul.length-1;i>=0;i--){var b=bul.at(i);b.x+=b.vx;b.y+=b.vy;b.l--;var rm=b.l<=0;for(var w=0;w<wal.length;w++)if(b.x>wal.at(w).x&&b.x<wal.at(w).x+70&&b.y>wal.at(w).y&&b.y<wal.at(w).y+70){rm=1;break}for(var x=box.length-1;x>=0;x--)if(!rm&&b.x>box.at(x).x&&b.x<box.at(x).x+40&&b.y>box.at(x).y&&b.y<box.at(x).y+40){box.at(x).hp-=b.d;sfx(150,90,.07,"triangle",.08);if(box.at(x).hp<=0){if(Math.random()<.5)fish.push({x:box.at(x).x+20,y:box.at(x).y+20});else cub.push({x:box.at(x).x+20,y:box.at(x).y+20});box.splice(x,1)}rm=1;break}if(!rm&&b.p){for(var k=bot.length-1;k>=0;k--)if(Math.hypot(b.x-bot.at(k).x,b.y-bot.at(k).y)<(bot.at(k).boss?40:26)){bot.at(k).hp-=b.d;sfx(300,150,.08,"square",.1);if(p.fu<=0){p.sp=Math.min(100,p.sp+12);if(p.sp>=100)document.getElementById("sup").className="ok"}if(bot.at(k).hp<=0){cub.push({x:bot.at(k).x,y:bot.at(k).y});bot.splice(k,1);sfx(400,100,.25,"sawtooth",.15)}rm=1;break}if(!rm&&p2Alive&&Math.hypot(b.x-p2.x,b.y-p2.y)<24){sfx(300,150,.08,"square",.1);if(p.fu<=0){p.sp=Math.min(100,p.sp+12);if(p.sp>=100)document.getElementById("sup").className="ok"}rm=1}}else if(!rm&&Math.hypot(b.x-p.x,b.y-p.y)<24){var sh=(p.type==2&&p.fu>0)?.25:(p.fu>0?.5:1);p.hp-=b.d*sh;rev=60;sfx(140,60,.1,"sawtooth",.14);rm=1}if(rm)bul.splice(i,1)}
  if((!isOnline||isHost)&&Math.random()<(0.008+lvl*0.002)&&met.length<3){
    var mx=st.x+(Math.random()*2-1)*(st.r-80);
    var my=st.y+(Math.random()*2-1)*(st.r-80);
    met.push({x:mx,y:my,r:75,t:85,maxT:85});
  }
  for(var i=met.length-1;i>=0;i--){
    var m=met.at(i);m.t--;
    if(m.t<=0){
      sfx(140,40,.35,"sawtooth",.22);
      if(Math.hypot(p.x-m.x,p.y-m.y)<m.r){p.hp-=650;rev=60}
      bot.forEach(function(o){if(Math.hypot(o.x-m.x,o.y-m.y)<m.r)o.hp-=850});
      for(var x=box.length-1;x>=0;x--)if(Math.hypot(box.at(x).x+20-m.x,box.at(x).y+20-m.y)<m.r)box.splice(x,1);
      var nDrop=2+Math.floor(Math.random()*2);
      for(var d=0;d<nDrop;d++){
        var ang=Math.random()*6.28,dist=15+Math.random()*35;
        pup.push({x:m.x+Math.cos(ang)*dist,y:m.y+Math.sin(ang)*dist,tp:Math.floor(Math.random()*3)});
      }
      met.splice(i,1);
    }
  }

  for(var i=pup.length-1;i>=0;i--){
    var u=pup.at(i);
    if(Math.hypot(p.x-u.x,p.y-u.y)<36){
      sfx(580,1150,.18,"sine",.18);
      if(u.tp==0){p.cb+=2;p.fu=Math.max(p.fu,120)}
      else if(u.tp==1){p.mhp+=350;p.hp=Math.min(p.mhp,p.hp+900)}
      else{p.sp=Math.min(100,p.sp+50);if(p.sp>=100)document.getElementById("sup").className="ok"}
      pup.splice(i,1);continue;
    }
    for(var j=0;j<bot.length;j++){
      var o=bot.at(j);
      if(Math.hypot(o.x-u.x,o.y-u.y)<36){
        if(u.tp==0)o.cb+=2;
        else if(u.tp==1){o.mhp+=500;o.hp=Math.min(o.mhp,o.hp+1000)}
        else o.ls=0;
        pup.splice(i,1);break;
      }
    }
  }

  var now=Date.now(),bossObj=null;
  if(!isOnline||isHost){for(var k=bot.length-1;k>=0;k--){var o=bot.at(k),dp=Math.hypot(p.x-o.x,p.y-o.y),canSee=(!p.b||dp<95);if(o.boss)bossObj=o;var moveAng=o.a;if(outSafe(o.x,o.y)){o.hp-=10;o.a=moveAng=Math.atan2(st.y-o.y,st.x-o.x)}else if(dp<(o.boss?560:460)&&canSee){var bVel=(o.boss?13:11.5)+Math.min(4,lvl*.35);var lead=(lvl>1)?(dp/bVel):0;o.a=Math.atan2((p.y+mv.y*spd*lead)-(o.y),(p.x+mv.x*spd*lead)-(o.x));if(lvl>=2&&dp<320){if(--o.mt<=0){o.stf=-o.stf;o.mt=45}moveAng=o.a+(o.stf*1.1)}else{moveAng=o.a}var cd=o.boss?Math.max(480,820-lvl*35):Math.max(450,1150-lvl*85);if(now-o.ls>cd){o.ls=now;var angs=o.boss?(lvl>=4?new Array(-.42,-.28,-.14,0,.14,.28,.42):new Array(-.32,-.16,0,.16,.32)):(lvl>=4?new Array(-.18,0,.18):(lvl>=2?new Array(-.11,.11):Array.of(0)));angs.forEach(function(off){bul.push({x:o.x+Math.cos(o.a)*30,y:o.y+Math.sin(o.a)*30,vx:Math.cos(o.a+off)*bVel,vy:Math.sin(o.a+off)*bVel,d:(o.boss?650:420)+o.cb*75,p:0,s:0,l:38,r:o.boss?9:5.5,col:o.boss?"#e84118":"#ff7675"})})}}else if(--o.mt<=0){o.a=Math.random()*6.28;moveAng=o.a;o.mt=75}var bspd=o.boss?Math.min(3.5,2.4+lvl*.12):Math.min(4.5,2.6+lvl*.22),bx=o.x+Math.cos(moveAng)*bspd,by=o.y+Math.sin(moveAng)*bspd;if(!hitW(bx,o.y))o.x=bx;else{o.a+=1.5;o.stf=-o.stf}if(!hitW(o.x,by))o.y=by;else{o.a+=1.5;o.stf=-o.stf}if(o.hp<=0){cub.push({x:o.x,y:o.y});bot.splice(k,1)}}}else{bot.forEach(function(o){if(o.boss)bossObj=o})}
  if(isOnline&&conn&&++netTick%2==0){var pkt={t:"p",p:{x:p.x,y:p.y,a:p.a,hp:p.hp,mhp:p.mhp,col:p.col,helm:p.helm,acc:p.acc,type:p.type,wpn:p.wpn,b:p.b}};if(isHost){pkt.bot=bot;pkt.box=box;pkt.cub=cub;pkt.fish=fish;pkt.met=met;pkt.pup=pup;pkt.sr=st.r}conn.send(pkt)}
  document.getElementById("bossHud").style.display=bossObj?"flex":"none";if(bossObj)document.getElementById("bossBar").style.width=(bossObj.hp/bossObj.mhp*100)+"%";
  sepCats();drwMM();
  document.getElementById("cb").innerText=tunaBank;document.getElementById("al").innerText=bot.length+1+(p2Alive?1:0);

  ctx.clearRect(0,0,W,H);ctx.save();ctx.translate(W/2-p.x,H/2-p.y);
  ctx.fillStyle=BG_COLS.at((lvl-1)%BG_COLS.length);ctx.fillRect(0,0,M,M);
  ctx.strokeStyle="#2f3640";ctx.lineWidth=16;ctx.strokeRect(0,0,M,M);
  if(aim&&drg){ctx.fillStyle="rgba(255,255,255,.25)";ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.arc(p.x,p.y,350,p.a-.2,p.a+.2);ctx.fill()}

  cub.forEach(function(c){ctx.fillStyle="#3498db";ctx.beginPath();ctx.arc(c.x,c.y,11,0,6.28);ctx.fill();ctx.strokeStyle="#fff";ctx.lineWidth=2;ctx.stroke();ctx.fillStyle="#fff";ctx.font="bold 11px sans-serif";ctx.textAlign="center";ctx.fillText("🐟",c.x,c.y+4)});
  fish.forEach(function(f){drwFish(f.x,f.y)});
  pup.forEach(function(u){drwPowerUp(u)});

  var drawList=[];
  bus.forEach(function(b){drawList.push({y:b.y+10,fn:function(){drwBush(b)}})});
  box.forEach(function(b){drawList.push({y:b.y+25,fn:function(){drwBox(b)}})});
  wal.forEach(function(w){drawList.push({y:w.y+45,fn:function(){drwWall(w)}})});

  bot.forEach(function(o){var h=bus.some(function(b){return Math.hypot(o.x-b.x,o.y-b.y)<50});if(o.boss||!h||Math.hypot(p.x-o.x,p.y-o.y)<75)drawList.push({y:o.y,fn:function(){drwCat(o.x,o.y,o.a,o.col||"#e74c3c",o.helm||"#2c3e50","#ff4757",o.cType||0,Math.min(4,Math.ceil(lvl/2)),o.hp,o.mhp,0,o.boss,1)}})});
  if(p2&&p2.hp>0&&(!p2.b||Math.hypot(p.x-p2.x,p.y-p2.y)<75))drawList.push({y:p2.y,fn:function(){ctx.globalAlpha=p2.b?.5:1;drwCat(p2.x,p2.y,p2.a,p2.col,p2.helm,p2.acc||"#fff",p2.type||0,p2.wpn||1,p2.hp,p2.mhp,0,0,1);ctx.globalAlpha=1}});
  var isMov=(Math.hypot(mv.x,mv.y)>0.1);
  drawList.push({y:p.y,fn:function(){ctx.globalAlpha=p.b?.5:1;drwCat(p.x,p.y,p.a,p.col,p.helm,p.acc||"#fff",p.type,p.wpn,p.hp,p.mhp,1,0,isMov);ctx.globalAlpha=1}});

  drawList.sort(function(a,b){return a.y-b.y});
  drawList.forEach(function(item){item.fn()});

  bul.forEach(function(b){ctx.fillStyle=b.col||"#fff";ctx.beginPath();ctx.arc(b.x,b.y,b.r,0,6.28);ctx.fill();if(b.s){ctx.strokeStyle="#fff";ctx.lineWidth=2;ctx.stroke()}});
  met.forEach(function(m){drwMeteor(m)});

  ctx.strokeStyle="#2ecc71";ctx.lineWidth=6;ctx.strokeRect(st.x-st.r,st.y-st.r,st.r*2,st.r*2);
  ctx.restore();
},16);

