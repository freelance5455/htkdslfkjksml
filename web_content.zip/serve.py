"""Same-origin development server: serves frontend and forwards /api to WSGI app."""
import os, sys, json, urllib.request, urllib.error
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
ROOT=Path(__file__).parent
sys.path.insert(0,str(ROOT/"backend"))
import app as api
class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*a,**kw): super().__init__(*a,directory=str(ROOT),**kw)
    def do_GET(self):
        if self.path.startswith("/api/"): return self.forward()
        return super().do_GET()
    def do_POST(self):
        if self.path.startswith("/api/"): return self.forward()
        self.send_error(404)
    def forward(self):
        from io import BytesIO
        import urllib.parse
        path=urllib.parse.urlparse(self.path).path[4:]
        length=int(self.headers.get("Content-Length","0"))
        body=self.rfile.read(length) if length else b""
        env={"REQUEST_METHOD":self.command,"PATH_INFO":path,"CONTENT_LENGTH":str(len(body)),
             "wsgi.input":BytesIO(body),"HTTP_AUTHORIZATION":self.headers.get("Authorization",""),
             "HTTP_X_ORGANIZATION_ID":self.headers.get("X-Organization-ID","")}
        result={}
        def start(status,headers): result["status"]=status;result["headers"]=headers
        chunks=b"".join(api.app(env,start))
        code=int(result["status"].split()[0])
        self.send_response(code)
        for k,v in result["headers"]:
            if k.lower() not in ("content-length",): self.send_header(k,v)
        self.send_header("Content-Length",str(len(chunks)));self.end_headers();self.wfile.write(chunks)
if __name__=="__main__":
    api.init_db()
    port=int(os.environ.get("PORT","8080"))
    print(f"Open http://localhost:{port}")
    ThreadingHTTPServer(("0.0.0.0",port),Handler).serve_forever()
