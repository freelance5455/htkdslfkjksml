IGL STUDIO — Free Fire Esports Strategy Board

Open index.html in Chrome (Android or desktop). The app is designed for offline-first planning, but built-in map image URLs require an internet connection. For offline use, upload a map image from your device.

Squad role markers: IGL, Primary Rusher (Pr), Secondary Rusher (Sr), Nader (N), Sniper (S).
Select any placed marker, label, or drawing and use Selected item size (50%–200%) to resize it.
Other markers: Enemy, Drop, Vehicle, Gloo Wall, Hold, Push, Split, Regroup, Rotate, Danger, Safe Zone.

Tools include pen, arrow, line, circle, rectangle, text, eraser, select/drag, undo/redo, zoom, plan notes, multiple plans, local save, editable JSON backup/import, and PNG export.

To install/use on Android:
1. Extract the ZIP using your Files app.
2. Open index.html with Chrome.
3. Allow file access if prompted. Use Upload Map to choose JPG, PNG, or WEBP from Gallery/Files.
4. Save plans on the device; use Export Project to transfer editable work to another phone.

Map artwork and game trademarks belong to their respective owners. Built-in map links need internet access and may change; upload your own permitted map images for reliable offline use.
