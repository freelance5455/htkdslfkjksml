# RISEUP 3.14.0 — Dark Hunter Rank Emblems

- Built from 3.13.0.
- Replaced the simple rank badge mark with six dark-fantasy hunter crests rendered as inline SVG/CSS.
- Rank unlock thresholds remain E=3, D=6, C=9, B=12, A=15, S=18.
- Backup deletion and existing gameplay logic preserved.
- Automated checks: static, PWA, gameplay.
- No physical Android device test performed.
