import express from 'express';
import multer from 'multer';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { upload, get_item } from 'internetarchive';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express();
const PORT=process.env.PORT||3000;
const DATA=path.join(__dirname,'data');
const DB=path.join(DATA,'rbm.json');
const TMP=path.join(DATA,'tmp');
fs.mkdirSync(TMP,{recursive:true});
if(!fs.existsSync(DB))fs.writeFileSync(DB,JSON.stringify({news:[],music:[]},null,2));
const readDB=()=>JSON.parse(fs.readFileSync(DB,'utf8'));
const writeDB=x=>fs.writeFileSync(DB,JSON.stringify(x,null,2));
const uploadFile=multer({dest:TMP,limits:{fileSize:250*1024*1024}});
const iaConfig={access_key:process.env.IA_ACCESS_KEY,secret_key:process.env.IA_SECRET_KEY};
const prefix=process.env.IA_IDENTIFIER_PREFIX||'richboyyz-rbm-music';
function safe(s){return String(s||'').replace(/[^a-zA-Z0-9._-]/g,'-').slice(0,100)}
function idFor(title){return `${prefix}-${Date.now()}-${safe(title).toLowerCase()}-${crypto.randomBytes(3).toString('hex')}`}
function needIA(){if(!iaConfig.access_key||iaConfig.access_key.startsWith('PASTE_')||!iaConfig.secret_key||iaConfig.secret_key.startsWith('PASTE_'))throw new Error('Internet Archive credentials are not configured on the server.');}
app.use(express.json({limit:'2mb'}));
app.use(express.static(path.join(__dirname,'public')));
app.get('/api/feed',(req,res)=>{const db=readDB();const feed=[...db.news].sort((a,b)=>b.createdAt-a.createdAt);res.json(feed)});
app.get('/api/music',(req,res)=>{const db=readDB();res.json(db.music.sort((a,b)=>b.createdAt-a.createdAt).map(x=>({...x,streamUrl:`/api/music/${x.id}/stream`,downloadUrl:`/api/music/${x.id}/download`,coverUrl:x.coverFile?`/api/music/${x.id}/cover`:''})))});
app.post('/api/news',uploadFile.single('file'),(req,res)=>{try{const {title,creator,details,type='news'}=req.body;if(!title||!details)return res.status(400).json({error:'Title and details are required.'});let db=readDB();let id=crypto.randomUUID();let item={id,title,creator:creator||'RBM Community',details,type,createdAt:Date.now(),fileName:req.file?.originalname||'',filePath:req.file?.path||''};db.news.unshift(item);writeDB(db);res.json({ok:true,item})}catch(e){res.status(500).json({error:e.message})}});
app.post('/api/music',uploadFile.fields([{name:'audio',maxCount:1},{name:'cover',maxCount:1}]),async(req,res)=>{let audio=req.files?.audio?.[0],cover=req.files?.cover?.[0];try{needIA();if(!audio)return res.status(400).json({error:'Audio file is required.'});const title=req.body.title||audio.originalname;const identifier=idFor(title);const remoteAudio=`${safe(title)}.mp3`;const files={};files[remoteAudio]=audio.path;if(cover)files[`cover-${safe(cover.originalname)}`]=cover.path;await upload(identifier,files,{...iaConfig,metadata:{title,creator:req.body.artist||'RBM Artist',description:req.body.details||'RBM music release',mediatype:'audio',subject:['RBM','RICH BOYYZ','Music']},queue_derive:true});const db=readDB();const item={id:identifier,title,artist:req.body.artist||'RBM Artist',producer:req.body.producer||'RICH BOYYZ',details:req.body.details||'',audioFile:remoteAudio,coverFile:cover?`cover-${safe(cover.originalname)}`:'',createdAt:Date.now()};db.music.unshift(item);writeDB(db);res.json({ok:true,item:{...item,streamUrl:`/api/music/${identifier}/stream`,downloadUrl:`/api/music/${identifier}/download`}})}catch(e){res.status(500).json({error:e.message})}finally{for(const f of [audio,cover])if(f?.path)try{fs.unlinkSync(f.path)}catch{}}});
async function proxyFile(req,res,download=false){try{const db=readDB();const item=db.music.find(x=>x.id===req.params.id);if(!item)return res.sendStatus(404);const filename=req.params.kind==='cover'?item.coverFile:item.audioFile;if(!filename)return res.sendStatus(404);needIA();const it=get_item(item.id,iaConfig);const url=`https://archive.org/download/${encodeURIComponent(item.id)}/${encodeURIComponent(filename)}`;const r=await fetch(url);if(!r.ok)return res.status(r.status).send('Media is not ready yet.');res.statusCode=200;res.setHeader('Content-Type',r.headers.get('content-type')||'application/octet-stream');if(download)res.setHeader('Content-Disposition',`attachment; filename="${filename.replace(/"/g,'')}"`);else res.setHeader('Content-Disposition','inline');if(r.body)r.body.pipeTo(new WritableStream({write(chunk){res.write(Buffer.from(chunk))},close(){res.end()},abort(){res.end()}}));else res.end(Buffer.from(await r.arrayBuffer()))}catch(e){res.status(500).send('Media unavailable.')}}
app.get('/api/music/:id/stream',(req,res)=>{req.params.kind='audio';proxyFile(req,res,false)});app.get('/api/music/:id/download',(req,res)=>{req.params.kind='audio';proxyFile(req,res,true)});app.get('/api/music/:id/cover',(req,res)=>{req.params.kind='cover';proxyFile(req,res,false)});
app.get('/api/archive-status/:id',async(req,res)=>{try{needIA();const item=get_item(req.params.id,iaConfig);const meta=await item.metadata;res.json({ok:true,title:meta?.title||req.params.id})}catch(e){res.status(500).json({ok:false,error:e.message})}});
app.listen(PORT,()=>console.log(`RBM running on http://localhost:${PORT}`));
