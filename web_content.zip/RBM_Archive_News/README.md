# RBM — RICH BOYYZ Magazine v2

## Changes requested
- Bottom navigation is now: **Home · News · Upload · Music · Search**.
- The old **Names** section has been removed and replaced by **News**.
- News shows what people upload plus title, creator, date/type and detailed text.
- Music has a dedicated upload screen opened by tapping the RBM logo.
- Music is uploaded by the server to the connected Internet Archive account, but **Archive.org is not displayed in the RBM interface**. RBM exposes `/api/music/...` stream/download routes instead.
- Users see only RBM branding, the player, Share and Download controls.

## Important privacy/technical limitation
This hides the storage provider from the normal RBM interface. It cannot guarantee that nobody can discover the provider: a technically skilled user can inspect network traffic/server behavior. The server proxy keeps the Archive.org URL out of the public HTML and player URLs.

## Internet Archive account setup
The supplied URL is a profile page, not a single storage item. Internet Archive supports audio uploads and requires an account; its programmatic upload interface uses IA-S3 credentials. See the official documentation for obtaining the keys and uploading items.

Set these environment variables on the RBM server:
- `IA_ACCESS_KEY`
- `IA_SECRET_KEY`
- `IA_IDENTIFIER_PREFIX` (for example `richboyyz-rbm-music`)

Do **not** put these credentials in HTML or JavaScript.

## Run
```bash
npm install
cp .env.example .env
# edit .env with the Internet Archive S3 keys
npm start
```
Then open `http://localhost:3000`.

## Public deployment
Use HTTPS, a real database, authentication/rate limits, upload moderation and file-size/type validation before opening public uploads widely. The included JSON file is a simple prototype store, not a production multi-server database.

## Rights
Only upload music you own or are authorized to distribute. Internet Archive requires appropriate rights/metadata for uploaded material.
