/**
 * ترید یار - سرور همگام‌سازی Cloudflare Worker با KV Storage
 * 
 * این Worker داده‌ها را در Cloudflare KV ذخیره می‌کند (نه textdb.dev)
 * KV رایگان است و در ایران فیلتر نیست.
 * 
 * دستورالعمل:
 * 1. در Cloudflare Dashboard → Workers → KV → Create namespace
 *    نام: TRADYAR_KV
 * 2. کد زیر را در Worker جایگزین کنید
 * 3. روی Deploy بزنید
 */

export default {
  async fetch(request, env) {
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Content-Type': 'application/json',
    };

    // Handle CORS preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: corsHeaders });
    }

    try {
      const KEY = 'tradyar_sync_data';

      // GET - fetch data from KV
      if (request.method === 'GET') {
        const value = await env.TRADYAR_KV.get(KEY);
        if (value) {
          return new Response(JSON.stringify({ ok: true, doc: JSON.parse(value) }), {
            status: 200, headers: corsHeaders,
          });
        }
        return new Response(JSON.stringify({ ok: false, reason: 'no_data' }), {
          status: 200, headers: corsHeaders,
        });
      }

      // POST - save data to KV
      if (request.method === 'POST') {
        const body = await request.text();
        await env.TRADYAR_KV.put(KEY, body);
        return new Response(JSON.stringify({ ok: true }), {
          status: 200, headers: corsHeaders,
        });
      }

      return new Response(JSON.stringify({ ok: false, error: 'method_not_allowed' }), {
        status: 405, headers: corsHeaders,
      });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: String(e) }), {
        status: 500, headers: corsHeaders,
      });
    }
  },
};
