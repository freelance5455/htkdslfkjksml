SS LOUCO — projeto Android (Java + WebView)

O que faz:
- Exibe uma bolha flutuante arrastável.
- Tocar na bolha abre/fecha a interface HTML.
- A interface inclui abas e controles visuais AIM/ESP/AJUSTES.

Limite técnico:
Este projeto implementa a sobreposição e a interface. Não lê nem altera a memória do Free Fire; os offsets fornecidos não são suficientes para validar endereços, estruturas e compatibilidade de uma build do jogo. Os controles AIM/ESP são apenas controles visuais.

Compilar:
1. Abra esta pasta no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Gere APK em Build > Build APK(s).

Instalar por ADB:
adb install -r app/build/outputs/apk/debug/app-debug.apk
adb shell monkey -p com.sslouco.overlay 1

Na primeira execução, toque em ATIVAR PAINEL FLUTUANTE e permita "Exibir sobre outros apps".
