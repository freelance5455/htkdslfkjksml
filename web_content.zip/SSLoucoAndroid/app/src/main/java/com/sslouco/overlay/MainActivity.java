package com.sslouco.overlay;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.Gravity;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQUEST = 701;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 48, 32, 32);
        layout.setGravity(Gravity.CENTER);
        layout.setBackgroundColor(0xFF061B12);

        TextView title = new TextView(this);
        title.setText("SS LOUCO");
        title.setTextColor(0xFF19FF4A);
        title.setTextSize(30);
        title.setGravity(Gravity.CENTER);
        layout.addView(title);

        TextView info = new TextView(this);
        info.setText("Ative a permissão de sobreposição para mostrar o painel flutuante.");
        info.setTextColor(0xFFD6FFE5);
        info.setTextSize(16);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, 24, 0, 24);
        layout.addView(info);

        Button start = new Button(this);
        start.setText("ATIVAR PAINEL FLUTUANTE");
        layout.addView(start);
        start.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
                Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(permission, OVERLAY_REQUEST);
            } else {
                startOverlay();
            }
        });
        setContentView(layout);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQUEST && (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this))) {
            startOverlay();
        }
    }

    private void startOverlay() {
        startService(new Intent(this, OverlayService.class));
        finish();
    }
}
