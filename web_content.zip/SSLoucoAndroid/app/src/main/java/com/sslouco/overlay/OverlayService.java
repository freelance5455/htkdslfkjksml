package com.sslouco.overlay;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager wm;
    private FrameLayout bubble;
    private FrameLayout panel;
    private WindowManager.LayoutParams bubbleParams, panelParams;
    private boolean open = false;

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        int type = android.os.Build.VERSION.SDK_INT >= 26
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        bubble = new FrameLayout(this);
        TextView mark = new TextView(this);
        mark.setText("SS");
        mark.setTextColor(Color.rgb(10, 35, 18));
        mark.setTextSize(20);
        mark.setGravity(Gravity.CENTER);
        mark.setTypeface(null, 1);
        mark.setBackground(makeCircle());
        bubble.addView(mark, new FrameLayout.LayoutParams( dp(62), dp(62), Gravity.CENTER));

        bubbleParams = new WindowManager.LayoutParams(dp(68), dp(68), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = dp(14); bubbleParams.y = dp(220);
        wm.addView(bubble, bubbleParams);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY; boolean moved;
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX=e.getRawX(); downY=e.getRawY();
                        startX=bubbleParams.x; startY=bubbleParams.y; moved=false; return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx=(int)(e.getRawX()-downX), dy=(int)(e.getRawY()-downY);
                        if (Math.abs(dx)+Math.abs(dy)>8) moved=true;
                        bubbleParams.x=startX+dx; bubbleParams.y=startY+dy;
                        wm.updateViewLayout(bubble,bubbleParams); return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) togglePanel(); return true;
                }
                return true;
            }
        });
        createPanel(type);
    }

    private void createPanel(int type) {
        panel = new FrameLayout(this);
        WebView web = new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.loadUrl("file:///android_asset/index.html");
        panel.addView(web, new FrameLayout.LayoutParams(-1,-1));
        panelParams = new WindowManager.LayoutParams(-1, dp(560), type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.CENTER;
    }

    private android.graphics.drawable.GradientDrawable makeCircle() {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        d.setColor(0xFF19FF4A); d.setStroke(dp(3), 0xFF17653E); return d;
    }
    private int dp(int v) { return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private void togglePanel() {
        if (open) { try { wm.removeView(panel); } catch(Exception ignored) {} }
        else { try { wm.addView(panel, panelParams); } catch(Exception ignored) {} }
        open = !open;
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public void onDestroy() {
        try { if (open) wm.removeView(panel); } catch(Exception ignored) {}
        try { wm.removeView(bubble); } catch(Exception ignored) {}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
