BOLA NA REDE — PROJETO ANDROID

Este projeto empacota o arquivo HTML original em um aplicativo Android WebView.

Configuração:
- Nome: Bola na Rede
- Orientação: retrato
- Tela cheia/imersiva
- JavaScript habilitado
- localStorage habilitado para preservar progresso/configurações
- Internet habilitada para os recursos externos que o HTML consulta
- HTML original preservado em app/src/main/assets/index.html

COMO GERAR O APK:
1. Abra esta pasta no Android Studio.
2. Aguarde o Gradle sincronizar e baixar as dependências.
3. Use Build > Build APK(s).
4. O APK de debug ficará em app/build/outputs/apk/debug/app-debug.apk.

Observação: o ambiente desta conversa não possui Android SDK/Gradle instalados, então o APK binário não pôde ser compilado aqui. O projeto já está preparado para a compilação no Android Studio.
