# v1.53.10 — Reversão segura do bloqueio de partidas

- Baseada na v1.53.8, mantendo a correção de armazenamento das ligas.
- Revertida a lógica nova de recuperação de partida da v1.53.9, que podia descartar um estado de partida válido e causar o bloqueio.
- Restaurados `goMatch()` e `init()` da v1.53.8; nenhum dado salvo é apagado automaticamente.
- Cache PWA renomeado para forçar a atualização dos arquivos após publicação.
