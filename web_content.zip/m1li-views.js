/* M1li client — عدّاد المشاهدات واللايكات والمتابعين (يتكلم مع server/server.js).
   ضعه قبل shop.js:  <script src="m1li-views.js"></script>
   الإعداد: افتراضياً نفس النطاق (السيرفر يقدّم المتجر نفسه).
   إذا كان المتجر على استضافة أخرى، ضع قبل هاد السكربت:
     <script>window.M1LI_API = 'https://api.your-domain.com';</script> */
(function () {
  var API = (typeof window.M1LI_API === 'string' ? window.M1LI_API : '').replace(/\/+$/, '');
  var MIN_VISIBLE_MS = 1500;   // لازم الإعلان يبقى ظاهر 1.5 ثانية (السيرفر يطلب 1.4 على الأقل)
  var MIN_VISIBLE_RATIO = 0.6; // 60% من الإعلان ظاهر على الشاشة
  var CONFIGURED = !(location.protocol === 'file:' && !API);

  function deviceId() {
    try {
      var id = localStorage.getItem('m1li_device');
      if (!id || !/^[A-Za-z0-9_\-]{8,64}$/.test(id)) {
        id = (crypto.randomUUID ? crypto.randomUUID() : (String(Date.now()) + Math.random().toString(36).slice(2)).replace(/[^A-Za-z0-9]/g, ''));
        localStorage.setItem('m1li_device', id);
      }
      return id;
    } catch (e) { return 'anon' + String(Math.random()).slice(2, 14); }
  }

  function get(path) {
    return fetch(API + path, { cache: 'no-store' }).then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; });
  }
  function post(path, body, extra) {
    return fetch(API + path, { method: 'POST', headers: Object.assign({ 'Content-Type': 'application/json' }, extra || {}), body: JSON.stringify(body) })
      .then(function (r) { return r.json().then(function (j) { return { status: r.status, json: j }; }, function () { return { status: r.status, json: null }; }); });
  }

  /* ---------- المشاهدات ---------- */
  function sendView(adId, tokenPromise) {
    var sentKey = 'm1li_seen_' + adId + '_' + new Date().toISOString().slice(0, 10);
    try { if (localStorage.getItem(sentKey)) return; localStorage.setItem(sentKey, '1'); } catch (e) {}
    function undo() { try { localStorage.removeItem(sentKey); } catch (e) {} }
    tokenPromise.then(function (tok) {
      if (!tok) { undo(); return; }
      return post('/api/view', { ad_id: adId, device_id: deviceId(), token: tok }).then(function (r) {
        // الرفض من السيرفر (مكرر/بوت...) قرار نهائي؛ أخطاء الشبكة والسيرفر نعيد المحاولة لها لاحقاً
        if (r.status >= 500 || r.status === 429) undo();
      });
    }).catch(undo);
  }

  function getToken(adId) {
    return get('/api/token?ad=' + encodeURIComponent(adId) + '&d=' + encodeURIComponent(deviceId())).then(function (j) { return j && j.token ? j.token : null; });
  }

  // M1Views.track(element, 'ad-123') — يسجّل مشاهدة بعد أن يظهر العنصر 1.5 ثانية
  function track(el, adId) {
    if (!CONFIGURED || !el || !adId || !('IntersectionObserver' in window)) return;
    var timer = null, tok = null;
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting && en.intersectionRatio >= MIN_VISIBLE_RATIO && !document.hidden) {
          if (!timer) {
            tok = getToken(adId);   // السيرفر يحسب مدة الظهور من لحظة إصدار التوكن
            timer = setTimeout(function () { sendView(adId, tok); io.disconnect(); }, MIN_VISIBLE_MS);
          }
        } else if (timer) { clearTimeout(timer); timer = null; tok = null; }
      });
    }, { threshold: [MIN_VISIBLE_RATIO] });
    io.observe(el);
  }

  /* ---------- الأرقام ---------- */
  // stats(['a','b']) -> { stats: { a: {views, likes} }, liked: ['a'] } أو null
  function stats(ids) {
    if (!CONFIGURED || !ids || !ids.length) return Promise.resolve(null);
    return get('/api/stats?ids=' + encodeURIComponent(ids.slice(0, 100).join(',')) + '&d=' + encodeURIComponent(deviceId()));
  }
  function counts(ids) {   // خريطة id -> عدد المشاهدات
    return stats(ids).then(function (j) {
      var m = {};
      if (j && j.stats) Object.keys(j.stats).forEach(function (k) { m[k] = Number(j.stats[k].views) || 0; });
      return m;
    });
  }
  function count(adId) { return counts([adId]).then(function (m) { return adId in m ? m[adId] : null; }); }

  /* ---------- لايك ومتابعة ---------- */
  // like('app-1', true) -> { ok, liked, likes } أو null (السيرفر يطلب أن يكون للجهاز مشاهدة صحيحة قبل اللايك)
  function like(adId, on) {
    if (!CONFIGURED || !adId) return Promise.resolve(null);
    return post('/api/like', { ad_id: adId, device_id: deviceId(), on: !!on }).then(function (r) { return r.json && r.json.ok ? r.json : null; }).catch(function () { return null; });
  }
  function follow(devKey, on) {
    if (!CONFIGURED || !devKey) return Promise.resolve(null);
    return post('/api/follow', { dev: String(devKey).slice(0, 40), device_id: deviceId(), on: !!on }).then(function (r) { return r.json && r.json.ok ? r.json : null; }).catch(function () { return null; });
  }
  function followers(devKey) {   // -> { followers, following } أو null
    if (!CONFIGURED || !devKey) return Promise.resolve(null);
    return get('/api/followers?dev=' + encodeURIComponent(String(devKey).slice(0, 40)) + '&d=' + encodeURIComponent(deviceId()));
  }

  /* ---------- الحسابات (رقم هاتف فريد + كلمة سر) ---------- */
  var SKEY = 'm1li_session';
  function session() { try { var s = JSON.parse(localStorage.getItem(SKEY) || 'null'); return s && s.token ? s : null; } catch (e) { return null; } }
  function setSession(s) { try { if (s) localStorage.setItem(SKEY, JSON.stringify(s)); else localStorage.removeItem(SKEY); } catch (e) {} }
  function authCall(path, body) {
    if (!CONFIGURED) return Promise.resolve({ ok: false, error: 'network' });
    return post(path, body).then(function (r) {
      if (r.json && r.json.ok && r.json.token) { setSession({ token: r.json.token, name: r.json.user.name, phone: r.json.user.phone || '', email: r.json.user.email || '', verified: !!r.json.user.verified }); return { ok: true, user: r.json.user }; }
      return { ok: false, error: (r.json && r.json.error) || 'network' };
    }).catch(function () { return { ok: false, error: 'network' }; });
  }
  function register(phone, name, password, code) { return authCall('/api/register', { phone: phone, name: name, password: password, code: code || '' }); }
  function login(phone, password, name) { return authCall('/api/login', { phone: phone, name: name || '', password: password }); }
  function forgotSend(phone) { if (!CONFIGURED) return Promise.resolve({ ok: false, error: 'network' }); return post('/api/password/forgot', { phone: phone }).then(function (r) { return r.json && r.json.ok ? { ok: true } : { ok: false, error: (r.json && r.json.error) || 'network' }; }).catch(function () { return { ok: false, error: 'network' }; }); }
  function forgotReset(phone, code, password) { if (!CONFIGURED) return Promise.resolve({ ok: false, error: 'network' }); return post('/api/password/reset', { phone: phone, code: code, password: password }).then(function (r) { return r.json && r.json.ok ? { ok: true } : { ok: false, error: (r.json && r.json.error) || 'network' }; }).catch(function () { return { ok: false, error: 'network' }; }); }
  function googleLogin(credential) { return authCall('/api/auth/google', { credential: credential }); }
  // me() -> 'ok' | 'out' (الجلسة منتهية/غير موجودة) | 'offline' (السيرفر غير متاح)
  function me() {
    var s = session();
    if (!s) return Promise.resolve('out');
    return fetch(API + '/api/me', { cache: 'no-store', headers: { 'Authorization': 'Bearer ' + s.token } }).then(function (r) {
      if (r.status === 401) { setSession(null); return 'out'; }
      return r.ok ? r.json().then(function (j) { setSession({ token: s.token, name: j.user.name, phone: j.user.phone || '', email: j.user.email || '', verified: !!j.user.verified }); return 'ok'; }) : 'offline';
    }).catch(function () { return 'offline'; });
  }
  function logout() {
    var s = session(); setSession(null);
    if (!s || !CONFIGURED) return Promise.resolve();
    return post('/api/logout', {}, { 'Authorization': 'Bearer ' + s.token }).catch(function () {});
  }

  /* ---------- التطبيقات على السيرفر ---------- */
  function authHeader() { var s = session(); return s ? { 'Authorization': 'Bearer ' + s.token } : {}; }
  function apps() {   // -> مصفوفة التطبيقات (بدون الكود) أو null
    if (!CONFIGURED) return Promise.resolve(null);
    return fetch(API + '/api/apps', { cache: 'no-store', headers: authHeader() }).then(function (r) { return r.ok ? r.json() : null; })
      .then(function (j) { return j && Array.isArray(j.apps) ? j.apps : null; }).catch(function () { return null; });
  }
  function getApp(id) {   // -> التطبيق كاملاً مع الكود أو null
    if (!CONFIGURED) return Promise.resolve(null);
    return fetch(API + '/api/apps/' + encodeURIComponent(id), { cache: 'no-store' }).then(function (r) { return r.ok ? r.json() : null; })
      .then(function (j) { return j && j.app ? j.app : null; }).catch(function () { return null; });
  }
  function appCall(path, body) {
    if (!CONFIGURED) return Promise.resolve({ ok: false, error: 'network' });
    return post(path, body, authHeader()).then(function (r) {
      return r.json && r.json.ok ? { ok: true, id: r.json.id, live: r.json.live !== false, publishAt: r.json.publishAt || 0 } : { ok: false, error: (r.json && r.json.error) || 'network' };
    }).catch(function () { return { ok: false, error: 'network' }; });
  }
  function publishApp(obj) { return appCall('/api/apps', obj); }
  function updateApp(id, obj) { return appCall('/api/apps/' + encodeURIComponent(id) + '/update', obj); }
  /* رفع APK/ZIP (ثنائي خام) مع نسبة التقدم -> { ok, url } أو { ok:false, error } */
  function uploadFile(file, onProgress) {
    if (!CONFIGURED) return Promise.resolve({ ok: false, error: 'network' });
    return new Promise(function (resolve) {
      var x = new XMLHttpRequest(), h = authHeader();
      x.open('POST', API + '/api/upload?name=' + encodeURIComponent(file.name));
      Object.keys(h).forEach(function (k) { x.setRequestHeader(k, h[k]); });
      x.setRequestHeader('Content-Type', 'application/octet-stream');
      if (x.upload && onProgress) x.upload.onprogress = function (e) { if (e.lengthComputable) onProgress(Math.round(e.loaded / e.total * 100)); };
      x.onload = function () {
        var j = null; try { j = JSON.parse(x.responseText); } catch (e) {}
        resolve(j && j.ok ? { ok: true, url: j.url } : { ok: false, error: (j && j.error) || 'network' });
      };
      x.onerror = x.ontimeout = function () { resolve({ ok: false, error: 'network' }); };
      x.send(file);
    });
  }
  function deleteApp(id) { return appCall('/api/apps/' + encodeURIComponent(id) + '/delete', {}); }

  /* ---------- تأكيد الرقم برمز (SMS / واتساب) ---------- */
  function config() {   // -> { otp: true/false, channel: 'sms'|'whatsapp' }
    if (!CONFIGURED) return Promise.resolve({ otp: false });
    return get('/api/config').then(function (j) { return j && j.ok ? j : { otp: false }; });
  }
  function otpCall(path, body) {
    if (!CONFIGURED) return Promise.resolve({ ok: false, error: 'network' });
    return post(path, body, authHeader()).then(function (r) {
      return r.json && r.json.ok ? r.json : { ok: false, error: (r.json && r.json.error) || 'network' };
    }).catch(function () { return { ok: false, error: 'network' }; });
  }
  function sendOtp(phone) { return otpCall('/api/otp/send', { phone: phone }); }          // -> { ok, cooldown, ttl }
  function verifyOtp(code) {                                                              // للحساب المسجَّل دخوله
    return otpCall('/api/otp/verify', { code: String(code || '') }).then(function (r) {
      if (r.ok) { var s = session(); if (s) { s.verified = true; setSession(s); } }
      return r;
    });
  }

  /* ---------- اربح مع m1li (نقاط الفيديوهات) ---------- */
  function earnCall(method, path, body) {
    if (!CONFIGURED) return Promise.resolve({ ok: false, error: 'network' });
    var opts = { method: method, cache: 'no-store', headers: Object.assign({ 'Content-Type': 'application/json' }, authHeader()) };
    if (body) opts.body = JSON.stringify(body);
    return fetch(API + path, opts).then(function (r) {
      return r.json().then(function (j) { return j && j.ok ? j : { ok: false, error: (j && j.error) || 'network', status: r.status }; }, function () { return { ok: false, error: 'network' }; });
    }).catch(function () { return { ok: false, error: 'network' }; });
  }
  function earnConfig() { return earnCall('GET', '/api/earn/config'); }
  function earnMe() { return earnCall('GET', '/api/earn/me'); }
  function earnSubmit(platform, url) { return earnCall('POST', '/api/earn/submit', { platform: platform, url: url }); }
  function earnPayout(points, method, holder, account) { return earnCall('POST', '/api/earn/payout', { points: points, method: method, holder: holder, account: account }); }

  window.M1Views = {
    config: config, sendOtp: sendOtp, verifyOtp: verifyOtp,
    apps: apps, getApp: getApp, publishApp: publishApp, updateApp: updateApp, uploadFile: uploadFile, deleteApp: deleteApp,
    register: register, login: login, googleLogin: googleLogin, forgotSend: forgotSend, forgotReset: forgotReset, me: me, logout: logout, session: session,
    track: track, stats: stats, count: count, counts: counts,
    like: like, follow: follow, followers: followers,
    earnConfig: earnConfig, earnMe: earnMe, earnSubmit: earnSubmit, earnPayout: earnPayout,
    get configured() { return CONFIGURED; }
  };
})();
