DESCIFRA Y COMUNICA — MVP 0.1

CONTENIDO
- index.html: interfaz principal.
- styles.css: diseño adaptable a móvil y escritorio.
- app.js: módulos de aprendizaje, preguntas, puntos y progreso local.
- manifest.json y sw.js: base para instalar como PWA y usar sin conexión.

CÓMO PROBAR
1. Descomprime el archivo.
2. Para probar localmente, abre index.html en un navegador moderno.
3. Para probar instalación PWA y modo offline, publica la carpeta en un hosting con HTTPS
   (por ejemplo, un hosting estático) y abre la URL en Chrome/Edge/Safari compatible.
4. En Android: menú del navegador > Instalar aplicación / Añadir a pantalla de inicio.
5. En iPhone: Safari > Compartir > Añadir a pantalla de inicio.
6. En PC: usa la opción Instalar de Chrome o Edge cuando esté disponible.

ESTADO Y LIMITACIONES HONESTAS
- Este es un prototipo funcional local, no una app nativa compilada.
- El progreso se guarda en el dispositivo mediante localStorage.
- La estructura PWA permite caché offline tras la primera carga desde HTTPS.
- Las partidas multijugador, cuentas, sincronización en la nube, clasificación global,
  notificaciones y audio avanzado requieren backend e implementación adicional.
- Los códigos 10 no son universales. Los ejemplos de la app son educativos y deben
  contrastarse con la normativa de cada entidad y jurisdicción.
- El alfabeto fonético usa la forma internacional estándar; las lecciones pueden ampliarse.

SIGUIENTE FASE RECOMENDADA
1. Validar contenido de Perú con fuentes institucionales.
2. Añadir más lecciones, niveles y banco de preguntas.
3. Implementar audio Morse y simulador de radio.
4. Crear backend seguro para usuarios, sincronización y torneos online.
5. Empaquetar/publicar en Google Play, App Store y escritorio según requisitos.
