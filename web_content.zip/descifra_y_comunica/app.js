const lessons = {
 phonetic:{title:"Alfabeto fonético",cipher:"A · B · C · D",question:"¿Qué palabras corresponden a las letras A, B y C en el alfabeto fonético internacional?",options:["Alfa · Bravo · Charlie","América · Brasil · Chile","Atlas · Beta · Cobra"],answer:0,explain:"¡Correcto! Alfa, Bravo y Charlie permiten identificar letras con claridad al transmitirlas por voz."},
 ten:{title:"Códigos 10",cipher:"10-4",question:"En muchas tablas de códigos 10, ¿qué significa 10-4?",options:["Recibido / entendido","Fuera de servicio","Regresar a la base"],answer:0,explain:"10-4 suele significar recibido o entendido. Los códigos varían entre agencias y jurisdicciones; no hay una tabla universal."},
 morse:{title:"Código Morse",cipher:"... --- ...",question:"¿Qué señal internacional de socorro representan estos puntos y rayas?",options:["SOS","OK","FIN"],answer:0,explain:"SOS se transmite como tres puntos, tres rayas y tres puntos."},
 tactical:{title:"Comunicación táctica",cipher:"N 12° · E 08°",question:"En este ejercicio ficticio de orientación, ¿qué representan N y E?",options:["Norte y Este","Nivel y Elevación","Noche y Entrada"],answer:0,explain:"N indica Norte y E indica Este. En una misión real se deben usar mapas y referencias oficiales."},
 colors:{title:"Código de colores",cipher:"🔵  🔴  🟡",question:"Clave del ejercicio: azul = 2, rojo = 1, amarillo = 3. ¿Cuál es la secuencia?",options:["213","123","321"],answer:0,explain:"Azul es 2, rojo es 1 y amarillo es 3: 213."},
 crypto:{title:"Criptografía César",cipher:"FDVD",question:"Descifra el texto desplazando cada letra tres posiciones hacia atrás.",options:["CASA","DATO","CLAVE"],answer:0,explain:"F→C, D→A, V→S y D→A. El mensaje dice CASA."},
 detective:{title:"Investigación policial ficticia",cipher:"PISTA 01 / ARCHIVO",question:"En un caso ficticio, una nota dice: «La clave está donde guardan los libros». ¿Qué lugar revisarías primero?",options:["La biblioteca","El estacionamiento","La azotea"],answer:0,explain:"La biblioteca es la deducción más directa a partir de la pista."}
};
const defaultState={xp:0,missions:0,correct:0,attempts:0,completed:[]};
let state={...defaultState,...JSON.parse(localStorage.getItem("dyc-progress")||"{}")};
const $=id=>document.getElementById(id);
function save(){localStorage.setItem("dyc-progress",JSON.stringify(state));renderStats()}
const ranks = [
 {name:"Recluta",min:0,next:100},
 {name:"Cadete",min:100,next:250},
 {name:"Operador",min:250,next:450},
 {name:"Agente",min:450,next:700},
 {name:"Agente especial",min:700,next:1000},
 {name:"Investigador",min:1000,next:1400},
 {name:"Experto táctico",min:1400,next:1900},
 {name:"Analista de inteligencia",min:1900,next:2500},
 {name:"Élite",min:2500,next:3300},
 {name:"Maestro de inteligencia",min:3300,next:null}
];
function currentRankIndex(){let i=0;for(let n=0;n<ranks.length;n++){if(state.xp>=ranks[n].min)i=n}return i}
function rank(){return ranks[currentRankIndex()].name}
function renderRanks(){
 const list=$("rank-list"); if(!list)return;
 const current=currentRankIndex();
 list.innerHTML="";
 ranks.forEach((r,i)=>{
  const row=document.createElement("div");row.className="rank-row"+(i===current?" current":"")+(i<current?" achieved":"");
  const mark=document.createElement("span");mark.className="rank-mark";mark.textContent=String(i+1).padStart(2,"0");
  const info=document.createElement("span");info.className="rank-info";
  const title=document.createElement("b");title.textContent=r.name;
  const sub=document.createElement("small");sub.textContent=i===current?"TU RANGO ACTUAL":(i<current?"RANGO ALCANZADO":r.min+" XP para desbloquear");
  info.append(title,sub);
  const stateMark=document.createElement("span");stateMark.className="rank-state";stateMark.textContent=i<current?"✓":(i===current?"ACTUAL":"🔒");
  row.append(mark,info,stateMark);list.append(row);
 });
 const r=ranks[current], progress=r.next?Math.min(100,Math.round((state.xp-r.min)/(r.next-r.min)*100)):100;
 const bar=$("rank-progress");if(bar)bar.style.width=progress+"%";
 const label=$("rank-progress-label");if(label)label.textContent=r.next?(state.xp-r.min)+" / "+(r.next-r.min)+" XP":"RANGO MÁXIMO ALCANZADO";
}
function renderStats(){
 $("xp").textContent=state.xp+" XP";$("rank").textContent=rank().toUpperCase();
 $("stat-xp").textContent=state.xp;$("stat-missions").textContent=state.missions;
 $("stat-accuracy").textContent=state.attempts?Math.round(state.correct/state.attempts*100)+"%":"—";
 $("record-rank").textContent=rank();$("record-xp").textContent=state.xp+" XP";$("record-correct").textContent=state.correct;renderRanks();
}
function view(name){document.querySelectorAll(".view").forEach(v=>v.classList.add("hidden"));$("view-"+name).classList.remove("hidden");document.querySelectorAll(".tab").forEach(t=>t.classList.toggle("active",t.dataset.view===name));window.scrollTo({top:0,behavior:"smooth"})}
document.querySelectorAll("[data-view]").forEach(b=>b.addEventListener("click",()=>view(b.dataset.view)));
let current=null,answered=false;
function openModule(id){
 current=lessons[id];if(!current)return;answered=false;
 $("modal-kicker").textContent="ENTRENAMIENTO · "+id.toUpperCase();$("modal-title").textContent=current.title;
 $("cipher").textContent=current.cipher;$("question").textContent=current.question;$("feedback").textContent="";$("feedback").className="feedback";$("next").classList.add("hidden");
 $("options").innerHTML="";
 current.options.forEach((option,i)=>{const b=document.createElement("button");b.className="option";b.textContent=String.fromCharCode(65+i)+".  "+option;b.addEventListener("click",()=>choose(i));$("options").appendChild(b)});
 $("modal").classList.remove("hidden");
}
function choose(i){
 if(answered)return;answered=true;state.attempts++;
 const good=i===current.answer;
 if(good){state.correct++;state.xp+=100;state.missions++;state.completed.push(current.title);$("feedback").textContent="✓ RESPUESTA CORRECTA · +100 XP. "+current.explain;$("feedback").className="feedback good"}
 else{$("feedback").textContent="✕ RESPUESTA INCORRECTA. La respuesta correcta es: "+current.options[current.answer]+". "+current.explain;$("feedback").className="feedback bad"}
 [...$("options").children].forEach((b,j)=>{b.disabled=true;if(j===current.answer)b.style.borderColor="#65e5b8"});
 save();$("next").classList.remove("hidden");$("next").textContent="VOLVER A LA BASE →";
}
document.querySelectorAll("[data-module]").forEach(b=>b.addEventListener("click",()=>openModule(b.dataset.module)));
$("close").addEventListener("click",()=>$("modal").classList.add("hidden"));
$("modal").addEventListener("click",e=>{if(e.target.id==="modal")$("modal").classList.add("hidden")});
$("next").addEventListener("click",()=>$("modal").classList.add("hidden"));
$("reset").addEventListener("click",()=>{if(confirm("¿Seguro que quieres borrar el progreso guardado en este dispositivo?")){state={...defaultState};save()}});
renderStats();
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
