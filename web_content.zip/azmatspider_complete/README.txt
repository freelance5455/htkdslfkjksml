AZMATSPIDER PACKS — BUILD 5 COMPLETION PACKAGE

Start here: SETUP.md
Main app: index.html
Database: supabase/schema.sql
Original Build 5 reference: build5-original.html

Important: backend must be configured and deployed before public accounts, cloud uploads, and cross-user pack syncing work. Never put a Supabase service_role key in the app.
