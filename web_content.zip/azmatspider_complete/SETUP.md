# AzmatSpider Packs — Build 5 completion package

This package contains the Build 5 UI carried forward into a real-backend-ready web app, Supabase database schema, account authentication, admin publishing, cloud file storage, and a feed-based discovery function. It is **not a pre-deployed public service**: no one can see shared packs until you create and configure your own Supabase project.

## Included
- `index.html` — responsive app UI with email/password signup, login/logout, user UUID account identity, public pack catalogue, category/search filters, admin upload/publish/delete, and discovery source controls.
- `supabase/schema.sql` — tables, row-level security, storage bucket and policies.
- `supabase/functions/admin-pin` — checks the admin PIN on the server (PIN is not embedded in the APK).
- `supabase/functions/discover-packs` — imports listing metadata from JSON or RSS feeds that you are allowed to index. It stores the original download link; it does not mirror/copy creators' files.
- `build5-original.html` — the original Build 5 HTML from the Library, kept for reference.

## Required one-time setup
1. Create a Supabase project at https://supabase.com/ (a parent/guardian should help manage the account and any billing settings).
2. Open **SQL Editor** and run `supabase/schema.sql`.
3. Open **Project Settings → API**. Copy the Project URL and anon/public key.
4. In `index.html`, replace `YOUR_SUPABASE_PROJECT_URL` and `YOUR_SUPABASE_ANON_KEY` in the `CONFIG` object. Never put a `service_role` key in this file or in an APK.
5. Deploy the Edge Functions with Supabase CLI from this folder:
   - `supabase functions deploy admin-pin`
   - `supabase secrets set ADMIN_PIN=6266`
   - `supabase functions deploy discover-packs`
6. Sign up for your own account in the app. In Supabase **Authentication → Users**, copy that user's UUID. In SQL Editor run:
   `update public.profiles set is_admin=true where id='PASTE-YOUR-USER-UUID';`
7. Open Admin, sign in, and enter PIN `6266`. Upload a pack file or add a direct HTTPS URL. Published records are visible to all app users.
8. Turn on email confirmation / configure SMTP before public release. Use a strong unique password and never share the admin PIN.

## Automatic discovery
The app accepts public JSON feeds (`[{"title":"Pack name","url":"https://..."}]` or `{ "items": [...] }`) and RSS/Atom feeds. Add only sources whose terms allow indexing and whose entries are genuine Minecraft pack listings. The discovery function imports metadata + source URLs, not the actual files. The **Run discovery now** button triggers a scan. A scheduled background run is not enabled until you configure a scheduler/cron for your Supabase project; there is no universal safe endpoint that can automatically collect every item on the internet.

For creators who explicitly allow redistribution, you can upload the actual file through Admin. For other creators, leave the file hosted at its original source and link to it.

## Android APK
`index.html` is the web app. To ship an Android APK, wrap this configured web app with a trusted Android WebView/Capacitor builder. Rebuild the APK after changing the Supabase URL/key. The APK can be distributed to users, while accounts and published packs stay online in Supabase. Do not put private keys or admin secrets in the APK.

## Important limitations
- This is a deployable starter project, not a live hosted backend or signed APK. Supabase project creation, secrets, admin-role grant, and deployment are required first.
- The discovery importer supports generic JSON/RSS feeds, not every website on the internet. Many sites block automated requests or prohibit scraping/rehosting.
- The original Build 5 file is included unchanged as `build5-original.html`; the new app is `index.html`.
