import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
serve(async (req) => {
  const auth = req.headers.get("Authorization") || "";
  const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: auth } } });
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return Response.json({ error: "Sign in required" }, { status: 401 });
  const { data: profile } = await supabase.from("profiles").select("is_admin").eq("id", user.id).single();
  if (!profile?.is_admin) return Response.json({ error: "Admin only" }, { status: 403 });
  const { data: sources, error } = await supabase.from("discovery_sources").select("*").eq("enabled", true);
  if (error) return Response.json({ error: error.message }, { status: 500 });
  let imported = 0, skipped = 0; const issues: string[] = [];
  for (const source of sources || []) {
    try {
      const response = await fetch(source.feed_url, { headers: { "User-Agent": "AzmatSpiderPacks/1.0" } });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const raw = await response.text(); let entries: any[] = [];
      if (source.format === "json") {
        const parsed = JSON.parse(raw); entries = Array.isArray(parsed) ? parsed : (parsed.items || parsed.entries || []);
      } else {
        // Minimal RSS/Atom metadata parser. It imports only externally hosted links.
        const blocks = raw.match(/<(item|entry)\b[\s\S]*?<\/(item|entry)>/gi) || [];
        entries = blocks.map((block) => ({
          title: (block.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] || "").replace(/<!\[CDATA\[|\]\]>/g, "").trim(),
          url: block.match(/<link[^>]*>(https?:[^<]+)<\/link>/i)?.[1] || block.match(/<link[^>]+href=["']([^"']+)/i)?.[1] || "",
          description: (block.match(/<description[^>]*>([\s\S]*?)<\/description>/i)?.[1] || "").replace(/<[^>]+>/g, " ").slice(0,500)
        }));
      }
      for (const e of entries.slice(0,100)) {
        const name = String(e.name || e.title || "").trim();
        const url = String(e.download_url || e.url || e.link || "").trim();
        if (!name || !/^https:\/\//i.test(url)) { skipped++; continue; }
        const { data: exists } = await supabase.from("packs").select("id").eq("download_url", url).maybeSingle();
        if (exists) { skipped++; continue; }
        const { error: insertError } = await supabase.from("packs").insert({ name, category: e.category || "Addons", edition: e.edition || "Bedrock", version: e.version || "Version varies", description: e.description || "Imported pack listing. Check source for details.", download_url: url, published: true, owner_id: user.id, source_name: source.name, license_note: source.license_note });
        if (insertError) skipped++; else imported++;
      }
    } catch (e) { issues.push(`${source.name}: ${String(e)}`); }
  }
  return Response.json({ imported, skipped, sources: sources?.length || 0, issues });
});
