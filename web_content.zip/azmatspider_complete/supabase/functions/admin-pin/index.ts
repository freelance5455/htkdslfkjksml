import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const expected = Deno.env.get("ADMIN_PIN");
  if (!expected) return Response.json({ ok: false, error: "ADMIN_PIN secret is not configured" }, { status: 500 });
  const body = await req.json().catch(() => ({}));
  return Response.json({ ok: typeof body.pin === "string" && body.pin === expected });
});
