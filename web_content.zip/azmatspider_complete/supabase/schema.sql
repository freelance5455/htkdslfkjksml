-- Run in Supabase SQL Editor. Create a Supabase project first.
create extension if not exists pgcrypto;
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 username text unique,
 is_admin boolean not null default false,
 created_at timestamptz not null default now()
);
create table if not exists public.packs (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 category text not null check (category in ('Mods','Addons','Maps','Shaders','Texture Packs','Resource Packs','Skins','Worlds','Behavior Packs')),
 edition text not null check (edition in ('Java','Bedrock','Both','PE')),
 version text,
 description text,
 file_path text,
 download_url text,
 image_url text,
 published boolean not null default false,
 owner_id uuid references auth.users(id) on delete set null,
 source_name text,
 license_note text,
 created_at timestamptz not null default now(),
 constraint pack_has_download check (file_path is not null or download_url is not null)
);
create table if not exists public.discovery_sources (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 feed_url text not null,
 format text not null default 'json' check (format in ('json','rss')),
 license_note text not null,
 enabled boolean not null default true,
 owner_id uuid references auth.users(id) on delete set null,
 created_at timestamptz not null default now()
);
create table if not exists public.favorites (
 user_id uuid references auth.users(id) on delete cascade,
 pack_id uuid references public.packs(id) on delete cascade,
 created_at timestamptz not null default now(),
 primary key(user_id,pack_id)
);
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.profiles(id,username) values(new.id, nullif(new.raw_user_meta_data->>'username','')); return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
alter table public.profiles enable row level security;
alter table public.packs enable row level security;
alter table public.discovery_sources enable row level security;
alter table public.favorites enable row level security;
drop policy if exists "profiles read self" on public.profiles;
create policy "profiles read self" on public.profiles for select to authenticated using (id=auth.uid() or exists(select 1 from public.profiles me where me.id=auth.uid() and me.is_admin));
-- Profile role is intentionally not user-editable; grant admin only from SQL/dashboard.
drop policy if exists "public read published packs" on public.packs;
create policy "public read published packs" on public.packs for select to anon,authenticated using (published=true or exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin));
drop policy if exists "admin insert packs" on public.packs;
create policy "admin insert packs" on public.packs for insert to authenticated with check (exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin));
drop policy if exists "admin update packs" on public.packs;
create policy "admin update packs" on public.packs for update to authenticated using (exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin)) with check (exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin));
drop policy if exists "admin delete packs" on public.packs;
create policy "admin delete packs" on public.packs for delete to authenticated using (exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin));
drop policy if exists "admin manage sources" on public.discovery_sources;
create policy "admin manage sources" on public.discovery_sources for all to authenticated using (exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin)) with check (exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin));
drop policy if exists "users manage own favorites" on public.favorites;
create policy "users manage own favorites" on public.favorites for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('packs','packs',true,524288000,array['application/octet-stream','application/zip','application/java-archive','application/x-zip-compressed','application/x-mcpack','application/x-mcaddon','application/x-mcworld','application/zip']) on conflict(id) do nothing;
drop policy if exists "public read pack files" on storage.objects;
create policy "public read pack files" on storage.objects for select to anon,authenticated using (bucket_id='packs');
drop policy if exists "admin upload pack files" on storage.objects;
create policy "admin upload pack files" on storage.objects for insert to authenticated with check (bucket_id='packs' and exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin));
drop policy if exists "admin delete pack files" on storage.objects;
create policy "admin delete pack files" on storage.objects for delete to authenticated using (bucket_id='packs' and exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin));
-- After creating your account, replace YOUR_USER_UUID with your auth.users id:
-- update public.profiles set is_admin=true where id='YOUR_USER_UUID';
