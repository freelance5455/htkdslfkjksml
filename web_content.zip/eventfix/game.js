function buyStarItem(type){
  const costs={revive:20,double:35,time:50,shield:70};
  const names={revive:"Vida extra",double:"Multiplicador de pontos",time:"Tempo Supremo",shield:"Escudo Supremo"};
  const inventoryMap={revive:"life",double:"double",time:"time",shield:"shield"};
  const max={revive:5,double:9,time:5,shield:9};
  const cost=costs[type], invId=inventoryMap[type];
  if(!cost||!invId)return;
  state.stars=Number(state.stars)||0;
  state.inventory=state.inventory||{};
  const have=Number(state.inventory[invId])||0;
  if(state.stars<cost){ecoNotify("⭐ Estrelas insuficientes!","Você precisa de "+cost+" estrelas.");return;}
  if(have>=max[type]){ecoNotify("📦 Limite atingido!","Você já possui o máximo desse item.");return;}
  state.stars-=cost;
  state.inventory[invId]=have+1;
  save();renderAll();sound("win");ecoNotify("⭐ Compra realizada!",names[type]+" adquirido.");
}function ecoNotify(title,message){const box=document.getElementById("ecoNotifications");if(!box)return;const n=document.createElement("div");n.className="eco-notify";n.innerHTML="<b>"+title+"</b><span>"+message+"</span>";box.appendChild(n);setTimeout(()=>n.remove(),4200);}
const phases=[
{name:"🏫 Escola Sustentável",icon:"🏫",difficulty:"DIFÍCIL",time:48,lives:3,items:18,desc:"Organize a escola antes do sinal.",pool:[["📄","Folha","blue"],["📚","Livro","blue"],["📦","Caixa","blue"],["🧴","Garrafa PET","red"],["🥤","Copo plástico","red"],["🛍️","Sacola","red"],["🍾","Garrafa de vidro","green"],["🫙","Pote de vidro","green"],["🥫","Lata","yellow"]]},
{name:"🌳 Praça Central",icon:"🌳",difficulty:"DIFÍCIL",time:43,lives:3,items:22,desc:"A praça está cheia de resíduos.",pool:[["📰","Jornal","blue"],["📦","Papelão","blue"],["📄","Papel","blue"],["🧴","PET","red"],["🛍️","Plástico","red"],["🥤","Embalagem","red"],["🍾","Vidro","green"],["🫙","Pote","green"],["🥫","Lata","yellow"],["🥤","Metal","yellow"]]},
{name:"🧺 Feira",icon:"🧺",difficulty:"EXTREMO",time:39,lives:2,items:26,desc:"Pouco tempo e muito movimento.",pool:[["📦","Caixa","blue"],["📰","Folheto","blue"],["📄","Papel","blue"],["🧴","Embalagem PET","red"],["🛍️","Sacola","red"],["🧃","Plástico","red"],["🍾","Garrafa","green"],["🫙","Vidro","green"],["🥫","Metal","yellow"],["🥤","Lata","yellow"]]},
{name:"🏙️ Centro Urbano",icon:"🏙️",difficulty:"EXTREMO",time:36,lives:2,items:30,desc:"O trânsito não para. Você também não.",pool:[["📰","Papel","blue"],["📦","Papelão","blue"],["📄","Revista","blue"],["🧴","Plástico","red"],["🛍️","Sacola","red"],["🧃","PET","red"],["🍾","Vidro","green"],["🫙","Pote","green"],["🥫","Metal","yellow"],["🥤","Lata","yellow"]]},
{name:"🏭 Zona Industrial",icon:"🏭",difficulty:"INSANO",time:33,lives:1,items:35,desc:"Uma falha pode acabar com tudo.",pool:[["📦","Papelão","blue"],["📰","Papel","blue"],["📄","Folha","blue"],["🧴","PET","red"],["🛍️","Plástico","red"],["🧃","Embalagem","red"],["🍾","Vidro","green"],["🫙","Pote","green"],["🥫","Metal","yellow"],["🥤","Lata","yellow"]]},
{name:"🌎 Desafio Brasil",icon:"🌎",difficulty:"PESADÍSSIMO",time:31,lives:1,items:42,desc:"A prova final da campanha.",pool:[["📦","Papelão","blue"],["📰","Papel","blue"],["📄","Papel","blue"],["🧴","PET","red"],["🛍️","Plástico","red"],["🧃","Plástico","red"],["🍾","Vidro","green"],["🫙","Vidro","green"],["🥫","Metal","yellow"],["🥤","Metal","yellow"]]}
];
const shopItems=[
{id:"life",icon:"❤️",name:"Vida Extra",price:650,desc:"+1 vida na próxima missão.",max:5},
{id:"shield",icon:"🛡️",name:"Escudo",price:500,desc:"Anula um erro sem perder a fase.",max:9},
{id:"double",icon:"⭐",name:"Estrela Dourada",price:750,desc:"Dobra pontos dos próximos 5 acertos.",max:9},
{id:"time",icon:"⏱️",name:"Tempo Extra",price:900,desc:"+6 segundos no início da missão.",max:5},
{id:"magnet",icon:"🧲",name:"Ímã de Moedas",price:750,desc:"+2 moedas por 6 acertos.",max:9},
{id:"heart",icon:"💚",name:"Coração Eco",price:900,desc:"Recupera 1 vida uma vez na missão.",max:5}
];
const missions=[
{id:"m1",icon:"♻️",name:"Primeira separação",desc:"Acerte 10 resíduos.",goal:10,reward:25,type:"correct"},
{id:"m2",icon:"🔥",name:"Combo de respeito",desc:"Faça uma sequência de 8 acertos.",goal:8,reward:40,type:"streak"},
{id:"m3",icon:"🪙",name:"Catador de moedas",desc:"Ganhe 100 moedas.",goal:100,reward:60,type:"coins"},
{id:"m4",icon:"🏁",name:"Maratona",desc:"Conclua 3 fases.",goal:3,reward:80,type:"wins"},
{id:"m5",icon:"🏆",name:"Campanha completa",desc:"Desbloqueie todas as fases.",goal:6,reward:150,type:"unlocked"}
];
const achievements=[
{id:"a1",icon:"🌱",name:"Começo Verde",desc:"Conclua sua primeira fase.",type:"wins",goal:1},
{id:"a2",icon:"🔥",name:"Combo 8",desc:"Alcance 8 acertos seguidos.",type:"bestStreak",goal:8},
{id:"a3",icon:"💰",name:"Economista",desc:"Junte 250 moedas.",type:"coins",goal:250},
{id:"a4",icon:"🌎",name:"Explorador",desc:"Desbloqueie todas as áreas.",type:"unlocked",goal:6},
{id:"a5",icon:"⚡",name:"Precisão",desc:"Conclua uma fase com 100% de acerto.",type:"perfect",goal:1},
{id:"a6",icon:"👑",name:"Lenda da Coleta",desc:"Conclua 10 fases.",type:"wins",goal:10}
];
let state={score:0,stars:0,coins:0,trophies:0,level:1,unlocked:1,wins:0,bestStreak:0,perfect:0,totalCorrect:0,totalAnswered:0,inventory:{life:0,shield:0,double:0,time:0,magnet:0,heart:0},claimedMissions:{},unlockedAchievements:{},settings:{music:true,sound:true,vibe:true}};
let game=null,timerId=null,musicCtx=null,musicTimer=null;
window.state=state;
window.replaceStateFromCloud=function(cloud){ if(!cloud||typeof cloud!=="object")return; state={...state,...cloud,inventory:{...state.inventory,...(cloud.inventory||{})},settings:{...state.settings,...(cloud.settings||{})}}; window.state=state; save(); renderAll(); };


function $(id){return document.getElementById(id)}
function save(){localStorage.setItem("ecoColetaV2",JSON.stringify(state));window.state=state;if(window.ecoOnline?.connected)window.ecoOnline.saveCloud().catch(()=>{});if(window.lanOnline?.publish)window.lanOnline.publish();}
function load(){
 try{
  let s=JSON.parse(localStorage.getItem("ecoColetaV2"));
  if(s)state={...state,...s,inventory:{...state.inventory,...(s.inventory||{})},settings:{...state.settings,...(s.settings||{})}};
  if(typeof state.stars!=="number"||!Number.isFinite(state.stars))state.stars=Number(state.score)||0;
 }catch(e){state.stars=Number(state.stars)||Number(state.score)||0}
}
function show(id){document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));$(id).classList.add("active");window.scrollTo({top:0,behavior:"smooth"});renderAll();if(id==="settings")syncSettings()}
function toast(t){let e=$("toast");e.textContent=t;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),1800)}
function sound(kind="ok"){
 if(!state.settings.sound)return;
 try{let c=new (window.AudioContext||window.webkitAudioContext)(),o=c.createOscillator(),g=c.createGain();o.frequency.value=kind==="bad"?150:kind==="win"?700:520;o.type=kind==="bad"?"sawtooth":"sine";g.gain.value=.045;o.connect(g);g.connect(c.destination);o.start();o.stop(c.currentTime+.12)}catch(e){}
}
function startMusic(){
 if(!state.settings.music||musicCtx)return;
 try{musicCtx=new (window.AudioContext||window.webkitAudioContext)();let c=musicCtx;
   let notes=[261.63,329.63,392,329.63,293.66,349.23,440,349.23],i=0;
   function tick(){if(!musicCtx)return;let o=c.createOscillator(),g=c.createGain();o.type="triangle";o.frequency.value=notes[i++%notes.length];g.gain.setValueAtTime(.012,c.currentTime);g.gain.exponentialRampToValueAtTime(.001,c.currentTime+.45);o.connect(g);g.connect(c.destination);o.start();o.stop(c.currentTime+.46)}
   tick();musicTimer=setInterval(tick,480)
 }catch(e){}
}
function stopMusic(){if(musicTimer)clearInterval(musicTimer);musicTimer=null;if(musicCtx){musicCtx.close();musicCtx=null}}
function vibe(ms=35){if(state.settings.vibe&&navigator.vibrate)navigator.vibrate(ms)}
function toggleSetting(k){state.settings[k]=!state.settings[k];save();syncSettings();if(k==="music")state.settings.music?startMusic():stopMusic();toast(state.settings[k]?"Ativado":"Desativado")}
function syncSettings(){["music","sound","vibe"].forEach(k=>{let e=$(k+"Switch");e.classList.toggle("on",!!state.settings[k])})}

function renderAll(){renderStats();renderMap();renderMissions();renderAchievements();renderShop();updateCampaign()}
function renderStats(){
 $("stars").textContent=Math.max(0,Math.floor(Number(state.stars)||0));
 $("coins").textContent=state.coins;
 $("trophies").textContent=state.trophies;
 $("playerLevel").textContent=state.level;
 $("shopStars").textContent=Math.max(0,Math.floor(Number(state.stars)||0));
 $("shopCoins").textContent=state.coins;
}
function updateCampaign(){let p=Math.min(100,(state.unlocked-1)/phases.length*100);$("campProg").style.width=p+"%";$("campText").textContent=`${Math.max(0,state.unlocked-1)} de ${phases.length} áreas liberadas • ${state.wins} vitórias`}
function renderMap(){
 let e=$("levels");e.innerHTML="";
 phases.forEach((p,i)=>{let unlocked=i<state.unlocked,c=document.createElement("div");c.className="card level"+(unlocked?"":" locked");let d=unlocked?`<button class="btn primary" onclick="startGame(${i})">Jogar</button>`:`<button class="btn" disabled>🔒 Bloqueada</button>`;c.innerHTML=`<div><div class="icon">${p.icon}</div><div style="margin-top:6px"><span class="tag ${i>=5?"boss":i>=3?"insane":i>=2?"extreme":""}">${p.difficulty}</span></div><h3>${p.name}</h3><p class="small">${p.desc}</p></div><div><div class="small">⏱️ ${p.time}s • ❤️ ${p.lives} • 📦 ${p.items} resíduos</div><div class="progress"><i style="width:${unlocked?100:0}%"></i></div>${d}</div>`;e.appendChild(c)})
}
function renderMissions(){
 let e=$("missionList");e.innerHTML="";
 missions.forEach(m=>{let val=missionValue(m.type),done=val>=m.goal,claimed=!!state.claimedMissions[m.id],c=document.createElement("div");c.className="row "+(done?"done":"");c.innerHTML=`<div class="ico">${m.icon}</div><div style="flex:1"><b>${m.name}</b><div class="small">${m.desc}</div><div class="progress"><i style="width:${Math.min(100,val/m.goal*100)}%"></i></div><div class="small">${Math.min(val,m.goal)} / ${m.goal} • +${m.reward} 🪙</div></div><button class="btn ${done&&!claimed?"gold":"ghost"}" ${!done||claimed?"disabled":""} onclick="claimMission('${m.id}')">${claimed?"✓":"Resgatar"}</button>`;e.appendChild(c)})
}
function missionValue(t){return t==="correct"?state.totalCorrect:t==="streak"?state.bestStreak:t==="coins"?state.coins:t==="wins"?state.wins:t==="unlocked"?state.unlocked:0}
function claimMission(id){let m=missions.find(x=>x.id===id);if(!m||state.claimedMissions[id]||missionValue(m.type)<m.goal)return;state.claimedMissions[id]=1;state.coins+=m.reward;state.score+=50;state.stars+=50;toast(`🎯 Missão concluída! +${m.reward} moedas`);sound("win");save();renderAll()}
function renderAchievements(){
 let e=$("achievementList");e.innerHTML="";
 achievements.forEach(a=>{let val=a.type==="wins"?state.wins:a.type==="bestStreak"?state.bestStreak:a.type==="coins"?state.coins:a.type==="unlocked"?state.unlocked:a.type==="perfect"?state.perfect:0,done=val>=a.goal,claimed=!!state.unlockedAchievements[a.id];if(done&&!claimed){state.unlockedAchievements[a.id]=1;state.trophies++;state.coins+=20;save();setTimeout(()=>toast(`🏆 Conquista: ${a.name} +20🪙`),80)}let c=document.createElement("div");c.className="card achievement "+(done?"unlocked":"");c.innerHTML=`<div class="shopicon">${a.icon}</div><h3>${a.name}</h3><p class="small">${a.desc}</p><span class="tag">${done?"DESBLOQUEADA":"EM PROGRESSO"} • ${Math.min(val,a.goal)}/${a.goal}</span>`;e.appendChild(c)})
}
function renderShop(){
 let e=$("shopList");e.innerHTML="";
 shopItems.forEach(s=>{let have=state.inventory[s.id]||0,c=document.createElement("div");c.className="card shopitem";c.innerHTML=`<div><div class="shopicon">${s.icon}</div><h3>${s.name}</h3><p class="small">${s.desc}</p></div><div><div class="price">🪙 ${s.price} • Possui: ${have}</div><button class="btn gold" style="width:100%;margin-top:8px" ${state.coins<s.price||have>=s.max?"disabled":""} onclick="buy('${s.id}')">${have>=s.max?"Máximo":"Comprar"}</button></div>`;e.appendChild(c)})
}
function buy(id){let s=shopItems.find(x=>x.id===id);if(!s||state.coins<s.price||(state.inventory[id]||0)>=s.max)return;state.coins-=s.price;state.inventory[id]=(state.inventory[id]||0)+1;save();toast(`🛒 ${s.name} comprado!`);sound("win");renderAll()}

function makeRound(pool,n){let a=[];for(let i=0;i<n;i++)a.push(pool[Math.floor(Math.random()*pool.length)]);return a}
function startGame(index){
 if(index>=state.unlocked)return;
 stopMusic();
 let p=phases[index],rounds=makeRound(p.pool,p.items),lives=p.lives+(state.inventory.life?1:0),time=p.time+(state.inventory.time?6:0);
 if(state.inventory.life)state.inventory.life--;if(state.inventory.time)state.inventory.time--;
 game={index,p,rounds,pos:0,lives,timeLeft:time,streak:0,shield:state.inventory.shield,double:state.inventory.double,magnet:state.inventory.magnet,heart:state.inventory.heart,answered:0,correct:0,started:Date.now()};
 state.totalAnswered=state.totalAnswered;save();
 $("phaseName").textContent=p.name;$("difficultyText").textContent=`${p.difficulty} • ${p.items} resíduos`;show("game");nextRound();clearInterval(timerId);timerId=setInterval(tick,1000);sound("win");startMusic()
}
function nextRound(){
 if(!game)return;
 if(game.pos>=game.rounds.length){winGame();return}
 let it=game.rounds[game.pos];$("wasteEmoji").textContent=it[0];$("wasteName").textContent=it[1];$("roundTag").textContent=`${game.pos+1}/${game.rounds.length}`;$("lives").textContent=game.lives;$("streak").textContent=game.streak;$("levelProg").style.width=(game.pos/game.rounds.length*100)+"%";$("feedback").textContent="";$("comboText").textContent=game.streak>=3?`🔥 Sequência x${game.streak}`:"";$("shieldCount").textContent=game.shield;$("doubleCount").textContent=game.double}
function tick(){if(!game)return;game.timeLeft--;let s=Math.max(0,game.timeLeft);$("timer").textContent=`00:${String(s).padStart(2,"0")}`;$("timer").classList.toggle("danger",s<=8);if(s<=0)loseGame("⏱️ Tempo esgotado!")}
function answer(type){
 if(!game)return;
 let it=game.rounds[game.pos],ok=type===it[2];game.answered++;state.totalAnswered++;
 if(ok){
   game.correct++;game.streak++;state.totalCorrect++;state.bestStreak=Math.max(state.bestStreak,game.streak);
   let pts=100+game.streak*15;if(game.double>0){pts*=2;game.double--}let coins=2+(game.streak>=5?2:0);if(game.magnet>0){coins+=2;game.magnet--}
   state.score+=pts;state.stars+=pts;state.coins+=coins;game.pos++;
   $("feedback").innerHTML=`<span class="oktext">✅ Correto! +${pts}⭐ +${coins}🪙</span>`;sound("ok");vibe(25);
   if(game.streak>=5)toast(`🔥 Combo x${game.streak}!`);
   save();checkLevel();setTimeout(nextRound,110);
 }else{
   game.streak=0;
   if(game.shield>0){game.shield--;$("feedback").innerHTML=`<span class="dangertext">🛡️ Escudo ativado! Você continua.</span>`;sound("bad");vibe(70);save();setTimeout(nextRound,180);return}
   game.lives--;sound("bad");vibe(120);
   if(game.lives<=0){loseGame("💥 Você ficou sem vidas!");return}
   $("feedback").innerHTML=`<span class="dangertext">❌ Separação errada! Vida perdida.</span>`;$("lives").textContent=game.lives;setTimeout(nextRound,280)
 }
}

setInterval(()=>{if(window.lanOnline&&window.game)window.lanOnline.publish()},250);
function useBoost(id){
 if(!game)return toast("Jogue uma fase para usar equipamentos.");
 if(id==="shield"&&game.shield>0){game.shield--;toast("🛡️ Escudo equipado");}
 else if(id==="double"&&game.double>0){game.double--;toast("⭐ Bônus ativado");}
 else toast("Você não possui esse item.");
 save();nextRound()
}
function checkLevel(){let n=1+Math.floor(state.score/1500);if(n>state.level){state.level=n;toast(`⬆️ Nível ${n}!`)}}
function winGame(){
 if(!game)return;clearInterval(timerId);timerId=null;stopMusic();
 let perfect=game.correct===game.answered;state.wins++;if(perfect)state.perfect++;
 let winStars=100+game.streak*10;state.score+=winStars;state.stars+=winStars;state.coins+=35+game.p.items;
 let i=game.index;if(i+1===state.unlocked&&state.unlocked<phases.length)state.unlocked++;
 if(game.lives===game.p.lives&&perfect)state.trophies++;
 state.inventory.heart=Math.max(0,state.inventory.heart);
 save();sound("win");renderAll();
 openModal(perfect?"🏆":"🎉",perfect?"FASE PERFEITA!":"MISSÃO CONCLUÍDA!",`${game.p.name}<br><br>Acertos: ${game.correct}/${game.rounds.length}<br>⭐ +${winStars} • 🪙 +${35+game.p.items}${perfect?"<br><br>🏆 Troféu de precisão!":""}`);
 game=null
}
function loseGame(msg){if(!game)return;clearInterval(timerId);timerId=null;stopMusic();openModal("💥","MISSÃO FALHOU",`${msg}<br><br>Você chegou a ${game.pos}/${game.rounds.length} resíduos.<br>Não desista: tente de novo.`);sound("bad");game=null}
function confirmExit(){if(!game)return;clearInterval(timerId);timerId=null;stopMusic();game=null;show("map");toast("↩️ Você saiu da missão.")}
function openModal(icon,title,text){$("modalIcon").textContent=icon;$("modalTitle").textContent=title;$("modalText").innerHTML=text;$("modal").classList.add("show")}
function closeModal(){$("modal").classList.remove("show");show("map")}
function resetGame(){
 if(!confirm("Apagar TODO o progresso, moedas, troféus, compras, conquistas e fases desbloqueadas?"))return;
 try{
  localStorage.removeItem("ecoColetaV2");
  localStorage.removeItem("ecoColeta");
 }catch(e){}
 state={score:0,stars:0,coins:0,trophies:0,level:1,unlocked:1,wins:0,bestStreak:0,perfect:0,totalCorrect:0,totalAnswered:0,inventory:{life:0,shield:0,double:0,time:0,magnet:0,heart:0},claimedMissions:{},unlockedAchievements:{},settings:{music:true,sound:true,vibe:true}};
 game=null;timerId=null;stopMusic();
 try{ sessionStorage.clear(); }catch(e){}
 toast("🗑️ Progresso apagado! Recarregando...");
 setTimeout(()=>location.reload(),120);
}

load();renderAll();syncSettings();
setTimeout(()=>{let b=$("loadbar"),t=$("loadtext");let n=0,id=setInterval(()=>{n+=10;b.style.width=n+"%";t.textContent=`Carregando ${n}%`;if(n>=100){clearInterval(id);setTimeout(()=>{ $("loading").classList.add("hidden");},220)}},45)},100);
document.addEventListener("click",()=>{if(state.settings.music)startMusic()},{once:true});
