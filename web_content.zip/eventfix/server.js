const http=require('http');
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const WebSocket=require('ws');
const ROOT=__dirname;
const PORT=Number(process.env.PORT||8080);
const rooms=new Map();
const MAX_PLAYERS=8;
const MAX_NAME=18;
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.txt':'text/plain; charset=utf-8'};
function code(){let s='';do{s=crypto.randomBytes(3).toString('hex').toUpperCase()}while(rooms.has(s));return s}
function send(ws,o){if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify(o));}
function roomView(r,me){return {code:r.code,phase:r.phase,started:r.started,players:[...r.players.values()].map(p=>({id:p.id,name:p.name,host:p.id===r.host,status:p.status,score:p.score,stars:p.stars,round:p.round,lives:p.lives,correct:p.correct,finished:p.finished})) ,isHost:r.host===me};}
function broadcast(r){for(const p of r.players.values())send(p.ws,{type:'room',room:roomView(r,p.id)});}
function leave(ws){const r=ws.room;if(!r)return;r.players.delete(ws.pid);if(r.host===ws.pid){const n=r.players.values().next().value;r.host=n?n.id:null;}if(r.players.size===0)rooms.delete(r.code);else broadcast(r);ws.room=null;ws.pid=null;}
const server=http.createServer((req,res)=>{let u=new URL(req.url,'http://localhost');let file=u.pathname==='/'?'/index.html':u.pathname;if(file.includes('..'))return res.writeHead(400).end();let fp=path.join(ROOT,file);fs.readFile(fp,(e,d)=>{if(e)return res.writeHead(404).end('Not found');res.writeHead(200,{'Content-Type':mime[path.extname(fp)]||'application/octet-stream','Cache-Control':'no-cache'});res.end(d);});});
const wss=new WebSocket.Server({noServer:true});
wss.on('connection',ws=>{ws.pid=crypto.randomUUID();send(ws,{type:'welcome',id:ws.pid});ws.on('message',raw=>{let m;try{m=JSON.parse(raw)}catch{return}
 if(m.type==='create'){leave(ws);const r={code:code(),host:ws.pid,phase:0,started:false,players:new Map()};rooms.set(r.code,r);ws.room=r;ws.name=String(m.name||'Jogador Eco').replace(/[<>]/g,'').trim().slice(0,MAX_NAME)||'Jogador Eco';r.players.set(ws.pid,{id:ws.pid,name:ws.name,host:true,status:'waiting',score:0,stars:0,round:0,lives:0,correct:0,finished:false,ws});broadcast(r);}
 else if(m.type==='join'){leave(ws);const codeIn=String(m.code||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,6);const r=rooms.get(codeIn);if(!r)return send(ws,{type:'error',message:'Sala não encontrada.'});if(r.players.size>=MAX_PLAYERS)return send(ws,{type:'error',message:'Sala cheia (máximo 8 jogadores).'});ws.room=r;ws.name=String(m.name||'Jogador Eco').replace(/[<>]/g,'').trim().slice(0,MAX_NAME)||'Jogador Eco';r.players.set(ws.pid,{id:ws.pid,name:ws.name,status:r.started?'playing':'waiting',score:0,stars:0,round:0,lives:0,correct:0,finished:false,ws});broadcast(r);}
 else if(m.type==='state'&&ws.room){const p=ws.room.players.get(ws.pid);if(p){p.score=Math.max(0,Number(m.score)||0);p.stars=Math.max(0,Number(m.stars)||0);p.round=Math.max(0,Number(m.round)||0);p.lives=Math.max(0,Number(m.lives)||0);p.correct=Math.max(0,Number(m.correct)||0);p.finished=!!m.finished;p.status=m.status==='playing'?'playing':m.status==='finished'?'finished':'waiting';broadcast(ws.room);}}
 else if(m.type==='start'&&ws.room&&ws.room.host===ws.pid){const rawPhase=Number(m.phase);const phase=Number.isFinite(rawPhase)?Math.max(0,Math.min(5,Math.floor(rawPhase))):0;ws.room.phase=phase;ws.room.started=true;for(const p of ws.room.players.values()){p.status='playing';p.round=0;p.lives=0;p.correct=0;p.score=0;p.stars=0;p.finished=false;send(p.ws,{type:'start',phase,players:roomView(ws.room,p.id).players});}broadcast(ws.room);}
 else if(m.type==='finish'&&ws.room){const p=ws.room.players.get(ws.pid);if(p){p.finished=true;p.status='finished';broadcast(ws.room);const allDone=[...ws.room.players.values()].every(x=>x.finished);if(allDone){ws.room.started=false;for(const x of ws.room.players.values()){x.status='waiting';x.finished=false;}broadcast(ws.room);}}}
 });ws.on('close',()=>leave(ws));});
const heartbeat=setInterval(()=>{for(const ws of wss.clients){if(ws.isAlive===false){ws.terminate();continue}ws.isAlive=false;ws.ping();}},30000);wss.on('connection',ws=>{ws.isAlive=true;ws.on('pong',()=>{ws.isAlive=true;});});
server.on('upgrade',(req,socket,head)=>{if(req.url!=='/ws')return socket.destroy();wss.handleUpgrade(req,socket,head,ws=>wss.emit('connection',ws,req));});
server.listen(PORT,'0.0.0.0',()=>console.log(`EcoColeta Multiplayer em http://0.0.0.0:${PORT}`));
