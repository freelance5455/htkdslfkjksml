const $ = id => document.getElementById(id);
const bn = s => String(s).replace(/\d/g, d => "০১২৩৪৫৬৭৮৯"[d]);

// ঘড়ি — Asia/Dhaka
const tf = new Intl.DateTimeFormat("en-GB", {timeZone:"Asia/Dhaka", hour:"2-digit", minute:"2-digit", second:"2-digit", hour12:false});
const df = new Intl.DateTimeFormat("bn-BD", {timeZone:"Asia/Dhaka", weekday:"long", day:"numeric", month:"long", year:"numeric"});
function tick(){
  const now = new Date();
  let [h,m,s] = tf.format(now).split(":").map(Number);
  const pm = h >= 12; h = h % 12 || 12;
  $("time").textContent = bn(`${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`);
  $("ampm").textContent = pm ? "PM" : "AM";
  $("date").textContent = df.format(now);
}
tick(); setInterval(tick, 250);

// ট্যাব
function show(tab){
  const c = tab === "clock";
  $("clock").hidden = !c; $("sw").hidden = c;
  $("tab-clock").setAttribute("aria-selected", c);
  $("tab-sw").setAttribute("aria-selected", !c);
}
$("tab-clock").onclick = () => show("clock");
$("tab-sw").onclick = () => show("sw");

// স্ক্রিন সব সময় চালু রাখা (Wake Lock) — স্টপওয়াচ চললে
let wakeLock = null;
async function keepAwake(){
  try{
    if("wakeLock" in navigator && !wakeLock){
      wakeLock = await navigator.wakeLock.request("screen");
      wakeLock.addEventListener("release", () => { wakeLock = null; });
    }
  }catch(e){ /* সাপোর্ট নেই বা অনুমতি পাওয়া যায়নি */ }
}
function releaseAwake(){
  if(wakeLock){ wakeLock.release().catch(()=>{}); wakeLock = null; }
}
// ট্যাবে ফিরে এলে আবার লক নেওয়া + সময় সঙ্গে সঙ্গে আপডেট
document.addEventListener("visibilitychange", () => {
  if(document.visibilityState === "visible" && running){
    keepAwake();
    $("swTime").textContent = fmt(elapsed + Date.now() - start);
  }
});

// স্টপওয়াচ
let running = false, start = 0, elapsed = 0, raf, lastLap = 0, laps = [];
const fmt = ms => {
  const cs = Math.floor(ms/10)%100, s = Math.floor(ms/1000)%60, m = Math.floor(ms/60000);
  const p = n => String(n).padStart(2,"0");
  return bn(`${p(m)}:${p(s)}.${p(cs)}`);
};
function loop(){
  $("swTime").textContent = fmt(elapsed + Date.now() - start);
  raf = requestAnimationFrame(loop);
}
$("startBtn").onclick = () => {
  if(!running){
    running = true; start = Date.now(); loop(); keepAwake();
    $("startBtn").textContent = "থামুন"; $("startBtn").classList.add("running");
    $("lapBtn").disabled = false; $("resetBtn").disabled = true;
  } else {
    running = false; cancelAnimationFrame(raf); elapsed += Date.now() - start; releaseAwake();
    $("swTime").textContent = fmt(elapsed);
    $("startBtn").textContent = "চালু করুন"; $("startBtn").classList.remove("running");
    $("lapBtn").disabled = true; $("resetBtn").disabled = false;
  }
};
$("lapBtn").onclick = () => {
  const total = elapsed + Date.now() - start;
  laps.unshift({n: laps.length+1, split: total-lastLap, total}); lastLap = total;
  $("laps").innerHTML = laps.map(l => `<li><span>ল্যাপ ${bn(l.n)}</span><span>${fmt(l.split)}</span><span>${fmt(l.total)}</span></li>`).join("");
};
$("resetBtn").onclick = () => {
  elapsed = 0; lastLap = 0; laps = []; $("laps").innerHTML = "";
  $("swTime").textContent = fmt(0); $("resetBtn").disabled = true;
  $("startBtn").textContent = "শুরু";
};
$("swTime").textContent = fmt(0);
