plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// توقيع النسخة النهائية: إن وُجد مفتاح خاص (متغيرات البيئة) يُستخدم، وإلا يُستخدم مفتاح التصحيح (يصلح للتثبيت المباشر).
val ksFile: String? = System.getenv("KEYSTORE_FILE")

android {
    namespace = "com.baraket.elhai"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.baraket.elhai"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    signingConfigs {
        if (ksFile != null) {
            create("release") {
                storeFile = file(ksFile)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = if (ksFile != null) signingConfigs.getByName("release") else signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
}
