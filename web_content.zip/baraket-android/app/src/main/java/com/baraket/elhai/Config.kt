package com.baraket.elhai

object Config {
    /** رابط تطبيق الويب على Google Apps Script (يُستخدم للتحقق من تحديثات الواجهة الرسمية). */
    const val API_URL =
        "https://script.google.com/macros/s/AKfycbwMIM78ymhpuLQVD3rtEXDi_pP594XJvi0JpigDbbTCFDLJLpr5pJY7-HM8KIQsB-OE/exec"

    /** نطاق افتراضي آمن يخدمه التطبيق نفسه، وكل نسخ الواجهة تُعرض عليه فتشترك في نفس التخزين المحلي (لا تضيع البيانات عند التحديث). */
    const val APP_HOST = "appassets.androidplatform.net"
    const val APP_URL = "https://$APP_HOST/app/index.html"

    const val MAX_BUNDLE_BYTES = 3_000_000
    const val READY_TIMEOUT_MS = 12_000L          // مهلة إعلان الصفحة الجديدة أنها بدأت سليمة قبل التراجع عنها
    const val RECHECK_MS = 10 * 60 * 1000L        // فحص التحديث أثناء بقاء التطبيق مفتوحًا

    /**
     * true  : عند انقطاع الإنترنت تُستخدم آخر واجهة رسمية محمّلة ومتحقَّق منها (الأنسب لتطابق البيانات)،
     *         وتبقى الواجهة الثابتة المضمّنة شبكة أمان (أول تشغيل بلا إنترنت، أو فشل الواجهة الرسمية).
     * false : عند انقطاع الإنترنت تُستخدم دائمًا الواجهة الثابتة المضمّنة في الـAPK.
     */
    const val OFFLINE_USES_CACHED_OFFICIAL = true

    /** علامة يجب أن تحتويها الواجهة الرسمية (<meta name="app-id" content="baraket-elhai">). */
    const val APP_MARKER = "baraket-elhai"

    const val CSP = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; " +
        "img-src 'self' data:; font-src 'self' data:; connect-src https://script.google.com https://*.googleusercontent.com; " +
        "frame-ancestors 'none'; base-uri 'none'; form-action 'none'"
}
