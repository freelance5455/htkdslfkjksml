package com.baraket.elhai

import android.content.Context
import java.io.ByteArrayInputStream
import java.io.File
import java.io.InputStream
import java.security.MessageDigest

/** يحفظ الواجهة الرسمية المحمّلة (الحالية + السابقة) ويتحقق من سلامتها، ويقدّم الواجهة الثابتة المضمّنة كشبكة أمان. */
class BundleStore(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "bundle").apply { mkdirs() }
    private val prefs = ctx.getSharedPreferences("bundle", Context.MODE_PRIVATE)
    private val cur = File(dir, "current.html")
    private val prev = File(dir, "previous.html")
    private val next = File(dir, "next.html")

    class Served(val stream: InputStream, val sha: String?, val official: Boolean)

    @Synchronized fun currentSha(): String? = prefs.getString("cur_sha", null)
    @Synchronized fun currentBuild(): String? = prefs.getString("cur_build", null)
    @Synchronized fun pendingSha(): String? = prefs.getString("pending_sha", null)
    @Synchronized fun isBad(sha: String): Boolean = (prefs.getStringSet("bad", emptySet()) ?: emptySet()).contains(sha)

    /** يعيد الواجهة الرسمية إن كانت موجودة وسليمة وإلا الواجهة الثابتة. */
    @Synchronized fun serve(preferOfficial: Boolean): Served {
        if (preferOfficial) {
            val sha = currentSha()
            if (sha != null && cur.exists()) {
                val bytes = cur.readBytes()
                if (sha256(bytes) == sha) return Served(ByteArrayInputStream(bytes), sha, true)
            }
        }
        return Served(ctx.assets.open("static/index.html"), null, false)
    }

    fun hasOfficial(): Boolean = currentSha() != null && cur.exists()

    /** يثبّت نسخة رسمية جديدة بعد التحقق من البصمة؛ ويحتفظ بالحالية كنسخة سابقة للتراجع. */
    @Synchronized fun install(html: String, sha: String, build: String): Boolean {
        val bytes = html.toByteArray(Charsets.UTF_8)
        if (sha256(bytes) != sha) return false
        next.writeBytes(bytes)
        if (sha256(next.readBytes()) != sha) { next.delete(); return false }
        val editor = prefs.edit()
        if (cur.exists() && currentSha() != null) {
            cur.copyTo(prev, overwrite = true)
            editor.putString("prev_sha", currentSha()).putString("prev_build", currentBuild())
        }
        if (!next.renameTo(cur)) { next.copyTo(cur, overwrite = true); next.delete() }
        editor.putString("cur_sha", sha).putString("cur_build", build).putString("pending_sha", sha).apply()
        return true
    }

    /** الصفحة الجديدة أعلنت أنها بدأت سليمة. */
    @Synchronized fun confirm(sha: String) {
        if (pendingSha() == sha) prefs.edit().remove("pending_sha").apply()
    }

    /** التراجع: تُعلَّم النسخة سيئة (لا تُحمَّل ثانية) وتُستعاد السابقة، أو الثابتة إن لم توجد. */
    @Synchronized fun rollback(badSha: String) {
        val bad = HashSet(prefs.getStringSet("bad", emptySet()) ?: emptySet()).apply { add(badSha) }
        val e = prefs.edit().putStringSet("bad", bad).remove("pending_sha")
        val pSha = prefs.getString("prev_sha", null)
        if (pSha != null && prev.exists() && sha256(prev.readBytes()) == pSha) {
            prev.copyTo(cur, overwrite = true)
            e.putString("cur_sha", pSha).putString("cur_build", prefs.getString("prev_build", ""))
        } else {
            cur.delete()
            e.remove("cur_sha").remove("cur_build")
        }
        e.apply()
    }

    companion object {
        fun sha256(bytes: ByteArray): String {
            val d = MessageDigest.getInstance("SHA-256").digest(bytes)
            val sb = StringBuilder(d.size * 2)
            for (b in d) sb.append(String.format("%02x", b.toInt() and 0xff))
            return sb.toString()
        }
    }
}
