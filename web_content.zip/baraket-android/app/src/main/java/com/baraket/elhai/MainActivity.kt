package com.baraket.elhai

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.print.PrintAttributes
import android.print.PrintManager
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var store: BundleStore
    private lateinit var checker: UpdateChecker
    private val handler = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()

    @Volatile private var servedSha: String? = null
    @Volatile private var servedOfficial = false
    @Volatile private var currentBuild = ""
    private var checking = false
    private var pendingApply = false
    private var applyUntil = 0L

    private val readyTimeout = Runnable { onReadyTimeout() }
    private val recheck = object : Runnable {
        override fun run() {
            checkForUpdate()
            handler.postDelayed(this, Config.RECHECK_MS)
        }
    }

    private val loader: WebViewAssetLoader by lazy {
        WebViewAssetLoader.Builder()
            .setDomain(Config.APP_HOST)
            .addPathHandler("/app/", AppPathHandler())
            .build()
    }

    // ---------------------------------------------------------------- دورة الحياة

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = BundleStore(this)
        checker = UpdateChecker(this, store)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#F4F7F5"))
        webView = WebView(this)
        root.addView(
            webView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        setContentView(root)

        configureWebView()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = onBack()
        })

        webView.loadUrl(Config.APP_URL)
        checkForUpdate()
        handler.postDelayed(recheck, Config.RECHECK_MS)
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        if (pendingApply) tryApply(0)
        else checkForUpdate()
    }

    override fun onPause() {
        webView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        exec.shutdownNow()
        webView.destroy()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- WebView

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    private fun configureWebView() {
        if ((applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true)
        }
        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true                    // localStorage: يبقى بين تحديثات الواجهة لأن النطاق ثابت
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.setSupportMultipleWindows(true)
        s.javaScriptCanOpenWindowsAutomatically = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.mediaPlaybackRequiresUserGesture = true
        s.userAgentString = s.userAgentString + " BaraketApp/" + versionName()

        webView.addJavascriptInterface(Bridge(), "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.scheme == "https" && u.host == Config.APP_HOST) return false
                openExternal(u)
                return true
            }

            override fun onPageFinished(view: WebView, url: String?) {
                // window.print لا يعمل داخل WebView، فنحوّله إلى طباعة النظام (حفظ PDF من نافذة الطباعة)
                view.evaluateJavascript("window.print=function(){AndroidBridge.print()};", null)
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            // window.open (مثل رابط واتساب الاحتياطي) يُفتح في التطبيق المناسب لا داخل الواجهة
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                val tmp = WebView(view.context)
                tmp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                        openExternal(r.url)
                        v.destroy()
                        return true
                    }
                }
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = tmp
                resultMsg.sendToTarget()
                return true
            }
        }
    }

    /** يخدم صفحة الواجهة: الرسمية المحمّلة إن صلحت، وإلا الثابتة المضمّنة. */
    inner class AppPathHandler : WebViewAssetLoader.PathHandler {
        override fun handle(path: String): WebResourceResponse? {
            if (path != "index.html") return null
            val preferOfficial = isOnline() || Config.OFFLINE_USES_CACHED_OFFICIAL
            val served = store.serve(preferOfficial)
            servedSha = served.sha
            servedOfficial = served.official
            val r = WebResourceResponse("text/html", "utf-8", served.stream)
            r.responseHeaders = mapOf(
                "Cache-Control" to "no-store",
                "Content-Security-Policy" to Config.CSP,
                "X-Content-Type-Options" to "nosniff"
            )
            // نسخة جديدة لم تُؤكَّد بعد: ننتظر منها إشارة ready وإلا نتراجع
            val sha = served.sha
            if (served.official && sha != null && store.pendingSha() == sha) {
                handler.post {
                    handler.removeCallbacks(readyTimeout)
                    handler.postDelayed(readyTimeout, Config.READY_TIMEOUT_MS)
                }
            }
            return r
        }
    }

    // ---------------------------------------------------------------- الجسر بين الصفحة والتطبيق

    inner class Bridge {
        @JavascriptInterface fun ready(build: String) {
            runOnUiThread {
                currentBuild = build
                handler.removeCallbacks(readyTimeout)
                servedSha?.let { store.confirm(it) }
            }
        }

        @JavascriptInterface fun print() {
            runOnUiThread { doPrint() }
        }

        @JavascriptInterface fun setUpdateUrl(url: String) {
            checker.setApiUrl(url)
        }

        @JavascriptInterface fun info(): String =
            JSONObject()
                .put("apk", versionName())
                .put("source", if (servedOfficial) "official" else "static")
                .put("build", currentBuild)
                .toString()
    }

    private fun onReadyTimeout() {
        val bad = servedSha ?: return
        if (store.pendingSha() != bad) return
        store.rollback(bad)                                  // الواجهة الجديدة لم تبدأ: نرجع للسابقة أو الثابتة
        Toast.makeText(this, "تعذّر تشغيل الواجهة الجديدة، تمت العودة للنسخة السابقة", Toast.LENGTH_LONG).show()
        webView.loadUrl(Config.APP_URL)
    }

    // ---------------------------------------------------------------- التحديث التلقائي

    private fun checkForUpdate() {
        if (checking || !isOnline()) return
        checking = true
        exec.execute {
            val res = try {
                checker.check()
            } catch (e: Exception) {
                UpdateChecker.Result(false, null)
            }
            runOnUiThread {
                checking = false
                if (res.updated) {
                    pendingApply = true
                    tryApply(0)
                }
            }
        }
    }

    /** يطبّق الواجهة الجديدة تلقائيًا عند الخمول فقط (لا نافذة مفتوحة ولا كتابة جارية). البيانات محفوظة محليًا فلا تضيع. */
    private fun tryApply(attempt: Int) {
        if (!pendingApply) return
        webView.evaluateJavascript(IDLE_JS) { v ->
            if (!pendingApply) return@evaluateJavascript
            val idle = v == null || v == "null" || v.trim('"') == "1"
            if (idle) {
                pendingApply = false
                Toast.makeText(this, "تم تحديث الواجهة", Toast.LENGTH_SHORT).show()
                webView.loadUrl(Config.APP_URL)
            } else if (attempt < 30) {
                handler.postDelayed({ tryApply(attempt + 1) }, 20_000)
            }                                                // وإلا يُطبَّق عند العودة للتطبيق (onResume)
        }
    }

    // ---------------------------------------------------------------- أدوات

    private fun onBack() {
        webView.evaluateJavascript(BACK_JS) { v ->
            if (v != "1") moveTaskToBack(true)
        }
    }

    private fun doPrint() {
        val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
        val name = webView.title ?: "بركة الحي"
        pm.print(
            name,
            webView.createPrintDocumentAdapter(name),
            PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build()
        )
    }

    private fun openExternal(u: Uri) {
        try {
            val intent = when (u.scheme) {
                "tel" -> Intent(Intent.ACTION_DIAL, u)
                "whatsapp", "mailto", "sms", "https", "http" -> Intent(Intent.ACTION_VIEW, u)
                else -> return
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "لا يوجد تطبيق لفتح هذا الرابط", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isOnline(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(n) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun versionName(): String =
        try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }

    companion object {
        private const val IDLE_JS =
            "(function(){var a=document.activeElement;var t=a&&['INPUT','SELECT','TEXTAREA'].indexOf(a.tagName)>=0;" +
                "var d=!!document.querySelector('#md .ov');return (t||d)?0:1})()"
        private const val BACK_JS =
            "(function(){var o=document.querySelector('#md .ov');if(o&&typeof closeDlg==='function'){closeDlg();return 1}return 0})()"
    }
}
