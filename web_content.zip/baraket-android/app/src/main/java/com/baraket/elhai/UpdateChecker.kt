package com.baraket.elhai

import android.content.Context
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** يسأل Apps Script عن بصمة الواجهة الرسمية، وإن تغيّرت يحمّلها ويتحقق منها ثم يثبّتها. */
class UpdateChecker(private val ctx: Context, private val store: BundleStore) {
    class Result(val updated: Boolean, val build: String?)

    private val prefs = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    /** رابط الخدمة: الافتراضي أو الذي أرسلته الواجهة (لو تغيّر النشر) بشرط أن يكون رابط Apps Script رسميًا. */
    fun apiUrl(): String = prefs.getString("api_url", null) ?: Config.API_URL

    fun setApiUrl(url: String): Boolean {
        if (!url.startsWith("https://script.google.com/macros/s/") || !url.endsWith("/exec") || url.length > 300) return false
        prefs.edit().putString("api_url", url).apply()
        return true
    }

    /** استدعاء متزامن؛ يُنفَّذ خارج الخيط الرئيسي. */
    fun check(): Result {
        val base = apiUrl()
        val meta = data(get("$base?action=htmlMeta&t=${System.currentTimeMillis()}")) ?: return Result(false, null)
        val sha = meta.optString("sha256")
        if (sha.length != 64) return Result(false, null)
        if (sha == store.currentSha() || store.isBad(sha)) return Result(false, null)

        val b = data(get("$base?action=htmlBundle&t=${System.currentTimeMillis()}")) ?: return Result(false, null)
        val html = b.optString("html")
        val gotSha = b.optString("sha256")
        val build = b.optString("build")
        if (gotSha != sha) return Result(false, null)                       // تغيّر الملف بين الطلبين
        if (html.length < 10_000 || !html.contains("</html>")) return Result(false, null)
        if (!html.contains(Config.APP_MARKER)) return Result(false, null)    // ليست واجهة هذا التطبيق
        val ok = store.install(html, sha, build)                             // يتحقق من البصمة محليًا أيضًا
        return Result(ok, if (ok) build else null)
    }

    private fun data(text: String): JSONObject? {
        val j = JSONObject(text)
        return if (j.optBoolean("success", false)) j.optJSONObject("data") else null
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8_000
        c.readTimeout = 15_000
        c.instanceFollowRedirects = true
        c.requestMethod = "GET"
        try {
            if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
            if (c.url.protocol != "https") throw IOException("insecure redirect")
            val out = ByteArrayOutputStream()
            c.inputStream.use { ins ->
                val buf = ByteArray(16 * 1024)
                var total = 0
                while (true) {
                    val n = ins.read(buf)
                    if (n <= 0) break
                    total += n
                    if (total > Config.MAX_BUNDLE_BYTES) throw IOException("response too large")
                    out.write(buf, 0, n)
                }
            }
            return out.toString("UTF-8")
        } finally {
            c.disconnect()
        }
    }
}
