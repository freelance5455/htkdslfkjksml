SMART STUDY AI - STD 9 GUJARATI MEDIUM
Redesigned responsive learning app based on the supplied purple/blue header and colorful subject-card reference.

OPEN:
- Open index.html in Chrome or another modern browser.
- Notes, Homework, Class Work, quiz reports and question banks are stored in this browser's local storage.
- Use the app's backup/export option before clearing browser data or changing devices.

FEATURES RETAINED:
- Subject and chapter selection
- Notes, homework tracker and classwork records
- 25-question chapter quiz flow (requires at least 25 questions in a chapter bank)
- Easy / medium / hard question levels
- Quiz report cards and JSON question-bank import

NOTE:
This ZIP contains the web-app source, not a compiled Android APK. Existing app data from another browser/device is not automatically transferred.
