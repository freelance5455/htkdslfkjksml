import { useEffect, useMemo, useState, type ReactNode, type FormEvent } from 'react';
import { Link, Route, Switch, useLocation } from 'wouter';
import { Bookmark, BookOpen, Check, ChevronLeft, CircleHelp, Clock3, Compass, Heart, Home, Info, Menu, Moon, Search, Sparkles, Sun, UsersRound, X, Star, RotateCcw, Minus, Droplets, HandHeart, ScrollText, Landmark } from 'lucide-react';

type ContentItem = { id: string; title: string; category: string; body: string; reference: string; repetitions?: number; kind: 'ذكر' | 'دعاء' | 'سنة' };
type Prayer = { name: string; rakats: string; time: string; steps: string[]; notes: string; source: string };
type WuduStep = { number: number; title: string; detail: string; status: 'required' | 'sunnah'; source: string };
type Prophet = { name: string; people: string; message: string; events: string; signs: string; verses: string; chronologyNote: string };
type ChildLesson = { title: string; explanation: string; example: string; reference: string };
type QuizQuestion = { question: string; choices: string[]; correctIndex: number; explanation: string; category: string; difficulty: 'سهل' | 'متوسط' | 'متقدم'; reference: string };
type Rating = { stars: number; feedback: string; createdAt: string };

const getStored = <T,>(key: string, fallback: T): T => {
  try { const value = localStorage.getItem(key); return value ? JSON.parse(value) as T : fallback; } catch { return fallback; }
};
const save = (key: string, value: unknown) => localStorage.setItem(key, JSON.stringify(value));

const adhkar: ContentItem[] = [
  { id: 'morning-1', title: 'آية الكرسي', category: 'أذكار الصباح والمساء', body: 'اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ...', reference: 'سورة البقرة: ٢٥٥', repetitions: 1, kind: 'ذكر' },
  { id: 'morning-2', title: 'سيد الاستغفار', category: 'أذكار الصباح والمساء', body: 'اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ...', reference: 'صحيح البخاري، ٦٣٠٦', repetitions: 1, kind: 'ذكر' },
  { id: 'sleep-1', title: 'ذكر النوم', category: 'أذكار النوم', body: 'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا', reference: 'صحيح البخاري، ٦٣٢٤', repetitions: 1, kind: 'ذكر' },
  { id: 'wake-1', title: 'ذكر الاستيقاظ', category: 'أذكار الاستيقاظ', body: 'الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ', reference: 'صحيح البخاري، ٦٣١٢', repetitions: 1, kind: 'ذكر' },
  { id: 'after-prayer-1', title: 'التسبيح بعد الصلاة', category: 'أذكار بعد الصلاة', body: 'سبحان الله، والحمد لله، والله أكبر', reference: 'صحيح مسلم، ٥٩٧ — ثلاث وثلاثون مرة لكل منها', repetitions: 33, kind: 'ذكر' },
  { id: 'prayer-1', title: 'دعاء الاستفتاح', category: 'أذكار الصلاة', body: 'سُبْحَانَكَ اللَّهُمَّ وَبِحَمْدِكَ، وَتَبَارَكَ اسْمُكَ، وَتَعَالَى جَدُّكَ، وَلَا إِلَهَ غَيْرُكَ', reference: 'سنن أبي داود، ٧٧٥؛ صححه الألباني', repetitions: 1, kind: 'ذكر' },
  { id: 'wudu-1', title: 'الذكر بعد الوضوء', category: 'أذكار الوضوء', body: 'أَشْهَدُ أَنْ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ', reference: 'صحيح مسلم، ٢٣٤', repetitions: 1, kind: 'ذكر' },
  { id: 'masjid-1', title: 'دعاء دخول المسجد', category: 'أذكار المسجد', body: 'اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ', reference: 'صحيح مسلم، ٧١٣', repetitions: 1, kind: 'ذكر' },
  { id: 'food-1', title: 'التسمية عند الطعام', category: 'أذكار الطعام', body: 'بِسْمِ اللَّهِ', reference: 'سنن أبي داود، ٣٧٦٧؛ حديث صحيح', repetitions: 1, kind: 'ذكر' },
  { id: 'travel-1', title: 'دعاء السفر', category: 'أذكار السفر', body: 'اللَّهُ أَكْبَرُ، اللَّهُ أَكْبَرُ، اللَّهُ أَكْبَرُ، سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ', reference: 'صحيح مسلم، ١٣٤٢', repetitions: 1, kind: 'ذكر' },
  { id: 'home-1', title: 'ذكر دخول المنزل', category: 'أذكار المنزل', body: 'بِسْمِ اللَّهِ وَلَجْنَا، وَبِسْمِ اللَّهِ خَرَجْنَا، وَعَلَى اللَّهِ رَبِّنَا تَوَكَّلْنَا', reference: 'سنن أبي داود، ٥٠٩٦؛ حسنه ابن باز', repetitions: 1, kind: 'ذكر' },
  { id: 'istighfar', title: 'الاستغفار', category: 'استغفار', body: 'أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ', reference: 'صحيح البخاري، ٦٣٠٧', repetitions: 100, kind: 'ذكر' },
  { id: 'salawat', title: 'الصلاة على النبي ﷺ', category: 'الصلاة على النبي', body: 'اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ', reference: 'صحيح البخاري، ٣٣٧٠؛ أصل الصلاة على النبي في القرآن: الأحزاب ٥٦', repetitions: 10, kind: 'ذكر' },
  { id: 'tasbih', title: 'التسبيح', category: 'تسبيح', body: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ', reference: 'صحيح البخاري، ٦٤٠٥', repetitions: 100, kind: 'ذكر' },
];
const duas: ContentItem[] = [
  { id: 'quran-rabbana', title: 'دعاء جامع من القرآن', category: 'أدعية قرآنية', body: 'رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ', reference: 'سورة البقرة: ٢٠١', kind: 'دعاء' },
  { id: 'quran-knowledge', title: 'طلب العلم', category: 'أدعية قرآنية', body: 'رَبِّ زِدْنِي عِلْمًا', reference: 'سورة طه: ١١٤', kind: 'دعاء' },
  { id: 'prophetic-distress', title: 'دعاء الكرب', category: 'أدعية نبوية', body: 'لَا إِلَهَ إِلَّا اللَّهُ الْعَظِيمُ الْحَلِيمُ، لَا إِلَهَ إِلَّا اللَّهُ رَبُّ الْعَرْشِ الْعَظِيمِ', reference: 'صحيح البخاري، ٦٣٤٦؛ صحيح مسلم، ٢٧٣٠', kind: 'دعاء' },
  { id: 'prophetic-guidance', title: 'سؤال الهداية والتقوى', category: 'أدعية نبوية', body: 'اللَّهُمَّ إِنِّي أَسْأَلُكَ الْهُدَى وَالتُّقَى وَالْعَفَافَ وَالْغِنَى', reference: 'صحيح مسلم، ٢٧٢١', kind: 'دعاء' },
  { id: 'everyday-parent', title: 'الدعاء للوالدين', category: 'أدعية يومية', body: 'رَبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا', reference: 'سورة الإسراء: ٢٤', kind: 'دعاء' },
];
const sunnahs: ContentItem[] = [
  { id: 'sunnah-miswak', title: 'السواك عند الوضوء', category: 'سنن مهجورة', body: 'يُستحب استعمال السواك عند الوضوء وتنظيف الفم به برفق. ابدأ بالجانب الأيمن، ولا تؤذِ اللثة.', reference: 'صحيح البخاري، ٨٨٧؛ صحيح مسلم، ٢٥٢', kind: 'سنة' },
  { id: 'sunnah-right', title: 'البدء باليمين في الطهور', category: 'سنن مهجورة', body: 'ابدأ باليمين عند غسل اليدين والرجلين في الوضوء، مع إتمام الأعضاء على الصفة التي تتعلمها من مصدر موثوق.', reference: 'صحيح البخاري، ١٦٨؛ صحيح مسلم، ٢٦٨', kind: 'سنة' },
  { id: 'sunnah-smile', title: 'البشاشة وحسن اللقاء', category: 'سنن مهجورة', body: 'لاقِ الناس بوجه طلق وكلمة طيبة؛ اجعلها عادة يومية في البيت والمدرسة والعمل.', reference: 'صحيح مسلم، ٢٦٢٦: «لا تحقرن من المعروف شيئًا...»', kind: 'سنة' },
  { id: 'sunnah-left', title: 'الدخول بالرجل اليمنى', category: 'سنن مهجورة', body: 'من آداب دخول المسجد تقديم الرجل اليمنى، والخروج باليسرى؛ وهي آداب مستندة إلى محبة التيامن في شأن التكريم.', reference: 'صحيح البخاري، ١٦٨؛ صحيح مسلم، ٢٦٨؛ التطبيق الفقهي مشهور عند أهل العلم', kind: 'سنة' },
];
const wuduSteps: WuduStep[] = [
  { number: 1, title: 'النية والتسمية', detail: 'انوِ الوضوء بقلبك. التسمية قبل الوضوء مستحبة عند جمهور الفقهاء، ووجوبها قول عند بعض أهل العلم.', status: 'sunnah', source: 'خلاف فقهي؛ انظر المذاهب الأربعة' },
  { number: 2, title: 'غسل الكفين', detail: 'اغسل كفيك ثلاثًا في بداية الوضوء، وهي صفة ثابتة في الأحاديث.', status: 'sunnah', source: 'صحيح البخاري، ١٥٩؛ صحيح مسلم، ٢٢٦' },
  { number: 3, title: 'المضمضة والاستنشاق', detail: 'تمضمض واستنشق الماء ثم استنثره. التفصيل في الحكم والترتيب له اختلاف فقهي.', status: 'sunnah', source: 'صحيح البخاري، ١٦٠؛ صحيح مسلم، ٢٣٦' },
  { number: 4, title: 'غسل الوجه', detail: 'اغسل الوجه كاملًا من منابت الشعر المعتادة إلى أسفل الذقن، ومن الأذن إلى الأذن.', status: 'required', source: 'سورة المائدة: ٦' },
  { number: 5, title: 'غسل اليدين إلى المرفقين', detail: 'اغسل اليدين مع المرفقين، وابدأ باليمين، وتأكد من وصول الماء إلى جميع المواضع.', status: 'required', source: 'سورة المائدة: ٦؛ صفة وضوء النبي في الصحيحين' },
  { number: 6, title: 'مسح الرأس والأذنين', detail: 'امسح الرأس بالماء. مقدار المسح وبعض تفاصيل الأذنين محل اختلاف بين المذاهب.', status: 'required', source: 'سورة المائدة: ٦؛ تفاصيل المسح فيها خلاف فقهي' },
  { number: 7, title: 'غسل القدمين إلى الكعبين', detail: 'اغسل القدمين مع الكعبين، وخلل بين الأصابع، وتفقد العقبين.', status: 'required', source: 'سورة المائدة: ٦؛ صحيح البخاري، ١٦٥' },
];
const prayers: Prayer[] = [
  { name: 'الفجر', rakats: 'ركعتان فرض، وقبلهما ركعتا سنة راتبة', time: 'من طلوع الفجر الصادق إلى شروق الشمس', steps: ['استقبل القبلة وانْوِ الصلاة بقلبك.', 'كبّر تكبيرة الإحرام قائمًا، واقرأ الفاتحة وسورة في كل ركعة.', 'اركع مطمئنًا، ثم ارفع، واسجد سجدتين بينهما جلوس.', 'أتم الركعة الثانية بالتشهد والسلام.'], notes: 'الجهر بالقراءة في الركعتين للإمام والمنفرد عند جمهور الفقهاء؛ وتفاصيل المسبوق لها أحكامها.', source: 'صحيح البخاري، كتاب الصلاة؛ سورة الإسراء: ٧٨' },
  { name: 'الظهر', rakats: 'أربع ركعات فرض، ورواتب قبلها وبعدها', time: 'بعد زوال الشمس عن وسط السماء', steps: ['صلِّ أربع ركعات بتشهد أوسط وأخير.', 'اقرأ الفاتحة في كل ركعة، وتكون القراءة سرية.', 'أتم الركوع والسجود والطمأنينة في كل ركعة.'], notes: 'عدد الرواتب المؤكدة قبل الظهر وبعدها ثابت في أحاديث، وفي جمعها وتفصيلها روايات متعددة.', source: 'صحيح مسلم، ٧٢٨؛ صحيح البخاري، ٥٠٦' },
  { name: 'العصر', rakats: 'أربع ركعات فرض', time: 'بعد انتهاء وقت الظهر إلى غروب الشمس', steps: ['صلِّ أربع ركعات سرية.', 'اقرأ الفاتحة في كل ركعة، وأتم الأركان بطمأنينة.', 'اجلس للتشهد بعد الركعة الثانية والأخيرة.'], notes: 'يحرم تأخيرها حتى اصفرار الشمس بلا عذر عند كثير من أهل العلم؛ وقت الصلاة يُعرف بالتقويم المحلي.', source: 'صحيح البخاري، ٥٥٤؛ صحيح مسلم، ٦١٢' },
  { name: 'المغرب', rakats: 'ثلاث ركعات فرض، وبعدها ركعتا سنة راتبة', time: 'من غروب الشمس إلى مغيب الشفق', steps: ['صلِّ الركعتين الأوليين جهرًا للإمام، ثم الثالثة سرًا.', 'اجلس للتشهد بعد الثانية، ثم قم للثالثة.', 'أتم التشهد الأخير والسلام.'], notes: 'تُراعى أوقات المغرب المعتمدة في بلدك.', source: 'صحيح البخاري، كتاب مواقيت الصلاة' },
  { name: 'العشاء', rakats: 'أربع ركعات فرض، وبعدها ركعتا سنة راتبة', time: 'بعد مغيب الشفق إلى نصف الليل الشرعي، ويمتد للضرورة عند أهل العلم', steps: ['صلِّ الركعتين الأوليين جهرًا للإمام، والأخريين سرًا.', 'اجلس للتشهد بعد الثانية ثم أتم الرابعة.', 'اختم بالتشهد والسلام، والوتر صلاة مستقلة بعدها.'], notes: 'تفاصيل نهاية الوقت فيها أقوال فقهية؛ اتبع تقويمًا موثوقًا وفتوى بلدك.', source: 'صحيح مسلم، ٦١٢' },
  { name: 'الجمعة', rakats: 'ركعتان فرض جماعة بعد الخطبتين', time: 'وقت الظهر يوم الجمعة', steps: ['استمع للخطبتين وأنصت.', 'صلِّ ركعتين مع الإمام جهرًا.', 'من فاتته الجمعة يصلي الظهر أربعًا.'], notes: 'شروط الوجوب والأعذار تختلف تفاصيلها فقهيًا؛ اسأل أهل العلم في حالتك.', source: 'سورة الجمعة: ٩؛ صحيح البخاري، ٩٣٤' },
  { name: 'الوتر', rakats: 'ركعة واحدة أو ثلاث فأكثر بوتر؛ صور الأداء متنوعة', time: 'بعد العشاء إلى طلوع الفجر', steps: ['صلِّ بعد العشاء، واجعل آخر صلاة الليل وترًا إن تيسر.', 'اقرأ ما تيسر من القرآن، ثم تشهد وسلم.', 'القنوت في الوتر وارد، وتفاصيله مستحبة لا لازمة.'], notes: 'صفة الوتر وعدده محل تنوع ثابت في السنة؛ لا تُلزم الناس بصفة واحدة.', source: 'صحيح مسلم، ٧٥١؛ سنن أبي داود، ١٤٢٢' },
  { name: 'الضحى', rakats: 'ركعتان فأكثر، مثنى مثنى', time: 'بعد ارتفاع الشمس إلى قبيل الزوال', steps: ['صلِّ ركعتين بنية صلاة الضحى.', 'اقرأ الفاتحة وما تيسر، وأتم الصلاة كغيرها.', 'يمكن الزيادة ركعتين ركعتين.'], notes: 'أقلها ركعتان؛ لا يثبت عدد واحد لازم.', source: 'صحيح مسلم، ٧٢٠' },
  { name: 'قيام الليل والتهجد', rakats: 'مثنى مثنى، ثم الوتر؛ لا حد لازم', time: 'بعد العشاء إلى الفجر، وآخر الليل أفضل لمن تيسر', steps: ['قم بما تيسر من الليل وصلِّ ركعتين ركعتين.', 'أطل القراءة بقدر استطاعتك دون مشقة.', 'اختم بوتر إن لم تكن أوترت.'], notes: 'التهجد بعد نوم، وقيام الليل أعمّ؛ استعمال المصطلحين قد يختلف.', source: 'صحيح البخاري، ١١٣٧؛ صحيح مسلم، ٧٤٩' },
  { name: 'التراويح', rakats: 'قيام رمضان؛ العدد والهيئة فيهما سعة معتبرة', time: 'بعد العشاء في ليالي رمضان', steps: ['صلِّ مع الإمام أو في البيت ركعتين ركعتين.', 'اتبع الإمام ولا تتعجل، وأتم الصلاة معه.', 'لا تجعل عددًا بعينه موضع نزاع أو إنكار.'], notes: 'اختلفت التطبيقات التاريخية والفقهية في العدد؛ لا يُعرض قول واحد كأنه إجماع.', source: 'صحيح البخاري، ٢٠٠٩؛ صحيح مسلم، ٧٥٩' },
  { name: 'صلاة العيد', rakats: 'ركعتان؛ تفاصيل التكبيرات الزوائد مختلف فيها', time: 'بعد ارتفاع الشمس يوم العيد', steps: ['صلِّ ركعتين مع الإمام في المصلى أو المسجد.', 'استمع للخطبة بعد الصلاة.', 'صفة التكبيرات الزوائد تختلف بين المذاهب.'], notes: 'توقيت المصلى وبدائل الصلاة يتبعان إعلان الجهات الشرعية المحلية.', source: 'صحيح البخاري، ٩٥٦؛ اختلاف فقهي في التكبيرات الزوائد' },
  { name: 'الاستخارة', rakats: 'ركعتان من غير الفريضة ثم دعاء الاستخارة', time: 'عند التردد في أمر مباح بعد الأخذ بالأسباب', steps: ['استشر واستخِر الله في الأمر المباح.', 'صلِّ ركعتين نافلة في وقت مباح.', 'ادع بدعاء الاستخارة المأثور، وامضِ فيما يتيسر.'], notes: 'لا يشترط رؤيا أو علامة غيبية بعد الاستخارة.', source: 'صحيح البخاري، ١١٦٦' },
  { name: 'التوبة', rakats: 'ركعتان نافلة عند كثير من أهل العلم', time: 'عند الندم والعزم على ترك الذنب', steps: ['أقلع عن الذنب، واندم، واعزم ألا تعود، ورد الحقوق.', 'توضأ وصلِّ ركعتين إن تيسر.', 'استغفر الله ولا تيأس من رحمته.'], notes: 'التوبة الصادقة واجبة فورًا؛ الصلاة نافلة ثابت أصلها وليست شرطًا لصحتها.', source: 'سنن أبي داود، ١٥٢١؛ التوبة: ٨' },
  { name: 'صلاة الجنازة', rakats: 'أربع تكبيرات غالبًا، بلا ركوع ولا سجود', time: 'بعد تجهيز الميت وقبل الدفن', steps: ['قف مستقبل القبلة وكبّر أربع تكبيرات.', 'اقرأ الفاتحة بعد الأولى، والصلاة الإبراهيمية بعد الثانية.', 'ادع للميت بعد الثالثة، ثم سلّم بعد الرابعة.'], notes: 'ترتيب القراءة والأدعية وكيفية التسليم فيها تفصيل فقهي؛ يُتبع الإمام.', source: 'صحيح البخاري، ١٣٣٥؛ صحيح مسلم، ٩٦٣' },
];
const prophets: Prophet[] = [
  { name: 'آدم عليه السلام', people: 'أبو البشر', message: 'عبادة الله وتعليمه التوبة', events: 'خلقه الله وأسكنه الجنة ثم أهبطه إلى الأرض.', signs: 'تعليم الأسماء، وسجود الملائكة بأمر الله.', verses: 'البقرة: ٣٠–٣٩؛ طه: ١١٥–١٢٣', chronologyNote: 'أول الأنبياء؛ لا يحدد القرآن زمنًا تقويميًا.' },
  { name: 'نوح عليه السلام', people: 'قوم نوح', message: 'التوحيد وترك عبادة الأصنام', events: 'دعا قومه زمنًا طويلًا، وصنع السفينة بأمر الله، ونجا المؤمنون من الطوفان.', signs: 'الطوفان والسفينة كما وردا في القرآن.', verses: 'هود: ٢٥–٤٩؛ نوح: ١–٢٨', chronologyNote: 'تأتي قصته بعد آدم في السرد القرآني؛ التواريخ العددية غير منصوص عليها.' },
  { name: 'إبراهيم عليه السلام', people: 'قومه وأهل بابل؛ ثم ذريته', message: 'التوحيد وترك الشرك', events: 'حاجّ قومه، وهاجر، ورفع القواعد من البيت مع إسماعيل.', signs: 'نجاته من النار، وبناء الكعبة مع إسماعيل.', verses: 'الأنبياء: ٥١–٧٠؛ البقرة: ١٢٤–١٢٩', chronologyNote: 'تختلف التواريخ التاريخية التقديرية؛ القرآن لا يحدد سنة.' },
  { name: 'موسى عليه السلام', people: 'بنو إسرائيل وفرعون', message: 'عبادة الله وإقامة العدل وإنقاذ بني إسرائيل', events: 'كلمه الله، وأرسل إلى فرعون، وانفلق البحر لبني إسرائيل.', signs: 'العصا واليد والبحر؛ آيات صريحة في القرآن.', verses: 'طه: ٩–٩٨؛ الشعراء: ١٠–٦٨', chronologyNote: 'الترتيب النسبي مستفاد من القصص القرآني، أما التأريخ الدقيق فمختلف فيه.' },
  { name: 'داود عليه السلام', people: 'بنو إسرائيل', message: 'النبوة والعدل وعبادة الله', events: 'آتاه الله الملك والحكمة، وأنزل عليه الزبور.', signs: 'تسبيح الجبال والطير معه، وفصل الخطاب.', verses: 'ص: ١٧–٢٦؛ سبأ: ١٠–١١', chronologyNote: 'ورد بعد موسى في السرد؛ لا يثبت القرآن تاريخًا محددًا.' },
  { name: 'عيسى عليه السلام', people: 'بنو إسرائيل', message: 'التوحيد وتصديق التوراة والبشارة برسول بعده', events: 'ولد من مريم بغير أب، وأيّده الله بالآيات، ورفعه إليه.', signs: 'كلامه في المهد وإبراء الأكمه والأبرص بإذن الله.', verses: 'آل عمران: ٤٥–٥٥؛ مريم: ١٦–٣٦', chronologyNote: 'التواريخ الميلادية الشائعة تقديرية وليست نصًا قرآنيًا.' },
  { name: 'محمد ﷺ', people: 'الناس كافة', message: 'خاتم الأنبياء، دعا إلى توحيد الله والرحمة والهداية', events: 'نزل عليه القرآن، هاجر إلى المدينة، وأكمل الله به الدين.', signs: 'القرآن الكريم أعظم آياته، والإسراء والمعراج ثابتان في القرآن والسنة.', verses: 'الأحزاب: ٤٠؛ الإسراء: ١؛ صحيح البخاري، ٤٩٨١', chronologyNote: 'خاتم النبيين بنص القرآن؛ chronology في القوائم السابقة تقريبية جدًا.' },
];
const lessons: ChildLesson[] = [
  { title: 'بر الوالدين', explanation: 'أحسن إلى والديك، وقل لهما كلامًا لطيفًا، وساعدهما.', example: 'رتّب أغراضك عندما يطلبان، وقل: شكرًا.', reference: 'الإسراء: ٢٣–٢٤' },
  { title: 'الصدق', explanation: 'قل الحقيقة حتى عندما تخطئ؛ فالصدق يبني الثقة.', example: 'إذا كسرت شيئًا، أخبر أهلك واعتذر.', reference: 'التوبة: ١١٩' },
  { title: 'الأمانة', explanation: 'احفظ ما ائتمنك عليه الناس وأعده كما أخذته.', example: 'أعد كتاب صديقك في موعده.', reference: 'النساء: ٥٨' },
  { title: 'احترام الكبار', explanation: 'تحدث بأدب، واستمع للكبير دون مقاطعة.', example: 'سلّم على جدتك واعرض أن تساعدها.', reference: 'سنن أبي داود، ٤٩٤٣؛ حسنه الترمذي' },
  { title: 'الرحمة بالصغار', explanation: 'عامل الأطفال بلطف، ولا تسخر منهم.', example: 'ساعد أخاك الصغير على ربط حذائه.', reference: 'صحيح البخاري، ٦٠١٣؛ صحيح مسلم، ٢٣١٩' },
  { title: 'مساعدة الآخرين', explanation: 'قدّم العون بقدر استطاعتك دون انتظار مقابل.', example: 'شارك زميلًا في حمل كتبه.', reference: 'المائدة: ٢' },
  { title: 'المحافظة على الصلاة', explanation: 'تعلم الصلاة خطوة خطوة، واطلب من أهلك أن يصلوا معك.', example: 'جهّز سجادتك عندما يحين وقت الصلاة.', reference: 'طه: ١٣٢' },
  { title: 'النظافة', explanation: 'اهتم بنظافة جسمك وملابسك ومكانك.', example: 'اغسل يديك بعد اللعب ورتب ألعابك.', reference: 'المدثر: ٤؛ صحيح مسلم، ٢٢٣' },
  { title: 'آداب الطعام', explanation: 'سمّ الله، وكل بيمينك مما يليك، ولا تسرف.', example: 'اجلس بهدوء وشارك الطعام مع أسرتك.', reference: 'صحيح البخاري، ٥٣٧٦؛ صحيح مسلم، ٢٠٢٢' },
  { title: 'آداب النوم', explanation: 'استعد للنوم بهدوء، ونم على جانبك الأيمن إن تيسر.', example: 'أطفئ الشاشة، وقل ذكر النوم المأثور.', reference: 'صحيح البخاري، ٦٣٢٤' },
  { title: 'حسن الكلام', explanation: 'اختر كلامًا طيبًا، وابتعد عن الشتائم والسخرية.', example: 'قل لصديقك: أحسنت، بدل أن تجرحه.', reference: 'البقرة: ٨٣؛ صحيح البخاري، ٦٠١٨' },
  { title: 'رفض التنمر', explanation: 'لا تؤذِ أحدًا، واطلب مساعدة شخص بالغ موثوق إذا تعرضت أو رأيت تنمرًا.', example: 'قل: هذا التصرف يؤذي، ثم أخبر المعلم.', reference: 'الحجرات: ١١؛ لا ضرر ولا ضرار — ابن ماجه، ٢٣٤٠' },
  { title: 'الاستئذان', explanation: 'اطرق الباب واستأذن قبل دخول غرفة خاصة.', example: 'قل: السلام عليكم، هل أدخل؟', reference: 'النور: ٢٧' },
  { title: 'حفظ اللسان', explanation: 'لا تنقل كلامًا يؤذي ولا تكذب ولا تغتب.', example: 'إذا غضبت، توقف وخذ نفسًا قبل الرد.', reference: 'ق: ١٨؛ الحجرات: ١٢' },
  { title: 'الإحسان إلى الجيران', explanation: 'عامل جارك بلطف، ولا تزعجه بصوت أو أذى.', example: 'ألقِ السلام وساعد في حمل شيء ثقيل.', reference: 'صحيح البخاري، ٦٠١٤؛ صحيح مسلم، ٤٧' },
  { title: 'الرفق بالحيوان', explanation: 'اسق الحيوان وأطعمه ولا تؤذه أو تخيفه.', example: 'ضع ماءً للقطط في مكان آمن بإذن أهلك.', reference: 'صحيح البخاري، ٢٣٦٣؛ صحيح مسلم، ٢٢٤٢' },
  { title: 'الشكر', explanation: 'اشكر الله على نعمه واشكر من أحسن إليك.', example: 'قل الحمد لله، وقل لمن ساعدك: جزاك الله خيرًا.', reference: 'إبراهيم: ٧؛ سنن أبي داود، ٤٨١١' },
];
const quizQuestions: QuizQuestion[] = [
  { question: 'كم عدد الصلوات المفروضة في اليوم والليلة؟', choices: ['ثلاث', 'خمس', 'سبع'], correctIndex: 1, explanation: 'الصلوات المفروضة خمس: الفجر والظهر والعصر والمغرب والعشاء.', category: 'الصلاة', difficulty: 'سهل', reference: 'صحيح البخاري، ٤٦؛ صحيح مسلم، ١١' },
  { question: 'في أي سورة ورد دعاء «رَبِّ زِدْنِي عِلْمًا»؟', choices: ['طه', 'الضحى', 'الناس'], correctIndex: 0, explanation: 'ورد الدعاء في سورة طه، الآية ١١٤.', category: 'القرآن', difficulty: 'سهل', reference: 'سورة طه: ١١٤' },
  { question: 'ما الصلاة التي تكون ركعتين بعد خطبة الجمعة؟', choices: ['صلاة الجمعة', 'صلاة الوتر', 'صلاة الضحى'], correctIndex: 0, explanation: 'صلاة الجمعة ركعتان جماعة بعد الخطبتين.', category: 'الصلاة', difficulty: 'متوسط', reference: 'صحيح البخاري، ٩٣٤' },
  { question: 'من النبي الذي بنى الكعبة مع ابنه إسماعيل عليهما السلام؟', choices: ['موسى', 'إبراهيم', 'داود'], correctIndex: 1, explanation: 'رفع إبراهيم وإسماعيل القواعد من البيت كما ورد في القرآن.', category: 'الأنبياء', difficulty: 'متوسط', reference: 'سورة البقرة: ١٢٧' },
  { question: 'ما أول ما يُغسل من أعضاء الوضوء المفروضة في آية الوضوء؟', choices: ['الوجه', 'القدمان', 'الرأس'], correctIndex: 0, explanation: 'ذكرت آية الوضوء غسل الوجه أولًا، ثم اليدين ومسح الرأس وغسل القدمين.', category: 'الطهارة', difficulty: 'متقدم', reference: 'سورة المائدة: ٦' },
  { question: 'ما اسم الكتاب الذي أُنزل على داود عليه السلام؟', choices: ['الزبور', 'الإنجيل', 'الصحف'], correctIndex: 0, explanation: 'آتَى الله داود زبورًا.', category: 'الأنبياء', difficulty: 'متقدم', reference: 'سورة الإسراء: ٥٥' },
];
const categories = [
  { title: 'أذكار الصباح والمساء', route: '/adhkar', icon: Sun, tint: 'gold', caption: 'ورد يرافق يومك' },
  { title: 'الأدعية', route: '/duas', icon: HandHeart, tint: 'sage', caption: 'من القرآن والسنة' },
  { title: 'الصلاة', route: '/prayer', icon: Compass, tint: 'sand', caption: 'دليل واضح خطوة بخطوة' },
  { title: 'الوضوء', route: '/wudu', icon: Droplets, tint: 'blue', caption: 'تعلم الطهارة' },
  { title: 'قصص الأنبياء', route: '/prophets', icon: BookOpen, tint: 'rose', caption: 'كما وردت في الوحي' },
  { title: 'للأطفال', route: '/children', icon: UsersRound, tint: 'gold', caption: 'قيم نعيشها كل يوم' },
  { title: 'سنن مهجورة', route: '/sunnah', icon: Sparkles, tint: 'sage', caption: 'أعمال يسيرة وأجر' },
  { title: 'اختبر معرفتك', route: '/quiz', icon: CircleHelp, tint: 'sand', caption: 'تعلم بسؤال وجواب' },
];
const navItems = [
  { label: 'الرئيسية', href: '/', icon: Home },
  { label: 'الأذكار', href: '/adhkar', icon: Sun },
  { label: 'الأدعية', href: '/duas', icon: HandHeart },
  { label: 'الصلاة', href: '/prayer', icon: Compass },
  { label: 'الوضوء', href: '/wudu', icon: Droplets },
  { label: 'النوافل', href: '/nawafil', icon: Landmark },
  { label: 'الأنبياء', href: '/prophets', icon: BookOpen },
  { label: 'للأطفال', href: '/children', icon: UsersRound },
  { label: 'سنن مهجورة', href: '/sunnah', icon: Sparkles },
  { label: 'الاختبار', href: '/quiz', icon: CircleHelp },
  { label: 'المفضلة', href: '/favorites', icon: Bookmark },
];

function App() {
  const [location, setLocation] = useLocation();
  const [dark, setDark] = useState(() => getStored('rafiq-theme', false));
  const [favorites, setFavorites] = useState<string[]>(() => getStored('rafiq-favorites', []));
  const [counts, setCounts] = useState<Record<string, number>>(() => getStored('rafiq-counts', {}));
  const [search, setSearch] = useState('');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [rating, setRating] = useState<Rating | null>(() => getStored('rafiq-rating', null));
  useEffect(() => { document.documentElement.classList.toggle('dark', dark); save('rafiq-theme', dark); }, [dark]);
  useEffect(() => { save('rafiq-favorites', favorites); }, [favorites]);
  useEffect(() => { save('rafiq-counts', counts); }, [counts]);
  useEffect(() => { document.title = 'رفيق الإسلام'; document.documentElement.lang = 'ar'; document.documentElement.dir = 'rtl'; }, []);
  const allItems = useMemo(() => [...adhkar, ...duas, ...sunnahs], []);
  const doFavorite = (id: string) => setFavorites(curr => curr.includes(id) ? curr.filter(x => x !== id) : [...curr, id]);
  const changeCount = (id: string, diff: number, target?: number) => setCounts(curr => ({ ...curr, [id]: target ?? Math.max(0, (curr[id] ?? 0) + diff) }));
  const results = search.trim() ? [
    ...allItems.filter(i => `${i.title} ${i.category} ${i.body}`.includes(search.trim())).map(item => ({ title: item.title, subtitle: item.category, href: item.kind === 'دعاء' ? '/duas' : item.kind === 'سنة' ? '/sunnah' : '/adhkar' })),
    ...lessons.filter(i => `${i.title} ${i.explanation}`.includes(search.trim())).map(item => ({ title: item.title, subtitle: 'السلوكيات الإسلامية للأطفال', href: '/children' })),
    ...prophets.filter(i => `${i.name} ${i.people} ${i.message}`.includes(search.trim())).map(item => ({ title: item.name, subtitle: 'قصص الأنبياء', href: '/prophets' })),
    ...prayers.filter(i => `${i.name} ${i.time}`.includes(search.trim())).map(item => ({ title: `صلاة ${item.name}`, subtitle: 'دليل الصلاة', href: '/prayer' })),
  ] : [];
  const routeTitles: Record<string, string> = { '/adhkar': 'الأذكار اليومية', '/duas': 'الأدعية', '/prayer': 'دليل الصلاة', '/wudu': 'دليل الوضوء', '/nawafil': 'صلاة التطوع', '/prophets': 'الأنبياء في القرآن', '/children': 'السلوكيات الإسلامية للأطفال', '/sunnah': 'سنن مهجورة', '/quiz': 'اختبر معرفتك', '/favorites': 'مكتبتي المحفوظة', '/rating': 'رأيك يهمنا' };
  return <div className="app-shell" dir="rtl">
    <aside className={`side-nav fixed inset-y-0 right-0 z-50 flex w-[270px] flex-col border-l border-[hsl(var(--sidebar-border))] px-5 py-6 transition-transform duration-300 md:translate-x-0 ${mobileOpen ? 'translate-x-0' : 'translate-x-full md:translate-x-0'}`}>
      <div className="flex items-center justify-between px-1">
        <Link href="/" className="flex items-center gap-3 rounded-xl">
          <span className="brand-mark flex h-11 w-11 items-center justify-center rounded-2xl"><span className="font-serif text-2xl">ر</span></span>
          <span><span className="block text-[17px] font-bold tracking-tight">رفيق الإسلام</span><span className="mt-0.5 block text-[11px] text-[hsl(var(--sidebar-foreground)/.62)]">رفيقك في طريق الخير</span></span>
        </Link>
        <button className="rounded-lg p-2 hover:bg-[hsl(var(--sidebar-accent))] md:hidden" aria-label="إغلاق القائمة" onClick={() => setMobileOpen(false)}><X size={18}/></button>
      </div>
      <div className="my-7 h-px bg-[hsl(var(--sidebar-border))]"/>
      <p className="mb-3 px-3 text-[10px] font-semibold tracking-[.18em] text-[hsl(var(--sidebar-foreground)/.48)]">مساحتك اليومية</p>
      <nav className="scrollbar-none flex-1 space-y-1 overflow-y-auto">
        {navItems.map(item => { const Icon = item.icon; const active = location === item.href; return <Link key={item.href} href={item.href} onClick={() => setMobileOpen(false)} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] transition-colors ${active ? 'bg-[hsl(var(--sidebar-accent))] font-semibold text-[hsl(var(--sidebar-primary))]' : 'text-[hsl(var(--sidebar-foreground)/.78)] hover:bg-[hsl(var(--sidebar-accent))]'}`}><Icon size={17} strokeWidth={1.8}/><span className="flex-1">{item.label}</span>{active && <span className="h-1.5 w-1.5 rounded-full bg-[hsl(var(--sidebar-primary))]"/>}</Link>; })}
      </nav>
      <div className="mt-5 rounded-2xl border border-[hsl(var(--sidebar-border))] bg-[hsl(var(--sidebar-accent)/.65)] p-4">
        <p className="text-xs font-semibold">خطوة صغيرة كل يوم</p><p className="mt-1.5 text-[11px] leading-6 text-[hsl(var(--sidebar-foreground)/.65)]">اجعل الذكر قريبًا من قلبك، وابدأ بما تستطيع.</p>
        <Link href="/rating" className="mt-3 inline-flex items-center gap-1 text-[11px] font-semibold text-[hsl(var(--sidebar-primary))]">شاركنا رأيك <ChevronLeft size={14}/></Link>
      </div>
      <p className="mt-5 px-2 text-[10px] text-[hsl(var(--sidebar-foreground)/.4)]">رفيق الإسلام · علم موثوق بلغة قريبة</p>
    </aside>
    {mobileOpen && <button aria-label="إغلاق القائمة" className="fixed inset-0 z-40 bg-black/35 md:hidden" onClick={() => setMobileOpen(false)}/>}
    <div className="min-h-[100dvh] md:mr-[270px]">
      <header className="sticky top-0 z-30 border-b border-[hsl(var(--border)/.8)] bg-[hsl(var(--background)/.93)] px-4 backdrop-blur-md sm:px-7">
        <div className="page-wrap flex h-[72px] items-center justify-between gap-3">
          <div className="flex min-w-0 items-center gap-2">
            <button className="rounded-xl border border-[hsl(var(--border))] p-2 md:hidden" aria-label="فتح القائمة" onClick={() => setMobileOpen(true)}><Menu size={19}/></button>
            <div className="hidden items-center gap-2 text-xs text-[hsl(var(--muted-foreground))] sm:flex"><span>رفيق الإسلام</span><ChevronLeft size={13}/><span className="font-semibold text-[hsl(var(--foreground))]">{routeTitles[location] ?? 'رفيقك اليومي'}</span></div>
          </div>
          <div className="relative w-full max-w-[420px]">
            <Search size={17} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[hsl(var(--muted-foreground))]"/>
            <input value={search} onChange={e => setSearch(e.target.value)} onKeyDown={e => e.key === 'Enter' && setLocation('/search')} placeholder="ابحث في الأذكار، الأدعية، الصلاة..." aria-label="بحث شامل" className="h-10 w-full rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] pr-10 pl-10 text-xs outline-none transition focus:border-[hsl(var(--ring))]"/>
            {search && <button onClick={() => setSearch('')} className="absolute left-3 top-1/2 -translate-y-1/2 rounded p-1 text-[hsl(var(--muted-foreground))]" aria-label="مسح البحث"><X size={14}/></button>}
            {search && <div className="absolute right-0 top-12 z-40 max-h-[360px] w-full overflow-y-auto rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-2 shadow-xl">
              {results.length ? results.slice(0, 8).map((r,i) => <Link key={`${r.href}-${r.title}-${i}`} href={r.href} onClick={() => setSearch('')} className="flex items-center justify-between rounded-xl px-3 py-2.5 text-right hover:bg-[hsl(var(--muted))]"><span><span className="block text-sm font-semibold">{r.title}</span><span className="mt-1 block text-[11px] text-[hsl(var(--muted-foreground))]">{r.subtitle}</span></span><ChevronLeft size={15}/></Link>) : <p className="p-4 text-center text-xs text-[hsl(var(--muted-foreground))]">لا توجد نتائج مطابقة. جرّب كلمة أخرى.</p>}
            </div>}
          </div>
          <button onClick={() => setDark(!dark)} className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] transition hover:bg-[hsl(var(--muted))]" aria-label={dark ? 'تفعيل الوضع الفاتح' : 'تفعيل الوضع الداكن'}>{dark ? <Sun size={17}/> : <Moon size={17}/>}</button>
        </div>
      </header>
      <main className="px-4 pb-16 pt-7 sm:px-7 sm:pt-9">
        <div className="page-wrap fade-up">
          <Switch>
            <Route path="/"><HomePage categories={categories} search={search} setSearch={setSearch} favorites={favorites} counts={counts}/></Route>
            <Route path="/adhkar"><ContentPage title="الأذكار اليومية" eyebrow="طمأنينة في كل وقت" description="أذكار مأثورة مصنفة بحسب يومك، مع مراجع واضحة وعدّاد يساعدك على المتابعة." items={adhkar} favorites={favorites} onFavorite={doFavorite} counts={counts} onCount={changeCount} categories={['الكل','أذكار الصباح والمساء','أذكار النوم','أذكار الاستيقاظ','أذكار بعد الصلاة','أذكار الصلاة','أذكار الوضوء','أذكار المسجد','أذكار الطعام','أذكار السفر','أذكار المنزل','تسبيح','استغفار','الصلاة على النبي']}/></Route>
            <Route path="/duas"><ContentPage title="الأدعية" eyebrow="اسأل الله من فضله" description="أدعية من القرآن والسنة وأدعية يومية ثابتة المصدر." items={duas} favorites={favorites} onFavorite={doFavorite} counts={counts} onCount={changeCount} categories={['الكل','أدعية قرآنية','أدعية نبوية','أدعية يومية']}/></Route>
            <Route path="/prayer"><PrayerPage/></Route>
            <Route path="/wudu"><WuduPage/></Route>
            <Route path="/nawafil"><NawafilPage favorites={favorites} onFavorite={doFavorite} counts={counts} onCount={changeCount}/></Route>
            <Route path="/prophets"><ProphetsPage/></Route>
            <Route path="/children"><ChildrenPage/></Route>
            <Route path="/sunnah"><ContentPage title="سنن مهجورة" eyebrow="أعمال يسيرة، ومعنى عظيم" description="ممارسات نبوية يمكن إحياؤها في حياتنا اليومية، مع بيان طريقة العمل ومصدره." items={sunnahs} favorites={favorites} onFavorite={doFavorite} counts={counts} onCount={changeCount} categories={['الكل']}/></Route>
            <Route path="/quiz"><QuizPage/></Route>
            <Route path="/favorites"><FavoritesPage items={allItems.filter(i => favorites.includes(i.id))} onFavorite={doFavorite} favorites={favorites} counts={counts} onCount={changeCount}/></Route>
            <Route path="/rating"><RatingPage rating={rating} onSubmit={value => { setRating(value); save('rafiq-rating', value); }}/></Route>
            <Route path="/search"><SearchPage query={search} results={results}/></Route>
            <Route><NotFoundPage/></Route>
          </Switch>
        </div>
      </main>
      <footer className="border-t border-[hsl(var(--border))] px-5 py-5 text-center text-[11px] text-[hsl(var(--muted-foreground))]">رفيق الإسلام · محتوى تعليمي بمراجع ظاهرة · تعلّم بتؤدة وارجع لأهل العلم فيما أشكل</footer>
    </div>
  </div>;
}

function SectionHeading({ eyebrow, title, description }: { eyebrow: string; title: string; description: string }) {
  return <div className="mb-7"><p className="mb-2 text-[11px] font-bold tracking-[.14em] text-[hsl(var(--primary))]">{eyebrow}</p><h1 className="font-serif text-[32px] font-bold leading-tight sm:text-[38px]">{title}</h1><p className="mt-2 max-w-2xl text-[13px] leading-7 text-[hsl(var(--muted-foreground))]">{description}</p></div>;
}

function HomePage({ categories: cats, search, setSearch, favorites, counts }: { categories: typeof categories; search: string; setSearch: (s:string)=>void; favorites:string[]; counts:Record<string,number> }) {
  const date = new Intl.DateTimeFormat('ar', { weekday:'long', year:'numeric', month:'long', day:'numeric' }).format(new Date());
  const daily = duas[0];
  const total = Object.values(counts).reduce((a,b)=>a+b,0);
  return <div className="space-y-8">
    <section className="hero-pattern relative overflow-hidden rounded-[28px] bg-[hsl(var(--primary))] px-6 py-8 text-[hsl(var(--primary-foreground))] sm:px-10 sm:py-11">
      <div className="absolute -left-10 -top-16 h-56 w-56 rounded-full border border-[hsl(var(--accent)/.26)]"/><div className="absolute -left-1 top-0 h-40 w-40 rounded-full border border-[hsl(var(--accent)/.2)]"/>
      <div className="relative max-w-[650px]"><p className="mb-3 flex items-center gap-2 text-xs text-[hsl(var(--accent))]"><span className="h-px w-6 bg-[hsl(var(--accent))]"/>{date}</p><h1 className="font-serif text-4xl font-bold leading-[1.3] sm:text-5xl">رفيقٌ يقرّبك<br className="sm:hidden"/> من الخير.</h1><p className="mt-3 max-w-md text-sm leading-7 text-[hsl(var(--primary-foreground)/.78)]">مساحة مطمئنة للتعلم والذكر، خطوةً صغيرة كل يوم.</p>
      <div className="mt-6 flex flex-wrap gap-3"><Link href="/adhkar" className="inline-flex items-center gap-2 rounded-xl bg-[hsl(var(--accent))] px-4 py-2.5 text-xs font-bold text-[hsl(var(--primary))] transition hover:opacity-90">ابدأ أذكارك <ChevronLeft size={15}/></Link><Link href="/prayer" className="inline-flex items-center gap-2 rounded-xl border border-[hsl(var(--primary-foreground)/.25)] px-4 py-2.5 text-xs font-semibold hover:bg-[hsl(var(--primary-foreground)/.08)]">تعلم الصلاة</Link></div>
      </div>
      <div className="relative mt-7 flex items-center gap-5 border-t border-[hsl(var(--primary-foreground)/.14)] pt-5 sm:absolute sm:bottom-8 sm:left-10 sm:mt-0 sm:border-0 sm:pt-0"><div><p className="text-[10px] text-[hsl(var(--primary-foreground)/.6)]">أذكار أُنجزت</p><p className="mt-1 text-xl font-bold tabular-nums">{total.toLocaleString('ar')}</p></div><div className="h-8 w-px bg-[hsl(var(--primary-foreground)/.2)]"/><div><p className="text-[10px] text-[hsl(var(--primary-foreground)/.6)]">محفوظاتك</p><p className="mt-1 text-xl font-bold tabular-nums">{favorites.length.toLocaleString('ar')}</p></div></div>
    </section>
    <section className="grid gap-5 lg:grid-cols-[1.35fr_.8fr]">
      <div><div className="mb-4 flex items-end justify-between"><div><p className="text-[11px] font-semibold text-[hsl(var(--muted-foreground))]">اختر ما تحتاجه</p><h2 className="mt-1 font-serif text-2xl font-bold">طريقك إلى المعرفة</h2></div><span className="text-[11px] text-[hsl(var(--muted-foreground))]">{cats.length} أبواب</span></div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">{cats.map((cat, i) => { const Icon = cat.icon; return <Link href={cat.route} key={cat.route} className={`content-card group min-h-[137px] p-4 transition duration-200 hover:-translate-y-1 ${i===0?'sm:col-span-2 sm:row-span-1':''}`}><div className={`mb-4 flex h-9 w-9 items-center justify-center rounded-xl ${cat.tint==='gold'?'bg-[#f4ead1] text-[#8f6d2e]':cat.tint==='sage'?'bg-[#deebe3] text-[#3f715b]':cat.tint==='blue'?'bg-[#dce8ec] text-[#4c7481]':cat.tint==='rose'?'bg-[#f1e3dc] text-[#a26a55]':'bg-[#e9e5d7] text-[#6e6b4a]'}`}><Icon size={18}/></div><p className="text-[13px] font-bold">{cat.title}</p><p className="mt-1.5 text-[10px] leading-5 text-[hsl(var(--muted-foreground))]">{cat.caption}</p></Link>; })}</div>
      </div>
      <div className="content-card relative overflow-hidden p-5 sm:p-6"><div className="absolute left-0 top-0 h-24 w-24 rounded-full bg-[hsl(var(--accent)/.18)] blur-2xl"/><div className="relative"><div className="flex items-center justify-between"><span className="inline-flex items-center gap-1.5 rounded-full bg-[hsl(var(--accent)/.25)] px-2.5 py-1 text-[10px] font-semibold text-[hsl(var(--primary))]"><Sparkles size={12}/> زاد اليوم</span><span className="text-[10px] text-[hsl(var(--muted-foreground))]">{date}</span></div><h2 className="mt-5 font-serif text-xl font-bold">{daily.title}</h2><p className="arabic-text mt-3 text-[22px] leading-[2]">{daily.body}</p><p className="mt-3 text-[10px] text-[hsl(var(--muted-foreground))]">{daily.reference}</p><Link href="/duas" className="mt-5 inline-flex items-center gap-1 text-xs font-bold text-[hsl(var(--primary))]">اكتشف أدعية أخرى <ChevronLeft size={15}/></Link></div></div>
    </section>
    <section className="content-card flex flex-col items-start justify-between gap-4 p-5 sm:flex-row sm:items-center sm:px-7"><div className="flex items-center gap-4"><div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[hsl(var(--secondary))] text-[hsl(var(--primary))]"><ScrollText size={22}/></div><div><p className="text-sm font-bold">تابع تعلّمك على مهل</p><p className="mt-1 text-xs leading-6 text-[hsl(var(--muted-foreground))]">قصص الأنبياء، قيم للصغار، واختبار خفيف لتثبيت المعرفة.</p></div></div><Link href="/quiz" className="inline-flex items-center gap-2 rounded-xl bg-[hsl(var(--primary))] px-4 py-2.5 text-xs font-semibold text-[hsl(var(--primary-foreground))]">جرّب سؤالًا <ChevronLeft size={15}/></Link></section>
  </div>;
}

function ContentPage({ title, eyebrow, description, items, favorites, onFavorite, counts, onCount, categories: filters }: { title:string; eyebrow:string; description:string; items:ContentItem[]; favorites:string[]; onFavorite:(id:string)=>void; counts:Record<string,number>; onCount:(id:string,diff:number,target?:number)=>void; categories:string[] }) {
  const [filter, setFilter] = useState('الكل');
  const shown = filter === 'الكل' ? items : items.filter(item => item.category === filter);
  return <><SectionHeading eyebrow={eyebrow} title={title} description={description}/><div className="scrollbar-none mb-6 flex gap-2 overflow-x-auto pb-1">{filters.map(f => <button key={f} onClick={()=>setFilter(f)} className={`shrink-0 rounded-full border px-4 py-2 text-xs transition ${filter===f?'border-[hsl(var(--primary))] bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]':'border-[hsl(var(--border))] bg-[hsl(var(--card))] hover:bg-[hsl(var(--muted))]'}`}>{f}</button>)}</div>
    {shown.length ? <div className="grid gap-4 lg:grid-cols-2">{shown.map(item => <ContentCard key={item.id} item={item} favorite={favorites.includes(item.id)} onFavorite={()=>onFavorite(item.id)} count={counts[item.id] ?? 0} onCount={(d,target)=>onCount(item.id,d,target)}/>)}</div> : <EmptyState title="لا توجد عناصر في هذا القسم بعد" text="اختر تصنيفًا آخر لاستكشاف المزيد."/>}</>;
}
function ContentCard({ item, favorite, onFavorite, count, onCount }: { item:ContentItem; favorite:boolean; onFavorite:()=>void; count:number; onCount:(d:number,target?:number)=>void }) {
  const [done, setDone] = useState(false);
  return <article className="content-card p-5 sm:p-6"><div className="flex items-start justify-between gap-3"><div><span className="rounded-full bg-[hsl(var(--secondary))] px-2.5 py-1 text-[10px] font-semibold text-[hsl(var(--primary))]">{item.category}</span><h2 className="mt-3 text-base font-bold">{item.title}</h2></div><button onClick={onFavorite} aria-label={favorite?'إزالة من المفضلة':'إضافة إلى المفضلة'} className={`rounded-xl border p-2 transition ${favorite?'border-rose-200 bg-rose-50 text-rose-700':'border-[hsl(var(--border))] text-[hsl(var(--muted-foreground))] hover:text-rose-600'}`}><Heart size={17} fill={favorite?'currentColor':'none'}/></button></div>
    <p className={`${item.kind==='ذكر'||item.kind==='دعاء'?'arabic-text text-[22px] leading-[2]':'mt-4 text-[14px] leading-8'} mt-4`}>{item.body}</p><div className="mt-4 flex items-start gap-2 border-t border-[hsl(var(--border))] pt-3 text-[10px] leading-5 text-[hsl(var(--muted-foreground))]"><Info size={13} className="mt-0.5 shrink-0"/><span>المصدر: {item.reference}</span></div>
    {item.repetitions && <div className="mt-4 flex items-center justify-between rounded-xl bg-[hsl(var(--muted)/.58)] p-2.5"><div><p className="text-[10px] text-[hsl(var(--muted-foreground))]">العدد المنقول</p><p className="mt-0.5 text-xs font-semibold">{item.repetitions} مرة</p></div><div className="flex items-center gap-2"><button aria-label="إنقاص العداد" onClick={()=>{onCount(-1);setDone(false)}} className="rounded-lg border border-[hsl(var(--border))] p-2 hover:bg-[hsl(var(--card))]"><Minus size={14}/></button><button onClick={()=>{onCount(1); if(count+1 >= item.repetitions!) setDone(true)}} className={`min-w-14 rounded-lg px-3 py-2 text-xs font-bold tabular-nums ${done?'bg-[hsl(var(--accent))] text-[hsl(var(--primary))]':'bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]'}`}>{done?<Check size={15} className="mx-auto"/>:`${count}/${item.repetitions}`}</button><button aria-label="تصفير العداد" onClick={()=>{onCount(0,0);setDone(false)}} className="rounded-lg border border-[hsl(var(--border))] p-2 hover:bg-[hsl(var(--card))]"><RotateCcw size={14}/></button></div></div>}
  </article>;
}
function PrayerPage() {
  const [selected,setSelected]=useState(prayers[0].name); const prayer=prayers.find(p=>p.name===selected)!;
  return <><SectionHeading eyebrow="عبادة تتكرر كل يوم" title="دليل الصلاة" description="تعرف على أوقات الصلوات وعدد ركعاتها، واتبع خطوات مبسطة. تعلّم صفة الصلاة من معلم موثوق إن أمكن."/><div className="mb-5 flex flex-wrap gap-2">{prayers.map(p=><button key={p.name} onClick={()=>setSelected(p.name)} className={`rounded-full border px-4 py-2 text-xs transition ${selected===p.name?'border-[hsl(var(--primary))] bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]':'border-[hsl(var(--border))] bg-[hsl(var(--card))] hover:bg-[hsl(var(--muted))]'}`}>{p.name}</button>)}</div>
    <div className="grid gap-5 lg:grid-cols-[.72fr_1.28fr]"><section className="content-card h-fit p-5"><div className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl bg-[hsl(var(--secondary))] text-[hsl(var(--primary))]"><Clock3 size={23}/></div><p className="text-[11px] text-[hsl(var(--muted-foreground))]">الصلاة المختارة</p><h2 className="mt-1 font-serif text-2xl font-bold">{prayer.name}</h2><div className="mt-5 space-y-4 border-t border-[hsl(var(--border))] pt-4"><div><p className="text-[10px] text-[hsl(var(--muted-foreground))]">عدد الركعات</p><p className="mt-1 text-sm font-semibold leading-7">{prayer.rakats}</p></div><div><p className="text-[10px] text-[hsl(var(--muted-foreground))]">الوقت</p><p className="mt-1 text-sm leading-7">{prayer.time}</p></div></div></section>
      <section className="content-card p-5 sm:p-7"><h2 className="text-lg font-bold">خطوات الصلاة</h2><ol className="mt-5 space-y-4">{prayer.steps.map((step,i)=><li key={step} className="flex gap-3"><span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[hsl(var(--secondary))] text-xs font-bold text-[hsl(var(--primary))]">{(i+1).toLocaleString('ar')}</span><p className="pt-0.5 text-sm leading-7">{step}</p></li>)}</ol><div className="mt-6 rounded-xl bg-[hsl(var(--muted)/.65)] p-4"><p className="text-xs font-bold">تنبيه فقهي</p><p className="mt-1 text-xs leading-6 text-[hsl(var(--muted-foreground))]">{prayer.notes}</p></div><p className="mt-4 text-[10px] leading-5 text-[hsl(var(--muted-foreground))]">المصدر: {prayer.source}</p></section></div></>;
}
function WuduPage() {
 return <><SectionHeading eyebrow="الطهارة" title="دليل الوضوء" description="تعلم ترتيب الوضوء ومعنى كل خطوة. نميز بين ما ورد فرضًا في آية الوضوء وما هو سنة أو محل تفصيل فقهي."/><div className="mb-5 flex flex-wrap gap-3"><span className="inline-flex items-center gap-2 rounded-full bg-[hsl(var(--primary)/.1)] px-3 py-2 text-xs"><span className="h-2 w-2 rounded-full bg-[hsl(var(--primary))]"/> واجب في الجملة</span><span className="inline-flex items-center gap-2 rounded-full bg-[hsl(var(--accent)/.32)] px-3 py-2 text-xs"><span className="h-2 w-2 rounded-full bg-[hsl(var(--accent))]"/> سنة أو تفصيل مختلف فيه</span></div>
   <div className="space-y-3">{wuduSteps.map(step=><article key={step.number} className="content-card flex gap-4 p-4 sm:gap-5 sm:p-5"><div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-sm font-bold ${step.status==='required'?'bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]':'bg-[hsl(var(--accent)/.45)] text-[hsl(var(--primary))]'}`}>{step.number.toLocaleString('ar')}</div><div className="flex-1"><div className="flex flex-wrap items-center justify-between gap-2"><h2 className="text-sm font-bold">{step.title}</h2><span className={`rounded-full px-2.5 py-1 text-[10px] ${step.status==='required'?'bg-[hsl(var(--primary)/.1)] text-[hsl(var(--primary))]':'bg-[hsl(var(--accent)/.25)] text-[hsl(var(--foreground))]'}`}>{step.status==='required'?'فرض في الجملة':'سنة / تفصيل فقهي'}</span></div><p className="mt-2 text-xs leading-7 text-[hsl(var(--muted-foreground))]">{step.detail}</p><p className="mt-2 text-[10px]">المصدر: {step.source}</p></div></article>)}</div><div className="mt-5 rounded-2xl border border-[hsl(var(--accent)/.55)] bg-[hsl(var(--accent)/.14)] p-4 text-xs leading-7"><strong>ملاحظة مهمة:</strong> ترتيب بعض السنن وحكم المضمضة والاستنشاق والتسمية وتفاصيل مسح الرأس تتباين بين المذاهب. هذا عرض تعليمي عام وليس فتوى خاصة.</div></>;
}
function NawafilPage({ favorites,onFavorite,counts,onCount }: {favorites:string[];onFavorite:(id:string)=>void;counts:Record<string,number>;onCount:(id:string,d:number,target?:number)=>void}) {
 const items:ContentItem[]=[
  {id:'rawatib',title:'السنن الرواتب',category:'نوافل',body:'من الرواتب المؤكدة: ركعتان قبل الفجر، وأربع قبل الظهر وركعتان بعدها، وركعتان بعد المغرب، وركعتان بعد العشاء. جاءت روايات أخرى في التفصيل.',reference:'صحيح مسلم، ٧٢٨؛ صحيح البخاري، ١١٨٠',kind:'سنة'},
  {id:'n-duha',title:'صلاة الضحى',category:'نوافل',body:'ركعتان فأكثر مثنى مثنى، من بعد ارتفاع الشمس إلى قبيل الزوال. لا عدد لازم لها.',reference:'صحيح مسلم، ٧٢٠',kind:'سنة'},
  {id:'n-witr',title:'الوتر',category:'نوافل',body:'صلاة تختم بها صلاة الليل، ركعة أو أكثر بوتر. ثبتت صور متنوعة في الأداء والعدد.',reference:'صحيح مسلم، ٧٥١',kind:'سنة'},
  {id:'tahajjud',title:'التهجد وقيام الليل',category:'نوافل',body:'صلِّ ما تيسر ركعتين ركعتين، وآخر الليل أفضل لمن لا يشق عليه. لا يكلّف الله نفسًا إلا وسعها.',reference:'صحيح البخاري، ١١٣٧؛ صحيح مسلم، ٧٤٩',kind:'سنة'},
  {id:'tarawih',title:'قيام رمضان (التراويح)',category:'نوافل',body:'قيام ليالي رمضان عبادة عظيمة؛ صلّ مع الإمام بخشوع، والعدد والهيئة فيهما سعة معتبرة بين أهل العلم.',reference:'صحيح البخاري، ٢٠٠٩؛ صحيح مسلم، ٧٥٩',kind:'سنة'},
  {id:'masjid-prayer',title:'تحية المسجد',category:'نوافل',body:'إذا دخلت المسجد فصل ركعتين قبل الجلوس إن لم يكن وقت نهي عند من يقول بذلك؛ المسألة لها تفصيل فقهي.',reference:'صحيح البخاري، ٤٤٤؛ صحيح مسلم، ٧١٤',kind:'سنة'},
  {id:'istikhara-prayer',title:'الاستخارة',category:'نوافل',body:'ركعتان من غير الفريضة ثم دعاء الاستخارة في الأمر المباح، مع الاستشارة والأخذ بالأسباب.',reference:'صحيح البخاري، ١١٦٦',kind:'سنة'},
  {id:'tawbah-prayer',title:'صلاة التوبة',category:'نوافل',body:'إذا أذنب المسلم فليتب فورًا، وله أن يصلي ركعتين ويستغفر. الصلاة ليست شرطًا لصحة التوبة.',reference:'سنن أبي داود، ١٥٢١؛ سورة التحريم: ٨',kind:'سنة'},
  {id:'other-nafl',title:'صلاة مطلقة',category:'نوافل',body:'التطوع بالصلاة مشروع في الأوقات التي لا نهي فيها، مع مراعاة أحكام النوافل عند مذهبك.',reference:'صحيح البخاري، ١١٢٣؛ مسائل الأوقات فيها تفصيل فقهي',kind:'سنة'},
 ]; return <ContentPage title="صلاة التطوع" eyebrow="قربات على قدر الاستطاعة" description="تعرف على الرواتب والنوافل المشروعة. المسائل التي تتعدد فيها صور الأداء موضحة دون تقديم رأي فقهي واحد كأنه محل إجماع." items={items} favorites={favorites} onFavorite={onFavorite} counts={counts} onCount={onCount} categories={['الكل']}/>;
}
function ProphetsPage() {
 const [selected,setSelected]=useState(0); const prophet=prophets[selected];
 return <><SectionHeading eyebrow="قصص الوحي" title="الأنبياء في القرآن" description="تعرف على عدد من أنبياء الله ورسالاتهم وآياتهم كما وردت في القرآن والسنة الصحيحة. ترتيب الأعمار والتواريخ التقديرية لا يُعرض على أنه يقين."/>
  <div className="mb-5 flex flex-wrap gap-2">{prophets.map((p,i)=><button key={p.name} onClick={()=>setSelected(i)} className={`rounded-full border px-4 py-2 text-xs ${selected===i?'border-[hsl(var(--primary))] bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]':'border-[hsl(var(--border))] bg-[hsl(var(--card))]'}`}>{p.name}</button>)}</div>
  <article className="content-card overflow-hidden"><div className="hero-pattern bg-[hsl(var(--primary))] p-6 text-[hsl(var(--primary-foreground))] sm:p-8"><p className="text-xs text-[hsl(var(--accent))]">نبي الله</p><h2 className="mt-2 font-serif text-3xl font-bold">{prophet.name}</h2><p className="mt-2 text-sm text-[hsl(var(--primary-foreground)/.8)]">{prophet.people}</p></div><div className="grid gap-5 p-5 sm:grid-cols-2 sm:p-7"><InfoBlock title="رسالته" text={prophet.message}/><InfoBlock title="أحداث من قصته" text={prophet.events}/><InfoBlock title="الآيات والدلالات" text={prophet.signs}/><InfoBlock title="مراجع للاستزادة" text={prophet.verses}/></div><div className="border-t border-[hsl(var(--border))] bg-[hsl(var(--muted)/.48)] px-5 py-4 text-xs leading-6 text-[hsl(var(--muted-foreground))]"><strong className="text-[hsl(var(--foreground))]">ملاحظة حول التسلسل:</strong> {prophet.chronologyNote}</div></article><p className="mt-4 text-[11px] leading-6 text-[hsl(var(--muted-foreground))]">ورد ذكر خمسة وعشرين نبيًا بالاسم في القرآن الكريم. هذه الصفحة تعرض نماذج تعليمية مختارة، وترتيبها الزمني تقريبي بحسب القصص، لا تأريخًا قطعيًا.</p></>;
}
function InfoBlock({title,text}:{title:string;text:string}) { return <div className="rounded-xl bg-[hsl(var(--muted)/.55)] p-4"><h3 className="text-xs font-bold">{title}</h3><p className="mt-2 text-xs leading-7 text-[hsl(var(--muted-foreground))]">{text}</p></div>; }
function ChildrenPage() {
 const [query,setQuery]=useState('');
 const shown=lessons.filter(l=>`${l.title} ${l.explanation}`.includes(query));
 return <><SectionHeading eyebrow="قيم تكبر معنا" title="السلوكيات الإسلامية للأطفال" description="مواقف قصيرة بلغة قريبة، تساعد الطفل على فهم الخلق الحسن وتجربته في البيت والمدرسة."/><div className="relative mb-5 max-w-sm"><Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-[hsl(var(--muted-foreground))]"/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="ابحث عن قيمة..." className="h-10 w-full rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] pr-9 pl-3 text-xs"/></div>
 {shown.length?<div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">{shown.map((lesson,i)=><article key={lesson.title} className="content-card p-5"><div className="flex items-center justify-between"><span className="flex h-8 w-8 items-center justify-center rounded-xl bg-[hsl(var(--secondary))] text-xs font-bold text-[hsl(var(--primary))]">{(i+1).toLocaleString('ar')}</span><HandHeart size={17} className="text-[hsl(var(--primary))]"/></div><h2 className="mt-4 text-base font-bold">{lesson.title}</h2><p className="mt-2 text-xs leading-7 text-[hsl(var(--muted-foreground))]">{lesson.explanation}</p><div className="mt-3 rounded-xl bg-[hsl(var(--muted)/.55)] p-3"><p className="text-[10px] font-bold">مثال من يومك</p><p className="mt-1 text-xs leading-6">{lesson.example}</p></div><p className="mt-3 text-[10px] text-[hsl(var(--muted-foreground))]">مرجع: {lesson.reference}</p></article>)}</div>:<EmptyState title="لم نعثر على هذه القيمة" text="جرّب كلمة بحث أخرى."/ >}</>;
}
function QuizPage() {
 const [difficulty,setDifficulty]=useState('الكل'); const [category,setCategory]=useState('الكل'); const [idx,setIdx]=useState(0); const [answer,setAnswer]=useState<number|null>(null); const [score,setScore]=useState(()=>getStored('rafiq-quiz-score',0)); const [asked,setAsked]=useState(()=>getStored('rafiq-quiz-asked',0)); const [shuffle,setShuffle]=useState(0);
 const pool=quizQuestions.filter(q=>(difficulty==='الكل'||q.difficulty===difficulty)&&(category==='الكل'||q.category===category));
 const question=pool[(idx+shuffle)%Math.max(1,pool.length)];
 const next=()=>{setIdx((idx+1)%Math.max(1,pool.length));setAnswer(null)};
 const respond=(choice:number)=>{if(answer!==null)return;setAnswer(choice);setAsked(asked+1);setAskedState(asked+1);if(choice===question.correctIndex){const n=score+1;setScore(n);save('rafiq-quiz-score',n);}save('rafiq-quiz-asked',asked+1);};
 function setAskedState(n:number){setAsked(n);}
 const reset=()=>{setShuffle(Math.floor(Math.random()*quizQuestions.length));setIdx(0);setAnswer(null);};
 return <><SectionHeading eyebrow="تعلم بالمراجعة" title="اختبر معرفتك" description="أسئلة متعددة الخيارات مع إجابة واحدة صحيحة وشرح موجز. تقدمك يبقى محفوظًا على هذا الجهاز."/><div className="mb-5 flex flex-wrap gap-3"><label className="text-[11px]">المستوى<select value={difficulty} onChange={e=>{setDifficulty(e.target.value);setIdx(0);setAnswer(null)}} className="mr-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-2 text-xs"><option>الكل</option><option>سهل</option><option>متوسط</option><option>متقدم</option></select></label><label className="text-[11px]">المجال<select value={category} onChange={e=>{setCategory(e.target.value);setIdx(0);setAnswer(null)}} className="mr-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-2 text-xs"><option>الكل</option>{['الصلاة','القرآن','الأنبياء','الطهارة'].map(c=><option key={c}>{c}</option>)}</select></label></div>
 {question?<section className="content-card max-w-3xl p-5 sm:p-8"><div className="flex flex-wrap items-center justify-between gap-2"><span className="rounded-full bg-[hsl(var(--secondary))] px-3 py-1 text-[10px] text-[hsl(var(--primary))]">{question.category} · {question.difficulty}</span><span className="text-xs text-[hsl(var(--muted-foreground))]">النتيجة {score.toLocaleString('ar')} / {asked.toLocaleString('ar')}</span></div><h2 className="mt-6 font-serif text-2xl font-bold leading-relaxed">{question.question}</h2><div className="mt-5 space-y-2.5">{question.choices.map((choice,i)=>{const right=answer!==null&&i===question.correctIndex;const wrong=answer===i&&i!==question.correctIndex;return <button key={choice} onClick={()=>respond(i)} disabled={answer!==null} className={`flex w-full items-center justify-between rounded-xl border px-4 py-3.5 text-right text-sm transition ${right?'border-emerald-600 bg-emerald-50 text-emerald-900':wrong?'border-rose-400 bg-rose-50 text-rose-900':'border-[hsl(var(--border))] hover:bg-[hsl(var(--muted))]'} disabled:cursor-default`}><span>{choice}</span>{right&&<Check size={17}/>}</button>})}</div>{answer!==null&&<div className={`mt-4 rounded-xl p-4 text-xs leading-7 ${answer===question.correctIndex?'bg-emerald-50 text-emerald-950':'bg-[hsl(var(--muted))]'}`}><strong>{answer===question.correctIndex?'إجابة صحيحة':'ليست الإجابة الصحيحة'}</strong><p className="mt-1">{question.explanation}</p><p className="mt-1 text-[10px] opacity-75">المصدر: {question.reference}</p></div>}<div className="mt-5 flex flex-wrap gap-2"><button onClick={next} className="rounded-xl bg-[hsl(var(--primary))] px-4 py-2.5 text-xs font-bold text-[hsl(var(--primary-foreground))]">السؤال التالي <ChevronLeft size={14} className="inline"/></button><button onClick={reset} className="rounded-xl border border-[hsl(var(--border))] px-4 py-2.5 text-xs">اختبار جديد <RotateCcw size={13} className="mr-1 inline"/></button></div></section>:<EmptyState title="لا أسئلة لهذا الاختيار" text="اختر مستوى أو مجالًا آخر."/>}</>;
}
function FavoritesPage({items,onFavorite,favorites,counts,onCount}:{items:ContentItem[];onFavorite:(id:string)=>void;favorites:string[];counts:Record<string,number>;onCount:(id:string,d:number,target?:number)=>void}) {
 return <><SectionHeading eyebrow="ما احتفظت به" title="مكتبتي المحفوظة" description="الأذكار والأدعية والسنن التي أضفتها إلى مفضلتك، متاحة على هذا الجهاز."/>
 {items.length?<div className="grid gap-4 lg:grid-cols-2">{items.map(item=><ContentCard key={item.id} item={item} favorite={favorites.includes(item.id)} onFavorite={()=>onFavorite(item.id)} count={counts[item.id]??0} onCount={(d,target)=>onCount(item.id,d,target)}/>)}</div>:<EmptyState title="مكتبتك تبدأ من هنا" text="احفظ ذكرًا أو دعاءً أو سنة لتجدها بسرعة في زيارتك القادمة." action={<Link href="/adhkar" className="mt-4 inline-flex rounded-xl bg-[hsl(var(--primary))] px-4 py-2.5 text-xs font-semibold text-[hsl(var(--primary-foreground))]">اكتشف الأذكار</Link>}/>}</>;
}
function RatingPage({rating,onSubmit}:{rating:Rating|null;onSubmit:(r:Rating)=>void}) {
 const [stars,setStars]=useState(rating?.stars??0); const [feedback,setFeedback]=useState(rating?.feedback??''); const [sent,setSent]=useState(false);
 const submit=(e:FormEvent)=>{e.preventDefault();if(!stars)return;onSubmit({stars,feedback:feedback.trim(),createdAt:new Date().toISOString()});setSent(true)};
 return <><SectionHeading eyebrow="نستمع إليك" title="رأيك يهمنا" description="ساعدنا في تحسين رفيق الإسلام. تقييمك وملاحظتك يحفظان على جهازك فقط."/><section className="content-card max-w-2xl p-5 sm:p-8">{sent||rating?<div className="rounded-2xl bg-[hsl(var(--secondary))] p-6 text-center"><span className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]"><Check size={23}/></span><h2 className="mt-4 text-lg font-bold">{sent?'شكرًا لمشاركتك':'شكرًا، وصلنا تقييمك'}</h2><p className="mt-2 text-xs leading-6 text-[hsl(var(--muted-foreground))]">نقدّر وقتك. إجابتك محفوظة محليًا على هذا الجهاز.</p><button onClick={()=>setSent(false)} className="mt-4 text-xs font-semibold text-[hsl(var(--primary))]">تعديل التقييم</button></div>:<form onSubmit={submit}><label className="text-sm font-semibold">كيف كانت تجربتك؟</label><div className="mt-3 flex gap-2" role="radiogroup" aria-label="تقييم من نجمة إلى خمس نجوم">{[1,2,3,4,5].map(n=><button key={n} type="button" aria-label={`${n} نجوم`} aria-checked={stars===n} role="radio" onClick={()=>setStars(n)} className={`rounded-lg p-2 transition ${stars>=n?'text-amber-500':'text-[hsl(var(--border))]'}`}><Star size={27} fill={stars>=n?'currentColor':'none'}/></button>)}</div><label htmlFor="feedback" className="mt-5 block text-xs font-semibold">ملاحظة اختيارية</label><textarea id="feedback" value={feedback} onChange={e=>setFeedback(e.target.value)} rows={5} maxLength={500} placeholder="ما الذي أعجبك؟ وما الذي يمكن أن نطوره؟" className="mt-2 w-full resize-y rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--background))] p-3 text-sm leading-7"/><p className="mt-1 text-left text-[10px] text-[hsl(var(--muted-foreground))]">{feedback.length}/٥٠٠</p><button disabled={!stars} className="mt-4 rounded-xl bg-[hsl(var(--primary))] px-5 py-3 text-xs font-bold text-[hsl(var(--primary-foreground))] disabled:opacity-45">إرسال التقييم</button></form>}</section></>;
}
function SearchPage({query,results}:{query:string;results:{title:string;subtitle:string;href:string}[]}) { return <><SectionHeading eyebrow="بحث شامل" title="نتائج البحث" description={query?`نتائج البحث عن «${query}» في محتوى رفيق الإسلام.`:'اكتب كلمة في حقل البحث أعلى الصفحة للعثور على محتوى.'}/>{results.length?<div className="content-card divide-y divide-[hsl(var(--border))] p-2">{results.map((r,i)=><Link key={`${i}-${r.title}`} href={r.href} className="flex items-center justify-between rounded-xl px-4 py-4 hover:bg-[hsl(var(--muted))]"><div><p className="text-sm font-semibold">{r.title}</p><p className="mt-1 text-[11px] text-[hsl(var(--muted-foreground))]">{r.subtitle}</p></div><ChevronLeft size={16}/></Link>)}</div>:<EmptyState title="لا توجد نتائج" text="جرّب كتابة كلمة أقصر أو مختلفة."/>}</>; }
function EmptyState({title,text,action}:{title:string;text:string;action?:ReactNode}) { return <div className="content-card flex min-h-[230px] flex-col items-center justify-center px-6 py-10 text-center"><div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[hsl(var(--secondary))] text-[hsl(var(--primary))]"><Bookmark size={21}/></div><h2 className="mt-4 text-base font-bold">{title}</h2><p className="mt-2 max-w-sm text-xs leading-6 text-[hsl(var(--muted-foreground))]">{text}</p>{action}</div>; }
function NotFoundPage() { return <div className="py-20"><EmptyState title="هذه الصفحة غير موجودة" text="قد يكون الرابط غير صحيح. عد إلى الصفحة الرئيسية وتابع رحلتك." action={<Link href="/" className="mt-4 inline-flex rounded-xl bg-[hsl(var(--primary))] px-4 py-2.5 text-xs font-bold text-[hsl(var(--primary-foreground))]">العودة للرئيسية</Link>}/></div>; }

export default App;
