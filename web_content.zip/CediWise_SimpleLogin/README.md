# CediWise — Mobile Web App

## Install on phone
1. Host the folder on HTTPS (e.g. Netlify Drop)
2. Open the link in Chrome (Android) or Safari (iPhone)
3. **Add to Home Screen** / Install app

## Update on phone
1. Open the app
2. Tap **⚙ Settings**
3. Tap **Check for updates**
4. The app reloads if a new version is available
5. Your expenses, budget, savings, and profile are kept

## Features
- Spending, Budget, Savings
- Quotes (via Settings)
- Dark / Light mode + accent colors
- Profile name + picture (upload, camera, gallery, crop)
- Data saved on device and preserved across app updates
