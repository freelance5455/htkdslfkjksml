# CediWise — Mobile Web App

A student money manager that works in the browser like a mobile app.

## Features
- **Spending** – track daily expenses
- **Budget** – set monthly & category limits
- **Savings** – create and track goals
- **Quotes** – daily inspiration (open from Settings)
- **Light & dark mode** – switch appearance in Settings, plus accent colors
- Data is **saved on the device** and stays after refresh
- Mobile-friendly with bottom navigation (like a real app)
- Account name + image

## How to open
1. Unzip the folder
2. Open `index.html` in a browser  
   **or**
3. Drag the folder to https://app.netlify.com/drop for a phone-friendly link

## Notes
- Data is stored in the browser (localStorage)
- Clearing browser data will erase saved information
