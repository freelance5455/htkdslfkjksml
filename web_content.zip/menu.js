document.querySelectorAll('.side-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.side-item').forEach(i => i.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    item.classList.add('active');
    document.getElementById('tab-' + item.dataset.tab).classList.add('active');
  });
});

function startGame(packageName) {
  document.getElementById('gameSelect').classList.add('hidden');
  document.getElementById('hackMenu').classList.remove('hidden');
  if (typeof Shizuku !== 'undefined') {
    // Bật VNP bypass, chặn anti, bypass, scan
    if (typeof initVNP === 'function') initVNP();
    if (typeof initBlocker === 'function') initBlocker();
    if (typeof initHook === 'function') initHook();
    // Mở game
    Shizuku.newProcess(['am','start','-n', packageName + '/com.dts.freefireth.FFMainActivity'], null, null);
  }
}

document.getElementById('ffGlobal').addEventListener('click', () => startGame('com.dts.freefireth'));
document.getElementById('ffMax').addEventListener('click', () => startGame('com.dts.freefiremax'));

const sens = document.getElementById('sens');
sens.addEventListener('input', () => {
  document.getElementById('sensVal').textContent = parseFloat(sens.value).toFixed(1);
  if (typeof aimSensitivity !== 'undefined') aimSensitivity = parseFloat(sens.value);
});

document.getElementById('aimbot').addEventListener('change', e => {
  if (e.target.checked && typeof toggleAim === 'function' && !aimActive) toggleAim();
  else if (!e.target.checked && typeof toggleAim === 'function' && aimActive) toggleAim();
});

['espLine','espBox','radar','crosshair','ghost','freeze','tunel','autofire','silentaim'].forEach(id => {
  const el = document.getElementById(id);
  if (el) el.addEventListener('change', e => {
    if (typeof Shizuku !== 'undefined') {
      Shizuku.newProcess(['settings','put','global', id + '_enabled', e.target.checked ? '1' : '0'], null, null);
    }
  });
});

document.getElementById('stopBtn').addEventListener('click', () => {
  if (typeof Shizuku !== 'undefined') {
    Shizuku.newProcess(['am','force-stop','com.dts.freefireth'], null, null);
    Shizuku.newProcess(['am','force-stop','com.dts.freefiremax'], null, null);
    Shizuku.newProcess(['settings','put','global','garena_anticheat_enabled','1'], null, null);
    Shizuku.newProcess(['settings','put','global','vnp_enabled','1'], null, null);
  }
  document.getElementById('hackMenu').classList.add('hidden');
  document.getElementById('gameSelect').classList.remove('hidden');
});