<?php
declare(strict_types=1);
// Explicit alternate entry point for shared-hosting deployments.
require __DIR__ . '/admin.php';
