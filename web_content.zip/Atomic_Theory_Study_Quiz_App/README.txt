Atomic Theory Study & Quiz App

Contents:
- index.html: Self-contained mobile-friendly app.
- 30 English multiple-choice questions, including calculations.
- Short Notes and Formula Sheet sections.
- Shows correct answer and explanation after each selected answer.
- Shows final score, percentage, and full answer review.

How to use:
1. Open index.html in a modern browser (Chrome recommended).
2. To share as a simple web app, host index.html on a static hosting service and share the resulting URL.
3. To make an Android APK, use a trusted HTML-to-APK builder or Android build environment. This ZIP is NOT an APK.
