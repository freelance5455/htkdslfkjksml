# Chill Life
Mobile-friendly Papers & Videos Hub prototype.

## Admin-only upload
This prototype hides upload controls from normal users and exposes them only after the admin login.

**Demo admin:** `admin`  
**Demo password:** `ChillLife@2026`

## Important
This is a front-end prototype using browser local storage. It is **not secure enough for a public production app**. For real admin-only uploads, connect authentication + storage (Firebase or Supabase) and enforce server-side storage/database rules so users cannot bypass the UI.
