-- GH MARKETPLACE: country onboarding RPC
-- Run in Supabase SQL Editor. The function only changes the signed-in user's profile.
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS country_market text;

CREATE OR REPLACE FUNCTION public.gh_set_my_country_market(p_country_market text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $function$
DECLARE
  v_user_id uuid;
  v_existing_market text;
BEGIN
  v_user_id := auth.uid();
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Please sign in first';
  END IF;
  IF p_country_market IS NULL OR length(trim(p_country_market)) = 0 OR length(trim(p_country_market)) > 100 THEN
    RAISE EXCEPTION 'Invalid country market';
  END IF;

  -- Create the profile when signup has not created one yet. SECURITY DEFINER allows
  -- this function to bypass table RLS without granting broad INSERT/UPDATE rights.
  INSERT INTO public.profiles (id, country_market)
  VALUES (v_user_id, trim(p_country_market))
  ON CONFLICT (id) DO NOTHING;

  SELECT country_market INTO v_existing_market
  FROM public.profiles WHERE id = v_user_id FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Profile could not be created; check required columns on public.profiles';
  END IF;

  IF v_existing_market IS NULL OR trim(v_existing_market) = '' THEN
    UPDATE public.profiles SET country_market = trim(p_country_market) WHERE id = v_user_id;
  ELSIF v_existing_market = trim(p_country_market) THEN
    RETURN;
  ELSE
    RAISE EXCEPTION 'Country market is already locked. Contact GH COMPANY to change it.';
  END IF;
END;
$function$;

REVOKE ALL ON FUNCTION public.gh_set_my_country_market(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.gh_set_my_country_market(text) TO authenticated;
NOTIFY pgrst, 'reload schema';
