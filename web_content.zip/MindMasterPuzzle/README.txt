MIND MASTER — STARTER GAME PROJECT
=================================

Included:
- index.html: complete playable mobile-friendly 15-tile number puzzle game.
- README.txt: these notes.

Try it now:
1. Extract the ZIP on your phone or computer.
2. Open index.html in Chrome or another modern browser.
3. Tap New Game, then slide tiles into order.
The game saves the best move count in browser storage.

Important:
This ZIP is the playable game source, not a compiled APK or Play Store AAB.
To publish on Google Play, the game must be packaged into an Android app, tested,
signed, and prepared as an Android App Bundle (AAB). Google Play Console account
and current Play policies also apply.

Suggested next step:
Package this HTML game inside an Android WebView project using Android Studio,
or use a reputable HTML-to-Android packaging workflow. Before release, add a
privacy policy if required by the features/SDKs used, app icon, screenshots,
content rating, and test on real devices. If ads are added later, use a supported
ad SDK and follow its policies; earnings are not guaranteed.
