META QUEST 3 TIMER — ANDROID PROJECT

Це проєкт справжньої Android-програми, яка відкриває таймер з локальних файлів.
Для запуску не потрібен сайт або інтернет.

ВАЖЛИВО: це вихідний проєкт Android Studio, а не готовий APK-файл.

ЯК ЗІБРАТИ APK:
1. Встанови Android Studio на комп'ютер з офіційного сайту developer.android.com/studio.
2. Розпакуй цей ZIP у папку.
3. В Android Studio вибери Open і відкрий папку QuestTimerAndroidApp.
4. Дочекайся Gradle Sync. Якщо попросить встановити Android SDK Platform 35 або Build Tools, погодься.
5. В меню Build вибери Build Bundle(s) / APK(s) > Build APK(s).
6. Коли збірка завершиться, натисни locate у сповіщенні Android Studio. APK буде в app/build/outputs/apk/debug/app-debug.apk.
7. Перенеси APK на телефон, відкрий його та дозволь установлення з цього джерела, якщо Android запитає.

Відкриття програми працює офлайн, бо index.html і зображення вбудовані в APK.
Потрібен Android Studio та завантаження Android SDK для першої збірки.
