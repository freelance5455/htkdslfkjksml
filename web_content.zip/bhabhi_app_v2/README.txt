Just For You, Heena 🌷
A private offline surprise app. Open index.html or package the folder as an Android APK using a trusted ZIP-to-APK builder.
Includes a searchable Heena profile, emotional letter, special qualities, memories, dua, and final surprise.
