Hay Day Desk

চালু করার নিয়ম:
1. ZIP ফাইল Extract করুন।
2. index.html ফাইলটি Chrome/Browser-এ খুলুন।
3. Settings থেকে নিয়মিত JSON Backup ডাউনলোড করে রাখুন।

গুরুত্বপূর্ণ:
- App-এর ডেটা এই Browser-এর localStorage-এ থাকে।
- Browser data clear করলে ডেটা হারাতে পারে।
- সকাল ৬টার reporting day বদলালে পুরোনো Delivery History, Order বা Tag মুছে যায় না।
- এক ফোনের ডেটা অন্য ফোনে স্বয়ংক্রিয়ভাবে Sync হয় না।
