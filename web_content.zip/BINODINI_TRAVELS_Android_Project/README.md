# BINODINI TRAVELS — Android app project

This is an Android Studio project for the BINODINI TRAVELS vehicle rental and document-tracking app.

## Build an APK
1. Install Android Studio: https://developer.android.com/studio
2. Extract/open this folder in Android Studio (the folder containing `settings.gradle`).
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Use **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Features
- Four vehicle cards and registration numbers
- Rental/trip records, fuel and expenses, income and calculated profit
- Vehicle document expiry records and alerts
- Calendar view for document due dates
- Local device storage, JSON backup and restore

## Important
Records are stored locally on this device, not synced to the cloud. Clearing app data or uninstalling may erase records; export backups regularly. Expiry reminders are shown in the app; this version does not send notifications when the app is closed.
