# Mir Tok

TikTok tipli qısa video + canlı yayın platforması prototipi.

**Ad:** Mir Tok  
**Versiya:** 1.0 (Frontend Prototip)

---

## Xüsusiyyətlər

### ✅ İşləyən
- **Şort video feed** – TikTok kimi yuxarı/aşağı sürüşdürmə (touch + mouse wheel)
- **Şəkil və video** paylaşımları
- **Profil səhifəsi** – avatar, bio, statistika, post grid
- **Yükləmə** – telefonda şəkil/video seçib önizləmə + paylaş (simulyasiya)
- **Canlı yayın UI** – canlı nişanı, izləyici sayı, şərhlər, mesaj yazma
- **Kölgə / modern UI** – tünd tema, hamar animasiyalar, mobil-first
- Bəyənmə (double-tap dəstəyi), izlə düyməsi, progress bar

### ⏳ Prototip səviyyəsində (real backend yoxdur)
- Real istifadəçi qeydiyyatı / login
- Real video hosting və CDN
- Real canlı yayın (WebRTC)
- Mesajlaşma və bildirişlər
- Alqoritmik tövsiyə sistemi

---

## Necə işə salmaq olar?

1. ZIP-i açın
2. `index.html` faylını brauzerdə açın (Chrome / Safari tövsiyə olunur)
3. Telefonunuzda da eyni şəkildə aça bilərsiniz (faylı telefona köçürün və ya local server ilə)

**Ən yaxşı təcrübə:** Telefonu şaquli tutun.

### İdarəetmə
| Hərəkət              | Nəticə                    |
|----------------------|---------------------------|
| Yuxarı/aşağı sürüşdür| Növbəti / əvvəlki video   |
| Double-tap           | Bəyən                     |
| Alt navi             | Səhifələr arası keçid     |
| ＋ düyməsi           | Video / Şəkil / Canlı     |

---

## Qovluq strukturu

```
MirTok/
├── index.html          ← Əsas səhifə
├── css/
│   └── style.css       ← Bütün stillər
├── js/
│   └── app.js          ← Məntiq və interaktivlik
├── assets/             ← (gələcək media)
└── README.md
```

---

## Qeyd

Bu **gözəl və funksional frontend prototipdir**.  
Real platforma üçün backend (Node.js / Firebase / Supabase), video emalı, canlı yayın infrastrukturu və moderasiya sistemi lazımdır.

İstəsəniz növbəti mərhələdə:
- Daha çox səhifə (ayarlar, axtarış)
- LocalStorage ilə sadə “paylaşımlarımı yadda saxla”
- PWA (telefon ekranına əlavə et)
- Daha real canlı yayın simulyasiyası

deyə bilərsiniz.

---

Hazırlayan: Grok (xAI)  
Tarix: 12 Oktyabr 2026
