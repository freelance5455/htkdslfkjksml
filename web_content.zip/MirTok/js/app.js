/* ========== MIR TOK - App Logic ========== */

// Mock data
const MOCK_VIDEOS = [
    {
        id: 1,
        type: 'video',
        src: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
        user: { name: 'Aysel_M', username: '@aysel', avatar: 'https://i.pravatar.cc/150?img=1' },
        caption: 'Bakı gecələri 🔥 #baku #nightvibes',
        likes: 12400,
        comments: 832,
        shares: 210,
        music: 'Original Sound - Aysel_M'
    },
    {
        id: 2,
        type: 'video',
        src: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
        user: { name: 'Elvin Pro', username: '@elvinpro', avatar: 'https://i.pravatar.cc/150?img=12' },
        caption: 'Yeni trend 💃 Kim təkrar edə bilər?',
        likes: 45800,
        comments: 2100,
        shares: 980,
        music: 'Trending Audio - MirTok'
    },
    {
        id: 3,
        type: 'photo',
        src: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800',
        user: { name: 'Nigar Art', username: '@nigarart', avatar: 'https://i.pravatar.cc/150?img=5' },
        caption: 'Yeni işim ✨ Rəy yazın!',
        likes: 8900,
        comments: 340,
        shares: 120,
        music: 'Chill Beats'
    },
    {
        id: 4,
        type: 'video',
        src: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
        user: { name: 'Rəşad Comedy', username: '@reshad', avatar: 'https://i.pravatar.cc/150?img=33' },
        caption: 'Bu dəfə çox gülməli oldu 😂😂',
        likes: 67200,
        comments: 4200,
        shares: 3100,
        music: 'Funny Sound Effect'
    },
    {
        id: 5,
        type: 'video',
        src: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4',
        user: { name: 'Leyla Travel', username: '@leylatravel', avatar: 'https://i.pravatar.cc/150?img=9' },
        caption: 'Qəbələyə yol 🚗🌲 #travel #azerbaijan',
        likes: 23100,
        comments: 1100,
        shares: 450,
        music: 'Road Trip Mix'
    }
];

const MOCK_PROFILE_POSTS = [
    { type: 'video', thumb: 'https://images.unsplash.com/photo-1611162616475-46b635cb686b?w=400', views: '12.4K' },
    { type: 'photo', thumb: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=400', views: '8.9K' },
    { type: 'video', thumb: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400', views: '45.2K' },
    { type: 'video', thumb: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=400', views: '31.7K' },
    { type: 'photo', thumb: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=400', views: '6.1K' },
    { type: 'video', thumb: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=400', views: '19.8K' },
    { type: 'photo', thumb: 'https://images.unsplash.com/photo-1459749411177-041677129afb?w=400', views: '4.3K' },
    { type: 'video', thumb: 'https://images.unsplash.com/photo-1487180144351-b8472da7d491?w=400', views: '27.5K' },
    { type: 'video', thumb: 'https://images.unsplash.com/photo-1429962714451-bb934ecdc4ec?w=400', views: '15.2K' }
];

// State
let currentIndex = 0;
let isTransitioning = false;
let likedVideos = new Set();
let currentView = 'feed';
let touchStartY = 0;
let touchEndY = 0;

// DOM refs
const feedContainer = () => document.getElementById('feed-container');
const slides = () => document.querySelectorAll('.video-slide');

// ========== INIT ==========
document.addEventListener('DOMContentLoaded', () => {
    // Splash
    setTimeout(() => {
        document.getElementById('splash').classList.add('hide');
        setTimeout(() => document.getElementById('splash').remove(), 600);
    }, 1800);

    renderFeed();
    renderProfileGrid();
    setupSwipe();
    setupNav();
    setupCreate();
    setupLive();
});

// ========== FEED ==========
function renderFeed() {
    const container = feedContainer();
    container.innerHTML = '';

    MOCK_VIDEOS.forEach((item, i) => {
        const slide = document.createElement('div');
        slide.className = 'video-slide' + (i === 0 ? ' active' : '');
        slide.dataset.index = i;

        if (item.type === 'video') {
            slide.innerHTML = `
                <video src="${item.src}" loop muted playsinline preload="metadata"></video>
            `;
        } else {
            slide.innerHTML = `
                <div class="photo-post">
                    <img src="${item.src}" alt="Post">
                </div>
            `;
        }

        // Side actions
        const side = document.createElement('div');
        side.className = 'side-actions';
        side.innerHTML = `
            <div class="action-btn like-btn" data-id="${item.id}">
                <div class="icon">♡</div>
                <div class="count">${formatCount(item.likes)}</div>
            </div>
            <div class="action-btn">
                <div class="icon">💬</div>
                <div class="count">${formatCount(item.comments)}</div>
            </div>
            <div class="action-btn">
                <div class="icon">↗</div>
                <div class="count">${formatCount(item.shares)}</div>
            </div>
            <div class="action-btn">
                <div class="icon">🎵</div>
            </div>
        `;
        slide.appendChild(side);

        // Info
        const info = document.createElement('div');
        info.className = 'video-info';
        info.innerHTML = `
            <div class="user-row">
                <img class="avatar" src="${item.user.avatar}" alt="">
                <span class="username">${item.user.name}</span>
                <button class="follow-btn">İzlə</button>
            </div>
            <div class="caption">${item.caption}</div>
            <div class="music">🎵 <span>${item.music} • ${item.music}</span></div>
        `;
        slide.appendChild(info);

        container.appendChild(slide);
    });

    // Progress bar
    const progress = document.createElement('div');
    progress.className = 'progress-bar';
    progress.innerHTML = '<div class="fill"></div>';
    container.appendChild(progress);

    // Like handlers
    document.querySelectorAll('.like-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const id = btn.dataset.id;
            if (likedVideos.has(id)) {
                likedVideos.delete(id);
                btn.classList.remove('liked');
                btn.querySelector('.icon').textContent = '♡';
            } else {
                likedVideos.add(id);
                btn.classList.add('liked');
                btn.querySelector('.icon').textContent = '❤️';
            }
        });
    });

    // Double tap like
    container.addEventListener('dblclick', (e) => {
        const active = document.querySelector('.video-slide.active');
        if (active) {
            const likeBtn = active.querySelector('.like-btn');
            if (likeBtn && !likeBtn.classList.contains('liked')) {
                likeBtn.click();
            }
        }
    });

    playCurrent();
}

function formatCount(n) {
    if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
    if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
    return n.toString();
}

function playCurrent() {
    const all = slides();
    all.forEach((s, i) => {
        const video = s.querySelector('video');
        if (video) {
            if (i === currentIndex) {
                video.currentTime = 0;
                video.play().catch(() => {});
            } else {
                video.pause();
            }
        }
    });
    updateProgress();
}

function updateProgress() {
    const active = document.querySelector('.video-slide.active video');
    const fill = document.querySelector('.progress-bar .fill');
    if (!active || !fill) return;

    const update = () => {
        if (active.duration) {
            fill.style.width = (active.currentTime / active.duration * 100) + '%';
        }
        if (currentView === 'feed') requestAnimationFrame(update);
    };
    requestAnimationFrame(update);
}

function goToSlide(index) {
    if (isTransitioning || index < 0 || index >= MOCK_VIDEOS.length) return;
    isTransitioning = true;

    const all = slides();
    all[currentIndex].classList.remove('active');
    currentIndex = index;
    all[currentIndex].classList.add('active');

    playCurrent();

    setTimeout(() => { isTransitioning = false; }, 280);
}

// Swipe
function setupSwipe() {
    const container = feedContainer();

    container.addEventListener('touchstart', (e) => {
        touchStartY = e.changedTouches[0].screenY;
    }, { passive: true });

    container.addEventListener('touchend', (e) => {
        touchEndY = e.changedTouches[0].screenY;
        handleSwipe();
    }, { passive: true });

    // Mouse wheel for desktop
    container.addEventListener('wheel', (e) => {
        e.preventDefault();
        if (e.deltaY > 30) goToSlide(currentIndex + 1);
        else if (e.deltaY < -30) goToSlide(currentIndex - 1);
    }, { passive: false });

    // Keyboard
    window.addEventListener('keydown', (e) => {
        if (currentView !== 'feed') return;
        if (e.key === 'ArrowDown') goToSlide(currentIndex + 1);
        if (e.key === 'ArrowUp') goToSlide(currentIndex - 1);
    });
}

function handleSwipe() {
    const diff = touchStartY - touchEndY;
    if (Math.abs(diff) < 50) return;
    if (diff > 0) goToSlide(currentIndex + 1);
    else goToSlide(currentIndex - 1);
}

// ========== NAVIGATION ==========
function setupNav() {
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', () => {
            const view = item.dataset.view;
            if (!view) return;

            // Pause videos when leaving feed
            if (currentView === 'feed' && view !== 'feed') {
                slides().forEach(s => {
                    const v = s.querySelector('video');
                    if (v) v.pause();
                });
            }

            switchView(view);

            document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
            item.classList.add('active');
        });
    });
}

function switchView(viewName) {
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    const target = document.getElementById(viewName + '-view');
    if (target) {
        target.classList.add('active');
        currentView = viewName;
        if (viewName === 'feed') playCurrent();
    }
}

// ========== PROFILE ==========
function renderProfileGrid() {
    const grid = document.getElementById('posts-grid');
    if (!grid) return;
    grid.innerHTML = '';

    MOCK_PROFILE_POSTS.forEach(post => {
        const item = document.createElement('div');
        item.className = 'grid-item';
        item.innerHTML = `
            <img src="${post.thumb}" alt="">
            ${post.type === 'video' ? '<span class="play-icon">▶</span>' : ''}
            <span class="views">▶ ${post.views}</span>
        `;
        grid.appendChild(item);
    });
}

// ========== CREATE ==========
function setupCreate() {
    const fileInput = document.getElementById('file-input');
    const preview = document.getElementById('upload-preview');
    const modal = document.getElementById('upload-modal');
    const caption = document.getElementById('upload-caption');

    document.getElementById('btn-upload-video')?.addEventListener('click', () => {
        fileInput.accept = 'video/*';
        fileInput.click();
    });
    document.getElementById('btn-upload-photo')?.addEventListener('click', () => {
        fileInput.accept = 'image/*';
        fileInput.click();
    });
    document.getElementById('btn-go-live')?.addEventListener('click', () => {
        switchView('live');
        document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
        startFakeLive();
    });

    fileInput?.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const url = URL.createObjectURL(file);
        preview.innerHTML = '';
        if (file.type.startsWith('video/')) {
            const vid = document.createElement('video');
            vid.src = url;
            vid.controls = true;
            vid.muted = true;
            preview.appendChild(vid);
        } else {
            const img = document.createElement('img');
            img.src = url;
            preview.appendChild(img);
        }
        modal.classList.add('active');
        caption.value = '';
    });

    document.getElementById('modal-close')?.addEventListener('click', () => {
        modal.classList.remove('active');
        fileInput.value = '';
        preview.innerHTML = '<p style="color:#666">Fayl seçilməyib</p>';
    });

    document.getElementById('btn-publish')?.addEventListener('click', () => {
        const text = caption.value.trim() || 'Yeni paylaşım ✨';
        // Simulate publish
        alert('Paylaşım uğurla yükləndi!\n\n(Bu prototipdir – real serverə göndərilmir)');
        modal.classList.remove('active');
        fileInput.value = '';
        switchView('feed');
        document.querySelector('.nav-item[data-view="feed"]')?.classList.add('active');
    });
}

// ========== LIVE ==========
function setupLive() {
    document.getElementById('live-close')?.addEventListener('click', () => {
        switchView('feed');
        document.querySelector('.nav-item[data-view="feed"]')?.classList.add('active');
        stopFakeLive();
    });

    const input = document.getElementById('live-input');
    const sendBtn = document.getElementById('live-send');
    const comments = document.getElementById('live-comments');

    function addComment(name, text) {
        const div = document.createElement('div');
        div.className = 'live-comment';
        div.innerHTML = `<strong>${name}</strong>${text}`;
        comments.appendChild(div);
        comments.scrollTop = comments.scrollHeight;
        // Keep only last 15
        while (comments.children.length > 15) {
            comments.removeChild(comments.firstChild);
        }
    }

    function send() {
        const text = input.value.trim();
        if (!text) return;
        addComment('Sən', text);
        input.value = '';
    }

    sendBtn?.addEventListener('click', send);
    input?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') send();
    });

    // Fake incoming comments
    window._liveInterval = null;
}

const FAKE_COMMENTS = [
    ['Aysel', 'Salam qardaş 🔥'],
    ['Elvin', 'Nə gözəl yayındır'],
    ['Nigar', 'Haradasan?'],
    ['Rəşad', 'Gülürəm 😂'],
    ['Leyla', 'Dəstək ❤️'],
    ['Murad', 'Daha çox danış'],
    ['Sabina', 'Səni izləyirəm'],
    ['Kamran', 'Keyfiyyət super'],
    ['Aytən', 'Necəsən?'],
    ['Orxan', 'Mir Tok ən yaxşısı']
];

function startFakeLive() {
    const comments = document.getElementById('live-comments');
    comments.innerHTML = '';
    document.getElementById('live-viewers').textContent = '1.2K izləyici';

    // Simulate viewer count increase
    let viewers = 1200;
    window._viewerInterval = setInterval(() => {
        viewers += Math.floor(Math.random() * 40) - 10;
        if (viewers < 800) viewers = 800;
        document.getElementById('live-viewers').textContent = formatCount(viewers) + ' izləyici';
    }, 3000);

    // Fake comments
    window._liveInterval = setInterval(() => {
        const [name, text] = FAKE_COMMENTS[Math.floor(Math.random() * FAKE_COMMENTS.length)];
        const div = document.createElement('div');
        div.className = 'live-comment';
        div.innerHTML = `<strong>${name}</strong>${text}`;
        comments.appendChild(div);
        comments.scrollTop = comments.scrollHeight;
        while (comments.children.length > 15) comments.removeChild(comments.firstChild);
    }, 2800);
}

function stopFakeLive() {
    clearInterval(window._liveInterval);
    clearInterval(window._viewerInterval);
}
