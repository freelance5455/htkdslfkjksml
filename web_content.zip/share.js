'use strict';
/* ============================================================
   Cartão compartilhável (canvas 1080×1350) e compartilhamento de arquivos
   ============================================================ */
const CARD_W = 1080, CARD_H = 1350, CARD_FONT = 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';

function loadSvgImage(svg){
  return new Promise(resolve=>{ const img = new Image(); img.onload = ()=>resolve(img); img.onerror = ()=>resolve(null); img.src = svgDataUrl(svg); });
}
function fitText(ctx, text, maxW, weight, startSize, minSize){
  let size = startSize; ctx.font = weight + ' ' + size + 'px ' + CARD_FONT;
  while(ctx.measureText(text).width > maxW && size > (minSize || 22)){ size -= 2; ctx.font = weight + ' ' + size + 'px ' + CARD_FONT; }
  let out = text;
  if(ctx.measureText(out).width > maxW){ while(out.length > 1 && ctx.measureText(out + '…').width > maxW) out = out.slice(0, -1); out += '…'; }
  return out;
}
function drawFlame(ctx, x, y, s, color){
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s); ctx.fillStyle = color;
  ctx.beginPath(); ctx.moveTo(0,-1);
  ctx.bezierCurveTo(0.55,-0.45, 0.95,0.05, 0.62,0.62); ctx.bezierCurveTo(0.45,0.95, -0.45,0.95, -0.62,0.55);
  ctx.bezierCurveTo(-0.85,0.05, -0.35,-0.25, -0.2,-0.6); ctx.bezierCurveTo(-0.08,-0.45, -0.05,-0.3, 0.05,-0.1); ctx.bezierCurveTo(0.2,-0.4, 0.15,-0.7, 0,-1); ctx.fill();
  ctx.restore();
}
function cardBackground(ctx){
  const g = ctx.createLinearGradient(0,0,0,CARD_H); g.addColorStop(0,'#07080A'); g.addColorStop(1,'#10141B');
  ctx.fillStyle = g; ctx.fillRect(0,0,CARD_W,CARD_H);
  let rg = ctx.createRadialGradient(180,160,0,180,160,700); rg.addColorStop(0,'rgba(0,229,255,.16)'); rg.addColorStop(1,'rgba(0,229,255,0)'); ctx.fillStyle = rg; ctx.fillRect(0,0,CARD_W,CARD_H);
  rg = ctx.createRadialGradient(920,1200,0,920,1200,760); rg.addColorStop(0,'rgba(139,92,246,.18)'); rg.addColorStop(1,'rgba(139,92,246,0)'); ctx.fillStyle = rg; ctx.fillRect(0,0,CARD_W,CARD_H);
  ctx.fillStyle = 'rgba(255,255,255,.04)';
  for(let x=24;x<CARD_W;x+=44) for(let y=24;y<CARD_H;y+=44) ctx.fillRect(x,y,2,2);
}
function statBox(ctx, x, y, w, label, value){
  ctx.fillStyle = 'rgba(255,255,255,.05)'; ctx.strokeStyle = 'rgba(255,255,255,.12)'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.roundRect(x, y, w, 150, 28); ctx.fill(); ctx.stroke();
  ctx.textAlign = 'center'; ctx.fillStyle = '#E8EAED'; ctx.font = '800 54px ' + CARD_FONT; ctx.fillText(fitText(ctx, value, w - 24, 800, 54, 30), x + w/2, y + 82);
  ctx.fillStyle = '#9AA0A6'; ctx.font = '700 26px ' + CARD_FONT; ctx.fillText(fitText(ctx, label.toUpperCase(), w - 20, 700, 26, 18), x + w/2, y + 124);
}

/* spec: { kind:'session', session, report } | { kind:'achievement', id, ts } */
async function renderShareCard(spec){
  const canvas = document.createElement('canvas'); canvas.width = CARD_W; canvas.height = CARD_H;
  const ctx = canvas.getContext('2d'); const G = State.data.gamification, lp = levelProgress(G.xpTotal), rank = lp.rank;
  cardBackground(ctx);
  // topo
  ctx.textBaseline = 'alphabetic'; ctx.textAlign = 'left'; ctx.fillStyle = '#FFFFFF'; ctx.font = '800 58px ' + CARD_FONT; ctx.fillText(fitText(ctx, APP_NAME, 560, 800, 58, 34), 72, 118);
  ctx.textAlign = 'right'; ctx.fillStyle = '#9AA0A6'; ctx.font = '600 32px ' + CARD_FONT;
  const when = spec.kind === 'session' ? spec.session.completedAt : (spec.ts || Date.now());
  ctx.fillText(fmtDateFull(when), 1008, 116);
  ctx.fillStyle = 'rgba(0,229,255,.55)'; ctx.fillRect(72, 146, 936, 3);
  ctx.textAlign = 'center';

  if(spec.kind === 'achievement'){
    const def = ACHIEVEMENTS.find(a=>a.id === spec.id);
    const ic = await loadSvgImage(achIconSVG(def.icon, '#FFD76A', 400));
    ctx.fillStyle = 'rgba(255,215,106,.08)'; ctx.strokeStyle = 'rgba(255,215,106,.45)'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.arc(540, 480, 250, 0, Math.PI*2); ctx.fill(); ctx.stroke();
    if(ic) ctx.drawImage(ic, 340, 280, 400, 400);
    ctx.fillStyle = '#FFD76A'; ctx.font = '800 34px ' + CARD_FONT; ctx.fillText(t('ach.unlocked').toUpperCase(), 540, 800);
    ctx.fillStyle = '#FFFFFF'; ctx.fillText(fitText(ctx, t('ach.' + spec.id + '.n'), 900, 800, 92, 44), 540, 900);
    ctx.fillStyle = '#C3C8CF'; ctx.font = '500 42px ' + CARD_FONT;
    const desc = t('ach.' + spec.id + '.d'); wrapText(ctx, desc, 540, 975, 860, 58, 3);
  } else {
    const rep = spec.report, xp = rep && rep.xp ? rep.xp.total + (rep.questXp || 0) : 0;
    const img = await loadSvgImage(insigniaSVG(rank.id, 320));
    if(img) ctx.drawImage(img, 380, 190, 320, 320);
    ctx.fillStyle = rank.color; ctx.font = '800 74px ' + CARD_FONT; ctx.fillText(t('rank.' + rank.id), 540, 590);
    ctx.fillStyle = '#C3C8CF'; ctx.font = '700 40px ' + CARD_FONT; ctx.fillText(t('lbl.level', { n:lp.level }), 540, 645);
    if(rep && rep.qualified){
      const gr = ctx.createLinearGradient(240,0,840,0); gr.addColorStop(0,'#00E5FF'); gr.addColorStop(1,'#8B5CF6');
      ctx.fillStyle = gr; ctx.font = '900 190px ' + CARD_FONT; ctx.fillText('+' + fmtInt(xp), 540, 820);
      ctx.fillStyle = '#9AA0A6'; ctx.font = '800 40px ' + CARD_FONT; ctx.fillText(t('lbl.xp'), 540, 872);
    } else {
      ctx.fillStyle = '#E8EAED'; ctx.font = '800 84px ' + CARD_FONT; ctx.fillText(fitText(ctx, spec.session.dayTitle || t('lbl.workout'), 900, 800, 84, 40), 540, 790);
    }
    const info = sessionInfo(spec.session);
    const vol = info.volume > 0 ? fmtInt(kgToDisp(info.volume)) + ' ' + unitLabel() : (info.cardioMin > 0 ? fmtInt(info.cardioMin) + ' ' + t('unit.min') : '—');
    statBox(ctx, 72, 930, 288, t('lbl.sets'), String(info.sets));
    statBox(ctx, 396, 930, 288, t('lbl.volume'), vol);
    statBox(ctx, 720, 930, 288, t('lbl.duration'), fmtDuration(spec.session.completedAt - spec.session.startedAt));
    // sequência + PRs
    const st = G.streak;
    drawFlame(ctx, 110, 1148, 34, '#F59E0B');
    ctx.textAlign = 'left'; ctx.fillStyle = '#F2F3F5'; ctx.font = '800 46px ' + CARD_FONT;
    ctx.fillText(t('card.streak', { n:st.current }), 160, 1163);
    const prs = rep && rep.prs ? rep.prs : [];
    ctx.font = '700 34px ' + CARD_FONT; let y = 1218;
    if(prs.length){
      ctx.fillStyle = '#F59E0B';
      prs.slice(0, 2).forEach(p=>{ ctx.fillText(fitText(ctx, t('lbl.pr') + ' · ' + p.name + ' ' + fmtLoad(String(p.load), true) + ' × ' + p.reps, 900, 700, 34, 22), 72, y); y += 46; });
    }
  }
  // rodapé
  ctx.textAlign = 'center'; ctx.fillStyle = '#6B7178'; ctx.font = '600 28px ' + CARD_FONT;
  const nm = (State.data.profile.name || '').trim();
  ctx.fillText(fitText(ctx, (nm ? nm + '  •  ' : '') + t('card.footer'), 936, 600, 28, 20), 540, 1312);
  return canvas;
}
function wrapText(ctx, text, x, y, maxW, lh, maxLines){
  const words = String(text).split(' '); let line = '', n = 0;
  for(let i=0;i<words.length;i++){
    const test = line ? line + ' ' + words[i] : words[i];
    if(ctx.measureText(test).width > maxW && line){ ctx.fillText(line, x, y); y += lh; line = words[i]; if(++n >= maxLines) return; } else line = test;
  }
  if(line) ctx.fillText(line, x, y);
}
function canvasToBlob(canvas){ return new Promise(res=>canvas.toBlob(res, 'image/png')); }

/* Web Share API com arquivo; fallback para download */
async function shareOrDownloadFile(file, title){
  try{
    if(navigator.share && navigator.canShare && navigator.canShare({ files:[file] })){ await navigator.share({ files:[file], title: title || APP_NAME }); return 'shared'; }
  }catch(e){ if(e && e.name === 'AbortError') return 'aborted'; }
  const url = URL.createObjectURL(file), a = document.createElement('a');
  a.href = url; a.download = file.name; document.body.appendChild(a); a.click(); document.body.removeChild(a);
  setTimeout(()=>URL.revokeObjectURL(url), 2000);
  return 'downloaded';
}
