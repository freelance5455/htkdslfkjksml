ATTENOVA Android APK project — v6.2

This project packages the offline ATTENOVA attendance app inside an Android application.

NEW IN v6.2
- Desktop left sidebar and mobile slide-out side navigation.
- Independently scrollable sidebar.
- Attendance streak, monthly class count, low-attendance subject counter.
- Smart Attendance Coach and subject search.
- Profile picture options remain removed.

BUILD LOCALLY
1. Open this folder in Android Studio.
2. Let Android Studio install Android SDK Platform 35 and Gradle dependencies.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK output: app/build/outputs/apk/debug/app-debug.apk

BUILD ONLINE WITHOUT PUBLISHING A WEBSITE
1. Create a private GitHub repository and upload the CONTENTS of this folder.
2. Open Actions > Build ATTENOVA APK.
3. Choose Run workflow (or push to main/master).
4. Download artifact ATTENOVA-v6_2-debug-apk after a successful run.
5. Extract the artifact ZIP to get app-debug.apk.

Package: com.adillatif.attenova
Version: 6.2 (versionCode 7)
Minimum Android: 6.0 (API 23)

Data is stored locally in the Android WebView app storage. Clearing app data or uninstalling can erase records. Download backups regularly.
