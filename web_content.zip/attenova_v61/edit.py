from pathlib import Path
p=Path('/mnt/data/attenova_edit/app/src/main/assets/www/index.html')
s=p.read_text()
# Remove profile picture styling and dashboard avatar styling
s=s.replace('.profile-avatar{width:76px;height:76px;border-radius:50%;object-fit:cover;border:3px solid var(--accent);background:var(--surface2);display:block}\n.profile-row{display:flex;align-items:center;gap:15px;flex-wrap:wrap}.profile-placeholder{display:grid;place-items:center;font-size:25px;color:var(--muted)}\n.nav-toggle{min-width:44px;position:relative;z-index:110}\n','')
s=s.replace('.dashboard-profile-photo{flex:0 0 auto}.dashboard-profile-photo .profile-avatar{width:94px;height:94px;box-shadow:0 8px 24px #0002}\n','')
s=s.replace('@media(max-width:480px){.dashboard-profile{gap:14px;padding:16px}.dashboard-profile-photo .profile-avatar{width:76px;height:76px}}','@media(max-width:480px){.dashboard-profile{padding:16px}}')
# Remove top hamburger button, retain theme/install controls
s=s.replace('<button class="ghost nav-toggle" id="navToggle" type="button" title="Open navigation menu" aria-label="Open navigation menu" aria-controls="appNavigation" aria-expanded="false">☰</button>','')
# Remove dashboard profile picture element
s=s.replace('  <div class="dashboard-profile-photo"><img id="homeProfileAvatar" class="profile-avatar" src="attenova-icon-192.png" alt="Student profile photo"></div>\n','')
# Remove settings profile-picture and navigation-layout panels
start=s.index('<section id="settings" class="view">')
needle='<div class="panel"><h3 style="margin-bottom:12px">Student profile</h3>'
pos=s.index(needle,start)
s=s[:start]+'<section id="settings" class="view">'+s[pos:]
# Remove legacy profile photo/nav state and render code
s=s.replace("d.profile.target=d.profile.target||75;d.profile.photo=d.profile.photo||'';", "d.profile.target=d.profile.target||75;delete d.profile.photo;d.navMode='top';")
import re
s=re.sub(r"function closeNavigation\(\)\{.*?\}\nfunction go\(id\)", "function go(id)", s, count=1, flags=re.S)
s=s.replace(";closeNavigation();window.scrollTo", ";window.scrollTo")
s=s.replace(" const avatar=d.profile.photo||'attenova-icon-192.png';const pa=$('profileAvatar'),ha=$('homeProfileAvatar');if(pa)pa.src=avatar;if(ha)ha.src=avatar;\n",'')
s=s.replace(" const remove=$('removePhotoBtn');if(remove)remove.disabled=!d.profile.photo;\n",'')
s=s.replace(" put('navModeLabel','Current layout: '+(d.navMode==='side'?'Side navigation':'Top navigation'));\n const top=$('topNavBtn'),side=$('sideNavBtn');if(top)top.className=d.navMode==='top'?'btn primary':'ghost';if(side)side.className=d.navMode==='side'?'btn primary':'ghost';\n document.body.dataset.nav=d.navMode||'top';", " document.body.dataset.nav='top';")
# Remove navigation and photo event listeners as one block
start=s.find("$('navToggle').onclick=")
end=s.find("document.addEventListener('click',e=>{let b=e.target.closest('button');", start)
if start!=-1 and end!=-1:
    s=s[:start]+s[end:]
else:
    print('event block not found',start,end)
p.write_text(s)
