# Turbo Rush (Android)

Endless car racer. The game lives in `app/src/main/assets/index.html`; the app is a fullscreen WebView around it.

## Get the APK
**Android Studio:** open this folder -> Build > Build APK(s). APK: `app/build/outputs/apk/debug/app-debug.apk`

**No PC tools (GitHub):** upload this folder to a new GitHub repo -> Actions tab -> "Build APK" -> download the `TurboRush-APK` artifact.

**Command line (with Android SDK + JDK 17):** `./gradlew assembleDebug`
