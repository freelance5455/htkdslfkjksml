import React from 'react';
import {
  CalendarDays,
  PlusCircle,
  Clock,
  History,
  SlidersHorizontal,
  FileDown,
  ShieldCheck,
} from 'lucide-react';
import { useDuty } from '../../context/DutyContext';

export type ActiveTab = 'dashboard' | 'new-entry' | 'calendar' | 'history' | 'master' | 'export';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  pendingCount: number;
  alertCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  pendingCount,
  alertCount,
}) => {
  const { userName, employeeId } = useDuty();
  return (
    <>
      {/* Top Header - Strictly 3 Zones */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-15 flex items-center justify-between">
          {/* Zone 1: Single text element wordmark */}
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-900 flex items-center justify-center text-white shadow-sm">
              <ShieldCheck className="w-5 h-5 text-blue-200" />
            </div>
            <a
              href="#dashboard"
              onClick={(e) => {
                e.preventDefault();
                setActiveTab('dashboard');
              }}
              className="text-base sm:text-lg font-bold tracking-tight text-slate-900 hover:text-blue-900 transition-colors"
            >
              Duty Adjustment
            </a>
          </div>

          {/* Zone 2: 4-6 nav links (Desktop) */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`px-3 py-1.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'dashboard'
                  ? 'bg-blue-50 text-blue-900 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Dashboard
            </button>
            <button
              onClick={() => setActiveTab('new-entry')}
              className={`px-3 py-1.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'new-entry'
                  ? 'bg-blue-50 text-blue-900 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              New Entry
            </button>
            <button
              onClick={() => setActiveTab('calendar')}
              className={`px-3 py-1.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'calendar'
                  ? 'bg-blue-50 text-blue-900 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Calendar
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`px-3 py-1.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap relative ${
                activeTab === 'history'
                  ? 'bg-blue-50 text-blue-900 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <span>History</span>
              {pendingCount > 0 && (
                <span className="ml-1.5 px-1.5 py-0.2 text-[10px] font-bold bg-amber-100 text-amber-800 rounded-full">
                  {pendingCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab('master')}
              className={`px-3 py-1.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'master'
                  ? 'bg-blue-50 text-blue-900 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Master
            </button>
            <button
              onClick={() => setActiveTab('export')}
              className={`px-3 py-1.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'export'
                  ? 'bg-blue-50 text-blue-900 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Export & Reports
            </button>
          </nav>

          {/* Zone 3: 1-2 primary actions */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setActiveTab('new-entry')}
              className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-900 hover:bg-blue-800 rounded-lg shadow-sm transition-all whitespace-nowrap"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Record Adjustment</span>
            </button>

            {alertCount > 0 && (
              <div
                title={`${alertCount} active duty alerts`}
                onClick={() => setActiveTab('dashboard')}
                className="cursor-pointer flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-red-700 bg-red-50 border border-red-200 rounded-lg"
              >
                <span className="w-2 h-2 rounded-full bg-red-600 animate-pulse"></span>
                <span>{alertCount} Alert</span>
              </div>
            )}

            {userName && (
              <div
                onClick={() => setActiveTab('master')}
                className="hidden lg:flex items-center gap-2 pl-3 border-l border-slate-200 cursor-pointer hover:opacity-85 transition-opacity"
                title="Registered Officer Credentials - View on Master"
              >
                <div className="w-7 h-7 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-900 font-bold text-xs shrink-0">
                  {userName.slice(0, 1).toUpperCase()}
                </div>
                <div className="flex flex-col text-left">
                  <span className="text-xs font-bold text-slate-900 leading-tight truncate max-w-[120px]">
                    {userName}
                  </span>
                  {employeeId && (
                    <span className="text-[10px] font-mono text-slate-500 font-semibold leading-none">
                      ID: {employeeId}
                    </span>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Bottom Navigation Bar for Mobile (<md) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-lg">
        <div className="grid grid-cols-6 h-16 max-w-lg mx-auto px-1">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex flex-col items-center justify-center py-1 transition-colors ${
              activeTab === 'dashboard' ? 'text-blue-900 font-semibold' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Clock className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] tracking-tight">Today</span>
          </button>

          <button
            onClick={() => setActiveTab('new-entry')}
            className={`flex flex-col items-center justify-center py-1 transition-colors relative ${
              activeTab === 'new-entry' ? 'text-blue-900 font-semibold' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <PlusCircle className="w-5 h-5 mb-0.5 text-blue-900" />
            <span className="text-[10px] tracking-tight">Entry</span>
          </button>

          <button
            onClick={() => setActiveTab('calendar')}
            className={`flex flex-col items-center justify-center py-1 transition-colors ${
              activeTab === 'calendar' ? 'text-blue-900 font-semibold' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <CalendarDays className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] tracking-tight">Calendar</span>
          </button>

          <button
            onClick={() => setActiveTab('history')}
            className={`flex flex-col items-center justify-center py-1 transition-colors relative ${
              activeTab === 'history' ? 'text-blue-900 font-semibold' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <div className="relative">
              <History className="w-5 h-5 mb-0.5" />
              {pendingCount > 0 && (
                <span className="absolute -top-1 -right-2 w-4 h-4 bg-amber-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                  {pendingCount > 9 ? '9+' : pendingCount}
                </span>
              )}
            </div>
            <span className="text-[10px] tracking-tight">History</span>
          </button>

          <button
            onClick={() => setActiveTab('master')}
            className={`flex flex-col items-center justify-center py-1 transition-colors ${
              activeTab === 'master' ? 'text-blue-900 font-semibold' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <SlidersHorizontal className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] tracking-tight">Master</span>
          </button>

          <button
            onClick={() => setActiveTab('export')}
            className={`flex flex-col items-center justify-center py-1 transition-colors ${
              activeTab === 'export' ? 'text-blue-900 font-semibold' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <FileDown className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] tracking-tight">Report</span>
          </button>
        </div>
      </nav>
    </>
  );
};
