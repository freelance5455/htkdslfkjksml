import React, { useState } from 'react';
import {
  ShieldCheck,
  User,
  BadgeAlert,
  CalendarDays,
  Lock,
  CheckCircle2,
  AlertCircle,
  Clock,
  Sparkles,
} from 'lucide-react';
import { useDuty } from '../../context/DutyContext';
import { DayOfWeek, WeeklyRoster } from '../../types/duty';
import { DAYS_OF_WEEK } from '../../utils/dutyEngine';
import {
  getShiftStyle,
  ShiftBadge,
  sortShiftsChronological,
} from '../../utils/shiftHelper';

export const FirstTimeRegisterView: React.FC = () => {
  const { registerOfficer, shifts } = useDuty();

  const orderedShifts = React.useMemo(() => sortShiftsChronological(shifts), [shifts]);

  const [name, setName] = useState<string>('');
  const [employeeId, setEmployeeId] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Default initial roster
  const [roster, setRoster] = useState<WeeklyRoster>({
    Saturday: 'Off',
    Sunday: 'shift-morning',
    Monday: 'shift-morning',
    Tuesday: 'shift-morning',
    Wednesday: 'shift-morning',
    Thursday: 'shift-afternoon',
    Friday: 'Off',
  });

  const handleShiftSelect = (day: DayOfWeek, shiftId: string) => {
    setRoster((prev) => ({
      ...prev,
      [day]: shiftId,
    }));
  };

  const applyPreset = (presetType: 'general' | 'afternoon' | 'all-morning' | 'night-rotation') => {
    const morningId = shifts.find((s) => s.name.toLowerCase().includes('morning'))?.id || shifts[0]?.id || 'shift-morning';
    const afternoonId = shifts.find((s) => s.name.toLowerCase().includes('afternoon'))?.id || shifts[1]?.id || 'shift-afternoon';
    const nightId = shifts.find((s) => s.name.toLowerCase().includes('night'))?.id || shifts[2]?.id || 'shift-night';

    if (presetType === 'general') {
      setRoster({
        Saturday: 'Off',
        Sunday: morningId,
        Monday: morningId,
        Tuesday: morningId,
        Wednesday: morningId,
        Thursday: morningId,
        Friday: 'Off',
      });
    } else if (presetType === 'afternoon') {
      setRoster({
        Saturday: 'Off',
        Sunday: afternoonId,
        Monday: afternoonId,
        Tuesday: afternoonId,
        Wednesday: afternoonId,
        Thursday: afternoonId,
        Friday: 'Off',
      });
    } else if (presetType === 'all-morning') {
      setRoster({
        Saturday: morningId,
        Sunday: morningId,
        Monday: morningId,
        Tuesday: morningId,
        Wednesday: morningId,
        Thursday: morningId,
        Friday: 'Off',
      });
    } else if (presetType === 'night-rotation') {
      setRoster({
        Saturday: 'Off',
        Sunday: afternoonId,
        Monday: afternoonId,
        Tuesday: morningId,
        Wednesday: morningId,
        Thursday: nightId,
        Friday: nightId,
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const trimmedName = name.trim();
    const trimmedId = employeeId.trim();

    if (!trimmedName) {
      setErrorMessage('Please enter your Full Name.');
      return;
    }

    if (!trimmedId) {
      setErrorMessage('Please enter your Employee ID.');
      return;
    }

    // Verify all 7 days have an assigned shift or Off
    for (const day of DAYS_OF_WEEK) {
      if (!roster[day]) {
        setErrorMessage(`Please select a shift or 'Off' for ${day}.`);
        return;
      }
    }

    registerOfficer(trimmedName, trimmedId, roster);
  };

  // Count working days
  const workingDaysCount = Object.values(roster).filter((s) => s !== 'Off').length;
  const offDaysCount = 7 - workingDaysCount;

  return (
    <div className="min-h-screen bg-slate-100/80 flex flex-col justify-center py-10 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-2xl w-full mx-auto space-y-6">
        {/* Brand & Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-blue-900 text-white shadow-md mx-auto mb-1">
            <ShieldCheck className="w-8 h-8 text-blue-200" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Duty Officer Initial Registration
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 max-w-lg mx-auto">
            Please register your permanent credentials and 7-day baseline duty roster schedule to initialize the system.
          </p>
        </div>

        {/* Permanent Save Notice Card */}
        <div className="bg-amber-50 border border-amber-200/90 rounded-2xl p-4 flex items-start gap-3 shadow-xs">
          <Lock className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
          <div className="text-xs space-y-1">
            <strong className="text-amber-900 font-bold block text-sm">
              Permanent Save Policy
            </strong>
            <p className="text-amber-800 leading-relaxed">
              Your <strong>Officer Name</strong> and <strong>Employee ID</strong> are permanently registered and locked upon submission. Afterward, <strong>only the 7-day duty roster</strong> can be modified in Master.
            </p>
          </div>
        </div>

        {errorMessage && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-3.5 flex items-center gap-2.5 text-xs text-red-800 font-semibold shadow-xs">
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Card 1: Officer Identification */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 sm:p-6 space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
              <User className="w-4 h-4 text-blue-900" />
              <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                1. Officer Credentials (Permanent)
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Officer Full Name <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Captain Ankit Maity"
                    className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900 font-medium"
                  />
                </div>
                <span className="text-[10px] text-slate-400 mt-1 block">
                  Printed on audit records & reports
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Employee ID <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <BadgeAlert className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    value={employeeId}
                    onChange={(e) => setEmployeeId(e.target.value)}
                    placeholder="e.g. EMP-9041 or DESK-02"
                    className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900 font-mono font-medium"
                  />
                </div>
                <span className="text-[10px] text-slate-400 mt-1 block">
                  Official badge or employee identification
                </span>
              </div>
            </div>
          </div>

          {/* Card 2: 7 Days Baseline Duty Roster */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 sm:p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <CalendarDays className="w-4 h-4 text-blue-900" />
                <div>
                  <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                    2. 7 Days Baseline Duty Roster
                  </h2>
                  <p className="text-[11px] text-slate-500">
                    Baseline weekly schedule (Saturday to Friday). Can be edited anytime on Master.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 text-xs">
                <span className="px-2 py-0.5 bg-blue-50 text-blue-900 font-bold rounded-lg border border-blue-100 text-[11px]">
                  {workingDaysCount} Working
                </span>
                <span className="px-2 py-0.5 bg-slate-100 text-slate-600 font-semibold rounded-lg text-[11px]">
                  {offDaysCount} Rest Days
                </span>
              </div>
            </div>

            {/* Quick Presets */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-amber-500" /> Quick Roster Presets
                </span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  onClick={() => applyPreset('general')}
                  className="px-2.5 py-1 text-[11px] font-semibold bg-slate-100 hover:bg-blue-50 hover:text-blue-900 text-slate-700 rounded-lg transition-colors border border-slate-200"
                >
                  General (Sun–Thu Morning)
                </button>
                <button
                  type="button"
                  onClick={() => applyPreset('afternoon')}
                  className="px-2.5 py-1 text-[11px] font-semibold bg-slate-100 hover:bg-blue-50 hover:text-blue-900 text-slate-700 rounded-lg transition-colors border border-slate-200"
                >
                  Afternoon (Sun–Thu Afternoon)
                </button>
                <button
                  type="button"
                  onClick={() => applyPreset('night-rotation')}
                  className="px-2.5 py-1 text-[11px] font-semibold bg-slate-100 hover:bg-blue-50 hover:text-blue-900 text-slate-700 rounded-lg transition-colors border border-slate-200"
                >
                  Rotational Duty
                </button>
                <button
                  type="button"
                  onClick={() => applyPreset('all-morning')}
                  className="px-2.5 py-1 text-[11px] font-semibold bg-slate-100 hover:bg-blue-50 hover:text-blue-900 text-slate-700 rounded-lg transition-colors border border-slate-200"
                >
                  6-Day Morning (Fri Off)
                </button>
              </div>
            </div>

            {/* 7 Days Schedule Selector (Visible by Morning, Afternoon, Night) */}
            <div className="space-y-2.5 pt-2">
              {DAYS_OF_WEEK.map((day) => {
                const currentShiftId = roster[day];
                const assignedShift = shifts.find((s) => s.id === currentShiftId);
                const assignedShiftName = currentShiftId === 'Off' ? 'Off' : (assignedShift?.name || 'Shift');

                return (
                  <div
                    key={day}
                    className="flex flex-col sm:flex-row sm:items-center justify-between p-2.5 sm:p-3 bg-slate-50 border border-slate-200 rounded-xl gap-2 hover:border-slate-300 transition-colors"
                  >
                    <div className="w-36 flex flex-col gap-0.5">
                      <span className="font-bold text-slate-900 text-xs sm:text-sm">{day}</span>
                      <div>
                        <ShiftBadge
                          shiftName={assignedShiftName}
                          size="xs"
                        />
                      </div>
                    </div>

                    {/* 1-Click Segmented Shift Selector: Off, Morning, Afternoon, Night */}
                    <div className="flex flex-wrap items-center gap-1.5 flex-1 max-w-lg justify-start sm:justify-end">
                      <button
                        type="button"
                        onClick={() => handleShiftSelect(day, 'Off')}
                        className={`px-2.5 py-1 text-xs rounded-lg font-bold border transition-all cursor-pointer ${
                          currentShiftId === 'Off'
                            ? 'bg-purple-800 text-white border-purple-900 shadow-xs ring-1 ring-purple-600'
                            : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100 hover:text-slate-900'
                        }`}
                      >
                        ☕ Off
                      </button>

                      {orderedShifts.map((s) => {
                        const isSel = currentShiftId === s.id;
                        const style = getShiftStyle(s.name || s.id);
                        return (
                          <button
                            key={s.id}
                            type="button"
                            onClick={() => handleShiftSelect(day, s.id)}
                            className={`px-2.5 py-1 text-xs rounded-lg font-bold border transition-all flex items-center gap-1 cursor-pointer ${
                              isSel ? `${style.activeCard} ring-1 ring-current` : `${style.inactiveCard}`
                            }`}
                            title={s.name}
                          >
                            <span className="scale-75 shrink-0">{style.icon}</span>
                            <span>{s.name}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Submission Action */}
          <div className="space-y-3">
            <button
              type="submit"
              className="w-full py-3 px-4 text-sm font-bold text-white bg-blue-900 hover:bg-blue-800 rounded-2xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Complete Registration & Permanently Save</span>
            </button>
            <p className="text-[11px] text-center text-slate-500">
              Only the 7-day duty roster schedule can be edited on Master once saved.
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};
