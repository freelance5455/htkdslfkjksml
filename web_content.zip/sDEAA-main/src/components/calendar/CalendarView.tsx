import React, { useState, useMemo } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Calendar as CalendarIcon,
  PlusCircle,
  AlertTriangle,
  AlertOctagon,
  CheckCircle2,
  X,
  FileText,
  Clock,
  ArrowRightLeft,
  UserCheck,
  UserX,
} from 'lucide-react';
import { useDuty } from '../../context/DutyContext';
import {
  formatDateToISO,
  getDayOfWeekFromDateString,
} from '../../utils/dutyEngine';
import {
  getShiftStyle,
  ShiftBadge,
} from '../../utils/shiftHelper';
import { DayDutyState, DutyAdjustment } from '../../types/duty';

interface CalendarViewProps {
  onNewAdjustment: (date: string) => void;
  onEditAdjustment: (adj: DutyAdjustment) => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({
  onNewAdjustment,
  onEditAdjustment,
}) => {
  const { getDayDuty, persons, shifts, adjustments, deleteAdjustment } = useDuty();

  // Current selected month view
  const [currentDate, setCurrentDate] = useState<Date>(() => new Date());
  // Selected date for bottom sheet / modal inspector
  const [selectedDateStr, setSelectedDateStr] = useState<string | null>(() =>
    formatDateToISO(new Date())
  );
  const [showDetailModal, setShowDetailModal] = useState<boolean>(false);

  // Lock background window scrolling when modal window is open
  React.useEffect(() => {
    if (showDetailModal) {
      const prevOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = prevOverflow;
      };
    }
  }, [showDetailModal]);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth(); // 0-indexed

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const handlePrevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const handleGoToday = () => {
    const today = new Date();
    setCurrentDate(today);
    setSelectedDateStr(formatDateToISO(today));
    setShowDetailModal(true);
  };

  // Build calendar matrix (Days of month)
  const calendarDays = useMemo(() => {
    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);

    const startingDayOfWeek = firstDayOfMonth.getDay(); // 0 is Sunday
    const daysInMonth = lastDayOfMonth.getDate();

    // Days from previous month to fill the first row
    const prevMonthLastDay = new Date(year, month, 0).getDate();
    const days = [];

    // Prefix days from previous month
    for (let i = startingDayOfWeek - 1; i >= 0; i--) {
      const prevDate = new Date(year, month - 1, prevMonthLastDay - i);
      const dateStr = formatDateToISO(prevDate);
      days.push({
        dateStr,
        dayNum: prevDate.getDate(),
        isCurrentMonth: false,
        dutyState: getDayDuty(dateStr),
      });
    }

    // Days of current month
    for (let i = 1; i <= daysInMonth; i++) {
      const curDate = new Date(year, month, i);
      const dateStr = formatDateToISO(curDate);
      days.push({
        dateStr,
        dayNum: i,
        isCurrentMonth: true,
        dutyState: getDayDuty(dateStr),
      });
    }

    // Suffix days from next month to complete standard grid (up to 35 or 42 cells)
    const totalSlots = Math.ceil(days.length / 7) * 7;
    const remaining = totalSlots - days.length;
    for (let i = 1; i <= remaining; i++) {
      const nextDate = new Date(year, month + 1, i);
      const dateStr = formatDateToISO(nextDate);
      days.push({
        dateStr,
        dayNum: i,
        isCurrentMonth: false,
        dutyState: getDayDuty(dateStr),
      });
    }

    return days;
  }, [year, month, getDayDuty]);

  const selectedDayDuty: DayDutyState | null = useMemo(() => {
    if (!selectedDateStr) return null;
    return getDayDuty(selectedDateStr);
  }, [selectedDateStr, getDayDuty]);

  const todayStr = formatDateToISO(new Date());

  return (
    <div className="space-y-5 pb-24 max-w-5xl mx-auto">
      {/* Calendar Header Card */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-900 text-white flex items-center justify-center font-bold">
              <CalendarIcon className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-blue-950">
                {monthNames[month]} {year}
              </h1>
              <p className="text-xs text-slate-500">
                White backdrop · Dynamic Navy typography & Dot Indicators
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleGoToday}
              className="px-3 py-1.5 text-xs font-bold text-blue-900 bg-blue-50 hover:bg-blue-100 rounded-xl transition-all"
            >
              Today
            </button>
            <div className="flex items-center bg-slate-100 rounded-xl p-1">
              <button
                onClick={handlePrevMonth}
                aria-label="Previous month"
                className="p-1.5 text-slate-600 hover:text-blue-900 hover:bg-white rounded-lg transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={handleNextMonth}
                aria-label="Next month"
                className="p-1.5 text-slate-600 hover:text-blue-900 hover:bg-white rounded-lg transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Legend */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-y-2 gap-x-4 text-xs">
          {/* Shifts visible legend */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-bold text-slate-500 uppercase tracking-wider text-[10px]">
              Shifts:
            </span>
            <ShiftBadge shiftName="Morning" size="xs" />
            <ShiftBadge shiftName="Afternoon" size="xs" />
            <ShiftBadge shiftName="Night" size="xs" />
            <ShiftBadge shiftName="Off" size="xs" />
          </div>

          {/* Indicators legend */}
          <div className="flex flex-wrap items-center gap-3">
            <span className="font-bold text-slate-500 uppercase tracking-wider text-[10px]">
              Indicators:
            </span>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-red-600"></span>
              <span className="text-slate-700 text-[11px]">He'll Do</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
              <span className="text-slate-700 text-[11px]">I'll Do</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-amber-500"></span>
              <span className="text-slate-700 text-[11px]">Exchange</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Calendar Grid */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Days of week header */}
        <div className="grid grid-cols-7 border-b border-slate-200 bg-slate-50/60 text-center">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
            <div key={d} className="py-2.5 text-xs font-bold text-blue-950 uppercase tracking-wider">
              {d}
            </div>
          ))}
        </div>

        {/* Day Cells */}
        <div className="grid grid-cols-7 divide-x divide-y divide-slate-100 bg-white">
          {calendarDays.map((cell) => {
            const isToday = cell.dateStr === todayStr;
            const isSelected = cell.dateStr === selectedDateStr;
            const state = cell.dutyState;
            const hasWarnings = state.warnings.length > 0;
            const hasCritical = state.warnings.some((w) => w.severity === 'critical');

            return (
              <div
                key={cell.dateStr}
                onClick={() => {
                  setSelectedDateStr(cell.dateStr);
                  setShowDetailModal(true);
                }}
                className={`min-h-[78px] sm:min-h-[102px] p-1.5 sm:p-2 cursor-pointer transition-all flex flex-col justify-between relative ${
                  !cell.isCurrentMonth ? 'bg-slate-50/40 text-slate-400' : 'text-blue-950 hover:bg-blue-50/30'
                } ${isSelected ? 'ring-2 ring-blue-900 ring-inset bg-blue-50/20' : ''}`}
              >
                {/* Cell Header: Date Number + Conflict Icon */}
                <div className="flex items-center justify-between">
                  <span
                    className={`text-xs sm:text-sm font-bold rounded-full w-6 h-6 flex items-center justify-center tabular-nums ${
                      isToday
                        ? 'bg-blue-900 text-white'
                        : cell.isCurrentMonth
                        ? 'text-blue-950'
                        : 'text-slate-400'
                    }`}
                  >
                    {cell.dayNum}
                  </span>

                  {hasCritical && (
                    <span title="Critical conflict" className="w-2 h-2 rounded-full bg-red-600 animate-ping"></span>
                  )}
                </div>

                {/* Duty Shift Summary Text on desktop */}
                <div className="mt-1 hidden sm:block">
                  {state.isNoDuty ? (
                    <span className="text-[10px] font-bold text-purple-700 bg-purple-50 px-1 py-0.5 rounded truncate block border border-purple-200">
                      No Duty
                    </span>
                  ) : state.finalShifts.length > 0 ? (
                    <div className="space-y-0.5">
                      {state.finalShifts.slice(0, 2).map((s, sIdx) => {
                        const style = getShiftStyle(s.shiftName);
                        return (
                          <div
                            key={sIdx}
                            className={`text-[10px] font-bold truncate px-1.5 py-0.5 rounded border flex items-center gap-1 ${style.bgBadge}`}
                          >
                            <span className="scale-75 shrink-0">{style.icon}</span>
                            <span className="truncate">{s.shiftName}</span>
                          </div>
                        );
                      })}
                      {state.finalShifts.length > 2 && (
                        <div className="text-[9px] font-bold text-red-600">
                          +{state.finalShifts.length - 2} more!
                        </div>
                      )}
                    </div>
                  ) : (
                    <span className="text-[10px] text-slate-400 italic">
                      {state.originalShiftName === 'Off' ? 'Off' : 'Relieved'}
                    </span>
                  )}
                </div>

                {/* Compact Shift Tag on Mobile */}
                <div className="mt-0.5 sm:hidden">
                  {state.isNoDuty ? (
                    <span className="text-[8px] font-bold text-purple-700 bg-purple-50 px-1 rounded block truncate">
                      Off
                    </span>
                  ) : state.finalShifts.length > 0 ? (
                    <div className="flex gap-0.5 flex-wrap">
                      {state.finalShifts.slice(0, 2).map((s, sIdx) => {
                        const style = getShiftStyle(s.shiftName);
                        return (
                          <span
                            key={sIdx}
                            className={`text-[8px] font-black px-1 rounded border ${style.bgBadge}`}
                          >
                            {style.shortLabel}
                          </span>
                        );
                      })}
                    </div>
                  ) : null}
                </div>

                {/* Colored Dots Indicators */}
                <div className="flex items-center gap-1 mt-1 flex-wrap">
                  {/* Red: Someone doing my duty */}
                  {state.indicators.hasSomeoneDoingMyDuty && (
                    <span
                      title="Someone is doing my duty"
                      className="w-2 h-2 rounded-full bg-red-600 shrink-0"
                    ></span>
                  )}

                  {/* Green: I am doing someone's duty */}
                  {state.indicators.hasIAmDoingSomeoneDuty && (
                    <span
                      title="I will be doing someone's duty"
                      className="w-2 h-2 rounded-full bg-emerald-600 shrink-0"
                    ></span>
                  )}

                  {/* Yellow: Shift Exchange */}
                  {state.indicators.hasShiftExchange && (
                    <span
                      title="Shift Exchange"
                      className="w-2 h-2 rounded-full bg-amber-500 shrink-0"
                    ></span>
                  )}

                  {/* Purple: No Duty */}
                  {state.indicators.hasNoDuty && (
                    <span
                      title="No Duty"
                      className="w-2 h-2 rounded-full bg-purple-600 shrink-0"
                    ></span>
                  )}

                  {hasWarnings && (
                    <span
                      title="Alert flag on this day"
                      className="w-1.5 h-1.5 rounded-full bg-red-500 ml-auto"
                    ></span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* BOTTOM SHEET / MODAL DATE INSPECTOR (Section 23) */}
      {showDetailModal && selectedDayDuty && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in overscroll-contain">
          <div
            className="bg-white rounded-t-3xl sm:rounded-2xl max-w-lg w-full p-5 sm:p-6 shadow-2xl border border-slate-200 max-h-[88vh] overflow-y-auto overscroll-contain my-auto space-y-4 custom-scrollbar"
            style={{ overscrollBehavior: 'contain' }}
          >
            {/* Sheet Handle for mobile */}
            <div className="sm:hidden w-12 h-1 bg-slate-300 rounded-full mx-auto -mt-1 mb-2"></div>

            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-blue-900">
                  {selectedDayDuty.dayOfWeek}
                </span>
                <h2 className="text-lg font-bold text-slate-900">
                  {selectedDayDuty.date}
                </h2>
              </div>
              <button
                onClick={() => setShowDetailModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Shift Comparison */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <span className="text-slate-500 block mb-1">Scheduled Roster:</span>
                <ShiftBadge shiftName={selectedDayDuty.originalShiftName} size="sm" />
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <span className="text-slate-500 block mb-1">Final Calculated Duty:</span>
                <div>
                  {selectedDayDuty.isNoDuty ? (
                    <ShiftBadge shiftName="Off" size="sm" />
                  ) : selectedDayDuty.finalShifts.length > 0 ? (
                    <div className="space-y-1">
                      {[...selectedDayDuty.finalShifts]
                        .sort((a, b) => {
                          const getOrder = (name: string, id: string) => {
                            const lower = (name + ' ' + id).toLowerCase();
                            if (lower.includes('morning')) return 1;
                            if (lower.includes('afternoon')) return 2;
                            if (lower.includes('night')) return 3;
                            return 4;
                          };
                          return getOrder(a.shiftName, a.shiftId) - getOrder(b.shiftName, b.shiftId);
                        })
                        .map((s, idx) => (
                          <div key={idx} className="space-y-0.5">
                            <ShiftBadge shiftName={s.shiftName} timing={s.timing} size="sm" />
                            {s.source === 'exchanged' && (
                              <div className="text-[10px] text-amber-800 font-semibold">
                                ⇄ Exchanged (Default: {selectedDayDuty.originalShiftName} · with {s.fromPersonName || 'Partner'})
                              </div>
                            )}
                          </div>
                        ))}
                    </div>
                  ) : (
                    <span className="text-slate-500 font-medium">Relieved / Off</span>
                  )}
                </div>
              </div>
            </div>

            {/* Warnings list on this date */}
            {selectedDayDuty.warnings.length > 0 && (
              <div className="space-y-2">
                {selectedDayDuty.warnings.map((w, idx) => (
                  <div
                    key={idx}
                    className={`p-3 rounded-xl border text-xs flex items-start gap-2.5 ${
                      w.severity === 'critical'
                        ? 'bg-red-50 border-red-200 text-red-950'
                        : w.severity === 'warning'
                        ? 'bg-amber-50 border-amber-200 text-amber-950'
                        : 'bg-emerald-50 border-emerald-200 text-emerald-950'
                    }`}
                  >
                    {w.severity === 'critical' ? (
                      <AlertOctagon className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                    ) : w.severity === 'warning' ? (
                      <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    ) : (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    )}
                    <div>
                      <div className="font-bold">{w.title}</div>
                      <div className="mt-0.5">{w.message}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Recorded Adjustments on this Date */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Adjustments On This Date ({selectedDayDuty.adjustments.length})
                </h3>
              </div>

              {selectedDayDuty.adjustments.length === 0 ? (
                <div className="p-4 bg-slate-50 rounded-xl text-center text-xs text-slate-500">
                  No adjustments recorded for this date. Standard weekly roster applies.
                </div>
              ) : (
                <div className="space-y-2.5">
                  {selectedDayDuty.adjustments.map((adj) => {
                    const person = persons.find((p) => p.id === adj.personId) || (adj.personName ? { name: adj.personName } : null);
                    const shift = shifts.find((s) => s.id === adj.shiftId);
                    const otherShift = shifts.find((s) => s.id === (adj.otherPersonShiftId || adj.colleagueShiftId));
                    const exchangePartnerName = adj.otherPersonName || person?.name || 'Partner';

                    return (
                      <div
                        key={adj.id}
                        className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-blue-900 bg-white px-2 py-0.5 rounded border border-blue-200">
                            {adj.action}
                          </span>
                          <span
                            className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                              adj.status === 'Completed'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {adj.status === 'Completed' ? '● Completed' : '○ Pending Reciprocal'}
                          </span>
                        </div>

                        {adj.action !== 'No Duty' && (
                          <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-700">
                            <div>
                              <span className="text-slate-400 block">Colleague:</span>
                              <strong className="text-slate-900">{person?.name || '—'}</strong>
                            </div>
                            <div>
                              <span className="text-slate-400 block">My Shift (Traded):</span>
                              <strong>{shift?.name || '—'}</strong>
                            </div>
                            {adj.action === 'Shift Exchange' && (
                              <div className="col-span-2 bg-white p-2 rounded border border-slate-200">
                                <span className="text-slate-400 block">Exchanged Shift (You Work):</span>
                                <strong className="text-blue-900">{otherShift?.name} ({otherShift?.startTime} – {otherShift?.endTime})</strong>
                                <span className="text-slate-500 block text-[10px] mt-0.5">Exchange Partner: <strong>{exchangePartnerName}</strong></span>
                              </div>
                            )}
                          </div>
                        )}

                        {adj.remarks && (
                          <div className="text-[11px] text-slate-500 italic bg-white p-2 rounded border border-slate-100">
                            "{adj.remarks}"
                          </div>
                        )}

                        {/* Quick Action buttons */}
                        <div className="flex items-center justify-end gap-2 pt-1 border-t border-slate-200/50">
                          <button
                            onClick={() => {
                              setShowDetailModal(false);
                              onEditAdjustment(adj);
                            }}
                            className="text-xs font-semibold text-blue-900 hover:text-blue-700"
                          >
                            Edit
                          </button>
                          <span className="text-slate-300">·</span>
                          <button
                            onClick={() => {
                              if (window.confirm('Are you sure you want to delete this adjustment record?')) {
                                deleteAdjustment(adj.id);
                              }
                            }}
                            className="text-xs font-semibold text-red-600 hover:text-red-700"
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Bottom Actions */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
              <button
                onClick={() => {
                  setShowDetailModal(false);
                  onNewAdjustment(selectedDayDuty.date);
                }}
                className="flex-1 py-2.5 px-4 text-xs font-bold text-white bg-blue-900 hover:bg-blue-800 rounded-xl transition-all flex items-center justify-center gap-1.5"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Add Adjustment on this Date</span>
              </button>
              <button
                onClick={() => setShowDetailModal(false)}
                className="py-2.5 px-4 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
