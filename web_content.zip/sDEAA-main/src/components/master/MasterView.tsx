import React, { useState, useRef } from 'react';
import {
  CalendarDays,
  Clock,
  Users,
  Plus,
  Edit2,
  Trash2,
  Shield,
  Save,
  AlertCircle,
  CheckCircle2,
  Settings,
  RotateCcw,
  Lock,
  Type,
  Sparkles,
  Check,
  Database,
  Download,
  Upload,
  Copy,
  FileText,
  FileCheck,
  FileJson,
  ArrowRight,
  HardDrive,
  AlertTriangle,
} from 'lucide-react';
import { useDuty } from '../../context/DutyContext';
import { DayOfWeek, ShiftDefinition } from '../../types/duty';
import { DAYS_OF_WEEK } from '../../utils/dutyEngine';
import {
  getShiftStyle,
  ShiftBadge,
  sortShiftsChronological,
} from '../../utils/shiftHelper';

export const MasterView: React.FC = () => {
  const {
    userName,
    employeeId,
    weeklyRoster,
    updateWeeklyRoster,
    shifts,
    addShift,
    updateShift,
    deleteShift,
    persons,
    addPerson,
    updatePerson,
    deletePerson,
    adjustments,
    dashboardFont,
    setDashboardFont,
    exportData,
    restoreData,
    resetToDefaults,
  } = useDuty();

  const [activeTab, setActiveTab] = useState<'roster' | 'shifts' | 'names' | 'font' | 'backup' | 'settings'>('roster');

  // Names management state
  const [newPersonName, setNewPersonName] = useState<string>('');
  const [editingPersonId, setEditingPersonId] = useState<string | null>(null);
  const [editingPersonName, setEditingPersonName] = useState<string>('');
  const [personSearch, setPersonSearch] = useState<string>('');
  const [personMessage, setPersonMessage] = useState<{ text: string; error?: boolean } | null>(null);

  // Shift management state
  const [editingShiftId, setEditingShiftId] = useState<string | null>(null);
  const [shiftForm, setShiftForm] = useState<{ name: string; startTime: string; endTime: string }>({
    name: '',
    startTime: '',
    endTime: '',
  });
  const [isAddingShift, setIsAddingShift] = useState<boolean>(false);
  const [shiftMessage, setShiftMessage] = useState<{ text: string; error?: boolean } | null>(null);

  // Backup & Restore state
  const [copyFeedback, setCopyFeedback] = useState<boolean>(false);
  const [backupDownloadMsg, setBackupDownloadMsg] = useState<string | null>(null);
  const [stagedBackup, setStagedBackup] = useState<any | null>(null);
  const [stagedFileName, setStagedFileName] = useState<string>('');
  const [stagedError, setStagedError] = useState<string | null>(null);
  const [restoreMessage, setRestoreMessage] = useState<{ text: string; error?: boolean } | null>(null);
  const [pasteInput, setPasteInput] = useState<string>('');
  const [showPasteBox, setShowPasteBox] = useState<boolean>(false);
  const [showRawJsonPreview, setShowRawJsonPreview] = useState<boolean>(false);
  const [isDragOver, setIsDragOver] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const orderedShifts = React.useMemo(() => sortShiftsChronological(shifts), [shifts]);

  // --- Handlers for Persons ---
  const handleAddPerson = (e: React.FormEvent) => {
    e.preventDefault();
    setPersonMessage(null);
    const res = addPerson(newPersonName);
    if (res.success) {
      setNewPersonName('');
      setPersonMessage({ text: 'Colleague successfully added to Master list.' });
    } else {
      setPersonMessage({ text: res.message || 'Error adding person', error: true });
    }
  };

  const handleSavePersonEdit = (id: string) => {
    setPersonMessage(null);
    const res = updatePerson(id, editingPersonName);
    if (res.success) {
      setEditingPersonId(null);
      setPersonMessage({ text: 'Person name updated successfully.' });
    } else {
      setPersonMessage({ text: res.message || 'Error updating person', error: true });
    }
  };

  const handleDeletePerson = (id: string) => {
    setPersonMessage(null);
    const res = deletePerson(id);
    if (res.success) {
      setPersonMessage({ text: 'Person removed from Master list.' });
    } else {
      setPersonMessage({ text: res.message || 'Error deleting person', error: true });
    }
  };

  // --- Handlers for Shifts ---
  const handleSaveNewShift = (e: React.FormEvent) => {
    e.preventDefault();
    setShiftMessage(null);
    if (!shiftForm.name.trim() || !shiftForm.startTime.trim() || !shiftForm.endTime.trim()) {
      setShiftMessage({ text: 'Please fill out all shift fields', error: true });
      return;
    }

    const res = addShift({
      name: shiftForm.name.trim(),
      startTime: shiftForm.startTime.trim(),
      endTime: shiftForm.endTime.trim(),
      isOvernight: shiftForm.name.toLowerCase().includes('night'),
    });

    if (res.success) {
      setIsAddingShift(false);
      setShiftForm({ name: '', startTime: '', endTime: '' });
      setShiftMessage({ text: 'New shift timing added to Master.' });
    } else {
      setShiftMessage({ text: res.message || 'Error adding shift', error: true });
    }
  };

  const handleSaveShiftEdit = (id: string) => {
    setShiftMessage(null);
    const res = updateShift(id, {
      name: shiftForm.name.trim(),
      startTime: shiftForm.startTime.trim(),
      endTime: shiftForm.endTime.trim(),
      isOvernight: shiftForm.name.toLowerCase().includes('night'),
    });

    if (res.success) {
      setEditingShiftId(null);
      setShiftForm({ name: '', startTime: '', endTime: '' });
      setShiftMessage({ text: 'Shift configuration updated.' });
    } else {
      setShiftMessage({ text: res.message || 'Error updating shift', error: true });
    }
  };

  const handleDeleteShift = (id: string) => {
    setShiftMessage(null);
    const res = deleteShift(id);
    if (res.success) {
      setShiftMessage({ text: 'Shift deleted.' });
    } else {
      setShiftMessage({ text: res.message || 'Cannot delete shift', error: true });
    }
  };

  // --- Handlers for Data Backup & Restore ---
  const handleDownloadBackup = () => {
    try {
      const backupObj = exportData();
      const jsonStr = JSON.stringify(backupObj, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const cleanName = (userName || 'officer').trim().replace(/[^a-zA-Z0-9_-]/g, '_');
      const now = new Date();
      const dateStr = now.toISOString().slice(0, 10);
      const timeStr = `${String(now.getHours()).padStart(2, '0')}${String(now.getMinutes()).padStart(2, '0')}`;
      const fileName = `duty_adjust_backup_${cleanName}_${dateStr}_${timeStr}.json`;

      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setBackupDownloadMsg(`Backup file downloaded successfully (${fileName}).`);
      setTimeout(() => setBackupDownloadMsg(null), 5000);
    } catch (err: any) {
      setRestoreMessage({ text: `Failed to generate backup: ${err?.message || 'Error'}`, error: true });
    }
  };

  const handleCopyBackupJson = () => {
    try {
      const backupObj = exportData();
      const jsonStr = JSON.stringify(backupObj, null, 2);
      navigator.clipboard.writeText(jsonStr);
      setCopyFeedback(true);
      setTimeout(() => setCopyFeedback(false), 2500);
    } catch {
      // Fallback
    }
  };

  const processBackupJsonString = (content: string, fileName: string = 'backup_data.json') => {
    setStagedError(null);
    setRestoreMessage(null);
    try {
      const parsed = JSON.parse(content);
      const payload = parsed.data && typeof parsed.data === 'object' ? parsed.data : parsed;
      if (!payload.weeklyRoster && !payload.adjustments && !payload.shifts && !payload.persons) {
        setStagedError('Invalid file structure: No recognized roster, shifts, colleague directory, or duty adjustments found.');
        setStagedBackup(null);
        return;
      }
      setStagedBackup(parsed);
      setStagedFileName(fileName);
    } catch (err: any) {
      setStagedError(`Failed to parse JSON file: ${err?.message || 'Invalid syntax'}`);
      setStagedBackup(null);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      processBackupJsonString(content, file.name);
    };
    reader.onerror = () => {
      setStagedError('Error reading the selected file. Please try again.');
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      processBackupJsonString(content, file.name);
    };
    reader.readAsText(file);
  };

  const handleConfirmRestore = () => {
    if (!stagedBackup) return;
    const res = restoreData(stagedBackup);
    if (res.success) {
      setRestoreMessage({
        text: `${res.message} Restored ${res.summary?.adjustments || 0} adjustments, ${res.summary?.shifts || 0} shifts, and ${res.summary?.persons || 0} colleagues.`,
      });
      setStagedBackup(null);
      setStagedFileName('');
      setPasteInput('');
      setShowPasteBox(false);
    } else {
      setRestoreMessage({ text: res.message, error: true });
    }
  };

  return (
    <div className="space-y-6 pb-24 max-w-4xl mx-auto">
      {/* Title & Permanent Officer Identity */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900">
              Master Configuration & Roster Settings
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">
              Only your 7-day duty roster schedule can be edited on Master. Officer credentials are permanently saved.
            </p>
          </div>
          <div className="flex items-center gap-2 p-2 px-3 bg-amber-50 border border-amber-200/80 rounded-xl text-xs text-amber-900 font-semibold shrink-0">
            <Lock className="w-4 h-4 text-amber-700" />
            <span>Credentials Locked</span>
          </div>
        </div>

        {/* Permanent Credentials Badge Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Officer:</span>
              <strong className="text-slate-900 font-bold">{userName || 'Duty Officer'}</strong>
            </div>
            <span className="text-slate-300">•</span>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Employee ID:</span>
              <strong className="font-mono text-blue-900 bg-white px-2 py-0.5 rounded border border-blue-200 font-bold text-[11px]">
                {employeeId || 'N/A'}
              </strong>
            </div>
          </div>
          <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
            ✓ 7-Day Duty Roster Editable Below
          </span>
        </div>

        {/* Master Tabs */}
        <div className="flex items-center gap-1.5 pt-2 border-t border-slate-100 overflow-x-auto pb-1">
          <button
            onClick={() => setActiveTab('roster')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'roster'
                ? 'bg-blue-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <CalendarDays className="w-3.5 h-3.5" />
            <span>7 Days Duty Roster (Editable)</span>
          </button>

          <button
            onClick={() => setActiveTab('names')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'names'
                ? 'bg-blue-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Colleague Names</span>
          </button>

          <button
            onClick={() => setActiveTab('shifts')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'shifts'
                ? 'bg-blue-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Shift Timings</span>
          </button>

          <button
            onClick={() => setActiveTab('font')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'font'
                ? 'bg-blue-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Type className="w-3.5 h-3.5" />
            <span>Dashboard Font</span>
          </button>

          <button
            onClick={() => setActiveTab('backup')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'backup'
                ? 'bg-blue-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>Backup & Restore</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'settings'
                ? 'bg-blue-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Profile & System</span>
          </button>
        </div>
      </div>

      {/* TAB 1: WEEKLY ROSTER (MY SHIFT) */}
      <div style={{ display: activeTab === 'roster' ? 'block' : 'none' }}>
        <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-3 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-900">
                  7 Days Duty Roster (Editable on Master)
                </h2>
                <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full">
                  Editable
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Baseline duty generated for every calendar week (Saturday through Friday). You can edit any day's shift anytime.
              </p>
            </div>
            <span className="text-xs font-semibold text-blue-900 bg-blue-50 px-2.5 py-1 rounded-lg">
              Auto-Applies to Dates
            </span>
          </div>

          <div className="space-y-3">
            {DAYS_OF_WEEK.map((day) => {
              const currentShiftId = weeklyRoster[day] || 'Off';
              const assignedShift = shifts.find((s) => s.id === currentShiftId);
              const assignedShiftName = currentShiftId === 'Off' ? 'Off' : (assignedShift?.name || 'Shift');

              return (
                <div
                  key={day}
                  className="flex flex-col sm:flex-row sm:items-center justify-between p-3.5 bg-slate-50 border border-slate-200 rounded-xl gap-3 hover:border-slate-300 transition-colors"
                >
                  <div className="w-36 flex flex-col gap-1">
                    <span className="font-bold text-slate-900 text-sm">{day}</span>
                    <div className="flex items-center gap-1.5">
                      <ShiftBadge
                        shiftName={assignedShiftName}
                        size="xs"
                      />
                    </div>
                  </div>

                  {/* 1-Click Segmented Shift Selector: Off, Morning, Afternoon, Night */}
                  <div className="flex flex-wrap items-center gap-1.5 flex-1 max-w-lg justify-start sm:justify-end">
                    <button
                      type="button"
                      onClick={() => updateWeeklyRoster(day, 'Off')}
                      className={`px-3 py-1.5 text-xs rounded-xl font-bold border transition-all cursor-pointer ${
                        currentShiftId === 'Off'
                          ? 'bg-purple-800 text-white border-purple-900 shadow-sm ring-1 ring-purple-600'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100 hover:text-slate-900'
                      }`}
                    >
                      ☕ Off (Rest)
                    </button>

                    {orderedShifts.map((s) => {
                      const isSel = currentShiftId === s.id;
                      const style = getShiftStyle(s.name || s.id);
                      return (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => updateWeeklyRoster(day, s.id)}
                          className={`px-3 py-1.5 text-xs rounded-xl font-bold border transition-all flex items-center gap-1.5 cursor-pointer ${
                            isSel
                              ? `${style.activeCard} ring-1 ring-current`
                              : `${style.inactiveCard}`
                          }`}
                          title={s.name}
                        >
                          <span className="scale-80 shrink-0">{style.icon}</span>
                          <span>{s.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* TAB 2: NAMES (COLLEAGUES & OFFICE) */}
      <div style={{ display: activeTab === 'names' ? 'block' : 'none' }}>
        <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Colleague Names & Special Entities
            </h2>
            <p className="text-xs text-slate-500">
              Maintain the list of officers and colleagues. "Office" is a protected system entity.
            </p>
          </div>

          {personMessage && (
            <div
              className={`p-3 rounded-xl text-xs font-semibold flex items-center gap-2 ${
                personMessage.error
                  ? 'bg-red-50 border border-red-200 text-red-800'
                  : 'bg-emerald-50 border border-emerald-200 text-emerald-800'
              }`}
            >
              {personMessage.error ? <AlertCircle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
              <span>{personMessage.text}</span>
            </div>
          )}

          {/* Add person form */}
          <form onSubmit={handleAddPerson} className="flex gap-2">
            <input
              type="text"
              value={newPersonName}
              onChange={(e) => setNewPersonName(e.target.value)}
              placeholder="Enter new colleague name (e.g. Officer Nathan)..."
              className="flex-1 px-3.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-900/20"
            />
            <button
              type="submit"
              className="px-4 py-2 text-xs font-bold text-white bg-blue-900 hover:bg-blue-800 rounded-xl transition-all flex items-center gap-1.5 shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Add Name</span>
            </button>
          </form>

          {/* Search box */}
          <div>
            <input
              type="text"
              value={personSearch}
              onChange={(e) => setPersonSearch(e.target.value)}
              placeholder="Filter names..."
              className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg"
            />
          </div>

          {/* List of Persons */}
          <div
            className="space-y-2 max-h-[480px] overflow-y-auto overscroll-contain pr-1 custom-scrollbar"
            style={{ overscrollBehavior: 'contain' }}
          >
            {persons
              .filter((p) => p.name.toLowerCase().includes(personSearch.toLowerCase()))
              .map((person) => {
                const isEditing = editingPersonId === person.id;

                return (
                  <div
                    key={person.id}
                    className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs"
                  >
                    {isEditing ? (
                      <div className="flex items-center gap-2 flex-1 mr-2">
                        <input
                          type="text"
                          value={editingPersonName}
                          onChange={(e) => setEditingPersonName(e.target.value)}
                          className="px-2 py-1 bg-white border border-slate-200 rounded text-xs flex-1"
                        />
                        <button
                          type="button"
                          onClick={() => handleSavePersonEdit(person.id)}
                          className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded hover:bg-emerald-100"
                        >
                          Save
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingPersonId(null)}
                          className="text-xs text-slate-500 px-2 py-1"
                        >
                          Cancel
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-900">{person.name}</span>
                        {person.isOffice && (
                          <span className="bg-blue-100 text-blue-900 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                            <Shield className="w-3 h-3" /> Protected Entity
                          </span>
                        )}
                        {person.frequencyScore && person.frequencyScore > 1 && (
                          <span className="text-[10px] text-slate-400">
                            ({person.frequencyScore} adjustments)
                          </span>
                        )}
                      </div>
                    )}

                    {!isEditing && (
                      <div className="flex items-center gap-2">
                        {!person.isOffice ? (
                          <>
                            <button
                              onClick={() => {
                                setEditingPersonId(person.id);
                                setEditingPersonName(person.name);
                              }}
                              className="p-1 text-slate-500 hover:text-blue-900 rounded"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeletePerson(person.id)}
                              className="p-1 text-slate-500 hover:text-red-700 rounded"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </>
                        ) : (
                          <span className="text-[10px] text-slate-400 italic">Protected</span>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
          </div>
        </div>
      </div>

      {/* TAB 3: SHIFT MASTER */}
      <div style={{ display: activeTab === 'shifts' ? 'block' : 'none' }}>
        <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Shift Timings & Duty Windows
              </h2>
              <p className="text-xs text-slate-500">
                Configure shift names, start times, and end times. Night shifts crossing midnight are handled automatically.
              </p>
            </div>
            {!isAddingShift && (
              <button
                onClick={() => {
                  setIsAddingShift(true);
                  setShiftForm({ name: '', startTime: '08:00 AM', endTime: '04:00 PM' });
                }}
                className="px-3.5 py-1.5 text-xs font-bold text-white bg-blue-900 hover:bg-blue-800 rounded-xl flex items-center gap-1"
              >
                <Plus className="w-4 h-4" />
                <span>Add Shift</span>
              </button>
            )}
          </div>

          {shiftMessage && (
            <div
              className={`p-3 rounded-xl text-xs font-semibold flex items-center gap-2 ${
                shiftMessage.error
                  ? 'bg-red-50 border border-red-200 text-red-800'
                  : 'bg-emerald-50 border border-emerald-200 text-emerald-800'
              }`}
            >
              {shiftMessage.error ? <AlertCircle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
              <span>{shiftMessage.text}</span>
            </div>
          )}

          {/* Add shift inline form */}
          {isAddingShift && (
            <form onSubmit={handleSaveNewShift} className="p-4 bg-blue-50/50 border border-blue-200 rounded-xl space-y-3">
              <span className="text-xs font-bold text-blue-900 uppercase tracking-wider block">
                New Shift Definition
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">Shift Name</label>
                  <input
                    type="text"
                    value={shiftForm.name}
                    onChange={(e) => setShiftForm({ ...shiftForm, name: e.target.value })}
                    placeholder="e.g. Evening Special"
                    className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg"
                    required
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">Start Time</label>
                  <input
                    type="text"
                    value={shiftForm.startTime}
                    onChange={(e) => setShiftForm({ ...shiftForm, startTime: e.target.value })}
                    placeholder="e.g. 03:00 PM"
                    className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">End Time</label>
                  <input
                    type="text"
                    value={shiftForm.endTime}
                    onChange={(e) => setShiftForm({ ...shiftForm, endTime: e.target.value })}
                    placeholder="e.g. 11:00 PM"
                    className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg font-mono"
                    required
                  />
                </div>
              </div>
              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsAddingShift(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-bold text-white bg-blue-900 rounded-lg"
                >
                  Save Shift
                </button>
              </div>
            </form>
          )}

          {/* List of shifts (Morning, Afternoon, Night) */}
          <div
            className="space-y-3 max-h-[480px] overflow-y-auto overscroll-contain pr-1 custom-scrollbar"
            style={{ overscrollBehavior: 'contain' }}
          >
            {orderedShifts.map((shift) => {
              const isEditing = editingShiftId === shift.id;
              const style = getShiftStyle(shift.name || shift.id);

              return (
                <div
                  key={shift.id}
                  className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs"
                >
                  {isEditing ? (
                    <div className="space-y-3">
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        <div>
                          <label className="text-[10px] text-slate-500 font-bold">Shift Name</label>
                          <input
                            type="text"
                            value={shiftForm.name}
                            onChange={(e) => setShiftForm({ ...shiftForm, name: e.target.value })}
                            className="w-full px-2 py-1 text-xs bg-white border border-slate-200 rounded"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-500 font-bold">Start Time</label>
                          <input
                            type="text"
                            value={shiftForm.startTime}
                            onChange={(e) => setShiftForm({ ...shiftForm, startTime: e.target.value })}
                            className="w-full px-2 py-1 text-xs bg-white border border-slate-200 rounded font-mono"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-500 font-bold">End Time</label>
                          <input
                            type="text"
                            value={shiftForm.endTime}
                            onChange={(e) => setShiftForm({ ...shiftForm, endTime: e.target.value })}
                            className="w-full px-2 py-1 text-xs bg-white border border-slate-200 rounded font-mono"
                          />
                        </div>
                      </div>
                      <div className="flex items-center justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setEditingShiftId(null)}
                          className="px-3 py-1 text-xs text-slate-500"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSaveShiftEdit(shift.id)}
                          className="px-3 py-1 text-xs font-bold text-white bg-blue-900 rounded"
                        >
                          Update
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="p-1 rounded-md bg-white border border-slate-200">
                            {style.icon}
                          </span>
                          <strong className="text-sm font-bold text-slate-900">{shift.name}</strong>
                          <ShiftBadge shiftName={shift.name} size="xs" />
                          {shift.isOvernight && (
                            <span className="text-[10px] bg-indigo-100 text-indigo-900 font-bold px-2 py-0.5 rounded-full">
                              Crosses Midnight
                            </span>
                          )}
                        </div>
                        <div className="text-slate-500 font-mono text-xs mt-1">
                          {shift.startTime} – {shift.endTime}
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => {
                            setEditingShiftId(shift.id);
                            setShiftForm({
                              name: shift.name,
                              startTime: shift.startTime,
                              endTime: shift.endTime,
                            });
                          }}
                          className="p-1.5 text-slate-500 hover:text-blue-900"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteShift(shift.id)}
                          className="p-1.5 text-slate-500 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* TAB 4: DASHBOARD FONT CUSTOMIZATION */}
      <div style={{ display: activeTab === 'font' ? 'block' : 'none' }}>
        <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-3 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-900">
                  Dashboard Font Customization (Master)
                </h2>
                <span className="text-[10px] font-bold text-blue-900 bg-blue-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-blue-700" />
                  Live Preview
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Select the font style applied to all duty tags across Today, Tomorrow, and Day After Tomorrow on your dashboard.
              </p>
            </div>
            <span className="text-xs font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
              Auto-saved to Master
            </span>
          </div>

          {/* 4 Font Options Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {[
              {
                id: 'script' as const,
                name: 'Reference Calligraphic Script',
                family: 'Great Vibes / Alex Brush',
                tag: 'Reference Image Default',
                badgeColor: 'bg-blue-100 text-blue-900 border-blue-200',
                fontClass: 'font-reference-script',
                desc: 'Calligraphic cursive handwriting as specified from the reference image.',
              },
              {
                id: 'brush' as const,
                name: 'Handwritten Brush Script',
                family: 'Caveat / Dancing Script',
                tag: 'Natural Handwriting',
                badgeColor: 'bg-purple-100 text-purple-900 border-purple-200',
                fontClass: 'font-reference-brush',
                desc: 'Warm and expressive handwritten brush stroke lettering.',
              },
              {
                id: 'serif' as const,
                name: 'Classic Editorial Serif',
                family: 'Playfair Display',
                tag: 'Distinguished',
                badgeColor: 'bg-amber-100 text-amber-900 border-amber-200',
                fontClass: 'font-reference-serif italic',
                desc: 'High-contrast traditional serif with sophisticated character.',
              },
              {
                id: 'sans' as const,
                name: 'Modern Bold Sans',
                family: 'Plus Jakarta Sans',
                tag: 'Clean Geometric',
                badgeColor: 'bg-slate-100 text-slate-800 border-slate-200',
                fontClass: 'font-black tracking-tight',
                desc: 'Ultra-crisp modern sans-serif for sharp, legible visibility.',
              },
            ].map((f) => {
              const isSelected = dashboardFont === f.id;
              return (
                <div
                  key={f.id}
                  onClick={() => setDashboardFont(f.id)}
                  className={`p-4 rounded-2xl border-2 transition-all cursor-pointer relative flex flex-col justify-between ${
                    isSelected
                      ? 'border-blue-900 bg-blue-50/30 shadow-md ring-2 ring-blue-900/10'
                      : 'border-slate-200 bg-white hover:border-slate-300 hover:shadow-xs'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <strong className="text-sm font-bold text-slate-900">{f.name}</strong>
                        <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded border ${f.badgeColor}`}>
                          {f.tag}
                        </span>
                      </div>
                      <div
                        className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${
                          isSelected ? 'bg-blue-900 text-white' : 'border border-slate-300 text-transparent'
                        }`}
                      >
                        <Check className="w-3 h-3 stroke-[3]" />
                      </div>
                    </div>

                    <p className="text-[11px] text-slate-500 mb-3">{f.desc}</p>

                    {/* Live typography specimen */}
                    <div className="p-3 bg-slate-50/80 rounded-xl border border-slate-200/80 mb-2">
                      <div className="text-[10px] text-slate-400 font-semibold mb-1">
                        Preview Specimen ({f.family}):
                      </div>
                      <div className={`text-2xl sm:text-3xl text-slate-900 leading-tight ${f.fontClass}`}>
                        Afternoon & Night
                      </div>
                      <div className={`text-xl sm:text-2xl text-slate-700 leading-tight mt-1 ${f.fontClass}`}>
                        Morning Duty
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[11px]">
                    <span className="text-slate-400 font-medium">Font Family: {f.family}</span>
                    <span
                      className={`font-bold ${
                        isSelected ? 'text-blue-900' : 'text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      {isSelected ? '✓ Active on Dashboard' : 'Click to Apply'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Simulated Today's Duty Box Preview */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <Type className="w-4 h-4 text-blue-900" />
                <span>Simulated Dashboard Today's Duty Card Preview</span>
              </span>
              <span className="text-[10px] font-bold text-blue-900 bg-white border border-blue-200 px-2 py-0.5 rounded-md">
                Reflects Selected Font
              </span>
            </div>

            <div className="bg-white rounded-xl p-3 border border-blue-900/60 shadow-xs ring-1 ring-blue-900/15 max-w-md mx-auto">
              <div className="flex items-center justify-between pb-1 border-b border-slate-100 mb-2">
                <div className="flex items-center gap-1.5">
                  <span className="text-[9px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded bg-blue-900 text-white">
                    TODAY'S DUTY
                  </span>
                  <span className="text-[10px] text-slate-500 font-semibold">Today, Live Preview</span>
                </div>
                <span className="text-[8px] font-bold px-1.5 py-0.5 rounded-full border bg-blue-50 text-blue-900 border-blue-200 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-blue-900" />
                  <span>Double Shift</span>
                </span>
              </div>

              <div className="grid grid-cols-2 gap-1.5">
                <div className="p-2 rounded-xl border border-amber-200/80 bg-amber-50/30">
                  <div className="text-[8px] text-slate-500 font-semibold mb-0.5">02:01 PM - 09:00 PM</div>
                  <div
                    className={`text-2xl font-bold text-slate-900 block leading-tight ${
                      dashboardFont === 'script'
                        ? 'font-reference-script'
                        : dashboardFont === 'brush'
                        ? 'font-reference-brush'
                        : dashboardFont === 'serif'
                        ? 'font-reference-serif italic'
                        : 'font-black tracking-tight'
                    }`}
                  >
                    Afternoon
                  </div>
                  <div className="text-[7.5px] text-slate-500 pt-0.5 border-t border-slate-200/60 mt-0.5">
                    Scheduled Roster
                  </div>
                </div>

                <div className="p-2 rounded-xl border border-indigo-200/80 bg-indigo-50/30">
                  <div className="text-[8px] text-slate-500 font-semibold mb-0.5">09:01 PM - 07:00 AM</div>
                  <div
                    className={`text-2xl font-bold text-slate-900 block leading-tight ${
                      dashboardFont === 'script'
                        ? 'font-reference-script'
                        : dashboardFont === 'brush'
                        ? 'font-reference-brush'
                        : dashboardFont === 'serif'
                        ? 'font-reference-serif italic'
                        : 'font-black tracking-tight'
                    }`}
                  >
                    Night
                  </div>
                  <div className="text-[7.5px] text-emerald-800 font-bold pt-0.5 border-t border-slate-200/60 mt-0.5">
                    Covering Colleague
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* TAB 5: DATA BACKUP & RESTORE */}
      <div style={{ display: activeTab === 'backup' ? 'block' : 'none' }}>
        <div className="space-y-6">
          {/* Main Header Card */}
          <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-900 shrink-0">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-slate-900">
                    Data Backup & Disaster Recovery Manager
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Create secure offline JSON backups of all your duty schedules and adjustments, or restore past records anytime.
                  </p>
                </div>
              </div>
              <span className="text-[11px] font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-xl self-start sm:self-auto flex items-center gap-1.5">
                <HardDrive className="w-3.5 h-3.5" />
                Offline & Private
              </span>
            </div>

            {/* Notifications */}
            {restoreMessage && (
              <div
                className={`p-3.5 rounded-xl text-xs font-semibold flex items-center justify-between gap-3 ${
                  restoreMessage.error
                    ? 'bg-red-50 text-red-900 border border-red-200'
                    : 'bg-emerald-50 text-emerald-900 border border-emerald-200'
                }`}
              >
                <div className="flex items-center gap-2">
                  {restoreMessage.error ? (
                    <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  )}
                  <span>{restoreMessage.text}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setRestoreMessage(null)}
                  className="text-slate-400 hover:text-slate-700 text-xs px-2 py-0.5 rounded cursor-pointer"
                >
                  ✕
                </button>
              </div>
            )}

            {backupDownloadMsg && (
              <div className="p-3.5 rounded-xl text-xs font-semibold bg-blue-50 text-blue-900 border border-blue-200 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-700 shrink-0" />
                  <span>{backupDownloadMsg}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setBackupDownloadMsg(null)}
                  className="text-slate-400 hover:text-slate-700 text-xs px-2 py-0.5 rounded cursor-pointer"
                >
                  ✕
                </button>
              </div>
            )}

            {/* Current Storage Inventory Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider block">
                  Duty Records
                </span>
                <div className="flex items-baseline gap-1 mt-0.5">
                  <span className="text-xl font-bold text-slate-900 font-mono">
                    {adjustments.length}
                  </span>
                  <span className="text-[10px] text-slate-500">entries</span>
                </div>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider block">
                  Colleagues Directory
                </span>
                <div className="flex items-baseline gap-1 mt-0.5">
                  <span className="text-xl font-bold text-slate-900 font-mono">
                    {persons.length}
                  </span>
                  <span className="text-[10px] text-slate-500">contacts</span>
                </div>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider block">
                  Defined Shifts
                </span>
                <div className="flex items-baseline gap-1 mt-0.5">
                  <span className="text-xl font-bold text-slate-900 font-mono">
                    {shifts.length}
                  </span>
                  <span className="text-[10px] text-slate-500">shifts</span>
                </div>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider block">
                  Baseline Roster
                </span>
                <div className="flex items-baseline gap-1 mt-0.5">
                  <span className="text-xl font-bold text-slate-900 font-mono">
                    7
                  </span>
                  <span className="text-[10px] text-slate-500">days active</span>
                </div>
              </div>
            </div>
          </div>

          {/* TWO COLUMNS: BACKUP (EXPORT) & RESTORE (IMPORT) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* CARD 1: BACKUP EXPORT */}
            <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                  <Download className="w-4 h-4 text-blue-900" />
                  <h3>Create & Download Backup</h3>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Download a complete JSON snapshot containing all your adjustment entries, scheduled 7-day roster, shift timings, colleague contacts, and preferences.
                </p>

                <div className="p-3.5 bg-blue-50/60 rounded-xl border border-blue-100 text-xs text-blue-950 space-y-1.5">
                  <div className="font-bold flex items-center gap-1.5 text-blue-900">
                    <Shield className="w-3.5 h-3.5" />
                    <span>Included in this backup file:</span>
                  </div>
                  <ul className="text-[11px] text-slate-600 space-y-1 list-disc pl-4">
                    <li>Officer credentials ({userName || 'Officer'} • {employeeId || 'ID'})</li>
                    <li>{adjustments.length} Duty adjustments and history records</li>
                    <li>7-Day weekly baseline shift schedules</li>
                    <li>{persons.length} Colleague directory contacts</li>
                    <li>{shifts.length} Shift definitions & timings</li>
                    <li>Dashboard font styling preference</li>
                  </ul>
                </div>
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={handleDownloadBackup}
                  className="w-full py-2.5 px-4 bg-blue-900 hover:bg-blue-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Backup File (.json)</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleCopyBackupJson}
                    className="flex-1 py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    {copyFeedback ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-emerald-700 font-bold">Copied JSON!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-slate-500" />
                        <span>Copy JSON to Clipboard</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowRawJsonPreview(!showRawJsonPreview)}
                    className="py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <FileText className="w-3.5 h-3.5 text-slate-500" />
                    <span>{showRawJsonPreview ? 'Hide Raw' : 'Preview'}</span>
                  </button>
                </div>

                {showRawJsonPreview && (
                  <div className="mt-2 p-2.5 bg-slate-900 text-emerald-400 rounded-xl font-mono text-[10px] max-h-48 overflow-y-auto overflow-x-hidden whitespace-pre-wrap break-all border border-slate-800">
                    {JSON.stringify(exportData(), null, 2)}
                  </div>
                )}
              </div>
            </div>

            {/* CARD 2: RESTORE IMPORT */}
            <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                  <Upload className="w-4 h-4 text-emerald-700" />
                  <h3>Restore from Backup</h3>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Upload a previously saved <code className="bg-slate-100 px-1 py-0.5 rounded text-[11px] font-mono text-slate-800">.json</code> backup file or paste its content to restore all your duty records.
                </p>

                {/* Staged file parsing error */}
                {stagedError && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-900 flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <span className="font-bold block">File Read Error</span>
                      <span>{stagedError}</span>
                    </div>
                  </div>
                )}

                {/* File Dropzone or Selection */}
                {!stagedBackup && (
                  <div
                    onDragOver={(e) => {
                      e.preventDefault();
                      setIsDragOver(true);
                    }}
                    onDragLeave={() => setIsDragOver(false)}
                    onDrop={handleDrop}
                    onClick={() => fileInputRef.current?.click()}
                    className={`border-2 border-dashed rounded-xl p-5 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-2 ${
                      isDragOver
                        ? 'border-emerald-600 bg-emerald-50/50'
                        : 'border-slate-300 hover:border-emerald-600 hover:bg-slate-50/70'
                    }`}
                  >
                    <input
                      type="file"
                      ref={fileInputRef}
                      accept=".json"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                    <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-800">
                      <FileJson className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-800">
                        Select Backup File (.json)
                      </div>
                      <div className="text-[10px] text-slate-500 mt-0.5">
                        or drag and drop your file here
                      </div>
                    </div>
                  </div>
                )}

                {/* Staged Backup Preview Card */}
                {stagedBackup && (
                  <div className="p-3.5 bg-emerald-50/60 border border-emerald-200 rounded-xl space-y-2.5">
                    <div className="flex items-center justify-between pb-2 border-b border-emerald-200/70">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-950">
                        <FileCheck className="w-4 h-4 text-emerald-700" />
                        <span className="truncate max-w-[200px]">{stagedFileName}</span>
                      </div>
                      <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100/80 px-2 py-0.5 rounded-full">
                        Ready to Restore
                      </span>
                    </div>

                    {/* Inspection metrics */}
                    <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-700">
                      <div>
                        <span className="text-slate-400 block text-[9.5px] uppercase font-bold">Officer in Backup</span>
                        <strong className="text-slate-900 font-bold">
                          {stagedBackup.data?.userName || stagedBackup.userName || 'Unspecified'}
                        </strong>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[9.5px] uppercase font-bold">Employee ID</span>
                        <strong className="font-mono text-slate-900 font-bold">
                          {stagedBackup.data?.employeeId || stagedBackup.employeeId || 'N/A'}
                        </strong>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[9.5px] uppercase font-bold">Adjustments</span>
                        <span className="font-bold text-emerald-900">
                          {Array.isArray(stagedBackup.data?.adjustments || stagedBackup.adjustments)
                            ? (stagedBackup.data?.adjustments || stagedBackup.adjustments).length
                            : 0}{' '}
                          records
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[9.5px] uppercase font-bold">Colleagues</span>
                        <span className="font-bold text-emerald-900">
                          {Array.isArray(stagedBackup.data?.persons || stagedBackup.persons)
                            ? (stagedBackup.data?.persons || stagedBackup.persons).length
                            : 0}{' '}
                          names
                        </span>
                      </div>
                    </div>

                    <div className="text-[10.5px] text-amber-800 bg-amber-50 p-2 rounded-lg border border-amber-200/70">
                      ⚠️ Restoring will overwrite existing duty history and settings with the data in this backup file.
                    </div>

                    <div className="flex items-center gap-2 pt-1">
                      <button
                        type="button"
                        onClick={handleConfirmRestore}
                        className="flex-1 py-2 px-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Confirm & Restore Now</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setStagedBackup(null);
                          setStagedFileName('');
                          setStagedError(null);
                        }}
                        className="py-2 px-3 bg-white hover:bg-slate-100 text-slate-600 rounded-xl text-xs font-semibold border border-slate-200 transition-colors cursor-pointer"
                      >
                        Discard
                      </button>
                    </div>
                  </div>
                )}

                {/* Paste JSON directly toggle */}
                {!stagedBackup && (
                  <div className="pt-1">
                    <button
                      type="button"
                      onClick={() => setShowPasteBox(!showPasteBox)}
                      className="text-[11px] font-semibold text-blue-900 hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <span>{showPasteBox ? '▼ Hide Direct JSON Paste' : '▶ Or Paste JSON Code Directly'}</span>
                    </button>

                    {showPasteBox && (
                      <div className="mt-2 space-y-2">
                        <textarea
                          value={pasteInput}
                          onChange={(e) => setPasteInput(e.target.value)}
                          placeholder="Paste JSON backup text here..."
                          rows={4}
                          className="w-full text-[11px] font-mono p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-blue-900 focus:outline-none"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            if (!pasteInput.trim()) return;
                            processBackupJsonString(pasteInput.trim(), 'pasted_backup.json');
                          }}
                          disabled={!pasteInput.trim()}
                          className="w-full py-2 bg-slate-800 hover:bg-slate-900 disabled:opacity-50 text-white rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <FileCheck className="w-3.5 h-3.5" />
                          <span>Validate & Review Pasted JSON</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="text-[10px] text-slate-400 pt-2 border-t border-slate-100 flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-slate-400" />
                <span>Zero cloud transmission. All backup and restore actions run locally in your browser.</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* TAB 6: SETTINGS & USER PROFILE (PERMANENT CREDENTIALS) */}
      <div style={{ display: activeTab === 'settings' ? 'block' : 'none' }}>
        <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs space-y-6">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Permanent Officer Identity & System Controls
            </h2>
            <p className="text-xs text-slate-500">
              Officer credentials are permanently locked. Only the 7-day duty roster can be edited on Master.
            </p>
          </div>

          {/* Permanent Credentials Display Card */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 sm:p-5 space-y-3">
            <div className="flex items-center gap-2 text-slate-800 font-bold text-xs uppercase tracking-wider">
              <Lock className="w-4 h-4 text-amber-600" />
              <span>Permanent Officer Credentials (Locked)</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
                <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                  Officer Full Name
                </span>
                <div className="flex items-center justify-between">
                  <strong className="text-sm font-bold text-slate-900">{userName || 'Duty Officer'}</strong>
                  <span className="text-[10px] text-amber-700 font-bold bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-md flex items-center gap-1">
                    <Lock className="w-3 h-3" /> Permanent
                  </span>
                </div>
              </div>

              <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
                <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                  Employee ID
                </span>
                <div className="flex items-center justify-between">
                  <strong className="text-sm font-mono font-bold text-slate-900">{employeeId || 'N/A'}</strong>
                  <span className="text-[10px] text-amber-700 font-bold bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-md flex items-center gap-1">
                    <Lock className="w-3 h-3" /> Permanent
                  </span>
                </div>
              </div>
            </div>

            <div className="p-3 bg-blue-50/70 rounded-xl border border-blue-100 text-xs text-blue-900 leading-relaxed">
              <strong>System Rule:</strong> Your Officer Name and Employee ID are permanently saved and cannot be edited. As per system requirements, only your 7-day duty roster can be edited on Master under the <strong>7 Days Duty Roster (Editable)</strong> tab.
            </div>

            {/* Quick link to Dashboard Font */}
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Type className="w-4 h-4 text-blue-900" />
                <div>
                  <div className="text-xs font-bold text-slate-900">Dashboard Font Style</div>
                  <div className="text-[10px] text-slate-500">
                    Currently configured:{' '}
                    <span className="font-bold text-blue-900">
                      {dashboardFont === 'script'
                        ? 'Reference Calligraphic Script'
                        : dashboardFont === 'brush'
                        ? 'Handwritten Brush Script'
                        : dashboardFont === 'serif'
                        ? 'Classic Editorial Serif'
                        : 'Modern Bold Sans'}
                    </span>
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('font')}
                className="px-2.5 py-1 text-xs font-bold text-blue-900 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors cursor-pointer"
              >
                Customize Font →
              </button>
            </div>

            {/* Quick link to Backup & Restore */}
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-emerald-700" />
                <div>
                  <div className="text-xs font-bold text-slate-900">Data Backup & Restore</div>
                  <div className="text-[10px] text-slate-500">
                    Export JSON snapshot or restore duty history, roster baseline, and colleagues directory.
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('backup')}
                className="px-2.5 py-1 text-xs font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 rounded-lg border border-emerald-200 transition-colors cursor-pointer"
              >
                Backup & Restore →
              </button>
            </div>
          </div>

          {/* Reset Demo Data */}
          <div className="pt-4 border-t border-slate-100">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
              Reset Application State & Re-register
            </h3>
            <p className="text-xs text-slate-500 mb-3">
              Clear all saved data and restart the initial registration process.
            </p>
            <button
              onClick={() => {
                if (window.confirm('Reset all duty records, credentials, and weekly rosters back to defaults and return to initial registration?')) {
                  resetToDefaults();
                }
              }}
              className="px-4 py-2 text-xs font-semibold text-red-700 bg-red-50 hover:bg-red-100 border border-red-200 rounded-xl transition-all flex items-center gap-1.5"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Reset All & Re-register</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
