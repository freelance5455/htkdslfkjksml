import React, { useState, useEffect, useMemo } from 'react';
import {
  Calendar,
  Clock,
  User,
  AlertTriangle,
  AlertOctagon,
  CheckCircle2,
  FileText,
  ArrowRightLeft,
  X,
  Search,
  Sparkles,
  ShieldAlert,
  Sun,
  Sunset,
  Moon,
} from 'lucide-react';
import { useDuty } from '../../context/DutyContext';
import {
  AdjustmentAction,
  DutyAdjustment,
  ShiftDefinition,
} from '../../types/duty';
import {
  analyzeProposedAdjustment,
  formatDateToISO,
  getDayOfWeekFromDateString,
  getRegularShiftForDate,
} from '../../utils/dutyEngine';
import {
  sortShiftsChronological,
  getShiftStyle,
} from '../../utils/shiftHelper';

interface NewEntryViewProps {
  initialDate?: string;
  editingAdjustment?: DutyAdjustment | null;
  onSuccess: () => void;
  onCancel: () => void;
}

const COMMON_REASONS = [
  'Personal emergency',
  'Mutual exchange agreement',
  'Official department adjustment',
  'Medical / Doctor appointment',
  'Family commitment',
  'Overtime compensation',
];

export const NewEntryView: React.FC<NewEntryViewProps> = ({
  initialDate,
  editingAdjustment,
  onSuccess,
  onCancel,
}) => {
  const {
    userName,
    weeklyRoster,
    shifts,
    persons,
    adjustments,
    frequentNames,
    addAdjustment,
    updateAdjustment,
    addPerson,
  } = useDuty();

  const defaultDate = initialDate || (editingAdjustment ? editingAdjustment.date : formatDateToISO(new Date()));

  const [date, setDate] = useState<string>(defaultDate);
  const [entryFrom, setEntryFrom] = useState<string>(
    editingAdjustment?.entryFrom || 'Main Operations Desk'
  );
  const [action, setAction] = useState<AdjustmentAction>(
    editingAdjustment?.action || "I'll Do"
  );
  const [personId, setPersonId] = useState<string>(
    editingAdjustment?.personId || ''
  );
  const [shiftId, setShiftId] = useState<string>(
    editingAdjustment?.shiftId || ''
  );
  const [otherPersonShiftId, setOtherPersonShiftId] = useState<string>(
    editingAdjustment?.otherPersonShiftId || ''
  );
  const [remarks, setRemarks] = useState<string>(
    editingAdjustment?.remarks || ''
  );

  // Colleague's Shift state (Option 2 in Shift Exchange)
  const [colleagueShiftId, setColleagueShiftId] = useState<string>(
    editingAdjustment?.colleagueShiftId || editingAdjustment?.otherPersonShiftId || ''
  );
  const [colleagueName, setColleagueName] = useState<string>(
    editingAdjustment?.personName ||
      (editingAdjustment?.personId ? persons.find((p) => p.id === editingAdjustment.personId)?.name || '' : '')
  );
  const [colleaguePersonId, setColleaguePersonId] = useState<string>(
    editingAdjustment?.personId || ''
  );
  const [isColleagueDropdownOpen, setIsColleagueDropdownOpen] = useState<boolean>(false);

  // Exchange with Shift state (Option 3 in Shift Exchange)
  const [exchangePersonName, setExchangePersonName] = useState<string>(
    editingAdjustment?.otherPersonName ||
      (editingAdjustment?.otherPersonId ? persons.find((p) => p.id === editingAdjustment.otherPersonId)?.name || '' : '') ||
      editingAdjustment?.personName ||
      ''
  );
  const [exchangePersonId, setExchangePersonId] = useState<string>(
    editingAdjustment?.otherPersonId || editingAdjustment?.personId || ''
  );
  const [isExchangePersonDropdownOpen, setIsExchangePersonDropdownOpen] = useState<boolean>(false);

  // Search filter for person dropdown (used in I'll Do / He'll Do)
  const [personSearch, setPersonSearch] = useState<string>('');
  const [isPersonDropdownOpen, setIsPersonDropdownOpen] = useState<boolean>(false);

  // Modal confirmation state
  const [showConfirmModal, setShowConfirmModal] = useState<boolean>(false);
  const [overrideRedAlert, setOverrideRedAlert] = useState<boolean>(false);
  const [validationError, setValidationError] = useState<string>('');

  // Lock background window scrolling when confirm modal is open
  useEffect(() => {
    if (showConfirmModal) {
      const prevOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = prevOverflow;
      };
    }
  }, [showConfirmModal]);

  // Determine user's standard roster shift on selected date
  const orderedShifts = useMemo(() => sortShiftsChronological(shifts), [shifts]);

  const regularShiftId = useMemo(() => {
    return getRegularShiftForDate(date, weeklyRoster);
  }, [date, weeklyRoster]);

  // Determine held shifts on this date (regular roster and any taken shifts)
  const heldOnDate = useMemo(() => {
    const list: { shiftId: string; shiftName: string; isDefault: boolean; fromName?: string }[] = [];
    if (regularShiftId && regularShiftId !== 'Off') {
      const sObj = shifts.find((s) => s.id === regularShiftId);
      list.push({
        shiftId: regularShiftId,
        shiftName: sObj?.name || 'Default Shift',
        isDefault: true,
      });
    }
    const illDoOnDate = adjustments.filter(
      (a) => a.date === date && a.action === "I'll Do" && a.id !== editingAdjustment?.id
    );
    illDoOnDate.forEach((adj) => {
      const sObj = shifts.find((s) => s.id === adj.shiftId);
      const pObj = persons.find((p) => p.id === adj.personId);
      const pName = adj.personName || pObj?.name || 'Colleague';
      if (adj.shiftId) {
        list.push({
          shiftId: adj.shiftId,
          shiftName: sObj?.name || 'Shift',
          isDefault: false,
          fromName: pName,
        });
      }
    });
    return list;
  }, [date, regularShiftId, shifts, adjustments, editingAdjustment, persons]);

  // Set default shifts when action or date changes
  useEffect(() => {
    if (editingAdjustment) return;

    if (action === "He'll Do") {
      // Defaults to the shift I was scheduled to work
      setShiftId(regularShiftId !== 'Off' ? regularShiftId : orderedShifts[0]?.id || '');
    } else if (action === "I'll Do") {
      // Default to morning or first shift
      if (!shiftId) setShiftId(orderedShifts[0]?.id || '');
    } else if (action === 'Shift Exchange') {
      // 1. My shift: user's scheduled shift (or first shift)
      const myScheduled = regularShiftId !== 'Off' ? regularShiftId : orderedShifts[0]?.id || '';
      setShiftId(myScheduled);

      // 2. Colleague's shift default (different from my shift)
      const other = orderedShifts.find((s) => s.id !== myScheduled) || orderedShifts[1] || orderedShifts[0];
      if (!colleagueShiftId) {
        setColleagueShiftId(other ? other.id : orderedShifts[0]?.id || '');
      }

      // 3. Exchange with shift default (the shift I will receive)
      if (!otherPersonShiftId) {
        setOtherPersonShiftId(other ? other.id : orderedShifts[0]?.id || '');
      }

      // Colleague & Exchange Person name defaults
      if (!colleagueName && persons.length > 0) {
        const firstColleague = persons.find((p) => !p.isOffice) || persons[0];
        setColleagueName(firstColleague.name);
        setColleaguePersonId(firstColleague.id);
        if (!exchangePersonName) {
          setExchangePersonName(firstColleague.name);
          setExchangePersonId(firstColleague.id);
        }
      }
    }
  }, [action, date, regularShiftId, orderedShifts, editingAdjustment, colleagueShiftId, otherPersonShiftId, colleagueName, exchangePersonName, persons]);

  // Set default person if none selected for I'll Do / He'll Do
  useEffect(() => {
    if (!personId && persons.length > 0) {
      const firstColleague = persons.find((p) => !p.isOffice) || persons[0];
      setPersonId(firstColleague.id);
    }
  }, [persons, personId]);

  // Filtered persons for searchable dropdown (I'll Do / He'll Do)
  const filteredPersons = useMemo(() => {
    if (!personSearch.trim()) return persons;
    const query = personSearch.toLowerCase();
    return persons.filter((p) => p.name.toLowerCase().includes(query));
  }, [persons, personSearch]);

  // Filtered persons for Colleague's Shift name box
  const filteredColleaguePersons = useMemo(() => {
    if (!colleagueName.trim()) return persons;
    const query = colleagueName.toLowerCase();
    return persons.filter((p) => p.name.toLowerCase().includes(query));
  }, [persons, colleagueName]);

  // Filtered persons for Exchange with Shift name box
  const filteredExchangePersons = useMemo(() => {
    if (!exchangePersonName.trim()) return persons;
    const query = exchangePersonName.toLowerCase();
    return persons.filter((p) => p.name.toLowerCase().includes(query));
  }, [persons, exchangePersonName]);

  const selectedPerson = persons.find((p) => p.id === personId);
  const selectedShift = shifts.find((s) => s.id === shiftId);
  const selectedOtherShift = shifts.find((s) => s.id === (otherPersonShiftId || colleagueShiftId));
  const selectedColleagueShift = shifts.find((s) => s.id === colleagueShiftId);

  // Run duty conflict analysis
  const proposedAnalysis = useMemo(() => {
    const effectiveShiftId = shiftId;
    const effectiveExchangeShift = otherPersonShiftId || colleagueShiftId;
    const effectivePersonId =
      action === 'Shift Exchange'
        ? colleaguePersonId || personId
        : personId;
    const effectivePersonName =
      action === 'Shift Exchange'
        ? colleagueName || selectedPerson?.name
        : selectedPerson?.name;
    const effectiveOtherPersonId =
      action === 'Shift Exchange'
        ? exchangePersonId || colleaguePersonId || personId
        : undefined;
    const effectiveOtherPersonName =
      action === 'Shift Exchange'
        ? exchangePersonName || colleagueName || selectedPerson?.name
        : undefined;

    return analyzeProposedAdjustment(
      {
        date,
        entryFrom,
        action,
        personId: action === 'No Duty' ? undefined : effectivePersonId,
        personName: action === 'Shift Exchange' ? effectivePersonName : undefined,
        shiftId: action === 'No Duty' ? undefined : effectiveShiftId,
        colleagueShiftId: action === 'Shift Exchange' ? colleagueShiftId || effectiveExchangeShift : undefined,
        otherPersonId: action === 'Shift Exchange' ? effectiveOtherPersonId : undefined,
        otherPersonName: action === 'Shift Exchange' ? effectiveOtherPersonName : undefined,
        otherPersonShiftId: action === 'Shift Exchange' ? effectiveExchangeShift : undefined,
        remarks,
      },
      adjustments,
      weeklyRoster,
      shifts,
      persons,
      editingAdjustment?.id
    );
  }, [
    date,
    entryFrom,
    action,
    personId,
    colleaguePersonId,
    colleagueName,
    exchangePersonId,
    exchangePersonName,
    shiftId,
    colleagueShiftId,
    otherPersonShiftId,
    remarks,
    adjustments,
    weeklyRoster,
    shifts,
    persons,
    selectedPerson,
    editingAdjustment,
  ]);

  const handleOpenConfirm = () => {
    setValidationError('');

    if (action === 'Shift Exchange') {
      const cName = colleagueName.trim() || selectedPerson?.name || '';
      const exName = exchangePersonName.trim() || cName;
      if (!cName && !exName && !personId) {
        setValidationError("Please enter or select a colleague name on Colleague's Shift.");
        return;
      }
      if (!shiftId) {
        setValidationError('Please select My Shift.');
        return;
      }
      if (!otherPersonShiftId && !colleagueShiftId) {
        setValidationError('Please select the Exchange with Shift.');
        return;
      }
      setShowConfirmModal(true);
      return;
    }

    if (action !== 'No Duty' && !personId) {
      setValidationError('Please select the person involved.');
      return;
    }

    if (action !== 'No Duty' && !shiftId) {
      setValidationError('Please select the shift.');
      return;
    }

    setShowConfirmModal(true);
  };

  const handleFinalSave = () => {
    if (proposedAnalysis.hasCriticalConflict && !overrideRedAlert) {
      setValidationError('You must explicitly acknowledge the RED ALERT before saving.');
      return;
    }

    if (action === 'Shift Exchange') {
      const cName = colleagueName.trim() || selectedPerson?.name || 'Colleague';
      const exName = exchangePersonName.trim() || cName;

      // Resolve colleague person ID
      let finalPersonId = colleaguePersonId;
      const matchedColleague = persons.find(
        (p) => p.id === colleaguePersonId || p.name.toLowerCase() === cName.toLowerCase()
      );
      if (matchedColleague) {
        finalPersonId = matchedColleague.id;
      } else if (cName) {
        addPerson(cName);
      }

      // Resolve exchange partner person ID
      let finalOtherId = exchangePersonId;
      const matchedExPerson = persons.find(
        (p) => p.id === exchangePersonId || p.name.toLowerCase() === exName.toLowerCase()
      );
      if (matchedExPerson) {
        finalOtherId = matchedExPerson.id;
      } else if (exName && exName !== cName) {
        addPerson(exName);
      } else if (!finalOtherId) {
        finalOtherId = finalPersonId;
      }

      const effectiveExchangedShift = otherPersonShiftId || colleagueShiftId;

      if (editingAdjustment) {
        updateAdjustment(editingAdjustment.id, {
          date,
          entryFrom,
          action,
          personId: finalPersonId,
          personName: cName,
          shiftId, // My Shift (scheduled / traded away)
          colleagueShiftId: colleagueShiftId || effectiveExchangedShift,
          otherPersonId: finalOtherId,
          otherPersonName: exName,
          otherPersonShiftId: effectiveExchangedShift, // Exchange with Shift (shift I will work)
          remarks,
        });
      } else {
        addAdjustment({
          date,
          entryFrom,
          action,
          personId: finalPersonId,
          personName: cName,
          shiftId, // My Shift (scheduled / traded away)
          colleagueShiftId: colleagueShiftId || effectiveExchangedShift,
          otherPersonId: finalOtherId,
          otherPersonName: exName,
          otherPersonShiftId: effectiveExchangedShift, // Exchange with Shift (shift I will work)
          remarks,
        });
      }

      setShowConfirmModal(false);
      onSuccess();
      return;
    }

    if (editingAdjustment) {
      updateAdjustment(editingAdjustment.id, {
        date,
        entryFrom,
        action,
        personId: action === 'No Duty' ? undefined : personId,
        shiftId: action === 'No Duty' ? undefined : shiftId,
        otherPersonShiftId: undefined,
        remarks,
      });
    } else {
      addAdjustment({
        date,
        entryFrom,
        action,
        personId: action === 'No Duty' ? undefined : personId,
        shiftId: action === 'No Duty' ? undefined : shiftId,
        otherPersonShiftId: undefined,
        remarks,
      });
    }

    setShowConfirmModal(false);
    onSuccess();
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-24">
      {validationError && (
        <div className="bg-red-50 border border-red-200 text-red-800 p-4 rounded-xl text-xs font-semibold flex items-center gap-2">
          <AlertOctagon className="w-4 h-4 text-red-600 shrink-0" />
          <span>{validationError}</span>
        </div>
      )}

      {/* Main Form Card */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5">
        {/* Duty Date */}
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-blue-900" />
            <span>Duty Date</span>
          </label>
          <div className="relative">
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900 transition-all font-mono"
            />
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">
            Duty Day: {getDayOfWeekFromDateString(date)} · Regular Roster:{' '}
            <strong className="text-blue-900">
              {regularShiftId === 'Off'
                ? 'Off'
                : shifts.find((s) => s.id === regularShiftId)?.name || regularShiftId}
            </strong>
          </span>
        </div>

        {/* Row 2: SMART ACTION SELECTOR */}
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
            Smart Action Selector
          </label>
          <div className="grid grid-cols-3 gap-2">
            {(["I'll Do", "He'll Do", "Shift Exchange"] as AdjustmentAction[]).map(
              (act) => {
                const isSelected = action === act;
                let activeStyle = '';
                if (act === "I'll Do") {
                  activeStyle = isSelected
                    ? 'bg-emerald-800 text-white border-emerald-800 ring-2 ring-emerald-600/30'
                    : 'bg-emerald-50 text-emerald-950 border-emerald-200 hover:bg-emerald-100';
                } else if (act === "He'll Do") {
                  activeStyle = isSelected
                    ? 'bg-red-800 text-white border-red-800 ring-2 ring-red-600/30'
                    : 'bg-red-50 text-red-950 border-red-200 hover:bg-red-100';
                } else {
                  activeStyle = isSelected
                    ? 'bg-amber-600 text-white border-amber-600 ring-2 ring-amber-500/30'
                    : 'bg-amber-50 text-amber-950 border-amber-200 hover:bg-amber-100';
                }

                return (
                  <button
                    key={act}
                    type="button"
                    onClick={() => setAction(act)}
                    className={`w-full py-2.5 px-2 rounded-xl border text-xs font-bold transition-all text-center flex flex-col items-center justify-center gap-0.5 ${activeStyle} cursor-pointer`}
                  >
                    <span>{act}</span>
                    <span className="text-[10px] font-normal opacity-90 block">
                      {act === "I'll Do" && 'Take duty'}
                      {act === "He'll Do" && 'Give my duty'}
                      {act === 'Shift Exchange' && 'Mutual swap'}
                    </span>
                  </button>
                );
              }
            )}
          </div>
        </div>

        {/* Dynamic Fields for Actions */}
        {action !== 'No Duty' && (
          action === 'Shift Exchange' ? (
            /* SHIFT EXCHANGE: Hide marking part, show 3 options: My Shift, Colleague's Shift, Exchange with Shift */
            <div className="space-y-4">
              {/* OPTION 1: My Shift */}
              <div className="bg-slate-50/90 p-4 rounded-2xl border border-slate-200/90 shadow-2xs space-y-2.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-blue-900 text-white text-[10px] font-black flex items-center justify-center shrink-0">
                      1
                    </span>
                    <span>My Shift</span>
                  </label>
                  <span className="text-[10px] text-slate-500 font-medium">
                    Shift Being Traded Away
                  </span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Select which of your shifts you are giving up / trading away:
                </p>
                <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
                  {orderedShifts.map((s) => {
                    const isSel = shiftId === s.id;
                    const style = getShiftStyle(s.name || s.id);
                    const heldItem = heldOnDate.find((h) => h.shiftId === s.id);
                    return (
                      <button
                        key={s.id}
                        type="button"
                        onClick={() => setShiftId(s.id)}
                        className={`py-2 px-2 sm:py-2.5 sm:px-3 rounded-xl border text-center transition-all flex flex-col items-center justify-center gap-1 min-w-0 cursor-pointer ${
                          isSel ? style.activeCard : style.inactiveCard
                        }`}
                      >
                        <div className="flex items-center gap-1.5">
                          {style.icon}
                          <span className="font-bold text-xs sm:text-sm truncate">{s.name}</span>
                        </div>
                        {heldItem && (
                          <span className="text-[8px] font-bold px-1 py-0.2 rounded bg-white/90 text-blue-900 border border-blue-200/80">
                            {heldItem.isDefault ? 'Default' : `From ${heldItem.fromName || 'Taken'}`}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
                {shiftId && (
                  <div className="text-[10px] sm:text-[11px] p-2 rounded-xl bg-blue-50/80 border border-blue-200/80 text-blue-950 font-medium leading-snug">
                    {shiftId === regularShiftId ? (
                      <span>
                        • Trading your <strong>default scheduled shift ({shifts.find((s) => s.id === shiftId)?.name})</strong>. The exchanged shift will replace it on Today's Duty Box.
                      </span>
                    ) : (
                      <span>
                        • Trading your <strong>taken shift ({shifts.find((s) => s.id === shiftId)?.name})</strong>. Your default <strong>{shifts.find((s) => s.id === regularShiftId)?.name || 'scheduled'}</strong> shift remains, resulting in <strong>Double Duty</strong> on Today's Duty Box.
                      </span>
                    )}
                  </div>
                )}
              </div>

              {/* OPTION 2: Colleague's Shift (with Name Box) */}
              <div className="bg-slate-50/90 p-4 rounded-2xl border border-slate-200/90 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-blue-900 text-white text-[10px] font-black flex items-center justify-center shrink-0">
                      2
                    </span>
                    <span>Colleague's Shift</span>
                  </label>
                  <span className="text-[10px] text-slate-500 font-medium">
                    Colleague & current shift
                  </span>
                </div>

                {/* Name Box on Colleague's Shift */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-blue-900" />
                      <span>Colleague Name</span>
                    </div>
                    <span className="text-[10px] text-slate-400 font-normal">Select or type</span>
                  </label>

                  {/* Quick frequent pills */}
                  <div className="flex flex-wrap items-center gap-1.5 mb-1">
                    <span className="text-[10px] text-slate-400 font-medium mr-1 flex items-center gap-0.5">
                      <Sparkles className="w-3 h-3 text-amber-500" /> Quick:
                    </span>
                    {frequentNames.slice(0, 4).map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => {
                          setColleagueName(p.name);
                          setColleaguePersonId(p.id);
                          setIsColleagueDropdownOpen(false);
                          if (!exchangePersonName) {
                            setExchangePersonName(p.name);
                            setExchangePersonId(p.id);
                          }
                        }}
                        className={`px-2 py-0.5 text-[11px] rounded-lg font-medium transition-colors cursor-pointer ${
                          colleaguePersonId === p.id || colleagueName === p.name
                            ? 'bg-blue-900 text-white font-semibold'
                            : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {p.name}
                      </button>
                    ))}
                  </div>

                  {/* Name Input Box & Dropdown */}
                  <div className="relative">
                    <div className="relative flex items-center">
                      <input
                        type="text"
                        value={colleagueName}
                        onChange={(e) => {
                          setColleagueName(e.target.value);
                          setIsColleagueDropdownOpen(true);
                          const matched = persons.find(
                            (p) => p.name.toLowerCase() === e.target.value.toLowerCase()
                          );
                          setColleaguePersonId(matched ? matched.id : '');
                        }}
                        onFocus={() => setIsColleagueDropdownOpen(true)}
                        placeholder="Type or select colleague name..."
                        className="w-full pl-3.5 pr-8 py-2.5 text-sm bg-white border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900 transition-all font-medium text-slate-900"
                      />
                      {colleagueName ? (
                        <button
                          type="button"
                          onClick={() => {
                            setColleagueName('');
                            setColleaguePersonId('');
                          }}
                          className="absolute right-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      ) : (
                        <Search className="w-4 h-4 text-slate-400 absolute right-3 pointer-events-none" />
                      )}
                    </div>

                    {isColleagueDropdownOpen && (
                      <div
                        className="absolute top-full left-0 right-0 mt-1 z-30 bg-white border border-slate-200 rounded-xl shadow-lg max-h-48 overflow-y-auto overscroll-contain p-1.5 custom-scrollbar"
                        style={{ overscrollBehavior: 'contain' }}
                      >
                        <div className="space-y-0.5">
                          {filteredColleaguePersons.slice(0, 8).map((p) => (
                            <div
                              key={p.id}
                              onClick={() => {
                                setColleagueName(p.name);
                                setColleaguePersonId(p.id);
                                setIsColleagueDropdownOpen(false);
                                if (!exchangePersonName) {
                                  setExchangePersonName(p.name);
                                  setExchangePersonId(p.id);
                                }
                              }}
                              className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer flex items-center justify-between ${
                                colleaguePersonId === p.id
                                  ? 'bg-blue-50 text-blue-900 font-bold'
                                  : 'hover:bg-slate-100 text-slate-700'
                              }`}
                            >
                              <span>{p.name}</span>
                              {p.isOffice && (
                                <span className="text-[10px] bg-blue-100 text-blue-900 px-1.5 py-0.2 rounded font-semibold">
                                  Office Protected
                                </span>
                              )}
                            </div>
                          ))}
                          {filteredColleaguePersons.length === 0 && (
                            <div
                              onClick={() => setIsColleagueDropdownOpen(false)}
                              className="px-3 py-2 text-xs text-blue-900 font-semibold cursor-pointer hover:bg-blue-50 rounded-lg"
                            >
                              + Use "{colleagueName}"
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Shift Selector for Colleague's Shift */}
                <div className="pt-1">
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    Colleague's Current Shift:
                  </label>
                  <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
                    {orderedShifts.map((s) => {
                      const isSel = colleagueShiftId === s.id;
                      const style = getShiftStyle(s.name || s.id);
                      return (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => {
                            setColleagueShiftId(s.id);
                            if (!otherPersonShiftId || otherPersonShiftId === colleagueShiftId) {
                              setOtherPersonShiftId(s.id);
                            }
                          }}
                          className={`py-2 px-2 sm:py-2.5 sm:px-3 rounded-xl border text-center transition-all flex items-center justify-center gap-1.5 min-w-0 cursor-pointer ${
                            isSel ? style.activeCard : style.inactiveCard
                          }`}
                        >
                          {style.icon}
                          <span className="font-bold text-xs sm:text-sm truncate">{s.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* OPTION 3: Exchange with Shift (with Name Box) */}
              <div className="bg-amber-50/40 p-4 rounded-2xl border border-amber-300/90 shadow-2xs space-y-3 ring-1 ring-amber-400/20">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-black text-amber-950 uppercase tracking-wider flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-amber-600 text-white text-[10px] font-black flex items-center justify-center shrink-0">
                      3
                    </span>
                    <span>Exchange with Shift</span>
                  </label>
                  <span className="text-[9.5px] font-bold text-amber-900 bg-amber-100 border border-amber-300 px-2 py-0.5 rounded-full">
                    Shift You Will Work
                  </span>
                </div>

                {/* Name Box on Exchange with Shift */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <ArrowRightLeft className="w-3.5 h-3.5 text-amber-700" />
                      <span>Exchange Partner Name</span>
                    </div>
                    <span className="text-[10px] text-slate-400 font-normal">Select or type</span>
                  </label>

                  {/* Quick frequent pills */}
                  <div className="flex flex-wrap items-center gap-1.5 mb-1">
                    <span className="text-[10px] text-slate-400 font-medium mr-1 flex items-center gap-0.5">
                      <Sparkles className="w-3 h-3 text-amber-500" /> Quick:
                    </span>
                    {frequentNames.slice(0, 4).map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => {
                          setExchangePersonName(p.name);
                          setExchangePersonId(p.id);
                          setIsExchangePersonDropdownOpen(false);
                        }}
                        className={`px-2 py-0.5 text-[11px] rounded-lg font-medium transition-colors cursor-pointer ${
                          exchangePersonId === p.id || exchangePersonName === p.name
                            ? 'bg-amber-600 text-white font-semibold'
                            : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {p.name}
                      </button>
                    ))}
                  </div>

                  {/* Name Input Box & Dropdown */}
                  <div className="relative">
                    <div className="relative flex items-center">
                      <input
                        type="text"
                        value={exchangePersonName}
                        onChange={(e) => {
                          setExchangePersonName(e.target.value);
                          setIsExchangePersonDropdownOpen(true);
                          const matched = persons.find(
                            (p) => p.name.toLowerCase() === e.target.value.toLowerCase()
                          );
                          setExchangePersonId(matched ? matched.id : '');
                        }}
                        onFocus={() => setIsExchangePersonDropdownOpen(true)}
                        placeholder="Type or select exchange person..."
                        className="w-full pl-3.5 pr-8 py-2.5 text-sm bg-white border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-600 transition-all font-medium text-slate-900"
                      />
                      {exchangePersonName ? (
                        <button
                          type="button"
                          onClick={() => {
                            setExchangePersonName('');
                            setExchangePersonId('');
                          }}
                          className="absolute right-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      ) : (
                        <Search className="w-4 h-4 text-slate-400 absolute right-3 pointer-events-none" />
                      )}
                    </div>

                    {isExchangePersonDropdownOpen && (
                      <div
                        className="absolute top-full left-0 right-0 mt-1 z-30 bg-white border border-slate-200 rounded-xl shadow-lg max-h-48 overflow-y-auto overscroll-contain p-1.5 custom-scrollbar"
                        style={{ overscrollBehavior: 'contain' }}
                      >
                        <div className="space-y-0.5">
                          {filteredExchangePersons.slice(0, 8).map((p) => (
                            <div
                              key={p.id}
                              onClick={() => {
                                setExchangePersonName(p.name);
                                setExchangePersonId(p.id);
                                setIsExchangePersonDropdownOpen(false);
                              }}
                              className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer flex items-center justify-between ${
                                exchangePersonId === p.id
                                  ? 'bg-amber-50 text-amber-900 font-bold'
                                  : 'hover:bg-slate-100 text-slate-700'
                              }`}
                            >
                              <span>{p.name}</span>
                              {p.isOffice && (
                                <span className="text-[10px] bg-blue-100 text-blue-900 px-1.5 py-0.2 rounded font-semibold">
                                  Office Protected
                                </span>
                              )}
                            </div>
                          ))}
                          {filteredExchangePersons.length === 0 && (
                            <div
                              onClick={() => setIsExchangePersonDropdownOpen(false)}
                              className="px-3 py-2 text-xs text-amber-900 font-semibold cursor-pointer hover:bg-amber-50 rounded-lg"
                            >
                              + Use "{exchangePersonName}"
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Shift Selector for Exchange with Shift */}
                <div className="pt-1">
                  <label className="block text-[11px] font-bold text-amber-900 mb-1">
                    Shift to Work (The shift you will perform from this exchange):
                  </label>
                  <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
                    {orderedShifts.map((s) => {
                      const isSel = otherPersonShiftId === s.id;
                      const style = getShiftStyle(s.name || s.id);
                      return (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => setOtherPersonShiftId(s.id)}
                          className={`py-2 px-2 sm:py-2.5 sm:px-3 rounded-xl border text-center transition-all flex items-center justify-center gap-1.5 min-w-0 cursor-pointer ${
                            isSel ? style.activeCard : style.inactiveCard
                          }`}
                        >
                          {style.icon}
                          <span className="font-bold text-xs sm:text-sm truncate">{s.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* LIVE OUTCOME PREVIEW */}
              <div className="bg-gradient-to-r from-blue-50/90 via-indigo-50/70 to-slate-50/90 p-3.5 rounded-2xl border border-blue-200/90 shadow-2xs space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase tracking-wider text-blue-950 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    <span>Today's Duty Box Outcome (Live Preview)</span>
                  </span>
                  <span className="text-[9px] font-bold text-blue-900 bg-white/80 px-1.5 py-0.2 rounded border border-blue-200">
                    Calculated Result
                  </span>
                </div>
                <div className="text-xs sm:text-sm font-bold text-slate-900 pt-0.5">
                  {(() => {
                    const myTradedName = shifts.find((s) => s.id === shiftId)?.name || 'Shift';
                    const receivedName = shifts.find((s) => s.id === (otherPersonShiftId || colleagueShiftId))?.name || 'Shift';
                    const cName = colleagueName.trim() || 'Colleague';
                    const defaultName = shifts.find((s) => s.id === regularShiftId)?.name || '';

                    if (shiftId === regularShiftId || regularShiftId === 'Off') {
                      return (
                        <div className="space-y-0.5">
                          <div className="text-blue-950 flex items-center gap-1.5 flex-wrap">
                            <span>👉 Today's Duty will show:</span>
                            <span className="text-emerald-700 font-black text-sm px-1.5 py-0.5 bg-emerald-50 rounded border border-emerald-200">
                              {receivedName}
                            </span>
                          </div>
                          <div className="text-[10.5px] text-slate-500 font-normal">
                            (Your default {myTradedName} is exchanged with {cName})
                          </div>
                        </div>
                      );
                    } else {
                      return (
                        <div className="space-y-0.5">
                          <div className="text-blue-950 flex items-center gap-1.5 flex-wrap">
                            <span>👉 Today's Duty will show:</span>
                            <span className="text-blue-900 font-black text-sm px-1.5 py-0.5 bg-blue-50 rounded border border-blue-200">
                              {defaultName}
                            </span>
                            <span className="text-slate-400 font-normal">&</span>
                            <span className="text-emerald-700 font-black text-sm px-1.5 py-0.5 bg-emerald-50 rounded border border-emerald-200">
                              {receivedName}
                            </span>
                          </div>
                          <div className="text-[10.5px] text-amber-900 font-semibold">
                            (Double Duty: Default {defaultName} retained + {receivedName} from exchange with {cName})
                          </div>
                        </div>
                      );
                    }
                  })()}
                </div>
              </div>
            </div>
          ) : (
            /* NON-EXCHANGE (I'll Do & He'll Do): Normal Person Selector & Shift Selector */
            <div className="bg-slate-50/80 p-4 rounded-2xl border border-slate-200/80 space-y-4">
              {/* Person Selector */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-blue-900" />
                    <span>
                      {action === "I'll Do" && "Whose Duty? (Colleague)"}
                      {action === "He'll Do" && "Who Will Do My Duty?"}
                    </span>
                  </label>
                  <span className="text-[11px] text-slate-500">From Master Names</span>
                </div>

                {/* Quick suggestions pills */}
                <div className="flex flex-wrap items-center gap-1.5 mb-2">
                  <span className="text-[11px] text-slate-400 font-medium mr-1 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-amber-500" /> Frequent:
                  </span>
                  {frequentNames.slice(0, 4).map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => {
                        setPersonId(p.id);
                        setIsPersonDropdownOpen(false);
                      }}
                      className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-colors ${
                        personId === p.id
                          ? 'bg-blue-900 text-white font-semibold'
                          : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {p.name}
                      {p.isOffice && ' ★'}
                    </button>
                  ))}
                </div>

                {/* Searchable Dropdown */}
                <div className="relative">
                  <div
                    onClick={() => setIsPersonDropdownOpen(!isPersonDropdownOpen)}
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-200 rounded-xl cursor-pointer flex items-center justify-between"
                  >
                    <span className="font-medium text-slate-900">
                      {selectedPerson ? (
                        <span className="flex items-center gap-1.5">
                          <span>{selectedPerson.name}</span>
                          {selectedPerson.isOffice && (
                            <span className="text-[10px] bg-blue-100 text-blue-900 px-1.5 py-0.2 rounded font-bold">
                              Office Protected
                            </span>
                          )}
                        </span>
                      ) : (
                        <span className="text-slate-400">Select person...</span>
                      )}
                    </span>
                    <Search className="w-4 h-4 text-slate-400" />
                  </div>

                  {isPersonDropdownOpen && (
                    <div
                      className="absolute top-full left-0 right-0 mt-1 z-20 bg-white border border-slate-200 rounded-xl shadow-lg max-h-56 overflow-y-auto overscroll-contain p-2 custom-scrollbar"
                      style={{ overscrollBehavior: 'contain' }}
                    >
                      <input
                        type="text"
                        placeholder="Search colleague name..."
                        value={personSearch}
                        onChange={(e) => setPersonSearch(e.target.value)}
                        className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg mb-2 focus:outline-none focus:ring-1 focus:ring-blue-900"
                        autoFocus
                      />
                      <div className="space-y-1">
                        {filteredPersons.map((p) => (
                          <div
                            key={p.id}
                            onClick={() => {
                              setPersonId(p.id);
                              setIsPersonDropdownOpen(false);
                              setPersonSearch('');
                            }}
                            className={`px-3 py-2 rounded-lg text-xs font-medium cursor-pointer flex items-center justify-between ${
                              personId === p.id
                                ? 'bg-blue-50 text-blue-900 font-bold'
                                : 'hover:bg-slate-100 text-slate-700'
                            }`}
                          >
                            <span>{p.name}</span>
                            {p.isOffice && (
                              <span className="text-[10px] bg-blue-100 text-blue-900 px-1.5 py-0.2 rounded font-semibold">
                                Special Entity
                              </span>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Single Shift Selector for I'll Do / He'll Do */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-blue-900" />
                    <span>
                      {action === "I'll Do" ? "Colleague's Shift Being Taken" : 'My Shift Being Relieved'}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-normal">Visible by Morning, Afternoon, Night</span>
                </label>
                <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
                  {orderedShifts.map((s) => {
                    const isSel = shiftId === s.id;
                    const style = getShiftStyle(s.name || s.id);
                    return (
                      <button
                        key={s.id}
                        type="button"
                        onClick={() => setShiftId(s.id)}
                        className={`py-2 px-2 sm:py-2.5 sm:px-3 rounded-xl border text-center transition-all flex items-center justify-center gap-1.5 min-w-0 cursor-pointer ${
                          isSel ? style.activeCard : style.inactiveCard
                        }`}
                      >
                        {style.icon}
                        <span className="font-bold text-xs sm:text-sm truncate">{s.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )
        )}

        {/* Remarks Section */}
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-blue-900" />
            <span>Remarks & Justification</span>
          </label>

          {/* Quick preset chips */}
          <div className="flex flex-wrap gap-1.5 mb-2">
            {COMMON_REASONS.map((reason) => (
              <button
                key={reason}
                type="button"
                onClick={() => setRemarks((prev) => (prev ? `${prev}; ${reason}` : reason))}
                className="text-[11px] px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors"
              >
                + {reason}
              </button>
            ))}
          </div>

          <textarea
            rows={3}
            value={remarks}
            onChange={(e) => setRemarks(e.target.value)}
            placeholder="Enter reason, emergency note, mutual approval details, or official sanction reference..."
            className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900 transition-all"
          ></textarea>
        </div>

        {/* LIVE DUTY CONFLICT & SAFETY PREVIEW */}
        <div className="pt-3 border-t border-slate-200">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4 text-blue-900" />
              <span>Smart Duty Conflict Analysis</span>
            </span>
            <span className="text-[11px] text-slate-500">Evaluated in Real-Time</span>
          </div>

          {/* Projected Final Shift summary */}
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs mb-3">
            <span className="text-slate-500">Projected Duties for {date}:</span>
            <div className="font-bold text-slate-900 mt-0.5">
              {proposedAnalysis.projectedShifts.length === 0 ? (
                <span className="text-purple-700">No active duty shifts (Rest / Off)</span>
              ) : (
                proposedAnalysis.projectedShifts.map((s, idx) => (
                  <span key={idx} className="mr-2 inline-block">
                    {s.shiftName} ({s.timing})
                  </span>
                ))
              )}
            </div>
          </div>

          {/* Warnings list */}
          {proposedAnalysis.warnings.length > 0 && (
            <div className="space-y-2">
              {proposedAnalysis.warnings.map((w, idx) => (
                <div
                  key={idx}
                  className={`p-3.5 rounded-xl border text-xs ${
                    w.severity === 'critical'
                      ? 'bg-red-50 border-red-300 text-red-950 ring-1 ring-red-400'
                      : w.severity === 'warning'
                      ? 'bg-amber-50 border-amber-300 text-amber-950'
                      : 'bg-emerald-50 border-emerald-300 text-emerald-950'
                  }`}
                >
                  <div className="flex items-start gap-2">
                    {w.severity === 'critical' ? (
                      <AlertOctagon className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                    ) : w.severity === 'warning' ? (
                      <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                    ) : (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                    )}
                    <div>
                      <div className="font-bold text-sm">{w.title}</div>
                      <div className="mt-1">{w.message}</div>
                      {w.details && (
                        <ul className="mt-1.5 list-disc list-inside space-y-0.5 text-[11px] opacity-90">
                          {w.details.map((d, dIdx) => (
                            <li key={dIdx}>{d}</li>
                          ))}
                        </ul>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="pt-4 flex items-center justify-end gap-2.5 border-t border-slate-200">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleOpenConfirm}
            className={`px-5 py-2.5 text-xs font-bold rounded-xl shadow-md transition-all flex items-center gap-2 ${
              proposedAnalysis.hasCriticalConflict
                ? 'bg-red-600 hover:bg-red-700 text-white shadow-red-600/20'
                : proposedAnalysis.warnings.some((w) => w.severity === 'warning')
                ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-amber-500/20'
                : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/20'
            }`}
          >
            {proposedAnalysis.hasCriticalConflict ? (
              <AlertOctagon className="w-4 h-4" />
            ) : proposedAnalysis.warnings.some((w) => w.severity === 'warning') ? (
              <AlertTriangle className="w-4 h-4" />
            ) : (
              <CheckCircle2 className="w-4 h-4" />
            )}
            <span>
              {proposedAnalysis.hasCriticalConflict
                ? 'Review & Save (Red Alert)'
                : proposedAnalysis.warnings.some((w) => w.severity === 'warning')
                ? 'Review & Save (Warning)'
                : 'Review & Save Adjustment'}
            </span>
          </button>
        </div>
      </div>

      {/* CONFIRMATION SUMMARY MODAL (Section 37) */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overscroll-contain">
          <div
            className="bg-white rounded-2xl max-w-lg w-full p-5 sm:p-6 shadow-2xl border border-slate-200 space-y-4 max-h-[90vh] overflow-y-auto overscroll-contain my-auto custom-scrollbar"
            style={{ overscrollBehavior: 'contain' }}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h2 className="text-base font-bold text-slate-900">
                Duty Adjustment Summary
              </h2>
              <button
                onClick={() => setShowConfirmModal(false)}
                className="text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Summary Data Grid */}
            <div className="bg-slate-50 rounded-xl p-4 space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500 font-medium">Date:</span>
                <span className="font-bold text-slate-900">{date} ({getDayOfWeekFromDateString(date)})</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500 font-medium">Action:</span>
                <span className="font-bold text-blue-900">{action}</span>
              </div>
              {action === 'Shift Exchange' ? (
                <>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500 font-medium">1. My Shift:</span>
                    <span className="font-bold text-slate-900">{selectedShift?.name || '—'}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500 font-medium">2. Colleague's Shift:</span>
                    <span className="font-bold text-slate-900">
                      {selectedColleagueShift?.name || '—'} · {colleagueName || 'Colleague'}
                    </span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500 font-medium">3. Exchange with Shift:</span>
                    <span className="font-bold text-amber-900">
                      {selectedOtherShift?.name || '—'} · {exchangePersonName || colleagueName || 'Partner'}
                    </span>
                  </div>
                </>
              ) : action !== 'No Duty' ? (
                <>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500 font-medium">Person:</span>
                    <span className="font-bold text-slate-900">{selectedPerson?.name || '—'}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500 font-medium">Duty Shift:</span>
                    <span className="font-bold text-slate-900">
                      {selectedShift ? `${selectedShift.name} (${selectedShift.startTime} – ${selectedShift.endTime})` : '—'}
                    </span>
                  </div>
                </>
              ) : null}
              <div className="flex justify-between py-1">
                <span className="text-slate-500 font-medium">Remarks:</span>
                <span className="font-medium text-slate-700 italic max-w-[240px] text-right truncate">
                  {remarks || 'None'}
                </span>
              </div>
            </div>

            {/* Assessment Status Badge */}
            <div className="p-3.5 rounded-xl border text-xs">
              {proposedAnalysis.hasCriticalConflict ? (
                <div className="text-red-900 bg-red-50 border border-red-200 p-3.5 rounded-lg space-y-1.5">
                  <div className="font-bold flex items-center gap-1.5 text-sm">
                    <AlertOctagon className="w-4 h-4 text-red-600 shrink-0" />
                    <span>
                      {proposedAnalysis.warnings.find((w) => w.severity === 'critical')?.title ||
                        '🔴 Not Acceptable — Critical Schedule Conflict'}
                    </span>
                  </div>
                  <p className="text-slate-800 text-xs font-medium">
                    {proposedAnalysis.warnings.find((w) => w.severity === 'critical')?.message ||
                      'This adjustment violates schedule safety limits.'}
                  </p>
                  {proposedAnalysis.warnings.find((w) => w.severity === 'critical')?.details && (
                    <ul className="list-disc list-inside space-y-0.5 text-[11px] text-slate-700 pt-1 border-t border-red-200/60">
                      {proposedAnalysis.warnings
                        .find((w) => w.severity === 'critical')
                        ?.details?.map((d, dIdx) => (
                          <li key={dIdx}>{d}</li>
                        ))}
                    </ul>
                  )}
                </div>
              ) : proposedAnalysis.warnings.some((w) => w.severity === 'warning') ? (
                <div className="text-amber-900 bg-amber-50 border border-amber-200 p-3 rounded-lg">
                  <div className="font-bold flex items-center gap-1.5 text-sm">
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    <span>🟡 Fatigue Warning Acknowledged</span>
                  </div>
                  <p className="mt-1 text-slate-700">
                    Consecutive Night-to-Morning transition detected. Please ensure sufficient rest is scheduled.
                  </p>
                </div>
              ) : (
                <div className="text-emerald-900 bg-emerald-50 border border-emerald-200 p-3 rounded-lg">
                  <div className="font-bold flex items-center gap-1.5 text-sm">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>🟢 Acceptable Duty Adjustment</span>
                  </div>
                  <p className="mt-1 text-slate-700">
                    Adjustment conforms with standard roster parameters and shift transition safety limits.
                  </p>
                </div>
              )}
            </div>

            {/* Explicit Override checkbox if Red Alert exists */}
            {proposedAnalysis.hasCriticalConflict && (
              <label className="flex items-start gap-2.5 p-3 bg-red-100/70 border border-red-300 rounded-xl cursor-pointer">
                <input
                  type="checkbox"
                  checked={overrideRedAlert}
                  onChange={(e) => setOverrideRedAlert(e.target.checked)}
                  className="mt-0.5 rounded border-red-400 text-red-700 focus:ring-red-600"
                />
                <span className="text-xs font-bold text-red-950">
                  I explicitly acknowledge the Critical RED ALERT conflict (
                  {proposedAnalysis.warnings.find((w) => w.severity === 'critical')?.title ||
                    'Schedule Clash'}
                  ) and authorize this override entry under administrative authority.
                </span>
              </label>
            )}

            {/* Modal Buttons */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleFinalSave}
                disabled={proposedAnalysis.hasCriticalConflict && !overrideRedAlert}
                className={`px-5 py-2 text-xs font-bold text-white rounded-xl shadow-sm transition-all flex items-center gap-1.5 ${
                  proposedAnalysis.hasCriticalConflict && !overrideRedAlert
                    ? 'bg-slate-400 cursor-not-allowed'
                    : proposedAnalysis.hasCriticalConflict
                    ? 'bg-red-600 hover:bg-red-700 shadow-red-600/20'
                    : proposedAnalysis.warnings.some((w) => w.severity === 'warning')
                    ? 'bg-amber-500 hover:bg-amber-600 shadow-amber-500/20'
                    : 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/20'
                }`}
              >
                {proposedAnalysis.hasCriticalConflict ? (
                  <AlertOctagon className="w-3.5 h-3.5" />
                ) : proposedAnalysis.warnings.some((w) => w.severity === 'warning') ? (
                  <AlertTriangle className="w-3.5 h-3.5" />
                ) : (
                  <CheckCircle2 className="w-3.5 h-3.5" />
                )}
                <span>Confirm & Save</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
