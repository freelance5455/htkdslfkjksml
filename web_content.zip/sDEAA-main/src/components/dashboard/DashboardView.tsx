import React, { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  ArrowRightLeft,
  UserCheck,
  UserX,
  PlusCircle,
  AlertOctagon,
  Info,
  Sparkles,
} from 'lucide-react';
import { useDuty } from '../../context/DutyContext';
import { formatDateToISO, addDays } from '../../utils/dutyEngine';
import { getShiftStyle, ShiftBadge } from '../../utils/shiftHelper';
import { DayDutyState, DutyAdjustment } from '../../types/duty';

interface DashboardViewProps {
  onNavigateToEntry: (date?: string) => void;
  onNavigateToCalendar: () => void;
  onNavigateToHistory: (filter?: string) => void;
  onNavigateToExport: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onNavigateToEntry,
  onNavigateToCalendar,
  onNavigateToHistory,
  onNavigateToExport,
}) => {
  const {
    userName,
    employeeId,
    adjustments,
    persons,
    shifts,
    getDayDuty,
    dashboardFont,
    addAdjustment,
    addPerson,
  } = useDuty();

  const [toastMessage, setToastMessage] = useState<string>('');

  const getFontClass = () => {
    switch (dashboardFont) {
      case 'script':
        return 'font-reference-script tracking-wide';
      case 'brush':
        return 'font-reference-brush tracking-wide';
      case 'serif':
        return 'font-reference-serif italic tracking-normal';
      case 'sans':
      default:
        return 'font-black tracking-tight';
    }
  };

  const todayStr = formatDateToISO(new Date());
  const tomorrowStr = addDays(todayStr, 1);
  const dayAfterTomorrowStr = addDays(todayStr, 2);

  const displayedDuties = React.useMemo(() => {
    return [
      { title: "Today's Duty", date: todayStr, isToday: true, dutyState: getDayDuty(todayStr) },
      { title: "Tomorrow's Duty", date: tomorrowStr, isToday: false, dutyState: getDayDuty(tomorrowStr) },
      { title: "Day After Tomorrow", date: dayAfterTomorrowStr, isToday: false, dutyState: getDayDuty(dayAfterTomorrowStr) },
    ];
  }, [todayStr, tomorrowStr, dayAfterTomorrowStr, getDayDuty]);

  // Summary counts
  const pendingCount = adjustments.filter((a) => a.status === 'Pending').length;
  const completedCount = adjustments.filter((a) => a.status === 'Completed').length;
  const totalExchanges = adjustments.filter((a) => a.action === 'Shift Exchange').length;

  // Active warnings across the displayed 3 days
  const activeWarningsCount = displayedDuties
    .flatMap((d) => d.dutyState.warnings)
    .filter((w) => w.severity === 'critical' || w.severity === 'warning').length;

  const renderDutyCard = (
    title: string,
    dutyState: DayDutyState,
    isToday: boolean = false
  ) => {
    const hasAdjustments = dutyState.adjustments.length > 0;
    const isNoDuty = dutyState.isNoDuty;
    const finalCount = dutyState.finalShifts.length;

    // Determine headline description
    let dutyHeadline = 'Regular Duty';
    let headlineIcon = <Clock className="w-3.5 h-3.5 text-blue-900" />;
    let badgeBg = 'bg-blue-50 text-blue-900 border-blue-200';

    if (finalCount >= 2) {
      dutyHeadline = '2 Duties (Double Shift)';
      headlineIcon = <Sparkles className="w-3.5 h-3.5 text-blue-900" />;
      badgeBg = 'bg-blue-50 text-blue-900 border-blue-200';
    } else if (isNoDuty) {
      dutyHeadline = 'No Duty (Off)';
      headlineIcon = <UserX className="w-3.5 h-3.5 text-purple-700" />;
      badgeBg = 'bg-purple-50 text-purple-900 border-purple-200';
    } else if (dutyState.indicators.hasSomeoneDoingMyDuty) {
      dutyHeadline = 'Relieved (Covered)';
      headlineIcon = <UserCheck className="w-3.5 h-3.5 text-red-600" />;
      badgeBg = 'bg-red-50 text-red-900 border-red-200';
    } else if (dutyState.indicators.hasShiftExchange) {
      dutyHeadline = 'Shift Exchange';
      headlineIcon = <ArrowRightLeft className="w-3.5 h-3.5 text-amber-600" />;
      badgeBg = 'bg-amber-50 text-amber-900 border-amber-200';
    } else if (dutyState.indicators.hasIAmDoingSomeoneDuty) {
      dutyHeadline = "Covering (I'll Do)";
      headlineIcon = <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />;
      badgeBg = 'bg-emerald-50 text-emerald-900 border-emerald-200';
    }

    return (
      <div
        className={`bg-white rounded-xl p-2 sm:p-2.5 border transition-all flex flex-col min-h-[195px] sm:min-h-[205px] overflow-hidden ${
          isToday
            ? 'border-blue-900/60 shadow-xs ring-1 ring-blue-900/15 bg-gradient-to-b from-blue-50/20 to-white'
            : 'border-slate-300 shadow-xs hover:border-blue-900/40 bg-gradient-to-b from-slate-50/30 to-white'
        }`}
      >
        {/* Top Header: Badge, Date, Font Switcher & Compact Adjust Button */}
        <div className="shrink-0 pb-1 border-b border-slate-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span
                className={`text-[9px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded shadow-2xs ${
                  isToday
                    ? 'bg-blue-900 text-white ring-1 ring-blue-900/20'
                    : 'bg-slate-800 text-white'
                }`}
              >
                {title}
              </span>
              <span className="text-[10px] text-slate-600 font-semibold">
                {dutyState.dayOfWeek.slice(0, 3)}, {dutyState.date}
              </span>
              {dutyHeadline && (
                <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded-full border flex items-center gap-1 ${badgeBg}`}>
                  {headlineIcon}
                  <span className="truncate max-w-[110px]">{dutyHeadline}</span>
                </span>
              )}
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => onNavigateToEntry(dutyState.date)}
                className="text-[9px] font-bold text-blue-900 hover:text-blue-700 flex items-center gap-1 px-1.5 py-0.5 rounded-md hover:bg-blue-50 transition-colors cursor-pointer"
                title="Adjust duty"
              >
                <PlusCircle className="w-2.5 h-2.5" />
                <span>Adjust</span>
              </button>
            </div>
          </div>
        </div>

        {/* Independent Scroll Container: Scrolls ONLY this individual window */}
        <div
          className="flex-1 overflow-y-auto overscroll-contain py-1 space-y-1 custom-scrollbar pr-1 flex flex-col justify-between"
          style={{ overscrollBehavior: 'contain' }}
        >
          {/* Main Duty Section */}
          <div>
            <div className="flex items-center justify-between gap-1.5">
              {isNoDuty ? (
                <div className="flex flex-col">
                  <div className="flex items-center gap-1.5">
                    <span className="p-1 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center shrink-0">
                      <UserX className="w-3.5 h-3.5" />
                    </span>
                    <span
                      className={`text-2xl sm:text-3xl text-purple-950 block leading-tight ${getFontClass()}`}
                    >
                      No Duty (Off)
                    </span>
                  </div>
                  <div className="text-[8.5px] text-slate-400 font-medium pl-1 mt-0.5">
                    Scheduled Rest Day
                  </div>
                </div>
              ) : finalCount === 0 ? (
                <div className="flex flex-col">
                  <div className="flex items-center gap-1.5">
                    <span className="p-1 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
                      <UserCheck className="w-3.5 h-3.5 text-slate-600" />
                    </span>
                    <span
                      className={`text-2xl sm:text-3xl text-slate-800 block leading-tight ${getFontClass()}`}
                    >
                      Relieved (Off)
                    </span>
                  </div>
                  {/* Small text right under: Default shift and helper */}
                  <div className="text-[9px] text-slate-600 font-medium pl-1 leading-snug mt-0.5">
                    <span className="text-slate-400 font-normal">Default: </span>
                    <strong className="text-slate-800 font-bold">{dutyState.originalShiftName}</strong>
                    {(() => {
                      const hellDoAdj = dutyState.adjustments.find((a) => a.action === "He'll Do");
                      const helperName = hellDoAdj ? persons.find((p) => p.id === hellDoAdj.personId)?.name : null;
                      return helperName ? (
                        <>
                          <span className="text-slate-300 mx-1">•</span>
                          <span className="text-red-700 font-bold">Covered by {helperName}</span>
                        </>
                      ) : null;
                    })()}
                  </div>
                </div>
              ) : finalCount >= 2 ? (
                /* TWO DUTIES PERFORMED: Slightly smaller vertical profile */
                <div className="grid grid-cols-2 gap-1.5 w-full">
                  {[...dutyState.finalShifts]
                    .sort((a, b) => {
                      const getOrder = (name: string, id: string) => {
                        const lower = (name + ' ' + id).toLowerCase();
                        if (lower.includes('morning')) return 1;
                        if (lower.includes('afternoon')) return 2;
                        if (lower.includes('night')) return 3;
                        return 4;
                      };
                      return getOrder(a.shiftName, a.shiftId) - getOrder(b.shiftName, b.shiftId);
                    })
                    .map((s, idx) => {
                      const style = getShiftStyle(s.shiftName);
                      const isExchanged = s.source === 'exchanged';
                      const isTaken = s.source === 'taken';

                      // Find exchange adjustment details
                      const exAdj = dutyState.adjustments.find((a) => a.action === 'Shift Exchange');
                      const exchangePartner =
                        s.fromPersonName ||
                        (exAdj
                          ? exAdj.otherPersonName ||
                            exAdj.personName ||
                            persons.find((p) => p.id === (exAdj.otherPersonId || exAdj.personId))?.name
                          : '') ||
                        'Colleague';

                      const defaultShiftName =
                        (exAdj?.shiftId ? shifts.find((sh) => sh.id === exAdj.shiftId)?.name : null) ||
                        (dutyState.originalShiftName !== 'Off' ? dutyState.originalShiftName : 'Scheduled Shift');

                      // Subtle theme for card border & background per shift
                      const cardTheme = s.shiftName.toLowerCase().includes('night')
                        ? 'bg-indigo-50/30 border-indigo-200/80 hover:border-indigo-300'
                        : s.shiftName.toLowerCase().includes('afternoon')
                        ? 'bg-amber-50/30 border-amber-200/80 hover:border-amber-300'
                        : 'bg-blue-50/30 border-blue-200/80 hover:border-blue-300';

                      return (
                        <div
                          key={idx}
                          className={`p-1.5 sm:p-2 rounded-xl border flex flex-col justify-between transition-all shadow-2xs ${cardTheme}`}
                        >
                          {/* Mini header inside duty column: icon & timing */}
                          <div className="flex items-center justify-between gap-1 text-[8px] text-slate-500 font-semibold">
                            <span className="p-0.5 rounded bg-white/90 shadow-2xs shrink-0">
                              {style.icon}
                            </span>
                            <span className="truncate text-slate-500 font-mono text-[7.5px]">{s.timing || 'Scheduled'}</span>
                          </div>

                          {/* Shift Name in Big Size Letter with Reference Image Font */}
                          <div className="py-0.5 text-center sm:text-left">
                            <span
                              className={`text-2xl sm:text-[26px] lg:text-[28px] font-bold text-slate-900 block leading-tight ${getFontClass()}`}
                            >
                              {s.shiftName}
                            </span>
                          </div>

                          {/* Small Details Right Underneath */}
                          <div className="pt-0.5 border-t border-slate-200/60 text-[8px] leading-tight mt-0.5">
                            {isExchanged ? (
                              <div className="text-slate-600 font-medium space-y-0.5">
                                <div className="text-amber-800 font-bold truncate">
                                  ⇄ Swap: {s.fromPersonName || exchangePartner}
                                </div>
                                <div className="text-slate-500 font-normal text-[7.5px]">
                                  Traded: <strong className="text-slate-700 font-semibold">{s.tradedShiftName || defaultShiftName}</strong>
                                </div>
                              </div>
                            ) : isTaken ? (
                              <div className="text-slate-600 font-medium space-y-0.5">
                                <div className="text-emerald-800 font-bold truncate">
                                  Covering {s.fromPersonName || 'Colleague'}
                                </div>
                                <div className="text-slate-400 font-normal text-[7.5px]">
                                  Taken Duty
                                </div>
                              </div>
                            ) : (
                              <div className="text-slate-500 font-medium">
                                <span className="text-blue-900 font-bold block">Scheduled Roster</span>
                                <span className="text-slate-400 text-[7.5px]">Default Duty</span>
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                </div>
              ) : (
                /* SINGLE DUTY PERFORMED: Big size with reference font */
                <div className="space-y-0.5 w-full">
                  {[...dutyState.finalShifts]
                    .sort((a, b) => {
                      const getOrder = (name: string, id: string) => {
                        const lower = (name + ' ' + id).toLowerCase();
                        if (lower.includes('morning')) return 1;
                        if (lower.includes('afternoon')) return 2;
                        if (lower.includes('night')) return 3;
                        return 4;
                      };
                      return getOrder(a.shiftName, a.shiftId) - getOrder(b.shiftName, b.shiftId);
                    })
                    .map((s, idx) => {
                      const style = getShiftStyle(s.shiftName);
                      const isExchanged = s.source === 'exchanged';
                      const isTaken = s.source === 'taken';

                      // Find exchange adjustment details
                      const exAdj = dutyState.adjustments.find((a) => a.action === 'Shift Exchange');
                      const exchangePartner =
                        s.fromPersonName ||
                        (exAdj
                          ? exAdj.otherPersonName ||
                            exAdj.personName ||
                            persons.find((p) => p.id === (exAdj.otherPersonId || exAdj.personId))?.name
                          : '') ||
                        'Colleague';

                      // Default baseline shift: my original default shift before the exchange
                      const defaultShiftName =
                        (exAdj?.shiftId ? shifts.find((sh) => sh.id === exAdj.shiftId)?.name : null) ||
                        (dutyState.originalShiftName !== 'Off' ? dutyState.originalShiftName : 'Scheduled Shift');

                      return (
                        <div key={idx} className="flex flex-col">
                          {/* Main Shift Row: Big size with reference image font */}
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="p-1 rounded-lg bg-slate-100 shadow-2xs flex items-center justify-center shrink-0">
                              {style.icon}
                            </span>
                            <span
                              className={`text-2.5xl sm:text-3xl lg:text-4xl font-bold text-slate-900 tracking-wide leading-none ${getFontClass()}`}
                            >
                              {s.shiftName}
                            </span>
                            {isExchanged && (
                              <span className="text-[8px] font-bold text-amber-900 bg-amber-100/90 border border-amber-300 px-1.5 py-0.2 rounded-md">
                                ⇄ Exchanged
                              </span>
                            )}
                            <span className="text-[9.5px] text-slate-400 font-mono">
                              {s.timing}
                            </span>
                          </div>

                          {/* Right under this in small size: my default shift & exchange partner */}
                          {isExchanged ? (
                            <div className="text-[9px] text-slate-600 font-medium pl-1 leading-snug mt-0.5 space-y-0.5">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="text-slate-400 font-normal">Default:</span>
                                <span className="text-slate-800 font-bold">{s.tradedShiftName || defaultShiftName}</span>
                                <span className="text-slate-300">•</span>
                                <span className="text-amber-800 font-bold">Exchanged with {s.fromPersonName || exchangePartner}</span>
                              </div>
                            </div>
                          ) : isTaken ? (
                            <div className="text-[9px] text-slate-600 font-medium pl-1 leading-snug mt-0.5">
                              <span className="text-emerald-800 font-bold">Covering {s.fromPersonName || 'Colleague'}</span>
                              {dutyState.originalShiftName && dutyState.originalShiftName !== 'Off' && (
                                <span className="text-slate-400 font-normal ml-1">
                                  (Default: <strong className="text-slate-700 font-medium">{dutyState.originalShiftName}</strong>)
                                </span>
                              )}
                            </div>
                          ) : (
                            <div className="text-[9px] text-slate-400 font-medium pl-1 mt-0.5">
                              Default Scheduled Roster
                            </div>
                          )}
                        </div>
                      );
                    })}
                </div>
              )}
            </div>
          </div>

          {/* Bottom Details: Arranged & Compact Info Strip */}
          <div className="pt-1 border-t border-slate-100 text-[8.5px] flex flex-col gap-0.5">
            <div className="flex items-center justify-between text-slate-600 gap-1 flex-wrap">
              <div className="flex items-center gap-1">
                <span className="text-slate-400 font-medium text-[8px]">Scheduled:</span>
                <ShiftBadge shiftName={dutyState.originalShiftName} size="xs" />
              </div>

              {/* Compact Adjustment Pills */}
              {hasAdjustments && (
                <div className="flex items-center gap-1 flex-wrap">
                  {dutyState.adjustments.map((adj) => {
                    const person = persons.find((p) => p.id === adj.personId);
                    const isComp = adj.status === 'Completed';
                    return (
                      <span
                        key={adj.id}
                        className={`inline-flex items-center gap-1 px-1.5 py-0.2 rounded-full text-[7.5px] font-semibold border ${
                          isComp
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                            : 'bg-amber-50 text-amber-800 border-amber-200'
                        }`}
                        title={adj.remarks || adj.action}
                      >
                        <span className="truncate max-w-[85px]">
                          {adj.action === 'Shift Exchange' ? '⇄ Swap' : adj.action} {person ? `· ${person.name}` : ''}
                        </span>
                        <span className="text-[7px] opacity-75">({isComp ? 'Done' : 'Pending'})</span>
                      </span>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Compact Warning Badges */}
            {dutyState.warnings.length > 0 && (
              <div className="flex items-center gap-1 flex-wrap">
                {dutyState.warnings.map((w, idx) => (
                  <span
                    key={idx}
                    className={`px-1.5 py-0.2 rounded text-[7.5px] font-bold flex items-center gap-1 border ${
                      w.severity === 'critical'
                        ? 'bg-red-50 border-red-200 text-red-900'
                        : w.severity === 'warning'
                        ? 'bg-amber-50 border-amber-200 text-amber-900'
                        : 'bg-emerald-50 border-emerald-200 text-emerald-900'
                    }`}
                  >
                    {w.severity === 'critical' ? (
                      <AlertOctagon className="w-2 h-2 text-red-600 shrink-0" />
                    ) : w.severity === 'warning' ? (
                      <AlertTriangle className="w-2 h-2 text-amber-600 shrink-0" />
                    ) : (
                      <CheckCircle2 className="w-2 h-2 text-emerald-600 shrink-0" />
                    )}
                    <span className="truncate max-w-[130px]">{w.title}</span>
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-3 pb-16">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="bg-emerald-600 text-white px-3.5 py-2.5 rounded-xl shadow-md text-xs font-bold flex items-center justify-between animate-in fade-in">
          <span>{toastMessage}</span>
          <button
            onClick={() => setToastMessage('')}
            className="text-emerald-200 hover:text-white ml-2 text-base font-bold"
          >
            ×
          </button>
        </div>
      )}

      {/* Officer Identification Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-1.5 bg-white rounded-xl border border-slate-200 text-xs shadow-2xs">
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Duty Officer:</span>
          <strong className="text-slate-900 font-bold">{userName || 'Duty Officer'}</strong>
          {employeeId && (
            <span className="font-mono text-blue-900 bg-blue-50 px-2 py-0.5 rounded text-[11px] font-bold border border-blue-100">
              ID: {employeeId}
            </span>
          )}
        </div>
        <div className="text-[11px] text-slate-500 font-medium">
          7-Day Weekly Baseline Active
        </div>
      </div>

      {/* 3 Duty Cards - Slightly Smaller Vertical Profile */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 sm:gap-3">
        {displayedDuties.map((item) => (
          <React.Fragment key={item.date}>
            {renderDutyCard(item.title, item.dutyState, item.isToday)}
          </React.Fragment>
        ))}
      </div>

      {/* Metric Cards Grid - Slightly Smaller Vertically */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3">
        <div
          onClick={() => onNavigateToHistory('Pending')}
          className="cursor-pointer bg-white p-3 sm:p-3.5 rounded-xl border border-slate-200 shadow-xs hover:border-amber-400 transition-all"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Pending Reciprocal</span>
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
          </div>
          <div className="mt-1 text-xl sm:text-2xl font-bold text-slate-900 tabular-nums">
            {pendingCount}
          </div>
          <p className="text-[10.5px] text-slate-500 mt-0.5 truncate">
            {pendingCount === 0 ? 'All squared up' : 'Awaiting fulfillment'}
          </p>
        </div>

        <div
          onClick={() => onNavigateToHistory('Completed')}
          className="cursor-pointer bg-white p-3 sm:p-3.5 rounded-xl border border-slate-200 shadow-xs hover:border-emerald-400 transition-all"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Completed Duties</span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
          </div>
          <div className="mt-1 text-xl sm:text-2xl font-bold text-slate-900 tabular-nums">
            {completedCount}
          </div>
          <p className="text-[10.5px] text-slate-500 mt-0.5 truncate">Obligations fulfilled</p>
        </div>

        <div
          onClick={() => onNavigateToHistory('Shift Exchange')}
          className="cursor-pointer bg-white p-3 sm:p-3.5 rounded-xl border border-slate-200 shadow-xs hover:border-blue-400 transition-all"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Shift Exchanges</span>
            <ArrowRightLeft className="w-3.5 h-3.5 text-blue-900" />
          </div>
          <div className="mt-1 text-xl sm:text-2xl font-bold text-slate-900 tabular-nums">
            {totalExchanges}
          </div>
          <p className="text-[10.5px] text-slate-500 mt-0.5 truncate">Mutual swaps recorded</p>
        </div>

        <div className="bg-white p-3 sm:p-3.5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Active Warnings</span>
            <AlertTriangle className={`w-3.5 h-3.5 ${activeWarningsCount > 0 ? 'text-red-500' : 'text-slate-400'}`} />
          </div>
          <div className="mt-1 text-xl sm:text-2xl font-bold text-slate-900 tabular-nums">
            {activeWarningsCount}
          </div>
          <p className="text-[10.5px] text-slate-500 mt-0.5 truncate">
            {activeWarningsCount === 0 ? 'No shift alerts' : 'Requires attention'}
          </p>
        </div>
      </div>

      {/* Legend & Safety Principles */}
      <div className="bg-slate-100/70 border border-slate-200 rounded-xl p-3 text-xs">
        <div className="font-bold text-slate-800 mb-1.5 flex items-center gap-1.5">
          <Info className="w-4 h-4 text-blue-900" />
          <span>Calendar Indicator & Alert Rules</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-slate-700">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-red-600"></span>
            <span>He'll Do (Taking my duty)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
            <span>I'll Do (Taking their duty)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
            <span>Shift Exchange (Swap)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
