import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  ArrowUpDown,
  Edit2,
  Trash2,
  Eye,
  Calendar,
  User,
  Clock,
  ArrowRightLeft,
  CheckCircle2,
  AlertTriangle,
  X,
  FileDown,
  Sparkles,
  Link as LinkIcon,
} from 'lucide-react';
import { useDuty } from '../../context/DutyContext';
import { DutyAdjustment, AdjustmentAction, AdjustmentStatus } from '../../types/duty';
import { formatDateToISO, getDayOfWeekFromDateString } from '../../utils/dutyEngine';
import { exportSingleEntryPDF } from '../../utils/pdfExport';
import { ShiftBadge } from '../../utils/shiftHelper';

interface HistoryViewProps {
  initialFilter?: string;
  onEditAdjustment: (adj: DutyAdjustment) => void;
  onNewAdjustment: () => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  initialFilter,
  onEditAdjustment,
  onNewAdjustment,
}) => {
  const { adjustments, persons, shifts, weeklyRoster, userName, employeeId, deleteAdjustment } = useDuty();

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>(
    initialFilter === 'Pending' || initialFilter === 'Completed' ? initialFilter : 'All'
  );
  const [actionFilter, setActionFilter] = useState<string>(
    initialFilter === 'Shift Exchange' ? initialFilter : 'All'
  );
  const [personFilter, setPersonFilter] = useState<string>('All');
  const [dateFrom, setDateFrom] = useState<string>('');
  const [dateTo, setDateTo] = useState<string>('');
  const [sortBy, setSortBy] = useState<
    'date-desc' | 'date-asc' | 'person' | 'status'
  >('date-desc');

  // Selected item for detail view modal
  const [viewingAdj, setViewingAdj] = useState<DutyAdjustment | null>(null);

  // Delete confirmation modal
  const [deletingAdj, setDeletingAdj] = useState<DutyAdjustment | null>(null);

  // Lock background window scrolling when any history modal is open
  React.useEffect(() => {
    if (viewingAdj || deletingAdj) {
      const prevOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = prevOverflow;
      };
    }
  }, [viewingAdj, deletingAdj]);

  const todayStr = formatDateToISO(new Date());

  const getPersonName = (id?: string) => {
    if (!id) return 'None';
    const found = persons.find((p) => p.id === id);
    return found ? found.name : id;
  };

  const getShiftDetails = (id?: string) => {
    if (!id || id === 'Off') return 'Off';
    const found = shifts.find((s) => s.id === id);
    return found ? `${found.name} (${found.startTime} – ${found.endTime})` : id;
  };

  const filteredAdjustments = useMemo(() => {
    return adjustments.filter((adj) => {
      // Status filter
      if (statusFilter !== 'All' && adj.status !== statusFilter) return false;

      // Action filter
      if (actionFilter !== 'All' && adj.action !== actionFilter) return false;

      // Person filter
      if (personFilter !== 'All' && adj.personId !== personFilter && adj.otherPersonId !== personFilter) return false;

      // Date range filter
      if (dateFrom && adj.date < dateFrom) return false;
      if (dateTo && adj.date > dateTo) return false;

      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const pName = getPersonName(adj.personId).toLowerCase();
        const rem = (adj.remarks || '').toLowerCase();
        const loc = (adj.entryFrom || '').toLowerCase();
        const act = adj.action.toLowerCase();
        const dateMatch = adj.date.includes(query);

        if (!pName.includes(query) && !rem.includes(query) && !loc.includes(query) && !act.includes(query) && !dateMatch) {
          return false;
        }
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'date-desc') return b.date.localeCompare(a.date);
      if (sortBy === 'date-asc') return a.date.localeCompare(b.date);
      if (sortBy === 'person') return getPersonName(a.personId).localeCompare(getPersonName(b.personId));
      if (sortBy === 'status') return a.status.localeCompare(b.status);
      return 0;
    });
  }, [
    adjustments,
    statusFilter,
    actionFilter,
    personFilter,
    dateFrom,
    dateTo,
    searchQuery,
    sortBy,
    persons,
  ]);

  const confirmDelete = () => {
    if (!deletingAdj) return;
    deleteAdjustment(deletingAdj.id);
    setDeletingAdj(null);
    if (viewingAdj?.id === deletingAdj.id) setViewingAdj(null);
  };

  const handleExportPDF = (adj: DutyAdjustment) => {
    exportSingleEntryPDF(adj, {
      userName,
      employeeId,
      weeklyRoster,
      shifts,
      persons,
      adjustments,
    });
  };

  return (
    <div className="space-y-5 pb-24 max-w-5xl mx-auto">
      {/* Search & Detailed Filters Controls (Compact 2-3 Rows) */}
      <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs space-y-2">
        {/* Row 1: Search bar + Record counter */}
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search colleague, remarks, date (YYYY-MM-DD)..."
              className="w-full pl-8 pr-7 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-900 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          <div className="text-[11px] text-slate-500 font-medium whitespace-nowrap hidden sm:block">
            {filteredAdjustments.length} / {adjustments.length} records
          </div>
        </div>

        {/* Row 2: Secondary Dropdown Filters (Compact 4-column row) */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          <select
            value={personFilter}
            onChange={(e) => setPersonFilter(e.target.value)}
            className="w-full px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-900"
          >
            <option value="All">All Persons</option>
            {persons.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-900"
          >
            <option value="All">All Statuses</option>
            <option value="Pending">Pending Reciprocal</option>
            <option value="Completed">Completed</option>
          </select>

          <select
            value={actionFilter}
            onChange={(e) => setActionFilter(e.target.value)}
            className="w-full px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-900"
          >
            <option value="All">All Actions</option>
            <option value="I'll Do">I'll Do (Take)</option>
            <option value="He'll Do">He'll Do (Give)</option>
            <option value="Shift Exchange">Shift Exchange</option>
          </select>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="w-full px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-900"
          >
            <option value="date-desc">Sort: Duty Date (Latest)</option>
            <option value="date-asc">Sort: Duty Date (Earliest)</option>
            <option value="person">Sort: Person Name</option>
            <option value="status">Sort: Status</option>
          </select>
        </div>

        {/* Row 3: Date Range & Clear Filters Row */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1.5 border-t border-slate-100 text-xs">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] text-slate-400 font-medium whitespace-nowrap">From:</span>
              <input
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg font-mono text-[11px] text-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-900"
              />
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] text-slate-400 font-medium whitespace-nowrap">To:</span>
              <input
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg font-mono text-[11px] text-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-900"
              />
            </div>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-[11px] text-slate-500 sm:hidden">
              {filteredAdjustments.length} / {adjustments.length} records
            </span>
            {(dateFrom || dateTo || searchQuery || statusFilter !== 'All' || actionFilter !== 'All' || personFilter !== 'All') && (
              <button
                onClick={() => {
                  setStatusFilter('All');
                  setActionFilter('All');
                  setPersonFilter('All');
                  setDateFrom('');
                  setDateTo('');
                  setSearchQuery('');
                }}
                className="text-[11px] text-blue-900 font-semibold hover:underline"
              >
                Clear all filters
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main List */}
      {filteredAdjustments.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center shadow-xs">
          <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
            <Calendar className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-slate-800">No duty adjustments found</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            {adjustments.length === 0
              ? 'Create your first duty adjustment to start tracking exchanges and safety limits.'
              : 'Try clearing your filters or search terms to see recorded adjustments.'}
          </p>
          <button
            onClick={onNewAdjustment}
            className="mt-4 px-4 py-2 text-xs font-bold text-white bg-blue-900 rounded-xl"
          >
            Record Adjustment
          </button>
        </div>
      ) : (
        <div className="space-y-2.5">
          {filteredAdjustments.map((adj) => {
            const isCompleted = adj.status === 'Completed';
            const personName =
              adj.personName ||
              (adj.personId ? getPersonName(adj.personId) : '') ||
              adj.otherPersonName ||
              'Colleague';
            const shiftText = getShiftDetails(adj.shiftId);
            const otherShiftText = getShiftDetails(adj.otherPersonShiftId || adj.colleagueShiftId);

            return (
              <div
                key={adj.id}
                className="bg-white rounded-xl border border-slate-200 p-3 sm:p-3.5 shadow-2xs hover:border-blue-900/40 transition-all space-y-2"
              >
                {/* Row 1: Action, Date, Colleague & Status */}
                <div className="flex flex-wrap items-center justify-between gap-1.5">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span
                      className={`text-[11px] font-bold px-2 py-0.5 rounded-md border ${
                        adj.action === "I'll Do"
                          ? 'bg-emerald-50 text-emerald-950 border-emerald-200'
                          : adj.action === "He'll Do"
                          ? 'bg-red-50 text-red-950 border-red-200'
                          : 'bg-amber-50 text-amber-950 border-amber-200'
                      }`}
                    >
                      {adj.action}
                    </span>

                    <span className="text-xs font-bold text-slate-900">
                      {adj.date}
                    </span>
                    <span className="text-[11px] text-slate-500">
                      ({getDayOfWeekFromDateString(adj.date).slice(0, 3)})
                    </span>

                    <span className="text-xs text-slate-300">•</span>
                    <span className="text-xs text-slate-700">
                      <span className="text-slate-400 text-[11px]">with </span>
                      <strong className="text-slate-900 font-semibold">{personName}</strong>
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        isCompleted
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {isCompleted ? '● Completed' : '○ Pending'}
                    </span>
                  </div>
                </div>

                {/* Row 2: Shift Details & Remarks */}
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs bg-slate-50 px-2.5 py-1.5 rounded-lg border border-slate-100">
                  <div className="flex items-center gap-2 flex-wrap text-slate-700">
                    <span className="text-[11px] text-slate-400">Shift:</span>
                    <ShiftBadge
                      shiftName={shiftText.split(' (')[0]}
                      timing={shiftText.includes('(') ? shiftText.split('(')[1]?.replace(')', '') : undefined}
                      size="xs"
                    />
                    {adj.action === 'Shift Exchange' && (
                      <>
                        <span className="text-blue-900 font-bold">⇄</span>
                        <span className="text-[11px] text-slate-400">Trade:</span>
                        <ShiftBadge
                          shiftName={otherShiftText.split(' (')[0]}
                          timing={otherShiftText.includes('(') ? otherShiftText.split('(')[1]?.replace(')', '') : undefined}
                          size="xs"
                        />
                      </>
                    )}
                    {adj.remarks && (
                      <span className="text-slate-500 italic text-[11px] truncate max-w-xs before:content-['•_']">
                        "{adj.remarks}"
                      </span>
                    )}
                  </div>
                  {adj.entryFrom && (
                    <span className="text-[10px] text-slate-400">
                      {adj.entryFrom}
                    </span>
                  )}
                </div>

                {/* Row 3: Action Buttons */}
                <div className="pt-1.5 flex items-center justify-between border-t border-slate-100 text-xs">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setViewingAdj(adj)}
                      className="text-slate-600 hover:text-blue-900 flex items-center gap-1 font-semibold transition-colors text-[11px]"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Details</span>
                    </button>
                    <button
                      onClick={() => handleExportPDF(adj)}
                      className="text-blue-900 hover:text-blue-700 flex items-center gap-1 font-semibold transition-colors text-[11px]"
                    >
                      <FileDown className="w-3.5 h-3.5" />
                      <span>PDF</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => onEditAdjustment(adj)}
                      className="text-slate-600 hover:text-blue-900 flex items-center gap-1 font-semibold transition-colors text-[11px]"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                      <span>Edit</span>
                    </button>
                    <button
                      onClick={() => setDeletingAdj(adj)}
                      className="text-red-600 hover:text-red-800 flex items-center gap-1 font-semibold transition-colors text-[11px]"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* DETAIL MODAL */}
      {viewingAdj && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overscroll-contain">
          <div
            className="bg-white rounded-2xl max-w-lg w-full p-5 sm:p-6 shadow-2xl border border-slate-200 space-y-4 max-h-[90vh] overflow-y-auto overscroll-contain my-auto custom-scrollbar"
            style={{ overscrollBehavior: 'contain' }}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-blue-900">
                  Adjustment Audit Record
                </span>
                <h3 className="text-base font-bold text-slate-900">
                  {viewingAdj.action} on {viewingAdj.date}
                </h3>
              </div>
              <button
                onClick={() => setViewingAdj(null)}
                className="text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500">Transaction ID:</span>
                <span className="font-mono font-bold text-slate-800">
                  {viewingAdj.linkedTransactionId || viewingAdj.id}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500">Status:</span>
                <span className={`font-bold ${viewingAdj.status === 'Completed' ? 'text-emerald-700' : 'text-amber-700'}`}>
                  {viewingAdj.status}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500">Date:</span>
                <span className="font-bold text-slate-900">
                  {viewingAdj.date} ({getDayOfWeekFromDateString(viewingAdj.date)})
                </span>
              </div>
              {viewingAdj.action === 'Shift Exchange' ? (
                <>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500">1. My Shift (Traded):</span>
                    <span className="font-bold text-slate-900">{getShiftDetails(viewingAdj.shiftId)}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500">2. Colleague's Shift:</span>
                    <span className="font-bold text-slate-900">
                      {getShiftDetails(viewingAdj.colleagueShiftId || viewingAdj.otherPersonShiftId)} ·{' '}
                      {viewingAdj.personName || getPersonName(viewingAdj.personId)}
                    </span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500">3. Exchange with Shift:</span>
                    <span className="font-bold text-amber-900">
                      {getShiftDetails(viewingAdj.otherPersonShiftId || viewingAdj.colleagueShiftId)} ·{' '}
                      {viewingAdj.otherPersonName || viewingAdj.personName || 'Partner'}
                    </span>
                  </div>
                </>
              ) : viewingAdj.action !== 'No Duty' ? (
                <>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500">Person Involved:</span>
                    <span className="font-bold text-slate-900">
                      {viewingAdj.personName || getPersonName(viewingAdj.personId)}
                    </span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500">Shift Involved:</span>
                    <span className="font-bold text-slate-900">{getShiftDetails(viewingAdj.shiftId)}</span>
                  </div>
                </>
              ) : null}
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500">Location / Desk:</span>
                <span className="font-medium text-slate-700">{viewingAdj.entryFrom || 'Standard Web'}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500">Duty date modified:</span>
                <span className="text-slate-700 font-mono text-[11px]">
                  {(viewingAdj.updatedAt || viewingAdj.createdAt || viewingAdj.date).slice(0, 10)}
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Created:</span>
                <span className="text-slate-700 font-mono text-[11px]">
                  {viewingAdj.createdAt.slice(0, 10)}
                </span>
              </div>
            </div>

            {viewingAdj.remarks && (
              <div className="text-xs bg-blue-50/50 border border-blue-100 p-3 rounded-xl">
                <span className="font-bold text-blue-900 block mb-1">Remarks:</span>
                <p className="text-slate-700 italic">"{viewingAdj.remarks}"</p>
              </div>
            )}

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                onClick={() => handleExportPDF(viewingAdj)}
                className="px-4 py-2 text-xs font-bold text-white bg-blue-900 hover:bg-blue-800 rounded-xl flex items-center gap-1.5"
              >
                <FileDown className="w-4 h-4" />
                <span>Export PDF</span>
              </button>
              <button
                onClick={() => setViewingAdj(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL WITH LINKED RECORD WARNING (Section 25) */}
      {deletingAdj && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overscroll-contain">
          <div
            className="bg-white rounded-2xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-slate-200 space-y-4 max-h-[90vh] overflow-y-auto overscroll-contain my-auto custom-scrollbar"
            style={{ overscrollBehavior: 'contain' }}
          >
            <div className="flex items-center gap-3 text-red-600">
              <div className="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5 text-red-700" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Delete Duty Adjustment?
                </h3>
                <span className="text-xs text-slate-500">This action cannot be undone.</span>
              </div>
            </div>

            {/* Warning if part of a linked transaction */}
            {deletingAdj.linkedTransactionId && (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-950 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="block font-bold">Linked Transaction Warning</strong>
                  <span>
                    This adjustment is part of a linked duty transaction ({deletingAdj.linkedTransactionId}). Deleting this entry will unlink reciprocal obligations and reset dependent duty statuses back to Pending.
                  </span>
                </div>
              </div>
            )}

            <div className="text-xs text-slate-600 bg-slate-50 p-3 rounded-xl">
              <div>Date: <strong>{deletingAdj.date}</strong></div>
              <div>Action: <strong>{deletingAdj.action}</strong></div>
              <div>Person: <strong>{getPersonName(deletingAdj.personId)}</strong></div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeletingAdj(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-xl shadow-xs"
              >
                Yes, Delete Record
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
