import React, { useState } from 'react';
import {
  FileDown,
  Printer,
  Calendar,
  Clock,
  CheckCircle2,
  AlertTriangle,
  AlertOctagon,
  FileText,
  User,
  ArrowRightLeft,
  ChevronRight,
} from 'lucide-react';
import { useDuty } from '../../context/DutyContext';
import { formatDateToISO, addDays, getDayOfWeekFromDateString } from '../../utils/dutyEngine';
import { exportSingleEntryPDF, exportRangeOrMonthPDF } from '../../utils/pdfExport';
import { DutyAdjustment } from '../../types/duty';

export const ExportView: React.FC = () => {
  const { userName, employeeId, weeklyRoster, shifts, persons, adjustments, getDayDuty } = useDuty();

  const sortedAdjustments = React.useMemo(() => {
    return [...adjustments].sort((a, b) => {
      const timeA = new Date(a.updatedAt || a.createdAt || a.date).getTime();
      const timeB = new Date(b.updatedAt || b.createdAt || b.date).getTime();
      if (timeA !== timeB) return timeA - timeB; // Oldest modified first
      return a.date.localeCompare(b.date);
    });
  }, [adjustments]);

  const [exportMode, setExportMode] = useState<'single' | 'range' | 'month'>('month');

  // Single entry selection
  const [selectedEntryId, setSelectedEntryId] = useState<string>(
    sortedAdjustments[0]?.id || adjustments[0]?.id || ''
  );

  // Date Range selection
  const todayStr = formatDateToISO(new Date());
  const [fromDate, setFromDate] = useState<string>(addDays(todayStr, -7));
  const [toDate, setToDate] = useState<string>(addDays(todayStr, 7));

  // Month selection
  const [selectedMonth, setSelectedMonth] = useState<string>(
    todayStr.slice(0, 7) // "YYYY-MM"
  );

  const [isExporting, setIsExporting] = useState<boolean>(false);

  // Trigger export
  const handleExportPDF = () => {
    setIsExporting(true);

    try {
      if (exportMode === 'single') {
        const entry = adjustments.find((a) => a.id === selectedEntryId);
        if (entry) {
          exportSingleEntryPDF(entry, {
            userName,
            employeeId,
            weeklyRoster,
            shifts,
            persons,
            adjustments,
          });
        }
      } else if (exportMode === 'range') {
        exportRangeOrMonthPDF('DUTY ADJUSTMENT DATE RANGE REPORT', fromDate, toDate, {
          userName,
          employeeId,
          weeklyRoster,
          shifts,
          persons,
          adjustments,
        });
      } else if (exportMode === 'month') {
        const [y, m] = selectedMonth.split('-').map(Number);
        const firstDay = `${selectedMonth}-01`;
        const lastDayNum = new Date(y, m, 0).getDate();
        const lastDay = `${selectedMonth}-${String(lastDayNum).padStart(2, '0')}`;

        exportRangeOrMonthPDF(
          `DUTY ADJUSTMENT MONTHLY REPORT (${selectedMonth})`,
          firstDay,
          lastDay,
          {
            userName,
            employeeId,
            weeklyRoster,
            shifts,
            persons,
            adjustments,
          }
        );
      }
    } finally {
      setTimeout(() => setIsExporting(false), 500);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  // 3-day status snapshot for printable sheet
  const threeDaysSnapshot = [
    { label: 'Today', date: todayStr },
    { label: 'Tomorrow', date: addDays(todayStr, 1) },
    { label: 'Day After Tomorrow', date: addDays(todayStr, 2) },
  ].map((d) => ({
    ...d,
    state: getDayDuty(d.date),
  }));

  return (
    <div className="space-y-6 pb-24 max-w-4xl mx-auto">
      {/* Title Card */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Export & Official Duty Reports
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Generate printable, audit-grade PDF documents with navy formatting and ISO roster compliance.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportPDF}
            disabled={isExporting}
            className="px-4 py-2 text-xs font-bold text-white bg-blue-900 hover:bg-blue-800 rounded-xl shadow-xs transition-all flex items-center gap-1.5"
          >
            <FileDown className="w-4 h-4" />
            <span>{isExporting ? 'Generating PDF...' : 'Download PDF'}</span>
          </button>
          <button
            onClick={handlePrint}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all flex items-center gap-1.5"
          >
            <Printer className="w-4 h-4" />
            <span>Print View</span>
          </button>
        </div>
      </div>

      {/* Mode Selection Tabs */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
          Select Export Report Type
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          <button
            onClick={() => setExportMode('month')}
            className={`p-3.5 rounded-xl border text-left transition-all ${
              exportMode === 'month'
                ? 'bg-blue-900 text-white border-blue-900 shadow-sm'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
          >
            <div className="font-bold text-xs flex items-center justify-between">
              <span>Full Monthly Report</span>
              <Calendar className="w-4 h-4" />
            </div>
            <div className={`text-[11px] mt-1 ${exportMode === 'month' ? 'text-blue-200' : 'text-slate-500'}`}>
              Full month duties, adjustments, indicators & warnings
            </div>
          </button>

          <button
            onClick={() => setExportMode('range')}
            className={`p-3.5 rounded-xl border text-left transition-all ${
              exportMode === 'range'
                ? 'bg-blue-900 text-white border-blue-900 shadow-sm'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
          >
            <div className="font-bold text-xs flex items-center justify-between">
              <span>Custom Date Range</span>
              <Clock className="w-4 h-4" />
            </div>
            <div className={`text-[11px] mt-1 ${exportMode === 'range' ? 'text-blue-200' : 'text-slate-500'}`}>
              Export adjustments filtered between two dates
            </div>
          </button>

          <button
            onClick={() => setExportMode('single')}
            className={`p-3.5 rounded-xl border text-left transition-all ${
              exportMode === 'single'
                ? 'bg-blue-900 text-white border-blue-900 shadow-sm'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
          >
            <div className="font-bold text-xs flex items-center justify-between">
              <span>Single Entry Record</span>
              <FileText className="w-4 h-4" />
            </div>
            <div className={`text-[11px] mt-1 ${exportMode === 'single' ? 'text-blue-200' : 'text-slate-500'}`}>
              Audit sheet for an individual duty adjustment
            </div>
          </button>
        </div>

        {/* Dynamic Parameter Selectors */}
        <div className="pt-3 border-t border-slate-100">
          {exportMode === 'month' && (
            <div className="max-w-xs">
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Select Month
              </label>
              <input
                type="month"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-mono"
              />
            </div>
          )}

          {exportMode === 'range' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-md">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  From Date
                </label>
                <input
                  type="date"
                  value={fromDate}
                  onChange={(e) => setFromDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-mono"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  To Date
                </label>
                <input
                  type="date"
                  value={toDate}
                  onChange={(e) => setToDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-mono"
                />
              </div>
            </div>
          )}

          {exportMode === 'single' && (
            <div className="max-w-lg">
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Select Duty Adjustment Entry
              </label>
              <select
                value={selectedEntryId}
                onChange={(e) => setSelectedEntryId(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
              >
                {sortedAdjustments.map((adj) => {
                  const p = persons.find((x) => x.id === adj.personId);
                  const modDate = (adj.updatedAt || adj.createdAt || adj.date).slice(0, 10);
                  return (
                    <option key={adj.id} value={adj.id}>
                      {adj.date} · Duty date mod: {modDate} · {adj.action} ({p?.name || 'Office'}) · {adj.status}
                    </option>
                  );
                })}
              </select>
            </div>
          )}
        </div>
      </div>

      {/* PRINT-READY PREVIEW SHEET (Sections 30 & 31) */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-md print:shadow-none print:border-none print:p-0 space-y-6">
        {/* Printable Header */}
        <div className="border-b-2 border-blue-950 pb-4 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-black text-blue-950 tracking-tight">
              DUTY ADJUSTMENT RECORD
            </h2>
            <p className="text-xs text-slate-600 mt-0.5">
              Official Shift Exchange & Schedule Adjustment System · Officer: <strong className="text-blue-900">{userName}</strong>
            </p>
          </div>
          <div className="text-right text-xs text-slate-500">
            <div>Date: {new Date().toLocaleDateString()}</div>
            <div className="text-[10px] font-mono text-slate-400">DOC-REF: {new Date().getTime().toString().slice(-8)}</div>
          </div>
        </div>

        {/* 3-Day Dashboard Snapshot Section */}
        <div>
          <h3 className="text-xs font-bold text-blue-950 uppercase tracking-wider mb-2">
            1. Current Roster Status Snapshot (3-Day Timeline)
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
            {threeDaysSnapshot.map((item, idx) => (
              <div key={idx} className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <span className="text-[10px] font-bold text-blue-900 uppercase block">
                  {item.label}
                </span>
                <div className="font-semibold text-slate-800 mt-0.5">
                  {item.date} ({item.state.dayOfWeek})
                </div>
                <div className="mt-2 text-slate-600">
                  <span className="text-[11px] text-slate-400 block">Scheduled:</span>
                  <span className="font-medium text-slate-800">{item.state.originalShiftName}</span>
                </div>
                <div className="mt-1">
                  <span className="text-[11px] text-slate-400 block">Final Duty:</span>
                  <span className="font-bold text-blue-950">
                    {item.state.isNoDuty
                      ? 'No Duty'
                      : item.state.finalShifts.map((s) => s.shiftName).join(', ') || 'Off'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Adjustments Table Section */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xs font-bold text-blue-950 uppercase tracking-wider">
              2. Adjustment Entries & Reciprocal Status
            </h3>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-semibold text-blue-900 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                Order: Duty date modified (Oldest First)
              </span>
              <span className="text-xs text-slate-500">Total: {adjustments.length}</span>
            </div>
          </div>

          <div
            className="border border-slate-200 rounded-xl overflow-x-auto max-h-[440px] overflow-y-auto overscroll-contain custom-scrollbar"
            style={{ overscrollBehavior: 'contain' }}
          >
            <table className="w-full text-left text-xs min-w-[500px]">
              <thead className="bg-blue-950 text-white font-bold text-[11px]">
                <tr>
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Action</th>
                  <th className="py-2.5 px-3">Colleague</th>
                  <th className="py-2.5 px-3">Shift</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Remarks</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {sortedAdjustments.slice(0, 10).map((adj) => {
                  const person =
                    persons.find((p) => p.id === adj.personId) ||
                    (adj.personName ? { name: adj.personName } : null) ||
                    (adj.otherPersonName ? { name: adj.otherPersonName } : null);
                  const shift = shifts.find((s) => s.id === adj.shiftId);
                  const exchangedShift =
                    adj.action === 'Shift Exchange'
                      ? shifts.find((s) => s.id === (adj.otherPersonShiftId || adj.colleagueShiftId))
                      : null;
                  const isComp = adj.status === 'Completed';

                  return (
                    <tr key={adj.id} className="hover:bg-slate-50/50">
                      <td className="py-2 px-3 font-mono font-medium text-slate-900">{adj.date}</td>
                      <td className="py-2 px-3 font-semibold text-blue-900">{adj.action}</td>
                      <td className="py-2 px-3">{person?.name || '—'}</td>
                      <td className="py-2 px-3">
                        {adj.action === 'Shift Exchange' && exchangedShift ? (
                          <span>
                            {shift?.name || '—'} ⇄ <strong className="text-blue-900">{exchangedShift.name}</strong>
                          </span>
                        ) : (
                          shift?.name || '—'
                        )}
                      </td>
                      <td className="py-2 px-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            isComp ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {adj.status}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-slate-500 text-[11px] truncate max-w-[150px]">
                        {adj.remarks || '—'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* System Legend & Signatures Section */}
        <div className="pt-4 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <h4 className="font-bold text-blue-950 mb-1.5 uppercase text-[11px]">System Status Legend</h4>
            <div className="space-y-1 text-slate-600 text-[11px]">
              <div>🔴 <strong className="text-slate-800">Red:</strong> Someone is doing my scheduled duty</div>
              <div>🟢 <strong className="text-slate-800">Green:</strong> I am covering another person's duty</div>
              <div>🟡 <strong className="text-slate-800">Yellow:</strong> Mutual shift exchange transaction</div>
            </div>
          </div>

          <div className="flex flex-col justify-end items-end space-y-4">
            <div className="w-48 border-b border-slate-400 pb-1 text-center text-[11px] text-slate-500">
              Authorized Signature & Stamp
            </div>
            <div className="text-[10px] text-slate-400">
              Generated automatically by Duty Adjustment Engine v2.4
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
