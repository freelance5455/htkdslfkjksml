export type ShiftType = 'Morning' | 'Afternoon' | 'Night' | string;

export interface ShiftDefinition {
  id: string;
  name: string;
  startTime: string; // e.g., "07:01 AM"
  endTime: string;   // e.g., "02:00 PM"
  isOvernight?: boolean;
}

export type DayOfWeek = 'Saturday' | 'Sunday' | 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday';

export type WeeklyRoster = Record<DayOfWeek, string>; // Shift ID or 'Off'

export interface Person {
  id: string;
  name: string;
  isOffice?: boolean;
  frequencyScore?: number;
}

export type AdjustmentAction = "I'll Do" | "He'll Do" | "Shift Exchange" | "No Duty";

export type AdjustmentStatus = 'Pending' | 'Completed';

export interface DutyAdjustment {
  id: string;
  date: string; // YYYY-MM-DD
  entryFrom?: string;
  action: AdjustmentAction;
  personId?: string; // The person involved (e.g. whose duty I take, or who takes my duty, or exchange partner)
  personName?: string; // Optional direct or fallback name
  shiftId?: string; // The shift being taken/adjusted
  otherPersonId?: string; // For exchange or reciprocal
  otherPersonName?: string; // Direct or fallback exchange partner name
  otherPersonShiftId?: string; // For Shift Exchange
  colleagueShiftId?: string; // For Shift Exchange (Colleague's Shift)
  remarks?: string;
  linkedTransactionId?: string; // Reciprocal link ID
  status: AdjustmentStatus;
  createdAt: string;
  updatedAt: string;
}

export type WarningSeverity = 'critical' | 'warning' | 'acceptable' | 'info';

export interface DutyWarning {
  severity: WarningSeverity;
  title: string;
  message: string;
  details?: string[];
}

export interface DayDutyState {
  date: string;
  dayOfWeek: DayOfWeek;
  originalShiftId: string; // 'Off' or shift ID
  originalShiftName: string;
  finalShifts: {
    shiftId: string;
    shiftName: string;
    timing: string;
    source: 'regular' | 'taken' | 'exchanged';
    fromPersonName?: string;
    tradedShiftName?: string;
  }[];
  isNoDuty: boolean;
  adjustments: DutyAdjustment[];
  warnings: DutyWarning[];
  indicators: {
    hasSomeoneDoingMyDuty: boolean; // Red
    hasIAmDoingSomeoneDuty: boolean; // Green
    hasShiftExchange: boolean;       // Yellow
    hasNoDuty: boolean;              // Purple
  };
}

export interface DutyBackupData {
  version: number;
  appName: string;
  exportedAt: string;
  data: {
    userName: string;
    employeeId: string;
    isRegistered: boolean;
    weeklyRoster: WeeklyRoster;
    shifts: ShiftDefinition[];
    persons: Person[];
    adjustments: DutyAdjustment[];
    dashboardFont?: 'script' | 'brush' | 'serif' | 'sans';
  };
}
