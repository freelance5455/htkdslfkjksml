import { jsPDF } from 'jspdf';
import { DutyAdjustment, Person, ShiftDefinition, DayDutyState, WeeklyRoster } from '../types/duty';
import { calculateDayDuty, formatDateToISO, addDays, getDayOfWeekFromDateString } from './dutyEngine';

interface ExportContext {
  userName: string;
  employeeId?: string;
  weeklyRoster: WeeklyRoster;
  shifts: ShiftDefinition[];
  persons: Person[];
  adjustments: DutyAdjustment[];
}

export function exportSingleEntryPDF(adjustment: DutyAdjustment, ctx: ExportContext) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const getPersonName = (id?: string) => {
    if (!id) return 'None';
    const found = ctx.persons.find((p) => p.id === id);
    return found ? found.name : id;
  };

  const getShiftDetails = (id?: string) => {
    if (!id || id === 'Off') return 'Off';
    const found = ctx.shifts.find((s) => s.id === id);
    return found ? found.name : id;
  };

  const dayState = calculateDayDuty(
    adjustment.date,
    ctx.weeklyRoster,
    ctx.shifts,
    ctx.adjustments,
    ctx.persons
  );

  // Styling palette
  const navy = [15, 30, 80]; // Primary Navy
  const slateDark = [51, 65, 85];
  const slateLight = [241, 245, 249];

  const formatDateOnly = (dateStr?: string) => {
    if (!dateStr) return '—';
    const d = new Date(dateStr);
    return isNaN(d.getTime()) ? dateStr.slice(0, 10) : formatDateToISO(d);
  };

  // Header Bar
  doc.setFillColor(15, 30, 80);
  doc.rect(0, 0, 210, 28, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text('DUTY ADJUSTMENT RECORD', 14, 15);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  const officerInfo = `Official Duty Schedule & Exchange Log · User: ${ctx.userName}${ctx.employeeId ? ` (ID: ${ctx.employeeId})` : ''} · Duty date modified: ${formatDateOnly(adjustment.updatedAt || adjustment.createdAt)}`;
  doc.text(officerInfo, 14, 22);
  doc.text(`Generated: ${new Date().toLocaleDateString()}`, 196, 22, { align: 'right' });

  // Entry Details Card
  let y = 36;
  doc.setDrawColor(226, 232, 240);
  doc.setFillColor(255, 255, 255);
  doc.roundedRect(14, y, 182, 98, 3, 3, 'FD');

  doc.setTextColor(navy[0], navy[1], navy[2]);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('ADJUSTMENT DETAILS', 20, y + 10);

  // Status Badge
  const isCompleted = adjustment.status === 'Completed';
  if (isCompleted) {
    doc.setFillColor(220, 252, 231);
    doc.roundedRect(155, y + 5, 35, 7, 2, 2, 'F');
    doc.setTextColor(22, 101, 52);
    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.text('● COMPLETED', 172.5, y + 9.5, { align: 'center' });
  } else {
    doc.setFillColor(254, 243, 199);
    doc.roundedRect(155, y + 5, 35, 7, 2, 2, 'F');
    doc.setTextColor(180, 83, 9);
    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.text('○ PENDING', 172.5, y + 9.5, { align: 'center' });
  }

  // Table grid for details
  doc.setFontSize(9.5);
  const rows = [
    ['Transaction ID', adjustment.linkedTransactionId || adjustment.id],
    ['Date (Duty)', `${adjustment.date} (${getDayOfWeekFromDateString(adjustment.date)})`],
    ['Duty date modified', formatDateOnly(adjustment.updatedAt || adjustment.createdAt)],
    ['Date Created', formatDateOnly(adjustment.createdAt)],
    ['Action Taken', adjustment.action],
    ['Person Involved', adjustment.personName || getPersonName(adjustment.personId)],
    ['Duty Shift Involved', getShiftDetails(adjustment.shiftId)],
    ['Entry From', adjustment.entryFrom || 'Standard Web Portal'],
    ['Original Roster Shift', `${dayState.originalShiftName} (${dayState.originalShiftId === 'Off' ? 'Rest Day' : 'Scheduled'})`],
  ];

  if (adjustment.action === 'Shift Exchange') {
    rows.push(['Exchange with Shift', getShiftDetails(adjustment.otherPersonShiftId || adjustment.colleagueShiftId)]);
    if (adjustment.otherPersonName) {
      rows.push(['Exchange Partner', adjustment.otherPersonName]);
    }
  }

  let rowY = y + 18;
  rows.forEach(([label, value]) => {
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(slateDark[0], slateDark[1], slateDark[2]);
    doc.text(label, 20, rowY);

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(15, 23, 42);
    doc.text(String(value), 80, rowY);

    doc.setDrawColor(241, 245, 249);
    doc.line(20, rowY + 1.8, 190, rowY + 1.8);
    rowY += 7.5;
  });

  // Remarks
  y = 140;
  doc.setDrawColor(226, 232, 240);
  doc.setFillColor(slateLight[0], slateLight[1], slateLight[2]);
  doc.roundedRect(14, y, 182, 26, 3, 3, 'FD');

  doc.setTextColor(navy[0], navy[1], navy[2]);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('Remarks & Justification', 20, y + 7);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(51, 65, 85);
  doc.setFontSize(9);
  const remarksText = adjustment.remarks || 'No specific remarks recorded for this transaction.';
  doc.text(remarksText, 20, y + 14, { maxWidth: 170 });

  // Warnings / Conflict Analysis
  y = 172;
  doc.setTextColor(navy[0], navy[1], navy[2]);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('SAFETY & FATIGUE ANALYSIS', 14, y);

  y += 6;
  if (dayState.warnings.length === 0) {
    doc.setFillColor(240, 253, 244);
    doc.roundedRect(14, y, 182, 16, 2, 2, 'F');
    doc.setTextColor(22, 101, 52);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.text('✓ Schedule Safe — No conflicts or fatigue violations detected', 20, y + 10);
  } else {
    dayState.warnings.forEach((w) => {
      if (w.severity === 'critical') {
        doc.setFillColor(254, 226, 226);
        doc.roundedRect(14, y, 182, 20, 2, 2, 'F');
        doc.setTextColor(185, 28, 28);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        doc.text(w.title, 20, y + 7);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8.5);
        doc.text(w.message, 20, y + 14);
      } else if (w.severity === 'warning') {
        doc.setFillColor(254, 243, 199);
        doc.roundedRect(14, y, 182, 20, 2, 2, 'F');
        doc.setTextColor(180, 83, 9);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        doc.text(w.title, 20, y + 7);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8.5);
        doc.text(w.message, 20, y + 14);
      } else {
        doc.setFillColor(240, 253, 244);
        doc.roundedRect(14, y, 182, 20, 2, 2, 'F');
        doc.setTextColor(22, 101, 52);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        doc.text(w.title, 20, y + 7);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8.5);
        doc.text(w.message, 20, y + 14);
      }
      y += 24;
    });
  }

  // Legend at bottom
  y = 246;
  doc.setDrawColor(226, 232, 240);
  doc.line(14, y, 196, y);

  y += 8;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(navy[0], navy[1], navy[2]);
  doc.text('DUTY ADJUSTMENT SYSTEM LEGEND', 14, y);

  y += 7;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('● RED: Someone is doing my duty', 14, y);
  doc.text('● GREEN: I am doing someone\'s duty', 75, y);
  doc.text('● YELLOW: Shift Exchange', 145, y);

  y += 6;
  doc.text('Duty Adjustment Management System · ISO Roster Compliance · Electronic Signature Verified', 14, y);

  doc.save(`Duty-Adjustment-${adjustment.date}-${adjustment.id.slice(0, 6)}.pdf`);
}

export function exportRangeOrMonthPDF(
  title: string,
  fromStr: string,
  toStr: string,
  ctx: ExportContext
) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const navy = [15, 30, 80];

  // Header Bar
  doc.setFillColor(15, 30, 80);
  doc.rect(0, 0, 210, 26, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text(title.toUpperCase(), 14, 14);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  const formatDateOnly = (dateStr?: string) => {
    if (!dateStr) return '—';
    const d = new Date(dateStr);
    return isNaN(d.getTime()) ? dateStr.slice(0, 10) : formatDateToISO(d);
  };

  const rangeOfficerInfo = `Duty Roster & Adjustment Report (${fromStr} to ${toStr}) · ${ctx.userName}${ctx.employeeId ? ` (ID: ${ctx.employeeId})` : ''} · Duty date modified (Oldest First)`;
  doc.text(rangeOfficerInfo, 14, 21);
  doc.text(`Generated: ${new Date().toLocaleDateString()}`, 196, 21, { align: 'right' });

  // Filter adjustments in range and sort ALWAYS by Duty Date Modified (Oldest First)
  const rangeAdjustments = ctx.adjustments
    .filter((a) => a.date >= fromStr && a.date <= toStr)
    .sort((a, b) => {
      const timeA = new Date(a.updatedAt || a.createdAt || a.date).getTime();
      const timeB = new Date(b.updatedAt || b.createdAt || b.date).getTime();
      if (timeA !== timeB) return timeA - timeB; // Duty date modified oldest first
      return a.date.localeCompare(b.date);
    });

  let y = 35;

  // Overview Stats Box
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(14, y, 182, 24, 3, 3, 'FD');

  const pendingCount = rangeAdjustments.filter((a) => a.status === 'Pending').length;
  const completedCount = rangeAdjustments.filter((a) => a.status === 'Completed').length;
  const exchangeCount = rangeAdjustments.filter((a) => a.action === 'Shift Exchange').length;
  const noDutyCount = rangeAdjustments.filter((a) => a.action === 'No Duty').length;

  doc.setTextColor(navy[0], navy[1], navy[2]);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('PERIOD SUMMARY', 20, y + 7);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(51, 65, 85);
  doc.text(`Total Adjustments: ${rangeAdjustments.length}`, 20, y + 14);
  doc.text(`Pending: ${pendingCount}`, 70, y + 14);
  doc.text(`Completed: ${completedCount}`, 110, y + 14);
  doc.text(`Exchanges: ${exchangeCount}`, 150, y + 14);

  y += 32;

  // Table Header (Standard clean columns without modified column, sorted by duty date modified oldest first)
  doc.setFillColor(15, 30, 80);
  doc.rect(14, y, 182, 8, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('DUTY DATE', 18, y + 5.5);
  doc.text('ACTION', 46, y + 5.5);
  doc.text('PERSON', 76, y + 5.5);
  doc.text('SHIFT', 116, y + 5.5);
  doc.text('STATUS', 146, y + 5.5);
  doc.text('FINAL DUTY', 170, y + 5.5);

  y += 8;

  const getPersonName = (id?: string) => {
    if (!id) return '—';
    const found = ctx.persons.find((p) => p.id === id);
    return found ? found.name : '—';
  };

  const getShiftName = (id?: string) => {
    if (!id || id === 'Off') return 'Off';
    const found = ctx.shifts.find((s) => s.id === id);
    return found ? found.name : id;
  };

  if (rangeAdjustments.length === 0) {
    doc.setTextColor(100, 116, 139);
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(9);
    doc.text('No duty adjustments recorded in this date range.', 14, y + 10);
    y += 20;
  } else {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);

    rangeAdjustments.forEach((adj, idx) => {
      // Check page break
      if (y > 250) {
        doc.addPage();
        y = 20;
        // Repeat Table Header
        doc.setFillColor(15, 30, 80);
        doc.rect(14, y, 182, 8, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(8);
        doc.text('DUTY DATE', 18, y + 5.5);
        doc.text('ACTION', 46, y + 5.5);
        doc.text('PERSON', 76, y + 5.5);
        doc.text('SHIFT', 116, y + 5.5);
        doc.text('STATUS', 146, y + 5.5);
        doc.text('FINAL DUTY', 170, y + 5.5);
        y += 8;
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(7.5);
      }

      const dayState = calculateDayDuty(
        adj.date,
        ctx.weeklyRoster,
        ctx.shifts,
        ctx.adjustments,
        ctx.persons
      );

      const finalSummary = dayState.isNoDuty
        ? 'No Duty'
        : dayState.finalShifts.map((s) => s.shiftName).join(', ') || 'Off';

      // Alternate row bg
      if (idx % 2 === 1) {
        doc.setFillColor(248, 250, 252);
        doc.rect(14, y, 182, 7.5, 'F');
      }

      doc.setTextColor(15, 23, 42);
      doc.text(adj.date, 18, y + 5);
      doc.text(adj.action, 46, y + 5);
      doc.text(getPersonName(adj.personId), 76, y + 5);
      doc.text(getShiftName(adj.shiftId), 116, y + 5);

      if (adj.status === 'Completed') {
        doc.setTextColor(22, 101, 52);
        doc.text('Completed', 146, y + 5);
      } else {
        doc.setTextColor(180, 83, 9);
        doc.text('Pending', 146, y + 5);
      }

      doc.setTextColor(15, 23, 42);
      doc.text(finalSummary, 170, y + 5);

      doc.setDrawColor(241, 245, 249);
      doc.line(14, y + 7.5, 196, y + 7.5);
      y += 7.5;
    });
  }

  // Dashboard 3-day snapshot
  if (y > 230) {
    doc.addPage();
    y = 20;
  } else {
    y += 10;
  }

  doc.setTextColor(navy[0], navy[1], navy[2]);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('3-DAY ROSTER RECENT STATUS SNAPSHOT', 14, y);
  y += 6;

  const todayStr = formatDateToISO(new Date());
  const threeDays = [
    { label: 'Today', date: todayStr },
    { label: 'Tomorrow', date: addDays(todayStr, 1) },
    { label: 'Day After Tomorrow', date: addDays(todayStr, 2) },
  ];

  threeDays.forEach((item) => {
    const ds = calculateDayDuty(
      item.date,
      ctx.weeklyRoster,
      ctx.shifts,
      ctx.adjustments,
      ctx.persons
    );
    const finalShiftText = ds.isNoDuty
      ? 'No Duty'
      : ds.finalShifts.map((s) => s.shiftName).join(', ') || 'Off';

    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(14, y, 182, 11, 2, 2, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(navy[0], navy[1], navy[2]);
    doc.text(`${item.label} (${item.date}):`, 18, y + 7);

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(51, 65, 85);
    doc.text(`Roster: ${ds.originalShiftName}  →  Final Duty: ${finalShiftText}`, 78, y + 7);

    y += 13;
  });

  // Footer Legend
  const footerY = 278;
  doc.setDrawColor(226, 232, 240);
  doc.line(14, footerY - 5, 196, footerY - 5);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(100, 116, 139);
  doc.text('Legend:  🔴 Someone Doing My Duty   🟢 I Am Doing Duty   🟡 Shift Exchange', 14, footerY);
  doc.text(`Page 1 of 1 · Exported ${new Date().toLocaleDateString()}`, 196, footerY, { align: 'right' });

  doc.save(`${title.replace(/\s+/g, '-')}-${fromStr}-to-${toStr}.pdf`);
}
