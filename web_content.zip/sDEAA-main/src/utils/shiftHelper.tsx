import React from 'react';
import { Sun, Sunset, Moon, Coffee, Clock } from 'lucide-react';
import { ShiftDefinition } from '../types/duty';

export type ShiftCategory = 'Morning' | 'Afternoon' | 'Night' | 'Off' | 'Other';

export interface ShiftStyleConfig {
  category: ShiftCategory;
  label: string;
  shortLabel: string;
  icon: React.ReactNode;
  bgBadge: string;
  bgLight: string;
  border: string;
  text: string;
  textAccent: string;
  activeCard: string;
  inactiveCard: string;
  dotColor: string;
  order: number;
}

export function getShiftCategory(shiftNameOrId?: string): ShiftCategory {
  if (!shiftNameOrId) return 'Other';
  const val = shiftNameOrId.toLowerCase();
  if (val === 'off' || val === 'rest') return 'Off';
  if (val.includes('morning') || val.includes('shift-morning')) return 'Morning';
  if (val.includes('afternoon') || val.includes('shift-afternoon')) return 'Afternoon';
  if (val.includes('night') || val.includes('shift-night')) return 'Night';
  return 'Other';
}

export function getShiftStyle(shiftNameOrId?: string): ShiftStyleConfig {
  const cat = getShiftCategory(shiftNameOrId);

  switch (cat) {
    case 'Morning':
      return {
        category: 'Morning',
        label: 'Morning',
        shortLabel: 'M',
        icon: <Sun className="w-3.5 h-3.5 text-amber-600 shrink-0" />,
        bgBadge: 'bg-amber-50 text-amber-900 border-amber-300',
        bgLight: 'bg-amber-50/80',
        border: 'border-amber-300',
        text: 'text-amber-900',
        textAccent: 'text-amber-600',
        activeCard: 'bg-gradient-to-br from-amber-500 to-amber-600 text-white border-amber-600 shadow-sm',
        inactiveCard: 'bg-amber-50/70 hover:bg-amber-100/90 text-amber-950 border-amber-200/90',
        dotColor: 'bg-amber-500',
        order: 1,
      };

    case 'Afternoon':
      return {
        category: 'Afternoon',
        label: 'Afternoon',
        shortLabel: 'A',
        icon: <Sunset className="w-3.5 h-3.5 text-orange-600 shrink-0" />,
        bgBadge: 'bg-orange-50 text-orange-900 border-orange-300',
        bgLight: 'bg-orange-50/80',
        border: 'border-orange-300',
        text: 'text-orange-900',
        textAccent: 'text-orange-600',
        activeCard: 'bg-gradient-to-br from-orange-500 to-orange-600 text-white border-orange-600 shadow-sm',
        inactiveCard: 'bg-orange-50/70 hover:bg-orange-100/90 text-orange-950 border-orange-200/90',
        dotColor: 'bg-orange-500',
        order: 2,
      };

    case 'Night':
      return {
        category: 'Night',
        label: 'Night',
        shortLabel: 'N',
        icon: <Moon className="w-3.5 h-3.5 text-indigo-400 shrink-0" />,
        bgBadge: 'bg-indigo-50 text-indigo-950 border-indigo-300',
        bgLight: 'bg-indigo-50/80',
        border: 'border-indigo-300',
        text: 'text-indigo-950',
        textAccent: 'text-indigo-600',
        activeCard: 'bg-gradient-to-br from-indigo-800 to-indigo-950 text-white border-indigo-900 shadow-sm',
        inactiveCard: 'bg-indigo-50/70 hover:bg-indigo-100/90 text-indigo-950 border-indigo-200/90',
        dotColor: 'bg-indigo-600',
        order: 3,
      };

    case 'Off':
      return {
        category: 'Off',
        label: 'Off (Rest)',
        shortLabel: 'Off',
        icon: <Coffee className="w-3.5 h-3.5 text-purple-600 shrink-0" />,
        bgBadge: 'bg-purple-50 text-purple-900 border-purple-200',
        bgLight: 'bg-purple-50/60',
        border: 'border-purple-200',
        text: 'text-purple-900',
        textAccent: 'text-purple-600',
        activeCard: 'bg-purple-800 text-white border-purple-900 shadow-sm',
        inactiveCard: 'bg-purple-50/60 hover:bg-purple-100/80 text-purple-950 border-purple-200',
        dotColor: 'bg-purple-500',
        order: 4,
      };

    default:
      return {
        category: 'Other',
        label: shiftNameOrId || 'Shift',
        shortLabel: 'S',
        icon: <Clock className="w-3.5 h-3.5 text-slate-500 shrink-0" />,
        bgBadge: 'bg-slate-100 text-slate-800 border-slate-200',
        bgLight: 'bg-slate-50',
        border: 'border-slate-200',
        text: 'text-slate-800',
        textAccent: 'text-slate-500',
        activeCard: 'bg-slate-800 text-white border-slate-900 shadow-sm',
        inactiveCard: 'bg-white hover:bg-slate-50 text-slate-800 border-slate-200',
        dotColor: 'bg-slate-500',
        order: 5,
      };
  }
}

/**
 * Sorts shifts according to chronological order:
 * Morning -> Afternoon -> Night
 */
export function sortShiftsChronological(shifts: ShiftDefinition[]): ShiftDefinition[] {
  return [...shifts].sort((a, b) => {
    const orderA = getShiftStyle(a.name || a.id).order;
    const orderB = getShiftStyle(b.name || b.id).order;
    return orderA - orderB;
  });
}

/**
 * Visual badge displaying shift according to Morning, Afternoon, Night
 */
export const ShiftBadge: React.FC<{
  shiftName?: string;
  timing?: string;
  showIcon?: boolean;
  size?: 'xs' | 'sm' | 'md';
  className?: string;
}> = ({
  shiftName = 'Morning',
  showIcon = true,
  size = 'sm',
  className = '',
}) => {
  const style = getShiftStyle(shiftName);

  const sizeClasses = {
    xs: 'text-[9px] px-1.5 py-0.2 gap-1 font-semibold',
    sm: 'text-[10px] px-2 py-0.5 gap-1.5 font-bold',
    md: 'text-xs px-2.5 py-1 gap-2 font-bold',
  }[size];

  const iconSizes = {
    xs: 'w-2.5 h-2.5',
    sm: 'w-3 h-3',
    md: 'w-3.5 h-3.5',
  }[size];

  return (
    <span
      className={`inline-flex items-center rounded-lg border ${style.bgBadge} ${sizeClasses} ${className}`}
    >
      {showIcon && (
        <span className="shrink-0 flex items-center">
          {style.category === 'Morning' && <Sun className={iconSizes} />}
          {style.category === 'Afternoon' && <Sunset className={iconSizes} />}
          {style.category === 'Night' && <Moon className={iconSizes} />}
          {style.category === 'Off' && <Coffee className={iconSizes} />}
          {style.category === 'Other' && <Clock className={iconSizes} />}
        </span>
      )}
      <span className="truncate">{shiftName}</span>
    </span>
  );
};
