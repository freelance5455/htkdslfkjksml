import {
  DayOfWeek,
  DutyAdjustment,
  DayDutyState,
  DutyWarning,
  Person,
  ShiftDefinition,
  WeeklyRoster,
  AdjustmentStatus,
} from '../types/duty';

// Predefined Days of Week in roster order starting from Saturday
export const DAYS_OF_WEEK: DayOfWeek[] = [
  'Saturday',
  'Sunday',
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
];

// Helper to get DayOfWeek from YYYY-MM-DD
export function getDayOfWeekFromDateString(dateStr: string): DayOfWeek {
  const [year, month, day] = dateStr.split('-').map(Number);
  const date = new Date(year, month - 1, day);
  const dayIndex = date.getDay(); // 0 is Sunday, 6 is Saturday
  const mapping: Record<number, DayOfWeek> = {
    0: 'Sunday',
    1: 'Monday',
    2: 'Tuesday',
    3: 'Wednesday',
    4: 'Thursday',
    5: 'Friday',
    6: 'Saturday',
  };
  return mapping[dayIndex];
}

export function formatDateToISO(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function addDays(dateStr: string, days: number): string {
  const [year, month, day] = dateStr.split('-').map(Number);
  const d = new Date(year, month - 1, day);
  d.setDate(d.getDate() + days);
  return formatDateToISO(d);
}

export function isDateInPast(dateStr: string, referenceDateStr?: string): boolean {
  const ref = referenceDateStr ? referenceDateStr : formatDateToISO(new Date());
  return dateStr < ref;
}

export function isDateTodayOrPast(dateStr: string, referenceDateStr?: string): boolean {
  const ref = referenceDateStr ? referenceDateStr : formatDateToISO(new Date());
  return dateStr <= ref;
}

/**
 * Returns the base regular shift for a given date based on weekly roster.
 */
export function getRegularShiftForDate(
  dateStr: string,
  weeklyRoster: WeeklyRoster
): string {
  const dayName = getDayOfWeekFromDateString(dateStr);
  return weeklyRoster[dayName] || 'Off';
}

/**
 * Calculates duty status for all adjustments and reciprocal link matching
 */
export function reconcileAdjustmentStatuses(
  adjustments: DutyAdjustment[],
  persons: Person[],
  todayStr: string = formatDateToISO(new Date())
): DutyAdjustment[] {
  // Build a clone
  const updated: DutyAdjustment[] = adjustments.map((a) => ({ ...a }));

  // Separate "I'll Do" and "He'll Do" to match reciprocity
  // If Person X did my duty on Date A ("He'll Do", personId: X)
  // And on Date B, I did Person X's duty ("I'll Do", personId: X)
  // Both can be reciprocated if both dates are <= todayStr!

  const illDoList = updated.filter(
    (a) => a.action === "I'll Do" && a.personId
  );
  const hellDoList = updated.filter(
    (a) => a.action === "He'll Do" && a.personId
  );

  // Group by personId
  const byPerson: Record<string, { illDo: DutyAdjustment[]; hellDo: DutyAdjustment[] }> = {};
  persons.forEach((p) => {
    byPerson[p.id] = { illDo: [], hellDo: [] };
  });

  illDoList.forEach((a) => {
    if (a.personId) {
      if (!byPerson[a.personId]) byPerson[a.personId] = { illDo: [], hellDo: [] };
      byPerson[a.personId].illDo.push(a);
    }
  });

  hellDoList.forEach((a) => {
    if (a.personId) {
      if (!byPerson[a.personId]) byPerson[a.personId] = { illDo: [], hellDo: [] };
      byPerson[a.personId].hellDo.push(a);
    }
  });

  // For each person, pair oldest completed dates FIFO
  Object.keys(byPerson).forEach((personId) => {
    const listIll = byPerson[personId].illDo.sort((a, b) => a.date.localeCompare(b.date));
    const listHell = byPerson[personId].hellDo.sort((a, b) => a.date.localeCompare(b.date));

    const pairsCount = Math.min(listIll.length, listHell.length);
    for (let i = 0; i < pairsCount; i++) {
      const a = listIll[i];
      const b = listHell[i];

      // A reciprocal exchange is only Completed if BOTH duty dates have passed!
      const aPassed = isDateTodayOrPast(a.date, todayStr);
      const bPassed = isDateTodayOrPast(b.date, todayStr);

      const linkId = a.linkedTransactionId || b.linkedTransactionId || `tx-${a.id.slice(0, 6)}-${b.id.slice(0, 6)}`;
      a.linkedTransactionId = linkId;
      b.linkedTransactionId = linkId;

      if (aPassed && bPassed) {
        a.status = 'Completed';
        b.status = 'Completed';
      } else {
        a.status = 'Pending';
        b.status = 'Pending';
      }
    }

    // Remaining un-paired in illDo
    for (let i = pairsCount; i < listIll.length; i++) {
      listIll[i].status = 'Pending';
    }
    // Remaining un-paired in hellDo
    for (let i = pairsCount; i < listHell.length; i++) {
      listHell[i].status = 'Pending';
    }
  });

  // Handle Shift Exchange & No Duty
  updated.forEach((adj) => {
    if (adj.action === 'Shift Exchange') {
      // A shift exchange is completed once the exchange date has passed!
      const datePassed = isDateTodayOrPast(adj.date, todayStr);
      adj.status = datePassed ? 'Completed' : 'Pending';
    } else if (adj.action === 'No Duty') {
      const datePassed = isDateTodayOrPast(adj.date, todayStr);
      adj.status = datePassed ? 'Completed' : 'Pending';
    }
  });

  return updated;
}

/**
 * Calculates full duty state for a specific date given weekly roster, shifts, and adjustments.
 */
export function calculateDayDuty(
  dateStr: string,
  weeklyRoster: WeeklyRoster,
  shifts: ShiftDefinition[],
  adjustments: DutyAdjustment[],
  persons: Person[]
): DayDutyState {
  const dayOfWeek = getDayOfWeekFromDateString(dateStr);
  const originalShiftId = getRegularShiftForDate(dateStr, weeklyRoster);

  const getShiftName = (sId: string) => {
    if (sId === 'Off') return 'Off';
    const found = shifts.find((s) => s.id === sId);
    return found ? found.name : sId;
  };

  const getShiftTiming = (sId: string) => {
    if (sId === 'Off') return 'Rest Day';
    const found = shifts.find((s) => s.id === sId);
    return found ? `${found.startTime} – ${found.endTime}` : '';
  };

  const getPersonName = (pId?: string) => {
    if (!pId) return '';
    const found = persons.find((p) => p.id === pId);
    return found ? found.name : 'Unknown';
  };

  // Adjustments on this date
  const dayAdjustments = adjustments.filter((a) => a.date === dateStr);

  const hasNoDuty = dayAdjustments.some((a) => a.action === 'No Duty');
  const hasSomeoneDoingMyDuty = dayAdjustments.some((a) => a.action === "He'll Do");
  const hasIAmDoingSomeoneDuty = dayAdjustments.some((a) => a.action === "I'll Do");
  const hasShiftExchange = dayAdjustments.some((a) => a.action === 'Shift Exchange');

  // Determine what shifts user actually performs
  type FinalShiftItem = {
    shiftId: string;
    shiftName: string;
    timing: string;
    source: 'regular' | 'taken' | 'exchanged';
    fromPersonName?: string;
    tradedShiftName?: string;
  };

  const finalShifts: FinalShiftItem[] = [];

  if (hasNoDuty) {
    // User performs nothing
  } else {
    // Track held shifts on this day before exchange:
    type HeldItem = {
      shiftId: string;
      shiftName: string;
      timing: string;
      source: 'regular' | 'taken';
      fromPersonName?: string;
      adjId?: string;
    };

    let heldShifts: HeldItem[] = [];

    // 1. Regular default scheduled shift (if not covered by someone else via "He'll Do")
    if (originalShiftId !== 'Off' && !hasSomeoneDoingMyDuty) {
      heldShifts.push({
        shiftId: originalShiftId,
        shiftName: getShiftName(originalShiftId),
        timing: getShiftTiming(originalShiftId),
        source: 'regular',
      });
    }

    // 2. Extra taken duties on this day ("I'll Do", e.g. taking Ravi's Morning)
    const illDoEntries = dayAdjustments.filter((a) => a.action === "I'll Do");
    illDoEntries.forEach((adj) => {
      if (adj.shiftId && adj.shiftId !== 'Off') {
        heldShifts.push({
          shiftId: adj.shiftId,
          shiftName: getShiftName(adj.shiftId),
          timing: getShiftTiming(adj.shiftId),
          source: 'taken',
          fromPersonName: adj.personName || getPersonName(adj.personId),
          adjId: adj.id,
        });
      }
    });

    // 3. Shift Exchange processing
    const exchangeEntries = dayAdjustments.filter((a) => a.action === 'Shift Exchange');

    if (exchangeEntries.length === 0) {
      // No exchange: all held shifts are performed
      heldShifts.forEach((h) => {
        finalShifts.push({
          shiftId: h.shiftId,
          shiftName: h.shiftName,
          timing: h.timing,
          source: h.source,
          fromPersonName: h.fromPersonName,
        });
      });
    } else {
      exchangeEntries.forEach((exAdj) => {
        const tradedShiftId = exAdj.shiftId; // The shift traded away (e.g. Afternoon, or Ravi's Morning)
        const receivedShiftId = exAdj.otherPersonShiftId || exAdj.colleagueShiftId; // The shift received (e.g. Morning, or Night)
        const partnerName =
          exAdj.otherPersonName ||
          exAdj.personName ||
          getPersonName(exAdj.otherPersonId || exAdj.personId);

        // Find which held shift was traded away:
        const matchedIndex = heldShifts.findIndex((h) => h.shiftId === tradedShiftId);
        if (matchedIndex !== -1) {
          // Traded away this specific held shift (e.g. default Afternoon, or taken Morning): remove it
          heldShifts.splice(matchedIndex, 1);
        } else if (tradedShiftId === originalShiftId) {
          // If explicitly traded default shift, remove regular shift
          heldShifts = heldShifts.filter((h) => h.source !== 'regular');
        }

        // Add the received shift from exchange
        if (receivedShiftId && receivedShiftId !== 'Off') {
          finalShifts.push({
            shiftId: receivedShiftId,
            shiftName: getShiftName(receivedShiftId),
            timing: getShiftTiming(receivedShiftId),
            source: 'exchanged',
            fromPersonName: partnerName,
            tradedShiftName: getShiftName(tradedShiftId || ''),
          });
        }
      });

      // Add remaining held shifts that were NOT traded away (e.g. default Afternoon when Ravi's Morning was traded)
      heldShifts.forEach((h) => {
        finalShifts.push({
          shiftId: h.shiftId,
          shiftName: h.shiftName,
          timing: h.timing,
          source: h.source,
          fromPersonName: h.fromPersonName,
        });
      });
    }
  }

  // Ensure shifts are sorted chronologically: Morning -> Afternoon -> Night
  finalShifts.sort((a, b) => {
    const getOrder = (name: string, id: string) => {
      const lower = (name + ' ' + id).toLowerCase();
      if (lower.includes('morning')) return 1;
      if (lower.includes('afternoon')) return 2;
      if (lower.includes('night')) return 3;
      return 4;
    };
    return getOrder(a.shiftName, a.shiftId) - getOrder(b.shiftName, b.shiftId);
  });

  // Calculate Warnings
  const warnings: DutyWarning[] = [];

  // RULE 1: Three shifts in one day (RED ALERT)
  if (finalShifts.length >= 3) {
    const shiftNames = finalShifts.map((s) => s.shiftName).join(', ');
    warnings.push({
      severity: 'critical',
      title: '🔴 RED ALERT — Three Shifts in One Day',
      message: 'Not Acceptable — Three shifts scheduled on the same calendar day.',
      details: [
        `Scheduled duties: ${shiftNames}`,
        'Dangerous schedule: Working three shifts in one day violates safety limits.',
      ],
    });
  }

  // RULE: Taking same shift on the same day (RED ALERT)
  const shiftOccurrences: Record<string, { count: number; name: string; timing: string; sources: string[] }> = {};
  finalShifts.forEach((s) => {
    const key = s.shiftId || s.shiftName.toLowerCase().trim();
    if (!shiftOccurrences[key]) {
      shiftOccurrences[key] = {
        count: 0,
        name: s.shiftName,
        timing: s.timing,
        sources: [],
      };
    }
    shiftOccurrences[key].count += 1;
    const sourceDesc =
      s.source === 'regular'
        ? 'Your Scheduled Roster'
        : s.source === 'exchanged'
        ? `Shift Exchange (${s.fromPersonName || 'Partner'})`
        : `Taking Duty ("I'll Do" for ${s.fromPersonName || 'Colleague'})`;
    shiftOccurrences[key].sources.push(sourceDesc);
  });

  Object.values(shiftOccurrences).forEach((item) => {
    if (item.count >= 2) {
      warnings.push({
        severity: 'critical',
        title: `🔴 RED ALERT — Same Shift on Same Day (${item.name})`,
        message: `Not Acceptable — Taking same shift (${item.name}) more than once on the same day.`,
        details: [
          `Conflict: Scheduled to work ${item.count}× ${item.name} (${item.timing}) on this date.`,
          `Assigned sources: ${item.sources.join(' and ')}.`,
          `Direct timing clash: You cannot be scheduled for the exact same shift twice on the same day.`,
        ],
      });
    }
  });

  // RULE 2 & 3: Acceptable duty adjustment & Office handling
  if (hasSomeoneDoingMyDuty) {
    const giveAdj = dayAdjustments.find((a) => a.action === "He'll Do");
    const person = persons.find((p) => p.id === giveAdj?.personId);
    const isOffice = person?.isOffice;

    if (isOffice) {
      warnings.push({
        severity: 'acceptable',
        title: '🟢 Duty Relieved by Office',
        message: 'Your scheduled shift has been taken over by Office as an official adjustment.',
      });
    } else {
      warnings.push({
        severity: 'acceptable',
        title: '🟢 Acceptable Duty Adjustment',
        message: `Your scheduled shift is being covered by ${person?.name || 'colleague'}.`,
      });
    }
  }

  // Check RULE 4 & 5: Fatigue warning (Morning immediately after Night)
  // Check if yesterday user worked a Night shift, and today user works a Morning shift!
  const yesterdayStr = addDays(dateStr, -1);
  const yesterdayDuty = calculateDayDutyInternalShiftsOnly(
    yesterdayStr,
    weeklyRoster,
    shifts,
    adjustments
  );

  const yesterdayHasNight = yesterdayDuty.some((s) =>
    s.shiftName.toLowerCase().includes('night')
  );
  const todayHasMorning = finalShifts.some((s) =>
    s.shiftName.toLowerCase().includes('morning')
  );

  if (yesterdayHasNight && todayHasMorning) {
    warnings.push({
      severity: 'warning',
      title: '🟡 YELLOW ALERT — Fatigue Sign',
      message: 'Fatigue Warning: Morning duty follows Night duty.',
      details: [
        'Night duty ends at 07:00 AM, and Morning duty starts at 07:01 AM.',
        'Back-to-back overnight shifts cause severe sleep deprivation. Exercise caution.',
      ],
    });
  }

  // Sort warnings: critical first, then warning, then acceptable, then info
  const priorityOrder: Record<string, number> = {
    critical: 1,
    warning: 2,
    acceptable: 3,
    info: 4,
  };
  warnings.sort((a, b) => (priorityOrder[a.severity] || 99) - (priorityOrder[b.severity] || 99));

  return {
    date: dateStr,
    dayOfWeek,
    originalShiftId,
    originalShiftName: getShiftName(originalShiftId),
    finalShifts,
    isNoDuty: hasNoDuty,
    adjustments: dayAdjustments,
    warnings,
    indicators: {
      hasSomeoneDoingMyDuty,
      hasIAmDoingSomeoneDuty,
      hasShiftExchange,
      hasNoDuty,
    },
  };
}

/**
 * Lightweight helper to determine final shifts for a date without recursion loop
 */
function calculateDayDutyInternalShiftsOnly(
  dateStr: string,
  weeklyRoster: WeeklyRoster,
  shifts: ShiftDefinition[],
  adjustments: DutyAdjustment[]
): { shiftId: string; shiftName: string }[] {
  const originalShiftId = getRegularShiftForDate(dateStr, weeklyRoster);

  const getShiftName = (sId: string) => {
    if (sId === 'Off') return 'Off';
    const found = shifts.find((s) => s.id === sId);
    return found ? found.name : sId;
  };

  const dayAdjustments = adjustments.filter((a) => a.date === dateStr);
  const hasNoDuty = dayAdjustments.some((a) => a.action === 'No Duty');
  if (hasNoDuty) return [];

  const hasSomeoneDoingMyDuty = dayAdjustments.some((a) => a.action === "He'll Do");
  const exchangeEntries = dayAdjustments.filter((a) => a.action === 'Shift Exchange');
  const illDoEntries = dayAdjustments.filter((a) => a.action === "I'll Do");

  let heldShifts: { shiftId: string; shiftName: string; source: 'regular' | 'taken' }[] = [];

  if (originalShiftId !== 'Off' && !hasSomeoneDoingMyDuty) {
    heldShifts.push({
      shiftId: originalShiftId,
      shiftName: getShiftName(originalShiftId),
      source: 'regular',
    });
  }

  illDoEntries.forEach((adj) => {
    if (adj.shiftId && adj.shiftId !== 'Off') {
      heldShifts.push({
        shiftId: adj.shiftId,
        shiftName: getShiftName(adj.shiftId),
        source: 'taken',
      });
    }
  });

  const final: { shiftId: string; shiftName: string }[] = [];

  if (exchangeEntries.length === 0) {
    heldShifts.forEach((h) => final.push({ shiftId: h.shiftId, shiftName: h.shiftName }));
  } else {
    exchangeEntries.forEach((exAdj) => {
      const tradedShiftId = exAdj.shiftId;
      const receivedShiftId = exAdj.otherPersonShiftId || exAdj.colleagueShiftId;

      const idx = heldShifts.findIndex((h) => h.shiftId === tradedShiftId);
      if (idx !== -1) {
        heldShifts.splice(idx, 1);
      } else if (tradedShiftId === originalShiftId) {
        heldShifts = heldShifts.filter((h) => h.source !== 'regular');
      }

      if (receivedShiftId && receivedShiftId !== 'Off') {
        final.push({
          shiftId: receivedShiftId,
          shiftName: getShiftName(receivedShiftId),
        });
      }
    });

    heldShifts.forEach((h) => final.push({ shiftId: h.shiftId, shiftName: h.shiftName }));
  }

  final.sort((a, b) => {
    const getOrder = (name: string, id: string) => {
      const lower = (name + ' ' + id).toLowerCase();
      if (lower.includes('morning')) return 1;
      if (lower.includes('afternoon')) return 2;
      if (lower.includes('night')) return 3;
      return 4;
    };
    return getOrder(a.shiftName, a.shiftId) - getOrder(b.shiftName, b.shiftId);
  });

  return final;
}

/**
 * Simulates saving a proposed entry to test what warnings would be triggered
 */
export function analyzeProposedAdjustment(
  proposed: Omit<DutyAdjustment, 'id' | 'createdAt' | 'updatedAt' | 'status'>,
  existingAdjustments: DutyAdjustment[],
  weeklyRoster: WeeklyRoster,
  shifts: ShiftDefinition[],
  persons: Person[],
  editingId?: string
): {
  projectedShifts: { shiftName: string; timing: string }[];
  warnings: DutyWarning[];
  hasCriticalConflict: boolean;
} {
  // Filter out the item if editing
  const simulatedAdjustments = existingAdjustments.filter((a) => a.id !== editingId);

  const mockEntry: DutyAdjustment = {
    ...proposed,
    id: 'proposed-mock',
    status: 'Pending',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  simulatedAdjustments.push(mockEntry);

  const dayResult = calculateDayDuty(
    proposed.date,
    weeklyRoster,
    shifts,
    simulatedAdjustments,
    persons
  );

  // Check tomorrow for fatigue as well if proposed is Night
  const tomorrowStr = addDays(proposed.date, 1);
  const tomorrowResult = calculateDayDuty(
    tomorrowStr,
    weeklyRoster,
    shifts,
    simulatedAdjustments,
    persons
  );

  const allWarnings = [...dayResult.warnings];

  // If proposed creates a Night shift today, and tomorrow has a Morning shift, append fatigue
  const isNightToday = dayResult.finalShifts.some((s) => s.shiftName.toLowerCase().includes('night'));
  const isMorningTomorrow = tomorrowResult.finalShifts.some((s) => s.shiftName.toLowerCase().includes('morning'));

  if (isNightToday && isMorningTomorrow && !allWarnings.some((w) => w.title.includes('Fatigue Sign'))) {
    allWarnings.push({
      severity: 'warning',
      title: '🟡 YELLOW ALERT — Fatigue Sign (Next Day)',
      message: 'Fatigue Warning: Tomorrow morning duty immediately follows this night duty.',
      details: [
        'Night shift finishes at 07:00 AM tomorrow, and Morning shift begins at 07:01 AM tomorrow.',
      ],
    });
  }

  const hasCriticalConflict = allWarnings.some((w) => w.severity === 'critical');

  return {
    projectedShifts: dayResult.finalShifts.map((s) => ({
      shiftName: s.shiftName,
      timing: s.timing,
    })),
    warnings: allWarnings,
    hasCriticalConflict,
  };
}
