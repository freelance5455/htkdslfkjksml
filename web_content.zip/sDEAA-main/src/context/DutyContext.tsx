import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import {
  DayOfWeek,
  DutyAdjustment,
  Person,
  ShiftDefinition,
  WeeklyRoster,
  DayDutyState,
  DutyBackupData,
} from '../types/duty';
import {
  calculateDayDuty,
  reconcileAdjustmentStatuses,
  formatDateToISO,
  addDays,
} from '../utils/dutyEngine';

interface DutyContextType {
  userName: string;
  setUserName: (name: string) => void;
  employeeId: string;
  isRegistered: boolean;
  registerOfficer: (name: string, employeeId: string, roster: WeeklyRoster) => void;
  weeklyRoster: WeeklyRoster;
  updateWeeklyRoster: (day: DayOfWeek, shiftId: string) => void;
  shifts: ShiftDefinition[];
  addShift: (shift: Omit<ShiftDefinition, 'id'>) => { success: boolean; message?: string };
  updateShift: (id: string, shift: Partial<ShiftDefinition>) => { success: boolean; message?: string };
  deleteShift: (id: string) => { success: boolean; message?: string };
  persons: Person[];
  addPerson: (name: string) => { success: boolean; message?: string };
  updatePerson: (id: string, name: string) => { success: boolean; message?: string };
  deletePerson: (id: string) => { success: boolean; message?: string };
  adjustments: DutyAdjustment[];
  addAdjustment: (adj: Omit<DutyAdjustment, 'id' | 'createdAt' | 'updatedAt' | 'status'>) => DutyAdjustment;
  updateAdjustment: (id: string, adj: Partial<DutyAdjustment>) => void;
  deleteAdjustment: (id: string) => void;
  getDayDuty: (dateStr: string) => DayDutyState;
  frequentNames: Person[];
  dashboardFont: 'script' | 'brush' | 'serif' | 'sans';
  setDashboardFont: (font: 'script' | 'brush' | 'serif' | 'sans') => void;
  exportData: () => DutyBackupData;
  restoreData: (backup: any) => {
    success: boolean;
    message: string;
    summary?: { adjustments: number; shifts: number; persons: number };
  };
  resetToDefaults: () => void;
}

const STORAGE_KEYS = {
  USER_NAME: 'duty_adjust_user_name',
  EMPLOYEE_ID: 'duty_adjust_employee_id',
  IS_REGISTERED: 'duty_adjust_is_registered',
  WEEKLY_ROSTER: 'duty_adjust_weekly_roster',
  SHIFTS: 'duty_adjust_shifts',
  PERSONS: 'duty_adjust_persons',
  ADJUSTMENTS: 'duty_adjust_adjustments',
  DASHBOARD_FONT: 'duty_adjust_dashboard_font',
};

// Initial Default Shifts
const DEFAULT_SHIFTS: ShiftDefinition[] = [
  {
    id: 'shift-morning',
    name: 'Morning',
    startTime: '07:01 AM',
    endTime: '02:00 PM',
  },
  {
    id: 'shift-afternoon',
    name: 'Afternoon',
    startTime: '02:01 PM',
    endTime: '09:00 PM',
  },
  {
    id: 'shift-night',
    name: 'Night',
    startTime: '09:01 PM',
    endTime: '07:00 AM',
    isOvernight: true,
  },
];

// Initial Default Weekly Roster
const DEFAULT_WEEKLY_ROSTER: WeeklyRoster = {
  Saturday: 'shift-afternoon',
  Sunday: 'shift-afternoon',
  Monday: 'shift-afternoon',
  Tuesday: 'shift-afternoon',
  Wednesday: 'shift-afternoon',
  Thursday: 'shift-night',
  Friday: 'shift-night',
};

// Initial Default Persons (with Office protected)
const DEFAULT_PERSONS: Person[] = [
  { id: 'person-office', name: 'Office', isOffice: true, frequencyScore: 10 },
  { id: 'person-ravi', name: 'Ravi', frequencyScore: 9 },
  { id: 'person-sarah', name: 'Sarah Jenkins', frequencyScore: 8 },
  { id: 'person-alex', name: 'Alex Rivera', frequencyScore: 6 },
  { id: 'person-david', name: 'David Chen', frequencyScore: 4 },
  { id: 'person-michael', name: 'Michael Ross', frequencyScore: 3 },
  { id: 'person-priya', name: 'Priya Patel', frequencyScore: 2 },
];

export const DutyContext = createContext<DutyContextType | null>(null);

export const DutyProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isRegistered, setIsRegisteredState] = useState<boolean>(() => {
    return localStorage.getItem(STORAGE_KEYS.IS_REGISTERED) === 'true';
  });

  const [employeeId, setEmployeeIdState] = useState<string>(() => {
    return localStorage.getItem(STORAGE_KEYS.EMPLOYEE_ID) || '';
  });

  const [userName, setUserNameState] = useState<string>(() => {
    return localStorage.getItem(STORAGE_KEYS.USER_NAME) || '';
  });

  const [weeklyRoster, setWeeklyRosterState] = useState<WeeklyRoster>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.WEEKLY_ROSTER);
      const parsed = saved ? JSON.parse(saved) : DEFAULT_WEEKLY_ROSTER;
      // Ensure today's baseline has afternoon shift for the 2 duties showcase
      const todayDay = new Date().toLocaleDateString('en-US', { weekday: 'long' }) as DayOfWeek;
      if (parsed[todayDay] === 'Off' || !parsed[todayDay]) {
        parsed[todayDay] = 'shift-afternoon';
      }
      return parsed;
    } catch {
      return DEFAULT_WEEKLY_ROSTER;
    }
  });

  const [shifts, setShiftsState] = useState<ShiftDefinition[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SHIFTS);
      return saved ? JSON.parse(saved) : DEFAULT_SHIFTS;
    } catch {
      return DEFAULT_SHIFTS;
    }
  });

  const [persons, setPersonsState] = useState<Person[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PERSONS);
      if (saved) {
        const parsed: Person[] = JSON.parse(saved);
        if (!parsed.some((p) => p.name.toLowerCase() === 'ravi')) {
          parsed.splice(1, 0, { id: 'person-ravi', name: 'Ravi', frequencyScore: 9 });
        }
        return parsed;
      }
      return DEFAULT_PERSONS;
    } catch {
      return DEFAULT_PERSONS;
    }
  });

  const [adjustments, setAdjustmentsState] = useState<DutyAdjustment[]>(() => {
    const today = new Date();
    const todayStr = formatDateToISO(today);
    const yesterdayStr = addDays(todayStr, -1);
    const dayBeforeYesterdayStr = addDays(todayStr, -2);
    const pastFiveDaysStr = addDays(todayStr, -5);
    const pastThreeDaysStr = addDays(todayStr, -3);
    const tomorrowStr = addDays(todayStr, 1);
    const nextWeekStr = addDays(todayStr, 4);

    const todayNightAdj: DutyAdjustment = {
      id: 'adj-sample-today-night',
      date: todayStr,
      entryFrom: 'Operations Desk',
      action: "I'll Do",
      personId: 'person-sarah',
      shiftId: 'shift-night',
      remarks: "Covering Sarah Jenkins' night shift today. Performing 2 duties today: Afternoon + Night.",
      status: 'Pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ADJUSTMENTS);
      if (saved) {
        const parsed: DutyAdjustment[] = JSON.parse(saved);
        const hasTodayAdjustment = parsed.some(
          (a) => a.date === todayStr && (a.shiftId === 'shift-night' || a.action === "I'll Do")
        );
        if (!hasTodayAdjustment) {
          return [todayNightAdj, ...parsed];
        }
        return parsed;
      }
    } catch {
      // Fallback
    }

    const initialAdjustments: DutyAdjustment[] = [
      // 0. TODAY: Double duty performing Afternoon (Default Roster) & Night (I'll Do covering Sarah)
      todayNightAdj,
      // 1. Reciprocal completed pair: Alex did my duty 5 days ago, and I did Alex's duty 3 days ago
      {
        id: 'adj-sample-1',
        date: pastFiveDaysStr,
        entryFrom: 'Station HQ',
        action: "He'll Do",
        personId: 'person-alex',
        shiftId: 'shift-afternoon',
        remarks: 'Alex covered my afternoon shift for personal appointment.',
        linkedTransactionId: 'tx-sample-reciprocal-1',
        status: 'Completed',
        createdAt: new Date(Date.now() - 5 * 86400000).toISOString(),
        updatedAt: new Date(Date.now() - 5 * 86400000).toISOString(),
      },
      {
        id: 'adj-sample-2',
        date: pastThreeDaysStr,
        entryFrom: 'Operations Desk',
        action: "I'll Do",
        personId: 'person-alex',
        shiftId: 'shift-morning',
        remarks: 'Returned Alex duty shift as agreed.',
        linkedTransactionId: 'tx-sample-reciprocal-1',
        status: 'Completed',
        createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
        updatedAt: new Date(Date.now() - 3 * 86400000).toISOString(),
      },
      // 2. Day before yesterday: Sarah covered my duty (He'll Do, currently Pending reciprocal)
      {
        id: 'adj-sample-3',
        date: dayBeforeYesterdayStr,
        entryFrom: 'Control Center',
        action: "He'll Do",
        personId: 'person-sarah',
        shiftId: 'shift-afternoon',
        remarks: 'Sarah covered my shift. Need to return duty next week.',
        linkedTransactionId: 'tx-pending-sarah',
        status: 'Pending',
        createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
        updatedAt: new Date(Date.now() - 2 * 86400000).toISOString(),
      },
      // 3. Yesterday: Mutual Shift Exchange with David Chen
      {
        id: 'adj-sample-4',
        date: yesterdayStr,
        entryFrom: 'Main Roster',
        action: 'Shift Exchange',
        personId: 'person-david',
        shiftId: 'shift-morning',
        otherPersonShiftId: 'shift-afternoon',
        remarks: 'Mutual shift trade with David Chen for schedule alignment.',
        linkedTransactionId: 'tx-ex-david',
        status: 'Completed',
        createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
        updatedAt: new Date(Date.now() - 1 * 86400000).toISOString(),
      },
      // 4. Tomorrow: Official duty given to Office
      {
        id: 'adj-sample-5',
        date: tomorrowStr,
        entryFrom: 'Admin Office',
        action: "He'll Do",
        personId: 'person-office',
        shiftId: 'shift-night',
        remarks: 'Official administrative relief sanctioned by Department.',
        linkedTransactionId: 'tx-office-relief',
        status: 'Pending',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      // 5. Future No Duty day
      {
        id: 'adj-sample-6',
        date: nextWeekStr,
        entryFrom: 'Station HQ',
        action: 'No Duty',
        remarks: 'Approved comp-off day.',
        status: 'Pending',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ];

    return initialAdjustments;
  });

  // Reconcile statuses on load and when dependencies change
  const reconciledAdjustments = useMemo(() => {
    return reconcileAdjustmentStatuses(adjustments, persons);
  }, [adjustments, persons]);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.IS_REGISTERED, isRegistered ? 'true' : 'false');
  }, [isRegistered]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.EMPLOYEE_ID, employeeId);
  }, [employeeId]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USER_NAME, userName);
  }, [userName]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.WEEKLY_ROSTER, JSON.stringify(weeklyRoster));
  }, [weeklyRoster]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SHIFTS, JSON.stringify(shifts));
  }, [shifts]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PERSONS, JSON.stringify(persons));
  }, [persons]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ADJUSTMENTS, JSON.stringify(adjustments));
  }, [adjustments]);

  const [dashboardFont, setDashboardFontState] = useState<'script' | 'brush' | 'serif' | 'sans'>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.DASHBOARD_FONT);
      if (saved === 'script' || saved === 'brush' || saved === 'serif' || saved === 'sans') {
        return saved;
      }
      return 'script';
    } catch {
      return 'script';
    }
  });

  const setDashboardFont = (font: 'script' | 'brush' | 'serif' | 'sans') => {
    setDashboardFontState(font);
    try {
      localStorage.setItem(STORAGE_KEYS.DASHBOARD_FONT, font);
    } catch {
      // ignore
    }
  };

  const registerOfficer = (name: string, empId: string, roster: WeeklyRoster) => {
    const trimmedName = name.trim();
    const trimmedEmpId = empId.trim();
    setUserNameState(trimmedName);
    setEmployeeIdState(trimmedEmpId);
    setWeeklyRosterState(roster);
    setIsRegisteredState(true);
    localStorage.setItem(STORAGE_KEYS.USER_NAME, trimmedName);
    localStorage.setItem(STORAGE_KEYS.EMPLOYEE_ID, trimmedEmpId);
    localStorage.setItem(STORAGE_KEYS.WEEKLY_ROSTER, JSON.stringify(roster));
    localStorage.setItem(STORAGE_KEYS.IS_REGISTERED, 'true');
  };

  const setUserName = (name: string) => {
    setUserNameState(name);
  };

  const updateWeeklyRoster = (day: DayOfWeek, shiftId: string) => {
    setWeeklyRosterState((prev) => ({
      ...prev,
      [day]: shiftId,
    }));
  };

  const addShift = (shift: Omit<ShiftDefinition, 'id'>) => {
    const id = `shift-${Date.now()}`;
    const newShift: ShiftDefinition = { ...shift, id };
    setShiftsState((prev) => [...prev, newShift]);
    return { success: true };
  };

  const updateShift = (id: string, updatedFields: Partial<ShiftDefinition>) => {
    setShiftsState((prev) =>
      prev.map((s) => (s.id === id ? { ...s, ...updatedFields } : s))
    );
    return { success: true };
  };

  const deleteShift = (id: string) => {
    // Check if shift is used in roster or adjustments
    const isUsedInRoster = Object.values(weeklyRoster).includes(id);
    const isUsedInAdjustments = adjustments.some(
      (a) => a.shiftId === id || a.otherPersonShiftId === id
    );

    if (isUsedInRoster || isUsedInAdjustments) {
      return {
        success: false,
        message: 'Cannot delete shift because it is currently assigned in the weekly roster or existing duty adjustment records.',
      };
    }

    setShiftsState((prev) => prev.filter((s) => s.id !== id));
    return { success: true };
  };

  const addPerson = (name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return { success: false, message: 'Name cannot be empty' };
    const exists = persons.some((p) => p.name.toLowerCase() === trimmed.toLowerCase());
    if (exists) return { success: false, message: 'A person with this name already exists' };

    const newPerson: Person = {
      id: `person-${Date.now()}`,
      name: trimmed,
      frequencyScore: 1,
    };
    setPersonsState((prev) => [...prev, newPerson]);
    return { success: true };
  };

  const updatePerson = (id: string, name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return { success: false, message: 'Name cannot be empty' };
    const person = persons.find((p) => p.id === id);
    if (person?.isOffice && trimmed.toLowerCase() !== 'office') {
      return { success: false, message: 'Office is a protected system entity and cannot be renamed' };
    }

    setPersonsState((prev) =>
      prev.map((p) => (p.id === id ? { ...p, name: trimmed } : p))
    );
    return { success: true };
  };

  const deletePerson = (id: string) => {
    const person = persons.find((p) => p.id === id);
    if (person?.isOffice) {
      return { success: false, message: 'Office is a protected system entity and cannot be deleted' };
    }

    const isUsed = adjustments.some(
      (a) => a.personId === id || a.otherPersonId === id
    );
    if (isUsed) {
      return {
        success: false,
        message: 'Cannot delete person because they are referenced in duty records.',
      };
    }

    setPersonsState((prev) => prev.filter((p) => p.id !== id));
    return { success: true };
  };

  const addAdjustment = (
    adj: Omit<DutyAdjustment, 'id' | 'createdAt' | 'updatedAt' | 'status'>
  ): DutyAdjustment => {
    const id = `adj-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    const nowIso = new Date().toISOString();
    const newEntry: DutyAdjustment = {
      ...adj,
      id,
      status: 'Pending',
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    // Bump frequency score for person
    if (adj.personId) {
      setPersonsState((prev) =>
        prev.map((p) =>
          p.id === adj.personId ? { ...p, frequencyScore: (p.frequencyScore || 0) + 1 } : p
        )
      );
    }

    setAdjustmentsState((prev) => [newEntry, ...prev]);
    return newEntry;
  };

  const updateAdjustment = (id: string, updatedFields: Partial<DutyAdjustment>) => {
    const nowIso = new Date().toISOString();
    setAdjustmentsState((prev) =>
      prev.map((a) => (a.id === id ? { ...a, ...updatedFields, updatedAt: nowIso } : a))
    );
  };

  const deleteAdjustment = (id: string) => {
    setAdjustmentsState((prev) => prev.filter((a) => a.id !== id));
  };

  const getDayDuty = (dateStr: string): DayDutyState => {
    return calculateDayDuty(dateStr, weeklyRoster, shifts, reconciledAdjustments, persons);
  };

  const frequentNames = useMemo(() => {
    return [...persons].sort((a, b) => (b.frequencyScore || 0) - (a.frequencyScore || 0));
  }, [persons]);

  const exportData = (): DutyBackupData => {
    return {
      version: 1,
      appName: 'DutyAdjust',
      exportedAt: new Date().toISOString(),
      data: {
        userName,
        employeeId,
        isRegistered,
        weeklyRoster,
        shifts,
        persons,
        adjustments,
        dashboardFont,
      },
    };
  };

  const restoreData = (
    backup: any
  ): {
    success: boolean;
    message: string;
    summary?: { adjustments: number; shifts: number; persons: number };
  } => {
    try {
      if (!backup || typeof backup !== 'object') {
        return { success: false, message: 'Invalid backup file: Root content must be a JSON object.' };
      }
      // Support both wrapped backup format { version, appName, data: { ... } } and direct payload
      const payload = backup.data && typeof backup.data === 'object' ? backup.data : backup;

      if (!payload.weeklyRoster && !payload.adjustments && !payload.shifts && !payload.persons) {
        return {
          success: false,
          message: 'Unrecognized format: Backup must contain weekly roster, shifts, colleague directory, or adjustments.',
        };
      }

      if (typeof payload.userName === 'string' && payload.userName.trim()) {
        setUserNameState(payload.userName.trim());
        localStorage.setItem(STORAGE_KEYS.USER_NAME, payload.userName.trim());
      }

      if (typeof payload.employeeId === 'string' && payload.employeeId.trim()) {
        setEmployeeIdState(payload.employeeId.trim());
        localStorage.setItem(STORAGE_KEYS.EMPLOYEE_ID, payload.employeeId.trim());
      }

      if (payload.isRegistered !== undefined) {
        const reg = Boolean(payload.isRegistered);
        setIsRegisteredState(reg);
        localStorage.setItem(STORAGE_KEYS.IS_REGISTERED, reg ? 'true' : 'false');
      }

      if (payload.weeklyRoster && typeof payload.weeklyRoster === 'object') {
        setWeeklyRosterState(payload.weeklyRoster);
        localStorage.setItem(STORAGE_KEYS.WEEKLY_ROSTER, JSON.stringify(payload.weeklyRoster));
      }

      let shiftsCount = 0;
      if (Array.isArray(payload.shifts) && payload.shifts.length > 0) {
        setShiftsState(payload.shifts);
        localStorage.setItem(STORAGE_KEYS.SHIFTS, JSON.stringify(payload.shifts));
        shiftsCount = payload.shifts.length;
      }

      let personsCount = 0;
      if (Array.isArray(payload.persons) && payload.persons.length > 0) {
        setPersonsState(payload.persons);
        localStorage.setItem(STORAGE_KEYS.PERSONS, JSON.stringify(payload.persons));
        personsCount = payload.persons.length;
      }

      let adjustmentsCount = 0;
      if (Array.isArray(payload.adjustments)) {
        setAdjustmentsState(payload.adjustments);
        localStorage.setItem(STORAGE_KEYS.ADJUSTMENTS, JSON.stringify(payload.adjustments));
        adjustmentsCount = payload.adjustments.length;
      }

      if (payload.dashboardFont && ['script', 'brush', 'serif', 'sans'].includes(payload.dashboardFont)) {
        setDashboardFontState(payload.dashboardFont);
        localStorage.setItem(STORAGE_KEYS.DASHBOARD_FONT, payload.dashboardFont);
      }

      return {
        success: true,
        message: 'Data backup successfully restored!',
        summary: {
          adjustments: adjustmentsCount,
          shifts: shiftsCount,
          persons: personsCount,
        },
      };
    } catch (err: any) {
      return { success: false, message: `Restore error: ${err?.message || 'Unknown error'}` };
    }
  };

  const resetToDefaults = () => {
    setUserNameState('');
    setEmployeeIdState('');
    setIsRegisteredState(false);
    setWeeklyRosterState(DEFAULT_WEEKLY_ROSTER);
    setShiftsState(DEFAULT_SHIFTS);
    setPersonsState(DEFAULT_PERSONS);
    setAdjustmentsState([]);
    setDashboardFontState('script');
    localStorage.clear();
  };

  return (
    <DutyContext.Provider
      value={{
        userName,
        setUserName,
        employeeId,
        isRegistered,
        registerOfficer,
        weeklyRoster,
        updateWeeklyRoster,
        shifts,
        addShift,
        updateShift,
        deleteShift,
        persons,
        addPerson,
        updatePerson,
        deletePerson,
        adjustments: reconciledAdjustments,
        addAdjustment,
        updateAdjustment,
        deleteAdjustment,
        getDayDuty,
        frequentNames,
        dashboardFont,
        setDashboardFont,
        exportData,
        restoreData,
        resetToDefaults,
      }}
    >
      {children}
    </DutyContext.Provider>
  );
};

export function useDuty(): DutyContextType {
  const context = useContext(DutyContext);
  if (!context) {
    throw new Error('useDuty must be used within a DutyProvider');
  }
  return context;
}
