/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect, useLayoutEffect } from 'react';
import { DutyProvider, useDuty } from './context/DutyContext';
import { Navbar, ActiveTab } from './components/layout/Navbar';
import { DashboardView } from './components/dashboard/DashboardView';
import { NewEntryView } from './components/entry/NewEntryView';
import { CalendarView } from './components/calendar/CalendarView';
import { HistoryView } from './components/history/HistoryView';
import { MasterView } from './components/master/MasterView';
import { ExportView } from './components/export/ExportView';
import { FirstTimeRegisterView } from './components/registration/FirstTimeRegisterView';
import { DutyAdjustment } from './types/duty';
import { formatDateToISO } from './utils/dutyEngine';

const MainAppContent: React.FC = () => {
  const { isRegistered, adjustments, getDayDuty } = useDuty();

  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [entryPreselectedDate, setEntryPreselectedDate] = useState<string | undefined>(undefined);
  const [editingAdjustment, setEditingAdjustment] = useState<DutyAdjustment | null>(null);
  const [historyFilter, setHistoryFilter] = useState<string | undefined>(undefined);

  // Store separate scrolling positions for each separate tab
  const tabScrollPositions = useRef<Record<ActiveTab, number>>({
    dashboard: 0,
    'new-entry': 0,
    calendar: 0,
    history: 0,
    master: 0,
    export: 0,
  });

  // Track current tab's scroll position as user scrolls
  useEffect(() => {
    const handleScroll = () => {
      tabScrollPositions.current[activeTab] = window.scrollY;
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [activeTab]);

  // Restore the target tab's scroll position immediately upon tab switch
  useLayoutEffect(() => {
    const targetY = tabScrollPositions.current[activeTab] ?? 0;
    window.scrollTo({ top: targetY, left: 0, behavior: 'instant' as ScrollBehavior });

    const rafId = requestAnimationFrame(() => {
      window.scrollTo({ top: targetY, left: 0, behavior: 'instant' as ScrollBehavior });
    });
    return () => cancelAnimationFrame(rafId);
  }, [activeTab]);

  if (!isRegistered) {
    return <FirstTimeRegisterView />;
  }

  const pendingCount = adjustments.filter((a) => a.status === 'Pending').length;

  const todayStr = formatDateToISO(new Date());
  const todayState = getDayDuty(todayStr);
  const activeAlertCount = todayState.warnings.filter(
    (w) => w.severity === 'critical' || w.severity === 'warning'
  ).length;

  const switchTab = (nextTab: ActiveTab) => {
    if (nextTab === activeTab) return;
    tabScrollPositions.current[activeTab] = window.scrollY;
    if (nextTab === 'new-entry' && activeTab !== 'new-entry') {
      setEditingAdjustment(null);
      setEntryPreselectedDate(undefined);
    }
    setActiveTab(nextTab);
  };

  const handleNavigateToEntry = (date?: string) => {
    tabScrollPositions.current[activeTab] = window.scrollY;
    setEditingAdjustment(null);
    setEntryPreselectedDate(date);
    tabScrollPositions.current['new-entry'] = 0;
    setActiveTab('new-entry');
  };

  const handleEditAdjustment = (adj: DutyAdjustment) => {
    tabScrollPositions.current[activeTab] = window.scrollY;
    setEditingAdjustment(adj);
    setEntryPreselectedDate(adj.date);
    tabScrollPositions.current['new-entry'] = 0;
    setActiveTab('new-entry');
  };

  const handleNavigateToCalendar = () => {
    switchTab('calendar');
  };

  const handleNavigateToHistory = (filter?: string) => {
    tabScrollPositions.current[activeTab] = window.scrollY;
    setHistoryFilter(filter);
    if (filter) {
      tabScrollPositions.current['history'] = 0;
    }
    setActiveTab('history');
  };

  const handleNavigateToExport = () => {
    switchTab('export');
  };

  const handleEntrySuccess = () => {
    setEditingAdjustment(null);
    setEntryPreselectedDate(undefined);
    tabScrollPositions.current['new-entry'] = 0;
    setActiveTab('dashboard');
  };

  const handleEntryCancel = () => {
    setEditingAdjustment(null);
    setEntryPreselectedDate(undefined);
    tabScrollPositions.current['new-entry'] = 0;
    setActiveTab('dashboard');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* Header & Nav */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={switchTab}
        pendingCount={pendingCount}
        alertCount={activeAlertCount}
      />

      {/* Main Container: Separate DOM container and separate scrolling position per tab */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 pt-5 pb-24 md:pb-16 overflow-x-hidden">
        <div style={{ display: activeTab === 'dashboard' ? 'block' : 'none' }}>
          <DashboardView
            onNavigateToEntry={handleNavigateToEntry}
            onNavigateToCalendar={handleNavigateToCalendar}
            onNavigateToHistory={handleNavigateToHistory}
            onNavigateToExport={handleNavigateToExport}
          />
        </div>

        <div style={{ display: activeTab === 'new-entry' ? 'block' : 'none' }}>
          <NewEntryView
            key={editingAdjustment ? editingAdjustment.id : (entryPreselectedDate || 'new-entry')}
            initialDate={entryPreselectedDate}
            editingAdjustment={editingAdjustment}
            onSuccess={handleEntrySuccess}
            onCancel={handleEntryCancel}
          />
        </div>

        <div style={{ display: activeTab === 'calendar' ? 'block' : 'none' }}>
          <CalendarView
            onNewAdjustment={handleNavigateToEntry}
            onEditAdjustment={handleEditAdjustment}
          />
        </div>

        <div style={{ display: activeTab === 'history' ? 'block' : 'none' }}>
          <HistoryView
            key={historyFilter || 'history-all'}
            initialFilter={historyFilter}
            onEditAdjustment={handleEditAdjustment}
            onNewAdjustment={() => handleNavigateToEntry()}
          />
        </div>

        <div style={{ display: activeTab === 'master' ? 'block' : 'none' }}>
          <MasterView />
        </div>

        <div style={{ display: activeTab === 'export' ? 'block' : 'none' }}>
          <ExportView />
        </div>
      </main>
    </div>
  );
};

export default function App() {
  return (
    <DutyProvider>
      <MainAppContent />
    </DutyProvider>
  );
}
