/* Service Worker: تخزين كل الملفات مسبقًا ليعمل التطبيق كاملًا دون اتصال */
const VERSION = 'midad-v1.0.0';
const FILES = ['./', 'index.html', 'manifest.webmanifest', 'css/app.css', 'css/themes.css',
  'fonts/midad-naskh-400.woff', 'fonts/midad-naskh-700.woff', 'fonts/midad-sans-400.woff', 'fonts/midad-sans-700.woff',
  'icons/icon.svg', 'icons/icon-192.png', 'icons/icon-512.png', 'icons/icon-maskable-512.png',
  'js/core/quran.js', 'js/core/dates.js', 'js/core/store.js', 'js/logic/ranges.js', 'js/logic/review.js', 'js/logic/progress.js', 'js/logic/plan.js',
  'js/logic/calendar.js', 'js/logic/growth.js', 'js/logic/backup.js', 'js/ui/color.js', 'js/ui/art.js', 'js/ui/themes.js', 'js/ui/icons.js', 'js/ui/dom.js',
  'js/views/home.js', 'js/views/session.js', 'js/views/plan.js', 'js/views/review.js', 'js/views/puzzle.js', 'js/views/progress.js', 'js/views/calendar.js',
  'js/views/garden.js', 'js/views/themes.js', 'js/views/settings.js', 'js/views/more.js', 'js/app.js'];
self.addEventListener('install', e => { e.waitUntil(caches.open(VERSION).then(c => c.addAll(FILES)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const req = e.request; if (req.method !== 'GET' || new URL(req.url).origin !== location.origin) return;
  e.respondWith(caches.match(req, { ignoreSearch: true }).then(hit => hit || fetch(req).then(res => {
    if (res.ok) { const copy = res.clone(); caches.open(VERSION).then(c => c.put(req, copy)); } return res;
  }).catch(() => req.mode === 'navigate' ? caches.match('index.html') : Response.error())));
});
self.addEventListener('notificationclick', e => { e.notification.close(); e.waitUntil(clients.matchAll({ type: 'window' }).then(l => l.length ? l[0].focus() : clients.openWindow('./'))); });
