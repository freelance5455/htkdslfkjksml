/* اختبارات منطق التطبيق (Node بدون أي اعتماديات): node tests/unit.test.js */
const path = require('path'), assert = require('assert');
['core/quran', 'core/dates', 'logic/ranges', 'core/store', 'logic/review', 'logic/progress', 'logic/plan', 'logic/calendar', 'logic/growth', 'logic/backup']
  .forEach(f => require(path.join(__dirname, '..', 'js', f + '.js')));
const M = globalThis.M, Q = M.quran, D = M.dates, PL = M.plan, V = M.review, P = M.progress;
let pass = 0, fail = 0;
function t(name, fn) { try { fn(); pass++; console.log('  ✓', name); } catch (e) { fail++; console.log('  ✗', name, '\n   ', e.message); } }
const fresh = () => M.store.defaultState();
const T0 = '2026-11-21'; // سبت
function mkPlan(st, over, today) { const inp = Object.assign(PL.defaults(), over || {}); const r = PL.create(st, inp, today || T0); assert(r.ok, JSON.stringify(r.errors)); return r.plan; }

console.log('بيانات القرآن');
t('114 سورة بالترتيب دون تكرار', () => { assert.equal(Q.SURAHS.length - 1, 114); assert.equal(new Set(Q.SURAHS.slice(1).map(s => s.name)).size, 114); Q.SURAHS.slice(1).forEach((s, i) => assert.equal(s.n, i + 1)); });
t('مجموع الآيات 6236', () => assert.equal(Q.TOTAL_AYAT, 6236));
t('أعداد آيات معروفة', () => { const c = n => Q.count(n); assert.deepEqual([c(1), c(2), c(18), c(36), c(55), c(67), c(112), c(114)], [7, 286, 110, 83, 78, 30, 4, 6]); assert.equal(Q.name(67), 'الملك'); assert.equal(Q.name(1), 'الفاتحة'); assert.equal(Q.name(114), 'الناس'); });
t('الفهرس العام ذهابًا وإيابًا', () => { for (let i = 1; i <= 6236; i += 7) { const p = Q.fromIdx(i); assert.equal(Q.toIdx(p.s, p.a), i); } });
t('تقسيم المقاطع عبر السور', () => assert.deepEqual(Q.segments(Q.toIdx(1, 6), Q.toIdx(2, 2)), [{ s: 1, from: 6, to: 7 }, { s: 2, from: 1, to: 2 }]));

console.log('مجالات الآيات');
t('إضافة ودمج وإزالة', () => { const R = M.ranges; let r = R.add([], 1, 5).ranges; r = R.add(r, 6, 8).ranges; assert.deepEqual(r, [[1, 8]]); const x = R.add(r, 5, 12); assert.deepEqual(x.added, [[9, 12]]); assert.equal(R.count(x.ranges), 12); assert.deepEqual(R.remove(x.ranges, 3, 4), [[1, 2], [5, 12]]); });

console.log('خطة الحفظ');
t('البداية الافتراضية سورة الملك آية ١ ويمكن تغييرها', () => { const d = PL.defaults(); assert.equal(d.startS, 67); assert.equal(d.startA, 1); const st = fresh(); const p = mkPlan(st, { startS: 2, startA: 255, endS: 3, endA: 10 }); assert.equal(p.startS, 2); assert.equal(p.cursor, Q.toIdx(2, 255)); });
t('لا يفترض حفظًا سابقًا', () => { const st = fresh(); mkPlan(st); assert.equal(P.totals(st).memorized, 0); assert.equal(P.totals(st).done, 0); });
t('التحقق من المدخلات', () => {
  assert(!PL.validate(Object.assign(PL.defaults(), { startA: 31 })).ok);
  assert(!PL.validate(Object.assign(PL.defaults(), { startS: 114, startA: 1, endS: 67, endA: 1 })).ok);
  assert(!PL.validate(Object.assign(PL.defaults(), { value: 0 })).ok);
  assert(!PL.validate(Object.assign(PL.defaults(), { days: { 0: 'rest', 1: 'rest', 2: 'rest', 3: 'rest', 4: 'rest', 5: 'rest', 6: 'opt' } })).ok);
  assert(PL.validate(Object.assign(PL.defaults(), { unit: 'page', value: 1 })).ok);
});
t('وحدات الحفظ', () => { assert.equal(Q.unitAyat('ayat', 7), 7); assert.equal(Q.unitAyat('page', 1), 10); assert.equal(Q.unitAyat('half', 1), 5); assert.equal(Q.unitAyat('quarter', 1), 3); assert.equal(Q.unitAyat('page', 2), 20); assert.equal(Q.unitAyat('custom', 4), 4); });
t('ورد اليوم الأول = ٥ آيات من الملك', () => { const st = fresh(); mkPlan(st); const p = PL.pending(st, T0); assert.equal(p.status, 'ready'); assert.equal(p.forDate, T0); assert.deepEqual(p.segments, [{ s: 67, from: 1, to: 5 }]); assert(p.isToday); });
t('إتمام الورد يسجل ويحدث التقدم والمراجعة ويولد ورد اليوم التالي', () => {
  const st = fresh(); mkPlan(st); const p1 = PL.pending(st, T0);
  const r = PL.complete(st, { key: p1.key, today: T0 }); assert(r.ok);
  assert.equal(P.memorized(st, 67), 5); assert.equal(P.status(st, 67), 'progress');
  assert.equal(st.reviews.length, 1); assert.equal(st.reviews[0].due, '2026-11-22'); // مراجعة أولى في اليوم التالي
  const p2 = PL.pending(st, T0); assert.deepEqual(p2.segments, [{ s: 67, from: 6, to: 10 }]); assert.equal(p2.forDate, '2026-11-22'); assert(p2.isAhead);
});
t('منع تكرار الإنجاز نفسه (نفس المفتاح)', () => {
  const st = fresh(); mkPlan(st); const p1 = PL.pending(st, T0);
  assert(PL.complete(st, { key: p1.key, today: T0 }).ok);
  const again = PL.complete(st, { key: p1.key, today: T0 }); assert(!again.ok); assert.equal(again.reason, 'duplicate');
  assert.equal(st.activity.filter(a => a.type === 'mem').length, 1); assert.equal(P.memorized(st, 67), 5);
});
t('إنجاز أيام متتالية، كل يوم بسجل مستقل وتحديث كامل', () => {
  const st = fresh(); mkPlan(st); let day = T0; // سبت
  for (let i = 0; i < 4; i++) { const p = PL.pending(st, day); const r = PL.complete(st, { key: p.key, today: day }); assert(r.ok, 'day ' + i); day = D.addDays(day, 1); }
  assert.equal(P.memorized(st, 67), 20); assert.equal(st.activity.filter(a => a.type === 'mem').length, 4);
  assert.equal(new Set(st.activity.map(a => a.key)).size, 4);
  assert.equal(st.reviews.length, 4);
});
t('اكتمال السورة عند وصول الآيات للإجمالي', () => {
  const st = fresh(); mkPlan(st, { endS: 67, endA: 30 }); let day = T0, n = 0;
  while (PL.pending(st, day).status === 'ready' && n < 40) { const p = PL.pending(st, day); PL.complete(st, { key: p.key, today: p.forDate }); day = D.addDays(p.forDate, 1); n++; }
  assert.equal(P.memorized(st, 67), 30); assert.equal(P.status(st, 67), 'done'); assert.equal(PL.active(st).status, 'done'); assert.equal(PL.pending(st, day).status, 'done');
});
t('الإنجاز عبر سورتين يوزع التقدم', () => {
  const st = fresh(); mkPlan(st, { startS: 1, startA: 6, endS: 2, endA: 10, value: 5 }); const p = PL.pending(st, T0);
  PL.complete(st, { key: p.key, today: T0 }); assert.equal(P.memorized(st, 1), 2); assert.equal(P.memorized(st, 2), 3);
});
t('تعديل الخطة يعيد حساب الورد فورًا ويحفظ السجل', () => {
  const st = fresh(); const pl = mkPlan(st); const p = PL.pending(st, T0); PL.complete(st, { key: p.key, today: T0 });
  const inp = Object.assign(PL.defaults(), { unit: 'page', value: 1, startS: 67, startA: 1 });
  assert(PL.update(st, pl.id, inp, T0).ok);
  const p2 = PL.pending(st, T0); assert.equal(p2.ayat, 10); assert.deepEqual(p2.segments, [{ s: 67, from: 6, to: 15 }]);
  assert.equal(st.activity.filter(a => a.type === 'mem').length, 1); assert.equal(P.memorized(st, 67), 5);
});
t('تغيير سورة البداية والهدف', () => {
  const st = fresh(); const pl = mkPlan(st);
  assert(PL.update(st, pl.id, Object.assign(PL.defaults(), { startS: 78, startA: 1, endS: 78, endA: 10 }), T0).ok);
  assert.deepEqual(PL.pending(st, T0).segments, [{ s: 78, from: 1, to: 5 }]); assert.equal(PL.pending(st, T0).remaining, 5);
  assert(PL.update(st, pl.id, Object.assign(PL.defaults(), { startS: 78, startA: 1, endS: 79, endA: 20 }), T0).ok);
  assert.equal(Q.fromIdx(PL.endIdx(PL.active(st))).s, 79);
});
t('إيقاف مؤقت واستئناف وإعادة بدء وخطة جديدة', () => {
  const st = fresh(); mkPlan(st); const p = PL.pending(st, T0); PL.complete(st, { key: p.key, today: T0 });
  assert(PL.pause(st, '2026-11-22')); assert.equal(PL.pending(st, '2026-11-23').status, 'paused');
  assert(PL.resume(st, '2026-11-25')); assert.equal(PL.pending(st, '2026-11-25').status, 'ready'); assert.equal(PL.pending(st, '2026-11-25').forDate, '2026-11-25');
  assert.equal(PL.pending(st, '2026-11-25').i1, Q.toIdx(67, 6));
  assert(PL.restart(st, '2026-11-26')); assert.equal(PL.pending(st, '2026-11-26').i1, Q.toIdx(67, 1)); assert.equal(P.memorized(st, 67), 5, 'السجل محفوظ');
  const old = PL.active(st).id; const n = PL.create(st, Object.assign(PL.defaults(), { startS: 1, startA: 1, endS: 1, endA: 7 }), '2026-11-26'); assert(n.ok);
  assert.equal(st.plans.length, 2); assert.equal(PL.get(st, old).status, 'ended'); assert.equal(P.memorized(st, 67), 5);
});
t('التراجع عن إنجاز يعيد الحالة', () => {
  const st = fresh(); mkPlan(st); const p = PL.pending(st, T0); const r = PL.complete(st, { key: p.key, today: T0 });
  assert(PL.undo(st, r.entry.id)); assert.equal(P.memorized(st, 67), 0); assert.equal(st.reviews.length, 0); assert.equal(PL.pending(st, T0).key, p.key);
  assert(PL.complete(st, { key: p.key, today: T0 }).ok);
});
t('يوم الراحة لا ينتج ورد حفظ والتقدم يتجاوز اليوم الفائت دون تراكم', () => {
  const st = fresh(); mkPlan(st); // الجمعة opt
  const fri = '2026-11-27'; assert.equal(PL.dayType(PL.active(st), fri), 'opt');
  const p = PL.pending(st, D.addDays(T0, 5)); assert.equal(p.forDate, '2026-11-26'); // خميس
  const p2 = PL.pending(st, fri); assert.equal(p2.forDate, '2026-11-28'); assert(!p2.isToday);
  const late = PL.pending(st, '2026-11-30'); assert.equal(late.ayat, 5, 'ورد واحد فقط رغم الغياب');
});
t('إعادة جدولة الورد لتاريخ آخر', () => { const st = fresh(); mkPlan(st); assert(PL.reschedule(st, '2026-11-24', T0)); assert.equal(PL.pending(st, T0).forDate, '2026-11-24'); assert(!PL.reschedule(st, '2026-11-01', T0)); });

console.log('المراجعة');
t('فواصل التقييم', () => {
  const iv = [1, 3, 7, 14, 30];
  assert.deepEqual(V.next(iv, 0, 'good'), { stage: 1, days: 3 }); assert.deepEqual(V.next(iv, 1, 'excellent'), { stage: 3, days: 14 });
  assert.deepEqual(V.next(iv, 3, 'needs'), { stage: 2, days: 7 }); assert.deepEqual(V.next(iv, 3, 'weak'), { stage: 0, days: 1 });
  assert.deepEqual(V.next(iv, 4, 'good'), { stage: 4, days: 30 }); assert.equal(V.next(iv, 4, 'excellent').days, 45);
});
t('الضعيف يعود أقرب من المتقن', () => {
  const st = fresh(); mkPlan(st); const p = PL.pending(st, T0); PL.complete(st, { key: p.key, today: T0 });
  const a = st.reviews[0]; V.rate(st, a.id, 'good', '2026-11-22'); V.rate(st, a.id, 'excellent', '2026-11-22');
  const dEx = D.diff(a.due, '2026-11-22'); V.rate(st, a.id, 'weak', '2026-11-22'); const dWk = D.diff(a.due, '2026-11-22');
  assert(dWk < dEx, dWk + ' < ' + dEx); assert.equal(dWk, 1); assert.equal(P.status(st, 67), 'review');
});
t('إعادة التقييم في اليوم نفسه لا تضاعف التقدم', () => {
  const st = fresh(); mkPlan(st); const p = PL.pending(st, T0); PL.complete(st, { key: p.key, today: T0 }); const a = st.reviews[0];
  V.rate(st, a.id, 'good', '2026-11-22'); V.rate(st, a.id, 'good', '2026-11-22');
  assert.equal(a.stage, 1); assert.equal(a.due, '2026-11-25'); assert.equal(st.activity.filter(x => x.type === 'rev').length, 1);
});
t('تقييم جيد يزيل علامة المراجعة', () => {
  const st = fresh(); mkPlan(st); const p = PL.pending(st, T0); PL.complete(st, { key: p.key, today: T0 }); const a = st.reviews[0];
  V.rate(st, a.id, 'weak', '2026-11-22'); assert.equal(P.status(st, 67), 'review'); V.rate(st, a.id, 'good', '2026-11-23'); assert.equal(P.status(st, 67), 'progress');
});
t('تأجيل وتغيير موعد وإضافة يدوية وحذف وإنهاء', () => {
  const st = fresh(); const r = V.addManual(st, { s: 2, from: 1, to: 5, due: '2026-11-30' }, T0); assert(r.ok);
  assert(!V.addManual(st, { s: 2, from: 1, to: 500 }, T0).ok); assert(!V.addManual(st, { s: 2, from: 1, to: 5, due: '2026-11-30' }, T0).ok, 'منع التكرار');
  V.postpone(st, r.item.id, 2, T0); assert.equal(r.item.due, '2026-11-23'); V.reschedule(st, r.item.id, '2026-12-01'); assert.equal(r.item.due, '2026-12-01');
  V.retire(st, r.item.id, T0); assert.equal(V.pending(st).length, 0); V.remove(st, r.item.id); assert.equal(st.reviews.length, 0);
});
t('إعادة تنظيم المتأخرات بحد يومي', () => {
  const st = fresh(); st.settings.review.dailyCap = 5;
  for (let i = 0; i < 17; i++) V.create(st, { s: 3, from: i + 1, to: i + 1, due: D.addDays(T0, -(i % 6) - 1), src: 'manual' });
  const before = V.today(st, T0); assert.equal(before.total, 17); assert.equal(before.visible.length, 5); assert.equal(before.hidden, 12);
  const r = V.reorganize(st, T0); assert.equal(r.days, 4);
  assert.equal(V.today(st, T0).total, 5); const by = {}; V.pending(st).forEach(x => by[x.due] = (by[x.due] || 0) + 1); Object.values(by).forEach(n => assert(n <= 5));
  assert(V.pending(st).every(x => x.due >= T0));
});
t('المراجعات المستحقة غير مرهقة ومرتبة بالأولوية', () => {
  const st = fresh(); const a = V.create(st, { s: 3, from: 1, to: 2, due: '2026-11-01' }); const b = V.create(st, { s: 4, from: 1, to: 2, due: '2026-11-10' }); b.lastRating = 'weak';
  assert.equal(V.dueBy(st, T0)[0].id, b.id);
});

console.log('البازل والتقدم');
t('الحالات الأربع', () => {
  const st = fresh(); assert.equal(P.status(st, 67), 'none');
  P.setMemorized(st, 67, 10, T0); assert.equal(P.status(st, 67), 'progress'); assert.equal(P.memorized(st, 67), 10);
  P.setMemorized(st, 67, 30, T0); assert.equal(P.status(st, 67), 'done');
  P.setStatus(st, 67, 'review', T0); assert.equal(P.status(st, 67), 'review'); assert(V.pending(st).length === 1);
  P.setStatus(st, 67, 'done', T0); assert.equal(P.status(st, 67), 'done');
  P.reset(st, 67, T0); assert.equal(P.status(st, 67), 'none'); assert.equal(P.memorized(st, 67), 0); assert.equal(V.pending(st).length, 0);
});
t('لا تُعدّ السورة مكتملة إلا صراحةً أو باكتمال الآيات', () => { const st = fresh(); P.setMemorized(st, 1, 6, T0); assert.equal(P.status(st, 1), 'progress'); P.setMemorized(st, 1, 7, T0); assert.equal(P.status(st, 1), 'done'); });
t('تحديد "تحتاج مراجعة" لسورة فارغة مرفوض', () => { const st = fresh(); assert.equal(P.setStatus(st, 5, 'review', T0).ok, false); });
t('الإحصائيات تطابق البيانات', () => {
  const st = fresh(); P.setMemorized(st, 1, 7, T0); P.setMemorized(st, 112, 2, T0); P.setMemorized(st, 114, 6, T0); P.setStatus(st, 114, 'review', T0);
  const t = P.totals(st); assert.equal(t.memorized, 15); assert.equal(t.done, 1); assert.equal(t.progress, 1); assert.equal(t.review, 1); assert.equal(t.none, 111); assert.equal(t.done + t.progress + t.review + t.none, 114);
  assert(Math.abs(t.pct - 15 / 6236 * 100) < 1e-9);
});
t('سلاسل أسبوعية وشهرية من البيانات الفعلية', () => {
  const st = fresh(); mkPlan(st); let day = T0; for (let i = 0; i < 3; i++) { const p = PL.pending(st, day); PL.complete(st, { key: p.key, today: day }); day = D.addDays(day, 1); }
  assert.equal(P.daily(st, '2026-11-23', 7).reduce((n, x) => n + x.ayahs, 0), 15); assert.equal(P.weekly(st, '2026-11-23', 6, 2).pop().ayahs, 15); assert.equal(P.monthly(st, '2026-11-23', 3).pop().ayahs, 15);
});

console.log('التقويم والنمو');
t('مؤشرات التقويم', () => {
  const st = fresh(); mkPlan(st); const p = PL.pending(st, T0); PL.complete(st, { key: p.key, today: T0 });
  const c = (d, today) => M.calendar.dayInfo(st, d, today);
  assert(c(T0, '2026-11-23').done); assert(!c(T0, '2026-11-23').missed);
  assert(c('2026-11-22', '2026-11-23').missed, 'الأحد فائت'); assert.equal(c('2026-11-27', '2026-11-23').type, 'opt');
  assert.equal(c('2026-11-24', '2026-11-23').projection.segments[0].from, 11 + 0 * 5 + 0, 'الإسقاط');
  assert(c('2026-11-22', '2026-11-22').revDue.length === 1);
  const cells = M.calendar.month(st, 2026, 10, '2026-11-23'); assert.equal(cells.length % 7, 0); assert.equal(cells.filter(x => x.inMonth).length, 30);
});
t('النمو لا يُمحى بيوم فائت', () => {
  const st = fresh(); mkPlan(st); let day = T0; for (let i = 0; i < 4; i++) { const p = PL.pending(st, day); PL.complete(st, { key: p.key, today: day }); day = D.addDays(day, 1); }
  const g1 = M.growth.compute(st, '2026-11-24'); assert.equal(g1.days, 4); assert.equal(g1.stage, 1);
  const g2 = M.growth.compute(st, '2026-12-20'); assert.equal(g2.days, 4); assert.equal(g2.stage, 1, 'المرحلة لا تتراجع'); assert.equal(g2.best >= 4, true);
});

console.log('النسخ الاحتياطي');
t('تصدير ثم استيراد يعيد البيانات نفسها', () => {
  const st = fresh(); mkPlan(st); const p = PL.pending(st, T0); PL.complete(st, { key: p.key, today: T0 }); P.setMemorized(st, 1, 3, T0); st.settings.theme = 'night';
  const txt = JSON.stringify(M.backup.build(st)); const r = M.backup.inspect(txt); assert(r.ok, JSON.stringify(r.errors));
  assert.deepEqual(r.state.progress, st.progress); assert.deepEqual(r.state.plans, st.plans); assert.deepEqual(r.state.reviews, st.reviews); assert.deepEqual(r.state.activity, st.activity); assert.equal(r.state.settings.theme, 'night');
});
t('رفض الملفات غير الصالحة دون لمس البيانات', () => {
  assert(!M.backup.inspect('not json').ok); assert(!M.backup.inspect('{"a":1}').ok); assert(!M.backup.inspect(JSON.stringify({ app: 'midad', schema: 99, data: {} })).ok);
  assert(!M.backup.inspect(JSON.stringify({ app: 'midad', schema: 1, data: { progress: 5 } })).ok);
  const bad = M.backup.inspect(JSON.stringify({ app: 'midad', schema: 1, data: { progress: { 1: { ranges: [[1, 99], [2, 3]] }, 999: {} }, plans: [{ id: 'x' }] } }));
  assert(bad.ok); assert.deepEqual(bad.state.progress[1].ranges, [[2, 3]]); assert.equal(bad.state.plans.length, 0); assert(bad.warnings.length >= 2);
});
t('منع السجلات المكررة عند الاستيراد', () => {
  const st = fresh(); mkPlan(st); const p = PL.pending(st, T0); const r = PL.complete(st, { key: p.key, today: T0 });
  const dup = JSON.parse(JSON.stringify(r.entry)); dup.id = 'other'; const b = M.backup.build(st); b.data.activity.push(dup);
  const i = M.backup.inspect(JSON.stringify(b)); assert(i.ok); assert.equal(i.state.activity.filter(a => a.type === 'mem').length, 1);
});

console.log(`\n${pass} نجح، ${fail} فشل`); process.exit(fail ? 1 : 0);
