/* اختبار المسارات الفعلية في متصفح Chromium: node tests/e2e.test.js (يتطلب playwright) */
const http = require('http'), fs = require('fs'), path = require('path'), assert = require('assert');
const { chromium } = require('playwright');
const ROOT = path.join(__dirname, '..'), MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.svg': 'image/svg+xml', '.woff': 'font/woff' };
const srv = http.createServer((q, r) => { let f = path.join(ROOT, decodeURIComponent(q.url.split('?')[0])); if (f.endsWith('/')) f += 'index.html'; fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); r.end(); } else { r.writeHead(200, { 'content-type': MIME[path.extname(f)] || 'application/octet-stream' }); r.end(d); } }); });
let pass = 0, fail = 0; const results = [];
async function t(name, fn) { try { await fn(); pass++; console.log('  ✓', name); } catch (e) { fail++; console.log('  ✗', name, '\n     ', String(e.message).split('\n').slice(0, 4).join('\n      ')); } }
const AR = d => String(d).replace(/\d/g, x => '٠١٢٣٤٥٦٧٨٩'[x]);

(async () => {
  await new Promise(r => srv.listen(0, r)); const URL = 'http://localhost:' + srv.address().port + '/index.html';
  const browser = await chromium.launch();
  const jsErrors = [];
  function decorate(page) {
    page.setDay = async (iso) => { await page.clock.setFixedTime(new Date(iso + 'T10:00:00+02:00')); await page.evaluate(() => document.dispatchEvent(new Event('visibilitychange'))); await page.waitForTimeout(120); };
    page.go = async (r) => { await page.evaluate(x => { location.hash = '#/' + x; }, r); await page.waitForTimeout(150); };
    page.st = () => page.evaluate(() => JSON.parse(JSON.stringify(M.store.state)));
    page.tid = id => page.locator(`[data-testid="${id}"]`);
  }
  async function fresh(opts = {}) {
    const ctx = await browser.newContext(Object.assign({ viewport: { width: 390, height: 800 }, timezoneId: 'Africa/Cairo', locale: 'ar-EG', acceptDownloads: true }, opts));
    const page = await ctx.newPage(); page.on('pageerror', e => jsErrors.push(e.message)); page.on('console', m => { if (m.type() === 'error') jsErrors.push(m.text()); });
    await page.clock.setFixedTime(new Date('2026-11-21T10:00:00+02:00')); // سبت
    await page.goto(URL); await page.waitForFunction(() => window.__midadReady);
    decorate(page);
    return { ctx, page };
  }
  async function withPlan(over) { const c = await fresh(); await c.page.go('plan'); if (over) await over(c.page); await c.page.tid('plan-save').click(); await c.page.waitForTimeout(250); return c; }

  console.log('البازل');
  let c = await fresh(); let page = c.page;
  await t('1) ظهور جميع السور الـ114 مع الأسماء والعداد 114 / 114', async () => {
    await page.go('puzzle'); assert.equal(await page.locator('.pz').count(), 114);
    assert.equal((await page.tid('surah-counter').innerText()).trim(), '١١٤ / ١١٤ سورة');
    const names = await page.$$eval('.pz .pz-name', e => e.map(x => x.textContent)); const exp = await page.evaluate(() => M.quran.SURAHS.slice(1).map(s => s.name));
    assert.deepEqual(names, exp); assert.equal(new Set(names).size, 114);
    assert.equal(await page.evaluate(() => M.quran.TOTAL_AYAT), 6236);
  });
  await t('2) فتح لوحة التعديل لكل قطعة (114)', async () => {
    const bad = [];
    for (let i = 1; i <= 114; i++) {
      await page.evaluate(s => document.querySelector(`.pz[data-s="${s}"]`).dispatchEvent(new MouseEvent('click', { bubbles: true })), i);
      const title = await page.locator('.sheet-title').first().innerText().catch(() => '');
      const total = await page.evaluate(s => M.quran.count(s), i), nm = await page.evaluate(s => M.quran.name(s), i);
      const memTxt = await page.tid('pz-mem').innerText();
      if (!title.includes(nm) || !memTxt.includes(AR(total))) bad.push(i);
      await page.keyboard.press('Escape'); await page.waitForTimeout(210);
    }
    assert.deepEqual(bad, []); assert.equal(await page.locator('.sheet').count() <= 1, true);
  });
  await t('3-5) تعديل الحالة يدويًا وعدد الآيات وإكمال السورة وتحديث البازل', async () => {
    const open = async s => { await page.evaluate(s => document.querySelector(`.pz[data-s="${s}"]`).dispatchEvent(new MouseEvent('click', { bubbles: true })), s); await page.waitForTimeout(80); };
    await open(67); await page.tid('pz-count').fill('10'); await page.tid('pz-save-count').click(); await page.waitForTimeout(100);
    assert.equal(await page.locator('.pz[data-s="67"]').getAttribute('data-st'), 'progress'); assert.equal((await page.tid('pz-mem').innerText()).trim(), '١٠ / ٣٠');
    await page.tid('pz-count').fill('31'); await page.tid('pz-save-count').click(); assert.match(await page.tid('pz-err').innerText(), /عددًا صحيحًا/);
    await page.tid('pz-count').fill('-3'); await page.tid('pz-save-count').click(); assert.match(await page.tid('pz-err').innerText(), /عددًا صحيحًا/);
    assert.equal((await page.st()).progress[67].ranges[0][1], 10, 'القيم الخاطئة لم تغيّر البيانات');
    await page.tid('pz-complete').click(); await page.waitForTimeout(100);
    assert.equal(await page.locator('.pz[data-s="67"]').getAttribute('data-st'), 'done'); assert.equal((await page.tid('pz-mem').innerText()).trim(), '٣٠ / ٣٠');
    await page.tid('st-review').click(); await page.waitForTimeout(100); assert.equal(await page.locator('.pz[data-s="67"]').getAttribute('data-st'), 'review');
    await page.tid('st-none').click(); await page.tid('confirm-ok').click(); await page.waitForTimeout(100); assert.equal(await page.locator('.pz[data-s="67"]').getAttribute('data-st'), 'none');
    await page.keyboard.press('Escape'); await page.waitForTimeout(220);
    await open(1); await page.tid('pz-count').fill('7'); await page.tid('pz-save-count').click(); await page.waitForTimeout(100);
    assert.equal(await page.locator('.pz[data-s="1"]').getAttribute('data-st'), 'done', 'اكتمال الآيات = مكتملة تلقائيًا');
    await page.keyboard.press('Escape'); await page.waitForTimeout(220);
    await open(2); await page.tid('pz-count').fill('5'); await page.tid('pz-save-count').click(); await page.tid('pz-reset').click(); await page.tid('confirm-ok').click(); await page.waitForTimeout(100);
    assert.equal(await page.locator('.pz[data-s="2"]').getAttribute('data-st'), 'none'); await page.keyboard.press('Escape'); await page.waitForTimeout(220);
  });
  await t('12) الإحصائيات تطابق التقدم الفعلي فورًا بعد التعديل اليدوي', async () => {
    await page.go('progress'); const st = await page.st();
    const mem = Object.values(st.progress).reduce((s, p) => s + p.ranges.reduce((a, r) => a + r[1] - r[0] + 1, 0), 0);
    assert.equal((await page.tid('stat-ayat').innerText()).trim(), AR(mem)); assert.equal(mem, 7);
    assert.equal((await page.tid('stat-done').innerText()).trim(), '١'); assert.equal((await page.tid('stat-progress').innerText()).trim(), '٠');
  });
  await c.ctx.close();

  console.log('خطة الحفظ والورد اليومي');
  await t('الافتراضي: الملك آية ١، لا حفظ مسبق، وإنشاء الخطة', async () => {
    c = await fresh(); page = c.page; await page.go('plan');
    assert.equal(await page.tid('plan-start-surah').inputValue(), '67'); assert.equal(await page.tid('plan-start-ayah').inputValue(), '1');
    assert.equal((await page.st()).plans.length, 0); await page.tid('plan-save').click(); await page.waitForTimeout(250);
    assert.match(await page.tid('portion-text').innerText(), /الملك/); const s = await page.st(); assert.equal(Object.keys(s.progress).length, 0);
  });
  await t('17+19) إتمام الورد ثم ظهور ورد غدٍ وإمكانية إتمامه، وتحديث الخطة والمراجعات والتقدم', async () => {
    await page.go('home'); assert.match(await page.tid('portion-text').innerText(), /\(١–٥\)/);
    await page.tid('complete-mem').click(); await page.waitForTimeout(250);
    let s = await page.st(); assert.equal(s.activity.filter(a => a.type === 'mem').length, 1); assert.deepEqual(s.progress[67].ranges, [[1, 5]]);
    assert.equal(s.reviews.length, 1); assert.equal(s.reviews[0].due, '2026-11-22');
    assert.equal(await page.tid('today-done').count(), 1); assert.match(await page.tid('portion-text').innerText(), /\(٦–١٠\)/, 'ورد الغد ظاهر');
    assert(await page.tid('complete-mem').isEnabled(), 'الزر متاح بعد إتمام ورد اليوم');
    await page.tid('complete-mem').click(); await page.waitForTimeout(150); await page.tid('confirm-ok').click(); await page.waitForTimeout(250); // ورد الغد مبكرًا
    s = await page.st(); assert.equal(s.activity.filter(a => a.type === 'mem').length, 2); assert.deepEqual(s.progress[67].ranges, [[1, 10]]); assert.equal(s.reviews.length, 2);
    assert.match(await page.tid('portion-text').innerText(), /\(١١–١٥\)/);
  });
  await t('17+19) يوم جديد: يظهر الورد التالي ويُسجَّل، ويمتنع تكرار الإنجاز نفسه', async () => {
    await page.setDay('2026-11-22'); // ورد الأحد أُنجز مبكرًا؛ المعروض الآن ورد الاثنين
    assert.equal(await page.tid('today-done').count(), 1); assert.match(await page.tid('portion-text').innerText(), /\(١١–١٥\)/);
    await page.tid('complete-mem').click(); await page.waitForTimeout(150); await page.tid('confirm-ok').click(); await page.waitForTimeout(250);
    let s = await page.st(); assert.equal(s.activity.filter(a => a.type === 'mem').length, 3);
    const dupe = await page.evaluate(() => { const st = M.store.state, a = st.activity.filter(x => x.type === 'mem')[2]; return M.plan.complete(st, { key: a.key, today: '2026-11-22' }); });
    assert.equal(dupe.ok, false); assert.equal(dupe.reason, 'duplicate'); s = await page.st(); assert.equal(s.activity.filter(a => a.type === 'mem').length, 3);
    assert.equal(new Set(s.activity.filter(a => a.type === 'mem').map(a => a.key)).size, 3); assert.deepEqual(s.progress[67].ranges, [[1, 15]]);
    await page.setDay('2026-11-23'); assert.match(await page.tid('portion-text').innerText(), /\(١٦–٢٠\)/);
    await page.tid('complete-mem').click(); await page.waitForTimeout(150); await page.tid('confirm-ok').click(); await page.waitForTimeout(250); s = await page.st();
    assert.equal(s.activity.filter(a => a.type === 'mem').length, 4); assert.deepEqual(s.progress[67].ranges, [[1, 20]]); assert.equal(s.reviews.length, 4);
    assert.equal(await page.evaluate(() => M.progress.status(M.store.state, 67)), 'progress');
    await page.go('puzzle'); assert.equal(await page.locator('.pz[data-s="67"]').getAttribute('data-st'), 'progress');
  });
  await t('17) يوم دون إنجاز مسبق: الزر يسجّل ورد اليوم نفسه دون تأكيد، ثم يظهر ورد الغد قابلًا للإتمام', async () => {
    const cc = await fresh(); const pg = cc.page; await pg.go('plan'); await pg.tid('plan-save').click(); await pg.waitForTimeout(200);
    await pg.tid('complete-mem').click(); await pg.waitForTimeout(200); await pg.setDay('2026-11-22');
    assert.equal(await pg.tid('today-done').count(), 0, 'اليوم الجديد: ورد اليوم لم يُنجز'); assert.match(await pg.tid('portion-text').innerText(), /\(٦–١٠\)/);
    await pg.tid('complete-mem').click(); await pg.waitForTimeout(200); assert.equal((await pg.st()).activity.filter(a => a.type === 'mem').length, 2, 'سُجّل مباشرة بلا تأكيد');
    assert.equal(await pg.tid('today-done').count(), 1); assert.match(await pg.tid('portion-text').innerText(), /\(١١–١٥\)/); assert(await pg.tid('complete-mem').isEnabled());
    await cc.ctx.close();
  });
  await t('18) سجل مستقل لكل ورد في يومه', async () => {
    const s = await page.st(), m = s.activity.filter(a => a.type === 'mem');
    assert.deepEqual(m.map(a => a.date), ['2026-11-21', '2026-11-21', '2026-11-22', '2026-11-23']); assert.deepEqual(m.map(a => a.forDate), ['2026-11-21', '2026-11-22', '2026-11-23', '2026-11-24']);
  });
  await t('10+9) المراجعة: مواعيد صحيحة، التقييم يحدّث الموعد التالي، الضعيف أقرب من المتقن', async () => {
    await page.go('review'); const items = page.tid('rv-item'); assert((await items.count()) >= 3);
    const id0 = await items.nth(0).getAttribute('data-id'), id1 = await items.nth(1).getAttribute('data-id');
    await items.nth(0).locator('[data-testid=rate-excellent]').click(); await page.waitForTimeout(150);
    await page.go('review'); await page.tid('rv-item').first().locator('[data-testid=rate-weak]').click(); await page.waitForTimeout(150);
    const s = await page.st(), a = s.reviews.find(r => r.id === id0), b = s.reviews.filter(r => r.history.length && r.lastRating === 'weak')[0];
    assert.equal(a.lastRating, 'excellent'); assert.equal(a.due, '2026-11-30'); assert(b, 'عنصر ضعيف'); assert.equal(b.due, '2026-11-24'); assert(b.due < a.due);
    assert.equal(await page.evaluate(sn => M.progress.status(M.store.state, sn), b.s), 'review');
    assert.equal(await page.locator('.rv.done').count() >= 2, true);
  });
  await t('أيام متأخرة لا تُنشئ تراكمًا مرهقًا + إعادة تنظيم المتأخرات', async () => {
    await page.setDay('2026-12-05'); await page.go('review'); assert.equal(await page.tid('overdue-banner').count(), 1);
    assert.equal((await page.evaluate(() => M.plan.pending(M.store.state, '2026-12-05'))).ayat, 5, 'ورد واحد فقط رغم الغياب');
    const before = await page.evaluate(() => M.review.dueBy(M.store.state, '2026-12-05').length);
    await page.evaluate(() => { M.store.state.settings.review.dailyCap = 1; M.store.commit(); });
    await page.go('home'); await page.go('review'); await page.tid('reorganize').click(); await page.tid('confirm-ok').click(); await page.waitForTimeout(200);
    const after = await page.evaluate(() => ({ today: M.review.dueBy(M.store.state, '2026-12-05').length, overdue: M.review.pending(M.store.state).filter(r => r.due < '2026-12-05').length }));
    assert(before >= 3); assert.equal(after.today, 1); assert.equal(after.overdue, 0);
  });
  await t('11) سجلات التقويم: منجز/فائت/راحة/مراجعة', async () => {
    await page.go('calendar'); const cell = d => page.locator(`[data-date="${d}"]`);
    await page.evaluate(() => { document.querySelector('[data-testid=cal-title]'); });
    assert.match(await cell('2026-12-05').getAttribute('aria-label'), /فائت|يوم حفظ|راحة/);
    await page.go('home'); await page.setDay('2026-11-23'); await page.go('calendar'); await page.tid('cal-today').click(); await page.waitForTimeout(100);
    assert.match(await cell('2026-11-21').getAttribute('aria-label'), /حفظ منجز/); assert.match(await cell('2026-11-23').getAttribute('aria-label'), /حفظ منجز/);
    await page.setDay('2026-12-05'); await page.go('calendar'); await page.tid('cal-today').click(); // نوفمبر 24 (ثلاثاء) فائت
    await page.tid('cal-prev').click(); await page.waitForTimeout(100); assert.match(await cell('2026-11-25').getAttribute('aria-label'), /حفظ فائت/); assert.match(await cell('2026-11-27').getAttribute('aria-label'), /(?!.*حفظ)/);
    assert.equal(await page.evaluate(() => M.plan.dayType(M.plan.active(M.store.state), '2026-11-27')), 'opt');
    await cell('2026-11-25').click(); await page.waitForTimeout(150); assert.equal(await page.tid('day-sheet').count(), 1); assert.match(await page.tid('day-sheet').innerText(), /لم يُسجَّل ورد/);
    await page.tid('resched-date').fill('2026-12-07'); await page.tid('resched-mem').click(); await page.waitForTimeout(200);
    assert.equal((await page.evaluate(() => M.plan.pending(M.store.state, '2026-12-05'))).forDate, '2026-12-07');
    await page.keyboard.press('Escape');
  });
  await c.ctx.close();

  console.log('تغيير الخطة');
  await t('6-8) تغيير سورة/آية البداية والهدف والمقدار فورًا مع بقاء السجل', async () => {
    c = await withPlan(); page = c.page; await page.tid('complete-mem').click(); await page.waitForTimeout(200);
    await page.go('plan'); await page.tid('plan-start-surah').selectOption('78'); await page.tid('plan-start-ayah').fill('3');
    await page.tid('plan-end-surah').selectOption('78'); await page.tid('end-of-surah').click(); await page.tid('plan-unit').locator('[data-v=page]').click(); await page.tid('plan-value').fill('1');
    await page.tid('plan-save').click(); await page.waitForTimeout(250); // بلا انتقال: تعديل
    assert.match(await page.tid('plan-summary').innerText(), /النبأ/); await page.go('home');
    assert.match(await page.tid('portion-text').innerText(), /النبأ \(٣–١٢\)/);
    const s = await page.st(); assert.equal(s.plans.length, 1); assert.equal(s.activity.filter(a => a.type === 'mem').length, 1, 'السجل السابق محفوظ'); assert.deepEqual(s.progress[67].ranges, [[1, 5]]);
    await page.go('plan'); await page.tid('plan-end-surah').selectOption('79'); await page.tid('plan-end-ayah').fill('10'); await page.tid('plan-save').click(); await page.waitForTimeout(200);
    assert.equal((await page.st()).plans[0].endS, 79);
    await page.go('plan'); await page.tid('plan-start-ayah').fill('99'); await page.tid('plan-save').click(); assert.match(await page.locator('.field-err').first().innerText(), /آية/); // تحقق
    await page.go('home'); await page.go('plan'); await page.tid('plan-end-surah').selectOption('1'); await page.tid('plan-save').click(); assert.equal(await page.tid('err-end').count(), 1);
    const dayBtns = await page.tid('plan-days').locator('button').count(); assert.equal(dayBtns, 7);
  });
  await t('إيقاف/استئناف/إعادة بدء/خطة جديدة', async () => {
    await page.go('plan'); await page.tid('plan-pause').click(); await page.waitForTimeout(150); assert.equal((await page.st()).plans[0].status, 'paused');
    await page.go('home'); assert.equal(await page.tid('resume-plan').count(), 1); await page.tid('resume-plan').click(); await page.waitForTimeout(150); assert.equal((await page.st()).plans[0].status, 'active');
    await page.go('plan'); await page.tid('plan-restart').click(); await page.tid('confirm-ok').click(); await page.waitForTimeout(150); assert.equal(await page.evaluate(() => M.plan.active(M.store.state).cursor), await page.evaluate(() => M.quran.toIdx(78, 3)));
    await page.go('plan'); await page.tid('plan-new').click(); await page.waitForTimeout(100); await page.tid('plan-start-surah').selectOption('1'); await page.tid('plan-save').click(); await page.waitForTimeout(250);
    const s = await page.st(); assert.equal(s.plans.length, 2); assert.equal(s.plans.filter(p => p.status === 'ended').length, 1); assert.equal(s.activity.filter(a => a.type === 'mem').length, 1);
  });
  await c.ctx.close();

  console.log('الثيمات والإعدادات');
  await t('19 ثيمًا، المعاينة قبل التطبيق، التطبيق الفوري، المفضلة، الحفظ بعد إعادة التحميل', async () => {
    c = await fresh(); page = c.page; await page.go('themes'); assert.equal(await page.tid('theme-card').count(), 19);
    const before = await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--primary'));
    await page.tid('preview-ramadan').click(); await page.waitForTimeout(200); assert.equal(await page.tid('preview-apply').count(), 1);
    assert.equal(await page.evaluate(() => document.documentElement.getAttribute('data-theme')), 'ramadan'); assert.equal((await page.st()).settings.theme, 'garden', 'المعاينة لا تحفظ');
    await page.go('calendar'); assert.equal(await page.tid('preview-cancel').count(), 1); await page.tid('preview-cancel').click(); await page.waitForTimeout(100);
    assert.equal(await page.evaluate(() => document.documentElement.getAttribute('data-theme')), 'garden');
    await page.go('themes'); await page.tid('apply-night').click(); await page.waitForTimeout(150);
    assert.equal(await page.evaluate(() => document.documentElement.getAttribute('data-theme')), 'night'); assert.equal(await page.tid('active-badge').count(), 1);
    assert.equal(await page.evaluate(() => document.querySelector('.tcard.active').dataset.themeId), 'night');
    await page.tid('fav-zen').click(); await page.waitForTimeout(100); await page.tid('cat-fav').click(); assert.equal(await page.tid('theme-card').count(), 1);
    await page.reload(); await page.waitForFunction(() => window.__midadReady);
    assert.equal(await page.evaluate(() => document.documentElement.getAttribute('data-theme')), 'night'); assert.deepEqual((await page.st()).settings.favorites, ['zen']);
  });
  await t('كل ثيم يطبَّق فورًا ويبدّل المتغيرات (تحقق من 19 ثيمًا ووضعي الإضاءة)', async () => {
    const seen = new Set();
    for (const mode of ['light', 'dark']) for (const id of await page.evaluate(() => M.themes.LIST.map(t => t.id))) {
      const v = await page.evaluate(([id, mode]) => { M.store.state.settings.theme = id; M.store.state.settings.mode = mode; M.store.commit(); const cs = getComputedStyle(document.documentElement); return cs.getPropertyValue('--bg') + '|' + cs.getPropertyValue('--primary') + '|' + cs.getPropertyValue('--font-display'); }, [id, mode]);
      assert(v.includes('#'), id); seen.add(v);
    }
    assert(seen.size >= 36, 'تفرد المتغيرات ' + seen.size);
    await page.evaluate(() => { M.store.state.settings.theme = 'garden'; M.store.state.settings.mode = 'auto'; M.store.commit(); });
  });
  await t('تخصيص: ألوان، خط، نمط تنقل، استدارة، أيقونات', async () => {
    await page.go('settings'); await page.tid('color-primary').evaluate(e => { e.value = '#aa3366'; e.dispatchEvent(new Event('input', { bubbles: true })); e.dispatchEvent(new Event('change', { bubbles: true })); }); await page.waitForTimeout(150);
    assert.equal(await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--primary').trim()), '#aa3366');
    await page.tid('set-nav').locator('[data-v=floating]').click(); await page.waitForTimeout(100); assert.equal(await page.evaluate(() => document.body.dataset.nav), 'floating');
    await page.tid('set-icons').locator('[data-v=solid]').click(); await page.waitForTimeout(100); assert.equal(await page.evaluate(() => document.body.dataset.icons), 'solid');
    await page.tid('set-font').locator('[data-v=kufi]').click(); await page.waitForTimeout(100); assert.match(await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--font-body')), /Kufi/);
    await page.tid('set-radius').evaluate(e => { e.value = 30; e.dispatchEvent(new Event('change', { bubbles: true })); }); await page.waitForTimeout(100); assert.equal(await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--r-card').trim()), '30px');
    await page.tid('set-mode').locator('[data-v=dark]').click(); await page.waitForTimeout(100); assert.equal(await page.evaluate(() => document.documentElement.dataset.mode), 'dark');
    await page.tid('reset-colors').click(); assert.equal((await page.st()).settings.colors.primary, '');
  });
  await t('فواصل المراجعة قابلة للتعديل مع التحقق', async () => {
    await page.go('settings'); await page.tid('set-intervals').fill('2, 5, 9'); await page.tid('set-intervals-save').click(); await page.waitForTimeout(100); assert.deepEqual((await page.st()).settings.review.intervals, [2, 5, 9]);
    await page.tid('set-intervals').fill('abc'); await page.tid('set-intervals-save').click(); assert.match(await page.tid('set-intervals-err').innerText(), /أعداد صحيحة/); assert.deepEqual((await page.st()).settings.review.intervals, [2, 5, 9]);
  });
  await c.ctx.close();

  console.log('التصدير والاستيراد والاستمرارية');
  await t('13) تصدير ثم تعديل ثم استيراد يستعيد الخطط والتقدم والمراجعات والإعدادات بموافقة صريحة', async () => {
    c = await withPlan(); page = c.page; await page.tid('complete-mem').click(); await page.waitForTimeout(200);
    await page.evaluate(() => { M.progress.setMemorized(M.store.state, 1, 4, '2026-11-21'); M.store.state.settings.theme = 'zen'; M.store.commit(); });
    await page.go('settings'); const [dl] = await Promise.all([page.waitForEvent('download'), page.tid('export').click()]); const file = await dl.path(); const txt = fs.readFileSync(file, 'utf8');
    const obj = JSON.parse(txt); assert.equal(obj.app, 'midad'); assert.equal(obj.data.progress[1].ranges[0][1], 4); assert.match(dl.suggestedFilename(), /^midad-backup-2026-11-21\.json$/);
    const snapshot = await page.st();
    await page.evaluate(() => { M.progress.setStatus(M.store.state, 1, 'none', '2026-11-21'); M.progress.setMemorized(M.store.state, 114, 6, '2026-11-21'); M.store.state.settings.theme = 'night'; M.store.commit(); });
    const tmp = path.join(require('os').tmpdir(), 'bk.json'); fs.writeFileSync(tmp, txt);
    await page.go('settings'); await page.tid('import-file').setInputFiles(tmp); await page.waitForTimeout(250);
    assert.equal(await page.tid('import-confirm').count(), 1); assert.match(await page.tid('import-confirm').innerText(), /سيستبدل/);
    assert.equal((await page.st()).settings.theme, 'night', 'لا تغيير قبل الموافقة'); await page.tid('import-confirm-btn').click(); await page.waitForTimeout(250);
    const s = await page.st(); assert.deepEqual(s.progress, snapshot.progress); assert.deepEqual(s.plans, snapshot.plans); assert.deepEqual(s.reviews, snapshot.reviews); assert.deepEqual(s.activity, snapshot.activity); assert.equal(s.settings.theme, 'zen');
    await page.go('settings'); assert.equal(await page.tid('undo-import').count(), 1); await page.tid('undo-import').click(); await page.tid('confirm-ok').click(); await page.waitForTimeout(200);
    assert.equal((await page.st()).settings.theme, 'night');
  });
  await t('13) رفض الملفات التالفة/الغريبة دون المساس بالبيانات', async () => {
    const before = JSON.stringify(await page.st());
    for (const [name, body] of [['bad1.json', 'هذا ليس json'], ['bad2.json', '{"hello":1}'], ['bad3.json', JSON.stringify({ app: 'midad', schema: 1, data: { progress: 'x' } })], ['bad4.json', JSON.stringify({ app: 'midad', schema: 99, data: {} })]]) {
      const f = path.join(require('os').tmpdir(), name); fs.writeFileSync(f, body); await page.go('settings'); await page.tid('import-file').setInputFiles(f); await page.waitForTimeout(200);
      assert.equal(await page.tid('import-error').count(), 1, name); await page.keyboard.press('Escape'); await page.waitForTimeout(220);
    }
    assert.equal(JSON.stringify(await page.st()), before);
  });
  await t('14) بقاء البيانات بعد إغلاق التطبيق وإعادة فتحه', async () => {
    const before = await page.st(); const p2 = await c.ctx.newPage(); decorate(p2); await page.close(); await p2.goto(URL); await p2.waitForFunction(() => window.__midadReady);
    const after = await p2.evaluate(() => JSON.parse(JSON.stringify(M.store.state))); assert.deepEqual(after.progress, before.progress); assert.deepEqual(after.plans, before.plans); assert.deepEqual(after.settings, before.settings); page = p2;
  });
  await t('استرجاع تلقائي عند تلف التخزين الرئيسي', async () => {
    await page.evaluate(() => localStorage.setItem('midad.data', '{broken')); await page.reload(); await page.waitForFunction(() => window.__midadReady);
    assert.equal(await page.evaluate(() => M.store.info.recovered), true); assert((await page.st()).plans.length >= 1);
  });
  await c.ctx.close();

  console.log('العمل دون اتصال والتثبيت');
  await t('15) service worker يعمل ويُحمَّل التطبيق دون اتصال كاملًا', async () => {
    c = await fresh(); page = c.page; await page.evaluate(() => navigator.serviceWorker.ready); await page.reload(); await page.waitForFunction(() => navigator.serviceWorker.controller);
    await page.go('plan'); await page.tid('plan-save').click(); await page.waitForTimeout(250);
    await c.ctx.setOffline(true); await page.reload(); await page.waitForFunction(() => window.__midadReady);
    assert.match(await page.tid('portion-text').innerText(), /الملك/); await page.go('puzzle'); assert.equal(await page.locator('.pz').count(), 114);
    await page.go('themes'); assert.equal(await page.tid('theme-card').count(), 19);
    await page.go('home'); await page.tid('complete-mem').click(); await page.waitForTimeout(200); assert.equal((await page.st()).activity.length, 1);
    await c.ctx.setOffline(false);
  });
  await t('manifest صالح وأيقونات موجودة', async () => {
    const m = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.webmanifest'), 'utf8'));
    assert.equal(m.display, 'standalone'); assert.equal(m.dir, 'rtl'); assert(m.icons.some(i => i.sizes === '192x192') && m.icons.some(i => i.sizes === '512x512') && m.icons.some(i => i.purpose === 'maskable'));
    m.icons.forEach(i => assert(fs.existsSync(path.join(ROOT, i.src)), i.src)); assert.equal(await page.evaluate(() => !!document.querySelector('link[rel=manifest]')), true);
  });
  await c.ctx.close();

  console.log('الشاشات الصغيرة');
  await t('16) لا انهيار ولا تمرير أفقي على 320×568 و360×640 في كل الصفحات وكل الثيمات الرئيسية', async () => {
    for (const vp of [{ width: 320, height: 568 }, { width: 360, height: 640 }]) {
      const cc = await fresh({ viewport: vp }); const pg = cc.page; await pg.go('plan'); await pg.tid('plan-save').click(); await pg.waitForTimeout(200);
      await pg.evaluate(() => { for (const s of [1, 2, 67]) M.progress.setMemorized(M.store.state, s, 3, '2026-11-21'); M.progress.setStatus(M.store.state, 67, 'review', '2026-11-21'); M.store.commit(); });
      const bad = [];
      for (const id of ['garden', 'doodle', 'editorial', 'geometric', 'night', 'notebook']) {
        await pg.evaluate(id => { M.store.state.settings.theme = id; M.store.state.settings.fontScale = 1.2; M.store.commit(); }, id);
        for (const r of ['home', 'session', 'plan', 'review', 'puzzle', 'progress', 'calendar', 'garden', 'themes', 'settings', 'more']) {
          await pg.go(r); await pg.waitForTimeout(60);
          const o = await pg.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
          if (o.sw > o.cw + 1) bad.push(`${vp.width}/${id}/${r}: ${o.sw}>${o.cw}`);
        }
      }
      await cc.ctx.close(); assert.deepEqual(bad, []);
    }
    assert.deepEqual(jsErrors, []);
  });
  await t('عناصر التحكم الرئيسية بحجم لمس مناسب (≥40px) على الهاتف', async () => {
    const cc = await fresh({ viewport: { width: 360, height: 640 } }); const pg = cc.page; await pg.go('plan'); await pg.tid('plan-save').click(); await pg.waitForTimeout(200);
    const small = await pg.evaluate(() => [...document.querySelectorAll('.btn, .bottom-nav a, .quick button')].map(e => { const r = e.getBoundingClientRect(); return [e.textContent.trim().slice(0, 14), Math.round(r.height)]; }).filter(x => x[1] < 40));
    await cc.ctx.close(); assert.deepEqual(small, []);
  });
  await t('لا أخطاء JavaScript أثناء كل الاختبارات', async () => { assert.deepEqual(jsErrors, []); });

  await browser.close(); srv.close(); console.log(`\n${pass} نجح، ${fail} فشل`); process.exit(fail ? 1 : 0);
})();
