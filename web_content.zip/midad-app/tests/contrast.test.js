/* يتحقق من تباين النصوص في كل ثيم وكل وضع (WCAG AA) */
const path = require('path');
['core/quran', 'core/dates', 'ui/color', 'ui/art', 'ui/themes'].forEach(f => require(path.join(__dirname, '..', 'js', f + '.js')));
const M = globalThis.M, C = M.color; let bad = 0, n = 0;
function chk(label, a, b, min) { n++; const c = C.contrast(a, b); if (c < min) { bad++; console.log('  ✗', label, c.toFixed(2), '<', min); } }
M.themes.LIST.forEach(t => ['light', 'dark'].forEach(mode => {
  for (const ov of [{}, { primary: '#ffcc00', bg: '#222222' }, { primary: '#112233', secondary: '#ffee00', bg: '#fafafa' }]) {
    const r = M.themes.compute(t, mode, { colors: Object.assign({ primary: '', secondary: '', bg: '', accent: '' }, ov), fontStyle: 'theme', radius: -1, deco: true });
    const v = r.vars, id = `${t.id}/${mode}/${JSON.stringify(ov)}`;
    chk(id + ' text/bg', v['--text'], v['--bg'], 7); chk(id + ' text/surface', v['--text'], v['--surface'], 7);
    chk(id + ' muted/bg', v['--muted'], v['--bg'], 4.5); chk(id + ' muted/surface', v['--muted'], v['--surface'], 4.5);
    chk(id + ' primary-text/surface', v['--primary-text'], v['--surface'], 4.5); chk(id + ' primary-text/bg', v['--primary-text'], v['--bg'], 4.5);
    chk(id + ' onPrimary', v['--on-primary'], v['--primary'], 4.5); chk(id + ' onSecondary', v['--on-secondary'], v['--secondary'], 4.5);
    chk(id + ' onAccent', v['--on-accent'], v['--accent'], 4.5); chk(id + ' onGood', v['--on-good'], v['--good'], 4.5); chk(id + ' onWarn', v['--on-warn'], v['--warn'], 4.5);
    chk(id + ' good-text', v['--good-text'], v['--surface'], 4.5); chk(id + ' warn-text', v['--warn-text'], v['--surface'], 4.5); chk(id + ' danger', v['--danger'], v['--surface'], 4.5);
    chk(id + ' text/pcNone', v['--text'], v['--pc-none'], 4.5); chk(id + ' text/primary-soft', v['--text'], v['--primary-soft'], 7);
    chk(id + ' text/good-soft', v['--text'], v['--good-soft'], 7); chk(id + ' text/warn-soft', v['--text'], v['--warn-soft'], 7);
    if (v['--page-bg'].includes('{') || v['--card-bg'].includes('{') || v['--card-shadow'].includes('{')) { bad++; console.log('  ✗ unresolved token', id, v['--page-bg']); }
  }
}));
console.log(`\n${M.themes.LIST.length} ثيمًا × وضعين × ٣ تخصيصات: ${n} فحص تباين، ${bad} إخفاق`); process.exit(bad ? 1 : 0);
