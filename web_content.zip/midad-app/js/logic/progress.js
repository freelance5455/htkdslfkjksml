/* تقدم السور والإحصائيات: كل الأرقام تُحسب من بيانات المستخدم الفعلية */
(function (M) {
  'use strict';
  var Q = M.quran, R = M.ranges, D = M.dates;
  var STATUS_LABEL = { none: 'لم تبدأ', progress: 'جارية', done: 'مكتملة', review: 'تحتاج مراجعة' };

  function ensure(state, s) { return state.progress[s] || (state.progress[s] = { ranges: [], review: false, started: false }); }
  function prune(state, s) { var p = state.progress[s]; if (p && !p.ranges.length && !p.review && !p.started) delete state.progress[s]; }

  var P = {
    STATUS_LABEL: STATUS_LABEL, ensure: ensure,
    memorized: function (state, s) { var p = state.progress[s]; return p ? R.count(p.ranges) : 0; },
    status: function (state, s) {
      var p = state.progress[s]; if (!p) return 'none';
      var m = R.count(p.ranges);
      if (p.review && (m > 0 || p.started)) return 'review';
      if (m >= Q.count(s)) return 'done';
      return (m > 0 || p.started) ? 'progress' : 'none';
    },
    totals: function (state) {
      var t = { memorized: 0, none: 0, progress: 0, done: 0, review: 0 };
      for (var s = 1; s <= 114; s++) { t.memorized += P.memorized(state, s); t[P.status(state, s)]++; }
      t.pct = t.memorized / Q.TOTAL_AYAT * 100; t.surahs = 114; return t;
    },
    log: function (state, entry) { entry.id = M.store.uid(); entry.ts = Date.now(); state.activity.push(entry); return entry; },
    setMemorized: function (state, s, n, today) {
      var total = Q.count(s); n = Math.max(0, Math.min(total, Math.floor(+n || 0)));
      var before = P.memorized(state, s), p = ensure(state, s);
      p.ranges = n ? [[1, n]] : []; if (n > 0) p.started = true;
      if (n !== before) P.log(state, { type: 'manual', date: today, s: s, ayahs: n - before, note: 'تعديل يدوي' });
      prune(state, s); return n;
    },
    /** تغيير الحالة يدويًا. يعيد {ok, reason} */
    setStatus: function (state, s, status, today) {
      var total = Q.count(s), p = ensure(state, s), before = P.memorized(state, s);
      if (status === 'none') {
        p.ranges = []; p.started = false; p.review = false;
        state.reviews.forEach(function (r) { if (r.s === s && r.status === 'pending') { r.status = 'retired'; r.history.push({ date: today, rating: 'retire', stageBefore: r.stage, dueBefore: r.due }); } });
      } else if (status === 'progress') {
        p.review = false; p.started = true; if (before >= total) p.ranges = total > 1 ? [[1, total - 1]] : [];
      } else if (status === 'done') {
        p.ranges = [[1, total]]; p.started = true; p.review = false;
      } else if (status === 'review') {
        if (before === 0 && !p.started) { prune(state, s); return { ok: false, reason: 'empty' }; }
        p.review = true; p.started = true;
        var span = R.span(p.ranges) || [1, total];
        var pend = M.review.pending(state).filter(function (r) { return r.s === s && r.src === 'flag'; })[0];
        if (pend) { if (pend.due > today) pend.due = today; pend.lastRating = pend.lastRating || 'needs'; }
        else { var it = M.review.create(state, { s: s, from: span[0], to: span[1], due: today, src: 'flag', created: today }); if (it) it.lastRating = 'needs'; }
      } else return { ok: false, reason: 'bad' };
      var after = P.memorized(state, s);
      if (after !== before) P.log(state, { type: 'manual', date: today, s: s, ayahs: after - before, note: 'تغيير الحالة: ' + STATUS_LABEL[status] });
      prune(state, s); return { ok: true };
    },
    reset: function (state, s, today) { return P.setStatus(state, s, 'none', today); },

    /** عدد الآيات الجديدة المحفوظة في يوم */
    ayahsOn: function (state, date) {
      return state.activity.reduce(function (n, a) { return n + ((a.type === 'mem' || a.type === 'manual') && a.date === date && a.ayahs > 0 ? a.ayahs : 0); }, 0);
    },
    daily: function (state, today, n) {
      var out = []; for (var i = n - 1; i >= 0; i--) { var d = D.addDays(today, -i); out.push({ date: d, ayahs: P.ayahsOn(state, d) }); } return out;
    },
    weekly: function (state, today, weekStart, n) {
      var ws = D.weekStartOf(today, weekStart), out = [];
      for (var i = n - 1; i >= 0; i--) {
        var from = D.addDays(ws, -7 * i), to = D.addDays(from, 6), sum = 0;
        state.activity.forEach(function (a) { if ((a.type === 'mem' || a.type === 'manual') && a.ayahs > 0 && a.date >= from && a.date <= to) sum += a.ayahs; });
        out.push({ from: from, to: to, ayahs: sum });
      } return out;
    },
    monthly: function (state, today, n) {
      var d = D.parse(today), out = [];
      for (var i = n - 1; i >= 0; i--) {
        var m = new Date(d.getFullYear(), d.getMonth() - i, 1), key = m.getFullYear() + '-' + D.pad(m.getMonth() + 1), sum = 0;
        state.activity.forEach(function (a) { if ((a.type === 'mem' || a.type === 'manual') && a.ayahs > 0 && a.date.slice(0, 7) === key) sum += a.ayahs; });
        out.push({ key: key, label: D.MONTHS[m.getMonth()], ayahs: sum });
      } return out;
    },
    recent: function (state, n) { return state.activity.slice().sort(function (a, b) { return b.ts - a.ts || (b.date < a.date ? -1 : 1); }).slice(0, n); }
  };
  M.progress = P;
  if (typeof module !== 'undefined') module.exports = P;
})(globalThis.M = globalThis.M || {});
