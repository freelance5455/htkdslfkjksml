/* منطق التقويم الشهري */
(function (M) {
  'use strict';
  var D = M.dates, PL = M.plan, V = M.review;
  var C = {
    dayInfo: function (state, date, today) {
      var plan = PL.planForDate(state, date), type = plan ? PL.dayType(plan, date) : null;
      var memDone = PL.memEntriesOn(state, date);
      var revDone = state.activity.filter(function (a) { return a.type === 'rev' && a.date === date; });
      var optDone = state.activity.filter(function (a) { return a.type === 'opt' && a.date === date; });
      var revDue = V.pending(state).filter(function (r) { return r.due === date; });
      var planned = type === 'mem';
      var missed = planned && date < today && !memDone.length;
      var info = {
        date: date, type: type, planned: planned, isToday: date === today, isFuture: date > today, isPast: date < today,
        memDone: memDone, revDone: revDone, revDue: revDue, optDone: optDone,
        missed: missed, missedRev: date < today ? revDue : [], rest: type === 'rest' || type === 'paused', optional: type === 'opt',
        done: memDone.length > 0 || revDone.length > 0 || optDone.length > 0
      };
      info.projection = planned && date >= today && !memDone.length ? PL.projection(state, date, today) : null;
      return info;
    },
    month: function (state, year, month, today) {
      var ws = state.settings.weekStart, first = year + '-' + D.pad(month + 1) + '-01';
      var start = D.weekStartOf(first, ws), n = D.daysInMonth(year, month), cells = [];
      var lead = D.diff(first, start), total = Math.ceil((lead + n) / 7) * 7;
      for (var i = 0; i < total; i++) {
        var d = D.addDays(start, i), inMonth = d.slice(0, 7) === first.slice(0, 7);
        cells.push({ date: d, inMonth: inMonth, info: inMonth ? C.dayInfo(state, d, today) : null });
      }
      return cells;
    },
    /** نقل المهام غير المكتملة ليوم معيّن */
    rescheduleMissed: function (state, date, today) { return PL.reschedule(state, date, today); }
  };
  M.calendar = C;
  if (typeof module !== 'undefined') module.exports = C;
})(globalThis.M = globalThis.M || {});
