/* عمليات على مجالات الآيات المحفوظة داخل السورة: [[من، إلى], ...] مرتبة وغير متداخلة */
(function (M) {
  'use strict';
  var R = {
    normalize: function (r) {
      var a = r.filter(function (x) { return x && x[0] <= x[1]; }).map(function (x) { return [x[0], x[1]]; }).sort(function (p, q) { return p[0] - q[0]; });
      var out = [];
      a.forEach(function (x) {
        var last = out[out.length - 1];
        if (last && x[0] <= last[1] + 1) last[1] = Math.max(last[1], x[1]); else out.push(x);
      });
      return out;
    },
    count: function (r) { return r.reduce(function (s, x) { return s + (x[1] - x[0] + 1); }, 0); },
    /** أجزاء [a,b] غير المغطاة بالمجالات r */
    gaps: function (r, a, b) {
      var out = [], cur = a;
      R.normalize(r).forEach(function (x) {
        if (x[1] < cur || x[0] > b) return;
        if (x[0] > cur) out.push([cur, x[0] - 1]);
        cur = Math.max(cur, x[1] + 1);
      });
      if (cur <= b) out.push([cur, b]);
      return out;
    },
    add: function (r, a, b) { var added = R.gaps(r, a, b); return { ranges: R.normalize(r.concat([[a, b]])), added: added }; },
    remove: function (r, a, b) {
      var out = [];
      R.normalize(r).forEach(function (x) {
        if (x[1] < a || x[0] > b) { out.push(x); return; }
        if (x[0] < a) out.push([x[0], a - 1]);
        if (x[1] > b) out.push([b + 1, x[1]]);
      });
      return out;
    },
    span: function (r) { return r.length ? [r[0][0], r[r.length - 1][1]] : null; }
  };
  M.ranges = R;
  if (typeof module !== 'undefined') module.exports = R;
})(globalThis.M = globalThis.M || {});
