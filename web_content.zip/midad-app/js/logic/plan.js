/* خطة الحفظ: إنشاء/تعديل/إيقاف، حساب ورد اليوم، وتسجيل الإنجاز */
(function (M) {
  'use strict';
  var Q = M.quran, D = M.dates, R = M.ranges, P = M.progress, V = M.review;
  var DEFAULT_DAYS = { 0: 'mem', 1: 'mem', 2: 'mem', 3: 'mem', 4: 'mem', 5: 'opt', 6: 'mem' };

  function lastCfg(plan, date) {
    var c = null; for (var i = 0; i < plan.cfg.length; i++) if (plan.cfg[i].from <= date && (!c || plan.cfg[i].from >= c.from)) c = plan.cfg[i]; return c;
  }
  function endIdx(plan) { return Q.toIdx(plan.endS, plan.endA); }
  function startIdx(plan) { return Q.toIdx(plan.startS, plan.startA); }

  var L = {
    DEFAULT_DAYS: DEFAULT_DAYS, startIdx: startIdx, endIdx: endIdx,
    defaults: function () { return { name: 'خطة الحفظ', startS: 67, startA: 1, endS: 114, endA: 6, unit: 'ayat', value: 5, days: JSON.parse(JSON.stringify(DEFAULT_DAYS)) }; },
    ayatPerDay: function (plan) { return Q.unitAyat(plan.unit, plan.value); },
    active: function (state) { for (var i = 0; i < state.plans.length; i++) if (state.plans[i].id === state.activePlanId) return state.plans[i]; return null; },
    get: function (state, id) { return state.plans.filter(function (p) { return p.id === id; })[0] || null; },

    /** التحقق من مدخلات المحرر. يعيد {ok, errors:{field:msg}, value} */
    validate: function (inp) {
      var e = {}, v = {};
      v.name = String(inp.name || '').trim().slice(0, 60) || 'خطة الحفظ';
      ['startS', 'endS', 'startA', 'endA'].forEach(function (k) { v[k] = Math.floor(+inp[k]); });
      if (!(v.startS >= 1 && v.startS <= 114)) e.startS = 'اختر سورة البداية';
      if (!(v.endS >= 1 && v.endS <= 114)) e.endS = 'اختر سورة الهدف';
      if (!e.startS && !(v.startA >= 1 && v.startA <= Q.count(v.startS))) e.startA = 'آية البداية بين ١ و' + Q.num(Q.count(v.startS));
      if (!e.endS && !(v.endA >= 1 && v.endA <= Q.count(v.endS))) e.endA = 'آية الهدف بين ١ و' + Q.num(Q.count(v.endS));
      if (!e.startS && !e.startA && !e.endS && !e.endA && Q.toIdx(v.startS, v.startA) > Q.toIdx(v.endS, v.endA)) e.endS = 'الهدف يجب أن يأتي بعد البداية في المصحف';
      v.unit = ['ayat', 'page', 'half', 'quarter', 'custom'].indexOf(inp.unit) >= 0 ? inp.unit : 'ayat';
      v.value = +inp.value;
      if (v.unit === 'half' || v.unit === 'quarter') v.value = 1;
      if (!(v.value > 0 && v.value <= 100)) e.value = 'أدخل مقدارًا صحيحًا أكبر من صفر';
      else if ((v.unit === 'ayat' || v.unit === 'custom') && !Number.isInteger(v.value)) e.value = 'عدد الآيات يجب أن يكون عددًا صحيحًا';
      v.days = {}; var mem = 0;
      for (var i = 0; i < 7; i++) { var t = inp.days && inp.days[i]; v.days[i] = ['mem', 'rest', 'opt'].indexOf(t) >= 0 ? t : 'rest'; if (v.days[i] === 'mem') mem++; }
      if (!mem) e.days = 'اختر يوم حفظ واحدًا على الأقل';
      return { ok: !Object.keys(e).length, errors: e, value: v };
    },

    dayType: function (plan, date) {
      if (!plan || date < plan.startDate) return null;
      if (plan.endDate && date > plan.endDate) return null;
      for (var i = 0; i < plan.pauses.length; i++) { var p = plan.pauses[i]; if (date >= p.from && (!p.to || date <= p.to)) return 'paused'; }
      if (plan.forcedDate === date) return 'mem';
      var c = lastCfg(plan, date); return c ? c.days[D.dow(date)] : null;
    },
    planForDate: function (state, date) {
      var best = null;
      state.plans.forEach(function (p) {
        if (p.startDate <= date && (!p.endDate || date <= p.endDate) && (!best || p.createdAt >= best.createdAt)) best = p;
      }); return best;
    },
    nextMemDate: function (plan, from) {
      for (var i = 0; i < 21; i++) { var d = D.addDays(from, i); var c = lastCfg(plan, d) || plan.cfg[plan.cfg.length - 1]; if (c.days[D.dow(d)] === 'mem' && L.dayType(plan, d) !== 'paused') return d; }
      return from;
    },
    effectiveDate: function (plan, today) {
      if (plan.forcedDate && plan.forcedDate >= today) return plan.forcedDate;
      return L.nextMemDate(plan, plan.notBefore > today ? plan.notBefore : today);
    },

    /** حالة الورد الحالي (المعلّق) */
    pending: function (state, today) {
      var plan = L.active(state); if (!plan || plan.status === 'ended') return { status: 'none' };
      if (plan.status === 'paused') return { status: 'paused', plan: plan };
      if (plan.status === 'done' || plan.cursor > endIdx(plan)) return { status: 'done', plan: plan };
      var forDate = L.effectiveDate(plan, today), n = L.ayatPerDay(plan);
      var i1 = plan.cursor, i2 = Math.min(endIdx(plan), i1 + n - 1);
      return {
        status: 'ready', plan: plan, forDate: forDate, i1: i1, i2: i2, ayat: i2 - i1 + 1, segments: Q.segments(i1, i2),
        key: plan.id + '|' + forDate + '|' + i1 + '-' + i2, isToday: forDate === today, isAhead: forDate > today,
        todayType: L.dayType(plan, today), remaining: endIdx(plan) - i2
      };
    },
    /** هل أُنجز ورد اليوم المحدد (بتاريخ الإنجاز أو بتاريخ الورد)؟ */
    memEntriesOn: function (state, date) { return state.activity.filter(function (a) { return a.type === 'mem' && (a.forDate === date || a.date === date); }); },

    create: function (state, inp, today) {
      var v = L.validate(inp); if (!v.ok) return { ok: false, errors: v.errors };
      var old = L.active(state);
      if (old && old.status !== 'done') { old.status = 'ended'; old.endDate = D.addDays(today, -1) < old.startDate ? old.startDate : D.addDays(today, -1); if (old.endDate < old.startDate) old.endDate = old.startDate; }
      else if (old) old.status = 'ended';
      var x = v.value, plan = {
        id: M.store.uid(), name: x.name, startS: x.startS, startA: x.startA, endS: x.endS, endA: x.endA, unit: x.unit, value: x.value,
        status: 'active', cursor: Q.toIdx(x.startS, x.startA), startDate: today, notBefore: today, forcedDate: null, endDate: null,
        cfg: [{ from: today, days: x.days }], pauses: [], createdAt: Date.now()
      };
      state.plans.push(plan); state.activePlanId = plan.id; return { ok: true, plan: plan };
    },
    /** تعديل الخطة الحالية: ينعكس فورًا على ورد اليوم الجديد ويحفظ السجل السابق */
    update: function (state, id, inp, today) {
      var plan = L.get(state, id); if (!plan) return { ok: false, errors: { _: 'الخطة غير موجودة' } };
      var v = L.validate(inp); if (!v.ok) return { ok: false, errors: v.errors };
      var x = v.value, startChanged = x.startS !== plan.startS || x.startA !== plan.startA;
      plan.name = x.name; plan.startS = x.startS; plan.startA = x.startA; plan.endS = x.endS; plan.endA = x.endA; plan.unit = x.unit; plan.value = x.value;
      if (startChanged) { plan.cursor = Q.toIdx(x.startS, x.startA); plan.forcedDate = null; }
      var cur = L.cfgAt(plan, today);
      if (JSON.stringify(cur) !== JSON.stringify(x.days)) {
        plan.cfg = plan.cfg.filter(function (c) { return c.from !== today; }); plan.cfg.push({ from: today, days: x.days });
      }
      if (plan.cursor > endIdx(plan)) { plan.status = 'done'; if (!plan.endDate) plan.endDate = today; }
      else if (plan.status === 'done') { plan.status = 'active'; plan.endDate = null; }
      return { ok: true, plan: plan };
    },
    cfgAt: function (plan, date) { var c = lastCfg(plan, date); return c ? c.days : plan.cfg[plan.cfg.length - 1].days; },
    pause: function (state, today) {
      var p = L.active(state); if (!p || p.status !== 'active') return false;
      p.status = 'paused'; p.pauses.push({ from: today, to: null }); return true;
    },
    resume: function (state, today) {
      var p = L.active(state); if (!p || p.status !== 'paused') return false;
      var last = p.pauses[p.pauses.length - 1]; if (last && !last.to) last.to = D.addDays(today, -1);
      if (last && last.to < last.from) p.pauses.pop();
      p.status = 'active'; p.notBefore = today; p.forcedDate = null; return true;
    },
    restart: function (state, today) {
      var p = L.active(state); if (!p) return false;
      var last = p.pauses[p.pauses.length - 1]; if (last && !last.to) { last.to = D.addDays(today, -1); if (last.to < last.from) p.pauses.pop(); }
      p.cursor = startIdx(p); p.status = 'active'; p.endDate = null; p.notBefore = today; p.forcedDate = null; return true;
    },
    end: function (state, today) {
      var p = L.active(state); if (!p) return false; p.status = 'ended'; p.endDate = today; state.activePlanId = null; return true;
    },
    reschedule: function (state, date, today) {
      var p = L.active(state); if (!p || p.status !== 'active' || !D.valid(date) || date < today) return false;
      p.forcedDate = date; p.notBefore = date; return true;
    },

    /** تسجيل إنجاز الورد الحالي. opts: {key, today} */
    complete: function (state, opts) {
      var today = opts.today, pend = L.pending(state, today);
      if (pend.status !== 'ready') return { ok: false, reason: pend.status === 'done' ? 'done' : 'noplan' };
      var plan = pend.plan, key = pend.key;
      if (opts.key && opts.key !== key) return { ok: false, reason: state.activity.some(function (a) { return a.key === opts.key; }) ? 'duplicate' : 'stale' };
      if (state.activity.some(function (a) { return a.type === 'mem' && a.key === key; })) return { ok: false, reason: 'duplicate' };
      var id = M.store.uid(), added = {}, newCount = 0, reviewIds = [];
      pend.segments.forEach(function (g) {
        var p = P.ensure(state, g.s), r = R.add(p.ranges, g.from, g.to);
        p.ranges = r.ranges; p.started = true;
        if (r.added.length) { added[g.s] = r.added; newCount += R.count(r.added); }
        var it = V.create(state, { s: g.s, from: g.from, to: g.to, due: D.addDays(today, state.settings.review.intervals[0]), src: 'plan', srcLog: id, created: today });
        if (it) reviewIds.push(it.id);
      });
      var entry = { id: id, type: 'mem', date: today, forDate: pend.forDate, ts: Date.now(), planId: plan.id, i1: pend.i1, i2: pend.i2, key: key, segments: pend.segments, added: added, ayahs: newCount, reviewIds: reviewIds };
      state.activity.push(entry);
      plan.cursor = pend.i2 + 1; plan.forcedDate = null; plan.notBefore = D.addDays(pend.forDate, 1);
      if (plan.cursor > endIdx(plan)) { plan.status = 'done'; plan.endDate = today; }
      return { ok: true, entry: entry, finished: plan.status === 'done' };
    },
    /** تراجع عن آخر إنجاز (يعيد المؤشر والتقدم والمراجعات المرتبطة) */
    undo: function (state, activityId) {
      var a = state.activity.filter(function (x) { return x.id === activityId && x.type === 'mem'; })[0]; if (!a) return false;
      var plan = L.get(state, a.planId);
      if (plan && plan.cursor !== a.i2 + 1) return false; // لا يُسمح إلا بالتراجع عن الأحدث
      for (var s in a.added) { var p = state.progress[s]; if (p) a.added[s].forEach(function (r) { p.ranges = R.remove(p.ranges, r[0], r[1]); }); if (p && !p.ranges.length && !p.review && !p.started) delete state.progress[s]; }
      state.reviews = state.reviews.filter(function (r) { return !(a.reviewIds.indexOf(r.id) >= 0 && !r.history.length); });
      state.activity = state.activity.filter(function (x) { return x.id !== activityId; });
      if (plan) { plan.cursor = a.i1; plan.status = 'active'; plan.endDate = null; plan.notBefore = D.addDays(a.forDate, 0); plan.forcedDate = null; }
      return true;
    },
    lastMem: function (state) {
      var plan = L.active(state); if (!plan) return null;
      var l = state.activity.filter(function (a) { return a.type === 'mem' && a.planId === plan.id; }).sort(function (a, b) { return b.ts - a.ts; })[0];
      return l && plan.cursor === l.i2 + 1 ? l : null;
    },
    /** ورد تقريبي ليوم مستقبلي (للتقويم) */
    projection: function (state, date, today) {
      var pend = L.pending(state, today); if (pend.status !== 'ready' || date < pend.forDate) return null;
      var plan = pend.plan, n = L.ayatPerDay(plan), k = 0, d = pend.forDate;
      if (date !== pend.forDate) {
        if (L.dayType(plan, date) !== 'mem') return null;
        for (d = D.addDays(pend.forDate, 1); d <= date; d = D.addDays(d, 1)) if (L.dayType(plan, d) === 'mem') k++;
      }
      var i1 = pend.i1 + k * n; if (i1 > endIdx(plan)) return null;
      var i2 = Math.min(endIdx(plan), i1 + n - 1); return { i1: i1, i2: i2, segments: Q.segments(i1, i2) };
    },
    /** مقترح مراجعة اختيارية: آخر ما حُفظ خلال ٧ أيام */
    optionalReview: function (state, today) {
      var from = D.addDays(today, -7), out = [];
      state.activity.forEach(function (a) { if (a.type === 'mem' && a.date >= from) a.segments.forEach(function (g) { out.push(g); }); });
      return out.slice(-6);
    }
  };
  M.plan = L;
  if (typeof module !== 'undefined') module.exports = L;
})(globalThis.M = globalThis.M || {});
