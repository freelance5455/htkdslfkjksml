/* التصدير والاستيراد مع التحقق قبل أي تغيير */
(function (M) {
  'use strict';
  var B = {
    build: function (state) {
      return { app: 'midad', schema: M.store.SCHEMA, exportedAt: new Date().toISOString(), data: state };
    },
    filename: function () { return 'midad-backup-' + M.dates.today() + '.json'; },
    /** يحلل نص JSON ويعيد {ok, errors, warnings, state, summary} دون المساس بالبيانات الحالية */
    inspect: function (text) {
      var obj; try { obj = JSON.parse(text); } catch (e) { return { ok: false, errors: ['الملف ليس JSON صالحًا'], warnings: [] }; }
      if (!obj || typeof obj !== 'object' || obj.app !== 'midad') return { ok: false, errors: ['هذا الملف ليس نسخة احتياطية من مِداد'], warnings: [] };
      if (!(Number.isInteger(obj.schema) && obj.schema >= 1)) return { ok: false, errors: ['إصدار النسخة غير معروف'], warnings: [] };
      var r = M.store.normalize(Object.assign({ schema: obj.schema }, obj.data));
      if (!r.state) return { ok: false, errors: r.errors, warnings: r.warnings };
      var t = M.progress.totals(r.state);
      return {
        ok: true, errors: [], warnings: r.warnings, state: r.state, exportedAt: obj.exportedAt || '',
        summary: { plans: r.state.plans.length, memorized: t.memorized, done: t.done, reviews: r.state.reviews.length, activity: r.state.activity.length }
      };
    }
  };
  M.backup = B;
  if (typeof module !== 'undefined') module.exports = B;
})(globalThis.M = globalThis.M || {});
