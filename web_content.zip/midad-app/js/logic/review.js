/* نظام المراجعة بالتكرار المتباعد */
(function (M) {
  'use strict';
  var D = M.dates, Q = M.quran, R = M.ranges;
  var LABELS = { excellent: 'متقن جدًا', good: 'جيد', needs: 'يحتاج تثبيت', weak: 'ضعيف', retire: 'إنهاء المتابعة' };
  var PRIO = { weak: 0, needs: 1 };

  function intervals(state) { return state.settings.review.intervals; }
  function find(state, id) { for (var i = 0; i < state.reviews.length; i++) if (state.reviews[i].id === id) return state.reviews[i]; return null; }
  function prio(it) { return PRIO[it.lastRating] === undefined ? 2 : PRIO[it.lastRating]; }
  function byPriority(a, b) { return prio(a) - prio(b) || D.cmp(a.due, b.due) || a.s - b.s || a.from - b.from; }

  function ensureP(state, s) { return state.progress[s] || (state.progress[s] = { ranges: [], review: false, started: false }); }

  var V = {
    LABELS: LABELS, RATINGS: ['excellent', 'good', 'needs', 'weak'], find: find,
    create: function (state, o) {
      var dup = state.reviews.some(function (r) { return r.status === 'pending' && r.s === o.s && r.from === o.from && r.to === o.to && r.due === o.due && r.src === (o.src || 'manual'); });
      if (dup) return null;
      var it = { id: M.store.uid(), s: o.s, from: o.from, to: o.to, due: o.due, stage: 0, status: 'pending', created: o.created || o.due, src: o.src || 'manual', srcLog: o.srcLog || null, lastRating: null, history: [] };
      state.reviews.push(it); return it;
    },
    pending: function (state) { return state.reviews.filter(function (r) { return r.status === 'pending'; }); },
    dueBy: function (state, date) { return V.pending(state).filter(function (r) { return r.due <= date; }).sort(byPriority); },
    reviewedOn: function (state, date) {
      return state.reviews.filter(function (r) { var h = r.history[r.history.length - 1]; return h && h.date === date && h.rating !== 'retire'; });
    },
    /** قائمة مراجعات اليوم مع احترام الحد اليومي وأيام الراحة */
    today: function (state, today) {
      var cap = state.settings.review.dailyCap, due = V.dueBy(state, today), hiddenRest = false;
      var plan = M.plan.planForDate(state, today);
      if (plan && !state.settings.review.reviewOnRest && M.plan.dayType(plan, today) === 'rest') { hiddenRest = due.length > 0; due = []; }
      var visible = cap > 0 ? due.slice(0, cap) : due;
      return { visible: visible, hidden: due.length - visible.length, done: V.reviewedOn(state, today), overdue: due.filter(function (r) { return r.due < today; }).length, total: due.length, hiddenRest: hiddenRest };
    },
    upcoming: function (state, today, days) {
      var out = {}; V.pending(state).forEach(function (r) { if (r.due > today && D.diff(r.due, today) <= days) (out[r.due] = out[r.due] || []).push(r); });
      return Object.keys(out).sort().map(function (d) { return { date: d, items: out[d] }; });
    },
    /** يحسب المرحلة والأيام التالية حسب التقييم */
    next: function (iv, stage, rating) {
      var last = iv.length - 1, ns, days;
      if (rating === 'excellent') ns = stage + 2; else if (rating === 'good') ns = stage + 1;
      else if (rating === 'needs') ns = Math.max(0, stage - 1); else ns = 0;
      var atEnd = ns > last; ns = Math.min(ns, last);
      days = iv[ns];
      if (rating === 'excellent' && atEnd) days = Math.round(iv[last] * 1.5);
      return { stage: ns, days: days };
    },
    recomputeFlag: function (state, s) {
      var p = state.progress[s]; if (!p) return;
      var weak = V.pending(state).some(function (r) { return r.s === s && (r.lastRating === 'weak' || r.lastRating === 'needs'); });
      if (p.review && !weak) p.review = false;
    },
    rate: function (state, id, rating, today) {
      var it = find(state, id); if (!it || V.RATINGS.indexOf(rating) < 0) return { ok: false };
      var last = it.history[it.history.length - 1];
      if (last && last.date === today && last.rating !== 'retire') { // إعادة تقييم في اليوم نفسه: تراجع عن السابق
        it.stage = last.stageBefore; it.due = last.dueBefore; it.history.pop(); it.status = 'pending';
        state.activity = state.activity.filter(function (a) { return !(a.type === 'rev' && a.reviewId === id && a.date === today); });
      }
      var n = V.next(intervals(state), it.stage, rating);
      it.history.push({ date: today, rating: rating, stageBefore: it.stage, dueBefore: it.due });
      it.stage = n.stage; it.due = D.addDays(today, n.days); it.lastRating = rating; it.status = 'pending';
      state.activity.push({ id: M.store.uid(), type: 'rev', date: today, ts: Date.now(), s: it.s, from: it.from, to: it.to, rating: rating, reviewId: id, ayahs: 0 });
      if (rating === 'weak' || rating === 'needs') { var p = ensureP(state, it.s); p.review = true; p.started = true; }
      else V.recomputeFlag(state, it.s);
      return { ok: true, item: it, days: n.days };
    },
    postpone: function (state, id, days, today) {
      var it = find(state, id); if (!it) return false; it.due = D.addDays(today, Math.max(1, days || 1)); return true;
    },
    reschedule: function (state, id, date) {
      var it = find(state, id); if (!it || !D.valid(date)) return false; it.due = date; return true;
    },
    retire: function (state, id, today) {
      var it = find(state, id); if (!it) return false;
      it.history.push({ date: today, rating: 'retire', stageBefore: it.stage, dueBefore: it.due }); it.status = 'retired';
      V.recomputeFlag(state, it.s); return true;
    },
    remove: function (state, id) {
      var it = find(state, id); if (!it) return false;
      state.reviews = state.reviews.filter(function (r) { return r.id !== id; });
      V.recomputeFlag(state, it.s); return true;
    },
    addManual: function (state, o, today) {
      var s = +o.s, a = +o.from, b = +o.to;
      if (!(s >= 1 && s <= 114)) return { ok: false, error: 'اختر السورة' };
      if (!(Number.isInteger(a) && Number.isInteger(b) && a >= 1 && b >= a && b <= Q.count(s))) return { ok: false, error: 'نطاق الآيات غير صحيح (١–' + Q.num(Q.count(s)) + ')' };
      var due = D.valid(o.due) ? o.due : D.addDays(today, 1);
      var it = V.create(state, { s: s, from: a, to: b, due: due, src: 'manual', created: today });
      return it ? { ok: true, item: it } : { ok: false, error: 'هذه المراجعة مضافة مسبقًا لنفس الموعد' };
    },
    /** إعادة توزيع المتأخرات والمستحقات الزائدة على الأيام القادمة بحد يومي معقول */
    reorganize: function (state, today) {
      var pool = V.dueBy(state, today), cap = state.settings.review.dailyCap || 10, moved = 0;
      pool.forEach(function (it, i) {
        var d = D.addDays(today, Math.floor(i / cap)); if (it.due !== d) { it.due = d; moved++; }
      });
      return { ok: true, moved: moved, days: pool.length ? Math.ceil(pool.length / cap) : 0, total: pool.length };
    },
    weak: function (state) {
      var seen = {}, out = [];
      V.pending(state).filter(function (r) { return r.lastRating === 'weak' || r.lastRating === 'needs'; }).sort(byPriority).forEach(function (r) { out.push(r); seen[r.s] = 1; });
      for (var s in state.progress) if (state.progress[s].review && !seen[s]) out.push({ s: +s, from: 1, to: Q.count(+s), lastRating: null, virtual: true });
      return out;
    },
    historyList: function (state) {
      return state.activity.filter(function (a) { return a.type === 'rev'; }).sort(function (a, b) { return b.ts - a.ts; });
    },
    text: function (it) { return Q.segText({ s: it.s, from: it.from, to: it.to }); }
  };
  M.review = V;
  if (typeof module !== 'undefined') module.exports = V;
})(globalThis.M = globalThis.M || {});
