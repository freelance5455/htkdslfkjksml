/* رحلة النمو: بذرة ← برعم ← نبتة ← شجرة ← حديقة. تعتمد على مجموع أيام الاجتهاد فلا يمحوها يوم فائت */
(function (M) {
  'use strict';
  var D = M.dates, PL = M.plan;
  var STAGES = [
    { id: 'seed', name: 'بذرة', at: 0, hint: 'بداية الرحلة' },
    { id: 'bud', name: 'برعم', at: 3, hint: 'بدأ الجذر يثبت' },
    { id: 'sprout', name: 'نبتة', at: 10, hint: 'تنمو بثبات' },
    { id: 'tree', name: 'شجرة', at: 30, hint: 'جذور راسخة وظل وارف' },
    { id: 'garden', name: 'حديقة', at: 80, hint: 'ثمرة الاستمرار' }
  ];
  var G = {
    STAGES: STAGES,
    activeDates: function (state) {
      var s = {}; state.activity.forEach(function (a) { if (a.type === 'mem' || a.type === 'rev' || a.type === 'opt') s[a.date] = 1; }); return s;
    },
    /** يوم سماح: راحة/إيقاف/مراجعة اختيارية لا تكسر السلسلة */
    grace: function (state, date) { var p = PL.planForDate(state, date), t = p && PL.dayType(p, date); return t === 'rest' || t === 'opt' || t === 'paused'; },
    compute: function (state, today) {
      var act = G.activeDates(state), days = Object.keys(act).length, stage = 0;
      STAGES.forEach(function (s, i) { if (days >= s.at) stage = i; });
      var next = STAGES[stage + 1] || null, prev = STAGES[stage];
      var frac = next ? (days - prev.at) / (next.at - prev.at) : 1;
      // السلسلة الحالية: تسمح بيوم فائت واحد بين يومين نشطين
      var streak = 0, miss = 0, d = today;
      for (var i = 0; i < 400; i++, d = D.addDays(today, -i)) {
        if (act[d]) { streak++; miss = 0; }
        else if (d === today || G.grace(state, d)) { /* لا يكسر */ }
        else { miss++; if (miss >= 2) break; }
      }
      var keys = Object.keys(act).sort(), best = 0, run = 0, prevD = null;
      keys.forEach(function (k) { run = prevD && D.diff(k, prevD) <= 2 ? run + 1 : 1; prevD = k; if (run > best) best = run; });
      var week = []; for (var j = 6; j >= 0; j--) { var dd = D.addDays(today, -j); week.push({ date: dd, active: !!act[dd], grace: !act[dd] && G.grace(state, dd) }); }
      return { stage: stage, info: prev, next: next, days: days, frac: Math.max(0, Math.min(1, frac)), streak: streak, best: Math.max(best, streak), week: week, toNext: next ? next.at - days : 0 };
    }
  };
  M.growth = G;
  if (typeof module !== 'undefined') module.exports = G;
})(globalThis.M = globalThis.M || {});
