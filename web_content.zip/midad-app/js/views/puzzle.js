/* بازل القرآن: ١١٤ قطعة مرتبطة ببيانات السور الفعلية */
(function (M) {
  'use strict';
  var h = M.ui.h, icon = M.ui.icon, n = M.ui.n, Q = M.quran, P = M.progress, PL = M.plan;
  var COLS = 6, S = 100, PAD = 6, filter = null, query = '', snapId = null;
  var LABEL = P.STATUS_LABEL, ORDER = ['none', 'progress', 'done', 'review'];

  /* اتجاه النتوء المشترك بين قطعتين متجاورتين: +1 يعني أن القطعة الأولى تبرز نحو الثانية */
  function hash(a, b, c) { return ((((a * 73856093) ^ (b * 19349663) ^ (c * 83492791)) >>> 0) % 2) ? 1 : -1; }
  function edge(x0, y0, x1, y1, nx, ny, dir) {
    if (!dir) return 'L' + x1 + ' ' + y1;
    var ux = x1 - x0, uy = y1 - y0;
    function pt(t, hh) { return (x0 + ux * t + nx * dir * hh * S).toFixed(1) + ' ' + (y0 + uy * t + ny * dir * hh * S).toFixed(1); }
    return 'L' + pt(.38, 0) + 'C' + pt(.38, .04) + ' ' + pt(.33, .06) + ' ' + pt(.33, .10) + 'C' + pt(.33, .15) + ' ' + pt(.41, .17) + ' ' + pt(.5, .17) +
      'C' + pt(.59, .17) + ' ' + pt(.67, .15) + ' ' + pt(.67, .10) + 'C' + pt(.67, .06) + ' ' + pt(.62, .04) + ' ' + pt(.62, 0) + 'L' + x1 + ' ' + y1;
  }
  function piecePath(r, c, rows) {
    var top = r === 0 ? 0 : -hash(r - 1, c, 1), bottom = r === rows - 1 ? 0 : hash(r, c, 1);
    var left = c === 0 ? 0 : -hash(r, c - 1, 2), right = c === COLS - 1 ? 0 : hash(r, c, 2);
    return 'M0 0' + edge(0, 0, S, 0, 0, -1, top) + edge(S, 0, S, S, 1, 0, right) + edge(S, S, 0, S, 0, 1, bottom) + edge(0, S, 0, 0, -1, 0, left) + 'Z';
  }
  var NS = 'http://www.w3.org/2000/svg';
  function se(tag, attrs, text) { var e = document.createElementNS(NS, tag); Object.keys(attrs || {}).forEach(function (k) { e.setAttribute(k, attrs[k]); }); if (text != null) e.textContent = text; return e; }

  function board(st) {
    var rows = Math.ceil(114 / COLS), W = COLS * S + PAD * 2, H = rows * S + PAD * 2;
    var svg = se('svg', { class: 'pz-board', viewBox: '0 0 ' + W + ' ' + H, role: 'group', 'aria-label': 'بازل سور القرآن', 'data-testid': 'puzzle-board' });
    var count = 0;
    for (var i = 1; i <= 114; i++) {
      var r = Math.floor((i - 1) / COLS), c = (i - 1) % COLS, vx = COLS - 1 - c; // الترتيب من اليمين
      var status = P.status(st, i), m = P.memorized(st, i), total = Q.count(i), nm = Q.name(i);
      var g = se('g', { class: 'pz', 'data-s': i, 'data-st': status, transform: 'translate(' + (PAD + vx * S) + ' ' + (PAD + r * S) + ')', tabindex: '0', role: 'button',
        'aria-label': 'سورة ' + nm + '، ' + LABEL[status] + '، ' + n(m) + ' من ' + n(total) + ' آية' });
      // أنماط الحافة تعتمد موضع القطعة البصري (vx) لتتطابق النتوءات مع الجيران
      g.appendChild(se('path', { class: 'pz-shape', d: piecePath(r, vx, rows) }));
      g.appendChild(se('text', { class: 'pz-num', x: 50, y: 36 }, n(i)));
      g.appendChild(se('text', { class: 'pz-name', x: 50, y: 62, 'font-size': nm.length > 7 ? 13.5 : nm.length > 5 ? 15.5 : 19 }, nm));
      g.appendChild(se('rect', { class: 'pz-bar-bg', x: 24, y: 74, width: 52, height: 6, rx: 3 }));
      g.appendChild(se('rect', { class: 'pz-bar', x: 24, y: 74, width: (52 * Math.min(1, m / total)).toFixed(1), height: 6, rx: 3 }));
      g.appendChild(se('path', { class: 'pz-mark', d: status === 'done' ? 'M40 80l7 6 13-13' : 'M44 80h12M50 74v12' }));
      if (filter && filter !== status) g.classList.add('dim');
      if (query && Q.name(i).indexOf(query) >= 0) g.classList.add('hit'); else if (query) g.classList.add('dim');
      if (snapId === i) { g.classList.add('snap'); }
      count++;
      svg.appendChild(g);
    }
    svg.dataset.count = count;
    snapId = null;
    return svg;
  }

  function openEdit(s) {
    var app = M.app, st = app.state(), today = app.today(), sh, count = P.memorized(st, s), total = Q.count(s);
    function after(snap) { app.commit(); if (snap) snapId = s; draw(); }
    function draw() {
      var status = P.status(st, s), m = P.memorized(st, s), pend = V_pending(st, s);
      var inp = h('input', { class: 'input num', type: 'number', inputmode: 'numeric', min: 0, max: total, value: m, 'data-testid': 'pz-count', 'aria-label': 'عدد الآيات المحفوظة' });
      var err = h('small', { class: 'field-err', role: 'alert', 'data-testid': 'pz-err' });
      sh.setTitle('سورة ' + Q.name(s));
      sh.set(h('div', { class: 'stack' },
        h('div', { class: 'row' }, h('span', { class: 'tag' }, 'رقم ' + n(s)), h('span', { class: 'tag' }, n(total) + ' آية'), h('span', { class: 'tag ' + (status === 'done' ? 'good' : status === 'review' ? 'warn' : ''), 'data-testid': 'pz-status' }, LABEL[status]), h('span', { class: 'grow' }), h('b', { 'data-testid': 'pz-mem' }, n(m) + ' / ' + n(total))),
        h('div', { class: 'pbar' }, h('i', { style: 'width:' + (m / total * 100) + '%' })),
        h('div', { class: 'field-label' }, 'حالة السورة'),
        h('div', { class: 'row wrap', role: 'radiogroup' }, ORDER.map(function (k) { return h('button', { class: 'chip', role: 'radio', 'aria-checked': String(k === status), 'aria-pressed': String(k === status), 'data-testid': 'st-' + k, onclick: function () { setStatus(k); } }, LABEL[k]); })),
        M.ui.field('عدد الآيات المحفوظة', h('div', { class: 'row' }, inp, M.ui.btn('حفظ', { kind: 'soft', id: 'pz-save-count', onclick: function () {
          var v = Number(inp.value); if (inp.value === '' || !Number.isInteger(v) || v < 0 || v > total) { err.textContent = 'أدخل عددًا صحيحًا بين ٠ و' + n(total); return; }
          var was = P.status(st, s); P.setMemorized(st, s, v, today); after(was !== 'done' && P.status(st, s) === 'done'); M.ui.toast('حُدّث عدد الآيات');
        } })), 'يُحسب التقدم من هذا العدد (من الآية ١)'), err,
        M.ui.btn('تحديد السورة كمكتملة بالكامل', { icon: 'check', id: 'pz-complete', onclick: function () { setStatus('done'); } }),
        M.ui.btn('إعادة تعيين التقدم', { kind: 'ghost', icon: 'restart', id: 'pz-reset', onclick: function () { setStatus('none'); } }),
        pend ? h('small', null, 'لهذه السورة مراجعات مجدولة: ' + n(pend)) : null));
    }
    function V_pending(st, s) { return M.review.pending(st).filter(function (r) { return r.s === s; }).length; }
    function setStatus(k) {
      var cur = P.status(st, s), m = P.memorized(st, s);
      function apply() {
        var r = P.setStatus(st, s, k, today);
        if (!r.ok) { M.ui.toast(r.reason === 'empty' ? 'سجّل عدد الآيات المحفوظة أولًا ثم حدّدها «تحتاج مراجعة»' : 'تعذّر التغيير', 'error'); return; }
        after(k === 'done' && cur !== 'done'); M.ui.toast('الحالة: ' + LABEL[P.status(st, s)]);
      }
      if (k === cur && k !== 'done') return;
      if (k === 'none' && (m > 0 || cur !== 'none')) return M.ui.confirm({ title: 'إعادة تعيين ' + Q.name(s), text: 'سيُصفَّر تقدم هذه السورة وتُنهى مراجعاتها المجدولة.', danger: true, ok: 'إعادة تعيين' }).then(function (ok) { if (ok) apply(); });
      if (k === 'progress' && m >= total) return M.ui.confirm({ title: 'تحويل إلى جارية', text: 'السورة محفوظة كاملة؛ سيُنقص عدد آياتها المحفوظة آية واحدة لتصبح «جارية». يمكنك تعديل العدد بعد ذلك.', ok: 'متابعة' }).then(function (ok) { if (ok) apply(); });
      apply();
    }
    sh = M.ui.sheet({ title: 'سورة ' + Q.name(s), content: '' }); draw();
  }

  M.views.puzzle = {
    title: 'بازل القرآن', edit: openEdit,
    render: function (ctx) {
      var st = ctx.state, root = h('div'), tot = P.totals(st), svg = board(st);
      root.appendChild(h('section', { class: 'card' },
        h('div', { class: 'row' }, h('div', { class: 'grow' }, h('div', { class: 'counter-big', 'data-testid': 'surah-counter' }, n(svg.dataset.count) + ' / ' + n(114) + ' سورة'), h('small', null, 'مكتملة: ' + n(tot.done) + ' • حفظت ' + n(tot.memorized) + ' آية (' + M.ui.pct(tot.pct) + ')')), M.ui.ring(tot.pct, 64, M.ui.pct(tot.pct))),
        h('div', { class: 'legend', style: 'margin-bottom:0;margin-top:10px' }, ORDER.map(function (k) {
          var col = { none: 'var(--pc-none)', progress: 'var(--pc-prog-base)', done: 'var(--pc-done)', review: 'var(--pc-rev)' }[k], bd = { none: 'var(--pc-none-line)', progress: 'var(--pc-prog)', done: 'var(--primary-text)', review: 'var(--warn-text)' }[k];
          return h('button', { class: 'chip', 'aria-pressed': String(filter === k), 'data-testid': 'legend-' + k, onclick: function () { filter = filter === k ? null : k; ctx.app.render(true); } }, h('i', { class: 'sw', style: 'background:' + col + ';border:2px ' + (k === 'none' ? 'dashed ' : 'solid ') + bd }), LABEL[k] + ' ' + n(tot[k]));
        }))));
      root.appendChild(h('div', { class: 'field', style: 'margin-bottom:8px' }, h('input', { class: 'input', type: 'search', placeholder: 'ابحث عن سورة…', value: query, 'aria-label': 'بحث عن سورة', 'data-testid': 'pz-search', oninput: function (e) {
        query = e.target.value.trim(); M.ui.$$('.pz', root).forEach(function (g) { var nm = Q.name(+g.dataset.s); g.classList.toggle('hit', !!query && nm.indexOf(query) >= 0); g.classList.toggle('dim', (!!query && nm.indexOf(query) < 0) || (!!filter && filter !== g.dataset.st)); }); } })));
      var wrap = h('section', { class: 'card pz-wrap', 'data-testid': 'puzzle-card' }, svg); root.appendChild(wrap);
      function hit(e) { var g = e.target.closest && e.target.closest('.pz'); if (g) openEdit(+g.dataset.s); }
      svg.addEventListener('click', hit);
      svg.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); hit(e); } });
      return root;
    }
  };
})(globalThis.M = globalThis.M || {});
