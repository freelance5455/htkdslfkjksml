/* المراجعة: اليوم، القادمة، السجل + إدارة العناصر */
(function (M) {
  'use strict';
  var h = M.ui.h, icon = M.ui.icon, n = M.ui.n, Q = M.quran, D = M.dates, V = M.review;
  var tab = 'today';
  var RL = V.LABELS, ICON = { excellent: 'star', good: 'check', needs: 'restart', weak: 'info' };

  function stageText(it, iv) { return 'المرحلة ' + n(Math.min(it.stage, iv.length - 1) + 1) + ' من ' + n(iv.length) + (it.lastRating ? ' • آخر تقييم: ' + RL[it.lastRating] : ''); }

  function itemMenu(it) {
    var st = M.app.state(), today = M.app.today(), sh;
    function act(fn, msg) { fn(); M.app.commit(); sh.close(); if (msg) M.ui.toast(msg); }
    var dateInp = h('input', { class: 'input', type: 'date', value: it.due, min: today, 'data-testid': 'rv-date' });
    sh = M.ui.sheet({ title: V.text(it), content: h('div', { class: 'stack' },
      h('p', { class: 'muted' }, 'الموعد: ' + D.rel(it.due, today) + ' • ' + stageText(it, st.settings.review.intervals)),
      h('div', { class: 'btn-row' },
        [1, 3, 7].map(function (d) { return M.ui.btn('تأجيل ' + (d === 1 ? 'يوم' : n(d) + ' أيام'), { kind: 'soft', id: 'rv-postpone-' + d, onclick: function () { act(function () { V.postpone(st, it.id, d, today); }, 'تم التأجيل'); } }); })),
      M.ui.field('تغيير الموعد', dateInp),
      M.ui.btn('حفظ الموعد الجديد', { kind: 'ghost', id: 'rv-save-date', onclick: function () { if (!D.valid(dateInp.value)) { M.ui.toast('تاريخ غير صالح', 'error'); return; } act(function () { V.reschedule(st, it.id, dateInp.value); }, 'تم تغيير الموعد'); } }),
      M.ui.btn('إنهاء متابعة هذا الجزء', { kind: 'ghost', icon: 'check', id: 'rv-retire', onclick: function () { act(function () { V.retire(st, it.id, today); }, 'لن يظهر هذا الجزء في المراجعات'); } }),
      M.ui.btn('حذف', { kind: 'danger', icon: 'trash', id: 'rv-delete', onclick: function () { M.ui.confirm({ title: 'حذف المراجعة', text: 'سيُحذف هذا العنصر وجدولته. يبقى سجل التقييمات السابقة.', danger: true, ok: 'حذف' }).then(function (ok) { if (ok) act(function () { V.remove(st, it.id); }, 'تم الحذف'); }); } })) });
  }

  function addSheet() {
    var st = M.app.state(), today = M.app.today(), f = { s: 67, from: 1, to: 5, due: D.addDays(today, 1) }, sh, err = h('small', { class: 'field-err', role: 'alert', 'data-testid': 'rv-add-err' });
    var to = M.ui.numInput(f.to, { min: 1, max: Q.count(f.s), id: 'rv-add-to', aria: 'إلى آية' }, function (v) { f.to = v; });
    sh = M.ui.sheet({ title: 'إضافة مراجعة يدويًا', content: h('div', null,
      M.ui.field('السورة', M.ui.surahSelect(f.s, function (v) { f.s = v; to.max = Q.count(v); }, 'rv-add-surah')),
      h('div', { class: 'grid2' }, M.ui.field('من آية', M.ui.numInput(f.from, { min: 1, id: 'rv-add-from', aria: 'من آية' }, function (v) { f.from = v; })), M.ui.field('إلى آية', to)),
      M.ui.field('موعد المراجعة', h('input', { class: 'input', type: 'date', value: f.due, 'data-testid': 'rv-add-date', onchange: function (e) { f.due = e.target.value; } })), err,
      M.ui.btn('إضافة', { icon: 'plus', id: 'rv-add-save', onclick: function () { var r = V.addManual(st, f, today); if (!r.ok) { err.textContent = r.error; return; } M.app.commit(); sh.close(); M.ui.toast('أُضيفت المراجعة'); } })) });
  }

  function card(it, st, today, done) {
    var iv = st.settings.review.intervals, c = h('div', { class: 'card rv' + (done ? ' done' : ''), 'data-testid': 'rv-item', 'data-id': it.id, 'data-surah': it.s });
    c.appendChild(h('div', { class: 'rv-head' }, h('div', { class: 'grow' }, h('div', { class: 'rv-title' }, V.text(it)), h('div', { class: 'rv-meta' }, (done ? 'قيّمتها اليوم: ' + RL[it.lastRating] + ' • القادمة ' + D.rel(it.due, today) : (it.due < today ? 'متأخرة ' + D.rel(it.due, today) : 'مستحقة اليوم') + ' • ' + stageText(it, iv)))),
      h('button', { class: 'icon-btn', 'aria-label': 'خيارات', 'data-testid': 'rv-menu', onclick: function () { itemMenu(it); } }, icon('dots'))));
    var rates = h('div', { class: 'rates' });
    V.RATINGS.forEach(function (r) { rates.appendChild(h('button', { class: 'rate ' + r + (done && it.lastRating === r ? ' sel' : ''), 'data-testid': 'rate-' + r, onclick: function () { M.actions.rateReview(it.id, r); } }, icon(ICON[r]), RL[r])); });
    if (!done || true) c.appendChild(rates);
    return c;
  }

  M.views.review = {
    title: 'المراجعة',
    actions: function (top) { top.appendChild(h('button', { class: 'icon-btn', 'aria-label': 'إضافة مراجعة', 'data-testid': 'rv-add', onclick: addSheet }, icon('plus'))); },
    render: function (ctx) {
      var st = ctx.state, today = ctx.today, root = h('div');
      root.appendChild(h('div', { class: 'tabs', role: 'tablist' }, [['today', 'اليوم'], ['upcoming', 'القادمة'], ['history', 'السجل']].map(function (t) {
        return h('button', { role: 'tab', 'aria-selected': String(tab === t[0]), 'data-testid': 'tab-' + t[0], onclick: function () { tab = t[0]; ctx.app.render(true); } }, t[1]);
      })));
      if (tab === 'today') {
        var rv = V.today(st, today);
        if (rv.overdue > 0 || rv.hidden > 0) root.appendChild(h('div', { class: 'banner', 'data-testid': 'overdue-banner' }, icon('info'), h('div', { class: 'grow' }, rv.overdue ? 'لديك ' + n(rv.overdue) + ' مراجعة متأخرة.' : '', rv.hidden ? ' ' + n(rv.hidden) + ' مراجعة فوق الحد اليومي (' + n(st.settings.review.dailyCap) + ').' : '', ' يمكن توزيعها على الأيام القادمة بلا ضغط.'),
          M.ui.btn('إعادة التنظيم', { kind: 'soft', cls: 'btn-sm', id: 'reorganize', onclick: function () {
            var all = V.dueBy(st, today).length, cap = st.settings.review.dailyCap || 10;
            M.ui.confirm({ title: 'إعادة تنظيم المراجعات', text: 'سيُوزَّع ' + n(all) + ' مراجعة مستحقة على ' + n(Math.ceil(all / cap)) + ' يوم بحد أقصى ' + n(cap) + ' يوميًا، والأضعف أولًا.', ok: 'نظّم' }).then(function (ok) { if (ok) { var r = V.reorganize(st, today); ctx.app.commit(); M.ui.toast('تم التوزيع على ' + n(r.days) + ' يوم'); } });
          } })));
        if (rv.hiddenRest) root.appendChild(h('p', { class: 'muted' }, 'اليوم يوم راحة والمراجعات مخفية بحسب إعداداتك.'));
        rv.visible.forEach(function (it) { root.appendChild(card(it, st, today, false)); });
        if (rv.done.length) { root.appendChild(h('div', { class: 'sec-title' }, icon('check'), 'تمت اليوم', h('small', null, n(rv.done.length)))); rv.done.forEach(function (it) { root.appendChild(card(it, st, today, true)); }); }
        if (!rv.visible.length && !rv.done.length && !rv.hiddenRest) root.appendChild(M.ui.empty('لا مراجعات اليوم', 'عند تسجيل ورد جديد تُجدول مراجعته تلقائيًا في اليوم التالي. يمكنك أيضًا إضافة مراجعة يدويًا.', M.ui.btn('إضافة مراجعة', { icon: 'plus', onclick: addSheet })));
      } else if (tab === 'upcoming') {
        var up = V.upcoming(st, today, 60);
        if (!up.length) root.appendChild(M.ui.empty('لا مراجعات قادمة', 'ستظهر هنا بعد تقييم المراجعات.'));
        up.forEach(function (u) { root.appendChild(h('section', { class: 'card' }, h('h2', null, icon('calendar'), D.rel(u.date, today), h('small', { style: 'margin-inline-start:auto' }, D.long(u.date))),
          u.items.map(function (it) { return h('div', { class: 'list-row' }, h('span', { class: 'grow' }, h('b', null, V.text(it)), h('div', { class: 'rv-meta' }, stageText(it, st.settings.review.intervals))), h('button', { class: 'icon-btn', 'aria-label': 'خيارات', onclick: function () { itemMenu(it); } }, icon('dots'))); }))); });
      } else {
        var hist = V.historyList(st).slice(0, 80);
        if (!hist.length) root.appendChild(M.ui.empty('لا سجل بعد', 'سيظهر هنا كل ما راجعته.'));
        else root.appendChild(h('section', { class: 'card' }, hist.map(function (a) { return h('div', { class: 'mini-item' }, h('span', { class: 'dot ' + (a.rating === 'weak' || a.rating === 'needs' ? 'warn' : 'good') }), h('span', { class: 'grow' }, Q.segText({ s: a.s, from: a.from, to: a.to })), h('span', { class: 'tag' }, RL[a.rating] || ''), h('small', null, D.medium(a.date))); })));
      }
      return root;
    }
  };
})(globalThis.M = globalThis.M || {});
