/* الإعدادات وإدارة البيانات: المظهر، التذكيرات، المراجعة، التصدير/الاستيراد */
(function (M) {
  'use strict';
  var h = M.ui.h, icon = M.ui.icon, n = M.ui.n, T = M.themes, B = M.backup, D = M.dates;

  function importFlow(file, app) {
    var rd = new FileReader();
    rd.onerror = function () { M.ui.toast('تعذّرت قراءة الملف', 'error'); };
    rd.onload = function () {
      var r = B.inspect(String(rd.result));
      if (!r.ok) { M.ui.sheet({ title: 'الملف غير صالح', content: h('div', { class: 'stack', 'data-testid': 'import-error' }, h('p', null, 'لم يتغير شيء في بياناتك.'), h('ul', null, r.errors.map(function (e) { return h('li', null, e); }))) }); return; }
      var cur = M.progress.totals(app.state()), sh;
      sh = M.ui.sheet({ title: 'استيراد نسخة احتياطية', content: h('div', { class: 'stack', 'data-testid': 'import-confirm' },
        h('div', { class: 'banner' }, icon('info'), h('div', { class: 'grow' }, h('b', null, 'سيستبدل الاستيراد بياناتك الحالية بالكامل'), ' (الخطط، التقدم، المراجعات، السجل، الإعدادات).')),
        h('ul', { class: 'sum-list' }, h('li', null, h('span', null, 'تاريخ النسخة'), h('b', null, r.exportedAt ? D.medium(r.exportedAt.slice(0, 10)) : 'غير معروف')), h('li', null, h('span', null, 'الآيات المحفوظة فيها'), h('b', null, n(r.summary.memorized))), h('li', null, h('span', null, 'آياتك الحالية'), h('b', null, n(cur.memorized))), h('li', null, h('span', null, 'خطط / مراجعات'), h('b', null, n(r.summary.plans) + ' / ' + n(r.summary.reviews)))),
        r.warnings.length ? h('div', null, h('b', null, 'تنبيهات:'), h('ul', null, r.warnings.slice(0, 6).map(function (w) { return h('li', null, w); }))) : null,
        M.ui.btn('تصدير نسخة من بياناتي الحالية أولًا', { kind: 'soft', icon: 'download', id: 'import-backup-first', onclick: function () { M.ui.download(B.filename(), JSON.stringify(B.build(app.state()), null, 1)); } }),
        M.ui.btn('استبدال بياناتي بهذه النسخة', { kind: 'danger', id: 'import-confirm-btn', onclick: function () { M.store.replace(r.state); sh.close(); M.ui.toast('تم الاستيراد بنجاح', '', { label: 'تراجع', fn: function () { if (M.store.restoreSnapshot()) M.ui.toast('أُعيدت بياناتك السابقة'); } }); } }),
        M.ui.btn('إلغاء', { kind: 'ghost', onclick: function () { sh.close(); } })) });
    };
    rd.readAsText(file);
  }

  function colorRow(label, key, st, app, fallbackVar) {
    var cur = st.settings.colors[key] || (getComputedStyle(document.documentElement).getPropertyValue(fallbackVar).trim() || '#888888');
    if (!/^#[0-9a-f]{6}$/i.test(cur)) cur = '#888888';
    var inp = h('input', { type: 'color', value: cur, 'aria-label': label, 'data-testid': 'color-' + key,
      oninput: function () { st.settings.colors[key] = inp.value; app.applyTheme(); }, onchange: function () { st.settings.colors[key] = inp.value; app.commit(); } });
    return h('div', { class: 'color-row' }, h('label', null, label), inp, st.settings.colors[key] ? h('button', { class: 'icon-btn', 'aria-label': 'إعادة اللون الافتراضي', onclick: function () { st.settings.colors[key] = ''; app.commit(); } }, icon('restart')) : null);
  }

  M.views.settings = {
    title: 'الإعدادات',
    render: function (ctx) {
      var st = ctx.state, s = st.settings, app = ctx.app, root = h('div'), set = function (k, v) { s[k] = v; app.commit(); };

      /* المظهر */
      var th = T.get(s.theme);
      root.appendChild(h('section', { class: 'card' }, h('h2', null, icon('palette'), 'المظهر'),
        h('div', { class: 'list-row link', onclick: function () { app.go('themes'); } }, h('div', { class: 'grow' }, h('b', null, 'الثيم الحالي: ' + th.name), h('div', { class: 'muted', style: 'font-size:.82rem' }, th.desc)), M.ui.btn('المعرض', { kind: 'soft', cls: 'btn-sm' })),
        M.ui.field('الوضع', M.ui.segmented([{ v: 'auto', l: 'تلقائي' }, { v: 'light', l: 'فاتح' }, { v: 'dark', l: 'داكن' }], s.mode, function (v) { set('mode', v); }, 'set-mode')),
        M.ui.field('نمط الخط', M.ui.segmented(Object.keys(T.FONT_NAMES).map(function (k) { return { v: k, l: T.FONT_NAMES[k] }; }), s.fontStyle, function (v) { set('fontStyle', v); }, 'set-font')),
        M.ui.field('حجم الخط (' + n(Math.round(s.fontScale * 100)) + '٪)', h('input', { type: 'range', min: 0.85, max: 1.4, step: 0.05, value: s.fontScale, 'data-testid': 'set-fontscale', 'aria-label': 'حجم الخط', oninput: function (e) { s.fontScale = +e.target.value; app.applyTheme(); }, onchange: function (e) { set('fontScale', +e.target.value); } })),
        M.ui.field('استدارة البطاقات' + (s.radius >= 0 ? ' (' + n(s.radius) + ')' : ' (حسب الثيم)'), h('div', { class: 'row' }, h('input', { type: 'range', min: 0, max: 36, step: 2, value: s.radius >= 0 ? s.radius : 16, 'data-testid': 'set-radius', 'aria-label': 'استدارة البطاقات', oninput: function (e) { s.radius = +e.target.value; app.applyTheme(); }, onchange: function (e) { set('radius', +e.target.value); } }),
          s.radius >= 0 ? h('button', { class: 'icon-btn', 'aria-label': 'استدارة الثيم الافتراضية', onclick: function () { set('radius', -1); } }, icon('restart')) : null)),
        M.ui.field('شريط التنقل', M.ui.segmented([{ v: 'classic', l: 'كلاسيكي' }, { v: 'floating', l: 'عائم' }, { v: 'compact', l: 'مضغوط' }, { v: 'icons', l: 'أيقونات' }], s.navStyle, function (v) { set('navStyle', v); }, 'set-nav')),
        M.ui.field('نمط الأيقونات', M.ui.segmented([{ v: 'line', l: 'خطّي' }, { v: 'solid', l: 'ممتلئ' }, { v: 'soft', l: 'ناعم' }], s.iconStyle, function (v) { set('iconStyle', v); }, 'set-icons')),
        M.ui.toggle(s.deco, function (v) { set('deco', v); }, 'الزخارف والرسومات التزيينية', 'set-deco'),
        h('h3', { style: 'font-size:1rem;margin:12px 0 4px' }, 'ألوان مخصصة'),
        colorRow('اللون الأساسي', 'primary', st, app, '--primary'), colorRow('اللون الثانوي', 'secondary', st, app, '--secondary'), colorRow('لون الخلفية', 'bg', st, app, '--bg'), colorRow('لون التمييز', 'accent', st, app, '--accent'),
        h('small', null, 'يضمن التطبيق قراءة النصوص تلقائيًا مهما اخترت.'),
        M.ui.btn('إعادة ألوان الثيم الأصلية', { kind: 'ghost', id: 'reset-colors', onclick: function () { s.colors = { primary: '', secondary: '', bg: '', accent: '' }; app.commit(); } })));

      /* التذكيرات */
      var r = s.reminders;
      root.appendChild(h('section', { class: 'card' }, h('h2', null, icon('bell'), 'التذكيرات'),
        M.ui.toggle(r.enabled, function (v) {
          if (v && 'Notification' in window && Notification.permission === 'default') Notification.requestPermission().then(function () { r.enabled = true; app.commit(); }); else { r.enabled = v; app.commit(); }
        }, 'تفعيل التذكير اليومي', 'set-remind'),
        M.ui.field('وقت التذكير', h('input', { class: 'input', type: 'time', value: r.time, 'data-testid': 'set-remind-time', onchange: function (e) { if (/^\d\d:\d\d$/.test(e.target.value)) { r.time = e.target.value; r.lastShown = ''; app.commit(); } } })),
        M.ui.toggle(r.mem, function (v) { r.mem = v; app.commit(); }, 'تذكير بورد الحفظ'), M.ui.toggle(r.rev, function (v) { r.rev = v; app.commit(); }, 'تذكير بالمراجعات'),
        h('small', null, 'تنبيه صريح: التطبيق يعمل دون خادم، لذا يظهر التذكير حين يكون مفتوحًا أو في الخلفية بعد وقته. لا يمكن لتطبيق ويب بلا خادم ضمان تنبيه والتطبيق مغلق تمامًا. للتأكد أضف منبّهًا في هاتفك.' + ('Notification' in window ? (Notification.permission === 'denied' ? ' (إشعارات المتصفح محظورة لهذا الموقع.)' : '') : ' (المتصفح لا يدعم الإشعارات؛ ستظهر تنبيهات داخل التطبيق.)'))));

      /* الحفظ والمراجعة */
      var iv = s.review.intervals, ivInp = h('input', { class: 'input', value: iv.join('، '), 'data-testid': 'set-intervals', inputmode: 'numeric', 'aria-label': 'فواصل المراجعة بالأيام' }), ivErr = h('small', { class: 'field-err', 'data-testid': 'set-intervals-err', role: 'alert' });
      root.appendChild(h('section', { class: 'card' }, h('h2', null, icon('review'), 'تفضيلات الحفظ والمراجعة'),
        M.ui.toggle(s.memorize.confirmAhead, function (v) { s.memorize.confirmAhead = v; app.commit(); }, 'اسأل قبل تسجيل ورد يوم قادم', 'set-confirm-ahead'),
        M.ui.field('فواصل المراجعة (أيام، تفصل بينها فاصلة)', ivInp, 'الافتراضي: ١، ٣، ٧، ١٤، ٣٠. الجزء الضعيف يعود لأول فاصل، والمتقن يقفز مرحلتين.'), ivErr,
        h('div', { class: 'btn-row' }, M.ui.btn('حفظ الفواصل', { kind: 'soft', id: 'set-intervals-save', onclick: function () {
          var raw = ivInp.value.replace(/[٠-٩]/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); }).split(/[,،\s]+/).filter(Boolean).map(Number);
          if (!raw.length || raw.length > 10 || raw.some(function (x) { return !Number.isInteger(x) || x < 1 || x > 365; })) { ivErr.textContent = 'أدخل من ١ إلى ١٠ أعداد صحيحة بين ١ و٣٦٥'; return; }
          raw = raw.filter(function (x, i) { return raw.indexOf(x) === i; }).sort(function (a, b) { return a - b; }); s.review.intervals = raw; app.commit(); M.ui.toast('حُفظت الفواصل: ' + raw.map(n).join('، '));
        } }), M.ui.btn('الافتراضي', { kind: 'ghost', onclick: function () { s.review.intervals = [1, 3, 7, 14, 30]; app.commit(); } })),
        M.ui.field('الحد اليومي للمراجعات (٠ = بلا حد)', M.ui.numInput(s.review.dailyCap, { min: 0, max: 200, id: 'set-cap', aria: 'الحد اليومي' }, function (v, el) { if (Number.isInteger(v) && v >= 0 && v <= 200) { s.review.dailyCap = v; M.store.save(); } }), 'يمنع تراكم المراجعات فوق طاقتك'),
        M.ui.toggle(s.review.reviewOnRest, function (v) { s.review.reviewOnRest = v; app.commit(); }, 'إظهار المراجعات في أيام الراحة', 'set-rest-review'),
        M.ui.field('بداية الأسبوع في التقويم', M.ui.segmented([{ v: 6, l: 'السبت' }, { v: 0, l: 'الأحد' }, { v: 1, l: 'الاثنين' }], s.weekStart, function (v) { set('weekStart', v); }, 'set-weekstart'))));

      /* البيانات */
      var file = h('input', { type: 'file', accept: 'application/json,.json', style: 'display:none', 'data-testid': 'import-file', onchange: function (e) { var f = e.target.files[0]; if (f) importFlow(f, app); e.target.value = ''; } });
      root.appendChild(h('section', { class: 'card' }, h('h2', null, icon('download'), 'البيانات والنسخ الاحتياطي'),
        h('p', { class: 'muted' }, 'بياناتك على جهازك فقط. صدّر نسخة بين وقت وآخر، خصوصًا قبل تغيير الهاتف أو مسح بيانات المتصفح.'),
        h('div', { class: 'stack' },
          M.ui.btn('تصدير نسخة احتياطية (JSON)', { icon: 'download', id: 'export', onclick: function () { M.ui.download(B.filename(), JSON.stringify(B.build(app.state()), null, 1)); M.ui.toast('تم إنشاء ملف النسخة الاحتياطية'); } }),
          M.ui.btn('استيراد نسخة احتياطية', { kind: 'soft', icon: 'upload', id: 'import', onclick: function () { file.click(); } }), file,
          M.store.hasSnapshot() ? M.ui.btn('التراجع عن آخر استيراد', { kind: 'ghost', icon: 'undo', id: 'undo-import', onclick: function () { M.ui.confirm({ title: 'التراجع عن الاستيراد', text: 'ستعود بياناتك إلى ما قبل آخر استيراد.', ok: 'تراجع' }).then(function (ok) { if (ok && M.store.restoreSnapshot()) M.ui.toast('أُعيدت البيانات السابقة'); }); } }) : null,
          M.ui.btn('مسح كل البيانات', { kind: 'danger', icon: 'trash', id: 'wipe', onclick: function () {
            M.ui.confirm({ title: 'مسح كل البيانات؟', text: 'سيُحذف كل شيء: الخطط والتقدم والمراجعات والإعدادات. لا يمكن التراجع إلا بنسخة احتياطية.', danger: true, ok: 'متابعة' }).then(function (ok) { if (!ok) return; return M.ui.confirm({ title: 'تأكيد أخير', text: 'هل أنت متأكد تمامًا؟ صدّرت نسخة احتياطية؟', danger: true, ok: 'نعم، امسح كل شيء' }).then(function (ok2) { if (ok2) { M.store.wipe(); M.ui.toast('مُسحت البيانات'); app.go('plan'); } }); });
          } }))));

      /* عن التطبيق */
      root.appendChild(h('section', { class: 'card' }, h('h2', null, icon('info'), 'عن مِداد'),
        h('ul', { class: 'sum-list' }, h('li', null, h('span', null, 'الإصدار'), h('b', null, '١٫٠٫٠')), h('li', null, h('span', null, 'التخزين'), h('b', null, M.store.storage.persistent() ? 'محلي دائم' : 'مؤقت')), h('li', null, h('span', null, 'العمل دون اتصال'), h('b', { 'data-testid': 'offline-state' }, 'serviceWorker' in navigator && navigator.serviceWorker.controller ? 'مفعّل' : 'يُفعَّل بعد أول تحميل'))),
        h('p', { class: 'muted' }, 'مِداد للتخطيط والمتابعة فقط؛ لا يتضمن تلاوة صوتية ولا تعرّفًا على الصوت، ولا حسابات ولا إعلانات ولا اشتراكات.')));
      return root;
    }
  };
})(globalThis.M = globalThis.M || {});
