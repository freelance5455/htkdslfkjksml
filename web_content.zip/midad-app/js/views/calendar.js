/* التقويم الشهري */
(function (M) {
  'use strict';
  var h = M.ui.h, icon = M.ui.icon, n = M.ui.n, Q = M.quran, D = M.dates, PL = M.plan, V = M.review, C = M.calendar;
  var ym = null, sel = null;

  function daySheet(date) {
    var app = M.app, st = app.state(), today = app.today(), info = C.dayInfo(st, date, today), sh;
    var body = h('div', { class: 'stack', 'data-testid': 'day-sheet' });
    var kind = info.type === 'mem' ? 'يوم حفظ' : info.type === 'opt' ? 'يوم مراجعة اختيارية' : info.type === 'paused' ? 'الخطة متوقفة' : info.type === 'rest' ? 'يوم راحة' : 'خارج الخطة';
    body.appendChild(h('div', { class: 'row wrap' }, h('span', { class: 'tag' }, kind), info.isToday ? h('span', { class: 'tag accent' }, 'اليوم') : null, h('small', null, D.hijri(date))));
    info.memDone.forEach(function (a) { body.appendChild(h('div', { class: 'done-banner', 'data-testid': 'day-mem-done' }, icon('check'), h('span', null, 'أُنجز الحفظ: ' + Q.segsText(a.segments)))); });
    if (info.planned && !info.memDone.length) {
      if (info.projection) body.appendChild(h('div', { class: 'portion' }, h('div', { class: 'meta' }, info.isToday ? 'ورد اليوم' : 'الورد المتوقع (تقريبي)'), h('div', { class: 'seg-line' }, Q.segsText(info.projection.segments))));
      if (info.missed) body.appendChild(h('div', { class: 'banner' }, icon('info'), h('div', { class: 'grow' }, 'لم يُسجَّل ورد هذا اليوم. لا بأس، لا تراكم: ورد واحد فقط ينتظرك.')));
      var pend = PL.pending(st, today);
      if (pend.status === 'ready') {
        var di = h('input', { class: 'input', type: 'date', value: date >= today ? date : today, min: today, 'data-testid': 'resched-date' });
        body.appendChild(M.ui.field(info.missed ? 'إعادة جدولة الورد المعلّق إلى' : 'نقل الورد إلى', di));
        body.appendChild(M.ui.btn('إعادة الجدولة', { kind: 'soft', icon: 'moveto', id: 'resched-mem', onclick: function () { if (!D.valid(di.value) || di.value < today) { M.ui.toast('اختر تاريخًا من اليوم فصاعدًا', 'error'); return; } PL.reschedule(st, di.value, today); app.commit(); sh.close(); M.ui.toast('نُقل الورد إلى ' + D.long(di.value)); } }));
      }
    }
    if (info.optional) body.appendChild(h('p', { class: 'muted' }, 'مراجعة اختيارية: لا تُحتسب فائتة.'));
    if (info.optDone.length) body.appendChild(h('div', { class: 'done-banner' }, icon('check'), 'أُنجزت المراجعة الاختيارية'));
    if (info.revDone.length || info.revDue.length) {
      body.appendChild(h('h3', { style: 'font-size:1rem' }, 'المراجعات'));
      info.revDone.forEach(function (a) { body.appendChild(h('div', { class: 'mini-item', 'data-testid': 'day-rev-done' }, h('span', { class: 'dot good' }), h('span', { class: 'grow' }, Q.segText({ s: a.s, from: a.from, to: a.to })), h('span', { class: 'tag good' }, V.LABELS[a.rating]))); });
      info.revDue.forEach(function (it) {
        var di = h('input', { class: 'input', type: 'date', value: today, min: today, style: 'max-width:150px' });
        body.appendChild(h('div', { class: 'mini-item', 'data-testid': 'day-rev-due' }, h('span', { class: 'dot warn' }), h('span', { class: 'grow' }, V.text(it)), info.isPast ? h('span', { class: 'tag warn' }, 'فائتة') : null,
          h('button', { class: 'btn btn-soft btn-sm', onclick: function () { var d = di.value; if (!D.valid(d)) return; V.reschedule(st, it.id, d); app.commit(); sh.close(); M.ui.toast('أُعيدت جدولة المراجعة'); } }, 'نقل إلى'), di));
      });
    }
    if (!info.memDone.length && !info.planned && !info.revDone.length && !info.revDue.length && !info.optDone.length) body.appendChild(h('p', { class: 'muted' }, 'لا مهام في هذا اليوم.'));
    sh = M.ui.sheet({ title: D.long(date), content: body });
  }

  M.views.calendar = {
    title: 'التقويم',
    render: function (ctx) {
      var st = ctx.state, today = ctx.today, root = h('div');
      var td = D.parse(today); if (!ym) ym = { y: td.getFullYear(), m: td.getMonth() };
      var ws = st.settings.weekStart;
      function shift(d) { var x = new Date(ym.y, ym.m + d, 1); ym = { y: x.getFullYear(), m: x.getMonth() }; ctx.app.render(true); }
      root.appendChild(h('div', { class: 'cal-head' }, h('button', { class: 'icon-btn', 'aria-label': 'الشهر السابق', 'data-testid': 'cal-prev', onclick: function () { shift(-1); } }, icon('prev')),
        h('h2', { 'data-testid': 'cal-title' }, D.MONTHS[ym.m] + ' ' + n(ym.y)), h('button', { class: 'icon-btn', 'aria-label': 'الشهر التالي', 'data-testid': 'cal-next', onclick: function () { shift(1); } }, icon('next'))));
      var card = h('section', { class: 'card' }), grid = h('div', { class: 'cal-grid', role: 'grid' });
      for (var i = 0; i < 7; i++) grid.appendChild(h('div', { class: 'cal-dow' }, D.DAYS_SHORT[(ws + i) % 7]));
      C.month(st, ym.y, ym.m, today).forEach(function (c) {
        if (!c.inMonth) { grid.appendChild(h('div', { class: 'cal-cell out' })); return; }
        var i = c.info, marks = h('span', { class: 'marks' });
        if (i.memDone.length || i.optDone.length) marks.appendChild(h('span', { class: 'mk ok', html: '<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>' }));
        else if (i.planned) marks.appendChild(h('span', { class: 'mk' }));
        if (i.optional && !i.optDone.length) marks.appendChild(h('span', { class: 'mk opt' }));
        if (i.revDue.length || i.revDone.length) marks.appendChild(h('span', { class: 'mk rev' }));
        var cls = 'cal-cell' + (i.isToday ? ' today' : '') + (i.rest ? ' rest' : '') + (i.missed ? ' missed' : '') + (sel === c.date ? ' sel' : '');
        var label = D.long(c.date) + (i.memDone.length ? '، حفظ منجز' : i.missed ? '، حفظ فائت' : i.planned ? '، يوم حفظ' : i.rest ? '، راحة' : '') + (i.revDue.length ? '، مراجعات' : '');
        grid.appendChild(h('button', { class: cls, 'data-date': c.date, 'data-testid': 'cal-day', 'aria-label': label, onclick: function () { sel = c.date; daySheet(c.date); ctx.app.render(true); } }, h('span', { class: 'n' }, n(D.parse(c.date).getDate())), marks));
      });
      card.appendChild(grid); root.appendChild(card);
      root.appendChild(h('div', { class: 'legend' },
        [['mk', 'حفظ'], ['mk rev', 'مراجعة'], ['mk opt', 'مراجعة اختيارية'], ['mk ok', 'منجز', true], ['', 'فائت', 'miss'], ['', 'راحة', 'rest']].map(function (l) {
          return h('span', { class: 'chip', style: 'min-height:32px;font-size:.8rem' }, l[2] === true ? h('span', { class: 'mk ok', html: '<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>' }) : l[2] === 'miss' ? h('span', { class: 'dot', style: 'background:var(--danger);width:8px;height:8px' }) : l[2] === 'rest' ? h('span', { class: 'dot none', style: 'border:1px dashed var(--muted);background:none' }) : h('span', { class: l[0] }), l[1]);
        })));
      root.appendChild(h('div', { class: 'btn-row' }, M.ui.btn('اليوم', { kind: 'ghost', id: 'cal-today', onclick: function () { ym = { y: td.getFullYear(), m: td.getMonth() }; ctx.app.render(true); } })));
      return root;
    }
  };
})(globalThis.M = globalThis.M || {});
