/* الصفحة الرئيسية + إجراءات مشتركة */
(function (M) {
  'use strict';
  var h = M.ui.h, icon = M.ui.icon, n = M.ui.n, Q = M.quran, D = M.dates, PL = M.plan, V = M.review, P = M.progress;
  M.ui.pct = function (v) { var s = v >= 10 || v === 0 ? String(Math.round(v)) : (Math.round(v * 10) / 10).toFixed(1).replace('.', '٫'); return n(s) + '٪'; };
  M.ui.pageOf = function (ayat) { var p = ayat / 10.3; return p < 0.4 ? 'أقل من ثلث صفحة' : '≈ ' + n((Math.round(p * 10) / 10).toString().replace('.', '٫')) + ' صفحة'; };
  var A = M.actions = {};

  /** تسجيل إنجاز الورد المعروض (بمفتاحه) مع منع التكرار وإمكانية التراجع */
  A.completeMem = function (pend) {
    var app = M.app, st = app.state(), today = app.today();
    function go() {
      var r = PL.complete(st, { key: pend.key, today: today });
      if (!r.ok) { M.ui.toast(r.reason === 'duplicate' ? 'سُجّل إنجاز هذا الورد مسبقًا' : r.reason === 'stale' ? 'تغيّر الورد، حدّثت الشاشة' : 'لا يوجد ورد لتسجيله'); app.render(true); return false; }
      app.commit();
      var id = r.entry.id;
      if (r.finished) M.ui.toast('🎉 أتممت خطة الحفظ كاملة، بارك الله فيك!');
      else M.ui.toast('تم تسجيل الورد ✓ وجُدولت مراجعته غدًا', '', { label: 'تراجع', fn: function () { if (PL.undo(M.store.state, id)) { M.app.commit(); M.ui.toast('تم التراجع عن الإنجاز'); } } });
      return true;
    }
    if (pend.isAhead && st.settings.memorize.confirmAhead) {
      return M.ui.confirm({ title: 'تسجيل ورد ' + D.rel(pend.forDate, today), text: 'هذا ورد ' + D.rel(pend.forDate, today) + ' (' + Q.segsText(pend.segments) + ').\nهل أتممته مبكرًا؟' , ok: 'نعم، أتممته' }).then(function (ok) { return ok ? go() : false; });
    }
    return Promise.resolve(go());
  };
  A.rateReview = function (id, rating) {
    var st = M.app.state(), r = V.rate(st, id, rating, M.app.today());
    if (r.ok) { M.app.commit(); M.ui.toast('المراجعة القادمة: ' + D.rel(r.item.due, M.app.today())); }
  };

  function segLine(pend) { return Q.segsText(pend.segments); }

  M.views.home = {
    title: 'مِداد',
    render: function (ctx) {
      var st = ctx.state, today = ctx.today, app = ctx.app, root = h('div');
      var tot = P.totals(st), pend = PL.pending(st, today), rv = V.today(st, today), g = M.growth.compute(st, today);
      var themeId = app.previewId || st.settings.theme, motif = M.themes.get(themeId).motif;
      var plan = PL.active(st), memToday = PL.memEntriesOn(st, today);

      /* رأس */
      root.appendChild(h('section', { class: 'card hero' }, h('div', { html: M.art.hero(motif) }).firstChild,
        h('div', { class: 'hero-in' },
          h('div', { class: 'grow' }, h('h2', null, 'السلام عليكم'), h('div', { class: 'date' }, D.long(today)), h('div', { class: 'hijri' }, D.hijri(today)),
            h('div', { class: 'row', style: 'margin-top:6px;gap:6px' }, h('span', { class: 'tag' }, n(tot.memorized) + ' / ' + n(Q.TOTAL_AYAT) + ' آية'))),
          UI_ring(tot.pct))));

      /* ورد الحفظ */
      var mem = h('section', { class: 'card', 'data-testid': 'mem-card' });
      mem.appendChild(h('h2', null, icon('book'), pend.status === 'ready' ? (pend.isToday ? 'ورد الحفظ اليوم' : 'ورد الحفظ — ' + D.rel(pend.forDate, today)) : 'ورد الحفظ'));
      if (pend.status === 'none') {
        mem.appendChild(h('p', { class: 'muted' }, 'لا توجد خطة حفظ حاليًا. أنشئ خطتك: اختر مكان البداية والمقدار اليومي كما تشاء.'));
        mem.appendChild(M.ui.btn('إنشاء خطة الحفظ', { icon: 'plan', id: 'create-plan', onclick: function () { app.go('plan'); } }));
      } else if (pend.status === 'paused') {
        mem.appendChild(h('div', { class: 'done-banner', style: 'background:var(--warn-soft)' }, icon('pause'), 'الخطة متوقفة مؤقتًا'));
        mem.appendChild(h('div', { class: 'btn-row' }, M.ui.btn('استئناف الخطة', { icon: 'play', id: 'resume-plan', onclick: function () { PL.resume(st, today); app.commit(); } }), M.ui.btn('تعديل الخطة', { kind: 'ghost', onclick: function () { app.go('plan'); } })));
      } else if (pend.status === 'done') {
        mem.appendChild(h('div', { class: 'done-banner' }, icon('check'), 'أتممت خطتك بالكامل. ما شاء الله!'));
        mem.appendChild(M.ui.btn('إنشاء خطة جديدة', { icon: 'plus', onclick: function () { app.go('plan'); } }));
      } else {
        if (memToday.length && pend.isAhead) {
          var last = PL.lastMem(st);
          mem.appendChild(h('div', { class: 'done-banner', 'data-testid': 'today-done' }, icon('check'), h('span', { class: 'grow' }, 'أتممت ورد اليوم ✓'),
            last ? h('button', { class: 'btn btn-sm btn-ghost', 'data-testid': 'undo-mem', onclick: function () { if (PL.undo(st, last.id)) { app.commit(); M.ui.toast('تم التراجع'); } } }, 'تراجع') : null));
        } else if (!pend.isToday && pend.todayType !== 'mem') {
          mem.appendChild(h('p', { class: 'muted' }, pend.todayType === 'opt' ? 'اليوم يوم مراجعة اختيارية، وورد الحفظ التالي:' : 'اليوم يوم راحة، وورد الحفظ التالي:'));
        }
        mem.appendChild(h('div', { class: 'portion' }, h('div', { class: 'seg-line', 'data-testid': 'portion-text' }, segLine(pend)),
          h('div', { class: 'meta' }, n(pend.ayat) + ' آية • ' + M.ui.pageOf(pend.ayat) + ' • متبقٍ في الخطة ' + n(pend.remaining) + ' آية')));
        mem.appendChild(h('div', { class: 'btn-row' },
          M.ui.btn('بدء حفظ اليوم', { kind: 'soft', icon: 'play', id: 'start-session', onclick: function () { app.go('session'); } }),
          M.ui.btn('أتممت الورد', { icon: 'check', id: 'complete-mem', onclick: function () { A.completeMem(pend); } })));
      }
      root.appendChild(mem);

      /* ورد المراجعة */
      var rvc = h('section', { class: 'card', 'data-testid': 'review-card' }, h('h2', null, icon('review'), 'ورد المراجعة اليوم'));
      if (rv.hiddenRest) rvc.appendChild(h('p', { class: 'muted' }, 'يوم راحة: أُخفيت المراجعات المستحقة (يمكن تغيير ذلك من الإعدادات).'));
      else if (!rv.total && !rv.done.length) rvc.appendChild(h('p', { class: 'muted' }, 'لا مراجعات مستحقة اليوم.'));
      else {
        rvc.appendChild(h('p', null, h('b', null, n(rv.done.length) + ' منجزة'), ' • ' + n(rv.total) + ' متبقية' + (rv.overdue ? ' (منها ' + n(rv.overdue) + ' متأخرة)' : '')));
        rv.visible.slice(0, 3).forEach(function (it) { rvc.appendChild(h('div', { class: 'mini-item' }, h('span', { class: 'dot ' + (it.lastRating === 'weak' || it.lastRating === 'needs' ? 'warn' : '') }), h('span', { class: 'grow' }, V.text(it)), h('small', null, D.rel(it.due, today)))); });
        if (rv.total > 3) rvc.appendChild(h('small', null, '… و' + n(rv.total - 3) + ' أخرى'));
      }
      rvc.appendChild(h('div', { style: 'margin-top:10px' }, M.ui.btn('فتح مراجعة اليوم', { kind: rv.total ? 'primary' : 'soft', icon: 'review', id: 'open-review', onclick: function () { app.go('review'); } })));
      root.appendChild(rvc);

      /* مراجعة اختيارية */
      if (plan && plan.status === 'active' && pend.todayType === 'opt' && !st.activity.some(function (a) { return a.type === 'opt' && a.date === today; })) {
        var opt = PL.optionalReview(st, today);
        if (opt.length) root.appendChild(h('section', { class: 'card' }, h('h2', null, icon('sparkle'), 'مراجعة اختيارية'), h('p', { class: 'muted' }, 'يوم مراجعة اختياري: راجع ما حفظته مؤخرًا إن تيسّر.'), h('p', null, Q.segsText(opt)),
          M.ui.btn('تمّت المراجعة الاختيارية', { kind: 'soft', id: 'opt-done', onclick: function () { P.log(st, { type: 'opt', date: today, segments: opt, ayahs: 0 }); app.commit(); M.ui.toast('بارك الله فيك'); } })));
      }

      /* حالة مهام اليوم */
      var tasks = [], memScheduled = pend.status === 'ready' && (pend.isToday || memToday.length);
      if (memScheduled || memToday.length) tasks.push({ t: 'ورد الحفظ', ok: memToday.length > 0 });
      var rvTotal = rv.visible.length + rv.done.length; if (rvTotal) tasks.push({ t: 'المراجعات (' + n(rv.done.length) + '/' + n(rvTotal) + ')', ok: rv.visible.length === 0 });
      var doneN = tasks.filter(function (x) { return x.ok; }).length, pctDay = tasks.length ? Math.round(doneN / tasks.length * 100) : 100;
      var tc = h('section', { class: 'card', 'data-testid': 'tasks-card' }, h('h2', null, icon('target'), 'مهام اليوم'),
        h('div', { class: 'row' }, M.ui.ring(pctDay, 84, n(pctDay) + '٪', 'اليوم'), h('div', { class: 'grow' },
          tasks.length ? tasks.map(function (x) { return h('div', { class: 'task' + (x.ok ? ' ok' : '') }, h('span', { class: 'box' }, icon('check')), h('span', null, x.t)); }) : h('p', { class: 'muted' }, 'لا مهام مجدولة اليوم 🌿'))));
      root.appendChild(tc);

      /* وصول سريع */
      root.appendChild(h('div', { class: 'quick' },
        h('button', { 'data-testid': 'q-session', onclick: function () { app.go('session'); } }, icon('play'), 'بدء حفظ اليوم'),
        h('button', { 'data-testid': 'q-review', onclick: function () { app.go('review'); } }, icon('review'), 'فتح مراجعة اليوم'),
        h('button', { 'data-testid': 'q-plan', onclick: function () { app.go('plan'); } }, icon('plan'), 'تعديل خطة الحفظ'),
        h('button', { 'data-testid': 'q-puzzle', onclick: function () { app.go('puzzle'); } }, icon('puzzle'), 'عرض بازل القرآن')));

      /* قادمة */
      var up = V.upcoming(st, today, 7).slice(0, 4);
      root.appendChild(h('section', { class: 'card' }, h('h2', null, icon('clock'), 'المراجعات القادمة'),
        up.length ? up.map(function (u) { return h('div', { class: 'mini-item' }, h('span', { class: 'dot good' }), h('span', { class: 'grow' }, D.rel(u.date, today)), h('b', null, n(u.items.length)), h('small', null, 'مراجعة')); }) : h('p', { class: 'muted' }, 'لا مراجعات في الأيام السبعة القادمة.')));

      /* ضعيفة */
      var weak = V.weak(st);
      var seen = {}; weak = weak.filter(function (w) { if (seen[w.s]) return false; seen[w.s] = 1; return true; }).slice(0, 6);
      root.appendChild(h('section', { class: 'card', 'data-testid': 'weak-card' }, h('h2', null, icon('info'), 'مواضع تحتاج اهتمامًا'),
        weak.length ? h('div', { class: 'row wrap' }, weak.map(function (w) { return h('button', { class: 'chip', onclick: function () { M.views.puzzle.edit(w.s); } }, Q.name(w.s) + (w.virtual ? '' : ' (' + n(w.from) + '–' + n(w.to) + ')')); }))
          : h('p', { class: 'muted' }, 'لا مواضع ضعيفة حاليًا. حين تقيّم مراجعة بـ«ضعيف» أو «يحتاج تثبيت» تظهر هنا.')));

      /* نمو */
      root.appendChild(h('section', { class: 'card', style: 'cursor:pointer', onclick: function () { app.go('garden'); } },
        h('div', { class: 'row' }, h('div', { style: 'width:72px', html: M.art.plant(g.stage) }), h('div', { class: 'grow' }, h('b', null, 'رحلتك: ' + g.info.name), h('div', { class: 'muted' }, n(g.days) + ' يوم اجتهاد • ' + n(g.streak) + ' متتالية'), h('div', { class: 'pbar', style: 'margin-top:6px' }, h('i', { style: 'width:' + Math.round(g.frac * 100) + '%' }))), icon('next'))));
      return root;
      function UI_ring(p) { return M.ui.ring(p, 92, M.ui.pct(p), 'محفوظ'); }
    }
  };
})(globalThis.M = globalThis.M || {});
