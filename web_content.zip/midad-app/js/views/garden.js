/* رحلة النمو: تشجّع الاستمرار ولا تعاقب على الغياب */
(function (M) {
  'use strict';
  var h = M.ui.h, icon = M.ui.icon, n = M.ui.n, D = M.dates, G = M.growth;
  M.views.garden = {
    title: 'رحلة النمو',
    render: function (ctx) {
      var g = G.compute(ctx.state, ctx.today), root = h('div');
      var msg = g.days === 0 ? 'بذرتك جاهزة. أول ورد يبدأ الرحلة 🌱' : g.stage === 4 ? 'ما شاء الله! حديقة عامرة بثمرة استمرارك.' : 'تقدّمك محفوظ دائمًا؛ يوم فائت لا يمحو ما نمت.';
      root.appendChild(h('section', { class: 'card', style: 'text-align:center' }, h('div', { class: 'plant-big', html: M.art.plant(g.stage), 'data-testid': 'plant' }), h('h2', { style: 'justify-content:center;margin-top:6px', 'data-testid': 'stage-name' }, g.info.name), h('p', { class: 'muted' }, g.info.hint),
        g.next ? h('div', null, h('div', { class: 'pbar' }, h('i', { style: 'width:' + Math.round(g.frac * 100) + '%' })), h('small', null, 'تبقّى ' + n(g.toNext) + ' يوم اجتهاد للوصول إلى «' + g.next.name + '»')) : h('small', null, 'بلغت أعلى مراحل الرحلة'), h('p', { style: 'margin-top:10px' }, msg)));
      root.appendChild(h('div', { class: 'grid3', style: 'margin-bottom:14px' }, h('div', { class: 'stat' }, h('b', { 'data-testid': 'g-days' }, n(g.days)), h('small', null, 'يوم اجتهاد')), h('div', { class: 'stat good' }, h('b', null, n(g.streak)), h('small', null, 'أيام متتالية')), h('div', { class: 'stat accent' }, h('b', null, n(g.best)), h('small', null, 'أفضل سلسلة'))));
      root.appendChild(h('section', { class: 'card' }, h('h2', null, icon('calendar'), 'آخر ٧ أيام'), h('div', { class: 'week' }, g.week.map(function (d) { return h('div', { class: 'd' + (d.active ? ' on' : d.grace ? ' g' : '') }, D.DAYS_SHORT[D.dow(d.date)], h('i')); })), h('small', null, 'الدائرة المتقطعة: يوم راحة، لا يقطع السلسلة. ويُسمح بيوم فائت واحد بين يومين دون كسرها.')));
      root.appendChild(h('section', { class: 'card' }, h('h2', null, icon('plant'), 'مراحل الرحلة'), h('div', { class: 'stage-row' }, G.STAGES.map(function (s, i) { return h('div', { class: 'st' + (i <= g.stage ? ' on' : '') }, h('div', { html: M.art.plant(i) }), s.name, h('div', null, n(s.at) + '+')); }))));
      return root;
    }
  };
})(globalThis.M = globalThis.M || {});
