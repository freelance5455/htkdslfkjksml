/* محرر خطة الحفظ وإدارتها (إيقاف/استئناف/إعادة بدء/خطة جديدة) */
(function (M) {
  'use strict';
  var h = M.ui.h, icon = M.ui.icon, n = M.ui.n, Q = M.quran, D = M.dates, PL = M.plan;
  var UNITS = [{ v: 'ayat', l: 'آيات' }, { v: 'page', l: 'صفحات' }, { v: 'half', l: 'نصف صفحة' }, { v: 'quarter', l: 'ربع صفحة' }, { v: 'custom', l: 'مخصص' }];
  var DAYT = { mem: 'حفظ', rest: 'راحة', opt: 'مراجعة' }, NEXT = { mem: 'rest', rest: 'opt', opt: 'mem' };
  var mode = null; // 'new' لإنشاء خطة جديدة بدل تعديل الحالية

  function estimate(st, form, plan, today) {
    var i1 = Q.toIdx(form.startS, form.startA), i2 = Q.toIdx(form.endS, form.endA); if (i1 > i2) return null;
    var cur = plan && !(plan.startS !== form.startS || plan.startA !== form.startA) ? Math.max(plan.cursor, i1) : i1;
    var rem = i2 - cur + 1, per = Q.unitAyat(form.unit, form.value); if (rem <= 0 || !(per > 0)) return { total: i2 - i1 + 1, rem: 0, days: 0, end: today, per: per };
    var portions = Math.ceil(rem / per), d = today, c = 0, guard = 0;
    while (guard++ < 4000) { if (form.days[D.dow(d)] === 'mem') { c++; if (c >= portions) break; } d = D.addDays(d, 1); }
    return { total: i2 - i1 + 1, rem: rem, portions: portions, end: d, per: per };
  }

  M.views.plan = {
    title: 'خطة الحفظ',
    render: function (ctx) {
      var st = ctx.state, today = ctx.today, app = ctx.app, plan = PL.active(st), root = h('div', { 'data-keep-render': '' });
      var isNew = mode === 'new' || !plan, welcome = !st.settings.onboarded && !st.plans.length;
      var form = isNew ? PL.defaults() : { name: plan.name, startS: plan.startS, startA: plan.startA, endS: plan.endS, endA: plan.endA, unit: plan.unit, value: plan.value, days: JSON.parse(JSON.stringify(PL.cfgAt(plan, today))) };
      var errs = {};
      function done() { root.removeAttribute('data-keep-render'); }

      if (welcome) {
        root.appendChild(h('div', { class: 'welcome' }, h('div', { html: M.art.plant(0), style: 'width:120px;margin:0 auto' }), h('h2', null, 'أهلًا بك في مِداد'), h('p', { class: 'muted' }, 'رفيقك لتنظيم الحفظ والمراجعة. كل شيء يبقى على جهازك ويعمل دون إنترنت. اختر خطتك أدناه — الافتراضي سورة الملك لكن يمكنك البدء من أي موضع.'),
          h('button', { class: 'btn btn-ghost btn-sm', 'data-testid': 'skip-onboard', onclick: function () { st.settings.onboarded = true; done(); app.commit(); app.go('home'); } }, 'تخطي الآن')));
      }

      /* ملخص الخطة الحالية وأزرار التحكم */
      if (plan && !isNew) {
        var s1 = Q.fromIdx(Math.min(plan.cursor, PL.endIdx(plan))), pend = PL.pending(st, today);
        var statusTxt = { active: 'نشطة', paused: 'متوقفة مؤقتًا', done: 'مكتملة', ended: 'منتهية' }[plan.status];
        var card = h('section', { class: 'card', 'data-testid': 'plan-summary' }, h('h2', null, icon('target'), plan.name, h('span', { class: 'tag ' + (plan.status === 'active' ? 'good' : 'warn'), style: 'margin-inline-start:auto' }, statusTxt)),
          h('ul', { class: 'sum-list' },
            h('li', null, h('span', null, 'من'), h('b', null, Q.name(plan.startS) + ' ' + n(plan.startA))), h('li', null, h('span', null, 'إلى'), h('b', null, Q.name(plan.endS) + ' ' + n(plan.endA))),
            h('li', null, h('span', null, 'الموضع التالي'), h('b', null, plan.status === 'done' ? 'اكتملت' : Q.name(s1.s) + ' ' + n(s1.a))),
            h('li', null, h('span', null, 'المقدار اليومي'), h('b', null, n(PL.ayatPerDay(plan)) + ' آية'))),
          h('div', { class: 'btn-row' },
            plan.status === 'paused' ? M.ui.btn('استئناف', { icon: 'play', id: 'plan-resume', onclick: function () { PL.resume(st, today); done(); app.commit(); M.ui.toast('تم استئناف الخطة'); } })
              : plan.status === 'active' ? M.ui.btn('إيقاف مؤقت', { kind: 'soft', icon: 'pause', id: 'plan-pause', onclick: function () { PL.pause(st, today); done(); app.commit(); M.ui.toast('الخطة متوقفة، سجلك محفوظ'); } }) : null,
            M.ui.btn('إعادة البدء', { kind: 'soft', icon: 'restart', id: 'plan-restart', onclick: function () { M.ui.confirm({ title: 'إعادة بدء الخطة', text: 'سيعود ورد الحفظ إلى بداية الخطة. يبقى سجل الحفظ والمراجعة كما هو.', ok: 'إعادة البدء' }).then(function (ok) { if (ok) { PL.restart(st, today); done(); app.commit(); M.ui.toast('أُعيد بدء الخطة'); } }); } }),
            M.ui.btn('خطة جديدة', { kind: 'soft', icon: 'plus', id: 'plan-new', onclick: function () { mode = 'new'; done(); app.render(true); } }),
            M.ui.btn('إنهاء الخطة', { kind: 'ghost', icon: 'close', id: 'plan-end', onclick: function () { M.ui.confirm({ title: 'إنهاء الخطة', text: 'ستنتهي هذه الخطة ويبقى كل ما سجّلته. يمكنك إنشاء خطة جديدة في أي وقت.', ok: 'إنهاء', danger: true }).then(function (ok) { if (ok) { PL.end(st, today); mode = null; done(); app.commit(); } }); } })));
        root.appendChild(card);
      }

      /* المحرر */
      var summary = h('div', { class: 'plan-sum', 'data-testid': 'plan-estimate' });
      var ed = h('section', { class: 'card', 'data-testid': 'plan-editor' });
      function updSummary() {
        var v = PL.validate(form), est = v.ok ? estimate(st, form, isNew ? null : plan, today) : null; summary.textContent = '';
        if (est) {
          summary.appendChild(h('div', { class: 'stat' }, h('b', null, n(est.per)), h('small', null, 'آية يوميًا (' + M.ui.pageOf(est.per) + ')')));
          summary.appendChild(h('div', { class: 'stat accent' }, h('b', null, n(est.rem)), h('small', null, 'آية متبقية')));
          if (est.rem > 0) summary.appendChild(h('div', { class: 'stat good', style: 'grid-column:1/-1' }, h('b', { style: 'font-size:1.1rem' }, D.medium(est.end)), h('small', null, 'التاريخ المتوقع للإتمام (' + n(est.portions) + ' ورد)')));
        }
      }
      function build() {
        ed.textContent = '';
        ed.appendChild(h('h2', null, icon('edit'), isNew ? 'خطة جديدة' : 'تعديل الخطة'));
        ed.appendChild(M.ui.field('اسم الخطة', h('input', { class: 'input', value: form.name, maxlength: 60, 'data-testid': 'plan-name', oninput: function (e) { form.name = e.target.value; } })));
        var startA, endA;
        ed.appendChild(h('h3', { style: 'font-size:1rem;margin:8px 0' }, 'نقطة البداية'));
        ed.appendChild(h('div', { class: 'grid2' },
          M.ui.field('السورة', M.ui.surahSelect(form.startS, function (v) { form.startS = v; form.startA = Math.min(form.startA, Q.count(v)); build(); }, 'plan-start-surah')),
          M.ui.field('الآية', (startA = M.ui.numInput(form.startA, { min: 1, max: Q.count(form.startS), id: 'plan-start-ayah', aria: 'آية البداية' }, function (v) { form.startA = v; upd(); })), 'من ١ إلى ' + n(Q.count(form.startS)), errs.startA)));
        ed.appendChild(h('h3', { style: 'font-size:1rem;margin:8px 0' }, 'الهدف'));
        ed.appendChild(h('div', { class: 'grid2' },
          M.ui.field('السورة', M.ui.surahSelect(form.endS, function (v) { form.endS = v; form.endA = Math.min(form.endA, Q.count(v)); build(); }, 'plan-end-surah')),
          M.ui.field('الآية', (endA = M.ui.numInput(form.endA, { min: 1, max: Q.count(form.endS), id: 'plan-end-ayah', aria: 'آية الهدف' }, function (v) { form.endA = v; upd(); })), 'من ١ إلى ' + n(Q.count(form.endS)), errs.endA)));
        if (errs.endS) ed.appendChild(h('small', { class: 'field-err', role: 'alert', 'data-testid': 'err-end' }, errs.endS));
        ed.appendChild(h('div', { class: 'row wrap', style: 'margin-bottom:12px' },
          h('button', { type: 'button', class: 'chip', 'data-testid': 'end-of-surah', onclick: function () { form.endA = Q.count(form.endS); build(); } }, 'إلى نهاية السورة'),
          h('button', { type: 'button', class: 'chip', 'data-testid': 'end-of-mushaf', onclick: function () { form.endS = 114; form.endA = 6; build(); } }, 'إلى آخر المصحف')));
        ed.appendChild(h('h3', { style: 'font-size:1rem;margin:8px 0' }, 'مقدار الحفظ اليومي'));
        ed.appendChild(M.ui.segmented(UNITS, form.unit, function (v) { form.unit = v; if (v === 'page' && !(form.value >= 1)) form.value = 1; if (v === 'ayat' || v === 'custom') form.value = Math.max(1, Math.round(form.value)); build(); }, 'plan-unit'));
        if (form.unit === 'half' || form.unit === 'quarter') ed.appendChild(h('p', { class: 'field-hint muted', style: 'margin-top:8px' }, form.unit === 'half' ? 'نصف صفحة ≈ ٥ آيات' : 'ربع صفحة ≈ ٣ آيات'));
        else ed.appendChild(h('div', { style: 'margin-top:10px' }, M.ui.field(form.unit === 'page' ? 'عدد الصفحات' : 'عدد الآيات', M.ui.stepper(form.value, { min: 1, max: 100, id: 'plan-value', aria: 'المقدار' }, function (v) { form.value = v; upd(); }), form.unit === 'page' ? 'الصفحة ≈ ١٠ آيات (تقريب)' : null, errs.value)));
        ed.appendChild(h('h3', { style: 'font-size:1rem;margin:12px 0 4px' }, 'أيام الأسبوع'));
        ed.appendChild(h('p', { class: 'field-hint muted', style: 'margin:0 0 8px' }, 'اضغط اليوم للتبديل: حفظ ← راحة ← مراجعة اختيارية'));
        var days = h('div', { class: 'days', 'data-testid': 'plan-days' });
        [6, 0, 1, 2, 3, 4, 5].forEach(function (d) {
          days.appendChild(h('button', { type: 'button', class: 'day-btn', 'data-d': d, 'data-t': form.days[d], 'aria-label': D.DAYS[d] + ': ' + DAYT[form.days[d]], onclick: function (e) { form.days[d] = NEXT[form.days[d]]; var b = e.currentTarget; b.dataset.t = form.days[d]; b.lastChild.textContent = DAYT[form.days[d]]; b.setAttribute('aria-label', D.DAYS[d] + ': ' + DAYT[form.days[d]]); upd(); } }, D.DAYS_SHORT[d], h('i'), h('span', { style: 'font-weight:500' }, DAYT[form.days[d]])));
        });
        ed.appendChild(days);
        if (errs.days) ed.appendChild(h('small', { class: 'field-err', role: 'alert' }, errs.days));
        ed.appendChild(h('div', { style: 'margin-top:14px' }, summary));
        ed.appendChild(h('div', { class: 'btn-row' },
          M.ui.btn(isNew ? 'بدء الخطة' : 'حفظ التعديلات', { icon: 'check', id: 'plan-save', onclick: save }),
          !isNew || plan ? M.ui.btn('إلغاء', { kind: 'ghost', onclick: function () { mode = null; done(); app.render(true); } }) : null));
        upd();
      }
      function upd() { var v = PL.validate(form); errs = v.errors; updSummary(); var sv = ed.querySelector('[data-testid=plan-save]'); if (sv) sv.disabled = false; }
      function save() {
        var v = PL.validate(form);
        if (!v.ok) { errs = v.errors; build(); var first = ed.querySelector('.field-err'); if (first) first.scrollIntoView({ block: 'center' }); M.ui.toast('راجع الحقول المحددة', 'error'); return; }
        var r = isNew ? PL.create(st, form, today) : PL.update(st, plan.id, form, today);
        if (!r.ok) { errs = r.errors; build(); return; }
        st.settings.onboarded = true; mode = null; done(); app.commit();
        M.ui.toast(isNew ? 'بدأت الخطة، بالتوفيق!' : 'حُفظت الخطة وأُعيد حساب ورد اليوم فورًا');
        if (welcome || isNew) app.go('home');
      }
      build(); root.appendChild(ed);

      /* سجل الخطط السابقة */
      var old = st.plans.filter(function (p) { return p.id !== st.activePlanId; });
      if (old.length) root.appendChild(h('section', { class: 'card' }, h('h2', null, icon('list'), 'خطط سابقة'), old.slice().reverse().map(function (p) {
        return h('div', { class: 'mini-item' }, h('span', { class: 'grow' }, h('b', null, p.name), h('div', { class: 'muted', style: 'font-size:.8rem' }, Q.name(p.startS) + ' ' + n(p.startA) + ' ← ' + Q.name(p.endS) + ' ' + n(p.endA))), h('small', null, D.medium(p.startDate)));
      })));
      return root;
    }
  };
  /* عند مغادرة الصفحة يُعاد وضع التعديل الافتراضي */
  window.addEventListener('hashchange', function () { if (location.hash !== '#/plan') mode = null; });
})(globalThis.M = globalThis.M || {});
