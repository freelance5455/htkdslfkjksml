(function (M) {
  'use strict';
  var h = M.ui.h, icon = M.ui.icon;
  var ITEMS = [['plan', 'خطة الحفظ', 'plan', 'ابدأ من أي موضع وعدّل متى شئت'], ['progress', 'متابعة التقدم', 'chart', 'إحصائيات من بياناتك الفعلية'], ['garden', 'رحلة النمو', 'plant', 'بذرة ← برعم ← نبتة ← شجرة ← حديقة'], ['themes', 'معرض الثيمات', 'palette', '١٩ ثيمًا مختلفًا مع معاينة'], ['settings', 'الإعدادات والبيانات', 'gear', 'المظهر، التذكيرات، النسخ الاحتياطي']];
  M.views.more = {
    title: 'المزيد',
    render: function (ctx) {
      return h('section', { class: 'card' }, ITEMS.map(function (i) { return h('a', { class: 'list-row link', href: '#/' + i[0], 'data-testid': 'more-' + i[0] }, icon(i[2], 26), h('div', { class: 'grow' }, h('b', null, i[1]), h('div', { class: 'muted', style: 'font-size:.82rem' }, i[3])), icon('next')); }));
    }
  };
})(globalThis.M = globalThis.M || {});
