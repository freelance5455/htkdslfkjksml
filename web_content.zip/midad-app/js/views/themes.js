/* معرض الثيمات: معاينة كاملة للتطبيق قبل التطبيق، مفضلة، تصنيفات */
(function (M) {
  'use strict';
  var h = M.ui.h, icon = M.ui.icon, n = M.ui.n, T = M.themes;
  var cat = 'all';
  function previewCard(theme, st) {
    var mode = T.resolveMode(theme, st.settings.mode, window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
    var el = h('div', { class: 'tprev', 'data-testid': 'thumb-' + theme.id }, h('div', { class: 'tp-deco' }), h('div', { html: M.art.hero(theme.motif) }).firstChild,
      h('div', { class: 'tp-pcs' }, h('i'), h('i'), h('i'), h('i')),
      h('div', { class: 'tp-card' }, h('span', { class: 'tp-t' }, 'ورد اليوم'), h('div', { class: 'tp-bar' }, h('i')), h('span', { class: 'tp-btn' }, 'أتممت الورد')));
    T.applyTo(el, theme.id, mode, Object.assign({}, st.settings, { colors: {}, fontStyle: 'theme', radius: -1 }));
    return el;
  }
  M.views.themes = {
    title: 'معرض الثيمات',
    render: function (ctx) {
      var st = ctx.state, app = ctx.app, root = h('div'), fav = st.settings.favorites, active = st.settings.theme;
      root.appendChild(h('p', { class: 'muted' }, 'اختر عالمًا بصريًا كاملًا. «معاينة» تُطبّق الثيم مؤقتًا على كل التطبيق لتتنقل فيه قبل التثبيت.'));
      root.appendChild(h('div', { class: 'chips', role: 'tablist' }, T.CATS.map(function (c) { return h('button', { class: 'chip', role: 'tab', 'aria-pressed': String(cat === c[0]), 'data-testid': 'cat-' + c[0], onclick: function () { cat = c[0]; app.render(true); } }, c[1] + (c[0] === 'fav' ? ' (' + n(fav.length) + ')' : '')); })));
      var list = T.LIST.filter(function (t) { return cat === 'all' || (cat === 'fav' ? fav.indexOf(t.id) >= 0 : t.cats.indexOf(cat) >= 0); });
      if (!list.length) root.appendChild(M.ui.empty('لا ثيمات هنا', cat === 'fav' ? 'اضغط القلب على أي ثيم لإضافته إلى المفضلة.' : ''));
      var grid = h('div', { class: 'theme-grid', 'data-testid': 'theme-grid' });
      list.forEach(function (t) {
        var isFav = fav.indexOf(t.id) >= 0, isActive = t.id === active;
        grid.appendChild(h('article', { class: 'tcard' + (isActive ? ' active' : ''), 'data-theme-id': t.id, 'data-testid': 'theme-card' },
          isActive ? h('span', { class: 'tag good badge-act', 'data-testid': 'active-badge' }, icon('check', 14), 'الحالي') : null,
          h('button', { class: 'icon-btn fav' + (isFav ? ' on' : ''), 'aria-pressed': String(isFav), 'aria-label': (isFav ? 'إزالة ' : 'إضافة ') + t.name + ' من المفضلة', 'data-testid': 'fav-' + t.id, onclick: function () { var i = fav.indexOf(t.id); if (i >= 0) fav.splice(i, 1); else fav.push(t.id); app.commit(); } }, icon('heart')),
          previewCard(t, st),
          h('div', { class: 'tinfo' }, h('b', null, t.name), h('p', null, t.desc),
            h('div', { class: 'btn-row' },
              M.ui.btn('معاينة', { kind: 'ghost', id: 'preview-' + t.id, onclick: function () { app.preview(t.id); app.go('home'); } }),
              M.ui.btn(isActive ? 'مُطبَّق' : 'تطبيق', { id: 'apply-' + t.id, disabled: isActive, onclick: function () { st.settings.theme = t.id; app.commit(); M.ui.toast('تم تطبيق: ' + t.name); } })))));
      });
      root.appendChild(grid);
      root.appendChild(h('div', { style: 'margin-top:14px' }, M.ui.btn('تخصيص الألوان والخطوط والشكل', { kind: 'soft', icon: 'gear', id: 'to-settings', onclick: function () { app.go('settings'); } })));
      return root;
    }
  };
})(globalThis.M = globalThis.M || {});
