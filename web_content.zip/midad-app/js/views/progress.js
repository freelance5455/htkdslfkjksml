/* متابعة التقدم: كل الأرقام من بيانات المستخدم */
(function (M) {
  'use strict';
  var h = M.ui.h, icon = M.ui.icon, n = M.ui.n, Q = M.quran, D = M.dates, P = M.progress;
  var range = 'week';
  function bars(items, unit) {
    var max = Math.max.apply(null, items.map(function (i) { return i.v; }).concat([1]));
    return h('div', { class: 'bars', role: 'img', 'aria-label': 'رسم بياني للآيات المحفوظة' }, items.map(function (i) { return h('div', { class: 'b' }, h('em', null, i.v ? n(i.v) : ''), h('i', { class: i.v ? '' : 'zero', style: 'height:' + Math.max(3, i.v / max * 84) + '%' }), h('span', null, i.l)); }));
  }
  function actText(a) {
    if (a.type === 'mem') return 'حفظ ' + Q.segsText(a.segments) + (a.ayahs ? ' (+' + n(a.ayahs) + ' آية)' : '');
    if (a.type === 'rev') return 'مراجعة ' + Q.segText({ s: a.s, from: a.from, to: a.to }) + ' — ' + M.review.LABELS[a.rating];
    if (a.type === 'manual') return 'تعديل يدوي: ' + Q.name(a.s) + ' (' + (a.ayahs > 0 ? '+' : '') + n(a.ayahs) + ')';
    return 'مراجعة اختيارية';
  }
  M.views.progress = {
    title: 'متابعة التقدم',
    render: function (ctx) {
      var st = ctx.state, today = ctx.today, root = h('div'), t = P.totals(st);
      root.appendChild(h('section', { class: 'card' }, h('div', { class: 'row' }, M.ui.ring(t.pct, 96, M.ui.pct(t.pct), 'نسبة الحفظ'), h('div', { class: 'grow' }, h('div', { class: 'counter-big', 'data-testid': 'stat-ayat' }, n(t.memorized)), h('small', null, 'آية محفوظة من ' + n(Q.TOTAL_AYAT)))),
        h('div', { class: 'stackbar', style: 'margin-top:12px', role: 'img', 'aria-label': 'توزيع حالات السور' }, [['done', 'var(--pc-done)'], ['progress', 'var(--pc-prog)'], ['review', 'var(--pc-rev)']].map(function (x) { return h('i', { style: 'width:' + t[x[0]] / 114 * 100 + '%;background:' + x[1] }); }))));
      root.appendChild(h('div', { class: 'grid3', style: 'margin-bottom:14px' },
        h('div', { class: 'stat' }, h('b', { 'data-testid': 'stat-done' }, n(t.done)), h('small', null, 'سور مكتملة')),
        h('div', { class: 'stat good' }, h('b', { 'data-testid': 'stat-progress' }, n(t.progress)), h('small', null, 'سور جارية')),
        h('div', { class: 'stat warn' }, h('b', { 'data-testid': 'stat-review' }, n(t.review)), h('small', null, 'تحتاج مراجعة'))));
      var sums = { day: P.daily(st, today, 7), week: P.weekly(st, today, st.settings.weekStart, 8), month: P.monthly(st, today, 6) };
      var items = range === 'day' ? sums.day.map(function (x) { return { l: D.DAYS_SHORT[D.dow(x.date)], v: x.ayahs }; }) : range === 'week' ? sums.week.map(function (x) { return { l: n(D.parse(x.from).getDate()) + '/' + n(D.parse(x.from).getMonth() + 1), v: x.ayahs }; }) : sums.month.map(function (x) { return { l: x.label, v: x.ayahs }; });
      var total = items.reduce(function (s, x) { return s + x.v; }, 0);
      root.appendChild(h('section', { class: 'card' }, h('h2', null, icon('chart'), 'آيات جديدة'), M.ui.segmented([{ v: 'day', l: 'آخر ٧ أيام' }, { v: 'week', l: 'أسبوعي' }, { v: 'month', l: 'شهري' }], range, function (v) { range = v; ctx.app.render(true); }, 'range'),
        h('div', { style: 'margin-top:10px' }, bars(items)), h('p', { class: 'muted', style: 'margin-top:8px', 'data-testid': 'range-total' }, 'المجموع: ' + n(total) + ' آية')));
      var rec = P.recent(st, 10);
      root.appendChild(h('section', { class: 'card' }, h('h2', null, icon('list'), 'أحدث النشاطات'), rec.length ? rec.map(function (a) { return h('div', { class: 'mini-item' }, h('span', { class: 'dot ' + (a.type === 'rev' ? 'warn' : a.type === 'mem' ? '' : 'none') }), h('span', { class: 'grow' }, actText(a)), h('small', null, D.rel(a.date, today))); }) : h('p', { class: 'muted' }, 'لا نشاطات بعد. ابدأ بورد اليوم.')));
      return root;
    }
  };
})(globalThis.M = globalThis.M || {});
