/* شاشة بدء حفظ اليوم: عرض الورد وعدّاد تكرار بسيط (لا صوت ولا تعرّف على التلاوة) */
(function (M) {
  'use strict';
  var h = M.ui.h, icon = M.ui.icon, n = M.ui.n, Q = M.quran, D = M.dates, PL = M.plan;
  var count = 0;
  M.views.session = {
    title: 'حفظ اليوم',
    render: function (ctx) {
      var st = ctx.state, today = ctx.today, app = ctx.app, pend = PL.pending(st, today), root = h('div');
      if (pend.status !== 'ready') {
        root.appendChild(M.ui.empty(pend.status === 'none' ? 'لا توجد خطة' : pend.status === 'paused' ? 'الخطة متوقفة' : 'أتممت الخطة', 'عدّل خطتك من صفحة الخطة.', M.ui.btn('فتح الخطة', { onclick: function () { app.go('plan'); } })));
        return root;
      }
      root.appendChild(h('section', { class: 'card' }, h('h2', null, icon('book'), pend.isToday ? 'ورد اليوم' : 'ورد ' + D.rel(pend.forDate, today)),
        pend.segments.map(function (g) { var len = g.to - g.from + 1; return h('div', { class: 'seg-card' }, h('div', { class: 'nm' }, 'سورة ' + Q.name(g.s)), h('div', null, 'من الآية ' + n(g.from) + ' إلى الآية ' + n(g.to) + ' (' + n(len) + ' آية)')); }),
        h('p', { class: 'muted' }, 'اقرأ الورد نظرًا من مصحفك، ثم كرّره حتى يثبت. العدّاد أدناه لمساعدتك على عدّ التكرار فقط.')));
      var num = h('span', { 'data-testid': 'rep-count' }, n(count));
      root.appendChild(h('section', { class: 'card counter' }, h('h2', null, icon('restart'), 'عدّاد التكرار'),
        h('button', { class: 'tap', 'data-testid': 'rep-tap', 'aria-label': 'تكرار', onclick: function () { count++; num.textContent = n(count); if (navigator.vibrate) navigator.vibrate(10); } }, num),
        h('button', { class: 'btn btn-ghost btn-sm', onclick: function () { count = 0; num.textContent = n(0); } }, 'تصفير العدّاد')));
      root.appendChild(h('div', { class: 'btn-row' }, M.ui.btn('أتممت الورد', { icon: 'check', id: 'session-complete', onclick: function () { M.actions.completeMem(pend).then(function (ok) { if (ok) { count = 0; app.go('home'); } }); } }),
        M.ui.btn('رجوع', { kind: 'ghost', onclick: function () { app.go('home'); } })));
      return root;
    }
  };
})(globalThis.M = globalThis.M || {});
