/* نقطة الدخول: التوجيه، تطبيق الثيم، التنقل، التذكيرات، تسجيل Service Worker */
(function (M) {
  'use strict';
  var h = M.ui.h, icon = M.ui.icon, n = M.ui.n, D = M.dates;
  var TABS = [['home', 'الرئيسية', 'home'], ['review', 'المراجعة', 'review'], ['puzzle', 'البازل', 'puzzle'], ['calendar', 'التقويم', 'calendar'], ['more', 'المزيد', 'more']];
  var TITLES = { home: 'مِداد', session: 'حفظ اليوم', plan: 'خطة الحفظ', review: 'المراجعة', puzzle: 'بازل القرآن', progress: 'متابعة التقدم', calendar: 'التقويم', garden: 'رحلة النمو', themes: 'معرض الثيمات', settings: 'الإعدادات', more: 'المزيد' };
  var App = { views: M.views = M.views || {}, previewId: null, route: 'home', lastDay: D.today() };
  M.app = App;

  App.today = function () { return D.today(); };
  App.state = function () { return M.store.state; };
  App.go = function (r) { if (location.hash === '#/' + r) App.render(true); else location.hash = '#/' + r; };
  App.commit = function () { M.store.commit(); };
  function currentRoute() { var r = (location.hash || '').replace(/^#\//, '').split('?')[0]; return TITLES[r] ? r : 'home'; }

  /* ---------- الثيم ---------- */
  var mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  App.applyTheme = function () {
    var st = App.state().settings, id = App.previewId || st.theme, theme = M.themes.get(id);
    var mode = M.themes.resolveMode(theme, st.mode, mq && mq.matches);
    var r = M.themes.applyTo(document.documentElement, theme.id, mode, st);
    document.documentElement.setAttribute('data-theme', theme.id);
    document.body.setAttribute('data-theme', theme.id); document.body.setAttribute('data-mode', mode);
    document.body.setAttribute('data-nav', st.navStyle); document.body.setAttribute('data-icons', st.iconStyle);
    document.documentElement.setAttribute('data-icons', st.iconStyle);
    document.documentElement.style.setProperty('--fs', st.fontScale);
    var meta = document.querySelector('meta[name=theme-color]'); if (meta) meta.setAttribute('content', r.vars['--bg']);
    var deco = document.querySelector('.deco'); if (deco) deco.style.display = st.deco === false ? 'none' : '';
    return r;
  };
  if (mq && mq.addEventListener) mq.addEventListener('change', function () { App.applyTheme(); });
  App.preview = function (id) { App.previewId = id; App.applyTheme(); App.renderBanner(); };
  App.endPreview = function (apply) {
    var id = App.previewId; App.previewId = null;
    if (apply && id) { App.state().settings.theme = id; App.commit(); M.ui.toast('تم تطبيق الثيم: ' + M.themes.get(id).name); }
    else { App.applyTheme(); App.renderBanner(); }
  };
  App.renderBanner = function () {
    var b = document.getElementById('banner'); b.textContent = '';
    if (App.previewId) {
      var t = M.themes.get(App.previewId);
      b.appendChild(h('div', { class: 'preview-banner', role: 'status' }, h('span', null, 'معاينة الثيم: ' + t.name + ' — تنقّل في التطبيق لترى الشكل كاملًا'),
        h('button', { class: 'btn btn-sm btn-ghost', 'data-testid': 'preview-apply', style: 'background:var(--surface);color:var(--text)', onclick: function () { App.endPreview(true); } }, 'تطبيق'),
        h('button', { class: 'btn btn-sm btn-ghost', 'data-testid': 'preview-cancel', style: 'background:var(--surface);color:var(--text)', onclick: function () { App.endPreview(false); } }, 'إلغاء')));
    } else if (!M.store.storage.persistent()) {
      b.appendChild(h('div', { class: 'storage-warn' }, 'التخزين المحلي غير متاح في هذا المتصفح (ربما وضع التصفح الخاص)، لن تُحفظ بياناتك بعد الإغلاق. صدّر نسخة احتياطية من الإعدادات.'));
    } else if (M.store.info.recovered) {
      b.appendChild(h('div', { class: 'storage-warn' }, 'تعذّرت قراءة آخر حفظ فاستُعيدت نسخة احتياطية تلقائية من بداية الجلسة السابقة.'));
    } else if (M.store.info.corrupt) {
      b.appendChild(h('div', { class: 'storage-warn' }, 'وُجدت بيانات تالفة فبدأ التطبيق ببيانات جديدة (احتُفظ بنسخة من التالف في التخزين المحلي).'));
    }
  };

  /* ---------- العرض ---------- */
  function renderNav(route) {
    var nav = document.getElementById('nav'); nav.textContent = '';
    var due = M.review.today(App.state(), App.today()).total;
    var tabRoute = ['home', 'review', 'puzzle', 'calendar'].indexOf(route) >= 0 ? route : 'more';
    TABS.forEach(function (t) {
      var a = h('a', { href: '#/' + t[0], 'data-testid': 'nav-' + t[0], 'aria-current': t[0] === tabRoute ? 'page' : null, 'aria-label': t[1] }, icon(t[2]), h('span', null, t[1]));
      if (t[0] === 'review' && due > 0) a.appendChild(h('span', { class: 'badge', 'aria-label': n(due) + ' مراجعة مستحقة' }, due > 99 ? '99+' : n(due)));
      nav.appendChild(a);
    });
  }
  App.render = function (keepAnim) {
    var route = currentRoute(), changed = route !== App.route; App.route = route;
    var view = document.getElementById('view'), top = document.getElementById('topbar'), v = App.views[route];
    var scroll = window.scrollY;
    var out;
    try { out = v.render({ state: App.state(), today: App.today(), app: App }); }
    catch (e) { console.error(e); out = h('div', { class: 'card' }, h('h2', null, 'حدث خطأ غير متوقع'), h('p', null, 'تعذّر عرض هذه الصفحة. بياناتك سليمة.'), h('button', { class: 'btn', onclick: function () { App.go('home'); } }, 'العودة للرئيسية')); }
    view.textContent = ''; view.appendChild(out);
    view.className = changed && keepAnim !== true ? 'page-in' : '';
    top.textContent = '';
    var isTab = ['home', 'review', 'puzzle', 'calendar', 'more'].indexOf(route) >= 0;
    if (!isTab) top.appendChild(h('button', { class: 'icon-btn back', 'aria-label': 'رجوع', 'data-testid': 'back', onclick: function () { App.go(route === 'session' ? 'home' : 'more'); } }, icon('prev')));
    top.appendChild(h('h1', null, v.title ? (typeof v.title === 'function' ? v.title(App.state()) : v.title) : TITLES[route]));
    if (v.actions) v.actions(top, App);
    renderNav(route);
    if (changed) window.scrollTo(0, 0); else window.scrollTo(0, scroll);
    document.title = (TITLES[route] === 'مِداد' ? '' : TITLES[route] + ' — ') + 'مِداد';
  };

  var pending = false;
  M.store.on(function () { App.applyTheme(); if (pending) return; pending = true; setTimeout(function () { pending = false; if (!document.querySelector('[data-keep-render]')) App.render(true); }, 0); });
  window.addEventListener('hashchange', function () { if (M.ui.sheetOpen()) M.ui.closeAllSheets(); App.render(); });

  /* ---------- تنبيهات التذكير (أثناء فتح التطبيق) ---------- */
  App.checkReminder = function () {
    var s = App.state(), r = s.settings.reminders, today = App.today();
    if (!r.enabled || r.lastShown === today) return;
    var now = new Date(), cur = D.pad(now.getHours()) + ':' + D.pad(now.getMinutes());
    if (cur < r.time) return;
    var pend = M.plan.pending(s, today), msgs = [];
    if (r.mem && pend.status === 'ready' && pend.isToday && !M.plan.memEntriesOn(s, today).length) msgs.push('ورد الحفظ بانتظارك');
    var rv = M.review.today(s, today); if (r.rev && rv.total > 0) msgs.push(n(rv.total) + ' مراجعة مستحقة');
    if (!msgs.length) return;
    r.lastShown = today; M.store.save();
    var body = msgs.join(' • ');
    M.ui.toast('🔔 تذكير: ' + body);
    try {
      if ('Notification' in window && Notification.permission === 'granted') {
        if (navigator.serviceWorker && navigator.serviceWorker.ready) navigator.serviceWorker.ready.then(function (reg) { reg.showNotification('مِداد', { body: body, icon: 'icons/icon-192.png', lang: 'ar', dir: 'rtl' }); });
        else new Notification('مِداد', { body: body });
      }
    } catch (e) {}
  };

  /* ---------- الإقلاع ---------- */
  function boot() {
    M.store.load();
    App.applyTheme(); App.renderBanner();
    try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist(); } catch (e) {}
    if (!location.hash) history.replaceState(null, '', '#/home');
    App.render();
    document.addEventListener('visibilitychange', function () { if (!document.hidden) tick(); });
    setInterval(tick, 30000);
    function tick() { var t = App.today(); if (t !== App.lastDay) { App.lastDay = t; App.render(true); } App.checkReminder(); }
    setTimeout(App.checkReminder, 1500);
    if ('serviceWorker' in navigator && location.protocol.indexOf('http') === 0) {
      navigator.serviceWorker.register('sw.js').catch(function (e) { console.warn('SW', e); });
    }
    window.__midadReady = true;
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})(globalThis.M = globalThis.M || {});
