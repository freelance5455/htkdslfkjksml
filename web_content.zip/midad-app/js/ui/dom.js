/* مساعدات DOM: إنشاء العناصر، الأيقونات، النوافذ السفلية، التنبيهات */
(function (M) {
  'use strict';
  var Q = M.quran;
  function h(tag, props) {
    var el = document.createElement(tag);
    if (props) Object.keys(props).forEach(function (k) {
      var v = props[k]; if (v == null || v === false) return;
      if (k === 'class') el.className = v;
      else if (k === 'style') { if (typeof v === 'string') el.style.cssText = v; else Object.keys(v).forEach(function (s) { el.style.setProperty(s, v[s]); }); }
      else if (k === 'html') el.innerHTML = v;
      else if (k.slice(0, 2) === 'on' && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (k === 'value' || k === 'checked' || k === 'disabled' || k === 'selected' || k === 'hidden') el[k] = v;
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, v);
    });
    for (var i = 2; i < arguments.length; i++) add(el, arguments[i]);
    return el;
  }
  function add(el, c) {
    if (c == null || c === false) return;
    if (Array.isArray(c)) c.forEach(function (x) { add(el, x); });
    else if (c instanceof Node) el.appendChild(c);
    else el.appendChild(document.createTextNode(String(c)));
  }
  function icon(name, size) {
    var s = h('span', { class: 'ic', 'aria-hidden': 'true', html: '<svg viewBox="0 0 24 24" focusable="false">' + (M.icons[name] || '') + '</svg>' });
    if (size) { s.style.width = s.style.height = size + 'px'; }
    return s;
  }
  var n = Q.num;
  var UI = { h: h, icon: icon, n: n, $: function (s, r) { return (r || document).querySelector(s); }, $$: function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); } };

  /* ---- تنبيه عابر ---- */
  var toastTimer;
  UI.toast = function (msg, kind, action) {
    var host = document.getElementById('toasts'); if (!host) return;
    host.textContent = '';
    var t = h('div', { class: 'toast ' + (kind || ''), role: 'status' }, h('span', null, msg));
    if (action) t.appendChild(h('button', { class: 'toast-act', onclick: function () { clearTimeout(toastTimer); host.textContent = ''; action.fn(); } }, action.label));
    host.appendChild(t); clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { if (t.parentNode) t.remove(); }, action ? 7000 : 3200);
  };

  /* ---- نافذة سفلية (Bottom sheet) مع دعم زر الرجوع ---- */
  var stack = [], suppress = 0;
  window.addEventListener('popstate', function () {
    if (suppress > 0) { suppress--; return; }
    if (stack.length) { var top = stack[stack.length - 1]; top.fromPop = true; top.close(); }
  });
  UI.sheet = function (o) {
    var prevFocus = document.activeElement, closed = false;
    var body = h('div', { class: 'sheet-body' });
    var head = h('div', { class: 'sheet-head' }, h('h2', { class: 'sheet-title' }, o.title || ''),
      h('button', { class: 'icon-btn', 'aria-label': 'إغلاق', onclick: function () { api.close(); } }, icon('close')));
    var sheet = h('div', { class: 'sheet' + (o.dialog ? ' dialog' : ''), role: 'dialog', 'aria-modal': 'true', 'aria-label': o.title || 'نافذة', tabindex: '-1' }, o.dialog ? null : h('div', { class: 'sheet-grab' }), head, body);
    var overlay = h('div', { class: 'overlay' }, sheet);
    overlay.addEventListener('mousedown', function (e) { if (e.target === overlay) api.close(); });
    var api = {
      el: sheet, body: body, overlay: overlay,
      set: function (c) { body.textContent = ''; add(body, typeof c === 'function' ? c(api) : c); },
      setTitle: function (t) { head.querySelector('.sheet-title').textContent = t; },
      close: function () {
        if (closed) return; closed = true;
        var i = stack.indexOf(api); if (i >= 0) stack.splice(i, 1);
        overlay.classList.add('out'); setTimeout(function () { overlay.remove(); }, 160);
        if (!stack.length) document.body.classList.remove('lock');
        if (!api.fromPop) { suppress++; history.back(); }
        if (o.onClose) o.onClose();
        try { if (prevFocus && prevFocus.focus && document.contains(prevFocus)) prevFocus.focus(); } catch (e) {}
      }
    };
    api.set(o.content);
    document.getElementById('overlays').appendChild(overlay);
    document.body.classList.add('lock'); stack.push(api);
    history.pushState({ midadSheet: stack.length }, '');
    setTimeout(function () { var f = o.focus ? sheet.querySelector(o.focus) : null; (f || sheet).focus(); }, 30);
    return api;
  };
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && stack.length) { e.preventDefault(); stack[stack.length - 1].close(); } });
  UI.sheetOpen = function () { return stack.length > 0; };
  UI.closeAllSheets = function () { stack.slice().reverse().forEach(function (s) { s.fromPop = true; s.close(); }); };

  /** تأكيد: يعيد Promise<boolean> */
  UI.confirm = function (o) {
    return new Promise(function (res) {
      var done = false, sh;
      function fin(v) { if (done) return; done = true; res(v); sh.close(); }
      sh = UI.sheet({
        title: o.title, dialog: true, onClose: function () { if (!done) { done = true; res(false); } },
        content: h('div', { class: 'confirm' },
          o.text ? h('p', { class: 'confirm-text' }, o.text) : null, o.extra || null,
          h('div', { class: 'btn-row' },
            h('button', { class: 'btn ' + (o.danger ? 'btn-danger' : 'btn-primary'), 'data-testid': 'confirm-ok', onclick: function () { fin(true); } }, o.ok || 'تأكيد'),
            h('button', { class: 'btn btn-ghost', 'data-testid': 'confirm-cancel', onclick: function () { fin(false); } }, o.cancel || 'إلغاء')))
      });
    });
  };

  /* ---- مكونات صغيرة ---- */
  UI.card = function (cls) { var a = Array.prototype.slice.call(arguments, 1); return h.apply(null, ['section', { class: 'card ' + (cls || '') }].concat(a)); };
  UI.btn = function (label, o) {
    o = o || {}; return h('button', { class: 'btn ' + (o.kind ? 'btn-' + o.kind : 'btn-primary') + (o.cls ? ' ' + o.cls : ''), type: 'button', onclick: o.onclick, 'data-testid': o.id, disabled: o.disabled, 'aria-label': o.aria }, o.icon ? icon(o.icon) : null, h('span', null, label));
  };
  UI.empty = function (title, text, action) { return h('div', { class: 'empty' }, h('div', { class: 'empty-art', html: M.art.plant(0) }), h('h3', null, title), text ? h('p', null, text) : null, action || null); };
  UI.ring = function (pct, size, label, sub) {
    var r = 42, c = 2 * Math.PI * r, p = Math.max(0, Math.min(100, pct)), off = c * (1 - p / 100);
    return h('div', { class: 'ring', style: { width: size + 'px', height: size + 'px' } },
      h('svg', { viewBox: '0 0 100 100', html: '<circle cx="50" cy="50" r="' + r + '" class="ring-bg"/><circle cx="50" cy="50" r="' + r + '" class="ring-fg" stroke-dasharray="' + c.toFixed(1) + '" stroke-dashoffset="' + off.toFixed(1) + '" transform="rotate(-90 50 50)"/>' }),
      h('div', { class: 'ring-label' }, h('b', null, label), sub ? h('small', null, sub) : null));
  };
  UI.segmented = function (opts, value, onchange, id) {
    var wrap = h('div', { class: 'seg', role: 'radiogroup', 'data-testid': id });
    opts.forEach(function (o) { wrap.appendChild(h('button', { type: 'button', role: 'radio', 'aria-checked': String(o.v === value), class: o.v === value ? 'on' : '', 'data-v': o.v, onclick: function () { onchange(o.v); } }, o.l)); });
    return wrap;
  };
  UI.toggle = function (checked, onchange, label, id) {
    var inp = h('input', { type: 'checkbox', checked: !!checked, role: 'switch', 'data-testid': id, onchange: function () { onchange(inp.checked); } });
    return h('label', { class: 'switch' }, h('span', { class: 'switch-label' }, label), inp, h('span', { class: 'switch-track' }, h('span', { class: 'switch-knob' })));
  };
  UI.field = function (label, control, hint, err) {
    return h('div', { class: 'field' + (err ? ' has-err' : '') }, h('label', { class: 'field-label' }, label, control), hint ? h('small', { class: 'field-hint' }, hint) : null, err ? h('small', { class: 'field-err', role: 'alert' }, err) : null);
  };
  UI.surahSelect = function (value, onchange, id) {
    var sel = h('select', { class: 'input', 'data-testid': id, onchange: function () { onchange(+sel.value); } });
    Q.SURAHS.slice(1).forEach(function (s) { sel.appendChild(h('option', { value: s.n, selected: s.n === value }, n(s.n) + '. ' + s.name)); });
    sel.value = String(value); return sel;
  };
  UI.numInput = function (value, o, onchange) {
    var inp = h('input', { class: 'input num', type: 'number', inputmode: 'numeric', min: o.min, max: o.max, step: o.step || 1, value: value, 'data-testid': o.id, 'aria-label': o.aria,
      oninput: function () { onchange(inp.value === '' ? NaN : +inp.value, inp); } });
    return inp;
  };
  UI.stepper = function (value, o, onchange) {
    var inp = h('input', { class: 'input num', type: 'number', inputmode: 'numeric', min: o.min, max: o.max, value: value, 'data-testid': o.id, 'aria-label': o.aria, oninput: function () { onchange(inp.value === '' ? NaN : +inp.value); } });
    function bump(d) { var v = (+inp.value || 0) + d; v = Math.max(o.min, Math.min(o.max, v)); inp.value = v; onchange(v); }
    return h('div', { class: 'stepper' }, h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'زيادة', onclick: function () { bump(1); } }, icon('plus')), inp, h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'إنقاص', onclick: function () { bump(-1); } }, icon('minus')));
  };
  UI.download = function (name, text, mime) {
    var blob = new Blob([text], { type: mime || 'application/json' }), url = URL.createObjectURL(blob);
    var a = h('a', { href: url, download: name, style: 'display:none' }); document.body.appendChild(a); a.click();
    setTimeout(function () { a.remove(); URL.revokeObjectURL(url); }, 1500);
  };
  M.ui = UI; M.views = M.views || {};
})(globalThis.M = globalThis.M || {});
