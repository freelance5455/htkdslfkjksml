/* أدوات الألوان والتباين (WCAG) */
(function (M) {
  'use strict';
  function hex2rgb(h) { h = h.replace('#', ''); if (h.length === 3) h = h.replace(/./g, '$&$&'); return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)]; }
  function rgb2hex(r) { return '#' + r.map(function (v) { v = Math.max(0, Math.min(255, Math.round(v))); return (v < 16 ? '0' : '') + v.toString(16); }).join(''); }
  function rgb2hsl(r) {
    var R = r[0] / 255, G = r[1] / 255, B = r[2] / 255, mx = Math.max(R, G, B), mn = Math.min(R, G, B), h = 0, s = 0, l = (mx + mn) / 2, d = mx - mn;
    if (d) { s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn); h = mx === R ? (G - B) / d + (G < B ? 6 : 0) : mx === G ? (B - R) / d + 2 : (R - G) / d + 4; h *= 60; }
    return [h, s, l];
  }
  function hsl2hex(h, s, l) {
    h = ((h % 360) + 360) % 360; s = Math.max(0, Math.min(1, s)); l = Math.max(0, Math.min(1, l));
    var c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = l - c / 2, r, g, b;
    if (h < 60) { r = c; g = x; b = 0; } else if (h < 120) { r = x; g = c; b = 0; } else if (h < 180) { r = 0; g = c; b = x; }
    else if (h < 240) { r = 0; g = x; b = c; } else if (h < 300) { r = x; g = 0; b = c; } else { r = c; g = 0; b = x; }
    return rgb2hex([(r + m) * 255, (g + m) * 255, (b + m) * 255]);
  }
  function lum(h) { var c = hex2rgb(h).map(function (v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; }
  function contrast(a, b) { var x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); }
  function mix(a, b, t) { var x = hex2rgb(a), y = hex2rgb(b); return rgb2hex([0, 1, 2].map(function (i) { return x[i] + (y[i] - x[i]) * t; })); }
  function onColor(bg) { if (contrast(bg, '#ffffff') >= 4.6) return '#ffffff'; if (contrast(bg, '#111111') >= 4.6) return '#111111'; return '#000000'; }
  /** يعدّل إضاءة fg حتى يبلغ التباين المطلوب مع bg */
  function ensure(fg, bg, min) {
    if (contrast(fg, bg) >= min) return fg;
    var hsl = rgb2hsl(hex2rgb(fg)), dir = lum(bg) > 0.4 ? -1 : 1, l = hsl[2];
    for (var i = 0; i < 60; i++) { l += dir * 0.02; var c = hsl2hex(hsl[0], hsl[1], l); if (contrast(c, bg) >= min) return c; if (l <= 0 || l >= 1) break; }
    return dir < 0 ? '#000000' : '#ffffff';
  }
  function rgba(h, a) { var c = hex2rgb(h); return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')'; }
  function hsl(h) { return rgb2hsl(hex2rgb(h)); }
  M.color = { hex2rgb: hex2rgb, rgb2hex: rgb2hex, hsl: hsl, hsl2hex: hsl2hex, lum: lum, contrast: contrast, mix: mix, onColor: onColor, ensure: ensure, rgba: rgba };
  if (typeof module !== 'undefined') module.exports = M.color;
})(globalThis.M = globalThis.M || {});
