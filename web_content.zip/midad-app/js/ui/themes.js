/* بيانات الثيمات (19) ومحرّك حساب المتغيرات: تبديل فوري دون إعادة تحميل */
(function (M) {
  'use strict';
  var C = M.color;
  var KEYS = ['bg', 'surface', 'text', 'muted', 'line', 'primary', 'secondary', 'accent', 'good', 'warn'];
  function pal(a) { var o = {}; KEYS.forEach(function (k, i) { o[k] = a[i]; }); return o; }

  var FONTS = {
    naskh: "'Amiri','Noto Naskh Arabic','Scheherazade New','Midad Naskh','Traditional Arabic',serif",
    sans: "'Cairo','Tajawal','Noto Sans Arabic','Almarai','Midad Sans',system-ui,sans-serif",
    kufi: "'Noto Kufi Arabic','Reem Kufi','Cairo','Midad Sans',system-ui,sans-serif",
    rounded: "'Baloo Bhaijaan 2','Mada','Almarai','Noto Sans Arabic','Midad Sans',system-ui,sans-serif",
    hand: "'Aref Ruqaa','Lateef','Noto Naskh Arabic','Midad Naskh',serif"
  };
  var FONT_NAMES = { theme: 'حسب الثيم', naskh: 'نسخ', sans: 'عصري', kufi: 'كوفي', rounded: 'مدوّر' };

  var CATS = [['all', 'الكل'], ['fav', 'المفضلة'], ['nature', 'طبيعة'], ['calm', 'هادئ وبسيط'], ['islamic', 'إسلامي'], ['art', 'فني'], ['night', 'ليلي'], ['fun', 'مرح'], ['seasonal', 'موسمي']];

  /* الحقول: id, name, desc, cats, motif, prefer (وضع مفضّل في التلقائي), light/dark (لوحات), fonts, ui (تجاوزات الشكل) */
  var THEMES = [
    { id: 'garden', name: 'حديقة هادئة', desc: 'أخضر نباتي مريح وأوراق ناعمة', cats: ['nature', 'calm'], motif: 'leaf', fonts: ['naskh', 'sans'],
      light: pal(['#F3F7EC', '#FFFFFF', '#1F3A28', '#566B5A', '#D5E2CB', '#3B8454', '#8DB255', '#E0A43A', '#3F8F57', '#C97A1E']),
      ui: { rCard: 22, rBtn: 14 } },
    { id: 'blossom', name: 'زهر وردي', desc: 'بتلات وردية رقيقة وطابع أنثوي ناعم', cats: ['nature', 'fun'], motif: 'blossom', fonts: ['naskh', 'rounded'],
      light: pal(['#FFF4F7', '#FFFFFF', '#4A2634', '#7A5360', '#F3D3DC', '#C94572', '#F29BB4', '#8E6BBF', '#5F9E80', '#D98A3B']),
      ui: { rCard: 26, rBtn: 999, btnShadow: '0 6px 14px {primaryA}' } },
    { id: 'zen', name: 'مينيمال ياباني', desc: 'هدوء وفراغ وخطوط رفيعة وشمس حمراء', cats: ['calm', 'art'], motif: 'zen', fonts: ['sans', 'sans'],
      light: pal(['#F5F2EC', '#FBF9F5', '#201E1B', '#625C52', '#D8D1C4', '#B02E26', '#3A3A3A', '#B8923F', '#4F7455', '#B16A1F']),
      ui: { rCard: 2, rBtn: 2, cardBorder: '0', cardShadow: 'none', btnWeight: 500, titleWeight: 500, titleSpacing: '.04em' } },
    { id: 'geometric', name: 'هندسة إسلامية', desc: 'نجوم ثمانية وأطر ذهبية على زمرد عميق', cats: ['islamic', 'art'], motif: 'geometric', fonts: ['naskh', 'sans'],
      light: pal(['#F4EFE2', '#FFFDF6', '#103836', '#4F6B68', '#D9CDA6', '#0C6561', '#A8832A', '#B8902F', '#2C855A', '#C0722A']),
      dark: pal(['#0B2A2A', '#103635', '#F2ECD9', '#B9C7BE', '#1F4A47', '#3CC1B8', '#D6B25B', '#D6B25B', '#5CC48E', '#E39A52']),
      ui: { rCard: 8, rBtn: 8, cardBorder: '1px solid {accent}' } },
    { id: 'watercolor', name: 'ألوان مائية', desc: 'بقع لونية شفافة تتداخل بنعومة', cats: ['art', 'calm'], motif: 'watercolor', fonts: ['naskh', 'sans'],
      light: pal(['#F0F5FB', '#FFFFFF', '#26354F', '#586A87', '#D0DCEC', '#3D6CC9', '#EE9F98', '#EFBE60', '#4FA48E', '#DA7F57']),
      ui: { rCard: 28, rBtn: 20, card: 'rgba(255,255,255,.72)', cardBorder: '1px solid rgba(255,255,255,.9)', cardShadow: '0 10px 30px {shadow}',
        pageBg: 'radial-gradient(60% 40% at 15% 8%, {primaryA2} 0, transparent 70%), radial-gradient(55% 40% at 90% 20%, {secondaryA2} 0, transparent 70%), radial-gradient(60% 40% at 60% 95%, {accentA2} 0, transparent 70%), {bg}' } },
    { id: 'modern', name: 'نقاء عصري', desc: 'حدود واضحة وفراغات مريحة وأزرق نظيف', cats: ['calm'], motif: 'modern', fonts: ['sans', 'sans'],
      light: pal(['#F6F7FA', '#FFFFFF', '#12151C', '#566070', '#E1E5EC', '#2753E8', '#0F8F80', '#F2780F', '#0F8F80', '#C77A00']),
      ui: { rCard: 14, rBtn: 10, cardShadow: '0 1px 2px {shadow}, 0 8px 24px {shadow}' } },
    { id: 'vintage', name: 'نباتات عتيقة', desc: 'ورق قديم ورسومات نباتية بحبر بني', cats: ['art', 'nature'], motif: 'vintage', fonts: ['naskh', 'naskh'],
      light: pal(['#EEE4CE', '#F7F0DD', '#3A2E1D', '#695840', '#CDBA93', '#566527', '#8A5628', '#9C3B2B', '#58742F', '#A86F12']),
      ui: { rCard: 6, rBtn: 4, cardBorder: '1px solid {line}', cardShadow: 'inset 0 0 0 4px {surface}, inset 0 0 0 5px {line}', titleWeight: 700 } },
    { id: 'pastel', name: 'باستيل ناعم', desc: 'ألوان حلوى لطيفة وأزرار منتفخة', cats: ['fun', 'calm'], motif: 'pastel', fonts: ['rounded', 'rounded'],
      light: pal(['#F4F0FF', '#FFFFFF', '#38325A', '#6A648C', '#DED6F6', '#7655D3', '#6FCBB1', '#FFB0A1', '#4FB391', '#E69A4C']),
      ui: { rCard: 28, rBtn: 22, cardBorder: '3px solid {line}', cardShadow: '0 6px 0 {line}', btnShadow: '0 4px 0 {primaryD}' } },
    { id: 'notebook', name: 'دفتر ورقي', desc: 'سطور دفتر وهامش أحمر وحبر أزرق', cats: ['art', 'calm'], motif: 'notebook', fonts: ['naskh', 'naskh'],
      light: pal(['#FBF7EC', '#FFFEF7', '#2A2938', '#646073', '#D8D1BA', '#2A56A3', '#BF3A2D', '#E4B01E', '#3C8858', '#CF7B22']),
      ui: { rCard: 3, rBtn: 3, cardBorder: '1px solid {line}', cardShadow: '2px 3px 0 {line}',
        pageBg: 'repeating-linear-gradient(to bottom, transparent 0 31px, {lineA} 31px 32px), {bg}' } },
    { id: 'night', name: 'سماء الليل', desc: 'نجوم وهلال ذهبي على ليل نيلي', cats: ['night', 'art'], motif: 'night', prefer: 'dark', fonts: ['naskh', 'sans'],
      dark: pal(['#0B1230', '#141C44', '#EEF1FF', '#AAB4DD', '#27316A', '#F2C14E', '#8C9BFF', '#FF9AC1', '#5FD6A5', '#FFB454']),
      light: pal(['#EEF0FB', '#FFFFFF', '#161B3D', '#555C84', '#CDD2EE', '#8A5A00', '#4A57C9', '#C23C7A', '#1F7F5E', '#A55F00']),
      ui: { rCard: 20, rBtn: 14, cardBorder: '1px solid {line}', cardShadow: '0 10px 30px rgba(0,0,0,.25), 0 0 0 1px {primaryA}',
        pageBg: 'radial-gradient(80% 50% at 80% 0%, {secondaryA2} 0, transparent 70%), linear-gradient(180deg, {bg}, {bg2})' } },
    { id: 'doodle', name: 'رسم يد لطيف', desc: 'خطوط مرحة بخط اليد وظلال كرتونية', cats: ['fun', 'art'], motif: 'doodle', fonts: ['hand', 'rounded'],
      light: pal(['#FFF8E1', '#FFFFFF', '#2B2824', '#665D52', '#2B2824', '#E8553A', '#2FA695', '#FFD02B', '#2FA695', '#E88A00']),
      ui: { rCard: 18, rBtn: 16, cardBorder: '2.5px solid {text}', cardShadow: '4px 4px 0 {text}', btnBorder: '2.5px solid {text}', btnShadow: '3px 3px 0 {text}', btnWeight: 800 } },
    { id: 'editorial', name: 'تحرير صحفي', desc: 'عناوين ثقيلة وخطوط سوداء وأحمر جريء', cats: ['art', 'calm'], motif: 'editorial', fonts: ['kufi', 'sans'],
      light: pal(['#FAFAF6', '#FFFFFF', '#0B0B0B', '#4F4F4F', '#0B0B0B', '#CF1F17', '#0B0B0B', '#F2C200', '#17784A', '#BF5400']),
      ui: { rCard: 0, rBtn: 0, cardBorder: '1px solid {text}', cardShadow: 'none', btnWeight: 900, titleWeight: 900, titleSpacing: '-.01em' } },
    { id: 'ramadan', name: 'رمضان', desc: 'فوانيس وهلال وذهب على بنفسجي ليلي', cats: ['seasonal', 'islamic', 'night'], motif: 'ramadan', prefer: 'dark', fonts: ['naskh', 'sans'],
      dark: pal(['#1A1033', '#261848', '#F7EFFF', '#BFAEDD', '#3C2B68', '#F0B94B', '#9373E8', '#F27AA8', '#66D1A4', '#FFB05A']),
      light: pal(['#F6F0FF', '#FFFFFF', '#2A1650', '#65508F', '#DCCFF3', '#7A4F00', '#6A47C8', '#C23C77', '#1F7F5E', '#A25D00']),
      ui: { rCard: 22, rBtn: 14, cardBorder: '1px solid {primaryA}', cardShadow: '0 10px 28px rgba(0,0,0,.3)',
        pageBg: 'radial-gradient(70% 40% at 15% 0%, {primaryA2} 0, transparent 70%), linear-gradient(180deg, {bg}, {bg2})' } },
    { id: 'fitr', name: 'عيد الفطر', desc: 'زينة وقصاصات ملونة وفرحة العيد', cats: ['seasonal', 'islamic', 'fun'], motif: 'fitr', fonts: ['rounded', 'rounded'],
      light: pal(['#FFF6E8', '#FFFFFF', '#4A2A18', '#7F563C', '#F5DAB8', '#D96A0C', '#139C90', '#E03C69', '#2B9967', '#D98E12']),
      ui: { rCard: 24, rBtn: 999, cardBorder: '2px dashed {line}', cardShadow: 'none', btnShadow: '0 6px 14px {primaryA}' } },
    { id: 'adha', name: 'عيد الأضحى', desc: 'ألوان الطين والزيتون وبلاط سداسي', cats: ['seasonal', 'islamic'], motif: 'adha', fonts: ['naskh', 'sans'],
      light: pal(['#F6EFE2', '#FFFCF5', '#2C281D', '#675F4B', '#DFD1B2', '#8A4529', '#58783F', '#BF922A', '#4B7B46', '#BF701F']),
      ui: { rCard: 10, rBtn: 8, cardBorder: '1px solid {line}', cardShadow: '0 2px 0 {line}' } },
    { id: 'dhulhijjah', name: 'عشر ذي الحجة', desc: 'أشعة ذهبية وسكينة رملية للأيام الفاضلة', cats: ['seasonal', 'islamic'], motif: 'dhulhijjah', fonts: ['naskh', 'sans'],
      light: pal(['#FBF5E6', '#FFFFFF', '#1E1A12', '#625847', '#E7D9B2', '#946510', '#1F1F1F', '#C4A046', '#3A7A4C', '#B3641A']),
      dark: pal(['#14110A', '#1E1A10', '#F6EDD6', '#C2B697', '#3A3219', '#E0B34A', '#E8D7A6', '#E0B34A', '#6CC28A', '#F0A04B']),
      ui: { rCard: 14, rBtn: 10, cardBorder: '1px solid {accent}', cardShadow: '0 6px 18px {shadow}' } },
    { id: 'spring', name: 'ربيع', desc: 'أزهار مفتوحة وأخضر نابض بالحياة', cats: ['seasonal', 'nature'], motif: 'spring', fonts: ['rounded', 'sans'],
      light: pal(['#F2FBEE', '#FFFFFF', '#1F3B25', '#527257', '#CFE9C6', '#2F9A41', '#EE7FA9', '#F7B91C', '#2F9A41', '#DA8A1C']),
      ui: { rCard: 24, rBtn: 18 } },
    { id: 'autumn', name: 'خريف', desc: 'أوراق متساقطة بألوان دافئة', cats: ['seasonal', 'nature'], motif: 'autumn', fonts: ['naskh', 'sans'],
      light: pal(['#FAF0E3', '#FFFAF2', '#3B2415', '#7A5842', '#EACCAC', '#AD4E17', '#6F8233', '#CE9812', '#66843A', '#B8601A']),
      ui: { rCard: 16, rBtn: 12 } },
    { id: 'winter', name: 'شتاء', desc: 'ثلج هادئ وزرقة جليدية صافية', cats: ['seasonal', 'calm'], motif: 'winter', fonts: ['sans', 'sans'],
      light: pal(['#ECF3FA', '#FFFFFF', '#1B293C', '#53647C', '#CFDDEC', '#2A68A4', '#6CB0D6', '#8D9DD3', '#38988B', '#C98035']),
      ui: { rCard: 20, rBtn: 14, cardShadow: '0 8px 24px {shadow}' } }
  ];

  var UI_DEFAULT = {
    rCard: 18, rBtn: 14, card: '{surface}', cardBorder: '1px solid {line}', cardShadow: '0 2px 10px {shadow}',
    btnBorder: '1px solid transparent', btnShadow: 'none', btnWeight: 700, titleWeight: 800, titleSpacing: '0', pageBg: '{bg}'
  };

  function deriveDark(p) {
    var h = C.hsl(p.bg)[0], hp = C.hsl(p.primary)[0], tint = function (l, s) { return C.hsl2hex(h, s, l); };
    var lift = function (c, minL) { var x = C.hsl(c); return C.hsl2hex(x[0], Math.min(1, x[1] * .95), Math.max(x[2], minL)); };
    return { bg: tint(.085, .3), surface: tint(.125, .26), text: tint(.93, .2), muted: tint(.72, .14), line: tint(.22, .22),
      primary: lift(p.primary, .6), secondary: lift(p.secondary, .6), accent: lift(p.accent, .62), good: lift(p.good, .58), warn: lift(p.warn, .6) };
  }
  function deriveLight(p) {
    var h = C.hsl(p.bg)[0], tint = function (l, s) { return C.hsl2hex(h, s, l); };
    var drop = function (c, maxL) { var x = C.hsl(c); return C.hsl2hex(x[0], x[1], Math.min(x[2], maxL)); };
    return { bg: tint(.96, .35), surface: '#ffffff', text: tint(.12, .35), muted: tint(.38, .15), line: tint(.84, .25),
      primary: drop(p.primary, .38), secondary: drop(p.secondary, .45), accent: drop(p.accent, .45), good: drop(p.good, .36), warn: drop(p.warn, .38) };
  }

  var T = {
    LIST: THEMES, CATS: CATS, FONTS: FONTS, FONT_NAMES: FONT_NAMES, KEYS: KEYS,
    get: function (id) { for (var i = 0; i < THEMES.length; i++) if (THEMES[i].id === id) return THEMES[i]; return THEMES[0]; },
    /** الوضع الفعلي: light/dark */
    resolveMode: function (theme, mode, systemDark) {
      if (mode === 'light' || mode === 'dark') return mode;
      return theme.prefer || (systemDark ? 'dark' : 'light');
    },
    palette: function (theme, mode) {
      var p = mode === 'dark' ? (theme.dark || deriveDark(theme.light)) : (theme.light || deriveLight(theme.dark));
      return Object.assign({}, p);
    },
    /** يحسب كل متغيرات الثيم الفعلية مع الاستبدالات المخصصة وضمان التباين */
    compute: function (theme, mode, settings) {
      var s = settings || {}, ov = s.colors || {}, p = T.palette(theme, mode), dark = mode === 'dark';
      if (ov.primary) p.primary = ov.primary;
      if (ov.secondary) p.secondary = ov.secondary;
      if (ov.accent) p.accent = ov.accent;
      if (ov.bg) { p.bg = ov.bg; dark = C.lum(ov.bg) < 0.3; p.surface = C.mix(ov.bg, '#ffffff', dark ? .07 : .6); if (dark !== (mode === 'dark')) { p.text = dark ? '#f2f2f2' : '#1a1a1a'; p.muted = dark ? '#bdbdbd' : '#555555'; } p.line = C.mix(ov.bg, p.text, .16); }
      // ضمان قابلية القراءة بعد أي تخصيص
      p.text = C.ensure(p.text, p.bg, 8); p.text = C.ensure(p.text, p.surface, 8);
      p.muted = C.ensure(C.ensure(p.muted, p.bg, 4.6), p.surface, 4.6);
      var v = {}; Object.keys(p).forEach(function (k) { v[k] = p[k]; });
      v.bg2 = C.mix(p.bg, p.primary, dark ? .12 : .06);
      v.surface2 = C.mix(p.bg, p.text, dark ? .10 : .05);
      v.primaryText = C.ensure(p.primary, p.surface, 4.6); v.primaryText = C.ensure(v.primaryText, p.bg, 4.6);
      v.secondaryText = C.ensure(p.secondary, p.surface, 4.6);
      v.goodText = C.ensure(p.good, p.surface, 4.6); v.warnText = C.ensure(p.warn, p.surface, 4.6);
      v.onPrimary = C.onColor(p.primary); v.onSecondary = C.onColor(p.secondary); v.onAccent = C.onColor(p.accent);
      v.onGood = C.onColor(p.good); v.onWarn = C.onColor(p.warn);
      v.danger = C.ensure(dark ? '#FF7B72' : '#C62828', p.surface, 4.6); v.onDanger = C.onColor(v.danger);
      v.primaryD = C.mix(p.primary, '#000000', .25); v.shadow = C.rgba(dark ? '#000000' : p.text, dark ? .35 : .1);
      v.primaryA = C.rgba(p.primary, .35); v.primaryA2 = C.rgba(p.primary, dark ? .22 : .2); v.secondaryA2 = C.rgba(p.secondary, dark ? .2 : .24); v.accentA2 = C.rgba(p.accent, dark ? .16 : .22);
      v.lineA = C.rgba(p.line, .9);
      var soft = function (c, t) { var r = C.mix(p.surface, c, t); while (t > 0.03 && C.contrast(p.text, r) < 7.2) { t -= 0.02; r = C.mix(p.surface, c, t); } return r; };
      v.primarySoft = soft(p.primary, dark ? .2 : .11); v.goodSoft = soft(p.good, dark ? .2 : .13); v.warnSoft = soft(p.warn, dark ? .2 : .15);
      v.accentSoft = soft(p.accent, dark ? .2 : .16);
      // حالات قطع البازل
      v.pcNone = v.surface2; v.pcNoneLine = C.mix(p.line, p.text, .25);
      v.pcProg = p.good; v.pcProgBase = v.goodSoft; v.pcDone = p.primary; v.pcRev = p.warn;
      var ui = Object.assign({}, UI_DEFAULT, theme.ui || {});
      var sub = function (str) { return String(str).replace(/\{(\w+)\}/g, function (_, k) { return v[k] !== undefined ? v[k] : '{' + k + '}'; }); };
      var out = {
        '--bg': p.bg, '--surface': p.surface, '--surface2': v.surface2, '--text': p.text, '--muted': p.muted, '--line': p.line,
        '--primary': p.primary, '--primary-text': v.primaryText, '--on-primary': v.onPrimary, '--primary-soft': v.primarySoft,
        '--secondary': p.secondary, '--secondary-text': v.secondaryText, '--on-secondary': v.onSecondary,
        '--accent': p.accent, '--on-accent': v.onAccent, '--accent-soft': v.accentSoft,
        '--good': p.good, '--good-text': v.goodText, '--on-good': v.onGood, '--good-soft': v.goodSoft,
        '--warn': p.warn, '--warn-text': v.warnText, '--on-warn': v.onWarn, '--warn-soft': v.warnSoft,
        '--danger': v.danger, '--on-danger': v.onDanger, '--shadow': v.shadow, '--bg2': v.bg2,
        '--pc-none': v.pcNone, '--pc-none-line': v.pcNoneLine, '--pc-prog': v.pcProg, '--pc-prog-base': v.pcProgBase, '--pc-done': v.pcDone, '--pc-rev': v.pcRev,
        '--r-card': (s.radius >= 0 ? s.radius : ui.rCard) + 'px', '--r-btn': (s.radius >= 0 ? Math.round(s.radius * .75) : ui.rBtn) + 'px',
        '--card-bg': sub(ui.card), '--card-border': sub(ui.cardBorder), '--card-shadow': sub(ui.cardShadow),
        '--btn-bg': sub(ui.btnBg || '{primary}'), '--btn-border': sub(ui.btnBorder), '--btn-shadow': sub(ui.btnShadow), '--btn-weight': ui.btnWeight,
        '--title-weight': ui.titleWeight, '--title-spacing': ui.titleSpacing, '--page-bg': sub(ui.pageBg)
      };
      var fk = s.fontStyle && s.fontStyle !== 'theme' ? s.fontStyle : null;
      out['--font-display'] = FONTS[fk || theme.fonts[0]]; out['--font-body'] = FONTS[fk || theme.fonts[1]];
      out['--deco'] = s.deco === false ? 'none' : M.art.tile(theme.motif, { primary: p.primary, secondary: p.secondary, accent: p.accent, good: p.good, warn: p.warn, text: p.text, muted: p.muted, line: p.line, bg: p.bg, surface: p.surface });
      return { vars: out, palette: v, mode: mode };
    },
    /** يطبّق المتغيرات على عنصر (الجذر أو بطاقة معاينة) */
    applyTo: function (el, themeId, mode, settings) {
      var theme = T.get(themeId), r = T.compute(theme, mode, settings);
      Object.keys(r.vars).forEach(function (k) { el.style.setProperty(k, r.vars[k]); });
      el.setAttribute('data-theme', theme.id); el.setAttribute('data-mode', mode);
      return r;
    }
  };
  M.themes = T;
  if (typeof module !== 'undefined') module.exports = T;
})(globalThis.M = globalThis.M || {});
