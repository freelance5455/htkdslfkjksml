/* رسومات SVG مولَّدة: زخارف الثيمات، نمط الخلفية، ومراحل النمو. الألوان تأتي من متغيرات CSS فتتغير فورًا مع الثيم */
(function (M) {
  'use strict';
  var A = {};
  function rnd(seed) { var s = seed; return function () { s = (s * 16807) % 2147483647; return s / 2147483647; }; }
  function F(c, o) { return 'fill:var(--' + c + ')' + (o != null ? ';opacity:' + o : ''); }
  function S(c, w, o) { return 'fill:none;stroke:var(--' + c + ');stroke-width:' + (w || 1.5) + ';stroke-linecap:round;stroke-linejoin:round' + (o != null ? ';opacity:' + o : ''); }
  function g(tr, inner) { return '<g transform="' + tr + '">' + inner + '</g>'; }

  var P = {
    leaf: function (x, y, s, rot, c, o) { return g('translate(' + x + ' ' + y + ') rotate(' + (rot || 0) + ')', '<path d="M0 0C' + s * .6 + ' ' + -s * .5 + ' ' + s * .6 + ' ' + -s * 1.1 + ' 0 ' + -s * 1.6 + 'C' + -s * .6 + ' ' + -s * 1.1 + ' ' + -s * .6 + ' ' + -s * .5 + ' 0 0Z" style="' + F(c, o) + '"/><path d="M0 0V' + -s * 1.3 + '" style="' + S('bg', 1, .5) + '"/>'); },
    flower: function (x, y, r, c, ctr, o) {
      var p = ''; for (var i = 0; i < 5; i++) { var a = i * 72 * Math.PI / 180; p += '<circle cx="' + (Math.sin(a) * r * .7).toFixed(1) + '" cy="' + (-Math.cos(a) * r * .7).toFixed(1) + '" r="' + (r * .5).toFixed(1) + '"/>'; }
      return g('translate(' + x + ' ' + y + ')', '<g style="' + F(c, o) + '">' + p + '</g><circle r="' + (r * .28).toFixed(1) + '" style="' + F(ctr || 'accent') + '"/>');
    },
    star: function (x, y, r, n, c, o, rot) {
      var pts = [], k = n || 5; for (var i = 0; i < k * 2; i++) { var a = i * Math.PI / k - Math.PI / 2, rr = i % 2 ? r * .45 : r; pts.push((Math.cos(a) * rr).toFixed(1) + ',' + (Math.sin(a) * rr).toFixed(1)); }
      return g('translate(' + x + ' ' + y + ') rotate(' + (rot || 0) + ')', '<polygon points="' + pts.join(' ') + '" style="' + F(c, o) + '"/>');
    },
    star8: function (x, y, r, c, o, st) { // نجمة ثمانية (مربعان متراكبان)
      var q = r * .72, sty = st ? S(c, 1.2, o) : F(c, o);
      return g('translate(' + x + ' ' + y + ')', '<rect x="' + -q + '" y="' + -q + '" width="' + 2 * q + '" height="' + 2 * q + '" style="' + sty + '"/><rect x="' + -q + '" y="' + -q + '" width="' + 2 * q + '" height="' + 2 * q + '" transform="rotate(45)" style="' + sty + '"/>');
    },
    crescent: function (x, y, r, c, o) { return g('translate(' + x + ' ' + y + ')', '<path d="M0 ' + -r + 'A' + r + ' ' + r + ' 0 1 0 ' + r * .9 + ' ' + r * .5 + 'A' + r * .8 + ' ' + r * .8 + ' 0 1 1 0 ' + -r + 'Z" style="' + F(c, o) + '"/>'); },
    circle: function (x, y, r, c, o) { return '<circle cx="' + x + '" cy="' + y + '" r="' + r + '" style="' + F(c, o) + '"/>'; },
    ring: function (x, y, r, c, w, o) { return '<circle cx="' + x + '" cy="' + y + '" r="' + r + '" style="' + S(c, w, o) + '"/>'; },
    blob: function (x, y, rx, ry, c, o, rot) { return '<ellipse cx="' + x + '" cy="' + y + '" rx="' + rx + '" ry="' + ry + '" transform="rotate(' + (rot || 0) + ' ' + x + ' ' + y + ')" style="' + F(c, o) + '"/>'; },
    snow: function (x, y, r, c, o) { var l = ''; for (var i = 0; i < 3; i++) l += '<line x1="0" y1="' + -r + '" x2="0" y2="' + r + '" transform="rotate(' + i * 60 + ')"/>'; return g('translate(' + x + ' ' + y + ')', '<g style="' + S(c, 1.3, o) + '">' + l + '</g>'); },
    lantern: function (x, y, s, c) { return g('translate(' + x + ' ' + y + ') scale(' + s + ')', '<path d="M0 -26V-14" style="' + S('accent', 1.5) + '"/><path d="M-6 -14h12l3 4v18l-3 4h-12l-3 -4v-18z" style="' + F(c) + '"/><path d="M-6 -14h12M-9 -10h18M-9 8h18" style="' + S('bg', 1, .6) + '"/><circle cy="-1" r="3.4" style="' + F('bg', .75) + '"/><path d="M-2 12l2 6 2 -6z" style="' + F('accent') + '"/>'); },
    line: function (d, c, w, o) { return '<path d="' + d + '" style="' + S(c, w, o) + '"/>'; },
    sprig: function (x, y, h, rot, c) {
      var s = '<path d="M0 0Q4 ' + -h / 2 + ' 0 ' + -h + '" style="' + S(c, 1.4, .8) + '"/>';
      for (var i = 1; i <= 4; i++) { var yy = -h * i / 5; s += P.leaf(0, yy, h / 7, i % 2 ? 55 : -55, c, .85); }
      return g('translate(' + x + ' ' + y + ') rotate(' + (rot || 0) + ')', s);
    },
    wave: function (x, y, r, c, o) { return g('translate(' + x + ' ' + y + ')', '<path d="M' + -r + ' 0A' + r + ' ' + r + ' 0 0 1 ' + r + ' 0M' + -r * .66 + ' 0A' + r * .66 + ' ' + r * .66 + ' 0 0 1 ' + r * .66 + ' 0M' + -r * .33 + ' 0A' + r * .33 + ' ' + r * .33 + ' 0 0 1 ' + r * .33 + ' 0" style="' + S(c, 1, o) + '"/>'); },
    rays: function (x, y, r1, r2, n, c, o) { var l = ''; for (var i = 0; i < n; i++) { var a = i * 2 * Math.PI / n; l += 'M' + (x + Math.cos(a) * r1).toFixed(1) + ' ' + (y + Math.sin(a) * r1).toFixed(1) + 'L' + (x + Math.cos(a) * r2).toFixed(1) + ' ' + (y + Math.sin(a) * r2).toFixed(1); } return '<path d="' + l + '" style="' + S(c, 1.2, o) + '"/>'; },
    hex: function (x, y, r, c, o) { var p = []; for (var i = 0; i < 6; i++) { var a = i * Math.PI / 3 + Math.PI / 6; p.push((x + Math.cos(a) * r).toFixed(1) + ',' + (y + Math.sin(a) * r).toFixed(1)); } return '<polygon points="' + p.join(' ') + '" style="' + S(c, 1.2, o) + '"/>'; },
    heart: function (x, y, s, c, o) { return g('translate(' + x + ' ' + y + ') scale(' + s + ')', '<path d="M0 6C-9 -1 -6 -8 0 -4C6 -8 9 -1 0 6Z" style="' + F(c, o) + '"/>'); },
    squiggle: function (x, y, w, c) { return '<path d="M' + x + ' ' + y + 'q' + w / 8 + ' -6 ' + w / 4 + ' 0t' + w / 4 + ' 0t' + w / 4 + ' 0t' + w / 4 + ' 0" style="' + S(c, 2) + '"/>'; }
  };
  A.P = P;

  /* ---------- زخرفة الرأس (360×110) لكل ثيم ---------- */
  var HERO = {
    leaf: function () { var r = rnd(3), s = P.blob(300, 40, 90, 60, 'secondary', .16) + P.blob(60, 80, 80, 40, 'good', .14); for (var i = 0; i < 7; i++) s += P.leaf(20 + i * 52 + r() * 14, 112, 22 + r() * 14, -30 + r() * 60, i % 2 ? 'good' : 'primary', .55); return s + P.circle(318, 26, 7, 'accent', .7); },
    blossom: function () { var s = P.blob(70, 30, 90, 50, 'secondary', .18); [[40, 28, 13], [92, 62, 9], [300, 36, 15], [338, 84, 10], [250, 78, 8], [200, 18, 7]].forEach(function (f, i) { s += P.flower(f[0], f[1], f[2], i % 2 ? 'secondary' : 'primary', 'accent', .75); }); return s + P.leaf(318, 112, 20, 20, 'good', .5) + P.leaf(24, 112, 18, -25, 'good', .5); },
    zen: function () { return P.circle(284, 44, 24, 'primary', .9) + P.line('M0 92H360', 'line', 1) + P.line('M40 78C90 58 130 98 190 74S300 70 360 86', 'muted', 1, .5) + P.line('M60 28V92', 'line', 1) + P.line('M96 40V92', 'line', 1, .6) + P.line('M130 52V92', 'line', 1, .35); },
    geometric: function () { var s = ''; for (var i = 0; i < 7; i++) s += P.star8(30 + i * 50, 55, i % 2 ? 20 : 26, i % 2 ? 'accent' : 'primary', i % 2 ? .6 : .22, i % 2); return s + P.line('M0 98H360', 'accent', 1.5, .8) + P.line('M0 104H360', 'accent', 1, .5) + P.ring(180, 55, 36, 'accent', 1, .5); },
    watercolor: function () { return P.blob(70, 52, 78, 40, 'primary', .22, -15) + P.blob(190, 40, 70, 46, 'secondary', .26, 10) + P.blob(290, 66, 82, 36, 'accent', .28, -8) + P.blob(150, 84, 60, 22, 'good', .2) + P.blob(320, 24, 36, 20, 'primary', .15); },
    modern: function () { return P.circle(300, 34, 46, 'primary', .1) + P.circle(260, 76, 26, 'secondary', .14) + P.line('M20 80H120', 'primary', 3, .8) + P.line('M20 92H80', 'muted', 3, .35) + '<rect x="318" y="62" width="22" height="22" rx="6" style="' + F('accent', .8) + '"/>'; },
    vintage: function () { return P.sprig(40, 112, 90, -8, 'primary') + P.sprig(84, 112, 70, 12, 'secondary') + P.sprig(320, 112, 96, 6, 'primary') + P.sprig(280, 112, 64, -14, 'secondary') + P.line('M120 28H240', 'secondary', 1, .6) + P.line('M140 34H220', 'secondary', 1, .4) + P.star8(180, 20, 7, 'accent', .8); },
    pastel: function () { return P.circle(54, 40, 26, 'secondary', .55) + P.circle(100, 74, 14, 'accent', .7) + '<rect x="270" y="20" width="42" height="42" rx="14" transform="rotate(14 291 41)" style="' + F('primary', .35) + '"/>' + P.circle(330, 84, 18, 'good', .5) + P.star(210, 30, 12, 5, 'accent', .8) + P.circle(180, 84, 6, 'primary', .5); },
    notebook: function () { var s = ''; for (var i = 0; i < 4; i++) s += P.line('M0 ' + (30 + i * 22) + 'H360', 'line', 1, .9); return s + P.line('M300 0V110', 'secondary', 1.5, .7) + '<rect x="30" y="16" width="64" height="20" rx="2" transform="rotate(-4 62 26)" style="' + F('accent', .6) + '"/>' + P.line('M110 60q10 -14 22 0t22 0t22 0', 'primary', 2, .7); },
    night: function () { var r = rnd(11), s = P.crescent(300, 40, 24, 'primary', .95); for (var i = 0; i < 26; i++) s += P.circle((r() * 360).toFixed(0), (r() * 100).toFixed(0), (r() * 1.4 + .5).toFixed(1), 'text', .5 + r() * .4); return s + P.star(60, 30, 8, 4, 'primary', .9) + P.star(190, 62, 6, 4, 'secondary', .9) + P.star(140, 20, 5, 4, 'accent', .9); },
    doodle: function () { return P.star(50, 34, 16, 5, 'accent', 1) + P.squiggle(96, 70, 80, 'primary') + P.heart(250, 36, 2.2, 'primary', .95) + P.ring(310, 60, 16, 'secondary', 3) + P.line('M20 90l14 -10l14 10', 'secondary', 3) + P.circle(200, 24, 5, 'accent', 1) + P.squiggle(236, 90, 60, 'secondary'); },
    editorial: function () { return '<rect x="0" y="0" width="360" height="6" style="' + F('text') + '"/><rect x="0" y="16" width="120" height="10" style="' + F('primary') + '"/>' + P.line('M0 100H360', 'text', 2) + '<rect x="250" y="34" width="80" height="50" style="' + F('accent', .9) + '"/><rect x="262" y="46" width="56" height="26" style="' + F('bg') + '"/>' + P.line('M20 60H200M20 74H160', 'text', 2, .7); },
    ramadan: function () { var r = rnd(5), s = P.crescent(300, 44, 26, 'primary', .95) + P.star(268, 28, 7, 5, 'primary', .9); for (var i = 0; i < 16; i++) s += P.circle((r() * 360).toFixed(0), (r() * 100).toFixed(0), (r() * 1.2 + .5).toFixed(1), 'text', .5); return s + P.lantern(60, 44, 1.6, 'primary') + P.lantern(120, 30, 1.1, 'secondary') + P.line('M0 0H200', 'accent', 1, .3); },
    fitr: function () { var s = P.line('M0 6Q90 40 180 6T360 6', 'text', 1, .4), cs = ['primary', 'secondary', 'accent', 'good']; for (var i = 0; i < 8; i++) s += g('translate(' + (22 + i * 44) + ' ' + (i % 2 ? 26 : 22) + ')', '<path d="M-9 0h18l-9 22z" style="' + F(cs[i % 4]) + '"/>'); var r = rnd(9); for (var j = 0; j < 14; j++) s += P.circle((r() * 360).toFixed(0), (50 + r() * 56).toFixed(0), (r() * 3 + 1.5).toFixed(1), cs[j % 4], .7); return s + P.crescent(300, 80, 14, 'accent', .9); },
    adha: function () { var s = ''; for (var i = 0; i < 6; i++) for (var j = 0; j < 3; j++) s += P.hex(30 + i * 62 + (j % 2) * 31, 22 + j * 36, 22, i % 2 ? 'secondary' : 'primary', .3); return s + P.crescent(300, 40, 20, 'accent', .95) + P.star(272, 26, 6, 5, 'accent', .95) + P.line('M0 104H360', 'primary', 2, .6); },
    dhulhijjah: function () { return P.rays(180, 120, 46, 130, 22, 'accent', .7) + P.circle(180, 120, 38, 'accent', .35) + P.ring(180, 120, 44, 'accent', 1.5, .8) + P.star8(60, 40, 16, 'accent', .6) + P.star8(300, 40, 16, 'accent', .6) + P.line('M0 100H360', 'text', 1, .4); },
    spring: function () { var s = P.blob(60, 20, 80, 36, 'secondary', .14) + P.blob(300, 90, 90, 30, 'good', .16); [[40, 34, 12], [110, 70, 9], [250, 28, 13], [320, 56, 11], [200, 80, 8]].forEach(function (f, i) { s += P.flower(f[0], f[1], f[2], i % 2 ? 'primary' : 'secondary', 'accent', .85); }); return s + P.leaf(150, 112, 22, 15, 'good', .6) + P.leaf(290, 112, 18, -20, 'good', .6) + P.circle(180, 28, 7, 'accent', .9); },
    autumn: function () { var r = rnd(21), s = P.circle(300, 36, 22, 'accent', .5), cs = ['primary', 'warn', 'accent', 'secondary']; for (var i = 0; i < 9; i++) s += P.leaf(r() * 340 + 10, 20 + r() * 80, 12 + r() * 10, r() * 360, cs[i % 4], .75); return s; },
    winter: function () { var r = rnd(17), s = P.blob(180, 120, 220, 36, 'secondary', .22); for (var i = 0; i < 12; i++) s += P.snow(r() * 350 + 5, r() * 90 + 8, 3 + r() * 7, 'primary', .65); return s + P.circle(300, 30, 18, 'surface', 1) + P.ring(300, 30, 18, 'secondary', 1.5, .8); }
  };
  A.hero = function (motif) { return '<svg class="hero-art" viewBox="0 0 360 110" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false">' + (HERO[motif] || HERO.leaf)() + '</svg>'; };

  /* ---------- نمط خلفية (بلاط 96×96) كرابط data-URI بألوان صريحة ---------- */
  var TILE = {
    leaf: function (c) { return P.leaf(20, 40, 14, 20, c.good, .12) + P.leaf(70, 86, 12, -30, c.primary, .1); },
    blossom: function (c) { return P.flower(24, 28, 7, c.secondary, c.accent, .16) + P.flower(72, 70, 5, c.primary, c.accent, .12); },
    zen: function (c) { return P.wave(24, 40, 20, c.line, .55) + P.wave(72, 40, 20, c.line, .55) + P.wave(48, 66, 20, c.line, .55) + P.wave(0, 66, 20, c.line, .55) + P.wave(96, 66, 20, c.line, .55); },
    geometric: function (c) { return P.star8(48, 48, 24, c.accent, .2, true) + P.star8(0, 0, 14, c.accent, .2, true) + P.star8(96, 0, 14, c.accent, .2, true) + P.star8(0, 96, 14, c.accent, .2, true) + P.star8(96, 96, 14, c.accent, .2, true); },
    watercolor: function (c) { return ''; },
    modern: function (c) { return P.circle(8, 8, 1.2, c.muted, .35) + P.circle(56, 56, 1.2, c.muted, .35); },
    vintage: function (c) { return P.sprig(26, 70, 40, 10, c.primary, .3) + P.circle(70, 26, 1.5, c.secondary, .4); },
    pastel: function (c) { return P.circle(18, 20, 5, c.secondary, .18) + P.star(70, 30, 7, 5, c.accent, .22) + P.circle(40, 72, 4, c.primary, .14) + '<rect x="72" y="66" width="12" height="12" rx="4" fill="' + c.accent + '" opacity=".2"/>'; },
    notebook: function (c) { return ''; },
    night: function (c) { var r = rnd(7), s = ''; for (var i = 0; i < 9; i++) s += '<circle cx="' + (r() * 96).toFixed(0) + '" cy="' + (r() * 96).toFixed(0) + '" r="' + (r() * 1.1 + .4).toFixed(1) + '" fill="' + c.text + '" opacity="' + (0.25 + r() * .4).toFixed(2) + '"/>'; return s + P.star(30, 60, 4, 4, c.primary, .5); },
    doodle: function (c) { return P.squiggle(10, 24, 30, c.primary) + P.star(66, 62, 6, 5, c.accent, .5) + P.heart(24, 74, 1.1, c.secondary, .4); },
    editorial: function (c) { return ''; },
    ramadan: function (c) { return P.crescent(24, 30, 9, c.primary, .18) + P.star(66, 66, 5, 5, c.primary, .2) + P.circle(70, 20, 1.2, c.text, .3) + P.circle(20, 78, 1.2, c.text, .3); },
    fitr: function (c) { return P.circle(14, 16, 3, c.primary, .22) + P.circle(60, 40, 2.5, c.secondary, .26) + P.circle(30, 72, 3, c.accent, .26) + P.circle(80, 82, 2.5, c.good, .24); },
    adha: function (c) { return P.hex(24, 24, 20, c.primary, .16) + P.hex(72, 48, 20, c.primary, .16) + P.hex(24, 72, 20, c.primary, .16); },
    dhulhijjah: function (c) { return P.star8(48, 48, 12, c.accent, .22, true) + P.circle(0, 0, 2, c.accent, .3) + P.circle(96, 96, 2, c.accent, .3); },
    spring: function (c) { return P.flower(22, 26, 6, c.secondary, c.accent, .22) + P.leaf(70, 80, 11, 25, c.good, .16); },
    autumn: function (c) { return P.leaf(20, 34, 12, 40, c.primary, .14) + P.leaf(70, 80, 11, -35, c.warn, .14); },
    winter: function (c) { return P.snow(22, 24, 6, c.primary, .22) + P.snow(70, 68, 5, c.secondary, .3); }
  };
  A.tile = function (motif, colors) {
    var body = (TILE[motif] || TILE.leaf)(colors);
    if (!body) return 'none';
    // الأنماط المولّدة تستخدم var(--x)؛ نستبدلها بألوان صريحة لأن data-URI لا يرث المتغيرات
    body = body.replace(/var\(--(\w+)\)/g, function (_, k) { return colors[k] || '#888'; });
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 96 96">' + body + '</svg>';
    return 'url("data:image/svg+xml,' + encodeURIComponent(svg) + '")';
  };

  /* ---------- مراحل النمو: بذرة ← برعم ← نبتة ← شجرة ← حديقة (200×200) ---------- */
  var SOIL = '<ellipse cx="100" cy="176" rx="74" ry="14" style="' + F('line') + '"/><ellipse cx="100" cy="172" rx="62" ry="10" style="' + F('secondary', .35) + '"/>';
  var PLANT = [
    function () { return SOIL + '<ellipse cx="100" cy="164" rx="11" ry="15" transform="rotate(-18 100 164)" style="' + F('warn') + '"/><path d="M96 158q4 -4 7 0" style="' + S('bg', 1.5, .6) + '"/>' + P.circle(150, 60, 14, 'accent', .5); },
    function () { return SOIL + '<path d="M100 172V132" style="' + S('good', 4) + '"/>' + P.leaf(100, 140, 20, -38, 'good') + P.leaf(100, 146, 18, 42, 'primary') + P.circle(150, 60, 14, 'accent', .5); },
    function () { return SOIL + '<path d="M100 172Q96 120 100 92" style="' + S('good', 5) + '"/>' + P.leaf(100, 150, 30, -45, 'good') + P.leaf(100, 138, 28, 48, 'primary') + P.leaf(99, 118, 24, -40, 'primary') + P.leaf(100, 104, 22, 38, 'good') + P.circle(100, 84, 9, 'accent') + P.circle(150, 50, 14, 'accent', .5); },
    function () { return SOIL + '<path d="M96 176Q100 120 94 84M104 176Q100 130 110 100" style="' + S('warn', 9) + '"/>' + P.blob(100, 70, 58, 46, 'good', .95) + P.blob(66, 88, 30, 24, 'primary', .9) + P.blob(136, 86, 30, 24, 'primary', .9) + P.blob(100, 50, 34, 26, 'secondary', .85) + P.circle(84, 72, 5, 'accent') + P.circle(122, 80, 5, 'accent') + P.circle(104, 52, 5, 'accent'); },
    function () { return SOIL + '<path d="M70 176Q74 130 66 100" style="' + S('warn', 8) + '"/>' + P.blob(66, 84, 46, 36, 'good', .95) + P.blob(44, 100, 24, 18, 'primary', .9) + P.blob(90, 98, 22, 18, 'primary', .9) + P.circle(56, 80, 4, 'accent') + P.circle(78, 90, 4, 'accent') + P.flower(130, 150, 12, 'secondary', 'accent') + P.flower(160, 160, 9, 'primary', 'accent') + P.flower(118, 168, 7, 'accent', 'warn') + P.leaf(150, 174, 18, 20, 'good') + P.leaf(176, 174, 16, -20, 'primary') + P.leaf(108, 174, 14, -30, 'good') + P.circle(150, 46, 14, 'accent', .6); }
  ];
  A.plant = function (stage, cls) { return '<svg class="' + (cls || 'plant-art') + '" viewBox="0 0 200 200" role="img" aria-hidden="true">' + PLANT[Math.max(0, Math.min(4, stage))]() + '</svg>'; };
  M.art = A;
  if (typeof module !== 'undefined') module.exports = A;
})(globalThis.M = globalThis.M || {});
