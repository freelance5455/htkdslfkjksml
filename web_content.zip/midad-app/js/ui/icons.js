/* مجموعة أيقونات SVG (شبكة 24). الصنف f = شكل مغلق قابل للتعبئة حسب نمط الأيقونات */
(function (M) {
  'use strict';
  var I = {
    home: '<path class="f" d="M4 11l8-7 8 7v8a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1z"/>',
    review: '<path d="M4 12a8 8 0 0 1 14-5.3L20 9"/><path d="M20 4v5h-5"/><path d="M20 12a8 8 0 0 1-14 5.3L4 15"/><path d="M4 20v-5h5"/>',
    puzzle: '<path class="f" d="M10 4a2 2 0 1 1 4 0v1h4a1 1 0 0 1 1 1v4h-1a2 2 0 1 0 0 4h1v4a1 1 0 0 1-1 1h-4v-1a2 2 0 1 0-4 0v1H6a1 1 0 0 1-1-1v-4h1a2 2 0 1 0 0-4H5V6a1 1 0 0 1 1-1h4z"/>',
    calendar: '<rect class="f" x="4" y="5" width="16" height="15" rx="2"/><path d="M8 3v4M16 3v4M4 10h16"/>',
    more: '<circle class="f" cx="5" cy="12" r="1.8"/><circle class="f" cx="12" cy="12" r="1.8"/><circle class="f" cx="19" cy="12" r="1.8"/>',
    plan: '<path d="M9 6h11M9 12h11M9 18h11"/><circle class="f" cx="4.5" cy="6" r="1.3"/><circle class="f" cx="4.5" cy="12" r="1.3"/><circle class="f" cx="4.5" cy="18" r="1.3"/>',
    chart: '<path d="M5 20V10M12 20V4M19 20v-7"/>',
    plant: '<path d="M12 21v-9"/><path class="f" d="M12 12c0-4 3-6 7-6 0 4-3 6-7 6z"/><path class="f" d="M12 15c0-3-2-5-6-5 0 3 2 5 6 5z"/>',
    palette: '<path class="f" d="M12 3a9 9 0 1 0 0 18c1.5 0 2-1 1.5-2s0-2 1.5-2h2a3 3 0 0 0 3-3C20 8 16.5 3 12 3z"/><circle cx="8" cy="11" r="1"/><circle cx="12" cy="7.5" r="1"/><circle cx="16" cy="10" r="1"/>',
    gear: '<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle class="f" cx="16" cy="7" r="2"/><circle class="f" cx="8" cy="17" r="2"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5 12h14"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    play: '<path class="f" d="M7 5l12 7-12 7z"/>',
    restart: '<path d="M4 12a8 8 0 1 0 3-6.3"/><path d="M4 4v5h5"/>',
    edit: '<path class="f" d="M4 20l1-4L16 5l3 3L8 19z"/><path d="M14 7l3 3"/>',
    trash: '<path d="M5 7h14M9 7V4h6v3M7 7l1 13h8l1-13"/>',
    clock: '<circle class="f" cx="12" cy="12" r="8.5"/><path d="M12 7v5l3 2"/>',
    download: '<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',
    upload: '<path d="M12 16V5M7 9l5-5 5 5M5 20h14"/>',
    star: '<path class="f" d="M12 3.5l2.6 5.5 6 .8-4.4 4.2 1.1 6L12 17l-5.3 3 1.1-6L3.4 9.8l6-.8z"/>',
    heart: '<path class="f" d="M12 20s-7.5-4.6-7.5-10A4.3 4.3 0 0 1 12 7.5 4.3 4.3 0 0 1 19.5 10c0 5.4-7.5 10-7.5 10z"/>',
    next: '<path d="M15 5l-7 7 7 7"/>', prev: '<path d="M9 5l7 7-7 7"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    book: '<path class="f" d="M4 5.5C7 4 10 4.3 12 6c2-1.7 5-2 8-.5V19c-3-1.5-6-1.2-8 .5-2-1.7-5-2-8-.5z"/><path d="M12 6v13.5"/>',
    bell: '<path class="f" d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15z"/><path d="M10 21h4"/>',
    moon: '<path class="f" d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z"/>',
    search: '<circle cx="11" cy="11" r="6"/><path d="M16 16l4 4"/>',
    undo: '<path d="M9 7L4 12l5 5"/><path d="M4 12h10a5 5 0 0 1 0 10h-2"/>',
    info: '<circle class="f" cx="12" cy="12" r="8.5"/><path d="M12 11v5M12 8v.01"/>',
    dots: '<circle class="f" cx="12" cy="5" r="1.7"/><circle class="f" cx="12" cy="12" r="1.7"/><circle class="f" cx="12" cy="19" r="1.7"/>',
    sparkle: '<path class="f" d="M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z"/>',
    list: '<path d="M4 6h16M4 12h16M4 18h10"/>',
    eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle class="f" cx="12" cy="12" r="2.8"/>',
    target: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle class="f" cx="12" cy="12" r="1"/>',
    moveto: '<path d="M5 12h12M13 6l6 6-6 6"/>',
    lock: '<rect class="f" x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>'
  };
  M.icons = I;
  if (typeof module !== 'undefined') module.exports = I;
})(globalThis.M = globalThis.M || {});
