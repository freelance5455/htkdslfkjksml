/* أدوات التاريخ: كل التواريخ نصوص بصيغة YYYY-MM-DD بالتوقيت المحلي */
(function (M) {
  'use strict';
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function fmt(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function parse(s) { var p = s.split('-'); return new Date(+p[0], +p[1] - 1, +p[2], 12, 0, 0); }
  function valid(s) { return typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && fmt(parse(s)) === s; }
  var D = {
    DAYS: ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'],
    DAYS_SHORT: ['أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'],
    MONTHS: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
    pad: pad, fmt: fmt, parse: parse, valid: valid,
    today: function () { return fmt(new Date()); },
    addDays: function (s, n) { var d = parse(s); d.setDate(d.getDate() + n); return fmt(d); },
    diff: function (a, b) { return Math.round((parse(a) - parse(b)) / 86400000); }, // a - b بالأيام
    dow: function (s) { return parse(s).getDay(); },
    cmp: function (a, b) { return a < b ? -1 : a > b ? 1 : 0; },
    monthKey: function (s) { return s.slice(0, 7); },
    daysInMonth: function (y, m) { return new Date(y, m + 1, 0).getDate(); },
    long: function (s) { var d = parse(s); return D.DAYS[d.getDay()] + ' ' + M.quran.num(d.getDate()) + ' ' + D.MONTHS[d.getMonth()]; },
    medium: function (s) { var d = parse(s); return M.quran.num(d.getDate()) + ' ' + D.MONTHS[d.getMonth()] + ' ' + M.quran.num(d.getFullYear()); },
    hijri: function (s) {
      try { return new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', { day: 'numeric', month: 'long', year: 'numeric' }).format(parse(s)); }
      catch (e) { return ''; }
    },
    /** وصف نسبي: اليوم/غدًا/أمس/بعد ٣ أيام */
    rel: function (s, today) {
      var n = D.diff(s, today), q = M.quran.num;
      if (n === 0) return 'اليوم'; if (n === 1) return 'غدًا'; if (n === -1) return 'أمس';
      if (n === 2) return 'بعد يومين'; if (n > 2 && n <= 10) return 'بعد ' + q(n) + ' أيام';
      if (n < 0 && n >= -10) return 'منذ ' + (n === -2 ? 'يومين' : q(-n) + ' أيام');
      return D.long(s);
    },
    /** بداية الأسبوع (weekStart: 0=الأحد..6=السبت) */
    weekStartOf: function (s, weekStart) { var d = D.dow(s); return D.addDays(s, -((d - weekStart + 7) % 7)); }
  };
  M.dates = D;
  if (typeof module !== 'undefined') module.exports = D;
})(globalThis.M = globalThis.M || {});
