/* بيانات القرآن: 114 سورة بالترتيب المصحفي (رواية حفص) مع أعداد الآيات */
(function (M) {
  'use strict';
  var RAW = 'الفاتحة:7|البقرة:286|آل عمران:200|النساء:176|المائدة:120|الأنعام:165|الأعراف:206|الأنفال:75|التوبة:129|يونس:109|' +
    'هود:123|يوسف:111|الرعد:43|إبراهيم:52|الحجر:99|النحل:128|الإسراء:111|الكهف:110|مريم:98|طه:135|' +
    'الأنبياء:112|الحج:78|المؤمنون:118|النور:64|الفرقان:77|الشعراء:227|النمل:93|القصص:88|العنكبوت:69|الروم:60|' +
    'لقمان:34|السجدة:30|الأحزاب:73|سبأ:54|فاطر:45|يس:83|الصافات:182|ص:88|الزمر:75|غافر:85|' +
    'فصلت:54|الشورى:53|الزخرف:89|الدخان:59|الجاثية:37|الأحقاف:35|محمد:38|الفتح:29|الحجرات:18|ق:45|' +
    'الذاريات:60|الطور:49|النجم:62|القمر:55|الرحمن:78|الواقعة:96|الحديد:29|المجادلة:22|الحشر:24|الممتحنة:13|' +
    'الصف:14|الجمعة:11|المنافقون:11|التغابن:18|الطلاق:12|التحريم:12|الملك:30|القلم:52|الحاقة:52|المعارج:44|' +
    'نوح:28|الجن:28|المزمل:20|المدثر:56|القيامة:40|الإنسان:31|المرسلات:50|النبأ:40|النازعات:46|عبس:42|' +
    'التكوير:29|الانفطار:19|المطففين:36|الانشقاق:25|البروج:22|الطارق:17|الأعلى:19|الغاشية:26|الفجر:30|البلد:20|' +
    'الشمس:15|الليل:21|الضحى:11|الشرح:8|التين:8|العلق:19|القدر:5|البينة:8|الزلزلة:8|العاديات:11|' +
    'القارعة:11|التكاثر:8|العصر:3|الهمزة:9|الفيل:5|قريش:4|الماعون:7|الكوثر:3|الكافرون:6|النصر:3|' +
    'المسد:5|الإخلاص:4|الفلق:5|الناس:6';

  var SURAHS = [null]; // الفهرس يبدأ من 1
  var OFFSET = [0, 0];  // OFFSET[s] = عدد الآيات قبل السورة s
  RAW.split('|').forEach(function (p, i) {
    var x = p.split(':');
    SURAHS.push({ n: i + 1, name: x[0], ayat: parseInt(x[1], 10) });
  });
  for (var s = 1; s <= 114; s++) OFFSET[s + 1] = OFFSET[s] + SURAHS[s].ayat;
  var TOTAL = OFFSET[115];

  var Q = {
    SURAHS: SURAHS,
    TOTAL_AYAT: TOTAL,
    TOTAL_SURAHS: 114,
    name: function (s) { return SURAHS[s].name; },
    count: function (s) { return SURAHS[s].ayat; },
    /** فهرس عام للآية (1..6236) */
    toIdx: function (s, a) { return OFFSET[s] + a; },
    fromIdx: function (i) {
      var lo = 1, hi = 114;
      while (lo < hi) { var mid = (lo + hi + 1) >> 1; if (OFFSET[mid] < i) lo = mid; else hi = mid - 1; }
      return { s: lo, a: i - OFFSET[lo] };
    },
    /** تقسيم مجال عام إلى مقاطع حسب السور */
    segments: function (i1, i2) {
      var out = [], i = i1;
      while (i <= i2) {
        var p = Q.fromIdx(i), last = Math.min(i2, OFFSET[p.s] + SURAHS[p.s].ayat);
        out.push({ s: p.s, from: p.a, to: last - OFFSET[p.s] });
        i = last + 1;
      }
      return out;
    },
    /** وصف نصي لمقطع */
    segText: function (g) {
      var n = SURAHS[g.s];
      if (g.from === 1 && g.to === n.ayat) return 'سورة ' + n.name + ' كاملة';
      return n.name + ' (' + Q.num(g.from) + (g.to !== g.from ? '–' + Q.num(g.to) : '') + ')';
    },
    segsText: function (segs) { return segs.map(Q.segText).join('، '); },
    /** وحدات الحفظ التقريبية: الصفحة ≈ 6236/604 آية */
    UNITS: { ayat: 1, page: 10, half: 5, quarter: 3 },
    unitAyat: function (unit, value) {
      if (unit === 'ayat' || unit === 'custom') return Math.max(1, Math.round(value));
      return Math.max(1, Math.round(Q.UNITS[unit] * (value || 1)));
    },
    num: function (n) { return String(n).replace(/\d/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'[d]; }); }
  };
  M.quran = Q;
  if (typeof module !== 'undefined') module.exports = Q;
})(globalThis.M = globalThis.M || {});
