/* الحالة والتخزين المحلي (localStorage) مع نسخة احتياطية تلقائية والتحقق من البيانات */
(function (M) {
  'use strict';
  var Q = M.quran, D = M.dates, R = M.ranges;
  var KEY = 'midad.data', BAK = 'midad.data.bak', PRE = 'midad.data.preimport';
  var SCHEMA = 1;

  /* ---- طبقة تخزين آمنة (تعود للذاكرة إذا تعذّر localStorage) ---- */
  var mem = {}, usable = true;
  try { localStorage.setItem('midad.t', '1'); localStorage.removeItem('midad.t'); } catch (e) { usable = false; }
  var S = {
    persistent: function () { return usable; },
    get: function (k) { try { return usable ? localStorage.getItem(k) : (mem[k] || null); } catch (e) { return mem[k] || null; } },
    set: function (k, v) { try { if (usable) localStorage.setItem(k, v); else mem[k] = v; return true; } catch (e) { mem[k] = v; return false; } },
    del: function (k) { try { if (usable) localStorage.removeItem(k); } catch (e) {} delete mem[k]; }
  };

  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }

  function defaultSettings() {
    return {
      theme: 'garden', mode: 'auto',
      colors: { primary: '', secondary: '', bg: '', accent: '' },
      fontScale: 1, fontStyle: 'theme', radius: -1, navStyle: 'classic', iconStyle: 'line', deco: true,
      favorites: [],
      reminders: { enabled: false, time: '20:00', mem: true, rev: true, lastShown: '' },
      memorize: { confirmAhead: true },
      review: { intervals: [1, 3, 7, 14, 30], dailyCap: 10, reviewOnRest: true },
      weekStart: 6, onboarded: false
    };
  }
  function defaultState() {
    return { schema: SCHEMA, createdAt: Date.now(), settings: defaultSettings(), plans: [], activePlanId: null, progress: {}, reviews: [], activity: [] };
  }

  /* ---- التحقق والتطبيع (يُستخدم للتحميل والاستيراد) ---- */
  var isObj = function (x) { return x && typeof x === 'object' && !Array.isArray(x); };
  var isInt = function (x, a, b) { return typeof x === 'number' && isFinite(x) && Math.floor(x) === x && x >= a && x <= b; };
  var HEX = /^#[0-9a-fA-F]{6}$/;
  function pick(v, list, def) { return list.indexOf(v) >= 0 ? v : def; }

  function normSettings(raw, warn) {
    var d = defaultSettings(); if (!isObj(raw)) return d;
    var s = d;
    if (typeof raw.theme === 'string' && raw.theme.length < 40) s.theme = raw.theme;
    s.mode = pick(raw.mode, ['auto', 'light', 'dark'], 'auto');
    if (isObj(raw.colors)) ['primary', 'secondary', 'bg', 'accent'].forEach(function (k) { if (HEX.test(raw.colors[k])) s.colors[k] = raw.colors[k]; });
    if (typeof raw.fontScale === 'number' && raw.fontScale >= 0.8 && raw.fontScale <= 1.5) s.fontScale = raw.fontScale;
    s.fontStyle = pick(raw.fontStyle, ['theme', 'naskh', 'sans', 'kufi', 'rounded'], 'theme');
    if (typeof raw.radius === 'number' && raw.radius >= -1 && raw.radius <= 40) s.radius = raw.radius;
    s.navStyle = pick(raw.navStyle, ['classic', 'floating', 'compact', 'icons'], 'classic');
    s.iconStyle = pick(raw.iconStyle, ['line', 'solid', 'soft'], 'line');
    s.deco = raw.deco !== false;
    if (Array.isArray(raw.favorites)) s.favorites = raw.favorites.filter(function (x) { return typeof x === 'string'; }).slice(0, 60);
    if (isObj(raw.reminders)) {
      var r = raw.reminders;
      s.reminders.enabled = r.enabled === true;
      if (/^\d{2}:\d{2}$/.test(r.time)) s.reminders.time = r.time;
      s.reminders.mem = r.mem !== false; s.reminders.rev = r.rev !== false;
      if (D.valid(r.lastShown)) s.reminders.lastShown = r.lastShown;
    }
    if (isObj(raw.memorize)) s.memorize.confirmAhead = raw.memorize.confirmAhead !== false;
    if (isObj(raw.review)) {
      var iv = raw.review.intervals;
      if (Array.isArray(iv) && iv.length >= 1 && iv.length <= 10 && iv.every(function (x) { return isInt(x, 1, 365); })) {
        s.review.intervals = iv.slice().sort(function (a, b) { return a - b; });
      } else if (iv !== undefined) warn.push('فواصل المراجعة غير صالحة، استُخدمت الافتراضية');
      if (isInt(raw.review.dailyCap, 0, 200)) s.review.dailyCap = raw.review.dailyCap;
      s.review.reviewOnRest = raw.review.reviewOnRest !== false;
    }
    if (isInt(raw.weekStart, 0, 6)) s.weekStart = raw.weekStart;
    s.onboarded = raw.onboarded === true;
    return s;
  }

  function normDays(days) {
    var out = {}, mems = 0;
    for (var i = 0; i < 7; i++) { var v = days && days[i]; out[i] = pick(v, ['mem', 'rest', 'opt'], 'rest'); if (out[i] === 'mem') mems++; }
    return mems ? out : null;
  }

  function normPlan(p, warn) {
    if (!isObj(p) || typeof p.id !== 'string') return null;
    if (!(isInt(p.startS, 1, 114) && isInt(p.endS, 1, 114))) return null;
    if (!isInt(p.startA, 1, Q.count(p.startS)) || !isInt(p.endA, 1, Q.count(p.endS))) return null;
    var i1 = Q.toIdx(p.startS, p.startA), i2 = Q.toIdx(p.endS, p.endA);
    if (i1 > i2) return null;
    var unit = pick(p.unit, ['ayat', 'page', 'half', 'quarter', 'custom'], 'ayat');
    var value = typeof p.value === 'number' && p.value > 0 && p.value <= 604 ? p.value : 5;
    var cfg = [];
    (Array.isArray(p.cfg) ? p.cfg : []).forEach(function (c) { var dd = isObj(c) && D.valid(c.from) && normDays(c.days); if (dd) cfg.push({ from: c.from, days: dd }); });
    if (!cfg.length) return null;
    var startDate = D.valid(p.startDate) ? p.startDate : cfg[0].from;
    var plan = {
      id: p.id, name: String(p.name || 'خطتي').slice(0, 60),
      startS: p.startS, startA: p.startA, endS: p.endS, endA: p.endA, unit: unit, value: value,
      status: pick(p.status, ['active', 'paused', 'ended', 'done'], 'active'),
      cursor: isInt(p.cursor, i1, i2 + 1) ? p.cursor : i1,
      startDate: startDate, notBefore: D.valid(p.notBefore) ? p.notBefore : startDate,
      forcedDate: D.valid(p.forcedDate) ? p.forcedDate : null,
      endDate: D.valid(p.endDate) ? p.endDate : null,
      cfg: cfg, pauses: [], createdAt: typeof p.createdAt === 'number' ? p.createdAt : Date.now()
    };
    (Array.isArray(p.pauses) ? p.pauses : []).forEach(function (x) { if (isObj(x) && D.valid(x.from) && (x.to == null || D.valid(x.to))) plan.pauses.push({ from: x.from, to: x.to || null }); });
    return plan;
  }

  function normProgress(raw, warn) {
    var out = {}; if (!isObj(raw)) return out;
    for (var s = 1; s <= 114; s++) {
      var p = raw[s]; if (!isObj(p)) continue;
      var rs = [];
      (Array.isArray(p.ranges) ? p.ranges : []).forEach(function (x) {
        if (Array.isArray(x) && isInt(x[0], 1, Q.count(s)) && isInt(x[1], 1, Q.count(s)) && x[0] <= x[1]) rs.push([x[0], x[1]]);
        else warn.push('مجال غير صالح في السورة ' + Q.name(s) + ' تم تجاهله');
      });
      rs = R.normalize(rs);
      var e = { ranges: rs, review: p.review === true, started: p.started === true };
      if (rs.length || e.review || e.started) out[s] = e;
    }
    return out;
  }

  function normSegs(a) {
    if (!Array.isArray(a)) return null; var out = [];
    for (var i = 0; i < a.length; i++) { var g = a[i]; if (!isObj(g) || !isInt(g.s, 1, 114) || !isInt(g.from, 1, Q.count(g.s)) || !isInt(g.to, 1, Q.count(g.s)) || g.from > g.to) return null; out.push({ s: g.s, from: g.from, to: g.to }); }
    return out;
  }

  function normReview(r, intervalsLen) {
    if (!isObj(r) || typeof r.id !== 'string' || !isInt(r.s, 1, 114)) return null;
    if (!isInt(r.from, 1, Q.count(r.s)) || !isInt(r.to, 1, Q.count(r.s)) || r.from > r.to || !D.valid(r.due)) return null;
    var rev = {
      id: r.id, s: r.s, from: r.from, to: r.to, due: r.due,
      stage: isInt(r.stage, 0, 20) ? r.stage : 0, status: pick(r.status, ['pending', 'retired'], 'pending'),
      created: D.valid(r.created) ? r.created : r.due, src: pick(r.src, ['plan', 'manual', 'flag'], 'manual'),
      srcLog: typeof r.srcLog === 'string' ? r.srcLog : null,
      lastRating: pick(r.lastRating, ['excellent', 'good', 'needs', 'weak'], null), history: []
    };
    (Array.isArray(r.history) ? r.history : []).forEach(function (h) {
      if (isObj(h) && D.valid(h.date) && ['excellent', 'good', 'needs', 'weak', 'retire'].indexOf(h.rating) >= 0)
        rev.history.push({ date: h.date, rating: h.rating, stageBefore: isInt(h.stageBefore, 0, 20) ? h.stageBefore : 0, dueBefore: D.valid(h.dueBefore) ? h.dueBefore : h.date });
    });
    return rev;
  }

  function normActivity(a) {
    if (!isObj(a) || typeof a.id !== 'string' || !D.valid(a.date)) return null;
    var type = pick(a.type, ['mem', 'rev', 'opt', 'manual'], null); if (!type) return null;
    var e = { id: a.id, type: type, date: a.date, ts: typeof a.ts === 'number' ? a.ts : 0, ayahs: isInt(a.ayahs, -7000, 7000) ? a.ayahs : 0 };
    if (type === 'mem') {
      var segs = normSegs(a.segments); if (!segs || !segs.length || typeof a.planId !== 'string' || !D.valid(a.forDate)) return null;
      e.planId = a.planId; e.forDate = a.forDate; e.segments = segs; e.i1 = a.i1; e.i2 = a.i2;
      e.added = {}; if (isObj(a.added)) for (var s in a.added) if (isInt(+s, 1, 114) && Array.isArray(a.added[s])) e.added[s] = R.normalize(a.added[s].filter(function (x) { return Array.isArray(x) && isInt(x[0], 1, Q.count(+s)) && isInt(x[1], 1, Q.count(+s)); }));
      e.reviewIds = Array.isArray(a.reviewIds) ? a.reviewIds.filter(function (x) { return typeof x === 'string'; }) : [];
      e.key = typeof a.key === 'string' ? a.key : a.planId + '|' + a.forDate + '|' + a.i1 + '-' + a.i2;
    } else if (type === 'rev') {
      if (!isInt(a.s, 1, 114)) return null; e.s = a.s; e.from = a.from; e.to = a.to; e.rating = pick(a.rating, ['excellent', 'good', 'needs', 'weak', 'retire'], 'good'); e.reviewId = a.reviewId || null;
    } else if (type === 'manual') {
      if (!isInt(a.s, 1, 114)) return null; e.s = a.s; e.note = typeof a.note === 'string' ? a.note.slice(0, 80) : '';
    } else if (type === 'opt') { e.segments = normSegs(a.segments) || []; }
    return e;
  }

  /** يطبّع كائن حالة خامًا. يعيد {state, errors, warnings}. */
  function normalize(raw) {
    var errors = [], warn = [];
    if (!isObj(raw)) return { state: null, errors: ['الملف لا يحتوي على بيانات صالحة'], warnings: warn };
    if (raw.schema !== undefined && (!isInt(raw.schema, 1, 1000) || raw.schema > SCHEMA)) errors.push('إصدار النسخة الاحتياطية أحدث من إصدار التطبيق');
    if (raw.progress !== undefined && !isObj(raw.progress)) errors.push('بيانات التقدم تالفة');
    if (raw.plans !== undefined && !Array.isArray(raw.plans)) errors.push('بيانات الخطط تالفة');
    if (raw.reviews !== undefined && !Array.isArray(raw.reviews)) errors.push('بيانات المراجعة تالفة');
    if (raw.activity !== undefined && !Array.isArray(raw.activity)) errors.push('سجل النشاط تالف');
    if (raw.progress === undefined && raw.plans === undefined && raw.settings === undefined) errors.push('الملف لا يبدو نسخة احتياطية من مِداد');
    if (errors.length) return { state: null, errors: errors, warnings: warn };

    var st = defaultState();
    st.createdAt = typeof raw.createdAt === 'number' ? raw.createdAt : st.createdAt;
    st.settings = normSettings(raw.settings, warn);
    var seenP = {}, dropped = 0;
    (raw.plans || []).forEach(function (p) { var n = normPlan(p, warn); if (n && !seenP[n.id]) { seenP[n.id] = 1; st.plans.push(n); } else dropped++; });
    if (dropped) warn.push('تم تجاهل ' + dropped + ' خطة غير صالحة');
    st.activePlanId = st.plans.some(function (p) { return p.id === raw.activePlanId; }) ? raw.activePlanId : null;
    st.progress = normProgress(raw.progress, warn);
    var seenR = {}; dropped = 0;
    (raw.reviews || []).forEach(function (r) { var n = normReview(r); if (n && !seenR[n.id]) { seenR[n.id] = 1; st.reviews.push(n); } else dropped++; });
    if (dropped) warn.push('تم تجاهل ' + dropped + ' عنصر مراجعة غير صالح');
    var seenA = {}, seenK = {}; dropped = 0;
    (raw.activity || []).forEach(function (a) {
      var n = normActivity(a);
      if (n && !seenA[n.id] && !(n.type === 'mem' && seenK[n.key])) { seenA[n.id] = 1; if (n.type === 'mem') seenK[n.key] = 1; st.activity.push(n); } else dropped++;
    });
    if (dropped) warn.push('تم تجاهل ' + dropped + ' سجل نشاط مكرر أو غير صالح');
    return { state: st, errors: [], warnings: warn };
  }

  /* ---- الحالة الحية ---- */
  var listeners = [], state = defaultState(), loadInfo = { fresh: true, recovered: false, persistent: usable };

  var Store = {
    KEY: KEY, SCHEMA: SCHEMA, uid: uid, defaultState: defaultState, defaultSettings: defaultSettings, normalize: normalize, storage: S,
    get state() { return state; },
    info: loadInfo,
    load: function () {
      var raw = S.get(KEY), res = null;
      if (raw) {
        try { res = normalize(JSON.parse(raw)); } catch (e) { res = null; }
        if (res && res.state) { state = res.state; loadInfo.fresh = false; }
        else {
          var b = S.get(BAK);
          if (b) { try { res = normalize(JSON.parse(b)); if (res.state) { state = res.state; loadInfo.recovered = true; loadInfo.fresh = false; } } catch (e) {} }
          if (!loadInfo.recovered) { S.set(KEY + '.corrupt', raw); loadInfo.corrupt = true; }
        }
      }
      if (!loadInfo.fresh) S.set(BAK, JSON.stringify(state));
      return state;
    },
    save: function () {
      var ok = S.set(KEY, JSON.stringify(state));
      if (!ok && !Store.saveFailed) { Store.saveFailed = true; M.ui && M.ui.toast && M.ui.toast('تعذّر حفظ البيانات: المساحة ممتلئة. صدّر نسخة احتياطية الآن.', 'error'); }
      return ok;
    },
    commit: function () { Store.save(); listeners.slice().forEach(function (fn) { try { fn(state); } catch (e) { console.error(e); } }); },
    on: function (fn) { listeners.push(fn); },
    /** استبدال الحالة بالكامل (استيراد/إعادة ضبط) مع حفظ لقطة للتراجع */
    replace: function (newState, keepSnapshot) {
      if (keepSnapshot !== false) S.set(PRE, JSON.stringify(state));
      state = newState; Store.commit();
    },
    hasSnapshot: function () { return !!S.get(PRE); },
    restoreSnapshot: function () {
      var raw = S.get(PRE); if (!raw) return false;
      try { var r = normalize(JSON.parse(raw)); if (!r.state) return false; Store.replace(r.state, false); S.del(PRE); return true; } catch (e) { return false; }
    },
    wipe: function () { S.del(KEY); S.del(BAK); S.del(PRE); state = defaultState(); loadInfo.fresh = true; Store.commit(); }
  };
  M.store = Store;
  if (typeof module !== 'undefined') module.exports = Store;
})(globalThis.M = globalThis.M || {});
