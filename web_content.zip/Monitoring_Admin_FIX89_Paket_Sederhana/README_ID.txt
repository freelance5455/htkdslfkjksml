Paket pembaruan UI aplikasi Admin FIX89

Berkas app/src/main/assets/index.html adalah halaman web admin dengan tombol ☰ Menu yang tetap menempel di pojok kanan atas pada layar HP saat konten digulir. Pada desktop sidebar tetap sticky. Memilih menu menutup panel navigasi di HP, tombol tetap tersedia.

Untuk memperbarui proyek Android WebView sebelumnya, ganti assets/index.html dengan berkas ini lalu build ulang proyek. Ini bukan APK siap instal. Pertahankan salinan proyek dan uji login/Firebase sebelum digunakan.
