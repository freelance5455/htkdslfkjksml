JS CONSTRUÇÕES — PROTÓTIPO OFFLINE

O que contém:
- Cadastro local de clientes e obras
- Registro de diárias
- Registro de materiais e indicação de quem pagou
- Entradas e despesas
- Cálculo de orçamento com impressão/salvar em PDF
- Exportar/importar backup JSON
- Identidade visual azul e cinza

IMPORTANTE:
- Este é um protótipo web funcional para testar no navegador; ainda não é APK.
- Os dados ficam no armazenamento local do navegador/aparelho. Não há login, nuvem, sincronização entre dispositivos ou criptografia personalizada.
- Faça backups frequentes. Não use para guardar dados altamente sensíveis.
- A tela de PDF usa a impressão do Android: escolher "Salvar como PDF".
- O cálculo do orçamento aplica a margem sobre a soma dos custos. Revise antes de enviar ao cliente.
- Registros de diárias não substituem folha de pagamento, recibos formais ou obrigações trabalhistas.
- Consulte contador para enquadramento MEI e obrigações tributárias.

TESTAR:
1. Extraia o ZIP.
2. Abra index.html num navegador compatível ou hospede os arquivos em HTTPS para instalar como PWA.
3. Para experiência offline confiável, hospede primeiro em HTTPS e instale pelo menu do navegador. O service worker não funciona normalmente ao abrir o arquivo diretamente.

COMO VIRAR APK:
Opção recomendada: Capacitor (exige computador com Node.js LTS, Android Studio e Android SDK).
1. Crie projeto Vite: npm create vite@latest js-construcoes -- --template vanilla
2. Copie index.html para a pasta de build conforme o projeto, ou adapte este protótipo para src.
3. Instale: npm install @capacitor/core @capacitor/cli
4. Configure: npx cap init "JS Construções" "br.com.jsconstrucoes.app"
5. Configure webDir como "dist" no capacitor.config.* e coloque os arquivos web na pasta public ou adapte para o build do Vite.
6. Execute: npm run build
7. Adicione Android: npm install @capacitor/android && npx cap add android
8. Sincronize: npx cap sync android
9. Abra: npx cap open android
10. No Android Studio, teste em aparelho/emulador e use Build > Build Bundle(s) / APK(s) > Build APK(s).
11. Antes de distribuir, configure ícone, nome, permissões, assinatura e teste backup/recuperação. Para publicar na Play Store, siga as exigências atuais de assinatura e formato AAB.

Para produção, recomenda-se melhorar a geração de PDF, validar dados, adicionar edição de registros, confirmação de exclusões, relatórios mensais, autenticação e cópia de segurança protegida.
