import express from "express";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = process.env.PORT || 3000;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-3.8-flash";

app.use(express.json({ limit: "20mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/chat", async (req, res) => {
  try {
    if (!GEMINI_API_KEY) {
      return res.status(500).json({ error: "Falta GEMINI_API_KEY en el archivo .env del servidor." });
    }

    const messages = Array.isArray(req.body.messages) ? req.body.messages : [];
    const mode = req.body.mode || "Normal";

    const contents = messages.map(m => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: String(m.content || "") }]
    }));

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": GEMINI_API_KEY
        },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{
              text: `Eres GPTSHARK, un asistente de IA creado por Sharky.
Tu identidad visual es un tiburón azul. Responde en español cuando el usuario escriba en español.
Sé útil, claro y directo. Modo actual: ${mode}.`
            }]
          },
          contents,
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 2048
          }
        })
      }
    );

    const data = await response.json();

    if (!response.ok) {
      console.error("Gemini error:", data);
      return res.status(response.status).json({
        error: data?.error?.message || "Gemini rechazó la solicitud."
      });
    }

    const text = data?.candidates?.[0]?.content?.parts
      ?.map(p => p.text || "")
      .join("") || "No recibí una respuesta de Gemini.";

    res.json({ text });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Error de conexión con el servicio de IA." });
  }
});

app.get("/api/status", (_req, res) => {
  res.json({
    app: "GPTSHARK",
    creator: "Sharky",
    provider: "Gemini",
    model: GEMINI_MODEL,
    configured: Boolean(GEMINI_API_KEY)
  });
});

app.listen(port, () => {
  console.log(`GPTSHARK listo en http://localhost:${port}`);
});
