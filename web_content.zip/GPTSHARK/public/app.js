const $=s=>document.querySelector(s);
const chat=$("#chat"), welcome=$("#welcome"), input=$("#input"), send=$("#send"), mode=$("#mode");
let messages=[], busy=false, selectedFile=null;

function addMessage(role,text){
  welcome.style.display="none"; chat.style.display="block";
  const row=document.createElement("div"); row.className=`msg ${role}`;
  const bubble=document.createElement("div"); bubble.className="bubble"; bubble.textContent=text;
  row.appendChild(bubble); chat.appendChild(row); chat.scrollTop=chat.scrollHeight;
}
function reset(){
  messages=[]; chat.innerHTML=""; chat.style.display="none"; welcome.style.display="block";
  $("#history").textContent="Sin conversaciones todavía";
}
async function ask(text){
  text=text.trim(); if(!text||busy)return;
  busy=true; send.disabled=true; input.value="";
  addMessage("user",text); messages.push({role:"user",content:text});
  addMessage("assistant","GPTSHARK está pensando…");
  const pending=chat.lastElementChild;
  try{
    const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({messages,mode:mode.value})});
    const data=await r.json();
    if(!r.ok) throw new Error(data.error||"Error");
    pending.querySelector(".bubble").textContent=data.text;
    messages.push({role:"assistant",content:data.text});
    $("#history").textContent="Chat actual";
  }catch(e){pending.querySelector(".bubble").textContent="⚠️ "+e.message}
  finally{busy=false;send.disabled=false;input.focus()}
}
send.onclick=()=>ask(input.value);
input.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();ask(input.value)}});
$("#menuBtn").onclick=()=>$("#sidebar").classList.toggle("open");
$("#newChat").onclick=reset;
document.querySelectorAll(".mode").forEach(b=>b.onclick=()=>{
  document.querySelectorAll(".mode").forEach(x=>x.classList.remove("active"));b.classList.add("active");mode.value=b.dataset.mode;
});
document.querySelectorAll(".chips button").forEach(b=>b.onclick=()=>ask(b.dataset.prompt));
$("#attach").onclick=()=>$("#file").click();
$("#file").onchange=()=>{
  const f=$("#file").files[0]; if(!f) return;
  selectedFile=f;
  const box=$("#attachmentPreview"); box.innerHTML="";
  const item=document.createElement("div"); item.className="attachment";
  if(f.type.startsWith("image/")){
    const img=document.createElement("img"); img.src=URL.createObjectURL(f); item.appendChild(img);
  } else {
    const icon=document.createElement("span"); icon.textContent="📄"; icon.style.fontSize="22px"; item.appendChild(icon);
  }
  const name=document.createElement("span"); name.textContent=f.name; item.appendChild(name);
  const rm=document.createElement("button"); rm.className="remove-file"; rm.textContent="✕";
  rm.onclick=()=>{selectedFile=null;$("#file").value="";box.innerHTML=""};
  item.appendChild(rm); box.appendChild(item);
  $("#status").textContent=f.type.startsWith("image/") ? "Imagen lista para analizar." : "Archivo listo para enviar.";
};
$("#mic").onclick=()=>{
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){$("#status").textContent="El reconocimiento de voz no está disponible en este navegador.";return}
  const r=new SR();r.lang="es-ES";r.onresult=e=>{input.value=e.results[0][0].transcript};r.start();
};

window.addEventListener("load",()=>setTimeout(()=>document.getElementById("splash").classList.add("hide"),1800));

$("#speak").onclick=()=>{
  const bubbles=[...document.querySelectorAll(".assistant .bubble")];
  const last=bubbles[bubbles.length-1];
  if(!last || !("speechSynthesis" in window)){ $("#status").textContent="La lectura de voz no está disponible."; return; }
  speechSynthesis.cancel();
  const u=new SpeechSynthesisUtterance(last.textContent);
  u.lang="es-VE"; speechSynthesis.speak(u);
};

async function checkGPTShark(){
  try{
    const r=await fetch("/api/status");
    const d=await r.json();
    if(!d.configured) $("#status").textContent="GPTSHARK está instalado, pero falta configurar la clave de IA en el servidor.";
  }catch(_){}
}
checkGPTShark();
