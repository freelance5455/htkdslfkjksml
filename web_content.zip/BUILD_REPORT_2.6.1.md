# Build report — Anonymoux Studios 2.6.1

- Theme: charcoal / white / neon green, subtle grain, low-intensity ambient light, Space Grotesk + Inter.
- Database: PDO SQLite only; `storage/workspace.sqlite`.
- Existing account, provider, wallet, and workspace data paths are preserved.
- PHP cURL and PDO SQLite are unavailable in the build container. Live provider calls and live PDO SQLite runtime checks are NOT TESTED.
- Run the included source and regression tests before deployment; back up `storage/` and `config.local.php` before replacing application files.
