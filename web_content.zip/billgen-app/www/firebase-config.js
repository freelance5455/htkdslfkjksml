// Fill this in with YOUR Firebase project's config (see README.md, Step 1).
// Firebase console → Project settings → General → "Your apps" → SDK setup and configuration.
// Until this is filled in, the app runs in local-only mode (no cross-device sync).
window.FIREBASE_CONFIG = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
