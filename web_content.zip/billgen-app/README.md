# BillGen — native app project

This turns the Bill Generator web app into a real installable app for
Android (Play Store) and iOS (App Store), using **Capacitor** (wraps
the web app in a native shell) and **Firebase** (real cross-device
cloud sync, replacing the Claude-only sync from the artifact version).

I can't run the actual builds or submit to the stores for you — that
needs your own developer accounts, a Mac (for iOS), and signing keys
only you should hold. Everything below is the exact path to get there.

---

## 0. What you need before starting

- **Node.js** 18+ and npm (you likely have these already)
- **Android Studio** (free) — for the Android build
- **A Mac with Xcode** (free, Mac required) — for the iOS build
- **A Google Play Developer account** — $25 one-time
- **An Apple Developer Program account** — $99/year
- **A Firebase account** (free) — free tier is plenty for a single shop

---

## 1. Set up Firebase (real cloud sync)

1. Go to https://console.firebase.google.com → **Add project** → name it
   anything (e.g. "billgen").
2. **Build → Firestore Database → Create database** → start in
   **production mode** → pick a region near you.
3. **Build → Authentication → Get started → Sign-in method → Anonymous**
   → enable it. (The app signs each device in anonymously — no login
   screen needed — just to satisfy Firestore's security rules.)
4. **Project settings (gear icon) → General → Your apps → </> (Web)**
   → register an app (any nickname) → copy the `firebaseConfig` object
   it shows you.
5. Paste those values into `www/firebase-config.js` in this project,
   replacing the `YOUR_...` placeholders.
6. **Firestore Database → Rules** tab → replace the contents with what's
   in `firestore.rules` in this project → **Publish**.

Once this is done, every device running the app with this config will
share the same menu and bill history in real time — that's the
"staff/devices sync" feature.

---

## 2. Install dependencies & add the native platforms

```bash
cd billgen-app
npm install
npx cap add android
npx cap add ios
```

Every time you change anything in `www/`, re-sync it into the native
projects:

```bash
npx cap sync
```

---

## 3. Generate real app icons & splash screens

A starter icon and splash image are in `resources/`
(`icon-1024.png`, `splash.png`) — replace them with your own shop's
branding if you like, then run:

```bash
npx @capacitor/assets generate
```

This generates every required icon/splash size for both platforms
automatically.

---

## 4. Set your app identity

- In `capacitor.config.json`, change `"appId"` from
  `com.yourshop.billgen` to your own reverse-domain ID (must be
  globally unique on the app stores — e.g. `com.acmecafe.billgen`).
- Change `"appName"` if you want a different display name.
- Re-run `npx cap sync` after changing either.

---

## 5. Build & test on a device/emulator

**Android:**
```bash
npx cap open android
```
This opens Android Studio. Pick a device/emulator and hit Run ▶.

**iOS (Mac only):**
```bash
npx cap open ios
```
This opens Xcode. Pick a simulator or your connected iPhone and hit Run ▶.

---

## 6. Publish to the Play Store (Android)

1. In Android Studio: **Build → Generate Signed Bundle/APK** → choose
   **Android App Bundle** → create a new keystore (⚠️ back this up
   somewhere safe — losing it means you can never update the app again).
2. Go to https://play.google.com/console → create the app listing
   (title, description, screenshots, a privacy policy URL — required
   even for a simple app; a free one-page policy generator is fine
   since this app only stores shop data, not personal user data
   beyond an anonymous device ID).
3. Upload the signed `.aab` file under **Production → Create release**.
4. Fill in the content rating questionnaire and store listing, submit
   for review. Typical review time: a few hours to a couple of days.

---

## 7. Publish to the App Store (iOS)

1. In Xcode: set your **Team** (your Apple Developer account) under
   Signing & Capabilities.
2. **Product → Archive**, then use the Organizer window to
   **Distribute App → App Store Connect**.
3. Go to https://appstoreconnect.apple.com → create the app record
   (bundle ID must match `capacitor.config.json`'s `appId`), fill in
   the listing, screenshots, and privacy policy URL.
4. Select your uploaded build and submit for review. Apple's review
   is typically 1–3 days, and may reject a bare web-wrapper if it
   looks too thin — the POS-style functionality here (menu
   management, cart, PDF receipts, multi-device sync) is exactly the
   kind of real functionality that helps it read as a genuine app
   rather than "just a website."

---

## What changed from the Claude artifact version

- Cloud sync now runs on **your own Firebase project** instead of
  Claude's artifact-only `db` capability, so it works in a standalone
  app with no Claude viewer around.
- Staff name is entered once per device (stored locally) instead of
  being pulled from a Claude account, and is attached to each bill.
- Everything else — menu, categories, cart, tax toggle, PDF receipts,
  dark/light toggle, delete/edit — works the same as the web version.
