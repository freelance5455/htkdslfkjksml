Nishant Live Chats - Android project
=====================================
OPTION A (phone only, free): GitHub se cloud mein APK banao
 1. github.com par account banao -> New repository (naam: nishant-live-chats).
 2. "uploading an existing file" se is ZIP ke ANDAR ki saari files/folders upload karo
    (.github folder bhi - hidden folder hai, phone par Files app mein "show hidden" on karo).
 3. Repository -> Actions tab -> "Build APK" -> Run workflow.
 4. 5-8 minute baad run khulega -> neeche "Artifacts" -> NishantLiveChats-apk download karo.
 5. ZIP khol kar app-debug.apk install karo (Unknown sources allow karna hoga).

OPTION B (computer): Android Studio mein folder kholo -> Build > Build APK(s).

Note: ye debug APK hai. Play Store ke liye signed release build aur Play policy review chahiye.
App ka HTML: app/src/main/assets/index.html
