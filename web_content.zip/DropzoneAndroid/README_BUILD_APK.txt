DROPZONE 3D Android wrapper project

This wraps the current HTML game in a fullscreen Android WebView. The game
loads its 3D engine from an online CDN, so an internet connection is needed.

BUILD THE APK WITH ANDROID STUDIO:
1. Extract this ZIP on a computer with Android Studio installed.
2. Open the extracted DropzoneAndroid folder in Android Studio.
3. Let Gradle sync and install any SDK components it requests.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Click the APK link shown by Android Studio after the build completes.

This ZIP is an Android Studio project, not a compiled APK. This environment
has no Android SDK/Gradle build tools installed, so it cannot compile the APK
here. The game HTML is included at app/src/main/assets/index.html.
