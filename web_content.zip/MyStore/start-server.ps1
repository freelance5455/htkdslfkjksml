$ErrorActionPreference = 'Stop'
$root = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Any, 8000)
$listener.Start()
Write-Host "MyStore is available at http://localhost:8000/"
Write-Host 'Keep this window open while using the app. Press Ctrl+C to stop.'

try {
    while ($true) {
        $client = $listener.AcceptTcpClient()
        try {
            $stream = $client.GetStream()
            $reader = [System.IO.StreamReader]::new($stream, [System.Text.Encoding]::ASCII, $false, 1024, $true)
            $requestLine = $reader.ReadLine()
            while ($null -ne ($header = $reader.ReadLine()) -and $header.Length -gt 0) { }

            $parts = if ($requestLine) { $requestLine.Split(' ') } else { @() }
            $status = '200 OK'
            $file = $null
            if ($parts.Count -lt 2 -or $parts[0] -ne 'GET') {
                $status = '405 Method Not Allowed'
            } else {
                $urlPath = [Uri]::UnescapeDataString(($parts[1] -split '\?')[0]).TrimStart('/')
                if ([string]::IsNullOrWhiteSpace($urlPath)) { $urlPath = 'index.html' }
                $candidate = [IO.Path]::GetFullPath((Join-Path $root $urlPath))
                if (-not $candidate.StartsWith($root + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
                    $status = '404 Not Found'
                } else {
                    $file = Get-Item -LiteralPath $candidate
                }
            }

            if ($file) {
                $body = [IO.File]::ReadAllBytes($file.FullName)
                $type = switch ($file.Extension.ToLowerInvariant()) {
                    '.html' { 'text/html; charset=utf-8' }
                    '.js'   { 'text/javascript; charset=utf-8' }
                    '.css'  { 'text/css; charset=utf-8' }
                    '.json' { 'application/json; charset=utf-8' }
                    '.svg'  { 'image/svg+xml; charset=utf-8' }
                    '.mp4'  { 'video/mp4' }
                    '.wav'  { 'audio/wav' }
                    '.mp3'  { 'audio/mpeg' }
                    default { 'application/octet-stream' }
                }
            } else {
                $body = [Text.Encoding]::UTF8.GetBytes('Not found')
                $type = 'text/plain; charset=utf-8'
            }

            $headers = [Text.Encoding]::ASCII.GetBytes("HTTP/1.1 $status`r`nContent-Type: $type`r`nContent-Length: $($body.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n`r`n")
            $stream.Write($headers, 0, $headers.Length)
            $stream.Write($body, 0, $body.Length)
            $stream.Flush()
        } catch [System.IO.IOException] {
            # Browsers may cancel speculative or abandoned requests; keep serving.
        } catch [System.Net.Sockets.SocketException] {
            # Ignore a client that disconnected while its request was being read.
        } finally {
            $client.Close()
        }
    }
} finally {
    
    $listener.Stop()
}
