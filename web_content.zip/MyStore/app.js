/* متجري: تطبيق محلي يعمل دون خدمات خارجية */
const DB_NAME='mystore-local',DB_VERSION=3,STORE={products:'products',customers:'customers',invoices:'invoices',expenses:'expenses',settings:'settings',purchases:'purchases',files:'files'};
let db, page='home', cart=[], invoiceFilter='all', searchText='', toastTimer,checkoutBusy=false,secretTapCount=0,secretTapTimer;
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const money=n=>`${Number(n||0).toLocaleString('ar-PS',{minimumFractionDigits:2,maximumFractionDigits:2})} ₪`;
const dateFmt=v=>new Date(v).toLocaleDateString('ar-PS',{year:'numeric',month:'short',day:'numeric'});
const dateKey=value=>{const d=new Date(value);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`};const todayKey=()=>dateKey(new Date());
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function openDB(){return new Promise((resolve,reject)=>{const req=indexedDB.open(DB_NAME,DB_VERSION);req.onupgradeneeded=()=>{const d=req.result;for(const name of Object.values(STORE)){if(!d.objectStoreNames.contains(name)){const st=d.createObjectStore(name,{keyPath:name==='settings'?'key':'id',autoIncrement:name!=='settings'});if(name==='products'){st.createIndex('barcode','barcode',{unique:false});st.createIndex('name','name',{unique:false})}}}};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)})}
function tx(store,mode='readonly'){return db.transaction(store,mode).objectStore(store)}
function reqP(req){return new Promise((resolve,reject)=>{req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)})}
async function all(store){return reqP(tx(store).getAll())}async function get(store,id){return reqP(tx(store).get(id))}async function put(store,v){return reqP(tx(store,'readwrite').put(v))}async function add(store,v){return reqP(tx(store,'readwrite').add(v))}async function del(store,id){return reqP(tx(store,'readwrite').delete(id))}
async function setting(key,fallback=''){const x=await get('settings',key);return x?.value??fallback}async function setSetting(key,value){return put('settings',{key,value})}
function toast(s){const el=$('#toast');el.textContent=s;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2500)}
function setPage(next){page=next;searchText='';render()}
function nav(){const group=['customers','reports','expenses','settings','returns'].includes(page)?'more':page;$$('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.page===group));}
async function render(){nav();const shop=await setting('shopName','إدارة متجرك بسهولة');$('#shop-name').textContent=shop;const app=$('#app');app.innerHTML='<div class="empty"><b>◌</b>جارٍ التحميل…</div>';try{switch(page){case'home':app.innerHTML=await homeHTML();break;case'cashier':app.innerHTML=await cashierHTML();break;case'products':app.innerHTML=await productsHTML();break;case'invoices':app.innerHTML=await invoicesHTML();break;case'customers':app.innerHTML=await customersHTML();break;case'finance':case'reports':case'expenses':app.innerHTML=await financeHTML();break;case'returns':app.innerHTML=await returnsHTML();break;case'settings':app.innerHTML=await settingsHTML();break;case'more':app.innerHTML=moreHTML();break;}bindPage()}catch(e){console.error(e);app.innerHTML=`<div class="notice">تعذر تحميل البيانات: ${esc(e.message)}</div>`}}
function netTotal(i){return Math.max(0,i.total-(i.returns||[]).reduce((a,r)=>a+Number(r.refund||0),0))}function netPaid(i){return Math.min(netTotal(i),paidAmount(i))}
function dueAmount(i){return Math.max(0,netTotal(i)-paidAmount(i))}function profitBeforeReturns(i){return i.total-i.items.reduce((a,it)=>a+Number(it.cost||0)*it.qty,0)}function returnAdjustment(i,r){return -Number(r.refund||0)+Number(i.items[r.itemIndex]?.cost||0)*r.qty}
async function totals(){const invoices=await all('invoices'),products=await all('products'),expenses=await all('expenses');const today=invoices.filter(i=>dateKey(i.date)===todayKey()&&!i.voided),allActive=invoices.filter(i=>!i.voided);const todaysReturns=allActive.flatMap(i=>(i.returns||[]).filter(r=>dateKey(r.date)===todayKey()).map(r=>({invoice:i,return:r}))),refunds=todaysReturns.reduce((a,x)=>a+Number(x.return.refund||0),0),grossReceived=today.reduce((a,i)=>a+(i.payments||[]).filter(p=>dateKey(p.date)===todayKey()).reduce((x,p)=>x+p.amount,0),0),received=grossReceived-refunds;const sales=today.reduce((a,i)=>a+i.total,0)-refunds;const debt=allActive.reduce((a,i)=>a+dueAmount(i),0);const low=products.filter(p=>p.qty<=Number(p.lowAt??3));const cost=today.reduce((a,i)=>a+profitBeforeReturns(i),0)+todaysReturns.reduce((a,x)=>a+returnAdjustment(x.invoice,x.return),0);const exp=expenses.filter(e=>dateKey(e.date)===todayKey()).reduce((a,e)=>a+e.amount,0);return{invoices,products,expenses,today,received,refunds,sales,debt,low,cost,exp}}
async function homeHTML(){const t=await totals();return `<h1>أهلاً بك 👋</h1><p class="sub">ملخص متجرك اليوم</p><section class="hero"><div class="label">المبيعات اليوم</div><div class="amount">${money(t.sales)}</div><small>المقبوض ${money(t.received)}</small></section><div class="grid"><div class="stat"><div class="label">الفواتير اليوم</div><strong>${t.today.length}</strong><em>فاتورة</em></div><div class="stat"><div class="label">ديون مفتوحة</div><strong>${money(t.debt)}</strong><em>على الزبائن</em></div><div class="stat"><div class="label">المنتجات</div><strong>${t.products.length}</strong><em>صنف بالمخزون</em></div><div class="stat"><div class="label">مخزون منخفض</div><strong>${t.low.length}</strong><em>بحاجة للمتابعة</em></div></div><div class="section-head"><h2>إجراءات سريعة</h2></div><div class="quick-grid"><button class="quick" data-go="cashier"><b>＋</b>فاتورة جديدة</button><button class="quick" data-action="add-product"><b>▦</b>إضافة منتج</button><button class="quick" data-go="customers"><b>♙</b>الزبائن والديون</button><button class="quick" data-go="invoices"><b>▧</b>الفواتير</button></div>${t.low.length?`<div class="section-head"><h2>تنبيه المخزون</h2><button class="btn secondary small" data-go="products">عرض الكل</button></div><div class="list">${t.low.slice(0,3).map(p=>`<div class="list-item"><div class="avatar">▦</div><div class="grow"><div class="item-title">${esc(p.name)}</div><div class="muted">المتبقي ${p.qty}</div></div><span class="badge warn">${p.qty===0?'نفد':'منخفض'}</span></div>`).join('')}</div>`:''}`}
async function cashierHTML(){const products=await all('products');return `<h1>الكاشير</h1><p class="sub">ابحث عن الصنف أو امسح الباركود</p><div class="row"><div class="searchbox grow"><input id="cash-search" class="input" placeholder="اسم المنتج أو الباركود" value="${esc(searchText)}"></div><button class="btn secondary" data-action="scan">▣</button></div><div id="cash-results" class="list"></div><div class="section-head"><h2>سلة الفاتورة</h2><button class="btn secondary small" data-action="manual-item">＋ بند يدوي</button></div><label class="field"><span>اسم الزبون (اختياري)</span><input id="sale-customer" class="input" placeholder="اسم الزبون"></label><div class="list" id="cart-list">${cart.length?cart.map((it,i)=>`<div class="list-item"><div class="grow"><div class="item-title">${esc(it.name)}</div><div class="muted">${money(it.price)} للقطعة</div></div><div class="qty"><button data-cart="minus" data-i="${i}">−</button><b>${it.qty}</b><button data-cart="plus" data-i="${i}">+</button><button class="icon-button" data-cart="remove" data-i="${i}">×</button></div></div>`).join(''):'<div class="empty"><b>▤</b>السلة فارغة، أضف منتجات للبدء</div>'}</div><div class="total-bar"><div class="row between"><span>الإجمالي قبل الخصم</span><b>${money(cart.reduce((a,i)=>a+i.price*i.qty,0))}</b></div><label class="field" style="margin-top:12px"><span>الخصم (₪)</span><input id="sale-discount" class="input" type="number" min="0" step="0.1" value="0"></label><div class="row between"><b>الإجمالي</b><b id="sale-total">${money(Math.max(0,cart.reduce((a,i)=>a+i.price*i.qty,0)))}</b></div><button class="btn full" style="margin-top:13px" data-action="checkout" ${cart.length?'':'disabled'}>إتمام الفاتورة</button></div>`}
async function productsHTML(){const products=await all('products'),list=products.filter(p=>`${p.name} ${p.barcode||''}`.toLowerCase().includes(searchText.toLowerCase()));return `<div class="row between"><div><h1>المنتجات</h1><p class="sub">إدارة الأصناف والمخزون</p></div><button class="btn" data-action="add-product">＋ إضافة</button></div><div class="searchbox"><input id="product-search" class="input" placeholder="بحث بالاسم أو الباركود" value="${esc(searchText)}"></div><div class="list">${list.length?list.map(p=>`<div class="list-item"><div class="avatar">▦</div><div class="grow"><div class="item-title">${esc(p.name)}</div><div class="muted">${p.barcode?`باركود ${esc(p.barcode)} · `:''}الكمية ${p.qty}</div></div><div class="price">${money(p.price)}${p.qty<=Number(p.lowAt??3)?'<div class="badge warn">مخزون منخفض</div>':''}</div><button class="icon-button" data-action="edit-product" data-id="${p.id}">✎</button></div>`).join(''):'<div class="empty"><b>▦</b>لا توجد منتجات بعد</div>'}</div>`}
async function invoicesHTML(){let invoices=(await all('invoices')).sort((a,b)=>b.date.localeCompare(a.date));if(invoiceFilter!=='all')invoices=invoices.filter(i=>invoiceStatus(i)===invoiceFilter);return `<h1>الفواتير</h1><p class="sub">عرض المبيعات والمدفوعات</p><div class="tabs">${[['all','الكل'],['paid','مدفوعة'],['partial','جزئية'],['unpaid','غير مدفوعة']].map(([k,v])=>`<button class="tab ${invoiceFilter===k?'active':''}" data-filter="${k}">${v}</button>`).join('')}</div><div class="list">${invoices.length?invoices.map(i=>{const paid=paidAmount(i);return `<div class="card"><div class="row between"><div><div class="item-title">فاتورة #${i.id} ${i.customer?`· ${esc(i.customer)}`:''}</div><div class="muted">${dateFmt(i.date)} · ${i.items.length} بنود</div></div><span class="badge ${invoiceStatus(i)==='paid'?'':'warn'}">${statusName(invoiceStatus(i))}</span></div><hr class="divider"><div class="row between"><div class="muted">الإجمالي ${money(netTotal(i))} · مدفوع ${money(paid)}</div><div class="row"><button class="btn secondary small" data-action="view-invoice" data-id="${i.id}">عرض</button>${dueAmount(i)>0?`<button class="btn small" data-action="pay-invoice" data-id="${i.id}">قبض دفعة</button>`:''}</div></div></div>`}).join(''):'<div class="empty"><b>▧</b>لا توجد فواتير هنا</div>'}</div>`}
function paidAmount(i){return(i.payments||[]).reduce((a,p)=>a+Number(p.amount),0)}function invoiceStatus(i){const paid=paidAmount(i),total=netTotal(i);return paid>=total?'paid':paid>0?'partial':'unpaid'}function statusName(s){return{paid:'مدفوعة',partial:'مدفوعة جزئياً',unpaid:'غير مدفوعة'}[s]}
async function customersHTML(){const customers=await all('customers'),invoices=await all('invoices');return `<div class="row between"><div><h1>الزبائن</h1><p class="sub">الأرصدة وكشوف الحساب</p></div><button class="btn" data-action="add-customer">＋ إضافة</button></div><div class="list">${customers.length?customers.map(c=>{const inv=invoices.filter(i=>i.customerId===c.id&&!i.voided),due=inv.reduce((a,i)=>a+dueAmount(i),0);return `<div class="card"><div class="row"><div class="avatar">♙</div><div class="grow"><div class="item-title">${esc(c.name)}</div><div class="muted">${esc(c.phone||'لا يوجد رقم')}</div></div><div class="price">${money(due)}<div class="muted">الرصيد</div></div></div><hr class="divider"><div class="row"><button class="btn secondary small grow" data-action="customer-statement" data-id="${c.id}">كشف حساب</button>${due>0?`<button class="btn small" data-action="customer-pay" data-id="${c.id}">تسجيل تسديد</button>`:''}</div></div>`}).join(''):'<div class="empty"><b>♙</b>أضف زبائنك لتسجيل المبيعات الآجلة</div>'}</div>`}
function moreHTML(){return `<h1>المزيد</h1><p class="sub">إدارة المتجر والأدوات</p><div class="list">${[['customers','♙','الزبائن','إدارة الديون وكشوف الحساب'],['returns','↶','المرتجعات','إرجاع الأصناف للمخزون'],['settings','⚙','الإعدادات والنسخ الاحتياطي','إعدادات المتجر والبيانات']].map(([p,icon,title,desc])=>`<button class="list-item quick" data-go="${p}"><div class="avatar">${icon}</div><div class="grow"><div class="item-title">${title}</div><div class="muted">${desc}</div></div>›</button>`).join('')}</div>`}
function profitPerProduct(product,invoices){let result=0;for(const invoice of invoices){if(invoice.voided)continue;const subtotal=invoice.subtotal||invoice.items.reduce((a,x)=>a+x.price*x.qty,0);invoice.items.forEach((item,index)=>{if(item.productId!==product.id)return;const gross=item.price*item.qty,discountShare=subtotal?Number(invoice.discount||0)*gross/subtotal:0;result+=gross-discountShare-Number(item.cost||0)*item.qty;for(const ret of invoice.returns||[])if(ret.itemIndex===index)result-=Number(ret.refund||0)-Number(item.cost||0)*ret.qty})}return result}
async function financeHTML(){const t=await totals(),expenses=(await all('expenses')).sort((a,b)=>b.date.localeCompare(a.date)),allInv=t.invoices.filter(i=>!i.voided);const sold={};for(const i of allInv)for(const it of i.items)sold[it.name]=(sold[it.name]||0)+it.qty;const top=Object.entries(sold).sort((a,b)=>b[1]-a[1]).slice(0,5);return `<div class="row between"><div><h1>الصفحة المالية</h1><p class="sub">أسعار الشراء والبيع والأرباح · ${dateFmt(new Date())}</p></div><button class="btn secondary small" data-action="print-report">طباعة / PDF</button></div><div class="grid"><div class="stat"><div class="label">مبيعات اليوم</div><strong>${money(t.sales)}</strong><em>${t.today.length} فاتورة</em></div><div class="stat"><div class="label">المقبوض الصافي</div><strong>${money(t.received)}</strong><em>بعد المرتجعات ${money(t.refunds)}</em></div><div class="stat"><div class="label">الديون القائمة</div><strong>${money(t.debt)}</strong><em>جميع الزبائن</em></div><div class="stat"><div class="label">أرباح اليوم</div><strong>${money(t.cost)}</strong><em>بعد المرتجعات وقبل المصاريف</em></div></div><div class="card" style="margin-top:12px"><div class="row between"><h2>صافي الربح اليوم</h2><b class="price">${money(t.cost-t.exp)}</b></div><div class="muted">الأرباح ${money(t.cost)} − المصاريف ${money(t.exp)}</div></div><div class="section-head"><h2>أسعار المنتجات وأرباحها</h2></div><div class="list">${t.products.length?t.products.map(p=>`<div class="card"><div class="row between"><div><div class="item-title">${esc(p.name)}</div><div class="muted">شراء ${money(p.cost)} · بيع ${money(p.price)}</div><div class="muted">هامش الوحدة ${money(p.price-p.cost)} · الربح المسجل ${money(profitPerProduct(p,allInv))}</div></div><button class="btn secondary small" data-action="finance-product" data-id="${p.id}">تعديل الأسعار</button></div></div>`).join(''):'<div class="empty">أضف منتجات لعرض الأسعار والأرباح</div>'}</div><div class="section-head"><h2>الأكثر مبيعاً</h2></div><div class="card">${top.length?top.map(([name,n])=>`<div class="table-row"><span>${esc(name)}</span><b>${n} قطعة</b></div>`).join(''):'<div class="muted">لا توجد مبيعات بعد</div>'}</div><div class="section-head"><h2>المصاريف</h2><button class="btn small" data-action="add-expense">＋ تسجيل مصروف</button></div><div class="list">${expenses.length?expenses.map(e=>`<div class="list-item"><div class="avatar">₪</div><div class="grow"><div class="item-title">${esc(e.title)}</div><div class="muted">${dateFmt(e.date)}</div></div><b class="price">${money(e.amount)}</b><button type="button" class="btn-delete-expense" data-action="delete-expense" data-id="${e.id}" data-delete-expense="${e.id}" title="حذف المصروف" aria-label="حذف المصروف" style="margin-inline-start:8px">🗑</button></div>`).join(''):'<div class="empty">لا توجد مصاريف مسجلة</div>'}</div><div class="section-head"><h2>المخزون</h2></div><div class="card">${t.products.map(p=>`<div class="table-row"><span>${esc(p.name)} ${p.qty<=Number(p.lowAt??3)?'<span class="badge warn">منخفض</span>':''}</span><b>${p.qty} قطعة</b></div>`).join('')||'<span class="muted">لا منتجات</span>'}</div>`}
async function expensesHTML(){const list=(await all('expenses')).sort((a,b)=>b.date.localeCompare(a.date));return `<div class="row between"><div><h1>المصاريف</h1><p class="sub">مصروفات المتجر اليومية</p></div><button class="btn" data-action="add-expense">＋ إضافة</button></div><div class="list">${list.length?list.map(e=>`<div class="list-item"><div class="avatar">₪</div><div class="grow"><div class="item-title">${esc(e.title)}</div><div class="muted">${dateFmt(e.date)}</div></div><b class="price">${money(e.amount)}</b><button type="button" class="btn-delete-expense" data-action="delete-expense" data-id="${e.id}" data-delete-expense="${e.id}" title="حذف المصروف" aria-label="حذف المصروف" style="margin-inline-start:8px">🗑</button></div>`).join(''):'<div class="empty"><b>₪</b>لم تسجل مصاريف</div>'}</div>`}
async function returnsHTML(){const invoices=(await all('invoices')).filter(i=>!i.voided&&i.items.some(x=>x.productId));return `<h1>المرتجعات</h1><p class="sub">حدد فاتورة لإرجاع منتج وإعادة كميته للمخزون</p><div class="list">${invoices.length?invoices.map(i=>`<div class="list-item"><div class="avatar">↶</div><div class="grow"><div class="item-title">فاتورة #${i.id} ${i.customer?`· ${esc(i.customer)}`:''}</div><div class="muted">${dateFmt(i.date)} · ${money(i.total)}</div></div><button class="btn secondary small" data-action="return-invoice" data-id="${i.id}">إرجاع</button></div>`).join(''):'<div class="empty"><b>↶</b>لا توجد فواتير بها منتجات مخزنية</div>'}</div>`}
async function settingsHTML(){return `<h1>الإعدادات</h1><p class="sub">بيانات المتجر والنسخ الاحتياطي المحلي</p><div class="card"><label class="field"><span>اسم المتجر</span><input id="shop-setting" class="input" value="${esc(await setting('shopName',''))}" placeholder="اسم المحل"></label><button class="btn full" data-action="save-shop">حفظ الاسم</button></div><div class="card"><h2>النسخ الاحتياطي</h2><p class="muted">حفظ المنتجات والفواتير والزبائن والإعدادات في ملف JSON على جهازك.</p><div class="row"><button class="btn secondary grow" data-action="backup">إنشاء نسخة</button><button class="btn secondary grow" data-action="restore">استعادة نسخة</button></div><input id="restore-file" type="file" accept="application/json,.json" hidden></div><div class="notice">تُحفظ بياناتك في مساحة المتصفح على هذا الهاتف. خذ نسخة احتياطية دورية، ولا تمسح بيانات المتصفح لتجنب فقدانها.</div><div class="card"><div class="row between"><span>حالة الاتصال</span><b>${navigator.onLine?'متصل':'دون إنترنت'}</b></div><div class="muted">يمكن استخدام التطبيق بعد تحميله مرة أولى مع تثبيت ملفات التطبيق.</div></div>`}
function bindPage(){ $$('[data-go]').forEach(b=>b.onclick=()=>setPage(b.dataset.go));$$('[data-filter]').forEach(b=>b.onclick=()=>{invoiceFilter=b.dataset.filter;render()});const ps=$('#product-search');if(ps)ps.oninput=()=>{searchText=ps.value;renderKeepFocus('product-search')};const cs=$('#cash-search');if(cs){cs.oninput=()=>{searchText=cs.value;renderCashResults()};renderCashResults()}$$('[data-action]').forEach(b=>b.onclick=()=>action(b.dataset.action,b.dataset.id));$$('[data-cart]').forEach(b=>b.onclick=()=>cartAction(b.dataset.cart,Number(b.dataset.i)));$('#sale-discount')?.addEventListener('input',updateSaleTotal)}
function renderKeepFocus(id){const el=$('#'+id);if(!el)return;const pos=el.selectionStart;render().then(()=>{const n=$('#'+id);if(n){n.focus();n.setSelectionRange(pos,pos)}})}
async function renderCashResults(){const el=$('#cash-results');if(!el)return;const q=searchText.trim().toLowerCase();if(!q){el.innerHTML='';return}const ps=(await all('products')).filter(p=>`${p.name} ${p.barcode||''}`.toLowerCase().includes(q)).slice(0,7);el.innerHTML=ps.length?ps.map(p=>`<button class="list-item quick" data-add-product="${p.id}"><div class="avatar">＋</div><div class="grow"><div class="item-title">${esc(p.name)}</div><div class="muted">متوفر ${p.qty}</div></div><b class="price">${money(p.price)}</b></button>`).join(''):'<div class="muted" style="padding:8px">لا توجد نتائج</div>';$$('[data-add-product]').forEach(b=>b.onclick=()=>addToCart(Number(b.dataset.addProduct)))}
async function addToCart(id){const p=await get('products',id);if(!p)return;if(p.qty<=0){toast('المنتج غير متوفر');return}const existing=cart.find(x=>x.productId===id);if(existing){if(existing.qty>=p.qty){toast('لا توجد كمية كافية');return}existing.qty++}else cart.push({productId:id,name:p.name,price:Number(p.price),cost:Number(p.cost),qty:1});render()}
function cartAction(action,i){const it=cart[i];if(!it)return;if(action==='remove')cart.splice(i,1);if(action==='plus')it.qty++;if(action==='minus'){if(it.qty<=1)cart.splice(i,1);else it.qty--}render()}
function updateSaleTotal(){const sub=cart.reduce((a,i)=>a+i.price*i.qty,0),d=Math.min(sub,Math.max(0,Number($('#sale-discount')?.value||0)));const el=$('#sale-total');if(el)el.textContent=money(sub-d)}
async function action(name,id){try{switch(name){case'add-product':await productModal();break;case'edit-product':await productModal(Number(id));break;case'finance-product':await financeProductModal(Number(id));break;case'add-customer':await customerModal();break;case'add-expense':await expenseModal();break;case'delete-expense':await deleteExpense(Number(id));break;case'checkout':await checkout();break;case'manual-item':await manualModal();break;case'scan':await scanner();break;case'view-invoice':await viewInvoice(Number(id));break;case'pay-invoice':await paymentModal(Number(id));break;case'customer-pay':await customerPaymentModal(Number(id));break;case'customer-statement':await statementModal(Number(id));break;case'return-invoice':await returnModal(Number(id));break;case'print-report':await printReport();break;case'backup':await backup();break;case'restore':$('#restore-file').click();break;case'save-shop':await setSetting('shopName',$('#shop-setting').value.trim());toast('تم الحفظ');render();break;}}catch(e){console.error(e);toast(e.message||'حدث خطأ، حاول مرة أخرى')}}
function openModal(title,html){$('#modal-title').textContent=title;$('#modal-body').innerHTML=html;$('#modal').showModal();$('.close-modal').onclick=()=>$('#modal').close()}
function closeModal(){if($('#modal').open)$('#modal').close()}
async function financeProductModal(id){const p=await get('products',id);if(!p)return;openModal('تعديل الأسعار المالية',`<p class="muted">تغيير التكلفة هنا لا يعدّل تكلفة المنتجات المباعة سابقاً.</p><div class="item-title">${esc(p.name)}</div><label class="field"><span>سعر الشراء بالجملة (₪)</span><input id="finance-cost" class="input" type="number" min="0" step="0.01" value="${Number(p.cost||0)}"></label><label class="field"><span>سعر البيع (₪)</span><input id="finance-price" class="input" type="number" min="0" step="0.01" value="${Number(p.price||0)}"></label><button type="button" class="btn full" id="save-finance-product">حفظ الأسعار</button>`);$('#save-finance-product').onclick=async()=>{const costText=$('#finance-cost').value.trim(),priceText=$('#finance-price').value.trim(),cost=Number(costText),price=Number(priceText);if(costText===''||priceText===''||!Number.isFinite(cost)||cost<0||!Number.isFinite(price)||price<0){toast('أدخل أسعاراً صحيحة');return}p.cost=cost;p.price=price;p.updated=new Date().toISOString();await put('products',p);closeModal();toast('تم حفظ الأسعار');render()}}
async function productModal(id){const p=id?await get('products',id):{};openModal(id?'تعديل المنتج':'إضافة منتج',`<label class="field"><span>اسم المنتج</span><input id="f-name" class="input" required value="${esc(p.name||'')}"></label><div class="row"><label class="field grow"><span>سعر البيع (₪)</span><input id="f-price" class="input" type="number" min="0" step="0.01" value="${p.price??''}"></label><label class="field grow"><span>سعر الشراء (₪)</span><input id="f-cost" class="input" type="number" min="0" step="0.01" value="${p.cost??''}"></label></div><div class="row"><label class="field grow"><span>الكمية</span><input id="f-qty" class="input" type="number" min="0" step="1" value="${p.qty??0}"></label><label class="field grow"><span>حد التنبيه</span><input id="f-low" class="input" type="number" min="0" value="${p.lowAt??3}"></label></div><label class="field"><span>الباركود (اختياري)</span><input id="f-barcode" class="input mono" value="${esc(p.barcode||'')}" placeholder="أدخل رقم أو امسح بالكاميرا"></label><div class="row"><button type="button" class="btn secondary grow" data-modal-action="scan-product">مسح بالكاميرا</button></div><div class="form-actions"><button type="button" class="btn" data-modal-action="save-product">حفظ المنتج</button>${id?'<button type="button" class="btn danger" data-modal-action="delete-product">حذف</button>':''}</div>`);$('#f-cost').closest('label').style.display='none';$$('[data-modal-action]').forEach(b=>b.onclick=()=>modalAction(b.dataset.modalAction,id))}
async function modalAction(n,id){if(n==='save-product'){const name=$('#f-name').value.trim(),priceText=$('#f-price').value.trim(),costText=$('#f-cost').value.trim(),price=Number(priceText),cost=costText===''?0:Number(costText),qty=Number($('#f-qty').value),barcode=$('#f-barcode').value.trim(),low=Number($('#f-low').value),weighted=!!$('#f-weighted')?.checked;if(!name||priceText===''||!Number.isFinite(price)||price<0||!Number.isFinite(cost)||cost<0||(!weighted&&!Number.isInteger(qty))||!Number.isFinite(qty)||qty<0||!Number.isInteger(low)||low<0){toast('أدخل الاسم والأسعار والكمية الصحيحة');return}if(barcode&&(await all('products')).some(x=>x.barcode===barcode&&x.id!==id)){toast('هذا الباركود مستخدم لمنتج آخر');return}const p={...(id?await get('products',id):{}),name,price,cost,qty,barcode,lowAt:low,updated:new Date().toISOString()};if(id)await put('products',p);else await add('products',p);closeModal();toast('تم حفظ المنتج');render();return}if(n==='delete-product'){if(!confirm('حذف هذا المنتج؟'))return;await del('products',id);closeModal();toast('تم الحذف');render();return}if(n==='scan-product'){await scanner(code=>{const el=$('#f-barcode');if(el){el.value=code;el.focus();toast('تم مسح الباركود: '+code);}});return}}
let audioCtx=null;
let videoBeepBuffer=null;
let beepAudioLoading=false;

function getAudioCtx(){
  try{
    const A=window.AudioContext||window.webkitAudioContext;
    if(!A)return null;
    if(!audioCtx)audioCtx=new A();
    if(audioCtx.state==='suspended')audioCtx.resume().catch(()=>{});
    return audioCtx;
  }catch(e){return null}
}

async function loadBeepAudio(){
  if(videoBeepBuffer||beepAudioLoading)return;
  beepAudioLoading=true;
  try{
    const actx=getAudioCtx();
    if(!actx)return;
    const res=await fetch('./ref_video.mp4');
    if(!res.ok)throw new Error('fetch status '+res.status);
    const arrayBuf=await res.arrayBuffer();
    const abuf=await actx.decodeAudioData(arrayBuf);
    const sr=abuf.sampleRate;
    const ch=abuf.getChannelData(0);
    const sStart=Math.floor(sr*4.2);
    const endS=Math.floor(sr*5.8);
    let maxV=0,pIdx=sStart;
    for(let i=sStart;i<endS;i++){
      const v=Math.abs(ch[i]);
      if(v>maxV){maxV=v;pIdx=i}
    }
    const bStart=Math.max(0,pIdx-Math.floor(sr*0.04));
    const bLen=Math.floor(sr*0.28);
    const slice=actx.createBuffer(1,bLen,sr);
    slice.copyToChannel(ch.slice(bStart,bStart+bLen),0);
    videoBeepBuffer=slice;
  }catch(err){
    console.warn('Audio buffer fallback to synth:',err);
  }finally{
    beepAudioLoading=false;
  }
}

if(typeof window!=='undefined'){
  window.addEventListener('pointerdown',()=>{getAudioCtx();loadBeepAudio()},{once:true});
  window.addEventListener('DOMContentLoaded',()=>{loadBeepAudio()});
}

function playSuccessBeep(){
  try{
    const actx=getAudioCtx();
    if(actx&&videoBeepBuffer){
      const src=actx.createBufferSource();
      src.buffer=videoBeepBuffer;
      src.connect(actx.destination);
      src.start(0);
      return;
    }
  }catch(e){}
  playSynthBeep(1850,0.09,'sine');
}

function playNotFoundBeep(){
  try{
    const actx=getAudioCtx();
    if(!actx)return;
    const now=actx.currentTime;
    const osc1=actx.createOscillator(),g1=actx.createGain();
    osc1.type='sawtooth';
    osc1.frequency.setValueAtTime(220,now);
    g1.gain.setValueAtTime(0.22,now);
    g1.gain.exponentialRampToValueAtTime(0.001,now+0.12);
    osc1.connect(g1);
    g1.connect(actx.destination);
    osc1.start(now);
    osc1.stop(now+0.12);

    const osc2=actx.createOscillator(),g2=actx.createGain();
    osc2.type='sawtooth';
    osc2.frequency.setValueAtTime(160,now+0.14);
    g2.gain.setValueAtTime(0.25,now+0.14);
    g2.gain.exponentialRampToValueAtTime(0.001,now+0.32);
    osc2.connect(g2);
    g2.connect(actx.destination);
    osc2.start(now+0.14);
    osc2.stop(now+0.32);
  }catch(e){}
}

function playSynthBeep(freq=1850,duration=0.09,type='sine'){
  try{
    const actx=getAudioCtx();
    if(!actx)return;
    const osc=actx.createOscillator(),gain=actx.createGain();
    osc.type=type;
    osc.frequency.setValueAtTime(freq,actx.currentTime);
    gain.gain.setValueAtTime(0.001,actx.currentTime);
    gain.gain.linearRampToValueAtTime(0.3,actx.currentTime+0.005);
    gain.gain.setValueAtTime(0.3,actx.currentTime+duration-0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001,actx.currentTime+duration);
    osc.connect(gain);
    gain.connect(actx.destination);
    osc.start(actx.currentTime);
    osc.stop(actx.currentTime+duration);
  }catch(e){}
}

function playBeep(){
  playSuccessBeep();
}
function eanSVG(){return ''}


async function customerModal(){openModal('إضافة زبون',`<label class="field"><span>اسم الزبون</span><input id="c-name" class="input" required></label><label class="field"><span>رقم الهاتف (اختياري)</span><input id="c-phone" class="input" type="tel" dir="ltr"></label><button type="button" class="btn full" id="save-customer">حفظ الزبون</button>`);$('#save-customer').onclick=async()=>{const name=$('#c-name').value.trim();if(!name){toast('أدخل الاسم');return}await add('customers',{name,phone:$('#c-phone').value.trim(),created:new Date().toISOString()});closeModal();toast('تمت الإضافة');render()}}
async function expenseModal(){openModal('تسجيل مصروف',`<label class="field"><span>وصف المصروف</span><input id="e-title" class="input" placeholder="مثال: كهرباء"></label><label class="field"><span>المبلغ (₪)</span><input id="e-amount" class="input" type="number" min="0.01" step="0.01"></label><button type="button" class="btn full" id="save-expense">حفظ المصروف</button>`);$('#save-expense').onclick=async()=>{const title=$('#e-title').value.trim(),amount=Number($('#e-amount').value);if(!title||amount<=0){toast('تحقق من الوصف والمبلغ');return}await add('expenses',{title,amount,date:new Date().toISOString()});closeModal();toast('تم تسجيل المصروف');render()}}
async function deleteExpense(id){if(!id)return;const exp=await get('expenses',id);if(!exp){toast('المصروف غير موجود');return}if(!confirm('هل أنت متأكد من حذف هذا المصروف؟'))return;await del('expenses',id);toast('تم حذف المصروف بنجاح وإعادة مبلغه إلى الصندوق');render()}
window.deleteExpense=deleteExpense;
async function manualModal(){openModal('بند يدوي',`<div class="notice">هذا البند لا يخصم من المخزون. استخدمه للخدمات أو المبيعات اليدوية.</div><label class="field"><span>وصف البند</span><input id="m-name" class="input"></label><div class="row"><label class="field grow"><span>السعر (₪)</span><input id="m-price" type="number" min="0" step="0.01" class="input"></label><label class="field grow"><span>الكمية</span><input id="m-qty" type="number" min="1" value="1" class="input"></label></div><button type="button" id="add-manual" class="btn full">إضافة للسلة</button>`);$('#add-manual').onclick=()=>{const name=$('#m-name').value.trim(),priceText=$('#m-price').value.trim(),price=Number(priceText),qty=Number($('#m-qty').value);if(!name||priceText===''||price<0||!Number.isInteger(qty)||qty<1){toast('تحقق من الحقول');return}cart.push({name,price,cost:0,qty,productId:null});closeModal();render()}}
async function checkout(){if(!cart.length||checkoutBusy)return;checkoutBusy=true;try{const discount=Math.max(0,Math.min(Number($('#sale-discount').value||0),cart.reduce((a,i)=>a+i.price*i.qty,0))),total=Math.max(0,cart.reduce((a,i)=>a+i.price*i.qty,0)-discount),customer=$('#sale-customer').value.trim(),customers=await all('customers');let customerId=customers.find(c=>c.name.toLowerCase()===customer.toLowerCase())?.id||null;const pay=prompt(`إجمالي الفاتورة ${money(total)}\nالمبلغ المدفوع الآن (أدخل 0 للآجل):`,String(total));if(pay===null){checkoutBusy=false;return}const amount=Number(pay);if(!Number.isFinite(amount)||amount<0||amount>total){checkoutBusy=false;toast('مبلغ الدفعة غير صالح');return}if(customer&&!customerId)customerId=await add('customers',{name:customer,phone:'',created:new Date().toISOString()});
const shopName=await setting('shopName','متجري'),transaction=db.transaction(['products','invoices'],'readwrite'),products=transaction.objectStore('products'),invoiceStore=transaction.objectStore('invoices');try{for(const it of cart){if(!it.productId)continue;const p=await reqP(products.get(it.productId));if(!p||p.qty<it.qty)throw new Error(`الكمية غير كافية للمنتج ${it.name}`);p.qty-=it.qty;products.put(p)}const inv={date:new Date().toISOString(),customer,customerId,shopName,items:cart.map(x=>({...x})),subtotal:cart.reduce((a,i)=>a+i.price*i.qty,0),discount,total,payments:amount>0?[{amount,date:new Date().toISOString(),method:'cash'}]:[],returns:[],voided:false};invoiceStore.add(inv);await new Promise((res,rej)=>{transaction.oncomplete=res;transaction.onerror=()=>rej(transaction.error);transaction.onabort=()=>rej(transaction.error)});cart=[];checkoutBusy=false;toast('تم حفظ الفاتورة وخصم المخزون مرة واحدة');setPage('invoices')}catch(e){checkoutBusy=false;try{transaction.abort()}catch{}toast(e.message)}}catch(e){checkoutBusy=false;toast(e.message||'تعذر إنشاء الفاتورة')}}
async function viewInvoice(id){const i=await get('invoices',id);if(!i)return;openModal(`فاتورة #${id}`,invoiceMarkup(i,true));$('#modal-body [data-print]').onclick=()=>printInvoice(i)}
function invoiceMarkup(i,buttons=false){return `<div id="invoice-paper"><div style="text-align:center"><h2>${esc(i.shopName||'متجري')}</h2><p class="muted">فاتورة بيع #${i.id}<br>${dateFmt(i.date)}</p></div>${i.customer?`<p>الزبون: ${esc(i.customer)}</p>`:''}${i.items.map(x=>`<div class="table-row"><span>${esc(x.name)} × ${x.qty}</span><b>${money(x.price*x.qty)}</b></div>`).join('')}<div class="table-row"><span>المجموع</span><b>${money(i.subtotal??i.items.reduce((a,x)=>a+x.price*x.qty,0))}</b></div>${i.discount?`<div class="table-row"><span>الخصم</span><b>− ${money(i.discount)}</b></div>`:''}${(i.returns||[]).length?`<div class="table-row"><span>المرتجعات</span><b>− ${money(i.returns.reduce((a,r)=>a+Number(r.refund||0),0))}</b></div>`:''}<div class="table-row"><b>الإجمالي</b><b>${money(netTotal(i))}</b></div><div class="table-row"><span>المدفوع</span><b>${money(paidAmount(i))}</b></div><div class="table-row"><span>المتبقي</span><b>${money(dueAmount(i))}</b></div><p class="small-note" style="text-align:center">شكراً لزيارتكم</p></div>${buttons?'<button class="btn full" data-print>طباعة / حفظ PDF</button>':''}`}
function printInvoice(i){printHTML(invoiceMarkup(i),'فاتورة '+i.id)}function printHTML(html,title,target=null){const w=target||window.open('','_blank');if(!w){toast('اسمح بفتح نافذة الطباعة');return}w.document.write(`<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><title>${esc(title)}</title><style>body{font:14px Tahoma,Arial;max-width:380px;margin:20px auto;padding:12px;color:#111}.table-row{display:flex;justify-content:space-between;border-bottom:1px solid #ddd;padding:10px 0}.muted{color:#666;font-size:12px;text-align:center}svg{max-width:100%}@media print{button{display:none}}</style><body>${html}<script>onload=()=>setTimeout(()=>print(),250)<\/script></body></html>`);w.document.close()}
async function printReport(){const target=window.open('','_blank');if(!target){toast('اسمح بفتح نافذة الطباعة');return}const t=await totals(),active=t.invoices.filter(i=>!i.voided),rows=t.products.map(p=>`<div class="table-row"><span>${esc(p.name)}<br>شراء ${money(p.cost)} · بيع ${money(p.price)} · هامش ${money(p.price-p.cost)}<br>ربح مسجل ${money(profitPerProduct(p,active))}</span><b>${p.qty} قطعة</b></div>`).join('');printHTML(`<h2>${esc(await setting('shopName','متجري'))} · التقرير المالي</h2><p>${dateFmt(new Date())}</p><div class="table-row"><span>مبيعات اليوم</span><b>${money(t.sales)}</b></div><div class="table-row"><span>المقبوض الصافي</span><b>${money(t.received)}</b></div><div class="table-row"><span>الديون القائمة</span><b>${money(t.debt)}</b></div><div class="table-row"><span>الفواتير اليوم</span><b>${t.today.length}</b></div><div class="table-row"><span>الربح الإجمالي</span><b>${money(t.cost)}</b></div><div class="table-row"><span>المصاريف</span><b>${money(t.exp)}</b></div><div class="table-row"><b>صافي الربح</b><b>${money(t.cost-t.exp)}</b></div><h3>المنتجات والأسعار والأرباح</h3>${rows||'<p>لا توجد منتجات</p>'}`,'التقرير المالي',target)}
async function paymentModal(id){const i=await get('invoices',id),due=dueAmount(i);openModal('تسجيل دفعة',`<p>المتبقي على الفاتورة: <b>${money(due)}</b></p><label class="field"><span>المبلغ المقبوض (₪)</span><input id="pay-amount" type="number" min="0.01" max="${due}" step="0.01" class="input"></label><button id="save-payment" class="btn full">تسجيل الدفعة</button>`);$('#save-payment').onclick=async()=>{const amount=Number($('#pay-amount').value);if(amount<=0||amount>due){toast('المبلغ غير صالح');return}i.payments.push({amount,date:new Date().toISOString(),method:'cash'});await put('invoices',i);closeModal();toast('تم تسجيل الدفعة');render()}}
async function customerPaymentModal(id){const customer=await get('customers',id),invoices=(await all('invoices')).filter(i=>i.customerId===id&&!i.voided&&dueAmount(i)>0).sort((a,b)=>a.date.localeCompare(b.date)),due=invoices.reduce((a,i)=>a+dueAmount(i),0);openModal('تسديد دين',`<p>${esc(customer.name)} · الرصيد ${money(due)}</p><label class="field"><span>المبلغ المقبوض (₪)</span><input id="customer-pay" type="number" min="0.01" max="${due}" step="0.01" class="input"></label><button id="save-customer-pay" class="btn full">تسجيل التسديد</button>`);$('#save-customer-pay').onclick=async()=>{let amount=Number($('#customer-pay').value);if(amount<=0||amount>due){toast('المبلغ غير صالح');return}for(const i of invoices){const remaining=dueAmount(i),part=Math.min(amount,remaining);if(part>0){i.payments.push({amount:part,date:new Date().toISOString(),method:'cash'});await put('invoices',i);amount-=part}if(amount<=0)break}closeModal();toast('تم تسجيل التسديد');render()}}
async function statementModal(id){const c=await get('customers',id),invoices=(await all('invoices')).filter(i=>i.customerId===id&&!i.voided).sort((a,b)=>a.date.localeCompare(b.date));openModal(`كشف حساب · ${c.name}`,`<div>${invoices.map(i=>`<div class="card"><div class="row between"><b>فاتورة #${i.id}</b><span>${dateFmt(i.date)}</span></div><div class="table-row"><span>الإجمالي ${money(netTotal(i))}</span><span>مدفوع ${money(paidAmount(i))}</span></div><div class="muted">المتبقي ${money(dueAmount(i))}</div>${i.payments.map(p=>`<div class="muted">دفعة ${money(p.amount)} · ${dateFmt(p.date)}</div>`).join('')}</div>`).join('')||'<div class="empty">لا توجد حركات</div>'}<button class="btn secondary full" onclick="print()">طباعة الكشف</button></div>`)}
async function returnModal(id){const i=await get('invoices',id),lines=i.items.map((it,index)=>{const returned=i.returns?.filter(r=>r.itemIndex===index).reduce((a,r)=>a+r.qty,0)||0;return it.productId?`<div class="card"><div class="row between"><div><b>${esc(it.name)}</b><div class="muted">مباع ${it.qty} · مرتجع ${returned}</div></div><input class="input return-qty" data-index="${index}" type="number" min="0" step="${it.weighted?'0.001':'1'}" max="${it.qty-returned}" value="0" style="max-width:90px"></div></div>`:''}).join('');openModal(`مرتجع فاتورة #${id}`,`${lines||'<p class="muted">لا توجد أصناف مخزنية.</p>'}<button class="btn full" id="save-return">تأكيد المرتجع وإعادة الكمية</button>`);$('#save-return').onclick=async()=>{const chosen=$$('.return-qty').map(x=>({idx:Number(x.dataset.index),qty:Number(x.value)})).filter(x=>x.qty>0);if(!chosen.length){toast('أدخل كمية للإرجاع');return}const transaction=db.transaction(['products','invoices'],'readwrite'),ps=transaction.objectStore('products'),is=transaction.objectStore('invoices');try{for(const x of chosen){const item=i.items[x.idx],old=i.returns?.filter(r=>r.itemIndex===x.idx).reduce((a,r)=>a+r.qty,0)||0;if(x.qty>item.qty-old)throw new Error('كمية الإرجاع تتجاوز المباع');const product=await reqP(ps.get(item.productId));if(product){product.qty+=x.qty;ps.put(product)}i.returns=i.returns||[];i.returns.push({itemIndex:x.idx,qty:x.qty,date:new Date().toISOString(),refund:x.qty*item.price})}is.put(i);await new Promise((r,j)=>{transaction.oncomplete=r;transaction.onerror=()=>j(transaction.error);transaction.onabort=()=>j(transaction.error)});closeModal();toast('تم تسجيل المرتجع وتحديث المخزون');render()}catch(e){transaction.abort();toast(e.message)}}}
async function scanner(onCode,options={}){
  if(typeof onCode==='object'&&onCode!==null&&!options.mode){
    options=onCode;
    onCode=null;
  }
  const mode=options.mode||(onCode?'callback':'cashier');
  getAudioCtx();
  loadBeepAudio();

  const oldOverlay=document.getElementById('live-scanner-overlay');
  if(oldOverlay)oldOverlay.remove();

  if(!('BarcodeDetector'in window)){
    toast('مسح الكاميرا غير مدعوم في هذا المتصفح. أدخل الباركود يدوياً.');
    return;
  }

  const baseModal=document.getElementById('modal');
  const wasModalOpen=baseModal&&baseModal.open;
  if(wasModalOpen){
    baseModal.style.visibility='hidden';
  }

  const overlay=document.createElement('dialog');
  overlay.id='live-scanner-overlay';
  overlay.className='scanner-dialog-overlay';
  overlay.innerHTML=`
    <header class="scanner-topbar">
      <button type="button" class="scanner-icon-btn" id="scanner-back-btn" aria-label="رجوع">←</button>
      <div class="scanner-topbar-title">${mode==='purchase'?'مسح باركود المشتريات':'مسح الباركود'}</div>
      <div class="scanner-actions-group">
        <button type="button" class="scanner-icon-btn" id="scanner-flash-btn" aria-label="فلاش">⚡</button>
        <button type="button" class="scanner-icon-btn" id="scanner-flip-btn" aria-label="تبديل الكاميرا">🔄</button>
      </div>
    </header>
    <div class="scanner-viewfinder-container">
      <video id="scanner-live-video" playsinline autoplay muted></video>
      <div class="scanner-reticle-box">
        <div class="scanner-corner scanner-corner-tl"></div>
        <div class="scanner-corner scanner-corner-tr"></div>
        <div class="scanner-corner scanner-corner-bl"></div>
        <div class="scanner-corner scanner-corner-br"></div>
        <div class="scanner-laser-line"></div>
      </div>
      <div id="scanner-floating-pill" class="scanner-floating-pill"></div>
    </div>
    <div class="scanner-bottom-panel">
      <div id="scanner-items-container" class="scanner-items-container"></div>
      <div class="scanner-footer-bar" id="scanner-footer-bar"></div>
    </div>
  `;
  document.body.appendChild(overlay);
  if(typeof overlay.showModal==='function'){
    try{overlay.showModal()}catch(e){}
  }
  overlay.addEventListener('cancel',e=>{
    e.preventDefault();
    closeScanner();
  });

  let stream=null;
  let active=true;
  let torchOn=false;
  let facingMode='environment';
  let pillTimer=null;
  let lastScannedCode=null;
  let lastScannedTime=0;
  const SCAN_DEBOUNCE_MS=1400;

  function showPill(text,type='success'){
    const pill=overlay.querySelector('#scanner-floating-pill');
    if(!pill)return;
    clearTimeout(pillTimer);
    pill.textContent=text;
    pill.className=`scanner-floating-pill show ${type}`;
    pillTimer=setTimeout(()=>{
      pill.className='scanner-floating-pill';
    },2200);
  }

  function closeScanner(){
    active=false;
    if(stream){
      stream.getTracks().forEach(t=>t.stop());
      stream=null;
    }
    if(wasModalOpen&&baseModal){
      baseModal.style.visibility='';
    }
    if(overlay.open){
      try{overlay.close()}catch(e){}
    }
    overlay.remove();
    if(mode==='cashier'||mode==='purchase'){
      if(typeof captureActiveCart==='function')captureActiveCart();
      if(typeof render==='function')render();
    }
  }

  overlay.querySelector('#scanner-back-btn').onclick=closeScanner;

  const flashBtn=overlay.querySelector('#scanner-flash-btn');
  flashBtn.onclick=async()=>{
    const track=stream?.getVideoTracks()[0];
    if(!track)return;
    const caps=track.getCapabilities?track.getCapabilities():{};
    if(!caps.torch){
      toast('الفلاش غير مدعوم في هذا الجهاز');
      return;
    }
    torchOn=!torchOn;
    try{
      await track.applyConstraints({advanced:[{torch:torchOn}]});
      flashBtn.style.color=torchOn?'#ffd600':'#ffffff';
    }catch(e){
      toast('تعذر تبديل الفلاش');
    }
  };

  const flipBtn=overlay.querySelector('#scanner-flip-btn');
  flipBtn.onclick=async()=>{
    facingMode=facingMode==='environment'?'user':'environment';
    if(stream){
      stream.getTracks().forEach(t=>t.stop());
    }
    await initCamera();
  };

  function renderLowerPanel(){
    const listEl=overlay.querySelector('#scanner-items-container');
    const footerEl=overlay.querySelector('#scanner-footer-bar');
    if(!listEl||!footerEl)return;

    if(mode==='callback'){
      listEl.innerHTML=`
        <div class="scanner-empty-state">
          <div class="scanner-empty-icon">📷</div>
          <div class="scanner-empty-text">وجّه الكاميرا إلى الباركود لقراءته تلقائياً</div>
          <p class="small-note" style="margin-top:8px">سيتم إغلاق الماسح ووضع الرمز في نموذج الصنف فور القراءة</p>
        </div>
      `;
      footerEl.innerHTML=`
        <button type="button" class="scanner-footer-btn" id="scanner-done-btn">✕ إلغاء والعودة للنموذج</button>
      `;
      overlay.querySelector('#scanner-done-btn').onclick=closeScanner;
      return;
    }

    const itemsList=mode==='purchase'?(typeof purchaseCart!=='undefined'?purchaseCart:[]):cart;
    const totalAmount=mode==='purchase'
      ?itemsList.reduce((acc,it)=>acc+(Number(it.cost||0)*Number(it.qty||1)),0)
      :itemsList.reduce((acc,it)=>acc+(Number(it.price||0)*Number(it.qty||1)),0);

    if(!itemsList.length){
      listEl.innerHTML=`
        <div class="scanner-empty-state">
          <div class="scanner-empty-icon">📦</div>
          <div class="scanner-empty-text">لم يتم قراءة أي منتج بعد</div>
          <p class="small-note" style="margin-top:6px">وجّه الكاميرا نحو باركود الصنف لإضافته إلى السلة مباشرة</p>
        </div>
      `;
    }else{
      listEl.innerHTML=itemsList.map((item,idx)=>{
        const itemPrice=mode==='purchase'?Number(item.cost||0):Number(item.price||0);
        const itemSum=itemPrice*Number(item.qty||1);
        return `
          <div class="scanner-item-row">
            <div class="scanner-item-details">
              <div class="scanner-item-name">${esc(item.name)}</div>
              <div class="scanner-item-meta">${item.barcode?`باركود: ${esc(item.barcode)} · `:''}${money(itemPrice)} للقطعة</div>
            </div>
            <div class="scanner-item-actions">
              <div class="scanner-qty-control">
                <button type="button" class="scanner-qty-btn" data-scan-qty="minus" data-idx="${idx}">−</button>
                <span class="scanner-qty-num">${item.qty}</span>
                <button type="button" class="scanner-qty-btn" data-scan-qty="plus" data-idx="${idx}">+</button>
              </div>
              <div class="scanner-item-price-sum">${money(itemSum)}</div>
              <button type="button" class="scanner-item-remove-btn" data-scan-del="${idx}" title="حذف">🗑</button>
            </div>
          </div>
        `;
      }).join('');

      listEl.querySelectorAll('[data-scan-qty="plus"]').forEach(b=>{
        b.onclick=()=>{
          const idx=Number(b.dataset.idx);
          if(itemsList[idx]){
            itemsList[idx].qty++;
            renderLowerPanel();
          }
        };
      });
      listEl.querySelectorAll('[data-scan-qty="minus"]').forEach(b=>{
        b.onclick=()=>{
          const idx=Number(b.dataset.idx);
          if(itemsList[idx]){
            if(itemsList[idx].qty<=1){
              itemsList.splice(idx,1);
            }else{
              itemsList[idx].qty--;
            }
            renderLowerPanel();
          }
        };
      });
      listEl.querySelectorAll('[data-scan-del]').forEach(b=>{
        b.onclick=()=>{
          const idx=Number(b.dataset.idx);
          if(itemsList[idx]){
            itemsList.splice(idx,1);
            renderLowerPanel();
          }
        };
      });
    }

    footerEl.innerHTML=`
      <div class="scanner-footer-summary">
        <span>الإجمالي الكلي</span>
        <b>${money(totalAmount)}</b>
      </div>
      <button type="button" class="scanner-footer-btn" id="scanner-done-btn">✓ إغلاق والعودة</button>
    `;
    overlay.querySelector('#scanner-done-btn').onclick=closeScanner;
  }

  renderLowerPanel();

  async function initCamera(){
    try{
      stream=await navigator.mediaDevices.getUserMedia({
        video:{facingMode:{ideal:facingMode},width:{ideal:1280},height:{ideal:720}},
        audio:false
      });
      const videoEl=overlay.querySelector('#scanner-live-video');
      if(!videoEl)return;
      videoEl.srcObject=stream;
      await videoEl.play();
    }catch(err){
      console.error(err);
      toast('تعذر تشغيل الكاميرا. تحقق من الإذن أو أدخل الباركود يدوياً.');
    }
  }

  await initCamera();

  try{
    const supported=await BarcodeDetector.getSupportedFormats();
    const desired=['ean_13','ean_8','upc_a','upc_e','code_128','code_39','qr_code'];
    const formats=desired.filter(f=>supported.includes(f));
    const detector=new BarcodeDetector({formats:formats.length?formats:supported});
    const videoEl=overlay.querySelector('#scanner-live-video');

    const scanLoop=async()=>{
      if(!active)return;
      try{
        if(videoEl&&videoEl.readyState>=2){
          const codes=await detector.detect(videoEl);
          if(codes&&codes.length){
            const raw=String(codes[0].rawValue||'').trim();
            const now=Date.now();
            if(raw&&(raw!==lastScannedCode||(now-lastScannedTime)>SCAN_DEBOUNCE_MS)){
              lastScannedCode=raw;
              lastScannedTime=now;
              await handleBarcode(raw);
            }
          }
        }
      }catch(e){}
      if(active){
        requestAnimationFrame(scanLoop);
      }
    };
    scanLoop();
  }catch(e){
    console.error('Detector init failed:',e);
  }

  async function handleBarcode(code){
    if(mode==='callback'&&onCode){
      playSuccessBeep();
      showPill(`✓ تم مسح: ${code}`,'success');
      setTimeout(()=>{
        closeScanner();
        onCode(code);
      },320);
      return;
    }

    const allProducts=await all('products');
    const hit=allProducts.find(p=>String(p.barcode||'').trim()===code);

    if(hit){
      playSuccessBeep();
      const unitPrice=mode==='purchase'?Number(hit.cost||0):Number(hit.price||0);
      showPill(`✓ ${hit.name} · ${money(unitPrice)}`,'success');

      if(mode==='purchase'){
        if(window.addPurchaseBarcodeProduct){
          window.addPurchaseBarcodeProduct(hit);
        }else{
          const pList=typeof purchaseCart!=='undefined'?purchaseCart:(window.purchaseCart||[]);
          const existing=pList.find(x=>x.productId===hit.id||x.name===hit.name);
          if(existing){
            existing.qty++;
          }else{
            pList.unshift({
              productId:hit.id,
              name:hit.name,
              cost:Number(hit.cost||0),
              qty:1,
              weighted:!!hit.weighted,
              barcode:hit.barcode
            });
          }
          if(typeof render==='function')render();
        }
      }else{
        if(hit.qty<=0){
          toast('المنتج كميته 0 في المخزون');
        }
        const existing=cart.find(x=>x.productId===hit.id);
        if(existing){
          existing.qty++;
        }else{
          cart.unshift({
            productId:hit.id,
            name:hit.name,
            price:Number(hit.price||0),
            cost:Number(hit.cost||0),
            qty:1,
            barcode:hit.barcode
          });
        }
      }
      renderLowerPanel();
    }else{
      playNotFoundBeep();
      showPill('✕ المنتج غير متوفر','error');
      toast('المنتج غير متوفر');
    }
  }
}
async function backup(){const data={format:'mystore-backup',version:1,exportedAt:new Date().toISOString(),stores:{}};for(const s of Object.values(STORE))data.stores[s]=await all(s);const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`mystore-backup-${todayKey()}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);toast('تم تنزيل النسخة الاحتياطية')}
async function restoreFile(file){try{const obj=JSON.parse(await file.text());if(obj.format!=='mystore-backup'||!obj.stores)throw new Error('صيغة الملف غير صحيحة');if(!confirm('ستُستبدل البيانات الحالية بمحتوى النسخة. هل تريد المتابعة؟'))return;const txdb=db.transaction(Object.values(STORE),'readwrite');for(const s of Object.values(STORE)){const st=txdb.objectStore(s);st.clear();for(const row of obj.stores[s]||[])st.put(row)}await new Promise((r,j)=>{txdb.oncomplete=r;txdb.onerror=()=>j(txdb.error)});toast('تمت استعادة النسخة');render()}catch(e){toast(e.message||'تعذرت استعادة النسخة')}}
$$('.bottom-nav button').forEach(b=>b.addEventListener('click',()=>{if(b.dataset.page==='more')setPage('more');else setPage(b.dataset.page)}));
$('#brand-mark').addEventListener('click',()=>{secretTapCount++;clearTimeout(secretTapTimer);secretTapTimer=setTimeout(()=>secretTapCount=0,1800);if(secretTapCount>=5){secretTapCount=0;setPage('finance')}});
document.addEventListener('change',e=>{if(e.target.id!=='restore-file')return;const f=e.target.files[0];if(f)restoreFile(f);e.target.value=''});
window.addEventListener('online',()=>{$('.status-dot').style.background='#2caa74'});window.addEventListener('offline',()=>{$('.status-dot').style.background='#d29527'});
async function boot(){db=await openDB();$('.status-dot').style.background=navigator.onLine?'#2caa74':'#d29527';if('serviceWorker'in navigator&&location.protocol!=='file:')navigator.serviceWorker.register('./sw.js').catch(console.warn);await render()}
boot().catch(e=>{console.error(e);$('#app').innerHTML=`<div class="notice">تعذر تشغيل قاعدة البيانات المحلية. افتح التطبيق عبر خادم محلي أو بعد تثبيته كتطبيق PWA. ${esc(e.message)}</div>`});
