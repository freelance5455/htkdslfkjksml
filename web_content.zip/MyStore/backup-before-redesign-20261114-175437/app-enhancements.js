/* Enhancements for the existing MyStore PWA. IndexedDB schema stays compatible. */
(() => {
  let lowStockOnly = false;
  let dailyCountDate = todayKey();
  let invoiceArchiveDate = todayKey();
  let financeDate = todayKey();
  let barcodeQueue = [];
  let checkoutCommitting = false;
  const BACKUP_META_KEY = 'mystore-backup-meta-v2';
  const toISO = () => new Date().toISOString();
  const sum = (items, fn) => items.reduce((value, item) => value + Number(fn(item) || 0), 0);
  const returnValue = invoice => sum(invoice.returns || [], item => item.refund);
  const cashRefundValue = invoice => sum((invoice.returns || []).filter(item => item.mode !== 'debt'), item => item.refund);
  const returnedQty = (invoice, index) => sum((invoice.returns || []).filter(item => item.itemIndex === index), item => item.qty);
  const returnAmount = (invoice, index, qty) => {
    const item = invoice.items[index]; if (!item) return 0;
    const originalSubtotal = sum((invoice.items || []).filter(line => !line.addedAt), line => line.price * line.qty);
    const discountPerUnit = !item.addedAt && originalSubtotal ? Number(invoice.discount || 0) * item.price / originalSubtotal : 0;
    return Math.max(0, (Number(item.price) - discountPerUnit) * qty);
  };
  const saleAdjustments = invoice => (invoice.history || []).filter(row => row.type === 'items-added');
  const adjustmentTotal = invoice => sum(saleAdjustments(invoice), row => row.total);
  const eventKey = value => dateKey(value);
  const dateTimeFmt = value => `${new Date(value).toLocaleDateString('ar-PS', { year: 'numeric', month: 'short', day: 'numeric' })} · ${new Date(value).toLocaleTimeString('ar-PS', { hour: '2-digit', minute: '2-digit' })}`;
  const transactionDone = transaction => new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onabort = transaction.onerror = () => reject(transaction.error || new Error('تعذرت معاملة قاعدة البيانات'));
  });

  netTotal = invoice => Math.max(0, Number(invoice.netTotalApplied ? invoice.total : invoice.total - returnValue(invoice)));
  paidAmount = invoice => Math.min(netTotal(invoice), Math.max(0, sum(invoice.payments || [], payment => payment.amount) - cashRefundValue(invoice)));
  dueAmount = invoice => Math.max(0, netTotal(invoice) - paidAmount(invoice));
  profitBeforeReturns = invoice => netTotal(invoice) - sum(invoice.items || [], item => Number(item.cost || 0) * Math.max(0, Number(item.qty) - returnedQty(invoice, invoice.items.indexOf(item))));
  returnAdjustment = (invoice, item) => -Number(item.refund || 0) + Number(invoice.items[item.itemIndex]?.cost || 0) * Number(item.qty || 0);

  function invoiceOriginalAmount(invoice) {
    return Number(invoice.grossTotal ?? (invoice.netTotalApplied ? invoice.total + returnValue(invoice) - adjustmentTotal(invoice) : invoice.total));
  }
  function invoiceSaleAmount(invoice) {
    return invoiceOriginalAmount(invoice) + adjustmentTotal(invoice);
  }
  function invoiceAmendmentsForDate(invoice, key) {
    return sum(saleAdjustments(invoice).filter(row => eventKey(row.date) === key), row => row.total);
  }
  function invoiceReturnsForDate(invoice, key) {
    return sum((invoice.returns || []).filter(row => eventKey(row.date) === key), row => row.refund);
  }
  function invoiceProfitForSale(invoice) {
    const originalItems = (invoice.items || []).filter(item => !item.addedAt);
    const cost = sum(originalItems, item => Number(item.cost || 0) * Number(item.qty || 0));
    return invoiceOriginalAmount(invoice) - cost;
  }

  async function dailyCount(key) {
    const [invoices, products, expenses] = await Promise.all([all('invoices'), all('products'), all('expenses')]);
    const active = invoices.filter(invoice => !invoice.voided);
    const salesToday = sum(active.filter(invoice => eventKey(invoice.date) === key), invoice => invoiceOriginalAmount(invoice))
      + sum(active, invoice => invoiceAmendmentsForDate(invoice, key))
      - sum(active, invoice => invoiceReturnsForDate(invoice, key));
    const paymentsToday = sum(active, invoice => sum((invoice.payments || []).filter(payment => eventKey(payment.date) === key), payment => payment.amount))
      - sum(active, invoice => sum((invoice.returns || []).filter(row => eventKey(row.date) === key && row.mode !== 'debt'), row => row.refund));
    const invoicesToday = active.filter(invoice => eventKey(invoice.date) === key).length;
    const openDebtAtDate = sum(active.filter(invoice => eventKey(invoice.date) <= key), invoice => {
      const sale = invoiceOriginalAmount(invoice)
        + sum(saleAdjustments(invoice).filter(row => eventKey(row.date) <= key), row => row.total)
        - sum((invoice.returns || []).filter(row => eventKey(row.date) <= key), row => row.refund);
      const paid = sum((invoice.payments || []).filter(payment => eventKey(payment.date) <= key), payment => payment.amount)
        - sum((invoice.returns || []).filter(row => eventKey(row.date) <= key && row.mode !== 'debt'), row => row.refund);
      return Math.max(0, sale - Math.max(0, paid));
    });
    const quantities = new Map();
    const addQty = (name, qty) => quantities.set(name, (quantities.get(name) || 0) + qty);
    active.forEach(invoice => {
      (invoice.items || []).forEach(item => {
        const soldOn = item.addedAt ? eventKey(item.addedAt) : eventKey(invoice.date);
        if (soldOn === key) addQty(item.name, Number(item.qty || 0));
      });
      (invoice.returns || []).filter(row => eventKey(row.date) === key).forEach(row => {
        const item = invoice.items[row.itemIndex];
        if (item) addQty(item.name, -Number(row.qty || 0));
      });
    });
    let grossProfit = sum(active.filter(invoice => eventKey(invoice.date) === key), invoice => invoiceProfitForSale(invoice));
    grossProfit += sum(active, invoice => sum(saleAdjustments(invoice).filter(row => eventKey(row.date) === key), row => Number(row.total || 0) - sum(row.items || [], item => item.cost * item.qty)));
    grossProfit += sum(active, invoice => sum((invoice.returns || []).filter(row => eventKey(row.date) === key), row => returnAdjustment(invoice, row)));
    const expenseTotal = sum(expenses.filter(expense => eventKey(expense.date) === key), expense => expense.amount);
    return {
      key, invoices, products, expenses, active, sales: salesToday, received: paymentsToday,
      debt: openDebtAtDate, invoiceCount: invoicesToday, grossProfit, expenseTotal,
      netProfit: grossProfit - expenseTotal,
      productSales: [...quantities.entries()].filter(([, qty]) => qty !== 0).sort((a, b) => a[0].localeCompare(b[0], 'ar'))
    };
  }

  totals = async () => {
    const report = await dailyCount(todayKey());
    const low = report.products.filter(product => product.qty <= Number(product.lowAt ?? 3));
    return {
      invoices: report.invoices, products: report.products, expenses: report.expenses,
      today: report.active.filter(invoice => eventKey(invoice.date) === report.key),
      received: report.received, refunds: sum(report.active, invoice => invoiceReturnsForDate(invoice, report.key)),
      sales: report.sales, debt: report.debt, low, cost: report.grossProfit, exp: report.expenseTotal
    };
  };

  homeHTML = async () => {
    const t = await totals();
    const cards = [
      ['الفواتير اليوم', t.today.length, 'invoice-archive', 'فاتورة'],
      ['الديون المفتوحة', money(t.debt), 'customers', 'على الزبائن'],
      ['المنتجات', t.products.length, 'products', 'صنف بالمخزون'],
      ['المخزون المنخفض', t.low.length, 'products-low', 'بحاجة للمتابعة']
    ];
    return `<h1>أهلاً بك 👋</h1><p class="sub">ملخص متجرك اليوم</p><button class="hero home-card" data-go="invoice-archive"><div class="label">المبيعات اليوم</div><div class="amount">${money(t.sales)}</div><small>المقبوض ${money(t.received)} · اضغط لفتح فواتير اليوم</small></button><div class="grid">${cards.map(([label, value, target, hint]) => `<button class="stat home-stat" data-home-target="${target}"><div class="label">${label}</div><strong>${value}</strong><em>${hint}</em></button>`).join('')}<button class="stat home-stat" data-home-target="products"><div class="label">المخزون</div><strong>${t.products.reduce((n, product) => n + Number(product.qty || 0), 0)}</strong><em>قطعة متوفرة</em></button></div><div class="section-head"><h2>إجراءات سريعة</h2></div><div class="quick-grid"><button class="quick" data-go="cashier"><b>＋</b>فاتورة جديدة</button><button class="quick" data-action="add-product"><b>▦</b>إضافة منتج</button><button class="quick" data-go="customers"><b>♙</b>الزبائن والديون</button><button class="quick" data-go="invoices"><b>▧</b>الفواتير</button></div>${t.low.length ? `<div class="section-head"><h2>تنبيه المخزون</h2><button class="btn secondary small" data-home-target="products-low">عرض المنتجات المنخفضة</button></div><div class="list">${t.low.slice(0, 3).map(product => `<button class="list-item quick" data-home-target="products-low"><div class="avatar">▦</div><div class="grow"><div class="item-title">${esc(product.name)}</div><div class="muted">المتبقي ${product.qty}</div></div><span class="badge warn">${product.qty === 0 ? 'نفد' : 'منخفض'}</span></button>`).join('')}</div>` : ''}`;
  };

  const baseSetPage = setPage;
  setPage = next => {
    if (next === 'products') lowStockOnly = false;
    baseSetPage(next);
  };

  productsHTML = async () => {
    const products = await all('products');
    const list = products.filter(product => (!lowStockOnly || product.qty <= Number(product.lowAt ?? 3))
      && `${product.name} ${product.barcode || ''}`.toLowerCase().includes(searchText.toLowerCase()));
    return `<div class="row between"><div><h1>${lowStockOnly ? 'المخزون المنخفض' : 'المنتجات والمخزون'}</h1><p class="sub">إدارة الأصناف والباركود والكميات</p></div><button class="btn" data-action="add-product">＋ إضافة</button></div><div class="searchbox"><input id="product-search" class="input" placeholder="بحث بالاسم أو الباركود" value="${esc(searchText)}"></div><div class="row"><button class="btn secondary small" data-stock-filter="all">كل المنتجات</button><button class="btn secondary small" data-stock-filter="low">المخزون المنخفض</button></div><div class="card barcode-queue-panel"><div class="row between"><div><h2>ملصقات الباركود</h2><div class="muted">أضف الأصناف ثم اطبعها معاً</div></div><button class="btn secondary small" data-barcode-action="open">قائمة الطباعة (${barcodeQueue.length})</button></div></div><div class="list">${list.length ? list.map(product => `<div class="list-item"><div class="avatar">▦</div><div class="grow"><div class="item-title">${esc(product.name)}</div><div class="muted">${product.barcode ? `باركود ${esc(product.barcode)} · ` : ''}الكمية ${product.qty}</div></div><div class="price">${money(product.price)}${product.qty <= Number(product.lowAt ?? 3) ? '<div class="badge warn">مخزون منخفض</div>' : ''}</div><button class="icon-button" data-barcode-action="add" data-id="${product.id}" aria-label="إضافة باركود للطباعة">▤</button><button class="icon-button" data-action="edit-product" data-id="${product.id}">✎</button></div>`).join('') : '<div class="empty">لا توجد منتجات مطابقة</div>'}</div>`;
  };

  const baseInvoicesHTML = invoicesHTML;
  invoicesHTML = async () => (await baseInvoicesHTML()).replace(/(<button class="btn secondary small" data-action="view-invoice" data-id="(\d+)">عرض<\/button>)/g, '$1<button class="btn danger small" data-invoice-delete="$2">حذف</button>');

  function bindEnhancements() {
    document.querySelectorAll('[data-home-target]').forEach(button => button.addEventListener('click', () => {
      if (button.dataset.homeTarget === 'products-low') {
        lowStockOnly = true; searchText = ''; page = 'products'; render();
      } else setPage(button.dataset.homeTarget);
    }));
    document.querySelectorAll('[data-stock-filter]').forEach(button => button.addEventListener('click', () => {
      lowStockOnly = button.dataset.stockFilter === 'low'; searchText = ''; render();
    }));
    document.querySelectorAll('[data-barcode-action]').forEach(button => button.addEventListener('click', () => {
      if (button.dataset.barcodeAction === 'add') addBarcodeToQueue(Number(button.dataset.id));
      if (button.dataset.barcodeAction === 'open') openBarcodeQueue();
    }));
    document.querySelectorAll('[data-action="daily-print"]').forEach(button => button.addEventListener('click', () => printDailyCount(dailyCountDate, true, window.open('', '_blank'))));
    document.querySelectorAll('[data-action="daily-pdf"]').forEach(button => button.addEventListener('click', () => saveHTMLAsPDF(dailyCountDate)));
    document.querySelectorAll('[data-action="finance-print"]').forEach(button => button.addEventListener('click', () => printFinanceReport(financeDate, window.open('', '_blank'))));
    document.querySelectorAll('[data-action="finance-pdf"]').forEach(button => button.addEventListener('click', () => saveFinancePDF(financeDate)));
    document.querySelectorAll('[data-action="archive-print"]').forEach(button => button.addEventListener('click', () => printInvoiceArchive(invoiceArchiveDate, window.open('', '_blank'))));
    document.querySelectorAll('[data-action="archive-pdf"]').forEach(button => button.addEventListener('click', () => saveInvoiceArchivePDF(invoiceArchiveDate)));
  }
  const baseBindPage = bindPage;
  bindPage = () => { baseBindPage(); bindEnhancements(); };

  const baseMoreHTML = moreHTML;
  moreHTML = () => `${baseMoreHTML().replace(/<\/div>$/, '')}<button class="list-item quick" data-go="invoice-archive"><div class="avatar">▧</div><div class="grow"><div class="item-title">أرشيف الفواتير</div><div class="muted">فواتير أي يوم وملخص طرق الدفع</div></div>›</button><button class="list-item quick" data-go="daily-count"><div class="avatar">▦</div><div class="grow"><div class="item-title">الجرد اليومي</div><div class="muted">المبيعات والكميات والرصيد بتاريخ تختاره</div></div>›</button></div>`;
  const baseRender = render;
  render = async () => {
    if (page !== 'daily-count' && page !== 'invoice-archive') return baseRender();
    nav();
    const app = $('#app');
    try { app.innerHTML = page === 'daily-count' ? await dailyCountHTML() : await invoiceArchiveHTML(); bindPage(); }
    catch (error) { console.error(error); app.innerHTML = `<div class="notice">تعذر تحميل التقرير: ${esc(error.message)}</div>`; }
  };
  nav = () => {
    const group = page === 'invoice-archive' ? 'invoices' : ['customers', 'reports', 'expenses', 'settings', 'returns', 'daily-count'].includes(page) ? 'more' : page;
    $$('.bottom-nav button').forEach(button => button.classList.toggle('active', button.dataset.page === group));
  };

  async function dailyCountHTML() {
    const report = await dailyCount(dailyCountDate);
    const currentByName = new Map(report.products.map(product => [product.name, product.qty]));
    const allNames = new Set([...report.productSales.map(([name]) => name), ...report.products.map(product => product.name)]);
    const rows = [...allNames].sort((a, b) => a.localeCompare(b, 'ar')).map(name => {
      const sold = report.productSales.find(([productName]) => productName === name)?.[1] || 0;
      return `<div class="table-row"><span>${esc(name)}<div class="muted">مباع صافٍ: ${sold}</div></span><b>المتبقي الآن: ${currentByName.get(name) ?? '—'}</b></div>`;
    }).join('');
    return `<div class="row between"><div><h1>الجرد اليومي</h1><p class="sub">مبيعات ودفعات وديون حتى نهاية اليوم المحدد</p></div></div><label class="field"><span>تاريخ التقرير</span><input id="daily-date" class="input" type="date" value="${esc(dailyCountDate)}"></label><div class="grid"><div class="stat"><div class="label">إجمالي المبيعات</div><strong>${money(report.sales)}</strong></div><div class="stat"><div class="label">عدد الفواتير</div><strong>${report.invoiceCount}</strong></div><div class="stat"><div class="label">المبالغ المدفوعة</div><strong>${money(report.received)}</strong></div><div class="stat"><div class="label">الديون القائمة</div><strong>${money(report.debt)}</strong></div></div><div class="section-head"><h2>المنتجات والكميات</h2></div><div class="card">${rows || '<div class="empty">لا توجد حركة لهذا اليوم</div>'}</div><div class="row"><button class="btn grow" data-action="daily-print">طباعة</button><button class="btn secondary grow" data-action="daily-pdf">حفظ PDF</button></div>`;
  }

  async function invoiceArchiveHTML() {
    const report = await dailyCount(invoiceArchiveDate), dayInvoices = report.active.filter(invoice => eventKey(invoice.date) === invoiceArchiveDate).sort((a, b) => a.date.localeCompare(b.date));
    const methods = new Map();
    report.active.forEach(invoice => (invoice.payments || []).filter(payment => eventKey(payment.date) === invoiceArchiveDate).forEach(payment => {
      const method = String(payment.method || invoice.paymentMethod || 'غير محدد').trim() || 'غير محدد';
      methods.set(method, (methods.get(method) || 0) + Number(payment.amount || 0));
    }));
    const rows = dayInvoices.map(invoice => `<div class="card"><div class="row between"><div><div class="item-title">فاتورة #${invoice.id} ${invoice.customer ? `· ${esc(invoice.customer)}` : ''}</div><div class="muted">${dateTimeFmt(invoice.date)}</div></div><button class="btn secondary small" data-action="view-invoice" data-id="${invoice.id}">التفاصيل</button></div><div class="table-row"><span>الإجمالي الصافي</span><b>${money(netTotal(invoice))}</b></div><div class="table-row"><span>المدفوع</span><b>${money(paidAmount(invoice))}</b></div><div class="table-row"><span>المتبقي</span><b>${money(dueAmount(invoice))}</b></div><div class="muted">طرق الدفع: ${esc([...new Set((invoice.payments || []).map(payment => payment.method || invoice.paymentMethod || 'غير محدد'))].join('، ') || invoice.paymentMethod || 'غير مدفوع')}</div></div>`).join('');
    const methodsHTML = [...methods.entries()].map(([method, amount]) => `<div class="table-row"><span>${esc(method)}</span><b>${money(amount)}</b></div>`).join('') || '<div class="muted">لا توجد دفعات مسجلة في هذا اليوم</div>';
    return `<h1>أرشيف الفواتير</h1><p class="sub">اختر يوماً لمراجعة فواتيره وحركات الدفع</p><label class="field"><span>التاريخ</span><input id="archive-date" class="input" type="date" value="${esc(invoiceArchiveDate)}"></label><div class="grid"><div class="stat"><div class="label">مبيعات اليوم</div><strong>${money(report.sales)}</strong></div><div class="stat"><div class="label">عدد الفواتير</div><strong>${report.invoiceCount}</strong></div><div class="stat"><div class="label">المقبوض في اليوم</div><strong>${money(report.received)}</strong></div><div class="stat"><div class="label">الديون القائمة</div><strong>${money(report.debt)}</strong></div></div><div class="section-head"><h2>الفواتير المسجلة في هذا اليوم</h2></div><div class="list">${rows || '<div class="empty">لا توجد فواتير في هذا التاريخ</div>'}</div><div class="section-head"><h2>الدفعات حسب الطريقة في هذا اليوم</h2></div><div class="card">${methodsHTML}</div><div class="row"><button class="btn grow" data-action="archive-print">طباعة الكشف</button><button class="btn secondary grow" data-action="archive-pdf">حفظ PDF</button></div>`;
  }
  async function printInvoiceArchive(key, target = null) {
    const report = await dailyCount(key), rows = report.active.filter(invoice => eventKey(invoice.date) === key).sort((a, b) => a.date.localeCompare(b.date));
    const methods = new Map(); report.active.forEach(invoice => (invoice.payments || []).filter(payment => eventKey(payment.date) === key).forEach(payment => { const name = payment.method || invoice.paymentMethod || 'غير محدد'; methods.set(name, (methods.get(name) || 0) + Number(payment.amount || 0)); }));
    const invoiceRows = rows.map(invoice => `<div class="card"><b>فاتورة #${invoice.id} · ${esc(invoice.customer || 'زبون نقدي')}</b><div class="muted">${dateTimeFmt(invoice.date)} · ${esc([...new Set((invoice.payments || []).map(payment => payment.method || invoice.paymentMethod || 'غير محدد'))].join('، ') || invoice.paymentMethod || 'غير مدفوع')}</div><div class="table-row"><span>الإجمالي ${money(netTotal(invoice))} · مدفوع ${money(paidAmount(invoice))}</span><b>متبقي ${money(dueAmount(invoice))}</b></div></div>`).join('');
    const methodRows = [...methods.entries()].map(([name, amount]) => `<div class="table-row"><span>${esc(name)}</span><b>${money(amount)}</b></div>`).join('');
    printHTML(`<h2>أرشيف الفواتير · ${esc(key)}</h2><div class="table-row"><span>إجمالي المبيعات</span><b>${money(report.sales)}</b></div><div class="table-row"><span>عدد الفواتير</span><b>${report.invoiceCount}</b></div><div class="table-row"><span>المقبوض</span><b>${money(report.received)}</b></div><div class="table-row"><span>الديون القائمة</span><b>${money(report.debt)}</b></div><h3>الفواتير</h3>${invoiceRows || '<p>لا توجد فواتير</p>'}<h3>الدفعات حسب الطريقة</h3>${methodRows || '<p>لا توجد دفعات</p>'}`, `أرشيف الفواتير ${key}`, target);
  }
  async function saveInvoiceArchivePDF(key) {
    const report = await dailyCount(key), invoices = report.active.filter(invoice => eventKey(invoice.date) === key).sort((a, b) => a.date.localeCompare(b.date));
    const lines = [`أرشيف الفواتير · ${key}`, `إجمالي المبيعات: ${money(report.sales)}`, `عدد الفواتير: ${report.invoiceCount}`, `المقبوض: ${money(report.received)}`, `الديون القائمة: ${money(report.debt)}`, ''];
    invoices.forEach(invoice => lines.push(`#${invoice.id} · ${invoice.customer || 'زبون نقدي'} · ${dateTimeFmt(invoice.date)} · الإجمالي ${money(netTotal(invoice))} · المدفوع ${money(paidAmount(invoice))} · المتبقي ${money(dueAmount(invoice))} · ${[...new Set((invoice.payments || []).map(payment => payment.method || invoice.paymentMethod || 'غير محدد'))].join('، ') || invoice.paymentMethod || 'غير مدفوع'}`));
    lines.push('', 'الدفعات حسب الطريقة');
    const methods = new Map(); report.active.forEach(invoice => (invoice.payments || []).filter(payment => eventKey(payment.date) === key).forEach(payment => { const method = payment.method || invoice.paymentMethod || 'غير محدد'; methods.set(method, (methods.get(method) || 0) + Number(payment.amount || 0)); }));
    methods.forEach((amount, method) => lines.push(`${method}: ${money(amount)}`));
    downloadArabicPDF(lines, `mystore-invoice-archive-${key}.pdf`); toast('تم حفظ كشف اليوم PDF');
  }

  financeHTML = async () => {
    const report = await dailyCount(financeDate);
    const products = report.products.map(product => ({
      ...product,
      profit: productProfit(product, report.active),
      sold: report.active.reduce((qty, invoice) => qty + invoice.items.reduce((n, item, index) => n + (item.productId === product.id ? Math.max(0, item.qty - returnedQty(invoice, index)) : 0), 0), 0)
    }));
    const top = [...products].sort((a, b) => b.sold - a.sold).slice(0, 5);
    return `<div class="row between"><div><h1>الصفحة المالية</h1><p class="sub">أسعار الشراء والبيع والأرباح · ${esc(financeDate)}</p></div></div><label class="field"><span>تاريخ التقرير المالي</span><input id="finance-date" class="input" type="date" value="${esc(financeDate)}"></label><div class="grid"><div class="stat"><div class="label">مبيعات اليوم</div><strong>${money(report.sales)}</strong></div><div class="stat"><div class="label">المقبوض</div><strong>${money(report.received)}</strong></div><div class="stat"><div class="label">الديون حتى نهاية اليوم</div><strong>${money(report.debt)}</strong></div><div class="stat"><div class="label">الربح الإجمالي</div><strong>${money(report.grossProfit)}</strong></div></div><div class="card"><div class="row between"><h2>صافي الربح بعد المصاريف</h2><b class="price">${money(report.netProfit)}</b></div><div class="muted">المصاريف: ${money(report.expenseTotal)}</div></div><div class="row"><button class="btn grow" data-action="finance-print">طباعة</button><button class="btn secondary grow" data-action="finance-pdf">حفظ PDF</button></div><div class="section-head"><h2>أسعار المنتجات وأرباحها</h2></div><div class="list">${products.map(product => `<div class="card"><div class="row between"><div><div class="item-title">${esc(product.name)}</div><div class="muted">شراء ${money(product.cost)} · بيع ${money(product.price)}</div><div class="muted">هامش الوحدة ${money(product.price - product.cost)} · ربح مسجل ${money(product.profit)} · مباع صافٍ ${product.sold}</div></div><button class="btn secondary small" data-action="finance-product" data-id="${product.id}">تعديل الأسعار</button></div></div>`).join('') || '<div class="empty">لا توجد منتجات</div>'}</div><div class="section-head"><h2>الأكثر مبيعاً</h2></div><div class="card">${top.map(product => `<div class="table-row"><span>${esc(product.name)}</span><b>${product.sold} قطعة</b></div>`).join('') || '<div class="muted">لا توجد مبيعات</div>'}</div><div class="section-head"><h2>المصاريف في التاريخ المحدد</h2><button class="btn small" data-action="add-expense">＋ تسجيل مصروف</button></div><div class="list">${report.expenses.filter(expense => eventKey(expense.date) === financeDate).map(expense => `<div class="list-item"><div class="grow">${esc(expense.title)}</div><b>${money(expense.amount)}</b></div>`).join('') || '<div class="empty">لا توجد مصاريف لهذا اليوم</div>'}</div><div class="section-head"><h2>المخزون الحالي</h2></div><div class="card">${report.products.map(product => `<div class="table-row"><span>${esc(product.name)}</span><b>${product.qty} قطعة</b></div>`).join('') || '<div class="muted">لا يوجد مخزون</div>'}</div>`;
  };
  function productProfit(product, invoices) {
    let profit = 0;
    for (const invoice of invoices) {
      if (invoice.voided) continue;
      const original = invoice.items.filter(item => !item.addedAt);
      const originalSubtotal = sum(original, item => item.price * item.qty);
      invoice.items.forEach((item, index) => {
        if (item.productId !== product.id) return;
        const returned = returnedQty(invoice, index);
        const refund = sum((invoice.returns || []).filter(row => row.itemIndex === index), row => row.refund);
        const discount = !item.addedAt && originalSubtotal ? Number(invoice.discount || 0) * item.price * item.qty / originalSubtotal : 0;
        profit += item.price * item.qty - discount - refund - Number(item.cost || 0) * (item.qty - returned);
      });
    }
    return profit;
  }
  function financeLines(key, report) {
    const lines = [`التقرير المالي · ${key}`, `المبيعات: ${money(report.sales)}`, `الفواتير: ${report.invoiceCount}`, `المقبوض: ${money(report.received)}`, `الديون القائمة: ${money(report.debt)}`, `الربح الإجمالي: ${money(report.grossProfit)}`, `المصاريف: ${money(report.expenseTotal)}`, `صافي الربح: ${money(report.netProfit)}`, '', 'المنتجات والأسعار والأرباح'];
    report.products.forEach(product => lines.push(`${product.name} · شراء ${money(product.cost)} · بيع ${money(product.price)} · ربح ${money(productProfit(product, report.active))} · مخزون ${product.qty}`));
    return lines;
  }
  async function printFinanceReport(key, target = null) { const report = await dailyCount(key); printHTML(`<h2>التقرير المالي · ${esc(key)}</h2>${financeLines(key, report).slice(1).map(line => `<div class="table-row">${esc(line)}</div>`).join('')}`, `التقرير المالي ${key}`, target); }
  async function saveFinancePDF(key) { const report = await dailyCount(key); downloadArabicPDF(financeLines(key, report), `mystore-finance-${key}.pdf`); toast('تم حفظ التقرير المالي كملف PDF'); }
  const baseBind = bindPage;
  bindPage = () => {
    baseBind();
    const archiveInput = $('#archive-date');
    if (archiveInput) archiveInput.addEventListener('change', () => { invoiceArchiveDate = archiveInput.value || todayKey(); render(); });
    const dateInput = $('#daily-date');
    if (dateInput) dateInput.addEventListener('change', () => { dailyCountDate = dateInput.value || todayKey(); render(); });
    const financeInput = $('#finance-date');
    if (financeInput) financeInput.addEventListener('change', () => { financeDate = financeInput.value || todayKey(); render(); });
  };

  async function printDailyCount(key, openWindow = true, target = null) {
    const report = await dailyCount(key);
    const rows = [...new Set([...report.productSales.map(row => row[0]), ...report.products.map(product => product.name)])].sort((a, b) => a.localeCompare(b, 'ar')).map(name => {
      const sold = report.productSales.find(row => row[0] === name)?.[1] || 0;
      const stock = report.products.find(product => product.name === name)?.qty ?? '—';
      return `<div class="table-row"><span>${esc(name)} · مباع ${sold}</span><b>المخزون ${stock}</b></div>`;
    }).join('');
    const html = `<h2>الجرد اليومي · ${esc(key)}</h2><div class="table-row"><span>إجمالي المبيعات</span><b>${money(report.sales)}</b></div><div class="table-row"><span>عدد الفواتير</span><b>${report.invoiceCount}</b></div><div class="table-row"><span>إجمالي المدفوع</span><b>${money(report.received)}</b></div><div class="table-row"><span>الديون القائمة حتى التاريخ</span><b>${money(report.debt)}</b></div><h3>المنتجات والكميات</h3>${rows}`;
    if (openWindow) printHTML(html, `الجرد اليومي ${key}`, target);
    return html;
  }
  async function saveHTMLAsPDF(key) {
    const report = await dailyCount(key);
    const lines = [`الجرد اليومي · ${key}`, `إجمالي المبيعات: ${money(report.sales)}`, `عدد الفواتير: ${report.invoiceCount}`, `إجمالي المدفوع: ${money(report.received)}`, `الديون القائمة: ${money(report.debt)}`, '', 'المنتجات والكميات'];
    report.products.forEach(product => lines.push(`${product.name} · مباع صافٍ: ${report.productSales.find(row => row[0] === product.name)?.[1] || 0} · متبقٍ: ${product.qty}`));
    downloadArabicPDF(lines, `mystore-daily-count-${key}.pdf`); toast('تم حفظ الجرد اليومي كملف PDF');
  }

  function downloadArabicPDF(lines, filename, preparedCanvases = null) {
    const width = 1190, height = 1684, margin = 84, lineHeight = 34, perPage = 44, pages = [];
    if (preparedCanvases?.length) preparedCanvases.forEach(canvas => pages.push(canvas.toDataURL('image/jpeg', 0.94).split(',')[1]));
    else for (let offset = 0; offset < lines.length || offset === 0; offset += perPage) {
      const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = height;
      const context = canvas.getContext('2d'); context.fillStyle = '#fff'; context.fillRect(0, 0, width, height);
      context.fillStyle = '#111'; context.direction = 'rtl'; context.textAlign = 'right'; context.font = '26px Tahoma, Arial, sans-serif';
      lines.slice(offset, offset + perPage).forEach((line, index) => {
        const y = margin + (index + 1) * lineHeight, maxWidth = width - margin * 2;
        let text = String(line), chunks = [];
        while (context.measureText(text).width > maxWidth) {
          let cut = text.length;
          while (cut > 1 && context.measureText(text.slice(0, cut)).width > maxWidth) cut--;
          const space = text.lastIndexOf(' ', cut); if (space > 0) cut = space;
          chunks.push(text.slice(0, cut)); text = text.slice(cut).trim();
        }
        chunks.push(text); chunks.forEach((chunk, part) => context.fillText(chunk, width - margin, y + part * lineHeight, maxWidth));
      });
      pages.push(canvas.toDataURL('image/jpeg', 0.9).split(',')[1]);
    }
    const encoder = new TextEncoder(), parts = [], offsets = [0]; let length = 0;
    const push = value => { const bytes = typeof value === 'string' ? encoder.encode(value) : value; parts.push(bytes); length += bytes.length; };
    push('%PDF-1.4\n%âãÏÓ\n');
    const objectCount = 2 + pages.length * 3;
    const object = (id, content) => { offsets[id] = length; push(`${id} 0 obj\n`); push(content); push('\nendobj\n'); };
    object(1, '<< /Type /Catalog /Pages 2 0 R >>');
    const pageIds = pages.map((_, index) => 3 + index * 3);
    object(2, `<< /Type /Pages /Kids [${pageIds.map(id => `${id} 0 R`).join(' ')}] /Count ${pages.length} >>`);
    pages.forEach((base64, index) => {
      const pageId = 3 + index * 3, contentId = pageId + 1, imageId = pageId + 2;
      const binary = atob(base64), jpeg = new Uint8Array(binary.length); for (let i = 0; i < binary.length; i++) jpeg[i] = binary.charCodeAt(i);
      object(pageId, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /XObject << /Im0 ${imageId} 0 R >> >> /Contents ${contentId} 0 R >>`);
      const content = encoder.encode('q 595 0 0 842 0 0 cm /Im0 Do Q');
      offsets[contentId] = length; push(`${contentId} 0 obj\n<< /Length ${content.length} >>\nstream\n`); push(content); push('\nendstream\nendobj\n');
      offsets[imageId] = length; push(`${imageId} 0 obj\n<< /Type /XObject /Subtype /Image /Width ${width} /Height ${height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpeg.length} >>\nstream\n`); push(jpeg); push('\nendstream\nendobj\n');
    });
    const xrefOffset = length; push(`xref\n0 ${objectCount + 1}\n0000000000 65535 f \n`);
    for (let id = 1; id <= objectCount; id++) push(`${String(offsets[id]).padStart(10, '0')} 00000 n \n`);
    push(`trailer\n<< /Size ${objectCount + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`);
    const blob = new Blob(parts, { type: 'application/pdf' }), url = URL.createObjectURL(blob), link = document.createElement('a');
    link.href = url; link.download = filename; link.click(); setTimeout(() => URL.revokeObjectURL(url), 3000);
  }

  async function addBarcodeToQueue(id) {
    const product = await get('products', id);
    if (!product?.barcode) { toast('أضف باركوداً صالحاً للمنتج أولاً'); return; }
    if (eanSVG(product.barcode).includes('صالحاً')) { toast('الطباعة التجميعية تدعم حالياً EAN-13 وUPC-A فقط'); return; }
    const existing = barcodeQueue.find(row => row.productId === id);
    if (existing) existing.copies++;
    else barcodeQueue.push({ productId: id, name: product.name, barcode: product.barcode, copies: 1 });
    toast('أُضيف الباركود إلى قائمة التجهيز'); render();
  }
  function openBarcodeQueue() {
    const body = () => `<div class="barcode-queue-list">${barcodeQueue.length ? barcodeQueue.map((row, index) => `<div class="card"><div class="row between"><div class="grow"><b>${esc(row.name)}</b><div class="mono muted">${esc(row.barcode)}</div></div><button class="icon-button" data-queue-remove="${index}" aria-label="حذف">×</button></div><label class="field"><span>عدد النسخ</span><input class="input" type="number" min="1" step="1" value="${row.copies}" data-queue-copies="${index}"></label></div>`).join('') : '<div class="empty">القائمة فارغة. أضف باركوداً من قائمة المنتجات.</div>'}</div><div class="row"><label class="field grow"><span>عرض الملصق (مم)</span><input id="barcode-width" class="input" type="number" min="20" max="95" value="45"></label><label class="field grow"><span>حجم ورق الطباعة</span><select id="barcode-paper" class="input"><option value="a4">A4</option><option value="58">حراري 58 مم</option><option value="80">حراري 80 مم</option></select></label></div><div class="row"><button class="btn grow" id="print-all-barcodes" ${barcodeQueue.length ? '' : 'disabled'}>طباعة الكل</button><button class="btn secondary grow" id="save-barcodes-pdf" ${barcodeQueue.length ? '' : 'disabled'}>حفظ PDF ‏(A4)</button></div><div class="row"><button class="btn secondary" id="clear-barcodes" ${barcodeQueue.length ? '' : 'disabled'}>مسح القائمة</button></div>`;
    openModal('تجهيز ملصقات الباركود', body());
    $('#modal-body').onclick = event => {
      const remove = event.target.closest('[data-queue-remove]');
      if (remove) { barcodeQueue.splice(Number(remove.dataset.queueRemove), 1); openBarcodeQueue(); return; }
      if (event.target.id === 'clear-barcodes') { barcodeQueue = []; openBarcodeQueue(); return; }
      if (event.target.id === 'save-barcodes-pdf') {
        barcodeQueue = barcodeQueue.map((row, index) => ({ ...row, copies: Math.max(1, Math.min(500, Math.floor(Number($(`[data-queue-copies="${index}"]`).value) || 1))) }));
        saveBarcodeQueuePDF(Number($('#barcode-width').value) || 45); return;
      }
      if (event.target.id === 'print-all-barcodes') {
        barcodeQueue = barcodeQueue.map((row, index) => ({ ...row, copies: Math.max(1, Math.min(500, Math.floor(Number($(`[data-queue-copies="${index}"]`).value) || 1))) }));
        const target = window.open('', '_blank'), width = Number($('#barcode-width').value) || 45, paper = $('#barcode-paper').value;
        refreshBarcodeQueue().then(valid => { if (valid) printBarcodeQueue(width, paper, target); else target?.close(); });
      }
    };
  }
  async function refreshBarcodeQueue() {
    for (const row of barcodeQueue) {
      if (row.productId == null) {
        if (!row.name || eanSVG(row.barcode).includes('صالحاً')) { toast('تعذر تجهيز باركود غير صالح'); return false; }
        continue;
      }
      const product = await get('products', row.productId);
      if (!product?.barcode || eanSVG(product.barcode).includes('صالحاً')) { toast(`تعذر تجهيز باركود ${row.name}؛ تحقق من المنتج`); return false; }
      row.name = product.name; row.barcode = product.barcode;
    }
    return barcodeQueue.length > 0;
  }
  function printBarcodeQueue(width, paper = 'a4', target = null) {
    const labels = barcodeQueue.flatMap(row => Array.from({ length: row.copies }, () => `<div class="barcode-label"><div>${eanSVG(row.barcode)}</div><div class="barcode-name">${esc(row.name)}</div></div>`)).join('');
    const thermal = paper === '58' || paper === '80', rollWidth = paper === '58' ? 58 : 80, labelWidth = thermal ? Math.min(width, rollWidth - 6) : width;
    const pageSize = paper === '58' ? '58mm 200mm' : paper === '80' ? '80mm 200mm' : 'A4';
    const grid = thermal ? '1fr' : `repeat(auto-fill,minmax(${Math.max(18, labelWidth)}mm,1fr))`;
    const page = `<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><title>ملصقات الباركود</title><style>@page{size:${pageSize};margin:${thermal ? '2mm' : '8mm'}}*{box-sizing:border-box}body{font:10px Tahoma,Arial;margin:0}.labels{display:grid;grid-template-columns:${grid};gap:2mm}.barcode-label{height:22mm;border:0.25mm dashed #aaa;display:flex;flex-direction:column;align-items:center;justify-content:center;overflow:hidden;break-inside:avoid;padding:1mm}.barcode-label svg{width:${Math.max(20, labelWidth - 4)}mm;height:13mm}.barcode-name{font-size:8px;white-space:nowrap;max-width:100%;overflow:hidden}</style><body><div class="labels">${labels}</div><script>onload=()=>setTimeout(()=>print(),250)<\/script></body></html>`;
    target ||= window.open('', '_blank');
    if (!target) { toast('اسمح بفتح نافذة الطباعة'); return; }
    target.document.open(); target.document.write(page); target.document.close();
  }

  async function saveBarcodeQueuePDF(width = 45) {
    if (!(await refreshBarcodeQueue())) return;
    const copies = barcodeQueue.flatMap(row => Array.from({ length: row.copies }, () => row));
    const columns = Math.max(1, Math.floor(1020 / (width * 11.2))), cellW = 1020 / columns, cellH = 215, startX = 85, startY = 80;
    const rowsPerPage = Math.floor((1684 - startY - 80) / cellH), perPage = columns * rowsPerPage, canvases = [];
    for (let index = 0; index < copies.length; index++) {
      const pageIndex = Math.floor(index / perPage), withinPage = index % perPage;
      if (!canvases[pageIndex]) { const page = document.createElement('canvas'); page.width = 1190; page.height = 1684; const pageContext = page.getContext('2d'); pageContext.fillStyle = '#fff'; pageContext.fillRect(0, 0, page.width, page.height); canvases.push(page); }
      const canvas = canvases[pageIndex], context = canvas.getContext('2d');
      const row = copies[index], x = startX + (withinPage % columns) * cellW, y = startY + Math.floor(withinPage / columns) * cellH;
      context.strokeStyle = '#bbb'; context.strokeRect(x, y, cellW - 12, cellH - 12);
      const svg = new Blob([eanSVG(row.barcode)], { type: 'image/svg+xml;charset=utf-8' }), url = URL.createObjectURL(svg);
      try {
        const image = new Image(); image.src = url;
        await new Promise((resolve, reject) => { image.onload = resolve; image.onerror = reject; });
        context.drawImage(image, x + 12, y + 15, cellW - 36, 125);
      } catch (error) { URL.revokeObjectURL(url); toast('تعذر رسم أحد الباركودات في ملف PDF'); return; }
      URL.revokeObjectURL(url); context.fillStyle = '#111'; context.font = '22px Tahoma, Arial'; context.textAlign = 'center'; context.direction = 'rtl';
      context.fillText(row.name, x + (cellW - 12) / 2, y + 169, cellW - 32);
      context.font = '18px monospace'; context.fillText(row.barcode, x + (cellW - 12) / 2, y + 196, cellW - 32);
    }
    downloadArabicPDF([], 'mystore-barcodes.pdf', canvases); toast('تم حفظ ملصقات الباركود بصيغة PDF');
  }

  function enableBarcodeCopies() {
    const preview = $('#barcode-preview'); if (!preview) return;
    if (!$('#barcode-copies')) preview.insertAdjacentHTML('beforeend', '<label class="field"><span>عدد النسخ</span><input id="barcode-copies" class="input" type="number" min="1" max="500" value="1"></label>');
    const button = preview.querySelector('[data-modal-action="print-barcode"]'); if (!button) return;
    button.textContent = 'إضافة إلى قائمة الطباعة';
    button.onclick = () => {
      const barcode = $('#f-barcode').value.trim(), name = $('#f-name').value.trim(), copies = Math.max(1, Math.min(500, Math.floor(Number($('#barcode-copies').value) || 1)));
      if (!name || eanSVG(barcode).includes('صالحاً')) { toast('أدخل اسم المنتج وباركود EAN-13 أو UPC-A صحيحاً'); return; }
      barcodeQueue.push({ productId: null, name, barcode, copies }); toast(`أضيف ${copies} ملصقاً إلى القائمة`);
    };
  }

  const baseModalAction = modalAction;
  modalAction = async (name, id) => {
    if (name === 'print-barcode') {
      const barcode = $('#f-barcode').value.trim(), label = $('#f-name').value.trim();
      if (!label || eanSVG(barcode).includes('صالحاً')) { toast('أدخل اسماً وباركود EAN-13 أو UPC-A صالحاً'); return; }
      barcodeQueue.push({ productId: null, name: label, barcode, copies: 1 });
      toast('أُضيف الملصق إلى قائمة التجهيز؛ افتح قائمة الطباعة من صفحة المنتجات');
      return;
    }
    const result = await baseModalAction(name, id);
    if (name === 'new-barcode') enableBarcodeCopies();
    return result;
  };
  const baseProductModal = productModal;
  productModal = async id => { await baseProductModal(id); enableBarcodeCopies(); };

  cashierHTML = async () => {
    const base = await (async () => {
      const products = await all('products');
      return `<h1>الكاشير</h1><p class="sub">ابحث بالاسم أو أدخل الباركود يدوياً أو امسحه بالكاميرا</p><div class="row"><div class="searchbox grow"><input id="cash-search" class="input" placeholder="اسم المنتج أو الباركود" value="${esc(searchText)}"></div><button class="btn secondary" data-action="scan">▣ كاميرا</button></div><div id="cash-results" class="list"></div><div class="section-head"><h2>سلة الفاتورة</h2><button class="btn secondary small" data-action="manual-item">＋ بند يدوي</button></div><label class="field"><span>اسم الزبون (اختياري)</span><input id="sale-customer" class="input" placeholder="اسم الزبون"></label><div class="list" id="cart-list">${cart.length ? cart.map((item, index) => `<div class="list-item"><div class="grow"><div class="item-title">${esc(item.name)}</div><div class="muted">${money(item.price)} للقطعة</div></div><div class="qty"><button data-cart="minus" data-i="${index}">−</button><b>${item.qty}</b><button data-cart="plus" data-i="${index}">+</button><button class="icon-button" data-cart="remove" data-i="${index}">×</button></div></div>`).join('') : '<div class="empty">السلة فارغة</div>'}</div><div class="total-bar"><label class="field"><span>الخصم (₪)</span><input id="sale-discount" class="input" type="number" min="0" step="0.01" value="0"></label><div class="row between"><b>الإجمالي</b><b id="sale-total">${money(cart.reduce((value, item) => value + item.price * item.qty, 0))}</b></div><button class="btn full" data-action="checkout" ${cart.length ? '' : 'disabled'}>إتمام الفاتورة</button></div>`;
    })();
    return base;
  };

  checkout = async () => {
    if (!cart.length || checkoutBusy) return;
    checkoutBusy = true;
    try {
      const subtotal = sum(cart, item => item.price * item.qty);
      const discount = Math.max(0, Math.min(subtotal, Number($('#sale-discount')?.value || 0)));
      const total = Math.max(0, subtotal - discount);
      const customerName = $('#sale-customer')?.value.trim() || '';
      $('#modal').addEventListener('close', () => { if (!checkoutCommitting) checkoutBusy = false; }, { once: true });
      openModal('إتمام الفاتورة', `<div class="card"><div class="row between"><span>الإجمالي</span><b>${money(total)}</b></div><div class="row between"><span>المتبقي بعد الدفع</span><b id="checkout-due">${money(0)}</b></div></div><label class="field"><span>حالة الدفع</span><select id="checkout-status" class="input"><option value="paid">مدفوعة بالكامل</option><option value="partial">مدفوعة جزئياً</option><option value="unpaid">غير مدفوعة</option></select></label><label class="field"><span>طريقة الدفع</span><input id="checkout-method" class="input" value="نقداً" placeholder="نقداً، بنك، محفظة…"></label><label class="field" id="checkout-paid-field"><span>المبلغ المدفوع (₪)</span><input id="checkout-paid" class="input" type="number" min="0" step="0.01" value="${total}"></label><button class="btn full" id="confirm-checkout">حفظ الفاتورة</button>`);
      const statusInput = $('#checkout-status'), paidInput = $('#checkout-paid');
      const syncPay = () => {
        if (statusInput.value === 'paid') paidInput.value = total;
        if (statusInput.value === 'unpaid') paidInput.value = 0;
        paidInput.disabled = statusInput.value !== 'partial';
        $('#checkout-due').textContent = money(Math.max(0, total - Number(paidInput.value || 0)));
      };
      statusInput.onchange = syncPay; paidInput.oninput = () => { $('#checkout-due').textContent = money(Math.max(0, total - Number(paidInput.value || 0))); };
      syncPay();
      $('#confirm-checkout').onclick = async () => {
        const amount = Number(paidInput.value);
        if (!Number.isFinite(amount) || amount < 0 || amount > total || (statusInput.value === 'partial' && (amount <= 0 || amount >= total))) { toast('تحقق من مبلغ الدفعة'); return; }
        if (statusInput.value !== 'paid' && !customerName) { toast('أدخل اسم الزبون لربط الرصيد بديونه'); $('#sale-customer')?.focus(); return; }
        const method = $('#checkout-method').value.trim() || 'غير محدد';
        const shopName = await setting('shopName', 'متجري');
        checkoutCommitting = true;
        const dbtx = db.transaction(['products', 'invoices', 'customers'], 'readwrite');
        const done = transactionDone(dbtx), products = dbtx.objectStore('products'), invoiceStore = dbtx.objectStore('invoices'), customerStore = dbtx.objectStore('customers');
        const abortWith = message => { toast(message); try { dbtx.abort(); } catch { } };
        const createInvoice = customerId => {
          const date = toISO();
          invoiceStore.add({ date, customer: customerName, customerId, shopName, paymentMethod: method, items: cart.map(item => ({ ...item })), subtotal, discount, total, grossTotal: total, netTotalApplied: true, history: [], payments: amount > 0 ? [{ amount, date, method }] : [], returns: [], voided: false });
        };
        const updateStock = customerId => {
          const stockItems = cart.filter(item => item.productId);
          if (!stockItems.length) { createInvoice(customerId); return; }
          let pending = stockItems.length, failed = false;
          stockItems.forEach(item => {
            const request = products.get(item.productId);
            request.onsuccess = () => {
              const product = request.result;
              if (!product || product.qty < item.qty) { failed = true; abortWith(`الكمية المتوفرة غير كافية: ${item.name}`); return; }
              product.qty -= item.qty; products.put(product);
              if (--pending === 0 && !failed) createInvoice(customerId);
            };
          });
        };
        const customerRequest = customerStore.getAll();
        customerRequest.onsuccess = () => {
          const existing = customerRequest.result.find(row => row.name.trim().toLowerCase() === customerName.toLowerCase());
          if (!customerName || existing) { updateStock(existing?.id || null); return; }
          const addCustomer = customerStore.add({ name: customerName, phone: '', created: toISO() });
          addCustomer.onsuccess = () => updateStock(addCustomer.result);
        };
        try {
          await done;
          cart = []; closeModal(); checkoutCommitting = false; checkoutBusy = false; toast('تم حفظ الفاتورة وتحديث المخزون'); setPage('invoices');
        } catch (error) { checkoutCommitting = false; checkoutBusy = false; toast(error.message || 'تعذر حفظ الفاتورة؛ لم يتم تطبيق خصم جزئي للمخزون'); }
      };
    } catch (error) { checkoutBusy = false; toast(error.message || 'تعذر بدء الفاتورة'); }
  };

  viewInvoice = async id => {
    const invoice = await get('invoices', id); if (!invoice) return;
    const audit = [...(invoice.history || []).map(row => `<div class="muted">تعديل ${dateFmt(row.date)} · ${row.items.map(item => `${esc(item.name)} × ${item.qty}`).join('، ')} · ${money(row.total)}</div>`), ...(invoice.returns || []).map(row => `<div class="muted">مرتجع ${dateFmt(row.date)} · ${esc(invoice.items[row.itemIndex]?.name || '')} × ${row.qty} · ${money(row.refund)}</div>`)].join('');
    openModal(`فاتورة #${id}`, `${invoiceMarkup(invoice)}<details class="card"><summary>سجل التعديلات والمرتجعات (للمراجعة)</summary>${audit || '<div class="muted">لا توجد تعديلات أو مرتجعات مسجلة.</div>'}</details><div class="row"><button class="btn grow" id="invoice-print">طباعة</button><button class="btn secondary grow" id="invoice-pdf">حفظ PDF</button></div><div class="row" style="margin-top:8px"><button class="btn secondary grow" id="invoice-amend">إضافة منتجات للفاتورة</button><button class="btn secondary grow" id="invoice-return">تسجيل مرتجع</button><button class="btn danger" id="invoice-delete">حذف الفاتورة</button></div>`);
    $('#invoice-print').onclick = () => printInvoice(invoice);
    $('#invoice-pdf').onclick = () => saveInvoicePDF(invoice);
    $('#invoice-amend').onclick = () => amendInvoiceModal(invoice.id);
    $('#invoice-return').onclick = () => returnModal(invoice.id);
    $('#invoice-delete').onclick = () => deleteInvoiceSafely(invoice.id);
  };
  invoiceMarkup = invoice => {
    const paymentRows = (invoice.payments || []).map(payment => `<div class="table-row"><span>${money(payment.amount)} · ${esc(payment.method || invoice.paymentMethod || 'غير محدد')}</span><span>${dateTimeFmt(payment.date)}</span></div>`).join('');
    const methods = [...new Set((invoice.payments || []).map(payment => payment.method || invoice.paymentMethod || 'غير محدد'))];
    return `<div id="invoice-paper"><div style="text-align:center"><h2>${esc(invoice.shopName || 'متجري')}</h2><p class="muted">فاتورة بيع #${invoice.id}<br>${dateTimeFmt(invoice.date)}</p></div>${invoice.customer ? `<p>الزبون: ${esc(invoice.customer)}</p>` : ''}${invoice.items.map((item, index) => { const qty = Math.max(0, item.qty - returnedQty(invoice, index)), refund = sum((invoice.returns || []).filter(row => row.itemIndex === index), row => row.refund), originalSubtotal = sum(invoice.items.filter(line => !line.addedAt), line => line.price * line.qty), lineDiscount = !item.addedAt && originalSubtotal ? Number(invoice.discount || 0) * item.price * item.qty / originalSubtotal : 0; return qty ? `<div class="table-row"><span>${esc(item.name)} × ${qty}</span><b>${money(Math.max(0, item.price * item.qty - lineDiscount - refund))}</b></div>` : ''; }).join('')}${invoice.discount ? `<div class="table-row"><span>الخصم</span><b>− ${money(invoice.discount)}</b></div>` : ''}<div class="table-row"><b>الإجمالي</b><b>${money(netTotal(invoice))}</b></div><div class="table-row"><span>المدفوع</span><b>${money(paidAmount(invoice))}</b></div><div class="table-row"><span>المتبقي</span><b>${money(dueAmount(invoice))}</b></div><div class="table-row"><span>طريقة الدفع</span><b>${esc(methods.join('، ') || invoice.paymentMethod || 'غير مدفوع')}</b></div><h3>سجل الدفعات</h3>${paymentRows || '<div class="muted">لا توجد دفعات مسجلة</div>'}<p class="small-note" style="text-align:center">شكراً لزيارتكم</p></div>`;
  };
  returnsHTML = async () => {
    const invoices = (await all('invoices')).filter(invoice => !invoice.voided && invoice.items.some(item => item.productId));
    return `<h1>المرتجعات</h1><p class="sub">اختر فاتورة لإرجاع كمية وإعادتها للمخزون</p><div class="list">${invoices.length ? invoices.map(invoice => `<div class="list-item"><div class="avatar">↶</div><div class="grow"><div class="item-title">فاتورة #${invoice.id} ${invoice.customer ? `· ${esc(invoice.customer)}` : ''}</div><div class="muted">${dateFmt(invoice.date)} · الصافي ${money(netTotal(invoice))}</div></div><button class="btn secondary small" data-action="return-invoice" data-id="${invoice.id}">إرجاع</button></div>`).join('') : '<div class="empty">لا توجد فواتير بها منتجات مخزنية</div>'}</div>`;
  };
  printInvoice = invoice => printHTML(invoiceMarkup(invoice), `فاتورة ${invoice.id}`);
  async function deleteInvoiceSafely(id) {
    const invoice = await get('invoices', id);
    if (!invoice) return;
    const received = paidAmount(invoice), due = dueAmount(invoice);
    if (!confirm(`حذف الفاتورة #${id} نهائياً؟ سيُلغى بيعها ودفعاتها ورصيد دينها من التقارير، ويُعاد للمخزون ما لم يُرجع سابقاً. المقبوض المسجل ${money(received)} والرصيد ${money(due)}.`)) return;
    const tx = db.transaction(['products', 'invoices'], 'readwrite'), done = transactionDone(tx);
    const products = tx.objectStore('products'), invoiceStore = tx.objectStore('invoices');
    const invoiceReq = invoiceStore.get(id);
    invoiceReq.onsuccess = () => {
      const fresh = invoiceReq.result;
      if (!fresh) { try { tx.abort(); } catch {} return; }
      const productReq = products.getAll();
      productReq.onsuccess = () => {
        const byId = new Map(productReq.result.map(product => [product.id, product])), restore = new Map();
        (fresh.items || []).forEach((item, index) => {
          if (item.productId) restore.set(item.productId, (restore.get(item.productId) || 0) + Math.max(0, Number(item.qty || 0) - returnedQty(fresh, index)));
        });
        for (const [productId, quantity] of restore) {
          const product = byId.get(productId);
          if (!product) { try { tx.abort(); } catch {} toast('تعذر الحذف: أحد منتجات الفاتورة غير موجود، لم تتغير البيانات'); return; }
          product.qty = Number(product.qty || 0) + quantity; products.put(product);
        }
        invoiceStore.delete(id);
      }
    };
    try { await done; closeModal(); toast('حُذفت الفاتورة وصُححت الأرصدة والمخزون'); render(); }
    catch (error) { console.error(error); toast('تعذر حذف الفاتورة'); }
  }

  customersHTML = async () => {
    const [customers, invoices] = await Promise.all([all('customers'), all('invoices')]);
    return `<div class="row between"><div><h1>الزبائن</h1><p class="sub">الأرصدة وكشوف الحساب</p></div><button class="btn" data-action="add-customer">＋ إضافة</button></div><div class="list">${customers.length ? customers.map(customer => { const related = invoices.filter(invoice => invoice.customerId === customer.id && !invoice.voided), due = sum(related, dueAmount); return `<div class="card"><div class="row"><div class="avatar">♙</div><div class="grow"><div class="item-title">${esc(customer.name)}</div><div class="muted">${esc(customer.phone || 'لا يوجد رقم')}</div></div><div class="price">${money(due)}<div class="muted">الرصيد</div></div></div><hr class="divider"><div class="row"><button class="btn secondary small grow" data-action="customer-statement" data-id="${customer.id}">كشف حساب</button>${due > 0 ? `<button class="btn small" data-action="customer-pay" data-id="${customer.id}">تسجيل تسديد</button>` : ''}<button class="btn danger small" data-action="delete-customer" data-id="${customer.id}">حذف زبون</button></div></div>`; }).join('') : '<div class="empty">أضف زبائنك لتسجيل المبيعات الآجلة</div>'}</div>`;
  };

  async function deleteSettledCustomer(id) {
    const [customer, invoices] = await Promise.all([get('customers', id), all('invoices')]);
    if (!customer) return;
    if (sum(invoices.filter(invoice => invoice.customerId === id && !invoice.voided), dueAmount) > 0) { toast('لا يمكن حذف زبون لديه دين مفتوح؛ سجّل التسديد أولاً.'); return; }
    if (!confirm(`حذف الزبون ${customer.name}؟ ستبقى فواتيره السابقة محفوظة باسمه.`)) return;
    const tx = db.transaction(['customers', 'invoices'], 'readwrite'), done = transactionDone(tx);
    const customers = tx.objectStore('customers'), invoiceStore = tx.objectStore('invoices'), request = invoiceStore.getAll();
    request.onsuccess = () => {
      request.result.filter(invoice => invoice.customerId === id).forEach(invoice => { delete invoice.customerId; invoiceStore.put(invoice); });
      customers.delete(id);
    };
    try { await done; toast('حُذف الزبون وبقي سجل فواتيره'); render(); }
    catch (error) { console.error(error); toast('تعذر حذف الزبون'); }
  }

  function saveInvoicePDF(invoice) {
    const lines = [invoice.shopName || 'متجري', `فاتورة بيع #${invoice.id}`, dateFmt(invoice.date), invoice.customer ? `الزبون: ${invoice.customer}` : '', ''];
    invoice.items.forEach((item, index) => { const qty = Math.max(0, item.qty - returnedQty(invoice, index)), refund = sum((invoice.returns || []).filter(row => row.itemIndex === index), row => row.refund), originalSubtotal = sum(invoice.items.filter(line => !line.addedAt), line => line.price * line.qty), lineDiscount = !item.addedAt && originalSubtotal ? Number(invoice.discount || 0) * item.price * item.qty / originalSubtotal : 0; if (qty) lines.push(`${item.name} × ${qty}     ${money(Math.max(0, item.price * item.qty - lineDiscount - refund))}`); });
    if (invoice.discount) lines.push(`الخصم: ${money(invoice.discount)}`);
    lines.push('', `الإجمالي: ${money(netTotal(invoice))}`, `المدفوع: ${money(paidAmount(invoice))}`, `المتبقي: ${money(dueAmount(invoice))}`, `طرق الدفع: ${[...new Set((invoice.payments || []).map(payment => payment.method || invoice.paymentMethod || 'غير محدد'))].join('، ') || invoice.paymentMethod || 'غير مدفوع'}`, 'سجل الدفعات:');
    (invoice.payments || []).forEach(payment => lines.push(`${dateTimeFmt(payment.date)} · ${payment.method || invoice.paymentMethod || 'غير محدد'} · ${money(payment.amount)}`));
    lines.push('شكراً لزيارتكم');
    downloadArabicPDF(lines.filter(Boolean), `mystore-invoice-${invoice.id}.pdf`); toast('تم إنشاء ملف PDF للفاتورة');
  }

  returnModal = async id => {
    const invoice = await get('invoices', id); if (!invoice) return;
    const lines = (invoice.items || []).map((item, index) => {
      if (!item.productId) return '';
      const remaining = Number(item.qty) - returnedQty(invoice, index);
      return `<label class="list-item"><span class="grow">${esc(item.name)}<div class="muted">المتاح للإرجاع ${remaining} · قيمة الإرجاع ${money(returnAmount(invoice, index, 1))} للقطعة</div></span><input class="input return-qty" data-index="${index}" type="number" min="0" max="${remaining}" step="1" value="0" style="max-width:100px"></label>`;
    }).join('');
    openModal(`مرتجع فاتورة #${id}`, `${lines || '<div class="empty">لا توجد أصناف مخزنية قابلة للإرجاع</div>'}<label class="field"><span>طريقة المعالجة</span><select class="input" id="return-mode"><option value="debt" ${dueAmount(invoice) > 0 ? 'selected' : ''}>تخفيض رصيد الدين</option><option value="refund" ${dueAmount(invoice) <= 0 ? 'selected' : ''}>خصم المبلغ من المقبوض</option></select></label><div class="row between"><span>الإجمالي الصافي الحالي</span><b>${money(netTotal(invoice))}</b></div><button class="btn full" id="save-return">تأكيد المرتجع</button>`);
    $('#save-return').onclick = async () => {
      const chosen = $$('.return-qty').map(input => ({ index: Number(input.dataset.index), qty: Number(input.value) })).filter(row => row.qty > 0);
      if (!chosen.length || chosen.some(row => !Number.isInteger(row.qty))) { toast('أدخل كميات صحيحة للإرجاع'); return; }
      const dbtx = db.transaction(['products', 'invoices'], 'readwrite'), done = transactionDone(dbtx), productStore = dbtx.objectStore('products'), invoiceStore = dbtx.objectStore('invoices');
      const abortWith = message => { toast(message); try { dbtx.abort(); } catch { } };
      const invoiceRequest = invoiceStore.get(id);
      invoiceRequest.onsuccess = () => {
        const fresh = invoiceRequest.result;
        if (!fresh) { abortWith('الفاتورة غير موجودة'); return; }
        const entries = [];
        for (const row of chosen) {
          const item = fresh.items[row.index], already = returnedQty(fresh, row.index);
          if (!item?.productId || row.qty > item.qty - already) { abortWith('كمية الإرجاع تتجاوز الكمية المتاحة'); return; }
          entries.push({ row, item, request: productStore.get(item.productId) });
        }
        let pending = entries.length, failed = false;
        entries.forEach(entry => entry.request.onsuccess = () => {
          const product = entry.request.result;
          if (!product) { failed = true; abortWith(`المنتج ${entry.item.name} غير موجود بالمخزون`); return; }
          entry.product = product;
          if (--pending !== 0 || failed) return;
        const refunded = sum(entries, row => returnAmount(fresh, row.row.index, row.row.qty)), currentNet = netTotal(fresh), date = toISO(), mode = $('#return-mode').value;
          if (refunded > currentNet) { abortWith('قيمة المرتجع أكبر من صافي الفاتورة'); return; }
          if (!fresh.netTotalApplied) fresh.grossTotal = Number(fresh.total);
          fresh.total = Math.max(0, currentNet - refunded); fresh.netTotalApplied = true; fresh.returns ||= [];
          entries.forEach(({ row, item, product }) => { product.qty += row.qty; productStore.put(product); fresh.returns.push({ itemIndex: row.index, qty: row.qty, date, refund: returnAmount(fresh, row.index, row.qty), mode }); });
          invoiceStore.put(fresh);
        });
      };
      try { await done; const updated = await get('invoices', id); closeModal(); toast(`تم تسجيل المرتجع. صافي الفاتورة ${money(netTotal(updated))}`); render(); }
      catch (error) { toast(error.message || 'تعذر تسجيل المرتجع؛ بقي المخزون والفاتورة كما كانا'); }
    };
  };

  async function amendInvoiceModal(id) {
    const invoice = await get('invoices', id); if (!invoice) return;
    openModal(`تعديل الفاتورة #${id}`, `<p class="notice">الإضافة تسجل كتعديل مؤرخ، وتخصم المخزون مرة واحدة عند الحفظ.</p><div class="searchbox"><input id="amend-search" class="input" placeholder="ابحث عن منتج"></div><div id="amend-results" class="list"></div><div id="amend-cart" class="list"></div><button class="btn full" id="save-amend" disabled>حفظ الإضافات</button>`);
    const additions = new Map();
    const refresh = async () => {
      const query = $('#amend-search').value.trim().toLowerCase();
      const products = (await all('products')).filter(product => product.name.toLowerCase().includes(query) || String(product.barcode || '').includes(query)).slice(0, 12);
      $('#amend-results').innerHTML = products.map(product => `<button class="list-item quick" data-amend-add="${product.id}"><span class="grow">${esc(product.name)} · متوفر ${product.qty}</span><b>${money(product.price)}</b></button>`).join('');
      $('#amend-cart').innerHTML = [...additions.values()].map(item => `<div class="list-item"><span class="grow">${esc(item.name)} × ${item.qty}</span><button class="icon-button" data-amend-remove="${item.productId}">−</button></div>`).join('');
      $('#save-amend').disabled = additions.size === 0;
    };
    $('#amend-search').oninput = refresh;
    $('#modal-body').onclick = async event => {
      const addButton = event.target.closest('[data-amend-add]'), removeButton = event.target.closest('[data-amend-remove]');
      if (addButton) { const product = await get('products', Number(addButton.dataset.amendAdd)); if (product) { const item = additions.get(product.id) || { productId: product.id, name: product.name, price: Number(product.price), cost: Number(product.cost), qty: 0 }; if (item.qty < product.qty) item.qty++; additions.set(product.id, item); await refresh(); } }
      if (removeButton) { const item = additions.get(Number(removeButton.dataset.amendRemove)); if (item && --item.qty <= 0) additions.delete(item.productId); await refresh(); }
      if (event.target.id === 'save-amend') {
        const dbtx = db.transaction(['products', 'invoices'], 'readwrite'), done = transactionDone(dbtx), productStore = dbtx.objectStore('products'), invoiceStore = dbtx.objectStore('invoices');
        const abortWith = message => { toast(message); try { dbtx.abort(); } catch { } };
        const invoiceRequest = invoiceStore.get(id);
        invoiceRequest.onsuccess = () => {
          const fresh = invoiceRequest.result;
          if (!fresh) { abortWith('الفاتورة غير موجودة'); return; }
          const items = [...additions.values()].map(item => ({ ...item, addedAt: toISO() }));
          const requests = items.map(item => ({ item, request: productStore.get(item.productId) }));
          let pending = requests.length, failed = false;
          requests.forEach(entry => entry.request.onsuccess = () => {
            entry.product = entry.request.result;
            if (!entry.product || entry.product.qty < entry.item.qty) { failed = true; abortWith(`المخزون غير كافٍ: ${entry.item.name}`); return; }
            if (--pending !== 0 || failed) return;
            requests.forEach(({ item, product }) => { product.qty -= item.qty; productStore.put(product); });
            const addedTotal = sum(items, item => item.price * item.qty);
            if (!fresh.netTotalApplied) fresh.grossTotal = Number(fresh.total) + returnValue(fresh);
            fresh.total = netTotal(fresh) + addedTotal; fresh.netTotalApplied = true;
            fresh.subtotal = Number(fresh.subtotal || 0) + addedTotal;
            fresh.items.push(...items); fresh.history ||= []; fresh.history.push({ type: 'items-added', date: toISO(), items, total: addedTotal });
            invoiceStore.put(fresh);
          });
        };
        try { await done; closeModal(); toast('تم تعديل الفاتورة وتحديث المخزون'); render(); }
        catch (error) { toast(error.message || 'تعذر تعديل الفاتورة؛ بقيت الفاتورة والمخزون دون تغيير'); }
      }
    };
    await refresh();
  }

  paymentModal = async id => {
    const invoice = await get('invoices', id); if (!invoice) return;
    const due = dueAmount(invoice);
    openModal('تسجيل دفعة', `<p>المتبقي: <b>${money(due)}</b></p><label class="field"><span>طريقة الدفع</span><input id="pay-method" class="input" value="نقداً"></label><label class="field"><span>المبلغ (₪)</span><input id="pay-amount" type="number" min="0.01" max="${due}" step="0.01" class="input"></label><button id="save-payment" class="btn full">تسجيل الدفعة</button>`);
    $('#save-payment').onclick = async () => {
      const amount = Number($('#pay-amount').value); if (amount <= 0 || amount > due) { toast('المبلغ غير صالح'); return; }
      invoice.payments ||= []; invoice.payments.push({ amount, date: toISO(), method: $('#pay-method').value.trim() || 'غير محدد' });
      await put('invoices', invoice); closeModal(); toast('تم تسجيل الدفعة'); render();
    };
  };

  async function stableSnapshot() {
    const names = Object.values(STORE), transaction = db.transaction(names, 'readonly'), done = transactionDone(transaction);
    const requests = names.map(name => reqP(transaction.objectStore(name).getAll()));
    const rows = await Promise.all(requests); await done;
    const stores = Object.fromEntries(names.map((name, index) => [name, rows[index].sort((a, b) => String(a.id ?? a.key).localeCompare(String(b.id ?? b.key)))]));
    return stores;
  }
  async function sha256(value) {
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
    return [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('');
  }
  async function backupDocument() {
    const stores = await stableSnapshot();
    const fingerprint = await sha256(JSON.stringify(stores));
    return { document: { format: 'mystore-backup', version: 2, exportedAt: toISO(), checksum: fingerprint, stores }, fingerprint };
  }
  settingsHTML = async () => {
    const shop = await setting('shopName', '');
    const meta = JSON.parse(localStorage.getItem(BACKUP_META_KEY) || 'null');
    return `<h1>الإعدادات</h1><p class="sub">بيانات المتجر والنسخ الاحتياطي اليدوي</p><div class="card"><label class="field"><span>اسم المتجر</span><input id="shop-setting" class="input" value="${esc(shop)}" placeholder="اسم المحل"></label><button class="btn full" data-action="save-shop">حفظ الاسم</button></div><div class="card"><h2>النسخ الاحتياطي</h2><p class="muted">ملف واحد يشمل المنتجات والفواتير والعملاء والدفعات والمرتجعات والمصاريف والإعدادات.</p><div class="muted" id="backup-status">${meta?.date ? `آخر نسخة على هذا الجهاز: ${dateFmt(meta.date)} · ${new Date(meta.date).toLocaleTimeString('ar-PS')}` : 'لم تُسجل نسخة احتياطية على هذا الجهاز بعد.'}</div><div class="list" style="margin-top:12px"><button class="btn full" data-backup="create">إنشاء نسخة احتياطية</button><button class="btn secondary full" data-backup="restore">استعادة نسخة احتياطية</button></div></div><div class="notice">النسخ يدوي. احتفظ بالملف وانقله إلى الهاتف الآخر بالطريقة التي تفضلها. إن لم يدعم المتصفح تحديث ملف موجود، ينزّل نسخة جديدة باسم وتاريخ واضحين. الاستعادة تستبدل بيانات هذا الجهاز بعد التحقق والتأكيد.</div><div class="card"><div class="row between"><span>حالة الاتصال</span><b>${navigator.onLine ? 'متصل' : 'دون إنترنت'}</b></div><div class="muted">يمكن استخدام التطبيق بعد تحميل ملفاته أول مرة.</div></div>`;
  };
  const bindSettingsActions = bindEnhancements;
  bindEnhancements = () => {
    bindSettingsActions();
    document.querySelectorAll('[data-backup]').forEach(button => button.addEventListener('click', () => button.dataset.backup === 'create' ? createBackup() : chooseRestoreFile()));
    document.querySelectorAll('[data-action="delete-customer"]').forEach(button => button.addEventListener('click', () => deleteSettledCustomer(Number(button.dataset.id))));
    document.querySelectorAll('[data-invoice-delete]').forEach(button => button.addEventListener('click', () => deleteInvoiceSafely(Number(button.dataset.invoiceDelete))));
  };

  async function createBackup() {
    try {
      let pickerRequest = null;
      if ('showOpenFilePicker' in window && confirm('إذا كان لديك ملف نسخة سابق، اختر «موافق» لتحديده وتحديثه. اختر «إلغاء» لتنزيل ملف نسخة جديد.')) {
        try { pickerRequest = window.showOpenFilePicker({ multiple: false, types: [{ description: 'نسخة MyStore', accept: { 'application/json': ['.json'] } }] }); }
        catch (error) { console.warn('File picker is unavailable; a new file will be downloaded.', error); }
      }
      const { document: payload, fingerprint } = await backupDocument();
      const meta = JSON.parse(localStorage.getItem(BACKUP_META_KEY) || 'null');
      if (meta?.fingerprint === fingerprint && !pickerRequest) { toast('النسخة الاحتياطية الحالية محدثة، لا توجد تغييرات'); return; }
      let savedInPlace = false;
      if (pickerRequest) {
        try {
          const [handle] = await pickerRequest;
          if (meta?.fingerprint === fingerprint) { toast('النسخة الاحتياطية الحالية محدثة، لا توجد تغييرات'); return; }
          const existing = JSON.parse(await (await handle.getFile()).text());
          if (existing?.format !== 'mystore-backup' || ![1, 2].includes(Number(existing.version))) throw new Error('الملف المحدد ليس نسخة MyStore معروفة');
          const writable = await handle.createWritable(); await writable.write(JSON.stringify(payload, null, 2)); await writable.close(); savedInPlace = true;
        } catch (error) { if (error.name === 'AbortError') return; toast('تعذر تحديث الملف المحدد؛ سيتم تنزيل نسخة جديدة.'); }
      }
      if (!savedInPlace) {
        const link = document.createElement('a'), url = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' }));
        link.href = url; link.download = `mystore-backup-${todayKey()}-${new Date().toTimeString().slice(0, 8).replaceAll(':', '')}.json`; link.click(); setTimeout(() => URL.revokeObjectURL(url), 2000);
      }
      const date = toISO(); localStorage.setItem(BACKUP_META_KEY, JSON.stringify({ fingerprint, date }));
      toast(savedInPlace ? 'تم تحديث ملف النسخة الاحتياطية' : 'تم تنزيل ملف النسخة الاحتياطية'); render();
    } catch (error) { console.error(error); toast('تعذر إنشاء النسخة الاحتياطية'); }
  }
  async function chooseRestoreFile() {
    if ('showOpenFilePicker' in window) {
      try { const [handle] = await window.showOpenFilePicker({ multiple: false, types: [{ description: 'نسخة MyStore', accept: { 'application/json': ['.json'] } }] }); await restoreFile(await handle.getFile()); return; }
      catch (error) { if (error.name === 'AbortError') return; }
    }
    const input = document.createElement('input'); input.type = 'file'; input.accept = '.json,application/json'; input.onchange = () => { if (input.files[0]) restoreFile(input.files[0]); }; input.click();
  }
  restoreFile = async file => {
    try {
      const payload = JSON.parse(await file.text());
      if (payload?.format !== 'mystore-backup' || ![1, 2].includes(Number(payload.version)) || !payload.stores || typeof payload.stores !== 'object') throw new Error('صيغة النسخة أو إصدارها غير مدعوم');
      for (const store of Object.values(STORE)) if (!Array.isArray(payload.stores[store])) throw new Error(`النسخة ناقصة: ${store}`);
      for (const store of Object.values(STORE)) {
        const keys = new Set();
        for (const row of payload.stores[store]) {
          const key = store === 'settings' ? row?.key : row?.id;
          if (key === undefined || key === null || keys.has(String(key))) throw new Error(`مفتاح مفقود أو مكرر في ${store}`);
          keys.add(String(key));
        }
      }
      for (const row of payload.stores.products) if (!row || typeof row.name !== 'string' || !row.name.trim() || !Number.isInteger(Number(row.qty)) || Number(row.qty) < 0 || !Number.isFinite(Number(row.price)) || Number(row.price) < 0 || (row.cost !== undefined && (!Number.isFinite(Number(row.cost)) || Number(row.cost) < 0))) throw new Error('بيانات منتج غير سليمة');
      for (const row of payload.stores.customers) if (!row || typeof row.name !== 'string' || !row.name.trim()) throw new Error('بيانات زبون غير سليمة');
      for (const row of payload.stores.expenses) if (!row || typeof row.title !== 'string' || !row.title.trim() || !Number.isFinite(Number(row.amount)) || Number(row.amount) < 0) throw new Error('بيانات مصروف غير سليمة');
      for (const row of payload.stores.invoices) {
        if (!row || !Array.isArray(row.items) || !Number.isFinite(Number(row.total)) || !row.items.every(item => item && typeof item.name === 'string' && Number.isInteger(Number(item.qty)) && Number(item.qty) > 0 && Number.isFinite(Number(item.price)) && Number(item.price) >= 0 && (item.cost === undefined || (Number.isFinite(Number(item.cost)) && Number(item.cost) >= 0)))) throw new Error('بيانات فاتورة غير سليمة');
        if (row.payments !== undefined && (!Array.isArray(row.payments) || !row.payments.every(payment => Number.isFinite(Number(payment.amount)) && Number(payment.amount) >= 0))) throw new Error('بيانات دفعة غير سليمة');
        if (row.returns !== undefined && (!Array.isArray(row.returns) || !row.returns.every(item => Number.isInteger(Number(item.itemIndex)) && item.itemIndex >= 0 && item.itemIndex < row.items.length && Number.isInteger(Number(item.qty)) && item.qty > 0 && Number.isFinite(Number(item.refund)) && item.refund >= 0))) throw new Error('بيانات مرتجع غير سليمة');
      }
      if (Number(payload.version) === 2 && await sha256(JSON.stringify(payload.stores)) !== payload.checksum) throw new Error('فشل التحقق من سلامة النسخة');
      if (!confirm(`سيتم استبدال بيانات هذا الجهاز بمحتوى النسخة بتاريخ ${payload.exportedAt ? dateFmt(payload.exportedAt) : 'غير معروف'}. تأكد من حفظ نسخة من البيانات الحالية. هل تريد المتابعة؟`)) return;
      const dbtx = db.transaction(Object.values(STORE), 'readwrite'), done = transactionDone(dbtx);
      try {
        for (const name of Object.values(STORE)) {
          const objectStore = dbtx.objectStore(name); objectStore.clear();
          payload.stores[name].forEach(row => objectStore.put(row));
        }
        await done;
      } catch (error) { try { dbtx.abort(); } catch { } try { await done; } catch { } throw error; }
      const fingerprint = Number(payload.version) === 2 ? payload.checksum : await sha256(JSON.stringify(payload.stores));
      localStorage.setItem(BACKUP_META_KEY, JSON.stringify({ fingerprint, date: payload.exportedAt || toISO() }));
      toast('تم التحقق من النسخة واستعادة البيانات'); render();
    } catch (error) { console.error(error); toast(error.message || 'تعذرت استعادة النسخة؛ بقيت البيانات الحالية كما هي'); }
  };
  backup = createBackup;

  customerPaymentModal = async id => {
    const customer = await get('customers', id);
    const invoices = (await all('invoices')).filter(invoice => invoice.customerId === id && !invoice.voided && dueAmount(invoice) > 0).sort((a, b) => a.date.localeCompare(b.date));
    const due = sum(invoices, invoice => dueAmount(invoice));
    openModal('تسديد دين الزبون', `<p>${esc(customer?.name || '')} · الرصيد ${money(due)}</p><label class="field"><span>طريقة الدفع</span><input id="customer-pay-method" class="input" value="نقداً"></label><label class="field"><span>المبلغ (₪)</span><input id="customer-pay" class="input" type="number" min="0.01" max="${due}" step="0.01"></label><button id="save-customer-pay" class="btn full">تسجيل التسديد</button>`);
    $('#save-customer-pay').onclick = async () => {
      let amount = Number($('#customer-pay').value); if (amount <= 0 || amount > due) { toast('المبلغ غير صالح'); return; }
      const method = $('#customer-pay-method').value.trim() || 'غير محدد';
      const dbtx = db.transaction('invoices', 'readwrite'), done = transactionDone(dbtx), store = dbtx.objectStore('invoices'), request = store.getAll();
      request.onsuccess = () => {
        const current = request.result.filter(invoice => invoice.customerId === id && !invoice.voided && dueAmount(invoice) > 0).sort((a, b) => a.date.localeCompare(b.date));
        let remainingAmount = amount; const date = toISO();
        for (const invoice of current) {
          const part = Math.min(remainingAmount, dueAmount(invoice));
          if (part > 0) { invoice.payments ||= []; invoice.payments.push({ amount: part, date, method }); store.put(invoice); remainingAmount -= part; }
          if (remainingAmount <= 0) break;
        }
        if (remainingAmount > 0) { try { dbtx.abort(); } catch { } }
      };
      try { await done; closeModal(); toast('تم تسجيل التسديد'); render(); }
      catch (error) { toast(error.message || 'تعذر حفظ التسديد؛ لم تتغير ديون الزبون'); }
    };
  };

})();
