/* Enhancements for the existing MyStore PWA. IndexedDB schema stays compatible. */
(() => {
  let lowStockOnly = false;
  let outOfStockOnly = false;
  let dailyCountDate = todayKey();
  let invoiceArchiveDate = todayKey();
  let financeDate = todayKey();
  
  let checkoutCommitting = false;
  const BACKUP_META_KEY = 'mystore-backup-meta-v2';
  const toISO = () => new Date().toISOString();
  const sum = (items, fn) => items.reduce((value, item) => value + Number(fn(item) || 0), 0);
  const returnValue = invoice => sum(invoice.returns || [], item => item.refund);
  const cashRefundValue = invoice => sum((invoice.returns || []).filter(item => item.mode !== 'debt'), item => item.refund);
  const returnedQty = (invoice, index) => sum((invoice.returns || []).filter(item => item.itemIndex === index), item => item.qty);
  const returnAmount = (invoice, index, qty) => {
    const item = invoice.items[index]; if (!item) return 0;
    const originalSubtotal = sum((invoice.items || []).filter(line => !line.addedAt), line => line.price * line.qty);
    const discountPerUnit = !item.addedAt && originalSubtotal ? Number(invoice.discount || 0) * item.price / originalSubtotal : 0;
    return Math.max(0, (Number(item.price) - discountPerUnit) * qty);
  };
  const saleAdjustments = invoice => (invoice.history || []).filter(row => row.type === 'items-added');
  const adjustmentTotal = invoice => sum(saleAdjustments(invoice), row => row.total);
  const eventKey = value => dateKey(value);
  const dateTimeFmt = value => `${new Date(value).toLocaleDateString('ar-PS', { year: 'numeric', month: 'short', day: 'numeric' })} · ${new Date(value).toLocaleTimeString('ar-PS', { hour: '2-digit', minute: '2-digit' })}`;
  const transactionDone = transaction => new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onabort = transaction.onerror = () => reject(transaction.error || new Error('تعذرت معاملة قاعدة البيانات'));
  });

  netTotal = invoice => Math.max(0, Number(invoice.netTotalApplied ? invoice.total : invoice.total - returnValue(invoice)));
  paidAmount = invoice => Math.min(netTotal(invoice), Math.max(0, sum(invoice.payments || [], payment => payment.amount) - cashRefundValue(invoice)));
  dueAmount = invoice => Math.max(0, netTotal(invoice) - paidAmount(invoice));
  profitBeforeReturns = invoice => netTotal(invoice) - sum(invoice.items || [], item => Number(item.cost || 0) * Math.max(0, Number(item.qty) - returnedQty(invoice, invoice.items.indexOf(item))));
  returnAdjustment = (invoice, item) => -Number(item.refund || 0) + Number(invoice.items[item.itemIndex]?.cost || 0) * Number(item.qty || 0);

  function invoiceOriginalAmount(invoice) {
    return Number(invoice.grossTotal ?? (invoice.netTotalApplied ? invoice.total + returnValue(invoice) - adjustmentTotal(invoice) : invoice.total));
  }
  function invoiceSaleAmount(invoice) {
    return invoiceOriginalAmount(invoice) + adjustmentTotal(invoice);
  }
  function invoiceAmendmentsForDate(invoice, key) {
    return sum(saleAdjustments(invoice).filter(row => eventKey(row.date) === key), row => row.total);
  }
  function invoiceReturnsForDate(invoice, key) {
    return sum((invoice.returns || []).filter(row => eventKey(row.date) === key), row => row.refund);
  }
  function invoiceProfitForSale(invoice) {
    const originalItems = (invoice.items || []).filter(item => !item.addedAt);
    const cost = sum(originalItems, item => Number(item.cost || 0) * Number(item.qty || 0));
    return invoiceOriginalAmount(invoice) - cost;
  }

  async function dailyCount(key) {
    const [invoices, products, expenses] = await Promise.all([all('invoices'), all('products'), all('expenses')]);
    const active = invoices.filter(invoice => !invoice.voided);
    const salesToday = sum(active.filter(invoice => eventKey(invoice.date) === key), invoice => invoiceOriginalAmount(invoice))
      + sum(active, invoice => invoiceAmendmentsForDate(invoice, key))
      - sum(active, invoice => invoiceReturnsForDate(invoice, key));
    const paymentsToday = sum(active, invoice => sum((invoice.payments || []).filter(payment => eventKey(payment.date) === key), payment => payment.amount))
      - sum(active, invoice => sum((invoice.returns || []).filter(row => eventKey(row.date) === key && row.mode !== 'debt'), row => row.refund));
    const invoicesToday = active.filter(invoice => eventKey(invoice.date) === key).length;
    const openDebtAtDate = sum(active.filter(invoice => eventKey(invoice.date) <= key), invoice => {
      const sale = invoiceOriginalAmount(invoice)
        + sum(saleAdjustments(invoice).filter(row => eventKey(row.date) <= key), row => row.total)
        - sum((invoice.returns || []).filter(row => eventKey(row.date) <= key), row => row.refund);
      const paid = sum((invoice.payments || []).filter(payment => eventKey(payment.date) <= key), payment => payment.amount)
        - sum((invoice.returns || []).filter(row => eventKey(row.date) <= key && row.mode !== 'debt'), row => row.refund);
      return Math.max(0, sale - Math.max(0, paid));
    });
    const quantities = new Map();
    const addQty = (name, qty) => quantities.set(name, (quantities.get(name) || 0) + qty);
    active.forEach(invoice => {
      (invoice.items || []).forEach(item => {
        const soldOn = item.addedAt ? eventKey(item.addedAt) : eventKey(invoice.date);
        if (soldOn === key) addQty(item.name, Number(item.qty || 0));
      });
      (invoice.returns || []).filter(row => eventKey(row.date) === key).forEach(row => {
        const item = invoice.items[row.itemIndex];
        if (item) addQty(item.name, -Number(row.qty || 0));
      });
    });
    let grossProfit = sum(active.filter(invoice => eventKey(invoice.date) === key), invoice => invoiceProfitForSale(invoice));
    grossProfit += sum(active, invoice => sum(saleAdjustments(invoice).filter(row => eventKey(row.date) === key), row => Number(row.total || 0) - sum(row.items || [], item => item.cost * item.qty)));
    grossProfit += sum(active, invoice => sum((invoice.returns || []).filter(row => eventKey(row.date) === key), row => returnAdjustment(invoice, row)));
    const expenseTotal = sum(expenses.filter(expense => eventKey(expense.date) === key), expense => expense.amount);
    return {
      key, invoices, products, expenses, active, sales: salesToday, received: paymentsToday,
      debt: openDebtAtDate, invoiceCount: invoicesToday, grossProfit, expenseTotal,
      netProfit: grossProfit - expenseTotal,
      productSales: [...quantities.entries()].filter(([, qty]) => qty !== 0).sort((a, b) => a[0].localeCompare(b[0], 'ar'))
    };
  }

  totals = async () => {
    const report = await dailyCount(todayKey());
    const low = report.products.filter(product => product.qty <= Number(product.lowAt ?? 3));
    return {
      invoices: report.invoices, products: report.products, expenses: report.expenses,
      today: report.active.filter(invoice => eventKey(invoice.date) === report.key),
      received: report.received, refunds: sum(report.active, invoice => invoiceReturnsForDate(invoice, report.key)),
      sales: report.sales, debt: report.debt, low, cost: report.grossProfit, exp: report.expenseTotal
    };
  };

  homeHTML = async () => {
    const t = await totals();
    const cards = [
      ['الفواتير اليوم', t.today.length, 'invoice-archive', 'فاتورة'],
      ['الديون المفتوحة', money(t.debt), 'customers', 'على الزبائن'],
      ['المنتجات', t.products.length, 'products', 'صنف بالمخزون'],
      ['المخزون المنخفض', t.low.length, 'products-low', 'بحاجة للمتابعة']
    ];
    return `<h1>أهلاً بك 👋</h1><p class="sub">ملخص متجرك اليوم</p><button class="hero home-card" data-go="invoice-archive"><div class="label">المبيعات اليوم</div><div class="amount">${money(t.sales)}</div><small>المقبوض ${money(t.received)} · اضغط لفتح فواتير اليوم</small></button><div class="grid">${cards.map(([label, value, target, hint]) => `<button class="stat home-stat" data-home-target="${target}"><div class="label">${label}</div><strong>${value}</strong><em>${hint}</em></button>`).join('')}<button class="stat home-stat" data-home-target="products"><div class="label">المخزون</div><strong>${t.products.reduce((n, product) => n + Number(product.qty || 0), 0)}</strong><em>قطعة متوفرة</em></button></div><div class="section-head"><h2>إجراءات سريعة</h2></div><div class="quick-grid"><button class="quick" data-go="cashier"><b>＋</b>فاتورة جديدة</button><button class="quick" data-action="add-product"><b>▦</b>إضافة منتج</button><button class="quick" data-go="customers"><b>♙</b>الزبائن والديون</button><button class="quick" data-go="invoices"><b>▧</b>الفواتير</button></div>${t.low.length ? `<div class="section-head"><h2>تنبيه المخزون</h2><button class="btn secondary small" data-home-target="products-low">عرض المنتجات المنخفضة</button></div><div class="list">${t.low.slice(0, 3).map(product => `<button class="list-item quick" data-home-target="products-low"><div class="avatar">▦</div><div class="grow"><div class="item-title">${esc(product.name)}</div><div class="muted">المتبقي ${product.qty}</div></div><span class="badge warn">${product.qty === 0 ? 'نفد' : 'منخفض'}</span></button>`).join('')}</div>` : ''}`;
  };

  const baseSetPage = setPage;
  setPage = next => {
    if (next === 'products') { lowStockOnly = false; outOfStockOnly = false; }
    baseSetPage(next);
  };

  productsHTML = async () => {
    const products = await all('products');
    const list = products.filter(product => (!lowStockOnly || (product.qty > 0 && product.qty <= Number(product.lowAt ?? 3)))
      && (!outOfStockOnly || product.qty === 0)
      && `${product.name} ${product.barcode || ''}`.toLowerCase().includes(searchText.toLowerCase()));
    return `<div class="row between"><div><h1>الأصناف</h1><p class="sub">الأصناف والباركود والكميات والأسعار</p></div><button class="btn" data-action="add-product">＋ إضافة صنف</button></div><div class="row"><div class="searchbox grow"><input id="product-search" class="input" placeholder="بحث بالاسم أو الباركود" value="${esc(searchText)}"></div><button class="btn secondary" data-product-scan>▣</button></div><div class="row"><button class="btn secondary small" data-stock-filter="low">وشك النفاذ</button><button class="btn secondary small" data-stock-filter="empty">نفدت الكمية</button></div><div class="list">${list.length ? list.map(product => `<article class="list-item"><div class="avatar">${product.image?`<img src="${esc(product.image)}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:inherit">`:'▦'}</div><div class="grow"><div class="item-title">${esc(product.name)}</div><div class="muted">${product.barcode ? `باركود ${esc(product.barcode)} · ` : 'بدون باركود · '}الكمية ${product.qty}</div><div class="muted">التكلفة ${money(product.cost)} · البيع ${money(product.price)}</div></div><span class="badge ${product.qty===0?'red':product.qty<=Number(product.lowAt??3)?'warn':''}">${product.qty===0?'نفدت الكمية':product.qty<=Number(product.lowAt??3)?'وشك النفاذ':'متوفر'}</span><button class="icon-button" data-action="edit-product" data-id="${product.id}">✎</button></article>`).join('') : '<div class="empty">لا توجد أصناف مطابقة</div>'}</div>`;
  };

  const baseInvoicesHTML = invoicesHTML;
  invoicesHTML = async () => (await baseInvoicesHTML()).replace(/(<button class="btn secondary small" data-action="view-invoice" data-id="(\d+)">عرض<\/button>)/g, '$1<button class="btn danger small" data-invoice-delete="$2">حذف</button>');

  function bindEnhancements() {
    document.querySelectorAll('[data-home-target]').forEach(button => button.addEventListener('click', () => {
      if (button.dataset.homeTarget === 'products-low') {
        lowStockOnly = true; searchText = ''; page = 'products'; render();
      } else setPage(button.dataset.homeTarget);
    }));
    document.querySelectorAll('[data-stock-filter]').forEach(button => button.addEventListener('click', () => {
      lowStockOnly = button.dataset.stockFilter === 'low'; outOfStockOnly = button.dataset.stockFilter === 'empty'; searchText = ''; render();
    }));
    
    document.querySelectorAll('[data-action="daily-print"]').forEach(button => button.addEventListener('click', () => printDailyCount(dailyCountDate, true, window.open('', '_blank'))));
    document.querySelectorAll('[data-action="daily-pdf"]').forEach(button => button.addEventListener('click', () => saveHTMLAsPDF(dailyCountDate)));
    document.querySelectorAll('[data-action="finance-print"]').forEach(button => button.addEventListener('click', () => printFinanceReport(financeDate, window.open('', '_blank'))));
    document.querySelectorAll('[data-action="finance-pdf"]').forEach(button => button.addEventListener('click', () => saveFinancePDF(financeDate)));
    document.querySelectorAll('[data-action="archive-print"]').forEach(button => button.addEventListener('click', () => printInvoiceArchive(invoiceArchiveDate, window.open('', '_blank'))));
    document.querySelectorAll('[data-action="archive-pdf"]').forEach(button => button.addEventListener('click', () => saveInvoiceArchivePDF(invoiceArchiveDate)));
  }
  const baseBindPage = bindPage;
  bindPage = () => { baseBindPage(); bindEnhancements(); };

  const baseMoreHTML = moreHTML;
  moreHTML = () => `${baseMoreHTML().replace(/<\/div>$/, '')}<button class="list-item quick" data-go="invoice-archive"><div class="avatar">▧</div><div class="grow"><div class="item-title">أرشيف الفواتير</div><div class="muted">فواتير أي يوم وملخص طرق الدفع</div></div>›</button><button class="list-item quick" data-go="daily-count"><div class="avatar">▦</div><div class="grow"><div class="item-title">الجرد اليومي</div><div class="muted">المبيعات والكميات والرصيد بتاريخ تختاره</div></div>›</button></div>`;
  const baseRender = render;
  render = async () => {
    if (page !== 'daily-count' && page !== 'invoice-archive') return baseRender();
    nav();
    const app = $('#app');
    try { app.innerHTML = page === 'daily-count' ? await dailyCountHTML() : await invoiceArchiveHTML(); bindPage(); }
    catch (error) { console.error(error); app.innerHTML = `<div class="notice">تعذر تحميل التقرير: ${esc(error.message)}</div>`; }
  };
  nav = () => {
    const group = page === 'invoice-archive' ? 'invoices' : ['customers', 'reports', 'expenses', 'settings', 'returns', 'daily-count'].includes(page) ? 'more' : page;
    $$('.bottom-nav button').forEach(button => button.classList.toggle('active', button.dataset.page === group));
  };

  async function dailyCountHTML() {
    const report = await dailyCount(dailyCountDate);
    const currentByName = new Map(report.products.map(product => [product.name, product.qty]));
    const allNames = new Set([...report.productSales.map(([name]) => name), ...report.products.map(product => product.name)]);
    const rows = [...allNames].sort((a, b) => a.localeCompare(b, 'ar')).map(name => {
      const sold = report.productSales.find(([productName]) => productName === name)?.[1] || 0;
      return `<div class="table-row"><span>${esc(name)}<div class="muted">مباع صافٍ: ${sold}</div></span><b>المتبقي الآن: ${currentByName.get(name) ?? '—'}</b></div>`;
    }).join('');
    return `<div class="row between"><div><h1>الجرد اليومي</h1><p class="sub">مبيعات ودفعات وديون حتى نهاية اليوم المحدد</p></div></div><label class="field"><span>تاريخ التقرير</span><input id="daily-date" class="input" type="date" value="${esc(dailyCountDate)}"></label><div class="grid"><div class="stat"><div class="label">إجمالي المبيعات</div><strong>${money(report.sales)}</strong></div><div class="stat"><div class="label">عدد الفواتير</div><strong>${report.invoiceCount}</strong></div><div class="stat"><div class="label">المبالغ المدفوعة</div><strong>${money(report.received)}</strong></div><div class="stat"><div class="label">الديون القائمة</div><strong>${money(report.debt)}</strong></div></div><div class="section-head"><h2>المنتجات والكميات</h2></div><div class="card">${rows || '<div class="empty">لا توجد حركة لهذا اليوم</div>'}</div><div class="row"><button class="btn grow" data-action="daily-print">طباعة</button><button class="btn secondary grow" data-action="daily-pdf">حفظ PDF</button></div>`;
  }

  async function invoiceArchiveHTML() {
    const report = await dailyCount(invoiceArchiveDate), dayInvoices = report.active.filter(invoice => eventKey(invoice.date) === invoiceArchiveDate).sort((a, b) => a.date.localeCompare(b.date));
    const methods = new Map();
    report.active.forEach(invoice => (invoice.payments || []).filter(payment => eventKey(payment.date) === invoiceArchiveDate).forEach(payment => {
      const method = String(payment.method || invoice.paymentMethod || 'غير محدد').trim() || 'غير محدد';
      methods.set(method, (methods.get(method) || 0) + Number(payment.amount || 0));
    }));
    const rows = dayInvoices.map(invoice => `<div class="card"><div class="row between"><div><div class="item-title">فاتورة #${invoice.id} ${invoice.customer ? `· ${esc(invoice.customer)}` : ''}</div><div class="muted">${dateTimeFmt(invoice.date)}</div></div><button class="btn secondary small" data-action="view-invoice" data-id="${invoice.id}">التفاصيل</button></div><div class="table-row"><span>الإجمالي الصافي</span><b>${money(netTotal(invoice))}</b></div><div class="table-row"><span>المدفوع</span><b>${money(paidAmount(invoice))}</b></div><div class="table-row"><span>المتبقي</span><b>${money(dueAmount(invoice))}</b></div><div class="muted">طرق الدفع: ${esc([...new Set((invoice.payments || []).map(payment => payment.method || invoice.paymentMethod || 'غير محدد'))].join('، ') || invoice.paymentMethod || 'غير مدفوع')}</div></div>`).join('');
    const methodsHTML = [...methods.entries()].map(([method, amount]) => `<div class="table-row"><span>${esc(method)}</span><b>${money(amount)}</b></div>`).join('') || '<div class="muted">لا توجد دفعات مسجلة في هذا اليوم</div>';
    return `<h1>أرشيف الفواتير</h1><p class="sub">اختر يوماً لمراجعة فواتيره وحركات الدفع</p><label class="field"><span>التاريخ</span><input id="archive-date" class="input" type="date" value="${esc(invoiceArchiveDate)}"></label><div class="grid"><div class="stat"><div class="label">مبيعات اليوم</div><strong>${money(report.sales)}</strong></div><div class="stat"><div class="label">عدد الفواتير</div><strong>${report.invoiceCount}</strong></div><div class="stat"><div class="label">المقبوض في اليوم</div><strong>${money(report.received)}</strong></div><div class="stat"><div class="label">الديون القائمة</div><strong>${money(report.debt)}</strong></div></div><div class="section-head"><h2>الفواتير المسجلة في هذا اليوم</h2></div><div class="list">${rows || '<div class="empty">لا توجد فواتير في هذا التاريخ</div>'}</div><div class="section-head"><h2>الدفعات حسب الطريقة في هذا اليوم</h2></div><div class="card">${methodsHTML}</div><div class="row"><button class="btn grow" data-action="archive-print">طباعة الكشف</button><button class="btn secondary grow" data-action="archive-pdf">حفظ PDF</button></div>`;
  }
  async function printInvoiceArchive(key, target = null) {
    const report = await dailyCount(key), rows = report.active.filter(invoice => eventKey(invoice.date) === key).sort((a, b) => a.date.localeCompare(b.date));
    const methods = new Map(); report.active.forEach(invoice => (invoice.payments || []).filter(payment => eventKey(payment.date) === key).forEach(payment => { const name = payment.method || invoice.paymentMethod || 'غير محدد'; methods.set(name, (methods.get(name) || 0) + Number(payment.amount || 0)); }));
    const invoiceRows = rows.map(invoice => `<div class="card"><b>فاتورة #${invoice.id} · ${esc(invoice.customer || 'زبون نقدي')}</b><div class="muted">${dateTimeFmt(invoice.date)} · ${esc([...new Set((invoice.payments || []).map(payment => payment.method || invoice.paymentMethod || 'غير محدد'))].join('، ') || invoice.paymentMethod || 'غير مدفوع')}</div><div class="table-row"><span>الإجمالي ${money(netTotal(invoice))} · مدفوع ${money(paidAmount(invoice))}</span><b>متبقي ${money(dueAmount(invoice))}</b></div></div>`).join('');
    const methodRows = [...methods.entries()].map(([name, amount]) => `<div class="table-row"><span>${esc(name)}</span><b>${money(amount)}</b></div>`).join('');
    printHTML(`<h2>أرشيف الفواتير · ${esc(key)}</h2><div class="table-row"><span>إجمالي المبيعات</span><b>${money(report.sales)}</b></div><div class="table-row"><span>عدد الفواتير</span><b>${report.invoiceCount}</b></div><div class="table-row"><span>المقبوض</span><b>${money(report.received)}</b></div><div class="table-row"><span>الديون القائمة</span><b>${money(report.debt)}</b></div><h3>الفواتير</h3>${invoiceRows || '<p>لا توجد فواتير</p>'}<h3>الدفعات حسب الطريقة</h3>${methodRows || '<p>لا توجد دفعات</p>'}`, `أرشيف الفواتير ${key}`, target);
  }
  async function saveInvoiceArchivePDF(key) {
    const report = await dailyCount(key), invoices = report.active.filter(invoice => eventKey(invoice.date) === key).sort((a, b) => a.date.localeCompare(b.date));
    const lines = [`أرشيف الفواتير · ${key}`, `إجمالي المبيعات: ${money(report.sales)}`, `عدد الفواتير: ${report.invoiceCount}`, `المقبوض: ${money(report.received)}`, `الديون القائمة: ${money(report.debt)}`, ''];
    invoices.forEach(invoice => lines.push(`#${invoice.id} · ${invoice.customer || 'زبون نقدي'} · ${dateTimeFmt(invoice.date)} · الإجمالي ${money(netTotal(invoice))} · المدفوع ${money(paidAmount(invoice))} · المتبقي ${money(dueAmount(invoice))} · ${[...new Set((invoice.payments || []).map(payment => payment.method || invoice.paymentMethod || 'غير محدد'))].join('، ') || invoice.paymentMethod || 'غير مدفوع'}`));
    lines.push('', 'الدفعات حسب الطريقة');
    const methods = new Map(); report.active.forEach(invoice => (invoice.payments || []).filter(payment => eventKey(payment.date) === key).forEach(payment => { const method = payment.method || invoice.paymentMethod || 'غير محدد'; methods.set(method, (methods.get(method) || 0) + Number(payment.amount || 0)); }));
    methods.forEach((amount, method) => lines.push(`${method}: ${money(amount)}`));
    downloadArabicPDF(lines, `mystore-invoice-archive-${key}.pdf`); toast('تم حفظ كشف اليوم PDF');
  }

  financeHTML = async () => {
    const report = await dailyCount(financeDate);
    const products = report.products.map(product => ({
      ...product,
      profit: productProfit(product, report.active),
      sold: report.active.reduce((qty, invoice) => qty + invoice.items.reduce((n, item, index) => n + (item.productId === product.id ? Math.max(0, item.qty - returnedQty(invoice, index)) : 0), 0), 0)
    }));
    const top = [...products].sort((a, b) => b.sold - a.sold).slice(0, 5);
    return `<div class="row between"><div><h1>الصفحة المالية</h1><p class="sub">أسعار الشراء والبيع والأرباح · ${esc(financeDate)}</p></div></div><label class="field"><span>تاريخ التقرير المالي</span><input id="finance-date" class="input" type="date" value="${esc(financeDate)}"></label><div class="grid"><div class="stat"><div class="label">مبيعات اليوم</div><strong>${money(report.sales)}</strong></div><div class="stat"><div class="label">المقبوض</div><strong>${money(report.received)}</strong></div><div class="stat"><div class="label">الديون حتى نهاية اليوم</div><strong>${money(report.debt)}</strong></div><div class="stat"><div class="label">الربح الإجمالي</div><strong>${money(report.grossProfit)}</strong></div></div><div class="card"><div class="row between"><h2>صافي الربح بعد المصاريف</h2><b class="price">${money(report.netProfit)}</b></div><div class="muted">المصاريف: ${money(report.expenseTotal)}</div></div><div class="row"><button class="btn grow" data-action="finance-print">طباعة</button><button class="btn secondary grow" data-action="finance-pdf">حفظ PDF</button></div><div class="section-head"><h2>أسعار المنتجات وأرباحها</h2></div><div class="list">${products.map(product => `<div class="card"><div class="row between"><div><div class="item-title">${esc(product.name)}</div><div class="muted">شراء ${money(product.cost)} · بيع ${money(product.price)}</div><div class="muted">هامش الوحدة ${money(product.price - product.cost)} · ربح مسجل ${money(product.profit)} · مباع صافٍ ${product.sold}</div></div><button class="btn secondary small" data-action="finance-product" data-id="${product.id}">تعديل الأسعار</button></div></div>`).join('') || '<div class="empty">لا توجد منتجات</div>'}</div><div class="section-head"><h2>الأكثر مبيعاً</h2></div><div class="card">${top.map(product => `<div class="table-row"><span>${esc(product.name)}</span><b>${product.sold} قطعة</b></div>`).join('') || '<div class="muted">لا توجد مبيعات</div>'}</div><div class="section-head"><h2>المصاريف في التاريخ المحدد</h2><button class="btn small" data-action="add-expense">＋ تسجيل مصروف</button></div><div class="list">${report.expenses.filter(expense => eventKey(expense.date) === financeDate).map(expense => `<div class="list-item"><div class="grow">${esc(expense.title)}</div><div style="display:flex;align-items:center;gap:10px"><b>${money(expense.amount)}</b><button type="button" class="btn-delete-expense" data-action="delete-expense" data-id="${expense.id}" data-delete-expense="${expense.id}" title="حذف المصروف" aria-label="حذف المصروف">🗑</button></div></div>`).join('') || '<div class="empty">لا توجد مصاريف لهذا اليوم</div>'}</div><div class="section-head"><h2>المخزون الحالي</h2></div><div class="card">${report.products.map(product => `<div class="table-row"><span>${esc(product.name)}</span><b>${product.qty} قطعة</b></div>`).join('') || '<div class="muted">لا يوجد مخزون</div>'}</div>`;
  };
  function productProfit(product, invoices) {
    let profit = 0;
    for (const invoice of invoices) {
      if (invoice.voided) continue;
      const original = invoice.items.filter(item => !item.addedAt);
      const originalSubtotal = sum(original, item => item.price * item.qty);
      invoice.items.forEach((item, index) => {
        if (item.productId !== product.id) return;
        const returned = returnedQty(invoice, index);
        const refund = sum((invoice.returns || []).filter(row => row.itemIndex === index), row => row.refund);
        const discount = !item.addedAt && originalSubtotal ? Number(invoice.discount || 0) * item.price * item.qty / originalSubtotal : 0;
        profit += item.price * item.qty - discount - refund - Number(item.cost || 0) * (item.qty - returned);
      });
    }
    return profit;
  }
  function financeLines(key, report) {
    const lines = [`التقرير المالي · ${key}`, `المبيعات: ${money(report.sales)}`, `الفواتير: ${report.invoiceCount}`, `المقبوض: ${money(report.received)}`, `الديون القائمة: ${money(report.debt)}`, `الربح الإجمالي: ${money(report.grossProfit)}`, `المصاريف: ${money(report.expenseTotal)}`, `صافي الربح: ${money(report.netProfit)}`, '', 'المنتجات والأسعار والأرباح'];
    report.products.forEach(product => lines.push(`${product.name} · شراء ${money(product.cost)} · بيع ${money(product.price)} · ربح ${money(productProfit(product, report.active))} · مخزون ${product.qty}`));
    return lines;
  }
  async function printFinanceReport(key, target = null) { const report = await dailyCount(key); printHTML(`<h2>التقرير المالي · ${esc(key)}</h2>${financeLines(key, report).slice(1).map(line => `<div class="table-row">${esc(line)}</div>`).join('')}`, `التقرير المالي ${key}`, target); }
  async function saveFinancePDF(key) { const report = await dailyCount(key); downloadArabicPDF(financeLines(key, report), `mystore-finance-${key}.pdf`); toast('تم حفظ التقرير المالي كملف PDF'); }
  const baseBind = bindPage;
  bindPage = () => {
    baseBind();
    const archiveInput = $('#archive-date');
    if (archiveInput) archiveInput.addEventListener('change', () => { invoiceArchiveDate = archiveInput.value || todayKey(); render(); });
    const dateInput = $('#daily-date');
    if (dateInput) dateInput.addEventListener('change', () => { dailyCountDate = dateInput.value || todayKey(); render(); });
    const financeInput = $('#finance-date');
    if (financeInput) financeInput.addEventListener('change', () => { financeDate = financeInput.value || todayKey(); render(); });
  };

  async function printDailyCount(key, openWindow = true, target = null) {
    const report = await dailyCount(key);
    const rows = [...new Set([...report.productSales.map(row => row[0]), ...report.products.map(product => product.name)])].sort((a, b) => a.localeCompare(b, 'ar')).map(name => {
      const sold = report.productSales.find(row => row[0] === name)?.[1] || 0;
      const stock = report.products.find(product => product.name === name)?.qty ?? '—';
      return `<div class="table-row"><span>${esc(name)} · مباع ${sold}</span><b>المخزون ${stock}</b></div>`;
    }).join('');
    const html = `<h2>الجرد اليومي · ${esc(key)}</h2><div class="table-row"><span>إجمالي المبيعات</span><b>${money(report.sales)}</b></div><div class="table-row"><span>عدد الفواتير</span><b>${report.invoiceCount}</b></div><div class="table-row"><span>إجمالي المدفوع</span><b>${money(report.received)}</b></div><div class="table-row"><span>الديون القائمة حتى التاريخ</span><b>${money(report.debt)}</b></div><h3>المنتجات والكميات</h3>${rows}`;
    if (openWindow) printHTML(html, `الجرد اليومي ${key}`, target);
    return html;
  }
  async function saveHTMLAsPDF(key) {
    const report = await dailyCount(key);
    const lines = [`الجرد اليومي · ${key}`, `إجمالي المبيعات: ${money(report.sales)}`, `عدد الفواتير: ${report.invoiceCount}`, `إجمالي المدفوع: ${money(report.received)}`, `الديون القائمة: ${money(report.debt)}`, '', 'المنتجات والكميات'];
    report.products.forEach(product => lines.push(`${product.name} · مباع صافٍ: ${report.productSales.find(row => row[0] === product.name)?.[1] || 0} · متبقٍ: ${product.qty}`));
    downloadArabicPDF(lines, `mystore-daily-count-${key}.pdf`); toast('تم حفظ الجرد اليومي كملف PDF');
  }

  let nextPdfKind = 'report';
  function downloadArabicPDF(lines, filename, preparedCanvases = null, kind = nextPdfKind) {
    const width = 1190, height = 1684, margin = 84, lineHeight = 34, perPage = 44, pages = [];
    if (preparedCanvases?.length) preparedCanvases.forEach(canvas => pages.push(canvas.toDataURL('image/jpeg', 0.94).split(',')[1]));
    else for (let offset = 0; offset < lines.length || offset === 0; offset += perPage) {
      const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = height;
      const context = canvas.getContext('2d'); context.fillStyle = '#fff'; context.fillRect(0, 0, width, height);
      context.fillStyle = '#111'; context.direction = 'rtl'; context.textAlign = 'right'; context.font = '26px Tahoma, Arial, sans-serif';
      lines.slice(offset, offset + perPage).forEach((line, index) => {
        const y = margin + (index + 1) * lineHeight, maxWidth = width - margin * 2;
        let text = String(line), chunks = [];
        while (context.measureText(text).width > maxWidth) {
          let cut = text.length;
          while (cut > 1 && context.measureText(text.slice(0, cut)).width > maxWidth) cut--;
          const space = text.lastIndexOf(' ', cut); if (space > 0) cut = space;
          chunks.push(text.slice(0, cut)); text = text.slice(cut).trim();
        }
        chunks.push(text); chunks.forEach((chunk, part) => context.fillText(chunk, width - margin, y + part * lineHeight, maxWidth));
      });
      pages.push(canvas.toDataURL('image/jpeg', 0.9).split(',')[1]);
    }
    const encoder = new TextEncoder(), parts = [], offsets = [0]; let length = 0;
    const push = value => { const bytes = typeof value === 'string' ? encoder.encode(value) : value; parts.push(bytes); length += bytes.length; };
    push('%PDF-1.4\n%âãÏÓ\n');
    const objectCount = 2 + pages.length * 3;
    const object = (id, content) => { offsets[id] = length; push(`${id} 0 obj\n`); push(content); push('\nendobj\n'); };
    object(1, '<< /Type /Catalog /Pages 2 0 R >>');
    const pageIds = pages.map((_, index) => 3 + index * 3);
    object(2, `<< /Type /Pages /Kids [${pageIds.map(id => `${id} 0 R`).join(' ')}] /Count ${pages.length} >>`);
    pages.forEach((base64, index) => {
      const pageId = 3 + index * 3, contentId = pageId + 1, imageId = pageId + 2;
      const binary = atob(base64), jpeg = new Uint8Array(binary.length); for (let i = 0; i < binary.length; i++) jpeg[i] = binary.charCodeAt(i);
      object(pageId, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /XObject << /Im0 ${imageId} 0 R >> >> /Contents ${contentId} 0 R >>`);
      const content = encoder.encode('q 595 0 0 842 0 0 cm /Im0 Do Q');
      offsets[contentId] = length; push(`${contentId} 0 obj\n<< /Length ${content.length} >>\nstream\n`); push(content); push('\nendstream\nendobj\n');
      offsets[imageId] = length; push(`${imageId} 0 obj\n<< /Type /XObject /Subtype /Image /Width ${width} /Height ${height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpeg.length} >>\nstream\n`); push(jpeg); push('\nendstream\nendobj\n');
    });
    const xrefOffset = length; push(`xref\n0 ${objectCount + 1}\n0000000000 65535 f \n`);
    for (let id = 1; id <= objectCount; id++) push(`${String(offsets[id]).padStart(10, '0')} 00000 n \n`);
    push(`trailer\n<< /Size ${objectCount + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`);
    const blob = new Blob(parts, { type: 'application/pdf' });
    add('files', { kind, name: filename, created: toISO(), blob }).catch(error => console.warn('تعذر حفظ PDF في الملفات', error));
    const url = URL.createObjectURL(blob), link = document.createElement('a');
    link.href = url; link.download = filename; link.click(); setTimeout(() => URL.revokeObjectURL(url), 3000);
  }

  const baseModalAction = modalAction;
  modalAction = async (name, id) => {
    let productExtras=null;
    if(name==='save-product'){
      const imageFile=$('#f-image')?.files?.[0]; let image=$('#f-image')?.dataset.current||'';
      if(imageFile) image=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(reader.error);reader.readAsDataURL(imageFile)});
      productExtras={image,weighted:!!$('#f-weighted')?.checked,description:$('#f-description')?.value.trim()||''};
    }
    const result = await baseModalAction(name, id);
    
    if(name==='save-product'&&productExtras&&!$('#modal').open){const rows=await all('products'),target=id?rows.find(row=>row.id===id):rows.filter(row=>row.name===$('#f-name')?.value).sort((a,b)=>String(b.updated).localeCompare(String(a.updated)))[0];if(target){Object.assign(target,productExtras);await put('products',target);render()}}
    return result;
  };
  const baseProductModal = productModal;
  productModal = async id => { const existing=id?await get('products',id):{}; await baseProductModal(id); if ($('#f-cost')) $('#f-cost').closest('label').style.display='block'; $('#f-name')?.closest('.field')?.insertAdjacentHTML('afterend',`<label class="field"><span>صورة المنتج (اختياري)</span><input id="f-image" class="input" type="file" accept="image/*" data-current="${esc(existing?.image||'')}">${existing?.image?`<img src="${esc(existing.image)}" alt="صورة المنتج" style="max-width:90px;max-height:80px;margin-top:8px;border-radius:12px">`:''}</label><label class="check-field"><input id="f-weighted" type="checkbox" ${existing?.weighted?'checked':''}> البيع بالوزن</label><label class="field"><span>وصف مختصر</span><textarea id="f-description" class="input">${esc(existing?.description||'')}</textarea></label>`); if($('#f-qty'))$('#f-qty').step=existing?.weighted?'0.001':'1';$('#f-weighted').onchange=()=>{$('#f-qty').step=$('#f-weighted').checked?'0.001':'1'};  };

  const baseAddToCart = addToCart;
  addToCart = async id => {
    const product=await get('products',id); if(!product)return;
    if(!product.weighted)return baseAddToCart(id);
    if(Number(product.qty)<=0){toast('المنتج غير متوفر');return}
    const existing=cart.find(item=>item.productId===id);
    if(existing){if(existing.qty+0.001>Number(product.qty)){toast('لا توجد كمية كافية');return}existing.qty=Number((existing.qty+1).toFixed(3));}
    else cart.push({productId:id,name:product.name,price:Number(product.price),cost:Number(product.cost),qty:1,weighted:true});
    render();
  };

  cashierHTML = async () => {
    const base = await (async () => {
      const products = await all('products');
      return `<h1>الكاشير</h1><p class="sub">ابحث بالاسم أو الباركود أو استخدم الكاميرا</p><div class="row"><div class="searchbox grow"><input id="cash-search" class="input" placeholder="اسم المنتج أو الباركود" value="${esc(searchText)}"></div><button class="btn secondary" data-action="scan">▣ كاميرا</button></div><div id="cash-results" class="list"></div><div class="section-head"><h2>سلة الفاتورة</h2><button class="btn secondary small" data-action="manual-item">＋ بند يدوي</button></div><label class="field"><span>اسم الزبون (اختياري)</span><input id="sale-customer" class="input" placeholder="اسم الزبون" value="${esc(salesCarts[activeSalesCart]?.customer||'')}"></label><div class="list" id="cart-list">${cart.length ? cart.map((item, index) => `<div class="list-item"><div class="grow"><div class="item-title">${esc(item.name)}</div><div class="muted">${money(item.price)} ${item.weighted?'للوحدة':'للقطعة'}</div></div>${item.weighted?`<input class="input weighted-qty" data-index="${index}" type="number" min="0.001" step="0.001" value="${item.qty}" style="max-width:115px">`:`<div class="qty"><button data-cart="minus" data-i="${index}">−</button><b>${item.qty}</b><button data-cart="plus" data-i="${index}">+</button></div>`}<button class="icon-button" data-cart="remove" data-i="${index}">×</button></div>`).join('') : '<div class="empty">السلة فارغة</div>'}</div><div class="total-bar"><label class="field"><span>الخصم (₪)</span><input id="sale-discount" class="input" type="number" min="0" step="0.01" value="${salesCarts[activeSalesCart]?.discount||0}"></label><div class="row between"><b>الإجمالي</b><b id="sale-total">${money(cart.reduce((value, item) => value + item.price * item.qty, 0))}</b></div><button class="btn full" data-action="checkout" ${cart.length ? '' : 'disabled'}>إتمام الفاتورة</button></div>`;
    })();
    return base;
  };

  checkout = async () => {
    if (!cart.length || checkoutBusy) return;
    checkoutBusy = true;
    try {
      const subtotal = sum(cart, item => item.price * item.qty);
      const discount = Math.max(0, Math.min(subtotal, Number($('#sale-discount')?.value || 0)));
      const total = Math.max(0, subtotal - discount);
      const customerName = $('#sale-customer')?.value.trim() || '';
      $('#modal').addEventListener('close', () => { if (!checkoutCommitting) checkoutBusy = false; }, { once: true });
      openModal('إتمام الفاتورة', `<div class="card"><div class="row between"><span>الإجمالي</span><b>${money(total)}</b></div><div class="row between"><span>المتبقي بعد الدفع</span><b id="checkout-due">${money(0)}</b></div></div><label class="field"><span>حالة الدفع</span><select id="checkout-status" class="input"><option value="paid">مدفوعة بالكامل</option><option value="partial">مدفوعة جزئياً</option><option value="unpaid">آجل</option></select></label><label class="field"><span>طريقة الدفع</span><select id="checkout-method" class="input"><option value="نقداً">نقدي</option><option value="بطاقة">بطاقة</option><option value="بنك أو محفظة">بنك أو محفظة</option><option value="mixed">دفع مختلط</option></select></label><div id="checkout-mixed" class="card" hidden><label class="field"><span>نقدي (₪)</span><input id="checkout-cash" class="input" type="number" min="0" step="0.01" value="${total}"></label><label class="field"><span>بطاقة (₪)</span><input id="checkout-card" class="input" type="number" min="0" step="0.01" value="0"></label><label class="field"><span>بنك أو محفظة (₪)</span><input id="checkout-wallet" class="input" type="number" min="0" step="0.01" value="0"></label></div><label class="field" id="checkout-paid-field"><span>المبلغ المدفوع (₪)</span><input id="checkout-paid" class="input" type="number" min="0" step="0.01" value="${total}"></label><button class="btn full" id="confirm-checkout">حفظ الفاتورة</button>`);
      const statusInput = $('#checkout-status'), paidInput = $('#checkout-paid'), methodInput=$('#checkout-method');
      const syncPay = () => {
        if(methodInput.value==='mixed'){
          $('#checkout-mixed').hidden=false; paidInput.disabled=true;
          if(statusInput.value==='paid'){ $('#checkout-cash').value=total;$('#checkout-card').value=0;$('#checkout-wallet').value=0; }
          if(statusInput.value==='unpaid'){ $('#checkout-cash').value=0;$('#checkout-card').value=0;$('#checkout-wallet').value=0; }
          paidInput.value=['checkout-cash','checkout-card','checkout-wallet'].reduce((sum,id)=>sum+Number($('#'+id).value||0),0);
        }else{
          $('#checkout-mixed').hidden=true;
          if (statusInput.value === 'paid') paidInput.value = total;
          if (statusInput.value === 'unpaid') paidInput.value = 0;
          paidInput.disabled = statusInput.value !== 'partial';
        }
        $('#checkout-due').textContent = money(Math.max(0, total - Number(paidInput.value || 0)));
      };
      statusInput.onchange = syncPay; methodInput.onchange=()=>{if(methodInput.value==='mixed'&&statusInput.value==='partial'){$('#checkout-cash').value=paidInput.value;$('#checkout-card').value=0;$('#checkout-wallet').value=0}syncPay()}; paidInput.oninput = () => { $('#checkout-due').textContent = money(Math.max(0, total - Number(paidInput.value || 0))); };
      ['checkout-cash','checkout-card','checkout-wallet'].forEach(id=>$('#'+id).oninput=()=>{paidInput.value=['checkout-cash','checkout-card','checkout-wallet'].reduce((sum,key)=>sum+Number($('#'+key).value||0),0);$('#checkout-due').textContent=money(Math.max(0,total-Number(paidInput.value||0)))});
      syncPay();
      $('#confirm-checkout').onclick = async () => {
        const amount = Number(paidInput.value);
        if (!Number.isFinite(amount) || amount < 0 || amount > total || (statusInput.value === 'paid' && Math.abs(amount-total)>0.005) || (statusInput.value === 'unpaid' && amount!==0) || (statusInput.value === 'partial' && (amount <= 0 || amount >= total))) { toast('تحقق من مبلغ الدفعة'); return; }
        if (statusInput.value !== 'paid' && !customerName) { toast('أدخل اسم الزبون لربط الرصيد بديونه'); $('#sale-customer')?.focus(); return; }
        const method = methodInput.value==='mixed'?'مختلط':methodInput.value;
        const splitPayments=methodInput.value==='mixed'?[['نقداً',$('#checkout-cash').value],['بطاقة',$('#checkout-card').value],['بنك أو محفظة',$('#checkout-wallet').value]].map(([method,value])=>({method,amount:Number(value||0)})).filter(payment=>payment.amount>0):[{method,amount}].filter(payment=>payment.amount>0);
        if(methodInput.value==='mixed'&&Math.abs(splitPayments.reduce((sum,payment)=>sum+payment.amount,0)-amount)>0.005){toast('مجموع طرق الدفع المختلطة غير متطابق');return}
        const shopName = await setting('shopName', 'متجري');
        checkoutCommitting = true;
        const dbtx = db.transaction(['products', 'invoices', 'customers'], 'readwrite');
        const done = transactionDone(dbtx), products = dbtx.objectStore('products'), invoiceStore = dbtx.objectStore('invoices'), customerStore = dbtx.objectStore('customers');
        const abortWith = message => { toast(message); try { dbtx.abort(); } catch { } };
        const createInvoice = customerId => {
          const date = toISO();
          invoiceStore.add({ date, customer: customerName, customerId, shopName, paymentMethod: method, items: cart.map(item => ({ ...item })), subtotal, discount, total, grossTotal: total, netTotalApplied: true, history: [], payments: splitPayments.map(payment=>({...payment,date})), returns: [], voided: false });
        };
        const updateStock = customerId => {
          const stockItems = cart.filter(item => item.productId);
          if (!stockItems.length) { createInvoice(customerId); return; }
          let pending = stockItems.length, failed = false;
          stockItems.forEach(item => {
            const request = products.get(item.productId);
            request.onsuccess = () => {
              const product = request.result;
              if (!product || product.qty < item.qty) { failed = true; abortWith(`الكمية المتوفرة غير كافية: ${item.name}`); return; }
              product.qty -= item.qty; products.put(product);
              if (--pending === 0 && !failed) createInvoice(customerId);
            };
          });
        };
        const customerRequest = customerStore.getAll();
        customerRequest.onsuccess = () => {
          const existing = customerRequest.result.find(row => row.name.trim().toLowerCase() === customerName.toLowerCase());
          if (!customerName || existing) { updateStock(existing?.id || null); return; }
          const addCustomer = customerStore.add({ name: customerName, phone: '', created: toISO() });
          addCustomer.onsuccess = () => updateStock(addCustomer.result);
        };
        try {
          await done;
          cart = []; if(salesCarts[activeSalesCart])salesCarts[activeSalesCart]={items:[],customer:'',discount:0}; cartViewActive=false; closeModal(); checkoutCommitting = false; checkoutBusy = false; toast('تم حفظ الفاتورة وتحديث المخزون'); setPage('invoices');
        } catch (error) { checkoutCommitting = false; checkoutBusy = false; toast(error.message || 'تعذر حفظ الفاتورة؛ لم يتم تطبيق خصم جزئي للمخزون'); }
      };
    } catch (error) { checkoutBusy = false; toast(error.message || 'تعذر بدء الفاتورة'); }
  };

  viewInvoice = async id => {
    const invoice = await get('invoices', id); if (!invoice) return;
    const audit = [...(invoice.history || []).map(row => `<div class="muted">تعديل ${dateFmt(row.date)} · ${row.items.map(item => `${esc(item.name)} × ${item.qty}`).join('، ')} · ${money(row.total)}</div>`), ...(invoice.returns || []).map(row => `<div class="muted">مرتجع ${dateFmt(row.date)} · ${esc(invoice.items[row.itemIndex]?.name || '')} × ${row.qty} · ${money(row.refund)}</div>`)].join('');
    openModal(`فاتورة #${id}`, `${invoiceMarkup(invoice)}<details class="card"><summary>سجل التعديلات والمرتجعات (للمراجعة)</summary>${audit || '<div class="muted">لا توجد تعديلات أو مرتجعات مسجلة.</div>'}</details><div class="row"><button class="btn grow" id="invoice-print">طباعة</button><button class="btn secondary grow" id="invoice-pdf">حفظ PDF</button></div><div class="row" style="margin-top:8px"><button class="btn secondary grow" id="invoice-amend">إضافة منتجات للفاتورة</button><button class="btn secondary grow" id="invoice-return">تسجيل مرتجع</button><button class="btn danger" id="invoice-delete">حذف الفاتورة</button></div>`);
    $('#invoice-print').onclick = () => printInvoice(invoice);
    $('#invoice-pdf').onclick = () => saveInvoicePDF(invoice);
    $('#invoice-amend').onclick = () => amendInvoiceModal(invoice.id);
    $('#invoice-return').onclick = () => returnModal(invoice.id);
    $('#invoice-delete').onclick = () => deleteInvoiceSafely(invoice.id);
  };
  invoiceMarkup = invoice => {
    const paymentRows = (invoice.payments || []).map(payment => `<div class="table-row"><span>${money(payment.amount)} · ${esc(payment.method || invoice.paymentMethod || 'غير محدد')}</span><span>${dateTimeFmt(payment.date)}</span></div>`).join('');
    const methods = [...new Set((invoice.payments || []).map(payment => payment.method || invoice.paymentMethod || 'غير محدد'))];
    return `<div id="invoice-paper"><div style="text-align:center"><h2>${esc(invoice.shopName || 'متجري')}</h2><p class="muted">فاتورة بيع #${invoice.id}<br>${dateTimeFmt(invoice.date)}</p></div>${invoice.customer ? `<p>الزبون: ${esc(invoice.customer)}</p>` : ''}${invoice.items.map((item, index) => { const qty = Math.max(0, item.qty - returnedQty(invoice, index)), refund = sum((invoice.returns || []).filter(row => row.itemIndex === index), row => row.refund), originalSubtotal = sum(invoice.items.filter(line => !line.addedAt), line => line.price * line.qty), lineDiscount = !item.addedAt && originalSubtotal ? Number(invoice.discount || 0) * item.price * item.qty / originalSubtotal : 0; return qty ? `<div class="table-row"><span>${esc(item.name)} × ${qty}</span><b>${money(Math.max(0, item.price * item.qty - lineDiscount - refund))}</b></div>` : ''; }).join('')}${invoice.discount ? `<div class="table-row"><span>الخصم</span><b>− ${money(invoice.discount)}</b></div>` : ''}<div class="table-row"><b>الإجمالي</b><b>${money(netTotal(invoice))}</b></div><div class="table-row"><span>المدفوع</span><b>${money(paidAmount(invoice))}</b></div><div class="table-row"><span>المتبقي</span><b>${money(dueAmount(invoice))}</b></div><div class="table-row"><span>طريقة الدفع</span><b>${esc(methods.join('، ') || invoice.paymentMethod || 'غير مدفوع')}</b></div><h3>سجل الدفعات</h3>${paymentRows || '<div class="muted">لا توجد دفعات مسجلة</div>'}<p class="small-note" style="text-align:center">شكراً لزيارتكم</p></div>`;
  };
  returnsHTML = async () => {
    const invoices = (await all('invoices')).filter(invoice => !invoice.voided && invoice.items.some(item => item.productId));
    return `<h1>المرتجعات</h1><p class="sub">اختر فاتورة لإرجاع كمية وإعادتها للمخزون</p><div class="list">${invoices.length ? invoices.map(invoice => `<div class="list-item"><div class="avatar">↶</div><div class="grow"><div class="item-title">فاتورة #${invoice.id} ${invoice.customer ? `· ${esc(invoice.customer)}` : ''}</div><div class="muted">${dateFmt(invoice.date)} · الصافي ${money(netTotal(invoice))}</div></div><button class="btn secondary small" data-action="return-invoice" data-id="${invoice.id}">إرجاع</button></div>`).join('') : '<div class="empty">لا توجد فواتير بها منتجات مخزنية</div>'}</div>`;
  };
  printInvoice = invoice => printHTML(invoiceMarkup(invoice), `فاتورة ${invoice.id}`);
  async function deleteInvoiceSafely(id) {
    const invoice = await get('invoices', id);
    if (!invoice) return;
    const received = paidAmount(invoice), due = dueAmount(invoice);
    if (!confirm(`حذف الفاتورة #${id} نهائياً؟ سيُلغى بيعها ودفعاتها ورصيد دينها من التقارير، ويُعاد للمخزون ما لم يُرجع سابقاً. المقبوض المسجل ${money(received)} والرصيد ${money(due)}.`)) return;
    const tx = db.transaction(['products', 'invoices'], 'readwrite'), done = transactionDone(tx);
    const products = tx.objectStore('products'), invoiceStore = tx.objectStore('invoices');
    const invoiceReq = invoiceStore.get(id);
    invoiceReq.onsuccess = () => {
      const fresh = invoiceReq.result;
      if (!fresh) { try { tx.abort(); } catch {} return; }
      const productReq = products.getAll();
      productReq.onsuccess = () => {
        const byId = new Map(productReq.result.map(product => [product.id, product])), restore = new Map();
        (fresh.items || []).forEach((item, index) => {
          if (item.productId) restore.set(item.productId, (restore.get(item.productId) || 0) + Math.max(0, Number(item.qty || 0) - returnedQty(fresh, index)));
        });
        for (const [productId, quantity] of restore) {
          const product = byId.get(productId);
          if (!product) { try { tx.abort(); } catch {} toast('تعذر الحذف: أحد منتجات الفاتورة غير موجود، لم تتغير البيانات'); return; }
          product.qty = Number(product.qty || 0) + quantity; products.put(product);
        }
        invoiceStore.delete(id);
      }
    };
    try { await done; closeModal(); toast('حُذفت الفاتورة وصُححت الأرصدة والمخزون'); render(); }
    catch (error) { console.error(error); toast('تعذر حذف الفاتورة'); }
  }

  customersHTML = async () => {
    const [customers, invoices] = await Promise.all([all('customers'), all('invoices')]);
    return `<div class="row between"><div><h1>الزبائن</h1><p class="sub">الأرصدة وكشوف الحساب</p></div><button class="btn" data-action="add-customer">＋ إضافة</button></div><div class="list">${customers.length ? customers.map(customer => { const related = invoices.filter(invoice => invoice.customerId === customer.id && !invoice.voided), due = sum(related, dueAmount); return `<div class="card"><div class="row"><div class="avatar">♙</div><div class="grow"><div class="item-title">${esc(customer.name)}</div><div class="muted">${esc(customer.phone || 'لا يوجد رقم')}</div></div><div class="price">${money(due)}<div class="muted">الرصيد</div></div></div><hr class="divider"><div class="row"><button class="btn secondary small grow" data-action="customer-statement" data-id="${customer.id}">كشف حساب</button>${due > 0 ? `<button class="btn small" data-action="customer-pay" data-id="${customer.id}">تسجيل تسديد</button>` : ''}<button class="btn danger small" data-action="delete-customer" data-id="${customer.id}">حذف زبون</button></div></div>`; }).join('') : '<div class="empty">أضف زبائنك لتسجيل المبيعات الآجلة</div>'}</div>`;
  };

  async function deleteSettledCustomer(id) {
    const [customer, invoices] = await Promise.all([get('customers', id), all('invoices')]);
    if (!customer) return;
    if (sum(invoices.filter(invoice => invoice.customerId === id && !invoice.voided), dueAmount) > 0) { toast('لا يمكن حذف زبون لديه دين مفتوح؛ سجّل التسديد أولاً.'); return; }
    if (!confirm(`حذف الزبون ${customer.name}؟ ستبقى فواتيره السابقة محفوظة باسمه.`)) return;
    const tx = db.transaction(['customers', 'invoices'], 'readwrite'), done = transactionDone(tx);
    const customers = tx.objectStore('customers'), invoiceStore = tx.objectStore('invoices'), request = invoiceStore.getAll();
    request.onsuccess = () => {
      request.result.filter(invoice => invoice.customerId === id).forEach(invoice => { delete invoice.customerId; invoiceStore.put(invoice); });
      customers.delete(id);
    };
    try { await done; toast('حُذف الزبون وبقي سجل فواتيره'); render(); }
    catch (error) { console.error(error); toast('تعذر حذف الزبون'); }
  }

  function saveInvoicePDF(invoice) {
    const lines = [invoice.shopName || 'متجري', `فاتورة بيع #${invoice.id}`, dateFmt(invoice.date), invoice.customer ? `الزبون: ${invoice.customer}` : '', ''];
    invoice.items.forEach((item, index) => { const qty = Math.max(0, item.qty - returnedQty(invoice, index)), refund = sum((invoice.returns || []).filter(row => row.itemIndex === index), row => row.refund), originalSubtotal = sum(invoice.items.filter(line => !line.addedAt), line => line.price * line.qty), lineDiscount = !item.addedAt && originalSubtotal ? Number(invoice.discount || 0) * item.price * item.qty / originalSubtotal : 0; if (qty) lines.push(`${item.name} × ${qty}     ${money(Math.max(0, item.price * item.qty - lineDiscount - refund))}`); });
    if (invoice.discount) lines.push(`الخصم: ${money(invoice.discount)}`);
    lines.push('', `الإجمالي: ${money(netTotal(invoice))}`, `المدفوع: ${money(paidAmount(invoice))}`, `المتبقي: ${money(dueAmount(invoice))}`, `طرق الدفع: ${[...new Set((invoice.payments || []).map(payment => payment.method || invoice.paymentMethod || 'غير محدد'))].join('، ') || invoice.paymentMethod || 'غير مدفوع'}`, 'سجل الدفعات:');
    (invoice.payments || []).forEach(payment => lines.push(`${dateTimeFmt(payment.date)} · ${payment.method || invoice.paymentMethod || 'غير محدد'} · ${money(payment.amount)}`));
    lines.push('شكراً لزيارتكم');
    downloadArabicPDF(lines.filter(Boolean), `mystore-invoice-${invoice.id}.pdf`, null, 'invoice'); toast('تم إنشاء ملف PDF للفاتورة');
  }

  returnModal = async id => {
    const invoice = await get('invoices', id); if (!invoice) return;
    const lines = (invoice.items || []).map((item, index) => {
      if (!item.productId) return '';
      const remaining = Number(item.qty) - returnedQty(invoice, index);
      return `<label class="list-item"><span class="grow">${esc(item.name)}<div class="muted">المتاح للإرجاع ${remaining} · قيمة الإرجاع ${money(returnAmount(invoice, index, 1))} للقطعة</div></span><input class="input return-qty" data-index="${index}" type="number" min="0" max="${remaining}" step="1" value="0" style="max-width:100px"></label>`;
    }).join('');
    openModal(`مرتجع فاتورة #${id}`, `${lines || '<div class="empty">لا توجد أصناف مخزنية قابلة للإرجاع</div>'}<label class="field"><span>طريقة المعالجة</span><select class="input" id="return-mode"><option value="debt" ${dueAmount(invoice) > 0 ? 'selected' : ''}>تخفيض رصيد الدين</option><option value="refund" ${dueAmount(invoice) <= 0 ? 'selected' : ''}>خصم المبلغ من المقبوض</option></select></label><div class="row between"><span>الإجمالي الصافي الحالي</span><b>${money(netTotal(invoice))}</b></div><button class="btn full" id="save-return">تأكيد المرتجع</button>`);
    $('#save-return').onclick = async () => {
      const chosen = $$('.return-qty').map(input => ({ index: Number(input.dataset.index), qty: Number(input.value) })).filter(row => row.qty > 0);
      if (!chosen.length || chosen.some(row => !Number.isInteger(row.qty))) { toast('أدخل كميات صحيحة للإرجاع'); return; }
      const dbtx = db.transaction(['products', 'invoices'], 'readwrite'), done = transactionDone(dbtx), productStore = dbtx.objectStore('products'), invoiceStore = dbtx.objectStore('invoices');
      const abortWith = message => { toast(message); try { dbtx.abort(); } catch { } };
      const invoiceRequest = invoiceStore.get(id);
      invoiceRequest.onsuccess = () => {
        const fresh = invoiceRequest.result;
        if (!fresh) { abortWith('الفاتورة غير موجودة'); return; }
        const entries = [];
        for (const row of chosen) {
          const item = fresh.items[row.index], already = returnedQty(fresh, row.index);
          if (!item?.productId || row.qty > item.qty - already) { abortWith('كمية الإرجاع تتجاوز الكمية المتاحة'); return; }
          entries.push({ row, item, request: productStore.get(item.productId) });
        }
        let pending = entries.length, failed = false;
        entries.forEach(entry => entry.request.onsuccess = () => {
          const product = entry.request.result;
          if (!product) { failed = true; abortWith(`المنتج ${entry.item.name} غير موجود بالمخزون`); return; }
          entry.product = product;
          if (--pending !== 0 || failed) return;
        const refunded = sum(entries, row => returnAmount(fresh, row.row.index, row.row.qty)), currentNet = netTotal(fresh), date = toISO(), mode = $('#return-mode').value;
          if (refunded > currentNet) { abortWith('قيمة المرتجع أكبر من صافي الفاتورة'); return; }
          if (!fresh.netTotalApplied) fresh.grossTotal = Number(fresh.total);
          fresh.total = Math.max(0, currentNet - refunded); fresh.netTotalApplied = true; fresh.returns ||= [];
          entries.forEach(({ row, item, product }) => { product.qty += row.qty; productStore.put(product); fresh.returns.push({ itemIndex: row.index, qty: row.qty, date, refund: returnAmount(fresh, row.index, row.qty), mode }); });
          invoiceStore.put(fresh);
        });
      };
      try { await done; const updated = await get('invoices', id); closeModal(); toast(`تم تسجيل المرتجع. صافي الفاتورة ${money(netTotal(updated))}`); render(); }
      catch (error) { toast(error.message || 'تعذر تسجيل المرتجع؛ بقي المخزون والفاتورة كما كانا'); }
    };
  };

  async function amendInvoiceModal(id) {
    const invoice = await get('invoices', id); if (!invoice) return;
    openModal(`تعديل الفاتورة #${id}`, `<p class="notice">الإضافة تسجل كتعديل مؤرخ، وتخصم المخزون مرة واحدة عند الحفظ.</p><div class="searchbox"><input id="amend-search" class="input" placeholder="ابحث عن منتج"></div><div id="amend-results" class="list"></div><div id="amend-cart" class="list"></div><button class="btn full" id="save-amend" disabled>حفظ الإضافات</button>`);
    const additions = new Map();
    const refresh = async () => {
      const query = $('#amend-search').value.trim().toLowerCase();
      const products = (await all('products')).filter(product => product.name.toLowerCase().includes(query) || String(product.barcode || '').includes(query)).slice(0, 12);
      $('#amend-results').innerHTML = products.map(product => `<button class="list-item quick" data-amend-add="${product.id}"><span class="grow">${esc(product.name)} · متوفر ${product.qty}</span><b>${money(product.price)}</b></button>`).join('');
      $('#amend-cart').innerHTML = [...additions.values()].map(item => `<div class="list-item"><span class="grow">${esc(item.name)} × ${item.qty}</span><button class="icon-button" data-amend-remove="${item.productId}">−</button></div>`).join('');
      $('#save-amend').disabled = additions.size === 0;
    };
    $('#amend-search').oninput = refresh;
    $('#modal-body').onclick = async event => {
      const addButton = event.target.closest('[data-amend-add]'), removeButton = event.target.closest('[data-amend-remove]');
      if (addButton) { const product = await get('products', Number(addButton.dataset.amendAdd)); if (product) { const item = additions.get(product.id) || { productId: product.id, name: product.name, price: Number(product.price), cost: Number(product.cost), qty: 0 }; if (item.qty < product.qty) item.qty++; additions.set(product.id, item); await refresh(); } }
      if (removeButton) { const item = additions.get(Number(removeButton.dataset.amendRemove)); if (item && --item.qty <= 0) additions.delete(item.productId); await refresh(); }
      if (event.target.id === 'save-amend') {
        const dbtx = db.transaction(['products', 'invoices'], 'readwrite'), done = transactionDone(dbtx), productStore = dbtx.objectStore('products'), invoiceStore = dbtx.objectStore('invoices');
        const abortWith = message => { toast(message); try { dbtx.abort(); } catch { } };
        const invoiceRequest = invoiceStore.get(id);
        invoiceRequest.onsuccess = () => {
          const fresh = invoiceRequest.result;
          if (!fresh) { abortWith('الفاتورة غير موجودة'); return; }
          const items = [...additions.values()].map(item => ({ ...item, addedAt: toISO() }));
          const requests = items.map(item => ({ item, request: productStore.get(item.productId) }));
          let pending = requests.length, failed = false;
          requests.forEach(entry => entry.request.onsuccess = () => {
            entry.product = entry.request.result;
            if (!entry.product || entry.product.qty < entry.item.qty) { failed = true; abortWith(`المخزون غير كافٍ: ${entry.item.name}`); return; }
            if (--pending !== 0 || failed) return;
            requests.forEach(({ item, product }) => { product.qty -= item.qty; productStore.put(product); });
            const addedTotal = sum(items, item => item.price * item.qty);
            if (!fresh.netTotalApplied) fresh.grossTotal = Number(fresh.total) + returnValue(fresh);
            fresh.total = netTotal(fresh) + addedTotal; fresh.netTotalApplied = true;
            fresh.subtotal = Number(fresh.subtotal || 0) + addedTotal;
            fresh.items.push(...items); fresh.history ||= []; fresh.history.push({ type: 'items-added', date: toISO(), items, total: addedTotal });
            invoiceStore.put(fresh);
          });
        };
        try { await done; closeModal(); toast('تم تعديل الفاتورة وتحديث المخزون'); render(); }
        catch (error) { toast(error.message || 'تعذر تعديل الفاتورة؛ بقيت الفاتورة والمخزون دون تغيير'); }
      }
    };
    await refresh();
  }

  paymentModal = async id => {
    const invoice = await get('invoices', id); if (!invoice) return;
    const due = dueAmount(invoice);
    openModal('تسجيل دفعة', `<p>المتبقي: <b>${money(due)}</b></p><label class="field"><span>طريقة الدفع</span><input id="pay-method" class="input" value="نقداً"></label><label class="field"><span>المبلغ (₪)</span><input id="pay-amount" type="number" min="0.01" max="${due}" step="0.01" class="input"></label><button id="save-payment" class="btn full">تسجيل الدفعة</button>`);
    $('#save-payment').onclick = async () => {
      const amount = Number($('#pay-amount').value); if (amount <= 0 || amount > due) { toast('المبلغ غير صالح'); return; }
      invoice.payments ||= []; invoice.payments.push({ amount, date: toISO(), method: $('#pay-method').value.trim() || 'غير محدد' });
      await put('invoices', invoice); closeModal(); toast('تم تسجيل الدفعة'); render();
    };
  };

  async function stableSnapshot() {
    const names = Object.values(STORE), transaction = db.transaction(names, 'readonly'), done = transactionDone(transaction);
    const requests = names.map(name => reqP(transaction.objectStore(name).getAll()));
    const rows = await Promise.all(requests); await done;
    const stores = Object.fromEntries(names.map((name, index) => [name, rows[index].sort((a, b) => String(a.id ?? a.key).localeCompare(String(b.id ?? b.key)))]));
    stores.files = await Promise.all((stores.files || []).map(async row => {
      if (!row.blob) return row;
      const bytes = new Uint8Array(await row.blob.arrayBuffer()); let binary = '';
      for (let offset=0; offset<bytes.length; offset+=0x8000) binary += String.fromCharCode(...bytes.subarray(offset,Math.min(offset+0x8000,bytes.length)));
      return { ...row, blob: undefined, blobData: btoa(binary), blobType: row.blob.type || 'application/pdf' };
    }));
    return stores;
  }
  async function sha256(value) {
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
    return [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('');
  }
  async function backupDocument() {
    const stores = await stableSnapshot();
    const fingerprint = await sha256(JSON.stringify(stores));
    return { document: { format: 'mystore-backup', version: 2, exportedAt: toISO(), checksum: fingerprint, stores }, fingerprint };
  }
  settingsHTML = async () => {
    const shop = await setting('shopName', '');
    const meta = JSON.parse(localStorage.getItem(BACKUP_META_KEY) || 'null');
    return `<h1>الإعدادات</h1><p class="sub">بيانات المتجر والنسخ الاحتياطي اليدوي</p><div class="card"><label class="field"><span>اسم المتجر</span><input id="shop-setting" class="input" value="${esc(shop)}" placeholder="اسم المحل"></label><button class="btn full" data-action="save-shop">حفظ الاسم</button></div><div class="card"><h2>النسخ الاحتياطي</h2><p class="muted">ملف واحد يشمل المنتجات والفواتير والعملاء والدفعات والمرتجعات والمصاريف والإعدادات.</p><div class="muted" id="backup-status">${meta?.date ? `آخر نسخة على هذا الجهاز: ${dateFmt(meta.date)} · ${new Date(meta.date).toLocaleTimeString('ar-PS')}` : 'لم تُسجل نسخة احتياطية على هذا الجهاز بعد.'}</div><div class="list" style="margin-top:12px"><button class="btn full" data-backup="create">إنشاء نسخة احتياطية</button><button class="btn secondary full" data-backup="restore">استعادة نسخة احتياطية</button></div></div><div class="notice">النسخ يدوي. احتفظ بالملف وانقله إلى الهاتف الآخر بالطريقة التي تفضلها. إن لم يدعم المتصفح تحديث ملف موجود، ينزّل نسخة جديدة باسم وتاريخ واضحين. الاستعادة تستبدل بيانات هذا الجهاز بعد التحقق والتأكيد.</div><div class="card"><div class="row between"><span>حالة الاتصال</span><b>${navigator.onLine ? 'متصل' : 'دون إنترنت'}</b></div><div class="muted">يمكن استخدام التطبيق بعد تحميل ملفاته أول مرة.</div></div>`;
  };
  const bindSettingsActions = bindEnhancements;
  bindEnhancements = () => {
    bindSettingsActions();
    document.querySelectorAll('[data-backup]').forEach(button => button.addEventListener('click', () => button.dataset.backup === 'create' ? createBackup() : chooseRestoreFile()));
    document.querySelectorAll('[data-action="delete-customer"]').forEach(button => button.addEventListener('click', () => deleteSettledCustomer(Number(button.dataset.id))));
    document.querySelectorAll('[data-invoice-delete]').forEach(button => button.addEventListener('click', () => deleteInvoiceSafely(Number(button.dataset.invoiceDelete))));
  };

  async function createBackup() {
    try {
      let pickerRequest = null;
      if ('showOpenFilePicker' in window && confirm('إذا كان لديك ملف نسخة سابق، اختر «موافق» لتحديده وتحديثه. اختر «إلغاء» لتنزيل ملف نسخة جديد.')) {
        try { pickerRequest = window.showOpenFilePicker({ multiple: false, types: [{ description: 'نسخة MyStore', accept: { 'application/json': ['.json'] } }] }); }
        catch (error) { console.warn('File picker is unavailable; a new file will be downloaded.', error); }
      }
      const { document: payload, fingerprint } = await backupDocument();
      const meta = JSON.parse(localStorage.getItem(BACKUP_META_KEY) || 'null');
      if (meta?.fingerprint === fingerprint && !pickerRequest) { toast('النسخة الاحتياطية الحالية محدثة، لا توجد تغييرات'); return; }
      let savedInPlace = false;
      if (pickerRequest) {
        try {
          const [handle] = await pickerRequest;
          if (meta?.fingerprint === fingerprint) { toast('النسخة الاحتياطية الحالية محدثة، لا توجد تغييرات'); return; }
          const existing = JSON.parse(await (await handle.getFile()).text());
          if (existing?.format !== 'mystore-backup' || ![1, 2].includes(Number(existing.version))) throw new Error('الملف المحدد ليس نسخة MyStore معروفة');
          const writable = await handle.createWritable(); await writable.write(JSON.stringify(payload, null, 2)); await writable.close(); savedInPlace = true;
        } catch (error) { if (error.name === 'AbortError') return; toast('تعذر تحديث الملف المحدد؛ سيتم تنزيل نسخة جديدة.'); }
      }
      if (!savedInPlace) {
        const link = document.createElement('a'), url = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' }));
        link.href = url; link.download = `mystore-backup-${todayKey()}-${new Date().toTimeString().slice(0, 8).replaceAll(':', '')}.json`; link.click(); setTimeout(() => URL.revokeObjectURL(url), 2000);
      }
      const date = toISO(); localStorage.setItem(BACKUP_META_KEY, JSON.stringify({ fingerprint, date }));
      toast(savedInPlace ? 'تم تحديث ملف النسخة الاحتياطية' : 'تم تنزيل ملف النسخة الاحتياطية'); render();
    } catch (error) { console.error(error); toast('تعذر إنشاء النسخة الاحتياطية'); }
  }
  async function chooseRestoreFile() {
    if ('showOpenFilePicker' in window) {
      try { const [handle] = await window.showOpenFilePicker({ multiple: false, types: [{ description: 'نسخة MyStore', accept: { 'application/json': ['.json'] } }] }); await restoreFile(await handle.getFile()); return; }
      catch (error) { if (error.name === 'AbortError') return; }
    }
    const input = document.createElement('input'); input.type = 'file'; input.accept = '.json,application/json'; input.onchange = () => { if (input.files[0]) restoreFile(input.files[0]); }; input.click();
  }
  restoreFile = async file => {
    try {
      const payload = JSON.parse(await file.text());
      if (payload?.format !== 'mystore-backup' || ![1, 2].includes(Number(payload.version)) || !payload.stores || typeof payload.stores !== 'object') throw new Error('صيغة النسخة أو إصدارها غير مدعوم');
      const checksumSource = JSON.stringify(payload.stores);
      payload.stores.purchases ||= []; payload.stores.files ||= [];
      for (const store of Object.values(STORE)) if (!Array.isArray(payload.stores[store])) throw new Error(`النسخة ناقصة: ${store}`);
      for (const store of Object.values(STORE)) {
        const keys = new Set();
        for (const row of payload.stores[store]) {
          const key = store === 'settings' ? row?.key : row?.id;
          if (key === undefined || key === null || keys.has(String(key))) throw new Error(`مفتاح مفقود أو مكرر في ${store}`);
          keys.add(String(key));
        }
      }
      for (const row of payload.stores.products) if (!row || typeof row.name !== 'string' || !row.name.trim() || !Number.isFinite(Number(row.qty)) || Number(row.qty) < 0 || (!row.weighted&&!Number.isInteger(Number(row.qty))) || !Number.isFinite(Number(row.price)) || Number(row.price) < 0 || (row.cost !== undefined && (!Number.isFinite(Number(row.cost)) || Number(row.cost) < 0))) throw new Error('بيانات منتج غير سليمة');
      for (const row of payload.stores.customers) if (!row || typeof row.name !== 'string' || !row.name.trim()) throw new Error('بيانات زبون غير سليمة');
      for (const row of payload.stores.expenses) if (!row || typeof row.title !== 'string' || !row.title.trim() || !Number.isFinite(Number(row.amount)) || Number(row.amount) < 0) throw new Error('بيانات مصروف غير سليمة');
      for (const row of payload.stores.invoices) {
        if (!row || !Array.isArray(row.items) || !Number.isFinite(Number(row.total)) || !row.items.every(item => item && typeof item.name === 'string' && Number.isFinite(Number(item.qty)) && Number(item.qty) > 0 && (item.weighted||Number.isInteger(Number(item.qty))) && Number.isFinite(Number(item.price)) && Number(item.price) >= 0 && (item.cost === undefined || (Number.isFinite(Number(item.cost)) && Number(item.cost) >= 0)))) throw new Error('بيانات فاتورة غير سليمة');
        if (row.payments !== undefined && (!Array.isArray(row.payments) || !row.payments.every(payment => Number.isFinite(Number(payment.amount)) && Number(payment.amount) >= 0))) throw new Error('بيانات دفعة غير سليمة');
        if (row.returns !== undefined && (!Array.isArray(row.returns) || !row.returns.every(item => Number.isInteger(Number(item.itemIndex)) && item.itemIndex >= 0 && item.itemIndex < row.items.length && Number.isFinite(Number(item.qty)) && item.qty > 0 && Number.isFinite(Number(item.refund)) && item.refund >= 0))) throw new Error('بيانات مرتجع غير سليمة');
      }
      if (Number(payload.version) === 2 && await sha256(checksumSource) !== payload.checksum) throw new Error('فشل التحقق من سلامة النسخة');
      if (!confirm(`سيتم استبدال بيانات هذا الجهاز بمحتوى النسخة بتاريخ ${payload.exportedAt ? dateFmt(payload.exportedAt) : 'غير معروف'}. تأكد من حفظ نسخة من البيانات الحالية. هل تريد المتابعة؟`)) return;
      const dbtx = db.transaction(Object.values(STORE), 'readwrite'), done = transactionDone(dbtx);
      try {
        for (const name of Object.values(STORE)) {
          const objectStore = dbtx.objectStore(name); objectStore.clear();
          payload.stores[name].forEach(row => { if (name==='files' && row.blobData) { const binary=atob(row.blobData),bytes=new Uint8Array(binary.length); for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i); row={...row,blob:new Blob([bytes],{type:row.blobType||'application/pdf'})}; delete row.blobData; delete row.blobType; } objectStore.put(row); });
        }
        await done;
      } catch (error) { try { dbtx.abort(); } catch { } try { await done; } catch { } throw error; }
      const fingerprint = Number(payload.version) === 2 ? payload.checksum : await sha256(JSON.stringify(payload.stores));
      localStorage.setItem(BACKUP_META_KEY, JSON.stringify({ fingerprint, date: payload.exportedAt || toISO() }));
      toast('تم التحقق من النسخة واستعادة البيانات'); render();
    } catch (error) { console.error(error); toast(error.message || 'تعذرت استعادة النسخة؛ بقيت البيانات الحالية كما هي'); }
  };
  backup = createBackup;

  customerPaymentModal = async id => {
    const customer = await get('customers', id);
    const invoices = (await all('invoices')).filter(invoice => invoice.customerId === id && !invoice.voided && dueAmount(invoice) > 0).sort((a, b) => a.date.localeCompare(b.date));
    const due = sum(invoices, invoice => dueAmount(invoice));
    openModal('تسديد دين الزبون', `<p>${esc(customer?.name || '')} · الرصيد ${money(due)}</p><label class="field"><span>طريقة الدفع</span><input id="customer-pay-method" class="input" value="نقداً"></label><label class="field"><span>المبلغ (₪)</span><input id="customer-pay" class="input" type="number" min="0.01" max="${due}" step="0.01"></label><button id="save-customer-pay" class="btn full">تسجيل التسديد</button>`);
    $('#save-customer-pay').onclick = async () => {
      let amount = Number($('#customer-pay').value); if (amount <= 0 || amount > due) { toast('المبلغ غير صالح'); return; }
      const method = $('#customer-pay-method').value.trim() || 'غير محدد';
      const dbtx = db.transaction('invoices', 'readwrite'), done = transactionDone(dbtx), store = dbtx.objectStore('invoices'), request = store.getAll();
      request.onsuccess = () => {
        const current = request.result.filter(invoice => invoice.customerId === id && !invoice.voided && dueAmount(invoice) > 0).sort((a, b) => a.date.localeCompare(b.date));
        let remainingAmount = amount; const date = toISO();
        for (const invoice of current) {
          const part = Math.min(remainingAmount, dueAmount(invoice));
          if (part > 0) { invoice.payments ||= []; invoice.payments.push({ amount: part, date, method }); store.put(invoice); remainingAmount -= part; }
          if (remainingAmount <= 0) break;
        }
        if (remainingAmount > 0) { try { dbtx.abort(); } catch { } }
      };
      try { await done; closeModal(); toast('تم تسجيل التسديد'); render(); }
      catch (error) { toast(error.message || 'تعذر حفظ التسديد؛ لم تتغير ديون الزبون'); }
    };
  };

  // New navigation and workspace pages; existing accounting actions remain in place.
  let reportRange = 'month', reportSection = 'summary', fileTab = 'invoice', fileQuery = '';
  let purchaseCart = [], purchaseTab = 'new', salesTab = 'new';
  let salesCarts = [{ items: [], customer: '', discount: 0 }], activeSalesCart = 0, cartViewActive = false;
  const pageTitles = { home: 'الرئيسية', sales: 'المبيعات', cashier: 'المبيعات', invoices: 'المبيعات', products: 'الأصناف', customers: 'الزبائن', reports: 'التقارير', purchases: 'المشتريات', backup: 'النسخ الاحتياطي', files: 'الملفات' };
  const iconFor = { cashier: '↗', purchases: '↙', products: '▦', customers: '♙', reports: '▤' };
  homeHTML = async () => `<div class="home-welcome"><p class="eyebrow">إدارة متجرك</p><h1>أهلاً بك في متجري</h1><p class="sub">اختر القسم الذي تريد العمل عليه</p></div><div class="home-tiles">${[['sales','المبيعات','↗'],['purchases','المشتريات','↙'],['products','الأصناف','▦'],['customers','الزبائن','♙'],['reports','التقارير','▤']].map(([target,label,icon])=>`<button class="home-tile" data-home-target="${target}"><span class="tile-icon">${icon}</span><span>${label}</span><b>‹</b></button>`).join('')}</div>`;
  moreHTML = () => `<h1>القائمة</h1><p class="sub">التنقل وإدارة ملفات المتجر</p><div class="list">${[['home','⌂','الرئيسية','العودة إلى الصفحة الرئيسية'],['backup','◫','النسخ الاحتياطي','إنشاء نسخة أو استعادتها'],['files','▧','الملفات','الفواتير والتقارير المحفوظة']].map(([target,icon,label,hint])=>`<button class="list-item quick" data-home-target="${target}"><div class="avatar">${icon}</div><div class="grow"><div class="item-title">${label}</div><div class="muted">${hint}</div></div><span>‹</span></button>`).join('')}</div>`;

  function periodBounds(range) {
    const end = new Date(); end.setHours(23,59,59,999); const start = new Date(end); start.setHours(0,0,0,0);
    if (range === 'week') start.setDate(start.getDate() - ((start.getDay() + 6) % 7));
    else if (range === 'month') start.setDate(1);
    else if (range === 'custom') { const from = $('#report-from')?.value, to = $('#report-to')?.value; if (from) start.setTime(new Date(`${from}T00:00:00`).getTime()); if (to) end.setTime(new Date(`${to}T23:59:59`).getTime()); }
    return [start, end];
  }
  const inReportRange = (value, bounds) => { const date = new Date(value); return date >= bounds[0] && date <= bounds[1]; };
  async function rangeReport() {
    const bounds = periodBounds(reportRange), [invoices, expenses, purchases] = await Promise.all([all('invoices'), all('expenses'), all('purchases')]);
    const active = invoices.filter(row => !row.voided), salesRows = active.filter(row => inReportRange(row.date, bounds));
    const initialSales = sum(active.filter(invoice=>inReportRange(invoice.date,bounds)), invoice => invoiceOriginalAmount(invoice));
    const adjustments = sum(active, invoice => sum(saleAdjustments(invoice).filter(row=>inReportRange(row.date,bounds)), row=>row.total));
    const returns = sum(active, invoice => sum((invoice.returns||[]).filter(row=>inReportRange(row.date,bounds)), row=>row.refund));
    const sales = Math.max(0,initialSales+adjustments-returns);
    const purchaseTotal = sum(purchases.filter(row => inReportRange(row.date, bounds)), row => row.total);
    const originalCost = sum(active.filter(invoice=>inReportRange(invoice.date,bounds)), invoice => sum((invoice.items||[]).filter(item=>!item.addedAt),item=>Number(item.cost||0)*Number(item.qty||0)));
    const adjustmentCost = sum(active, invoice => sum(saleAdjustments(invoice).filter(row=>inReportRange(row.date,bounds)),row=>sum(row.items||[],item=>Number(item.cost||0)*Number(item.qty||0))));
    const returnCost = sum(active, invoice => sum((invoice.returns||[]).filter(row=>inReportRange(row.date,bounds)),row=>Number(invoice.items[row.itemIndex]?.cost||0)*Number(row.qty||0)));
    const cost = Math.max(0,originalCost+adjustmentCost-returnCost);
    const expenseTotal = sum(expenses.filter(row => inReportRange(row.date, bounds)), row => row.amount);
    const paymentMethods = new Map();
    active.forEach(invoice => (invoice.payments || []).filter(payment => inReportRange(payment.date, bounds)).forEach(payment => { const method=payment.method||invoice.paymentMethod||'غير محدد'; paymentMethods.set(method,(paymentMethods.get(method)||0)+Number(payment.amount||0)); }));
    const received = [...paymentMethods.values()].reduce((total,value)=>total+value,0);
    return { bounds, salesRows, sales, purchaseTotal, cost, expenseTotal, received, paymentMethods, profit: sales-cost-expenseTotal, purchases: purchases.filter(row=>inReportRange(row.date,bounds)), expenseRows:expenses.filter(row=>inReportRange(row.date,bounds)) };
  }
  financeHTML = async () => {
    const report = await rangeReport(), fmt = date => `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
    const tabs = [['summary','الملخص'],['revenue','الإيرادات'],['sales','المبيعات'],['purchases','المشتريات']];
    const summary = `<div class="report-grid">${[['إجمالي المبيعات',report.sales],['إجمالي المشتريات',report.purchaseTotal],['المصروفات',report.expenseTotal],['إجمالي الأرباح',report.sales-report.cost],['صافي الربح',report.profit]].map(([label,value])=>`<div class="stat"><span class="label">${label}</span><strong>${money(value)}</strong></div>`).join('')}</div><div class="card"><h2>الأرباح والخسائر</h2><div class="table-row"><span>المبيعات</span><b>${money(report.sales)}</b></div><div class="table-row"><span>تكلفة البضاعة</span><b>${money(report.cost)}</b></div><div class="table-row"><span>هامش الربح</span><b>${money(report.sales-report.cost)}</b></div><div class="table-row"><span>المصروفات</span><b>${money(report.expenseTotal)}</b></div><div class="table-row"><b>صافي الأرباح</b><b>${money(report.profit)}</b></div></div>`;
    const details = reportSection==='sales' ? report.salesRows.map(row=>`<div class="list-item"><div class="grow"><b>فاتورة #${row.id} · ${esc(row.customer||'بيع مباشر')}</b><div class="muted">${dateTimeFmt(row.date)} · ${esc((row.payments||[]).map(x=>x.method).filter(Boolean).join('، ')||'آجل')}</div></div><b>${money(netTotal(row))}</b><button class="btn secondary small" data-action="view-invoice" data-id="${row.id}">عرض</button></div>`).join('') : reportSection==='purchases' ? report.purchases.map(row=>`<div class="list-item"><div class="grow"><b>شراء #${row.id}</b><div class="muted">${dateTimeFmt(row.date)} · ${(row.items||[]).length} أصناف</div></div><b>${money(row.total)}</b></div>`).join('') : reportSection==='revenue' ? `<div class="card"><div class="table-row"><span>إجمالي المقبوض في الفترة</span><b>${money(report.received)}</b></div>${[...report.paymentMethods].map(([method,amount])=>`<div class="table-row"><span>${esc(method)}</span><b>${money(amount)}</b></div>`).join('')}<div class="table-row"><span>الرصيد المتبقي على فواتير الفترة</span><b>${money(sum(report.salesRows,dueAmount))}</b></div><div class="muted">تتضمن المبالغ الدفعات الجزئية والمختلطة بحسب وسيلة الدفع المسجلة.</div></div>` : '';
    return `<div class="row between"><div><h1>التقارير</h1><p class="sub">نتائج من سجلات المتجر حسب الفترة</p></div><button class="btn" data-report-pdf>PDF</button></div><div class="range-chips">${[['day','اليوم'],['week','هذا الأسبوع'],['month','هذا الشهر'],['custom','فترة مخصصة']].map(([key,label])=>`<button class="tab ${reportRange===key?'active':''}" data-range="${key}">${label}</button>`).join('')}</div>${reportRange==='custom'?`<div class="row"><label class="field grow"><span>من</span><input id="report-from" class="input" type="date" value="${fmt(report.bounds[0])}"></label><label class="field grow"><span>إلى</span><input id="report-to" class="input" type="date" value="${fmt(report.bounds[1])}"></label></div>`:''}<div class="report-highlights"><div><span>إجمالي المبيعات</span><b>${money(report.sales)}</b></div><div><span>إجمالي الأرباح</span><b>${money(report.sales-report.cost)}</b></div></div><div class="tabs">${tabs.map(([key,label])=>`<button class="tab ${reportSection===key?'active':''}" data-report-tab="${key}">${label}</button>`).join('')}</div>${reportSection==='summary'?`${summary}<section class="card"><div class="row between"><h2>المصروفات</h2><button class="btn secondary small" data-action="add-expense">＋ تسجيل مصروف</button></div>${report.expenseRows.map(row=>`<div class="table-row" style="display:flex;align-items:center;justify-content:space-between;gap:12px"><span style="flex:1">${esc(row.title)}<small class="muted" style="display:block;margin-top:2px">${dateTimeFmt(row.date)}</small></span><div style="display:flex;align-items:center;gap:10px"><b>${money(row.amount)}</b><button type="button" class="btn-delete-expense" data-action="delete-expense" data-id="${row.id}" data-delete-expense="${row.id}" title="حذف المصروف" aria-label="حذف المصروف">🗑</button></div></div>`).join('')||'<div class="muted">لا توجد مصروفات في هذه الفترة</div>'}</section>`:`<div class="list">${details||'<div class="empty">لا توجد بيانات في الفترة المحددة</div>'}</div>`}<dialog id="report-export"><div class="modal-shell"><header class="modal-head"><h2>تصدير تقرير PDF</h2><button type="button" class="icon-button" data-close-export>×</button></header><div class="export-options">${[['summary','الملخص'],['sales','المبيعات'],['products','الأصناف']].map(([key,label])=>`<button class="list-item quick" data-export="${key}"><span>${label}</span><b>‹</b></button>`).join('')}</div></div></dialog>`;
  };

  settingsHTML = async () => {
    const meta = JSON.parse(localStorage.getItem(BACKUP_META_KEY) || 'null');
    return `<h1>النسخ الاحتياطي</h1><p class="sub">حافظ على نسخة من بيانات المتجر واستعدها عند الحاجة</p><div class="card backup-card"><div class="avatar">◫</div><div><span class="label">آخر نسخة احتياطية ناجحة</span><h2>${meta?.date ? dateTimeFmt(meta.date) : 'لم تُنشأ نسخة بعد'}</h2></div></div><section class="card"><h2>إنشاء نسخة احتياطية</h2><p class="muted">تشمل الأصناف والمخزون والعملاء والفواتير والمشتريات والدفعات والإعدادات.</p><button class="btn full" data-backup="create">نسخ على الجهاز</button></section><section class="card"><h2>استعادة النسخة</h2><p class="muted">اختر ملف نسخة MyStore. سيتحقق التطبيق من سلامته قبل الاستعادة.</p><button class="btn secondary full" data-backup="restore">استعادة من الجهاز</button></section>`;
  };

  async function filesHTML() {
    const files=(await all('files')).filter(file=>file.kind===fileTab&&`${file.name}`.toLowerCase().includes(fileQuery.toLowerCase())).sort((a,b)=>b.created.localeCompare(a.created));
    return `<h1>الملفات</h1><p class="sub">الملفات التي نزّلتها من التطبيق</p><div class="tabs"><button class="tab ${fileTab==='invoice'?'active':''}" data-file-tab="invoice">فواتيري</button><button class="tab ${fileTab==='report'?'active':''}" data-file-tab="report">التقارير</button></div><div class="searchbox"><input id="file-search" class="input" placeholder="ابحث عن ملف بالاسم" value="${esc(fileQuery)}"></div><div class="list">${files.length?files.map(file=>`<article class="file-card"><div class="avatar">PDF</div><div class="grow"><b>${esc(file.name)}</b><div class="muted">${dateTimeFmt(file.created)}</div></div><details class="file-menu"><summary aria-label="إجراءات الملف">⋮</summary><div><button data-file-open="${file.id}">فتح</button><button data-file-share="${file.id}">مشاركة</button><button data-file-delete="${file.id}">حذف من الملفات</button></div></details></article>`).join(''):'<div class="empty">لا توجد ملفات PDF محفوظة هنا بعد</div>'}</div>`;
  }

  purchasesHTML = async () => {
    const purchases=(await all('purchases')).sort((a,b)=>b.date.localeCompare(a.date));
    return `<h1>المشتريات</h1><p class="sub">تسجيل الشراء وتحديث كميات المخزون</p><div class="tabs"><button class="tab ${purchaseTab==='new'?'active':''}" data-purchase-tab="new">شراء جديد</button><button class="tab ${purchaseTab==='history'?'active':''}" data-purchase-tab="history">سجل المشتريات</button></div>${purchaseTab==='new'?`<div class="row"><div class="searchbox grow"><input id="purchase-search" class="input" placeholder="ابحث بالاسم أو الباركود"></div><button class="btn secondary" data-action="scan-purchase">▣</button><button class="btn secondary" data-action="add-product">＋ صنف جديد</button></div><div id="purchase-results" class="list"></div><div class="list">${purchaseCart.map((item,index)=>`<div class="list-item"><div class="grow"><b>${esc(item.name)}</b><div class="muted">إجمالي السطر ${money(item.cost*item.qty)}</div></div><label class="field"><span>تكلفة الوحدة</span><input class="input purchase-cost" data-index="${index}" type="number" min="0" step="0.01" value="${item.cost}" style="max-width:120px"></label><label class="field"><span>الكمية</span><input class="input purchase-qty" data-index="${index}" type="number" min="${item.weighted?'0.001':'1'}" step="${item.weighted?'0.001':'1'}" value="${item.qty}" style="max-width:90px"></label></div>`).join('')||'<div class="empty">أضف الأصناف التي اشتريتها</div>'}</div><div class="total-bar"><div class="row between"><b>إجمالي التكلفة</b><b>${money(sum(purchaseCart,x=>x.qty*x.cost))}</b></div><button class="btn full" data-purchase-save ${purchaseCart.length?'':'disabled'}>إتمام الشراء وإضافة المخزون</button></div>`:`<div class="list">${purchases.map(row=>`<article class="card"><b>عملية شراء #${row.id}</b><div class="muted">${dateTimeFmt(row.date)}</div>${(row.items||[]).map(item=>`<div class="table-row"><span>${esc(item.name)} × ${item.qty}</span><b>${money(item.cost*item.qty)}</b></div>`).join('')}<div class="table-row"><b>الإجمالي</b><b>${money(row.total)}</b></div></article>`).join('')||'<div class="empty">لا توجد عمليات شراء مسجلة</div>'}</div>`}`;

  };
  async function salesHTML(){return `<h1>المبيعات</h1><p class="sub">أنشئ فاتورة أو راجع الفواتير السابقة</p><div class="tabs"><button class="tab ${salesTab==='new'?'active':''}" data-sales-tab="new">بيع جديد</button><button class="tab ${salesTab==='history'?'active':''}" data-sales-tab="history">سجل المبيعات</button></div>${salesTab==='new'?`<div class="sale-cart-tabs">${salesCarts.map((item,index)=>`<button class="tab ${index===activeSalesCart?'active':''}" data-sale-cart="${index}">سلة ${index+1}${item.customer?` · ${esc(item.customer)}`:''}</button>`).join('')}<button class="btn secondary small" data-sale-cart-new>＋ سلة جديدة</button></div>${await cashierHTML()}`:await invoicesHTML()}`;}
  const oldRender = render;
  render = async () => {
    if (!['backup','files','purchases','sales'].includes(page)) return oldRender();
    nav(); const app=$('#app'); try { app.innerHTML=page==='backup'?await settingsHTML():page==='files'?await filesHTML():page==='purchases'?await purchasesHTML():await salesHTML(); bindPage(); }
    catch(error){console.error(error);app.innerHTML=`<div class="notice">تعذر تحميل الصفحة: ${esc(error.message)}</div>`;}
  };
  const oldHomeRender = render;
  const baseRenderWorkspace = oldHomeRender;
  // Home and reports use the same database-backed rendering pipeline.
  const workspaceRender = render;
  render = async () => { if (page==='reports'||page==='finance'||page==='expenses') { nav(); const app=$('#app'); app.innerHTML=await financeHTML(); bindPage(); } else return workspaceRender(); };

  function go(target) { if(target==='backup'||target==='files'||target==='purchases'||target==='reports'||target==='customers'||target==='products'||target==='sales'||target==='cashier'||target==='home'||target==='invoices') { page=target; searchText=''; if(target==='products'){lowStockOnly=false;outOfStockOnly=false} render(); } }
  function bindWorkspace() {
    document.querySelectorAll('[data-home-target]').forEach(button=>button.onclick=()=>go(button.dataset.homeTarget));
    document.querySelectorAll('[data-report-tab]').forEach(button=>button.onclick=()=>{reportSection=button.dataset.reportTab;render()});
    document.querySelectorAll('[data-range]').forEach(button=>button.onclick=()=>{reportRange=button.dataset.range;render()});
    document.querySelectorAll('[data-file-tab]').forEach(button=>button.onclick=()=>{fileTab=button.dataset.fileTab;render()});
    $('#file-search')?.addEventListener('input',event=>{fileQuery=event.target.value;renderKeepFocus('file-search')});
    document.querySelectorAll('[data-file-delete]').forEach(button=>button.onclick=async()=>{await del('files',Number(button.dataset.fileDelete));render()});
    document.querySelectorAll('[data-delete-expense]').forEach(button=>button.onclick=()=>deleteExpense(Number(button.dataset.deleteExpense)));
    document.querySelectorAll('[data-file-open],[data-file-share]').forEach(button=>button.onclick=async()=>{const file=await get('files',Number(button.dataset.fileOpen||button.dataset.fileShare));if(!file?.blob)return toast('الملف غير متاح');const url=URL.createObjectURL(file.blob);if(button.hasAttribute('data-file-share')&&navigator.share){try{await navigator.share({title:file.name,files:[new File([file.blob],file.name,{type:'application/pdf'})]})}catch{} }else window.open(url,'_blank');setTimeout(()=>URL.revokeObjectURL(url),60000)});
    const exportDialog=$('#report-export');document.querySelector('[data-report-pdf]')?.addEventListener('click',()=>exportDialog?.showModal());document.querySelector('[data-close-export]')?.addEventListener('click',()=>exportDialog?.close());
    document.querySelectorAll('[data-export]').forEach(button=>button.onclick=async()=>{const report=await rangeReport(),kind=button.dataset.export;let lines;if(kind==='sales')lines=['تقرير المبيعات',...report.salesRows.map(row=>`فاتورة #${row.id} · ${row.customer||'بيع مباشر'} · ${dateTimeFmt(row.date)} · ${money(netTotal(row))}`)];else if(kind==='products'){const products=await all('products');lines=['تقرير الأصناف',...products.map(item=>`${item.name} · باركود ${item.barcode||'—'} · كمية ${item.qty} · بيع ${money(item.price)}`)]}else lines=['ملخص التقارير',`المبيعات: ${money(report.sales)}`,`المشتريات: ${money(report.purchaseTotal)}`,`المصروفات: ${money(report.expenseTotal)}`,`تكلفة البضاعة: ${money(report.cost)}`,`صافي الربح: ${money(report.profit)}`];downloadArabicPDF(lines,`mystore-report-${kind}-${todayKey()}.pdf`,null,'report');exportDialog.close()});
    document.querySelectorAll('[data-purchase-tab]').forEach(button=>button.onclick=()=>{purchaseTab=button.dataset.purchaseTab;render()});
    document.querySelectorAll('[data-sales-tab]').forEach(button=>button.onclick=()=>{salesTab=button.dataset.salesTab;render()});
    document.querySelectorAll('[data-sale-cart]').forEach(button=>button.onclick=()=>{captureActiveCart();activeSalesCart=Number(button.dataset.saleCart);cart=salesCarts[activeSalesCart].items.map(item=>({...item}));cartViewActive=false;render()});
    document.querySelectorAll('[data-sale-cart-new]').forEach(button=>button.onclick=()=>{captureActiveCart();salesCarts.push({items:[],customer:'',discount:0});activeSalesCart=salesCarts.length-1;cart=[];cartViewActive=false;render()});
    $('#sale-customer')?.addEventListener('input',event=>{if(salesCarts[activeSalesCart])salesCarts[activeSalesCart].customer=event.target.value});
    $('#sale-discount')?.addEventListener('input',event=>{if(salesCarts[activeSalesCart])salesCarts[activeSalesCart].discount=Number(event.target.value)||0});
    ['report-from','report-to'].forEach(id=>$('#'+id)?.addEventListener('change',()=>render()));
    document.querySelectorAll('[data-product-scan]').forEach(button=>button.onclick=()=>scanner(code=>{searchText=code;render()}));
    $('#purchase-search')?.addEventListener('input',async event=>{const q=event.target.value.toLowerCase(),products=(await all('products')).filter(item=>`${item.name} ${item.barcode||''}`.toLowerCase().includes(q)).slice(0,8);$('#purchase-results').innerHTML=products.map(item=>`<button class="list-item quick" data-purchase-add="${item.id}"><div class="grow"><b>${esc(item.name)}</b><div class="muted">${item.barcode||'بدون باركود'} · الكمية الحالية ${item.qty}</div></div><b>${money(item.cost)}</b></button>`).join('');document.querySelectorAll('[data-purchase-add]').forEach(row=>row.onclick=()=>addPurchaseItem(Number(row.dataset.purchaseAdd)))});
    document.querySelectorAll('[data-purchase-save]').forEach(button=>button.onclick=savePurchase);
    document.querySelectorAll('.purchase-qty').forEach(input=>input.onchange=()=>{const item=purchaseCart[Number(input.dataset.index)],minimum=item.weighted?0.001:1;item.qty=Math.max(minimum,Number(input.value)||minimum);render()});
    document.querySelectorAll('.purchase-cost').forEach(input=>input.onchange=()=>{purchaseCart[Number(input.dataset.index)].cost=Math.max(0,Number(input.value)||0);render()});
    document.querySelectorAll('.weighted-qty').forEach(input=>input.onchange=async()=>{const index=Number(input.dataset.index),qty=Number(input.value),product=await get('products',cart[index]?.productId);if(!Number.isFinite(qty)||qty<=0||qty>Number(product?.qty||0)){toast('أدخل كمية وزن متوفرة');render();return}cart[index].qty=Number(qty.toFixed(3));render()});
    document.querySelectorAll('[data-action="scan-purchase"]').forEach(button=>button.onclick=()=>scanner(null,{mode:'purchase'}));
  }
  function captureActiveCart(){if(!salesCarts[activeSalesCart])return;const current=salesCarts[activeSalesCart];current.items=cart.map(item=>({...item}));current.customer=$('#sale-customer')?.value??current.customer;current.discount=Number($('#sale-discount')?.value??current.discount)||0;}
  async function addPurchaseItem(id){const product=await get('products',id);if(!product)return;const found=purchaseCart.find(row=>row.productId===id);if(found)found.qty++;else purchaseCart.push({productId:id,name:product.name,cost:Number(product.cost||0),qty:1,weighted:!!product.weighted});render()}
  async function savePurchase(){if(!purchaseCart.length)return;const total=sum(purchaseCart,item=>item.qty*item.cost),date=toISO(),dbtx=db.transaction(['products','purchases'],'readwrite'),done=transactionDone(dbtx),productStore=dbtx.objectStore('products');for(const item of purchaseCart){const req=productStore.get(item.productId);req.onsuccess=()=>{const product=req.result;if(product){product.qty=Number(product.qty||0)+item.qty;product.cost=Number(item.cost);productStore.put(product)}}}dbtx.objectStore('purchases').add({date,items:purchaseCart.map(item=>({...item})),total});try{await done;purchaseCart=[];purchaseTab='history';toast('تم تسجيل الشراء وتحديث المخزون');render()}catch(error){toast(error.message||'تعذر تسجيل الشراء')}}

  // Replace legacy bottom navigation with the reference style drawer.
  const drawer=document.createElement('aside'); drawer.className='side-drawer'; drawer.id='side-drawer'; drawer.innerHTML=`<div class="drawer-head"><strong>متجري</strong><button class="icon-button" data-drawer-close>×</button></div><button data-drawer-go="home">⌂ <span>الرئيسية</span></button><button data-drawer-go="backup">◫ <span>النسخ الاحتياطي</span></button><button data-drawer-go="files">▧ <span>الملفات</span></button>`;
  document.body.append(drawer); const backdrop=document.createElement('div');backdrop.className='drawer-backdrop';document.body.append(backdrop);
  const menuButton=document.createElement('button');menuButton.className='icon-button menu-trigger';menuButton.setAttribute('aria-label','فتح القائمة');menuButton.textContent='☰';document.querySelector('.topbar').prepend(menuButton);
  menuButton.onclick=()=>{drawer.classList.add('open');backdrop.classList.add('open')}; const closeDrawer=()=>{drawer.classList.remove('open');backdrop.classList.remove('open')}; backdrop.onclick=closeDrawer;drawer.querySelector('[data-drawer-close]').onclick=closeDrawer;
  drawer.querySelectorAll('[data-drawer-go]').forEach(button=>button.onclick=()=>{closeDrawer();go(button.dataset.drawerGo)});
  document.querySelectorAll('.bottom-nav button').forEach(button=>button.onclick=()=>go(({home:'home',cashier:'cashier',products:'products',invoices:'invoices',more:'more'})[button.dataset.page]||'home'));
  const moreRender=render; render=async()=>{
    if(cartViewActive){const saved=salesCarts[activeSalesCart];saved.items=cart.map(item=>({...item}));saved.customer=$('#sale-customer')?.value??saved.customer;saved.discount=Number($('#sale-discount')?.value??saved.discount)||0;}
    cartViewActive=(page==='sales'&&salesTab==='new')||page==='cashier';
    if(cartViewActive){while(salesCarts.length<=activeSalesCart)salesCarts.push({items:[],customer:'',discount:0});cart=salesCarts[activeSalesCart].items.map(item=>({...item}));}
    if(page==='more'){nav();$('#app').innerHTML=moreHTML();bindPage();return}
    return moreRender();
  };
  document.querySelectorAll('.bottom-nav button[data-page="more"]').forEach(button=>button.onclick=()=>go('more'));
  const baseBindFinal=bindPage; bindPage=()=>{baseBindFinal();bindWorkspace()};

})();
