# Carreira de Craque v1.47.6 — Flamengo fiel à referência

- Flamengo titular: mangas e gola pretas.
- Três faixas horizontais grossas no corpo: vermelha superior começando perto do topo, preta no meio e vermelha inferior.
- Aplicado tanto na arte da camisa do jogador quanto na prévia vetorial, pelo padrão compartilhado usado no profissional e no Sub-20.
- Cache PWA atualizado para forçar o carregamento da nova versão.
