Amount & Commission Calculator - Android Studio project

Features:
- Total amount input
- Decimal percentage deduction (e.g. 1.45%)
- Decimal commission percentage (e.g. 0.25%)
- Both percentages calculated from the original total amount
- Live results and reset-to-zero button
- Offline operation; no internet permission required

Build an APK:
1. Install Android Studio on a computer.
2. Open the folder AmountCommissionCalculator in Android Studio.
3. Allow Gradle sync and install any requested Android SDK platform (API 35).
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location. Usually:
   app/build/outputs/apk/debug/app-debug.apk
6. Transfer the APK to your Android phone and open it to install. You may need to allow
   installation from that file manager.

This ZIP is the source project, not a prebuilt APK. An Android SDK/Gradle build environment
was not available in the current workspace to compile and verify the APK here.
