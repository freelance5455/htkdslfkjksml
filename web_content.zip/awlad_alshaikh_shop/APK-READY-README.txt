أولاد الشيخ للتسوق — حزمة جاهزة للتحويل إلى APK

هذه ليست APK جاهزة؛ إنها ملفات الموقع مرتبة لتدخلها في أداة تحويل الموقع إلى تطبيق Android (WebView).

ملف البداية:
index.html

مجلد التطبيق:
awlad_alshaikh_shop/

إعدادات مقترحة في أداة التحويل:
اسم التطبيق: أولاد الشيخ للتسوق
Package ID: com.awladalsheikh.shop
Version name: 1.0.0
Version code: 1
اتجاه العرض: Portrait
JavaScript: Enabled
DOM Storage / Local Storage: Enabled
Camera: Enabled (للتصوير من داخل صفحة إضافة المنتج)
File chooser / Gallery: Enabled
Internet permission: Enabled
HTTPS: Required

مهم:
- ارفع الموقع على استضافة HTTPS أولاً إذا كانت أداة التحويل تعمل برابط موقع.
- إذا كانت الأداة تقبل ملفات HTML محلية، اختر index.html كنقطة بداية وأضف المجلدات والملفات كلها كما هي.
- تسجيل الدخول ومزامنة Supabase يحتاجان الإنترنت.
- الحزمة تحتوي أيقونات Android/PWA بمقاسي 192 و512.
- لا ترفع مفاتيح سرية أو رموز جلسات الدخول ضمن التطبيق.

تم تحديث شعار الواجهة إلى شعار بقالة بمنتجات غذائية ومشروبات ومواد استهلاكية، وليس خضروات فقط.
