# Socle 3.6 — Gouvernance, recrutement et staff

## Fonctions ajoutées
- Décisions du conseil traitées automatiquement à l'avancement journalier ; chaque décision conserve son statut, sa date et son motif.
- Une demande de démission approuvée libère le poste, détache le manager du club et conserve l'événement dans l'historique de carrière.
- Marché de l'emploi pour les managers sans club : postes filtrés par réputation, candidatures, traitement par les clubs, proposition à accepter ou refuser et nomination effective.
- Une proposition d'emploi reçue devient une action prioritaire et bloque le bouton CONTINUER jusqu'à la réponse du manager.
- Profils du staff personnalisables : nom, profil descriptif et niveau de compétence ; validations des champs et sauvegarde dans la carrière.
- Le conseil garde les six domaines de confiance, objectifs et demandes déjà présents.

## Règles et limites explicites
- Le seuil d'accès à un poste dépend de la division ; les clubs de division supérieure demandent une réputation plus forte.
- La réponse d'une candidature est calculée à partir de la réputation et de l'ambition du poste. C'est une première simulation déterministe, à enrichir avec négociations salariales, entretiens et contrats.
- Les demandes financières ou d'installations sont approuvées en principe ; les montants, coûts et travaux détaillés seront raccordés au système économique complet dans une étape ultérieure.
- Les profils du staff sont éditables, mais le recrutement, le licenciement, les contrats et les effets tactiques/physiques de chaque compétence restent à développer.
- Les modèles 3D, les règles de dames, les calendriers et les huit moteurs de compétition n'ont pas été modifiés.
