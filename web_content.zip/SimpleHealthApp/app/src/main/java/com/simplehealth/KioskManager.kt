package com.simplehealth

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.Context

class KioskManager(
    private val activity: Activity
) {

    private val devicePolicyManager =
        activity.getSystemService(
            Context.DEVICE_POLICY_SERVICE
        ) as DevicePolicyManager

    fun isLockTaskPermitted(): Boolean {
        return devicePolicyManager
            .isLockTaskPermitted(
                activity.packageName
            )
    }

    fun startKiosk() {
        if (isLockTaskPermitted()) {
            activity.startLockTask()
        }
    }

    fun stopKiosk() {
        activity.stopLockTask()
    }
}