package com.simplehealth

import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

class VideoService : Service() {

    private var player: ExoPlayer? = null

    override fun onCreate() {
        super.onCreate()

        NotificationHelper.createChannel(this)

        val notification =
            NotificationHelper.createNotification(this)

        startForeground(
            NotificationHelper.NOTIFICATION_ID,
            notification
        )

        startPlayer()
    }

    private fun startPlayer() {

        player = ExoPlayer.Builder(this)
            .build()

        val videoUri =
            "asset:///videos/afternoon.mp4"

        val mediaItem =
            MediaItem.fromUri(videoUri)

        player?.setMediaItem(mediaItem)

        player?.prepare()

        player?.playWhenReady = true

        // ভিডিও শেষ হলে আবার শুরু হবে
        player?.repeatMode =
            ExoPlayer.REPEAT_MODE_ONE
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {

        player?.play()

        return START_STICKY
    }

    override fun onDestroy() {

        player?.release()
        player = null

        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}