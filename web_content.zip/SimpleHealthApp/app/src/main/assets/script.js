const video = document.getElementById("mainVideo");

function startVideo() {
    video.play().catch(() => {
        console.log("Video autoplay blocked.");
    });
}

window.addEventListener("load", () => {
    startVideo();
});

document.addEventListener(
    "visibilitychange",
    () => {

        if (!document.hidden) {
            startVideo();
        }

    }
);