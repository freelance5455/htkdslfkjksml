package ir.daftarman.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
