function powBI(a,b) {
  if (negative(b)) return str2bigInt("0",10);
  if (equalsInt(b,0)) return str2bigInt("1",10);
  var c = dup(b);
  if (equalsInt(c,1)) return a;
  var odd = modInt(c,2);
  halve_(c);
  var prod = powBI(a,c);
  prod = mult(prod,prod);
  if (odd) prod = mult(prod,a);
  return prod;
}

function by3s(str) {
  var n = str.length;
  rtn = str.substring(n-3,n);
  for (i=3; i<n; i+=3) {
    rtn = str.substring(n-i-3,n-i)+","+rtn;
  }
  return rtn;
}

function calculate() {
  var nStr = document.getElementById("N").value;
  var n = str2bigInt(nStr,10,100,100);
  if (negative(n) || equalsInt(n,0) || equalsInt(n,1)) {
    str = "N should be an integer greater than one!";
  } else {
    var k = addInt(n,-2);
    halve_(k);
    var kSq = mult(k,k);
    var r3 = str2bigInt("43252003274489856000",10,100,100);
    var r2 = str2bigInt("3674160",10,100,100);
    var fac24 = str2bigInt("620448401733239439360000", 10,100,100);
    var choose = str2bigInt("3246670537110000",10,100,100);
    var odd = modInt(n,2);
    var comb = powBI(fac24,k);
    comb = mult(comb,powBI(choose,kSq));
    if (odd) {
      comb = mult(comb,powBI(choose,k));
      comb = mult(comb,r3);
      //str = "<b>The "+nStr+"×"+nStr+"×"+nStr+" cube has "+parseInt(bigInt2str(comb,10)).toExponential(3)+" or </b>"+by3s(bigInt2str(comb,10))+" <b>possible combinations.</b><br><br>Mind you there are only aproximately 1,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000 atoms in the known universe";
      str = "<b>The "+nStr+"×"+nStr+"×"+nStr+" cube has "+convertToScientificNotation(bigInt2str(comb,10))+" or </b>"+by3s(bigInt2str(comb,10))+" <b>possible combinations.</b>"//<br><br>Mind you there are only aproximately 1,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000 atoms in the known universe";
    } else {
      comb = mult(comb,r2);
      //str = "<b>The "+nStr+"×"+nStr+"×"+nStr+" cube has "+parseInt(bigInt2str(comb,10)).toExponential(3)+" or </b>"+by3s(bigInt2str(comb,10))+" <b>possible combinations.</b><br><br>Mind you there are only aproximately 1,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000 atoms in the known universe";
      str = "<b>The "+nStr+"×"+nStr+"×"+nStr+" cube has "+convertToScientificNotation(bigInt2str(comb,10))+" or </b>"+by3s(bigInt2str(comb,10))+" <b>possible combinations.</b>"//<br><br>Mind you there are only aproximately 1,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000 atoms in the known universe";
    }
  }
  document.getElementById("comb").innerHTML=str;
  removeCommasAndCopyToClipboard(bigInt2str(comb,10))
}

////////////////////////////////////////////////////////////////////////////////////////
// Big Integer Library v. 5.1
// Created 2000, last modified 2007
// Leemon Baird
// www.leemon.com
//
//globals
bpe=0;         //bits stored per array element
mask=0;        //AND this with an array element to chop it down to bpe bits
radix=mask+1;  //equals 2^bpe.  A single 1 bit to the left of the last bit of mask.

//the digits for converting to different bases
digitsStr='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_=!@#$%^&*()[]{}|;:,.<>/?`~ \\\'\"+-';

//initialize the global variables
for (bpe=0; (1<<(bpe+1)) > (1<<bpe); bpe++);  //bpe=number of bits in the mantissa on this platform
bpe>>=1;                   //bpe=number of bits in one element of the array representing the bigInt
mask=(1<<bpe)-1;           //AND the mask with an integer to get its bpe least significant bits
radix=mask+1;              //2^bpe.  a single 1 bit to the left of the first bit of mask
one=int2bigInt(1,1,1);     //constant used in powMod_()

//the following global variables are scratchpad memory to 
//reduce dynamic memory allocation in the inner loop
t=new Array(0);
ss=t;       //used in mult_()
s0=t;       //used in multMod_(), squareMod_() 
s1=t;       //used in powMod_(), multMod_(), squareMod_() 
s2=t;       //used in powMod_(), multMod_()
s3=t;       //used in powMod_()
s4=t; s5=t; //used in mod_()
s6=t;       //used in bigInt2str()
s7=t;       //used in powMod_()
T=t;        //used in GCD_()
sa=t;       //used in mont_()
mr_x1=t; mr_r=t; mr_a=t;                                      //used in millerRabin()
eg_v=t; eg_u=t; eg_A=t; eg_B=t; eg_C=t; eg_D=t;               //used in eGCD_(), inverseMod_()
md_q1=t; md_q2=t; md_q3=t; md_r=t; md_r1=t; md_r2=t; md_tt=t; //used in mod_()

primes=t; pows=t; s_i=t; s_i2=t; s_R=t; s_rm=t; s_q=t; s_n1=t; 
  s_a=t; s_r2=t; s_n=t; s_b=t; s_d=t; s_x1=t; s_x2=t, s_aa=t; //used in randTruePrime_()

////////////////////////////////////////////////////////////////////////////////////////


//return a copy of x with at least n elements, adding leading zeros if needed
function expand(x,n) {
  var ans=int2bigInt(0,(x.length>n ? x.length : n)*bpe,0);
  copy_(ans,x);
  return ans;
}

//return (x+n) where x is a bigInt and n is an integer.
function addInt(x,n) {
  var ans=expand(x,x.length+1);
  addInt_(ans,n);
  return trim(ans,1);
}

//return x*y for bigInts x and y. This is faster when y<x.
function mult(x,y) {
  var ans=expand(x,x.length+y.length);
  mult_(ans,y);
  return trim(ans,1);
}

//is bigInt x negative?
function negative(x) {
  return ((x[x.length-1]>>(bpe-1))&1);
}

//return x mod n for bigInt x and integer n.
function modInt(x,n) {
  var i,c=0;
  for (i=x.length-1; i>=0; i--)
    c=(c*radix+x[i])%n;
  return c;
}

//convert the integer t into a bigInt with at least the given number of bits.
//the returned array stores the bigInt in bpe-bit chunks, little endian (buff[0] is least significant word)
//Pad the array with leading zeros so that it has at least minSize elements.
//There will always be at least one leading 0 element.
function int2bigInt(t,bits,minSize) {   
  var i,k;
  k=Math.ceil(bits/bpe)+1;
  k=minSize>k ? minSize : k;
  buff=new Array(k);
  copyInt_(buff,t);
  return buff;
}

//return the bigInt given a string representation in a given base.  
//Pad the array with leading zeros so that it has at least minSize elements.
//If base=-1, then it reads in a space-separated list of array elements in decimal.
//The array will always have at least one leading zero, unless base=-1.
function str2bigInt(s,base,minSize) {
  var d, i, j, x, y, kk;
  var k=s.length;
  if (base==-1) { //comma-separated list of array elements in decimal
    x=new Array(0);
    for (;;) {
      y=new Array(x.length+1);
      for (i=0;i<x.length;i++)
        y[i+1]=x[i];
      y[0]=parseInt(s,10);
      x=y;
      d=s.indexOf(',',0);
      if (d<1) 
        break;
      s=s.substring(d+1);
      if (s.length==0)
        break;
    }
    if (x.length<minSize) {
      y=new Array(minSize);
      copy_(y,x);
      return y;
    }
    return x;
  }

  x=int2bigInt(0,base*k,0);
  for (i=0;i<k;i++) {
    d=digitsStr.indexOf(s.substring(i,i+1),0);
    if (base<=36 && d>=36)  //convert lowercase to uppercase if base<=36
      d-=26;
    if (d<base && d>=0) {   //ignore illegal characters
      multInt_(x,base);
      addInt_(x,d);
    }
  }

  for (k=x.length;k>0 && !x[k-1];k--); //strip off leading zeros
  k=minSize>k+1 ? minSize : k+1;
  y=new Array(k);
  kk=k<x.length ? k : x.length;
  for (i=0;i<kk;i++)
    y[i]=x[i];
  for (;i<k;i++)
    y[i]=0;
  return y;
}

//is bigint x equal to integer y?
//y must have less than bpe bits
function equalsInt(x,y) {
  var i;
  if (x[0]!=y)
    return 0;
  for (i=1;i<x.length;i++)
    if (x[i])
      return 0;
  return 1;
}


//is the bigInt x equal to zero?
function isZero(x) {
  var i;
  for (i=0;i<x.length;i++)
    if (x[i])
      return 0;
  return 1;
}

//convert a bigInt into a string in a given base, from base 2 up to base 95.
//Base -1 prints the contents of the array representing the number.
function bigInt2str(x,base) {
  var i,t,s="";

  if (s6.length!=x.length) 
    s6=dup(x);
  else
    copy_(s6,x);

  if (base==-1) { //return the list of array contents
    for (i=x.length-1;i>0;i--)
      s+=x[i]+',';
    s+=x[0];
  }
  else { //return it in the given base
    while (!isZero(s6)) {
      t=divInt_(s6,base);  //t=s6 % base; s6=floor(s6/base);
      s=digitsStr.substring(t,t+1)+s;
    }
  }
  if (s.length==0)
    s="0";
  return s;
}

//returns a duplicate of bigInt x
function dup(x) {
  var i;
  buff=new Array(x.length);
  copy_(buff,x);
  return buff;
}

//do x=y on bigInts x and y.  x must be an array at least as big as y (not counting the leading zeros in y).
function copy_(x,y) {
  var i;
  var k=x.length<y.length ? x.length : y.length;
  for (i=0;i<k;i++)
    x[i]=y[i];
  for (i=k;i<x.length;i++)
    x[i]=0;
}

//do x=y on bigInt x and integer y.  
function copyInt_(x,n) {
  var i,c;
  for (c=n,i=0;i<x.length;i++) {
    x[i]=c & mask;
    c>>=bpe;
  }
}

//do x=x+n where x is a bigInt and n is an integer.
//x must be large enough to hold the result.
function addInt_(x,n) {
  var i,k,c,b;
  x[0]+=n;
  k=x.length;
  c=0;
  for (i=0;i<k;i++) {
    c+=x[i];
    b=0;
    if (c<0) {
      b=-(c>>bpe);
      c+=b*radix;
    }
    x[i]=c & mask;
    c=(c>>bpe)-b;
    if (!c) return; //stop carrying as soon as the carry_ is zero
  }
}

//do x=floor(|x|/2)*sgn(x) for bigInt x in 2's complement
function halve_(x) {
  var i;
  for (i=0;i<x.length-1;i++) {
    x[i]=mask & ((x[i+1]<<(bpe-1)) | (x[i]>>1));
  }
  x[i]=(x[i]>>1) | (x[i] & (radix>>1));  //most significant bit stays the same
}
//do x=x*n where x is a bigInt and n is an integer.
//x must be large enough to hold the result.
function multInt_(x,n) {
  var i,k,c,b;
  if (!n)
    return;
  k=x.length;
  c=0;
  for (i=0;i<k;i++) {
    c+=x[i]*n;
    b=0;
    if (c<0) {
      b=-(c>>bpe);
      c+=b*radix;
    }
    x[i]=c & mask;
    c=(c>>bpe)-b;
  }
}

//do x=floor(x/n) for bigInt x and integer n, and return the remainder
function divInt_(x,n) {
  var i,r=0,s;
  for (i=x.length-1;i>=0;i--) {
    s=r*radix+x[i];
    x[i]=Math.floor(s/n);
    r=s%n;
  }
  return r;
}

//do the linear combination x=a*x+b*y for bigInts x and y, and integers a and b.
//x must be large enough to hold the answer.
function linComb_(x,y,a,b) {
  var i,c,k,kk;
  k=x.length<y.length ? x.length : y.length;
  kk=x.length;
  for (c=0,i=0;i<k;i++) {
    c+=a*x[i]+b*y[i];
    x[i]=c & mask;
    c>>=bpe;
  }
  for (i=k;i<kk;i++) {
    c+=a*x[i];
    x[i]=c & mask;
    c>>=bpe;
  }
}

//do the linear combination x=a*x+b*(y<<(ys*bpe)) for bigInts x and y, and integers a, b and ys.
//x must be large enough to hold the answer.
function linCombShift_(x,y,b,ys) {
  var i,c,k,kk;
  k=x.length<ys+y.length ? x.length : ys+y.length;
  kk=x.length;
  for (c=0,i=ys;i<k;i++) {
    c+=x[i]+b*y[i-ys];
    x[i]=c & mask;
    c>>=bpe;
  }
  for (i=k;c && i<kk;i++) {
    c+=x[i];
    x[i]=c & mask;
    c>>=bpe;
  }
}


//do x=x*y for bigInts x and y.  This is faster when y<x.
function mult_(x,y) {
  var i;
  if (ss.length!=2*x.length)
    ss=new Array(2*x.length);
  copyInt_(ss,0);
  for (i=0;i<y.length;i++)
    if (y[i])
      linCombShift_(ss,x,y[i],i);   //ss=1*ss+y[i]*(x<<(i*bpe))
  copy_(x,ss);
}

//return x with exactly k leading zero elements
function trim(x,k) {
  var i,y;
  for (i=x.length; i>0 && !x[i-1]; i--);
  y=new Array(i+k);
  copy_(y,x);
  return y;
}

//scientific notation
/* function toScientificNotation(number) {
  return number.toExponential();
}

const largeNumber = 1234567890123;
const scientificNotation = toScientificNotation(largeNumber);

console.log(scientificNotation); */

//scientific notation


function removeCommasAndCopyToClipboard(inputString) {
    // 1. Remove all commas from the string
    let stringWithoutCommas = inputString.replace(/,/g, "");
    //let stringWithoutCommas = bigInt2str(comb,10)

    // 2. Copy the modified string to the clipboard var
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(stringWithoutCommas)
            .then(() => {
                console.log("String (without commas) copied to clipboard!");
            })
            .catch(err => {
                console.log("Failed to copy text to clipboard:", err);
            });
    } else {
        console.log("Clipboard API not available or permission denied.");
        // Fallback for older browsers or environments without Clipboard API support
        // (e.g., using a temporary textarea and document.execCommand('copy'))
    }
}

// Example usage:
//let myText = "Hello, world, this, is, a, test.";
//removeCommasAndCopyToClipboard(myText);


function convertToScientificNotation(largeNumberString) {
  // Remove commas from the string
  const numberWithoutCommas = largeNumberString.replace(/,/g, '');

  // Check if the string is a valid number after comma removal
  if (!/^\d+$/.test(numberWithoutCommas)) {
    throw new Error("Input string contains non-numeric characters after comma removal.");
  }

  // Get the length of the numeral string
  const numeralLength = numberWithoutCommas.length;

  // Handle cases where the number is zero or empty after comma removal
  if (numeralLength === 0 || numberWithoutCommas === '0') {
    return '0';
  }

  // Determine the exponent for scientific notation
  // The exponent is (length of numerals - 1)
  const exponent = numeralLength - 1;

  // Extract the first digit and the remaining digits for the mantissa
  const firstDigit = numberWithoutCommas[0];
  const remainingDigits = numberWithoutCommas.substring(1);

  // Construct the mantissa. If there are remaining digits, add a decimal point.
  const mantissa = remainingDigits.length > 0 ? `${firstDigit}.${remainingDigits.slice(0, 2)}` : firstDigit;
  
  // Return the scientific notation string
  return `${mantissa}e+${exponent}`;
}

/* Example usage:
const largeNumber = "1,234,567,890,123,456,789";
const scientificNotation = convertToScientificNotation(largeNumber);
console.log(scientificNotation); // Output: 1.234567890123456789e+18

const anotherLargeNumber = "9,876";
const anotherScientificNotation = convertToScientificNotation(anotherLargeNumber);
console.log(anotherScientificNotation); // Output: 9.876e+3

const singleDigitNumber = "7";
const singleDigitScientificNotation = convertToScientificNotation(singleDigitNumber);
console.log(singleDigitScientificNotation); // Output: 7e+0
*/