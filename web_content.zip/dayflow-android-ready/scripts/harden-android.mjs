import fs from 'node:fs';
import path from 'node:path';

const manifest = path.resolve('android/app/src/main/AndroidManifest.xml');
if (!fs.existsSync(manifest)) {
  console.error('Android project not found. Run: npx cap add android');
  process.exit(1);
}
let xml = fs.readFileSync(manifest, 'utf8');
xml = xml.replace(/\s*<uses-permission[^>]+android\.permission\.(?:INTERNET|ACCESS_NETWORK_STATE)[^>]*\/>/g, '');
if (!xml.includes('xmlns:tools=')) xml = xml.replace('xmlns:android=', 'xmlns:tools="http://schemas.android.com/tools" xmlns:android=');
if (!xml.includes('android.permission.USE_BIOMETRIC')) {
  xml = xml.replace('<application', '    <uses-permission android:name="android.permission.USE_BIOMETRIC" />\n    <application');
}
// Manifest-merger removal markers prevent Capacitor/library manifests from re-adding network permissions.
if (!xml.includes('tools:node="remove"')) {
  xml = xml.replace('<application', '    <uses-permission android:name="android.permission.INTERNET" tools:node="remove" />\n    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" tools:node="remove" />\n    <application');
}
xml = xml.replace(/<application\b([^>]*)>/, (full, attrs) => {
  let next = attrs;
  if (!/android:allowBackup=/.test(next)) next += ' android:allowBackup="false"';
  if (!/android:usesCleartextTraffic=/.test(next)) next += ' android:usesCleartextTraffic="false"';
  return `<application${next}>`;
});
fs.writeFileSync(manifest, xml);

const javaRoot = path.resolve('android/app/src/main/java');
function walk(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap(entry => {
    const full = path.join(dir, entry.name);
    return entry.isDirectory() ? walk(full) : /MainActivity\.(java|kt)$/.test(entry.name) ? [full] : [];
  });
}
const activities = walk(javaRoot);
if (!activities.length) console.warn('MainActivity not found; add FLAG_SECURE manually if your project uses a non-standard activity path.');
for (const file of activities) {
  let source = fs.readFileSync(file, 'utf8');
  if (source.includes('FLAG_SECURE')) continue;
  if (file.endsWith('.java')) {
    if (!source.includes('import android.view.WindowManager;')) source = source.replace(/(package [^;]+;\s*)/, '$1\nimport android.view.WindowManager;\n');
    source = source.replace(/(super\.onCreate\(savedInstanceState\);)/, '$1\n        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);');
  } else {
    if (!source.includes('import android.view.WindowManager')) source = source.replace(/(package [^\n]+\n)/, '$1\nimport android.view.WindowManager\n');
    source = source.replace(/(super\.onCreate\(savedInstanceState\))/,'$1\n        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)');
  }
  fs.writeFileSync(file, source);
}
console.log('Android hardening applied: network permissions explicitly removed, backup disabled, cleartext traffic disabled, biometric permission added, screenshots blocked.');
