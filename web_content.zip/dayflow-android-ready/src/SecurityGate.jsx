import { useEffect, useState } from 'react';
import { App as CapacitorApp } from '@capacitor/app';
import { secureStore, hashPin } from './secureStore';
import './SecurityGate.css';

export default function SecurityGate({ children }) {
  const [ready, setReady] = useState(false);
  const [hasPin, setHasPin] = useState(false);
  const [locked, setLocked] = useState(true);
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [biometricAvailable, setBiometricAvailable] = useState(false);
  const [biometricEnabled, setBiometricEnabled] = useState(false);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [storageFailed, setStorageFailed] = useState(false);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const verifier = await secureStore.getPinVerifier();
        const available = await secureStore.biometricAvailable();
        const enabled = await secureStore.hasBiometric();
        if (!active) return;
        setHasPin(Boolean(verifier));
        setBiometricAvailable(available);
        setBiometricEnabled(enabled && available);
      } catch {
        if (active) { setStorageFailed(true); setError('Secure storage could not be opened. Do not reset the PIN or clear app data; recover from an encrypted backup or contact support.'); }
      } finally { if (active) setReady(true); }
    })();
    let listener;
    let backgroundTimer;
    if (secureStore.isNative()) {
      CapacitorApp.addListener('appStateChange', ({ isActive }) => {
        if (!isActive) {
          if (backgroundTimer) window.clearTimeout(backgroundTimer);
          // Short grace period lets Android's system file picker return without destroying an import flow.
          backgroundTimer = window.setTimeout(() => { setLocked(true); setPin(''); setConfirmPin(''); }, 15000);
        } else if (backgroundTimer) {
          window.clearTimeout(backgroundTimer); backgroundTimer = undefined;
        }
      }).then(handle => { listener = handle; });
    }
    return () => { active = false; if (backgroundTimer) window.clearTimeout(backgroundTimer); listener?.remove(); };
  }, []);

  async function createPin(event) {
    event.preventDefault(); setError('');
    if (!/^\d{8,12}$/.test(pin)) return setError('Choose a stronger PIN containing 8–12 digits.');
    if (pin !== confirmPin) return setError('The two PINs do not match.');
    setBusy(true);
    try {
      const verifier = await hashPin(pin);
      await secureStore.setPinVerifier(verifier);
      setHasPin(true); setLocked(false); setPin(''); setConfirmPin('');
    } catch { setError('Could not save your PIN securely.'); }
    finally { setBusy(false); }
  }

  async function unlock(event) {
    event.preventDefault(); setError(''); setBusy(true);
    try {
      const until = await secureStore.getLockoutUntil();
      if (Date.now() < until) throw new Error(`Too many attempts. Try again in ${Math.ceil((until - Date.now()) / 1000)} seconds.`);
      const saved = await secureStore.getPinVerifier();
      const [salt, expected] = (saved || '').split(':');
      const candidate = await hashPin(pin, salt);
      if (!saved || candidate.split(':')[1] !== expected) {
        const attempts = (await secureStore.getFailedAttempts()) + 1;
        await secureStore.setFailedAttempts(attempts);
        if (attempts % 5 === 0) {
          const waitMs = Math.min(60 * 60 * 1000, 30 * 1000 * (2 ** Math.max(0, Math.floor(attempts / 5) - 1)));
          await secureStore.setLockoutUntil(Date.now() + waitMs);
          throw new Error(`Too many attempts. Dayflow is locked for ${Math.ceil(waitMs / 1000)} seconds.`);
        }
        throw new Error(`Incorrect PIN. ${5 - (attempts % 5)} attempts until a temporary lockout.`);
      }
      await secureStore.setFailedAttempts(0); await secureStore.setLockoutUntil(0);
      setLocked(false); setPin('');
    } catch (e) { setError(e.message?.startsWith('Incorrect PIN.') || e.message?.startsWith('Too many attempts.') ? e.message : 'Unable to verify PIN.'); }
    finally { setBusy(false); }
  }

  async function unlockWithBiometric() {
    setError(''); setBusy(true);
    try { await secureStore.authenticateBiometric(); await secureStore.setFailedAttempts(0); await secureStore.setLockoutUntil(0); setLocked(false); }
    catch { setError('Biometric verification was cancelled or unsuccessful. Use your PIN.'); }
    finally { setBusy(false); }
  }

  async function toggleBiometric() {
    setError(''); setBusy(true);
    try {
      if (biometricEnabled) { await secureStore.setBiometric(false); setBiometricEnabled(false); setError('Biometric unlock disabled. PIN protection remains active.'); }
      else { await secureStore.authenticateBiometric(); await secureStore.setBiometric(true); setBiometricEnabled(true); setError('Biometric unlock enabled.'); }
    } catch { setError('Biometric setting could not be changed. Your PIN remains active.'); }
    finally { setBusy(false); }
  }

  if (!ready) return <div className="security-screen"><div className="security-panel"><div className="security-mark">D</div><h1>Dayflow</h1><p>Opening protected storage…</p></div></div>;
  if (storageFailed) return <div className="security-screen"><div className="security-panel"><div className="security-mark">D</div><h1>Secure storage unavailable</h1><p className="security-error">{error}</p></div></div>;
  if (!hasPin || locked) return <div className="security-screen"><div className="security-panel">
    <div className="security-mark">D</div>
    <p className="security-kicker">PRIVATE · OFFLINE · ENCRYPTED</p>
    <h1>{hasPin ? 'Welcome back' : 'Protect your Dayflow'}</h1>
    <p>{hasPin ? 'Enter your PIN to unlock your private planner.' : 'Create an 8–12 digit PIN. You will need it whenever Dayflow opens.'}</p>
    <form onSubmit={hasPin ? unlock : createPin} className="security-form">
      <label>{hasPin ? 'Your PIN' : 'Create PIN'}<input type="password" inputMode="numeric" autoComplete="off" pattern="[0-9]*" maxLength={12} minLength={8} value={pin} onChange={e => setPin(e.target.value.replace(/\D/g, '').slice(0,12))} placeholder="8–12 digits" required /></label>
      {!hasPin && <label>Confirm PIN<input type="password" inputMode="numeric" autoComplete="off" maxLength={12} value={confirmPin} onChange={e => setConfirmPin(e.target.value.replace(/\D/g, '').slice(0,12))} placeholder="Enter PIN again" required /></label>}
      {error && <p className="security-error" role="alert">{error}</p>}
      <button className="security-primary" disabled={busy}>{busy ? 'Please wait…' : hasPin ? 'Unlock Dayflow' : 'Create secure PIN'}</button>
    </form>
    {hasPin && biometricAvailable && biometricEnabled && <button className="security-secondary" onClick={unlockWithBiometric} disabled={busy}>Use fingerprint / face unlock</button>}
    {!hasPin && biometricAvailable && <p className="security-hint">You can enable fingerprint or face unlock in Settings after setup.</p>}
    <p className="security-hint">Your PIN verifier and app data are stored using Android Keystore-backed encrypted storage. Keep your PIN safe; there is no online PIN recovery.</p>
  </div></div>;
  return <>{children}{error && <div className="security-toast" role="status">{error}</div>}{biometricAvailable && <button className="biometric-enable" onClick={toggleBiometric} disabled={busy}>{biometricEnabled ? 'Disable biometric unlock' : 'Enable biometric unlock'}</button>}</>;
}
