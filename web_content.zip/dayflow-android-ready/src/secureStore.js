import { Capacitor } from '@capacitor/core';
import { NativeBiometric } from '@capgo/capacitor-native-biometric';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

const DATA_KEY = 'dayflow.encrypted.data.v2';
const PIN_KEY = 'dayflow.pin.verifier.v1';
const BIO_KEY = 'dayflow.biometric.enabled.v1';
const ATTEMPTS_KEY = 'dayflow.pin.failed-attempts.v1';
const LOCKOUT_KEY = 'dayflow.pin.lockout-until.v1';
const native = () => Capacitor.isNativePlatform();

// NativeBiometric's setData/getData use Android Keystore-backed encrypted storage.
// Browser storage is only a development preview and is NOT equivalent security.
async function getItem(key) {
  if (native()) {
    const result = await NativeBiometric.getData({ key });
    return result?.value ?? null;
  }
  return localStorage.getItem(key);
}
async function setItem(key, value) {
  if (native()) return NativeBiometric.setData({ key, value: String(value) });
  localStorage.setItem(key, String(value));
}
async function removeItem(key) {
  if (native()) return NativeBiometric.deleteData({ key });
  localStorage.removeItem(key);
}

export const secureStore = {
  async getData() {
    const raw = await getItem(DATA_KEY);
    if (raw) return JSON.parse(raw);
    // One-time migration from the previous Dayflow Android build's plaintext WebView storage.
    if (native()) {
      const legacy = localStorage.getItem('dayflow-v1');
      if (legacy) {
        const parsed = JSON.parse(legacy);
        await setItem(DATA_KEY, JSON.stringify(parsed));
        localStorage.removeItem('dayflow-v1');
        return parsed;
      }
    }
    return null;
  },
  async setData(data) {
    await setItem(DATA_KEY, JSON.stringify(data));
  },
  async clearData() {
    await removeItem(DATA_KEY);
  },
  async exportBackupFile(filename, contents) {
    if (!native()) {
      const blob = new Blob([contents], { type: 'application/octet-stream' });
      const url = URL.createObjectURL(blob); const a = document.createElement('a');
      a.href = url; a.download = filename; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
      return;
    }
    const saved = await Filesystem.writeFile({ path: filename, data: contents, directory: Directory.Documents, encoding: Encoding.UTF8, recursive: true });
    await Share.share({ title: 'Dayflow encrypted backup', text: 'Encrypted Dayflow backup. Keep your password separately.', url: saved.uri, dialogTitle: 'Save encrypted Dayflow backup' });
  },
  async getPinVerifier() { return getItem(PIN_KEY); },
  async setPinVerifier(value) { return setItem(PIN_KEY, value); },
  async hasBiometric() { return (await getItem(BIO_KEY)) === 'true'; },
  async setBiometric(enabled) { return setItem(BIO_KEY, enabled ? 'true' : 'false'); },
  async getFailedAttempts() { return Number(await getItem(ATTEMPTS_KEY) || 0); },
  async setFailedAttempts(value) { return setItem(ATTEMPTS_KEY, String(value)); },
  async getLockoutUntil() { return Number(await getItem(LOCKOUT_KEY) || 0); },
  async setLockoutUntil(value) { return setItem(LOCKOUT_KEY, String(value)); },
  async biometricAvailable() {
    if (!native()) return false;
    try { return (await NativeBiometric.isAvailable()).isAvailable === true; }
    catch { return false; }
  },
  async authenticateBiometric() {
    if (!native()) throw new Error('Biometric authentication is only available in the Android app.');
    await NativeBiometric.verifyIdentity({ reason: 'Unlock your private Dayflow data' });
  },
  isNative: native,
};

const toBase64 = bytes => { const array = new Uint8Array(bytes); let binary = ''; for (let i = 0; i < array.length; i += 0x8000) binary += String.fromCharCode(...array.subarray(i, i + 0x8000)); return btoa(binary); };
const fromBase64 = value => Uint8Array.from(atob(value), c => c.charCodeAt(0));

async function deriveBackupKey(password, salt) {
  const material = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations: 310000, hash: 'SHA-256' },
    material,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt'],
  );
}

export async function makeEncryptedBackup(data, password) {
  if (password.length < 12) throw new Error('Use a backup password of at least 12 characters.');
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await deriveBackupKey(password, salt);
  const plaintext = new TextEncoder().encode(JSON.stringify(data));
  const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, plaintext);
  return JSON.stringify({
    format: 'DAYFLOW-ENCRYPTED-BACKUP',
    version: 1,
    kdf: 'PBKDF2-SHA256',
    iterations: 310000,
    cipher: 'AES-256-GCM',
    salt: toBase64(salt),
    iv: toBase64(iv),
    ciphertext: toBase64(ciphertext),
  });
}

export async function readEncryptedBackup(raw, password) {
  const file = JSON.parse(raw);
  if (file.format !== 'DAYFLOW-ENCRYPTED-BACKUP' || file.version !== 1 || file.cipher !== 'AES-256-GCM') {
    throw new Error('This is not a supported encrypted Dayflow backup.');
  }
  const key = await deriveBackupKey(password, fromBase64(file.salt));
  const clear = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: fromBase64(file.iv) }, key, fromBase64(file.ciphertext));
  const data = JSON.parse(new TextDecoder().decode(clear));
  if (!Array.isArray(data.tasks) || !Array.isArray(data.notes)) throw new Error('Backup contents are invalid.');
  return data;
}

export async function hashPin(pin, saltHex) {
  const salt = saltHex ? Uint8Array.from(saltHex.match(/.{2}/g), x => parseInt(x, 16)) : crypto.getRandomValues(new Uint8Array(16));
  const material = await crypto.subtle.importKey('raw', new TextEncoder().encode(pin), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: 310000, hash: 'SHA-256' }, material, 256);
  const hex = [...new Uint8Array(bits)].map(x => x.toString(16).padStart(2, '0')).join('');
  const saltString = [...salt].map(x => x.toString(16).padStart(2, '0')).join('');
  return `${saltString}:${hex}`;
}
