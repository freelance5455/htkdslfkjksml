# Dayflow Android — Privacy Upgrade

Dayflow is an offline-first personal planner built with React and Capacitor 7.

## Privacy and security implemented

- **Android encrypted storage:** planner JSON and PIN verifier are stored through `@capgo/capacitor-native-biometric` `setData/getData`. On Android this plugin uses Android Keystore-backed encrypted storage. The app does not use `localStorage` for ongoing Android data storage.
- **PIN gate:** first launch requires a 8–12 digit PIN. The app stores a PBKDF2-HMAC-SHA-256 verifier (310,000 iterations), with progressive temporary lockouts after repeated wrong attempts with a random salt, not the PIN itself.
- **Biometric unlock:** optional fingerprint/face/device biometric prompt, enabled from the floating button after the first unlock. PIN remains available as fallback.
- **Auto-lock:** locks after the app remains inactive for 15 seconds; it locks again when the app is reopened.
- **Encrypted backups:** `.dayflow` backup files are written to Android Documents and opened in the native share sheet (browser preview downloads a file). They use AES-256-GCM with a random salt/IV and PBKDF2-SHA-256 (310,000 iterations). Backup password must be at least 12 characters. The password is never stored by Dayflow.
- **Offline-only Android build:** Android INTERNET and ACCESS_NETWORK_STATE permissions are explicitly removed using Android manifest-merger directives; cleartext traffic is disabled. Content Security Policy blocks remote connections. Google Fonts import was removed.
- **Reduced OS exposure:** Android backup is disabled and `FLAG_SECURE` blocks screenshots/screen recording and recent-app thumbnails.
- **Legacy migration:** if the previous Dayflow build's `dayflow-v1` WebView localStorage data exists, it is migrated once into encrypted Android storage and the old plaintext key is removed.

## Important limitations

- This is a security-focused implementation, **not a third-party security audit**. Build and test it on the target phone before trusting it with sensitive information.
- Biometric gating is an app access control, while data-at-rest encryption is provided separately by Android Keystore-backed storage. A rooted/compromised device, malicious accessibility service, OS exploit, or someone who knows your PIN may still expose data.
- There is no cloud recovery and no PIN reset flow. If you forget the PIN, there is no server to reset it. Keep the encrypted backup password safe; losing it makes that backup unrecoverable.
- Android Keystore data is device-bound. Reinstalling the app or clearing app data may permanently delete the encryption key and stored planner data. `allowBackup=false` intentionally prevents unusable encrypted data from being copied to another device.
- The browser preview uses localStorage as a development fallback and does **not** provide Android Keystore protection. Use the native Android build for the stated privacy guarantees.
- App updates that change native plugins or manifest settings require a new APK build. The APK has not been compiled or independently penetration-tested in this environment.

## Build on Windows / Android Studio

1. Install Node.js LTS and Android Studio with Android SDK.
2. Extract this project and open a terminal in the project folder.
3. Install packages:

   ```bash
   npm install
   ```

4. Create the Android native project (first time only):

   ```bash
   npx cap add android
   ```

5. Build and apply Android hardening:

   ```bash
   npm run android:release
   ```

   This runs the Vite production build, syncs Capacitor plugins/assets, removes internet permissions, disables Android backup and cleartext traffic, adds biometric permission, and enables Android `FLAG_SECURE`.

6. Open Android Studio:

   ```bash
   npx cap open android
   ```

7. In Android Studio choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
8. Install the APK on your phone. Create a PIN, then optionally enable biometric unlock.

For later updates, run `npm run android:release` again before rebuilding the APK.

## Backup instructions

In Dayflow → Settings → **Create encrypted backup**, choose a strong password of at least 12 characters and store it separately from the phone. To restore, choose **Restore encrypted backup** and enter the same password. Dayflow cannot recover a forgotten backup password.

## Dependencies

- React 19
- Capacitor 7
- `@capgo/capacitor-native-biometric` v7 (Android Keystore encrypted storage + native biometric prompt)
- `@capacitor/app`, `@capacitor/filesystem`, and `@capacitor/share` v7 (app lifecycle, local backup export and share sheet)
