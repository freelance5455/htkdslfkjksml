RAFA Android Project

This is an Android Studio project wrapping the offline RAFA inventory/sales HTML app.
Open the project folder in Android Studio and build APK from Build > Build APK(s).
The web app is bundled locally in app/src/main/assets/index.html and uses localStorage for data.
