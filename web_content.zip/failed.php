<?php 
// failed.php
$orderId = $_GET['orderid'] ?? 'N/A';

// Set Indian Time Zone
date_default_timezone_set('Asia/Kolkata');
$currentDate = date('d M, Y h:i A');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Payment Failed</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --bg-primary: #05051E;
            --bg-secondary: #141432;
            --card-bg: #151530;
            --text-primary: #FFFFFF;
            --text-secondary: #A0A0B8;
            --accent-cyan: #00E0FF;
            --accent-pink: #FF3D71;
            --btn-green: #4CAF50;
            --border-color: #2a2a4a;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        .failed-card {
            width: 100%;
            max-width: 420px;
            background: var(--bg-secondary);
            border-radius: 24px;
            padding: 32px 24px 28px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
            text-align: center;
            position: relative;
            border: 1px solid var(--border-color);
            animation: fadeInUp 0.5s cubic-bezier(0.16, 1, 0.3, 1);
            overflow: hidden;
        }

        .failed-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80%;
            height: 4px;
            background: linear-gradient(90deg, var(--accent-pink), #ff6b8a);
            border-radius: 0 0 10px 10px;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .icon-wrapper {
            width: 96px;
            height: 96px;
            margin: 8px auto 18px;
            background: rgba(255, 61, 113, 0.12);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid rgba(255, 61, 113, 0.4);
            position: relative;
            animation: popIn 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            box-shadow: 0 0 30px rgba(255, 61, 113, 0.2);
        }

        @keyframes popIn {
            0% { transform: scale(0); opacity: 0; }
            100% { transform: scale(1); opacity: 1; }
        }

        .icon-wrapper i {
            font-size: 46px;
            color: var(--accent-pink);
        }

        .icon-wrapper .pulse {
            position: absolute;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            border: 2px solid rgba(255, 61, 113, 0.35);
            animation: pulseRing 1.8s ease-out infinite;
        }

        @keyframes pulseRing {
            0% { transform: scale(1); opacity: 1; }
            100% { transform: scale(1.4); opacity: 0; }
        }

        .failed-title {
            font-size: 24px;
            font-weight: 700;
            color: var(--text-primary);
            letter-spacing: -0.3px;
            margin-bottom: 8px;
        }

        .failed-sub {
            font-size: 14px;
            color: var(--text-secondary);
            line-height: 1.7;
            margin-bottom: 22px;
            padding: 0 4px;
        }
        .failed-sub i {
            color: var(--accent-pink);
            margin-right: 4px;
        }

        .details-grid {
            width: 100%;
            background: var(--card-bg);
            border-radius: 14px;
            padding: 14px 18px;
            border: 1px solid var(--border-color);
            margin-bottom: 20px;
            text-align: left;
        }
        .d-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 9px 0;
            border-bottom: 1px solid var(--border-color);
            gap: 8px;
        }
        .d-row:last-child {
            border-bottom: none;
            padding-bottom: 0;
        }
        .d-label {
            font-size: 13px;
            font-weight: 500;
            color: var(--text-secondary);
            white-space: nowrap;
        }
        .d-label i {
            width: 18px;
            margin-right: 6px;
            color: var(--accent-cyan);
        }
        .d-val {
            font-size: 13px;
            font-weight: 600;
            color: var(--text-primary);
            text-align: right;
            word-break: break-all;
        }
        .d-val .order-id {
            font-family: 'Courier New', monospace;
            color: var(--accent-cyan);
            font-size: 12px;
            background: rgba(0, 224, 255, 0.1);
            padding: 3px 10px;
            border-radius: 6px;
            border: 1px solid rgba(0, 224, 255, 0.25);
            display: inline-block;
            max-width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .status-badge {
            background: rgba(255, 61, 113, 0.15);
            color: var(--accent-pink);
            padding: 3px 14px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
            border: 1px solid rgba(255, 61, 113, 0.4);
            display: inline-block;
        }
        .status-badge i {
            margin-right: 4px;
            font-size: 10px;
        }

        .btn-action {
            width: 100%;
            padding: 16px;
            border-radius: 50px;
            border: none;
            background: linear-gradient(90deg, var(--accent-cyan), #0099CC);
            color: #000;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                        box-shadow 0.25s ease;
            box-shadow: 0 8px 25px rgba(0, 224, 255, 0.35);
            text-transform: uppercase;
            letter-spacing: 1px;
            will-change: transform;
        }
        .btn-action:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 35px rgba(0, 224, 255, 0.5);
        }
        .btn-action:active {
            transform: scale(0.97);
        }
        .btn-action i {
            font-size: 14px;
        }

        .btn-support {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 14px;
            font-size: 13px;
            font-weight: 600;
            color: var(--text-secondary);
            text-decoration: none;
            padding: 10px 22px;
            border-radius: 30px;
            border: 1px solid var(--border-color);
            transition: all 0.25s ease;
            background: transparent;
        }
        .btn-support:hover {
            color: var(--accent-cyan);
            border-color: var(--accent-cyan);
            background: rgba(0, 224, 255, 0.06);
        }
        .btn-support:active {
            transform: scale(0.96);
        }
        .btn-support i {
            font-size: 14px;
        }

        .help-section {
            margin-top: 20px;
            padding-top: 18px;
            border-top: 1px solid var(--border-color);
        }
        .help-text {
            font-size: 12px;
            color: var(--text-secondary);
            font-weight: 500;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            line-height: 1.5;
            text-align: center;
        }
        .help-text i {
            color: var(--accent-cyan);
            flex-shrink: 0;
        }

        @media (max-width: 480px) {
            .failed-card {
                padding: 26px 18px 22px;
            }
            .icon-wrapper {
                width: 80px;
                height: 80px;
                margin-bottom: 14px;
            }
            .icon-wrapper i {
                font-size: 38px;
            }
            .failed-title {
                font-size: 20px;
            }
            .failed-sub {
                font-size: 13px;
            }
            .d-label, .d-val {
                font-size: 12px;
            }
        }
    </style>
</head>
<body>

    <div class="failed-card">

        <div class="icon-wrapper">
            <span class="pulse"></span>
            <i class="fa-solid fa-circle-xmark"></i>
        </div>

        <h1 class="failed-title">Payment Failed</h1>
        <p class="failed-sub">
            <i class="fa-solid fa-triangle-exclamation"></i> 
            Your payment was not received. Please complete the payment and try again.
        </p>

        <div class="details-grid">
            <div class="d-row">
                <span class="d-label"><i class="fa-regular fa-receipt"></i> Transaction ID</span>
                <span class="d-val"><span class="order-id"><?= htmlspecialchars($orderId) ?></span></span>
            </div>
            <div class="d-row">
                <span class="d-label"><i class="fa-regular fa-clock"></i> Date & Time</span>
                <span class="d-val"><?= $currentDate ?></span>
            </div>
            <div class="d-row">
                <span class="d-label"><i class="fa-regular fa-circle"></i> Status</span>
                <span class="d-val"><span class="status-badge"><i class="fa-solid fa-xmark"></i> FAILED</span></span>
            </div>
        </div>

        <a href="index.html" class="btn-action">
            <i class="fa-solid fa-rotate-right"></i> TRY AGAIN
        </a>

        <a href="https://t.me/VishalCodeVerseOwner" target="_blank" class="btn-support">
            <i class="fa-regular fa-circle-question"></i> Need Help? Contact Support
        </a>

        <div class="help-section">
            <span class="help-text">
                <i class="fa-regular fa-lightbulb"></i>
                Still having issues? Our support team is here to help.
            </span>
        </div>

    </div>

</body>
</html>