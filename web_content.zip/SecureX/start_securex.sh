#!/bin/sh
cd "$(dirname "$0")" && python3 securex_av.py
