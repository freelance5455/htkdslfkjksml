SecureX - desktop version (Windows, macOS, Linux)

1. Install Python 3 from python.org (nothing else needed).
2. Unzip this folder.
3. Double-click securex.py, or run:  python securex.py
   Terminal mode:                    python securex.py "C:\path\to\folder"
4. Click "Scan a folder". When a threat is found, the red "Take Action!" screen appears:
   - Delete virus from this file  = permanently deletes the file
   - Uninstall this virus         = moves it to the SecureX_Quarantine folder (safe, reversible)

Try it: make a text file containing the standard EICAR test string and scan its folder.
Deleting is permanent, so check the file name before you click.

Web version: open index.html in any browser to scan files without installing anything.
The browser version can't delete files (browsers don't allow it); use securex.py for real deletion.

App detector (find and uninstall risky apps): python securex_apps.py   (for a phone with no computer, use SecureX_Android)
 - Android phone / Android TV / Google TV: install Android platform-tools, turn on USB debugging
   (or wireless debugging; for a TV run "adb connect TV_IP"), allow the computer, then scan.
 - Windows: lists installed programs; uninstalling opens the program's own uninstaller.
 - Add known-bad package names to bad_packages.txt (one per line); they are treated as threats.
 - Flags come from where the app was installed from and what it asks for, so a flagged app may be legitimate.
   SecureX only uninstalls after you click the button.

=== SecureX Antivirus (main program) ===
Start it: double-click "Start SecureX.bat" (Windows) or start_securex.sh (macOS/Linux), or run: python securex_av.py
 - Real-time protection: watches Downloads, Desktop and Documents (change this in Settings). New or changed files are
   scanned once they finish writing; confirmed threats are moved to quarantine automatically.
 - Quick scan, Full scan (home folder) and Custom scan, with the "Checking.." and "Take Action!" screens.
 - Quarantine tab: restore or permanently delete anything SecureX isolated.
 - Log tab: everything SecureX did. Settings: schedule (scan every N hours while open), folders, auto-quarantine.
 - Signatures: add SHA-256 hashes to signatures.txt, or set a signature URL in Settings and click "Update signatures now".
 - Run in the background: put "pythonw securex_av.py" in your Startup folder (Windows) or add it to login items.
   Terminal options: --quick (for Task Scheduler/cron), --watch, --update.
Limits: SecureX is written in Python, so it detects by hash, signature text and behaviour clues. It has no kernel-level
protection and can miss new or hidden malware. Keep your system's own protection (Windows Security, Play Protect) on.
