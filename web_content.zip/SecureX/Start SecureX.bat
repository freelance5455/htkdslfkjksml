@echo off
cd /d "%~dp0"
start "" pythonw securex_av.py
