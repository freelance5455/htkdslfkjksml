#!/usr/bin/env python3
"""SecureX Antivirus - full desktop program: real-time protection, quick/full/custom scans,
quarantine manager, signature updates, scheduled scans and a log.
  python securex_av.py              open the window
  python securex_av.py --quick      quick scan in the terminal (use with Task Scheduler / cron)
  python securex_av.py --watch      real-time protection in the terminal
  python securex_av.py --update     download signatures from the URL in config.json
"""
import os, sys, json, time, shutil, tempfile, threading, queue, urllib.request, re
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import securex as core
CFG, LOG, SIGS, QDIR = (os.path.join(HERE, n) for n in ("config.json", "securex.log", "signatures.txt", "SecureX_Quarantine"))
core.QUAR = QDIR
HOME = os.path.expanduser("~")
DEFAULT = {"watch": [os.path.join(HOME, d) for d in ("Downloads", "Desktop", "Documents")],
           "realtime": True, "auto_quarantine": True, "schedule_hours": 24, "signature_url": "", "last_scan": 0}
SKIP = {"windows", "program files", "program files (x86)", "node_modules", ".git", "appdata", "library", "proc", "sys", "dev", "securex_quarantine"}

def load_cfg():
    c = dict(DEFAULT)
    try: c.update(json.load(open(CFG)))
    except (OSError, ValueError): pass
    return c
def save_cfg(c): json.dump(c, open(CFG, "w"), indent=2)
def log(msg):
    with open(LOG, "a", encoding="utf-8") as f: f.write("%s  %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg))

def load_sigs():
    n = 0
    try:
        for line in open(SIGS):
            t = line.split()
            if t and re.fullmatch(r"[0-9a-fA-F]{64}", t[0]): core.BAD_HASH[t[0].lower()] = " ".join(t[1:]) or "Known-Malware"; n += 1
    except OSError: pass
    return n
def update_sigs(url):
    if not url: raise ValueError("Set signature_url in config.json (a text file with one SHA-256 hash per line).")
    data = urllib.request.urlopen(url, timeout=30).read().decode("utf-8", "ignore")
    old = open(SIGS).read() if os.path.exists(SIGS) else ""
    found = [l for l in data.splitlines() if re.match(r"[0-9a-fA-F]{64}", l.strip())]
    open(SIGS, "w").write(old + "\n".join(found) + "\n"); log("Signatures updated: %d entries" % len(found))
    return load_sigs()

def quick_folders(): return [p for p in (os.path.join(HOME, d) for d in ("Downloads", "Desktop", "Documents")) if os.path.isdir(p)] + [tempfile.gettempdir()]
def iter_files(folders):
    seen = set()
    for top in folders:
        for root, dirs, files in os.walk(top):
            dirs[:] = [d for d in dirs if d.lower() not in SKIP]
            for n in files:
                p = os.path.join(root, n); k = os.path.realpath(p)
                if k not in seen: seen.add(k); yield p

def quarantine_file(path, why):
    os.makedirs(QDIR, exist_ok=True); qid = "%d_%s" % (time.time() * 1000, os.path.basename(path))
    shutil.move(path, os.path.join(QDIR, qid + ".quarantined"))
    json.dump({"orig": path, "why": why, "time": time.time()}, open(os.path.join(QDIR, qid + ".json"), "w"))
    log("QUARANTINED %s (%s)" % (path, "; ".join(why))); return qid
def list_quarantine():
    out = []
    if os.path.isdir(QDIR):
        for f in sorted(os.listdir(QDIR)):
            if f.endswith(".json"):
                try: out.append((f[:-5], json.load(open(os.path.join(QDIR, f)))))
                except ValueError: pass
    return out
def q_restore(qid):
    meta = json.load(open(os.path.join(QDIR, qid + ".json"))); dest = meta["orig"]
    if os.path.exists(dest): dest += ".restored"
    os.makedirs(os.path.dirname(dest), exist_ok=True); shutil.move(os.path.join(QDIR, qid + ".quarantined"), dest)
    os.remove(os.path.join(QDIR, qid + ".json")); log("RESTORED " + dest); return dest
def q_purge(qid):
    for ext in (".quarantined", ".json"):
        try: os.remove(os.path.join(QDIR, qid + ext))
        except OSError: pass
    log("DELETED permanently " + qid)

def scan_folders(folders, progress=None, stop=lambda: False):
    res, n = [], 0
    for p in iter_files(folders):
        if stop(): break
        n += 1; lv, why = core.scan_file(p)
        if lv: res.append((p, lv, why))
        if progress and n % 25 == 0: progress(n)
    log("Scan finished: %d files, %d flagged" % (n, len(res))); return n, res

class Realtime(threading.Thread):
    """Watches folders; new or changed files are scanned once they stop growing."""
    def __init__(self, cfg, events):
        super().__init__(daemon=True); self.cfg, self.events, self.stop_flag = cfg, events, False
    def run(self):
        seen, pending = {}, {}
        for p in iter_files(self.cfg["watch"]):
            try: s = os.stat(p); seen[p] = (s.st_mtime, s.st_size)
            except OSError: pass
        log("Real-time protection on: " + ", ".join(self.cfg["watch"]))
        while not self.stop_flag:
            time.sleep(2)
            for p in iter_files(self.cfg["watch"]):
                try: s = os.stat(p)
                except OSError: continue
                sig = (s.st_mtime, s.st_size)
                if seen.get(p) != sig:
                    if pending.get(p) == sig:
                        seen[p] = sig; pending.pop(p)
                        lv, why = core.scan_file(p)
                        if lv == 2:
                            qid = None
                            if self.cfg["auto_quarantine"]:
                                try: qid = quarantine_file(p, why)
                                except OSError as e: why = why + ["Could not quarantine: %s" % e]
                            self.events.put(("threat", p, why, qid))
                        elif lv == 1: log("Suspicious (real-time) %s (%s)" % (p, "; ".join(why))); self.events.put(("sus", p, why, None))
                    else: pending[p] = sig
        log("Real-time protection off")

def cli(args):
    cfg = load_cfg(); load_sigs()
    if "--update" in args: print("Signatures loaded:", update_sigs(cfg["signature_url"])); return
    if "--watch" in args:
        ev = queue.Queue(); Realtime(cfg, ev).start(); print("SecureX real-time protection running. Ctrl+C to stop.")
        while True:
            e = ev.get(); print(("THREAT " if e[0] == "threat" else "Suspicious ") + e[1], "-", "; ".join(e[2]), "(quarantined)" if e[3] else "")
    n, res = scan_folders(quick_folders()); cfg["last_scan"] = time.time(); save_cfg(cfg)
    for p, lv, why in res:
        print(("THREAT     " if lv == 2 else "Suspicious ") + p + "  [" + "; ".join(why) + "]")
        if lv == 2 and cfg["auto_quarantine"]:
            try: quarantine_file(p, why); print("  -> quarantined")
            except OSError as e: print("  -> could not quarantine:", e)
    print("Scanned %d files, %d flagged." % (n, len(res)))

def gui():
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox
    cfg = load_cfg(); load_sigs(); events = queue.Queue(); rt = [None]; stop = [False]; busy = [False]
    root = tk.Tk(); root.title("SecureX Antivirus"); root.geometry("680x640")
    try: logo = tk.PhotoImage(file=os.path.join(HERE, "logo.png")); tk.Label(root, image=logo).pack(pady=4)
    except Exception: pass
    tabs = ttk.Notebook(root); tabs.pack(fill="both", expand=True, padx=8, pady=8)
    t1, t2, t3, t4 = (ttk.Frame(tabs) for _ in range(4))
    for t, n in ((t1, "Protection"), (t2, "Quarantine"), (t3, "Log"), (t4, "Settings")): tabs.add(t, text=n)
    status = tk.StringVar(); tk.Label(t1, textvariable=status, font=("Trebuchet MS", 14, "bold")).pack(pady=10)
    info = tk.StringVar(value="Never scanned." if not cfg["last_scan"] else "Last scan: " + time.strftime("%Y-%m-%d %H:%M", time.localtime(cfg["last_scan"])))
    tk.Label(t1, textvariable=info).pack()
    box = tk.Listbox(t1, height=12); box.pack(fill="both", expand=True, padx=10, pady=10)
    def refresh_status():
        status.set("Real-time protection: ON" if rt[0] else "Real-time protection: OFF")
        rtbtn.config(text="Turn off real-time protection" if rt[0] else "Turn on real-time protection")
    def toggle_rt():
        if rt[0]: rt[0].stop_flag = True; rt[0] = None
        else: rt[0] = Realtime(cfg, events); rt[0].start()
        refresh_status()
    def checking_screen():
        w = tk.Toplevel(root); w.configure(bg="#4d88ff"); w.geometry("460x520"); w.title("SecureX")
        c = tk.Canvas(w, width=140, height=140, bg="#4d88ff", highlightthickness=0); c.pack(pady=(60, 30))
        c.create_oval(8, 8, 132, 132, fill="#0450ff", outline="#0450ff")
        c.create_line(40, 56, 62, 52, fill="white", width=4, capstyle="round")
        c.create_oval(76, 40, 106, 70, outline="white", width=4); c.create_line(100, 66, 116, 84, fill="white", width=4)
        c.create_arc(48, 96, 88, 124, start=0, extent=180, style="arc", outline="white", width=4)
        lab = tk.Label(w, text="Checking..", font=("Courier", 26), bg="#4d88ff"); lab.pack(expand=True)
        cancel = tk.Button(w, text="Stop", command=lambda: stop.__setitem__(0, True)); cancel.pack(pady=20)
        w.update(); return w, lab
    def alert(path, why, qid):
        w = tk.Toplevel(root); w.configure(bg="#ff8888"); w.geometry("460x540"); w.title("SecureX"); w.grab_set()
        c = tk.Canvas(w, width=110, height=110, bg="#ff8888", highlightthickness=0); c.pack(pady=14)
        c.create_oval(5, 5, 105, 105, fill="red", outline="red"); c.create_rectangle(50, 20, 58, 62, fill="white", outline="white")
        c.create_oval(47, 72, 63, 88, fill="white", outline="white")
        tk.Label(w, text="Take Action!", font=("Courier", 26), bg="#ff8888").pack()
        extra = "\nSecureX already moved it to quarantine." if qid else ""
        tk.Label(w, text="The App/File\n%s\nhas a Trojan or malware.\n%s%s" % (os.path.basename(path), "; ".join(why), extra),
                 font=("Courier", 12), bg="#ff8888", wraplength=400).pack(pady=14, expand=True)
        def delete():
            try:
                if qid: q_purge(qid)
                else: os.remove(path); log("DELETED " + path)
                box.insert(0, "DELETED  " + path)
            except OSError as e: messagebox.showerror("SecureX", str(e))
            w.destroy(); fill_q()
        def quar():
            try:
                if not qid: quarantine_file(path, why)
                box.insert(0, "QUARANTINED  " + path)
            except OSError as e: messagebox.showerror("SecureX", str(e))
            w.destroy(); fill_q()
        for t, f in (("Delete virus from this file", delete), ("Keep in quarantine" if qid else "Uninstall this virus (quarantine)", quar)):
            tk.Button(w, text=t, command=f, bg="#ff8888", relief="flat", font=("Courier", 13), pady=14).pack(fill="x", pady=2)
        w.wait_window()
    def do_scan(folders):
        if busy[0]: return
        busy[0] = True; stop[0] = False; box.delete(0, "end"); out = {}
        scr, lab = checking_screen(); t0 = time.time()
        def work(): out["r"] = scan_folders(folders, lambda n: out.__setitem__("n", n), lambda: stop[0])
        th = threading.Thread(target=work, daemon=True); th.start()
        def poll():
            if th.is_alive() or time.time() - t0 < 1.5:
                lab.config(text="Checking" + "." * (2 + int(time.time() * 2) % 3) + ("  %d" % out["n"] if "n" in out else "")); root.after(300, poll); return
            scr.destroy(); n, res = out["r"]; busy[0] = False
            cfg["last_scan"] = time.time(); save_cfg(cfg); info.set("Last scan: " + time.strftime("%Y-%m-%d %H:%M"))
            for p, lv, why in res: box.insert("end", ("THREAT  " if lv == 2 else "Suspicious  ") + p)
            box.insert(0, "Scanned %d files, %d flagged." % (n, len(res)))
            for p, lv, why in res:
                if lv == 2 and os.path.exists(p): alert(p, why, None)
        poll()
    def custom():
        d = filedialog.askdirectory()
        if d: do_scan([d])
    app_lines = {}
    def app_alert(pkg, why):
        w = tk.Toplevel(root); w.configure(bg="#ff8888"); w.geometry("460x540"); w.title("SecureX"); w.grab_set()
        c = tk.Canvas(w, width=110, height=110, bg="#ff8888", highlightthickness=0); c.pack(pady=14)
        c.create_oval(5, 5, 105, 105, fill="red", outline="red"); c.create_rectangle(50, 20, 58, 62, fill="white", outline="white")
        c.create_oval(47, 72, 63, 88, fill="white", outline="white")
        tk.Label(w, text="Take Action!", font=("Courier", 26), bg="#ff8888").pack()
        tk.Label(w, text="The App\n%s\nmay have a Trojan or malware.\n%s" % (pkg.split("|")[0], "; ".join(why)),
                 font=("Courier", 12), bg="#ff8888", wraplength=400).pack(pady=14, expand=True)
        def go():
            import securex_apps as apps
            ok, msg = apps.uninstall(pkg); log("UNINSTALL %s: %s" % (pkg.split("|")[0], msg)); messagebox.showinfo("SecureX", msg); w.destroy()
        tk.Button(w, text="Uninstall this virus", command=go, bg="#ff8888", relief="flat", font=("Courier", 14), pady=16).pack(fill="x", pady=2)
        tk.Button(w, text="Skip", command=w.destroy, bg="#ff8888", relief="flat").pack(fill="x")
        w.wait_window()
    def check_apps():
        if busy[0]: return
        import securex_apps as apps
        busy[0] = True; stop[0] = False; box.delete(0, "end"); app_lines.clear(); out = {}
        scr, lab = checking_screen(); t0 = time.time()
        def work():
            try: out["r"] = apps.scan(lambda p: out.__setitem__("n", p))
            except BaseException as e: out["err"] = str(e) or "Could not check apps."
        th = threading.Thread(target=work, daemon=True); th.start()
        def poll():
            if th.is_alive() or time.time() - t0 < 1.5:
                lab.config(text="Checking" + "." * (2 + int(time.time() * 2) % 3)); root.after(300, poll); return
            scr.destroy(); busy[0] = False
            if "err" in out: messagebox.showerror("SecureX", out["err"]); return
            res = out["r"]; flagged = [r for r in res if r[0]]
            for lv, pkg, why in flagged:
                line = ("THREAT  " if lv == 2 else "Suspicious  ") + pkg.split("|")[0]; box.insert("end", line); app_lines[line] = (pkg, why)
            box.insert(0, "%d apps checked, %d flagged. Double-click a flagged app to uninstall it." % (len(res), len(flagged))); log("App check: %d apps, %d flagged" % (len(res), len(flagged)))
            for lv, pkg, why in flagged:
                if lv == 2: app_alert(pkg, why)
        poll()
    box.bind("<Double-1>", lambda e: app_lines.get(box.get(box.nearest(e.y))) and app_alert(*app_lines[box.get(box.nearest(e.y))]))
    rtbtn = tk.Button(t1, command=toggle_rt); rtbtn.pack(pady=2)
    row = tk.Frame(t1); row.pack(pady=6)
    for t, f in (("Quick scan", lambda: do_scan(quick_folders())), ("Full scan (home folder)", lambda: do_scan([HOME])), ("Custom scan", custom), ("Check apps", check_apps)):
        tk.Button(row, text=t, command=f, padx=10, pady=6).pack(side="left", padx=4)
    # quarantine tab
    qbox = tk.Listbox(t2); qbox.pack(fill="both", expand=True, padx=10, pady=10); qitems = []
    def fill_q():
        qbox.delete(0, "end"); qitems.clear()
        for qid, m in list_quarantine(): qitems.append(qid); qbox.insert("end", m["orig"] + "  [" + "; ".join(m["why"]) + "]")
    def qdo(fn, ask):
        s = qbox.curselection()
        if s and messagebox.askyesno("SecureX", ask): fn(qitems[s[0]]); fill_q()
    qr = tk.Frame(t2); qr.pack(pady=6)
    tk.Button(qr, text="Restore", command=lambda: qdo(q_restore, "Restore this file to its original place? It was flagged as dangerous.")).pack(side="left", padx=6)
    tk.Button(qr, text="Delete permanently", command=lambda: qdo(q_purge, "Delete this file forever?")).pack(side="left", padx=6)
    # log tab
    lt = tk.Text(t3, state="disabled"); lt.pack(fill="both", expand=True, padx=10, pady=10)
    def fill_log():
        lt.config(state="normal"); lt.delete("1.0", "end")
        try: lt.insert("end", "".join(open(LOG, encoding="utf-8").readlines()[-300:]))
        except OSError: lt.insert("end", "No log yet.")
        lt.config(state="disabled"); lt.see("end")
    tabs.bind("<<NotebookTabChanged>>", lambda e: (fill_q(), fill_log()))
    # settings tab
    vq = tk.BooleanVar(value=cfg["auto_quarantine"]); vr = tk.BooleanVar(value=cfg["realtime"])
    vh = tk.StringVar(value=str(cfg["schedule_hours"])); vu = tk.StringVar(value=cfg["signature_url"]); vw = tk.StringVar(value=";".join(cfg["watch"]))
    tk.Checkbutton(t4, text="Start real-time protection when SecureX opens", variable=vr).pack(anchor="w", padx=12, pady=4)
    tk.Checkbutton(t4, text="Automatically quarantine threats found by real-time protection", variable=vq).pack(anchor="w", padx=12)
    for label, var in (("Scan every N hours while open (0 = off)", vh), ("Signature update URL (text file of SHA-256 hashes)", vu), ("Folders to protect (separate with ;)", vw)):
        tk.Label(t4, text=label).pack(anchor="w", padx=12, pady=(10, 0)); tk.Entry(t4, textvariable=var).pack(fill="x", padx=12)
    def save():
        cfg.update(auto_quarantine=vq.get(), realtime=vr.get(), signature_url=vu.get().strip(), watch=[p for p in vw.get().split(";") if p.strip()])
        try: cfg["schedule_hours"] = max(0, float(vh.get()))
        except ValueError: cfg["schedule_hours"] = 0
        save_cfg(cfg); messagebox.showinfo("SecureX", "Saved. Turn real-time protection off and on to apply new folders.")
    def upd():
        cfg["signature_url"] = vu.get().strip()
        try: messagebox.showinfo("SecureX", "Signatures loaded: %d" % update_sigs(cfg["signature_url"]))
        except Exception as e: messagebox.showerror("SecureX", str(e))
    br = tk.Frame(t4); br.pack(pady=14)
    tk.Button(br, text="Save settings", command=save).pack(side="left", padx=6); tk.Button(br, text="Update signatures now", command=upd).pack(side="left", padx=6)
    def pump():
        while not events.empty():
            kind, p, why, qid = events.get()
            box.insert(0, ("THREAT (real-time)  " if kind == "threat" else "Suspicious (real-time)  ") + p)
            if kind == "threat": alert(p, why, qid)
        h = cfg["schedule_hours"]
        if h and not busy[0] and time.time() - cfg["last_scan"] > h * 3600: do_scan(quick_folders())
        fill_q() if tabs.index(tabs.select()) == 1 else None
        root.after(1000, pump)
    if cfg["realtime"]: toggle_rt()
    refresh_status(); fill_q(); pump()
    root.protocol("WM_DELETE_WINDOW", lambda: (setattr(rt[0], "stop_flag", True) if rt[0] else None, root.destroy()))
    root.mainloop()

if __name__ == "__main__":
    if len(sys.argv) > 1: cli(sys.argv[1:])
    else:
        try: gui()
        except ImportError: print("No window support here. Use: --quick, --watch or --update")
