#!/usr/bin/env python3
"""SecureX App Detector - finds risky installed apps and uninstalls them.
Android phone / Android TV / Google TV: connect it to this computer with ADB, then run  python securex_apps.py
Windows: run it directly to list installed programs.  Add known-bad package names to bad_packages.txt.
"""
import os, re, sys, shutil, subprocess
HERE = os.path.dirname(os.path.abspath(__file__))
HIGH = ["BIND_ACCESSIBILITY_SERVICE", "BIND_DEVICE_ADMIN", "SYSTEM_ALERT_WINDOW", "SEND_SMS", "READ_SMS",
        "RECEIVE_SMS", "READ_CALL_LOG", "REQUEST_INSTALL_PACKAGES", "BIND_NOTIFICATION_LISTENER_SERVICE"]
STORES = ("com.android.vending", "com.amazon.venezia", "com.sec.android.app.samsungapps", "com.google.android.packageinstaller.store")

def blocklist():
    p = os.path.join(HERE, "bad_packages.txt")
    if not os.path.exists(p): return set()
    return {l.strip() for l in open(p) if l.strip() and not l.startswith("#")}

def adb(*a):
    r = subprocess.run(["adb"] + list(a), capture_output=True, text=True, timeout=60)
    return (r.stdout + r.stderr).strip()

def judge(pkg, installer, perms, accessibility_on, bad):
    """Returns (level, reasons). 0 clean, 1 suspicious, 2 threat."""
    sideloaded = installer not in STORES
    if accessibility_on: perms = perms + " BIND_ACCESSIBILITY_SERVICE"
    risky = [p for p in HIGH if p in perms]
    why = []
    if pkg in bad: return 2, ["On the SecureX blocklist"]
    if sideloaded: why.append("Not installed from a trusted app store")
    if risky: why.append("Asks for: " + ", ".join(r.lower() for r in risky))
    if accessibility_on: why.append("Has Accessibility control turned on")
    banker = ("BIND_ACCESSIBILITY_SERVICE" in risky and "SYSTEM_ALERT_WINDOW" in risky
              and any(s in risky for s in ("SEND_SMS", "READ_SMS", "RECEIVE_SMS")))
    if sideloaded and banker: return 2, why + ["Matches banking-trojan pattern (screen control + overlay + SMS)"]
    if (sideloaded and len(risky) >= 2) or len(risky) >= 4 or (sideloaded and accessibility_on): return 1, why
    return 0, why

def android_scan(progress=lambda s: None):
    if not shutil.which("adb"): raise SystemExit("ADB not found. Install Android platform-tools and add adb to your PATH.")
    devs = [l for l in adb("devices").splitlines()[1:] if l.strip().endswith("device")]
    if not devs: raise SystemExit("No device found. Turn on Developer options > USB debugging, connect, and allow this computer.")
    bad = blocklist(); acc = adb("shell", "settings", "get", "secure", "enabled_accessibility_services")
    out = []
    for line in adb("shell", "pm", "list", "packages", "-3", "-i").splitlines():
        m = re.match(r"package:(\S+)\s+installer=(\S+)", line)
        if not m: continue
        pkg, inst = m.groups(); progress(pkg)
        perms = adb("shell", "dumpsys", "package", pkg)
        lv, why = judge(pkg, inst, perms, pkg in acc, bad)
        out.append((lv, pkg, why))
    return sorted(out, reverse=True)

def android_uninstall(pkg):
    r = adb("uninstall", pkg)
    if "Success" in r: return True, "Uninstalled."
    r2 = adb("shell", "pm", "uninstall", "--user", "0", pkg)   # fallback for device-admin / stubborn apps
    if "Success" in r2: return True, "Uninstalled for this user."
    return False, "Android refused: %s. If it is a device admin, turn that off in Settings > Security first." % r2

def windows_scan(progress=lambda s: None):
    import winreg
    bad = {b.lower() for b in blocklist()}; out = []
    for root in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
        for sub in (r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"):
            try: k = winreg.OpenKey(root, sub)
            except OSError: continue
            for i in range(winreg.QueryInfoKey(k)[0]):
                try:
                    s = winreg.OpenKey(k, winreg.EnumKey(k, i))
                    g = lambda n: winreg.QueryValueEx(s, n)[0]
                    name, cmd = g("DisplayName"), g("UninstallString")
                except OSError: continue
                try: pub = g("Publisher")
                except OSError: pub = ""
                lv, why = (2, ["On the SecureX blocklist"]) if name.lower() in bad else (1, ["No publisher listed"]) if not pub else (0, [])
                out.append((lv, name + "|" + cmd, why))
    return sorted(out, reverse=True)

def windows_uninstall(key):
    subprocess.Popen(key.split("|", 1)[1], shell=True); return True, "Uninstaller opened. Follow its steps."

if sys.platform.startswith("win") and not shutil.which("adb"): scan, uninstall = windows_scan, windows_uninstall
else: scan, uninstall = android_scan, android_uninstall

def cli():
    res = scan(lambda p: print("checking", p, end="\r"))
    for lv, pkg, why in res:
        if lv: print(("THREAT     " if lv == 2 else "Suspicious ") + pkg.split("|")[0] + "  [" + "; ".join(why) + "]")
    for lv, pkg, why in [r for r in res if r[0] == 2]:
        if input("\nTake Action! %s is a threat. Uninstall this virus? [y/N]: " % pkg.split("|")[0]).lower() == "y":
            print(uninstall(pkg)[1])
    print("\nDone. %d apps checked." % len(res))

def checking_screen(root):
    import tkinter as tk
    w = tk.Toplevel(root); w.configure(bg="#4d88ff"); w.geometry("460x520"); w.title("SecureX")
    c = tk.Canvas(w, width=140, height=140, bg="#4d88ff", highlightthickness=0); c.pack(pady=(60, 30))
    c.create_oval(8, 8, 132, 132, fill="#0450ff", outline="#0450ff")
    c.create_line(40, 56, 62, 52, fill="white", width=4, capstyle="round")
    c.create_oval(76, 40, 106, 70, outline="white", width=4); c.create_line(100, 66, 116, 84, fill="white", width=4)
    c.create_arc(48, 96, 88, 124, start=0, extent=180, style="arc", outline="white", width=4)
    tk.Label(w, text="Checking..", font=("Courier", 26), bg="#4d88ff").pack(expand=True)
    w.update(); return w

def gui():
    import tkinter as tk
    from tkinter import messagebox
    root = tk.Tk(); root.title("SecureX App Detector"); root.geometry("640x560")
    try: logo = tk.PhotoImage(file=os.path.join(HERE, "logo.png")); tk.Label(root, image=logo).pack(pady=6)
    except Exception: pass
    st = tk.StringVar(value="Connect your device with ADB, then scan."); tk.Label(root, textvariable=st).pack()
    box = tk.Listbox(root, height=16); box.pack(fill="both", expand=True, padx=12, pady=8); items = []
    def alert(pkg, why):
        w = tk.Toplevel(root); w.configure(bg="#ff8888"); w.geometry("460x520"); w.grab_set()
        c = tk.Canvas(w, width=110, height=110, bg="#ff8888", highlightthickness=0); c.pack(pady=14)
        c.create_oval(5, 5, 105, 105, fill="red", outline="red"); c.create_rectangle(50, 20, 58, 62, fill="white", outline="white")
        c.create_oval(47, 72, 63, 88, fill="white", outline="white")
        tk.Label(w, text="Take Action!", font=("Courier", 26), bg="#ff8888").pack()
        tk.Label(w, text="The app\n%s\nhas a Trojan or malware.\n%s" % (pkg.split("|")[0], "; ".join(why)), font=("Courier", 12),
                 bg="#ff8888", wraplength=400).pack(pady=14, expand=True)
        def go():
            ok, msg = uninstall(pkg); messagebox.showinfo("SecureX", msg); w.destroy()
        tk.Button(w, text="Uninstall this virus", command=go, bg="#ff8888", relief="flat", font=("Courier", 14), pady=16).pack(fill="x", pady=2)
        tk.Button(w, text="Skip", command=w.destroy, bg="#ff8888", relief="flat").pack(fill="x")
        w.wait_window()
    def run():
        ck = checking_screen(root)
        try: st.set("Scanning..."); root.update(); res = scan(lambda p: (st.set("Checking " + p[:50]), root.update()))
        except SystemExit as e: ck.destroy(); messagebox.showerror("SecureX", str(e)); st.set("Not scanned."); return
        ck.destroy()
        box.delete(0, "end"); items.clear()
        for lv, pkg, why in res:
            if lv: items.append((pkg, why)); box.insert("end", ("THREAT  " if lv == 2 else "Suspicious  ") + pkg.split("|")[0])
        st.set("%d apps checked, %d flagged." % (len(res), len(items)))
        for lv, pkg, why in res:
            if lv == 2: alert(pkg, why)
    def sel():
        s = box.curselection()
        if s: alert(*items[s[0]])
    tk.Button(root, text="Scan apps", command=run, padx=16, pady=8).pack(side="left", padx=40, pady=10)
    tk.Button(root, text="Uninstall selected", command=sel, padx=16, pady=8).pack(side="right", padx=40, pady=10)
    root.mainloop()

if __name__ == "__main__":
    if "--cli" in sys.argv: cli()
    else:
        try: gui()
        except ImportError: cli()
