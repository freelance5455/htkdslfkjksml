SecureX for Android - installed-app checker with an Uninstall button

Build the APK (needs Android Studio, free):
1. Open Android Studio > Open > choose this SecureX_Android folder. Let it sync (it may offer to download Gradle 8.7 - accept).
2. Build > Build APK(s). The file appears in app/build/outputs/apk/debug/app-debug.apk. Copy it to your phone/TV and install it
   (allow "install unknown apps" for the app you use to open it).
3. Open SecureX, tap "Check apps". Threats show the red "Take Action!" screen; "Uninstall this virus" opens Android's own
   uninstall confirmation. Suspicious apps are listed - tap one to see why.

Notes: add known-bad package names to app/src/main/assets/bad_packages.txt. This app only reads which apps are installed,
what permissions they use and where they came from. It never uploads anything. Flags are clues, not proof: a legitimate
sideloaded app can look suspicious. Android may refuse to uninstall device-admin apps until admin is turned off in Settings.
