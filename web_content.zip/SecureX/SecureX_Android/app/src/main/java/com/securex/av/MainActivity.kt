package com.securex.av

import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.concurrent.thread

class MainActivity : Activity() {

    data class Finding(val pkg: String, val label: String, val level: Int, val why: List<String>)

    private val high = listOf(
        "BIND_ACCESSIBILITY_SERVICE", "BIND_DEVICE_ADMIN", "SYSTEM_ALERT_WINDOW", "SEND_SMS", "READ_SMS",
        "RECEIVE_SMS", "READ_CALL_LOG", "REQUEST_INSTALL_PACKAGES", "BIND_NOTIFICATION_LISTENER_SERVICE"
    )
    private val stores = setOf("com.android.vending", "com.amazon.venezia", "com.sec.android.app.samsungapps")

    private lateinit var root: FrameLayout
    private lateinit var list: LinearLayout
    private lateinit var summary: TextView
    private lateinit var checkButton: Button
    private val pendingThreats = ArrayDeque<Finding>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)
        root.setBackgroundColor(0xFFF3F6FF.toInt())
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(16), dp(36), dp(16), dp(16))

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        col.addView(logo, LinearLayout.LayoutParams(dp(96), dp(96)))

        val title = TextView(this)
        title.text = "SecureX"
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28f)
        title.setTypeface(null, Typeface.BOLD)
        title.setTextColor(0xFF0B1B3F.toInt())
        col.addView(title)

        checkButton = Button(this)
        checkButton.text = "Check apps"
        checkButton.setTextColor(Color.WHITE)
        checkButton.setBackgroundColor(0xFF0450FF.toInt())
        checkButton.setOnClickListener { startCheck() }
        val bp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(56))
        bp.setMargins(0, dp(16), 0, dp(8))
        col.addView(checkButton, bp)

        summary = TextView(this)
        summary.text = "Tap Check apps to scan the apps installed on this device."
        summary.setTextColor(0xFF5B6B8C.toInt())
        col.addView(summary)

        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.addView(list)
        col.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(col)
        setContentView(root)
    }

    // ---------- scanning ----------
    private fun startCheck() {
        checkButton.isEnabled = false
        val screen = buildCheckingScreen()
        root.addView(screen)
        val t0 = System.currentTimeMillis()
        thread {
            val found: List<Finding>? = try { scan() } catch (e: Exception) { null }
            val wait = 1500 - (System.currentTimeMillis() - t0)
            if (wait > 0) Thread.sleep(wait)
            runOnUiThread {
                root.removeView(screen)
                checkButton.isEnabled = true
                if (found == null) summary.text = "Could not check apps on this device." else showResults(found)
            }
        }
    }

    private fun scan(): List<Finding> {
        val flags = PackageManager.GET_PERMISSIONS or PackageManager.GET_SERVICES or PackageManager.GET_RECEIVERS
        @Suppress("DEPRECATION")
        val pkgs = packageManager.getInstalledPackages(flags)
        val acc = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        val bad = assets.open("bad_packages.txt").bufferedReader().readLines()
            .map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }.toSet()
        val out = mutableListOf<Finding>()
        for (p in pkgs) {
            val ai = p.applicationInfo ?: continue
            if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 || p.packageName == packageName) continue
            val label = packageManager.getApplicationLabel(ai).toString()
            val installer: String? = try {
                if (Build.VERSION.SDK_INT >= 30) packageManager.getInstallSourceInfo(p.packageName).installingPackageName
                else @Suppress("DEPRECATION") packageManager.getInstallerPackageName(p.packageName)
            } catch (e: Exception) { null }
            val have = HashSet<String>()
            p.requestedPermissions?.forEach { have.add(it.substringAfterLast('.')) }
            p.services?.forEach { s -> s.permission?.let { have.add(it.substringAfterLast('.')) } }
            p.receivers?.forEach { r -> r.permission?.let { have.add(it.substringAfterLast('.')) } }
            val accOn = acc.contains(p.packageName)
            if (accOn) have.add("BIND_ACCESSIBILITY_SERVICE")
            val risky = high.filter { it in have }
            val sideloaded = installer == null || installer !in stores
            val why = mutableListOf<String>()
            if (sideloaded) why.add("Not installed from a trusted app store")
            if (risky.isNotEmpty()) why.add("Uses: " + risky.joinToString(", ") { it.lowercase() })
            if (accOn) why.add("Has Accessibility control turned on")
            val banker = "BIND_ACCESSIBILITY_SERVICE" in risky && "SYSTEM_ALERT_WINDOW" in risky &&
                listOf("SEND_SMS", "READ_SMS", "RECEIVE_SMS").any { it in risky }
            val level = when {
                p.packageName in bad -> { why.add("On the SecureX blocklist"); 2 }
                sideloaded && banker -> { why.add("Banking-trojan pattern (screen control + overlay + SMS)"); 2 }
                (sideloaded && risky.size >= 2) || risky.size >= 4 || (sideloaded && accOn) -> 1
                else -> 0
            }
            out.add(Finding(p.packageName, label, level, why))
        }
        return out.sortedByDescending { it.level }
    }

    private fun showResults(all: List<Finding>) {
        list.removeAllViews()
        val flagged = all.filter { it.level > 0 }
        summary.text = "${all.size} apps checked, ${flagged.size} flagged. Tap a flagged app for details."
        for (f in flagged) {
            val row = TextView(this)
            row.text = (if (f.level == 2) "THREAT  " else "Suspicious  ") + f.label + "\n" + f.pkg
            row.setTextColor(if (f.level == 2) 0xFFC42B2B.toInt() else 0xFFB86A00.toInt())
            row.setPadding(dp(8), dp(12), dp(8), dp(12))
            row.setOnClickListener { showAlert(f) }
            list.addView(row)
        }
        pendingThreats.clear()
        flagged.filter { it.level == 2 }.forEach { pendingThreats.addLast(it) }
        nextThreat()
    }

    private fun nextThreat() {
        val f = pendingThreats.removeFirstOrNull() ?: return
        showAlert(f)
    }

    // ---------- screens ----------
    private class Emblem(ctx: android.content.Context, private val color: Int, private val alertMode: Boolean) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            p.style = Paint.Style.FILL; p.color = color
            c.drawRoundRect(RectF(0.1f * w, 0.04f * h, 0.96f * w, 0.96f * h), 0.32f * w, 0.32f * w, p)
            p.color = Color.WHITE
            p.strokeCap = Paint.Cap.ROUND
            if (alertMode) {
                p.style = Paint.Style.STROKE; p.strokeWidth = 0.05f * w
                c.drawLine(0.5f * w, 0.2f * h, 0.5f * w, 0.55f * h, p)
                p.style = Paint.Style.FILL
                c.drawCircle(0.5f * w, 0.74f * h, 0.1f * w, p)
            } else {
                p.style = Paint.Style.STROKE; p.strokeWidth = 0.04f * w
                c.drawLine(0.28f * w, 0.4f * h, 0.45f * w, 0.37f * h, p)
                c.drawCircle(0.62f * w, 0.36f * h, 0.14f * w, p)
                c.drawLine(0.72f * w, 0.46f * h, 0.84f * w, 0.58f * h, p)
                c.drawArc(RectF(0.35f * w, 0.62f * h, 0.7f * w, 0.9f * h), 200f, 140f, false, p)
            }
        }
    }

    private fun mono(t: String, sp: Float, color: Int = Color.BLACK): TextView {
        val v = TextView(this)
        v.text = t
        v.typeface = Typeface.MONOSPACE
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        v.setTextColor(color)
        v.gravity = Gravity.CENTER
        return v
    }

    private fun buildCheckingScreen(): View {
        val screen = FrameLayout(this)
        screen.setBackgroundColor(0xFF4D88FF.toInt())
        screen.isClickable = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.addView(Emblem(this, 0xFF0450FF.toInt(), false), LinearLayout.LayoutParams(dp(170), dp(170)))
        val label = mono("Checking..", 28f)
        label.setPadding(0, dp(28), 0, 0)
        col.addView(label)
        screen.addView(col, FrameLayout.LayoutParams(-1, -1))
        var n = 0
        val tick = object : Runnable {
            override fun run() {
                if (!screen.isAttachedToWindow) return
                n = (n + 1) % 3
                label.text = "Checking" + ".".repeat(n + 2)
                screen.postDelayed(this, 350)
            }
        }
        screen.postDelayed(tick, 350)
        return screen
    }

    private fun showAlert(f: Finding) {
        val screen = FrameLayout(this)
        screen.setBackgroundColor(0xFFFF8888.toInt())
        screen.isClickable = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(20), dp(48), dp(20), 0)
        col.addView(Emblem(this, 0xFFFF0000.toInt(), true), LinearLayout.LayoutParams(dp(130), dp(130)))
        col.addView(mono("Take Action!", 32f))
        val msg = mono("The App\n${f.label}\nmay have a Trojan or malware.\n" + f.why.joinToString("; "), 15f)
        msg.setPadding(0, dp(16), 0, 0)
        col.addView(msg, LinearLayout.LayoutParams(-1, 0, 1f))
        fun bar(text: String, action: () -> Unit) {
            val b = Button(this)
            b.text = text
            b.isAllCaps = false
            b.typeface = Typeface.MONOSPACE
            b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            b.setBackgroundColor(0xFFFF8888.toInt())
            b.setOnClickListener { action() }
            col.addView(b, LinearLayout.LayoutParams(-1, dp(72)))
            val line = View(this)
            line.setBackgroundColor(Color.WHITE)
            col.addView(line, LinearLayout.LayoutParams(-1, dp(3)))
        }
        val line0 = View(this); line0.setBackgroundColor(Color.WHITE)
        col.addView(line0, LinearLayout.LayoutParams(-1, dp(3)))
        bar("Uninstall this virus") {
            root.removeView(screen)
            // Android shows its own confirmation. Device-admin apps must have admin turned off first.
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + f.pkg)))
        }
        bar("Skip") { root.removeView(screen); nextThreat() }
        screen.addView(col, FrameLayout.LayoutParams(-1, -1))
        root.addView(screen)
    }
}
