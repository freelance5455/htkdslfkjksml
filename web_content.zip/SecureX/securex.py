#!/usr/bin/env python3
"""SecureX antivirus - scans a folder and can really delete or quarantine threats.
Usage:  python securex.py            (opens the window)
        python securex.py FOLDER     (scan in the terminal, asks before deleting)
"""
import os, sys, re, shutil, hashlib, time
HERE = os.path.dirname(os.path.abspath(__file__))
QUAR = os.path.join(HERE, "SecureX_Quarantine")
EICAR = "X5O!P%@AP[4\\PZX54(P^)7CC)7}$" + "EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"
BAD_HASH = {"275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f": "EICAR-Test-File"}
# Add your own known-bad SHA-256 hashes above, one per line: "hash": "Name",
RISKY = re.compile(r"\.(exe|scr|bat|cmd|com|pif|vbs|vbe|js|jse|wsf|ps1|msi|jar|apk|lnk|hta|dll)$", re.I)
DOUBLE = re.compile(r"\.(pdf|docx?|xlsx?|jpe?g|png|txt|mp3|mp4|zip)\.(exe|scr|bat|cmd|com|js|vbs|ps1|lnk)$", re.I)
PATTERNS = [(re.compile(rb"powershell(\.exe)?\s+.*-(enc|encodedcommand)\b", re.I), "Encoded PowerShell command"),
 (re.compile(rb"WScript\.Shell", re.I), "Script launches system shell"),
 (re.compile(rb"CreateRemoteThread|VirtualAllocEx|WriteProcessMemory"), "Process-injection API calls"),
 (re.compile(rb"eval\s*\(\s*(atob|unescape)\s*\(", re.I), "Obfuscated script"),
 (re.compile(rb"DownloadString|Invoke-WebRequest.*\|\s*iex", re.I), "Download-and-run pattern")]

def scan_file(path):
    """Returns (level, reasons): 0 clean, 1 suspicious, 2 threat."""
    level, why = 0, []
    name = os.path.basename(path)
    if RISKY.search(name): why.append("Executable or script file type"); level = 1
    if DOUBLE.search(name): why.append("Disguised double extension"); level = 2
    try:
        if os.path.getsize(path) <= 100 * 1048576:
            h = hashlib.sha256()
            with open(path, "rb") as f:
                head = f.read(2097152); h.update(head)
                for chunk in iter(lambda: f.read(1048576), b""): h.update(chunk)
            if h.hexdigest() in BAD_HASH: why.append("Known malware: " + BAD_HASH[h.hexdigest()]); level = 2
            if EICAR.encode() in head: why.append("Signature match: EICAR-Test-File"); level = 2
            for rx, label in PATTERNS:
                if rx.search(head): why.append(label); level = max(level, 1)
            if head[:2] == b"MZ" and not re.search(r"\.(exe|dll|scr|sys|ocx)$", name, re.I):
                why.append("Windows program hidden under another file type"); level = max(level, 1)
        else: why.append("Too large to inspect (over 100 MB)")
    except OSError as e: why.append("Could not read: %s" % e)
    return level, why

def walk(folder):
    for root, dirs, files in os.walk(folder):
        if os.path.abspath(root).startswith(QUAR): continue
        for n in files: yield os.path.join(root, n)

def delete(path): os.remove(path)
def quarantine(path):
    os.makedirs(QUAR, exist_ok=True)
    dest = os.path.join(QUAR, "%d_%s.quarantined" % (time.time(), os.path.basename(path)))
    shutil.move(path, dest); return dest

def cli(folder):
    threats = []
    for p in walk(folder):
        lv, why = scan_file(p)
        if lv: print(("THREAT     " if lv == 2 else "Suspicious ") + p + "  [" + "; ".join(why) + "]")
        if lv == 2: threats.append(p)
    print("\nScan done. %d threat(s)." % len(threats))
    for p in threats:
        a = input("\nTake Action! %s\n  [d] Delete virus from this file  [q] Quarantine  [s] Skip: " % p).strip().lower()
        if a == "d": delete(p); print("Deleted.")
        elif a == "q": print("Moved to", quarantine(p))

def checking_screen(root):
    import tkinter as tk
    w = tk.Toplevel(root); w.configure(bg="#4d88ff"); w.geometry("460x520"); w.title("SecureX")
    c = tk.Canvas(w, width=140, height=140, bg="#4d88ff", highlightthickness=0); c.pack(pady=(60, 30))
    c.create_oval(8, 8, 132, 132, fill="#0450ff", outline="#0450ff")
    c.create_line(40, 56, 62, 52, fill="white", width=4, capstyle="round")
    c.create_oval(76, 40, 106, 70, outline="white", width=4); c.create_line(100, 66, 116, 84, fill="white", width=4)
    c.create_arc(48, 96, 88, 124, start=0, extent=180, style="arc", outline="white", width=4)
    tk.Label(w, text="Checking..", font=("Courier", 26), bg="#4d88ff").pack(expand=True)
    w.update(); return w

def gui():
    import tkinter as tk
    from tkinter import filedialog, ttk
    root = tk.Tk(); root.title("SecureX"); root.geometry("620x560")
    try: logo = tk.PhotoImage(file=os.path.join(HERE, "logo.png")); tk.Label(root, image=logo).pack(pady=8)
    except Exception: pass
    tk.Label(root, text="SecureX", font=("Trebuchet MS", 22, "bold")).pack()
    status = tk.StringVar(value="Choose a folder to scan."); tk.Label(root, textvariable=status).pack(pady=4)
    box = tk.Listbox(root, height=14); box.pack(fill="both", expand=True, padx=12, pady=8)
    def alert(path, why):
        w = tk.Toplevel(root); w.configure(bg="#ff8888"); w.geometry("460x520"); w.title("SecureX"); w.grab_set()
        c = tk.Canvas(w, width=110, height=110, bg="#ff8888", highlightthickness=0); c.pack(pady=14)
        c.create_oval(5, 5, 105, 105, fill="red", outline="red"); c.create_rectangle(50, 20, 58, 62, fill="white", outline="white")
        c.create_oval(47, 72, 63, 88, fill="white", outline="white")
        tk.Label(w, text="Take Action!", font=("Courier", 26), bg="#ff8888").pack()
        tk.Label(w, text="The app/file\n%s\nhas a Trojan or malware.\n%s" % (os.path.basename(path), "; ".join(why)),
                 font=("Courier", 12), bg="#ff8888", wraplength=400).pack(pady=14, expand=True)
        def do(fn, msg):
            try: fn(path); box.insert("end", msg + path)
            except OSError as e: box.insert("end", "FAILED: %s" % e)
            w.destroy()
        for t, f, m in (("Delete virus from this file", delete, "DELETED  "), ("Uninstall this virus (quarantine)", quarantine, "QUARANTINED  ")):
            tk.Button(w, text=t, command=lambda f=f, m=m: do(f, m), bg="#ff8888", relief="flat", font=("Courier", 13), pady=14).pack(fill="x", pady=2)
        tk.Button(w, text="Skip", command=w.destroy, bg="#ff8888", relief="flat").pack(fill="x")
        w.wait_window()
    def run():
        d = filedialog.askdirectory()
        if not d: return
        box.delete(0, "end"); n = 0; found = []; ck = checking_screen(root)
        for p in walk(d):
            lv, why = scan_file(p); n += 1
            if lv: box.insert("end", ("THREAT  " if lv == 2 else "Suspicious  ") + p)
            if lv == 2: found.append((p, why))
            if n % 50 == 0: status.set("Scanned %d files..." % n); root.update()
        status.set("Scanned %d files. %d threat(s)." % (n, len(found)))
        ck.destroy()
        for p, why in found: alert(p, why)
    tk.Button(root, text="Scan a folder", command=run, padx=16, pady=8).pack(pady=8)
    root.mainloop()

if __name__ == "__main__":
    if len(sys.argv) > 1: cli(sys.argv[1])
    else:
        try: gui()
        except ImportError: print("No window support here. Run: python securex.py FOLDER")
