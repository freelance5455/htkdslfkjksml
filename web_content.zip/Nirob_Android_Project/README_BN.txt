NIROB — Android source package (early buildable project)
=======================================================

এই প্যাকেজে আছে:
- Android Studio project source (Kotlin + WebView wrapper)
- Local HTML scanner UI (app assets-এর ভিতরে; run-time-এ ওয়েবসাইট থেকে HTML লোড করে না)
- Camera permission ও WebView camera permission bridge
- Image file chooser bridge
- A4 portrait/landscape page output, local monochrome/high-contrast cleanup
- PDF ও JPG export UI; fixed watermark/footer

কিন্তু গুরুত্বপূর্ণ সীমাবদ্ধতা:
1) এটি এখনও verified APK নয়। এই পরিবেশে Android SDK/Gradle build এবং বাস্তব Android ফোনে পরীক্ষা করা হয়নি।
2) বাংলা/ইংরেজি OCR engine এবং ben/eng traineddata এই ZIP-এ নেই। ফলে ছবির লেখা শনাক্ত করে editable text বানায় না।
3) টেবিল/কলামকে আসল text/table হিসেবে reconstruct করে না।
4) logo/image background segmentation আলাদা করে নেই; বর্তমানে সম্পূর্ণ imported/captured page-কে monochrome cleanup করা হয়।
5) Camera zoom/torch/focus WebView ও hardware support অনুযায়ী সীমিত হতে পারে।

Android Studio-তে:
- এই ফোল্ডারটি project হিসেবে open করুন।
- Android SDK Platform 35 ইনস্টল থাকতে হবে।
- Gradle sync-এর জন্য ইন্টারনেট লাগতে পারে (Android Gradle Plugin ও dependencies download করতে)।
- তারপর Run/Build APK করুন এবং ফোনে camera/import/export পরীক্ষা করুন।

যা এখনো বাস্তবায়ন করতে হবে সম্পূর্ণ প্রোডাক্টের জন্য:
- Tesseract native OCR + Bengali (ben) ও English (eng) traineddata assets bundle
- OCR word/line bounding-box layout engine ও table/column reconstruction
- logo/image object segmentation/background removal
- native camera capture pipeline, autofocus, torch, zoom ও perspective correction
- generated PDF-এর text layer/accessible selectable text এবং QA

এই ফাইলটি source starter project; সম্পূর্ণ feature-complete application বা install-ready APK বলে বিবেচনা করবেন না।
