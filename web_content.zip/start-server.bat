@echo off
setlocal
echo AlarmSimulator Ukraine - TEST SERVER
echo Enter a private admin token (at least 24 characters).
set /p ADMIN_TOKEN=ADMIN_TOKEN: 
if "%ADMIN_TOKEN%"=="" (echo Token is required.& pause & exit /b 1)
node -e "if((process.env.ADMIN_TOKEN||'').length<24)process.exit(1)"
if errorlevel 1 (echo Token must be at least 24 characters.& pause & exit /b 1)
echo Starting server... keep this window open.
node server.js
pause
