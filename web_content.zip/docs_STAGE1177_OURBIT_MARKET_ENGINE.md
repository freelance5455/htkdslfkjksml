# CryptoPulse Stage 1177 — Ourbit Market Engine

Ourbit is now the primary public market-data source.

- Spot: api.ourbit.com/api/v3/ticker/24hr, /ticker/price, /klines, /depth.
- Futures: contract.ourbit.com/api/v1/contract/ticker, /depth_commits, /kline.
- Trade chart requests Ourbit first.
- Futures browser market/orderbook/history requests Ourbit first.
- Native Android missing-symbol ticker requests Ourbit first.
- LBank remains fallback for compatibility; no fake market data is generated.
