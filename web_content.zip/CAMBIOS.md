# Cambios (PWA, no Godot: el proyecto es un único index.html en JS)
## Hecho
- Banner mixto de invocación: 8 personajes + 7 compañeros nuevos (SUP). 40 ✦, 60/28/10/2 (suman 100), garantía a 10 (guardada en M.pity). Reparto personaje/compañero dentro de cada rareza configurable en BAL.CAT_W (60/40) sin alterar las rarezas.
- Compañeros de apoyo equipables (M.comp), datos separados de la lógica; reutilizan las habilidades existentes (órbitas, torreta, caparazón…).
- Sinergias por datos (SYN: afinidad del personaje + etiqueta del compañero). Un compañero rinde distinto según el personaje.
- Estrellas: ★3 +1 rango de la habilidad inicial, ★5 sinergias ×2 (compañero) / +1 relanzamiento (personaje). Bonus de stats de personaje 4%→3% por ★.
- Quitada la evolución por nombres de criatura (ahora fases Latente→Resonante→Ascendido→Singular). Renombrados personajes y afinidades. Fusiones (antes "Evolución") renombradas.
- Guardado 'pocket2' compatible (campo nuevo M.comp). Cache del service worker mp3→mp4.
## Conservado
Combate, oleadas, jefes, mejoras permanentes, ajustes, controles táctiles, PWA.
## Ronda 2
- Sprites nuevos (código, sin reutilizar los antiguos): llama errante, brea, arco, escombros, vórtice, encapuchado del vacío, esquirla y singularidad (jefe). Héroe Hifa rediseñada (encapuchada con micelio que crece por fase). Paletas oscuras. Jefe renombrado "La Singularidad".
- Sinergia de combate "marca y detonación": compañeros orbitales (Esquirla orbital, Faro anómalo) marcan; cualquier otro ataque consume la marca y causa una explosión pequeña (sin recursión, daño acotado; ★5 la refuerza).
- Caché del service worker: mp5. Prueba de humo de sprites con canvas simulado.
## Ronda 3 (sprites y efectos)
- Enemigos con sprites de Pixel Fantasy Monsters (Laphkal); jefes alternos: Verdugo (orco) y Minotauro (RetroLabStudioCo). 3 enemigos nuevos (trasgo, esqueleto, araña).
- Efectos de magia SpritePilot (CC0): bolas de fuego, esquirlas de hielo y orbes de energía como proyectiles (rotan según su dirección), burbuja de escudo y aura de curación.
- Héroes animados con 4 direcciones (idle/andar/ataque/daño): Hifa usa el mago, Escoria el caballero. El resto de personajes sigue en dibujo vectorial.
- Caché mp7 con los 51 recursos. Créditos en CREDITOS.md.
## Ronda 4 (dificultad)
- Selector de dificultad en el menú: Normal ×1, Difícil ×2, Pesadilla ×5, Colapso ×10 (por defecto, también en guardados antiguos). El índice es el producto de presión de oleadas × vida × daño × velocidad, no una medida literal.
- Más presión (más enemigos a la vez, hasta 110), escalado como si fueran más oleadas, más élites, cercos más frecuentes, tiradores con ráfaga triple y más cadencia, jefes con ritmo de ataque más rápido y refuerzos durante la pelea. La esencia ganada sube (×1 a ×3) para no frenar el gacha.
## Ronda 5 (patrones de enemigos)
- Perseguidores (oleada 3+): salto con telegráfico de línea. Tiradores (oleada 4+): cada 3er disparo es un bombardeo de 3 círculos. Cargadores: doble embestida. Emboscadores: tras teletransportarse disparan un abanico (oleada 5+). Bombarderos: la explosión suelta 6 esquirlas (oleada 7+).
- Esqueleto pasa a "bruiser": golpe en cono con telegráfico. Nuevo enemigo de apoyo "Limo" (oleada 4): cura 22% a los aliados cercanos y los acelera; matarlo primero corta la cura.
- Mecanismo reutilizable: los telegráficos aceptan una función `fn` que se ejecuta al disparar.
## Pendiente (honesto)
- Arte: siluetas nuevas pero sin revisar en pantalla real; faltan mecánicas únicas por jefe y por élite, y variar más a los enemigos.
- Solo hay una sinergia de combate (marca/detonación); el resto son bonus de partida.
- Sin balance medido en partida; sin prueba en navegador. Un solo hueco de compañero.
- El juego no tenía captura ni bestiario; no había nada que quitar de eso.

## Ronda 6 (escenarios) — alcance real
- HECHO: sistema de fondos procedural `bgDraw` integrado en `draw()` (sustituye la cuadrícula plana). 5 biomas que rotan cada 3 oleadas: Bosque corrompido, Ruinas antiguas, Cementerio, Caverna cristalina, Templo de la anomalía. Capas: suelo con baldosas, decoración sin colisión (árboles, pilares, tumbas, cristales, runas animadas), niebla en movimiento, partículas con parallax, luz aditiva que reacciona a las habilidades (`fx`), tinte rojo pulsante durante jefes, transición de color y rótulo del bioma. Cámara cenital y movimiento intactos.
- NO HECHO (pendiente): sprites nuevos por habilidad, rediseño mecánico de habilidades, nuevos nombres/habilidades de personajes y ayudantes, retratos, interfaz de cooldowns, barra de jefe, sprites de ayudantes. No se tocó el gacha.
- Pruebas: `node tests.js` 64 ok; `bgDraw` ejecutado con un canvas simulado (oleadas 1–13, con y sin jefe) sin errores. NO probado en navegador real ni en Android: el aspecto y el rendimiento reales siguen sin verificar.
## Ronda 7 (habilidades y jefe)
- CORREGIDO: la barra del jefe mostraba "GRAN DRAGONCITO". Ahora usa el nombre real del jefe (`nm`: EL MINOTAURO / EL VERDUGO), el mismo que el aviso de aparición.
- 5 habilidades nuevas (en el selector de mejoras, el libro y el HUD): Charco de brasas (zona ardiente 3–7 s, máx. 4), Runa detonante (sello con retraso de 0,9 s; ×1,3 a ralentizados/congelados), Corte umbrío (tajo en línea que atraviesa), Relámpago errante (rebota entre enemigos; ×1,5 a mojados; −15% por salto), Égida reactiva (al recibir un golpe lanza una onda de choque, con reutilización).
- Cada una tiene efecto visual propio dibujado por código (zona de llamas, runa giratoria, tajo, rayo en zigzag, onda). Sin sprites nuevos de imagen.
- Pruebas: `node tests.js` 64 ok; arnés simulado de `newSk` (200 ticks, las 5 activas) sin errores. NO probado en navegador ni balanceado en partida. Caché mp11.
## Ronda 8 (oleada 20)
- Desde la oleada REAL 20 (no la "efectiva" de dificultad) el mapa cambia a un bioma nuevo, "Campo de guerra orco" (suelo ocre oscuro, estandartes, estacas y cráneos, brasas y niebla rojiza), con aviso "¡LLEGAN LAS HORDAS ORCAS!". Antes de la 20 los biomas siguen rotando cada 3 oleadas.
- 3 criaturas nuevas con los sprites de CraftPix (assets/orcs/, 4 direcciones, caminar 6 fotogramas y ataque 8): Saqueador (perseguidor con salto), Capitán de guerra (bruiser con golpe en cono, mucha vida) y Acechador (emboscador que se teletransporta y dispara abanico). Tienen su fila en ARC con min. oleada 999: nunca salen por el sorteo normal; el director las genera con 40% de probabilidad desde la oleada 20. Usan los patrones de ataque existentes de su rol.
- Pruebas: `node tests.js` 137 ok (incluye que pick() nunca devuelva orcos y que existan los 6 PNG). Orientación/anclaje del sprite comprobados con canvas simulado. NO probado en navegador: tamaño visual y balance sin verificar. Caché mp12.
- Licencia: el pack CraftPix solo trae un enlace a craftpix.net/file-licenses; revisa sus condiciones. Atribución en CREDITOS.md.
## Ronda 9 (colisión y disparos, parcial)
- CORREGIDO: el efecto visual del Corte umbrío era un cono mucho más ancho que su zona real de daño (parecía golpear lo que no golpeaba). Ahora se dibuja el rectángulo exacto que daña (largo y ancho reales).
- CORREGIDO: los disparos principales vivían 364 px de alcance pero apuntaban a enemigos hasta 380 px; ahora viven 420 px, así que ya no caducan antes de llegar al objetivo más lejano.
- SIN CONFIRMAR: no se pudo reproducir nada más sin ver el juego. Hipótesis pendientes: los enemigos no se empujan entre sí (se apilan) y el jugador no choca con ellos (solo recibe daño por contacto); no hay obstáculos en el mapa. Pruebas: tests.js y simulación del tajo. Caché mp13.

## Ronda 10 (avance, a petición)
- **Oleadas más cortas:** 30 s → 20 s (`WT`). La fase de respiro del director pasa de 22 s a 14 s de rampa (6 s de calma al final de cada oleada). Efecto colateral: todo llega antes (el mapa orco, a los ~6 min 20 s).
- **Jefes:** hasta la oleada 5 sigue habiendo un jefe cada 60 s. Desde la oleada 6, cada oleada trae **2 jefes + 4 mini-jefes** (mini = 30% de vida, más rápidos, sin fases). **Vida de todos los jefes +25%.** Tope de 12 jefes vivos para no saturar. Solo los jefes (no los minis) dan botín de mejora y esencia completa; los minis dan 2 ✦ y una fruta.
- **Aturdimiento:** cualquier golpe de jefe (contacto, embestida, círculos, proyectiles) aturde 0,6 s (mini 0,35 s). Mientras dura no te mueves. Tras aturdirte tienes 2,5 s de inmunidad al aturdimiento para que no te encadenen. Si el escudo absorbe todo el golpe no aturde.
- **Empuje con colisión:** `push()` (Ráfaga) ahora arrastra al enemigo contra los de atrás: el golpeado hace daño de colisión y transmite el empuje en cadena (hasta 3 saltos, −40% cada uno). Los jefes resisten (×0,25). Además, los enemigos ya no se apilan (`sepEn`: separación entre sí y no entran en el jugador).
- **Movimientos nuevos de jefe:** Barrido (círculo alrededor del jefe que daña y empuja 100 px), Aplastamiento (salta sobre el círculo avisado, daña y empuja 70 px) y Grito de guerra (invoca 2–5 refuerzos). Todos con aviso ≥ 0,9 s.
- **Cambio de mapa (oleada real 20):** se eliminan los enemigos del primer conjunto que había en pantalla (los jefes y orcos se conservan) y desde ahí **solo salen orcos** (antes 40%). El cerco, los refuerzos de jefe y los invocadores también usan orcos.
- Se corrigió además un fallo propio detectado por las pruebas: refuerzos del jefe que se saltaban el límite de enemigos (ahora tope = cap + 25).
- Pruebas: `node tests.js` (137 ok, una actualizada por el cambio de 40% a 100%) y `node tests_ronda10.js` (18 ok, motor real con DOM simulado). **No probado en navegador ni en Android; el balance de 2 jefes + 4 minis por oleada no está medido.**
- Caché del service worker: mp14.

## Ronda 11 (enemigos y jefes con sprites nuevos)
- **4 enemigos nuevos del conjunto orco** (Tiny RPG, vista lateral, andar 8 f / ataque 6–8 f, se voltean a izquierda/derecha): **Soldado** (tirador; sus disparos son flechas con sprite que rotan), **Orco de asedio** (tanque, 80 de vida, golpe en círculo), **Bestia sangrienta** (embestida doble con polvo) y **Demonio** (bombardero: explosión con anillo morado y 6 esquirlas). Reutilizan los patrones de su rol; no salen del sorteo normal (ola mín. 999).
- **Aparición escalonada** (`orcPick`, ponderada): Saqueador/Capitán/Acechador/Soldado desde la oleada 20, Bestia sangrienta 21, Demonio 22, Orco de asedio 23. Pesos y oleadas en `ORCW`. Cerco, refuerzos y jefes usan el mismo sorteo.
- **2 jefes nuevos**: **La Bestia Sangrienta** (en fase 2+ sus embestidas se repiten 2 veces) y **El Demonio Abisal** (en fase 2+ cada ataque termina con 8 proyectiles radiales). Rotan por nivel de jefe: Verdugo, Bestia, Demonio, Minotauro (`KB`). Los mini-jefes usan los mismos sprites. Ojo: antes los niveles pares eran Minotauro y los impares Verdugo; ahora el orden es el de arriba.
- **Efectos de sprite** (`vfx`, máx. 60 a la vez): anillo de impacto en golpes en círculo/cono de orcos y jefes (morado para demonio/bestia), chispas al morir, polvo en la embestida, anillo grande al cambiar de fase de jefe.
- Pruebas: `node tests.js` 153 ok, `node tests_ronda10.js` 18 ok, `node tests_ronda11.js` 27 ok (motor real con DOM simulado). **No probado en navegador ni Android**: tamaño en pantalla, colocación de los pies del sprite y balance (vida/daño de los 4 enemigos y 2 jefes) sin verificar. Caché mp15. Licencias de estos packs: ver CREDITOS.md.

## Ronda 12 (habilidades nuevas y animación de sprites)
- **4 habilidades nuevas** (en selector, libro y HUD), todas con animación de sprite del pack Effect and FX Pixel desde el primer fotograma:
  - **Lluvia de meteoros** (fuego, rango 4, Nv 5): 1+⌈r/2⌉ meteoros caen sobre enemigos cercanos tras un aviso; daño en área, incendian. Anillo + estallido al caer.
  - **Torbellino** (aire, rango 3, Nv 4): vórtice con sprite de remolino que atrae a los enemigos (jefes ×0,25) y los daña; máx. 2 a la vez.
  - **Nova glacial** (hielo, rango 3, Nv 4): onda alrededor de ti que congela; los jefes solo se ralentizan. Combina con Sismo (×1,5 a congelados) y Runa (×1,3 a ralentizados).
  - **Zarzal** (planta, rango 4, Nv 3): espinas animadas que dañan y ralentizan; máx. 3 zonas.
- **Las 5 de la ronda 7 ahora usan sprites** además de las formas de antes: Charco de brasas (llamas animadas), Runa detonante (sello giratorio + anillo y estallido morados), Corte umbrío (media luna con la zona exacta de daño debajo), Relámpago errante (rayo de sprite por tramo + chispas en cada impacto), Égida reactiva (onda de choque de sprite).
- **Equilibrio medido** (no estimado): simulación de 40 s con 8 maniquíes inmóviles, solo la habilidad. DPS a rango 3 — antiguas: 35 / 42 / 49 / 72 (Runa / Corte / Brasero / Relámpago); nuevas: Meteoros 44, Torbellino 53, Nova 47, Zarzal 47. Nova bajó de D(10+6r) a D(6+4r) porque daba 61 (más que casi todas) además de congelar. La prueba exige que cada nueva quede entre 0,5× y 1,6× la mediana de las antiguas y que el DPS crezca con el rango. Es DPS en área contra 8 objetivos, no contra uno solo ni contra oleadas reales.
- `node tests_ronda12.js`: 13 ok (efectos, congelación, atracción, ralentización, que cada zona dibuje sprites, equilibrio, 120 s dibujando con todo al máximo). Suite completa: 153 + 18 + 27 + 13. **Sin probar en navegador ni Android**: orientación y tamaño de los sprites (rayo, media luna) y rendimiento reales sin verificar. Caché mp16.

## Ronda 13 (equilibrio, límite de habilidades, sin ventaja de tipo, sprites)
- **Sin ventaja por tipos:** eliminada la tabla de debilidades (+60% / −40%). El daño depende solo de la habilidad. Se conservan los combos de ESTADO descritos en las habilidades (mojado+eléctrico ×1,5, congelado+Sismo ×1,5, ralentizado+Runa ×1,3), el blindaje de élites y la vulnerabilidad de jefes. `hurt()` ya no daña a enemigos con vida ≤0 (evita daño/textos fantasma sobre cadáveres) y el aviso «!» solo sale por combos reales.
- **Máximo 10 habilidades por partida** (`BAL.MAX_SK`). No cuentan: la Semilla (disparo básico), los rangos extra ni las fusiones. Sí cuentan las iniciales del personaje y del compañero. Con 10 llenas solo se ofrecen subidas de rango y fusiones; si no queda nada que ofrecer, se cura 30% y se sigue (sin pantalla vacía). Contador en la pantalla de mejora («NUEVA 7/10», «FUSIÓN») y en el HUD. Las habilidades que ya tienes se pueden mejorar aunque aún no alcances su nivel mínimo.
- **Rebalanceo medido** (DPS vs maniquíes inmóviles, 30 s, 2 semillas; S = un enemigo, P = 8 enemigos pegados). Valores al rango máximo, antes → después:
  Brasa S 10→24 · Chispa P 26→36 (prob. y daño de cadena) · Ráfaga S 5→43, P 51→203 (ahora apunta: 1 cuchilla al enemigo + 2 gemelas + anillo; ya no dispara sin objetivo) · Eclipse crítico 8%→10%/rango, ×3 · Aliento dragón S 25→73 (era el más flojo siendo legendaria) · Charco S 44→35 · Runa S 19→34 · Corte S 28→41 · Relámpago S 19→34 · Meteoros S 11→44 (ya no se limitan al nº de enemigos) · Géiser P 217→88 · Sismo S 7→12, P 58→98 · Torbellino P 80→59 · Nova P 24→51 · Cápsula P 337→161 · Guardián S 18→30 · Floración cura 4/rango con menos espera · Escarcha: la congelación crece con el rango.
  Bandas objetivo (en `tests_ronda13.js`): daño > control; legendaria > épica > rara > común; el DPS crece con cada rango.
- **Sprites nuevos** (del pack Effect and FX Pixel + orbes recoloreados de SpritePilot): orbes de disparo por elemento (planta, agua, aire, tierra, sombra, dragón, eléctrico), cuchillas de viento (Ráfaga), aliento de fuego (Dragón), géiser, roca (Sismo), pinchos de hielo/brote, estallidos de crítico y halos de mejora. Estados de enemigo con sprite: quemado, mojado, congelado, marcado. Orbes de Cápsula y torreta del Guardián con sprite; arcos de Chispa/Tormenta con rayo animado; estela, caparazón, floración, burbuja y todas las mejoras pasivas (corazón, pasos, imán) con efecto.
- **Animaciones ajustadas** al área real de daño (runa, torbellino, nova, meteoros, aliento) y comprobadas en Chromium con capturas.
- Pruebas: tests.js 153 · ronda10 18 · ronda11 27 · ronda12 11 · **ronda13 74**. Caché mp17. Sin probar en móvil real.

## Ronda 14 (fusión: rama con sprites + correcciones de reparación)
- Base: la rama con sin-tipos, límite de 10 habilidades, rebalanceo y sprites (ronda 13). Portadas las correcciones de la reparación, que esa rama no tenía:
  `nodrop` respetado en el cambio de mapa (ola 20); la ralentización afecta a los jefes (`K.bossSlow`); nivel máximo `K.lvMax`=99 y XP saneada; `pick()` solo acepta lo ofrecido y sin superar el rango máximo; guardado validado (`sane()`); `die()` una sola vez y esencia acotada; recompensa de jefe acotada (`BAL.bossEss`).
- No se portaron los multiplicadores de balance de la reparación (`SKM`/`SKB`): la rama con sprites ya rebalancea cada habilidad y se habrían aplicado dos veces.
- Pruebas: tests.js 153 · ronda10 18 · ronda11 27 · ronda12 11 · ronda13 74 · **tests_reparacion.js 18** (7 de ellas fallan sin las correcciones). Caché mp18 (92 recursos). Sin probar en móvil real.

## Rediseño de la selección de habilidades (pantalla de subida de nivel)
- Nuevo aspecto basado en la referencia de tienda: cinta morada con el nivel, fondo con greca, tarjetas con marco naranja ornamentado, icono en rombo con el color de la rareza, píldora de rango (casillas llenas = rango actual, parpadeante = el siguiente; "NUEVA n/10" o "FUSIÓN"), nombre en dorado, "Efecto:" y botón de acción (APRENDER / MEJORAR / FUSIONAR). Las fusiones usan marco rosa. El relanzamiento es un botón del mismo estilo.
- Responsive: en vertical las tarjetas se apilan (icono a la izquierda); desde 600 px de ancho van en 3 columnas como en la referencia; compacto en móvil horizontal.
- Solo cambia la presentación (CSS + generación de tarjetas en `lvlUp()`); la lógica (`offerList`, `pick`, relanzar, huecos) no se tocó. Tarjetas accesibles con teclado (Enter/Espacio). Sin dependencias ni fuentes externas (sigue funcionando sin conexión).
- Pruebas: todas las suites existentes pasan (153 + 18 + 18 + 27 + 11 + 74). Revisado en Chromium a 390×844, 360×640, 844×390 y 1024×768 sin errores de consola. No probado en un Android real.

## Menú principal nuevo
- Mismo lenguaje visual que la selección de habilidades: cinta morada con el logo, fondo de greca, contadores en píldora (✦ Esencia, 🏆 Mejor oleada).
- Mejoras permanentes como 3 tarjetas con rombo de icono (⚔️ ❤️ 👟), 10 casillas de rango y botón con el coste (gris si no alcanza la esencia; "MÁXIMO" en dorado).
- Botón grande ENTRAR AL BROTE con brillo pulsante (se desactiva con "reducir movimiento"); debajo, paneles: Invocar·Ruleta (muestra personaje + apoyo), Libro, Ajustes y Dificultad.
- Se conservaron los ids y la lógica (`menu()`, compra de mejoras, dificultad, ruleta); cambió solo el HTML/CSS del menú y cómo se pinta. Pruebas: las 6 suites pasan. Revisado en Chromium 390×844, 360×640 y 844×390; en pantallas bajas se desplaza.

## Gacha (invocación) mejorado
- Rueda: marco de bronce con luces que giran más rápido durante la tirada, segmentos oscuros teñidos por rareza, puntero dorado, buje con gema y destello dorado al terminar. La lógica de giro y probabilidades no cambió.
- Revelación del premio: tarjeta con icono en rombo del color de la rareza, "¡NUEVO PERSONAJE/COMPAÑERO!", "REPETIDO · ★n" o "AL MÁXIMO", y el efecto del repetido (★3 mejora de habilidad, ★5 sinergias, +3% vida y daño, reembolso). Épico o mejor brilla en pulso.
- Barra de garantía (progreso hacia el Épico asegurado), botón INVOCAR grande (se pone gris con "FALTAN n ✦"), barra de probabilidades por colores y las reglas largas plegadas en "Reglas de la invocación".
- Colección en tarjetas de 2 columnas: rombo de rareza, ★ de 1 a 5, descripción, insignias ACTIVO / EQUIPADO, bloqueadas con "?" y contador 2/9, 1/7. Tocar equipa igual que antes.
- Nuevo estado `rRes` (último premio); no se guarda. Pruebas: las 6 suites pasan. Revisado en Chromium (giro completo y resultado) a 390×844 y 844×390 sin errores. No probado en Android real.

## Ronda 15 (sprites Tiny Hero)
- Nuevos sprites jugables del pack Free Pixel Art Tiny Hero Sprites: **Pink Monster → Ceniciento**, **Owlet Monster → Vórtice**, **Dude Monster → Arco roto**. Hasta ahora solo Hifa y Escoria usaban sprite; el resto se dibujaba con formas de código (sigue siendo el respaldo para los demás).
- Animaciones: reposo (4 fotogramas), caminar (6), ataque (hoja Attack2, 6) y herido (4). Son de vista lateral: izquierda = volteo horizontal; arriba/abajo mantienen el último lado. El número de fotogramas sale del ancho de la hoja.
- Cambios: `HMAP`, `HS` y `heroS()` en index.html; 12 PNG en assets/heroes/; caché mp19. Pruebas: las 6 suites pasan. **No probado en navegador ni Android**: tamaño y posición respecto a la sombra sin verificar visualmente.

## Ronda 16 (ruleta: 100 ✦, ×10 tiros, Hueco legendario)
- **Precio del giro: 40 → 100 ✦** (`BAL.SPIN_COST`). Las probabilidades por rareza no cambian (60/28/10/2).
- **Botón ×10 TIROS** junto a INVOCAR: cuesta 10 × 100 = 1000 ✦ (sin descuento) y hace 10 giros seguidos con las mismas probabilidades. La garantía de Épico o mejor cuenta cada giro, así que cada tanda de 10 incluye al menos uno. Los premios se conceden y se guardan al pulsar (no se pierden si sales durante la animación). La rueda gira ~2,6 s hacia el mejor premio y luego aparece una cuadrícula de 10 con NUEVO / ★n / MÁX y el resumen «n nuevos · m repetidos · +x ✦». Con ★5, cada repetido devuelve 20 ✦ como en el giro simple. Constante `BAL.MULTI`=10.
- **Hueco (Eclipse) pasa de Épico a Legendario** (`r:3`). Ahora el grupo Legendario es Singular + Hueco, y el Épico solo tiene a Vórtice entre los personajes. Solo cambia la rareza (probabilidad de salir, color y etiqueta); sus estadísticas y su habilidad Eclipse no se tocaron.
- Pruebas: las 6 suites anteriores pasan; nueva `tests_ronda16.js` con 9 (precio, rareza, probabilidades, ×10 con y sin esencia, garantía en 300 tandas, reembolsos, interfaz). Caché mp20. Revisado en Chromium a 390×844 sin errores de consola; no probado en Android real.

## Ronda 17a (Grimorio arcano: habilidades exclusivas del gacha)
- **Nuevo gacha «Grimorio arcano»** (botón en el refugio, junto a la ruleta): 150 ✦ por tirada, ×10 = 1500 ✦. Reutiliza la esencia; sin pagos.
- **12 habilidades arcanas que SOLO se consiguen aquí** (no existen en `SK`, no salen al subir de nivel ni en botines de jefe; un guardado manipulado no puede equiparlas). Se equipan hasta 2 antes de entrar al brote.
- **Probabilidad exponencial en la calidad:** Común 76,7 % · Rara 18,1 % · Épica 4,2 % · **Legendaria 1 %** (cada rareza ≈ 4,2× más rara). Dentro de cada rareza todas son equiprobables (3 por rareza).
- **Poder exponencial:** daño ×2,5 por rareza y ×1,25 por ★ (repetidas ★1–5). Una Legendaria ★0 = ×15,6 sobre una Común; Legendaria ★5 = ×47,7. Con ★5, repetir devuelve 30/60/120/240 ✦ según rareza.
- **Garantías** (constantes en `BAL`, ponlas a 0 para quitarlas): Legendaria como máximo en la tirada 100; Épica o mejor en la 20. Por tanto la tasa efectiva con garantía es algo mayor que el 1 % base.
- **Habilidades:** Común — Dardos buscadores, Aro de cuchillas, Pulso sónico · Rara — Tempestad arcana, Agujero negro, Aura solar · Épica — Lluvia estelar, Lanza del alba, Pacto de sangre · Legendaria — Fénix eterno (renace 1 vez; 2 con ★5), Tiempo detenido (congela todo), Juicio final (columna de luz sobre todos los enemigos cercanos).
- **Efectos:** 13 hojas nuevas de Effect and FX Pixel (assets/fx/fx_void, skull, rays, lotus, galaxy, hex, ringfrag, nova, star, pulse, zig, beam, sun) para las habilidades y para la animación del gacha (cada rareza tiene su estallido; la Legendaria el mayor). Las arcanas equipadas aparecen abajo a la derecha en combate, con barra de recarga.
- Libro: nueva sección «Habilidades arcanas». Guardado: `M.ar` (colección, equipadas, contadores de garantía) saneado en `sane()`.
- Pruebas: las 7 suites anteriores siguen pasando (con caché mp21) + nueva `tests_ronda17.js` (32: probabilidades por simulación de 400 000 tiradas, exponencialidad, exclusividad, garantías, guardado, cada habilidad en combate a ★0 y ★5, Fénix, Tiempo, Juicio, interfaz). Revisado en Chromium a 390×844 sin errores de consola. No probado en Android real.

## Ronda 17b (sprites animados para los 4 personajes que faltaban)
- **Qué faltaba:** solo 5 de los 9 personajes jugables tenían sprite animado (Hifa, Escoria, Ceniciento, Vórtice, Arco roto). **Brea viva (`gotin`), Prisma (`cristalin`), Hueco (`umbrio`) y Singular (`dragon`)** se dibujaban con formas de código y no tenían animaciones. Ahora los 9 tienen sprite; el dibujo por código sigue siendo el respaldo si una imagen no carga.
- **Nuevos recursos (16 PNG, 32×32 por fotograma, vista lateral mirando a la derecha; izquierda = volteo horizontal):** `<id>_idle` (4 fotogramas), `_walk` (6), `_attack` (6) y `_hurt` (4, con destello blanco). Mismo formato que Pink/Owlet/Dude, así que `heroS()` los usa sin cambios de lógica.
  - **Brea viva:** gota de alquitrán con brillo y burbujas; salto elástico al caminar, escupe gotas al atacar.
  - **Prisma:** gólem de cristal con esquirlas orbitando; lanza un pincho de hielo al atacar.
  - **Hueco:** figura encapuchada con ojos rosados y dobladillo ondulante; extiende el brazo y crea una esfera de vacío.
  - **Singular:** dragoncito violeta/dorado con ala, cola enroscada y cuernos; lanza aliento de fuego.
  - Colores tomados de la paleta de afinidad de cada uno (`EL[...]`). Son **arte original generado por código** (`tools/gen_heroes.py`, determinista, requiere Pillow): no hay licencia de terceros asociada.
- **Cambios en código:** `HMAP` (4 entradas nuevas) y la lista de hojas laterales de `HS` en `index.html`; 16 PNG añadidos a `sw.js`; caché **mp21**. No cambian ids, claves de guardado, estadísticas, habilidades ni rarezas.
- **Pruebas:** nueva `tests_ronda17.js` (31): existencia y dimensiones de las 16 hojas, caché, fotogramas no vacíos ni recortados, animación real (los fotogramas cambian), destello de daño, `HMAP` completo (9/9), `heroS` en las 4 animaciones y con imágenes sin cargar, 60 s de partida con los 9 personajes. Esta prueba detectó recortes reales en mis primeros sprites (burbujas y capuchas tocaban el borde) y se corrigieron en el generador. Se modificaron 2 pruebas existentes (`tests_ronda13`, `tests_ronda16`): fijaban literalmente «mp20» y ahora aceptan mp20 o posterior, porque la versión de caché tiene que subir al añadir archivos.
- **Resultado:** tests.js 153 · reparación 18 · ronda10 18 · ronda11 27 · ronda12 11 · ronda13 74 · ronda16 9 · **ronda17 31** = 341, todas correctas. Revisado en Chromium 390×844 (DPR 3): hojas cargadas con el ancho esperado, 0 errores de consola, 0 respuestas HTTP erróneas y capturas de los 4 en reposo/caminar/ataque/herido. **No probado en Android real.**
- **Pendiente (no hecho):** los 7 compañeros de apoyo siguen representados por iconos/efectos, sin sprite propio; no se añadieron animaciones nuevas de muerte o de subida de nivel; Hifa y Escoria conservan sus hojas de 4 direcciones.

## Rama «supervivencia»: Ronda 14 — Supervivencia táctica (2026-10-28)
- Se añadió una esquiva manual con botón táctil, compatible con teclado (Espacio/Shift). Tiene una breve ventana de invulnerabilidad, desplazamiento rápido, daño de paso limitado a un impacto por enemigo y recarga de 3,6 s.
- Se añadió una racha de derribos: los derribos consecutivos dentro de 4 s elevan el daño hasta un máximo de +12%; la racha expira si se deja de derrotar enemigos. El HUD comunica la racha sin llenar la pantalla de efectos.
- Se muestra el tiempo de recarga en el botón de esquiva y solo aparece durante la expedición.
- Se actualizó la caché de la PWA a mp19 para que el navegador no conserve la versión anterior.
- Pruebas: suites anteriores y pruebas específicas de esquiva/racha.

## Rama «supervivencia»: Ronda 15 — Oleadas temáticas y jefes (2026-10-28)
- **Oleadas temáticas rotativas.** Cada oleada usa un grupo de enemigos afines (`BAL.THEMES`). Antes de la 20: 🦇 Plaga de la cueva (murciélagos, arañas), 👹 Legión infernal (imps, acólitos, espectros), 🐺 Tribu salvaje (trasgos, lobos, gólems), 💀 Marcha de los muertos (esqueletos, acólitos, espectros), 🍄 Ciénaga fúngica (limos, hongos, arañas, gólems; desde la 5). Desde la 20 (mapa orco): 🪓 Vanguardia orca, 🩸 Cacería sangrienta, 😈 Artillería abisal. Los temas salen en bolsa barajada: todos antes de repetir y nunca el mismo dos oleadas seguidas. El nombre aparece en el aviso de oleada y en el HUD. El cerco usa el enemigo básico del tema.
- **Jefes antes de la 20 reducidos** (de ~90 a 13 en total): jefe principal en las oleadas 5, 10, 15 y 20; mini-jefes en la 8 (2), 13 (2), 18 (3) y 20 (2). Tabla en `BOSS_EARLY`. Desde la 21 se mantienen 2 jefes + 4 mini-jefes por oleada (`BOSS_LATE`).
- **Bug corregido:** `waveBosses()` salía sin invocar nada si ya había 12 jefes vivos, y los jefes se acumulan si no se derrotan, así que no aparecían más. Ahora los jefes principales siempre aparecen: se retiran (sin botín) los mini-jefes más antiguos y, si hace falta, el jefe más antiguo, manteniendo el total ≤ 12. Los mini-jefes solo ocupan huecos libres.
- Se eliminó el jefe por minuto de las oleadas 1-5 (sustituido por el de la oleada 5).
- Pruebas: `tests_ronda15.js` (8) y actualizadas las que asumían jefes desde la oleada 6. Caché mp20. No probado en móvil real; el balance de las nuevas oleadas está sin jugar.

## Rama «supervivencia»: Ronda 16 — Daño tras la oleada 30 y etapas de 10 oleadas (2026-10-28)
- **Daño de enemigos** (`BAL.dmm`): antes quedaba plano en ×2,2 desde la oleada 21 mientras su vida seguía creciendo. Ahora: igual hasta la 21; +3%/oleada hasta la 30 (×2,47); +5%/oleada desde la 30, con tope ×4 (~ola 61). Se calcula con la oleada efectiva (`ew()`, incluye la rampa de dificultad), como el resto de escalados.
- **Daño de jefes** (`BAL.bossDm`): el daño base (18; mini 12) no escalaba con la oleada. Desde la 31 sube +3%/oleada hasta ×2.
- **Tope por golpe** (`BAL.hitCap`): desde la oleada 30 un solo golpe no quita más del 40% de la vida máxima, para que el escalado no cause muertes de un toque con la vida del personaje casi fija.
- **Etapas cada 10 oleadas** (`BAL.ERAS`): en las oleadas 10, 20, 30 y 40 cambia el conjunto de temas; dentro de cada etapa siguen rotando por oleada. Etapas: 0-9 Las cuevas (cueva, infierno, tribu) · 10-19 Cripta y ciénaga (muertos, ciénaga, infierno) · 20-29 La invasión orca (vanguardia, cacería) · 30-39 El asedio (artillería, asedio orco) · 40-49 El abismo (rito abisal, guardia de hierro) · desde la 50 se repiten las etapas 3-5. 3 temas orcos nuevos: Asedio orco, Rito abisal, Guardia de hierro. Aviso «¡NUEVA ETAPA!» con el nombre.
- Pruebas: `tests_ronda16.js` (8). Caché mp21. Sin jugar en móvil real: las cifras de daño están calculadas, no probadas con un build real del jugador.

## Rama «supervivencia»: Ronda 17 — Fondos por etapa (2026-10-28)
- Los fondos ahora van ligados a las **etapas de 10 oleadas** (`BAL.eraOf`), no a los 6 biomas de 3 oleadas. Cada etapa tiene paleta saturada, suelo propio, decorados con brillo, capa ambiental, partículas y viñeta de color:
  - **Las cuevas** (0-9): azul profundo, cristales y hongos luminosos, haces de luz, motas flotantes.
  - **Cripta y ciénaga** (10-19): verde tóxico, charcos con ondas, lápidas con fantasmas, juncos, bruma y burbujas.
  - **La invasión orca** (20-29): tierra quemada con grietas de lava pulsantes, estandartes y estacas con cráneo, humo y brasas.
  - **El asedio** (30-39): piedra azul con ladrillos, braseros con llama animada, ruinas, lluvia y relámpago tenue.
  - **El abismo** (40-49): vacío púrpura con anillos rúnicos giratorios, obeliscos, remolino central y estrellas titilantes. Desde la 50 se repiten las etapas 3-5.
- Destello de color al cambiar de etapa (desactivado con `prefers-reduced-motion`, igual que el relámpago). Se retiró el rótulo antiguo del bioma y el aviso duplicado de las hordas orcas (el aviso de etapa ya lo muestra).
- Revisado en Chromium a 390×700 con una captura por etapa y sin errores de consola. Sin probar en Android real (rendimiento de los degradados y trazos).

## Ronda 18 — Fusión de las tres ramas en un solo código
Se unieron en `index.html` (sin perder nada de ninguna): **pwa_14** (Grimorio arcano + 13 sprites de efectos), **ronda17** (sprites animados de Brea viva, Prisma, Hueco y Singular + `tools/gen_heroes.py`) y **supervivencia_v5** (esquiva y racha, oleadas temáticas y jefes, daño tras la ola 30, etapas y fondos). Base común: pwa_13.
- Orden: pwa_13 + pwa_14 + ronda17 (sin conflictos de código) → + supervivencia_v5 (14 conflictos resueltos a mano, ver abajo).
- Resolución de conflictos: ruleta ×10 tiros, botón y pantalla del Grimorio, `arStart()`/`arKill()` → se conservan; esquiva (`#dash`), racha (`combo`), temas/etapas en `start()` y bucle de derribos → se conservan; `BAL` exporta la unión de ambas ramas (Grimorio + `bossDm`, `hitCap`, `ERAS`, `eraOf`, `THEMES`, `bossPlan`…); `show()` oculta el botón de esquiva fuera de partida y conoce la pantalla `arc`.
- `sw.js`: regenerado con la lista completa de `assets/` (138 recursos) y caché **mp23**. Las pruebas que fijaban una versión de caché exacta ahora aceptan «esa versión o posterior».
- Pruebas: se renombró `tests_ronda16.js` de la rama supervivencia a `tests_dano_etapas.js` (chocaba con la de la ruleta) y `tests_ronda17.js` pasó a `tests_grimorio.js` (pwa_14) y `tests_sprites_heroes.js` (ronda17). Nueva `tests_integracion.js` (7): las 12 arcanas en parejas × olas 2-55 con dibujo, esquiva+racha+Grimorio, olas 1-60, héroes con sprite propio, guardado, caché completa, escalado de daño + reparaciones.
- Sin probar en Android real; el balance de la combinación (Grimorio + oleadas temáticas + daño tras la ola 30) no se ha jugado.

## Eliminación de esquiva y racha
- Quitados el botón/tecla de esquiva (Espacio/Shift), su recarga, invulnerabilidad y daño de paso.
- Quitada la racha de derribos (+daño hasta 12%) y su texto en el HUD.
- Caché del service worker: mp24.
## Ronda: curación y XP
- Fruta de curación: cura 12% → 6% de la vida máxima; probabilidad de caída de enemigos normales 2% → 1% (BAL.K.fh y BAL.K.fd). Nunca hay más de una en el suelo a la vez (dropHeal ignora la caída si ya existe otra); los jefes sueltan 1 en vez de 2.
- XP por nivel: la curva cuadrática se multiplica por (1+4%·nivel) (BAL.K.xg). Nivel 10: 390 → 546; nivel 20: 1340 → 2412; nivel 50: 7790 → 23370.
- Guardado 'pocket2' intacto (solo cambia balance dentro de la partida). Caché del service worker mp24 → mp25.
## Ronda: curación (habilidades)
- Presupuesto de curación por habilidades: tope 6% → 4% de la vida máxima y recarga 2%/s → 1%/s (BAL.K.hbc, BAL.K.hbr).
- Floración: cura ×4 → ×2,5 por rango y ciclo más lento (mín. 3 s, base 7,5 s, −1,2 s por rango). Eclipse: cura ×0,5. Bosque vivo: semillas curan 0,3 (antes 0,6). Pacto de sangre: 0,5%+0,15%/★ por derribo (antes 0,8%+0,2%).
- Fruta corazón: cura 15 (antes 30). Mejoras al máximo: cura 15% (antes 30%).
## Ronda: nuevo enemigo Dragón Abisal
- Enemigo 'draco' (sombra, tirador: vida 48, vel 42, daño 10, radio 15, coste 3,2; aparece desde la oleada efectiva 8). Sprite assets/monsters/abyss_dragon.png (hoja 4x4: 0-3 reposo, 4-11 andar, 12-15 aliento con rayo morado).
- Nueva oleada temática 'NIDO DEL DRAGÓN' 🐉 (mapa base, etapa CRIPTA Y CIÉNAGA, ondas 10-19): dragón + umbrío + araña. Caché del service worker mp26.
## Ronda: CHAOS KING (mega jefe) en la oleada 10
- Temporal: constante CK_WAVES=[10] en index.html. En esa oleada se retiran todos los enemigos y aparece SOLO el Chaos King (sprite del Dragón Abisal, radio 38, sprite ×3,8). Para ponerlo cada 10 oleadas basta cambiar a [10,20,30,...]; para quitarlo, [].
- 2 barras de vida (HUD con dos barras, "BARRA 1/2"): al vaciar la primera se enfurece (rugido, vulnerable 1,5 s, ×1,25 velocidad, ataques más rápidos y lluvia de meteoros). Cada barra = bossHp × dificultad × 2,2.
- Zona de combate: arena circular (radio 270) centrada donde estaba el jugador; el jugador y el jefe no pueden salir; fuera de ella se oscurece y el borde se marca con sprites fx_sigil giratorios. No salen más enemigos durante el combate y el reloj de oleadas se congela.
- Habilidades con sprites (fx_*) en vez de partículas: Aliento (fx_breath + fx_flame, cono), Golpe de púas (fx_spike), Tornado persistente que persigue (fx_swirl), Impacto nova (fx_nova + fx_ring) y Meteoros en fase 2 (fx_rock). Las telegrafías usan fx_sigil. vfk(): nuevo lanzador de sprites con ancho/alto y rotación.
- Al morir: 5 s de cuenta atrás ("NUEVA OLEADA EN n"), se abre la arena y arranca la oleada 11. Caché del service worker mp27.
## Ronda: Chaos King a la oleada 50
- CK_WAVES=[50] (antes [10]). Estadísticas al nivel de la oleada 50: vida por barra ×3,2 (antes ×2,2; ≈53 800 PV por barra en Normal), daño base 28 (antes 20; ≈91 con el escalado de la oleada), velocidad 38 y radio 42.
- Con oleada ≥ 40 sus ataques crecen: púas +2, meteoros 10 (antes 7) y un tornado más. Caché del service worker mp28.
## Ronda: arena del Chaos King más grande
- Radio de la zona de combate 270 → 420 (constante CK_R; ≈2,4× de superficie). Sigilos del borde 16 → 24. Caché del service worker mp29.
## Ronda: pantalla de victoria del Chaos King
- Al derrotarlo (y tras elegir la mejora pendiente) el juego se pausa y muestra "¡CHAOS KING DERROTADO!" con dos botones: CONTINUAR (sigue la expedición; la oleada siguiente llega 5 s después) o VOLVER AL REFUGIO (termina la expedición, cobra la esencia y muestra "¡VICTORIA!"). die(v) acepta ahora un indicador de victoria. Caché del service worker mp30.

## Ronda 18 (misiones y nivel de cuenta)
- Nuevo botón **MISIONES** en el menú: 12 familias de misiones por niveles (derribos, oleada, jefes, tiempo, expediciones, nivel en partida, invocaciones, mejoras, colección y oleada en cada dificultad). Cada una se reclama a mano y da XP de cuenta.
- **Nivel de cuenta** derivado del XP total (1–30; pasar del nivel l al l+1 cuesta 30+15·l XP).
- **Dificultades bloqueadas por nivel:** Normal ×1 (Nv 1), Difícil ×2 (Nv 5), Pesadilla ×5 (Nv 12), Colapso ×10 (Nv 20). Los requisitos están en `BAL.DIF_REQ`; las misiones en `BAL.MIS`.
- La dificultad por defecto pasa de Colapso a Normal. Un guardado con una dificultad aún bloqueada baja a la más alta disponible.
- Las estadísticas se guardan al terminar la expedición (una expedición cuenta desde 30 s). Oleada, invocaciones, mejoras y colección se leen del progreso ya existente, así que los jugadores antiguos ya tienen parte reclamable.
- Guardado 'pocket2' compatible (campo nuevo M.mi). Caché del service worker mp31. Pruebas: `node tests_misiones.js` y `node tests_misiones_ui.js`.

## Ronda 19 (misiones semanales y diarias)
- Las misiones por niveles ahora son **semanales**: el progreso y lo reclamado se reinician cada lunes (hora local). Metas ajustadas a una semana (4 niveles por familia; invocaciones y mejoras cuentan lo hecho esa semana; se quitó «Personajes y compañeros», que es colección permanente). El **XP y nivel de cuenta no se pierden**, así que las dificultades desbloqueadas siguen abiertas.
- Nuevas **misiones diarias**: 3 al día (de 8 posibles, con estadísticas distintas), elegidas por fecha y se reinician a medianoche local. Dan XP de cuenta (15-25). «RECLAMAR TODO» incluye diarias y semanales; la insignia del menú las cuenta.
- Guardado 'pocket2' compatible (campos nuevos dentro de M.mi; un guardado anterior arranca con semana y día limpios). Caché del service worker mp32.
- Pruebas: `node tests_misiones.js` y `node tests_misiones_ui.js` actualizadas (reinicios, no doble reclamo, claves de semana/día). Sin probar en Android real.
