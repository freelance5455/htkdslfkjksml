# Sol Norte — registro de cambios

## Errores corregidos
- **Crítico:** completar la misión "La furgoneta" lanzaba una excepción en el bucle de juego (`run` se leía después de `complete()`), y el juego se quedaba congelado. Corregido en `updateMission`.
- Los coches de policía destruidos ocupaban el cupo de patrullas: tras dos derribos no había refuerzos. Ahora un patrulla destruido sale de la persecución y se repone si hace falta.
- La pantalla de muerte reaparecía sola a los 2,6 s. Ahora espera a que el jugador pulse "Reaparecer".
- Al ocultar la pestaña, el coche seguía circulando. Ahora el juego se pausa.
- La sonda de pruebas `window.__controlsTest` se exponía a los jugadores. Ahora solo existe en desarrollo o con `?qa=1`.
- El botón de pausa conservaba el foco: tras un clic, la barra espaciadora volvía a pausar en vez de atacar.
- Si WebGL no arrancaba, el menú aparecía sin funcionar y sin aviso. Ahora se muestra un mensaje en español.
- El componente de error estaba en inglés y con colores claros. Ahora usa los tokens del juego y está en español.
- `dispose` no liberaba geometrías, materiales ni texturas de GPU.

## Mejoras
- Botón "Empezar" en español (antes "Start").
- Botón de silencio en la barra superior; la preferencia se guarda.
- "Nueva partida" en el menú de pausa, con confirmación en dos pasos.
- En móvil el botón dice "Correr" a pie y "Freno" en coche.
- Accesibilidad: roles `meter`, `img`, `status` (con `aria-live`), `dialog` y `alertdialog`; foco automático en los diálogos; iconos decorativos ocultos a lectores de pantalla.
- Limpieza: clase compartida renombrada a `sn-icon-btn`, selectores CSS muertos eliminados, ternario redundante en `city.ts` (mismo resultado).

## Pruebas nuevas
- `src/game/world.test.ts` (7 pruebas): generación determinista, ningún edificio sobre una calle, ningún objetivo dentro de un edificio, todos los objetivos alcanzables a pie y en coche. Añadido al script `npm test`.
- Arnés headless de simulación (fuera de este proyecto): 16 pruebas de comportamiento (controles, misiones, economía, policía, muerte, pausa, guardado, nueva partida, silencio) y fuzzer de entradas aleatorias. Todo pasa en la versión final.

## Verificación pendiente en tu entorno
- `npm install`, `npm run build`, `npm run typecheck` y `npm test` completos. En este entorno no hay red ni dependencias instaladas.
- Prueba en navegador real (desktop y móvil), porque el render 3D no se pudo ejecutar aquí.
- Los 8 tests de `scripts/` fallan solo si se ejecutan desde la raíz, porque leen `src/lib/og/site.json`. Desde otro directorio pasan 197/197.

## Seguridad
- `src/lib/auth/preview.ts` contiene un client secret escrito en el código. Es un archivo de la plataforma y no se modificó; revísalo antes de publicar el repositorio.
