// دالة لطلب إذن الإشعارات من المستخدم
function requestNotificationPermission() {
  if (!("Notification" in window)) {
    console.log("هذا المتصفح لا يدعم الإشعارات");
    return;
  }

  if (Notification.permission === "default") {
    Notification.requestPermission().then(permission => {
      if (permission === "granted") {
        console.log("تم السماح بالإشعارات");
      }
    });
  }
}

// دالة لفحص الأجهزة وإظهار الإشعارات
function checkAndScheduleNotifications() {
  // لو المستخدم رافض الإشعارات أو المتصفح مش داعمها، اخرج
  if (!("Notification" in window) || Notification.permission !== "granted") {
    return;
  }

  const devices = getDevices(); // دالة من ملف storage.js
  const today = new Date();
  today.setHours(0, 0, 0, 0); // تصفير الوقت عشان نحسب الأيام بدقة

  devices.forEach(device => {
    const purchaseDate = new Date(device.purchaseDate);
    const expiryDate = new Date(purchaseDate);
    expiryDate.setMonth(expiryDate.getMonth() + parseInt(device.warrantyMonths));
    expiryDate.setHours(0, 0, 0, 0);

    const diffTime = expiryDate - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    // إشعار قبل الانتهاء بيوم أو 7 أيام
    if (diffDays === 7 || diffDays === 1) {
      const notifKey = `notified_${device.id}_${diffDays}`;
      
      // عشان ميزعجش المستخدم كل ما يفتح التطبيق، بنبعت الإشعار مرة واحدة بس
      if (!localStorage.getItem(notifKey)) {
        const bodyText = diffDays === 1 
          ? `ضمان "${device.name}" ينتهي غداً!` 
          : `ضمان "${device.name}" ينتهي بعد أسبوع!`;

        new Notification("تنبيه ضمان ⚠️", {
          body: bodyText,
          icon: "icons/icon-192.png",
          vibrate: [200, 100, 200]
        });

        // بنسجل إننا بعتنا الإشعار ده خلاص
        localStorage.setItem(notifKey, "sent");
      }
    }
  });
}

// طلب الإذن أول ما التطبيق يفتح
requestNotificationPermission();