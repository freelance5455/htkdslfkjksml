import { isTaskActive, isTaskDone, isPaused, applyVacationAdjustment, todayKey } from './recurrence.js';
import { t } from './i18n.js';

const sent = new Set();
const timeToMinutes = (value) => /^\d{2}:\d{2}$/.test(value || '') ? value.split(':').map(Number).reduce((hours, minutes) => hours * 60 + minutes) : null;
const minutesNow = (date) => date.getHours() * 60 + date.getMinutes();
const makeMoment = (date, time) => { const minutes = timeToMinutes(time); if (minutes === null) return null; const moment = new Date(date); moment.setHours(Math.floor(minutes / 60), minutes % 60, 0, 0); return moment; };
const settingNumber = (settings, key, fallback) => { const value = Number(settings?.[key]); return Number.isFinite(value) && value >= 0 ? value : fallback; };

function emitNotice(settings, key, title, body, onNotice) {
  if (sent.has(key)) return;
  sent.add(key);
  if (settings.inApp !== false) onNotice?.(body);
  if (settings.system && 'Notification' in window && Notification.permission === 'granted') {
    try { new Notification(title, { body, tag: key }); } catch (error) { console.warn('System notification failed', error); }
  }
}

export function notificationDefaults() { return { enabled: true, inApp: true, system: false, taskLead: 10, appointmentLead: 15, taskEndLead: 5 }; }

export async function requestSystemPermission() {
  if (!('Notification' in window)) throw new Error('unsupported');
  if (Notification.permission === 'granted') return true;
  const permission = await Notification.requestPermission();
  if (permission !== 'granted') throw new Error('denied');
  return true;
}

export function checkNotifications(state, onNotice) {
  const settings = state?.settings?.notifications || notificationDefaults();
  if (settings.enabled === false) return;
  const now = new Date();
  const today = todayKey(now);
  const nowMinute = minutesNow(now);
  const taskLead = settingNumber(settings, 'taskLead', 10);
  const endLead = settingNumber(settings, 'taskEndLead', 5);
  const appointmentLead = settingNumber(settings, 'appointmentLead', 15);
  const tasks = (state.tasks || []).map((task) => applyVacationAdjustment(task, 'task', state.vacations, now));
  tasks.filter((task) => isTaskActive(task, now) && !isPaused('task', task.id, state.vacations, now)).forEach((task) => {
    const start = timeToMinutes(task.time);
    const duration = Number(task.duration) || 0;
    if (start === null) return;
    const end = start + duration;
    const subtasks = Array.isArray(task.subtasks) ? task.subtasks : [];
    const hasSubtasks = subtasks.length > 0;
    const subtaskStarted = hasSubtasks && subtasks.some((subtask) => subtask.done);
    // Start-Erinnerung: Hat die Aufgabe Unteraufgaben, bleibt sie über das ganze Zeitfenster
    // bestehen, bis mindestens eine Unteraufgabe erledigt wurde (echter Beleg, dass begonnen
    // wurde - reine Zeit reicht nicht). Ohne Unteraufgaben gilt weiterhin: nur vor Beginn.
    const startWindowEnd = hasSubtasks ? end : start;
    if (nowMinute >= start - taskLead && nowMinute < startWindowEnd && !subtaskStarted) emitNotice(settings, `${today}:task:${task.id}:start`, t('notifications.taskTitle'), t('notifications.taskDue', { name: task.name, time: task.time }), onNotice);
    // Ende-Erinnerung bleibt bestehen, solange die Aufgabe nicht abgeschlossen ist - auch über das Zeitfenster hinaus.
    if (!isTaskDone(task, now) && duration > 0 && nowMinute >= end - endLead) emitNotice(settings, `${today}:task:${task.id}:end`, t('notifications.taskEndTitle'), t('notifications.taskEnding', { name: task.name, time: task.endTime || `${String(Math.floor(end / 60) % 24).padStart(2, '0')}:${String(end % 60).padStart(2, '0')}` }), onNotice);
  });
  (state.appointments || []).filter((appointment) => appointment.date === today).forEach((appointment) => {
    const start = timeToMinutes(appointment.time);
    if (start === null) return;
    const reminders = appointment.reminders && typeof appointment.reminders === 'object' ? appointment.reminders : { mode: 'default', minutes: [] };
    if (reminders.mode === 'off') return;
    const leads = reminders.mode === 'custom' && reminders.minutes.length ? reminders.minutes : [appointmentLead];
    leads.forEach((lead) => {
      const leadMinutes = Number(lead);
      if (!Number.isFinite(leadMinutes) || leadMinutes < 0) return;
      if (nowMinute < start - leadMinutes || nowMinute >= start) return;
      emitNotice(settings, `${today}:appointment:${appointment.id}:lead:${leadMinutes}`, t('notifications.appointmentTitle'), t('notifications.appointmentDue', { name: appointment.title, time: appointment.time }), onNotice);
    });
  });
}

