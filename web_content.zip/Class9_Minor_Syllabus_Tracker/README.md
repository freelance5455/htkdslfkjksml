# Class 9 • Minor • Syllabus Tracker

Updated standalone PWA implementation based on the supplied current-app screenshot and the supplied ALLEN Class 9 Minor Test Syllabus PDF.

## Included
- Same dark/premium tracker style and smooth page animation
- MINOR label instead of SEM I MAJOR
- Compact date selector on the main page
- Five Minor test dates from the supplied syllabus
- Date-specific syllabus; subjects with no syllabus/NA are not displayed
- Separate completion state for each test date and topic, stored in localStorage
- Back-to-main-page controls on every secondary screen
- Offline PWA caching
- Responsive mobile-first layout

## Dates
18 Oct 2026, 29 Nov 2026, 20 Dec 2026, 10 Jan 2027, 31 Jan 2027.

## Run
Open `index.html` in a browser for basic use. For full PWA installation/offline service-worker behavior, serve the folder from HTTPS or localhost.

## Final polish
- Added a restrained mastery celebration that fires when the selected test date reaches 100%.
- The mastery effect is date-specific because completion is stored separately for every test date.
- Respects reduced-motion accessibility preferences.
- Service-worker cache bumped to v2 so the upgraded UI is not trapped behind an old cache.
