extends CharacterBody3D

@export var move_speed: float = 0.65
@export var notice_distance: float = 9.0
var player: XROrigin3D

func _ready() -> void:
    player = get_tree().current_scene.get_node_or_null("XRRoot")
    var material := StandardMaterial3D.new()
    material.albedo_color = Color(0.04, 0.42, 0.55)
    material.roughness = 0.85
    var body := get_node_or_null("Body") as MeshInstance3D
    if body:
        body.material_override = material

func _physics_process(_delta: float) -> void:
    if player == null:
        return
    var offset: Vector3 = player.global_position - global_position
    offset.y = 0
    if offset.length() < notice_distance and offset.length() > 1.4:
        velocity = offset.normalized() * move_speed
        look_at(Vector3(player.global_position.x, global_position.y, player.global_position.z), Vector3.UP)
    else:
        velocity = Vector3.ZERO
    move_and_slide()
