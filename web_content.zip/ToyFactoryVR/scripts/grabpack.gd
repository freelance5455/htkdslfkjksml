extends XRController3D

@export var reach: float = 4.0
var ray: RayCast3D

func _ready() -> void:
    ray = RayCast3D.new()
    ray.target_position = Vector3(0, 0, -reach)
    ray.enabled = true
    add_child(ray)

func _process(_delta: float) -> void:
    # Starter interaction: point a controller at a puzzle target and press trigger.
    # Configure the matching OpenXR action in Godot's XR action map before building.
    if is_button_pressed("trigger_click") and ray.is_colliding():
        var hit := ray.get_collider()
        if hit and hit.has_method("activate"):
            hit.activate()
