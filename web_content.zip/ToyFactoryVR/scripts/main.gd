extends Node3D

# Toy Factory: Night Shift — original VR horror prototype.
# Built from primitive geometry so no copyrighted game assets are required.

var xr_origin: XROrigin3D
var monster: Node3D
var status_label: Label3D
var objective: Node3D
var door: Node3D
var won := false
var elapsed := 0.0

func _ready() -> void:
    _make_world()
    _make_factory()
    _make_xr_rig()
    _make_monster()
    _make_objective()
    _make_door()
    _make_sign()
    var interface := XRServer.find_interface("OpenXR")
    if interface and interface.is_initialized():
        get_viewport().use_xr = true

func _material(color: Color, roughness := 0.8, emission := Color.BLACK) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = roughness
    if emission != Color.BLACK:
        m.emission_enabled = true
        m.emission = emission
        m.emission_energy_multiplier = 1.5
    return m

func _box(parent: Node3D, name: String, pos: Vector3, size: Vector3, mat: Material, collision := false) -> Node3D:
    var body: Node3D
    if collision:
        body = StaticBody3D.new()
        var shape_node := CollisionShape3D.new()
        var shape := BoxShape3D.new()
        shape.size = size
        shape_node.shape = shape
        body.add_child(shape_node)
    else:
        body = MeshInstance3D.new()
    body.name = name
    body.position = pos
    var mesh := BoxMesh.new()
    mesh.size = size
    if body is MeshInstance3D:
        (body as MeshInstance3D).mesh = mesh
        (body as MeshInstance3D).material_override = mat
    else:
        var visual := MeshInstance3D.new()
        visual.mesh = mesh
        visual.material_override = mat
        body.add_child(visual)
    parent.add_child(body)
    return body

func _make_world() -> void:
    var env_node := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.006, 0.009, 0.018)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.18, 0.22, 0.3)
    env.ambient_light_energy = 0.45
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env_node.environment = env
    add_child(env_node)
    var light := DirectionalLight3D.new()
    light.rotation_degrees = Vector3(-55, -25, 0)
    light.light_color = Color(0.46, 0.58, 0.82)
    light.light_energy = 0.25
    add_child(light)

func _make_factory() -> void:
    var floor_mat := _material(Color(0.10, 0.12, 0.15))
    var wall_mat := _material(Color(0.12, 0.16, 0.20))
    var trim_mat := _material(Color(0.03, 0.45, 0.52), 0.4, Color(0.02, 0.22, 0.28))
    _box(self, "FactoryFloor", Vector3(0, -0.12, -4), Vector3(12, 0.24, 30), floor_mat, true)
    _box(self, "LeftWall", Vector3(-6, 2, -4), Vector3(0.3, 4, 30), wall_mat, true)
    _box(self, "RightWall", Vector3(6, 2, -4), Vector3(0.3, 4, 30), wall_mat, true)
    _box(self, "BackWall", Vector3(0, 2, -19), Vector3(12, 4, 0.3), wall_mat, true)
    _box(self, "FrontWallLeft", Vector3(-4.3, 2, 11), Vector3(3.4, 4, 0.3), wall_mat, true)
    _box(self, "FrontWallRight", Vector3(4.3, 2, 11), Vector3(3.4, 4, 0.3), wall_mat, true)
    _box(self, "Header", Vector3(0, 3.7, 11), Vector3(5.2, 0.6, 0.35), wall_mat, true)
    for z in [7.0, 1.0, -5.0, -11.0, -17.0]:
        _box(self, "CeilingBeam", Vector3(0, 3.75, z), Vector3(12, 0.18, 0.25), trim_mat)
        var lamp := OmniLight3D.new()
        lamp.position = Vector3(0, 3.1, z - 1)
        lamp.light_color = Color(0.15, 0.75, 0.9) if int(abs(z)) % 2 == 1 else Color(0.9, 0.22, 0.12)
        lamp.light_energy = 0.8
        lamp.omni_range = 8
        add_child(lamp)
    # Crates and conveyor machinery make the corridor feel like a factory.
    var crate_mat := _material(Color(0.22, 0.25, 0.28))
    for i in range(5):
        _box(self, "StorageCrate", Vector3(-3.9, 0.65, 4.0 - i * 3.6), Vector3(1.5, 1.3, 1.3), crate_mat, true)
        _box(self, "StorageCrate", Vector3(3.9, 0.65, 2.2 - i * 3.6), Vector3(1.5, 1.3, 1.3), crate_mat, true)
    _box(self, "Conveyor", Vector3(0, 0.8, -8), Vector3(2.2, 0.25, 5.0), _material(Color(0.04, 0.05, 0.07)), true)

func _make_xr_rig() -> void:
    xr_origin = XROrigin3D.new()
    xr_origin.name = "XROrigin3D"
    xr_origin.position = Vector3(0, 0, 8)
    add_child(xr_origin)
    var camera := XRCamera3D.new()
    camera.name = "XRCamera3D"
    camera.position.y = 1.65
    xr_origin.add_child(camera)
    for side in ["left_hand", "right_hand"]:
        var controller := XRController3D.new()
        controller.name = "Controller_" + side
        controller.tracker = side
        xr_origin.add_child(controller)
        # Original dual-grabber gloves: chunky palms, segmented fingertips, and a wrist housing.
        # These are intentionally original designs rather than a copy of any existing game's prop.
        _make_grabber_glove(controller, side == "left_hand")


func _make_grabber_glove(parent: Node3D, is_left: bool) -> void:
    var glove_color := Color(0.95, 0.32, 0.10) if is_left else Color(0.04, 0.68, 0.82)
    var dark_color := Color(0.12, 0.15, 0.19)
    var metal := _material(Color(0.32, 0.38, 0.43), 0.35)
    var glove_mat := _material(glove_color, 0.38, glove_color * 0.12)
    var dark_mat := _material(dark_color, 0.5)
    _box(parent, "WristHousing", Vector3(0, 0, 0.06), Vector3(0.16, 0.14, 0.22), dark_mat)
    _box(parent, "MetalCuff", Vector3(0, 0, -0.055), Vector3(0.18, 0.16, 0.07), metal)
    _box(parent, "GlovePalm", Vector3(0, -0.015, -0.13), Vector3(0.18, 0.17, 0.09), glove_mat)
    # Four visible, rounded finger pads make the hand read clearly in-headset.
    for i in range(4):
        var x := (float(i) - 1.5) * 0.044
        var finger := MeshInstance3D.new()
        finger.name = "FingerPad_%d" % i
        var capsule := CapsuleMesh.new()
        capsule.radius = 0.018
        capsule.height = 0.09
        finger.mesh = capsule
        finger.material_override = glove_mat
        finger.position = Vector3(x, -0.035, -0.205)
        finger.rotation_degrees.x = 90
        parent.add_child(finger)
    var thumb := MeshInstance3D.new()
    thumb.name = "ThumbPad"
    var thumb_mesh := CapsuleMesh.new()
    thumb_mesh.radius = 0.02
    thumb_mesh.height = 0.075
    thumb.mesh = thumb_mesh
    thumb.material_override = glove_mat
    thumb.position = Vector3(-0.105 if is_left else 0.105, -0.015, -0.16)
    thumb.rotation_degrees = Vector3(20, 0, 55 if is_left else -55)
    parent.add_child(thumb)
    _box(parent, "GloveStatusLight", Vector3(0, 0.055, -0.01), Vector3(0.045, 0.018, 0.018), _material(Color(0.75, 1.0, 0.85), 0.2, Color(0.2, 0.9, 0.55)))

func _make_monster() -> void:
    monster = Node3D.new()
    monster.name = "The_Teal_Toy"
    monster.position = Vector3(0, 0, -12)
    add_child(monster)
    var blue := _material(Color(0.015, 0.28, 0.36), 0.65)
    var dark := _material(Color(0.008, 0.012, 0.02), 0.3)
    var eye := _material(Color(0.95, 0.96, 1.0), 0.2, Color(0.45, 0.6, 0.9))
    _sphere(monster, "Head", Vector3(0, 2.0, 0), Vector3(0.72, 0.85, 0.58), blue)
    _sphere(monster, "Torso", Vector3(0, 1.0, 0), Vector3(0.52, 1.0, 0.36), blue)
    for side in [-1.0, 1.0]:
        _sphere(monster, "LongArm", Vector3(side * 0.72, 1.15, -0.02), Vector3(0.18, 1.0, 0.18), blue)
        _sphere(monster, "Hand", Vector3(side * 0.76, 0.55, -0.02), Vector3(0.23, 0.25, 0.2), blue)
        _sphere(monster, "Eye", Vector3(side * 0.23, 2.15, -0.51), Vector3(0.14, 0.18, 0.08), eye)
        _sphere(monster, "Pupil", Vector3(side * 0.23, 2.14, -0.58), Vector3(0.055, 0.09, 0.035), dark)
        _sphere(monster, "Leg", Vector3(side * 0.2, 0.25, 0), Vector3(0.18, 0.55, 0.2), blue)
    _box(monster, "DarkMouth", Vector3(0, 1.78, -0.54), Vector3(0.48, 0.12, 0.06), dark)

func _sphere(parent: Node3D, name: String, pos: Vector3, size: Vector3, mat: Material) -> void:
    var mesh_instance := MeshInstance3D.new()
    mesh_instance.name = name
    var mesh := SphereMesh.new()
    mesh.radius = 0.5
    mesh.height = 1.0
    mesh_instance.mesh = mesh
    mesh_instance.scale = size * 2.0
    mesh_instance.position = pos
    mesh_instance.material_override = mat
    parent.add_child(mesh_instance)

func _make_objective() -> void:
    objective = Node3D.new()
    objective.name = "PowerCell"
    objective.position = Vector3(0, 1.2, -7.5)
    add_child(objective)
    _sphere(objective, "GlowingPowerCell", Vector3.ZERO, Vector3(0.25, 0.42, 0.25), _material(Color(0.1, 0.9, 0.75), 0.2, Color(0.05, 0.9, 0.65)))
    var glow := OmniLight3D.new()
    glow.light_color = Color(0.05, 0.9, 0.65)
    glow.light_energy = 1.2
    glow.omni_range = 3
    objective.add_child(glow)

func _make_door() -> void:
    door = _box(self, "ExitDoor", Vector3(0, 1.6, -18.6), Vector3(2.5, 3.2, 0.25), _material(Color(0.16, 0.18, 0.2)), true)

func _make_sign() -> void:
    var sign := Label3D.new()
    sign.text = "NIGHT SHIFT  //  RESTORE POWER"
    sign.font_size = 48
    sign.position = Vector3(0, 3.0, -7.0)
    sign.pixel_size = 0.006
    sign.modulate = Color(0.25, 0.9, 0.9)
    add_child(sign)
    status_label = Label3D.new()
    status_label.text = "FIND THE POWER CELL"
    status_label.font_size = 32
    status_label.position = Vector3(0, 2.6, 7.0)
    status_label.pixel_size = 0.006
    status_label.modulate = Color(0.9, 0.75, 0.3)
    add_child(status_label)

func _process(delta: float) -> void:
    elapsed += delta
    if is_instance_valid(objective):
        objective.rotate_y(delta * 0.8)
        objective.position.y = 1.2 + sin(elapsed * 2.0) * 0.12
    if xr_origin == null or monster == null or won:
        return
    var player_pos := xr_origin.global_position
    var diff := player_pos - monster.global_position
    diff.y = 0
    var distance := diff.length()
    if distance < 11.0 and distance > 1.3:
        monster.global_position += diff.normalized() * delta * (0.45 if distance > 5.0 else 0.85)
        monster.look_at(Vector3(player_pos.x, monster.global_position.y, player_pos.z), Vector3.UP)
    if distance < 1.5:
        status_label.text = "IT FOUND YOU  —  KEEP MOVING"
        status_label.modulate = Color(1, 0.12, 0.08)
    # Desktop fallback controls for testing without a headset.
    if not get_viewport().use_xr:
        var move := Vector3.ZERO
        if Input.is_key_pressed(KEY_W): move.z -= 1
        if Input.is_key_pressed(KEY_S): move.z += 1
        if Input.is_key_pressed(KEY_A): move.x -= 1
        if Input.is_key_pressed(KEY_D): move.x += 1
        xr_origin.position += move.normalized() * delta * 2.2
        if Input.is_key_pressed(KEY_E) and xr_origin.global_position.distance_to(objective.global_position) < 2.0:
            _restore_power()

func _restore_power() -> void:
    if won:
        return
    won = true
    objective.visible = false
    monster.visible = false
    status_label.text = "POWER RESTORED — EXIT OPEN"
    status_label.modulate = Color(0.2, 1, 0.45)
    if is_instance_valid(door):
        door.visible = false
