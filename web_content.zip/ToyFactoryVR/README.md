# Toy Factory: Night Shift VR — Quest 2 prototype

An original toy-factory horror prototype built with Godot 4.3 and procedural geometry. It is **not** the official Poppy Playtime game and contains no official game assets.

## Android/Quest export setup

This project now includes an Android export preset and a GitHub Actions workflow. The workflow attempts to export a debug APK for **ARM64 Android** and publish it as a downloadable build artifact.

### Build from a phone using GitHub Actions

1. Sign in to GitHub and create a new **public or private repository**.
2. Upload the contents of this project folder to the repository (upload the files/folders, not just the ZIP).
3. Open the repository's **Actions** tab and allow Actions if GitHub asks.
4. Select **Build Android APK** and tap **Run workflow**. A push to the `main` branch also triggers it.
5. When the workflow finishes successfully, open that run and download **ToyFactoryVR-Quest2-APK** under Artifacts. The ZIP artifact contains `ToyFactoryVR-Quest2.apk`.

If the build fails, open the workflow log: the first error message should identify whether the Godot CI image, export template, or Android preset needs adjustment. This setup is not a guarantee that export will succeed on every runner image.

## Install on Meta Quest 2

The APK is intended for Quest 2's Android ARM64 platform, but it must be tested on the headset. To install it, use a sideloading method such as Meta Quest Developer Hub/SideQuest from a compatible computer, or another trusted ADB sideload workflow. An APK downloaded to a phone does not automatically install onto the Quest just by sharing it; the headset must receive and install the APK through a supported sideloading method. Only install APKs you trust.

## Prototype status and limitations

- Procedurally generated corridor, crates, lights, exit door, power-cell objective, and an original teal toy monster.
- OpenXR is enabled in project settings and the Android preset requests XR mode.
- This is an early prototype. Touch-controller actions, locomotion/collision tuning, audio, comfort settings, and actual Quest-device testing remain unfinished.
- A successful Android export does **not** by itself prove the game launches correctly in VR. Test on Quest 2 before treating it as ready.
