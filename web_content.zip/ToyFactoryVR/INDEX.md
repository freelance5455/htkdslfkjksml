# Toy Factory VR — Project Index

## What this is
An original, early-stage toy-factory horror VR prototype for Godot 4.3, set up for an Android ARM64 APK build targeting Meta Quest 2. It is fan-made and unofficial; it is not the Poppy Playtime game and does not include its proprietary models, textures, sounds, or code.

## Main files
- `project.godot` — Godot project and OpenXR settings.
- `scenes/Main.tscn` — main scene entry point.
- `scripts/main.gd` — factory room, monster, objective, exit, and VR rig.
- `scripts/grabpack.gd` — controller trigger/raycast interaction starter.
- `export_presets.cfg` — Android ARM64 export preset.
- `.github/workflows/build-android.yml` — cloud build workflow.
- `index.html` — browser-readable project landing page and build guide.

## Build status
This ZIP contains project source and build configuration, not a compiled APK. The workflow must finish successfully to produce an APK artifact. Test the resulting build on the headset before relying on it.
