# Protwave data handling (plain English)

**Your text.** Selections, files and prompts are analysed on your device. They are never uploaded by Protwave.

**How capture works.** When you press the hotkey Protwave presses copy for you, reads the selection, then puts your previous clipboard text back. If your clipboard held something that isn't text (an image or files) it is left alone when nothing is selected, but it is replaced when a text selection is captured.

**What Protwave may contact (and only this)**
- The signed price list at the `ledgerUrl` in `src/config.js`. Updates apply only if the Ed25519 signature checks out.
- Your own feedback server, only if you set `url` in `src/config.js` AND the user sends feedback or switches on anonymous usage (random install ID, app version, OS; never text).

**See it yourself.** Open the card, tap `⋯`, then "Privacy & data": the network log lists every request Protwave made this session, with the host and purpose. "Copy data" exports everything stored locally; "Erase all" wipes it.

**Stored locally.** Settings, calibration numbers, savings totals, the hotkey, and the last verified price list.

**Limits.** Token counts for Claude, Gemini and Muse are estimates (their tokenizers are not public). Prices are list prices and may be out of date; the card warns when the price list is more than 3 weeks old.
