TALLY PRO - APK PROJECT

Is project mein aapki Tally Pro HTML website pehle se app/src/main/assets/index.html mein rakhi hui hai.

MOBILE SE APK BANANE KA TARIKA:
1. AndroidIDE ya koi Android Gradle IDE install karein jo Android Gradle Plugin 8.6.1 aur SDK 35 support karta ho.
2. Is ZIP ko extract karein.
3. IDE mein extracted TallyPro folder ko Open Project karein.
4. Gradle sync hone dein. Internet aur Android SDK components ki zaroorat ho sakti hai.
5. Build menu mein Build APK / Assemble Debug chalayein.
6. APK aam taur par app/build/outputs/apk/debug/app-debug.apk mein milegi.

Agar IDE SDK 35 ya Gradle 8.7 download karne ko kahe, to usse allow karein.

NOTE:
- App aapki original HTML file ko WebView mein chalata hai.
- Tailwind CSS aur Google Fonts CDN se load hote hain, isliye pehli baar styling/fonts ke liye internet lag sakta hai.
- App ko install karne se pehle APK ko scan karein aur sirf apne banaye/ भरोसेमंद build ko install karein.
