"""اختبارات بنفسج: python3 tests/project_test.py   (تتطلب: pip install playwright && playwright install chromium)
تُشغّل خادمًا محليًا لمجلد www وتختبر الوظائف وPWA وحالة عدم الاتصال وأحجام الشاشات."""
import json,os,re,subprocess,sys,threading,http.server,socketserver,functools
from playwright.sync_api import sync_playwright
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));WWW=os.path.join(ROOT,"www")
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a):pass
srv=socketserver.TCPServer(("127.0.0.1",0),functools.partial(Q,directory=WWW));PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start();URL=f"http://127.0.0.1:{PORT}/index.html"
res=[];errs=[]
def ok(n,c):res.append((n,bool(c)))
def sel(pg,v):pg.click(f'nav button[data-v="{v}"]')
with sync_playwright() as p:
    b=p.chromium.launch()
    ctx=b.new_context(viewport={"width":390,"height":800},is_mobile=True,has_touch=True,permissions=["clipboard-read","clipboard-write"])
    pg=ctx.new_page();pg.on("pageerror",lambda e:errs.append(str(e)));pg.on("console",lambda m:errs.append(m.text) if m.type=="error" else None)
    pg.goto(URL);pg.wait_for_selector("#app > *")
    # --- data & absence of the removed report button
    pg.click('nav button[data-v="browse"]');pg.click('[data-a="f"][data-f="all"]');pg.wait_for_function("document.querySelector('#cnt')&&document.querySelector('#cnt').innerText.startsWith('3604')")
    ok("library loads: 3604 items",True)
    for t,n in [("zajal",500),("quote",500),("wisdom",500),("phrase",500),("message",None),("poetry",None),("vocab",None)]:
        pg.click(f'[data-a="f"][data-f="{t}"]');pg.wait_for_selector(".card")
        if n:ok(f"{t} = {n}",pg.locator("#cnt").inner_text().startswith(str(n)))
    ok("no 'تقرير المكتبة' in page",all("تقرير المكتبة" not in x for x in [pg.content()]))
    # --- all sections reachable & render
    for t in ["quote","wisdom","proverb","dua","zajal","phrase","message","status","poetry","thought","pride","condolence","gratitude","vocab","discuss","game","occasion","daily","riddle"]:
        pg.click(f'[data-a="f"][data-f="{t}"]');pg.wait_for_selector(".card",timeout=5000)
    ok("all 19 sections open and render cards",True)
    # --- search: exact, partial, no results
    sel(pg,"home");pg.fill("#q","أمي");pg.wait_for_selector("#out .card");ok("search 'أمي'",pg.locator("#out .card").count()==20)
    pg.fill("#q","شتاق");pg.wait_for_selector("#out .card",timeout=8000);ok("partial search 'شتاق'",pg.locator("#out .card").count()>0)
    pg.fill("#q","ظظظظظظ");pg.wait_for_selector("#out .empty",timeout=8000);ok("no-results message shown",True)
    # --- back button keeps user inside the app
    pg.fill("#q","");pg.click('nav button[data-v="browse"]');pg.wait_for_selector(".card");pg.go_back();pg.wait_for_selector("#app .hero")
    ok("browser/Android Back returns to previous view",pg.evaluate("document.querySelector('#app .hero')!==null"))
    pg.fill("#q","حب");pg.click('[data-a="search"]');pg.wait_for_selector("h2:has-text('نتائج')");pg.go_back();pg.wait_for_selector("#app .hero");ok("Back from results returns home",True)
    # --- favorites persist across reload
    sel(pg,"browse");pg.click('[data-a="f"][data-f="dua"]');pg.wait_for_selector(".card");pg.click('.fav >> nth=1');pg.wait_for_selector(".fav.on")
    pg.reload();pg.wait_for_selector("#app > *");sel(pg,"favs");pg.wait_for_selector(".card");ok("favorites persist after reload",pg.locator(".card").count()>=1)
    # --- copy: clipboard path, and fallback when clipboard API is missing
    sel(pg,"today");pg.wait_for_selector(".card");pg.click('[data-a="copy"] >> nth=0');pg.wait_for_timeout(200)
    ok("copy via clipboard API",pg.evaluate("navigator.clipboard.readText()").endswith("— بنفسج 💜"))
    pg.evaluate("Object.defineProperty(navigator,'clipboard',{value:undefined,configurable:true});window.__ec=0;document.execCommand=()=>{window.__ec++;return true};0")
    pg.click('[data-a="copy"] >> nth=1');pg.wait_for_timeout(200);ok("copy fallback (execCommand) when Clipboard API unavailable",pg.evaluate("window.__ec")==1 and "تم النسخ" in pg.locator("#toast").inner_text())
    # --- share: Capacitor plugin, Web Share API, WhatsApp link fallback
    pg.evaluate("window.__s=[];window.Capacitor={Plugins:{Share:{share:o=>{window.__s.push(o.text);return Promise.resolve()}}}};0")
    pg.click('[data-a="share"] >> nth=0');pg.wait_for_timeout(150);ok("share via Capacitor Share plugin",pg.evaluate("window.__s.length")==1)
    pg.evaluate("delete window.Capacitor;window.__n=[];navigator.share=t=>{window.__n.push(t.text);return Promise.resolve()};0")
    pg.click('[data-a="share"] >> nth=0');pg.wait_for_timeout(150);ok("share via Web Share API",pg.evaluate("window.__n.length")==1)
    pg.evaluate("navigator.share=undefined;window.__o=[];window.open=(u)=>{window.__o.push(u)};0")
    pg.click('[data-a="share"] >> nth=0');pg.wait_for_timeout(150);ok("share fallback opens wa.me link",pg.evaluate("window.__o.length")==1 and "wa.me" in pg.evaluate("window.__o[0]"))
    ok("no JavaScript console errors",not errs)
    ctx.close()
    # --- screen sizes: no horizontal overflow, touch targets >= 40px
    for name,(w,h) in {"360x640":(360,640),"412x915":(412,915),"768x1024":(768,1024),"1280x800":(1280,800)}.items():
        c=b.new_context(viewport={"width":w,"height":h},has_touch=w<800);q=c.new_page();q.goto(URL);q.wait_for_selector("#app > *");bad=0;small=0
        for v in ["home","browse","today","favs"]:
            q.click(f'nav button[data-v="{v}"]');q.wait_for_timeout(150)
            bad+=q.evaluate("document.documentElement.scrollWidth>window.innerWidth+1")
            small+=q.evaluate("[...document.querySelectorAll('button,input,textarea')].filter(e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height<39.5}).length")
        ok(f"{name}: no overflow, no small touch targets",bad==0 and small==0);c.close()
    # --- PWA: manifest, icons, service worker, offline
    ctx=b.new_context(viewport={"width":390,"height":800});q=ctx.new_page();q.goto(URL);q.wait_for_selector("#app > *")
    m=json.load(open(os.path.join(WWW,"manifest.webmanifest"),encoding="utf-8"))
    ok("manifest: name/short_name/rtl/standalone",m["short_name"]=="بنفسج" and m["dir"]=="rtl" and m["display"]=="standalone")
    ok("manifest icons exist (192, 512, maskable)",all(os.path.exists(os.path.join(WWW,i["src"])) for i in m["icons"]) and any(i["purpose"]=="maskable" for i in m["icons"]))
    q.evaluate("navigator.serviceWorker.ready");q.reload();q.wait_for_function("navigator.serviceWorker.controller!==null",timeout=10000)
    ok("service worker active and controlling the page",True)
    ctx.set_offline(True);q.reload();q.wait_for_selector("#app .hero",timeout=10000)
    q.click('nav button[data-v="browse"]');q.wait_for_selector(".card");q.click('[data-a="f"][data-f="proverb"]');q.wait_for_selector(".card")
    ok("works offline after first visit (reload + browse)",q.locator("#cnt").inner_text().startswith("200"))
    ctx.set_offline(False);ctx.close();b.close()
for n,c in res:print(("PASS " if c else "FAIL ")+n)
print(f"passed {sum(c for _,c in res)}/{len(res)} | console errors: {errs[:3]}")
sys.exit(0 if all(c for _,c in res) else 1)
