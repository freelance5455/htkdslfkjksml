# 💜 بنفسج — مشروع جاهز لـ PWA وتطبيق أندرويد (Capacitor)

مكتبة عربية RTL للكلمات: اقتباسات، حكم، أمثال، أدعية، زواجل، عبارات، رسائل، حالات، شعر، خواطر، مناسبات، ألغاز، مفردات سودانية.
التطبيق ملف واحد مستقل (`www/index.html`) يحمل مكتبته داخله، فيعمل دون خادم ودون إنترنت.

## بنية المشروع
```
binafsaj-app/
├─ www/                 ← التطبيق (هذا ما يُغلَّف داخل APK ويُنشر كـPWA)
│  ├─ index.html        التطبيق + البيانات (كتلة JSON لكل نوع، تُحلَّل عند الحاجة)
│  ├─ manifest.webmanifest   اسم «بنفسج»، RTL، standalone، الأيقونات
│  ├─ sw.js             Service Worker (الشبكة أولًا للصفحة، ويُغيَّر اسم الذاكرة تلقائيًا مع كل تحديث)
│  └─ icons/            192 و512 وmaskable وapple-touch وfavicon
├─ assets/              مصادر الأيقونة وشاشة البداية لأداة @capacitor/assets
├─ capacitor.config.json   appId = app.binafsaj.words ، appName = بنفسج
├─ package.json
├─ data/                نسخة JSON منظّمة من المحتوى + registry.json (الأهداف والأعداد)
└─ tests/project_test.py   اختبارات المتصفح (27 اختبارًا)
```

## الخيار 1: نشر PWA
1. ارفع محتويات `www/` كما هي على أي استضافة ثابتة تدعم HTTPS (GitHub Pages أو Netlify أو غيرهما).
2. افتح الرابط من Chrome على أندرويد ← القائمة ← «تثبيت التطبيق» / «إضافة إلى الشاشة الرئيسية».
3. لتجربة محلية: `npm run serve` ثم افتح `http://localhost:8080`.
التحديثات تصل تلقائيًا: الصفحة تُجلب من الشبكة أولًا، واسم الذاكرة المؤقتة مرتبط بمحتوى الملف.

## الخيار 2: بناء APK بـ Capacitor
**المتطلبات على جهازك:** Node 18+ ، JDK 17 ، Android Studio (أو Android SDK مع `ANDROID_HOME`) ، والإنترنت لتنزيل الحزم.
```bash
cd binafsaj-app
npm install
npx cap add android            # ينشئ مجلد android/
npm run assets                 # يولّد أيقونات وشاشات البداية من assets/
npx cap sync android           # ينسخ www/ إلى المشروع الأصلي
cd android
./gradlew assembleDebug        # ويندوز: gradlew.bat assembleDebug
```
الناتج: `android/app/build/outputs/apk/debug/app-debug.apk`
التثبيت على هاتف موصول بـUSB (وضع المطوّر مفعّل): `adb install -r app/build/outputs/apk/debug/app-debug.apk`
أو افتح المشروع في Android Studio: `npm run open` ثم Run.

**نسخة موقّعة للنشر:** من Android Studio: Build ← Generate Signed App Bundle / APK، وأنشئ مفتاحًا جديدًا واحفظه وكلمة مروره خارج المشروع (الملفات `*.jks` و`*.keystore` مستثناة في `.gitignore`). غيّر `appId` في `capacitor.config.json` إلى معرّف يخصّك قبل النشر على Google Play.

**الصلاحيات:** قالب Capacitor يضيف صلاحية `INTERNET` فقط. التطبيق لا يحتاجها فعليًا (كل شيء محلي)، ويمكنك حذفها من `android/app/src/main/AndroidManifest.xml` إن أردت (لم أجرّب ذلك).

## ما يفعله التطبيق داخل أندرويد
- المشاركة: عبر `@capacitor/share` (لأن WebView لا يدعم Web Share)، ثم Web Share، ثم رابط واتساب كحل أخير.
- النسخ: Clipboard API ثم `execCommand` عند عدم توفرها.
- زر الرجوع في أندرويد ينتقل بين الصفحات (سجلّ التنقل) ولا يغلق التطبيق إلا من الرئيسية.
- المفضلة تُحفظ في التخزين المحلي للتطبيق وتبقى بعد الإغلاق.

## إضافة محتوى جديد
المحتوى مضمَّن في `www/index.html` في كتلة لكل نوع (`<script type="application/json" id="d-quote">`). حقول العنصر: `i` معرّف رقمي فريد وثابت (تعتمد عليه المفضلة، فلا تغيّره ولا تعيد استخدامه)، `c` التصنيف، `x` النص، `s` المصدر (يُحذف إن كان «من صياغة بنفسج»)، `g` وسوم، `a` مؤلف، `m` معنى/إجابة، `v` حالة النسبة. عند الإضافة زِد العدد في `<script id="meta">` وحدّث `data/*.json` و`data/registry.json`.

## الاختبار
```bash
pip install playwright && playwright install chromium
python3 tests/project_test.py
```
يختبر: تحميل المكتبة والأقسام (19)، البحث الكامل والجزئي ورسالة «لا نتائج»، زر الرجوع، المفضلة بعد إعادة التحميل، النسخ والمشاركة (بدائلها الثلاثة)، أحجام الشاشات (360 و412 و768 و1280)، الـmanifest والأيقونات، الـService Worker، والعمل دون اتصال.

## حدود معروفة (لم أتحقق منها هنا)
- لم يُبنَ APK فعليًا: بيئة العمل التي جُهّز فيها المشروع بلا Android SDK ولا وصول إلى npm، فالأوامر أعلاه لم تُنفَّذ.
- لم يُختبر على جهاز أندرويد حقيقي (الاختبارات على Chromium).
- إصدارات Capacitor مثبّتة على 6.x؛ إن استخدمت إصدارًا أحدث فراجع دليل الترقية.
- ما زالت بعض الأقسام دون أهدافها (انظر `data/registry.json`): الشعر والمفردات السودانية والأمثال والأدعية.
