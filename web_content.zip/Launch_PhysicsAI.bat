@echo off
cd /d "%~dp0"
start "" chrome.exe --app="file:///%CD%/index.html"
if errorlevel 1 start "" msedge.exe --app="file:///%CD%/index.html"
