import { estimateYouTubeQuota, searchFans } from '../core/search';
import { createStore, type KV } from '../core/store';
import { installNativeFetch } from './nativehttp';
import { createAuthStore, freshToken, googleChannelName, googlePoll, googleRevoke, googleStart, parseRedditCallback, redditAuthUrl, redditExchange, redditName, type DeviceCode, type Provider } from '../core/auth';
import { redditMessage, youtubeCommentId, youtubeReply } from '../core/actions';
import { activePage, facebookReply, instagramReply, metaConnect } from '../core/meta';
import { buildManualFan } from '../core/manual';
import { shortcuts } from '../core/shortcuts';
import { SOURCE_LABEL, STATUSES, type FanCandidate, type FanStatus, type SearchResponse, type Source } from '../core/types';

installNativeFetch();

// ---------- almacenamiento (con respaldo en memoria si el WebView lo bloquea) ----------
function safeKV(): KV {
  try {
    const t = '__fr_test__';
    localStorage.setItem(t, '1');
    localStorage.removeItem(t);
    return localStorage;
  } catch {
    const m = new Map<string, string>();
    return { getItem: (k) => m.get(k) ?? null, setItem: (k, v) => void m.set(k, v), removeItem: (k) => void m.delete(k) };
  }
}
const kv = safeKV();
const store = createStore(kv);
const auth = createAuthStore(kv);
const REDDIT_STATE_KEY = 'fanradar.reddit.state';

interface Settings {
  youtubeKey: string;
  redditId: string;
  redditSecret: string;
  googleClientId: string;
  googleClientSecret: string;
  redditClientId: string;
  bandName: string;
  songUrl: string;
  bands: string;
  genre: string;
  city: string;
  subreddits: string;
  ytOn: boolean;
  rdOn: boolean;
  igOn: boolean;
  fbOn: boolean;
  hashtags: string;
  metaAppId: string;
  metaAppSecret: string;
  metaUserToken: string;
  maxVideoViews: number;
  videosPerBand: number;
}
const SETTINGS_KEY = 'fanradar.settings.v1';
const DEFAULTS: Settings = {
  youtubeKey: '',
  redditId: '',
  redditSecret: '',
  googleClientId: '',
  googleClientSecret: '',
  redditClientId: '',
  bandName: '',
  songUrl: '',
  bands: '',
  genre: 'death thrash metal',
  city: 'Ciudad de México',
  subreddits: 'deathmetal, thrashmetal, MetalMexico',
  ytOn: true,
  rdOn: true,
  igOn: false,
  fbOn: false,
  hashtags: 'deaththrash, thrashmetal, metalmexico',
  metaAppId: '',
  metaAppSecret: '',
  metaUserToken: '',
  maxVideoViews: 20000,
  videosPerBand: 3,
};
function loadSettings(): Settings {
  try {
    return { ...DEFAULTS, ...JSON.parse(kv.getItem(SETTINGS_KEY) ?? '{}') };
  } catch {
    return { ...DEFAULTS };
  }
}
let settings = loadSettings();
function saveSettings(patch: Partial<Settings>) {
  settings = { ...settings, ...patch };
  try {
    kv.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    toast('No se pudo guardar (almacenamiento lleno o bloqueado)');
  }
}

// ---------- utilidades de DOM (todo el texto externo va como texto, nunca como HTML) ----------
type Kid = Node | string | null | false | undefined;
function h<K extends keyof HTMLElementTagNameMap>(tag: K, props: Record<string, any> = {}, ...kids: Kid[]): HTMLElementTagNameMap[K] {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on') && typeof v === 'function') (el as any)[k] = v;
    else if (k === 'value' || k === 'checked') (el as any)[k] = v;
    else el.setAttribute(k, v === true ? '' : String(v));
  }
  for (const kid of kids) if (kid) el.append(kid);
  return el;
}
const safeUrl = (u: string) => (/^https:\/\//i.test(u) ? u : '#');
const link = (href: string, text: string) => h('a', { href: safeUrl(href), target: '_blank', rel: 'noopener noreferrer' }, text);
const fmtDate = (iso?: string) => {
  const t = iso ? Date.parse(iso) : NaN;
  return Number.isFinite(t) ? new Date(t).toLocaleDateString('es-MX') : '';
};

let toastTimer: number | undefined;
function toast(msg: string) {
  document.querySelector('.toast')?.remove();
  document.body.append(h('div', { class: 'toast', role: 'status' }, msg));
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => document.querySelector('.toast')?.remove(), Math.max(2600, msg.length * 55));
}

const ids = () => ({
  googleClientId: settings.googleClientId.trim(),
  googleClientSecret: settings.googleClientSecret.trim(),
  redditClientId: settings.redditClientId.trim(),
});

function openExternal(url: string) {
  if (window.AndroidHttp?.open) window.AndroidHttp.open(url);
  else window.open(url, '_blank', 'noopener');
}

async function copyText(text: string): Promise<boolean> {
  try {
    if (window.AndroidHttp?.copy) {
      window.AndroidHttp.copy(text);
      return true;
    }
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = h('textarea', { style: 'position:fixed;opacity:0;top:0' });
    ta.value = text;
    document.body.append(ta);
    ta.select();
    let ok = false;
    try {
      ok = document.execCommand('copy');
    } catch {
      /* nada */
    }
    ta.remove();
    return ok;
  }
}

const STATUS_LABEL: Record<FanStatus, string> = { NEW: 'Nuevo', CONTACTED: 'Contactado', REPLIED: 'Respondió', FAN: 'Fan', DISCARDED: 'Descartado' };
const splitList = (s: string) => s.split(/[\n,;]+/).map((x) => x.trim()).filter(Boolean);

// ---------- tarjeta de candidato ----------
const isMetaSource = (c: FanCandidate) => c.source === 'instagram' || c.source === 'facebook';
const metaToken = () => activePage(auth.get().meta)?.token ?? null;

function buildMessage(c: FanCandidate): string {
  const first = c.displayName.replace(/^u\//, '').replace(/^@/, '');
  const genre = settings.genre.trim() || '[género]';
  const mine = settings.bandName.trim() || '[tu banda]';
  const song = settings.songUrl.trim() || '[enlace a una canción]';
  // Quien comentó en TUS publicaciones (Instagram/Facebook): agradecer, no "vi tu comentario sobre otra banda".
  if (isMetaSource(c) && c.evidence.some((e) => e.refId)) {
    return `Hola ${first}, gracias por tu comentario. Hacemos ${genre} con ${mine}; aquí va una canción por si quieres escucharla: ${song}`;
  }
  const band = c.evidence[0]?.band && c.evidence[0].band !== 'manual' ? c.evidence[0].band : c.bands[0];
  const where = c.source === 'youtube' || c.source === 'tiktok' ? 'video' : c.source === 'reddit' ? 'post' : 'publicación';
  const seen = band ? `Hola ${first}. Vi tu comentario en un ${where} sobre ${band}.` : `Hola ${first}.`;
  return `${seen} Hago ${genre} con ${mine} y creo que podría gustarte. Aquí está una canción: ${song}. Gracias por escuchar música nueva.`;
}

type Channel = { label: string; provider: 'google' | 'reddit' | 'meta' };
/** Cómo se puede contactar por API desde la app (null = solo abrir el perfil y copiar el mensaje). */
function apiChannel(c: FanCandidate): Channel | null {
  switch (c.source) {
    case 'youtube':
      return { label: 'Responder en YouTube', provider: 'google' };
    case 'reddit':
      return { label: 'Mensaje en Reddit', provider: 'reddit' };
    case 'instagram':
      return c.evidence.some((e) => e.refId) ? { label: 'Responder en Instagram', provider: 'meta' } : null;
    case 'facebook':
      return c.evidence.some((e) => e.refId) ? { label: 'Responder en Facebook', provider: 'meta' } : null;
    default:
      return null;
  }
}
const hasSession = (p: Channel['provider']) => (p === 'meta' ? !!activePage(auth.get().meta) : !!auth.get()[p]);

function composePanel(c: FanCandidate, onSent: () => void, onClose: () => void): HTMLElement {
  const ch = apiChannel(c)!;
  const isYT = c.source === 'youtube';
  const isRD = c.source === 'reddit';
  const ev = isMetaSource(c) ? c.evidence.find((e) => e.refId) : c.evidence[0];
  const parentId = isYT ? youtubeCommentId(ev?.url ?? '') : isRD ? null : ev?.refId ?? null;
  if (!isRD && !parentId) return h('p', { class: 'hint' }, 'No encontré el id del comentario para responder. Ábrelo con “abrir prueba”.');

  const subject = h('input', { type: 'text', value: `Si te gusta ${ev?.band ?? c.bands[0] ?? 'el metal'}`, maxlength: 100 });
  const ta = h('textarea', { 'aria-label': 'Mensaje' });
  ta.value = buildMessage(c);
  const send = h(
    'button',
    {
      class: 'btn small',
      type: 'button',
      onclick: async () => {
        const text = ta.value.trim();
        if (!text) return toast('Escribe el mensaje');
        const what = isRD
          ? `¿Enviar un mensaje privado a ${c.displayName} en Reddit?`
          : `¿Responder PÚBLICAMENTE al comentario de ${c.displayName} en ${SOURCE_LABEL[c.source]}?`;
        const prior = c.status !== 'NEW' ? `\n\nOJO: ya está marcado como “${STATUS_LABEL[c.status]}”.` : '';
        if (!window.confirm(`${what}\n\n${text}${prior}`)) return;
        send.disabled = true;
        send.textContent = 'Enviando…';
        try {
          const token = ch.provider === 'meta' ? metaToken() : await freshToken(ch.provider, auth, ids());
          if (!token) throw new Error('Inicia sesión en Ajustes → Cuentas.');
          if (isYT) await youtubeReply(token, parentId!, text);
          else if (isRD) await redditMessage(token, c.displayName, subject.value.trim() || 'Hola', text);
          else if (c.source === 'instagram') await instagramReply(token, parentId!, text);
          else await facebookReply(token, parentId!, text);
          if (c.status === 'NEW') store.setStatus(c.id, 'CONTACTED');
          toast('Enviado');
          onSent();
        } catch (e: any) {
          toast(e.message ?? 'No se pudo enviar');
          send.disabled = false;
          send.textContent = 'Enviar';
        }
      },
    },
    'Enviar',
  );
  return h(
    'div',
    { class: 'compose' },
    isRD
      ? h('label', {}, 'Asunto', subject)
      : h('p', { class: 'hint' }, 'Se publicará como respuesta pública a: “', ev?.text.slice(0, 80) ?? '', '”.', isYT ? ' Cuesta 50 unidades de cuota.' : ''),
    ta,
    h('div', { class: 'actions' }, send, h('button', { class: 'btn ghost small', type: 'button', onclick: onClose }, 'Cancelar')),
  );
}

function card(c: FanCandidate, rerender: () => void): HTMLElement {
  const composeHost = h('div', {});
  const scoreCls = c.score >= 60 ? 'hi' : c.score >= 40 ? 'mid' : '';
  const ch = apiChannel(c);
  const statusRow = h(
    'div',
    { class: 'status', role: 'group', 'aria-label': 'Estado' },
    ...STATUSES.map((s) =>
      h(
        'button',
        {
          type: 'button',
          'aria-pressed': c.status === s ? 'true' : 'false',
          onclick: () => {
            store.setStatus(c.id, s);
            rerender();
          },
        },
        STATUS_LABEL[s],
      ),
    ),
  );
  return h(
    'article',
    { class: 'card' },
    h(
      'header',
      {},
      h('div', { class: 'name' }, link(c.profileUrl, c.displayName), h('div', { class: 'src' }, SOURCE_LABEL[c.source], ' · ', fmtDate(c.foundAt))),
      h('div', { class: `score ${scoreCls}`, title: 'Probabilidad de ser fan (0-100)' }, String(c.score)),
    ),
    h('ul', { class: 'reasons' }, ...c.reasons.map((r) => h('li', {}, r))),
    h('div', { class: 'chips' }, ...c.bands.map((b) => h('span', { class: 'chip' }, b))),
    h(
      'details',
      {},
      h('summary', {}, `Pruebas (${c.evidence.length})`),
      ...c.evidence.map((e) =>
        h(
          'div',
          { class: 'ev' },
          e.text ? h('p', {}, `“${e.text}”`) : null,
          h('small', {}, `${e.band} · ${e.likes ?? 0} likes · ${fmtDate(e.publishedAt)} · `, link(e.url, 'abrir prueba')),
        ),
      ),
    ),
    statusRow,
    h(
      'div',
      { class: 'actions' },
      ch
        ? h(
            'button',
            {
              class: 'btn small',
              type: 'button',
              onclick: () => {
                if (!hasSession(ch.provider)) return toast('Inicia sesión o conecta la cuenta en Ajustes → Cuentas');
                composeHost.replaceChildren(composePanel(c, rerender, () => composeHost.replaceChildren()));
              },
            },
            ch.label,
          )
        : h('button', { class: 'btn small', type: 'button', onclick: () => openExternal(c.profileUrl) }, 'Abrir perfil'),
      h(
        'button',
        {
          class: 'btn ghost small',
          type: 'button',
          onclick: async () => {
            const ok = await copyText(buildMessage(c));
            toast(ok ? 'Mensaje copiado.' : 'No se pudo copiar');
          },
        },
        'Copiar mensaje',
      ),
    ),
    composeHost,
  );
}

// ---------- pantallas ----------
type Tab = 'buscar' | 'fans' | 'ajustes';
let tab: Tab = 'buscar';
let filter: FanStatus | 'ALL' = 'ALL';
let manualOpen = false;
const manualDraft = { source: 'instagram' as Source, who: '', band: '', note: '', evidenceUrl: '' };
let lastResult: SearchResponse | null = null;
let lastSaved: { added: number; updated: number } | null = null;
let busy = false;
let progressMsg = '';

const root = document.getElementById('app')!;

function viewBuscar(): HTMLElement {
  const bandsEl = h('textarea', { placeholder: 'Una por línea o separadas por coma\nBanda A\nBanda B\nBanda C', value: settings.bands, 'aria-label': 'Bandas parecidas' });
  const quotaEl = h('p', { class: 'hint' });
  const updateQuota = () => {
    const n = Math.min(8, splitList(bandsEl.value).length);
    quotaEl.replaceChildren(
      n ? `YouTube gastará ≈ ` : 'Escribe de 3 a 6 bandas. ',
      n ? h('b', {}, String(estimateYouTubeQuota(n))) : '',
      n ? ' de 10,000 unidades diarias.' : 'Quien aparece en 2 o más es el candidato más valioso.',
    );
  };
  const termsBox = h('div', {});
  const refreshTerms = () => {
    const terms = [...new Set([...splitList(bandsEl.value), settings.genre.trim(), ...splitList(settings.hashtags)].filter(Boolean))];
    termsBox.replaceChildren(
      ...terms.map((t) =>
        h('div', { class: 'term' }, h('b', {}, t), h('div', { class: 'chips' }, ...shortcuts(t).map((x) => h('button', { class: 'chip', type: 'button', onclick: () => openExternal(x.url) }, x.label)))),
      ),
    );
  };
  bandsEl.oninput = () => {
    saveSettings({ bands: bandsEl.value });
    updateQuota();
    refreshTerms();
  };
  updateQuota();

  const genre = h('input', { type: 'text', value: settings.genre, oninput: (e: Event) => { saveSettings({ genre: (e.target as HTMLInputElement).value }); refreshTerms(); } });
  const hashtags = h('input', { type: 'text', value: settings.hashtags, placeholder: 'deaththrash, thrashmetal', oninput: (e: Event) => { saveSettings({ hashtags: (e.target as HTMLInputElement).value }); refreshTerms(); } });
  const metaPage = activePage(auth.get().meta);
  const ig = h('input', { type: 'checkbox', checked: settings.igOn && !!metaPage?.igId, disabled: !metaPage?.igId, onchange: (e: Event) => saveSettings({ igOn: (e.target as HTMLInputElement).checked }) });
  const fb = h('input', { type: 'checkbox', checked: settings.fbOn && !!metaPage, disabled: !metaPage, onchange: (e: Event) => saveSettings({ fbOn: (e.target as HTMLInputElement).checked }) });
  const city = h('input', { type: 'text', value: settings.city, oninput: (e: Event) => saveSettings({ city: (e.target as HTMLInputElement).value }) });
  const subs = h('input', { type: 'text', value: settings.subreddits, oninput: (e: Event) => saveSettings({ subreddits: (e.target as HTMLInputElement).value }) });
  const yt = h('input', { type: 'checkbox', checked: settings.ytOn, onchange: (e: Event) => saveSettings({ ytOn: (e.target as HTMLInputElement).checked }) });
  const rd = h('input', { type: 'checkbox', checked: settings.rdOn, onchange: (e: Event) => saveSettings({ rdOn: (e.target as HTMLInputElement).checked }) });
  const maxViews = h('input', { type: 'number', inputmode: 'numeric', min: 100, value: settings.maxVideoViews, oninput: (e: Event) => saveSettings({ maxVideoViews: Number((e.target as HTMLInputElement).value) || DEFAULTS.maxVideoViews }) });
  const vids = h('input', { type: 'number', inputmode: 'numeric', min: 1, max: 10, value: settings.videosPerBand, oninput: (e: Event) => saveSettings({ videosPerBand: Math.min(10, Math.max(1, Number((e.target as HTMLInputElement).value) || 3)) }) });

  refreshTerms();
  const progress = h('div', { class: 'progress', 'aria-live': 'polite' }, progressMsg);
  const results = h('div', {});

  const btn = h(
    'button',
    {
      class: 'btn',
      type: 'button',
      disabled: busy,
      onclick: async () => {
        if (busy) return;
        const bands = splitList(bandsEl.value);
        const useIg = settings.igOn && !!metaPage?.igId;
        const useFb = settings.fbOn && !!metaPage;
        if (!settings.ytOn && !settings.rdOn && !useIg && !useFb) return toast('Activa al menos una fuente');
        if ((settings.ytOn || settings.rdOn) && !bands.length) return toast('Escribe al menos una banda parecida');
        const sources: Source[] = [
          ...(settings.ytOn ? (['youtube'] as const) : []),
          ...(settings.rdOn ? (['reddit'] as const) : []),
          ...(useIg ? (['instagram'] as const) : []),
          ...(useFb ? (['facebook'] as const) : []),
        ];
        busy = true;
        btn.disabled = true;
        btn.textContent = 'Buscando…';
        results.replaceChildren();
        try {
          const warn: string[] = [];
          let youtubeToken: string | undefined;
          let redditToken: string | undefined;
          try {
            youtubeToken = (await freshToken('google', auth, ids())) ?? undefined;
          } catch (e: any) {
            warn.push(e.message);
          }
          try {
            redditToken = (await freshToken('reddit', auth, ids())) ?? undefined;
          } catch (e: any) {
            warn.push(e.message);
          }
          const res = await searchFans(
            {
              bands,
              genre: settings.genre.trim() || undefined,
              city: settings.city.trim() || undefined,
              subreddits: splitList(settings.subreddits),
              sources,
              maxVideoViews: settings.maxVideoViews,
              videosPerBand: settings.videosPerBand,
            },
            { youtubeKey: settings.youtubeKey.trim(), redditId: settings.redditId.trim(), redditSecret: settings.redditSecret.trim(), youtubeToken, redditToken, meta: metaPage ? { page: metaPage, label: settings.bandName.trim() || 'tu cuenta' } : undefined },
            (m) => {
              progressMsg = m;
              progress.textContent = m;
            },
          );
          res.stats.errors.unshift(...warn);
          lastResult = res;
          lastSaved = store.upsertMany(res.candidates);
        } catch (e: any) {
          lastResult = null;
          toast(e?.message ?? 'Error al buscar');
        } finally {
          busy = false;
          progressMsg = '';
          if (tab === 'buscar') render();
        }
      },
    },
    busy ? 'Buscando…' : 'Buscar fans',
  );

  if (lastResult) results.append(resultsView(lastResult));

  return h(
    'section',
    {},
    h('label', {}, 'Bandas parecidas a la tuya (de tamaño similar)'),
    bandsEl,
    quotaEl,
    h('label', {}, 'Género'),
    genre,
    h('div', { class: 'row' }, h('div', {}, h('label', {}, 'Ciudad'), city)),
    h('label', {}, 'Subreddits (sin r/)'),
    subs,
    h('div', { class: 'checks' }, h('label', {}, yt, 'YouTube'), h('label', {}, rd, 'Reddit')),
    h('div', { class: 'checks' }, h('label', {}, ig, 'Instagram (tu cuenta)'), h('label', {}, fb, 'Facebook (tu Página)')),
    metaPage ? null : h('p', { class: 'hint' }, 'Instagram y Facebook leen a quienes comentan en TUS publicaciones: conecta Meta en Ajustes → Cuentas.'),
    h(
      'details',
      { class: 'adv' },
      h('summary', {}, 'Opciones avanzadas'),
      h('div', { class: 'row' }, h('div', {}, h('label', {}, 'Máx. vistas por video'), maxViews), h('div', {}, h('label', {}, 'Videos por banda'), vids)),
      h('p', { class: 'hint' }, 'Baja las vistas (p. ej. 20,000) para ir a videos chicos donde comentan fans que descubren música; súbelas si salen pocos resultados.'),
    ),
    btn,
    progress,
    results,
    h(
      'details',
      { class: 'adv' },
      h('summary', {}, 'Explorar en Instagram, TikTok y Facebook'),
      h('p', { class: 'hint' }, 'Estas redes no permiten buscar fans automáticamente. Abre una búsqueda, encuentra a quienes comentan o publican sobre bandas parecidas y agrégalos con “＋ Agregar fan manual”.'),
      h('label', {}, 'Hashtags extra (sin #)'),
      hashtags,
      termsBox,
      h('button', { class: 'btn ghost small', type: 'button', style: 'margin-top:12px', onclick: () => { tab = 'fans'; manualOpen = true; render(); window.scrollTo(0, 0); } }, '＋ Agregar fan manual'),
    ),
  );
}

function resultsView(res: SearchResponse): HTMLElement {
  const ids = new Set(res.candidates.map((c) => c.id));
  const current = store.listAll().filter((c) => ids.has(c.id));
  const s = res.stats;
  return h(
    'div',
    {},
    h(
      'div',
      { class: 'summary' },
      h('b', {}, `${s.unique} candidatos`),
      ` (${s.raw} resultados crudos)`,
      lastSaved ? ` · ${lastSaved.added} nuevos, ${lastSaved.updated} ya existían` : '',
      s.errors.length ? h('ul', { class: 'errs' }, ...s.errors.map((e) => h('li', {}, e))) : null,
    ),
    current.length ? null : h('p', { class: 'empty' }, 'Sin candidatos. Sube “Máx. vistas por video”, agrega bandas o quita el género si es muy específico.'),
    ...current.map((c) => card(c, render)),
  );
}

function manualForm(): HTMLElement {
  const sel = h('select', { 'aria-label': 'Red', onchange: (e: Event) => { manualDraft.source = (e.target as HTMLSelectElement).value as Source; } }, ...(['instagram', 'tiktok', 'facebook', 'youtube', 'reddit'] as Source[]).map((k) => h('option', { value: k, selected: manualDraft.source === k }, SOURCE_LABEL[k])));
  const bind = (k: 'who' | 'band' | 'note' | 'evidenceUrl') => (e: Event) => { manualDraft[k] = (e.target as HTMLInputElement).value; };
  const note = h('textarea', { placeholder: 'Qué comentó o publicó (opcional)', oninput: bind('note') });
  note.value = manualDraft.note;
  return h(
    'div',
    { class: 'compose' },
    h('label', {}, 'Red'),
    sel,
    h('label', {}, 'Usuario o enlace de su perfil'),
    h('input', { type: 'text', value: manualDraft.who, placeholder: '@usuario o https://…', autocomplete: 'off', autocapitalize: 'off', oninput: bind('who') }),
    h('label', {}, 'Banda parecida con la que se relaciona (opcional)'),
    h('input', { type: 'text', value: manualDraft.band, oninput: bind('band') }),
    h('label', {}, 'Nota'),
    note,
    h('label', {}, 'Enlace a su comentario o publicación (opcional)'),
    h('input', { type: 'url', value: manualDraft.evidenceUrl, placeholder: 'https://…', oninput: bind('evidenceUrl') }),
    h(
      'div',
      { class: 'actions' },
      h(
        'button',
        {
          class: 'btn small',
          type: 'button',
          onclick: () => {
            try {
              const r = store.addManual(buildManualFan(manualDraft));
              toast(r === 'added' ? 'Fan agregado' : 'Ya existía: se sumó la prueba');
              Object.assign(manualDraft, { who: '', band: '', note: '', evidenceUrl: '' });
              manualOpen = false;
              render();
            } catch (e: any) {
              toast(e.message);
            }
          },
        },
        'Guardar',
      ),
    ),
  );
}

function viewFans(): HTMLElement {
  const all = store.listAll();
  const counts: Record<string, number> = { ALL: all.length };
  for (const s of STATUSES) counts[s] = all.filter((c) => c.status === s).length;
  const list = filter === 'ALL' ? all : all.filter((c) => c.status === filter);
  const chip = (k: FanStatus | 'ALL', label: string) =>
    h('button', { type: 'button', 'aria-pressed': filter === k ? 'true' : 'false', onclick: () => { filter = k; render(); } }, `${label} ${counts[k]}`);
  return h(
    'section',
    {},
    h('button', { class: 'btn ghost small', type: 'button', style: 'margin-top:8px', onclick: () => { manualOpen = !manualOpen; render(); } }, manualOpen ? 'Cerrar formulario' : '＋ Agregar fan manual'),
    manualOpen ? manualForm() : null,
    h('div', { class: 'filters' }, chip('ALL', 'Todos'), ...STATUSES.map((s) => chip(s, STATUS_LABEL[s]))),
    list.length ? null : h('p', { class: 'empty' }, all.length ? 'No hay fans con este estado.' : 'Aún no hay fans guardados. Haz una búsqueda.'),
    ...list.map((c) => card(c, render)),
    all.length ? h('p', { class: 'hint' }, 'Cada envío es uno por uno y lo confirmas tú. Un solo enlace, y evita copiar el mismo texto a todos: las plataformas penalizan la promoción no solicitada.') : null,
  );
}

// ---------- cuentas: Google (flujo de dispositivos) y Reddit (OAuth con retorno a la app) ----------
let googleFlow: { dc: DeviceCode; cancelled: boolean } | null = null;

async function loginGoogle() {
  const { googleClientId: clientId, googleClientSecret: clientSecret } = ids();
  if (!clientId || !clientSecret) return toast('Pega el Client ID y el Client secret de Google');
  let flow: { dc: DeviceCode; cancelled: boolean } | null = null;
  try {
    const dc = await googleStart(clientId);
    flow = { dc, cancelled: false };
    googleFlow = flow;
    await copyText(dc.userCode);
    render();
    toast(`Código ${dc.userCode} copiado: pégalo en Google`);
    openExternal(dc.verificationUrl);
    const t = await googlePoll({ clientId, clientSecret }, dc, { isCancelled: () => flow!.cancelled });
    const name = await googleChannelName(t.access).catch(() => undefined);
    auth.set('google', { ...t, name });
    toast(name ? `Google conectado: ${name}` : 'Google conectado (sin canal de YouTube: no podrás comentar)');
  } catch (e: any) {
    if (!flow?.cancelled) toast(e.message ?? 'No se pudo iniciar sesión');
  } finally {
    if (googleFlow === flow) googleFlow = null;
    if (tab === 'ajustes') render();
  }
}

function loginReddit() {
  const id = ids().redditClientId;
  if (!id) return toast('Pega el Client ID de tu app de Reddit');
  const state = Array.from(crypto.getRandomValues(new Uint8Array(12)), (b) => b.toString(16).padStart(2, '0')).join('');
  kv.setItem(REDDIT_STATE_KEY, state);
  toast('Autoriza en Reddit y regresa a FanRadar');
  openExternal(redditAuthUrl(id, state));
}

function handleOAuthCallback() {
  const uri = window.AndroidHttp?.takePendingOAuth?.();
  if (!uri) return;
  void (async () => {
    try {
      const code = parseRedditCallback(uri, kv.getItem(REDDIT_STATE_KEY));
      const t = await redditExchange(ids().redditClientId, code);
      const name = await redditName(t.access).catch(() => undefined);
      auth.set('reddit', { ...t, name });
      kv.removeItem(REDDIT_STATE_KEY);
      toast(`Reddit conectado${name ? `: u/${name}` : ''}`);
    } catch (e: any) {
      toast(e.message ?? 'No se pudo conectar Reddit');
    }
    tab = 'ajustes';
    render();
  })();
}
window.__oauthCheck = handleOAuthCallback;

function textField(label: string, key: keyof Settings, type = 'text', ph = ''): HTMLElement {
  return h(
    'div',
    {},
    h('label', {}, label),
    h('input', { type, value: String(settings[key]), placeholder: ph, autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', oninput: (e: Event) => saveSettings({ [key]: (e.target as HTMLInputElement).value } as Partial<Settings>) }),
  );
}

let metaBusy = false;
async function connectMeta() {
  const appId = settings.metaAppId.trim();
  const appSecret = settings.metaAppSecret.trim();
  const userToken = settings.metaUserToken.trim();
  if (!appId || !appSecret || !userToken) return toast('Pega el App ID, el App secret y el token de usuario');
  metaBusy = true;
  render();
  try {
    const session = await metaConnect({ appId, appSecret, userToken });
    auth.setMeta(session);
    saveSettings({ metaUserToken: '' });
    toast(`Meta conectado: ${activePage(session)!.name}`);
  } catch (e: any) {
    toast(e.message ?? 'No se pudo conectar Meta');
  } finally {
    metaBusy = false;
    if (tab === 'ajustes') render();
  }
}

function accountsView(): HTMLElement {
  const a = auth.get();

  const google = a.google
    ? h(
        'div',
        {},
        h('p', { class: 'ok' }, `Google conectado: ${a.google.name ?? 'cuenta sin canal de YouTube'}`),
        a.google.name ? null : h('p', { class: 'hint' }, 'Sin canal de YouTube no se puede comentar. Crea uno en youtube.com.'),
        h('button', { class: 'btn danger small', type: 'button', onclick: async () => { await googleRevoke(a.google!.access); auth.set('google', undefined); toast('Sesión de Google cerrada'); render(); } }, 'Cerrar sesión de Google'),
      )
    : googleFlow
      ? h(
          'div',
          {},
          h('p', {}, 'En Google escribe este código (ya está copiado):'),
          h('div', { class: 'code' }, googleFlow.dc.userCode),
          h('div', { class: 'actions' },
            h('button', { class: 'btn small', type: 'button', onclick: () => openExternal(googleFlow!.dc.verificationUrl) }, 'Abrir google.com/device'),
            h('button', { class: 'btn ghost small', type: 'button', onclick: () => { googleFlow!.cancelled = true; googleFlow = null; render(); } }, 'Cancelar'),
          ),
          h('p', { class: 'hint' }, 'Al aceptar en Google, vuelve aquí: la app detecta la autorización sola.'),
        )
      : h(
          'div',
          {},
          textField('Google Client ID', 'googleClientId', 'text', '…apps.googleusercontent.com'),
          textField('Google Client secret', 'googleClientSecret', 'password'),
          h('button', { class: 'btn small', type: 'button', style: 'margin-top:12px', onclick: loginGoogle }, 'Iniciar sesión con Google'),
          h(
            'details',
            { class: 'adv' },
            h('summary', {}, 'Cómo obtener el Client ID de Google'),
            h('ol', { class: 'hint' },
              h('li', {}, 'En console.cloud.google.com crea un proyecto y activa “YouTube Data API v3”.'),
              h('li', {}, 'Pantalla de consentimiento OAuth: tipo Externo; en “Usuarios de prueba” agrega tu correo.'),
              h('li', {}, 'Credenciales → Crear credenciales → ID de cliente de OAuth → tipo “TVs y dispositivos de entrada limitada”.'),
              h('li', {}, 'Copia aquí el Client ID y el Client secret. En modo “Prueba” la sesión caduca a los 7 días.'),
            ),
          ),
        );

  const reddit = a.reddit
    ? h(
        'div',
        {},
        h('p', { class: 'ok' }, `Reddit conectado${a.reddit.name ? `: u/${a.reddit.name}` : ''}`),
        h('button', { class: 'btn danger small', type: 'button', onclick: () => { auth.set('reddit', undefined); toast('Sesión de Reddit cerrada'); render(); } }, 'Cerrar sesión de Reddit'),
      )
    : h(
        'div',
        {},
        textField('Reddit Client ID', 'redditClientId'),
        h('button', { class: 'btn small', type: 'button', style: 'margin-top:12px', onclick: loginReddit }, 'Iniciar sesión con Reddit'),
        h(
          'details',
          { class: 'adv' },
          h('summary', {}, 'Cómo obtener el Client ID de Reddit'),
          h('ol', { class: 'hint' },
            h('li', {}, 'Entra a reddit.com/prefs/apps → “create another app”.'),
            h('li', {}, 'Tipo: “installed app”. Redirect uri: fanradar://reddit'),
            h('li', {}, 'Copia el ID que aparece bajo el nombre de la app.'),
          ),
        ),
      );

  const meta = auth.get().meta;
  const mp = activePage(meta);
  const metaBlock = mp
    ? h(
        'div',
        {},
        h('p', { class: 'ok' }, `Meta conectado: ${mp.name}${mp.igUsername ? ` · Instagram @${mp.igUsername}` : ' · sin Instagram profesional ligado'}`),
        meta!.pages.length > 1
          ? h('div', {}, h('label', {}, 'Página activa'), h('select', { onchange: (e: Event) => { auth.setMeta({ ...meta!, selected: (e.target as HTMLSelectElement).value }); render(); } }, ...meta!.pages.map((p) => h('option', { value: p.id, selected: p.id === mp.id }, `${p.name}${p.igUsername ? ` (@${p.igUsername})` : ''}`))))
          : null,
        h('button', { class: 'btn danger small', type: 'button', style: 'margin-top:12px', onclick: () => { auth.setMeta(undefined); toast('Meta desconectado'); render(); } }, 'Desconectar Meta'),
        h('p', { class: 'hint' }, 'Para revocar el acceso por completo: Facebook → Configuración → Integraciones de empresa.'),
      )
    : h(
        'div',
        {},
        h('p', { class: 'hint' }, 'Instagram y Facebook (Meta): leer comentarios de tus publicaciones y responderlos.'),
        textField('Meta App ID', 'metaAppId'),
        textField('Meta App secret', 'metaAppSecret', 'password'),
        textField('Token de usuario (del Explorador de la Graph API)', 'metaUserToken', 'password'),
        h('button', { class: 'btn small', type: 'button', style: 'margin-top:12px', disabled: metaBusy, onclick: connectMeta }, metaBusy ? 'Conectando…' : 'Conectar Meta'),
        h(
          'details',
          { class: 'adv' },
          h('summary', {}, 'Cómo conectar Instagram y Facebook'),
          h('ol', { class: 'hint' },
            h('li', {}, 'Tu Instagram debe ser cuenta profesional (Creador o Empresa) y estar ligada a tu Página de Facebook.'),
            h('li', {}, 'En developers.facebook.com → Mis apps → Crear app. Copia el App ID y el App secret (Configuración → Básica).'),
            h('li', {}, 'Abre el Explorador de la Graph API, elige tu app y “Generar token de acceso de usuario” con: pages_show_list, pages_read_engagement, pages_read_user_content, pages_manage_engagement, instagram_basic, instagram_manage_comments (y business_management si tu Página está en Business Manager).'),
            h('li', {}, 'Copia el token, pégalo arriba y toca Conectar. La app lo cambia por un token de Página que no caduca. Debes ser administrador de la app y de la Página (modo desarrollo: sin revisión de Meta).'),
          ),
          h('button', { class: 'btn ghost small', type: 'button', onclick: () => openExternal('https://developers.facebook.com/tools/explorer/') }, 'Abrir el Explorador de la Graph API'),
        ),
      );

  return h(
    'div',
    {},
    h('h2', {}, 'Cuentas'),
    h('p', { class: 'hint' }, 'Con sesión puedes responder comentarios de YouTube, Instagram y Facebook y mandar mensajes de Reddit desde la app. La búsqueda usa tu sesión (Reddit ya no depende del JSON público). Los tokens se guardan solo en este teléfono. TikTok no ofrece API para esto: se agrega a mano.'),
    google,
    reddit,
    metaBlock,
  );
}

function viewAjustes(): HTMLElement {
  const field = (label: string, key: keyof Settings, type = 'text', ph = '') =>
    h(
      'div',
      {},
      h('label', {}, label),
      h('input', { type, value: String(settings[key]), placeholder: ph, autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', oninput: (e: Event) => saveSettings({ [key]: (e.target as HTMLInputElement).value } as Partial<Settings>) }),
    );
  const importBox = h('textarea', { placeholder: 'Pega aquí un respaldo para importarlo' });
  return h(
    'section',
    {},
    accountsView(),
    h('h2', {}, 'Clave de YouTube (se guarda solo en este teléfono)'),
    field('Clave de YouTube Data API v3 (o inicia sesión con Google arriba)', 'youtubeKey', 'password', 'AIza…'),
    h(
      'p',
      { class: 'hint' },
      'En Google Cloud Console crea un proyecto, activa “YouTube Data API v3” y crea una clave de API ',
      h('b', {}, 'sin restricción de aplicación'),
      ' (las restricciones por app Android la bloquean).',
    ),
    h('p', { class: 'hint' }, 'Reddit: inicia sesión en Cuentas (arriba) para buscar sin bloqueos. Sin sesión se usa su JSON público, que a veces bloquea las solicitudes.'),
    h('h2', {}, 'Para el mensaje de contacto'),
    field('Tu banda', 'bandName', 'text', '4PAIN'),
    field('Enlace a una canción', 'songUrl', 'url', 'https://…'),
    h('h2', {}, 'Respaldo de fans'),
    h(
      'div',
      { class: 'row' },
      h('button', { class: 'btn ghost', type: 'button', onclick: async () => toast((await copyText(store.exportJson())) ? 'Respaldo copiado' : 'No se pudo copiar') }, 'Copiar respaldo'),
    ),
    importBox,
    h(
      'button',
      {
        class: 'btn ghost',
        type: 'button',
        onclick: () => {
          try {
            const n = store.importJson(importBox.value);
            importBox.value = '';
            toast(`Importados ${n} fans nuevos`);
          } catch (e: any) {
            toast(`No se pudo importar: ${e.message}`);
          }
        },
      },
      'Importar respaldo',
    ),
    h(
      'button',
      {
        class: 'btn danger',
        type: 'button',
        onclick: () => {
          if (window.confirm('¿Borrar TODOS los fans guardados? Esto no se puede deshacer.')) {
            store.clear();
            lastResult = null;
            toast('Fans borrados');
          }
        },
      },
      'Borrar todos los fans',
    ),
    h('p', { class: 'hint' }, 'YouTube: 10,000 unidades al día (se reinician a medianoche, hora del Pacífico). Los resultados con datos reales de tu cuenta aún no se han probado en este teléfono.'),
  );
}

function render() {
  const scroll = window.scrollY;
  const view = tab === 'buscar' ? viewBuscar() : tab === 'fans' ? viewFans() : viewAjustes();
  const navBtn = (t: Tab, ico: string, label: string) =>
    h('button', { type: 'button', 'aria-current': tab === t ? 'page' : undefined, onclick: () => { tab = t; render(); window.scrollTo(0, 0); } }, h('span', { class: 'ico', 'aria-hidden': 'true' }, ico), label);
  root.replaceChildren(
    h('header', { class: 'top' }, h('h1', {}, 'Fan', h('b', {}, 'Radar')), h('span', {}, tab === 'buscar' ? 'Buscar' : tab === 'fans' ? 'Mis fans' : 'Ajustes')),
    h('main', {}, view),
    h('nav', { class: 'tabs' }, navBtn('buscar', '◎', 'Buscar'), navBtn('fans', '★', 'Fans'), navBtn('ajustes', '⚙', 'Ajustes')),
  );
  window.scrollTo(0, scroll);
}

render();
handleOAuthCallback();
