// Dentro de la app Android, las llamadas HTTPS pasan por el puente nativo (sin CORS y con User-Agent propio).
// Fuera de la app (navegador) no hace nada y se usa fetch normal.
interface Bridge {
  request(id: string, method: string, url: string, headersJson: string, body: string): void;
  copy?(text: string): void;
  open?(url: string): void;
  takePendingOAuth?(): string;
}
declare global {
  interface Window {
    AndroidHttp?: Bridge;
    __oauthCheck?: () => void;
    __nativeHttpDone?: (id: string, status: number, body: string, err: string | null) => void;
  }
}

export function installNativeFetch() {
  const bridge = window.AndroidHttp;
  if (!bridge) return;
  const pending = new Map<string, { ok: (r: Response) => void; fail: (e: Error) => void }>();
  let n = 0;

  window.__nativeHttpDone = (id, status, body, err) => {
    const p = pending.get(id);
    if (!p) return;
    pending.delete(id);
    if (err || status < 200 || status > 599) return p.fail(new TypeError(err ?? `HTTP ${status}`));
    p.ok(new Response(status === 204 || status === 205 ? null : body, { status }));
  };

  const orig = window.fetch.bind(window);
  window.fetch = (input: RequestInfo | URL, init?: RequestInit) => {
    const url = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url;
    if (!/^https:\/\//i.test(url)) return orig(input, init);
    const headers: Record<string, string> = {};
    new Headers(init?.headers).forEach((v, k) => (headers[k] = v));
    const body = typeof init?.body === 'string' ? init.body : init?.body instanceof URLSearchParams ? init.body.toString() : '';
    return new Promise<Response>((ok, fail) => {
      const id = `r${++n}`;
      pending.set(id, { ok, fail });
      try {
        bridge.request(id, (init?.method ?? 'GET').toUpperCase(), url, JSON.stringify(headers), body);
      } catch (e: any) {
        pending.delete(id);
        fail(e);
      }
    });
  };
}
