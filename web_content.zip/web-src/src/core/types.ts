export type Source = 'youtube' | 'reddit' | 'instagram' | 'facebook' | 'tiktok';
export const SOURCE_LABEL: Record<Source, string> = { youtube: 'YouTube', reddit: 'Reddit', instagram: 'Instagram', facebook: 'Facebook', tiktok: 'TikTok' };

/** Página de Facebook (y su Instagram profesional ligado) con token de Página. */
export interface MetaPage {
  id: string;
  name: string;
  token: string;
  igId?: string;
  igUsername?: string;
}
export interface MetaSession {
  pages: MetaPage[];
  selected: string; // id de la Página activa
  userName?: string;
}
/** Cuenta propia a leer (Instagram/Facebook) con el token de su Página. */
export interface MetaCreds {
  page: MetaPage;
  label: string; // cómo se llama tu banda/cuenta en las razones del score
}

/** Una prueba concreta y enlazable de que esta persona escucha/habla de música del nicho. */
export interface Evidence {
  source: Source;
  band: string; // banda parecida con la que interactuó
  text: string; // comentario o título del post (recortado)
  url: string; // enlace verificable a la prueba
  likes?: number;
  publishedAt?: string;
  refId?: string; // id del comentario (para responder por API)
}

export type FanStatus = 'NEW' | 'CONTACTED' | 'REPLIED' | 'FAN' | 'DISCARDED';
export const STATUSES: FanStatus[] = ['NEW', 'CONTACTED', 'REPLIED', 'FAN', 'DISCARDED'];

export interface FanCandidate {
  id: string; // `${source}:${authorId}`
  source: Source;
  displayName: string;
  profileUrl: string; // perfil real del autor (no una búsqueda)
  evidence: Evidence[];
  bands: string[];
  score: number; // 0-100, explicable por `reasons`
  reasons: string[];
  status: FanStatus;
  foundAt: string;
}

export interface RawFan {
  source: Source;
  authorId: string;
  displayName: string;
  profileUrl: string;
  evidence: Evidence;
}

export interface SearchRequest {
  bands: string[];
  genre?: string;
  city?: string;
  subreddits?: string[];
  sources?: Source[];
  maxVideoViews?: number; // default 50,000
  videosPerBand?: number; // default 3
  commentsPerVideo?: number; // default 100 (máx. 100)
}

export interface Credentials {
  youtubeKey?: string;
  redditId?: string;
  redditSecret?: string;
  meta?: MetaCreds; // Instagram/Facebook propios
  youtubeToken?: string; // sesión de Google (tiene prioridad sobre la clave)
  redditToken?: string; // sesión de Reddit (evita el bloqueo del JSON público)
}

export interface SearchResponse {
  candidates: FanCandidate[];
  stats: { raw: number; unique: number; sources: Record<string, number>; errors: string[] };
}

export type Progress = (msg: string) => void;

/** Error que detiene toda una fuente (cuota agotada, clave inválida, bloqueo). */
export class FatalSourceError extends Error {}
