import type { Credentials, Progress, RawFan, SearchRequest, SearchResponse, Source } from './types';
import { findYouTubeFans } from './youtube';
import { findRedditFans } from './reddit';
import { findMetaFans } from './meta';
import { aggregateAndScore } from './score';

export const QUOTA_PER_BAND = 104; // 100 búsqueda + 1 videos + hasta 3 comentarios

export function estimateYouTubeQuota(bandCount: number): number {
  return Math.min(8, bandCount) * QUOTA_PER_BAND;
}

export async function searchFans(
  req: SearchRequest,
  creds: Credentials,
  onProgress?: Progress,
  opts: { redditSleep?: (ms: number) => Promise<void> } = {},
): Promise<SearchResponse> {
  const errors: string[] = [];
  const bands = [...new Set((req.bands ?? []).map((b) => b.trim()).filter(Boolean))].slice(0, 8);
  const sources: Source[] = req.sources?.length ? req.sources : ['youtube', 'reddit'];
  // Las bandas parecidas solo hacen falta para buscar en YouTube/Reddit (Instagram/Facebook leen tus propios comentarios).
  if (!bands.length && (sources.includes('youtube') || sources.includes('reddit'))) throw new Error('Escribe al menos una banda parecida a la tuya.');
  const jobs: Promise<RawFan[]>[] = [];

  if (sources.includes('youtube')) {
    if (!creds.youtubeKey && !creds.youtubeToken) errors.push('Falta la clave de YouTube o iniciar sesión con Google (Ajustes): se omite YouTube.');
    else
      jobs.push(
        findYouTubeFans({
          key: creds.youtubeKey,
          token: creds.youtubeToken,
          bands,
          genre: req.genre,
          maxVideoViews: req.maxVideoViews ?? 50_000,
          videosPerBand: req.videosPerBand ?? 3,
          commentsPerVideo: req.commentsPerVideo ?? 100,
          errors,
          onProgress,
        }),
      );
  }

  if (sources.includes('reddit')) {
    const subs = (req.subreddits ?? []).map((s) => s.replace(/^\/?r\//i, '').trim()).filter(Boolean);
    if (!subs.length) errors.push('Sin subreddits: se omite Reddit.');
    else
      jobs.push(
        findRedditFans({
          bands,
          subreddits: subs,
          clientId: creds.redditId,
          clientSecret: creds.redditSecret,
          userToken: creds.redditToken,
          errors,
          onProgress,
          sleep: opts.redditSleep,
        }),
      );
  }

  const wantIg = sources.includes('instagram');
  const wantFb = sources.includes('facebook');
  if (wantIg || wantFb) {
    if (!creds.meta) errors.push('Conecta Meta en Ajustes para leer tus comentarios de Instagram/Facebook.');
    else jobs.push(findMetaFans({ meta: creds.meta, instagram: wantIg, facebook: wantFb, errors, onProgress }));
  }

  const raw = (await Promise.all(jobs)).flat();
  const candidates = aggregateAndScore(raw, { ...req, bands });

  const perSource: Record<string, number> = {};
  for (const c of candidates) perSource[c.source] = (perSource[c.source] ?? 0) + 1;

  return { candidates, stats: { raw: raw.length, unique: candidates.length, sources: perSource, errors } };
}
