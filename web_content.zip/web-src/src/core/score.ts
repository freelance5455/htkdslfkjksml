import type { FanCandidate, RawFan, SearchRequest } from './types';

// Corrección: antes "gem" y "new" coincidían dentro de palabras ("Gemini", "news", "newcomer").
const DISCOVERY_STRICT = /\b(new|gems?)\b/i; // palabras cortas: solo completas
const DISCOVERY_LONG =
  /\b(descubr|nuevo|nueva|underrated|recom(?:ie|e)nd|recommend|joya|brutal|incre[ií]ble|buen[ií]sim|lo escuch|me encant|love|amazing|sick|killer|m[aá]s gente|merece|deserve)/i;
const BOT_NAME = /(bot|official|records|oficial|music ?channel|promo)/i;

export const norm = (s: string) =>
  s
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');

export const hasDiscoveryLanguage = (text: string) => DISCOVERY_LONG.test(text) || DISCOVERY_STRICT.test(text);

/** Alias comunes para que "Ciudad de México" también detecte "CDMX", etc. */
export function cityTerms(city: string): string[] {
  const c = norm(city).trim();
  const terms = new Set([c]);
  if (/^(ciudad de mexico|mexico city|cdmx|d\.?f\.?|distrito federal)$/.test(c)) {
    ['ciudad de mexico', 'mexico city', 'cdmx', 'chilangolandia'].forEach((t) => terms.add(t));
  }
  return [...terms].filter(Boolean);
}

function mentionsCity(text: string, city: string): boolean {
  const t = norm(text);
  return cityTerms(city).some((x) => t.includes(x));
}

/** Agrupa por persona y calcula un score explicable (cada punto tiene su razón). */
export function aggregateAndScore(raw: RawFan[], req: SearchRequest): FanCandidate[] {
  // Corrección: nombres de banda muy cortos (<3 letras) descartaban cuentas legítimas ("Ra" en "Rafael").
  const ownBands = (req.bands ?? []).map(norm).filter((b) => b.replace(/\s+/g, '').length >= 3);
  const groups = new Map<string, RawFan[]>();

  for (const r of raw) {
    const n = norm(r.displayName);
    if (ownBands.some((b) => n.includes(b.replace(/\s+/g, '')) || n.includes(b))) continue;
    if (r.source === 'youtube' && BOT_NAME.test(r.displayName)) continue;
    const key = `${r.source}:${r.authorId}`;
    const g = groups.get(key);
    if (g) g.push(r);
    else groups.set(key, [r]);
  }

  const now = Date.now();
  const out: FanCandidate[] = [];

  for (const [id, items] of groups) {
    const reasons: string[] = [];
    let score = 20;

    const bands = [...new Set(items.map((i) => i.evidence.band))];
    if (bands.length >= 2) {
      score += Math.min(40, 20 * bands.length);
      reasons.push(`Interactuó con ${bands.length} bandas del nicho (${bands.join(', ')})`);
    } else {
      reasons.push(`Interactuó con ${bands[0]}`);
    }

    const evidence = items
      .map((i) => i.evidence)
      .sort((a, b) => (b.likes ?? 0) - (a.likes ?? 0))
      .slice(0, 5);

    if (items.length >= 2) {
      score += Math.min(15, 5 * items.length);
      reasons.push(`${items.length} interacciones registradas`);
    }

    if (items.some((i) => hasDiscoveryLanguage(i.evidence.text))) {
      score += 10;
      reasons.push('Usa lenguaje de descubrimiento/entusiasmo');
    }

    const likes = Math.max(...items.map((i) => i.evidence.likes ?? 0));
    if (likes >= 2) {
      score += Math.min(10, likes);
      reasons.push(`Su comentario/post recibió ${likes} likes`);
    }

    const recent = items.some((i) => {
      const t = i.evidence.publishedAt ? Date.parse(i.evidence.publishedAt) : NaN;
      return Number.isFinite(t) && now - t < 90 * 864e5;
    });
    if (recent) {
      score += 10;
      reasons.push('Activo en los últimos 90 días');
    }

    if (req.city && items.some((i) => mentionsCity(i.evidence.text, req.city!))) {
      score += 15;
      reasons.push(`Menciona ${req.city}`);
    }

    out.push({
      id,
      source: items[0].source,
      displayName: items[0].displayName,
      profileUrl: items[0].profileUrl,
      evidence,
      bands,
      score: Math.min(100, score),
      reasons,
      status: 'NEW',
      foundAt: new Date().toISOString(),
    });
  }

  return out.sort((a, b) => b.score - a.score);
}
