import { FatalSourceError, type MetaCreds, type MetaPage, type MetaSession, type Progress, type RawFan } from './types';

// Versión de la Graph API. Meta retira cada versión ~2 años después; si algún día falla, súbela aquí.
export const GRAPH = 'https://graph.facebook.com/v23.0';

export function graphError(status: number, err: any, raw: string): Error {
  const code = err?.code;
  const msg = String(err?.message ?? raw.slice(0, 160));
  if (code === 190 || status === 401) return new FatalSourceError('Meta: tu sesión caducó o fue revocada. Vuelve a conectar Meta en Ajustes.');
  if (code === 10 || (typeof code === 'number' && code >= 200 && code <= 299))
    return new FatalSourceError(`Meta: falta un permiso (${msg}). Genera el token de nuevo con todos los permisos de la guía.`);
  if ([4, 17, 32, 613, 80002, 80006].includes(code)) return new FatalSourceError('Meta: límite de solicitudes alcanzado. Espera unos minutos.');
  return new Error(`Meta ${code ?? status}: ${msg}`);
}

/** Llamada a la Graph API. Con `method: 'POST'` los datos van en el cuerpo. */
export async function graph(path: string, token: string, params: Record<string, string> = {}, method: 'GET' | 'POST' = 'GET'): Promise<any> {
  const all = token ? { ...params, access_token: token } : params;
  const res =
    method === 'POST'
      ? await fetch(`${GRAPH}/${path}`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(all).toString() })
      : await fetch(`${GRAPH}/${path}?${new URLSearchParams(all)}`);
  const text = await res.text();
  let json: any = null;
  try {
    json = JSON.parse(text);
  } catch {
    /* no era JSON */
  }
  if (!res.ok || json?.error) throw graphError(res.status, json?.error, text);
  return json;
}

/**
 * Conecta Meta: cambia el token corto del Explorador de la Graph API por uno largo (60 días)
 * y obtiene los tokens de Página (no caducan) con su Instagram profesional ligado.
 */
export async function metaConnect(cfg: { appId: string; appSecret: string; userToken: string }): Promise<MetaSession> {
  const ex = await graph('oauth/access_token', '', {
    grant_type: 'fb_exchange_token',
    client_id: cfg.appId,
    client_secret: cfg.appSecret,
    fb_exchange_token: cfg.userToken,
  });
  const long: string = ex.access_token;
  if (!long) throw new Error('Meta no devolvió un token largo.');
  const acc = await graph('me/accounts', long, { fields: 'id,name,access_token,instagram_business_account{id,username}', limit: '50' });
  const pages: MetaPage[] = (acc.data ?? [])
    .filter((p: any) => p?.id && p?.access_token)
    .map((p: any) => ({ id: p.id, name: p.name, token: p.access_token, igId: p.instagram_business_account?.id, igUsername: p.instagram_business_account?.username }));
  if (!pages.length)
    throw new Error('Meta no devolvió Páginas. Revisa que seas administrador de la Página y que el token incluya pages_show_list (y business_management si la Página está en Business Manager).');
  const me = await graph('me', long, { fields: 'name' }).catch(() => null);
  return { pages, selected: (pages.find((p) => p.igId) ?? pages[0]).id, userName: me?.name };
}

export const activePage = (m?: MetaSession): MetaPage | undefined => m?.pages.find((p) => p.id === m.selected) ?? m?.pages[0];

const MEDIA_LIMIT = 10;
const COMMENTS_LIMIT = 50;

/** Lee a quienes comentan en TUS publicaciones de Instagram y de tu Página de Facebook. */
export async function findMetaFans(opts: {
  meta: MetaCreds;
  instagram: boolean;
  facebook: boolean;
  errors: string[];
  onProgress?: Progress;
}): Promise<RawFan[]> {
  const { page, label } = opts.meta;
  const out: RawFan[] = [];
  const tok = page.token;

  try {
    if (opts.instagram) {
      if (!page.igId) opts.errors.push('Esta Página no tiene un Instagram profesional ligado: se omite Instagram.');
      else {
        opts.onProgress?.('Instagram: tus publicaciones…');
        const media = await graph(`${page.igId}/media`, tok, { fields: 'id,caption,permalink,timestamp,comments_count', limit: String(MEDIA_LIMIT) });
        for (const m of media.data ?? []) {
          if (!m.comments_count) continue;
          try {
            const cs = await graph(`${m.id}/comments`, tok, { fields: 'id,text,timestamp,username,like_count', limit: String(COMMENTS_LIMIT) });
            for (const c of cs.data ?? []) {
              const u: string | undefined = c.username;
              if (!u || u.toLowerCase() === page.igUsername?.toLowerCase()) continue;
              out.push({
                source: 'instagram',
                authorId: u.toLowerCase(),
                displayName: `@${u}`,
                profileUrl: `https://www.instagram.com/${u}/`,
                evidence: { source: 'instagram', band: label, text: String(c.text ?? '').slice(0, 280), url: m.permalink, likes: c.like_count ?? 0, publishedAt: c.timestamp, refId: c.id },
              });
            }
          } catch (e: any) {
            if (e instanceof FatalSourceError) throw e;
            opts.errors.push(`Instagram ${m.id}: ${e.message}`);
          }
        }
        // Publicaciones donde te etiquetaron: el autor es una señal fuerte (mejor esfuerzo).
        try {
          const tags = await graph(`${page.igId}/tags`, tok, { fields: 'id,caption,permalink,timestamp,username,like_count', limit: '25' });
          for (const t of tags.data ?? []) {
            const u: string | undefined = t.username;
            if (!u || u.toLowerCase() === page.igUsername?.toLowerCase()) continue;
            out.push({
              source: 'instagram',
              authorId: u.toLowerCase(),
              displayName: `@${u}`,
              profileUrl: `https://www.instagram.com/${u}/`,
              evidence: { source: 'instagram', band: label, text: `Te etiquetó: ${String(t.caption ?? '').slice(0, 240)}`.trim(), url: t.permalink, likes: t.like_count ?? 0, publishedAt: t.timestamp },
            });
          }
        } catch (e: any) {
          opts.errors.push(`Instagram (etiquetas): ${e.message}`);
        }
      }
    }

    if (opts.facebook) {
      opts.onProgress?.('Facebook: las publicaciones de tu Página…');
      const posts = await graph(`${page.id}/posts`, tok, { fields: 'id,message,permalink_url,created_time', limit: String(MEDIA_LIMIT) });
      for (const p of posts.data ?? []) {
        try {
          const cs = await graph(`${p.id}/comments`, tok, {
            fields: 'id,from{id,name},message,created_time,like_count,permalink_url',
            filter: 'toplevel',
            order: 'reverse_chronological',
            limit: String(COMMENTS_LIMIT),
          });
          for (const c of cs.data ?? []) {
            const from = c.from;
            if (!from?.id || from.id === page.id) continue; // sin autor visible o la propia Página
            const url = c.permalink_url ?? p.permalink_url;
            out.push({
              source: 'facebook',
              authorId: String(from.id),
              displayName: from.name ?? `Usuario ${from.id}`,
              profileUrl: url, // Meta no entrega un enlace al perfil: se abre el comentario
              evidence: { source: 'facebook', band: label, text: String(c.message ?? '').slice(0, 280), url, likes: c.like_count ?? 0, publishedAt: c.created_time, refId: c.id },
            });
          }
        } catch (e: any) {
          if (e instanceof FatalSourceError) throw e;
          opts.errors.push(`Facebook ${p.id}: ${e.message}`);
        }
      }
    }
  } catch (e: any) {
    if (!(e instanceof FatalSourceError)) throw e;
    opts.errors.push(e.message);
  }
  return out;
}

/** Responde públicamente a un comentario de Instagram. */
export async function instagramReply(token: string, commentId: string, text: string): Promise<string> {
  const j = await graph(`${commentId}/replies`, token, { message: text }, 'POST');
  return String(j?.id ?? '');
}

/** Responde públicamente a un comentario en tu Página de Facebook. */
export async function facebookReply(token: string, commentId: string, text: string): Promise<string> {
  const j = await graph(`${commentId}/comments`, token, { message: text }, 'POST');
  return String(j?.id ?? '');
}
