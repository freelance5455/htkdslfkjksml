import { FatalSourceError, type Progress, type RawFan } from './types';

const API = 'https://www.googleapis.com/youtube/v3';

export interface YtAuth {
  key?: string;
  token?: string;
}

async function yt(path: string, params: Record<string, string>, auth: YtAuth): Promise<any> {
  const q = auth.token ? params : { ...params, key: auth.key ?? '' };
  const res = await fetch(`${API}/${path}?${new URLSearchParams(q)}`, auth.token ? { headers: { Authorization: `Bearer ${auth.token}` } } : undefined);
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    // Corrección: antes, con la cuota agotada se seguía llamando por cada banda (todas fallaban).
    if (res.status === 401) throw new FatalSourceError('YouTube: tu sesión de Google expiró. Inicia sesión de nuevo en Ajustes.');
    if (/quotaExceeded|dailyLimitExceeded|rateLimitExceeded/.test(body))
      throw new FatalSourceError('YouTube: cuota diaria agotada. Se reinicia a medianoche (hora del Pacífico).');
    if (/keyInvalid|API key not valid|API_KEY_INVALID/.test(body))
      throw new FatalSourceError('YouTube: la clave de API no es válida. Revísala en Ajustes.');
    if (/accessNotConfigured|has not been used|SERVICE_DISABLED/.test(body))
      throw new FatalSourceError('YouTube: activa "YouTube Data API v3" en tu proyecto de Google Cloud.');
    if (/API_KEY_ANDROID_APP_BLOCKED|API_KEY_HTTP_REFERRER_BLOCKED|ipRefererBlocked/.test(body))
      throw new FatalSourceError('YouTube: tu clave tiene restricciones de aplicación. Usa una clave sin restricción de app.');
    throw new Error(`YouTube ${path} ${res.status}: ${body.slice(0, 160)}`);
  }
  return res.json();
}

/**
 * Para cada banda parecida: busca sus videos, se queda con los de pocas vistas
 * (ahí comenta gente que realmente descubre música nueva) y toma a los comentaristas.
 * Cuota: search.list = 100 unidades; videos/commentThreads = 1 c/u.
 */
export async function findYouTubeFans(opts: {
  key?: string;
  token?: string;
  bands: string[];
  genre?: string;
  maxVideoViews: number;
  videosPerBand: number;
  commentsPerVideo: number;
  errors: string[];
  onProgress?: Progress;
}): Promise<RawFan[]> {
  const out: RawFan[] = [];
  const auth: YtAuth = { key: opts.key, token: opts.token };

  for (const band of opts.bands) {
    opts.onProgress?.(`YouTube: ${band}…`);
    try {
      const search = await yt(
        'search',
        { part: 'snippet', type: 'video', q: `${band} ${opts.genre ?? ''}`.trim(), maxResults: '15', relevanceLanguage: 'es' },
        auth,
      );
      const ids: string[] = (search.items ?? []).map((i: any) => i.id?.videoId).filter(Boolean);
      if (!ids.length) continue;

      const stats = await yt('videos', { part: 'statistics,snippet', id: ids.join(',') }, auth);
      const small = (stats.items ?? [])
        .filter((v: any) => {
          const views = Number(v.statistics?.viewCount ?? 0);
          const commentCount = Number(v.statistics?.commentCount ?? 0);
          return views <= opts.maxVideoViews && commentCount > 0;
        })
        // Corrección: respetar el orden de relevancia de la búsqueda (la API de videos no lo garantiza).
        .sort((a: any, b: any) => ids.indexOf(a.id) - ids.indexOf(b.id))
        .slice(0, opts.videosPerBand);

      for (const v of small) {
        try {
          const threads = await yt(
            'commentThreads',
            {
              part: 'snippet',
              videoId: v.id,
              maxResults: String(Math.min(100, opts.commentsPerVideo)),
              order: 'relevance',
              textFormat: 'plainText',
            },
            auth,
          );
          for (const t of threads.items ?? []) {
            const c = t.snippet?.topLevelComment?.snippet;
            const authorId = c?.authorChannelId?.value;
            if (!c || !authorId) continue;
            if (authorId === v.snippet?.channelId) continue; // el dueño del video no es fan
            out.push({
              source: 'youtube',
              authorId,
              displayName: c.authorDisplayName ?? authorId,
              profileUrl: c.authorChannelUrl ?? `https://www.youtube.com/channel/${authorId}`,
              evidence: {
                source: 'youtube',
                band,
                text: String(c.textOriginal ?? c.textDisplay ?? '').slice(0, 280),
                url: `https://www.youtube.com/watch?v=${v.id}&lc=${t.id}`,
                likes: c.likeCount ?? 0,
                publishedAt: c.publishedAt,
              },
            });
          }
        } catch (e: any) {
          if (e instanceof FatalSourceError) throw e;
          opts.errors.push(`video ${v.id}: ${e.message}`); // p. ej. comentarios desactivados
        }
      }
    } catch (e: any) {
      if (e instanceof FatalSourceError) {
        opts.errors.push(e.message);
        return out; // conserva lo ya encontrado y deja de gastar cuota
      }
      opts.errors.push(`banda "${band}": ${e.message}`);
    }
  }
  return out;
}
