const form = (o: Record<string, string>) => new URLSearchParams(o).toString();

/** El id del comentario de YouTube viaja en la URL de la prueba (parámetro lc). */
export function youtubeCommentId(evidenceUrl: string): string | null {
  try {
    return new URL(evidenceUrl).searchParams.get('lc');
  } catch {
    return null;
  }
}

/** Responde públicamente a un comentario. Cuesta 50 unidades de cuota. */
export async function youtubeReply(token: string, parentId: string, text: string): Promise<string> {
  const res = await fetch('https://www.googleapis.com/youtube/v3/comments?part=snippet', {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ snippet: { parentId, textOriginal: text } }),
  });
  if (res.ok) return String(((await res.json()) as any)?.id ?? '');
  const body = await res.text().catch(() => '');
  if (res.status === 401) throw new Error('Tu sesión de Google expiró. Inicia sesión de nuevo en Ajustes.');
  if (/quotaExceeded/.test(body)) throw new Error('YouTube: cuota diaria agotada.');
  if (/insufficientPermissions|ACCESS_TOKEN_SCOPE_INSUFFICIENT/.test(body)) throw new Error('Permisos insuficientes: cierra sesión y vuelve a iniciar para aceptar el permiso de YouTube.');
  if (/commentsDisabled|forbidden/.test(body)) throw new Error('YouTube no permite comentar ahí (comentarios desactivados o restringidos).');
  if (/channelNotFound|youtubeSignupRequired/.test(body)) throw new Error('Esa cuenta de Google no tiene canal de YouTube. Crea uno para poder comentar.');
  throw new Error(`YouTube ${res.status}: ${body.slice(0, 160)}`);
}

/** Mensaje privado de Reddit. */
export async function redditMessage(token: string, to: string, subject: string, text: string): Promise<void> {
  const res = await fetch('https://oauth.reddit.com/api/compose', {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: form({ api_type: 'json', to: to.replace(/^u\//i, ''), subject, text }),
  });
  if (res.status === 401) throw new Error('Tu sesión de Reddit expiró. Inicia sesión de nuevo en Ajustes.');
  if (res.status === 429) throw new Error('Reddit limitó tus envíos. Espera unos minutos.');
  if (!res.ok) throw new Error(`Reddit ${res.status}`);
  const j: any = await res.json().catch(() => null);
  const errs: any[] = j?.json?.errors ?? [];
  if (errs.length) {
    const code = String(errs[0]?.[0] ?? '');
    if (code === 'RATELIMIT') throw new Error(`Reddit: demasiados envíos. ${errs[0]?.[1] ?? ''}`.trim());
    if (code === 'USER_DOESNT_EXIST') throw new Error('Ese usuario ya no existe en Reddit.');
    if (code === 'NOT_WHITELISTED_BY_USER_MESSAGE') throw new Error('Ese usuario no acepta mensajes de cuentas que no conoce.');
    throw new Error('Reddit: ' + errs.map((e) => (Array.isArray(e) ? e.slice(0, 2).join(' — ') : String(e))).join('; '));
  }
}
