import type { KV } from './store';
import type { MetaSession } from './types';

export interface Tokens {
  access: string;
  refresh?: string;
  exp: number; // ms epoch
  name?: string; // canal de YouTube / usuario de Reddit
}
export interface AuthState {
  google?: Tokens;
  reddit?: Tokens;
  meta?: MetaSession;
}
export type Provider = 'google' | 'reddit';

export const REDDIT_REDIRECT = 'fanradar://reddit';
const GOOGLE_SCOPE = 'https://www.googleapis.com/auth/youtube'; // leer y comentar (permitido en el flujo de dispositivos)
const REDDIT_SCOPE = 'identity read privatemessages';
const GOOGLE_TOKEN = 'https://oauth2.googleapis.com/token';
const REDDIT_TOKEN = 'https://www.reddit.com/api/v1/access_token';

const form = (o: Record<string, string>) => new URLSearchParams(o).toString();

async function postForm(url: string, body: Record<string, string>, headers: Record<string, string> = {}) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', ...headers },
    body: form(body),
  });
  const text = await res.text();
  let json: any = null;
  try {
    json = JSON.parse(text);
  } catch {
    /* no era JSON */
  }
  return { status: res.status, json, text };
}

// ---------- almacenamiento de sesiones (solo en este teléfono) ----------
export function createAuthStore(kv: KV, key = 'fanradar.auth.v1') {
  const load = (): AuthState => {
    try {
      const s = JSON.parse(kv.getItem(key) ?? '{}');
      return s && typeof s === 'object' ? s : {};
    } catch {
      return {};
    }
  };
  return {
    get: load,
    set(p: Provider, t: Tokens | undefined) {
      const s = load();
      if (t) s[p] = t;
      else delete s[p];
      kv.setItem(key, JSON.stringify(s));
    },
    setMeta(m: MetaSession | undefined) {
      const s = load();
      if (m) s.meta = m;
      else delete s.meta;
      kv.setItem(key, JSON.stringify(s));
    },
  };
}

// ---------- Google: flujo de dispositivos (sin redirecciones ni WebView) ----------
export interface DeviceCode {
  deviceCode: string;
  userCode: string;
  verificationUrl: string;
  expiresIn: number;
  interval: number;
}
export interface GoogleCfg {
  clientId: string;
  clientSecret: string;
}

export async function googleStart(clientId: string): Promise<DeviceCode> {
  const r = await postForm('https://oauth2.googleapis.com/device/code', { client_id: clientId, scope: GOOGLE_SCOPE });
  if (r.status !== 200 || !r.json?.device_code)
    throw new Error(
      `Google: ${r.json?.error_description ?? r.json?.error ?? r.status}. Revisa que el Client ID sea de tipo "TVs y dispositivos de entrada limitada".`,
    );
  return {
    deviceCode: r.json.device_code,
    userCode: r.json.user_code,
    verificationUrl: r.json.verification_url ?? 'https://www.google.com/device',
    expiresIn: r.json.expires_in ?? 1800,
    interval: r.json.interval ?? 5,
  };
}

export async function googlePoll(
  cfg: GoogleCfg,
  dc: DeviceCode,
  opts: { isCancelled: () => boolean; sleep?: (ms: number) => Promise<void> },
): Promise<Tokens> {
  const sleep = opts.sleep ?? ((ms: number) => new Promise<void>((r) => setTimeout(r, ms)));
  let interval = dc.interval;
  const deadline = Date.now() + dc.expiresIn * 1000;
  while (Date.now() < deadline) {
    await sleep(interval * 1000);
    if (opts.isCancelled()) throw new Error('Inicio de sesión cancelado.');
    const r = await postForm(GOOGLE_TOKEN, {
      client_id: cfg.clientId,
      client_secret: cfg.clientSecret,
      device_code: dc.deviceCode,
      grant_type: 'urn:ietf:params:oauth:grant-type:device_code',
    });
    if (r.status === 200 && r.json?.access_token)
      return { access: r.json.access_token, refresh: r.json.refresh_token, exp: Date.now() + (r.json.expires_in ?? 3600) * 1000 };
    const err = r.json?.error;
    if (err === 'authorization_pending') continue;
    if (err === 'slow_down') {
      interval += 5;
      continue;
    }
    if (err === 'access_denied') throw new Error('Rechazaste el acceso en Google.');
    if (err === 'expired_token') break;
    throw new Error(`Google: ${r.json?.error_description ?? err ?? r.status}`);
  }
  throw new Error('El código expiró. Vuelve a iniciar sesión.');
}

export async function googleRefresh(cfg: GoogleCfg, t: Tokens): Promise<Tokens> {
  if (!t.refresh) throw new Error('Sesión de Google sin renovación: inicia sesión de nuevo.');
  const r = await postForm(GOOGLE_TOKEN, {
    client_id: cfg.clientId,
    client_secret: cfg.clientSecret,
    refresh_token: t.refresh,
    grant_type: 'refresh_token',
  });
  if (r.status !== 200 || !r.json?.access_token)
    throw new Error(
      r.json?.error === 'invalid_grant'
        ? 'La sesión de Google caducó (en modo "Prueba" dura 7 días). Inicia sesión de nuevo.'
        : `Google: ${r.json?.error_description ?? r.json?.error ?? r.status}`,
    );
  return { ...t, access: r.json.access_token, exp: Date.now() + (r.json.expires_in ?? 3600) * 1000 };
}

export async function googleChannelName(token: string): Promise<string | undefined> {
  const res = await fetch('https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true', {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) return undefined;
  const j: any = await res.json();
  return j?.items?.[0]?.snippet?.title;
}

export async function googleRevoke(token: string): Promise<void> {
  try {
    await postForm('https://oauth2.googleapis.com/revoke', { token });
  } catch {
    /* mejor esfuerzo */
  }
}

// ---------- Reddit: OAuth de "app instalada" con retorno a fanradar://reddit ----------
const basic = (id: string) => 'Basic ' + btoa(`${id}:`);

export function redditAuthUrl(clientId: string, state: string): string {
  return (
    'https://www.reddit.com/api/v1/authorize.compact?' +
    form({ client_id: clientId, response_type: 'code', state, redirect_uri: REDDIT_REDIRECT, duration: 'permanent', scope: REDDIT_SCOPE })
  );
}

/** Extrae el código del enlace fanradar://reddit?code=...&state=... y valida el estado. */
export function parseRedditCallback(uri: string, expectedState: string | null): string {
  const u = new URL(uri);
  const err = u.searchParams.get('error');
  if (err) throw new Error(err === 'access_denied' ? 'Rechazaste el acceso en Reddit.' : `Reddit: ${err}`);
  const code = u.searchParams.get('code');
  if (!code) throw new Error('Reddit: la respuesta no trae código.');
  if (!expectedState || u.searchParams.get('state') !== expectedState) throw new Error('Reddit: estado inválido. Inicia sesión de nuevo.');
  return code;
}

export async function redditExchange(clientId: string, code: string): Promise<Tokens> {
  const r = await postForm(REDDIT_TOKEN, { grant_type: 'authorization_code', code, redirect_uri: REDDIT_REDIRECT }, { Authorization: basic(clientId) });
  if (r.status !== 200 || !r.json?.access_token) throw new Error(`Reddit: ${r.json?.error ?? r.status}. Revisa el Client ID y el redirect URI (${REDDIT_REDIRECT}).`);
  return { access: r.json.access_token, refresh: r.json.refresh_token, exp: Date.now() + (r.json.expires_in ?? 3600) * 1000 };
}

export async function redditRefresh(clientId: string, t: Tokens): Promise<Tokens> {
  if (!t.refresh) throw new Error('Sesión de Reddit sin renovación: inicia sesión de nuevo.');
  const r = await postForm(REDDIT_TOKEN, { grant_type: 'refresh_token', refresh_token: t.refresh }, { Authorization: basic(clientId) });
  if (r.status !== 200 || !r.json?.access_token) throw new Error('La sesión de Reddit caducó. Inicia sesión de nuevo.');
  return { ...t, access: r.json.access_token, exp: Date.now() + (r.json.expires_in ?? 3600) * 1000 };
}

export async function redditName(token: string): Promise<string | undefined> {
  const res = await fetch('https://oauth.reddit.com/api/v1/me', { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) return undefined;
  const j: any = await res.json();
  return j?.name;
}

/** Devuelve un token vigente (renovándolo si falta poco) o null si no hay sesión. */
export async function freshToken(
  provider: Provider,
  store: ReturnType<typeof createAuthStore>,
  ids: { googleClientId: string; googleClientSecret: string; redditClientId: string },
): Promise<string | null> {
  const t = store.get()[provider];
  if (!t) return null;
  if (t.exp - Date.now() > 60_000) return t.access;
  const next =
    provider === 'google'
      ? await googleRefresh({ clientId: ids.googleClientId, clientSecret: ids.googleClientSecret }, t)
      : await redditRefresh(ids.redditClientId, t);
  store.set(provider, next);
  return next.access;
}
