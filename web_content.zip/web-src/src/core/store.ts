import { STATUSES, type FanCandidate, type FanStatus } from './types';

export interface KV {
  getItem(k: string): string | null;
  setItem(k: string, v: string): void;
  removeItem(k: string): void;
}

const KEY = 'fanradar.db.v1';

export function createStore(kv: KV, key = KEY) {
  function load(): Record<string, FanCandidate> {
    const raw = kv.getItem(key);
    if (!raw) return {};
    try {
      const db = JSON.parse(raw);
      if (db && typeof db === 'object' && !Array.isArray(db)) return db;
      throw new Error('formato inesperado');
    } catch {
      // Corrección: antes un archivo dañado se leía como vacío y la siguiente búsqueda lo sobrescribía sin aviso.
      try {
        kv.setItem(`${key}.corrupt.${Date.now()}`, raw);
      } catch {
        /* sin espacio: seguimos */
      }
      return {};
    }
  }

  function save(db: Record<string, FanCandidate>) {
    kv.setItem(key, JSON.stringify(db));
  }

  /** Guarda sin duplicar. Si ya existía, conserva su status y fecha, y actualiza evidencia/score. */
  function upsertMany(cands: FanCandidate[]): { added: number; updated: number } {
    const db = load();
    let added = 0;
    let updated = 0;
    for (const c of cands) {
      const prev = db[c.id];
      if (prev) {
        db[c.id] = { ...c, status: prev.status, foundAt: prev.foundAt };
        updated++;
      } else {
        db[c.id] = c;
        added++;
      }
    }
    save(db);
    return { added, updated };
  }

  /** Alta manual: si la persona ya existe, suma la prueba y conserva su estado y fecha. */
  function addManual(c: FanCandidate): 'added' | 'updated' {
    const db = load();
    const prev = db[c.id];
    if (!prev) {
      db[c.id] = c;
      save(db);
      return 'added';
    }
    const seen = new Set<string>();
    const evidence = [...c.evidence, ...prev.evidence].filter((e) => {
      const k = `${e.url}|${e.text}`;
      return seen.has(k) ? false : (seen.add(k), true);
    });
    db[c.id] = {
      ...prev,
      evidence: evidence.slice(0, 5),
      bands: [...new Set([...prev.bands, ...c.bands])],
      reasons: [...new Set([...prev.reasons, ...c.reasons])],
      score: Math.max(prev.score, c.score),
    };
    save(db);
    return 'updated';
  }

  function listAll(status?: FanStatus): FanCandidate[] {
    const all = Object.values(load()).sort((a, b) => b.score - a.score);
    return status ? all.filter((c) => c.status === status) : all;
  }

  function setStatus(id: string, status: FanStatus): FanCandidate | null {
    if (!STATUSES.includes(status)) return null;
    const db = load();
    if (!db[id]) return null;
    db[id].status = status;
    save(db);
    return db[id];
  }

  function clear() {
    kv.removeItem(key);
  }

  function exportJson(): string {
    return JSON.stringify(load(), null, 2);
  }

  /** Mezcla un respaldo: conserva el estado más avanzado ya guardado. */
  function importJson(text: string): number {
    const parsed = JSON.parse(text);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('Respaldo inválido');
    const db = load();
    let n = 0;
    for (const [id, c] of Object.entries<any>(parsed)) {
      if (!c || typeof c.id !== 'string' || !Array.isArray(c.evidence) || !STATUSES.includes(c.status)) continue;
      if (!db[id]) n++;
      db[id] = db[id] ? { ...c, status: db[id].status, foundAt: db[id].foundAt } : c;
    }
    save(db);
    return n;
  }

  return { upsertMany, addManual, listAll, setStatus, clear, exportJson, importJson };
}
