/** "Death Thrash!" -> "deaththrash" (formato de hashtag). */
export const hashtagify = (s: string) =>
  s
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]/g, '');

export interface Shortcut {
  id: 'ig' | 'tt' | 'ttt' | 'fb' | 'fbg';
  label: string;
  url: string;
}

/** Enlaces que abren la búsqueda de un término en cada red (se explora a mano y se agrega con "＋ Agregar"). */
export function shortcuts(term: string): Shortcut[] {
  const t = term.trim();
  if (!t) return [];
  const q = encodeURIComponent(t);
  const tag = hashtagify(t);
  const out: Shortcut[] = [];
  if (tag) out.push({ id: 'ig', label: `Instagram #${tag}`, url: `https://www.instagram.com/explore/tags/${tag}/` });
  out.push({ id: 'tt', label: 'TikTok', url: `https://www.tiktok.com/search?q=${q}` });
  if (tag) out.push({ id: 'ttt', label: `TikTok #${tag}`, url: `https://www.tiktok.com/tag/${tag}` });
  out.push({ id: 'fb', label: 'Facebook', url: `https://www.facebook.com/search/posts?q=${q}` });
  out.push({ id: 'fbg', label: 'FB grupos', url: `https://www.facebook.com/search/groups?q=${q}` });
  return out;
}
