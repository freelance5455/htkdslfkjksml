import { FatalSourceError, type Progress, type RawFan } from './types';

const BOTS = new Set(['automoderator', '[deleted]', 'musicmod', 'repostsleuthbot']);
let cachedToken: { id: string; value: string; exp: number } | null = null;

async function getToken(id?: string, secret?: string): Promise<string | null> {
  if (!id || !secret) return null;
  if (cachedToken && cachedToken.id === id && cachedToken.exp > Date.now() + 30_000) return cachedToken.value;
  const res = await fetch('https://www.reddit.com/api/v1/access_token', {
    method: 'POST',
    headers: {
      // Corrección: Buffer no existe en el teléfono; se usa btoa.
      Authorization: 'Basic ' + btoa(`${id}:${secret}`),
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'grant_type=client_credentials',
  });
  if (!res.ok) throw new Error(`Reddit token ${res.status} (revisa ID y secreto)`);
  const j: any = await res.json();
  if (!j?.access_token) throw new Error('Reddit token: respuesta sin access_token');
  cachedToken = { id, value: j.access_token, exp: Date.now() + (j.expires_in ?? 3600) * 1000 };
  return cachedToken.value;
}

/**
 * Busca en cada subreddit posts que mencionen a las bandas parecidas.
 * Quien escribe sobre bandas chicas del nicho es un fan potencial real.
 */
export async function findRedditFans(opts: {
  bands: string[];
  subreddits: string[];
  clientId?: string;
  clientSecret?: string;
  userToken?: string;
  errors: string[];
  onProgress?: Progress;
  sleep?: (ms: number) => Promise<void>;
}): Promise<RawFan[]> {
  const sleep = opts.sleep ?? ((ms: number) => new Promise<void>((r) => setTimeout(r, ms)));
  const out: RawFan[] = [];
  let token: string | null = opts.userToken ?? null;
  try {
    if (!token) token = await getToken(opts.clientId, opts.clientSecret);
  } catch (e: any) {
    opts.errors.push(`${e.message}. Se usa el JSON público.`);
  }
  const base = token ? 'https://oauth.reddit.com' : 'https://www.reddit.com';
  const suffix = token ? '' : '.json';
  const headers: Record<string, string> = {};
  if (token) headers.Authorization = `Bearer ${token}`;

  try {
    for (const sub of opts.subreddits) {
      for (const band of opts.bands) {
        opts.onProgress?.(`Reddit: r/${sub} · ${band}…`);
        try {
          const qs = new URLSearchParams({ q: `"${band}"`, restrict_sr: '1', sort: 'new', limit: '25', t: 'year', raw_json: '1' });
          const res = await fetch(`${base}/r/${encodeURIComponent(sub)}/search${suffix}?${qs}`, { headers });
          // Corrección: con 403/429 Reddit está bloqueando; seguir solo empeora el bloqueo y tarda ~1.1 s por intento.
          if (res.status === 403 || res.status === 429)
            throw new FatalSourceError(
              `Reddit respondió ${res.status}: bloqueó o limitó las solicitudes. Configura credenciales de Reddit en Ajustes o espera unos minutos.`,
            );
          if (!res.ok) throw new Error(`${res.status}`);
          const j: any = await res.json();
          for (const child of j?.data?.children ?? []) {
            const p = child.data;
            if (!p?.author || BOTS.has(String(p.author).toLowerCase())) continue;
            out.push({
              source: 'reddit',
              // Corrección: los usuarios de Reddit no distinguen mayúsculas; sin esto se duplicaban personas.
              authorId: String(p.author).toLowerCase(),
              displayName: `u/${p.author}`,
              profileUrl: `https://www.reddit.com/user/${p.author}`,
              evidence: {
                source: 'reddit',
                band,
                text: `${p.title ?? ''} ${String(p.selftext ?? '').slice(0, 200)}`.trim().slice(0, 280),
                url: `https://www.reddit.com${p.permalink}`,
                likes: p.score ?? 0,
                publishedAt: p.created_utc ? new Date(p.created_utc * 1000).toISOString() : undefined,
              },
            });
          }
        } catch (e: any) {
          if (e instanceof FatalSourceError) throw e;
          opts.errors.push(`reddit r/${sub} "${band}": ${e.message}`);
        }
        await sleep(1100); // respeta el rate limit
      }
    }
  } catch (e: any) {
    if (!(e instanceof FatalSourceError)) throw e;
    opts.errors.push(e.message);
  }
  return out;
}
