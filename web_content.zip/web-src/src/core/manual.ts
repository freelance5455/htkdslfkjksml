import type { FanCandidate, Source } from './types';

export interface ParsedProfile {
  id: string; // sin el prefijo de red
  displayName: string;
  profileUrl: string;
}

const tryUrl = (raw: string): URL | null => {
  const s = raw.trim();
  try {
    if (/^https?:\/\//i.test(s)) return new URL(s);
    if (/^(www\.|m\.|vm\.)?[a-z0-9-]+\.(com|tv|be)\//i.test(s)) return new URL('https://' + s);
  } catch {
    /* no es un enlace */
  }
  return null;
};
const bad = (msg: string) => new Error(msg);

/** Lee un usuario o enlace de perfil de la red indicada. */
export function parseProfile(source: Source, input: string): ParsedProfile {
  const raw = input.trim();
  if (!raw) throw bad('Escribe el usuario o pega el enlace de su perfil.');
  const u = tryUrl(raw);
  const seg = u ? u.pathname.split('/').filter(Boolean) : [];
  const handle = (s: string) => s.replace(/^@/, '').replace(/^\/+|\/+$/g, '');

  switch (source) {
    case 'instagram': {
      let name = u ? seg[0] ?? '' : handle(raw);
      if (u && ['p', 'reel', 'reels', 'stories', 'explore', 'tv', 'accounts', 'direct'].includes(name.toLowerCase()))
        throw bad('Ese enlace es de una publicación. Abre su perfil y pega el enlace del perfil o su usuario.');
      name = handle(name);
      if (!/^[A-Za-z0-9._]{1,30}$/.test(name)) throw bad('Usuario de Instagram no válido.');
      return { id: name.toLowerCase(), displayName: `@${name}`, profileUrl: `https://www.instagram.com/${name}/` };
    }
    case 'tiktok': {
      if (u && /^vm\.|^vt\./i.test(u.hostname)) throw bad('Es un enlace corto de TikTok. Ábrelo y copia el @usuario.');
      const name = handle(u ? (seg.find((x) => x.startsWith('@')) ?? '') : raw);
      if (!/^[A-Za-z0-9._]{2,24}$/.test(name)) throw bad('Usuario de TikTok no válido. Usa @usuario o el enlace de su perfil.');
      return { id: name.toLowerCase(), displayName: `@${name}`, profileUrl: `https://www.tiktok.com/@${name}` };
    }
    case 'facebook': {
      if (u) {
        if (seg[0] === 'profile.php') {
          const id = u.searchParams.get('id') ?? '';
          if (!/^\d{5,}$/.test(id)) throw bad('Enlace de perfil de Facebook no válido.');
          return { id, displayName: `Facebook ${id}`, profileUrl: `https://www.facebook.com/profile.php?id=${id}` };
        }
        if (seg[0] === 'people' && /^\d{5,}$/.test(seg[2] ?? '')) {
          return { id: seg[2], displayName: decodeURIComponent(seg[1]).replace(/[-+]/g, ' '), profileUrl: `https://www.facebook.com/profile.php?id=${seg[2]}` };
        }
        if (!seg[0] || ['groups', 'pages', 'watch', 'permalink.php', 'share', 'photo', 'photo.php', 'story.php', 'posts', 'reel', 'hashtag'].includes(seg[0]))
          throw bad('Ese enlace no es de un perfil. Abre el perfil de la persona y pega su enlace.');
      }
      const name = handle(u ? seg[0] : raw);
      if (!/^[A-Za-z0-9.]{5,}$/.test(name)) throw bad('Usuario de Facebook no válido.');
      return { id: name.toLowerCase(), displayName: name, profileUrl: `https://www.facebook.com/${name}` };
    }
    case 'youtube': {
      if (u) {
        const i = seg.findIndex((x) => x.startsWith('@'));
        if (i >= 0) {
          const h = handle(seg[i]);
          return { id: h.toLowerCase(), displayName: `@${h}`, profileUrl: `https://www.youtube.com/@${h}` };
        }
        if (seg[0] === 'channel' && /^UC[\w-]{20,}$/.test(seg[1] ?? '')) return { id: seg[1], displayName: seg[1], profileUrl: `https://www.youtube.com/channel/${seg[1]}` };
        if ((seg[0] === 'c' || seg[0] === 'user') && seg[1]) return { id: seg[1].toLowerCase(), displayName: seg[1], profileUrl: `https://www.youtube.com/${seg[0]}/${seg[1]}` };
        throw bad('Pega el enlace del canal (youtube.com/@usuario o /channel/…).');
      }
      const h = handle(raw);
      if (/^UC[\w-]{20,}$/.test(h)) return { id: h, displayName: h, profileUrl: `https://www.youtube.com/channel/${h}` };
      if (!/^[\w.-]{3,30}$/.test(h)) throw bad('Usuario de YouTube no válido.');
      return { id: h.toLowerCase(), displayName: `@${h}`, profileUrl: `https://www.youtube.com/@${h}` };
    }
    case 'reddit': {
      let name = '';
      if (u) {
        const i = seg.findIndex((x) => x === 'user' || x === 'u');
        name = i >= 0 ? seg[i + 1] ?? '' : '';
      } else name = raw.replace(/^\/?u(ser)?\//i, '');
      if (!/^[A-Za-z0-9_-]{3,20}$/.test(name)) throw bad('Usuario de Reddit no válido. Usa u/usuario o el enlace de su perfil.');
      return { id: name.toLowerCase(), displayName: `u/${name}`, profileUrl: `https://www.reddit.com/user/${name}` };
    }
  }
}

export interface ManualInput {
  source: Source;
  who: string; // usuario o enlace de perfil
  band?: string; // banda parecida con la que se relaciona (opcional)
  note?: string; // qué hizo/comentó (opcional)
  evidenceUrl?: string; // enlace a su comentario o publicación (opcional, https)
}

/** Crea un candidato a partir de un alta manual. */
export function buildManualFan(i: ManualInput): FanCandidate {
  const p = parseProfile(i.source, i.who);
  const note = (i.note ?? '').trim().slice(0, 280);
  const evUrl = (i.evidenceUrl ?? '').trim();
  if (evUrl && !/^https:\/\//i.test(evUrl)) throw bad('El enlace de la prueba debe empezar con https://');
  const band = (i.band ?? '').trim();
  const evidence = note || evUrl ? [{ source: i.source, band: band || 'manual', text: note, url: evUrl || p.profileUrl }] : [];
  return {
    id: `${i.source}:${p.id}`,
    source: i.source,
    displayName: p.displayName,
    profileUrl: p.profileUrl,
    evidence,
    bands: band ? [band] : [],
    score: 30,
    reasons: ['Agregado manualmente', ...(band ? [`Relacionado con ${band}`] : [])],
    status: 'NEW',
    foundAt: new Date().toISOString(),
  };
}
