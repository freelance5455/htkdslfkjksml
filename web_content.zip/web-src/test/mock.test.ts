import assert from 'node:assert/strict';
import { searchFans } from '../src/core/search';
import { createStore, type KV } from '../src/core/store';
import { hasDiscoveryLanguage, aggregateAndScore } from '../src/core/score';
import type { RawFan } from '../src/core/types';
import { createAuthStore, googleStart, googlePoll, googleRefresh, redditAuthUrl, parseRedditCallback, redditExchange, freshToken, REDDIT_REDIRECT } from '../src/core/auth';
import { youtubeCommentId, youtubeReply, redditMessage } from '../src/core/actions';
import { parseProfile, buildManualFan } from '../src/core/manual';
import { shortcuts, hashtagify } from '../src/core/shortcuts';
import { metaConnect, instagramReply, facebookReply, activePage } from '../src/core/meta';
import type { MetaCreds } from '../src/core/types';

const mem = (): KV & { m: Map<string, string> } => {
  const m = new Map<string, string>();
  return { m, getItem: (k) => m.get(k) ?? null, setItem: (k, v) => void m.set(k, v), removeItem: (k) => void m.delete(k) };
};
const recent = new Date(Date.now() - 10 * 864e5).toISOString();
const json = (o: unknown, status = 200) => new Response(JSON.stringify(o), { status });
const noSleep = async () => {};
const creds = { youtubeKey: 'fake' };

// ---------- 1) Flujo completo con APIs simuladas (igual que el test original) ----------
globalThis.fetch = (async (input: any) => {
  const url = String(input);
  if (url.includes('/youtube/v3/search')) {
    const q = new URL(url).searchParams.get('q')!;
    return json({ items: [{ id: { videoId: q.startsWith('BandA') || q.startsWith('BandaA') ? 'vA' : 'vB' } }, { id: { videoId: 'vBIG' } }] });
  }
  if (url.includes('/youtube/v3/videos')) {
    return json({
      items: [
        { id: 'vA', statistics: { viewCount: '800', commentCount: '5' }, snippet: { channelId: 'chA' } },
        { id: 'vB', statistics: { viewCount: '1200', commentCount: '3' }, snippet: { channelId: 'chB' } },
        { id: 'vBIG', statistics: { viewCount: '9000000', commentCount: '900' }, snippet: { channelId: 'chX' } },
      ].filter((v) => url.includes(v.id)),
    });
  }
  if (url.includes('/youtube/v3/commentThreads')) {
    const vid = new URL(url).searchParams.get('videoId')!;
    const mk = (id: string, name: string, text: string, likes = 0) => ({
      id: `c-${id}-${vid}`,
      snippet: { topLevelComment: { snippet: { authorChannelId: { value: id }, authorDisplayName: name, authorChannelUrl: `https://www.youtube.com/channel/${id}`, textDisplay: text, likeCount: likes, publishedAt: recent } } },
    });
    return json({
      items: [
        mk('UClucia', 'Lucia Metal', 'Qué joya, no conocía esta banda, de CDMX!', 6),
        mk('UCown', 'BandaA Official', 'gracias por escuchar'),
        mk(vid === 'vA' ? 'chA' : 'chB', 'x', 'owner'), // el dueño comenta en SU video
        ...(vid === 'vA' ? [mk('UCpedro', 'Pedro', 'ok')] : []),
      ],
    });
  }
  if (url.includes('reddit.com') && url.includes('/search')) {
    return json({ data: { children: [
      { data: { author: 'AutoModerator', title: 'x', permalink: '/r/x/1' } },
      { data: { author: 'Lucia_Riffs', title: 'Alguien conoce algo parecido a BandaA?', selftext: '', permalink: '/r/deathmetal/comments/abc', score: 4, created_utc: Date.now() / 1000 } },
    ] } });
  }
  throw new Error('URL inesperada en el test: ' + url);
}) as typeof fetch;

const r = await searchFans({ bands: ['BandaA', 'BandaB'], genre: 'death thrash', city: 'CDMX', subreddits: ['deathmetal'] }, creds, undefined, { redditSleep: noSleep });
assert.equal(r.candidates[0].id, 'youtube:UClucia', 'la fan que comenta en 2 bandas debe ir primero');
assert.deepEqual([...r.candidates[0].bands].sort(), ['BandaA', 'BandaB']);
assert.ok(r.candidates[0].reasons.some((x) => x.includes('CDMX')), 'detecta ciudad');
assert.ok(!r.candidates.some((c) => /official/i.test(c.displayName)), 'filtra canales oficiales/propios');
assert.ok(!r.candidates.some((c) => c.id === 'youtube:chB' || c.id === 'youtube:chA'), 'filtra al dueño del video');
assert.ok(r.candidates.some((c) => c.id === 'youtube:UCpedro'), 'trae comentaristas del video A (cada banda va a su video)');
assert.ok(!r.candidates.some((c) => c.id.includes('automoderator')), 'filtra bots de reddit');
assert.ok(r.candidates.some((c) => c.id === 'reddit:lucia_riffs'), 'reddit: id en minúsculas (usuarios sin distinción de mayúsculas)');
assert.ok(!JSON.stringify(r).includes('vBIG'), 'ignora videos masivos');

// ---------- 2) Persistencia + dedupe + estado ----------
const kv = mem();
const store = createStore(kv);
assert.deepEqual(store.upsertMany(r.candidates), { added: r.candidates.length, updated: 0 });
store.setStatus('youtube:UClucia', 'CONTACTED');
assert.deepEqual(store.upsertMany(r.candidates), { added: 0, updated: r.candidates.length });
assert.equal(store.listAll('CONTACTED')[0].id, 'youtube:UClucia', 'conserva el status al re-buscar');
assert.equal(store.setStatus('nope', 'FAN'), null);
// respaldo ida y vuelta
const backup = store.exportJson();
const kv2 = mem();
assert.equal(createStore(kv2).importJson(backup), r.candidates.length);
assert.equal(createStore(kv2).listAll('CONTACTED').length, 1);

// ---------- 3) Corrección: almacenamiento dañado no se pierde en silencio ----------
const kvBad = mem();
kvBad.setItem('fanradar.db.v1', '{esto no es json');
const sBad = createStore(kvBad);
assert.deepEqual(sBad.listAll(), []);
assert.ok([...kvBad.m.keys()].some((k) => k.startsWith('fanradar.db.v1.corrupt.')), 'guarda copia del dato dañado');

// ---------- 4) Corrección: regex de descubrimiento ----------
assert.equal(hasDiscoveryLanguage('Gemini me recomendó esto'), true, '"recomend" sí cuenta');
assert.equal(hasDiscoveryLanguage('mira Gemini y las news de hoy'), false, '"gem" dentro de Gemini y "new" dentro de news ya no cuentan');
assert.equal(hasDiscoveryLanguage('what a gem'), true);
assert.equal(hasDiscoveryLanguage('this is new to me'), true);

// ---------- 5) Corrección: bandas de nombre muy corto no borran cuentas ----------
const mkRaw = (name: string, id: string, band = 'X'): RawFan => ({ source: 'youtube', authorId: id, displayName: name, profileUrl: 'https://www.youtube.com/channel/' + id, evidence: { source: 'youtube', band, text: 'hola', url: 'https://www.youtube.com/watch?v=1' } });
const short = aggregateAndScore([mkRaw('Rafael Metalero', 'UC1')], { bands: ['Ra'] });
assert.equal(short.length, 1, 'banda "Ra" no debe descartar a "Rafael"');

// ---------- 6) Corrección: ciudad con alias ----------
const cdmx = aggregateAndScore([{ ...mkRaw('Ana', 'UC2'), evidence: { source: 'youtube', band: 'X', text: 'Soy de CDMX y me late', url: 'https://www.youtube.com/watch?v=2' } }], { bands: ['Zzz'], city: 'Ciudad de México' });
assert.ok(cdmx[0].reasons.some((x) => x.startsWith('Menciona')), '"Ciudad de México" detecta "CDMX"');

// ---------- 7) Corrección: cuota agotada detiene YouTube (no gasta ni reintenta por banda) ----------
let ytCalls = 0;
globalThis.fetch = (async (input: any) => {
  if (String(input).includes('/youtube/v3/')) {
    ytCalls++;
    return json({ error: { errors: [{ reason: 'quotaExceeded' }] } }, 403);
  }
  throw new Error('inesperado');
}) as typeof fetch;
const q = await searchFans({ bands: ['A1x', 'B2x', 'C3x'], sources: ['youtube'] }, creds);
assert.equal(ytCalls, 1, 'tras quotaExceeded no se hacen más llamadas');
assert.ok(q.stats.errors.some((e) => e.includes('cuota diaria agotada')));

// ---------- 8) Corrección: Reddit 429 corta el recorrido ----------
let rdCalls = 0;
globalThis.fetch = (async (input: any) => {
  if (String(input).includes('reddit.com')) { rdCalls++; return json({}, 429); }
  throw new Error('inesperado');
}) as typeof fetch;
const rd = await searchFans({ bands: ['A1x', 'B2x'], subreddits: ['a', 'b'], sources: ['reddit'] }, {}, undefined, { redditSleep: noSleep });
assert.equal(rdCalls, 1, 'tras 429 no se insiste');
assert.ok(rd.stats.errors.some((e) => e.includes('429')));

// ---------- 9) Sin clave de YouTube / sin bandas ----------
const nk = await searchFans({ bands: ['A1x'], sources: ['youtube'] }, {});
assert.ok(nk.stats.errors[0].includes('clave de YouTube'));
await assert.rejects(() => searchFans({ bands: [' ', ''] }, creds), /al menos una banda/);



// =====================  SESIONES Y ENVÍO  =====================
type Call = { url: string; init?: any };
const calls: Call[] = [];
let handler: (url: string, init?: any) => Response = () => json({}, 404);
globalThis.fetch = (async (input: any, init?: any) => { calls.push({ url: String(input), init }); return handler(String(input), init); }) as typeof fetch;
const reset = (h: typeof handler) => { calls.length = 0; handler = h; };

// ---- 10) Búsqueda de YouTube con sesión de Google: Bearer y sin clave en la URL
reset((url) => {
  if (url.includes('/youtube/v3/search')) return json({ items: [{ id: { videoId: 'v1' } }] });
  if (url.includes('/youtube/v3/videos')) return json({ items: [{ id: 'v1', statistics: { viewCount: '5', commentCount: '1' }, snippet: { channelId: 'o' } }] });
  return json({ items: [] });
});
await searchFans({ bands: ['Zeta Band'], sources: ['youtube'] }, { youtubeToken: 'TOK' });
assert.ok(calls.length >= 2 && calls.every((c) => c.init?.headers?.Authorization === 'Bearer TOK' && !c.url.includes('key=')), 'usa Bearer y no manda la clave');
reset(() => json({ items: [] }));
await searchFans({ bands: ['Zeta Band'], sources: ['youtube'] }, { youtubeKey: 'K' });
assert.ok(calls[0].url.includes('key=K') && !calls[0].init?.headers, 'sin sesión usa la clave');

// ---- 11) Reddit con sesión: oauth.reddit.com + Bearer, sin pedir token de app
reset((url) => (url.includes('/search') ? json({ data: { children: [] } }) : json({}, 500)));
await searchFans({ bands: ['Zeta Band'], subreddits: ['x'], sources: ['reddit'] }, { redditToken: 'RT' }, undefined, { redditSleep: noSleep });
assert.ok(calls.length === 1 && calls[0].url.startsWith('https://oauth.reddit.com/r/x/search?') && calls[0].init.headers.Authorization === 'Bearer RT');

// ---- 12) Google: flujo de dispositivos
reset(() => json({ device_code: 'DC', user_code: 'ABCD-EFGH', verification_url: 'https://www.google.com/device', expires_in: 1800, interval: 5 }));
const dc = await googleStart('CID');
assert.equal(dc.userCode, 'ABCD-EFGH');
assert.ok(calls[0].init.body.includes('client_id=CID') && calls[0].init.body.includes('scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fyoutube'));
reset(() => json({ error: 'invalid_client', error_description: 'bad' }, 401));
await assert.rejects(() => googleStart('MAL'), /Google: bad/);

const seq = ['authorization_pending', 'slow_down', 'ok'];
const sleeps: number[] = [];
reset(() => { const k = seq.shift()!; return k === 'ok' ? json({ access_token: 'AT', refresh_token: 'RF', expires_in: 3600 }) : json({ error: k }, 400); });
const gt = await googlePoll({ clientId: 'CID', clientSecret: 'SEC' }, dc, { isCancelled: () => false, sleep: async (ms) => void sleeps.push(ms) });
assert.deepEqual([gt.access, gt.refresh], ['AT', 'RF']);
assert.deepEqual(sleeps, [5000, 5000, 10000], 'slow_down suma 5 s al intervalo');
assert.ok(calls[0].init.body.includes('grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Adevice_code') && calls[0].init.body.includes('client_secret=SEC'));
reset(() => json({ error: 'access_denied' }, 400));
await assert.rejects(() => googlePoll({ clientId: 'a', clientSecret: 'b' }, dc, { isCancelled: () => false, sleep: noSleep }), /Rechazaste/);
reset(() => json({ error: 'expired_token' }, 400));
await assert.rejects(() => googlePoll({ clientId: 'a', clientSecret: 'b' }, dc, { isCancelled: () => false, sleep: noSleep }), /expiró/);
await assert.rejects(() => googlePoll({ clientId: 'a', clientSecret: 'b' }, dc, { isCancelled: () => true, sleep: noSleep }), /cancelado/);

// ---- 13) Renovación de tokens
reset(() => json({ access_token: 'NEW', expires_in: 3600 }));
const rf = await googleRefresh({ clientId: 'a', clientSecret: 'b' }, { access: 'old', refresh: 'RF', exp: 0 });
assert.equal(rf.access, 'NEW'); assert.equal(rf.refresh, 'RF');
reset(() => json({ error: 'invalid_grant' }, 400));
await assert.rejects(() => googleRefresh({ clientId: 'a', clientSecret: 'b' }, { access: 'o', refresh: 'RF', exp: 0 }), /7 días/);

const auth = createAuthStore(mem());
const ids = { googleClientId: 'a', googleClientSecret: 'b', redditClientId: 'r' };
assert.equal(await freshToken('google', auth, ids), null, 'sin sesión -> null');
auth.set('google', { access: 'VIGENTE', refresh: 'RF', exp: Date.now() + 3600_000 });
reset(() => json({}, 500));
assert.equal(await freshToken('google', auth, ids), 'VIGENTE'); assert.equal(calls.length, 0, 'vigente: no renueva');
auth.set('google', { access: 'VENCIDO', refresh: 'RF', exp: Date.now() + 10_000 });
reset(() => json({ access_token: 'RENOVADO', expires_in: 3600 }));
assert.equal(await freshToken('google', auth, ids), 'RENOVADO'); assert.equal(auth.get().google?.access, 'RENOVADO', 'guarda el token renovado');
auth.set('google', undefined); assert.equal(auth.get().google, undefined, 'cerrar sesión borra tokens');

// ---- 14) Reddit OAuth
const au = new URL(redditAuthUrl('RID', 'ST8'));
assert.equal(au.searchParams.get('redirect_uri'), REDDIT_REDIRECT); assert.equal(au.searchParams.get('duration'), 'permanent');
assert.equal(au.searchParams.get('scope'), 'identity read privatemessages');
assert.equal(parseRedditCallback('fanradar://reddit?code=XYZ&state=ST8#_', 'ST8'), 'XYZ');
assert.throws(() => parseRedditCallback('fanradar://reddit?code=XYZ&state=OTRO', 'ST8'), /estado inválido/);
assert.throws(() => parseRedditCallback('fanradar://reddit?error=access_denied', 'ST8'), /Rechazaste/);
reset(() => json({ access_token: 'RA', refresh_token: 'RR', expires_in: 3600 }));
const rt = await redditExchange('RID', 'XYZ');
assert.equal(rt.access, 'RA');
assert.equal(calls[0].init.headers.Authorization, 'Basic ' + btoa('RID:'));
assert.ok(calls[0].init.body.includes('grant_type=authorization_code') && calls[0].init.body.includes('code=XYZ'));
reset(() => json({ error: 'invalid_grant' }, 400));
await assert.rejects(() => redditExchange('RID', 'MAL'), /Reddit: invalid_grant/);

// ---- 15) Responder en YouTube
assert.equal(youtubeCommentId('https://www.youtube.com/watch?v=abc&lc=Ugx123'), 'Ugx123');
assert.equal(youtubeCommentId('basura'), null);
reset(() => json({ id: 'NUEVO' }));
assert.equal(await youtubeReply('TOK', 'Ugx123', 'Hola'), 'NUEVO');
assert.equal(calls[0].init.headers.Authorization, 'Bearer TOK');
assert.deepEqual(JSON.parse(calls[0].init.body), { snippet: { parentId: 'Ugx123', textOriginal: 'Hola' } });
reset(() => json({ error: { errors: [{ reason: 'insufficientPermissions' }] } }, 403));
await assert.rejects(() => youtubeReply('T', 'p', 'x'), /Permisos insuficientes/);
reset(() => json({ error: { errors: [{ reason: 'commentsDisabled' }] } }, 403));
await assert.rejects(() => youtubeReply('T', 'p', 'x'), /no permite comentar/);
reset(() => json({}, 401));
await assert.rejects(() => youtubeReply('T', 'p', 'x'), /expiró/);

// ---- 16) Mensaje en Reddit
reset(() => json({ json: { errors: [] } }));
await redditMessage('RT', 'u/Lucia_Riffs', 'Asunto', 'Texto con & y ñ');
const sent = new URLSearchParams(calls[0].init.body);
assert.equal(sent.get('to'), 'Lucia_Riffs'); assert.equal(sent.get('text'), 'Texto con & y ñ'); assert.equal(sent.get('api_type'), 'json');
reset(() => json({ json: { errors: [['RATELIMIT', 'intenta en 5 minutos', 'ratelimit']] } }));
await assert.rejects(() => redditMessage('RT', 'x', 's', 't'), /demasiados envíos/);
reset(() => json({ json: { errors: [['USER_DOESNT_EXIST', 'x', 'to']] } }));
await assert.rejects(() => redditMessage('RT', 'x', 's', 't'), /ya no existe/);
reset(() => json({}, 429));
await assert.rejects(() => redditMessage('RT', 'x', 's', 't'), /limitó/);



// =====================  REDES: MANUAL, ATAJOS Y META  =====================
// ---- 17) Alta manual: lectura de usuarios y enlaces
const pp = (src: any, x: string) => { const r = parseProfile(src, x); return `${r.id}|${r.displayName}|${r.profileUrl}`; };
assert.equal(pp('instagram', '@Lucia.Metal'), 'lucia.metal|@Lucia.Metal|https://www.instagram.com/Lucia.Metal/');
assert.equal(pp('instagram', 'https://www.instagram.com/lucia.metal/?hl=es'), 'lucia.metal|@lucia.metal|https://www.instagram.com/lucia.metal/');
assert.throws(() => parseProfile('instagram', 'https://www.instagram.com/p/Cabc123/'), /publicación/);
assert.equal(pp('tiktok', 'https://www.tiktok.com/@thrash_mx/video/7123'), 'thrash_mx|@thrash_mx|https://www.tiktok.com/@thrash_mx');
assert.equal(pp('tiktok', '@Thrash_MX'), 'thrash_mx|@Thrash_MX|https://www.tiktok.com/@Thrash_MX');
assert.throws(() => parseProfile('tiktok', 'https://vm.tiktok.com/ZMabc/'), /corto/);
assert.equal(pp('facebook', 'https://www.facebook.com/profile.php?id=100012345678'), '100012345678|Facebook 100012345678|https://www.facebook.com/profile.php?id=100012345678');
assert.equal(pp('facebook', 'https://m.facebook.com/lucia.metal.mx?ref=x'), 'lucia.metal.mx|lucia.metal.mx|https://www.facebook.com/lucia.metal.mx');
assert.throws(() => parseProfile('facebook', 'https://www.facebook.com/groups/12345'), /no es de un perfil/);
assert.equal(pp('youtube', 'https://www.youtube.com/@DeathFan'), 'deathfan|@DeathFan|https://www.youtube.com/@DeathFan');
assert.equal(pp('youtube', 'https://www.youtube.com/channel/UCabcdefghijklmnopqrstuv'), 'UCabcdefghijklmnopqrstuv|UCabcdefghijklmnopqrstuv|https://www.youtube.com/channel/UCabcdefghijklmnopqrstuv');
assert.equal(pp('reddit', 'u/Lucia_Riffs'), 'lucia_riffs|u/Lucia_Riffs|https://www.reddit.com/user/Lucia_Riffs');
assert.equal(pp('reddit', 'https://www.reddit.com/user/Lucia_Riffs/'), 'lucia_riffs|u/Lucia_Riffs|https://www.reddit.com/user/Lucia_Riffs');
assert.throws(() => parseProfile('reddit', 'x'), /no válido/);
assert.throws(() => parseProfile('instagram', '   '), /Escribe/);

// ---- 18) Alta manual: candidato, fusión y estado conservado
const man = buildManualFan({ source: 'tiktok', who: '@thrash_mx', band: 'Banda A', note: 'Hizo un duet con Banda A', evidenceUrl: 'https://www.tiktok.com/@thrash_mx/video/1' });
assert.equal(man.id, 'tiktok:thrash_mx'); assert.equal(man.status, 'NEW'); assert.deepEqual(man.bands, ['Banda A']);
assert.throws(() => buildManualFan({ source: 'tiktok', who: '@thrash_mx', evidenceUrl: 'http://inseguro' }), /https/);
assert.equal(buildManualFan({ source: 'instagram', who: 'ana_riffs' }).evidence.length, 0, 'sin nota ni enlace: sin pruebas');
const ms = createStore(mem());
assert.equal(ms.addManual(man), 'added');
ms.setStatus('tiktok:thrash_mx', 'REPLIED');
const man2 = buildManualFan({ source: 'tiktok', who: 'https://www.tiktok.com/@Thrash_MX', band: 'Banda B', note: 'Otro comentario' });
assert.equal(ms.addManual(man2), 'updated');
const merged = ms.listAll()[0];
assert.equal(merged.status, 'REPLIED', 'conserva el estado'); assert.deepEqual([...merged.bands].sort(), ['Banda A', 'Banda B']); assert.equal(merged.evidence.length, 2);

// ---- 19) Atajos de búsqueda
assert.equal(hashtagify('Death Thrash!'), 'deaththrash'); assert.equal(hashtagify('Ñandú Metal'), 'nandumetal');
const sc = shortcuts('Death Thrash Metal');
assert.deepEqual(sc.map((x) => x.id), ['ig', 'tt', 'ttt', 'fb', 'fbg']);
assert.equal(sc[0].url, 'https://www.instagram.com/explore/tags/deaththrashmetal/');
assert.equal(sc[1].url, 'https://www.tiktok.com/search?q=Death%20Thrash%20Metal');
assert.deepEqual(shortcuts('   '), []);
assert.deepEqual(shortcuts('!!!').map((x) => x.id), ['tt', 'fb', 'fbg'], 'sin hashtag válido solo búsquedas');

// ---- 20) Conectar Meta
reset((url) => {
  const u = new URL(url);
  if (u.pathname.endsWith('/oauth/access_token')) return u.searchParams.get('client_secret') === 'MAL' ? json({ error: { message: 'Error validating client secret.', code: 1 } }, 400) : json({ access_token: 'LONG', expires_in: 5184000 });
  if (u.pathname.endsWith('/me/accounts')) return json({ data: [
    { id: 'P1', name: 'Mi Página sin IG', access_token: 'PT1' },
    { id: 'P2', name: '4PAIN', access_token: 'PT2', instagram_business_account: { id: 'IG2', username: '4pain_band' } },
  ] });
  if (u.pathname.endsWith('/me')) return json({ name: 'Lee' });
  return json({}, 404);
});
const ses = await metaConnect({ appId: 'APP', appSecret: 'SEC', userToken: 'SHORT' });
assert.equal(ses.selected, 'P2', 'prefiere la Página con Instagram'); assert.equal(ses.pages.length, 2); assert.equal(ses.userName, 'Lee');
assert.equal(activePage(ses)?.igUsername, '4pain_band');
const exu = new URL(calls[0].url);
assert.equal(exu.searchParams.get('fb_exchange_token'), 'SHORT'); assert.equal(exu.searchParams.get('client_id'), 'APP'); assert.equal(exu.searchParams.get('grant_type'), 'fb_exchange_token');
assert.ok(!exu.searchParams.has('access_token'), 'el intercambio no manda access_token');
assert.equal(new URL(calls[1].url).searchParams.get('access_token'), 'LONG', 'las Páginas se piden con el token largo');
await assert.rejects(() => metaConnect({ appId: 'APP', appSecret: 'MAL', userToken: 'S' }), /Meta 1: Error validating client secret/);
reset((url) => (url.includes('/me/accounts') ? json({ data: [] }) : json({ access_token: 'LONG' })));
await assert.rejects(() => metaConnect({ appId: 'A', appSecret: 'B', userToken: 'S' }), /no devolvió Páginas/);

// ---- 21) Leer comentarios propios de Instagram y Facebook
const page = ses.pages[1];
const meta: MetaCreds = { page, label: '4PAIN' };
const t0 = new Date(Date.now() - 4 * 864e5).toISOString();
reset((url) => {
  const u = new URL(url); const p = u.pathname.replace('/v23.0', '');
  if (p === '/IG2/media') return json({ data: [{ id: 'M1', permalink: 'https://www.instagram.com/p/AAA/', comments_count: 3 }, { id: 'M2', permalink: 'https://www.instagram.com/p/BBB/', comments_count: 0 }] });
  if (p === '/M1/comments') return json({ data: [
    { id: 'C1', text: 'qué joya de banda desde CDMX', username: 'Fan_Uno', timestamp: t0, like_count: 4 },
    { id: 'C2', text: 'brutal', username: 'fan_uno', timestamp: t0, like_count: 0 },
    { id: 'C3', text: 'gracias!', username: '4pain_band', timestamp: t0 },
  ] });
  if (p === '/IG2/tags') return json({ data: [{ id: 'T1', caption: 'con 4PAIN en vivo', permalink: 'https://www.instagram.com/p/CCC/', username: 'fan_dos', timestamp: t0, like_count: 9 }] });
  if (p === '/P2/posts') return json({ data: [{ id: 'P2_1', permalink_url: 'https://www.facebook.com/P2/posts/1' }] });
  if (p === '/P2_1/comments') return json({ data: [
    { id: 'FC1', from: { id: '111', name: 'María Metalera' }, message: 'Los vi, increíble', created_time: t0, like_count: 2, permalink_url: 'https://www.facebook.com/P2/posts/1?comment_id=FC1' },
    { id: 'FC2', from: { id: 'P2', name: '4PAIN' }, message: 'gracias', created_time: t0 },
    { id: 'FC3', message: 'sin autor visible', created_time: t0 },
  ] });
  return json({ error: { message: 'no existe', code: 100 } }, 400);
});
const mres = await searchFans({ bands: [], sources: ['instagram', 'facebook'] }, { meta });
const ids2 = mres.candidates.map((c) => c.id).sort();
assert.deepEqual(ids2, ['facebook:111', 'instagram:fan_dos', 'instagram:fan_uno'], 'sin la propia cuenta ni comentarios sin autor');
assert.equal(mres.stats.errors.length, 0, JSON.stringify(mres.stats.errors));
const fu = mres.candidates.find((c) => c.id === 'instagram:fan_uno')!;
assert.equal(fu.displayName, '@Fan_Uno'); assert.equal(fu.profileUrl, 'https://www.instagram.com/Fan_Uno/');
assert.equal(fu.evidence[0].refId, 'C1', 'guarda el id del comentario para responder');
assert.ok(fu.reasons.some((r) => r.includes('4PAIN')) && fu.reasons.some((r) => r.includes('2 interacciones')) && fu.reasons.some((r) => r.startsWith('Menciona')) === false);
const fb1 = mres.candidates.find((c) => c.id === 'facebook:111')!;
assert.equal(fb1.profileUrl, 'https://www.facebook.com/P2/posts/1?comment_id=FC1'); assert.equal(fb1.evidence[0].refId, 'FC1');
assert.ok(calls.every((c) => new URL(c.url).searchParams.get('access_token') === 'PT2'), 'todo con el token de Página');

// solo Instagram, Página sin IG, y sin Meta conectado
reset(() => json({ data: [] }));
const noig = await searchFans({ bands: [], sources: ['instagram'] }, { meta: { page: ses.pages[0], label: 'x' } });
assert.ok(noig.stats.errors[0].includes('no tiene un Instagram profesional'));
const nometa = await searchFans({ bands: [], sources: ['facebook'] }, {});
assert.ok(nometa.stats.errors[0].includes('Conecta Meta'));
await assert.rejects(() => searchFans({ bands: [], sources: ['youtube'] }, {}), /al menos una banda/);

// ---- 22) Token vencido (190) detiene todo con mensaje claro; permisos (10) también
reset(() => json({ error: { message: 'Error validating access token', code: 190 } }, 400));
const exp = await searchFans({ bands: [], sources: ['instagram', 'facebook'] }, { meta });
assert.ok(exp.stats.errors.some((e) => e.includes('caducó')) && calls.length === 1, 'tras 190 no se insiste');
reset(() => json({ error: { message: '(#10) permiso', code: 10 } }, 403));
const perm = await searchFans({ bands: [], sources: ['facebook'] }, { meta });
assert.ok(perm.stats.errors[0].includes('falta un permiso'));

// ---- 23) Responder
reset(() => json({ id: 'R1' }));
assert.equal(await instagramReply('PT2', 'C1', 'Gracias por escuchar'), 'R1');
assert.ok(calls[0].url.endsWith('/v23.0/C1/replies') && calls[0].init.method === 'POST');
const rb = new URLSearchParams(calls[0].init.body); assert.equal(rb.get('message'), 'Gracias por escuchar'); assert.equal(rb.get('access_token'), 'PT2');
assert.equal(await facebookReply('PT2', 'FC1', 'Hola'), 'R1');
assert.ok(calls[1].url.endsWith('/v23.0/FC1/comments'));
reset(() => json({ error: { message: 'Invalid parameter', code: 100 } }, 400));
await assert.rejects(() => instagramReply('T', 'X', 'x'), /Meta 100: Invalid parameter/);

console.log('OK: todas las verificaciones pasaron');
