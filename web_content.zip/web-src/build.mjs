import { build } from 'esbuild';
import fs from 'node:fs';

const OUT = process.env.OUT ?? '../app/src/main/assets/www';
fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(OUT, { recursive: true });

await build({ entryPoints: ['src/app/main.ts'], bundle: true, outfile: `${OUT}/app.js`, format: 'iife', target: 'chrome90', minify: true, logLevel: 'info' });
for (const f of ['index.html', 'styles.css']) fs.copyFileSync(`web/${f}`, `${OUT}/${f}`);
console.log(`${OUT} listo`);
