# Histoarall — Phase 01 MVP

Community chat platform (servers, channels, real-time messaging, friends, DMs, notifications, search, settings).

> **Status: written but NOT yet executed.** This code was authored in an environment with no network access, so
> `npm install`, Prisma migrations, the dev servers, Vitest and Playwright have **not been run**. Expect to fix a few
> type/runtime errors on first launch. See "Known limitations".

## Run it
```bash
npm install                      # installs both workspaces
npm run db:up                    # PostgreSQL 16 via Docker Compose
cp server/.env.example server/.env   # (already copied once; edit if needed)
npm run migrate -w server -- --name init   # creates + applies the initial migration, generates Prisma client
npm run seed -w server           # demo data
npm run dev                      # API :4000 + web :5173
```
Open http://localhost:5173. Demo accounts: `alice`, `bob`, `carol`, `dave`, `erin` — password `DemoPass123!` (dev only).

Tests: `npm test` (Vitest, no DB needed) · `npm run e2e -w client` (Playwright; needs DB seeded, `npx playwright install` first).
Quality: `npm run lint` · `npm run format` · `npm run typecheck`.

## Environment variables (`server/.env`)
| Var | Default | Purpose |
|---|---|---|
| DATABASE_URL | — (required) | PostgreSQL connection string |
| PORT | 4000 | API port |
| CLIENT_ORIGIN | http://localhost:5173 | Exact browser origin; used for CORS and the WebSocket origin check |
| NODE_ENV | development | `production` enables Secure cookies and trust-proxy |
| SESSION_TTL_DAYS | 14 | Session lifetime |
| UPLOAD_DIR | uploads | Where avatars / server icons are stored |

## Architecture
- `server/src/auth.ts` session cookies (opaque token, SHA-256 hash stored), Argon2id, double-submit CSRF.
- `server/src/perms.ts` all authorization (membership, role permissions, private channels). Non-members get 404s.
- `server/src/routes/*` REST; `server/src/socket.ts` Socket.IO (cookie-authenticated, origin-checked, per-socket rate limit).
- Messages are persisted first, then broadcast. `clientId` + unique `(authorId, clientId)` makes retries idempotent.
- `client/src/store.ts` Zustand store; `client/src/socket.ts` realtime wiring. Vite proxies `/api`, `/uploads`, `/socket.io`.

## Database (Prisma, `server/prisma/schema.prisma`)
User, Session, Server, ServerMember, Role, Permission, ChannelCategory, Channel, Message, MessageReaction, Attachment,
Friendship (BLOCKED rows: requester = blocker), DirectConversation, DirectConversationMember, DirectMessage, Notification,
ServerInvitation. UUID ids. Deletion policy is documented at the top of the schema.

## Known limitations
- Not executed or tested yet (see above). No migration SQL is committed; you generate it with the `migrate` command.
- Voice channels, mic and headphone buttons are visual placeholders (labelled as such in the UI).
- Password reset is a documented placeholder (no email delivery).
- Presence is in-memory: single server instance only.
- Search covers channel messages you can access, not DMs.
- DM messages can't be edited or deleted; reactions exist for channel messages only.
- Roles are fixed (Admin / Member) with fixed permission sets; fine-grained roles are Phase 04.
- Only unit tests exist (validation, upload sniffing, Argon2). Authorization/integration tests and Playwright runs are still TODO.
- No unread markers for channels; notification badges cover friends, invites and DMs.

## Phase 02 suggestions
Run and harden Phase 01 first; add API integration tests for every authorization rule; typing indicators; unread channel
markers; custom themes and animation polish; profile banners; attachment uploads in messages; email-based password reset.

## Deploy + Android APK
The APK cannot contain the Node/PostgreSQL backend, so the app is deployed once and the APK is a shell around it.
1. Deploy (Render / Railway / any VPS) with a PostgreSQL database. Build: `npm install && npm run build`. Start: `npm start`.
   Env: `DATABASE_URL`, `NODE_ENV=production`, `CLIENT_ORIGIN=https://your-app-url` (must match exactly). Run `npm run seed -w server` once if you want demo data.
   First deploy needs a migration committed: run `npm run migrate -w server -- --name init` locally and commit `server/prisma/migrations`.
   Note: uploaded avatars live on disk (`UPLOAD_DIR`); use a persistent disk on your host.
2. Easiest APK: open https://www.pwabuilder.com, enter your URL, choose Android, download the package (APK/AAB).
3. Alternative (Capacitor): edit `client/capacitor.config.json` (set `server.url`), then in `client/`:
   `npm i @capacitor/core @capacitor/cli @capacitor/android && npx cap add android && npx cap open android` and Build > Build APK in Android Studio.
