# Security overview (Phase 01)

## Implemented
- Passwords: Argon2id (19 MiB / 2 iterations), policy (min 10 chars, no common passwords, no username/email inside).
- Sessions: 256-bit random token in an HttpOnly, SameSite=Lax cookie (`__Host-` + Secure in production); only a SHA-256 hash is stored.
  Max 10 sessions per user; change password / "log out everywhere" revokes sessions and kills live sockets; sockets re-validate every 2 min.
- CSRF: double-submit token on every state-changing request + Origin check. JSON-only bodies.
- Brute force: IP rate limits, per-IP+account lockout (5 tries / 15 min), per-account lockout (30), timing equalisation for unknown users.
- Abuse: global and per-user write rate limits, per-socket message rate limit, 100 KB body / socket payload limits, DMs only between friends or people sharing a server.
- Headers: strict CSP, no framing, no-referrer, HSTS (helmet), nosniff. Uploads served with `CSP: sandbox` and validated by magic bytes (PNG/JPEG/WebP/GIF), random names, 2 MB limit; SVG rejected.
- Authorization: every resource is checked server-side (membership, role permissions, private channels); outsiders receive 404, not 403. Socket identity comes from the session only.
- Injection/XSS: Prisma parameterised queries, zod validation everywhere, React escaping, no raw HTML rendering.
- Ops: production refuses to start without an https CLIENT_ORIGIN; demo seed refuses to run in production; Postgres bound to localhost in Docker.

## NOT implemented yet (be honest with yourself before launch)
- Two-factor authentication, email verification, real password-reset email.
- Persistent audit log / alerting; rate-limit and lockout state is in memory (single instance).
- Antivirus / image re-encoding for uploads; end-to-end encryption of messages (messages are plaintext in the database).
- Automated dependency scanning: run `npm audit` and commit the lockfile.
- Independent penetration test. Nothing here has been run or tested yet.

## Your checklist before going public
Use HTTPS only · strong DB password and DB not exposed publicly · encrypted DB backups · persistent disk for uploads ·
`npm audit` clean · keep Node/Postgres updated · never commit `.env`.
