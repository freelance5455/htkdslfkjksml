import 'dotenv/config';
import { z } from 'zod';

const schema = z.object({
  DATABASE_URL: z.string().min(1),
  PORT: z.coerce.number().default(4000),
  CLIENT_ORIGIN: z.string().default('http://localhost:5173'),
  NODE_ENV: z.string().default('development'),
  SESSION_TTL_DAYS: z.coerce.number().default(14),
  UPLOAD_DIR: z.string().default('uploads'),
});
export const env = schema.parse(process.env);
if (env.NODE_ENV === 'production' && !env.CLIENT_ORIGIN.startsWith('https://')) {
  throw new Error('In production CLIENT_ORIGIN must be an https:// origin (cookies are Secure-only).');
}
