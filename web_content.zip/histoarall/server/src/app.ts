import cookieParser from 'cookie-parser';
import cors from 'cors';
import express, { type NextFunction, type Request, type Response } from 'express';
import rateLimit from 'express-rate-limit';
import helmet from 'helmet';
import fs from 'node:fs';
import path from 'node:path';
import { ZodError } from 'zod';
import { attachUser, csrfGuard, requireAuth } from './auth';
import { env } from './env';
import { HttpError } from './errors';
import authRoutes from './routes/auth';
import channelRoutes from './routes/channels';
import messageRoutes from './routes/messages';
import serverRoutes from './routes/servers';
import socialRoutes from './routes/social';
import userRoutes from './routes/users';

export function createApp() {
  const app = express();
  if (env.NODE_ENV === 'production') app.set('trust proxy', 1);
  const ws = env.CLIENT_ORIGIN.replace(/^http/, 'ws');
  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'"],
          imgSrc: ["'self'", 'data:', 'blob:'], fontSrc: ["'self'"], connectSrc: ["'self'", ws],
          objectSrc: ["'none'"], frameAncestors: ["'none'"], baseUri: ["'self'"], formAction: ["'self'"],
        },
      },
      referrerPolicy: { policy: 'no-referrer' },
    }),
  );
  app.use(cors({ origin: env.CLIENT_ORIGIN, credentials: true }));
  app.use(express.json({ limit: '100kb' }));
  app.use(cookieParser());

  app.use(
    '/uploads',
    (_req, res, next) => {
      res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
      res.setHeader('Content-Security-Policy', "default-src 'none'; sandbox"); // uploaded files can never run script
      next();
    },
    express.static(path.resolve(env.UPLOAD_DIR), { index: false, dotfiles: 'deny' }),
  );

  app.get('/api/health', (_req, res) => res.json({ ok: true }));
  app.use('/api', rateLimit({ windowMs: 60_000, limit: 300, standardHeaders: true, legacyHeaders: false }));
  app.use('/api/auth/login', rateLimit({ windowMs: 15 * 60_000, limit: 20, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many attempts. Try again later.' } }));
  app.use('/api/auth/register', rateLimit({ windowMs: 60 * 60_000, limit: 20, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many attempts. Try again later.' } }));
  // Defence in depth for state-changing requests: Origin must match (in addition to the CSRF token).
  app.use('/api', (req, _res, next) => {
    const o = req.get('origin');
    if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method) && o && o !== env.CLIENT_ORIGIN) throw new HttpError(403, 'Bad origin');
    next();
  });
  app.use('/api', attachUser, csrfGuard);
  // Per-user write limiter (spam / abuse control).
  app.use('/api', rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: true, legacyHeaders: false, skip: (req) => ['GET', 'HEAD', 'OPTIONS'].includes(req.method), keyGenerator: (req) => req.user?.id ?? req.ip ?? 'anon', message: { error: 'Slow down a little.' } }));
  app.use('/api/auth', authRoutes);
  app.use('/api', requireAuth, userRoutes, serverRoutes, channelRoutes, messageRoutes, socialRoutes);
  app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found' }));

  // Production: serve the built web app (client/dist) with SPA fallback.
  const dist = path.resolve(process.cwd(), process.env.CLIENT_DIST || '../client/dist');
  if (fs.existsSync(path.join(dist, 'index.html'))) {
    app.use(express.static(dist));
    app.use((req, res, next) => {
      if (req.method !== 'GET' || /^\/(api|uploads|socket\.io)/.test(req.path)) return next();
      res.sendFile(path.join(dist, 'index.html'));
    });
  }

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    if (err instanceof HttpError) return res.status(err.status).json({ error: err.message });
    if (err instanceof ZodError) {
      const i = err.issues[0];
      return res.status(400).json({ error: i?.message || 'Invalid input' });
    }
    if (err?.code === 'P2025') return res.status(404).json({ error: 'Not found' });
    if (err?.code === 'P2002') return res.status(409).json({ error: 'That already exists' });
    if (err?.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: 'File too large (max 2 MB)' });
    if (err?.type === 'entity.parse.failed') return res.status(400).json({ error: 'Malformed JSON' });
    console.error(err);
    res.status(500).json({ error: 'Something went wrong' });
  });
  return app;
}
