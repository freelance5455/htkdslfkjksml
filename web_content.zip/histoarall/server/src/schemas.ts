import { z } from 'zod';

export const contentSchema = z
  .string()
  .transform((s) => s.trim())
  .pipe(z.string().min(1, 'Message cannot be empty').max(2000, 'Message is too long (max 2000 characters)'));
export const sendSchema = z.object({ channelId: z.string().uuid(), content: contentSchema, clientId: z.string().uuid() });
export const dmSendSchema = z.object({ conversationId: z.string().uuid(), content: contentSchema, clientId: z.string().uuid() });
export const usernameSchema = z.string().regex(/^[a-zA-Z0-9_.]{3,32}$/, 'Username must be 3-32 characters: letters, numbers, _ or .');
export const passwordSchema = z.string().min(10, 'Password must be at least 10 characters').max(128);
export const idSchema = z.string().uuid();
export const channelName = z
  .string()
  .transform((s) => s.trim().toLowerCase().replace(/\s+/g, '-'))
  .pipe(z.string().regex(/^[a-z0-9_-]{1,50}$/, 'Channel names use letters, numbers, - and _ (max 50)'));
