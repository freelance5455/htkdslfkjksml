import { parse } from 'cookie';
import type http from 'node:http';
import { Server } from 'socket.io';
import { SESSION_COOKIE, userFromToken } from './auth';
import { prisma } from './db';
import { env } from './env';
import { HttpError } from './errors';
import { fmtDM, fmtMessage, messageInclude } from './lib/messages';
import { blockedBetween } from './lib/social';
import { channelAccess } from './perms';
import { USER_SELECT, broadcastPresence, markOffline, markOnline, notify, setIO } from './realtime';
import { dmSendSchema, idSchema, sendSchema } from './schemas';
import { z } from 'zod';

type Ack = (r: { ok: boolean; message?: any; error?: string; reactions?: any }) => void;
const fail = (ack: Ack | undefined, e: unknown) =>
  ack?.({ ok: false, error: e instanceof HttpError ? e.message : e instanceof z.ZodError ? e.issues[0]?.message : 'Could not complete that action' });

export function initSocket(server: http.Server) {
  const io = new Server(server, { cors: { origin: env.CLIENT_ORIGIN, credentials: true }, maxHttpBufferSize: 100_000 });
  setIO(io);

  io.use(async (socket, next) => {
    try {
      const origin = socket.handshake.headers.origin; // blocks cross-site WebSocket hijacking
      if (origin && origin !== env.CLIENT_ORIGIN) return next(new Error('forbidden'));
      const r = await userFromToken(parse(socket.handshake.headers.cookie || '')[SESSION_COOKIE]);
      if (!r) return next(new Error('unauthorized'));
      socket.data.sessionId = r.sessionId;
      socket.data.userId = r.user.id; // identity always comes from the session, never from client payloads
      next();
    } catch {
      next(new Error('unauthorized'));
    }
  });

  io.on('connection', async (socket) => {
    const uid: string = socket.data.userId;
    socket.join(`user:${uid}`);
    // Drop the socket as soon as its session is revoked/expired (checked every 2 min).
    const sid: string = socket.data.sessionId;
    const timer = setInterval(async () => {
      const s = await prisma.session.findUnique({ where: { id: sid } }).catch(() => null);
      if (!s || s.expiresAt < new Date()) socket.disconnect(true);
    }, 120_000);
    const mems = await prisma.serverMember.findMany({ where: { userId: uid }, select: { serverId: true } });
    mems.forEach((m) => socket.join(`server:${m.serverId}`));
    if (markOnline(uid)) broadcastPresence(uid);

    let tokens = 10;
    let last = Date.now();
    const allow = () => {
      const now = Date.now();
      tokens = Math.min(10, tokens + (now - last) / 500);
      last = now;
      if (tokens < 1) throw new HttpError(429, 'You are sending messages too fast');
      tokens -= 1;
    };

    socket.on('channel:join', async (channelId: string, ack?: Ack) => {
      try {
        const id = idSchema.parse(channelId);
        if (!(await channelAccess(uid, id))) throw new HttpError(404, 'Channel not found');
        socket.join(`channel:${id}`);
        ack?.({ ok: true });
      } catch (e) {
        fail(ack, e);
      }
    });
    socket.on('channel:leave', (channelId: string) => {
      if (typeof channelId === 'string') socket.leave(`channel:${channelId}`);
    });

    socket.on('message:send', async (raw: unknown, ack?: Ack) => {
      try {
        allow();
        const b = sendSchema.parse(raw);
        if (!(await channelAccess(uid, b.channelId))) throw new HttpError(404, 'Channel not found');
        let msg;
        try {
          msg = await prisma.message.create({ data: { channelId: b.channelId, authorId: uid, content: b.content, clientId: b.clientId }, include: messageInclude });
        } catch (e: any) {
          if (e?.code === 'P2002') {
            // Retry of an already-persisted message (e.g. after reconnect): return it, do not broadcast again.
            const dup = await prisma.message.findFirstOrThrow({ where: { authorId: uid, clientId: b.clientId }, include: messageInclude });
            return ack?.({ ok: true, message: fmtMessage(dup) });
          }
          throw e;
        }
        const out = fmtMessage(msg);
        io.to(`channel:${b.channelId}`).emit('message:new', out); // persisted first, then broadcast
        ack?.({ ok: true, message: out });
      } catch (e) {
        fail(ack, e);
      }
    });

    socket.on('reaction:toggle', async (raw: unknown, ack?: Ack) => {
      try {
        allow();
        const b = z.object({ messageId: idSchema, emoji: z.string().min(1).max(16) }).parse(raw);
        const m = await prisma.message.findUnique({ where: { id: b.messageId } });
        if (!m || !(await channelAccess(uid, m.channelId))) throw new HttpError(404, 'Message not found');
        const key = { messageId_userId_emoji: { messageId: b.messageId, userId: uid, emoji: b.emoji } };
        if (await prisma.messageReaction.findUnique({ where: key })) await prisma.messageReaction.delete({ where: key });
        else await prisma.messageReaction.create({ data: { messageId: b.messageId, userId: uid, emoji: b.emoji } });
        const full = await prisma.message.findUniqueOrThrow({ where: { id: b.messageId }, include: messageInclude });
        io.to(`channel:${m.channelId}`).emit('reaction:update', { messageId: m.id, channelId: m.channelId, reactions: fmtMessage(full).reactions });
        ack?.({ ok: true });
      } catch (e) {
        fail(ack, e);
      }
    });

    socket.on('dm:send', async (raw: unknown, ack?: Ack) => {
      try {
        allow();
        const b = dmSendSchema.parse(raw);
        const conv = await prisma.directConversation.findFirst({ where: { id: b.conversationId, members: { some: { userId: uid } } }, include: { members: true } });
        if (!conv) throw new HttpError(404, 'Conversation not found');
        const other = conv.members.find((m) => m.userId !== uid)!.userId;
        if (await blockedBetween(uid, other)) throw new HttpError(403, 'You cannot message this user');
        let msg;
        try {
          msg = await prisma.directMessage.create({ data: { conversationId: conv.id, authorId: uid, content: b.content, clientId: b.clientId }, include: { author: { select: USER_SELECT } } });
        } catch (e: any) {
          if (e?.code === 'P2002') {
            const dup = await prisma.directMessage.findFirstOrThrow({ where: { authorId: uid, clientId: b.clientId }, include: { author: { select: USER_SELECT } } });
            return ack?.({ ok: true, message: fmtDM(dup) });
          }
          throw e;
        }
        const out = fmtDM(msg);
        io.to([`user:${uid}`, `user:${other}`]).emit('dm:new', out);
        await notify(other, 'DIRECT_MESSAGE', { conversationId: conv.id, from: out.author?.displayName, preview: b.content.slice(0, 80) });
        ack?.({ ok: true, message: out });
      } catch (e) {
        fail(ack, e);
      }
    });

    socket.on('disconnect', () => {
      clearInterval(timer);
      if (markOffline(uid)) broadcastPresence(uid);
    });
  });
  return io;
}
