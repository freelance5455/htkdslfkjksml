import argon2 from 'argon2';
import crypto from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import { prisma } from './db';
import { env } from './env';
import { HttpError } from './errors';

// __Host- prefix (production): browser enforces Secure + path=/ + no Domain, blocking cookie-injection from subdomains.
const PFX = env.NODE_ENV === 'production' ? '__Host-' : '';
export const SESSION_COOKIE = `${PFX}hs_session`;
export const CSRF_COOKIE = `${PFX}hs_csrf`;
const MAX_SESSIONS = 10;

const sha = (s: string) => crypto.createHash('sha256').update(s).digest('hex');
// OWASP-recommended Argon2id parameters (19 MiB, 2 iterations, 1 lane).
export const hashPassword = (p: string) => argon2.hash(p, { type: argon2.argon2id, memoryCost: 19456, timeCost: 2, parallelism: 1 });
export const verifyPassword = async (hash: string, p: string) => {
  try {
    return await argon2.verify(hash, p);
  } catch {
    return false;
  }
};

const base = { sameSite: 'lax' as const, secure: env.NODE_ENV === 'production', path: '/' };
const maxAge = () => env.SESSION_TTL_DAYS * 86_400_000;

export async function createSession(res: Response, userId: string, userAgent?: string) {
  const token = crypto.randomBytes(32).toString('base64url');
  await prisma.session.create({
    data: { tokenHash: sha(token), userId, userAgent: userAgent?.slice(0, 200), expiresAt: new Date(Date.now() + maxAge()) },
  });
  res.cookie(SESSION_COOKIE, token, { ...base, httpOnly: true, maxAge: maxAge() });
  // Keep only the newest MAX_SESSIONS sessions per user.
  const old = await prisma.session.findMany({ where: { userId }, orderBy: { createdAt: 'desc' }, skip: MAX_SESSIONS, select: { id: true } });
  if (old.length) await prisma.session.deleteMany({ where: { id: { in: old.map((o) => o.id) } } });
}

export function ensureCsrf(req: Request, res: Response): string {
  const existing = req.cookies?.[CSRF_COOKIE];
  if (existing) return existing;
  const t = crypto.randomBytes(24).toString('base64url');
  res.cookie(CSRF_COOKIE, t, { ...base, httpOnly: false, maxAge: maxAge() });
  return t;
}

export async function userFromToken(token?: string) {
  if (!token) return null;
  const s = await prisma.session.findUnique({ where: { tokenHash: sha(token) }, include: { user: true } });
  if (!s || s.expiresAt < new Date()) return null;
  return { user: s.user, sessionId: s.id };
}

export async function attachUser(req: Request, _res: Response, next: NextFunction) {
  const r = await userFromToken(req.cookies?.[SESSION_COOKIE]);
  if (r) {
    req.user = r.user;
    req.sessionId = r.sessionId;
  }
  next();
}

export function requireAuth(req: Request, _res: Response, next: NextFunction) {
  if (!req.user) throw new HttpError(401, 'Not authenticated');
  next();
}

// Double-submit cookie CSRF protection for all state-changing API calls.
export function csrfGuard(req: Request, _res: Response, next: NextFunction) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const c = req.cookies?.[CSRF_COOKIE];
  const h = req.get('x-csrf-token');
  if (!c || !h || c.length !== h.length || !crypto.timingSafeEqual(Buffer.from(c), Buffer.from(h))) {
    throw new HttpError(403, 'Invalid CSRF token');
  }
  next();
}

// ---- password policy ----
const COMMON = ['password', 'password1', 'password123', '1234567890', '12345678910', 'qwertyuiop', 'iloveyou123', 'admin12345', 'welcome123', 'letmein1234', 'histoarall', 'abc1234567', 'passw0rd123'];
export function checkPassword(pw: string, ctx: { username?: string; email?: string }) {
  const lower = pw.toLowerCase();
  const local = ctx.email?.split('@')[0]?.toLowerCase();
  if (COMMON.includes(lower) || /^(.)\1+$/.test(pw) || '0123456789'.includes(pw) || 'abcdefghijklmnopqrstuvwxyz'.includes(lower)) throw new HttpError(400, 'That password is too common. Choose something harder to guess.');
  if ((ctx.username && ctx.username.length >= 3 && lower.includes(ctx.username.toLowerCase())) || (local && local.length >= 3 && lower.includes(local))) throw new HttpError(400, 'Password must not contain your username or email.');
}

// ---- login throttling (in-memory; per IP+account and per account) ----
const fails = new Map<string, { n: number; first: number; lockedUntil: number }>();
const WINDOW = 15 * 60_000;
const keysFor = (ip: string, id: string): [string, number][] => [[`ip:${ip}:${id}`, 5], [`acct:${id}`, 30]];
export function assertNotLocked(ip: string, id: string) {
  for (const [k] of keysFor(ip, id)) if ((fails.get(k)?.lockedUntil ?? 0) > Date.now()) throw new HttpError(429, 'Too many failed attempts. Try again in 15 minutes.');
}
export function recordFailure(ip: string, id: string) {
  if (fails.size > 20_000) fails.clear();
  const now = Date.now();
  for (const [k, max] of keysFor(ip, id)) {
    let f = fails.get(k);
    if (!f || now - f.first > WINDOW) f = { n: 0, first: now, lockedUntil: 0 };
    if (++f.n >= max) { f.lockedUntil = now + WINDOW; console.warn(`[security] login lockout: ${k.split(':')[0]}`); }
    fails.set(k, f);
  }
}
export const clearFailures = (ip: string, id: string) => fails.delete(`ip:${ip}:${id}`);
// Constant-ish timing for unknown users (avoids revealing which accounts exist).
let dummy: Promise<string> | undefined;
export const dummyVerify = async (pw: string) => { dummy ??= hashPassword('timing-equalisation-dummy'); await verifyPassword(await dummy, pw); };
