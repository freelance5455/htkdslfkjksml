import { prisma } from './db';
import { HttpError } from './errors';

export const PERMS = ['MANAGE_SERVER', 'MANAGE_CHANNELS', 'MANAGE_MESSAGES', 'INVITE_MEMBERS', 'KICK_MEMBERS'] as const;
export type Perm = (typeof PERMS)[number];

export async function ensurePermissions() {
  for (const key of PERMS) await prisma.permission.upsert({ where: { key }, update: {}, create: { key } });
}

export async function membership(userId: string, serverId: string) {
  const m = await prisma.serverMember.findUnique({
    where: { userId_serverId: { userId, serverId } },
    include: { role: { include: { permissions: true } }, server: { select: { ownerId: true } } },
  });
  if (!m) return null;
  const isOwner = m.server.ownerId === userId;
  const keys = new Set(m.role?.permissions.map((p) => p.key) ?? []);
  return { member: m, isOwner, has: (p: Perm) => isOwner || keys.has(p), list: () => PERMS.filter((p) => isOwner || keys.has(p)) };
}

// Non-members get 404 (not 403) so server existence is not leaked.
export async function requireMember(userId: string, serverId: string) {
  const m = await membership(userId, serverId);
  if (!m) throw new HttpError(404, 'Server not found');
  return m;
}
export async function requirePerm(userId: string, serverId: string, p: Perm) {
  const m = await requireMember(userId, serverId);
  if (!m.has(p)) throw new HttpError(403, 'You do not have permission to do that');
  return m;
}

export async function channelAccess(userId: string, channelId: string) {
  const channel = await prisma.channel.findUnique({ where: { id: channelId } });
  if (!channel) return null;
  const m = await membership(userId, channel.serverId);
  if (!m) return null;
  if (channel.isPrivate && !m.has('MANAGE_CHANNELS')) return null;
  return { channel, ...m };
}

export async function accessibleChannelIds(userId: string): Promise<string[]> {
  const mems = await prisma.serverMember.findMany({
    where: { userId },
    include: { role: { include: { permissions: true } }, server: { select: { ownerId: true } } },
  });
  const out: string[] = [];
  for (const m of mems) {
    const mod = m.server.ownerId === userId || !!m.role?.permissions.some((p) => p.key === 'MANAGE_CHANNELS');
    const chans = await prisma.channel.findMany({
      where: { serverId: m.serverId, type: 'TEXT', ...(mod ? {} : { isPrivate: false }) },
      select: { id: true },
    });
    out.push(...chans.map((c) => c.id));
  }
  return out;
}
