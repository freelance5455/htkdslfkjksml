import { describe, expect, it } from 'vitest';
import { assertNotLocked, checkPassword, hashPassword, recordFailure, verifyPassword } from './auth';
import { sniffImage } from './lib/uploads';
import { channelName, contentSchema, sendSchema, usernameSchema } from './schemas';

describe('validation', () => {
  it('trims and rejects empty / oversized messages', () => {
    expect(contentSchema.parse('  hi  ')).toBe('hi');
    expect(() => contentSchema.parse('   ')).toThrow();
    expect(() => contentSchema.parse('x'.repeat(2001))).toThrow();
  });
  it('requires uuid ids on send payloads', () => {
    expect(() => sendSchema.parse({ channelId: 'nope', content: 'a', clientId: 'x' })).toThrow();
  });
  it('validates usernames and normalises channel names', () => {
    expect(() => usernameSchema.parse('a b')).toThrow();
    expect(usernameSchema.parse('alice_1')).toBe('alice_1');
    expect(channelName.parse('Dev Talk')).toBe('dev-talk');
    expect(() => channelName.parse('bad/name')).toThrow();
  });
});

describe('uploads', () => {
  it('accepts real image signatures and rejects everything else', () => {
    const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47]), Buffer.alloc(16)]);
    expect(sniffImage(png)?.mime).toBe('image/png');
    expect(sniffImage(Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"></svg>'))).toBeNull();
    expect(sniffImage(Buffer.from('MZ' + 'x'.repeat(30)))).toBeNull();
  });
});

describe('passwords', () => {
  it('hashes with argon2id and verifies', async () => {
    const h = await hashPassword('correct horse battery');
    expect(h.startsWith('$argon2id$')).toBe(true);
    expect(await verifyPassword(h, 'correct horse battery')).toBe(true);
    expect(await verifyPassword(h, 'wrong')).toBe(false);
  });
});

describe('password policy & throttling', () => {
  it('rejects weak passwords', () => {
    expect(() => checkPassword('password123', {})).toThrow();
    expect(() => checkPassword('aaaaaaaaaaaa', {})).toThrow();
    expect(() => checkPassword('alice-rocks-2024', { username: 'alice' })).toThrow();
    expect(() => checkPassword('Tr1cky-horse-staple', { username: 'alice' })).not.toThrow();
  });
  it('locks an IP+account pair after 5 failures', () => {
    for (let i = 0; i < 5; i++) recordFailure('1.2.3.4', 'victim');
    expect(() => assertNotLocked('1.2.3.4', 'victim')).toThrow();
    expect(() => assertNotLocked('9.9.9.9', 'victim')).not.toThrow(); // a different IP can't be locked out by an attacker
  });
});
