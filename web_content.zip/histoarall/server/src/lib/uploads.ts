import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import multer from 'multer';
import { prisma } from '../db';
import { env } from '../env';
import { HttpError } from '../errors';

export const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 2 * 1024 * 1024, files: 1 } });

// Validate by magic bytes, never by client-provided mimetype/extension.
export function sniffImage(b: Buffer): { ext: string; mime: string } | null {
  if (b.length < 12) return null;
  if (b[0] === 0x89 && b.toString('ascii', 1, 4) === 'PNG') return { ext: 'png', mime: 'image/png' };
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return { ext: 'jpg', mime: 'image/jpeg' };
  if (b.toString('ascii', 0, 4) === 'RIFF' && b.toString('ascii', 8, 12) === 'WEBP') return { ext: 'webp', mime: 'image/webp' };
  if (['GIF87a', 'GIF89a'].includes(b.toString('ascii', 0, 6))) return { ext: 'gif', mime: 'image/gif' };
  return null;
}

export async function saveImage(file: Express.Multer.File | undefined, uploaderId: string, sub: 'avatars' | 'icons') {
  if (!file) throw new HttpError(400, 'No file uploaded');
  const t = sniffImage(file.buffer);
  if (!t) throw new HttpError(400, 'Only PNG, JPEG, WebP or GIF images are allowed');
  const name = `${crypto.randomUUID()}.${t.ext}`;
  const dir = path.resolve(env.UPLOAD_DIR, sub);
  await fs.mkdir(dir, { recursive: true });
  await fs.writeFile(path.join(dir, name), file.buffer);
  const url = `/uploads/${sub}/${name}`;
  await prisma.attachment.create({ data: { uploaderId, url, mime: t.mime, size: file.size } });
  return url;
}
