import { publicUser, USER_SELECT } from '../realtime';

export const messageInclude = { author: { select: USER_SELECT }, reactions: true } as const;

export function fmtMessage(m: any) {
  const map = new Map<string, string[]>();
  for (const r of m.reactions ?? []) map.set(r.emoji, [...(map.get(r.emoji) ?? []), r.userId]);
  return {
    id: m.id, channelId: m.channelId, content: m.content, createdAt: m.createdAt, editedAt: m.editedAt, clientId: m.clientId,
    author: m.author ? publicUser(m.author) : null,
    reactions: [...map].map(([emoji, userIds]) => ({ emoji, userIds })),
  };
}

export const fmtDM = (m: any) => ({
  id: m.id, conversationId: m.conversationId, content: m.content, createdAt: m.createdAt, editedAt: m.editedAt,
  clientId: m.clientId, author: m.author ? publicUser(m.author) : null,
});
