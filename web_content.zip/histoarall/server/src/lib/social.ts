import { prisma } from '../db';

export const blockedBetween = (a: string, b: string) =>
  prisma.friendship.findFirst({
    where: { status: 'BLOCKED', OR: [{ requesterId: a, addresseeId: b }, { requesterId: b, addresseeId: a }] },
  });

export async function blockerIds(userId: string): Promise<string[]> {
  const rows = await prisma.friendship.findMany({ where: { status: 'BLOCKED', addresseeId: userId }, select: { requesterId: true } });
  return rows.map((r) => r.requesterId);
}
