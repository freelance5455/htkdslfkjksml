import http from 'node:http';
import { createApp } from './app';
import { prisma } from './db';
import { env } from './env';
import { initSocket } from './socket';

const server = http.createServer(createApp());
initSocket(server);

// Purge expired sessions hourly.
setInterval(() => prisma.session.deleteMany({ where: { expiresAt: { lt: new Date() } } }).catch(() => {}), 3_600_000).unref();

server.listen(env.PORT, () => console.log(`Histoarall API listening on :${env.PORT}`));
const stop = () => server.close(() => prisma.$disconnect().then(() => process.exit(0)));
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
process.on('unhandledRejection', (e) => console.error('[unhandledRejection]', e));
