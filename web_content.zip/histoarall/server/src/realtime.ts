import type { Server } from 'socket.io';
import { prisma } from './db';

let _io: Server | undefined;
export const setIO = (i: Server) => {
  _io = i;
};
export const io = () => _io;

// In-memory presence (single-instance only; see README limitations).
const online = new Map<string, number>();
export const markOnline = (id: string) => {
  online.set(id, (online.get(id) || 0) + 1);
  return online.get(id) === 1;
};
export const markOffline = (id: string) => {
  const n = (online.get(id) || 1) - 1;
  if (n <= 0) {
    online.delete(id);
    return true;
  }
  online.set(id, n);
  return false;
};
export const presenceOf = (u: { id: string; status: string }) =>
  online.has(u.id) && u.status !== 'INVISIBLE' ? u.status : 'OFFLINE';

export const USER_SELECT = {
  id: true, username: true, displayName: true, avatarUrl: true, bio: true, customStatus: true, createdAt: true, status: true,
} as const;

export const publicUser = (u: any) => ({
  id: u.id, username: u.username, displayName: u.displayName, avatarUrl: u.avatarUrl, bio: u.bio,
  customStatus: u.customStatus, createdAt: u.createdAt, status: presenceOf(u),
});

export async function broadcastPresence(userId: string) {
  const s = io();
  if (!s) return;
  const [user, mems, fr] = await Promise.all([
    prisma.user.findUnique({ where: { id: userId }, select: USER_SELECT }),
    prisma.serverMember.findMany({ where: { userId }, select: { serverId: true } }),
    prisma.friendship.findMany({ where: { status: 'ACCEPTED', OR: [{ requesterId: userId }, { addresseeId: userId }] } }),
  ]);
  if (!user) return;
  const rooms = [
    `user:${userId}`,
    ...mems.map((m) => `server:${m.serverId}`),
    ...fr.map((f) => `user:${f.requesterId === userId ? f.addresseeId : f.requesterId}`),
  ];
  s.to(rooms).emit('presence', { userId, status: presenceOf(user) });
}

const NOTIFY_KEY: Record<string, string> = {
  FRIEND_REQUEST: 'notifyFriend', FRIEND_ACCEPTED: 'notifyFriend', DIRECT_MESSAGE: 'notifyDM', SERVER_INVITE: 'notifyInvite',
};
export async function notify(userId: string, type: any, data: any) {
  const u = await prisma.user.findUnique({ where: { id: userId }, select: { settings: true } });
  const settings = (u?.settings as any) || {};
  if (settings[NOTIFY_KEY[type]] === false) return;
  const n = await prisma.notification.create({ data: { userId, type, data } });
  io()?.to(`user:${userId}`).emit('notification:new', n);
}

export const serverChanged = (serverId: string) => io()?.to(`server:${serverId}`).emit('server:updated', { serverId });
export const friendsChanged = (...ids: string[]) => io()?.to(ids.map((i) => `user:${i}`)).emit('friends:changed');

export async function removeFromServerRooms(userId: string, serverId: string) {
  const s = io();
  if (!s) return;
  const chans = await prisma.channel.findMany({ where: { serverId }, select: { id: true } });
  s.to(`user:${userId}`).emit('server:removed', { serverId });
  s.in(`user:${userId}`).socketsLeave([`server:${serverId}`, ...chans.map((c) => `channel:${c.id}`)]);
}

// Force-disconnect live sockets (used when sessions are revoked).
export async function dropSockets(userId: string, pred: (sessionId: string) => boolean) {
  const s = io();
  if (!s) return;
  for (const sock of await s.in(`user:${userId}`).fetchSockets()) if (pred(sock.data.sessionId)) sock.disconnect(true);
}
