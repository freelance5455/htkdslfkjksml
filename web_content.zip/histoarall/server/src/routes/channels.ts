import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../db';
import { HttpError } from '../errors';
import { requirePerm } from '../perms';
import { io, serverChanged } from '../realtime';
import { channelName, idSchema } from '../schemas';

const r = Router();
const fields = {
  topic: z.string().trim().max(200).optional(),
  categoryId: idSchema.nullable().optional(),
  isPrivate: z.boolean().optional(),
};

async function checkCategory(serverId: string, categoryId?: string | null) {
  if (!categoryId) return;
  const c = await prisma.channelCategory.findFirst({ where: { id: categoryId, serverId } });
  if (!c) throw new HttpError(400, 'Category does not belong to this server');
}

r.post('/servers/:id/channels', async (req, res) => {
  const serverId = idSchema.parse(req.params.id);
  await requirePerm(req.user!.id, serverId, 'MANAGE_CHANNELS');
  const b = z.object({ name: channelName, type: z.enum(['TEXT', 'VOICE']).optional(), ...fields }).parse(req.body);
  await checkCategory(serverId, b.categoryId);
  const position = await prisma.channel.count({ where: { serverId } });
  const ch = await prisma.channel.create({ data: { ...b, serverId, position } });
  serverChanged(serverId);
  res.status(201).json(ch);
});

r.patch('/channels/:id', async (req, res) => {
  const id = idSchema.parse(req.params.id);
  const ch = await prisma.channel.findUnique({ where: { id } });
  if (!ch) throw new HttpError(404, 'Channel not found');
  await requirePerm(req.user!.id, ch.serverId, 'MANAGE_CHANNELS');
  const b = z.object({ name: channelName.optional(), ...fields }).parse(req.body);
  await checkCategory(ch.serverId, b.categoryId);
  const updated = await prisma.channel.update({ where: { id }, data: b });
  // Eject everyone from the live room when it becomes private; clients re-join (and are re-checked) on refresh.
  if (b.isPrivate) io()?.in(`channel:${id}`).socketsLeave(`channel:${id}`);
  serverChanged(ch.serverId);
  res.json(updated);
});

r.delete('/channels/:id', async (req, res) => {
  const id = idSchema.parse(req.params.id);
  const ch = await prisma.channel.findUnique({ where: { id } });
  if (!ch) throw new HttpError(404, 'Channel not found');
  await requirePerm(req.user!.id, ch.serverId, 'MANAGE_CHANNELS');
  if (ch.type === 'TEXT' && (await prisma.channel.count({ where: { serverId: ch.serverId, type: 'TEXT' } })) <= 1) {
    throw new HttpError(400, 'A server needs at least one text channel');
  }
  io()?.in(`channel:${id}`).socketsLeave(`channel:${id}`);
  await prisma.channel.delete({ where: { id } });
  serverChanged(ch.serverId);
  res.status(204).end();
});

r.post('/servers/:id/categories', async (req, res) => {
  const serverId = idSchema.parse(req.params.id);
  await requirePerm(req.user!.id, serverId, 'MANAGE_CHANNELS');
  const { name } = z.object({ name: z.string().trim().min(1).max(40) }).parse(req.body);
  const position = await prisma.channelCategory.count({ where: { serverId } });
  const c = await prisma.channelCategory.create({ data: { serverId, name, position } });
  serverChanged(serverId);
  res.status(201).json(c);
});

r.patch('/categories/:id', async (req, res) => {
  const id = idSchema.parse(req.params.id);
  const c = await prisma.channelCategory.findUnique({ where: { id } });
  if (!c) throw new HttpError(404, 'Category not found');
  await requirePerm(req.user!.id, c.serverId, 'MANAGE_CHANNELS');
  const { name } = z.object({ name: z.string().trim().min(1).max(40) }).parse(req.body);
  res.json(await prisma.channelCategory.update({ where: { id }, data: { name } }));
  serverChanged(c.serverId);
});

r.delete('/categories/:id', async (req, res) => {
  const id = idSchema.parse(req.params.id);
  const c = await prisma.channelCategory.findUnique({ where: { id } });
  if (!c) throw new HttpError(404, 'Category not found');
  await requirePerm(req.user!.id, c.serverId, 'MANAGE_CHANNELS');
  await prisma.channelCategory.delete({ where: { id } }); // channels become uncategorised (SetNull)
  serverChanged(c.serverId);
  res.status(204).end();
});

export default r;
