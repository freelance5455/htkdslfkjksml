import { Router } from 'express';
import { z } from 'zod';
import { CSRF_COOKIE, SESSION_COOKIE, assertNotLocked, checkPassword, clearFailures, createSession, dummyVerify, ensureCsrf, hashPassword, recordFailure, verifyPassword } from '../auth';
import { prisma } from '../db';
import { HttpError } from '../errors';
import { passwordSchema, usernameSchema } from '../schemas';
import { dropSockets, publicUser } from '../realtime';

const r = Router();
export const me = (u: any) => ({ ...publicUser(u), status: u.status, email: u.email, settings: u.settings });

r.get('/csrf', (req, res) => {
  res.json({ csrfToken: ensureCsrf(req, res) });
});

r.post('/register', async (req, res) => {
  const b = z
    .object({
      email: z.string().email('Enter a valid email').max(254).transform((s) => s.toLowerCase()),
      username: usernameSchema,
      displayName: z.string().trim().min(1).max(32).optional(),
      password: passwordSchema,
    })
    .parse(req.body);
  const [e, u] = await Promise.all([
    prisma.user.findUnique({ where: { email: b.email } }),
    prisma.user.findFirst({ where: { username: { equals: b.username, mode: 'insensitive' } } }),
  ]);
  if (e) throw new HttpError(409, 'That email is already registered');
  if (u) throw new HttpError(409, 'That username is already taken');
  checkPassword(b.password, { username: b.username, email: b.email });
  const user = await prisma.user.create({
    data: { email: b.email, username: b.username, displayName: b.displayName || b.username, passwordHash: await hashPassword(b.password) },
  });
  await createSession(res, user.id, req.get('user-agent'));
  res.status(201).json(me(user));
});

r.post('/login', async (req, res) => {
  const b = z.object({ identifier: z.string().trim().min(1).max(254), password: z.string().min(1).max(128) }).parse(req.body);
  const id = b.identifier.toLowerCase();
  const ip = req.ip ?? 'unknown';
  assertNotLocked(ip, id);
  const user = await prisma.user.findFirst({ where: { OR: [{ email: id }, { username: { equals: b.identifier, mode: 'insensitive' } }] } });
  let ok = false;
  if (user) ok = await verifyPassword(user.passwordHash, b.password);
  else await dummyVerify(b.password);
  if (!user || !ok) {
    recordFailure(ip, id);
    throw new HttpError(401, 'Invalid credentials'); // identical for unknown user and wrong password
  }
  clearFailures(ip, id);
  await createSession(res, user.id, req.get('user-agent'));
  res.json(me(user));
});

r.post('/logout', async (req, res) => {
  if (req.sessionId) {
    await prisma.session.deleteMany({ where: { id: req.sessionId } });
    await dropSockets(req.user!.id, (sid) => sid === req.sessionId);
  }
  res.clearCookie(SESSION_COOKIE, { path: '/' });
  res.clearCookie(CSRF_COOKIE, { path: '/' });
  res.status(204).end();
});

r.post('/logout-all', async (req, res) => {
  if (!req.user) throw new HttpError(401, 'Not authenticated');
  await prisma.session.deleteMany({ where: { userId: req.user.id } });
  await dropSockets(req.user.id, () => true);
  res.clearCookie(SESSION_COOKIE, { path: '/' });
  res.clearCookie(CSRF_COOKIE, { path: '/' });
  res.status(204).end();
});

r.get('/me', (req, res) => {
  if (!req.user) throw new HttpError(401, 'Not authenticated');
  res.json(me(req.user));
});

// DOCUMENTED PLACEHOLDER: no email delivery is configured in Phase 01, so no reset token is issued.
r.post('/forgot', (req, res) => {
  z.object({ email: z.string().email() }).parse(req.body);
  res.status(202).json({ message: 'Password reset by email is not available yet. Contact an administrator.' });
});

export default r;
