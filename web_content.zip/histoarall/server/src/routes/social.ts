import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../db';
import { HttpError } from '../errors';
import { blockedBetween, blockerIds } from '../lib/social';
import { accessibleChannelIds } from '../perms';
import { USER_SELECT, friendsChanged, notify, publicUser } from '../realtime';
import { idSchema } from '../schemas';

const r = Router();
const userIdBody = z.object({ userId: idSchema });
const both = (a: string, b: string) => ({ OR: [{ requesterId: a, addresseeId: b }, { requesterId: b, addresseeId: a }] });

r.get('/friends', async (req, res) => {
  const uid = req.user!.id;
  const rows = await prisma.friendship.findMany({
    where: { OR: [{ requesterId: uid }, { addresseeId: uid }] },
    include: { requester: { select: USER_SELECT }, addressee: { select: USER_SELECT } },
  });
  const other = (f: any) => publicUser(f.requesterId === uid ? f.addressee : f.requester);
  res.json({
    friends: rows.filter((f) => f.status === 'ACCEPTED').map((f) => ({ friendshipId: f.id, user: other(f) })),
    incoming: rows.filter((f) => f.status === 'PENDING' && f.addresseeId === uid).map((f) => ({ friendshipId: f.id, user: other(f) })),
    outgoing: rows.filter((f) => f.status === 'PENDING' && f.requesterId === uid).map((f) => ({ friendshipId: f.id, user: other(f) })),
    blocked: rows.filter((f) => f.status === 'BLOCKED' && f.requesterId === uid).map((f) => ({ friendshipId: f.id, user: other(f) })),
  });
});

r.post('/friends/request', async (req, res) => {
  const uid = req.user!.id;
  const { userId } = userIdBody.parse(req.body);
  if (userId === uid) throw new HttpError(400, 'You cannot add yourself');
  const target = await prisma.user.findUnique({ where: { id: userId } });
  if (!target || (await blockedBetween(uid, userId))) throw new HttpError(404, 'User not found');
  if (((target.settings as any) || {}).allowFriendRequests === false) throw new HttpError(403, 'This user is not accepting friend requests');
  const existing = await prisma.friendship.findFirst({ where: both(uid, userId) });
  if (existing?.status === 'ACCEPTED') throw new HttpError(409, 'Already friends');
  if (existing?.status === 'PENDING') {
    if (existing.requesterId === uid) throw new HttpError(409, 'Request already sent');
    await prisma.friendship.update({ where: { id: existing.id }, data: { status: 'ACCEPTED' } }); // they had asked us first
    await notify(userId, 'FRIEND_ACCEPTED', { user: publicUser(req.user!) });
  } else {
    await prisma.friendship.create({ data: { requesterId: uid, addresseeId: userId } });
    await notify(userId, 'FRIEND_REQUEST', { user: publicUser(req.user!) });
  }
  friendsChanged(uid, userId);
  res.status(201).end();
});

r.post('/friends/:id/accept', async (req, res) => {
  const f = await prisma.friendship.findFirst({ where: { id: idSchema.parse(req.params.id), addresseeId: req.user!.id, status: 'PENDING' } });
  if (!f) throw new HttpError(404, 'Request not found');
  await prisma.friendship.update({ where: { id: f.id }, data: { status: 'ACCEPTED' } });
  await notify(f.requesterId, 'FRIEND_ACCEPTED', { user: publicUser(req.user!) });
  friendsChanged(f.requesterId, f.addresseeId);
  res.status(204).end();
});

r.post('/friends/:id/reject', async (req, res) => {
  const f = await prisma.friendship.findFirst({ where: { id: idSchema.parse(req.params.id), addresseeId: req.user!.id, status: 'PENDING' } });
  if (!f) throw new HttpError(404, 'Request not found');
  await prisma.friendship.delete({ where: { id: f.id } });
  friendsChanged(f.requesterId, f.addresseeId);
  res.status(204).end();
});

// Remove a friend, or cancel an outgoing request.
r.delete('/friends/:id', async (req, res) => {
  const uid = req.user!.id;
  const f = await prisma.friendship.findFirst({
    where: { id: idSchema.parse(req.params.id), status: { in: ['ACCEPTED', 'PENDING'] }, OR: [{ requesterId: uid }, { addresseeId: uid }] },
  });
  if (!f) throw new HttpError(404, 'Friendship not found');
  await prisma.friendship.delete({ where: { id: f.id } });
  friendsChanged(f.requesterId, f.addresseeId);
  res.status(204).end();
});

r.post('/blocks', async (req, res) => {
  const uid = req.user!.id;
  const { userId } = userIdBody.parse(req.body);
  if (userId === uid) throw new HttpError(400, 'You cannot block yourself');
  if (!(await prisma.user.findUnique({ where: { id: userId } }))) throw new HttpError(404, 'User not found');
  await prisma.$transaction([
    // Never delete the *other* person's BLOCKED row.
    prisma.friendship.deleteMany({ where: { status: { in: ['ACCEPTED', 'PENDING'] }, ...both(uid, userId) } }),
    prisma.friendship.upsert({
      where: { requesterId_addresseeId: { requesterId: uid, addresseeId: userId } },
      update: { status: 'BLOCKED' }, create: { requesterId: uid, addresseeId: userId, status: 'BLOCKED' },
    }),
  ]);
  friendsChanged(uid);
  res.status(204).end();
});

r.delete('/blocks/:userId', async (req, res) => {
  await prisma.friendship.deleteMany({ where: { requesterId: req.user!.id, addresseeId: idSchema.parse(req.params.userId), status: 'BLOCKED' } });
  friendsChanged(req.user!.id);
  res.status(204).end();
});

// ---- notifications ----
r.get('/notifications', async (req, res) => {
  res.json(await prisma.notification.findMany({ where: { userId: req.user!.id }, orderBy: { createdAt: 'desc' }, take: 50 }));
});
r.post('/notifications/read', async (req, res) => {
  const b = z.object({ conversationId: idSchema.optional() }).parse(req.body ?? {});
  await prisma.notification.updateMany({
    where: { userId: req.user!.id, read: false, ...(b.conversationId ? { type: 'DIRECT_MESSAGE', data: { path: ['conversationId'], equals: b.conversationId } } : {}) },
    data: { read: true },
  });
  res.status(204).end();
});

// ---- search (every result set is scoped to what the caller may see) ----
r.get('/search', async (req, res) => {
  const uid = req.user!.id;
  const q = z.string().trim().min(2).max(100).parse(req.query.q);
  const like = { contains: q, mode: 'insensitive' as const };
  const [blockers, channelIds] = await Promise.all([blockerIds(uid), accessibleChannelIds(uid)]);
  const [users, servers, channels, messages] = await Promise.all([
    prisma.user.findMany({ where: { id: { notIn: [uid, ...blockers] }, OR: [{ username: like }, { displayName: like }] }, select: USER_SELECT, take: 10 }),
    prisma.server.findMany({ where: { name: like, members: { some: { userId: uid } } }, select: { id: true, name: true, iconUrl: true }, take: 10 }),
    prisma.channel.findMany({ where: { id: { in: channelIds }, name: like }, select: { id: true, name: true, serverId: true, server: { select: { name: true } } }, take: 10 }),
    prisma.message.findMany({
      where: { channelId: { in: channelIds }, content: like }, orderBy: { createdAt: 'desc' }, take: 15,
      include: { author: { select: USER_SELECT }, channel: { select: { name: true, serverId: true } } },
    }),
  ]);
  res.json({
    users: users.map(publicUser), servers, channels,
    messages: messages.map((m) => ({ id: m.id, content: m.content.slice(0, 200), createdAt: m.createdAt, channelId: m.channelId, serverId: m.channel.serverId, channelName: m.channel.name, author: m.author ? publicUser(m.author) : null })),
  });
});

export default r;
