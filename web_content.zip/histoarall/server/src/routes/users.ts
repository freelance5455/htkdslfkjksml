import { Router } from 'express';
import { z } from 'zod';
import { checkPassword, hashPassword, verifyPassword } from '../auth';
import { prisma } from '../db';
import { HttpError } from '../errors';
import { blockerIds } from '../lib/social';
import { saveImage, upload } from '../lib/uploads';
import { USER_SELECT, broadcastPresence, dropSockets, publicUser } from '../realtime';
import { idSchema, passwordSchema } from '../schemas';
import { me } from './auth';

const r = Router();

r.get('/users/search', async (req, res) => {
  const q = z.string().trim().min(2).max(50).parse(req.query.q);
  const blockers = await blockerIds(req.user!.id);
  const users = await prisma.user.findMany({
    where: {
      id: { notIn: [req.user!.id, ...blockers] },
      OR: [{ username: { contains: q, mode: 'insensitive' } }, { displayName: { contains: q, mode: 'insensitive' } }],
    },
    select: USER_SELECT, take: 20,
  });
  res.json(users.map(publicUser));
});

r.get('/users/:id', async (req, res) => {
  const id = idSchema.parse(req.params.id);
  const u = await prisma.user.findUnique({ where: { id }, select: USER_SELECT });
  if (!u || (await blockerIds(req.user!.id)).includes(id)) throw new HttpError(404, 'User not found');
  res.json(publicUser(u));
});

r.patch('/users/me', async (req, res) => {
  const b = z
    .object({
      displayName: z.string().trim().min(1).max(32).optional(),
      bio: z.string().max(300).optional(),
      customStatus: z.string().trim().max(60).nullable().optional(),
      status: z.enum(['ONLINE', 'IDLE', 'DND', 'INVISIBLE']).optional(),
    })
    .parse(req.body);
  const u = await prisma.user.update({ where: { id: req.user!.id }, data: { ...b, customStatus: b.customStatus === undefined ? undefined : b.customStatus || null } });
  broadcastPresence(u.id);
  res.json(me(u));
});

r.post('/users/me/avatar', upload.single('file'), async (req, res) => {
  const url = await saveImage(req.file, req.user!.id, 'avatars');
  res.json(me(await prisma.user.update({ where: { id: req.user!.id }, data: { avatarUrl: url } })));
});

r.patch('/users/me/settings', async (req, res) => {
  const b = z
    .object({
      compactMode: z.boolean(), accent: z.enum(['#7775F8', '#43C9C2', '#F472B6', '#F59E0B', '#34D399']),
      notifyDM: z.boolean(), notifyFriend: z.boolean(), notifyInvite: z.boolean(), allowFriendRequests: z.boolean(),
    })
    .partial()
    .strict()
    .parse(req.body);
  const merged = { ...((req.user!.settings as object) || {}), ...b };
  res.json(me(await prisma.user.update({ where: { id: req.user!.id }, data: { settings: merged } })));
});

r.post('/users/me/password', async (req, res) => {
  const b = z.object({ current: z.string().max(128), next: passwordSchema }).parse(req.body);
  if (!(await verifyPassword(req.user!.passwordHash, b.current))) throw new HttpError(400, 'Current password is incorrect');
  checkPassword(b.next, { username: req.user!.username, email: req.user!.email });
  await prisma.user.update({ where: { id: req.user!.id }, data: { passwordHash: await hashPassword(b.next) } });
  // Sign out all other sessions.
  await prisma.session.deleteMany({ where: { userId: req.user!.id, NOT: { id: req.sessionId } } });
  await dropSockets(req.user!.id, (sid) => sid !== req.sessionId);
  res.status(204).end();
});

export default r;
