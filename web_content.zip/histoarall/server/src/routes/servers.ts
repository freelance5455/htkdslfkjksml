import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../db';
import { HttpError } from '../errors';
import { blockedBetween } from '../lib/social';
import { saveImage, upload } from '../lib/uploads';
import { requireMember, requirePerm } from '../perms';
import { USER_SELECT, io, notify, publicUser, removeFromServerRooms, serverChanged } from '../realtime';
import { idSchema } from '../schemas';
import { addMember, createServerWithDefaults } from '../services';

const r = Router();
const nameSchema = z.string().trim().min(2, 'Name must be at least 2 characters').max(60);
const SERVER_LITE = { id: true, name: true, iconUrl: true, ownerId: true, isPublic: true } as const;

r.get('/servers', async (req, res) => {
  const ms = await prisma.serverMember.findMany({
    where: { userId: req.user!.id }, include: { server: { select: SERVER_LITE } }, orderBy: { joinedAt: 'asc' },
  });
  res.json(ms.map((m) => m.server));
});

r.get('/servers/explore', async (req, res) => {
  const servers = await prisma.server.findMany({
    where: { isPublic: true, members: { none: { userId: req.user!.id } } },
    select: { ...SERVER_LITE, _count: { select: { members: true } } }, take: 30,
  });
  res.json(servers);
});

r.post('/servers', async (req, res) => {
  const b = z.object({ name: nameSchema, isPublic: z.boolean().default(false) }).parse(req.body);
  const s = await createServerWithDefaults(req.user!.id, b.name, b.isPublic);
  io()?.in(`user:${req.user!.id}`).socketsJoin(`server:${s.id}`);
  res.status(201).json(s);
});

r.get('/servers/:id', async (req, res) => {
  const id = idSchema.parse(req.params.id);
  const m = await requireMember(req.user!.id, id);
  const s = await prisma.server.findUniqueOrThrow({
    where: { id },
    include: {
      categories: { orderBy: { position: 'asc' } },
      channels: { orderBy: { position: 'asc' } },
      members: { include: { user: { select: USER_SELECT }, role: true } },
    },
  });
  res.json({
    id: s.id, name: s.name, iconUrl: s.iconUrl, ownerId: s.ownerId, isPublic: s.isPublic,
    categories: s.categories,
    channels: s.channels.filter((c) => !c.isPrivate || m.has('MANAGE_CHANNELS')),
    members: s.members.map((x) => ({ ...publicUser(x.user), role: x.role?.name ?? null, roleColor: x.role?.color ?? null, isOwner: x.userId === s.ownerId })),
    me: { isOwner: m.isOwner, perms: m.list() },
  });
});

r.patch('/servers/:id', async (req, res) => {
  const id = idSchema.parse(req.params.id);
  await requirePerm(req.user!.id, id, 'MANAGE_SERVER');
  const b = z.object({ name: nameSchema.optional(), isPublic: z.boolean().optional() }).parse(req.body);
  const s = await prisma.server.update({ where: { id }, data: b, select: SERVER_LITE });
  serverChanged(id);
  res.json(s);
});

r.post('/servers/:id/icon', upload.single('file'), async (req, res) => {
  const id = idSchema.parse(req.params.id);
  await requirePerm(req.user!.id, id, 'MANAGE_SERVER');
  const url = await saveImage(req.file, req.user!.id, 'icons');
  const s = await prisma.server.update({ where: { id }, data: { iconUrl: url }, select: SERVER_LITE });
  serverChanged(id);
  res.json(s);
});

r.post('/servers/:id/join', async (req, res) => {
  const id = idSchema.parse(req.params.id);
  const s = await prisma.server.findUnique({ where: { id } });
  if (!s || !s.isPublic) throw new HttpError(404, 'Server not found'); // private servers are join-by-invite only
  await addMember(req.user!.id, id);
  io()?.in(`user:${req.user!.id}`).socketsJoin(`server:${id}`);
  res.status(204).end();
});

r.post('/servers/:id/leave', async (req, res) => {
  const id = idSchema.parse(req.params.id);
  const m = await requireMember(req.user!.id, id);
  if (m.isOwner) throw new HttpError(400, 'Owners cannot leave. Delete the server or transfer ownership first.');
  await prisma.serverMember.delete({ where: { userId_serverId: { userId: req.user!.id, serverId: id } } });
  await removeFromServerRooms(req.user!.id, id);
  serverChanged(id);
  res.status(204).end();
});

r.delete('/servers/:id', async (req, res) => {
  const id = idSchema.parse(req.params.id);
  const s = await prisma.server.findUnique({ where: { id }, include: { channels: { select: { id: true } } } });
  if (!s || s.ownerId !== req.user!.id) throw new HttpError(s ? 403 : 404, s ? 'Only the owner can delete this server' : 'Server not found');
  const room = `server:${id}`;
  io()?.to(room).emit('server:removed', { serverId: id });
  io()?.in(room).socketsLeave([room, ...s.channels.map((c) => `channel:${c.id}`)]);
  await prisma.server.delete({ where: { id } });
  res.status(204).end();
});

// ---- members ----
r.delete('/servers/:id/members/:userId', async (req, res) => {
  const id = idSchema.parse(req.params.id);
  const target = idSchema.parse(req.params.userId);
  await requirePerm(req.user!.id, id, 'KICK_MEMBERS');
  const s = await prisma.server.findUniqueOrThrow({ where: { id } });
  if (target === s.ownerId || target === req.user!.id) throw new HttpError(400, 'You cannot remove that member');
  await prisma.serverMember.delete({ where: { userId_serverId: { userId: target, serverId: id } } }).catch(() => {
    throw new HttpError(404, 'Member not found');
  });
  await removeFromServerRooms(target, id);
  serverChanged(id);
  res.status(204).end();
});

r.patch('/servers/:id/members/:userId', async (req, res) => {
  const id = idSchema.parse(req.params.id);
  const target = idSchema.parse(req.params.userId);
  const m = await requireMember(req.user!.id, id);
  if (!m.isOwner) throw new HttpError(403, 'Only the owner can change roles');
  const { role } = z.object({ role: z.enum(['Admin', 'Member']) }).parse(req.body);
  const roleRow = await prisma.role.findUniqueOrThrow({ where: { serverId_name: { serverId: id, name: role } } });
  await prisma.serverMember.update({ where: { userId_serverId: { userId: target, serverId: id } }, data: { roleId: roleRow.id } });
  serverChanged(id);
  res.status(204).end();
});

// ---- invitations ----
r.post('/servers/:id/invites', async (req, res) => {
  const id = idSchema.parse(req.params.id);
  const uid = req.user!.id;
  await requirePerm(uid, id, 'INVITE_MEMBERS');
  const { userId } = z.object({ userId: idSchema }).parse(req.body);
  const [target, server] = await Promise.all([prisma.user.findUnique({ where: { id: userId } }), prisma.server.findUniqueOrThrow({ where: { id } })]);
  if (!target || (await blockedBetween(uid, userId))) throw new HttpError(404, 'User not found');
  if (await prisma.serverMember.findUnique({ where: { userId_serverId: { userId, serverId: id } } })) throw new HttpError(409, 'Already a member');
  const existing = await prisma.serverInvitation.findUnique({ where: { serverId_inviteeId: { serverId: id, inviteeId: userId } } });
  if (existing?.status === 'PENDING') throw new HttpError(409, 'Invitation already sent');
  const inv = existing
    ? await prisma.serverInvitation.update({ where: { id: existing.id }, data: { status: 'PENDING', inviterId: uid } })
    : await prisma.serverInvitation.create({ data: { serverId: id, inviterId: uid, inviteeId: userId } });
  await notify(userId, 'SERVER_INVITE', { inviteId: inv.id, serverId: id, serverName: server.name, from: req.user!.displayName });
  io()?.to(`user:${userId}`).emit('invites:changed');
  res.status(201).json({ id: inv.id });
});

r.get('/invites', async (req, res) => {
  const rows = await prisma.serverInvitation.findMany({
    where: { inviteeId: req.user!.id, status: 'PENDING' },
    include: { server: { select: SERVER_LITE }, inviter: { select: USER_SELECT } }, orderBy: { createdAt: 'desc' },
  });
  res.json(rows.map((i) => ({ id: i.id, server: i.server, inviter: publicUser(i.inviter), createdAt: i.createdAt })));
});

async function respond(req: any, res: any, accept: boolean) {
  const id = idSchema.parse(req.params.id);
  const inv = await prisma.serverInvitation.findFirst({ where: { id, inviteeId: req.user.id, status: 'PENDING' } });
  if (!inv) throw new HttpError(404, 'Invitation not found');
  await prisma.serverInvitation.update({ where: { id }, data: { status: accept ? 'ACCEPTED' : 'DECLINED' } });
  if (accept) {
    await addMember(req.user.id, inv.serverId);
    io()?.in(`user:${req.user.id}`).socketsJoin(`server:${inv.serverId}`);
  }
  res.status(204).end();
}
r.post('/invites/:id/accept', (req, res) => respond(req, res, true));
r.post('/invites/:id/decline', (req, res) => respond(req, res, false));

export default r;
