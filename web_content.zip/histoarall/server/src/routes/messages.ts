import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../db';
import { HttpError } from '../errors';
import { fmtDM, fmtMessage, messageInclude } from '../lib/messages';
import { channelAccess } from '../perms';
import { USER_SELECT, io, publicUser } from '../realtime';
import { blockedBetween } from '../lib/social';
import { contentSchema, idSchema } from '../schemas';

const r = Router();
const page = z.object({ before: z.string().datetime().optional(), limit: z.coerce.number().int().min(1).max(100).default(50) });

r.get('/channels/:id/messages', async (req, res) => {
  const id = idSchema.parse(req.params.id);
  if (!(await channelAccess(req.user!.id, id))) throw new HttpError(404, 'Channel not found');
  const q = page.parse(req.query);
  const rows = await prisma.message.findMany({
    where: { channelId: id, ...(q.before ? { createdAt: { lt: new Date(q.before) } } : {}) },
    orderBy: { createdAt: 'desc' }, take: q.limit + 1, include: messageInclude,
  });
  res.json({ messages: rows.slice(0, q.limit).reverse().map(fmtMessage), hasMore: rows.length > q.limit });
});

r.patch('/messages/:id', async (req, res) => {
  const id = idSchema.parse(req.params.id);
  const content = contentSchema.parse(req.body?.content);
  const m = await prisma.message.findUnique({ where: { id } });
  if (!m || m.authorId !== req.user!.id) throw new HttpError(404, 'Message not found'); // only the author may edit
  if (!(await channelAccess(req.user!.id, m.channelId))) throw new HttpError(404, 'Message not found');
  const u = await prisma.message.update({ where: { id }, data: { content, editedAt: new Date() }, include: messageInclude });
  const out = fmtMessage(u);
  io()?.to(`channel:${m.channelId}`).emit('message:updated', out);
  res.json(out);
});

r.delete('/messages/:id', async (req, res) => {
  const id = idSchema.parse(req.params.id);
  const m = await prisma.message.findUnique({ where: { id } });
  if (!m) throw new HttpError(404, 'Message not found');
  const acc = await channelAccess(req.user!.id, m.channelId);
  if (!acc) throw new HttpError(404, 'Message not found');
  if (m.authorId !== req.user!.id && !acc.has('MANAGE_MESSAGES')) throw new HttpError(403, 'You cannot delete this message');
  await prisma.message.delete({ where: { id } });
  io()?.to(`channel:${m.channelId}`).emit('message:deleted', { id, channelId: m.channelId });
  res.status(204).end();
});

// ---- direct messages (history only; sending is over the socket) ----
r.get('/dms', async (req, res) => {
  const uid = req.user!.id;
  const convs = await prisma.directConversation.findMany({
    where: { members: { some: { userId: uid } } },
    include: { members: { include: { user: { select: USER_SELECT } } }, messages: { orderBy: { createdAt: 'desc' }, take: 1 } },
  });
  const out = convs
    .map((c) => ({
      id: c.id,
      user: publicUser(c.members.find((m) => m.userId !== uid)!.user),
      lastMessage: c.messages[0] ? { content: c.messages[0].content, createdAt: c.messages[0].createdAt } : null,
      sort: (c.messages[0]?.createdAt ?? c.createdAt).getTime(),
    }))
    .sort((a, b) => b.sort - a.sort);
  res.json(out);
});

r.post('/dms', async (req, res) => {
  const uid = req.user!.id;
  const { userId } = z.object({ userId: idSchema }).parse(req.body);
  if (userId === uid) throw new HttpError(400, 'You cannot message yourself');
  const target = await prisma.user.findUnique({ where: { id: userId } });
  if (!target || (await blockedBetween(uid, userId))) throw new HttpError(404, 'User not found');
  const related =
    (await prisma.friendship.findFirst({ where: { status: 'ACCEPTED', OR: [{ requesterId: uid, addresseeId: userId }, { requesterId: userId, addresseeId: uid }] } })) ||
    (await prisma.serverMember.findFirst({ where: { userId, server: { members: { some: { userId: uid } } } } }));
  if (!related) throw new HttpError(403, 'You can only message friends or people who share a server with you');
  let conv = await prisma.directConversation.findFirst({
    where: { AND: [{ members: { some: { userId: uid } } }, { members: { some: { userId } } }] },
  });
  if (!conv) conv = await prisma.directConversation.create({ data: { members: { create: [{ userId: uid }, { userId }] } } });
  res.json({ id: conv.id });
});

r.get('/dms/:id/messages', async (req, res) => {
  const id = idSchema.parse(req.params.id);
  const ok = await prisma.directConversationMember.findUnique({ where: { conversationId_userId: { conversationId: id, userId: req.user!.id } } });
  if (!ok) throw new HttpError(404, 'Conversation not found');
  const q = page.parse(req.query);
  const rows = await prisma.directMessage.findMany({
    where: { conversationId: id, ...(q.before ? { createdAt: { lt: new Date(q.before) } } : {}) },
    orderBy: { createdAt: 'desc' }, take: q.limit + 1, include: { author: { select: USER_SELECT } },
  });
  res.json({ messages: rows.slice(0, q.limit).reverse().map(fmtDM), hasMore: rows.length > q.limit });
});

export default r;
