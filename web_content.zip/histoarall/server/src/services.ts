import { prisma } from './db';
import { ensurePermissions, PERMS } from './perms';
import { io, serverChanged } from './realtime';

export async function createServerWithDefaults(ownerId: string, name: string, isPublic = false) {
  await ensurePermissions();
  return prisma.$transaction(async (tx) => {
    const server = await tx.server.create({ data: { name, ownerId, isPublic } });
    const admin = await tx.role.create({
      data: { serverId: server.id, name: 'Admin', color: '#7775F8', permissions: { connect: PERMS.map((key) => ({ key })) } },
    });
    await tx.role.create({
      data: { serverId: server.id, name: 'Member', color: '#A1A6B5', isDefault: true, permissions: { connect: [{ key: 'INVITE_MEMBERS' }] } },
    });
    await tx.serverMember.create({ data: { userId: ownerId, serverId: server.id, roleId: admin.id } });
    const cat = await tx.channelCategory.create({ data: { serverId: server.id, name: 'Text Channels', position: 0 } });
    await tx.channel.create({ data: { serverId: server.id, categoryId: cat.id, name: 'general', topic: 'Welcome to your new server!', position: 0 } });
    return server;
  });
}

export async function addMember(userId: string, serverId: string) {
  const exists = await prisma.serverMember.findUnique({ where: { userId_serverId: { userId, serverId } } });
  if (exists) return;
  const role = await prisma.role.findFirst({ where: { serverId, isDefault: true } });
  await prisma.serverMember.create({ data: { userId, serverId, roleId: role?.id } });
  io()?.in(`user:${userId}`).socketsJoin(`server:${serverId}`);
  serverChanged(serverId);
}
