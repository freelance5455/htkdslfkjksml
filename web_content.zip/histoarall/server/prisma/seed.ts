import { PrismaClient } from '@prisma/client';
import { hashPassword } from '../src/auth';
import { ensurePermissions } from '../src/perms';
import { createServerWithDefaults } from '../src/services';

const prisma = new PrismaClient();
export const DEMO_PASSWORD = 'DemoPass123!'; // development-only credential

async function main() {
  if (process.env.NODE_ENV === 'production') throw new Error('Refusing to seed demo accounts with a known password in production.');
  if (await prisma.user.findUnique({ where: { username: 'alice' } })) return console.log('Already seeded.');
  await ensurePermissions();
  const passwordHash = await hashPassword(DEMO_PASSWORD);
  const mk = (username: string, displayName: string, bio: string, customStatus?: string) =>
    prisma.user.create({ data: { email: `${username}@histoarall.test`, username, displayName, passwordHash, bio, customStatus } });
  const [alice, bob, carol, dave, erin] = await Promise.all([
    mk('alice', 'Alice Demo', 'Community founder. Coffee-powered.', 'Building things'),
    mk('bob', 'Bob Demo', 'Frontend tinkerer.'),
    mk('carol', 'Carol Demo', 'Designer and gamer.', 'Away from keyboard'),
    mk('dave', 'Dave Demo', 'Backend and bikes.'),
    mk('erin', 'Erin Demo', 'Just exploring.'),
  ]);

  const hq = await createServerWithDefaults(alice.id, 'Histoarall HQ', true);
  const member = await prisma.role.findFirstOrThrow({ where: { serverId: hq.id, name: 'Member' } });
  const admin = await prisma.role.findFirstOrThrow({ where: { serverId: hq.id, name: 'Admin' } });
  await prisma.serverMember.createMany({
    data: [
      { userId: bob.id, serverId: hq.id, roleId: admin.id },
      { userId: carol.id, serverId: hq.id, roleId: member.id },
      { userId: dave.id, serverId: hq.id, roleId: member.id },
    ],
  });
  const text = await prisma.channelCategory.findFirstOrThrow({ where: { serverId: hq.id } });
  const general = await prisma.channel.findFirstOrThrow({ where: { serverId: hq.id, name: 'general' } });
  const voiceCat = await prisma.channelCategory.create({ data: { serverId: hq.id, name: 'Voice Channels', position: 1 } });
  const mkCh = (name: string, topic: string, position: number, extra: object = {}) =>
    prisma.channel.create({ data: { serverId: hq.id, categoryId: text.id, name, topic, position, ...extra } });
  const [announcements, , dev] = await Promise.all([
    mkCh('announcements', 'Official news', 1),
    mkCh('random', 'Anything goes', 2),
    mkCh('dev-talk', 'Code, bugs and coffee', 3),
    mkCh('staff-only', 'Private: admins only', 4, { isPrivate: true }),
    prisma.channel.create({ data: { serverId: hq.id, categoryId: voiceCat.id, name: 'Lounge', type: 'VOICE', position: 5 } }),
    prisma.channel.create({ data: { serverId: hq.id, categoryId: voiceCat.id, name: 'Game Night', type: 'VOICE', position: 6 } }),
  ]);
  await prisma.channel.update({ where: { id: general.id }, data: { topic: 'Say hello and meet the community 👋' } });

  const t0 = Date.now() - 3_600_000;
  const msgs: [string, typeof alice, string][] = [
    [general.id, alice, 'Welcome to Histoarall HQ! This is the demo community.'],
    [general.id, bob, 'Hey everyone 👋 Real-time messages are working.'],
    [general.id, carol, 'Love the dark theme.'],
    [general.id, dave, 'Try editing or deleting your own messages with the hover menu.'],
    [announcements.id, alice, 'Phase 01 MVP is live. Voice channels are placeholders for now.'],
    [dev.id, bob, 'Anyone tried the Prisma migrations yet?'],
    [dev.id, dave, 'Yes, `npm run migrate -w server` and you are set.'],
  ];
  let i = 0;
  for (const [channelId, a, content] of msgs)
    await prisma.message.create({ data: { channelId, authorId: a.id, content, createdAt: new Date(t0 + i++ * 240_000), clientId: crypto.randomUUID() } });

  await prisma.friendship.createMany({
    data: [
      { requesterId: alice.id, addresseeId: bob.id, status: 'ACCEPTED' },
      { requesterId: dave.id, addresseeId: alice.id, status: 'ACCEPTED' },
      { requesterId: carol.id, addresseeId: alice.id, status: 'PENDING' },
    ],
  });
  const conv = await prisma.directConversation.create({ data: { members: { create: [{ userId: alice.id }, { userId: bob.id }] } } });
  await prisma.directMessage.createMany({
    data: [
      { conversationId: conv.id, authorId: bob.id, content: 'Hey Alice, the demo is ready!', clientId: crypto.randomUUID() },
      { conversationId: conv.id, authorId: alice.id, content: 'Great, thanks Bob 🎉', clientId: crypto.randomUUID() },
    ],
  });
  await prisma.notification.create({ data: { userId: alice.id, type: 'FRIEND_REQUEST', data: { user: { displayName: carol.displayName, username: carol.username, id: carol.id } } } });
  console.log(`Seeded. Demo accounts: alice, bob, carol, dave, erin (@histoarall.test) — password: ${DEMO_PASSWORD}`);
  void erin;
}
main().finally(() => prisma.$disconnect());
