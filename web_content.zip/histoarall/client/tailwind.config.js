export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: '#111318', bg2: '#181B23', panel: '#202430', line: '#303545', txt: '#F5F6FA', mute: '#A1A6B5',
        accent: 'rgb(var(--accent) / <alpha-value>)', accent2: '#43C9C2',
      },
      fontFamily: { sans: ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'] },
      keyframes: { pop: { '0%': { opacity: '0', transform: 'scale(.96) translateY(4px)' }, '100%': { opacity: '1', transform: 'none' } } },
      animation: { pop: 'pop .16s ease-out' },
    },
  },
  plugins: [],
};
