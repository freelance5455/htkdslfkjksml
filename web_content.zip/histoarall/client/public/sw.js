self.addEventListener('fetch', () => {}); // minimal worker so the app is installable; no offline caching
