import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

// All API / socket / upload traffic is proxied so the browser sees a single origin (first-party cookies, no CORS).
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': 'http://localhost:4000',
      '/uploads': 'http://localhost:4000',
      '/socket.io': { target: 'http://localhost:4000', ws: true },
    },
  },
});
