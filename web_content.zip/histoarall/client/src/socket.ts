import { io, type Socket } from 'socket.io-client';
import { api } from './api';
import { useStore } from './store';

let socket: Socket | null = null;
export const getSocket = () => socket;

export function connectSocket() {
  if (socket) return;
  socket = io({ withCredentials: true, transports: ['websocket', 'polling'] });
  const s = () => useStore.getState();
  let first = true;
  socket.on('connect', () => {
    if (first) first = false;
    else s().resync(); // reconnect: re-join the open channel and pull anything we missed
  });
  // Session revoked / expired server-side: fall back to the login screen.
  socket.on('connect_error', (e) => { if (e.message === 'unauthorized') useStore.setState({ me: null }); });
  socket.on('disconnect', (reason) => { if (reason === 'io server disconnect') api('GET', '/auth/me').catch(() => useStore.setState({ me: null })); });
  socket.on('message:new', (m) => s().receiveMessage('channel:' + m.channelId, m));
  socket.on('message:updated', (m) => s().receiveMessage('channel:' + m.channelId, m));
  socket.on('message:deleted', ({ id, channelId }) => s().removeMessage('channel:' + channelId, id));
  socket.on('reaction:update', ({ messageId, channelId, reactions }) => s().patchMessage('channel:' + channelId, messageId, { reactions }));
  socket.on('dm:new', (m) => { s().receiveMessage('dm:' + m.conversationId, m); s().loadDMs(); });
  socket.on('presence', ({ userId, status }) => s().setPresence(userId, status));
  socket.on('server:updated', ({ serverId }) => s().loadServer(serverId));
  socket.on('server:removed', ({ serverId }) => s().serverGone(serverId));
  socket.on('friends:changed', () => s().loadFriends());
  socket.on('invites:changed', () => s().loadInvites());
  socket.on('notification:new', (n) => {
    s().pushNotification(n);
    if (n.type === 'SERVER_INVITE') s().loadInvites();
    if (n.type === 'DIRECT_MESSAGE') return;
    s().toast('info', notifText(n));
  });
}
export function disconnectSocket() { socket?.disconnect(); socket = null; }
export const notifText = (n: { type: string; data: any }) =>
  n.type === 'FRIEND_REQUEST' ? `${n.data.user?.displayName ?? 'Someone'} sent you a friend request`
  : n.type === 'FRIEND_ACCEPTED' ? `${n.data.user?.displayName ?? 'Someone'} accepted your friend request`
  : n.type === 'SERVER_INVITE' ? `${n.data.from} invited you to ${n.data.serverName}`
  : `New message from ${n.data.from ?? 'someone'}`;
