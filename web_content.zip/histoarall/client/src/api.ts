let csrf = '';
export class ApiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}
async function token(force = false) {
  if (!csrf || force) csrf = (await (await fetch('/api/auth/csrf', { credentials: 'same-origin' })).json()).csrfToken;
  return csrf;
}
export async function api<T = any>(method: string, path: string, body?: unknown, retry = true): Promise<T> {
  const headers: Record<string, string> = {};
  const init: RequestInit = { method, credentials: 'same-origin', headers };
  if (method !== 'GET') headers['x-csrf-token'] = await token();
  if (body instanceof FormData) init.body = body;
  else if (body !== undefined) { headers['content-type'] = 'application/json'; init.body = JSON.stringify(body); }
  const res = await fetch('/api' + path, init);
  const data = res.status === 204 ? null : await res.json().catch(() => null);
  if (res.status === 403 && retry && data?.error === 'Invalid CSRF token') { await token(true); return api(method, path, body, false); }
  if (!res.ok) throw new ApiError(res.status, data?.error || 'Request failed');
  return data as T;
}
export const errMsg = (e: unknown) => (e instanceof Error ? e.message : 'Something went wrong');
