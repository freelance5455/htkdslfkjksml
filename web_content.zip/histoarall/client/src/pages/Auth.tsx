import { useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api, errMsg } from '../api';
import { ErrorText, Logo } from '../components/ui';
import { useStore } from '../store';

export default function Auth({ mode }: { mode: 'login' | 'register' }) {
  const auth = useStore((s) => s.auth);
  const nav = useNavigate();
  const [f, setF] = useState({ identifier: '', email: '', username: '', password: '' });
  const [err, setErr] = useState('');
  const [info, setInfo] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true); setErr('');
    try {
      await auth(mode, mode === 'login' ? { identifier: f.identifier, password: f.password } : { email: f.email, username: f.username, password: f.password });
      nav('/', { replace: true });
    } catch (x) { setErr(errMsg(x)); } finally { setBusy(false); }
  };
  const forgot = async () => {
    const email = prompt('Enter your account email');
    if (!email) return;
    try { setInfo((await api<{ message: string }>('POST', '/auth/forgot', { email })).message); } catch (x) { setErr(errMsg(x)); }
  };
  return (
    <main className="grid min-h-dvh place-items-center bg-[radial-gradient(ellipse_at_top,rgb(var(--accent)/0.18),transparent_60%)] p-4">
      <form onSubmit={submit} className="animate-pop w-full max-w-sm rounded-2xl border border-line bg-bg2 p-7 shadow-2xl">
        <div className="mb-6 flex flex-col items-center gap-3 text-center"><Logo size={56} /><h1 className="text-2xl font-bold">{mode === 'login' ? 'Welcome back' : 'Create your account'}</h1><p className="text-sm text-mute">{mode === 'login' ? 'Log in to continue to Histoarall.' : 'Join Histoarall and start talking.'}</p></div>
        <div className="space-y-4">
          {mode === 'login' ? (
            <div><label htmlFor="id" className="label">Email or username</label><input id="id" className="input" autoComplete="username" required autoFocus value={f.identifier} onChange={set('identifier')} /></div>
          ) : (
            <>
              <div><label htmlFor="em" className="label">Email</label><input id="em" type="email" className="input" autoComplete="email" required autoFocus value={f.email} onChange={set('email')} /></div>
              <div><label htmlFor="un" className="label">Username</label><input id="un" className="input" autoComplete="username" required minLength={3} maxLength={32} pattern="[a-zA-Z0-9_.]+" title="Letters, numbers, _ and ." value={f.username} onChange={set('username')} /></div>
            </>
          )}
          <div><label htmlFor="pw" className="label">Password</label><input id="pw" type="password" className="input" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} required minLength={mode === 'register' ? 10 : 1} value={f.password} onChange={set('password')} /></div>
          <ErrorText>{err}</ErrorText>
          {info && <p className="rounded-lg bg-panel px-3 py-2 text-sm">{info}</p>}
          <button className="btn-primary w-full" disabled={busy}>{busy ? 'Please wait…' : mode === 'login' ? 'Log in' : 'Create account'}</button>
        </div>
        <div className="mt-5 flex justify-between text-sm text-mute">
          {mode === 'login' ? <><Link className="text-accent hover:underline" to="/register">Create an account</Link><button type="button" className="hover:underline" onClick={forgot}>Forgot password?</button></> : <Link className="text-accent hover:underline" to="/login">Already have an account?</Link>}
        </div>
        {mode === 'login' && <p className="mt-5 rounded-lg bg-bg p-3 text-xs text-mute">Demo (after <code>npm run seed</code>): <b>alice</b> / <b>DemoPass123!</b></p>}
      </form>
    </main>
  );
}
