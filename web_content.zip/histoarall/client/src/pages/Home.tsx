import { Check, MessageSquare, Menu, UserMinus, UserPlus, X } from 'lucide-react';
import { useEffect, useState, type ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, errMsg } from '../api';
import { Avatar, Empty } from '../components/ui';
import { useStore } from '../store';
import type { FriendRow, User } from '../types';

export default function Home() {
  const st = useStore();
  const { friends, invites, homeTab: tab, setHomeTab, toast, loadFriends, loadInvites, loadServers, loadDMs, openModal } = st;
  const nav = useNavigate();
  const [q, setQ] = useState('');
  const [res, setRes] = useState<User[]>([]);
  useEffect(() => {
    if (tab !== 'add' || q.trim().length < 2) return setRes([]);
    const t = setTimeout(() => api<User[]>('GET', `/users/search?q=${encodeURIComponent(q.trim())}`).then(setRes).catch(() => setRes([])), 250);
    return () => clearTimeout(t);
  }, [q, tab]);

  const act = async (fn: () => Promise<unknown>, ok?: string) => { try { await fn(); await loadFriends(); if (ok) toast('success', ok); } catch (e) { toast('error', errMsg(e)); } };
  const dm = (u: User) => act(async () => { const c = await api<{ id: string }>('POST', '/dms', { userId: u.id }); await loadDMs(); nav(`/dm/${c.id}`); });
  const Row = ({ u, children }: { u: User; children: ReactNode }) => (
    <li className="flex items-center gap-3 rounded-xl px-3 py-2.5 hover:bg-panel/60">
      <button onClick={() => openModal({ type: 'profile', userId: u.id })} className="flex min-w-0 flex-1 items-center gap-3 text-left"><Avatar user={u} size={38} dot /><span className="min-w-0"><span className="block truncate font-medium">{u.displayName}</span><span className="block truncate text-xs text-mute">@{u.username}{u.customStatus ? ` · ${u.customStatus}` : ''}</span></span></button>
      <div className="flex gap-1">{children}</div>
    </li>
  );
  const fr = (r: FriendRow) => (
    <Row key={r.friendshipId} u={r.user}>
      <button className="icon-btn" aria-label={`Message ${r.user.displayName}`} onClick={() => dm(r.user)}><MessageSquare size={17} /></button>
      <button className="icon-btn hover:text-rose-400" aria-label={`Remove ${r.user.displayName}`} onClick={() => st.confirm({ title: `Remove ${r.user.displayName}?`, body: 'You will no longer be friends.', confirmLabel: 'Remove', onYes: () => act(() => api('DELETE', `/friends/${r.friendshipId}`)) })}><UserMinus size={17} /></button>
    </Row>
  );
  const pendingCount = friends.incoming.length + invites.length;
  const tabs: [typeof tab, string][] = [['friends', 'Friends'], ['pending', `Pending${pendingCount ? ` (${pendingCount})` : ''}`], ['blocked', 'Blocked'], ['add', 'Add friend']];
  const online = friends.friends.filter((r) => r.user.status !== 'OFFLINE');
  const offline = friends.friends.filter((r) => r.user.status === 'OFFLINE');
  return (
    <>
      <header className="flex h-12 shrink-0 items-center gap-2 border-b border-line px-3">
        <button className="icon-btn md:hidden" aria-label="Open navigation" onClick={() => st.setNav(true)}><Menu size={20} /></button>
        <h1 className="mr-3 font-semibold">Friends</h1>
        <div className="flex gap-1 overflow-x-auto" role="tablist">{tabs.map(([k, l]) => <button role="tab" aria-selected={tab === k} key={k} onClick={() => setHomeTab(k)} className={`whitespace-nowrap rounded-lg px-3 py-1 text-sm ${tab === k ? (k === 'add' ? 'bg-accent text-white' : 'bg-panel') : 'text-mute hover:bg-panel/60'}`}>{l}</button>)}</div>
      </header>
      <div className="min-h-0 flex-1 overflow-y-auto p-3">
        {tab === 'friends' && (friends.friends.length === 0 ? <Empty title="No friends yet" hint="Use “Add friend” to find people by username." /> : (
          <>
            <p className="label px-3">Online — {online.length}</p><ul>{online.map(fr)}</ul>
            <p className="label mt-4 px-3">Offline — {offline.length}</p><ul className="opacity-70">{offline.map(fr)}</ul>
          </>
        ))}
        {tab === 'pending' && (
          <>
            {friends.incoming.length + friends.outgoing.length + invites.length === 0 && <Empty title="Nothing pending" />}
            {invites.length > 0 && <><p className="label px-3">Server invitations</p><ul>{invites.map((i) => (
              <li key={i.id} className="flex items-center gap-3 rounded-xl px-3 py-2.5 hover:bg-panel/60">
                <Avatar user={{ displayName: i.server.name, avatarUrl: i.server.iconUrl }} size={38} /><div className="min-w-0 flex-1"><p className="truncate font-medium">{i.server.name}</p><p className="text-xs text-mute">Invited by {i.inviter.displayName}</p></div>
                <button className="btn-primary" onClick={async () => { try { await api('POST', `/invites/${i.id}/accept`); await Promise.all([loadServers(), loadInvites()]); nav(`/s/${i.server.id}`); } catch (e) { toast('error', errMsg(e)); } }}>Join</button>
                <button className="btn-ghost" onClick={async () => { try { await api('POST', `/invites/${i.id}/decline`); await loadInvites(); } catch (e) { toast('error', errMsg(e)); } }}>Decline</button>
              </li>))}</ul></>}
            {friends.incoming.length > 0 && <><p className="label mt-4 px-3">Incoming requests</p><ul>{friends.incoming.map((r) => <Row key={r.friendshipId} u={r.user}>
              <button className="icon-btn text-emerald-400" aria-label={`Accept ${r.user.displayName}`} onClick={() => act(() => api('POST', `/friends/${r.friendshipId}/accept`), 'Friend added')}><Check size={18} /></button>
              <button className="icon-btn hover:text-rose-400" aria-label={`Reject ${r.user.displayName}`} onClick={() => act(() => api('POST', `/friends/${r.friendshipId}/reject`))}><X size={18} /></button></Row>)}</ul></>}
            {friends.outgoing.length > 0 && <><p className="label mt-4 px-3">Sent requests</p><ul>{friends.outgoing.map((r) => <Row key={r.friendshipId} u={r.user}>
              <button className="btn-ghost" onClick={() => act(() => api('DELETE', `/friends/${r.friendshipId}`))}>Cancel</button></Row>)}</ul></>}
          </>
        )}
        {tab === 'blocked' && (friends.blocked.length === 0 ? <Empty title="No blocked users" /> : <ul>{friends.blocked.map((r) => <Row key={r.friendshipId} u={r.user}><button className="btn-ghost" onClick={() => act(() => api('DELETE', `/blocks/${r.user.id}`), 'Unblocked')}>Unblock</button></Row>)}</ul>)}
        {tab === 'add' && (
          <div className="mx-auto max-w-xl">
            <input className="input mb-3" autoFocus aria-label="Search users" placeholder="Search by username or display name" value={q} onChange={(e) => setQ(e.target.value)} />
            <ul>{res.map((u) => {
              const already = friends.friends.some((r) => r.user.id === u.id), sent = friends.outgoing.some((r) => r.user.id === u.id);
              return <Row key={u.id} u={u}>{already ? <span className="text-xs text-mute">Friends</span> : sent ? <span className="text-xs text-mute">Request sent</span> : <button className="btn-primary" onClick={() => act(() => api('POST', '/friends/request', { userId: u.id }), 'Friend request sent')}><UserPlus size={15} /> Add</button>}</Row>;
            })}</ul>
            {q.trim().length >= 2 && res.length === 0 && <Empty title="No users found" />}
          </div>
        )}
      </div>
    </>
  );
}
