import { useEffect } from 'react';
import { Navigate, Outlet, Route, Routes, useLocation, useMatch, useNavigate, useParams } from 'react-router-dom';
import { Chat } from './components/Chat';
import { ModalHost, ACCENTS } from './components/Modals';
import { ChannelSidebar, HomeSidebar, MemberList, ServerSidebar, UserPanel } from './components/Sidebars';
import { Logo, Spinner, Toasts } from './components/ui';
import Auth from './pages/Auth';
import Home from './pages/Home';
import { useStore } from './store';

const rgb = (hex: string) => [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16)).join(' ');

function Shell() {
  const nav = useNavigate();
  const loc = useLocation();
  const serverId = useMatch('/s/:serverId/*')?.params.serverId;
  const { navOpen, setNav, loadServer, servers, booted } = useStore();
  const known = useStore((s) => s.servers.some((x) => x.id === serverId));
  useEffect(() => { setNav(false); }, [loc.pathname, setNav]);
  useEffect(() => { if (serverId) loadServer(serverId); }, [serverId, loadServer]);
  useEffect(() => { if (serverId && booted && servers.length >= 0 && !known) nav('/', { replace: true }); }, [serverId, known, booted, servers, nav]);
  useEffect(() => {
    const h = (e: KeyboardEvent) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); useStore.getState().openModal({ type: 'search' }); } };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, []);
  return (
    <div className="flex h-dvh overflow-hidden">
      <div className={`fixed inset-y-0 left-0 z-40 flex transition-transform duration-200 md:static md:translate-x-0 ${navOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <ServerSidebar />
        {serverId ? <ChannelSidebar serverId={serverId} /> : <div className="flex min-h-0 w-60 flex-col bg-bg2"><HomeSidebar /><UserPanel /></div>}
      </div>
      {navOpen && <div className="fixed inset-0 z-30 bg-black/60 md:hidden" onClick={() => setNav(false)} aria-hidden />}
      <main className="flex min-w-0 flex-1 flex-col bg-bg"><Outlet /></main>
    </div>
  );
}

function ChannelPage() {
  const { serverId = '', channelId } = useParams();
  const nav = useNavigate();
  const sd = useStore((s) => s.serverData[serverId]);
  const membersOpen = useStore((s) => s.membersOpen);
  const setMembersOpen = useStore((s) => s.setMembersOpen);
  useEffect(() => {
    if (!sd) return;
    const ok = sd.channels.find((c) => c.id === channelId && c.type === 'TEXT');
    const first = sd.channels.find((c) => c.type === 'TEXT');
    if (!ok && first) nav(`/s/${serverId}/${first.id}`, { replace: true });
  }, [sd, channelId, serverId, nav]);
  const ch = sd?.channels.find((c) => c.id === channelId && c.type === 'TEXT');
  return (
    <div className="flex min-h-0 flex-1">
      <div className="flex min-w-0 flex-1 flex-col">
        {ch && sd ? <Chat key={ch.id} kind="channel" id={ch.id} title={ch.name} topic={ch.topic} hasMembers canModerate={sd.me.isOwner || sd.me.perms.includes('MANAGE_MESSAGES')} /> : <Spinner />}
      </div>
      <MemberList serverId={serverId} />
      {membersOpen && (
        <div className="fixed inset-0 z-40 flex justify-end bg-black/60 lg:hidden" onClick={() => setMembersOpen(false)}>
          <div className="h-full animate-pop" onClick={(e) => e.stopPropagation()}><MemberList serverId={serverId} mobile /></div>
        </div>
      )}
    </div>
  );
}

function DMPage() {
  const { id = '' } = useParams();
  const conv = useStore((s) => s.dms.find((c) => c.id === id));
  const loadDMs = useStore((s) => s.loadDMs);
  useEffect(() => { if (!conv) loadDMs(); }, [conv, loadDMs]);
  return conv ? <Chat key={id} kind="dm" id={id} title={conv.user.displayName} /> : <Spinner />;
}

export default function App() {
  const { me, booted, boot } = useStore();
  const accent = me?.settings?.accent;
  useEffect(() => { boot(); }, [boot]);
  useEffect(() => { document.documentElement.style.setProperty('--accent', rgb(accent && ACCENTS.includes(accent) ? accent : ACCENTS[0])); }, [accent]);
  if (!booted) return <div className="grid h-dvh place-items-center"><Logo size={56} /></div>;
  return (
    <>
      <Routes>
        <Route path="/login" element={me ? <Navigate to="/" replace /> : <Auth mode="login" />} />
        <Route path="/register" element={me ? <Navigate to="/" replace /> : <Auth mode="register" />} />
        <Route element={me ? <Shell /> : <Navigate to="/login" replace />}>
          <Route index element={<Home />} />
          <Route path="dm/:id" element={<DMPage />} />
          <Route path="s/:serverId/:channelId?" element={<ChannelPage />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      {me && <ModalHost />}
      <Toasts />
    </>
  );
}
