export type Status = 'ONLINE' | 'IDLE' | 'DND' | 'INVISIBLE' | 'OFFLINE';
export interface Settings { compactMode?: boolean; accent?: string; notifyDM?: boolean; notifyFriend?: boolean; notifyInvite?: boolean; allowFriendRequests?: boolean }
export interface User { id: string; username: string; displayName: string; avatarUrl: string | null; bio: string; customStatus: string | null; status: Status; createdAt: string; email?: string; settings?: Settings }
export interface Member extends User { role: string | null; roleColor: string | null; isOwner: boolean }
export interface Reaction { emoji: string; userIds: string[] }
export interface Msg { id: string; channelId?: string; conversationId?: string; content: string; createdAt: string; editedAt: string | null; clientId?: string | null; author: User | null; reactions?: Reaction[]; pending?: boolean; failed?: boolean }
export interface Channel { id: string; serverId: string; categoryId: string | null; name: string; topic: string; type: 'TEXT' | 'VOICE'; isPrivate: boolean }
export interface Category { id: string; name: string }
export interface ServerLite { id: string; name: string; iconUrl: string | null; ownerId: string; isPublic: boolean }
export interface ServerFull extends ServerLite { categories: Category[]; channels: Channel[]; members: Member[]; me: { isOwner: boolean; perms: string[] } }
export interface Conv { id: string; user: User; lastMessage: { content: string; createdAt: string } | null }
export interface FriendRow { friendshipId: string; user: User }
export interface Friends { friends: FriendRow[]; incoming: FriendRow[]; outgoing: FriendRow[]; blocked: FriendRow[] }
export interface Invite { id: string; server: ServerLite; inviter: User; createdAt: string }
export interface Notif { id: string; type: 'FRIEND_REQUEST' | 'FRIEND_ACCEPTED' | 'DIRECT_MESSAGE' | 'SERVER_INVITE'; data: any; read: boolean; createdAt: string }
export type ModalState =
  | { type: 'createServer' } | { type: 'settings'; tab?: string } | { type: 'profile'; userId: string }
  | { type: 'channel'; serverId: string; channel?: Channel; categoryId?: string } | { type: 'category'; serverId: string }
  | { type: 'invite'; serverId: string } | { type: 'members'; serverId: string } | { type: 'serverSettings'; serverId: string }
  | { type: 'explore' } | { type: 'search' } | { type: 'notifications' }
  | { type: 'confirm'; title: string; body: string; confirmLabel: string; onYes: () => void | Promise<void> };
