import { create } from 'zustand';
import { api, errMsg } from './api';
import { uuid } from './uuid';
import { connectSocket, disconnectSocket, getSocket } from './socket';
import type { Conv, Friends, Invite, ModalState, Msg, Notif, ServerFull, ServerLite, Status, User } from './types';

const emptyFriends: Friends = { friends: [], incoming: [], outgoing: [], blocked: [] };
type Kind = 'channel' | 'dm';
export interface Toast { id: number; kind: 'info' | 'error' | 'success'; text: string }

const upsert = (list: Msg[] = [], m: Msg) => {
  const i = list.findIndex((x) => x.id === m.id || (!!m.clientId && x.clientId === m.clientId));
  if (i < 0) return [...list, m];
  const c = [...list];
  c[i] = m;
  return c;
};
let toastId = 1;

interface S {
  me: User | null; booted: boolean; servers: ServerLite[]; serverData: Record<string, ServerFull>;
  messages: Record<string, Msg[]>; hasMore: Record<string, boolean>; activeKey: string | null;
  dms: Conv[]; friends: Friends; invites: Invite[]; notifications: Notif[];
  toasts: Toast[]; modal: ModalState | null; navOpen: boolean; membersOpen: boolean; homeTab: 'friends' | 'pending' | 'blocked' | 'add';
  boot(): Promise<void>; auth(mode: 'login' | 'register', body: object): Promise<void>; logout(all?: boolean): Promise<void>; setMe(u: User): void;
  loadServers(): Promise<void>; loadServer(id: string): Promise<void>; loadDMs(): Promise<void>; loadFriends(): Promise<void>;
  loadInvites(): Promise<void>; loadNotifications(): Promise<void>;
  toast(kind: Toast['kind'], text: string): void; dismissToast(id: number): void;
  openModal(m: ModalState): void; closeModal(): void; confirm(o: { title: string; body: string; confirmLabel?: string; onYes: () => void | Promise<void> }): void;
  setNav(v: boolean): void; setMembersOpen(v: boolean): void; setHomeTab(t: S['homeTab']): void; setActive(k: string | null): void;
  loadMessages(kind: Kind, id: string, older?: boolean): Promise<void>; resync(): void;
  send(kind: Kind, id: string, content: string, clientId?: string): void;
  receiveMessage(key: string, m: Msg): void; removeMessage(key: string, id: string): void; patchMessage(key: string, id: string, p: Partial<Msg>): void;
  setPresence(userId: string, status: Status): void; serverGone(id: string): void; pushNotification(n: Notif): void; markRead(conversationId?: string): Promise<void>;
}

export const useStore = create<S>((set, get) => ({
  me: null, booted: false, servers: [], serverData: {}, messages: {}, hasMore: {}, activeKey: null,
  dms: [], friends: emptyFriends, invites: [], notifications: [], toasts: [], modal: null, navOpen: false, membersOpen: false, homeTab: 'friends',

  async boot() {
    try {
      set({ me: await api('GET', '/auth/me') });
      await after();
    } catch { /* not signed in */ }
    set({ booted: true });
  },
  async auth(mode, body) {
    set({ me: await api('POST', '/auth/' + mode, body) });
    await after();
  },
  async logout(all = false) {
    await api('POST', all ? '/auth/logout-all' : '/auth/logout').catch(() => {});
    disconnectSocket();
    set({ me: null, servers: [], serverData: {}, messages: {}, hasMore: {}, dms: [], friends: emptyFriends, invites: [], notifications: [], modal: null, activeKey: null });
  },
  setMe: (me) => set({ me }),

  async loadServers() { try { set({ servers: await api('GET', '/servers') }); } catch (e) { get().toast('error', errMsg(e)); } },
  async loadServer(id) {
    try { const d = await api<ServerFull>('GET', '/servers/' + id); set((s) => ({ serverData: { ...s.serverData, [id]: d } })); }
    catch { get().serverGone(id); }
  },
  async loadDMs() { try { set({ dms: await api('GET', '/dms') }); } catch { /* ignore */ } },
  async loadFriends() { try { set({ friends: await api('GET', '/friends') }); } catch { /* ignore */ } },
  async loadInvites() { try { set({ invites: await api('GET', '/invites') }); } catch { /* ignore */ } },
  async loadNotifications() { try { set({ notifications: await api('GET', '/notifications') }); } catch { /* ignore */ } },

  toast(kind, text) {
    const id = toastId++;
    set((s) => ({ toasts: [...s.toasts, { id, kind, text }] }));
    setTimeout(() => get().dismissToast(id), 4500);
  },
  dismissToast: (id) => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),
  openModal: (modal) => set({ modal }),
  closeModal: () => set({ modal: null }),
  confirm: (o) => set({ modal: { type: 'confirm', title: o.title, body: o.body, confirmLabel: o.confirmLabel ?? 'Confirm', onYes: o.onYes } }),
  setNav: (navOpen) => set({ navOpen }),
  setMembersOpen: (membersOpen) => set({ membersOpen }),
  setHomeTab: (homeTab) => set({ homeTab }),
  setActive: (activeKey) => set({ activeKey }),

  async loadMessages(kind, id, older = false) {
    const key = `${kind}:${id}`;
    const cur = get().messages[key] ?? [];
    const before = older ? cur.find((m) => !m.id.startsWith('tmp-'))?.createdAt : undefined;
    try {
      const q = new URLSearchParams({ limit: '50', ...(before ? { before } : {}) });
      const r = await api<{ messages: Msg[]; hasMore: boolean }>('GET', `/${kind === 'channel' ? 'channels' : 'dms'}/${id}/messages?${q}`);
      set((s) => {
        const existing = s.messages[key] ?? [];
        const next = older
          ? [...r.messages, ...existing]
          : [...r.messages, ...existing.filter((m) => m.id.startsWith('tmp-') && !r.messages.some((f) => f.clientId === m.clientId))];
        return { messages: { ...s.messages, [key]: next }, hasMore: { ...s.hasMore, [key]: older ? r.hasMore : r.hasMore } };
      });
    } catch (e) {
      get().toast('error', errMsg(e));
      set((s) => ({ messages: { ...s.messages, [key]: s.messages[key] ?? [] } }));
    }
  },
  resync() {
    const k = get().activeKey;
    get().loadServers();
    get().loadFriends();
    if (!k) return;
    const [kind, id] = k.split(':') as [Kind, string];
    if (kind === 'channel') getSocket()?.emit('channel:join', id);
    get().loadMessages(kind, id);
  },

  send(kind, id, content, existing) {
    const key = `${kind}:${id}`;
    const clientId = existing ?? uuid();
    const tmp: Msg = { id: 'tmp-' + clientId, clientId, content, createdAt: new Date().toISOString(), editedAt: null, author: get().me, pending: true, reactions: [], ...(kind === 'channel' ? { channelId: id } : { conversationId: id }) };
    set((s) => ({ messages: { ...s.messages, [key]: upsert(s.messages[key], tmp) } }));
    const mark = (failed: boolean) =>
      set((s) => ({ messages: { ...s.messages, [key]: (s.messages[key] ?? []).map((m) => (m.id === 'tmp-' + clientId ? { ...m, pending: false, failed } : m)) } }));
    const sock = getSocket();
    if (!sock?.connected) return mark(true);
    const payload = kind === 'channel' ? { channelId: id, content, clientId } : { conversationId: id, content, clientId };
    sock.timeout(8000).emit(kind === 'channel' ? 'message:send' : 'dm:send', payload, (err: unknown, res: any) => {
      if (err || !res?.ok) {
        mark(true);
        if (res?.error) get().toast('error', res.error);
        return;
      }
      get().receiveMessage(key, res.message);
    });
  },
  receiveMessage(key, m) {
    set((s) => (s.messages[key] ? { messages: { ...s.messages, [key]: upsert(s.messages[key], m) } } : s));
  },
  removeMessage: (key, id) => set((s) => ({ messages: { ...s.messages, [key]: (s.messages[key] ?? []).filter((m) => m.id !== id) } })),
  patchMessage: (key, id, p) => set((s) => ({ messages: { ...s.messages, [key]: (s.messages[key] ?? []).map((m) => (m.id === id ? { ...m, ...p } : m)) } })),

  setPresence(userId, status) {
    set((s) => {
      const serverData = { ...s.serverData };
      for (const k in serverData) serverData[k] = { ...serverData[k], members: serverData[k].members.map((m) => (m.id === userId ? { ...m, status } : m)) };
      const f = (rows: Friends['friends']) => rows.map((r) => (r.user.id === userId ? { ...r, user: { ...r.user, status } } : r));
      return {
        serverData,
        dms: s.dms.map((c) => (c.user.id === userId ? { ...c, user: { ...c.user, status } } : c)),
        friends: { friends: f(s.friends.friends), incoming: f(s.friends.incoming), outgoing: f(s.friends.outgoing), blocked: f(s.friends.blocked) },
      };
    });
  },
  serverGone(id) {
    set((s) => {
      const { [id]: _drop, ...rest } = s.serverData;
      return { servers: s.servers.filter((x) => x.id !== id), serverData: rest };
    });
  },
  pushNotification: (n) => set((s) => ({ notifications: [n, ...s.notifications] })),
  async markRead(conversationId) {
    set((s) => ({ notifications: s.notifications.map((n) => (!conversationId || n.data?.conversationId === conversationId ? { ...n, read: true } : n)) }));
    await api('POST', '/notifications/read', conversationId ? { conversationId } : {}).catch(() => {});
  },
}));

async function after() {
  connectSocket();
  const s = useStore.getState();
  await Promise.all([s.loadServers(), s.loadDMs(), s.loadFriends(), s.loadInvites(), s.loadNotifications()]);
}
