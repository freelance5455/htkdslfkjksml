import { Camera, Check, Search as SearchIcon } from 'lucide-react';
import { useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, errMsg } from '../api';
import { notifText } from '../socket';
import { useStore } from '../store';
import type { Channel, ModalState, Settings, Status, User } from '../types';
import { Avatar, Empty, ErrorText, Modal, Spinner, STATUS_LABEL, Toggle } from './ui';

function useForm() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const run = async (fn: () => Promise<void>) => {
    setBusy(true); setError('');
    try { await fn(); } catch (e) { setError(errMsg(e)); } finally { setBusy(false); }
  };
  return { busy, error, run };
}
const Field = ({ id, label, children }: { id: string; label: string; children: ReactNode }) => (
  <div className="mb-4"><label htmlFor={id} className="label">{label}</label>{children}</div>
);
export const ACCENTS = ['#7775F8', '#43C9C2', '#F472B6', '#F59E0B', '#34D399'];

export function ModalHost() {
  const m = useStore((s) => s.modal);
  const close = useStore((s) => s.closeModal);
  if (!m) return null;
  switch (m.type) {
    case 'createServer': return <CreateServer />;
    case 'explore': return <Explore />;
    case 'settings': return <SettingsModal tab={m.tab} />;
    case 'profile': return <ProfileModal userId={m.userId} />;
    case 'channel': return <ChannelModal serverId={m.serverId} channel={m.channel} categoryId={m.categoryId} />;
    case 'category': return <CategoryModal serverId={m.serverId} />;
    case 'invite': return <InviteModal serverId={m.serverId} />;
    case 'members': return <MembersModal serverId={m.serverId} />;
    case 'serverSettings': return <ServerSettingsModal serverId={m.serverId} />;
    case 'search': return <SearchModal />;
    case 'notifications': return <NotificationsModal />;
    case 'confirm': return <ConfirmModal m={m} onClose={close} />;
  }
}

function ConfirmModal({ m, onClose }: { m: Extract<ModalState, { type: 'confirm' }>; onClose: () => void }) {
  const f = useForm();
  return (
    <Modal title={m.title} onClose={onClose}>
      <p className="mb-5 text-sm text-mute">{m.body}</p>
      <div className="flex justify-end gap-2">
        <button className="btn-ghost" onClick={onClose}>Cancel</button>
        <button autoFocus className="btn-danger" disabled={f.busy} onClick={() => f.run(async () => { await m.onYes(); onClose(); })}>{m.confirmLabel}</button>
      </div>
    </Modal>
  );
}

function CreateServer() {
  const { closeModal, loadServers, loadServer } = useStore();
  const nav = useNavigate();
  const [name, setName] = useState('');
  const [pub, setPub] = useState(false);
  const f = useForm();
  const submit = (e: FormEvent) => {
    e.preventDefault();
    f.run(async () => {
      const s = await api<{ id: string }>('POST', '/servers', { name, isPublic: pub });
      await loadServers(); await loadServer(s.id); closeModal(); nav(`/s/${s.id}`);
    });
  };
  return (
    <Modal title="Create a server" onClose={closeModal}>
      <form onSubmit={submit}>
        <Field id="sn" label="Server name"><input id="sn" className="input" autoFocus required minLength={2} maxLength={60} value={name} onChange={(e) => setName(e.target.value)} placeholder="My community" /></Field>
        <Toggle checked={pub} onChange={setPub} label="Public server" hint="Anyone can find and join it from Explore." />
        <ErrorText>{f.error}</ErrorText>
        <div className="mt-4 flex justify-end gap-2"><button type="button" className="btn-ghost" onClick={closeModal}>Cancel</button><button className="btn-primary" disabled={f.busy}>Create</button></div>
      </form>
    </Modal>
  );
}

function Explore() {
  const { closeModal, loadServers, loadServer } = useStore();
  const nav = useNavigate();
  const [list, setList] = useState<any[] | null>(null);
  const f = useForm();
  useEffect(() => { api('GET', '/servers/explore').then(setList).catch(() => setList([])); }, []);
  return (
    <Modal title="Explore communities" onClose={closeModal}>
      <ErrorText>{f.error}</ErrorText>
      {!list ? <Spinner /> : list.length === 0 ? <Empty title="Nothing to explore yet" hint="Public servers you haven’t joined appear here." /> : (
        <ul className="space-y-2">
          {list.map((s) => (
            <li key={s.id} className="flex items-center gap-3 rounded-xl bg-panel p-3">
              <Avatar user={{ displayName: s.name, avatarUrl: s.iconUrl }} size={40} />
              <div className="min-w-0 flex-1"><p className="truncate font-medium">{s.name}</p><p className="text-xs text-mute">{s._count.members} members</p></div>
              <button className="btn-primary" onClick={() => f.run(async () => { await api('POST', `/servers/${s.id}/join`); await loadServers(); await loadServer(s.id); closeModal(); nav(`/s/${s.id}`); })}>Join</button>
            </li>
          ))}
        </ul>
      )}
    </Modal>
  );
}

function ChannelModal({ serverId, channel, categoryId }: { serverId: string; channel?: Channel; categoryId?: string }) {
  const { closeModal, loadServer, confirm } = useStore();
  const sd = useStore((s) => s.serverData[serverId]);
  const nav = useNavigate();
  const [name, setName] = useState(channel?.name ?? '');
  const [topic, setTopic] = useState(channel?.topic ?? '');
  const [cat, setCat] = useState(channel?.categoryId ?? categoryId ?? '');
  const [priv, setPriv] = useState(channel?.isPrivate ?? false);
  const [type, setType] = useState<'TEXT' | 'VOICE'>('TEXT');
  const f = useForm();
  const submit = (e: FormEvent) => {
    e.preventDefault();
    f.run(async () => {
      const body = { name, topic, categoryId: cat || null, isPrivate: priv };
      if (channel) await api('PATCH', `/channels/${channel.id}`, body);
      else await api('POST', `/servers/${serverId}/channels`, { ...body, type });
      await loadServer(serverId); closeModal();
    });
  };
  return (
    <Modal title={channel ? `Edit #${channel.name}` : 'Create channel'} onClose={closeModal}>
      <form onSubmit={submit}>
        {!channel && <div className="mb-4 flex gap-2" role="radiogroup" aria-label="Channel type">{(['TEXT', 'VOICE'] as const).map((t) => <button type="button" role="radio" aria-checked={type === t} key={t} onClick={() => setType(t)} className={`btn flex-1 ${type === t ? 'bg-accent text-white' : 'bg-panel'}`}>{t === 'TEXT' ? '# Text' : 'Voice (placeholder)'}</button>)}</div>}
        <Field id="cn" label="Channel name"><input id="cn" className="input" required autoFocus maxLength={50} value={name} onChange={(e) => setName(e.target.value)} placeholder="new-channel" /></Field>
        {(channel?.type ?? type) === 'TEXT' && <Field id="ct" label="Description"><input id="ct" className="input" maxLength={200} value={topic} onChange={(e) => setTopic(e.target.value)} placeholder="What is this channel about?" /></Field>}
        <Field id="cc" label="Category">
          <select id="cc" className="input" value={cat} onChange={(e) => setCat(e.target.value)}><option value="">No category</option>{sd?.categories.map((k) => <option key={k.id} value={k.id}>{k.name}</option>)}</select>
        </Field>
        <Toggle checked={priv} onChange={setPriv} label="Private channel" hint="Only the owner and members who can manage channels can see it." />
        <ErrorText>{f.error}</ErrorText>
        <div className="mt-4 flex items-center justify-between gap-2">
          {channel ? <button type="button" className="btn-danger" onClick={() => confirm({ title: `Delete #${channel.name}?`, body: 'All messages in this channel will be permanently deleted.', confirmLabel: 'Delete channel', onYes: async () => { await api('DELETE', `/channels/${channel.id}`); await loadServer(serverId); nav(`/s/${serverId}`); } })}>Delete</button> : <span />}
          <div className="flex gap-2"><button type="button" className="btn-ghost" onClick={closeModal}>Cancel</button><button className="btn-primary" disabled={f.busy}>{channel ? 'Save' : 'Create'}</button></div>
        </div>
      </form>
    </Modal>
  );
}

function CategoryModal({ serverId }: { serverId: string }) {
  const { closeModal, loadServer } = useStore();
  const [name, setName] = useState('');
  const f = useForm();
  return (
    <Modal title="Create category" onClose={closeModal}>
      <form onSubmit={(e) => { e.preventDefault(); f.run(async () => { await api('POST', `/servers/${serverId}/categories`, { name }); await loadServer(serverId); closeModal(); }); }}>
        <Field id="kn" label="Category name"><input id="kn" className="input" autoFocus required maxLength={40} value={name} onChange={(e) => setName(e.target.value)} /></Field>
        <ErrorText>{f.error}</ErrorText>
        <div className="mt-4 flex justify-end"><button className="btn-primary" disabled={f.busy}>Create</button></div>
      </form>
    </Modal>
  );
}

function useUserSearch() {
  const [q, setQ] = useState('');
  const [res, setRes] = useState<User[]>([]);
  useEffect(() => {
    if (q.trim().length < 2) return setRes([]);
    const t = setTimeout(() => api<User[]>('GET', `/users/search?q=${encodeURIComponent(q.trim())}`).then(setRes).catch(() => setRes([])), 250);
    return () => clearTimeout(t);
  }, [q]);
  return { q, setQ, res };
}

function InviteModal({ serverId }: { serverId: string }) {
  const { closeModal, toast } = useStore();
  const sd = useStore((s) => s.serverData[serverId]);
  const { q, setQ, res } = useUserSearch();
  const [sent, setSent] = useState<string[]>([]);
  const memberIds = new Set(sd?.members.map((m) => m.id));
  return (
    <Modal title={`Invite people to ${sd?.name ?? ''}`} onClose={closeModal}>
      <input className="input mb-3" autoFocus placeholder="Search registered users by name or username" aria-label="Search users" value={q} onChange={(e) => setQ(e.target.value)} />
      <ul className="space-y-1">
        {res.map((u) => (
          <li key={u.id} className="flex items-center gap-3 rounded-lg p-2 hover:bg-panel">
            <Avatar user={u} size={34} dot /><div className="min-w-0 flex-1"><p className="truncate text-sm font-medium">{u.displayName}</p><p className="text-xs text-mute">@{u.username}</p></div>
            {memberIds.has(u.id) ? <span className="text-xs text-mute">Member</span> : sent.includes(u.id) ? <span className="flex items-center gap-1 text-xs text-emerald-400"><Check size={14} />Sent</span> :
              <button className="btn-primary" onClick={async () => { try { await api('POST', `/servers/${serverId}/invites`, { userId: u.id }); setSent([...sent, u.id]); } catch (e) { toast('error', errMsg(e)); } }}>Invite</button>}
          </li>
        ))}
        {q.trim().length >= 2 && res.length === 0 && <Empty title="No users found" />}
      </ul>
    </Modal>
  );
}

function MembersModal({ serverId }: { serverId: string }) {
  const { closeModal, loadServer, confirm, toast, me } = useStore();
  const sd = useStore((s) => s.serverData[serverId]);
  if (!sd) return null;
  const can = (p: string) => sd.me.isOwner || sd.me.perms.includes(p);
  const act = async (fn: () => Promise<unknown>) => { try { await fn(); await loadServer(serverId); } catch (e) { toast('error', errMsg(e)); } };
  return (
    <Modal title={`Members — ${sd.members.length}`} onClose={closeModal} wide>
      <ul className="space-y-1">
        {sd.members.map((m) => (
          <li key={m.id} className="flex items-center gap-3 rounded-lg p-2 hover:bg-panel">
            <Avatar user={m} size={36} dot />
            <div className="min-w-0 flex-1"><p className="truncate text-sm font-medium">{m.displayName} <span className="text-xs text-mute">@{m.username}</span></p><p className="text-xs text-mute">{m.isOwner ? 'Owner' : m.role}</p></div>
            {sd.me.isOwner && !m.isOwner && <button className="btn-ghost" onClick={() => act(() => api('PATCH', `/servers/${serverId}/members/${m.id}`, { role: m.role === 'Admin' ? 'Member' : 'Admin' }))}>{m.role === 'Admin' ? 'Demote' : 'Make admin'}</button>}
            {can('KICK_MEMBERS') && !m.isOwner && m.id !== me?.id && <button className="btn-danger" onClick={() => confirm({ title: `Remove ${m.displayName}?`, body: 'They can rejoin only if the server is public or they are invited again.', confirmLabel: 'Remove', onYes: () => act(() => api('DELETE', `/servers/${serverId}/members/${m.id}`)) })}>Remove</button>}
          </li>
        ))}
      </ul>
    </Modal>
  );
}

function ServerSettingsModal({ serverId }: { serverId: string }) {
  const { closeModal, loadServer, loadServers, confirm, toast } = useStore();
  const sd = useStore((s) => s.serverData[serverId]);
  const nav = useNavigate();
  const [name, setName] = useState(sd?.name ?? '');
  const [pub, setPub] = useState(sd?.isPublic ?? false);
  const f = useForm();
  const file = useRef<HTMLInputElement>(null);
  if (!sd) return null;
  const upload = async (fl?: File) => {
    if (!fl) return;
    const fd = new FormData(); fd.append('file', fl);
    try { await api('POST', `/servers/${serverId}/icon`, fd); await Promise.all([loadServer(serverId), loadServers()]); toast('success', 'Server icon updated'); } catch (e) { toast('error', errMsg(e)); }
  };
  return (
    <Modal title="Server settings" onClose={closeModal}>
      <div className="mb-4 flex items-center gap-4">
        <Avatar user={{ displayName: sd.name, avatarUrl: sd.iconUrl }} size={64} />
        <input ref={file} type="file" hidden accept="image/png,image/jpeg,image/webp,image/gif" onChange={(e) => upload(e.target.files?.[0])} />
        <button className="btn-ghost" onClick={() => file.current?.click()}><Camera size={16} /> Change icon</button>
      </div>
      <form onSubmit={(e) => { e.preventDefault(); f.run(async () => { await api('PATCH', `/servers/${serverId}`, { name, isPublic: pub }); await Promise.all([loadServer(serverId), loadServers()]); toast('success', 'Saved'); }); }}>
        <Field id="ssn" label="Server name"><input id="ssn" className="input" required minLength={2} maxLength={60} value={name} onChange={(e) => setName(e.target.value)} /></Field>
        <Toggle checked={pub} onChange={setPub} label="Public server" hint="Listed in Explore; anyone can join." />
        <ErrorText>{f.error}</ErrorText>
        <div className="mt-4 flex justify-end"><button className="btn-primary" disabled={f.busy}>Save changes</button></div>
      </form>
      {sd.me.isOwner && (
        <div className="mt-6 rounded-xl border border-rose-500/30 p-4">
          <p className="mb-2 text-sm font-semibold text-rose-300">Danger zone</p>
          <button className="btn-danger" onClick={() => confirm({ title: `Delete ${sd.name}?`, body: 'Every channel and message will be permanently deleted for all members.', confirmLabel: 'Delete server', onYes: async () => { await api('DELETE', `/servers/${serverId}`); useStore.getState().serverGone(serverId); nav('/'); } })}>Delete server</button>
        </div>
      )}
    </Modal>
  );
}

function ProfileModal({ userId }: { userId: string }) {
  const { closeModal, openModal, me, friends, confirm, toast, loadFriends, loadDMs } = useStore();
  const nav = useNavigate();
  const [u, setU] = useState<User | null>(userId === me?.id ? me : null);
  const [err, setErr] = useState('');
  useEffect(() => { if (userId !== me?.id) api<User>('GET', `/users/${userId}`).then(setU).catch((e) => setErr(errMsg(e))); }, [userId, me?.id]);
  if (err) return <Modal title="Profile" onClose={closeModal}><ErrorText>{err}</ErrorText></Modal>;
  if (!u) return <Modal title="Profile" onClose={closeModal}><Spinner /></Modal>;
  const isMe = u.id === me?.id;
  const fr = friends.friends.find((r) => r.user.id === u.id);
  const out = friends.outgoing.find((r) => r.user.id === u.id);
  const inc = friends.incoming.find((r) => r.user.id === u.id);
  const blocked = friends.blocked.find((r) => r.user.id === u.id);
  const act = async (fn: () => Promise<unknown>, ok?: string) => { try { await fn(); await loadFriends(); if (ok) toast('success', ok); } catch (e) { toast('error', errMsg(e)); } };
  return (
    <Modal title="Profile" onClose={closeModal}>
      <div className="-mx-5 -mt-5 mb-10 h-20 bg-gradient-to-r from-accent to-accent2" />
      <div className="-mt-16 mb-3 flex items-end gap-3"><div className="rounded-full border-4 border-bg2"><Avatar user={isMe ? { ...u, status: u.status === 'INVISIBLE' ? 'OFFLINE' : u.status } : u} size={80} dot /></div></div>
      <h3 className="text-xl font-bold">{u.displayName}</h3>
      <p className="text-sm text-mute">@{u.username} · {STATUS_LABEL[isMe ? u.status : u.status]}</p>
      {u.customStatus && <p className="mt-2 rounded-lg bg-panel px-3 py-1.5 text-sm">{u.customStatus}</p>}
      <p className="label mt-4">About</p><p className="whitespace-pre-wrap text-sm">{u.bio || <span className="text-mute">No bio yet.</span>}</p>
      <p className="label mt-4">Member since</p><p className="text-sm">{new Date(u.createdAt).toLocaleDateString([], { dateStyle: 'long' })}</p>
      <div className="mt-6 flex flex-wrap gap-2">
        {isMe ? <button className="btn-primary" onClick={() => openModal({ type: 'settings', tab: 'profile' })}>Edit profile</button> : blocked ? (
          <button className="btn-ghost" onClick={() => act(() => api('DELETE', `/blocks/${u.id}`), 'Unblocked')}>Unblock</button>
        ) : (
          <>
            <button className="btn-primary" onClick={() => act(async () => { const c = await api<{ id: string }>('POST', '/dms', { userId: u.id }); await loadDMs(); closeModal(); nav(`/dm/${c.id}`); })}>Message</button>
            {fr ? <button className="btn-ghost" onClick={() => confirm({ title: `Remove ${u.displayName}?`, body: 'You will no longer be friends.', confirmLabel: 'Remove friend', onYes: () => act(() => api('DELETE', `/friends/${fr.friendshipId}`)) })}>Remove friend</button>
              : inc ? <button className="btn-ghost" onClick={() => act(() => api('POST', `/friends/${inc.friendshipId}/accept`), 'Friend added')}>Accept request</button>
              : out ? <button className="btn-ghost" onClick={() => act(() => api('DELETE', `/friends/${out.friendshipId}`))}>Cancel request</button>
              : <button className="btn-ghost" onClick={() => act(() => api('POST', '/friends/request', { userId: u.id }), 'Friend request sent')}>Add friend</button>}
            <button className="btn-ghost text-rose-300" onClick={() => confirm({ title: `Block ${u.displayName}?`, body: 'They won’t be able to message you or find you in search. Any friendship is removed.', confirmLabel: 'Block', onYes: () => act(() => api('POST', '/blocks', { userId: u.id }), 'Blocked') })}>Block</button>
          </>
        )}
      </div>
    </Modal>
  );
}

function SettingsModal({ tab: initial }: { tab?: string }) {
  const { closeModal, me, setMe, toast, logout, friends, loadFriends } = useStore();
  const nav = useNavigate();
  const [tab, setTab] = useState(initial ?? 'account');
  const tabs = [['account', 'My Account'], ['profile', 'Profile'], ['appearance', 'Appearance'], ['notifications', 'Notifications'], ['privacy', 'Privacy & Safety'], ['blocked', 'Blocked Users']];
  if (!me) return null;
  const s: Settings = me.settings ?? {};
  const save = async (p: Partial<Settings>) => { try { setMe(await api('PATCH', '/users/me/settings', p)); } catch (e) { toast('error', errMsg(e)); } };
  return (
    <Modal title="Settings" onClose={closeModal} wide>
      <div className="flex flex-col gap-5 md:flex-row">
        <nav aria-label="Settings sections" className="flex shrink-0 gap-1 overflow-x-auto md:w-44 md:flex-col">
          {tabs.map(([k, l]) => <button key={k} onClick={() => setTab(k)} aria-current={tab === k} className={`whitespace-nowrap rounded-lg px-3 py-2 text-left text-sm ${tab === k ? 'bg-panel font-medium' : 'text-mute hover:bg-panel/60'}`}>{l}</button>)}
          <button className="whitespace-nowrap rounded-lg px-3 py-2 text-left text-sm text-rose-400 hover:bg-panel/60" onClick={async () => { closeModal(); await logout(); nav('/login'); }}>Log out</button>
        </nav>
        <div className="min-w-0 flex-1">
          {tab === 'account' && <AccountTab />}
          {tab === 'profile' && <ProfileTab />}
          {tab === 'appearance' && (
            <div>
              <Toggle checked={!!s.compactMode} onChange={(v) => save({ compactMode: v })} label="Compact message spacing" hint="Fit more messages on screen." />
              <p className="label mt-4">Accent color</p>
              <div className="flex gap-2">{ACCENTS.map((c) => <button key={c} aria-label={`Accent ${c}`} aria-pressed={(s.accent ?? ACCENTS[0]) === c} onClick={() => save({ accent: c })} className="grid h-9 w-9 place-items-center rounded-full ring-offset-2 ring-offset-bg2 aria-pressed:ring-2 ring-white" style={{ background: c }}>{(s.accent ?? ACCENTS[0]) === c && <Check size={16} />}</button>)}</div>
            </div>
          )}
          {tab === 'notifications' && (
            <div>
              <Toggle checked={s.notifyDM !== false} onChange={(v) => save({ notifyDM: v })} label="Direct messages" />
              <Toggle checked={s.notifyFriend !== false} onChange={(v) => save({ notifyFriend: v })} label="Friend requests and acceptances" />
              <Toggle checked={s.notifyInvite !== false} onChange={(v) => save({ notifyInvite: v })} label="Server invitations" />
              <p className="mt-3 text-xs text-mute">In-app notifications only. Push notifications arrive in a later phase.</p>
            </div>
          )}
          {tab === 'privacy' && (
            <div>
              <Toggle checked={s.allowFriendRequests !== false} onChange={(v) => save({ allowFriendRequests: v })} label="Allow friend requests" hint="When off, nobody can send you new friend requests." />
              <p className="mt-3 text-xs text-mute">Blocked users cannot message you, invite you, or find you in search.</p>
            </div>
          )}
          {tab === 'blocked' && (friends.blocked.length === 0 ? <Empty title="You haven’t blocked anyone" /> : (
            <ul className="space-y-1">{friends.blocked.map((r) => (
              <li key={r.user.id} className="flex items-center gap-3 rounded-lg p-2 hover:bg-panel"><Avatar user={r.user} size={34} /><span className="flex-1 text-sm">{r.user.displayName} <span className="text-mute">@{r.user.username}</span></span>
                <button className="btn-ghost" onClick={async () => { try { await api('DELETE', `/blocks/${r.user.id}`); await loadFriends(); } catch (e) { toast('error', errMsg(e)); } }}>Unblock</button></li>
            ))}</ul>
          ))}
        </div>
      </div>
    </Modal>
  );
}

function AccountTab() {
  const { me, toast, logout, confirm, closeModal } = useStore();
  const nav = useNavigate();
  const [cur, setCur] = useState('');
  const [next, setNext] = useState('');
  const f = useForm();
  return (
    <div>
      <dl className="mb-6 grid grid-cols-[auto_1fr] gap-x-6 gap-y-2 text-sm">
        <dt className="text-mute">Username</dt><dd>@{me!.username}</dd><dt className="text-mute">Email</dt><dd className="break-all">{me!.email}</dd>
        <dt className="text-mute">Joined</dt><dd>{new Date(me!.createdAt).toLocaleDateString()}</dd>
      </dl>
      <form onSubmit={(e) => { e.preventDefault(); f.run(async () => { await api('POST', '/users/me/password', { current: cur, next }); setCur(''); setNext(''); toast('success', 'Password changed. Other sessions were signed out.'); }); }}>
        <p className="mb-2 font-semibold">Change password</p>
        <Field id="cp" label="Current password"><input id="cp" type="password" autoComplete="current-password" className="input" required value={cur} onChange={(e) => setCur(e.target.value)} /></Field>
        <Field id="np" label="New password"><input id="np" type="password" autoComplete="new-password" className="input" required minLength={10} value={next} onChange={(e) => setNext(e.target.value)} /></Field>
        <ErrorText>{f.error}</ErrorText>
        <button className="btn-primary mt-3" disabled={f.busy}>Update password</button>
      </form>
      <div className="mt-6 border-t border-line pt-4">
        <p className="mb-1 font-semibold">Sessions</p>
        <p className="mb-2 text-xs text-mute">Signs you out everywhere, including this device.</p>
        <button className="btn-ghost" onClick={() => confirm({ title: 'Log out of all devices?', body: 'Every active session will be ended.', confirmLabel: 'Log out everywhere', onYes: async () => { closeModal(); await logout(true); nav('/login'); } })}>Log out of all devices</button>
      </div>
    </div>
  );
}

function ProfileTab() {
  const { me, setMe, toast } = useStore();
  const [name, setName] = useState(me!.displayName);
  const [bio, setBio] = useState(me!.bio);
  const [cs, setCs] = useState(me!.customStatus ?? '');
  const [status, setStatus] = useState<Status>(me!.status);
  const file = useRef<HTMLInputElement>(null);
  const f = useForm();
  const upload = async (fl?: File) => {
    if (!fl) return;
    const fd = new FormData(); fd.append('file', fl);
    try { setMe(await api('POST', '/users/me/avatar', fd)); toast('success', 'Avatar updated'); } catch (e) { toast('error', errMsg(e)); }
  };
  return (
    <form onSubmit={(e) => { e.preventDefault(); f.run(async () => { setMe(await api('PATCH', '/users/me', { displayName: name, bio, customStatus: cs, status })); toast('success', 'Profile saved'); }); }}>
      <div className="mb-4 flex items-center gap-4">
        <Avatar user={me} size={72} />
        <input ref={file} type="file" hidden accept="image/png,image/jpeg,image/webp,image/gif" onChange={(e) => upload(e.target.files?.[0])} />
        <div><button type="button" className="btn-ghost" onClick={() => file.current?.click()}><Camera size={16} /> Upload avatar</button><p className="mt-1 text-xs text-mute">PNG, JPEG, WebP or GIF · max 2 MB</p></div>
      </div>
      <Field id="dn" label="Display name"><input id="dn" className="input" required maxLength={32} value={name} onChange={(e) => setName(e.target.value)} /></Field>
      <Field id="bio" label="About me"><textarea id="bio" className="input" rows={3} maxLength={300} value={bio} onChange={(e) => setBio(e.target.value)} /></Field>
      <Field id="cs" label="Custom status"><input id="cs" className="input" maxLength={60} value={cs} onChange={(e) => setCs(e.target.value)} placeholder="What’s happening?" /></Field>
      <Field id="st" label="Status"><select id="st" className="input" value={status} onChange={(e) => setStatus(e.target.value as Status)}>{(['ONLINE', 'IDLE', 'DND', 'INVISIBLE'] as Status[]).map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}</select></Field>
      <ErrorText>{f.error}</ErrorText>
      <button className="btn-primary mt-2" disabled={f.busy}>Save changes</button>
    </form>
  );
}

function SearchModal() {
  const { closeModal, openModal } = useStore();
  const nav = useNavigate();
  const [q, setQ] = useState('');
  const [r, setR] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    if (q.trim().length < 2) return setR(null);
    setLoading(true);
    const t = setTimeout(() => api('GET', `/search?q=${encodeURIComponent(q.trim())}`).then(setR).catch(() => setR(null)).finally(() => setLoading(false)), 300);
    return () => clearTimeout(t);
  }, [q]);
  const go = (to: string) => { closeModal(); nav(to); };
  const none = r && !r.users.length && !r.servers.length && !r.channels.length && !r.messages.length;
  const H = ({ children }: { children: ReactNode }) => <p className="label mt-3">{children}</p>;
  return (
    <Modal title="Search" onClose={closeModal} wide>
      <div className="relative"><SearchIcon size={16} className="absolute left-3 top-2.5 text-mute" /><input autoFocus className="input pl-9" aria-label="Search" placeholder="Search people, servers, channels and messages" value={q} onChange={(e) => setQ(e.target.value)} /></div>
      {loading && <Spinner />}
      {none && <Empty title="No results" hint="Search only covers things you can access." />}
      {r && !none && (
        <div>
          {r.users.length > 0 && <><H>People</H>{r.users.map((u: User) => <button key={u.id} className="flex w-full items-center gap-2 rounded-lg p-2 text-left hover:bg-panel" onClick={() => { closeModal(); openModal({ type: 'profile', userId: u.id }); }}><Avatar user={u} size={30} dot /><span className="text-sm">{u.displayName} <span className="text-mute">@{u.username}</span></span></button>)}</>}
          {r.servers.length > 0 && <><H>Servers</H>{r.servers.map((s: any) => <button key={s.id} className="block w-full rounded-lg p-2 text-left text-sm hover:bg-panel" onClick={() => go(`/s/${s.id}`)}>{s.name}</button>)}</>}
          {r.channels.length > 0 && <><H>Channels</H>{r.channels.map((c: any) => <button key={c.id} className="block w-full rounded-lg p-2 text-left text-sm hover:bg-panel" onClick={() => go(`/s/${c.serverId}/${c.id}`)}>#{c.name} <span className="text-mute">in {c.server.name}</span></button>)}</>}
          {r.messages.length > 0 && <><H>Messages</H>{r.messages.map((m: any) => <button key={m.id} className="block w-full rounded-lg p-2 text-left hover:bg-panel" onClick={() => go(`/s/${m.serverId}/${m.channelId}`)}><span className="block text-xs text-mute">{m.author?.displayName ?? 'Deleted user'} · #{m.channelName} · {new Date(m.createdAt).toLocaleDateString()}</span><span className="block truncate text-sm">{m.content}</span></button>)}</>}
        </div>
      )}
    </Modal>
  );
}

function NotificationsModal() {
  const { closeModal, notifications, markRead, setHomeTab } = useStore();
  const nav = useNavigate();
  useEffect(() => { useStore.getState().loadNotifications(); }, []);
  return (
    <Modal title="Notifications" onClose={closeModal}>
      {notifications.length === 0 ? <Empty title="You’re all caught up" /> : (
        <>
          <div className="mb-2 flex justify-end"><button className="btn-ghost text-xs" onClick={() => markRead()}>Mark all as read</button></div>
          <ul className="space-y-1">
            {notifications.map((n) => (
              <li key={n.id}>
                <button className={`flex w-full items-start gap-2 rounded-lg p-2.5 text-left text-sm hover:bg-panel ${n.read ? 'opacity-60' : ''}`} onClick={() => { closeModal(); if (n.type === 'DIRECT_MESSAGE') nav(`/dm/${n.data.conversationId}`); else { setHomeTab(n.type === 'FRIEND_ACCEPTED' ? 'friends' : 'pending'); nav('/'); } }}>
                  {!n.read && <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-accent" />}
                  <span><span className="block">{notifText(n)}</span>{n.type === 'DIRECT_MESSAGE' && <span className="block truncate text-xs text-mute">{n.data.preview}</span>}<time className="text-xs text-mute">{new Date(n.createdAt).toLocaleString()}</time></span>
                </button>
              </li>
            ))}
          </ul>
        </>
      )}
    </Modal>
  );
}
