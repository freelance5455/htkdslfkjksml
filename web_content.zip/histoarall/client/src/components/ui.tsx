import { Loader2, X } from 'lucide-react';
import { useEffect, type ReactNode } from 'react';
import { useStore } from '../store';
import type { Status } from '../types';

export function Logo({ size = 36 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" role="img" aria-label="Histoarall">
      <defs>
        <linearGradient id="hg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#7775F8" />
          <stop offset="1" stopColor="#43C9C2" />
        </linearGradient>
      </defs>
      <rect width="40" height="40" rx="11" fill="url(#hg)" />
      <rect x="10" y="9" width="6" height="22" rx="3" fill="#fff" />
      <rect x="24" y="9" width="6" height="22" rx="3" fill="#fff" />
      <rect x="12" y="17" width="16" height="6" rx="3" fill="#fff" />
    </svg>
  );
}

const DOT: Record<string, string> = { ONLINE: 'bg-emerald-400', IDLE: 'bg-amber-400', DND: 'bg-rose-500', OFFLINE: 'bg-slate-500', INVISIBLE: 'bg-slate-500' };
export const STATUS_LABEL: Record<Status, string> = { ONLINE: 'Online', IDLE: 'Idle', DND: 'Do not disturb', INVISIBLE: 'Invisible', OFFLINE: 'Offline' };

export function Avatar({ user, size = 36, dot = false, className = '' }: { user?: { displayName: string; avatarUrl: string | null; status?: Status } | null; size?: number; dot?: boolean; className?: string }) {
  const name = user?.displayName || '?';
  const hue = [...name].reduce((a, c) => a + c.charCodeAt(0), 0) % 360;
  return (
    <div className={`relative shrink-0 ${className}`} style={{ width: size, height: size }}>
      {user?.avatarUrl ? (
        <img src={user.avatarUrl} alt="" className="h-full w-full rounded-full object-cover" />
      ) : (
        <div className="grid h-full w-full place-items-center rounded-full font-semibold text-white" style={{ background: `hsl(${hue} 45% 42%)`, fontSize: size * 0.4 }}>
          {name[0]?.toUpperCase()}
        </div>
      )}
      {dot && <span aria-label={user?.status ?? 'OFFLINE'} className={`absolute -bottom-0.5 -right-0.5 rounded-full border-2 border-bg2 ${DOT[user?.status ?? 'OFFLINE']}`} style={{ width: Math.max(10, size * 0.32), height: Math.max(10, size * 0.32) }} />}
    </div>
  );
}

export function Modal({ title, onClose, children, wide = false }: { title: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true" aria-label={title} className={`animate-pop max-h-[90dvh] w-full overflow-auto rounded-2xl border border-line bg-bg2 shadow-2xl ${wide ? 'max-w-3xl' : 'max-w-md'}`}>
        <div className="flex items-center justify-between border-b border-line px-5 py-3">
          <h2 className="font-semibold">{title}</h2>
          <button className="icon-btn" aria-label="Close" onClick={onClose}><X size={18} /></button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

export const Spinner = ({ label = 'Loading…' }: { label?: string }) => (
  <div className="flex items-center justify-center gap-2 p-6 text-sm text-mute"><Loader2 className="animate-spin" size={16} />{label}</div>
);
export const Empty = ({ title, hint }: { title: string; hint?: string }) => (
  <div className="p-8 text-center"><p className="font-medium">{title}</p>{hint && <p className="mt-1 text-sm text-mute">{hint}</p>}</div>
);
export const ErrorText = ({ children }: { children?: ReactNode }) => (children ? <p role="alert" className="rounded-lg bg-rose-500/10 px-3 py-2 text-sm text-rose-300">{children}</p> : null);

export function Toggle({ checked, onChange, label, hint }: { checked: boolean; onChange: (v: boolean) => void; label: string; hint?: string }) {
  return (
    <div className="flex items-center justify-between gap-4 py-2">
      <div><p className="text-sm font-medium">{label}</p>{hint && <p className="text-xs text-mute">{hint}</p>}</div>
      <button role="switch" aria-checked={checked} aria-label={label} onClick={() => onChange(!checked)} className={`relative h-6 w-11 shrink-0 rounded-full transition ${checked ? 'bg-accent' : 'bg-line'}`}>
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${checked ? 'left-[22px]' : 'left-0.5'}`} />
      </button>
    </div>
  );
}

export function Toasts() {
  const toasts = useStore((s) => s.toasts);
  const dismiss = useStore((s) => s.dismissToast);
  return (
    <div className="pointer-events-none fixed bottom-4 right-4 z-[60] flex w-[min(22rem,calc(100vw-2rem))] flex-col gap-2" aria-live="polite">
      {toasts.map((t) => (
        <button key={t.id} onClick={() => dismiss(t.id)} className={`pointer-events-auto animate-pop rounded-xl border px-4 py-3 text-left text-sm shadow-xl ${t.kind === 'error' ? 'border-rose-500/40 bg-rose-950 text-rose-100' : t.kind === 'success' ? 'border-emerald-500/40 bg-emerald-950 text-emerald-100' : 'border-line bg-panel text-txt'}`}>
          {t.text}
        </button>
      ))}
    </div>
  );
}
