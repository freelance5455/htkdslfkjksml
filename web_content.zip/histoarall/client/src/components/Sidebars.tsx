import { Bell, ChevronDown, Compass, Headphones, HeadphoneOff, Hash, Mic, MicOff, Plus, Search, Settings, Users, Volume2 } from 'lucide-react';
import { useState } from 'react';
import { NavLink, useMatch, useNavigate } from 'react-router-dom';
import { api, errMsg } from '../api';
import { useStore } from '../store';
import type { Channel, Member } from '../types';
import { Avatar, Logo, Spinner, STATUS_LABEL } from './ui';

export function ServerSidebar() {
  const servers = useStore((s) => s.servers);
  const open = useStore((s) => s.openModal);
  const badge = useStore((s) => s.notifications.filter((n) => !n.read).length + 0);
  const invites = useStore((s) => s.invites.length);
  const active = useMatch('/s/:serverId/*')?.params.serverId;
  const home = !!useMatch('/') || !!useMatch('/dm/:id');
  const count = Math.max(badge, invites);
  return (
    <nav aria-label="Servers" className="flex w-[72px] shrink-0 flex-col items-center gap-2 overflow-y-auto bg-bg py-3">
      <NavLink to="/" aria-label="Home and direct messages" title="Home" className={`relative grid h-12 w-12 place-items-center rounded-2xl transition ${home ? 'ring-2 ring-accent' : 'opacity-80 hover:opacity-100'}`}>
        <Logo size={44} />
        {count > 0 && <span className="absolute -bottom-1 -right-1 grid min-w-[18px] place-items-center rounded-full border-2 border-bg bg-rose-500 px-1 text-[10px] font-bold">{count > 9 ? '9+' : count}</span>}
      </NavLink>
      <div className="h-px w-8 bg-line" />
      {servers.map((s) => (
        <NavLink key={s.id} to={`/s/${s.id}`} title={s.name} aria-label={s.name} className="group relative grid h-12 w-12 place-items-center">
          <span className={`absolute -left-3 w-1 rounded-r bg-white transition-all ${active === s.id ? 'h-8' : 'h-0 group-hover:h-4'}`} />
          {s.iconUrl ? (
            <img src={s.iconUrl} alt="" className={`h-12 w-12 object-cover transition-all ${active === s.id ? 'rounded-2xl' : 'rounded-3xl group-hover:rounded-2xl'}`} />
          ) : (
            <span className={`grid h-12 w-12 place-items-center bg-panel text-sm font-semibold transition-all ${active === s.id ? 'rounded-2xl bg-accent' : 'rounded-3xl group-hover:rounded-2xl group-hover:bg-accent'}`}>
              {s.name.split(/\s+/).map((w) => w[0]).join('').slice(0, 3).toUpperCase()}
            </span>
          )}
        </NavLink>
      ))}
      <button aria-label="Create a server" title="Create a server" onClick={() => open({ type: 'createServer' })} className="grid h-12 w-12 place-items-center rounded-3xl bg-panel text-accent2 transition-all hover:rounded-2xl hover:bg-accent2 hover:text-bg"><Plus /></button>
      <button aria-label="Explore communities" title="Explore communities" onClick={() => open({ type: 'explore' })} className="grid h-12 w-12 place-items-center rounded-3xl bg-panel text-accent2 transition-all hover:rounded-2xl hover:bg-accent2 hover:text-bg"><Compass /></button>
    </nav>
  );
}

export function UserPanel() {
  const me = useStore((s) => s.me)!;
  const open = useStore((s) => s.openModal);
  const unread = useStore((s) => s.notifications.filter((n) => !n.read).length);
  const [mic, setMic] = useState(true);
  const [hp, setHp] = useState(true);
  return (
    <div className="flex items-center gap-2 border-t border-line bg-bg px-2 py-2">
      <button onClick={() => open({ type: 'profile', userId: me.id })} className="flex min-w-0 flex-1 items-center gap-2 rounded-lg p-1 text-left hover:bg-panel" aria-label="Open your profile">
        <Avatar user={{ ...me, status: me.status === 'INVISIBLE' ? 'OFFLINE' : me.status }} size={34} dot />
        <span className="min-w-0">
          <span className="block truncate text-sm font-semibold">{me.displayName}</span>
          <span className="block truncate text-xs text-mute">{me.customStatus || STATUS_LABEL[me.status]}</span>
        </span>
      </button>
      <button className="icon-btn" title="Microphone (visual only in Phase 01)" aria-label="Toggle microphone (visual only)" aria-pressed={!mic} onClick={() => setMic(!mic)}>{mic ? <Mic size={17} /> : <MicOff size={17} className="text-rose-400" />}</button>
      <button className="icon-btn" title="Headphones (visual only in Phase 01)" aria-label="Toggle headphones (visual only)" aria-pressed={!hp} onClick={() => setHp(!hp)}>{hp ? <Headphones size={17} /> : <HeadphoneOff size={17} className="text-rose-400" />}</button>
      <button className="icon-btn relative" aria-label="Notifications" onClick={() => open({ type: 'notifications' })}>
        <Bell size={17} />{unread > 0 && <span className="absolute right-0 top-0 h-2.5 w-2.5 rounded-full bg-rose-500" />}
      </button>
      <button className="icon-btn" aria-label="User settings" onClick={() => open({ type: 'settings' })}><Settings size={17} /></button>
    </div>
  );
}

export function HomeSidebar() {
  const dms = useStore((s) => s.dms);
  const notifs = useStore((s) => s.notifications);
  const open = useStore((s) => s.openModal);
  const pending = useStore((s) => s.friends.incoming.length + s.invites.length);
  return (
    <aside className="flex min-h-0 flex-1 flex-col bg-bg2">
      <button onClick={() => open({ type: 'search' })} className="m-2 flex items-center gap-2 rounded-lg bg-bg px-3 py-2 text-left text-sm text-mute hover:text-txt"><Search size={15} /> Search…</button>
      <NavLink to="/" end className={({ isActive }) => `mx-2 flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium ${isActive ? 'bg-panel' : 'text-mute hover:bg-panel/60 hover:text-txt'}`}>
        <Users size={18} /> Friends {pending > 0 && <span className="ml-auto rounded-full bg-rose-500 px-1.5 text-[10px] font-bold text-white">{pending}</span>}
      </NavLink>
      <p className="mt-4 px-4 text-xs font-semibold uppercase tracking-wide text-mute">Direct messages</p>
      <div className="mt-1 flex-1 space-y-0.5 overflow-y-auto px-2">
        {dms.length === 0 && <p className="px-2 py-3 text-xs text-mute">No conversations yet. Open a friend’s profile to say hi.</p>}
        {dms.map((c) => {
          const unread = notifs.some((n) => !n.read && n.type === 'DIRECT_MESSAGE' && n.data?.conversationId === c.id);
          return (
            <NavLink key={c.id} to={`/dm/${c.id}`} className={({ isActive }) => `flex items-center gap-2.5 rounded-lg px-2 py-1.5 ${isActive ? 'bg-panel' : 'hover:bg-panel/60'}`}>
              <Avatar user={c.user} size={32} dot />
              <span className="min-w-0 flex-1">
                <span className={`block truncate text-sm ${unread ? 'font-bold' : 'font-medium'}`}>{c.user.displayName}</span>
                <span className="block truncate text-xs text-mute">{c.lastMessage?.content ?? 'No messages yet'}</span>
              </span>
              {unread && <span className="h-2 w-2 rounded-full bg-accent" />}
            </NavLink>
          );
        })}
      </div>
    </aside>
  );
}

export function ChannelSidebar({ serverId }: { serverId: string }) {
  const sd = useStore((s) => s.serverData[serverId]);
  const open = useStore((s) => s.openModal);
  const confirm = useStore((s) => s.confirm);
  const toast = useStore((s) => s.toast);
  const nav = useNavigate();
  const [menu, setMenu] = useState(false);
  if (!sd) return <aside className="w-60 bg-bg2"><Spinner /></aside>;
  const can = (p: string) => sd.me.isOwner || sd.me.perms.includes(p);
  const done = async (fn: () => Promise<unknown>) => { try { await fn(); } catch (e) { toast('error', errMsg(e)); } };
  const item = 'flex w-full items-center justify-between gap-2 rounded-md px-2 py-1.5 text-left text-sm hover:bg-accent hover:text-white';
  const uncategorised = sd.channels.filter((c) => !c.categoryId || !sd.categories.some((k) => k.id === c.categoryId));
  const renderCh = (c: Channel) =>
    c.type === 'VOICE' ? (
      <div key={c.id} title="Voice channels arrive in a later phase" aria-disabled className="flex items-center gap-2 rounded-md px-2 py-1 text-sm text-mute/70"><Volume2 size={16} />{c.name}<span className="ml-auto rounded bg-panel px-1.5 text-[10px] uppercase">Soon</span></div>
    ) : (
      <div key={c.id} className="group relative">
        <NavLink to={`/s/${serverId}/${c.id}`} className={({ isActive }) => `flex items-center gap-1.5 rounded-md px-2 py-1 text-sm ${isActive ? 'bg-panel text-txt' : 'text-mute hover:bg-panel/60 hover:text-txt'}`}>
          <Hash size={16} /> <span className="truncate">{c.name}</span>{c.isPrivate && <span className="ml-1 text-[10px] uppercase text-amber-400">private</span>}
        </NavLink>
        {can('MANAGE_CHANNELS') && <button aria-label={`Edit #${c.name}`} onClick={() => open({ type: 'channel', serverId, channel: c })} className="icon-btn absolute right-1 top-0.5 hidden h-6 w-6 group-hover:grid"><Settings size={14} /></button>}
      </div>
    );
  return (
    <aside className="flex min-h-0 w-60 flex-col bg-bg2">
      <div className="relative border-b border-line">
        <button onClick={() => setMenu(!menu)} aria-expanded={menu} aria-haspopup="menu" className="flex h-12 w-full items-center justify-between px-4 font-semibold hover:bg-panel/60"><span className="truncate">{sd.name}</span><ChevronDown size={16} className={menu ? 'rotate-180' : ''} /></button>
        {menu && (
          <>
            <div className="fixed inset-0 z-10" onClick={() => setMenu(false)} />
            <div role="menu" className="absolute left-2 right-2 top-12 z-20 animate-pop rounded-xl border border-line bg-bg p-1.5 shadow-2xl" onClick={() => setMenu(false)}>
              {can('INVITE_MEMBERS') && <button role="menuitem" className={item} onClick={() => open({ type: 'invite', serverId })}>Invite people</button>}
              {can('MANAGE_SERVER') && <button role="menuitem" className={item} onClick={() => open({ type: 'serverSettings', serverId })}>Server settings</button>}
              <button role="menuitem" className={item} onClick={() => open({ type: 'members', serverId })}>Members</button>
              {can('MANAGE_CHANNELS') && <button role="menuitem" className={item} onClick={() => open({ type: 'channel', serverId })}>Create channel</button>}
              {can('MANAGE_CHANNELS') && <button role="menuitem" className={item} onClick={() => open({ type: 'category', serverId })}>Create category</button>}
              <div className="my-1 h-px bg-line" />
              {sd.me.isOwner ? (
                <button role="menuitem" className={`${item} text-rose-400`} onClick={() => open({ type: 'serverSettings', serverId })}>Delete server…</button>
              ) : (
                <button role="menuitem" className={`${item} text-rose-400`} onClick={() => confirm({ title: `Leave ${sd.name}?`, body: 'You will need a new invite to rejoin if the server is private.', confirmLabel: 'Leave server', onYes: () => done(async () => { await api('POST', `/servers/${serverId}/leave`); useStore.getState().serverGone(serverId); nav('/'); }) })}>Leave server</button>
              )}
            </div>
          </>
        )}
      </div>
      <div className="flex-1 space-y-3 overflow-y-auto px-2 py-3">
        {uncategorised.length > 0 && <div className="space-y-0.5">{uncategorised.map(renderCh)}</div>}
        {sd.categories.map((k) => (
          <div key={k.id}>
            <div className="group flex items-center justify-between px-1 pb-1 text-xs font-semibold uppercase tracking-wide text-mute">
              <span>{k.name}</span>
              {can('MANAGE_CHANNELS') && <button aria-label={`Create channel in ${k.name}`} className="opacity-60 hover:opacity-100" onClick={() => open({ type: 'channel', serverId, categoryId: k.id })}><Plus size={15} /></button>}
            </div>
            <div className="space-y-0.5">{sd.channels.filter((c) => c.categoryId === k.id).map(renderCh)}</div>
          </div>
        ))}
      </div>
      <UserPanel />
    </aside>
  );
}

const rank = (m: Member) => (m.status === 'OFFLINE' ? 1 : 0);
export function MemberList({ serverId, mobile = false }: { serverId: string; mobile?: boolean }) {
  const sd = useStore((s) => s.serverData[serverId]);
  const open = useStore((s) => s.openModal);
  if (!sd) return null;
  const online = sd.members.filter((m) => rank(m) === 0);
  const offline = sd.members.filter((m) => rank(m) === 1);
  const row = (m: Member) => (
    <button key={m.id} onClick={() => open({ type: 'profile', userId: m.id })} className={`flex w-full items-center gap-2.5 rounded-lg px-2 py-1.5 text-left hover:bg-panel/60 ${m.status === 'OFFLINE' ? 'opacity-50' : ''}`}>
      <Avatar user={m} size={32} dot />
      <span className="min-w-0 flex-1">
        <span className="block truncate text-sm font-medium" style={m.roleColor && m.role === 'Admin' ? { color: m.roleColor } : undefined}>{m.displayName}</span>
        {m.customStatus && <span className="block truncate text-xs text-mute">{m.customStatus}</span>}
      </span>
      {m.isOwner ? <span className="rounded bg-accent/20 px-1.5 text-[10px] font-semibold uppercase text-accent">Owner</span> : m.role === 'Admin' && <span className="rounded bg-panel px-1.5 text-[10px] uppercase text-mute">Admin</span>}
    </button>
  );
  return (
    <aside aria-label="Members" className={mobile ? 'w-64 overflow-y-auto bg-bg2 p-2' : 'hidden w-60 shrink-0 overflow-y-auto border-l border-line bg-bg2 p-2 lg:block'}>
      <p className="px-2 py-1 text-xs font-semibold uppercase tracking-wide text-mute">Online — {online.length}</p>
      {online.map(row)}
      <p className="mt-3 px-2 py-1 text-xs font-semibold uppercase tracking-wide text-mute">Offline — {offline.length}</p>
      {offline.map(row)}
    </aside>
  );
}
