import { AlertCircle, ArrowDown, Hash, Menu, Pencil, Search, Send, SmilePlus, Trash2, Users } from 'lucide-react';
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { api, errMsg } from '../api';
import { getSocket } from '../socket';
import { useStore } from '../store';
import type { Msg } from '../types';
import { Avatar, Empty, Spinner } from './ui';

const QUICK = ['👍', '❤️', '😂', '🎉', '👀'];
const fmt = (iso: string) => new Date(iso).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' });

interface Props { kind: 'channel' | 'dm'; id: string; title: string; topic?: string; canModerate?: boolean; hasMembers?: boolean }

export function Chat({ kind, id, title, topic, canModerate, hasMembers }: Props) {
  const key = `${kind}:${id}`;
  const st = useStore();
  const { me, loadMessages, send, setActive, openModal, toast } = st;
  const msgs = st.messages[key];
  const hasMore = st.hasMore[key];
  const compact = !!me?.settings?.compactMode;
  const scroller = useRef<HTMLDivElement>(null);
  const [text, setText] = useState('');
  const [editing, setEditing] = useState<{ id: string; draft: string } | null>(null);
  const [picker, setPicker] = useState<string | null>(null);
  const [atBottom, setAtBottom] = useState(true);

  useEffect(() => {
    setActive(key);
    setText('');
    setEditing(null);
    if (kind === 'channel') getSocket()?.emit('channel:join', id);
    loadMessages(kind, id);
    if (kind === 'dm') st.markRead(id);
    return () => {
      if (kind === 'channel') getSocket()?.emit('channel:leave', id);
      setActive(null);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  const last = msgs?.[msgs.length - 1];
  useLayoutEffect(() => {
    const el = scroller.current;
    if (el && (atBottom || last?.author?.id === me?.id)) el.scrollTop = el.scrollHeight;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [msgs?.length, last?.id, key]);
  useEffect(() => { if (kind === 'dm' && last && last.author?.id !== me?.id) st.markRead(id); /* eslint-disable-next-line */ }, [last?.id]);

  const submit = () => {
    const t = text.trim();
    if (!t) return;
    send(kind, id, t);
    setText('');
  };
  const saveEdit = async () => {
    if (!editing) return;
    const draft = editing.draft.trim();
    if (!draft) return toast('error', 'Message cannot be empty');
    try {
      const m = await api<Msg>('PATCH', `/messages/${editing.id}`, { content: draft });
      st.receiveMessage(key, m);
      setEditing(null);
    } catch (e) { toast('error', errMsg(e)); }
  };
  const del = (m: Msg) =>
    st.confirm({ title: 'Delete message?', body: 'This cannot be undone.', confirmLabel: 'Delete', onYes: async () => { try { await api('DELETE', `/messages/${m.id}`); } catch (e) { toast('error', errMsg(e)); } } });
  const react = (m: Msg, emoji: string) => { setPicker(null); getSocket()?.emit('reaction:toggle', { messageId: m.id, emoji }, (r: any) => r && !r.ok && toast('error', r.error)); };

  const rows = useMemo(
    () => (msgs ?? []).map((m, i, a) => {
      const p = a[i - 1];
      const grouped = !!p && p.author?.id === m.author?.id && new Date(m.createdAt).getTime() - new Date(p.createdAt).getTime() < 5 * 60_000;
      return { m, grouped };
    }),
    [msgs],
  );

  return (
    <>
      <header className="flex h-12 shrink-0 items-center gap-2 border-b border-line bg-bg px-3">
        <button className="icon-btn md:hidden" aria-label="Open navigation" onClick={() => st.setNav(true)}><Menu size={20} /></button>
        {kind === 'channel' ? <Hash size={18} className="text-mute" /> : <span className="text-mute">@</span>}
        <h1 className="truncate font-semibold">{title}</h1>
        {topic && <><span className="hidden h-5 w-px bg-line sm:block" /><p className="hidden truncate text-sm text-mute sm:block">{topic}</p></>}
        <div className="ml-auto flex items-center gap-1">
          <button className="icon-btn" aria-label="Search" onClick={() => openModal({ type: 'search' })}><Search size={18} /></button>
          {hasMembers && <button className="icon-btn lg:hidden" aria-label="Show members" onClick={() => st.setMembersOpen(true)}><Users size={18} /></button>}
        </div>
      </header>

      <div ref={scroller} onScroll={(e) => { const el = e.currentTarget; setAtBottom(el.scrollHeight - el.scrollTop - el.clientHeight < 160); }} className="relative min-h-0 flex-1 overflow-y-auto py-2" role="log" aria-live="polite" aria-label="Messages">
        {!msgs ? <Spinner label="Loading messages…" /> : (
          <>
            {hasMore ? <div className="p-2 text-center"><button className="btn-ghost text-xs" onClick={() => loadMessages(kind, id, true)}>Load older messages</button></div>
              : <div className="px-4 pb-4 pt-8"><h2 className="text-2xl font-bold">{kind === 'channel' ? `Welcome to #${title}` : `This is the start of your conversation with ${title}`}</h2>{topic && <p className="text-mute">{topic}</p>}</div>}
            {msgs.length === 0 && <Empty title="No messages yet" hint="Be the first to say something." />}
            {rows.map(({ m, grouped }) => {
              const mine = m.author?.id === me?.id;
              const tmp = m.id.startsWith('tmp-');
              const isEditing = editing?.id === m.id;
              return (
                <div key={m.id} className={`group relative flex gap-3 px-4 hover:bg-panel/30 ${compact ? 'py-0.5' : grouped ? 'py-0.5' : 'mt-3 py-1'} ${m.pending ? 'opacity-60' : ''}`}>
                  <div className="w-10 shrink-0">
                    {!grouped ? <button onClick={() => m.author && openModal({ type: 'profile', userId: m.author.id })} aria-label={`Profile of ${m.author?.displayName ?? 'deleted user'}`}><Avatar user={m.author} size={40} /></button>
                      : <span className="hidden pt-1 text-[10px] text-mute group-hover:block">{new Date(m.createdAt).toLocaleTimeString([], { timeStyle: 'short' })}</span>}
                  </div>
                  <div className="min-w-0 flex-1">
                    {!grouped && <p className="flex items-baseline gap-2"><span className="font-semibold">{m.author?.displayName ?? 'Deleted user'}</span><time className="text-xs text-mute" dateTime={m.createdAt}>{fmt(m.createdAt)}</time></p>}
                    {isEditing ? (
                      <div>
                        <textarea autoFocus className="input" rows={2} maxLength={2000} value={editing.draft} onChange={(e) => setEditing({ id: m.id, draft: e.target.value })} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); saveEdit(); } if (e.key === 'Escape') setEditing(null); }} />
                        <p className="mt-1 text-xs text-mute">Enter to save · Esc to cancel</p>
                      </div>
                    ) : (
                      <p className="whitespace-pre-wrap break-words text-[15px] leading-relaxed">{m.content}{m.editedAt && <span className="ml-1 text-[10px] text-mute">(edited)</span>}</p>
                    )}
                    {m.failed && <p className="mt-1 flex items-center gap-2 text-xs text-rose-400"><AlertCircle size={14} /> Failed to send.
                      <button className="underline" onClick={() => send(kind, id, m.content, m.clientId ?? undefined)}>Retry</button>
                      <button className="underline" onClick={() => st.removeMessage(key, m.id)}>Remove</button></p>}
                    {!!m.reactions?.length && (
                      <div className="mt-1 flex flex-wrap gap-1">
                        {m.reactions.map((r) => {
                          const on = r.userIds.includes(me!.id);
                          return <button key={r.emoji} onClick={() => react(m, r.emoji)} aria-pressed={on} className={`rounded-full border px-2 py-0.5 text-xs ${on ? 'border-accent bg-accent/20' : 'border-line bg-panel hover:border-mute'}`}>{r.emoji} {r.userIds.length}</button>;
                        })}
                      </div>
                    )}
                  </div>
                  {!tmp && !isEditing && (
                    <div className="absolute -top-3 right-4 hidden items-center rounded-lg border border-line bg-bg2 p-0.5 shadow group-focus-within:flex group-hover:flex">
                      {kind === 'channel' && <button className="icon-btn h-7 w-7" aria-label="Add reaction" onClick={() => setPicker(picker === m.id ? null : m.id)}><SmilePlus size={15} /></button>}
                      {kind === 'channel' && mine && <button className="icon-btn h-7 w-7" aria-label="Edit message" onClick={() => setEditing({ id: m.id, draft: m.content })}><Pencil size={15} /></button>}
                      {kind === 'channel' && (mine || canModerate) && <button className="icon-btn h-7 w-7 hover:text-rose-400" aria-label="Delete message" onClick={() => del(m)}><Trash2 size={15} /></button>}
                    </div>
                  )}
                  {picker === m.id && <div className="absolute -top-12 right-4 z-10 flex animate-pop gap-1 rounded-xl border border-line bg-bg2 p-1.5 shadow-xl">{QUICK.map((e) => <button key={e} className="rounded-lg px-1.5 py-1 text-lg hover:bg-line" onClick={() => react(m, e)}>{e}</button>)}</div>}
                </div>
              );
            })}
          </>
        )}
        {!atBottom && <button aria-label="Jump to latest" onClick={() => scroller.current && (scroller.current.scrollTop = scroller.current.scrollHeight)} className="sticky bottom-2 left-full mr-4 grid h-9 w-9 place-items-center rounded-full bg-accent shadow-lg"><ArrowDown size={18} /></button>}
      </div>

      <div className="shrink-0 px-3 pb-3 pt-1 [padding-bottom:max(0.75rem,env(safe-area-inset-bottom))]">
        <div className="flex items-end gap-2 rounded-xl border border-line bg-panel px-3 py-2 focus-within:border-accent">
          <textarea aria-label="Message" rows={1} maxLength={2000} value={text} onChange={(e) => setText(e.target.value)} placeholder={kind === 'channel' ? `Message #${title}` : `Message @${title}`}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); submit(); } }}
            className="max-h-40 min-h-[1.5rem] flex-1 resize-none bg-transparent text-[15px] outline-none placeholder:text-mute/60" style={{ fieldSizing: 'content' } as any} />
          <button className="btn-primary h-8 w-8 !p-0" aria-label="Send message" disabled={!text.trim()} onClick={submit}><Send size={16} /></button>
        </div>
      </div>
    </>
  );
}
