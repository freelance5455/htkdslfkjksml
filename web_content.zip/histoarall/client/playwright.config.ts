import { defineConfig } from '@playwright/test';
export default defineConfig({
  testDir: 'e2e',
  use: { baseURL: 'http://localhost:5173' },
  // Requires Postgres up, migrated and seeded; starts API + client.
  webServer: [
    { command: 'npm run dev -w server', url: 'http://localhost:4000/api/health', reuseExistingServer: true, cwd: '..' },
    { command: 'npm run dev -w client', url: 'http://localhost:5173', reuseExistingServer: true, cwd: '..' },
  ],
});
