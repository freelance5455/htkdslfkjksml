import { expect, test } from '@playwright/test';

test('register, create a server, send a message that survives refresh', async ({ page }) => {
  const u = `e2e${Date.now() % 1e8}`;
  await page.goto('/register');
  await page.getByLabel('Email').fill(`${u}@histoarall.test`);
  await page.getByLabel('Username').fill(u);
  await page.getByLabel('Password').fill('E2ePassword123!');
  await page.getByRole('button', { name: /create account/i }).click();
  await page.getByRole('button', { name: 'Create a server' }).click();
  await page.getByLabel('Server name').fill('E2E Server');
  await page.getByRole('button', { name: 'Create', exact: true }).click();
  await expect(page.getByText('#general').first()).toBeVisible();
  await page.getByPlaceholder(/message #general/i).fill('hello from playwright');
  await page.keyboard.press('Enter');
  await expect(page.getByText('hello from playwright')).toBeVisible();
  await page.reload();
  await expect(page.getByText('hello from playwright')).toBeVisible();
});

test('login with demo account and logout', async ({ page }) => {
  await page.goto('/login');
  await page.getByLabel('Email or username').fill('alice');
  await page.getByLabel('Password').fill('DemoPass123!');
  await page.getByRole('button', { name: /log in/i }).click();
  await expect(page.getByRole('button', { name: 'Create a server' })).toBeVisible();
});
