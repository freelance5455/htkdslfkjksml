# Phone-Only Setup

## What the app does

The APK contains the strategy/risk calculator locally. It can:
- calculate EMA trend direction from supplied EMA20/EMA50 values
- evaluate RSI
- calculate an estimated risk amount
- estimate lot size from stop-loss distance
- calculate SL/TP levels
- keep a local trade journal
- open the official Exness trading page/app for manual execution

## What it does not do

It cannot run an MT5 `.mq5` EA on Android. It also does not silently log in to Exness with your trading password or place broker orders through an undocumented interface.

## Example

Balance: 1000 USD
Risk: 0.25%
Price: 2650.00
SL distance: 5.00
TP distance: 10.00

The app calculates the maximum risk amount and an estimated lot size using the configured XAUUSD contract-size assumption. Always verify the actual symbol contract specifications in your Exness account before placing an order.

## Safety

Use demo first. Never paste your Exness/MT5 master password into this app.
