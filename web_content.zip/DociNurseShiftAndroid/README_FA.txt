DociNurse Shift - Android wrapper project

این پروژه، نسخه HTML آفلاین DociNurse Shift را داخل یک اپلیکیشن Android WebView اجرا می‌کند.

شناسه برنامه: ir.docinurse.shift
نسخه: 1.0.0
حداقل اندروید: Android 6.0 (API 23)

برای ساخت APK به Android SDK و Gradle نیاز است. در این محیط ابزارهای Flutter/Android SDK/Gradle نصب نیستند؛ بنابراین APK در اینجا کامپایل نشده است.

روش ساخت در محیط دارای Android SDK:
1) این پوشه را در Android Studio باز کنید.
2) اجازه دهید Gradle Sync انجام شود.
3) از منوی Build > Build Bundle(s) / APK(s) > Build APK(s) را انتخاب کنید.
4) فایل خروجی معمولاً در app/build/outputs/apk/debug/app-debug.apk قرار می‌گیرد.
