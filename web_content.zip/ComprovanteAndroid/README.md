# Gerador de Comprovante — projeto Android

Este projeto abre o HTML do gerador de comprovante dentro de um aplicativo Android (WebView), mantendo os campos e botões existentes.

## Como gerar o APK
1. Em um computador, instale o **Android Studio**.
2. Extraia o ZIP e abra a pasta `ComprovanteAndroid` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. No menu **Build > Build APK(s)**, gere o APK de teste.
5. O APK normalmente ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Recursos
- Mantém o formulário e o layout do HTML original.
- Imprimir abre o diálogo de impressão do Android.
- Salvar PDF grava o arquivo em Downloads.
- Salvar imagem grava o PNG em Imagens/Comprovantes.
- O HTML carrega as bibliotecas html2canvas e jsPDF por CDN; portanto, a primeira utilização desses recursos requer internet.

## Requisitos
- Android 10 (API 29) ou superior.

## Observações
- Este ZIP contém o projeto-fonte para abrir e compilar no Android Studio, não um APK já compilado.
- A impressão depende do serviço de impressão Android e da impressora compatível configurada no aparelho.
