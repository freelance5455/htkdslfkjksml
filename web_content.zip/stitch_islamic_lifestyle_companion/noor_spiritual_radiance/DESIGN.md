---
name: Noor Spiritual Radiance
colors:
  surface: '#f8faf8'
  surface-dim: '#d8dad9'
  surface-bright: '#f8faf8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f2'
  surface-container: '#eceeec'
  surface-container-high: '#e6e9e7'
  surface-container-highest: '#e1e3e1'
  on-surface: '#191c1b'
  on-surface-variant: '#404846'
  inverse-surface: '#2e3130'
  inverse-on-surface: '#eff1ef'
  outline: '#717976'
  outline-variant: '#c0c8c5'
  surface-tint: '#3b665d'
  primary: '#002721'
  on-primary: '#ffffff'
  primary-container: '#0f3e36'
  on-primary-container: '#7ca99e'
  inverse-primary: '#a2d0c4'
  secondary: '#904d00'
  on-secondary: '#ffffff'
  secondary-container: '#fe932c'
  on-secondary-container: '#663500'
  tertiary: '#002810'
  on-tertiary: '#ffffff'
  tertiary-container: '#00401e'
  on-tertiary-container: '#70ad7f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bdece0'
  primary-fixed-dim: '#a2d0c4'
  on-primary-fixed: '#00201b'
  on-primary-fixed-variant: '#224e46'
  secondary-fixed: '#ffdcc3'
  secondary-fixed-dim: '#ffb77d'
  on-secondary-fixed: '#2f1500'
  on-secondary-fixed-variant: '#6e3900'
  tertiary-fixed: '#b1f2be'
  tertiary-fixed-dim: '#96d5a3'
  on-tertiary-fixed: '#00210d'
  on-tertiary-fixed-variant: '#12512c'
  background: '#f8faf8'
  on-background: '#191c1b'
  surface-variant: '#e1e3e1'
typography:
  headline-xl:
    fontFamily: Noto Serif
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Noto Serif
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Noto Serif
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Noto Serif
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  arabic-verse:
    fontFamily: Noto Serif
    fontSize: 24px
    fontWeight: '400'
    lineHeight: 48px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  margin: 1.25rem
  margin-sm: 1rem
  margin-lg: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system embodies serene spiritual elevation, contemplative tranquility, and modern Islamic craftsmanship. Designed for daily spiritual companionship—accommodating Quranic recitation, prayer chronometry, and reflective supplication—it serves a bilingual and multicultural audience navigating Bangla, English, and Arabic script systems.

The aesthetic philosophy synthesizes **Minimalist Sacred Geometry** with **Tactile Heritage Refinement**:
- **Sacred Harmony**: Layouts balance ample pristine negative space with intricate, ultra-low-opacity micro-motifs derived from classical octagrams (*Rub el Hizb*) and arched prayer niches (*Mihrab* contours).
- **Luminous Warmth**: Deep emerald depths anchor the composition, illuminated by delicate gold-leaf hairline accents and soft cream backdrops that eliminate harsh glare during pre-dawn (*Fajr*) and late-night (*Tahajjud*) usage.
- **Organic Softness**: Expansive card radii (16px to 24px) emulate polished jade, soft parchment, and honed marble, creating an approachable, protective tactile presence.

## Colors

The palette grounds the interface in timeless botanical tones balanced by warm celestial radiance:

- **Primary (`#0F3E36` - Midnight Emerald)**: The primary anchor for top navigation app bars, key call-to-action blocks, and prominent headers. Evokes depth, endurance, and traditional Islamic architecture.
- **Secondary (`#D97706` - Radiant Gold)**: Accent tone for prayer indicators, audio progress trackers, active states, active tab markers, and decorative hairline borders.
- **Tertiary (`#14532D` - Forest Sanctuary)**: Paired with Primary for lush tonal gradients on prayer countdown banners and Quran reading chapter cards.
- **Neutral (`#F8FAF8` - Pristine Ivory/Cream)**: Soft canvas tone replacing stark stark whites to protect the eyes during focused reading. Secondary surface containers use `#F3F4F6` or warm cream highlights (`#FEF3C7` at low opacities).
- **Semantic Accents**: Gold highlight surfaces leverage `#FEF3C7` (Amber Frost) for active card washes, while dark-mode or elevated overlays rely on deep translucent emeralds (`rgba(15, 62, 54, 0.04)` to `rgba(15, 62, 54, 0.08)`).

## Typography

The typographical pairing respects editorial grandeur alongside crystalline utility:

- **Display & Headings (`Noto Serif`)**: Brings high-contrast classical poise to Surah titles, daily Hadith verses, and prominent section banners. Seamlessly complements traditional Bengali serifs and graceful Arabic Nastaliq/Naskh proportion scales.
- **UI & Continuous Reading (`Plus Jakarta Sans`)**: Delivers friendly, modern, open-counter legibility across compact mobile screens, navigation labels, timestamps, and transliterated guides.
- **Script Handling**: Arabic scripture utilizes relaxed line heights (`line-height: 2.0` or greater) to allow uninhibited display of complex diacritics (*Tashkeel*) and pause marks without clipping.
- **Multilingual Support**: Primary layouts provide automatic typographic rhythm shifts when toggling between Bangla script and Latin characters, maintaining identical vertical baseline cadence.

## Layout & Spacing

A strict 4px/8px modular spacing rhythm underpins the fluid mobile experience:

- **Grid Architecture**: 4-column fluid layout on mobile viewports (< 600px) with 16px (`gutter`) gutters and 20px (`margin`) outer screen margins, expanding to 8-column layout on tablets with 24px margins.
- **Vertical Breathing Space**: Content sections maintain an unhurried, meditative cadence. Major functional clusters (e.g., Today's Prayer Times vs. Quranic Reflection) are isolated using `space-xl` (32px) margins to avoid visual noise and cognitive burden.
- **RTL & LTR Adaptation**: Layouts are fully symmetrical, enabling bidirectional flipping for fluid transitions between Arabic, Bengali, and English contexts.

## Elevation & Depth

Visual hierarchy uses luminous depth instead of heavy dropshadows, ensuring an airy, sacred ambiance:

- **Tonal Layering**: Deep-surface containers emerge via tinted ivory surfaces (`#FFFFFF` resting over `#F8FAF8`), establishing hierarchy via color purity rather than contrast harshness.
- **Ambient Gold/Emerald Tinted Diffusion**: Elevated floating surfaces (such as the Next Prayer Countdown card) employ ultra-soft, diffused multi-stop shadows:
  - Ambient: `0 12px 32px -4px rgba(15, 62, 54, 0.08)`
  - Direct: `0 4px 12px -2px rgba(217, 119, 6, 0.06)`
- **Hairline Luminous Borders**: Cards and floating controls feature a 1px solid or gradient border: `rgba(217, 119, 6, 0.2)` transitioning to `rgba(15, 62, 54, 0.08)`. This creates a subtle gold-leaf edge reminiscent of hand-bound sacred manuscripts.
- **Islamic Arabesque Backdrop**: Specialized hero containers incorporate faint SVG geometric watermarks (*Rub el Hizb* 8-point stars) set to 3–5% opacity in gold or pure white against rich emerald backgrounds.

## Shapes

The design system employs a soft, comforting curvature that balances modern mobile ergonomics with smooth architectural arches:

- **Base Cards & Modules**: Utilize 16px to 24px (`rounded-lg` to `rounded-xl`) corner radii, generating a smooth, pebble-like tactile quality in hand.
- **Hero Containers**: Top prayer dashboards and daily verse highlights use 24px corner radii, occasionally paired with a gentle upward arch contour along the bottom boundary.
- **Interactive Controls**: Buttons and search bars implement full capsule pill geometries (9999px / `rounded-full`) or standardized 16px rounded corners.
- **Ornamental Frames**: Selected prayer timing progress circles and tasbih counters incorporate geometric 8-sided poly-star shapes alongside soft circular forms.

## Components

### Buttons
- **Primary**: Deep emerald (`#0F3E36`) background with pure white typography and a subtle 1px border of `rgba(245, 158, 11, 0.3)`. Border-radius is 16px or full pill shape. Active state incorporates a faint golden glow.
- **Secondary / Gold Outline**: Transparent or ivory backdrop with a 1.5px border of `#D97706` and text in `#0F3E36`.
- **Prayer Action (Quick Du'a / Audio Play)**: Circular pill buttons with emerald fill and warm amber iconography (`#F59E0B`).

### Cards & Arabesque Surfaces
- **Daily Dashboard Card**: Deep emerald gradient background (from `#0F3E36` down to `#14532D`), bounded by a delicate 1px border in `rgba(245, 158, 11, 0.25)`. A faint, geometric Islamic tile pattern is watermarked in the upper-right corner.
- **Standard Content Cards (Surah List, Daily Reflection)**: Crisp white (`#FFFFFF`) surface set against the ivory canvas (`#F8FAF8`), featuring 20px rounded corners and a soft 1px border in `rgba(15, 62, 54, 0.06)`.

### Navigation Tabs
- **Bottom Navigation Bar**: Floating dock or docked bar in `#FFFFFF` with a top 1px hairline border in `rgba(217, 119, 6, 0.2)`. 
- **Active Tab**: Marked by an amber-gold icon (`#D97706`), accompanied by a miniature golden indicator dot and an emerald pill backdrop tint (`rgba(15, 62, 54, 0.05)`).
- **Labels**: Rendered in `label-sm` font weight with high legibility across English and Bangla.

### Chips & Filter Tags
- **Filter Tags (e.g., Makki / Madani Surahs, Topics)**: 12px pill shapes. Default: `#F3F4F6` background with `#0F3E36` text. Active: `#FEF3C7` (Soft Amber) fill, `#D97706` text, and a crisp 1px border in `rgba(217, 119, 6, 0.4)`.

### Form Fields & Search
- **Search Bar (Surah & Verse Finder)**: 16px radius, background in `#FFFFFF`, with 1px border in `rgba(15, 62, 54, 0.12)`. Focus state reveals a warm gold outline (`#D97706`) with an emerald placeholder. Supports instant bilingual input (Bangla/English).

### Prayer Time Strip & Tasbih Counter
- **Prayer Time Item**: Vertical pill container showing prayer name, time, and status. The active prayer slot highlights in full emerald (`#0F3E36`) with glowing amber typography (`#F59E0B`).
- **Digital Tasbih Component**: Centered circular tactile counter with layered concentric emerald rings, decorated with faint ornamental star tick-marks and haptic feedback triggers.