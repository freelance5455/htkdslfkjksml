#!/usr/bin/env node
/* CodeX Studio build server.
 * Receives a web bundle (app.json + www/** + icons/*.png) as a ZIP, generates the Android project
 * itself (client-supplied Gradle/Java is never used), runs a REAL Gradle build, streams the log and
 * progress to the browser, and serves the resulting APK. No npm dependencies.
 *
 *   node server/server.js
 *   env: PORT=8787 HOST=127.0.0.1 BUILD_TOKEN=secret CORS_ORIGIN=https://my.site
 *        GRADLE_BIN=gradle ANDROID_HOME=/path/to/sdk MAX_BUNDLE_MB=100 BUILD_TIMEOUT_MIN=20 SERVE_APP=1
 */
'use strict';
const http = require('http');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const os = require('os');
const zlib = require('zlib');
const crypto = require('crypto');
const { spawn } = require('child_process');
const ApkGen = require('../apkgen.js');

const CFG = {
  port: +process.env.PORT || 8787,
  host: process.env.HOST || '127.0.0.1',
  token: process.env.BUILD_TOKEN || '',
  cors: process.env.CORS_ORIGIN || '',
  gradle: process.env.GRADLE_BIN || 'gradle',
  sdk: process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT || '',
  maxBundle: (+process.env.MAX_BUNDLE_MB || 100) * 1024 * 1024,
  timeoutMs: (+process.env.BUILD_TIMEOUT_MIN || 20) * 60 * 1000,
  serveApp: process.env.SERVE_APP !== '0',
  jobsDir: process.env.JOBS_DIR || path.join(os.tmpdir(), 'codex-apk-jobs'),
  appDir: path.join(__dirname, '..'),
  maxEntries: 6000
};

class UserError extends Error { constructor(msg, status = 400) { super(msg); this.status = status; } }

/* ───────────── safe ZIP reader (stored + deflate, no ZIP64, no encryption) ───────────── */
function listZip(buf, limits) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 22 - 65535); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new UserError('The upload is not a valid ZIP file');
  const count = buf.readUInt16LE(eocd + 10), cdOff = buf.readUInt32LE(eocd + 16);
  if (count === 0xffff || cdOff === 0xffffffff) throw new UserError('ZIP64 archives are not supported');
  if (count > limits.maxEntries) throw new UserError(`Too many files in the bundle (limit ${limits.maxEntries})`);
  const out = []; let p = cdOff, total = 0;
  for (let i = 0; i < count; i++) {
    if (p + 46 > buf.length || buf.readUInt32LE(p) !== 0x02014b50) throw new UserError('The ZIP file is damaged (bad directory)');
    const flags = buf.readUInt16LE(p + 8), method = buf.readUInt16LE(p + 10);
    const csize = buf.readUInt32LE(p + 20), usize = buf.readUInt32LE(p + 24);
    const nlen = buf.readUInt16LE(p + 28), elen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32), lho = buf.readUInt32LE(p + 42);
    const name = buf.toString('utf8', p + 46, p + 46 + nlen);
    p += 46 + nlen + elen + clen;
    if (name.endsWith('/')) continue;
    if (flags & 1) throw new UserError('Encrypted ZIP files are not supported');
    total += usize;
    if (total > limits.maxTotal) throw new UserError('The bundle is too large once unpacked');
    out.push({ name, method, csize, usize, lho });
  }
  return out;
}
function readZipEntry(buf, e) {
  const l = e.lho;
  if (l + 30 > buf.length || buf.readUInt32LE(l) !== 0x04034b50) throw new UserError('The ZIP file is damaged (bad entry)');
  const start = l + 30 + buf.readUInt16LE(l + 26) + buf.readUInt16LE(l + 28);
  if (start + e.csize > buf.length) throw new UserError('The ZIP file is damaged (truncated)');
  const raw = buf.subarray(start, start + e.csize);
  let data;
  if (e.method === 0) data = raw;
  else if (e.method === 8) { try { data = zlib.inflateRawSync(raw, { maxOutputLength: e.usize + 1 }); } catch { throw new UserError(`Could not unpack ${e.name}`); } }
  else throw new UserError(`Unsupported compression in ${e.name}`);
  if (data.length !== e.usize) throw new UserError(`${e.name} does not match its recorded size`);
  return data;
}

/* ───────────── toolchain detection ───────────── */
function run(cmd, args, timeout = 20000) {
  return new Promise(resolve => {
    let out = '', done = false;
    let ch;
    try { ch = spawn(cmd, args, { env: { ...process.env, ...(CFG.sdk ? { ANDROID_HOME: CFG.sdk } : {}) } }); } catch (e) { return resolve({ ok: false, out: String(e.message) }); }
    const fin = r => { if (!done) { done = true; clearTimeout(t); resolve(r); } };
    const t = setTimeout(() => { try { ch.kill('SIGKILL'); } catch { /* gone */ } fin({ ok: false, out: out + 'timeout' }); }, timeout);
    ch.stdout.on('data', d => { out += d; }); ch.stderr.on('data', d => { out += d; });
    ch.on('error', e => fin({ ok: false, out: e.code === 'ENOENT' ? 'not found' : String(e.message) }));
    ch.on('close', code => fin({ ok: code === 0, out }));
  });
}
let tcCache = { t: 0, v: null };
async function toolchain(force) {
  if (!force && tcCache.v && Date.now() - tcCache.t < 30000) return tcCache.v;
  const javaBin = process.env.JAVA_HOME ? path.join(process.env.JAVA_HOME, 'bin', 'java') : 'java';
  const j = await run(javaBin, ['-version']);
  const jm = /version "(\d+)(?:\.(\d+))?/.exec(j.out);
  const javaMajor = jm ? (jm[1] === '1' ? +jm[2] : +jm[1]) : 0;
  const g = await run(CFG.gradle, ['--version']);
  const gv = /Gradle (\d+\.\d+(?:\.\d+)?)/.exec(g.out);
  let sdkOk = false;
  if (CFG.sdk) { try { sdkOk = (await fsp.stat(CFG.sdk)).isDirectory(); } catch { sdkOk = false; } }
  const problems = [];
  if (!j.ok || !javaMajor) problems.push('Java (JDK 17 or newer) was not found');
  else if (javaMajor < 17) problems.push(`Java ${javaMajor} is too old; JDK 17 or newer is required`);
  if (!g.ok) problems.push(`Gradle was not found (tried "${CFG.gradle}"). Install Gradle ${ApkGen.GRADLE} or newer`);
  if (!CFG.sdk) problems.push('ANDROID_HOME is not set. Point it at your Android SDK folder');
  else if (!sdkOk) problems.push(`ANDROID_HOME points to a folder that does not exist: ${CFG.sdk}`);
  const v = { ready: !problems.length, problems, java: j.ok ? javaMajor : null, gradle: g.ok && gv ? gv[1] : null, androidSdk: sdkOk ? CFG.sdk : null };
  tcCache = { t: Date.now(), v };
  return v;
}

/* ───────────── jobs ───────────── */
const jobs = new Map();
let activeJob = null;
const emit = (job, event, data) => {
  const msg = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  job.clients.forEach(res => { try { res.write(msg); } catch { /* client gone */ } });
};
function setStage(job, stage, progress) {
  progress = Math.max(job.progress, progress);
  job.stage = stage; job.progress = progress;
  emit(job, 'stage', { stage, progress });
}
function log(job, line) {
  if (job.logs.length < 6000) job.logs.push(line);
  emit(job, 'log', { line });
}
function finish(job, state, extra) {
  job.state = state; Object.assign(job, extra || {});
  if (activeJob === job) activeJob = null;
  if (state === 'done') { job.progress = 100; emit(job, 'done', { apk: job.apk, progress: 100 }); }
  else emit(job, state === 'cancelled' ? 'cancelled' : 'error', { message: job.error || 'Build cancelled', problems: job.problems || [] });
  job.clients.forEach(res => { try { res.end(); } catch { /* ignore */ } });
  job.clients.clear();
}
const TASK_PROGRESS = [
  ['preBuild', 20], ['generateDebugResValues', 24], ['mergeDebugResources', 32], ['processDebugManifest', 38],
  ['mergeDebugAssets', 46], ['processDebugResources', 52], ['compileDebugJavaWithJavac', 62], ['dexBuilderDebug', 72],
  ['mergeDebugJavaResource', 78], ['packageDebug', 88], ['assembleDebug', 94]
];

async function prepareBundle(buf) {
  const entries = listZip(buf, { maxEntries: CFG.maxEntries, maxTotal: CFG.maxBundle });
  const byName = new Map();
  entries.forEach(e => byName.set(e.name.replace(/\\/g, '/'), e));
  const appJson = byName.get('app.json');
  if (!appJson) throw new UserError('The bundle is missing app.json');
  let raw;
  try { raw = JSON.parse(readZipEntry(buf, appJson).toString('utf8')); } catch (e) { if (e instanceof UserError) throw e; throw new UserError('app.json is not valid JSON'); }
  const www = [];
  for (const [name, e] of byName) {
    if (!name.startsWith('www/')) continue;
    const rel = ApkGen.safeRelPath(name.slice(4));
    if (!rel) throw new UserError(`Unsafe file path in bundle: ${name}`);
    www.push({ path: rel, data: readZipEntry(buf, e) });
  }
  if (!www.length) throw new UserError('The bundle contains no website files');
  const v = ApkGen.validateSettings(raw, www.map(f => f.path));
  if (!v.ok) throw new UserError('Invalid settings: ' + Object.values(v.errors).join('; '));
  const icons = {};
  for (const d of Object.keys(ApkGen.ICON_SIZES)) {
    const e = byName.get(`icons/${d}.png`);
    if (!e) throw new UserError(`The bundle is missing the ${d} launcher icon`);
    const data = readZipEntry(buf, e);
    if (data.length > 1024 * 1024 || data.length < 8 || data.readUInt32BE(0) !== 0x89504e47) throw new UserError(`The ${d} launcher icon is not a valid PNG`);
    icons[d] = data;
  }
  return { clean: v.clean, www, icons };
}

async function writeProject(dir, files) {
  const root = path.resolve(dir);
  for (const f of files) {
    const target = path.resolve(root, f.path);
    if (target !== root && !target.startsWith(root + path.sep)) throw new Error('Refusing to write outside the project: ' + f.path);
    await fsp.mkdir(path.dirname(target), { recursive: true });
    await fsp.writeFile(target, f.data);
  }
}

async function verifyApk(file, entry) {
  const buf = await fsp.readFile(file);
  if (buf.length < 1000 || buf.readUInt32LE(0) !== 0x04034b50) throw new Error('Gradle finished but the output is not a valid APK file');
  const names = listZip(buf, { maxEntries: 200000, maxTotal: 4e9 }).map(e => e.name);
  const need = ['AndroidManifest.xml', 'classes.dex', 'assets/www/' + entry];
  const missing = need.filter(n => !names.includes(n));
  if (missing.length) throw new Error('The APK is missing expected content: ' + missing.join(', '));
  return { size: buf.length, sha256: crypto.createHash('sha256').update(buf).digest('hex') };
}

async function runJob(job, bundle) {
  const { clean, www, icons } = bundle;
  try {
    setStage(job, 'Checking build tools', 4);
    const tc = await toolchain(true);
    if (!tc.ready) {
      log(job, 'Build tools check failed:'); tc.problems.forEach(p => log(job, ' - ' + p));
      return finish(job, 'error', { error: 'This build server is missing required tools. ' + tc.problems.join('. ') + '.', problems: tc.problems });
    }
    log(job, `Java ${tc.java}, Gradle ${tc.gradle}, Android SDK ${tc.androidSdk}`);
    setStage(job, 'Generating Android project', 10);
    const dir = path.join(job.dir, 'project');
    await writeProject(dir, ApkGen.generateProject(clean, www, icons));
    await fsp.writeFile(path.join(dir, 'local.properties'), 'sdk.dir=' + CFG.sdk.replace(/\\/g, '\\\\') + '\n');
    log(job, `Project written: ${www.length} web file(s), package ${clean.packageId}`);

    setStage(job, 'Running Gradle (first build downloads dependencies and can take several minutes)', 15);
    const env = { ...process.env, ANDROID_HOME: CFG.sdk, ANDROID_SDK_ROOT: CFG.sdk };
    const child = spawn(CFG.gradle, ['assembleDebug', '--no-daemon', '--console=plain'], { cwd: dir, env, detached: true });
    job.child = child;
    const timer = setTimeout(() => { job.timedOut = true; killTree(child); }, CFG.timeoutMs);
    let carry = '';
    const onData = chunk => {
      carry += chunk.toString('utf8');
      const lines = carry.split(/\r?\n/); carry = lines.pop();
      lines.forEach(line => {
        log(job, line);
        const m = /^> Task :app:(\w+)/.exec(line);
        if (m) { const hit = TASK_PROGRESS.find(([k]) => m[1].includes(k)); if (hit) setStage(job, 'Running Gradle: ' + m[1], hit[1]); }
        else if (/^BUILD SUCCESSFUL/.test(line)) setStage(job, 'Gradle finished', 96);
      });
    };
    child.stdout.on('data', onData); child.stderr.on('data', onData);
    const code = await new Promise(res => { child.on('error', e => { log(job, 'Could not start Gradle: ' + e.message); res(-1); }); child.on('close', c => res(c)); });
    clearTimeout(timer);
    if (carry) log(job, carry);
    if (job.cancelled) return finish(job, 'cancelled');
    if (job.timedOut) return finish(job, 'error', { error: `The build was stopped after ${Math.round(CFG.timeoutMs / 60000)} minutes.` });
    if (code !== 0) {
      const hint = job.logs.filter(l => /error|FAILED|What went wrong|Could not|not found/i.test(l)).slice(-4).join(' | ');
      return finish(job, 'error', { error: `Gradle failed (exit code ${code}).` + (hint ? ' ' + hint : '') });
    }
    setStage(job, 'Verifying APK', 97);
    const apkPath = path.join(dir, 'app', 'build', 'outputs', 'apk', 'debug', 'app-debug.apk');
    const meta = await verifyApk(apkPath, clean.entry);
    job.apkPath = apkPath;
    const name = `${ApkGen.slug(clean.appName)}-${clean.versionName}.apk`;
    log(job, `APK verified: ${name} (${meta.size} bytes, sha256 ${meta.sha256.slice(0, 16)}...)`);
    finish(job, 'done', { apk: { name, size: meta.size, sha256: meta.sha256 } });
  } catch (e) {
    log(job, 'Build error: ' + (e && e.message || e));
    if (job.state === 'running') finish(job, 'error', { error: e && e.message || String(e) });
  }
}
function killTree(child) { try { process.kill(-child.pid, 'SIGTERM'); } catch { try { child.kill('SIGTERM'); } catch { /* gone */ } } }

setInterval(() => {
  const now = Date.now();
  for (const [id, j] of jobs) if (j.state !== 'running' && now - j.created > 60 * 60 * 1000) { jobs.delete(id); fsp.rm(j.dir, { recursive: true, force: true }).catch(() => {}); }
}, 5 * 60 * 1000).unref();

/* ───────────── HTTP ───────────── */
const json = (res, status, obj) => { const b = JSON.stringify(obj); res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(b); };
function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const declared = +req.headers['content-length'] || 0;
    if (declared > limit) { req.resume(); return reject(new UserError('The bundle is too large for this server', 413)); }
    const chunks = []; let n = 0;
    req.on('data', c => { n += c.length; if (n > limit) { reject(new UserError('The bundle is too large for this server', 413)); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}
const authed = req => !CFG.token || (() => {
  const h = req.headers.authorization || '';
  const a = Buffer.from(h), b = Buffer.from('Bearer ' + CFG.token);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
})();

const STATIC = /^\/(index\.html|app\.js|apkgen\.js|apk\.js|sw\.js|manifest\.webmanifest|icon[\w.-]*\.(?:png|svg))$/;
const TYPES = { html: 'text/html; charset=utf-8', js: 'text/javascript; charset=utf-8', webmanifest: 'application/manifest+json', png: 'image/png', svg: 'image/svg+xml' };

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const p = url.pathname;
  if (CFG.cors) {
    res.setHeader('Access-Control-Allow-Origin', CFG.cors);
    res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition');
    if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  }
  try {
    if (p === '/api/health' && req.method === 'GET') {
      const tc = await toolchain(url.searchParams.has('fresh'));
      return json(res, 200, { ok: true, service: 'codex-apk-builder', authRequired: !!CFG.token, busy: !!activeJob, maxBundleMB: Math.round(CFG.maxBundle / 1048576), agp: ApkGen.AGP, gradleMin: ApkGen.GRADLE, ...tc });
    }
    if (p.startsWith('/api/')) {
      if (!authed(req)) return json(res, 401, { error: 'Access token required or incorrect' });
      if (p === '/api/build' && req.method === 'POST') {
        if (activeJob) throw new UserError('Another build is running on this server. Try again when it finishes.', 429);
        const buf = await readBody(req, CFG.maxBundle);
        const bundle = await prepareBundle(buf);
        const id = crypto.randomBytes(9).toString('hex');
        const job = { id, state: 'running', stage: 'Queued', progress: 1, logs: [], clients: new Set(), created: Date.now(), dir: path.join(CFG.jobsDir, id), cancelled: false };
        await fsp.mkdir(job.dir, { recursive: true });
        jobs.set(id, job); activeJob = job;
        runJob(job, bundle);
        return json(res, 202, { jobId: id });
      }
      let m;
      if ((m = /^\/api\/build\/([a-f0-9]+)\/events$/.exec(p)) && req.method === 'GET') {
        const job = jobs.get(m[1]); if (!job) throw new UserError('Unknown build', 404);
        res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
        res.write(`event: stage\ndata: ${JSON.stringify({ stage: job.stage, progress: job.progress })}\n\n`);
        job.logs.forEach(line => res.write(`event: log\ndata: ${JSON.stringify({ line })}\n\n`));
        if (job.state === 'done') { res.write(`event: done\ndata: ${JSON.stringify({ apk: job.apk, progress: 100 })}\n\n`); return res.end(); }
        if (job.state !== 'running') { res.write(`event: ${job.state === 'cancelled' ? 'cancelled' : 'error'}\ndata: ${JSON.stringify({ message: job.error || 'Build cancelled', problems: job.problems || [] })}\n\n`); return res.end(); }
        job.clients.add(res);
        const hb = setInterval(() => { try { res.write(': keep-alive\n\n'); } catch { /* closed */ } }, 15000);
        req.on('close', () => { clearInterval(hb); job.clients.delete(res); });
        return;
      }
      if ((m = /^\/api\/build\/([a-f0-9]+)\/apk$/.exec(p)) && req.method === 'GET') {
        const job = jobs.get(m[1]);
        if (!job || job.state !== 'done') throw new UserError('No finished APK for this build', 404);
        res.writeHead(200, { 'Content-Type': 'application/vnd.android.package-archive', 'Content-Length': job.apk.size, 'Content-Disposition': `attachment; filename="${job.apk.name}"`, 'Cache-Control': 'no-store' });
        return fs.createReadStream(job.apkPath).pipe(res);
      }
      if ((m = /^\/api\/build\/([a-f0-9]+)\/cancel$/.exec(p)) && req.method === 'POST') {
        const job = jobs.get(m[1]); if (!job) throw new UserError('Unknown build', 404);
        if (job.state === 'running') { job.cancelled = true; if (job.child) killTree(job.child); else finish(job, 'cancelled'); }
        return json(res, 200, { ok: true });
      }
      throw new UserError('Not found', 404);
    }
    if (CFG.serveApp && req.method === 'GET') {
      const f = p === '/' ? '/index.html' : p;
      if (STATIC.test(f)) {
        const data = await fsp.readFile(path.join(CFG.appDir, f));
        res.writeHead(200, { 'Content-Type': TYPES[f.split('.').pop()] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
        return res.end(data);
      }
    }
    throw new UserError('Not found', 404);
  } catch (e) {
    if (res.headersSent) return res.end();
    if (e instanceof UserError) return json(res, e.status, { error: e.message });
    if (e && e.code === 'ENOENT') return json(res, 404, { error: 'Not found' });
    console.error(e);
    json(res, 500, { error: 'Internal server error' });
  }
});

if (require.main === module) {
  fs.mkdirSync(CFG.jobsDir, { recursive: true });
  server.listen(CFG.port, CFG.host, async () => {
    console.log(`CodeX APK build server on http://${CFG.host}:${CFG.port}${CFG.serveApp ? ' (also serving the app)' : ''}`);
    if (CFG.host !== '127.0.0.1' && !CFG.token) console.log('WARNING: listening on a network interface without BUILD_TOKEN. Set BUILD_TOKEN to require a token.');
    const tc = await toolchain(true);
    console.log(tc.ready ? `Toolchain ready: Java ${tc.java}, Gradle ${tc.gradle}, SDK ${tc.androidSdk}` : 'Toolchain NOT ready:\n - ' + tc.problems.join('\n - '));
  });
}
module.exports = { server, listZip, readZipEntry, CFG };
