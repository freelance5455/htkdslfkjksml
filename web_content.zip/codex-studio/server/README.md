# CodeX APK build server

Turns a web bundle from CodeX Studio into a **real debug-signed APK** by running Gradle. The browser app talks to it
from **Menu > HTML to APK / ZIP to APK > Build APK**. Without this server, the same screen can still
**Export Android project** (a full Gradle project + GitHub Actions workflow + build instructions).

## What it needs (on the machine that runs it)
- Node.js 18+ (no npm packages are used)
- JDK 17 or newer
- Gradle 8.7 or newer on `PATH` (or set `GRADLE_BIN`)
- Android SDK with platform 34 and build-tools: set `ANDROID_HOME` (licences accepted: `sdkmanager --licenses`)
- Internet on the first build (Gradle downloads the Android Gradle Plugin and `androidx.webkit` from Google Maven)

Example SDK setup on Linux:
```
# download "Command line tools only" from https://developer.android.com/studio, unpack to $ANDROID_HOME/cmdline-tools/latest
yes | $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses
$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager "platforms;android-34" "build-tools;34.0.0"
```

## Run
```
cd server
ANDROID_HOME=/path/to/sdk node server.js
```
Open http://127.0.0.1:8787 : the server also serves CodeX Studio itself, so the app finds the build API automatically.
The status line in the builder tells you exactly what is missing if the toolchain is incomplete.

| env var | default | meaning |
|---|---|---|
| `PORT` / `HOST` | 8787 / 127.0.0.1 | listen address. Use `HOST=0.0.0.0` to reach it from your phone on the same network |
| `BUILD_TOKEN` | none | if set, every build API call needs `Authorization: Bearer <token>`. **Set this whenever HOST is not 127.0.0.1** |
| `CORS_ORIGIN` | none | allow a CodeX Studio hosted elsewhere (e.g. `https://my-codex.netlify.app`) to call this server |
| `GRADLE_BIN` / `ANDROID_HOME` / `JAVA_HOME` | `gradle` / none / PATH | tool locations |
| `MAX_BUNDLE_MB` | 100 | largest accepted upload |
| `BUILD_TIMEOUT_MIN` | 20 | build is killed after this long |
| `SERVE_APP` | 1 | `0` = API only |

Notes
- One build at a time; others get HTTP 429.
- Security: the server **generates all Gradle, Manifest and Java files itself** from validated settings. Uploaded content only goes
  into `assets/www/` and launcher icons, so a bundle cannot inject build scripts. It still runs a real build on your machine, so do not
  expose it publicly without `BUILD_TOKEN` and a reverse proxy with HTTPS (browsers block an https page from calling an http server).
- Output is a **debug-signed** APK (installable on your own devices, not publishable on Google Play).
- Build folders are deleted one hour after the build.

## Docker (untested starting point)
`Dockerfile` in this folder installs the same tools. It has not been built or run by the author; the Android command-line tools
download URL changes over time, so check it before building.
