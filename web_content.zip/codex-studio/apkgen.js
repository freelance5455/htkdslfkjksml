/* CodeX Studio — Android project generator (WebView shell).
 * Runs in the browser (window.ApkGen) and in Node (server/server.js).
 * The Gradle/Manifest/Java files are always produced HERE from validated settings;
 * user content only ever lands in assets/www/ and res/mipmap-*, never in build scripts. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.ApkGen = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const AGP = '8.5.2', GRADLE = '8.7', COMPILE_SDK = 34, MIN_SDK = 24, TARGET_SDK = 34, WEBKIT = '1.11.0';
  const ICON_SIZES = { mdpi: 48, hdpi: 72, xhdpi: 96, xxhdpi: 144, xxxhdpi: 192 };
  const JAVA_WORDS = new Set(('abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for goto if implements import instanceof int interface long native new package private protected public return short static strictfp super switch synchronized this throw throws transient try void volatile while true false null').split(' '));

  const enc = s => new TextEncoder().encode(s);
  const isHtml = p => /\.html?$/i.test(p);

  /* ---------- validation ---------- */
  function validatePackageId(id) {
    if (typeof id !== 'string' || id.length > 150) return 'Package ID is required (example: com.example.myapp)';
    if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(id)) return 'Use lowercase letters, digits and underscores, with at least two parts separated by dots (com.example.myapp)';
    const bad = id.split('.').find(s => JAVA_WORDS.has(s));
    if (bad) return '"' + bad + '" is a reserved Java word and cannot be used in a package ID';
    return '';
  }

  /* input: raw settings; wwwPaths: array of file paths inside www/. Returns {ok, errors, clean}. */
  function validateSettings(i, wwwPaths) {
    const e = {};
    i = i || {};
    const appName = String(i.appName == null ? '' : i.appName).trim();
    if (!appName) e.appName = 'Enter an app name';
    else if (appName.length > 30) e.appName = 'Keep the app name to 30 characters or fewer';
    else if (/[\u0000-\u001f]/.test(appName)) e.appName = 'The app name contains invalid characters';

    const packageId = String(i.packageId == null ? '' : i.packageId).trim();
    const pe = validatePackageId(packageId);
    if (pe) e.packageId = pe;

    const versionName = String(i.versionName == null ? '' : i.versionName).trim();
    if (!/^[0-9A-Za-z][0-9A-Za-z._+-]{0,29}$/.test(versionName)) e.versionName = 'Use up to 30 letters, digits, dots or dashes (example: 1.0.0)';

    const vc = Number(i.versionCode);
    if (!Number.isInteger(vc) || vc < 1 || vc > 2100000000) e.versionCode = 'Version code must be a whole number from 1 to 2100000000';

    const themeMode = i.themeMode === 'dark' ? 'dark' : i.themeMode === 'light' || i.themeMode == null ? 'light' : null;
    if (!themeMode) e.themeMode = 'Choose light or dark';

    const themeColor = String(i.themeColor == null ? '' : i.themeColor).trim().toLowerCase();
    if (!/^#[0-9a-f]{6}$/.test(themeColor)) e.themeColor = 'Use a colour like #1d2232';

    const orientation = ['auto', 'portrait', 'landscape'].includes(i.orientation) ? i.orientation : i.orientation == null ? 'auto' : null;
    if (!orientation) e.orientation = 'Choose auto, portrait or landscape';

    const entry = String(i.entry == null ? '' : i.entry);
    if (!entry) e.entry = 'Choose the HTML file the app should open';
    else if (wwwPaths && !wwwPaths.includes(entry)) e.entry = 'The start page "' + entry + '" is not in the project';
    else if (!isHtml(entry)) e.entry = 'The start page must be an .html file';

    return { ok: !Object.keys(e).length, errors: e, clean: { appName, packageId, versionName, versionCode: vc, themeMode, themeColor, orientation, entry } };
  }

  /* ---------- helpers for generated text ---------- */
  const xmlText = s => String(s).replace(/\\/g, '\\\\').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '\\&quot;').replace(/'/g, "\\'").replace(/^([@?])/, '\\$1');
  const javaStr = s => String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
  const luminance = hex => { const n = parseInt(hex.slice(1), 16); const f = c => { c /= 255; return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); }; return 0.2126 * f(n >> 16) + 0.7152 * f((n >> 8) & 255) + 0.0722 * f(n & 255); };
  const slug = s => (String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'app').slice(0, 40);
  const urlPath = p => p.split('/').map(encodeURIComponent).join('/');

  /* ---------- file templates ---------- */
  function mainActivity(c) {
    return `package ${c.packageId};

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.Locale;

/** Loads the bundled website (assets/www) inside a WebView, fully offline. */
public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/${javaStr(urlPath(c.entry))}";
    private static final int FILE_CHOOSER = 1001;

    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;

    /** Serves files from assets/www at the site root, so absolute paths like /css/app.css work. */
    private static final class WwwHandler implements WebViewAssetLoader.PathHandler {
        private final Context context;

        WwwHandler(Context context) { this.context = context; }

        @Override
        public WebResourceResponse handle(String path) {
            if (path.contains("..")) return notFound();
            if (path.isEmpty() || path.endsWith("/")) path = path + "index.html";
            try {
                InputStream in = context.getAssets().open("www/" + path);
                String mime = mimeFor(path);
                boolean text = mime.startsWith("text/") || mime.contains("json") || mime.contains("javascript") || mime.contains("xml") || mime.contains("svg");
                return new WebResourceResponse(mime, text ? "utf-8" : null, in);
            } catch (IOException e) {
                return notFound();
            }
        }

        private static WebResourceResponse notFound() {
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", Collections.<String, String>emptyMap(), new ByteArrayInputStream(new byte[0]));
        }

        private static String mimeFor(String path) {
            String p = path.toLowerCase(Locale.ROOT);
            int dot = p.lastIndexOf('.');
            String ext = dot < 0 ? "" : p.substring(dot + 1);
            switch (ext) {
                case "html": case "htm": return "text/html";
                case "css": return "text/css";
                case "js": case "mjs": return "text/javascript";
                case "json": case "map": case "webmanifest": return "application/json";
                case "svg": return "image/svg+xml";
                case "png": return "image/png";
                case "jpg": case "jpeg": return "image/jpeg";
                case "gif": return "image/gif";
                case "webp": return "image/webp";
                case "ico": return "image/x-icon";
                case "avif": return "image/avif";
                case "woff": return "font/woff";
                case "woff2": return "font/woff2";
                case "ttf": return "font/ttf";
                case "otf": return "font/otf";
                case "wasm": return "application/wasm";
                case "mp3": return "audio/mpeg";
                case "ogg": return "audio/ogg";
                case "wav": return "audio/wav";
                case "mp4": return "video/mp4";
                case "webm": return "video/webm";
                case "txt": return "text/plain";
                case "xml": return "application/xml";
                case "pdf": return "application/pdf";
                default: return "application/octet-stream";
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/", new WwwHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (HOST.equals(uri.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (ActivityNotFoundException ignored) {
                    // no app can open this link
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_CHOOSER);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl(START_URL);
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER && filePathCallback != null) {
            filePathCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            filePathCallback = null;
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
`;
  }

  function manifest(c) {
    const orient = c.orientation === 'portrait' ? 'portrait' : c.orientation === 'landscape' ? 'sensorLandscape' : 'unspecified';
    return `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:theme="@style/AppTheme"
        android:usesCleartextTraffic="false">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|smallestScreenSize|screenLayout|keyboardHidden|uiMode"
            android:screenOrientation="${orient}"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`;
  }

  function styles(c) {
    const parent = c.themeMode === 'dark' ? 'Theme.Material.NoActionBar' : 'Theme.Material.Light.NoActionBar';
    return `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme" parent="@android:style/${parent}">
        <item name="android:statusBarColor">@color/theme_color</item>
        <item name="android:windowLightStatusBar">${luminance(c.themeColor) > 0.5}</item>
        <item name="android:windowBackground">@color/window_background</item>
    </style>
</resources>
`;
  }

  const colors = c => `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="theme_color">${c.themeColor}</color>
    <color name="window_background">${c.themeMode === 'dark' ? '#121212' : '#ffffff'}</color>
</resources>
`;
  const strings = c => `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">${xmlText(c.appName)}</string>
</resources>
`;

  const appGradle = c => `plugins {
    id 'com.android.application'
}

android {
    namespace '${c.packageId}'
    compileSdk ${COMPILE_SDK}

    defaultConfig {
        applicationId '${c.packageId}'
        minSdk ${MIN_SDK}
        targetSdk ${TARGET_SDK}
        versionCode ${c.versionCode}
        versionName '${c.versionName}'
    }

    buildTypes {
        release {
            minifyEnabled false
        }
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }

    androidResources {
        // The default pattern drops folders that start with "_" (for example _next/) and dotfiles.
        // Keep everything from the website bundle except version-control leftovers.
        ignoreAssetsPattern '!.svn:!.git:!.ds_store:!*.scc:!CVS:!thumbs.db:!picasa.ini:!*~'
    }
}

dependencies {
    implementation 'androidx.webkit:webkit:${WEBKIT}'
}
`;

  const rootGradle = () => `plugins {
    id 'com.android.application' version '${AGP}' apply false
}
`;
  const settingsGradle = c => `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = '${slug(c.appName)}'
include ':app'
`;
  const gradleProps = () => `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
`;
  const wrapperProps = () => `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-${GRADLE}-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`;

  const workflow = () => `name: Build APK
on:
  workflow_dispatch:
  push:
    branches: [main, master]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 17
      - uses: android-actions/setup-android@v3
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '${GRADLE}'
      - name: Build debug APK
        run: gradle assembleDebug --no-daemon
      - uses: actions/upload-artifact@v4
        with:
          name: app-debug-apk
          path: app/build/outputs/apk/debug/app-debug.apk
`;

  const buildDocs = c => `# ${c.appName} — Android project

Generated by CodeX Studio. It is a standard Android Studio / Gradle project that wraps your website
(in \`app/src/main/assets/www\`) in a WebView. Package: \`${c.packageId}\`, version ${c.versionName} (${c.versionCode}).
Start page: \`${c.entry}\`. Everything in the bundle works offline; links to other websites open in the phone's browser.

Requirements: JDK 17, Android SDK (platform ${COMPILE_SDK}), Gradle ${GRADLE}+ (Android Gradle Plugin ${AGP}).

## Option A: build in the cloud with GitHub Actions (no installs)
1. Create an empty GitHub repository and upload everything in this folder (keep the \`.github\` folder).
2. Open the **Actions** tab and run **Build APK** (it also runs on every push).
3. When it finishes, download the **app-debug-apk** artifact and unzip it to get \`app-debug.apk\`.

## Option B: Android Studio
1. Open this folder in Android Studio and let it sync (it downloads Gradle and the Android SDK pieces it needs).
2. Menu **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
3. The file is \`app/build/outputs/apk/debug/app-debug.apk\`.

## Option C: command line
\`\`\`
gradle assembleDebug
\`\`\`
(or run \`gradle wrapper --gradle-version ${GRADLE}\` once, then \`./gradlew assembleDebug\`).
Set \`ANDROID_HOME\` to your Android SDK folder, or create \`local.properties\` with \`sdk.dir=/path/to/sdk\`.

## Installing
The result is a **debug-signed** APK. It installs on your own phone (allow "install unknown apps" for the app you open it with).
It cannot be uploaded to Google Play: for that, create your own signing key and build a release bundle.
`;

  /* ---------- project assembly ---------- */
  /* www: [{path, data}] ; icons: {mdpi: Uint8Array, ...}. Returns [{path, data}] */
  function generateProject(c, www, icons, opts) {
    opts = opts || {};
    const out = [];
    const add = (path, data) => out.push({ path, data });
    add('settings.gradle', settingsGradle(c));
    add('build.gradle', rootGradle());
    add('gradle.properties', gradleProps());
    add('gradle/wrapper/gradle-wrapper.properties', wrapperProps());
    add('.gitignore', '.gradle/\nbuild/\nlocal.properties\n.idea/\n*.iml\n');
    add('app/build.gradle', appGradle(c));
    add('app/src/main/AndroidManifest.xml', manifest(c));
    add('app/src/main/java/' + c.packageId.split('.').join('/') + '/MainActivity.java', mainActivity(c));
    add('app/src/main/res/values/strings.xml', strings(c));
    add('app/src/main/res/values/colors.xml', colors(c));
    add('app/src/main/res/values/styles.xml', styles(c));
    Object.keys(ICON_SIZES).forEach(d => {
      if (!icons || !icons[d]) throw new Error('Missing launcher icon for ' + d);
      add('app/src/main/res/mipmap-' + d + '/ic_launcher.png', icons[d]);
    });
    www.forEach(f => add('app/src/main/assets/www/' + f.path, f.data));
    if (opts.includeDocs) {
      add('README-BUILD.md', buildDocs(c));
      add('.github/workflows/build-apk.yml', workflow());
    }
    return out;
  }

  /* path safety shared by client and server */
  function safeRelPath(name) {
    if (typeof name !== 'string') return null;
    let n = name.replace(/\\/g, '/');
    if (!n || n.startsWith('/') || /^[A-Za-z]:/.test(n) || /[\u0000-\u001f]/.test(n) || n.length > 240) return null;
    const parts = n.split('/');
    if (parts.some(p => p === '' || p === '.' || p === '..')) return null;
    return parts.join('/');
  }

  return { AGP, GRADLE, COMPILE_SDK, MIN_SDK, TARGET_SDK, ICON_SIZES, validateSettings, validatePackageId, generateProject, safeRelPath, slug, isHtml, enc };
});
