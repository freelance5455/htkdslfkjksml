/* CodeX Studio — HTML to APK / ZIP to APK builder.
 * Builds a real Android (WebView) app: the web bundle is sent to the CodeX build server, which runs Gradle.
 * Without a working build server the same screen exports a complete Android project instead. */
(() => {
'use strict';
const X = window.CodeX, A = window.ApkGen;
if (!X || !A) return;
const { esc, icon, toast, DB, S } = X;
const $ = (s, r = document) => r.querySelector(s);

const LIMITS = { files: 3000, total: 100 * 1024 * 1024, one: 40 * 1024 * 1024 };
const fmt = n => n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(1) + ' MB';
const enc = s => new TextEncoder().encode(s);

/* ───────── persisted builder settings ───────── */
const LS = 'codex.apk.v1';
const cfg = Object.assign({ server: '', token: '', byName: {} }, (() => { try { return JSON.parse(localStorage.getItem(LS)) || {}; } catch { return {}; } })());
const saveCfg = () => { try { localStorage.setItem(LS, JSON.stringify(cfg)); } catch { /* ignore */ } };

/* ───────── state ───────── */
let st, root;
const fresh = mode => ({
  mode, src: null, srcTab: 'project', projects: [], projectId: null,
  pkgTouched: false, iconBitmap: null, iconName: '',
  server: { state: 'unknown', msg: '', info: null },
  building: false, abort: null, jobId: null, apk: null, previewPage: null, previewToken: null, previewFrame: null
});

/* ───────── DOM skeleton ───────── */
function fld(id, label, attrs = '', hint = '') {
  return `<label class="fld" data-f="${id}"><span>${label}</span><input id="${id}" autocomplete="off" autocapitalize="off" spellcheck="false" ${attrs}><p class="apk-err" hidden></p>${hint ? `<p class="apk-hint">${hint}</p>` : ''}</label>`;
}
function open(mode) {
  close(true);
  st = fresh(mode);
  root = document.createElement('div');
  root.id = 'apkView';
  root.setAttribute('role', 'dialog');
  root.setAttribute('aria-label', mode === 'zip' ? 'ZIP to APK' : 'HTML to APK');
  root.innerHTML = `
  <div class="apk-top">
    <button class="btn ghost" id="apkBack" aria-label="Back to editor">${icon('code')}</button>
    <h1>${mode === 'zip' ? 'ZIP to APK' : 'HTML to APK'}</h1>
  </div>
  <div class="apk-body">
    <section class="apk-card" id="cSource"><h2>1. Source</h2><div id="srcBody"></div></section>
    <section class="apk-card" id="cPreview" hidden><h2>2. Preview</h2>
      <div class="apk-prev" id="prevBox"></div><p class="apk-prevmsg" id="prevMsg" hidden></p>
      <div class="row"><button class="btn outline" id="prevReload">${icon('refresh')}Reload preview</button></div>
      <p class="apk-hint">The preview runs your files in an isolated frame. Links between your pages work. The installed app loads the same files from its own storage, so it also works offline.</p>
    </section>
    <section class="apk-card" id="cSettings" hidden><h2>3. App settings</h2>
      ${fld('aName', 'App name', 'maxlength="30"')}
      ${fld('aPkg', 'Package ID', 'inputmode="url"', 'Unique ID for your app, like com.yourname.myapp. It cannot be changed later without being treated as a different app.')}
      <div class="apk-grid">${fld('aVer', 'Version name', 'value="1.0.0"')}${fld('aCode', 'Version code', 'inputmode="numeric" value="1"')}</div>
      <div class="fld"><span>Theme</span><div class="seg" id="aTheme" role="group" aria-label="Theme"><button data-v="light" aria-pressed="true">Light</button><button data-v="dark" aria-pressed="false">Dark</button></div></div>
      <label class="fld" data-f="aColor"><span>Status bar colour</span><div class="apk-color"><input type="color" id="aColorPick" value="#1d2232" aria-label="Pick colour"><input id="aColor" value="#1d2232" autocomplete="off" autocapitalize="off" spellcheck="false"></div><p class="apk-err" hidden></p></label>
      <div class="fld"><span>Orientation</span><div class="seg" id="aOrient" role="group" aria-label="Orientation"><button data-v="auto" aria-pressed="true">Auto</button><button data-v="portrait" aria-pressed="false">Portrait</button><button data-v="landscape" aria-pressed="false">Landscape</button></div></div>
      <div class="fld"><span>App icon</span>
        <div class="apk-iconrow"><img id="aIconImg" alt="App icon preview" width="64" height="64">
          <button class="btn outline" id="aIconPick">${icon('upl')}Choose image</button>
          <button class="btn outline" id="aIconReset" hidden>Use generated icon</button></div>
        <p class="apk-err" id="aIconErr" hidden></p>
        <p class="apk-hint" id="aIconHint">A simple icon from the app name and colour is generated. Choose a square PNG, JPG or WebP (192 px or larger works best) to use your own.</p></div>
    </section>
    <section class="apk-card" id="cBuild" hidden><h2>4. Build</h2>
      <div class="apk-srv" id="srvLine"><i></i><span id="srvText">Checking build server...</span></div>
      <details id="srvCfg"><summary>Build server settings</summary>
        <div class="fld"><span>Server URL (leave empty for this site)</span><input id="srvUrl" placeholder="https://build.example.com" autocomplete="off" autocapitalize="off" spellcheck="false" inputmode="url"></div>
        <div class="fld" style="margin-top:8px"><span>Access token (if the server requires one)</span><input id="srvTok" type="password" autocomplete="off"></div>
        <div class="row" style="margin-top:8px"><button class="btn outline" id="srvCheck">Check connection</button></div>
      </details>
      <div class="row"><button class="btn primary" id="btnBuild">${icon('apk')}Build APK</button><button class="btn outline" id="btnCancel" hidden>Cancel build</button><button class="btn outline" id="btnExport">${icon('pkg')}Export Android project</button></div>
      <p class="apk-hint">Build APK needs a CodeX build server (see server/README.md). Export Android project works anywhere and includes a GitHub Actions workflow and instructions to build the APK yourself.</p>
      <div id="progWrap" hidden>
        <div class="apk-stage"><span id="progStage">Starting</span><span id="progPct">0%</span></div>
        <div class="apk-bar" id="progBar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><i></i></div>
      </div>
      <div class="apk-errbox" id="errBox" hidden></div>
      <div class="apk-okbox" id="okBox" hidden></div>
      <div class="row" id="resRow" hidden><button class="btn primary" id="btnDownload">${icon('down')}Download APK</button></div>
      <details id="logWrap" hidden><summary>Build log</summary><div class="apk-log" id="logBox" role="log"></div><div class="row" style="margin-top:8px"><button class="btn outline" id="logCopy">${icon('copy')}Copy log</button></div></details>
    </section>
  </div>`;
  document.body.appendChild(root);
  $('#apkBack').onclick = () => close();
  wireSettings();
  renderSource();
  $('#srvUrl').value = cfg.server; $('#srvTok').value = cfg.token;
  refreshIcon();
  checkServer();
}
async function close(silent) {
  if (!root) return;
  if (st && st.building && !silent) {
    if (!await X.confirmBox({ title: 'Stop the build?', message: 'A build is still running. Leaving this screen will cancel it.', ok: 'Cancel build', danger: true })) return;
    await cancelBuild();
  }
  if (st && st.abort) st.abort.abort();
  window.removeEventListener('message', onPreviewMessage);
  root.remove(); root = null; st = null;
}

/* ───────── source step ───────── */
const getProjects = async () => { await X.save(false); return (await DB.all()).sort((a, b) => b.updated - a.updated); };

async function renderSource() {
  const b = $('#srcBody');
  if (st.mode === 'zip') {
    b.innerHTML = `<p class="apk-hint">Upload a ZIP containing a website or web app (it should include an index.html). Files are checked and unpacked safely on this device. Nothing is uploaded until you press Build APK.</p>
      <div class="row"><button class="btn outline" id="zipPick">${icon('upl')}Choose ZIP file</button></div><div id="srcInfo"></div>`;
    $('#zipPick').onclick = () => pickFile('.zip,application/zip', loadZip);
    return;
  }
  b.innerHTML = `<div class="seg" id="srcTabs" role="group" aria-label="Source"><button data-t="project" aria-pressed="${st.srcTab === 'project'}">Saved project</button><button data-t="file" aria-pressed="${st.srcTab === 'file'}">HTML file</button></div><div id="srcPane"></div><div id="srcInfo"></div>`;
  b.querySelectorAll('#srcTabs button').forEach(x => x.onclick = () => { st.srcTab = x.dataset.t; st.src = null; hideAfterSource(); renderSource(); });
  const pane = $('#srcPane');
  if (st.srcTab === 'file') {
    pane.innerHTML = `<p class="apk-hint" style="margin:8px 0">Import a single HTML file. Only that file is packaged, so CSS, scripts and images it links to are not included. Use a saved project or ZIP to APK for those.</p><div class="row"><button class="btn outline" id="htmlPick">${icon('upl')}Choose HTML file</button></div>`;
    $('#htmlPick').onclick = () => pickFile('.html,.htm,text/html', loadHtmlFile);
    return;
  }
  st.projects = await getProjects();
  if (!st.projects.length) { pane.innerHTML = '<p class="apk-hint">No saved projects yet.</p>'; return; }
  if (!st.projectId || !st.projects.find(p => p.id === st.projectId)) st.projectId = (S.project && S.project.id) || st.projects[0].id;
  pane.innerHTML = `<label class="fld" style="margin-top:8px"><span>Project</span><select class="apk-select" id="projSel">${st.projects.map(p => `<option value="${esc(p.id)}"${p.id === st.projectId ? ' selected' : ''}>${esc(p.name)} (${p.files.length} files)</option>`).join('')}</select></label>`;
  $('#projSel').onchange = e => { st.projectId = e.target.value; loadProject(); };
  loadProject();
}

function pickFile(accept, handler) {
  const i = document.createElement('input');
  i.type = 'file'; i.accept = accept;
  i.onchange = () => { if (i.files[0]) handler(i.files[0]); };
  i.click();
}

function hideAfterSource() {
  ['cPreview', 'cSettings', 'cBuild'].forEach(id => { $('#' + id).hidden = true; });
}
function sourceError(msg) {
  st.src = null; hideAfterSource();
  $('#srcInfo').innerHTML = `<div class="apk-errbox" style="margin-top:8px">${esc(msg)}</div>`;
}

/* a source is { name, files:[{name,content}|{name,binary,data}], raw?:Map, htmls:[], entry, warnings:[], total } */
function finishSource(src) {
  const htmls = src.files.filter(f => A.isHtml(f.name)).map(f => f.name);
  if (!htmls.length) return sourceError('No HTML file was found, so there is nothing to open. Add an index.html and try again.');
  const rank = n => /(^|\/)index\.html?$/i.test(n) ? 0 : 1;
  htmls.sort((a, b) => a.split('/').length - b.split('/').length || rank(a) - rank(b) || a.localeCompare(b));
  src.htmls = htmls;
  const idx = htmls.find(n => n === 'index.html') || htmls.find(n => /(^|\/)index\.html?$/i.test(n)) || htmls[0];
  src.entry = src.preferEntry && htmls.includes(src.preferEntry) ? src.preferEntry : idx;
  if (!htmls.includes('index.html') && htmls.length) src.warnings.push(`There is no index.html at the top level. The app will open "${src.entry}"; change it below if that is wrong.`);
  src.total = src.files.reduce((n, f) => n + (src.raw && src.raw.get(f.name) ? src.raw.get(f.name).length : f.binary ? f.data.byteLength : enc(f.content).length), 0);
  if (src.total > 30 * 1024 * 1024) src.warnings.push(`This is a large app (${fmt(src.total)}). The APK will be at least that big.`);
  st.src = src;
  renderSourceInfo();
  $('#cPreview').hidden = false; $('#cSettings').hidden = false; $('#cBuild').hidden = false;
  applyDefaults();
  renderPreview(src.entry);
  resetResult();
}

function renderSourceInfo() {
  const s = st.src;
  const warn = s.warnings.length ? `<p class="apk-warn">${s.warnings.length === 1 ? esc(s.warnings[0]) : '<b>Notes</b><ul>' + s.warnings.slice(0, 8).map(w => `<li>${esc(w)}</li>`).join('') + (s.warnings.length > 8 ? `<li>and ${s.warnings.length - 8} more</li>` : '') + '</ul>'}</p>` : '';
  const pick = s.htmls.length > 1 ? `<div class="fld" style="margin-top:8px"><span>Start page (${s.htmls.length} HTML files found)</span><div class="apk-list" id="entryList" role="group" aria-label="Start page">${s.htmls.map(n => `<button data-n="${esc(n)}" aria-pressed="${n === s.entry}">${icon('file', 'sm')}<span>${esc(n)}</span></button>`).join('')}</div><p class="apk-err" id="entryErr" hidden></p></div>` : '';
  $('#srcInfo').innerHTML = `<div class="apk-sum" style="margin-top:10px"><span><b>${esc(s.name)}</b></span><span><b>${s.files.length}</b> files</span><span><b>${fmt(s.total)}</b></span><span>start page <b>${esc(s.entry)}</b></span></div>${warn}${pick}`;
  const list = $('#entryList');
  if (list) list.querySelectorAll('button').forEach(btn => btn.onclick = () => {
    s.entry = btn.dataset.n;
    list.querySelectorAll('button').forEach(x => x.setAttribute('aria-pressed', x === btn));
    renderSourceInfo(); renderPreview(s.entry);
  });
}

function loadProject() {
  const p = st.projects.find(x => x.id === st.projectId);
  if (!p) return;
  const files = p.files.map(f => f.binary ? { name: f.name, binary: true, data: f.data } : { name: f.name, content: f.content });
  finishSource({ name: p.name, files, warnings: [], preferEntry: p.active });
}

async function loadHtmlFile(file) {
  if (file.size > 20 * 1024 * 1024) return sourceError('That HTML file is larger than 20 MB.');
  let text;
  try { text = await file.text(); } catch { return sourceError('Could not read that file.'); }
  if (!/<\s*(html|body|head|!doctype|div|p|h1|script|style|a|img|main|section)\b/i.test(text)) return sourceError('That file does not look like HTML.');
  finishSource({ name: file.name.replace(/\.[^.]+$/, '') || 'Imported page', files: [{ name: 'index.html', content: text }], warnings: [] });
}

/* Safe ZIP extraction: structure + size checks happen before anything is inflated. */
async function loadZip(file) {
  if (!window.JSZip) return sourceError('ZIP support did not load. Check your connection and reload.');
  $('#srcInfo').innerHTML = '<p class="apk-hint" style="margin-top:8px">Checking ZIP...</p>';
  let zip;
  try { zip = await JSZip.loadAsync(file); } catch { return sourceError('That file is not a valid ZIP archive.'); }
  const list = [];
  zip.forEach((p, e) => { if (!e.dir) list.push([p, e]); });
  if (!list.length) return sourceError('That ZIP file is empty.');
  if (list.length > LIMITS.files) return sourceError(`That ZIP has ${list.length} files; the limit is ${LIMITS.files}.`);
  const warnings = [];
  let declared = 0;
  for (const [p, e] of list) {
    const u = e._data && typeof e._data.uncompressedSize === 'number' ? e._data.uncompressedSize : 0;
    if (u > LIMITS.one) return sourceError(`"${p}" is ${fmt(u)} unpacked; single files are limited to ${fmt(LIMITS.one)}.`);
    declared += u;
    if (declared > LIMITS.total) return sourceError(`The ZIP would unpack to more than ${fmt(LIMITS.total)}. It was not extracted.`);
  }
  const keep = []; let unsafe = 0, ignored = 0;
  for (const [p, e] of list) {
    const raw = p.replace(/\\/g, '/');
    if (/(^|\/)(__MACOSX|\.DS_Store|Thumbs\.db|\.git)(\/|$)/.test(raw)) { ignored++; continue; }
    const safe = A.safeRelPath(raw);
    if (!safe) { unsafe++; continue; }
    keep.push([safe, e]);
  }
  if (unsafe) warnings.push(`${unsafe} file${unsafe === 1 ? ' was' : 's were'} skipped because the path was unsafe (for example "../" or an absolute path).`);
  if (!keep.length) return sourceError('There are no usable files in that ZIP.');
  const roots = new Set(keep.map(([p]) => p.split('/')[0]));
  const strip = roots.size === 1 && keep.every(([p]) => p.includes('/')) ? [...roots][0] + '/' : '';
  const files = [], rawMap = new Map(); let actual = 0;
  for (const [p0, e] of keep) {
    const name = strip ? p0.slice(strip.length) : p0;
    const bytes = await e.async('uint8array');
    actual += bytes.length;
    if (bytes.length > LIMITS.one || actual > LIMITS.total) return sourceError('The ZIP unpacks to more data than it declares. It was rejected for safety.');
    rawMap.set(name, bytes);
    if (X.TEXT_EXT.has(X.ext(name))) files.push({ name, content: new TextDecoder('utf-8').decode(bytes) });
    else files.push({ name, binary: true, data: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) });
  }
  files.sort((a, b) => a.name.localeCompare(b.name));
  finishSource({ name: file.name.replace(/\.zip$/i, '') || 'Web app', files, raw: rawMap, warnings });
}

/* ───────── preview ───────── */
function renderPreview(page) {
  const s = st.src; if (!s) return;
  st.previewPage = page;
  const token = X.uid();
  const built = X.buildPreview(s.files, page, token);
  const box = $('#prevBox'); box.innerHTML = '';
  $('#prevMsg').hidden = true;
  if (!built) { box.innerHTML = '<div style="padding:20px;color:var(--mute)">Nothing to preview.</div>'; return; }
  const fr = document.createElement('iframe');
  fr.title = 'App preview';
  fr.setAttribute('sandbox', 'allow-scripts allow-modals allow-forms allow-popups');
  fr.srcdoc = built.html;
  box.appendChild(fr);
  st.previewToken = token; st.previewFrame = fr;
  window.removeEventListener('message', onPreviewMessage);
  window.addEventListener('message', onPreviewMessage);
  layoutPreview();
}
function layoutPreview() {
  const box = $('#prevBox'), fr = st && st.previewFrame; if (!box || !fr) return;
  const aw = box.clientWidth, ah = box.clientHeight; if (!aw) return;
  const W = 390, scale = Math.min(1, aw / W);
  fr.style.width = W + 'px'; fr.style.height = Math.round(ah / scale) + 'px';
  fr.style.transform = `translateX(-50%) scale(${scale})`;
  fr.style.transformOrigin = '50% 0';
}
window.addEventListener('resize', () => { if (root) layoutPreview(); });
function onPreviewMessage(e) {
  if (!st || !st.previewFrame || e.source !== st.previewFrame.contentWindow) return;
  const d = e.data; if (!d || d.cx !== st.previewToken) return;
  if (d.type === 'nav') {
    const dir = st.previewPage.includes('/') ? st.previewPage.slice(0, st.previewPage.lastIndexOf('/') + 1) : '';
    let h = String(d.href).split(/[?#]/)[0]; try { h = decodeURIComponent(h); } catch { /* keep */ }
    const parts = []; (h.startsWith('/') ? h.slice(1) : dir + h).split('/').forEach(x => { if (x === '' || x === '.') return; if (x === '..') parts.pop(); else parts.push(x); });
    let target = parts.join('/');
    const names = new Set(st.src.files.map(f => f.name));
    if (!names.has(target) && names.has(target + '/index.html')) target += '/index.html';
    if (!names.has(target) && names.has(target + '.html')) target += '.html';
    if (names.has(target) && A.isHtml(target)) renderPreview(target);
    else toast('Page not found in the app: ' + d.href, 'error');
  } else if (d.type === 'error' || (d.type === 'console' && d.level === 'error')) {
    const m = $('#prevMsg'); m.hidden = false; m.textContent = 'Script error in preview: ' + (d.message || d.text);
  }
}

/* ───────── settings ───────── */
function setSeg(id, v) { root.querySelectorAll('#' + id + ' button').forEach(b => b.setAttribute('aria-pressed', b.dataset.v === v)); }
const getSeg = id => { const b = root.querySelector('#' + id + ' button[aria-pressed=true]'); return b ? b.dataset.v : null; };
function suggestPkg(name) {
  let seg = A.slug(name).replace(/-/g, '');
  if (!/^[a-z]/.test(seg)) seg = 'app' + seg;
  if (['do', 'if', 'for', 'new', 'int', 'try', 'case', 'else', 'goto', 'this', 'void', 'byte', 'char', 'long', 'enum', 'final', 'class', 'const', 'while', 'break', 'catch', 'throw', 'short', 'super', 'float', 'public', 'return', 'static', 'switch', 'double', 'import', 'native', 'private', 'package', 'boolean'].includes(seg)) seg += 'app';
  return 'com.codex.' + seg;
}
function wireSettings() {
  const clear = id => { const f = root.querySelector(`[data-f="${id}"]`); if (f) { f.classList.remove('bad'); const e = f.querySelector('.apk-err'); if (e) e.hidden = true; } };
  ['aName', 'aPkg', 'aVer', 'aCode', 'aColor'].forEach(id => $('#' + id).addEventListener('input', () => { clear(id); if (id === 'aPkg') st.pkgTouched = true; }));
  $('#aName').addEventListener('input', () => { if (!st.pkgTouched) $('#aPkg').value = suggestPkg($('#aName').value); refreshIcon(); });
  $('#aPkg').addEventListener('input', () => { $('#aPkg').value = $('#aPkg').value.toLowerCase().replace(/\s+/g, ''); });
  $('#aColorPick').addEventListener('input', e => { $('#aColor').value = e.target.value; clear('aColor'); refreshIcon(); });
  $('#aColor').addEventListener('input', e => { if (/^#[0-9a-fA-F]{6}$/.test(e.target.value)) $('#aColorPick').value = e.target.value.toLowerCase(); refreshIcon(); });
  root.querySelectorAll('#aTheme button').forEach(b => b.onclick = () => { setSeg('aTheme', b.dataset.v); refreshIcon(); });
  root.querySelectorAll('#aOrient button').forEach(b => b.onclick = () => setSeg('aOrient', b.dataset.v));
  $('#aIconPick').onclick = () => pickFile('image/png,image/jpeg,image/webp', async f => {
    const err = $('#aIconErr'); err.hidden = true;
    if (f.size > 8 * 1024 * 1024) { err.textContent = 'That image is larger than 8 MB.'; err.hidden = false; return; }
    try { st.iconBitmap = await createImageBitmap(f); st.iconName = f.name; }
    catch { err.textContent = 'That image could not be read. Use a PNG, JPG or WebP file.'; err.hidden = false; return; }
    const w = st.iconBitmap.width, h = st.iconBitmap.height;
    $('#aIconHint').textContent = `Using ${f.name} (${w}x${h})` + (w !== h ? '. It is not square, so the centre is cropped.' : '.') + (Math.min(w, h) < 192 ? ' It is smaller than 192 px and will look soft on large screens.' : '');
    $('#aIconReset').hidden = false; refreshIcon();
  });
  $('#aIconReset').onclick = () => { st.iconBitmap = null; $('#aIconReset').hidden = true; $('#aIconHint').textContent = 'A simple icon from the app name and colour is generated.'; refreshIcon(); };
  $('#prevReload').onclick = () => renderPreview(st.previewPage || st.src.entry);
  $('#srvCheck').onclick = () => { cfg.server = $('#srvUrl').value.trim().replace(/\/+$/, ''); cfg.token = $('#srvTok').value; saveCfg(); checkServer(true); };
  $('#btnBuild').onclick = startBuild;
  $('#btnCancel').onclick = cancelBuild;
  $('#btnExport').onclick = exportProject;
  $('#btnDownload').onclick = () => { if (st.apk) X.download(st.apk.blob, st.apk.name); };
  $('#logCopy').onclick = async () => { try { await navigator.clipboard.writeText($('#logBox').textContent); toast('Log copied'); } catch { toast('Could not copy the log', 'error'); } };
}
function applyDefaults() {
  const saved = cfg.byName[st.src.name];
  const name = saved ? saved.appName : st.src.name.replace(/[-_]+/g, ' ').replace(/^\w/, c => c.toUpperCase()).slice(0, 30);
  $('#aName').value = name;
  $('#aPkg').value = saved ? saved.packageId : suggestPkg(name);
  st.pkgTouched = !!saved;
  $('#aVer').value = saved ? saved.versionName : '1.0.0';
  $('#aCode').value = saved ? saved.versionCode : 1;
  $('#aColor').value = $('#aColorPick').value = saved ? saved.themeColor : '#1d2232';
  setSeg('aTheme', saved ? saved.themeMode : 'light'); setSeg('aOrient', saved ? saved.orientation : 'auto');
  refreshIcon();
}
const readSettings = () => ({ appName: $('#aName').value, packageId: $('#aPkg').value, versionName: $('#aVer').value, versionCode: $('#aCode').value, themeMode: getSeg('aTheme'), themeColor: $('#aColor').value, orientation: getSeg('aOrient'), entry: st.src && st.src.entry });
const FIELD_OF = { appName: 'aName', packageId: 'aPkg', versionName: 'aVer', versionCode: 'aCode', themeColor: 'aColor' };
function validate() {
  root.querySelectorAll('.fld.bad').forEach(f => { f.classList.remove('bad'); const e = f.querySelector('.apk-err'); if (e) e.hidden = true; });
  const v = A.validateSettings(readSettings(), st.src.files.map(f => f.name));
  let first = null;
  Object.entries(v.errors).forEach(([k, msg]) => {
    const id = FIELD_OF[k];
    if (id) { const f = root.querySelector(`[data-f="${id}"]`); f.classList.add('bad'); const e = f.querySelector('.apk-err'); e.textContent = msg; e.hidden = false; first = first || f; }
    else { toast(msg, 'error'); }
  });
  if (first) first.scrollIntoView({ block: 'center', behavior: 'smooth' });
  return v;
}

/* ───────── icons ───────── */
function drawIcon(size) {
  const c = document.createElement('canvas'); c.width = c.height = size;
  const g = c.getContext('2d');
  if (st.iconBitmap) {
    const b = st.iconBitmap, m = Math.min(b.width, b.height);
    g.imageSmoothingQuality = 'high';
    g.drawImage(b, (b.width - m) / 2, (b.height - m) / 2, m, m, 0, 0, size, size);
    return c;
  }
  const color = /^#[0-9a-fA-F]{6}$/.test($('#aColor').value) ? $('#aColor').value : '#1d2232';
  const n = parseInt(color.slice(1), 16), lum = (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255;
  const r = size * 0.22;
  g.fillStyle = color; g.beginPath();
  g.moveTo(r, 0); g.arcTo(size, 0, size, size, r); g.arcTo(size, size, 0, size, r); g.arcTo(0, size, 0, 0, r); g.arcTo(0, 0, size, 0, r); g.closePath(); g.fill();
  const ch = (($('#aName').value.match(/[A-Za-z0-9]/) || ['A'])[0]).toUpperCase();
  g.fillStyle = lum > 0.6 ? '#1d2232' : '#ffffff';
  g.font = `700 ${Math.round(size * 0.56)}px system-ui, sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText(ch, size / 2, size / 2 + size * 0.03);
  return c;
}
let iconT;
function refreshIcon() { clearTimeout(iconT); iconT = setTimeout(() => { if (root) $('#aIconImg').src = drawIcon(128).toDataURL('image/png'); }, 120); }
async function makeIcons() {
  const out = {};
  for (const [d, size] of Object.entries(A.ICON_SIZES)) {
    const blob = await new Promise(res => drawIcon(size).toBlob(res, 'image/png'));
    if (!blob) throw new Error('Could not create the app icon');
    out[d] = new Uint8Array(await blob.arrayBuffer());
  }
  return out;
}

/* ───────── packaging ───────── */
const bytesOf = f => (st.src.raw && st.src.raw.get(f.name)) || (f.binary ? new Uint8Array(f.data) : enc(f.content));
const wwwFiles = () => st.src.files.map(f => ({ path: f.name, data: bytesOf(f) }));

async function exportProject() {
  const v = validate(); if (!v.ok) return;
  remember(v.clean);
  try {
    const icons = await makeIcons();
    const files = A.generateProject(v.clean, wwwFiles(), icons, { includeDocs: true });
    const zip = new JSZip(), dir = A.slug(v.clean.appName) + '-android/';
    files.forEach(f => zip.file(dir + f.path, f.data));
    const blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE' });
    X.download(blob, A.slug(v.clean.appName) + '-android-project.zip');
    showOk(`<b>Android project exported.</b> It contains the full Gradle project, your site in <code>app/src/main/assets/www</code>, a GitHub Actions workflow and <code>README-BUILD.md</code> with three ways to turn it into an APK. This is not an APK yet.`);
  } catch (e) { showErr('Could not export the project: ' + (e && e.message || e)); }
}
const remember = c => { cfg.byName[st.src.name] = { appName: c.appName, packageId: c.packageId, versionName: c.versionName, versionCode: c.versionCode, themeMode: c.themeMode, themeColor: c.themeColor, orientation: c.orientation }; saveCfg(); };

/* ───────── build server ───────── */
const base = () => cfg.server || '';
const authHeaders = () => cfg.token ? { Authorization: 'Bearer ' + cfg.token } : {};
function setSrv(state, msg) {
  st.server.state = state; st.server.msg = msg;
  const line = $('#srvLine'); if (!line) return;
  line.className = 'apk-srv ' + (state === 'ready' ? 'ok' : state === 'unknown' ? '' : 'bad');
  $('#srvText').textContent = msg;
}
async function checkServer(manual) {
  setSrv('unknown', 'Checking build server...');
  try {
    const r = await fetch(base() + '/api/health' + (manual ? '?fresh=1' : ''), { headers: authHeaders(), cache: 'no-store' });
    const ct = r.headers.get('content-type') || '';
    if (!r.ok || !ct.includes('json')) throw new Error('nohealth');
    const h = await r.json();
    if (h.service !== 'codex-apk-builder') throw new Error('nohealth');
    st.server.info = h;
    if (h.ready) setSrv('ready', `Build server ready (Java ${h.java}, Gradle ${h.gradle}).` + (h.busy ? ' A build is running; yours will be refused until it finishes.' : ''));
    else setSrv('notready', 'The build server is reachable but cannot build yet: ' + h.problems.join('. ') + '.');
  } catch {
    setSrv('none', cfg.server ? `Cannot reach a build server at ${cfg.server}. Check the URL, that the server is running, and that it allows this site (CORS_ORIGIN).` : 'No build server found for this site. Export the Android project to build the APK yourself, or enter a build server URL under Build server settings.');
  }
}

/* ───────── build ───────── */
function resetResult() {
  if (!root) return;
  ['errBox', 'okBox', 'resRow', 'logWrap', 'progWrap'].forEach(id => { $('#' + id).hidden = true; });
  st.apk = null;
}
const showErr = m => { $('#okBox').hidden = true; $('#errBox').hidden = false; $('#errBox').textContent = m; $('#errBox').scrollIntoView({ block: 'nearest' }); };
const showOk = html => { $('#errBox').hidden = true; $('#okBox').hidden = false; $('#okBox').innerHTML = html; };
function setProgress(pct, label, cls) {
  $('#progWrap').hidden = false;
  const p = Math.max(0, Math.min(100, Math.round(pct)));
  $('#progBar').firstElementChild.style.width = p + '%';
  $('#progBar').className = 'apk-bar' + (cls ? ' ' + cls : '');
  $('#progBar').setAttribute('aria-valuenow', p);
  $('#progPct').textContent = p + '%';
  if (label) $('#progStage').textContent = label;
}
function addLog(line) {
  const box = $('#logBox'); $('#logWrap').hidden = false;
  const d = document.createElement('div');
  d.textContent = line;
  if (/\b(error|FAILED|exception)\b/i.test(line)) d.className = 'e'; else if (/\bwarning\b/i.test(line)) d.className = 'w'; else if (/^> Task|^BUILD/.test(line)) d.className = 't';
  box.appendChild(d);
  while (box.childElementCount > 3000) box.firstElementChild.remove();
  box.scrollTop = box.scrollHeight;
}
function setBuilding(on) {
  st.building = on;
  $('#btnBuild').disabled = on; $('#btnExport').disabled = on; $('#btnCancel').hidden = !on;
}

function xhrPost(url, blob, headers, onProg, signal) {
  return new Promise((resolve, reject) => {
    const x = new XMLHttpRequest();
    x.open('POST', url);
    Object.entries(headers).forEach(([k, v]) => x.setRequestHeader(k, v));
    x.upload.onprogress = e => { if (e.lengthComputable) onProg(e.loaded / e.total); };
    x.onload = () => { let j = null; try { j = JSON.parse(x.responseText); } catch { /* not json */ } resolve({ status: x.status, json: j }); };
    x.onerror = () => reject(new Error('network'));
    x.onabort = () => reject(new Error('aborted'));
    signal.addEventListener('abort', () => x.abort());
    x.send(blob);
  });
}

async function startBuild() {
  const v = validate(); if (!v.ok) return;
  resetResult();
  $('#logBox').innerHTML = '';
  await checkServer(true);
  if (st.server.state !== 'ready') {
    showErr(st.server.state === 'notready' ? st.server.msg + ' Fix that on the server, or use Export Android project.' : st.server.msg);
    return;
  }
  remember(v.clean);
  st.abort = new AbortController(); setBuilding(true);
  const signal = st.abort.signal;
  try {
    setProgress(0, 'Packaging ' + st.src.files.length + ' files');
    const icons = await makeIcons();
    const zip = new JSZip();
    zip.file('app.json', JSON.stringify(v.clean));
    st.src.files.forEach(f => zip.file('www/' + f.name, bytesOf(f), { binary: true }));
    Object.entries(icons).forEach(([d, b]) => zip.file(`icons/${d}.png`, b, { compression: 'STORE' }));
    const blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE' }, m => setProgress(m.percent * 0.01, 'Packaging files'));
    addLog(`Bundle ready: ${st.src.files.length} files, ${fmt(blob.size)}`);
    setProgress(1, 'Uploading ' + fmt(blob.size));
    const r = await xhrPost(base() + '/api/build', blob, { 'Content-Type': 'application/zip', ...authHeaders() }, f => setProgress(1 + f * 2, 'Uploading ' + Math.round(f * 100) + '%'), signal);
    if (r.status !== 202 || !r.json || !r.json.jobId) {
      const msg = (r.json && r.json.error) || 'The server refused the build (HTTP ' + r.status + ').';
      throw new Error(r.status === 401 ? 'The build server needs an access token. Enter it under Build server settings.' : msg);
    }
    st.jobId = r.json.jobId;
    addLog('Build started on the server (job ' + st.jobId + ')');
    await followBuild(v.clean, signal);
  } catch (e) {
    if (signal.aborted) { setProgress(0, 'Cancelled', 'fail'); }
    else {
      setProgress(Number($('#progBar').getAttribute('aria-valuenow')) || 0, 'Build failed', 'fail');
      showErr(e.message === 'network' ? `Could not reach the build server${cfg.server ? ' at ' + cfg.server : ''}. If this page is on https, the server must also use https.` : e.message);
    }
  } finally { setBuilding(false); }
}

async function followBuild(clean, signal) {
  let terminal = null, retries = 0;
  while (!terminal) {
    try {
      const r = await fetch(`${base()}/api/build/${st.jobId}/events`, { headers: authHeaders(), signal });
      if (!r.ok) throw new Error('Lost the build (HTTP ' + r.status + '). The server may have restarted.');
      const reader = r.body.getReader(), dec = new TextDecoder(); let buf = '';
      $('#logBox').innerHTML = '';
      for (;;) {
        const { done, value } = await reader.read(); if (done) break;
        buf += dec.decode(value, { stream: true });
        let i;
        while ((i = buf.indexOf('\n\n')) >= 0) {
          const block = buf.slice(0, i); buf = buf.slice(i + 2);
          let ev = 'message', data = '';
          block.split('\n').forEach(l => { if (l.startsWith('event: ')) ev = l.slice(7); else if (l.startsWith('data: ')) data += l.slice(6); });
          if (!data) continue;
          const d = JSON.parse(data);
          if (ev === 'log') addLog(d.line);
          else if (ev === 'stage') setProgress(d.progress, d.stage);
          else if (ev === 'done' || ev === 'error' || ev === 'cancelled') terminal = { ev, d };
        }
      }
    } catch (e) {
      if (signal.aborted) throw e;
      if (/^Lost the build/.test(e.message) || ++retries > 4) throw new Error(e.message.startsWith('Lost') ? e.message : 'Lost connection to the build server. The build may still be running on it.');
      addLog(`Connection dropped, reconnecting (${retries}/4)...`);
      await new Promise(res => setTimeout(res, 1500 * retries));
    }
  }
  if (terminal.ev === 'cancelled') { setProgress(0, 'Cancelled', 'fail'); showErr('The build was cancelled.'); return; }
  if (terminal.ev === 'error') { setProgress(Number($('#progBar').getAttribute('aria-valuenow')) || 0, 'Build failed', 'fail'); showErr(terminal.d.message + ' See the build log for details.'); $('#logWrap').open = true; return; }
  await fetchApk(terminal.d.apk, clean, signal);
}

async function fetchApk(meta, clean, signal) {
  setProgress(98, 'Downloading APK from the server');
  const r = await fetch(`${base()}/api/build/${st.jobId}/apk`, { headers: authHeaders(), signal });
  if (!r.ok) throw new Error('The build finished but the APK could not be downloaded (HTTP ' + r.status + ').');
  const buf = new Uint8Array(await r.arrayBuffer());
  if (buf.length !== meta.size || buf[0] !== 0x50 || buf[1] !== 0x4b || buf[2] !== 3 || buf[3] !== 4) throw new Error('The downloaded file is not a valid APK (size or format mismatch). It was discarded.');
  let verified = 'not checked (needs a secure connection)';
  if (window.crypto && crypto.subtle) {
    const hex = [...new Uint8Array(await crypto.subtle.digest('SHA-256', buf))].map(b => b.toString(16).padStart(2, '0')).join('');
    if (hex !== meta.sha256) throw new Error('The downloaded APK failed its SHA-256 check. It was discarded.');
    verified = 'matches the server';
  }
  st.apk = { blob: new Blob([buf], { type: 'application/vnd.android.package-archive' }), name: meta.name };
  setProgress(100, 'Done', 'ok');
  $('#resRow').hidden = false;
  showOk(`<b>APK built.</b> ${esc(meta.name)}, ${fmt(meta.size)}. SHA-256 <code>${meta.sha256.slice(0, 16)}...</code> (${verified}).<br>It is debug-signed: install it on your own phone (allow installs from the app you open it with). It cannot be published on Google Play without your own release signing key.`);
}

async function cancelBuild() {
  if (!st || !st.building) return;
  try { if (st.jobId) await fetch(`${base()}/api/build/${st.jobId}/cancel`, { method: 'POST', headers: authHeaders() }); } catch { /* server unreachable */ }
  if (st.abort) st.abort.abort();
}

window.CodeXApk = { open, close };
})();
