/* CodeX Studio — editor, projects, sandboxed preview, import/export */
(() => {
'use strict';

/* ───────────── helpers ───────────── */
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const icon = (id, cls = '') => `<svg class="ic ${cls}"><use href="#i-${id}"/></svg>`;
const ago = t => {
  const s = (Date.now() - t) / 1000;
  if (s < 60) return 'just now';
  if (s < 3600) return Math.floor(s / 60) + ' min ago';
  if (s < 86400) return Math.floor(s / 3600) + ' h ago';
  return new Date(t).toLocaleDateString();
};
const ext = n => { const m = /\.([^./]+)$/.exec(n); return m ? m[1].toLowerCase() : ''; };
const base = n => n.slice(n.lastIndexOf('/') + 1);
const slug = s => (s || 'project').trim().replace(/[^\w.-]+/g, '-').replace(/^-+|-+$/g, '') || 'project';
const countNl = s => { let n = 0; for (let i = s.indexOf('\n'); i >= 0; i = s.indexOf('\n', i + 1)) n++; return n; };
const b64 = bytes => { let s = ''; for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000)); return btoa(s); };

const TEXT_EXT = new Set('html htm css js mjs cjs json xml svg md markdown txt csv ts tsx jsx py yaml yml sql sh php java c cpp h hpp go rs rb kt swift ini toml env gitignore'.split(' '));
const MIME = { html: 'text/html', htm: 'text/html', css: 'text/css', js: 'text/javascript', mjs: 'text/javascript', json: 'application/json', xml: 'application/xml', svg: 'image/svg+xml', md: 'text/markdown', txt: 'text/plain', csv: 'text/csv', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', ico: 'image/x-icon', woff: 'font/woff', woff2: 'font/woff2', ttf: 'font/ttf', mp3: 'audio/mpeg', mp4: 'video/mp4', pdf: 'application/pdf' };
const mimeOf = n => MIME[ext(n)] || (TEXT_EXT.has(ext(n)) ? 'text/plain' : 'application/octet-stream');
const MODES = { html: 'htmlmixed', htm: 'htmlmixed', css: 'css', js: 'javascript', mjs: 'javascript', cjs: 'javascript', jsx: 'javascript', json: { name: 'javascript', json: true }, ts: { name: 'javascript', typescript: true }, tsx: { name: 'javascript', typescript: true }, xml: 'xml', svg: 'xml', md: 'markdown', markdown: 'markdown', py: 'python', yaml: 'yaml', yml: 'yaml', sql: 'sql', sh: 'shell', java: 'text/x-java', c: 'text/x-csrc', h: 'text/x-csrc', cpp: 'text/x-c++src', hpp: 'text/x-c++src', go: 'go', rs: 'rust' };
const modeFor = n => MODES[ext(n)] || null;
const TAB_COLOR = { html: '#ff8f6b', htm: '#ff8f6b', css: '#6fb1ff', js: '#f2cc72', mjs: '#f2cc72', json: '#9be3a7', md: '#c4a7ff', svg: '#ff8fa3', py: '#7fdbca' };
const colorFor = n => TAB_COLOR[ext(n)] || '#8d96b3';
const isHtmlName = n => /\.html?$/i.test(n);
const isCodeName = n => /\.(html?|css|m?js)$/i.test(n);

/* ───────────── preferences ───────────── */
const PREF_KEY = 'codex.prefs.v1';
const prefs = Object.assign({ fontSize: 15, wrap: false, live: false, device: 'mobile', split: false }, (() => { try { return JSON.parse(localStorage.getItem(PREF_KEY)) || {}; } catch { return {}; } })());
const savePrefs = () => { try { localStorage.setItem(PREF_KEY, JSON.stringify(prefs)); } catch { /* ignore */ } };
const lsGet = k => { try { return localStorage.getItem(k); } catch { return null; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch { /* ignore */ } };

/* ───────────── storage (IndexedDB, memory fallback) ───────────── */
const DB = (() => {
  let db = null, usingMem = false;
  const mem = new Map();
  const open = () => new Promise(res => {
    try {
      const rq = indexedDB.open('codex-studio', 1);
      rq.onupgradeneeded = () => rq.result.createObjectStore('projects', { keyPath: 'id' });
      rq.onsuccess = () => { db = rq.result; res(true); };
      rq.onerror = rq.onblocked = () => { usingMem = true; res(false); };
    } catch { usingMem = true; res(false); }
  });
  const tx = (mode, fn) => new Promise((res, rej) => {
    const t = db.transaction('projects', mode);
    const r = fn(t.objectStore('projects'));
    t.oncomplete = () => res(r && r.result);
    t.onerror = t.onabort = () => rej(t.error || new Error('Storage error'));
  });
  return {
    open,
    get persistent() { return !usingMem; },
    all: () => usingMem ? Promise.resolve([...mem.values()]) : tx('readonly', s => s.getAll()),
    put: p => usingMem ? (mem.set(p.id, structuredClone(p)), Promise.resolve()) : tx('readwrite', s => s.put(p)),
    del: id => usingMem ? (mem.delete(id), Promise.resolve()) : tx('readwrite', s => s.delete(id))
  };
})();

/* ───────────── templates ───────────── */
const EMPTY = { 'index.html': '', 'style.css': '', 'script.js': '' };
const newProjectObj = (name) => {
  const src = EMPTY;
  const now = Date.now();
  return { id: uid(), name: name || 'Untitled project', created: now, updated: now, active: 'index.html', files: Object.keys(src).map(n => ({ name: n, content: src[n] })) };
};

/* ───────────── state ───────────── */
const S = { project: null, docs: new Map(), active: null, rev: 0, savedRev: 0, previewOn: false, scroll: {}, run: { token: null, frame: null, lineMap: [] }, counts: { warn: 0, error: 0 } };
let cm = null;
const narrow = () => matchMedia('(max-width:699px)').matches;
let PV = null; // preview override used by the APK builder: { files, entry } (null = the open project)
const projFiles = () => PV ? PV.files : S.project.files;
const fileOf = n => projFiles().find(f => f.name === n);
const getText = n => { if (!PV) { const d = S.docs.get(n); if (d) return d.getValue(); } const f = fileOf(n); return f && !f.binary ? f.content : ''; };

/* ───────────── toast ───────────── */
let toastT;
function toast(msg, kind) {
  const t = $('#toast');
  t.textContent = msg;
  t.className = 'show' + (kind === 'error' ? ' error' : '');
  clearTimeout(toastT);
  toastT = setTimeout(() => { t.className = ''; }, kind === 'error' ? 3800 : 1900);
}

/* ───────────── sheets & dialogs ───────────── */
const sheets = [];
function sheet(title, build, opts = {}) {
  const bd = document.createElement('div');
  bd.className = 'backdrop';
  const sh = document.createElement('div');
  sh.className = 'sheet';
  sh.setAttribute('role', 'dialog');
  sh.setAttribute('aria-label', title);
  sh.innerHTML = `<div class="shead"><h2>${esc(title)}</h2><button class="btn ghost" aria-label="Close">${icon('x')}</button></div><div class="sbody"></div>`;
  bd.appendChild(sh);
  document.body.appendChild(bd);
  const api = {
    el: sh, body: sh.querySelector('.sbody'), closed: false,
    close() { if (api.closed) return; api.closed = true; bd.remove(); sheets.splice(sheets.indexOf(api), 1); if (opts.onClose) opts.onClose(); }
  };
  sheets.push(api);
  sh.querySelector('.shead .btn').onclick = () => api.close();
  let downOnBd = false;
  bd.addEventListener('pointerdown', e => { downOnBd = e.target === bd; });
  bd.addEventListener('click', e => { if (downOnBd && e.target === bd) api.close(); });
  build(api.body, api);
  return api;
}
document.addEventListener('keydown', e => { if (e.key === 'Escape' && sheets.length) sheets[sheets.length - 1].close(); });

function menuRows(items) {
  return (b, api) => {
    items.forEach(it => {
      if (it === '-') { const d = document.createElement('div'); d.className = 'sep'; b.appendChild(d); return; }
      const r = document.createElement('button');
      r.className = 'mrow' + (it.danger ? ' danger' : '');
      r.innerHTML = `${icon(it.icon)}<span>${esc(it.label)}</span>${it.sub ? `<span class="sub">${esc(it.sub)}</span>` : ''}`;
      r.onclick = () => { api.close(); setTimeout(it.run, 0); };
      b.appendChild(r);
    });
  };
}

function ask({ title, label = '', value = '', placeholder = '', ok = 'OK' }) {
  return new Promise(res => {
    let out = null;
    sheet(title, (b, api) => {
      b.innerHTML = `<label class="fld">${label ? `<span>${esc(label)}</span>` : ''}<input type="text" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="${esc(placeholder)}"></label><div class="row end"><button class="btn outline" data-x="c">Cancel</button><button class="btn primary" data-x="ok">${esc(ok)}</button></div>`;
      const inp = b.querySelector('input');
      inp.value = value;
      const done = () => { out = inp.value; api.close(); };
      b.querySelector('[data-x=ok]').onclick = done;
      b.querySelector('[data-x=c]').onclick = () => api.close();
      inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); done(); } });
      setTimeout(() => { inp.focus(); inp.select(); }, 60);
    }, { onClose: () => res(out) });
  });
}
function confirmBox({ title, message, ok = 'OK', danger = false }) {
  return new Promise(res => {
    let out = false;
    sheet(title, (b, api) => {
      b.innerHTML = `<p class="msg">${esc(message)}</p><div class="row end"><button class="btn outline" data-x="c">Cancel</button><button class="btn ${danger ? 'outline danger' : 'primary'}" data-x="ok">${esc(ok)}</button></div>`;
      b.querySelector('[data-x=ok]').onclick = () => { out = true; api.close(); };
      b.querySelector('[data-x=c]').onclick = () => api.close();
    }, { onClose: () => res(out) });
  });
}

/* ───────────── editor ───────────── */
const OPEN = { '(': ')', '[': ']', '{': '}', '"': '"', "'": "'", '`': '`' };
const CLOSERS = new Set([')', ']', '}', '"', "'", '`']);
const VOIDS = new Set('area base br col embed hr img input link meta param source track wbr'.split(' '));

function autoPair(c, t) {
  if (c.somethingSelected()) return;
  const cur = c.getCursor();
  const line = c.getLine(cur.line);
  const prev = line[cur.ch - 2] || '';
  const next = line[cur.ch] || '';
  const isQuote = t === '"' || t === "'" || t === '`';
  // typing a closer that already sits right after the cursor: step over it
  if (CLOSERS.has(t) && next === t && !(isQuote && /\w/.test(prev) && t === "'")) {
    c.replaceRange('', { line: cur.line, ch: cur.ch - 1 }, cur);
    c.setCursor({ line: cur.line, ch: cur.ch });
    return;
  }
  if (OPEN[t]) {
    const okNext = !next || /[\s)\]}>,;:.]/.test(next);
    const okPrev = !isQuote || !/[\w\\'"`]/.test(prev);
    if (okNext && okPrev) c.replaceSelection(OPEN[t], 'start');
    return;
  }
  if (t === '>' && /^(html?|xml|svg)$/.test(ext(S.active || ''))) {
    const md = c.getModeAt(cur);
    if (md && (md.name === 'javascript' || md.name === 'css')) return;
    const upto = line.slice(0, cur.ch);
    const m = /<([A-Za-z][\w:-]*)(?:\s[^<>]*?)?>$/.exec(upto);
    if (m && !/\/>$/.test(upto) && !VOIDS.has(m[1].toLowerCase()) && !/^<\//.test(upto.slice(upto.lastIndexOf('<')))) {
      c.replaceSelection('</' + m[1] + '>', 'start');
    }
  }
}

function smartEnter(c) {
  if (c.somethingSelected()) return CodeMirror.Pass;
  const cur = c.getCursor();
  const line = c.getLine(cur.line);
  const before = line.slice(0, cur.ch), after = line.slice(cur.ch);
  const between = ('{[('.includes(before.slice(-1)) && before.slice(-1) && OPEN[before.slice(-1)] === after[0]) || (/>$/.test(before) && /^<\//.test(after));
  if (!between) return CodeMirror.Pass;
  const L = cur.line;
  c.operation(() => {
    c.replaceSelection('\n\n', 'end');
    c.indentLine(L + 2, 'smart', true);
    c.indentLine(L + 1, 'smart', true);
    const indentOf = n => /^\s*/.exec(c.getLine(n))[0].length;
    if (indentOf(L + 1) <= indentOf(L)) c.indentLine(L + 1, 'add', true);
    c.setCursor({ line: L + 1, ch: c.getLine(L + 1).length });
  });
}

function smartBackspace(c) {
  if (c.somethingSelected()) return CodeMirror.Pass;
  const cur = c.getCursor();
  const line = c.getLine(cur.line);
  const a = line[cur.ch - 1], b = line[cur.ch];
  if (a && OPEN[a] && OPEN[a] === b) { c.replaceRange('', { line: cur.line, ch: cur.ch - 1 }, { line: cur.line, ch: cur.ch + 1 }); return; }
  return CodeMirror.Pass;
}

function buildEditor() {
  cm = CodeMirror($('#editor'), {
    value: '', theme: 'cx', lineNumbers: true, lineWrapping: prefs.wrap,
    indentUnit: 2, tabSize: 2, indentWithTabs: false, smartIndent: true, electricChars: true,
    matchBrackets: true, styleActiveLine: true,
    spellcheck: false, autocorrect: false, autocapitalize: false,
    hintOptions: { completeSingle: false },
    extraKeys: {
      'Tab': c => c.somethingSelected() ? c.execCommand('indentMore') : c.execCommand('insertSoftTab'),
      'Shift-Tab': c => c.execCommand('indentLess'),
      'Enter': smartEnter,
      'Backspace': smartBackspace,
      'Ctrl-S': () => save(true), 'Cmd-S': () => save(true),
      'Ctrl-Enter': () => run(), 'Cmd-Enter': () => run(),
      'Ctrl-F': () => openFind(), 'Cmd-F': () => openFind(),
      'Ctrl-/': c => c.toggleComment && c.toggleComment(), 'Cmd-/': c => c.toggleComment && c.toggleComment(),
      'Ctrl-Space': c => c.showHint && c.showHint({ completeSingle: false })
    }
  });
  cm.getWrapperElement().style.fontSize = '';
  document.documentElement.style.setProperty('--fs', prefs.fontSize + 'px');

  cm.on('inputRead', (c, ch) => {
    if (ch.origin !== '+input' || ch.text.length !== 1 || ch.text[0].length !== 1) return;
    const t = ch.text[0];
    autoPair(c, t);
    if (CodeMirror.showHint && !c.state.completionActive && /[\w<.-]/.test(t)) {
      clearTimeout(buildEditor.hintT);
      buildEditor.hintT = setTimeout(() => {
        const cur = c.getCursor();
        const w = c.getRange({ line: cur.line, ch: Math.max(0, cur.ch - 2) }, cur);
        if (/^[\w<.-]{2}$/.test(w) || t === '<' || t === '.') { try { c.showHint({ completeSingle: false }); } catch { /* hint unavailable */ } }
      }, 200);
    }
  });
  cm.on('change', () => {
    markDirty();
    if (!$('#findbar').hidden) { clearTimeout(refreshFind.t); refreshFind.t = setTimeout(refreshFind, 250); }
    if (prefs.live && S.previewOn) { clearTimeout(run.t); run.t = setTimeout(() => run(false), 650); }
  });
  new ResizeObserver(() => cm.refresh()).observe($('#editorWrap'));
}

function setFontSize(px) {
  prefs.fontSize = Math.max(10, Math.min(26, px));
  document.documentElement.style.setProperty('--fs', prefs.fontSize + 'px');
  cm.refresh();
  savePrefs();
}
function setWrap(on) { prefs.wrap = on; cm.setOption('lineWrapping', on); savePrefs(); }

/* quick-key bar */
function bindTap(el, fn) {
  let sx = 0, sy = 0, moved = false;
  el.addEventListener('touchstart', e => { const t = e.touches[0]; sx = t.clientX; sy = t.clientY; moved = false; }, { passive: true });
  el.addEventListener('touchmove', e => { const t = e.touches[0]; if (Math.abs(t.clientX - sx) > 8 || Math.abs(t.clientY - sy) > 8) moved = true; }, { passive: true });
  el.addEventListener('touchend', e => { if (!moved) { e.preventDefault(); fn(); } });
  el.addEventListener('mousedown', e => e.preventDefault()); // keep the editor focused (keeps the keyboard open)
  el.addEventListener('click', () => fn());
}
function buildKeys() {
  const bar = $('#keys');
  const add = (html, label, fn, cls = '') => {
    const b = document.createElement('button');
    b.className = 'key ' + cls; b.innerHTML = html; b.setAttribute('aria-label', label); b.type = 'button';
    bindTap(b, fn); bar.appendChild(b);
  };
  add('Tab', 'Insert tab', () => { cm.execCommand(cm.somethingSelected() ? 'indentMore' : 'insertSoftTab'); cm.focus(); }, 'sp');
  add(icon('undo'), 'Undo', () => { cm.undo(); cm.focus(); });
  add(icon('redo'), 'Redo', () => { cm.redo(); cm.focus(); });
  add(icon('search'), 'Find and replace', () => openFind());
  '< > / { } ( ) [ ] ; : = " \' ` $ # & | _ - + * ! . , ? \\ %'.split(' ').forEach(ch => {
    add(esc(ch), 'Insert ' + ch, () => { cm.replaceSelection(ch, 'end'); autoPair(cm, ch); cm.focus(); });
  });
}

/* ───────────── find & replace ───────────── */
const F = { marks: [], cs: false, re: false };
function compileFind(global = true) {
  const q = $('#findIn').value;
  if (!q) return null;
  try { return new RegExp(F.re ? q : q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), (global ? 'g' : '') + (F.cs ? '' : 'i')); } catch { return false; }
}
function allMatches() {
  const rx = compileFind(); if (!rx) return rx === false ? false : [];
  const text = cm.getValue(), out = []; let m;
  while ((m = rx.exec(text)) && out.length < 5000) {
    if (m[0] === '') { rx.lastIndex++; continue; }
    out.push({ s: m.index, e: m.index + m[0].length, t: m[0] });
  }
  return out;
}
function refreshFind() {
  F.marks.forEach(m => m.clear()); F.marks = [];
  const ms = allMatches(), lbl = $('#findCount');
  if (ms === false) { lbl.textContent = 'Invalid pattern'; return ms; }
  ms.slice(0, 400).forEach(m => F.marks.push(cm.markText(cm.posFromIndex(m.s), cm.posFromIndex(m.e), { className: 'cm-find' })));
  lbl.textContent = $('#findIn').value ? (ms.length ? ms.length + (ms.length === 1 ? ' match' : ' matches') : 'No matches') : '';
  return ms;
}
function gotoMatch(dir) {
  const ms = refreshFind(); if (!ms || !ms.length) return;
  const from = cm.indexFromPos(cm.getCursor('from')), to = cm.indexFromPos(cm.getCursor('to'));
  let hit;
  if (dir > 0) hit = ms.find(m => m.s >= to) || ms[0];
  else hit = [...ms].reverse().find(m => m.e <= from) || ms[ms.length - 1];
  cm.setSelection(cm.posFromIndex(hit.s), cm.posFromIndex(hit.e));
  cm.scrollIntoView({ from: cm.posFromIndex(hit.s), to: cm.posFromIndex(hit.e) }, 60);
}
function replacement(matched) {
  const r = $('#replIn').value;
  if (!F.re) return r;
  const one = compileFind(false);
  return one ? matched.replace(one, r) : r;
}
function replaceOne() {
  const sel = cm.getSelection(), rx = compileFind(false);
  if (sel && rx) { const m = rx.exec(sel); if (m && m[0] === sel) cm.replaceSelection(replacement(sel), 'around'); }
  gotoMatch(1);
}
function replaceAll() {
  const ms = allMatches();
  if (!ms || !ms.length) { toast(ms === false ? 'Invalid pattern' : 'No matches', 'error'); return; }
  cm.operation(() => {
    for (let i = ms.length - 1; i >= 0; i--) cm.replaceRange(replacement(ms[i].t), cm.posFromIndex(ms[i].s), cm.posFromIndex(ms[i].e));
  });
  refreshFind();
  toast('Replaced ' + ms.length + (ms.length === 1 ? ' match' : ' matches'));
}
function openFind() {
  $('#findbar').hidden = false;
  const sel = cm.getSelection();
  if (sel && !sel.includes('\n')) $('#findIn').value = sel;
  refreshFind();
  $('#findIn').focus(); $('#findIn').select();
}
function closeFind() {
  $('#findbar').hidden = true;
  F.marks.forEach(m => m.clear()); F.marks = [];
  cm.focus();
}

/* ───────────── projects & files ───────────── */
function markDirty() {
  S.rev++;
  $('#dirtyDot').hidden = false;
  clearTimeout(markDirty.t);
  markDirty.t = setTimeout(() => save(false), 1200);
}
function snapshot() {
  const p = S.project;
  p.files.forEach(f => { if (!f.binary) { const d = S.docs.get(f.name); if (d) f.content = d.getValue(); } });
  p.active = S.active;
  p.updated = Date.now();
  return p;
}
async function save(manual) {
  clearTimeout(markDirty.t);
  if (!S.project) return;
  const rev = S.rev;
  snapshot();
  try {
    await DB.put(S.project);
    if (S.rev === rev) $('#dirtyDot').hidden = true;
    if (manual) toast(DB.persistent ? 'Saved' : 'Saved for this session only (browser storage is unavailable)', DB.persistent ? '' : 'error');
  } catch (e) { toast('Could not save: ' + (e && e.message || e), 'error'); }
}

function makeDoc(f) { return CodeMirror.Doc(f.content || '', modeFor(f.name)); }

async function openProject(p) {
  if (S.project && S.project.id !== p.id) await save(false);
  S.project = p; S.docs.clear(); S.scroll = {};
  p.files.forEach(f => { if (!f.binary) S.docs.set(f.name, makeDoc(f)); });
  lsSet('codex.last', p.id);
  $('#projName').textContent = p.name;
  S.active = null;
  setActive(fileOf(p.active) ? p.active : p.files[0].name, true);
  $('#dirtyDot').hidden = true;
  clearConsole();
  if (S.previewOn) run(false); else resetFrame();
}

function setActive(name, initial) {
  if (S.active && !initial) { const si = cm.getScrollInfo(); S.scroll[S.active] = { x: si.left, y: si.top }; }
  S.active = name;
  const f = fileOf(name);
  const bin = $('#binView');
  if (f && f.binary) {
    bin.hidden = false;
    const isImg = /^image\//.test(mimeOf(name));
    let url = '';
    if (isImg) url = URL.createObjectURL(new Blob([f.data], { type: mimeOf(name) }));
    bin.innerHTML = `${isImg ? `<img alt="" src="${url}">` : icon('file')}<div><strong style="color:var(--text)">${esc(name)}</strong><br>Binary asset (${(f.data.byteLength / 1024).toFixed(1)} KB). Use it from HTML or CSS by file name. Tap the tab to rename or delete it.</div>`;
  } else {
    bin.hidden = true;
    cm.swapDoc(S.docs.get(name));
    cm.setOption('mode', modeFor(name));
    const sc = S.scroll[name]; if (sc) cm.scrollTo(sc.x, sc.y);
    cm.refresh();
  }
  renderTabs();
  if (!initial) markDirty();
}

function renderTabs() {
  const list = $('#tabList');
  list.innerHTML = '';
  S.project.files.forEach(f => {
    const b = document.createElement('button');
    const sel = f.name === S.active;
    b.className = 'tab'; b.type = 'button'; b.setAttribute('role', 'tab'); b.setAttribute('aria-selected', sel);
    b.style.setProperty('--tc', colorFor(f.name));
    b.innerHTML = `<i></i><span>${esc(f.name)}</span>${sel ? icon('chev', 'sm') : ''}`;
    b.onclick = () => sel ? fileMenu() : setActive(f.name);
    list.appendChild(b);
    if (sel) requestAnimationFrame(() => b.scrollIntoView({ inline: 'nearest', block: 'nearest' }));
  });
}

const cleanName = v => {
  let n = String(v || '').trim().replace(/\\/g, '/').replace(/^(\.\/|\/)+/, '');
  if (!n || n.endsWith('/') || n.split('/').some(s => s === '..' || s === '') || /[<>:"|?*\u0000-\u001f]/.test(n) || n.length > 120) return null;
  return n;
};

function addTextFile(name, content) {
  const f = { name, content };
  S.project.files.push(f);
  S.docs.set(name, makeDoc(f));
}

function newFileSheet() {
  sheet('New file', (b, api) => {
    b.innerHTML = `<label class="fld"><span>File name</span><input type="text" autocomplete="off" autocapitalize="off" spellcheck="false" value="untitled.js"></label>
      <div class="chips">${['.html', '.css', '.js', '.json', '.md', '.svg', '.py'].map(e => `<button class="chip" data-e="${e}">${e}</button>`).join('')}</div>
      <div class="row"><button class="btn primary" data-x="ok">Create file</button><button class="btn outline" data-x="up">${icon('upl')}Upload from device</button></div>`;
    const inp = b.querySelector('input');
    b.querySelectorAll('.chip').forEach(c => c.onclick = () => { inp.value = inp.value.replace(/\.[^./]*$/, '') + c.dataset.e; inp.focus(); });
    const done = () => {
      const n = cleanName(inp.value);
      if (!n) return toast('Enter a valid file name', 'error');
      if (fileOf(n)) return toast(n + ' already exists', 'error');
      api.close();
      addTextFile(n, '');
      setActive(n);
      cm.focus();
    };
    b.querySelector('[data-x=ok]').onclick = done;
    b.querySelector('[data-x=up]').onclick = () => { api.close(); $('#fileUpload').click(); };
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); done(); } });
    setTimeout(() => { inp.focus(); inp.setSelectionRange(0, inp.value.lastIndexOf('.')); }, 60);
  });
}

function fileMenu() {
  const f = fileOf(S.active); if (!f) return;
  sheet(f.name, menuRows([
    { icon: 'pencil', label: 'Rename file', run: () => renameFile(f) },
    { icon: 'copy', label: 'Duplicate file', run: () => duplicateFile(f) },
    { icon: 'down', label: 'Download this file', run: () => downloadFile(f) },
    '-',
    { icon: 'trash', label: 'Delete file', danger: true, run: () => deleteFile(f) }
  ]));
}

async function renameFile(f) {
  const v = await ask({ title: 'Rename file', value: f.name, ok: 'Rename' });
  if (v === null) return;
  const n = cleanName(v);
  if (!n) return toast('That file name is not valid', 'error');
  if (n === f.name) return;
  if (fileOf(n)) return toast(n + ' already exists', 'error');
  if (!f.binary) { S.docs.set(n, S.docs.get(f.name)); S.docs.delete(f.name); }
  if (S.scroll[f.name]) { S.scroll[n] = S.scroll[f.name]; delete S.scroll[f.name]; }
  f.name = n;
  S.active = n;
  if (!f.binary) cm.setOption('mode', modeFor(n));
  renderTabs(); markDirty();
  toast('Renamed to ' + n);
}
function duplicateFile(f) {
  let n = f.name.replace(/(\.[^./]*)?$/, m => '-copy' + (m || ''));
  for (let i = 2; fileOf(n); i++) n = f.name.replace(/(\.[^./]*)?$/, m => '-copy' + i + (m || ''));
  if (f.binary) S.project.files.push({ name: n, binary: true, data: f.data.slice(0) });
  else addTextFile(n, getText(f.name));
  setActive(n);
}
async function deleteFile(f) {
  if (S.project.files.length <= 1) return toast('A project needs at least one file', 'error');
  if (!await confirmBox({ title: 'Delete file', message: `Delete ${f.name}? This cannot be undone.`, ok: 'Delete', danger: true })) return;
  const i = S.project.files.indexOf(f);
  S.project.files.splice(i, 1);
  S.docs.delete(f.name);
  delete S.scroll[f.name];
  S.active = null;
  setActive(S.project.files[Math.max(0, i - 1)].name);
  toast('Deleted ' + f.name);
}

/* projects sheet */
async function projectsSheet() {
  await save(false);
  const list = (await DB.all()).sort((a, b) => b.updated - a.updated);
  sheet('Projects', (b, api) => {
    b.innerHTML = `<div class="row"><button class="btn primary" data-x="new">${icon('plus')}New project</button><button class="btn outline" data-x="imp">${icon('upl')}Import HTML or ZIP</button></div><ul class="plist"></ul>`;
    b.querySelector('[data-x=new]').onclick = () => { api.close(); newProjectSheet(); };
    b.querySelector('[data-x=imp]').onclick = () => { api.close(); $('#fileImport').click(); };
    const ul = b.querySelector('.plist');
    list.forEach(p => {
      const li = document.createElement('li');
      li.className = 'prow' + (p.id === S.project.id ? ' cur' : '');
      li.innerHTML = `<button class="open"><strong>${esc(p.name)}</strong><small>${p.files.length} file${p.files.length === 1 ? '' : 's'}, edited ${ago(p.updated)}</small></button><button class="btn ghost" data-a="ren" aria-label="Rename ${esc(p.name)}">${icon('pencil')}</button><button class="btn ghost danger" data-a="del" aria-label="Delete ${esc(p.name)}">${icon('trash')}</button>`;
      li.querySelector('.open').onclick = async () => { api.close(); if (p.id !== S.project.id) { await openProject(p); toast('Opened ' + p.name); } };
      li.querySelector('[data-a=ren]').onclick = async () => {
        const v = await ask({ title: 'Rename project', value: p.name, ok: 'Rename' });
        if (v === null || !v.trim()) return;
        p.name = v.trim();
        if (p.id === S.project.id) { S.project.name = p.name; $('#projName').textContent = p.name; await save(false); } else await DB.put(p);
        api.close(); projectsSheet();
      };
      li.querySelector('[data-a=del]').onclick = async () => {
        if (!await confirmBox({ title: 'Delete project', message: `Delete "${p.name}" and all of its files? This cannot be undone.`, ok: 'Delete', danger: true })) return;
        await DB.del(p.id);
        api.close();
        if (p.id === S.project.id) {
          clearTimeout(markDirty.t);
          const rest = (await DB.all()).sort((a, b) => b.updated - a.updated);
          S.project = null;
          if (rest.length) await openProject(rest[0]); else { const np = newProjectObj('My First Project'); await DB.put(np); await openProject(np); }
        }
        toast('Deleted ' + p.name);
        projectsSheet();
      };
      ul.appendChild(li);
    });
  });
}
function newProjectSheet() {
  sheet('New project', (b, api) => {
    b.innerHTML = `<label class="fld"><span>Project name</span><input type="text" autocomplete="off" spellcheck="false" value="Untitled project"></label>
      <div class="row end"><button class="btn outline" data-x="c">Cancel</button><button class="btn primary" data-x="ok">Create project</button></div>`;
    const inp = b.querySelector('input');
    const done = async () => {
      api.close();
      const p = newProjectObj(inp.value.trim() || 'Untitled project');
      await DB.put(p); await openProject(p); toast('Created ' + p.name);
    };
    b.querySelector('[data-x=ok]').onclick = done;
    b.querySelector('[data-x=c]').onclick = () => api.close();
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); done(); } });
    setTimeout(() => { inp.focus(); inp.select(); }, 60);
  });
}

/* ───────────── import ───────────── */
async function importProjectFile(file) {
  try {
    const name = file.name.replace(/\.[^.]+$/, '') || 'Imported';
    let files = [];
    if (/\.zip$/i.test(file.name)) {
      if (!window.JSZip) return toast('ZIP support did not load. Check your connection and reload.', 'error');
      const zip = await JSZip.loadAsync(file);
      const entries = [];
      zip.forEach((path, e) => { if (!e.dir && !/(^|\/)(__MACOSX|\.DS_Store|Thumbs\.db)/.test(path)) entries.push([path, e]); });
      if (!entries.length) return toast('That ZIP file is empty', 'error');
      const roots = new Set(entries.map(([p]) => p.split('/')[0]));
      const strip = roots.size === 1 && entries.every(([p]) => p.includes('/')) ? [...roots][0] + '/' : '';
      for (const [path, e] of entries) {
        const n = cleanName(strip ? path.slice(strip.length) : path);
        if (!n) continue;
        if (TEXT_EXT.has(ext(n))) files.push({ name: n, content: await e.async('string') });
        else files.push({ name: n, binary: true, data: await e.async('arraybuffer') });
      }
    } else {
      files.push({ name: 'index.html', content: await file.text() });
    }
    if (!files.length) return toast('Nothing to import', 'error');
    const rank = n => ['index.html', 'style.css', 'script.js'].indexOf(n);
    files.sort((a, b) => (rank(a.name) < 0 ? 9 : rank(a.name)) - (rank(b.name) < 0 ? 9 : rank(b.name)) || a.name.localeCompare(b.name));
    const now = Date.now();
    const p = { id: uid(), name, created: now, updated: now, active: (files.find(f => isHtmlName(f.name)) || files[0]).name, files };
    await DB.put(p);
    await openProject(p);
    toast(`Imported ${files.length} file${files.length === 1 ? '' : 's'}`);
  } catch (e) { toast('Import failed: ' + (e && e.message || e), 'error'); }
}
async function uploadFiles(list) {
  for (const file of list) {
    let n = cleanName(file.name) || 'upload';
    if (fileOf(n)) { const m = /^(.*?)(\.[^.]*)?$/.exec(n); let i = 2; while (fileOf(`${m[1]}-${i}${m[2] || ''}`)) i++; n = `${m[1]}-${i}${m[2] || ''}`; }
    if (TEXT_EXT.has(ext(n))) addTextFile(n, await file.text());
    else S.project.files.push({ name: n, binary: true, data: await file.arrayBuffer() });
    setActive(n);
  }
  toast(`Added ${list.length} file${list.length === 1 ? '' : 's'}`);
}

/* ───────────── export ───────────── */
function download(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = name; a.rel = 'noopener';
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 15000);
  toast('Downloaded ' + name);
}
function downloadFile(f) {
  if (f.binary) return download(new Blob([f.data], { type: mimeOf(f.name) }), base(f.name));
  download(new Blob([getText(f.name)], { type: mimeOf(f.name) + ';charset=utf-8' }), base(f.name));
}
async function exportZip() {
  if (!window.JSZip) return toast('ZIP support did not load. Check your connection and reload.', 'error');
  try {
    const zip = new JSZip();
    S.project.files.forEach(f => zip.file(f.name, f.binary ? f.data : getText(f.name)));
    const blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE' });
    download(blob, slug(S.project.name) + '.zip');
  } catch (e) { toast('ZIP export failed: ' + (e && e.message || e), 'error'); }
}
function exportStandalone() {
  const built = build({ token: null });
  if (!built) return toast('Add an HTML file first', 'error');
  download(new Blob([built.html], { type: 'text/html;charset=utf-8' }), slug(S.project.name) + '.html');
}

/* ───────────── preview: build the document ───────────── */
function preludeFn(T, FILES, NAV) {
  var P = window.parent;
  function send(o) { o.cx = T; try { P.postMessage(o, '*'); } catch (e) { /* ignore */ } }
  function str(v, d) {
    d = d || 0;
    try {
      if (v === null) return 'null';
      if (v === undefined) return 'undefined';
      var t = typeof v;
      if (t === 'string') return d ? JSON.stringify(v) : v;
      if (t === 'function') return 'ƒ ' + (v.name || '(anonymous)') + '()';
      if (t !== 'object') return String(v) + (t === 'bigint' ? 'n' : '');
      if (v instanceof Error) return v.stack || String(v);
      if (typeof Node !== 'undefined' && v instanceof Node) return v.nodeType === 1 ? v.outerHTML.slice(0, 200) : String(v);
      if (d > 2) return Array.isArray(v) ? '[…]' : '{…}';
      if (Array.isArray(v)) return '[' + v.map(function (x) { return str(x, d + 1); }).join(', ') + ']';
      var ks = Object.keys(v);
      var nm = v.constructor && v.constructor.name && v.constructor.name !== 'Object' ? v.constructor.name + ' ' : '';
      return nm + '{' + ks.slice(0, 30).map(function (k) { return k + ': ' + str(v[k], d + 1); }).join(', ') + (ks.length > 30 ? ', …' : '') + '}';
    } catch (e) { return '[unprintable]'; }
  }
  ['log', 'info', 'warn', 'error', 'debug'].forEach(function (l) {
    var o = console[l];
    console[l] = function () {
      var a = [].slice.call(arguments);
      send({ type: 'console', level: l === 'debug' || l === 'info' ? 'log' : l, text: a.map(function (x) { return str(x, 0); }).join(' ') });
      try { o.apply(console, arguments); } catch (e) { /* ignore */ }
    };
  });
  console.clear = function () { send({ type: 'clear' }); };
  window.addEventListener('error', function (e) {
    if (e.target && e.target !== window) {
      var t = e.target;
      send({ type: 'console', level: 'error', text: 'Failed to load <' + String(t.tagName).toLowerCase() + '> ' + (t.src || t.href || '') });
      return;
    }
    send({ type: 'error', message: e.message, line: e.lineno, col: e.colno });
  }, true);
  window.addEventListener('unhandledrejection', function (e) {
    var r = e.reason;
    send({ type: 'error', message: 'Unhandled promise rejection: ' + (r && r.message ? r.message : str(r, 1)) });
  });
  window.addEventListener('message', function (e) {
    var d = e.data;
    if (!d || d.cx !== T || d.type !== 'eval') return;
    try { send({ type: 'console', level: 'result', text: str((0, eval)(d.code), 1) }); }
    catch (err) { send({ type: 'console', level: 'error', text: String(err) }); }
  });
  if (NAV) {
    document.addEventListener('click', function (e) {
      var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
      if (!a) return;
      var h = a.getAttribute('href');
      if (!h || h.charAt(0) === '#' || /^([a-z][a-z0-9+.-]*:|\/\/)/i.test(h)) return;
      e.preventDefault();
      send({ type: 'nav', href: h });
    }, true);
  }
  var of = window.fetch;
  if (of) {
    window.fetch = function (u) {
      if (typeof u === 'string') {
        var k = u.replace(/^\.?\//, '').split(/[?#]/)[0];
        if (Object.prototype.hasOwnProperty.call(FILES, k)) return Promise.resolve(new Response(FILES[k].t, { status: 200, headers: { 'Content-Type': FILES[k].m } }));
      }
      return of.apply(this, arguments);
    };
  }
}
const safeJson = x => JSON.stringify(x).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
function preludeHtml(token, nav) {
  const data = {};
  projFiles().forEach(f => { if (!f.binary && !isCodeName(f.name) && /^(json|txt|csv|md|xml|svg)$/.test(ext(f.name))) data[f.name] = { t: getText(f.name), m: mimeOf(f.name) }; });
  return `<script>(${preludeFn.toString()})(${safeJson(token)},${safeJson(data)},${nav ? 'true' : 'false'});<\/script>`;
}

function resolveRef(ref, fromFile) {
  if (!ref) return null;
  ref = ref.trim();
  if (/^(?:[a-z][a-z0-9+.-]*:|\/\/|#)/i.test(ref)) return null;
  let p = ref.split(/[?#]/)[0];
  try { p = decodeURIComponent(p); } catch { /* keep raw */ }
  const dir = fromFile.includes('/') ? fromFile.slice(0, fromFile.lastIndexOf('/') + 1) : '';
  p = p.startsWith('/') ? p.slice(1) : dir + p;
  const parts = [];
  p.split('/').forEach(s => { if (s === '' || s === '.') return; if (s === '..') parts.pop(); else parts.push(s); });
  const name = parts.join('/');
  return projFiles().find(f => f.name === name) || null;
}
const attrOf = (tag, name) => { const m = new RegExp('\\b' + name + '\\s*=\\s*(?:"([^"]*)"|\'([^\']*)\'|([^\\s>]+))', 'i').exec(tag); return m ? (m[1] ?? m[2] ?? m[3]) : null; };

function build(opts) {
  const cache = new Map();
  const dataUrl = f => {
    if (!cache.has(f.name)) cache.set(f.name, 'data:' + mimeOf(f.name) + ';base64,' + b64(f.binary ? new Uint8Array(f.data) : new TextEncoder().encode(getText(f.name))));
    return cache.get(f.name);
  };
  // choose the page to run
  const act = PV ? fileOf(PV.entry) : fileOf(S.active);
  let entry = null;
  if (act && !act.binary && isHtmlName(act.name)) entry = act.name;
  else { const h = fileOf('index.html') || projFiles().find(f => !f.binary && isHtmlName(f.name)); if (h) entry = h.name; }
  let src, entryName;
  if (entry) { src = getText(entry); entryName = entry; }
  else if (act && !act.binary && /\.m?js$/i.test(act.name)) {
    src = `<!DOCTYPE html>\n<html><head><meta charset="utf-8"></head><body>\n<script src="${esc(act.name)}"><\/script>\n</body></html>`;
    entryName = '(runner)';
  } else return null;

  const assetText = t => t
    .replace(/\b(src|poster)\s*=\s*(["'])(.*?)\2/gi, (m0, a, q, v) => { const f = resolveRef(v, entryName === '(runner)' ? '' : entryName); return f && !isCodeName(f.name) ? `${a}=${q}${dataUrl(f)}${q}` : m0; })
    .replace(/(<link\b[^>]*?\bhref\s*=\s*)(["'])(.*?)\2/gi, (m0, pre, q, v) => { const f = resolveRef(v, entryName === '(runner)' ? '' : entryName); return f && !isCodeName(f.name) ? `${pre}${q}${dataUrl(f)}${q}` : m0; })
    .replace(/url\(\s*(["']?)([^"')]+)\1\s*\)/gi, (m0, q, v) => { const f = resolveRef(v, entryName === '(runner)' ? '' : entryName); return f && !isCodeName(f.name) ? `url("${dataUrl(f)}")` : m0; });
  const cssText = (t, from) => t.replace(/url\(\s*(["']?)([^"')]+)\1\s*\)/gi, (m0, q, v) => { const f = resolveRef(v, from); return f && !isCodeName(f.name) ? `url("${dataUrl(f)}")` : m0; });

  const pieces = [];
  const push = (text, file, line) => { if (text) pieces.push({ text, file, line }); };
  let insertAt = 0;
  { const h = /<head\b[^>]*>/i.exec(src) || /<html\b[^>]*>/i.exec(src) || /<!doctype[^>]*>/i.exec(src); if (h) insertAt = h.index + h[0].length; }
  let preludeDone = !opts.token;
  let pos = 0, ln = 1;
  const emit = to => { if (to > pos) { const t = src.slice(pos, to); push(assetText(t), entryName, ln); ln += countNl(t); pos = to; } };
  const doPrelude = () => { if (!preludeDone) { preludeDone = true; push(preludeHtml(opts.token, opts.nav), null, 0); } };

  const rx = /<link\b[^>]*>|<script\b[^>]*\bsrc\s*=[^>]*>\s*<\/script\s*>/gi;
  let m;
  while ((m = rx.exec(src))) {
    if (!preludeDone && insertAt <= m.index) { emit(insertAt); doPrelude(); }
    emit(m.index);
    const tag = m[0];
    let repl = null;
    if (/^<link/i.test(tag)) {
      if (/stylesheet/i.test(attrOf(tag, 'rel') || '')) {
        const f = resolveRef(attrOf(tag, 'href'), entryName === '(runner)' ? '' : entryName);
        if (f && !f.binary) repl = { open: '<style>', body: cssText(getText(f.name), f.name), close: '\n</style>', file: f.name };
      }
    } else {
      const f = resolveRef(attrOf(tag, 'src'), entryName === '(runner)' ? '' : entryName);
      if (f && !f.binary) {
        const attrs = /^<script\b([^>]*)>/i.exec(tag)[1].replace(/\bsrc\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/i, '').replace(/\s+$/, '');
        repl = { open: `<script${attrs}>`, body: getText(f.name).replace(/<\/(script)/gi, '<\\/$1'), close: '\n<\/script>', file: f.name };
      }
    }
    if (repl) {
      push(repl.open, entryName, ln);
      push('\n' + repl.body, repl.file, 0);
      push(repl.close, entryName, ln);
      ln += countNl(tag);
      pos = m.index + tag.length;
    }
  }
  if (!preludeDone) { emit(insertAt); doPrelude(); }
  emit(src.length);

  const lineMap = [];
  pieces.forEach(p => p.text.split('\n').forEach((_, i) => {
    if (i === 0) { if (!lineMap.length) lineMap.push({ file: p.file, line: p.line }); } else lineMap.push({ file: p.file, line: p.line + i });
  }));
  return { html: pieces.map(p => p.text).join(''), lineMap, entry: entryName };
}

/* ───────────── preview: run & console ───────────── */
function resetFrame() {
  const wrap = $('#frameWrap');
  wrap.innerHTML = '';
  $('#emptyPrev').hidden = false;
  S.run = { token: null, frame: null, lineMap: [] };
}
function run(manual = true) {
  if (!S.project) return;
  const token = uid();
  const built = build({ token });
  if (!built) { toast('Nothing to run. Add an .html file, or open a .js file.', 'error'); return; }
  clearConsole();
  const wrap = $('#frameWrap');
  wrap.innerHTML = '';
  const fr = document.createElement('iframe');
  fr.title = 'Preview';
  fr.setAttribute('sandbox', 'allow-scripts allow-modals allow-forms allow-popups allow-pointer-lock');
  fr.srcdoc = built.html;
  wrap.appendChild(fr);
  $('#emptyPrev').hidden = true;
  S.run = { token, frame: fr, lineMap: built.lineMap };
  showPreview(true);
  layoutFrame();
}
function showPreview(on) {
  S.previewOn = on;
  const w = $('#work');
  w.classList.toggle('show-preview', on);
  w.classList.toggle('split', on && prefs.split);
  if (!on) $('#previewPane').classList.remove('full');
  updateChrome();
  requestAnimationFrame(() => { cm.refresh(); layoutFrame(); });
}
function updateChrome() {
  const full = narrow() && S.previewOn && !prefs.split;
  $('#btnPreview').setAttribute('aria-pressed', S.previewOn);
  $('#btnPreview').setAttribute('aria-label', S.previewOn ? (full ? 'Back to code' : 'Hide preview') : 'Show preview');
  $('#lblPreview').textContent = full ? 'Code' : 'Preview';
  $('#icPreview').innerHTML = `<use href="#i-${full ? 'code' : 'eye'}"/>`;
  $('#pLive').setAttribute('aria-pressed', prefs.live);
  $('#icDevice').innerHTML = `<use href="#i-${prefs.device === 'mobile' ? 'phone' : 'desktop'}"/>`;
  const isFull = $('#previewPane').classList.contains('full');
  $('#icFull').innerHTML = `<use href="#i-${isFull ? 'shrink' : 'expand'}"/>`;
  $('#pFull').setAttribute('aria-label', isFull ? 'Exit fullscreen' : 'Fullscreen preview');
}
function layoutFrame() {
  const stage = $('#stage'), wrap = $('#frameWrap'), fr = wrap.firstElementChild;
  const aw = stage.clientWidth, ah = stage.clientHeight;
  if (!aw || !ah) return;
  const W = prefs.device === 'desktop' ? 1280 : Math.min(390, aw);
  const scale = Math.min(1, aw / W);
  wrap.style.width = Math.round(W * scale) + 'px';
  wrap.style.height = ah + 'px';
  $('#sizeLbl').textContent = prefs.device === 'desktop' ? `Desktop ${W}px` : `Mobile ${W}px`;
  if (fr) {
    fr.style.width = W + 'px';
    fr.style.height = Math.round(ah / scale) + 'px';
    fr.style.transform = scale < 1 ? `scale(${scale})` : '';
  }
}

function clearConsole() {
  $('#conBody').innerHTML = '';
  S.counts = { warn: 0, error: 0 };
  updateBadges();
}
function updateBadges() {
  const e = $('#cntErr'), w = $('#cntWarn');
  e.hidden = !S.counts.error; e.textContent = S.counts.error;
  w.hidden = !S.counts.warn; w.textContent = S.counts.warn;
}
function addConsole(level, text, loc) {
  const body = $('#conBody');
  const d = document.createElement('div');
  d.className = 'ln ' + level;
  d.textContent = text;
  if (loc && loc.file && loc.file !== '(runner)' && fileOf(loc.file)) {
    const b = document.createElement('button');
    b.className = 'loc'; b.type = 'button'; b.textContent = `${loc.file}:${loc.line}`;
    b.onclick = () => gotoLocation(loc.file, loc.line, loc.col);
    d.appendChild(b);
  }
  body.appendChild(d);
  while (body.childElementCount > 500) body.firstElementChild.remove();
  body.scrollTop = body.scrollHeight;
  if (level === 'warn') S.counts.warn++;
  if (level === 'error') { S.counts.error++; $('#previewPane').classList.add('con-open'); }
  updateBadges();
}
function gotoLocation(file, line, col) {
  if (S.active !== file) setActive(file);
  if (narrow() && !prefs.split) showPreview(false);
  const f = fileOf(file);
  if (f && !f.binary) {
    requestAnimationFrame(() => {
      cm.setCursor({ line: Math.max(0, line - 1), ch: Math.max(0, (col || 1) - 1) });
      cm.scrollIntoView(null, 80);
      cm.focus();
    });
  }
}
window.addEventListener('message', e => {
  const r = S.run;
  if (!r.frame || e.source !== r.frame.contentWindow) return;
  const d = e.data;
  if (!d || d.cx !== r.token) return;
  if (d.type === 'console') addConsole(d.level, d.text);
  else if (d.type === 'error') {
    const loc = d.line ? r.lineMap[d.line - 1] : null;
    addConsole('error', d.message || 'Script error', loc ? { file: loc.file, line: loc.line, col: d.col } : null);
  } else if (d.type === 'clear') clearConsole();
});

/* ───────────── menu ───────────── */
function mainMenu() {
  sheet('Menu', (b, api) => {
    b.innerHTML = '';
    const rows = menuRows([
      { icon: 'search', label: 'Find and replace', run: openFind },
      { icon: 'plus', label: 'New file', run: newFileSheet },
      { icon: 'upl', label: 'Upload files into this project', run: () => $('#fileUpload').click() },
      '-',
      { icon: 'down', label: 'Download current file', sub: fileOf(S.active) ? base(S.active) : '', run: () => downloadFile(fileOf(S.active)) },
      { icon: 'pkg', label: 'Export project as ZIP', run: exportZip },
      { icon: 'globe', label: 'Export standalone HTML', sub: 'CSS and JS embedded', run: exportStandalone },
      '-',
      { icon: 'apk', label: 'HTML to APK', sub: 'Android app', run: () => window.CodeXApk && window.CodeXApk.open('html') },
      { icon: 'pkg', label: 'ZIP to APK', sub: 'Android app', run: () => window.CodeXApk && window.CodeXApk.open('zip') },
      '-',
      { icon: 'folder', label: 'Projects', run: projectsSheet },
      { icon: 'upl', label: 'Import HTML or ZIP as new project', run: () => $('#fileImport').click() }
    ]);
    rows(b, api);
    const sep = document.createElement('div'); sep.className = 'sep'; b.appendChild(sep);
    const fs = document.createElement('div');
    fs.className = 'fsz';
    fs.innerHTML = `<span>${icon('text')}</span><button class="btn outline" data-a="-" aria-label="Smaller text">A−</button><input type="range" min="10" max="26" step="1" value="${prefs.fontSize}" aria-label="Font size"><button class="btn outline" data-a="+" aria-label="Larger text">A+</button><output>${prefs.fontSize}</output>`;
    const rg = fs.querySelector('input'), out = fs.querySelector('output');
    const set = v => { setFontSize(v); rg.value = prefs.fontSize; out.textContent = prefs.fontSize; };
    rg.oninput = () => set(+rg.value);
    fs.querySelector('[data-a="-"]').onclick = () => set(prefs.fontSize - 1);
    fs.querySelector('[data-a="+"]').onclick = () => set(prefs.fontSize + 1);
    b.appendChild(fs);
    const wr = document.createElement('button');
    wr.className = 'mrow';
    const paint = () => { wr.innerHTML = `${icon('file')}<span>Wrap long lines</span><span class="sub">${prefs.wrap ? 'On' : 'Off'}</span>`; };
    paint();
    wr.onclick = () => { setWrap(!prefs.wrap); paint(); };
    b.appendChild(wr);
  });
}

/* ───────────── wiring ───────────── */
function fitViewport() {
  const vv = window.visualViewport;
  const h = vv ? vv.height : window.innerHeight;
  document.documentElement.style.setProperty('--vh', h + 'px');
  $('#app').style.transform = vv && vv.offsetTop ? `translateY(${vv.offsetTop}px)` : '';
  if (cm) cm.refresh();
  layoutFrame();
}

function wire() {
  $('#btnProjects').onclick = projectsSheet;
  $('#btnSave').onclick = () => save(true);
  $('#btnRun').onclick = () => run(true);
  $('#btnMenu').onclick = mainMenu;
  $('#btnNewFile').onclick = newFileSheet;
  $('#btnPreview').onclick = () => { if (S.previewOn) showPreview(false); else if (S.run.frame) showPreview(true); else run(); };
  $('#pClose').onclick = () => showPreview(false);
  $('#pRefresh').onclick = () => run(true);
  $('#pLive').onclick = () => { prefs.live = !prefs.live; savePrefs(); updateChrome(); toast(prefs.live ? 'Live preview on' : 'Live preview off'); if (prefs.live) run(false); };
  $('#pDevice').onclick = () => { prefs.device = prefs.device === 'mobile' ? 'desktop' : 'mobile'; savePrefs(); updateChrome(); layoutFrame(); };
  $('#pSplit').onclick = () => { prefs.split = !prefs.split; savePrefs(); $('#work').classList.toggle('split', S.previewOn && prefs.split); updateChrome(); requestAnimationFrame(() => { cm.refresh(); layoutFrame(); }); };
  $('#pFull').onclick = () => { $('#previewPane').classList.toggle('full'); updateChrome(); requestAnimationFrame(layoutFrame); };
  $('#conToggle').onclick = () => { $('#previewPane').classList.toggle('con-open'); requestAnimationFrame(layoutFrame); };
  $('#conClear').onclick = clearConsole;
  $('#conInput').addEventListener('keydown', e => {
    if (e.key !== 'Enter') return;
    const code = e.target.value.trim(); if (!code) return;
    e.target.value = '';
    addConsole('sys', '› ' + code);
    if (S.run.frame) S.run.frame.contentWindow.postMessage({ cx: S.run.token, type: 'eval', code }, '*');
    else addConsole('error', 'Run your project first.');
  });
  new ResizeObserver(layoutFrame).observe($('#stage'));

  $('#findIn').addEventListener('input', () => refreshFind());
  $('#findIn').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); gotoMatch(e.shiftKey ? -1 : 1); } if (e.key === 'Escape') closeFind(); });
  $('#findNext').onclick = () => gotoMatch(1);
  $('#findPrev').onclick = () => gotoMatch(-1);
  $('#findClose').onclick = closeFind;
  $('#replOne').onclick = replaceOne;
  $('#replAll').onclick = replaceAll;
  $('#optCase').onclick = e => { F.cs = !F.cs; e.currentTarget.setAttribute('aria-pressed', F.cs); refreshFind(); };
  $('#optRe').onclick = e => { F.re = !F.re; e.currentTarget.setAttribute('aria-pressed', F.re); refreshFind(); };

  $('#fileImport').onchange = e => { const f = e.target.files[0]; e.target.value = ''; if (f) importProjectFile(f); };
  $('#fileUpload').onchange = e => { const l = [...e.target.files]; e.target.value = ''; if (l.length) uploadFiles(l); };

  document.addEventListener('keydown', e => {
    const mod = e.ctrlKey || e.metaKey;
    if (mod && e.key.toLowerCase() === 's') { e.preventDefault(); save(true); }
    if (mod && e.key === 'Enter') { e.preventDefault(); run(); }
  });
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') save(false); });
  window.addEventListener('pagehide', () => save(false));
  window.addEventListener('resize', () => { fitViewport(); updateChrome(); });
  if (window.visualViewport) { visualViewport.addEventListener('resize', fitViewport); visualViewport.addEventListener('scroll', fitViewport); }
  matchMedia('(max-width:699px)').addEventListener('change', () => { updateChrome(); requestAnimationFrame(() => { cm.refresh(); layoutFrame(); }); });
}

async function init() {
  if (!window.CodeMirror) {
    const d = document.createElement('div');
    d.id = 'fatal';
    d.innerHTML = '<div><h2>The editor could not load</h2><p>CodeX Studio needs to download its editor library once. Connect to the internet and reload. After the first load it works offline.</p></div>';
    document.body.appendChild(d);
    return;
  }
  fitViewport();
  buildEditor();
  buildKeys();
  wire();
  updateChrome();
  await DB.open();
  const list = await DB.all();
  let p = list.find(x => x.id === lsGet('codex.last')) || list.sort((a, b) => b.updated - a.updated)[0];
  if (!p) { p = newProjectObj('My First Project'); await DB.put(p); }
  await openProject(p);
  if (!DB.persistent) toast('Browser storage is unavailable. Projects will not be kept after you close the app.', 'error');
  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) navigator.serviceWorker.register('sw.js').catch(() => {});
}
/* API used by apk.js (HTML/ZIP to APK builder) */
function buildPreview(files, entry, token) {
  PV = { files, entry };
  try { return build({ token, nav: true }); } finally { PV = null; }
}
window.CodeX = { S, DB, sheet, toast, ask, confirmBox, icon, esc, uid, save, download, cleanName, buildPreview, TEXT_EXT, ext, base, mimeOf, isHtmlName, isCodeName };

init();
})();
