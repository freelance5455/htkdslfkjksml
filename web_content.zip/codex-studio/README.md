# CodeX Studio

Mobile-first code editor: write HTML/CSS/JS, run it in a sandboxed preview, save projects locally, export files / ZIP / standalone HTML.

## Run it
Needs HTTPS or localhost (for the PWA/offline part). First load needs internet once (editor libraries come from cdnjs; the service worker then caches them).

- Hosted: upload this folder to Netlify Drop, GitHub Pages or Cloudflare Pages, open the URL in Chrome on Android, menu > Install app.
- On the phone itself (Termux): `pkg install python`, `cd` into this folder, `python -m http.server 8080`, open http://localhost:8080 in Chrome, menu > Install app.

## Files
index.html (UI + styles), app.js (all logic), sw.js (offline cache), manifest.webmanifest, icon-192.png, icon-512.png, icon.svg

## HTML to APK / ZIP to APK
Menu (three dots) > **HTML to APK** or **ZIP to APK**. Pick a saved project, an HTML file or a ZIP, check the preview, set name / package ID / version / theme / icon, then:
- **Build APK**: needs the build server in `server/` (Node + JDK 17 + Gradle + Android SDK). See `server/README.md`. Real Gradle build, live log and progress, then a downloadable debug-signed APK.
- **Export Android project**: works with no server. Gives a complete Gradle project, a GitHub Actions workflow and `README-BUILD.md`.
