/* CodeX Studio service worker: offline app shell + cached CDN libraries */
const V = 'codex-v2';
const SHELL = ['./', 'index.html', 'app.js', 'apkgen.js', 'apk.js', 'manifest.webmanifest', 'icon.svg', 'icon-192.png', 'icon-512.png'];

// Keep in sync with the <script>/<link> tags in index.html.
const CDN = 'https://cdnjs.cloudflare.com/ajax/libs/';
const LIBS = ["codemirror/5.65.16/codemirror.min.css", "codemirror/5.65.16/addon/hint/show-hint.min.css", "codemirror/5.65.16/codemirror.min.js", "codemirror/5.65.16/mode/xml/xml.min.js", "codemirror/5.65.16/mode/javascript/javascript.min.js", "codemirror/5.65.16/mode/css/css.min.js", "codemirror/5.65.16/mode/htmlmixed/htmlmixed.min.js", "codemirror/5.65.16/mode/markdown/markdown.min.js", "codemirror/5.65.16/mode/python/python.min.js", "codemirror/5.65.16/mode/clike/clike.min.js", "codemirror/5.65.16/mode/yaml/yaml.min.js", "codemirror/5.65.16/mode/sql/sql.min.js", "codemirror/5.65.16/mode/shell/shell.min.js", "codemirror/5.65.16/mode/go/go.min.js", "codemirror/5.65.16/mode/rust/rust.min.js", "codemirror/5.65.16/addon/edit/matchbrackets.min.js", "codemirror/5.65.16/addon/selection/active-line.min.js", "codemirror/5.65.16/addon/comment/comment.min.js", "codemirror/5.65.16/addon/hint/show-hint.min.js", "codemirror/5.65.16/addon/hint/anyword-hint.min.js", "codemirror/5.65.16/addon/hint/html-hint.min.js", "codemirror/5.65.16/addon/hint/css-hint.min.js", "codemirror/5.65.16/addon/hint/javascript-hint.min.js", "jszip/3.10.1/jszip.min.js"];

self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const c = await caches.open(V);
    await c.addAll(SHELL);
    // Precache the editor libraries so the very first visit also works offline later.
    await Promise.allSettled(LIBS.map(async u => {
      const res = await fetch(new Request(CDN + u, { mode: 'cors' }));
      if (res.ok) await c.put(CDN + u, res);
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== V).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  if (url.origin === location.origin) {
    // network first so new versions arrive, cache fallback when offline
    e.respondWith(
      fetch(req).then(res => {
        if (res.ok) { const copy = res.clone(); caches.open(V).then(c => c.put(req, copy)); }
        return res;
      }).catch(() => caches.match(req, { ignoreSearch: true }).then(m => m || caches.match('index.html')))
    );
  } else if (url.hostname === 'cdnjs.cloudflare.com') {
    // cache first for versioned library files
    e.respondWith(
      caches.match(req, { ignoreVary: true }).then(hit => hit || fetch(req).then(res => {
        if (res.ok || res.type === 'opaque') { const copy = res.clone(); caches.open(V).then(c => c.put(req, copy)); }
        return res;
      }))
    );
  }
});
