KYY MONEY — ANDROID PROJECT
Tema hitam + emas. Aplikasi catatan pengeluaran sederhana.

CARA PALING MUDAH UNTUK DAPATKAN APK PERCUMA:
1. Buat akaun di https://github.com
2. Buat repository baharu bernama KYY-Money.
3. Upload semua fail dan folder di dalam ZIP ini (bukan ZIP itu sendiri).
4. Buka tab Actions, pilih "Build KYY Money APK", kemudian tekan Run workflow.
   Jika workflow tidak muncul, buat satu commit/push ke branch main.
5. Setelah selesai, buka run yang berjaya. Di bahagian Artifacts, download KYY-Money-APK.
6. Extract ZIP artifact itu; akan ada app-debug.apk. Buka APK pada telefon untuk install.

NOTA:
- Projek ini perlu dibina menjadi APK dahulu; ZIP ini sendiri bukan aplikasi yang boleh dipasang.
- Build dilakukan oleh GitHub Actions secara percuma dalam had penggunaan akaun.
- Data catatan disimpan secara setempat di dalam aplikasi. Jangan clear app data jika mahu menyimpannya.
- Debug APK sesuai untuk dipasang sendiri; untuk Google Play perlu build/release dan tandatangan berasingan.
