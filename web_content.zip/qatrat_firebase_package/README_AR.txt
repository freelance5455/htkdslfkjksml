قطرة دم تنقذ حياة - نسخة ربط Firebase أولية

المحتويات:
- index.html و styles.css و app.js: واجهة عربية واتصال Firebase.
- firestore.rules: قواعد صلاحيات Firestore المقترحة.

قبل تحويل ZIP إلى APK:
1) ارفع ملفات الموقع إلى استضافة HTTPS تدعم JavaScript modules (مثل Firebase Hosting). لا تفتح index.html مباشرة من مدير الملفات.
2) Firebase Console > Authentication > Sign-in method: فعّل Phone.
3) Authentication > Settings > Authorized domains: أضف نطاق HTTPS الفعلي للموقع.
4) Firestore Database > Rules: راجع firestore.rules ثم انشرها. لا تستخدم allow read, write: if true.
5) جرّب تسجيل الهاتف من رابط HTTPS أولًا، ثم حوّل الرابط إلى APK من أداة تدعم WebView وreCAPTCHA. بعض أدوات تحويل ZIP إلى APK لا تدعم Firebase Phone Auth بشكل صحيح.

ملاحظات مهمة:
- هذا مشروع أولي وليس مراجعة أمنية أو تطبيقًا طبيًا جاهزًا للنشر العام.
- بيانات المتبرعين وأرقامهم تظهر للمستخدمين المسجلين فقط، وبموافقة المتبرع.
- Firebase Phone Auth يرسل رمز SMS؛ لا توجد كلمة مرور للحساب.
- إعدادات SMS والفوترة وحدود الإرسال قد تؤثر في إرسال الرموز.
- لا تشارك ملفات مفاتيح خدمة Firebase (service account) مع أحد. إعدادات Web SDK المضمنة ليست بديلًا عن قواعد Firestore.
