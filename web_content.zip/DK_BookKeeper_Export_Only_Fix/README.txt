DK BookKeeper — EXPORT-ONLY FIX

This package preserves the existing DK BookKeeper interface and voucher/account features. The HTML changes are limited to export status reporting and routing XLSX files through an Android native file bridge when running inside the APK.

INTEGRATION
1. Replace your app's app/src/main/assets/index.html with the index.html in this package.
2. Copy AndroidFileBridge.kt into your app's Kotlin source package. IMPORTANT: change the first-line package declaration if your Android project uses a different package/application namespace.
3. In your existing MainActivity (do not replace the whole activity), register the bridge on the WebView BEFORE loading index.html:

   webView.addJavascriptInterface(AndroidFileBridge(this), "AndroidFileBridge")

4. Ensure JavaScript is enabled on the WebView.
5. Rebuild and install a new APK.

EXPORT BEHAVIOUR
- Exports are generated as real XLSX workbooks using the existing SheetJS library.
- In the APK, the native bridge saves the file to the public Downloads collection on Android 10+.
- The app displays a success or error message after the save call.
- If the bridge is not registered, the app falls back to browser XLSX download behaviour; this fallback may not work in Android WebView.

DEPENDENCY / INTERNET
The current HTML loads SheetJS from jsDelivr CDN. Internet access is required for that library unless you bundle xlsx.full.min.js locally and change the script reference. Keep INTERNET permission in the manifest.

IMPORTANT
This is an integration source package, NOT a compiled APK. A rebuilt APK is required for the native bridge to take effect. No voucher/account logic or voice workflow has intentionally been changed.
