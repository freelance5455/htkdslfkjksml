MULANJE BANTING COACH — ANDROID PROJECT

This is a native Android Studio project wrapper for the mobile-first meal-plan and home-workout app.

BUILD AN APK:
1. Install Android Studio on a computer.
2. Open the extracted MulanjeBantingAndroid folder as an existing project.
3. Let Android Studio sync/download the Android Gradle Plugin and SDK components.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is usually created at app/build/outputs/apk/debug/app-debug.apk.
6. Transfer that APK to your Android phone and open it to install. You may need to allow installation from that source.

This environment cannot compile/sign an APK because Android SDK/Gradle build tools are not installed here. This is source project, not a finished APK binary.
The app uses local WebView storage for weight entries and daily checklists. Data remains on the device.
Health information is general education, not medical advice.
