const fs = require('fs');
let code = fs.readFileSync('src/components/ProfessionalFooter.tsx', 'utf8');

const target = `        } catch (err) {
          console.error("Media access denied or error:", err);
          // Just gracefully fail, keeping stream null
        }`;

const replace = `        } catch (err) {
          console.error("Media access denied or error:", err);
          alert("Camera or Microphone permission was denied. Please allow access in your browser to use voice and video calls.");
          setActiveCall(null);
        }`;

if (code.includes(target)) {
  code = code.replace(target, replace);
  fs.writeFileSync('src/components/ProfessionalFooter.tsx', code);
  console.log("Patched media error handling.");
} else {
  console.log("Target not found.");
}
