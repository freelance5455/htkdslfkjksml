package com.layercut.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.IOException;
import java.io.OutputStream;

public final class MainActivity extends Activity {
    private static final int FILE_PICKER_REQUEST = 41;
    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private Uri pendingExportUri;
    private OutputStream pendingExportStream;
    private String pendingExportName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(13, 15, 14));
        window.setNavigationBarColor(Color.rgb(13, 15, 14));

        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        webView.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);

        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return assetLoader.shouldInterceptRequest(Uri.parse(url));
            }
        });

        webView.addJavascriptInterface(new ExportBridge(), "LayerCutBridge");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, FILE_PICKER_REQUEST);
                    return true;
                } catch (ActivityNotFoundException | SecurityException exception) {
                    fileChooserCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "No compatible file picker is available.", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });

        root.addView(webView);
        setContentView(root);
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_PICKER_REQUEST) return;
        ValueCallback<Uri[]> callback = fileChooserCallback;
        fileChooserCallback = null;
        if (callback == null) return;
        Uri[] uris = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                uris = new Uri[count];
                for (int i = 0; i < count; i++) uris[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                uris = new Uri[]{data.getData()};
            }
        }
        callback.onReceiveValue(uris);
    }

    private final class ExportBridge {
        @JavascriptInterface
        public synchronized boolean beginExport(String name, String mimeType) {
            cancelExport();
            try {
                String safeName = sanitizeName(name);
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName);
                values.put(MediaStore.MediaColumns.MIME_TYPE,
                        mimeType == null || mimeType.trim().isEmpty() ? "application/octet-stream" : mimeType);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Layer Cut");
                values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                pendingExportUri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (pendingExportUri == null) return false;
                pendingExportStream = getContentResolver().openOutputStream(pendingExportUri, "w");
                if (pendingExportStream == null) {
                    getContentResolver().delete(pendingExportUri, null, null);
                    pendingExportUri = null;
                    return false;
                }
                pendingExportName = safeName;
                return true;
            } catch (Exception exception) {
                cancelExport();
                return false;
            }
        }

        @JavascriptInterface
        public synchronized boolean writeExportChunk(String encodedChunk) {
            if (pendingExportStream == null || encodedChunk == null) return false;
            try {
                pendingExportStream.write(Base64.decode(encodedChunk, Base64.DEFAULT));
                return true;
            } catch (IOException | IllegalArgumentException exception) {
                return false;
            }
        }

        @JavascriptInterface
        public synchronized boolean finishExport() {
            if (pendingExportStream == null || pendingExportUri == null) return false;
            try {
                pendingExportStream.flush();
                pendingExportStream.close();
                pendingExportStream = null;
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.IS_PENDING, 0);
                int updated = getContentResolver().update(pendingExportUri, values, null, null);
                if (updated <= 0) return false;
                String completedName = pendingExportName;
                pendingExportUri = null;
                pendingExportName = null;
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Saved to Downloads/Layer Cut: " + completedName, Toast.LENGTH_LONG).show());
                return true;
            } catch (Exception exception) {
                cancelExport();
                return false;
            }
        }

        @JavascriptInterface
        public synchronized void cancelExport() {
            try { if (pendingExportStream != null) pendingExportStream.close(); } catch (IOException ignored) { }
            pendingExportStream = null;
            if (pendingExportUri != null) {
                try { getContentResolver().delete(pendingExportUri, null, null); } catch (Exception ignored) { }
            }
            pendingExportUri = null;
            pendingExportName = null;
        }
    }

    private static String sanitizeName(String name) {
        String value = name == null ? "later-cut-export" : name;
        value = value.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (value.isEmpty()) value = "later-cut-export";
        return value.length() > 120 ? value.substring(0, 120) : value;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (fileChooserCallback != null) {
            fileChooserCallback.onReceiveValue(null);
            fileChooserCallback = null;
        }
        if (webView != null) {
            webView.removeJavascriptInterface("LayerCutBridge");
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
