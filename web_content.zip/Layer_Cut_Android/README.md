# Layer Cut — Android source project

**Tagline:** Create Beyond Limits  
**Package ID:** `com.layercut.app`  
**Minimum Android version:** Android 10 (API 29)

This is an Android Studio project that bundles the current Layer Cut web prototype inside a native Android WebView. `project.json` is a manifest describing this project; it is not an APK and is not guaranteed to import into third-party app builders that require their own JSON schema.

## Build an APK

1. Open the `Layer_Cut_Android` folder in Android Studio on a computer.
2. Install/configure JDK 17 and Android SDK Platform 35 (or a compatible platform), and Build Tools.
3. Sync Gradle. The first build requires internet access to download Gradle plugins and the AndroidX WebKit dependency.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK is normally written to `app/build/outputs/apk/debug/app-debug.apk`.

## Included

- Layer Cut interface bundled locally.
- Android document picker for importing photos and videos.
- Export bridge that writes supported exports to `Downloads/Layer Cut` on Android 10+.
- No tracking SDK and no AI credentials embedded in the app.

## Prototype limitations

This is a WebView-based prototype wrapper, not a complete native media editor. Photo adjustments/JPEG export and a limited single-source video trim/color/title/WebM export flow depend on WebView support and device performance. AI prompt saving is present, but real AI generation is not connected. Professional multitrack editing, native 4K/H.265 export, RAW development, advanced masks, and a full audio effects engine are not implemented.

## Project manifest

See `project.json` for the machine-readable project metadata. JSON import formats differ by app builder, so compatibility with an unnamed third-party builder cannot be guaranteed.
