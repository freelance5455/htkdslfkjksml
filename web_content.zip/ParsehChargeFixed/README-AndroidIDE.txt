مدیریت شارژ آسان مجتمع - پارسه
پروژه آماده AndroidIDE

روش ساخت با گوشی:
1) AndroidIDE را نصب کنید.
2) این پوشه را از حالت ZIP خارج کنید.
3) داخل AndroidIDE گزینه Open/Import Project را بزنید و پوشه ParsehCharge را انتخاب کنید.
4) صبر کنید Gradle و وابستگی‌های لازم دانلود شوند.
5) از منوی Build گزینه Assemble Debug را اجرا کنید.
6) APK ساخته‌شده را نصب کنید.

نکته: برنامه کاملاً آفلاین است و داده‌های localStorage داخل WebView نگهداری می‌شوند.
شناسه برنامه: ir.parseh.charge
نسخه: 1.20
