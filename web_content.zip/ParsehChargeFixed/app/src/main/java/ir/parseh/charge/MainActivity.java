package ir.parseh.charge;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.view.*;
import android.content.*;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.database.Cursor;
import android.content.SharedPreferences;
import android.webkit.JavascriptInterface;
import java.io.*;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_PICKER = 1001;
    private static final int BACKUP_FILE_PICKER = 1002;
    private static final int FOLDER_PICKER = 1003;
    private static final int BACKUP_SAVE_PICKER = 1004;
    private Uri pendingBackupFileUri;
    private String pendingBackupContent;
    private String pendingBackupFilename;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("parseh_storage", MODE_PRIVATE);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try { startActivityForResult(params.createIntent(), FILE_PICKER); return true; }
                catch (Exception e) { fileCallback = null; return false; }
            }
        });
        webView.addJavascriptInterface(new AndroidStorageBridge(), "AndroidStorage");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void notifyJs(String expression) {
        webView.post(() -> webView.evaluateJavascript("javascript:" + expression, null));
    }

    private void notifyFolder(String name) {
        notifyJs("window.__androidBackupFolderSelected && window.__androidBackupFolderSelected(" + JSONObjectQuote(name) + ")");
    }

    private void notifyRestoreReady() {
        notifyJs("window.__androidBackupFileSelected && window.__androidBackupFileSelected()");
    }

    private static String JSONObjectQuote(String s) {
        if (s == null) return "null";
        StringBuilder b = new StringBuilder("\"");
        for (int i=0;i<s.length();i++) {
            char c=s.charAt(i);
            switch(c) {
                case '\\': b.append("\\\\"); break;
                case '"': b.append("\\\""); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                case '\b': b.append("\\b"); break;
                case '\f': b.append("\\f"); break;
                default:
                    if(c<32) b.append(String.format("\\u%04x",(int)c)); else b.append(c);
            }
        }
        return b.append('"').toString();
    }

    private Uri getTreeUri() {
        String s = prefs.getString("backup_tree_uri", null);
        return s == null ? null : Uri.parse(s);
    }

    private String displayName(Uri uri) {
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, new String[]{"_display_name"}, null, null, null);
            if(c != null && c.moveToFirst()) return c.getString(0);
        } catch(Exception ignored) {} finally { if(c != null) c.close(); }
        return "";
    }

    private Uri findChild(Uri tree, String filename) {
        Cursor c = null;
        try {
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
            c = getContentResolver().query(children, new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null);
            if(c != null) while(c.moveToNext()) {
                String name = c.getString(1);
                if(filename.equals(name)) {
                    return DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0));
                }
            }
        } catch(Exception ignored) {} finally { if(c != null) c.close(); }
        return null;
    }

    private boolean writeUri(Uri uri, String content) {
        try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
            if(out == null) return false;
            out.write(content.getBytes("UTF-8"));
            out.flush();
            return true;
        } catch(Exception e) { return false; }
    }

    private boolean saveToSelectedFolder(String filename, String content) {
        Uri tree = getTreeUri();
        if(tree == null) return false;
        try {
            Uri target = findChild(tree, filename);
            if(target == null) target = DocumentsContract.createDocument(getContentResolver(), tree, "application/json", filename);
            return target != null && writeUri(target, content);
        } catch(Exception e) { return false; }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_PICKER && fileCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount(); results = new Uri[n];
                    for (int i=0;i<n;i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) results = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(results); fileCallback = null;
        } else if (requestCode == BACKUP_FILE_PICKER) {
            if(resultCode == RESULT_OK && data != null && data.getData() != null) {
                pendingBackupFileUri = data.getData();
                try { getContentResolver().takePersistableUriPermission(pendingBackupFileUri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored) {}
                notifyRestoreReady();
            }
        } else if (requestCode == FOLDER_PICKER) {
            if(resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri tree = data.getData();
                try {
                    int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    getContentResolver().takePersistableUriPermission(tree, flags);
                } catch(Exception ignored) {}
                prefs.edit().putString("backup_tree_uri", tree.toString()).apply();
                notifyFolder(displayName(tree));
            }
        } else if (requestCode == BACKUP_SAVE_PICKER) {
            if(resultCode == RESULT_OK && data != null && data.getData() != null) {
                boolean ok = writeUri(data.getData(), pendingBackupContent == null ? "" : pendingBackupContent);
                pendingBackupContent = null;
                pendingBackupFilename = null;
                notifyJs("window.__androidBackupSaved && window.__androidBackupSaved(" + (ok ? "true" : "false") + ")");
            } else {
                pendingBackupContent = null;
                pendingBackupFilename = null;
                notifyJs("window.__androidBackupSaved && window.__androidBackupSaved(false)");
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public class AndroidStorageBridge {
        @JavascriptInterface public boolean isAvailable() { return true; }

        @JavascriptInterface public void chooseBackupFolder() {
            try {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
                Uri tree = getTreeUri();
                if(tree != null) i.putExtra("android.provider.extra.INITIAL_URI", tree);
                startActivityForResult(i, FOLDER_PICKER);
            } catch(Exception e) {
                notifyFolder("");
            }
        }

        @JavascriptInterface public String getBackupFolderName() {
            Uri tree = getTreeUri();
            return tree == null ? "" : displayName(tree);
        }

        @JavascriptInterface public void saveBackup(String filename, String content) {
            boolean ok = saveToSelectedFolder(filename, content);
            if(ok) {
                notifyJs("window.__androidBackupSaved && window.__androidBackupSaved(true)");
                return;
            }
            pendingBackupFilename = filename;
            pendingBackupContent = content;
            try {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE, filename);
                startActivityForResult(i, BACKUP_SAVE_PICKER);
            } catch(Exception e) {
                pendingBackupContent = null;
                pendingBackupFilename = null;
                notifyJs("window.__androidBackupSaved && window.__androidBackupSaved(false)");
            }
        }

        @JavascriptInterface public void pickBackupFile() {
            try {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/plain", "*/*"});
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(i, BACKUP_FILE_PICKER);
            } catch(Exception e) { notifyRestoreReady(); }
        }

        @JavascriptInterface public String readSelectedBackup() {
            if(pendingBackupFileUri == null) return "";
            try (InputStream in = getContentResolver().openInputStream(pendingBackupFileUri); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                if(in == null) return "";
                byte[] buf = new byte[8192]; int n;
                while((n=in.read(buf))!=-1) out.write(buf,0,n);
                return out.toString("UTF-8");
            } catch(Exception e) { return ""; }
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
