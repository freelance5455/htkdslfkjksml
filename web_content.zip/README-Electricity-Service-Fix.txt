Electricity Service - Location & Photo Fix

Changes: separate Camera and Gallery buttons; clearer GPS permission/error messages.

Important: browser geolocation requires permissions and normally a secure HTTPS context. Opening an HTML file in an in-app preview may block GPS/camera. Open in Chrome and allow Camera/Photos/Location permissions. For reliable use in an installed APK, native Android permissions/bridge and online/offline sync still need proper setup. This is not an APK.
