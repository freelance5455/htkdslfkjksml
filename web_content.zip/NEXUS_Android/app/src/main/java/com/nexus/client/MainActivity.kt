package com.nexus.client

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF171820)
private val Panel = Color(0xFF222431)
private val Purple = Color(0xFF8B5CF6)
private val Muted = Color(0xFF9CA3AF)
private val White = Color(0xFFF4F4F5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexusApp() }
    }
}

@Composable
fun NexusApp() {
    var page by remember { mutableStateOf("Início") }
    var accent by remember { mutableStateOf(Purple) }
    var compact by remember { mutableStateOf(false) }
    var connected by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = accent,
            background = Bg,
            surface = Panel,
            onBackground = White,
            onSurface = White
        )
    ) {
        Row(Modifier.fillMaxSize().background(Bg)) {
            NavigationRail(
                containerColor = Color(0xFF111218),
                contentColor = White,
                header = {
                    Box(
                        Modifier.padding(vertical = 14.dp).size(48.dp)
                            .background(accent, RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) { Text("N", fontSize = 25.sp, fontWeight = FontWeight.Black) }
                }
            ) {
                listOf(
                    "Início" to Icons.Default.Home,
                    "Servidores" to Icons.Default.Groups,
                    "Mensagens" to Icons.Default.Chat,
                    "Plugins" to Icons.Default.Extension,
                    "NEXUS Settings" to Icons.Default.Settings
                ).forEach { (label, icon) ->
                    NavigationRailItem(
                        selected = page == label,
                        onClick = { page = label },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label, fontSize = 9.sp) },
                        alwaysShowLabel = false
                    )
                }
            }
            Column(Modifier.fillMaxSize().padding(18.dp)) {
                Text("NEXUS", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = White)
                Text(page, color = accent, fontSize = 14.sp)
                Spacer(Modifier.height(18.dp))
                when (page) {
                    "Início" -> HomeScreen(connected, onConnect = { connected = true })
                    "Servidores" -> InfoScreen(
                        "Seus servidores Discord",
                        "A lista real de servidores exige autorização OAuth2 e o escopo identify + guilds. Configure a integração no backend antes de exibir dados."
                    )
                    "Mensagens" -> InfoScreen(
                        "Mensagens",
                        "A API pública do Discord não permite a um cliente independente ler e enviar mensagens como uma conta pessoal. Esta tela não inventa conversas nem mensagens."
                    )
                    "Plugins" -> PluginsScreen()
                    else -> SettingsScreen(
                        accent = accent,
                        onAccent = { accent = it },
                        compact = compact,
                        onCompact = { compact = it }
                    )
                }
            }
        }
    }
}

@Composable
fun HomeScreen(connected: Boolean, onConnect: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Sua experiência Discord, com identidade NEXUS.", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(
                "Projeto inicial Android nativo. A conexão oficial ainda precisa ser configurada com um aplicativo Discord Developer e um backend seguro.",
                color = Muted
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = if (connected) Color(0xFF22C55E) else Muted)
                Spacer(Modifier.width(8.dp))
                Text(if (connected) "Modo de demonstração local ativado" else "Discord não conectado", color = White)
            }
            Button(onClick = onConnect, enabled = !connected, colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                Text(if (connected) "Solicitação registrada" else "Preparar conexão Discord")
            }
            Text("Este botão ainda não autentica: não insira sua senha ou token neste aplicativo.", color = Muted, fontSize = 12.sp)
        }
    }
    Spacer(Modifier.height(16.dp))
    Text("Atalhos", color = White, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SmallFeature("Temas", Icons.Default.Palette)
        SmallFeature("Extensões", Icons.Default.Extension)
        SmallFeature("Privacidade", Icons.Default.Shield)
    }
}

@Composable
fun SmallFeature(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = null, tint = Purple)
            Spacer(Modifier.height(6.dp))
            Text(title, fontSize = 12.sp, color = White)
        }
    }
}

@Composable
fun InfoScreen(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(body, color = Muted)
            Text("Limitação documentada — nenhuma funcionalidade falsa será exibida.", color = Color(0xFFFBBF24), fontSize = 12.sp)
        }
    }
}

@Composable
fun PluginsScreen() {
    val plugins = listOf(
        "NEXUS Theme Pack" to "Temas e paletas locais",
        "Compact Layout" to "Reduz espaçamentos da interface",
        "Profile Decor" to "Decoração local de perfil"
    )
    var enabled by remember { mutableStateOf(setOf("NEXUS Theme Pack")) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Central de extensões", color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Extensões demonstrativas locais. O carregamento de código externo está desativado por segurança.", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
        }
        items(plugins.size) { index ->
            val (name, description) = plugins[index]
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(name, color = White, fontWeight = FontWeight.SemiBold)
                        Text(description, color = Muted, fontSize = 12.sp)
                    }
                    Switch(
                        checked = name in enabled,
                        onCheckedChange = { checked ->
                            enabled = if (checked) enabled + name else enabled - name
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    accent: Color,
    onAccent: (Color) -> Unit,
    compact: Boolean,
    onCompact: (Boolean) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Personalização", color = White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Cor de destaque", color = White, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    listOf(Purple, Color(0xFF3B82F6), Color(0xFF10B981), Color(0xFFEC4899), Color(0xFFF59E0B)).forEach { color ->
                        Box(
                            Modifier.size(34.dp).background(color, RoundedCornerShape(50))
                                .clickable { onAccent(color) }
                        )
                    }
                }
                HorizontalDivider(color = Color.DarkGray)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Modo compacto", color = White)
                        Text("Reduz espaços da interface", color = Muted, fontSize = 12.sp)
                    }
                    Switch(checked = compact, onCheckedChange = onCompact)
                }
            }
        }
        Text("Mais opções planejadas", color = White, fontWeight = FontWeight.SemiBold)
        listOf("Gradientes personalizados", "Fontes personalizadas", "Ícones personalizados", "Balões de mensagem", "Barra lateral", "Animações", "Importar temas").forEach {
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(it, color = White)
                Spacer(Modifier.weight(1f))
                Text("Em desenvolvimento", color = Muted, fontSize = 11.sp)
            }
        }
    }
}
