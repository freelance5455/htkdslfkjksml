NEXUS Browser — Android project

Це Android Studio проєкт для створення APK.

Що включено:
- інтерфейс NEXUS з наявного HTML-прототипу;
- Google Search через перехід на сторінку результатів Google;
- відкриття сайтів у тому самому вікні браузера;
- кнопка «Назад» Android повертає на попередню сторінку;
- завантаження через системний Android DownloadManager з повідомленням про завершення.

Як зібрати APK:
1. Відкрити папку NEXUS_Android в Android Studio.
2. Дочекатися Gradle Sync і встановлення Android SDK 35, якщо IDE попросить.
3. Build → Build Bundle(s) / APK(s) → Build APK(s).
4. APK буде в app/build/outputs/apk/debug/app-debug.apk.

Важливо: цей проєкт ще не зібраний і не протестований на фізичному телефоні. Для збірки потрібні Android Studio, Android SDK і Gradle. Це поки тестова версія, не готова до публікації в магазинах.
