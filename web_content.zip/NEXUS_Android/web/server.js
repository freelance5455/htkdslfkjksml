// NEXUS OAuth2 backend — Node.js 20+
require('dotenv').config();
const express = require('express');
const session = require('express-session');
const crypto = require('node:crypto');
const path = require('node:path');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const CLIENT_ID = process.env.DISCORD_CLIENT_ID;
const CLIENT_SECRET = process.env.DISCORD_CLIENT_SECRET;
const BASE_URL = (process.env.BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, '');
const REDIRECT_URI = `${BASE_URL}/auth/discord/callback`;

if (!CLIENT_ID || !CLIENT_SECRET || !process.env.SESSION_SECRET) {
  console.error('Configure DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET e SESSION_SECRET no arquivo .env');
  process.exit(1);
}

app.disable('x-powered-by');
if (process.env.NODE_ENV === 'production') app.set('trust proxy', 1);
app.use(session({
  name: 'nexus.sid',
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 24 * 60 * 60 * 1000
  }
}));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/auth/discord', (req, res) => {
  const state = crypto.randomBytes(24).toString('hex');
  req.session.oauthState = state;
  const params = new URLSearchParams({
    client_id: CLIENT_ID,
    response_type: 'code',
    redirect_uri: REDIRECT_URI,
    scope: 'identify guilds',
    state
  });
  res.redirect(`https://discord.com/oauth2/authorize?${params.toString()}`);
});

app.get('/auth/discord/callback', async (req, res) => {
  const { code, state, error } = req.query;
  if (error) return res.status(400).send('Autorização Discord cancelada ou recusada.');
  if (!code || !state || !req.session.oauthState || state !== req.session.oauthState) {
    return res.status(400).send('Resposta OAuth2 inválida. Volte ao NEXUS e tente novamente.');
  }
  delete req.session.oauthState;
  try {
    const tokenResponse = await fetch('https://discord.com/api/v10/oauth2/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: CLIENT_ID,
        client_secret: CLIENT_SECRET,
        grant_type: 'authorization_code',
        code: String(code),
        redirect_uri: REDIRECT_URI
      })
    });
    const tokenData = await tokenResponse.json();
    if (!tokenResponse.ok || !tokenData.access_token) {
      console.error('Falha na troca OAuth2:', tokenData.error || tokenResponse.status);
      return res.status(400).send('Não foi possível concluir o login Discord.');
    }
    req.session.discordAccessToken = tokenData.access_token;
    req.session.discordScope = tokenData.scope || '';
    res.redirect('/');
  } catch (err) {
    console.error('Erro OAuth2:', err.message);
    res.status(500).send('Erro interno ao conectar com o Discord.');
  }
});

async function discordGet(req, endpoint) {
  if (!req.session.discordAccessToken) return null;
  const response = await fetch(`https://discord.com/api/v10${endpoint}`, {
    headers: { Authorization: `Bearer ${req.session.discordAccessToken}` }
  });
  if (!response.ok) return null;
  return response.json();
}

app.get('/api/me', async (req, res) => {
  try {
    const user = await discordGet(req, '/users/@me');
    if (!user) return res.sendStatus(401);
    res.json({
      id: user.id,
      username: user.username,
      global_name: user.global_name,
      avatar: user.avatar
    });
  } catch { res.sendStatus(502); }
});

app.get('/api/guilds', async (req, res) => {
  try {
    if (!req.session.discordAccessToken || !req.session.discordScope.split(' ').includes('guilds')) {
      return res.sendStatus(401);
    }
    const guilds = await discordGet(req, '/users/@me/guilds');
    if (!guilds) return res.sendStatus(502);
    res.json(guilds.map(g => ({ id: g.id, name: g.name, icon: g.icon })));
  } catch { res.sendStatus(502); }
});

app.post('/auth/logout', (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('nexus.sid', { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production' });
    res.sendStatus(204);
  });
});

app.listen(PORT, () => {
  console.log(`NEXUS disponível em ${BASE_URL}`);
  console.log(`Cadastre este Redirect URI no Discord Developer Portal: ${REDIRECT_URI}`);
});
