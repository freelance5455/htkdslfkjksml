# NEXUS Android

Projeto inicial nativo em Kotlin + Jetpack Compose.

## O que já existe
- Interface Android escura com navegação lateral.
- Telas NEXUS: Início, Servidores, Mensagens, Plugins e Configurações.
- Seleção local de cor de destaque e modo compacto.
- Central de plugins local com ativação/desativação de opções demonstrativas.
- Avisos explícitos onde a API pública do Discord não permite uma função.

## Limitação essencial
Este projeto **não é um cliente Discord funcional completo**. A API pública comum do Discord não oferece a um app independente acesso geral às mensagens de usuário nem às chamadas de voz do cliente oficial. Não há leitura/envio de mensagens ou voz implementados, e a interface não finge que existem.

Não use user tokens, self-bots, extração de sessão, engenharia reversa do app oficial ou credenciais de usuário. Para recursos sociais permitidos, consulte a documentação oficial e obtenha as aprovações necessárias.

## Abrir e compilar
1. Instale Android Studio atualizado.
2. Abra a pasta `NEXUS_Android`.
3. Aguarde a sincronização do Gradle.
4. Selecione Build > Build APK(s).
5. APK de debug: `app/build/outputs/apk/debug/app-debug.apk`.

Requisitos: JDK 17 e Android SDK 35.

## Próximas etapas para integração oficial
- Criar uma aplicação no Discord Developer Portal.
- Configurar OAuth2 e redirect URI.
- Implementar backend seguro para troca de código OAuth2 e armazenamento de tokens.
- Solicitar apenas escopos aprovados e necessários.
- Usar endpoints oficiais autorizados; não prometer recursos indisponíveis.


## Login Discord pelo HTML (pasta `web/`)

Foi adicionada uma versão web mobile-first com `web/public/index.html` e backend OAuth2.

### Configurar
1. Instale Node.js 20 ou superior.
2. No Discord Developer Portal, crie/seleciona uma aplicação e copie o Client ID e Client Secret.
3. Na seção OAuth2, adicione exatamente o Redirect URI `http://localhost:3000/auth/discord/callback` para teste local.
4. Copie `web/.env.example` para `web/.env` e preencha as credenciais. Nunca publique o `.env` nem coloque o Client Secret no HTML.
5. No terminal, entre na pasta `web/`, execute `npm install` e depois `npm start`.
6. Abra `http://localhost:3000` no navegador. O botão abre a página oficial `discord.com` para autorização.

Para publicar, configure `BASE_URL` com seu domínio HTTPS e cadastre o Redirect URI HTTPS idêntico no Developer Portal. Use um armazenamento de sessão persistente e seguro em produção; o armazenamento padrão em memória do express-session é apenas para desenvolvimento.

### O que o login libera
O fluxo solicita somente `identify` e `guilds`. Após a autorização, o site mostra o perfil básico e a lista de servidores que a API permite consultar.

**Não libera mensagens privadas, histórico de mensagens, envio de mensagens ou chamadas de voz.** Não peça senha nem token de usuário. Recursos adicionais dependem de APIs e aprovações específicas do Discord.
