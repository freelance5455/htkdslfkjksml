/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        'bg-dark': '#0a0e17',
        'bg-card': '#121726',
        'bg-card2': '#1a2035',
        'border-soft': '#2a324a',
        'accent-blue': '#3b82f6',
        'accent-cyan': '#06b6d4',
        'up-green': '#10b981',
        'down-red': '#ef4444',
        'warn-yellow': '#f59e0b',
      },
      fontFamily: {
        sans: ['"Rubik"', '"Assistant"', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
