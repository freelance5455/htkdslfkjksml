// Production proxy for Cloudflare Workers / Vercel Edge.
// Usage: deploy this file as a worker route /api/market-proxy on your hosting provider.

// Cloudflare Worker entry
export default {
  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);
    const source = url.searchParams.get('source') || 'bybit';
    const path = url.searchParams.get('path') || '';
    url.searchParams.delete('source');
    url.searchParams.delete('path');
    const TARGETS: Record<string, string> = {
      bybit: 'https://api.bybit.com',
      binance: 'https://api.binance.com',
      coingecko: 'https://api.coingecko.com',
    };
    const target = TARGETS[source];
    if (!target) return new Response('Unknown source', { status: 400 });
    const upstream = `${target}${path}${url.searchParams.toString() ? '?' + url.searchParams.toString() : ''}`;
    try {
      const r = await fetch(upstream, { headers: { 'Accept': 'application/json' } });
      const body = await r.text();
      return new Response(body, {
        status: r.status,
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'Access-Control-Allow-Origin': '*',
          'Cache-Control': 'public, max-age=5',
        },
      });
    } catch (e) {
      return new Response(JSON.stringify({ error: 'proxy_failed', message: String(e) }), { status: 502 });
    }
  },
};
