// Unified market proxy used by the browser. Routes to Bybit V5, Binance, or CoinGecko
// with automatic fallback. This is served by Vite's dev server in dev and by any
// static host with a `/api/market-proxy` rewrite in production.
//
// Usage:
//   GET /api/market-proxy?source=bybit&path=/v5/market/kline&category=linear&symbol=BTCUSDT&interval=15&limit=200
//   GET /api/market-proxy?source=binance&path=/api/v3/klines&symbol=BTCUSDT&interval=15m&limit=200
//   GET /api/market-proxy?source=coingecko&path=/api/v3/coins/markets&vs_currency=usd&order=market_cap_desc&per_page=60
//
// For production (static hosting), deploy the small Cloudflare Worker / Vercel function
// included at server/proxy-worker.js alongside the built static assets.

import type { Plugin, Connect } from 'vite';
import type { IncomingMessage, ServerResponse } from 'http';

const TARGETS: Record<string, string> = {
  bybit: 'https://api.bybit.com',
  binance: 'https://api.binance.com',
  coingecko: 'https://api.coingecko.com',
};

export function marketProxyPlugin(): Plugin {
  return {
    name: 'crypto-market-proxy',
    configureServer(server) {
      server.middlewares.use('/api/market-proxy', async (req: IncomingMessage, res: ServerResponse, next: Connect.NextFunction) => {
        try {
          const url = new URL(req.url || '/', 'http://localhost');
          const source = url.searchParams.get('source') || 'bybit';
          const path = url.searchParams.get('path') || '';
          const target = TARGETS[source];
          if (!target) { res.writeHead(400); res.end('Unknown source'); return; }
          // Strip source/path params and forward the rest
          const sp = new URLSearchParams(url.searchParams);
          sp.delete('source'); sp.delete('path');
          const qs = sp.toString();
          const upstream = `${target}${path}${qs ? '?' + qs : ''}`;
          const ctrl = new AbortController();
          const to = setTimeout(() => ctrl.abort(), 8000);
          const r = await fetch(upstream, {
            signal: ctrl.signal,
            headers: { 'Accept': 'application/json' },
          });
          clearTimeout(to);
          const text = await r.text();
          res.setHeader('Content-Type', 'application/json; charset=utf-8');
          res.setHeader('Cache-Control', 'public, max-age=5');
          res.setHeader('Access-Control-Allow-Origin', '*');
          res.statusCode = r.status;
          res.end(text);
        } catch (e) {
          res.statusCode = 502;
          res.end(JSON.stringify({ error: 'proxy_failed', message: String(e) }));
        }
      });
    },
  };
}
