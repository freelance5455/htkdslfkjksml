import { useEffect, useState } from 'react';
import { Card, Badge } from '../components/UI';
import { MarketTicker } from '../types';
import { fetchCoinsMarket } from '../services/marketService';

interface CoinMeta {
  symbol: string;
  name: string;
  onChainVolume: number;
  activeWallets: number;
  supplyInflation: number;
  devActivity: number;
  summary: string;
  category: string;
}

const RESEARCH_DATA: Record<string, Omit<CoinMeta, 'symbol'>> = {
  BTC: { name: 'Bitcoin', category: 'מטבע רזרבה', onChainVolume: 28_500_000_000, activeWallets: 1_020_000, supplyInflation: 1.7, devActivity: 62, summary: 'זהב דיגיטלי. מטבע הקריפטו הראשון, הגדול והמבוסס ביותר. משמש כמאגר ערך וגידור מפני אינפלציה בשווקים גלובליים. האבטחה הגבוהה ביותר מכל רשת PoW.' },
  ETH: { name: 'Ethereum', category: 'שכבה 1', onChainVolume: 15_200_000_000, activeWallets: 2_400_000, supplyInflation: 0.2, devActivity: 98, summary: 'הרשת החוזית החכמה המובילה. מרבית ה-DeFi, ה-NFT ושכבות ה-L2 בנויים על גביה. עוברת ל-Proof-of-Stake עם הנפקה דפלציונית.' },
  SOL: { name: 'Solana', category: 'שכבה 1', onChainVolume: 3_800_000_000, activeWallets: 3_100_000, supplyInflation: 6.8, devActivity: 84, summary: 'רשת בעלת תפוקה גבוהה (50k TPS) ועמלות נמוכות במיוחד. אקו-סיסטם DeFi, NFT ו-memes פעיל במיוחד. נתמך ע"י חברות גדולות.' },
  BNB: { name: 'BNB', category: 'אקו-סיסטם בורסה', onChainVolume: 1_900_000_000, activeWallets: 1_200_000, supplyInflation: -1.2, devActivity: 71, summary: 'הטוקן המקורי של אקו-סיסטם Binance. משמש לעמלות מוזלות בבורסה וברשת BNB Smart Chain עם מערך DeFi נרחב.' },
  XRP: { name: 'XRP', category: 'תשלומים', onChainVolume: 1_400_000_000, activeWallets: 260_000, supplyInflation: -2.1, devActivity: 55, summary: 'מיועד לתשלומים חוצי גבולות וסליקה בין בנקים. מערכת RippleNet עם שותפויות מוסדיות נרחבות. עברה ניצחון משפטי משמעותי מול ה-SEC.' },
  ADA: { name: 'Cardano', category: 'שכבה 1', onChainVolume: 420_000_000, activeWallets: 520_000, supplyInflation: 3.5, devActivity: 78, summary: 'רשת PoS מבוססת מחקר אקדמי. פילוסופיה מדעית וביקורת עמיתים לפרוטוקול. מתרחבת ל-DeFi וחוזים חכמים.' },
  DOGE: { name: 'Dogecoin', category: 'מטבע ממים', onChainVolume: 880_000_000, activeWallets: 4_800_000, supplyInflation: 3.9, devActivity: 32, summary: 'מטבע הממים הראשון. קהילה חזקה ונאמנה, תמיכה של אילון מאסק, עמלות נמוכות מאוד. מתעדכן לאיטו עם תשלומים פיזיים ושילובי X.' },
  AVAX: { name: 'Avalanche', category: 'שכבה 1', onChainVolume: 720_000_000, activeWallets: 380_000, supplyInflation: 4.8, devActivity: 74, summary: 'פרוטוקול Layer 1 עם סופיות בלוק תת-שנייה ותתי-רשתות (Subnets). פופולרי למוסדות ולפרויקטי RWA (נכסי עולם אמיתי).' },
  DOT: { name: 'Polkadot', category: 'תשתית צולבת', onChainVolume: 380_000_000, activeWallets: 220_000, supplyInflation: 7.2, devActivity: 82, summary: 'פרוטוקול לחיבור parachains שונים תחת רשת אחת. חזון אינטראופרביליות עם בטיחות משותפת וממשל משוכלל.' },
  MATIC: { name: 'Polygon', category: 'Layer 2', onChainVolume: 1_100_000_000, activeWallets: 950_000, supplyInflation: 5.1, devActivity: 86, summary: 'פתרון Layer 2 מוביל ל-Ethereum (zk-EVM, PoS). עמלות נמוכות ושדרוג טכנולוגי מתמיד. שותפויות עם חברות ענק.' },
  LINK: { name: 'Chainlink', category: 'אורקל', onChainVolume: 580_000_000, activeWallets: 340_000, supplyInflation: 4.3, devActivity: 89, summary: 'רשת אורקלים מבוזרת המספקת נתוני עולם אמיתי לחוזים חכמים. תשתית קריטית ל-DeFi ול-RWA. פרוטוקול CCIP לחציית רשתות.' },
  UNI: { name: 'Uniswap', category: 'DEX', onChainVolume: 320_000_000, activeWallets: 290_000, supplyInflation: 2.0, devActivity: 83, summary: 'ה-DEX הגדול בעולם. פרוטוקול אוטומטי ל-AMM עם עוצמת נזילים ועמלות. גרסה V4 מביאה Hooks וגמישות רבה יותר.' },
  AAVE: { name: 'Aave', category: 'DeFi הלוואות', onChainVolume: 180_000_000, activeWallets: 180_000, supplyInflation: 3.0, devActivity: 77, summary: 'פרוטוקול הלוואות מבוזר מוביל בריבוי רשתות. מערכת GHO סטייבלקוין משלו. ניהול מבוזר DAO.' },
  ATOM: { name: 'Cosmos', category: 'אינטראופרביליות', onChainVolume: 290_000_000, activeWallets: 240_000, supplyInflation: 7.5, devActivity: 79, summary: 'מערכת אקו של בלוקצ׳יינים עצמאיים (Zones) עם פרוטוקול IBC לחיבור ביניהם. מודל Cosmos SDK פופולרי לבניית שרשראות.' },
  NEAR: { name: 'NEAR Protocol', category: 'שכבה 1', onChainVolume: 210_000_000, activeWallets: 720_000, supplyInflation: 5.2, devActivity: 81, summary: 'Layer 1 ממוקד UX עם חשבונות קריאים ועמלות נמוכות. מפתחת Chain Abstraction לפישוט שימוש בקריפטו.' },
  LTC: { name: 'Litecoin', category: 'מטבע תשלום', onChainVolume: 440_000_000, activeWallets: 410_000, supplyInflation: 3.8, devActivity: 48, summary: 'כסף דיגיטלי מול הזהב של ביטקוין. ותק של למעלה מעשור, אימוץ תשלומים ופעילות Mimblewimble לפרטיות.' },
};

const DEFAULT_ENTRY: Omit<CoinMeta, 'symbol'> = { name: 'Unknown', category: 'אחר', onChainVolume: 0, activeWallets: 0, supplyInflation: 0, devActivity: 0, summary: 'מטבע קריפטוגרפי נוסף בשוק. מומלץ לבדוק את הצוות, הטוקונומיקה ופעילות קהילתית לפני השקעה.' };

function fmt(n: number): string {
  if (n >= 1e9) return (n / 1e9).toFixed(2) + 'B';
  if (n >= 1e6) return (n / 1e6).toFixed(2) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
  return n.toString();
}

export function ResearchTab() {
  const [coins, setCoins] = useState<MarketTicker[]>([]);
  const [selected, setSelected] = useState<string>('BTC');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCoinsMarket().then(c => { setCoins(c); setLoading(false); });
  }, []);

  const ticker = coins.find(c => c.symbol.startsWith(selected));
  const meta = RESEARCH_DATA[selected] || DEFAULT_ENTRY;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      <Card className="lg:col-span-2">
        <h2 className="text-xl font-bold mb-4">🔬 מחקר עומק - ניתוח יסודי (Messari-style)</h2>
        {loading ? <p className="text-gray-400">טוען נתונים...</p> : (
          <>
            <div className="flex flex-wrap items-center gap-3 mb-4">
              <h3 className="text-2xl font-bold">{meta.name} <span className="text-gray-400 text-lg">({selected})</span></h3>
              <Badge color="blue">{meta.category}</Badge>
              {ticker && (
                <>
                  <span className="text-xl font-bold text-accent-cyan">${ticker.price.toFixed(ticker.price < 1 ? 4 : 2)}</span>
                  <Badge color={ticker.change24h >= 0 ? 'green' : 'red'}>{ticker.change24h >= 0 ? '+' : ''}{ticker.change24h.toFixed(2)}%</Badge>
                </>
              )}
            </div>
            <div className="bg-bg-card2 rounded-lg p-4 mb-4">
              <div className="text-sm font-bold mb-2 text-accent-cyan">🧠 סיכום AI:</div>
              <p className="text-gray-200 leading-relaxed text-sm">{meta.summary}</p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
              <div className="bg-bg-card2 rounded p-3">
                <div className="text-xs text-gray-400">נפח און-צ'יין 24ש</div>
                <div className="text-lg font-bold mt-1">${fmt(meta.onChainVolume)}</div>
              </div>
              <div className="bg-bg-card2 rounded p-3">
                <div className="text-xs text-gray-400">ארנקים פעילים</div>
                <div className="text-lg font-bold mt-1">{fmt(meta.activeWallets)}</div>
              </div>
              <div className="bg-bg-card2 rounded p-3">
                <div className="text-xs text-gray-400">אינפלציית היצע</div>
                <div className={`text-lg font-bold mt-1 ${meta.supplyInflation > 3 ? 'text-down-red' : meta.supplyInflation > 0 ? 'text-warn-yellow' : 'text-up-green'}`}>{meta.supplyInflation.toFixed(1)}%</div>
              </div>
              <div className="bg-bg-card2 rounded p-3">
                <div className="text-xs text-gray-400">פעילות מפתחים</div>
                <div className="text-lg font-bold mt-1">{meta.devActivity}/100</div>
                <div className="w-full bg-bg-dark rounded-full h-2 mt-1"><div className="bg-accent-blue h-2 rounded-full" style={{ width: `${meta.devActivity}%` }} /></div>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="bg-bg-card2 rounded p-3">
                <div className="text-sm font-bold text-up-green mb-2">✓ יתרונות</div>
                <ul className="text-xs space-y-1 text-gray-300 list-disc pr-4">
                  <li>נפח און-צ'יין {fmt(meta.onChainVolume)}$ מעיד על פעילות אמיתית</li>
                  <li>{meta.activeWallets > 1_000_000 ? 'אימוץ רחב עם מיליוני ארנקים' : meta.activeWallets > 200_000 ? 'בסיס משתמשים משמעותי' : 'בסיס משתמשים ממוקד'}</li>
                  <li>פעילות מפתחים {meta.devActivity > 80 ? 'גבוהה מאוד' : meta.devActivity > 60 ? 'חזקה' : 'מתונה'}</li>
                </ul>
              </div>
              <div className="bg-bg-card2 rounded p-3">
                <div className="text-sm font-bold text-down-red mb-2">⚠ סיכונים</div>
                <ul className="text-xs space-y-1 text-gray-300 list-disc pr-4">
                  <li>אינפלציית היצע {meta.supplyInflation.toFixed(1)}% {meta.supplyInflation > 4 ? '(דילול גבוה)' : meta.supplyInflation > 2 ? '(דילול בינוני)' : '(דילול נמוך)'}</li>
                  <li>תחרות עזה בקטגוריית {meta.category}</li>
                  <li>סיכון רגולטורי ותנודתיות שוק</li>
                </ul>
              </div>
            </div>
          </>
        )}
      </Card>
      <Card>
        <h3 className="font-bold mb-3">🔍 בחר מטבע למחקר</h3>
        <div className="grid grid-cols-2 gap-2">
          {Object.keys(RESEARCH_DATA).map(sym => (
            <button key={sym} onClick={() => setSelected(sym)}
              className={`text-right p-2 rounded text-sm font-semibold transition ${selected === sym ? 'bg-accent-blue text-white' : 'bg-bg-card2 hover:bg-bg-card2/70'}`}>
              <div>{sym}</div>
              <div className="text-[10px] opacity-70 font-normal">{RESEARCH_DATA[sym].category}</div>
            </button>
          ))}
        </div>
      </Card>
    </div>
  );
}
