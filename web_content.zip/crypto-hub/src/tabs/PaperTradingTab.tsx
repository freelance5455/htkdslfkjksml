import { useEffect, useState, useRef } from 'react';
import { Card, Button, Stat, Badge } from '../components/UI';
import { PaperOrder, MarketTicker } from '../types';
import { loadState, resetPaperBalance } from '../store/useStore';
import { openOrder, closeOrder, calcLiquidationPrice, unrealizedPnL, monitorOrders, cancelOrder } from '../services/paperTrading';

export function PaperTradingTab({ tickers }: { tickers: MarketTicker[] }) {
  const [balance, setBalance] = useState(10000);
  const [initialBal, setInitialBal] = useState(10000);
  const [orders, setOrders] = useState<PaperOrder[]>([]);
  const [symbol, setSymbol] = useState('BTCUSDT');
  const [direction, setDirection] = useState<'LONG' | 'SHORT'>('LONG');
  const [qtyUSDT, setQtyUSDT] = useState(500);
  const [leverage, setLeverage] = useState(5);
  const [slPct, setSlPct] = useState(1.5);
  const [tpPct, setTpPct] = useState(3);
  const [orderType, setOrderType] = useState<'market' | 'limit'>('market');
  const [limitPrice, setLimitPrice] = useState(0);
  const [error, setError] = useState('');
  const pricesRef = useRef<Record<string, number>>({});

  const PAIRS = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT', 'DOGEUSDT', 'ADAUSDT', 'AVAXUSDT', 'LINKUSDT'];

  const refresh = () => {
    const s = loadState();
    setBalance(s.paperBalance);
    setInitialBal(s.initialBalance);
    setOrders(Array.isArray(s.orders) ? s.orders : []);
  };

  useEffect(() => {
    refresh();
    const id = setInterval(() => {
      const prices: Record<string, number> = {};
      (Array.isArray(tickers) ? tickers : []).forEach(t => prices[t.symbol] = t.price);
      pricesRef.current = prices;
      if (Object.keys(prices).length > 0) {
        monitorOrders(prices);
        refresh();
      }
    }, 2000);
    return () => clearInterval(id);
  }, [tickers]);

  const t = (Array.isArray(tickers) ? tickers : []).find(x => x.symbol === symbol);
  const price = t?.price ?? 0;
  const openOrders = (Array.isArray(orders) ? orders : []).filter(o => o.status === 'OPEN');
  const pendingOrders = (Array.isArray(orders) ? orders : []).filter(o => o.status === 'PENDING');
  const closedOrders = (Array.isArray(orders) ? orders : []).filter(o => o.status === 'CLOSED' || o.status === 'CANCELLED').slice(0, 80);
  const unrealized = openOrders.reduce((sum, o) => sum + unrealizedPnL(o, pricesRef.current[o.symbol] ?? o.entryPrice), 0);
  const equity = balance + unrealized;
  const roi = initialBal > 0 ? ((equity - initialBal) / initialBal) * 100 : 0;
  const realized = closedOrders.filter(o => o.status === 'CLOSED').reduce((sum, o) => sum + (o.pnl ?? 0), 0);
  const marginUsed = openOrders.reduce((s, o) => s + (o.entryPrice * o.quantity / o.leverage), 0);

  const submit = () => {
    setError('');
    if (!price) { setError('מחיר לא זמין'); return; }
    const entryPrice = price;
    const limitExec = orderType === 'limit' ? (limitPrice > 0 ? limitPrice : price) : undefined;
    const execPrice = limitExec || entryPrice;
    const qty = (qtyUSDT * leverage) / execPrice;
    const sl = direction === 'LONG' ? execPrice * (1 - slPct / 100) : execPrice * (1 + slPct / 100);
    const tp = direction === 'LONG' ? execPrice * (1 + tpPct / 100) : execPrice * (1 - tpPct / 100);
    const res = openOrder({
      symbol, direction, entryPrice, quantity: qty, leverage, sl, tp,
      orderType, limitPrice: limitExec,
      note: orderType === 'limit' ? 'Limit order' : 'Market order',
    });
    if (res.error) setError(res.error);
    else refresh();
  };

  const close = (id: string) => {
    const o = orders.find(x => x.id === id);
    if (!o) return;
    const p = pricesRef.current[o.symbol] ?? o.entryPrice;
    closeOrder(id, p, 'סגירה ידנית');
    refresh();
  };

  const cancel = (id: string) => { cancelOrder(id); refresh(); };

  const reset = () => {
    if (confirm('איפוס חשבון הדמו יסגור את כל הפוזיציות ויאפס את היתרה ל-$10,000. להמשיך?')) {
      resetPaperBalance();
      refresh();
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
        <Stat label="יתרה זמינה" value={`$${balance.toFixed(2)}`} />
        <Stat label="בטחונות תפוסים" value={`$${marginUsed.toFixed(2)}`} sub="Margin Used" />
        <Stat label="שווי תיק" value={`$${equity.toFixed(2)}`} />
        <Stat label="P&L לא ממומש" value={`$${unrealized.toFixed(2)}`} color={unrealized >= 0 ? 'text-up-green' : 'text-down-red'} />
        <Stat label="P&L ממומש" value={`$${realized.toFixed(2)}`} color={realized >= 0 ? 'text-up-green' : 'text-down-red'} />
        <Stat label="תשואה כוללת" value={`${roi >= 0 ? '+' : ''}${roi.toFixed(2)}%`} color={roi >= 0 ? 'text-up-green' : 'text-down-red'} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-1">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold">📊 פתח עסקת דמו</h2>
            <Button variant="danger" onClick={reset}>איפוס חשבון</Button>
          </div>
          {error && <div className="bg-down-red/20 border border-down-red/40 text-down-red rounded p-2 text-xs mb-3">{error}</div>}
          <label className="block text-xs mb-3">
            זוג מטבעות:
            <select value={symbol} onChange={e => setSymbol(e.target.value)} className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-2">
              {PAIRS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </label>
          <div className="grid grid-cols-2 gap-2 mb-3">
            <button onClick={() => setDirection('LONG')}
              className={`py-3 rounded-lg font-bold transition ${direction === 'LONG' ? 'bg-up-green text-white' : 'bg-bg-card2 border border-border-soft text-gray-400'}`}>
              לונג LONG
            </button>
            <button onClick={() => setDirection('SHORT')}
              className={`py-3 rounded-lg font-bold transition ${direction === 'SHORT' ? 'bg-down-red text-white' : 'bg-bg-card2 border border-border-soft text-gray-400'}`}>
              שורט SHORT
            </button>
          </div>
          <label className="block text-xs mb-3">
            סכום ב-USDT (ללא מינוף):
            <input type="number" value={qtyUSDT} onChange={e => setQtyUSDT(Number(e.target.value))}
              className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-2" />
          </label>
          <div className="grid grid-cols-2 gap-2 mb-3">
            <div>
              <label className="text-xs">סוג פקודה:</label>
              <select value={orderType} onChange={e => setOrderType(e.target.value as any)}
                className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-2">
                <option value="market">Market (מיידי)</option>
                <option value="limit">Limit (ממתין למחיר)</option>
              </select>
            </div>
            {orderType === 'limit' ? (
              <div>
                <label className="text-xs">מחיר כניסה:</label>
                <input type="number" step="0.01" value={limitPrice || price} onChange={e => setLimitPrice(Number(e.target.value))}
                  className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-2" />
              </div>
            ) : (
              <div className="flex items-end">
                <div className="w-full bg-bg-card2 rounded px-2 py-2 text-center text-sm font-semibold">
                  שוק: ${price > 0 ? price.toFixed(2) : '—'}
                </div>
              </div>
            )}
          </div>
          <label className="block text-xs mb-3">
            מינוף: {leverage}x
            <input type="range" min={1} max={20} value={leverage} onChange={e => setLeverage(Number(e.target.value))} className="w-full mt-1 accent-accent-blue" />
          </label>
          <label className="block text-xs mb-3">
            Stop-Loss %: {slPct}%
            <input type="range" min={0.2} max={10} step={0.1} value={slPct} onChange={e => setSlPct(Number(e.target.value))} className="w-full mt-1 accent-down-red" />
          </label>
          <label className="block text-xs mb-4">
            Take-Profit %: {tpPct}%
            <input type="range" min={0.5} max={20} step={0.1} value={tpPct} onChange={e => setTpPct(Number(e.target.value))} className="w-full mt-1 accent-up-green" />
          </label>
          <div className="bg-bg-card2 rounded p-2 text-xs space-y-1 mb-3">
            <div className="flex justify-between"><span>מחיר שוק:</span><span>${price > 0 ? price.toFixed(2) : '—'}</span></div>
            <div className="flex justify-between"><span>גודל פוזיציה:</span><span>${(qtyUSDT * leverage).toFixed(2)}</span></div>
            <div className="flex justify-between"><span>בטחונות נדרשים:</span><span>${qtyUSDT.toFixed(2)}</span></div>
            <div className="flex justify-between"><span>חשש/סיכון:</span><span className="text-down-red">${(qtyUSDT * slPct / 100 * leverage).toFixed(2)}</span></div>
          </div>
          <Button variant={direction === 'LONG' ? 'success' : 'danger'} onClick={submit} className="w-full py-3">
            ⚡ בצע {direction === 'LONG' ? 'לונג' : 'שורט'} {symbol} {orderType === 'limit' ? '(Limit)' : '(Market)'}
          </Button>
        </Card>

        <div className="lg:col-span-2 space-y-4">
          <Card>
            <h3 className="font-bold mb-3">🕒 פקודות ממתינות - Pending ({pendingOrders.length})</h3>
            {pendingOrders.length === 0 ? (
              <p className="text-gray-400 text-sm">אין פקודות Limit ממתינות.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="text-xs text-gray-400 border-b border-border-soft">
                    <tr><th className="text-right py-2">מטבע</th><th className="text-right">כיוון</th><th className="text-right">מחיר מבוקש</th><th className="text-right">מחיר נוכחי</th><th className="text-right">מינוף</th><th className="text-right">סוג</th><th className="text-right"></th></tr>
                  </thead>
                  <tbody>
                    {pendingOrders.map(o => (
                      <tr key={o.id} className="border-b border-border-soft/50">
                        <td className="py-2 font-semibold">{o.symbol}</td>
                        <td><Badge color={o.direction === 'LONG' ? 'green' : 'red'}>{o.direction === 'LONG' ? 'לונג' : 'שורט'}</Badge></td>
                        <td>${o.entryPrice.toFixed(2)}</td>
                        <td>${(pricesRef.current[o.symbol] ?? o.entryPrice).toFixed(2)}</td>
                        <td>{o.leverage}x</td>
                        <td><Badge color="yellow">Limit</Badge></td>
                        <td><Button variant="ghost" onClick={() => cancel(o.id)}>בטל</Button></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>

          <Card>
            <h3 className="font-bold mb-3">📂 פוזיציות פתוחות ({openOrders.length})</h3>
            {openOrders.length === 0 ? (
              <p className="text-gray-400 text-sm">אין פוזיציות פתוחות כרגע.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="text-xs text-gray-400 border-b border-border-soft">
                    <tr><th className="text-right py-2">מטבע</th><th className="text-right">כיוון</th><th className="text-right">כניסה</th><th className="text-right">נוכחי</th><th className="text-right">מינוף</th><th className="text-right">P&L</th><th className="text-right">חיסול</th><th className="text-right"></th></tr>
                  </thead>
                  <tbody>
                    {openOrders.map(o => {
                      const cur = pricesRef.current[o.symbol] ?? o.entryPrice;
                      const pnl = unrealizedPnL(o, cur);
                      const liq = calcLiquidationPrice(o);
                      return (
                        <tr key={o.id} className="border-b border-border-soft/50">
                          <td className="py-2 font-semibold">{o.isCopy ? '📋 ' : ''}{o.symbol}</td>
                          <td><Badge color={o.direction === 'LONG' ? 'green' : 'red'}>{o.direction === 'LONG' ? 'לונג' : 'שורט'}</Badge></td>
                          <td>${o.entryPrice.toFixed(2)}</td>
                          <td>${cur.toFixed(2)}</td>
                          <td>{o.leverage}x</td>
                          <td className={pnl >= 0 ? 'text-up-green font-bold' : 'text-down-red font-bold'}>{pnl >= 0 ? '+' : ''}${pnl.toFixed(2)}</td>
                          <td className="text-down-red text-xs">${liq.toFixed(2)}</td>
                          <td><Button variant="ghost" onClick={() => close(o.id)}>סגור</Button></td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>
      </div>

      <Card>
        <h3 className="font-bold mb-3">📜 היסטוריית עסקאות (אחרונות 80)</h3>
        {closedOrders.length === 0 ? (
          <p className="text-gray-400 text-sm">אין עסקאות סגורות עדיין.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-xs text-gray-400 border-b border-border-soft">
                <tr><th className="text-right py-2">תאריך</th><th className="text-right">מטבע</th><th className="text-right">כיוון</th><th className="text-right">סוג</th><th className="text-right">כניסה</th><th className="text-right">יציאה</th><th className="text-right">מינוף</th><th className="text-right">P&L</th><th className="text-right">הערה</th></tr>
              </thead>
              <tbody>
                {closedOrders.map(o => (
                  <tr key={o.id} className="border-b border-border-soft/50">
                    <td className="py-2 text-xs text-gray-400">{new Date(o.closedAt || o.openedAt).toLocaleString('he-IL')}</td>
                    <td className="font-semibold">{o.symbol}</td>
                    <td><Badge color={o.direction === 'LONG' ? 'green' : 'red'}>{o.direction === 'LONG' ? 'לונג' : 'שורט'}</Badge></td>
                    <td><Badge color={o.orderType === 'limit' ? 'yellow' : 'blue'}>{o.orderType === 'limit' ? 'Limit' : 'Market'}</Badge></td>
                    <td>${o.entryPrice.toFixed(2)}</td>
                    <td>${o.closePrice?.toFixed(2) ?? '—'}</td>
                    <td>{o.leverage}x</td>
                    <td className={(o.pnl ?? 0) >= 0 ? 'text-up-green font-bold' : 'text-down-red font-bold'}>
                      {o.status === 'CANCELLED' ? '—' : `${(o.pnl ?? 0) >= 0 ? '+' : ''}$${(o.pnl ?? 0).toFixed(2)} (${o.pnlPct?.toFixed(2) ?? 0}%)`}
                    </td>
                    <td className="text-xs text-gray-400">{o.note || (o.status === 'CANCELLED' ? 'בוטל' : '-')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
