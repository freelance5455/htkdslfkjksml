import { useEffect, useState } from 'react';
import { Card, Button, Stat, Badge } from '../components/UI';
import { MasterTrader } from '../types';
import { loadState, saveState } from '../store/useStore';
import { setCopySettings } from '../services/copyTrading';

export function CopyTradingTab() {
  const [traders, setTraders] = useState<MasterTrader[]>([]);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [alloc, setAlloc] = useState<Record<string, number>>({});
  const [sl, setSl] = useState<Record<string, number>>({});
  const [maxPos, setMaxPos] = useState<Record<string, number>>({});
  const [levCap, setLevCap] = useState<Record<string, number>>({});

  useEffect(() => {
    const s = loadState();
    setTraders(s.traders);
    const a: any = {}, b: any = {}, c: any = {}, d: any = {};
    s.traders.forEach(t => {
      a[t.id] = t.copyAllocation ?? 500;
      b[t.id] = t.copyStopLoss ?? 5;
      c[t.id] = t.copyMaxPositions ?? 3;
      d[t.id] = t.copyLeverageCap ?? Math.min(t.riskScore, 5);
    });
    setAlloc(a); setSl(b); setMaxPos(c); setLevCap(d);
  }, []);

  const toggleCopy = (t: MasterTrader) => {
    const next = !t.isCopied;
    const s = setCopySettings(t.id, {
      isCopied: next,
      copyAllocation: alloc[t.id],
      copyStopLoss: sl[t.id],
      copyMaxPositions: maxPos[t.id],
      copyLeverageCap: levCap[t.id],
    });
    setTraders([...s.traders]);
  };

  const save = (id: string) => {
    const s = setCopySettings(id, {
      copyAllocation: alloc[id], copyStopLoss: sl[id], copyMaxPositions: maxPos[id], copyLeverageCap: levCap[id],
    });
    setTraders([...s.traders]);
  };

  return (
    <div className="space-y-4">
      <Card>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 className="text-xl font-bold">🏆 חיקוי עסקאות סוחרים - לוח מובילים</h2>
            <p className="text-sm text-gray-400 mt-1">בחר סוחר מוביל או אסטרטגיית AI, קבע תקציב והעתק עסקאות אוטומטית במסחר דמו.</p>
          </div>
          <Badge color="blue">סה"כ סוחרים: {traders.length}</Badge>
        </div>
      </Card>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {traders.map(t => (
          <Card key={t.id}>
            <div className="flex items-start gap-3">
              <div className="text-4xl">{t.avatar}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-bold">{t.name}</h3>
                  <Badge color={t.riskScore <= 4 ? 'green' : t.riskScore <= 7 ? 'yellow' : 'red'}>סיכון {t.riskScore}/10</Badge>
                  {t.isCopied && <Badge color="green">✓ עוקב</Badge>}
                </div>
                <p className="text-xs text-gray-400 mt-1">{t.description}</p>
                <p className="text-[11px] text-accent-cyan mt-1">שיטה: {t.strategy}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-4">
              <Stat label="Win Rate 7d" value={`${t.winRate7d}%`} color={t.winRate7d >= 75 ? 'text-up-green' : 'text-gray-200'} />
              <Stat label="ROI 7d" value={`${t.roi7d > 0 ? '+' : ''}${t.roi7d}%`} color={t.roi7d > 0 ? 'text-up-green' : 'text-down-red'} />
              <Stat label="ROI 30d" value={`${t.roi30d > 0 ? '+' : ''}${t.roi30d}%`} color={t.roi30d > 0 ? 'text-up-green' : 'text-down-red'} />
              <Stat label="Profit Factor" value={t.profitFactor.toFixed(2)} color={t.profitFactor >= 2 ? 'text-up-green' : 'text-gray-200'} />
              <Stat label="Max DD" value={`${t.maxDrawdown}%`} color="text-down-red" />
              <Stat label="עסקאות" value={t.trades} />
              <Stat label="מכפיל" value={`${levCap[t.id]}x`} />
              <Stat label="הקצאה" value={`$${alloc[t.id] ?? 0}`} />
            </div>
            <div className="mt-3">
              <button onClick={() => setExpanded(expanded === t.id ? null : t.id)} className="text-xs text-accent-cyan hover:underline">
                {expanded === t.id ? 'סגור הגדרות' : '⚙ הגדרות חיקוי מתקדמות'}
              </button>
              {expanded === t.id && (
                <div className="mt-3 bg-bg-card2 rounded-lg p-3 space-y-2">
                  <label className="block text-xs">
                    תקציב הקצאה ($):
                    <input type="number" value={alloc[t.id] || 0} onChange={e => setAlloc({ ...alloc, [t.id]: Number(e.target.value) })}
                      className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-1" />
                  </label>
                  <label className="block text-xs">
                    Stop-Loss מקסימלי (%):
                    <input type="number" value={sl[t.id] || 0} onChange={e => setSl({ ...sl, [t.id]: Number(e.target.value) })}
                      className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-1" />
                  </label>
                  <label className="block text-xs">
                    מקסימום פוזיציות פתוחות:
                    <input type="number" value={maxPos[t.id] || 1} onChange={e => setMaxPos({ ...maxPos, [t.id]: Number(e.target.value) })}
                      className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-1" />
                  </label>
                  <label className="block text-xs">
                    תקרת מינוף:
                    <input type="number" min={1} max={20} value={levCap[t.id] || 1} onChange={e => setLevCap({ ...levCap, [t.id]: Number(e.target.value) })}
                      className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-1" />
                  </label>
                  <Button variant="ghost" onClick={() => save(t.id)} className="w-full mt-2">שמור הגדרות</Button>
                </div>
              )}
            </div>
            <div className="mt-3 flex gap-2">
              <Button variant={t.isCopied ? 'danger' : 'success'} onClick={() => toggleCopy(t)} className="flex-1">
                {t.isCopied ? 'הפסק חיקוי' : 'עקוב ושכפל'}
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
