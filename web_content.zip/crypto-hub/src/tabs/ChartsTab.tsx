import { useEffect, useState, useRef } from 'react';
import { Card } from '../components/UI';
import { CandleChart } from '../components/CandleChart';
import { RsiPanel, MacdPanel } from '../components/IndicatorPanels';
import { LiveOrderBook } from '../components/LiveOrderBook';
import { TradeTape } from '../components/TradeTape';
import { RiskCalculator } from '../components/RiskCalculator';
import { DCACalculator } from '../components/DCACalculator';
import { fetchKlines } from '../services/marketService';
import { wsClient } from '../services/websocketService';
import { Kline } from '../types';

const PAIRS = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT', 'DOGEUSDT', 'AVAXUSDT', 'LINKUSDT', 'MATICUSDT'];
const INTERVALS = [
  { v: '1', l: '1ד' }, { v: '5', l: '5ד' }, { v: '15', l: '15ד' }, { v: '60', l: '1ש' }, { v: '240', l: '4ש' }, { v: 'D', l: 'יומי' },
];

export function ChartsTab() {
  const [symbol, setSymbol] = useState('BTCUSDT');
  const [interval, setIntervalOpt] = useState('15');
  const [klines, setKlines] = useState<Kline[]>([]);
  const [loading, setLoading] = useState(true);
  const [livePrice, setLivePrice] = useState<number>(0);
  const liveRef = useRef(0);

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    fetchKlines(symbol, interval, 200).then(k => {
      if (!mounted) return;
      const safe = Array.isArray(k) ? k : [];
      setKlines(safe);
      setLivePrice(safe[safe.length - 1]?.close ?? 0);
      liveRef.current = safe[safe.length - 1]?.close ?? 0;
      setLoading(false);
    });
    const id = setInterval(async () => {
      const k = await fetchKlines(symbol, interval, 200);
      if (mounted && Array.isArray(k) && k.length > 0) {
        setKlines(k);
        // Preserve WS price if newer than last candle close
        const lastClose = k[k.length - 1]?.close ?? 0;
        setLivePrice(liveRef.current > 0 ? liveRef.current : lastClose);
      }
    }, 15000);
    return () => { mounted = false; clearInterval(id); };
  }, [symbol, interval]);

  // Subscribe to WS ticker for live price updates
  useEffect(() => {
    wsClient.watch([symbol]);
    const unsub = wsClient.subscribe({
      onTicker: (t) => {
        if (t.symbol === symbol) { setLivePrice(t.price); liveRef.current = t.price; }
      },
    });
    return () => { unsub(); };
  }, [symbol]);

  useEffect(() => {
    // Ensure WS is connected
    try { wsClient.connect(); } catch {}
  }, []);

  const last = klines[klines.length - 1];
  const first = klines[0];
  const change = last && first ? ((livePrice - first.close) / first.close) * 100 : 0;
  const high = klines.length ? Math.max(...klines.map(k => k.high)) : 0;
  const low = klines.length ? Math.min(...klines.map(k => k.low)) : 0;
  const vol24 = klines.slice(-96).reduce((s, k) => s + k.volume * k.close, 0);

  return (
    <div className="space-y-4">
      <Card>
        <div className="flex flex-wrap items-center gap-3 mb-4">
          <h2 className="text-xl font-bold flex-1">📈 גרפים וספר פקודות - 200 נרות</h2>
          <select value={symbol} onChange={e => setSymbol(e.target.value)}
            className="bg-bg-dark border border-border-soft rounded px-3 py-2 text-sm">
            {PAIRS.map(p => <option key={p} value={p}>{p}</option>)}
          </select>
          <div className="flex gap-1 flex-wrap">
            {INTERVALS.map(i => (
              <button key={i.v} onClick={() => setIntervalOpt(i.v)}
                className={`px-3 py-1 rounded text-xs font-semibold ${interval === i.v ? 'bg-accent-blue text-white' : 'bg-bg-card2 text-gray-300 hover:bg-bg-card2/70'}`}>
                {i.l}
              </button>
            ))}
          </div>
        </div>
        {loading ? <div className="py-20 text-center text-gray-400">טוען נתונים חיים...</div> : (
          <>
            <div className="flex flex-wrap gap-4 mb-3 text-sm">
              <span>מחיר: <strong className="text-accent-cyan">${livePrice > 0 ? livePrice.toFixed(2) : last?.close.toFixed(2)}</strong></span>
              <span>שינוי: <strong className={change >= 0 ? 'text-up-green' : 'text-down-red'}>{change >= 0 ? '+' : ''}{change.toFixed(2)}%</strong></span>
              <span>גבוה: <strong className="text-up-green">${high.toFixed(2)}</strong></span>
              <span>נמוך: <strong className="text-down-red">${low.toFixed(2)}</strong></span>
              <span>נפח: <strong>${(vol24 / 1e6).toFixed(1)}M</strong></span>
            </div>
            <div className="grid grid-cols-1 xl:grid-cols-4 gap-3">
              <div className="xl:col-span-3 space-y-2">
                <CandleChart klines={klines} />
                <div className="border border-border-soft rounded-lg overflow-hidden">
                  <RsiPanel klines={klines} height={120} />
                </div>
                <div className="border border-border-soft rounded-lg overflow-hidden">
                  <MacdPanel klines={klines} height={120} />
                </div>
              </div>
              <div className="xl:col-span-1 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-1 gap-3">
                <LiveOrderBook symbol={symbol} livePrice={livePrice} />
                <TradeTape symbol={symbol} />
                <RiskCalculator balance={10000} />
                <DCACalculator />
              </div>
            </div>
          </>
        )}
      </Card>
    </div>
  );
}
