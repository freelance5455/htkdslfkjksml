import { useEffect, useState } from 'react';
import { Card, Stat, Badge, Button } from '../components/UI';
import { EquityCurve } from '../components/EquityCurve';
import { MarketTicker, PaperOrder } from '../types';
import { loadState } from '../store/useStore';
import { addAlert, checkAlerts, loadAlerts, PriceAlert, removeAlert } from '../services/alertsService';
import { notificationsService } from '../services/notificationsService';

export function DashboardTab({ tickers }: { tickers: MarketTicker[] }) {
  const [orders, setOrders] = useState<PaperOrder[]>([]);
  const [balance, setBalance] = useState(10000);
  const [initialBal, setInitialBal] = useState(10000);
  const [alerts, setAlerts] = useState<PriceAlert[]>([]);
  const [watching, setWatching] = useState<string[]>(['BTCUSDT', 'ETHUSDT', 'SOLUSDT']);
  const [alertSym, setAlertSym] = useState('BTCUSDT');
  const [alertDir, setAlertDir] = useState<'above' | 'below'>('above');
  const [alertPrice, setAlertPrice] = useState(70000);

  useEffect(() => {
    const refresh = () => {
      const s = loadState();
      setOrders(s.orders);
      setBalance(s.paperBalance);
      setInitialBal(s.initialBalance);
    };
    refresh();
    const id = setInterval(refresh, 3000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const pm: Record<string, number> = {};
    tickers.forEach(t => pm[t.symbol] = t.price);
    if (Object.keys(pm).length) {
      const a = checkAlerts(pm);
      setAlerts([...a]);
    }
  }, [tickers]);

  const roi = ((balance - initialBal) / initialBal) * 100;
  const open = orders.filter(o => o.status === 'OPEN');
  const closed = orders.filter(o => o.status === 'CLOSED');
  const wins = closed.filter(o => (o.pnl ?? 0) > 0).length;
  const losses = closed.filter(o => (o.pnl ?? 0) <= 0).length;
  const winrate = closed.length > 0 ? (wins / closed.length) * 100 : 0;
  const profitFactor = (() => {
    const gw = closed.reduce((s, o) => s + Math.max(0, o.pnl ?? 0), 0);
    const gl = closed.reduce((s, o) => s + Math.max(0, -(o.pnl ?? 0)), 0);
    return gl === 0 ? (gw > 0 ? Infinity : 0) : gw / gl;
  })();
  const biggestWin = closed.reduce((m, o) => Math.max(m, o.pnl ?? 0), 0);
  const biggestLoss = closed.reduce((m, o) => Math.min(m, o.pnl ?? 0), 0);
  const avgWin = wins > 0 ? closed.filter(o => (o.pnl ?? 0) > 0).reduce((s, o) => s + (o.pnl ?? 0), 0) / wins : 0;
  const avgLoss = losses > 0 ? closed.filter(o => (o.pnl ?? 0) <= 0).reduce((s, o) => s + (o.pnl ?? 0), 0) / losses : 0;

  const topGainers = [...tickers].sort((a, b) => b.change24h - a.change24h).slice(0, 5);
  const topLosers = [...tickers].sort((a, b) => a.change24h - b.change24h).slice(0, 5);

  const createAlert = () => {
    addAlert(alertSym, alertDir, alertPrice);
    setAlerts(loadAlerts());
    notificationsService.sendPush('התראה נוצרה', `תקבל/י התראה כש-${alertSym} ${alertDir === 'above' ? 'יחצה מעל' : 'ירד מתחת'} $${alertPrice}`);
  };

  const rmAlert = (id: string) => { removeAlert(id); setAlerts(loadAlerts()); };

  const toggleWatch = (sym: string) => {
    setWatching(w => w.includes(sym) ? w.filter(x => x !== sym) : [...w, sym].slice(0, 12));
  };

  return (
    <div className="space-y-4">
      <Card>
        <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
          <div>
            <h2 className="text-2xl font-bold">👋 ברוכים הבאים לקריפטו האב</h2>
            <p className="text-sm text-gray-400 mt-1">לוח בקרה ראשי - ביצועי תיק, סנטימנט שוק, רשימת מעקב והתראות מחיר</p>
          </div>
          <Badge color="blue">{new Date().toLocaleDateString('he-IL', { weekday: 'long', day: 'numeric', month: 'long' })}</Badge>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Stat label="יתרה בדמו" value={`$${balance.toFixed(2)}`} sub={`התחלתי: $${initialBal.toFixed(0)}`} />
          <Stat label="תשואה כוללת" value={`${roi >= 0 ? '+' : ''}${roi.toFixed(2)}%`} color={roi >= 0 ? 'text-up-green' : 'text-down-red'} sub={`${roi >= 0 ? 'רווח' : 'הפסד'} $${(balance - initialBal).toFixed(2)}`} />
          <Stat label="אחוז הצלחה" value={`${winrate.toFixed(0)}%`} color={winrate >= 60 ? 'text-up-green' : 'text-gray-200'} sub={`${wins} ניצחונות / ${losses} הפסדים`} />
          <Stat label="Profit Factor" value={profitFactor === Infinity ? '∞' : profitFactor.toFixed(2)} color={profitFactor >= 1.5 ? 'text-up-green' : 'text-gray-200'} sub={`עסקאות: ${closed.length}`} />
        </div>
        <div className="mt-4">
          <div className="text-sm font-bold mb-1 text-accent-cyan">📈 עקומת הון</div>
          <EquityCurve orders={orders} initialBalance={initialBal} currentBalance={balance} />
        </div>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        <Card>
          <div className="text-sm font-bold text-up-green mb-2">🔥 חמש העולות (24ש)</div>
          <div className="space-y-1 text-sm">
            {topGainers.map(t => (
              <div key={t.symbol} className="flex justify-between">
                <span className="font-semibold">{t.symbol.replace('USDT', '')}</span>
                <span className="text-up-green font-bold">+{t.change24h.toFixed(2)}%</span>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <div className="text-sm font-bold text-down-red mb-2">🧊 חמש היורדות (24ש)</div>
          <div className="space-y-1 text-sm">
            {topLosers.map(t => (
              <div key={t.symbol} className="flex justify-between">
                <span className="font-semibold">{t.symbol.replace('USDT', '')}</span>
                <span className="text-down-red font-bold">{t.change24h.toFixed(2)}%</span>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <div className="text-sm font-bold text-accent-cyan mb-2">📊 סטטיסטיקות</div>
          <div className="space-y-1 text-xs">
            <div className="flex justify-between"><span>רווח ממוצע:</span><span className="text-up-green">${avgWin.toFixed(2)}</span></div>
            <div className="flex justify-between"><span>הפסד ממוצע:</span><span className="text-down-red">${avgLoss.toFixed(2)}</span></div>
            <div className="flex justify-between"><span>רווח מקס׳:</span><span className="text-up-green">${biggestWin.toFixed(2)}</span></div>
            <div className="flex justify-between"><span>הפסד מקס׳:</span><span className="text-down-red">${biggestLoss.toFixed(2)}</span></div>
            <div className="flex justify-between"><span>פוזיציות פתוחות:</span><span>{open.length}</span></div>
          </div>
        </Card>
        <Card>
          <div className="text-sm font-bold text-warn-yellow mb-2">🚨 התראות מחיר פעילות</div>
          <div className="text-xs mb-2 grid grid-cols-2 gap-1">
            <select value={alertSym} onChange={e => setAlertSym(e.target.value)} className="bg-bg-dark border border-border-soft rounded px-1 py-1">
              {tickers.slice(0, 30).map(t => <option key={t.symbol} value={t.symbol}>{t.symbol}</option>)}
            </select>
            <select value={alertDir} onChange={e => setAlertDir(e.target.value as any)} className="bg-bg-dark border border-border-soft rounded px-1 py-1">
              <option value="above">מעל</option>
              <option value="below">מתחת</option>
            </select>
            <input type="number" value={alertPrice} onChange={e => setAlertPrice(Number(e.target.value))}
              className="col-span-1 bg-bg-dark border border-border-soft rounded px-1 py-1" placeholder="מחיר" />
            <Button variant="success" onClick={createAlert} className="text-xs py-1">+ הוסף</Button>
          </div>
          <div className="space-y-1 max-h-[130px] overflow-y-auto">
            {alerts.filter(a => !a.triggered).length === 0 && <p className="text-gray-500 text-xs">אין התראות פעילות</p>}
            {alerts.filter(a => !a.triggered).map(a => (
              <div key={a.id} className="flex items-center justify-between bg-bg-card2 rounded px-2 py-1 text-xs">
                <span>{a.symbol} {a.condition === 'above' ? '≥' : '≤'} ${a.price.toFixed(2)}</span>
                <button onClick={() => rmAlert(a.id)} className="text-down-red">✕</button>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card>
        <h3 className="font-bold mb-3">⭐ רשימת מעקב</h3>
        <div className="flex flex-wrap gap-2 mb-3">
          {tickers.slice(0, 30).map(t => (
            <button key={t.symbol} onClick={() => toggleWatch(t.symbol)}
              className={`px-2 py-1 rounded text-xs font-semibold transition ${watching.includes(t.symbol) ? 'bg-accent-blue text-white' : 'bg-bg-card2 text-gray-400'}`}>
              {t.symbol.replace('USDT', '')}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {watching.map(sym => {
            const t = tickers.find(x => x.symbol === sym);
            if (!t) return null;
            return (
              <div key={sym} className="bg-bg-card2 rounded-lg p-3">
                <div className="flex justify-between items-center">
                  <span className="font-bold">{sym.replace('USDT', '')}</span>
                  <Badge color={t.change24h >= 0 ? 'green' : 'red'}>{t.change24h >= 0 ? '+' : ''}{t.change24h.toFixed(2)}%</Badge>
                </div>
                <div className="text-lg font-bold text-accent-cyan mt-1">${t.price < 1 ? t.price.toFixed(4) : t.price.toFixed(2)}</div>
                <div className="text-[11px] text-gray-400 mt-1">נ"פ 24ש: ${(t.volume24h / 1e6).toFixed(1)}M</div>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
