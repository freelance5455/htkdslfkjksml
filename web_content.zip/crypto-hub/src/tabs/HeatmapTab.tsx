import { useEffect, useState, useRef } from 'react';
import { Card, Stat, Badge } from '../components/UI';
import { MarketTicker } from '../types';
import { fetchCoinsMarket, fetchTickers } from '../services/marketService';
import { fetchSentiment, SentimentData, fallbackSentiment } from '../services/sentimentService';
import { SquarifiedTreemap } from '../components/SquarifiedTreemap';

export function HeatmapTab() {
  const [coins, setCoins] = useState<MarketTicker[]>([]);
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState<'mcap' | 'vol'>('mcap');
  const [sentiment, setSentiment] = useState<SentimentData>(fallbackSentiment());
  const wrapRef = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState({ w: 1200, h: 640 });

  useEffect(() => {
    (async () => {
      setLoading(true);
      let c: MarketTicker[] = [];
      const gecko = await fetchCoinsMarket();
      if (gecko.length > 0) c = gecko;
      else {
        const binance = await fetchTickers();
        c = binance.filter(t => ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'XRPUSDT', 'ADAUSDT', 'DOGEUSDT', 'AVAXUSDT', 'DOTUSDT', 'MATICUSDT', 'LINKUSDT', 'LTCUSDT', 'UNIUSDT', 'ATOMUSDT', 'ETCUSDT', 'NEARUSDT', 'APTUSDT', 'ARBUSDT', 'OPUSDT', 'FILUSDT', 'AAVEUSDT', 'SUIUSDT', 'INJUSDT', 'IMXUSDT', 'RNDRUSDT', 'TRXUSDT', 'SHIBUSDT', 'PEPEUSDT'].includes(t.symbol));
      }
      setCoins(Array.isArray(c) ? c : []);
      const s = await fetchSentiment(Array.isArray(c) ? c : []);
      setSentiment(s);
      setLoading(false);
    })();
    const onResize = () => {
      if (wrapRef.current) setSize({ w: wrapRef.current.clientWidth, h: Math.min(700, Math.max(400, wrapRef.current.clientWidth * 0.5)) });
    };
    onResize();
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  const fgColor = sentiment.fearGreedValue <= 25 ? 'text-down-red' : sentiment.fearGreedValue <= 45 ? 'text-warn-yellow' : sentiment.fearGreedValue <= 65 ? 'text-accent-cyan' : 'text-up-green';
  const advRatio = sentiment.total > 0 ? (sentiment.advancers / sentiment.total) * 100 : 50;

  const data = coins.map(c => ({
    id: c.symbol,
    name: c.symbol.replace('USDT', ''),
    value: mode === 'mcap' ? (c.marketCap || c.volume24h) : c.volume24h,
    change: c.change24h,
    price: c.price,
  }));

  return (
    <div className="space-y-4">
      <Card>
        <div className="flex flex-wrap items-center gap-3 mb-4">
          <h2 className="text-xl font-bold flex-1">🗺️ מפת חום שוק הקריפטו</h2>
          <button onClick={() => setMode('mcap')} className={`px-3 py-1 rounded text-sm ${mode === 'mcap' ? 'bg-accent-blue text-white' : 'bg-bg-card2'}`}>לפי שווי שוק</button>
          <button onClick={() => setMode('vol')} className={`px-3 py-1 rounded text-sm ${mode === 'vol' ? 'bg-accent-blue text-white' : 'bg-bg-card2'}`}>לפי נפח 24ש</button>
          <div className="flex items-center gap-1 text-xs text-gray-400">
            <span className="inline-block w-5 h-5" style={{ backgroundColor: 'rgb(255,40,60)' }}></span> -5%
            <span className="inline-block w-5 h-5 mx-1" style={{ backgroundColor: 'rgb(55,55,80)' }}></span> 0%
            <span className="inline-block w-5 h-5" style={{ backgroundColor: 'rgb(16,255,90)' }}></span> +5%
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <div className="bg-bg-card2 rounded p-3 text-center">
            <div className="text-xs text-gray-400 mb-1">😱 Fear & Greed</div>
            <div className={`text-2xl font-bold ${fgColor}`}>{sentiment.fearGreedValue}</div>
            <div className="text-xs mt-1">{sentiment.fearGreedLabel}</div>
          </div>
          <Stat label="שווי שוק כולל" value={`$${(sentiment.totalMarketCap / 1e12).toFixed(2)}T`} sub="Total Market Cap" />
          <Stat label="דומיננטיות ביטקוין" value={`${sentiment.btcDominance.toFixed(1)}%`} />
          <Stat label="עולות / יורדות" value={`${sentiment.advancers} / ${sentiment.decliners}`}
            color={advRatio > 60 ? 'text-up-green' : advRatio < 40 ? 'text-down-red' : 'text-gray-200'} />
          <Stat label="סנטימנט שוק"
            value={sentiment.marketSentiment === 'green' ? 'שורי' : sentiment.marketSentiment === 'red' ? 'דובי' : 'ניטראלי'}
            color={sentiment.marketSentiment === 'green' ? 'text-up-green' : sentiment.marketSentiment === 'red' ? 'text-down-red' : 'text-warn-yellow'} />
        </div>
      </Card>
      {loading ? (
        <Card><div className="py-20 text-center text-gray-400">טוען נתוני שוק...</div></Card>
      ) : (
        <Card className="p-2">
          <div ref={wrapRef} className="w-full">
            <SquarifiedTreemap data={data} width={size.w} height={size.h} />
          </div>
        </Card>
      )}
    </div>
  );
}
