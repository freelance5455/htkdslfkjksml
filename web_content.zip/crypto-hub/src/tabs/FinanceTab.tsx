import { useEffect, useState } from 'react';
import { Card, Button, Stat, Badge } from '../components/UI';
import { Invoice, TaxRecord } from '../types';
import { loadState, saveState, uid } from '../store/useStore';
import { computeTaxSummary, generateInvoice, exportCSV, usdToILS } from '../utils/tax';

export function FinanceTab() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [taxRecords, setTaxRecords] = useState<TaxRecord[]>([]);
  const [pnl, setPnl] = useState(0);
  // Invoice form
  const [invAmount, setInvAmount] = useState(100);
  const [invCurrency, setInvCurrency] = useState<'USDT' | 'ILS'>('USDT');
  const [invDesc, setInvDesc] = useState('תשלום עבור שירותי ייעוץ קריפטו');
  // Tax form
  const [taxSymbol, setTaxSymbol] = useState('BTC');
  const [taxType, setTaxType] = useState<'buy' | 'sell' | 'trade'>('sell');
  const [taxAmount, setTaxAmount] = useState(0.1);
  const [taxPrice, setTaxPrice] = useState(250000);
  const [taxGain, setTaxGain] = useState(0);
  const [taxNotes, setTaxNotes] = useState('');

  useEffect(() => { refresh(); }, []);
  const refresh = () => {
    const s = loadState();
    // Build tax records from paper orders for convenience
    const fromOrders: TaxRecord[] = s.orders.filter(o => o.status === 'CLOSED').map(o => ({
      id: 'tax-' + o.id,
      date: o.closedAt!,
      type: o.direction === 'LONG' ? 'sell' : 'sell', // close = sell base
      symbol: o.symbol,
      amount: o.quantity,
      priceILS: usdToILS(o.closePrice ?? o.entryPrice),
      gainILS: usdToILS(o.pnl ?? 0),
      notes: o.note || 'מסחר דמו',
    }));
    const extra = s.taxRecords || [];
    setTaxRecords([...extra, ...fromOrders]);
    setInvoices(s.invoices || []);
    setPnl(s.paperBalance - s.initialBalance);
  };

  const summary = computeTaxSummary(taxRecords);

  const addInvoice = () => {
    const s = loadState();
    const inv = generateInvoice(invAmount, invCurrency, invDesc);
    s.invoices = [inv, ...(s.invoices || [])];
    saveState(s);
    refresh();
    window.dispatchEvent(new CustomEvent('crypto-toast', { detail: { title: 'חשבונית נוצרה', body: `מספר חשבונית: ${inv.id}` } }));
  };

  const markPaid = (id: string) => {
    const s = loadState();
    const inv = (s.invoices || []).find(i => i.id === id);
    if (inv) { inv.status = 'paid'; saveState(s); refresh(); }
  };

  const addTaxRecord = () => {
    const s = loadState();
    const rec: TaxRecord = {
      id: uid(), date: Date.now(), type: taxType, symbol: taxSymbol,
      amount: taxAmount, priceILS: taxPrice, gainILS: taxGain, notes: taxNotes,
    };
    s.taxRecords = [rec, ...(s.taxRecords || [])];
    saveState(s);
    refresh();
  };

  const downloadCSV = () => {
    const csv = exportCSV(taxRecords);
    // Add BOM for Hebrew encoding
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `crypto-tax-${new Date().toISOString().slice(0, 10)}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      <Card>
        <h2 className="text-xl font-bold mb-4">🧾 פיננסים, מיסוי ודוחות - רשות המסים בישראל</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Stat label="P&L כולל (USD)" value={`$${pnl.toFixed(2)}`} color={pnl >= 0 ? 'text-up-green' : 'text-down-red'} />
          <Stat label="P&L חייב (ILS)" value={`₪${summary.netTaxableILS.toFixed(2)}`} />
          <Stat label="מס רווחי הון 25%" value={`₪${summary.capitalGainsTax25.toFixed(2)}`} color="text-warn-yellow" sub="מחזור מזדמן" />
          <Stat label="מס עסקי 50%" value={`₪${summary.businessIncomeTax50.toFixed(2)}`} color="text-down-red" sub="אם מסווג כעסק" />
        </div>
        <div className="mt-3 flex gap-2 flex-wrap items-center">
          <Badge color="green">עסקאות מרוויחות: {summary.winningTrades}</Badge>
          <Badge color="red">עסקאות מפסידות: {summary.losingTrades}</Badge>
          <Button variant="ghost" onClick={downloadCSV}>⬇ יצוא CSV (טופס 909)</Button>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <h3 className="font-bold mb-3">📄 מחולל חשבוניות USDT/ILS</h3>
          <label className="block text-xs mb-2">
            סכום:
            <input type="number" value={invAmount} onChange={e => setInvAmount(Number(e.target.value))}
              className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-2" />
          </label>
          <label className="block text-xs mb-2">
            מטבע:
            <select value={invCurrency} onChange={e => setInvCurrency(e.target.value as any)} className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-2">
              <option value="USDT">USDT</option>
              <option value="ILS">ILS (₪)</option>
            </select>
          </label>
          <label className="block text-xs mb-3">
            תיאור:
            <input type="text" value={invDesc} onChange={e => setInvDesc(e.target.value)}
              className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-2" />
          </label>
          <Button onClick={addInvoice} variant="success" className="w-full">צור חשבונית דיגיטלית</Button>
          <div className="mt-4 space-y-2 max-h-[300px] overflow-y-auto">
            {invoices.length === 0 && <p className="text-gray-400 text-sm">אין חשבוניות עדיין.</p>}
            {invoices.map(inv => (
              <div key={inv.id} className="bg-bg-card2 rounded p-3 text-xs">
                <div className="flex justify-between items-center">
                  <span className="font-bold">#{inv.id}</span>
                  <Badge color={inv.status === 'paid' ? 'green' : 'yellow'}>{inv.status === 'paid' ? 'שולם' : 'ממתין'}</Badge>
                </div>
                <div>{inv.amount} {inv.currency} - {inv.description}</div>
                <div className="text-gray-400">{new Date(inv.createdAt).toLocaleDateString('he-IL')}</div>
                {inv.status === 'pending' && inv.currency === 'USDT' && (
                  <>
                    <div className="text-accent-cyan mt-1 break-all">כתובת ארנק: {inv.walletAddress}</div>
                    <Button variant="success" className="mt-2 text-xs" onClick={() => markPaid(inv.id)}>סמן כשולם</Button>
                  </>
                )}
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <h3 className="font-bold mb-3">📒 יומן עסקאות לדוח מס</h3>
          <div className="grid grid-cols-2 gap-2 text-xs mb-3">
            <label>
              סוג:
              <select value={taxType} onChange={e => setTaxType(e.target.value as any)} className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-2">
                <option value="buy">קנייה</option>
                <option value="sell">מכירה</option>
                <option value="trade">המרה</option>
              </select>
            </label>
            <label>
              מטבע:
              <input value={taxSymbol} onChange={e => setTaxSymbol(e.target.value)}
                className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-2" />
            </label>
            <label>
              כמות:
              <input type="number" value={taxAmount} onChange={e => setTaxAmount(Number(e.target.value))}
                className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-2" />
            </label>
            <label>
              מחיר ב-₪:
              <input type="number" value={taxPrice} onChange={e => setTaxPrice(Number(e.target.value))}
                className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-2" />
            </label>
            <label>
              רווח/הפסד ₪:
              <input type="number" value={taxGain} onChange={e => setTaxGain(Number(e.target.value))}
                className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-2" />
            </label>
            <label>
              הערות:
              <input value={taxNotes} onChange={e => setTaxNotes(e.target.value)}
                className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-2" />
            </label>
          </div>
          <Button onClick={addTaxRecord} className="w-full mb-3">הוסף רשומה</Button>
          <div className="overflow-x-auto max-h-[300px] overflow-y-auto">
            <table className="w-full text-xs">
              <thead className="text-gray-400 border-b border-border-soft"><tr><th className="text-right py-1">תאריך</th><th className="text-right">סוג</th><th className="text-right">מטבע</th><th className="text-right">רווח ₪</th></tr></thead>
              <tbody>
                {taxRecords.map(r => (
                  <tr key={r.id} className="border-b border-border-soft/50">
                    <td className="py-1">{new Date(r.date).toLocaleDateString('he-IL')}</td>
                    <td>{r.type === 'buy' ? 'קנייה' : r.type === 'sell' ? 'מכירה' : 'המרה'}</td>
                    <td>{r.symbol}</td>
                    <td className={(r.gainILS ?? 0) >= 0 ? 'text-up-green' : 'text-down-red'}>{(r.gainILS ?? 0).toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>

      <Card>
        <h3 className="font-bold mb-2">⚖️ מידע משפטי - רשות המסים בישראל</h3>
        <div className="text-sm text-gray-300 leading-relaxed space-y-2">
          <p>▸ <strong>מס רווחי הון (25%):</strong> אם מדובר בהשקעה פסיבית מזדמנת בקריפטו, הרווח ממוסה ב-25% ללא קיזוז הוצאות.</p>
          <p>▸ <strong>הכנסה עסקית (עד 50%):</strong> אם אתה סוחר בתדירות גבוהה, מנהל תיק לקוחות או כורה, רשות המסים עשויה לסווג אותך כ"עסק" ולהטיל מס שולי עד 50% + מע"מ וביטוח לאומי.</p>
          <p>▸ <strong>טופס 909:</strong> נדרש לדווח על רווחי הון בדוח השנתי. השתמש ביצוא ה-CSV כדי להזין נתונים.</p>
          <p>▸ <strong>קיזוז הפסדים:</strong> ניתן לקזז הפסדי קריפטו מרווחי הון אחרים. שמור רישום מדויק.</p>
          <p className="text-warn-yellow">⚠ אין לראות באפליקציה ייעוץ מס. התייעץ עם רואה חשבון מוסמך לפני הגשת דוחות.</p>
        </div>
      </Card>
    </div>
  );
}
