import { useEffect, useState, useCallback } from 'react';
import { Card, Button, Stat, Badge } from '../components/UI';
import { fetchKlines } from '../services/marketService';
import { Kline, TradeSignal } from '../types';
import { generateSignal } from '../utils/signalEngine';
import { loadState } from '../store/useStore';
import { openOrder } from '../services/paperTrading';
import { ConfluenceMatrix } from '../components/ConfluenceMatrix';

const SYMBOLS = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT', 'DOGEUSDT', 'ADAUSDT', 'AVAXUSDT', 'LINKUSDT', 'MATICUSDT', 'DOTUSDT'];

export function SignalsTab({ onScan, scanning, lastScan }: { onScan: () => void; scanning: boolean; lastScan: Date | null }) {
  const [signals, setSignals] = useState<TradeSignal[]>([]);
  const [prices, setPrices] = useState<Record<string, number>>({});
  const [selected, setSelected] = useState<string>('BTCUSDT');
  const [klinesMap, setKlinesMap] = useState<Record<string, Kline[]>>({});
  const [balance, setBalance] = useState<number>(10000);

  const loadAll = useCallback(async () => {
    const state = loadState();
    setBalance(state.paperBalance);
    const sigs: TradeSignal[] = [];
    const km: Record<string, Kline[]> = {};
    const pr: Record<string, number> = {};
    await Promise.all(SYMBOLS.map(async (sym) => {
      try {
        const k = await fetchKlines(sym, '15', 200);
        km[sym] = k;
        pr[sym] = k[k.length - 1]?.close ?? 0;
        const s = generateSignal(sym, k, state.paperBalance);
        if (s) sigs.push(s);
      } catch (e) { console.warn(sym, e); }
    }));
    setKlinesMap(km);
    setPrices(pr);
    // Sort: active LONG/SHORT first, then by confidence desc
    sigs.sort((a, b) => {
      const sa = a.direction === 'WAIT' ? 0 : 1;
      const sb = b.direction === 'WAIT' ? 0 : 1;
      if (sa !== sb) return sb - sa;
      return b.confidence - a.confidence;
    });
    setSignals(sigs);
  }, []);

  useEffect(() => { loadAll(); }, [loadAll, lastScan]);

  const sel = signals.find(s => s.symbol === selected) || signals[0];
  const selKlines = klinesMap[selected] ?? [];

  const executeOnPaper = (s: TradeSignal) => {
    if (s.direction === 'WAIT') return;
    const qty = s.positionSizeUSDT * s.leverage / s.entry;
    const res = openOrder({
      symbol: s.symbol,
      direction: s.direction,
      entryPrice: s.entry,
      quantity: qty,
      leverage: s.leverage,
      sl: s.sl,
      tp: s.tp1,
      note: 'אות AI',
    });
    if (res.error) {
      window.dispatchEvent(new CustomEvent('crypto-toast', { detail: { title: 'שגיאה', body: res.error } }));
    } else {
      setBalance(loadState().paperBalance);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      <div className="lg:col-span-2 space-y-4">
        <Card>
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <div>
              <h2 className="text-xl font-bold">📊 ניתוח מעמיק ואיתותי AI - {sel?.symbol || 'BTCUSDT'}</h2>
              <p className="text-sm text-gray-400 mt-1">
                {lastScan ? `סריקה אחרונה: ${lastScan.toLocaleTimeString('he-IL')}` : 'טוען נתונים חיים...'}
              </p>
            </div>
            <Button onClick={onScan} disabled={scanning} variant="primary">
              {scanning ? '⟳ סורק...' : 'סריקה ידנית עכשיו'}
            </Button>
          </div>
          {sel && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
              <Stat label="כיוון" value={sel.direction === 'LONG' ? 'לונג LONG' : sel.direction === 'SHORT' ? 'שורט SHORT' : 'המתנה WAIT'}
                color={sel.direction === 'LONG' ? 'text-up-green' : sel.direction === 'SHORT' ? 'text-down-red' : 'text-gray-400'} />
              <Stat label="רמת ביטחון" value={`${sel.confidence}%`} color={sel.confidence >= 70 ? 'text-up-green' : sel.confidence >= 50 ? 'text-warn-yellow' : 'text-down-red'} />
              <Stat label="כניסה" value={`$${sel.entry.toFixed(2)}`} />
              <Stat label="מינוף מומלץ" value={`${sel.leverage}x`} />
            </div>
          )}
          {sel && (
            <div className="grid grid-cols-3 gap-3 mb-4">
              <Stat label="Stop-Loss" value={`$${sel.sl.toFixed(2)}`} color="text-down-red" sub={`מרחק ${((Math.abs(sel.entry - sel.sl) / sel.entry) * 100).toFixed(2)}%`} />
              <Stat label="TP1" value={`$${sel.tp1.toFixed(2)}`} color="text-up-green" sub={`יחס 1:${((sel.tp1 - sel.entry) / (sel.entry - sel.sl) || 1).toFixed(1)}`} />
              <Stat label="TP2" value={`$${sel.tp2.toFixed(2)}`} color="text-accent-cyan" />
            </div>
          )}
          {sel && (
            <div className="flex flex-wrap gap-2 mb-4">
              <Badge color="blue">גודל פוזיציה מומלץ: ${sel.positionSizeUSDT.toFixed(2)}</Badge>
              <Badge color="yellow">סיכון לטרייד: {sel.riskPct}% מהתיק</Badge>
              {sel.direction !== 'WAIT' && (
                <Button variant="success" onClick={() => executeOnPaper(sel)}>▶ בצע במסחר דמו</Button>
              )}
            </div>
          )}
          <div className="bg-bg-card2 rounded-lg p-3">
            <div className="text-sm font-bold mb-2 text-accent-cyan">📝 נימוקי האות:</div>
            <ul className="text-sm space-y-1 text-gray-300 list-disc pr-5">
              {(sel?.reasons || []).map((r, i) => <li key={i}>{r}</li>)}
            </ul>
          </div>
        </Card>
        {sel && (
          <Card>
            <h3 className="font-bold mb-3">📈 אינדיקטורים טכניים - {sel.symbol}</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
              <Stat label="RSI (14)" value={sel.indicators.rsi.toFixed(1)} color={sel.indicators.rsi > 70 ? 'text-down-red' : sel.indicators.rsi < 30 ? 'text-up-green' : 'text-gray-200'} />
              <Stat label="MACD" value={sel.indicators.macd.macd.toFixed(2)} color={sel.indicators.macd.hist > 0 ? 'text-up-green' : 'text-down-red'} sub={`Hist: ${sel.indicators.macd.hist.toFixed(2)}`} />
              <Stat label="EMA 20" value={`$${sel.indicators.ema20.toFixed(2)}`} />
              <Stat label="EMA 50" value={`$${sel.indicators.ema50.toFixed(2)}`} />
              <Stat label="EMA 200" value={sel.indicators.ema200_exists ? `$${sel.indicators.ema200.toFixed(2)}` : '...'} color={sel.indicators.ema200_exists ? 'text-gray-200' : 'text-gray-500'} sub={sel.indicators.ema200_exists ? undefined : 'טוען...'} />
              <Stat label="ATR (14)" value={sel.indicators.atr.toFixed(2)} sub={`תנודתיות ${((sel.indicators.atr / sel.entry) * 100).toFixed(2)}%`} />
              <Stat label="ADX" value={sel.indicators.adx.toFixed(1)} color={sel.indicators.adx > 25 ? 'text-up-green' : 'text-warn-yellow'} sub={sel.indicators.adx > 25 ? 'מגמה חזקה' : 'מגמה חלשה'} />
              <Stat label="נפח עכשווי" value={sel.indicators.currentVolume.toFixed(0)} color={sel.indicators.currentVolume > sel.indicators.volumeSma20 * 1.3 ? 'text-up-green' : 'text-gray-200'} sub={`ממוצע 20: ${sel.indicators.volumeSma20.toFixed(0)}`} />
            </div>
          </Card>
        )}
        <ConfluenceMatrix symbol={selected} />
      </div>
      <div className="space-y-4">
        <Card>
          <h3 className="font-bold mb-3">🎯 כל האיתותים במעקב</h3>
          <div className="space-y-2 max-h-[720px] overflow-y-auto pr-1">
            {signals.map(s => (
              <button key={s.symbol} onClick={() => setSelected(s.symbol)}
                className={`w-full text-right rounded-lg border p-3 transition ${selected === s.symbol ? 'bg-accent-blue/20 border-accent-blue' : 'bg-bg-card2 border-border-soft hover:border-accent-blue/50'}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold">{s.symbol.replace('USDT', '/USDT')}</span>
                  <Badge color={s.direction === 'LONG' ? 'green' : s.direction === 'SHORT' ? 'red' : 'gray'}>
                    {s.direction === 'LONG' ? 'לונג' : s.direction === 'SHORT' ? 'שורט' : 'המתנה'}
                  </Badge>
                </div>
                <div className="flex items-center justify-between text-xs text-gray-400">
                  <span>${prices[s.symbol]?.toFixed(2) || '--'}</span>
                  <span className={s.confidence >= 70 ? 'text-up-green' : s.confidence >= 50 ? 'text-warn-yellow' : 'text-gray-400'}>
                    ביטחון {s.confidence}%
                  </span>
                </div>
              </button>
            ))}
          </div>
        </Card>
        <Card>
          <h3 className="font-bold mb-2">💡 טיפ לניהול סיכון</h3>
          <p className="text-sm text-gray-300 leading-relaxed">
            המערכת משתמשת ב-<strong>קרייטריון קלי (Kelly Criterion)</strong> לחישוב גודל פוזיציה אופטימלי,
            בשילוב ATR למיקום מדויק של Stop-Loss. לעולם אל תסכן יותר מ-2% מהתיק בטרייד בודד.
          </p>
        </Card>
      </div>
    </div>
  );
}
