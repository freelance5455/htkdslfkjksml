import { useMemo } from 'react';

// Squarified treemap algorithm for true Finviz-style proportional tiles.
interface Node { id: string; name: string; value: number; change: number; price: number; }

interface Rect { x: number; y: number; w: number; h: number; }

function squarify(items: Node[], bounds: Rect): Array<{ item: Node; rect: Rect }> {
  const result: Array<{ item: Node; rect: Rect }> = [];
  const total = items.reduce((s, i) => s + i.value, 0) || 1;
  let x = bounds.x, y = bounds.y, w = bounds.w, h = bounds.h;
  const list = [...items].sort((a, b) => b.value - a.value);
  const rec = (arr: Node[], rx: number, ry: number, rw: number, rh: number) => {
    if (arr.length === 0) return;
    if (arr.length === 1) {
      result.push({ item: arr[0], rect: { x: rx, y: ry, w: rw, h: rh } });
      return;
    }
    const sum = arr.reduce((s, i) => s + i.value, 0);
    const isHorizontal = rw >= rh;
    const splitLen = isHorizontal ? rw : rh;
    const splitVal = arr[0].value / sum * splitLen;
    const first = [arr[0]];
    let rest = arr.slice(1);
    let used = arr[0].value / sum * splitLen;
    // Build a row/column with best aspect ratio
    while (rest.length > 0) {
      const n = rest[0];
      const newUsed = used + n.value / sum * splitLen;
      // Simplified: just take one more if it improves worst ratio, else stop
      if (newUsed < splitLen * 0.7 && rest.length > 1) {
        first.push(n); rest = rest.slice(1); used = newUsed;
      } else break;
    }
    // Place first group
    const groupSum = first.reduce((s, i) => s + i.value, 0);
    const primaryLen = groupSum / sum * splitLen;
    if (isHorizontal) {
      // column
      let cy = ry;
      for (const item of first) {
        const ih = (item.value / groupSum) * rh;
        result.push({ item, rect: { x: rx, y: cy, w: primaryLen, h: ih } });
        cy += ih;
      }
      rec(rest, rx + primaryLen, ry, rw - primaryLen, rh);
    } else {
      let cx = rx;
      for (const item of first) {
        const iw = (item.value / groupSum) * rw;
        result.push({ item, rect: { x: cx, y: ry, w: iw, h: primaryLen } });
        cx += iw;
      }
      rec(rest, rx, ry + primaryLen, rw, rh - primaryLen);
    }
  };
  rec(list, x, y, w, h);
  return result;
}

function colorFor(pct: number): string {
  const c = Math.max(-5, Math.min(5, pct));
  const r = c > 0 ? 16 + (1 - c / 5) * 60 : 80 + (1 + c / 5) * 175;
  const g = c > 0 ? 80 + (c / 5) * 175 : 40 + (1 + c / 5) * 60;
  const b = 80;
  return `rgb(${Math.round(r)},${Math.round(g)},${Math.round(b)})`;
}

export function SquarifiedTreemap({ data, width = 1200, height = 600 }: { data: Node[]; width?: number; height?: number }) {
  const layout = useMemo(() => {
    return squarify(data.filter(d => d.value > 0), { x: 0, y: 0, w: width, h: height });
  }, [data, width, height]);

  return (
    <div className="relative rounded-lg overflow-hidden" style={{ width, height }}>
      {layout.map(({ item, rect }) => {
        const bg = colorFor(item.change);
        const fontSize = Math.min(28, Math.max(10, Math.sqrt(rect.w * rect.h) / 6));
        const showSym = rect.w > 40 && rect.h > 30;
        const showPct = rect.w > 60 && rect.h > 50;
        const showPrice = rect.w > 80 && rect.h > 70;
        return (
          <div key={item.id}
            className="absolute p-2 flex flex-col justify-between transition hover:brightness-125 cursor-pointer overflow-hidden border border-black/20"
            style={{ left: rect.x, top: rect.y, width: rect.w, height: rect.h, backgroundColor: bg }}
            title={`${item.name} $${item.price} (${item.change >= 0 ? '+' : ''}${item.change.toFixed(2)}%)`}>
            {showSym && <div className="font-bold text-white drop-shadow" style={{ fontSize }}>{item.name}</div>}
            {showPrice && <div className="text-white/90 font-semibold" style={{ fontSize: fontSize * 0.65 }}>
              ${item.price < 1 ? item.price.toFixed(4) : item.price.toFixed(2)}
            </div>}
            {showPct && <div className="font-bold text-white" style={{ fontSize: fontSize * 0.7 }}>
              {item.change >= 0 ? '+' : ''}{item.change.toFixed(2)}%
            </div>}
          </div>
        );
      })}
    </div>
  );
}
