import { ConnectionStatus } from '../types';

const MAP: Record<ConnectionStatus, { emoji: string; text: string; cls: string }> = {
  connected: { emoji: '🟢', text: 'מחובר לבורסה', cls: 'bg-up-green/20 text-up-green border-up-green/40' },
  slow: { emoji: '🟡', text: 'תקשורת איטית', cls: 'bg-warn-yellow/20 text-warn-yellow border-warn-yellow/40' },
  reconnecting: { emoji: '🔴', text: 'אין תקשורת - מנסה להתחבר...', cls: 'bg-down-red/20 text-down-red border-down-red/40' },
  backup: { emoji: '🟠', text: 'מחובר לשרת גיבוי / נתוני הדגמה', cls: 'bg-orange-500/20 text-orange-400 border-orange-500/40' },
};

export function HealthBadge({ status, ping }: { status: ConnectionStatus; ping: number }) {
  const m = MAP[status] ?? MAP.reconnecting;
  return (
    <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full border text-xs font-semibold ${m.cls}`}>
      <span>{m.emoji}</span>
      <span>{m.text}</span>
      {ping > 0 && <span className="opacity-70">({ping}ms)</span>}
    </div>
  );
}
