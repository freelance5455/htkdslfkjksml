import { useEffect, useState } from 'react';
import { subscribeDepth, onDepth, initOrderbookWS, OrderBookSnapshot } from '../services/orderbookService';

// Live WebSocket-backed order book, falls back to synthetic via prop if no WS data.
import { OrderBook as SyntheticOrderBook } from './OrderBook';

export function LiveOrderBook({ symbol, livePrice }: { symbol: string; livePrice?: number }) {
  const [snap, setSnap] = useState<OrderBookSnapshot | null>(null);

  useEffect(() => {
    initOrderbookWS();
    subscribeDepth(symbol);
    const unsub = onDepth(s => { if (s.symbol === symbol) setSnap(s); });
    return () => { unsub(); };
  }, [symbol]);

  if (!snap || snap.bids.length === 0) {
    return <SyntheticOrderBook symbol={symbol} livePrice={livePrice} />;
  }

  const asks = [...snap.asks].sort((a, b) => a.price - b.price).slice(0, 12);
  const bids = [...snap.bids].sort((a, b) => b.price - a.price).slice(0, 12);
  const maxBid = bids.reduce((m, b) => Math.max(m, b.size), 0);
  const maxAsk = asks.reduce((m, a) => Math.max(m, a.size), 0);
  const max = Math.max(maxBid, maxAsk) || 1;
  const bestAsk = asks[asks.length - 1]?.price ?? 0;
  const bestBid = bids[0]?.price ?? 0;
  const spread = bestAsk - bestBid;
  const mid = (bestAsk + bestBid) / 2;
  const spreadPct = mid > 0 ? (spread / mid) * 100 : 0;

  return (
    <div className="bg-bg-card border border-border-soft rounded-lg p-3 text-xs font-mono">
      <div className="flex justify-between items-center mb-2 font-sans">
        <div className="font-bold text-sm">📖 עומק שוק (Live)</div>
        <div className="text-gray-400">ספרד: ${spread.toFixed(2)} ({spreadPct.toFixed(3)}%)</div>
      </div>
      <div className="grid grid-cols-3 text-gray-500 px-1 py-1 font-sans">
        <span className="text-right">מחיר</span>
        <span className="text-center">כמות</span>
        <span className="text-left">סך</span>
      </div>
      {asks.slice().reverse().map((a, i) => (
        <div key={'a' + i} className="relative grid grid-cols-3 py-0.5 px-1">
          <div className="absolute inset-y-0 left-0 bg-down-red/20" style={{ width: `${(a.size / max) * 100}%` }} />
          <span className="relative text-down-red text-right">{a.price.toFixed(2)}</span>
          <span className="relative text-center text-gray-300">{a.size.toFixed(3)}</span>
          <span className="relative text-left text-gray-400">{(a.price * a.size).toFixed(0)}</span>
        </div>
      ))}
      <div className="py-1 my-1 bg-bg-card2 rounded text-center font-bold text-base font-sans"
        style={{ color: livePrice ? (livePrice >= (snap.bids[0]?.price ?? 0) ? '#10b981' : '#ef4444') : '#06b6d4' }}>
        ${(livePrice || mid).toFixed(2)}
      </div>
      {bids.map((b, i) => (
        <div key={'b' + i} className="relative grid grid-cols-3 py-0.5 px-1">
          <div className="absolute inset-y-0 right-0 bg-up-green/20" style={{ width: `${(b.size / max) * 100}%` }} />
          <span className="relative text-up-green text-right">{b.price.toFixed(2)}</span>
          <span className="relative text-center text-gray-300">{b.size.toFixed(3)}</span>
          <span className="relative text-left text-gray-400">{(b.price * b.size).toFixed(0)}</span>
        </div>
      ))}
    </div>
  );
}
