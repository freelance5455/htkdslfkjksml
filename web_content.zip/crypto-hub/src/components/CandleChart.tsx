import { useEffect, useRef } from 'react';
import { createChart, IChartApi, ISeriesApi, CandlestickData, HistogramData, Time } from 'lightweight-charts';
import { Kline, TradeSignal } from '../types';

interface Props {
  klines: Kline[];
  signal?: TradeSignal | null;
  height?: number;
}

export function CandleChart({ klines, signal, height = 480 }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const candleRef = useRef<ISeriesApi<'Candlestick'> | null>(null);
  const volRef = useRef<ISeriesApi<'Histogram'> | null>(null);
  const priceLinesRef = useRef<any[]>([]);

  useEffect(() => {
    if (!containerRef.current) return;
    const chart = createChart(containerRef.current, {
      layout: { background: { color: '#121726' }, textColor: '#cbd5e1' },
      grid: { vertLines: { color: '#1f2937' }, horzLines: { color: '#1f2937' } },
      rightPriceScale: { borderColor: '#2a324a' },
      timeScale: { borderColor: '#2a324a', timeVisible: true, secondsVisible: false },
      width: containerRef.current.clientWidth,
      height,
    });
    const candles = chart.addCandlestickSeries({
      upColor: '#10b981', downColor: '#ef4444', wickUpColor: '#10b981', wickDownColor: '#ef4444', borderVisible: false,
    });
    const vol = chart.addHistogramSeries({
      color: '#3b82f6', priceFormat: { type: 'volume' }, priceScaleId: '',
    });
    vol.priceScale().applyOptions({ scaleMargins: { top: 0.85, bottom: 0 } });
    candleRef.current = candles;
    volRef.current = vol;
    chartRef.current = chart;

    const onResize = () => {
      if (containerRef.current && chartRef.current) chartRef.current.applyOptions({ width: containerRef.current.clientWidth });
    };
    window.addEventListener('resize', onResize);
    return () => { window.removeEventListener('resize', onResize); chart.remove(); };
  }, [height]);

  useEffect(() => {
    if (!candleRef.current || !volRef.current) return;
    // Clear old price lines
    priceLinesRef.current.forEach(pl => {
      try { candleRef.current?.removePriceLine(pl); } catch {}
    });
    priceLinesRef.current = [];
    const safe = Array.isArray(klines) ? klines : [];
    candleRef.current.setData(safe.map(k => ({ time: k.time as Time, open: k.open, high: k.high, low: k.low, close: k.close })));
    volRef.current.setData(safe.map(k => ({ time: k.time as Time, value: k.volume, color: k.close >= k.open ? 'rgba(16,185,129,0.5)' : 'rgba(239,68,68,0.5)' })));
    if (signal && signal.direction !== 'WAIT' && safe.length > 0) {
      candleRef.current.setMarkers([
        { time: safe[safe.length - 1].time as Time, position: 'belowBar' as const, color: signal.direction === 'LONG' ? '#10b981' : '#ef4444', shape: 'arrowUp' as const, text: `כניסה ${signal.direction === 'LONG' ? 'לונג' : 'שורט'}` },
      ]);
      const addLine = (price: number, color: string, title: string) => {
        const l = candleRef.current!.createPriceLine({ price, color, lineWidth: 1, lineStyle: 2, axisLabelVisible: true, title });
        priceLinesRef.current.push(l);
      };
      addLine(signal.entry, '#3b82f6', 'כניסה');
      addLine(signal.sl, '#ef4444', 'SL');
      addLine(signal.tp1, '#10b981', 'TP1');
      addLine(signal.tp2, '#06b6d4', 'TP2');
    } else {
      candleRef.current.setMarkers([]);
    }
    chartRef.current?.timeScale().fitContent();
  }, [klines, signal]);

  return <div ref={containerRef} className="rounded-lg overflow-hidden border border-border-soft" style={{ height }} />;
}
