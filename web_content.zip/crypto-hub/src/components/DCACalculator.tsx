import { useMemo, useState } from 'react';
import { Card, Stat } from './UI';

// Dollar-Cost Averaging simulator - builds hypothetical DCA strategy over N periods
// with historical-like volatility so the user can plan entries.

export function DCACalculator() {
  const [amount, setAmount] = useState(100);
  const [periods, setPeriods] = useState(8);
  const [entry, setEntry] = useState(67000);
  const [dipPct, setDipPct] = useState(15); // expected dip during accumulation
  const [targetPct, setTargetPct] = useState(30);

  const sim = useMemo(() => {
    const levels: Array<{ i: number; price: number; coins: number; totalCost: number; totalCoins: number; avg: number }> = [];
    const stepDown = dipPct / 100 / (periods - 1 || 1);
    let totalCost = 0, totalCoins = 0;
    for (let i = 0; i < periods; i++) {
      const factor = 1 - stepDown * i;
      const price = entry * factor;
      const coins = amount / price;
      totalCost += amount; totalCoins += coins;
      levels.push({
        i, price, coins, totalCost, totalCoins, avg: totalCost / totalCoins,
      });
    }
    const avg = totalCost / totalCoins;
    const targetPrice = avg * (1 + targetPct / 100);
    const targetValue = totalCoins * targetPrice;
    const profit = targetValue - totalCost;
    const breakEven = avg;
    return { levels, totalCost, totalCoins, avg, targetPrice, targetValue, profit, breakEven };
  }, [amount, periods, entry, dipPct, targetPct]);

  return (
    <Card>
      <h3 className="font-bold text-lg mb-3">💰 מתכנן DCA (Dollar Cost Average)</h3>
      <p className="text-xs text-gray-400 mb-3">תכנן כניסות מדורגות (DCA) לתוך פוזיציה עם רמות קנייה מחושבות מראש.</p>
      <div className="grid grid-cols-2 gap-3 text-xs">
        <label className="block">
          סכום לכל קנייה ($):
          <input type="number" value={amount} onChange={e => setAmount(Number(e.target.value))}
            className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-2" />
        </label>
        <label className="block">
          מספר פעימות:
          <input type="number" min={2} max={30} value={periods} onChange={e => setPeriods(Number(e.target.value))}
            className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-2" />
        </label>
        <label className="block">
          מחיר התחלתי:
          <input type="number" value={entry} onChange={e => setEntry(Number(e.target.value))}
            className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-2" />
        </label>
        <label className="block">
          עומק ירידה משוער: {dipPct}%
          <input type="range" min={3} max={50} value={dipPct} onChange={e => setDipPct(Number(e.target.value))}
            className="w-full accent-down-red mt-1" />
        </label>
        <label className="block col-span-2">
          יעד רווח: {targetPct}%
          <input type="range" min={5} max={200} value={targetPct} onChange={e => setTargetPct(Number(e.target.value))}
            className="w-full accent-up-green mt-1" />
        </label>
      </div>
      <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-2">
        <Stat label="סך השקעה" value={`$${sim.totalCost.toFixed(0)}`} />
        <Stat label="מחיר ממוצע" value={`$${sim.avg.toFixed(2)}`} />
        <Stat label="יעד מכירה" value={`$${sim.targetPrice.toFixed(2)}`} />
        <Stat label="רווח צפוי" value={`$${sim.profit.toFixed(0)}`} color="text-up-green" sub={`${targetPct}%`} />
      </div>
      <div className="mt-4 overflow-x-auto">
        <table className="w-full text-xs">
          <thead className="text-gray-400 border-b border-border-soft">
            <tr><th className="text-right py-1">#</th><th className="text-right">מחיר</th><th className="text-right">כמות</th><th className="text-right">סה"כ עלות</th><th className="text-right">ממוצע</th></tr>
          </thead>
          <tbody>
            {sim.levels.map(l => (
              <tr key={l.i} className="border-b border-border-soft/40">
                <td className="py-1">{l.i + 1}</td>
                <td className={l.price < entry ? 'text-down-red' : ''}>${l.price.toFixed(2)}</td>
                <td>{l.coins.toFixed(6)}</td>
                <td>${l.totalCost.toFixed(0)}</td>
                <td className="text-accent-cyan">${l.avg.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
