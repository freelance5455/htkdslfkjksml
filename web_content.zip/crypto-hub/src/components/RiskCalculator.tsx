import { useMemo, useState } from 'react';
import { Card, Button, Stat } from './UI';

export function RiskCalculator({ balance = 10000 }: { balance?: number }) {
  const [entry, setEntry] = useState(67000);
  const [sl, setSl] = useState(66000);
  const [tp, setTp] = useState(69000);
  const [riskPct, setRiskPct] = useState(1.5);
  const [leverage, setLeverage] = useState(5);

  const calc = useMemo(() => {
    if (!entry || !sl || entry === sl) return null;
    const isLong = entry > sl; // SL below entry = long
    const stopDist = Math.abs(entry - sl);
    const tpDist = Math.abs(tp - entry);
    const riskUSDT = balance * (riskPct / 100);
    const posSize = riskUSDT / stopDist; // coins
    const notional = posSize * entry;
    const levUsed = notional / balance;
    const maxLeverage = Math.floor(entry / stopDist);
    const rr = stopDist > 0 ? tpDist / stopDist : 0;
    const tpReward = posSize * tpDist;
    const liqDistance = entry / leverage * 0.9;
    const liq = isLong ? entry - liqDistance : entry + liqDistance;
    const marginRequired = notional / leverage;
    return { isLong, stopDist, tpDist, riskUSDT, posSize, notional, levUsed, maxLeverage, rr, tpReward, liq, marginRequired };
  }, [entry, sl, tp, riskPct, leverage, balance]);

  return (
    <Card>
      <h3 className="font-bold text-lg mb-3">🧮 מחשבון ניהול סיכון</h3>
      <div className="grid grid-cols-2 gap-3 text-xs">
        <label className="block">
          מחיר כניסה:
          <input type="number" value={entry} onChange={e => setEntry(Number(e.target.value))}
            className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-2" />
        </label>
        <label className="block">
          Stop-Loss:
          <input type="number" value={sl} onChange={e => setSl(Number(e.target.value))}
            className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-2" />
        </label>
        <label className="block">
          Take-Profit:
          <input type="number" value={tp} onChange={e => setTp(Number(e.target.value))}
            className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-2" />
        </label>
        <label className="block">
          סיכון % מהתיק:
          <input type="number" step="0.1" value={riskPct} onChange={e => setRiskPct(Number(e.target.value))}
            className="mt-1 w-full bg-bg-dark border border-border-soft rounded px-2 py-2" />
        </label>
        <label className="block col-span-2">
          מינוף: {leverage}x
          <input type="range" min={1} max={25} value={leverage} onChange={e => setLeverage(Number(e.target.value))} className="w-full accent-accent-blue mt-1" />
        </label>
      </div>
      {calc && (
        <div className="mt-4">
          <div className="text-sm mb-2 font-semibold">
            כיוון משוער: <span className={calc.isLong ? 'text-up-green' : 'text-down-red'}>{calc.isLong ? 'לונג LONG' : 'שורט SHORT'}</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            <Stat label="סיכון בדולר" value={`$${calc.riskUSDT.toFixed(2)}`} color="text-down-red" />
            <Stat label="גודל פוזיציה (coins)" value={calc.posSize.toFixed(4)} />
            <Stat label="Notional" value={`$${calc.notional.toFixed(0)}`} />
            <Stat label="R:R יחס" value={`1:${calc.rr.toFixed(2)}`} color={calc.rr >= 2 ? 'text-up-green' : 'text-warn-yellow'} />
            <Stat label="בטחונות נדרשים" value={`$${calc.marginRequired.toFixed(2)}`} />
            <Stat label="מחיר חיסול" value={`$${calc.liq.toFixed(2)}`} color="text-down-red" />
            <Stat label="מינוף בפועל" value={`${calc.levUsed.toFixed(2)}x`} sub={`מקסימלי מותר: ${calc.maxLeverage}x`} />
            <Stat label="רווח ב-TP" value={`$${calc.tpReward.toFixed(2)}`} color="text-up-green" />
            <Stat label="מרחק SL" value={`${((calc.stopDist / entry) * 100).toFixed(2)}%`} />
          </div>
          {leverage > calc.maxLeverage && (
            <div className="mt-3 bg-down-red/20 border border-down-red/40 text-down-red rounded p-2 text-xs">
              ⚠️ אזהרה: המינוף שנבחר ({leverage}x) גבוה מטווח הבטוח - ה-SL ייפגע לפני שימוש אמיתי במינוף. מומלץ להשתמש במינוף מקסימלי {calc.maxLeverage}x.
            </div>
          )}
        </div>
      )}
    </Card>
  );
}
