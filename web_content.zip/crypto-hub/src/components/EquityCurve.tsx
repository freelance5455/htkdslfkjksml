import { useEffect, useRef } from 'react';
import { createChart, IChartApi, ISeriesApi, Time } from 'lightweight-charts';
import { PaperOrder } from '../types';

export function EquityCurve({ orders, initialBalance, currentBalance }: {
  orders: PaperOrder[]; initialBalance: number; currentBalance: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<ISeriesApi<'Area'> | null>(null);

  useEffect(() => {
    if (!ref.current) return;
    const chart = createChart(ref.current, {
      layout: { background: { color: 'transparent' }, textColor: '#94a3b8' },
      grid: { vertLines: { color: 'transparent' }, horzLines: { color: '#1f2937' } },
      rightPriceScale: { borderColor: 'transparent' },
      timeScale: { borderColor: 'transparent', timeVisible: true },
      width: ref.current.clientWidth,
      height: 200,
      handleScroll: false,
      handleScale: false,
    });
    const series = chart.addAreaSeries({
      lineColor: '#06b6d4',
      topColor: 'rgba(6,182,212,0.35)',
      bottomColor: 'rgba(6,182,212,0.02)',
      lineWidth: 2,
    });
    chartRef.current = chart;
    seriesRef.current = series;
    const onResize = () => { if (ref.current) chart.applyOptions({ width: ref.current.clientWidth }); };
    window.addEventListener('resize', onResize);
    return () => { window.removeEventListener('resize', onResize); chart.remove(); };
  }, []);

  useEffect(() => {
    if (!seriesRef.current) return;
    // Build equity curve from closed trades
    const closed = orders.filter(o => o.status === 'CLOSED').sort((a, b) => (a.closedAt || 0) - (b.closedAt || 0));
    const data: { time: Time; value: number }[] = [];
    let running = initialBalance;
    data.push({ time: Math.floor(Date.now() / 1000) - (closed.length * 3600) as Time, value: initialBalance });
    closed.forEach((o) => {
      running += o.pnl ?? 0;
      data.push({ time: Math.floor((o.closedAt || Date.now()) / 1000) as Time, value: running });
    });
    // Current
    data.push({ time: Math.floor(Date.now() / 1000) as Time, value: currentBalance });
    seriesRef.current.setData(data);
    chartRef.current?.timeScale().fitContent();
  }, [orders, initialBalance, currentBalance]);

  return <div ref={ref} className="w-full" style={{ height: 200 }} />;
}
