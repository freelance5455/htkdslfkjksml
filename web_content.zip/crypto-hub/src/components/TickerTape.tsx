import { useEffect, useRef } from 'react';
import { MarketTicker } from '../types';

export function TickerTape({ tickers }: { tickers: MarketTicker[] }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!ref.current) return;
    // Double the content for seamless loop
  }, [tickers]);
  const top = tickers.slice(0, 30);
  const doubled = [...top, ...top];
  return (
    <div className="bg-bg-card border-b border-border-soft overflow-hidden py-2 relative">
      <div ref={ref} className="flex gap-6 ticker-track whitespace-nowrap" style={{ animation: 'tickerScroll 60s linear infinite' }}>
        {doubled.map((t, i) => (
          <div key={i} className="flex items-center gap-2 text-sm font-semibold shrink-0">
            <span className="text-gray-300">{t.symbol.replace('USDT', '')}</span>
            <span className="text-gray-100">${t.price < 1 ? t.price.toFixed(4) : t.price.toFixed(2)}</span>
            <span className={t.change24h >= 0 ? 'text-up-green' : 'text-down-red'}>
              {t.change24h >= 0 ? '▲' : '▼'} {Math.abs(t.change24h).toFixed(2)}%
            </span>
          </div>
        ))}
      </div>
      <style>{`
        @keyframes tickerScroll {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
      `}</style>
    </div>
  );
}
