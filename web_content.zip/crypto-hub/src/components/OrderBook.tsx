import { useEffect, useMemo, useState } from 'react';
import { fetchKlines } from '../services/marketService';
import { Kline } from '../types';

// Simulated Level-2 order book built from recent trades/klines (works with any source)
// In production: subscribe to orderbook WS (orderbook.200.BTCUSDT on Bybit).
export function OrderBook({ symbol, livePrice }: { symbol: string; livePrice?: number }) {
  const [klines, setKlines] = useState<Kline[]>([]);
  useEffect(() => {
    fetchKlines(symbol, '1', 60).then(setKlines);
  }, [symbol]);

  const book = useMemo(() => {
    const price = livePrice || klines[klines.length - 1]?.close || 0;
    if (!price) return { bids: [], asks: [], spread: 0 };
    const vol = klines.length ? klines.reduce((s, k) => s + k.volume, 0) / klines.length : price * 10;
    const tick = price * 0.0003;
    const asks: { p: number; v: number; cum: number }[] = [];
    const bids: { p: number; v: number; cum: number }[] = [];
    let cumA = 0, cumB = 0;
    for (let i = 1; i <= 12; i++) {
      const ap = price + tick * i;
      const bp = price - tick * i;
      // pseudo-random depth with falloff
      const av = vol * (0.6 + Math.abs(Math.sin(ap * 13)) * 1.3) * (1 / Math.sqrt(i));
      const bv = vol * (0.6 + Math.abs(Math.cos(bp * 11)) * 1.3) * (1 / Math.sqrt(i));
      cumA += av; cumB += bv;
      asks.push({ p: ap, v: av, cum: cumA });
      bids.push({ p: bp, v: bv, cum: cumB });
    }
    return { asks: asks.reverse(), bids, spread: tick * 2 };
  }, [klines, livePrice]);

  const maxCum = Math.max(
    book.asks[0]?.cum || 1,
    book.bids[book.bids.length - 1]?.cum || 1,
  );

  return (
    <div className="bg-bg-card border border-border-soft rounded-lg p-3 text-xs font-mono">
      <div className="flex justify-between items-center mb-2 font-sans">
        <div className="font-bold text-sm">📖 עומק שוק (Order Book)</div>
        <div className="text-gray-400">ספרד: ${book.spread.toFixed(2)}</div>
      </div>
      <div className="grid grid-cols-3 text-gray-500 px-1 py-1 font-sans">
        <span className="text-right">מחיר</span>
        <span className="text-center">כמות</span>
        <span className="text-left">סך הכל</span>
      </div>
      {book.asks.map((a, i) => (
        <div key={'a' + i} className="relative grid grid-cols-3 py-0.5 px-1">
          <div className="absolute inset-y-0 left-0 bg-down-red/15" style={{ width: `${(a.cum / maxCum) * 100}%` }} />
          <span className="relative text-down-red text-right">{a.p.toFixed(2)}</span>
          <span className="relative text-center text-gray-300">{a.v.toFixed(3)}</span>
          <span className="relative text-left text-gray-400">{a.cum.toFixed(2)}</span>
        </div>
      ))}
      <div className="py-1 my-1 bg-bg-card2 rounded text-center font-bold text-base font-sans"
        style={{ color: livePrice && klines[0] ? (livePrice >= klines[0].close ? '#10b981' : '#ef4444') : '#06b6d4' }}>
        ${(livePrice || 0).toFixed(2)}
      </div>
      {book.bids.map((b, i) => (
        <div key={'b' + i} className="relative grid grid-cols-3 py-0.5 px-1">
          <div className="absolute inset-y-0 right-0 bg-up-green/15" style={{ width: `${(b.cum / maxCum) * 100}%` }} />
          <span className="relative text-up-green text-right">{b.p.toFixed(2)}</span>
          <span className="relative text-center text-gray-300">{b.v.toFixed(3)}</span>
          <span className="relative text-left text-gray-400">{b.cum.toFixed(2)}</span>
        </div>
      ))}
    </div>
  );
}
