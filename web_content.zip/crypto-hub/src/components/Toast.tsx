import { useEffect, useState } from 'react';

interface ToastMsg { id: number; title: string; body: string; }

export function Toast() {
  const [toasts, setToasts] = useState<ToastMsg[]>([]);
  useEffect(() => {
    let idc = 0;
    const onMsg = (e: any) => {
      const id = ++idc;
      setToasts(ts => [...ts, { id, title: e.detail?.title || '', body: e.detail?.body || '' }]);
      setTimeout(() => setToasts(ts => ts.filter(t => t.id !== id)), 4500);
    };
    window.addEventListener('crypto-toast', onMsg);
    return () => window.removeEventListener('crypto-toast', onMsg);
  }, []);
  return (
    <div className="fixed top-4 left-4 z-50 flex flex-col gap-2 pointer-events-none">
      {toasts.map(t => (
        <div key={t.id} className="bg-bg-card2 border border-border-soft rounded-lg px-4 py-3 shadow-2xl pointer-events-auto min-w-[260px] animate-slidein">
          <div className="font-bold text-sm text-accent-cyan">{t.title}</div>
          <div className="text-sm text-gray-300 mt-1">{t.body}</div>
        </div>
      ))}
    </div>
  );
}
