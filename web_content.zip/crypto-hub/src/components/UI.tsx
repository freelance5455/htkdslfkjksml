import { ReactNode } from 'react';

export function Card({ children, className = '' }: { children: ReactNode; className?: string }) {
  return (
    <div className={`bg-bg-card border border-border-soft rounded-xl p-4 ${className}`}>{children}</div>
  );
}

export function Button({ children, onClick, variant = 'primary', className = '', disabled, type }: {
  children: ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'success' | 'danger' | 'ghost' | 'warn';
  className?: string;
  disabled?: boolean;
  type?: 'button' | 'submit';
}) {
  const variants = {
    primary: 'bg-accent-blue hover:bg-blue-600 text-white',
    success: 'bg-up-green hover:bg-green-600 text-white',
    danger: 'bg-down-red hover:bg-red-600 text-white',
    warn: 'bg-warn-yellow hover:bg-yellow-600 text-black',
    ghost: 'bg-bg-card2 hover:bg-bg-card2/70 text-gray-200 border border-border-soft',
  };
  return (
    <button type={type || 'button'} onClick={onClick} disabled={disabled}
      className={`px-4 py-2 rounded-lg font-semibold text-sm transition disabled:opacity-50 disabled:cursor-not-allowed ${variants[variant]} ${className}`}>
      {children}
    </button>
  );
}

export function Stat({ label, value, color, sub }: { label: string; value: string | number; color?: string; sub?: string }) {
  return (
    <div className="bg-bg-card2 rounded-lg p-3">
      <div className="text-xs text-gray-400 mb-1">{label}</div>
      <div className={`text-lg font-bold ${color || 'text-gray-100'}`}>{value}</div>
      {sub && <div className="text-[11px] text-gray-500 mt-1">{sub}</div>}
    </div>
  );
}

export function Badge({ children, color = 'gray' }: { children: ReactNode; color?: 'green' | 'red' | 'yellow' | 'blue' | 'gray' }) {
  const c = {
    green: 'bg-up-green/20 text-up-green',
    red: 'bg-down-red/20 text-down-red',
    yellow: 'bg-warn-yellow/20 text-warn-yellow',
    blue: 'bg-accent-blue/20 text-accent-blue',
    gray: 'bg-gray-700/40 text-gray-300',
  }[color];
  return <span className={`px-2 py-0.5 rounded text-xs font-semibold ${c}`}>{children}</span>;
}
