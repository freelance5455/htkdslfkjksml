import { useEffect, useState } from 'react';
import { wsClient, Trade } from '../services/websocketService';

const MAX = 40;

export function TradeTape({ symbol }: { symbol: string }) {
  const [trades, setTrades] = useState<Trade[]>([]);
  useEffect(() => {
    wsClient.watch([symbol]);
    const unsub = wsClient.subscribe({
      onTrade: (t) => {
        if (t.symbol !== symbol) return;
        setTrades(prev => [t, ...prev].slice(0, MAX));
      },
    });
    return () => { unsub(); };
  }, [symbol]);
  return (
    <div className="bg-bg-card border border-border-soft rounded-lg p-3 text-xs font-mono">
      <div className="font-bold text-sm mb-2 font-sans">⚡ זרימת עסקאות (Trade Tape)</div>
      <div className="grid grid-cols-3 text-gray-500 pb-1 font-sans">
        <span className="text-right">מחיר</span>
        <span className="text-center">כמות</span>
        <span className="text-left">זמן</span>
      </div>
      <div className="max-h-[380px] overflow-y-auto">
        {trades.length === 0 && <p className="text-gray-500 font-sans mt-2">ממתין לעסקאות חיות...</p>}
        {trades.map((t, i) => (
          <div key={i} className="grid grid-cols-3 py-0.5">
            <span className={t.side === 'buy' ? 'text-up-green text-right' : 'text-down-red text-right'}>
              {t.side === 'buy' ? '▲' : '▼'} {t.price.toFixed(2)}
            </span>
            <span className="text-center text-gray-300">{t.size.toFixed(4)}</span>
            <span className="text-left text-gray-500">{new Date(t.time).toLocaleTimeString('he-IL', { hour12: false })}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
