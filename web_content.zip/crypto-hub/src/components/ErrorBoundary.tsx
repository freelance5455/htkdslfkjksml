import { Component, ReactNode } from 'react';

interface Props { children: ReactNode }
interface State { hasError: boolean; error?: string }

export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false };
  static getDerivedStateFromError(err: Error): State { return { hasError: true, error: err.message }; }
  componentDidCatch(err: Error) { console.error('App error:', err); }
  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center p-6 text-center">
          <div className="bg-bg-card border border-border-soft rounded-xl p-8 max-w-md">
            <div className="text-5xl mb-4">⚠️</div>
            <h2 className="text-xl font-bold mb-2">שגיאה בטעינת האפליקציה</h2>
            <p className="text-gray-400 text-sm mb-4">{this.state.error || 'אירעה שגיאה לא צפויה'}</p>
            <button onClick={() => { this.setState({ hasError: false }); window.location.reload(); }}
              className="px-5 py-2 bg-accent-blue rounded-lg font-semibold hover:bg-blue-600 transition">
              טען מחדש
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
