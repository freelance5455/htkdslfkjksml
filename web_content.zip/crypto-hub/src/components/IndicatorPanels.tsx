import { useEffect, useRef } from 'react';
import { createChart, IChartApi, ISeriesApi, Time } from 'lightweight-charts';
import { Kline } from '../types';
import { rsi, macd as macdFn } from '../utils/indicators';

export function RsiPanel({ klines, height = 140 }: { klines: Kline[]; height?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<ISeriesApi<'Line'> | null>(null);

  useEffect(() => {
    if (!ref.current) return;
    const chart = createChart(ref.current, {
      layout: { background: { color: '#121726' }, textColor: '#94a3b8' },
      grid: { vertLines: { color: '#1f2937' }, horzLines: { color: '#1f2937' } },
      rightPriceScale: { borderColor: '#2a324a' },
      timeScale: { borderColor: '#2a324a', visible: false },
      width: ref.current.clientWidth,
      height,
      handleScroll: false,
      handleScale: false,
    });
    const line = chart.addLineSeries({ color: '#a855f7', lineWidth: 2 });
    chartRef.current = chart;
    seriesRef.current = line;
    const r = () => { if (ref.current) chart.applyOptions({ width: ref.current.clientWidth }); };
    window.addEventListener('resize', r);
    return () => { window.removeEventListener('resize', r); chart.remove(); };
  }, [height]);

  useEffect(() => {
    if (!seriesRef.current) return;
    const closes = klines.map(k => k.close);
    const r = rsi(closes, 14);
    const data = klines.map((k, i) => ({ time: k.time as Time, value: r[i] })).filter(p => !isNaN(p.value));
    seriesRef.current.setData(data);
    seriesRef.current.createPriceLine({ price: 70, color: '#ef4444', lineWidth: 1, lineStyle: 2, axisLabelVisible: true, title: 'יתר' });
    seriesRef.current.createPriceLine({ price: 30, color: '#10b981', lineWidth: 1, lineStyle: 2, axisLabelVisible: true, title: 'חוסר' });
    chartRef.current?.timeScale().fitContent();
  }, [klines]);

  return (
    <div>
      <div className="text-xs font-bold text-purple-400 px-2 pt-2">RSI (14)</div>
      <div ref={ref} style={{ height }} />
    </div>
  );
}

export function MacdPanel({ klines, height = 140 }: { klines: Kline[]; height?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const histRef = useRef<ISeriesApi<'Histogram'> | null>(null);
  const macdLineRef = useRef<ISeriesApi<'Line'> | null>(null);
  const sigRef = useRef<ISeriesApi<'Line'> | null>(null);

  useEffect(() => {
    if (!ref.current) return;
    const chart = createChart(ref.current, {
      layout: { background: { color: '#121726' }, textColor: '#94a3b8' },
      grid: { vertLines: { color: '#1f2937' }, horzLines: { color: '#1f2937' } },
      rightPriceScale: { borderColor: '#2a324a' },
      timeScale: { borderColor: '#2a324a', visible: false },
      width: ref.current.clientWidth,
      height,
      handleScroll: false,
      handleScale: false,
    });
    const hist = chart.addHistogramSeries({ priceFormat: { type: 'price', precision: 4 }, priceScaleId: '' });
    hist.priceScale().applyOptions({ scaleMargins: { top: 0.2, bottom: 0.2 } });
    const ml = chart.addLineSeries({ color: '#3b82f6', lineWidth: 2 });
    const sl = chart.addLineSeries({ color: '#f59e0b', lineWidth: 2 });
    chartRef.current = chart;
    histRef.current = hist; macdLineRef.current = ml; sigRef.current = sl;
    const r = () => { if (ref.current) chart.applyOptions({ width: ref.current.clientWidth }); };
    window.addEventListener('resize', r);
    return () => { window.removeEventListener('resize', r); chart.remove(); };
  }, [height]);

  useEffect(() => {
    if (!histRef.current || !macdLineRef.current || !sigRef.current) return;
    const closes = klines.map(k => k.close);
    const m = macdFn(closes);
    histRef.current.setData(klines.map((k, i) => ({ time: k.time as Time, value: m.hist[i], color: m.hist[i] >= 0 ? 'rgba(16,185,129,0.6)' : 'rgba(239,68,68,0.6)' })));
    macdLineRef.current.setData(klines.map((k, i) => ({ time: k.time as Time, value: m.macdLine[i] })));
    sigRef.current.setData(klines.map((k, i) => ({ time: k.time as Time, value: m.sigLine[i] })));
    chartRef.current?.timeScale().fitContent();
  }, [klines]);

  return (
    <div>
      <div className="text-xs font-bold text-blue-400 px-2 pt-2">MACD (12,26,9)</div>
      <div ref={ref} style={{ height }} />
    </div>
  );
}
