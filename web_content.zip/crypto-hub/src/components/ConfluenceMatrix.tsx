import { useEffect, useState } from 'react';
import { Card, Badge } from './UI';
import { fetchKlines } from '../services/marketService';
import { Kline } from '../types';
import { computeIndicators } from '../utils/indicators';

// Multi-timeframe confluence matrix: analyzes 1h / 4h / 1D alongside the active interval
// and shows alignment across timeframes (a classic "professional trading terminal" feature).

const TIMEFRAMES = [
  { v: '15', label: '15ד' },
  { v: '60', label: '1ש' },
  { v: '240', label: '4ש' },
  { v: 'D', label: 'יומי' },
  { v: 'W', label: 'שבועי' },
];

type TFBias = { tf: string; label: string; rsi: number; emaBias: 'bull' | 'bear' | 'neutral'; macdBias: 'bull' | 'bear' | 'neutral'; volumeBias: 'bull' | 'bear' | 'neutral'; overall: 'LONG' | 'SHORT' | 'WAIT'; strength: number };

function mapInterval(v: string): string {
  // Bybit V5 uses 1/3/5/15/30/60/120/240/360/720/D/W/M; Binance uses 1m/5m/...
  return v;
}

function analyze(k: Kline[]): Omit<TFBias, 'tf' | 'label'> | null {
  const ind = computeIndicators(k);
  if (!ind) return null;
  const price = k[k.length - 1].close;
  const emaBias: 'bull' | 'bear' | 'neutral' = price > ind.ema20 && ind.ema20 > ind.ema50 ? 'bull' : price < ind.ema20 && ind.ema20 < ind.ema50 ? 'bear' : 'neutral';
  const macdBias: 'bull' | 'bear' | 'neutral' = ind.macd.hist > 0 && ind.macd.macd > ind.macd.signal ? 'bull' : ind.macd.hist < 0 && ind.macd.macd < ind.macd.signal ? 'bear' : 'neutral';
  const volumeBias: 'bull' | 'bear' | 'neutral' =
    ind.currentVolume > ind.volumeSma20 * 1.2
      ? (price > ind.ema20 ? 'bull' : 'bear')
      : 'neutral';
  const rsiBull = ind.rsi < 45 ? 1 : ind.rsi > 55 ? -1 : 0;
  let score = 0;
  if (emaBias === 'bull') score += 2; else if (emaBias === 'bear') score -= 2;
  if (macdBias === 'bull') score += 1; else if (macdBias === 'bear') score -= 1;
  if (volumeBias === 'bull') score += 1; else if (volumeBias === 'bear') score -= 1;
  if (rsiBull > 0) score += 1; else if (rsiBull < 0) score -= 1;
  const overall: 'LONG' | 'SHORT' | 'WAIT' = score >= 3 ? 'LONG' : score <= -3 ? 'SHORT' : 'WAIT';
  const strength = Math.min(100, Math.abs(score) * 20);
  return { rsi: ind.rsi, emaBias, macdBias, volumeBias, overall, strength };
}

export function ConfluenceMatrix({ symbol }: { symbol: string }) {
  const [rows, setRows] = useState<TFBias[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    Promise.all(TIMEFRAMES.map(async tf => {
      try {
        const limit = tf.v === 'W' ? 100 : 200;
        const k = await fetchKlines(symbol, mapInterval(tf.v), limit);
        const a = analyze(k);
        if (!a) return null;
        return { tf: tf.v, label: tf.label, ...a } as TFBias;
      } catch { return null; }
    })).then(rs => {
      if (!mounted) return;
      setRows((rs.filter(Boolean) as TFBias[]));
      setLoading(false);
    });
    return () => { mounted = false; };
  }, [symbol]);

  const alignedLong = rows.filter(r => r.overall === 'LONG').length;
  const alignedShort = rows.filter(r => r.overall === 'SHORT').length;
  const call: 'LONG' | 'SHORT' | 'WAIT' = alignedLong >= 3 ? 'LONG' : alignedShort >= 3 ? 'SHORT' : 'WAIT';
  const confluencePct = rows.length > 0 ? Math.max(alignedLong, alignedShort) / rows.length * 100 : 0;

  return (
    <Card>
      <h3 className="font-bold text-lg mb-3">🎯 מטריצת קונפלואינציה רב-מסגרתית</h3>
      {loading ? (
        <p className="text-gray-400 text-sm">טוען ניתוח רב-מסגרתי...</p>
      ) : (
        <>
          <div className="bg-bg-card2 rounded-lg p-3 mb-3 flex flex-wrap items-center gap-3">
            <div className="text-sm">הכרעה מסכמת:</div>
            <Badge color={call === 'LONG' ? 'green' : call === 'SHORT' ? 'red' : 'yellow'}>
              {call === 'LONG' ? 'לונג' : call === 'SHORT' ? 'שורט' : 'המתנה'}
            </Badge>
            <span className="text-sm">קונפלואינציה: <strong className={confluencePct >= 70 ? 'text-up-green' : confluencePct >= 50 ? 'text-warn-yellow' : 'text-gray-400'}>{confluencePct.toFixed(0)}%</strong></span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="text-gray-400 border-b border-border-soft">
                <tr><th className="text-right py-1">מסגרת</th><th className="text-center">RSI</th><th className="text-center">EMA</th><th className="text-center">MACD</th><th className="text-center">נפח</th><th className="text-center">הכרעה</th><th className="text-center">עוצמה</th></tr>
              </thead>
              <tbody>
                {rows.map(r => (
                  <tr key={r.tf} className="border-b border-border-soft/40">
                    <td className="py-2 font-bold">{r.label}</td>
                    <td className="text-center">
                      <span className={r.rsi > 70 ? 'text-down-red' : r.rsi < 30 ? 'text-up-green' : 'text-gray-300'}>{r.rsi.toFixed(1)}</span>
                    </td>
                    <td className="text-center">
                      <Badge color={r.emaBias === 'bull' ? 'green' : r.emaBias === 'bear' ? 'red' : 'gray'}>
                        {r.emaBias === 'bull' ? 'שורי' : r.emaBias === 'bear' ? 'דובי' : 'ניטרלי'}
                      </Badge>
                    </td>
                    <td className="text-center">
                      <Badge color={r.macdBias === 'bull' ? 'green' : r.macdBias === 'bear' ? 'red' : 'gray'}>
                        {r.macdBias === 'bull' ? 'שורי' : r.macdBias === 'bear' ? 'דובי' : 'ניטרלי'}
                      </Badge>
                    </td>
                    <td className="text-center">
                      <Badge color={r.volumeBias === 'bull' ? 'green' : r.volumeBias === 'bear' ? 'red' : 'gray'}>
                        {r.volumeBias === 'bull' ? 'אישור לונג' : r.volumeBias === 'bear' ? 'אישור שורט' : '—'}
                      </Badge>
                    </td>
                    <td className="text-center">
                      <Badge color={r.overall === 'LONG' ? 'green' : r.overall === 'SHORT' ? 'red' : 'gray'}>
                        {r.overall === 'LONG' ? 'לונג' : r.overall === 'SHORT' ? 'שורט' : 'המתנה'}
                      </Badge>
                    </td>
                    <td className="text-center">
                      <div className="inline-flex items-center gap-1">
                        <div className="w-16 bg-bg-dark rounded-full h-2 overflow-hidden">
                          <div className={r.overall === 'LONG' ? 'bg-up-green h-full' : r.overall === 'SHORT' ? 'bg-down-red h-full' : 'bg-gray-500 h-full'} style={{ width: `${r.strength}%` }} />
                        </div>
                        <span className="text-gray-400">{r.strength}%</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </Card>
  );
}
