import { useEffect, useState } from 'react';
import { Card, Badge } from './UI';
import { AuditLog } from '../types';
import { loadState } from '../store/useStore';

export function AuditLogView() {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [stats, setStats] = useState({ total: 0, won: 0, wr: 0, conf: 3 });

  useEffect(() => {
    const refresh = () => {
      const s = loadState();
      setLogs(s.auditLogs || []);
      setStats({
        total: s.totalSignalsEvaluated,
        won: s.signalsWon,
        wr: s.totalSignalsEvaluated ? s.signalsWon / s.totalSignalsEvaluated : 0,
        conf: s.signalConfig.minConfluence,
      });
    };
    refresh();
    const id = setInterval(refresh, 5000);
    return () => clearInterval(id);
  }, []);

  const typeMap: Record<string, { color: 'green' | 'red' | 'yellow' | 'blue'; icon: string }> = {
    success: { color: 'green', icon: '✅' },
    failure: { color: 'red', icon: '❌' },
    warning: { color: 'yellow', icon: '⚠️' },
    tweak: { color: 'blue', icon: '🔧' },
  };

  return (
    <Card>
      <div className="flex flex-wrap items-center gap-3 mb-4">
        <h3 className="font-bold text-lg flex-1">🧠 יומן אבחונים וסריקה עצמית (Evaluator Agent)</h3>
        <Badge color="blue">קונפלואינציה: {stats.conf}/5</Badge>
        <Badge color={stats.wr >= 0.75 ? 'green' : 'red'}>
          דיוק: {stats.total ? (stats.wr * 100).toFixed(0) : '--'}% ({stats.won}/{stats.total})
        </Badge>
      </div>
      <p className="text-xs text-gray-400 mb-3">
        המערכת מבצעת בדיקה אוטומטית כל 5 דקות, מנתחת כישלונות, ומכיילת מחמירות תנאי כניסה כאשר שיעור ההצלחה יורד מתחת ל-75%.
      </p>
      <div className="space-y-2 max-h-[400px] overflow-y-auto">
        {logs.length === 0 && <p className="text-gray-400 text-sm">אין רשומות ביומן.</p>}
        {logs.map(l => {
          const t = typeMap[l.type] || typeMap.warning;
          return (
            <div key={l.id} className="bg-bg-card2 rounded p-3 flex gap-3">
              <div className="text-xl">{t.icon}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge color={t.color}>{l.symbol || 'SYSTEM'}</Badge>
                  <span className="text-xs text-gray-500">{new Date(l.timestamp).toLocaleString('he-IL')}</span>
                </div>
                <div className="text-sm mt-1">{l.message}</div>
                {l.details && <div className="text-xs text-gray-400 mt-1">{l.details}</div>}
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}
