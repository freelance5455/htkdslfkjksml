import { PaperOrder, MasterTrader, AuditLog, Invoice, TaxRecord } from '../types';
import { DEFAULT_SIGNAL_CONFIG, SignalConfig } from '../utils/signalEngine';

const STORAGE_KEY = 'crypto-hub-state-v1';

export interface AppState {
  paperBalance: number;
  initialBalance: number;
  orders: PaperOrder[];
  traders: MasterTrader[];
  auditLogs: AuditLog[];
  invoices: Invoice[];
  taxRecords: TaxRecord[];
  signalConfig: SignalConfig;
  lastWinRateCheck: number;
  totalSignalsEvaluated: number;
  signalsWon: number;
}

const seedTraders: MasterTrader[] = [
  { id: 'tr-001', name: 'מומנטום אלוף', avatar: '🦅', winRate7d: 78, roi7d: 14.2, roi30d: 42.5, maxDrawdown: 8.3, profitFactor: 2.4, riskScore: 6, trades: 212, description: 'אסטרטגיית מומנטום על פרקי זמן קצרים עם אישור נפח', strategy: 'EMA + MACD + Volume breakout' },
  { id: 'tr-002', name: 'נינג׳ה סווינג', avatar: '🥷', winRate7d: 71, roi7d: 9.8, roi30d: 28.4, maxDrawdown: 5.1, profitFactor: 2.1, riskScore: 4, trades: 138, description: 'מסחר סווינג על בסיס תבניות היפוך ותמיכות', strategy: 'RSI divergence + EMA200 bounce' },
  { id: 'tr-003', name: 'סקальпер קוונטי', avatar: '⚡', winRate7d: 83, roi7d: 18.6, roi30d: 51.2, maxDrawdown: 12.4, profitFactor: 1.8, riskScore: 9, trades: 980, description: 'סקיילפינג מהיר בתדירות גבוהה עם ניהול סיכון הדוק', strategy: 'Order flow + VWAP scalp' },
  { id: 'tr-004', name: 'שומר ערך', avatar: '🛡️', winRate7d: 68, roi7d: 6.1, roi30d: 17.9, maxDrawdown: 3.2, profitFactor: 2.9, riskScore: 2, trades: 54, description: 'שמרני - טרנדים ארוכים עם מינוף נמוך', strategy: 'EMAs cross + weekly trend' },
  { id: 'tr-005', name: 'קורע השווקים', avatar: '🔥', winRate7d: 74, roi7d: 22.3, roi30d: 64.1, maxDrawdown: 18.7, profitFactor: 2.0, riskScore: 10, trades: 420, description: 'אגרסיבי - תנועות חדות עם מינוף גבוה', strategy: 'Breakout + volatility squeeze' },
  { id: 'tr-ai-01', name: 'AI מודל אלפא v3', avatar: '🤖', winRate7d: 81, roi7d: 16.4, roi30d: 47.8, maxDrawdown: 6.8, profitFactor: 2.7, riskScore: 5, trades: 1247, description: 'מודל ML מבוסס לאסמבל אינדיקטורים + סנטימנט', strategy: 'Random Forest + Transformer confluence' },
];

const defaultState: AppState = {
  paperBalance: 10000,
  initialBalance: 10000,
  orders: [],
  traders: seedTraders,
  auditLogs: [
    { id: 'a0', timestamp: Date.now(), type: 'success', message: 'מערכת הסריקה אותחלה - ניטור אותות פעיל' },
  ],
  invoices: [],
  taxRecords: [],
  signalConfig: DEFAULT_SIGNAL_CONFIG,
  lastWinRateCheck: Date.now(),
  totalSignalsEvaluated: 0,
  signalsWon: 0,
};

export function loadState(): AppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultState;
    const parsed = JSON.parse(raw);
    return { ...defaultState, ...parsed, traders: parsed.traders?.length ? parsed.traders : seedTraders };
  } catch { return defaultState; }
}

export function saveState(state: AppState) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch {}
}

export function resetPaperBalance(): AppState {
  const s = loadState();
  s.paperBalance = s.initialBalance;
  // Close all open orders
  s.orders = s.orders.map(o => o.status === 'OPEN' ? { ...o, status: 'CLOSED', closedAt: Date.now(), closePrice: o.entryPrice, pnl: 0, pnlPct: 0, note: 'איפוס חשבון' } : o);
  saveState(s);
  return s;
}

export function uid() { return Math.random().toString(36).slice(2, 10); }
