import { useEffect, useRef, useState, useCallback } from 'react';
import { ErrorBoundary } from './components/ErrorBoundary';
import { HealthBadge } from './components/HealthBadge';
import { Toast } from './components/Toast';
import { useConnectionHealth } from './hooks/useConnectionHealth';
import { fetchKlines, fetchTickers, getActiveSource } from './services/marketService';
import { notificationsService } from './services/notificationsService';
import { wsClient } from './services/websocketService';
import { MarketTicker, TradeSignal, Kline, ConnectionStatus } from './types';
import { generateSignal } from './utils/signalEngine';
import { loadState } from './store/useStore';
import { monitorOrders } from './services/paperTrading';
import { maybeCopyTrade } from './services/copyTrading';
import { runEvaluatorCycle } from './services/evaluatorAgent';

import { SignalsTab } from './tabs/SignalsTab';
import { CopyTradingTab } from './tabs/CopyTradingTab';
import { PaperTradingTab } from './tabs/PaperTradingTab';
import { ChartsTab } from './tabs/ChartsTab';
import { HeatmapTab } from './tabs/HeatmapTab';
import { ResearchTab } from './tabs/ResearchTab';
import { FinanceTab } from './tabs/FinanceTab';
import { DashboardTab } from './tabs/DashboardTab';
import { AuditLogView } from './components/AuditLog';
import { TickerTape } from './components/TickerTape';

function mapFromArr(arr: MarketTicker[]): Record<string, number> {
  const m: Record<string, number> = {};
  (Array.isArray(arr) ? arr : []).forEach(t => { m[t.symbol] = t.price; });
  return m;
}

const TABS = [
  { id: 'dashboard', label: 'לוח בקרה', icon: '🏠' },
  { id: 'signals', label: 'אותות ועצות מסחר', icon: '🎯' },
  { id: 'copy', label: 'חיקוי עסקאות סוחרים', icon: '🏆' },
  { id: 'paper', label: 'מסחר דמו / ניסיון', icon: '📊' },
  { id: 'charts', label: 'גרפים וספר פקודות', icon: '📈' },
  { id: 'heatmap', label: 'מפת שוק', icon: '🗺️' },
  { id: 'research', label: 'מחקר עומק', icon: '🔬' },
  { id: 'finance', label: 'פיננסים, מיסוי ודוחות', icon: '🧾' },
];

function AppInner() {
  const { status, ping } = useConnectionHealth();
  const [tab, setTab] = useState('dashboard');
  const [tickers, setTickers] = useState<MarketTicker[]>([]);
  const [scanning, setScanning] = useState(false);
  const [lastScan, setLastScan] = useState<Date | null>(null);
  const lastSignalRef = useRef<TradeSignal | null>(null);
  const pricesRef = useRef<Record<string, number>>({});

  const scan = useCallback(async () => {
    setScanning(true);
    try {
      const ts = await fetchTickers();
      setTickers(Array.isArray(ts) ? ts : []);
      const priceMap: Record<string, number> = {};
      (Array.isArray(ts) ? ts : []).forEach(t => priceMap[t.symbol] = t.price);
      pricesRef.current = priceMap;
      monitorOrders(priceMap);

      // Generate main signal for evaluator & copy trading
      const state = loadState();
      try {
        const btc = await fetchKlines('BTCUSDT', '15', 200);
        if (btc.length > 0) {
          const sig = generateSignal('BTCUSDT', btc, state.paperBalance);
          if (sig) {
            lastSignalRef.current = sig;
            if (sig.direction !== 'WAIT' && sig.confidence >= 80) {
              notificationsService.sendPush('🔔 אות בטוח גבוה', `${sig.symbol} - ${sig.direction} בביטחון ${sig.confidence}%`);
            }
            // Copy trading trigger for copied traders
            const traders = state.traders.filter(t => t.isCopied);
            traders.forEach(t => maybeCopyTrade(t, btc[btc.length - 1].close, sig.direction, sig.indicators.atr));
          }
          runEvaluatorCycle(sig, (s) => pricesRef.current[s] ?? null);
        }
      } catch (e) { console.warn('scan signal', e); }
      setLastScan(new Date());
      window.dispatchEvent(new CustomEvent('crypto-toast', { detail: { title: 'הסריקה הושלמה בהצלחה', body: `עודכן דרך ${getActiveSource()}` } }));
    } finally {
      setScanning(false);
    }
  }, []);

  useEffect(() => {
    notificationsService.requestPermission();
    scan();

    // Start WebSocket stream for live prices / trade tape
    try { wsClient.connect(); } catch {}
    wsClient.watch(['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT', 'DOGEUSDT', 'AVAXUSDT', 'LINKUSDT', 'MATICUSDT']);
    const unsubWS = wsClient.subscribe({
      onTicker: (t) => {
        if (!t?.symbol) return;
        pricesRef.current[t.symbol] = t.price;
        setTickers(prev => {
          const arr = Array.isArray(prev) ? prev : [];
          const idx = arr.findIndex(x => x.symbol === t.symbol);
          const existing = idx >= 0 ? arr[idx] : null;
          const updated: MarketTicker = existing
            ? { ...existing, price: t.price, change24h: t.change24h || existing.change24h, high24h: t.high || existing.high24h, low24h: t.low || existing.low24h, volume24h: t.volume || existing.volume24h }
            : { symbol: t.symbol, price: t.price, change24h: t.change24h, volume24h: t.volume, high24h: t.high, low24h: t.low };
          if (idx >= 0) { const c = arr.slice(); c[idx] = updated; return c; }
          return [...arr, updated];
        });
        monitorOrders({ ...pricesRef.current });
      },
      onStatus: (s: ConnectionStatus) => { /* health hook already checks REST; WS augments */ },
    });

    const scanId = setInterval(scan, 5 * 60 * 1000);
    const tickId = setInterval(async () => {
      const ts = await fetchTickers();
      if (Array.isArray(ts) && ts.length > 0) {
        setTickers(prev => {
          // Merge with WS prices (prefer WS)
          const map: Record<string, MarketTicker> = {};
          (Array.isArray(prev) ? prev : []).forEach(x => { map[x.symbol] = x; });
          ts.forEach(x => { map[x.symbol] = pricesRef.current[x.symbol] ? { ...x, price: pricesRef.current[x.symbol] } : x; });
          return Object.values(map);
        });
        const pm: Record<string, number> = {};
        Object.entries(mapFromArr(ts)).forEach(([k, v]) => pm[k] = pricesRef.current[k] ?? v);
        pricesRef.current = pm;
        monitorOrders(pm);
      }
    }, 15000);
    return () => { clearInterval(scanId); clearInterval(tickId); unsubWS(); };
  }, [scan]);

  return (
    <div className="min-h-screen bg-bg-dark pb-24 lg:pb-0">
      <Toast />
      <header className="sticky top-0 z-40 bg-bg-card/95 backdrop-blur border-b border-border-soft">
        <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 bg-gradient-to-br from-accent-blue to-accent-cyan rounded-lg flex items-center justify-center text-xl">💎</div>
            <div>
              <div className="font-bold text-base leading-tight">קריפטו האב</div>
              <div className="text-[10px] text-gray-400">Crypto Scanner • AI • Paper Trading</div>
            </div>
          </div>
          <div className="flex-1" />
          <HealthBadge status={status} ping={ping} />
          {tickers.length > 0 && (
            <div className="hidden md:flex items-center gap-3 text-xs font-bold">
              <span>BTC <span className={tickers.find(t=>t.symbol==='BTCUSDT')?.change24h! >= 0 ? 'text-up-green' : 'text-down-red'}>${tickers.find(t=>t.symbol==='BTCUSDT')?.price.toFixed(0)}</span></span>
              <span>ETH <span className={tickers.find(t=>t.symbol==='ETHUSDT')?.change24h! >= 0 ? 'text-up-green' : 'text-down-red'}>${tickers.find(t=>t.symbol==='ETHUSDT')?.price.toFixed(0)}</span></span>
            </div>
          )}
        </div>
        {/* Desktop tabs */}
        <nav className="max-w-7xl mx-auto px-2 hidden lg:flex gap-1 overflow-x-auto">
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`px-4 py-2 text-sm font-semibold whitespace-nowrap border-b-2 transition ${tab === t.id ? 'border-accent-cyan text-accent-cyan' : 'border-transparent text-gray-400 hover:text-gray-200'}`}>
              <span className="ml-1">{t.icon}</span>{t.label}
            </button>
          ))}
        </nav>
      </header>
      <TickerTape tickers={tickers} />

      <main className="max-w-7xl mx-auto px-4 py-4">
        {tab === 'dashboard' && <DashboardTab tickers={tickers} />}
        {tab === 'signals' && (
          <div className="space-y-4">
            <SignalsTab onScan={scan} scanning={scanning} lastScan={lastScan} />
            <AuditLogView />
          </div>
        )}
        {tab === 'copy' && <CopyTradingTab />}
        {tab === 'paper' && <PaperTradingTab tickers={tickers} />}
        {tab === 'charts' && <ChartsTab />}
        {tab === 'heatmap' && <HeatmapTab />}
        {tab === 'research' && <ResearchTab />}
        {tab === 'finance' && <FinanceTab />}
      </main>

      {/* Mobile bottom nav */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-bg-card border-t border-border-soft grid grid-cols-7 z-40">
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`py-2 text-[10px] flex flex-col items-center gap-0.5 ${tab === t.id ? 'text-accent-cyan' : 'text-gray-400'}`}>
            <span className="text-lg">{t.icon}</span>
            <span className="truncate w-full text-center px-0.5 leading-tight">{t.label.slice(0, 7)}</span>
          </button>
        ))}
      </nav>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AppInner />
    </ErrorBoundary>
  );
}
