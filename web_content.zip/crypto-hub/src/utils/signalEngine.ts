import { Kline, IndicatorSet, TradeSignal, Direction } from '../types';
import { computeIndicators } from './indicators';

export interface SignalConfig {
  minConfluence: number; // 3-5
  riskPct: number;
  atrMultiplierSL: number;
  atrMultiplierTP1: number;
  atrMultiplierTP2: number;
}

export const DEFAULT_SIGNAL_CONFIG: SignalConfig = {
  minConfluence: 3,
  riskPct: 1.5,
  atrMultiplierSL: 1.5,
  atrMultiplierTP1: 2.0,
  atrMultiplierTP2: 3.5,
};

const analyzeDirection = (price: number, ind: IndicatorSet): { direction: Direction; bullish: number; bearish: number; reasons: string[] } => {
  let bullish = 0, bearish = 0;
  const reasons: string[] = [];

  // RSI
  if (ind.rsi < 30) { bullish += 1; reasons.push('RSI במכירת יתר (<30) - פוטנציאל לונג'); }
  else if (ind.rsi > 70) { bearish += 1; reasons.push('RSI בקניית יתר (>70) - פוטנציאל שורט'); }
  else if (ind.rsi < 45) { bullish += 0.5; }
  else if (ind.rsi > 55) { bearish += 0.5; }

  // MACD
  if (ind.macd.hist > 0 && ind.macd.macd > ind.macd.signal) { bullish += 1; reasons.push('MACD חצה מעל הסיגנל במומנטום חיובי'); }
  else if (ind.macd.hist < 0 && ind.macd.macd < ind.macd.signal) { bearish += 1; reasons.push('MACD חצה מתחת לסיגנל במומנטום שלילי'); }
  if (ind.macd.hist > 0 && ind.macd.macd < 0 && ind.macd.signal < 0) {
    // cross up from below zero - strong
    bullish += 0.5;
  }

  // EMA alignment
  if (price > ind.ema20 && ind.ema20 > ind.ema50) { bullish += 1; reasons.push('מחיר מעל EMA20 ומעל EMA50 - מגמה עולה'); }
  else if (price < ind.ema20 && ind.ema20 < ind.ema50) { bearish += 1; reasons.push('מחיר מתחת EMA20 ומתחת EMA50 - מגמה יורדת'); }
  if (ind.ema200_exists) {
    if (price > ind.ema200) bullish += 0.5;
    else bearish += 0.5;
  }

  // Volume
  if (ind.currentVolume > ind.volumeSma20 * 1.3) {
    reasons.push('נפח מסחר גבוה ב-30%+ מהממוצע - אישור למהלך');
    if (price > ind.ema20) bullish += 0.5;
    else bearish += 0.5;
  }

  // ADX trend strength
  if (ind.adx > 25) {
    if (ind.ema20 > ind.ema50) bullish += 0.5;
    else bearish += 0.5;
    reasons.push(`ADX ${ind.adx.toFixed(0)} - מגמה חזקה`);
  } else {
    reasons.push(`ADX ${ind.adx.toFixed(0)} - מגמה חלשה/צדדית`);
  }

  const total = bullish + bearish;
  let direction: Direction = 'WAIT';
  if (bullish >= DEFAULT_SIGNAL_CONFIG.minConfluence && bullish > bearish) direction = 'LONG';
  else if (bearish >= DEFAULT_SIGNAL_CONFIG.minConfluence && bearish > bullish) direction = 'SHORT';
  else {
    reasons.push('קונפלואינציה נמוכה - מומלץ להמתין');
  }
  return { direction, bullish, bearish, reasons };
};

const recommendLeverage = (ind: IndicatorSet): number => {
  // Lower ATR % -> higher leverage is safer; cap at 10x
  const atrPct = ind.atr / (ind.ema20 || 1);
  if (atrPct < 0.005) return Math.min(10, 10);
  if (atrPct < 0.01) return 5;
  if (atrPct < 0.02) return 3;
  if (atrPct < 0.03) return 2;
  return 1;
};

export const generateSignal = (symbol: string, klines: Kline[], balance: number): TradeSignal | null => {
  const ind = computeIndicators(klines);
  if (!ind) return null;
  const price = klines[klines.length - 1].close;
  const { direction, bullish, bearish, reasons } = analyzeDirection(price, ind);
  const total = bullish + bearish;
  const confidence = total === 0 ? 0 : Math.round((direction === 'WAIT' ? Math.min(bullish, bearish) / total : Math.max(bullish, bearish) / total) * 100);

  let sl = price, tp1 = price, tp2 = price;
  if (direction === 'LONG') {
    sl = price - ind.atr * DEFAULT_SIGNAL_CONFIG.atrMultiplierSL;
    tp1 = price + ind.atr * DEFAULT_SIGNAL_CONFIG.atrMultiplierTP1;
    tp2 = price + ind.atr * DEFAULT_SIGNAL_CONFIG.atrMultiplierTP2;
  } else if (direction === 'SHORT') {
    sl = price + ind.atr * DEFAULT_SIGNAL_CONFIG.atrMultiplierSL;
    tp1 = price - ind.atr * DEFAULT_SIGNAL_CONFIG.atrMultiplierTP1;
    tp2 = price - ind.atr * DEFAULT_SIGNAL_CONFIG.atrMultiplierTP2;
  } else {
    sl = price - ind.atr * DEFAULT_SIGNAL_CONFIG.atrMultiplierSL;
    tp1 = price + ind.atr * DEFAULT_SIGNAL_CONFIG.atrMultiplierTP1;
    tp2 = price + ind.atr * DEFAULT_SIGNAL_CONFIG.atrMultiplierTP2;
  }

  const leverage = direction === 'WAIT' ? 1 : recommendLeverage(ind);
  const riskPct = DEFAULT_SIGNAL_CONFIG.riskPct;
  const riskUSDT = balance * (riskPct / 100);
  const stopDistance = Math.abs(price - sl) || price * 0.01;
  // Kelly: half-kelly sizing
  const winProb = Math.max(0.3, Math.min(0.85, (confidence / 100)));
  const rr = Math.abs(tp1 - price) / stopDistance;
  const kelly = rr > 0 ? (winProb * rr - (1 - winProb)) / rr : 0;
  const halfKelly = Math.max(0, kelly / 2);
  const positionSizeUSDT = direction === 'WAIT' ? 0 : Math.min(balance * Math.max(halfKelly, 0.01), balance * 0.2);

  return {
    symbol,
    direction,
    confidence,
    entry: price,
    sl,
    tp1,
    tp2,
    leverage,
    riskPct,
    positionSizeUSDT: Math.round(positionSizeUSDT * 100) / 100,
    reasons,
    timestamp: Date.now(),
    indicators: ind,
  };
};

export const generateSignalsForMultiple = async (
  symbols: string[],
  fetcher: (symbol: string) => Promise<Kline[]>,
  balance: number
): Promise<TradeSignal[]> => {
  const results = await Promise.allSettled(symbols.map(async (sym) => {
    const klines = await fetcher(sym);
    return generateSignal(sym, klines, balance);
  }));
  return results
    .filter(r => r.status === 'fulfilled' && r.value)
    .map(r => (r as PromiseFulfilledResult<TradeSignal>).value);
};
