import { Kline, IndicatorSet } from '../types';

export const sma = (values: number[], period: number): number[] => {
  const out: number[] = [];
  if (values.length < period) {
    values.forEach(() => out.push(NaN));
    return out;
  }
  for (let i = 0; i < values.length; i++) {
    if (i < period - 1) { out.push(NaN); continue; }
    let sum = 0;
    for (let j = i - period + 1; j <= i; j++) sum += values[j];
    out.push(sum / period);
  }
  return out;
};

export const ema = (values: number[], period: number): number[] => {
  const out: number[] = [];
  const k = 2 / (period + 1);
  values.forEach((v, i) => {
    if (i === 0) { out.push(v); return; }
    out.push(v * k + out[i - 1] * (1 - k));
  });
  return out;
};

export const rsi = (closes: number[], period = 14): number[] => {
  const out: number[] = new Array(closes.length).fill(NaN);
  if (closes.length <= period) return out;
  let gains = 0, losses = 0;
  for (let i = 1; i <= period; i++) {
    const d = closes[i] - closes[i - 1];
    if (d >= 0) gains += d; else losses -= d;
  }
  let avgG = gains / period;
  let avgL = losses / period;
  out[period] = avgL === 0 ? 100 : 100 - 100 / (1 + avgG / avgL);
  for (let i = period + 1; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    const g = d > 0 ? d : 0;
    const l = d < 0 ? -d : 0;
    avgG = (avgG * (period - 1) + g) / period;
    avgL = (avgL * (period - 1) + l) / period;
    out[i] = avgL === 0 ? 100 : 100 - 100 / (1 + avgG / avgL);
  }
  return out;
};

export const macd = (closes: number[], fast = 12, slow = 26, signal = 9) => {
  const ef = ema(closes, fast);
  const es = ema(closes, slow);
  const macdLine = closes.map((_, i) => ef[i] - es[i]);
  const sigLine = ema(macdLine, signal);
  const hist = macdLine.map((m, i) => m - sigLine[i]);
  return { macdLine, sigLine, hist };
};

export const atr = (klines: Kline[], period = 14): number[] => {
  const tr: number[] = [];
  klines.forEach((k, i) => {
    if (i === 0) { tr.push(k.high - k.low); return; }
    const prev = klines[i - 1].close;
    const a = k.high - k.low;
    const b = Math.abs(k.high - prev);
    const c = Math.abs(k.low - prev);
    tr.push(Math.max(a, b, c));
  });
  return ema(tr, period);
};

// Simplified ADX
export const adx = (klines: Kline[], period = 14): number[] => {
  const out: number[] = new Array(klines.length).fill(NaN);
  if (klines.length < period * 2) return out;
  const plusDM: number[] = [0];
  const minusDM: number[] = [0];
  const trArr: number[] = [klines[0].high - klines[0].low];
  for (let i = 1; i < klines.length; i++) {
    const k = klines[i];
    const p = klines[i - 1];
    const up = k.high - p.high;
    const dn = p.low - k.low;
    plusDM.push(up > dn && up > 0 ? up : 0);
    minusDM.push(dn > up && dn > 0 ? dn : 0);
    const tr = Math.max(k.high - k.low, Math.abs(k.high - p.close), Math.abs(k.low - p.close));
    trArr.push(tr);
  }
  let atrV = trArr.slice(0, period).reduce((a, b) => a + b, 0) / period;
  let pDI = plusDM.slice(0, period).reduce((a, b) => a + b, 0) / period / atrV * 100;
  let mDI = minusDM.slice(0, period).reduce((a, b) => a + b, 0) / period / atrV * 100;
  let dx = Math.abs(pDI - mDI) / (pDI + mDI) * 100;
  let adxVal = dx;
  out[period] = NaN;
  for (let i = period + 1; i < klines.length; i++) {
    atrV = (atrV * (period - 1) + trArr[i]) / period;
    pDI = ((plusDM.slice(0, i).reduce((a, b) => a + b, 0) / i) * (period - 1) + plusDM[i]) / period / atrV * 100;
    mDI = ((minusDM.slice(0, i).reduce((a, b) => a + b, 0) / i) * (period - 1) + minusDM[i]) / period / atrV * 100;
    const denom = (pDI + mDI);
    dx = denom === 0 ? 0 : Math.abs(pDI - mDI) / denom * 100;
    adxVal = (adxVal * (period - 1) + dx) / period;
    out[i] = adxVal;
  }
  return out;
};

export const computeIndicators = (klines: Kline[]): IndicatorSet | null => {
  if (!Array.isArray(klines) || klines.length < 50) return null;
  const closes = klines.map(k => k.close);
  const volumes = klines.map(k => k.volume);
  const rsiArr = rsi(closes, 14);
  const macdObj = macd(closes);
  const ema20Arr = ema(closes, 20);
  const ema50Arr = ema(closes, 50);
  const ema200Arr = ema(closes, 200);
  const atrArr = atr(klines, 14);
  const adxArr = adx(klines, 14);
  const volSma = sma(volumes, 20);
  const i = closes.length - 1;
  return {
    rsi: rsiArr[i] ?? 50,
    macd: { macd: macdObj.macdLine[i] ?? 0, signal: macdObj.sigLine[i] ?? 0, hist: macdObj.hist[i] ?? 0 },
    ema20: ema20Arr[i] ?? closes[i],
    ema50: ema50Arr[i] ?? closes[i],
    ema200: ema200Arr[i] ?? closes[i],
    ema200_exists: closes.length >= 200,
    atr: atrArr[i] ?? closes[i] * 0.01,
    adx: adxArr[i] ?? 25,
    volumeSma20: volSma[i] ?? volumes[i],
    currentVolume: volumes[i],
  };
};
