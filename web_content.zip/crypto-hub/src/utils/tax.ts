import { TaxRecord, Invoice } from '../types';
import { uid } from '../store/useStore';

// Israeli Tax Authority: 25% capital gains tax on crypto (unless classified as business income, which can go up to 50%).
// This helper exports ledger & computes estimated tax.

export interface TaxSummary {
  totalRealizedGainsILS: number;
  totalRealizedLossesILS: number;
  netTaxableILS: number;
  capitalGainsTax25: number;
  businessIncomeTax50: number;
  winningTrades: number;
  losingTrades: number;
}

const ILS_RATE = 3.75; // USD/ILS approximate; in prod fetch live

export function usdToILS(usd: number): number { return usd * ILS_RATE; }

export function computeTaxSummary(records: TaxRecord[]): TaxSummary {
  let gains = 0, losses = 0, win = 0, lose = 0;
  for (const r of records) {
    const g = r.gainILS ?? 0;
    if (g > 0) { gains += g; win++; }
    else if (g < 0) { losses += -g; lose++; }
  }
  const net = gains - losses;
  return {
    totalRealizedGainsILS: gains,
    totalRealizedLossesILS: losses,
    netTaxableILS: Math.max(0, net),
    capitalGainsTax25: Math.max(0, net) * 0.25,
    businessIncomeTax50: Math.max(0, net) * 0.50,
    winningTrades: win,
    losingTrades: lose,
  };
}

export function generateInvoice(amount: number, currency: 'USDT' | 'ILS', description: string): Invoice {
  return {
    id: uid(),
    amount,
    currency,
    status: 'pending',
    description,
    createdAt: Date.now(),
    walletAddress: 'T' + uid().toUpperCase().slice(0, 32),
  };
}

export function exportCSV(records: TaxRecord[]): string {
  const header = ['תאריך', 'סוג', 'מטבע', 'כמות', 'מחיר ב-ILS', 'רווח/הפסד ILS', 'הערות'];
  const rows = records.map(r => [
    new Date(r.date).toLocaleDateString('he-IL'),
    r.type === 'buy' ? 'קנייה' : r.type === 'sell' ? 'מכירה' : 'המרה',
    r.symbol,
    r.amount,
    r.priceILS.toFixed(2),
    (r.gainILS ?? 0).toFixed(2),
    r.notes,
  ]);
  return [header.join(','), ...rows.map(r => r.join(','))].join('\n');
}
