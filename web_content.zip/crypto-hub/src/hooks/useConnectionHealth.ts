import { useEffect, useRef, useState } from 'react';
import { checkHealth, getActiveSource } from '../services/marketService';
import { ConnectionStatus } from '../types';

export function useConnectionHealth() {
  const [status, setStatus] = useState<ConnectionStatus>('reconnecting');
  const [ping, setPing] = useState<number>(0);
  const failures = useRef(0);

  useEffect(() => {
    let mounted = true;
    const tick = async () => {
      const start = performance.now();
      const h = await checkHealth();
      const p = Math.round(performance.now() - start);
      if (!mounted) return;
      setPing(p);
      if (h === 'bybit') {
        setStatus(p > 2000 ? 'slow' : 'connected');
        failures.current = 0;
      } else if (h === 'binance') {
        setStatus('backup');
        failures.current = 0;
      } else {
        // synthetic data mode - still show as backup/demo
        setStatus('backup');
        failures.current = 0;
      }
    };
    tick();
    const id = setInterval(tick, 12000);
    return () => { mounted = false; clearInterval(id); };
  }, []);

  return { status, ping, activeSource: getActiveSource() };
}
