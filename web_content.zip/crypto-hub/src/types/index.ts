export interface Kline {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export type Direction = 'LONG' | 'SHORT' | 'WAIT';

export interface IndicatorSet {
  rsi: number;
  macd: { macd: number; signal: number; hist: number };
  ema20: number;
  ema50: number;
  ema200: number;
  ema200_exists: boolean;
  atr: number;
  adx: number;
  volumeSma20: number;
  currentVolume: number;
}

export interface TradeSignal {
  symbol: string;
  direction: Direction;
  confidence: number;
  entry: number;
  sl: number;
  tp1: number;
  tp2: number;
  leverage: number;
  riskPct: number;
  positionSizeUSDT: number;
  reasons: string[];
  timestamp: number;
  indicators: IndicatorSet;
}

export interface PaperOrder {
  id: string;
  symbol: string;
  direction: 'LONG' | 'SHORT';
  entryPrice: number;
  quantity: number;
  leverage: number;
  sl?: number;
  tp?: number;
  orderType?: 'market' | 'limit';
  limitPrice?: number;
  status: 'OPEN' | 'CLOSED' | 'PENDING' | 'CANCELLED';
  openedAt: number;
  closedAt?: number;
  closePrice?: number;
  pnl?: number;
  pnlPct?: number;
  isCopy?: boolean;
  copiedTraderId?: string;
  note?: string;
}

export interface MasterTrader {
  id: string;
  name: string;
  avatar: string;
  winRate7d: number;
  roi7d: number;
  roi30d: number;
  maxDrawdown: number;
  profitFactor: number;
  riskScore: number;
  trades: number;
  isCopied?: boolean;
  copyAllocation?: number;
  copyStopLoss?: number;
  copyMaxPositions?: number;
  copyLeverageCap?: number;
  description: string;
  strategy: string;
}

export interface MarketTicker {
  symbol: string;
  price: number;
  change24h: number;
  volume24h: number;
  marketCap?: number;
  high24h: number;
  low24h: number;
}

export type ConnectionStatus = 'connected' | 'slow' | 'reconnecting' | 'backup';

export interface AuditLog {
  id: string;
  timestamp: number;
  type: 'failure' | 'success' | 'warning' | 'tweak';
  message: string;
  details?: string;
  symbol?: string;
}

export interface Invoice {
  id: string;
  amount: number;
  currency: 'USDT' | 'ILS';
  status: 'paid' | 'pending';
  description: string;
  createdAt: number;
  walletAddress?: string;
}

export interface TaxRecord {
  id: string;
  date: number;
  type: 'buy' | 'sell' | 'trade';
  symbol: string;
  amount: number;
  priceILS: number;
  gainILS?: number;
  notes: string;
}
