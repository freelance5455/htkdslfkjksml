import { Kline, MarketTicker } from '../types';

// Unified market data layer: tries the local /api/market-proxy Vite dev endpoint first (works
// in production if the proxy-worker is deployed), then falls back to direct proxied paths
// (/api/bybit, /api/binance, /api/coingecko), then to public CORS proxies, and finally to
// a synthetic-klines safety net so the UI NEVER goes blank regardless of network/region.

const PUBLIC_CORS = [
  (url: string) => `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`,
];

type Source = 'bybit' | 'binance' | 'coingecko';

async function proxyFetch(source: Source, path: string, params: Record<string, string | number> = {}): Promise<any> {
  const sp = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => sp.append(k, String(v)));
  const qs = sp.toString();
  const tryUrls = [
    `/api/market-proxy?source=${source}&path=${encodeURIComponent(path)}${qs ? '&' + qs : ''}`,
    source === 'bybit' ? `/api/bybit${path}${qs ? '?' + qs : ''}` : null,
    source === 'binance' ? `/api/binance${path}${qs ? '?' + qs : ''}` : null,
    source === 'coingecko' ? `/api/coingecko${path}${qs ? '?' + qs : ''}` : null,
    ...PUBLIC_CORS.map(build => {
      const base = { bybit: 'https://api.bybit.com', binance: 'https://api.binance.com', coingecko: 'https://api.coingecko.com' }[source];
      return build(`${base}${path}${qs ? '?' + qs : ''}`);
    }),
  ].filter(Boolean) as string[];

  let lastErr: any = null;
  for (const url of tryUrls) {
    try {
      const ctrl = new AbortController();
      const to = setTimeout(() => ctrl.abort(), 7000);
      const r = await fetch(url, { signal: ctrl.signal, headers: { 'Accept': 'application/json' } });
      clearTimeout(to);
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const text = await r.text();
      if (!text || text.startsWith('<')) throw new Error('not json');
      return JSON.parse(text);
    } catch (e) { lastErr = e; }
  }
  throw lastErr ?? new Error(`all sources failed for ${source}${path}`);
}

let activeSource: 'bybit' | 'binance' | 'synthetic' = 'bybit';
export function getActiveSource() { return activeSource; }

// ---------- Synthetic safety net (used if every network source is blocked) ----------
function generateSyntheticKlines(symbol: string, limit = 200): Kline[] {
  const seed = symbol.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  const basePrice = [42000, 2300, 100, 0.5, 60, 0.15, 35, 15, 7, 140, 80, 8, 6, 25][seed % 14];
  const intervalMs = 15 * 60 * 1000;
  const now = Date.now();
  let price = basePrice;
  const out: Kline[] = [];
  for (let i = limit - 1; i >= 0; i--) {
    const t = Math.floor((now - i * intervalMs) / 1000);
    const noise = (Math.sin(seed + i * 0.3) + Math.cos(seed + i * 0.17) * 0.7) * (basePrice * 0.005);
    const drift = Math.sin(i * 0.02 + seed) * basePrice * 0.03;
    const open = price;
    const close = Math.max(0.00001, basePrice + drift + noise);
    const high = Math.max(open, close) + Math.abs(Math.sin(i + seed)) * basePrice * 0.003;
    const low = Math.min(open, close) - Math.abs(Math.cos(i + seed)) * basePrice * 0.003;
    const volume = basePrice * 1000 * (0.7 + Math.abs(Math.sin(i * 0.5 + seed)));
    out.push({ time: t, open, high, low, close, volume });
    price = close;
  }
  return out;
}

function syntheticTickers(): MarketTicker[] {
  const seeds: Array<[string, number]> = [
    ['BTCUSDT', 67000], ['ETHUSDT', 3500], ['BNBUSDT', 600], ['SOLUSDT', 160],
    ['XRPUSDT', 0.55], ['ADAUSDT', 0.45], ['DOGEUSDT', 0.15], ['AVAXUSDT', 35],
    ['DOTUSDT', 7], ['MATICUSDT', 0.7], ['LINKUSDT', 18], ['LTCUSDT', 80],
    ['UNIUSDT', 10], ['ATOMUSDT', 8], ['ETCUSDT', 25], ['NEARUSDT', 6],
    ['APTUSDT', 9], ['ARBUSDT', 1.2], ['OPUSDT', 2.3], ['FILUSDT', 6],
    ['AAVEUSDT', 140], ['SUIUSDT', 1.3], ['INJUSDT', 25], ['IMXUSDT', 1.6],
    ['TRXUSDT', 0.12], ['SHIBUSDT', 0.000025], ['PEPEUSDT', 0.000008], ['RNDRUSDT', 8],
  ];
  return seeds.map(([s, p]) => {
    const ch = Math.sin(s.length * 3.7 + Date.now() / 1e6) * 4;
    return {
      symbol: s, price: p, change24h: ch, volume24h: p * 1e7,
      high24h: p * 1.04, low24h: p * 0.96, marketCap: p * 1e9,
    };
  });
}

function normalizeBybitKlines(data: any): Kline[] {
  const list: any[] = Array.isArray(data?.result?.list) ? data.result.list : [];
  const asc = [...list].reverse();
  return asc.map(r => ({
    time: Math.floor(Number(r[0]) / 1000),
    open: Number(r[1]), high: Number(r[2]), low: Number(r[3]),
    close: Number(r[4]), volume: Number(r[5]),
  })).filter(k => !isNaN(k.close) && k.close > 0);
}
function normalizeBinanceKlines(data: any): Kline[] {
  const arr: any[] = Array.isArray(data) ? data : [];
  return arr.map(r => ({
    time: Math.floor(Number(r[0]) / 1000),
    open: Number(r[1]), high: Number(r[2]), low: Number(r[3]),
    close: Number(r[4]), volume: Number(r[5]),
  })).filter(k => !isNaN(k.close) && k.close > 0);
}
function normalizeGeckoMarket(data: any): MarketTicker[] {
  const arr: any[] = Array.isArray(data) ? data : [];
  return arr.map((c: any) => ({
    symbol: ((c.symbol || '') + 'USDT').toUpperCase(),
    price: c.current_price ?? 0,
    change24h: c.price_change_percentage_24h ?? 0,
    volume24h: c.total_volume ?? 0,
    marketCap: c.market_cap ?? 0,
    high24h: c.high_24h ?? c.current_price ?? 0,
    low24h: c.low_24h ?? c.current_price ?? 0,
  }));
}

export async function fetchKlinesBybit(symbol: string, interval = '15', limit = 200): Promise<Kline[]> {
  const d = await proxyFetch('bybit', '/v5/market/kline', { category: 'linear', symbol, interval, limit });
  return normalizeBybitKlines(d);
}
export async function fetchKlinesBinance(symbol: string, interval = '15m', limit = 200): Promise<Kline[]> {
  const d = await proxyFetch('binance', '/api/v3/klines', { symbol, interval, limit });
  return normalizeBinanceKlines(d);
}
export async function fetchCoinsMarket(): Promise<MarketTicker[]> {
  const d = await proxyFetch('coingecko', '/api/v3/coins/markets', {
    vs_currency: 'usd', order: 'market_cap_desc', per_page: 60, page: 1, sparkline: 'false',
    price_change_percentage: '24h',
  });
  return normalizeGeckoMarket(d);
}

export async function fetchKlines(symbol: string, interval = '15', limit = 200): Promise<Kline[]> {
  try {
    const k = await fetchKlinesBybit(symbol, interval, limit);
    if (Array.isArray(k) && k.length > 0) { activeSource = 'bybit'; return k; }
  } catch {}
  activeSource = 'binance';
  try {
    const bi = interval === '1' ? '1m' : interval === '5' ? '5m' : interval === '15' ? '15m' : interval === '60' ? '1h' : interval === '240' ? '4h' : '1d';
    const k = await fetchKlinesBinance(symbol, bi, limit);
    if (Array.isArray(k) && k.length > 0) return k;
  } catch {}
  return generateSyntheticKlines(symbol, limit);
}

export async function fetchTickers(): Promise<MarketTicker[]> {
  try {
    const d = await proxyFetch('binance', '/api/v3/ticker/24hr');
    const usdt = (Array.isArray(d) ? d : []).filter((t: any) => t.symbol?.endsWith('USDT'));
    if (usdt.length > 0) {
      return usdt.map((t: any) => ({
        symbol: t.symbol,
        price: Number(t.lastPrice),
        change24h: Number(t.priceChangePercent),
        volume24h: Number(t.quoteVolume),
        high24h: Number(t.highPrice),
        low24h: Number(t.lowPrice),
        marketCap: 0,
      }));
    }
  } catch {}
  try {
    return await fetchCoinsMarket();
  } catch {}
  return syntheticTickers();
}

export async function checkHealth(): Promise<'bybit' | 'binance' | 'synthetic'> {
  try { const k = await fetchKlinesBybit('BTCUSDT', '1', 10); if (k.length > 0) { activeSource = 'bybit'; return 'bybit'; } } catch {}
  try { const k = await fetchKlinesBinance('BTCUSDT', '1m', 10); if (k.length > 0) { activeSource = 'binance'; return 'binance'; } } catch {}
  activeSource = 'synthetic';
  return 'synthetic';
}
