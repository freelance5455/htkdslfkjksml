// Extended WebSocket client with real order book depth (Bybit orderbook.200 + Binance depth).
// Maintains a local order book and emits updates for OrderBook visualization.

export interface DepthLevel { price: number; size: number; }
export interface OrderBookSnapshot { symbol: string; bids: DepthLevel[]; asks: DepthLevel[]; }

type DepthListener = (snap: OrderBookSnapshot) => void;

interface BookState {
  bids: Map<number, number>;
  asks: Map<number, number>;
  lastUpdate: number;
}

import { wsClient } from './websocketService';

const books: Record<string, BookState> = {};
const depthListeners = new Set<DepthListener>();

function ensureBook(symbol: string): BookState {
  if (!books[symbol]) books[symbol] = { bids: new Map(), asks: new Map(), lastUpdate: 0 };
  return books[symbol];
}

// Subscribe for order book depth via the shared wsClient
// We re-use bybit linear WS via a special second connection for orderbook (kept separate to avoid complexity)
let bookWs: WebSocket | null = null;
let bookRetries = 0;
let bookSource: 'bybit' | 'binance' = 'bybit';
const subscribedSymbols = new Set<string>();

export function subscribeDepth(symbol: string) { subscribedSymbols.add(symbol); connectBook(); }
export function unsubscribeDepth(symbol: string) { subscribedSymbols.delete(symbol); }

export function onDepth(l: DepthListener) { depthListeners.add(l); return () => depthListeners.delete(l); }

export function getBookSnapshot(symbol: string): OrderBookSnapshot | null {
  const b = books[symbol];
  if (!b) return null;
  const bids = [...b.bids.entries()].sort((a, b2) => b2[0] - a[0]).slice(0, 20).map(([price, size]) => ({ price, size }));
  const asks = [...b.asks.entries()].sort((a, b2) => a[0] - b2[0]).slice(0, 20).map(([price, size]) => ({ price, size }));
  return { symbol, bids, asks };
}

function emit(symbol: string) {
  const snap = getBookSnapshot(symbol);
  if (!snap) return;
  depthListeners.forEach(l => { try { l(snap); } catch {} });
}

function handleBybitDepthMsg(d: any) {
  if (d.type === 'snapshot' || d.type === 'delta') {
    const topic: string = d.topic || '';
    const m = topic.match(/orderbook\.(\d+)\.(\S+)/);
    if (!m) return;
    const symbol = m[2];
    const book = ensureBook(symbol);
    const data = d.data;
    if (!data) return;
    if (d.type === 'snapshot') {
      book.bids.clear();
      book.asks.clear();
      const bids: [string, string][] = Array.isArray(data.b) ? data.b : [];
      const asks: [string, string][] = Array.isArray(data.a) ? data.a : [];
      bids.forEach(([p, s]) => {
        const price = Number(p), size = Number(s);
        if (size > 0) book.bids.set(price, size);
      });
      asks.forEach(([p, s]) => {
        const price = Number(p), size = Number(s);
        if (size > 0) book.asks.set(price, size);
      });
    } else {
      (data.b || []).forEach(([p, s]: [string, string]) => {
        const price = Number(p), size = Number(s);
        if (size <= 0) book.bids.delete(price); else book.bids.set(price, size);
      });
      (data.a || []).forEach(([p, s]: [string, string]) => {
        const price = Number(p), size = Number(s);
        if (size <= 0) book.asks.delete(price); else book.asks.set(price, size);
      });
    }
    book.lastUpdate = data.ts ?? Date.now();
    emit(symbol);
  }
}

function handleBinanceDepthMsg(d: any) {
  // Binance partial depth stream: <symbol>@depth20@100ms
  if (!d?.data?.b) return;
  const sym = d.stream?.split('@')[0]?.toUpperCase() || '';
  if (!sym) return;
  const book = ensureBook(sym);
  book.bids.clear();
  book.asks.clear();
  (d.data.b || []).forEach(([p, s]: [string, string]) => book.bids.set(Number(p), Number(s)));
  (d.data.a || []).forEach(([p, s]: [string, string]) => book.asks.set(Number(p), Number(s)));
  emit(sym);
}

function connectBook() {
  if (bookWs && (bookWs.readyState === WebSocket.OPEN || bookWs.readyState === WebSocket.CONNECTING)) {
    // Send subscribe
    const args = bookSource === 'bybit'
      ? [...subscribedSymbols].map(s => `orderbook.50.${s}`)
      : [...subscribedSymbols].map(s => `${s.toLowerCase()}@depth20@100ms`);
    if (args.length > 0) {
      try {
        if (bookSource === 'bybit') bookWs.send(JSON.stringify({ op: 'subscribe', args }));
        else {
          const req = { method: 'SUBSCRIBE', params: args, id: Date.now() };
          bookWs.send(JSON.stringify(req));
        }
      } catch {}
    }
    return;
  }
  try {
    const url = bookSource === 'bybit'
      ? 'wss://stream.bybit.com/v5/public/linear'
      : 'wss://stream.binance.com:9443/stream';
    bookWs = new WebSocket(url);
    bookWs.onopen = () => {
      bookRetries = 0;
      const args = bookSource === 'bybit'
        ? [...subscribedSymbols].map(s => `orderbook.50.${s}`)
        : [...subscribedSymbols].map(s => `${s.toLowerCase()}@depth20@100ms`);
      if (args.length > 0) {
        if (bookSource === 'bybit') bookWs?.send(JSON.stringify({ op: 'subscribe', args }));
        else bookWs?.send(JSON.stringify({ method: 'SUBSCRIBE', params: args, id: Date.now() }));
      }
      if (bookSource === 'bybit') {
        setInterval(() => { try { bookWs?.send(JSON.stringify({ op: 'ping' })); } catch {} }, 20000);
      }
    };
    bookWs.onmessage = (e) => {
      try {
        const d = JSON.parse(e.data);
        if (d.op === 'pong' || d.result) return;
        if (bookSource === 'bybit') handleBybitDepthMsg(d);
        else handleBinanceDepthMsg(d);
      } catch {}
    };
    bookWs.onerror = () => {};
    bookWs.onclose = () => {
      bookWs = null;
      bookRetries++;
      if (bookRetries >= 3 && bookSource === 'bybit') { bookSource = 'binance'; }
      setTimeout(connectBook, Math.min(30000, 1000 * bookRetries));
    };
  } catch {
    setTimeout(connectBook, 2000);
  }
}

// Kick off connection when module is imported
export function initOrderbookWS() {
  if (!bookWs) connectBook();
}
