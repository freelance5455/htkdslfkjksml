// notificationsService - web notifications (shim for Expo/Firebase Push on web)
// On native this would wrap expo-notifications / Firebase Cloud Messaging.

type Listener = (msg: { title: string; body: string; data?: any }) => void;
const listeners: Listener[] = [];

export async function requestPermission(): Promise<boolean> {
  if (!('Notification' in window)) return false;
  if (Notification.permission === 'granted') return true;
  if (Notification.permission === 'denied') return false;
  const p = await Notification.requestPermission();
  return p === 'granted';
}

export function sendPush(title: string, body: string, data?: any) {
  listeners.forEach(l => { try { l({ title, body, data }); } catch {} });
  if ('Notification' in window && Notification.permission === 'granted') {
    try {
      new Notification(title, { body, icon: '/vite.svg' });
    } catch {}
  }
  // also fire a toast event
  window.dispatchEvent(new CustomEvent('crypto-toast', { detail: { title, body } }));
}

export function subscribe(l: Listener) {
  listeners.push(l);
  return () => { const i = listeners.indexOf(l); if (i >= 0) listeners.splice(i, 1); };
}

export const notificationsService = { requestPermission, sendPush, subscribe };
