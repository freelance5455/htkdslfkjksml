// Live Fear & Greed Index + market sentiment computed from live ticker data.
// Uses the public alternative.me API via our market proxy.

export interface SentimentData {
  fearGreedValue: number;
  fearGreedLabel: string;
  btcDominance: number;
  totalMarketCap: number;
  btcChange24h: number;
  ethChange24h: number;
  advancers: number;
  decliners: number;
  total: number;
  marketSentiment: 'green' | 'yellow' | 'red';
}

const FALLBACK = (): SentimentData => ({
  fearGreedValue: 55,
  fearGreedLabel: 'תאוותנות',
  btcDominance: 52,
  totalMarketCap: 2_600_000_000_000,
  btcChange24h: 0,
  ethChange24h: 0,
  advancers: 50,
  decliners: 50,
  total: 100,
  marketSentiment: 'yellow',
});

export async function fetchSentiment(tickers: { symbol: string; change24h: number; marketCap?: number }[]): Promise<SentimentData> {
  let fearGreed = 55;
  let label = 'ניטראלי';
  try {
    const r = await fetch('https://api.alternative.me/fng/?limit=1').catch(() => null);
    if (r) {
      const d = await r.json();
      const v = Number(d?.data?.[0]?.value);
      if (!isNaN(v)) {
        fearGreed = v;
        const labels = ['פחד קיצוני', 'פחד', 'פחד', 'ניטראלי', 'תאוותנות', 'תאוותנות קיצונית'];
        label = labels[Math.min(5, Math.floor((v - 1) / 20))];
      }
    }
  } catch {}
  const usdt = Array.isArray(tickers) ? tickers.filter(t => t.symbol?.endsWith('USDT')) : [];
  const advancers = usdt.filter(t => t.change24h > 0).length;
  const decliners = usdt.filter(t => t.change24h < 0).length;
  const total = advancers + decliners || 1;
  const btcCap = (usdt.find(t => t.symbol === 'BTCUSDT')?.marketCap) ?? 1_300_000_000_000;
  const totalCap = usdt.reduce((s, t) => s + (t.marketCap || t.change24h * 0 + 100_000_000), 0) || 2_600_000_000_000;
  const btcChange = usdt.find(t => t.symbol === 'BTCUSDT')?.change24h ?? 0;
  const ethChange = usdt.find(t => t.symbol === 'ETHUSDT')?.change24h ?? 0;
  const advRatio = advancers / total;
  const sentiment: SentimentData['marketSentiment'] = advRatio > 0.6 ? 'green' : advRatio < 0.4 ? 'red' : 'yellow';
  return {
    fearGreedValue: fearGreed,
    fearGreedLabel: label,
    btcDominance: (btcCap / totalCap) * 100,
    totalMarketCap: totalCap,
    btcChange24h: btcChange,
    ethChange24h: ethChange,
    advancers, decliners, total,
    marketSentiment: sentiment,
  };
}

export const fallbackSentiment = FALLBACK;
