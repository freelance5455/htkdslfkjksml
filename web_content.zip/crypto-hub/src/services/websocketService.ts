// Live WebSocket ticker stream with auto-reconnect and fallback.
// Attempts Bybit linear tickers WS -> Binance miniTicker WS.
import { ConnectionStatus } from '../types';

export type Trade = { symbol: string; price: number; size: number; side: 'buy' | 'sell'; time: number };
export type MiniTicker = { symbol: string; price: number; change24h: number; high: number; low: number; volume: number };

type Listener = {
  onTicker?: (t: MiniTicker) => void;
  onTrade?: (t: Trade) => void;
  onStatus?: (s: ConnectionStatus) => void;
};

class WSClient {
  private ws: WebSocket | null = null;
  private listeners = new Set<Listener>();
  private source: 'bybit' | 'binance' = 'bybit';
  private retries = 0;
  private subscribed = new Set<string>();
  private hb: any = null;
  private status: ConnectionStatus = 'reconnecting';

  subscribe(l: Listener) { this.listeners.add(l); return () => this.listeners.delete(l); }

  connect() {
    this.disconnect();
    const url = this.source === 'bybit'
      ? 'wss://stream.bybit.com/v5/public/linear'
      : 'wss://stream.binance.com:9443/ws/!miniTicker@arr';
    try {
      this.ws = new WebSocket(url);
    } catch (e) { this.switchSource(); return; }
    this.ws.onopen = () => {
      this.retries = 0;
      this.setStatus(this.source === 'bybit' ? 'connected' : 'backup');
      if (this.source === 'bybit') {
        // Subscribe to individual tickers
        const args = Array.from(this.subscribed).flatMap(s => [`tickers.${s}`, `publicTrade.${s}`]);
        if (args.length === 0) args.push('tickers.BTCUSDT', 'publicTrade.BTCUSDT');
        this.ws?.send(JSON.stringify({ op: 'subscribe', args }));
        // Heartbeat ping every 20s
        this.hb = setInterval(() => {
          try { this.ws?.send(JSON.stringify({ op: 'ping' })); } catch {}
        }, 20000);
      }
    };
    this.ws.onmessage = (e) => {
      try {
        const d = JSON.parse(e.data);
        if (this.source === 'bybit') {
          if (d.op === 'pong') return;
          const topic: string = d.topic || '';
          if (topic.startsWith('tickers.') && d.data) {
            const t = Array.isArray(d.data) ? d.data[0] : d.data;
            const symbol = t.symbol;
            const ticker: MiniTicker = {
              symbol,
              price: Number(t.lastPrice ?? t.markPrice ?? 0),
              change24h: Number(t.price24hPcnt ?? 0) * 100,
              high: Number(t.highPrice24h ?? 0),
              low: Number(t.lowPrice24h ?? 0),
              volume: Number(t.volume24h ?? t.turnover24h ?? 0),
            };
            if (ticker.price > 0) this.listeners.forEach(l => l.onTicker?.(ticker));
          } else if (topic.startsWith('publicTrade.') && d.data) {
            const arr = Array.isArray(d.data) ? d.data : [d.data];
            arr.forEach((t: any) => {
              this.listeners.forEach(l => l.onTrade?.({
                symbol: t.s, price: Number(t.p), size: Number(t.v), side: (t.S || 'Buy').toLowerCase() === 'buy' ? 'buy' : 'sell', time: Number(t.T || Date.now()),
              }));
            });
          }
        } else {
          // Binance miniTicker arr
          if (Array.isArray(d)) {
            d.forEach((t: any) => {
              const symbol = t.s;
              if (!symbol.endsWith('USDT')) return;
              const price = Number(t.c);
              const open = Number(t.o);
              const chg = price && open ? ((price - open) / open) * 100 : 0;
              this.listeners.forEach(l => l.onTicker?.({
                symbol, price, change24h: chg,
                high: Number(t.h), low: Number(t.l), volume: Number(t.q),
              }));
            });
          }
        }
      } catch (err) { /* ignore malformed */ }
    };
    this.ws.onerror = () => { /* onclose handles reconnect */ };
    this.ws.onclose = () => {
      clearInterval(this.hb);
      this.retries++;
      if (this.retries >= 3) { this.switchSource(); return; }
      this.setStatus('reconnecting');
      setTimeout(() => this.connect(), Math.min(30000, 1000 * this.retries));
    };
  }

  private switchSource() {
    clearInterval(this.hb);
    this.source = this.source === 'bybit' ? 'binance' : 'bybit';
    this.setStatus('backup');
    setTimeout(() => this.connect(), 1000);
  }

  private setStatus(s: ConnectionStatus) {
    this.status = s;
    this.listeners.forEach(l => l.onStatus?.(s));
  }

  watch(symbols: string[]) {
    symbols.forEach(s => this.subscribed.add(s));
    if (this.ws?.readyState === WebSocket.OPEN && this.source === 'bybit') {
      const args = symbols.flatMap(s => [`tickers.${s}`, `publicTrade.${s}`]);
      try { this.ws.send(JSON.stringify({ op: 'subscribe', args })); } catch {}
    }
  }

  disconnect() {
    clearInterval(this.hb);
    if (this.ws) { try { this.ws.close(); } catch {} this.ws = null; }
  }
}

export const wsClient = new WSClient();
