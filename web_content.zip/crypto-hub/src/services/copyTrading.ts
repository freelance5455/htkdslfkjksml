import { MasterTrader, PaperOrder, AuditLog } from '../types';
import { AppState, loadState, saveState, uid } from '../store/useStore';
import { openOrder } from './paperTrading';
import { notificationsService } from './notificationsService';

// Generate simulated master-trader signals deterministically from live price action
// In production, this would subscribe to master trader websocket feeds.
// Here we create a model-driven simulated trade history so the UI is fully functional.

export interface SimulatedMasterTrade {
  traderId: string;
  symbol: string;
  direction: 'LONG' | 'SHORT';
  entry: number;
  sl?: number;
  tp?: number;
  leverage: number;
  timestamp: number;
}

// In-memory record of last simulated action per trader to avoid duplicates
const lastAction: Record<string, number> = {};

export function maybeCopyTrade(
  trader: MasterTrader,
  price: number,
  signalDirection: 'LONG' | 'SHORT' | 'WAIT',
  atr: number
) {
  if (!trader.isCopied) return;
  const now = Date.now();
  const last = lastAction[trader.id] ?? 0;
  // Deterministic-ish: based on trader's win rate & randomness, avoid spam
  if (now - last < 1000 * 60 * 15) return; // min 15m between actions per trader
  if (signalDirection === 'WAIT') return;

  // Allocation-based sizing
  const allocation = trader.copyAllocation ?? 500;
  const leverage = Math.min(trader.copyLeverageCap ?? trader.riskScore, 10);
  const lev = Math.max(1, leverage);
  const riskPct = 0.01;
  const stopDistance = Math.max(atr, price * 0.005) * 1.2;
  const sl = signalDirection === 'LONG' ? price - stopDistance : price + stopDistance;
  const tp = signalDirection === 'LONG' ? price + stopDistance * 2 : price - stopDistance * 2;
  const qty = (allocation * lev) / price;

  const state = loadState();
  // check max open positions cap
  const openCopyPositions = state.orders.filter(o => o.status === 'OPEN' && o.copiedTraderId === trader.id).length;
  if (openCopyPositions >= (trader.copyMaxPositions ?? 3)) return;

  // 15% chance of a trade per tick, scaled by winrate (simulated skill)
  const prob = (trader.winRate7d / 100) * 0.25;
  if (Math.random() > prob) return;

  lastAction[trader.id] = now;
  openOrder({
    symbol: 'BTCUSDT',
    direction: signalDirection,
    entryPrice: price,
    quantity: qty,
    leverage: lev,
    sl,
    tp,
    isCopy: true,
    copiedTraderId: trader.id,
    note: `חיקוי אוטומטי: ${trader.name}`,
  });
  notificationsService.sendPush('חיקוי עסקה חדש', `${trader.name} פתח ${signalDirection === 'LONG' ? 'לונג' : 'שורט'} ב-BTCUSDT`);
}

export function setCopySettings(traderId: string, updates: Partial<MasterTrader>): AppState {
  const state = loadState();
  const t = state.traders.find(x => x.id === traderId);
  if (t) {
    Object.assign(t, updates);
    if (updates.isCopied !== undefined) {
      const entry: AuditLog = {
        id: uid(),
        timestamp: Date.now(),
        type: 'success',
        message: updates.isCopied ? `הפעלת חיקוי לסוחר: ${t.name}` : `הפסקת חיקוי לסוחר: ${t.name}`,
      };
      state.auditLogs = [entry, ...state.auditLogs].slice(0, 200);
    }
    saveState(state);
  }
  return state;
}
