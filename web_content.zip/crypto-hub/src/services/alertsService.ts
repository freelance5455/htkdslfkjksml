import { uid } from '../store/useStore';
import { notificationsService } from './notificationsService';

export interface PriceAlert {
  id: string;
  symbol: string;
  condition: 'above' | 'below';
  price: number;
  createdAt: number;
  triggered: boolean;
}

const KEY = 'crypto-hub-alerts-v1';

export function loadAlerts(): PriceAlert[] {
  try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch { return []; }
}
export function saveAlerts(a: PriceAlert[]) { try { localStorage.setItem(KEY, JSON.stringify(a)); } catch {} }

export function addAlert(symbol: string, condition: 'above' | 'below', price: number): PriceAlert {
  const a: PriceAlert = { id: uid(), symbol, condition, price, createdAt: Date.now(), triggered: false };
  const list = loadAlerts();
  list.push(a);
  saveAlerts(list);
  return a;
}
export function removeAlert(id: string) {
  saveAlerts(loadAlerts().filter(a => a.id !== id));
}

export function checkAlerts(prices: Record<string, number>) {
  const list = loadAlerts();
  let changed = false;
  for (const a of list) {
    if (a.triggered) continue;
    const p = prices[a.symbol];
    if (!p) continue;
    const hit = a.condition === 'above' ? p >= a.price : p <= a.price;
    if (hit) {
      a.triggered = true; changed = true;
      notificationsService.sendPush('🚨 התראת מחיר', `${a.symbol} ${a.condition === 'above' ? 'חצה מעל' : 'ירד מתחת'} $${a.price.toFixed(2)} (מחיר עכשווי: $${p.toFixed(2)})`);
    }
  }
  if (changed) saveAlerts(list);
  return list;
}
