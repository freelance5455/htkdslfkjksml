import { PaperOrder } from '../types';
import { AppState, loadState, saveState, uid } from '../store/useStore';
import { notificationsService } from './notificationsService';

export interface OpenOrderInput {
  symbol: string;
  direction: 'LONG' | 'SHORT';
  entryPrice: number;
  quantity: number;
  leverage: number;
  sl?: number;
  tp?: number;
  orderType?: 'market' | 'limit';
  limitPrice?: number;
  isCopy?: boolean;
  copiedTraderId?: string;
  note?: string;
}

export function openOrder(input: OpenOrderInput): { state: AppState; order: PaperOrder | null; error?: string } {
  const state = loadState();
  const isLimit = input.orderType === 'limit';
  const executionPrice = isLimit ? (input.limitPrice || input.entryPrice) : input.entryPrice;
  const margin = (executionPrice * input.quantity) / input.leverage;
  if (margin > state.paperBalance) {
    return { state, order: null, error: 'אין מספיק יתרה בחשבון הדמו' };
  }
  const order: PaperOrder = {
    id: uid(),
    symbol: input.symbol,
    direction: input.direction,
    entryPrice: isLimit ? executionPrice : input.entryPrice,
    quantity: input.quantity,
    leverage: input.leverage,
    sl: input.sl,
    tp: input.tp,
    orderType: input.orderType || 'market',
    limitPrice: isLimit ? executionPrice : undefined,
    status: isLimit ? 'PENDING' : 'OPEN',
    openedAt: Date.now(),
    isCopy: input.isCopy,
    copiedTraderId: input.copiedTraderId,
    note: input.note,
  };
  if (!isLimit) state.paperBalance -= margin; // reserve margin immediately for market
  state.orders = [order, ...state.orders];
  saveState(state);
  notificationsService.sendPush(
    isLimit ? 'פקודת Limit נוצרה (דמו)' : 'עסקה חדשה נפתחה (דמו)',
    isLimit
      ? `${input.direction === 'LONG' ? 'לונג' : 'שורט'} ${input.symbol} @ $${executionPrice.toFixed(2)} - ממתין למימוש`
      : `${input.direction === 'LONG' ? 'לונג' : 'שורט'} ${input.symbol} @ ${input.entryPrice.toFixed(2)}`
  );
  return { state, order };
}

export function closeOrder(orderId: string, price: number, note?: string): { state: AppState; pnl: number } {
  const state = loadState();
  const o = state.orders.find(x => x.id === orderId);
  if (!o || o.status !== 'OPEN') return { state, pnl: 0 };
  const dirMul = o.direction === 'LONG' ? 1 : -1;
  const rawPnl = (price - o.entryPrice) * o.quantity * dirMul;
  const pnl = rawPnl; // already PnL in quote units
  const pnlPct = ((price - o.entryPrice) / o.entryPrice) * 100 * dirMul * o.leverage;
  const marginBack = (o.entryPrice * o.quantity) / o.leverage;
  o.status = 'CLOSED';
  o.closedAt = Date.now();
  o.closePrice = price;
  o.pnl = pnl;
  o.pnlPct = pnlPct;
  o.note = note || o.note;
  state.paperBalance += marginBack + pnl;
  saveState(state);
  notificationsService.sendPush('עסקה נסגרה (דמו)', `${o.symbol} ${pnl >= 0 ? 'רווח' : 'הפסד'} $${pnl.toFixed(2)} (${pnlPct.toFixed(2)}%)`);
  return { state, pnl };
}

export function calcLiquidationPrice(o: PaperOrder): number {
  // Simple: liq when ~90% of margin is lost
  const margin = (o.entryPrice * o.quantity) / o.leverage;
  const lossPerCoin = margin * 0.9 / o.quantity;
  return o.direction === 'LONG' ? o.entryPrice - lossPerCoin : o.entryPrice + lossPerCoin;
}

export function unrealizedPnL(o: PaperOrder, price: number): number {
  const dir = o.direction === 'LONG' ? 1 : -1;
  return (price - o.entryPrice) * o.quantity * dir;
}

export function cancelOrder(orderId: string) {
  const state = loadState();
  const o = state.orders.find(x => x.id === orderId);
  if (!o || o.status !== 'PENDING') return;
  o.status = 'CANCELLED';
  o.note = 'בוטל ידנית';
  o.closedAt = Date.now();
  saveState(state);
}

export function monitorOrders(prices: Record<string, number>) {
  const state = loadState();
  let changed = false;
  for (const o of state.orders) {
    const p = prices[o.symbol];
    if (!p) continue;
    // Fill PENDING limit orders when price crosses them
    if (o.status === 'PENDING' && o.orderType === 'limit' && o.limitPrice) {
      const lp = o.limitPrice;
      const hit = (o.direction === 'LONG' && p <= lp) || (o.direction === 'SHORT' && p >= lp);
      if (hit) {
        o.status = 'OPEN';
        o.entryPrice = lp;
        const margin = (lp * o.quantity) / o.leverage;
        // Reserve margin from balance (deduct now)
        state.paperBalance -= margin;
        o.note = `Limit מומש @ $${lp.toFixed(2)}`;
        changed = true;
        notificationsService.sendPush('Limit order מומש', `${o.symbol} ${o.direction} @ $${lp.toFixed(2)}`);
      }
      continue;
    }
    if (o.status !== 'OPEN') continue;
    const liq = calcLiquidationPrice(o);
    if ((o.direction === 'LONG' && p <= liq) || (o.direction === 'SHORT' && p >= liq)) {
      closeOrderSync(state, o, p, 'חוסל (Liquidation)');
      changed = true;
      continue;
    }
    if (o.sl) {
      if ((o.direction === 'LONG' && p <= o.sl) || (o.direction === 'SHORT' && p >= o.sl)) {
        closeOrderSync(state, o, o.sl, 'Stop-Loss הופעל');
        changed = true;
        continue;
      }
    }
    if (o.tp) {
      if ((o.direction === 'LONG' && p >= o.tp) || (o.direction === 'SHORT' && p <= o.tp)) {
        closeOrderSync(state, o, o.tp, 'Take-Profit הופעל');
        changed = true;
        continue;
      }
    }
  }
  if (changed) saveState(state);
}

function closeOrderSync(state: AppState, o: PaperOrder, price: number, note: string) {
  const dir = o.direction === 'LONG' ? 1 : -1;
  const pnl = (price - o.entryPrice) * o.quantity * dir;
  const pnlPct = ((price - o.entryPrice) / o.entryPrice) * 100 * dir * o.leverage;
  const marginBack = (o.entryPrice * o.quantity) / o.leverage;
  o.status = 'CLOSED';
  o.closedAt = Date.now();
  o.closePrice = price;
  o.pnl = pnl;
  o.pnlPct = pnlPct;
  o.note = note;
  state.paperBalance += marginBack + pnl;
  notificationsService.sendPush(note, `${o.symbol} - ${pnl >= 0 ? 'רווח' : 'הפסד'} $${pnl.toFixed(2)}`);
}
