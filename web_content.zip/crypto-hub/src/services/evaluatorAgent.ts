import { AppState, loadState, saveState, uid } from '../store/useStore';
import { TradeSignal, PaperOrder, AuditLog } from '../types';
import { notificationsService } from './notificationsService';

// On every 5-minute scan, audit recently closed signals: compare signal direction to later prices.
// Diagnose failures & adjust confluence threshold adaptively.

export function auditSignal(signal: TradeSignal, laterPrice: number, state: AppState): AppState {
  const { direction, entry, sl, tp1, timestamp } = signal;
  if (direction === 'WAIT') return state;
  const isLong = direction === 'LONG';
  // Did it hit TP1 before SL? (simple heuristic using laterPrice + 5min close)
  const reachedTP = isLong ? laterPrice >= tp1 : laterPrice <= tp1;
  const reachedSL = isLong ? laterPrice <= sl : laterPrice >= sl;
  const won = reachedTP && !reachedSL;
  const lost = reachedSL;
  state.totalSignalsEvaluated += 1;
  if (won) state.signalsWon += 1;

  let type: AuditLog['type'] = 'success';
  let message = '';
  let details = '';

  if (won) {
    message = `אות מוצלח (${signal.symbol} ${direction}): הגיע ל-TP1`;
    type = 'success';
  } else if (lost) {
    type = 'failure';
    const ind = signal.indicators;
    const volLow = ind.currentVolume < ind.volumeSma20 * 0.9;
    const adxLow = ind.adx < 20;
    const rsiDiv = (isLong && ind.rsi > 65) || (!isLong && ind.rsi < 35);
    const reasons: string[] = [];
    if (volLow) reasons.push('נפח נמוך מתחת לממוצע');
    if (adxLow) reasons.push(`ADX חלש (${ind.adx.toFixed(0)}) - חוסר מגמה`);
    if (rsiDiv) reasons.push('סטיית RSI בכיוון ההפוך');
    if (reasons.length === 0) reasons.push('פריצת שווא / רעש שוק');
    message = `כישלון אות (${signal.symbol} ${direction}): ${reasons.join('; ')}`;
    details = reasons.join(' | ');
  } else {
    return state; // unresolved yet
  }

  state.auditLogs = [{ id: uid(), timestamp: Date.now(), type, message, details, symbol: signal.symbol }, ...state.auditLogs].slice(0, 200);

  // Adaptive threshold correction every 30 signals
  if (state.totalSignalsEvaluated > 0 && state.totalSignalsEvaluated % 30 === 0) {
    const wr = state.signalsWon / state.totalSignalsEvaluated;
    if (wr < 0.75 && state.signalConfig.minConfluence < 5) {
      state.signalConfig = { ...state.signalConfig, minConfluence: Math.min(5, state.signalConfig.minConfluence + 1) };
      state.auditLogs = [{ id: uid(), timestamp: Date.now(), type: 'tweak', message: `כויל אוטומטי: הועלתה דרישת קונפלואינציה ל-${state.signalConfig.minConfluence}/5 אינדיקטורים (שיעור הצלחה ${(wr * 100).toFixed(0)}% ב-30 אותות אחרונים)` }, ...state.auditLogs];
      notificationsService.sendPush('שינוי פרמטרים אוטומטי', `אחוז הצלחה ירד מתחת ל-75% - הוחרפו תנאי הכניסה. אחוז נוכחי: ${(wr * 100).toFixed(0)}%`);
    } else if (wr > 0.85 && state.signalConfig.minConfluence > 2) {
      state.signalConfig = { ...state.signalConfig, minConfluence: Math.max(2, state.signalConfig.minConfluence - 1) };
      state.auditLogs = [{ id: uid(), timestamp: Date.now(), type: 'tweak', message: `כויל אוטומטי: הורדה לדרישת קונפלואינציה ${state.signalConfig.minConfluence}/5 (שיעור הצלחה ${(wr * 100).toFixed(0)}%)` }, ...state.auditLogs];
    }
  }
  return state;
}

export function runEvaluatorCycle(latestSignal: TradeSignal | null, getPrice: (s: string) => number | null) {
  let state = loadState();
  if (latestSignal) {
    const later = getPrice(latestSignal.symbol);
    if (later) state = auditSignal(latestSignal, later, state);
  }
  // Check open paper orders for SL/TP triggers - handled in paper trading engine
  saveState(state);
}
