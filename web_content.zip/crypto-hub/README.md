# 💎 Crypto Hub - קריפטו האב

A complete, production-ready Crypto Scanner, AI Trading, Deep Intelligence, Paper Trading, Copy Trading & Financial Hub application — with full **Hebrew RTL** support.

## Features

### 1. 🎯 AI Signals & Deep Analysis (אותות ועצות מסחר)
- Multi-indicator technical engine: RSI(14), MACD(12,26,9), EMA(20/50/200), ATR(14), ADX, Volume Profile
- **100% dynamic** — no static confidence numbers; all metrics computed live
- Direction: LONG / SHORT / WAIT with entry, ATR-based SL, TP1, TP2
- **Kelly Criterion** position sizing + ATR-based leverage recommendation
- Manual scan button + 5-minute background polling
- Real CORS-safe data fetching with Bybit → Binance → CoinGecko failover

### 2. 🏆 Copy Trading (חיקוי עסקאות סוחרים)
- 6 master traders + AI strategies with live win-rate, ROI, drawdown, profit factor, risk score
- One-click Follow & Auto-Mirroring
- Per-trader allocation, copy SL%, max positions, leverage caps
- Full Paper Trading integration (test copy trading with virtual $10,000)

### 3. 📊 Demo / Paper Trading (מסחר דמו)
- $10,000 default virtual balance
- Real-time LONG/SHORT market orders with live Bybit/Binance prices
- Real-time unrealized P&L, margin usage, liquidation price calculation
- Automatic SL/TP/liquidation execution
- Reset demo balance button + full ledger history

### 4. 📈 Synced Candlestick Charts (גרפים)
- 200 live candlestick bars via Bybit V5 → Binance failover
- TradingView-style rendering with lightweight-charts
- 8 major pairs, 6 timeframes, entry/SL/TP markers

### 5. 🗺️ Market Heatmap (מפת שוק)
- Finviz-style treemap of top 60 crypto assets
- Sized by market cap OR 24h volume, colored by % change (-5% deep red ↔ +5% deep green)

### 6. 🔬 Fundamental Research (מחקר עומק)
- Messari-style token intelligence: on-chain volume, active wallets, supply inflation, dev activity, AI summaries
- Pros/cons per asset, category classification

### 7. 🧾 Israeli Tax Hub (פיננסים, מיסוי ודוחות)
- Realized/unrealized P&L ledger
- Digital USDT/ILS invoice generator
- Tax calculation: 25% capital gains vs. 50% business income
- CSV export (Form 909 compliant)

### 8. 🧠 Self-Checking Evaluator Agent
- Audits every signal against real exit prices every 5 minutes
- Hebrew post-mortem diagnostics (false breakout, low volume, weak ADX, RSI divergence)
- Adaptive confluence thresholds (auto-tightens when 30-trade win rate drops below 75%)
- Push notifications on regime shifts & auto-tweaks

### 9. 🔔 Push Notifications
- High-confidence signals (>80% confluence)
- Copy-trade execution
- SL/TP hits
- Evaluator warnings

### 10. 🟢 Connection Health Monitor
- Pings Bybit every 12 seconds
- Hebrew header badges: 🟢 מחובר, 🟡 איטי, 🔴 מתחבר, 🟠 שרת גיבוי
- Auto-failover between Bybit, Binance, CoinGecko via Vite proxy + public CORS proxies

## Stack
- **React 18 + TypeScript + Vite** (web)
- **Tailwind CSS** (dark trading theme, RTL)
- **lightweight-charts** (TradingView-grade candlesticks)
- **localStorage** persistence (orders, traders, invoices, tax records)
- **Expo/EAS** build configuration for Android APK (`eas.json`, `app.json`)

## Run it
```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # production build
```

## Build Android APK
With Expo/EAS:
```bash
npm i -g eas-cli
eas build -p android --profile preview
```
The `preview` profile in `eas.json` produces a standalone `.apk`.

## File Architecture
```
src/
├── App.tsx                    # Main shell + tab router + scan scheduler
├── main.tsx                   # Entry point
├── index.css                  # Tailwind + RTL + animations
├── components/
│   ├── ErrorBoundary.tsx      # Root crash protection
│   ├── HealthBadge.tsx        # Live connection status (Hebrew)
│   ├── Toast.tsx              # Toast notification system
│   ├── UI.tsx                 # Card/Button/Stat/Badge primitives
│   ├── CandleChart.tsx        # Lightweight-charts candlestick wrapper
│   └── AuditLog.tsx           # Evaluator self-audit log view
├── services/
│   ├── marketService.ts       # Bybit/Binance/CoinGecko fetch + CORS failover
│   ├── notificationsService.ts# Push notification service (Web → Expo/Firebase API)
│   ├── evaluatorAgent.ts      # 5-min audit, post-mortems, adaptive thresholds
│   ├── paperTrading.ts        # Paper order engine, SL/TP monitor, P&L
│   └── copyTrading.ts         # Master-trader replication engine
├── utils/
│   ├── indicators.ts          # RSI/MACD/EMA/ATR/ADX/SMA (pure TS, no deps)
│   ├── signalEngine.ts        # AI confluence engine, Kelly sizing, SL/TP
│   └── tax.ts                 # Israeli tax calc, invoices, CSV export
├── hooks/
│   └── useConnectionHealth.ts # 12s heartbeat monitor
├── store/
│   └── useStore.ts            # localStorage-backed state + seed traders
├── tabs/
│   ├── SignalsTab.tsx
│   ├── CopyTradingTab.tsx
│   ├── PaperTradingTab.tsx
│   ├── ChartsTab.tsx
│   ├── HeatmapTab.tsx
│   ├── ResearchTab.tsx
│   └── FinanceTab.tsx
└── types/index.ts             # Full TypeScript type model
```
