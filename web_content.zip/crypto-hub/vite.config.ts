import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { marketProxyPlugin } from './src/server/marketProxyPlugin';

export default defineConfig({
  plugins: [react(), marketProxyPlugin()],
  server: {
    host: '0.0.0.0',
    port: 5173,
    allowedHosts: true,
    proxy: {
      '/api/bybit': {
        target: 'https://api.bybit.com',
        changeOrigin: true,
        rewrite: (p) => p.replace(/^\/api\/bybit/, ''),
      },
      '/api/binance': {
        target: 'https://api.binance.com',
        changeOrigin: true,
        rewrite: (p) => p.replace(/^\/api\/binance/, ''),
      },
      '/api/coingecko': {
        target: 'https://api.coingecko.com',
        changeOrigin: true,
        rewrite: (p) => p.replace(/^\/api\/coingecko/, ''),
      },
    },
  },
});
