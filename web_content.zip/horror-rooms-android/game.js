// ==============================
// Horror Rooms - Android Web Game
// ==============================

let scene, camera, renderer, raycaster, mouse;
let currentRoom = 'main';
let interactables = [];
let isPlaying = false;
let clock = new THREE.Clock();

// بيانات الشخصيات والغرف
const CHARACTERS = {
  piggy:       { name: 'Piggy',       color: 0xff69b4, msg: 'Oink... جاية لك!' },
  baldi:       { name: 'Baldi',       color: 0x00ff00, msg: 'You got a wrong answer!' },
  neighbor:    { name: 'Neighbor',    color: 0x4488ff, msg: 'من بيتي؟!' },
  misst:       { name: 'Miss T',      color: 0xffaa00, msg: 'هتعاقب دلوقتي!' },
  sirenhead:   { name: 'Siren Head',  color: 0x222222, msg: '██████████████' },
  rod:         { name: 'Rod',         color: 0x88ccff, msg: 'Ice Cream...؟' },
  granny:      { name: 'Granny',      color: 0xccccaa, msg: 'هتلاقيك يا حبيبي...' },
  bacon:       { name: 'Bacon',       color: 0xff8800, msg: 'oof...' }
};

const ROOMS = {
  main: {
    name: 'الغرفة الرئيسية',
    doors: [
      { to: 'piggy',    pos: [-4, 0, -5], rot: 0 },
      { to: 'baldi',    pos: [0, 0, -5],  rot: 0 },
      { to: 'neighbor', pos: [4, 0, -5],  rot: 0 },
      { to: 'misst',    pos: [-4, 0, 5],  rot: Math.PI },
      { to: 'siren',    pos: [0, 0, 5],   rot: Math.PI },
      { to: 'rod',      pos: [4, 0, 5],   rot: Math.PI }
    ]
  },
  piggy:    { name: 'غرفة Piggy',     char: 'piggy' },
  baldi:    { name: 'غرفة Baldi',     char: 'baldi' },
  neighbor: { name: 'غرفة Neighbor',  char: 'neighbor' },
  misst:    { name: 'غرفة Miss T',    char: 'misst' },
  siren:    { name: 'غرفة Siren Head',char: 'sirenhead' },
  rod:      { name: 'غرفة Rod',       char: 'rod' },
  granny:   { name: 'غرفة Granny',    char: 'granny' },
  bacon:    { name: 'غرفة Bacon',     char: 'bacon' }
};

// ==============================
// تهيئة اللعبة
// ==============================
function init() {
  const canvas = document.getElementById('game-canvas');

  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x050505);
  scene.fog = new THREE.Fog(0x050505, 8, 25);

  camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.1, 100);
  camera.position.set(0, 1.6, 0);

  renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;

  // إضاءة رعب
  const ambient = new THREE.AmbientLight(0x222222);
  scene.add(ambient);

  const point = new THREE.PointLight(0xff2200, 0.8, 15);
  point.position.set(0, 3, 0);
  scene.add(point);

  const flicker = new THREE.PointLight(0xaa0000, 0.4, 10);
  flicker.position.set(2, 2.5, -2);
  scene.add(flicker);
  // حفظ للإضاءة المتذبذبة
  window.flickerLight = flicker;

  raycaster = new THREE.Raycaster();
  mouse = new THREE.Vector2();

  // أحداث
  window.addEventListener('resize', onResize);
  canvas.addEventListener('pointerdown', onPointerDown);
  document.getElementById('start-btn').addEventListener('click', startGame);
  document.getElementById('back-btn').addEventListener('click', goToMain);

  // منع السكرول
  document.body.addEventListener('touchmove', e => e.preventDefault(), { passive: false });

  buildRoom('main');
  animate();
}

function startGame() {
  document.getElementById('start-screen').classList.add('hidden');
  document.getElementById('ui').classList.remove('hidden');
  isPlaying = true;
  updateUI();
}

// ==============================
// بناء الغرف
// ==============================
function clearScene() {
  // إزالة كل شيء ما عدا الإضاءة
  const toRemove = [];
  scene.traverse(obj => {
    if (obj.isMesh || obj.isGroup) toRemove.push(obj);
  });
  toRemove.forEach(obj => {
    if (obj.parent) obj.parent.remove(obj);
  });
  interactables = [];
}

function createFloor() {
  const geo = new THREE.PlaneGeometry(20, 20);
  const mat = new THREE.MeshStandardMaterial({ 
    color: 0x1a1a1a, 
    roughness: 0.9,
    metalness: 0.1
  });
  const floor = new THREE.Mesh(geo, mat);
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);

  // شبكة أرضية
  const grid = new THREE.GridHelper(20, 20, 0x330000, 0x220000);
  grid.position.y = 0.01;
  scene.add(grid);
}

function createWalls() {
  const wallMat = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.95 });
  const wallH = 4;
  const wallT = 0.3;

  // الجدران الأربعة
  const positions = [
    { pos: [0, wallH/2, -6], size: [12, wallH, wallT] },
    { pos: [0, wallH/2, 6],  size: [12, wallH, wallT] },
    { pos: [-6, wallH/2, 0], size: [wallT, wallH, 12] },
    { pos: [6, wallH/2, 0],  size: [wallT, wallH, 12] }
  ];

  positions.forEach(p => {
    const geo = new THREE.BoxGeometry(...p.size);
    const wall = new THREE.Mesh(geo, wallMat);
    wall.position.set(...p.pos);
    wall.castShadow = true;
    wall.receiveShadow = true;
    scene.add(wall);
  });
}

function createDoor(doorData) {
  const group = new THREE.Group();
  group.position.set(...doorData.pos);
  group.rotation.y = doorData.rot;

  // إطار الباب
  const frameMat = new THREE.MeshStandardMaterial({ color: 0x3a1a1a });
  const frame = new THREE.Mesh(new THREE.BoxGeometry(1.6, 2.6, 0.15), frameMat);
  frame.position.y = 1.3;
  group.add(frame);

  // الباب نفسه
  const doorMat = new THREE.MeshStandardMaterial({ color: 0x5a2a2a });
  const door = new THREE.Mesh(new THREE.BoxGeometry(1.4, 2.4, 0.08), doorMat);
  door.position.set(0, 1.2, 0.05);
  door.userData = { type: 'door', target: doorData.to };
  group.add(door);

  // مقبض
  const handle = new THREE.Mesh(
    new THREE.SphereGeometry(0.06, 8, 8),
    new THREE.MeshStandardMaterial({ color: 0xaaaaaa, metalness: 0.8 })
  );
  handle.position.set(0.5, 1.2, 0.12);
  group.add(handle);

  // لوحة اسم الغرفة
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 64;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#1a0000';
  ctx.fillRect(0, 0, 256, 64);
  ctx.fillStyle = '#ff4444';
  ctx.font = 'bold 28px Arial';
  ctx.textAlign = 'center';
  ctx.fillText(ROOMS[doorData.to]?.name || doorData.to, 128, 42);

  const tex = new THREE.CanvasTexture(canvas);
  const label = new THREE.Mesh(
    new THREE.PlaneGeometry(1.2, 0.3),
    new THREE.MeshBasicMaterial({ map: tex, transparent: true })
  );
  label.position.set(0, 2.7, 0.1);
  group.add(label);

  scene.add(group);
  interactables.push(door);
}

function createCharacter(charKey) {
  const data = CHARACTERS[charKey];
  if (!data) return;

  const group = new THREE.Group();
  group.position.set(0, 0, -2);

  // الجسم
  const bodyMat = new THREE.MeshStandardMaterial({ 
    color: data.color, 
    roughness: 0.7,
    emissive: data.color,
    emissiveIntensity: 0.15
  });

  // رأس
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.45, 16, 16), bodyMat);
  head.position.y = 1.7;
  group.add(head);

  // جسم
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.4, 1.0, 12), bodyMat);
  body.position.y = 0.9;
  group.add(body);

  // عيون متوهجة
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0xff0000 });
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), eyeMat);
  eyeL.position.set(-0.15, 1.75, 0.38);
  group.add(eyeL);
  const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), eyeMat);
  eyeR.position.set(0.15, 1.75, 0.38);
  group.add(eyeR);

  // اسم الشخصية فوقها
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 64;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'rgba(0,0,0,0.7)';
  ctx.fillRect(0, 0, 256, 64);
  ctx.fillStyle = '#ff2222';
  ctx.font = 'bold 32px Arial';
  ctx.textAlign = 'center';
  ctx.fillText(data.name, 128, 42);

  const tex = new THREE.CanvasTexture(canvas);
  const label = new THREE.Mesh(
    new THREE.PlaneGeometry(1.5, 0.4),
    new THREE.MeshBasicMaterial({ map: tex, transparent: true })
  );
  label.position.y = 2.4;
  group.add(label);

  // جعل المجموعة قابلة للتفاعل
  group.traverse(c => {
    if (c.isMesh) {
      c.userData = { type: 'character', char: charKey };
      interactables.push(c);
    }
  });

  scene.add(group);

  // دوران بسيط
  group.userData.spin = true;
  window.charGroup = group;
}

function buildRoom(roomId) {
  clearScene();
  currentRoom = roomId;
  createFloor();
  createWalls();

  const room = ROOMS[roomId];

  if (roomId === 'main') {
    // أبواب للغرف
    room.doors.forEach(d => createDoor(d));
    // باب إضافي لـ Granny و Bacon
    createDoor({ to: 'granny', pos: [-6, 0, 0], rot: Math.PI / 2 });
    createDoor({ to: 'bacon',  pos: [6, 0, 0],  rot: -Math.PI / 2 });
  } else if (room.char) {
    createCharacter(room.char);
  }

  // إضاءة خفيفة في الغرفة
  const roomLight = new THREE.PointLight(0xff1100, 0.6, 12);
  roomLight.position.set(0, 3, 0);
  scene.add(roomLight);

  updateUI();
}

// ==============================
// التفاعل
// ==============================
function onPointerDown(event) {
  if (!isPlaying) return;

  const rect = renderer.domElement.getBoundingClientRect();
  mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
  mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

  raycaster.setFromCamera(mouse, camera);
  const hits = raycaster.intersectObjects(interactables, true);

  if (hits.length > 0) {
    const obj = hits[0].object;
    const data = obj.userData;

    if (data.type === 'door') {
      // انتقال للغرفة
      buildRoom(data.target);
      // صوت باب (محاكاة)
      playClickSound();
    } else if (data.type === 'character') {
      triggerJumpscare(data.char);
    }
  }
}

function goToMain() {
  buildRoom('main');
  playClickSound();
}

function triggerJumpscare(charKey) {
  const data = CHARACTERS[charKey];
  if (!data) return;

  const el = document.getElementById('jumpscare');
  document.getElementById('jumpscare-name').textContent = data.name;
  document.getElementById('jumpscare-msg').textContent = data.msg;
  el.classList.remove('hidden');

  // اهتزاز الشاشة (Android)
  if (navigator.vibrate) navigator.vibrate([100, 50, 100, 50, 200]);

  // صوت رعب بسيط (Web Audio)
  playHorrorSound();

  setTimeout(() => {
    el.classList.add('hidden');
  }, 1800);
}

// ==============================
// أصوات بسيطة (Web Audio API)
// ==============================
function playClickSound() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.value = 180;
    gain.gain.setValueAtTime(0.15, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.15);
    osc.start();
    osc.stop(ctx.currentTime + 0.15);
  } catch(e) {}
}

function playHorrorSound() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    // نغمة منخفضة مرعبة
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(80, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(30, ctx.currentTime + 1.2);
    gain.gain.setValueAtTime(0.3, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 1.5);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 1.5);
  } catch(e) {}
}

// ==============================
// واجهة
// ==============================
function updateUI() {
  const room = ROOMS[currentRoom];
  document.getElementById('room-name').textContent = room.name;
  document.getElementById('hint-text').textContent = 
    currentRoom === 'main' ? 'اضغط على باب للدخول' : 'اضغط على الشخصية للاتصال';
  
  const backBtn = document.getElementById('back-btn');
  if (currentRoom === 'main') {
    backBtn.classList.add('hidden');
  } else {
    backBtn.classList.remove('hidden');
  }
}

// ==============================
// حلقة الرسم
// ==============================
function animate() {
  requestAnimationFrame(animate);

  const t = clock.getElapsedTime();

  // إضاءة متذبذبة
  if (window.flickerLight) {
    window.flickerLight.intensity = 0.3 + Math.sin(t * 8) * 0.2 + Math.random() * 0.1;
  }

  // دوران الشخصية
  if (window.charGroup) {
    window.charGroup.rotation.y = Math.sin(t * 0.8) * 0.3;
  }

  renderer.render(scene, camera);
}

function onResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}

// تشغيل
init();
