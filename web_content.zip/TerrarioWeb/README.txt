TERRARIO - version 3, thème nature
1. Décompresse le ZIP sur ton téléphone.
2. Ouvre le dossier TerrarioWeb dans Acode.
3. Ouvre index.html puis lance Preview/Aperçu.
Thème amélioré : couleurs naturelles, cartes arrondies, décorations d'insectes et de plantes.
Fonctions conservées : fiches avec photos, habitats, reproductions, naissances et soins.
Les données restent dans le stockage local du navigateur. Exporte régulièrement une sauvegarde JSON.
