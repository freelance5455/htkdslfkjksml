펫타운 판타지 Android 앱 프로젝트

현재 제작된 애니메이션풍 펫타운 RPG가 앱 안에 포함되어 있습니다.

APK 만들기:
1. Android Studio에서 이 폴더를 엽니다.
2. Gradle 동기화를 기다립니다.
3. Build > Build Bundle(s) / APK(s) > Build APK(s)를 선택합니다.
4. 생성된 APK를 Android 스마트폰에 설치합니다.

앱 이름: 펫타운 판타지
패키지명: com.pettown.fantasy
화면 방향: 세로
