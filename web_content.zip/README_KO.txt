자산온 안드로이드 프로젝트 (APK 빌드용)

이 폴더는 APK 자체가 아니라 APK를 만들기 위한 Android Studio 프로젝트 소스입니다.
포함 기능: 앱 아이콘으로 실행되는 WebView 껍데기 + 자산온 HTML 화면.
인터넷/시세 자동연동은 없으며, 입력 데이터는 앱 내부 WebView 저장소에 보관됩니다.

빌드하려면 Android Studio가 설치된 컴퓨터가 필요합니다.
1. ZIP 압축을 풉니다.
2. Android Studio에서 이 폴더를 프로젝트로 엽니다.
3. Gradle 동기화를 완료합니다.
4. Build > Build Bundle(s) / APK(s) > Build APK(s)를 선택합니다.
5. 생성된 APK를 갤럭시로 옮겨 설치합니다.

현재 이 채팅에서는 Android SDK/Gradle 빌드 환경이 없어 APK 바이너리를 직접 생성하지 못했습니다.
