// ====================================================================
// BLOCK 4: RECTIFIED DATABASE EXPORT COMPILERS WITH FULL METAS
// ====================================================================

const chordScale = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];

function transposeChords(semitones) {
  const song = songbook.find(s => s.id === currentSongId); if (!song) return;
  song.lyrics = song.lyrics.replace(/\[([^\]]+)\]/g, (match, chordToken) => {
    const rootMatch = chordToken.match(/^([A-G]#?|[A-G]b?)/); if (!rootMatch) return `[${chordToken}]`;
    let root = rootMatch[0]; const rest = chordToken.slice(root.length);
    if (root.endsWith('b')) { const map = { 'Db':'C#', 'Eb':'D#', 'Gb':'F#', 'Ab':'G#', 'Bb':'A#' }; root = map[root] || root; }
    let idx = chordScale.indexOf(root); if (idx === -1) return `[${chordToken}]`;
    return `[${chordScale[(idx + semitones + 12) % 12]}${rest}]`;
  });
  commitDatabaseMutation(); loadSong(currentSongId);
}

function clearFormForNewSong() {
  document.getElementById('edit-id').value = ""; document.getElementById('edit-title').value = ""; document.getElementById('edit-artist').value = ""; 
  document.getElementById('edit-tune').value = ""; document.getElementById('edit-style').value = ""; document.getElementById('edit-signature').value = "";
  document.getElementById('edit-duration').value = ""; document.getElementById('edit-lyrics').value = "";
  document.getElementById('delete-song-btn').style.display = "none"; document.getElementById('edit-title').focus();
}

function saveSong() {
  const id = document.getElementById('edit-id').value; const title = document.getElementById('edit-title').value.trim(); const artist = document.getElementById('edit-artist').value.trim() || "Unknown Artist"; 
  const tune = document.getElementById('edit-tune').value.trim() || "C"; const style = document.getElementById('edit-style').value.trim() || "Rock"; const signature = document.getElementById('edit-signature').value.trim() || "4/4";
  const duration = document.getElementById('edit-duration').value.trim() || "3:30"; const lyrics = document.getElementById('edit-lyrics').value;
  if (!title || !lyrics) { alert("Provide Title and Lyrics!"); return; }
  
  if (id) {
    let index = songbook.findIndex(s => s.id == id); if (index !== -1) songbook[index] = { ...songbook[index], title, artist, tune, style, signature, duration, lyrics };
  } else {
    const newId = songbook.length ? Math.max(...songbook.map(s => s.id)) + 1 : 1;
    songbook.push({ id: newId, title, artist, tune, style, signature, duration, lyrics, favorite: false, saved_bpm: "120" }); currentSongId = newId;
  }
  commitDatabaseMutation(); autoSyncDatabaseViews(); loadSong(currentSongId); togglePanel('editor-panel');
}

function deleteActiveSong() {
  const id = document.getElementById('edit-id').value; if (!id) return;
  const songIndex = songbook.findIndex(s => s.id == id); if (songIndex === -1) return;
  if (!confirm(`Delete "${songbook[songIndex].title}"?`)) return;
  songbook.splice(songIndex, 1); if (songbook.length === 0) { songbook = [{ id: 1, title: "Empty", artist: "Live Book", lyrics: "Create sheets.", favorite: false }]; }
  currentSongId = songbook[Math.max(0, songIndex - 1)].id; commitDatabaseMutation(); autoSyncDatabaseViews(); loadSong(currentSongId); togglePanel('editor-panel');
}

function wipeEntireLibraryEngine() {
  if (!confirm("🚨 Reset database to default tracking?")) return;
  localStorage.removeItem('songbook_pro_db'); localStorage.removeItem('songbook_pro_active_id');
  initLocalStorageEngine(); autoSyncDatabaseViews(); loadSong(songbook[0].id); togglePanel('io-panel');
}

function generateExportContent(format) {
  activeExportFormat = format; let previewArea = document.getElementById('export-preview'); let generatedData = "";
  if (format === 'html') {
    const dynamicPayload = `/*SONGBOOK_START*/\nwindow.IMPORTED_SONGBOOK = ${JSON.stringify(songbook)};\n/*SONGBOOK_END*/`;
    generatedData = `<!DOCTYPE html>\n<html>\n<head><title>Songbook Data</title></head>\n<body>\n<script>\n${dynamicPayload}\nalert("Backup complete!");\n<\/script>\n</body>\n</html>`;
  } else if (format === 'json') { generatedData = JSON.stringify(songbook, null, 2); }
  else { songbook.forEach(s => { generatedData += `========================================\n${s.title.toUpperCase()} - ${s.artist.toUpperCase()}\nKey: ${s.tune} | Genre: ${s.style} | Duration: ${s.duration}\n========================================\n\n${s.lyrics}\n\n\n`; }); }
  previewArea.value = generatedData;
}

function copyPreviewToClipboard() {
  const previewArea = document.getElementById('export-preview'); if (!previewArea.value) { alert("Tap a format first!"); return; }
  previewArea.select(); previewArea.setSelectionRange(0, 99999); navigator.clipboard.writeText(previewArea.value).then(() => alert("Copied!"));
}

function downloadPreviewAsFile() {
  const previewArea = document.getElementById('export-preview'); if (!previewArea.value) { alert("Select format engine first!"); return; }
  let mimeType = activeExportFormat === 'html' ? 'text/html' : activeExportFormat === 'json' ? 'application/json' : 'text/plain';
  const blob = new Blob([previewArea.value], { type: mimeType }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
  a.download = `songbook-backup.${activeExportFormat}`; document.body.appendChild(a); a.click(); document.body.removeChild(a);
}

function handleSongDragStart(e) { this.classList.add('dragging'); dragSourceElement = this; e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', this.getAttribute('data-id')); }
function handleSongDragOver(e) { if (e.preventDefault) e.preventDefault(); return false; }
function handleSongDrop(e) { e.preventDefault(); if (dragSourceElement !== this) { reorderSetlistArray(parseInt(e.dataTransfer.getData('text/plain')), parseInt(this.getAttribute('data-id'))); } }
function handleSongDragEnd() { this.classList.remove('dragging'); }
function handleTouchStart(e) { if (!e.target.classList.contains('drag-handle')) return; touchStartTarget = this; initialTouchY = e.touches[0].clientY; this.classList.add('dragging'); }
function handleTouchMove(e) {
  if (!touchStartTarget) return; e.preventDefault(); const currentY = e.touches[0].clientY; const elementOver = document.elementFromPoint(e.touches[0].clientX, currentY); const targetLi = elementOver ? elementOver.closest('.song-item') : null;
  if (targetLi && targetLi !== touchStartTarget && targetLi.parentNode === touchStartTarget.parentNode) { const container = touchStartTarget.parentNode; const nextNode = (currentY < initialTouchY) ? targetLi : targetLi.nextSibling; container.insertBefore(touchStartTarget, nextNode); initialTouchY = currentY; }
}
function handleTouchEnd() {
  if (!touchStartTarget) return; touchStartTarget.classList.remove('dragging'); const updatedIdsOrder = Array.from(document.querySelectorAll('#song-list .song-item')).map(li => parseInt(li.getAttribute('data-id')));
  let temporaryList = []; updatedIdsOrder.forEach(id => { const song = songbook.find(s => s.id === id); if(song) temporaryList.push(song); });
  songbook.forEach(song => { if(!temporaryList.find(t => t.id === song.id)) temporaryList.push(song); }); songbook = temporaryList; commitDatabaseMutation(); buildHorizontalIndex(); touchStartTarget = null;
}

function importSongbook(event) {
  const fileTarget = event.target.files[0]; if (!fileTarget) return;
  const reader = new FileReader(); reader.onload = function(e) {
    const fileContent = e.target.result;
    try {
      if (fileContent.includes('window.IMPORTED_SONGBOOK')) {
        const blockStart = fileContent.indexOf('window.IMPORTED_SONGBOOK = ') + 'window.IMPORTED_SONGBOOK = '.length;
        const blockEnd = fileContent.indexOf(';\n/*SONGBOOK_END*/');
        const parsedArray = JSON.parse(fileContent.substring(blockStart, blockEnd));
        if (Array.isArray(parsedArray) && parsedArray.length > 0) { songbook = parsedArray; currentSongId = songbook[0].id; updateAppAfterImport(); return; }
      }
      if (fileTarget.name.endsWith('.json')) {
        const parsed = JSON.parse(fileContent);
        if (Array.isArray(parsed) && parsed.length > 0) { songbook = parsed; currentSongId = songbook[0].id; updateAppAfterImport(); return; }
      }
      const derivedTitle = fileTarget.name.replace(/\.[^/.]+$/, "").replace(/[_-]/g, " ");
      const newId = songbook.length ? Math.max(...songbook.map(s => s.id)) + 1 : 1;
      songbook.push({ id: newId, title: derivedTitle.charAt(0).toUpperCase() + derivedTitle.slice(1), artist: "Universal Ingest", tune: "C", style: "Rock", signature: "4/4", duration: "3:30", lyrics: fileContent.trim(), favorite: false, saved_bpm: "120" });
      currentSongId = newId; updateAppAfterImport();
    } catch {
      const finalFallbackId = songbook.length ? Math.max(...songbook.map(s => s.id)) + 1 : 1;
      songbook.push({ id: finalFallbackId, title: fileTarget.name.replace(/\.[^/.]+$/, ""), artist: "Fallback Doc", tune: "C", style: "Text", signature: "4/4", duration: "3:30", lyrics: fileContent, favorite: false, saved_bpm: "120" });
      currentSongId = finalFallbackId; updateAppAfterImport();
    }
  }; reader.readAsText(fileTarget);
}
function updateAppAfterImport() { commitDatabaseMutation(); autoSyncDatabaseViews(); loadSong(currentSongId); togglePanel('io-panel'); alert("Database synced successfully!"); }