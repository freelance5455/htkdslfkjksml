FocusLock - APP created by jash ghoria

Open index.html in any browser (or host it and "Add to Home screen").
Includes: Focus lock (demo), Calendar with festivals/holidays, PDF library.

NOTE: a web page cannot block real apps on your phone. To truly block apps:
build an Android app (Kotlin) with UsageStatsManager + an Accessibility Service
or Device Policy, and show a full-screen overlay when a blocked app opens.
You can wrap this UI with Capacitor and call that native code from it.
