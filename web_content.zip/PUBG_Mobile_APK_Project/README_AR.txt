مشروع تحويل لعبة PUBG التجريبية إلى تطبيق Android APK

طريقة البناء:
1) نزّل Android Studio على كمبيوتر.
2) افتح مجلد PUBG_Mobile_APK_Project عبر Android Studio.
3) انتظر Gradle Sync، وثبّت Android SDK Platform 35 إذا طلبه.
4) اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
5) ستجد APK في app/build/outputs/apk/debug/app-debug.apk

ملاحظة:
هذا مشروع تغليف WebView للعبة HTML الحالية. لا يحتوي على خوادم أونلاين حقيقية أو ملفات لعبة PUBG الأصلية.
