const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

canvas.width = 960;
canvas.height = 540;

ctx.imageSmoothingEnabled = false;


// ======================================
// CONFIGURACIÓN
// ======================================

const TILE_SIZE = 40;

const WORLD_WIDTH = 120;
const WORLD_HEIGHT = 50;

const WORLD_PIXEL_WIDTH = WORLD_WIDTH * TILE_SIZE;
const WORLD_PIXEL_HEIGHT = WORLD_HEIGHT * TILE_SIZE;


// ======================================
// BLOQUES
// ======================================

const BLOCK = {
    AIR: 0,
    GRASS: 1,
    DIRT: 2,
    STONE: 3,
    BEDROCK: 4,
    WOOD: 5,
    LEAVES: 6
};


// ======================================
// TEXTURAS
// ======================================

const textures = {};

function loadTexture(name, path) {

    const img = new Image();

    img.src = path;

    textures[name] = img;

}


// BLOQUES

loadTexture("grass", "textures/grass.png");
loadTexture("dirt", "textures/dirt.png");
loadTexture("stone", "textures/stone.png");
loadTexture("bedrock", "textures/bedrock.png");
// Estas dos texturas las agregarás en la carpeta textures/.
loadTexture("wood", "textures/wood.png");
loadTexture("leaves", "textures/leaves.png");

// JUGADOR

loadTexture("player", "textures/player.png");

// FONDO

loadTexture("background", "textures/background.png");
loadTexture("clouds", "textures/clouds.png");
loadTexture("sun", "textures/sun.png");

// INTERFAZ: INVENTARIO COMPLETO, VIDA Y HAMBRE
loadTexture("ui_slot", "textures/UI/casilla.png");
loadTexture("ui_selected", "textures/UI/item_selected.png");
loadTexture("ui_heart", "textures/UI/heart.png");
loadTexture("ui_heart_half", "textures/UI/heart_medium.png");
loadTexture("ui_heart_empty", "textures/UI/heart_empty.png");
loadTexture("ui_food", "textures/UI/food.png");
loadTexture("ui_food_half", "textures/UI/food_medium.png");
loadTexture("ui_food_empty", "textures/UI/food_empity.png");
loadTexture("ui_pause", "textures/UI/pause_button.png");
loadTexture("ui_inventory", "textures/UI/inventory.png");


// ======================================
// GENERACIÓN DEL MUNDO
// ======================================

const world = [];
const surfaceHeights = [];

for (let y = 0; y < WORLD_HEIGHT; y++) {

    world[y] = [];

    for (let x = 0; x < WORLD_WIDTH; x++) {
        world[y][x] = BLOCK.AIR;
    }

}


function generateWorld() {

    for (let x = 0; x < WORLD_WIDTH; x++) {

        let surface = Math.floor(
            21 +
            Math.sin(x * 0.12) * 2 +
            Math.sin(x * 0.035) * 3
        );

        surface = Math.max(
            16,
            Math.min(27, surface)
        );

        surfaceHeights[x] = surface;

        for (let y = surface; y < WORLD_HEIGHT; y++) {

            if (y === WORLD_HEIGHT - 1) {

                world[y][x] = BLOCK.BEDROCK;

            } else if (y === surface) {

                world[y][x] = BLOCK.GRASS;

            } else if (y < surface + 4) {

                world[y][x] = BLOCK.DIRT;

            } else {

                world[y][x] = BLOCK.STONE;

            }

        }

    }

}

generateWorld();


// ======================================
// ÁRBOLES DE SUPERFICIE
// ======================================

function generateTrees() {
    // Posiciones deterministas: el mundo conserva los mismos árboles
    // cada vez que se inicia la página.
    let treeX = 11;

    while (treeX < WORLD_WIDTH - 4) {
        const value = Math.abs(Math.sin(treeX * 12.9898 + 78.233) * 43758.5453);
        const variation = value - Math.floor(value);
        const trunkHeight = 3 + Math.floor(variation * 2);
        const groundY = surfaceHeights[treeX];

        // Dejamos libre la zona inicial del jugador.
        if (treeX > 8 && world[groundY - 1][treeX] === BLOCK.AIR) {
            // Tronco: crece desde la superficie hacia arriba.
            for (let i = 1; i <= trunkHeight; i++) {
                const y = groundY - i;
                if (y >= 0) world[y][treeX] = BLOCK.WOOD;
            }

            // Copa compacta. El centro queda libre donde pasa el tronco.
            const crownY = groundY - trunkHeight;
            const leafRows = [
                { offset: -2, columns: [0] },
                { offset: -1, columns: [-1, 0, 1] },
                { offset: 0, columns: [-2, -1, 1, 2] },
                { offset: 1, columns: [-1, 1] }
            ];

            for (const row of leafRows) {
                for (const dx of row.columns) {
                    const x = treeX + dx;
                    const y = crownY + row.offset;

                    if (
                        x >= 0 && x < WORLD_WIDTH &&
                        y >= 0 && y < WORLD_HEIGHT &&
                        world[y][x] === BLOCK.AIR
                    ) {
                        world[y][x] = BLOCK.LEAVES;
                    }
                }
            }
        }

        treeX += 10 + Math.floor(variation * 7);
    }
}

generateTrees();


// ======================================
// JUGADOR
// ======================================

const player = {

    x: 120,
    y: 0,

    width: 30,
    height: 55,

    vx: 0,
    vy: 0,

    speed: 4,

    gravity: 0.65,

    jumpPower: -12,

    onGround: false,

    // 20 puntos equivalen a 10 corazones y 10 iconos de hambre.
    health: 20,
    maxHealth: 20,
    hunger: 20,
    maxHunger: 20,

    fallStartY: null

};


// POSICIÓN INICIAL

const spawnColumn = Math.floor(player.x / TILE_SIZE);

player.y =
    surfaceHeights[spawnColumn] * TILE_SIZE
    - player.height;


// ======================================
// CÁMARA
// ======================================

const camera = {
    x: 0,
    y: 0
};


// ======================================
// INVENTARIO COMPLETO (27 + 9 CASILLAS)
// ======================================

const HOTBAR_SLOTS = 9;
const MAIN_INVENTORY_SLOTS = 27;
const INVENTORY_TOTAL_SLOTS = HOTBAR_SLOTS + MAIN_INVENTORY_SLOTS;
const HOTBAR_SLOT_WIDTH = 34;
const HOTBAR_SLOT_HEIGHT = 38;
const HOTBAR_GAP = 3;
const HOTBAR_BOTTOM = 10;
const MAX_STACK_SIZE = 64;

// Los índices 0-8 son la barra rápida. Los índices 9-35 son las 27
// casillas principales del inventario.
const inventory = Array.from(
    { length: INVENTORY_TOTAL_SLOTS },
    () => ({ id: BLOCK.AIR, count: 0 })
);

let selectedSlot = 0;
let inventoryOpen = false;
let cursorStack = null;
let inventoryPanelRect = null;
let inventoryPointer = { x: -1, y: -1 };
const statusElement = document.getElementById("status");
const inventoryButton = document.getElementById("inventory-button");
const gameScreen = document.getElementById("game-screen");

const BLOCK_NAMES = {
    [BLOCK.GRASS]: "Césped",
    [BLOCK.DIRT]: "Tierra",
    [BLOCK.STONE]: "Piedra",
    [BLOCK.BEDROCK]: "Roca madre",
    [BLOCK.WOOD]: "Madera",
    [BLOCK.LEAVES]: "Hojas"
};

function setStatus(message) {
    if (statusElement) statusElement.textContent = message;
}

function clearSlot(slot) {
    slot.id = BLOCK.AIR;
    slot.count = 0;
}

function addBlockToInventory(blockId) {
    // Primero llena cualquier montón existente del mismo bloque.
    for (const slot of inventory) {
        if (slot.id === blockId && slot.count > 0 && slot.count < MAX_STACK_SIZE) {
            slot.count++;
            return true;
        }
    }

    // Después ocupa una casilla vacía, comenzando por la barra rápida.
    for (const slot of inventory) {
        if (slot.count === 0) {
            slot.id = blockId;
            slot.count = 1;
            return true;
        }
    }
    return false;
}

function storeStack(stack) {
    if (!stack || stack.count <= 0) return 0;
    let remaining = stack.count;

    for (const slot of inventory) {
        if (slot.id === stack.id && slot.count > 0 && slot.count < MAX_STACK_SIZE) {
            const moved = Math.min(MAX_STACK_SIZE - slot.count, remaining);
            slot.count += moved;
            remaining -= moved;
            if (remaining <= 0) return 0;
        }
    }

    for (const slot of inventory) {
        if (slot.count === 0) {
            const moved = Math.min(MAX_STACK_SIZE, remaining);
            slot.id = stack.id;
            slot.count = moved;
            remaining -= moved;
            if (remaining <= 0) return 0;
        }
    }
    return remaining;
}

function selectHotbarSlot(index) {
    if (index < 0 || index >= HOTBAR_SLOTS) return;
    selectedSlot = index;
    const slot = inventory[selectedSlot];
    if (slot.count > 0) {
        setStatus(`${BLOCK_NAMES[slot.id] || "Bloque"} ×${slot.count} seleccionado`);
    } else {
        setStatus(`Casilla ${selectedSlot + 1} vacía`);
    }
}

function getHotbarLayout() {
    const totalWidth = HOTBAR_SLOTS * HOTBAR_SLOT_WIDTH + (HOTBAR_SLOTS - 1) * HOTBAR_GAP;
    return {
        x: (canvas.width - totalWidth) / 2,
        y: canvas.height - HOTBAR_SLOT_HEIGHT - HOTBAR_BOTTOM,
        totalWidth
    };
}

function getHotbarSlotAt(position) {
    const layout = getHotbarLayout();
    if (position.y < layout.y || position.y > layout.y + HOTBAR_SLOT_HEIGHT) return -1;

    for (let i = 0; i < HOTBAR_SLOTS; i++) {
        const left = layout.x + i * (HOTBAR_SLOT_WIDTH + HOTBAR_GAP);
        if (position.x >= left && position.x <= left + HOTBAR_SLOT_WIDTH) return i;
    }
    return -1;
}

function isHotbarTouchArea(position) {
    const layout = getHotbarLayout();
    return position.x >= layout.x - 2 &&
        position.x <= layout.x + layout.totalWidth + 2 &&
        position.y >= layout.y - 2 &&
        position.y <= layout.y + HOTBAR_SLOT_HEIGHT + 2;
}

function getInventoryPanelRect() {
    const panelWidth = 1052;
    const panelHeight = 992;
    const scale = Math.min(0.60, (canvas.width - 20) / panelWidth, (canvas.height - 16) / panelHeight);
    const width = panelWidth * scale;
    const height = panelHeight * scale;
    return { x: (canvas.width - width) / 2, y: (canvas.height - height) / 2, width, height, scale };
}

function toggleInventory(forceState) {
    const nextState = typeof forceState === "boolean" ? forceState : !inventoryOpen;
    if (nextState === inventoryOpen) return;

    if (nextState) {
        stopMining();
        keys.clear();
        inventoryOpen = true;
        setStatus("Inventario abierto · toca una casilla para mover objetos");
    } else {
        // Si había un montón en el cursor, lo devuelve antes de cerrar.
        if (cursorStack && cursorStack.count > 0) {
            const remaining = storeStack(cursorStack);
            if (remaining > 0) {
                setStatus("No hay espacio para devolver ese montón.");
                return;
            }
            cursorStack = null;
        }
        inventoryOpen = false;
        setStatus("Inventario cerrado");
    }

    if (gameScreen) gameScreen.classList.toggle("inventory-open", inventoryOpen);
    if (inventoryButton) {
        inventoryButton.textContent = inventoryOpen ? "×" : "INV";
        inventoryButton.setAttribute("aria-label", inventoryOpen ? "Cerrar inventario" : "Abrir inventario");
        inventoryButton.setAttribute("aria-expanded", String(inventoryOpen));
    }
}

function getInventorySlotAt(position) {
    const rect = inventoryPanelRect || getInventoryPanelRect();
    const localX = (position.x - rect.x) / rect.scale;
    const localY = (position.y - rect.y) / rect.scale;
    const gridX = 40; // La imagen se recortó desde el píxel 3 del original.
    if (localX < gridX || localX >= gridX + 9 * 108) return -1;

    const column = Math.floor((localX - gridX) / 108);
    if (column < 0 || column >= 9) return -1;

    // Tres filas principales (27 casillas).
    const mainGridY = 496;
    if (localY >= mainGridY && localY < mainGridY + 3 * 108) {
        const row = Math.floor((localY - mainGridY) / 108);
        return HOTBAR_SLOTS + row * 9 + column;
    }

    // Fila inferior: barra rápida (9 casillas).
    if (localY >= 844 && localY < 844 + 108) return column;
    return -1;
}

function isInsideInventoryPanel(position) {
    const rect = inventoryPanelRect || getInventoryPanelRect();
    return position.x >= rect.x && position.x <= rect.x + rect.width &&
        position.y >= rect.y && position.y <= rect.y + rect.height;
}

function handleInventoryTap(position) {
    inventoryPointer = { x: position.x, y: position.y };
    const index = getInventorySlotAt(position);

    // Tocar fuera del panel cierra la interfaz. Los espacios de equipamiento
    // y fabricación quedan reservados sin cerrar accidentalmente el menú.
    if (index < 0) {
        if (!isInsideInventoryPanel(position)) toggleInventory(false);
        return;
    }

    const slot = inventory[index];
    if (!cursorStack) {
        if (slot.count <= 0) return;
        cursorStack = { id: slot.id, count: slot.count, originIndex: index };
        clearSlot(slot);
        setStatus(`${BLOCK_NAMES[cursorStack.id] || "Objeto"} ×${cursorStack.count} en el cursor`);
        return;
    }

    if (slot.count === 0) {
        slot.id = cursorStack.id;
        slot.count = cursorStack.count;
        cursorStack = null;
        setStatus("Objeto colocado");
        return;
    }

    if (slot.id === cursorStack.id && slot.count < MAX_STACK_SIZE) {
        const moved = Math.min(MAX_STACK_SIZE - slot.count, cursorStack.count);
        slot.count += moved;
        cursorStack.count -= moved;
        if (cursorStack.count <= 0) cursorStack = null;
        setStatus("Montones combinados");
        return;
    }

    // Si son objetos distintos (o el montón está lleno), intercambia las casillas.
    const oldStack = { id: slot.id, count: slot.count, originIndex: index };
    slot.id = cursorStack.id;
    slot.count = cursorStack.count;
    cursorStack = oldStack;
    setStatus("Objetos intercambiados");
}

if (inventoryButton) {
    inventoryButton.addEventListener("click", function() { toggleInventory(); });
}

// ======================================
// CONTROLES
// ======================================

const keys = new Set();

let jumpBufferTimer = 0;
const JUMP_BUFFER_DURATION = 0.18;

// ======================================
// RUPTURA DE BLOQUES
// ======================================

const mining = {
    active: false,
    pointerDown: false,
    pointerId: null,
    pointerScreenX: -1,
    pointerScreenY: -1,
    x: -1,
    y: -1,
    progress: 0,
    duration: 0
};

const BREAK_TIME = {
    [BLOCK.GRASS]: 0.45,
    [BLOCK.DIRT]: 0.35,
    [BLOCK.STONE]: 1.25,
    [BLOCK.WOOD]: 0.65,
    [BLOCK.LEAVES]: 0.22
};

const MINING_REACH = TILE_SIZE * 5;
let lastFrameTime = 0;

function getCanvasPosition(event) {
    const rect = canvas.getBoundingClientRect();
    return {
        x: (event.clientX - rect.left) * (canvas.width / rect.width),
        y: (event.clientY - rect.top) * (canvas.height / rect.height)
    };
}

function getTargetTile(event) {
    const pos = getCanvasPosition(event);
    const worldX = pos.x + camera.x;
    const worldY = pos.y + camera.y;
    const tileX = Math.floor(worldX / TILE_SIZE);
    const tileY = Math.floor(worldY / TILE_SIZE);

    if (tileX < 0 || tileX >= WORLD_WIDTH || tileY < 0 || tileY >= WORLD_HEIGHT) {
        return null;
    }

    const playerCenterX = player.x + player.width / 2;
    const playerCenterY = player.y + player.height / 2;
    const tileCenterX = tileX * TILE_SIZE + TILE_SIZE / 2;
    const tileCenterY = tileY * TILE_SIZE + TILE_SIZE / 2;
    const distance = Math.hypot(
        tileCenterX - playerCenterX,
        tileCenterY - playerCenterY
    );

    if (distance > MINING_REACH) {
        return null;
    }

    return {
        x: tileX,
        y: tileY,
        id: world[tileY][tileX]
    };
}

function hasAdjacentSolidBlock(tileX, tileY) {
    const neighbors = [
        [tileX - 1, tileY],
        [tileX + 1, tileY],
        [tileX, tileY - 1],
        [tileX, tileY + 1]
    ];

    return neighbors.some(([x, y]) => {
        if (x < 0 || x >= WORLD_WIDTH || y < 0 || y >= WORLD_HEIGHT) {
            return false;
        }

        return world[y][x] !== BLOCK.AIR;
    });
}

function tileOverlapsPlayer(tileX, tileY) {
    const tileLeft = tileX * TILE_SIZE;
    const tileTop = tileY * TILE_SIZE;
    const tileRight = tileLeft + TILE_SIZE;
    const tileBottom = tileTop + TILE_SIZE;

    const playerLeft = player.x;
    const playerTop = player.y;
    const playerRight = player.x + player.width;
    const playerBottom = player.y + player.height;

    return (
        tileLeft < playerRight &&
        tileRight > playerLeft &&
        tileTop < playerBottom &&
        tileBottom > playerTop
    );
}

function placeSelectedBlock(target) {
    const slot = inventory[selectedSlot];

    if (!slot || slot.count <= 0 || slot.id === BLOCK.AIR) {
        setStatus("Selecciona un bloque en la barra para colocarlo.");
        return false;
    }

    if (target.id !== BLOCK.AIR) {
        return false;
    }

    if (!hasAdjacentSolidBlock(target.x, target.y)) {
        setStatus("Coloca el bloque junto a otro bloque.");
        return false;
    }

    if (tileOverlapsPlayer(target.x, target.y)) {
        setStatus("No puedes colocar un bloque dentro del jugador.");
        return false;
    }

    const placedBlock = slot.id;
    world[target.y][target.x] = placedBlock;

    slot.count--;
    if (slot.count <= 0) {
        slot.id = BLOCK.AIR;
        slot.count = 0;
    }

    const name = BLOCK_NAMES[placedBlock] || "Bloque";
    setStatus(
        slot.count > 0
            ? `${name} colocado · quedan ${slot.count}`
            : `${name} colocado · casilla vacía`
    );

    return true;
}

function beginMiningTarget(target) {
    if (!target || target.id === BLOCK.AIR) {
        mining.active = false;
        mining.x = -1;
        mining.y = -1;
        mining.progress = 0;
        mining.duration = 0;
        return;
    }

    if (target.id === BLOCK.BEDROCK) {
        mining.active = false;
        mining.x = -1;
        mining.y = -1;
        mining.progress = 0;
        mining.duration = 0;
        setStatus("La roca madre no se puede romper.");
        return;
    }

    // No reinicia el progreso mientras el dedo siga sobre el mismo bloque.
    if (mining.active && mining.x === target.x && mining.y === target.y) {
        return;
    }

    mining.active = true;
    mining.x = target.x;
    mining.y = target.y;
    mining.progress = 0;
    mining.duration = BREAK_TIME[target.id] || 0.5;
}

function startMining(event) {
    if (event.button !== undefined && event.button !== 0) return;

    const pointerPosition = getCanvasPosition(event);
    if (inventoryOpen) {
        handleInventoryTap(pointerPosition);
        event.preventDefault();
        return;
    }
    mining.pointerScreenX = pointerPosition.x;
    mining.pointerScreenY = pointerPosition.y;

    // La barra rápida está dibujada dentro del canvas.
    if (isHotbarTouchArea(pointerPosition)) {
        stopMining();
        const slotIndex = getHotbarSlotAt(pointerPosition);
        if (slotIndex !== -1) {
            selectHotbarSlot(slotIndex);
        }
        event.preventDefault();
        return;
    }

    const target = getTargetTile(event);
    if (!target) {
        stopMining();
        return;
    }

    // Tocar un espacio vacío coloca un bloque; arrastrar sobre espacios
    // vacíos no coloca bloques accidentalmente.
    if (target.id === BLOCK.AIR) {
        stopMining();
        placeSelectedBlock(target);
        event.preventDefault();
        return;
    }

    mining.pointerDown = true;
    mining.pointerId = event.pointerId;
    canvas.setPointerCapture?.(event.pointerId);
    beginMiningTarget(target);
    event.preventDefault();
}

function moveMiningPointer(event) {
    if (inventoryOpen) {
        inventoryPointer = getCanvasPosition(event);
        return;
    }
    if (!mining.pointerDown || event.pointerId !== mining.pointerId) return;

    const pointerPosition = getCanvasPosition(event);
    mining.pointerScreenX = pointerPosition.x;
    mining.pointerScreenY = pointerPosition.y;

    const target = getTargetTile(event);
    if (!target || target.id === BLOCK.AIR) {
        mining.active = false;
        mining.x = -1;
        mining.y = -1;
        mining.progress = 0;
        mining.duration = 0;
        return;
    }

    beginMiningTarget(target);
    event.preventDefault();
}

function stopMining() {
    mining.active = false;
    mining.pointerDown = false;
    mining.pointerId = null;
    mining.pointerScreenX = -1;
    mining.pointerScreenY = -1;
    mining.x = -1;
    mining.y = -1;
    mining.progress = 0;
    mining.duration = 0;
}

function updateMining(deltaTime) {
    if (!mining.active) return;

    const id = world[mining.y]?.[mining.x];
    if (id === undefined || id === BLOCK.AIR || id === BLOCK.BEDROCK) {
        mining.active = false;
        mining.x = -1;
        mining.y = -1;
        mining.progress = 0;
        mining.duration = 0;
        return;
    }

    mining.progress += deltaTime;

    if (mining.progress >= mining.duration) {
        const collectedBlock = id;

        // Las hojas se destruyen, pero no generan objetos ni ocupan inventario.
        if (
            collectedBlock !== BLOCK.LEAVES &&
            !addBlockToInventory(collectedBlock)
        ) {
            setStatus("¡Inventario lleno! Selecciona otra casilla o libera espacio.");
            stopMining();
            return;
        }

        world[mining.y][mining.x] = BLOCK.AIR;
        const name = BLOCK_NAMES[collectedBlock] || "Bloque";

        if (collectedBlock === BLOCK.LEAVES) {
            setStatus("Hojas eliminadas · no se recogen.");
        } else {
            const selectedItem = inventory[selectedSlot];
            setStatus(`${name} recogido · ${selectedItem.count > 0 && selectedItem.id === collectedBlock ? `tienes ${selectedItem.count}` : "guardado en el inventario"}`);
        }

        // Conserva el dedo pulsado. Al moverlo al siguiente bloque,
        // la minería continúa sin tener que levantarlo y tocar otra vez.
        mining.active = false;
        mining.x = -1;
        mining.y = -1;
        mining.progress = 0;
        mining.duration = 0;
    }
}

canvas.addEventListener("pointerdown", startMining);
canvas.addEventListener("pointermove", moveMiningPointer);
window.addEventListener("pointerup", function(event) {
    if (mining.pointerDown && event.pointerId === mining.pointerId) stopMining();
});
window.addEventListener("pointercancel", function(event) {
    if (mining.pointerDown && event.pointerId === mining.pointerId) stopMining();
});
window.addEventListener("blur", stopMining);

function drawMiningOverlay() {
    if (!mining.active) return;

    const x = mining.x * TILE_SIZE - camera.x;
    const y = mining.y * TILE_SIZE - camera.y;
    const ratio = Math.min(1, mining.progress / mining.duration);
    const stage = Math.floor(ratio * 5);

    // Oscurecimiento progresivo del bloque.
    ctx.fillStyle = `rgba(0, 0, 0, ${0.12 + ratio * 0.22})`;
    ctx.fillRect(x, y, TILE_SIZE, TILE_SIZE);

    // Grietas visuales por etapas.
    if (stage >= 1) {
        ctx.strokeStyle = "rgba(20,20,20,0.9)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(x + 20, y + 5);
        ctx.lineTo(x + 16, y + 18);
        ctx.lineTo(x + 25, y + 23);
        ctx.lineTo(x + 18, y + 35);
        if (stage >= 2) {
            ctx.moveTo(x + 16, y + 18);
            ctx.lineTo(x + 7, y + 24);
        }
        if (stage >= 3) {
            ctx.moveTo(x + 25, y + 23);
            ctx.lineTo(x + 34, y + 15);
            ctx.lineTo(x + 36, y + 31);
        }
        if (stage >= 4) {
            ctx.moveTo(x + 18, y + 35);
            ctx.lineTo(x + 8, y + 38);
        }
        ctx.stroke();
    }

    ctx.strokeStyle = "rgba(255,255,255,0.9)";
    ctx.lineWidth = 2;
    ctx.strokeRect(x + 1, y + 1, TILE_SIZE - 2, TILE_SIZE - 2);
}


// ======================================
// LUPA DE MINERÍA (inspirada en Terraria)
// ======================================

const magnifier = {
    size: 116,
    zoom: 2.4,
    offsetX: 72,
    offsetY: -78,
    snapshot: document.createElement("canvas")
};

magnifier.snapshot.width = canvas.width;
magnifier.snapshot.height = canvas.height;

function drawMiningMagnifier() {
    if (!mining.pointerDown || mining.pointerScreenX < 0 || mining.pointerScreenY < 0) {
        return;
    }

    const size = magnifier.size;
    const radius = size / 2;
    const sourceSize = size / magnifier.zoom;
    const px = mining.pointerScreenX;
    const py = mining.pointerScreenY;

    // La lupa aparece desplazada para no quedar debajo del dedo.
    let centerX = px + magnifier.offsetX;
    let centerY = py + magnifier.offsetY;

    if (centerX + radius > canvas.width - 8) centerX = px - magnifier.offsetX;
    if (centerY - radius < 8) centerY = py + Math.abs(magnifier.offsetY);

    centerX = Math.max(radius + 6, Math.min(canvas.width - radius - 6, centerX));
    centerY = Math.max(radius + 6, Math.min(canvas.height - radius - 6, centerY));

    const sourceX = Math.max(0, Math.min(canvas.width - sourceSize, px - sourceSize / 2));
    const sourceY = Math.max(0, Math.min(canvas.height - sourceSize, py - sourceSize / 2));

    // Copia la escena ya dibujada antes de ampliarla, evitando dibujar el canvas sobre sí mismo.
    const snapshotCtx = magnifier.snapshot.getContext("2d");
    snapshotCtx.clearRect(0, 0, canvas.width, canvas.height);
    snapshotCtx.drawImage(canvas, 0, 0);

    ctx.save();
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
    ctx.clip();

    ctx.fillStyle = "#202020";
    ctx.fillRect(centerX - radius, centerY - radius, size, size);

    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(
        magnifier.snapshot,
        sourceX, sourceY, sourceSize, sourceSize,
        centerX - radius, centerY - radius, size, size
    );

    // Retícula central para identificar exactamente el punto bajo el dedo.
    ctx.strokeStyle = "rgba(255,255,255,0.9)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(centerX - 9, centerY);
    ctx.lineTo(centerX + 9, centerY);
    ctx.moveTo(centerX, centerY - 9);
    ctx.lineTo(centerX, centerY + 9);
    ctx.stroke();

    ctx.restore();

    // Borde exterior y pequeño brillo.
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius - 1, 0, Math.PI * 2);
    ctx.strokeStyle = "#202020";
    ctx.lineWidth = 7;
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(centerX, centerY, radius - 4, 0, Math.PI * 2);
    ctx.strokeStyle = "rgba(255,255,255,0.9)";
    ctx.lineWidth = 2;
    ctx.stroke();
}

window.addEventListener("keydown", function(e) {

    if (!e.repeat && (e.code === "KeyE" || e.code === "KeyI")) {
        e.preventDefault();
        toggleInventory();
        return;
    }

    if (inventoryOpen) {
        if (e.code === "Escape") {
            e.preventDefault();
            toggleInventory(false);
        }
        return;
    }

    const controls = [
        "ArrowLeft",
        "ArrowRight",
        "ArrowUp",
        "Space",
        "KeyA",
        "KeyD",
        "KeyW"
    ];

    if (controls.includes(e.code)) {
        e.preventDefault();
    }

    if (
        !e.repeat &&
        (
            e.code === "Space" ||
            e.code === "ArrowUp" ||
            e.code === "KeyW"
        )
    ) {
        jumpBufferTimer = JUMP_BUFFER_DURATION;
    }

    if (!e.repeat && /^Digit[1-9]$/.test(e.code)) {
        selectHotbarSlot(Number(e.code.slice(-1)) - 1);
    }

    keys.add(e.code);

});


window.addEventListener("keyup", function(e) {
    keys.delete(e.code);
});

window.addEventListener("blur", function() {
    keys.clear();
    jumpBufferTimer = 0;
    stopMining();
});


// ======================================
// CONTROLES TÁCTILES
// ======================================

const buttons = document.querySelectorAll(
    "#touch-controls button"
);

buttons.forEach(function(button) {

    const control = button.dataset.control;

    button.addEventListener("pointerdown", function(e) {

        e.preventDefault();

        button.setPointerCapture(e.pointerId);

        keys.add(control);

        if (control === "jump") {
            jumpBufferTimer = JUMP_BUFFER_DURATION;
        }

    });

    function release() {
        keys.delete(control);
    }

    button.addEventListener("pointerup", release);

    button.addEventListener("pointercancel", release);

    button.addEventListener("lostpointercapture", release);

});


// ======================================
// COLISIONES
// ======================================

function isSolid(x, y) {

    const tileX = Math.floor(x / TILE_SIZE);
    const tileY = Math.floor(y / TILE_SIZE);

    if (tileX < 0 || tileX >= WORLD_WIDTH) {
        return true;
    }

    if (tileY < 0) {
        return false;
    }

    if (tileY >= WORLD_HEIGHT) {
        return true;
    }

    // Solo el terreno bloquea el movimiento. Troncos y hojas son atravesables.
    const block = world[tileY][tileX];
    return (
        block === BLOCK.GRASS ||
        block === BLOCK.DIRT ||
        block === BLOCK.STONE ||
        block === BLOCK.BEDROCK
    );

}


function playerCollides(x, y) {

    const left = x + 1;
    const right = x + player.width - 1;

    const top = y + 1;
    const bottom = y + player.height - 1;

    return (
        isSolid(left, top) ||
        isSolid(right, top) ||
        isSolid(left, bottom) ||
        isSolid(right, bottom)
    );

}


// ======================================
// VIDA Y DAÑO
// ======================================

function damagePlayer(amount) {
    if (amount <= 0 || player.health <= 0) return;

    player.health = Math.max(0, player.health - amount);
    setStatus(`¡Cuidado! Perdiste ${amount} de vida.`);

    if (player.health === 0) {
        // Reaparición sencilla para esta primera versión.
        player.x = 120;
        const spawn = Math.floor(player.x / TILE_SIZE);
        player.y = surfaceHeights[spawn] * TILE_SIZE - player.height;
        player.vx = 0;
        player.vy = 0;
        player.onGround = false;
        player.fallStartY = null;
        player.health = player.maxHealth;
        player.hunger = player.maxHunger;
        setStatus("Has reaparecido con la vida y el hambre completas.");
    }
}


// ======================================
// ACTUALIZAR JUGADOR
// ======================================

function updatePlayer(deltaTime) {

    let direction = 0;

    if (
        keys.has("ArrowLeft") ||
        keys.has("KeyA") ||
        keys.has("left")
    ) {
        direction--;
    }

    if (
        keys.has("ArrowRight") ||
        keys.has("KeyD") ||
        keys.has("right")
    ) {
        direction++;
    }


    // MOVIMIENTO HORIZONTAL

    player.vx = direction * player.speed;

    const oldX = player.x;

    player.x += player.vx;

    if (playerCollides(player.x, player.y)) {
        player.x = oldX;
    }


    // SALTO CON BUFFER: si se pulsa justo antes de tocar el suelo,
    // el salto se ejecuta al aterrizar en lugar de perder la pulsación.
    if (jumpBufferTimer > 0 && player.onGround) {
        player.vy = player.jumpPower;
        player.onGround = false;
        player.fallStartY = null;
        jumpBufferTimer = 0;
    } else {
        jumpBufferTimer = Math.max(0, jumpBufferTimer - deltaTime);
    }


    // GRAVEDAD

    player.vy += player.gravity;

    if (player.vy > 15) {
        player.vy = 15;
    }


    // MOVIMIENTO VERTICAL

    if (player.vy > 0 && !player.onGround && player.fallStartY === null) {
        player.fallStartY = player.y;
    }

    player.y += player.vy;

    if (playerCollides(player.x, player.y)) {

        if (player.vy > 0) {

            const tileY = Math.floor(
                (player.y + player.height - 0.001) / TILE_SIZE
            );

            player.y =
                tileY * TILE_SIZE - player.height;

            const fallDistance = player.fallStartY === null
                ? 0
                : Math.max(0, player.y - player.fallStartY);

            // Caer más de cuatro bloques empieza a restar corazones.
            if (fallDistance > TILE_SIZE * 4) {
                const fallBlocks = Math.floor(fallDistance / TILE_SIZE);
                damagePlayer(Math.max(1, fallBlocks - 3));
            }

            player.fallStartY = null;
            player.onGround = true;

        }

        else if (player.vy < 0) {

            const tileY = Math.floor(
                player.y / TILE_SIZE
            );

            player.y =
                (tileY + 1) * TILE_SIZE;

            player.onGround = false;

        }

        player.vy = 0;

    } else {

        player.onGround = false;

    }

}


// ======================================
// INTERFAZ: CORAZONES, HAMBRE E INVENTARIO
// ======================================

function drawResourceIcons(current, max, fullTexture, halfTexture, emptyTexture, x, y) {
    const iconSize = 18;
    const gap = 3;
    const totalIcons = Math.ceil(max / 2);

    for (let i = 0; i < totalIcons; i++) {
        const points = current - i * 2;
        let textureName = emptyTexture;
        if (points >= 2) textureName = fullTexture;
        else if (points >= 1) textureName = halfTexture;

        const img = textures[textureName];
        const iconX = x + i * (iconSize + gap);
        if (img && img.complete && img.naturalWidth > 0) {
            ctx.drawImage(img, iconX, y, iconSize, iconSize);
        } else {
            ctx.fillStyle = textureName === fullTexture ? "#e53935" : "#555";
            ctx.fillRect(iconX + 3, y + 3, 12, 12);
        }
    }
}

function getItemTextureName(id) {
    if (id === BLOCK.GRASS) return "grass";
    if (id === BLOCK.DIRT) return "dirt";
    if (id === BLOCK.STONE) return "stone";
    if (id === BLOCK.WOOD) return "wood";
    if (id === BLOCK.LEAVES) return "leaves";
    return "";
}

function drawItemStack(slot, x, y, size, countFontSize) {
    if (!slot || slot.count <= 0 || slot.id === BLOCK.AIR) return;
    const textureName = getItemTextureName(slot.id);
    const img = textures[textureName];
    const inset = size * 0.14;
    if (img && img.complete && img.naturalWidth > 0) {
        ctx.drawImage(img, x + inset, y + inset, size - inset * 2, size - inset * 2);
    } else {
        ctx.fillStyle = "#888";
        ctx.fillRect(x + inset, y + inset, size - inset * 2, size - inset * 2);
    }

    if (slot.count > 1) {
        ctx.font = `bold ${countFontSize}px Arial`;
        ctx.textAlign = "right";
        ctx.textBaseline = "bottom";
        ctx.lineWidth = Math.max(2, countFontSize * 0.22);
        ctx.strokeStyle = "#111";
        ctx.strokeText(String(slot.count), x + size - 3, y + size - 2);
        ctx.fillStyle = "#fff";
        ctx.fillText(String(slot.count), x + size - 3, y + size - 2);
    }
}

function drawHotbar() {
    const layout = getHotbarLayout();
    const slotImage = textures.ui_slot;
    const selectedImage = textures.ui_selected;

    for (let i = 0; i < HOTBAR_SLOTS; i++) {
        const x = layout.x + i * (HOTBAR_SLOT_WIDTH + HOTBAR_GAP);
        const y = layout.y;
        const slot = inventory[i];

        if (slotImage && slotImage.complete && slotImage.naturalWidth > 0) {
            ctx.drawImage(slotImage, x, y, HOTBAR_SLOT_WIDTH, HOTBAR_SLOT_HEIGHT);
        } else {
            ctx.fillStyle = "#262626";
            ctx.fillRect(x, y, HOTBAR_SLOT_WIDTH, HOTBAR_SLOT_HEIGHT);
            ctx.strokeStyle = "#b9b9b9";
            ctx.strokeRect(x, y, HOTBAR_SLOT_WIDTH, HOTBAR_SLOT_HEIGHT);
        }

        if (i === selectedSlot && selectedImage && selectedImage.complete && selectedImage.naturalWidth > 0) {
            ctx.drawImage(selectedImage, x - 2, y + 1, HOTBAR_SLOT_WIDTH + 4, HOTBAR_SLOT_HEIGHT - 2);
        } else if (i === selectedSlot) {
            ctx.strokeStyle = "#fff";
            ctx.lineWidth = 3;
            ctx.strokeRect(x + 1, y + 1, HOTBAR_SLOT_WIDTH - 2, HOTBAR_SLOT_HEIGHT - 2);
        }

        drawItemStack(slot, x + 2, y + 2, HOTBAR_SLOT_WIDTH - 4, 12);
    }
}

function drawPlayerPreview(rect) {
    // Miniatura sencilla del jugador en el recuadro negro de la interfaz.
    const sc = rect.scale;
    ctx.save();
    ctx.translate(rect.x, rect.y);
    ctx.scale(sc, sc);
    const x = 270;
    const y = 190;
    ctx.fillStyle = "#d6a47b";
    ctx.fillRect(x + 15, y, 60, 63);
    ctx.fillStyle = "#2864a0";
    ctx.fillRect(x + 7, y + 63, 76, 63);
    ctx.fillStyle = "#303030";
    ctx.fillRect(x + 10, y + 126, 28, 57);
    ctx.fillRect(x + 52, y + 126, 28, 57);
    ctx.fillStyle = "#222";
    ctx.fillRect(x + 57, y + 20, 11, 11);
    ctx.restore();
}

function drawInventoryOverlay() {
    ctx.save();
    ctx.fillStyle = "rgba(0, 0, 0, 0.62)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const rect = getInventoryPanelRect();
    inventoryPanelRect = rect;
    const panel = textures.ui_inventory;

    if (panel && panel.complete && panel.naturalWidth > 0) {
        ctx.drawImage(panel, rect.x, rect.y, rect.width, rect.height);
    } else {
        ctx.fillStyle = "#c6c6c6";
        ctx.fillRect(rect.x, rect.y, rect.width, rect.height);
        ctx.strokeStyle = "#555";
        ctx.lineWidth = 4;
        ctx.strokeRect(rect.x, rect.y, rect.width, rect.height);
    }

    // 27 espacios principales: 3 filas de 9.
    for (let row = 0; row < 3; row++) {
        for (let col = 0; col < 9; col++) {
            const index = HOTBAR_SLOTS + row * 9 + col;
            const x = rect.x + (40 + col * 108 + 17) * rect.scale;
            const y = rect.y + (496 + row * 108 + 17) * rect.scale;
            drawItemStack(inventory[index], x, y, 76 * rect.scale, 19 * rect.scale);
        }
    }

    // Nueve espacios de la barra rápida, en la fila inferior del panel.
    for (let col = 0; col < 9; col++) {
        const x = rect.x + (40 + col * 108 + 17) * rect.scale;
        const y = rect.y + (844 + 17) * rect.scale;
        drawItemStack(inventory[col], x, y, 76 * rect.scale, 19 * rect.scale);

        if (col === selectedSlot) {
            ctx.strokeStyle = "#fff";
            ctx.lineWidth = Math.max(1, 3 * rect.scale);
            ctx.strokeRect(
                rect.x + (40 + col * 108 + 4) * rect.scale,
                rect.y + (844 + 4) * rect.scale,
                100 * rect.scale,
                100 * rect.scale
            );
        }
    }

    drawPlayerPreview(rect);

    // El montón tomado se muestra junto al último toque para facilitar el arrastre
    // por pasos en pantallas táctiles (tocar origen y luego destino).
    if (cursorStack && cursorStack.count > 0 && inventoryPointer.x >= 0) {
        drawItemStack(
            cursorStack,
            Math.min(canvas.width - 48, inventoryPointer.x + 8),
            Math.max(4, inventoryPointer.y - 42),
            38,
            12
        );
    }

    ctx.restore();
}

function drawHUD() {
    ctx.fillStyle = "rgba(0,0,0,0.18)";
    ctx.fillRect(10, 8, 220, 29);
    ctx.fillRect(canvas.width - 230, 8, 220, 29);

    drawResourceIcons(player.health, player.maxHealth, "ui_heart", "ui_heart_half", "ui_heart_empty", 17, 13);
    drawResourceIcons(player.hunger, player.maxHunger, "ui_food", "ui_food_half", "ui_food_empty", canvas.width - 17 - 10 * 21, 13);
    drawHotbar();
}

// ======================================
// FONDO
// ======================================

function drawBackground() {

    // CIELO

    const sky = ctx.createLinearGradient(
        0, 0,
        0, canvas.height
    );

    sky.addColorStop(0, "#65b9ed");
    sky.addColorStop(1, "#c4eaff");

    ctx.fillStyle = sky;

    ctx.fillRect(
        0,
        0,
        canvas.width,
        canvas.height
    );


    // TERRENO LEJANO

    const bg = textures.background;

    if (bg && bg.complete && bg.naturalWidth > 0) {

        const width = canvas.width;
        const height = 220;

        const offset = -(camera.x * 0.12 % width);

        ctx.drawImage(
            bg,
            offset,
            canvas.height - height,
            width,
            height
        );

        ctx.drawImage(
            bg,
            offset + width,
            canvas.height - height,
            width,
            height
        );

    } else {

        // MONTAÑAS PROVISIONALES

        ctx.fillStyle = "#9ac6d2";

        ctx.beginPath();

        ctx.moveTo(0, 360);

        for (let x = 0; x <= canvas.width; x += 80) {

            const y =
                330 + Math.sin((x + camera.x * 0.12) * 0.015) * 35;

            ctx.lineTo(x, y);

        }

        ctx.lineTo(canvas.width, canvas.height);
        ctx.lineTo(0, canvas.height);

        ctx.fill();

    }


    // NIEBLA AZULADA

    const fog = ctx.createLinearGradient(
        0,
        300,
        0,
        540
    );

    fog.addColorStop(
        0,
        "rgba(130,190,220,0)"
    );

    fog.addColorStop(
        1,
        "rgba(130,190,220,0.45)"
    );

    ctx.fillStyle = fog;

    ctx.fillRect(
        0,
        300,
        canvas.width,
        240
    );


    // SOL

    const sun = textures.sun;

    if (sun && sun.complete && sun.naturalWidth > 0) {

        ctx.drawImage(sun, 760, 55, 80, 80);

    } else {

        ctx.fillStyle = "#fff2a6";
        ctx.fillRect(760, 55, 64, 64);

    }


    // NUBES

    const clouds = textures.clouds;

    if (clouds && clouds.complete && clouds.naturalWidth > 0) {

        const offset = -(camera.x * 0.2 % 240);

        for (let x = offset - 240; x < 1200; x += 240) {

            ctx.drawImage(
                clouds,
                x,
                100,
                180,
                65
            );

        }

    } else {

        drawSquareCloud(150, 90);
        drawSquareCloud(480, 160);
        drawSquareCloud(850, 75);

    }

}


function drawSquareCloud(x, y) {

    ctx.fillStyle = "rgba(255,255,255,0.9)";

    ctx.fillRect(x + 20, y, 55, 20);
    ctx.fillRect(x, y + 20, 95, 20);
    ctx.fillRect(x + 15, y + 40, 65, 15);

}


// ======================================
// DIBUJAR BLOQUES
// ======================================

function getBlockTextureName(id) {
    if (id === BLOCK.GRASS) return "grass";
    if (id === BLOCK.DIRT) return "dirt";
    if (id === BLOCK.STONE) return "stone";
    if (id === BLOCK.BEDROCK) return "bedrock";
    if (id === BLOCK.WOOD) return "wood";
    if (id === BLOCK.LEAVES) return "leaves";
    return "";
}

function drawBlock(id, screenX, screenY, worldX, worldY) {
    const name = getBlockTextureName(id);
    const img = textures[name];

    if (img && img.complete && img.naturalWidth > 0) {
        ctx.drawImage(img, screenX, screenY, TILE_SIZE, TILE_SIZE);
        return;
    }

    // Colores provisionales hasta que estén listas las texturas.
    let color = "#777777";
    if (id === BLOCK.GRASS) color = "#65a83b";
    if (id === BLOCK.DIRT) color = "#87502d";
    if (id === BLOCK.STONE) color = "#777777";
    if (id === BLOCK.BEDROCK) color = "#292929";
    if (id === BLOCK.WOOD) color = "#8a572e";
    if (id === BLOCK.LEAVES) color = "#397b32";

    ctx.fillStyle = color;
    ctx.fillRect(screenX, screenY, TILE_SIZE, TILE_SIZE);

    if (id === BLOCK.GRASS) {
        ctx.fillStyle = "#397c2b";
        ctx.fillRect(screenX, screenY + 9, TILE_SIZE, 5);
    }

    if (id === BLOCK.WOOD) {
        ctx.fillStyle = "rgba(50,25,10,0.28)";
        ctx.fillRect(screenX + 9, screenY, 4, TILE_SIZE);
        ctx.fillRect(screenX + 27, screenY, 3, TILE_SIZE);
    }

    if (id === BLOCK.LEAVES) {
        ctx.fillStyle = "rgba(20,70,15,0.25)";
        ctx.fillRect(screenX + 5, screenY + 6, 8, 8);
        ctx.fillRect(screenX + 24, screenY + 23, 9, 8);
    }

    const seed = Math.abs((worldX * 17 + worldY * 31) % 9);
    ctx.fillStyle = "rgba(0,0,0,0.12)";
    ctx.fillRect(screenX + seed * 3, screenY + 17, 5, 5);
    ctx.strokeStyle = "rgba(0,0,0,0.12)";
    ctx.strokeRect(screenX, screenY, TILE_SIZE, TILE_SIZE);
}

function drawBackgroundWall(id, screenX, screenY, worldX, worldY) {
    const img = textures[getBlockTextureName(id)];

    if (img && img.complete && img.naturalWidth > 0) {
        ctx.drawImage(img, screenX, screenY, TILE_SIZE, TILE_SIZE);
    } else {
        // La pared usa el mismo aspecto del bloque, con una base oscura.
        drawBlock(id, screenX, screenY, worldX, worldY);
    }

    // Oscurecimiento uniforme para simular las paredes del subsuelo.
    ctx.fillStyle = "rgba(0,0,0,0.52)";
    ctx.fillRect(screenX, screenY, TILE_SIZE, TILE_SIZE);
}


// ======================================
// DIBUJAR MUNDO
// ======================================

function drawWorld() {
    const startX = Math.max(0, Math.floor(camera.x / TILE_SIZE));
    const startY = Math.max(0, Math.floor(camera.y / TILE_SIZE));
    const endX = Math.min(WORLD_WIDTH, Math.ceil((camera.x + canvas.width) / TILE_SIZE));
    const endY = Math.min(WORLD_HEIGHT, Math.ceil((camera.y + canvas.height) / TILE_SIZE));

    // PRIMERA PASADA: paredes oscuras detrás del terreno.
    // Cuando se rompe un bloque subterráneo, esta capa queda visible.
    for (let y = startY; y < endY; y++) {
        for (let x = startX; x < endX; x++) {
            if (y <= surfaceHeights[x]) continue;

            const id = world[y][x];
            let wallId;

            if (
                id === BLOCK.DIRT ||
                id === BLOCK.GRASS ||
                (id === BLOCK.AIR && y <= surfaceHeights[x] + 4)
            ) {
                wallId = BLOCK.DIRT;
            } else if (id === BLOCK.WOOD || id === BLOCK.LEAVES) {
                continue;
            } else {
                wallId = BLOCK.STONE;
            }

            // Los huecos excavados conservan una pared de fondo oscura.
            const screenX = x * TILE_SIZE - camera.x;
            const screenY = y * TILE_SIZE - camera.y;
            drawBackgroundWall(wallId, screenX, screenY, x, y);
        }
    }

    // SEGUNDA PASADA: bloques normales por delante de las paredes.
    for (let y = startY; y < endY; y++) {
        for (let x = startX; x < endX; x++) {
            const id = world[y][x];
            if (id === BLOCK.AIR) continue;

            const screenX = x * TILE_SIZE - camera.x;
            const screenY = y * TILE_SIZE - camera.y;
            drawBlock(id, screenX, screenY, x, y);
        }
    }
}

// ======================================
// DIBUJAR JUGADOR
// ======================================

function drawPlayer() {

    const x = player.x - camera.x;
    const y = player.y - camera.y;

    const img = textures.player;

    if (img && img.complete && img.naturalWidth > 0) {

        ctx.drawImage(
            img,
            x,
            y,
            player.width,
            player.height
        );

        return;

    }


    // JUGADOR PROVISIONAL

    ctx.fillStyle = "#d6a47b";

    ctx.fillRect(
        x + 5,
        y,
        20,
        21
    );

    ctx.fillStyle = "#2864a0";

    ctx.fillRect(
        x + 2,
        y + 21,
        26,
        21
    );

    ctx.fillStyle = "#303030";

    ctx.fillRect(
        x + 3,
        y + 42,
        10,
        13
    );

    ctx.fillRect(
        x + 17,
        y + 42,
        10,
        13
    );

    ctx.fillStyle = "#222";

    ctx.fillRect(
        x + 19,
        y + 7,
        4,
        4
    );

}


// ======================================
// CÁMARA
// ======================================

function updateCamera() {

    camera.x = Math.max(
        0,
        Math.min(
            player.x + player.width / 2 - canvas.width / 2,
            WORLD_PIXEL_WIDTH - canvas.width
        )
    );

    camera.y = Math.max(
        0,
        Math.min(
            player.y + player.height / 2 - canvas.height * 0.55,
            WORLD_PIXEL_HEIGHT - canvas.height
        )
    );

}


// ======================================
// ESCENA
// ======================================

function draw() {

    drawBackground();

    drawWorld();

    drawMiningOverlay();

    drawPlayer();

    drawHUD();

    if (!inventoryOpen) drawMiningMagnifier();
    if (inventoryOpen) drawInventoryOverlay();

}


// ======================================
// BUCLE PRINCIPAL
// ======================================

function gameLoop(timestamp) {

    const deltaTime = lastFrameTime === 0 ? 0 : Math.min((timestamp - lastFrameTime) / 1000, 0.05);
    lastFrameTime = timestamp;

    if (!inventoryOpen) {
        updatePlayer(deltaTime);
        updateMining(deltaTime);
    }

    updateCamera();

    draw();

    requestAnimationFrame(gameLoop);

}


// ======================================
// INICIAR
// ======================================

setStatus("0.7 · Inventario de 36 casillas · Toca INV para abrir");

gameLoop();