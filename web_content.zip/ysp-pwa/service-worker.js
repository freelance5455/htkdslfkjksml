/* Stone Pro service worker.
   Pages and scripts: network first, so a new version arrives as soon as the user is online,
   with the cached copy as the offline fallback. Images and icons: cache first. */
const CACHE_NAME = 'stonepro-v14-4';
const ASSETS = [
  './', './index.html', './manifest.json',
  './js/core.js', './js/sha.js', './js/security.js', './js/jdate.js', './js/plan.js', './js/data-tools.js', './js/site.js', './js/stock.js', './js/insurance.js', './js/onboarding.js',
  './img/ya-logo.png', './icon-192.png', './icon-512.png', './icon-512-maskable.png'
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))))
  );
  self.clients.claim();
});

const isCode = (req) => req.mode === 'navigate' || /\.(html|js|json)$/.test(new URL(req.url).pathname);

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;
  if (isCode(req)) {
    e.respondWith(
      fetch(req).then((res) => {
        if (res.ok) { const copy = res.clone(); caches.open(CACHE_NAME).then((c) => c.put(req, copy)); }
        return res;
      }).catch(() => caches.match(req).then((hit) => hit || caches.match('./index.html')))
    );
    return;
  }
  e.respondWith(
    caches.match(req).then((hit) => hit || fetch(req).then((res) => {
      if (res.ok) { const copy = res.clone(); caches.open(CACHE_NAME).then((c) => c.put(req, copy)); }
      return res;
    }))
  );
});
