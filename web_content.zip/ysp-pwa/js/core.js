/* Stone Pro core: storage, Persian date/time helpers and the automatic event log.
   Every change to a tracked collection is written to the event log with the exact
   date and time, so no screen has to remember to log anything by itself. */
"use strict";
(function (root) {
  const APP_VERSION = "14.2.0";
  const EVENTS_KEY = "ysp_events";
  const MAX_EVENTS = 2000;
  const ENTITY_OF = {
    ysp_projects: "project",
    ysp_workers: "worker",
    ysp_worker_ledger: "ledger",
    ysp_estimates: "estimate",
    ysp_photos: "photo",
    ysp_profile: "profile",
    ysp_parties: "party",
    ysp_entries: "entry",
    ysp_pays: "pay",
  };
  const LEDGER_LABEL = {
    work: "کارکرد روزانه",
    holiday: "کارکرد روز تعطیلی",
    payment: "پول داده به کارگر",
    receipt: "پول گرفته کارگر",
  };
  const USER_TYPE = { owner: "صاحبکار / کارفرما", contractor: "پیمانکار", worker: "کارگر" };
  const WORKER_LEDGER_LABEL = {
    work: "کارکرد روزانه",
    holiday: "کارکرد روز تعطیلی",
    payment: "دریافتی من از کارفرما",
    receipt: "ثبت مالی دیگر",
  };
  const ONLY_DATE = /^\d{4}-\d{2}-\d{2}$/;
  const isStampKey = (k) => (k !== "dueDate" && /(Date|At)$/.test(k)) || k === "id";
  let muted = 0;

  const pad = (n) => String(n).padStart(2, "0");
  const isoDate = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const nowISO = () => new Date().toISOString();

  let dateFmt, timeFmt;
  try {
    dateFmt = new Intl.DateTimeFormat("fa-IR-u-ca-persian", { year: "numeric", month: "2-digit", day: "2-digit" });
    timeFmt = new Intl.DateTimeFormat("fa-IR", { hour: "2-digit", minute: "2-digit", hour12: false });
  } catch (e) {
    dateFmt = { format: (d) => isoDate(d) };
    timeFmt = { format: (d) => `${pad(d.getHours())}:${pad(d.getMinutes())}` };
  }

  function toDate(v) {
    if (!v) return null;
    const d = ONLY_DATE.test(v) ? new Date(v + "T12:00:00") : new Date(v);
    return isNaN(d.getTime()) ? null : d;
  }
  const jalali = (v) => { const d = toDate(v); return d ? dateFmt.format(d) : ""; };
  const clock = (v) => { const d = v && !ONLY_DATE.test(v) ? toDate(v) : null; return d ? timeFmt.format(d) : ""; };
  /** "date  hour:minute" when the exact time is known, otherwise the date alone. */
  function dtShow(dateISO, atISO) {
    if (atISO && toDate(atISO)) return `${jalali(atISO)}  ${clock(atISO)}`;
    return dateISO ? jalali(dateISO) || String(dateISO) : "ثبت نشده";
  }

  /* ---------- storage ---------- */
  function getArr(key) {
    try {
      const v = JSON.parse(localStorage.getItem(key) || "[]");
      return Array.isArray(v) ? v : [];
    } catch (e) { return []; }
  }

  function describe(entity, rec) {
    switch (entity) {
      case "project": return rec.name || "پروژه";
      case "worker": return rec.name || "کارگر";
      case "estimate": return rec.title || "برآورد";
      case "photo": return rec.caption || "عکس";
      case "party": return rec.name || "طرف حساب";
      case "entry": {
        const kind = { material: "خرید مصالح", work_day: "کارکرد روزمزد", work_meter: "کارکرد متری", expense: "هزینه" }[rec.kind] || "ثبت";
        const who = (getArr("ysp_parties").find((x) => x.id === rec.partyId) || {}).name;
        return kind + (rec.title ? ": " + rec.title : "") + (who ? " – " + who : "") + (rec.amount ? " – " + Number(rec.amount).toLocaleString("fa-IR") + " تومان" : "");
      }
      case "pay": {
        const who = (getArr("ysp_parties").find((x) => x.id === rec.partyId) || {}).name;
        return "پرداخت " + ({ cash: "نقد", transfer: "حواله", check: "چک" }[rec.method] || "") + (who ? " – " + who : "") + " – " + Number(rec.amount || 0).toLocaleString("fa-IR") + " تومان";
      }
      case "profile": return "نقش: " + (USER_TYPE[rec.userType] || "—") + (rec.trade ? " · " + rec.trade : "");
      case "ledger": {
        const w = (getArr("ysp_workers").find((x) => x.id === rec.workerId) || {}).name;
        const money = rec.amount ? " – " + Number(rec.amount).toLocaleString("fa-IR") + " تومان" : "";
        return (ledgerLabels()[rec.type] || "ثبت کارگر") + (w ? " – " + w : "") + money;
      }
      default: return "";
    }
  }

  function changedFields(before, after) {
    const keys = new Set([...Object.keys(before), ...Object.keys(after)]);
    const out = [];
    keys.forEach((k) => {
      if (isStampKey(k)) return;
      if (JSON.stringify(before[k]) !== JSON.stringify(after[k])) out.push(k);
    });
    return out;
  }

  function readEvents() { return getArr(EVENTS_KEY); }
  function writeEvents(list) {
    const trimmed = list.length > MAX_EVENTS ? list.slice(list.length - MAX_EVENTS) : list;
    try { localStorage.setItem(EVENTS_KEY, JSON.stringify(trimmed)); } catch (e) { /* log must never break the app */ }
  }
  const eventId = () => "ev" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

  function logMany(items) {
    if (!items.length) return;
    const at = nowISO();
    const list = readEvents();
    items.forEach((e) => list.push(Object.assign({ id: eventId(), at }, e)));
    writeEvents(list);
  }
  function log(kind, entity, refId, title, fields) {
    logMany([{ kind, entity: entity || "", refId: refId || "", title: title || "", fields: fields || [] }]);
  }

  function diffLog(entity, before, after) {
    const idx = (a) => new Map(a.filter((x) => x && x.id).map((x) => [x.id, x]));
    const b = idx(before), a = idx(after), items = [];
    a.forEach((rec, id) => {
      const old = b.get(id);
      if (!old) items.push({ kind: "create", entity, refId: id, title: describe(entity, rec), fields: [] });
      else if (entity !== "photo") {
        const f = changedFields(old, rec);
        if (f.length) items.push({ kind: "update", entity, refId: id, title: describe(entity, rec), fields: f });
      }
    });
    b.forEach((rec, id) => {
      if (!a.has(id)) items.push({ kind: "delete", entity, refId: id, title: describe(entity, rec), fields: [] });
    });
    logMany(items);
  }

  /** Saves an array; tracked collections are diffed against the stored copy and logged. */
  function setArr(key, arr) {
    const entity = ENTITY_OF[key];
    const before = entity && !muted ? getArr(key) : null;
    try {
      localStorage.setItem(key, JSON.stringify(arr));
    } catch (e) {
      alert("حافظه دستگاه پر است. اول از اطلاعات پشتیبان بگیر و عکس‌های اضافه را حذف کن.");
      return false;
    }
    if (before) { try { diffLog(entity, before, arr); } catch (e) { /* ignore */ } }
    return true;
  }

  function silent(fn) { muted++; try { return fn(); } finally { muted--; } }

  /* ---------- user profile (role + trade) ---------- */
  function profile() { return getArr("ysp_profile")[0] || null; }
  function role() { const p = profile(); return p ? p.userType : ""; }
  /** Ledger wording depends on whose point of view the app has (a worker sees money as "received"). */
  function ledgerLabels() { return role() === "worker" ? WORKER_LEDGER_LABEL : LEDGER_LABEL; }

  /* ---------- small UI helpers ---------- */
  const fmt = (n) => Number(n || 0).toLocaleString();
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  function toast(msg) {
    let t = document.getElementById("ysp-toast");
    if (!t) {
      t = document.createElement("div");
      t.id = "ysp-toast";
      t.setAttribute("role", "status");
      t.style.cssText = "position:fixed;left:50%;bottom:92px;transform:translateX(-50%);background:#141210;color:#f3f1ec;border:1px solid #cda43e;border-radius:12px;padding:10px 16px;font-size:13px;z-index:300000;max-width:86vw;text-align:center;display:none";
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.style.display = "block";
    clearTimeout(toast._t);
    toast._t = setTimeout(() => { t.style.display = "none"; }, 2600);
  }

  function fallbackCopy(text) {
    const x = document.createElement("textarea");
    x.value = text;
    x.style.cssText = "position:fixed;opacity:0";
    document.body.appendChild(x);
    x.select();
    let ok = false;
    try { ok = document.execCommand("copy"); } catch (e) { /* ignore */ }
    x.remove();
    toast(ok ? "متن کپی شد و آماده ارسال است." : "کپی نشد؛ متن را دستی انتخاب کن.");
  }
  /** Opens the system share sheet when available, otherwise copies to the clipboard. */
  function share(text) {
    if (navigator.share) { navigator.share({ title: "Stone Pro", text }).catch(() => {}); return; }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(() => toast("متن کپی شد و آماده ارسال است.")).catch(() => fallbackCopy(text));
    } else fallbackCopy(text);
  }

  root.YSP = { version: APP_VERSION, events: readEvents, log, silent, nowISO, isoDate, jalali, clock, dtShow, share, toast, LEDGER_LABEL, USER_TYPE, profile, role, ledgerLabels };
  root.getArr = getArr;
  root.setArr = setArr;
  root.fmt = fmt;
  root.esc = esc;
})(window);
