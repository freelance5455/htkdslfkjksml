/* Stone Pro "workshop and accounts" (for owners and contractors).
   Parties (material suppliers, workers, craftsmen) have an account: what they are owed
   (material purchases, daily-wage work, per-meter work, expenses) minus what was paid
   (cash, transfer, cheque). Every record gets its date automatically and the exact time it was
   entered. Cheques keep a due date and raise an alert when it is close. */
"use strict";
(function (root) {
  const K = { party: "ysp_parties", entry: "ysp_entries", pay: "ysp_pays" };
  const KIND = { material: "خرید مصالح", work_day: "کارکرد روزمزد", work_meter: "کارکرد متری", expense: "هزینه", contract: "قرارداد / صورت‌وضعیت پیمانکار" };
  const PARTY = { supplier: "فروشنده مصالح", contractor: "پیمانکار", craftsman: "استادکار", worker: "کارگر" };
  const METHOD = { cash: "نقد", transfer: "کارت‌به‌کارت / حواله", check: "چک" };
  const STATUS = { pending: "در انتظار سررسید", cleared: "وصول شد", bounced: "برگشت خورد" };
  const ALERT_DAYS = 3;
  const UNITS = ["کیسه", "عدد", "متر مربع", "متر طول", "متر مکعب", "کیلوگرم", "تن", "بسته", "رول", "شاخه"];
  const $ = (id) => document.getElementById(id);
  const list = (k) => getArr(k);
  const uid = (p) => p + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const today = () => YSP.isoDate();
  const money = (n) => fmt(Math.round(Number(n) || 0));
  const S = { tab: "accounts", partyId: null, filter: "all", form: null, fd: {} };

  function num(v) {
    const s = String(v == null ? "" : v)
      .replace(/[۰-۹]/g, (d) => d.charCodeAt(0) - 1776)
      .replace(/[٠-٩]/g, (d) => d.charCodeAt(0) - 1632)
      .replace(/[,٬\s]/g, "").replace("٫", ".");
    const n = Number(s);
    return isFinite(n) ? n : 0;
  }
  const partyById = (id) => list(K.party).find((p) => p.id === id);
  const pname = (id) => (partyById(id) || {}).name || "—";
  const projectName = (id) => ((getArr("ysp_projects").find((p) => p.id === id)) || {}).name || "";
  const entryAmt = (e) => Number(e.amount) || 0;
  const countsAsPaid = (p) => !(p.method === "check" && p.checkStatus === "bounced");
  const payAmt = (p) => (countsAsPaid(p) ? Number(p.amount) || 0 : 0);
  const isPendingCheck = (p) => p.method === "check" && p.checkStatus === "pending";
  const sortNewest = (a, b) => (b.date || "").localeCompare(a.date || "") || (b.at || "").localeCompare(a.at || "");

  function balanceOf(id) {
    const ch = list(K.entry).filter((e) => e.partyId === id).reduce((a, e) => a + entryAmt(e), 0);
    const pd = list(K.pay).filter((p) => p.partyId === id).reduce((a, p) => a + payAmt(p), 0);
    return { charged: ch, paid: pd, balance: ch - pd };
  }
  function totals() {
    const en = list(K.entry), py = list(K.pay), pa = list(K.party);
    const charged = en.reduce((a, e) => a + entryAmt(e), 0);
    const paid = py.reduce((a, p) => a + payAmt(p), 0);
    const pend = py.filter(isPendingCheck);
    return {
      charged, paid, balance: charged - paid,
      pendingAmount: pend.reduce((a, p) => a + (Number(p.amount) || 0), 0), pendingCount: pend.length,
      people: pa.filter((p) => p.kind !== "supplier").length,
      personDays: en.filter((e) => e.kind === "work_day").reduce((a, e) => a + (Number(e.qty) || 0) * (Number(e.count) || 1), 0),
      meters: en.filter((e) => e.kind === "work_meter").reduce((a, e) => a + (Number(e.qty) || 0), 0),
    };
  }
  /** Paid to contractors for one project. A payment with no project counts for the project of that
      contractor's contract when the contractor has contracts in exactly one project. */
  function paidToContractor(projectId) {
    const contractors = list(K.party).filter((x) => x.kind === "contractor");
    const homeOf = new Map(contractors.map((c) => {
      const ps = new Set(list(K.entry).filter((e) => e.partyId === c.id && e.kind === "contract" && e.projectId).map((e) => e.projectId));
      return [c.id, ps.size === 1 ? Array.from(ps)[0] : ""];
    }));
    return list(K.pay).filter((x) => homeOf.has(x.partyId) && (!projectId || (x.projectId || homeOf.get(x.partyId)) === projectId)).reduce((a, x) => a + payAmt(x), 0);
  }
  function amountFor(kind, f) {
    const qty = num(f.qty), rate = num(f.rate), count = num(f.count) || 1;
    if (kind === "material") return qty && rate ? Math.round(qty * rate) : Math.round(num(f.amount));
    if (kind === "work_day") return Math.round(qty * rate * count);
    if (kind === "work_meter") return Math.round(qty * rate);
    return Math.round(num(f.amount));
  }

  /* ---------- styles ---------- */
  const css = document.createElement("style");
  css.textContent = `
  .site-tabs{display:flex;gap:6px;overflow-x:auto;margin:0 0 12px;padding-bottom:2px}
  .site-tab{flex:none;padding:9px 14px;border-radius:20px;border:1px solid var(--line);background:var(--bg-2);color:var(--gray);font-family:inherit;font-size:12.5px}
  .site-tab.on{color:#0b0b0b;background:linear-gradient(160deg,var(--gold-bright),var(--gold));border-color:transparent;font-weight:700}
  .site-actions{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px}
  .site-actions button{padding:12px 8px;border-radius:14px;border:1px solid var(--line);background:var(--bg-2);color:var(--text,#f3f1ec);font-family:inherit;font-size:13px}
  .site-actions button:last-child:nth-child(odd){grid-column:1 / -1}
  .site-sec{font-size:12.5px;color:var(--gray);margin:14px 0 8px}
  .site-row{display:flex;justify-content:space-between;gap:10px;align-items:flex-start;padding:11px 0;border-bottom:1px solid var(--line);font-size:13px}
  .site-row:last-child{border-bottom:0}.site-row .s{font-size:11.5px;color:var(--gray);margin-top:3px;line-height:1.8}
  .site-mini{padding:7px 11px;border-radius:10px;border:1px solid var(--line);background:transparent;color:var(--gold-bright);font-family:inherit;font-size:12px}
  .site-mini.red{color:#d97b7b;border-color:rgba(217,123,123,.4)}.site-mini.green{color:#7fc79a;border-color:rgba(127,199,154,.4)}
  .chip{font-size:11px;padding:3px 9px;border-radius:20px;border:1px solid;white-space:nowrap}
  .chip.red{color:#d97b7b;border-color:rgba(217,123,123,.5)}.chip.amber{color:#e6c265;border-color:rgba(230,194,101,.5)}.chip.green{color:#7fc79a;border-color:rgba(127,199,154,.5)}.chip.gray{color:var(--gray);border-color:var(--line)}
  #site-sheet{position:fixed;inset:0;z-index:90000;background:var(--bg,#0b0b0b);overflow-y:auto;display:none;direction:rtl}
  #site-sheet.open{display:block}
  #site-sheet .sh-head{position:sticky;top:0;background:var(--bg,#0b0b0b);padding:14px 16px;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;align-items:center;z-index:2}
  #site-sheet .sh-head b{font-size:15px}
  #site-sheet .sh-body{padding:14px 16px 110px}
  #site-sheet .err{color:#d97b7b;font-size:12.5px;min-height:18px;margin-top:8px}
  .site-total{font-weight:700;color:var(--gold-bright);font-size:17px}`;
  document.head.appendChild(css);

  /* ---------- sheet helper ---------- */
  function sheet(title, html) {
    let s = $("site-sheet");
    if (!s) {
      s = document.createElement("div");
      s.id = "site-sheet";
      s.innerHTML = '<div class="sh-head"><b id="sh-title"></b><button type="button" class="site-mini" onclick="YSPSite.closeSheet()">✕ بستن</button></div><div class="sh-body" id="sh-body"></div>';
      document.body.appendChild(s);
    }
    $("sh-title").textContent = title;
    $("sh-body").innerHTML = html;
    s.classList.add("open");
    s.scrollTop = 0;
  }
  function closeSheet() { const s = $("site-sheet"); if (s) s.classList.remove("open"); S.form = null; }
  const setErr = (t) => { const e = $("sf-err"); if (e) e.textContent = t || ""; };

  /* ---------- shared form pieces ---------- */
  function partySelectHtml(kinds, selected, createKinds) {
    const ps = list(K.party).filter((p) => !kinds || kinds.indexOf(p.kind) !== -1);
    const opts = ps.map((p) => `<option value="${p.id}" ${p.id === selected ? "selected" : ""}>${esc(p.name)} (${PARTY[p.kind]})</option>`).join("");
    const ck = createKinds || ["supplier", "contractor", "craftsman"];
    const kindOptions = ck.map((k) => `<option value="${k}">${PARTY[k]}</option>`).join("");
    return `<div class="card"><div class="lbl">👤 طرف حساب</div>
      <select id="sf-party"><option value="">${ps.length ? "انتخاب کن…" : "هنوز کسی ثبت نشده"}</option>${opts}</select>
      <div class="client" style="margin:8px 0 6px">یا یک طرف حساب جدید بنویس${ck.length === 1 ? " (" + PARTY[ck[0]] + ")" : ""}:</div>
      <input id="sf-newname" type="text" maxlength="60" placeholder="نام (مثلاً بنگاه سیمان، استاد رضا، پیمانکار اسکلت)">
      <select id="sf-pkind" style="margin-top:8px;${ck.length === 1 ? "display:none" : ""}">${kindOptions}</select></div>`;
  }
  function projectSelectHtml(selected) {
    const ps = getArr("ysp_projects");
    return `<div class="card"><div class="lbl">🏗️ پروژه (اختیاری)</div><select id="sf-project"><option value="">بدون پروژه</option>${ps.map((p) => `<option value="${p.id}" ${p.id === selected ? "selected" : ""}>${esc(p.name || "بدون نام")}</option>`).join("")}</select></div>`;
  }
  function dateCardHtml(field, label, note) {
    return `<div class="card"><div class="lbl">${label}</div><div id="sf-date-${field}" style="font-weight:700;color:var(--gold-bright)">${esc(YSP.jalali(S.fd[field]))}</div>
      <div class="client" style="margin:5px 0 8px">${note}</div><button type="button" class="site-mini" onclick="YSPSite.changeDate('${field}')">تغییر تاریخ</button></div>`;
  }
  function changeDate(field) {
    YSPDate.pick({ value: S.fd[field] || undefined, title: { dueDate: "تاریخ سررسید چک", nextDue: "سررسید پرداخت حق بیمه", endDate: "پایان بیمه‌نامه", startDate: "شروع بیمه" }[field] || "تاریخ ثبت" }).then((iso) => {
      if (!iso) return;
      S.fd[field] = iso;
      const el = $("sf-date-" + field); if (el) el.textContent = YSP.jalali(iso);
    });
  }
  /** Finds the chosen party or creates the one typed in; returns its id or "" (with an error shown). */
  function resolveParty() {
    const picked = $("sf-party").value, name = ($("sf-newname").value || "").trim();
    if (picked) return picked;
    if (!name) { setErr("طرف حساب را انتخاب کن یا نام جدید بنویس."); return ""; }
    if (YSPPlan.limitHit("parties", list(K.party).length)) return "";
    const rec = { id: uid("pt"), kind: $("sf-pkind").value, name, phone: "", createdAt: YSP.nowISO() };
    if (!setArr(K.party, list(K.party).concat([rec]))) return "";
    return rec.id;
  }

  /* ---------- party ---------- */
  function openParty(id) {
    const ex = id ? partyById(id) : null;
    S.form = { type: "party", id: id || null };
    sheet(ex ? "ویرایش طرف حساب" : "طرف حساب جدید", `
      <div class="card"><div class="lbl">👤 نام</div><input id="sf-name" type="text" maxlength="60" value="${esc(ex ? ex.name : "")}"></div>
      <div class="card"><div class="lbl">🏷️ نوع</div><select id="sf-kind">${["supplier", "contractor", "craftsman"].concat(ex && ex.kind === "worker" ? ["worker"] : []).map((k) => `<option value="${k}" ${ex && ex.kind === k ? "selected" : ""}>${PARTY[k]}</option>`).join("")}</select></div>
      <div class="card"><div class="lbl">📞 شماره تماس (اختیاری)</div><input id="sf-phone" type="text" inputmode="tel" maxlength="20" value="${esc(ex ? ex.phone || "" : "")}"></div>
      <div class="err" id="sf-err"></div><button type="button" class="save-btn" onclick="YSPSite.saveParty()">ذخیره</button>`);
  }
  function saveParty() {
    const name = ($("sf-name").value || "").trim();
    if (!name) return setErr("نام را بنویس.");
    const id = S.form && S.form.id, all = list(K.party);
    if (id) {
      const p = all.find((x) => x.id === id);
      Object.assign(p, { name, kind: $("sf-kind").value, phone: ($("sf-phone").value || "").trim(), updatedAt: YSP.nowISO() });
      if (!setArr(K.party, all)) return;
    } else {
      if (YSPPlan.limitHit("parties", all.length)) return;
      if (!setArr(K.party, all.concat([{ id: uid("pt"), kind: $("sf-kind").value, name, phone: ($("sf-phone").value || "").trim(), createdAt: YSP.nowISO() }]))) return;
    }
    closeSheet(); render();
  }
  function deleteParty(id) {
    const p = partyById(id); if (!p) return;
    requestDelete(`حذف «${p.name}»`, () => {
      setArr(K.entry, list(K.entry).filter((e) => e.partyId !== id));
      setArr(K.pay, list(K.pay).filter((x) => x.partyId !== id));
      setArr(K.party, list(K.party).filter((x) => x.id !== id));
      S.partyId = null; closeSheet(); render();
    }, { text: "همه‌ی خریدها، کارکردها و پرداخت‌های این طرف حساب هم حذف می‌شود. برای ادامه رمز را وارد کن." });
  }

  /* ---------- entries (purchases, work, expenses) ---------- */
  function openEntry(kind, opts) {
    opts = opts || {};
    const ex = opts.id ? list(K.entry).find((e) => e.id === opts.id) : null;
    kind = ex ? ex.kind : kind;
    if (kind === "work_meter" && !YSPPlan.gate("site.meter")) return;
    if (!ex && YSPPlan.limitHit("entries", list(K.entry).length)) return;
    const f = ex || { kind, partyId: opts.partyId || "", projectId: "", date: today(), qty: "", unit: "", rate: "", count: 1, amount: "", title: "", invoiceNo: "", note: "" };
    S.form = { type: "entry", kind, id: ex ? ex.id : null };
    S.fd = { date: f.date || today() };
    const isWork = kind === "work_day" || kind === "work_meter";
    const kinds = isWork ? ["craftsman", "worker"] : kind === "contract" ? ["contractor"] : null;
    const createKinds = isWork ? ["craftsman"] : kind === "contract" ? ["contractor"] : kind === "material" ? ["supplier"] : ["supplier", "contractor", "craftsman"];
    let fields = "";
    if (kind === "material") fields = `
      <div class="card"><div class="lbl">🧱 نام مصالح</div><input id="sf-title" type="text" maxlength="80" value="${esc(f.title)}" placeholder="مثلاً سیمان، ماسه، سنگ"></div>
      <div class="card"><div class="lbl">⚖️ مقدار و واحد</div><div style="display:flex;gap:8px"><input id="sf-qty" type="text" inputmode="decimal" placeholder="مقدار" value="${esc(f.qty)}" oninput="YSPSite.recalc()"><input id="sf-unit" list="sf-units" placeholder="واحد" value="${esc(f.unit)}"></div><datalist id="sf-units">${UNITS.map((u) => `<option value="${u}">`).join("")}</datalist></div>
      <div class="card"><div class="lbl">💰 قیمت هر واحد (تومان)</div><input id="sf-rate" type="text" inputmode="decimal" value="${esc(f.rate)}" oninput="YSPSite.recalc()"></div>
      <div class="card"><div class="lbl">💵 یا مبلغ کل (اگر مقدار و قیمت واحد نداری)</div><input id="sf-amount" type="text" inputmode="decimal" value="${ex && !f.qty ? esc(f.amount) : ""}" oninput="YSPSite.recalc()"></div>
      <div class="card"><div class="lbl">🧾 شماره فاکتور (اختیاری)</div><input id="sf-invoice" type="text" maxlength="30" value="${esc(f.invoiceNo)}"></div>`;
    else if (kind === "work_day") fields = `
      <div class="card"><div class="lbl">📝 شرح کار (اختیاری)</div><input id="sf-title" type="text" maxlength="80" value="${esc(f.title)}"></div>
      <div class="card"><div class="lbl">📅 تعداد روز</div><input id="sf-qty" type="text" inputmode="decimal" value="${esc(f.qty || 1)}" oninput="YSPSite.recalc()"></div>
      <div class="card"><div class="lbl">👷 تعداد کارگر</div><input id="sf-count" type="text" inputmode="numeric" value="${esc(f.count || 1)}" oninput="YSPSite.recalc()"></div>
      <div class="card"><div class="lbl">💰 روزمزد هر نفر (تومان)</div><input id="sf-rate" type="text" inputmode="decimal" value="${esc(f.rate)}" oninput="YSPSite.recalc()"></div>`;
    else if (kind === "work_meter") fields = `
      <div class="card"><div class="lbl">📝 شرح کار (مثلاً سنگ‌کاری نما)</div><input id="sf-title" type="text" maxlength="80" value="${esc(f.title)}"></div>
      <div class="card"><div class="lbl">📐 متراژ انجام‌شده (متر)</div><input id="sf-qty" type="text" inputmode="decimal" value="${esc(f.qty)}" oninput="YSPSite.recalc()"></div>
      <div class="card"><div class="lbl">💰 نرخ هر متر (تومان)</div><input id="sf-rate" type="text" inputmode="decimal" value="${esc(f.rate)}" oninput="YSPSite.recalc()"></div>`;
    else if (kind === "contract") fields = `
      <div class="card"><div class="lbl">📝 شرح (مثلاً قرارداد اسکلت، صورت‌وضعیت شماره ۲)</div><input id="sf-title" type="text" maxlength="80" value="${esc(f.title)}"></div>
      <div class="card"><div class="lbl">💵 مبلغ (تومان)</div><input id="sf-amount" type="text" inputmode="decimal" value="${esc(f.amount)}" oninput="YSPSite.recalc()"></div>`;
    else fields = `
      <div class="card"><div class="lbl">📝 شرح هزینه</div><input id="sf-title" type="text" maxlength="80" value="${esc(f.title)}" placeholder="مثلاً کرایه حمل، برق موقت"></div>
      <div class="card"><div class="lbl">💵 مبلغ (تومان)</div><input id="sf-amount" type="text" inputmode="decimal" value="${esc(f.amount)}" oninput="YSPSite.recalc()"></div>
      <div class="card"><div class="lbl">🧾 شماره فاکتور (اختیاری)</div><input id="sf-invoice" type="text" maxlength="30" value="${esc(f.invoiceNo)}"></div>`;
    if (kind === "material" && root.YSPStock) fields += `<div class="card"><label style="display:flex;gap:10px;align-items:center"><input type="checkbox" id="sf-tostock" style="width:22px;height:22px" ${!ex || YSPStock.hasLink(ex.id) ? "checked" : ""}><span>ورود این خرید به انبار هم ثبت شود</span></label><div class="client" style="margin-top:6px">فقط وقتی مقدار و واحد را نوشته باشی ثبت می‌شود.</div></div>`;
    sheet((ex ? "ویرایش: " : "ثبت: ") + KIND[kind],
      partySelectHtml(kinds, f.partyId, createKinds) + projectSelectHtml(f.projectId) + fields +
      `<div class="card"><div class="lbl">💰 جمع مبلغ</div><div class="site-total" id="sf-total">0</div></div>` +
      dateCardHtml("date", "📅 تاریخ ثبت", `تاریخ امروز خودکار ثبت می‌شود و ساعت دقیق هم نگه داشته می‌شود${ex ? ` (ثبت اولیه: ${esc(YSP.dtShow("", ex.at))})` : ""}.`) +
      `<div class="card"><div class="lbl">🗒️ توضیحات (اختیاری)</div><textarea id="sf-note" rows="2">${esc(f.note)}</textarea></div>
      <div class="err" id="sf-err"></div><button type="button" class="save-btn" onclick="YSPSite.saveEntry()">ذخیره</button>`);
    if (kind === "work_meter" && !ex && $("sf-pkind")) $("sf-pkind").value = "craftsman";
    recalc();
  }
  function recalc() {
    if (!S.form || S.form.type !== "entry") return;
    const g = (id) => ($(id) ? $(id).value : "");
    const t = $("sf-total");
    if (t) t.textContent = money(amountFor(S.form.kind, { qty: g("sf-qty"), rate: g("sf-rate"), count: g("sf-count"), amount: g("sf-amount") })) + " تومان";
  }
  function saveEntry() {
    const kind = S.form.kind, g = (id) => ($(id) ? $(id).value : "");
    const raw = { qty: g("sf-qty"), rate: g("sf-rate"), count: g("sf-count"), amount: g("sf-amount") };
    const amount = amountFor(kind, raw);
    if (amount <= 0) return setErr("مبلغ صفر است؛ مقدار و نرخ (یا مبلغ) را کامل کن.");
    if ((kind === "material" || kind === "expense") && !g("sf-title").trim()) return setErr("نام مصالح یا شرح هزینه را بنویس.");
    const partyId = resolveParty();
    if (!partyId) return;
    const all = list(K.entry), id = S.form.id, old = id ? all.find((e) => e.id === id) : null;
    const rec = {
      id: id || uid("en"), partyId, projectId: g("sf-project"), kind, title: g("sf-title").trim(),
      qty: num(raw.qty) || "", unit: g("sf-unit").trim(), rate: num(raw.rate) || "", count: kind === "work_day" ? (num(raw.count) || 1) : "",
      amount, invoiceNo: g("sf-invoice").trim(), date: S.fd.date || today(), at: old ? old.at : YSP.nowISO(), note: g("sf-note").trim(),
    };
    if (old) { Object.assign(old, rec, { updatedAt: YSP.nowISO() }); if (!setArr(K.entry, all)) return; }
    else if (!setArr(K.entry, all.concat([rec]))) return;
    if (root.YSPStock && kind === "material") YSPStock.syncPurchase(old || rec, $("sf-tostock") ? $("sf-tostock").checked : false);
    closeSheet(); render();
  }
  function deleteEntry(id) {
    const e = list(K.entry).find((x) => x.id === id); if (!e) return;
    requestDelete(`حذف ثبت «${e.title || KIND[e.kind]}»`, () => {
      setArr(K.pay, list(K.pay).map((p) => (p.entryId === id ? Object.assign({}, p, { entryId: "" }) : p)));
      setArr(K.entry, list(K.entry).filter((x) => x.id !== id));
      if (root.YSPStock) YSPStock.removeByEntry(id);
      render();
    });
  }

  /* ---------- payments ---------- */
  function openPay(opts) {
    opts = opts || {};
    const ex = opts.id ? list(K.pay).find((p) => p.id === opts.id) : null;
    const f = ex || { partyId: opts.partyId || "", projectId: "", amount: "", method: "cash", checkNo: "", bank: "", dueDate: "", entryId: opts.entryId || "", date: today(), note: "" };
    if (f.entryId && !f.partyId) { const en = list(K.entry).find((e) => e.id === f.entryId); if (en) f.partyId = en.partyId; }
    S.form = { type: "pay", id: ex ? ex.id : null, kinds: opts.kinds || null };
    S.fd = { date: f.date || today(), dueDate: f.dueDate || "" };
    const invoices = list(K.entry).filter((e) => (e.kind === "material" || e.kind === "expense") && (!f.partyId || e.partyId === f.partyId));
    sheet(ex ? "ویرایش پرداخت" : opts.kinds ? "پرداخت به پیمانکار" : "ثبت پرداخت",
      partySelectHtml(opts.kinds || null, f.partyId, opts.kinds || null) + projectSelectHtml(f.projectId) +
      `<div class="card"><div class="lbl">💸 مبلغ پرداخت (تومان)</div><input id="sf-amount" type="text" inputmode="decimal" value="${esc(f.amount)}"></div>
       <div class="card"><div class="lbl">🏦 نوع پرداخت</div><select id="sf-method" onchange="YSPSite.methodChanged()">${Object.keys(METHOD).map((m) => `<option value="${m}" ${f.method === m ? "selected" : ""}>${METHOD[m]}</option>`).join("")}</select></div>
       <div id="sf-check-box" style="display:${f.method === "check" ? "block" : "none"}">
         <div class="card"><div class="lbl">🔢 شماره چک</div><input id="sf-checkno" type="text" maxlength="30" value="${esc(f.checkNo)}"></div>
         <div class="card"><div class="lbl">🏛️ بانک (اختیاری)</div><input id="sf-bank" type="text" maxlength="40" value="${esc(f.bank)}"></div>
         <div class="card"><div class="lbl">⏰ تاریخ سررسید چک</div><div id="sf-date-dueDate" style="font-weight:700;color:var(--gold-bright)">${f.dueDate ? esc(YSP.jalali(f.dueDate)) : "انتخاب نشده"}</div><div class="client" style="margin:5px 0 8px">قبل از سررسید در خانه هشدار می‌گیری.</div><button type="button" class="site-mini" onclick="YSPSite.changeDate('dueDate')">انتخاب تاریخ سررسید</button></div></div>
       ${invoices.length ? `<div class="card"><div class="lbl">🧾 بابت کدام فاکتور؟ (اختیاری)</div><select id="sf-entry"><option value="">بدون اتصال به فاکتور</option>${invoices.map((e) => `<option value="${e.id}" ${e.id === f.entryId ? "selected" : ""}>${esc(e.title || KIND[e.kind])}${e.invoiceNo ? " · " + esc(e.invoiceNo) : ""} · ${money(e.amount)}</option>`).join("")}</select></div>` : ""}` +
      dateCardHtml("date", "📅 تاریخ پرداخت", `تاریخ امروز خودکار ثبت می‌شود و ساعت دقیق هم نگه داشته می‌شود${ex ? ` (ثبت اولیه: ${esc(YSP.dtShow("", ex.at))})` : ""}.`) +
      `<div class="card"><div class="lbl">🗒️ توضیحات (اختیاری)</div><textarea id="sf-note" rows="2">${esc(f.note)}</textarea></div>
      <div class="err" id="sf-err"></div><button type="button" class="save-btn" onclick="YSPSite.savePay()">ذخیره</button>`);
  }
  function methodChanged() {
    const m = $("sf-method").value;
    if (m === "check" && !YSPPlan.allowed()) { $("sf-method").value = "cash"; YSPPlan.gate("site.checks"); return; }
    $("sf-check-box").style.display = m === "check" ? "block" : "none";
  }
  function savePay() {
    const amount = Math.round(num($("sf-amount").value));
    if (amount <= 0) return setErr("مبلغ پرداخت را وارد کن.");
    const method = $("sf-method").value;
    if (method === "check") {
      if (!YSPPlan.gate("site.checks")) return;
      if (!S.fd.dueDate) return setErr("تاریخ سررسید چک را انتخاب کن.");
    }
    const partyId = resolveParty();
    if (!partyId) return;
    const all = list(K.pay), id = S.form.id, old = id ? all.find((p) => p.id === id) : null;
    const rec = {
      id: id || uid("py"), partyId, projectId: $("sf-project").value, amount, method,
      checkNo: method === "check" ? $("sf-checkno").value.trim() : "", bank: method === "check" ? $("sf-bank").value.trim() : "",
      dueDate: method === "check" ? S.fd.dueDate : "", checkStatus: method === "check" ? (old && old.checkStatus) || "pending" : "",
      entryId: $("sf-entry") ? $("sf-entry").value : "", date: S.fd.date || today(), at: old ? old.at : YSP.nowISO(), note: $("sf-note").value.trim(),
    };
    if (old) { Object.assign(old, rec, { updatedAt: YSP.nowISO() }); if (!setArr(K.pay, all)) return; }
    else if (!setArr(K.pay, all.concat([rec]))) return;
    closeSheet(); render();
  }
  function deletePay(id) {
    const p = list(K.pay).find((x) => x.id === id); if (!p) return;
    requestDelete(`حذف پرداخت ${money(p.amount)} تومان`, () => { setArr(K.pay, list(K.pay).filter((x) => x.id !== id)); render(); });
  }
  function setCheckStatus(id, status) {
    const all = list(K.pay), p = all.find((x) => x.id === id); if (!p) return;
    p.checkStatus = status; p.statusAt = YSP.nowISO();
    if (setArr(K.pay, all)) render();
  }

  /* ---------- cheque alerts and calendar ---------- */
  function checkState(p) {
    if (!p.dueDate) return { text: "بدون سررسید", cls: "gray", left: 0 };
    const left = YSPDate.daysBetween(today(), p.dueDate);
    if (p.checkStatus === "cleared") return { text: "وصول شد", cls: "green", left };
    if (p.checkStatus === "bounced") return { text: "برگشت خورد", cls: "red", left };
    if (left < 0) return { text: `${money(-left)} روز از سررسید گذشته`, cls: "red", left };
    if (left === 0) return { text: "سررسید امروز", cls: "red", left };
    if (left === 1) return { text: "سررسید فردا", cls: "amber", left };
    return { text: `${money(left)} روز مانده`, cls: left <= 7 ? "amber" : "gray", left };
  }
  function alertChecks() {
    const role = YSP.role();
    if ((role !== "owner" && role !== "contractor") || !YSPPlan.allowed()) return [];
    const limit = YSPDate.addDays(today(), ALERT_DAYS);
    return list(K.pay).filter((p) => isPendingCheck(p) && p.dueDate && p.dueDate <= limit).sort((a, b) => a.dueDate.localeCompare(b.dueDate));
  }
  const alertSources = [];
  const registerAlerts = (fn) => { alertSources.push(fn); };
  /** Every pending alert (cheques, insurance, ...), soonest first. */
  function allAlerts() {
    const role = YSP.role();
    if (role !== "owner" && role !== "contractor") return [];
    const items = alertChecks().map((p) => ({ tab: "checks", sort: p.dueDate, text: `چک ${pname(p.partyId)} — ${money(p.amount)} تومان — ${checkState(p).text}` }));
    alertSources.forEach((fn) => { try { fn().forEach((x) => items.push(x)); } catch (e) { /* one broken source must not hide the others */ } });
    return items.sort((x, y) => (x.sort || "").localeCompare(y.sort || ""));
  }
  function alertsHtml() {
    const a = allAlerts();
    if (!a.length) return "";
    const lines = a.slice(0, 4).map((x) => `<div class="client">• ${esc(x.text)}</div>`).join("");
    const tabs = Array.from(new Set(a.map((x) => x.tab)));
    return `<div class="card" style="border-color:#d97b7b;margin-bottom:12px"><div class="lbl">⏰ هشدار سررسید (${money(a.length)})</div>${lines}${a.length > 4 ? `<div class="client">و ${money(a.length - 4)} مورد دیگر</div>` : ""}<div style="display:flex;gap:8px;margin-top:8px">${tabs.map((t) => `<button type="button" class="save-btn" style="margin:0" onclick="YSPSite.open('${t}')">${esc((TABS[t] || [t])[0])}</button>`).join("")}</div></div>`;
  }
  function refreshBadge() {
    const b = $("site-badge"); if (!b) return;
    const n = allAlerts().length;
    b.style.display = n ? "inline-block" : "none";
    b.textContent = n ? money(n) : "";
  }
  const icsText = (s) => String(s).replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n");
  function downloadText(name, text, type) {
    const url = URL.createObjectURL(new Blob([text], { type }));
    const a = document.createElement("a");
    a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }
  /** A one-day calendar event with a reminder the day before. */
  function buildIcsEvent(uidValue, title, dateISO, description) {
    const d = dateISO.replace(/-/g, ""), next = YSPDate.addDays(dateISO, 1).replace(/-/g, "");
    const stamp = new Date().toISOString().replace(/[-:]/g, "").replace(/\.\d+/, "");
    return ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Stone Pro//FA//", "BEGIN:VEVENT", `UID:${uidValue}@stonepro`, `DTSTAMP:${stamp}`,
      `DTSTART;VALUE=DATE:${d}`, `DTEND;VALUE=DATE:${next}`, `SUMMARY:${icsText(title)}`, `DESCRIPTION:${icsText(description || "")}`,
      "BEGIN:VALARM", "TRIGGER:-P1D", "ACTION:DISPLAY", `DESCRIPTION:${icsText("فردا سررسید است")}`, "END:VALARM", "END:VEVENT", "END:VCALENDAR"].join("\r\n");
  }
  function buildIcs(p) {
    return buildIcsEvent(p.id, `سررسید چک ${money(p.amount)} تومان - ${pname(p.partyId)}`, p.dueDate, `شماره چک: ${p.checkNo || "—"}${p.bank ? " - " + p.bank : ""}`);
  }
  function addToCalendar(id) {
    const p = list(K.pay).find((x) => x.id === id);
    if (!p || !p.dueDate) return;
    YSPPlan.gate("site.checks", () => { downloadText(`check-${p.checkNo || p.id}.ics`, buildIcs(p), "text/calendar"); YSP.toast("فایل تقویم ساخته شد؛ آن را باز کن تا یادآور اضافه شود."); });
  }

  /* ---------- text for sharing ---------- */
  function statementText(id) {
    const p = partyById(id); if (!p) return "";
    const rows = [];
    list(K.entry).filter((e) => e.partyId === id).forEach((e) => rows.push({ k: e.date, a: e.at, t: `${YSP.dtShow(e.date, e.at)} | ${KIND[e.kind]}${e.title ? ": " + e.title : ""}${e.qty ? ` (${e.qty}${e.unit ? " " + e.unit : e.kind === "work_meter" ? " متر" : e.kind === "work_day" ? " روز" : ""}${e.kind === "work_day" && e.count > 1 ? ` × ${e.count} نفر` : ""})` : ""} | ${money(e.amount)} تومان` }));
    list(K.pay).filter((x) => x.partyId === id).forEach((x) => rows.push({ k: x.date, a: x.at, t: `${YSP.dtShow(x.date, x.at)} | پرداخت (${METHOD[x.method]}${x.method === "check" ? " - سررسید " + YSP.jalali(x.dueDate) : ""}) | ${money(x.amount)} تومان` }));
    rows.sort((a, b) => (a.k || "").localeCompare(b.k || "") || (a.a || "").localeCompare(b.a || ""));
    const b = balanceOf(id);
    return `صورت‌حساب ${p.name} (${PARTY[p.kind]})\n${rows.map((r) => r.t).join("\n")}\n—\nجمع خرید/کارکرد: ${money(b.charged)} تومان\nجمع پرداخت: ${money(b.paid)} تومان\nمانده حساب: ${money(b.balance)} تومان`;
  }
  function reportText() {
    const t = totals(), byProject = costByProject();
    return `گزارش کارگاه — ${YSP.dtShow("", YSP.nowISO())}\nجمع خرید و کارکرد: ${money(t.charged)} تومان\nجمع پرداخت: ${money(t.paid)} تومان\nمانده بدهی: ${money(t.balance)} تومان\nچک‌های در راه: ${money(t.pendingCount)} فقره / ${money(t.pendingAmount)} تومان\n` +
      byProject.map((r) => `${r.name}: ${money(r.amount)} تومان`).join("\n");
  }
  function costByProject() {
    const m = new Map();
    list(K.entry).forEach((e) => { const k = e.projectId || ""; m.set(k, (m.get(k) || 0) + entryAmt(e)); });
    return Array.from(m.entries()).map(([k, amount]) => ({ name: k ? projectName(k) || "پروژه حذف‌شده" : "بدون پروژه", amount })).sort((a, b) => b.amount - a.amount);
  }
  /** Payments as rows for the app-wide financial report. */
  function financeRows() {
    return list(K.pay).filter(countsAsPaid).map((p) => {
      const party = partyById(p.partyId) || {};
      return { date: YSP.dtShow(p.date, p.at), type: `پرداخت ${METHOD[p.method]}${party.kind ? " به " + PARTY[party.kind] : ""}`, title: party.name || "—", amount: -(Number(p.amount) || 0), share: () => YSP.share(statementText(p.partyId)) };
    });
  }
  const share = (text) => YSPPlan.gate("site.share", () => YSP.share(text));

  /* ---------- screen ---------- */
  function open(tab) {
    S.partyId = null;
    if (tab) S.tab = tab;
    go("site");
    if (tab) setTimeout(() => { const t = document.querySelector("#site .site-tabs"); if (t) t.scrollIntoView({ block: "start" }); }, 60);
  }
  function setTab(t) { S.tab = t; S.partyId = null; render(); }
  function setFilter(f) { S.filter = f; render(); }
  const lockedCard = (feature) => `<div class="card"><div class="lbl">⭐ امکان اشتراکی</div><div class="client" style="margin-bottom:8px">${esc(YSPPlan.FEATURES[feature])}</div><button type="button" class="save-btn" style="margin:0" onclick="YSPPlan.gate('${feature}')">درباره اشتراک</button></div>`;
  const empty = (t) => `<div class="empty" style="margin-top:30px">${t}</div>`;
  const chipBal = (b) => `<span class="chip ${b > 0 ? "amber" : b < 0 ? "green" : "gray"}">${b > 0 ? "بدهکارم: " : b < 0 ? "طلبکارم: " : "تسویه: "}${money(Math.abs(b))}</span>`;

  function tabAccounts() {
    const ps = list(K.party);
    const card = (p) => { const b = balanceOf(p.id); return `<div class="pcard" onclick="YSPSite.party('${p.id}')"><div><div class="name">${esc(p.name)}</div><div class="client">${PARTY[p.kind]} · ${p.kind === "contractor" ? "قرارداد" : "خرید/کارکرد"} ${money(b.charged)} · پرداخت ${money(b.paid)}</div></div>${chipBal(b.balance)}</div>`; };
    const con = ps.filter((p) => p.kind === "contractor"), sup = ps.filter((p) => p.kind === "supplier"), ppl = ps.filter((p) => p.kind === "craftsman" || p.kind === "worker");
    return `<button type="button" class="site-mini" style="margin-bottom:10px" onclick="YSPSite.openParty()">➕ طرف حساب جدید</button>
      ${ps.length ? "" : empty("هنوز طرف حسابی ثبت نشده.<br>با ثبت اولین خرید، کارکرد یا قرارداد، طرف حساب خودکار ساخته می‌شود.")}
      ${con.length ? `<div class="site-sec">🏗️ پیمانکارها — مانده حساب پیمانکار</div><div class="plist">${con.map(card).join("")}</div>` : ""}
      ${sup.length ? `<div class="site-sec">🧱 فروشندگان مصالح — مانده حساب مصالح</div><div class="plist">${sup.map(card).join("")}</div>` : ""}
      ${ppl.length ? `<div class="site-sec">👷 استادکارها — مانده حساب</div><div class="plist">${ppl.map(card).join("")}</div>` : ""}
      <div class="client" style="margin-top:12px">کارگرهای روزمزد (کارکرد، تعطیلی، اضافه‌کاری، کسری، پول گرفته) در بخش «کارگران روزمزد» صفحه اصلی هستند.</div>`;
  }
  function tabInvoices() {
    if (!YSPPlan.allowed()) return lockedCard("site.invoices");
    const inv = list(K.entry).filter((e) => e.kind === "material" || e.kind === "expense").sort(sortNewest);
    const rows = inv.map((e) => {
      const linked = list(K.pay).filter((p) => p.entryId === e.id).reduce((a, p) => a + payAmt(p), 0), rest = entryAmt(e) - linked;
      return { e, linked, rest };
    }).filter((r) => S.filter !== "unpaid" || r.rest > 0);
    return `<div style="display:flex;gap:8px;margin-bottom:10px"><button type="button" class="site-tab ${S.filter === "all" ? "on" : ""}" onclick="YSPSite.setFilter('all')">همه</button><button type="button" class="site-tab ${S.filter === "unpaid" ? "on" : ""}" onclick="YSPSite.setFilter('unpaid')">پرداخت‌نشده</button></div>
      ${rows.length ? rows.map((r) => `<div class="card"><div class="site-row" style="border:0;padding:0"><div><b>${esc(r.e.title || KIND[r.e.kind])}</b>${r.e.invoiceNo ? ` · فاکتور ${esc(r.e.invoiceNo)}` : ""}<div class="s">${esc(pname(r.e.partyId))} · ${esc(YSP.dtShow(r.e.date, r.e.at))}${r.e.projectId ? " · " + esc(projectName(r.e.projectId)) : ""}</div></div><div style="text-align:left"><div>${money(r.e.amount)}</div><span class="chip ${r.rest <= 0 ? "green" : r.linked ? "amber" : "gray"}">${r.rest <= 0 ? "تسویه" : "مانده " + money(r.rest)}</span></div></div>
        <div style="display:flex;gap:6px;margin-top:8px"><button type="button" class="site-mini" onclick="YSPSite.pay({entryId:'${r.e.id}'})">💸 پرداخت برای این فاکتور</button><button type="button" class="site-mini" onclick="YSPSite.entry('',{id:'${r.e.id}'})">✏️</button></div></div>`).join("") : empty("فاکتوری برای نمایش نیست.")}`;
  }
  function tabChecks() {
    if (!YSPPlan.allowed()) return lockedCard("site.checks");
    const cs = list(K.pay).filter((p) => p.method === "check").sort((a, b) => (a.checkStatus === "pending" ? 0 : 1) - (b.checkStatus === "pending" ? 0 : 1) || (a.dueDate || "").localeCompare(b.dueDate || ""));
    if (!cs.length) return empty("چکی ثبت نشده.<br>هنگام ثبت پرداخت، نوع «چک» را انتخاب کن و تاریخ سررسید بگذار.");
    return cs.map((p) => { const st = checkState(p); return `<div class="card"><div class="site-row" style="border:0;padding:0"><div><b>${esc(pname(p.partyId))}</b> · ${money(p.amount)} تومان<div class="s">چک ${esc(p.checkNo || "—")}${p.bank ? " · " + esc(p.bank) : ""}<br>سررسید: ${esc(YSP.jalali(p.dueDate))} · ثبت: ${esc(YSP.dtShow(p.date, p.at))}</div></div><span class="chip ${st.cls}">${esc(st.text)}</span></div>
      <div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap">${p.checkStatus === "pending" ? `<button type="button" class="site-mini green" onclick="YSPSite.checkStatus('${p.id}','cleared')">✅ وصول شد</button><button type="button" class="site-mini red" onclick="YSPSite.checkStatus('${p.id}','bounced')">↩️ برگشت خورد</button><button type="button" class="site-mini" onclick="YSPSite.calendar('${p.id}')">📅 افزودن به تقویم</button>` : `<button type="button" class="site-mini" onclick="YSPSite.checkStatus('${p.id}','pending')">بازگرداندن به «در انتظار»</button>`}<button type="button" class="site-mini" onclick="YSPSite.pay({id:'${p.id}'})">✏️</button><button type="button" class="site-mini red" onclick="YSPSite.delPay('${p.id}')">🗑️</button></div></div>`; }).join("");
  }
  function tabWork() {
    const t = totals(), ppl = list(K.party).filter((p) => p.kind !== "supplier");
    const rows = ppl.map((p) => {
      const en = list(K.entry).filter((e) => e.partyId === p.id);
      const days = en.filter((e) => e.kind === "work_day").reduce((a, e) => a + (Number(e.qty) || 0) * (Number(e.count) || 1), 0);
      const meters = en.filter((e) => e.kind === "work_meter").reduce((a, e) => a + (Number(e.qty) || 0), 0);
      const wages = en.filter((e) => e.kind === "work_day" || e.kind === "work_meter").reduce((a, e) => a + entryAmt(e), 0);
      return { p, days, meters, wages, bal: balanceOf(p.id).balance };
    });
    return `<div class="statgrid"><div class="stat"><div class="n">${money(t.people)}</div><div class="l">کارگر و استادکار ثبت‌شده</div></div><div class="stat"><div class="n">${money(t.personDays)}</div><div class="l">جمع نفر-روز کارکرد</div></div>
      <div class="stat"><div class="n">${YSPPlan.allowed() ? money(t.meters) : "⭐"}</div><div class="l">${YSPPlan.allowed() ? "جمع متراژ استادکارها (متر)" : "جمع متراژ (اشتراکی)"}</div></div><div class="stat"><div class="n">${money(rows.reduce((a, r) => a + r.wages, 0))}</div><div class="l">جمع دستمزد کارکردها</div></div></div>
      ${rows.length ? rows.map((r) => `<div class="pcard" onclick="YSPSite.party('${r.p.id}')"><div><div class="name">${esc(r.p.name)}</div><div class="client">${PARTY[r.p.kind]} · ${money(r.days)} نفر-روز${r.meters ? ` · ${money(r.meters)} متر` : ""} · دستمزد ${money(r.wages)}</div></div>${chipBal(r.bal)}</div>`).join("") : empty("هنوز کارکردی ثبت نشده.")}`;
  }
  function tabReport() {
    if (!YSPPlan.allowed()) return lockedCard("site.reports");
    const t = totals(), byP = costByProject();
    const byKind = Object.keys(KIND).map((k) => ({ k, a: list(K.entry).filter((e) => e.kind === k).reduce((x, e) => x + entryAmt(e), 0) })).filter((r) => r.a);
    return `<div class="card"><div class="lbl">📊 هزینه به تفکیک نوع</div>${byKind.length ? byKind.map((r) => `<div class="site-row"><span>${KIND[r.k]}</span><b>${money(r.a)}</b></div>`).join("") : '<div class="client">—</div>'}</div>
      <div class="card"><div class="lbl">🏗️ هزینه به تفکیک پروژه</div>${byP.length ? byP.map((r) => `<div class="site-row"><span>${esc(r.name)}</span><b>${money(r.amount)}</b></div>`).join("") : '<div class="client">—</div>'}</div>
      <div class="card"><div class="lbl">💰 جمع کل</div><div class="site-row"><span>خرید و کارکرد</span><b>${money(t.charged)}</b></div><div class="site-row"><span>پرداخت‌ها</span><b>${money(t.paid)}</b></div><div class="site-row"><span>مانده بدهی</span><b>${money(t.balance)}</b></div></div>
      <button type="button" class="save-btn" onclick="YSPSite.shareReport()">📤 کپی/ارسال گزارش</button>`;
  }

  function renderParty(host) {
    const p = partyById(S.partyId);
    if (!p) { S.partyId = null; return render(); }
    const b = balanceOf(p.id);
    const rows = [];
    list(K.entry).filter((e) => e.partyId === p.id).forEach((e) => rows.push({ kind: "entry", r: e }));
    list(K.pay).filter((x) => x.partyId === p.id).forEach((x) => rows.push({ kind: "pay", r: x }));
    rows.sort((a, c) => sortNewest(a.r, c.r));
    const isWorker = p.kind === "craftsman" || p.kind === "worker", isCon = p.kind === "contractor";
    host.innerHTML = `<button type="button" class="site-mini" onclick="YSPSite.back()">← بازگشت به حساب‌ها</button>
      <div class="card" style="margin-top:10px"><div class="lbl">${PARTY[p.kind]}${p.phone ? " · " + esc(p.phone) : ""}</div><div style="font-size:18px;font-weight:700">${esc(p.name)}</div></div>
      <div class="statgrid"><div class="stat"><div class="n">${money(b.charged)}</div><div class="l">${isWorker ? "جمع کارکرد" : isCon ? "جمع قرارداد و صورت‌وضعیت" : "جمع خرید"}</div></div><div class="stat"><div class="n">${money(b.paid)}</div><div class="l">جمع پرداخت</div></div><div class="stat" style="grid-column:1/-1"><div class="n">${money(b.balance)}</div><div class="l">مانده حساب ${b.balance > 0 ? "(بدهکارم)" : b.balance < 0 ? "(طلبکارم)" : "(تسویه)"}</div></div></div>
      <div class="site-actions">${isWorker ? `<button type="button" onclick="YSPSite.entry('work_day',{partyId:'${p.id}'})">👷 کارکرد روزمزد</button><button type="button" onclick="YSPSite.entry('work_meter',{partyId:'${p.id}'})">📐 کارکرد متری</button>` : isCon ? `<button type="button" onclick="YSPSite.entry('contract',{partyId:'${p.id}'})">📝 قرارداد / صورت‌وضعیت</button>` : `<button type="button" onclick="YSPSite.entry('material',{partyId:'${p.id}'})">🧱 ثبت خرید</button><button type="button" onclick="YSPSite.entry('expense',{partyId:'${p.id}'})">🧾 هزینه</button>`}<button type="button" onclick="YSPSite.pay({partyId:'${p.id}'})">${isCon ? "💸 پرداخت به پیمانکار" : "💸 ثبت پرداخت"}</button><button type="button" onclick="YSPSite.shareParty('${p.id}')">📤 کپی/ارسال صورت‌حساب</button></div>
      <div class="card"><div class="lbl">📒 سابقه (تاریخ و ساعت ثبت)</div>${rows.length ? rows.map((x) => {
        if (x.kind === "entry") { const e = x.r; return `<div class="site-row"><div><b>${KIND[e.kind]}${e.title ? ": " + esc(e.title) : ""}</b><div class="s">${esc(YSP.dtShow(e.date, e.at))}${e.qty ? ` · ${money(e.qty)}${e.unit ? " " + esc(e.unit) : e.kind === "work_meter" ? " متر" : " روز"}${e.kind === "work_day" && e.count > 1 ? ` × ${money(e.count)} نفر` : ""}` : ""}${e.invoiceNo ? " · فاکتور " + esc(e.invoiceNo) : ""}${e.projectId ? " · " + esc(projectName(e.projectId)) : ""}</div></div><div style="text-align:left"><div>${money(e.amount)}</div><button type="button" class="site-mini" onclick="YSPSite.entry('',{id:'${e.id}'})">✏️</button> <button type="button" class="site-mini red" onclick="YSPSite.delEntry('${e.id}')">🗑️</button></div></div>`; }
        const q = x.r, st = q.method === "check" ? checkState(q) : null;
        return `<div class="site-row"><div><b>پرداخت — ${METHOD[q.method]}</b>${st ? ` <span class="chip ${st.cls}">${esc(st.text)}</span>` : ""}<div class="s">${esc(YSP.dtShow(q.date, q.at))}${q.method === "check" ? ` · چک ${esc(q.checkNo || "—")} · سررسید ${esc(YSP.jalali(q.dueDate))}` : ""}</div></div><div style="text-align:left"><div style="color:#7fc79a">−${money(q.amount)}</div><button type="button" class="site-mini" onclick="YSPSite.pay({id:'${q.id}'})">✏️</button> <button type="button" class="site-mini red" onclick="YSPSite.delPay('${q.id}')">🗑️</button></div></div>`;
      }).join("") : '<div class="client">هنوز چیزی ثبت نشده.</div>'}</div>
      <button type="button" class="del-btn" onclick="YSPSite.delParty('${p.id}')">🗑️ حذف این طرف حساب</button>`;
  }

  const TAB_ORDER = ["accounts", "work", "stock", "insurance", "checks", "invoices", "report"];
  const TABS = { accounts: ["حساب‌ها", tabAccounts], work: ["کارکرد", tabWork], invoices: ["فاکتورها", tabInvoices], checks: ["چک‌ها", tabChecks], report: ["گزارش", tabReport] };
  const registerTab = (key, label, fn) => { TABS[key] = [label, fn]; };

  function render() {
    const host = $("site-main"); if (!host) return;
    refreshBadge();
    if (S.partyId) { renderParty(host); return; }
    const t = totals();
    const tabs = TAB_ORDER.filter((k) => TABS[k]).map((k) => [k, TABS[k][0]]);
    const body = (TABS[S.tab] || TABS.accounts)[1]();
    host.innerHTML = `${alertsHtml()}
      <div class="statgrid"><div class="stat"><div class="n">${money(t.charged)}</div><div class="l">جمع خرید و کارکرد</div></div><div class="stat"><div class="n">${money(t.paid)}</div><div class="l">جمع پرداخت</div></div><div class="stat"><div class="n">${money(t.balance)}</div><div class="l">مانده بدهی</div></div><div class="stat"><div class="n">${YSPPlan.allowed() ? money(t.pendingCount) : "⭐"}</div><div class="l">${YSPPlan.allowed() ? "چک در راه · " + money(t.pendingAmount) : "چک‌ها (اشتراکی)"}</div></div></div>
      <div class="site-actions"><button type="button" onclick="YSPSite.entry('material')">🧱 خرید مصالح</button><button type="button" onclick="YSPSite.entry('work_day')">👷 کارکرد روزمزد</button><button type="button" onclick="YSPSite.entry('work_meter')">📐 کارکرد متری</button><button type="button" onclick="YSPSite.pay()">💸 ثبت پرداخت</button><button type="button" onclick="YSPSite.entry('expense')">🧾 هزینه متفرقه</button><button type="button" onclick="YSPSite.entry('contract')">📝 قرارداد پیمانکار</button><button type="button" onclick="YSPSite.pay({kinds:['contractor']})">🏗️ پول داده به پیمانکار</button></div>
      <div class="site-tabs">${tabs.map(([k, l]) => `<button type="button" class="site-tab ${S.tab === k ? "on" : ""}" onclick="YSPSite.tab('${k}')">${l}</button>`).join("")}</div>${body}`;
  }

  root.YSPSite = {
    render, open, tab: setTab, setFilter, back: () => { S.partyId = null; render(); }, party: (id) => { S.partyId = id; render(); window.scrollTo(0, 0); },
    openParty, saveParty, delParty: deleteParty, entry: openEntry, saveEntry, recalc, delEntry: deleteEntry,
    pay: openPay, savePay, methodChanged, delPay: deletePay, checkStatus: setCheckStatus, calendar: addToCalendar,
    changeDate, closeSheet, shareParty: (id) => share(statementText(id)), shareReport: () => share(reportText()),
    alertsHtml, refreshBadge, alerts: alertChecks, allAlerts, balanceOf, totals, buildIcs, statementText,
    paidToContractor, financeRows, registerTab, registerAlerts,
    api: { S, list, uid, today, money, num, sheet, closeSheet, setErr, dateCardHtml, projectSelectHtml, partySelectHtml, resolveParty, lockedCard, empty, render, projectName, partyById, pname, buildIcsEvent, downloadText, checkStateFor: checkState, share, KIND, PARTY },
  };
  refreshBadge();
})(window);
