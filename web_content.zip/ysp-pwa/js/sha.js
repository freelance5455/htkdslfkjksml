/* Small dependency-free SHA-256, HMAC-SHA256 and PBKDF2-HMAC-SHA256.
   WebCrypto is only available on secure origins (https). Apps packaged from HTML run from file://,
   where it is missing, so Stone Pro falls back to this code. Results are identical to WebCrypto
   (checked against the standard test vectors and against WebCrypto itself in the test suite). */
"use strict";
(function (root) {
  const K = new Uint32Array([
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
  ]);
  const IV = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];

  /** Processes one 64-byte block held in w[0..15]; w must have room for 64 words. */
  function compress(st, w) {
    for (let i = 16; i < 64; i++) {
      const a = w[i - 15], b = w[i - 2];
      const s0 = ((a >>> 7) | (a << 25)) ^ ((a >>> 18) | (a << 14)) ^ (a >>> 3);
      const s1 = ((b >>> 17) | (b << 15)) ^ ((b >>> 19) | (b << 13)) ^ (b >>> 10);
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
    }
    let a = st[0], b = st[1], c = st[2], d = st[3], e = st[4], f = st[5], g = st[6], h = st[7];
    for (let i = 0; i < 64; i++) {
      const S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
      const t1 = (h + S1 + ((e & f) ^ (~e & g)) + K[i] + w[i]) | 0;
      const S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
      const t2 = (S0 + ((a & b) ^ (a & c) ^ (b & c))) | 0;
      h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
    }
    st[0] = (st[0] + a) | 0; st[1] = (st[1] + b) | 0; st[2] = (st[2] + c) | 0; st[3] = (st[3] + d) | 0;
    st[4] = (st[4] + e) | 0; st[5] = (st[5] + f) | 0; st[6] = (st[6] + g) | 0; st[7] = (st[7] + h) | 0;
  }

  function loadBlock(dv, off, w) { for (let i = 0; i < 16; i++) w[i] = dv.getUint32(off + i * 4); }
  function digestBytes(st) {
    const out = new Uint8Array(32), dv = new DataView(out.buffer);
    for (let i = 0; i < 8; i++) dv.setUint32(i * 4, st[i] >>> 0);
    return out;
  }

  /** Finishes a hash that already consumed `prefixLen` bytes (state `st`) with the final bytes `tail`. */
  function finish(st, tail, prefixLen) {
    const len = tail.length, total = prefixLen + len;
    const padded = ((len + 9 + 63) >> 6) << 6;
    const buf = new Uint8Array(padded);
    buf.set(tail); buf[len] = 0x80;
    const dv = new DataView(buf.buffer), bits = total * 8;
    dv.setUint32(padded - 8, Math.floor(bits / 0x100000000));
    dv.setUint32(padded - 4, bits >>> 0);
    const w = new Uint32Array(64);
    for (let off = 0; off < padded; off += 64) { loadBlock(dv, off, w); compress(st, w); }
    return st;
  }

  function sha256(bytes) { return digestBytes(finish(Uint32Array.from(IV), bytes, 0)); }

  function hmacStates(key) {
    if (key.length > 64) key = sha256(key);
    const ip = new Uint8Array(64).fill(0x36), op = new Uint8Array(64).fill(0x5c);
    for (let i = 0; i < key.length; i++) { ip[i] ^= key[i]; op[i] ^= key[i]; }
    const w = new Uint32Array(64), inner = Uint32Array.from(IV), outer = Uint32Array.from(IV);
    loadBlock(new DataView(ip.buffer), 0, w); compress(inner, w);
    loadBlock(new DataView(op.buffer), 0, w); compress(outer, w);
    return { inner, outer };
  }

  function hmac(key, msg) {
    const s = hmacStates(key);
    const innerDigest = digestBytes(finish(Uint32Array.from(s.inner), msg, 64));
    return digestBytes(finish(Uint32Array.from(s.outer), innerDigest, 64));
  }

  /** PBKDF2-HMAC-SHA256, 32-byte output (one block). */
  function pbkdf2(password, salt, iterations) {
    const s = hmacStates(password);
    const first = new Uint8Array(salt.length + 4);
    first.set(salt); first[salt.length + 3] = 1;
    let u = Uint32Array.from(finish(Uint32Array.from(s.outer), digestBytes(finish(Uint32Array.from(s.inner), first, 64)), 64));
    const t = Uint32Array.from(u);
    const w = new Uint32Array(64), st = new Uint32Array(8);
    w[8] = 0x80000000; w[15] = 768; // fixed padding for a 32-byte message after a 64-byte key block
    for (let i = 1; i < iterations; i++) {
      w.set(u, 0); st.set(s.inner); compress(st, w);
      w.set(st, 0); st.set(s.outer); compress(st, w);
      u.set(st);
      for (let j = 0; j < 8; j++) t[j] ^= u[j];
    }
    return digestBytes(t);
  }

  const hex = (u8) => Array.from(u8).map((b) => b.toString(16).padStart(2, "0")).join("");
  root.YSPHash = { sha256, hmac, pbkdf2, hex };
})(window);
