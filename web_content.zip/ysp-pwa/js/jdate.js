/* Stone Pro Jalali (Persian) dates. Conversions use the browser's built-in Persian calendar, the same
   source the rest of the app uses to display dates, so what the user picks always matches what is shown.
   Dates are stored as Gregorian ISO strings (YYYY-MM-DD); only the screen speaks Jalali. */
"use strict";
(function (root) {
  const MONTHS = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"];
  const parts = new Intl.DateTimeFormat("en-u-ca-persian-nu-latn", { year: "numeric", month: "numeric", day: "numeric", timeZone: "UTC" });
  const pad = (n) => String(n).padStart(2, "0");
  const DAY = 86400000;
  const isoOf = (d) => `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
  const utcNoon = (iso) => { const [y, m, d] = iso.split("-").map(Number); return new Date(Date.UTC(y, m - 1, d, 12)); };
  const faNum = (n) => Number(n).toLocaleString("fa-IR", { useGrouping: false });

  function toJalali(iso) {
    const o = {};
    parts.formatToParts(utcNoon(iso)).forEach((p) => { if (p.type === "year" || p.type === "month" || p.type === "day") o[p.type] = Number(p.value); });
    return { y: o.year, m: o.month, d: o.day };
  }
  const dayOfYear = (m, d) => (m <= 6 ? (m - 1) * 31 : 186 + (m - 7) * 30) + (d - 1);
  const ordinal = (y, m, d) => y * 400 + dayOfYear(m, d);

  /** Jalali y/m/d -> Gregorian ISO, or null when that Jalali date does not exist. */
  function toGregorian(jy, jm, jd) {
    let t = Date.UTC(jy + 621, 2, 21, 12) + dayOfYear(jm, jd) * DAY;
    for (let i = 0; i < 8; i++) {
      const iso = isoOf(new Date(t));
      const j = toJalali(iso);
      if (j.y === jy && j.m === jm && j.d === jd) return iso;
      t += (ordinal(jy, jm, jd) - ordinal(j.y, j.m, j.d)) * DAY;
    }
    return null;
  }
  function monthLength(jy, jm) {
    if (jm <= 6) return 31;
    if (jm <= 11) return 30;
    return toGregorian(jy, 12, 30) ? 30 : 29;
  }
  /** Same Jalali day n months later (clamped to the month length), as a Gregorian ISO date. */
  function addMonths(iso, n) {
    const j = toJalali(iso);
    const idx = j.m - 1 + n, y = j.y + Math.floor(idx / 12), m = ((idx % 12) + 12) % 12 + 1;
    return toGregorian(y, m, Math.min(j.d, monthLength(y, m)));
  }
  const addDays = (iso, n) => isoOf(new Date(utcNoon(iso).getTime() + n * DAY));
  const daysBetween = (a, b) => Math.round((utcNoon(b) - utcNoon(a)) / DAY);

  /* ---------- picker ---------- */
  const css = document.createElement("style");
  css.textContent = `
  #ysp-date-modal{position:fixed;inset:0;background:rgba(0,0,0,.8);display:none;align-items:center;justify-content:center;z-index:100002;padding:18px;direction:rtl}
  #ysp-date-modal.open{display:flex}
  #ysp-date-box{width:min(340px,94vw);background:#141210;border:1px solid #cda43e;border-radius:18px;padding:18px;color:#f3f1ec;display:flex;flex-direction:column;gap:12px;font-family:inherit}
  #ysp-date-box h3{margin:0;font-size:16px}
  #ysp-date-row{display:grid;grid-template-columns:1.1fr 1.4fr 1fr;gap:8px}
  #ysp-date-box select{padding:12px 8px;border-radius:12px;border:1px solid #2a2620;background:#0b0b0b;color:#f3f1ec;font-family:inherit;font-size:15px}
  #ysp-date-box .row{display:flex;gap:8px}
  #ysp-date-box button{flex:1;padding:12px;border-radius:12px;border:1px solid #2a2620;background:transparent;color:#9a958a;font-family:inherit;font-size:14px}
  #ysp-date-box button.go{background:linear-gradient(160deg,#e6c265,#cda43e);color:#0b0b0b;border:0;font-weight:700}`;
  document.head.appendChild(css);

  function pick(opts) {
    opts = opts || {};
    return new Promise((resolve) => {
      const todayISO = YSP.isoDate();
      let cur = toJalali(opts.value || todayISO);
      let m = document.getElementById("ysp-date-modal");
      if (!m) {
        m = document.createElement("div");
        m.id = "ysp-date-modal";
        m.innerHTML = '<div id="ysp-date-box" role="dialog" aria-modal="true"></div>';
        document.body.appendChild(m);
      }
      const box = m.querySelector("#ysp-date-box");
      const nowY = toJalali(todayISO).y;
      const from = Math.min(nowY - 3, cur.y), to = Math.max(nowY + 5, cur.y);
      let years = "";
      for (let y = from; y <= to; y++) years += `<option value="${y}">${faNum(y)}</option>`;
      box.innerHTML = `<h3>${opts.title || "انتخاب تاریخ"}</h3>
        <div id="ysp-date-row"><select id="ysp-jy" aria-label="سال">${years}</select>
        <select id="ysp-jm" aria-label="ماه">${MONTHS.map((n, i) => `<option value="${i + 1}">${n}</option>`).join("")}</select>
        <select id="ysp-jd" aria-label="روز"></select></div>
        <div class="row"><button type="button" id="ysp-date-today">امروز</button></div>
        <div class="row"><button type="button" class="go" id="ysp-date-ok">تأیید</button><button type="button" id="ysp-date-cancel">انصراف</button></div>`;
      const sy = box.querySelector("#ysp-jy"), sm = box.querySelector("#ysp-jm"), sd = box.querySelector("#ysp-jd");
      function fillDays(day) {
        const n = monthLength(Number(sy.value), Number(sm.value));
        let o = "";
        for (let d = 1; d <= n; d++) o += `<option value="${d}">${faNum(d)}</option>`;
        sd.innerHTML = o;
        sd.value = String(Math.min(day, n));
      }
      function setTo(j) { sy.value = String(j.y); sm.value = String(j.m); fillDays(j.d); }
      setTo(cur);
      sy.onchange = sm.onchange = () => fillDays(Number(sd.value));
      const done = (v) => { m.classList.remove("open"); resolve(v); };
      box.querySelector("#ysp-date-today").onclick = () => setTo(toJalali(todayISO));
      box.querySelector("#ysp-date-cancel").onclick = () => done(null);
      box.querySelector("#ysp-date-ok").onclick = () => done(toGregorian(Number(sy.value), Number(sm.value), Number(sd.value)));
      m.classList.add("open");
    });
  }

  root.YSPDate = { MONTHS, toJalali, toGregorian, monthLength, addDays, addMonths, daysBetween, pick };
})(window);
