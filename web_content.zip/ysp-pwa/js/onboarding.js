/* Stone Pro onboarding: (1) the user must accept the terms before entering, (2) the user picks who
   they are: owner/employer, contractor (with a trade) or worker. The choice changes which tiles,
   labels and reports the app shows. Accepting the terms is stored with the exact date, time and
   version, and again whenever the terms text changes. */
"use strict";
(function (root) {
  const TERMS_VERSION = "2026-10-14";
  const LEGAL_KEY = "ysp_legal";

  /* NOTE FOR THE OWNER: this is a careful draft, not legal advice. Have a lawyer read it before the
     paid release, and bump TERMS_VERSION whenever the text changes so everyone accepts it again. */
  const TERMS = [
    ["۱. ماهیت برنامه", "Stone Pro ابزاری برای ثبت و مدیریت اطلاعات پروژه‌های ساختمانی است (پروژه، کارکرد، هزینه، گزارش و …). این برنامه مشاور حقوقی، مالیاتی، بیمه‌ای، مهندسی یا حسابداری رسمی نیست و جایگزین قرارداد رسمی، سند مالی یا نظر متخصص نمی‌شود."],
    ["۲. مسئولیت اطلاعات", "درستی همه‌ی اطلاعاتی که وارد می‌کنی (مبلغ‌ها، تاریخ‌ها، متن قراردادها، نام و شماره‌ها) و بررسی نتیجه‌ی محاسبه‌ها و گزارش‌ها با خود توست."],
    ["۳. قرارداد و مدارک", "متن قرارداد و برآورد داخل برنامه فقط یادداشت شخصی تو است. اعتبار قانونی آن‌ها به رعایت قوانین و امضای طرفین بستگی دارد و برنامه طرف هیچ قراردادی نیست."],
    ["۴. مالی، بیمه و سررسید", "گزارش‌ها و هشدارها (از جمله بیمه و سررسید) فقط کمک‌یادآور هستند و جای اعلام رسمی سازمان‌هایی مثل تأمین اجتماعی و سازمان مالیاتی را نمی‌گیرند. پرداخت و پیگیری به‌موقع با خود توست."],
    ["۵. اطلاعات دیگران", "اگر نام، تلفن، مبلغ یا عکس افراد دیگر (کارفرما، پیمانکار، کارگر) را ثبت می‌کنی، تأیید می‌کنی حق ثبت آن را داری و آن را برای کار غیرقانونی، آزار یا فریب استفاده نمی‌کنی. فرستادن آن‌ها به دیگران با مسئولیت خودت است."],
    ["۶. حریم خصوصی و محل ذخیره", "در این نسخه، اطلاعات فقط روی دستگاه خودت ذخیره می‌شود و برنامه آن‌ها را به هیچ سروری نمی‌فرستد. فقط وقتی فایل پشتیبان یا گزارشی را خودت ارسال کنی، آن اطلاعات از دستگاه خارج می‌شود. اگر در آینده خدمات آنلاین اضافه شود، شرایطش جداگانه اعلام و دوباره از تو تأیید گرفته می‌شود."],
    ["۷. پشتیبان‌گیری و رمز", "گرفتن پشتیبان با توست. پاک شدن اطلاعات مرورگر، گم شدن یا خراب شدن گوشی ممکن است به از بین رفتن اطلاعات منجر شود. رمز فراموش‌شده قابل بازیابی نیست."],
    ["۸. استفاده مجاز", "استفاده برخلاف قوانین، مثل جعل سند، پنهان‌کردن درآمد برای فرار از تعهدات قانونی یا ثبت اطلاعات خلاف واقع برای فریب دیگران، ممنوع است و مسئولیت آن فقط با کاربر است."],
    ["۹. محدودیت مسئولیت", "برنامه «همان‌طور که هست» ارائه می‌شود. تلاش شده بدون خطا باشد ولی بدون خطا بودن تضمین نمی‌شود. تا حدی که قانون اجازه می‌دهد، سازنده مسئول خسارت ناشی از خطای برنامه، از دست رفتن اطلاعات یا تصمیم‌های مالی و حقوقی کاربر نیست."],
    ["۱۰. اشتراک و پرداخت", "اگر بخش‌هایی پولی شود، قیمت، مدت، تمدید و شرایط بازپرداخت پیش از هر پرداخت جداگانه اعلام می‌شود."],
    ["۱۱. تغییر مقررات", "این مقررات ممکن است به‌روز شود. با هر تغییر، نسخه‌ی جدید هنگام ورود برای تأیید دوباره نشان داده می‌شود."],
    ["۱۲. قانون حاکم", "این مقررات تابع قوانین جمهوری اسلامی ایران است."],
  ];

  const TRADES = [
    ["پیمانکار عمومی (چند صنف)", ["متر مربع", "متر طول", "متر مکعب", "عدد", "نقطه", "روز کار"]],
    ["سنگ‌کار", ["متر مربع", "متر طول", "پله", "جلوپله", "عدد", "روز کار"]],
    ["کاشی‌کار و سرامیک‌کار", ["متر مربع", "متر طول", "عدد", "روز کار"]],
    ["گچ‌کار و نازک‌کار", ["متر مربع", "متر طول", "روز کار"]],
    ["نقاش ساختمان", ["متر مربع", "متر طول", "دست", "روز کار"]],
    ["برقکار ساختمان", ["نقطه", "متر طول", "عدد", "روز کار"]],
    ["لوله‌کش و تأسیسات", ["نقطه", "متر طول", "عدد", "روز کار"]],
    ["جوشکار و آهنگر", ["کیلوگرم", "متر طول", "متر مربع", "عدد", "روز کار"]],
    ["نجار و کابینت‌ساز", ["متر طول", "متر مربع", "عدد", "روز کار"]],
    ["بنّا و آجرکار", ["متر مربع", "متر مکعب", "روز کار"]],
    ["بتن‌کار و قالب‌بند", ["متر مکعب", "متر مربع", "روز کار"]],
    ["نماکار", ["متر مربع", "متر طول", "روز کار"]],
    ["عایق‌کار", ["متر مربع", "متر طول", "روز کار"]],
    ["کفساز و موزائیک‌کار", ["متر مربع", "متر طول", "روز کار"]],
    ["سایر (خودم می‌نویسم)", ["متر مربع", "متر طول", "عدد", "روز کار"]],
  ];
  const OTHER = TRADES.length - 1;

  const HOME_SUB = { owner: "صاحبکار / کارفرما", contractor: "پیمانکار", worker: "کارگر" };
  const LABELS_OWNER = new WeakMap();

  /* ---------- styles ---------- */
  const css = document.createElement("style");
  css.textContent = `
  body[data-role="owner"] [data-for]:not([data-for~="owner"]),
  body[data-role="contractor"] [data-for]:not([data-for~="contractor"]),
  body[data-role="worker"] [data-for]:not([data-for~="worker"]){display:none!important}
  .ysp-gate{position:fixed;inset:0;z-index:150000;background:#0b0b0b;display:none;flex-direction:column;direction:rtl;color:#f3f1ec;font-family:inherit}
  .ysp-gate.open{display:flex}
  .ysp-gate-head{padding:18px 18px 10px;text-align:center;border-bottom:1px solid #2a2620}
  .ysp-gate-head img{height:46px;width:auto}
  .ysp-gate-head h2{margin:8px 0 0;font-size:17px}
  .ysp-gate-body{flex:1;overflow-y:auto;padding:14px 16px;font-size:13.5px;line-height:2}
  .ysp-gate-foot{padding:12px 16px calc(14px + env(safe-area-inset-bottom,0px));border-top:1px solid #2a2620;display:flex;flex-direction:column;gap:10px}
  .ysp-terms-item{margin-bottom:10px}.ysp-terms-item b{color:#e6c265;display:block}
  .ysp-check{display:flex;gap:10px;align-items:center;font-size:13.5px}
  .ysp-check input{width:22px;height:22px;accent-color:#cda43e}
  .ysp-check.off{opacity:.45}
  .ysp-hint{font-size:11.5px;color:#9a958a;text-align:center;min-height:16px}
  .ysp-gate .ysp-btn{width:100%}
  .ysp-gate .ysp-btn[disabled]{opacity:.4}
  .ysp-role-card{background:#141210;border:1px solid #2a2620;border-radius:16px;padding:16px;margin-bottom:12px;text-align:right;cursor:pointer;width:100%;color:inherit;font-family:inherit}
  .ysp-role-card:active,.ysp-role-card.sel{border-color:#cda43e;background:#1a1712}
  .ysp-role-card .t{font-size:16px;font-weight:700;color:#e6c265}
  .ysp-role-card .d{font-size:12.5px;color:#9a958a;margin-top:4px;line-height:1.8}
  .ysp-field{display:block;margin-bottom:12px;font-size:12.5px;color:#9a958a}
  .ysp-field input,.ysp-field select{display:block;width:100%;margin-top:6px;padding:13px;border-radius:12px;border:1px solid #2a2620;background:#141210;color:#f3f1ec;font-family:inherit;font-size:15px;outline:none}
  .ysp-field input:focus,.ysp-field select:focus{border-color:#cda43e}`;
  document.head.appendChild(css);

  /* ---------- helpers ---------- */
  const $ = (sel, el) => (el || document).querySelector(sel);
  function gate(id, title) {
    let g = document.getElementById(id);
    if (g) return g;
    g = document.createElement("div");
    g.id = id; g.className = "ysp-gate"; g.setAttribute("role", "dialog"); g.setAttribute("aria-modal", "true");
    g.innerHTML = `<div class="ysp-gate-head"><img src="img/ya-logo.png" alt="YA"><h2>${title}</h2></div><div class="ysp-gate-body"></div><div class="ysp-gate-foot"></div>`;
    document.body.appendChild(g);
    return g;
  }
  const legal = () => { try { return JSON.parse(localStorage.getItem(LEGAL_KEY) || "null"); } catch (e) { return null; } };
  const termsOk = () => { const l = legal(); return !!(l && l.version === TERMS_VERSION && l.at); };

  /* ---------- terms ---------- */
  function termsHtml() {
    return TERMS.map(([h, t]) => `<div class="ysp-terms-item"><b>${esc(h)}</b>${esc(t)}</div>`).join("") +
      `<div class="ysp-hint">نسخه‌ی مقررات: ${esc(TERMS_VERSION)}</div>`;
  }
  function openTerms() {
    const g = gate("ysp-terms", "مقررات استفاده از Stone Pro");
    const body = $(".ysp-gate-body", g), foot = $(".ysp-gate-foot", g);
    body.innerHTML = `<p style="margin-top:0">قبل از ورود، لطفاً مقررات زیر را تا آخر بخوان.</p>${termsHtml()}`;
    foot.innerHTML = `<label class="ysp-check off" id="ysp-terms-check-row"><input type="checkbox" id="ysp-terms-check" disabled><span>مقررات را خوانده‌ام و می‌پذیرم</span></label>
      <div class="ysp-hint" id="ysp-terms-hint">برای فعال شدن گزینه‌ی پذیرش، متن را تا آخر پایین ببر.</div>
      <button class="ysp-btn" id="ysp-terms-go" type="button" disabled>ادامه و ورود</button>
      <button class="ysp-btn ghost" id="ysp-terms-no" type="button">نمی‌پذیرم</button>`;
    g.classList.add("open");
    const chk = $("#ysp-terms-check", g), go = $("#ysp-terms-go", g), hint = $("#ysp-terms-hint", g), row = $("#ysp-terms-check-row", g);
    const atEnd = () => body.scrollHeight - body.scrollTop - body.clientHeight < 12;
    const unlock = () => { if (!atEnd()) return; chk.disabled = false; row.classList.remove("off"); hint.textContent = ""; };
    body.onscroll = unlock; setTimeout(unlock, 80);
    chk.onchange = () => { go.disabled = !chk.checked; };
    $("#ysp-terms-no", g).onclick = () => { hint.textContent = "بدون پذیرش مقررات نمی‌توانی از برنامه استفاده کنی."; };
    go.onclick = () => {
      if (!chk.checked) return;
      const rec = { version: TERMS_VERSION, at: YSP.nowISO() };
      localStorage.setItem(LEGAL_KEY, JSON.stringify(rec));
      YSP.log("terms_accepted", "legal", "", "پذیرش مقررات نسخه‌ی " + TERMS_VERSION);
      g.classList.remove("open");
      start();
    };
  }
  function showTerms() {
    const g = gate("ysp-terms-view", "مقررات و حریم خصوصی");
    $(".ysp-gate-body", g).innerHTML = termsHtml();
    $(".ysp-gate-foot", g).innerHTML = `<div class="ysp-hint">${esc(acceptedText())}</div><button class="ysp-btn" id="ysp-terms-close" type="button">بستن</button>`;
    g.classList.add("open");
    $("#ysp-terms-close", g).onclick = () => g.classList.remove("open");
  }
  function acceptedText() {
    const l = legal();
    return l ? `پذیرفته‌شده در ${YSP.dtShow("", l.at)} (نسخه‌ی ${l.version})` : "هنوز پذیرفته نشده";
  }

  /* ---------- role + trade ---------- */
  function summary() {
    const p = YSP.profile();
    if (!p) return "هنوز انتخاب نشده";
    return (HOME_SUB[p.userType] || "—") + (p.userType === "contractor" && p.trade ? " · " + p.trade : "") + (p.name ? " · " + p.name : "");
  }
  function openRole(canCancel) {
    const g = gate("ysp-role", "نقش خود را انتخاب کنید");
    const body = $(".ysp-gate-body", g), foot = $(".ysp-gate-foot", g);
    const cur = YSP.profile() || {};
    const chosen = { userType: cur.userType || "", trade: cur.trade || "", name: cur.name || "" };
    g.classList.add("open");

    function stepRole() {
      body.innerHTML = `<p style="margin-top:0;color:#9a958a">یکی را انتخاب کنید. برنامه فقط بخش‌های مناسب شما را نشان می‌دهد و اطلاعاتی حذف نمی‌شود.</p>
        <button class="ysp-role-card ${chosen.userType === "owner" ? "sel" : ""}" data-r="owner" type="button"><div class="t">🏠 صاحبکار / کارفرما</div><div class="d">خرید مصالح، هزینه‌ها، پرداخت به فروشنده‌ها، کارگرها و استادکارها، فاکتورها و چک‌های داده‌شده را مدیریت می‌کنم و قرارداد پیمانکارها را دنبال می‌کنم.</div></button>
        <button class="ysp-role-card ${chosen.userType === "contractor" ? "sel" : ""}" data-r="contractor" type="button"><div class="t">🧱 پیمانکار</div><div class="d">پروژه‌ها، کارگرها، مصالح، حساب و گزارش کارم را مدیریت می‌کنم. صنفم را انتخاب می‌کنم. (بعضی امکانات اشتراکی می‌شود)</div></button>
        <button class="ysp-role-card ${chosen.userType === "worker" ? "sel" : ""}" data-r="worker" type="button"><div class="t">👷 کارگر</div><div class="d">نرخ کارکرد، روزهای کار و تعطیلی و پول‌های دریافتی‌ام را با تاریخ ثبت می‌کنم و مانده حسابم نزد کارفرما را می‌بینم. این بخش همیشه رایگان است.</div></button>`;
      foot.innerHTML = canCancel ? '<button class="ysp-btn ghost" id="ysp-role-cancel" type="button">انصراف</button>' : "";
      body.querySelectorAll(".ysp-role-card").forEach((b) => { b.onclick = () => { chosen.userType = b.dataset.r; stepDetails(); }; });
      const c = $("#ysp-role-cancel", g); if (c) c.onclick = () => g.classList.remove("open");
    }

    function stepDetails() {
      const needsTrade = chosen.userType === "contractor";
      const idx = TRADES.findIndex((t) => t[0] === chosen.trade);
      const isOther = chosen.trade && idx === -1;
      const options = TRADES.map((t, i) => `<option value="${i}" ${(idx === i || (isOther && i === OTHER)) ? "selected" : ""}>${esc(t[0])}</option>`).join("");
      body.innerHTML = `<p style="margin-top:0;color:#9a958a">${esc(HOME_SUB[chosen.userType])}</p>
        ${needsTrade ? `<label class="ysp-field">صنف<select id="ysp-trade"><option value="">انتخاب کن…</option>${options}</select></label>
        <label class="ysp-field" id="ysp-trade-other-row" style="display:${isOther ? "block" : "none"}">نام صنف<input id="ysp-trade-other" type="text" maxlength="40" value="${isOther ? esc(chosen.trade) : ""}"></label>` : ""}
        <label class="ysp-field">نام تو (اختیاری)<input id="ysp-name" type="text" maxlength="40" value="${esc(chosen.name)}"></label>
        <div class="ysp-hint" id="ysp-role-err" style="color:#d97b7b"></div>`;
      foot.innerHTML = `<button class="ysp-btn" id="ysp-role-save" type="button">شروع</button><button class="ysp-btn ghost" id="ysp-role-back" type="button">بازگشت</button>`;
      const sel = $("#ysp-trade", g);
      if (sel) sel.onchange = () => { $("#ysp-trade-other-row", g).style.display = Number(sel.value) === OTHER && sel.value !== "" ? "block" : "none"; };
      $("#ysp-role-back", g).onclick = stepRole;
      $("#ysp-role-save", g).onclick = () => {
        let trade = "";
        if (needsTrade) {
          if (!sel.value) { $("#ysp-role-err", g).textContent = "صنف را انتخاب کن."; return; }
          trade = Number(sel.value) === OTHER ? ($("#ysp-trade-other", g).value || "").trim() : TRADES[Number(sel.value)][0];
          if (!trade) { $("#ysp-role-err", g).textContent = "نام صنف را بنویس."; return; }
        }
        const now = YSP.nowISO();
        const rec = { id: "profile", userType: chosen.userType, trade, name: ($("#ysp-name", g).value || "").trim(), createdAt: cur.createdAt || now, updatedAt: now };
        if (!setArr("ysp_profile", [rec])) return;
        g.classList.remove("open");
        applyRole();
        if (typeof go === "function") go("home");
      };
    }
    stepRole();
  }

  /* ---------- applying the role to the screens ---------- */
  function unitsFor(trade) {
    const t = TRADES.find((x) => x[0] === trade);
    return t ? t[1] : TRADES[OTHER][1];
  }
  function ensureSelfWorker(p) {
    const list = getArr("ysp_workers");
    if (list.some((w) => w.id === "wself")) return;
    const now = YSP.isoDate();
    list.push({ id: "wself", name: p.name || "من", role: p.trade || "", phone: "", wage: "", workDays: 0, holidayDays: 0, paid: 0, paidDate: "", holidayWorkDate: "", received: 0, createdDate: now, updatedDate: now });
    setArr("ysp_workers", list);
  }
  function relabel(role) {
    document.querySelectorAll("[data-label-owner]").forEach((el) => {
      if (!LABELS_OWNER.has(el)) LABELS_OWNER.set(el, el.textContent);
      el.textContent = role === "owner" ? el.dataset.labelOwner : LABELS_OWNER.get(el);
    });
  }
  function applyRole() {
    const p = YSP.profile();
    if (!p) { delete document.body.dataset.role; delete document.body.dataset.trade; return; }
    document.body.dataset.role = p.userType;
    document.body.dataset.trade = p.trade || "";
    const sub = document.getElementById("home-sub");
    if (sub) sub.textContent = (HOME_SUB[p.userType] || "") + (p.userType === "contractor" && p.trade ? " · " + p.trade : "");
    relabel(p.userType);
    let dl = document.getElementById("ysp-units");
    if (!dl) { dl = document.createElement("datalist"); dl.id = "ysp-units"; document.body.appendChild(dl); }
    dl.innerHTML = unitsFor(p.trade).map((u) => `<option value="${esc(u)}">`).join("");
    if (p.userType === "worker") ensureSelfWorker(p);
  }

  /** Money side of one worker: days x rate (the rate at the time of entry when known) + overtime - deductions - money taken. */
  function workerEarnings(w) {
    const rows = workerEntries(w.id), rate = Number(w.wage) || 0, hrate = Number(w.holidayWage) || rate, t = workerTotals(w);
    const sum = (rs, f) => rs.reduce((a, r) => a + f(r), 0), of = (type) => rows.filter((r) => r.type === type);
    const workPay = Number(w.workDays || 0) * rate + sum(of("work"), (r) => Number(r.days || 1) * (Number(r.rate) || rate));
    const holidayPay = Number(w.holidayDays || 0) * hrate + sum(of("holiday"), (r) => Number(r.days || 1) * (Number(r.rate) || hrate));
    const overtime = sum(of("overtime"), (r) => Number(r.amount) || 0), overtimeHours = sum(of("overtime"), (r) => Number(r.hours) || 0);
    const deductions = sum(of("deduction"), (r) => Number(r.amount) || 0);
    const earned = workPay + holidayPay + overtime;
    return { t, rate, hrate, orate: Number(w.overtimeWage) || 0, workPay, holidayPay, overtime, overtimeHours, deductions, earned, received: t.paid, balance: earned - deductions - t.paid };
  }
  const currentRate = (id, type) => {
    const w = getArr("ysp_workers").find((x) => x.id === id) || {};
    return type === "holiday" ? Number(w.holidayWage) || Number(w.wage) || 0 : Number(w.wage) || 0;
  };
  let entryDateISO = null; // day the next logbook entry is recorded for (null = today)
  const entryDate = () => entryDateISO;
  const resetEntryDate = () => { entryDateISO = null; };
  function changeEntryDate() {
    YSPDate.pick({ value: entryDateISO || YSP.isoDate(), title: "تاریخ ثبت" }).then((iso) => {
      if (!iso) return;
      entryDateISO = iso === YSP.isoDate() ? null : iso;
      renderWorkerForm();
    });
  }
  const readNum = (id) => { const el = document.getElementById(id); return el ? Number(String(el.value || "").replace(/[۰-۹]/g, (d) => d.charCodeAt(0) - 1776).replace(/[,٬\s]/g, "")) || 0 : 0; };
  function saveRates() {
    const list = getArr("ysp_workers"), w = list.find((x) => x.id === curEntityId);
    if (!w) return;
    w.wage = readNum("wr-rate") || ""; w.holidayWage = readNum("wr-hrate") || "";
    if (document.getElementById("wr-orate")) w.overtimeWage = readNum("wr-orate") || "";
    w.updatedDate = YSP.isoDate();
    if (setArr("ysp_workers", list)) { YSP.toast("نرخ‌ها ذخیره شد."); renderWorkerForm(); }
  }
  function recordOvertime() {
    const w = getArr("ysp_workers").find((x) => x.id === curEntityId);
    if (!w) { alert("ابتدا اطلاعات کارگر را ذخیره کنید."); return; }
    const hours = readNum("wo-hours"), rate = readNum("wr-orate") || Number(w.overtimeWage) || 0;
    if (hours <= 0) { YSP.toast("تعداد ساعت اضافه‌کاری را وارد کن."); return; }
    if (!rate) { YSP.toast("نرخ ساعتی اضافه‌کاری را وارد کن و ذخیره کن."); return; }
    addWorkerEntry(curEntityId, "overtime", Math.round(hours * rate), `${hours} ساعت × ${fmt(rate)} تومان`, { hours, rate });
  }
  function recordDeduction() {
    const amount = readNum("wd-amount");
    if (amount <= 0) { YSP.toast("مبلغ کسری را وارد کن."); return; }
    const why = (document.getElementById("wd-reason") || {}).value || "";
    addWorkerEntry(curEntityId, "deduction", amount, why.trim() || "کسری");
  }
  /** Worker mode reuses the worker ledger screen for the worker's own logbook. */
  function openMyLog() {
    ensureSelfWorker(YSP.profile() || {});
    entryDateISO = null;
    openEntityForm("worker", "wself");
  }
  /** Adds the money summary, rates, overtime/deduction and date cards to the worker screen, by role. */
  function decorateWorkerForm() {
    const role = YSP.role(), box = document.getElementById("worker-ledger-box");
    if (!box || (role !== "worker" && role !== "owner" && role !== "contractor")) return;
    const w = getArr("ysp_workers").find((x) => x.id === curEntityId);
    if (!w) return;
    const isSelf = w.id === "wself", f = (n) => fmt(Math.round(n)), e = workerEarnings(w);
    const title = document.getElementById("ef-title");
    if (title) title.textContent = isSelf ? "کارکرد و دریافتی من" : "کارگر: " + (w.name || "");
    // wording by role
    if (role === "worker" || role === "owner") {
      const rec = box.querySelector("[onclick=\"recordWorkerMoney('receipt')\"]");
      if (rec) rec.remove();
      const pay = box.querySelector("[onclick=\"recordWorkerMoney('payment')\"]");
      if (pay) pay.textContent = role === "worker" ? "💰 ثبت دریافتی" : "💸 ثبت پول گرفته کارگر";
      const lbl = box.querySelector(".worker-money-card .lbl");
      if (lbl) lbl.textContent = role === "worker" ? "💰 مبلغ دریافتی از کارفرما" : "💸 مبلغ پول گرفته کارگر (تومان)";
      box.querySelectorAll(".stat .l").forEach((l) => {
        if (l.textContent === "پول داده") l.textContent = role === "worker" ? "دریافتی من" : "پول گرفته کارگر";
        if (l.textContent === "پول گرفته" && l.parentElement) l.parentElement.remove();
      });
    }
    const old = Array.from(box.querySelectorAll(".card")).find((c) => c.textContent.includes("تاریخ ثبت خودکار"));
    if (old) old.remove();
    const owes = role === "worker" ? "کارفرما به من بدهکار است" : "به کارگر بدهکارم";
    const over = role === "worker" ? "بیشتر از کارکرد دریافت کرده‌ام" : "کارگر بیشتر از کارکرد پول گرفته";
    const row = (l, v, sign) => `<div class="site-row"><span>${l}</span><b>${sign || ""}${f(v)}</b></div>`;
    const showOt = role !== "worker";
    box.insertAdjacentHTML("afterbegin", `
      <div class="card"><div class="lbl">⚖️ ${role === "worker" ? "مانده حساب نزد کارفرما" : "مانده حساب این کارگر"}</div>
        ${row(`کارکرد روزانه (${fmt(e.t.workDays)} روز)`, e.workPay)}${row(`کارکرد روز تعطیل (${fmt(e.t.holidayDays)} روز)`, e.holidayPay)}
        ${showOt ? row(`اضافه‌کاری (${fmt(e.overtimeHours)} ساعت)`, e.overtime) + row("کسری", e.deductions, "−") : ""}
        ${row(role === "worker" ? "دریافتی من" : "پول گرفته کارگر", e.received, "−")}
        <div class="site-row" style="border-bottom:0"><b>${e.balance > 0 ? owes : e.balance < 0 ? over : "تسویه"}</b><b class="site-total">${f(Math.abs(e.balance))}</b></div></div>
      <div class="card"><div class="lbl">💰 نرخ‌ها</div>
        <div class="client" style="margin-bottom:4px">نرخ روزمزد (تومان)</div><input id="wr-rate" type="text" inputmode="decimal" placeholder="مثلاً ۸۰۰٬۰۰۰" value="${e.rate || ""}">
        <div class="client" style="margin:10px 0 4px">نرخ روز تعطیل (اختیاری؛ خالی = همان روزمزد)</div><input id="wr-hrate" type="text" inputmode="decimal" placeholder="اختیاری" value="${w.holidayWage || ""}">
        ${showOt ? `<div class="client" style="margin:10px 0 4px">نرخ هر ساعت اضافه‌کاری (تومان)</div><input id="wr-orate" type="text" inputmode="decimal" placeholder="مثلاً ۱۲۰٬۰۰۰" value="${w.overtimeWage || ""}">` : ""}
        <div class="client" style="margin-top:6px">نرخ هر کارکرد در لحظه ثبت نگه داشته می‌شود؛ تغییر نرخ، کارکردهای قبلی را عوض نمی‌کند.</div>
        <button type="button" class="save-btn" style="margin:10px 0 0" onclick="YSPRole.saveRates()">ذخیره نرخ‌ها</button></div>
      ${showOt ? `<div class="card"><div class="lbl">⏱️ اضافه‌کاری</div><input id="wo-hours" type="text" inputmode="decimal" placeholder="تعداد ساعت"><button type="button" class="save-btn" style="margin:10px 0 0" onclick="YSPRole.recordOvertime()">ثبت اضافه‌کاری</button></div>
      <div class="card"><div class="lbl">➖ کسری</div><input id="wd-amount" type="text" inputmode="decimal" placeholder="مبلغ کسری (تومان)"><input id="wd-reason" type="text" maxlength="60" placeholder="دلیل (مثلاً غیبت، خسارت)" style="margin-top:8px"><button type="button" class="save-btn" style="margin:10px 0 0" onclick="YSPRole.recordDeduction()">ثبت کسری</button></div>` : ""}
      <div class="card"><div class="lbl">📅 تاریخ ثبت</div><div style="font-weight:700;color:var(--gold-bright)">${esc(YSP.jalali(entryDateISO || YSP.isoDate()))}${entryDateISO ? "" : " (امروز)"}</div>
        <div class="client" style="margin:5px 0 8px">تاریخ و ساعت هر ثبت خودکار نگه داشته می‌شود. برای ثبت روزهای قبل، تاریخ را عوض کن.</div><button type="button" class="site-mini" onclick="YSPRole.changeEntryDate()">تغییر تاریخ</button></div>`);
  }
  function shareOwner(id) {
    const p = getArr("ysp_projects").find((x) => x.id === id);
    if (!p) return;
    const price = Number(p.price) || 0, paid = Number(p.expense) || 0;
    YSP.share(`پروژه: ${p.name || "بدون نام"}\nپیمانکار: ${p.client || "ثبت نشده"}\nمبلغ قرارداد: ${price.toLocaleString("fa-IR")} تومان\nپرداختی: ${paid.toLocaleString("fa-IR")} تومان | ${YSP.dtShow(p.expenseDate, p.expenseAt)}\nمانده: ${(price - paid).toLocaleString("fa-IR")} تومان`);
  }

  /* ---------- start sequence ---------- */
  function start() {
    if (!termsOk()) { openTerms(); return; }
    if (!YSP.profile()) { openRole(false); return; }
    applyRole();
  }

  root.YSPRole = { start, openRole, openTerms, showTerms, applyRole, summary, acceptedText, openMyLog, decorateWorkerForm, shareOwner, workerEarnings, currentRate, entryDate, resetEntryDate, changeEntryDate, saveRates, recordOvertime, recordDeduction, termsOk, TRADES, TERMS_VERSION };
  start();
})(window);
