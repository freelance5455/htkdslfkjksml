/* Stone Pro insurance: building insurance and workers' insurance (for example social security).
   Each policy keeps its premium, the next payment due date and the end date. Alerts appear when a
   payment is close or overdue, or when a policy is about to end. Marking a premium as paid records the
   date and time and moves a monthly or yearly policy to its next due date. */
"use strict";
(function (root) {
  const K = "ysp_insurance";
  const DUE_DAYS = 7, END_DAYS = 30;
  const A = () => YSPSite.api;
  const TYPE = { building: "بیمه ساختمان", workers: "بیمه کارگران" };
  const REPEAT = { none: "یک‌بار", monthly: "ماهانه", yearly: "سالانه" };
  const $ = (id) => document.getElementById(id);
  const list = () => getArr(K);
  const money = (n) => fmt(Math.round(Number(n) || 0));
  const days = (iso) => YSPDate.daysBetween(YSP.isoDate(), iso);

  function whenText(left, doneText) {
    if (left < 0) return { text: `${money(-left)} روز گذشته`, cls: "red" };
    if (left === 0) return { text: "امروز", cls: "red" };
    if (left === 1) return { text: "فردا", cls: "amber" };
    return { text: `${money(left)} روز مانده`, cls: left <= DUE_DAYS ? "amber" : "gray" };
  }
  const subjectOf = (p) => (p.type === "building" ? (p.projectId ? A().projectName(p.projectId) : "") : (p.subject || "همه کارگران"));

  /* ---------- alerts ---------- */
  function alerts() {
    if (!YSPPlan.allowed()) return [];
    const today = YSP.isoDate(), dueLimit = YSPDate.addDays(today, DUE_DAYS), endLimit = YSPDate.addDays(today, END_DAYS), out = [];
    list().forEach((p) => {
      const label = `${TYPE[p.type]}${p.company ? " " + p.company : ""}${subjectOf(p) ? " (" + subjectOf(p) + ")" : ""}`;
      if (p.nextDue && p.nextDue <= dueLimit) out.push({ tab: "insurance", sort: p.nextDue, text: `پرداخت حق بیمه — ${label} — ${p.premium ? money(p.premium) + " تومان — " : ""}${whenText(days(p.nextDue)).text}` });
      if (p.endDate && p.endDate <= endLimit) out.push({ tab: "insurance", sort: p.endDate, text: `${days(p.endDate) < 0 ? "پایان یافته" : "پایان بیمه‌نامه"} — ${label} — ${whenText(days(p.endDate)).text}` });
    });
    return out;
  }

  /* ---------- form ---------- */
  function dateRow(field, label, optional, note) {
    const a = A(), v = a.S.fd[field];
    return `<div class="card"><div class="lbl">${label}</div><div id="sf-date-${field}" style="font-weight:700;color:var(--gold-bright)">${v ? esc(YSP.jalali(v)) : "انتخاب نشده"}</div>${note ? `<div class="client" style="margin:5px 0 8px">${note}</div>` : ""}
      <div style="display:flex;gap:8px;margin-top:6px"><button type="button" class="site-mini" onclick="YSPSite.changeDate('${field}')">انتخاب تاریخ</button>${optional ? `<button type="button" class="site-mini red" onclick="YSPIns.clearDate('${field}')">پاک کردن</button>` : ""}</div></div>`;
  }
  function clearDate(field) { A().S.fd[field] = ""; const el = $("sf-date-" + field); if (el) el.textContent = "انتخاب نشده"; }
  function typeChanged() {
    const t = $("ins-type").value;
    $("ins-building-box").style.display = t === "building" ? "block" : "none";
    $("ins-workers-box").style.display = t === "workers" ? "block" : "none";
  }
  function open(id) {
    const a = A();
    if (!YSPPlan.gate("site.insurance")) return;
    const ex = id ? list().find((x) => x.id === id) : null;
    const f = ex || { type: "building", company: "", policyNo: "", projectId: "", subject: "", premium: "", repeat: "none", nextDue: "", startDate: "", endDate: "", note: "" };
    a.S.form = { type: "insurance", id: ex ? ex.id : null };
    a.S.fd = { nextDue: f.nextDue || "", startDate: f.startDate || "", endDate: f.endDate || "" };
    const workers = getArr("ysp_workers").filter((w) => w.id !== "wself").map((w) => w.name).filter(Boolean);
    a.sheet(ex ? "ویرایش بیمه" : "ثبت بیمه", `
      <div class="card"><div class="lbl">🏷️ نوع بیمه</div><select id="ins-type" onchange="YSPIns.typeChanged()"><option value="building" ${f.type === "building" ? "selected" : ""}>بیمه ساختمان</option><option value="workers" ${f.type === "workers" ? "selected" : ""}>بیمه کارگران</option></select></div>
      <div class="card"><div class="lbl">🏢 شرکت یا سازمان بیمه</div><input id="ins-company" type="text" maxlength="60" value="${esc(f.company)}" placeholder="مثلاً بیمه ایران، تأمین اجتماعی"></div>
      <div class="card"><div class="lbl">🔢 شماره بیمه‌نامه / پرونده (اختیاری)</div><input id="ins-no" type="text" maxlength="40" value="${esc(f.policyNo)}"></div>
      <div id="ins-building-box" style="display:${f.type === "building" ? "block" : "none"}">${a.projectSelectHtml(f.projectId)}</div>
      <div id="ins-workers-box" style="display:${f.type === "workers" ? "block" : "none"}"><div class="card"><div class="lbl">👷 مشمول بیمه</div><input id="ins-subject" list="ins-wlist" type="text" maxlength="60" value="${esc(f.subject)}" placeholder="همه کارگران یا نام یک کارگر"><datalist id="ins-wlist">${workers.map((n) => `<option value="${esc(n)}">`).join("")}</datalist></div></div>
      <div class="card"><div class="lbl">💰 مبلغ حق بیمه هر نوبت (تومان)</div><input id="ins-premium" type="text" inputmode="decimal" value="${esc(f.premium)}"></div>
      <div class="card"><div class="lbl">🔁 تکرار پرداخت</div><select id="ins-repeat">${Object.keys(REPEAT).map((r) => `<option value="${r}" ${f.repeat === r ? "selected" : ""}>${REPEAT[r]}</option>`).join("")}</select></div>
      ${dateRow("nextDue", "⏰ تاریخ سررسید پرداخت حق بیمه", true, "قبل از این تاریخ در خانه هشدار می‌گیری.")}
      ${dateRow("startDate", "📅 شروع بیمه (اختیاری)", true)}
      ${dateRow("endDate", "🛑 پایان بیمه‌نامه (اختیاری)", true, "نزدیک پایان بیمه هم هشدار می‌گیری.")}
      <div class="card"><div class="lbl">🗒️ توضیحات (اختیاری)</div><textarea id="ins-note" rows="2">${esc(f.note)}</textarea></div>
      <div class="err" id="sf-err"></div><button type="button" class="save-btn" onclick="YSPIns.save()">ذخیره</button>`);
  }
  function save() {
    const a = A(), type = $("ins-type").value, company = $("ins-company").value.trim();
    if (!company) return a.setErr("نام شرکت یا سازمان بیمه را بنویس.");
    if (!a.S.form.id && !a.S.fd.nextDue && !a.S.fd.endDate) return a.setErr("حداقل یکی از تاریخ‌ها (سررسید پرداخت یا پایان بیمه) را انتخاب کن تا هشدار کار کند.");
    const all = list(), id = a.S.form.id, old = id ? all.find((x) => x.id === id) : null;
    const rec = {
      id: id || a.uid("ins"), type, company, policyNo: $("ins-no").value.trim(), projectId: type === "building" ? $("sf-project").value : "",
      subject: type === "workers" ? $("ins-subject").value.trim() : "", premium: a.num($("ins-premium").value) || "", repeat: $("ins-repeat").value,
      nextDue: a.S.fd.nextDue, startDate: a.S.fd.startDate, endDate: a.S.fd.endDate, note: $("ins-note").value.trim(),
      payments: old ? old.payments || [] : [], date: old ? old.date : YSP.isoDate(), at: old ? old.at : YSP.nowISO(),
    };
    if (old) { Object.assign(old, rec, { updatedAt: YSP.nowISO() }); if (!setArr(K, all)) return; }
    else if (!setArr(K, all.concat([rec]))) return;
    a.closeSheet(); a.render();
  }
  function remove(id) {
    const p = list().find((x) => x.id === id); if (!p) return;
    requestDelete(`حذف ${TYPE[p.type]} ${p.company}`, () => { setArr(K, list().filter((x) => x.id !== id)); A().render(); });
  }

  /* ---------- paying a premium ---------- */
  function paid(id) {
    const all = list(), p = all.find((x) => x.id === id);
    if (!p) return;
    p.payments = (p.payments || []).concat([{ id: A().uid("ip"), amount: Number(p.premium) || 0, date: YSP.isoDate(), at: YSP.nowISO(), forDue: p.nextDue || "" }]);
    if (p.nextDue && p.repeat === "monthly") p.nextDue = YSPDate.addMonths(p.nextDue, 1);
    else if (p.nextDue && p.repeat === "yearly") p.nextDue = YSPDate.addMonths(p.nextDue, 12);
    else p.nextDue = "";
    p.updatedAt = YSP.nowISO();
    if (setArr(K, all)) { YSP.toast("پرداخت ثبت شد" + (p.nextDue ? "؛ سررسید بعدی: " + YSP.jalali(p.nextDue) : ".")); A().render(); }
  }
  function calendar(id, which) {
    const p = list().find((x) => x.id === id), a = A();
    const d = which === "end" ? p && p.endDate : p && p.nextDue;
    if (!p || !d) return;
    YSPPlan.gate("site.insurance", () => {
      const title = (which === "end" ? "پایان " : "پرداخت حق بیمه ") + `${TYPE[p.type]} ${p.company}`;
      a.downloadText(`insurance-${p.id}.ics`, a.buildIcsEvent(p.id + (which || ""), title, d, `${p.policyNo ? "شماره: " + p.policyNo : ""}${p.premium ? " - مبلغ " + money(p.premium) + " تومان" : ""}`), "text/calendar");
      YSP.toast("فایل تقویم ساخته شد؛ آن را باز کن تا یادآور اضافه شود.");
    });
  }

  /* ---------- tab ---------- */
  function card(p) {
    const due = p.nextDue ? whenText(days(p.nextDue)) : null, end = p.endDate ? whenText(days(p.endDate)) : null;
    return `<div class="card"><div class="site-row" style="border:0;padding:0"><div><b>${esc(p.company)}</b> · ${TYPE[p.type]}<div class="s">${subjectOf(p) ? esc(subjectOf(p)) + " · " : ""}${p.policyNo ? "شماره " + esc(p.policyNo) + " · " : ""}${p.premium ? "حق بیمه " + money(p.premium) + " تومان (" + REPEAT[p.repeat] + ")" : ""}</div></div></div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin:8px 0">${due ? `<span class="chip ${due.cls}">پرداخت: ${esc(YSP.jalali(p.nextDue))} · ${esc(due.text)}</span>` : '<span class="chip green">پرداخت‌ها تسویه</span>'}${end ? `<span class="chip ${days(p.endDate) < 0 ? "red" : days(p.endDate) <= END_DAYS ? "amber" : "gray"}">پایان: ${esc(YSP.jalali(p.endDate))}</span>` : ""}</div>
      ${(p.payments || []).length ? `<div class="client" style="margin-bottom:6px">آخرین پرداخت: ${esc(YSP.dtShow((p.payments.slice(-1)[0]).date, (p.payments.slice(-1)[0]).at))} (${money(p.payments.length)} بار)</div>` : ""}
      <div style="display:flex;gap:6px;flex-wrap:wrap">${p.nextDue ? `<button type="button" class="site-mini green" onclick="YSPIns.paid('${p.id}')">✅ پرداخت شد</button><button type="button" class="site-mini" onclick="YSPIns.calendar('${p.id}')">📅 تقویم پرداخت</button>` : ""}${p.endDate ? `<button type="button" class="site-mini" onclick="YSPIns.calendar('${p.id}','end')">📅 تقویم پایان</button>` : ""}<button type="button" class="site-mini" onclick="YSPIns.open('${p.id}')">✏️</button><button type="button" class="site-mini red" onclick="YSPIns.del('${p.id}')">🗑️</button></div></div>`;
  }
  function tab() {
    const a = A();
    if (!YSPPlan.allowed()) return a.lockedCard("site.insurance");
    const ps = list().sort((x, y) => (x.nextDue || x.endDate || "9").localeCompare(y.nextDue || y.endDate || "9"));
    const b = ps.filter((p) => p.type === "building"), w = ps.filter((p) => p.type === "workers");
    return `<button type="button" class="save-btn" style="margin-bottom:12px" onclick="YSPIns.open()">➕ ثبت بیمه جدید</button>
      ${ps.length ? "" : a.empty("هنوز بیمه‌ای ثبت نشده.<br>بیمه ساختمان یا بیمه کارگران را با تاریخ سررسید ثبت کن تا هشدار بگیری.")}
      ${b.length ? `<div class="site-sec">🏢 بیمه ساختمان</div>${b.map(card).join("")}` : ""}
      ${w.length ? `<div class="site-sec">👷 بیمه کارگران</div>${w.map(card).join("")}` : ""}`;
  }

  root.YSPIns = { open, save, del: remove, paid, calendar, clearDate, typeChanged, alerts, tab };
  YSPSite.registerTab("insurance", "بیمه", tab);
  YSPSite.registerAlerts(alerts);
})(window);
