/* Stone Pro security: app lock with a hashed PIN (PBKDF2-SHA256), wrong-attempt throttling,
   auto-lock after the app was in the background, and PIN confirmation for destructive actions.
   The PIN is never stored; only a salted hash is. The data itself stays unencrypted in the
   browser storage, so this protects the app screen and deletions, not the raw device storage. */
"use strict";
(function (root) {
  const KEY = "ysp_sec";
  const ITER_SUBTLE = 200000;
  const ITER_JS = 100000; // pure JS fallback (apps opened from file:// have no WebCrypto)
  const IDLE_LOCK_MS = 120000;
  const FREE_TRIES = 5;
  const enc = new TextEncoder();
  const hasSubtle = !!(root.crypto && root.crypto.subtle);

  /* ---------- state ---------- */
  function readState() { try { return JSON.parse(localStorage.getItem(KEY) || "null"); } catch (e) { return null; } }
  function writeState(s) { localStorage.setItem(KEY, JSON.stringify(s)); }
  const hasPin = () => { const s = readState(); return !!(s && s.hash && s.salt); };
  const b64 = (u8) => btoa(String.fromCharCode.apply(null, Array.from(u8)));
  const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

  async function derive(pin, salt, iter) {
    if (hasSubtle) {
      try {
        const key = await crypto.subtle.importKey("raw", enc.encode(pin), "PBKDF2", false, ["deriveBits"]);
        const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt, iterations: iter }, key, 256);
        return new Uint8Array(bits);
      } catch (e) { /* fall through to the JS implementation */ }
    }
    await new Promise((r) => setTimeout(r, 30)); // let the screen repaint before the heavy loop
    return YSPHash.pbkdf2(enc.encode(pin), salt, iter);
  }
  function sameBytes(a, b) {
    if (a.length !== b.length) return false;
    let r = 0;
    for (let i = 0; i < a.length; i++) r |= a[i] ^ b[i];
    return r === 0;
  }

  /** Returns an error message for a bad PIN, or "" when it is acceptable. */
  function pinProblem(pin) {
    if (!/^\d{4,8}$/.test(pin || "")) return "رمز باید فقط عدد و بین ۴ تا ۸ رقم باشد.";
    if (/^(\d)\1+$/.test(pin)) return "رمز نباید همه‌ی رقم‌هایش یکی باشد.";
    const d = pin.split("").map(Number);
    const step = d[1] - d[0];
    if ((step === 1 || step === -1) && d.every((x, i) => i === 0 || x - d[i - 1] === step)) return "رمز نباید ردیف ساده‌ی اعداد (مثل ۱۲۳۴) باشد.";
    return "";
  }

  async function setPin(pin) {
    const bad = pinProblem(pin);
    if (bad) throw new Error(bad);
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const iter = hasSubtle ? ITER_SUBTLE : ITER_JS;
    const hash = await derive(pin, salt, iter);
    writeState({ v: 1, salt: b64(salt), hash: b64(hash), iter, fails: 0, lockUntil: 0 });
    if (root.YSP) YSP.log("pin_set", "security", "", "رمز برنامه تعیین یا تغییر کرد");
  }

  /** Checks a PIN with throttling. Resolves to { ok, wait, left }. */
  async function verify(pin) {
    const s = readState();
    if (!s || !s.hash) return { ok: false, noPin: true };
    const now = Date.now();
    if (s.lockUntil && s.lockUntil > now) return { ok: false, wait: Math.ceil((s.lockUntil - now) / 1000), left: 0 };
    const ok = sameBytes(await derive(String(pin || ""), unb64(s.salt), s.iter || ITER_SUBTLE), unb64(s.hash));
    if (ok) {
      s.fails = 0; s.lockUntil = 0; writeState(s);
      return { ok: true };
    }
    s.fails = (s.fails || 0) + 1;
    let wait = 0;
    if (s.fails >= FREE_TRIES) {
      wait = Math.min(900, 30 * Math.pow(2, s.fails - FREE_TRIES));
      s.lockUntil = Date.now() + wait * 1000;
    }
    writeState(s);
    if (root.YSP) YSP.log("auth_fail", "security", "", "رمز اشتباه وارد شد");
    return { ok: false, wait, left: Math.max(0, FREE_TRIES - s.fails) };
  }

  function removePin() {
    localStorage.removeItem(KEY);
    if (root.YSP) YSP.log("pin_removed", "security", "", "قفل برنامه غیرفعال شد");
  }

  function failText(r) {
    if (r.wait) return `تلاش‌های اشتباه زیاد بود. ${r.wait} ثانیه صبر کن.`;
    if (typeof r.left === "number") return `رمز اشتباه است. ${r.left} تلاش آزاد باقی مانده.`;
    return "رمز اشتباه است.";
  }

  /* ---------- styles ---------- */
  const css = document.createElement("style");
  css.textContent = `
  #ysp-lock{position:fixed;inset:0;z-index:200000;background:#0b0b0b;display:none;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:24px;text-align:center;direction:rtl}
  #ysp-lock.open{display:flex}
  #ysp-lock img{width:min(58vw,220px);height:auto;filter:drop-shadow(0 0 20px rgba(205,164,62,.3))}
  #ysp-lock h2{margin:0;font-size:19px;color:#f3f1ec}
  #ysp-lock p{margin:0;font-size:13px;color:#9a958a;min-height:20px}
  #ysp-lock p.err{color:#d97b7b}
  .ysp-pin{width:min(260px,80vw);padding:14px;border-radius:14px;border:1px solid #2a2620;background:#141210;color:#f3f1ec;font-size:22px;letter-spacing:8px;text-align:center;font-family:inherit;outline:none}
  .ysp-pin:focus{border-color:#cda43e}
  .ysp-btn{width:min(260px,80vw);padding:13px;border-radius:14px;border:0;background:linear-gradient(160deg,#e6c265,#cda43e);color:#0b0b0b;font-weight:700;font-size:15px;font-family:inherit}
  .ysp-btn.ghost{background:transparent;color:#9a958a;border:1px solid #2a2620;font-weight:500}
  .ysp-link{background:none;border:0;color:#9a958a;font-size:12px;text-decoration:underline;font-family:inherit}
  #ysp-sec-modal{position:fixed;inset:0;background:rgba(0,0,0,.78);display:none;align-items:center;justify-content:center;z-index:100001;padding:18px;direction:rtl}
  #ysp-sec-modal.open{display:flex}
  #ysp-sec-box{width:min(360px,94vw);background:#141210;border:1px solid #cda43e;border-radius:18px;padding:18px;color:#f3f1ec;display:flex;flex-direction:column;gap:10px}
  #ysp-sec-box h3{margin:0;font-size:16px}
  #ysp-sec-box p{margin:0;font-size:12px;color:#9a958a;line-height:1.9}
  #ysp-sec-box .ysp-pin{width:100%;font-size:18px;letter-spacing:5px}
  #ysp-sec-box .ysp-btn{width:100%}
  #ysp-sec-err{min-height:18px;font-size:12px;color:#d97b7b}`;
  document.head.appendChild(css);

  /* ---------- lock screen ---------- */
  const lockEl = document.createElement("div");
  lockEl.id = "ysp-lock";
  lockEl.setAttribute("role", "dialog");
  lockEl.setAttribute("aria-modal", "true");
  lockEl.innerHTML = `<img src="img/ya-logo.png" alt="YA"><h2>Stone Pro</h2><p id="ysp-lock-msg">رمز ورود را وارد کن</p>
    <input id="ysp-lock-pin" class="ysp-pin" type="password" inputmode="numeric" autocomplete="off" maxlength="8" aria-label="رمز ورود">
    <button id="ysp-lock-go" class="ysp-btn" type="button">ورود</button>
    <button id="ysp-lock-forgot" class="ysp-link" type="button">رمز را فراموش کرده‌ام</button>`;
  document.body.appendChild(lockEl);
  const lockPin = lockEl.querySelector("#ysp-lock-pin");
  const lockMsg = lockEl.querySelector("#ysp-lock-msg");
  let busy = false;

  function lock() {
    if (!hasPin()) return;
    lockPin.value = "";
    lockMsg.textContent = "رمز ورود را وارد کن";
    lockMsg.className = "";
    lockEl.classList.add("open");
    setTimeout(() => lockPin.focus(), 60);
  }
  async function tryUnlock() {
    if (busy) return;
    busy = true;
    try {
      const r = await verify(lockPin.value);
      if (r.ok) {
        lockEl.classList.remove("open");
        lockPin.value = "";
        if (root.YSP) YSP.log("auth_ok", "security", "", "ورود به برنامه");
      } else {
        lockMsg.textContent = failText(r);
        lockMsg.className = "err";
        lockPin.value = "";
      }
    } finally { busy = false; }
  }
  lockEl.querySelector("#ysp-lock-go").addEventListener("click", tryUnlock);
  lockPin.addEventListener("keydown", (e) => { if (e.key === "Enter") tryUnlock(); });
  lockEl.querySelector("#ysp-lock-forgot").addEventListener("click", () => {
    const word = "پاک‌سازی";
    const typed = prompt(`رمز قابل بازیابی نیست. اگر از اطلاعاتت بکاپ داری، می‌توانی همه‌چیز را پاک کنی و بعد بکاپ را بازیابی کنی.\nبرای پاک‌سازی کامل این کلمه را بنویس: ${word}`);
    if (typed && typed.trim() === word) {
      Object.keys(localStorage).filter((k) => k.indexOf("ysp_") === 0).forEach((k) => localStorage.removeItem(k));
      location.reload();
    }
  });

  let hiddenAt = 0;
  function autoLockCheck(nowMs) {
    if (hasPin() && hiddenAt && nowMs - hiddenAt > IDLE_LOCK_MS) lock();
    hiddenAt = 0;
  }
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) hiddenAt = Date.now();
    else autoLockCheck(Date.now());
  });

  /* ---------- PIN settings dialog ---------- */
  function secModal() {
    let m = document.getElementById("ysp-sec-modal");
    if (m) return m;
    m = document.createElement("div");
    m.id = "ysp-sec-modal";
    m.setAttribute("aria-hidden", "true");
    m.innerHTML = '<div id="ysp-sec-box" role="dialog" aria-modal="true"></div>';
    document.body.appendChild(m);
    return m;
  }
  function closeSec() { const m = document.getElementById("ysp-sec-modal"); if (m) { m.classList.remove("open"); m.setAttribute("aria-hidden", "true"); } }

  function openPinSettings(note, onDone) {
    const m = secModal(), box = m.querySelector("#ysp-sec-box"), has = hasPin();
    box.innerHTML = `<h3>🔒 قفل برنامه</h3>
      <p>${note ? esc(note) + "<br>" : ""}${has ? "قفل فعال است. برای تغییر یا حذف، اول رمز فعلی را وارد کن." : "یک رمز ۴ تا ۸ رقمی تعیین کن. این رمز هنگام ورود و برای هر حذف و بازیابی اطلاعات لازم است. رمز فراموش‌شده قابل بازیابی نیست."}</p>
      ${has ? '<input id="ysp-pin-old" class="ysp-pin" type="password" inputmode="numeric" maxlength="8" placeholder="رمز فعلی" autocomplete="off">' : ""}
      <input id="ysp-pin-new" class="ysp-pin" type="password" inputmode="numeric" maxlength="8" placeholder="${has ? "رمز جدید" : "رمز"}" autocomplete="off">
      <input id="ysp-pin-new2" class="ysp-pin" type="password" inputmode="numeric" maxlength="8" placeholder="تکرار رمز" autocomplete="off">
      <div id="ysp-sec-err"></div>
      <button id="ysp-pin-save" class="ysp-btn" type="button">${has ? "تغییر رمز" : "فعال‌سازی قفل"}</button>
      ${has ? '<button id="ysp-pin-remove" class="ysp-btn ghost" type="button">غیرفعال کردن قفل</button>' : ""}
      <button id="ysp-pin-cancel" class="ysp-btn ghost" type="button">بستن</button>`;
    m.classList.add("open"); m.setAttribute("aria-hidden", "false");
    const err = (t) => { box.querySelector("#ysp-sec-err").textContent = t || ""; };
    const val = (id) => (box.querySelector(id) ? box.querySelector(id).value : "");
    async function checkOld() {
      if (!has) return true;
      const r = await verify(val("#ysp-pin-old"));
      if (!r.ok) { err(failText(r)); return false; }
      return true;
    }
    box.querySelector("#ysp-pin-cancel").onclick = closeSec;
    box.querySelector("#ysp-pin-save").onclick = async () => {
      err("");
      if (!(await checkOld())) return;
      const a = val("#ysp-pin-new"), b = val("#ysp-pin-new2");
      if (a !== b) return err("تکرار رمز با رمز اول یکی نیست.");
      try { await setPin(a); } catch (e) { return err(e.message); }
      closeSec();
      YSP.toast(has ? "رمز تغییر کرد." : "قفل برنامه فعال شد.");
      if (root.YSPData) YSPData.renderBanners();
      if (typeof onDone === "function") onDone();
    };
    const rm = box.querySelector("#ysp-pin-remove");
    if (rm) rm.onclick = async () => {
      err("");
      if (!(await checkOld())) return;
      removePin(); closeSec();
      YSP.toast("قفل برنامه غیرفعال شد.");
      if (root.YSPData) YSPData.renderBanners();
    };
  }

  /* ---------- destructive-action confirmation (keeps the old requestDelete name) ---------- */
  let pending = null;
  function requestDelete(title, callback, opts) {
    opts = opts || {};
    if (!hasPin()) {
      // No deletion without a password: make one first, then ask for it right away.
      openPinSettings("برای حذف هر مورد باید رمز داشته باشی. اول یک رمز تعیین کن؛ بعد از آن همین حذف را با رمز تأیید می‌کنی.", () => requestDelete(title, callback, opts));
      return;
    }
    const modal = document.getElementById("ysp-delete-modal");
    if (!modal) return;
    pending = callback;
    document.getElementById("ysp-delete-title").textContent = title || "تأیید حذف";
    document.getElementById("ysp-delete-text").textContent = opts.text || "برای ادامه رمز برنامه را وارد کن.";
    document.getElementById("ysp-delete-error").textContent = "";
    modal.querySelector(".ysp-delete-confirm").textContent = opts.confirmLabel || "حذف";
    const input = document.getElementById("ysp-delete-password");
    input.value = "";
    modal.classList.add("open"); modal.setAttribute("aria-hidden", "false");
    setTimeout(() => input.focus(), 50);
  }
  function closeDeleteModal() {
    const modal = document.getElementById("ysp-delete-modal");
    if (modal) { modal.classList.remove("open"); modal.setAttribute("aria-hidden", "true"); }
    pending = null;
  }
  async function confirmDeleteModal() {
    const input = document.getElementById("ysp-delete-password");
    const r = await verify(input.value);
    if (!r.ok) {
      document.getElementById("ysp-delete-error").textContent = failText(r);
      input.value = "";
      return;
    }
    const cb = pending;
    closeDeleteModal();
    if (typeof cb === "function") cb();
  }
  document.addEventListener("keydown", (e) => {
    const m = document.getElementById("ysp-delete-modal");
    if (!m || !m.classList.contains("open")) return;
    if (e.key === "Enter") confirmDeleteModal();
    if (e.key === "Escape") closeDeleteModal();
  });

  root.YSPSec = { hasPin, verify, setPin, removePin, pinProblem, lock, autoLockCheck, markHidden: (t) => { hiddenAt = t; }, openPinSettings, hasSubtle };
  root.requestDelete = requestDelete;
  root.closeDeleteModal = closeDeleteModal;
  root.confirmDeleteModal = confirmDeleteModal;

  if (hasPin()) lock();
})(window);
