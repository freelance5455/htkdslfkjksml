/* Stone Pro data tools: backup file, validated restore, event-log viewer, and the
   reminders shown on the home screen. */
"use strict";
(function (root) {
  const FORMAT = 1;
  const KEYS = ["ysp_projects", "ysp_workers", "ysp_worker_ledger", "ysp_estimates", "ysp_photos", "ysp_parties", "ysp_entries", "ysp_pays", "ysp_stock", "ysp_insurance", "ysp_profile", "ysp_events"];
  const LAST_BACKUP = "ysp_last_backup";
  const REMIND_DAYS = 7;
  const MAX_FILE = 30 * 1024 * 1024;
  const COUNT_LABEL = {
    ysp_projects: "پروژه", ysp_workers: "کارگر", ysp_worker_ledger: "ثبت کارگر",
    ysp_estimates: "برآورد", ysp_photos: "عکس", ysp_parties: "طرف حساب", ysp_entries: "خرید/کارکرد", ysp_pays: "پرداخت", ysp_stock: "انبار", ysp_insurance: "بیمه", ysp_profile: "نقش", ysp_events: "رویداد",
  };
  const KIND = {
    create: "➕ ثبت", update: "✏️ ویرایش", delete: "🗑️ حذف", backup: "💾 پشتیبان", restore: "♻️ بازیابی",
    auth_ok: "🔓 ورود", auth_fail: "⚠️ رمز اشتباه", pin_set: "🔒 رمز", pin_removed: "🔓 رمز حذف شد", terms_accepted: "📜 پذیرش مقررات",
  };
  const ENTITY = { project: "پروژه", worker: "کارگر", ledger: "کارکرد/مالی کارگر", estimate: "برآورد", photo: "عکس", security: "امنیت", data: "اطلاعات", profile: "نقش کاربر", legal: "مقررات", party: "طرف حساب", entry: "خرید/کارکرد", pay: "پرداخت", stock: "انبار", insurance: "بیمه" };
  const FIELD = {
    name: "نام", client: "کارفرما", phone: "تلفن", price: "قیمت", income: "دریافتی", expense: "هزینه",
    contractorReceived: "دریافت از پیمانکار", workerPaid: "پرداخت به کارگر", contract: "قرارداد", notes: "توضیحات",
    status: "وضعیت", role: "تخصص", userType: "نوع کاربر", trade: "صنف", amount: "مبلغ", qty: "مقدار", rate: "نرخ", count: "تعداد کارگر", method: "نوع پرداخت", dueDate: "سررسید چک", checkStatus: "وضعیت چک", invoiceNo: "شماره فاکتور", partyId: "طرف حساب", projectId: "پروژه", kind: "نوع", date: "تاریخ", unit: "واحد", bank: "بانک", checkNo: "شماره چک", dir: "ورود/خروج", item: "کالا", receiver: "تحویل‌گیرنده", company: "شرکت/سازمان بیمه", policyNo: "شماره بیمه‌نامه", premium: "حق بیمه", nextDue: "سررسید پرداخت", endDate: "پایان بیمه", startDate: "شروع بیمه", repeat: "تکرار", subject: "مشمول", type: "نوع", wage: "دستمزد", title: "عنوان", rows: "ردیف‌ها", note: "توضیحات", caption: "توضیح",
  };

  /* ---------- helpers ---------- */
  /** SHA-256 hex of a string. WebCrypto when present, identical pure-JS code otherwise,
      so a backup made in the installed app verifies in the browser and the other way round. */
  async function sha256Hex(text) {
    const bytes = new TextEncoder().encode(text);
    if (root.crypto && crypto.subtle) {
      try { return YSPHash.hex(new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))); } catch (e) { /* fall back */ }
    }
    return YSPHash.hex(YSPHash.sha256(bytes));
  }
  function readAll() {
    const data = {};
    KEYS.forEach((k) => { data[k] = getArr(k); });
    return data;
  }
  const countsOf = (data) => KEYS.map((k) => `${COUNT_LABEL[k]}: ${(data[k] || []).length.toLocaleString("fa-IR")}`).join(" · ");
  const stampName = () => {
    const d = new Date(), p = (n) => String(n).padStart(2, "0");
    return `${YSP.jalali(YSP.isoDate(d)).replace(/\//g, "-")}_${p(d.getHours())}${p(d.getMinutes())}`;
  };

  /* ---------- backup ---------- */
  async function buildBackup() {
    const data = readAll();
    const checksum = await sha256Hex(JSON.stringify(data));
    return { app: "stone-pro", format: FORMAT, version: YSP.version, createdAt: YSP.nowISO(), algo: "sha256", checksum, data };
  }
  async function exportBackup(viaShare) {
    const backup = await buildBackup();
    const text = JSON.stringify(backup);
    const name = `StonePro-backup-${stampName()}.json`;
    const file = new File([text], name, { type: "application/json" });
    if (viaShare && navigator.canShare && navigator.canShare({ files: [file] })) {
      try { await navigator.share({ files: [file], title: "پشتیبان Stone Pro" }); markBackup(); return; } catch (e) { if (e && e.name === "AbortError") return; }
    }
    const url = URL.createObjectURL(file);
    const a = document.createElement("a");
    a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    markBackup();
    YSP.toast("فایل پشتیبان ساخته شد. آن را جای امن (مثلاً تلگرام خودت) نگه دار.");
  }
  function markBackup() {
    localStorage.setItem(LAST_BACKUP, YSP.nowISO());
    YSP.log("backup", "data", "", "ساخت فایل پشتیبان");
    renderBanners(); fillSettings();
  }

  /* ---------- restore ---------- */
  async function validateBackup(text) {
    if (text.length > MAX_FILE) return { error: "فایل خیلی بزرگ است." };
    let obj;
    try { obj = JSON.parse(text); } catch (e) { return { error: "فایل خراب است یا فایل پشتیبان نیست." }; }
    if (!obj || obj.app !== "stone-pro" || typeof obj.data !== "object" || obj.data === null) return { error: "این فایل، پشتیبان Stone Pro نیست." };
    if (obj.format !== FORMAT) return { error: "نسخه‌ی این فایل پشتیبان پشتیبانی نمی‌شود." };
    const expected = await sha256Hex(JSON.stringify(obj.data));
    if (expected !== obj.checksum) return { error: "فایل پشتیبان تغییر کرده یا ناقص است؛ بازیابی انجام نشد." };
    const data = {};
    for (const k of KEYS) {
      const v = obj.data[k] === undefined ? [] : obj.data[k];
      if (!Array.isArray(v) || v.some((x) => !x || typeof x !== "object" || Array.isArray(x))) return { error: `بخش «${COUNT_LABEL[k]}» در فایل معتبر نیست.` };
      data[k] = v;
    }
    return { backup: obj, data };
  }
  function applyRestore(backup, data) {
    const old = {};
    KEYS.forEach((k) => { old[k] = localStorage.getItem(k); });
    const restored = Object.assign({}, data);
    restored.ysp_events = (data.ysp_events || []).concat([{ id: "ev" + Date.now().toString(36), at: YSP.nowISO(), kind: "restore", entity: "data", refId: "", title: "بازیابی از فایل پشتیبان ساخته‌شده در " + YSP.dtShow("", backup.createdAt), fields: [] }]);
    try {
      KEYS.forEach((k) => localStorage.setItem(k, JSON.stringify(restored[k])));
    } catch (e) {
      KEYS.forEach((k) => { if (old[k] === null) localStorage.removeItem(k); else localStorage.setItem(k, old[k]); });
      alert("حافظه دستگاه برای این بازیابی کافی نیست. اطلاعات قبلی سر جایش ماند.");
      return false;
    }
    return true;
  }
  function pickBackupFile() {
    const inp = document.createElement("input");
    inp.type = "file"; inp.accept = ".json,application/json";
    inp.onchange = async () => {
      const f = inp.files && inp.files[0];
      if (!f) return;
      const res = await validateBackup(await f.text());
      if (res.error) { alert(res.error); return; }
      const info = `پشتیبان ساخته‌شده در: ${YSP.dtShow("", res.backup.createdAt)}\n${countsOf(res.data)}\n\nبا بازیابی، همه‌ی اطلاعات فعلی این برنامه با این فایل جایگزین می‌شود.`;
      requestDelete("بازیابی از پشتیبان", () => {
        if (applyRestore(res.backup, res.data)) location.reload();
      }, { text: info, confirmLabel: "بازیابی" });
    };
    inp.click();
  }

  /* ---------- event log viewer ---------- */
  function eventLine(e) {
    const kind = KIND[e.kind] || e.kind;
    const fields = (e.fields || []).map((f) => FIELD[f]).filter(Boolean);
    return { kind, entity: ENTITY[e.entity] || "", title: e.title || "", fields: fields.join("، "), when: YSP.dtShow("", e.at) };
  }
  function eventsText() {
    return YSP.events().slice().reverse().map((e) => {
      const l = eventLine(e);
      return `${l.when} | ${l.kind}${l.entity ? " " + l.entity : ""}${l.title ? " | " + l.title : ""}${l.fields ? " | " + l.fields : ""}`;
    }).join("\n");
  }
  function openEvents() {
    ensureUtilityModals();
    let m = document.getElementById("ysp-events-modal");
    if (!m) {
      m = document.createElement("div");
      m.id = "ysp-events-modal"; m.className = "utility-modal"; m.setAttribute("aria-hidden", "true");
      m.innerHTML = `<div class="utility-sheet"><div class="utility-head"><b>🧾 گزارش رویدادها</b><button type="button" onclick="closeUtilityModal('ysp-events-modal')">✕</button></div>
        <div class="client" style="margin-bottom:8px">تاریخ و ساعت همه‌ی ثبت‌ها، ویرایش‌ها و حذف‌ها اینجا خودکار نگه داشته می‌شود.</div>
        <button type="button" class="save-btn" style="margin:0 0 10px" onclick="YSPData.shareEvents()">📤 کپی/ارسال گزارش</button>
        <div id="ysp-events-list"></div></div>`;
      document.body.appendChild(m);
    }
    const list = YSP.events().slice().reverse().slice(0, 300);
    m.querySelector("#ysp-events-list").innerHTML = list.length ? list.map((e) => {
      const l = eventLine(e);
      return `<div class="utility-result" style="cursor:default"><b>${esc(l.kind)}${l.entity ? " · " + esc(l.entity) : ""}</b>${l.title ? "<div>" + esc(l.title) + "</div>" : ""}${l.fields ? `<div class="small">تغییر: ${esc(l.fields)}</div>` : ""}<div class="small">🕒 ${esc(l.when)}</div></div>`;
    }).join("") : '<div class="empty">هنوز رویدادی ثبت نشده است.</div>';
    m.classList.add("open"); m.setAttribute("aria-hidden", "false");
  }

  /* ---------- home banners and settings ---------- */
  function daysSince(iso) { const d = iso ? new Date(iso) : null; return d && !isNaN(d) ? (Date.now() - d.getTime()) / 86400000 : Infinity; }
  function hasData() { return KEYS.some((k) => k !== "ysp_events" && k !== "ysp_profile" && getArr(k).length); }
  function renderBanners() {
    const box = document.getElementById("ysp-banners");
    if (!box) return;
    const items = [];
    if (root.YSPSite) { const a = YSPSite.alertsHtml(); if (a) items.push(a); YSPSite.refreshBadge(); }
    if (hasData() && daysSince(localStorage.getItem(LAST_BACKUP)) > REMIND_DAYS) {
      items.push(`<div class="card" style="border-color:#cda43e"><div class="lbl">💾 پشتیبان‌گیری</div><div class="client" style="margin-bottom:8px">${localStorage.getItem(LAST_BACKUP) ? "آخرین پشتیبان قدیمی است." : "هنوز از اطلاعاتت پشتیبان نگرفته‌ای."} اگر مرورگر یا گوشی عوض شود، بدون پشتیبان اطلاعات از بین می‌رود.</div><button type="button" class="save-btn" style="margin:0" onclick="YSPData.exportBackup(true)">همین الان پشتیبان بگیر</button></div>`);
    }
    if (!YSPSec.hasPin()) {
      items.push(`<div class="card"><div class="lbl">🔒 قفل برنامه</div><div class="client" style="margin-bottom:8px">اطلاعات مالی و مشتری‌هایت را با رمز قفل کن. بدون رمز، حذف اطلاعات ممکن نیست.</div><button type="button" class="save-btn" style="margin:0" onclick="YSPSec.openPinSettings()">فعال‌سازی قفل</button></div>`);
    }
    box.innerHTML = items.join("");
    box.style.cssText = items.length ? "display:flex;flex-direction:column;gap:10px;margin-bottom:14px" : "";
  }
  function fillSettings() {
    const box = document.getElementById("ysp-settings-tools");
    if (!box) return;
    const last = localStorage.getItem(LAST_BACKUP);
    box.innerHTML = `
      <div class="card"><div class="lbl">🕒 تاریخ و ساعت اکنون</div><div id="ysp-now" style="font-weight:700;color:var(--gold-bright)">${esc(YSP.dtShow("", YSP.nowISO()))}</div></div>
      <div class="card"><div class="lbl">💾 پشتیبان‌گیری و بازیابی</div>
        <div class="client" style="margin-bottom:8px">آخرین پشتیبان: ${last ? esc(YSP.dtShow("", last)) : "هنوز گرفته نشده"}</div>
        <button type="button" class="save-btn" style="margin:0 0 8px" onclick="YSPData.exportBackup(false)">⬇️ دانلود فایل پشتیبان</button>
        <button type="button" class="save-btn" style="margin:0 0 8px" onclick="YSPData.exportBackup(true)">📤 ارسال فایل پشتیبان</button>
        <button type="button" class="del-btn" style="margin:0" onclick="YSPData.restore()">♻️ بازیابی از فایل پشتیبان</button></div>
      <div class="card"><div class="lbl">👤 نقش و صنف</div>
        <div class="client" style="margin-bottom:8px">${esc(YSPRole.summary())}</div>
        <button type="button" class="save-btn" style="margin:0" onclick="closeUtilityModal('ysp-settings-modal');YSPRole.openRole(true)">تغییر نقش یا صنف</button></div>
      <div class="card"><div class="lbl">🔒 امنیت</div>
        <div class="client" style="margin-bottom:8px">${YSPSec.hasPin() ? "قفل برنامه فعال است." : "قفل برنامه فعال نیست."}</div>
        <button type="button" class="save-btn" style="margin:0" onclick="YSPSec.openPinSettings()">${YSPSec.hasPin() ? "تغییر یا حذف رمز" : "فعال‌سازی قفل"}</button></div>
      <div class="card"><div class="lbl">⭐ اشتراک</div>${YSPPlan.summaryHtml()}</div>
      <div class="card"><div class="lbl">📜 مقررات و حریم خصوصی</div>
        <div class="client" style="margin-bottom:8px">${esc(YSPRole.acceptedText())}</div>
        <button type="button" class="save-btn" style="margin:0" onclick="closeUtilityModal('ysp-settings-modal');YSPRole.showTerms()">مشاهده مقررات</button></div>
      <div class="card"><div class="lbl">🧾 گزارش رویدادها</div>
        <button type="button" class="save-btn" style="margin:0" onclick="closeUtilityModal('ysp-settings-modal');YSPData.openEvents()">مشاهده تاریخ و ساعت همه‌ی رویدادها</button></div>
      <div class="client" style="text-align:center;margin-top:6px">Stone Pro نسخه ${esc(YSP.version)}</div>`;
  }

  root.YSPData = {
    exportBackup, restore: pickBackupFile, openEvents, renderBanners, fillSettings,
    shareEvents: () => YSP.share(eventsText()),
    _validate: validateBackup,
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", renderBanners);
  else renderBanners();
})(window);
