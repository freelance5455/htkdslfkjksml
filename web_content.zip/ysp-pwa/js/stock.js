/* Stone Pro warehouse (انبار): every movement in or out of the site store is recorded with its date and
   the exact time. A material purchase can add itself to the store. Taking out more than the store holds
   is refused, so the balance never goes negative. */
"use strict";
(function (root) {
  const K = "ysp_stock";
  const A = () => YSPSite.api;
  const list = () => getArr(K);
  const norm = (s) => String(s || "").trim().replace(/\s+/g, " ");
  const keyOf = (name, unit) => norm(name) + "|" + norm(unit);
  const qtyText = (n) => Number(n).toLocaleString("fa-IR", { maximumFractionDigits: 3 });
  const sortNewest = (a, b) => (b.date || "").localeCompare(a.date || "") || (b.at || "").localeCompare(a.at || "");

  function items() {
    const m = new Map();
    list().forEach((mv) => {
      const key = keyOf(mv.item, mv.unit);
      const it = m.get(key) || { key, name: norm(mv.item), unit: norm(mv.unit), qty: 0, moves: [] };
      it.qty += (mv.dir === "in" ? 1 : -1) * (Number(mv.qty) || 0);
      it.moves.push(mv);
      m.set(key, it);
    });
    return Array.from(m.values()).sort((a, b) => a.name.localeCompare(b.name, "fa"));
  }
  const balanceOf = (key) => (items().find((i) => i.key === key) || { qty: 0 }).qty;

  /* ---------- purchases feed the store ---------- */
  const hasLink = (entryId) => list().some((m) => m.fromEntryId === entryId);
  function syncPurchase(entry, want) {
    const all = list(), cur = all.find((m) => m.fromEntryId === entry.id);
    const qty = Number(entry.qty) || 0;
    if (!want || !qty || !entry.title) { if (cur) setArr(K, all.filter((m) => m.fromEntryId !== entry.id)); return; }
    const rec = { id: cur ? cur.id : A().uid("st"), item: entry.title, unit: entry.unit || "", dir: "in", qty, partyId: entry.partyId, projectId: entry.projectId || "", receiver: "", date: entry.date, at: cur ? cur.at : YSP.nowISO(), fromEntryId: entry.id, note: "از خرید" + (entry.invoiceNo ? " (فاکتور " + entry.invoiceNo + ")" : "") };
    setArr(K, cur ? all.map((m) => (m.id === cur.id ? rec : m)) : all.concat([rec]));
  }
  const removeByEntry = (entryId) => { if (hasLink(entryId)) setArr(K, list().filter((m) => m.fromEntryId !== entryId)); };

  /* ---------- forms ---------- */
  function openIn() {
    const a = A(), its = items();
    a.S.form = { type: "stock", dir: "in" }; a.S.fd = { date: a.today() };
    a.sheet("ورود به انبار", `
      <div class="card"><div class="lbl">📦 نام کالا</div><input id="sk-item" list="sk-items" type="text" maxlength="60" placeholder="مثلاً سیمان، سنگ نما">
        <datalist id="sk-items">${its.map((i) => `<option value="${esc(i.name)}">`).join("")}</datalist></div>
      <div class="card"><div class="lbl">⚖️ مقدار و واحد</div><div style="display:flex;gap:8px"><input id="sk-qty" type="text" inputmode="decimal" placeholder="مقدار"><input id="sk-unit" list="sk-units" type="text" maxlength="20" placeholder="واحد"></div>
        <datalist id="sk-units">${["کیسه", "عدد", "متر مربع", "متر طول", "متر مکعب", "کیلوگرم", "تن", "بسته", "رول", "شاخه"].map((u) => `<option value="${u}">`).join("")}</datalist></div>
      ${a.projectSelectHtml("")}
      <div class="card"><div class="lbl">🚚 از کجا آمد؟ (اختیاری)</div><input id="sk-from" type="text" maxlength="60" placeholder="فروشنده یا توضیح"></div>
      ${a.dateCardHtml("date", "📅 تاریخ ورود", "تاریخ امروز خودکار ثبت می‌شود و ساعت دقیق هم نگه داشته می‌شود.")}
      <div class="err" id="sf-err"></div><button type="button" class="save-btn" onclick="YSPStock.saveIn()">ثبت ورود</button>`);
  }
  function saveIn() {
    const a = A(), item = norm($("sk-item").value), qty = a.num($("sk-qty").value);
    if (!item) return a.setErr("نام کالا را بنویس.");
    if (qty <= 0) return a.setErr("مقدار را وارد کن.");
    // keep the unit of an existing item with the same name when none was typed
    let unit = norm($("sk-unit").value);
    if (!unit) { const ex = items().find((i) => i.name === item); if (ex) unit = ex.unit; }
    const rec = { id: a.uid("st"), item, unit, dir: "in", qty, partyId: "", projectId: $("sf-project").value, receiver: "", date: a.S.fd.date || a.today(), at: YSP.nowISO(), fromEntryId: "", note: norm($("sk-from").value) };
    if (!setArr(K, list().concat([rec]))) return;
    a.closeSheet(); a.render();
  }
  function openOut(presetKey) {
    const a = A(), avail = items().filter((i) => i.qty > 0);
    if (!avail.length) { YSP.toast("انبار خالی است؛ اول ورود ثبت کن."); return; }
    a.S.form = { type: "stock", dir: "out" }; a.S.fd = { date: a.today() };
    a.sheet("خروج از انبار", `
      <div class="card"><div class="lbl">📦 کالا</div><select id="sk-pick" onchange="YSPStock.pickChanged()">${avail.map((i) => `<option value="${esc(i.key)}" ${i.key === presetKey ? "selected" : ""}>${esc(i.name)}${i.unit ? " (" + esc(i.unit) + ")" : ""} — موجودی ${qtyText(i.qty)}</option>`).join("")}</select></div>
      <div class="card"><div class="lbl">⚖️ مقدار خروج</div><input id="sk-qty" type="text" inputmode="decimal"><div class="client" style="margin-top:6px" id="sk-left"></div></div>
      <div class="card"><div class="lbl">👤 تحویل‌گیرنده / محل مصرف</div><input id="sk-to" type="text" maxlength="60" placeholder="مثلاً استاد رضا، طبقه دوم"></div>
      ${a.projectSelectHtml("")}
      ${a.dateCardHtml("date", "📅 تاریخ خروج", "تاریخ امروز خودکار ثبت می‌شود و ساعت دقیق هم نگه داشته می‌شود.")}
      <div class="card"><div class="lbl">🗒️ توضیحات (اختیاری)</div><textarea id="sk-note" rows="2"></textarea></div>
      <div class="err" id="sf-err"></div><button type="button" class="save-btn" onclick="YSPStock.saveOut()">ثبت خروج</button>`);
    pickChanged();
  }
  function pickChanged() {
    const sel = $("sk-pick"), el = $("sk-left");
    if (sel && el) { const it = items().find((i) => i.key === sel.value); el.textContent = it ? `موجودی فعلی: ${qtyText(it.qty)} ${it.unit}` : ""; }
  }
  function saveOut() {
    const a = A(), key = $("sk-pick").value, it = items().find((i) => i.key === key), qty = a.num($("sk-qty").value);
    if (!it) return a.setErr("کالا را انتخاب کن.");
    if (qty <= 0) return a.setErr("مقدار خروج را وارد کن.");
    if (qty > it.qty) return a.setErr(`موجودی کافی نیست؛ فقط ${qtyText(it.qty)} ${it.unit} در انبار هست. اگر خرید را ثبت نکرده‌ای، اول «ورود» را ثبت کن.`);
    const rec = { id: a.uid("st"), item: it.name, unit: it.unit, dir: "out", qty, partyId: "", projectId: $("sf-project").value, receiver: norm($("sk-to").value), date: a.S.fd.date || a.today(), at: YSP.nowISO(), fromEntryId: "", note: norm($("sk-note").value) };
    if (!setArr(K, list().concat([rec]))) return;
    a.closeSheet(); a.render();
  }
  const $ = (id) => document.getElementById(id);

  /* ---------- item history ---------- */
  function openItem(key) {
    const a = A(), it = items().find((i) => i.key === key);
    if (!it) return;
    const rows = it.moves.slice().sort(sortNewest);
    a.sheet(it.name, `
      <div class="statgrid"><div class="stat"><div class="n">${qtyText(it.qty)}</div><div class="l">موجودی ${esc(it.unit)}</div></div>
      <div class="stat"><div class="n">${qtyText(rows.filter((m) => m.dir === "in").reduce((x, m) => x + m.qty, 0))}</div><div class="l">جمع ورود</div></div></div>
      <div class="site-actions"><button type="button" onclick="YSPSite.closeSheet();YSPStock.out('${esc(it.key).replace(/'/g, "\\'")}')">➖ خروج</button><button type="button" onclick="YSPSite.closeSheet();YSPStock.openIn()">➕ ورود</button></div>
      <div class="card"><div class="lbl">📒 سابقه ورود و خروج</div>${rows.map((m) => `<div class="site-row"><div><b>${m.dir === "in" ? "➕ ورود" : "➖ خروج"} ${qtyText(m.qty)} ${esc(m.unit)}</b><div class="s">${esc(YSP.dtShow(m.date, m.at))}${m.receiver ? " · " + esc(m.receiver) : ""}${m.projectId ? " · " + esc(A().projectName(m.projectId)) : ""}${m.note ? " · " + esc(m.note) : ""}</div></div><button type="button" class="site-mini red" onclick="YSPStock.del('${m.id}','${esc(it.key).replace(/'/g, "\\'")}')">🗑️</button></div>`).join("")}</div>`);
  }
  function del(id, key) {
    const m = list().find((x) => x.id === id);
    if (!m) return;
    // removing an "in" must not leave the store negative
    if (m.dir === "in" && balanceOf(key) - Number(m.qty) < 0) { YSP.toast("این ورود را نمی‌شود حذف کرد؛ بعد از آن خروج ثبت شده و موجودی منفی می‌شود."); return; }
    requestDelete(`حذف ${m.dir === "in" ? "ورود" : "خروج"} ${m.item}`, () => { setArr(K, list().filter((x) => x.id !== id)); A().closeSheet(); A().render(); });
  }

  /* ---------- tab ---------- */
  function tab() {
    const a = A(), its = items();
    const inStock = its.filter((i) => i.qty > 0).length;
    const text = its.map((i) => `${i.name}: ${qtyText(i.qty)} ${i.unit}`).join("\n");
    return `<div class="statgrid"><div class="stat"><div class="n">${a.money(its.length)}</div><div class="l">تعداد اقلام</div></div><div class="stat"><div class="n">${a.money(inStock)}</div><div class="l">اقلام موجود</div></div></div>
      <div class="site-actions"><button type="button" onclick="YSPStock.openIn()">➕ ورود به انبار</button><button type="button" onclick="YSPStock.out()">➖ خروج از انبار</button></div>
      ${its.length ? its.map((i) => `<div class="pcard" onclick="YSPStock.item('${esc(i.key).replace(/'/g, "\\'")}')"><div><div class="name">${esc(i.name)}</div><div class="client">${i.moves.length} حرکت · آخرین: ${esc(YSP.dtShow(i.moves.slice().sort(sortNewest)[0].date, i.moves.slice().sort(sortNewest)[0].at))}</div></div><span class="chip ${i.qty > 0 ? "green" : "gray"}">${qtyText(i.qty)} ${esc(i.unit)}</span></div>`).join("") : a.empty("انبار خالی است.<br>ورود کالا را ثبت کن یا هنگام ثبت خرید، گزینه‌ی «ورود به انبار» را بزن.")}
      ${its.length ? `<button type="button" class="save-btn" style="margin-top:12px" onclick="YSPStock.share()">📤 کپی/ارسال موجودی انبار</button>` : ""}`;
  }

  root.YSPStock = {
    hasLink, syncPurchase, removeByEntry, openIn, saveIn, out: openOut, saveOut, pickChanged, item: openItem, del,
    share: () => YSPPlan.gate("site.share", () => YSP.share("موجودی انبار — " + YSP.dtShow("", YSP.nowISO()) + "\n" + items().map((i) => `${i.name}: ${qtyText(i.qty)} ${i.unit}`).join("\n"))),
    items, balanceOf, tab,
  };
  YSPSite.registerTab("stock", "انبار", tab);
})(window);
