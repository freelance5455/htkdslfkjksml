/* Stone Pro plans. The worker section is always free. For owners and contractors some features are
   marked "paid" here. Enforcement is OFF (config.enforced = false) until an online payment/licence
   service exists: a lock that lives only inside the app can be bypassed by anyone who edits the
   page, so it is not worth switching on before there is a server to confirm payments.
   To change what is paid, edit FEATURES and FREE_LIMITS below. */
"use strict";
(function (root) {
  const config = { enforced: false };
  const FEATURES = {
    "site.checks": "چک‌های داده‌شده، هشدار سررسید و افزودن به تقویم",
    "site.meter": "کارکرد متری و جمع متراژ استادکار",
    "site.invoices": "فاکتورها و تطبیق پرداخت با فاکتور",
    "site.reports": "گزارش هزینه به تفکیک پروژه",
    "site.share": "کپی و ارسال صورت‌حساب و گزارش",
  };
  const FREE_LIMITS = { parties: 5, entries: 60 };
  const LIMIT_LABEL = { parties: "تعداد طرف‌های حساب (فروشنده، کارگر، استادکار)", entries: "تعداد ثبت‌های خرید و کارکرد" };

  function plan() {
    try {
      const p = JSON.parse(localStorage.getItem("ysp_plan") || "null");
      return p && p.plan === "pro" && (!p.until || p.until > YSP.nowISO()) ? "pro" : "free";
    } catch (e) { return "free"; }
  }
  const appliesToRole = () => YSP.role() !== "worker";
  const locked = () => config.enforced && appliesToRole() && plan() !== "pro";
  const allowed = () => !locked();

  function modal(title, text) {
    let m = document.getElementById("ysp-plan-modal");
    if (!m) {
      m = document.createElement("div");
      m.id = "ysp-plan-modal";
      m.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,.8);display:none;align-items:center;justify-content:center;z-index:100003;padding:18px;direction:rtl";
      m.innerHTML = '<div style="width:min(360px,94vw);background:#141210;border:1px solid #cda43e;border-radius:18px;padding:18px;color:#f3f1ec;display:flex;flex-direction:column;gap:10px;font-family:inherit"><h3 id="ysp-plan-title" style="margin:0;font-size:16px"></h3><p id="ysp-plan-text" style="margin:0;font-size:13px;line-height:2;color:#cfc9bb"></p><button type="button" id="ysp-plan-close" style="padding:13px;border-radius:14px;border:0;background:linear-gradient(160deg,#e6c265,#cda43e);color:#0b0b0b;font-weight:700;font-family:inherit;font-size:15px">بستن</button></div>';
      document.body.appendChild(m);
      m.querySelector("#ysp-plan-close").onclick = () => { m.style.display = "none"; };
    }
    m.querySelector("#ysp-plan-title").textContent = title;
    m.querySelector("#ysp-plan-text").textContent = text;
    m.style.display = "flex";
  }
  const paywall = (feature) => modal("⭐ امکان اشتراکی", `«${FEATURES[feature] || feature}» در نسخه اشتراکی است. پرداخت آنلاین هنوز فعال نیست؛ با فعال شدن، از همین‌جا اشتراک می‌گیری و اطلاعاتت سر جایش می‌ماند.`);

  /** Runs fn when the feature is allowed, otherwise shows the paywall. Returns true when it ran. */
  function gate(feature, fn) {
    if (allowed()) { if (fn) fn(); return true; }
    paywall(feature);
    return false;
  }
  /** True when adding one more record of this kind would pass the free limit (and tells the user). */
  function limitHit(kind, currentCount) {
    if (!locked() || currentCount < FREE_LIMITS[kind]) return false;
    modal("⭐ سقف نسخه رایگان", `در نسخه رایگان تا ${FREE_LIMITS[kind]} مورد برای «${LIMIT_LABEL[kind]}» ممکن است. برای بیشتر، اشتراک لازم است. پرداخت آنلاین هنوز فعال نیست.`);
    return true;
  }
  function summaryHtml() {
    const items = Object.keys(FEATURES).map((k) => `<li>${esc(FEATURES[k])}</li>`).join("");
    const state = !config.enforced ? "فعلاً همه‌ی امکانات رایگان است (دوره‌ی آزمایشی)." : plan() === "pro" ? "اشتراک فعال است." : "نسخه‌ی رایگان.";
    return `<div class="client" style="margin-bottom:8px">${esc(state)}</div>
      <div class="client" style="margin-bottom:6px">بخش کارگر همیشه رایگان است. برای صاحبکار و پیمانکار، این موارد اشتراکی خواهند بود:</div>
      <ul class="client" style="margin:0 18px 8px 0;line-height:2">${items}<li>بیشتر از ${FREE_LIMITS.parties} طرف حساب یا ${FREE_LIMITS.entries} ثبت</li></ul>`;
  }

  root.YSPPlan = { config, FEATURES, FREE_LIMITS, plan, allowed, locked, gate, limitHit, summaryHtml };
})(window);
