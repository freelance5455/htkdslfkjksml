package com.rayan.accounting

import android.Manifest
import android.content.Intent
import android.content.ContentValues
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.util.Base64
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.webkit.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var pendingFileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingPermissionRequest: PermissionRequest? = null

    private val filePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val data = if (result.resultCode == RESULT_OK) result.data?.data?.let { arrayOf(it) } else null
        pendingFileCallback?.onReceiveValue(data)
        pendingFileCallback = null
    }

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val request = pendingPermissionRequest
        pendingPermissionRequest = null
        if (granted && request != null) request.grant(request.resources)
        else request?.deny()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WebView.setWebContentsDebuggingEnabled(false)
        webView = WebView(this)
        setContentView(webView)
        webView.addJavascriptInterface(NativeFiles(), "AndroidFiles")

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                return if (url.host == "appassets.androidplatform.net") false else {
                    if (url.scheme == "https" && (url.host == "wa.me" || url.host == "www.whatsapp.com")) {
                        startActivity(Intent(Intent.ACTION_VIEW, url))
                    }
                    true
                }
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                pendingFileCallback?.onReceiveValue(null)
                pendingFileCallback = callback
                return try {
                    filePicker.launch(params.createIntent())
                    true
                } catch (_: Exception) {
                    pendingFileCallback = null
                    false
                }
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
                        if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                            request.grant(request.resources)
                        } else {
                            pendingPermissionRequest = request
                            cameraPermission.launch(Manifest.permission.CAMERA)
                        }
                    } else request.deny()
                }
            }
        }
        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }


    inner class NativeFiles {
        @JavascriptInterface fun saveFile(name: String, mime: String, data: String): String {
            return try {
                val bytes = Base64.decode(data, Base64.DEFAULT)
                val values = ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, name); put(MediaStore.MediaColumns.MIME_TYPE, mime); put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/RayanAccounting") }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return "ERROR: ایجاد فایل ناموفق بود"
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: return "ERROR: نوشتن فایل ناموفق بود"
                "OK"
            } catch (e: Exception) { "ERROR: ${e.message ?: "خطای ذخیره فایل"}" }
        }
        @JavascriptInterface fun shareFile(name: String, mime: String, data: String): String {
            return try {
                val bytes = Base64.decode(data, Base64.DEFAULT)
                val values = ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, name); put(MediaStore.MediaColumns.MIME_TYPE, mime); put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/RayanAccounting") }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return "ERROR: ساخت فایل اشتراک ناموفق بود"
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: return "ERROR: نوشتن فایل ناموفق بود"
                val intent = Intent(Intent.ACTION_SEND).apply { type = mime; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                runOnUiThread { startActivity(Intent.createChooser(intent, "اشتراک‌گذاری بل")) }
                "OK"
            } catch (e: Exception) { "ERROR: ${e.message ?: "خطای اشتراک‌گذاری"}" }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        pendingFileCallback?.onReceiveValue(null)
        pendingFileCallback = null
        webView.destroy()
        super.onDestroy()
    }
}
