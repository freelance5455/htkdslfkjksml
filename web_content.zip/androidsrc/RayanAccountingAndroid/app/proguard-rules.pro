# No custom rules required for the initial WebView wrapper.
