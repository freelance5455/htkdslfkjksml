(function () {
'use strict';

/* ================= ثابت‌ها ================= */
const SECTIONS = [
  { id: 'tasks',  icon: '✅' },
  { id: 'notes',  icon: '📝' },
  { id: 'shop',   icon: '🛒' },
  { id: 'habits', icon: '🔥' },
  { id: 'timer',  icon: '⏱️' },
  { id: 'money',  icon: '💰' },
  { id: 'goals',  icon: '🎯' },
  { id: 'stats',  icon: '📊' }
];
/* ===== آیکون‌های دلخواه =====
   عکس‌هات (PNG/SVG/WebP) را در پوشه‌ای کنار index.html به نام icons بگذار
   و نام فایل را جلوی هر بخش بنویس. خالی = همان ایموجی. */
const ICON_FILES = {
  tasks:  '',   // مثلا 'icons/tasks.png'
  notes:  '',
  shop:   '',
  habits: '',
  timer:  '',
  money:  '',
  goals:  '',
  stats:  ''
};
function iconHtml(s) {
  const f = ICON_FILES[s.id];
  if (!f) return s.icon;
  return '<img class="ic-img" src="' + f + '" alt="" draggable="false" onerror="this.replaceWith(document.createTextNode(\'' + s.icon + '\'))">';
}
const N = SECTIONS.length;
const STEP = 360 / N;
const ACCENTS = [
  ['#38bdf8', '#6366f1'], ['#34d399', '#059669'], ['#f472b6', '#db2777'],
  ['#fb923c', '#ea580c'], ['#a78bfa', '#7c3aed']
];
const CAT_ICONS = ['🍽️', '🚌', '🛍️', '🧾', '🎮', '📦'];
const PRI_ICON = ['🟢', '🟡', '🔴'];
const ICONS = ['🎯', '📚', '💪', '💰', '✈️', '🏠', '🎓', '❤️'];
const CLOUDY = ['tasks', 'notes', 'shop', 'goals', 'habits'];
const HEAD = 170;
const HUBOFF = 16;
const HUBR = 19;
const SHAPES = ['cl-a', 'cl-b', 'cl-c'];

/* ================= زبان ================= */
let LANG = 'fa';
function NL() { return LANG === 'en' ? 'en-US' : 'fa-IR'; }
function t(k) {
  const a = arguments;
  if (k === 'cur') return curLabel();
  let s = (D[LANG] && D[LANG][k] !== undefined) ? D[LANG][k] : (D.fa[k] !== undefined ? D.fa[k] : k);
  if (s.indexOf('{cur}') > -1) s = s.replace(/\{cur\}/g, curLabel());
  if (a.length > 1) s = s.replace(/\{(\d)\}/g, function (m, i) { const v = a[Number(i) + 1]; return v === undefined ? m : v; });
  return s;
}

/* ================= ابزارها ================= */
const $ = id => document.getElementById(id);
const view = $('view');
const wheel = $('wheel');
const ring = $('ring');

function pad(n) { return n < 10 ? '0' + n : '' + n; }
function dayKey(d) {
  d = d || new Date();
  return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
}
function dayKeyAgo(n) { const d = new Date(); d.setDate(d.getDate() - n); return dayKey(d); }
function nf(n, g) {
  n = Number(n) || 0;
  try { return n.toLocaleString(NL(), { useGrouping: !!g, maximumFractionDigits: g ? 2 : 0 }); }
  catch (e) { return String(Math.round(n)); }
}
function nd(n) {
  n = Number(n) || 0;
  try { return n.toLocaleString(NL(), { useGrouping: true, maximumFractionDigits: 2 }); }
  catch (e) { return String(n); }
}
function fp(n) { return (n < 10 ? (LANG === 'en' ? '0' : '۰') : '') + nf(n); }
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function toEn(s) {
  return String(s == null ? '' : s)
    .replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))
    .replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))
    .replace(/٫/g, '.')
    .replace(/[٬,،\s]/g, '');
}
function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
function hash(s) { let h = 0; s = String(s); for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h); }
function hashFrac(s, salt) { return (hash(s + salt) % 1000) / 1000; }
function val(id) { const e = $(id); return e ? e.value : ''; }
function empty(msg) { return '<div class="empty">' + msg + '</div>'; }
function sum(a) { return a.reduce((p, c) => p + c, 0); }

/* اعداد با جداکنندهٔ سه‌رقمی (قیمت و مبلغ) */
function faDig(s) { return LANG === 'en' ? String(s) : String(s).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]); }
function groupInt(ds) {
  return faDig(String(ds).replace(/\B(?=(\d{3})+(?!\d))/g, LANG === 'en' ? ',' : '٬'));
}
function fmtNumVal(n) {
  n = Number(n);
  if (!n || !isFinite(n)) return '';
  const s = String(Math.round(n * 100) / 100);
  const i = s.indexOf('.');
  const ip = i > -1 ? s.slice(0, i) : s, fr = i > -1 ? s.slice(i + 1) : '';
  return groupInt(ip) + (fr ? (LANG === 'en' ? '.' : '٫') + faDig(fr) : '');
}
function numFmt(el, dec) {
  const raw = el.value;
  const pos = el.selectionStart == null ? raw.length : el.selectionStart;
  const before = toEn(raw.slice(0, pos)).replace(/[^\d.]/g, '').length;
  let s = toEn(raw).replace(/[^\d.]/g, '');
  if (!dec) s = s.replace(/\./g, '');
  else { const i = s.indexOf('.'); if (i > -1) s = s.slice(0, i + 1) + s.slice(i + 1).replace(/\./g, ''); }
  let ip = s, fr = '';
  const di = s.indexOf('.');
  if (di > -1) { ip = s.slice(0, di); fr = s.slice(di + 1, di + 3); }
  ip = ip.replace(/^0+(?=\d)/, '').slice(0, 15);
  let out = groupInt(ip);
  if (di > -1) out += (LANG === 'en' ? '.' : '٫') + faDig(fr);
  if (out === el.value) return;
  el.value = out;
  let p = 0, c = 0;
  while (p < out.length && c < before) { if (/[0-9۰-۹.٫]/.test(out[p])) c++; p++; }
  try { el.setSelectionRange(p, p); } catch (e) {}
}
function fmtClock(sec) {
  sec = Math.max(0, Math.round(sec));
  const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
  return (h ? h + ':' + pad(m) : pad(m)) + ':' + pad(s);
}

function hm(ts) {
  const d = new Date(ts);
  try { return d.toLocaleTimeString(NL(), { hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }); }
  catch (e) { return pad(d.getHours()) + ':' + pad(d.getMinutes()); }
}
function dayLabel(k) {
  if (k === dayKey()) return t('today');
  const p = String(k).split('-').map(Number);
  if (p.length < 3 || p.some(isNaN)) return String(k);
  try { return new Date(p[0], p[1] - 1, p[2]).toLocaleDateString(NL(), { month: 'long', day: 'numeric' }); }
  catch (e) { return String(k); }
}
function wd(d) {
  try { return d.toLocaleDateString(NL(), { weekday: 'short' }); }
  catch (e) { return String(d.getDate()); }
}
function fmtDay(ts) {
  const d = new Date(ts), tm = new Date();
  tm.setDate(tm.getDate() + 1);
  const k = dayKey(d);
  if (k === dayKey()) return t('today');
  if (k === dayKey(tm)) return t('tomorrow');
  return dayLabel(k);
}
function fmtDue(ts) { return fmtDay(ts) + ' ' + hm(ts); }
function remText(ms) {
  const late = ms < 0;
  const m = late ? Math.floor(-ms / 60000) : Math.ceil(ms / 60000);
  if (late && m < 1) return t('now');
  const h = Math.floor(m / 60), mm = m % 60;
  let s;
  if (h >= 24) s = nf(Math.floor(h / 24)) + ' ' + t('u_day');
  else if (h >= 1) s = nf(h) + ' ' + t('u_hour') + (mm ? t('and') + nf(mm) + ' ' + t('u_min') : '');
  else s = nf(m) + ' ' + t('u_min');
  return s + ' ' + t(late ? 'overdue' : 'left');
}
function mkTime(ds, ts) {
  const p = String(ds).split('-').map(Number), q = String(ts).split(':').map(Number);
  if (p.length < 3 || q.length < 2 || p.some(isNaN) || q.some(isNaN)) return null;
  const tt = new Date(p[0], p[1] - 1, p[2], q[0], q[1], 0, 0).getTime();
  return isNaN(tt) ? null : tt;
}
function copyText(s) {
  try { if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(s); return true; } } catch (e) {}
  try {
    const a = document.createElement('textarea');
    a.value = s;
    a.style.cssText = 'position:fixed;top:0;left:0;opacity:0';
    document.body.appendChild(a);
    a.focus(); a.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(a);
    return ok;
  } catch (e) { return false; }
}
function endOfWeek() {
  const d = new Date();
  const add = LANG === 'en' ? (7 - d.getDay()) % 7 : (5 - d.getDay() + 7) % 7;
  d.setDate(d.getDate() + add);
  d.setHours(23, 59, 0, 0);
  return d.getTime();
}
function monthOptions() {
  let fmt = null;
  try { fmt = new Intl.DateTimeFormat(NL(), { month: 'long' }); } catch (e) {}
  const out = [];
  let last = null;
  for (let i = 0; i < 400 && out.length <= 12; i++) {
    const d = new Date();
    d.setDate(d.getDate() + i);
    d.setHours(23, 59, 0, 0);
    let lb;
    try { lb = fmt ? fmt.format(d) : String(d.getMonth() + 1); } catch (e) { lb = String(d.getMonth() + 1); }
    if (lb !== last) { out.push({ label: lb, end: d.getTime() }); last = lb; }
    else out[out.length - 1].end = d.getTime();
  }
  return out.slice(0, 12);
}
function monthName(ts) {
  try { return new Date(ts).toLocaleDateString(NL(), { month: 'long' }); } catch (e) { return ''; }
}
function whenLabel(x) {
  if (x.when === 'week') return t('thisWeek');
  if (x.when === 'funded') return t('whenFunded');
  if (x.when === 'month' && x.wd) return monthName(x.wd);
  if (x.when === 'date' && x.wd) return fmtDay(x.wd);
  return '';
}

/* تقویم (شمسی یا میلادی طبق زبان) */
let PFMT = null;
function calInfo(d) {
  if (LANG === 'en') return { key: d.getFullYear() + '-' + pad(d.getMonth() + 1), dom: d.getDate() };
  try {
    if (!PFMT) PFMT = new Intl.DateTimeFormat('en-US-u-ca-persian-nu-latn', { year: 'numeric', month: 'numeric', day: 'numeric' });
    let y = '', m = '', dd = '';
    PFMT.formatToParts(d).forEach(p => {
      if (p.type === 'year' || p.type === 'relatedYear') y = p.value;
      if (p.type === 'month') m = p.value;
      if (p.type === 'day') dd = p.value;
    });
    if (y && m && dd) return { key: y + '-' + pad(Number(m)), dom: Number(dd) };
  } catch (e) {}
  return { key: d.getFullYear() + '-' + pad(d.getMonth() + 1), dom: d.getDate() };
}
function calMonth(v) {
  const info = calInfo(v);
  const d0 = new Date(v.getFullYear(), v.getMonth(), v.getDate() - (info.dom - 1), 12);
  const days = [], d = new Date(d0.getTime());
  for (let i = 0; i < 40; i++) {
    if (calInfo(d).key !== info.key) break;
    days.push(new Date(d.getTime()));
    d.setDate(d.getDate() + 1);
  }
  return days;
}
function calStep(v, dir) {
  const days = calMonth(v);
  if (!days.length) return v;
  if (dir < 0) { const f = days[0]; return new Date(f.getFullYear(), f.getMonth(), f.getDate() - 1, 12); }
  const l = days[days.length - 1];
  return new Date(l.getFullYear(), l.getMonth(), l.getDate() + 1, 12);
}
const mkCache = {};
function monthInfo(d) {
  const key = calInfo(d).key;
  let label;
  try { label = LANG === 'en' ? d.toLocaleDateString('en-US', { month: 'short' }) : d.toLocaleDateString('fa-IR', { month: 'long' }); }
  catch (e) { label = String(d.getMonth() + 1); }
  return { key: key, label: label };
}
function monthKeyOfDay(k) {
  if (mkCache[k]) return mkCache[k];
  const p = String(k).split('-').map(Number);
  const key = monthInfo(new Date(p[0], (p[1] || 1) - 1, p[2] || 1, 12)).key;
  mkCache[k] = key;
  return key;
}

/* ================= هش رمز (برای دفتر خاطرات) ================= */
const SH = (function () {
  const K = [], H0 = [], primes = [];
  let n = 2;
  while (primes.length < 64) {
    let ok = true;
    for (let i = 2; i * i <= n; i++) { if (n % i === 0) { ok = false; break; } }
    if (ok) primes.push(n);
    n++;
  }
  const fr = x => x - Math.floor(x);
  for (let i = 0; i < 64; i++) K[i] = Math.floor(fr(Math.pow(primes[i], 1 / 3)) * 4294967296) >>> 0;
  for (let i = 0; i < 8; i++) H0[i] = Math.floor(fr(Math.sqrt(primes[i])) * 4294967296) >>> 0;
  return { K: K, H0: H0 };
})();
function sha256(str) {
  const bin = unescape(encodeURIComponent(str));
  const bytes = [];
  for (let i = 0; i < bin.length; i++) bytes.push(bin.charCodeAt(i));
  const l = bytes.length;
  bytes.push(0x80);
  while (bytes.length % 64 !== 56) bytes.push(0);
  const hi = Math.floor(l * 8 / 4294967296), lo = (l * 8) >>> 0;
  bytes.push((hi >>> 24) & 255, (hi >>> 16) & 255, (hi >>> 8) & 255, hi & 255, (lo >>> 24) & 255, (lo >>> 16) & 255, (lo >>> 8) & 255, lo & 255);
  const H = SH.H0.slice(), w = new Array(64);
  const rr = (v, a) => (v >>> a) | (v << (32 - a));
  for (let o = 0; o < bytes.length; o += 64) {
    for (let i = 0; i < 16; i++) w[i] = ((bytes[o + i * 4] << 24) | (bytes[o + i * 4 + 1] << 16) | (bytes[o + i * 4 + 2] << 8) | bytes[o + i * 4 + 3]) | 0;
    for (let i = 16; i < 64; i++) {
      const s0 = rr(w[i - 15], 7) ^ rr(w[i - 15], 18) ^ (w[i - 15] >>> 3);
      const s1 = rr(w[i - 2], 17) ^ rr(w[i - 2], 19) ^ (w[i - 2] >>> 10);
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
    }
    let a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
    for (let i = 0; i < 64; i++) {
      const S1 = rr(e, 6) ^ rr(e, 11) ^ rr(e, 25);
      const ch = (e & f) ^ (~e & g);
      const t1 = (h + S1 + ch + SH.K[i] + w[i]) | 0;
      const S0 = rr(a, 2) ^ rr(a, 13) ^ rr(a, 22);
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const t2 = (S0 + maj) | 0;
      h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
    }
    H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
    H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
  }
  return H.map(x => ('00000000' + (x >>> 0).toString(16)).slice(-8)).join('');
}
function hashPw(pw, salt) {
  let h = sha256(salt + ':' + pw);
  for (let i = 0; i < 3000; i++) h = sha256(h + salt + pw);
  return h;
}


/* ================= رمزگذاری دفتر خاطرات (AES-256 حالت CTR + امضای سلامت) =================
   بدون وابستگی به WebCrypto، پس در هر WebView و حتی بدون اینترنت و بدون https کار می‌کند. */
const AES = (function () {
  const sb = new Array(256);
  let p = 1, q = 1;
  const rotl = (x, n) => ((x << n) | (x >> (8 - n))) & 255;
  do {
    p = (p ^ ((p << 1) & 255) ^ ((p & 0x80) ? 0x1b : 0)) & 255;
    q ^= (q << 1) & 255; q ^= (q << 2) & 255; q ^= (q << 4) & 255;
    if (q & 0x80) q ^= 0x09;
    q &= 255;
    sb[p] = (q ^ rotl(q, 1) ^ rotl(q, 2) ^ rotl(q, 3) ^ rotl(q, 4) ^ 0x63) & 255;
  } while (p !== 1);
  sb[0] = 0x63;
  const xt = x => ((x << 1) ^ ((x & 0x80) ? 0x1b : 0)) & 255;
  function expand(key) {
    const w = new Array(240);
    for (let i = 0; i < 32; i++) w[i] = key[i];
    let rc = 1;
    for (let i = 32; i < 240; i += 4) {
      let a = w[i - 4], b = w[i - 3], c = w[i - 2], d = w[i - 1];
      if (i % 32 === 0) { const t0 = a; a = sb[b] ^ rc; b = sb[c]; c = sb[d]; d = sb[t0]; rc = xt(rc); }
      else if (i % 32 === 16) { a = sb[a]; b = sb[b]; c = sb[c]; d = sb[d]; }
      w[i] = w[i - 32] ^ a; w[i + 1] = w[i - 31] ^ b; w[i + 2] = w[i - 30] ^ c; w[i + 3] = w[i - 29] ^ d;
    }
    return w;
  }
  function block(rk, inp) {
    let s = new Array(16), n = new Array(16);
    for (let i = 0; i < 16; i++) s[i] = inp[i] ^ rk[i];
    for (let r = 1; r <= 14; r++) {
      for (let i = 0; i < 16; i++) s[i] = sb[s[i]];
      for (let c = 0; c < 4; c++) for (let rw = 0; rw < 4; rw++) n[c * 4 + rw] = s[((c + rw) & 3) * 4 + rw];
      if (r < 14) {
        for (let c = 0; c < 4; c++) {
          const a0 = n[c * 4], a1 = n[c * 4 + 1], a2 = n[c * 4 + 2], a3 = n[c * 4 + 3];
          const all = a0 ^ a1 ^ a2 ^ a3;
          s[c * 4] = a0 ^ all ^ xt(a0 ^ a1);
          s[c * 4 + 1] = a1 ^ all ^ xt(a1 ^ a2);
          s[c * 4 + 2] = a2 ^ all ^ xt(a2 ^ a3);
          s[c * 4 + 3] = a3 ^ all ^ xt(a3 ^ a0);
        }
      } else s = n.slice();
      for (let i = 0; i < 16; i++) s[i] ^= rk[r * 16 + i];
    }
    return s;
  }
  function ctr(rk, iv, data) {
    const cnt = iv.slice(), out = new Array(data.length);
    for (let o = 0; o < data.length; o += 16) {
      const ks = block(rk, cnt);
      for (let i = 0; i < 16 && o + i < data.length; i++) out[o + i] = data[o + i] ^ ks[i];
      for (let j = 15; j >= 0; j--) { cnt[j] = (cnt[j] + 1) & 255; if (cnt[j]) break; }
    }
    return out;
  }
  return { expand: expand, ctr: ctr, block: block };
})();
function toHex(b) { let s = ''; for (let i = 0; i < b.length; i++) s += ('0' + b[i].toString(16)).slice(-2); return s; }
function fromHex(h) { const b = []; for (let i = 0; i + 1 < h.length; i += 2) b.push(parseInt(h.substr(i, 2), 16)); return b; }
function strBytes(str) { const bin = unescape(encodeURIComponent(str)), b = []; for (let i = 0; i < bin.length; i++) b.push(bin.charCodeAt(i)); return b; }
function bytesStr(b) { let bin = ''; for (let i = 0; i < b.length; i++) bin += String.fromCharCode(b[i]); try { return decodeURIComponent(escape(bin)); } catch (e) { return null; } }
function randBytes(n) {
  const b = new Array(n);
  try { const u = new Uint8Array(n); (window.crypto || window.msCrypto).getRandomValues(u); for (let i = 0; i < n; i++) b[i] = u[i]; return b; } catch (e) {}
  for (let i = 0; i < n; i++) b[i] = Math.floor(Math.random() * 256) ^ ((Date.now() >> (i % 8)) & 255);
  return b;
}
function deriveDiaryKey(pw, salt) {
  const dk = hashPw(pw, 'k:' + salt);
  return { rk: AES.expand(fromHex(dk)), mac: sha256('m:' + dk) };
}
function encBlob(key, plain) {
  const iv = randBytes(16), c = toHex(AES.ctr(key.rk, iv, strBytes(plain))), ivh = toHex(iv);
  return 'v1.' + ivh + '.' + c + '.' + sha256(key.mac + '|' + ivh + '|' + c + '|' + key.mac);
}
function decBlob(key, blob) {
  const p = String(blob).split('.');
  if (p.length !== 4 || p[0] !== 'v1') return null;
  if (sha256(key.mac + '|' + p[1] + '|' + p[2] + '|' + key.mac) !== p[3]) return null;
  return bytesStr(AES.ctr(key.rk, fromHex(p[1]), fromHex(p[2])));
}

/* ================= واحدهای پولی ================= */
const FS_STEPS = [0.88, 1, 1.14, 1.3, 1.5];
const CURRENCIES = [
  { c: 'IRT', fa: 'تومان', en: 'Toman', s: 'تومان' }, { c: 'IRR', fa: 'ریال', en: 'Rial', s: 'ریال' },
  { c: 'USD', fa: 'دلار آمریکا', en: 'US Dollar', s: '$' }, { c: 'EUR', fa: 'یورو', en: 'Euro', s: '€' },
  { c: 'GBP', fa: 'پوند انگلیس', en: 'British Pound', s: '£' }, { c: 'AED', fa: 'درهم امارات', en: 'UAE Dirham', s: 'AED' },
  { c: 'TRY', fa: 'لیر ترکیه', en: 'Turkish Lira', s: '₺' }, { c: 'CAD', fa: 'دلار کانادا', en: 'Canadian Dollar', s: 'CA$' },
  { c: 'AUD', fa: 'دلار استرالیا', en: 'Australian Dollar', s: 'A$' }, { c: 'CHF', fa: 'فرانک سوئیس', en: 'Swiss Franc', s: 'CHF' },
  { c: 'JPY', fa: 'ین ژاپن', en: 'Japanese Yen', s: '¥' }, { c: 'CNY', fa: 'یوان چین', en: 'Chinese Yuan', s: 'CN¥' },
  { c: 'INR', fa: 'روپیه هند', en: 'Indian Rupee', s: '₹' }, { c: 'RUB', fa: 'روبل روسیه', en: 'Russian Ruble', s: '₽' },
  { c: 'SAR', fa: 'ریال عربستان', en: 'Saudi Riyal', s: 'SAR' }, { c: 'KWD', fa: 'دینار کویت', en: 'Kuwaiti Dinar', s: 'KWD' },
  { c: 'QAR', fa: 'ریال قطر', en: 'Qatari Riyal', s: 'QAR' }, { c: 'OMR', fa: 'ریال عمان', en: 'Omani Rial', s: 'OMR' },
  { c: 'BHD', fa: 'دینار بحرین', en: 'Bahraini Dinar', s: 'BHD' }, { c: 'IQD', fa: 'دینار عراق', en: 'Iraqi Dinar', s: 'IQD' },
  { c: 'AFN', fa: 'افغانی', en: 'Afghan Afghani', s: '؋' }, { c: 'PKR', fa: 'روپیه پاکستان', en: 'Pakistani Rupee', s: 'Rs' },
  { c: 'AZN', fa: 'منات آذربایجان', en: 'Azerbaijani Manat', s: '₼' }, { c: 'GEL', fa: 'لاری گرجستان', en: 'Georgian Lari', s: '₾' },
  { c: 'AMD', fa: 'درام ارمنستان', en: 'Armenian Dram', s: '֏' }, { c: 'KZT', fa: 'تنگه قزاقستان', en: 'Kazakhstani Tenge', s: '₸' },
  { c: 'UZS', fa: 'سوم ازبکستان', en: 'Uzbekistani Som', s: 'UZS' }, { c: 'SEK', fa: 'کرون سوئد', en: 'Swedish Krona', s: 'kr' },
  { c: 'NOK', fa: 'کرون نروژ', en: 'Norwegian Krone', s: 'NOK' }, { c: 'DKK', fa: 'کرون دانمارک', en: 'Danish Krone', s: 'DKK' },
  { c: 'PLN', fa: 'زلوتی لهستان', en: 'Polish Zloty', s: 'zł' }, { c: 'CZK', fa: 'کرون چک', en: 'Czech Koruna', s: 'Kč' },
  { c: 'HUF', fa: 'فورینت مجارستان', en: 'Hungarian Forint', s: 'Ft' }, { c: 'UAH', fa: 'گریونا اوکراین', en: 'Ukrainian Hryvnia', s: '₴' },
  { c: 'BRL', fa: 'رئال برزیل', en: 'Brazilian Real', s: 'R$' }, { c: 'MXN', fa: 'پزو مکزیک', en: 'Mexican Peso', s: 'MX$' },
  { c: 'KRW', fa: 'وون کره جنوبی', en: 'South Korean Won', s: '₩' }, { c: 'THB', fa: 'بات تایلند', en: 'Thai Baht', s: '฿' },
  { c: 'MYR', fa: 'رینگیت مالزی', en: 'Malaysian Ringgit', s: 'RM' }, { c: 'SGD', fa: 'دلار سنگاپور', en: 'Singapore Dollar', s: 'S$' },
  { c: 'IDR', fa: 'روپیه اندونزی', en: 'Indonesian Rupiah', s: 'Rp' }, { c: 'EGP', fa: 'پوند مصر', en: 'Egyptian Pound', s: 'E£' },
  { c: 'ZAR', fa: 'رند آفریقای جنوبی', en: 'South African Rand', s: 'R' }, { c: 'NGN', fa: 'نایرا نیجریه', en: 'Nigerian Naira', s: '₦' },
  { c: 'ILS', fa: 'شکل اسرائیل', en: 'Shekel', s: '₪' },
  { c: 'BTC', fa: 'بیت‌کوین', en: 'Bitcoin', s: '₿' }, { c: 'ETH', fa: 'اتریوم', en: 'Ethereum', s: 'ETH' },
  { c: 'USDT', fa: 'تتر', en: 'Tether', s: 'USDT' },
  { c: 'COIN', fa: 'سکه طلا', en: 'Gold coin', s: 'سکه' }, { c: 'GOLD', fa: 'گرم طلا', en: 'Gold gram', s: 'g Au' }
];
function curLabel() {
  const c = CURRENCIES.find(x => x.c === (S && S.set && S.set.cur)) || CURRENCIES[0];
  if (LANG !== 'en') return c.fa;
  return ({ IRT: 'Toman', IRR: 'Rial', COIN: 'Gold coin', GOLD: 'g gold' })[c.c] || c.c;
}

/* ================= ذخیره‌سازی ================= */
const KEY = 'daily_app_v1';
const ARR = ['tasks', 'notes', 'shop', 'habits', 'money', 'goals'];
function def() {
  return {
    tasks: [], notes: [], shop: [], habits: [], money: [], goals: [], log: [], slots: [0, 0, 0, 0], slotsSec: 1, qtimers: [],
    diary: { hash: '', salt: '', secs: [] },
    set: { theme: 'dark', accent: 0, sound: true, vib: true, budget: 0, wheel: true, lang: 'fa', fs: 1, ff: 'nimbo', cur: 'IRT' }
  };
}
function subsNorm(a) {
  return Array.isArray(a)
    ? a.filter(x => x && x.id).map(x => ({ id: String(x.id), t: String(x.t == null ? '' : x.t), d: !!x.d }))
    : [];
}
function buildLog(d, pm) {
  const L = [];
  d.tasks.forEach(tk => { if (tk.done && tk.doneAt) L.push({ id: uid(), k: 't', d: dayKey(new Date(tk.doneAt)), n: tk.title, ref: tk.id }); });
  d.habits.forEach(h => { h.days.forEach(k => { if (/^\d{4}-\d\d-\d\d$/.test(k)) L.push({ id: uid(), k: 'h', d: k, n: h.name, ref: h.id }); }); });
  d.money.forEach(m => L.push({ id: uid(), k: 'm', d: m.d, n: m.t || '', a: m.a, c: Number.isInteger(m.c) ? m.c : 5, ref: m.id }));
  Object.keys(pm).forEach(k => {
    const c = Math.min(30, pm[k]);
    for (let i = 0; i < c; i++) L.push({ id: uid(), k: 'p', d: k, n: '' });
  });
  return L;
}
function norm(o) {
  const d = def();
  if (o && typeof o === 'object') {
    ARR.forEach(k => {
      if (Array.isArray(o[k])) d[k] = o[k].filter(x => x && typeof x === 'object' && x.id);
    });
    d.tasks.forEach(x => { x.subs = subsNorm(x.subs); x.title = String(x.title == null ? '' : x.title); });
    d.notes.forEach(x => { x.text = String(x.text == null ? '' : x.text); x.title = String(x.title == null ? '' : x.title); x.t = Number(x.t) || Date.now(); });
    d.habits.forEach(h => {
      h.subs = subsNorm(h.subs);
      h.name = String(h.name == null ? '' : h.name);
      h.days = Array.isArray(h.days) ? h.days.map(String) : [];
      h.wd = Array.isArray(h.wd) ? h.wd.map(Number).filter((x, i, a) => x >= 0 && x <= 6 && a.indexOf(x) === i) : [];
      if (!h.sd || typeof h.sd !== 'object' || Array.isArray(h.sd)) h.sd = {};
    });
    d.goals.forEach(g => {
      if (g.target == null) { g.target = 100; g.cur = Number(g.p) || 0; g.unit = '%'; }
      g.target = Number(g.target) > 0 ? Number(g.target) : 100;
      g.cur = Number(g.cur) || 0;
      g.unit = String(g.unit == null ? '' : g.unit);
      g.step = Number(g.step) > 0 ? Number(g.step) : Math.max(1, Math.round(g.target / 10));
      g.icon = g.icon || '🎯';
      g.title = String(g.title == null ? '' : g.title);
    });
    d.shop.forEach(x => {
      x.text = String(x.text == null ? '' : x.text);
      x.price = Number(x.price) || 0;
      x.saved = Number(x.saved) || 0;
      x.when = x.when || ''; x.wd = Number(x.wd) || 0;
    });
    d.money.forEach(m => { m.a = Number(m.a) || 0; m.d = /^\d{4}-\d\d-\d\d$/.test(String(m.d)) ? String(m.d) : dayKey(); });
    const pm = {};
    if (o.pomo && typeof o.pomo === 'object' && !Array.isArray(o.pomo)) {
      Object.keys(o.pomo).forEach(k => { const n = Number(o.pomo[k]); if (n > 0) pm[k] = n; });
    }
    if (Array.isArray(o.log)) {
      d.log = o.log
        .filter(e => e && e.id && ['t', 'h', 'm', 'p'].indexOf(e.k) > -1 && /^\d{4}-\d\d-\d\d$/.test(String(e.d)))
        .map(e => {
          const x = { id: String(e.id), k: e.k, d: String(e.d), n: String(e.n == null ? '' : e.n) };
          if (e.a != null) x.a = Number(e.a) || 0;
          if (Number.isInteger(e.c)) x.c = e.c;
          if (e.ref != null) x.ref = String(e.ref);
          return x;
        });
    } else d.log = buildLog(d, pm);
    if (Array.isArray(o.qtimers)) {
      d.qtimers = o.qtimers.filter(q => q && q.id && Number(q.end) > 0)
        .map(q => ({ id: String(q.id), label: String(q.label == null ? '' : q.label), end: Number(q.end), total: Number(q.total) || 60, created: Number(q.created) || Date.now() }));
    }
    if (Array.isArray(o.slots)) {
      const f = o.slotsSec ? 1 : 60; d.slotsSec = 1;
      for (let i = 0; i < 4; i++) { const n = Math.round(Number(o.slots[i]) * f); d.slots[i] = (n >= 5 && n <= 36000) ? n : 0; }
    }
    const dy = o.diary;
    if (dy && typeof dy === 'object') {
      d.diary.hash = String(dy.hash || '');
      d.diary.salt = String(dy.salt || '');
      if (Array.isArray(dy.secs)) {
        d.diary.secs = dy.secs.filter(x => x && x.id).map(x => x.enc
          ? { id: String(x.id), enc: String(x.enc), t: Number(x.t) || Date.now() }
          : { id: String(x.id), title: String(x.title == null ? '' : x.title), text: String(x.text == null ? '' : x.text), t: Number(x.t) || Date.now() });
      }
    }
    const s = o.set;
    if (s && typeof s === 'object') {
      d.set.theme = ['dark', 'light', 'auto'].indexOf(s.theme) > -1 ? s.theme : (s.light ? 'light' : 'dark');
      const ac = Number(s.accent);
      d.set.accent = (ac >= 0 && ac < ACCENTS.length) ? Math.floor(ac) : 0;
      d.set.sound = s.sound !== false;
      d.set.vib = s.vib !== false;
      d.set.budget = Number(s.budget) > 0 ? Number(s.budget) : 0;
      d.set.wheel = s.wheel !== false;
      d.set.lang = s.lang === 'en' ? 'en' : 'fa';
      d.set.fs = (Number(s.fs) >= 0 && Number(s.fs) < FS_STEPS.length) ? Math.floor(Number(s.fs)) : 1;
      d.set.ff = s.ff === 'system' ? 'system' : 'nimbo';
      d.set.cur = CURRENCIES.some(c => c.c === s.cur) ? s.cur : 'IRT';
    }
  }
  return d;
}
function load() {
  try { const r = localStorage.getItem(KEY); if (r) return norm(JSON.parse(r)); } catch (e) {}
  return def();
}
let S = load();
let dKey = null;          // کلید دفتر خاطرات، فقط وقتی قفل باز است در حافظه می‌ماند
const encCache = {};
function diaryBlob(n) {
  if (n.enc) return n.enc;
  const src = (n.title || '') + '\u0001' + (n.text || '');
  const c = encCache[n.id];
  if (c && c.s === src) return c.e;
  const e = encBlob(dKey, JSON.stringify({ a: n.title || '', b: n.text || '' }));
  encCache[n.id] = { s: src, e: e };
  return e;
}
function ser() {
  if (!S.diary.hash) return JSON.stringify(S);
  const secs = S.diary.secs.map(n => (n.enc || dKey) ? { id: n.id, t: n.t, enc: diaryBlob(n) } : { id: n.id, t: n.t, title: n.title, text: n.text });
  return JSON.stringify(Object.assign({}, S, { diary: { hash: S.diary.hash, salt: S.diary.salt, secs: secs } }));
}
function save() { try { localStorage.setItem(KEY, ser()); } catch (e) {} }
let svT = 0;
function saveSoon() { clearTimeout(svT); svT = setTimeout(save, 350); }

/* ================= روز و شب، تم ================= */
function sunTimes(d) {
  const doy = Math.floor((d - new Date(d.getFullYear(), 0, 0)) / 864e5);
  const L = 12 + 2.3 * Math.sin(2 * Math.PI * (doy - 80) / 365);
  const noon = 12.3;
  return { sr: (noon - L / 2) * 60, ss: (noon + L / 2) * 60 };
}
function isDay() {
  const d = new Date(), tt = d.getHours() * 60 + d.getMinutes(), s = sunTimes(d);
  return tt >= s.sr && tt <= s.ss;
}
function applyTheme() {
  let light = S.set.theme === 'light';
  if (S.set.theme === 'auto') light = isDay();
  document.body.classList.toggle('light', light);
  const a = ACCENTS[S.set.accent] || ACCENTS[0];
  const st = document.documentElement.style;
  st.setProperty('--acc', a[0]);
  st.setProperty('--acc2', a[1]);
  const m = document.querySelector('meta[name="theme-color"]');
  if (m) m.setAttribute('content', light ? '#e2e8f0' : '#0e1322');
}
function applyFont() {
  const st = document.documentElement.style;
  st.setProperty('--fs', String(FS_STEPS[S.set.fs] || 1));
  if (S.set.ff === 'system') st.setProperty('--ff', 'system-ui, -apple-system, Tahoma, "Segoe UI", Roboto, sans-serif');
  else st.removeProperty('--ff');
}
function titleOf(id) {
  if (id === 'home') return '☁️ ' + t('appTitle');
  if (id === 'settings') return '⚙️ ' + t('settings');
  if (id === 'diary') return '📔 ' + t('diary');
  if (id === 'mods') return '🧩 ' + t('mods');
  const s = SECTIONS.find(x => x.id === id);
  return s ? s.icon + ' ' + t('sec_' + id) : t('appTitle');
}
function applyLang() {
  LANG = S.set.lang === 'en' ? 'en' : 'fa';
  const h = document.documentElement;
  h.lang = LANG;
  h.dir = LANG === 'en' ? 'ltr' : 'rtl';
  document.title = t('appTitle');
  Object.keys(mkCache).forEach(k => { delete mkCache[k]; });
  items.forEach((b, i) => { b.querySelector('.lb').textContent = t('sec_' + SECTIONS[i].id); });
  $('hub').setAttribute('aria-label', t('menu'));
  $('homeBtn').setAttribute('aria-label', t('home'));
  $('setBtn').setAttribute('aria-label', t('settings'));
  $('srchBtn').setAttribute('aria-label', t('searchB'));
  $('title').textContent = titleOf(current);
}

/* ================= پیام، صدا، لرزش ================= */
let toastT;
function toast(m) {
  const el = $('toast');
  el.textContent = m;
  el.classList.add('show');
  clearTimeout(toastT);
  toastT = setTimeout(() => el.classList.remove('show'), 2800);
}
let AC = null;
function audio() {
  try {
    if (!AC) { const C = window.AudioContext || window.webkitAudioContext; if (C) AC = new C(); }
    if (AC && AC.state === 'suspended') AC.resume();
  } catch (e) {}
  return AC;
}
document.addEventListener('pointerdown', () => { audio(); }, { once: true });
function beep() {
  if (!S.set.sound) return;
  const ac = audio();
  if (!ac) return;
  try {
    const now = ac.currentTime;
    [0, 0.28, 0.56].forEach(o => {
      const os = ac.createOscillator(), g = ac.createGain();
      os.frequency.value = 880;
      os.connect(g); g.connect(ac.destination);
      g.gain.setValueAtTime(0.0001, now + o);
      g.gain.exponentialRampToValueAtTime(0.25, now + o + 0.03);
      g.gain.exponentialRampToValueAtTime(0.0001, now + o + 0.22);
      os.start(now + o); os.stop(now + o + 0.25);
    });
  } catch (e) {}
}
function buzz(p) {
  if (!S.set.vib) return;
  try { if (navigator.vibrate) navigator.vibrate(p || [250, 120, 250]); } catch (e) {}
}
function alarm() { buzz(); beep(); }

/* ================= سابقهٔ آمار ================= */
function logAdd(k, d, n, x) {
  const e = { id: uid(), k: k, d: d, n: String(n == null ? '' : n) };
  if (x) for (const p in x) e[p] = x[p];
  S.log.push(e);
  return e;
}
function logDelRef(k, ref, d) {
  S.log = S.log.filter(e => !(e.k === k && e.ref === ref && (d === undefined || e.d === d)));
}

/* ================= منطق کارها، عادت‌ها، خرید، هدف ================= */
function subPct(tk) {
  const s = tk.subs || [];
  if (!s.length) return tk.done ? 100 : 0;
  return Math.round(s.filter(x => x.d).length / s.length * 100);
}
function taskLocked(tk) { return !!(tk.rep && !tk.done && tk.due && dayKey(new Date(tk.due)) > dayKey()); }
function setTaskDone(tk) {
  if (taskLocked(tk)) { toast(t('taskLocked')); return; }
  tk.done = true; tk.notified = true; tk.doneAt = Date.now();
  tk.subs.forEach(s => { s.d = true; });
  logDelRef('t', tk.id);
  logAdd('t', dayKey(), tk.title, { ref: tk.id });
  if (tk.rep && !tk.cloned) {
    tk.cloned = true;
    const step = (tk.rep === 'w' ? 7 : 1) * 86400000;
    let nx = (tk.due || Date.now()) + step;
    while (nx <= Date.now()) nx += step;
    S.tasks.push({
      id: uid(), title: tk.title, due: nx, done: false, notified: false, created: Date.now(),
      pri: tk.pri, rep: tk.rep, subs: tk.subs.map(s => ({ id: uid(), t: s.t, d: false })), cloud: !!tk.cloud
    });
    toast(t('nextMade'));
  } else toast(t('cheer'));
}
function undoTask(tk) {
  tk.done = false; delete tk.doneAt;
  logDelRef('t', tk.id);
}
function toggleTask(tk) {
  if (tk.done) { undoTask(tk); tk.subs.forEach(s => { s.d = false; }); }
  else setTaskDone(tk);
}
function taskSync(tk) {
  const s = tk.subs;
  if (!s.length) return;
  const all = s.every(x => x.d);
  if (all && !tk.done) setTaskDone(tk);
  else if (!all && tk.done) undoTask(tk);
}
function habOn(h, d) {            // آیا این عادت در این روز هفته نوبت دارد؟ (بدون روز انتخاب‌شده یعنی هر روز)
  return !h.wd || !h.wd.length || h.wd.indexOf((d || new Date()).getDay()) > -1;
}
function habStreak(h) {
  const set = new Set(h.days);
  const d = new Date();
  if (!set.has(dayKey(d))) d.setDate(d.getDate() - 1);
  let c = 0, guard = 0;
  while (guard++ < 4000) {
    if (set.has(dayKey(d))) c++;
    else if (habOn(h, d)) break;      // روزی که نوبت بود و انجام نشد، زنجیره را می‌شکند
    d.setDate(d.getDate() - 1);
  }
  return c;
}
function hSubDone(h, k) {
  const ids = (h.sd && h.sd[k]) || [];
  return h.subs.filter(s => ids.indexOf(s.id) > -1).length;
}
function hPct(h, k) {
  const n = h.subs.length;
  if (!n) return h.days.indexOf(k) > -1 ? 100 : 0;
  return Math.round(hSubDone(h, k) / n * 100);
}
function habSetDay(h, k, on) {
  const p = h.days.indexOf(k);
  if (on && p < 0) { h.days.push(k); logAdd('h', k, h.name, { ref: h.id }); }
  else if (!on && p > -1) { h.days.splice(p, 1); logDelRef('h', h.id, k); }
}
function hSync(h, k) {
  const n = h.subs.length;
  if (!n) return;
  habSetDay(h, k, hSubDone(h, k) === n);
}
function toggleHabitToday(h) {
  const k = dayKey();
  if (h.subs.length) {
    const full = hSubDone(h, k) === h.subs.length;
    h.sd[k] = full ? [] : h.subs.map(s => s.id);
    hSync(h, k);
  } else habSetDay(h, k, h.days.indexOf(k) < 0);
  if (h.days.length > 800) h.days = h.days.slice(-800);
}
function pctGoal(g) { return Math.max(0, Math.min(100, g.target ? g.cur / g.target * 100 : 0)); }
function goalStep(g, dir) {
  const was = pctGoal(g);
  g.cur = Math.max(0, Math.round((g.cur + dir * g.step) * 100) / 100);
  if (g.cur > g.target) g.cur = g.target;
  save();
  if (was < 100 && pctGoal(g) >= 100) { toast(t('goalReached')); alarm(); }
}
function checkFunded(x) {
  if (x.price > 0 && x.saved >= x.price) {
    if (!x.fn) { x.fn = true; toast(t('fundedToast', x.text)); alarm(); }
  } else x.fn = false;
}
function pomoToday() { const k = dayKey(); return S.log.filter(e => e.k === 'p' && e.d === k).length; }

/* ================= آسمان، ابرها و پرنده (صفحه اصلی) ================= */
let cloudN = 0;
function cloudItems() {
  const now = Date.now(), l = [];
  S.qtimers.forEach(q => {
    l.push({ k: 'qt', id: q.id, ic: '⏱️', tx: q.label || tcName(q.total), sub: fmtClock(Math.ceil((q.end - now) / 1000)), due: 0, qt: q.id, o: q.end });
  });
  if (T.run) {
    l.push({ k: 'mt', id: 'main', ic: '⏱️', tx: t('sec_timer') + ' · ' + durText(T.total), sub: mmss(tmLeft()), due: 0, mt: 1, o: T.end });
  }
  S.tasks.forEach(tk => {
    if ((tk.cloud || (tk.due && tk.due - now < 12 * 3600000)) && !tk.done) {
      l.push({
        k: 'tasks', id: tk.id, ic: '✅', tx: tk.title,
        sub: tk.due ? remText(tk.due - now) : (tk.subs.length ? nf(subPct(tk)) + '%' : ''),
        due: tk.due || 0, o: tk.due ? tk.due - (tk.pri === 2 ? 6 : tk.pri === 0 ? 0 : 2) * 3600000 : 9e15 - 10 - (tk.pri == null ? 1 : tk.pri), late: !!(tk.due && tk.due < now), it: tk
      });
    }
  });
  const today = dayKey();
  S.habits.forEach(h => {
    if (h.cloud && habOn(h) && hPct(h, today) < 100) {
      l.push({ k: 'habits', id: h.id, ic: '🔥', tx: h.name, sub: h.subs.length ? nf(hPct(h, today)) + '%' : '🔥 ' + nf(habStreak(h)), due: 0, o: 9e15 - 1, it: h });
    }
  });
  S.notes.forEach(n => { if (n.cloud) l.push({ k: 'notes', id: n.id, ic: '📝', tx: noteTitle(n), sub: '', due: 0, o: 9e15 - 2, it: n }); });
  S.shop.forEach(x => {
    if (x.cloud && !x.done) {
      l.push({ k: 'shop', id: x.id, ic: '🛒', tx: x.text, sub: x.price ? nf(Math.round(Math.min(100, x.saved / x.price * 100))) + '%' : '', due: 0, o: 9e15 - 3, it: x });
    }
  });
  S.goals.forEach(g => {
    if (g.cloud && pctGoal(g) < 100) l.push({ k: 'goals', id: g.id, ic: g.icon || '🎯', tx: g.title, sub: nf(Math.round(pctGoal(g))) + '%', due: 0, o: 9e15 - 4, it: g });
  });
  l.forEach(c => {                       // ابرهای سنجاق‌شده همیشه اول می‌آیند
    if (c.k === 'mt') return;
    const it = c.it || findItem(c.k, c.id);
    if (it && it.hp) { c.hp = true; c.o -= 1e16; }
  });
  l.sort((a, b) => a.o - b.o);
  return l;
}
const mix = (a, b, k) => a.map((v, i) => Math.round(v + (b[i] - v) * k));
const rgb = a => 'rgb(' + a[0] + ',' + a[1] + ',' + a[2] + ')';
const sm = x => x <= 0 ? 0 : x >= 1 ? 1 : x * x * (3 - 2 * x);
function gray(a, k) { const l = Math.round(a[0] * .3 + a[1] * .59 + a[2] * .11); return mix(a, [l, l, l], k); }

/* باران خودکار: وقتی ابرها زیاد و آسمان سیاه می‌شود (اگر مود باران یا برف روشن نباشد) */
let arStop = null, arViews = [];
const arNimbo = { current: () => current, onView: fn => { arViews.push(fn); } };
function setAutoRain(on) {
  if (on && !arStop) { arViews = []; arStop = FALL_JS(arNimbo, 'rain'); }
  else if (!on && arStop) { arStop(); arStop = null; arViews = []; }
}
function paintSky() {
  const sc = $('scene');
  if (!sc) return;
  const d = new Date(), tt = d.getHours() * 60 + d.getMinutes() + d.getSeconds() / 60;
  const st = sunTimes(d), sr = st.sr, ss = st.ss;
  const c = Math.min(0.9, cloudN * 0.08);
  const day = tt >= sr && tt <= ss;
  let e = 0, tw = 0, k = 0;
  if (day) { e = Math.sin(Math.PI * (tt - sr) / (ss - sr)); k = sm(e / 0.3); }
  else {
    const dist = tt < sr ? Math.min(sr - tt, tt + 1440 - ss) : Math.min(tt - ss, sr + 1440 - tt);
    tw = Math.max(0, 1 - dist / 70);
  }
  const NT = [8, 14, 40], NB = [26, 40, 86], WT = [84, 86, 160], WB = [246, 160, 106], DT = [47, 125, 225], DB = [143, 208, 247];
  let top, bot;
  if (day) { top = mix(WT, DT, k); bot = mix(WB, DB, k); }
  else { top = mix(NT, WT, tw); bot = mix(NB, WB, tw); }
  const dl = day ? (0.35 + 0.65 * k) : 0.35 * tw;
  top = gray(top, c * 0.85); bot = gray(bot, c * 0.8);
  const dk = 1 - 0.22 * c;
  top = top.map(v => Math.round(v * dk)); bot = bot.map(v => Math.round(v * dk));
  let cA = mix([190, 200, 228], [255, 255, 255], dl), cB = mix([96, 110, 156], [205, 219, 238], dl);
  let gA = mix([116, 124, 142], [212, 218, 228], dl); let gB = mix([70, 80, 104], [148, 158, 176], dl);
  cA = mix(cA, gA, c * .75); cB = mix(cB, gB, c * .75);
  const sk = Math.max(0, (c - 0.28) / 0.62);       // هرچه ابرها بیشتر شوند، تیره‌تر می‌شوند
  if (sk > 0) { cA = mix(cA, [46, 52, 68], sk * 0.92); cB = mix(cB, [18, 21, 32], sk * 0.92); }
  if (sk > 0) { gA = mix(gA, [40, 46, 60], sk * 0.95); gB = mix(gB, [16, 19, 30], sk * 0.95); }
  sc.classList.toggle('storm', sk > 0.4);
  setAutoRain(sk > 0.4 && MODS_ON.indexOf('rain') < 0 && MODS_ON.indexOf('snow') < 0);
  sc.style.setProperty('--st', rgb(top));
  sc.style.setProperty('--sb', rgb(bot));
  const rs = document.documentElement.style;
  rs.setProperty('--cA', rgb(cA));
  rs.setProperty('--cB', rgb(cB));
  rs.setProperty('--gA', rgb(gA));
  rs.setProperty('--gB', rgb(gB));

  const vis = 1 - c * 0.97;
  const sun = $('sun'), moon = $('moon'), stars = $('stars'), cov = $('cover');
  if (sun) {
    if (day) {
      const k2 = sm(e / 0.45);
      sun.style.display = 'block';
      sun.style.transform = 'translateY(' + (HEAD - e * (HEAD - 24)) + 'px)';
      sun.style.opacity = vis;
      sun.style.setProperty('--s1', rgb(mix([255, 120, 50], [255, 232, 120], k2)));
      sun.style.setProperty('--s2', rgb(mix([255, 90, 30], [255, 190, 40], k2)));
    } else sun.style.display = 'none';
  }
  if (moon) {
    if (!day) {
      const span = 1440 - (ss - sr);
      const pm = Math.min(1, Math.max(0, (tt > ss ? tt - ss : tt + 1440 - ss) / span));
      const em = Math.sin(Math.PI * pm);
      moon.style.display = 'block';
      moon.style.transform = 'translateY(' + (HEAD - em * (HEAD - 24)) + 'px) rotate(-20deg)';
      moon.style.opacity = vis;
    } else moon.style.display = 'none';
  }
  if (stars) stars.style.opacity = day ? 0 : Math.max(0, 1 - tw) * (1 - c * 0.9);
  if (cov) cov.style.opacity = c;
}

function findSpot(fw, fh, key, x0, y0, x1, y1, placed) {
  const aw = x1 - x0 - fw, ah = y1 - y0 - fh;
  if (aw < 0 || ah < 0) return null;
  const free = (x, y) => {
    for (let i = 0; i < placed.length; i++) {
      const p = placed[i];
      if (x < p.x + p.w && x + fw > p.x && y < p.y + p.h && y + fh > p.y) return false;
    }
    return true;
  };
  for (let i = 0; i < 28; i++) {
    const x = x0 + hashFrac(key, 'x' + i) * aw, y = y0 + hashFrac(key, 'y' + i) * ah;
    if (free(x, y)) return { x: x, y: y };
  }
  for (let y = 0; y <= ah; y += 16) {
    for (let x = 0; x <= aw; x += 16) {
      if (free(x0 + x, y0 + y)) return { x: x0 + x, y: y0 + y };
    }
  }
  return null;
}
let lastVis = null;
function layoutClouds() {
  const sc = $('scene'), box = $('clouds');
  if (!sc || !box) return;
  const W = sc.clientWidth, H = sc.clientHeight;
  if (!W || !H) return;
  const closed = document.body.classList.contains('wheel-closed');
  const reserve = closed ? 72 : (wheel.offsetHeight / 2 + HUBOFF + HUBR + 14);
  const mx = 14, my = 16;
  const x0 = 8, x1 = W - 8, y0 = 146, y1 = H - reserve;
  const maxW = Math.min(176, Math.max(110, W * 0.5));
  const placed = [], vis = new Set();
  const cws = [].slice.call(box.querySelectorAll('.cw'));
  cws.forEach(el => { el.style.display = ''; });
  const sizes = cws.map(el => [el.offsetWidth, el.offsetHeight]);      // یک بار خواندن، بدون reflow پیاپی
  let fails = 0;                       // پس از چند شکست پیاپی، بقیهٔ ابرها (کم‌اهمیت‌تر) بدون جست‌وجو پنهان می‌شوند
  const out = cws.map((el, i) => {
    if (fails >= 3) return null;
    const fw = sizes[i][0] + mx * 2, fh = sizes[i][1] + my * 2, key = el.getAttribute('data-k') || '';
    const spot = findSpot(fw, fh, key, x0, y0, x1, y1, placed);
    if (spot) { placed.push({ x: spot.x, y: spot.y, w: fw, h: fh }); vis.add(key); fails = 0; } else fails++;
    return spot;
  });
  cws.forEach((el, i) => {
    const spot = out[i];
    if (!spot) { el.style.display = 'none'; return; }
    el.style.left = (spot.x + mx) + 'px';
    el.style.top = (spot.y + my) + 'px';
    el.style.opacity = '1';
  });
  if (lastVis && !view.classList.contains('enter')) {
    cws.forEach(el => {
      const k = el.getAttribute('data-k') || '';
      if (vis.has(k) && !lastVis.has(k)) { el.classList.add('rise'); setTimeout(() => el.classList.remove('rise'), 3600); }
    });
  }
  lastVis = vis;
  const more = $('more');
  if (more) {
    const extra = Number(box.getAttribute('data-total') || 0) - placed.length;
    if (extra > 0) { more.style.display = ''; more.textContent = t('moreClouds', nf(extra)); }
    else more.style.display = 'none';
  }
}
function tickClouds() {
  const now = Date.now();
  view.querySelectorAll('.cloud[data-due]').forEach(el => {
    const due = Number(el.getAttribute('data-due'));
    const s = el.querySelector('.c-s');
    if (s) s.textContent = remText(due - now);
    el.classList.toggle('late', due < now);
  });
}
function habitsInner() {
  const today = dayKey(), C = 94.25;
  const rings = S.habits.filter(h => habOn(h)).slice(0, 6).map(h => {
    const p = hPct(h, today);
    const ch = Array.from(h.name || '?')[0] || '?';
    return '<button class="rh' + (p >= 100 ? ' full' : '') + '" type="button" data-act="h-toggle" data-id="' + esc(h.id) + '" data-lp="habits:' + esc(h.id) + '" aria-label="' + esc(h.name) + '">' +
      '<svg viewBox="0 0 36 36"><circle class="rb" cx="18" cy="18" r="15"/><circle class="rp" cx="18" cy="18" r="15" stroke-dasharray="' + C + '" stroke-dashoffset="' + (C * (1 - p / 100)).toFixed(2) + '"/></svg>' +
      '<span>' + (p >= 100 ? '✓' : esc(ch)) + '</span></button>';
  }).join('');
  const nOn = S.habits.filter(h => habOn(h)).length;
  const more = nOn > 6 ? '<button class="rm" type="button" data-go="3">+' + nf(nOn - 6) + '</button>' : '';
  return rings + more;
}
const BIRD_SVG = '<svg viewBox="0 0 72 52" aria-hidden="true">' +
  '<defs><linearGradient id="crb" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3a4668"/><stop offset=".45" stop-color="#1a2136"/><stop offset="1" stop-color="#090c16"/></linearGradient>' +
  '<linearGradient id="crw" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#4d3f7a"/><stop offset=".5" stop-color="#232c52"/><stop offset="1" stop-color="#0c1020"/></linearGradient></defs>' +
  /* دم: چند پَر پشت‌سرهم */
  '<path d="M48 31 L71 40 L66 42 L70 45 L64 45 L67 48 L46 41 Z" fill="#0b0f1c"/>' +
  '<path d="M48 33 L68 41" stroke="#3b4770" stroke-width=".8" opacity=".6"/><path d="M47 37 L64 45" stroke="#3b4770" stroke-width=".7" opacity=".5"/>' +
  /* پاها */
  '<path d="M33 41 L32 48 M29.5 49.5 L32 48 L35 50 M32 48 L33 50.5 M42 41 L42 48 M39 49.5 L42 48 L45 50 M42 48 L43 50.5" stroke="#1a1410" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" fill="none"/>' +
  /* بدن */
  '<path d="M15 21 C18 12 32 10 44 15 C55 19 61 28 58 36 C52 44 36 46 27 42 C19 38 13 29 15 21 Z" fill="url(#crb)"/>' +
  '<path d="M17 30 C22 38 34 42 46 40" stroke="#4a5686" stroke-width="1" fill="none" opacity=".4" stroke-linecap="round"/>' +
  /* سر و گردن */
  '<path d="M10 17 C11 9 21 6 27 11 C31 15 30 22 25 26 C20 29 12 26 10 17 Z" fill="url(#crb)"/>' +
  '<path d="M14 25 L12 29 L16 27 L15 31 L19 28" stroke="#0b0f1c" stroke-width="1.3" fill="none" stroke-linejoin="round" opacity=".8"/>' +
  /* نوک: قوی و کمی خمیده */
  '<path d="M11 13 C6 12.5 2 15 0.5 19.5 C4 19 8 19.3 11.5 20.4 Z" fill="#14161c"/>' +
  '<path d="M11.5 20.4 C8 19.3 4 19 .5 19.5 C3 22 7 23.5 11.5 22.5 Z" fill="#0a0b10"/>' +
  '<path d="M10 14 C6.5 14 3.5 15.5 2 18" stroke="#5a6070" stroke-width=".9" fill="none" opacity=".75" stroke-linecap="round"/>' +
  /* چشم */
  '<circle cx="17" cy="14.5" r="3" fill="#e9eef8"/><circle cx="16.3" cy="14.8" r="1.8" fill="#07080c"/><circle cx="15.7" cy="14.2" r=".6" fill="#fff"/>' +
  '<path d="M13.5 11.8 C15.5 10.6 18 10.8 19.8 12.2" stroke="#0b0f1c" stroke-width="1.3" fill="none" stroke-linecap="round"/>' +
  /* درخشش پشت سر */
  '<path d="M20 8.5 C26 7.5 31 10.5 33 14" stroke="#7d8dd0" stroke-width="1.1" fill="none" opacity=".35" stroke-linecap="round"/>' +
  /* بال با پَرهای لایه‌ای */
  '<g class="wing"><path d="M36 19 C46 12 61 17 69 33 L63 31 L64 36 L58 32 L58 38 L52 32.5 L50 38 L45 31 C40 30 36 26 36 19 Z" fill="url(#crw)"/>' +
  '<path d="M41 22 C49 18 58 22 64 31" stroke="#8a97d6" stroke-width=".9" fill="none" opacity=".35" stroke-linecap="round"/>' +
  '<path d="M44 26 C50 24 56 27 60 33 M47 29 C51 28 54 30 56 34" stroke="#0a0d1a" stroke-width=".9" fill="none" opacity=".7" stroke-linecap="round"/></g>' +
  '</svg>';

function cloudSvg(shape, flip) {
  const u = '<use href="#' + shape + '" xlink:href="#' + shape + '"';
  return '<svg class="puff' + (flip ? ' flip' : '') + '" viewBox="0 0 240 120" preserveAspectRatio="none" aria-hidden="true">' +
    '<g filter="url(#cl-soft)">' +
    u + ' style="fill:var(--cB)" transform="translate(0 9)"/>' +
    u + ' style="fill:url(#cl-g)"/>' +
    u + ' class="tint"/>' +
    '</g></svg>';
}
function coverSvg(shape) {
  const u = '<use href="#' + shape + '" xlink:href="#' + shape + '"';
  return '<svg viewBox="0 0 240 120" preserveAspectRatio="none" aria-hidden="true"><g filter="url(#cl-soft)">' +
    u + ' style="fill:var(--gB)" transform="translate(0 9)"/>' +
    u + ' style="fill:url(#cl-gg)"/>' +
    '</g></svg>';
}
function vHome() {
  const cl = cloudItems();
  cloudN = cl.length;
  const d = new Date();
  let ds;
  try { ds = d.toLocaleDateString(NL(), { weekday: 'long', day: 'numeric', month: 'long' }); }
  catch (e) { ds = dayKey(d); }
  const cells = cl.slice(0, 14).map((c, i) => {
    const hs = hash(c.k + c.id);
    const openAttr = c.k === 'mt' ? 'data-go="4"' : 'data-open="' + c.k + ':' + esc(c.id) + '"';
    const okAct = c.k === 'tasks' ? 't-toggle' : (c.k === 'habits' ? 'h-toggle' : '');
    return '<div class="cw" data-k="' + esc(c.k + c.id) + '" style="animation-duration:' + (12 + hs % 9) + 's;animation-delay:-' + (hs % 11) + 's">' +
      '<div class="cloud' + (c.late ? ' late' : '') + (c.qt || c.mt ? ' tm' : '') + '" ' + openAttr + (c.due ? ' data-due="' + c.due + '"' : '') +
      (c.qt ? ' data-qt="' + esc(c.qt) + '"' : '') + (c.mt ? ' data-mt="1"' : '') + ' style="animation-delay:-' + (i * 1.3) + 's">' +
      cloudSvg(SHAPES[hs % 3], (hs >> 2) % 2 === 1) +
      '<div class="c-t">' + c.ic + ' ' + esc(c.tx) + '</div>' +
      (c.sub ? '<div class="c-s">' + esc(c.sub) + '</div>' : '') +
      (okAct ? '<button class="c-ok" type="button" data-act="' + okAct + '" data-id="' + esc(c.id) + '" aria-label="OK">✓</button>' : '') +
      '</div></div>';
  }).join('');
  return '<div class="scene" id="scene">' +
    '<div class="stars" id="stars"></div>' +
    '<div class="orb"><div class="sun" id="sun"></div><div class="moon" id="moon"></div></div>' +
    '<div class="cover" id="cover">' + coverSvg('cl-a') + coverSvg('cl-b') + coverSvg('cl-c') + '</div>' +
    '<div class="hud"><div class="clock" id="clock">' + hm(Date.now()) + '</div><div class="date">' + esc(ds) + '</div></div>' +
    '<div class="sbar">' + (function () { const n = todayInfo().pending; return '<button class="sumb' + (n ? '' : ' zero') + '" type="button" data-act="summary" aria-label="' + esc(t('sumTitle')) + '">📋 <b>' + (n ? nf(n) : '✓') + '</b></button>'; })() +
    (cl.length ? '<button class="sumb allb" type="button" data-act="more-clouds" aria-label="' + esc(t('allClouds')) + '">☁️ <b>' + nf(cl.length) + '</b></button>' : '') + '</div>' +
    '<div class="hb' + (S.habits.length ? '' : ' hide') + '" id="hbw">' + habitsInner() + '</div>' +
    '<div class="clouds" id="clouds" data-total="' + cl.length + '">' + cells + '</div>' +
    '<button class="pillmore" id="more" type="button" data-act="more-clouds" style="display:none"></button>' +
    (cl.length ? '' : '<div class="skyhint">' + t('skyEmpty') + '<small>' + t('skyEmptySub') + '</small></div>') +
    '<button class="bird" id="bird" type="button" data-act="quick" aria-label="' + esc(t('birdLabel')) + '">' + BIRD_SVG + '<i class="bp">+</i></button>' +
    '</div>';
}
function flyBird() {
  const b = $('bird');
  if (!b) return;
  b.classList.remove('back');
  b.classList.add('go');
  setTimeout(() => {
    const bb = $('bird');
    if (bb) {
      bb.classList.remove('go');
      bb.classList.add('back');
      setTimeout(() => { const b3 = $('bird'); if (b3) b3.classList.remove('back'); }, 900);
    }
  }, 1300);
}

/* ================= کارها ================= */
let tFilter = 'open', tPlanOff = 0;
function taskSort(a, b) {
  const ad = a.due || Infinity, bd = b.due || Infinity;
  if (ad !== bd) return ad < bd ? -1 : 1;
  const p = (b.pri == null ? 1 : b.pri) - (a.pri == null ? 1 : a.pri);
  if (p) return p;
  return (a.created || 0) - (b.created || 0);
}
function isTodayTask(tk, now, today) {
  return !tk.done && tk.due && (tk.due < now || dayKey(new Date(tk.due)) === today);
}
function subsHtml(subs, attrs, doneFn) {
  return '<div class="subs">' + subs.map(s => {
    const on = doneFn(s);
    return '<button class="sb' + (on ? ' on' : '') + '" type="button" ' + attrs + ' data-sid="' + esc(s.id) + '"><i>' + (on ? '✔' : '') + '</i>' + esc(s.t) + '</button>';
  }).join('') + '</div>';
}
function vTasks() {
  const now = Date.now(), today = dayKey();
  const openN = S.tasks.filter(x => !x.done).length;
  const todayN = S.tasks.filter(x => isTodayTask(x, now, today)).length;
  const doneN = S.tasks.filter(x => x.done).length;
  if (tFilter === 'plan') {
    const tabs0 = ['open', 'today', 'done', 'plan'].map(id => '<button class="tab' + (tFilter === id ? ' on' : '') + '" type="button" data-act="tfilter" data-id="' + id + '">' + (id === 'plan' ? t('tabPlan') : t(id === 'open' ? 'tabOpen' : id === 'today' ? 'today' : 'tabDone') + ' (' + nf(id === 'open' ? openN : id === 'today' ? todayN : doneN) + ')') + '</button>').join('');
    return '<button class="btn addb" type="button" data-act="add" data-id="tasks">' + t('newTask') + '</button><div class="tabs">' + tabs0 + '</div>' + planHtml();
  }
  const list = S.tasks.filter(x =>
    tFilter === 'done' ? x.done : tFilter === 'today' ? isTodayTask(x, now, today) : !x.done);
  if (tFilter === 'done') list.sort((a, b) => (b.doneAt || 0) - (a.doneAt || 0));
  else list.sort(taskSort);
  const tab = (id, label, n) =>
    '<button class="tab' + (tFilter === id ? ' on' : '') + '" type="button" data-act="tfilter" data-id="' + id + '">' + label + ' (' + nf(n) + ')</button>';
  let h = '<button class="btn addb" type="button" data-act="add" data-id="tasks">' + t('newTask') + '</button>' +
    '<div class="tabs">' + tab('open', t('tabOpen'), openN) + tab('today', t('today'), todayN) + tab('done', t('tabDone'), doneN) + '<button class="tab" type="button" data-act="tfilter" data-id="plan">' + t('tabPlan') + '</button></div>';
  if (!list.length) return h + empty(t(tFilter === 'done' ? 'noDone' : 'noTasks'));
  h += list.map(x => {
    const late = !x.done && x.due && x.due < now, lk = taskLocked(x);
    const pri = x.pri == null ? 1 : x.pri;
    const sub = (x.due ? fmtDue(x.due) + (x.done ? '' : ' · ' + remText(x.due - now)) : t('noSchedule')) + (x.rep ? ' · 🔁' : '') + (lk ? ' · 🔒 ' + t('lockedTill') : '') + (x.cloud ? ' · ☁️' : '');
    const hasSubs = x.subs.length > 0;
    return '<div class="item p' + pri + (x.done ? ' done' : '') + (late ? ' late' : '') + (lk ? ' locked' : '') + '" data-lp="tasks:' + esc(x.id) + '">' +
      '<button class="chk" type="button" data-act="t-toggle" data-id="' + esc(x.id) + '">' + (x.done ? '✔' : lk ? '🔒' : '') + '</button>' +
      '<div class="grow"><div class="ttl">' + esc(x.title) + '</div><div class="sub">' + sub + '</div>' +
      (hasSubs ? '<div class="bar"><i style="width:' + subPct(x) + '%"></i></div>' + subsHtml(x.subs, 'data-act="t-sub" data-id="' + esc(x.id) + '"', s => s.d) : '') +
      '</div><button class="mini" type="button" data-open="tasks:' + esc(x.id) + '" aria-label="⋮">⋮</button></div>';
  }).join('');
  if (tFilter === 'done' && doneN) h += '<button class="btn ghost" type="button" data-act="t-clear">' + t('clearDone') + '</button>';
  return h;
}


/* ===== نمای برنامهٔ روز (تایم‌لاین) ===== */
const TL_HR = 66, TL_H = 54;
function digs(x) { return LANG === 'en' ? String(x) : String(x).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]); }
function planHtml() {
  const day = new Date(); day.setDate(day.getDate() + tPlanOff);
  const key = dayKey(day), isToday = tPlanOff === 0, nowD = new Date();
  const list = S.tasks.filter(x => x.due && dayKey(new Date(x.due)) === key).sort((a, b) => a.due - b.due);
  const none = S.tasks.filter(x => !x.due && !x.done);
  const doneN = list.filter(x => x.done).length;
  let wdn = ''; try { wdn = day.toLocaleDateString(NL(), { weekday: 'long' }); } catch (e) {}
  let h = '<div class="tl-head"><button class="tl-arrow" type="button" data-act="tplan" data-id="-1" aria-label="prev">‹</button>' +
    '<button class="tl-title" type="button" data-act="tplan" data-id="0"><b>' + (isToday ? t('today') : esc(wdn)) + '</b><span>' + (isToday ? esc(wdn) + ' · ' : '') + dayLabel(key) + (list.length ? ' · ' + nf(doneN) + '/' + nf(list.length) : '') + '</span></button>' +
    '<button class="tl-arrow" type="button" data-act="tplan" data-id="1" aria-label="next">›</button></div>';
  if (none.length) h += '<div class="tl-none"><span>' + t('tlNoTime') + ' — ' + t('tlDragHint') + '</span>' + none.slice(0, 12).map(x => '<button type="button" class="tl-chip" data-nt="' + esc(x.id) + '" data-open="tasks:' + esc(x.id) + '">⠿ ' + esc(x.title) + '</button>').join('') + '</div>';
  let g = '';
  for (let hr = 0; hr < 24; hr++) {
    const cur = isToday && hr === nowD.getHours();
    g += '<div class="tl-row' + (hr < 6 || hr >= 22 ? ' nt' : '') + (cur ? ' cur' : '') + '" style="top:' + (hr * TL_HR) + 'px;height:' + TL_HR + 'px"><span>' + digs(pad(hr) + ':00') + '</span></div>';
  }
  const cols = [], pos = [];
  list.forEach(x => {
    const d = new Date(x.due), m = d.getHours() * 60 + d.getMinutes();
    let c = 0; while (cols[c] > m) c++;
    cols[c] = m + 50; pos.push({ x: x, m: m, c: c });
  });
  const nc = Math.max(1, cols.length);
  pos.forEach(p => {
    const x = p.x, pri = x.pri == null ? 1 : x.pri, top = Math.min(p.m / 60 * TL_HR, 24 * TL_HR - TL_H) + 2;
    g += '<div class="tlb p' + pri + (x.done ? ' done' : '') + '" data-id="' + esc(x.id) + '" data-open="tasks:' + esc(x.id) + '" style="top:' + top + 'px;height:' + (TL_H - 4) + 'px;left:calc(52px + (100% - 58px) * ' + (p.c / nc) + ');width:calc((100% - 58px) / ' + nc + ' - 5px)">' +
      '<b>' + (x.done ? '✔ ' : '') + esc(x.title) + '</b><i>' + hm(x.due) + (x.subs.length ? ' · ' + nf(subPct(x)) + '%' : '') + '</i><span class="tlh" aria-label="drag"><em></em></span></div>';
  });
  if (isToday) g += '<div class="tl-now" id="tl-now" style="top:' + ((nowD.getHours() * 60 + nowD.getMinutes()) / 60 * TL_HR) + 'px"><span>' + hm(Date.now()) + '</span></div>';
  if (!list.length) h += '<div class="tl-empty">🗓️<br>' + t('tlEmpty') + '</div>';
  return h + '<div class="tl" id="tl" data-day="' + key + '" style="height:' + (24 * TL_HR) + 'px">' + g + '</div>';
}
function tlScroll() { const n = $('tl-now'); if (n) requestAnimationFrame(() => n.scrollIntoView({ block: 'center' })); }
let tlDrag = null;
view.addEventListener('pointerdown', e => {
  const hd = e.target.closest('.tlh');
  if (!hd) return;
  e.preventDefault(); e.stopPropagation();
  const b = hd.closest('.tlb');
  try { hd.setPointerCapture(e.pointerId); } catch (er) {}
  tlDrag = { b: b, y: e.clientY, top: parseFloat(b.style.top), moved: false };
  b.classList.add('drag');
}, true);
view.addEventListener('pointermove', e => {
  if (!tlDrag) return;
  const dy = e.clientY - tlDrag.y; if (Math.abs(dy) > 4) tlDrag.moved = true;
  const q = TL_HR / 4, top = Math.max(0, Math.min(24 * TL_HR - q, Math.round((tlDrag.top + dy) / q) * q));
  tlDrag.b.style.top = top + 'px'; tlDrag.nt = top;
  const m = Math.round(top / TL_HR * 60), it = tlDrag.b.querySelector('i');
  if (it) it.textContent = nf(pad(Math.floor(m / 60))) + ':' + nf(pad(m % 60));
});
['pointerup', 'pointercancel'].forEach(n => view.addEventListener(n, () => {
  const d = tlDrag; if (!d) return; tlDrag = null; d.b.classList.remove('drag');
  if (!d.moved || d.nt == null) return;
  const tk = S.tasks.find(x => x.id === d.b.dataset.id), tl = $('tl');
  if (!tk || !tl) return;
  const p = tl.dataset.day.split('-').map(Number), m = Math.round(d.nt / TL_HR * 60);
  const dt = new Date(p[0], p[1] - 1, p[2], Math.floor(m / 60), m % 60, 0, 0);
  tk.due = dt.getTime(); tk.notified = tk.due <= Date.now();
  if (typeof taskSync === 'function') taskSync(tk);
  buzz(15); save(); refresh(true); toast(t('saved'));
}));
let ntDrag = null;
function ntMin(y) { const r = $('tl').getBoundingClientRect(); return Math.max(0, Math.min(24 * 60 - 15, Math.round((y - r.top) / TL_HR * 4) * 15)); }
view.addEventListener('pointerdown', e => {
  const c = e.target.closest('.tl-chip');
  if (!c) return;
  ntDrag = { id: c.dataset.nt, x: e.clientX, y: e.clientY, g: null, c: c, title: c.textContent.replace('⠿ ', '') };
  try { c.setPointerCapture(e.pointerId); } catch (er) {}
});
view.addEventListener('pointermove', e => {
  const d = ntDrag; if (!d) return;
  if (!d.g) {
    if (Math.hypot(e.clientX - d.x, e.clientY - d.y) < 8) return;
    d.g = document.createElement('div'); d.g.className = 'tl-ghost'; document.body.appendChild(d.g); d.c.classList.add('lift'); buzz(10);
  }
  const tl = $('tl'), r = tl.getBoundingClientRect(), over = e.clientY > r.top && e.clientY < r.bottom;
  const m = over ? ntMin(e.clientY) : null;
  d.g.textContent = d.title + (over ? '  ·  ' + digs(pad(Math.floor(m / 60)) + ':' + pad(m % 60)) : '');
  d.g.style.left = Math.max(8, Math.min(window.innerWidth - 8, e.clientX)) + 'px'; d.g.style.top = (e.clientY - 34) + 'px';
  d.g.classList.toggle('ok', over);
  const vr = view.getBoundingClientRect();
  if (e.clientY < vr.top + 70) view.scrollTop -= 10; else if (e.clientY > vr.bottom - 120) view.scrollTop += 10;
});
['pointerup', 'pointercancel'].forEach(n => view.addEventListener(n, e => {
  const d = ntDrag; if (!d) return; ntDrag = null;
  d.c.classList.remove('lift');
  if (!d.g) return;
  d.g.remove(); lpFired = true; setTimeout(() => { lpFired = false; }, 300);
  const tl = $('tl'); if (!tl || n === 'pointercancel') return;
  const r = tl.getBoundingClientRect(); if (e.clientY <= r.top || e.clientY >= r.bottom) return;
  const tk = S.tasks.find(x => x.id === d.id); if (!tk) return;
  const m = ntMin(e.clientY), p = tl.dataset.day.split('-').map(Number);
  tk.due = new Date(p[0], p[1] - 1, p[2], Math.floor(m / 60), m % 60, 0, 0).getTime(); tk.notified = tk.due <= Date.now();
  if (typeof taskSync === 'function') taskSync(tk);
  buzz(15); save(); refresh(true); toast(t('saved'));
}, true));
view.addEventListener('click', e => { if (e.target.closest('.tlh')) { e.stopPropagation(); e.stopImmediatePropagation(); e.preventDefault(); } }, true);

/* ================= ویرایشگر کامل (یادداشت و دفتر) ================= */
let ed = null; // {kind:'notes'|'diary', id, isNew}
function edItem() {
  if (!ed) return null;
  if (ed.kind === 'notes') return S.notes.find(x => x.id === ed.id) || null;
  return S.diary.secs.find(x => x.id === ed.id) || null;
}
function noteTitle(n) {
  return (n.title || '').trim() || String(n.text).split('\n')[0].trim().slice(0, 60) || t('untitled');
}
function notePrev(n) {
  let s = String(n.text);
  if (!(n.title || '').trim()) { const i = s.indexOf('\n'); s = i > -1 ? s.slice(i + 1) : ''; }
  return s.trim();
}
function autoGrow() {
  const ta = $('ne-text');
  if (!ta) return;
  ta.style.height = 'auto';
  ta.style.height = Math.max(ta.scrollHeight + 4, Math.round(window.innerHeight * 0.42)) + 'px';
}
function editorHtml(n, kind) {
  const isNote = kind === 'notes';
  const back = LANG === 'en' ? '‹' : '›';
  let tools = '';
  if (isNote) {
    tools += '<button class="chip' + (n.pin ? ' on' : '') + '" type="button" data-act="ne-pin">📌 ' + t(n.pin ? 'unpinS' : 'pinS') + '</button>' +
      '<button class="chip' + (n.cloud ? ' on' : '') + '" type="button" data-act="ne-cloud">☁️ ' + t('fCloud') + ': ' + t(n.cloud ? 'yes' : 'no') + '</button>' +
      '<button class="chip" type="button" data-act="ne-copy">' + t('copyText') + '</button>';
  }
  tools += '<button class="chip" type="button" data-act="ne-del">' + t('del') + '</button>';
  return '<div class="ned"><div class="ned-top"><button class="btn ghost sm" type="button" data-act="ne-back">' + back + ' ' + t('back') + '</button>' +
    '<span class="sub">' + t('savedAt', fmtDue(n.t || Date.now())) + '</span></div>' +
    '<input id="ne-title" class="ned-title" type="text" maxlength="80" placeholder="' + esc(t(isNote ? 'noteTitlePh' : 'dSecTitlePh')) + '" value="' + esc(n.title || '') + '" autocomplete="off">' +
    '<textarea id="ne-text" class="ned-text" placeholder="' + esc(t(isNote ? 'noteBodyPh' : 'dBodyPh')) + '">' + esc(n.text) + '</textarea>' +
    '<div class="chips" style="margin-top:12px">' + tools + '</div></div>';
}
function openEditor(kind, id, isNew) {
  if (kind === 'notes' && current !== 'notes') pick(1);
  ed = { kind: kind, id: id, isNew: !!isNew };
  refresh(false);
  view.scrollTop = 0;
  setTimeout(() => { const e = $('ne-title'); if (e && !e.value && ed) e.focus(); }, 380);
}
function closeEd(ask, silent) {
  if (!ed) return;
  const e = ed, n = edItem();
  ed = null;
  clearTimeout(svT);
  if (!n) { if (!silent) refresh(false); return; }
  const blank = !String(n.title || '').trim() && !String(n.text || '').trim();
  if (blank) {
    if (e.kind === 'notes') S.notes = S.notes.filter(x => x !== n);
    else S.diary.secs = S.diary.secs.filter(x => x !== n);
    save();
    if (!silent) refresh(false);
    return;
  }
  save();
  if (!silent) refresh(false);
  if (ask && e.isNew && e.kind === 'notes') askCloud('notes', n.id);
}
function newNote() {
  const n = { id: uid(), title: '', text: '', t: Date.now(), pin: false, cloud: false };
  S.notes.push(n);
  save();
  openEditor('notes', n.id, true);
}

/* ================= یادداشت ================= */
function vNotes() {
  if (ed && ed.kind === 'notes') {
    const n = edItem();
    if (n) return editorHtml(n, 'notes');
    ed = null;
  }
  let h = '<button class="btn addb" type="button" data-act="add" data-id="notes">' + t('newNote') + '</button>';
  if (!S.notes.length) return h + empty(t('noNotes'));
  const l = S.notes.slice().sort((a, b) => (b.pin ? 1 : 0) - (a.pin ? 1 : 0) || (b.t || 0) - (a.t || 0));
  h += '<input id="n-q" class="inp" type="search" placeholder="' + esc(t('searchNotes')) + '" autocomplete="off">';
  h += l.map(n => {
    const prev = notePrev(n);
    return '<div class="item" data-lp="notes:' + esc(n.id) + '" data-s="' + esc(((n.title || '') + ' ' + n.text).toLowerCase()) + '">' +
      '<div class="grow" data-act="n-open" data-id="' + esc(n.id) + '">' +
      '<div class="ttl">' + (n.pin ? '📌 ' : '') + esc(noteTitle(n)) + '</div>' +
      (prev ? '<div class="np clamp2">' + esc(prev) + '</div>' : '') +
      '<div class="sub">' + fmtDue(n.t || Date.now()) + (n.cloud ? ' · ☁️' : '') + '</div></div>' +
      '<button class="mini" type="button" data-open="notes:' + esc(n.id) + '" aria-label="⋮">⋮</button></div>';
  }).join('');
  return h;
}
function filterNotes() {
  const q = $('n-q');
  if (!q) return;
  const s = q.value.trim().toLowerCase();
  view.querySelectorAll('.item[data-s]').forEach(el => {
    el.style.display = (!s || el.getAttribute('data-s').indexOf(s) > -1) ? '' : 'none';
  });
}

/* ================= خرید ================= */
function vShop() {
  let h = '<button class="btn addb" type="button" data-act="add" data-id="shop">' + t('newItem') + '</button>';
  if (!S.shop.length) return h + empty(t('noShop'));
  const l = S.shop.filter(x => !x.done), dn = S.shop.filter(x => x.done).sort((a, b) => (b.doneAt || 0) - (a.doneAt || 0));
  if (!l.length) h += empty(t('shopAllDone'));
  let tot = 0, sv = 0;
  S.shop.forEach(x => { if (!x.done) { tot += x.price; sv += Math.min(x.saved, x.price || x.saved); } });
  if (tot > 0) h += '<div class="muted center" style="margin-top:0">' + t('shopTotal', nf(tot, true), nf(sv, true)) + '</div>';
  h += l.map(x => {
    const fund = x.price > 0 && x.saved >= x.price;
    const pc = x.price > 0 ? Math.min(100, Math.round(x.saved / x.price * 100)) : 0;
    const wl = whenLabel(x);
    return '<div class="item v' + (x.done ? ' done' : '') + '" data-lp="shop:' + esc(x.id) + '">' +
      '<div class="row-top"><button class="chk" type="button" data-act="s-toggle" data-id="' + esc(x.id) + '">' + (x.done ? '✔' : '') + '</button>' +
      '<div class="grow"><div class="ttl">' + esc(x.text) + '</div><div class="sub">' + (x.price ? nf(x.price, true) + ' ' + t('cur') : t('noPrice')) +
      (wl ? ' · ⏳ ' + esc(wl) : '') + (x.cloud ? ' · ☁️' : '') + '</div></div>' +
      '<button class="mini" type="button" data-open="shop:' + esc(x.id) + '" aria-label="⋮">⋮</button></div>' +
      (x.price > 0
        ? '<div class="bar' + (fund ? ' ok' : '') + '"><i style="width:' + pc + '%"></i></div>' +
          '<div class="row-top"><div class="sub grow">' + (fund ? t('funded') + ' ' : '') + t('of', nf(x.saved, true), nf(x.price, true)) + ' (' + nf(pc) + '%)</div>' +
          '<button class="chip on" type="button" data-act="s-sav" data-id="' + esc(x.id) + '">' + t('savingsBtn') + '</button></div>'
        : '') + '</div>';
  }).join('');
  if (dn.length) {
    h += '<div class="sec-h">✅ ' + t('shopDoneH') + ' (' + nf(dn.length) + ')</div>' + dn.map(x =>
      '<div class="item v done sd" data-lp="shop:' + esc(x.id) + '"><div class="row-top"><button class="chk" type="button" data-act="s-toggle" data-id="' + esc(x.id) + '">✔</button>' +
      '<div class="grow"><div class="ttl">' + esc(x.text) + '</div><div class="sub">' + (x.price ? nf(x.price, true) + ' ' + t('cur') + ' · ' : '') + (x.doneAt ? dayLabel(dayKey(new Date(x.doneAt))) : '') + '</div></div>' +
      '<button class="mini" type="button" data-open="shop:' + esc(x.id) + '" aria-label="⋮">⋮</button></div></div>').join('') +
      '<div class="row gap"><button class="btn ghost" type="button" data-act="s-copy">' + t('copySel') + '</button>' +
      '<button class="btn ghost" type="button" data-act="s-clear">' + t('clearSel') + '</button></div>';
  }
  return h;
}

/* ================= عادت‌ها ================= */
const WD_ORDER = () => LANG === 'en' ? [0, 1, 2, 3, 4, 5, 6] : [6, 0, 1, 2, 3, 4, 5];
function wdName(n, short) {
  try { return new Date(2023, 0, 1 + n).toLocaleDateString(NL(), { weekday: short ? 'short' : 'long' }); } catch (e) { return String(n); }
}
function wdNames(a) { return WD_ORDER().filter(x => a.indexOf(x) > -1).map(x => wdName(x, true)).join('، '); }
function vHabits() {
  const today = dayKey();
  let h = '<button class="btn addb" type="button" data-act="add" data-id="habits">' + t('newHabit') + '</button>';
  if (!S.habits.length) return h + empty(t('noHabits'));
  h += S.habits.map(x => {
    const set = new Set(x.days);
    const on = set.has(today);
    const hasSubs = x.subs.length > 0;
    const ids = (x.sd && x.sd[today]) || [];
    let dots = '';
    for (let i = 6; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i);
      dots += '<span class="dot' + (set.has(dayKey(d)) ? ' on' : '') + (i === 0 ? ' today' : '') + '"></span>';
    }
    return '<div class="item" data-lp="habits:' + esc(x.id) + '">' +
      '<button class="chk' + (on ? ' on' : '') + '" type="button" data-act="h-toggle" data-id="' + esc(x.id) + '">' + (on ? '✔' : '') + '</button>' +
      '<div class="grow"><div class="ttl">' + esc(x.name) + (x.cloud ? ' ☁️' : '') + '</div>' +
      '<div class="sub">' + t('streakDays', nf(habStreak(x))) + (hasSubs ? t('todayPct', nf(hPct(x, today))) : '') +
      (x.wd && x.wd.length ? ' · ' + wdNames(x.wd) + (habOn(x) ? '' : ' · ' + t('notToday')) : '') + '</div>' +
      (hasSubs ? '<div class="bar' + (on ? ' ok' : '') + '"><i style="width:' + hPct(x, today) + '%"></i></div>' +
        subsHtml(x.subs, 'data-act="h-sub" data-id="' + esc(x.id) + '"', s => ids.indexOf(s.id) > -1) : '') +
      '<div class="dots">' + dots + '</div></div>' +
      '<button class="mini" type="button" data-open="habits:' + esc(x.id) + '" aria-label="⋮">⋮</button></div>';
  }).join('');
  return h;
}

/* ================= تایمر ================= */
const C_ARC = 339.292;
const T = { total: 25 * 60, left: 25 * 60, end: 0, run: false };
function tmLeft() { return T.run ? Math.max(0, Math.ceil((T.end - Date.now()) / 1000)) : T.left; }
function mmss(s) { return pad(Math.floor(s / 60)) + ':' + pad(s % 60); }
function arcOff(s) { return T.total ? C_ARC * (1 - s / T.total) : 0; }
function durText(sec) { sec = Math.round(sec); return sec % 60 === 0 ? nf(sec / 60) + ' ' + t('minU') : (sec < 60 ? nf(sec) + ' ' + t('secU') : fmtClock(sec)); }
function tcName(sec) { sec = Math.round(sec); return sec % 60 === 0 ? t('timerCloud', nf(sec / 60)) : t('timerCloudS', fmtClock(sec)); }
function setTimerSec(sec) {
  T.total = sec;
  if (T.run) { T.end = Date.now() + sec * 1000; T.left = sec; refresh(true); }
  else { T.left = sec; refresh(false); }
}
function setTimerMin(m) { setTimerSec(m * 60); }
function slotBtn(i) {
  const m = S.slots[i];
  return '<button class="slotb' + (m && T.total === m ? ' on' : '') + '" type="button" data-act="slot" data-id="' + i + '"' + (m ? ' data-lp="slot:' + i + '"' : '') + '>' +
    (m ? (m % 60 === 0 ? '<b>' + nf(m / 60) + '</b><small>' + t('minU') + '</small>' : m < 60 ? '<b>' + nf(m) + '</b><small>' + t('secU') + '</small>' : '<b>' + fmtClock(m) + '</b><small>' + t('minU') + '</small>') : '<b>＋</b><small>' + t('slotNew') + '</small>') + '</button>';
}
function vTimer() {
  const s = tmLeft();
  const m = T.total / 60;
  return '<div class="card center"><div class="chips c-center">' +
    '<button class="chip' + (m === 25 ? ' on' : '') + '" type="button" data-act="tm-set" data-min="25">' + t('focus25') + '</button>' +
    '<button class="chip' + (m === 5 ? ' on' : '') + '" type="button" data-act="tm-set" data-min="5">' + t('rest5') + '</button>' +
    '<button class="chip' + (m === 15 ? ' on' : '') + '" type="button" data-act="tm-set" data-min="15">' + t('rest15') + '</button></div>' +
    '<div class="trow"><div class="tside">' + slotBtn(0) + slotBtn(1) + '</div>' +
    '<div class="tring' + (T.run ? ' run' : '') + '" id="tring"><svg viewBox="0 0 120 120"><circle class="bgc" cx="60" cy="60" r="54"/>' +
    '<circle id="tm-arc" class="arc" cx="60" cy="60" r="54" stroke-dasharray="' + C_ARC + '" stroke-dashoffset="' + arcOff(s) + '"/></svg>' +
    '<div class="big" id="tm-disp">' + mmss(s) + '</div></div>' +
    '<div class="tside">' + slotBtn(2) + slotBtn(3) + '</div></div>' +
    '<div class="row"><button class="btn" type="button" data-act="tm-toggle">' + t(T.run ? 'pause' : 'start') + '</button>' +
    '<button class="btn ghost" type="button" data-act="tm-reset">' + t('restart') + '</button></div>' +
    '<div class="muted">' + t('timerHelp', nf(pomoToday())) + '</div></div>';
}
function tickTimer() {
  if (!T.run) return;
  const s = tmLeft();
  if (s <= 0) {
    T.run = false; T.left = 0;
    if (T.total >= 20 * 60) logAdd('p', dayKey(), '');
    save();
    toast(t('timerDone'));
    alarm();
    if (current === 'home') {
      const el = view.querySelector('.cloud[data-mt]');
      const cw = el ? el.closest('.cw') : null;
      if (cw) cw.classList.add('poof');
      setTimeout(() => { if (current === 'home') refresh(true); }, 380);
    } else if (current === 'timer') refresh(true);
    document.body.classList.remove('focus');
    return;
  }
  const tx = mmss(s);
  if (current === 'timer') {
    const d = $('tm-disp'), a = $('tm-arc');
    if (d && d.textContent !== tx) d.textContent = tx;
    if (a) a.style.strokeDashoffset = arcOff(s);
  } else if (current === 'home') {
    const el = view.querySelector('.cloud[data-mt] .c-s');
    if (el && el.textContent !== tx) el.textContent = tx;
  }
}
function tickQTimers() {
  if (!S.qtimers.length) return;
  const now = Date.now();
  const fin = S.qtimers.filter(q => q.end <= now);
  if (fin.length) {
    S.qtimers = S.qtimers.filter(q => q.end > now);
    save();
    toast(t('qtDone', fin[0].label || tcName(fin[0].total)));
    alarm();
    if (current === 'home') {
      fin.forEach(q => {
        const el = view.querySelector('.cloud[data-qt="' + q.id + '"]');
        const cw = el ? el.closest('.cw') : null;
        if (cw) cw.classList.add('poof');
      });
      setTimeout(() => { if (current === 'home') refresh(true); }, 380);
    }
  }
  if (current === 'home') {
    view.querySelectorAll('.cloud[data-qt]').forEach(el => {
      const q = S.qtimers.find(x => x.id === el.getAttribute('data-qt'));
      if (!q) return;
      const s = el.querySelector('.c-s');
      const tx = fmtClock(Math.ceil((q.end - now) / 1000));
      if (s && s.textContent !== tx) s.textContent = tx;
    });
  }
}

/* ================= هزینه ================= */
function vMoney() {
  const today = dayKey(), month = today.slice(0, 7);
  let td = 0, mo = 0;
  S.money.forEach(m => {
    const a = Number(m.a) || 0;
    if (m.d === today) td += a;
    if (String(m.d).slice(0, 7) === month) mo += a;
  });
  const b = S.set.budget;
  let bud = '';
  if (b > 0) {
    const p = mo / b;
    bud = '<div class="card"><div class="row-top"><div class="ttl grow">' + t('budgetMonth') + '</div><span class="pct' + (p > 1 ? ' bad' : '') + '">' + nf(Math.round(p * 100)) + '%</span></div>' +
      '<div class="bar' + (p > 1 ? ' over' : '') + '"><i style="width:' + Math.min(100, Math.round(p * 100)) + '%"></i></div>' +
      '<div class="sub">' + t('of', nf(mo, true), nf(b, true)) + ' ' + t('cur') + (p > 1 ? t('overBudget') : '') + '</div></div>';
  }
  let h = '<div class="stats ms"><div class="stat"><b>' + nf(td, true) + '</b>' + t('moneyToday') + '</div>' +
    '<div class="stat"><b>' + nf(mo, true) + '</b>' + t('moneyMonth') + '</div></div>' + bud +
    '<button class="btn addb" type="button" data-act="add" data-id="money">' + t('newSpend') + '</button>';
  if (!S.money.length) return h + empty(t('noSpend'));
  const rows = S.money.slice().sort((a, b2) => String(b2.d).localeCompare(String(a.d))).slice(0, 80);
  let lastD = '', shown = 0;
  h += '<div class="mtab" role="table"><div class="mh"><span></span><span>' + t('mcDesc') + '</span><span>' + t('mcDate') + '</span><span>' + t('mcAmt') + ' (' + t('cur') + ')</span><span></span></div>' +
    rows.map(m => {
      const ci = Number.isInteger(m.c) ? m.c : 5, a = Number(m.a) || 0;
      shown += a;
      return '<div class="mr' + (m.d === today ? ' td' : '') + '" data-lp="money:' + esc(m.id) + '" data-open="money:' + esc(m.id) + '"><span class="mi">' + CAT_ICONS[ci] + '</span>' +
        '<span class="md">' + esc(m.t || t('cat' + ci)) + '</span><span class="mdt">' + dayLabel(m.d) + '</span><b class="ma">' + nf(a, true) + '</b><span class="mm">⋮</span></div>';
    }).join('') +
    '<div class="mf"><span></span><span>' + t('mcTotal') + '</span><span></span><b class="ma">' + nf(shown, true) + '</b><span></span></div></div>';
  return h;
}

/* ================= هدف‌ها ================= */
function goalStatus(g) {
  const p = pctGoal(g);
  if (p >= 100) return t('goalDone');
  if (!g.due) return '';
  const now = Date.now();
  if (g.due < now) return t('goalLate');
  const days = Math.ceil((g.due - now) / 86400000);
  const exp = Math.min(1, Math.max(0, (now - (g.created || now)) / Math.max(1, g.due - (g.created || now))));
  const ok = p / 100 >= exp - 0.05;
  return t('goalDays', nf(days), t(ok ? 'onTrack' : 'behind'));
}
function vGoals() {
  let h = '<button class="btn addb" type="button" data-act="add" data-id="goals">' + t('newGoal') + '</button>';
  if (!S.goals.length) return h + empty(t('noGoals'));
  h += S.goals.map(g => {
    const p = Math.round(pctGoal(g));
    const st = goalStatus(g);
    return '<div class="item v" data-lp="goals:' + esc(g.id) + '">' +
      '<div class="row-top"><span class="gi">' + esc(g.icon || '🎯') + '</span><div class="ttl grow">' + esc(g.title) + (g.cloud ? ' ☁️' : '') + '</div>' +
      '<span class="pct">' + nf(p) + '%</span>' +
      '<button class="mini" type="button" data-open="goals:' + esc(g.id) + '" aria-label="⋮">⋮</button></div>' +
      '<div class="bar' + (p >= 100 ? ' ok' : '') + '"><i style="width:' + p + '%"></i></div>' +
      '<div class="row-top"><div class="sub grow">' + t('of', nd(g.cur), nd(g.target)) + ' ' + esc(g.unit) + (st ? '<br>' + st : '') + '</div>' +
      '<button class="chip" type="button" data-act="g-dec" data-id="' + esc(g.id) + '">− ' + nd(g.step) + '</button>' +
      '<button class="chip on" type="button" data-act="g-inc" data-id="' + esc(g.id) + '">+ ' + nd(g.step) + '</button></div></div>';
  }).join('');
  return h;
}

/* ================= آمار ================= */
function yearBuckets() {
  const bs = [], seen = {};
  for (let i = 0; i < 400 && bs.length < 12; i++) {
    const d = new Date(); d.setDate(d.getDate() - i);
    const mi = monthInfo(d);
    if (!seen[mi.key]) { seen[mi.key] = 1; bs.push(mi); }
  }
  return bs.reverse();
}
function series(kind, range) {
  const v = e => kind === 'm' ? (Number(e.a) || 0) : 1;
  const ents = S.log.filter(e => e.k === kind);
  if (range === 'y') {
    const bs = yearBuckets(), idx = {};
    bs.forEach((b, i) => { idx[b.key] = i; });
    const vals = bs.map(() => 0);
    ents.forEach(e => { const i = idx[monthKeyOfDay(e.d)]; if (i !== undefined) vals[i] += v(e); });
    return { vals: vals, labels: bs.map(b => b.label), cls: 'yr' };
  }
  const n = range === 'm' ? 30 : 7, days = [], idx = {};
  for (let i = n - 1; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); days.push(d); idx[dayKey(d)] = n - 1 - i; }
  const vals = days.map(() => 0);
  ents.forEach(e => { const i = idx[e.d]; if (i !== undefined) vals[i] += v(e); });
  const labels = days.map((d, i) => n === 7 ? wd(d) : ((n - 1 - i) % 5 === 0 ? nf(d.getDate()) : ''));
  return { vals: vals, labels: labels, cls: n > 7 ? 'dense' : '' };
}
function bars(vals, labels, fmt, cls) {
  const mx = Math.max.apply(null, vals.concat([1]));
  return '<div class="bars ' + (cls || '') + '">' + vals.map((x, i) =>
    '<div class="bcol"><span class="bv">' + fmt(x) + '</span><div class="bw"><div class="bb" style="height:' + Math.round(x / mx * 100) + '%"></div></div><span class="bl">' + esc(labels[i]) + '</span></div>'
  ).join('') + '</div>';
}
const nfmt = x => x ? nf(x) : '';
const kfmt = x => x ? nf(Math.round(x / 1000)) + 'k' : '';
function entriesFor(kind, range) {
  let ok;
  if (range === 'y') {
    const ks = {};
    yearBuckets().forEach(b => { ks[b.key] = 1; });
    ok = e => ks[monthKeyOfDay(e.d)] === 1;
  } else {
    const from = dayKeyAgo(range === 'm' ? 29 : 6), to = dayKey();
    ok = e => e.d >= from && e.d <= to;
  }
  return S.log.filter(e => e.k === kind && ok(e)).reverse().sort((a, b) => a.d < b.d ? 1 : a.d > b.d ? -1 : 0);
}
function weekReport() {
  const keys = [], now = new Date();
  for (let i = 0; i < 14; i++) { const d = new Date(now); d.setDate(d.getDate() - i); keys.push(dayKey(d)); }
  const cur = new Set(keys.slice(0, 7)), prev = new Set(keys.slice(7));
  const r = { cur: { t: 0, h: 0, p: 0, m: 0 }, prev: { t: 0, h: 0, p: 0, m: 0 }, day: {} };
  S.log.forEach(e => {
    const w = cur.has(e.d) ? r.cur : (prev.has(e.d) ? r.prev : null);
    if (!w) return;
    if (e.k === 'm') w.m += Number(e.a) || 0; else w[e.k]++;
    if (w === r.cur && e.k !== 'm') r.day[e.d] = (r.day[e.d] || 0) + 1;
  });
  let best = '', bv = 0;
  Object.keys(r.day).forEach(k => { if (r.day[k] > bv) { bv = r.day[k]; best = k; } });
  r.best = best; r.bestN = bv;
  return r;
}
function weekCard() {
  const r = weekReport();
  const row = (ic, label, a, b, fmt, inv) => {
    const dl = a - b, up = inv ? dl < 0 : dl > 0;
    const tag = dl === 0 || (!a && !b) ? '' : '<small class="' + (up ? 'up' : 'dn') + '"> ' + (dl > 0 ? '▲' : '▼') + ' ' + fmt(Math.abs(dl)) + '</small>';
    return '<div class="sub-row"><span class="si">' + ic + '</span><div class="grow"><div class="ttl">' + label + '</div></div><b>' + fmt(a) + '</b>' + tag + '</div>';
  };
  const n0 = x => nf(x), mm = x => nf(x, true) + ' ' + t('cur');
  return '<div class="card"><div class="ttl">📅 ' + t('wkTitle') + '</div><div class="sub gap">' + t('wkSub') + '</div>' +
    row('✅', t('ch_t'), r.cur.t, r.prev.t, n0) + row('🔥', t('ch_h'), r.cur.h, r.prev.h, n0) +
    row('🍅', t('ch_p'), r.cur.p, r.prev.p, n0) + row('💰', t('ch_m'), r.cur.m, r.prev.m, mm, true) +
    (r.best ? '<div class="sub gap">' + t('wkBest', dayLabel(r.best), nf(r.bestN)) + '</div>' : '<div class="sub gap">' + t('wkNone') + '</div>') + '</div>';
}
function vStats() {
  const today = dayKey();
  const sT = series('t', 'w'), sH = series('h', 'w'), sM = series('m', 'w'), sP = series('p', 'w');
  let best = 0;
  S.habits.forEach(h => { best = Math.max(best, habStreak(h)); });
  const month = today.slice(0, 7), cat = {};
  let top = -1, topV = 0;
  S.log.forEach(e => {
    if (e.k === 'm' && String(e.d).slice(0, 7) === month) {
      const c = Number.isInteger(e.c) ? e.c : 5;
      cat[c] = (cat[c] || 0) + (Number(e.a) || 0);
      if (cat[c] > topV) { topV = cat[c]; top = c; }
    }
  });
  const card = (k, s, fmt, extra) =>
    '<div class="card tap" data-act="stat-open" data-id="' + k + '"><div class="row-top"><div class="ttl grow">' + t('ch_' + k) + '</div><small class="sub">' + t('tapMore') + '</small></div>' +
    bars(s.vals, s.labels, fmt, s.cls) + (extra || '') + '</div>';
  return weekCard() + '<div class="stats">' +
    '<div class="stat"><b>' + nf(sT.vals[6]) + '</b>' + t('st_today') + '</div>' +
    '<div class="stat"><b>' + nf(sum(sT.vals)) + '</b>' + t('st_week') + '</div>' +
    '<div class="stat"><b>' + nf(best) + '</b>' + t('st_streak') + '</div>' +
    '<div class="stat"><b>' + nf(sP.vals[6]) + '</b>' + t('st_pomo') + '</div></div>' +
    card('t', sT, nfmt) + card('h', sH, nfmt) +
    card('m', sM, kfmt, '<div class="sub" style="margin-top:10px">' + t('weekTotal', nf(sum(sM.vals), true), t('cur')) +
      (top > -1 ? '<br>' + t('topCat', CAT_ICONS[top] + ' ' + t('cat' + top), nf(topV, true), t('cur')) : '') + '</div>') +
    card('p', sP, nfmt);
}
function statSheet(kind) {
  let range = 'w';
  const rowHtml = e => {
    let name;
    if (kind === 'm') { const ci = Number.isInteger(e.c) ? e.c : 5; name = CAT_ICONS[ci] + ' ' + (e.n || t('cat' + ci)); }
    else if (kind === 'p') name = '🍅 ' + t('focusSession');
    else name = e.n || '—';
    return '<div class="sub-row"><div class="grow"><div class="ttl">' + esc(name) + '</div><div class="sub">' + dayLabel(e.d) +
      (kind === 'm' ? ' · ' + nf(e.a, true) + ' ' + t('cur') : '') + '</div></div>' +
      '<button class="mini" type="button" data-sa="ldel" data-id="' + esc(e.id) + '" aria-label="' + esc(t('del')) + '">✕</button></div>';
  };
  return {
    render() {
      const sr = series(kind, range);
      const total = sum(sr.vals);
      const list = entriesFor(kind, range);
      let h = '<div class="grab"></div><div class="sh-t">' + t('ch_' + kind) + '</div>';
      h += '<div class="tabs">' + [['w', 'rWeek'], ['m', 'rMonth'], ['y', 'rYear']].map(r =>
        '<button class="tab' + (range === r[0] ? ' on' : '') + '" type="button" data-sa="sr" data-v="' + r[0] + '">' + t(r[1]) + '</button>').join('') + '</div>';
      h += bars(sr.vals, sr.labels, kind === 'm' ? kfmt : nfmt, sr.cls);
      h += '<div class="pk-prev">' + t('total') + ': ' + (kind === 'm' ? nf(total, true) + ' ' + t('cur') : nf(total)) + '</div>';
      h += '<div class="lbl">' + t('history') + '</div>';
      h += list.length ? list.slice(0, 150).map(rowHtml).join('') : '<div class="empty">' + t('noEntries') + '</div>';
      h += '<div class="sub gap">' + t('delNote') + '</div>';
      h += '<div class="row sh-b"><button class="btn ghost" type="button" data-sa="close">' + t('closeB') + '</button></div>';
      return h;
    },
    act(a, el) {
      if (a === 'sr') { range = el.dataset.v; repaint(); }
      else if (a === 'ldel') {
        const id = el.dataset.id;
        S.log = S.log.filter(e => e.id !== id);
        save(); toast(t('entryDeleted'));
        refresh(true); repaint();
      } else if (a === 'close') popSheet();
    }
  };
}

/* ================= دفتر خاطرات ================= */
let dUnlocked = false;
function lockDiary() {
  if (ed && ed.kind === 'diary') closeEd(false, true);
  if (dKey && S.diary.hash) {
    S.diary.secs = S.diary.secs.map(n => ({ id: n.id, t: n.t, enc: diaryBlob(n) }));
    save();
  }
  dKey = null;
  Object.keys(encCache).forEach(k => { delete encCache[k]; });
  dUnlocked = false;
}
function unlockDiary(pw) {
  dKey = deriveDiaryKey(pw, S.diary.salt);
  S.diary.secs = S.diary.secs.map(n => {
    if (!n.enc) return n;
    const j = decBlob(dKey, n.enc);
    let o = null;
    try { o = j == null ? null : JSON.parse(j); } catch (e) {}
    return o ? { id: n.id, t: n.t, title: String(o.a || ''), text: String(o.b || '') } : n;
  });
  dUnlocked = true;
  save();   // دفترهای قدیمی (بدون رمزگذاری) همین‌جا رمزگذاری می‌شوند
}
function vDiary() {
  if (ed && ed.kind === 'diary' && dUnlocked) {
    const n = edItem();
    if (n) return editorHtml(n, 'diary');
    ed = null;
  }
  if (!S.diary.hash) {
    return '<div class="card lockc"><div class="big-ic">📔</div><div class="ttl gap">' + t('dSetupTitle') + '</div>' +
      '<div class="sub gap">' + t('dSetupMsg') + '</div>' +
      '<input id="dp1" class="inp" type="password" placeholder="' + esc(t('dPw')) + '" autocomplete="new-password">' +
      '<input id="dp2" class="inp" type="password" placeholder="' + esc(t('dPw2')) + '" autocomplete="new-password" data-enter="d-setup-btn">' +
      '<button id="d-setup-btn" class="btn" type="button" data-act="d-setup">' + t('dCreate') + '</button></div>';
  }
  if (!dUnlocked) {
    return '<div class="card lockc"><div class="big-ic">🔒</div><div class="ttl gap">' + t('dLockedTitle') + '</div>' +
      '<input id="dp" class="inp" type="password" placeholder="' + esc(t('dPw')) + '" autocomplete="off" data-enter="d-unlock-btn">' +
      '<button id="d-unlock-btn" class="btn" type="button" data-act="d-unlock">' + t('dUnlock') + '</button>' +
      '<button class="btn ghost" type="button" data-act="d-forgot" style="margin-top:10px">' + t('dForgot') + '</button></div>';
  }
  let h = '<button class="btn addb" type="button" data-act="d-new">' + t('dNewSec') + '</button>';
  const vis = S.diary.secs.filter(n => !n.enc);
  if (!vis.length) h += empty(t('dNoSecs'));
  else {
    h += vis.slice().sort((a, b) => (b.t || 0) - (a.t || 0)).map(n => {
      const prev = notePrev(n);
      return '<div class="item"><div class="grow" data-act="d-open" data-id="' + esc(n.id) + '">' +
        '<div class="ttl">' + esc(noteTitle(n)) + '</div>' +
        (prev ? '<div class="np clamp2">' + esc(prev) + '</div>' : '') +
        '<div class="sub">' + fmtDue(n.t || Date.now()) + '</div></div></div>';
    }).join('');
  }
  h += '<div class="row gap"><button class="btn ghost" type="button" data-act="d-chpw">' + t('dChangePw') + '</button>' +
    '<button class="btn ghost" type="button" data-act="d-lock">' + t('dLockNow') + '</button></div>' +
    '<div class="muted center">' + t('dBackupNote') + '</div><div class="muted center">' + t('dEncNote') + '</div>';
  return h;
}
function pwForm() {
  const d = { p1: '', p2: '' };
  pushSheet(formSheet({
    title: t('dChangePw'), draft: d,
    fields: [{ kind: 'pw', key: 'p1', label: t('dNewPw') }, { kind: 'pw', key: 'p2', label: t('dPw2') }],
    onSave(dd) {
      if (dd.p1.length < 4) { toast(t('dPwShort')); return false; }
      if (dd.p1 !== dd.p2) { toast(t('dMismatch')); return false; }
      const salt = uid();
      S.diary.salt = salt;
      S.diary.hash = hashPw(dd.p1, salt);
      dKey = deriveDiaryKey(dd.p1, salt);
      Object.keys(encCache).forEach(k => { delete encCache[k]; });
      save();
      toast(t('dPwChanged'));
    }
  }));
}

/* ================= تنظیمات ================= */
function vSettings() {
  const seg = (list, cur, action) => '<div class="seg">' + list.map(o =>
    '<button type="button" class="' + (cur === o[0] ? 'on' : '') + '" data-act="' + action + '" data-id="' + o[0] + '">' + o[1] + '</button>').join('') + '</div>';
  const sw = (on, id) => '<button class="switch' + (on ? ' on' : '') + '" type="button" data-act="tog" data-id="' + id + '" role="switch" aria-checked="' + (on ? 'true' : 'false') + '"></button>';
  const sws = ACCENTS.map((a, i) =>
    '<button class="swatch' + (S.set.accent === i ? ' on' : '') + '" type="button" data-act="accent" data-id="' + i + '" style="background:linear-gradient(135deg,' + a[0] + ',' + a[1] + ')" aria-label="' + (i + 1) + '"></button>').join('');
  const group = (title, rows) => '<div class="sg"><div class="sg-t">' + title + '</div><div class="sg-c">' + rows + '</div></div>';
  return group('🌐 ' + t('language'),
      '<div class="srow col">' + seg([['fa', 'فارسی'], ['en', 'English']], S.set.lang, 'lang') + '</div>') +
    group('🎨 ' + t('appearance'),
      '<div class="srow col"><div class="sl"><b>' + t('theme') + '</b><small>' + t('thAutoHint') + '</small></div>' +
      seg([['dark', t('thDark')], ['light', t('thLight')], ['auto', t('thAuto')]], S.set.theme, 'theme-set') + '</div>' +
      '<div class="srow col"><div class="sl"><b>' + t('accent') + '</b></div><div class="chips" style="margin:0">' + sws + '</div></div>') +
    group('🔤 ' + t('fontSec'),
      '<div class="srow col"><div class="sl"><b>' + t('fontSize') + '</b><small>' + t('fontSizeSub') + '</small></div>' +
      seg([[0, t('fs0')], [1, t('fs1')], [2, t('fs2')], [3, t('fs3')], [4, t('fs4')]], S.set.fs, 'fs-set') +
      '<div class="fsprev">' + t('fontPrev') + '</div></div>' +
      '<div class="srow col"><div class="sl"><b>' + t('fontFam') + '</b><small>' + t('fontFamSub') + '</small></div>' +
      seg([['nimbo', t('ffNimbo')], ['system', t('ffSystem')]], S.set.ff, 'ff-set') + '</div>') +
    group('🔔 ' + t('alerts'),
      '<div class="srow"><span class="si">🔊</span><div class="sl"><b>' + t('sound') + '</b><small>' + t('soundSub') + '</small></div>' + sw(S.set.sound, 'sound') + '</div>' +
      '<div class="srow"><span class="si">📳</span><div class="sl"><b>' + t('vib') + '</b><small>' + t('vibSub') + '</small></div>' + sw(S.set.vib, 'vib') + '</div>') +
    group('💰 ' + t('budget'),
      '<div class="srow"><span class="si">💱</span><div class="sl"><b>' + t('curTitle') + '</b><small>' + esc(curLabel()) + '</small></div>' +
      '<button class="btn sm" type="button" data-act="cur-open">' + t('change') + '</button></div>' +
      '<div class="srow col"><div class="sl"><b>' + t('budgetMonthly') + '</b><small>' + t('budgetSub') + '</small></div>' +
      '<div class="row"><input id="set-budget" class="inp" type="text" inputmode="numeric" data-nf="m" value="' + esc(fmtNumVal(S.set.budget)) + '" placeholder="5,000,000" autocomplete="off">' +
      '<button class="btn sm" type="button" data-act="budget-save">' + t('save') + '</button></div></div>') +
    group('📔 ' + t('diary'),
      '<div class="srow"><span class="si">' + (S.diary.hash ? '🔒' : '📔') + '</span><div class="sl"><b>' + t('diary') + '</b><small>' + t(S.diary.hash ? 'dSubSet' : 'dSubNew') + '</small></div>' +
      '<button class="btn sm" type="button" data-act="diary-open">' + t('dOpen') + '</button></div>') +
    group('🧩 ' + t('mods'),
      '<div class="srow"><span class="si">🧩</span><div class="sl"><b>' + t('mods') + '</b><small>' + t('modsSub', nf(MODS_ON.length)) + '</small></div>' +
      '<button class="btn sm" type="button" data-act="mods-open">' + t('dOpen') + '</button></div>') +
    group('💾 ' + t('data'),
      '<div class="srow"><span class="si">💾</span><div class="sl"><b>' + t('backup') + '</b><small>' + t('bkSub') + '</small></div>' +
      '<div class="bkb"><button class="btn sm" type="button" data-act="bk-file">' + t('bkSave2') + '</button>' +
      '<button class="btn sm ghost" type="button" data-act="bk-pick">' + t('bkRestore2') + '</button></div></div>' +
      '<input id="bkf" type="file" accept=".json,application/json,text/plain" style="display:none">' +
      '<details class="bkd"><summary>' + t('bkAdv') + '</summary>' +
      '<div class="sub gap">' + t('bkTextNote') + '</div>' +
      '<textarea id="bk" class="inp" rows="3" style="margin:0" placeholder="' + esc(t('backupPh')) + '"></textarea>' +
      '<div class="row"><button class="btn ghost sm" type="button" data-act="bk-make">' + t('bkMake') + '</button>' +
      '<button class="btn ghost sm" type="button" data-act="bk-load">' + t('bkLoad') + '</button></div></details>') +
    group('⚠️ ' + t('danger'),
      '<div class="srow col"><button class="btn danger" type="button" data-act="reset">' + t('eraseAll') + '</button></div>') +
    '<div class="muted center">' + t('localNote') + '</div>';
}

const V = { home: vHome, tasks: vTasks, notes: vNotes, shop: vShop, habits: vHabits, timer: vTimer, money: vMoney, goals: vGoals, stats: vStats, settings: vSettings, diary: vDiary };
let current = 'home';

/* ================= مودها (داخل خود برنامه، بدون دانلود) =================
   هر مود یک آیتم در لیست BUILTIN_MODS است. فقط یک مود می‌تواند فعال باشد:
   وقتی کاربر مود دیگری را می‌زند، مود قبلی خودکار خاموش می‌شود.

   قالب یک مود (همهٔ بخش‌ها به‌جز id و name اختیاری‌اند):
     {
       id: 'نام-انگلیسی-یکتا',
       name: 'نام نمایشی',
       desc: 'توضیح کوتاه',
       tags: ['برچسب۱', 'برچسب۲'],          // برای جست‌وجو
       css: '...کد CSS...',                  // ظاهر
       js: '...کد جاوااسکریپت...'            // رفتار؛ داخلش به شیء nimbo دسترسی داری
     }

   امکانات شیء nimbo داخل js:
     nimbo.S              داده‌های برنامه (tasks, notes, shop, habits, money, goals, log, set ...)
     nimbo.save()         ذخیره‌کردن داده‌ها
     nimbo.refresh()      بازکشیدن دوبارهٔ صفحهٔ فعلی
     nimbo.go('tasks')    رفتن به یک بخش (home, tasks, notes, shop, habits, timer, money, goals, stats, settings)
     nimbo.current()      نام بخش فعلی
     nimbo.toast('متن')    پیام کوتاه
     nimbo.css('...')     افزودن CSS؛ تابع پاک‌کردنش را برمی‌گرداند
     nimbo.onView(fn)     هر بار صفحه‌ای کشیده شد fn(نام‌بخش, عنصر) صدا زده می‌شود (برای اضافه‌کردن دکمه و المان)
     nimbo.el(id)         گرفتن المان با id
     nimbo.lang()         'fa' یا 'en'
   اگر در js تابعی return کنی، وقتی مود خاموش شد صدا زده می‌شود (برای جمع‌کردن کارهایی که کرده‌ای).
   مودهای onView و المان‌های اضافه خودکار با خاموش‌شدن مود پاک می‌شوند، ولی المان‌هایی را که خودت در document می‌گذاری باید در تابع return پاک کنی. */
const LIQUID_JS = function (nimbo) {
  var NS = 'http://www.w3.org/2000/svg';
  function band(id, x1, y1, x2, y2, rgb, off) {
    return '<linearGradient id="' + id + '" x1="' + x1 + '" y1="' + y1 + '" x2="' + x2 + '" y2="' + y2 + '">' +
      '<stop offset="0" stop-color="' + rgb + '"/><stop offset="' + off + '" stop-color="rgb(128,128,128)" stop-opacity="0"/></linearGradient>';
  }
  function dmap(bx, by) {
    var svg = '<svg xmlns="' + NS + '" width="100" height="100" viewBox="0 0 100 100" preserveAspectRatio="none"><defs>' +
      band('l', 0, 0, 1, 0, 'rgb(255,128,128)', bx) + band('r', 1, 0, 0, 0, 'rgb(0,128,128)', bx) +
      band('t', 0, 0, 0, 1, 'rgb(128,255,128)', by) + band('b', 0, 1, 0, 0, 'rgb(128,0,128)', by) + '</defs>' +
      '<rect width="100" height="100" fill="rgb(128,128,128)"/>' +
      '<rect width="100" height="100" fill="url(#l)"/><rect width="100" height="100" fill="url(#r)"/>' +
      '<rect width="100" height="100" fill="url(#t)"/><rect width="100" height="100" fill="url(#b)"/></svg>';
    return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
  }
  function filt(id, scale, bx, by) {
    return '<filter id="' + id + '" primitiveUnits="objectBoundingBox" x="0" y="0" width="1" height="1" color-interpolation-filters="sRGB">' +
      '<feImage x="0" y="0" width="1" height="1" preserveAspectRatio="none" href="' + dmap(bx, by) + '" result="m"/>' +
      '<feDisplacementMap in="SourceGraphic" in2="m" scale="' + scale + '" xChannelSelector="R" yChannelSelector="G"/></filter>';
  }
  var holder = document.createElement('div');
  holder.style.cssText = 'position:absolute;width:0;height:0;overflow:hidden;pointer-events:none';
  holder.innerHTML = '<svg width="0" height="0" aria-hidden="true"><defs>' +
    filt('lgA', 0.035, 0.07, 0.06) +
    '</defs></svg>';
  document.body.appendChild(holder);

  var sel = '.card,.item,.stat,.sg-c,.btn,.chip,.tbtn,.it,.hub,.top,.sheet,.wheel,.pillmore,.hb,.slotb,.tab,.mrow,.inp,.toast';
  function glow(e) {
    var t = e.target && e.target.closest && e.target.closest(sel);
    if (!t) return;
    var r = t.getBoundingClientRect();
    if (!r.width || !r.height) return;
    t.style.setProperty('--mx', ((e.clientX - r.left) / r.width * 100).toFixed(1) + '%');
    t.style.setProperty('--my', ((e.clientY - r.top) / r.height * 100).toFixed(1) + '%');
  }
  document.addEventListener('pointerdown', glow, true);

  var root = document.documentElement, pend = false, ox = 0, oy = 0;
  function tilt(e) {
    if (e.gamma == null) return;
    ox = Math.max(-30, Math.min(30, e.gamma));
    oy = Math.max(-30, Math.min(30, (e.beta || 0) - 40));
    if (pend) return;
    pend = true;
    requestAnimationFrame(function () {
      pend = false;
      root.style.setProperty('--tx', (-ox * 1.4).toFixed(1) + 'px');
      root.style.setProperty('--ty', (-oy * 1.4).toFixed(1) + 'px');
    });
  }
  window.addEventListener('deviceorientation', tilt);

  return function () {
    document.removeEventListener('pointerdown', glow, true);
      window.removeEventListener('deviceorientation', tilt);
    holder.remove();
    root.style.removeProperty('--tx');
    root.style.removeProperty('--ty');
    document.querySelectorAll('[style*="--mx"]').forEach(function (el) { el.style.removeProperty('--mx'); el.style.removeProperty('--my'); });
  };
};
const GLASS_CSS = `/* ===== شیشه‌ای مات (Liquid Glass) ===== */
:root{
  --g-fill: linear-gradient(135deg, rgba(255,255,255,.17), rgba(255,255,255,.05));
  --g-fill2: linear-gradient(135deg, rgba(255,255,255,.26), rgba(255,255,255,.09));
  --g-line: rgba(255,255,255,.20);
  --g-hi: rgba(255,255,255,.38);
  --g-sh: 0 10px 30px rgba(0,0,0,.28);
  --g-blur: blur(18px) saturate(170%);
  --g-text: #f8fafc;
}
body.light{
  --g-fill: linear-gradient(135deg, rgba(255,255,255,.78), rgba(255,255,255,.42));
  --g-fill2: linear-gradient(135deg, rgba(255,255,255,.9), rgba(255,255,255,.55));
  --g-line: rgba(255,255,255,.85);
  --g-hi: rgba(255,255,255,1);
  --g-sh: 0 10px 30px rgba(60,80,120,.18);
  --g-text: #0f172a;
}

/* پس‌زمینهٔ رنگی نرم که شیشه روی آن معنا پیدا می‌کند */
body::before{
  content:""; position:absolute; left:-25%; top:-25%; width:150%; height:150%; z-index:-1; pointer-events:none;
  background:
    radial-gradient(38% 32% at 20% 18%, rgba(56,189,248,.55), transparent 70%),
    radial-gradient(42% 36% at 84% 24%, rgba(168,85,247,.50), transparent 70%),
    radial-gradient(46% 40% at 72% 82%, rgba(236,72,153,.42), transparent 70%),
    radial-gradient(38% 34% at 12% 78%, rgba(34,197,94,.36), transparent 70%);
  animation: glassDrift 60s ease-in-out infinite alternate; will-change: transform;
}
body.light::before{
  background:
    radial-gradient(38% 32% at 20% 18%, rgba(56,189,248,.55), transparent 70%),
    radial-gradient(42% 36% at 84% 24%, rgba(192,132,252,.50), transparent 70%),
    radial-gradient(46% 40% at 72% 82%, rgba(251,146,190,.50), transparent 70%),
    radial-gradient(38% 34% at 12% 78%, rgba(110,231,160,.46), transparent 70%);
}
@keyframes glassDrift{ from{transform:translate(-3%,-2%) rotate(0deg) scale(1)} to{transform:translate(3%,3%) rotate(8deg) scale(1.08)} }

/* سطح‌های شیشه‌ای اصلی */
.card,.item,.stat,.sg-c,.tabs,.seg,.reader,.warn,.mrow,.sub-row,.lockc,.slotb,.ned-title,.ned-text,.inp,.hb,.pillmore,.tbtn,.chip,.btn.ghost,.opts .btn{
  background: var(--g-fill) !important;
  border: 1px solid var(--g-line) !important;
  box-shadow: inset 0 1px 0 var(--g-hi), inset 0 -1px 0 rgba(255,255,255,.06), 0 6px 16px rgba(0,0,0,.2);
  color: var(--g-text);
}
.item{ border-inline-start: 4px solid var(--pc, var(--g-line)) !important; }
.item.late{ border-color: var(--bad) !important; }
.chip,.tbtn,.inp,.slotb,.ned-title,.ned-text,.sub-row{ box-shadow: inset 0 1px 0 var(--g-hi), 0 3px 8px rgba(0,0,0,.12); }
.inp::placeholder,.ned-title::placeholder,.ned-text::placeholder{ color: rgba(148,163,184,.9); }
.inp:focus,.ned-title:focus,.ned-text:focus{ border-color: rgba(255,255,255,.55) !important; box-shadow: inset 0 1px 0 var(--g-hi), 0 0 0 3px rgba(125,211,252,.28); }
.card.tap:active,.item:active{ background: var(--g-fill2) !important; }

/* نوار بالا */
.top{
  background: var(--g-fill) !important;
  border-bottom: 1px solid var(--g-line) !important;
  box-shadow: inset 0 -1px 0 rgba(255,255,255,.08), 0 6px 24px rgba(0,0,0,.18);
  -webkit-backdrop-filter: var(--g-blur); backdrop-filter: var(--g-blur);
  color: var(--g-text);
}
.top h1{ color: var(--g-text); }

/* دکمه‌های رنگی: شیشهٔ رنگی با درخشش */
.btn:not(.ghost):not(.danger),.chip.on,.tab.on,.seg button.on,.slotb.on{
  background-image: linear-gradient(180deg, rgba(255,255,255,.45), rgba(255,255,255,0) 55%), linear-gradient(135deg, var(--acc), var(--acc2)) !important;
  background-color: transparent !important;
  border: 1px solid rgba(255,255,255,.45) !important;
  box-shadow: inset 0 1px 0 rgba(255,255,255,.7), 0 8px 22px rgba(0,0,0,.28);
  color: #fff !important;
  text-shadow: 0 1px 2px rgba(0,0,0,.25);
}
.btn.danger{
  background-image: linear-gradient(180deg, rgba(255,255,255,.4), rgba(255,255,255,0) 55%), linear-gradient(135deg, #ef4444, #be123c) !important;
  border: 1px solid rgba(255,255,255,.4) !important;
  box-shadow: inset 0 1px 0 rgba(255,255,255,.6), 0 8px 22px rgba(0,0,0,.25);
}
.tab,.seg button{ background: transparent !important; border: 0 !important; box-shadow: none !important; -webkit-backdrop-filter: none; backdrop-filter: none; color: var(--g-text); }
.tabs,.seg{ padding: 3px; }

/* نوارهای پیشرفت */
.bar{ background: rgba(255,255,255,.14) !important; box-shadow: inset 0 1px 2px rgba(0,0,0,.25); }

.tring .bgc{ stroke: rgba(255,255,255,.16) !important; }


/* پنجرهٔ پایین (شیت) */
.ov{ background: rgba(8,12,24,.28) !important; -webkit-backdrop-filter: blur(8px) saturate(140%); backdrop-filter: blur(8px) saturate(140%); }
.sheet{
  background: linear-gradient(160deg, rgba(255,255,255,.26), rgba(255,255,255,.08)) !important;
  border: 1px solid var(--g-line); border-bottom: 0;
  box-shadow: inset 0 1px 0 var(--g-hi), 0 -16px 50px rgba(0,0,0,.35);
  -webkit-backdrop-filter: blur(40px) saturate(200%); backdrop-filter: blur(40px) saturate(200%);
  color: var(--g-text);
}
body.light .sheet{ background: linear-gradient(160deg, rgba(255,255,255,.88), rgba(255,255,255,.6)) !important; }
.sheet .grab{ background: rgba(255,255,255,.5) !important; }

/* پیام */
.toast{
  background: var(--g-fill2) !important; color: var(--g-text) !important;
  border: 1px solid var(--g-line); box-shadow: inset 0 1px 0 var(--g-hi), var(--g-sh);
  -webkit-backdrop-filter: var(--g-blur); backdrop-filter: var(--g-blur);
}

/* چرخ منو */
.wheel{
  background: linear-gradient(160deg, rgba(255,255,255,.2), rgba(255,255,255,.05)) !important;
  border: 1px solid var(--g-line) !important;
  box-shadow: inset 0 2px 0 var(--g-hi), 0 -10px 40px rgba(0,0,0,.3);
  -webkit-backdrop-filter: var(--g-blur); backdrop-filter: var(--g-blur);
}
body.light .wheel{ background: linear-gradient(160deg, rgba(255,255,255,.8), rgba(255,255,255,.45)) !important; }
.it{
  background: var(--g-fill2) !important; border: 1px solid var(--g-line) !important;
  box-shadow: inset 0 1px 0 var(--g-hi), 0 6px 16px rgba(0,0,0,.25);
  color: var(--g-text);
}
.it.act{ background-image: linear-gradient(180deg, rgba(255,255,255,.5), rgba(255,255,255,0) 60%), linear-gradient(135deg, var(--acc), var(--acc2)) !important; border-color: rgba(255,255,255,.7) !important; color:#fff; }
.hub{
  background-image: linear-gradient(180deg, rgba(255,255,255,.5), rgba(255,255,255,0) 55%), linear-gradient(135deg, var(--acc), var(--acc2)) !important;
  border: 1px solid rgba(255,255,255,.65) !important;
  box-shadow: inset 0 1px 0 rgba(255,255,255,.8), 0 8px 22px rgba(0,0,0,.35);
}

/* صفحهٔ اصلی: شیشهٔ روی آسمان */
.hb{ background: linear-gradient(135deg, rgba(255,255,255,.34), rgba(255,255,255,.12)) !important; }
.pillmore{ color: #fff; }

/* کلید روشن/خاموش */
.switch{ background: rgba(255,255,255,.22) !important; border: 1px solid var(--g-line); box-shadow: inset 0 1px 3px rgba(0,0,0,.25); }
.switch.on{ background: rgba(34,197,94,.75) !important; }

/* فقط سطح‌هایی که روی محتوا می‌نشینند بلور می‌گیرند (سبک‌تر و روان‌تر) */
.top,.sheet,.wheel,.toast,.pillmore,.hb{ -webkit-backdrop-filter: var(--g-blur); backdrop-filter: var(--g-blur); }
`;
const CRYSTAL_JS = function (nimbo) {
  var bg = document.createElement('div');
  bg.id = 'lgbg';
  document.body.appendChild(bg);
  var pend = false, ox = 0, oy = 0;
  function tilt(e) {
    if (e.gamma == null) return;
    ox = Math.max(-25, Math.min(25, e.gamma));
    oy = Math.max(-25, Math.min(25, (e.beta || 0) - 40));
    if (pend) return;
    pend = true;
    requestAnimationFrame(function () {
      pend = false;
      bg.style.transform = 'translate3d(' + (-ox * 0.8).toFixed(1) + 'px,' + (-oy * 0.8).toFixed(1) + 'px,0)';
    });
  }
  window.addEventListener('deviceorientation', tilt);
  return function () {
    window.removeEventListener('deviceorientation', tilt);
    bg.remove();
  };
};
const FALL_JS = function (nimbo, kind) {
  let cv = null, raf = 0, W = 0, H = 0, last = 0;
  const B = document.body, N = kind === 'snow' ? 46 : 50, ps = [];
  const look = () => B.classList.contains('mod-terminal') ? 'green' : (B.classList.contains('mod-paper') ? 'ink' : 'plain');
  function reset(p, first) {
    p.x = Math.random() * W; p.y = first ? Math.random() * H : -10;
    p.v = kind === 'snow' ? 18 + Math.random() * 26 : 380 + Math.random() * 220;
    p.s = kind === 'snow' ? 1.2 + Math.random() * 2.4 : 8 + Math.random() * 10;
    p.w = Math.random() * 6.28;
    // برای حالت «کشیدن و پاک‌کردن روی کاغذ»
    p.life = 1.8 + Math.random() * 1.8; p.age = -Math.random() * p.life;
    p.L = kind === 'snow' ? 7 + Math.random() * 6 : 14 + Math.random() * 14;
    if (first === 2) { p.x = Math.random() * W; p.y = 30 + Math.random() * (H - 60); }
  }
  function mount(sc) {
    if (cv && cv.isConnected) return;
    cv = document.createElement('canvas');
    cv.className = 'fall';
    W = cv.width = sc.clientWidth || 360; H = cv.height = sc.clientHeight || 640;
    sc.appendChild(cv);
    ps.length = 0;
    for (let i = 0; i < N; i++) { const p = {}; reset(p, true); ps.push(p); }
  }
  function ink(g, dt) {
    g.lineCap = 'round';
    ps.forEach(p => {
      p.age += dt;
      if (p.age < 0) return;
      if (p.age > p.life) { reset(p, 2); p.age = 0; return; }
      const f = p.age / p.life;
      const draw = Math.min(1, f / 0.22);                       // کشیدن
      const er = f < 0.62 ? 0 : (f - 0.62) / 0.38;              // پاک‌شدن
      const al = 0.62 * (1 - er * er);
      g.strokeStyle = 'rgba(58,46,28,' + al.toFixed(3) + ')';
      g.lineWidth = 1.7 - er * 0.6;
      g.beginPath();
      if (kind === 'snow') {
        const r = p.L * (draw * 0.85 + 0.15) * (1 - er * 0.35);
        for (let k = 0; k < 3; k++) {
          const an = k * 1.0472 + p.w;
          g.moveTo(p.x - Math.cos(an) * r, p.y - Math.sin(an) * r); g.lineTo(p.x + Math.cos(an) * r, p.y + Math.sin(an) * r);
        }
      } else {
        const x0 = p.x, y0 = p.y + p.age * 14, dx = -p.L * 0.22;
        const a0 = er, a1 = draw;                                // ابتدا و انتهای بخش دیده‌شده
        g.moveTo(x0 + dx * a0, y0 + p.L * a0);
        g.lineTo(x0 + dx * a1 + Math.sin(p.w) * 0.8, y0 + p.L * a1);
        g.moveTo(x0 + 1.4 + dx * a0, y0 + p.L * a0 + 1);          // خط دومِ کم‌رنگ، حالت مداد
        g.lineTo(x0 + 1.4 + dx * a1 * 0.9, y0 + p.L * a1 * 0.9 + 1);
      }
      g.stroke();
    });
  }
  const can = () => nimbo.current() === 'home' && !document.hidden && !document.querySelector('.px-ov') && cv && cv.isConnected;
  function sync() {          // خارج از صفحهٔ اصلی یا وقتی پنجره‌ای روی صفحه است، هیچ حلقهٔ انیمیشنی اجرا نمی‌شود
    if (can()) { if (!raf) { last = 0; raf = requestAnimationFrame(frame); } }
    else if (raf) { cancelAnimationFrame(raf); raf = 0; }
  }
  function frame(ts) {
    if (!can()) { raf = 0; return; }
    raf = requestAnimationFrame(frame);
    if (ts - last < 33) return;   // حداکثر ۳۰ فریم در ثانیه
    const dt = Math.min(0.06, (ts - last) / 1000); last = ts;
    const g = cv.getContext('2d'), lk = look();
    g.clearRect(0, 0, W, H);
    if (lk === 'ink') { ink(g, dt); return; }
    if (kind === 'snow') {
      g.fillStyle = lk === 'green' ? 'rgba(110,240,160,.85)' : 'rgba(255,255,255,.85)';
      ps.forEach(p => {
        p.y += p.v * dt; p.w += dt * 1.4; p.x += Math.sin(p.w) * 14 * dt;
        if (p.y > H + 6) reset(p, false);
        g.beginPath();
        if (lk === 'green') g.rect(p.x, p.y, p.s * 1.6, p.s * 1.6); else g.arc(p.x, p.y, p.s, 0, 6.283);
        g.fill();
      });
    } else {
      const gr = lk === 'green';
      g.lineCap = 'butt';
      g.strokeStyle = gr ? 'rgba(74,222,128,.75)' : 'rgba(190,215,255,.55)'; g.lineWidth = gr ? 1.6 : 1.3;
      g.beginPath();
      ps.forEach(p => {
        p.y += p.v * dt; if (!gr) p.x -= p.v * dt * 0.12;
        if (p.y > H + 24) reset(p, false);
        const x = gr ? Math.round(p.x) : p.x;           // ترمینال: خط کاملاً عمودی، صاف و بدون سر گرد
        g.moveTo(x, p.y); g.lineTo(gr ? x : x - p.s * 0.12, p.y - p.s * (gr ? 2 : 1));
      });
      g.stroke();
    }
  }
  nimbo.onView(function (id, view) {
    if (id === 'home') { const sc = view.querySelector('.scene'); if (sc) mount(sc); }
    sync();
  });
  document.addEventListener('visibilitychange', sync);
  window.addEventListener('nimbo-overlay', sync);
  sync();
  return function () { cancelAnimationFrame(raf); raf = 0; document.removeEventListener('visibilitychange', sync); window.removeEventListener('nimbo-overlay', sync); if (cv) cv.remove(); };
};
const TINT_JS = function (nimbo) {
  const ov = document.createElement('div');
  ov.id = 'tintov';
  document.body.appendChild(ov);
  function paint() {
    const d = new Date(), h = d.getHours() + d.getMinutes() / 60;
    let c;
    if (h < 5) c = 'rgba(255,120,40,.16)';            // شب: فیلتر گرم، کم‌کردن نور آبی
    else if (h < 7.5) c = 'rgba(255,150,170,.11)';    // طلوع
    else if (h < 16) c = 'rgba(0,0,0,0)';             // روز بدون تغییر
    else if (h < 18) c = 'rgba(255,200,90,.09)';      // عصر
    else if (h < 19.5) c = 'rgba(255,110,50,.14)';    // غروب
    else c = 'rgba(255,120,40,.15)';                  // شب
    ov.style.background = c;
  }
  paint();
  const iv = setInterval(paint, 60000);
  return function () { clearInterval(iv); ov.remove(); };
};
const CVD_SHARED = `/* ===== رنگ‌کور: کدگذاری دوگانه (رنگ + شکل) ===== */
.item{ border-inline-start-width:5px !important; }
.item.p0{ border-inline-start-width:3px !important; }
.item.p2{ border-inline-start-width:9px !important; }
.item.p0 .ttl::before{ content:"▽ "; opacity:.75; font-size:.8em; }
.item.p1 .ttl::before{ content:"◆ "; opacity:.85; font-size:.8em; }
.item.p2 .ttl::before{ content:"▲ "; font-size:.8em; font-weight:800; }
.item.late{ background-image:repeating-linear-gradient(135deg, rgba(128,128,128,.14) 0, rgba(128,128,128,.14) 6px, transparent 6px, transparent 12px) !important; }
.item.late .sub::before, .cloud.late .c-s::before{ content:"⚠ "; }
.item.late .sub{ font-weight:700; }
.item.done .ttl{ text-decoration:line-through; opacity:.7; }
.chk.on,.item.done .chk{ background:var(--ok) !important; border-color:var(--ok) !important; }
.bar i{ background-image:repeating-linear-gradient(135deg, rgba(255,255,255,.35) 0, rgba(255,255,255,.35) 4px, transparent 4px, transparent 8px), linear-gradient(90deg, var(--acc2), var(--acc)) !important; }
.puff .tint{ fill:var(--bad) !important; }
.cloud.late .puff .tint{ opacity:.4 !important; }
.rh.full{ background:var(--ok) !important; }
.inp:focus,.ned-title:focus,.ned-text:focus,.btn:focus-visible,.chip:focus-visible{ outline:3px solid var(--acc) !important; outline-offset:2px; }
.chip.on,.tab.on,.seg button.on{ box-shadow:inset 0 -3px 0 rgba(0,0,0,.35); font-weight:800; }
.switch.on::after{ content:"✓"; color:#fff; font-size:13px; font-weight:800; position:absolute; inset-inline-end:7px; top:50%; transform:translateY(-50%); }
.sub-row b.bad{ text-decoration:underline wavy; }
`;
const CALM_JS = function (nimbo) {
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const pad = n => (n < 10 ? '0' : '') + n;
  const key = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  nimbo.onView(function (id, view) {
    if (id !== 'home') return;
    const sc = view.querySelector('.scene');
    if (!sc || sc.querySelector('.cm')) return;
    const S = nimbo.S, now = Date.now(), d = new Date(), today = key(d), fa = nimbo.lang() !== 'en';
    const nf = n => Number(n).toLocaleString(fa ? 'fa-IR' : 'en-US');
    const hr = d.getHours();
    const greet = fa ? (hr < 5 ? 'شب بخیر' : hr < 12 ? 'صبح بخیر' : hr < 17 ? 'ظهر بخیر' : hr < 20 ? 'عصر بخیر' : 'شب بخیر')
                     : (hr < 5 ? 'Good night' : hr < 12 ? 'Good morning' : hr < 17 ? 'Good afternoon' : hr < 20 ? 'Good evening' : 'Good night');
    const open = S.tasks.filter(x => !x.done).sort((a, b) => (a.due || 9e15) - (b.due || 9e15));
    const late = open.filter(x => x.due && x.due < now).length;
    const dueToday = open.filter(x => x.due && key(new Date(x.due)) === today || (x.due && x.due < now));
    const doneToday = S.log.filter(e => e.k === 't' && e.d === today).length;
    const total = doneToday + dueToday.length, pct = total ? Math.round(doneToday / total * 100) : 0;
    const habs = S.habits.filter(h => (!h.wd || !h.wd.length || h.wd.indexOf(d.getDay()) > -1));
    const habDone = habs.filter(h => h.days.indexOf(today) > -1).length;
    const pomo = S.log.filter(e => e.k === 'p' && e.d === today).length;
    const C = 2 * Math.PI * 44;
    let h = '<div class="cm-head"><div><div class="cm-greet">' + greet + '</div><div class="cm-date">' +
      d.toLocaleDateString(fa ? 'fa-IR' : 'en-US', { weekday: 'long', day: 'numeric', month: 'long' }) + '</div></div>' +
      '<div class="cm-ring"><svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="44" class="cm-bg"/><circle cx="50" cy="50" r="44" class="cm-fg" stroke-dasharray="' + C.toFixed(1) + '" stroke-dashoffset="' + (C * (1 - pct / 100)).toFixed(1) + '"/></svg>' +
      '<b>' + (total ? nf(pct) + '٪' : '—') + '</b></div></div>';
    h += '<div class="cm-stats"><div><b class="' + (late ? 'bad' : '') + '">' + nf(late) + '</b><span>' + (fa ? 'عقب‌افتاده' : 'Overdue') + '</span></div>' +
      '<div><b>' + nf(doneToday) + '</b><span>' + (fa ? 'انجام‌شده' : 'Done') + '</span></div>' +
      '<div><b>' + nf(habDone) + '/' + nf(habs.length) + '</b><span>' + (fa ? 'عادت‌ها' : 'Habits') + '</span></div>' +
      '<div><b>' + nf(pomo) + '</b><span>' + (fa ? 'تمرکز' : 'Focus') + '</span></div></div>';
    if (open.length) {
      h += '<div class="cm-sec">' + (fa ? 'پیش رو' : 'Up next') + '</div>';
      open.slice(0, 8).forEach(x => {
        const isLate = x.due && x.due < now;
        h += '<div class="item p' + (x.pri == null ? 1 : x.pri) + (isLate ? ' late' : '') + '" data-open="tasks:' + esc(x.id) + '"><button class="chk" type="button" data-act="t-toggle" data-id="' + esc(x.id) + '"></button>' +
          '<div class="grow"><div class="ttl">' + esc(x.title) + '</div>' + (x.due ? '<div class="sub">' + new Date(x.due).toLocaleString(fa ? 'fa-IR' : 'en-US', { weekday: 'short', hour: '2-digit', minute: '2-digit' }) + '</div>' : '') + '</div></div>';
      });
    }
    if (habs.length) {
      h += '<div class="cm-sec">' + (fa ? 'عادت‌های امروز' : 'Habits today') + '</div><div class="cm-habs">';
      habs.forEach(x => {
        const on = x.days.indexOf(today) > -1;
        h += '<button class="cm-hab' + (on ? ' on' : '') + '" type="button" data-act="h-toggle" data-id="' + esc(x.id) + '">' + (on ? '✔ ' : '') + esc(x.name) + '</button>';
      });
      h += '</div>';
    }
    if (!open.length && !habs.length) h += '<div class="empty">' + (fa ? 'همه‌چیز انجام شده ✨' : 'All done ✨') + '</div>';
    const box = document.createElement('div');
    box.className = 'cm';
    box.innerHTML = h + '<div style="height:70px"></div>';
    sc.appendChild(box);
    const add = document.createElement('button');
    add.className = 'cm-add'; add.type = 'button'; add.setAttribute('data-act', 'quick'); add.textContent = '+';
    sc.appendChild(add);
  });
};
const GAME_JS = function (nimbo) {
  const LS = 'nimbo_game_v1';
  const fa = () => nimbo.lang() !== 'en';
  const nf = n => Number(n).toLocaleString(fa() ? 'fa-IR' : 'en-US');
  const pad = n => (n < 10 ? '0' : '') + n;
  const key = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  const RANKS = {
    fa: ['تازه‌کار', 'جوینده', 'کوشا', 'پیگیر', 'ماهر', 'حرفه‌ای', 'استاد', 'قهرمان', 'اسطوره', 'افسانه'],
    en: ['Rookie', 'Seeker', 'Diligent', 'Steady', 'Skilled', 'Pro', 'Master', 'Champion', 'Mythic', 'Legend']
  };
  let G = { bonus: 0, claimed: {}, ach: {}, lv: 1 };
  const firstRun = !localStorage.getItem(LS);
  try { const r = JSON.parse(localStorage.getItem(LS)); if (r && typeof r === 'object') G = Object.assign(G, r); } catch (e) {}
  const store = () => { try { localStorage.setItem(LS, JSON.stringify(G)); } catch (e) {} };
  const xpFor = l => 50 * l * (l - 1);                 // XP لازم برای رسیدن به سطح l
  function stats() {
    const S = nimbo.S, c = { t: 0, h: 0, p: 0, m: 0 }, days = {};
    S.log.forEach(e => { if (c[e.k] !== undefined) c[e.k]++; if (e.k !== 'm') days[e.d] = 1; });
    let streak = 0; const d = new Date();
    if (!days[key(d)]) d.setDate(d.getDate() - 1);
    while (days[key(d)] && streak < 4000) { streak++; d.setDate(d.getDate() - 1); }
    let best = 0;
    S.habits.forEach(h => {
      const set = {}; h.days.forEach(k => { set[k] = 1; });
      const e = new Date(); if (!set[key(e)]) e.setDate(e.getDate() - 1);
      let n = 0; while (set[key(e)] && n < 4000) { n++; e.setDate(e.getDate() - 1); }
      best = Math.max(best, n);
    });
    const xp = c.t * 10 + c.h * 5 + c.p * 15 + G.bonus;
    let lv = 1; while (xp >= xpFor(lv + 1)) lv++;
    return { c: c, streak: streak, best: best, xp: xp, lv: lv, lo: xpFor(lv), hi: xpFor(lv + 1), pct: Math.round((xp - xpFor(lv)) / (xpFor(lv + 1) - xpFor(lv)) * 100) };
  }
  function quests() {
    const S = nimbo.S, d = new Date(), today = key(d);
    const done = S.log.filter(e => e.k === 't' && e.d === today).length;
    const hs = S.habits.filter(h => (!h.wd || !h.wd.length || h.wd.indexOf(d.getDay()) > -1));
    const hd = hs.filter(h => h.days.indexOf(today) > -1).length;
    const pomo = S.log.filter(e => e.k === 'p' && e.d === today).length;
    const notes = S.notes.filter(n => key(new Date(n.t || 0)) === today).length;
    return [
      { id: 'q1', ic: '✅', fa: 'سه کار را انجام بده', en: 'Finish 3 tasks', v: done, n: 3, xp: 20 },
      hs.length ? { id: 'q2', ic: '🔥', fa: 'همهٔ عادت‌های امروز را ثبت کن', en: 'Log all of today’s habits', v: hd, n: hs.length, xp: 20 }
                : { id: 'q2', ic: '📝', fa: 'یک یادداشت بنویس', en: 'Write a note', v: notes, n: 1, xp: 20 },
      { id: 'q3', ic: '🍅', fa: 'یک جلسهٔ تمرکز کامل کن', en: 'Complete a focus session', v: pomo, n: 1, xp: 25 }
    ];
  }
  const ACH = [
    ['a1', '✅', 'اولین کار', 'First task', s => s.c.t >= 1], ['a2', '✅', '۱۰ کار', '10 tasks', s => s.c.t >= 10],
    ['a3', '✅', '۵۰ کار', '50 tasks', s => s.c.t >= 50], ['a4', '🎯', '۲۰۰ کار', '200 tasks', s => s.c.t >= 200],
    ['a5', '🍅', 'اولین تمرکز', 'First focus', s => s.c.p >= 1], ['a6', '🍅', '۱۰ جلسه تمرکز', '10 focus sessions', s => s.c.p >= 10],
    ['a7', '🔥', 'عادت ۷ روزه', '7-day habit', s => s.best >= 7], ['a8', '🔥', 'عادت ۳۰ روزه', '30-day habit', s => s.best >= 30],
    ['a9', '⚡', '۳ روز پیاپی', '3-day streak', s => s.streak >= 3], ['a10', '⚡', '۷ روز پیاپی', '7-day streak', s => s.streak >= 7],
    ['a11', '⚡', '۳۰ روز پیاپی', '30-day streak', s => s.streak >= 30], ['a12', '💰', '۱۰ هزینه ثبت‌شده', '10 expenses logged', s => s.c.m >= 10],
    ['a13', '🎉', 'سطح ۵', 'Level 5', s => s.lv >= 5], ['a14', '🎉', 'سطح ۱۰', 'Level 10', s => s.lv >= 10]
  ];
  const top = document.querySelector('.top');
  const chip = document.createElement('button');
  chip.type = 'button'; chip.className = 'gm-chip';
  const bar = document.createElement('div'); bar.className = 'xpbar'; bar.innerHTML = '<i></i>';
  top.insertBefore(chip, top.querySelector('.tools')); top.appendChild(bar);
  const ring = (pct, r, sw) => { const C = 2 * Math.PI * r; return '<circle cx="50" cy="50" r="' + r + '" class="gm-bg" stroke-width="' + sw + '"/><circle cx="50" cy="50" r="' + r + '" class="gm-fg" stroke-width="' + sw + '" stroke-dasharray="' + C.toFixed(1) + '" stroke-dashoffset="' + (C * (1 - pct / 100)).toFixed(1) + '"/>'; };
  function award(msg, xp) { G.bonus += xp; store(); nimbo.toast(msg + '  +' + nf(xp)); }
  function evaluate() {
    const today = key(new Date());
    G.claimed[today] = G.claimed[today] || {};
    let s = stats();
    quests().forEach(q => {
      if (q.v >= q.n && !G.claimed[today][q.id]) { G.claimed[today][q.id] = 1; award('🎯 ' + (fa() ? q.fa : q.en), q.xp); }
    });
    if (G.claimed[today].q1 && G.claimed[today].q2 && G.claimed[today].q3 && !G.claimed[today].all) { G.claimed[today].all = 1; award(fa() ? '🎉 همهٔ مأموریت‌های امروز' : '🎉 All daily quests', 30); }
    s = stats();
    ACH.forEach(a => { if (!G.ach[a[0]] && a[4](s)) { G.ach[a[0]] = Date.now(); award('🏅 ' + (fa() ? a[2] : a[3]), 25); s = stats(); } });
    return s;
  }
  function confetti(host) {
    const cols = ['#f59e0b', '#22c55e', '#38bdf8', '#ec4899', '#a78bfa', '#ef4444'];
    for (let i = 0; i < 30; i++) {
      const sp = document.createElement('i');
      sp.style.cssText = 'left:' + (Math.random() * 100) + '%;background:' + cols[i % cols.length] + ';animation-delay:' + (Math.random() * 0.5) + 's;--dx:' + (Math.random() * 120 - 60) + 'px;--r:' + (Math.random() * 720 - 360) + 'deg';
      host.appendChild(sp);
    }
  }
  function levelUp(lv) {
    const ov = document.createElement('div');
    ov.className = 'gm-ov up';
    const rk = RANKS[fa() ? 'fa' : 'en'][Math.min(9, Math.floor((lv - 1) / 2))];
    ov.innerHTML = '<div class="gm-cf"></div><div class="gm-card up"><div class="gm-big">' + nf(lv) + '</div><div class="gm-t">' + (fa() ? 'سطح جدید!' : 'Level up!') + '</div><div class="gm-s">' + rk + '</div></div>';
    document.body.appendChild(ov);
    confetti(ov.firstChild);
    const close = () => { ov.remove(); };
    ov.addEventListener('click', close);
    setTimeout(close, 3600);
  }
  function profile() {
    const s = stats(), today = key(new Date()), cl = G.claimed[today] || {};
    const rk = RANKS[fa() ? 'fa' : 'en'][Math.min(9, Math.floor((s.lv - 1) / 2))];
    const ov = document.createElement('div');
    ov.className = 'gm-ov';
    let h = '<div class="gm-card"><div class="gm-top"><svg viewBox="0 0 100 100" class="gm-r">' + ring(s.pct, 44, 8) + '</svg><div class="gm-lv"><small>' + (fa() ? 'سطح' : 'Level') + '</small><b>' + nf(s.lv) + '</b></div></div>' +
      '<div class="gm-rank">' + rk + '</div><div class="gm-xp">' + nf(s.xp) + ' / ' + nf(s.hi) + ' ' + (fa() ? 'امتیاز' : 'XP') + '</div>' +
      '<div class="gm-pb"><i style="width:' + s.pct + '%"></i></div>' +
      '<div class="gm-row"><div><b>🔥 ' + nf(s.streak) + '</b><span>' + (fa() ? 'روز پیاپی' : 'day streak') + '</span></div><div><b>✅ ' + nf(s.c.t) + '</b><span>' + (fa() ? 'کار' : 'tasks') + '</span></div><div><b>🍅 ' + nf(s.c.p) + '</b><span>' + (fa() ? 'تمرکز' : 'focus') + '</span></div></div>' +
      '<div class="gm-h">' + (fa() ? 'مأموریت‌های امروز' : 'Daily quests') + '</div>';
    quests().forEach(q => {
      const p = Math.min(100, Math.round(q.v / q.n * 100));
      h += '<div class="gm-q' + (cl[q.id] ? ' ok' : '') + '"><span class="gm-qi">' + q.ic + '</span><div class="gm-qt"><b>' + (fa() ? q.fa : q.en) + '</b><div class="gm-pb sm"><i style="width:' + p + '%"></i></div></div><em>' + (cl[q.id] ? '✔' : '+' + nf(q.xp)) + '</em></div>';
    });
    h += '<div class="gm-h">' + (fa() ? 'نشان‌ها' : 'Badges') + ' · ' + nf(Object.keys(G.ach).length) + '/' + nf(ACH.length) + '</div><div class="gm-ach">';
    ACH.forEach(a => { h += '<div class="gm-a' + (G.ach[a[0]] ? ' on' : '') + '"><span>' + a[1] + '</span><small>' + (fa() ? a[2] : a[3]) + '</small></div>'; });
    h += '</div><button class="gm-x" type="button">' + (fa() ? 'بستن' : 'Close') + '</button></div>';
    ov.innerHTML = h;
    document.body.appendChild(ov);
    ov.addEventListener('click', e => { if (e.target === ov || e.target.closest('.gm-x')) ov.remove(); });
  }
  chip.addEventListener('click', profile);
  function paint() {
    const s = evaluate();
    chip.innerHTML = '<svg viewBox="0 0 100 100">' + ring(s.pct, 42, 12) + '</svg><b>' + nf(s.lv) + '</b>';
    chip.setAttribute('aria-label', (fa() ? 'سطح ' : 'Level ') + s.lv);
    bar.firstChild.style.width = s.pct + '%';
    if (s.lv > G.lv) { G.lv = s.lv; store(); levelUp(s.lv); } else if (s.lv < G.lv) { G.lv = s.lv; store(); }
  }
  if (firstRun) {                         // بار اول: دستاوردهای قبلی بی‌سروصدا ثبت می‌شوند، نه جشن و پاداش
    const s0 = stats(), today0 = key(new Date());
    G.lv = s0.lv; G.claimed[today0] = G.claimed[today0] || {};
    ACH.forEach(a => { if (a[4](s0)) G.ach[a[0]] = Date.now(); });
    quests().forEach(q => { if (q.v >= q.n) G.claimed[today0][q.id] = 1; });
    store();
  }
  nimbo.onView(function () { paint(); });
  return function () { chip.remove(); bar.remove(); document.querySelectorAll('.gm-ov').forEach(e => e.remove()); };
};
const PXL_JS = function (nimbo) {
// دادهٔ اسپرایت‌ها: هر سطر یک ردیف پیکسل؛ حروف = رنگ در PAL
  const PAL = { k:'#1a1428', w:'#ffffff', l:'#d9dee8', e:'#9aa3b2', E:'#5b6577', s:'#f2c8a0', S:'#c98f66', r:'#d6334a', R:'#8e1b30', b:'#3b6fd8', B:'#233f8f', y:'#f5c542', Y:'#b8861b', g:'#4fae4f', G:'#2d6a35', n:'#7a4a2a', N:'#4a2b17', p:'#8a4fd0', P:'#52308a', o:'#f08a24', c:'#47d4e0', C:'#1f8f9c', d:'#2e2a40', m:'#e68fb5' };
const SPR = {
  knight: [
    '....rr....',
    '...rrrr...',
    '..kkkkkk..',
    '.keeeeeek.',
    '.kekkkkek.',
    '.keeeeeek.',
    '..keeeek..',
    '.kkbbbbkk.',
    'kebbwwbbek',
    'ksbbwwbbsk',
    'ksbbbbbbsk',
    '.kbbbbbbk.',
    '.kbbkkbbk.',
    '.kEEkkEEk.',
    '.kEEkkEEk.',
    '.kkkk.kkkk'.slice(0,10)
  ],
  ninja: [
    '..kkkkkk..',
    '.kddddddk.',
    '.kddddddk.',
    '.kssssssk.',
    '.kswkksws.'.slice(0,10),
    '.kddddddk.',
    '..kkrrkk..',
    '.kddrrddk.',
    'kdddddddrk',
    'kdddddddrr',
    'sdddkkdddk',
    '.kddkkddk.',
    '.kddkkddk.',
    '.kddk.kdk.',
    '.kdk...kdk',
    '.kk.....kk'
  ],
  archer: [
    '...gggg.....',
    '..gGGGGg....',
    '.gGsssSGg.n.',
    '.gGskskGg.nk',
    '.gGsssSGg.n.k'.slice(0,12),
    '..gGGGGg..n.',
    '...gggg...n.',
    '..gGGGGGg.n.',
    '.gGgyyggGgn.',
    'sGgggggggGn.',
    '.kgggggggkn.',
    '..gGggGGg.n.',
    '..gGg.gGg.n.',
    '..gnn.nng.k.',
    '..nnk.knn...',
    '..kk...kk...'
  ],
  zombie: [
    '..kkkkkk..',
    '.kggggggk.',
    '.kgrkgkrk.',
    '.kggggggk.',
    '.kgkRRkgk.',
    '..kggggk..',
    '.kkbbbbkk.',
    'kgkbbbbkgk',
    'kgkbRbbkgk',
    'kgkbbbbkgk',
    'kk.bbbbb.kk'.slice(0,10),
    '..kbbbbk..',
    '..kbkkbk..',
    '..kBkkBk..',
    '.kBBk.kBBk',
    '.kkk...kkk'
  ],
  golem: [
    '..kkkkkkkk..',
    '.keeeeeeeek.',
    '.keEEeeEEek.',
    '.kecceecceek'.slice(0,12),
    '.keeeeeeeek.',
    '..kkeEEekk..',
    'kkeeeeeeeekk',
    'keEeeeeeeEek',
    'keEeekkeeEek',
    'keEeeEEeeEek',
    'kkEeeeeeeEkk',
    '.keeeeeeeek.',
    '..keeeeeek..',
    '..keEkkEek..',
    '.keeEk.kEeek'.slice(0,12),
    '.kkkkk.kkkkk'.slice(0,12)
  ],
  dragon: [
    '.......kk.k...',
    '......koGkoGk.',
    '.....kGGGGGGk.',
    '....kGgwGgwGk.',
    '....kGgkGgkGk.',
    '.kk.kGggggGk..',
    'koPkkGgrrgGkk.',
    'kPPPkgggggGkPk',
    'kPPPPkgggGkPPk',
    '.kPPPPgyyggPk.',
    '..kkPgggyygk..',
    '....kggyyggk..',
    '.....kgggkk...',
    '....kgkkgk....',
    '...kgk..kgk...',
    '...kk....kk...'
  ],
  sword: [
    '..........kk',
    '.........kwlk',
    '........kwlek',
    '.......kwlek.',
    '......kwlek..',
    '.....kwlek...',
    '.k..kwlek....',
    '.kykwlek.....',
    '..kyyek......',
    '...kyyk......',
    '..knYyk......',
    '.knNk.kyk....',
    'knNk..........',
    'kNk...........',
    'kk............'
  ].map(r => r.slice(0, 13)),
  shield: [
    '..kkkkkkkkkk..',
    '.kbbbbbbbbbbk.',
    'kbbbbbwwbbbbbk',
    'kbbbbbwwbbbbbk',
    'kbrrrrrrrrrrbk',
    'kbrrrrwwrrrrbk',
    'kbwwwwwwwwwwbk',
    'kbrrrrwwrrrrbk',
    'kbbrrrrrrrrbbk',
    '.kbbbbwwbbbbk.',
    '.kbbbbwwbbbbk.',
    '..kbbbbbbbbk..',
    '...kBbbbbBk...',
    '....kBBBBk....',
    '.....kkkk.....'
  ],
  boots: [
    '..kkkk......',
    '.knnnnk.....',
    '.knnnnk.....',
    '.knNNnk.....',
    '.knnnnk.....',
    '.knnnnkkkk..',
    '.knnnnnnnnk.',
    '.knnnnnnnnnk',
    'knnnnnnnnnnk',
    'kyyyyyyyyyyk',
    'kkkkkkkkkkk.',
    '.w.w..w.w.w.',
    '..w.w...w...',
    '.w..w.w..w..'
  ],
  fireball: [
    '......y.......',
    '.....yoy..y...',
    '....yooy.yo...',
    '...yooooyoo...',
    '..yoorrooooy..',
    '.yorrrrrroooy.',
    '.yorrwwwrrooy.',
    'yoorrwyywrroyy'.slice(0,14),
    'yorrrwyywrrooy',
    '.yorrrwwrrroy.',
    '.yoorrrrrroy..',
    '..yoorrrroy...',
    '...yoooooy....',
    '....yyoyy.....',
    '.....yyy......'
  ],
  heal: [
    '....kkkkkk....',
    '...kwwwwwwk...',
    '..kwwggggwwk..',
    '.kwwwgggggwwk.',
    '.kwgggwwgggwk.',
    'kwwgggwwgggwwk',
    'kwwwwwwwwwwwwk'.replace(/w{12}/, 'wwggwwwwggww').slice(0,14),
    'kwwwwwwwwwwwwk',
    'kwwgggwwgggwwk',
    '.kwgggwwgggwk.',
    '.kwwwgggggwwk.',
    '..kwwggggwwk..',
    '...kwwwwwwk...',
    '....kkkkkk....'
  ],
  lightning: [
    '......kkkk....',
    '.....kyyyyk...',
    '....kyywwyk...',
    '...kyywwyk....',
    '..kyywwyyk....',
    '..kyywwwwwyk..',
    '...kkyywwyyk..',
    '.....kywwyk...',
    '.....kyywk....',
    '....kyywk.....',
    '....kywk......',
    '...kyyk.......',
    '...kyk........',
    '..kyk.........',
    '..kk..........'
  ],
  gen: [
    '....kkkk....',
    '...kccccck..'.slice(0,12),
    '..kcwccccck.'.slice(0,12),
    '..kccccCcck.',
    '..kcccCCcck.',
    '...kcCCCck..',
    '...kkkkkkk..',
    '..kEEEEEEEk.',
    '.kEeeeeeeeEk',
    '.kEekkkkkeEk',
    '.kEek.c.keEk'.slice(0,12),
    '.kEekkkkkeEk',
    '.kEeeeeeeeEk',
    '.kEEEEEEEEEk',
    '.kkkkkkkkkkk'.slice(0,12)
  ],
  totem: [
    '..kkkkkkkk..',
    '.kyyyyyyyyk.',
    '.kyokkkkoyk.',
    '.kyokrrkoyk.',
    '.kyyyyyyyyk.',
    '..kPPPPPPk..',
    '.kpPwkkwPpk.',
    '.kpPPPPPPpk.',
    '.kpPkrrkPpk.',
    '.kpPPPPPPpk.',
    '..kyyyyyyk..',
    '.kypPPPPpyk.',
    '.kypPwwPpyk.',
    '.kypPPPPpyk.',
    '.kkkkkkkkkk.'
  ],
  chest: [
    '..kkkkkkkkkk..',
    '.knnnnnnnnnnk.',
    'knNnnnnnnnnNnk',
    'knnnnnyynnnnnk',
    'kyyyyyyyyyyyyk',
    'kkkkkkyykkkkkk',
    'knnnnnkkknnnnk'.slice(0,14),
    'knNnnnykynnNnk'.slice(0,14),
    'knnnnnnnnnnnnk',
    'knnnnnnnnnnnnk',
    'knNnnnnnnnNnnk'.slice(0,14),
    'kyyyyyyyyyyyyk',
    '.kkkkkkkkkkkk.'
  ]
};
// آیکون‌های کوچک
const ICO = {
  heart: ['.rr.rr.', 'rwrrrrr', 'rrrrrrr', '.rrrrr.', '..rrr..', '...r...'],
  atk:   ['....ww.', '...wll.', '..wll..', 'k.wl...', '.kk....', 'kyk....'].map(r=>r),
  def:   ['bbbbbbb', 'bwbbbbb', 'bwbbbbb', 'bbbbbbb', '.bbbbb.', '..bbb..', '...b...'],
  drop:  ['...c...', '..ccc..', '.ccwcc.', '.cwcccc', '.ccccc.', '..ccc..'],
  spd:   ['..yyy..', '.yyy...', 'yyyyyy.', '...yyy.', '..yyy..', '.yy....'],
  coin:  ['.yyyy.', 'ywyyYy', 'yyyyYy', 'yyyyYy', 'yyyYYy', '.yYYy.'],
  star:  ['...y...', '...y...', 'yyyyyyy', '.yyyyy.', '..yyy..', '.yy.yy.', '.y...y.']
};
// آیکون‌های منوی اصلی (۱۲×۱۲)
const HUB = {
  battle: ['kk........kk', 'kwk......kwk', '.kwk....kwk.', '..kwk..kwk..', '...kwkkwk...', '....kwwk....', '....kwwk....', '...kykkyk...', '..kykkkkyk..', '.kyk....kyk.', 'kyk......kyk', 'kk........kk'],
  collection: ['..kkkkkk....', '.kbbbbbbk...', '.kbwwwwbk.kk', '.kbwkkwbkkrk', '.kbwwwwbkrrk', '.kbbbbbbkrrk', '.kbbbbbbkrrk', '.kbbbbbbkkkk', '..kkkkkk....'],
  missions: ['.kkkkkkkkk..', 'kwwwwwwwwwk.', 'kwkkkkkkwwk.', 'kwwwwwwwwwk.', 'kwkkkkkwwwk.', 'kwwwwwwwwwk.', 'kwkkkkkkwwk.', 'kwwwwwwwwwk.', '.kkkkkkkkkk.'],
  shop: ['..kkkkkk....', '.knnnnnnk...', 'knnnnnnnnk..', 'knNnnnnNnk..', 'knnnyynnnk..', 'knnyyyynnk..', 'knnnyynnnk..', 'knNnnnnNnk..', '.kkkkkkkkk..'],
  deck: ['...kkkkkkk..', '..kbbbbbbk..', '.kbwbbbbbk..', '.kbbbbbbk.k.', '.kbbwwbbkk..', '.kbbbbbbk...', '.kbbbbbbk...', '..kkkkkkk...'],
  progress: ['..yyyyyyyy..', '.kyywwwwyyk.', 'kkyywwwwyykk', 'k.kyyyyyyk.k', '.k.kyyyyk.k.', '...kyyyyk...', '....kyyk....', '....kyyk....', '...kyyyyk...', '..kyyyyyyk..']
};

  const LS = 'nimbo_cf_v1';
  const B = document.body;
  const fa = () => false; /* همهٔ متن‌های بازی انگلیسی است */
  const nf = n => Number(n).toLocaleString(fa() ? 'fa-IR' : 'en-US');
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  /* ---------- تنظیمات مرکزی (قابل‌تغییر برای تعادل بازی) ---------- */
  /* (CFG در cf_state.js) */

  const TYPES = ['character', 'creature', 'equipment', 'spell', 'support'];
  const RARITIES = ['common', 'rare', 'epic', 'legendary'];
  const TXT = {
    fa: {
      title: 'میدان کارت پیکسلی', hub: 'خانه', coins: 'سکه', close: 'بستن', soon: 'به‌زودی',
      battle: 'نبرد', collection: 'مجموعه', missions: 'مأموریت‌ها', shop: 'فروشگاه', deck: 'دسته', progress: 'پیشرفت',
      battleD: 'روی زمین ۶×۴ بجنگ', collectionD: 'همهٔ کارت‌هایت', missionsD: 'چالش و پاداش', shopD: 'کارت و تجهیزات', deckD: 'دستهٔ خودت را بساز', progressD: 'آمار و دستاوردها',
      character: 'شخصیت', creature: 'موجود', equipment: 'تجهیزات', spell: 'جادو', support: 'پشتیبان',
      common: 'معمولی', rare: 'کمیاب', epic: 'حماسی', legendary: 'افسانه‌ای',
      all: 'همه', search: 'جست‌وجوی نام کارت…', owned: 'مالکیت', of: 'از', locked: 'قفل', copies: 'نسخه',
      hp: 'جان', atk: 'حمله', def: 'دفاع', cost: 'اکسیر', spd: 'سرعت', move: 'حرکت', range: 'محدودهٔ حمله', how: 'روش دریافت', special: 'ویژگی',
      tapFlip: 'برای چرخاندن کارت لمس کن', flipBtn: 'چرخاندن', starter: 'کارت شروع', shopHow: 'فروشگاه', missionHow: 'مأموریت', rareHow: 'دستاورد ویژه',
      prog1: 'کارت‌های جمع‌شده', prog2: 'کارت‌های متفاوت', prog3: 'کارت‌های تکراری', prog4: 'نبرد / برد', empty: 'کارتی پیدا نشد',
      legend: 'راهنما', mvLegend: 'حرکت', atLegend: 'حمله', theme: 'پوسته', skBase: 'پایه', skInk: 'کاغذ و جوهر', skTerm: 'ترمینال', skDark: 'شب‌بیدار', skGlass: 'شیشه‌ای',
      hubHint: 'کارت‌ها را بچرخان و جمع کن؛ میدان نبرد آمادهٔ آزمایش است و قوانین بعداً می‌آیند.', front: 'روی کارت', back: 'پشت کارت',
      btRound: 'دور', btEnd: 'پایان نوبت', btWait: 'در جنگ…', btFight: 'نبرد!', btHint: 'یک کارت از دستت انتخاب کن', btNoMana: 'اکسیر کافی نیست', btMine: 'فقط نیمهٔ پایین مال توست', btTarget: 'روی خانهٔ روشن بزن', btNoActs: 'استقرار این نوبت تمام شد', dailyOk: 'پاداش روزانه: ۲۵ سکه', dailyDone: 'پاداش امروز را گرفته‌ای'
    },
    en: {
      title: 'Pixel Card Arena', hub: 'Home', coins: 'Coins', close: 'Close', soon: 'Soon',
      battle: 'Battle', collection: 'Collection', missions: 'Missions', shop: 'Shop', deck: 'Deck', progress: 'Progress',
      battleD: 'Fight on the 6×4 board', collectionD: 'All your cards', missionsD: 'Challenges & rewards', shopD: 'Cards & gear', deckD: 'Build your deck', progressD: 'Stats & achievements',
      character: 'Character', creature: 'Creature', equipment: 'Equipment', spell: 'Spell', support: 'Support',
      common: 'Common', rare: 'Rare', epic: 'Epic', legendary: 'Legendary',
      all: 'All', search: 'Search card name…', owned: 'Owned', of: 'of', locked: 'Locked', copies: 'copies',
      hp: 'HP', atk: 'ATK', def: 'DEF', cost: 'Elixir', spd: 'Speed', move: 'Move', range: 'Attack range', how: 'How to get', special: 'Ability',
      tapFlip: 'Tap the card to flip it', flipBtn: 'Flip', starter: 'Starter card', shopHow: 'Shop', missionHow: 'Missions', rareHow: 'Special achievement',
      prog1: 'Cards collected', prog2: 'Unique cards', prog3: 'Duplicates', prog4: 'Battles / wins', empty: 'No cards found',
      legend: 'Legend', mvLegend: 'Move', atLegend: 'Attack', theme: 'Skin', skBase: 'Base', skInk: 'Paper & Ink', skTerm: 'Terminal', skDark: 'Night Owl', skGlass: 'Glass',
      hubHint: 'Flip and collect cards; the battlefield is ready to try, rules come later.', front: 'Front', back: 'Back',
      btRound: 'Round', btEnd: 'End Turn', btWait: 'Fighting…', btFight: 'FIGHT!', btHint: 'Pick a card from your hand', btNoMana: 'Not enough elixir', btMine: 'Only the lower half is yours', btTarget: 'Tap a glowing cell', btNoActs: 'No deployments left this turn', dailyOk: 'Daily reward: 25 coins', dailyDone: 'Already claimed today'
    }
  };
  const T = k => (TXT[fa() ? 'fa' : 'en'][k] || k);
  const L = (o, k) => o[k + (fa() ? 'Fa' : 'En')];

  /* ---------- داده‌های کارت‌ها (جدا از ظاهر) ---------- */
  // pat: alvo حمله و حرکت به‌صورت [dx,dy]؛ dy منفی = جلو. mv: خانه‌های حرکت. jump: پرش از روی دشمن
  const CARDS = [
    { id: 'knight', type: 'character', rar: 'common', cost: 3, hp: 8, atk: 3, def: 2, spd: 2, spr: 'knight', src: 'starter', mv: [[0, -1]], at: [[0, -1]],
      nameFa: 'شوالیه', nameEn: 'Knight', descFa: 'جنگجوی زره‌پوش با حملهٔ مستقیم و دفاع خوب؛ ستون فقرات هر دسته.', descEn: 'An armored fighter with a straight strike and solid defense; the backbone of any deck.', spFa: 'ضربهٔ مستقیم', spEn: 'Straight strike' },
    { id: 'ninja', type: 'character', rar: 'rare', cost: 2, hp: 4, atk: 3, def: 0, spd: 4, spr: 'ninja', src: 'starter', mv: [[0, -2], [-1, -1], [1, -1]], at: [[0, -1]], jump: true,
      nameFa: 'نینجا', nameEn: 'Ninja', descFa: 'سریع و کم‌جان. از روی دشمن می‌پرد و بعد از فرود ضربه می‌زند، اما ضربهٔ سنگین او را می‌اندازد.', descEn: 'Fast and fragile. Leaps over enemies and strikes after landing, but a heavy hit takes it down.', spFa: 'پرش و ضربهٔ پس از فرود', spEn: 'Leap & land strike' },
    { id: 'archer', type: 'character', rar: 'common', cost: 2, hp: 3, atk: 2, def: 0, spd: 3, spr: 'archer', src: 'starter', mv: [[0, -1]], at: [[-1, -2], [1, -2], [0, -2], [0, -3]],
      nameFa: 'کماندار', nameEn: 'Archer', descFa: 'از فاصله و به‌صورت مورب آسیب می‌زند؛ در مبارزهٔ نزدیک ضعیف است و آسیب کمتری وارد می‌کند.', descEn: 'Shoots from range, diagonally too; weak in close combat where it deals less damage.', spFa: 'تیر دوربرد', spEn: 'Ranged shot' },
    { id: 'dragon', type: 'creature', rar: 'epic', cost: 4, hp: 6, atk: 2, def: 1, spd: 3, spr: 'dragon', src: 'starter', mv: [[0, -2], [-1, -1], [1, -1]], at: [[0, -1], [-1, -1], [1, -1], [0, -2]], fly: true,
      nameFa: 'اژدهای کوچک', nameEn: 'Baby Dragon', descFa: 'آتش او چند خانهٔ جلو را می‌گیرد و می‌تواند از بالای کارت‌ها عبور کند.', descEn: 'Its flames cover several cells ahead and it can fly over other cards.', spFa: 'آتش ناحیه‌ای و پرواز', spEn: 'Area flames & flight' },
    { id: 'skeleton', type: 'character', rar: 'epic', cost: 4, hp: 7, atk: 3, def: 2, spd: 2, spr: 'knight', art: 'skeleton', emb: 'zombie', src: 'starter', mv: [[0, -1]], at: [[0, -1]],
      nameFa: 'اسکلت طلایی', nameEn: 'Golden Skeleton', descFa: 'جنگجوی طلایی و سخت‌جان با حملهٔ مستقیم؛ استخوان‌هایش دست‌بردار نیست.', descEn: 'A gilded warrior, tough and relentless, with a straight strike.', spFa: 'ضربهٔ مستقیم', spEn: 'Straight strike' },
    { id: 'mage', type: 'character', rar: 'common', cost: 3, hp: 3, atk: 2, def: 0, spd: 2, spr: 'archer', art: 'mage', emb: 'fireball', src: 'starter', mv: [[0, -1]], at: [[0, -1], [0, -2], [-1, -1], [1, -1]],
      nameFa: 'جادوگر', nameEn: 'Mage', descFa: 'با جادو از فاصله و مورب ضربه می‌زند؛ در نبرد نزدیک شکننده است.', descEn: 'Casts arcane bolts ahead and diagonally; fragile up close.', spFa: 'جادوی دوربرد', spEn: 'Arcane bolt' },
    { id: 'ranger', type: 'character', rar: 'common', cost: 2, hp: 5, atk: 2, def: 1, spd: 2, spr: 'knight', art: 'ranger', emb: 'knight', src: 'starter', mv: [[0, -1]], at: [[0, -1]],
      nameFa: 'شمشیرزن', nameEn: 'Swordsman', descFa: 'شمشیرزن ولگرد با سپر؛ مدافعی ارزان و مطمئن.', descEn: 'A wandering blade with a shield; a cheap, reliable blocker.', spFa: 'ضربهٔ مستقیم', spEn: 'Straight strike' },
    { id: 'hammer', type: 'equipment', rar: 'common', cost: 2, spr: 'sword', art: 'hammer', emb: 'sword', src: 'starter', slot: 'weapon', bonus: { atk: 3 },
      nameFa: 'چکش طوفان', nameEn: 'Storm Hammer', descFa: 'به یک شخصیت یا موجود وصل می‌شود و ۳ واحد به حمله‌اش اضافه می‌کند.', descEn: 'Attach to a character or creature for +3 attack.', spFa: '+۳ حمله', spEn: '+3 attack' },
    { id: 'drake', type: 'character', rar: 'common', cost: 3, hp: 6, atk: 3, def: 1, spd: 2, spr: 'knight', art: 'drake', emb: 'dragon', src: 'starter', mv: [[0, -1]], at: [[0, -1], [-1, -1], [1, -1]],
      nameFa: 'جنگجوی اژدهایی', nameEn: 'Drake Warrior', descFa: 'جنگجوی تبرزن اژدهاتبار؛ با ضربهٔ پهن، مقابل و دو مورب جلو را می‌زند.', descEn: 'An axe-wielding drakeblood; its wide swing hits ahead and both front diagonals.', spFa: 'ضربهٔ پهن', spEn: 'Wide swing' },
    { id: 'bow', type: 'equipment', rar: 'common', cost: 2, spr: 'sword', art: 'bow', emb: 'sword', src: 'starter', slot: 'weapon', bonus: { atk: 1, reach: 1 },
      nameFa: 'کمان طوفانی', nameEn: 'Storm Bow', descFa: 'به یک شخصیت وصل می‌شود: ۱ حمله و ۱ خانه برد بیشتر.', descEn: 'Attach to a unit: +1 attack and +1 range.', spFa: '+۱ حمله، +۱ برد', spEn: '+1 attack, +1 range' },
    { id: 'zombie', type: 'creature', rar: 'common', cost: 1, hp: 3, atk: 1, def: 0, spd: 1, spr: 'knight', art: 'zombie', emb: 'zombie', src: 'starter', mv: [[0, -1]], at: [[0, -1]], fx: { kind: 'rise', hp: 1 },
      nameFa: 'زامبی', nameEn: 'Zombie', descFa: 'ارزان و کند. پس از شکست، یک‌بار با ۱ جان در همان خانه برمی‌گردد (اگر خالی باشد).', descEn: 'Cheap and slow. When defeated it returns once with 1 HP if its cell is free.', spFa: 'بازگشت یک‌باره', spEn: 'Rises once' },
    { id: 'mace', type: 'equipment', rar: 'common', cost: 1, spr: 'sword', art: 'mace', emb: 'sword', src: 'starter', slot: 'weapon', bonus: { atk: 2 },
      nameFa: 'گرز میخ‌دار', nameEn: 'Spiked Club', descFa: 'به یک شخصیت یا موجود وصل می‌شود و ۲ واحد به حمله‌اش اضافه می‌کند.', descEn: 'Attach to a character or creature for +2 attack.', spFa: '+۲ حمله', spEn: '+2 attack' },
    { id: 'dblade', type: 'equipment', rar: 'rare', cost: 2, spr: 'sword', art: 'dblade', emb: 'sword', src: 'starter', slot: 'weapon', bonus: { atk: 3 },
      nameFa: 'تیغهٔ سایه', nameEn: 'Dark Blade', descFa: 'شمشیر جادویی بنفش؛ ۳ واحد به حملهٔ دارنده اضافه می‌کند.', descEn: 'A violet enchanted sword; +3 attack to its bearer.', spFa: '+۳ حمله', spEn: '+3 attack' },
    { id: 'fblade', type: 'equipment', rar: 'epic', cost: 3, spr: 'sword', art: 'fblade', emb: 'sword', src: 'starter', slot: 'weapon', bonus: { atk: 4 },
      nameFa: 'تیغهٔ شعله', nameEn: 'Flame Blade', descFa: 'شمشیر آتشین سنگین؛ ۴ واحد به حملهٔ دارنده اضافه می‌کند.', descEn: 'A blazing sword; +4 attack to its bearer.', spFa: '+۴ حمله', spEn: '+4 attack' },
    { id: 'lantern', type: 'spell', rar: 'common', cost: 1, spr: 'heal', art: 'lantern', emb: 'heal', src: 'starter', fx: { kind: 'heal', amt: 4 }, at: [[0, 0]],
      nameFa: 'فانوس شفا', nameEn: 'Healing Lantern', descFa: '۴ جان به یک کارت خودی برمی‌گرداند، بی‌آنکه از حداکثر جانش بیشتر شود.', descEn: 'Restores 4 HP to an allied card, never above its maximum.', spFa: 'بازیابی جان', spEn: 'Restore HP' },
    { id: 'potion', type: 'spell', rar: 'rare', cost: 2, spr: 'heal', art: 'potion', emb: 'heal', src: 'starter', fx: { kind: 'heal', amt: 8 }, at: [[0, 0]],
      nameFa: 'معجون آبی', nameEn: 'Blue Potion', descFa: '۸ جان به یک کارت خودی برمی‌گرداند، بی‌آنکه از حداکثر جانش بیشتر شود.', descEn: 'Restores 8 HP to an allied card, never above its maximum.', spFa: 'بازیابی جان زیاد', spEn: 'Big restore' },
    { id: 'magma', type: 'creature', rar: 'legendary', cost: 6, hp: 10, atk: 4, def: 2, spd: 3, spr: 'dragon', art: 'magma', emb: 'dragon', src: 'starter', mv: [[0, -2], [-1, -1], [1, -1]], at: [[0, -1], [-1, -1], [1, -1], [0, -2]], fly: true,
      nameFa: 'اژدهای گدازه', nameEn: 'Magma Dragon', descFa: 'اژدهای سیاه و سرخ؛ پرواز می‌کند و آتشش چند خانهٔ جلو را می‌گیرد.', descEn: 'A black-and-crimson dragon that flies and scorches several cells ahead.', spFa: 'آتش ناحیه‌ای و پرواز', spEn: 'Area flames & flight' },
    { id: 'sdrake', type: 'creature', rar: 'legendary', cost: 6, hp: 9, atk: 4, def: 2, spd: 3, spr: 'dragon', art: 'sdrake', emb: 'dragon', src: 'starter', mv: [[0, -2], [-1, -1], [1, -1]], at: [[0, -1], [-1, -1], [1, -1], [0, -2]], fly: true,
      nameFa: 'اژدهای طوفان', nameEn: 'Storm Dragon', descFa: 'اژدهای آبی و طلایی؛ بالای سر کارت‌ها پرواز می‌کند و شعله‌های آبی می‌پاشد.', descEn: 'A blue-and-gold dragon that glides over cards and sprays blue flames.', spFa: 'شعلهٔ آبی و پرواز', spEn: 'Blue flames & flight' },
    { id: 'smage', type: 'character', rar: 'rare', cost: 4, hp: 4, atk: 3, def: 0, spd: 2, spr: 'archer', art: 'smage', emb: 'fireball', src: 'starter', mv: [[0, -1]], at: [[0, -1], [0, -2], [-1, -1], [1, -1]],
      nameFa: 'جادوگر سایه', nameEn: 'Shadow Mage', descFa: 'جادوگر شناور با گوی بنفش؛ از فاصله و مورب ضربه می‌زند.', descEn: 'A floating mage with a violet orb; strikes ahead and diagonally.', spFa: 'گوی جادویی', spEn: 'Arcane orb' },
    { id: 'fireball', type: 'spell', rar: 'common', cost: 2, spr: 'fireball', art: 'fireball', emb: 'fireball', src: 'starter', fx: { kind: 'dmg', amt: 4 }, at: [[0, 0]],
      nameFa: 'گوی آتش', nameEn: 'Fireball', descFa: '۴ آسیب به یک کارت دشمن وارد می‌کند.', descEn: 'Deals 4 damage to one enemy card.', spFa: 'آسیب مستقیم', spEn: 'Direct damage' },
    { id: 'icesh', type: 'spell', rar: 'common', cost: 1, spr: 'fireball', art: 'icesh', emb: 'fireball', src: 'starter', fx: { kind: 'dmg', amt: 3 }, at: [[0, 0]],
      nameFa: 'تیر یخی', nameEn: 'Ice Shard', descFa: '۳ آسیب به یک کارت دشمن وارد می‌کند.', descEn: 'Deals 3 damage to one enemy card.', spFa: 'آسیب مستقیم', spEn: 'Direct damage' },
    { id: 'toxic', type: 'spell', rar: 'common', cost: 3, spr: 'fireball', art: 'toxic', emb: 'fireball', src: 'starter', fx: { kind: 'dmg', amt: 2 }, at: [[0, 0], [0, -1], [0, 1], [-1, 0], [1, 0]],
      nameFa: 'گوی سمی', nameEn: 'Toxic Orb', descFa: '۲ آسیب به یک کارت دشمن و چهار خانهٔ اطرافش می‌زند.', descEn: 'Deals 2 damage to an enemy card and the four cells around it.', spFa: 'آسیب مستقیم', spEn: 'Direct damage' },
    { id: 'bflame', type: 'equipment', rar: 'common', cost: 2, spr: 'sword', art: 'bflame', emb: 'sword', src: 'starter', slot: 'weapon', bonus: { atk: 3 },
      nameFa: 'تیغهٔ یخ‌آتش', nameEn: 'Frost Flame', descFa: 'شمشیر شعله‌های آبی؛ ۳ واحد به حملهٔ دارنده اضافه می‌کند.', descEn: 'A sword wreathed in blue flame; +3 attack to its bearer.', spFa: '+۳ حمله', spEn: '+3 attack' },
    { id: 'claws', type: 'equipment', rar: 'common', cost: 2, spr: 'sword', art: 'claws', emb: 'sword', src: 'starter', slot: 'weapon', bonus: { atk: 2 },
      nameFa: 'پنجه‌های فولادی', nameEn: 'Steel Claws', descFa: 'دستکش‌های پنجه‌دار؛ ۲ واحد به حمله اضافه می‌کنند.', descEn: 'Clawed gauntlets; +2 attack to their bearer.', spFa: '+۲ حمله', spEn: '+2 attack' },
    { id: 'nunchaku', type: 'equipment', rar: 'legendary', cost: 3, spr: 'sword', art: 'nunchaku', emb: 'sword', src: 'starter', slot: 'weapon', bonus: { atk: 4 },
      nameFa: 'نانچیکوی اژدها', nameEn: 'Dragon Nunchaku', descFa: 'نانچیکوی طلایی با نقش اژدها؛ ۴ واحد به حمله اضافه می‌کند.', descEn: 'Golden nunchaku etched with a dragon; +4 attack to its bearer.', spFa: '+۴ حمله', spEn: '+4 attack' },
    { id: 'pencil', type: 'equipment', rar: 'legendary', cost: 3, spr: 'sword', art: 'pencil', emb: 'sword', src: 'starter', slot: 'weapon', bonus: { atk: 5 },
      nameFa: 'مداد خونین', nameEn: 'Bloody Pencil', descFa: 'کوچک اما کشنده؛ ۵ واحد به حمله اضافه می‌کند.', descEn: 'Small but deadly; +5 attack to its bearer.', spFa: '+۵ حمله', spEn: '+5 attack' },
  ];
  const CARD = {}; CARDS.forEach(c => { CARD[c.id] = c; });

  /* (وضعیت ماندگار در cf_state.js) */

  /* ---------- موتور اسپرایت و پوسته ---------- */
  function skin() {
    if (B.classList.contains('mod-paper')) return 'ink';
    if (B.classList.contains('mod-terminal')) return 'term';
    if (B.classList.contains('mod-amoled')) return 'dark';
    if (B.classList.contains('mod-crystal') || B.classList.contains('mod-liquid')) return 'glass';
    return 'base';
  }
  const hex = h => [parseInt(h.substr(1, 2), 16), parseInt(h.substr(3, 2), 16), parseInt(h.substr(5, 2), 16)];
  const toHex = a => '#' + a.map(v => ('0' + Math.max(0, Math.min(255, Math.round(v))).toString(16)).slice(-2)).join('');
  const INK = ['#2b2013', '#5a4630', '#8b7550', '#d8c690'], RUST = ['#4a1d0c', '#8a3412', '#b45309', '#e0b070'], TERM = ['#031a0a', '#0f6b34', '#22c55e', '#bbf7d0'];
  const palCache = {};
  function palFor(sk) {
    if (palCache[sk]) return palCache[sk];
    const out = {};
    Object.keys(PAL).forEach(ch => {
      const c = hex(PAL[ch]), lum = (0.3 * c[0] + 0.59 * c[1] + 0.11 * c[2]) / 255;
      if (sk === 'ink') {
        const red = c[0] > c[1] * 1.5 && c[0] > c[2] * 1.4, ramp = red ? RUST : INK, i = lum < .3 ? 1 : (lum < .55 ? 2 : 3);
        out[ch] = ch === 'k' ? INK[0] : (lum > 0.86 ? '#f6ecc9' : (i === 3 && !red ? '#cdb97c' : ramp[i]));
      } else if (sk === 'term') {
        out[ch] = ch === 'k' ? TERM[0] : TERM[lum < .3 ? 1 : (lum < .68 ? 2 : 3)];
      } else out[ch] = PAL[ch];
    });
    return (palCache[sk] = out);
  }
  function drawRows(cv, rows, sk, flipX) {
    const w = Math.max.apply(null, rows.map(r => r.length)), h = rows.length, N = Math.max(w, h);
    cv.width = N; cv.height = N;
    const x = cv.getContext('2d'), pal = palFor(sk), ox = Math.floor((N - w) / 2), oy = N - h;
    x.clearRect(0, 0, N, N);
    rows.forEach((r, j) => { for (let i = 0; i < r.length; i++) { const ch = r[i]; if (ch !== '.' && pal[ch]) { x.fillStyle = pal[ch]; x.fillRect(ox + i, oy + j, 1, 1); } } });
  }
  function paint(root) {
    const sk = skin();
    root.querySelectorAll('canvas[data-s]').forEach(cv => {
      const src = cv.dataset.s.split(':'), rows = src[0] === 'spr' ? SPR[src[1]] : (src[0] === 'ico' ? ICO[src[1]] : HUB[src[1]]);
      if (rows) drawRows(cv, rows, sk);
    });
    root.querySelectorAll('canvas[data-banner]').forEach(cv => banner(cv, sk));
    root.querySelectorAll('canvas[data-card]').forEach(cv => drawCard(cv, sk));
  }
  const cvs = (key, cls) => '<canvas class="pxs ' + (cls || '') + '" data-s="' + key + '" width="16" height="16"></canvas>';
  // بنر ساده: آسمان، تپه و قلعه (کاملاً با کد)
  function banner(cv, sk) {
    const W = 64, H = 20; cv.width = W; cv.height = H;
    const x = cv.getContext('2d'), pal = palFor(sk);
    const C = { sky1: '#6fb4ff', sky2: '#a8d6ff', hill: '#4fae4f', hill2: '#2d6a35', cas: '#9aa3b2', cas2: '#5b6577', sun: '#f5c542', k: '#1a1428' };
    if (sk === 'ink') { C.sky1 = '#e8d9ae'; C.sky2 = '#efe1b8'; C.hill = '#8b7550'; C.hill2 = '#5a4630'; C.cas = '#cdb97c'; C.cas2 = '#5a4630'; C.sun = '#b45309'; C.k = '#2b2013'; }
    if (sk === 'term') { C.sky1 = '#031a0a'; C.sky2 = '#052a12'; C.hill = '#0f6b34'; C.hill2 = '#0a4a24'; C.cas = '#22c55e'; C.cas2 = '#0f6b34'; C.sun = '#bbf7d0'; C.k = '#031a0a'; }
    if (sk === 'dark') { C.sky1 = '#05060c'; C.sky2 = '#0b0e1c'; C.sun = '#cfd6ff'; }
    for (let j = 0; j < H; j++) { x.fillStyle = j < 9 ? C.sky1 : C.sky2; x.fillRect(0, j, W, 1); }
    x.fillStyle = C.sun; x.fillRect(48, 3, 5, 5); x.fillRect(47, 4, 7, 3); x.fillRect(49, 2, 3, 7);
    for (let i = 0; i < W; i++) { const h = 13 + Math.round(2 * Math.sin(i / 6) + Math.sin(i / 2.7)); x.fillStyle = C.hill; x.fillRect(i, h, 1, H - h); x.fillStyle = C.hill2; x.fillRect(i, H - 3, 1, 3); }
    x.fillStyle = C.cas2; x.fillRect(14, 6, 11, 11); x.fillStyle = C.cas; x.fillRect(15, 7, 9, 10);
    [14, 17, 20, 23].forEach(i => { x.fillStyle = C.cas2; x.fillRect(i, 4, 2, 3); });
    x.fillStyle = C.k; x.fillRect(18, 12, 3, 5); x.fillRect(16, 9, 1, 2); x.fillRect(22, 9, 1, 2);
    x.fillStyle = C.cas2; x.fillRect(30, 9, 7, 8); x.fillStyle = C.cas; x.fillRect(31, 10, 5, 7); [30, 32, 34, 36].forEach(i => { x.fillStyle = C.cas2; x.fillRect(i, 8, 1, 2); });
    x.fillStyle = C.sky2; [[4, 3], [6, 3], [5, 2], [38, 5], [40, 5], [39, 4]].forEach(p => x.fillRect(p[0], p[1], 1, 1));
  }

  /* ---------- نقاش پیکسلی با جزئیات بالا (شبکهٔ ۶۴×۷۲ برای هر شخصیت) ---------- */
  const AW = 64, AH = 72;
  const mixc = (c, t, f) => { const a = hex(c), b = hex(t); return toHex([a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f]); };
  const shade = (c, f) => f >= 0 ? mixc(c, '#ffffff', f) : mixc(c, '#150f26', -f);
  function mkArt() {
    const col = new Array(AW * AH).fill(null); let seed = 11;
    const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
    const inb = (x, y) => x >= 0 && y >= 0 && x < AW && y < AH;
    const M = () => new Uint8Array(AW * AH);
    function paint(mask, c, o) {
      o = o || {}; let y0 = AH, y1 = 0;
      for (let y = 0; y < AH; y++) for (let x = 0; x < AW; x++) if (mask[y * AW + x]) { if (y < y0) y0 = y; if (y > y1) y1 = y; }
      const hg = Math.max(1, y1 - y0), m = (x, y) => inb(x, y) && mask[y * AW + x];
      for (let y = 0; y < AH; y++) for (let x = 0; x < AW; x++) {
        if (!mask[y * AW + x]) continue; let k = c;
        if (o.sh !== false) {
          const br = !m(x + 1, y) || !m(x, y + 1), tl = !m(x - 1, y) || !m(x, y - 1);
          if (br) k = shade(c, -.3); else if (tl) k = shade(c, .24); else if ((y - y0) / hg > .68) k = shade(c, -.11);
          if (o.sep !== false && (br || tl)) {
            [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(d => { const nx = x + d[0], ny = y + d[1]; if (inb(nx, ny) && !m(nx, ny) && col[ny * AW + nx]) k = shade(c, -.55); });
          }
        }
        if (o.n && rnd() < o.n) k = shade(k, -.17);
        if (o.l && rnd() < o.l) k = shade(k, .16);
        if (o.t) { const f = o.t(x, y); if (f) k = shade(k, f); }
        col[y * AW + x] = k;
      }
    }
    const A = {
      rect(x, y, w, h, c, o) { const m = M(); for (let j = y; j < y + h; j++) for (let i = x; i < x + w; i++) if (inb(i, j)) m[j * AW + i] = 1; paint(m, c, o); },
      ell(cx, cy, rx, ry, c, o) { const m = M(); for (let j = 0; j < AH; j++) for (let i = 0; i < AW; i++) { const dx = (i + .5 - cx) / rx, dy = (j + .5 - cy) / ry; if (dx * dx + dy * dy <= 1) m[j * AW + i] = 1; } paint(m, c, o); },
      poly(p, c, o) { const m = M(); for (let j = 0; j < AH; j++) for (let i = 0; i < AW; i++) { let ins = false; const X = i + .5, Y = j + .5; for (let a = 0, b = p.length - 1; a < p.length; b = a++) { if (((p[a][1] > Y) !== (p[b][1] > Y)) && X < (p[b][0] - p[a][0]) * (Y - p[a][1]) / (p[b][1] - p[a][1]) + p[a][0]) ins = !ins; } if (ins) m[j * AW + i] = 1; } paint(m, c, o); },
      line(x0, y0, x1, y1, w, c, o) { const m = M(), dx = x1 - x0, dy = y1 - y0, L = dx * dx + dy * dy || 1; for (let j = 0; j < AH; j++) for (let i = 0; i < AW; i++) { let t = ((i + .5 - x0) * dx + (j + .5 - y0) * dy) / L; t = Math.max(0, Math.min(1, t)); const px = x0 + t * dx, py = y0 + t * dy; if ((i + .5 - px) * (i + .5 - px) + (j + .5 - py) * (j + .5 - py) <= w * w / 4) m[j * AW + i] = 1; } paint(m, c, o); },
      px(x, y, c) { if (inb(x, y)) col[y * AW + x] = c; },
      box(x, y, w, h, c) { for (let j = y; j < y + h; j++) for (let i = x; i < x + w; i++) A.px(i, j, c); },
      done() {
        const out = col.slice();
        for (let y = 0; y < AH; y++) for (let x = 0; x < AW; x++) if (!col[y * AW + x]) {
          let best = null;
          [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(d => { const nx = x + d[0], ny = y + d[1]; if (inb(nx, ny) && col[ny * AW + nx]) best = best || col[ny * AW + nx]; });
          if (best) out[y * AW + x] = shade(best, -.78);
        }
        return out;
      }
    };
    return A;
  }
  const hexcache = {};
  function ART_KNIGHT() {
    const P = {"a": "#95312c", "b": "#c3332f", "c": "#771b24", "d": "#886548", "e": "#39171c", "f": "#ba8550", "g": "#d7b990", "h": "#a9693e", "i": "#c29d71", "j": "#5c4539", "k": "#30292b", "l": "#3f3d41", "m": "#676360", "n": "#87827b", "o": "#1b181d"}, R = ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "........................abbbb...................................", ".......................bbbabbb..................................", "....................cbbbabacbbb.................................", "...................aaaaaaccccba.d...............................", "..................caccabbbceec.fg...............................", "..................cccabacabc..ahgi..............................", "...................caacceeec..jjdd..............................", "...................abccce...kllldfl.............................", "..................ebbccc...lmngimfin............................", ".................cbbccce..jmnnngnmddgm..........................", ".............ebbbbbcecc..lmmnnnnmddnggj.........................", ".............accac..cce.kllmmnmmfinmgggd........................", "............ac.cce.ecce.llllmlhffnnmiigf........................", "............b..ce..cce..llidkfhmnnnmiiim........................", "............c..ce.cce....hhhjhlmninniggm........................", "...............e..ee.....jjk.hl...jmin..........................", ".........................oeo.dml................................", ".....................dh...kk.dlmnnm..jim........................", "...................lmjhi....ohllmlnnggmj........................", ".................lmmnnmdi.e..jdmm.m.n.nj........................", ".................lmnignjidecc..jm.n.njn.gl......................", "................jjjmnnnmdf.ccae.lmn.nn..inm.....................", "...............ddfggdmmmkfjeccbae.mmn..ffng.....................", "...................fifljhjfdcccabc...c.hmmnm....................", "..........jiiggfdij.jfffjdfg..caabbba.ddllmfd...................", "..........fhhfffhigi..hj..hjlm.ecaae..ffjlmij...................", "..........fj.....ffigj..o..omnnnl..mn.ddjfid....................", "..........f.okkkklkjfiidj..kmmnnifiin....jj.....................", "..........f.kkklmmlkldhif...lmmnmfinn..kk.......................", "..........f.kkkdimlllkjff...klmmljmml.olkjd.....................", "..........h.ljkfiidllljfh....kklmnll..oojink..fi................", "..........h.jfjjifdffljfd...oklmmimk...khmnm..ff................", "..........hkkjhfihjhdljfj.kk..o..lk....jjlml.di.................", "........a.h.kljfifhdlljfj.ejjjkffikjj....klmldf.................", ".......ba.h.lddfihjmlljf....kjjhjflj...o...ljhh.................", "......bbc.hkkjjhihlllkhh.llko..hhh.oll..ok.kahf.ii..............", ".....bbaeejh.kkhffdllkfj.mmdj.e....dmnm..ok.aah.mgg.............", "....abbccejh.kdjfldhkjhelmmi.ecccc.dfmm.....ah.lmnggn...........", "...abbaccc.hjokdfjllkhd.lmfj.ecbca..dgid....h..ljmnggi..........", "...bbbcccc.adkkkdklkjh.kdfj..ccbaa.ook.....hh.lnmmmmggi.........", "..abbbcccc..hlkklkklhj..jjok.ccbba.kllkh...hd..jnnmmmigim.......", "..bbbaccce..adkklkkdh..odj.k.aaab..kk.fnm.......jnnmmmggg.......", ".bbaacccceoe.hjklldh..llni...abab....hmnn.........nnmmmiggg.....", ".ce..eccceee.jhkjhd...llnnd..baab...jlmmn..........mnnmmnggn....", "......ccc.eee.jhfa..jkollj...acaa..jklllk...........minnmnggg...", "......ccc..eee.dh....ejddk...acc.....jdfj............jninmmggm..", "......ecc...ee......k.......eac.....k..................nnnmngi..", ".......ece.........klmmk....ee......kllml................gingg..", "........e..........llml..............lmnj................jiinii.", "..................jhido..............lljfj..................lmn.", "..................kkjh...............kldfhk.....................", ".................jnimjj.............jkkhjlnnm...................", "................lmniilj............jj.jjlmnnn...................", "................jlmld....................lllf...................", "................................................................", "................................................................", "................................................................"];
    const a = mkArt(); R.forEach((r, y) => { for (let x = 0; x < r.length; x++) if (r[x] !== '.') a.px(x, y, P[r[x]]); });
    return a.done();
  }
  const ARTS = { knight: ART_KNIGHT, ninja: () => artImg(IMG_ninja2), archer: () => artImg(IMG_archer2), dragon: () => artImg(IMG_dragon2), skeleton: () => artImg(IMG_skeleton), mage: () => artImg(IMG_mage), ranger: () => artImg(IMG_ranger), hammer: () => artImg(IMG_hammer), zombie: () => artImg(IMG_zombie), mace: () => artImg(IMG_mace), dblade: () => artImg(IMG_dblade), fblade: () => artImg(IMG_fblade), lantern: () => artImg(IMG_lantern), potion: () => artImg(IMG_potion), magma: () => artImg(IMG_magma), sdrake: () => artImg(IMG_sdrake), smage: () => artImg(IMG_smage), drake: () => artImg(IMG_drake), bow: () => artImg(IMG_bow), fireball: () => artImg(IMG_fireball), icesh: () => artImg(IMG_icesh), toxic: () => artImg(IMG_toxic), bflame: () => artImg(IMG_bflame), claws: () => artImg(IMG_claws), nunchaku: () => artImg(IMG_nunchaku), pencil: () => artImg(IMG_pencil) };
  const artCache = {};
  function artPix(id) { return artCache[id] || (artCache[id] = ARTS[id]()); }
  const INK5 = ['#2b2013', '#4a3a22', '#6f5b3a', '#a38b5a', '#d8c690'], RUST5 = ['#3a1608', '#6b2a0e', '#8a3412', '#b45309', '#e0a060'], TERM5 = ['#031a0a', '#0a4a24', '#15803d', '#22c55e', '#bbf7d0'];
  function mapCol(h, sk) {
    if (sk === 'base' || sk === 'dark' || sk === 'glass') return h;
    const c = hex(h); let lum = (0.3 * c[0] + 0.59 * c[1] + 0.11 * c[2]) / 255;
    lum = Math.max(0, Math.min(1, (lum - .1) * 1.22));
    const red = sk === 'ink' && c[0] > c[1] * 1.5 && c[0] > c[2] * 1.4, ramp = sk === 'ink' ? (red ? RUST5 : INK5) : TERM5;
    const t = lum * 4, k = Math.min(3, Math.floor(t));
    return mixc(ramp[k], ramp[k + 1], t - k);
  }
  function drawEmblem(x, id, sk, cx, cy, S) {
    const pix = artPix(id); let x0 = AW, x1 = 0, y0 = AH, y1 = 0;
    for (let y = 0; y < AH; y++) for (let i = 0; i < AW; i++) if (pix[y * AW + i]) { if (i < x0) x0 = i; if (i > x1) x1 = i; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    const w = x1 - x0 + 1, h = y1 - y0 + 1, f = Math.max(w, h) / S, nw = Math.max(1, Math.round(w / f)), nh = Math.max(1, Math.round(h / f));
    for (let j = 0; j < nh; j++) for (let i = 0; i < nw; i++) {
      let r = 0, g = 0, b = 0, n = 0, bright = null, bl = -1;
      const ax = x0 + Math.floor(i * f), bx = x0 + Math.max(Math.floor(i * f), Math.ceil((i + 1) * f) - 1), ay = y0 + Math.floor(j * f), by = y0 + Math.max(Math.floor(j * f), Math.ceil((j + 1) * f) - 1);
      for (let yy = ay; yy <= by; yy++) for (let xx = ax; xx <= bx; xx++) { const hx = pix[yy * AW + xx]; if (!hx) continue; const c = hex(hx); r += c[0]; g += c[1]; b += c[2]; n++; }
      if (n * 2 < (bx - ax + 1) * (by - ay + 1)) continue;
      x.fillStyle = mapCol(toHex([r / n * 1.45 + 14, g / n * 1.45 + 14, b / n * 1.45 + 14]), sk);
      x.fillRect(cx - Math.floor(nw / 2) + i, cy - Math.floor(nh / 2) + j, 1, 1);
    }
  }
  function drawArtHi(x, id, sk, ox, oy) {
    const pix = artPix(id), cache = {};
    for (let y = 0; y < AH; y++) for (let i = 0; i < AW; i++) { const h = pix[y * AW + i]; if (!h) continue; const m = cache[h] || (cache[h] = mapCol(h, sk)); x.fillStyle = m; x.fillRect(ox + i, oy + y, 1, 1); }
  }

  /* صحنهٔ پشت شخصیت: واحد = ۲ پیکسل بوم ۲۸۸×۴۰۸ (هم‌اندازهٔ پیکسل شخصیت)؛ مرکز دایره (۷۲،۸۱) و شعاع ۴۴ */
  function sceneHi(x, P, c, sk, lock) {
    const CX = 72, CY = 81, RR = 44;
    x.save(); x.beginPath(); x.arc(CX, CY, RR + .5, 0, 7); x.clip();
    const fl = 96;
    R(x, 0, 0, 144, fl, P.wall);
    let sd = 5; const rn = () => { sd = (sd * 1103515245 + 12345) & 0x7fffffff; return sd / 0x7fffffff; };
    for (let row = 0, y = 34; y < fl; row++, y += 8) {
      for (let bx = -(row % 2 ? 8 : 0); bx < 144; bx += 16) {
        const f = (rn() - .5) * .16; R(x, bx + 1, y + 1, 14, 6, shade(P.wall, f));
        R(x, bx + 1, y + 1, 14, 1, shade(P.wall, .1)); R(x, bx + 1, y + 6, 14, 1, P.wall2);
        if (rn() < .3) R(x, bx + 3 + ((rn() * 7) | 0), y + 3, 3, 1, P.wall2);
      }
      R(x, 0, y, 144, 1, P.mort);
    }
    if (c.type === 'spell') { for (let r = RR + 2; r > 3; r -= 5) { x.strokeStyle = (r / 5 | 0) % 2 ? P.ban : P.bg; x.globalAlpha = .55; x.lineWidth = 2; x.beginPath(); x.arc(CX, CY + 6, r, 0, 7); x.stroke(); } x.globalAlpha = 1; }
    if (c.type === 'support') { R(x, 30, 38, 3, 58, P.wall2); R(x, 111, 38, 3, 58, P.wall2); }
    R(x, 0, fl, 144, 45, P.floor);
    for (let j = 0; j < 5; j++) R(x, 0, fl + 5 + j * 9, 144, 1, P.floor2);
    for (let i = 0; i < 40; i++) R(x, ((i * 53) % 128) + 8, fl + 2 + ((i * 17) % 30), 4, 1, P.floor2);
    R(x, 0, fl, 144, 1, P.floor2);
    if (c.type === 'character' || c.type === 'creature') {
      R(x, 105, 72, 3, 20, P.floor2); R(x, 103, 67, 7, 5, P.gold); R(x, 104, 68, 5, 1, P.goldL);
      if (sk === 'term' || sk === 'ink') { R(x, 104, 56, 5, 11, P.gold); R(x, 105, 52, 3, 5, P.gold); R(x, 106, 58, 3, 7, P.goldL); }
      else { [[104, 57, 5, 10, '#c8421a'], [102, 60, 9, 7, '#e8731f'], [105, 52, 4, 9, '#f08a24'], [106, 48, 2, 6, '#f5a62a'], [105, 60, 4, 6, '#f9c93a'], [106, 62, 2, 4, '#fff3b0']].forEach(r => R(x, r[0], r[1], r[2], r[3], r[4])); }
    }
    if (!lock) {
      const stand = c.type === 'character' || c.type === 'creature' || c.type === 'support';
      const oy = stand ? 114 - 68 : 81 - 36, ox = 72 - 32, sy = stand ? 114 : 121;
      x.fillStyle = 'rgba(0,0,0,.32)';
      for (let k = 0; k < 4; k++) x.fillRect(72 - (20 - k * 4), sy - 2 + k, (20 - k * 4) * 2, 1);
      if (ARTS[c.art || c.spr]) { const g = x.createRadialGradient(CX, 92, 4, CX, 92, 46); g.addColorStop(0, 'rgba(255,240,210,.5)'); g.addColorStop(1, 'rgba(255,240,210,0)'); x.fillStyle = g; x.fillRect(0, 40, 144, 90); }
      drawArtHi(x, c.art || c.spr, sk, ox, oy);
    }
    for (let k = 0; k < 3; k++) { x.strokeStyle = 'rgba(0,0,0,' + (.22 - k * .07) + ')'; x.lineWidth = 2; x.beginPath(); x.arc(CX, CY, RR - 1 - k * 2, 0, 7); x.stroke(); }
    x.restore();
  }
  /* هنرهای تبدیل‌شده از طرح‌های کاربر (شبکهٔ ۶۴×۷۲) */
  const IMG_dragon2 = [{"a": "#5d6364", "b": "#be9e7e", "c": "#8e7969", "d": "#3c414a", "e": "#594e4b", "f": "#444c53", "g": "#8d6652", "h": "#31343e", "i": "#9e4b3a", "j": "#292831", "k": "#3e383b", "l": "#1e1e26", "m": "#922f2c", "n": "#2c2e38", "o": "#742828", "p": "#492426", "q": "#272028", "r": "#2b161d", "s": "#d14936", "t": "#ab362f", "u": "#18151d"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", ".....................abbbc......................................", "....................cccaad......................................", "..................ccefffd........c..............................", "................ccafgghd.........bc.............................", ".............accaddhiij..........ebe............................", "............bcdaafj.kjl..........kcbg.....cc....................", "...........ccadh....l.j...........ebb.....kbg...................", "..........cacah....hh.............egbc.m...gb...................", ".........baaah.lnj.fnj............kgbbemo..ebg...accd...........", "........bcaah.lndn.ann.............egbbpm..qeb...daaa...........", ".......baaad.jjfdn.andc..........eekecbepoo.gb...jfdda..........", "......caaaf.jnnddj.dlhaa......cbbcq.eebcomo.ec....hgcfa.........", ".....ccaafjqhhdhh.qcelda......eccepmreehmsstpg.....iikfc........", "....ccaafjlnhhfdj.ngg.hac......kgeppp.ktstssskc..ll...dda.......", "...ccfafn.jdhaaf.q.kq.jhd.........otppptsstssok..jnnl.jfaa......", "...anl...jhdeaakqhhj...daa.......omopop.ossssso...jdhl.jfac.....", "...hfaf.qndhaaaldddd.l..fa.......osiomm..pssss.....dhjl.haae....", "...caaf.nddaaaknddfdujq.hfnb...bkopiimsib.ptst...ehdhnju.fac....", "...caajjhddaffqddffflhjl.heac.ggptr..mttip.ossi..fhnjnhq.jace...", "..ecaalhddfcfhnffffdqdhj.lfca....oo.osmomttmmssodfjeeldjj.fac...", "..caadqfafaaa.jfffdhnddhq.fcf....pmrqqpgg.ommmsphdqgg.dnn..ac...", "..caa.unhfaaf..ndddjhdfdnlllle....mpeejebc.kptm.aj.q..ddhj.fcc..", "..caf.....ffd...ndaqdfffdl..da..cgpopeek.ebga..fa.qjj.dfhhl.fc..", "..ca.......a.....ddj..ndflq.hfe.ge.moecg...cc.jfj.nddldadhqljak.", ".ecf.......e......fjhakqj.jllhn....mtpbbg.....hduqhffnnaahn.fj..", ".ba...............jh..fajlhnl.lfh.rommebbb...eeqljddfh.fahhlfa..", ".cd....................fdqjnh.qh.ppmmtebbck..aa.jjdfadlfckhjdc..", ".c......................khd.jq.rosmommebbbgjhnd.nnddffjheddjha..", ".............g...............rtstsmsimpcbbb.j..jdndddn..aannnc..", "...........cbb..........eec..tssmtsiboebgcc..ujhdnedj...aahhuae.", "..........cbbg..........kgeqtssotsssmocbbbbg.ndfdndd....fcfhlac.", "........cjkke............kppssposssspocbbbbe.nn.h.fj....faf..ac.", ".......bcjfq.e.........gkomppo.mssss.ecgbbbp.....nf.....ff...fc.", "......bceudn..........kgptmor.otsssorgbbgg.op....nh.....d....qa.", "......ekqlqook..a......omopopromsto.egbbbkpo..................a.", "........g..osm..bg.gc.pmtiprpgmomo.kgggbgro...................e.", ".......ke..pssm.eg...ootssor.ctm..kgeggerpr.....................", "...........jotttoooompmtstor.ktst.kggej.poo.....................", "...........jpotmsstmo.ssmtor.otssokeeq.pots.....................", "............kpomtmmopmsstmo...mssm......otsm....................", ".............gkoppppptttmo....ptsm......pmst....................", "...............ggggptmoop....q.ottp......omtp...................", "................kekttoor....pprotst......omss...................", "...................iopkr.....p.emieo.....opooo..................", "...................b..bek....rebpgbkb....pcpeec.................", "..................eg..bkgg....cg.eb.c.....b.ebkc................", "..............................g...g.......g..g..................", "................................................................", "................................................................", "................................................................"]];
  const IMG_archer2 = [{"a": "#867249", "b": "#4e2e26", "c": "#6b3e2e", "d": "#7a4e35", "e": "#876644", "f": "#c09d6f", "g": "#495039", "h": "#586441", "i": "#5a362a", "j": "#424032", "k": "#273029", "l": "#392320", "m": "#291a1a", "n": "#232320", "o": "#3e2e27", "p": "#191a1b", "q": "#1c1315"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "............................................ab..................", "............................................cd..................", "...........................................beff.................", ".......................ghhhghhg............h.d..................", "...............h......hhhhhhhaffh............bci................", "..............gfh....hgjghhhhaaafa........a...bceb..............", "..............iff...gjkkhhhhhhhhafa......a.....lce..............", "..........bgff.ef.....khhhhhhhhhhfff....a........ie.............", "...........jffa.f.....ghhhhghhhhae.cj...a........mcec...........", "........aff.eff......jghhhgjhhhae.m.a..a..........bdf...........", ".........afamffnm....kgghjjhhheelcdbo.h...........oca...........", "..........ff.ja..l..kjjkjjghheeiibee..a...........mbei..........", "...........fg....c..kjkkjkgheeicecce.a.............obe..........", "............m..ccll.nkkkkjhhe.bafa.dah.............iffe.........", ".............idbbbl.pkkkjhhaob..f..ea.............eedd..........", "............icbiio....kghhedbefhf..hg.............lbii..........", "............lbcbo...hg.khhdldefff.g.h..............oge..........", ".............il...kn.jj.ni..cdfffh..g..............lje..........", ".............lddiccm...obmn......e.j................lb...gff....", ".............feicdecbmcccibeffaciiccccccccccccccccciiicciihffff.", "............efibicccbcccdb.dffffo.........................hffa..", "............ifbllbbo.bbccl.ffffhkgonjeffaiiefccoliiaff...jfa....", ".............dd.mlm...qlim.g...lg..kjaffecideccoblqdff..........", "..........................njhocbhg.kceffiolbcolmmlmcff..........", "................p.....pplcinod.kkh..ciic.lmmiq......d...........", "...............kk.....pknicce.kgh.a.................li..........", "..............jj...p...kk.bc.ojgk.g................oge..........", ".............gg...n....plcbpldjj...g..............oici..........", "..........kghgk.pnn.p..mb.nkplcc....e.............eaed..........", "........ghhhhj.pnnn.p.....podd.......h.............cafd.........", "......ghhhhgj.pnkknpp..icbcdbiicd....e.............lod..........", "....khhhhhhgk.nkkknp...mlmliceooll....a...........midb..........", "....hhhhhhhj.nkkknn..lib.......p.bi...............oie...........", "...ghhhhhhhkpnkkknp.lcdlpko..p.djkm....e..........ocd...........", "..ghhhhhhhh.nkjkkn.lidonjgilkk.eagj.....a........lid............", "..hhjhhghhh.kkjkn..ddbnjghckjjn.fahhk...........midi............", ".jg...gghhkpkjknp....kjhhe.kjgj..dfaak...a.....lid..............", ".j.....jhh.nkkkknpgcdaahad.jgggg....eac...a...lc................", ".......jhh.nkknkk....daaa..jggggc.mlm.....g..mi.................", ".......hhh....nkn.mbomld...jggghe.lobdc....g.i..................", ".......ghh.....k.qiccilq...dhghec.loiic....iefa.................", "........hh.......moicilq...dhae...qmoooaf...ie..................", "........jh......eflobom.pp.df......mloaff...ei..................", ".........j.....cdedolm.pkkp..........ee.........................", "...............qmlccbl.kkkp.......lcddbmc.......................", "...............bbqlddb.kk..........iciqidb......................", "..............lcil.cb...k...........b.lidb......................", "..............bbbbq...................obcb......................", ".............lbibm....................obcd......................", ".............dcbo.....................mbbbc.....................", "............l.cim.....................mlleei....................", "...........idcmlo....................mo.cdmce...................", "..........icdebmo....................ol.cloccd..................", ".........mbbic.......................m....oboil.................", "................................................................", "................................................................", "................................................................"]];
  const IMG_skeleton = [{"a": "#634b23", "b": "#e3b133", "c": "#f9de71", "d": "#b07f23", "e": "#f3c93f", "f": "#d9901c", "g": "#8b470e", "h": "#a16116", "i": "#4c250e", "j": "#5e3a1b", "k": "#372217", "l": "#4d301c", "m": "#251910"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "....................................abccccd.....................", "..................................deeeeccccc....................", ".................................dfbeeeeccccf...................", "................................ffffeeeccecce...................", "................................fffgfeeeceeeeh..................", "...............................iddhgdbeeeeeeeb..................", "...............................ghhgjfbeeebbeee..................", "...............................gggjdh...dbfd.d..................", ".cd............................ggigf..eh.fdb.d..................", ".bccd...........................ggfb..fgkedggd..................", ".bbccc...........................jhfe...bhagbl..................", ".bfbccc............................gddhfehfh....................", ".bffccca..........................mm.iifbee.....................", ".dbffcec.................acefh.....i.hjggha..a..................", "..bffbced................eecbdi.ji.j.jfhbha.hcca................", "...ffdceb................dfefg.h..gfg..hdhjgbeec.......eb.......", "...dfffcea...............ihhgj.gd..gg....hjhfcee.....ccbbb......", "....bffhee..............hhiggim.fbh....gbfjghffh...bcbfhbbc.....", ".....bfdbed.............bbg...gh.gbcefebhi.kgggi..cefgkkjdbea...", ".....dffheb............hed....jfdhdcb....ji.iggh.debglhjllhfca..", "......dfdfed..........aefk....jjddbcfbbbbdi..igjacfhkjdaalklda..", ".......ffgbb........bchfg.....hdiideggfbhii....befhkljlaaaldab..", "........bfhea......jbfkg......idbbbefd...hh..ccbfjllaaaaaalajb..", "........dfhbe......ggdgi......gabghegbbbbh..hcfhlklllalalajlld..", ".........dfhed.....edgfg......gf.....hfg.k..gbdkgdlllllcllllld..", ".........jfhdb.db.fbhii........m..iji..fdgi..ffigdlllldcdllald..", "..........hdhhdbh.fhi.............jgj...j....degmkllllgeblabkdf.", "...........hhchhkggk..............gfg.........ehkllddllbblbfkhb.", "...........ggfgk.ki...............gagj........fb.lkdedlfbhbgkgf.", ".......aa.hdjiiabh.............hg.dbhiigj.....gealllfehgebblkjf.", ".......fbbdgk.ihdf............j.jghfbigkkj.....edkllhbbbefflkgg.", "........hhgk.gfgig............gdgacehegghg.....dbkllkhfdfhhllgg.", ".........jj..kgdj............iijggfeghghhi.....gbgklkjjkhdllkgh.", "..............ihij...........ffimghhhjhh.jhi....dfmklkkjfbalkgd.", "................mgf.........fbfhi.gfidh.ihhfa...gbhkkkkkdfalkh..", ".................hdj.......febhhi.jgdfi.ghgbba...dfakkkklalllg..", ".................ii.......heedj....fea...gghbea...fflkkkkklljh..", "..........................eedj.mm.........ihhbea..gfdkkkkkllag..", ".........................eedj..lkk..........jheel..gfhkkkaakhj..", "......................dbcgd....ll............iddid..gfhkkaalh...", ".....................dbccfi...................ijdcf..gffikkhg...", ".....................ghffbg....................gfbb...jffdah....", "....................fgigfh....................higfg.....hffg....", "....................gebj.....................gffgil.......h.....", "....................gdbfh.....................jhbbb.............", "...................jhfhhi......................igfh.............", "...................jbfi.........................gfg.............", "...................dbj..........................ifh.............", "..................jbf...........................ifh.............", "..................fbj...........................ifd.............", ".................ghf............................ide.............", "...............hbedgi..........................hdgfb............", "..................chd..........................gedbhi...........", "..............gddgidf.........................ijhhkgfd..........", ".............dbdefjjgi........................dfikgffbda........", "............bfhcdfhigh.......................jhh.ghhbdfbd.......", "...........gfjcbhdgmjg........................jg.ighhbhdbg......", "...........jj.bdjii.................................jflghg......", "................................................................", "................................................................", "................................................................"]];
  const IMG_hammer = [{"a": "#454d61", "b": "#809dba", "c": "#857f87", "d": "#93bcdd", "e": "#577aa2", "f": "#485a78", "g": "#162c4b", "h": "#30394e", "i": "#6f6064", "j": "#5c5e6f", "k": "#151f33", "l": "#231f2c", "m": "#0d1728", "n": "#553c3b", "o": "#3c2323", "p": "#100f15"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "............................abc.................................", "...........................cccddce..bfeba.......................", ".......................f..ccaacbccb..egef.......................", ".........................achijhjjddbc..ef.......................", ".......................ahcjjhajhcccdbbedg.......................", ".....................hbejchiiajjcjebdddbb.....eg................", ".....................eeabaajji.ebbddeebdcc....ge................", "....................begcchjjaajjfeejccccdbcj....................", "....................eddbhjaaihjajjjjbddcjcdbc...................", ".....................fdjaajjhjjjjjebdddejjcbcci.ghg.............", ".....................cchjjajaajjebbddddejjjjjbcbbebbf...........", "....................cjcchaihcjjeddddbdbejjjajccddchfd...........", "....................fhkhccajjajdbddebddejjajjihhcdbheh..........", "....................ehkkkaacjjjebdddddebfjajjhjahjaje...........", "....................hekgllkaccffedbdddedeajjihijahbba...........", ".....................bgkh.kkgjebdeebdbeedejchaaajacjb...........", ".....................fehhkk.gedbejafedffedejajjahcjhj...........", ".........................mggeeggajjjjffafdehaajjjchhh...........", "......................hh...eg..mkkjjjaahedfajajhcaha............", ".......................fb.....ac.kkhjjafdeahcaaichhf............", "........................ff....acjl.kkhjedfaahjhcahf.bh..........", ".........................e...jdclk..kkgfdajjjacchaa.ge..........", ".............................icakg....ggacchjachhj..e...........", "............................ncnha....gegkkhcacchah..............", "...........................ono..a....fegkkkh.cahj...............", "...........................cco.l......bhggkgmgcj................", "..........................nnnn........ff.ggkgkcj................", ".........................nnn.pl.......kb..k.ggg.................", ".........................ico...........ef.......................", "........................nnno..............hb....................", ".......................nio.l....................................", "......................hcno......................................", "......................cdc.l.....................................", ".....................niiah......................................", ".....................inolf......................................", "....................nnn.........................................", "...................iiool........................................", "..................onn..l........................................", "..................ino...........................................", ".................nnn.l..........................................", "................ncno.l..........................................", "................nin.l...........................................", "...............nnoo.............................................", "..............nino.l............................................", "..............nii...............................................", ".............inooo..............................................", "...........aiino.o..............................................", "..........hjbbnol...............................................", ".........hadbajn................................................", ".........abbca.aa...............................................", "...........ichgf................................................", ".............hfa................................................", "..........o...h.................................................", "..........o.o...................................................", "...........n..ooonino...........................................", "...........nn......on...........................................", "...........nno......on..........................................", "............on......l...........................................", ".............loo....o...........................................", "................oo.o............................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................"]];
  const IMG_ninja2 = [{"a": "#676847", "b": "#202b23", "c": "#485435", "d": "#4c413a", "e": "#1a1f1e", "f": "#a6927e", "g": "#34402e", "h": "#6e5840", "i": "#121514", "j": "#201617", "k": "#2f2725", "l": "#4d3128", "m": "#3f251f", "n": "#70432e", "o": "#100d0e"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "...............................aaaaaa...........................", "...........................bccaaaaaaacb.........................", "...........................bccccaaaaaacc........................", "...................d........eccaccaaaaaaa.......................", "...................fa.f.....gccccacaagb..b......................", "..................hffdf....bgccccccagijk.b......................", "...............dfahfflf....ggcggccakjlldmb......................", "................ffdffkf...bgcggcaagjldnkhe......................", ".................fhaa.l..bgggbcaagjjllhmme......................", ".................dajk..j.ggcbgaac.nd.hn.jb......................", "...................j..nl.egegaccjmffffh..bb.....................", "....................lnlkjibeccabijhffff.ibe.....................", "...................nlkmj..eebcc.ebk...k.eb......................", "...................kjmibggi.eg...ekgddk.e.......................", "...................jmjgcaacbi.biibkkgb..e.......................", ".....................gcaaaacgea.eoekii.ecce.....................", "....................bcaaccgbbfdd.gb.i.bcagb.....................", "...................egcgggcccgdad.iee.bccggcg....................", "...................bbgcaaacg....kjee..gccac.....................", "..................igcaack....ikemnkgmj..........................", ".................ecacg.jjkj.igacknnlnje..lnj....................", "................bcc..eiknm..egaadjnhmgk.kdkg....................", "...............egg.nlbgi...ebkgdgljllki..ekk....................", "..............abkjhff.e....ekbkennjjnl..iejnfa..................", ".............kdmnhmff..o......mnl.iijl....nfff.nm...............", "............beejknnl..ii.i..mlnmibgkej.....ff.lnm...............", "............e..nhjmj..e.ii..jjjibbeii.......lknmnn..............", "............eemnlmj..iiie.imjm..kaahll.......mmmlnn.............", "...........ib.nnlj.oeeei...mnhmnhdlhmn.........jkmjl............", "..........igijkjj..eeeemnnl.lnknddhhmm..........i.klllf.........", ".........bgbelll..eeeeilllm.mk......ij............jmlj..........", "........ggbimddlk.ebee.mamm.n.e.bggbbcl.............l.f.........", ".......gcbei.kdj..eeeejnlnj..ibbibcccgdl.........jdmjedfa.......", ".....bccbeecf.jlh.eeeilnnl.ekbggg...ccghl............ddafa......", "....kccbbeafadk.lieeeimnnj.lkgcgc.ii..gghl............aaaf......", "...kccbgbgfaaabiiebbei...jblkcccc.eeebi..hl............dfff.....", "..gccbggdffafkeeeebeee.eegn.gccag.iikggkj..m.............aff....", "..ccgggbffafbeebbebeeeiggnl.ccac...oeggggki..............dffa...", "..acccgffaabeebbbbbee.gdnn..gca....iebggggge..............aff...", ".cak.gaffaieebbbebbeeklnljeikag..i.ieebgggkj...............aff..", ".cg...ffdeebbbgbbgbekln..eke.c...ei.iekkge.da................af.", ".e....d.bebbbggbbgbim..ekgkeo.i.ebeeiiebe.nhfh..................", ".......bbbggbggbggee..ekggbe..eeebeeeio..lddafk.................", ".......bgggggbggggei...ikkei.eeebbbbbe.jlmkdddd.................", "........gccg...ggb...dfg.ie.iebebbbbbb.jmlkddkg.................", "........gccg...bgb..kaaad..iebbbbgb.....j...dde.................", ".........ccg...eg..jddfdkm.eebbeggb......ieegd..................", "..........ag....g.ikddddkjiebgb.egb......ekke...................", "..........gc.....ebkkkke..ibgg...e.......ii.mnn.................", "...........k.....ebkdkk....egg...........jmnnhn.................", "................l...........ge...........mnnnn..................", "...............mnnlkj.......e............mj.jm..................", "...............mllmj......................jmlnn.................", "...............nlki.......................mllnn.................", "..............nlmj.........................mlll.................", ".............mllm..........................kmnn.................", "............lfjj...........................jmkkk................", "............dadk...........................jjghh................", "............mjkl...........................kmmkm................", "...........nnlj............................mmmmnhm..............", "..........nhnlm...........................mlmmlllnhl............", ".........mnnnlm...........................kkjjmmnnnhm...........", ".........mnnlmm...........................llm..llnnlm...........", "................................................................", "................................................................", "................................................................"]];
  const IMG_ranger = [{"a": "#4a2f29", "b": "#2c1e1f", "c": "#573d38", "d": "#392d31", "e": "#5e5155", "f": "#34201f", "g": "#251718", "h": "#9a8a85", "i": "#2b304b", "j": "#383d5b", "k": "#262738", "l": "#201f2c", "m": "#13131a", "n": "#1c1416", "o": "#161826", "p": "#150e11", "q": "#0e0e14"}, ["................................................................", "................................................................", "................................................................", ".........................................a......................", "....................................bcccad......................", "...................................accccaddd....................", "..................................addcceecddf...................", "...................................ddaccaecd....................", "..................................ffddadcada....................", "..................................bbfdfadcac....................", "...................................gcahcchgf....................", "................................i...bahhhhf.....................", "..............................jkii..lkkdjim.....................", "..............................kjiijkmldiikmm....................", "............................bea.ijiji.lkd...i...................", "..........................ehheednljijjk....ijo..................", "..........................eehhee.goijijjikjjil..................", ".........................eeheheh.f..kjjijjiloj..................", ".........................eehececpaa.noijikokjjj.................", ".........................ceeee..gaaofbqoljjjjjj.................", "........................dehe..gb.fcilaam..kjjk..................", "...........................nddfg.fbjjlcdban.lik.................", ".......................ldddccgb..gljjjbacfik...bcc..............", "......................k.bcecbb..nndiji.ae.ji.b...ee.............", ".....................jlbg...a....okiifcbfcd..db...ee............", "...................jjkbcccb.....mlllacfloaa.ndd...nhe...........", ".................kjji....cag......baabkiina.n...gg.eh...........", "................kji...hhc.bn.....gafplikklg..nb.ggb.h...........", "................i....ceehc..o.........g......ff.gfbghh..........", ".....................ceeca.om.o..faaaaaeeec...g.nfbbeh..........", "...................i.dcbf..o.om..gaaf.accea..gab.fbfdhe.........", "..................jk.eean.oooo.ac.f..bn......gbf.bganhc.........", "................kjil.ccf.ml.oobafngaa.okk.fa..ba.gganec.........", "...............ijklobecb.oooo.faggca.lkiilncn..bf.bffec.........", ".............kjjkhb.gb..oloomgcagff.lkjijimfa..n..gbncd.........", "............jjjidaa.fca.oooomggg.ol.iijkjii.aa..fb.fncd.........", "...........jjjijkmggdaffmleom..mli..kjjkijio.a..bg.gbcn.........", "..........kjjijik..fddafpeh...lkij.pkjjl.jiim..g.e.gdc..........", "..........jjijjim.mnacf.cego.lijj.bblji..jjjkl..gf.ndd..........", ".........jjijjio.oompg.cebc.mkijlndboj....jjkkk.....c...........", "........kjijjjlmolooo..eaceedkjlnddbll....jkjjdl....d...........", "........jjijji.mllokloacbdcehdmndddbb.....j..ijj...d............", ".......kjijjil..klkkklegdeccehdbddddp....li.bn.dd.b.............", ".......jjijji...lkikldh.odeecehhbddb.......gbdbbn...............", ".......i.ijik...oiikoo.oo..cheehhcdn..m...nbbddbee..............", ".........iji....kiklmolko...dheehhc.ooo....nbbneee..............", ".........ijk...oiikoooklo.gbn.ehehheloo....ngnceehh.............", ".........ij....iiilmokklo..bn...hhhhhdo.......eeheh.............", ".........ki...ljii.moiklmfgbeec..hhehh.......ndcdde.............", "..........l...iiii.mkilom.deehe...hhhhhh....p.nddcd.............", "..............iiio..kkl.dddchhe.moodhhhhh...bccbde..............", "..............kii...koo.geclcce.ooookehhhh.......e..............", "...............ii...o..afbd.mcd.oololo.hhhhe...gn...............", "...............i......gaabn.gd..llklk...hhhhegbbfg..............", "...............k......affbg..om.lkklk....ehhhebfaf..............", "......................ccaafg.o...kkko......hhheaca..............", "......................gacca..m...ik.........dhhac...............", "......................agbfg......im............gb...............", "......................aab........i............nbf...............", "....................ca.fg.......................acc.............", "....................baac.....................gaacfb.............", "....................na.fg.....................ffnf..............", "....................fbb........................nfaf.............", "...................acab.......................ngbfa.............", "..................faffag.......................gbfcf............", "...................ffg.n......................gbffbbaa..........", "..................cccag.......................ng.ngacccf........", ".................acccaf......................nffn.gaaacc........", ".................acccaa.........................................", "................................................................", "................................................................", "................................................................"]];
  const IMG_mage = [{"a": "#444876", "b": "#323a6c", "c": "#191f39", "d": "#2e2f49", "e": "#493535", "f": "#613a31", "g": "#4f2222", "h": "#23233b", "i": "#755d60", "j": "#754b3b", "k": "#121320", "l": "#15192c", "m": "#3a1f21", "n": "#644b4a", "o": "#301d20", "p": "#221519", "q": "#8c6f6a", "r": "#a69395", "s": "#0a0b14", "t": "#130c10"}, ["................................................................", "................................................................", "................................................................", ".........................ab.....................................", "......................cbadaaa.........................ef........", "......................adcddbaabd......................eg........", ".....................ddh.hdbbaaa....................eije........", "....................hbckkldddaaaa...............f.minopf........", "..................abdcl..ccdbbbnqq..............mjnp..hmj.......", ".................dhllk...ccddnqjiai.............fn..drdim.......", ".................dl......llnnfffjiem...........men.brrbdj.......", "................dl.......ejniffolldbadd........f.ebrrra.ej......", "................l.......pgfdfjcbaaaaaaqqqif....f.mearra.mj......", "........................op.fjdaaaaaaiq..ske...oj..faabb.fe......", ".......................llcdldaaiqqefo...kc.....jf.naad.ej.......", "......................hchdbaajj.mofgg..lc......eq.mb.hij........", "....................chcddaae.po.gjfpj.ll.......oejopnje.........", "..................fndddbinomfffrrrdomks..........ffjm...........", "..............a....pefjf.toogjqrrrqo.............pjpth..........", "............h.d........s.mfmgfjrrrpg............lahfenf.........", ".............c..........mggtmfjj...g.............ejf.e..........", ".........ad.bacdb.....pgfmlh.jqq.hbho..........gqjo..n..........", "...........cara........fpdhddmjhbbhbaf.........jop...n..........", "...........arrra......jmkkhdcfehddbdclg.......ommf...n..........", "...........barab.....fgkablkfqqnll.kdh.........mjm..............", ".........bd.bab.d....gmdabhcfbbjohbbba.........ej...oi..........", ".............b.......pkdddbnpjjgjonaabd........ne...naj.........", "............ei.q......dbaaioimfmeqd.eiie......on....hne.........", "............jrnq.....dbaie.hnmffhdh.ttk.......jmkd...d..........", ".............jqrr....nnho..kkmmgokt.pcdh......mtlb..............", "...............qqjjiah.llt.tmohhmo..ldhbaaieqrjnkd..............", ".................gmqabdhc.ttp.kk.p..kcdbaaqfjerjkhd.............", "...................qibbck.offjqjifj..lhbaijmgiq.klb.............", ".................k.qndhl..p.feifnmg..kcdbq..pf...cdh............", ".................lsnbhlomplh..pmttmf..lhdi.sfm...hca............", ".................hendlojjjglofjgt.qnf..cnistjp..lcda............", ".................hebcsffjfmpjfod.piaj..ldjkof...cdbd............", "................elidl.mqomfpokniotfj....cn.fg....ba.............", "................henh.mfmffm.koqr.ptgml..knoj.....da.............", "...............oeihssofjfgtpd.rrdmlpjj...lef.....he.............", "..............ccfo.sk.ooopohn.rreohcpgm...fm......a.............", ".............ddhp.skk.s..mmdf.qrn.ndck....j.......q.............", "...........babamsskkkshcfgdi.oiri.nbdbl..gf.....................", ".........daabbeskklkkdejjlijt.irqteabbb..fo.....................", "........hqaabnpkkll.mjjglbiop.irqtfabda..f......................", ".......dqiaiafkkclk.gpslbifoo.irrteiabbdpf......................", ".......iaiiiimlcclkkcccbaqoe..irqttiabdbpm......................", ".......qq.eqilchcllbbcdaioee..qrqptibadab.......................", "......nq......hdckbbhcaqjoep..rrnpofaabba.......................", "......q........clabhlaaipeo...qiipeeiabdba......................", "......j........dbbdlbaipee..s.qqehepqbadbad.....................", ".............eaaadldaq.nepskk.i..depqbaadbi.....................", "............iqiahcdiqmmqn..kkss..dehoiaaadiq....................", "...........qaiiddeqqf.eeo.klkklk.nekpqaaqdbi....................", "...........jiiedep.ioopptklcllckpnet.jaiiadj....................", "............qi..pk.tmfjgoschkchlof.tmoqiiii.....................", "............jq.....ttgfgpchclcdckl..gpjiqaq.....................", ".............j....mompp..cl.kddc....tp.qiq......................", "..................geggp......ddh....omoerj......................", "..................pjojo......bh.....pfgpj.......................", "..................mfpp.......c......p.omg.......................", ".................pfgo...............mtoof.......................", ".................ffmp...............e.tgjg......................", "................gqmm...............om..goj......................", "................omgp...............e...gme......................", "................fepp..............pe..oommf.....................", "...............fffo................o..ompefj....................", ".............ojjjep...................mptmeffo..................", ".............mggemp...................mo.omgeg..................", "................................................................", "................................................................", "................................................................"]];
  const IMG_fireball = [{"a": "#610d01", "b": "#a52b02", "c": "#630300", "d": "#a80501", "e": "#6d1f02", "f": "#d04904", "g": "#db2801", "h": "#f85202", "i": "#aa1501", "j": "#380000", "k": "#f77104", "l": "#d71101", "m": "#fb8c09", "n": "#fda80f", "o": "#fdba1d", "p": "#fed638", "q": "#f13002", "r": "#fec423", "s": "#fee55a", "t": "#fef2a2"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "......................................ab........................", "............................................cd..................", "........................e..................bfghi...i............", "............................c.......bf..e....fefb.....ie........", ".........j..................eh.......eb..fkbcilgkmfddi.ff.......", "...........aigb..............be..e......cimnhhhkkopmgglif.......", "..e..........ihme.......ibe...b..fe..diifkhnohgllqnnoomqq.......", "......bb......qhhd.....qfhmf.......dghnokidfqllqhkknmrppmq......", "......ea......c..l....e...gkhcc..cdlqnpkdigdlhnronnnrrmmpnld....", ".................idc......bknhllddlqnmkiggqlqnohhooosspnmpklf...", "..........cdd.....cddc..j.hknnkhhknnmmqldlggqhqhkknoospprpphf...", ".............dc....cde.jbkkmnponronnokqmkhkkqhmrnknsspsrnosmg...", ".........a....cddcddlqhkkqlghhpokhqkmkhgkornmrprssrpttssooopgc..", "......c.........dllllqkh...dggqmnmmmkqlglhopspmnossssttssrnpqi..", "......cc.........cghkhg......cillqlqmkilhknonpmnrsstttttsrpokq..", "....................ce..eb...cc.dlllgmfddfhqhmprsstttttttppokg..", "...............b........b..a...j..dldgkillghqhmrorsttttssrsoge..", "............b...................bb.cidghdlfnkqkmopspsttsrprnl...", "...................b........a...fmhfhhqhgddlqhhmoorssssnrsrhc...", ".............................fffkkf.bhkmmidlqqhkmppprrrrsrklc...", "..............................eb.a....qhmnflqnmmpssprmnprklc....", "............................a.......cc..cifhlqmrrnrrmhmnkl......", ".........................................lqmhglghmkhhopfd.......", "........................................c..bkmmgillfmob.c.......", ".....................................b....e.....ccibb...........", ".....................................kb.........................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................"]];
  const IMG_icesh = [{"a": "#6aa2e0", "b": "#9ed9f7", "c": "#5685b8", "d": "#152e5b", "e": "#1e60c1", "f": "#75d5fb", "g": "#348adf", "h": "#305b97", "i": "#183976", "j": "#307ad7", "k": "#5eb1ef", "l": "#1e499b", "m": "#379af0", "n": "#65c1f8", "o": "#a0eafd", "p": "#8ec1ea", "q": "#4da0eb", "r": "#cdf2fd", "s": "#396bb2", "t": "#102455", "u": "#08142c"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "...................abcc........c.....d..........................", "....................ecbf..............ga........................", "................h...ijgkk....lmac......jbc......................", ".....................hmmnh....ieaf.....jjboc....................", ".............hapc.......ih.....lmk......gjofn..c................", "..........dhj.eqrc..................hh..cmepfk.ca...............", "...............iar.......ljeei.......kc..ljeaqs.fq..h...........", "........di......lba........lgqpnmjh...itelejeqmhskj..f..........", ".........qbc.....ibc.........jmbafnmjeearfffpqbnmgmj.nnh........", ".........hjkc......arcccaakqqmjjglllcpoonmqjjgnrrrpagmfnj.......", "..........hhh.....c.dcpfkqjeeeliisaronfjesjgmkqoooorrorrfq......", "........................snks..lejlllcpjlllcfnnnfrrroffbnrbm.....", "...h..........cpbp....c...hgknkqjjgjeilgecoffooronborrfoforph...", "...gs.......cobnkg.........ljakkkqgeeceecrropaqjqejqnqfbrrrrrc..", "...........apjeqc.......tcpbbqeeeejeleeeonjglgmeqeqqemmnorrns...", "..........sejmkh......cppkjeeabrbncjllellnmjqeejkngmqforrkmi....", ".......i..........hspaci...ljeleqpbfmlieelamkeejkknforpkkj......", ".......a.........hc........ijeliieejansleeeafmgkjmnfajjkh.......", ".......................hh.il........ulbfmmqmkofmnkjgje..........", ".................h...cfki......c.....imagsljqafqelqmh...........", ".........ii......d..bfqm......pj.ss..ii...emjej..jml............", "..........lkh......apqjs.....hg..i........kqmg...q.c............", "...................pemk..............hkl.ckmh.h.i...............", "..................ajms....c.........png..nh.....................", "..................gh.....hk........hkm..d.......................", "...................................h............................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................"]];
  const IMG_toxic = [{"a": "#2e9303", "b": "#77b90c", "c": "#085104", "d": "#559508", "e": "#044006", "f": "#156e03", "g": "#337204", "h": "#74d207", "i": "#bcee1a", "j": "#9be30d", "k": "#4bb304", "l": "#022905", "m": "#e1fa2c", "n": "#011b04", "o": "#114102", "p": "#205102"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "....................................ab..........................", "...................................c..d.........................", "...................................c..b...e......af.c...........", "...................................aga...ceaaaf...hihd..........", "....................d.........c.........e...hija.aikabjj........", "..............hg........l......fag...dd...djmmmmiihhaabmb.......", ".........nl..gib.......l.cc......ckbbdbjjjjajjkhbjaakkfahib.....", "..........lea.d..........cfkkf...bm..eccfacfhbhfcahimmjakiid....", "............oe...........efkijkbjb......e.chhbccckmmimmjkjkd....", "...................f..ajd....bib.....eahihibf.efhiibimmjhajhd...", ".................ff.kbd...d...e.cf..chiimmifa.cjih..imm..kajd...", "....fd.........................c...fjbffhmadg.hmkd..dmb..ahji...", "....ab.....................lc..efc.hk.f.jhcd.cjjk...gdd..cjimd..", "............dh.........ee.fkhjha..ag..p.gia..ckhkdddbcbdddimmg..", "...........d..j.........egakghjiibp.....ekif.fcjajmmmbimmimim...", "...........gdgb..........ec....g.bj.cffa.ajid..kkhimd.pmmimhj...", "............dd.......gakp........aibpfkjjfhk.fd.hkjb...dimhhd...", "................g...f...hd.d.......bijjbijhh..gc.hhk...dijab....", ".........................kh..d...........djmjfe.e.fahjhkkab.....", "................efd.............fgjg.....gfajmkaeacfcfkjbb......", "...............................f..ab....ee..kjijaiikfghmj.......", "...............................gadf........c..gkmidgbbd.........", ".........................................g.....k................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................"]];
  const IMG_bflame = [{"a": "#38498c", "b": "#718cb7", "c": "#454664", "d": "#99e2f9", "e": "#273380", "f": "#5f6394", "g": "#7bbae1", "h": "#4ec7fb", "i": "#36b0fb", "j": "#2590ee", "k": "#1a70e5", "l": "#155ec9", "m": "#1247bc", "n": "#0d3196", "o": "#181f46", "p": "#4793da", "q": "#0f2090", "r": "#08104e", "s": "#3964b5", "t": "#32314e", "u": "#070c33"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "............................................................ab..", ".........................................................cbdde..", ".......................................................fgdddb...", "....................................................ebhhdddd....", "...................................................adijkhhde....", ".............................................lmnnmeghnmiida.....", "............................................nm..obhpqqjidf......", "............................................qn.bhipqqlidb.......", "............................................rpgkmkqmljdbl.......", ".........................................mqagimnkmmphdgrk.......", "........................................sspijmmmmkiga...n.......", "..................................nkilrrihiikqqjjdg.............", ".................................mqrmikkkkjlmmjhgt..............", "................................q...ejjkkmmkkjgpq...............", "...............................n..rsimkiqmlkiijp................", "..............................rrofgklkhlkhhjgnr.................", "..................a..........rlbhkmimjihgaagr...................", ".................fs......ebbbghjmmkkkdga........................", "................pfe.......mpiipmlqkkhpm.........................", "...............pcfo......lkmnkmqnkijbrljll......................", "..............lnecct.efpjksfammmjiih...qq.......................", "..............n..tbcaaeesfcemqligbbb............................", ".................tccmaffcoqkkjign...............................", "................afceidptoqklmjgqmn..............................", "................rofmkimtrkj.ngo.................................", "................etccnmcums..ao..................................", "..............sseuoctctol.......................................", "............aaeoq.ecotfo........................................", "..........esteq...sr.tct........................................", ".....ft.osenru.......otbf.......................................", "....sabcanuu.........maooesa....................................", "...shsft............ejqeqr......................................", "..ehpqtt........................................................", "..sjkkoct.......................................................", ".....ot.........................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................"]];
  const IMG_nunchaku = [{"a": "#594d47", "b": "#856a49", "c": "#3e3634", "d": "#36281d", "e": "#302117", "f": "#211c1b", "g": "#b58643", "h": "#53432f", "i": "#6f5024", "j": "#eba940", "k": "#e19e37", "l": "#d88e27", "m": "#aa6514", "n": "#4b2403", "o": "#ae7222", "p": "#924e0a", "q": "#743603", "r": "#5b2902", "s": "#632c02", "t": "#321905", "u": "#52371a", "v": "#7c5c38"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", ".....................................................aba........", "..................................................aca..bc.......", "................................................adca.cadabca....", "................................................a..e.....c.f....", ".............................................caaaac.......aa....", "...........................................fbgaf............aa..", "..........................................hbbd.d...........c.a..", "........................................ijkcf..h............ac..", ".......................................ljkmn.dd............af...", ".....................................ojklpqr..............a.bh..", "...................................ikjlmqsr..............cb.....", "..................................ljlopqst..............fbbce...", "................................ojjlmqsn................abd.c...", "..............................mjjlmpsr.................dbd.e....", "............................uogllpqst.................oji.......", "...........................oi..pqsn..................ijlpn......", ".........................ovip.pss....................jkmss......", ".......................pjhu.prst....................ljlqs.......", "......................ogl.pnsn.....................ojlps........", "....................id..r.rr......................ijlmsn........", "..................ouum.q.nt.......................kkmqs.........", "................pkium.nsn........................obpps..........", "...............kji.qrrr.........................ou.ns...........", ".............ojkop..nt.........................iki.sr...........", "...........mkjoqq.tn...........................oe.ss............", ".........ikkloqqsr............................ohqns.............", "........ojklmpss.............................ojm.sn.............", "......ivalmpqrn.............................iviq.r..............", ".....baofrqrr...............................hd..n...............", "...obiu.t.nt...............................vhm.r................", "..vjm.n.n.................................mhmrtn................", "..fmp..t.................................ig.qnr.................", "...tsr...................................kgu.r..................", "....t...................................lvmrst..................", ".......................................okppsn...................", "......................................iklmqr....................", "......................................blmqs.....................", ".....................................oa.srn.....................", "....................................vci..n......................", "...................................hvo..........................", "...................................li.n.........................", "..................................ikon.t........................", "...................................dpsn.........................", ".....................................r..........................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................"]];
  const IMG_claws = [{"a": "#2e2d34", "b": "#4f4e55", "c": "#897f85", "d": "#222026", "e": "#36343b", "f": "#26242b", "g": "#2a282f", "h": "#5c565b", "i": "#46444b", "j": "#1c1b22", "k": "#42373e", "l": "#7e6b70", "m": "#19181d", "n": "#17151b", "o": "#bcbdc4", "p": "#0f0f13", "q": "#a69ba1", "r": "#651215", "s": "#855154", "t": "#6b3235", "u": "#410f10", "v": "#121117"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", ".............................abc................................", "............................deafeb..............................", "..........................bghcbijhe.............................", ".........................a.iheiag.e.............................", ".......................kgiaili.g................................", ".....................iggeiikmef...d.............................", "...................ihafgchkdd...jdn.............................", "..................ie.dlagbijmg.mdd......................kk......", ".................cl..i..hgj.af.........................adabi....", "................ohp.qe.bajidanmd.....................kblhhkli...", "..............coejhqg..i...mm.d.....................djhlibg.k...", ".............oqa.coa.lqd.mfn..b...................hfgeeebag.....", "...........hocg.cqg.hoa..dnn..a.................ea.fhcegdf...j..", "..........rlhj.qoe.hoe.jaeg..j.................kfgblikhdj..dnf..", ".........sti..qqe..oe...ekn..................iigfkkhie.fmngj....", "........csk..cca.lob....gnfg...............gidkhgdhbefm..jj.....", ".......stu..lla.loh......npv..............fh.ak..bjfaanm.f......", "......qs...ste..qh........................jv.cf.bajg.n.f........", ".....lu...stg..qt........................e..qf..i.alfgjgd.......", "....qt...cs...st.........................nhqg..qj.bv..dk........", "...st...qsu..tru.........................coe..oe.hh....lj.......", "...u...lqu..rr..........................coiv.ob..od.v..g........", ".......qu..tlu.........................coi..ol..oi.d..j.........", "......tu...tt.........................sqi..ocd.ql..f............", ".....ru...rt.........................tsk..qce.cqd.m.mj..........", ".....u...ru.........................srt..lqe..ok................", ".........r..........................rt..tlk..ol.................", "........u..........................lu...sk..cl..................", "..................................qs...st..bcf..................", ".................................sr...qs...su...................", "................................tr...scu..cs....................", "................................r....qu..tl.....................", "...............................r....st...lu.....................", "....................................r...tt......................", "...................................t...ur.......................", ".......................................r........................", "..................................u....u........................", "......................................r.........................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................"]];
  const IMG_pencil = [{"a": "#995f3b", "b": "#dda351", "c": "#581405", "d": "#d67129", "e": "#b83a24", "f": "#6a0909", "g": "#7f0d0a", "h": "#4b3935", "i": "#793e25", "j": "#911e18", "k": "#6d2106", "l": "#b28350", "m": "#580605", "n": "#351c13", "o": "#f2c371", "p": "#3a0f08", "q": "#4c0000", "r": "#953914", "s": "#b24d12", "t": "#1d1312", "u": "#732d0a", "v": "#db8928", "w": "#cb5f16", "x": "#3a0403", "y": "#5d1f07"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", ".........................................................aba....", ".......................................................cdbeba...", "......................................................feegddd...", "....................................................haijgjeeek..", "..................................................hahllhmjjejf..", ".................................................nloohhlpfffff..", "...............................................hiiloilhnhq.mmf..", "..............................................rqilllalhph..qp...", "............................................ssgjmlhhhhh.t.......", "..........................................uvwrjfq.hhhhntn.......", ".........................................dvbdrrmmxhttnh.........", ".......................................ivvbarvrsfq.t.n..........", "......................................wwddjfwwrrcq.h............", "....................................fjgejjfcssuycx..............", "..................................crdjjmmfysyyky................", ".................................sbbdkmmq.ykky...x..............", "...............................ssbbswwum..qc.....g..............", ".............................krvbvsdwwm..q......................", "............................dwbbdswwskc..f......................", "..........................gsgvvsgwsscyp.mf......................", "........................rrsvvrwc.suyy...q.......................", "......................udrvbvswssruy.............................", ".....................dwgdvvsswsuup..............................", "...................idjgewdrrwrky........mg......................", "..................vddjgfrfksuu..........mm......................", "................rbvbbfqysyuky...................................", "..............yvbbvds.rrrqk.....................................", "............qrvvbwwrqusyc.......................................", "...........ggkssgrrsquky........................................", ".........yaijjfmkssucu..........................................", ".........looimq.fkkcp...........................................", "........looafq.mkcx.............................................", ".......looaayp..m...............................................", "......ioollain.x................................................", "......ejaaiiip..................................................", ".....hmyuyn.....................................................", "....ht.p........................................................", "...h............................................................", "...x.m..........................................................", ".....m..........................................................", ".....m..........................................................", ".....f..........................................................", ".....j..........................................................", ".....m..........................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................"]];
  function artImg(d) { const a = mkArt(); d[1].forEach((r, y) => { for (let x = 0; x < r.length; x++) if (r[x] !== '.') a.px(x, y, d[0][r[x]]); }); return a.done(); }
  /* هنرهای تبدیل‌شده از طرح‌های کاربر (شبکهٔ ۶۴×۷۲) */
  const IMG_drake = [{"a": "#7b5a4f", "b": "#b68f77", "c": "#8f6f60", "d": "#61463f", "e": "#504042", "f": "#52342d", "g": "#372423", "h": "#9f2d21", "i": "#4d191a", "j": "#752a20", "k": "#3d171a", "l": "#641c1d", "m": "#4f2822", "n": "#1b1013", "o": "#854532", "p": "#291216", "q": "#1d1618", "r": "#261d1f", "s": "#140b0d", "t": "#3e3031", "u": "#301b1b"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "...............................abc....c.........................", ".................................dbbd.eb........................", "..................................fcba.ac.......................", ".............................abbc..gabhijj......................", "...............................abbcjkihhhjl.....................", "................................gemijjlkjhh.....................", "...............................afnmohhhlakjhl...................", "..............................dfpjk.jhjjhhhjh...................", "...........................ed..pljpojlcbfjjhh..........a...d....", "...........................qraakjliksgffacack..........at.ag....", ".........................eaccgaeillidaad...............tufu.....", "........................rtecbata.iimccam............aatqaf.eb...", ".......................tecaedetegulobbbmp...........rerdfrteba..", "........................urdatdarmfuabbcukk...........rmffqeeab..", ".......................qmfq....qkmodbbcgmll..........qff.teetda.", "......................klikfgn.nddgojdcfbdki..........taqreeetba.", ".....................klhhhk....dcaqjdfbbdnp..........mr.eeetdb..", "...................akihlhjp.qqqgefotmffapmi.........ff..reeeb...", "...................uecjhp...qqttrgdafgm.nui........uog...eecb...", "..................tteedok....umgifbbcdk.plh........omu...edb....", "...................rdbtr.....ppiufadaf.suklpa.....monu...ebd....", "...................tecgg.....ppikacaap..pklcdg....om.u...ec.....", "...................rtce....umpkuk.da.k..nlfeaad.hiu..uk.........", "...................tat...fnfoo.uouafrmm.pkgrfeelilj..uf.........", ".....d.............guolh...dfmm...dd..u...rrgrqp.ki..no.........", "....ac.............qffhii.mufo.mrrqnntff.....qpkpji..nf.........", "...bcf.............kllhpp.oookgfttdetrfft.......li...gmm........", "..bca............famukiis.ufmpd.edaed.nttg.....f.....fg.........", ".acgkh...d....b...fm.....nrggfu.eaadermfmi....jk.....gm.........", ".c..ulhh.c..f.dc.iljlkpnrtdd.uuneaaaepmghhj..mm......g..........", ".....kljhjijhiijhhhlkppn.pkjffg.daaatquklhh.ett.................", "......kiijhhhhhhjikpuup.klhhjmu.ddadtqummlkacqd.................", ".......piiikkkkkpikkkps.mdajjk..eeatt.pgmutabd..................", ".........pkmliiiikkpn..gdccdksqnqrd.nq.nimdete..................", "............pkkps.....petbatpqrqqq.gqr..purttg..................", ".....................pmrtrr..gtrrt.tr...kmnrt...................", ".....................umueg...tqgtr.q...pmumf....................", ".....................gufuu.....rf......mmtmm....................", ".....................gfupn..............urdf....................", ".....................gdg................uudf....................", "....................tcgn................nuge....................", "...................rdce.................muea....................", "...................umur.................pptpi...................", "..................jlhji.................kmpmhlji................", ".................coacib.................lk.lobfbf...............", ".................a.a..a.........................................", "................................................................", "................................................................", "................................................................"]];
  const IMG_bow = [{"a": "#73809c", "b": "#595464", "c": "#3c3b50", "d": "#22253c", "e": "#7fa5c8", "f": "#716a75", "g": "#243560", "h": "#264a7b", "i": "#4b6597", "j": "#241e2b", "k": "#593b37", "l": "#624643", "m": "#3d2d31", "n": "#0e0f17", "o": "#1e171e", "p": "#3a507d", "q": "#101725"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "......................aa........................................", ".......................bac......................................", ".......................dcef.....................................", "........................gbeb....................................", ".......................gehcfbb..................................", "........................idjddfa.................................", "........................gdkkddaa................................", "........................ii.kljcf................................", "........................g...mldg................................", "........................h....mlhg...............................", "........................g.....kliig.............................", ".......................h......nlkiia............................", ".......................h.......olkgic...........................", ".......................g........llkcpf..........................", "......................h.........jmlmdf..........................", "......................h...........kmhba.........................", "..................................mmicf.........................", ".....................p............ggpkjb........................", ".....................h...........ccfdl..........................", "....................g...........cbbpfb..........................", "....................p..........cbbiepaf.........................", "....................h..........jjbiegcaf........................", "................................mjfpc...........................", "...................h............mmjb............................", "...............................omlo.............................", "..................i............oko..............................", ".................cp...........jml........gp.....................", "..............hp.daf..........ccm.........heeag.................", "...............ieabifc..m.m...jcam......bfaiieeeag..............", "...............giiddcj........qcbq.......dgheeiig...............", "..............headfff.........cca.........ieig..................", ".................bf...........djm...............................", "..................i...........ojko..............................", "...............................omm..............................", "...................h...........omlm.............................", "...................g............jmmf............................", "....................g...........jkfbb...........................", "....................h...........jbpepfam........................", "....................g..........ccbiehbm.........................", ".....................h.........jcccpcb..........................", ".....................h...........cdcdk..........................", "..................................ddpkmc........................", "......................h...........jmicf.........................", "......................h...........kmgbb.........................", ".......................g........kmljdbm.........................", ".......................h........klmgpm..........................", "...............................olmha............................", "........................h......lmhe.............................", "........................h.....lkhh..............................", ".............................kkgd...............................", ".........................h..kldh................................", ".........................ejkkjgm................................", "........................hgkkjgaf................................", "........................idjjcfc.................................", ".......................gepafjd..................................", "........................gac.....................................", ".......................bfbj.....................................", "......................faj.......................................", ".....................abj........................................", "....................fj..........................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................"]];
  /* هنرهای تبدیل‌شده از طرح‌های کاربر (شبکهٔ ۶۴×۷۲) */
  const IMG_zombie = [{"a": "#493b3e", "b": "#2e252c", "c": "#20131a", "d": "#362d34", "e": "#463132", "f": "#2d191e", "g": "#591f23", "h": "#683c38", "i": "#875c52", "j": "#867162", "k": "#513d3d", "l": "#221c24", "m": "#594846", "n": "#9d7d6e", "o": "#a9927e", "p": "#715b55", "q": "#110c11", "r": "#bea88f", "s": "#392025", "t": "#64534a", "u": "#161219", "v": "#3c3742", "w": "#25222d"}, ["................................................................", "................................................................", "................................................................", ".....................................ab.cb......................", "..................................debdeee.......................", "..................................cdfgddaaea....................", ".................................eaghijkbeal....................", "................................damgginopkbeeq..................", "................................edkgghnrojkdad..................", "...............................cllsgghnrrrnecdl.................", "...............................bcmlghnrrrrot.d..................", "...............................lumbeipporoop.d..................", "............................dpbuqemjmsesjrot.d..................", "...........................aop.q.mkojpnckefe.l..................", ".........................opkopcsf.ptrpknphi.....................", "......................mrrrnmjoas.imksirjq.e.....................", ".....................prrnorptrjf.mog.ihiit......................", "....................korrroookprpc.jsf..sg.......................", "....................knnrrrojtmjaeqehgek.........................", "...................cpjnrrropmbbssq.eiih.e.......................", "...................dpnoronrpdvbsfc.c..ftna......................", "..................bpjnorniojbmacke.bbubjrnb.....................", "..................anooonhhihumkfhsukdddjoone....................", "..................popjnhgshieeaesdlkkaejoooojm..................", ".................djp.pifgggitcakmavttbdpnoorta..................", ".................etl..efhis.abatpdppacvtjnomfkk.................", ".................b.qq..epom.cdktadntc.dmpjmfkjnkk...............", "...................wbu.ejojkfwamltjd...apm.smpnoona.............", "...................ddwc.jjrrpcba.pm.....aa..femtiorrih..........", "..................dmddb.ptnrrjf.ljl.....baulc..cenronhg.........", ".................qmmaadcfkpjoris.t.......be......nnrnnig........", ".................epakmabll.epjnigf..............gjdtnihi........", "..................edmmmvvd...etiijjpe...........he..eigh........", "...................emppamklquc..torrom..........h....igf........", "..................lmpjpmpacseec.fjorooj.........f....gf.........", "..................dpjjpppfckkefc.toooojth.......................", "..................mnjpjjm.udefcq.foinjteig......................", ".................dpjdknjbqq...qqu.nkhhp.gg......................", ".................apb.djp.uwlwwll.qi.gghg.f......................", "................bpduuqkpqlwwddwwufg...gg........................", "................amllllddwdbddwlwdff...f.........................", "..................qwddluvvvwluldvd..............................", "..................ldvvddvvbq..wvvvd.............................", ".................ubvvvvavvl.qlwdvvvw............................", ".................ldvmgaavdq..lwbvvavw...........................", ".................lvkfcvmvl...ulddvmmv...........................", ".................ld.gsamvu....lwvvamaw..........................", ".................lufhgevd.....ulwvvmwul.........................", ".................ucgnhsvw......llvvvgh..........................", "................qbshoieal......uwbvfirm.........................", "...............udvejrnsv........uwuciot.........................", "..............uvvwkjoobv.........uqshtf.........................", "..............vvvdkpield........quseks..........................", ".............vvuevvkdwl.........uqttis..........................", "............dvlcmvvblwu.........llktjf..........................", "............lcccmvvwwu..........llvmpbl.........................", ".............ffcfvvbw...........wwvdkvw.........................", "............ekks.dvdl..........udwbddvd.........................", "...........ktptc..vvu..........wlwwwvvvw........................", ".........qetpjf....w...........w.duuvddw........................", ".........esmnm...................vuuwd..........................", ".........edmt....................uskb...........................", ".........fike.....................skb.hs........................", "........us.ff....................lcfhhsf........................", "........eftftf...................feescf.........................", ".......feepkefc.....................cskkkf......................", ".......eektempps.................uffsekttktk....................", ".......fbeektmme.................cfffsekkktke...................", ".......cc.lsekke.................ses..lbsekke...................", "................................................................", "................................................................", "................................................................"]];
  const IMG_mace = [{"a": "#524547", "b": "#806868", "c": "#51302b", "d": "#67595b", "e": "#6a2f2a", "f": "#421313", "g": "#5d4644", "h": "#4b3e3f", "i": "#72483f", "j": "#5f1716", "k": "#7a5c56", "l": "#463738", "m": "#987e75", "n": "#302424", "o": "#201313", "p": "#342829", "q": "#432c28", "r": "#231e20", "s": "#2c1515", "t": "#171314", "u": "#372f32", "v": "#1f191b", "w": "#2f1f1d", "x": "#0f0b0b", "y": "#140f0f"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "...................................................a............", "..................................................b.............", ".................................................cd.............", ".............................................cefggdh....if......", ".........................................d...jfckeekblkmc.......", ".........................................dmk.nopnfjjimef........", "..........................................cbbdqmejojfjfp........", "..........................................lplrikmeeofson........", "...........................................rtldjjiipkirp........", "......................................mh..rtubbkggiqhisvp.......", "......................................hbbnugpnbdbhcpojfvab......", ".......................................haalikeoaahrw.ffv........", ".......................................pupkmbfddunl..ss.........", ".......................................rhhbiepmd.rvvofq.........", ".....................................uradbbciwrtx.vnncia........", ".....................................phflmddcnyo..r..hgm........", ".....................................giejndhlooyttn....eg.......", "....................................diejijvulvyo.vlg....f.......", "..................................llgdfeejo.oryvp..g............", "..................................ubcdbffst.pp..g...............", "..................................prbbaaytrvn...................", ".................................lnbtaupr.tgd...................", ".................................cmuy.uvn.phba..................", "................................qbpnah.nn...am..................", "...............................wkicwhtxu.....l..................", "...............................ekcno.tv.........................", ".............................cjicno..u..........................", "............................dqjfwo..............................", "............................mmdro...............................", "...........................dgbgu................................", "..........................mmmhr.................................", ".........................fhgll..................................", "........................jfmln...................................", ".......................iecdn....................................", "......................ligru.....................................", ".....................dmqwyp.....................................", "...................rduauy.......................................", "...................bda.p........................................", "..................kaarr.........................................", ".................bmdrr..........................................", "................bmkur...........................................", "...............clbdh............................................", "..............nicvu.............................................", ".............ccnsvg.............................................", "............cccwxra.............................................", "...........ecqo..u..............................................", "..........qicwy.................................................", ".........ecqoy..................................................", "........qccns...................................................", "......hblqsy....................................................", ".....hubavw.....................................................", ".....dbrrn......................................................", ".....uhut.......................................................", "....g.ruv.......................................................", "....wqstr.......................................................", "......ysywo.....................................................", ".......q..w.....................................................", ".......nw..w....................................................", ".......wc.q.....................................................", "........ncs.....................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................"]];
  const IMG_dblade = [{"a": "#854ec5", "b": "#a77fc3", "c": "#d8a9f3", "d": "#3f2e5d", "e": "#786582", "f": "#6a5081", "g": "#ab67e7", "h": "#574966", "i": "#4b218c", "j": "#3f236d", "k": "#6e39aa", "l": "#43345a", "m": "#5e3a8d", "n": "#34265a", "o": "#5c3098", "p": "#9b4fe7", "q": "#5e22af", "r": "#843cd1", "s": "#4a3c5c", "t": "#311b5a", "u": "#31263e", "v": "#231b2c", "w": "#1e1430", "x": "#160c27"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", ".............................................................a..", "...........................................................bcd..", ".........................................................eccb...", ".......................................................fcccc....", "......................................................bccccb....", "....................................................bcccggc.....", "...................................................gcccagch.....", "..................................................gggaigcb......", ".................................................agijiacc.......", "................................................kgllmjgce.......", "...............................................agddinopa........", "..............................................kgnlinjpk.........", "............................................egaldonhpk..........", "...........................................dphnnmnjgo...........", "...........................................aknnodjpm............", "..........................................mpdnkjdpf.............", ".........................................kgmdkjnpm..............", "........................................bgmjajnka...............", ".......................................ponjpjjqg................", "......................................pkjdrjopm.................", ".....................................piijriop...................", "....................................rjqirijpd...................", "..................................drnoqpijrs....................", ".................................jknjprjnrm.....................", "................................jknnrknnkk......................", "...............................oknnqrtnkk.......................", "..............................bmjqipinqk........................", "............................fomukrgqnqk.........................", "............................khntpppjok..........................", "...........................jknirriqik...........................", "...................h......ornipqitia............................", ".................ee......aojjrqinsa.............................", "...............sehv....bbmiprpqnlo..............................", "..............bhod.....dnjqrqpjjka..............................", ".............enmjh.....hnrrprqik................................", "............edjjhfhhheestjoqijk.................................", "............m...wlbhhnwsehjjdk..................................", "................lwhlhhsfewhhfk..................................", "...............u..sdkggolulwa...................................", "................vuulqcginsv.....................................", ".................xvsrprmth......................................", ".................ulfjjnhwe......................................", "................veehuvulhe....s.................................", "................dheuvvvvses..eu.................................", "..............xjulvl..v.xslefe..................................", ".............xwktx.......djqfu..................................", "............xtoww........toih...................................", "...........xijww.........jtfh...................................", "..........xttjw..........mfd....................................", ".........xtktx..........mm......................................", ".........tiwx...................................................", ".....u.wssww....................................................", "....shhhauv.....................................................", "...suwlenw......................................................", "...vikollx......................................................", "...npgjuhs......................................................", "...kcrtvu.......................................................", "..najduuv.......................................................", "..mn............................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................"]];
  const IMG_fblade = [{"a": "#984b23", "b": "#731f13", "c": "#d68535", "d": "#530b08", "e": "#f0ba4d", "f": "#c85824", "g": "#e79c39", "h": "#f8d55f", "i": "#c5431c", "j": "#76503a", "k": "#a12c1c", "l": "#a16f41", "m": "#971811", "n": "#362527", "o": "#56190e", "p": "#cf722c", "q": "#6d3a28", "r": "#542c1c", "s": "#321510"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "............................................................a...", "...........................................................bc...", "..........................................................def...", "......................................................a..dgeb...", ".....................................................aa.beehd...", ".....................................................idahege....", "....................................................dahhggec....", ".................................................jkaehelcgha....", "...............................................m.lhhhljkgchd....", ".................................................cglnjkfcgg.....", "................................................beljjimfgea.....", "............................................aa.oehjjbipggho.q...", "...........................................bcdqeelqdkfehec......", "..........................................fgheeljqboigemkb......", ".........................................ahecljjqmbigeb..ba.....", ".........................................gpjjnjbimkcem..gc......", "........................................bgljlbqfkkfep...........", "........................................ccqrkdsfkaghd...........", "......................................bbckabibslafec............", ".....................................k...llbksrbighkbk..........", "..................................dbiiaqclnmmaifgghda...........", ".................................i...qhlqjbkqiceckb.............", "...............................oi....ccnjrqrigha...p............", "................................klacgejn.lakghb...aq............", ".................................chljrsdlqigeb..................", ".................................annobddckchb...................", "..........................b.....llnjkkoqpfef....................", "..........................pehelclrjqiosqfgem....................", "......................a...fpplrarjqoqaiichaba...................", "..................l...k....cprnaaqbbapggghd.....................", ".................e........lclnkosmbaggabcl......................", "................cc......rlljnobbokqgg.....m.....................", "................cb..b.jljjrnnlaikopeo....m......................", "...............jfjl...sllljqggkmkrgc............................", "...............a.sjlclrjaorlcabjaaeq............................", "..................nnnjlbliimaojaifh.............................", "..................b.nnamfegmlrqa.ph.............................", "..................a.nrfiehfmlqr...h.............................", "..................pplraigfmblr....l.............................", "..................e.oqapkmlalr..................................", ".................l..alaoqqrqcr.l...o............................", "..............k....rclqqassnlpfe................................", "..............k...jjoas.aa.njcpg................................", "...............m.njlnr..gb.nljac................................", "................rknrs..al....apcfb..............................", "...............nnmd..........bga................................", "..............sjjs..d........ae.................................", ".............nbks...b........gj.................................", "............sjnd...kk.......a...................................", "..........aljks..b..............................................", "........jjjlls..................................................", ".......olllqqr..................................................", ".......plfqqr...................................................", "....p.pjfpjr....................................................", "...badgjqaqaq...................................................", "...k.agffp......................................................", ".....ega........................................................", "..o.al..pp......................................................", "..b....ma.......................................................", "...f..b.........................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................"]];
  const IMG_lantern = [{"a": "#6c5032", "b": "#a28557", "c": "#57422b", "d": "#828464", "e": "#746545", "f": "#3b6442", "g": "#1c4929", "h": "#4c4f38", "i": "#3f8356", "j": "#9ca691", "k": "#6ea87e", "l": "#3aa765", "m": "#bdcfaf", "n": "#59c77e", "o": "#5de791", "p": "#906a3c", "q": "#b3f8c2", "r": "#473424", "s": "#233120", "t": "#bdb493", "u": "#2d241b", "v": "#0f2214", "w": "#1b140e"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "...............................a................................", "...............................bb...............................", "..............................cdb...............................", "...............................e................................", "..............................fgh...............................", ".........................i..jkglgij.............................", "...........................mngiooglmecbb........................", "......................pbp.dklfloqnikj.rre.......................", ".....................ra...dnfnoqqqind..spt......................", "....................ac....hiennooniih...htb.....................", "...................aph....ppfloqonfeba..abpd....................", "...................edh....cbtenmoittbr..jdep....................", "..................udmme....rcrapbpcc..hmqte.....................", "..................udjeabbpphaachapahpbbcjmj.....................", "..................rddracaaaapbceubbpapbpemt.....................", "..................jdd.rccaaapachuppppppe.ttmh...................", ".................dmmd.......suusuu.......dmmme..................", "................hkitj....i..rurcecf..i....mjik..................", "................jjijd......scpbbttbg......jkijd.................", "...............gjmmm.......suurchrhf...ijv.mmmk.................", "...............fikmm...fi.ccrgfiigsee.kqqj.jmmdg................", "...............iikkk..ikihcpaapdddapb.gkmf.hmkif................", "...............eejli..kgfgcarhfffhraa..gf...klid................", "...............h.jmf..knvgshfgfligfh........lkjj................", ".................eme...kknfdlilolilk........kmhh................", "..................t.....gonknlnqolnlf.......mj..................", ".........................lgkoqqqqqoolg......jd..................", ".........................lgdnoqqqonnnof.....je..................", ".........................kfelloqolllifm.....h...................", ".....................fq..fmkllnoonoqigo.........................", "....................fkqk..fjqooqoqqngi..i.......................", "....................iqqqg.seloqqqoleg...........................", ".....................fqg..adoqqqooldbg..........................", "......................g..fepiiillihae.o.........................", "........................k.ceaebttdapc.ii........................", ".......................i..rpccpbtbab..kf........................", ".....................i..f...wwuru.u..if.........................", "............................uurpbr..............................", "............................ucaiep..............................", "...........................hppfnkbt.............................", "...........................ucciiica..g..........................", "............................urrlha..iqi.........................", "..............................cca...iqf.........................", "..............................ua.....g..........................", "..............................ree...............................", "..............................rpc...............................", "...............................p................................", ".............................c.cc...............................", ".............................p...a..............................", "..............................cdc...............................", "...............................m................................", "..............................hmd...............................", ".............................hemj...............................", ".............................ddmm...............................", "............................hdjij...............................", "............................dimik...............................", "...........................gkfkkm...............................", "...........................edfkkk...............................", "...........................e..jtk...............................", "...............................tj...............................", "...............................j................................", "...............................h................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................"]];
  const IMG_potion = [{"a": "#1d3587", "b": "#878ea1", "c": "#0d3ae0", "d": "#93bdd9", "e": "#2068e3", "f": "#278ef2", "g": "#a5f2fc", "h": "#2252c9", "i": "#27cdfc", "j": "#0b2298", "k": "#916a4c", "l": "#805940", "m": "#4a2d26", "n": "#030730", "o": "#3d2d31", "p": "#6b4233", "q": "#635963", "r": "#38221f", "s": "#5a3d34", "t": "#251b20", "u": "#423e61", "v": "#191213", "w": "#04106b"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", ".............................ab.................................", "............................acdb................................", "............................ecfgf...............................", "...........................efcdggh..............................", "..........................efceiggfa.............................", ".........................affciigggd.............................", "..........................chhedggec.............................", "..........................cchccdfhj.............................", ".........................kaccccgfca.............................", "........................lmnceecgfeok............................", "........................pkkqjeegeqbbl...........................", "........................mrlqhhhdblmkm...........................", "........................orkskbdgbktl............................", ".........................ulrmmpkkpr.............................", "..........................uttmplmr..............................", "..........................utttmlsmt.............................", "....................dd....ttrslkmt.m............................", "....................be....uvtrrrsmrm............................", "..........................urrrmps.rvm...........................", "...................w...ww.utrslpmr..trp.........................", "......................eew.utttrmrv...tr.mm......................", ".....................hfw..baaauuom...ptm.sl.....................", ".....................ffw..uaahaqlp...lps..rp....................", ".....................jih.umooskbkm....rl...rm...................", "......................jffhoosskkpvp...slkl..rm..................", ".......................nhhhatrmskpk...kuao..rsr.................", "........................uoroplkdbpsk.ukaeal.tsp.................", "..................n.....hvrspppdkntrs.lhfes..pmm................", ".................wdj...baannuslbshanm.luefap.smr................", ".................bgdw.bhaaahawukojfau.tlheul...m................", ".................wdj.ubaaafeehaohhiauq.lkuk.v...................", "..................w..duaaedffeehfdaaab..oklvt...................", "....................kaaahedffffffdhaaad.....tr..................", ".................waolaeiiiifeccceddceabb....rm..................", "................hfhslcjeigiiffecefgffead....tmm.................", "...............aijulueccceefeeeefdggdiffa...trp.................", "...............aeaqrnjjcefeccccefddgeceidh...ppm................", "...............wfbpwjcejjccccchjjccdicjhfiw..psm................", "................wblajchjjcecjjjjcccigfhhafa..smr................", ".................bkacccjcfgfccccccfgiejhhfn...mr................", "................qqlujeicegggfefeffigejjban.a...r................", "................bllkkjiceigifiiiiigfcjjd........................", "................lrrlkkheeiiiiiiiggfecjjb........................", "................ttvtskuccfiiiiggififjhaq........................", "...................aalwcceiigggiificjhak........................", "...................bhlocfiiiiiiiieejeaokl.......................", "................fa.qhukwceefiiifecchhtskk.......................", "................bw..bhqojcccfifcccjhukkpp.......................", "..................n.qhupjcceifcccjcqkksow.......................", "..................b..balwccigieccjwolm.adj......................", "......................ulocccfchccjwps.ndgdn.....................", ".....................musswjceabqjwopo..jdw......................", ".....................ltoltonoqkksmmml...n.......................", ".....................psrspssppskkpsps...........................", "......................tsppsmsufqlkkt............................", ".....................mrtrskmphefsrtpl...........................", ".....................kptvttmrseumtvmkk..........................", "....................klmrv.t.mmpst.vtsk..........................", "....................ppr......rsr...vrk..........................", "....................ml........m.....mk..........................", ".....................l..............ss..........................", "....................................m...........................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................"]];
  const IMG_magma = [{"a": "#8e5141", "b": "#936c59", "c": "#7e6253", "d": "#b38c73", "e": "#9a7964", "f": "#69342e", "g": "#714f44", "h": "#563c36", "i": "#5f493e", "j": "#552e2a", "k": "#453530", "l": "#402e2b", "m": "#1f1014", "n": "#140f10", "o": "#2f0f15", "p": "#17070b", "q": "#211919", "r": "#491b1d", "s": "#4e0d16", "t": "#6e1317", "u": "#2d1b1d", "v": "#871517", "w": "#310910", "x": "#382726", "y": "#a71a18", "z": "#2e2121", "A": "#993023"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "....................ab..........................................", "................cddeafdb..gde...................................", "...........hibbgjklmnmijl..ibd..................................", "........cdglomoomomommppqgirgae.....................i...........", "......edfssttsstsoomommukgkgt.......................cb..........", ".....eavvtvstvttwsssoxichxmru...........eg...ge....lt...........", "...eei.t.vyyyvtstsrxunponmzkg............ed...lighiroh..........", "..c......vy.yyssfhupowsmmklg..............aedeczcbkn.kg.........", "..........yvvsogioosssomlc.h........e.....hjhcijcaaxnpmlh.......", ".........Ayvoxjusstwwoomguplc.......jfibebchm.mljaeanmmomih.....", ".........yvxuwsstvswswmorpmld.........vrghmnn.cegffechoosohg....", "........ttxstvvyyttswosoqmmze..........fjuzzs.hzotfhcgowsssce...", ".......gjjsvytyyyyrostszmoomcg..........aukmonkbjdvxuxmssttrc...", ".......dftvyytyyytosvtsxowoxffx........guxusll.hcAfmnmqsttvtfc..", "......bityvyvyyyvot.yvrxsssmqzkid...c..hxjujc...igAqmwqstv...d..", ".....gbst.....Ayovyyyvlwtssompmqcd..ge.jmkufg....cjumswryt....c.", ".....di.......Artsy.vvztvsstsmpmqgfkredkxirreh...izsotsuy.....c.", "....gg........Ast...ytsyytsttwmpzzulqjeecbufdi...pmsotvrt.......", "....e.........a....yyrv.ysvttswmp.nxdllideothg.cqmwtrtvst.......", ".............h.....tysv.....stsoom.ibdirecjfAfcdowstst.tj.......", "...................yts.........smmlixccfbdttvAcgwwvwttyyr.......", "...................tt.....fcbhumwppqhxdoxevAAvbxhtsytvtyjj......", ".........A.........v.......ruzxm.oolxuimcjtAdAgi....vy..tg......", "........A..........t....bgroziquruqkhhq.gjtyAvle....tt...e......", ".......AA...............utozcczqnlkzxx.mufftAsg.....v....d......", "....c.AbvfA...........hfsqmxeezi.xhhq.nuohabfuk..........b......", "....cvcgfA.........gegfrqnqfcikudbehfmnlkhbannlq.........g......", "...cvfcft...........kfrznqqrhrlnieedfxnigic..qzz................", "...faAj...........ilrxmmqc.qfrqn.kjdb..g.i...qnqii..............", "..csaAs........c..kfrqnkieiqlq..zcrfe........lxice..............", "..fiAsfh...bc..iearxrmnbgczzkq...zxfgs.......hjorb..............", "...tfraaxbh.cbxlrxlmnuzejbxxk....qquva.........sjgg.............", "...tfrhgjjfrrjtjxqooxhjfrh......xzlzade..........zhAb...........", "....tt.gjuuqrquoqruhh.jot........kjxcib...........khd...........", ".....A...iiijhxgkgk...joj........lrgzstx..........qcjl..........", ".....................chgbx.......klkxsbhhg.......hzhkjlg........", "....................dhzzecc........eckbblce.....k...xiege.......", "...................g.....g.h.......dl.cd..e..........qlb.h......", "...................................h...d........................", ".......................................k........................", "................................................................", "................................................................", "................................................................"]];
  const IMG_sdrake = [{"a": "#644d42", "b": "#74625a", "c": "#b78956", "d": "#b19f81", "e": "#916a4b", "f": "#5c4132", "g": "#112e80", "h": "#3b323a", "i": "#1c2138", "j": "#0d226c", "k": "#2b92db", "l": "#1243a4", "m": "#3f4461", "n": "#0c142c", "o": "#4b6089", "p": "#2db4eb", "q": "#141a35", "r": "#302728", "s": "#1563c5", "t": "#0a194c", "u": "#040932", "v": "#32d1f4", "w": "#8b8788", "x": "#9ac7c6", "y": "#18171e"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................", "...............................ab...............................", ".............................cca................................", ".........................b.bdef.....g...........................", ".......................echieef......gj.b........................", "......................aahiacc........klma.......................", "..................eecefn..cea.....g..opgd....l..................", "...............ecefiq...qrrf......gs..tsbc...kof................", "..............baeainn.tth.ee......uvj.tkmece.ml.e...............", "..........g....eainqqjth.na........glowkobeccwloe...a...........", ".........ko..bccrttttjirnqf........ookkkljihaexsw....d..........", "........jkodcehnqjtjljhqnif......s..skssxlawbhcobab..ea.........", "........s.kaerqtttgsgaqtnia.....op..jkklgoebaffcbka..aa.........", ".......ogjkhntjttlsjbftqnic.....tl.mpslgbmbmifaodsa..eb.........", ".......kkvwqtjjsjgjmcqjtqic.....tkugpslodmg.mffmobm..cea........", ".....gsxwhtjjgpgjggeejttqhc......kppssldagnqihadbmo..ecra.......", "....lpkwftggllgjllletgjqirea..lj..olkswbmhqhomhmbdm..eana.......", "...okgwehllsslllssmhggjinnie...l...ksslmcrhbwb.......eytre......", "...xgwwjlgsvsllslsiggjqtjniea..ksggppkswenibww......fyrt.hca....", "...xmdmllsvvpsslsltlgttsltqfc....oxplpsofriedd......anrtnqf.....", "...ldbssskppvsslkbgsljgkjjtrccf.....skksmiimdd.....ahnritna.....", "...aclskppvvskssdmlkgllgggtqeac.e...jlvsoinmwxd....eqqihgqrc....", "...cokkpppvpskskcmspsslslgtiqqacad..b.opshqlwxxb..caqttmltnhe...", "...cspvkjxvvpkkwessspkslsltqnqqqhacadf.kmhqlmwxxbchiitjagjqh....", "..cwpvp.gxpvvppdokkkvkkssgijljq.qihbccaoqhijodxxwbqntjiejgth....", "..dpvg...ojsvvkwkpvvvvppkmlslltqyiqnhccrnresobxxd.tjtghejljae...", "..dv.......ovvokpvvkllvpkoskslgqne...fcc.fckjbxdwamjtgtbgggtd.g.", ".cx........tvvbvkll...svkkpppsgtjhcceefcccaxbfdwdmegjljoljgjmxp.", ".d..........oxkvtj.....vpvkospllltfcca.ffdebdaccowcmlsjslglghbk.", ".d..........wdvt.......xo....lskltrecfnq.fcileedkxcossjslskgmeg.", ".b..........dwg.............ehkgtn.rh.imircyggmekvemssmssppljb..", "............do.....kps....bbhrjtnn.efqimmqeiwmsedwfdsswssvksle..", "............w......upklbwemiiinrnrn.aqmmomfqbxmjecqwkowssvpssb..", "....................spsghyimiqraerqn..immmyihxwsawmpkowskppssb..", "..................wxvkbefrmqiqhhmgiiqqnmom.qhwxobmgvpospvppkkb..", "..................bmlmeeyqqqafrrgsswhriim.qimxwhb..kvopvvvvpkb..", "......l......b.feemoee.ynqqieeinqqtohehin.iwwwb.i..ovovlokvvpw..", "......gp.....aaahafe..qqinniechimohaifcebmoww..n...mpvk.tjkovc..", "......vp...ewoljin.qqtjiminifcaiqmoaanhecamm.nnqh...xvt..lj.vc..", ".....lp....bjttqntjjgmoomqqiace..n.heiihde...qnihc.hxt..tj..pc..", "....ol...bdljqtjggoowowmfrqaewb..n..eaqiac...riqheemt.......wa..", "....k...cmbqjjoowwwwwo..eitbwpm...iqnffqhe.....fhfe.........d...", "...ls...eljgowwwwmm....afitokk....riqqhrimf......hab........c...", "...kx..cajjwwm.........ahtjpo....riqqim..hbb.....mmc............", "...os.aemjoo...........fhi.......rfitto..hcc....fotma...........", "....s.ohmoo.....gj....rab........ffr.....hhb....e.jom...........", "....jlmmjoo.....os....faa........frar....qomom....omo...........", "...mtslwoko..o.usx....ri...........hr....hwtcb....cfc...........", "....gklowo..ksopvg...qim............iii..fc.cef...c.c...........", "....gkgobo..spspkg...ommm...........goga....ff...f..a...........", ".....plljwkkslspklt.bbbac...........jbbbe.......................", ".....kvslmxolkxvpvxjw.bere............c.e.......................", "......lvpllglllspvlgm..a..............f.........................", ".......kjvsksskskpvl............................................", "........tgkkokkvvvvvg...........................................", ".............gpjmgopxt..........................................", "....................oo..........................................", "................................................................", "................................................................", "................................................................", "................................................................"]];
  const IMG_smage = [{"a": "#40146d", "b": "#8c4aa2", "c": "#7c5bae", "d": "#1c0e59", "e": "#4c11b1", "f": "#402899", "g": "#2f0f76", "h": "#8131d3", "i": "#612bcc", "j": "#150549", "k": "#b999e1", "l": "#a171bf", "m": "#2a1044", "n": "#a95fb9", "o": "#65479f", "p": "#1a0c3b", "q": "#663063", "r": "#43253b", "s": "#150a22", "t": "#060130"}, ["................................................................", "................................................................", "................................................................", "................................................................", "................................................................", ".....................aa.........................................", ".....................ab.........................................", "...................c..deef......................................", "..................ffghhihe......................................", "..............gj...diklj........................................", ".............gkh..dehgj.........................................", ".............gig..eihieeg...fm..................................", ".................ehkknhefif.go..................................", "................inkkkhhhg.ff....................................", ".............f..hkhhkhihed.id....agf............................", ".............aoekhikkkihlgdog...efgpf...........................", ".............fignhikkhiihglf...oegmpd...........................", "............if.ehhiilhhligi....iigp.............................", "............h..fhkkihhkke..a..olqfm.............................", ".............o..fhkkkkkefg....blqqam............................", "...............g.fihkhegfle..oq..qra............................", "................qcdlffa.ehi..b....qra..o........................", "...............jlhfcoo...ig.b..c.ogqq..o........................", "................hhhlkfa....rsj.d.....q.......ag.................", ".................hhhhko.....rrm....spsq....jgnnf................", "...................eei....llqqrp...pqr....gehlko................", "....................ggq.oqamqqqbq..rr...gd.gkkkg................", "....................mrqbbkkom.rqbrbqqq..fgtekhhdg...............", "....................amrrlaqqqm.rrqhcrsq....clcd..f..............", ".................fg.r.ppqoarqaprqokkqraa...aj....o..............", "..............gi......s.qigpqqqrrfhkarqq........oa..............", "..............h.....qp..qfgd....rricrrsmd..gfffa................", ".............ahf.a..qrsqbggps.rrsraq..rqqr......................", "..............flg...brmnqdpp..qrrrqrr..pd......o................", "................ohf.qrqqmpm.ssqr.qrqsrpggf...c.cc...............", "...................fnqqrjpppsqqqrrbrsqpdffbq.hlkoh..............", "...............bq...bqrjggdmrqaq.qqqrmqdabaefhlkh.ao............", "..............ahhp.rqr.ihiioqbqrsrbq.qqmqrgeikkhe.af............", "..............blla.q....fiollcnddrqqsqrqr...eie..jo.............", "..............allj.....mf..mqnciedbrarqqrpd....jfc..............", "...............hh......ba..rb.ggihfgg.qbq.dg....................", "...............ml..o..fdppq..pg.jgcig.qqq..dg...................", ".....................agdrb.ppgg.pggff..bq.ppgfa.................", "...................aeggpbqppdgmpdgiedg..r.psdfeea...............", ".................aobqgdmrmmdff.pdehigg...qpppgmp................", "................rblnqdgddqmgefppmgihgdi..qqjpp..................", "................qq.rrgggdabfa.mqaghigaef..qjdpp.................", "................r...qafgdmb.....ehcegaec.....j..................", "....................qbfgaqa...giheieeehog.......................", "..................a..nqqqmffeiefehigeikg..qhm...................", ".....................qqq...heeegiieihkf...hhb...................", ".....................qr...ig.eeeeihkkf...akkh...................", ".................f.......ieg..geihklga...hklq...................", ".................aka.....cgg..eihkig.bo.ahhn....................", "..................if.....df..iiliegh.....biq....................", "...................o...o..ffihoeegda......b.....................", "........................go.ehfgee..qqq.o........................", ".......................i...hhgeiie..............................", "......................if...olie.chh.............................", "......................hg.....ehf.kio............................", "......................ihffd..qhdhki.............................", "........................fcij..ihkhl.............................", "............................tokkh...............................", "............................fklg................................", "............................chg.................................", "............................dij.................................", "..............................g.................................", "................................................................", "................................................................", "................................................................", "................................................................", "................................................................"]];
  /* ---------- متن انگلیسی کارت‌ها (ti: عنوان کوتاه روی کارت، bl: توضیح روی کارت، st: داستان، hw: روش بازی) ---------- */
  const CT = {
    knight: { ti: 'KNIGHT', nm: 'Knight', bl: 'Armored fighter. Strikes straight ahead.', st: 'Sworn to the keep, he never leaves his post.', hw: 'Moves 1 cell forward. Attacks the cell directly ahead.', tp: 'A solid front line. Pair it with a Shield or Sword.', tpFa: 'خط مقدم محکم؛ با سپر یا شمشیر ترکیبش کن.' },
    ninja: { ti: 'NINJA', nm: 'Ninja', bl: 'Leaps over foes, then strikes.', st: 'Seen by none, felt by all.', hw: 'Leaps 2 ahead or 1 diagonal over any card, lands on an empty cell, then strikes ahead.', tp: 'Hunt archers and supports. Avoid golems.', tpFa: 'کماندار و پشتیبان‌ها را شکار کن؛ از غول دوری کن.' },
    archer: { ti: 'ARCHER', nm: 'Archer', bl: 'Shoots from afar, even diagonally.', st: 'Every arrow finds its mark.', hw: 'Hits cells 2 and 3 ahead and both diagonals 2 ahead. Deals 1 less damage to adjacent enemies.', tp: 'Keep a blocker in front of it.', tpFa: 'جلوی او حتماً یک مدافع بگذار.' },
    dragon: { ti: 'BABY DRAGON', nm: 'Baby Dragon', bl: 'Breathes fire on several cells. Flies over cards.', st: 'Small, hot-tempered and proud of its flames.', hw: 'Flies 2 ahead or 1 diagonal over cards. Flames hit ahead, both diagonals and 2 ahead.', tp: 'Great against groups. Only 6 HP, so protect it.', tpFa: 'برابر گروه‌ها عالی است؛ جانش کم است، محافظت کن.' },
    skeleton: { ti: 'GOLD BONES', nm: 'Golden Skeleton', bl: 'Gilded warrior. Tough and relentless.', st: 'Gold seeped into the bones and the bones refused to rest.', hw: 'Moves 1 cell forward and attacks the cell directly ahead. High HP and solid defense.', tp: 'Hold the front line with it.', tpFa: 'خط مقدم را با آن نگه دار.' },
    mage: { ti: 'MAGE', nm: 'Mage', bl: 'Casts arcane bolts at range.', st: 'Her staff hums louder than any argument.', hw: 'Hits the cell ahead, 2 ahead and both diagonals ahead. Fragile in close combat.', tp: 'Keep her behind a Knight.', tpFa: 'پشت شوالیه نگهش دار.' },
    ranger: { ti: 'SWORDSMAN', nm: 'Swordsman', bl: 'Steady blade and shield.', st: 'A wanderer who learned that patience beats speed.', hw: 'Moves 1 cell forward and attacks directly ahead.', tp: 'A cheap, reliable blocker.', tpFa: 'مدافع ارزان و مطمئن.' },
    drake: { ti: 'DRAKE', nm: 'Drake Warrior', bl: 'Axe fighter. Swings wide.', st: 'Scales hardened in a forge-fire it never left.', hw: 'Moves 1 cell forward. Hits the cell ahead and both front diagonals.', tp: 'Great against crowded lines.', tpFa: 'مقابل صف‌های شلوغ عالی است.' },
    bow: { ti: 'STORM BOW', nm: 'Storm Bow', bl: 'Attach to a unit: +1 ATK, +1 range.', st: 'Its string hums with trapped lightning.', hw: 'Play on a friendly Character or Creature. Slot: Weapon. One per unit. Adds 1 range.', tp: 'Pairs well with fragile units.', tpFa: 'با کارت‌های شکننده خوب است.' },
    zombie: { ti: 'ZOMBIE', nm: 'Zombie', bl: 'Shambling undead. Rises once.', st: 'Once a living soul, now just a shell.', hw: 'Moves 1 cell forward and bites the cell ahead. When defeated, returns once with 1 HP if its cell is free.', tp: 'Cheap blocker; do not trust it alone.', tpFa: 'مدافع ارزان است؛ تنها رهایش نکن.' },
    fireball: { ti: 'FIREBALL', nm: 'Fireball', bl: 'Deals 4 damage to an enemy.', st: 'A little sun with a bad temper.', hw: 'Pick an enemy card. It takes 4 damage.', tp: 'Finish off a wounded unit.', tpFa: 'واحد زخمی را تمام کن.' },
    icesh: { ti: 'ICE SHARD', nm: 'Ice Shard', bl: 'Deals 3 damage to an enemy.', st: 'Cold enough to stop a heartbeat.', hw: 'Pick an enemy card. It takes 3 damage.', tp: 'Cheap and quick, use it early.', tpFa: 'ارزان و سریع است، زود استفاده کن.' },
    toxic: { ti: 'TOXIC ORB', nm: 'Toxic Orb', bl: 'Deals 2 damage in a cross.', st: 'Nothing grows where it lands.', hw: 'Pick an enemy card. It and the 4 cells around it take 2 damage.', tp: 'Great against packed formations.', tpFa: 'مقابل صف فشرده عالی است.' },
    bflame: { ti: 'FROST FLAME', nm: 'Frost Flame', bl: 'Attach to a unit: +3 Attack.', st: 'Blue fire that burns cold.', hw: 'Play on a friendly Character or Creature. Slot: Weapon. One per unit.', tp: 'Good on any frontliner.', tpFa: 'روی هر کارت خط مقدم خوب است.' },
    claws: { ti: 'CLAWS', nm: 'Steel Claws', bl: 'Attach to a unit: +2 Attack.', st: 'Three blades, no mercy.', hw: 'Play on a friendly Character or Creature. Slot: Weapon. One per unit.', tp: 'A cheap boost for fast units.', tpFa: 'تقویت ارزان برای کارت‌های سریع.' },
    nunchaku: { ti: 'NUNCHAKU', nm: 'Dragon Nunchaku', bl: 'Attach to a unit: +4 Attack.', st: 'The dragon only wakes when it spins.', hw: 'Play on a friendly Character or Creature. Slot: Weapon. One per unit.', tp: 'Strong on a quick fighter.', tpFa: 'روی جنگجوی چابک قوی است.' },
    pencil: { ti: 'PENCIL', nm: 'Bloody Pencil', bl: 'Attach to a unit: +5 Attack.', st: 'Never underestimate the sharp end.', hw: 'Play on a friendly Character or Creature. Slot: Weapon. One per unit.', tp: 'The biggest weapon bonus there is.', tpFa: 'بزرگ‌ترین امتیاز سلاح است.' },
    mace: { ti: 'SPIKE CLUB', nm: 'Spiked Club', bl: 'Attach to a unit: +2 Attack.', st: 'Crude, bloody and effective.', hw: 'Play on a friendly Character or Creature. Slot: Weapon. One per unit.', tp: 'A cheap upgrade for any frontliner.', tpFa: 'ارتقای ارزان برای خط مقدم.' },
    dblade: { ti: 'DARK BLADE', nm: 'Dark Blade', bl: 'Attach to a unit: +3 Attack.', st: 'It hums with a violet hunger.', hw: 'Play on a friendly Character or Creature. Slot: Weapon. One per unit.', tp: 'Pair it with a tough unit.', tpFa: 'روی کارت سخت‌جان بگذار.' },
    fblade: { ti: 'FLAME BLADE', nm: 'Flame Blade', bl: 'Attach to a unit: +4 Attack.', st: 'Forged where the mountain bleeds.', hw: 'Play on a friendly Character or Creature. Slot: Weapon. One per unit.', tp: 'Best on fast units that strike first.', tpFa: 'روی کارت‌های سریع بهترین است.' },
    lantern: { ti: 'LANTERN', nm: 'Healing Lantern', bl: 'Restores 4 HP to an ally.', st: 'A green light that mends what steel has torn.', hw: 'Pick a friendly card. Heals 4 HP, never above its maximum HP.', tp: 'Save it for your best unit.', tpFa: 'برای بهترین کارتت نگهش دار.' },
    potion: { ti: 'BLUE POTION', nm: 'Blue Potion', bl: 'Restores 8 HP to an ally.', st: 'Bottled starlight, a little bitter.', hw: 'Pick a friendly card. Heals 8 HP, never above its maximum HP.', tp: 'Great after a big fight.', tpFa: 'بعد از نبرد سنگین عالی است.' },
    magma: { ti: 'MAGMA DRAKE', nm: 'Magma Dragon', bl: 'Flies and scorches cells ahead.', st: 'Its heart is a cooling volcano that never cools.', hw: 'Flies 2 ahead or 1 diagonal over cards. Hits the cell ahead, both diagonals and 2 ahead.', tp: 'Land it behind your front line.', tpFa: 'پشت خط مقدم فرودش بیاور.' },
    sdrake: { ti: 'STORM DRAKE', nm: 'Storm Dragon', bl: 'Flies, sprays blue flames.', st: 'Where it passes, the air crackles blue.', hw: 'Flies 2 ahead or 1 diagonal over cards. Hits the cell ahead, both diagonals and 2 ahead.', tp: 'Strongest when your board is crowded.', tpFa: 'وقتی زمین شلوغ است قوی‌تر است.' },
    smage: { ti: 'SHADOW MAGE', nm: 'Shadow Mage', bl: 'Floating caster with an arcane orb.', st: 'No face, only a voice that answers questions you did not ask.', hw: 'Hits the cell ahead, 2 ahead and both diagonals ahead.', tp: 'Keep it behind a sturdy unit.', tpFa: 'پشت یک کارت مقاوم نگهش دار.' },
    hammer: { ti: 'HAMMER', nm: 'Storm Hammer', bl: 'Attach to a unit: +3 Attack.', st: 'It hums before every thunderclap.', hw: 'Play on a friendly Character or Creature. Slot: Weapon. One per unit. Any unit can use it.', tp: 'Best on tough units that survive to swing.', tpFa: 'روی کارت‌های سخت‌جان بهترین است.' },
  };
  CARDS.forEach(c => { Object.assign(c, CT[c.id] || {}); });

  /* ---------- فونت بیت‌مپ ۵×۷ (برای عنوان‌ها و عددها) ---------- */
  const GL = {};
  ('A:01110,10001,10001,11111,10001,10001,10001;B:11110,10001,10001,11110,10001,10001,11110;C:01110,10001,10000,10000,10000,10001,01110;D:11110,10001,10001,10001,10001,10001,11110;' +
   'E:11111,10000,10000,11110,10000,10000,11111;F:11111,10000,10000,11110,10000,10000,10000;G:01110,10001,10000,10111,10001,10001,01111;H:10001,10001,10001,11111,10001,10001,10001;' +
   'I:01110,00100,00100,00100,00100,00100,01110;J:00111,00010,00010,00010,00010,10010,01100;K:10001,10010,10100,11000,10100,10010,10001;L:10000,10000,10000,10000,10000,10000,11111;' +
   'M:10001,11011,10101,10101,10001,10001,10001;N:10001,11001,10101,10011,10001,10001,10001;O:01110,10001,10001,10001,10001,10001,01110;P:11110,10001,10001,11110,10000,10000,10000;' +
   'Q:01110,10001,10001,10001,10101,10010,01101;R:11110,10001,10001,11110,10100,10010,10001;S:01111,10000,10000,01110,00001,00001,11110;T:11111,00100,00100,00100,00100,00100,00100;' +
   'U:10001,10001,10001,10001,10001,10001,01110;V:10001,10001,10001,10001,10001,01010,00100;W:10001,10001,10001,10101,10101,11011,10001;X:10001,10001,01010,00100,01010,10001,10001;' +
   'Y:10001,10001,01010,00100,00100,00100,00100;Z:11111,00001,00010,00100,01000,10000,11111;0:01110,10001,10011,10101,11001,10001,01110;1:00100,01100,00100,00100,00100,00100,01110;' +
   '2:01110,10001,00001,00010,00100,01000,11111;3:11110,00001,00001,01110,00001,00001,11110;4:00010,00110,01010,10010,11111,00010,00010;5:11111,10000,11110,00001,00001,10001,01110;' +
   '6:00110,01000,10000,11110,10001,10001,01110;7:11111,00001,00010,00100,01000,01000,01000;8:01110,10001,10001,01110,10001,10001,01110;9:01110,10001,10001,01111,00001,00010,01100;' +
   '+:00000,00100,00100,11111,00100,00100,00000;-:00000,00000,00000,11111,00000,00000,00000;::00000,00100,00000,00000,00000,00100,00000;.:00000,00000,00000,00000,00000,00110,00110;' +
   '?:01110,10001,00001,00010,00100,00000,00100;/:00001,00001,00010,00100,01000,10000,10000;*:00000,10101,01110,11111,01110,10101,00000').split(';').forEach(g => { GL[g[0]] = g.slice(2).split(','); });
  const tw = (s, sc) => Math.max(0, s.length * 6 * sc - sc);
  function txt(x, s, X, Y, col, sc, shade) {
    sc = sc || 1; s = String(s).toUpperCase();
    for (let pass = shade ? 0 : 1; pass < 2; pass++) {
      x.fillStyle = pass ? col : shade;
      for (let n = 0; n < s.length; n++) {
        const g = GL[s[n]]; if (!g) continue;
        for (let j = 0; j < 7; j++) for (let i = 0; i < 5; i++) if (g[j][i] === '1') x.fillRect(X + n * 6 * sc + i * sc, Y + j * sc + (pass ? 0 : sc), sc, sc);
      }
    }
  }
  const txtC = (x, s, cx, Y, col, sc, shade) => txt(x, s, Math.round(cx - tw(String(s), sc || 1) / 2), Y, col, sc, shade);

  /* ---------- پالت‌های کارت (بر اساس پوسته و نوع) ---------- */
  const TYPE_BG = { character: ['#17335e', '#2a5190'], creature: ['#14463f', '#23796c'], equipment: ['#4a2d18', '#8a5530'], spell: ['#3a1f5c', '#6b3fa3'], support: ['#124a52', '#1f8a96'] };
  const RAR_COL = { common: '#c9a15a', rare: '#6fa8ff', epic: '#c08cff', legendary: '#ffd84a' };
  function cpal(sk, type) {
    const tb = TYPE_BG[type] || TYPE_BG.character;
    let P = { bg: tb[0], ban: tb[1], bar: tb[0], gold: '#d9a04a', goldD: '#6e4514', goldL: '#f6dc8a', parch: '#e6c488', parchD: '#a8743c', tx: '#f6ecc9', ink: '#2a1a0c', atk: '#c62839', atkD: '#6a1020', def: '#2a62ae', defD: '#102f5c', grn: '#2f8f46', grnD: '#12441f', teal: '#1f8a96', tealD: '#0d4047', yel: '#e0a82a', yelD: '#6e4a08', wall: '#2d3340', wall2: '#1e222c', mort: '#14171e', floor: '#4a3524', floor2: '#352417', gem: '#47d4e0', gemD: '#0d4047', val: '#f6dc8a' };
    if (sk === 'ink') P = Object.assign(P, { bg: '#d8c690', ban: '#cdb97c', bar: '#cdb97c', gold: '#5a4630', goldD: '#2b2013', goldL: '#8b7550', parch: '#efe1b8', parchD: '#8b7550', tx: '#2b2013', ink: '#2b2013', atk: '#b45309', atkD: '#4a1d0c', def: '#5a4630', defD: '#2b2013', grn: '#6b6b2a', grnD: '#2b2013', teal: '#5a4630', tealD: '#2b2013', yel: '#b8861b', yelD: '#4a3208', wall: '#bfa96a', wall2: '#a3894f', mort: '#6f5b3a', floor: '#a08a52', floor2: '#7a6540', gem: '#efe1b8', gemD: '#2b2013', val: '#b45309' });
    else if (sk === 'term') P = Object.assign(P, { bg: '#031a0a', ban: '#0a3a1c', bar: '#052a12', gold: '#22c55e', goldD: '#0a4a24', goldL: '#86efac', parch: '#052a12', parchD: '#15803d', tx: '#4ade80', ink: '#4ade80', atk: '#16a34a', atkD: '#052a12', def: '#15803d', defD: '#052a12', grn: '#22c55e', grnD: '#052a12', teal: '#15803d', tealD: '#052a12', yel: '#86efac', yelD: '#0a4a24', wall: '#052a12', wall2: '#031a0a', mort: '#0a3a1c', floor: '#0a3a1c', floor2: '#052a12', gem: '#86efac', gemD: '#031a0a' });
    else if (sk === 'dark') P = Object.assign(P, { bg: '#0b0b0d', ban: '#1d1f2a', bar: '#14151b', gold: '#8a93ad', goldD: '#2a2d3a', goldL: '#c9d1e8', parch: '#1b1d25', parchD: '#3a3f55', tx: '#e8eaed', ink: '#e8eaed', wall: '#141620', wall2: '#0d0e14', mort: '#05060a', floor: '#1a1c26', floor2: '#101119' });
    else if (sk === 'glass') P = Object.assign(P, { gold: '#e6f4ff', goldD: '#3b6a99', goldL: '#ffffff', parch: '#cfe6fa', parchD: '#6d9cc9', ink: '#0f2a4a', tx: '#eaf6ff', bg: tb[0], ban: tb[1] });
    return P;
  }
  const R = (x, X, Y, w, h, c) => { x.fillStyle = c; x.fillRect(X, Y, w, h); };
  const chamf = (x, X, Y, w, h, c, k) => { k = k || 2; for (let i = 0; i < k; i++) R(x, X + k - i, Y + i, w - 2 * (k - i), h - 2 * i, c); R(x, X, Y + k, w, h - 2 * k, c); };
  function disc(x, cx, cy, r, c) { x.fillStyle = c; for (let j = -r; j <= r; j++) for (let i = -r; i <= r; i++) if (i * i + j * j <= r * r + r * .6) x.fillRect(cx + i, cy + j, 1, 1); }
  function frame(x, P) {
    chamf(x, 0, 0, 96, 136, P.goldD, 3); chamf(x, 1, 1, 94, 134, P.gold, 3); chamf(x, 3, 3, 90, 130, P.goldD, 2); chamf(x, 4, 4, 88, 128, P.bg, 2);
    R(x, 6, 1, 84, 1, P.goldL); R(x, 1, 6, 1, 124, P.goldL);
    R(x, 7, 7, 82, 1, P.goldD); R(x, 7, 128, 82, 1, P.goldD); R(x, 7, 7, 1, 122, P.goldD); R(x, 88, 7, 1, 122, P.goldD);
    [[7, 7], [88, 7], [7, 128], [88, 128]].forEach(p => { disc(x, p[0], p[1], 6, P.goldD); disc(x, p[0], p[1], 5, P.gold); disc(x, p[0], p[1], 3, P.goldD); disc(x, p[0], p[1], 2, P.bg); R(x, p[0] - 1, p[1] - 1, 1, 1, P.goldL); });
  }
  function blit(x, rows, ox, oy, sc, pal) {
    for (let j = 0; j < rows.length; j++) for (let i = 0; i < rows[j].length; i++) { const ch = rows[j][i]; if (ch !== '.' && pal[ch]) { x.fillStyle = pal[ch]; x.fillRect(ox + i * sc, oy + j * sc, sc, sc); } }
  }
  function scene(x, P, c, sk) {
    const CX = 48, CY = 54, RR = 29;
    x.save(); x.beginPath(); x.arc(CX, CY, RR + .5, 0, 7); x.clip();
    const floorY = CY + 8;
    // دیوار آجری
    R(x, 0, 0, 96, floorY, P.wall);
    for (let row = 0, y = CY - RR; y < floorY; row++, y += 6) {
      R(x, 0, y, 96, 1, P.mort);
      for (let bx = -(row % 2 ? 6 : 0); bx < 96; bx += 12) { R(x, bx, y, 1, 6, P.mort); if (((bx * 7 + row * 13) & 7) === 3) R(x, bx + 2, y + 2, 5, 2, P.wall2); }
    }
    if (c.type === 'spell') { for (let r = RR; r > 0; r -= 5) { x.strokeStyle = r % 10 ? P.ban : P.bg; x.lineWidth = 2; x.beginPath(); x.arc(CX, CY + 4, r, 0, 7); x.stroke(); } }
    R(x, 0, floorY, 96, 40, P.floor);
    for (let i = 0; i < 24; i++) R(x, ((i * 37) % 70) + 10, floorY + 2 + ((i * 11) % 18), 3, 1, P.floor2);
    R(x, 0, floorY, 96, 1, P.floor2);
    // مشعل برای دنیای شخصیت‌ها و موجودات
    if (c.type === 'character' || c.type === 'creature') {
      R(x, 68, 50, 2, 11, P.floor2); R(x, 67, 48, 4, 3, P.gold);
      if (sk === 'term' || sk === 'ink') { R(x, 67, 41, 4, 6, P.gold); R(x, 68, 43, 2, 3, P.goldL); } else { R(x, 67, 41, 4, 6, '#f08a24'); R(x, 68, 40, 2, 3, '#f5c542'); R(x, 68, 44, 2, 3, '#fff3b0'); }
    }
    x.restore();
  }
  function artRing(x, P) {
    const CX = 48, CY = 54;
    disc(x, CX, CY, 33, P.goldD); disc(x, CX, CY, 32, P.gold); disc(x, CX, CY, 30, P.goldD);
    [[11, 21, 1, 1], [85, 21, -1, 1], [11, 87, 1, -1], [85, 87, -1, -1]].forEach(a => { for (let k = 0; k < 7; k++) { R(x, a[0] + a[2] * k - (a[2] < 0 ? 0 : 0), a[1], 1, 1, P.gold); R(x, a[0], a[1] + a[3] * k, 1, 1, P.gold); } });
  }
  function badge(x, P, X, Y, w, col, lab, val) {
    const c1 = { red: [P.atk, P.atkD], blue: [P.def, P.defD], grn: [P.grn, P.grnD], teal: [P.teal, P.tealD], yel: [P.yel, P.yelD] }[col] || [P.atk, P.atkD];
    chamf(x, X, Y, w, 25, P.goldD, 2); chamf(x, X + 1, Y + 1, w - 2, 23, P.gold, 2); chamf(x, X + 2, Y + 2, w - 4, 21, c1[0], 1);
    const lt = P.tx === '#2b2013' ? '#efe1b8' : '#ffffff';
    txtC(x, lab, X + w / 2, Y + 3, lt, 1, c1[1]);
    const sc = String(val).length > 2 ? 1 : 2;
    txtC(x, val, X + w / 2, Y + (sc === 2 ? 10 : 14), lt, sc, c1[1]);
  }
  function badges(c) {
    const b = {};
    if (c.type === 'character' || c.type === 'creature') { b.L = ['red', 'ATK', c.atk]; b.R = ['blue', 'DEF', c.def]; }
    else if (c.type === 'equipment') {
      if (c.bonus.atk) b.L = ['red', 'ATK', '+' + c.bonus.atk];
      if (c.bonus.def) b.R = ['blue', 'DEF', '+' + c.bonus.def];
      if (c.bonus.jump) b.L = ['grn', 'LEAP', 'YES'];
    } else if (c.type === 'spell') {
      if (c.fx.kind === 'area') { b.L = ['red', 'DMG', c.fx.dmg]; b.R = ['yel', 'AREA', '+']; }
      if (c.fx.kind === 'heal') { b.L = ['grn', 'HEAL', c.fx.amt]; }
      if (c.fx.kind === 'dmg') { b.L = ['red', 'DMG', c.fx.amt]; }
      if (c.fx.kind === 'poison') { b.L = ['grn', 'PSN', c.fx.dmg]; b.R = ['yel', 'TURN', c.fx.turns]; }
      if (c.fx.kind === 'multi') { b.L = ['red', 'DMG', c.fx.dmg]; b.R = ['blue', 'HITS', c.fx.targets]; }
    } else if (c.type === 'support') {
      if (c.fx.kind === 'elixir') { b.L = ['teal', 'ELIX', '+' + c.fx.amt]; b.R = ['blue', 'MAX', c.fx.cap]; }
      if (c.fx.kind === 'aura') { b.R = ['blue', 'DEF', '+' + c.fx.def]; }
      if (c.fx.kind === 'coins') { b.L = ['yel', 'GOLD', c.fx.amt]; b.R = ['teal', 'WAIT', c.fx.after]; }
    }
    return b;
  }
  function drawFront(x, c, sk, lock) {
    const P = cpal(sk, c.type), pal = palFor(sk);
    x.clearRect(0, 0, 96, 136); frame(x, P);
    // عنوان
    chamf(x, 13, 4, 70, 14, P.goldD, 2); chamf(x, 14, 5, 68, 12, P.gold, 1); chamf(x, 15, 6, 66, 10, P.ban, 1);
    txtC(x, lock ? '???' : c.ti, 48, 8, P.tx, 1, sk === 'ink' ? null : P.goldD);
    // هزینهٔ اکسیر در گوشهٔ بالا چپ
    disc(x, 7, 7, 5, P.gemD); disc(x, 7, 7, 4, P.gem);
    txtC(x, c.cost, 7.5, 4, sk === 'ink' ? '#2b2013' : '#04323a', 1);
    // تصویر
    artRing(x, P);
    x.save(); x.setTransform(2, 0, 0, 2, 0, 0); sceneHi(x, P, c, sk, lock); x.restore();
    if (lock) txtC(x, '?', 48, 40, P.tx, 5, P.goldD);
    // نوار نوع + کمیابی + جان
    chamf(x, 12, 89, 72, 11, P.goldD, 1); R(x, 13, 90, 70, 9, P.bar);
    txt(x, T0(c.type), 16, 91, P.tx, 1);
    const n = RARITIES.indexOf(c.rar) + 1;
    for (let i = 0; i < n; i++) { R(x, 81 - i * 4 - 3, 92, 3, 5, P.goldD); R(x, 81 - i * 4 - 2, 93, 1, 3, lock ? P.parchD : RAR_COL[c.rar]); }
    // پوستهٔ توضیح
    chamf(x, 10, 101, 76, 15, P.parchD, 1); chamf(x, 11, 102, 74, 13, P.parch, 1);
    // نشان‌ها
    const b = lock ? {} : badges(c);
    if (b.L) badge(x, P, 5, 111, 27, b.L[0], b.L[1], b.L[2]);
    if (b.R) badge(x, P, 64, 111, 27, b.R[0], b.R[1], b.R[2]);
    disc(x, 48, 125, 8, P.goldD); disc(x, 48, 125, 7, P.gold); disc(x, 48, 125, 5, P.bg);
    blit(x, ICO.star, 45, 122, 1, { y: lock ? '#777' : RAR_COL[c.rar] });
    R(x, 47, 124, 1, 1, '#fff');
  }
  const T0 = t => ({ character: 'CHARACTER', creature: 'CREATURE', equipment: 'EQUIPMENT', spell: 'SPELL', support: 'SUPPORT' })[t];
  function backRows(c) {
    const r = [];
    if (c.type === 'character' || c.type === 'creature') { r.push(['heart', 'HP', c.hp], ['atk', 'ATK', c.atk], ['def', 'DEF', c.def], ['spd', 'SPD', c.spd], ['drop', 'COST', c.cost]); return r; }
    if (c.type === 'equipment') { r.push(['atk', 'SLOT', c.slot === 'weapon' ? 'WPN' : (c.slot === 'tool' ? 'TOOL' : 'BOOT')]); if (c.bonus.atk) r.push(['atk', 'ATK', '+' + c.bonus.atk]); if (c.bonus.def) r.push(['def', 'DEF', '+' + c.bonus.def]); if (c.bonus.jump) r.push(['spd', 'LEAP', 'YES']); }
    else if (c.type === 'spell') { const f = c.fx; r.push([f.kind === 'heal' ? 'heart' : 'atk', f.kind === 'heal' ? 'HEAL' : 'DMG', f.amt || f.dmg]); if (f.targets) r.push(['spd', 'HITS', f.targets]); else if (f.kind !== 'heal') r.push(['def', 'DEF', 'IGN']); }
    else { r.push(['heart', 'HP', c.hp]); const f = c.fx; if (f.kind === 'elixir') r.push(['drop', 'ELIX', '+' + f.amt]); if (f.kind === 'aura') r.push(['def', 'DEF', '+' + f.def]); if (f.kind === 'coins') r.push(['coin', 'GOLD', f.amt]); }
    r.push(['drop', 'COST', c.cost]);
    return r.slice(0, 3);
  }
  function drawBack(x, c, sk, lock) {
    const P = cpal(sk, c.type), pal = palFor(sk);
    x.clearRect(0, 0, 96, 136); frame(x, P);
    for (let j = 9; j < 127; j += 4) for (let i = 9 + ((j >> 2) % 2) * 2; i < 87; i += 4) R(x, i, j, 1, 1, P.ban);
    disc(x, 48, 15, 11, P.goldD); disc(x, 48, 15, 10, P.gold); disc(x, 48, 15, 8, P.bg);
    R(x, 14, 15, 24, 1, P.gold); R(x, 58, 15, 24, 1, P.gold); R(x, 14, 17, 18, 1, P.goldD); R(x, 64, 17, 18, 1, P.goldD);
    if (lock) txtC(x, '?', 48, 11, P.tx, 1); else if (ARTS[c.art || c.spr]) { x.fillStyle = 'rgba(255,240,210,.2)'; disc(x, 48, 15, 8, 'rgba(255,240,210,.2)'); drawEmblem(x, c.art || c.spr, sk, 48, 15, 15); } else { const rows = SPR[c.emb || c.spr], w = Math.max.apply(null, rows.map(r => r.length)), h = rows.length; blit(x, rows, 48 - Math.floor(w / 2), 15 - Math.floor(h / 2), 1, pal); }
    // جداکننده‌ها
    [62, 93].forEach(y => { R(x, 10, y, 76, 1, P.gold); R(x, 10, y + 1, 76, 1, P.goldD); R(x, 46, y - 1, 4, 4, P.gold); R(x, 47, y, 2, 2, P.goldL); });
    if (lock) { txtC(x, 'LOCKED', 48, 72, P.tx, 2, P.goldD); return; }
    const rows = backRows(c), two = rows.length > 3;
    rows.forEach((r, i) => {
      const col = two ? i % 2 : 0, row = two ? (i / 2) | 0 : i, X = two ? (col ? 52 : 11) : 30, Y = 66 + row * 9;
      blit(x, ICO[r[0]], X, Y, 1, pal);
      txt(x, r[1], X + 9, Y, P.tx, 1);
      txt(x, String(r[2]), X + 9 + (r[1].length + 1) * 6, Y, P.val || P.goldL, 1);
    });
    txt(x, 'HOW TO PLAY', 11, 96, P.val || P.goldL, 1);
  }
  function drawCard(cv, sk) {
    const c = CARD[cv.dataset.card]; if (!c) return;
    cv.width = 288; cv.height = 408;
    const x = cv.getContext('2d'), lock = cv.dataset.lk === '1';
    if (DCsk !== sk) { DC = {}; DCsk = sk; }
    const key = c.id + cv.dataset.face + (lock ? 1 : 0), hit = DC[key];
    if (hit) { x.drawImage(hit, 0, 0); return; }
    x.setTransform(3, 0, 0, 3, 0, 0);
    if (cv.dataset.face === 'b') drawBack(x, c, sk, lock); else drawFront(x, c, sk, lock);
    const o = document.createElement('canvas'); o.width = 288; o.height = 408; o.getContext('2d').drawImage(cv, 0, 0); DC[key] = o;
  }
  let DC = {}, DCsk = '';

  /* ---------- کارت دوطرفه (HTML) ---------- */
  const OBT = { starter: 'starter', shop: 'shopHow', missions: 'missionHow', rare: 'rareHow' };
  function patGrid(c) {
    const pts = (c.mv || []).concat(c.at || []).concat([[0, 0]]);
    let x0 = -1, x1 = 1, y0 = 0, y1 = 0;
    pts.forEach(p => { x0 = Math.min(x0, p[0]); x1 = Math.max(x1, p[0]); y0 = Math.min(y0, p[1]); y1 = Math.max(y1, p[1]); });
    const mv = {}, at = {}, cells = [];
    (c.mv || []).forEach(p => { mv[p[0] + ',' + p[1]] = 1; }); (c.at || []).forEach(p => { at[p[0] + ',' + p[1]] = 1; });
    for (let dy = y0; dy <= y1; dy++) for (let dx = x0; dx <= x1; dx++) {
      const k = dx + ',' + dy; let cl = 'pg';
      if (c.type === 'spell' ? (dx === 0 && dy === 0 ? false : false) : (dx === 0 && dy === 0)) cl += ' me';
      if (at[k] && mv[k]) cl += ' both'; else if (at[k]) cl += ' at'; else if (mv[k]) cl += ' mv';
      if (c.type === 'spell' && dx === 0 && dy === 0) cl += ' tg';
      cells.push('<i class="' + cl + '"></i>');
    }
    return '<div class="patg" style="grid-template-columns:repeat(' + (x1 - x0 + 1) + ',1fr);width:calc(var(--u) * ' + (x1 - x0 + 1) * 6.2 + ')">' + cells.join('') + '</div>';
  }
  function cardHtml(c, o) {
    o = o || {};
    const sk = skin(), owned = G.owned[c.id] || 0, lock = !owned && !o.reveal, hasPat = !lock && (c.mv || c.at);
    const how = T(OBT[c.src] || 'starter');
    const back = lock
      ? '<div class="pov bsp lk">' + (fa() ? 'روش دریافت: ' : 'Get it: ') + esc(how) + '</div>'
      : '<div class="pov bnm">' + esc(c.nm) + '</div><div class="pov bds">' + esc(c.st) + '</div>' +
        '<div class="pov bbt' + (hasPat ? '' : ' nopt') + '">' + (hasPat ? '<div class="bpt">' + patGrid(c) + '<div class="lg"><span class="lm">MOVE</span><span class="la">' + (c.type === 'spell' ? 'AREA' : 'HIT') + '</span></div></div>' : '') + '<div class="bhw">' + esc(c.hw) + '</div></div>';
    return '<div class="pxc ' + (lock ? 'lk ' : '') + 'r-' + c.rar + ' t-' + c.type + (o.flip ? ' flip' : '') + '" data-sk="' + sk + '" data-id="' + c.id + '" style="--w:' + (o.w || 144) + 'px">' +
      '<div class="pin"><div class="pxf fr"><canvas class="cf" data-card="' + c.id + '" data-face="f"' + (lock ? ' data-lk="1"' : '') + ' width="288" height="408"></canvas>' + (lock ? '' : '<div class="pov dsf">' + esc(c.bl) + '</div>') + '</div>' +
      '<div class="pxf bk"><canvas class="cf" data-card="' + c.id + '" data-face="b"' + (lock ? ' data-lk="1"' : '') + ' width="288" height="408"></canvas>' + back + '</div></div>' +
      (owned > 1 && o.count !== false ? '<span class="cnt">×' + nf(owned) + '</span>' : '') + '</div>';
  }
  /* ======================================================================
     CROWNFALL — داده‌های کارت: دسته‌بندی، قیمت، توانایی‌ها (جدا از ظاهر و منطق)
     ====================================================================== */
  const CATS = ['creature', 'human', 'weapon', 'tool', 'power', 'support', 'poison'];
  const CAT_NAME = { creature: 'Creatures', human: 'Humans', weapon: 'Weapons', tool: 'Tools', power: 'Powers', support: 'Support', poison: 'Poison' };
  const RAR_PRICE = { common: 50, rare: 120, epic: 300, legendary: 700 };
  const GEM_PRICE = { legendary: 60, epic: 30 };
  const STARTER_IDS = ['knight', 'zombie', 'archer', 'mace', 'fireball'];

  /* سپر آهنی: هنر پیکسلی اورجینال که با کد ساخته می‌شود (سپر گرد-تیز ساده با صلیب طلایی) */
  function shieldRows() {
    const pal = { a: '#5b6f94', b: '#3f5278', c: '#2c3b5c', g: '#e0b445', h: '#f6dc86', k: '#8a6a22', s: '#c9d3e6' }, W = 64, H = 72, rows = [];
    for (let y = 0; y < H; y++) {
      let r = '';
      for (let x = 0; x < W; x++) {
        const dx = x - 31.5, ty = y - 9; let hw = -1;
        if (ty >= 0 && ty <= 52) hw = ty < 30 ? 22 : 22 * Math.pow(1 - (ty - 30) / 23, .78);
        if (ty > 52) hw = -1;
        const ax = Math.abs(dx); let ch = '.';
        if (hw > 0 && ax <= hw) {
          const edge = hw - ax, topEdge = ty < 2.5;
          if (edge < 2.4 || topEdge) ch = (dx < 0 || ty < 2.5) ? 'h' : 'g';
          else if (edge < 3.6) ch = 'k';
          else if (ax < 3.2 && ty > 3) ch = (dx < 0) ? 'h' : 'g';
          else if (Math.abs(ty - 20) < 3.2 && ax < hw - 3) ch = (ty < 20) ? 'h' : 'g';
          else ch = dx < 0 ? 'a' : 'b';
          if (ch === 'a' || ch === 'b') { if ((ty < 12 && dx < -4 && ax > 6 && ax < 16) && (x + y) % 5 === 0) ch = 's'; if (ty > 34 && dx > 4) ch = 'c'; }
        }
        r += ch;
      }
      rows.push(r);
    }
    for (const [x, y] of [[14, 15], [49, 15], [31, 15]]) { const row = rows[y].split(''); row[x] = 'h'; row[x + 1] = 'k'; rows[y] = row.join(''); }
    return [pal, rows];
  }
  ARTS.shield = () => artImg(shieldRows());

  CARDS.push({ id: 'shield', type: 'equipment', rar: 'common', cost: 2, spr: 'sword', art: 'shield', emb: 'sword', src: 'shop', slot: 'tool', bonus: { def: 2 },
    nameFa: 'سپر آهنی', nameEn: 'Iron Shield', descFa: '', descEn: 'Attach to a unit for +2 defense.', spFa: '', spEn: '+2 defense' });
  CT.shield = { ti: 'IRON SHIELD', nm: 'Iron Shield', bl: 'Attach to a unit: +2 Defense.', st: 'Dented, trusted, and still standing.', hw: 'Play on a friendly Character or Creature. Slot: Tool. One per unit.', tp: 'Put it on a unit that holds the front.', tpFa: '' };
  CARD.shield = CARDS[CARDS.length - 1];

  /* تنظیم تعادل و دسته‌بندی هر کارت */
  const META = {
    knight: ['human', ['guard']], ninja: ['human', ['jump']], archer: ['human', ['ranged']], skeleton: ['human', []], mage: ['human', ['ranged']], ranger: ['human', []],
    drake: ['human', ['sweep']], smage: ['human', ['ranged']],
    dragon: ['creature', ['fly']], zombie: ['creature', ['rise']], magma: ['creature', ['fly']], sdrake: ['creature', ['fly']],
    hammer: ['weapon', []], mace: ['weapon', []], dblade: ['weapon', []], fblade: ['weapon', []], bflame: ['weapon', []], claws: ['weapon', []], nunchaku: ['weapon', []], pencil: ['weapon', []],
    bow: ['tool', ['range+1']], shield: ['tool', ['armor']],
    fireball: ['power', []], icesh: ['power', ['freeze']], toxic: ['poison', ['poison']], lantern: ['support', []], potion: ['support', []]
  };
  CARDS.forEach(c => {
    const m = META[c.id] || ['human', []]; c.cat = m[0]; c.ab = m[1];
    c.src = STARTER_IDS.indexOf(c.id) > -1 ? 'starter' : 'shop';
    c.price = RAR_PRICE[c.rar] + c.cost * 5; c.gems = GEM_PRICE[c.rar] || 0;
    if (c.type === 'equipment' && !c.slot) c.slot = 'weapon';
  });
  CARD.bow.slot = 'tool';
  CARD.fireball.fx = { kind: 'dmg', amt: 3 }; CARD.fireball.descEn = 'Deals 3 damage to one enemy card.';
  CARD.icesh.fx = { kind: 'dmg', amt: 2, freeze: 1 }; CARD.icesh.descEn = 'Deals 2 damage and freezes the target for a turn.';
  CARD.toxic.fx = { kind: 'poison', dmg: 2, turns: 2 }; CARD.toxic.descEn = 'Poisons an enemy card and the four cells around it: 2 damage a turn for 2 turns.';
  Object.assign(CT.fireball, { bl: 'Deals 3 damage to an enemy.', hw: 'Pick an enemy card. It takes 3 damage.' });
  Object.assign(CT.icesh, { bl: '2 damage and freeze.', hw: 'Pick an enemy card. It takes 2 damage and cannot act next turn.' });
  Object.assign(CT.toxic, { bl: 'Poison in a cross.', hw: 'Pick an enemy card. It and the 4 cells around it take 2 poison damage per turn for 2 turns.' });
  CARD.knight.descEn = 'Guard: friendly cards next to it take 1 less damage.';
  Object.assign(CT.knight, { bl: 'Guards adjacent allies.', hw: 'Moves 1 cell forward and strikes the cell ahead. Allies standing next to it take 1 less damage.' });
  Object.assign(CT.bow, { hw: 'Play on a friendly Character or Creature. Slot: Tool. One per unit. Adds 1 range.' });
  CARDS.forEach(c => { Object.assign(c, CT[c.id] || {}); });
  const TIER_RAR = { common: 0, rare: 1, epic: 2, legendary: 3 };
  const catOf = c => c.cat;
  const isUnit = c => c.type === 'character' || c.type === 'creature';

  /* ---------- کلاس‌ها و سازگاری تجهیزات (داده‌محور؛ برای افزودن کلاس جدید فقط این جدول‌ها را گسترش بده) ---------- */
  const CLASS_OF = { knight: 'warrior', ranger: 'warrior', drake: 'warrior', skeleton: 'warrior', ninja: 'assassin', archer: 'archer', mage: 'mage', smage: 'mage', zombie: 'undead', dragon: 'dragon', magma: 'dragon', sdrake: 'dragon' };
  const CLS_NAME = { warrior: 'Warrior', assassin: 'Assassin', archer: 'Archer', mage: 'Mage', undead: 'Undead', dragon: 'Dragon' };
  const EQ_CLASSES = { mace: ['warrior', 'undead'], hammer: ['warrior'], dblade: ['warrior', 'assassin'], fblade: ['warrior'], bflame: ['warrior', 'mage'], claws: ['assassin', 'undead', 'dragon'], nunchaku: ['assassin'], pencil: ['mage', 'assassin'], bow: ['archer'], shield: ['warrior'] };
  CARDS.forEach(c => {
    c.cls = CLASS_OF[c.id] || null;
    if (c.type === 'equipment') c.eq = EQ_CLASSES[c.id] || null;
    c.deploys = isUnit(c);
    if (isUnit(c)) {
      const at = c.at || [], d = [];
      c.range = Math.max(1, ...at.map(o => Math.max(Math.abs(o[0]), Math.abs(o[1]))));
      at.forEach(o => { const n = o[0] && o[1] ? 'Diagonal' : o[1] < 0 ? 'Forward' : o[1] > 0 ? 'Backward' : o[0] < 0 ? 'Left' : 'Right'; if (d.indexOf(n) < 0) d.push(n); });
      c.dirs = d; c.mvRange = Math.max(0, ...(c.mv || []).map(o => Math.max(Math.abs(o[0]), Math.abs(o[1]))));
      c.atkType = c.cls === 'mage' ? 'Magic' : (c.ab.indexOf('ranged') > -1 || c.range > 1 ? 'Ranged' : 'Melee');
    }
  });
  function equipCheck(card, u) {
    const c = CARD[u.id];
    if (card.type !== 'equipment') return { ok: false, msg: 'This card is not equipment.' };
    if (!isUnit(c)) return { ok: false, msg: 'Only units can carry equipment.' };
    if (card.eq && card.eq.indexOf(c.cls) < 0) return { ok: false, msg: card.nm + ' can only be used by: ' + card.eq.map(x => CLS_NAME[x]).join(', ') + '. ' + c.nm + ' is ' + (/^[aeiou]/i.test(CLS_NAME[c.cls]) ? 'an ' : 'a ') + CLS_NAME[c.cls] + '.' };
    if ((card.slot === 'weapon' ? u.wp : u.tl) === card.id) return { ok: false, msg: c.nm + ' already has ' + card.nm + '.' };
    return { ok: true };
  }
  /* ======================================================================
     CROWNFALL — وضعیت مرکزی بازی (تنها منبع حقیقت)، ذخیره‌سازی و اقتصاد
     ====================================================================== */
  const CFG = { deckSize: 20, copyLimit: 3, minDeck: 8, baseHp: 30, startMana: 3, manaMax: 10, deployPerTurn: 3, handMax: 7, startHand: 5, drawCost: 1, startGold: 100, startGems: 10, gemToGold: [5, 100] };
  const clampInt = (v, lo, hi, d) => { v = Math.floor(Number(v)); return isFinite(v) ? Math.max(lo, Math.min(hi, v)) : d; };
  const pad2 = n => (n < 10 ? '0' : '') + n;
  const dateKey = d => d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
  const todayKey = () => dateKey(new Date());
  const dayIdx = k => { const p = String(k).split('-'); return p.length === 3 ? Math.round(Date.UTC(+p[0], +p[1] - 1, +p[2]) / 86400000) : NaN; };
  const weekKey = () => { const d = new Date(); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return dateKey(d); };

  /* منحنی سطح: هر سطح بیشتر از قبلی XP می‌خواهد */
  const LV_MAX = 50;
  const xpNeed = l => Math.round(100 + 40 * (l - 1) + 6 * (l - 1) * (l - 1));
  const lvReward = l => ({ gold: 40 + 10 * l, gems: l % 5 === 0 ? 5 : 0 });

  const MIS_DAILY = [
    { id: 'd_win', t: 'Win 1 battle', k: 'win', n: 1, gold: 40, xp: 25 },
    { id: 'd_bat', t: 'Complete 2 battles', k: 'battle', n: 2, gold: 30, xp: 20 },
    { id: 'd_play', t: 'Play 6 cards', k: 'play', n: 6, gold: 30, xp: 20 },
    { id: 'd_gold', t: 'Earn 100 Gold', k: 'gold', n: 100, gems: 2, xp: 25 }];
  const MIS_WEEKLY = [
    { id: 'w_win', t: 'Win 5 battles', k: 'win', n: 5, gold: 150, gems: 3, xp: 90 },
    { id: 'w_play', t: 'Play 30 cards', k: 'play', n: 30, gold: 120, xp: 70 },
    { id: 'w_kill', t: 'Destroy 25 enemy cards', k: 'kill', n: 25, gold: 120, xp: 70 },
    { id: 'w_buy', t: 'Buy 2 cards', k: 'buy', n: 2, gold: 80, gems: 2, xp: 50 }];
  const MIS_SPECIAL = [
    { id: 's_first', t: 'Win your first battle', k: 'wins', n: 1, gold: 60, xp: 40 },
    { id: 's_own', t: 'Own 8 cards', k: 'own', n: 8, gold: 100, xp: 60 },
    { id: 's_deck', t: 'Build a deck of 15 cards', k: 'deck', n: 15, gold: 60, xp: 40 },
    { id: 's_lv', t: 'Reach level 5', k: 'level', n: 5, gold: 150, gems: 5, xp: 0 },
    { id: 's_win10', t: 'Win 10 battles', k: 'wins', n: 10, gold: 200, gems: 4, xp: 100 }];
  const ACHS = [
    { id: 'a_win1', t: 'First Blood', d: 'Win a battle', k: 'wins', n: 1, gold: 50, xp: 30 },
    { id: 'a_win10', t: 'Veteran', d: 'Win 10 battles', k: 'wins', n: 10, gold: 120, gems: 2, xp: 80 },
    { id: 'a_win50', t: 'Champion', d: 'Win 50 battles', k: 'wins', n: 50, gold: 400, gems: 10, xp: 250 },
    { id: 'a_own10', t: 'Collector', d: 'Own 10 cards', k: 'own', n: 10, gold: 150, xp: 80 },
    { id: 'a_own20', t: 'Hoarder', d: 'Own 20 cards', k: 'own', n: 20, gold: 300, gems: 5, xp: 150 },
    { id: 'a_lv5', t: 'Rising Star', d: 'Reach level 5', k: 'level', n: 5, gold: 100, xp: 0 },
    { id: 'a_lv10', t: 'Hero', d: 'Reach level 10', k: 'level', n: 10, gold: 250, gems: 5, xp: 0 },
    { id: 'a_gold', t: 'Rich', d: 'Earn 1000 Gold in total', k: 'goldTotal', n: 1000, gems: 3, xp: 100 },
    { id: 'a_streak', t: 'Devoted', d: 'Log in 3 days in a row', k: 'streak', n: 3, gold: 80, xp: 50 },
    { id: 'a_kill', t: 'Slayer', d: 'Destroy 50 enemy cards', k: 'kill', n: 50, gold: 150, xp: 90 },
    { id: 'a_play', t: 'Tactician', d: 'Play 100 cards', k: 'play', n: 100, gold: 150, xp: 90 }];
  const DAILY_R = [{ gold: 30, xp: 10 }, { gold: 40, xp: 10 }, { gold: 50, xp: 15 }, { gold: 60, xp: 15 }, { gold: 80, xp: 20 }, { gold: 100, xp: 25 }, { gold: 150, gems: 5, xp: 40 }];

  let G = null;
  function freshState() {
    const owned = {}; STARTER_IDS.forEach(id => { owned[id] = 1; });
    const deck = []; STARTER_IDS.forEach(id => { for (let i = 0; i < 3; i++) deck.push(id); });
    return { v: 2, profile: { name: 'Hero', created: Date.now() }, gold: CFG.startGold, gems: CFG.startGems, level: 1, xp: 0, owned: owned, deck: deck,
      stats: { battles: 0, wins: 0, losses: 0, goldEarned: 0, kills: 0, played: 0, buys: 0 }, daily: { last: '', streak: 0, best: 0, total: 0 },
      missions: { day: '', week: '', d: {}, w: {}, s: {} }, ach: {}, settings: { sound: true, music: true, vibration: true }, ui: { view: 'menu', cat: 'all', rar: 'all', tab: 'owned', mtab: 'daily', sh: 'cards' }, battle: null, rewarded: {} };
  }
  /* بررسی و پاک‌سازی دادهٔ ذخیره‌شده تا دادهٔ خراب بازی را نشکند */
  function validate(raw) {
    const f = freshState(); if (!raw || typeof raw !== 'object' || raw.v !== 2) return null;
    const g = f, obj = o => (o && typeof o === 'object' && !Array.isArray(o)) ? o : {};
    g.profile.name = String(obj(raw.profile).name || 'Hero').replace(/[<>&"]/g, '').slice(0, 12) || 'Hero'; g.profile.created = clampInt(obj(raw.profile).created, 0, 9e15, Date.now());
    g.gold = clampInt(raw.gold, 0, 999999999, 0); g.gems = clampInt(raw.gems, 0, 999999, 0);
    g.level = clampInt(raw.level, 1, LV_MAX, 1); g.xp = clampInt(raw.xp, 0, 99999999, 0); if (g.level >= LV_MAX) g.xp = 0; else if (g.xp >= xpNeed(g.level)) g.xp = xpNeed(g.level) - 1;
    g.owned = {}; const ro = obj(raw.owned); Object.keys(ro).forEach(id => { if (CARD[id] && ro[id]) g.owned[id] = 1; });
    if (!Object.keys(g.owned).length) STARTER_IDS.forEach(id => { g.owned[id] = 1; });
    const cnt = {}; g.deck = []; (Array.isArray(raw.deck) ? raw.deck : []).forEach(id => { if (g.owned[id] && g.deck.length < CFG.deckSize && (cnt[id] || 0) < CFG.copyLimit) { cnt[id] = (cnt[id] || 0) + 1; g.deck.push(id); } });
    const rs = obj(raw.stats); Object.keys(g.stats).forEach(k => { g.stats[k] = clampInt(rs[k], 0, 9e12, 0); });
    const rd = obj(raw.daily); g.daily = { last: /^\d{4}-\d\d-\d\d$/.test(rd.last) ? rd.last : '', streak: clampInt(rd.streak, 0, 9999, 0), best: clampInt(rd.best, 0, 9999, 0), total: clampInt(rd.total, 0, 99999, 0) };
    const rm = obj(raw.missions); g.missions = { day: String(rm.day || ''), week: String(rm.week || ''), d: {}, w: {}, s: {} };
    [['d', MIS_DAILY], ['w', MIS_WEEKLY], ['s', MIS_SPECIAL]].forEach(p => { const src = obj(rm[p[0]]); p[1].forEach(m => { const e = obj(src[m.id]); g.missions[p[0]][m.id] = { p: clampInt(e.p, 0, m.n, 0), c: e.c ? 1 : 0 }; }); });
    const ra = obj(raw.ach); ACHS.forEach(a => { if (ra[a.id]) g.ach[a.id] = 1; });
    const st = obj(raw.settings); g.settings = { sound: st.sound !== false, music: st.music !== false, vibration: st.vibration !== false };
    const ru = obj(raw.ui); g.ui = Object.assign(g.ui, { cat: String(ru.cat || 'all'), rar: String(ru.rar || 'all'), tab: ru.tab === 'deck' ? 'deck' : 'owned', mtab: ['daily', 'weekly', 'special', 'ach'].indexOf(ru.mtab) > -1 ? ru.mtab : 'daily', sh: ru.sh === 'gems' ? 'gems' : 'cards' });
    g.rewarded = {}; Object.keys(obj(raw.rewarded)).slice(-40).forEach(k => { g.rewarded[k] = 1; });
    const b = raw.battle, okSide = p => p && typeof p === 'object' && Array.isArray(p.hand) && Array.isArray(p.draw) && p.hand.every(id => CARD[id]) && p.draw.every(id => CARD[id]) && isFinite(p.hp) && isFinite(p.mana) && isFinite(p.max);
    g.battle = (b && typeof b === 'object' && typeof b.id === 'string' && Array.isArray(b.board) && b.board.length === 20 && okSide(b.p) && okSide(b.e) && isFinite(b.turn) && isFinite(b.tier) && b.tier >= 0 && b.tier <= 2) ? b : null;
    if (g.battle) { for (let i = 0; i < 20; i++) { const u = g.battle.board[i]; if (u && (!CARD[u.id] || !(u.hp > 0) || !(u.mhp > 0) || (u.side !== 'p' && u.side !== 'e'))) g.battle.board[i] = null; } if (g.battle.p.hp <= 0 || g.battle.e.hp <= 0 || g.battle.over) g.battle = null; }
    return g;
  }
  try { G = validate(JSON.parse(localStorage.getItem(LS))); } catch (e) { G = null; }
  if (!G) G = freshState();
  const persist = () => { try { localStorage.setItem(LS, JSON.stringify(G)); } catch (e) {} };
  persist();
  const ownedList = () => CARDS.filter(c => G.owned[c.id]);
  const deckCount = id => G.deck.filter(x => x === id).length;

  /* ---------- اقتصاد: طلا، الماس، XP و سطح ---------- */
  const eco = {
    addGold(n) { n = Math.floor(n); if (!(n > 0)) return 0; G.gold = Math.min(999999999, G.gold + n); G.stats.goldEarned += n; track('gold', n); return n; },
    spendGold(n) { n = Math.floor(n); if (!(n > 0) || G.gold < n) return false; G.gold -= n; return true; },
    addGems(n) { n = Math.floor(n); if (n > 0) G.gems = Math.min(999999, G.gems + n); },
    spendGems(n) { n = Math.floor(n); if (!(n > 0) || G.gems < n) return false; G.gems -= n; return true; },
    addXp(n) {
      n = Math.floor(n); const ups = []; if (!(n > 0) || G.level >= LV_MAX) return ups; G.xp += n;
      while (G.level < LV_MAX && G.xp >= xpNeed(G.level)) {
        G.xp -= xpNeed(G.level); G.level++; const r = lvReward(G.level); eco.addGold(r.gold); eco.addGems(r.gems); ups.push({ level: G.level, gold: r.gold, gems: r.gems });
      }
      if (G.level >= LV_MAX) G.xp = 0; if (ups.length) syncGoals(); return ups;
    },
    give(r) { const o = { gold: 0, gems: 0, xp: 0, ups: [] }; if (r.gold) o.gold = eco.addGold(r.gold); if (r.gems) { eco.addGems(r.gems); o.gems = r.gems; } if (r.xp) { o.xp = r.xp; o.ups = eco.addXp(r.xp); } return o; }
  };
  const rewardText = r => [r.gold ? r.gold + ' Gold' : '', r.gems ? r.gems + ' Gems' : '', r.xp ? r.xp + ' XP' : ''].filter(Boolean).join(' · ');

  /* ---------- مأموریت‌ها و دستاوردها ---------- */
  const goalProg = k => ({ wins: G.stats.wins, own: Object.keys(G.owned).length, level: G.level, goldTotal: G.stats.goldEarned, streak: Math.max(G.daily.streak, G.daily.best), kill: G.stats.kills, play: G.stats.played, deck: G.deck.length })[k] || 0;
  function ensureMissions() {
    const M = G.missions, t = todayKey(), w = weekKey();
    if (M.day !== t) { M.day = t; M.d = {}; MIS_DAILY.forEach(m => { M.d[m.id] = { p: 0, c: 0 }; }); }
    if (M.week !== w) { M.week = w; M.w = {}; MIS_WEEKLY.forEach(m => { M.w[m.id] = { p: 0, c: 0 }; }); }
    MIS_SPECIAL.forEach(m => { if (!M.s[m.id]) M.s[m.id] = { p: 0, c: 0 }; });
  }
  function syncGoals() { ensureMissions(); MIS_SPECIAL.forEach(m => { const e = G.missions.s[m.id]; e.p = Math.max(e.p, Math.min(m.n, goalProg(m.k))); }); }
  /* رویدادهای بازی به مأموریت‌های دوره‌ای نسبت داده می‌شوند (پیشرفت خودکار) */
  function track(kind, n) {
    ensureMissions(); const M = G.missions;
    [['d', MIS_DAILY], ['w', MIS_WEEKLY]].forEach(p => p[1].forEach(m => { if (m.k === kind) { const e = M[p[0]][m.id]; e.p = Math.min(m.n, e.p + n); } }));
  }
  const missionList = tab => (tab === 'daily' ? MIS_DAILY : tab === 'weekly' ? MIS_WEEKLY : MIS_SPECIAL);
  function claimMission(tab, id) {
    ensureMissions(); syncGoals(); const m = missionList(tab).find(x => x.id === id), e = m && G.missions[tab === 'daily' ? 'd' : tab === 'weekly' ? 'w' : 's'][id];
    if (!m || !e || e.c || e.p < m.n) return null; e.c = 1; const r = eco.give(m); syncGoals(); persist(); return r;
  }
  function claimAch(id) { const a = ACHS.find(x => x.id === id); if (!a || G.ach[id] || goalProg(a.k) < a.n) return null; G.ach[id] = 1; const r = eco.give(a); syncGoals(); persist(); return r; }
  const claimable = () => { ensureMissions(); syncGoals(); let n = 0; ['daily', 'weekly', 'special'].forEach(t => missionList(t).forEach(m => { const e = G.missions[t === 'daily' ? 'd' : t === 'weekly' ? 'w' : 's'][m.id]; if (!e.c && e.p >= m.n) n++; })); ACHS.forEach(a => { if (!G.ach[a.id] && goalProg(a.k) >= a.n) n++; }); return n; };

  /* ---------- پاداش روزانه با زنجیرهٔ ورود ---------- */
  function dailyInfo() {
    const t = todayKey(), last = G.daily.last, can = last !== t, gap = last ? dayIdx(t) - dayIdx(last) : 99;
    const cur = can ? (gap === 1 ? G.daily.streak + 1 : 1) : G.daily.streak;
    return { can: can, streak: cur, idx: (Math.max(1, cur) - 1) % 7 };
  }
  function claimDaily() {
    const info = dailyInfo(); if (!info.can) return null;
    G.daily.last = todayKey(); G.daily.streak = info.streak; G.daily.best = Math.max(G.daily.best, info.streak); G.daily.total++;
    const r = eco.give(DAILY_R[info.idx]); syncGoals(); persist(); return r;
  }

  /* ---------- فروشگاه و دسته ---------- */
  function buyCard(id, cur) {
    const c = CARD[id]; if (!c) return { ok: false, msg: 'Unknown card.' }; if (G.owned[id]) return { ok: false, msg: 'You already own this card.' };
    if (cur === 'gems') { if (!c.gems) return { ok: false, msg: 'This card is not sold for Gems.' }; if (G.gems < c.gems) return { ok: false, msg: 'Not enough Gems. You need ' + (c.gems - G.gems) + ' more.' }; eco.spendGems(c.gems); }
    else { if (G.gold < c.price) return { ok: false, msg: 'Not enough Gold. You need ' + (c.price - G.gold) + ' more.' }; eco.spendGold(c.price); }
    G.owned[id] = 1; G.stats.buys++; track('buy', 1); syncGoals(); persist(); return { ok: true, msg: c.nm + ' added to your collection!' };
  }
  function exchangeGems() { if (!eco.spendGems(CFG.gemToGold[0])) return { ok: false, msg: 'Not enough Gems.' }; eco.addGold(CFG.gemToGold[1]); persist(); return { ok: true, msg: '+' + CFG.gemToGold[1] + ' Gold' }; }
  function deckAdd(id) {
    if (!CARD[id] || !G.owned[id]) return { ok: false, msg: 'You do not own this card.' };
    if (G.deck.length >= CFG.deckSize) return { ok: false, msg: 'Your deck is full (' + CFG.deckSize + ').' };
    if (deckCount(id) >= CFG.copyLimit) return { ok: false, msg: 'Max ' + CFG.copyLimit + ' copies of one card.' };
    G.deck.push(id); syncGoals(); persist(); return { ok: true };
  }
  function deckRemove(id) { const i = G.deck.lastIndexOf(id); if (i < 0) return { ok: false, msg: 'Not in deck.' }; G.deck.splice(i, 1); syncGoals(); persist(); return { ok: true }; }
  function resetAll() { try { localStorage.removeItem(LS); } catch (e) {} G = freshState(); ensureMissions(); syncGoals(); persist(); }
  ensureMissions(); syncGoals(); persist();
  const api = { eco: eco, buy: buyCard, deckAdd: deckAdd, deckRemove: deckRemove };
  /* ======================================================================
     CROWNFALL — موتور نبرد (منطق خالص بدون DOM؛ انیمیشن‌ها فقط نتیجهٔ همین محاسبات را نشان می‌دهند)
     خانه‌ها: ۰–۹ دشمن (ردیف ۰ و ۱)، ۱۰–۱۹ بازیکن (ردیف ۲ و ۳)؛ ۵ ستون
     ====================================================================== */
  let BT = null, UID = 1;
  const rcOf = i => [Math.floor(i / 5), i % 5];
  const idxOf = (r, c) => (r < 0 || r > 3 || c < 0 || c > 4) ? -1 : r * 5 + c;
  const sideOf = i => (i >= 10 ? 'p' : 'e');
  const foe = s => (s === 'p' ? 'e' : 'p');
  function offIdx(i, side, o) { const rc = rcOf(i); return side === 'p' ? idxOf(rc[0] + o[1], rc[1] + o[0]) : idxOf(rc[0] - o[1], rc[1] - o[0]); }
  const rnd = n => Math.floor(Math.random() * n);
  const shuffle = a => { for (let i = a.length - 1; i > 0; i--) { const j = rnd(i + 1), t = a[i]; a[i] = a[j]; a[j] = t; } return a; };
  const mkUnit = (id, side) => { const c = CARD[id]; return { uid: UID++, id: id, side: side, hp: c.hp, mhp: c.hp, wp: null, tl: null, moved: 0, psn: null, frz: 0, rose: 0 }; };
  const hasAb = (u, a) => CARD[u.id].ab.indexOf(a) > -1;
  function ustat(u) {
    const c = CARD[u.id]; let atk = c.atk, def = c.def, reach = 0;
    [u.wp, u.tl].forEach(e => { if (e) { const b = CARD[e].bonus || {}; atk += b.atk || 0; def += b.def || 0; reach += b.reach || 0; } });
    return { atk: atk, def: def, reach: reach };
  }
  function upattern(u) {
    const c = CARD[u.id], at = c.at.map(a => a.slice()), r = ustat(u).reach; let mn = 0; c.at.forEach(o => { if (o[0] === 0) mn = Math.min(mn, o[1]); });
    for (let k = 1; k <= r; k++) at.push([0, mn - k]); return at;
  }
  const ENEMIES = [{ n: 'Goblin Scout', dep: 2 }, { n: 'Bandit Captain', dep: 3 }, { n: 'Dark Warlord', dep: 3 }];
  const POOLS = [
    { zombie: 4, archer: 3, ranger: 3, mace: 3, knight: 2, lantern: 2, fireball: 2 },
    { zombie: 2, archer: 2, ranger: 2, knight: 3, ninja: 2, drake: 2, mage: 2, hammer: 2, bflame: 2, icesh: 2, toxic: 2, lantern: 2, shield: 2, skeleton: 1 },
    { knight: 2, ninja: 2, drake: 2, mage: 2, skeleton: 2, dragon: 2, smage: 2, dblade: 2, fblade: 2, icesh: 2, toxic: 2, potion: 2, claws: 1, shield: 2, bow: 1, magma: 1, sdrake: 1, nunchaku: 1, fireball: 2 }];
  function enemyDeck(tier) { const d = []; const pool = POOLS[tier]; Object.keys(pool).forEach(id => { if (CARD[id]) for (let i = 0; i < pool[id]; i++) d.push(id); }); return shuffle(d).slice(0, 24); }
  const tierNow = () => (G.stats.wins < 3 ? 0 : (G.stats.wins < 9 ? 1 : 2));
  function drawFromDeck(s) { const p = BT[s]; if (p.draw.length && p.hand.length < CFG.handMax) p.hand.push(p.draw.shift()); }
  function playerDeck() {
    let d = G.deck.filter(id => G.owned[id]); if (d.length < CFG.minDeck) { const o = ownedList().map(c => c.id); let k = 0; while (d.length < CFG.minDeck && o.length) d.push(o[k++ % o.length]); }
    return shuffle(d.slice());
  }
  function battleNew() {
    const tier = tierNow();
    BT = { id: 'b' + Date.now() + '_' + rnd(1e6), turn: 1, tier: tier, enemy: ENEMIES[tier].n, phase: 'player', over: null, rewarded: 0, land: -1, board: new Array(20).fill(null),
      p: { mhp: CFG.baseHp, hp: CFG.baseHp, mana: CFG.startMana, max: CFG.startMana, dep: 0, hand: [], draw: playerDeck() }, e: { mhp: CFG.baseHp + [0, 2, 8][tier], hp: CFG.baseHp + [0, 2, 8][tier], mana: CFG.startMana + (tier > 1 ? 1 : 0), max: CFG.startMana + (tier > 1 ? 1 : 0), dep: 0, hand: [], draw: enemyDeck(tier) } };
    for (let i = 0; i < CFG.startHand; i++) { drawFromDeck('p'); drawFromDeck('e'); }
    return BT;
  }
  const saveBattle = () => { G.battle = (BT && !BT.over) ? JSON.parse(JSON.stringify(BT)) : null; persist(); };
  function battleLoad() { if (!G.battle) return null; BT = JSON.parse(JSON.stringify(G.battle)); BT.phase = 'player'; BT.land = -1; BT.board.forEach(u => { if (u && u.uid >= UID) UID = u.uid + 1; }); return BT; }

  /* ---------- هدف‌های معتبر ---------- */
  function targetsFor(card, side) {
    const out = [], mine = side === 'p' ? [10, 19] : [0, 9];
    for (let i = 0; i < 20; i++) {
      const u = BT.board[i], own = i >= mine[0] && i <= mine[1];
      if (isUnit(card)) { if (!u && own) out.push(i); }
      else if (card.type === 'equipment') { if (u && u.side === side && equipCheck(card, u).ok) out.push(i); }
      else if (card.fx.kind === 'heal') { if (u && u.side === side && u.hp < u.mhp) out.push(i); }
      else if (u && u.side !== side) out.push(i);
    }
    return out;
  }
  function moveTargets(i) {
    const u = BT.board[i]; if (!u || u.moved || u.frz > 0) return []; const c = CARD[u.id], out = [];
    (c.mv || []).forEach(o => {
      const t = offIdx(i, u.side, o); if (t < 0 || BT.board[t]) return;
      if (o[0] === 0 && Math.abs(o[1]) === 2) { const m = offIdx(i, u.side, [0, o[1] / 2]); if (BT.board[m] && !hasAb(u, 'jump') && !hasAb(u, 'fly')) return; }
      out.push(t);
    });
    return out;
  }
  /* ---------- آسیب و مرگ ---------- */
  function guardCut(i) {
    const u = BT.board[i], rc = rcOf(i); let g = 0;
    [[0, 1], [0, -1], [1, 0], [-1, 0]].forEach(d => { const t = idxOf(rc[0] + d[0], rc[1] + d[1]), v = t >= 0 ? BT.board[t] : null; if (v && v.side === u.side && hasAb(v, 'guard')) g = 1; });
    return g;
  }
  function hurt(i, dmg, fl, o) {
    const u = BT.board[i]; if (!u) return 0; o = o || {};
    if (!o.pierce) dmg = Math.max(1, dmg - ustat(u).def - guardCut(i)); else dmg = Math.max(1, dmg);
    u.hp -= dmg; fl.push({ i: i, t: '-' + dmg, c: 'r' }); if (u.hp <= 0) die(i, fl); return dmg;
  }
  function die(i, fl) {
    const u = BT.board[i], c = CARD[u.id];
    if (c.fx && c.fx.kind === 'rise' && !u.rose) { u.rose = 1; u.hp = c.fx.hp; u.psn = null; fl.push({ i: i, t: 'RISE', c: 'g' }); return; }
    BT.board[i] = null; if (u.side === 'e') { G.stats.kills++; track('kill', 1); }
  }
  /* ---------- اثر کارت ---------- */
  function applyCard(card, side, i, fl) {
    const u = BT.board[i];
    if (isUnit(card)) { BT.board[i] = mkUnit(card.id, side); BT.land = i; return; }
    if (card.type === 'equipment') { if (u) { if (card.slot === 'weapon') u.wp = card.id; else u.tl = card.id; fl.push({ i: i, t: 'EQUIP', c: 'g' }); } return; }
    const f = card.fx;
    if (f.kind === 'heal' && u) { const g = Math.min(f.amt, u.mhp - u.hp); u.hp += g; fl.push({ i: i, t: '+' + g, c: 'g' }); return; }
    if (f.kind === 'dmg' && u) { hurt(i, f.amt, fl, { pierce: 1 }); if (f.freeze && BT.board[i]) { BT.board[i].frz = f.freeze; fl.push({ i: i, t: 'FROZEN', c: 'b' }); } return; }
    if (f.kind === 'poison') {
      card.at.forEach(o => { const rc = rcOf(i), t = idxOf(rc[0] + o[1], rc[1] + o[0]), v = t >= 0 ? BT.board[t] : null; if (v && v.side !== side) { v.psn = { d: f.dmg, t: f.turns }; fl.push({ i: t, t: 'POISON', c: 'g' }); } });
    }
  }
  /* بازی‌کردن کارت از دست: همهٔ قوانین (مانا، سقف استقرار، هدف) اینجا بررسی می‌شود */
  function playCard(side, hi, target) {
    if (!BT || BT.over || BT.phase !== 'player' && side === 'p') return { ok: false, msg: 'Not your turn.' };
    const P = BT[side], id = P.hand[hi], card = CARD[id]; if (!card) return { ok: false, msg: 'No such card.' };
    if (side === 'p' && !G.owned[id]) return { ok: false, msg: 'You do not own this card.' };
    if (card.cost > P.mana) return { ok: false, msg: 'Not enough Mana (' + card.cost + ' needed).' };
    if (P.dep >= CFG.deployPerTurn) return { ok: false, msg: 'No plays left this turn.' };
    if (card.type === 'equipment') { const tu = BT.board[target]; if (tu && tu.side === side) { const ck = equipCheck(card, tu); if (!ck.ok) return { ok: false, msg: ck.msg }; } }
    if (targetsFor(card, side).indexOf(target) < 0) return { ok: false, msg: 'Invalid target.' };
    const fl = []; P.mana -= card.cost; P.dep++; P.hand.splice(hi, 1); applyCard(card, side, target, fl);
    if (side === 'p') { G.stats.played++; track('play', 1); syncGoals(); }
    return { ok: true, fl: fl, card: card };
  }
  function doMove(i, t) {
    const u = BT.board[i]; if (!u || moveTargets(i).indexOf(t) < 0) return false; BT.board[t] = u; BT.board[i] = null; u.moved = 1; return true;
  }
  /* ---------- حملهٔ یک واحد ---------- */
  function unitAct(u) {
    const i = BT.board.indexOf(u); if (i < 0) return null; const fx = { atk: i, hits: [], fl: [] };
    if (u.frz > 0) { u.frz--; fx.fl.push({ i: i, t: 'FROZEN', c: 'b' }); return fx; }
    const st = ustat(u), pat = upattern(u), hits = [];
    pat.forEach(o => { const t = offIdx(i, u.side, o); if (t >= 0 && BT.board[t] && BT.board[t].side !== u.side && hits.indexOf(t) < 0) hits.push(t); });
    if (hits.length) { hits.forEach(t => { if (BT.board[t]) { hurt(t, st.atk, fx.fl); fx.hits.push(t); } }); return fx; }
    /* مسیر خالی از دشمن + واحد در ردیف جلو (یا برد دور) => ضربه به پایگاه */
    const rc = rcOf(i), dir = u.side === 'p' ? -1 : 1; let blocked = false;
    for (let r = rc[0] + dir; r >= 0 && r <= 3; r += dir) { const v = BT.board[idxOf(r, rc[1])]; if (v && v.side !== u.side) blocked = true; }
    const front = u.side === 'p' ? rc[0] <= 2 : rc[0] >= 1, far = pat.some(o => o[1] <= -2);
    if (!blocked && (front || far)) {
      const f = foe(u.side), d = Math.max(1, st.atk); BT[f].hp = Math.max(0, BT[f].hp - d); fx.base = f; fx.fl.push({ base: f, t: '-' + d, c: 'r' }); return fx;
    }
    return null;
  }
  function tickPoison() {
    const fl = [];
    BT.board.forEach((u, i) => { if (u && u.psn) { const d = u.psn.d; u.hp -= d; fl.push({ i: i, t: '-' + d, c: 'g' }); u.psn.t--; if (u.psn.t <= 0) u.psn = null; if (u.hp <= 0) die(i, fl); } });
    return fl;
  }
  function checkEnd() {
    if (BT.over) return BT.over;
    if (BT.e.hp <= 0 && BT.p.hp > 0) BT.over = 'win'; else if (BT.p.hp <= 0) BT.over = 'lose';
    else if (BT.turn > 25) BT.over = BT.p.hp > BT.e.hp ? 'win' : 'lose';
    return BT.over;
  }
  function startTurn() {
    BT.turn++; ['p', 'e'].forEach(s => { const P = BT[s]; P.max = Math.min(CFG.manaMax, CFG.startMana + BT.turn - 1 + (s === 'e' && BT.tier > 1 ? 1 : 0)); P.mana = P.max; P.dep = 0; P.drew = 0; });
    BT.board.forEach(u => { if (u) u.moved = 0; }); BT.phase = 'player';
  }
  /* ---------- هوش مصنوعی دشمن (و ربات آزمایشی بازیکن) ---------- */
  function cardScore(card, side) {
    const tg = targetsFor(card, side); if (!tg.length) return null; let best = null;
    const mine = BT.board.map((u, i) => [u, i]).filter(p => p[0] && p[0].side === side), their = BT.board.map((u, i) => [u, i]).filter(p => p[0] && p[0].side !== side);
    const val = u => { const s = ustat(u); return s.atk * 1.4 + u.hp * .6 + CARD[u.id].cost * .4; };
    tg.forEach(t => {
      let sc = 0; const u = BT.board[t];
      if (isUnit(card)) {
        const col = t % 5, row = rcOf(t)[0], front = side === 'p' ? row === 2 : row === 1;
        sc = 4 + card.atk * 1.3 + card.hp * .7 + card.cost * .5 + (front ? 2 : -1) + their.filter(p => p[1] % 5 === col).length * 1.2 - Math.abs(col - 2) * .2 + Math.random();
      } else if (card.type === 'equipment') {
        const b = card.bonus || {}; sc = 3 + (b.atk || 0) * 1.6 + (b.def || 0) * 1.4 + (b.reach || 0) + val(u) * .15 + Math.random();
      } else if (card.fx.kind === 'heal') { const miss = u.mhp - u.hp; sc = miss >= card.fx.amt * .6 ? 3 + miss * .8 : -1; }
      else if (card.fx.kind === 'dmg') { const real = Math.max(1, card.fx.amt); sc = real >= u.hp ? 5 + val(u) : 2 + real * .8 + val(u) * .15; }
      else { const n = card.at.filter(o => { const rc = rcOf(t), k = idxOf(rc[0] + o[1], rc[1] + o[0]), v = k >= 0 ? BT.board[k] : null; return v && v.side !== side; }).length; sc = 1 + n * 2.4 + val(u) * .1; }
      if (!best || sc > best.sc) best = { sc: sc, t: t };
    });
    return best && best.sc > 0 ? best : null;
  }
  function aiPickPlay(side) {
    const P = BT[side]; if (P.dep >= (side === 'e' ? ENEMIES[BT.tier].dep : CFG.deployPerTurn)) return null; let pick = null;
    P.hand.forEach((id, hi) => { const c = CARD[id]; if (c.cost > P.mana) return; const r = cardScore(c, side); if (!r) return; const sc = r.sc + (c.cost <= P.mana ? c.cost * .35 : 0); if (!pick || sc > pick.sc) pick = { sc: sc, hi: hi, t: r.t }; });
    return pick;
  }
  function aiPickMove(side) {
    let best = null;
    BT.board.forEach((u, i) => {
      if (!u || u.side !== side) return; const mv = moveTargets(i); if (!mv.length) return;
      const c0 = unitAct0(u, i); if (c0) return; /* اگر همین‌جا هدف دارد حرکت نمی‌کند */
      mv.forEach(t => {
        const rc = rcOf(t), cnt = BT.board.filter((v, k) => v && v.side !== side && k % 5 === t % 5).length; let sc = (side === 'p' ? 3 - rc[0] : rc[0]) + cnt * 1.5 + Math.random();
        const saved = BT.board[i]; BT.board[t] = saved; BT.board[i] = null; const inr = unitAct0(saved, t); BT.board[i] = saved; BT.board[t] = null; if (inr) sc += 3; if (!best || sc > best.sc) best = { sc: sc, i: i, t: t };
      });
    });
    return best;
  }
  function unitAct0(u, i) { const pat = upattern(u); return pat.some(o => { const t = offIdx(i, u.side, o); return t >= 0 && BT.board[t] && BT.board[t].side !== u.side; }); }
  /* ترتیب حمله: سریع‌ترها اول؛ در تساوی بازیکن */
  const attackOrder = () => BT.board.filter(Boolean).sort((a, b) => (CARD[b.id].spd - CARD[a.id].spd) || (a.side === 'p' ? -1 : 1));
  function resolveRewards() {
    if (BT.rewarded || !BT.over) return null; BT.rewarded = 1; const win = BT.over === 'win', t = BT.tier;
    const r = win ? { gold: 70 + 20 * t, xp: 55 + 15 * t } : { gold: 15, xp: 18 };
    G.stats.battles++; if (win) G.stats.wins++; else G.stats.losses++; track('battle', 1); if (win) track('win', 1);
    const got = eco.give(r); G.rewarded[BT.id] = 1; G.battle = null; syncGoals(); persist(); got.win = win; return got;
  }

  /* ---------- کشیدن دستی کارت: دقیقاً ۱ مانا؛ همهٔ بررسی‌ها قبل از کسر مانا ---------- */
  function manualDraw(side) {
    if (!BT || BT.over) return { ok: false, msg: 'No battle in progress.' };
    if (side === 'p' && BT.phase !== 'player') return { ok: false, msg: 'Not your turn.' };
    const P = BT[side];
    if (P.mana < CFG.drawCost) return { ok: false, msg: 'Not enough Mana to draw (' + CFG.drawCost + ' needed).' };
    if (P.hand.length >= CFG.handMax) return { ok: false, msg: 'Your hand is full (' + CFG.handMax + ').' };
    if (!P.draw.length) return { ok: false, msg: 'The Deck is empty.' };
    P.mana -= CFG.drawCost; P.drew = (P.drew || 0) + 1; const id = P.draw.shift(); P.hand.push(id); return { ok: true, id: id };
  }
  function unequip(i, slot) {
    const u = BT && BT.board[i]; if (!u || u.side !== 'p' || BT.phase !== 'player' || BT.over) return { ok: false, msg: 'Cannot do that now.' };
    const id = slot === 'wp' ? u.wp : u.tl; if (!id) return { ok: false, msg: 'Nothing equipped.' };
    if (BT.p.hand.length >= CFG.handMax) return { ok: false, msg: 'Your hand is full.' };
    BT.p.hand.push(id); if (slot === 'wp') u.wp = null; else u.tl = null; return { ok: true };
  }
  /* تصمیم بعدی هوش مصنوعی (همان قوانین بازیکن: مانا، سقف استقرار، کشیدن با ۱ مانا) */
  function aiNext(side) {
    const P = BT[side], lim = side === 'e' ? ENEMIES[BT.tier].dep : CFG.deployPerTurn, pk = aiPickPlay(side);
    if (pk) return { k: 'play', hi: pk.hi, t: pk.t };
    if (P.dep < lim && P.mana >= CFG.drawCost && P.hand.length < CFG.handMax && P.draw.length && (P.drew || 0) < 2 && P.hand.length < 3) return { k: 'draw' };
    return null;
  }
  /* ======================================================================
     CROWNFALL — رابط کاربری: تصویرها، صحنه‌های تمام‌صفحه، منو، پیش از نبرد، صفحه‌های پنلی
     ====================================================================== */
  let ov = null, view = 'menu', detail = null, modal = null, UI = { sel: -1, unit: -1, fx: null, busy: false, res: null, back: 'menu', hint: '' };
  const IMGF = { menu: 'crownfall_menu.png', home: 'crownfall_home.png', field: 'crownfall_battlefield.png' };
  const IMG_DIRS = ['./assets/', 'assets/'];
  const IMG = { ok: false, err: '', loading: false, menu: '', home: '', field: '' };
  IMG.st = {};
  function loadAssets() {
    if (IMG.loading) return; IMG.loading = true; const keys = Object.keys(IMGF); let done = 0;
    keys.forEach(k => {
      if (IMG.st[k] === 'ok') { done++; return; } let n = 0; const im = new Image();
      const end = () => { if (++done < keys.length) return; IMG.loading = false; if (ov) render(); };
      im.onload = () => { IMG[k] = im.src; IMG.st[k] = 'ok'; end(); };
      im.onerror = () => { if (++n < IMG_DIRS.length) im.src = IMG_DIRS[n] + IMGF[k]; else { IMG.st[k] = 'bad'; try { console.error('[crownfall] missing: ' + IMGF[k]); } catch (e) {} end(); } };
      im.src = IMG_DIRS[0] + IMGF[k];
    });
    if (done >= keys.length) IMG.loading = false;
  }
  /* فقط تصویرِ همین صفحه لازم است؛ اگر نبود نام دقیق فایل نشان داده می‌شود */
  function assetGuard(k) {
    if (IMG.st[k] === 'ok') return false; if (!IMG.st[k]) loadAssets();
    const bad = IMG.st[k] === 'bad';
    ov.innerHTML = '<div class="stgwrap"><div class="assetmsg"><b>' + (bad ? 'Image loading error' : 'Loading…') + '</b>' + (bad ? '<p>Missing file: assets/' + esc(IMGF[k]) + '</p><p>Copy the image into the assets folder with exactly this name.</p><button class="pxbtn" data-pa="c:menu">Back</button> <button class="pxbtn alt" data-pa="close">Close</button>' : '') + '</div></div>';
    return true;
  }
  const cfpx = n => Math.round(n * 100) / 100;
  const cfbx = (x, y, w, h, cls, attr, inner) => '<div class="' + cls + '" style="left:' + cfpx(x) + 'px;top:' + cfpx(y) + 'px;width:' + cfpx(w) + 'px;height:' + cfpx(h) + 'px" ' + (attr || '') + '>' + (inner || '') + '</div>';
  const cfHit = (b, a) => cfbx(b[0], b[1], b[2] - b[0], b[3] - b[1], 'hit', 'data-pa="' + a + '"');
  /* تکه‌ای که عدد ثابت تصویر را می‌پوشاند و با مقدار واقعی جایگزین می‌کند */
  const patch = (r, g, inner, cls) => '<div class="pt ' + (cls || '') + '" style="left:' + r[0] + 'px;top:' + r[1] + 'px;width:' + (r[2] - r[0]) + 'px;height:' + (r[3] - r[1]) + 'px;background:linear-gradient(' + g[0] + ',' + g[1] + ')">' + (inner || '') + '</div>';
  const cfScene = (img, w, h, inner, fill) => '<div class="stgwrap"><div class="stgbg" style="background-image:url(' + img + ')"></div><div class="stg"' + (fill ? ' data-fill="1"' : '') + ' data-w="' + w + '" data-h="' + h + '" style="width:' + w + 'px;height:' + h + 'px"><img class="stgimg" src="' + img + '" alt="" draggable="false">' + inner + '</div></div>';
  /* صحنه تمام صفحه را می‌پوشاند؛ بیشترین بریدگی افقی کم و باقی با پس‌زمینهٔ محوِ همان تصویر پر می‌شود */
  function stageFit() {
    if (!ov) return;
    const W = ov.clientWidth || window.innerWidth, H = ov.clientHeight || window.innerHeight;
    ov.querySelectorAll('.stg').forEach(el => {
      const w = +el.dataset.w, h = +el.dataset.h, cover = Math.max(W / w, H / h), s = Math.max(W / w, Math.min(cover, W / (0.92 * w)));
      if (el.dataset.fill === '2') { const sx = W / w, sy = Math.max(sx, Math.min(H / h, sx * 1.45)); el.style.transform = 'translate(-50%,-50%) scale(' + cfpx(sx) + ',' + cfpx(sy) + ')'; return; }
      if (el.dataset.fill) { const sx = Math.max(W / w, Math.min(cover, W / (0.97 * w))), sy = Math.max(sx, Math.min(H / h, sx * 1.45)); el.style.transform = 'translate(-50%,-50%) scale(' + cfpx(sx) + ',' + cfpx(sy) + ')'; return; }
      el.style.transform = 'translate(-50%,-50%) scale(' + cfpx(s) + ')';
    });
    placeBar();
  }
  function placeBar() {
    const bar = ov && ov.querySelector('.cfbar'), st = ov && ov.querySelector('.stg'); if (!bar || !st) return;
    const r = st.getBoundingClientRect(), o = ov.getBoundingClientRect(), k = r.height / (+st.dataset.h), h = Math.max(96, 208 * k);
    bar.style.top = (r.top - o.top + 1262 * k) + 'px'; bar.style.height = h + 'px'; bar.style.setProperty('--hw', Math.max(60, Math.floor((h - 14) * 288 / 408)) + 'px');
  }
  function stageShow(html) { ov.dataset.sk = skin(); ov.innerHTML = html; paint(ov); stageFit(); }
  const TOAST = m => { try { nimbo.toast(m); } catch (e) {} };

  /* ---------- صدا و موسیقی (با تنظیمات) ---------- */
  let AC = null, musT = 0, musI = 0;
  function audio() { if (!AC) { try { AC = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { AC = null; } } if (AC && AC.state === 'suspended') { try { AC.resume(); } catch (e) {} } return AC; }
  function tone(f, d, type, vol, delay) {
    const a = audio(); if (!a) return; try {
      const t = a.currentTime + (delay || 0), o = a.createOscillator(), g = a.createGain(); o.type = type || 'square'; o.frequency.setValueAtTime(f, t);
      g.gain.setValueAtTime(vol || .05, t); g.gain.exponentialRampToValueAtTime(.0001, t + d); o.connect(g); g.connect(a.destination); o.start(t); o.stop(t + d + .02);
    } catch (e) {}
  }
  function sfx(k) {
    if (!G.settings.sound) return;
    if (k === 'click') tone(620, .05, 'square', .035); else if (k === 'play') { tone(380, .08, 'square', .05); tone(570, .1, 'square', .05, .07); }
    else if (k === 'hit') { tone(140, .12, 'sawtooth', .07); tone(90, .14, 'square', .05, .05); } else if (k === 'heal') { tone(520, .1, 'sine', .06); tone(780, .14, 'sine', .06, .08); }
    else if (k === 'coin') { tone(880, .07, 'square', .04); tone(1320, .1, 'square', .04, .06); }
    else if (k === 'win') [523, 659, 784, 1047].forEach((f, i) => tone(f, .22, 'square', .05, i * .14));
    else if (k === 'lose') [392, 330, 262, 196].forEach((f, i) => tone(f, .26, 'triangle', .06, i * .18));
    else if (k === 'err') tone(160, .15, 'square', .05);
    if (G.settings.vibration && (k === 'hit' || k === 'win' || k === 'lose')) { try { navigator.vibrate && navigator.vibrate(k === 'hit' ? 25 : 80); } catch (e) {} }
  }
  function musicStart() {
    if (!G.settings.music || musT || !ov || !audio()) return; const N = [220, 262, 330, 262, 196, 247, 294, 247, 220, 262, 349, 262, 175, 220, 262, 220];
    musT = setInterval(() => { if (!ov || document.hidden) return; tone(N[musI++ % N.length], .4, 'triangle', .028); }, 440);
  }
  function musicStop() { clearInterval(musT); musT = 0; }

  /* ---------- مودال‌ها ---------- */
  const mbtn = (a, t, alt) => '<button class="pxbtn' + (alt ? ' alt' : '') + '" data-pa="' + a + '">' + t + '</button>';
  function modalHtml() {
    if (!modal) return '';
    return '<div class="cfmask" data-pa="m:x"><div class="cfmodal2" data-pa="m:keep"><b>' + esc(modal.title) + '</b><div class="mb">' + modal.body + '</div><div class="mbtns">' + (modal.btns || mbtn('m:x', 'OK')) + '</div></div></div>';
  }
  const showModal = (title, body, btns) => { modal = { title: title, body: body, btns: btns }; render(); };

  /* ---------- ۱) منوی اصلی ---------- */
  function menuRender() {
    if (assetGuard('menu')) return;
    stageShow(cfScene(IMG.menu, 941, 1672, cfHit([240, 790, 700, 910], 'c:play') + cfHit([240, 945, 700, 1062], 'c:about') + cfHit([240, 1098, 700, 1215], 'c:setting') + cfHit([240, 1250, 700, 1368], 'c:exit')) + modalHtml());
  }
  /* ---------- ۲) پیش از نبرد: مقدارهای واقعی روی عددهای ثابت تصویر ---------- */
  function hubRender() {
    if (assetGuard('home')) return;
    ensureMissions(); syncGoals();
    const need = G.level >= LV_MAX ? 1 : xpNeed(G.level), pct = G.level >= LV_MAX ? 100 : Math.round(100 * G.xp / need), tr = ['transparent', 'transparent'];
    const hud = patch([188, 24, 320, 54], tr, 'Lv. ' + G.level, 'hlv') + patch([176, 61, 338, 76], tr, '<i style="width:' + pct + '%"></i>', 'hxp') +
      patch([454, 30, 560, 70], tr, shortN(G.gold), 'hnum') + patch([654, 30, 752, 70], tr, shortN(G.gems), 'hnum');
    const o = hud + cfHit([862, 14, 925, 84], 'c:menu') + cfHit([262, 855, 690, 992], 'g:battle') +
      cfHit([16, 1028, 305, 1276], 'v:cards') + cfHit([322, 1028, 620, 1276], 'v:collection') + cfHit([638, 1028, 925, 1276], 'v:level') +
      cfHit([16, 1294, 305, 1540], 'v:missions') + cfHit([322, 1294, 620, 1540], 'v:guide') + cfHit([638, 1294, 925, 1540], 'v:shop');
    stageShow(cfScene(IMG.home, 941, 1671, o, 2) + modalHtml());
  }
  function shortN(n) { n = Math.floor(n); return n >= 1e6 ? (n / 1e6).toFixed(1) + 'M' : (n >= 1e5 ? Math.floor(n / 1000) + 'k' : String(n)); }

  /* ---------- صفحه‌های پنلی ---------- */
  const CHIPS = (list, cur, kind, all) => '<div class="pxchips">' + [['all', 'All']].concat(list).map(a => '<button class="pxchip' + (cur === a[0] ? ' on' : '') + '" data-pa="f:' + kind + ':' + a[0] + '">' + a[1] + '</button>').join('') + '</div>';
  const CAT_CHIPS = CATS.map(c => [c, CAT_NAME[c]]), RAR_CHIPS = RARITIES.map(r => [r, r[0].toUpperCase() + r.slice(1)]);
  const RAR_LABEL = r => r[0].toUpperCase() + r.slice(1);
  function hdr(title, back) {
    return '<div class="pxh"><button class="pxb" data-pa="' + (back || 'v:hub') + '">◀</button><div class="pxt">' + esc(title) + '</div>' +
      '<div class="pxcoin g"><i class="ci g"></i><b>' + shortN(G.gold) + '</b></div><div class="pxcoin m"><i class="ci m"></i><b>' + shortN(G.gems) + '</b></div></div>';
  }
  const panel = (title, body, back) => { ov.dataset.sk = skin(); ov.innerHTML = '<div class="pxapp cfp">' + hdr(title, back) + '<div class="pxbody">' + body + '</div></div>' + (detail ? detailHtml() : '') + modalHtml(); paint(ov); };
  const filt = list => list.filter(c => (G.ui.cat === 'all' || c.cat === G.ui.cat) && (G.ui.rar === 'all' || c.rar === G.ui.rar));
  const tagRar = c => '<span class="rtag r-' + c.rar + '">' + RAR_LABEL(c.rar) + '</span>';

  function cardsView() {
    const own = ownedList(), dn = G.deck.length;
    const tabs = '<div class="pxchips"><button class="pxchip' + (G.ui.tab === 'owned' ? ' on' : '') + '" data-pa="f:tab:owned">Owned (' + own.length + ')</button><button class="pxchip' + (G.ui.tab === 'deck' ? ' on' : '') + '" data-pa="f:tab:deck">Deck (' + dn + '/' + CFG.deckSize + ')</button></div>';
    const cap = '<div class="pxsum">Deck <b>' + dn + ' / ' + CFG.deckSize + '</b> · up to ' + CFG.copyLimit + ' copies of a card · battles need at least ' + CFG.minDeck + '</div><div class="pxbar"><div><i style="width:' + Math.round(100 * dn / CFG.deckSize) + '%"></i></div></div><div class="pxsum">' + CATS.map(k => [CAT_NAME[k], G.deck.filter(id => CARD[id].cat === k).length]).filter(x => x[1]).map(x => x[0] + ' ' + x[1]).join(' · ') + '</div>';
    let body;
    if (G.ui.tab === 'deck') {
      const ids = []; G.deck.forEach(id => { if (ids.indexOf(id) < 0) ids.push(id); }); ids.sort((a, b) => CARD[a].cost - CARD[b].cost);
      body = ids.length ? '<div class="pxgrid">' + ids.map(id => cell(CARD[id])).join('') + '</div>' : '<p class="pxhint">Your deck is empty. Open the Owned tab and add cards.</p>';
    } else body = CHIPS(CAT_CHIPS, G.ui.cat, 'cat') + CHIPS(RAR_CHIPS, G.ui.rar, 'rar') + '<div class="pxgrid">' + (filt(own).map(c => cell(c)).join('') || '<p class="pxhint">No cards match.</p>') + '</div>';
    function cell(c) {
      const k = deckCount(c.id);
      return '<div class="pxcell cfcc"><div data-pa="open:' + c.id + '">' + cardHtml(c, { w: 144, count: false }) + '</div><div class="cfctl"><button data-pa="d:-:' + c.id + '"' + (k ? '' : ' disabled') + '>−</button><span>' + k + '</span><button data-pa="d:+:' + c.id + '">+</button></div></div>';
    }
    return tabs + cap + body;
  }
  function collView() {
    const have = ownedList().length;
    return '<div class="pxsum">Collected <b>' + have + ' / ' + CARDS.length + '</b> cards — locked cards can be bought in the Shop.</div><div class="pxbar"><div><i style="width:' + Math.round(100 * have / CARDS.length) + '%"></i></div></div>' + CHIPS(CAT_CHIPS, G.ui.cat, 'cat') + CHIPS(RAR_CHIPS, G.ui.rar, 'rar') +
      '<div class="pxgrid">' + (filt(CARDS).map(c => { const o = G.owned[c.id]; return '<div class="pxcell cfcc' + (o ? '' : ' lockd') + '" data-pa="open:' + c.id + '">' + cardHtml(c, { w: 144, count: false, reveal: true }) + '<div class="cftag ' + (o ? 'ok' : 'no') + '">' + (o ? 'OWNED' : 'LOCKED') + '</div></div>'; }).join('') || '<p class="pxhint">No cards match.</p>') + '</div>';
  }
  function shopView() {
    const left = CARDS.filter(c => !G.owned[c.id]).sort((a, b) => a.price - b.price);
    const tabs = '<div class="pxchips"><button class="pxchip' + (G.ui.sh === 'cards' ? ' on' : '') + '" data-pa="f:sh:cards">Cards (Gold)</button><button class="pxchip' + (G.ui.sh === 'gems' ? ' on' : '') + '" data-pa="f:sh:gems">Gem Offers</button></div>';
    if (G.ui.sh === 'gems') {
      const gc = left.filter(c => c.gems);
      return tabs + '<div class="pxpanel cfex"><div><b>Gem Exchange</b><br><small>' + CFG.gemToGold[0] + ' Gems → ' + CFG.gemToGold[1] + ' Gold (repeatable)</small></div>' + mbtn('s:ex', 'Exchange') + '</div>' +
        '<div class="pxsum">Premium cards sold for Gems</div><div class="pxgrid">' + (gc.map(c => '<div class="pxcell cfcc"><div data-pa="open:' + c.id + '">' + cardHtml(c, { w: 144, count: false, reveal: true }) + '</div><button class="cfbuy' + (G.gems >= c.gems ? '' : ' no') + '" data-pa="s:g:' + c.id + '"><i class="ci m"></i>' + c.gems + '</button></div>').join('') || '<p class="pxhint">No premium cards left to buy.</p>') + '</div>';
    }
    return tabs + '<div class="pxsum">' + left.length + ' cards left to collect · earn Gold in battles, missions and daily rewards</div>' + CHIPS(RAR_CHIPS, G.ui.rar, 'rar') +
      '<div class="pxgrid">' + (left.filter(c => G.ui.rar === 'all' || c.rar === G.ui.rar).map(c => '<div class="pxcell cfcc"><div data-pa="open:' + c.id + '">' + cardHtml(c, { w: 144, count: false, reveal: true }) + '</div><div class="cfmeta">' + tagRar(c) + '</div><button class="cfbuy' + (G.gold >= c.price ? '' : ' no') + '" data-pa="s:b:' + c.id + '"><i class="ci g"></i>' + c.price + '</button></div>').join('') || '<p class="pxhint">You own every card in this list!</p>') + '</div>';
  }
  function levelView() {
    const need = G.level >= LV_MAX ? 0 : xpNeed(G.level), S = G.stats, wr = S.battles ? Math.round(100 * S.wins / S.battles) : 0;
    let rw = ''; for (let l = G.level + 1; l <= Math.min(LV_MAX, G.level + 6); l++) { const r = lvReward(l); rw += '<div class="pxrow"><span>Level ' + l + '</span><b>' + rewardText(r) + '</b></div>'; }
    const row = (a, b) => '<div class="pxrow"><span>' + a + '</span><b>' + b + '</b></div>';
    return '<div class="pxpanel cfprof"><div class="pname"><label>Name</label><input id="cfname" maxlength="12" value="' + esc(G.profile.name) + '"></div><div class="plv">Level <b>' + G.level + '</b></div>' +
      '<div class="pxbar lgb"><div><i style="width:' + (need ? Math.round(100 * G.xp / need) : 100) + '%"></i></div><b>' + (need ? G.xp + ' / ' + need + ' XP' : 'MAX LEVEL') + '</b></div>' + (need ? '<div class="pxhint">' + (need - G.xp) + ' XP to level ' + (G.level + 1) + '</div>' : '') + '</div>' +
      '<div class="pxsum">Level rewards (given automatically)</div><div class="pxpanel">' + (rw || '<p class="pxhint">You reached the maximum level.</p>') + '</div>' +
      '<div class="pxsum">Statistics</div><div class="pxpanel">' + row('Battles', S.battles) + row('Wins / Losses', S.wins + ' / ' + S.losses) + row('Win rate', wr + '%') + row('Gold earned', S.goldEarned) + row('Enemy cards destroyed', S.kills) + row('Cards played', S.played) + row('Cards owned', ownedList().length + ' / ' + CARDS.length) + '</div>';
  }
  function missionsView() {
    ensureMissions(); syncGoals(); const tab = G.ui.mtab;
    const tabs = '<div class="pxchips">' + [['daily', 'Daily'], ['weekly', 'Weekly'], ['special', 'Special'], ['ach', 'Achievements']].map(t => '<button class="pxchip' + (tab === t[0] ? ' on' : '') + '" data-pa="f:mtab:' + t[0] + '">' + t[1] + '</button>').join('') + '</div>';
    const item = (m, p, claimed, act) => {
      const done = p >= m.n;
      return '<div class="pxpanel cfm' + (claimed ? ' cl' : '') + '"><div class="mt"><b>' + esc(m.t) + '</b>' + (m.d ? '<small>' + esc(m.d) + '</small>' : '') + '<span class="mrw">' + rewardText(m) + '</span></div><div class="mp"><div class="pxbar"><div><i style="width:' + Math.round(100 * Math.min(p, m.n) / m.n) + '%"></i></div><small>' + Math.min(p, m.n) + ' / ' + m.n + '</small></div>' +
        (claimed ? '<span class="mdone">Claimed</span>' : (done ? mbtn(act, 'Claim') : '<span class="mlock">In progress</span>')) + '</div></div>';
    };
    let body;
    if (tab === 'ach') body = ACHS.map(a => item(a, goalProg(a.k), !!G.ach[a.id], 'a:' + a.id)).join('');
    else { const key = tab === 'daily' ? 'd' : tab === 'weekly' ? 'w' : 's'; body = (tab === 'daily' ? '<div class="pxsum">Resets every day</div>' : tab === 'weekly' ? '<div class="pxsum">Resets every Monday</div>' : '<div class="pxsum">One-time goals</div>') + missionList(tab).map(m => { const e = G.missions[key][m.id]; return item(m, e.p, !!e.c, 'ms:' + tab + ':' + m.id); }).join(''); }
    return tabs + body;
  }
  function dailyView() {
    const dn = dailyInfo();
    return '<div class="pxsum">Log in every day to build a streak. Current streak: <b>' + (dn.can ? Math.max(0, dn.streak - 1) : dn.streak) + '</b> day(s)</div><div class="cfdays">' + DAILY_R.map((r, i) => {
      const st = dn.can ? (i < dn.idx ? 'done' : i === dn.idx ? 'now' : '') : (i < dn.idx ? 'done' : i === dn.idx ? 'done today' : '');
      return '<div class="cfday ' + st + '"><small>Day ' + (i + 1) + '</small><b>' + rewardText(r).replace(/ · /g, '<br>') + '</b></div>';
    }).join('') + '</div><div class="cfclaim">' + (dn.can ? mbtn('dl', 'Claim Day ' + (dn.idx + 1) + ' reward') : '<p class="pxhint">Come back tomorrow for the next reward!</p>') + '</div>';
  }
  function guideView() {
    const s = (t, b) => '<div class="pxpanel"><b class="gt">' + t + '</b><p>' + b + '</p></div>';
    return s('Goal', 'Reduce the enemy base from ' + CFG.baseHp + '+ HP to zero before yours falls. Win battles to earn Gold, XP and new cards.') +
      s('Your turn', 'Each turn you get Mana (3 on turn 1, +1 each turn, max 10) and draw a card. You may play up to ' + CFG.deployPerTurn + ' cards per turn. Tap a card in your hand, then tap a glowing slot. Tap one of your units to see where it can move; each unit moves once per turn.') +
      s('End turn', 'The enemy plays its cards, then every card fights in order of speed. A card hits the cells in its attack pattern. If no enemy is in its way and it stands in the front row (or has long range), it hits the enemy base instead.') +
      s('Card types', 'Humans and Creatures fight on the board. Weapons add attack; Tools add defense or range. Powers deal damage. Support cards heal. Poison hurts over time.') +
      s('Special abilities', 'Guard: neighbors take 1 less damage. Rise: returns once with 1 HP. Jump and Fly: pass over other cards. Freeze: the target skips its next action.') +
      s('Progress', 'Spend Gold in the Shop to buy cards, build a deck of up to ' + CFG.deckSize + ' cards in Cards, finish Missions and claim Daily Rewards.');
  }
  function settingsView() {
    const row = (k, t, d) => '<div class="pxpanel cfset"><div><b>' + t + '</b><br><small>' + d + '</small></div><button class="tg' + (G.settings[k] ? ' on' : '') + '" data-pa="t:' + k + '">' + (G.settings[k] ? 'ON' : 'OFF') + '</button></div>';
    return row('sound', 'Sound effects', 'Card plays, hits and fanfares') + row('music', 'Music', 'Background tune while playing') + row('vibration', 'Vibration', 'Short buzz on hits') +
      '<div class="pxsum">Theme: ' + T(skinLabel()) + ' (changes with your Nimbo theme mods)</div>' +
      '<div class="pxpanel cfset"><div><b>Reset progress</b><br><small>Erase cards, gold, level and missions</small></div>' + mbtn('r:ask', 'Reset', 1) + '</div>';
  }
  function skinLabel() { return ({ ink: 'skInk', term: 'skTerm', dark: 'skDark', glass: 'skGlass', base: 'skBase' })[skin()]; }
  function detailHtml(fw) {
    const c = CARD[detail.id], own = G.owned[c.id], w = fw || Math.max(192, Math.min(288, Math.floor((window.innerWidth - 40) / 96) * 96));
    const ab = c.ab.length ? '<p><b>Abilities:</b> ' + c.ab.map(a => ({ guard: 'Guard', jump: 'Jump', fly: 'Fly', rise: 'Rise', ranged: 'Ranged', sweep: 'Wide swing', 'range+1': 'Range +1', armor: 'Armor', freeze: 'Freeze', poison: 'Poison' }[a] || a)).join(', ') + '</p>' : '';
    const info = '<div class="pxinfo"><b>' + esc(c.nm) + '</b> ' + tagRar(c) + '<p>' + CAT_NAME[c.cat] + (c.cls ? ' · Class: ' + CLS_NAME[c.cls] : '') + ' · Cost ' + c.cost + ' Mana' + (isUnit(c) ? ' · HP ' + c.hp + ' · ATK ' + c.atk + ' · DEF ' + c.def : '') + '</p>' + (isUnit(c) ? '<p>' + c.atkType + ' attack · range ' + c.range + ' · ' + c.dirs.join('/') + ' · move ' + (c.mvRange || 'none') + '</p>' : '') + (c.type === 'equipment' ? '<p>Slot: ' + (c.slot === 'weapon' ? 'Weapon' : 'Tool') + ' · Usable by: ' + (c.eq ? c.eq.map(x => CLS_NAME[x]).join(', ') : 'anyone') + '</p>' : '') + '<p>' + esc(c.descEn) + '</p>' + ab + '<p dir="ltr">' + esc(c.hw) + '</p>' +
      (view === 'battle' ? '' : own ? '<p class="tip">Owned · ' + deckCount(c.id) + ' in deck</p>' : '<p class="tip">LOCKED — Shop price: ' + c.price + ' Gold' + (c.gems ? ' or ' + c.gems + ' Gems' : '') + '</p>') + (detail.extra || '') + '</div>';
    const btns = '<div class="pxbtns"><button class="pxbtn" data-pa="dflip">Flip</button>' + (!own && view !== 'battle' ? '<button class="pxbtn" data-pa="v:shop">Shop</button>' : '') + '<button class="pxbtn alt" data-pa="dclose">Close</button></div>';
    return '<div class="pxdt" data-pa="dclose"><div class="pxdbox" data-pa="stop">' + cardHtml(c, { w: w, flip: detail.flip, count: false, reveal: true }) + '<p class="pxhint">Tap the card to flip it</p>' + btns + info + '</div></div>';
  }
  const PANELS = { cards: ['Cards', cardsView], collection: ['Collection', collView], shop: ['Shop', shopView], level: ['Level', levelView], missions: ['Missions', missionsView], daily: ['Daily Rewards', dailyView], guide: ['Guide', guideView] };
  function panelRender() {
    if (view === 'settings') return panel('Settings', settingsView(), 'v:' + UI.back);
    const p = PANELS[view]; if (!p) { view = 'hub'; return render(); } panel(p[0], p[1]());
  }

  /* ---------- ۳) میدان نبرد تعاملی ---------- */
  const CF_ROWS = [[487, 605, [[205, 310], [316, 415], [424, 520], [530, 630], [636, 740]]], [625, 755, [[188, 300], [305, 410], [420, 522], [532, 640], [646, 755]]],
    [943, 1088, [[155, 280], [287, 405], [416, 530], [540, 660], [665, 788]]], [1103, 1258, [[138, 268], [275, 402], [412, 535], [545, 672], [676, 808]]]];
  const slotRect = i => { const r = CF_ROWS[Math.floor(i / 5)], x = r[2][i % 5]; return [x[0], r[0], x[1] - x[0], r[1] - r[0]]; };
  const cfCard = (c, w) => '<div class="pxc r-' + c.rar + ' t-' + c.type + '" data-sk="' + skin() + '" style="--w:' + w + 'px"><canvas class="cf" data-card="' + c.id + '" data-face="f" width="288" height="408"></canvas></div>';
  let TK = 0;
  const sleep = ms => new Promise(r => setTimeout(r, ms * (UI.speed || 1)));
  UI.targets = []; UI.mv = []; UI.bad = []; UI.land = -1; UI.speed = 1; UI.newId = -1; UI.dl = 0;
  const clearSel = () => { UI.sel = -1; UI.unit = -1; UI.targets = []; UI.mv = []; UI.bad = []; };
  function unitHtml(u, w, h) {
    const c = CARD[u.id], cw = Math.floor(Math.min(w - 8, (h - 6) * 288 / 408)), st = ustat(u);
    return '<div class="cfu ' + u.side + (u.frz > 0 ? ' frz' : '') + '">' + cfCard(c, cw) + '<div class="cfst"><b class="hp">♥' + u.hp + '</b><b class="at">⚔' + st.atk + '</b></div>' +
      '<div class="cfbd">' + (u.frz > 0 ? '<i class="b">ICE</i>' : '') + (u.psn ? '<i class="g">PSN</i>' : '') + (u.wp ? '<i class="y">WPN</i>' : '') + (u.tl ? '<i class="y">GEAR</i>' : '') + '</div></div>';
  }
  const barP = (r, g, ratio, cls) => patch(r, g, '<i style="width:' + Math.max(0, Math.round(100 * ratio)) + '%"></i>', 'fbar ' + (cls || ''));
  function fieldRender() {
    if (assetGuard('field')) return; if (!BT) { view = 'hub'; return render(); }
    const B = BT, P = B.p, E = B.e; let o = '';
    CF_ROWS.forEach((r, ri) => r[2].forEach((x, ci) => {
      const i = ri * 5 + ci, u = B.board[i]; let cls = 'cfslot ' + (ri < 2 ? 'e' : 'p');
      if (UI.targets.indexOf(i) > -1) cls += ' ok'; if (UI.mv.indexOf(i) > -1) cls += ' mv'; if (UI.unit === i) cls += ' sel'; if (UI.land === i) cls += ' land'; if (UI.bad.indexOf(i) > -1) cls += ' bad';
      o += cfbx(x[0], r[0], x[1] - x[0], r[1] - r[0], cls, 'data-pa="s:' + i + '" data-slot="' + i + '"', u ? unitHtml(u, x[1] - x[0], r[1] - r[0]) : '');
    }));
    /* دست: نوار افقیِ قابل اسکرول بیرون از صحنه (کارت‌ها بزرگ‌تر از کارت‌های میدان) */
    const P0 = B.p.hand, can = B.phase === 'player' && !UI.busy && !B.over;
    const bar = '<div class="cfbar"><div class="cfscroll">' + P0.map((id, hi) => { const c = CARD[id], dim = !can || c.cost > P.mana || P.dep >= CFG.deployPerTurn;
      return '<div class="cfhc' + (UI.sel === hi ? ' sel' : '') + (dim ? ' dim' : '') + (UI.newId === hi ? ' nw' : '') + '" data-pa="h:' + hi + '"><div class="pxc r-' + c.rar + ' t-' + c.type + '" data-sk="' + skin() + '" style="--w:var(--hw)"><canvas class="cf" data-card="' + c.id + '" data-face="f" width="288" height="408"></canvas></div><b class="cfcost">' + c.cost + '</b></div>'; }).join('') + (P0.length ? '' : '<span class="cfempty">Hand empty — tap the Deck to draw (1 Mana)</span>') + '</div></div>';
    UI.newId = -1;
    /* مقدارهای واقعی روی عددهای تصویر */
    o += patch([104, 48, 204, 72], ['#1c1010', '#331a13'], 'HP ' + P.hp + '/' + P.mhp, 'ftx') + barP([100, 22, 278, 42], ['#3a1810', '#220a0c'], P.hp / P.mhp) +
      patch([744, 48, 842, 72], ['#261311', '#2c1812'], 'HP ' + E.hp + '/' + E.mhp, 'ftx') + barP([742, 22, 860, 42], ['#3a1810', '#220a0c'], E.hp / E.mhp, 'rt') +
      patch([352, 26, 402, 50], ['#01060e', '#03060d'], P.mana + '/' + P.max, 'ftx') + patch([496, 26, 556, 50], ['#01050c', '#040810'], shortN(G.gold), 'ftx') +
      patch([645, 26, 688, 50], ['#00050d', '#020409'], Math.max(0, CFG.deployPerTurn - P.dep) + '/' + CFG.deployPerTurn, 'ftx') + patch([424, 78, 514, 102], ['#01060d', '#00040b'], 'Round ' + B.turn, 'ftx') +
      patch([138, 1578, 174, 1614], ['#0d0b09', '#080607'], String(P.draw.length), 'ftx dk') +
      cfbx(110, 452, 720, 34, 'cfhint', '', esc(UI.hint || '')) +
      cfHit([380, 66, 560, 116], 'bm') + cfHit([715, 1478, 918, 1630], 'et') + cfbx(40, 1470, 135, 155, 'cfdeck' + (B.p.draw.length && P.mana >= CFG.drawCost && P.hand.length < CFG.handMax && can ? ' can' : ''), 'data-pa="dk"');
    const sc0 = ov.querySelector('.cfscroll'), sx0 = sc0 ? sc0.scrollLeft : 0;
    stageShow(cfScene(IMG.field, 941, 1672, o) + bar + (detail ? detailHtml() : '') + modalHtml());
    const sc1 = ov.querySelector('.cfscroll'); if (sc1) { sc1.scrollLeft = sx0; const sel = sc1.querySelector('.sel'); if (sel && (sel.offsetLeft < sc1.scrollLeft || sel.offsetLeft + sel.offsetWidth > sc1.scrollLeft + sc1.clientWidth)) sc1.scrollLeft = sel.offsetLeft - 20; }
  }
  const setHint = t => { UI.hint = t; const h = ov && ov.querySelector('.cfhint'); if (h) h.textContent = t; };
  function floatAt(i, t, c) {
    const st = ov && ov.querySelector('.stg'); if (!st) return; const r = slotRect(i), d = document.createElement('div');
    d.className = 'cffl ' + (c || 'r'); d.textContent = t; d.style.left = (r[0] + r[2] / 2) + 'px'; d.style.top = (r[1] + r[3] / 3) + 'px'; st.appendChild(d); setTimeout(() => d.remove(), 1000);
  }
  function floatBase(side, t, c) {
    const st = ov && ov.querySelector('.stg'); if (!st) return; const d = document.createElement('div');
    d.className = 'cffl ' + (c || 'r'); d.textContent = t; d.style.left = (side === 'p' ? 190 : 800) + 'px'; d.style.top = '86px'; st.appendChild(d); setTimeout(() => d.remove(), 1000);
  }
  const floats = fl => (fl || []).forEach(f => { if (f.base) floatBase(f.base, f.t, f.c); else floatAt(f.i, f.t, f.c); });
  function startBattle() {
    if (G.battle && battleLoad()) { TOAST('Battle resumed'); }
    else {
      if (G.deck.length < CFG.minDeck) { TOAST('Your deck needs at least ' + CFG.minDeck + ' cards.'); G.ui.tab = 'deck'; view = 'cards'; return render(); }
      battleNew(); saveBattle();
    }
    clearSel(); UI.busy = false; UI.land = -1; UI.hint = 'Your turn — tap a card, or tap the Deck to draw (1 Mana).'; view = 'battle'; detail = null; render(); musicStart();
  }
  function handTap(hi) {
    if (UI.busy || !BT || BT.over || BT.phase !== 'player') return;
    if (UI.sel === hi) { detail = { id: BT.p.hand[hi], flip: false }; return render(); }
    const id = BT.p.hand[hi], c = CARD[id], P = BT.p;
    if (!G.owned[id]) { sfx('err'); return TOAST('You do not own this card.'); }
    if (c.cost > P.mana) { sfx('err'); setHint('Not enough Mana (' + c.cost + ' needed).'); return TOAST('Not enough Mana (' + c.cost + ' needed).'); }
    if (P.dep >= CFG.deployPerTurn) { sfx('err'); setHint('No plays left this turn.'); return TOAST('No plays left this turn.'); }
    const tg = targetsFor(c, 'p');
    if (!tg.length) { const m = c.type === 'equipment' ? 'No compatible unit for ' + c.nm + ' (' + (c.eq || []).map(x => CLS_NAME[x]).join(', ') + ').' : 'No valid target for this card.'; sfx('err'); setHint(m); return TOAST(m); }
    clearSel(); UI.sel = hi; UI.targets = tg; sfx('click');
    if (c.type === 'equipment') BT.board.forEach((u, k) => { if (u && u.side === 'p' && tg.indexOf(k) < 0) UI.bad.push(k); });
    UI.hint = isUnit(c) ? 'Tap a glowing slot to deploy ' + c.nm + '.' : (c.type === 'equipment' ? 'Pick a compatible card (' + (c.eq || []).map(x => CLS_NAME[x]).join(', ') + ').' : 'Choose a target for ' + c.nm + '.'); render();
  }
  function flyCard(card, from, i) {
    const slot = ov.querySelector('[data-slot="' + i + '"]'), cu = slot && slot.querySelector('.pxc'); if (!slot || !cu) return;
    const to = cu.getBoundingClientRect(), o = ov.getBoundingClientRect(); slot.classList.add('fly');
    const f = document.createElement('div'); f.className = 'cffly'; f.style.cssText = 'left:' + (from.left - o.left) + 'px;top:' + (from.top - o.top) + 'px;width:' + from.width + 'px;height:' + from.height + 'px';
    f.innerHTML = '<div class="pxc r-' + card.rar + ' t-' + card.type + '" data-sk="' + skin() + '" style="--w:' + from.width + 'px"><canvas class="cf" data-card="' + card.id + '" data-face="f" width="288" height="408"></canvas></div>'; ov.appendChild(f); paint(f);
    requestAnimationFrame(() => requestAnimationFrame(() => { f.style.transform = 'translate(' + (to.left - from.left) + 'px,' + (to.top - from.top) + 'px) scale(' + (to.width / from.width) + ')'; }));
    setTimeout(() => { f.remove(); slot.classList.remove('fly'); }, 420);
  }
  function drawTap() {
    if (!BT || BT.over) return; if (UI.busy || BT.phase !== 'player') return TOAST('Wait for your turn.');
    const now = Date.now(); if (now - UI.dl < 300) return; UI.dl = now;
    const r = manualDraw('p'); if (!r.ok) { sfx('err'); setHint(r.msg); return TOAST(r.msg); }
    sfx('play'); UI.hint = 'Drew ' + CARD[r.id].nm + ' (-1 Mana).'; UI.newId = BT.p.hand.length - 1; saveBattle(); render();
    const sc = ov.querySelector('.cfscroll'); if (sc) sc.scrollLeft = sc.scrollWidth;
  }
  function unitDetail(u) {
    const c = CARD[u.id], st = ustat(u);
    const canEdit = u.side === 'p' && !UI.busy && BT.phase === 'player' && !BT.over, ub = (u.wp ? '<button class="pxbtn alt" data-pa="ue:' + BT.board.indexOf(u) + ':wp">Remove ' + esc(CARD[u.wp].nm) + '</button>' : '') + (u.tl ? '<button class="pxbtn alt" data-pa="ue:' + BT.board.indexOf(u) + ':tl">Remove ' + esc(CARD[u.tl].nm) + '</button>' : '');
    detail = { id: u.id, flip: false, extra: (canEdit && ub ? '<div class="pxbtns">' + ub + '</div>' : '') + '<p class="tip">On board: HP ' + u.hp + '/' + u.mhp + ' · ATK ' + st.atk + ' · DEF ' + st.def + (u.wp ? ' · ' + CARD[u.wp].nm : '') + (u.tl ? ' · ' + CARD[u.tl].nm : '') + (u.frz > 0 ? ' · Frozen' : '') + (u.psn ? ' · Poisoned (' + u.psn.d + '/turn, ' + u.psn.t + ' left)' : '') + '</p>' };
    render();
  }
  function slotTap(i) {
    if (!BT || BT.over) return; const u = BT.board[i];
    if (UI.busy || BT.phase !== 'player') { if (u) unitDetail(u); return; }
    if (UI.sel >= 0) {
      if (UI.targets.indexOf(i) < 0) { const sc = CARD[BT.p.hand[UI.sel]]; if (u && u.side === 'p' && sc && sc.type === 'equipment') { const ck = equipCheck(sc, u); sfx('err'); setHint(ck.msg); return TOAST(ck.msg); } if (u) { clearSel(); return unitDetail(u); } sfx('err'); clearSel(); UI.hint = 'Pick a glowing slot, or choose another card.'; return render(); }
      const hEl = ov.querySelector('.cfhc.sel'), from = hEl ? hEl.getBoundingClientRect() : null, r = playCard('p', UI.sel, i);
      if (!r.ok) { sfx('err'); TOAST(r.msg); clearSel(); return render(); }
      sfx(r.card.type === 'spell' ? 'hit' : 'play'); clearSel(); UI.land = isUnit(r.card) ? i : -1; UI.hint = r.card.nm + ' played.'; saveBattle(); render(); floats(r.fl); if (isUnit(r.card) && from) flyCard(r.card, from, i);
      if (UI.land >= 0) setTimeout(() => { UI.land = -1; }, 600); return;
    }
    if (UI.unit >= 0 && UI.mv.indexOf(i) > -1) { const from = UI.unit; if (doMove(from, i)) { sfx('click'); clearSel(); UI.hint = 'Moved.'; saveBattle(); render(); } return; }
    if (u && u.side === 'p') {
      if (UI.unit === i) { clearSel(); return unitDetail(u); }
      clearSel(); UI.unit = i; UI.mv = moveTargets(i);
      UI.hint = UI.mv.length ? 'Tap a green slot to move, or tap the card again for details.' : (u.moved ? 'This card already moved this turn.' : (u.frz > 0 ? 'Frozen cards cannot move.' : 'This card cannot move.')); sfx('click'); return render();
    }
    if (u) return unitDetail(u);
    clearSel(); UI.hint = 'Your turn.'; render();
  }
  /* پایان نوبت: نوبت دشمن، سپس درگیری همهٔ کارت‌ها، سمّ، بررسی پایان و شروع نوبت بعد */
  async function endTurn() {
    if (UI.busy || !BT || BT.over || BT.phase !== 'player') return;
    const tk = TK; UI.busy = true; clearSel(); BT.phase = 'enemy'; setHint('Enemy turn…'); render(); await sleep(450); if (tk !== TK) return;
    for (let k = 0; k < 8; k++) {
      const a = aiNext('e'); if (!a) break;
      if (a.k === 'draw') { if (!manualDraw('e').ok) break; setHint('Enemy draws a card.'); await sleep(400); if (tk !== TK) return; continue; }
      const p = a, r = playCard('e', p.hi, p.t); if (!r.ok) break;
      UI.land = isUnit(r.card) ? p.t : -1; sfx('play'); setHint('Enemy plays ' + r.card.nm + '.'); render(); floats(r.fl); await sleep(650); if (tk !== TK) return; UI.land = -1;
    }
    for (let k = 0; k < 6; k++) { const m = aiPickMove('e'); if (!m) break; if (!doMove(m.i, m.t)) break; render(); await sleep(350); if (tk !== TK) return; }
    setHint('Battle!'); await sleep(250); if (tk !== TK) return;
    const order = attackOrder();
    for (const u of order) {
      if (BT.board.indexOf(u) < 0) continue; const i0 = BT.board.indexOf(u), el = ov && ov.querySelector('[data-slot="' + i0 + '"]');
      const fx = unitAct(u); if (!fx) continue;
      if (el) { el.classList.add(u.side === 'p' ? 'atkp' : 'atke'); await sleep(170); if (tk !== TK) return; }
      sfx(fx.fl.length ? 'hit' : 'click'); render(); floats(fx.fl); await sleep(fx.hits.length || fx.base ? 520 : 300); if (tk !== TK) return;
      if (checkEnd()) break;
    }
    if (!BT.over) { const fl = tickPoison(); if (fl.length) { render(); floats(fl); await sleep(600); if (tk !== TK) return; } checkEnd(); }
    if (!BT.over) { startTurn(); checkEnd(); }
    if (BT.over) return finishBattle();
    UI.busy = false; UI.hint = 'Your turn — Mana ' + BT.p.mana + '. Tap a card.'; saveBattle(); render(); sfx('click');
  }
  function finishBattle() {
    const tk = TK, win = BT.over === 'win'; UI.busy = true; clearSel(); render();
    const got = resolveRewards(); sfx(win ? 'win' : 'lose'); musicStop();
    let body = '<p>' + (win ? 'The enemy base has fallen.' : 'Your base was destroyed.') + '</p><div class="rw"><b>+' + (got ? got.gold : 0) + ' Gold</b><b>+' + (got ? got.xp : 0) + ' XP</b></div>';
    if (got && got.ups.length) body += got.ups.map(u => '<p class="lvup">LEVEL UP! You reached level ' + u.level + '<br>' + rewardText(u) + '</p>').join('');
    if (G.battle === null && claimable()) body += '<p class="hintp">You have rewards to claim in Missions.</p>';
    showModal(win ? 'VICTORY' : 'DEFEAT', body, mbtn('r:done', 'Continue'));
  }
  function leaveBattle() { TK++; if (BT && !BT.over) { if (BT.phase !== 'player') BT.phase = 'player'; saveBattle(); } UI.busy = false; clearSel(); detail = null; modal = null; view = 'hub'; musicStop(); render(); }

  /* ---------- مسیریابی و کلیک‌ها ---------- */
  const saveUi = () => { G.ui.view = view; persist(); };
  function render() {
    if (!ov) return;
    if (view === 'menu') return menuRender();
    if (view === 'hub') return hubRender();
    if (view === 'battle') return fieldRender();
    panelRender();
  }
  function go(v) { detail = null; modal = null; if (v === 'hub' || v === 'menu') { UI.back = v; } view = v; render(); }
  function aboutModal() { showModal('CROWNFALL', '<p>A pixel-art fantasy card battler. Collect cards, build a deck of up to ' + CFG.deckSize + ', and break the enemy base before yours falls.</p>', mbtn('m:x', 'OK')); }
  function openArena() {
    if (ov) return; view = 'menu'; detail = null; modal = null; UI.back = 'menu'; UI.busy = false; clearSel();
    ov = document.createElement('div'); ov.className = 'px-ov'; ov.dir = 'ltr'; ov.addEventListener('click', onClick);
    ov.addEventListener('change', e => { if (e.target.id === 'cfname') { G.profile.name = String(e.target.value).replace(/[<>&"]/g, '').trim().slice(0, 12) || 'Hero'; persist(); TOAST('Name saved'); } });
    window.addEventListener('resize', stageFit); window.addEventListener('orientationchange', stageFit); document.addEventListener('visibilitychange', onVis);
    document.body.appendChild(ov); loadAssets(); render(); window.dispatchEvent(new Event('nimbo-overlay'));
  }
  const onVis = () => { if (document.hidden) { if (BT && !BT.over && view === 'battle' && !UI.busy) saveBattle(); } };
  function closeArena() {
    TK++; musicStop(); window.removeEventListener('resize', stageFit); window.removeEventListener('orientationchange', stageFit); document.removeEventListener('visibilitychange', onVis);
    if (BT && !BT.over && view === 'battle') { BT.phase = 'player'; saveBattle(); }
    if (ov) { ov.remove(); ov = null; detail = null; modal = null; UI.busy = false; window.dispatchEvent(new Event('nimbo-overlay')); }
  }
  function onClick(e) {
    const el = e.target.closest('[data-pa]'); if (!el || !ov.contains(el)) return; const a = el.dataset.pa; if (a !== 'm:keep' && a !== 'stop') sfx('click');
    if (a === 'stop') { const c = e.target.closest('.pxc'); if (c && detail) { detail.flip = !detail.flip; render(); } return; }
    if (a === 'm:keep') return; if (a === 'm:x') { modal = null; return render(); }
    if (a === 'close') return closeArena();
    if (a === 'soon') return TOAST('Coming soon');
    if (a === 'dflip') { detail.flip = !detail.flip; return render(); } if (a === 'dclose') { detail = null; return render(); }
    if (a.indexOf('open:') === 0) { detail = { id: a.slice(5), flip: false }; return render(); }
    if (a.indexOf('v:') === 0) { const v = a.slice(2); if (v === 'hub') { if (view === 'settings' && UI.back === 'menu') return go('menu'); } return go(v); }
    if (a === 'c:play') return go('hub'); if (a === 'c:menu') return go('menu'); if (a === 'c:exit') return closeArena(); if (a === 'c:about') return aboutModal();
    if (a === 'c:setting') { UI.back = view === 'menu' ? 'menu' : 'hub'; return go('settings'); }
    if (a === 'g:battle') return startBattle();
    if (a === 'g:gems') { G.ui.sh = 'gems'; return go('shop'); }
    if (a.indexOf('f:') === 0) { const p = a.split(':'); G.ui[p[1]] = p[2]; persist(); return render(); }
    if (a.indexOf('d:') === 0) { const p = a.split(':'), r = p[1] === '+' ? deckAdd(p[2]) : deckRemove(p[2]); if (!r.ok) { sfx('err'); TOAST(r.msg); } return render(); }
    if (a.indexOf('s:b:') === 0 || a.indexOf('s:g:') === 0) { const r = buyCard(a.slice(4), a[2] === 'g' ? 'gems' : 'gold'); r.ok ? sfx('coin') : sfx('err'); TOAST(r.msg); return render(); }
    if (a === 's:ex') { const r = exchangeGems(); r.ok ? sfx('coin') : sfx('err'); TOAST(r.msg); return render(); }
    if (a.indexOf('ms:') === 0) { const p = a.split(':'), r = claimMission(p[1], p[2]); if (r) { sfx('coin'); claimToast(r); } return render(); }
    if (a.indexOf('a:') === 0) { const r = claimAch(a.slice(2)); if (r) { sfx('coin'); claimToast(r); } return render(); }
    if (a === 'dl') { const r = claimDaily(); if (r) { sfx('coin'); claimToast(r); } return render(); }
    if (a.indexOf('t:') === 0) { const k = a.slice(2); G.settings[k] = !G.settings[k]; persist(); if (k === 'music') { G.settings.music ? musicStart() : musicStop(); } if (k === 'sound' && G.settings.sound) sfx('click'); return render(); }
    if (a === 'r:ask') return showModal('Reset progress?', '<p>This erases your cards, deck, Gold, Gems, level, missions and settings. This cannot be undone.</p>', mbtn('r:yes', 'Yes, reset') + mbtn('m:x', 'Cancel', 1));
    if (a === 'r:yes') { TK++; BT = null; resetAll(); modal = null; UI.busy = false; clearSel(); TOAST('Progress reset.'); return go('hub'); }
    if (a === 'r:done') { modal = null; BT = null; UI.busy = false; return go('hub'); }
    if (a.indexOf('h:') === 0) return handTap(+a.slice(2));
    if (a.indexOf('s:') === 0) return slotTap(+a.slice(2));
    if (a === 'et') return endTurn();
    if (a === 'dk') return drawTap();
    if (a.indexOf('ue:') === 0) { const p = a.split(':'), r = unequip(+p[1], p[2]); if (!r.ok) { sfx('err'); return TOAST(r.msg); } detail = null; saveBattle(); UI.hint = 'Equipment returned to your hand.'; return render(); }
    if (a === 'bm') { if (UI.busy) return; return showModal('Round ' + BT.turn, '<p>Enemy: ' + esc(BT.enemy) + '<br>Your base ' + BT.p.hp + ' HP · Enemy base ' + BT.e.hp + ' HP</p>', mbtn('m:x', 'Resume') + mbtn('b:leave', 'Save & Leave', 1) + mbtn('b:ff', 'Forfeit', 1)); }
    if (a === 'b:leave') return leaveBattle();
    if (a === 'b:ff') return showModal('Forfeit battle?', '<p>You will lose this battle and receive the defeat reward.</p>', mbtn('b:ff2', 'Forfeit') + mbtn('m:x', 'Cancel', 1));
    if (a === 'b:ff2') { modal = null; BT.over = 'lose'; return finishBattle(); }
  }
  function claimToast(r) { TOAST('Claimed: ' + rewardText(r) + (r.ups && r.ups.length ? ' · Level ' + r.ups[r.ups.length - 1].level + '!' : '')); }

  /* ---------- دکمهٔ ورود و واکنش به مودهای دیگر ---------- */
  const top = document.querySelector('.top');
  const btn = document.createElement('button');
  btn.type = 'button'; btn.className = 'px-btn'; btn.setAttribute('aria-label', 'CROWNFALL');
  btn.innerHTML = cvs('hub:collection', 'btnic');
  btn.addEventListener('click', openArena);
  top.insertBefore(btn, top.querySelector('.tools'));
  paint(btn);
  const mo = new MutationObserver(() => { palCache.ink = palCache.term = null; paint(btn); render(); });
  mo.observe(B, { attributes: true, attributeFilter: ['class'] });
  nimbo.onView(() => { if (ov) render(); });
  window.__pxl = { html: cardHtml, paint: paint, G: () => G, CFG: CFG, CARDS: CARDS, open: openArena, close: closeArena, skin: skin,
    T: { playCard, manualDraw, equipCheck, unequip, moveTargets, targetsFor, doMove, unitAct, attackOrder, tickPoison, hurt, mkUnit, aiNext, drawTap, BT: () => BT, startBattle: startBattle, endTurn: endTurn, handTap: handTap, slotTap: slotTap, UI: UI, go: go, view: () => view, modal: () => modal } };
  return () => { mo.disconnect(); closeArena(); btn.remove(); delete window.__pxl; };

};
const PXL_CSS = `/* ===== میدان کارت پیکسلی ===== */
.pxs{ image-rendering:pixelated; image-rendering:crisp-edges; display:block; }
.px-btn{ width:40px; height:40px; border-radius:50%; border:0; padding:0; background:var(--card); display:flex; align-items:center; justify-content:center; flex:0 0 auto; }
.px-btn:active{ transform:scale(.88); } .px-btn .btnic{ width:26px; height:26px; }
.px-ov{ --pf:#1a1428; --pb:#2a2150; --pbg:#171233; --ptx:#f3efff; --pmu:#a79bcb; --pac:#f5c542; --pcard:#fff7e0; --pin:#1a1428;
  position:fixed; left:0; top:0; right:0; bottom:0; z-index:160; background:var(--pbg); color:var(--ptx); overflow:hidden; animation:pxIn .25s ease-out; font-family:inherit; }
@keyframes pxIn{ from{ opacity:0; } to{ opacity:1; } }
.px-ov[data-sk=ink]{ --pf:#2b2013; --pb:#c9b57f; --pbg:#e8d9ae; --ptx:#33281a; --pmu:#8a7752; --pac:#b45309; --pcard:#efe1b8; --pin:#2b2013;
  background-image:repeating-linear-gradient(0deg,transparent 0 27px,rgba(139,117,80,.22) 27px 28px); }
.px-ov[data-sk=term]{ --pf:#0f6b34; --pb:#0a3a1c; --pbg:#021008; --ptx:#4ade80; --pmu:#2f9a58; --pac:#22c55e; --pcard:#031a0a; --pin:#22c55e; }
.px-ov[data-sk=dark]{ --pf:#2a2d3a; --pb:#14161d; --pbg:#000; --ptx:#e8eaed; --pmu:#8b93a1; --pac:#7c9cff; --pcard:#0b0b0d; --pin:#e8eaed; }
.px-ov[data-sk=glass]{ --pf:rgba(255,255,255,.55); --pb:rgba(255,255,255,.12); --pbg:#0f2a4a; --ptx:#eaf6ff; --pmu:#a8c6e6; --pac:#7dd3fc; --pcard:rgba(255,255,255,.14); --pin:#eaf6ff;
  background-image:linear-gradient(160deg,#16467a,#0b1d38 60%,#2a1650); }
.pxapp{ height:100%; max-width:560px; margin:0 auto; display:flex; flex-direction:column; }
.pxh{ display:flex; align-items:center; gap:10px; padding:10px 12px; border-bottom:3px solid var(--pf); background:var(--pb); flex:0 0 auto; }
.pxb{ width:40px; height:40px; border:3px solid var(--pf); background:var(--pcard); color:var(--pin); font-size:18px; font-weight:800; border-radius:0; clip-path:polygon(0 4px,4px 4px,4px 0,calc(100% - 4px) 0,calc(100% - 4px) 4px,100% 4px,100% calc(100% - 4px),calc(100% - 4px) calc(100% - 4px),calc(100% - 4px) 100%,4px 100%,4px calc(100% - 4px),0 calc(100% - 4px)); }
.pxb:active{ transform:translateY(2px); }
.pxt{ flex:1; font-weight:800; font-size:17px; letter-spacing:.3px; }
.pxcoin{ display:flex; align-items:center; gap:6px; font-weight:800; background:var(--pcard); color:var(--pin); padding:5px 10px; border:3px solid var(--pf); } .pxcoin .sm{ width:18px; height:18px; }
.pxbody{ flex:1; overflow-y:auto; padding:12px; -webkit-overflow-scrolling:touch; }
.pxfoot{ flex:0 0 auto; padding:6px 12px; font-size:12px; color:var(--pmu); text-align:center; border-top:2px dashed var(--pf); }
.pxbn{ border:3px solid var(--pf); margin-bottom:12px; line-height:0; } .pxbn canvas{ width:100%; height:auto; aspect-ratio:64/20; }
.pxhubrow{ display:flex; gap:12px; align-items:flex-start; flex-wrap:wrap; justify-content:center; }
.pxfeat{ text-align:center; } .pxfeat small{ display:block; margin-top:6px; color:var(--pmu); font-size:11px; max-width:130px; }
.pxgrid6{ flex:1; min-width:220px; display:grid; grid-template-columns:1fr 1fr; gap:10px; }
.pxtile{ position:relative; border:3px solid var(--pf); background:var(--pcard); color:var(--pin); padding:10px 6px 8px; display:flex; flex-direction:column; align-items:center; gap:4px; font-family:inherit; box-shadow:0 4px 0 var(--pf); }
.pxtile:active{ transform:translateY(3px); box-shadow:0 1px 0 var(--pf); }
.pxtile .tile{ width:52px; height:52px; } .pxtile b{ font-size:15px; } .pxtile small{ font-size:11px; opacity:.75; text-align:center; }
.pxtile.soon{ opacity:.6; } .pxtile em{ position:absolute; top:4px; inset-inline-end:4px; font-size:9px; font-style:normal; background:var(--pac); color:#1a1428; padding:1px 5px; font-weight:800; }
.pxhint{ text-align:center; color:var(--pmu); font-size:12.5px; margin:12px 0 4px; }
.pxsum{ font-size:13px; margin-bottom:8px; color:var(--pmu); } .pxsum b{ color:var(--ptx); }
.pxq{ width:100%; box-sizing:border-box; padding:9px 10px; border:3px solid var(--pf); background:var(--pcard); color:var(--pin); font-family:inherit; font-size:14px; margin-bottom:8px; border-radius:0; }
.pxchips{ display:flex; gap:6px; overflow-x:auto; padding-bottom:6px; margin-bottom:4px; }
.pxchip{ flex:0 0 auto; padding:5px 10px; border:2px solid var(--pf); background:var(--pcard); color:var(--pin); font-size:12px; font-family:inherit; border-radius:0; }
.pxchip.on{ background:var(--pac); color:#1a1428; font-weight:800; }
.pxgrid{ display:grid; grid-template-columns:repeat(auto-fill,minmax(144px,1fr)); gap:12px 8px; justify-items:center; margin-top:8px; }
.pxcell{ cursor:pointer; } .pxcell:active{ transform:scale(.96); }
.pxpanel{ border:3px solid var(--pf); background:var(--pcard); color:var(--pin); padding:10px 12px; margin-bottom:12px; }
.pxrow{ display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px dashed var(--pf); font-size:14px; } .pxrow:last-child{ border:0; }
.pxbar{ display:flex; align-items:center; gap:8px; font-size:13px; margin:6px 0; } .pxbar span{ width:64px; } .pxbar div{ flex:1; height:12px; border:2px solid var(--pf); } .pxbar i{ display:block; height:100%; background:var(--pac); } .pxbar b{ width:44px; text-align:end; }
.pxdt{ position:absolute; left:0; top:0; right:0; bottom:0; background:rgba(0,0,0,.72); display:flex; padding:16px; z-index:3; overflow-y:auto; }
.pxdbox{ text-align:center; margin:auto; } .pxdbox .pxhint{ color:#d8d4ee; }
.pxbtns{ display:flex; gap:10px; justify-content:center; margin-top:8px; }
.pxbtn{ padding:9px 18px; border:3px solid var(--pf); background:var(--pac); color:#1a1428; font-weight:800; font-family:inherit; border-radius:0; box-shadow:0 3px 0 var(--pf); } .pxbtn.alt{ background:var(--pcard); color:var(--pin); } .pxbtn:active{ transform:translateY(2px); box-shadow:0 1px 0 var(--pf); }

/* --- خود کارت: قاب و تصویر روی بوم پیکسلی ۹۶×۱۳۶ کشیده می‌شود؛ فقط متن‌های بلند HTML هستند --- */
.pxc{ --u:calc(var(--w) / 96); --bt:#f6ecc9; --bt2:#d6c9a4; --ptxt:#2a1a0c; --mvc:#3b6fd8; --atc:#d6334a;
  position:relative; width:var(--w); height:calc(var(--w) * 136 / 96); perspective:1000px; display:inline-block; direction:ltr; text-align:left; font-family:"Nimbo",Tahoma,sans-serif; }
.pxc[data-sk=ink]{ --bt:#2b2013; --bt2:#4a3a22; --ptxt:#2b2013; --mvc:#5a4630; --atc:#b45309; }
.pxc[data-sk=term]{ --bt:#4ade80; --bt2:#2f9a58; --ptxt:#4ade80; --mvc:#15803d; --atc:#bbf7d0; }
.pxc[data-sk=dark]{ --bt:#e8eaed; --bt2:#9aa3b2; --ptxt:#e8eaed; }
.pxc[data-sk=glass]{ --bt:#eaf6ff; --bt2:#bcd6f0; --ptxt:#0f2a4a; }
.pxc .pin{ position:absolute; inset:0; transform-style:preserve-3d; transition:transform .5s steps(7); }
.pxc.flip .pin{ transform:rotateY(180deg); }
.pxc .pxf{ position:absolute; inset:0; backface-visibility:hidden; -webkit-backface-visibility:hidden; }
.pxc .pxf.bk{ transform:rotateY(180deg); }
.pxc canvas.cf{ position:absolute; left:0; top:0; width:100%; height:100%; image-rendering:pixelated; image-rendering:crisp-edges; }
.pxc .pov{ position:absolute; box-sizing:border-box; font-weight:700; }
.pxc .dsf{ left:calc(var(--u) * 13); top:calc(var(--u) * 102); width:calc(var(--u) * 70); height:calc(var(--u) * 10); font-size:calc(var(--u) * 4); line-height:1.16; overflow:hidden; color:var(--ptxt); text-align:center; display:flex; align-items:center; justify-content:center; }
.pxc .bnm{ left:calc(var(--u) * 8); top:calc(var(--u) * 27); width:calc(var(--u) * 80); text-align:center; font-size:calc(var(--u) * 6); letter-spacing:calc(var(--u) * .4); text-transform:uppercase; color:var(--bt); line-height:1.1; }
.pxc .bds{ left:calc(var(--u) * 11); top:calc(var(--u) * 37); width:calc(var(--u) * 74); height:calc(var(--u) * 24); font-size:calc(var(--u) * 4.4); line-height:1.22; color:var(--bt2); text-align:center; overflow:hidden; font-weight:600; }
.pxc .bbt{ left:calc(var(--u) * 10); top:calc(var(--u) * 105); width:calc(var(--u) * 76); height:calc(var(--u) * 22); display:flex; gap:calc(var(--u) * 3); align-items:center; overflow:hidden; }
.pxc .bpt{ flex:0 0 auto; display:flex; flex-direction:column; align-items:center; gap:calc(var(--u) * 1); }
.pxc .bhw{ flex:1; font-size:calc(var(--u) * 4); line-height:1.18; color:var(--bt); font-weight:600; overflow:hidden; max-height:100%; }
.pxc .bsp.lk{ left:calc(var(--u) * 10); top:calc(var(--u) * 92); width:calc(var(--u) * 76); text-align:center; font-size:calc(var(--u) * 5); color:var(--bt); }
.pxc .patg{ display:grid; gap:calc(var(--u) * .8); }
.pxc .pg{ display:block; aspect-ratio:1; background:rgba(128,128,128,.28); } .pxc .pg.me{ background:var(--bt); } .pxc .pg.mv{ background:var(--mvc); } .pxc .pg.at{ background:var(--atc); } .pxc .pg.both{ background:linear-gradient(135deg,var(--mvc) 50%,var(--atc) 50%); } .pxc .pg.tg{ outline:calc(var(--u) * .6) solid var(--bt); }
.pxc .lg{ display:flex; gap:calc(var(--u) * 2); font-size:calc(var(--u) * 3); color:var(--bt2); white-space:nowrap; } .pxc .lg span::before{ content:""; display:inline-block; width:calc(var(--u) * 2.2); height:calc(var(--u) * 2.2); margin-inline-end:calc(var(--u) * .8); } .pxc .lm::before{ background:var(--mvc); } .pxc .la::before{ background:var(--atc); }
.pxc .cnt{ position:absolute; inset-inline-end:-.3em; top:-.5em; background:#f5c542; color:#1a1428; font-weight:800; font-size:12px; padding:1px 6px; border:2px solid #1a1428; z-index:2; }
.pxinfo{ margin-top:10px; padding:10px 12px; background:var(--pcard); color:var(--pin); border:3px solid var(--pf); text-align:start; font-size:13px; line-height:1.7; max-width:288px; } .pxinfo p{ margin:4px 0; } .pxinfo .tip{ color:var(--pac); font-weight:700; }
@media (prefers-reduced-motion:reduce){ .pxc .pin{ transition:none; } .px-ov{ animation:none; } }

/* ===== صحنه‌های تصویری ===== */
.px-ov.sc{ background:#05080b; }
.stgwrap{ position:absolute; left:0; top:0; right:0; bottom:0; overflow:hidden; background:#05080b; direction:ltr; user-select:none; -webkit-user-select:none; -webkit-tap-highlight-color:transparent; }
.stgbg{ position:absolute; left:-24px; top:-24px; right:-24px; bottom:-24px; background-size:cover; background-position:center; filter:blur(14px) brightness(.55); }
.stg{ position:absolute; left:50%; top:50%; transform-origin:50% 50%; }
.stgimg{ position:absolute; left:0; top:0; width:100%; height:100%; display:block; pointer-events:none; }
.stg .hit{ position:absolute; cursor:pointer; border-radius:16px; } .stg .hit:active{ background:rgba(255,255,255,.16); }
.cfslot{ position:absolute; pointer-events:none; }
.cfhand{ position:absolute; width:112px; transform:rotate(var(--r,0deg)); transform-origin:50% 130%; filter:drop-shadow(0 4px 5px rgba(0,0,0,.7)); pointer-events:none; } .cfhand .pxc{ display:block; }
.cfmodal{ position:absolute; left:120px; top:640px; width:700px; padding:34px 30px; box-sizing:border-box; text-align:center; background:rgba(8,6,12,.95); border:5px solid #c9a34a; color:#f3d98a; z-index:20; cursor:pointer; font-family:"Nimbo",Tahoma,sans-serif; }
.cfmodal b{ display:block; font-size:54px; letter-spacing:3px; } .cfmodal p{ font-size:30px; line-height:1.6; color:#efe6cf; margin:16px 0; } .cfmodal span{ font-size:34px; color:#ffd24a; }
.assetmsg{ position:absolute; left:0; top:0; right:0; bottom:0; display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center; padding:20px; color:#f1e6c4; gap:8px; } .assetmsg p{ font-size:13px; color:#ff9a8a; word-break:break-all; }

/* ===== CROWNFALL: رابط کاربری کامل ===== */
.stg .pt{ position:absolute; display:flex; align-items:center; justify-content:center; color:#f6e7b4; font-weight:800; font-family:"Nimbo",Tahoma,sans-serif; white-space:nowrap; overflow:hidden; box-sizing:border-box; pointer-events:none; text-shadow:0 2px 0 #000; font-size:26px; }
.stg .pt.hnum{ font-size:28px; color:#f3e6bd; } .stg .pt.ftx{ font-size:24px; } .stg .pt.ftx.dk{ font-size:26px; color:#fff; }
.stg .pt.hprof{ display:block; position:absolute; text-align:left; padding:0; } .stg .pt.hprof .hn{ position:absolute; left:3px; top:1px; font-size:28px; color:#f4e8c1; } .stg .pt.hprof .hl{ position:absolute; left:3px; top:40px; font-size:24px; color:#e8c35a; }
.stg .pt .hbar{ position:absolute; left:82px; top:42px; width:196px; height:22px; background:#06090d; border:2px solid #6a5420; box-sizing:border-box; overflow:hidden; } .stg .pt .hbar i{ position:absolute; left:0; top:0; bottom:0; background:linear-gradient(#5fd0ff,#2a78d8); } .stg .pt .hbar span{ position:absolute; left:0; right:0; top:0; bottom:0; text-align:center; font-size:16px; line-height:18px; color:#fff; }
.stg .pt.hmis{ flex-direction:column; gap:4px; font-size:22px; justify-content:center; } .stg .pt .hbar.s{ position:static; width:136px; height:12px; }
.stg .pt.hbadge{ background:#0b0c0e !important; }
.stg .cfdot{ position:absolute; display:flex; align-items:center; justify-content:center; background:#d62828; color:#fff; border:3px solid #fff; border-radius:50%; font-weight:800; font-size:22px; box-sizing:border-box; pointer-events:none; }
.stg .pt.fbar{ padding:0; display:block; border:2px solid #000; } .stg .pt.fbar i{ display:block; height:100%; background:linear-gradient(#ff5b4a,#c01d1d); transition:width .35s; } .stg .pt.fbar.rt i{ margin-left:auto; }
.cfslot{ position:absolute; pointer-events:auto; display:flex; align-items:center; justify-content:center; box-sizing:border-box; cursor:pointer; -webkit-tap-highlight-color:transparent; }
.cfslot.ok{ background:rgba(255,214,74,.26); outline:4px solid #ffd24a; animation:cfpulse 1s ease-in-out infinite; } .cfslot.mv{ background:rgba(90,230,130,.28); outline:4px solid #5ae682; animation:cfpulse 1s ease-in-out infinite; } .cfslot.sel{ outline:5px solid #6ad0ff; background:rgba(106,208,255,.2); }
@keyframes cfpulse{ 50%{ opacity:.7; } }
.cfu{ position:relative; display:flex; align-items:center; justify-content:center; width:100%; height:100%; } .cfu .pxc{ display:block; box-shadow:0 3px 6px rgba(0,0,0,.7); } .cfu.e .pxc{ outline:3px solid #b3322f; } .cfu.p .pxc{ outline:3px solid #3a86d6; } .cfu.frz .pxc{ filter:saturate(.4) brightness(1.2) hue-rotate(160deg); }
.cfst{ position:absolute; left:0; right:0; bottom:-2px; display:flex; justify-content:center; gap:6px; pointer-events:none; } .cfst b{ font-size:20px; line-height:22px; padding:0 6px; background:rgba(0,0,0,.82); border:2px solid #000; color:#fff; } .cfst .hp{ color:#ff8a8a; } .cfst .at{ color:#ffd24a; }
.cfbd{ position:absolute; left:2px; top:2px; display:flex; flex-direction:column; gap:2px; pointer-events:none; } .cfbd i{ font-style:normal; font-size:14px; font-weight:800; padding:0 4px; color:#000; background:#ffd24a; } .cfbd i.b{ background:#7fd4ff; } .cfbd i.g{ background:#7be37b; }
.cfslot.land .cfu .pxc{ animation:cfdrop .5s ease-out; } @keyframes cfdrop{ from{ transform:translateY(160px) scale(.7); opacity:0; } to{ transform:none; opacity:1; } }
.cfslot.atkp .cfu{ animation:cfatkp .22s ease-out; } .cfslot.atke .cfu{ animation:cfatke .22s ease-out; } @keyframes cfatkp{ 50%{ transform:translateY(-34px); } } @keyframes cfatke{ 50%{ transform:translateY(34px); } }
.cfhand{ pointer-events:auto; cursor:pointer; transition:top .15s; } .cfhand.dim .pxc{ filter:brightness(.5) saturate(.6); } .cfhand.sel .pxc{ outline:4px solid #ffd24a; }
.cfcost{ position:absolute; left:-6px; top:-6px; width:34px; height:34px; border-radius:50%; background:#1f6fd1; border:3px solid #fff; color:#fff; font-size:22px; line-height:28px; text-align:center; box-sizing:border-box; }
.cfhint{ position:absolute; text-align:center; color:#ffe9a8; font-size:24px; font-weight:700; text-shadow:0 2px 0 #000; pointer-events:none; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; font-family:"Nimbo",Tahoma,sans-serif; }
.cffl{ position:absolute; font-size:44px; font-weight:900; transform:translate(-50%,0); text-shadow:0 3px 0 #000,0 0 8px #000; animation:cffl 1s ease-out forwards; pointer-events:none; z-index:15; font-family:"Nimbo",Tahoma,sans-serif; } .cffl.r{ color:#ff6a5a; } .cffl.g{ color:#78f08a; } .cffl.b{ color:#7fd4ff; }
@keyframes cffl{ from{ opacity:1; margin-top:0; } to{ opacity:0; margin-top:-90px; } }
.cfmask{ position:absolute; left:0; top:0; right:0; bottom:0; background:rgba(0,0,0,.66); z-index:40; display:flex; align-items:center; justify-content:center; padding:16px; }
.cfmodal2{ width:100%; max-width:340px; background:#0d0a14; border:3px solid #c9a34a; color:#f3d98a; padding:18px 16px; text-align:center; box-shadow:0 0 0 3px #000; font-family:"Nimbo",Tahoma,sans-serif; } .cfmodal2>b{ display:block; font-size:24px; letter-spacing:2px; } .cfmodal2 .mb{ color:#efe6cf; font-size:14px; line-height:1.6; margin:10px 0; } .cfmodal2 .mbtns{ display:flex; gap:8px; justify-content:center; flex-wrap:wrap; }
.cfmodal2 .rw{ display:flex; gap:10px; justify-content:center; margin:8px 0; } .cfmodal2 .rw b{ color:#ffd24a; font-size:18px; } .cfmodal2 .lvup{ color:#7be37b; font-weight:800; } .cfmodal2 .hintp{ color:#a79bcb; font-size:12px; }
.px-ov .pxh .pxcoin.m .ci,.px-ov .pxh .pxcoin.g .ci{ display:inline-block; width:14px; height:14px; border:2px solid #000; } .ci.g{ background:#f5c542; border-radius:50%; } .ci.m{ background:#4ac8ff; transform:rotate(45deg); width:12px !important; height:12px !important; }
.cfcc{ position:relative; display:flex; flex-direction:column; align-items:center; gap:6px; } .cfcc.lockd .pxc{ filter:grayscale(.85) brightness(.55); } .cftag{ font-size:11px; font-weight:800; padding:2px 8px; border:2px solid #000; } .cftag.ok{ background:#7be37b; color:#000; } .cftag.no{ background:#444; color:#ddd; }
.cfctl{ display:flex; align-items:center; gap:8px; } .cfctl button{ width:34px; height:30px; border:3px solid var(--pf); background:var(--pac); color:#1a1428; font-weight:800; font-size:18px; font-family:inherit; border-radius:0; } .cfctl button:disabled{ opacity:.35; } .cfctl span{ min-width:18px; text-align:center; font-weight:800; color:var(--ptx); }
.cfbuy{ display:flex; align-items:center; gap:6px; padding:5px 14px; border:3px solid var(--pf); background:var(--pac); color:#1a1428; font-weight:800; font-family:inherit; border-radius:0; } .cfbuy.no{ background:#777; color:#222; }
.rtag{ font-size:11px; font-weight:800; padding:1px 7px; border:2px solid #000; color:#000; background:#bbb; } .rtag.r-rare{ background:#6ab0ff; } .rtag.r-epic{ background:#c58cff; } .rtag.r-legendary{ background:#ffc94a; } .cfmeta{ line-height:1; }
.cfex,.cfset{ display:flex; align-items:center; justify-content:space-between; gap:10px; } .cfset small,.cfex small{ color:#777; }
.tg{ min-width:64px; padding:8px 12px; border:3px solid var(--pf); background:#999; color:#111; font-weight:800; font-family:inherit; border-radius:0; } .tg.on{ background:#5ae682; }
.cfm .mt{ display:flex; flex-direction:column; gap:2px; } .cfm .mt small{ color:#777; } .cfm .mrw{ color:#a06a00; font-size:12px; font-weight:700; } .cfm .mp{ display:flex; align-items:center; gap:10px; margin-top:6px; } .cfm .mp .pxbar{ flex:1; margin:0; } .cfm .mp .pxbar small{ white-space:nowrap; } .cfm.cl{ opacity:.55; } .mdone{ color:#2a8a3c; font-weight:800; } .mlock{ color:#888; font-size:12px; }
.cfdays{ display:grid; grid-template-columns:repeat(4,1fr); gap:8px; margin:10px 0; } .cfday{ border:3px solid var(--pf); background:var(--pcard); color:var(--pin); padding:8px 4px; text-align:center; font-size:12px; min-height:70px; display:flex; flex-direction:column; justify-content:center; gap:4px; } .cfday.done{ opacity:.5; } .cfday.now{ outline:4px solid var(--pac); } .cfday.today{ opacity:1; outline:4px solid #5ae682; } .cfclaim{ text-align:center; margin-top:14px; }
.cfprof .pname{ display:flex; align-items:center; gap:10px; } .cfprof input{ flex:1; padding:7px; border:3px solid var(--pf); background:#fff; color:#111; font-family:inherit; font-size:15px; border-radius:0; } .cfprof .plv{ font-size:20px; margin:8px 0 2px; } .pxbar.lgb div{ height:18px; }
.gt{ display:block; margin-bottom:4px; color:#a06a00; } .cfp .pxpanel p{ margin:0; font-size:13.5px; line-height:1.65; }
.pxbar.lgb b{ width:auto; white-space:nowrap; font-size:12px; }
.ci{ display:inline-block; width:14px; height:14px; border:2px solid #000; box-sizing:border-box; vertical-align:middle; }
.stg .pt.hlv{ justify-content:flex-start; font-size:26px; color:#e8c35a; } .stg .pt.hxp{ display:block; padding:0; } .stg .pt.hxp i{ display:block; height:100%; background:linear-gradient(#5fd0ff,#2a78d8); } .stg .pt.hnum{ justify-content:flex-start; font-size:32px; }
/* ===== تم: سه صفحهٔ تصویری با تم فعلی هماهنگ می‌شوند ===== */
.px-ov[data-sk=ink] .stgimg,.px-ov[data-sk=ink] .stg .pt{ filter:sepia(.85) saturate(.75) contrast(1.05) brightness(1.08); }
.px-ov[data-sk=ink] .stgbg{ filter:sepia(.85) saturate(.75) blur(14px) brightness(.7); }
.px-ov[data-sk=term] .stgimg,.px-ov[data-sk=term] .stg .pt{ filter:grayscale(1) sepia(1) hue-rotate(70deg) saturate(3.2) brightness(.95) contrast(1.1); }
.px-ov[data-sk=term] .stgbg{ filter:grayscale(1) sepia(1) hue-rotate(70deg) saturate(3) blur(14px) brightness(.45); }
.px-ov[data-sk=dark] .stgimg,.px-ov[data-sk=dark] .stg .pt{ filter:grayscale(.65) brightness(.82) contrast(1.15); }
.px-ov[data-sk=dark] .stgbg{ filter:grayscale(.65) blur(14px) brightness(.4); }
.px-ov[data-sk=glass] .stgimg,.px-ov[data-sk=glass] .stg .pt{ filter:hue-rotate(160deg) saturate(.85) brightness(1.1); }
.px-ov[data-sk=glass] .stgbg{ filter:hue-rotate(160deg) blur(14px) brightness(.6); }

/* ===== نوار دست (بزرگ‌تر از میدان، قابل اسکرول افقی) ===== */
.cfbar{ position:absolute; left:0; right:0; z-index:12; background:linear-gradient(rgba(0,0,0,0),rgba(0,0,0,.45)); direction:ltr; }
.cfscroll{ height:100%; display:flex; align-items:flex-end; gap:6px; padding:0 10px 6px; overflow-x:auto; overflow-y:hidden; -webkit-overflow-scrolling:touch; scrollbar-width:none; } .cfscroll::-webkit-scrollbar{ display:none; }
.cfhc{ position:relative; flex:0 0 auto; cursor:pointer; filter:drop-shadow(0 3px 4px rgba(0,0,0,.8)); transition:transform .15s; } .cfhc .pxc{ display:block; }
.cfhc.dim .pxc{ filter:brightness(.55) saturate(.6); } .cfhc.sel{ transform:translateY(-12px); } .cfhc.sel .pxc{ outline:3px solid #ffd24a; box-shadow:0 0 12px #ffd24a; }
.cfhc.nw{ animation:cfnew .4s ease-out; } @keyframes cfnew{ from{ transform:translateY(40px) scale(.6); opacity:0; } }
.cfhc .cfcost{ left:-4px; top:-4px; width:26px; height:26px; font-size:17px; line-height:20px; }
.cfempty{ color:#ffe9a8; font-size:13px; align-self:center; text-shadow:0 1px 0 #000; padding:0 12px; }
.cfdeck{ position:absolute; cursor:pointer; border-radius:12px; } .cfdeck.can{ box-shadow:0 0 0 4px #ffd24a inset; animation:cfpulse 1.2s ease-in-out infinite; }
.cfslot.bad{ background:rgba(214,40,40,.28); outline:4px solid #d62828; } .cfslot.fly .cfu .pxc{ visibility:hidden; }
.cffly{ position:absolute; z-index:30; pointer-events:none; transform-origin:0 0; transition:transform .38s ease-in; }
.cfhc .cfcost{ display:none; }
`;

const BUILTIN_MODS = [
  {
    id: 'calm', name: 'یک‌دست (داشبورد ساده)',
    desc: 'ابر و پرنده و آسمان کنار می‌روند و صفحهٔ اصلی یک داشبورد تمیز می‌شود: حلقهٔ پیشرفت امروز، آمار سریع، کارهای پیش رو و عادت‌ها با تیک مستقیم و دکمهٔ افزودن سریع.',
    tags: ['ساده', 'مینیمال', 'داشبورد', 'فهرست', 'calm'],
    css: `/* ===== یک‌دست: داشبورد بدون ابر و پرنده ===== */
.scene .clouds,.scene .cover,.scene .bird,.scene .pillmore,.scene .skyhint,.scene .stars,.scene .orb,.scene .hud,.scene .hb,.scene .sbar{ display:none !important; }
.scene{ background:linear-gradient(180deg, var(--bg2), var(--bg)) !important; }
.cm{ position:absolute; left:0; right:0; top:0; bottom:calc(var(--R) + var(--hub) + 18px); overflow-y:auto; padding:68px 14px 0; z-index:6; -webkit-overflow-scrolling:touch; }
body.wheel-closed .cm{ bottom:64px; }
.cm-head{ display:flex; align-items:center; justify-content:space-between; margin-bottom:14px; }
.cm-greet{ font-size:calc(24px * var(--fs, 1)); font-weight:700; color:var(--text); }
.cm-date{ font-size:calc(14px * var(--fs, 1)); color:var(--muted); margin-top:2px; }
.cm-ring{ position:relative; width:84px; height:84px; flex:0 0 auto; }
.cm-ring svg{ width:100%; height:100%; transform:rotate(-90deg); }
.cm-bg{ fill:none; stroke:var(--line); stroke-width:9; }
.cm-fg{ fill:none; stroke:var(--acc); stroke-width:9; stroke-linecap:round; transition:stroke-dashoffset .8s var(--ease); }
.cm-ring b{ position:absolute; left:0; right:0; top:50%; transform:translateY(-50%); text-align:center; font-size:calc(17px * var(--fs, 1)); color:var(--text); }
.cm-stats{ display:grid; grid-template-columns:repeat(4,1fr); gap:8px; margin-bottom:6px; }
.cm-stats div{ background:var(--card); border:1px solid var(--line); border-radius:14px; padding:10px 4px; text-align:center; }
.cm-stats b{ display:block; font-size:calc(19px * var(--fs, 1)); color:var(--text); } .cm-stats b.bad{ color:var(--bad); }
.cm-stats span{ font-size:calc(11px * var(--fs, 1)); color:var(--muted); }
.cm-sec{ font-size:calc(13px * var(--fs, 1)); font-weight:700; color:var(--muted); margin:16px 4px 8px; }
.cm-habs{ display:flex; flex-wrap:wrap; gap:8px; }
.cm-hab{ padding:9px 14px; border-radius:20px; border:1px solid var(--line); background:var(--card); color:var(--text); font-size:calc(14px * var(--fs, 1)); }
.cm-hab.on{ background:var(--acc); border-color:var(--acc); color:#04202e; font-weight:700; }
.cm-hab:active{ transform:scale(.94); }
.cm-add{ position:absolute; right:16px; bottom:calc(var(--R) + var(--hub) + var(--hs) / 2 + 20px); width:54px; height:54px; border-radius:50%; border:0; z-index:8;
  background:linear-gradient(135deg, var(--acc), var(--acc2)); color:#fff; font-size:32px; line-height:1; box-shadow:0 6px 16px rgba(0,0,0,.3); transition:bottom .65s var(--ease); }
body.wheel-closed .cm-add{ bottom:76px; }
.cm-add:active{ transform:scale(.9); }
`,
    js: 'return (' + CALM_JS.toString() + ')(nimbo);'
  },
  {
    id: 'game', name: 'مسابقه‌ای (سطح، مأموریت و نشان)',
    desc: 'کارها، عادت‌ها و جلسه‌های تمرکز امتیاز می‌گیرند و سطح و رتبه‌ات بالا می‌رود. هر روز سه مأموریت داری، ۱۴ نشان باز می‌شود و با هر ارتقا جشن می‌گیریم. روی نشان سطح بالای صفحه بزن تا پروفایل را ببینی.',
    tags: ['بازی', 'امتیاز', 'سطح', 'مأموریت', 'نشان', 'انگیزه', 'xp'],
    css: `/* ===== مسابقه‌ای ===== */
.gm-chip{ position:relative; width:40px; height:40px; border-radius:50%; border:0; padding:0; background:var(--card); color:var(--text); display:flex; align-items:center; justify-content:center; flex:0 0 auto; }
.gm-chip svg{ position:absolute; left:0; top:0; width:100%; height:100%; transform:rotate(-90deg); }
.gm-chip b{ position:relative; font-size:15px; font-weight:800; }
.gm-chip:active{ transform:scale(.88); }
.gm-bg{ fill:none; stroke:rgba(128,128,128,.28); } .gm-fg{ fill:none; stroke:var(--acc); stroke-linecap:round; }
.xpbar{ position:absolute; left:0; right:0; bottom:-1px; height:3px; background:rgba(128,128,128,.25); }
.xpbar i{ display:block; height:100%; width:0; background:linear-gradient(90deg,var(--acc),var(--acc2)); transition:width .6s; }
.gm-ov{ position:fixed; left:0; top:0; right:0; bottom:0; z-index:150; background:rgba(4,8,20,.62); display:flex; align-items:center; justify-content:center; padding:16px; animation:gmIn .25s ease-out; }
@keyframes gmIn{ from{ opacity:0; } to{ opacity:1; } }
.gm-card{ width:100%; max-width:390px; max-height:92vh; overflow-y:auto; background:var(--card); color:var(--text); border:1px solid var(--line); border-radius:24px; padding:20px 18px 16px; text-align:center; box-shadow:0 20px 50px rgba(0,0,0,.45); animation:gmPop .45s var(--spring); }
@keyframes gmPop{ from{ transform:scale(.85) translateY(20px); opacity:0; } to{ transform:none; opacity:1; } }
.gm-top{ position:relative; width:112px; height:112px; margin:0 auto 6px; }
.gm-r{ width:100%; height:100%; transform:rotate(-90deg); }
.gm-r .gm-fg{ filter:drop-shadow(0 0 6px var(--acc)); }
.gm-lv{ position:absolute; left:0; right:0; top:50%; transform:translateY(-50%); line-height:1; }
.gm-lv small{ display:block; font-size:12px; color:var(--muted); margin-bottom:2px; } .gm-lv b{ font-size:38px; font-weight:800; }
.gm-rank{ font-size:20px; font-weight:800; margin-top:4px; background:linear-gradient(90deg,var(--acc),var(--acc2)); -webkit-background-clip:text; background-clip:text; color:transparent; }
.gm-xp{ font-size:13px; color:var(--muted); margin:2px 0 8px; }
.gm-pb{ height:10px; border-radius:6px; background:rgba(128,128,128,.22); overflow:hidden; } .gm-pb.sm{ height:6px; margin-top:5px; }
.gm-pb i{ display:block; height:100%; border-radius:6px; background:linear-gradient(90deg,var(--acc),var(--acc2)); transition:width .7s var(--ease); }
.gm-row{ display:grid; grid-template-columns:repeat(3,1fr); gap:8px; margin:14px 0 4px; }
.gm-row div{ background:rgba(128,128,128,.14); border-radius:14px; padding:9px 4px; } .gm-row b{ display:block; font-size:17px; } .gm-row span{ font-size:11px; color:var(--muted); }
.gm-h{ text-align:start; font-size:13px; font-weight:700; color:var(--muted); margin:16px 2px 8px; }
.gm-q{ display:flex; align-items:center; gap:10px; padding:10px 12px; margin-bottom:6px; border-radius:14px; background:rgba(128,128,128,.12); text-align:start; }
.gm-q.ok{ background:rgba(34,197,94,.16); }
.gm-qi{ font-size:22px; } .gm-qt{ flex:1; min-width:0; } .gm-qt b{ font-size:14px; font-weight:600; }
.gm-q em{ font-style:normal; font-weight:800; font-size:14px; color:var(--acc); }
.gm-ach{ display:grid; grid-template-columns:repeat(4,1fr); gap:8px; }
.gm-a{ border-radius:14px; padding:8px 2px; background:rgba(128,128,128,.12); filter:grayscale(1); opacity:.45; }
.gm-a.on{ filter:none; opacity:1; background:linear-gradient(160deg, rgba(245,158,11,.22), rgba(245,158,11,.06)); box-shadow:inset 0 0 0 1px rgba(245,158,11,.5); }
.gm-a span{ display:block; font-size:24px; } .gm-a small{ display:block; font-size:10px; line-height:1.3; margin-top:2px; }
.gm-x{ margin-top:16px; width:100%; padding:13px; border-radius:14px; border:1px solid var(--line); background:transparent; color:var(--text); font-size:15px; }
.gm-ov.up{ background:rgba(4,8,20,.72); }
.gm-card.up{ padding:34px 18px; background:linear-gradient(160deg, var(--card), rgba(245,158,11,.14)); }
.gm-big{ font-size:92px; font-weight:800; line-height:1; background:linear-gradient(135deg,#fbbf24,#f97316); -webkit-background-clip:text; background-clip:text; color:transparent; animation:gmBeat 1s ease-in-out infinite alternate; }
@keyframes gmBeat{ from{ transform:scale(.94); } to{ transform:scale(1.06); } }
.gm-t{ font-size:24px; font-weight:800; margin-top:6px; } .gm-s{ font-size:16px; color:var(--muted); margin-top:4px; }
.gm-cf{ position:absolute; left:0; top:0; right:0; bottom:0; overflow:hidden; pointer-events:none; }
.gm-cf i{ position:absolute; top:-16px; width:9px; height:15px; border-radius:2px; opacity:0; animation:gmFall 2.2s ease-in forwards; }
@keyframes gmFall{ 0%{ opacity:1; transform:translate(0,0) rotate(0); } 100%{ opacity:0; transform:translate(var(--dx),105vh) rotate(var(--r)); } }
`,
    js: 'return (' + GAME_JS.toString() + ')(nimbo);'
  },
  {
    id: 'cvd-rg', grp: 'cvd', name: 'رنگ‌کور · قرمز-سبز (پروتان و دوترآن)',
    desc: 'برای رایج‌ترین نوع کوررنگی (قرمز و سبز یکی دیده می‌شوند). همهٔ رنگ‌های معنادار به پالت علمی Okabe-Ito با آبی و نارنجی تبدیل می‌شوند، و علاوه بر رنگ، شکل هم دارند: اولویت کم ▽ ، متوسط ◆ ، بالا ▲ با ضخامت متفاوت نوار کنار هر مورد، عقب‌افتاده با راه‌راه و ⚠ ، و انجام‌شده خط‌خورده با ✔.',
    tags: ['دسترسی', 'رنگ‌کور', 'کوررنگی', 'پروتان', 'دوترآن', 'قرمز', 'سبز', 'colorblind'],
    css: CVD_SHARED + `
:root, body, body.light{ --ok:#0072b2 !important; --bad:#d55e00 !important; --acc:#0072b2 !important; --acc2:#56b4e9 !important; }
body:not(.light){ --acc:#56b4e9 !important; --acc2:#0072b2 !important; }
.item.p0{ --pc:#56b4e9 !important; } .item.p1{ --pc:#e69f00 !important; } .item.p2{ --pc:#d55e00 !important; }
.btn.danger{ background:#d55e00 !important; }
`
  },
  {
    id: 'cvd-by', grp: 'cvd', name: 'رنگ‌کور · آبی-زرد (تریتان)',
    desc: 'برای نوع نادرتر کوررنگی که آبی و سبز، یا زرد و بنفش را اشتباه می‌گیرد. پالت بر محور قرمز-فیروزه‌ای ساخته شده و مثل مود دیگر، شکل‌ها (▽ ◆ ▲)، راه‌راه و علامت‌ها هم کنار رنگ هستند.',
    tags: ['دسترسی', 'رنگ‌کور', 'کوررنگی', 'تریتان', 'آبی', 'زرد', 'colorblind'],
    css: CVD_SHARED + `
:root, body, body.light{ --ok:#00838f !important; --bad:#e53935 !important; --acc:#00838f !important; --acc2:#e53935 !important; }
body:not(.light){ --acc:#26c6da !important; --acc2:#00838f !important; }
.item.p0{ --pc:#26c6da !important; } .item.p1{ --pc:#78909c !important; } .item.p2{ --pc:#e53935 !important; }
.btn.danger{ background:#e53935 !important; }
`
  },
  {
    id: 'terminal', grp: 'theme', name: 'ترمینال (سبز روی سیاه)',
    desc: 'ظاهر هکری با فونت تک‌فاصله، سبز فسفری و خطوط ریز صفحه‌نمایش قدیمی.',
    tags: ['تم','ترمینال','برنامه‌نویس','سبز','terminal'],
    css: `/* ===== ترمینال: سبز روی سیاه ===== */
:root, body, body.light{ --bg:#020a04; --bg2:#031208; --card:#05160b; --text:#4ade80; --muted:#2f9a58; --line:#0f4a28; --wheel:#021008; --ok:#4ade80; --bad:#f87171; --acc:#22c55e !important; --acc2:#16a34a !important; color-scheme: dark; }
body, body.light{ background:#020a04 !important; color:#4ade80; font-family: "Courier New", ui-monospace, Menlo, monospace !important; }
.top, body.light .top{ background:#031208 !important; border-bottom:1px solid #0f4a28 !important; color:#4ade80; }
.card,.item,.stat,.sg-c,.tabs,.seg,.reader,.warn,.mrow,.sub-row,.lockc,.slotb,.ned-title,.ned-text,.inp,.tbtn,.chip,.btn.ghost,.it{
  background:#05160b !important; border:1px solid #0f4a28 !important; border-radius:3px !important; color:#4ade80 !important; box-shadow:none !important; }
.item{ border-inline-start:4px solid var(--pc, #0f4a28) !important; }
.sheet, body.light .sheet{ background:#031208 !important; border:1px solid #1d7a42 !important; border-bottom:0 !important; border-radius:8px 8px 0 0 !important; color:#4ade80; box-shadow:none !important; }
.wheel, body.light .wheel{ background:#021008 !important; border:1px solid #0f4a28 !important; box-shadow:none !important; }
.ov{ background:rgba(0,12,4,.74) !important; }
.btn:not(.ghost):not(.danger),.chip.on,.tab.on,.seg button.on,.it.act{ background:#22c55e !important; color:#001a08 !important; border:1px solid #4ade80 !important; border-radius:3px !important; box-shadow:none !important; font-weight:700; }
.tab,.seg button{ background:transparent !important; border:0 !important; box-shadow:none !important; color:#4ade80 !important; }
.tab.on,.seg button.on{ background:#22c55e !important; color:#001a08 !important; }
.ttl,.sh-t,.top h1{ text-shadow:0 0 6px rgba(74,222,128,.45); }
.inp::placeholder,.ned-title::placeholder,.ned-text::placeholder{ color:#2f9a58; }
.toast{ background:#05160b !important; color:#4ade80 !important; border:1px solid #1d7a42; border-radius:3px !important; }
.bar{ background:#0a2615 !important; }
.switch{ background:#0f3a20 !important; } .switch.on{ background:#22c55e !important; }
.sumb{ background:rgba(0,0,0,.45); border-color:#1d7a42; color:#4ade80; }
`
  },
  {
    id: 'paper', grp: 'theme', name: 'کاغذ و جوهر',
    desc: 'رنگ‌های گرم کاغذ، لبه‌های نرم و ویرایشگر یادداشت خط‌دار مثل دفترچهٔ واقعی.',
    tags: ['تم','کاغذ','دفترچه','گرم','paper'],
    css: `/* ===== کاغذ و جوهر: رنگ‌های گرم و صفحهٔ خط‌دار ===== */
:root, body, body.light{ --bg:#e8d9ae; --bg2:#dfcd9d; --card:#efe1b8; --text:#33281a; --muted:#8a7752; --line:#c9b57f; --wheel:#dccb9a; --acc:#b45309 !important; --acc2:#92400e !important; --ok:#4d7c0f; --bad:#b91c1c; color-scheme: light; }
body, body.light{ background:#e8d9ae !important; color:#33281a; font-family: Vazirmatn, Georgia, "Times New Roman", serif !important; }
.top, body.light .top{ background:#dfcd9d !important; border-bottom:1px solid #c9b57f !important; color:#33281a; }
.card,.item,.stat,.sg-c,.tabs,.seg,.reader,.warn,.mrow,.sub-row,.lockc,.slotb,.inp,.tbtn,.chip,.btn.ghost,.it{
  background:#efe1b8 !important; border:1px solid #c9b57f !important; color:#33281a !important; box-shadow:1px 2px 0 rgba(120,90,40,.14) !important; }
.item{ border-inline-start:4px solid var(--pc, #c9b57f) !important; }
.ned-title,.ned-text{ background-color:#f3e7c3 !important; color:#33281a !important; border:1px solid #c9b57f !important; }
.ned-text{ background-image:repeating-linear-gradient(to bottom, transparent 0, transparent 27px, rgba(180,83,9,.18) 27px, rgba(180,83,9,.18) 28px) !important; background-attachment:local !important; line-height:28px !important; }
.sheet, body.light .sheet{ background:#e9dba9 !important; color:#33281a; border-top:2px solid #c9b57f !important; box-shadow:0 -6px 20px rgba(80,60,20,.22) !important; }
.wheel, body.light .wheel{ background:#dccb9a !important; border:1px solid #c9b57f !important; box-shadow:none !important; }
.ov{ background:rgba(50,34,8,.42) !important; }
.btn:not(.ghost):not(.danger),.chip.on,.tab.on,.seg button.on,.it.act{ background:linear-gradient(135deg,#c2670f,#92400e) !important; color:#fff8e6 !important; border:1px solid #92400e !important; box-shadow:1px 2px 0 rgba(80,40,10,.3) !important; }
.tab,.seg button{ background:transparent !important; border:0 !important; box-shadow:none !important; color:#5c4a2a !important; }
.tab.on,.seg button.on{ color:#fff8e6 !important; }
.inp::placeholder,.ned-title::placeholder,.ned-text::placeholder{ color:#8f7c4f; }
.toast{ background:#33281a !important; color:#efe1b8 !important; }
.bar{ background:#d6c490 !important; }
.switch{ background:#c9b57f !important; } .switch.on{ background:#4d7c0f !important; }
.sumb{ background:rgba(90,66,24,.28); border-color:rgba(60,40,10,.4); color:#33281a; text-shadow:none; }
.hb{ background:rgba(90,66,24,.2) !important; border-color:rgba(60,40,10,.3) !important; }
.rh span,.rm{ color:#33281a; text-shadow:none; }
.rh .rb{ stroke:rgba(51,40,26,.28); } .rh .rp{ stroke:#33281a; }
.pillmore{ background:rgba(90,66,24,.3); color:#33281a; border-color:rgba(60,40,10,.4); }
.scene{ --st:#f2e8cb !important; --sb:#e4d4a9 !important; }
.hud{ color:#33281a !important; text-shadow:none !important; }
`
  },
  {
    id: 'rain', grp: 'weather', name: 'باران',
    desc: 'باران آرام روی آسمان صفحهٔ اصلی؛ سبک و با سقف ۳۰ فریم در ثانیه.',
    tags: ['باران','آسمان','جلوه','rain'],
    css: `.fall{ position:absolute; left:0; top:0; width:100%; height:100%; pointer-events:none; z-index:4; }`,
    js: 'return (' + FALL_JS.toString() + ')(nimbo, "rain");'
  },
  {
    id: 'snow', grp: 'weather', name: 'برف',
    desc: 'برف نرم روی آسمان صفحهٔ اصلی؛ سبک و با سقف ۳۰ فریم در ثانیه.',
    tags: ['برف','آسمان','جلوه','snow','زمستان'],
    css: `.fall{ position:absolute; left:0; top:0; width:100%; height:100%; pointer-events:none; z-index:4; }`,
    js: 'return (' + FALL_JS.toString() + ')(nimbo, "snow");'
  },
  {
    id: 'tint', name: 'غروب و طلوع (فیلتر ساعت)',
    desc: 'طبق ساعت، یک لایهٔ رنگی بسیار ملایم روی برنامه می‌افتد: گرم‌تر در عصر و غروب و فیلتر کم‌نور-آبی در شب.',
    tags: ['فیلتر','شب','غروب','چشم','tint'],
    css: `#tintov{ position:fixed; left:0; top:0; right:0; bottom:0; pointer-events:none; z-index:400; transition:background 2s; }`,
    js: 'return (' + TINT_JS.toString() + ')(nimbo);'
  },
  {
    id: 'amoled', grp: 'theme', name: 'شب‌بیداری (سیاه مطلق)',
    desc: 'پس‌زمینهٔ کاملاً سیاه و کارت‌های تیره؛ روی صفحه‌های AMOLED باتری کمتری مصرف می‌کند و چشم را کمتر اذیت می‌کند. آسمان صفحهٔ اصلی همان می‌ماند.',
    tags: ['تم', 'تیره', 'سیاه', 'amoled', 'باتری', 'شب'],
    css: `/* ===== شب‌بیداری: سیاه مطلق، مناسب صفحه‌های AMOLED و صرفه‌جویی باتری ===== */
:root, body, body.light{
  --bg:#000; --bg2:#000; --card:#0b0b0d; --text:#e8eaed; --muted:#8b93a1; --line:#1d1f24; --wheel:#07070a;
  color-scheme: dark;
}
body, body.light{ background:#000 !important; color:#e8eaed; }
.top, body.light .top{ background:#000 !important; border-bottom:1px solid #15171b !important; color:#e8eaed; }
.card,.item,.stat,.sg-c,.tabs,.seg,.reader,.warn,.mrow,.sub-row,.lockc,.slotb,.ned-title,.ned-text,.inp,.tbtn,.chip,.btn.ghost,.it{
  background:#0b0b0d !important; border-color:#1d1f24 !important; color:#e8eaed;
}
.sheet, body.light .sheet{ background:#08080a !important; border-color:#1d1f24 !important; color:#e8eaed; box-shadow:none !important; }
.ov{ background:rgba(0,0,0,.7) !important; }
.wheel, body.light .wheel{ background:#050507 !important; border-color:#15171b !important; box-shadow:none !important; }
.it.act{ background:linear-gradient(135deg,var(--acc),var(--acc2)) !important; color:#fff; border-color:transparent !important; }
.toast{ background:#15171b !important; color:#fff !important; }
.bar{ background:#17191e !important; }
.switch{ background:#23262d !important; }
.switch.on{ background:var(--ok) !important; }
.inp::placeholder,.ned-title::placeholder,.ned-text::placeholder{ color:#5b6270; }
.chip.on,.tab.on,.seg button.on{ background:linear-gradient(135deg,var(--acc),var(--acc2)) !important; border-color:transparent !important; color:#fff !important; }
.sumb{ background:rgba(0,0,0,.35); }
.hb{ background:rgba(0,0,0,.45) !important; }
`
  },
  {
    id: 'crystal', grp: 'theme', name: 'شیشه‌ای روان (بدون لگ)',
    desc: 'شیشهٔ شفاف با لبهٔ براق و بازتاب نور، بدون هیچ بلور و فیلتر سنگین؛ به همین دلیل کاملاً روان است و روی گوشی‌های ضعیف هم لگ نمی‌کند.',
    tags: ['تم', 'شیشه', 'اپل', 'روان', 'glass'],
    css: `/* ===== شیشهٔ روان: بدون بلور و بدون فیلتر، پس هیچ لگی ندارد ===== */
:root{
  --c-tint: rgba(14,22,46,.34);
  --c-sheen: linear-gradient(180deg, rgba(255,255,255,.20) 0, rgba(255,255,255,.06) 38%, rgba(255,255,255,0) 60%);
  --c-fill: linear-gradient(135deg, rgba(255,255,255,.13), rgba(255,255,255,.03));
  --c-line: rgba(255,255,255,.20);
  --c-rim: inset 0 1px 0 rgba(255,255,255,.42), inset 0 -1px 0 rgba(255,255,255,.07), inset 1px 0 0 rgba(255,255,255,.10);
  --c-sh: 0 4px 12px rgba(0,0,0,.20);
  --c-text: #f8fafc;
}
body.light{
  --c-tint: rgba(255,255,255,.38);
  --c-sheen: linear-gradient(180deg, rgba(255,255,255,.75) 0, rgba(255,255,255,.25) 40%, rgba(255,255,255,0) 62%);
  --c-fill: linear-gradient(135deg, rgba(255,255,255,.45), rgba(255,255,255,.12));
  --c-line: rgba(255,255,255,.95);
  --c-rim: inset 0 1px 0 #fff, inset 0 -1px 0 rgba(120,140,180,.18);
  --c-sh: 0 4px 12px rgba(70,90,140,.16);
  --c-text: #0f172a;
}
body{ background: transparent !important; }
#lgbg{ position: fixed; left: -10%; top: -10%; width: 120%; height: 120%; z-index: -1; pointer-events: none; will-change: transform;
  background:
    radial-gradient(34% 28% at 16% 14%, rgba(56,189,248,.72), transparent 70%),
    radial-gradient(38% 30% at 88% 20%, rgba(168,85,247,.66), transparent 70%),
    radial-gradient(40% 34% at 76% 82%, rgba(244,63,94,.52), transparent 70%),
    radial-gradient(32% 28% at 8% 78%, rgba(34,197,94,.48), transparent 70%),
    radial-gradient(26% 22% at 50% 46%, rgba(250,204,21,.26), transparent 70%),
    linear-gradient(160deg, #0b1230, #101a3d 55%, #0a1026); }
body.light #lgbg{ background:
    radial-gradient(34% 28% at 16% 14%, rgba(56,189,248,.70), transparent 70%),
    radial-gradient(38% 30% at 88% 20%, rgba(192,132,252,.62), transparent 70%),
    radial-gradient(40% 34% at 76% 82%, rgba(251,113,160,.56), transparent 70%),
    radial-gradient(32% 28% at 8% 78%, rgba(74,222,128,.52), transparent 70%),
    radial-gradient(26% 22% at 50% 46%, rgba(253,224,71,.42), transparent 70%),
    linear-gradient(160deg, #eaf3ff, #f4ecff 55%, #eafaf1); }

/* همهٔ سطح‌های شیشه‌ای: فقط گرادیان و سایهٔ کوچک */
.card,.item,.stat,.sg-c,.tabs,.seg,.reader,.warn,.mrow,.sub-row,.lockc,.slotb,.ned-title,.ned-text,.inp,.tbtn,.chip,.btn.ghost,.opts .btn,.it{
  background: var(--c-sheen), var(--c-fill), var(--c-tint) !important;
  border: 1px solid var(--c-line) !important;
  box-shadow: var(--c-rim), var(--c-sh) !important;
  color: var(--c-text);
}
.item{ border-inline-start: 4px solid var(--pc, var(--c-line)) !important; }
.item.late{ border-color: var(--bad) !important; }
.chip,.tbtn,.slotb,.it,.inp,.sub-row{ box-shadow: var(--c-rim), 0 2px 6px rgba(0,0,0,.14) !important; }
.inp::placeholder,.ned-title::placeholder,.ned-text::placeholder{ color: rgba(148,163,184,.95); }
.inp:focus,.ned-title:focus,.ned-text:focus{ border-color: rgba(255,255,255,.6) !important; box-shadow: var(--c-rim), 0 0 0 3px rgba(125,211,252,.28) !important; }
.card.tap:active,.item:active{ transform: scale(.975); }

/* نوار بالا، شیت، چرخ: کمی پررنگ‌تر تا نوشته‌ها خوانا بمانند (بدون بلور) */
.top{
  background: var(--c-sheen), linear-gradient(135deg, rgba(255,255,255,.12), rgba(255,255,255,.03)), rgba(12,18,40,.62) !important;
  border-bottom: 1px solid var(--c-line) !important; box-shadow: inset 0 -1px 0 rgba(255,255,255,.10), 0 2px 8px rgba(0,0,0,.18) !important;
  color: var(--c-text);
}
body.light .top{ background: var(--c-sheen), rgba(255,255,255,.62) !important; }
.sheet{
  background: var(--c-sheen), linear-gradient(160deg, rgba(255,255,255,.14), rgba(255,255,255,.03)), rgba(14,22,48,.86) !important;
  border: 1px solid var(--c-line); border-bottom: 0;
  box-shadow: inset 0 1px 0 rgba(255,255,255,.45), 0 -6px 20px rgba(0,0,0,.30) !important;
  color: var(--c-text);
}
body.light .sheet{ background: var(--c-sheen), rgba(250,252,255,.9) !important; }
.sheet .grab{ background: rgba(255,255,255,.45) !important; }
.wheel{
  background: var(--c-sheen), linear-gradient(160deg, rgba(255,255,255,.12), rgba(255,255,255,.02)), rgba(14,22,48,.66) !important;
  border: 1px solid var(--c-line) !important; box-shadow: inset 0 2px 0 rgba(255,255,255,.35), 0 -4px 16px rgba(0,0,0,.25) !important;
}
body.light .wheel{ background: var(--c-sheen), rgba(255,255,255,.7) !important; }
.it.act{ background-image: linear-gradient(180deg, rgba(255,255,255,.5), rgba(255,255,255,0) 60%), linear-gradient(135deg, var(--acc), var(--acc2)) !important; background-color: transparent !important; border-color: rgba(255,255,255,.75) !important; color:#fff; }
.hub{
  background-image: linear-gradient(180deg, rgba(255,255,255,.5), rgba(255,255,255,0) 55%), linear-gradient(135deg, var(--acc), var(--acc2)) !important;
  border: 1px solid rgba(255,255,255,.65) !important; box-shadow: inset 0 1px 0 rgba(255,255,255,.8), 0 4px 12px rgba(0,0,0,.3) !important;
}

/* دکمه‌های رنگی */
.btn:not(.ghost):not(.danger),.chip.on,.tab.on,.seg button.on,.slotb.on{
  background-image: linear-gradient(180deg, rgba(255,255,255,.45), rgba(255,255,255,0) 55%), linear-gradient(135deg, var(--acc), var(--acc2)) !important;
  background-color: transparent !important;
  border: 1px solid rgba(255,255,255,.45) !important;
  box-shadow: inset 0 1px 0 rgba(255,255,255,.7), 0 3px 10px rgba(0,0,0,.24) !important;
  color: #fff !important; text-shadow: 0 1px 2px rgba(0,0,0,.25);
}
.btn.danger{ background-image: linear-gradient(180deg, rgba(255,255,255,.4), rgba(255,255,255,0) 55%), linear-gradient(135deg, #ef4444, #be123c) !important; border: 1px solid rgba(255,255,255,.4) !important; box-shadow: inset 0 1px 0 rgba(255,255,255,.6), 0 3px 10px rgba(0,0,0,.22) !important; }
.tab,.seg button{ background: transparent !important; border: 0 !important; box-shadow: none !important; color: var(--c-text); }
.tabs,.seg{ padding: 3px; }
.bar{ background: rgba(255,255,255,.16) !important; }
.tring .bgc{ stroke: rgba(255,255,255,.18) !important; }
.switch{ background: rgba(255,255,255,.24) !important; border: 1px solid var(--c-line); }
.switch.on{ background: rgba(34,197,94,.78) !important; }

/* چیزهای سنگین برنامه خاموش می‌شوند */
.ov{ background: rgba(4,8,20,.42) !important; -webkit-backdrop-filter: none !important; backdrop-filter: none !important; }
.hb,.pillmore,.toast{ -webkit-backdrop-filter: none !important; backdrop-filter: none !important; }
.hb{ background: var(--c-sheen), rgba(255,255,255,.18) !important; }
.pillmore{ background: var(--c-sheen), rgba(14,22,48,.5) !important; color:#fff; }
.toast{ background: var(--c-sheen), rgba(14,22,48,.86) !important; color:#fff !important; border: 1px solid var(--c-line); }
.bird{ filter: none !important; }
`,
    js: 'return (' + CRYSTAL_JS.toString() + ')(nimbo);'
  },
  {
    id: 'liquid', grp: 'theme', name: 'شیشهٔ مایع (سنگین‌تر)',
    desc: 'نسخهٔ سنگین‌تر با بلور و شکست نور؛ فقط برای گوشی‌های قوی. شیشهٔ نرم: نور ملایم، لبهٔ براق، درخشش با لمس، شکست نور در نوار بالا و پنجره‌ها، و پس‌زمینهٔ رنگی که با کج‌کردن گوشی کمی تکان می‌خورد.',
    tags: ['تم', 'شیشه', 'اپل', 'liquid', 'glass'],
    css: GLASS_CSS + `/* ===== شیشهٔ مایع: شکست نور در لبه‌ها، درخشش زنده، پس‌زمینهٔ متحرک ===== */
:root{
  --g-fill: linear-gradient(135deg, rgba(255,255,255,.13), rgba(255,255,255,.03));
  --g-fill2: linear-gradient(135deg, rgba(255,255,255,.22), rgba(255,255,255,.07));
  --g-line: rgba(255,255,255,.22);
  --g-blur: blur(14px) saturate(160%);
  --g-rim: inset 1px 1px 1px -.5px rgba(255,255,255,.5), inset -1px -1px 1px -.5px rgba(255,255,255,.22), inset 0 0 16px rgba(255,255,255,.05);
}
body.light{
  --g-fill: linear-gradient(135deg, rgba(255,255,255,.55), rgba(255,255,255,.22));
  --g-fill2: linear-gradient(135deg, rgba(255,255,255,.8), rgba(255,255,255,.4));
  --g-line: rgba(255,255,255,.95);
  --g-blur: blur(14px) saturate(150%);
}
body::before{
  translate: var(--tx, 0px) var(--ty, 0px);
  transition: translate .35s linear;
  background:
    radial-gradient(30% 26% at 18% 16%, rgba(56,189,248,.70), transparent 70%),
    radial-gradient(34% 28% at 86% 22%, rgba(168,85,247,.75), transparent 70%),
    radial-gradient(36% 32% at 74% 80%, rgba(244,63,94,.62), transparent 70%),
    radial-gradient(30% 26% at 10% 76%, rgba(34,197,94,.58), transparent 70%),
    radial-gradient(24% 20% at 50% 48%, rgba(250,204,21,.38), transparent 70%) !important;
}
body.light::before{
  background:
    radial-gradient(30% 26% at 18% 16%, rgba(56,189,248,.75), transparent 70%),
    radial-gradient(34% 28% at 86% 22%, rgba(192,132,252,.70), transparent 70%),
    radial-gradient(36% 32% at 74% 80%, rgba(251,113,160,.62), transparent 70%),
    radial-gradient(30% 26% at 10% 76%, rgba(74,222,128,.58), transparent 70%),
    radial-gradient(24% 20% at 50% 48%, rgba(253,224,71,.5), transparent 70%) !important;
}

/* سطح‌های شیشه‌ای: بدون رنگ سنگین تا پشت آن‌ها دیده شود + درخششی که با لمس حرکت می‌کند */
.card,.item,.stat,.sg-c,.tabs,.seg,.reader,.warn,.mrow,.sub-row,.lockc,.slotb,.ned-title,.ned-text,.inp,.hb,.pillmore,.tbtn,.chip,.btn.ghost,.opts .btn,.toast,.it{
  background:
    radial-gradient(circle 150px at var(--mx, 22%) var(--my, 0%), rgba(255,255,255,.14), rgba(255,255,255,0) 70%),
    var(--g-fill) !important;
  box-shadow: var(--g-rim), 0 5px 14px rgba(0,0,0,.16) !important;
}
.chip,.tbtn,.slotb,.it,.inp,.sub-row{ box-shadow: var(--g-rim), 0 3px 8px rgba(0,0,0,.14) !important; }
.top{
  background: radial-gradient(circle 200px at var(--mx, 22%) var(--my, 0%), rgba(255,255,255,.14), rgba(255,255,255,0) 70%), var(--g-fill) !important;
  box-shadow: inset 0 -1px 0 rgba(255,255,255,.18), 0 4px 14px rgba(0,0,0,.14) !important;
}
.sheet{
  background: radial-gradient(circle 260px at var(--mx, 50%) var(--my, 0%), rgba(255,255,255,.14), rgba(255,255,255,0) 70%), linear-gradient(160deg, rgba(255,255,255,.2), rgba(255,255,255,.05)) !important;
  box-shadow: var(--g-rim), 0 -10px 30px rgba(0,0,0,.28) !important;
}
body.light .sheet{ background: radial-gradient(circle 260px at var(--mx, 50%) var(--my, 0%), rgba(255,255,255,.9), rgba(255,255,255,0) 70%), linear-gradient(160deg, rgba(255,255,255,.72), rgba(255,255,255,.42)) !important; }
.wheel{
  background: radial-gradient(circle 220px at var(--mx, 50%) var(--my, 0%), rgba(255,255,255,.12), rgba(255,255,255,0) 70%), linear-gradient(160deg, rgba(255,255,255,.16), rgba(255,255,255,.04)) !important;
  box-shadow: var(--g-rim), 0 -8px 24px rgba(0,0,0,.24) !important;
}
body.light .wheel{ background: linear-gradient(160deg, rgba(255,255,255,.7), rgba(255,255,255,.35)) !important; }
.ov{ background: rgba(6,10,22,.18) !important; -webkit-backdrop-filter: blur(5px) saturate(150%); backdrop-filter: blur(5px) saturate(150%); }

/* شکست نور فقط روی نوار بالا و پنجرهٔ پایین (کم‌هزینه)؛ بقیه فقط بلور سبک دارند */
.top,.sheet{ -webkit-backdrop-filter: url(#lgA) var(--g-blur); backdrop-filter: url(#lgA) var(--g-blur); }
.wheel,.toast,.pillmore,.hb{ -webkit-backdrop-filter: var(--g-blur); backdrop-filter: var(--g-blur); }

/* لمس: شیشه مثل مایع کمی فرو می‌رود */
.card.tap:active,.item:active,.btn:active,.chip:active,.tbtn:active{ transform: scale(.965); transition: transform .12s ease-out; }
.it,.hub{ transition: transform .5s cubic-bezier(.34,1.56,.5,1); }
`,
    js: 'return (' + LIQUID_JS.toString() + ')(nimbo);'
  },
  {
    id: 'pxl', name: 'میدان کارت پیکسلی (بخش اول)',
    desc: 'یک بازی کارتی کاملاً پیکسلی داخل برنامه. دکمهٔ کارت بالای صفحه آن را باز می‌کند: صفحهٔ اصلی با ۶ بخش، مجموعهٔ ۱۵ کارت دوطرفه (روی کارت: تصویر پیکسلی، پشت کارت: توضیح و الگوی حمله) و پیشرفت. ظاهر کارت‌ها با مودهای فعال (مثل کاغذ و جوهر، ترمینال، شب‌بیدار، شیشه‌ای) هماهنگ می‌شود. نبرد، فروشگاه، مأموریت و دسته در بخش‌های بعدی می‌آیند.',
    tags: ['بازی', 'کارت', 'پیکسل', 'مجموعه', 'نبرد', 'pixel', 'card'],
    css: PXL_CSS,
    js: 'return (' + PXL_JS.toString() + ')(nimbo);'
  }
];
/* ===== آسمان اختصاصی هر تم (صفحهٔ اصلی) ===== */
const GLASS_SKY = `
.scene{ background:linear-gradient(180deg, rgba(40,90,210,.28), rgba(150,205,255,.14)) !important; background:linear-gradient(180deg, color-mix(in srgb, var(--st) 34%, transparent), color-mix(in srgb, var(--sb) 22%, transparent)) !important; }
.sun{ background:radial-gradient(circle at 36% 30%, rgba(255,255,255,.95) 0, rgba(255,226,130,.82) 36%, rgba(255,184,60,.7) 100%) !important;
  box-shadow:inset 0 2px 5px rgba(255,255,255,.85), inset 0 -4px 10px rgba(255,150,30,.4), 0 0 0 1px rgba(255,255,255,.5), 0 0 34px 10px rgba(255,205,90,.45) !important; }
.moon{ filter:drop-shadow(0 0 10px rgba(220,235,255,.8)); }
.cloud .puff use:nth-of-type(1){ fill:rgba(255,255,255,.14) !important; }
.cloud .puff use:nth-of-type(2){ fill:rgba(255,255,255,.34) !important; }
.cloud .puff{ filter:drop-shadow(0 1px 0 rgba(255,255,255,.6)) drop-shadow(0 8px 10px rgba(25,45,110,.28)); }
.cover svg use:nth-of-type(1){ fill:rgba(255,255,255,.12) !important; }
.cover svg use:nth-of-type(2){ fill:rgba(255,255,255,.26) !important; }
.cloud{ color:#fff; text-shadow:0 1px 6px rgba(20,40,100,.55); } .c-s{ color:rgba(255,255,255,.82); text-shadow:0 1px 4px rgba(20,40,100,.5); }
.scene.storm .cloud .puff use:nth-of-type(2){ fill:rgba(28,36,66,.55) !important; }
.scene.storm .cover svg use:nth-of-type(2){ fill:rgba(24,30,56,.55) !important; }
.hb{ background:rgba(255,255,255,.2) !important; }
`;
const SKY = {
  liquid: GLASS_SKY,
  crystal: GLASS_SKY,
  amoled: `
.scene{ --st:#000 !important; --sb:#05060a !important; }
.stars{ opacity:1 !important; }
.sun{ filter:saturate(.75) brightness(.92); } .sun::before{ opacity:.45; }
.cloud .puff use:nth-of-type(1){ fill:#0b0c10 !important; }
.cloud .puff use:nth-of-type(2){ fill:#23252d !important; }
.cover svg use:nth-of-type(1){ fill:#090a0d !important; } .cover svg use:nth-of-type(2){ fill:#1a1c22 !important; }
.scene.storm .cloud .puff use:nth-of-type(2){ fill:#15161b !important; }
.scene.storm .cover svg use:nth-of-type(2){ fill:#0e0f13 !important; }
.cloud .puff{ filter:drop-shadow(0 0 1px rgba(255,255,255,.22)); }
.cloud{ color:#e6e8ee; } .c-s{ color:#8b93a1; } .scene.storm .cloud{ color:#f1f3f8; }
.hb{ background:rgba(255,255,255,.07) !important; }
`,
  terminal: `
.scene{ --st:#010a04 !important; --sb:#03160a !important;
  background:radial-gradient(rgba(74,222,128,.16) 1px, transparent 1.5px) 0 0/26px 26px, linear-gradient(180deg, var(--st), var(--sb)) !important; }
.sun{ background:transparent !important; border:2px solid #4ade80; box-shadow:0 0 20px rgba(74,222,128,.55), inset 0 0 16px rgba(74,222,128,.35) !important; }
.sun::before{ background:repeating-conic-gradient(rgba(74,222,128,.32) 0 4deg, transparent 4deg 22.5deg) !important; }
.moon{ box-shadow:12px 0 0 0 #4ade80 !important; filter:drop-shadow(0 0 7px #4ade80) !important; }
.cloud .puff use:nth-of-type(1){ fill:#04200f !important; }
.cloud .puff use:nth-of-type(2){ fill:#0a3a1d !important; }
.cloud .puff{ filter:drop-shadow(0 0 6px rgba(74,222,128,.7)); }
.cover svg use:nth-of-type(1){ fill:#031a0c !important; } .cover svg use:nth-of-type(2){ fill:#072d16 !important; }
.scene.storm .cloud .puff use:nth-of-type(2){ fill:#031a0c !important; }
.scene.storm .cloud .puff{ filter:drop-shadow(0 0 3px rgba(74,222,128,.35)); }
.cloud{ color:#4ade80; } .c-s{ color:#2f9a58; }
.clock{ color:#4ade80; text-shadow:0 0 12px rgba(74,222,128,.6); } .date{ color:#2f9a58; }
.hud{ color:#4ade80 !important; text-shadow:none !important; }
.hb{ background:rgba(0,20,8,.6) !important; border-color:#1d7a42 !important; }
.rh span,.rm{ color:#4ade80; } .rh .rb{ stroke:rgba(74,222,128,.3); } .rh .rp{ stroke:#4ade80; }
.bird{ color:#4ade80; filter:drop-shadow(0 0 5px rgba(74,222,128,.6)); }
.skyhint{ color:#4ade80; text-shadow:none; }
`,
  paper: `
.scene{ --st:#eadcb1 !important; --sb:#dccb9a !important; }
.stars{ animation:none !important; filter:invert(1) brightness(.35); }
.stars::after{ animation:none !important; opacity:0 !important; }
.sun{ background:#e0a23a !important; border:2px solid #33281a; box-shadow:none !important; }
.sun::before{ background:repeating-conic-gradient(rgba(51,40,26,.7) 0 3deg, transparent 3deg 22.5deg) !important; opacity:.8; }
.moon{ box-shadow:12px 0 0 0 #33281a !important; filter:none !important; }
.cloud .puff use:nth-of-type(1){ fill:#d3c08a !important; }
.cloud .puff use:nth-of-type(2){ fill:#f1e5c0 !important; }
.cloud .puff{ filter:drop-shadow(1.3px 0 0 #5c4a2a) drop-shadow(-1.3px 0 0 #5c4a2a) drop-shadow(0 1.3px 0 #5c4a2a) drop-shadow(0 -1.3px 0 #5c4a2a); }
.cover svg use:nth-of-type(1){ fill:#cdb985 !important; } .cover svg use:nth-of-type(2){ fill:#e3d3a6 !important; }
.scene.storm .cloud .puff use:nth-of-type(2){ fill:#8c846f !important; }
.scene.storm .cloud .puff use:nth-of-type(1){ fill:#6f6855 !important; }
.scene.storm .cover svg use:nth-of-type(2){ fill:#7a725d !important; }
.cloud{ color:#33281a; } .c-s{ color:#6b5a38; } .scene.storm .cloud{ color:#f4ead0; } .scene.storm .c-s{ color:#d9ccaa; }
.hud{ color:#33281a !important; text-shadow:none !important; }
.skyhint{ color:#33281a; text-shadow:none; }
`
};
BUILTIN_MODS.forEach(m => { if (SKY[m.id]) m.css += '\n' + SKY[m.id]; });

const MOD_EN = {
  liquid: { n: 'Liquid Glass (heavier)', d: 'The heavier version with real blur and light refraction; only for strong phones. Glass sky, sun and clouds on the home screen.', t: ['theme', 'glass', 'apple', 'liquid'] },
  crystal: { n: 'Smooth Glass (no lag)', d: 'Clear glass with glossy rims and light reflections, no blur or heavy filters, so it stays perfectly smooth even on weak phones. Glass sky on the home screen.', t: ['theme', 'glass', 'apple', 'smooth'] },
  amoled: { n: 'Night Owl (pure black)', d: 'Pure black background and dark cards; saves battery on AMOLED screens. The home sky becomes a starry black night with dark clouds.', t: ['theme', 'dark', 'black', 'amoled', 'battery', 'night'] },
  terminal: { n: 'Terminal (green on black)', d: 'Hacker look with a monospace font and phosphor green. The sun and moon become wireframes and clouds glow like neon.', t: ['theme', 'terminal', 'developer', 'green'] },
  paper: { n: 'Paper & Ink', d: 'Warm cream paper colors and a lined notebook editor. The home sky is a sheet of paper with an ink-drawn sun and outlined clouds.', t: ['theme', 'paper', 'notebook', 'warm'] },
  calm: { n: 'Calm (simple dashboard)', d: 'Clouds, bird and sky step aside and the home screen becomes a clean dashboard: today’s progress ring, quick stats, up-next tasks and habits with direct ticks, plus a quick-add button.', t: ['simple', 'minimal', 'dashboard', 'list', 'calm'] },
  game: { n: 'Game mode (levels, quests & badges)', d: 'Tasks, habits and focus sessions earn points and raise your level and rank. Three daily quests, 14 badges to unlock, and a celebration on every level-up. Tap the level badge at the top to see your profile.', t: ['game', 'points', 'level', 'quests', 'badges', 'xp'] },
  'cvd-rg': { n: 'Color-blind · Red-Green (protan & deutan)', d: 'For the most common type of color blindness. All meaningful colors switch to the scientific Okabe-Ito palette (blue and orange) and also get shapes: low priority ▽, medium ◆, high ▲ with different bar widths, overdue shown with stripes and ⚠, done items struck through with ✔.', t: ['accessibility', 'color-blind', 'protan', 'deutan', 'red', 'green'] },
  'cvd-by': { n: 'Color-blind · Blue-Yellow (tritan)', d: 'For the rarer type that confuses blue with green, or yellow with violet. The palette is built on the red-teal axis, and the same shapes (▽ ◆ ▲), stripes and symbols sit next to every color.', t: ['accessibility', 'color-blind', 'tritan', 'blue', 'yellow'] },
  tint: { n: 'Sunset & Sunrise (time filter)', d: 'A very gentle color layer follows the clock: warmer in the evening and sunset, and a low-blue-light filter at night.', t: ['filter', 'night', 'sunset', 'eyes', 'tint'] },
  rain: { n: 'Rain', d: 'Gentle rain over the home sky; light, capped at 30 fps. Combines with Terminal (green straight rain) and Paper & Ink (pencil rain that draws and erases).', t: ['rain', 'sky', 'effect'] },
  snow: { n: 'Snow', d: 'Soft snow over the home sky; light, capped at 30 fps. On Terminal it becomes green pixels, on Paper & Ink hand-drawn snowflakes.', t: ['snow', 'sky', 'effect', 'winter'] },
  pxl: { n: 'Pixel Card Arena (part 1)', d: 'A fully pixel-art card game inside the app. The card button at the top opens it: a hub with 6 sections, a collection of 15 two-sided cards (front: pixel art, back: description and attack pattern) and progress. Card looks follow your active mods (Paper & Ink, Terminal, Night Owl, Glass). Battle, shop, missions and deck arrive in the next parts.', t: ['game', 'cards', 'pixel', 'collection', 'battle'] }
};
const modName = m => (LANG === 'en' && MOD_EN[m.id]) ? MOD_EN[m.id].n : m.name;
const modDesc = m => (LANG === 'en' && MOD_EN[m.id]) ? MOD_EN[m.id].d : m.desc;
const modTags = m => (LANG === 'en' && MOD_EN[m.id]) ? MOD_EN[m.id].t : (m.tags || []);

const MODS_KEY = 'nimbo_mods_v2', MODS_PEND_KEY = 'nimbo_mods_pending';
let MODS_ON = [];
const modRun = {};
try { const a = JSON.parse(localStorage.getItem(MODS_KEY) || '[]'); if (Array.isArray(a)) MODS_ON = a.map(String); } catch (e) {}
function modsSave() { try { localStorage.setItem(MODS_KEY, JSON.stringify(MODS_ON)); } catch (e) {} }
function modById(id) { return BUILTIN_MODS.find(m => m.id === id); }
const MOD_API = {
  version: 2,
  get S() { return S; },
  save: () => save(),
  refresh: () => refresh(true),
  current: () => current,
  toast: m => toast(String(m)),
  go: id => openSection(id),
  el: id => document.getElementById(id),
  css(txt) { const s = document.createElement('style'); s.textContent = String(txt); document.head.appendChild(s); return () => s.remove(); },
  lang: () => LANG
};
function modStart(m) {
  modStop(m.id);
  const rec = { cleanup: null, style: null, hooks: [] };
  document.body.classList.add('mod-' + m.id);
  if (m.css) {
    const s = document.createElement('style');
    s.setAttribute('data-mod', m.id);
    s.textContent = m.css;
    document.head.appendChild(s);
    rec.style = s;
  }
  if (m.js) {
    const api = Object.create(MOD_API);
    api.onView = fn => {
      modViewHooks.push(fn); rec.hooks.push(fn);
      try { fn(current, view); } catch (e) {}
    };
    try {
      const r = new Function('nimbo', '"use strict";' + m.js)(api);
      if (typeof r === 'function') rec.cleanup = r;
    } catch (e) { toast(t('modErr', modName(m))); }
  }
  modRun[m.id] = rec;
}
function modStop(id) {
  const r = modRun[id];
  if (!r) return;
  try { if (r.cleanup) r.cleanup(); } catch (e) {}
  r.hooks.forEach(fn => { const i = modViewHooks.indexOf(fn); if (i > -1) modViewHooks.splice(i, 1); });
  if (r.style) r.style.remove();
  document.body.classList.remove('mod-' + id);
  delete modRun[id];
}
function modsBoot() {
  let pend = null;
  try { pend = localStorage.getItem(MODS_PEND_KEY); } catch (e) {}
  if (pend && MODS_ON.indexOf(pend) > -1) {
    MODS_ON = MODS_ON.filter(x => x !== pend); modsSave();
    const pm = modById(pend);
    setTimeout(() => toast(t('modCrash', pm ? modName(pm) : pend)), 800);
  }
  try { localStorage.removeItem(MODS_PEND_KEY); } catch (e) {}
  const seenG = {};
  MODS_ON = MODS_ON.filter(id => {
    const m = modById(id);
    if (!m) return false;
    if (m.grp) { if (seenG[m.grp]) return false; seenG[m.grp] = 1; }
    return true;
  });
  MODS_ON.forEach(id => modStart(modById(id)));
}
function modToggle(id) {
  const m = modById(id);
  if (!m) return;
  if (MODS_ON.indexOf(id) > -1) {
    modStop(id);
    MODS_ON = MODS_ON.filter(x => x !== id);
    modsSave();
    toast(t('modRemoved', modName(m)) + (m.js ? ' ' + t('modRestart') : ''));
  } else {
    if (m.grp) {   // از هر گروه (تم، بارش) فقط یکی؛ بقیه آزادانه ترکیب می‌شوند
      MODS_ON.filter(x => { const o = modById(x); return o && o.grp === m.grp; }).forEach(x => { modStop(x); });
      MODS_ON = MODS_ON.filter(x => { const o = modById(x); return !(o && o.grp === m.grp); });
    }
    MODS_ON.push(id);
    modsSave();
    if (m.js) try { localStorage.setItem(MODS_PEND_KEY, id); } catch (e) {}
    modStart(m);
    if (m.js) setTimeout(() => { try { if (localStorage.getItem(MODS_PEND_KEY) === id) localStorage.removeItem(MODS_PEND_KEY); } catch (e) {} }, 8000);
    toast(t('modApplied', modName(m)));
  }
  if (current === 'mods') refresh(true);
}
function modCard(m) {
  const on = MODS_ON.indexOf(m.id) > -1;
  const s = (m.name + ' ' + m.desc + ' ' + (m.tags || []).join(' ') + ' ' + (MOD_EN[m.id] ? MOD_EN[m.id].n + ' ' + MOD_EN[m.id].d + ' ' + MOD_EN[m.id].t.join(' ') : '')).toLowerCase();
  return '<div class="item mod' + (on ? ' on' : '') + '" data-s="' + esc(s) + '"><div class="grow"><div class="ttl">' + esc(modName(m)) + '</div>' +
    '<div class="np">' + esc(modDesc(m)) + '</div>' +
    '<div class="chips mt"><span class="tagc grp">' + t(m.grp === 'theme' ? 'grpTheme' : (m.grp === 'weather' ? 'grpWeather' : (m.grp === 'cvd' ? 'grpCvd' : 'grpAddon'))) + '</span>' + modTags(m).map(x => '<span class="tagc">' + esc(x) + '</span>').join('') + '</div></div>' +
    '<button class="btn sm' + (on ? ' ghost' : '') + '" type="button" data-act="mod-toggle" data-id="' + esc(m.id) + '">' + t(on ? 'modRemoveB' : 'modApply') + '</button></div>';
}
function vMods() {
  return '<div class="card"><div class="sub">' + t('modsIntro') + '</div>' +
    '<input id="mod-q" class="inp" type="text" placeholder="' + esc(t('modSearch')) + '" autocomplete="off" style="margin-top:10px"></div>' +
    (BUILTIN_MODS.length ? BUILTIN_MODS.map(modCard).join('') : empty(t('modEmpty'))) + '<div class="empty" id="mod-none" style="display:none">' + t('modNoMatch') + '</div>';
}
function filterMods() {
  const q = (val('mod-q') || '').trim().toLowerCase();
  let n = 0;
  view.querySelectorAll('.mod').forEach(e => {
    const hit = !q || (e.getAttribute('data-s') || '').indexOf(q) > -1;
    e.style.display = hit ? '' : 'none';
    if (hit) n++;
  });
  const z = $('mod-none');
  if (z) z.style.display = n ? 'none' : '';
}
V.mods = vMods;


/* ================= نمایش ================= */
let popId = null;
const modViewHooks = [];
function render() {
  view.classList.toggle('home', current === 'home');
  if (current !== 'home') lastVis = null;
  const f = V[current] || vHome;
  try { view.innerHTML = f(); }
  catch (err) { view.innerHTML = '<div class="card">⚠️ ' + esc(err.message) + '</div>'; }
  if (current === 'home') {
    paintSky();
    layoutClouds();
    requestAnimationFrame(() => { const b = $('clouds'); if (b) b.classList.add('ready'); });
  }
  autoGrow();
  if (popId) {
    const el = view.querySelector('.chk[data-id="' + popId + '"]');
    if (el) el.classList.add('pop');
    popId = null;
  }
  document.body.classList.remove('focus');
  modViewHooks.forEach(fn => { try { fn(current, view); } catch (e) {} });
  arViews.forEach(fn => { try { fn(current, view); } catch (e) {} });
}
function keepInputs() {
  const o = {};
  view.querySelectorAll('input[id],textarea[id],select[id]').forEach(e => { o[e.id] = e.value; });
  return o;
}
function restoreInputs(o) { Object.keys(o).forEach(k => { const e = $(k); if (e) e.value = o[k]; }); }
function refresh(keep) {
  const st = view.scrollTop;
  const k = keep === false ? null : keepInputs();
  render();
  if (k) restoreInputs(k);
  if (current === 'notes') filterNotes();
  autoGrow();
  view.scrollTop = st;
}
function markActive() { items.forEach((b, i) => b.classList.toggle('act', SECTIONS[i].id === current)); }
let enterT;
function openSection(id, fromPop) {
  if (!V[id]) id = 'home';
  if (ed) closeEd(false, true);
  if (current === 'diary' && id !== 'diary') lockDiary();
  if (!fromPop && id !== current) { try { history.pushState({ s: id }, ''); } catch (e) {} }
  current = id;
  $('title').textContent = titleOf(id);
  $('homeBtn').classList.toggle('hide', id === 'home');
  $('setBtn').classList.toggle('hide', id === 'settings');
  markActive();
  view.classList.remove('enter');
  render();
  view.scrollTop = 0;
  void view.offsetWidth;
  view.classList.add('enter');
  clearTimeout(enterT);
  enterT = setTimeout(() => view.classList.remove('enter'), 1100);
}

/* ================= پنجره‌های پایین (شیت) ================= */
const ov = $('ov'), sheet = $('sheet');
const stack = [];
let shHist = false, ignorePop = 0;

function paintSheet(keep) {
  document.body.classList.toggle('sheet-open', stack.length > 0);
  if (!stack.length) {
    ov.classList.remove('show');
    setTimeout(() => {
      if (!stack.length && shHist) { shHist = false; ignorePop++; try { history.back(); } catch (e) { ignorePop--; } }
    }, 60);
    setTimeout(() => { if (!stack.length) sheet.innerHTML = ''; }, 520);
    return;
  }
  if (!shHist) { shHist = true; try { history.pushState({ s: current, sh: 1 }, ''); } catch (e) { shHist = false; } }
  const top = stack[stack.length - 1];
  const st = keep ? sheet.scrollTop : 0;
  sheet.innerHTML = top.render();
  sheet.scrollTop = st;
  ov.classList.add('show');
  if (top.mount) top.mount();
}
function pushSheet(d) { stack.push(d); paintSheet(false); }
function popSheet() { stack.pop(); paintSheet(false); }
function swapSheet(d) { stack[stack.length - 1] = d; paintSheet(false); }
function repaint() { paintSheet(true); }

ov.addEventListener('click', e => {
  if (e.target === ov) { popSheet(); return; }
  const el = e.target.closest('[data-sa]');
  if (!el) return;
  const top = stack[stack.length - 1];
  if (top && top.act) top.act(el.dataset.sa, el);
});
ov.addEventListener('input', e => {
  const nfm = e.target.dataset ? e.target.dataset.nf : '';
  if (nfm) numFmt(e.target, nfm === 'd');
  const top = stack[stack.length - 1];
  if (top && top.input) top.input(e);
});
ov.addEventListener('keydown', e => {
  if (e.key === 'Enter' && e.target.dataset && e.target.dataset.senter) {
    e.preventDefault();
    const top = stack[stack.length - 1];
    if (top && top.act) top.act(e.target.dataset.senter, e.target);
  }
});

function optionsSheet(title, opts, cb) {
  return {
    render() {
      return '<div class="grab"></div><div class="sh-t">' + title + '</div><div class="opts">' +
        opts.map((o, i) => '<button class="btn ghost" type="button" data-sa="opt" data-i="' + i + '">' + esc(o[1]) + '</button>').join('') + '</div>';
    },
    act(a, el) { if (a === 'opt') { cb(opts[Number(el.dataset.i)][0]); popSheet(); } }
  };
}
function confirmSheet(o) {
  return {
    render() {
      return '<div class="grab"></div><div class="sh-t">' + o.title + '</div><div class="warn">' + o.msg + '</div>' +
        '<div class="row sh-b"><button class="btn ' + (o.danger ? 'danger' : '') + '" type="button" data-sa="ok">' + o.ok + '</button>' +
        '<button class="btn ghost" type="button" data-sa="no">' + t('cancel') + '</button></div>';
    },
    act(a) { if (a === 'ok') { popSheet(); o.cb(); } else if (a === 'no') popSheet(); }
  };
}

/* انتخاب تاریخ و ساعت: تقویم کامل، همهٔ ماه‌ها و سال‌ها */
function pickerSheet(o) {
  const time = o.time !== false;
  const base = new Date(o.ts ? o.ts : (time ? Math.ceil((Date.now() + 3600000) / 300000) * 300000 : Date.now()));
  const st = { day: dayKey(base), h: base.getHours(), m: base.getMinutes(), view: new Date(base.getFullYear(), base.getMonth(), base.getDate(), 12) };
  const presets = [
    ['pre30', () => Date.now() + 30 * 60000],
    ['pre60', () => Date.now() + 60 * 60000],
    ['pre120', () => Date.now() + 120 * 60000],
    ['preTonight', () => { const d = new Date(); d.setHours(21, 0, 0, 0); if (d.getTime() <= Date.now()) d.setDate(d.getDate() + 1); return d.getTime(); }],
    ['preTom', () => { const d = new Date(); d.setDate(d.getDate() + 1); d.setHours(9, 0, 0, 0); return d.getTime(); }]
  ];
  function cur() { return mkTime(st.day, time ? pad(st.h) + ':' + pad(st.m) : '23:59'); }
  function calHtml() {
    const days = calMonth(st.view);
    if (!days.length) return '';
    const first = days[0];
    const off = LANG === 'en' ? first.getDay() : (first.getDay() + 1) % 7;
    let title;
    try { title = first.toLocaleDateString(NL(), { month: 'long', year: 'numeric' }); } catch (e) { title = dayKey(first).slice(0, 7); }
    const ar = LANG === 'en' ? ['❮', '❯'] : ['❯', '❮'];
    const ya = LANG === 'en' ? ['«', '»'] : ['»', '«'];
    let wl = '';
    for (let i = 0; i < 7; i++) {
      const dd = new Date(2024, 0, (LANG === 'en' ? 7 : 6) + i, 12);
      let w = '';
      try { w = dd.toLocaleDateString(NL(), { weekday: 'narrow' }); } catch (e) {}
      wl += '<span>' + esc(w) + '</span>';
    }
    let cells = '';
    for (let i = 0; i < off; i++) cells += '<i></i>';
    const today = dayKey();
    days.forEach(d => {
      const k = dayKey(d);
      cells += '<button type="button" class="' + (k === st.day ? 'on' : '') + (k === today ? ' td' : '') + '" data-sa="pk-day" data-v="' + k + '">' + nf(calInfo(d).dom) + '</button>';
    });
    return '<div class="cal-h"><button type="button" data-sa="cal-yp">' + ya[0] + '</button><button type="button" data-sa="cal-mp">' + ar[0] + '</button>' +
      '<b>' + esc(title) + '</b>' +
      '<button type="button" data-sa="cal-mn">' + ar[1] + '</button><button type="button" data-sa="cal-yn">' + ya[1] + '</button></div>' +
      '<div class="cal-w">' + wl + '</div><div class="cal-g">' + cells + '</div>';
  }
  function ui() {
    sheet.querySelectorAll('[data-sa="pk-day"]').forEach(b => b.classList.toggle('on', b.dataset.v === st.day));
    sheet.querySelectorAll('[data-sa="pk-h"]').forEach(b => b.classList.toggle('on', Number(b.dataset.v) === st.h));
    sheet.querySelectorAll('[data-sa="pk-m"]').forEach(b => b.classList.toggle('on', Number(b.dataset.v) === st.m));
    const p = sheet.querySelector('#pk-prev');
    if (p) { const ts = cur(); p.textContent = ts ? (time ? fmtDue(ts) : fmtDay(ts)) : ''; }
    const mv = sheet.querySelector('#pk-mv');
    if (mv) mv.textContent = fp(st.m);
    ['pk-h', 'pk-m'].forEach(n => {
      const el = sheet.querySelector('[data-sa="' + n + '"].on');
      if (el && el.scrollIntoView) { try { el.scrollIntoView({ inline: 'center', block: 'nearest' }); } catch (e) {} }
    });
  }
  function paintCal() {
    const c = sheet.querySelector('#cal');
    if (c) c.innerHTML = calHtml();
    ui();
  }
  function setTs(ts) {
    const d = new Date(ts);
    st.day = dayKey(d); st.h = d.getHours(); st.m = d.getMinutes();
    st.view = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 12);
  }
  return {
    render() {
      let h = '<div class="grab"></div><div class="sh-t">' + t(time ? 'pkTitleDT' : 'pkTitleD') + '</div><div id="cal">' + calHtml() + '</div>';
      if (time) {
        h += '<div class="lbl">' + t('hourL') + '</div><div class="strip">';
        for (let i = 0; i < 24; i++) h += '<button class="pk sm" type="button" data-sa="pk-h" data-v="' + i + '">' + fp(i) + '</button>';
        h += '</div><div class="lbl">' + t('minL') + '</div><div class="strip"><button class="pk sm" type="button" data-sa="pk-mi" data-v="-1">−1</button>';
        for (let i = 0; i < 60; i += 5) h += '<button class="pk sm" type="button" data-sa="pk-m" data-v="' + i + '">' + fp(i) + '</button>';
        h += '<button class="pk sm" type="button" data-sa="pk-mi" data-v="1">+1</button><span class="pkv" id="pk-mv"></span></div>';
        h += '<div class="chips">' + presets.map((p, i) => '<button class="chip" type="button" data-sa="pk-pre" data-i="' + i + '">' + t(p[0]) + '</button>').join('') + '</div>';
      }
      h += '<div class="pk-prev" id="pk-prev"></div>';
      h += '<div class="row sh-b"><button class="btn" type="button" data-sa="ok">' + t('confirm') + '</button>' +
        '<button class="btn ghost" type="button" data-sa="clr">' + t('noTime') + '</button>' +
        '<button class="btn ghost" type="button" data-sa="cancel">' + t('cancel') + '</button></div>';
      return h;
    },
    mount() { ui(); },
    act(a, el) {
      switch (a) {
        case 'pk-day': st.day = el.dataset.v; ui(); break;
        case 'cal-mp': st.view = calStep(st.view, -1); paintCal(); break;
        case 'cal-mn': st.view = calStep(st.view, 1); paintCal(); break;
        case 'cal-yp': for (let i = 0; i < 12; i++) st.view = calStep(st.view, -1); paintCal(); break;
        case 'cal-yn': for (let i = 0; i < 12; i++) st.view = calStep(st.view, 1); paintCal(); break;
        case 'pk-h': st.h = Number(el.dataset.v); ui(); break;
        case 'pk-m': st.m = Number(el.dataset.v); ui(); break;
        case 'pk-mi': st.m = (st.m + Number(el.dataset.v) + 60) % 60; ui(); break;
        case 'pk-pre': setTs(presets[Number(el.dataset.i)][1]()); paintCal(); break;
        case 'ok': { const ts = cur(); if (ts === null) { toast(t('badTime')); return; } o.cb(ts); popSheet(); break; }
        case 'clr': o.cb(null); popSheet(); break;
        case 'cancel': popSheet(); break;
      }
    }
  };
}

function fieldHtml(f, d) {
  const k = f.key, v = d[k];
  switch (f.kind) {
    case 'text':
      return '<label class="lbl">' + f.label + '<input class="inp" type="text" data-f="' + k + '" value="' + esc(v) + '" maxlength="' + (f.max || 120) + '" placeholder="' + esc(f.ph || '') + '" autocomplete="off"></label>';
    case 'pw':
      return '<label class="lbl">' + f.label + '<input class="inp" type="password" data-f="' + k + '" value="' + esc(v) + '" autocomplete="new-password"></label>';
    case 'area':
      return '<label class="lbl">' + f.label + '<textarea class="inp" rows="6" data-f="' + k + '" placeholder="' + esc(f.ph || '') + '">' + esc(v) + '</textarea></label>';
    case 'money':
      return '<label class="lbl">' + f.label + '<input class="inp" type="text" inputmode="decimal" data-f="' + k + '" data-nf="d" value="' + esc(v) + '" placeholder="' + esc(f.ph || '') + '" autocomplete="off"></label>';
    case 'num':
      return '<label class="lbl">' + f.label + '<input class="inp" type="text" inputmode="decimal" data-f="' + k + '" data-nf="d" value="' + esc(v) + '" placeholder="' + esc(f.ph || '') + '" autocomplete="off"></label>';
    case 'chips':
      return '<div class="lbl">' + f.label + '</div><div class="chips">' + f.opts.map((o, i) =>
        '<button class="chip' + (String(v) === String(o[0]) ? ' on' : '') + '" type="button" data-sa="chip" data-k="' + k + '" data-i="' + i + '">' + esc(o[1]) + '</button>').join('') + '</div>';
    case 'multi':
      return '<div class="lbl">' + f.label + '</div><div class="chips">' + f.opts.map((o, i) =>
        '<button class="chip' + ((v || []).indexOf(o[0]) > -1 ? ' on' : '') + '" type="button" data-sa="multi" data-k="' + k + '" data-i="' + i + '">' + esc(o[1]) + '</button>').join('') + '</div>';
    case 'toggle':
      return '<div class="chips"><button class="chip' + (v ? ' on' : '') + '" type="button" data-sa="tog" data-k="' + k + '">' + f.label + ': ' + t(v ? 'yes' : 'no') + '</button></div>';
    case 'due':
      return '<div class="lbl">' + f.label + '</div><div class="chips"><button class="chip on" type="button" data-sa="due" data-k="' + k + '">' +
        (v ? (f.time === false ? fmtDay(v) : fmtDue(v)) : f.empty) + '</button>' +
        (v ? '<button class="chip" type="button" data-sa="due-clear" data-k="' + k + '">' + t('clearBtn') + '</button>' : '') + '</div>';
    case 'subs':
      return '<div class="lbl">' + f.label + '</div>' + (v || []).map(s =>
        '<div class="sub-row"><span>' + esc(s.t) + '</span><button class="mini" type="button" data-sa="sub-del" data-k="' + k + '" data-sid="' + esc(s.id) + '">✕</button></div>').join('') +
        '<div class="row gap"><input id="sn-' + k + '" class="inp" type="text" maxlength="80" placeholder="' + esc(t('subPh')) + '" data-senter="sub-add" data-k="' + k + '" autocomplete="off">' +
        '<button class="btn sm" type="button" data-sa="sub-add" data-k="' + k + '">➕</button></div>';
    case 'when': {
      const opts = [['', t('noTime')], ['week', t('thisWeek')], ['month', t('oneMonth')], ['funded', t('whenFunded')], ['date', t('pickDate')]];
      const wl = whenLabel(d);
      return '<div class="lbl">' + t('fWhen') + '</div><div class="chips">' + opts.map(o =>
        '<button class="chip' + (d.when === o[0] ? ' on' : '') + '" type="button" data-sa="when" data-v="' + o[0] + '">' + o[1] + '</button>').join('') + '</div>' +
        (wl ? '<div class="sub gap">' + t('whenSel', esc(wl)) + '</div>' : '');
    }
    case 'info':
      return '<div class="sub gap">' + f.html + '</div>';
  }
  return '';
}

function formSheet(o) {
  const d = o.draft;
  const getBs = () => typeof o.buttons === 'function' ? o.buttons(d)
    : (o.buttons || [{ label: t('saveBtn'), fn: o.onSave }, { label: t('cancel'), cls: 'ghost', fn: null }]);
  function flush() {
    o.fields.forEach(f => {
      if (f.kind === 'subs') {
        const i = $('sn-' + f.key);
        if (i && i.value.trim()) { d[f.key].push({ id: uid(), t: i.value.trim(), d: false }); i.value = ''; }
      }
    });
  }
  return {
    render() {
      const bs = getBs();
      let h = '<div class="grab"></div><div class="sh-t">' + o.title + '</div>';
      o.fields.forEach(f => { if (f.show && !f.show(d)) return; h += fieldHtml(f, d); });
      h += '<div class="row sh-b">' + bs.map((b, i) =>
        '<button class="btn ' + (b.cls || '') + '" type="button" data-sa="btn" data-i="' + i + '">' + b.label + '</button>').join('') + '</div>';
      return h;
    },
    input(e) { const f = e.target.dataset.f; if (f) d[f] = e.target.value; },
    act(a, el) {
      const k = el.dataset.k;
      const fd = o.fields.find(x => x.key === k);
      switch (a) {
        case 'btn': {
          const b = getBs()[Number(el.dataset.i)];
          if (!b) return;
          flush();
          const r = b.fn ? b.fn(d) : undefined;
          if (r === false) return;
          popSheet();
          if (typeof r === 'function') r();
          break;
        }
        case 'chip': if (fd) { d[k] = fd.opts[Number(el.dataset.i)][0]; repaint(); } break;
        case 'multi': if (fd) { const n = fd.opts[Number(el.dataset.i)][0], p = d[k].indexOf(n); if (p > -1) d[k].splice(p, 1); else d[k].push(n); repaint(); } break;
        case 'tog': d[k] = !d[k]; repaint(); break;
        case 'due':
          if (fd) pushSheet(pickerSheet({ ts: d[k], time: fd.time !== false, cb: ts => { d[k] = ts; } }));
          break;
        case 'due-clear': d[k] = null; repaint(); break;
        case 'sub-add': {
          const inp = $('sn-' + k);
          const v = inp ? inp.value.trim() : '';
          if (v) d[k].push({ id: uid(), t: v, d: false });
          repaint();
          const i2 = $('sn-' + k);
          if (i2) i2.focus();
          break;
        }
        case 'sub-del': d[k] = d[k].filter(x => x.id !== el.dataset.sid); repaint(); break;
        case 'when': {
          const v = el.dataset.v;
          if (v === '') { d.when = ''; d.wd = 0; repaint(); }
          else if (v === 'week') { d.when = 'week'; d.wd = endOfWeek(); repaint(); }
          else if (v === 'funded') { d.when = 'funded'; d.wd = 0; repaint(); }
          else if (v === 'month') {
            const mo = monthOptions();
            pushSheet(optionsSheet(t('whichMonth'), mo.map((m, i) => [i, m.label]), i => { d.when = 'month'; d.wd = mo[i].end; }));
          } else if (v === 'date') {
            pushSheet(pickerSheet({ ts: d.wd || null, time: false, cb: ts => { if (ts) { d.when = 'date'; d.wd = ts; } } }));
          }
          break;
        }
      }
    }
  };
}

/* ---------- فرم‌های افزودن و ویرایش ---------- */
function colOf(kind) { return kind === 'qt' ? S.qtimers : (S[kind] || []); }
function findItem(kind, id) {
  if (kind === 'slot') { const i = Number(id); return S.slots[i] ? { id: i, sec: S.slots[i] } : null; }
  return colOf(kind).find(x => x.id === id) || null;
}
function askCloud(kind, id) {
  pushSheet({
    render() {
      return '<div class="grab"></div><div class="sh-t">' + t('askCloudT') + '</div>' +
        '<div class="muted center" style="margin-top:0">' + t('askCloudMsg') + '</div>' +
        '<div class="row sh-b"><button class="btn" type="button" data-sa="y">' + t('cloudYes') + '</button>' +
        '<button class="btn ghost" type="button" data-sa="n">' + t('cloudNo') + '</button></div>';
    },
    act(a) {
      if (a === 'y') {
        const x = findItem(kind, id);
        if (x) { x.cloud = true; save(); refresh(true); }
        popSheet(); toast(t('cloudMade'));
      } else if (a === 'n') popSheet();
    }
  });
}
function taskForm(id) {
  const tk = id ? S.tasks.find(x => x.id === id) : null;
  if (id && !tk) return;
  const d = tk
    ? { title: tk.title, due: tk.due || null, pri: tk.pri == null ? 1 : tk.pri, rep: tk.rep || '', subs: JSON.parse(JSON.stringify(tk.subs)), cloud: !!tk.cloud }
    : { title: '', due: null, pri: 1, rep: '', subs: [], cloud: false };
  const fields = [
    { kind: 'text', key: 'title', label: t('fTitle') },
    { kind: 'due', key: 'due', label: t('fDue'), empty: t('dueEmpty') },
    { kind: 'chips', key: 'pri', label: t('fPri'), opts: [[0, PRI_ICON[0] + ' ' + t('pri0')], [1, PRI_ICON[1] + ' ' + t('pri1')], [2, PRI_ICON[2] + ' ' + t('pri2')]] },
    { kind: 'chips', key: 'rep', label: t('fRep'), opts: [['', t('repNone')], ['d', t('repD')], ['w', t('repW')]] },
    { kind: 'subs', key: 'subs', label: t('fSubs') }
  ];
  if (tk) fields.push({ kind: 'toggle', key: 'cloud', label: t('fCloud') });
  pushSheet(formSheet({
    title: tk ? t('editTask') : t('newTask'), draft: d, fields: fields,
    onSave(dd) {
      const title = dd.title.trim();
      if (!title) { toast(t('titleMissing')); return false; }
      let due = dd.due;
      if (dd.rep && !due) due = mkTime(dayKey(), '23:59');
      if (tk) {
        const od = tk.due;
        tk.title = title; tk.due = due; tk.pri = Number(dd.pri); tk.rep = dd.rep; tk.subs = dd.subs; tk.cloud = !!dd.cloud;
        if (od !== due) tk.notified = !!(due && due <= Date.now());
        taskSync(tk);
        save(); refresh(true); toast(t('saved'));
        return;
      }
      const nt = { id: uid(), title: title, due: due, done: false, notified: !!(due && due <= Date.now()), created: Date.now(), pri: Number(dd.pri), rep: dd.rep, subs: dd.subs, cloud: false };
      S.tasks.push(nt);
      save(); refresh(false);
      return () => askCloud('tasks', nt.id);
    }
  }));
}
function shopForm(id) {
  const x = id ? S.shop.find(i => i.id === id) : null;
  if (id && !x) return;
  const d = x
    ? { text: x.text, price: fmtNumVal(x.price), saved: fmtNumVal(x.saved), when: x.when || '', wd: x.wd || 0, cloud: !!x.cloud }
    : { text: '', price: '', saved: '', when: '', wd: 0, cloud: false };
  const fields = [
    { kind: 'text', key: 'text', label: t('fShopName'), max: 80 },
    { kind: 'money', key: 'price', label: t('fPrice') },
    { kind: 'money', key: 'saved', label: t('fSaved') },
    { kind: 'when', key: 'when' }
  ];
  if (x) fields.push({ kind: 'toggle', key: 'cloud', label: t('fCloud') });
  pushSheet(formSheet({
    title: x ? t('editItem') : t('newItem'), draft: d, fields: fields,
    onSave(dd) {
      const text = dd.text.trim();
      if (!text) { toast(t('needName')); return false; }
      const price = Math.max(0, Number(toEn(dd.price)) || 0), saved = Math.max(0, Number(toEn(dd.saved)) || 0);
      if (x) {
        if (x.when !== dd.when || x.wd !== dd.wd) x.wn = false;
        x.text = text; x.price = price; x.saved = saved; x.when = dd.when; x.wd = dd.wd; x.cloud = !!dd.cloud;
        checkFunded(x);
        save(); refresh(true); toast(t('saved'));
        return;
      }
      const nx = { id: uid(), text: text, price: price, saved: saved, when: dd.when, wd: dd.wd, done: false, cloud: false, created: Date.now(), fn: false, wn: false };
      checkFunded(nx);
      S.shop.push(nx);
      save(); refresh(false);
      return () => askCloud('shop', nx.id);
    }
  }));
}
function habitForm(id) {
  const h = id ? S.habits.find(x => x.id === id) : null;
  if (id && !h) return;
  const d = h ? { name: h.name, subs: JSON.parse(JSON.stringify(h.subs)), cloud: !!h.cloud, wd: (h.wd || []).slice() } : { name: '', subs: [], cloud: false, wd: [] };
  const fields = [
    { kind: 'text', key: 'name', label: t('fHabitName'), max: 60 },
    { kind: 'multi', key: 'wd', label: t('fHabitDays'), opts: WD_ORDER().map(n => [n, wdName(n, false)]) },
    { kind: 'subs', key: 'subs', label: t('fHabitSubs') }
  ];
  if (h) fields.push({ kind: 'toggle', key: 'cloud', label: t('fCloud') });
  pushSheet(formSheet({
    title: h ? t('editHabit') : t('newHabit'), draft: d, fields: fields,
    onSave(dd) {
      const name = dd.name.trim();
      if (!name) { toast(t('needHabit')); return false; }
      if (h) {
        h.name = name; h.subs = dd.subs; h.cloud = !!dd.cloud; h.wd = dd.wd.slice();
        hSync(h, dayKey());
        save(); refresh(true); toast(t('saved'));
        return;
      }
      const nh = { id: uid(), name: name, days: [], subs: dd.subs, sd: {}, cloud: false, wd: dd.wd.slice() };
      S.habits.push(nh);
      save(); refresh(false);
      return () => askCloud('habits', nh.id);
    }
  }));
}
function moneyForm(id) {
  const m = id ? S.money.find(x => x.id === id) : null;
  if (id && !m) return;
  const d = m
    ? { a: fmtNumVal(m.a), t: m.t || '', c: Number.isInteger(m.c) ? m.c : 5, ts: mkTime(m.d, '12:00') }
    : { a: '', t: '', c: 0, ts: null };
  pushSheet(formSheet({
    title: m ? t('editSpend') : t('newSpend'), draft: d,
    fields: [
      { kind: 'money', key: 'a', label: t('fAmount') },
      { kind: 'text', key: 't', label: t('fDesc'), max: 60 },
      { kind: 'chips', key: 'c', label: t('fCat'), opts: CAT_ICONS.map((ic, i) => [i, ic + ' ' + t('cat' + i)]) },
      { kind: 'due', key: 'ts', label: t('pickDate'), time: false, empty: t('today') }
    ],
    onSave(dd) {
      const a = Number(toEn(dd.a));
      if (!(a > 0)) { toast(t('badAmount')); return false; }
      const day = dd.ts ? dayKey(new Date(dd.ts)) : (m ? m.d : dayKey());
      const c = Number(dd.c), desc = dd.t.trim();
      if (m) {
        m.a = a; m.t = desc; m.c = c; m.d = day;
        const le = S.log.find(e => e.k === 'm' && e.ref === m.id);
        if (le) { le.a = a; le.n = desc; le.c = c; le.d = day; }
        else logAdd('m', day, desc, { a: a, c: c, ref: m.id });
        toast(t('saved'));
      } else {
        const nm = { id: uid(), a: a, t: desc, d: day, c: c };
        S.money.push(nm);
        logAdd('m', day, desc, { a: a, c: c, ref: nm.id });
        toast(t('spendSaved'));
      }
      save(); refresh(!!m);
    }
  }));
}
function goalForm(id) {
  const g = id ? S.goals.find(x => x.id === id) : null;
  if (id && !g) return;
  const d = g
    ? { title: g.title, icon: g.icon || '🎯', target: fmtNumVal(g.target), cur: fmtNumVal(g.cur), unit: g.unit, step: fmtNumVal(g.step), due: g.due || null, cloud: !!g.cloud }
    : { title: '', icon: '🎯', target: '', cur: '', unit: '', step: '', due: null, cloud: false };
  const fields = [
    { kind: 'text', key: 'title', label: t('fGoalTitle'), max: 80 },
    { kind: 'chips', key: 'icon', label: t('fIcon'), opts: ICONS.map(i => [i, i]) },
    { kind: 'num', key: 'target', label: t('fTarget') },
    { kind: 'num', key: 'cur', label: t('fCur') },
    { kind: 'text', key: 'unit', label: t('fUnit'), max: 20 },
    { kind: 'num', key: 'step', label: t('fStep') },
    { kind: 'due', key: 'due', label: t('fDeadline'), time: false, empty: t('noDeadline') }
  ];
  if (g) fields.push({ kind: 'toggle', key: 'cloud', label: t('fCloud') });
  pushSheet(formSheet({
    title: g ? t('editGoal') : t('newGoal'), draft: d, fields: fields,
    onSave(dd) {
      const title = dd.title.trim();
      const target = Number(toEn(dd.target));
      if (!title) { toast(t('needGoal')); return false; }
      if (!(target > 0)) { toast(t('badTarget')); return false; }
      const cur = Math.max(0, Number(toEn(dd.cur)) || 0);
      const stp = Number(toEn(dd.step)) > 0 ? Number(toEn(dd.step)) : Math.max(1, Math.round(target / 10));
      if (g) {
        g.title = title; g.icon = dd.icon; g.target = target; g.cur = cur; g.unit = dd.unit.trim(); g.step = stp; g.due = dd.due || null; g.cloud = !!dd.cloud;
        save(); refresh(true); toast(t('saved'));
        return;
      }
      const ng = { id: uid(), title: title, icon: dd.icon, target: target, cur: cur, unit: dd.unit.trim(), step: stp, due: dd.due || null, created: Date.now(), cloud: false };
      S.goals.push(ng);
      save(); refresh(false);
      return () => askCloud('goals', ng.id);
    }
  }));
}
function slotForm(i) {
  const d = { min: S.slots[i] ? fmtNumVal(Math.floor(S.slots[i] / 60)) : '', sec: S.slots[i] ? fmtNumVal(S.slots[i] % 60) : '' };
  pushSheet(formSheet({
    title: S.slots[i] ? t('slotEdit') : t('slotAdd'), draft: d,
    fields: [{ kind: 'num', key: 'min', label: t('fSlotMin') }, { kind: 'num', key: 'sec', label: t('fSlotSec') }],
    onSave(dd) {
      const n = Math.round(Number(toEn(dd.min) || 0)) * 60 + Math.round(Number(toEn(dd.sec) || 0));
      if (!(n >= 5 && n <= 36000)) { toast(t('badMin')); return false; }
      S.slots[i] = n; save(); refresh(true); toast(t('saved'));
    }
  }));
}
function savingsSheet(id) {
  const x = S.shop.find(i => i.id === id);
  if (!x) return { render() { return '<div class="empty">' + t('notFound') + '</div>'; } };
  const d = { amt: '' };
  const apply = (sign, dd) => {
    const a = Number(toEn(dd.amt));
    if (!(a > 0)) { toast(t('badAmount')); return false; }
    x.saved = Math.max(0, x.saved + sign * a);
    checkFunded(x);
    save(); refresh(true);
  };
  return formSheet({
    title: t('savTitle', esc(x.text)), draft: d,
    fields: [
      { kind: 'info', html: t('savNow') + ': ' + nf(x.saved, true) + (x.price ? ' / ' + nf(x.price, true) : '') + ' ' + t('cur') },
      { kind: 'money', key: 'amt', label: t('fSavAmt') }
    ],
    buttons: [
      { label: t('savAdd'), fn: dd => apply(1, dd) },
      { label: t('savSub'), cls: 'ghost', fn: dd => apply(-1, dd) },
      { label: t('cancel'), cls: 'ghost', fn: null }
    ]
  });
}
function openQuick() {
  const d = { text: '', type: 't', due: null, qm: 25, qc: '', qs: '' };
  pushSheet(formSheet({
    title: t('quickTitle'), draft: d,
    fields: [
      { kind: 'chips', key: 'type', label: t('fType'), opts: [['t', t('typeTask')], ['n', t('typeNote')], ['q', t('typeTimer')]] },
      { kind: 'text', key: 'text', label: t('fQuickText'), ph: t('quickPh'), show: dd => dd.type !== 'q' },
      { kind: 'text', key: 'text', label: t('fTimerLabel'), ph: t('timerLabelPh'), show: dd => dd.type === 'q' },
      { kind: 'due', key: 'due', label: t('fQuickDue'), empty: t('dueEmpty'), show: dd => dd.type === 't' },
      { kind: 'chips', key: 'qm', label: t('fTimerMin'), opts: [5, 10, 15, 25, 30, 45, 60].map(m => [m, nf(m) + ' ' + t('minU')]), show: dd => dd.type === 'q' },
      { kind: 'num', key: 'qc', label: t('fTimerCustom'), show: dd => dd.type === 'q' },
      { kind: 'num', key: 'qs', label: t('fTimerSec'), show: dd => dd.type === 'q' }
    ],
    buttons: dd => dd.type === 'q'
      ? [{ label: t('startTimerCloud'), fn: x => quickSend(x, true) }, { label: t('cancel'), cls: 'ghost', fn: null }]
      : [{ label: t('sendCloud'), fn: x => quickSend(x, true) }, { label: t('justSave'), cls: 'ghost', fn: x => quickSend(x, false) }, { label: t('cancel'), cls: 'ghost', fn: null }]
  }));
}
function quickSend(d, cloud) {
  const text = d.text.trim();
  if (d.type === 'q') {
    const cs = Math.max(0, Math.round(Number(toEn(d.qs)) || 0)), cm = Number(toEn(d.qc)) || 0;
    let sec = (cm > 0 || cs > 0) ? Math.round(cm * 60) + cs : (Number(d.qm) || 25) * 60;
    sec = Math.max(5, Math.min(36000, sec));
    S.qtimers.push({ id: uid(), label: text, end: Date.now() + sec * 1000, total: sec, created: Date.now() });
    save(); refresh(false);
    toast(sec % 60 === 0 ? t('timerStarted', nf(sec / 60)) : t('timerStartedS', fmtClock(sec)));
    return () => flyBird();
  }
  if (!text) { toast(t('needText')); return false; }
  if (d.type === 'n') S.notes.push({ id: uid(), title: '', text: text, t: Date.now(), pin: false, cloud: cloud });
  else S.tasks.push({ id: uid(), title: text, due: d.due || null, done: false, notified: !!(d.due && d.due <= Date.now()), created: Date.now(), pri: 1, rep: '', subs: [], cloud: cloud });
  save(); refresh(false);
  return () => flyBird();
}
function openForm(kind, id) {
  if (kind === 'tasks') taskForm(id);
  else if (kind === 'notes') { if (id) openEditor('notes', id, false); else newNote(); }
  else if (kind === 'shop') shopForm(id);
  else if (kind === 'habits') habitForm(id);
  else if (kind === 'money') moneyForm(id);
  else if (kind === 'goals') goalForm(id);
  else if (kind === 'slot') slotForm(Number(id));
}
function moreSheet() {
  return {
    render() {
      const l = cloudItems();
      return '<div class="grab"></div><div class="sh-t">☁️ ' + t('allClouds') + '</div><div class="sub gap">' + t('pinHint') + '</div>' + l.map(c =>
        '<div class="mrow"><button class="mc" type="button" data-sa="mc" data-v="' + c.k + ':' + esc(c.id) + '"><span>' + c.ic + '</span><span class="grow">' + esc(c.tx) + '</span><small>' + esc(c.sub) + '</small></button>' +
        (c.k === 'mt' ? '' : '<button class="mini pinb' + (c.hp ? ' on' : '') + '" type="button" data-sa="pin" data-v="' + c.k + ':' + esc(c.id) + '" aria-label="' + esc(t('pinCloud')) + '">📌</button>') + '</div>').join('') +
        '<div class="row sh-b"><button class="btn ghost" type="button" data-sa="close">' + t('closeB') + '</button></div>';
    },
    act(a, el) {
      if (a === 'close') popSheet();
      else if (a === 'pin') {
        const v = el.dataset.v, i = v.indexOf(':'), it = findItem(v.slice(0, i), v.slice(i + 1));
        if (it) {
          if (!it.hp && cloudItems().filter(c => c.hp).length >= 6) { toast(t('pinMax')); return; }
          it.hp = !it.hp; save(); refresh(true); repaint();
        }
      } else if (a === 'mc') {
        const v = el.dataset.v;
        const i = v.indexOf(':');
        const k = v.slice(0, i);
        if (k === 'mt') { popSheet(); pick(4); }
        else swapSheet(itemSheet(k, v.slice(i + 1)));
      }
    }
  };
}


/* ================= جستجوی سراسری و برچسب‌ها ================= */
const TAG_RE = /#[^\s#.,،؛;:!؟?()\[\]{}"'«»]+/g;
function sNorm(x) { return toEn(String(x == null ? '' : x)).toLowerCase().replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/‌/g, ' '); }
function searchTexts() {
  const r = [];
  S.tasks.forEach(x => r.push({ k: 'tasks', id: x.id, ic: '✅', tx: x.title, hay: x.title + ' ' + x.subs.map(q => q.t).join(' '), sub: x.done ? t('tabDone') : (x.due ? fmtDue(x.due) : '') }));
  S.notes.forEach(x => r.push({ k: 'notes', id: x.id, ic: '📝', tx: noteTitle(x), hay: x.title + ' ' + x.text, sub: String(x.text).replace(/\s+/g, ' ').trim().slice(0, 70) }));
  S.shop.forEach(x => r.push({ k: 'shop', id: x.id, ic: '🛒', tx: x.text, hay: x.text, sub: x.price ? nf(x.price, true) + ' ' + t('cur') : '' }));
  S.habits.forEach(x => r.push({ k: 'habits', id: x.id, ic: '🔥', tx: x.name, hay: x.name, sub: '' }));
  S.goals.forEach(x => r.push({ k: 'goals', id: x.id, ic: x.icon || '🎯', tx: x.title, hay: x.title, sub: '' }));
  return r;
}
function allTags() {
  const m = {};
  searchTexts().forEach(r => (r.hay.match(TAG_RE) || []).forEach(g => { const k = g.toLowerCase(); m[k] = (m[k] || 0) + 1; }));
  return Object.keys(m).sort((a, b) => m[b] - m[a]).slice(0, 24);
}
function searchResults(q) {
  const n = sNorm(q).trim();
  if (!n) return [];
  return searchTexts().filter(r => sNorm(r.hay).indexOf(n) > -1).slice(0, 60);
}
function searchSheet() {
  const resHtml = q => {
    const list = searchResults(q);
    if (!q.trim()) return '<div class="sub gap">' + t('srchHint') + '</div>';
    if (!list.length) return empty(t('srchNone'));
    return list.map(r => '<button class="sub-row srow-b" type="button" data-sa="go" data-v="' + esc(r.k + ':' + r.id) + '">' +
      '<span class="si">' + r.ic + '</span><div class="grow"><div class="ttl">' + esc(r.tx) + '</div><div class="sub">' + t('sec_' + r.k) + (r.sub ? ' · ' + esc(r.sub) : '') + '</div></div></button>').join('');
  };
  return {
    render() {
      const tags = allTags();
      return '<div class="grab"></div><div class="sh-t">🔎 ' + t('searchB') + '</div>' +
        '<input id="gq" class="inp" type="search" placeholder="' + esc(t('srchPh')) + '" autocomplete="off">' +
        (tags.length ? '<div class="lbl">' + t('srchTags') + '</div><div class="chips">' + tags.map(g =>
          '<button class="chip" type="button" data-sa="tag" data-v="' + esc(g) + '">' + esc(g) + '</button>').join('') + '</div>' : '') +
        '<div id="gres">' + resHtml('') + '</div>' +
        '<div class="row sh-b"><button class="btn ghost" type="button" data-sa="close">' + t('closeB') + '</button></div>';
    },
    mount() { setTimeout(() => { const e = $('gq'); if (e) e.focus(); }, 320); },
    input(e) { if (e.target.id === 'gq') { const r = $('gres'); if (r) r.innerHTML = resHtml(e.target.value); } },
    act(a, el) {
      if (a === 'close') popSheet();
      else if (a === 'tag') { const i = $('gq'); if (i) { i.value = el.dataset.v; const r = $('gres'); if (r) r.innerHTML = resHtml(i.value); } }
      else if (a === 'go') { const v = el.dataset.v, i = v.indexOf(':'); swapSheet(itemSheet(v.slice(0, i), v.slice(i + 1))); }
    }
  };
}


/* ================= انتخاب واحد پول ================= */
function currencySheet() {
  const rows = q => {
    const n = sNorm(q).trim();
    return CURRENCIES.filter(c => !n || sNorm(c.fa + ' ' + c.en + ' ' + c.c + ' ' + c.s).indexOf(n) > -1).map(c =>
      '<button class="mrow' + (c.c === S.set.cur ? ' sel' : '') + '" type="button" data-sa="pick" data-v="' + c.c + '"><span class="cs">' + esc(c.s) + '</span>' +
      '<span class="grow">' + esc(LANG === 'en' ? c.en : c.fa) + '</span><small>' + c.c + '</small></button>').join('') || empty(t('srchNone'));
  };
  return {
    render() {
      return '<div class="grab"></div><div class="sh-t">💱 ' + t('curTitle') + '</div>' +
        '<input id="cq" class="inp" type="search" placeholder="' + esc(t('curSearch')) + '" autocomplete="off">' +
        '<div class="sub gap">' + t('curNote') + '</div><div id="cres">' + rows('') + '</div>' +
        '<div class="row sh-b"><button class="btn ghost" type="button" data-sa="close">' + t('closeB') + '</button></div>';
    },
    mount() { setTimeout(() => { const e = $('cq'); if (e) e.focus(); }, 320); },
    input(e) { if (e.target.id === 'cq') { const r = $('cres'); if (r) r.innerHTML = rows(e.target.value); } },
    act(a, el) {
      if (a === 'close') popSheet();
      else if (a === 'pick') { S.set.cur = el.dataset.v; save(); popSheet(); refresh(true); toast(t('curSet', curLabel())); }
    }
  };
}

/* ================= خلاصهٔ امروز ================= */
function todayInfo() {
  const now = Date.now(), today = dayKey();
  const late = S.tasks.filter(x => !x.done && x.due && x.due < now);
  const soon = S.tasks.filter(x => !x.done && x.due && x.due >= now && dayKey(new Date(x.due)) === today);
  const hOpen = S.habits.filter(h => habOn(h) && h.days.indexOf(today) < 0);
  return {
    late: late, soon: soon, hOpen: hOpen, hAll: S.habits.filter(h => habOn(h)).length,
    done: S.log.filter(e => e.k === 't' && e.d === today).length,
    spent: S.money.filter(m => m.d === today).reduce((a, m) => a + m.a, 0),
    pomo: S.log.filter(e => e.k === 'p' && e.d === today).length,
    pending: late.length + soon.length + hOpen.length
  };
}
function summarySheet() {
  return {
    render() {
      const I = todayInfo();
      const row = (ic, label, v, cls) => '<div class="sub-row"><span class="si">' + ic + '</span><div class="grow"><div class="ttl">' + label + '</div></div><b class="' + (cls || '') + '">' + v + '</b></div>';
      let h = '<div class="grab"></div><div class="sh-t">📋 ' + t('sumTitle') + '</div>';
      if (!I.pending && !I.done && !I.spent && !I.pomo) h += empty(t('sumNothing'));
      else {
        if (!I.pending && I.done) h += '<div class="warn ok">' + t('sumAllDone') + '</div>';
        h += row('⏰', t('sumLate'), nf(I.late.length), I.late.length ? 'bad' : '') +
          row('✅', t('sumTasks'), nf(I.soon.length)) +
          row('✔', t('sumDone'), nf(I.done)) +
          (I.hAll ? row('🔥', t('sumHabits'), nf(I.hAll - I.hOpen.length) + ' / ' + nf(I.hAll)) : '') +
          row('🍅', t('sumFocus'), nf(I.pomo)) +
          row('💰', t('sumSpent'), nf(I.spent, true) + ' ' + t('cur'));
        const tk = I.late.concat(I.soon).slice(0, 6);
        if (tk.length) h += '<div class="lbl gap">' + t('sumNext') + '</div>' + tk.map(x =>
          '<button class="sub-row srow-b" type="button" data-sa="go" data-v="tasks:' + esc(x.id) + '"><div class="grow"><div class="ttl">' + esc(x.title) + '</div><div class="sub">' + fmtDue(x.due) + ' · ' + remText(x.due - Date.now()) + '</div></div></button>').join('');
        if (I.hOpen.length) h += '<div class="lbl gap">' + t('sumHabitsLeft') + '</div><div class="chips">' + I.hOpen.slice(0, 8).map(x =>
          '<button class="chip" type="button" data-sa="go" data-v="habits:' + esc(x.id) + '">' + esc(x.name) + '</button>').join('') + '</div>';
      }
      return h + '<div class="row sh-b"><button class="btn ghost" type="button" data-sa="close">' + t('closeB') + '</button></div>';
    },
    act(a, el) {
      if (a === 'close') popSheet();
      else if (a === 'go') { const v = el.dataset.v, i = v.indexOf(':'); swapSheet(itemSheet(v.slice(0, i), v.slice(i + 1))); }
    }
  };
}

/* ---------- شیت جزئیات و گزینه‌ها (نگه‌داشتن یا زدن روی مورد) ---------- */
let undoT = 0;
function showUndo(msg, fn) {
  let el = $('undo');
  if (!el) {
    el = document.createElement('div');
    el.id = 'undo'; el.className = 'undo';
    el.innerHTML = '<span></span><button type="button"></button>';
    document.body.appendChild(el);
    el.addEventListener('click', e => {
      if (!e.target.closest('button')) return;
      const f = el._fn; el._fn = null;
      el.classList.remove('show'); clearTimeout(undoT);
      if (f) f();
    });
  }
  el.firstChild.textContent = msg;
  el.lastChild.textContent = t('restoreB');
  el._fn = fn;
  el.classList.add('show');
  clearTimeout(undoT);
  undoT = setTimeout(() => { el.classList.remove('show'); el._fn = null; }, 6500);
}
function restoreBackup(text) {
  try {
    const o = JSON.parse(text);
    if (!o || typeof o !== 'object') throw new Error('bad');
    const keepDiary = o.diary === undefined ? S.diary : null;
    const keepKey = keepDiary ? dKey : null;
    S = norm(o);
    if (keepDiary) { S.diary = keepDiary; dKey = keepKey; }
    else { dKey = null; dUnlocked = false; ed = null; Object.keys(encCache).forEach(k => { delete encCache[k]; }); }
    save(); applyTheme(); applyLang(); refresh(false); toast(t('bkLoaded'));
  } catch (x) { toast(t('bkBad')); }
}
function delItem(kind, id) {
  let back;
  if (kind === 'slot') {
    const i = Number(id), old = S.slots[i];
    S.slots[i] = 0;
    back = () => { S.slots[i] = old; };
  } else {
    const key = kind === 'qt' ? 'qtimers' : kind;
    const arr = S[key], i = arr.findIndex(x => x.id === id), it = arr[i];
    S[key] = arr.filter(x => x.id !== id);
    back = () => { if (it && !S[key].some(x => x.id === it.id)) S[key].splice(Math.min(i, S[key].length), 0, it); };
  }
  save(); refresh(true);
  showUndo(t('deleted'), () => { back(); save(); refresh(true); toast(t('restored')); });
}
function detail(kind, x) {
  const now = Date.now();
  const cl = CLOUDY.indexOf(kind) > -1 ? [['cloud', t(x.cloud ? 'removeCloud' : 'makeCloud')]] : [];
  const tail = [['edit', t('edit')], ['del', t('del'), 'danger'], ['close', t('closeB')]];
  let ti = '', body = '', btns = [];
  switch (kind) {
    case 'tasks':
      ti = '✅ ' + esc(x.title);
      body = '<div class="sub gap">' + (x.due ? fmtDue(x.due) + (x.done ? '' : ' · ' + remText(x.due - now)) : t('noSchedule')) +
        ' · ' + t('priLabel', t('pri' + (x.pri == null ? 1 : x.pri))) + (x.rep ? ' · 🔁' : '') + '</div>';
      if (x.subs.length) body += '<div class="bar"><i style="width:' + subPct(x) + '%"></i></div>' + subsHtml(x.subs, 'data-sa="subtick"', s => s.d);
      btns = [['done', t(x.done ? 'undo' : 'markDone')]].concat(cl, tail);
      break;
    case 'notes':
      ti = '📝 ' + esc(noteTitle(x));
      body = '<div class="reader">' + esc(x.text) + '</div><div class="sub gap">' + fmtDue(x.t || now) + '</div>';
      btns = [['edit', t('openEdit')], ['copy', t('copyText')], ['pin', t(x.pin ? 'unpin' : 'pin')]].concat(cl, [['del', t('del'), 'danger'], ['close', t('closeB')]]);
      break;
    case 'shop': {
      const pc = x.price > 0 ? Math.min(100, Math.round(x.saved / x.price * 100)) : 0;
      const wl = whenLabel(x);
      ti = '🛒 ' + esc(x.text);
      body = '<div class="sub gap">' + (x.price ? nf(x.price, true) + ' ' + t('cur') : t('noPrice')) + (wl ? ' · ⏳ ' + esc(wl) : '') + '</div>';
      if (x.price > 0) body += '<div class="bar' + (pc >= 100 ? ' ok' : '') + '"><i style="width:' + pc + '%"></i></div><div class="sub gap">' + t('of', nf(x.saved, true), nf(x.price, true)) + ' (' + nf(pc) + '%)</div>';
      btns = [['sav', t('savingsBtn')], ['tick', t(x.done ? 'unpick' : 'pick')]].concat(cl, tail);
      break;
    }
    case 'habits':
      ti = '🔥 ' + esc(x.name);
      body = '<div class="sub gap">' + t('streakDays', nf(habStreak(x))) + ' · ' + t('subCount', nf(x.subs.length)) + '</div>';
      btns = [['htoday', t('markToday')]].concat(cl, tail);
      break;
    case 'money': {
      const ci = Number.isInteger(x.c) ? x.c : 5;
      ti = '💰 ' + nf(x.a, true) + ' ' + t('cur');
      body = '<div class="sub gap">' + CAT_ICONS[ci] + ' ' + t('cat' + ci) + (x.t ? ' · ' + esc(x.t) : '') + ' · ' + dayLabel(x.d) + '</div>';
      btns = tail;
      break;
    }
    case 'goals': {
      const p = Math.round(pctGoal(x));
      ti = esc(x.icon || '🎯') + ' ' + esc(x.title);
      body = '<div class="bar"><i style="width:' + p + '%"></i></div><div class="sub gap">' + t('of', nd(x.cur), nd(x.target)) + ' ' + esc(x.unit) + ' (' + nf(p) + '%)' + (goalStatus(x) ? '<br>' + goalStatus(x) : '') + '</div>';
      btns = [['inc', '＋ ' + nd(x.step)], ['dec', '－ ' + nd(x.step)]].concat(cl, tail);
      break;
    }
    case 'slot':
      ti = t('customTimer');
      body = '<div class="sub gap">' + durText(x.sec) + '</div>';
      btns = [['use', t('useTimer')]].concat(tail);
      break;
    case 'qt':
      ti = '⏱️ ' + esc(x.label || tcName(x.total));
      body = '<div class="sub gap">' + t('timeLeft') + ': <b>' + fmtClock(Math.ceil((x.end - now) / 1000)) + '</b></div>';
      btns = [['qadd', t('add5')], ['del', t('cancelTimer'), 'danger'], ['close', t('closeB')]];
      break;
  }
  return { ti: ti, body: body, btns: btns };
}
function itemSheet(kind, id) {
  return {
    render() {
      const x = findItem(kind, id);
      if (!x) return '<div class="grab"></div><div class="empty">' + t('notFound') + '</div>';
      const dt = detail(kind, x);
      return '<div class="grab"></div><div class="sh-t">' + dt.ti + '</div>' + dt.body +
        '<div class="opts">' + dt.btns.map((b, i) =>
          '<button class="btn ' + (b[2] || (i === 0 ? '' : 'ghost')) + '" type="button" data-sa="' + b[0] + '">' + b[1] + '</button>').join('') + '</div>';
    },
    act(a, el) {
      const x = findItem(kind, id);
      if (!x) { popSheet(); return; }
      switch (a) {
        case 'close': popSheet(); return;
        case 'edit': popSheet(); openForm(kind, id); return;
        case 'del': delItem(kind, id); popSheet(); return;
        case 'cloud': x.cloud = !x.cloud; save(); refresh(true); repaint(); return;
        case 'done': toggleTask(x); save(); refresh(true); repaint(); return;
        case 'htoday': toggleHabitToday(x); save(); refresh(true); repaint(); return;
        case 'subtick': {
          const s = x.subs.find(i => i.id === el.dataset.sid);
          if (s) { s.d = !s.d; taskSync(x); save(); refresh(true); repaint(); }
          return;
        }
        case 'copy': toast(copyText(x.text) ? t('copied') : t('copyFail')); return;
        case 'pin': x.pin = !x.pin; save(); refresh(true); repaint(); return;
        case 'tick': x.done = !x.done; save(); refresh(true); repaint(); return;
        case 'sav': pushSheet(savingsSheet(id)); return;
        case 'inc': goalStep(x, 1); refresh(true); repaint(); return;
        case 'dec': goalStep(x, -1); refresh(true); repaint(); return;
        case 'use': popSheet(); setTimerSec(x.sec); return;
        case 'qadd': x.end += 5 * 60000; x.total += 300; save(); refresh(true); repaint(); return;
      }
    }
  };
}

/* ================= عملیات‌ها ================= */
function act(a, id, el) {
  switch (a) {
    case 'add': openForm(id, null); break;
    case 'quick': openQuick(); break;
    case 'more-clouds': pushSheet(moreSheet()); break;
    case 'stat-open': pushSheet(statSheet(id)); break;

    /* کارها */
    case 'tfilter': tFilter = id; if (id === 'plan') tPlanOff = 0; refresh(true); if (id === 'plan') tlScroll(); break;
    case 'tplan': tPlanOff = id === '0' ? 0 : tPlanOff + Number(id); refresh(true); if (tPlanOff === 0) tlScroll(); break;
    case 't-toggle': {
      { const tk0 = S.tasks.find(x => x.id === id); if (tk0 && taskLocked(tk0)) { toast(t('taskLocked')); break; } }
      popId = id;
      const run = () => { const tk = S.tasks.find(x => x.id === id); if (tk) { toggleTask(tk); save(); refresh(true); } };
      const cw = el.closest ? el.closest('.cw') : null;
      if (cw) { cw.classList.add('poof'); setTimeout(run, 330); } else run();
      break;
    }
    case 't-sub': {
      const tk = S.tasks.find(x => x.id === id);
      if (tk) {
        const s = tk.subs.find(i => i.id === el.dataset.sid);
        if (s) { if (taskLocked(tk)) { toast(t('taskLocked')); break; } s.d = !s.d; taskSync(tk); save(); refresh(true); }
      }
      break;
    }
    case 't-clear': {
      const gone = S.tasks.filter(x => x.done), keep = S.tasks.filter(x => !x.done);
      S.tasks = keep; save(); refresh(true);
      if (gone.length) showUndo(t('deleted'), () => { S.tasks = S.tasks.concat(gone); save(); refresh(true); toast(t('restored')); });
      break;
    }

    /* یادداشت و ویرایشگر */
    case 'n-open': openEditor('notes', id, false); break;
    case 'ne-back': closeEd(true); break;
    case 'ne-pin': { const n = edItem(); if (n) { n.pin = !n.pin; save(); refresh(true); } break; }
    case 'ne-cloud': { const n = edItem(); if (n) { n.cloud = !n.cloud; save(); refresh(true); } break; }
    case 'ne-copy': { const n = edItem(); if (n) toast(copyText((n.title ? n.title + '\n\n' : '') + n.text) ? t('copied') : t('copyFail')); break; }
    case 'ne-del': {
      const n = edItem();
      if (!n) break;
      const kind = ed.kind;
      pushSheet(confirmSheet({
        title: t(kind === 'notes' ? 'delNoteT' : 'dDelT'), msg: t(kind === 'notes' ? 'delNoteMsg' : 'dDelMsg'), ok: t('del'), danger: true,
        cb() {
          if (kind === 'notes') S.notes = S.notes.filter(x => x !== n);
          else S.diary.secs = S.diary.secs.filter(x => x !== n);
          ed = null; clearTimeout(svT); save(); refresh(false); toast(t('deleted'));
        }
      }));
      break;
    }

    /* خرید */
    case 's-toggle': { const x = S.shop.find(i => i.id === id); if (x) { popId = id; x.done = !x.done; if (x.done) x.doneAt = Date.now(); else delete x.doneAt; save(); refresh(true); } break; }
    case 's-sav': if (S.shop.some(i => i.id === id)) pushSheet(savingsSheet(id)); break;
    case 's-copy': {
      const l = S.shop.filter(x => x.done).map(x => '• ' + x.text + (x.price ? ' — ' + nf(x.price, true) + ' ' + t('cur') : ''));
      if (!l.length) { toast(t('nothingSel')); return; }
      toast(copyText(l.join('\n')) ? t('copied') : t('copyFail'));
      break;
    }
    case 's-clear': S.shop = S.shop.filter(x => !x.done); save(); refresh(true); break;

    /* عادت‌ها */
    case 'h-toggle': {
      const h = S.habits.find(i => i.id === id);
      if (h) {
        popId = id;
        const run = () => {
          toggleHabitToday(h);
          save();
          if (current === 'home') {
            const w = $('hbw');
            if (w) w.innerHTML = habitsInner();
            if (h.cloud) refresh(true);
          } else refresh(true);
        };
        const cw = el.closest ? el.closest('.cw') : null;
        if (cw) { cw.classList.add('poof'); setTimeout(run, 330); } else run();
      }
      break;
    }
    case 'h-sub': {
      const h = S.habits.find(i => i.id === id);
      if (h) {
        const k = dayKey();
        const ids = h.sd[k] || (h.sd[k] = []);
        const sid = el.dataset.sid;
        const p = ids.indexOf(sid);
        if (p > -1) ids.splice(p, 1); else ids.push(sid);
        hSync(h, k);
        const keys = Object.keys(h.sd).sort();
        while (keys.length > 60) delete h.sd[keys.shift()];
        save(); refresh(true);
      }
      break;
    }

    /* تایمر */
    case 'tm-set': setTimerMin(Number(el.dataset.min)); break;
    case 'tm-toggle':
      audio();
      if (T.run) { T.left = tmLeft(); T.run = false; }
      else { if (T.left <= 0) T.left = T.total; T.end = Date.now() + T.left * 1000; T.run = true; }
      refresh(true);
      break;
    case 'tm-reset': T.run = false; T.left = T.total; refresh(false); break;
    case 'slot': {
      const i = Number(id);
      if (S.slots[i]) setTimerSec(S.slots[i]); else slotForm(i);
      break;
    }

    /* هدف‌ها */
    case 'g-inc': case 'g-dec': {
      const g = S.goals.find(x => x.id === id);
      if (g) { goalStep(g, a === 'g-inc' ? 1 : -1); refresh(true); }
      break;
    }

    /* دفتر خاطرات */
    case 'summary': pushSheet(summarySheet()); break;
    case 'mods-open': openSection('mods'); break;
    case 'mod-toggle': modToggle(id); break;
    case 'diary-open': openSection('diary'); break;
    case 'd-setup': {
      const p1 = val('dp1'), p2 = val('dp2');
      if (p1.length < 4) { toast(t('dPwShort')); return; }
      if (p1 !== p2) { toast(t('dMismatch')); return; }
      const salt = uid();
      S.diary.salt = salt;
      S.diary.hash = hashPw(p1, salt);
      dKey = deriveDiaryKey(p1, salt);
      save();
      dUnlocked = true;
      refresh(false);
      toast(t('dCreated'));
      break;
    }
    case 'd-unlock': {
      const pw = val('dp');
      if (pw && hashPw(pw, S.diary.salt) === S.diary.hash) { unlockDiary(pw); refresh(false); }
      else {
        toast(t('dWrong'));
        const i = $('dp');
        if (i) { i.value = ''; i.classList.remove('shake'); void i.offsetWidth; i.classList.add('shake'); }
      }
      break;
    }
    case 'd-forgot':
      pushSheet(confirmSheet({
        title: t('dForgotTitle'), msg: t('dForgotMsg'), ok: t('dForgotYes'), danger: true,
        cb() { S.diary = { hash: '', salt: '', secs: [] }; dUnlocked = false; dKey = null; ed = null; save(); refresh(false); toast(t('dErased')); }
      }));
      break;
    case 'd-new': {
      const n = { id: uid(), title: '', text: '', t: Date.now() };
      S.diary.secs.push(n);
      save();
      openEditor('diary', n.id, true);
      break;
    }
    case 'd-open': openEditor('diary', id, false); break;
    case 'd-lock': lockDiary(); refresh(false); break;
    case 'd-chpw': pwForm(); break;

    /* تنظیمات */
    case 'lang':
      S.set.lang = id === 'en' ? 'en' : 'fa';
      save(); applyLang(); refresh(false);
      break;
    case 'cur-open': pushSheet(currencySheet()); break;
    case 'fs-set': S.set.fs = Number(id); save(); applyFont(); refresh(true); break;
    case 'ff-set': S.set.ff = id === 'system' ? 'system' : 'nimbo'; save(); applyFont(); refresh(true); break;
    case 'theme-set': S.set.theme = id; save(); applyTheme(); refresh(true); break;
    case 'accent': S.set.accent = Number(id); save(); applyTheme(); refresh(true); break;
    case 'tog':
      if (id === 'sound') { S.set.sound = !S.set.sound; if (S.set.sound) beep(); }
      else { S.set.vib = !S.set.vib; buzz(40); }
      save(); refresh(true);
      break;
    case 'budget-save': {
      const n = Number(toEn(val('set-budget'))) || 0;
      S.set.budget = n > 0 ? n : 0;
      save(); toast(t('budgetSaved'));
      break;
    }
    case 'bk-file': {
      try {
        const blob = new Blob([ser()], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = 'nimbo-backup-' + dayKey() + '.json';
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 5000);
        toast(t('bkFileOk'));
      } catch (x) { toast(t('bkManual')); }
      break;
    }
    case 'bk-pick': { const f = $('bkf'); if (f) f.click(); break; }
    case 'bk-make': {
      const e = $('bk');
      e.value = ser();
      const ok = copyText(e.value);
      e.focus(); e.select();
      toast(t(ok ? 'bkOk' : 'bkManual'));
      break;
    }
    case 'bk-load': restoreBackup(val('bk')); break;
    case 'reset':
      pushSheet(confirmSheet({
        title: t('resetTitle'), msg: t('resetMsg'), ok: t('resetYes'), danger: true,
        cb() {
          S = def(); dUnlocked = false; dKey = null; ed = null; MODS_ON.slice().forEach(modStop); MODS_ON = []; modsSave(); save(); applyTheme(); applyLang(); refresh(false); toast(t('resetDone'));
        }
      }));
      break;
  }
}

/* ---------- رویدادهای صفحه ---------- */
let lp = null, lpFired = false;
function lpCancel() { if (lp) { clearTimeout(lp.t); lp = null; } }
view.addEventListener('pointerdown', e => {
  const el = e.target.closest('[data-lp]');
  if (!el || e.target.closest('input,textarea,select')) return;
  lpCancel();
  lp = {
    x: e.clientX, y: e.clientY,
    t: setTimeout(() => {
      const v = el.getAttribute('data-lp');
      lp = null; lpFired = true;
      setTimeout(() => { lpFired = false; }, 800);
      buzz(25);
      const i = v.indexOf(':');
      pushSheet(itemSheet(v.slice(0, i), v.slice(i + 1)));
    }, 520)
  };
});
view.addEventListener('pointermove', e => {
  if (lp && (Math.abs(e.clientX - lp.x) > 10 || Math.abs(e.clientY - lp.y) > 10)) lpCancel();
});
['pointerup', 'pointercancel', 'pointerleave'].forEach(n => view.addEventListener(n, lpCancel));
view.addEventListener('contextmenu', e => e.preventDefault());

view.addEventListener('click', e => {
  if (lpFired) { lpFired = false; return; }
  const el = e.target.closest('[data-act]');
  if (el) { act(el.dataset.act, el.dataset.id, el); return; }
  const g = e.target.closest('[data-go]');
  if (g) { pick(Number(g.dataset.go)); return; }
  const o = e.target.closest('[data-open]');
  if (o) {
    const v = o.getAttribute('data-open');
    const i = v.indexOf(':');
    pushSheet(itemSheet(v.slice(0, i), v.slice(i + 1)));
  }
});
view.addEventListener('keydown', e => {
  if (e.key === 'Enter' && e.target.dataset && e.target.dataset.enter) {
    e.preventDefault();
    const b = $(e.target.dataset.enter);
    if (b) b.click();
  }
});
view.addEventListener('input', e => {
  const tg = e.target, id = tg.id;
  if (id === 'n-q') { filterNotes(); return; }
  if (id === 'mod-q') { filterMods(); return; }
  if (id === 'ne-title' || id === 'ne-text') {
    const n = edItem();
    if (!n) return;
    if (id === 'ne-title') n.title = tg.value;
    else { n.text = tg.value; autoGrow(); }
    n.t = Date.now();
    saveSoon();
    return;
  }
  if (tg.dataset && tg.dataset.nf) numFmt(tg, tg.dataset.nf === 'd');
});
document.addEventListener('change', e => {
  const f = e.target;
  if (!f || f.id !== 'bkf' || !f.files || !f.files[0]) return;
  const rd = new FileReader();
  rd.onload = () => { restoreBackup(String(rd.result || '')); };
  rd.onerror = () => { toast(t('bkBad')); };
  rd.readAsText(f.files[0]);
  f.value = '';
});
$('homeBtn').addEventListener('click', () => openSection('home'));
$('srchBtn').addEventListener('click', () => pushSheet(searchSheet()));
$('setBtn').addEventListener('click', () => openSection('settings'));

/* ================= چرخ ================= */
const items = [];
SECTIONS.forEach((s, i) => {
  const slot = document.createElement('div');
  slot.className = 'slot';
  slot.style.setProperty('--i', i);
  const b = document.createElement('button');
  b.type = 'button';
  b.className = 'it';
  b.setAttribute('data-i', i);
  b.innerHTML = '<span class="ii"><span class="ic">' + iconHtml(s) + '</span><span class="lb"></span></span>';
  slot.appendChild(b);
  ring.appendChild(slot);
  items.push(b);
});

let rot = 0, raf = 0;
function setRot(r) {
  rot = r;
  ring.style.transform = 'rotate(' + r + 'deg)';
  for (let i = 0; i < N; i++) items[i].style.transform = 'rotate(' + (-(i * STEP + r)) + 'deg)';
}
function idxOf(tg) { return (((Math.round(-tg / STEP)) % N) + N) % N; }
function targetFor(i) {
  const k = Math.round((rot + i * STEP) / 360);
  return -i * STEP + 360 * k;
}
function stopAnim() { if (raf) { cancelAnimationFrame(raf); raf = 0; } }
function animateTo(target, dur) {
  stopAnim();
  const from = rot, delta = target - from;
  if (Math.abs(delta) < 0.01) { setRot(target); return; }
  const t0 = performance.now();
  function step(now) {
    const p = (now - t0) / dur;
    if (p >= 1) { setRot(target); raf = 0; return; }
    setRot(from + delta * (1 - Math.pow(1 - p, 4)));
    raf = requestAnimationFrame(step);
  }
  raf = requestAnimationFrame(step);
}
function pick(i) {
  animateTo(targetFor(i), 1000);
  buzz(8);
  openSection(SECTIONS[i].id);
}

let drag = null, justDragged = false;
function ang(e, c) { return Math.atan2(e.clientY - c.y, e.clientX - c.x) * 180 / Math.PI; }

wheel.addEventListener('pointerdown', e => {
  if (drag || document.body.classList.contains('wheel-closed')) return;
  stopAnim();
  const r = wheel.getBoundingClientRect();
  const c = { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  drag = { id: e.pointerId, c: c, last: ang(e, c), acc: 0, r0: rot, moved: false, s: [{ t: performance.now(), r: rot }] };
});
window.addEventListener('pointermove', e => {
  if (!drag || e.pointerId !== drag.id) return;
  const a = ang(e, drag.c);
  let d = a - drag.last;
  if (d > 180) d -= 360;
  if (d < -180) d += 360;
  drag.last = a;
  drag.acc += d;
  if (Math.abs(drag.acc) > 6) drag.moved = true;
  if (drag.moved) {
    setRot(drag.r0 + drag.acc);
    drag.s.push({ t: performance.now(), r: rot });
    if (drag.s.length > 6) drag.s.shift();
  }
  e.preventDefault();
}, { passive: false });
function endDrag(e) {
  if (!drag || (e && e.pointerId !== drag.id)) return;
  const dg = drag;
  drag = null;
  if (!dg.moved) return;
  justDragged = true;
  setTimeout(() => { justDragged = false; }, 350);
  const now = performance.now();
  let v = 0;
  for (let i = 0; i < dg.s.length; i++) {
    const dt = now - dg.s[i].t;
    if (dt <= 120) { v = (rot - dg.s[i].r) / Math.max(16, dt); break; }
  }
  v = Math.max(-0.8, Math.min(0.8, v));
  let target = rot + v * 110;
  target = Math.max(rot - 2 * STEP, Math.min(rot + 2 * STEP, target));
  target = Math.round(target / STEP) * STEP;
  animateTo(target, Math.min(1500, 750 + Math.abs(target - rot) * 3.4));
  buzz(8);
  openSection(SECTIONS[idxOf(target)].id);
}
window.addEventListener('pointerup', endDrag);
window.addEventListener('pointercancel', endDrag);
wheel.addEventListener('contextmenu', e => e.preventDefault());

ring.addEventListener('click', e => {
  if (justDragged || document.body.classList.contains('wheel-closed')) return;
  const b = e.target.closest('.it');
  if (!b) return;
  pick(Number(b.getAttribute('data-i')));
});

function setWheel(open, persist) {
  document.body.classList.toggle('wheel-closed', !open);
  document.body.classList.toggle('wheel-open', open);
  if (persist) { S.set.wheel = open; save(); }
  if (current === 'home') layoutClouds();
}
$('hub').addEventListener('click', () => {
  setWheel(document.body.classList.contains('wheel-closed'), true);
});
window.addEventListener('resize', () => { if (current === 'home') layoutClouds(); });

window.addEventListener('popstate', e => {
  if (ignorePop > 0) { ignorePop--; return; }
  if (stack.length) { shHist = false; stack.length = 0; paintSheet(false); return; }
  const id = (e.state && e.state.s) || 'home';
  const i = SECTIONS.findIndex(s => s.id === id);
  if (i > -1) animateTo(targetFor(i), 1000);
  openSection(id, true);
});

/* ================= یادآور و حلقهٔ زمان ================= */
function checkReminders() {
  const now = Date.now();
  let changed = false;
  const due = S.tasks.filter(x => !x.done && x.due && !x.notified && x.due <= now);
  if (due.length) {
    due.forEach(x => { x.notified = true; });
    changed = true;
    toast(due.length === 1 ? t('dueOne', due[0].title) : t('dueMany', nf(due.length)));
    alarm();
  }
  const sh = S.shop.filter(x => {
    if (x.done || x.wn || !(x.wd > 0) || ['week', 'month', 'date'].indexOf(x.when) < 0) return false;
    const r = new Date(x.wd); r.setHours(9, 0, 0, 0);
    return r.getTime() <= now;
  });
  if (sh.length) {
    sh.forEach(x => { x.wn = true; });
    changed = true;
    toast(t('buyTime', sh[0].text) + (sh.length > 1 ? t('andMore', nf(sh.length - 1)) : ''));
    alarm();
  }
  if (changed) {
    save();
    if (current === 'tasks' || current === 'home' || current === 'shop') refresh(true);
  }
}
let slowAt = Date.now();
setInterval(() => {
  const c = $('clock');
  if (c) { const tx = hm(Date.now()); if (c.textContent !== tx) c.textContent = tx; }
  tickTimer();
  tickQTimers();
  const now = Date.now();
  if (now - slowAt >= 15000) {
    slowAt = now;
    checkReminders();
    if (S.set.theme === 'auto') applyTheme();
    if (current === 'home') { paintSky(); tickClouds(); }
  }
}, 500);
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    clearTimeout(svT);
    save();
    if (dUnlocked) { lockDiary(); if (current === 'diary') refresh(false); }
    return;
  }
  checkReminders();
  tickTimer();
  tickQTimers();
  if (S.set.theme === 'auto') applyTheme();
  if (current === 'home') { paintSky(); tickClouds(); layoutClouds(); }
});

/* ================= متن‌ها ================= */
const D = {
fa: {
  appTitle: 'نیمبو', home: 'صفحه اصلی', settings: 'تنظیمات', menu: 'منو',
  sec_tasks: 'کارها', sec_notes: 'یادداشت', sec_shop: 'خرید', sec_habits: 'عادت‌ها',
  sec_timer: 'تایمر', sec_money: 'هزینه', sec_goals: 'هدف‌ها', sec_stats: 'آمار',
  today: 'امروز', tomorrow: 'فردا', u_day: 'روز', u_hour: 'ساعت', u_min: 'دقیقه', and: ' و ',
  left: 'مانده', overdue: 'گذشته', now: 'همین الان', cur: 'تومان',
  skyEmpty: 'آسمان خالی است ☀️', skyEmptySub: 'با پرنده چیزی اضافه کن تا ابر بشود',
  pinHint: 'حداکثر ۶ ابر را می‌توانی 📌 سنجاق کنی تا همیشه روی صفحهٔ اصلی بمانند. کارهایی که کمتر از ۱۲ ساعت به موعدشان مانده خودکار ابر می‌شوند، حتی بدون سنجاق.', pinMax: 'حداکثر ۶ ابر را می‌شود سنجاق کرد',
  fontSec: 'نوشته‌ها', fontSize: 'اندازهٔ نوشته‌ها', fontSizeSub: 'همهٔ متن‌های برنامه (به‌جز برچسب‌های ریز چرخ و ابرها)', fontPrev: 'نمونه: امروز چه کارهایی داری؟ Hello Nimbo 123',
  fs0: 'کوچک', fs1: 'معمولی', fs2: 'بزرگ', fs3: 'خیلی بزرگ', fs4: 'عظیم',
  fontFam: 'فونت', fontFamSub: 'نیمبو: انگلیسی با فونت اختصاصی برنامه. فارسی با Vazirmatn اگر روی گوشی باشد.', ffNimbo: 'نیمبو', ffSystem: 'سیستم',
  curTitle: 'واحد پول', curSearch: 'جستجوی واحد پول… (دلار، یورو، USD، تتر)', curNote: 'فقط نام و نماد واحد در برنامه عوض می‌شود؛ مبلغ‌ها تبدیل نمی‌شوند.', curSet: 'واحد پول: {0}', change: 'تغییر',
  moreClouds: '+{0} ابر دیگر', birdLabel: 'افزودن سریع', allClouds: 'همهٔ ابرها',
  newTask: '➕ کار جدید', tabPlan: '🗓️ روز', tlNoTime: 'بدون ساعت', tlDragHint: 'بکش روی ساعت', tlEmpty: 'برای این روز کاری با ساعت نیست. با ➕ کار جدید بساز؛ بعد با ⠿ بکش و جابه‌جا کن.', tabOpen: 'باز', tabDone: 'انجام‌شده', noDone: 'هنوز کاری انجام نداده‌ای',
  noTasks: 'کاری اینجا نیست 🎉', noSchedule: 'بدون زمان‌بندی', clearDone: '🧹 پاک کردن انجام‌شده‌ها',
  newNote: '➕ یادداشت جدید', noNotes: 'هنوز یادداشتی نداری', searchNotes: '🔎 جستجو در یادداشت‌ها',
  noteTitlePh: 'عنوان یادداشت', noteBodyPh: 'اینجا بنویس...', untitled: 'بدون عنوان', back: 'بازگشت',
  pinS: 'سنجاق', unpinS: 'برداشتن سنجاق', savedAt: 'آخرین ویرایش: {0}',
  delNoteT: '🗑 حذف یادداشت؟', delNoteMsg: 'این یادداشت برای همیشه پاک می‌شود.', openEdit: '✏️ باز کردن و ویرایش',
  newItem: '➕ مورد جدید', noShop: 'لیست خرید خالی است', shopTotal: 'جمع قیمت‌ها: {0} {cur} · پس‌انداز: {1}',
  noPrice: 'بدون قیمت', funded: '✅ پولش جمع شد!', of: '{0} از {1}', savingsBtn: '💰 پس‌انداز',
  copySel: '📋 کپی انتخاب‌شده‌ها', clearSel: '🧹 پاک کردن انتخاب‌شده‌ها', nothingSel: 'چیزی انتخاب نشده',
  newHabit: '➕ عادت جدید', noHabits: 'هنوز عادتی اضافه نکرده‌ای', streakDays: '🔥 {0} روز پشت‌سرهم', todayPct: ' · امروز {0}٪',
  markToday: '✓ ثبت امروز',
  focus25: '🍅 تمرکز ۲۵', rest5: '☕ استراحت ۵', rest15: '🛋️ استراحت ۱۵', start: '▶️ شروع', pause: '⏸ توقف',
  restart: '↺ از اول', minU: 'دقیقه', slotNew: 'تایم', timerDone: '⏰ تایمر تمام شد!',
  timerHelp: '🍅 جلسه‌های تمرکز امروز: {0}<br>دکمه‌های کناری تایم‌های دلخواه تو هستند؛ ＋ را بزن تا بسازی، نگه‌دار تا ویرایش یا حذف کنی.',
  typeTimer: '⏱️ تایمر', fTimerLabel: 'نام تایمر (اختیاری)', timerLabelPh: 'مثلاً: دم‌نوش', fTimerMin: '⏲️ چند دقیقه؟',
  fTimerCustom: 'یا زمان دلخواه (دقیقه)', startTimerCloud: '▶️ شروع تایمر (ابر)', timerStarted: 'تایمر {0} دقیقه‌ای شروع شد ⏱️',
  timerCloud: 'تایمر {0} دقیقه', timerCloudS: 'تایمر {0}', secU: 'ثانیه', fSlotSec: '⏲️ چند ثانیه؟ (۰ تا ۵۹)', fTimerSec: 'ثانیهٔ اضافه (اختیاری)', timerStartedS: 'تایمر {0} شروع شد ⏱️', qtDone: '⏰ تایمر «{0}» تمام شد!', add5: '＋ ۵ دقیقه', cancelTimer: '✕ لغو تایمر', timeLeft: 'زمان باقی‌مانده',
  moneyToday: 'امروز ({cur})', moneyMonth: 'این ماه ({cur})', budgetMonth: '📅 بودجه این ماه',
  overBudget: ' — از بودجه رد شده‌ای!', newSpend: '➕ هزینه جدید', noSpend: 'هنوز هزینه‌ای ثبت نشده',
  newGoal: '➕ هدف جدید', noGoals: 'هنوز هدفی نداری', goalDone: '🎉 تمام شد', goalLate: '⌛ مهلت تمام شده',
  goalDays: '{0} روز مانده · {1}', onTrack: '✅ طبق برنامه', behind: '⚠️ عقب‌تر از برنامه',
  goalReached: '🎉 تبریک! به هدفت رسیدی',
  st_today: '✅ انجام‌شده امروز', st_week: '📆 انجام‌شده این هفته', st_streak: '🔥 بهترین رشتهٔ عادت', st_pomo: '🍅 تمرکز امروز',
  ch_t: '✅ کارهای انجام‌شده', ch_h: '🔥 عادت‌های انجام‌شده', ch_m: '💰 هزینه‌ها', ch_p: '🍅 جلسه‌های تمرکز',
  tapMore: 'ماه و سال ←', rWeek: 'هفته', rMonth: 'ماه', rYear: 'سال', total: 'جمع', history: 'سابقه',
  noEntries: 'چیزی ثبت نشده', delNote: 'حذف از اینجا فقط از آمار پاک می‌کند، نه از بخش‌های دیگر. حذف در بخش‌های دیگر هم آمار را پاک نمی‌کند.',
  entryDeleted: 'از آمار حذف شد', weekTotal: 'جمع هفته: {0} {1}', topCat: 'بیشترین هزینهٔ این ماه: {0} ({1} {2})',
  focusSession: 'جلسهٔ تمرکز',
  language: 'زبان', appearance: 'ظاهر', theme: 'پوسته', thDark: '🌙 تیره', thLight: '☀️ روشن', thAuto: '🌓 خودکار',
  thAutoHint: 'در حالت خودکار، تم با روز و شب عوض می‌شود', accent: 'رنگ اصلی',
  alerts: 'هشدارها', sound: 'صدا', soundSub: 'بوق یادآوری و تایمر', vib: 'لرزش', vibSub: 'لرزش هنگام هشدار',
  budget: 'بودجه', budgetMonthly: 'بودجهٔ ماهانه', budgetSub: 'صفر یعنی بدون بودجه', save: 'ذخیره', budgetSaved: 'بودجه ذخیره شد',
  bkSub: 'همهٔ اطلاعات در یک فایل', bkSave2: 'ذخیره', bkRestore2: 'بازیابی', bkAdv: 'روش متنی (پیشرفته)',
  data: 'اطلاعات', backup: 'پشتیبان‌گیری', backupPh: 'متن پشتیبان اینجا ساخته می‌شود. برای بازیابی، متن را اینجا بچسبان.',
  bkMake: '📤 ساخت و کپی', bkLoad: '📥 بازیابی', bkOk: 'پشتیبان ساخته و کپی شد ✅', bkManual: 'متن را کپی کن و جایی نگه دار',
  bkLoaded: 'اطلاعات بازیابی شد ✅', bkBad: 'متن پشتیبان درست نیست', danger: 'منطقهٔ خطر', eraseAll: '🗑 پاک کردن همه اطلاعات',
  resetTitle: '⚠️ همه‌چیز پاک می‌شود',
  resetMsg: 'همه‌چیز برای همیشه پاک می‌شود: کارها، یادداشت‌ها، لیست خرید، عادت‌ها، هزینه‌ها، هدف‌ها، تایم‌ها، دفتر خاطرات و رمزش، آمار و تنظیمات.\nاین کار قابل برگشت نیست.\n\nاگر مطمئن نیستی، اول یک پشتیبان بگیر.',
  resetYes: 'بله، همه چیز پاک شود', resetDone: 'همه اطلاعات پاک شد', localNote: 'اطلاعات فقط روی همین دستگاه ذخیره می‌شود',
  mods: 'مودها', modsSub: 'طرح‌ها و ایده‌های آماده · فعال: {0}',
  modsIntro: 'یک مود را بزن تا همان لحظه اعمال شود. چند مود را می‌شود با هم داشت؛ فقط از هر گروه ظاهری یکی: یک «تم» (مثل سیاه مطلق یا ترمینال) و یک «بارش» (باران یا برف). رنگ‌کور هم یک گروه جدا دارد (فقط یکی). بقیه، مثل مسابقه‌ای و یک‌دست، آزادانه با هر چیز ترکیب می‌شوند.',
  grpTheme: 'تم · فقط یکی', grpWeather: 'بارش · فقط یکی', grpAddon: 'قابل ترکیب', grpCvd: 'رنگ‌کور · فقط یکی',
  modEmpty: 'هنوز مودی اضافه نشده است.', modSearch: 'جست‌وجو در مودها…', modApply: 'اعمال', modRemoveB: 'برداشتن', modNoMatch: 'چیزی پیدا نشد.',
  modApplied: 'مود «{0}» اعمال شد', modRemoved: 'مود «{0}» برداشته شد.', modRestart: 'برای اثر کامل، برنامه را دوباره باز کن.',
  modErr: 'مود «{0}» خطا داد', modCrash: 'مود «{0}» مشکل داشت و خاموش شد',
  diary: 'دفتر خاطرات', dSubNew: 'هنوز رمز نساخته‌ای', dSubSet: 'با رمز قفل است', dOpen: 'باز کردن',
  dSetupTitle: 'یک رمز برای دفترت بساز', dSetupMsg: 'فقط خودت می‌توانی دفتر را باز کنی. اگر رمز را فراموش کنی، تنها راه، پاک کردن دفتر است.',
  dPw: 'رمز', dPw2: 'تکرار رمز', dCreate: '🔐 ساخت دفتر', dPwShort: 'رمز باید حداقل ۴ نویسه باشد', dMismatch: 'دو رمز یکی نیستند',
  dCreated: 'دفتر ساخته شد 📔', dLockedTitle: 'دفتر قفل است', dUnlock: '🔓 باز کردن', dWrong: 'رمز اشتباه است',
  dForgot: 'رمز را فراموش کرده‌ام', dForgotTitle: '⚠️ پاک شدن دفتر',
  dForgotMsg: 'برای ساختن رمز تازه، همهٔ قسمت‌ها و نوشته‌های دفتر برای همیشه پاک می‌شوند. این کار قابل برگشت نیست.',
  dForgotYes: 'پاک کردن دفتر', dErased: 'دفتر پاک شد', dNewSec: '➕ قسمت جدید', dSecTitlePh: 'نام قسمت',
  dBodyPh: 'هرچه می‌خواهی بنویس...', dNoSecs: 'هنوز قسمتی نساخته‌ای', dChangePw: '🔑 تغییر رمز', dLockNow: '🔒 قفل کن',
  dNewPw: 'رمز تازه', dPwChanged: 'رمز تغییر کرد 🔑', dDelT: '🗑 حذف قسمت؟', dDelMsg: 'این قسمت و نوشته‌هایش برای همیشه پاک می‌شود.',
  dBackupNote: 'پشتیبان‌گیری در تنظیمات، متن دفتر را هم شامل می‌شود. رمز فقط قفل برنامه است و جایگزین رمزگذاری کامل نیست.',
  cancel: 'انصراف', closeB: 'بستن', edit: '✏️ ویرایش', del: '🗑 حذف', deleted: 'حذف شد 🗑',
  fHabitDays: '📅 روزهای هفته (خالی = هر روز)', notToday: 'امروز نوبتش نیست',
  wkTitle: 'گزارش هفتگی', wkSub: '۷ روز گذشته، در مقایسه با ۷ روز قبل از آن', wkBest: 'بهترین روزت: {0} با {1} کار انجام‌شده', wkNone: 'هنوز در ۷ روز گذشته چیزی ثبت نشده.',
  restoreB: '↩ برگردان', restored: 'برگردانده شد ✅',
  sumTitle: 'خلاصهٔ امروز', sumTasks: 'کارهای باقی‌ماندهٔ امروز', sumLate: 'عقب‌افتاده', sumDone: 'انجام‌شده امروز', sumHabits: 'عادت‌های امروز',
  sumFocus: 'جلسهٔ تمرکز', sumSpent: 'خرج امروز', sumNothing: 'برای امروز چیزی نداری؛ یک روز آزاد! ☀️', sumAllDone: 'همهٔ کارهای امروز انجام شد 🎉',
  sumNext: 'کارهای پیش رو', sumHabitsLeft: 'عادت‌های ثبت‌نشده',
  searchB: 'جستجو', srchPh: 'جستجو در همه‌چیز… یا یک #برچسب', srchTags: 'برچسب‌ها', srchNone: 'چیزی پیدا نشد',
  srchHint: 'برای برچسب‌زدن، داخل متن کار، یادداشت، خرید و… بنویس #نام؛ مثلاً «خرید نان #خانه». برچسب‌ها همین‌جا ظاهر می‌شوند.',
  bkFile: '📥 ذخیره به‌صورت فایل', bkPick: '📂 بازیابی از فایل', bkFileOk: 'فایل پشتیبان ساخته شد (معمولاً در پوشهٔ دانلودها)',
  bkTextNote: 'اگر ذخیره/باز کردن فایل در برنامه‌ات کار نکرد، از متن پشتیبان زیر استفاده کن:',
  dEncNote: '🔐 نوشته‌های دفتر با رمز خودت رمزگذاری (AES-256) ذخیره می‌شوند. اگر رمز را فراموش کنی، راهی برای بازیابی نیست.', saved: 'ذخیره شد', saveBtn: '💾 ذخیره',
  yes: 'بله', no: 'خیر', clearBtn: '✕ پاک', subPh: 'مورد جدید...', notFound: 'پیدا نشد',
  fTitle: 'عنوان', fDue: '⏰ زمان (اختیاری)', dueEmpty: 'بدون زمان — انتخاب کن', fPri: 'اولویت', pri0: 'کم', pri1: 'متوسط', pri2: 'زیاد',
  taskLocked: '🔒 این کار تکراری است؛ در روز خودش می‌توانی انجامش بدهی', lockedTill: 'تا روز خودش قفل است',
  shopDoneH: 'خریدهای انجام‌شده', shopAllDone: 'همهٔ خریدها انجام شد 🎉',
  mcDesc: 'شرح', mcDate: 'تاریخ', mcAmt: 'مبلغ', mcTotal: 'جمع',
  fRep: '🔁 تکرار', repNone: 'بدون تکرار', repD: 'هر روز', repW: 'هر هفته', fSubs: '☑️ مراحل داخل کار (اختیاری)',
  fCloud: '☁️ نمایش به شکل ابر', editTask: '✏️ ویرایش کار', titleMissing: 'عنوان را بنویس',
  fShopName: 'چی می‌خوای بخری؟', fPrice: '💰 قیمت ({cur}، اختیاری)', fSaved: '🐖 تا الان چقدر کنار گذاشته‌ای (اختیاری)',
  fWhen: '⏳ چه زمانی بخرم؟', thisWeek: 'این هفته', oneMonth: 'یک ماه', whenFunded: 'وقتی پولش جمع شد', pickDate: '📅 تاریخ',
  whenSel: 'انتخاب‌شده: {0}', whichMonth: '📆 کدام ماه؟', needName: 'نام کالا را بنویس', editItem: '✏️ ویرایش مورد خرید',
  fundedToast: '🎉 پولِ «{0}» جمع شد! می‌تونی بخری', buyTime: '🛒 زمان خرید رسید: {0}', andMore: ' و {0} مورد دیگر',
  fHabitName: 'نام عادت', fHabitSubs: '☑️ بخش‌های داخل عادت (اختیاری؛ با تیک زدن همه، عادت خودش تیک می‌خورد)',
  editHabit: '✏️ ویرایش عادت', needHabit: 'نام عادت را بنویس',
  fAmount: '💵 مبلغ ({cur})', fDesc: 'بابت چی؟ (اختیاری)', fCat: 'دسته', editSpend: '✏️ ویرایش هزینه',
  badAmount: 'مبلغ را درست وارد کن', spendSaved: 'ثبت شد 💰',
  cat0: 'غذا', cat1: 'رفت‌وآمد', cat2: 'خرید', cat3: 'قبض', cat4: 'تفریح', cat5: 'سایر',
  fGoalTitle: 'عنوان هدف', fIcon: 'آیکون', fTarget: '🎯 مقدار هدف (مثلاً ۱۰)', fCur: '📍 تا الان چقدر انجام شده',
  fUnit: 'واحد (مثلاً کتاب، کیلومتر، تومان)', fStep: '⚡ گام افزایش (خالی = خودکار)', fDeadline: '📅 مهلت (اختیاری)',
  noDeadline: 'بدون مهلت — انتخاب کن', editGoal: '✏️ ویرایش هدف', needGoal: 'عنوان هدف را بنویس', badTarget: 'مقدار هدف باید بیشتر از صفر باشد',
  slotAdd: '➕ تایم دلخواه', slotEdit: '✏️ ویرایش تایم دلخواه', fSlotMin: '⏲️ چند دقیقه؟ (۰ تا ۶۰۰)', badMin: 'زمان باید بین ۵ ثانیه و ۶۰۰ دقیقه باشد',
  savTitle: '💰 پس‌انداز برای: {0}', savNow: 'تا الان', fSavAmt: 'چقدر اضافه یا کم کنیم؟ ({cur})', savAdd: '➕ اضافه کن', savSub: '➖ کم کن',
  quickTitle: '🐦 افزودن سریع', fQuickText: 'چی تو ذهنته؟', quickPh: 'مثلاً: زنگ زدن به مامان', fType: 'نوع',
  typeTask: '✅ کار', typeNote: '📝 یادداشت', fQuickDue: '⏰ یادآوری (فقط برای کار)', sendCloud: '☁️ ابر کن و بفرست',
  justSave: '📋 فقط ذخیره کن', needText: 'چیزی بنویس',
  askCloudT: '☁️ ابر بشه؟', askCloudMsg: 'می‌خوای این مورد روی صفحه اصلی به شکل ابر نشان داده بشه؟',
  cloudYes: '☁️ بله، ابر بشه', cloudNo: 'نه', cloudMade: 'ابر شد ☁️', removeCloud: '☁️ برداشتن از ابرها', makeCloud: '☁️ نمایش به شکل ابر',
  markDone: '✓ انجام شد', undo: '↺ برگرداندن', copyText: '📋 کپی متن', copied: 'کپی شد 📋', copyFail: 'کپی نشد',
  pin: '📌 سنجاق', unpin: '📌 برداشتن سنجاق', pick: '✔ انتخاب / خریدم', unpick: '↺ از انتخاب درآوردن',
  useTimer: '▶️ استفاده', customTimer: '⏱️ تایم دلخواه', priLabel: 'اولویت {0}', subCount: '{0} بخش داخلی',
  pkTitleDT: '📅 انتخاب تاریخ و ساعت', pkTitleD: '📅 انتخاب تاریخ', hourL: 'ساعت', minL: 'دقیقه',
  pre30: '۳۰ دقیقه دیگر', pre60: '۱ ساعت دیگر', pre120: '۲ ساعت دیگر', preTonight: 'امشب ۲۱:۰۰', preTom: 'فردا ۰۹:۰۰',
  confirm: '✔ تأیید', noTime: 'بدون زمان', badTime: 'زمان درست نیست',
  cheer: 'آفرین! 👏', nextMade: 'آفرین! نوبت بعدی ساخته شد 🔁',
  dueOne: '⏰ زمان کار رسید: {0}', dueMany: '⏰ {0} کار به موعدشان رسیدند'
},
en: {
  appTitle: 'Nimbo', home: 'Home', settings: 'Settings', menu: 'Menu',
  sec_tasks: 'Tasks', sec_notes: 'Notes', sec_shop: 'Shopping', sec_habits: 'Habits',
  sec_timer: 'Timer', sec_money: 'Spending', sec_goals: 'Goals', sec_stats: 'Stats',
  today: 'Today', tomorrow: 'Tomorrow', u_day: 'd', u_hour: 'h', u_min: 'min', and: ' ',
  left: 'left', overdue: 'overdue', now: 'just now', cur: 'Toman',
  skyEmpty: 'The sky is empty ☀️', skyEmptySub: 'Add something with the bird to make a cloud',
  pinHint: 'You can pin up to 6 clouds 📌 so they always stay on the home screen. Tasks due in under 12 hours become clouds automatically, even if not pinned.', pinMax: 'You can pin up to 6 clouds', pinCloud: 'Pin to home',
  fontSec: 'Text', fontSize: 'Text size', fontSizeSub: 'All text in the app (except tiny wheel labels and clouds)', fontPrev: 'Sample: What do you have today? Hello Nimbo 123',
  fs0: 'Small', fs1: 'Normal', fs2: 'Large', fs3: 'X-Large', fs4: 'Huge',
  fontFam: 'Font', fontFamSub: 'Nimbo: the app’s own font for English. Persian uses Vazirmatn if it is on the phone.', ffNimbo: 'Nimbo', ffSystem: 'System',
  curTitle: 'Currency', curSearch: 'Search currency… (dollar, euro, USD, tether)', curNote: 'Only the unit name and symbol change; amounts are not converted.', curSet: 'Currency: {0}', change: 'Change',
  moreClouds: '+{0} more', birdLabel: 'Quick add', allClouds: 'All clouds',
  newTask: '➕ New task', tabPlan: '🗓️ Day', tlNoTime: 'No time set', tlDragHint: 'drag onto the timeline', tlEmpty: 'No timed tasks this day. Add one with ➕, then drag ⠿ to move it.', tabOpen: 'Open', tabDone: 'Done', noDone: 'Nothing completed yet',
  noTasks: 'Nothing here 🎉', noSchedule: 'No schedule', clearDone: '🧹 Clear completed',
  newNote: '➕ New note', noNotes: 'No notes yet', searchNotes: '🔎 Search notes',
  noteTitlePh: 'Note title', noteBodyPh: 'Write here...', untitled: 'Untitled', back: 'Back',
  pinS: 'Pin', unpinS: 'Unpin', savedAt: 'Last edited: {0}',
  delNoteT: '🗑 Delete note?', delNoteMsg: 'This note will be deleted permanently.', openEdit: '✏️ Open and edit',
  newItem: '➕ New item', noShop: 'Your list is empty', shopTotal: 'Total: {0} {cur} · Saved: {1}',
  noPrice: 'No price', funded: '✅ Fully funded!', of: '{0} of {1}', savingsBtn: '💰 Savings',
  copySel: '📋 Copy selected', clearSel: '🧹 Clear selected', nothingSel: 'Nothing selected',
  newHabit: '➕ New habit', noHabits: 'No habits yet', streakDays: '🔥 {0}-day streak', todayPct: ' · today {0}%',
  markToday: '✓ Mark today',
  focus25: '🍅 Focus 25', rest5: '☕ Break 5', rest15: '🛋️ Break 15', start: '▶️ Start', pause: '⏸ Pause',
  restart: '↺ Restart', minU: 'min', slotNew: 'Timer', timerDone: '⏰ Timer finished!',
  timerHelp: '🍅 Focus sessions today: {0}<br>The side buttons are your own timers: tap ＋ to create one, press and hold to edit or delete.',
  typeTimer: '⏱️ Timer', fTimerLabel: 'Timer name (optional)', timerLabelPh: 'e.g. Tea', fTimerMin: '⏲️ How many minutes?',
  fTimerCustom: 'Or custom minutes', startTimerCloud: '▶️ Start timer (cloud)', timerStarted: '{0}-min timer started ⏱️',
  timerCloud: '{0}-min timer', timerCloudS: 'Timer {0}', secU: 'sec', fSlotSec: '⏲️ How many seconds? (0–59)', fTimerSec: 'Extra seconds (optional)', timerStartedS: 'Timer {0} started ⏱️', qtDone: '⏰ Timer “{0}” finished!', add5: '＋ 5 min', cancelTimer: '✕ Cancel timer', timeLeft: 'Time left',
  moneyToday: 'Today ({cur})', moneyMonth: 'This month ({cur})', budgetMonth: '📅 Monthly budget',
  overBudget: ' — over budget!', newSpend: '➕ New expense', noSpend: 'No expenses yet',
  newGoal: '➕ New goal', noGoals: 'No goals yet', goalDone: '🎉 Completed', goalLate: '⌛ Deadline passed',
  goalDays: '{0} days left · {1}', onTrack: '✅ On track', behind: '⚠️ Behind schedule',
  goalReached: '🎉 Congrats! Goal reached',
  st_today: '✅ Done today', st_week: '📆 Done this week', st_streak: '🔥 Best habit streak', st_pomo: '🍅 Focus today',
  ch_t: '✅ Completed tasks', ch_h: '🔥 Completed habits', ch_m: '💰 Spending', ch_p: '🍅 Focus sessions',
  tapMore: 'Month & year →', rWeek: 'Week', rMonth: 'Month', rYear: 'Year', total: 'Total', history: 'History',
  noEntries: 'Nothing recorded', delNote: 'Deleting here only removes it from stats, not from the other sections. Deleting elsewhere never removes stats.',
  entryDeleted: 'Removed from stats', weekTotal: 'Week total: {0} {1}', topCat: 'Top spending this month: {0} ({1} {2})',
  focusSession: 'Focus session',
  language: 'Language', appearance: 'Appearance', theme: 'Theme', thDark: '🌙 Dark', thLight: '☀️ Light', thAuto: '🌓 Auto',
  thAutoHint: 'Auto switches with day and night', accent: 'Accent color',
  alerts: 'Alerts', sound: 'Sound', soundSub: 'Reminder and timer beep', vib: 'Vibration', vibSub: 'Vibrate on alerts',
  budget: 'Budget', budgetMonthly: 'Monthly budget', budgetSub: '0 means no budget', save: 'Save', budgetSaved: 'Budget saved',
  bkSub: 'All your data in one file', bkSave2: 'Save', bkRestore2: 'Restore', bkAdv: 'Text method (advanced)',
  data: 'Data', backup: 'Backup', backupPh: 'Your backup text appears here. Paste a backup here to restore.',
  bkMake: '📤 Create & copy', bkLoad: '📥 Restore', bkOk: 'Backup created and copied ✅', bkManual: 'Copy the text and keep it safe',
  bkLoaded: 'Data restored ✅', bkBad: 'Invalid backup text', danger: 'Danger zone', eraseAll: '🗑 Erase all data',
  resetTitle: '⚠️ Everything will be erased',
  resetMsg: 'Everything will be permanently erased: tasks, notes, shopping list, habits, expenses, goals, timers, the diary and its password, stats and settings.\nThis cannot be undone.\n\nIf you are not sure, create a backup first.',
  resetYes: 'Yes, erase everything', resetDone: 'All data erased', localNote: 'Data is stored only on this device',
  mods: 'Mods', modsSub: 'Ready-made looks and ideas · active: {0}',
  modsIntro: 'Tap a mod to apply it right away. You can combine mods; only one per look group: one “Theme” (e.g. Amoled or Terminal) and one “Weather” (rain or snow). Color-blind is its own group (one at a time). The rest, like Game mode and Calm, combine freely with anything.',
  grpTheme: 'Theme · one at a time', grpWeather: 'Weather · one at a time', grpAddon: 'Combinable', grpCvd: 'Color-blind · one at a time',
  modEmpty: 'No mods yet.', modSearch: 'Search mods…', modApply: 'Apply', modRemoveB: 'Remove', modNoMatch: 'Nothing found.',
  modApplied: 'Mod “{0}” applied', modRemoved: 'Mod “{0}” removed.', modRestart: 'Reopen the app for full effect.',
  modErr: 'Mod “{0}” failed', modCrash: 'Mod “{0}” had a problem and was turned off',
  diary: 'Diary', dSubNew: 'No password yet', dSubSet: 'Locked with a password', dOpen: 'Open',
  dSetupTitle: 'Create a password for your diary', dSetupMsg: 'Only you can open the diary. If you forget the password, the only way out is to erase the diary.',
  dPw: 'Password', dPw2: 'Repeat password', dCreate: '🔐 Create diary', dPwShort: 'Password must be at least 4 characters', dMismatch: 'The passwords do not match',
  dCreated: 'Diary created 📔', dLockedTitle: 'The diary is locked', dUnlock: '🔓 Unlock', dWrong: 'Wrong password',
  dForgot: 'I forgot my password', dForgotTitle: '⚠️ Erase the diary',
  dForgotMsg: 'To set a new password, all sections and entries in the diary will be permanently erased. This cannot be undone.',
  dForgotYes: 'Erase the diary', dErased: 'Diary erased', dNewSec: '➕ New section', dSecTitlePh: 'Section name',
  dBodyPh: 'Write anything you like...', dNoSecs: 'No sections yet', dChangePw: '🔑 Change password', dLockNow: '🔒 Lock now',
  dNewPw: 'New password', dPwChanged: 'Password changed 🔑', dDelT: '🗑 Delete section?', dDelMsg: 'This section and its text will be deleted permanently.',
  dBackupNote: 'Backups from Settings include the diary text. The password only locks the app; it is not full encryption.',
  cancel: 'Cancel', closeB: 'Close', edit: '✏️ Edit', del: '🗑 Delete', deleted: 'Deleted 🗑',
  fHabitDays: '📅 Days of the week (empty = every day)', notToday: 'not scheduled today',
  wkTitle: 'Weekly report', wkSub: 'Last 7 days vs the 7 days before', wkBest: 'Your best day: {0} with {1} things done', wkNone: 'Nothing logged in the last 7 days yet.',
  restoreB: '↩ Undo', restored: 'Restored ✅',
  sumTitle: "Today's summary", sumTasks: 'Tasks left today', sumLate: 'Overdue', sumDone: 'Done today', sumHabits: 'Habits today',
  sumFocus: 'Focus sessions', sumSpent: 'Spent today', sumNothing: 'Nothing planned for today, a free day! ☀️', sumAllDone: 'Everything for today is done 🎉',
  sumNext: 'Coming up', sumHabitsLeft: 'Habits not logged yet',
  searchB: 'Search', srchPh: 'Search everything… or a #tag', srchTags: 'Tags', srchNone: 'Nothing found',
  srchHint: 'To tag something, write #name inside a task, note, shopping item… e.g. "Buy bread #home". Your tags show up here.',
  bkFile: '📥 Save as file', bkPick: '📂 Restore from file', bkFileOk: 'Backup file created (usually in Downloads)',
  bkTextNote: "If saving/opening files doesn't work in your app, use the backup text below:",
  dEncNote: '🔐 Diary entries are stored encrypted (AES-256) with your password. If you forget it, there is no way to recover them.', saved: 'Saved', saveBtn: '💾 Save',
  yes: 'Yes', no: 'No', clearBtn: '✕ Clear', subPh: 'New item...', notFound: 'Not found',
  fTitle: 'Title', fDue: '⏰ Time (optional)', dueEmpty: 'No time — tap to set', fPri: 'Priority', pri0: 'Low', pri1: 'Medium', pri2: 'High',
  taskLocked: '🔒 Repeating task — you can complete it on its own day', lockedTill: 'locked until its day',
  shopDoneH: 'Purchased', shopAllDone: 'Everything is bought 🎉',
  mcDesc: 'Description', mcDate: 'Date', mcAmt: 'Amount', mcTotal: 'Total',
  fRep: '🔁 Repeat', repNone: 'No repeat', repD: 'Daily', repW: 'Weekly', fSubs: '☑️ Steps inside the task (optional)',
  fCloud: '☁️ Show as a cloud', editTask: '✏️ Edit task', titleMissing: 'Enter a title',
  fShopName: 'What do you want to buy?', fPrice: '💰 Price (optional)', fSaved: '🐖 Saved so far (optional)',
  fWhen: '⏳ When to buy?', thisWeek: 'This week', oneMonth: 'A month', whenFunded: 'When funded', pickDate: '📅 Date',
  whenSel: 'Selected: {0}', whichMonth: '📆 Which month?', needName: 'Enter an item name', editItem: '✏️ Edit item',
  fundedToast: '🎉 You saved enough for “{0}”!', buyTime: '🛒 Time to buy: {0}', andMore: ' and {0} more',
  fHabitName: 'Habit name', fHabitSubs: '☑️ Parts of the habit (optional; completing all checks the habit)',
  editHabit: '✏️ Edit habit', needHabit: 'Enter a habit name',
  fAmount: '💵 Amount', fDesc: 'What for? (optional)', fCat: 'Category', editSpend: '✏️ Edit expense',
  badAmount: 'Enter a valid amount', spendSaved: 'Recorded 💰',
  cat0: 'Food', cat1: 'Transport', cat2: 'Shopping', cat3: 'Bills', cat4: 'Fun', cat5: 'Other',
  fGoalTitle: 'Goal title', fIcon: 'Icon', fTarget: '🎯 Target amount (e.g. 10)', fCur: '📍 Progress so far',
  fUnit: 'Unit (e.g. books, km, $)', fStep: '⚡ Step size (empty = auto)', fDeadline: '📅 Deadline (optional)',
  noDeadline: 'No deadline — tap to set', editGoal: '✏️ Edit goal', needGoal: 'Enter a goal title', badTarget: 'Target must be greater than zero',
  slotAdd: '➕ Custom timer', slotEdit: '✏️ Edit custom timer', fSlotMin: '⏲️ How many minutes? (0–600)', badMin: 'Time must be between 5 seconds and 600 minutes',
  savTitle: '💰 Savings for: {0}', savNow: 'So far', fSavAmt: 'Amount to add or remove', savAdd: '➕ Add', savSub: '➖ Remove',
  quickTitle: '🐦 Quick add', fQuickText: 'What is on your mind?', quickPh: 'e.g. Call mom', fType: 'Type',
  typeTask: '✅ Task', typeNote: '📝 Note', fQuickDue: '⏰ Reminder (tasks only)', sendCloud: '☁️ Make a cloud and send',
  justSave: '📋 Just save', needText: 'Write something',
  askCloudT: '☁️ Make it a cloud?', askCloudMsg: 'Do you want this to appear as a cloud on the home screen?',
  cloudYes: '☁️ Yes, make a cloud', cloudNo: 'No', cloudMade: 'Cloud created ☁️', removeCloud: '☁️ Remove from clouds', makeCloud: '☁️ Show as a cloud',
  markDone: '✓ Mark done', undo: '↺ Undo', copyText: '📋 Copy text', copied: 'Copied 📋', copyFail: 'Copy failed',
  pin: '📌 Pin', unpin: '📌 Unpin', pick: '✔ Select / bought', unpick: '↺ Unselect',
  useTimer: '▶️ Use', customTimer: '⏱️ Custom timer', priLabel: '{0} priority', subCount: '{0} parts',
  pkTitleDT: '📅 Pick date & time', pkTitleD: '📅 Pick a date', hourL: 'Hour', minL: 'Minute',
  pre30: 'In 30 min', pre60: 'In 1 hour', pre120: 'In 2 hours', preTonight: 'Tonight 21:00', preTom: 'Tomorrow 09:00',
  confirm: '✔ Confirm', noTime: 'No time', badTime: 'Invalid time',
  cheer: 'Well done! 👏', nextMade: 'Well done! Next one created 🔁',
  dueOne: '⏰ Task due: {0}', dueMany: '⏰ {0} tasks are due'
}
};

/* ================= شروع ================= */
/* جلوگیری از «کشیدن برای رفرش» در WebView اندروید */
(function () {
  let y0 = 0;
  document.addEventListener('touchstart', e => { y0 = e.touches[0].clientY; }, { passive: true });
  document.addEventListener('touchmove', e => {
    const dy = e.touches[0].clientY - y0;
    if (dy <= 12) return;
    let el = e.target;
    while (el && el !== document.body) {
      if (el.scrollHeight > el.clientHeight + 1) {
        const oy = getComputedStyle(el).overflowY;
        if ((oy === 'auto' || oy === 'scroll') && el.scrollTop > 0) return;
      }
      el = el.parentElement;
    }
    if (e.cancelable) e.preventDefault();
  }, { passive: false });
})();

/* ================= آیکون‌های ساخته‌شده با کد (جایگزین ایموجی‌ها) =================
   هر ایموجی در متن‌ها خودکار به آیکون SVG زیر تبدیل می‌شود.
   برای عوض‌کردن شکل یک آیکون، همین‌جا مسیرش (path) را عوض کن. */
const SVGI = {
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  checkc: '<circle cx="12" cy="12" r="9"/><path d="M8 12.5l3 3 5-6"/>',
  checkb: '<rect x="4" y="4" width="16" height="16" rx="3.5"/><path d="M8 12l3 3 5-6"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  pencil: '<path d="M4 20l1-4L16.5 4.5a2.1 2.1 0 013 3L8 19z"/><path d="M14.5 6.5l3 3"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6"/>',
  note: '<path d="M6 3h9l4 4v14H6z"/><path d="M15 3v4h4M9 12h7M9 16h5"/>',
  cart: '<circle cx="9" cy="20" r="1.5"/><circle cx="17" cy="20" r="1.5"/><path d="M3 4h2.5l2.2 11h10l2-8H7"/>',
  flame: '<path d="M12 3c1 3.5 5 5.5 5 10a5 5 0 01-10 0c0-2 1-3 2-4 .3 1.5 1 2 1.8 2.2C10.5 8 11 5.5 12 3z"/>',
  stopwatch: '<circle cx="12" cy="13.5" r="7.5"/><path d="M12 13.5V9.5M9.5 3h5M12 3v3M18.5 6.5l1.2-1.2"/>',
  hourglass: '<path d="M7 3h10M7 21h10M8 3c0 5 4 6 4 9s-4 4-4 9M16 3c0 5-4 6-4 9s4 4 4 9"/>',
  coins: '<ellipse cx="12" cy="7" rx="7" ry="3"/><path d="M5 7v5c0 1.7 3.1 3 7 3s7-1.3 7-3V7M5 12v5c0 1.7 3.1 3 7 3s7-1.3 7-3v-5"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.2" fill="currentColor"/>',
  bars: '<path d="M5 20v-8M12 20V4M19 20v-5" stroke-width="3.4"/>',
  gear: '<circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="6.5"/><path d="M12 5.5V2.5M12 18.5v3M5.5 12h-3M18.5 12h3M7.4 7.4L5.3 5.3M16.6 16.6l2.1 2.1M16.6 7.4l2.1-2.1M7.4 16.6l-2.1 2.1"/>',
  home: '<path d="M4 11l8-7 8 7M6 10v10h12V10M10 20v-6h4v6"/>',
  cloud: '<path d="M7 18a4.5 4.5 0 01-.6-8.96A6 6 0 0118 10.5 3.8 3.8 0 0117.5 18z"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
  palette: '<path d="M12 3a9 9 0 100 18c1.5 0 2-1 1.5-2-.6-1.2.2-2.5 1.6-2.5H17a4 4 0 004-4c0-5-4-9.5-9-9.5z"/><circle cx="7.5" cy="11" r="1" fill="currentColor"/><circle cx="10" cy="7" r="1" fill="currentColor"/><circle cx="15" cy="7.5" r="1" fill="currentColor"/>',
  bell: '<path d="M6 17v-6a6 6 0 0112 0v6l1.5 2h-15zM10 21h4"/>',
  speaker: '<path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z"/><path d="M15.5 9a4 4 0 010 6M18 6.5a8 8 0 010 11"/>',
  vibrate: '<rect x="8" y="3" width="8" height="18" rx="2"/><path d="M4 8v8M20 8v8"/>',
  book: '<path d="M5 4a1 1 0 011-1h12v18H6a1 1 0 01-1-1z"/><path d="M9 8h6M9 12h6"/>',
  disk: '<path d="M5 3h12l3 3v15H5z"/><path d="M8 3v5h7V3M8 21v-7h8v7"/>',
  warn: '<path d="M12 3.5l9.5 16.5h-19z"/><path d="M12 10v4.5M12 17.3v.2"/>',
  moon: '<path d="M20 14.5A8 8 0 019.5 4 8 8 0 1020 14.5z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.5V5M12 19v2.5M2.5 12H5M19 12h2.5M5.3 5.3l1.8 1.8M16.9 16.9l1.8 1.8M18.7 5.3l-1.8 1.8M7.1 16.9l-1.8 1.8"/>',
  half: '<circle cx="12" cy="12" r="8.5"/><path d="M12 3.5a8.5 8.5 0 010 17z" fill="currentColor"/>',
  alarm: '<circle cx="12" cy="13" r="7.5"/><path d="M12 9v4l2.5 2M4 6l3-2.5M20 6l-3-2.5"/>',
  repeat: '<path d="M4 11V9a3 3 0 013-3h12M16 3l3 3-3 3M20 13v2a3 3 0 01-3 3H5M8 21l-3-3 3-3"/>',
  pin: '<path d="M9 3h6l-1 6 3 3v2H7v-2l3-3z"/><path d="M12 14v7"/>',
  clip: '<rect x="5" y="4.5" width="14" height="17" rx="2"/><rect x="9" y="2.5" width="6" height="4" rx="1"/><path d="M9 12h6M9 16h4"/>',
  cal: '<rect x="4" y="5" width="16" height="16" rx="2"/><path d="M4 10h16M8 3v4M16 3v4"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
  aa: '<path d="M3 18l5-12 5 12M5 14h6"/><path d="M15 18v-6a3 3 0 016 0v6M15 15h6"/>',
  swap: '<path d="M4 8h14l-3-3M20 16H6l3 3"/>',
  broom: '<path d="M16 3l-5 8"/><path d="M8 11h6l3 9H5z"/><path d="M8 15l1 5M12 15v5"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3M14 9l2 2"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>',
  unlock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 017.5-2"/>',
  up: '<path d="M12 16V4M7 9l5-5 5 5M5 20h14"/>',
  down: '<path d="M12 4v12M7 11l5 5 5-5M5 20h14"/>',
  mappin: '<path d="M12 21s-6.5-6-6.5-11a6.5 6.5 0 0113 0c0 5-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.3"/>',
  bolt: '<path d="M13 2.5L5 13.5h6l-1 8 8-11h-6z"/>',
  reset: '<path d="M5 12a7 7 0 107-7H7"/><path d="M10 2L6.5 5 10 8"/>',
  pause: '<path d="M8 5v14M16 5v14" stroke-width="3.2"/>',
  play: '<path d="M7 4.5v15l12-7.5z" fill="currentColor"/>',
  dot: '<circle cx="12" cy="12" r="6.5" fill="currentColor" stroke="none"/>',
  fork: '<path d="M7 3v8M5 3v5a2 2 0 004 0V3M7 11v10M17 21V3c-2.5 1.5-3.5 5-3.5 8H17"/>',
  bus: '<rect x="4" y="3.5" width="16" height="14" rx="3"/><path d="M4 12h16M8 20v-2.5M16 20v-2.5"/><circle cx="8" cy="15" r=".7" fill="currentColor"/><circle cx="16" cy="15" r=".7" fill="currentColor"/>',
  bag: '<path d="M5 8h14l-1 13H6z"/><path d="M9 8V6a3 3 0 016 0v2"/>',
  receipt: '<path d="M6 3h12v18l-2.5-1.8L13 21l-2-1.8L8.5 21 6 19.2z"/><path d="M9 8h6M9 12h6"/>',
  gamepad: '<path d="M7 7h10a4 4 0 014 4v2a3.5 3.5 0 01-6 2.5L13.5 14h-3L9 15.5A3.5 3.5 0 013 13v-2a4 4 0 014-4z"/><path d="M8 10v3M6.5 11.5h3"/><circle cx="16" cy="11" r=".9" fill="currentColor"/>',
  box: '<path d="M3.5 7.5L12 3l8.5 4.5v9L12 21l-8.5-4.5z"/><path d="M3.5 7.5L12 12l8.5-4.5M12 12v9"/>',
  books: '<path d="M4 4h4v16H4zM10 4h4v16h-4z"/><path d="M16.5 5.5l3.5 1-3.5 13.5-3.5-1z"/>',
  dumbbell: '<path d="M6.5 7v10M17.5 7v10M3.5 9.5v5M20.5 9.5v5M6.5 12h11" stroke-width="2.4"/>',
  plane: '<path d="M21 3L10 14M21 3l-6.5 18-3.5-7-7-3.5z"/>',
  cap: '<path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11.5V16c0 1.5 3 3 6 3s6-1.5 6-3v-4.5M22 9v6"/>',
  heart: '<path d="M12 20.5S3.5 15 3.5 9a4.5 4.5 0 018.5-2 4.5 4.5 0 018.5 2c0 6-8.5 11.5-8.5 11.5z"/>',
  sofa: '<path d="M5 11V8a2 2 0 012-2h10a2 2 0 012 2v3M3 13a2 2 0 014 0v1h10v-1a2 2 0 014 0v5H3zM6 18v2M18 18v2"/>',
  piggy: '<path d="M5 11a7 6 0 0113-2h2l-.5 3 1.5 1v3l-2 .5V19h-3v-2H9v2H6v-3.5A6 6 0 015 11z"/><circle cx="15" cy="11" r=".8" fill="currentColor"/><path d="M9 7.5h3"/>',
  note$: '<rect x="3" y="6.5" width="18" height="11" rx="2"/><circle cx="12" cy="12" r="2.5"/><path d="M6.5 12h.01M17.5 12h.01"/>',
  tomato: '<circle cx="12" cy="13.5" r="7.5"/><path d="M9 6.5c1 .5 2 .3 3-.7 1 1 2 1.2 3 .7M12 5.8V3.5"/>',
  coffee: '<path d="M5 9h11v5a5 5 0 01-5 5h-1a5 5 0 01-5-5zM16 10h2a2.5 2.5 0 010 5h-2M8 3v2M12 3v2"/>',
  spark: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7z"/>',
  bird: '<path d="M3 8c3 0 4 1 6 1 .5-3 3-5 6-5 1 0 2 .3 3 1l2-.5-1 2c0 6-4 12-11 12-3 0-5-1-6-2 2 0 3-.5 4-1.5-2-.2-3.5-1.5-4-3.5.7.2 1.3.2 2 0C4 11 3 9.5 3 8z"/>',
  puzzle: '<path d="M10 3h4v3a2 2 0 104 0h3v5h-3a2 2 0 100 4h3v6H3V9h3a2 2 0 100-4H3V3z"/>',
  chl: '<path d="M15 5l-7 7 7 7"/>',
  chr: '<path d="M9 5l7 7-7 7"/>'
};
const EMOJI_ICON = {
  '✅': 'checkc', '✔': 'check', '✓': 'check', '☑': 'checkb', '✕': 'x', '➕': 'plus', '➖': 'minus',
  '✏': 'pencil', '🗑': 'trash', '📝': 'note', '🛒': 'cart', '🔥': 'flame', '⏱': 'stopwatch', '⏲': 'stopwatch',
  '⌛': 'hourglass', '⏳': 'hourglass', '💰': 'coins', '🎯': 'target', '📊': 'bars', '⚙': 'gear', '🏠': 'home',
  '☁': 'cloud', '🌐': 'globe', '🎨': 'palette', '🔔': 'bell', '🔊': 'speaker', '📳': 'vibrate', '📔': 'book',
  '💾': 'disk', '⚠': 'warn', '🌙': 'moon', '☀': 'sun', '🌓': 'half', '⏰': 'alarm', '🔁': 'repeat', '📌': 'pin',
  '📋': 'clip', '📅': 'cal', '📆': 'cal', '🔎': 'search', '🔤': 'aa', '💱': 'swap', '🧹': 'broom', '🔑': 'key', '🔐': 'lock', '🔒': 'lock',
  '🔓': 'unlock', '📤': 'up', '📥': 'down', '📍': 'mappin', '⚡': 'bolt', '↺': 'reset', '⏸': 'pause', '▶': 'play',
  '🟢': 'dot', '🟡': 'dot', '🔴': 'dot', '🍽': 'fork', '🚌': 'bus', '🛍': 'bag', '🧾': 'receipt', '🎮': 'gamepad',
  '📦': 'box', '📚': 'books', '💪': 'dumbbell', '✈': 'plane', '🎓': 'cap', '❤': 'heart', '🛋': 'sofa',
  '🐖': 'piggy', '💵': 'note$', '🍅': 'tomato', '☕': 'coffee', '🎉': 'spark', '👏': 'spark', '🐦': 'bird',
  '🧩': 'puzzle', '❮': 'chl', '❯': 'chr'
};
const ICON_COLOR = { '✅': '#22c55e', '🔥': '#f97316', '🍅': '#ef4444', '❤': '#ef4444', '☀': '#f59e0b', '🌙': '#fbbf24',
  '🐖': '#f472b6', '☕': '#d97706', '🎉': '#f59e0b', '👏': '#f59e0b', '⚡': '#f59e0b', '⚠': '#f59e0b',
  '🟢': '#22c55e', '🟡': '#f59e0b', '🔴': '#ef4444', '💰': '#f59e0b', '💵': '#22c55e', '🎯': '#ef4444' };
const EMO_RE = /[✓✕↺❮❯]|\p{Extended_Pictographic}️?/gu;
const EMO_TEST = /[✓✕↺❮❯]|\p{Extended_Pictographic}/u;
const icoCache = {};
function icoNode(key) {
  const nm = EMOJI_ICON[key];
  if (!nm || !SVGI[nm]) return null;
  if (!icoCache[key]) {
    const tp = document.createElement('template');
    const col = ICON_COLOR[key];
    tp.innerHTML = '<svg class="ico" viewBox="0 0 24 24" aria-hidden="true"' + (col ? ' style="color:' + col + '"' : '') + '>' + SVGI[nm] + '</svg>';
    icoCache[key] = tp.content.firstChild;
  }
  return icoCache[key].cloneNode(true);
}
function fixText(n) {
  const p = n.parentNode;
  if (!p) return;
  const tg = p.nodeName;
  if (tg === 'TEXTAREA' || tg === 'SCRIPT' || tg === 'STYLE' || tg === 'TITLE' || tg === 'OPTION') return;
  const s = n.nodeValue;
  if (!EMO_TEST.test(s)) return;
  const frag = document.createDocumentFragment();
  let last = 0, hit = false, m;
  EMO_RE.lastIndex = 0;
  while ((m = EMO_RE.exec(s))) {
    const node = icoNode(m[0].replace(/️/g, ''));
    if (!node) continue;
    hit = true;
    if (m.index > last) frag.appendChild(document.createTextNode(s.slice(last, m.index)));
    frag.appendChild(node);
    last = m.index + m[0].length;
  }
  if (!hit) return;
  if (last < s.length) frag.appendChild(document.createTextNode(s.slice(last)));
  p.replaceChild(frag, n);
}
function iconize(root) {
  if (!root) return;
  if (root.nodeType === 3) { fixText(root); return; }
  if (root.nodeType !== 1) return;
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const list = [];
  let n;
  while ((n = w.nextNode())) if (EMO_TEST.test(n.nodeValue)) list.push(n);
  list.forEach(fixText);
}
new MutationObserver(ms => {
  for (let i = 0; i < ms.length; i++) {
    const m = ms[i];
    if (m.type === 'characterData') fixText(m.target);
    else for (let j = 0; j < m.addedNodes.length; j++) iconize(m.addedNodes[j]);
  }
}).observe(document.body, { childList: true, subtree: true, characterData: true });

applyTheme();
applyFont();
setWheel(S.set.wheel !== false, false);
setRot(0);
try { history.replaceState({ s: 'home' }, ''); } catch (e) {}
applyLang();
openSection('home', true);
modsBoot();
checkReminders();
iconize(document.body);

})();