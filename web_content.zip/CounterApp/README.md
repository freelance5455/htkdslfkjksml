# Simple Counter (Android)

A tiny native Android app with a top-right `amount/93.5` display and `−` / `+` buttons. Each tap changes the amount by 0.80. The value is clamped to 0.00–93.50 and stored across activity recreation.

## Build APK

Requires Android Studio or Android SDK + Gradle, and internet access to download Android Gradle Plugin/dependencies.

From this folder, run:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.
