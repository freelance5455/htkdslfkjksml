HOW TO BUILD THE APK
1. Install Android Studio (free): https://developer.android.com/studio
2. File > Open > select this CounterApp folder. Wait for Gradle sync to finish.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Click "locate" in the popup. The file is app/build/outputs/apk/debug/app-debug.apk
5. Copy it to your phone and install (allow "install unknown apps" if asked).
