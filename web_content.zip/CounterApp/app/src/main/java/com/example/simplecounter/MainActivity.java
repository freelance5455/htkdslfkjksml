package com.example.simplecounter;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int STEP_CENTS = 80;
    private static final int MAX_CENTS = 9350;
    private int amountCents = 0;
    private TextView amountView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) amountCents = savedInstanceState.getInt("amountCents", 0);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(247, 248, 250));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        amountView = new TextView(this);
        amountView.setTextColor(Color.rgb(25, 35, 32));
        amountView.setTextSize(24);
        amountView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        amountView.setGravity(Gravity.END);
        top.addView(amountView, new LinearLayout.LayoutParams(-2, -2));
        root.addView(top, new LinearLayout.LayoutParams(-1, dp(64)));

        View spacer = new View(this);
        root.addView(spacer, new LinearLayout.LayoutParams(1, 0, 1));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER);
        Button minus = makeButton("−", false);
        Button plus = makeButton("+", true);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(112), 1f);
        bp.setMargins(0, 0, dp(10), 0);
        buttons.addView(minus, bp);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(0, dp(112), 1f);
        pp.setMargins(dp(10), 0, 0, 0);
        buttons.addView(plus, pp);
        root.addView(buttons, new LinearLayout.LayoutParams(-1, dp(112)));

        View bottomSpace = new View(this);
        root.addView(bottomSpace, new LinearLayout.LayoutParams(1, 0, 1f));
        setContentView(root);
        minus.setOnClickListener(v -> { amountCents = Math.max(0, amountCents - STEP_CENTS); updateAmount(); });
        plus.setOnClickListener(v -> { amountCents = Math.min(MAX_CENTS, amountCents + STEP_CENTS); updateAmount(); });
        updateAmount();
    }

    private Button makeButton(String label, boolean positive) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(42);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(positive ? Color.rgb(23, 107, 82) : Color.rgb(66, 76, 73)));
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        return b;
    }

    private void updateAmount() {
        amountView.setText(String.format(Locale.US, "%.2f/93.5", amountCents / 100.0));
    }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    @Override protected void onSaveInstanceState(Bundle out) {
        out.putInt("amountCents", amountCents);
        super.onSaveInstanceState(out);
    }
}
