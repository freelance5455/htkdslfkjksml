STAFF & STORE MANAGER — QR SCANNER EDITION

Files:
- index.html: complete app source (HTML/CSS/JavaScript)

Features:
- Offline staff and inventory records saved in this browser on this device
- Admin/staff accounts, dashboard, stock movements, JSON backup/restore, CSV exports
- QR Scanner page: scans QR codes using the phone camera where supported; tries to match the decoded text to a product SKU/name; manual SKU entry is also available

IMPORTANT CAMERA NOTE:
The app's records work offline, but browser camera access is usually allowed only on HTTPS pages or localhost. Opening index.html directly as a file may block camera access. Use an HTTPS host or an Android local web server if needed. Camera scanning requires a compatible updated browser with BarcodeDetector QR support. Manual SKU entry/search remains available if scanning is unsupported.

BACKUP:
Export a JSON backup regularly. Browser storage can be cleared by Android/Chrome and is not a substitute for a secure business database. This starter app is not security-audited and should not store sensitive records.
