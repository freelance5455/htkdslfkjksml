
import { createAHMADAiChat } from "./ai.js";

const IMAGE_API =
  "https://ahmad-ai-image.abwm63076.workers.dev";

const promptInput = document.getElementById("imagePrompt");
const generateBtn = document.getElementById("generateImageBtn");
const statusText = document.getElementById("imageStatus");
const imageBox = document.getElementById("generatedImageBox");
const generatedImage = document.getElementById("generatedImage");
const downloadBtn = document.getElementById("downloadGeneratedImage");
// إنشاء صورة من نص خارجي داخل استوديو المحتوى
export async function generateImageFromText(userPrompt) {
  if (!userPrompt || !userPrompt.trim()) {
    throw new Error("لا يوجد محتوى لإنشاء الصورة.");
  }

  const chat = createAHMADAiChat();

  const enhancedPrompt = await chat.send(`
You are an expert video game scene recreation specialist.

Your task is to recreate the actual visual world of the video game described by the user.

SPECIAL RULE FOR COMMAND & CONQUER: GENERALS – ZERO HOUR:

When this game is mentioned, create an image that looks like an authentic gameplay screenshot from the original game.

VISUAL REQUIREMENTS:
- Use the original isometric real-time strategy gameplay camera perspective.
- Show an actual battlefield, not a computer room or gaming setup.
- Recreate recognizable military base layouts and battlefield environments.
- Include recognizable units, vehicles and structures from the USA, China and GLA factions when relevant.
- Preserve the classic game's visual identity, terrain, buildings and military atmosphere.
- Use highly realistic, cinematic 3D graphics with detailed military vehicles, realistic metal surfaces, authentic battlefield terrain, natural lighting, realistic shadows and high-resolution textures.
- Preserve the recognizable designs and identity of Command & Conquer: Generals Zero Hour.
- Avoid cartoon graphics, toy-like vehicles, childish proportions, simplified textures and illustrated appearances.
- The result should resemble a modern realistic 3D recreation of the original game, not a cartoon.
- Show units and buildings placed naturally on the battlefield.
- Make the scene look like a real moment during gameplay.

STRICTLY FORBIDDEN:
- No computer monitors.
- No gaming desks or keyboards.
- No people sitting in front of computers.
- No futuristic holographic control rooms.
- No unrelated science-fiction buildings or vehicles.
- No generic modern military scene replacing the game's visual identity.

GENERAL RULES:
- Identify the exact game before describing the scene.
- Preserve the requested subject and context.
- Do not invent unrelated objects or mix different games.
- If a specific unit or building is requested, prioritize its recognizable design.
- Do not add random details just to make the image more complex.

OUTPUT:
Return one detailed English image-generation prompt.
The result must look like an actual screenshot or faithful visual recreation of the requested game.
No external captions, watermarks or decorative text.

USER CONTENT:
${userPrompt}



Return only the final image description in English.
`);

  const finalPrompt = enhancedPrompt.trim();

  if (!finalPrompt || finalPrompt.length < 10) {
    throw new Error("تعذر تجهيز وصف الصورة.");
  }

  const response = await fetch(IMAGE_API, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      prompt: finalPrompt
    })
  });

  const result = await response.json();

  if (!response.ok || !result.success || !result.image) {
    throw new Error(result.error || "فشل إنشاء الصورة.");
  }

  return result.image;
}
generateBtn.addEventListener("click", async () => {
  const userPrompt = promptInput.value.trim();

  if (!userPrompt) {
    statusText.textContent = "اكتب ماذا تريد أن ترى في الصورة.";
    return;
  }

  generateBtn.disabled = true;
  imageBox.hidden = true;

  try {
    // المرحلة الأولى: تحسين الوصف باستخدام Gemini
    generateBtn.textContent = "يفهم طلبك ويجهز الوصف...";
    statusText.textContent = "الذكاء الاصطناعي يحضّر فكرتك...";

    const chat = createAHMADAiChat();

    const enhancedPrompt = await chat.send(`
You are a precision-first image prompt translator.

Your job is to convert the user's request into an image-generation prompt while preserving exactly what the user wants.

ABSOLUTE PRIORITY: FOLLOW THE USER'S DESCRIPTION.

1. SUBJECT FIDELITY:
- Identify the exact subject requested.
- Keep the same subject, identity, object, place, activity and context.
- Never replace the requested subject with something similar or generic.
- Never change the meaning of the request.

2. STYLE FIDELITY:
- Follow the exact visual style requested by the user.
- If the user requests realistic, use realistic.
- If the user requests cartoon, use cartoon.
- If the user requests 3D, use 3D.
- If the user requests a gameplay screenshot, recreate a gameplay scene.
- If no style is specified, choose a suitable style without changing the subject.
- Never impose a fixed artistic style on every request.

3. DETAIL FIDELITY:
- Preserve requested colors, shapes, materials, proportions, objects and surroundings.
- Preserve the requested camera angle and composition.
- Do not add people, vehicles, buildings or objects unless requested or clearly necessary.
- Do not omit important requested details.
- Do not invent details to fill gaps.

4. NAMED GAMES AND PRODUCTS:
- Treat game titles, product names, vehicle models and proper nouns as exact names.
- Do not interpret parts of a proper name as ordinary words.
- For Command & Conquer: Generals – Zero Hour, understand that this is a real-time strategy video game.
- When this game is requested, depict its actual gameplay world, recognizable faction structures, military units and vehicles, using an RTS gameplay camera perspective.
- Do not depict a military general as a person unless explicitly requested.
- Do not substitute unrelated military imagery for the game's world.

5. COMPOSITION:
- Create one coherent image matching the user's request.
- Keep the main subject clear and recognizable.
- Choose only supporting details that fit the requested scene.
- Do not turn a simple request into a different elaborate concept.

6. TEXT AND LOGOS:
- Include text or logos only if the user explicitly requests them.
- Otherwise avoid unwanted writing, captions and watermarks.

7. FINAL OUTPUT:
- Write a clear, detailed English prompt for the image model.
- Preserve the user's intended meaning and requested visual style.
- Do not add explanations, introductions or alternative concepts.
- Do not mention elements that should not appear unless needed to prevent a known misunderstanding.

USER'S ORIGINAL REQUEST:
${userPrompt}
`);

    const finalPrompt = enhancedPrompt.trim();

    if (!finalPrompt || finalPrompt.length < 10) {
      throw new Error("لم يتمكن الذكاء الاصطناعي من تحسين الوصف.");
    }

    // المرحلة الثانية: إنشاء الصورة
    generateBtn.textContent = "جارٍ إنشاء الصورة...";
    statusText.textContent = "تم تجهيز الوصف، يجري إنشاء صورتك الآن...";

    const response = await fetch(IMAGE_API, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        prompt: finalPrompt
      })
    });

    const result = await response.json();

    if (!response.ok || !result.success || !result.image) {
      throw new Error(result.error || "فشل إنشاء الصورة.");
    }

    generatedImage.src = result.image;
    downloadBtn.href = result.image;
    imageBox.hidden = false;

    statusText.textContent = "تم إنشاء صورتك بنجاح! ✨";

  } catch (error) {
    console.error("AHMAD AI Image Error:", error);
    statusText.textContent = "حدث خطأ: " + error.message;

  } finally {
    generateBtn.disabled = false;
    generateBtn.textContent = "✨ إنشاء الصورة";
  }
});
