# Glassboard Android

Standalone Android app wrapper for Glassboard. The UI is bundled locally and opens as its own Android app, not Chrome.

## Included features
- Existing Glassboard tasks, subtasks, notes, links, images, videos and media viewer
- Task/sub-task time period with optional start date/time and due date/time
- Reminder choices: None, Daily, Every 1-24 hours, Custom days/hours/minutes
- Local Android notifications while the app is closed
- Notifications stop when the task/sub-task is completed or the due time is reached
- Notification tap opens the related task/sub-task
- Reminders are restored after device reboot/app update
- Android file picker support for image/video uploads

## Build
Open the project in Android Studio. Sync Gradle, then build `app > Tasks > build > assembleDebug` or use `Build > Build APK(s)`.

The project requests notification permission on Android 13+ and declares exact-alarm permission support on Android 12+.
