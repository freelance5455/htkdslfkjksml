
## Geri düyməsi
Android-in geri düyməsi bir addım geri qayıdır: təqdimat → redaktor → ana səhifə. Yalnız ana səhifədə geri basanda tətbiq bağlanır.
APK-nı yenidən qurmaq üçün: `www/` dəyişəndən sonra `npx cap sync android`, sonra Android Studio-da yenidən Build.
