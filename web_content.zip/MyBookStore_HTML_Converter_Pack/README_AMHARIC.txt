MyBookStore — Amharic HTML Converter Pack
==========================================

Book price: 100 ETB
Seller: Workiye Nigusu Cheru (ወርቅዬ ንጉሱ ቸሩ)
Telebirr phone supplied by seller: 0940277822
CBE account supplied by seller: 1000307290247

Files:
- index.html: mobile-friendly Amharic storefront with payment instructions and a payment-reference form.
- book.pdf: the supplied book PDF.

How to use with an HTML-to-APK converter:
1. Extract this ZIP.
2. Choose index.html as the app start page.
3. Keep book.pdf in the same folder/package so the existing PDF preview/link can find it.
4. Build and test the APK on your Android phone.

IMPORTANT LIMITATIONS:
- This is a prototype. The payment form only displays a summary locally; it does not send details to the seller, contact a bank, verify a transfer, or unlock the book.
- The phone number should only be used for Telebirr if it is registered to receive Telebirr payments.
- Never ask buyers for PINs, passwords, or OTP codes.
- Before real sales, connect a secure backend and official merchant payment verification, and store the PDF privately. Do not rely on a screenshot or user-entered transaction reference alone.
- Because book.pdf is included in this package, buyers may be able to extract/copy it. This is not DRM protection.
