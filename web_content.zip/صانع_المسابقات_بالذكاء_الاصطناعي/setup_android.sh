#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"

echo "=== إعداد صانع المسابقات الذكي على Android ==="
echo "سيتم تثبيت Node.js ومكتبات الخادم."
pkg update -y
pkg install nodejs-lts -y || pkg install nodejs -y

echo "تثبيت مكتبات المشروع..."
npm install

if [ ! -f .env ]; then
  echo
  echo "أدخل مفتاح OpenAI API. لن يظهر أثناء الكتابة."
  read -r -s -p "OPENAI_API_KEY: " API_KEY
  echo
  if [ -z "$API_KEY" ]; then
    echo "لم تدخل مفتاحاً. يمكنك لاحقاً نسخ .env.example إلى .env وتعديله."
    cp .env.example .env
  else
    printf 'OPENAI_API_KEY=%s\nOPENAI_MODEL=gpt-6.1-sol\nPORT=3000\n' "$API_KEY" > .env
    chmod 600 .env
    unset API_KEY
  fi
fi

echo
echo "اكتمل الإعداد."
echo "لتشغيل البرنامج نفّذ: bash start_android.sh"
