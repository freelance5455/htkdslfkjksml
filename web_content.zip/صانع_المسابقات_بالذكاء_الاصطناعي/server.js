import express from "express";
import dotenv from "dotenv";

dotenv.config();
const app = express();
app.use(express.json({ limit: "2mb" }));
app.use(express.static("public"));

const PORT = process.env.PORT || 3000;
const MODEL = process.env.OPENAI_MODEL || "gpt-6.1-sol";

const schema = {
  type: "object",
  additionalProperties: false,
  properties: {
    questions: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          type: { type: "string", enum: ["mcq", "tf", "short"] },
          question: { type: "string" },
          options: {
            type: "array",
            items: { type: "string" }
          },
          correct_index: { type: "integer" },
          answer: { type: "string" },
          source_quote: { type: "string" },
          page: { type: "string" }
        },
        required: ["type", "question", "options", "correct_index", "answer", "source_quote", "page"]
      }
    }
  },
  required: ["questions"]
};

function extractOutputText(response) {
  const parts = [];
  for (const item of response.output || []) {
    if (item.type === "message") {
      for (const content of item.content || []) {
        if (content.type === "output_text" && content.text) parts.push(content.text);
        if (content.type === "refusal") throw new Error(content.refusal || "تم رفض الطلب.");
      }
    }
  }
  return parts.join("\n");
}

function validateQuestion(q, requestedType) {
  if (!["mcq", "tf", "short"].includes(q.type)) return false;
  if (requestedType !== "mixed" && q.type !== requestedType) return false;
  if (!q.question?.trim() || !q.answer?.trim() || !q.source_quote?.trim()) return false;
  if (!Array.isArray(q.options)) return false;
  if (q.type === "mcq") {
    if (q.options.length !== 3 || q.options.some(x => !String(x).trim())) return false;
    if (q.correct_index < 0 || q.correct_index > 2) return false;
  }
  if (q.type !== "mcq" && q.correct_index !== 0) return false;
  return true;
}

app.post("/api/generate", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "لم يتم إعداد مفتاح الذكاء الاصطناعي. أضف OPENAI_API_KEY في ملف .env على الخادم، ولا تضعه داخل صفحة HTML." });
    }

    const { title, level, count, type, source } = req.body || {};
    if (!source?.text || !source?.title) return res.status(400).json({ error: "بيانات المصدر ناقصة." });
    if (source.text.length > 65000) return res.status(413).json({ error: "النص كبير جداً لهذه الدفعة. حدد نطاق صفحات أصغر ثم أعد المحاولة." });
    const safeCount = Math.min(40, Math.max(1, Number(count) || 10));
    const chosenTypes = type === "mixed" ? "وزّع الأسئلة بالتساوي قدر الإمكان بين اختيار من متعدد وصح/خطأ وسؤال بإجابة واحدة" :
      type === "mcq" ? "اجعل جميع الأسئلة اختياراً من متعدد بثلاثة خيارات" :
      type === "tf" ? "اجعل جميع الأسئلة من نوع صح أو خطأ" :
      "اجعل جميع الأسئلة سؤالاً مباشراً بإجابة واحدة";

    const instructions = `
أنت محرر مسابقات علمية دقيق. مهمتك إنشاء أسئلة من المصدر المرفق فقط.
قواعد إلزامية:
- لا تستخدم معلومات من خارج النص ولا تكمل النواقص من معرفتك.
- لا تخترع أسماء أو تواريخ أو أحكاماً أو وقائع.
- كل سؤال يجب أن يختبر معلومة واضحة موجودة في النص.
- source_quote يجب أن يكون اقتباساً حرفياً قصيراً من النص المقدم، لا تعِد صياغته.
- page يجب أن يكون رقم الصفحة الظاهر في علامة [الصفحة N] الأقرب للاقتباس. إذا لم تتوفر علامة صفحة فاكتب "غير محددة".
- لا تنشئ سؤالاً إذا لم تجد له اقتباساً داعماً واضحاً.
- امنع تكرار السؤال والمعلومة، حتى لو اختلفت الصياغة.
- أسئلة الاختيار من متعدد: ثلاثة خيارات فقط، متقاربة ومعقولة، لكن خيار واحد فقط صحيح وفق النص. اجعل المشتتات من مفاهيم أو عبارات موجودة في المصدر قدر الإمكان، ولا تجعلها مضللة لغوياً.
- في صح/خطأ: answer يجب أن تكون "صح" أو "خطأ"، وعبارة السؤال يجب أن تكون قابلة للتحقق من النص.
- في السؤال المباشر: إجابة واحدة موجزة ومحددة.
- إذا كان النص لا يدعم العدد المطلوب، أعد فقط الأسئلة المدعومة ولا تملأ العدد بالتخمين.
- مستوى الصعوبة المطلوب: ${level || "متنوع"}.
- ${chosenTypes}.
- أعد JSON مطابقاً للمخطط فقط.
`;

    const input = `عنوان المسابقة: ${title || "مسابقة ثقافية"}\nالمصدر: ${source.title}\nالمؤلف: ${source.author || "غير محدد"}\nعدد الأسئلة المطلوب: ${safeCount}\n\nالنص:\n${source.text}`;

    const apiResponse = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: MODEL,
        instructions,
        input,
        max_output_tokens: 7000,
        text: {
          format: {
            type: "json_schema",
            name: "contest_questions",
            strict: true,
            schema
          }
        }
      })
    });

    const responseBody = await apiResponse.json();
    if (!apiResponse.ok) {
      const message = responseBody?.error?.message || "تعذر الاتصال بخدمة الذكاء الاصطناعي.";
      return res.status(apiResponse.status).json({ error: message });
    }

    const outputText = extractOutputText(responseBody);
    if (!outputText) return res.status(502).json({ error: "لم يرجع محرك الذكاء الاصطناعي نتيجة قابلة للقراءة." });
    const parsed = JSON.parse(outputText);
    const questions = (parsed.questions || []).filter(q => validateQuestion(q, type));
    if (!questions.length) return res.status(422).json({ error: "لم أجد في النص معلومات كافية لإنشاء أسئلة موثقة. جرّب نطاق صفحات آخر أو أضف نصاً أوضح." });

    res.json({ questions, model: MODEL, usage: responseBody.usage || null });
  } catch (error) {
    console.error("generation_error", error);
    res.status(500).json({ error: error.message || "حدث خطأ غير متوقع أثناء إنشاء المسابقة." });
  }
});

app.listen(PORT, () => {
  console.log(`Quiz app ready at http://localhost:${PORT}`);
});
