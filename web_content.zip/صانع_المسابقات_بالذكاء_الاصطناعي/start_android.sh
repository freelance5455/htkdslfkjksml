#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"

if [ ! -f .env ]; then
  echo "ملف .env غير موجود. شغّل setup_android.sh أولاً."
  exit 1
fi

if command -v termux-wake-lock >/dev/null 2>&1; then
  termux-wake-lock || true
fi

echo
echo "صانع المسابقات الذكي يعمل الآن."
echo "افتح متصفح الهاتف وانتقل إلى:"
echo "http://127.0.0.1:3000"
echo
echo "اترك Termux يعمل في الخلفية أثناء استخدام البرنامج."
echo "لإيقاف الخادم اضغط CTRL + C داخل Termux."
echo

node server.js
