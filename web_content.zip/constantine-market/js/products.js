const products=[
{id:1,name:"قميص رجالي كلاسيك",price:4200,category:"ملابس",shop:"Boutique Constantine",emoji:"👔"},
{id:2,name:"حذاء رياضي",price:6500,category:"أحذية",shop:"El Khroub Shoes",emoji:"👟"},
{id:3,name:"عطر شرقي",price:2800,category:"تجميل",shop:"Parfumerie Cirta",emoji:"🌹"},
{id:4,name:"سلة حلويات تقليدية",price:1900,category:"غذاء",shop:"Douceurs du Rocher",emoji:"🍰"},
{id:5,name:"سماعات لاسلكية",price:3900,category:"إلكترونيات",shop:"Tech DZ",emoji:"🎧"},
{id:6,name:"حقيبة نسائية",price:5200,category:"إكسسوارات",shop:"Mode Cirta",emoji:"👜"},
{id:7,name:"فستان نسائي",price:7200,category:"ملابس",shop:"Boutique Cirta",emoji:"👗"},
{id:8,name:"ساعة يد",price:8500,category:"إكسسوارات",shop:"Time Constantine",emoji:"⌚"}
];
const categories=[
["الكل","🛍️"],["ملابس","👕"],["أحذية","👟"],["تجميل","💄"],["غذاء","🍰"],["إلكترونيات","📱"],["إكسسوارات","👜"]
];
const shops=[
["Boutique Constantine","👔","ملابس وأزياء"],
["Tech DZ","📱","هواتف وإلكترونيات"],
["Douceurs du Rocher","🍰","حلويات ومنتجات غذائية"],
["Mode Cirta","👜","إكسسوارات"],
["Parfumerie Cirta","🌹","عطور وتجميل"],
["El Khroub Shoes","👟","أحذية"]
];