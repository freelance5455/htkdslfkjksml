let cart=JSON.parse(localStorage.getItem("cm_cart")||"[]");
let activeCategory="الكل";

const $=id=>document.getElementById(id);
const money=n=>new Intl.NumberFormat("fr-DZ").format(n)+" دج";

function renderCategories(){
  $("categories").innerHTML=categories.map(([name,emoji])=>`<button class="category ${activeCategory===name?"active":""}" onclick="setCategory('${name}')"><span class="emoji">${emoji}</span>${name}</button>`).join("");
}
function renderProducts(){
  let q=$("searchInput").value.trim().toLowerCase();
  let list=products.filter(p=>(activeCategory==="الكل"||p.category===activeCategory)&&(!q||`${p.name} ${p.shop} ${p.category}`.toLowerCase().includes(q)));
  const sort=$("sortSelect").value;
  if(sort==="low") list.sort((a,b)=>a.price-b.price);
  if(sort==="high") list.sort((a,b)=>b.price-a.price);
  $("productGrid").innerHTML=list.length?list.map(p=>`
  <article class="product">
    <div class="product-img">${p.emoji}</div>
    <div class="product-body">
      <small>${p.shop}</small><h3>${p.name}</h3>
      <div class="price">${money(p.price)}</div>
      <button class="add" onclick="addToCart(${p.id})">أضف إلى السلة</button>
    </div>
  </article>`).join(""):`<div class="empty">لا توجد منتجات مطابقة.</div>`;
}
function renderShops(){
 $("shopGrid").innerHTML=shops.map(s=>`<div class="shop"><div class="icon">${s[1]}</div><h3>${s[0]}</h3><small>${s[2]}</small></div>`).join("");
}
function setCategory(c){activeCategory=c;renderCategories();renderProducts();document.getElementById("products").scrollIntoView({behavior:"smooth"});}
function addToCart(id){let item=cart.find(x=>x.id===id);if(item)item.qty++;else cart.push({id,qty:1});saveCart();openCart();}
function saveCart(){localStorage.setItem("cm_cart",JSON.stringify(cart));renderCart();}
function renderCart(){
 $("cartCount").textContent=cart.reduce((s,x)=>s+x.qty,0);
 if(!cart.length){$("cartItems").innerHTML='<div class="empty">السلة فارغة 🛒</div>';$("cartTotal").textContent="0 دج";return}
 let total=0;
 $("cartItems").innerHTML=cart.map(x=>{let p=products.find(p=>p.id===x.id);total+=p.price*x.qty;return `<div class="cart-row"><div><b>${p.name}</b><br><small>${money(p.price)}</small></div><div class="qty"><button onclick="changeQty(${p.id},-1)">−</button><span>${x.qty}</span><button onclick="changeQty(${p.id},1)">+</button></div></div>`}).join("");
 $("cartTotal").textContent=money(total);
}
function changeQty(id,d){let x=cart.find(x=>x.id===id);if(!x)return;x.qty+=d;if(x.qty<=0)cart=cart.filter(i=>i.id!==id);saveCart();}
function openCart(){$("cartPanel").classList.add("open");$("overlay").classList.add("show")}
function closeCart(){$("cartPanel").classList.remove("open");$("overlay").classList.remove("show")}
$("cartBtn").onclick=openCart;$("closeCart").onclick=closeCart;$("overlay").onclick=closeCart;
$("searchInput").oninput=renderProducts;$("searchBtn").onclick=renderProducts;$("sortSelect").onchange=renderProducts;
$("checkoutBtn").onclick=()=>{if(!cart.length)return alert("أضف منتجًا إلى السلة أولاً.");$("checkoutDialog").showModal()};
$("checkoutForm").onsubmit=e=>{e.preventDefault();const fd=new FormData(e.target);const order={id:"CM-"+Date.now(),customer:Object.fromEntries(fd),items:cart,total:cart.reduce((s,x)=>s+(products.find(p=>p.id===x.id).price*x.qty),0),date:new Date().toISOString()};let orders=JSON.parse(localStorage.getItem("cm_orders")||"[]");orders.push(order);localStorage.setItem("cm_orders",JSON.stringify(orders));cart=[];saveCart();e.target.closest("dialog").close();closeCart();alert("تم تسجيل طلبك بنجاح: "+order.id);};
renderCategories();renderProducts();renderShops();renderCart();