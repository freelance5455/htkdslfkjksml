# AsimAI — Mobile, JARVIS and IDE upgrade

## Installation
1. Make a backup of the currently running AsimAI folder.
2. Extract this ZIP into a new folder.
3. Keep the `icons` folder beside `index.html` (do not move the PNG files).
4. Serve the folder from `http://localhost:7700` or an HTTPS website.
5. Open the exact folder URL in Chrome and refresh once.
6. To install, use the visible Install button. If Chrome does not show a native prompt, open Chrome menu (⋮) and choose Install app / Add to Home screen.

PWA installation needs a secure context (HTTPS or localhost), a valid manifest, icons, and a successfully registered service worker. The included service worker now caches shell files independently so one missing optional file will not block installation.

## JARVIS
- JARVIS is voice-only: the microphone is the primary interaction; no text composer or transcript panel is shown.
- JARVIS is ephemeral by design: voice transcripts and AI replies are not written to local storage or chat history.
- Voice replies use concise Roman Urdu / Pakistani Hinglish by default. Speech quality and language availability depend on Android TTS voices and browser speech recognition support.
- Supported commands include opening common sites, opening a supplied website URL, opening the camera, flashlight on/off where the browser exposes camera torch controls, time/date, news search, read last JARVIS reply, stop speaking, and clearing the JARVIS conversation.
- Camera/microphone require permission and HTTPS or localhost. Torch support depends on Android device/browser.
- A website cannot turn off or lock the phone screen. Use the phone's physical power button.
- Opening external apps may open their website instead, depending on Android app links and browser settings.

## IDE
- Existing CodeMirror editor, syntax modes, autocomplete/hints, project explorer, file import/export, preview, Python runtime, console and Auto-Fix remain.
- Additional language modes and runner mappings were added.
- HTML/CSS/JavaScript projects can preview in the browser. Python runs in the browser using Pyodide.
- Other compiled/interpreted languages execute through a Piston-compatible runner that you configure in the IDE. The IDE sends the current project text files (up to 30 files / 2 MB) after asking for confirmation. It cannot provide a browser-native visual preview for every programming language; many languages produce terminal output instead.

## RAG and performance
- Fixed Orama vector search to pass `{ value, property }` in its vector argument.
- RAG no longer loads the embedding model for every normal chat when no PDFs have been indexed. The embedding model loads when PDF indexing is requested.
- The AI provider still determines response speed; network latency and provider quotas are outside the browser app's control.

## Important
- API keys are still stored in browser-side storage in this project. For a public production deployment, move provider calls behind a secure backend.
- JavaScript syntax and package integrity were checked. Live API calls, microphone, torch, camera, PWA installation and external runner execution need to be tested on the actual hosting/device.


## Visual and workflow enhancements in this build
- App-wide white/light workspace with light-orange primary actions.
- Main empty-state logo is now a softly animated 3D orb.
- Upload/paperclip button opens task modes (image analysis, coding, document analysis, research, data analysis, creative work) plus a separate multi-file upload action. Selecting a task inserts an instruction into the chat composer; attach the relevant file where required.
- JARVIS voice panel now matches the white/orange theme.
- IDE receives a professional, touch-first VS Code-inspired visual skin. Its existing CodeMirror editor and tools are retained; this is not a pixel-perfect or feature-identical Microsoft VS Code port.
- Command Center module was removed as explicitly requested. No other existing app module was removed.
- AsimAI's base system prompt now emphasizes accurate, complete, context-aware work and feature preservation.

## AsimAI Pro UI upgrades
- Dedicated History page opens from the main menu; saved main-chat conversations remain available there.
- IDE mobile activity navigation uses four separated touch targets (Files, Editor, Search, Preview).
- Main chat composer outer border is removed while the existing attachment, model compare, prompt, web and send actions remain.
- JARVIS is voice-only and does not save transcripts or replies.
- Dialog corners are sharpened and primary actions use red backgrounds with white labels.
- Added additive upgrade CSS/JS and included both the named HTML entry file and standard index.html.

LATEST PATCH (2026-11-13)
- Added a dedicated History button directly inside the hamburger/sidebar menu.
- History opens as a full-page view and supports reading/reopening, renaming, and deleting saved conversations.
- Removed an accidental literal backslash-n sequence between stylesheet links that was visible at the top of the page.
- Added a Chrome install welcome prompt on preview. The user taps Install app to trigger Chrome's native install sheet.
- Bumped the service-worker shell cache version so deployed browsers can receive the updated files.

PWA INSTALL NOTE
Chrome does not permit websites to force-open its native install sheet without a user gesture. AsimAI now shows its own install invitation automatically in Chrome; tapping Install app invokes the native prompt when Chrome has made it available. PWA installation requires HTTPS or localhost, a valid manifest, and a registered service worker.


ALL-IN-ONE WORKSPACE UPGRADE (2026-11-13)
- Added a dedicated All-in-One Workspace entry in the sidebar.
- Dashboard provides quick access to existing AI Chat, JARVIS, IDE, History, PDF/document knowledge upload, Analytics, Prompt Library and Settings.
- Added saved personal AI instructions. They are stored in the existing browser settings store and appended to future AI system prompts; the text is limited to 4,000 characters.
- Added a local usage overview: saved conversation count, message count, approximate token estimate from saved message text, and configured provider-key count. Token figures are estimates, not provider billing totals.
- Existing modules remain in place; the workspace is an additive navigation and personalization layer.
- Service worker shell cache includes the new script.
- Personal instructions and usage stats remain local; prompts still go to whichever AI provider the user selects. Do not put provider API keys in public frontend code.


LATEST ADDITIVE UPGRADE (2026-11-13)
- Added a searchable IDE Command Palette (Ctrl/Cmd+Shift+P), Quick Open (Ctrl/Cmd+P), and Save All shortcut (Ctrl/Cmd+Shift+S); existing editor actions remain available.
- Added a premium responsive JARVIS command surface and extra voice commands: open workspace, open history, start a new chat, web search, and command help. Existing voice commands and app modules remain.
- Added installation diagnostics for the manifest, icons, secure origin and service worker. The Chrome native install prompt is still controlled by Chrome.
- Added START-ASIMAI.bat (Windows) and START-ASIMAI.sh (Mac/Linux) to serve this folder at localhost:7700. For Chrome install, do not open index.html as file://; use localhost or host the app on HTTPS and open its direct page URL. Embedded previews may not be installable.
- Updated the service-worker cache version and included all new app-shell files.

ASIMAI ULTIMATE ADDITIVE UPGRADE (2026-11-14)
- Added Ultimate Center with a basic Security Center, local workspace snapshot, validated JSON backup/restore, and a human-approved AI task planner that prepares a structured prompt in the existing chat composer.
- Backup exports conversations and settings but deliberately excludes provider API keys. Restore validates the backup format and conversation structure, asks before replacing current conversations, and preserves the currently configured provider keys.
- Removed an unused hardcoded Firebase configuration/API key from app.js. Firebase was not initialized or referenced elsewhere in the client application. If that key was a real credential, rotate/revoke it at the provider console; removing it from this ZIP does not invalidate copies already shared or deployed.
- Bumped the service-worker shell cache to v12 and included the new Ultimate module and stylesheet.
- Security Center checks basic origin/PWA configuration and warns when provider keys are stored in browser settings. It is a diagnostic aid, not a penetration test or substitute for a backend proxy.
- Agent Task Planner prepares instructions only; it does not autonomously execute external/destructive actions.
