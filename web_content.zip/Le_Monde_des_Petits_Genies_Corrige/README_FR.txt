LE MONDE DES PETITS GÉNIES — PROJET ANDROID CORRIGÉ
===================================================

Cette archive contient le code source Android et un lanceur `gradlew` ajouté pour éviter l'erreur « ./gradlew: No such file or directory » dans AndroidIDE.

CONTENU
- 20 mini-jeux éducatifs dans les assets HTML locaux.
- 7 langues : français, anglais, turc, espagnol, chinois simplifié, russe et hindi.
- Pas de SDK publicitaire ni de permission Internet déclarée dans l'application.
- Android Java + WebView locale.
- Configuration Gradle 8.7 / Android Gradle Plugin 8.5.2 / compileSdk 34, pour JDK 17.

INSTALLATION DANS ANDROIDIDE
1. Conserve l'ancien dossier en sauvegarde.
2. Extrais cette archive dans un nouveau dossier.
3. Dans AndroidIDE, ouvre le dossier `Le_Monde_des_Petits_Genies_Corrige` extrait (celui qui contient `settings.gradle`).
4. Si AndroidIDE demande de synchroniser Gradle, accepte et laisse le téléchargement se terminer.
5. Dans le menu ⋮ > Gradle, saisis `assembleDebug`, puis Run.
6. Au premier lancement, `gradlew` peut télécharger Gradle 8.7. Le téléphone doit être connecté à Internet et disposer d'espace libre.
7. Si la compilation réussit, l'APK debug se trouvera dans `app/build/outputs/apk/debug/app-debug.apk`.

IMPORTANT
- Le lanceur personnalisé télécharge la distribution Gradle si aucune commande `gradle` n'est installée. Il a besoin d'un accès réseau et d'un outil `unzip` ou `busybox`.
- Cette archive n'est pas un APK déjà compilé. La compilation doit encore être exécutée sur ton téléphone.
- Si une erreur apparaît, copie le journal complet via « Copy Log » et envoie-le. Ne supprime pas le dossier précédent avant d'avoir confirmé que le nouveau fonctionne.
