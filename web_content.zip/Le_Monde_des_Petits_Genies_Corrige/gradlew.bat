@echo off
set ROOT=%~dp0
if exist "%USERPROFILE%\.gradle\manual-wrapper\gradle-8.7\bin\gradle.bat" (
  call "%USERPROFILE%\.gradle\manual-wrapper\gradle-8.7\bin\gradle.bat" -p "%ROOT%" %*
) else (
  echo Ce paquet utilise un lanceur Gradle simplifie pour AndroidIDE. Sur Windows, ouvrez le projet dans Android Studio pour generer le wrapper standard.
  exit /b 1
)
