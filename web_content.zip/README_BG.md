# LUMA Rituals Premium v29 — прозрачна Android Status Bar

## Какво беше коригирано

В v28 беше зададено `StatusBarOverlaysWebView=true` и се използваше старият `cordova-plugin-statusbar` API, но проектът е на `cordova-android 15.1.0`. При Cordova Android 15 управлението на системната лента е вградено в платформата, а режимът edge-to-edge се включва изрично. Затова v29:

- задава `<preference name="AndroidEdgeToEdge" value="true" />`;
- задава `StatusBarBackgroundColor` на `#00000000` (напълно прозрачен ARGB);
- използва вградената API `window.statusbar.setBackgroundColor('#00000000')` след `deviceready`;
- премахва зависимостта от стария `cordova-plugin-statusbar`, за да не се смесват два механизма за системната лента;
- съдържа `index.html` в корена като входна точка и `www/index.html` за стандартна Cordova компилация.

Официалната документация на Cordova Android 15 описва вградената StatusBar API и `AndroidEdgeToEdge`. Виж: https://cordova.apache.org/announcements/2026/03/06/cordova-android-15.0.0.html

## Важно за APK конвертора

Това са настройки на **нативната Android Status Bar**. Те се прилагат само ако APK компилаторът използва Cordova проекта (чете `config.xml`/`package.json`) или има собствена настройка за прозрачна/overlay status bar. Ако програмата само пакетира уебсайта и игнорира нативната конфигурация, HTML сам по себе си няма право да направи Android системната лента прозрачна. В този случай трябва да се включи в конвертора `Transparent Status Bar` / `Overlay status bar` / `Draw behind status bar`.

## Проверки

- Архивът съдържа `config.xml` и `package.json` в корена, `www/index.html` и `www/assets/`.
- Изображенията са запазени без редактиране.
- Размерът на ZIP пакета е под 5 MB.
- Тази папка не включва готов APK и не е компилирана на физическо устройство.
