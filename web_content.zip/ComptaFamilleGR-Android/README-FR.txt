ComptaFamille GR — projet Android

Ce dossier est un projet Android Studio prêt à compiler, et non un APK déjà compilé.

Pour générer l’APK :
1. Installer Android Studio sur un ordinateur.
2. Ouvrir le dossier ComptaFamilleGR dans Android Studio.
3. Laisser Gradle synchroniser le projet (connexion Internet nécessaire au premier build).
4. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio affichera un lien vers app-debug.apk. Copier ce fichier sur le téléphone et l’ouvrir pour l’installer.

L’application charge l’interface HTML embarquée. JavaScript et DOM storage sont activés pour que localStorage conserve les données localement sur le téléphone. Les bibliothèques CDN de l’interface (si utilisées par la page) nécessitent Internet.

Attention : les données locales peuvent être perdues si l’application est désinstallée ou si les données de l’application sont effacées. Utilisez l’export de sauvegarde dans l’application.
