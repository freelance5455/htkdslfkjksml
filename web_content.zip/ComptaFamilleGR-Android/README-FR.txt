ComptaFamille GR - Projet Android
=================================

Le fichier app/src/main/assets/index.html contient l'interface mise à jour :
- Recettes et dépenses sur la même ligne.
- Trésorerie totale centrée en dessous.
- Cartes de synthèse plus lisibles sur mobile.

IMPORTANT
---------
Ce dossier est le projet source Android, pas un APK déjà compilé.
La compilation nécessite Android Studio (JDK + Android SDK + Gradle) sur un PC.
Aucune synchronisation serveur n'est activée par ce projet : les données restent
locales dans l'application jusqu'à ce que la connexion à une base partagée soit
configurée et testée.

Pour créer un APK avec Android Studio :
1. Ouvrir Android Studio.
2. Choisir « Open » et sélectionner ce dossier.
3. Attendre la synchronisation Gradle et installer les composants Android demandés.
4. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Tester l'APK sur un appareil avant d'utiliser les données réelles.

Ne pas désinstaller une ancienne version avant d'avoir sauvegardé ses données.
