# Th.. — Chat & Create

## A simpler app

Open the app, describe your complete idea, and get original motion graphics directly in the conversation. No template picker, code panel, timeline, inspector, or manual layer setup. Ask for changes in the same chat. Valid generated recipes automatically become playable animations; older versions can be restored.

The app includes a real OpenRouter/OpenAI backend. There is no keyword-based AI imitation and no app watermark or app-branded end card in the video.

### Download your generated animation

Tap **Download video** below the preview. The app records the actual animated canvas in real time. Keep the tab visible. Use **Save video** if your phone blocks the automatic download. WebM is preferred; MP4 is used only if the browser's MediaRecorder advertises support. Video is silent. Phone/browser support varies. Stop a render by tapping its progress button.

## Hosting on Netlify

**Do not deploy just the HTML file or use a static ZIP upload.** The AI requires the included Functions backend.

1. Extract this ZIP and put its contents in a Git repository, preserving folders. `netlify.toml`, `package.json`, `public`, `backend`, and `netlify/functions` belong at the project root.
2. In Netlify use **Add new project → Import an existing project**, then select the repository.
3. Leave build command empty. Publish directory: **public**. Functions directory: **netlify/functions** (both are in the included config).
4. Add these private environment variables with Functions/runtime access:

| Variable | Set privately to |
|---|---|
| `OPENROUTER_API_KEY` | Your valid OpenRouter API key |
| `AI_MODEL` | `liquid/lfm-2.5-2.6b:free`, or another available model supporting JSON output |
| `STUDIO_ACCESS_CODE` | Your own strong private password of at least 16 characters |
| `AI_TIMEOUT_MS` | `50000` |

5. Deploy/redeploy after configuring variables.
6. Open the site's HTTPS URL on your phone. **Unlock studio** with your studio password. Then send your prompt. You don't enter an API key in the app.

For more ambitious compositions you may choose a stronger available model with sufficient API credits. `openrouter/free` also works as a free-model router, but model availability, quality and latency vary. Some free models time out or are rate-limited. The small free model above was tested for a simple original title animation; it does not guarantee premium design quality for every brief. Set your preferred model in the host environment, then redeploy.

For OpenAI instead: leave `OPENROUTER_API_KEY` unset, set `OPENAI_API_KEY`, and use `AI_MODEL=gpt-4.1-mini`. Provider API billing is separate from a chat subscription.

Your temporary sandbox API connection does not transfer into a download. No private key is embedded in this ZIP. Keys previously shared in chat should be rotated and replaced in your host settings. Never commit `.env` or a key to source control.

### Netlify CLI alternative (computer)

Run `npm install`, then `npm run deploy`. Log in and create/link the site. Set environment variables in Netlify and redeploy. The CLI builds/packages Functions; dragging just static files does not.

## Local computer

Install Node.js 20.12 or later. Copy `.env.example` to `.env`, enter your provider key, then run:

```
node start.mjs
```

Open `http://localhost:3000` on that computer. The server binds locally; a phone cannot run it merely by opening the downloaded HTML. Publish the app for phone use.

## What is really rendered

Animated text and uniformly timed captions; interface cards, charts and counters; circles, rings, lines, hexagons, geometric perspective cubes and approximate vector-depth titles; scene/camera movement; uploaded images and silent video layers. These are real timed objects and keyframes rendered by the preview/export engine. No static mockup is passed off as a video.

Not implemented: AI video/image generation, generated voice/music, audio mixing, speech/beat/face analysis, auto cutouts, physical 3D materials, imported 3D models, motion blur, arbitrary generated JavaScript or external rendering code. If your brief needs an unavailable asset/effect, the bot should explain the limitation or ask for uploads. MP4 export is browser-native only where supported, not a server encoder.

## Persistence and privacy

Chat, the current recipe and up to five versions are saved in this browser. Uploaded files remain in memory; after reopening, attach the same original filename/type again to relink its stored reference. They are not uploaded to the AI provider. The provider sees your prompt, scene recipe and asset metadata. Clearing a project removes browser-saved chat/recipe state for this app.

Hosted access uses a signed HttpOnly/Secure two-hour cookie. Changing the access password or provider key invalidates existing cookies. Use a strong password and host-level access controls for larger deployments. This is a single-owner prototype, not a multi-user account/billing system.

Errors, timeouts or invalid replies preserve the previous animation and restore your prompt for retry. Omitted safe recipe defaults are completed server-side, then validated; unsupported types/unsafe references are rejected. Being connected does not override provider quotas or guarantee availability.

## Tests

- `npm test`: offline function tests with a mock provider, no API costs.
- Optional browser tests: install Playwright (`npm install --no-save playwright` and `npx playwright install chromium`), start the local server, then run `node tests/browser-test.cjs` and `node tests/browser-edge-test.cjs`. These intercept AI requests and do not call a paid provider.

Verified in development: clean phone layout; conversational greetings; prompt-to-animation without template/approval steps; changing rendered frames; video rendering/downloading; failed/malformed response recovery; version persistence; uploaded-file relinking; render cancellation; no browser runtime exceptions in tested flows. A real OpenRouter title animation was generated and downloaded through the password-protected phone URL. Netlify authentication/routing/function behavior was tested locally; this project has not been deployed into your Netlify account.
