# Vérification — CGD V117 Socle 3.5

## Ajouts
- Progression quotidienne du manager, un jour par activation de CONTINUER.
- Blocage conservé pour les messages exigeant une réponse et les matchs du club dirigé.
- Lorsqu'un événement de compétition est rencontré, les rencontres IA sont traitées par le calendrier central ; le match du club reste réservé.
- Administration du club : trésorerie, budgets prévisionnels, installations, registre du staff et délégations.
- Domaines de confiance du conseil, objectifs de saison et dépôt de demandes au conseil.
- Prévisions de recettes et charges à zéro par défaut : aucune somme fictive n'est débitée sans réglage du manager.

## Vérifications
- Tests automatisés : 205 réussis, 0 échec.
- Syntaxe JavaScript : `src/app.js` et `src/manager-office.js` validées avec `node --check`.
- Comparaison avec Socle 3.4 : 15 moteurs et modules du jeu de dames/calendrier identiques.
- Vérification de l'archive ZIP : effectuée après génération.

## Limites explicites
- Les offres d'emploi du mode sans emploi ne sont pas encore raccordées.
- Le conseil enregistre les demandes ; la décision automatique et l'application des budgets/installations seront approfondies dans une étape ultérieure.
- Les coûts et recettes quotidiennes sont configurables et n'ont pas de valeurs arbitraires par défaut.
- Le rendu réel sur appareil mobile n'a pas été validé visuellement dans cette exécution.
