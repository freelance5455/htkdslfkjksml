SKIN VOICES / صدای فریاد اسکین‌ها
==================================

When a skin is in its FINAL form and touches a trap, the shield breaks and the
character screams. The game looks for a recording in this folder first:

    voices/<name>.mp3     (also tried: .ogg, .wav, .m4a)

If the file does not exist, a synthesized stand-in scream is played instead,
so every skin still shouts.

File names (skin order in the game):
    naruto   luffy   goku    tanjiro
    deku     ichigo  zoro    edward
    sailor   eren    gojo    sasuke
    spark    saitama pink    ice

Example:
    voices/naruto.mp3   -> played when Naruto's shield breaks
    voices/goku.mp3     -> played when Goku's Ultra Instinct form breaks

Tips:
- Keep each clip short (1-3 seconds); anything longer than ~3.7 s is cut off.
- Only use audio you have the right to use (your own recordings or licensed clips).
- Volume follows the game's Master x SFX sliders; Mute silences it.
- For the Android build, run `npm run web` again so the voices/ folder is copied.
