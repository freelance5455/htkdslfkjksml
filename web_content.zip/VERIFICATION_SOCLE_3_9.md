# Vérification — Socle 3.9

- Tests automatisés : 228 réussis, 0 échec.
- Vérification syntaxique : `node --check` sur tous les fichiers JavaScript de `src/` et `tests/` réussie.
- Quatre tests supplémentaires dédiés à l'animation du public et à la caméra cinématique.
- Le rendu reste fondé sur WebGL et conserve les fonctions existantes `animateMove` et `playPose`.
- Aucun moteur de compétition ni fichier de règles de dames n'a été modifié dans ce socle.
- Test visuel réel sur navigateur/appareil mobile : non effectué.
