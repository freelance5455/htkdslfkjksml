create table if not exists public.servicar_datos (
  code text primary key,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.servicar_datos enable row level security;
revoke all on public.servicar_datos from anon, authenticated;

create or replace function public.sv_leer(p_code text)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if p_code is null or length(p_code) < 24 then raise exception 'codigo invalido'; end if;
  return (select jsonb_build_object('data', data, 'updated_at', updated_at) from public.servicar_datos where code = p_code);
end $$;

create or replace function public.sv_guardar(p_code text, p_data jsonb)
returns timestamptz language plpgsql security definer set search_path = public as $$
declare t timestamptz := now();
begin
  if p_code is null or length(p_code) < 24 then raise exception 'codigo invalido'; end if;
  insert into public.servicar_datos(code, data, updated_at) values (p_code, p_data, t)
  on conflict (code) do update set data = excluded.data, updated_at = t;
  return t;
end $$;

grant execute on function public.sv_leer(text) to anon;
grant execute on function public.sv_guardar(text, jsonb) to anon;
