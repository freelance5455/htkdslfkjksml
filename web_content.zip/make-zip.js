import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

const zip = new JSZip();
const ROOT_DIR = process.cwd();

const EXCLUDE_DIRS = new Set(['node_modules', '.git', '.playwright-cli', 'dist']);

function addDirectoryToZip(currentDir, currentZipFolder) {
  const files = fs.readdirSync(currentDir);
  for (const file of files) {
    if (EXCLUDE_DIRS.has(file)) continue;
    if (file.endsWith('.zip')) continue;

    const fullPath = path.join(currentDir, file);
    const stat = fs.statSync(fullPath);

    if (stat.isDirectory()) {
      const subFolder = currentZipFolder.folder(file);
      addDirectoryToZip(fullPath, subFolder);
    } else {
      const fileData = fs.readFileSync(fullPath);
      currentZipFolder.file(file, fileData);
    }
  }
}

console.log('Packaging BD BLOOD DONATION into bd-blood-donation.zip...');
addDirectoryToZip(ROOT_DIR, zip);

zip.generateNodeStream({ type: 'nodebuffer', streamFiles: true })
  .pipe(fs.createWriteStream('bd-blood-donation.zip'))
  .on('finish', () => {
    const size = fs.statSync('bd-blood-donation.zip').size;
    console.log(`Successfully generated bd-blood-donation.zip (${(size / 1024).toFixed(1)} KB)`);
  });
