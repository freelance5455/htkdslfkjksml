#!/bin/bash
# GPU 1.0.1 - Comandos limpos com 2>/dev/null || true
echo "Aplicando GPU 1.0.1..."

setprop debug.performance.tuning 1 2>/dev/null || true
setprop debug.hwui.renderer skiagl 2>/dev/null || true
setprop debug.egl.hw 1 2>/dev/null || true
setprop debug.sf.hw 1 2>/dev/null || true
setprop persist.sys.ui.hw 1 2>/dev/null || true
setprop debug.composition.type gpu 2>/dev/null || true
setprop hw3d.force 1 2>/dev/null || true
setprop video.accelerate.hw 1 2>/dev/null || true

echo "GPU 1.0.1 aplicado!"
