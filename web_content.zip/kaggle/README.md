# GODEX P5.10 — Dedicated Kaggle GPU Worker Architecture

This directory contains the authoritative Kaggle GPU worker script and Jupyter Notebook for running AI video diffusion models (e.g. `damo-vilab/text-to-video-ms-1.7b`) on Kaggle GPU instances (T4 x2 or P100).

## Files:
- `godex_kaggle_gpu_worker.ipynb`: Interactive Jupyter Notebook ready for Kaggle Notebooks.
- `godex_kaggle_gpu_worker.py`: Standalone CLI worker script.

## Setup Instructions on Kaggle:
1. Go to [kaggle.com/code](https://www.kaggle.com/code) and click **New Notebook**.
2. Click **File** > **Import Notebook** and upload `godex_kaggle_gpu_worker.ipynb`.
3. In the Notebook Settings sidebar on the right:
   - Set **Accelerator** to **GPU T4 x2** (or **GPU P100**).
   - Set **Internet** to **On**.
4. Set the `GODEX_ENDPOINT` variable to your active GODEX development URL.
5. Run the cells to launch inference and upload verified MP4 binaries back to GODEX.
