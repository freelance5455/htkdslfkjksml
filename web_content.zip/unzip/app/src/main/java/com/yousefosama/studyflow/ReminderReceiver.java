package com.yousefosama.studyflow;

import android.Manifest;
import android.app.BroadcastReceiver;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import androidx.core.app.NotificationCompat;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        String timerMode = intent.getStringExtra("timerMode");
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if ("focus".equals(timerMode) || "break".equals(timerMode)) {
            boolean focus = "focus".equals(timerMode);
            String channel = focus ? MainActivity.TIMER_FOCUS_CHANNEL_ID : MainActivity.TIMER_BREAK_CHANNEL_ID;
            String title = focus ? "انتهى وقت المذاكرة" : "انتهى وقت البريك";
            String message = focus ? "حان وقت البريك. خُد راحة قصيرة." : "البريك خلص. جاهز لجلسة مذاكرة جديدة؟";
            NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channel)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title).setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true);
            nm.notify(focus ? 2001 : 2002, builder.build());
            return;
        }

        String id = intent.getStringExtra("id");
        String title = intent.getStringExtra("title");
        String message = intent.getStringExtra("message");
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, MainActivity.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title == null || title.isEmpty() ? "StudyFlow" : title)
            .setContentText(message == null || message.isEmpty() ? "حان وقت المذاكرة" : message)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT).setAutoCancel(true);
        nm.notify(id == null ? 1 : Math.abs(id.hashCode()), builder.build());
        if (id != null) context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE).edit().remove(id).apply();
    }
}
