# GoalPulse Android v1.1

Existing GoalPulse screens retained. Added API-Football key field in Settings and native Android networking for live scores.
Open Settings > API-Football key, enter your own key and save. Open Matches to load live scores.
The app refreshes every 60 seconds while Matches is open.
The API key is stored locally on this device. Do not share your key or distribute an APK containing your personal key.
