# GoalPulse Android

Android Studio project wrapping the GoalPulse mobile web UI in a native Android WebView.

## Build APK
Open this folder in Android Studio, let Gradle sync, then choose Build > Build APK(s).
The debug APK will be under app/build/outputs/apk/debug/.

## Important
This APK currently contains the GoalPulse UI/demo. Live API-Football data must be served through the GoalPulse backend. Do NOT put the API-Football secret key in the APK or in index.html. Keep it on the backend.
