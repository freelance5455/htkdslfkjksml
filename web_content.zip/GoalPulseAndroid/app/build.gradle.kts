plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.goalpulse.app"; compileSdk = 35
    defaultConfig { applicationId = "com.goalpulse.app"; minSdk = 23; targetSdk = 35; versionCode = 2; versionName = "1.1" }
}
