package com.goalpulse.app

import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.webkit.JavascriptInterface
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView

    inner class GoalPulseBridge {
        @JavascriptInterface
        fun getLiveScores(apiKey: String) {
            thread {
                try {
                    val conn = URL("https://v3.football.api-sports.io/fixtures?live=all").openConnection() as HttpURLConnection
                    conn.requestMethod = "GET"
                    conn.setRequestProperty("x-apisports-key", apiKey)
                    conn.connectTimeout = 15000
                    conn.readTimeout = 20000
                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val body = stream.bufferedReader().use { it.readText() }
                    val safeBody = JSONObject.quote(body)
                    runOnUiThread {
                        if (code in 200..299) {
                            web.evaluateJavascript("receiveLiveScores($safeBody)", null)
                        } else {
                            web.evaluateJavascript("receiveLiveError('API request failed: HTTP $code')", null)
                        }
                    }
                    conn.disconnect()
                } catch (e: Exception) {
                    val safeMessage = JSONObject.quote(e.message ?: "Network error")
                    runOnUiThread { web.evaluateJavascript("receiveLiveError($safeMessage)", null) }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.webViewClient = WebViewClient()
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.addJavascriptInterface(GoalPulseBridge(), "GoalPulseBridge")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }
}
