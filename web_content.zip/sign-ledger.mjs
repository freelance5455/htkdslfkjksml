// node tools/sign-ledger.mjs ledger/ledger.json   (uses env LEDGER_PRIVATE_KEY or ./ledger_private.pem) -> writes ledger/ledger.json.sig
import { sign, createPrivateKey } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
const file = process.argv[2]; if (!file) { console.error("usage: sign-ledger.mjs <file>"); process.exit(1); }
const pem = process.env.LEDGER_PRIVATE_KEY || readFileSync("ledger_private.pem", "utf8");
const data = readFileSync(file); // sign the exact bytes the app will download
JSON.parse(data.toString("utf8")); // refuse to sign invalid JSON
writeFileSync(file + ".sig", sign(null, data, createPrivateKey(pem)).toString("base64") + "\n");
console.log("signed", file);
