SensiPlay - projeto Android

Este projeto empacota o HTML original em um aplicativo Android usando WebView.
JavaScript e armazenamento local estão habilitados para preservar as funções e os perfis salvos.

COMO GERAR O APK:
1. Instale o Android Studio em um computador.
2. Abra a pasta SensiPlayAndroid no Android Studio.
3. Aguarde a sincronização do Gradle e a instalação do Android SDK 35, se solicitado.
4. Selecione Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de teste será gerado em app/build/outputs/apk/debug/app-debug.apk.

Observação: este ambiente não possui Android SDK/Gradle instalado, portanto o APK binário não pode ser compilado aqui. O HTML original está em app/src/main/assets/index.html.
