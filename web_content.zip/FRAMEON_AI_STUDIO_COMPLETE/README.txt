FRAMEON AI STUDIO — LIGHT UI UPDATE

This package is a mobile-friendly app-style prototype (PWA/WebView source), with a clean white and light-blue interface. It is not an APK by itself.

WHAT CHANGED
- Premium white-first, light-blue interface.
- Clearer, simpler labels for beginners.
- Main entry is “AI Video Generation”.
- Prompt flow creates an editable scene plan and then shows scenes in the editing workspace.
- Duration choices include 15 seconds, 30 seconds, 1, 2, 5 and 10 minutes.
- Existing media import, basic timeline, clip inspector, project JSON save/export, payment QR option, and AI Customer Care UI are retained.

IMPORTANT HONEST LIMITATIONS
- Prompt generation currently makes a local editable storyboard/scene plan, NOT real AI-generated video clips.
- 10-minute choice sets a project/storyboard duration; it does NOT mean this prototype can render a finished 10-minute video.
- Real text-to-video needs a video-generation provider API and server-side job handling.
- Finished MP4 export needs a rendering pipeline (for example, server-side FFmpeg or a suitable cloud renderer).
- AI Customer Care needs this Node.js backend hosted and OPENAI_API_KEY configured.
- Payment QR is a manual payment display only. Secure subscription activation needs a payment gateway and server-side verification.
- Account login, cloud project storage, production security and billing are not fully implemented.

RUN AI CUSTOMER CARE LOCALLY (Node.js 18+)
1. Set OPENAI_API_KEY as an environment variable. Do not put the key in index.html.
2. Run: npm start
3. Open http://localhost:3000

The package is a prototype foundation, not a finished competitor to After Effects, DaVinci Resolve, CapCut or Filmora. Add and test real providers before charging users.
