// FRAMEON AI Studio support backend starter. Requires Node.js 18+.
// Keep OPENAI_API_KEY on the server; never place it in index.html.
const http = require('http');
const fs = require('fs');
const path = require('path');
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const MIME = {'.html':'text/html; charset=utf-8','.css':'text/css','.js':'text/javascript','.json':'application/json','.jpg':'image/jpeg','.png':'image/png','.webp':'image/webp','.svg':'image/svg+xml'};

function send(res, status, body, type='application/json; charset=utf-8') { res.writeHead(status, {'Content-Type':type,'Cache-Control':'no-store'}); res.end(typeof body === 'string' ? body : JSON.stringify(body)); }
const server = http.createServer(async (req,res) => {
  if (req.method === 'POST' && req.url === '/api/support-chat') {
    if (!process.env.OPENAI_API_KEY) return send(res, 503, {error:'AI support is not configured yet. The owner must set OPENAI_API_KEY on the server.'});
    let raw=''; req.on('data',chunk=>{raw+=chunk;if(raw.length>50000){req.destroy();}});
    req.on('end', async () => {
      try {
        const input=JSON.parse(raw||'{}');
        const messages=Array.isArray(input.messages)?input.messages.slice(-12):[];
        const safeMessages=messages.filter(m=>['user','assistant'].includes(m.role)&&typeof m.content==='string').map(m=>({role:m.role,content:m.content.slice(0,4000)}));
        if(!safeMessages.length) return send(res,400,{error:'Please send a question.'});
        const response=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'Authorization':`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-4.1-mini',instructions:'You are FRAMEON AI STUDIO Customer Care. Help users understand the app, editing workflow, project setup, troubleshooting, supported features, and payment/account process. Be clear, friendly, and step-by-step for beginners. Never claim a feature works if it is not confirmed. The current starter has local project/storyboard tools and a basic timeline, but real AI video generation, cloud accounts, verified payments, and MP4 rendering require separate integrations. Do not ask for passwords, API keys, payment PINs, or full card details. For payment disputes, advise contacting the official support channel and checking their payment app. Explain that this is AI support, not a human agent. Reply in the language the user uses.',input:safeMessages,max_output_tokens:700}),});
        const data=await response.json();
        if(!response.ok) return send(res,response.status,{error:data.error?.message||'OpenAI request failed'});
        let reply='';
        if(Array.isArray(data.output)) for(const item of data.output) if(item.type==='message'&&Array.isArray(item.content)) for(const c of item.content) if(c.type==='output_text') reply+=c.text;
        return send(res,200,{reply:reply||'Sorry, I could not generate a reply.'});
      } catch(e) { return send(res,500,{error:'Could not contact AI support. Check server logs and API configuration.'}); }
    }); return;
  }
  if(req.method!=='GET'&&req.method!=='HEAD') return send(res,405,{error:'Method not allowed'});
  let urlPath=decodeURIComponent((req.url||'/').split('?')[0]); if(urlPath==='/')urlPath='/index.html';
  const full=path.resolve(ROOT,'.'+urlPath); if(!full.startsWith(ROOT+path.sep)&&full!==path.join(ROOT,'index.html'))return send(res,403,{error:'Forbidden'});
  fs.readFile(full,(err,buf)=>{if(err)return send(res,404,{error:'Not found'});res.writeHead(200,{'Content-Type':MIME[path.extname(full)]||'application/octet-stream'});res.end(buf);});
});
server.listen(PORT,()=>console.log(`FRAMEON AI Studio running on http://localhost:${PORT}`));
