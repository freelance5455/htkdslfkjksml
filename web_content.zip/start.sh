#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo "========================================"
echo "       KARTINO - Offline Server"
echo "========================================"
python3 build.py 2>/dev/null || true
export ADMIN_PASSWORD="${ADMIN_PASSWORD:-kartinoasmin}"
export ADMIN_USERNAME="${ADMIN_USERNAME:-mahdi689}"
echo "Admin: $ADMIN_USERNAME / $ADMIN_PASSWORD"
echo "Open:  http://localhost:8080"
echo ""
node server.js
