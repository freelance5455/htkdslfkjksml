#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
if ! command -v python >/dev/null 2>&1; then
  echo "Python غير مثبت. شغّل install.sh أولًا."
  exit 1
fi
echo "BOT VODEKA — أدخل التوكن الجديد الذي أنشأته بعد إلغاء القديم."
echo "لن يتم حفظ التوكن داخل ملفات المشروع."
read -rsp "Bot Token: " BOT_TOKEN
echo
if [ -z "$BOT_TOKEN" ]; then echo "لم تدخل توكن."; exit 1; fi
export BOT_TOKEN
python monitor.py
