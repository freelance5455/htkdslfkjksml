#!/bin/bash
echo ""
echo "╔══════════════════════════════════════╗"
echo "║      ASION AI - Google Agent         ║"
echo "║   Ollama + Puppeteer + Node.js       ║"
echo "╚══════════════════════════════════════╝"
echo ""

# Cek Node.js
if ! command -v node &> /dev/null; then
    echo "[ERROR] Node.js tidak ditemukan!"
    echo "Install: sudo apt install nodejs npm  (Linux)"
    echo "         brew install node            (Mac)"
    exit 1
fi

# Cek Ollama
if ! command -v ollama &> /dev/null; then
    echo "[ERROR] Ollama tidak ditemukan!"
    echo "Install: curl -fsSL https://ollama.com/install.sh | sh"
    exit 1
fi

echo "[1/4] Memulai Ollama di background..."
ollama serve &>/dev/null &
sleep 3

echo "[2/4] Menarik model qwen2.5:7b..."
ollama pull qwen2.5:7b

echo "[3/4] Install dependensi..."
if [ ! -d "node_modules" ]; then
    npm install
    npx puppeteer browsers install chrome
fi

echo "[4/4] Menjalankan server..."
echo ""
echo "  Server: http://localhost:3000"
echo "  Tekan Ctrl+C untuk berhenti"
echo ""
node server.js
