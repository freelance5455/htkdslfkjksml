NUMBER SCROLL ULTIMATE v11 — GLOBAL BROADCAST

Added:
- Fully custom global announcements from Staff panel.
- Custom title, unlimited-style long text up to 600 chars, type, duration and button label.
- Persistent global announcement stored in localStorage for all local accounts on the same browser/device.
- Event creator remains available with custom title/description, multiplier, duration, country and region.

IMPORTANT: This build is still offline/localStorage. "All players" means all accounts in the same local game instance. True cross-device broadcast requires a server/database/WebSocket backend.
