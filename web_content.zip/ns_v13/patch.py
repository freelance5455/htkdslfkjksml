from pathlib import Path
p=Path('/mnt/data/nswork/index.html')
s=p.read_text(encoding='utf-8')
# 1 CSS variables and richer visual effects
s=s.replace('html,body{margin:0;min-height:100%;background:#060a0f;color:#f3f7fa;font-family:Arial,sans-serif}', ''':root{--accent:#6de7ff;--accent2:#8effc2;--hot:#9b7cff;--bg:#060a0f;--panel:#101b25;--panel2:#0a131b;--line:#ffffff14;--text:#f3f7fa;--muted:#78909e}
html,body{margin:0;min-height:100%;background:var(--bg);color:var(--text);font-family:Arial,sans-serif;transition:background .45s,color .45s}''')
s=s.replace(' radial-gradient(circle at 50% 0%,#254b62 0,#101b26 34%,#060a0f 72%);', ' radial-gradient(circle at 50% 0%,color-mix(in srgb,var(--accent) 24%,#101b26) 0,#101b26 34%,var(--bg) 72%);')
s=s.replace('.primary{width:100%;height:53px;', '.primary{width:100%;height:53px;position:relative;overflow:hidden;transition:transform .18s,box-shadow .25s;')
s=s.replace('.note{font-size:10px;', '.primary:hover{transform:translateY(-2px);box-shadow:0 16px 45px color-mix(in srgb,var(--accent) 35%,transparent)}.primary:active{transform:scale(.985)}\n.note{font-size:10px;')
s=s.replace('.plate{height:190px;', '.plate{height:190px;transform-style:preserve-3d;transition:transform .45s,filter .45s,box-shadow .45s;')
s=s.replace('.plate.flash:after{transform:translateX(75%) rotate(8deg)}', '''.plate.flash:after{transform:translateX(75%) rotate(8deg)}
.plate.rolling{animation:plateRoll .34s ease-in-out infinite alternate;filter:saturate(1.25) brightness(1.08);box-shadow:0 20px 70px #000b,0 0 0 2px color-mix(in srgb,var(--accent) 55%,#fff),0 0 45px color-mix(in srgb,var(--accent) 28%,transparent),inset 0 0 0 2px #b5bec5}
.plate.rolling .country,.plate.rolling .region,.plate.rolling .reel{animation:plateParts .22s ease-in-out infinite alternate}
@keyframes plateRoll{from{transform:perspective(900px) rotateX(0deg) rotateY(-1deg) scale(1)}to{transform:perspective(900px) rotateX(1.4deg) rotateY(1.4deg) scale(1.012)}}
@keyframes plateParts{from{transform:translateY(-3px) scale(.99)}to{transform:translateY(3px) scale(1.01)}}''')
s=s.replace('.admin-tools{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:12px}', '''.admin-tools{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:12px}
.admin-section{margin-top:14px;padding:14px;border:1px solid #ffffff10;background:#081119aa;border-radius:16px}.admin-section h3{margin:0 0 8px;font-size:12px}.admin-actions{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.theme-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:7px}.theme-btn{height:38px;border:1px solid #ffffff18;border-radius:11px;color:#fff;font-size:9px;font-weight:900}.theme-btn.cyan{background:linear-gradient(135deg,#123746,#1c8ca3)}.theme-btn.violet{background:linear-gradient(135deg,#241c46,#7955d9)}.theme-btn.red{background:linear-gradient(135deg,#45151d,#d33b55)}.theme-btn.gold{background:linear-gradient(135deg,#45300e,#d6a83b)}.theme-btn.green{background:linear-gradient(135deg,#123d2d,#27b777)}
.generator-controls{display:grid;grid-template-columns:1fr 1fr 1.25fr;gap:8px;margin-top:12px}.selectbox{width:100%;height:44px;border:1px solid #ffffff14;background:#0a151e;color:#dce8ed;border-radius:12px;padding:0 10px;font-size:11px;font-weight:800;outline:none}.selectbox:focus{border-color:color-mix(in srgb,var(--accent) 60%,transparent)}.plate-mode{display:flex;align-items:center;justify-content:space-between;padding:0 11px;background:#0a151e;border:1px solid #ffffff14;border-radius:12px;font-size:10px;color:#9bb0bc}.plate-mode label{display:flex;gap:7px;align-items:center}.plate-mode input{accent-color:var(--accent)}''')
s=s.replace('@media(max-width:470px){.shell{padding:12px}', '@media(max-width:470px){.shell{padding:12px}.generator-controls{grid-template-columns:1fr 1fr}.plate-mode{grid-column:1/-1}')
# 2 constants / region data
old='const REGIONS=["01","02","05","07","16","18","22","23","24","25","26","27","29","30","31","32","33","34","35","36","37","38","39","40","41","42","43","44","45","46","47","48","49","50","51","52","53","54","55","56","57","58","59","60","61","62","63","64","65","66","67","68","69","70","71","72","73","74","75","76","77","78","79","80","82","83","86","87","89","90","91","92","93","94","95","96","97","98","99"];'
new='''const RU_REGION_DATA=[
["01","Адыгея"],["02","Башкортостан"],["03","Бурятия"],["04","Алтай"],["05","Дагестан"],["06","Ингушетия"],["07","Кабардино-Балкария"],["08","Калмыкия"],["09","Карачаево-Черкесия"],["10","Карелия"],["11","Коми"],["12","Марий Эл"],["13","Мордовия"],["14","Саха (Якутия)"],["15","Северная Осетия"],["16","Татарстан"],["17","Тыва"],["18","Удмуртия"],["19","Хакасия"],["20","Чечня"],["21","Чувашия"],["22","Алтайский край"],["23","Краснодарский край"],["24","Красноярский край"],["25","Приморский край"],["26","Ставропольский край"],["27","Хабаровский край"],["28","Амурская область"],["29","Архангельская область"],["30","Астраханская область"],["31","Белгородская область"],["32","Брянская область"],["33","Владимирская область"],["34","Волгоградская область"],["35","Вологодская область"],["36","Воронежская область"],["37","Ивановская область"],["38","Иркутская область"],["39","Калининградская область"],["40","Калужская область"],["41","Камчатский край"],["42","Кемеровская область"],["43","Кировская область"],["44","Костромская область"],["45","Курганская область"],["46","Курская область"],["47","Ленинградская область"],["48","Липецкая область"],["49","Магаданская область"],["50","Московская область"],["51","Мурманская область"],["52","Нижегородская область"],["53","Новгородская область"],["54","Новосибирская область"],["55","Омская область"],["56","Оренбургская область"],["57","Орловская область"],["58","Пензенская область"],["59","Пермский край"],["60","Псковская область"],["61","Ростовская область"],["62","Рязанская область"],["63","Самарская область"],["64","Саратовская область"],["65","Сахалинская область"],["66","Свердловская область"],["67","Смоленская область"],["68","Тамбовская область"],["69","Тверская область"],["70","Томская область"],["71","Тульская область"],["72","Тюменская область"],["73","Ульяновская область"],["74","Челябинская область"],["75","Забайкальский край"],["76","Ярославская область"],["77","Москва"],["78","Санкт-Петербург"],["79","Еврейская АО"],["80","Забайкальский край"],["81","Пермский край"],["82","Крым"],["83","Ненецкий АО"],["84","Красноярский край"],["85","Иркутская область"],["86","Ханты-Мансийский АО"],["87","Чукотский АО"],["88","Красноярский край"],["89","Ямало-Ненецкий АО"],["90","Московская область"],["91","Калининградская область"],["92","Севастополь"],["93","Краснодарский край"],["94","Территории за пределами РФ"],["95","Чечня"],["96","Свердловская область"],["97","Москва"],["98","Санкт-Петербург"],["99","Москва"]];
const REGIONS=RU_REGION_DATA.map(x=>x[0]);
const BY_REGION_DATA=[["1","Брестская область"],["2","Витебская область"],["3","Гомельская область"],["4","Гродненская область"],["5","Минская область"],["6","Могилёвская область"],["7","Минск"],["8","Минск — резервный код"]];'''
s=s.replace(old,new)
s=s.replace('const BY_REGIONS=["1","2","3","4","5","6","7","8"];','const BY_REGIONS=BY_REGION_DATA.map(x=>x[0]);\nlet selectedCountry="RU",selectedRegion="RANDOM";')
# 3 generation and formatting
s=s.replace('function make(){return {type:"RU",a:pick(LETTERS),n:String(Math.floor(Math.random()*1000)).padStart(3,"0"),b:pick(LETTERS),c:pick(LETTERS),r:pick(REGIONS)}}\nfunction makeBelarus(){\n  return {type:"BY",a:String(Math.floor(Math.random()*10)),n:String(Math.floor(Math.random()*1000)).padStart(3,"0"),b:pick(BY_LETTERS),c:pick(BY_LETTERS),r:pick(BY_REGIONS)};\n}\nfunction makeForRoll(){return user().rolls>=BELARUS_UNLOCK_ROLLS?makeBelarus():make()}', '''function randomRURegion(){return selectedRegion!=="RANDOM"&&selectedCountry==="RU"?selectedRegion:pick(REGIONS)}
function randomBYRegion(){return selectedRegion!=="RANDOM"&&selectedCountry==="BY"?selectedRegion:pick(BY_REGIONS)}
function make(){return {type:"RU",a:pick(LETTERS),n:String(Math.floor(Math.random()*1000)).padStart(3,"0"),b:pick(LETTERS),c:pick(LETTERS),r:randomRURegion()}}
function makeBelarus(){return {type:"BY",a:String(Math.floor(Math.random()*10)),n:String(Math.floor(Math.random()*1000)).padStart(3,"0"),b:pick(BY_LETTERS),c:pick(BY_LETTERS),r:randomBYRegion()};}
function makeForRoll(){return selectedCountry==="BY"?makeBelarus():make()}''')
# 4 add controls to generator
needle='''        <div class="muted">Прокрути барабаны и реши, оставить номер или продолжить поиск.</div>\n        <div class="plate" id="plate">'''
rep='''        <div class="muted">Выбери страну и любой доступный регион. При выбивании анимируется вся номерная рамка.</div>
        <div class="generator-controls">
          <select id="countrySelect" class="selectbox"><option value="RU">🇷🇺 Россия</option><option value="BY">🇧🇾 Беларусь</option></select>
          <select id="regionSelect" class="selectbox"><option value="RANDOM">🎲 Любой регион</option></select>
          <div class="plate-mode"><label><input id="fullAnim" type="checkbox" checked> Полная анимация</label><span id="regionHint">Регион: случайный</span></div>
        </div>
        <div class="plate" id="plate">'''
s=s.replace(needle,rep)
# 5 admin HTML
oldadmin='''      <div class="admin-tools">
        <button class="smallbtn" id="giftItem" type="button">Выдать предмет</button>
        <button class="smallbtn" id="resetStats" type="button">Сбросить статистику</button>
        <button class="smallbtn" id="refreshAdmin" type="button">Обновить панель</button>
      </div>'''
newadmin='''      <div class="admin-tools">
        <button class="smallbtn" id="giftItem" type="button">Выдать предмет</button>
        <button class="smallbtn" id="grantMoney" type="button">Выдать BYN</button>
        <button class="smallbtn" id="setLevel" type="button">Установить уровень</button>
        <button class="smallbtn" id="resetStats" type="button">Сбросить статистику</button>
        <button class="smallbtn" id="refreshAdmin" type="button">Обновить панель</button>
      </div>
      <div class="admin-section"><h3>🎨 ЦЕНТР ОФОРМЛЕНИЯ</h3><div class="muted" style="margin-bottom:9px">Цветовая тема применяется ко всему приложению и сохраняется.</div><div class="theme-grid">
        <button class="theme-btn cyan" data-theme="cyan">CYAN</button><button class="theme-btn violet" data-theme="violet">VIOLET</button><button class="theme-btn red" data-theme="red">CRIMSON</button><button class="theme-btn gold" data-theme="gold">GOLD</button><button class="theme-btn green" data-theme="green">EMERALD</button>
      </div></div>
      <div class="admin-section"><h3>🛠 УПРАВЛЕНИЕ ИГРОЙ</h3><div class="admin-actions">
        <button class="smallbtn" id="adminAddEvent" type="button">Создать событие</button><button class="smallbtn" id="adminEconomy" type="button">Бонус экономики</button><button class="smallbtn" id="adminClearSaves" type="button">Очистить номера игрока</button>
      </div></div>'''
s=s.replace(oldadmin,newadmin)
# 6 initialize controls after initDB
needle='initDB();\n\nfunction getSession()'
rep='''initDB();
function populateRegions(){
  const sel=$("#regionSelect"); if(!sel)return; sel.innerHTML='<option value="RANDOM">🎲 Любой регион</option>';
  const data=selectedCountry==="BY"?BY_REGION_DATA:RU_REGION_DATA;
  data.forEach(([code,name])=>{const o=document.createElement("option");o.value=code;o.textContent=code+" — "+name;sel.appendChild(o)});
  sel.value=selectedRegion="RANDOM"; $("#regionHint").textContent="Регион: случайный";
}
function applyTheme(name){
 const themes={cyan:["#6de7ff","#8effc2","#9b7cff"],violet:["#9f8cff","#d6a7ff","#61c7ff"],red:["#ff5f7a","#ff9a8b","#ffcf70"],gold:["#ffd76a","#fff0a8","#ff9d5c"],green:["#55e6a5","#b2ffcf","#67d7ff"]};
 const t=themes[name]||themes.cyan;document.documentElement.style.setProperty("--accent",t[0]);document.documentElement.style.setProperty("--accent2",t[1]);document.documentElement.style.setProperty("--hot",t[2]);localStorage.setItem("ns_theme",name);toast("Тема: "+name.toUpperCase());
}
function loadTheme(){applyTheme(localStorage.getItem("ns_theme")||"cyan")}

function getSession()'''
s=s.replace(needle,rep)
# 7 controls listeners before switch page listeners
needle='document.querySelectorAll(".nav button[data-page]").forEach(b=>b.onclick=()=>switchPage(b.dataset.page));'
rep='''populateRegions();loadTheme();
$("#countrySelect").onchange=()=>{selectedCountry=$("#countrySelect").value;populateRegions();setNumber(selectedCountry==="BY"?makeBelarus():make());};
$("#regionSelect").onchange=()=>{selectedRegion=$("#regionSelect").value;$("#regionHint").textContent=selectedRegion==="RANDOM"?"Регион: случайный":"Регион: "+selectedRegion;setNumber(selectedCountry==="BY"?makeBelarus():make());};
document.querySelectorAll("[data-theme]").forEach(b=>b.onclick=()=>{if(user()?.role==="ADMIN")applyTheme(b.dataset.theme)});
document.querySelectorAll(".nav button[data-page]").forEach(b=>b.onclick=()=>switchPage(b.dataset.page));'''
s=s.replace(needle,rep)
# 8 full plate animation in roll
s=s.replace('if(busy)return;busy=true;$("#go").disabled=true;', 'if(busy)return;busy=true;$("#go").disabled=true;$("#plate").classList.toggle("rolling",$("#fullAnim").checked);')
s=s.replace('$("#reels").classList.remove("rolling");$("#plate").classList.add("flash");', '$("#reels").classList.remove("rolling");$("#plate").classList.remove("rolling");$("#plate").classList.add("flash");')
# 9 admin handlers
needle='''$("#giftItem").onclick=()=>{
  if(user()?.role!=="ADMIN")return;
  let name=prompt("Название предмета:","Бонусный жетон"); if(!name)return;
  let icon=prompt("Иконка:","◆")||"◆"; let u=allUsers();u.forEach(x=>{x.inventory=x.inventory||[];let q=x.inventory.find(i=>i.name===name);q?q.count++:x.inventory.push({name,icon,count:1,desc:"Выдан администратором"})});saveUsers(u);renderAdmin();toast("Предмет выдан всем аккаунтам");
};'''
rep=needle+'''\n$("#grantMoney").onclick=()=>{if(user()?.role!=="ADMIN")return;const amount=Number(prompt("Сколько BYN выдать всем игрокам?","10000"));if(!amount||amount<0)return;allUsers().forEach(x=>x.money=Number(x.money||0)+amount);saveUsers(allUsers());renderAdmin();toast("Всем выдано "+amount.toLocaleString("ru-RU")+" BYN")};
$("#setLevel").onclick=()=>{if(user()?.role!=="ADMIN")return;const name=prompt("Логин игрока:");if(!name)return;const level=Number(prompt("Новый уровень:","10"));if(!level)return;const us=allUsers(),x=us.find(a=>a.username===name);if(!x){toast("Игрок не найден");return}x.level=level;x.xp=0;saveUsers(us);renderAdmin();toast("Уровень установлен")};
$("#adminAddEvent").onclick=()=>{if(user()?.role!=="ADMIN")return;const text=prompt("Текст мирового события:","⚡ ОХОТА ЗА КРАСИВЫМИ НОМЕРАМИ — x2 XP");if(!text)return;localStorage.setItem("ns_event",text);$("#eventText").textContent=text;toast("Событие опубликовано")};
$("#adminEconomy").onclick=()=>{if(user()?.role!=="ADMIN")return;localStorage.setItem("ns_economyBoost","2");toast("Экономический буст x2 включён")};
$("#adminClearSaves").onclick=()=>{if(user()?.role!=="ADMIN")return;const name=prompt("Логин игрока:");if(!name)return;const us=allUsers(),x=us.find(a=>a.username===name);if(!x){toast("Игрок не найден");return}x.saved=[];saveUsers(us);renderAdmin();toast("Коллекция игрока очищена")};'''
s=s.replace(needle,rep)
# 10 event persistence and README
s=s.replace('q("#eventText").textContent=info.d.rarity==="mythic"?', 'q("#eventText").textContent=localStorage.getItem("ns_event")|| (info.d.rarity==="mythic"?')
# Above introduces mismatched ternary likely. Revert that specific complex line if changed incorrectly.
s=s.replace('q("#eventText").textContent=localStorage.getItem("ns_event")|| (info.d.rarity==="mythic"?"МИФИЧЕСКИЙ ДЖЕКПОТ! Номер можно продать за огромную сумму.":"Редкость "+info.d.rarity+" повышает стоимость номера.");', 'q("#eventText").textContent=localStorage.getItem("ns_event")|| (info.d.rarity==="mythic"?"МИФИЧЕСКИЙ ДЖЕКПОТ! Номер можно продать за огромную сумму.":"Редкость "+info.d.rarity+" повышает стоимость номера.");')
p.write_text(s,encoding='utf-8')
