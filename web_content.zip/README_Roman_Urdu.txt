GST & Income Tax Calculator — APK Project Package v8

ZIP ke andar index.html bilkul root/main level par hai. Ye ZIP khud APK file nahi hai; isay HTML-to-APK/WebView builder mein project ke taur par use karna hai.

APP SETTINGS:
App Name: GST Tax Calculator
Package Name: com.mohsin.gstcalculator
Version Name: 1.0.0
Version Code: 1

IMPORTANT — BLANK SCREEN SE BACHNE KE LIYE:
1. Agar aapka converter ZIP/project upload accept karta hai, to ye poori ZIP upload karein aur 'HTML project', 'Local HTML', 'WebView app' ya isi tarah ka option select karein.
2. Agar converter ZIP accept nahi karta, ZIP ko extract karein aur index.html ko uske saath maujood icons folder aur manifest/service-worker files ke saath local website/project option mein import karein. Sirf ZIP ka naam package name field mein na likhein.
3. Agar converter sirf Website URL maangta hai, to is local ZIP ko URL field mein daalne se kaam nahi hoga. Us converter mein local HTML/project ka option dhoondein.
4. Agar converter sirf ek HTML file leta hai, to GST_Income_Tax_Calculator_Updated_Mustard_v8.html use karein.
5. Agar phir bhi blank screen aaye, converter ke settings mein JavaScript enable karein. Agar 'Start URL' ya 'Start page' ka option ho to index.html set karein. Internet/remote website URL zaroori nahi, kyun ke calculator local HTML hai.

CALCULATOR FEATURES:
- Filer aur Non-Filer calculation modes.
- GST Rate aur GST Withholding edit/save controls.
- Description table mein row aur extra column add/delete karne ke controls.
- Table/rates save karne ke liye local storage.

Note: Har APK builder ke options mukhtalif hote hain. Package Name/version fields app ki pehchan ke liye hain; blank screen aam tor par HTML load/start-page ya JavaScript setting se related hoti hai.
