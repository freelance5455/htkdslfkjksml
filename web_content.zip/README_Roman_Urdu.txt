GST & Income Tax Calculator — APK Project Package v8

ZIP ke andar index.html bilkul root/main level par hai. Ye ZIP khud APK file nahi hai; isay HTML-to-APK/WebView builder mein project ke taur par use karna hai.

APP SETTINGS:
App Name: GST Tax Calculator
Package Name: com.mohsin.gstcalculator
Version Name: 1.0.0
Version Code: 1

IMPORTANT — BLANK SCREEN SE BACHNE KE LIYE:
1. Agar aapka converter ZIP/project upload accept karta hai, to ye poori ZIP upload karein aur 'HTML project', 'Local HTML', 'WebView app' ya isi tarah ka option select karein.
2. Agar converter ZIP accept nahi karta, ZIP ko extract karein aur index.html ko uske saath maujood icons folder aur manifest/service-worker files ke saath local website/project option mein import karein. Sirf ZIP ka naam package name field mein na likhein.
3. Agar converter sirf Website URL maangta hai, to is local ZIP ko URL field mein daalne se kaam nahi hoga. Us converter mein local HTML/project ka option dhoondein.
4. Agar converter sirf ek HTML file leta hai, to GST_Income_Tax_Calculator_Updated_Mustard_v8.html use karein.
5. Agar phir bhi blank screen aaye, converter ke settings mein JavaScript enable karein. Agar 'Start URL' ya 'Start page' ka option ho to index.html set karein. Internet/remote website URL zaroori nahi, kyun ke calculator local HTML hai.

CALCULATOR FEATURES:
- Filer aur Non-Filer calculation modes.
- GST Rate aur GST Withholding edit/save controls.
- Description table mein row aur extra column add/delete karne ke controls.
- Table/rates save karne ke liye local storage.

Note: Har APK builder ke options mukhtalif hote hain. Package Name/version fields app ki pehchan ke liye hain; blank screen aam tor par HTML load/start-page ya JavaScript setting se related hoti hai.


Version 9 mein settings drawer (theme/design/font), Share Summary, professional A4/PDF print layout aur Powered by branding add ki gayi hai. PDF button dabane ke baad print dialog mein Save as PDF select karein.


Version 10 updates: print/PDF action chooser, A4 print preview, improved print scaling, and corrected branding name: Syed Mohsin Ali Raza.


Version 11 update: Header ke right side par ab sirf three-dots (⋮) menu hai. Tap karne par vertical menu khulta hai: PDF, Print Preview, Print.


Version 12 update: Right-side three-dots menu now contains 8 options: PDF, Print Preview, Print, Share Summary, Copy Summary, Download Summary, Full Screen, and App Settings. Copy/Download Summary respects Filer and Non-Filer mode.

Version 13 update: Share Summary and Copy Summary menu items have been removed and replaced with History. Added history save/view/delete, history CSV export, current calculation CSV export, backup/restore, data/privacy history clearing, About App, plus PDF/Preview/Print, Download Summary, Full Screen and App Settings. History/settings are stored locally on this device.

Version 16 updates:
- Main page se Copy Summary aur Share Summary buttons remove kar diye gaye hain.
- Main page ke top par Supplier / Vendor / Shop / Company Name ka input box add kiya gaya hai.
- Naam isi device par save rahega aur PDF/Print report, downloaded summary, CSV aur History records mein shamil hoga.
- History se record open karne par supplier/vendor ka naam bhi wapas load hota hai.
