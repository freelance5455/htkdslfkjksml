GST & Income Tax Calculator — APK Package

ZIP ke andar index.html root mein rakhi gayi hai, is liye HTML-to-APK builder mein upload karna asaan hoga.

APK banane ka asaan tareeqa:
1. ZIP file ko mobile par download aur extract kar lein agar builder extracted files maangta ho.
2. Kisi HTML-to-APK / WebView APK builder mein index.html ya is ZIP ko upload karein (builder ki instructions ke mutabiq).
3. App ka naam "GST & Income Tax Calculator" rakh lein.
4. Build/Generate APK par tap karein, phir APK download karke Android par install karein.

Zaroori baat:
- Har APK builder ZIP upload support nahi karta; kuch sirf website URL ya single HTML file lete hain.
- Agar builder ZIP accept na kare to ZIP extract karke index.html upload karein, ya us builder ka local HTML/project option use karein.
- Online builder par upload karne se pehle apni file aur service ki privacy/permissions check karein.
- Ye package khud APK nahi hai; ye HTML web-app project hai jise APK builder se APK mein convert karna hoga.


Latest update v5: GST Rate aur GST Withholding dono ke liye Edit Rate / Save Rate controls shamil hain. Non-Filer mode mein bhi dono rates edit ho sakte hain.
