# Quick Rx Android

Android Studio project wrapping the supplied Quick Rx HTML interface in a WebView and providing native Android BLE printer access.

## Build the APK
1. Install Android Studio (current stable) on a computer.
2. Open this `QuickRxAndroid` folder in Android Studio.
3. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location (normally `app/build/outputs/apk/debug/app-debug.apk`).

## Use
- Install the APK on the Android phone.
- Open Quick Rx and tap **Connect Printer**.
- Allow Bluetooth permissions, wait for scanning to finish, then select the BLE printer.
- Tap a disease protocol to print. Use Edit mode to modify protocols.
- Backup opens Android's save-file dialog. Restore opens the Android document picker.

## Important notes
- This is a BLE/GATT printer implementation. It will not work with a classic Bluetooth SPP-only printer.
- Printer compatibility varies by manufacturer. The app discovers the first writable GATT characteristic; some printers require a specific service/characteristic UUID, encoding, or command sequence.
- Test printing before clinical use. The HTML supplied by the user strips non-ASCII characters before printing, so Bangla text is removed from print output.
- Saved protocol data uses WebView local storage on the device. Uninstalling the app or clearing its app data may erase it; use Backup regularly.
