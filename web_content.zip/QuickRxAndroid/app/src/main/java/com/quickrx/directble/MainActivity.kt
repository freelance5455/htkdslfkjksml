package com.quickrx.directble

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.app.AlertDialog
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val handler = Handler(Looper.getMainLooper())
    private val devices = linkedMapOf<String, BluetoothDevice>()
    private var gatt: BluetoothGatt? = null
    private var writable: BluetoothGattCharacteristic? = null
    private val printQueue = ArrayDeque<ByteArray>()
    private var writing = false
    private var backupContent: String = ""
    private var pendingFileCallback: android.webkit.ValueCallback<Array<Uri>>? = null

    private val REQ_PERMISSIONS = 501
    private val REQ_PICK_FILE = 502
    private val REQ_SAVE_FILE = 503

    private fun requestBluetoothPermissions(permissions: Array<String>) {
        requestPermissions(permissions, REQ_PERMISSIONS)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                pendingFileCallback?.onReceiveValue(null)
                pendingFileCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                }
                startActivityForResult(intent, REQ_PICK_FILE)
                return true
            }
        }
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class AndroidBridge {
        @JavascriptInterface fun connectPrinter() {
            runOnUiThread {
                val permissions = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
                    else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
                val missing = permissions.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
                if (missing.isNotEmpty()) requestBluetoothPermissions(missing.toTypedArray()) else startScan()
            }
        }
        @JavascriptInterface fun isPrinterConnected(): Boolean = writable != null && gatt != null
        @JavascriptInterface fun saveBackup(json: String) {
            runOnUiThread {
                backupContent = json
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "quick_rx_backup.json")
                }
                startActivityForResult(intent, REQ_SAVE_FILE)
            }
        }
        @JavascriptInterface fun printText(base64: String) {
            try {
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                runOnUiThread {
                    if (writable == null || gatt == null) { status("Printer is not connected", false); return@runOnUiThread }
                    var offset = 0
                    while (offset < bytes.size) {
                        val end = minOf(offset + 100, bytes.size)
                        printQueue.add(bytes.copyOfRange(offset, end)); offset = end
                    }
                    writeNext()
                }
            } catch (_: Exception) { status("Invalid print data", false) }
        }
    }

    private fun startScan() {
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null || !adapter.isEnabled) { status("Please turn on Bluetooth", false); return }
        devices.clear()
        status("Scanning for BLE printers...", false)
        val scanner = adapter.bluetoothLeScanner ?: run { status("Bluetooth scanner unavailable", false); return }
        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val device = result.device
                val key = try { device.address } catch (_: SecurityException) { return }
                devices[key] = device
            }
            override fun onScanFailed(errorCode: Int) { status("Bluetooth scan failed: $errorCode", false) }
        }
        try {
            scanner.startScan(callback)
            handler.postDelayed({
                try { scanner.stopScan(callback) } catch (_: Exception) {}
                showDevicePicker()
            }, 8000)
        } catch (_: SecurityException) { status("Bluetooth permission required", false) }
    }

    private fun showDevicePicker() {
        if (devices.isEmpty()) { status("No BLE devices found. Move closer to the printer and retry.", false); return }
        val list = devices.values.toList()
        val labels = list.map { device ->
            val name = try { device.name } catch (_: SecurityException) { null }
            "${name ?: "Unknown BLE device"}  (${device.address})"
        }.toTypedArray()
        runOnUiThread {
            AlertDialog.Builder(this).setTitle("Select your printer")
                .setItems(labels) { _, which -> connectDevice(list[which]) }
                .setNegativeButton("Cancel", null).show()
        }
    }

    private fun connectDevice(device: BluetoothDevice) {
        status("Connecting to printer...", false)
        try { gatt?.close(); gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE) }
        catch (_: SecurityException) { status("Bluetooth permission required", false) }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                runOnUiThread { status("Connected. Discovering printer services...", false) }
                try { g.discoverServices() } catch (_: SecurityException) { status("Bluetooth permission required", false) }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                writable = null; gatt = null
                status("Printer disconnected", false)
            }
        }
        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            writable = g.services.asSequence().flatMap { it.characteristics.asSequence() }
                .firstOrNull { it.properties and (BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0 }
            if (writable != null) status("Connected! Ready to print.", true) else status("No writable printer characteristic found", false)
        }
        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) {
            writing = false
            if (statusCode == BluetoothGatt.GATT_SUCCESS) writeNext()
            else { printQueue.clear(); writing = false; status("Print failed. Check printer connection.", false) }
        }
    }

    private fun writeNext() {
        val g = gatt ?: return
        val c = writable ?: return
        if (printQueue.isEmpty()) { writing = false; return }
        if (writing) return
        writing = true
        val chunk = printQueue.removeFirst()
        try {
            val noResponse = c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0
            if (Build.VERSION.SDK_INT >= 33) {
                val result = g.writeCharacteristic(c, chunk, if (noResponse) BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT)
                if (result != BluetoothGatt.GATT_SUCCESS) { writing = false; status("Could not write to printer", false) }
                else if (noResponse) { writing = false; handler.postDelayed({ writeNext() }, 35) }
            } else {
                @Suppress("DEPRECATION")
                c.writeType = if (noResponse) BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                @Suppress("DEPRECATION")
                c.value = chunk
                @Suppress("DEPRECATION")
                val started = g.writeCharacteristic(c)
                if (!started) { writing = false; status("Could not write to printer", false) }
                else if (noResponse) { writing = false; handler.postDelayed({ writeNext() }, 35) }
            }
        } catch (_: SecurityException) { writing = false; status("Bluetooth permission required", false) }
    }

    private fun status(message: String, connected: Boolean) {
        runOnUiThread {
            val safe = message.replace("\\", "\\\\").replace("'", "\\'")
            webView.evaluateJavascript("updatePrinterStatus('$safe', $connected)", null)
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERMISSIONS) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) startScan()
            else status("Bluetooth permission was not granted", false)
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK_FILE) {
            val uri = if (resultCode == RESULT_OK) data?.data else null
            pendingFileCallback?.onReceiveValue(uri?.let { arrayOf(it) })
            pendingFileCallback = null
        } else if (requestCode == REQ_SAVE_FILE && resultCode == RESULT_OK) {
            try {
                data?.data?.let { uri -> contentResolver.openOutputStream(uri)?.use { it.write(backupContent.toByteArray(Charsets.UTF_8)) } }
                Toast.makeText(this, "Backup saved", Toast.LENGTH_SHORT).show()
            } catch (_: Exception) { Toast.makeText(this, "Could not save backup", Toast.LENGTH_LONG).show() }
        }
    }

    override fun onDestroy() {
        try { gatt?.disconnect(); gatt?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
