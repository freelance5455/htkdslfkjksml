EVSL Auto Maintenance - Date-wise Breakdown Register
======================================================

Contents
- index.html: offline date-wise breakdown register prototype

Features
- Add breakdown with date, vehicle, vehicle ID, status, complaint, repair action,
  spare parts, technician remarks
- Filter records by date, status, and vehicle/complaint text
- Show all dates, grouped date-wise
- Attach multiple photos from camera or gallery (device/browser support dependent)
- Export records to CSV
- Stores data locally in the browser on this device

How to use
1. Extract the ZIP file.
2. Open index.html in Chrome or another modern browser.
3. Add breakdown records and use Date-wise Breakdown History to filter them.

Important
- This is an offline web prototype/source ZIP, not an APK.
- It does not connect to Firebase or SAP.
- Records/photos are stored in browser local storage. Clearing browser data can erase them.
- Export CSV regularly as a backup. For a production Android app, use Android's native
  photo picker/camera integration and a database with backup/restore.
