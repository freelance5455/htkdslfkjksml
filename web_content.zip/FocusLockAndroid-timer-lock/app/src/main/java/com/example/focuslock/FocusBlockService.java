package com.example.focuslock;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class FocusBlockService extends AccessibilityService {
    private static final Set<String> ALLOWED = new HashSet<>(Arrays.asList(
        "com.android.phone", "com.android.dialer", "com.google.android.dialer",
        "com.samsung.android.dialer", "com.android.contacts", "com.google.android.contacts",
        "com.samsung.android.contacts", "com.android.emergency"
    ));
    private long lastRedirect = 0;

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        if (!getSharedPreferences("focuslock", MODE_PRIVATE).getBoolean("blocking", false)) return;
        CharSequence cs = event.getPackageName();
        if (cs == null) return;
        String pkg = cs.toString();
        if (pkg.equals(getPackageName()) || ALLOWED.contains(pkg) || pkg.equals("com.android.systemui")) return;
        long now = SystemClock.elapsedRealtime();
        if (now - lastRedirect < 700) return;
        lastRedirect = now;
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }
    @Override public void onInterrupt() { }
}
