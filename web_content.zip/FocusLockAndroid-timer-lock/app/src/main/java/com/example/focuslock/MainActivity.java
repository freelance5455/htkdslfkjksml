package com.example.focuslock;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.provider.Settings;
import android.content.ComponentName;
import android.content.Context;
import android.view.accessibility.AccessibilityManager;
import android.accessibilityservice.AccessibilityServiceInfo;

public class MainActivity extends Activity {
    private WebView webView;
    private boolean focusMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        webView.addJavascriptInterface(new SystemLockBridge(), "AndroidLock");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void enterImmersiveMode() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );
    }

    private class SystemLockBridge {
        @JavascriptInterface
        public void startPinning() {
            runOnUiThread(() -> {
                getSharedPreferences("focuslock", MODE_PRIVATE).edit().putBoolean("blocking", true).apply();
                focusMode = true;
                enterImmersiveMode();
            });
        }

        @JavascriptInterface
        public void stopPinning() {
            runOnUiThread(() -> {
                focusMode = false;
                getSharedPreferences("focuslock", MODE_PRIVATE).edit().putBoolean("blocking", false).apply();
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
            });
        }

        @JavascriptInterface
        public boolean isBlockingReady() {
            AccessibilityManager am = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
            if (am == null || !am.isEnabled()) return false;
            for (AccessibilityServiceInfo info : am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)) {
                if (info.getResolveInfo() != null && info.getResolveInfo().serviceInfo != null &&
                    getPackageName().equals(info.getResolveInfo().serviceInfo.packageName) &&
                    "FocusBlockService".equals(info.getResolveInfo().serviceInfo.name.substring(info.getResolveInfo().serviceInfo.name.lastIndexOf('.') + 1))) return true;
            }
            return false;
        }

        @JavascriptInterface
        public void openAccessibilitySettings() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && focusMode) enterImmersiveMode();
    }


    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // Keep the focus screen open while the timer is running.
        if (focusMode) {
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidLock");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
