iOS 27.P — PROJET WEB POUR UN CONVERTISSEUR WEB-TO-APK

Contenu :
- index.html : écran de démonstration
- style.css : apparence mobile
- app.js : horloge, recherche, mode clair/sombre et boutons de démonstration
- manifest.json et sw.js : prise en charge PWA de base

IMPORTANT :
Ce ZIP est une maquette web. Il n'est pas une application Android native et ne remplace pas l'écran de verrouillage Android.
Sur un service de conversion web-vers-APK, téléversez ce ZIP seulement si le service accepte les projets HTML/CSS/JavaScript.
Si le site exige un fichier HTML précis, extrayez le ZIP et sélectionnez index.html.
