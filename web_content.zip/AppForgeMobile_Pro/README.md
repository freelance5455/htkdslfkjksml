# AppForge Mobile Pro

A dark, mobile-friendly HTML/CSS/JavaScript app builder plus an Android Studio WebView wrapper project.

## Included features
- HTML/CSS/JavaScript editor
- Sandboxed live preview
- Starter templates: counter, task list, profile card, calculator
- Save/open/delete projects in browser local storage
- Import HTML files
- Import ZIP files containing HTML (loads JSZip from a CDN, so ZIP import requires internet)
- Export edited source as an HTML file
- Android app shell that opens the builder UI in a WebView

## Build an Android APK
Requirements:
- A computer with Android Studio (current stable release)
- Internet for initial Gradle/plugin/SDK downloads
- Android SDK Platform 35 and a compatible JDK (Android Studio manages these in most setups)

Steps:
1. Extract `AppForgeMobile_Pro.zip`.
2. Open the extracted `AppForgeMobile_Pro` folder in Android Studio.
3. Allow Gradle sync and install any SDK components Android Studio requests.
4. Use **Build > Build APK(s)** (menu wording may vary).
5. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.
6. Copy that APK to your Android phone and open it to install. If Android blocks it, allow installs from the file manager/browser used to open the APK.
7. For a shareable release build, choose **Build > Generate Signed Bundle / APK** and create a signing key. Keep the keystore and password safe.

## Important limitations
- This is a real Android Studio project source, not a prebuilt APK. It must be built with Android Studio/Gradle.
- The builder exports standalone HTML. It does not automatically turn every arbitrary web project into an APK. Each app needs its own Android wrapper/configuration and may need native permissions/plugins.
- Browser local storage is device/browser-local and can be cleared by Android/browser data cleanup.
- ZIP import loads JSZip from a CDN and therefore requires internet. HTML editing, templates, preview, saving, and export work locally.
- Preview code runs in a sandboxed iframe, but only import/run code you trust.

## Project layout
- `app/src/main/assets/index.html` — AppForge builder UI
- `app/src/main/java/com/appforge/mobile/MainActivity.java` — Android WebView launcher
- `app/src/main/AndroidManifest.xml` — Android manifest
- `build.gradle`, `settings.gradle`, `app/build.gradle` — Gradle configuration
