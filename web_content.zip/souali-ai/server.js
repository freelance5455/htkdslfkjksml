// Souali AI – خادم آمن. مفتاح OpenAI يبقى هنا فقط ولا يصل للتطبيق.
// التشغيل: OPENAI_API_KEY=sk-... node server.js   (يتطلب Node 18+)
const http = require("http");
const fs = require("fs");
const path = require("path");

const KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || "gpt-4o-mini"; // يدعم النص والصور
const PORT = process.env.PORT || 3000;
const hits = new Map(); // تحديد معدل الطلبات لكل IP

const MANIFEST = JSON.stringify({
  name: "Souali AI – سؤالي AI", short_name: "سؤالي AI", start_url: "/",
  display: "standalone", dir: "rtl", lang: "ar",
  background_color: "#14102b", theme_color: "#5b3df5",
  icons: [{ src: "/icon.svg", sizes: "any", type: "image/svg+xml", purpose: "any maskable" }],
});
const ICON = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#7c3aed"/><stop offset="1" stop-color="#2563eb"/></linearGradient></defs><rect width="512" height="512" rx="112" fill="url(#g)"/><text x="256" y="350" font-size="300" text-anchor="middle" fill="#fff" font-family="Arial" font-weight="700">س</text></svg>`;

function limited(ip) {
  const now = Date.now(), arr = (hits.get(ip) || []).filter((t) => now - t < 60000);
  arr.push(now); hits.set(ip, arr); return arr.length > 20;
}
function readBody(req) {
  return new Promise((res, rej) => {
    let b = ""; req.on("data", (c) => { b += c; if (b.length > 8e6) { rej(new Error("big")); req.destroy(); } });
    req.on("end", () => res(b));
  });
}
function send(res, code, obj) {
  res.writeHead(code, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(obj));
}

http.createServer(async (req, res) => {
  if (req.url === "/manifest.json") { res.writeHead(200, { "Content-Type": "application/manifest+json" }); return res.end(MANIFEST); }
  if (req.url === "/icon.svg") { res.writeHead(200, { "Content-Type": "image/svg+xml" }); return res.end(ICON); }

  if (req.method === "POST" && req.url === "/api/chat") {
    if (!KEY) return send(res, 500, { error: "الخادم غير مهيأ: مفتاح OPENAI_API_KEY مفقود." });
    if (limited(req.socket.remoteAddress)) return send(res, 429, { error: "طلبات كثيرة، حاول بعد دقيقة." });
    try {
      const { messages, system } = JSON.parse(await readBody(req));
      if (!Array.isArray(messages) || !messages.length) return send(res, 400, { error: "طلب غير صالح." });
      const ctrl = new AbortController();
      res.on("close", () => ctrl.abort()); // إيقاف التوليد عند قطع العميل
      const r = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST", signal: ctrl.signal,
        headers: { "Content-Type": "application/json", Authorization: "Bearer " + KEY },
        body: JSON.stringify({
          model: MODEL,
          messages: [{ role: "system", content: system || "You are Souali AI, a helpful assistant. Reply in the user's language." }, ...messages.slice(-30)],
        }),
      });
      const data = await r.json();
      if (!r.ok) return send(res, r.status, { error: data.error?.message || "خطأ من OpenAI" });
      return send(res, 200, { reply: data.choices[0].message.content });
    } catch (e) {
      if (e.name === "AbortError") return;
      return send(res, 502, { error: "تعذر الاتصال بـ OpenAI." });
    }
  }

  const f = path.join(__dirname, "public", "index.html");
  res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
  fs.createReadStream(f).pipe(res);
}).listen(PORT, () => console.log("Souali AI يعمل على المنفذ " + PORT));
