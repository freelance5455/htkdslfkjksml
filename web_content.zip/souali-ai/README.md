# Souali AI – سؤالي AI
1. `export OPENAI_API_KEY=sk-...` ثم `node server.js` (Node 18+)
2. انشر المجلد على استضافة HTTPS (Render / Railway / VPS).
3. على أندرويد: افتح الرابط في Chrome ← ⋮ ← "تثبيت التطبيق".
لتحويله إلى APK: bubblewrap init --manifest https://your-domain/manifest.json ثم bubblewrap build (أو PWABuilder.com).
