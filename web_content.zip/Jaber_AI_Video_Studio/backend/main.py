from __future__ import annotations
import os, json, uuid, shutil, asyncio, subprocess, re
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent
FRONT = ROOT / "frontend"
UPLOADS = BASE / "uploads"
OUTPUTS = BASE / "outputs"
for p in (UPLOADS, OUTPUTS): p.mkdir(parents=True, exist_ok=True)
load_dotenv(BASE / ".env")

app = FastAPI(title="Jaber AI Video Studio")
app.mount("/static", StaticFiles(directory=FRONT), name="static")

def clean_name(s: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_-]", "_", s)[:50] or "video"

@app.get("/")
def home():
    return FileResponse(FRONT / "index.html")

@app.get("/manifest.webmanifest")
def manifest():
    return JSONResponse({
        "name":"Jaber AI Video Studio","short_name":"Jaber Studio",
        "start_url":"/","display":"standalone","background_color":"#0b1020",
        "theme_color":"#111827","lang":"ar","dir":"rtl",
        "icons":[]
    })

@app.get("/health")
def health():
    return {"ok": True, "ffmpeg": shutil.which("ffmpeg") is not None,
            "ai_configured": bool(os.getenv("OPENAI_API_KEY"))}

@app.post("/api/script")
async def make_script(idea: str = Form(...), kind: str = Form("تلقائي"),
                      duration: int = Form(60), language: str = Form("عامية مصرية")):
    idea = idea.strip()
    if len(idea) < 5: raise HTTPException(400, "اكتب فكرة أوضح للفيديو.")
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        raise HTTPException(503, "لم يتم إعداد مفتاح الذكاء الاصطناعي. راجع README_AR.md وملف backend/.env.")
    try:
        from openai import OpenAI
        client = OpenAI(api_key=key)
        prompt = f"""اكتب خطة فيديو عربية كاملة بناءً على الفكرة التالية.
النوع: {kind}; المدة: {duration} ثانية; الأسلوب اللغوي: {language}.
أعد JSON فقط بالشكل:
{{"title":"عنوان جذاب","description":"وصف قصير","scenes":[{{"title":"عنوان المشهد","narration":"نص التعليق الصوتي","visual":"وصف الصورة المناسبة للمشهد"}}]}}
اجعل عدد المشاهد مناسبًا للمدة، والنص طبيعيًا ومترابطًا، ولا تضف حقائق غير مؤكدة.
الفكرة: {idea}"""
        response = client.chat.completions.create(
            model=os.getenv("OPENAI_MODEL","gpt-4o-mini"),
            messages=[{"role":"system","content":"أنت كاتب سيناريو فيديو محترف. أخرج JSON صحيحًا فقط."},
                      {"role":"user","content":prompt}],
            response_format={"type":"json_object"},
            temperature=0.8
        )
        data = json.loads(response.choices[0].message.content)
        if not isinstance(data.get("scenes"), list) or not data["scenes"]:
            raise ValueError("Invalid scenes")
        return data
    except Exception as e:
        raise HTTPException(502, f"تعذر إنشاء السيناريو: {str(e)[:300]}")

def srt_time(seconds: float) -> str:
    ms = int(seconds * 1000)
    h, rem = divmod(ms, 3600000); m, rem = divmod(rem, 60000); s, ms = divmod(rem, 1000)
    return f"{h:02}:{m:02}:{s:02},{ms:03}"

@app.post("/api/render")
async def render_video(project: str = Form(...), ratio: str = Form("9:16"),
                       voice: str = Form("ar-EG-SalmaNeural"),
                       images: list[UploadFile] = File(...)):
    if not shutil.which("ffmpeg"):
        raise HTTPException(503, "FFmpeg غير مثبت على الخادم.")
    try:
        data = json.loads(project)
        scenes = data.get("scenes", [])
        if not scenes or len(images) != len(scenes):
            raise HTTPException(400, "ارفع صورة واحدة لكل مشهد.")
        job = uuid.uuid4().hex[:12]
        work = UPLOADS / job
        work.mkdir(parents=True)
        saved = []
        for i, up in enumerate(images):
            ext = Path(up.filename or "img.jpg").suffix.lower()
            if ext not in (".jpg",".jpeg",".png",".webp"): ext = ".jpg"
            dest = work / f"scene_{i:02d}{ext}"
            with dest.open("wb") as f: shutil.copyfileobj(up.file, f)
            saved.append(dest)
        narration = "\n\n".join(str(s.get("narration","")) for s in scenes).strip()
        if not narration: raise HTTPException(400, "لا يوجد نص تعليق صوتي.")
        audio = work / "voice.mp3"
        import edge_tts
        communicate = edge_tts.Communicate(narration, voice)
        await communicate.save(str(audio))
        # Determine audio duration with ffprobe.
        probe = subprocess.run(["ffprobe","-v","error","-show_entries","format=duration",
                                "-of","default=noprint_wrappers=1:nokey=1",str(audio)],
                               capture_output=True,text=True)
        if probe.returncode != 0: raise RuntimeError("تعذر قراءة مدة الصوت.")
        total = max(float(probe.stdout.strip()), 1.0)
        per = total / len(saved)
        w,h = (1080,1920) if ratio=="9:16" else ((1080,1080) if ratio=="1:1" else (1920,1080))
        concat = work / "concat.txt"
        with concat.open("w",encoding="utf-8") as f:
            for img in saved:
                f.write(f"file '{img.as_posix()}'\n")
                f.write(f"duration {per:.3f}\n")
            f.write(f"file '{saved[-1].as_posix()}'\n")
        # Create simple timed subtitles aligned approximately by scene.
        srt = work / "captions.srt"
        with srt.open("w",encoding="utf-8") as f:
            for i, sc in enumerate(scenes):
                start=i*per; end=(i+1)*per
                caption=str(sc.get("narration","")).strip()
                f.write(f"{i+1}\n{srt_time(start)} --> {srt_time(end)}\n{caption}\n\n")
        out = OUTPUTS / f"jaber_video_{job}.mp4"
        # FFmpeg slideshow with Arabic subtitles. libass availability depends on FFmpeg build.
        vf = f"scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},format=yuv420p"
        cmd = ["ffmpeg","-y","-f","concat","-safe","0","-i",str(concat),"-i",str(audio),
               "-vf",vf,"-r","30","-c:v","libx264","-preset","veryfast","-tune","stillimage",
               "-c:a","aac","-b:a","160k","-shortest","-pix_fmt","yuv420p",str(out)]
        run = subprocess.run(cmd,capture_output=True,text=True)
        if run.returncode != 0:
            raise RuntimeError("فشل FFmpeg: "+run.stderr[-700:])
        return {"ok":True,"url":f"/api/download/{out.name}","filename":out.name,
                "note":"تم إنشاء الفيديو. الترجمة النصية لم تُحرق داخل الصورة في هذا الإصدار؛ التعليق الصوتي موجود."}
    except HTTPException: raise
    except Exception as e:
        raise HTTPException(500, f"فشل إنتاج الفيديو: {str(e)[:500]}")

@app.get("/api/download/{filename}")
def download(filename: str):
    path = OUTPUTS / Path(filename).name
    if not path.exists(): raise HTTPException(404,"الملف غير موجود.")
    return FileResponse(path, media_type="video/mp4", filename=path.name)
