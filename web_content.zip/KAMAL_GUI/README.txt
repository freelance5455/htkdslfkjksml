KAMAL GUI — version connectée

Cette version est préparée pour un fonctionnement centralisé :
- Les utilisateurs lisent les œuvres depuis une base Firestore.
- Le propriétaire se connecte avec un compte Firebase et peut ajouter/supprimer des œuvres.
- Les changements apparaissent sur les téléphones des utilisateurs après actualisation / écoute temps réel.
- En l'absence de configuration Firebase, l'application garde un mode local hors connexion.

IMPORTANT
Le ZIP ne peut pas contenir vos identifiants Firebase ni créer votre projet Firebase à votre place. Pour activer le mode connecté :
1. Créez un projet Firebase.
2. Activez Authentication > Email/Password.
3. Activez Firestore Database.
4. Créez un utilisateur propriétaire dans Authentication.
5. Dans www/firebase-config.js, mettez la configuration Web de votre projet.
6. Déployez les règles de firestore.rules.
7. Pour que le propriétaire puisse modifier les œuvres, ajoutez le custom claim admin=true à son compte (côté serveur / Admin SDK).

Les 3 textes présents dans l'ancien ZIP sont conservés comme secours local. Les 20 œuvres réelles ne sont pas inventées : elles doivent être importées avec leur texte complet dans Firestore ou dans une future version du ZIP.

PIN local de démonstration : 2468. Ne l'utilisez pas comme protection réelle en mode connecté.
