const DEFAULT_PIN="2468";
const seedWorks=[
 {id:"w1",title:"العمل الأول",category:"نص تجريبي",text:"بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\n\nهذا نص تجريبي داخل مكتبة KAMAL GUI.\n\nيمكن للمالك استبداله بأعماله العربية وإضافة أعمال جديدة من الإعدادات."},
 {id:"w2",title:"العمل الثاني",category:"مدحة",text:"بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\n\nيا رب صل على النبي المصطفى\nواجعل لنا من فضلكم نصيبًا."},
 {id:"w3",title:"العمل الثالث",category:"دعاء",text:"رَبِّ اغْفِرْ لَنَا وَارْحَمْنَا\nوَاهْدِنَا إِلَى صِرَاطِكَ الْمُسْتَقِيمِ."}
];
const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
let works=[...seedWorks], owner=false, currentWork=null, cloud=false, db=null, auth=null, unsubscribe=null;

function hasFirebaseConfig(){const c=window.KAMAL_FIREBASE_CONFIG||{};return !!(c.apiKey&&c.authDomain&&c.projectId&&c.appId)}
function localLoad(){const added=JSON.parse(localStorage.getItem("kamal_added_works")||"[]");const deleted=JSON.parse(localStorage.getItem("kamal_deleted_bundled")||"[]");works=seedWorks.filter(w=>!deleted.includes(w.id)).concat(added)}
function localSave(){const bundledIds=new Set(seedWorks.map(w=>w.id));const deleted=seedWorks.filter(w=>!works.some(x=>x.id===w.id)).map(w=>w.id);localStorage.setItem("kamal_deleted_bundled",JSON.stringify(deleted));localStorage.setItem("kamal_added_works",JSON.stringify(works.filter(w=>!bundledIds.has(w.id))))}
function save(){if(!cloud)localSave();renderWorks();renderOwner()}
function renderWorks(filter=""){
 const q=filter.trim().toLowerCase(), list=$("#workList");list.innerHTML="";
 const found=works.filter(w=>(w.title+" "+(w.category||"")+" "+w.text).toLowerCase().includes(q));
 $("#workCount").textContent=found.length+" œuvre"+(found.length>1?"s":"");$("#emptyState").classList.toggle("hidden",found.length>0);
 found.forEach((w,i)=>{const el=document.createElement("div");el.className="work-item";el.innerHTML=`<div class="work-num">${i+1}</div><div class="work-info"><h4>${escapeHtml(w.title)}</h4><p>${escapeHtml(w.category||"Œuvre")} · ${w.text.length} حرف</p></div><div class="work-arrow">←</div>`;el.onclick=()=>openReader(w.id);list.appendChild(el)})
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function showView(id){$$('.view').forEach(v=>v.classList.remove('active'));$("#"+id).classList.add('active');$$('.nav-item').forEach(n=>n.classList.toggle('active',n.dataset.view===id));window.scrollTo(0,0)}
function openReader(id){currentWork=works.find(w=>w.id===id);if(!currentWork)return;$("#readerTitle").textContent=currentWork.title;$("#readerCategory").textContent=currentWork.category||"Œuvre";$("#readerDate").textContent="KAMAL GUI";$("#readerText").textContent=currentWork.text;showView("readerView")}
function openModal(id){$("#"+id).classList.remove("hidden")} function closeModal(id){$("#"+id).classList.add("hidden")}
function renderOwner(){
 $("#ownerLocked").classList.toggle("hidden",owner);$("#ownerTools").classList.toggle("hidden",!owner);const box=$("#ownerWorkList");if(!box)return;box.innerHTML="";
 works.forEach(w=>{const row=document.createElement('div');row.className='owner-work-row';row.innerHTML=`<b>${escapeHtml(w.title)}</b><button class="delete-mini" data-id="${w.id}">حذف</button>`;row.querySelector('button').onclick=async()=>{if(!confirm("Supprimer cette œuvre pour tous les utilisateurs ?"))return;if(cloud)await cloudDelete(w.id);else{works=works.filter(x=>x.id!==w.id);save();renderOwner()}};box.appendChild(row)})
}
function applyPrefs(){const fs=localStorage.getItem('kamal_font')||'medium',ff=localStorage.getItem('kamal_family')||'serif';document.body.classList.remove('font-small','font-medium','font-large','font-xl','family-serif','family-sans','family-mono');document.body.classList.add('font-'+fs,'family-'+ff);$$('[data-font]').forEach(b=>b.classList.toggle('selected',b.dataset.font===fs));$$('[data-fontfamily]').forEach(b=>b.classList.toggle('selected',b.dataset.fontfamily===ff));const dark=localStorage.getItem('kamal_dark')==='1';document.body.classList.toggle('dark',dark);$('#darkToggle').checked=dark;$('#soundToggle').checked=localStorage.getItem('kamal_sound')!=='0'}
function hijriParts(date){
 const f=new Intl.DateTimeFormat('en-u-ca-islamic-umalqura',{year:'numeric',month:'numeric',day:'numeric'}).formatToParts(date);
 const o={};f.forEach(x=>o[x.type]=x.value);return {year:Number(o.year),month:Number(o.month),day:Number(o.day)};
}
const hijriNames=['محرّم','صفر','ربيع الأول','ربيع الآخر','جمادى الأولى','جمادى الآخرة','رجب','شعبان','رمضان','شوّال','ذو القعدة','ذو الحجة'];
const hijriWeek=['الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
let calendarOffset=0;
function shiftedDate(base,days){const d=new Date(base);d.setDate(d.getDate()+days);return d}
function hijriMonthAnchor(offset){
 const now=new Date(), targetBase=shiftedDate(now,Math.round(offset*29.53059));
 let target=hijriParts(targetBase), d=shiftedDate(targetBase,-40);
 for(let i=0;i<90;i++,d=shiftedDate(d,1)){const h=hijriParts(d);if(h.year===target.year&&h.month===target.month&&h.day===1)return d}
 return targetBase;
}
function renderHijriCalendar(){
 const anchor=hijriMonthAnchor(calendarOffset), h=hijriParts(anchor), monthName=hijriNames[h.month-1]||('Mois '+h.month);
 $('#hijriDate').textContent=`${h.day} ${monthName} ${h.year} هـ`;
 $('#calMonthLabel').textContent=`${monthName} ${h.year} هـ`;
 const grid=$('#hijriCalendar');grid.innerHTML='';
 hijriWeek.forEach(x=>{const e=document.createElement('div');e.className='cal-week';e.textContent=x;grid.appendChild(e)});
 const firstDow=anchor.getDay(); for(let i=0;i<firstDow;i++){const e=document.createElement('div');e.className='cal-empty';grid.appendChild(e)}
 let d=new Date(anchor);let day=1;
 while(true){const hp=hijriParts(d);if(hp.year!==h.year||hp.month!==h.month)break;const e=document.createElement('button');e.className='cal-day';e.innerHTML=`<b>${day}</b><small>${d.getDate()}/${d.getMonth()+1}</small>`;const today=new Date();if(d.toDateString()===today.toDateString())e.classList.add('today');e.onclick=()=>{$('#gregDate').textContent=d.toLocaleDateString('fr-FR',{weekday:'long',year:'numeric',month:'long',day:'numeric'});};grid.appendChild(e);day++;d=shiftedDate(d,1)}
 $('#gregDate').textContent=new Date().toLocaleDateString('fr-FR',{weekday:'long',year:'numeric',month:'long',day:'numeric'});
}
function updateCalendar(){renderHijriCalendar()}
let tasbihAudioContext=null;
function playTasbihSound(){
 if(localStorage.getItem('kamal_sound')==='0')return;
 try{
  const C=window.AudioContext||window.webkitAudioContext;if(!C)return;
  if(!tasbihAudioContext)tasbihAudioContext=new C();
  const c=tasbihAudioContext;
  const resume=c.resume();
  const play=()=>{
   const o=c.createOscillator(),g=c.createGain();
   o.frequency.setValueAtTime(880,c.currentTime);
   o.frequency.exponentialRampToValueAtTime(660,c.currentTime+.07);
   o.type='sine';
   g.gain.setValueAtTime(.0001,c.currentTime);
   g.gain.exponentialRampToValueAtTime(.16,c.currentTime+.008);
   g.gain.exponentialRampToValueAtTime(.0001,c.currentTime+.13);
   o.connect(g);g.connect(c.destination);o.start();o.stop(c.currentTime+.14);
  };
  if(resume&&typeof resume.then==='function')resume.then(play).catch(play);else play();
 }catch(e){}
}

async function initCloud(){
 if(!hasFirebaseConfig())return;
 try{
  firebase.initializeApp(window.KAMAL_FIREBASE_CONFIG);auth=firebase.auth();db=firebase.firestore();cloud=true;
  unsubscribe=db.collection('works').orderBy('createdAt','asc').onSnapshot(s=>{works=s.docs.map(d=>({id:d.id,...d.data()}));renderWorks($('#searchInput').value);renderOwner()},e=>{console.error(e);cloud=false;localLoad();renderWorks();renderOwner()});
  $('#ownerLogin').textContent='Accès propriétaire (Firebase)';
 }catch(e){console.error(e);cloud=false;localLoad()}
}
async function cloudLogin(){const email=$('#ownerEmail').value.trim(),password=$('#ownerPin').value;if(!email||!password)return $('#pinError').textContent='Email et mot de passe requis.';try{await auth.signInWithEmailAndPassword(email,password);owner=true;closeModal('ownerModal');renderOwner()}catch(e){$('#pinError').textContent='Connexion refusée. Vérifiez le compte propriétaire.'}}
async function cloudAdd(work){await db.collection('works').add({...work,createdAt:firebase.firestore.FieldValue.serverTimestamp()})}
async function cloudDelete(id){try{await db.collection('works').doc(id).delete()}catch(e){alert('Suppression impossible. Vérifiez la connexion et les règles Firebase.')}}

$('#searchInput').addEventListener('input',e=>renderWorks(e.target.value));$$('.nav-item').forEach(n=>n.onclick=()=>showView(n.dataset.view));$('#settingsBtn').onclick=()=>showView('settingsView');$('#backBtn').onclick=()=>showView('homeView');$$('[data-close]').forEach(b=>b.onclick=()=>b.closest('.modal').classList.add('hidden'));
$('#ownerLogin').onclick=()=>{$('#ownerEmail').value='';$('#ownerPin').value='';$('#pinError').textContent='';openModal('ownerModal');setTimeout(()=>$('#ownerEmail').focus(),100)};
$('#pinSubmit').onclick=async()=>{if(cloud)return cloudLogin();if($('#ownerPin').value===DEFAULT_PIN){owner=true;closeModal('ownerModal');renderOwner()}else $('#pinError').textContent='Code incorrect.'};
$('#logoutBtn').onclick=async()=>{owner=false;if(cloud&&auth)await auth.signOut();renderOwner()};
$('#addWorkBtn').onclick=()=>{$('#newTitle').value='';$('#newCategory').value='Œuvre';$('#newText').value='';openModal('addModal')};
$('#saveWork').onclick=async()=>{const title=$('#newTitle').value.trim(),text=$('#newText').value.trim();if(!title||!text)return alert('Veuillez saisir le titre et le texte de l’œuvre.');const work={title,category:$('#newCategory').value.trim()||'Œuvre',text};if(cloud)await cloudAdd(work);else{works.push({id:'w'+Date.now(),...work});save()}closeModal('addModal');showView('homeView')};
$('#darkToggle').onchange=e=>{localStorage.setItem('kamal_dark',e.target.checked?'1':'0');applyPrefs()};$('#soundToggle').onchange=e=>{localStorage.setItem('kamal_sound',e.target.checked?'1':'0');applyPrefs()};$$('[data-font]').forEach(b=>b.onclick=()=>{localStorage.setItem('kamal_font',b.dataset.font);applyPrefs()});$$('[data-fontfamily]').forEach(b=>b.onclick=()=>{localStorage.setItem('kamal_family',b.dataset.fontfamily);applyPrefs()});
$('#tasbihOpen').onclick=()=>{$('#tasbihPanel').classList.toggle('hidden');$('#calendarPanel').classList.add('hidden')};$('#calendarOpen').onclick=()=>{$('#calendarPanel').classList.toggle('hidden');$('#tasbihPanel').classList.add('hidden');if(!$('#calendarPanel').classList.contains('hidden')){calendarOffset=0;updateCalendar()}};$('#calPrev').onclick=()=>{calendarOffset--;renderHijriCalendar()};$('#calNext').onclick=()=>{calendarOffset++;renderHijriCalendar()};let count=Number(localStorage.getItem('kamal_tasbih')||0);$('#tasbihCount').textContent=count;$('#tasbihAdd').onclick=()=>{count++;localStorage.setItem('kamal_tasbih',count);$('#tasbihCount').textContent=count;playTasbihSound()};$('#tasbihReset').onclick=()=>{count=0;localStorage.setItem('kamal_tasbih',0);$('#tasbihCount').textContent=0};
$('#exportBtn').onclick=()=>{const blob=new Blob([JSON.stringify(works,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='KAMAL_GUI_bibliotheque.json';a.click();URL.revokeObjectURL(a.href)};
if('serviceWorker' in navigator)navigator.serviceWorker.register('sw.js').catch(()=>{});
localLoad();renderWorks();renderOwner();applyPrefs();initCloud();
