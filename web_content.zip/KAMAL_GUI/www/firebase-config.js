// Collez ici la configuration de votre projet Firebase.
// L'application fonctionne aussi en mode local tant que ce fichier reste vide.
window.KAMAL_FIREBASE_CONFIG = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: ""
};
