
// ======================================
// تطبيق ذِكر - الملف البرمجي الرئيسي
// ======================================

// الأذكار الأساسية للمسبحة
const defaultDhikr = [
  "أستغفر الله",
  "سبحان الله",
  "الحمد لله",
  "الله أكبر"
];

// قراءة البيانات المحفوظة
let saved = {};

try {
  saved = JSON.parse(
    localStorage.getItem("zikrData")
  ) || {};
} catch (error) {
  saved = {};
}

// المتغيرات
let counts = saved.counts || {};
let selectedDhikr = saved.selectedDhikr || "";
let customDhikrs = saved.customDhikrs || [];
let soundEnabled = saved.soundEnabled !== false;
let vibrationEnabled = saved.vibrationEnabled !== false;

// حفظ البيانات
function saveData() {
  localStorage.setItem("zikrData", JSON.stringify({
    counts,
    selectedDhikr,
    customDhikrs,
    soundEnabled,
    vibrationEnabled
  }));
}

// جميع أذكار المسبحة
function allDhikrs() {
  return [...defaultDhikr, ...customDhikrs];
}

// إجمالي التسبيحات
function totalCount() {
  return Object.values(counts).reduce(
    (sum, value) => sum + Number(value), 0
  );
}

// ======================================
// المسبحة الإلكترونية
// ======================================

function renderDhikrs() {
  const container = document.getElementById("dhikr-list");
  container.innerHTML = "";

  allDhikrs().forEach(dhikr => {
    const button = document.createElement("button");

    button.textContent = dhikr;
    button.style.margin = "5px";
    button.style.padding = "12px";
    button.style.borderRadius = "12px";
    button.style.border = "1px solid #e5c477";
    button.style.background =
      selectedDhikr === dhikr ? "#e5c477" : "#103c30";
    button.style.color =
      selectedDhikr === dhikr ? "#103c30" : "#ffffff";

    button.onclick = () => {
      selectedDhikr = dhikr;
      saveData();
      renderDhikrs();
      updateCounter();
    };

    container.appendChild(button);
  });
}

// تحديث العداد
function updateCounter() {
  const countElement = document.getElementById("count");
  const selectedElement =
    document.getElementById("selected-dhikr");
  const countButton = document.getElementById("count-btn");

  selectedElement.textContent =
    selectedDhikr || "اختر ذكراً للبدء";

  countElement.textContent =
    counts[selectedDhikr] || 0;

  countButton.disabled = !selectedDhikr;
}

// الصوت
function playSound() {
  if (!soundEnabled) return;

  try {
    const audio = new AudioContext();
    const oscillator = audio.createOscillator();
    const gain = audio.createGain();

    oscillator.frequency.value = 700;
    gain.gain.value = 0.08;

    oscillator.connect(gain);
    gain.connect(audio.destination);

    oscillator.start();
    oscillator.stop(audio.currentTime + 0.08);

    oscillator.onended = () => audio.close();
  } catch (error) {}
}

// الاهتزاز
function vibrate() {
  if (vibrationEnabled && navigator.vibrate) {
    navigator.vibrate(40);
  }
}

// زر التسبيح
document.getElementById("count-btn").onclick = () => {
  if (!selectedDhikr) return;

  counts[selectedDhikr] =
    (counts[selectedDhikr] || 0) + 1;

  saveData();
  updateCounter();
  updateStats();

  playSound();
  vibrate();
};

// تصفير العداد الحالي
document.getElementById("reset-btn").onclick = () => {
  if (!selectedDhikr) return;

  if (confirm("هل تريد تصفير عداد هذا الذكر؟")) {
    counts[selectedDhikr] = 0;
    saveData();
    updateCounter();
    updateStats();
  }
};

// ======================================
// الأذكار اليومية من ملف JSON
// ======================================

let adhkarData = {};

// تحميل ملف الأذكار
async function loadAdhkar() {
  const container = document.getElementById("adhkar-list");

  container.textContent = "جارٍ تحميل الأذكار...";

  try {
    const response = await fetch("adhkar.json");

    if (!response.ok) {
      throw new Error("تعذر تحميل الملف");
    }

    adhkarData = await response.json();

    renderAdhkar();

  } catch (error) {
    container.innerHTML =
      '<p style="color:#e5c477;text-align:center;">' +
      'تعذر تحميل الأذكار. تأكد من وجود ملف adhkar.json ' +
      'داخل مجلد المشروع، ثم أعد تشغيل المعاينة.' +
      '</p>';
  }
}

// عرض جميع أقسام الأذكار
function renderAdhkar() {
  const container = document.getElementById("adhkar-list");

  container.innerHTML = "";

  const title = document.createElement("p");
  title.textContent = "اختر القسم الذي تريد قراءته";
  title.style.color = "#e5c477";
  container.appendChild(title);
const searchBox = document.createElement("input");

searchBox.type = "search";
searchBox.placeholder = "ابحث عن ذكر أو قسم...";
searchBox.style.width = "100%";
searchBox.style.padding = "14px";
searchBox.style.margin = "12px 0";
searchBox.style.borderRadius = "12px";
searchBox.style.border = "1px solid #e5c477";
searchBox.style.boxSizing = "border-box";
searchBox.style.fontSize = "16px";

container.appendChild(searchBox);
  Object.entries(adhkarData).forEach(([name, group]) => { 

    if (!group || typeof group !== "object") return;

    const items = Array.isArray(group.text)
      ? group.text
      : [];

    const card = document.createElement("button");

    card.className = "adhkar-item";
    card.dataset.search = (name + " " + items.join(" ")).toLowerCase();
    card.textContent = (Object.keys(adhkarData).indexOf(name) + 1) + ". " + name;

    card.style.display = "block";
    card.style.width = "100%";
    card.style.padding = "17px";
    card.style.margin = "10px 0";
    card.style.borderRadius = "14px";
    card.style.border = "1px solid #e5c477";
    card.style.background = "#103c30";
    card.style.color = "#ffffff";
    card.style.textAlign = "right";
    card.style.fontSize = "17px";

    card.onclick = () => {
      openAdhkarGroup(name, items, group.footnote);
    };

    container.appendChild(card);
  });
  searchBox.oninput = () => {
  const query = searchBox.value.trim().toLowerCase();

  container.querySelectorAll(".adhkar-item").forEach(card => {
    card.style.display = card.dataset.search.includes(query)
      ? "block"
      : "none";
  });
};
}

// فتح القسم وعرض أذكاره
function openAdhkarGroup(name, items, footnote) {
  const container = document.getElementById("adhkar-list");

  container.innerHTML = "";

  // زر الرجوع
  const backButton = document.createElement("button");

  backButton.textContent = "← الرجوع إلى الأقسام";
  backButton.style.padding = "12px";
  backButton.style.marginBottom = "15px";
  backButton.style.borderRadius = "10px";
  backButton.style.background = "#e5c477";
  backButton.style.color = "#103c30";
  backButton.style.border = "none";

  backButton.onclick = renderAdhkar;

  container.appendChild(backButton);

  // عنوان القسم
  const heading = document.createElement("h3");

  heading.textContent = name;
  heading.style.color = "#e5c477";
  heading.style.textAlign = "center";

  container.appendChild(heading);

  // عرض الأذكار
  if (items.length === 0) {
    const empty = document.createElement("p");
    empty.textContent = "لا توجد أذكار في هذا القسم.";
    container.appendChild(empty);
  }

  items.forEach((text, index) => {

    const item = document.createElement("div");

    item.className = "adhkar-item";
    item.style.padding = "16px";
    item.style.margin = "12px 0";
    item.style.borderRadius = "12px";
    item.style.background = "#103c30";
    item.style.color = "#ffffff";
    item.style.lineHeight = "2";
    item.style.fontSize = "17px";
    item.style.border = "1px solid #e5c477";

    const number = document.createElement("div");
    number.textContent = "الذكر " + (index + 1);
    number.style.color = "#e5c477";
    number.style.marginBottom = "8px";

    const content = document.createElement("div");
    content.textContent = text;

    item.appendChild(number);
    item.appendChild(content);

    container.appendChild(item);
  });

  // عرض الحاشية أو المرجع إن وجد
  if (footnote) {
    const note = document.createElement("p");

    note.textContent = Array.isArray(footnote)
      ? footnote.join(" ")
      : footnote;

    note.style.color = "#e5c477";
    note.style.lineHeight = "2";
    note.style.marginTop = "15px";

    container.appendChild(note);
  }

  // زر الرجوع في نهاية القائمة
  const bottomBack = document.createElement("button");

  bottomBack.textContent = "العودة إلى الأقسام";
  bottomBack.style.padding = "12px";
  bottomBack.style.margin = "15px 0";
  bottomBack.style.borderRadius = "10px";
  bottomBack.style.background = "#e5c477";
  bottomBack.style.color = "#103c30";
  bottomBack.style.border = "none";

  bottomBack.onclick = renderAdhkar;

  container.appendChild(bottomBack);
}

// ======================================
// الإحصائيات
// ======================================

function updateStats() {
  document.getElementById("total-count").textContent =
    totalCount();
}

// ======================================
// إضافة الأذكار الخاصة
// ======================================

function renderCustomDhikrs() {
  const container = document.getElementById("custom-list");

  container.innerHTML = "";

  customDhikrs.forEach((dhikr, index) => {

    const item = document.createElement("div");

    item.style.display = "flex";
    item.style.justifyContent = "space-between";
    item.style.alignItems = "center";
    item.style.padding = "10px";
    item.style.margin = "8px 0";
    item.style.background = "#103c30";
    item.style.borderRadius = "10px";
    item.style.color = "#ffffff";

    const name = document.createElement("span");
    name.textContent = dhikr;

    const deleteButton = document.createElement("button");
    deleteButton.textContent = "حذف";
    deleteButton.style.background = "#8b3333";
    deleteButton.style.color = "#ffffff";
    deleteButton.style.border = "none";
    deleteButton.style.padding = "8px";
    deleteButton.style.borderRadius = "8px";

    deleteButton.onclick = () => {

      if (confirm("هل تريد حذف هذا الذكر؟")) {

        if (selectedDhikr === dhikr) {
          selectedDhikr = "";
        }

        customDhikrs.splice(index, 1);

        saveData();
        renderCustomDhikrs();
        renderDhikrs();
        updateCounter();
      }
    };

    item.appendChild(name);
    item.appendChild(deleteButton);

    container.appendChild(item);
  });
}

// زر إضافة ذكر
document.getElementById("add-btn").onclick = () => {

  const input = document.getElementById("custom-input");
  const value = input.value.trim();

  if (!value) {
    alert("اكتب الذكر أولاً");
    return;
  }

  if (allDhikrs().includes(value)) {
    alert("هذا الذكر موجود بالفعل");
    return;
  }

  customDhikrs.push(value);

  input.value = "";

  saveData();
  renderCustomDhikrs();
  renderDhikrs();
};

// ======================================
// إعدادات الصوت والاهتزاز
// ======================================

function renderSettings() {

  const section = document.getElementById("stats-section");

  if (document.getElementById("sound-setting")) return;

  const settings = document.createElement("div");

  settings.style.marginTop = "20px";
  settings.style.padding = "12px";
  settings.style.background = "#103c30";
  settings.style.borderRadius = "12px";

  const soundLabel = document.createElement("label");
  soundLabel.style.display = "block";
  soundLabel.style.padding = "8px";

  const soundCheckbox = document.createElement("input");
  soundCheckbox.type = "checkbox";
  soundCheckbox.id = "sound-setting";
  soundCheckbox.checked = soundEnabled;

  soundCheckbox.onchange = () => {
    soundEnabled = soundCheckbox.checked;
    saveData();
  };

  soundLabel.appendChild(soundCheckbox);
  soundLabel.append(" تفعيل الصوت");

  const vibrationLabel = document.createElement("label");
  vibrationLabel.style.display = "block";
  vibrationLabel.style.padding = "8px";

  const vibrationCheckbox = document.createElement("input");
  vibrationCheckbox.type = "checkbox";
  vibrationCheckbox.id = "vibration-setting";
  vibrationCheckbox.checked = vibrationEnabled;

  vibrationCheckbox.onchange = () => {
    vibrationEnabled = vibrationCheckbox.checked;
    saveData();
  };

  vibrationLabel.appendChild(vibrationCheckbox);
  vibrationLabel.append(" تفعيل الاهتزاز");

  settings.appendChild(soundLabel);
  settings.appendChild(vibrationLabel);

  section.appendChild(settings);
}

// ======================================
// تشغيل التطبيق
// ======================================

function startApp() {

  if (!selectedDhikr ||
      !allDhikrs().includes(selectedDhikr)) {
    selectedDhikr = defaultDhikr[0];
  }

  renderDhikrs();
  updateCounter();
  updateStats();
  renderCustomDhikrs();
  renderSettings();
  loadAdhkar();

  saveData();
}

startApp();

// ======================================
// تحسين عرض الأذكار
// ======================================

function openAdhkarGroup(name, items, footnote) {
  const container = document.getElementById("adhkar-list");
  container.innerHTML = "";

  let fontSize = 18;

  const back = document.createElement("button");
  back.textContent = "← الرجوع إلى الأقسام";
  back.onclick = renderAdhkar;
  container.appendChild(back);

  const heading = document.createElement("h3");
  heading.textContent = name;
  heading.style.color = "#e5c477";
  heading.style.textAlign = "center";
  container.appendChild(heading);

  // التحكم بحجم الخط
  const controls = document.createElement("div");
  controls.style.textAlign = "center";
  controls.style.margin = "15px";

  const smaller = document.createElement("button");
  smaller.textContent = "A-";

  const bigger = document.createElement("button");
  bigger.textContent = "A+";

  smaller.onclick = () => {
    fontSize = Math.max(14, fontSize - 2);
    container.querySelectorAll(".new-dhikr-text")
      .forEach(el => el.style.fontSize = fontSize + "px");
  };

  bigger.onclick = () => {
    fontSize = Math.min(30, fontSize + 2);
    container.querySelectorAll(".new-dhikr-text")
      .forEach(el => el.style.fontSize = fontSize + "px");
  };

  controls.append(smaller, bigger);
  container.appendChild(controls);

  items.forEach((text, index) => {
    const card = document.createElement("div");

    card.style.background = "#103c30";
    card.style.border = "1px solid #e5c477";
    card.style.borderRadius = "14px";
    card.style.padding = "16px";
    card.style.margin = "12px 0";
    card.style.color = "white";

    const number = document.createElement("div");
    number.textContent = "الذكر " + (index + 1);
    number.style.color = "#e5c477";

    const content = document.createElement("p");
    content.className = "new-dhikr-text";
    content.textContent = text;
    content.style.fontSize = fontSize + "px";
    content.style.lineHeight = "2";
    content.style.whiteSpace = "pre-wrap";

    const copy = document.createElement("button");
    copy.textContent = "نسخ الذكر";

    copy.onclick = async () => {
      try {
        await navigator.clipboard.writeText(text);
        copy.textContent = "تم النسخ ✓";
      } catch (error) {
        copy.textContent = "تعذر النسخ";
      }
    };

    const counter = document.createElement("div");
    counter.style.marginTop = "12px";
    counter.style.textAlign = "center";

    let repetitions = 0;

    const numberCount = document.createElement("p");
    numberCount.textContent = "التكرار: 0";

    const add = document.createElement("button");
    add.textContent = "تسبيح +";

    const reset = document.createElement("button");
    reset.textContent = "تصفير";

    add.onclick = () => {
      repetitions++;
      numberCount.textContent = "التكرار: " + repetitions;
    };

    reset.onclick = () => {
      repetitions = 0;
      numberCount.textContent = "التكرار: 0";
    };

    counter.append(numberCount, add, reset);

    card.append(number, content, copy, counter);
    container.appendChild(card);
  });

  if (footnote) {
    const note = document.createElement("p");
    note.textContent = Array.isArray(footnote)
      ? footnote.join(" ")
      : footnote;
    note.style.color = "#e5c477";
    note.style.lineHeight = "2";
    container.appendChild(note);
  }

  const bottomBack = document.createElement("button");
  bottomBack.textContent = "العودة إلى الأقسام";
  bottomBack.onclick = renderAdhkar;
  container.appendChild(bottomBack);
}
