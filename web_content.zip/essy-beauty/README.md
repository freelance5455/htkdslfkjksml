# Essy Beauty starter

A React Native + Expo starter for an Android/iPhone shopping app, with a separate responsive HTML browser preview.

## Native app (Android/iPhone)
1. Install Node.js LTS from https://nodejs.org/en/download and install Expo Go on your phone.
2. Open this project folder in a terminal.
3. Run `npm install`.
4. Run `npx expo start` and scan the QR code with Expo Go.

The native app UI is in `App.tsx`. `index.html` is not used to render the native Android/iPhone screens.

## Web preview
Open `web-preview/index.html` directly in a browser to view the separate HTML prototype. It has sample products, search, category filters, favourites and a demo shopping bag.

## Before launch
Product details and prices are sample data. No real accounts, order backend, inventory, or payments are connected. Bank transfer and card checkout require a secure backend/payment provider before accepting real orders. Do not collect card details in this demo.
