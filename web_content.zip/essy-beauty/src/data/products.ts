export type Product = {
  id: string;
  name: string;
  category: "Fashion" | "Makeup" | "Skincare" | "Accessories";
  price: number;
  description: string;
  image: string;
};

// Sample catalogue only. Replace these sample products, prices and photos with your real stock.
export const PRODUCTS: Product[] = [
  {
    id: "dress-01",
    name: "Everyday Chic Dress",
    category: "Fashion",
    price: 18500,
    description: "A versatile dress for casual outings and special moments. Add your actual sizes, fabric details and care instructions before selling.",
    image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=700"
  },
  {
    id: "bag-01",
    name: "Classic Mini Bag",
    category: "Accessories",
    price: 12500,
    description: "A compact accessory to complement your look. Replace this sample description with the exact product details.",
    image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=700"
  },
  {
    id: "makeup-01",
    name: "Velvet Lip Colour",
    category: "Makeup",
    price: 6500,
    description: "A makeup-bag essential. Add the shade range, ingredients, net content and supplier information for your actual product.",
    image: "https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=700"
  },
  {
    id: "skin-01",
    name: "Daily Glow Serum",
    category: "Skincare",
    price: 9800,
    description: "A skincare product listing placeholder. Replace with verified ingredients, directions and appropriate product claims.",
    image: "https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?w=700"
  },
  {
    id: "fashion-02",
    name: "Soft Neutral Top",
    category: "Fashion",
    price: 11000,
    description: "A simple wardrobe staple. Add the available colours, sizes and garment measurements.",
    image: "https://images.unsplash.com/photo-1551163943-3f6a855d1153?w=700"
  },
  {
    id: "accessory-02",
    name: "Minimal Gold Earrings",
    category: "Accessories",
    price: 7500,
    description: "A sample accessories listing. Add the true material, dimensions and care information before launch.",
    image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=700"
  }
];

export const CATEGORIES = ["All", "Fashion", "Makeup", "Skincare", "Accessories"];
