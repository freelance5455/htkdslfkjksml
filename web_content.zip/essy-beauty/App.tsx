import React, { useMemo, useState } from "react";
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Image,
  Alert,
} from "react-native";
import { StatusBar as ExpoStatusBar } from "expo-status-bar";
import { PRODUCTS, Product, CATEGORIES } from "./src/data/products";

type Tab = "Home" | "Shop" | "Saved" | "Bag" | "Profile";

const money = (amount: number) =>
  new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    maximumFractionDigits: 0,
  }).format(amount);

export default function App() {
  const [tab, setTab] = useState<Tab>("Home");
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [saved, setSaved] = useState<string[]>([]);
  const [bag, setBag] = useState<Record<string, number>>({});
  const [selected, setSelected] = useState<Product | null>(null);
  const [payment, setPayment] = useState<"Bank transfer" | "Card">("Bank transfer");

  const visibleProducts = useMemo(() => {
    let list = PRODUCTS;
    if (tab === "Saved") list = list.filter((p) => saved.includes(p.id));
    if (category !== "All" && tab === "Shop") {
      list = list.filter((p) => p.category === category);
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter((p) =>
        `${p.name} ${p.category} ${p.description}`.toLowerCase().includes(q)
      );
    }
    return list;
  }, [tab, category, search, saved]);

  const bagCount = Object.values(bag).reduce((sum, count) => sum + count, 0);
  const bagTotal = PRODUCTS.reduce(
    (sum, p) => sum + p.price * (bag[p.id] || 0),
    0
  );

  const addToBag = (product: Product) => {
    setBag((old) => ({ ...old, [product.id]: (old[product.id] || 0) + 1 }));
    Alert.alert("Added to bag", `${product.name} has been added to your shopping bag.`);
  };

  const toggleSaved = (product: Product) => {
    setSaved((old) =>
      old.includes(product.id)
        ? old.filter((id) => id !== product.id)
        : [...old, product.id]
    );
  };

  const changeQuantity = (id: string, delta: number) => {
    setBag((old) => {
      const next = Math.max(0, (old[id] || 0) + delta);
      const updated = { ...old };
      if (next === 0) delete updated[id];
      else updated[id] = next;
      return updated;
    });
  };

  const checkout = () => {
    Alert.alert(
      "Checkout preview",
      `Total: ${money(bagTotal)}\\nPayment: ${payment}\\n\\nThis demo does not process payments yet. A secure payment provider and order backend must be connected before launch.`
    );
  };

  const Header = () => (
    <View style={styles.header}>
      <View>
        <Text style={styles.brand}>ESSY BEAUTY</Text>
        <Text style={styles.tagline}>Fashion • Beauty • Confidence</Text>
      </View>
      <TouchableOpacity style={styles.bagButton} onPress={() => setTab("Bag")}>
        <Text style={styles.bagButtonText}>Bag ({bagCount})</Text>
      </TouchableOpacity>
    </View>
  );

  const ProductTile = ({ product }: { product: Product }) => (
    <View style={styles.productCard}>
      <TouchableOpacity onPress={() => setSelected(product)} activeOpacity={0.85}>
        <Image source={{ uri: product.image }} style={styles.productImage} />
        <Text style={styles.productCategory}>{product.category}</Text>
        <Text style={styles.productName}>{product.name}</Text>
        <Text style={styles.productPrice}>{money(product.price)}</Text>
      </TouchableOpacity>
      <View style={styles.productActions}>
        <TouchableOpacity
          style={styles.outlineButton}
          onPress={() => toggleSaved(product)}
        >
          <Text style={styles.outlineButtonText}>
            {saved.includes(product.id) ? "♥ Saved" : "♡ Save"}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.smallPrimaryButton} onPress={() => addToBag(product)}>
          <Text style={styles.smallPrimaryButtonText}>Add</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  const renderProducts = () => (
    <>
      <TextInput
        value={search}
        onChangeText={setSearch}
        placeholder="Search fashion and beauty..."
        placeholderTextColor="#9A8588"
        style={styles.search}
        autoCapitalize="none"
      />
      {tab === "Shop" && (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categories}>
          {CATEGORIES.map((item) => (
            <TouchableOpacity
              key={item}
              onPress={() => setCategory(item)}
              style={[styles.categoryPill, category === item && styles.categoryPillActive]}
            >
              <Text style={[styles.categoryText, category === item && styles.categoryTextActive]}>
                {item}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      )}
      {visibleProducts.length ? (
        <View style={styles.productGrid}>
          {visibleProducts.map((product) => (
            <View key={product.id} style={styles.productCell}>
              <ProductTile product={product} />
            </View>
          ))}
        </View>
      ) : (
        <View style={styles.emptyState}>
          <Text style={styles.emptyTitle}>Nothing here just yet</Text>
          <Text style={styles.muted}>Try another search or explore the shop.</Text>
        </View>
      )}
    </>
  );

  const renderHome = () => (
    <>
      <View style={styles.hero}>
        <Text style={styles.heroEyebrow}>YOUR STYLE, YOUR GLOW</Text>
        <Text style={styles.heroTitle}>Discover Your Glow</Text>
        <Text style={styles.heroCopy}>
          Your favourite fashion and beauty essentials, all in one place.
        </Text>
        <TouchableOpacity style={styles.heroButton} onPress={() => { setTab("Shop"); setCategory("All"); }}>
          <Text style={styles.heroButtonText}>Explore the collection</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.sectionHeading}>
        <Text style={styles.sectionTitle}>Featured picks</Text>
        <TouchableOpacity onPress={() => setTab("Shop")}>
          <Text style={styles.seeAll}>See all</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.productGrid}>
        {PRODUCTS.slice(0, 4).map((product) => (
          <View key={product.id} style={styles.productCell}>
            <ProductTile product={product} />
          </View>
        ))}
      </View>
    </>
  );

  const renderBag = () => {
    const items = PRODUCTS.filter((p) => (bag[p.id] || 0) > 0);
    return (
      <View>
        <Text style={styles.pageTitle}>Shopping bag</Text>
        {items.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyTitle}>Your bag is empty</Text>
            <Text style={styles.muted}>Add something you love from the shop.</Text>
            <TouchableOpacity style={styles.primaryButton} onPress={() => setTab("Shop")}>
              <Text style={styles.primaryButtonText}>Browse products</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <>
            {items.map((p) => (
              <View key={p.id} style={styles.bagItem}>
                <Image source={{ uri: p.image }} style={styles.bagImage} />
                <View style={styles.bagItemInfo}>
                  <Text style={styles.productName}>{p.name}</Text>
                  <Text style={styles.productPrice}>{money(p.price)}</Text>
                  <View style={styles.quantityRow}>
                    <TouchableOpacity style={styles.quantityButton} onPress={() => changeQuantity(p.id, -1)}>
                      <Text>−</Text>
                    </TouchableOpacity>
                    <Text style={styles.quantityText}>{bag[p.id]}</Text>
                    <TouchableOpacity style={styles.quantityButton} onPress={() => changeQuantity(p.id, 1)}>
                      <Text>+</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            ))}
            <View style={styles.totalRow}>
              <Text style={styles.totalLabel}>Subtotal</Text>
              <Text style={styles.totalValue}>{money(bagTotal)}</Text>
            </View>
            <Text style={styles.muted}>Delivery costs are calculated separately.</Text>
            <Text style={styles.fieldLabel}>Payment method</Text>
            {(["Bank transfer", "Card"] as const).map((method) => (
              <TouchableOpacity
                key={method}
                style={[styles.paymentOption, payment === method && styles.paymentOptionActive]}
                onPress={() => setPayment(method)}
              >
                <Text style={styles.paymentOptionText}>{method}</Text>
                <Text style={styles.paymentRadio}>{payment === method ? "●" : "○"}</Text>
              </TouchableOpacity>
            ))}
            <TouchableOpacity style={styles.primaryButton} onPress={checkout}>
              <Text style={styles.primaryButtonText}>Continue to checkout</Text>
            </TouchableOpacity>
          </>
        )}
      </View>
    );
  };

  const renderProfile = () => (
    <View>
      <Text style={styles.pageTitle}>My account</Text>
      <View style={styles.profileCard}>
        <Text style={styles.profileEmoji}>♡</Text>
        <Text style={styles.sectionTitle}>Welcome to Essy Beauty</Text>
        <Text style={styles.muted}>
          Customer sign-in, saved delivery addresses and order history will be connected in the next build.
        </Text>
      </View>
      <Text style={styles.fieldLabel}>Coming next</Text>
      {["Sign in / create account", "Delivery addresses", "My orders", "Contact customer care"].map((item) => (
        <View key={item} style={styles.profileRow}>
          <Text style={styles.profileRowText}>{item}</Text>
          <Text style={styles.muted}>›</Text>
        </View>
      ))}
    </View>
  );

  const renderContent = () => {
    if (selected) {
      return (
        <View>
          <TouchableOpacity onPress={() => setSelected(null)} style={styles.backButton}>
            <Text style={styles.seeAll}>‹ Back to shop</Text>
          </TouchableOpacity>
          <Image source={{ uri: selected.image }} style={styles.detailImage} />
          <Text style={styles.productCategory}>{selected.category}</Text>
          <Text style={styles.pageTitle}>{selected.name}</Text>
          <Text style={styles.productPrice}>{money(selected.price)}</Text>
          <Text style={styles.detailDescription}>{selected.description}</Text>
          <TouchableOpacity style={styles.primaryButton} onPress={() => addToBag(selected)}>
            <Text style={styles.primaryButtonText}>Add to bag</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.outlineWideButton} onPress={() => toggleSaved(selected)}>
            <Text style={styles.outlineButtonText}>
              {saved.includes(selected.id) ? "♥ Remove from saved" : "♡ Save to favourites"}
            </Text>
          </TouchableOpacity>
        </View>
      );
    }
    if (tab === "Bag") return renderBag();
    if (tab === "Profile") return renderProfile();
    if (tab === "Home") return renderHome();
    return (
      <>
        <Text style={styles.pageTitle}>{tab === "Saved" ? "Your favourites" : "Shop our collection"}</Text>
        {renderProducts()}
      </>
    );
  };

  return (
    <SafeAreaView style={styles.safe}>
      <ExpoStatusBar style="dark" />
      <StatusBar barStyle="dark-content" backgroundColor="#FFF8F6" />
      <Header />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {renderContent()}
        <Text style={styles.footer}>ESSY BEAUTY  •  Fashion, beauty and confidence</Text>
      </ScrollView>
      <View style={styles.tabBar}>
        {(["Home", "Shop", "Saved", "Bag", "Profile"] as Tab[]).map((item) => (
          <TouchableOpacity key={item} style={styles.tabItem} onPress={() => { setSelected(null); setTab(item); }}>
            <Text style={[styles.tabLabel, tab === item && styles.tabLabelActive]}>{item}</Text>
            {item === "Bag" && bagCount > 0 ? <Text style={styles.tabCount}>{bagCount}</Text> : null}
          </TouchableOpacity>
        ))}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#FFF8F6" },
  header: { paddingHorizontal: 20, paddingTop: 10, paddingBottom: 15, flexDirection: "row", justifyContent: "space-between", alignItems: "center", borderBottomWidth: 1, borderBottomColor: "#F0E2E0" },
  brand: { color: "#9D4B63", fontSize: 20, fontWeight: "800", letterSpacing: 2 },
  tagline: { color: "#8C777B", fontSize: 11, marginTop: 3 },
  bagButton: { backgroundColor: "#9D4B63", paddingHorizontal: 14, paddingVertical: 10, borderRadius: 18 },
  bagButtonText: { color: "#FFFFFF", fontSize: 12, fontWeight: "700" },
  content: { padding: 18, paddingBottom: 28 },
  hero: { backgroundColor: "#F5E3E2", borderRadius: 22, padding: 22, marginBottom: 24 },
  heroEyebrow: { color: "#9D4B63", fontSize: 10, fontWeight: "800", letterSpacing: 2 },
  heroTitle: { color: "#512E38", fontSize: 30, fontWeight: "800", marginTop: 10 },
  heroCopy: { color: "#76545D", fontSize: 14, lineHeight: 21, marginTop: 8, maxWidth: 270 },
  heroButton: { alignSelf: "flex-start", backgroundColor: "#9D4B63", borderRadius: 12, paddingHorizontal: 16, paddingVertical: 12, marginTop: 18 },
  heroButtonText: { color: "#FFFFFF", fontWeight: "700", fontSize: 12 },
  sectionHeading: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 },
  sectionTitle: { color: "#39282C", fontSize: 18, fontWeight: "800" },
  seeAll: { color: "#9D4B63", fontSize: 13, fontWeight: "700" },
  pageTitle: { color: "#39282C", fontSize: 24, fontWeight: "800", marginBottom: 16 },
  search: { backgroundColor: "#FFFFFF", borderColor: "#EAD9D9", borderWidth: 1, borderRadius: 13, paddingHorizontal: 14, paddingVertical: 12, marginBottom: 13, color: "#39282C" },
  categories: { marginBottom: 14, maxHeight: 42 },
  categoryPill: { borderColor: "#E6D2D4", borderWidth: 1, borderRadius: 18, paddingHorizontal: 14, paddingVertical: 9, marginRight: 8, backgroundColor: "#FFFFFF" },
  categoryPillActive: { backgroundColor: "#9D4B63", borderColor: "#9D4B63" },
  categoryText: { color: "#76545D", fontSize: 12, fontWeight: "600" },
  categoryTextActive: { color: "#FFFFFF" },
  productGrid: { flexDirection: "row", flexWrap: "wrap", marginHorizontal: -5 },
  productCell: { width: "50%", paddingHorizontal: 5, marginBottom: 12 },
  productCard: { backgroundColor: "#FFFFFF", borderRadius: 15, padding: 9, borderColor: "#F0E2E0", borderWidth: 1 },
  productImage: { width: "100%", height: 138, borderRadius: 10, backgroundColor: "#F5EAE8" },
  productCategory: { color: "#9D4B63", fontSize: 10, fontWeight: "700", textTransform: "uppercase", marginTop: 9 },
  productName: { color: "#39282C", fontSize: 13, fontWeight: "700", marginTop: 4 },
  productPrice: { color: "#9D4B63", fontSize: 14, fontWeight: "800", marginTop: 5 },
  productActions: { flexDirection: "row", gap: 6, marginTop: 10 },
  outlineButton: { flex: 1, borderWidth: 1, borderColor: "#E6D2D4", borderRadius: 9, paddingVertical: 8, alignItems: "center" },
  outlineButtonText: { color: "#9D4B63", fontSize: 11, fontWeight: "700" },
  smallPrimaryButton: { backgroundColor: "#9D4B63", borderRadius: 9, paddingHorizontal: 12, justifyContent: "center" },
  smallPrimaryButtonText: { color: "#FFFFFF", fontSize: 11, fontWeight: "700" },
  emptyState: { alignItems: "center", paddingVertical: 45, paddingHorizontal: 18 },
  emptyTitle: { color: "#39282C", fontSize: 18, fontWeight: "800", marginBottom: 7 },
  muted: { color: "#8C777B", fontSize: 12, lineHeight: 18 },
  primaryButton: { backgroundColor: "#9D4B63", paddingVertical: 15, paddingHorizontal: 18, borderRadius: 12, alignItems: "center", marginTop: 18 },
  primaryButtonText: { color: "#FFFFFF", fontWeight: "800", fontSize: 13 },
  outlineWideButton: { borderColor: "#E6D2D4", borderWidth: 1, paddingVertical: 14, borderRadius: 12, alignItems: "center", marginTop: 10 },
  bagItem: { flexDirection: "row", padding: 10, backgroundColor: "#FFFFFF", borderRadius: 14, marginBottom: 10, borderWidth: 1, borderColor: "#F0E2E0" },
  bagImage: { width: 86, height: 92, borderRadius: 10, backgroundColor: "#F5EAE8" },
  bagItemInfo: { flex: 1, marginLeft: 12, justifyContent: "center" },
  quantityRow: { flexDirection: "row", alignItems: "center", marginTop: 9, gap: 12 },
  quantityButton: { width: 28, height: 28, borderRadius: 8, backgroundColor: "#F7E7E6", alignItems: "center", justifyContent: "center" },
  quantityText: { color: "#39282C", fontWeight: "700" },
  totalRow: { flexDirection: "row", justifyContent: "space-between", paddingTop: 16, marginTop: 8, borderTopWidth: 1, borderTopColor: "#EAD9D9" },
  totalLabel: { color: "#39282C", fontSize: 15, fontWeight: "700" },
  totalValue: { color: "#9D4B63", fontSize: 18, fontWeight: "800" },
  fieldLabel: { color: "#39282C", fontSize: 13, fontWeight: "800", marginTop: 20, marginBottom: 8 },
  paymentOption: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 14, borderWidth: 1, borderColor: "#E6D2D4", borderRadius: 12, marginBottom: 8, backgroundColor: "#FFFFFF" },
  paymentOptionActive: { borderColor: "#9D4B63", backgroundColor: "#FBEFF0" },
  paymentOptionText: { color: "#39282C", fontWeight: "600", fontSize: 13 },
  paymentRadio: { color: "#9D4B63", fontSize: 16 },
  profileCard: { alignItems: "center", backgroundColor: "#F5E3E2", padding: 24, borderRadius: 18 },
  profileEmoji: { color: "#9D4B63", fontSize: 40, marginBottom: 8 },
  profileRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 16, borderBottomWidth: 1, borderBottomColor: "#F0E2E0" },
  profileRowText: { color: "#39282C", fontSize: 13, fontWeight: "600" },
  detailImage: { width: "100%", height: 300, borderRadius: 18, backgroundColor: "#F5EAE8", marginBottom: 12 },
  detailDescription: { color: "#76545D", fontSize: 14, lineHeight: 22, marginTop: 12 },
  backButton: { marginBottom: 12 },
  footer: { color: "#B5A0A4", textAlign: "center", fontSize: 10, marginTop: 25, marginBottom: 8 },
  tabBar: { flexDirection: "row", justifyContent: "space-around", paddingTop: 11, paddingBottom: 12, borderTopWidth: 1, borderTopColor: "#F0E2E0", backgroundColor: "#FFFFFF" },
  tabItem: { minWidth: 48, alignItems: "center" },
  tabLabel: { color: "#9B858A", fontSize: 11, fontWeight: "600" },
  tabLabelActive: { color: "#9D4B63", fontWeight: "800" },
  tabCount: { color: "#9D4B63", fontSize: 9, fontWeight: "800", marginTop: 2 }
});
