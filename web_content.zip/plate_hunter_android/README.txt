PLATE HUNTER — Android project

Содержимое:
- app/src/main/assets/index.html — сама игра
- MainActivity.java — Android WebView-оболочка
- Gradle-конфигурация для сборки APK в Android Studio

Как получить APK:
1. Установите Android Studio на компьютер.
2. Откройте папку plate_hunter_android в Android Studio.
3. Дождитесь загрузки Gradle и Android SDK (compileSdk 35).
4. Выберите Build → Build Bundle(s) / APK(s) → Build APK(s).
5. APK появится в app/build/outputs/apk/debug/app-debug.apk.

В этом окружении Android SDK/Gradle отсутствуют, поэтому собранный APK приложить не могу. Проект подготовлен для сборки. Для быстрого запуска можно открыть app/src/main/assets/index.html в браузере телефона.
