THE HAUNTED HOSPITAL 3D
=======================

Kaise chalayein:
1. Zip ko extract karo.
2. index.html ko Chrome me kholo (phone me: Files app se "Open with Chrome").
   Spck Editor ka built-in Preview use mat karo, usme 3D (WebGL) nahi chalta.
3. Internet on rakho, kyunki Three.js CDN se load hota hai.
   Offline chalane ke liye: three.min.js (r128) download karke index.html ke saath wali
   folder me rakh do. Game apne aap use utha legi.

Controls:
- PC: WASD chalo, Shift daudo, Mouse dekho, E interact, F torch, C crouch, I backpack
- Mobile: left joystick, right taraf swipe se dekho, E / torch / backpack / crouch / run buttons
  (landscape me khelo)

Optional intro video:
- Koi bhi video "intro.mp4" naam se index.html ke saath wali folder me rakho.
  Game pehle wahi chalayegi. Na mile to apna cinematic intro chalega.

Online daalna (dost bhi khel sakein):
- GitHub Pages ya app.netlify.com/drop par poori folder daal do, link mil jayega.
