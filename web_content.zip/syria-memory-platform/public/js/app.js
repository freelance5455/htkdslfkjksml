const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
let governorates = [];
let quizQuestions = [];
let quizIndex = 0, quizScore = 0, quizLocked = false;
let chatHistory = [];
let map = null, mapMarkers = [];
const savedScore = () => Number(localStorage.getItem("syriaQuizBest") || 0);

function toast(message) {
  const el = $("#toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer = setTimeout(()=>el.classList.remove("show"), 3000);
}
function showPage(name) {
  $$(".page").forEach(p=>p.classList.toggle("active", p.id === `page-${name}`));
  $$(".nav-link").forEach(b=>b.classList.toggle("active", b.dataset.page === name));
  closeMenu(); window.scrollTo({top:0,behavior:"smooth"});
  if(name==="map") setTimeout(()=>map?.invalidateSize(),100);
  if(name==="future") loadProjects();
  if(name==="quiz") loadLeaderboard();
}
function closeMenu(){ $("#sidebar").classList.remove("open"); $("#scrim").classList.remove("show"); }
$("#menuToggle").addEventListener("click",()=>{$("#sidebar").classList.toggle("open");$("#scrim").classList.toggle("show");});
$("#scrim").addEventListener("click",closeMenu);
$$("[data-page]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.page)));
$$("[data-go]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.go)));

async function checkHealth(){
  try {
    const r=await fetch("/api/health"); const d=await r.json();
    $("#connectionText").textContent = d.ok ? "متصل بالمنصة" : "غير متصل";
    $("#connectionText").previousElementSibling.style.background=d.ok?"#83b88b":"#b38f45";
    if(!d.aiConfigured) $("#connectionText").textContent="المساعد بانتظار الإعداد";
  } catch { $("#connectionText").textContent="تعذر الاتصال"; }
}

async function loadGovernorates(){
  try { const r=await fetch("/api/governorates"); governorates=await r.json(); }
  catch { toast("تعذر تحميل بيانات المحافظات."); return; }
  const list=$("#governorateList"); list.innerHTML="";
  governorates.forEach((g,i)=>{
    const b=document.createElement("button"); b.className="gov-btn"; b.textContent=g.name;
    b.addEventListener("click",()=>selectGovernorate(i)); list.appendChild(b);
  });
  if(window.L && !map){
    map=L.map("syriaMap",{scrollWheelZoom:false}).setView([35.1,38.8],6);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:12,attribution:'© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'}).addTo(map);
    governorates.forEach((g,i)=>{
      const marker=L.marker([g.lat,g.lng]).addTo(map).bindPopup(`<b>${g.name}</b><br><button class="map-popup-btn" onclick="window.selectGovFromMap(${i})">عرض المعلومات</button>`);
      mapMarkers.push(marker);
    });
  }
  window.selectGovFromMap=selectGovernorate;
  selectGovernorate(0);
}
function selectGovernorate(i){
  const g=governorates[i]; if(!g)return;
  $$(".gov-btn").forEach((b,n)=>b.classList.toggle("active",n===i));
  $("#govDetail").innerHTML=`<b>${g.name}</b><p>${g.note}</p><small>الموقع الجغرافي للعلامة تقريبي.</small>`;
  if(map) map.setView([g.lat,g.lng],7,{animate:true});
}

async function loadMuseum(){
  try{
    const r=await fetch("/api/museum"); const items=await r.json();
    renderMuseum(items);
  }catch{toast("تعذر تحميل المتحف.");}
}
function renderMuseum(items){
  const box=$("#museumGrid"); box.innerHTML="";
  items.forEach(item=>{
    const article=document.createElement("article"); article.className="museum-card"; article.dataset.category=item.category;
    const meta=document.createElement("div"); meta.className="meta"; meta.textContent=`${item.category} • ${item.year}`;
    const title=document.createElement("h3"); title.textContent=item.title;
    const summary=document.createElement("p"); summary.textContent=item.summary;
    const body=document.createElement("p"); body.textContent=item.body;
    const actions=document.createElement("div"); actions.className="card-actions";
    const speak=document.createElement("button"); speak.className="mini-btn"; speak.textContent="استمع للنص";
    speak.addEventListener("click",()=>speak(`${item.title}. ${item.summary} ${item.body}`));
    const source=document.createElement("span"); source.className="source"; source.textContent=item.source;
    actions.append(speak,source); article.append(meta,title,summary,body,actions); box.append(article);
  });
}
$$(".filter").forEach(btn=>btn.addEventListener("click",()=>{
  $$(".filter").forEach(x=>x.classList.remove("active")); btn.classList.add("active");
  $$(".museum-card").forEach(card=>card.style.display=(btn.dataset.filter==="الكل"||card.dataset.category===btn.dataset.filter)?"block":"none");
}));
function speak(text){
  if(!("speechSynthesis" in window)){toast("القراءة الصوتية غير مدعومة في هذا المتصفح.");return;}
  speechSynthesis.cancel(); const u=new SpeechSynthesisUtterance(text); u.lang="ar";u.rate=.92;speechSynthesis.speak(u);
}

function addBubble(text, role){
  const el=document.createElement("div");el.className=`bubble ${role}`;el.textContent=text;$("#chatMessages").append(el);$("#chatMessages").scrollTop=$("#chatMessages").scrollHeight;return el;
}
async function sendChat(message){
  if(!message.trim())return;
  addBubble(message,"user");$("#chatInput").value="";
  const wait=addBubble("أفكر في إجابة مناسبة…","bot thinking");
  try{
    const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message,history:chatHistory})});
    const d=await r.json(); if(!r.ok)throw new Error(d.error||"تعذر الاتصال.");
    wait.textContent=d.answer;wait.classList.remove("thinking");
    chatHistory.push({role:"user",text:message},{role:"model",text:d.answer});chatHistory=chatHistory.slice(-10);
  }catch(e){wait.textContent=e.message;wait.classList.remove("thinking");}
  $("#chatMessages").scrollTop=$("#chatMessages").scrollHeight;
}
$("#chatForm").addEventListener("submit",e=>{e.preventDefault();sendChat($("#chatInput").value);});
$("#clearChat").addEventListener("click",()=>{chatHistory=[];$("#chatMessages").innerHTML="";addBubble("بدأنا محادثة جديدة. ما الذي تريد معرفته؟","bot");});
$$(".suggestions button").forEach(b=>b.addEventListener("click",()=>sendChat(b.textContent)));

async function loadQuiz(){
  try{const r=await fetch("/api/quiz");quizQuestions=await r.json();renderQuestion();}
  catch{toast("تعذر تحميل المسابقة.");}
}
function renderQuestion(){
  const area=$("#quizArea");
  if(quizIndex>=quizQuestions.length){
    const best=Math.max(savedScore(),quizScore);localStorage.setItem("syriaQuizBest",best);$("#homeScore").textContent=best;
    area.innerHTML=`<div class="quiz-question">انتهت المسابقة!</div><p>نتيجتك: <b>${quizScore} من 100</b></p><label>اسم مستعار للوحة الترتيب<input id="quizNickname" maxlength="20" placeholder="مثلاً: طالب المعرفة"></label><button class="btn gold" id="saveQuiz">حفظ النتيجة</button> <button class="btn outline" id="restartQuiz">إعادة المسابقة</button>`;
    $("#saveQuiz").addEventListener("click",saveQuizScore);$("#restartQuiz").addEventListener("click",()=>{quizIndex=0;quizScore=0;renderQuestion();});
    $("#quizProgress").style.width="100%";$("#quizProgressText").textContent="اكتملت المسابقة";$("#quizLiveScore").textContent=`${quizScore} نقطة`;return;
  }
  const q=quizQuestions[quizIndex];quizLocked=false;
  $("#quizProgressText").textContent=`السؤال ${quizIndex+1} من ${quizQuestions.length}`;$("#quizLiveScore").textContent=`${quizScore} نقطة`;$("#quizProgress").style.width=`${quizIndex/quizQuestions.length*100}%`;
  area.innerHTML=`<div class="quiz-question">${q.q}</div><div class="answer-list">${q.a.map((a,i)=>`<button class="answer-btn" data-answer="${i}">${a}</button>`).join("")}</div><div id="quizFeedback" class="quiz-feedback"></div>`;
  $$(".answer-btn").forEach(btn=>btn.addEventListener("click",()=>answerQuestion(Number(btn.dataset.answer))));
}
async function answerQuestion(index){
  if(quizLocked)return;quizLocked=true;const q=quizQuestions[quizIndex];const buttons=$$(".answer-btn");
  buttons.forEach((b,i)=>{b.disabled=true;if(i===q.correct)b.classList.add("correct");if(i===index&&index!==q.correct)b.classList.add("wrong");});
  const correct=index===q.correct;if(correct)quizScore+=10;
  $("#quizLiveScore").textContent=`${quizScore} نقطة`;
  $("#quizFeedback").textContent=(correct?"إجابة صحيحة. ":"إجابة غير صحيحة. ")+q.why;
  const next=document.createElement("button");next.className="btn gold";next.style.marginTop="15px";next.textContent=quizIndex===quizQuestions.length-1?"عرض النتيجة":"السؤال التالي";next.addEventListener("click",()=>{quizIndex++;renderQuestion();});$("#quizFeedback").append(document.createElement("br"),next);
}
async function saveQuizScore(){
  const nickname=$("#quizNickname").value.trim();if(nickname.length<2){toast("اكتب اسماً مستعاراً من حرفين على الأقل.");return;}
  try{const r=await fetch("/api/leaderboard",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({nickname,score:quizScore})});const d=await r.json();if(!r.ok)throw new Error(d.error);toast(d.message);loadLeaderboard();}
  catch(e){toast(e.message||"تعذر حفظ النتيجة.");}
}
async function loadLeaderboard(){
  try{const r=await fetch("/api/leaderboard");const d=await r.json();const box=$("#leaderboard");box.innerHTML="";
    if(!d.scores?.length){box.innerHTML='<p class="note">لا توجد نتائج منشورة بعد.</p>';return;}
    d.scores.forEach((s,i)=>{const row=document.createElement("div");row.className="leader-row";const n=document.createElement("span");n.textContent=`${i+1}. ${s.nickname}`;const score=document.createElement("b");score.textContent=`${s.score} نقطة`;row.append(n,score);box.append(row);});
  }catch{$("#leaderboard").innerHTML='<p class="note">تعذر تحميل النتائج.</p>';}
}

async function loadProjects(){
  const box=$("#projectsList");box.innerHTML='<p class="note">جارٍ تحميل المبادرات…</p>';
  try{const r=await fetch("/api/projects");const d=await r.json();box.innerHTML="";
    if(!d.projects?.length){box.innerHTML='<p class="note">لا توجد مبادرات منشورة حالياً. كن أول من يقترح فكرة!</p>';return;}
    d.projects.forEach(p=>{
      const card=document.createElement("article");card.className="project-item";
      const title=document.createElement("b");title.textContent=p.title;
      const desc=document.createElement("p");desc.textContent=p.description;
      const meta=document.createElement("div");meta.className="project-meta";meta.textContent=`${p.category} • ${p.votes||0} تصويت`;
      const vote=document.createElement("button");vote.className="vote-btn";vote.textContent="أؤيد الفكرة";
      vote.addEventListener("click",async()=>{try{const vr=await fetch(`/api/projects/${encodeURIComponent(p.id)}/vote`,{method:"POST"});const vd=await vr.json();if(!vr.ok)throw new Error(vd.error);toast("تم تسجيل تأييدك.");loadProjects();}catch(e){toast(e.message||"تعذر التصويت.");}});
      card.append(title,desc,meta,vote);box.append(card);
    });
  }catch{box.innerHTML='<p class="note">تعذر تحميل المبادرات.</p>';}
}
$("#refreshProjects").addEventListener("click",loadProjects);
$("#projectForm").addEventListener("submit",async e=>{
  e.preventDefault();const payload={title:$("#projectTitle").value.trim(),category:$("#projectCategory").value,description:$("#projectDescription").value.trim()};
  const msg=$("#projectMessage");msg.textContent="جارٍ إرسال المبادرة…";
  try{const r=await fetch("/api/projects",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});const d=await r.json();if(!r.ok)throw new Error(d.error);msg.textContent=d.message;$("#projectForm").reset();}
  catch(err){msg.textContent=err.message||"تعذر إرسال المبادرة.";}
});

checkHealth();loadGovernorates();loadMuseum();loadQuiz();loadLeaderboard();loadProjects();
$("#homeScore").textContent=savedScore();
