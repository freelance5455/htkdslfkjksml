-- Run this script in the Supabase SQL Editor.
-- Keep the service-role key on the server only. Never place it in browser JavaScript.

create extension if not exists pgcrypto;

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  title varchar(90) not null,
  category varchar(40) not null,
  description varchar(1200) not null,
  status varchar(20) not null default 'pending' check (status in ('pending','approved','rejected')),
  votes integer not null default 0 check (votes >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.quiz_scores (
  id uuid primary key default gen_random_uuid(),
  nickname varchar(20) not null,
  score integer not null check (score between 0 and 100),
  created_at timestamptz not null default now()
);

alter table public.projects enable row level security;
alter table public.quiz_scores enable row level security;

-- Browser users have no direct table access. The Node server uses the service role key.
revoke all on public.projects from anon, authenticated;
revoke all on public.quiz_scores from anon, authenticated;

create or replace function public.vote_for_project(project_id uuid)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare new_votes integer;
begin
  update public.projects
  set votes = votes + 1
  where id = project_id and status = 'approved'
  returning votes into new_votes;

  if new_votes is null then
    raise exception 'Project not found or not approved';
  end if;
  return new_votes;
end;
$$;

revoke all on function public.vote_for_project(uuid) from public, anon, authenticated;
grant execute on function public.vote_for_project(uuid) to service_role;
