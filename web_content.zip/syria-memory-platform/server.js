import "dotenv/config";
import express from "express";
import helmet from "helmet";
import compression from "compression";
import rateLimit from "express-rate-limit";
import { GoogleGenAI } from "@google/genai";
import { createClient } from "@supabase/supabase-js";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 8080);
const MODEL = process.env.GEMINI_MODEL || "gemini-3.8-flash";

app.set("trust proxy", 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "https://unpkg.com"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://unpkg.com"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'", "https://*.supabase.co", "https://generativelanguage.googleapis.com"],
      fontSrc: ["'self'", "data:", "https:"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: []
    }
  }
}));
app.use(compression());
app.use(express.json({ limit: "80kb" }));
app.use(express.static(path.join(__dirname, "public"), { maxAge: "1h" }));

const ai = process.env.GEMINI_API_KEY
  ? new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY })
  : null;

const supabase = process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY
  ? createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, {
      auth: { persistSession: false, autoRefreshToken: false }
    })
  : null;

const chatLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 12,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "طلبات كثيرة خلال وقت قصير. انتظر دقيقة ثم حاول مجدداً." }
});
const submitLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: 8,
  standardHeaders: "draft-8",
  legacyHeaders: false
});

const governorates = [
  { name:"دمشق", lat:33.5138, lng:36.2765, note:"العاصمة السورية، وتضم معالم تاريخية وثقافية بارزة." },
  { name:"ريف دمشق", lat:33.6, lng:36.4, note:"محافظة تحيط بالعاصمة وتضم مدناً وبلدات ومناطق طبيعية متنوعة." },
  { name:"حلب", lat:36.2021, lng:37.1343, note:"مدينة تاريخية مهمة في شمال سوريا." },
  { name:"حمص", lat:34.7324, lng:36.7137, note:"تقع في وسط سوريا وتتميز بموقعها الذي يربط مناطق البلاد." },
  { name:"حماة", lat:35.1318, lng:36.7515, note:"مدينة سورية معروفة بتاريخها ومعالمها المائية والتراثية." },
  { name:"اللاذقية", lat:35.5317, lng:35.7901, note:"مدينة ساحلية على البحر الأبيض المتوسط." },
  { name:"طرطوس", lat:34.8890, lng:35.8866, note:"محافظة ساحلية لها تراث بحري ومواقع تاريخية." },
  { name:"إدلب", lat:35.9306, lng:36.6339, note:"تقع في شمال غرب سوريا." },
  { name:"دير الزور", lat:35.3359, lng:40.1408, note:"مدينة تقع على نهر الفرات في شرق سوريا." },
  { name:"الرقة", lat:35.9594, lng:39.0098, note:"مدينة على الضفة الشمالية لنهر الفرات." },
  { name:"الحسكة", lat:36.5024, lng:40.7477, note:"تقع في شمال شرق سوريا." },
  { name:"درعا", lat:32.6189, lng:36.1021, note:"تقع في جنوب سوريا." },
  { name:"السويداء", lat:32.7089, lng:36.5695, note:"محافظة جنوبية تتميز بطبيعتها الجبلية وتراثها." },
  { name:"القنيطرة", lat:33.1250, lng:35.8240, note:"تقع في جنوب غرب سوريا." }
];

const quizQuestions = [
  { q:"كم عدد المحافظات السورية؟", a:["12","13","14","15"], correct:2, why:"تتألف سوريا إدارياً من 14 محافظة." },
  { q:"ما عاصمة سوريا؟", a:["حلب","دمشق","حمص","حماة"], correct:1, why:"دمشق هي عاصمة الجمهورية العربية السورية." },
  { q:"على أي بحر تطل اللاذقية؟", a:["البحر الأحمر","البحر المتوسط","البحر الأسود","بحر العرب"], correct:1, why:"اللاذقية مدينة ساحلية على البحر الأبيض المتوسط." },
  { q:"في أي عام بدأت الاحتجاجات الشعبية في سوريا؟", a:["2008","2010","2011","2013"], correct:2, why:"بدأت الاحتجاجات الشعبية في سوريا عام 2011." },
  { q:"أي نهر يرتبط بمدينة الرقة؟", a:["العاصي","بردى","الفرات","الخابور"], correct:2, why:"تقع الرقة على نهر الفرات." },
  { q:"في أي جزء من سوريا تقع دير الزور؟", a:["الشرق","الغرب","الساحل","الجنوب الغربي"], correct:0, why:"تقع دير الزور في شرق سوريا." },
  { q:"ما المجال الأساسي لبناء قدرات الأجيال؟", a:["التعليم","العزلة","الإهمال","التوقف"], correct:0, why:"التعليم من أهم أسس تنمية المجتمع." },
  { q:"أي مدينة سورية ساحلية؟", a:["حماة","اللاذقية","الرقة","الحسكة"], correct:1, why:"اللاذقية مدينة ساحلية." },
  { q:"أين تقع السويداء؟", a:["شمال سوريا","جنوب سوريا","شرق سوريا","الساحل"], correct:1, why:"تقع السويداء في جنوب سوريا." },
  { q:"ما الهدف من توثيق التاريخ؟", a:["حفظ المعرفة","اختلاق الوقائع","إخفاء المصادر","إلغاء الاختلاف"], correct:0, why:"التوثيق يساعد على حفظ المعرفة ومراجعة المصادر." }
];

const museumSeed = [
  { id:"m1", title:"سوريا عبر العصور", category:"تاريخ", year:"مدخل عام", summary:"تقع سوريا عند ملتقى طرق تاريخية، وشهدت أرضها تعاقب حضارات وممالك وإمبراطوريات تركت آثاراً مادية وثقافية.", body:"تضم سوريا مواقع أثرية ومدناً تاريخية تعكس تنوعاً حضارياً واسعاً. ينبغي دراسة كل موقع بالاعتماد على مؤسسات التراث والآثار والمراجع الأكاديمية، مع ذكر تاريخ النشر ومصدر كل وثيقة.", source:"مدخل تعريفي؛ أضف مرجعاً متخصصاً قبل النشر النهائي.", audio:true },
  { id:"m2", title:"التراث السوري", category:"ثقافة", year:"تراث متجدد", summary:"يشمل التراث السوري العمارة والأسواق والحرف والموسيقى والمطبخ والعادات المحلية المتنوعة.", body:"حماية التراث مسؤولية ثقافية ومجتمعية. يمكن للطلاب جمع صور ووصف للحرف والمباني بموافقة أصحابها، مع تسجيل المكان والتاريخ واسم المصدر.", source:"مادة تثقيفية عامة؛ يلزم إرفاق مصادر محلية موثقة.", audio:true },
  { id:"m3", title:"عام 2011 والتحولات السورية", category:"تاريخ معاصر", year:"2011", summary:"شهد عام 2011 بدء احتجاجات شعبية في سوريا، ثم دخلت البلاد في تحولات سياسية وإنسانية واسعة.", body:"تتباين الروايات حول كثير من أحداث التاريخ المعاصر؛ لذلك يعرض هذا المتحف الوقائع مع تواريخها ومصادرها، ويميّز بين المعلومة المؤكدة والشهادة الشخصية والتحليل.", source:"ينبغي إضافة مصادر مستقلة متعددة لكل حدث محدد.", audio:true },
  { id:"m4", title:"التعليم في أوقات الأزمات", category:"إنسان", year:"قضية مستمرة", summary:"استمرار التعليم وحماية حق الأطفال في التعلم عنصران أساسيان في التعافي المجتمعي.", body:"يمكن للمدارس والطلاب توثيق المبادرات التعليمية وقصص التعلم بموافقة أصحابها، دون نشر أسماء أو بيانات حساسة للقاصرين.", source:"مادة توعوية؛ أضف تقارير تعليمية موثوقة عند التوسع.", audio:true },
  { id:"m5", title:"حكايات الناس وذاكرة المكان", category:"شهادات", year:"أرشيف مفتوح", summary:"تحفظ الشهادات الشفوية جوانب من التجربة الإنسانية، لكنها تحتاج إلى موافقة واضحة ومراجعة دقيقة.", body:"لا تُنشر شهادة شخصية إلا بموافقة صاحبها، مع توضيح إن كانت شهادة مباشرة أو منقولة، وإتاحة طلب التصحيح أو الحذف. لا تجمع بيانات حساسة عن الضحايا أو الأطفال.", source:"سياسة توثيق أخلاقية للمشروع.", audio:true }
];

function cleanText(value, max = 1200) {
  return String(value ?? "").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").trim().slice(0, max);
}
function adminAllowed(req) {
  const token = req.get("x-admin-token") || "";
  return Boolean(process.env.ADMIN_TOKEN && token && token === process.env.ADMIN_TOKEN);
}
async function dbInsert(table, row) {
  if (!supabase) return { data: null, error: new Error("DATABASE_NOT_CONFIGURED") };
  return await supabase.from(table).insert(row).select().single();
}
async function dbList(table, query) {
  if (!supabase) return { data: [], error: new Error("DATABASE_NOT_CONFIGURED") };
  return await query(supabase.from(table)).select("*");
}

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    aiConfigured: Boolean(ai),
    databaseConfigured: Boolean(supabase),
    model: MODEL
  });
});

app.get("/api/governorates", (_req, res) => res.json(governorates));
app.get("/api/quiz", (_req, res) => {
  res.json(quizQuestions.map(({q,a}, index) => ({ id:index, q, a })));
});
app.get("/api/museum", (_req, res) => res.json(museumSeed));

app.post("/api/chat", chatLimiter, async (req, res) => {
  try {
    if (!ai) return res.status(503).json({ error:"المساعد الذكي غير مفعّل بعد. أضف GEMINI_API_KEY إلى إعدادات الخادم." });
    const message = cleanText(req.body?.message, 3000);
    const history = Array.isArray(req.body?.history) ? req.body.history.slice(-10) : [];
    if (!message) return res.status(400).json({ error:"اكتب سؤالك أولاً." });

    const safeHistory = history.map(item => ({
      role: item.role === "model" ? "model" : "user",
      parts: [{ text: cleanText(item.text, 1800) }]
    })).filter(item => item.parts[0].text);

    const systemInstruction = `
أنت "مِشكاة"، مساعد معرفي داخل مشروع طلابي اسمه "سوريا | ذاكرة وطن ومستقبل أمة".
أجب بالعربية الواضحة، ويمكنك فهم اللهجة السورية. كن محترماً ومتوازناً وغير تحريضي.
اختصّ بتاريخ سوريا وجغرافيتها وثقافتها وتراثها والتعليم والتنمية وإعادة الإعمار والمواطنة.
لا تختلق تواريخ أو أسماء أو أرقاماً أو مراجع. إذا لم تكن متأكداً فقل ذلك بوضوح واقترح التحقق من مصادر موثوقة.
ميّز بين الحقيقة التاريخية، والرأي، والشهادة الشخصية. عند تناول الأحداث المعاصرة اعرض السياق الإنساني وتجنب التعميم أو تمجيد العنف.
لا تقدم إرشادات عن العنف أو الأسلحة أو استهداف الأشخاص أو تجاوز القانون.
لا تطلب من المستخدم معلومات شخصية أو عنواناً أو رقم هاتف. لا تدّع أنك تتصفح الإنترنت أو تتحقق من الأخبار مباشرة.
قدّم إجابات منظمة ومفيدة للطلاب، واذكر أن التفاصيل التاريخية تحتاج إلى مصادر قابلة للتحقق.
`;
    const response = await ai.models.generateContent({
      model: MODEL,
      contents: [...safeHistory, { role:"user", parts:[{ text:message }] }],
      config: {
        systemInstruction,
        temperature: 0.45,
        maxOutputTokens: 1200
      }
    });
    res.json({ answer: response.text || "لم أتمكن من صياغة إجابة الآن. حاول مرة أخرى." });
  } catch (err) {
    console.error("Gemini error:", err?.message || err);
    res.status(502).json({ error:"تعذر الاتصال بالمساعد حالياً. تحقق من إعدادات Gemini ثم حاول مجدداً." });
  }
});

app.get("/api/projects", async (_req, res) => {
  if (!supabase) return res.json({ projects:[], databaseConfigured:false });
  const { data, error } = await supabase.from("projects")
    .select("id,title,category,description,created_at,votes")
    .eq("status","approved").order("created_at",{ascending:false}).limit(100);
  if (error) return res.status(500).json({ error:"تعذر تحميل المبادرات." });
  res.json({ projects:data || [], databaseConfigured:true });
});

app.post("/api/projects", submitLimiter, async (req, res) => {
  const title = cleanText(req.body?.title, 90);
  const category = cleanText(req.body?.category, 40);
  const description = cleanText(req.body?.description, 1200);
  if (title.length < 3 || description.length < 20)
    return res.status(400).json({ error:"اكتب عنواناً من 3 أحرف على الأقل ووصفاً من 20 حرفاً." });
  if (!supabase) return res.status(503).json({ error:"قاعدة البيانات المشتركة غير مهيأة. أضف إعدادات Supabase أولاً." });
  const { error } = await dbInsert("projects", { title, category, description, status:"pending", votes:0 });
  if (error) {
    console.error(error.message);
    return res.status(500).json({ error:"لم نتمكن من حفظ المبادرة. تحقق من إعداد قاعدة البيانات." });
  }
  res.status(201).json({ message:"وصلت مبادرتك إلى الإدارة للمراجعة قبل نشرها." });
});

app.post("/api/projects/:id/vote", submitLimiter, async (req, res) => {
  if (!supabase) return res.status(503).json({ error:"قاعدة البيانات غير مهيأة." });
  const id = cleanText(req.params.id, 80);
  const { data, error } = await supabase.rpc("vote_for_project", { project_id: id });
  if (error) return res.status(400).json({ error:"تعذر تسجيل التصويت. قد تكون المبادرة غير متاحة." });
  res.json({ votes:data });
});

app.get("/api/leaderboard", async (_req, res) => {
  if (!supabase) return res.json({ scores:[], databaseConfigured:false });
  const { data, error } = await supabase.from("quiz_scores")
    .select("nickname,score,created_at").order("score",{ascending:false}).order("created_at",{ascending:true}).limit(20);
  if (error) return res.status(500).json({ error:"تعذر تحميل لوحة الترتيب." });
  res.json({ scores:data || [], databaseConfigured:true });
});

app.post("/api/leaderboard", submitLimiter, async (req, res) => {
  const nickname = cleanText(req.body?.nickname, 20).replace(/[<>]/g,"");
  const score = Number(req.body?.score);
  if (nickname.length < 2 || !Number.isInteger(score) || score < 0 || score > 100)
    return res.status(400).json({ error:"تحقق من الاسم المستعار والنتيجة." });
  if (!supabase) return res.status(503).json({ error:"لوحة الترتيب المشتركة غير مهيأة." });
  const { error } = await dbInsert("quiz_scores", { nickname, score });
  if (error) return res.status(500).json({ error:"تعذر حفظ النتيجة." });
  res.status(201).json({ message:"تم حفظ نتيجتك." });
});

app.post("/api/admin/projects/:id", async (req, res) => {
  if (!adminAllowed(req)) return res.status(401).json({ error:"غير مصرح." });
  if (!supabase) return res.status(503).json({ error:"قاعدة البيانات غير مهيأة." });
  const status = req.body?.status === "approved" ? "approved" : "rejected";
  const { error } = await supabase.from("projects").update({ status }).eq("id", req.params.id);
  if (error) return res.status(500).json({ error:"تعذر تحديث المبادرة." });
  res.json({ message:"تم تحديث حالة المبادرة." });
});

app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error:"حدث خطأ غير متوقع." });
});

app.listen(PORT, () => console.log(`Syria Memory platform listening on ${PORT}`));
