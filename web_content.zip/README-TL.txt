BIBLE QUIZ — SALITA NG DIOS
Updated Android-ready PWA package

WHAT'S INCLUDED
- index.html: game interface and gameplay
- sw.js: offline cache (version 2)
- manifest.webmanifest: app name and install settings
- icons/: app icons

UPDATED IN THIS BUILD
- Main menu now shows five game categories first.
- Selecting a category opens CHOOSE THE LEVEL.
- Easy / Medium / Hard are set to 25 / 50 / 100 rounds.
- Added an essay-clue mode that asks players to identify the Bible reference.
- Perfect-score celebration and spoken “PERFECT SCORE! CONGRATS!” are included in the multiple-choice and verse modes where supported.

IMPORTANT LIMITATIONS
- This ZIP is an installable Progressive Web App (PWA), not a signed native Android APK.
- To install as a PWA, the files must be hosted on an HTTPS site and opened in Chrome on Android. After the first successful load, offline use is supported.
- Some game question banks are still small. To reach 25 / 50 / 100 rounds in every category, some current rounds repeat. The banks need a larger, carefully checked set of distinct Bible questions before calling this a complete question bank.
- The essay clue mode currently has a small set of specific paraphrased clues; other verses use a general fallback clue. It needs more verse-specific essay clues.
- Speech announcement depends on the Android browser/device supporting speech synthesis.

ANDROID INSTALL (PWA)
1. Host the contents of this ZIP on an HTTPS static host.
2. Open the hosted link in Chrome on Android.
3. Open Chrome menu (⋮) and choose Install app / Add to Home screen if offered.
4. Launch from the new app icon. Keep the files hosted for future updates.

NATIVE APK
A signed APK has not been built in this package. A native Android build requires an Android build environment and signing step.
