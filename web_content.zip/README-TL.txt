TAIWAN MANDARIN DICTIONARY - Android project
Version 2.0

Bundled offline data:
- 275 dictionary entries (English, Taiwan Traditional Chinese, Pinyin, Zhuyin, Tagalog)
- 25 useful conversational phrases
- Search across English, Chinese, Pinyin, Zhuyin and Tagalog
- Category filters, favorites, Taiwan Mandarin text-to-speech, quiz mode
- Works offline after installation; audio voice availability depends on Android TTS language pack

Build APK on Android:
1. Extract this ZIP to your Android phone.
2. Open the project folder in AndroidIDE (or Android Studio on a computer).
3. Connect to internet for the first Gradle sync.
4. Build > Assemble Debug.
5. APK output: app/build/outputs/apk/debug/app-debug.apk
6. Install the APK. Allow installs from your file manager/AndroidIDE if Android asks.

Pronunciation: app uses the Android zh-TW text-to-speech voice. If missing, install a Traditional Chinese (Taiwan) voice in Android text-to-speech settings.

Note: This is an expanded practical learner's dictionary, not an exhaustive dictionary of every English word. Some technical terms can vary by Taiwan shop/brand; verify specialist terminology for safety-critical repair instructions.
