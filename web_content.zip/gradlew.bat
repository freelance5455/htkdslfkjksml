@echo off
setlocal
set VERSION=8.13
set DIST=gradle-%VERSION%-bin.zip
set BASE=%USERPROFILE%\.gradle\wrapper\dists\gradle-%VERSION%-bin\mrk-bootstrap
set BIN=%BASE%\gradle-%VERSION%\bin\gradle.bat
if not exist "%BIN%" (
  if not exist "%BASE%" mkdir "%BASE%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $u='https://services.gradle.org/distributions/%DIST%'; $z='%BASE%\%DIST%'; $h='%BASE%\%DIST%.sha256'; Invoke-WebRequest $u -OutFile $z; Invoke-WebRequest ($u+'.sha256') -OutFile $h; $expected=(Get-Content $h -Raw).Trim().Split(' ')[0]; $actual=(Get-FileHash $z -Algorithm SHA256).Hash.ToLower(); if($actual -ne $expected){throw 'Gradle SHA-256 check failed'}; Expand-Archive -LiteralPath $z -DestinationPath '%BASE%' -Force; Remove-Item $z,$h -Force"
  if errorlevel 1 exit /b 1
)
call "%BIN%" %*
