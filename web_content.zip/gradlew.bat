@rem Gradle start up script for Windows
@echo off
set DIR=%~dp0
set GRADLE_JAR=%DIR%gradle\wrapper\gradle-wrapper.jar
if not exist "%GRADLE_JAR%" (
    echo Downloading Gradle wrapper...
    powershell -Command "Invoke-WebRequest -Uri https://raw.githubusercontent.com/gradle/gradle/master/gradle/wrapper/gradle-wrapper.jar -OutFile '%GRADLE_JAR%'" 2>nul
)
gradle assembleDebug %*
