@echo off
setlocal
set "GRADLE_VERSION=8.7"
set "GRADLE_HOME=%USERPROFILE%\.gradle\wrapper\dists\gradle-%GRADLE_VERSION%"
set "DIST_URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip"
if not exist "%GRADLE_HOME%\gradle-%GRADLE_VERSION%\bin\gradle.bat" (
  if not exist "%GRADLE_HOME%" mkdir "%GRADLE_HOME%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri '%DIST_URL%' -OutFile '%GRADLE_HOME%\gradle-%GRADLE_VERSION%-bin.zip'"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%GRADLE_HOME%\gradle-%GRADLE_VERSION%-bin.zip' '%GRADLE_HOME%'"
)
call "%GRADLE_HOME%\gradle-%GRADLE_VERSION%\bin\gradle.bat" %*
