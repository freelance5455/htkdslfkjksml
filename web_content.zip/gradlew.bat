@rem Gradle Wrapper startup script for Windows (Mizo_q TikTok Toolkit V6.0)
@echo off
set DIRNAME=%~dp0
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    gradle --project-dir "%DIRNAME%" %*
    exit /b %ERRORLEVEL%
) else (
    echo Gradle CLI not found in PATH. Open this project in Android Studio or install Gradle 8.9.
    exit /b 1
)
