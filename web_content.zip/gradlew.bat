@echo off
setlocal
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
set "GV=8.9"
set "CACHE=%USERPROFILE%\.gradle\chakravuyh-gradle\%GV%"
set "DIST=%CACHE%\gradle-%GV%"
if exist "%DIST%\bin\gradle.bat" goto run
if not exist "%CACHE%" mkdir "%CACHE%"
set "ZIP=%CACHE%\gradle-%GV%-bin.zip"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing -Uri 'https://services.gradle.org/distributions/gradle-%GV%-bin.zip' -OutFile '%ZIP%'"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP%' '%CACHE%'"
:run
call "%DIST%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
