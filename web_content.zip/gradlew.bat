@rem
@if "%DEBUG%"=="" @echo off
set DEFAULT_JVM_OPTS="-Xmx64m" "-Xms64m"
java -jar "%~dp0gradle\wrapper\gradle-wrapper.jar" %*
