@rem Gradle Wrapper for Windows
gradle %*
