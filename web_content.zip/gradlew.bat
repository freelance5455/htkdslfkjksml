@echo off
echo Please open this project in Android Studio and let Gradle sync/build it.
