@rem Execute Gradle command
@gradle %*
