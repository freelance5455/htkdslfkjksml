package com.bikoo2018.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
  private WebView webView;
  private boolean fullscreen = false;
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    webView = new WebView(this);
    webView.setBackgroundColor(0xFFF3F6FB);
    WebSettings s = webView.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    s.setDatabaseEnabled(true); s.setDefaultTextEncodingName("UTF-8");
    s.setLoadWithOverviewMode(true); s.setUseWideViewPort(true);
    s.setSupportZoom(true); s.setBuiltInZoomControls(false);
    s.setAllowFileAccess(true); s.setAllowContentAccess(true);
    s.setLoadsImagesAutomatically(true); s.setJavaScriptCanOpenWindowsAutomatically(false);
    webView.setVerticalScrollBarEnabled(true); webView.setHorizontalScrollBarEnabled(false);
    webView.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
    webView.setWebChromeClient(new WebChromeClient());
    webView.setWebViewClient(new WebViewClient());
    webView.addJavascriptInterface(new NativeBridge(), "BikooNative");
    setContentView(webView);
    webView.loadUrl("file:///android_asset/index.html");
  }
  private class NativeBridge {
    @JavascriptInterface public void toggleFullscreen() { runOnUiThread(() -> {
      fullscreen = !fullscreen;
      View decor = getWindow().getDecorView();
      if (fullscreen) {
        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
      } else { decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE); }
    }); }
    @JavascriptInterface public void keepScreenOn(boolean on) { runOnUiThread(() -> { if(on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); }); }
  }
  @Override protected void onPause() { if (webView != null) webView.onPause(); super.onPause(); }
  @Override protected void onResume() { super.onResume(); if (webView != null) webView.onResume(); }
  @Override public void onBackPressed() {
    if (fullscreen) { fullscreen = false; getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE); }
    else if (webView != null && webView.canGoBack()) webView.goBack();
    else super.onBackPressed();
  }
}
