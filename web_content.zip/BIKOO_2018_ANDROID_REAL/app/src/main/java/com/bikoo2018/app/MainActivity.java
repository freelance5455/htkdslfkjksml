package com.bikoo2018.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JsResult;
import android.webkit.JsPromptResult;
import android.webkit.ConsoleMessage;
import android.widget.EditText;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
  private static final int FILE_CHOOSER_REQUEST = 1001;
  private static final int CREATE_FILE_REQUEST = 1002;
  private WebView webView;
  private boolean fullscreen = false;
  private ValueCallback<Uri[]> filePathCallback;
  private String pendingExportText = "";
  private String pendingExportMime = "text/plain";

  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    webView = new WebView(this);
    webView.setBackgroundColor(0xFFF3F6FB);
    WebSettings s = webView.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setDatabaseEnabled(true);
    s.setDefaultTextEncodingName("UTF-8");
    s.setLoadWithOverviewMode(true);
    s.setUseWideViewPort(true);
    s.setSupportZoom(true);
    s.setBuiltInZoomControls(false);
    s.setDisplayZoomControls(false);
    s.setAllowFileAccess(true);
    s.setAllowContentAccess(true);
    s.setLoadsImagesAutomatically(true);
    s.setJavaScriptCanOpenWindowsAutomatically(false);
    webView.setVerticalScrollBarEnabled(true);
    webView.setNestedScrollingEnabled(true);
    webView.setFocusable(true);
    webView.setFocusableInTouchMode(true);
    webView.setHorizontalScrollBarEnabled(false);
    webView.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
    webView.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
        if (filePathCallback != null) filePathCallback.onReceiveValue(null);
        filePathCallback = callback;
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        try { startActivityForResult(Intent.createChooser(intent, "Select backup file"), FILE_CHOOSER_REQUEST); }
        catch (Exception e) { filePathCallback = null; callback.onReceiveValue(null); return false; }
        return true;
      }
      @Override public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
        new AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton("OK", (d,w) -> result.confirm()).setOnCancelListener(d -> result.cancel()).show();
        return true;
      }
      @Override public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
        new AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton("Yes", (d,w) -> result.confirm()).setNegativeButton("No", (d,w) -> result.cancel()).setOnCancelListener(d -> result.cancel()).show();
        return true;
      }
      @Override public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
        EditText input = new EditText(MainActivity.this);
        input.setText(defaultValue == null ? "" : defaultValue);
        new AlertDialog.Builder(MainActivity.this).setTitle(message).setView(input)
          .setPositiveButton("OK", (d,w) -> result.confirm(input.getText().toString()))
          .setNegativeButton("Cancel", (d,w) -> result.cancel())
          .setOnCancelListener(d -> result.cancel()).show();
        return true;
      }
    });
    webView.setWebViewClient(new WebViewClient());
    webView.addJavascriptInterface(new NativeBridge(), "BikooNative");
    setContentView(webView);
    webView.loadUrl("file:///android_asset/index.html");
  }

  private class NativeBridge {
    @JavascriptInterface public void toggleFullscreen() { runOnUiThread(() -> {
      fullscreen = !fullscreen;
      View decor = getWindow().getDecorView();
      if (fullscreen) {
        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
      } else { decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE); }
    }); }
    @JavascriptInterface public void keepScreenOn(boolean on) { runOnUiThread(() -> {
      if(on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
      else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }); }
    @JavascriptInterface public void saveTextFile(String filename, String content, String mimeType) {
      runOnUiThread(() -> {
        pendingExportText = content == null ? "" : content;
        pendingExportMime = mimeType == null ? "text/plain" : mimeType;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(pendingExportMime);
        intent.putExtra(Intent.EXTRA_TITLE, filename == null ? "BIKOO_export.txt" : filename);
        try { startActivityForResult(intent, CREATE_FILE_REQUEST); }
        catch (Exception e) { Toast.makeText(MainActivity.this, "Could not open file saver", Toast.LENGTH_LONG).show(); }
      });
    }
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == FILE_CHOOSER_REQUEST) {
      if (filePathCallback != null) {
        Uri[] result = (resultCode == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
        filePathCallback.onReceiveValue(result);
        filePathCallback = null;
      }
    } else if (requestCode == CREATE_FILE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
      try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
        if (out != null) {
          out.write(pendingExportText.getBytes(StandardCharsets.UTF_8));
          Toast.makeText(this, "File saved", Toast.LENGTH_SHORT).show();
        }
      } catch (Exception e) { Toast.makeText(this, "File could not be saved", Toast.LENGTH_LONG).show(); }
      pendingExportText = "";
    }
  }

  @Override protected void onPause() { if (webView != null) webView.onPause(); super.onPause(); }
  @Override protected void onResume() { super.onResume(); if (webView != null) webView.onResume(); }
  @Override public void onBackPressed() {
    if (fullscreen) {
      fullscreen = false;
      getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    } else if (webView != null && webView.canGoBack()) webView.goBack();
    else super.onBackPressed();
  }
}
