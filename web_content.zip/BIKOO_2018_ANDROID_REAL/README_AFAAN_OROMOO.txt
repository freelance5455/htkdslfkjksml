BIKOO 2018 – ANDROID SOURCE PROJECT

Appii barreeffama gabaabaa fi dheeraa, lesson notes, yaadannoo fi dubbisaaf qophaa'e.

Amaloota:
- Android WebView app; maqaan BIKOO 2018.
- Barreeffama dheerina qabu; fuula ol-gadi harkisuu (vertical scrolling).
- Reading Mode fi Edit Mode adda addaa.
- Full screen native Android.
- Auto-save yeroo barreessitu, yeroo app gara duubaatti deemu fi yeroo fuula jijjiirtu.
- Background halluu 16, dark theme, font guddisuu/xiqqeessuu.
- Copy, paste, share, bold, italic, underline, bullets fi numbered lists.
- Search, categories, favorites, TXT export.
- JSON backup fi restore; Android irratti file picker fi file saver fayyadama.
- Screen awake toggle.

IJAARUU (APK):
1. ZIP extract godhi.
2. Android Studio banii Open filadhu; folder BIKOO_2018_ANDROID_REAL filadhu.
3. JDK 17, Android SDK Platform 35, Android Gradle Plugin 8.6.1 fi Gradle 8.7 fayyadami; Gradle Sync godhi.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) filadhu.
5. APK app/build/outputs/apk/debug/app-debug.apk keessatti argatta.

MURTEESSAA:
Kun Android Studio source project dha; APK compiled miti. APK ijaaruuf Android Studio/SDK fi Gradle dependencies barbaachisu. Barreeffamni local storage keessatti kuufama; bilbila/app data haqamuun dura JSON backup godhi. Barreeffama garmalee guddaa yeroo dheeraa keessatti kuufamuuf yeroo yerootti backup godhi.

QORANNOO VERSION KANAA:
- JavaScript syntax check: passed.
- HTML element references: checked; missing IDs hin argamne.
- AndroidManifest XML fi SVG: parse check passed.
- Java/Gradle APK build: naannoo kana keessatti Android SDK/Gradle hin jiraniif hin raawwatamne. Kanaaf APK compile fi device test xumurame jechuun hin danda'amu.
