Achaemenid ball - پروژه اندروید

این پروژه بازی HTML شما را داخل WebView اندروید اجرا می‌کند.
نام برنامه: Achaemenid ball
آیکون: تصویر ارسالی شما

ساخت APK:
1) Android Studio را نصب کنید.
2) از File > Open پوشه AchaemenidBall-Android را باز کنید.
3) صبر کنید Gradle Sync کامل شود و در صورت درخواست SDK Platform 35 را نصب کنید.
4) از منوی Build گزینه Build Bundle(s) / APK(s) و سپس Build APK(s) را بزنید.
5) فایل APK معمولاً در مسیر app/build/outputs/apk/debug/app-debug.apk ساخته می‌شود.

نکته:
بازی برای بارگذاری Three.js و فونت‌های گوگل به اینترنت نیاز دارد؛ بنابراین مجوز اینترنت در برنامه فعال است.
این محیط ابزارهای Android SDK و Gradle را ندارد، پس APK نهایی در اینجا کامپایل نشده است.
