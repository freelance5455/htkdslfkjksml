AA Rozana Khata V2 (Offline PWA)
=================================

V2 is built on the supplied V1 project. Existing V1 entries, categories, settings,
and templates remain supported. New inventory fields are added without removing
old ledger data.

New Inventory features:
- Separate Sale, Rental, and Sale + Rental item modes.
- Stock unit supports Piece and KG (e.g. lime/chuna and nails/keelain).
- Sale stock quantity is reduced when a sale is recorded; sale total is added to
  the existing income ledger.
- Rental stock availability accounts for active rentals; partial returns make
  only returned quantity available again.
- Friday rent checkbox: checked means Friday is charged; unchecked means Friday
  is excluded from billable rental days.
- Rental amount is calculated from quantity × agreed daily rate × billable days.
- Personal/regular V1 khata and reports remain available.

Important notes:
- This is an initial V2 implementation, not a certified production accounting
  system. Test with sample data and keep a backup before relying on it.
- The current rental module tracks quantities; the serial-number checkbox is a
  tracking preference field, not yet a full individual-unit serial registry.
- Deposits/paid amounts are recorded as received income only when entered as
  rental payment; the advanced deposit liability/settlement workflow is not yet
  implemented.
- Data is stored locally in this browser/app. PWA and APK installations normally
  have separate local data. Export a JSON backup regularly.
- To use: serve the folder over HTTPS (e.g. Netlify Drop), open the site, then
  install from the browser menu. Keep sw.js and manifest.json alongside index.html.
