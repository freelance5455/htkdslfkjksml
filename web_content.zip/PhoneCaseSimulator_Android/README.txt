Phone Case Simulator Android project

This project wraps the game's HTML in an Android WebView.
To build the APK, open this folder in Android Studio, allow Gradle sync, then choose Build > Build APK(s).
The APK will be under app/build/outputs/apk/debug/app-debug.apk.
Internet permission is enabled so online phone photos can load. Game files are bundled in app/src/main/assets/index.html.
