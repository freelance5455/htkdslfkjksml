const fs=require('fs');
global.window=global;
require('./data.js');
require('./extra-facts.js');
const stems=[
'کدام سرنخ، راه درست را در این بخش نشان می‌دهد؟','آراد در دفتر ماجراجویی‌اش چه نکته‌ای را باید ثبت کند؟','تیزهوش سه راه پیش روی تو گذاشته؛ کدام راه درست است؟','اگر بخواهی این راز را برای دوستت توضیح بدهی، کدام جمله را می‌گویی؟','کدام گزینه با آموخته‌های این درس هماهنگ است؟','برای باز شدن قفل این مرحله، کدام گزاره را انتخاب می‌کنی؟','کدام جمله می‌تواند قطعه گمشده نقشه را روشن کند؟','در دفتر دانایی، کدام نکته باید نوشته شود؟','کدام انتخاب به آراد کمک می‌کند از این چالش عبور کند؟','کدام گزینه مفهوم این بخش را درست بیان می‌کند؟','تیزهوش از تو می‌خواهد یک نشانه معتبر پیدا کنی؛ کدام است؟','کدام جمله را می‌توان با اطمینان به عنوان یک نکته درست پذیرفت؟','در این ایستگاه، کدام پاسخ کلید حل معماست؟','کدام گزاره با موضوع درس سازگاری دارد؟','اگر نقشه را با این دانسته کامل کنی، کدام گزینه را برمی‌گزینی؟','کدام نکته به شناخت بهتر این موضوع کمک می‌کند؟','کدام پاسخ، انتخاب درست یک کاوشگر داناست؟','برای روشن شدن نشان این مرحله، کدام جمله را انتخاب می‌کنی؟','کدام گزینه از دانسته‌های کتاب پشتیبانی می‌کند؟','آخرین سرنخ این بخش کدام است؟'];
const pages=LESSONS.map(l=>l[2]);
const questions=[];
LESSONS.forEach((l,li)=>{
 const facts=FACTS[li];
 if(facts.length!==20)throw new Error(`lesson ${li+1}: expected 20 concepts, got ${facts.length}`);
 facts.forEach((f,j)=>{
  let wrong=[],seen=new Set([f[0]]);for(const step of [3,8,14,...Array.from({length:20},(_,k)=>k)]){const candidate=facts[(j+step)%20][1];if(!seen.has(candidate)){seen.add(candidate);wrong.push(candidate)}if(wrong.length===3)break;}
  let opts=[f[0],...wrong];
  let seed=li*1009+j*71+13;
  for(let k=opts.length-1;k>0;k--){seed=(seed*9301+49297)%233280;let n=Math.floor(seed/233280*(k+1));[opts[k],opts[n]]=[opts[n],opts[k]]}
  questions.push({id:`L${li+1}-Q${j+1}`,lessonId:li+1,type:'چهارگزینه‌ای',difficulty:j<6?'ساده':j<14?'متوسط':'چالشی',sourcePages:pages[li],concept:l[3],questionText:stems[j]+` (${l[0]})`,options:opts,correctAnswer:f[0],correctIndex:opts.indexOf(f[0]),explanation:f[2],hints:[`به موضوع اصلی «${l[0]}» و واژه‌های کلیدی آن توجه کن.`,`این سرنخ را به خاطر بیاور: ${f[2]}`,`سه گزینه را با دانسته‌های کتاب مقایسه کن و ناسازگارها را کنار بگذار.`]});
 });
});
const counts=LESSONS.map((l,i)=>questions.filter(q=>q.lessonId===i+1).length);
const uniqueTexts=new Set(questions.map(q=>q.questionText));
const ids=new Set(questions.map(q=>q.id));
const report={source:'کتاب مطالعات اجتماعی چهارم دبستان، چاپ سیزدهم ۱۴۰۵؛ PDF ارائه‌شده در گفتگو',lessons:LESSONS.length,questions:questions.length,independentConceptStatements:FACTS.reduce((n,x)=>n+x.length,0),perLesson:counts,uniqueIds:ids.size,uniqueQuestionTexts:uniqueTexts.size,duplicateQuestionTexts:questions.length-uniqueTexts.size,allAnswersPresent:questions.every(q=>q.options[q.correctIndex]===q.correctAnswer),allHaveExplanations:questions.every(q=>q.explanation&&q.hints.length===3),types:{'چهارگزینه‌ای':questions.length},difficulty:{'ساده':questions.filter(q=>q.difficulty==='ساده').length,'متوسط':questions.filter(q=>q.difficulty==='متوسط').length,'چالشی':questions.filter(q=>q.difficulty==='چالشی').length},validation:'کنترل ساختاری خودکار موفق؛ بازبینی انسانی تخصصی تک‌تک سؤال‌ها هنوز لازم است.',limitations:['۴۴۰ گزاره آموزشی مستقل از متن کتاب تدوین شده‌اند؛ استقلال مفهومی و تنوع صورت سؤال به صورت ساختاری کنترل شده است، اما بازبینی انسانی تک‌تک گزینه‌ها هنوز انجام نشده است.','برخی گزینه‌های نادرست، گزاره‌های نادرست دیگر همان درس هستند؛ برای نسخه مدرسه‌ای نهایی، بازبینی معلم و اصلاح distractorهای ضعیف توصیه می‌شود.','شماره صفحه‌ها به صورت بازه درس ثبت شده‌اند، نه صفحه دقیق هر گزاره.','تیزهوش موتور راهنمایی قواعدمحور آفلاین است، نه مدل هوش مصنوعی مولد.','تصاویر شخصیت‌ها از یک تصویر مفهومی سه‌بعدی بریده شده و با CSS متحرک شده‌اند؛ مدل سه‌بعدی تعاملی یا ریگ انیمیشن واقعی نیستند.','آزمون واقعی روی همه گوشی‌ها و ابزارهای تبدیل APK انجام نشده است.']};
if(questions.length!==440||counts.some(n=>n!==20)||ids.size!==440||uniqueTexts.size!==440||!report.allAnswersPresent||!report.allHaveExplanations)throw new Error(JSON.stringify(report));
fs.writeFileSync('../data/questions.json',JSON.stringify(questions,null,2),'utf8');
fs.writeFileSync('../data/lessons.json',JSON.stringify(LESSONS.map((l,i)=>({id:i+1,title:l[0],realm:l[1],pages:l[2],concepts:l[3],independentConcepts:FACTS[i].length})),null,2),'utf8');
fs.writeFileSync('../گزارش-اعتبارسنجی.json',JSON.stringify(report,null,2),'utf8');
console.log(JSON.stringify(report,null,2));
