# تبلیغ پاداشی واقعی AdMob (LEVEL HARD GAME)

کد بازی آماده است (`AdBridge` در game.js). تبلیغ واقعی فقط داخل اپ اندروید اجرا می‌شود، داخل مرورگر نه.

## مراحل
1. در https://admob.google.com یک App و یک Ad unit از نوع **Rewarded** بساز.
2. در `game.js` بالای بخش AdMob (`const ADMOB=`) این دو مقدار را با IDهای خودت عوض کن:
   - `appId`  (شبیه ca-app-pub-XXXX~YYYY)
   - `rewardedId` (شبیه ca-app-pub-XXXX/ZZZZ)
   الان IDهای تستی خود گوگل گذاشته شده؛ تبلیغ تستی نشان می‌دهد و امن است.
3. در پوشه‌ی پروژه:
   ```
   npm install
   npm run android:add
   ```
4. فایل `android/app/src/main/AndroidManifest.xml` را باز کن و داخل تگ `<application>` اضافه کن (App ID خودت):
   ```
   <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="ca-app-pub-XXXX~YYYY"/>
   ```
   و بالای `<application>`: `<uses-permission android:name="android.permission.INTERNET"/>` (اگر نبود).
5. `npm run android:sync` و بعد `npm run android:open` تا در Android Studio ساخته و روی گوشی اجرا شود.
6. قبل از انتشار: ID واقعی بگذار. با ID واقعی خودت هیچ‌وقت روی تبلیغ‌های خودت کلیک نکن (حساب AdMob بسته می‌شود).

## قوانین بازی (همه واقعی)
- اسکین قفل‌شده زیرش نقطه‌های پیشرفت، `n / 5` و «x تبلیغ مانده» را نشان می‌دهد.
- شمارنده فقط وقتی یکی زیاد می‌شود که گوگل رویداد «پاداش داده شد» را بفرستد. اگر تبلیغ را وسط ببندی یا لود نشود، چیزی حساب نمی‌شود.
- بعد از ۵ تبلیغ تأییدشده، اسکین خودکار باز و انتخاب می‌شود.
- ستاره‌ها، شمارنده‌ی تبلیغ و اسکین‌های خریده‌شده در ذخیره‌ی بازی (`save.skins`) می‌مانند.
- در بعضی کشورها (اروپا و ...) برای انتشار باید پنجره‌ی رضایت کاربر (UMP / Consent) هم فعال شود.
