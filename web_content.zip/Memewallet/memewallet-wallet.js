import {
    initializeApp
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-app.js";

import {
    getAuth,
    onAuthStateChanged,
    signOut,
    GoogleAuthProvider,
    signInWithPopup,
    signInWithRedirect,
    getRedirectResult,
    setPersistence,
    browserLocalPersistence
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js";

import {
    getFirestore,
    collection,
    getDoc,
    doc,
    addDoc,
    onSnapshot,
    query,
    orderBy,
    serverTimestamp,
    Timestamp,
    runTransaction
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-firestore.js";


/* =========================================
   FIREBASE CONFIG
========================================== */

const firebaseConfig = {

    apiKey:
        "AIzaSyA4Cva8qKlNEB_3EmGrfKLak2BMSyuFMr8",

    authDomain:
        "memewallet.firebaseapp.com",

    projectId:
        "memewallet",

    storageBucket:
        "memewallet.firebasestorage.app",

    messagingSenderId:
        "84684019273",

    appId:
        "1:84684019273:web:ba9ddc3894da012f8dd198",

    measurementId:
        "G-9624VWJQ4H"

};


const app =
    initializeApp(
        firebaseConfig
    );

const auth =
    getAuth(
        app
    );

const db =
    getFirestore(
        app
    );


/* =========================================
   ELEMENTS
========================================== */

const pages =
    document.querySelectorAll(
        '.page'
    );

const mobileNavItems =
    document.querySelectorAll(
        '.mobile-nav-item'
    );

const drawerBackdrop =
    document.getElementById(
        'drawerBackdrop'
    );

const depositDrawer =
    document.getElementById(
        'depositDrawer'
    );

const withdrawDrawer =
    document.getElementById(
        'withdrawDrawer'
    );

const toast =
    document.getElementById(
        'toast'
    );

const bankTransferCard =
    document.getElementById(
        'bankTransferCard'
    );

const depositAmountCard =
    document.getElementById(
        'depositAmountCard'
    );

const depositAccountCard =
    document.getElementById(
        'depositAccountCard'
    );

const bankDepositOption =
    document.getElementById(
        'bankDepositOption'
    );

const depositAmountInput =
    document.getElementById(
        'depositAmount'
    );

const depositAmountOptions =
    document.querySelectorAll(
        '.deposit-amount-option'
    );

const depositNextButton =
    document.getElementById(
        'depositNextButton'
    );

const selectedDepositAmount =
    document.getElementById(
        'selectedDepositAmount'
    );

const depositFee =
    document.getElementById(
        'depositFee'
    );

const depositTimer =
    document.getElementById(
        'depositTimer'
    );

const depositTimerLabel =
    document.getElementById(
        'depositTimerLabel'
    );

const transferredFundsButton =
    document.getElementById(
        'transferredFundsButton'
    );

const transactionList =
    document.getElementById(
        'transactionList'
    );

const transactionsEmpty =
    document.getElementById(
        'transactionsEmpty'
    );

const transactionLoading =
    document.getElementById(
        'transactionLoading'
    );

const walletBalance =
    document.getElementById(
        'walletBalance'
    );

const headerCashBalance =
    document.getElementById(
        'headerCashBalance'
    );

const profileWalletBalance =
    document.getElementById(
        'profileWalletBalance'
    );

const headerUserEmail =
    document.getElementById(
        'headerUserEmail'
    );

const headerAvatar =
    document.getElementById(
        'headerAvatar'
    );

const profileAvatar =
    document.getElementById(
        'profileAvatar'
    );

const profileDisplayName =
    document.getElementById(
        'profileDisplayName'
    );

const profileDisplayEmail =
    document.getElementById(
        'profileDisplayEmail'
    );

const profileUserId =
    document.getElementById(
        'profileUserId'
    );

const profileAccountEmail =
    document.getElementById(
        'profileAccountEmail'
    );

const profileAccountName =
    document.getElementById(
        'profileAccountName'
    );

const notificationButton =
    document.getElementById(
        'notificationButton'
    );

const notificationPanel =
    document.getElementById(
        'notificationPanel'
    );

const closeNotificationPanel =
    document.getElementById(
        'closeNotificationPanel'
    );

const notificationList =
    document.getElementById(
        'notificationList'
    );

const notificationsEmpty =
    document.getElementById(
        'notificationsEmpty'
    );

const notificationBadge =
    document.getElementById(
        'notificationBadge'
    );


/* =========================================
   CONSTANTS
========================================== */

const DEPOSIT_EXPIRY_HOURS =
    8;

const DEPOSIT_EXPIRY_SECONDS =
    DEPOSIT_EXPIRY_HOURS * 60 * 60;


/* =========================================
   STATE
========================================== */

let currentPage =
    'wallet';

let toastTimer =
    null;

let depositTimerInterval =
    null;

let depositSecondsRemaining =
    0;

let currentUser =
    null;

let unsubscribeTransactions =
    null;

let unsubscribeUserWallet =
    null;

let selectedDepositNumericAmount =
    0;

let selectedDepositId =
    null;

let pendingTransactions =
    [];

let allTransactions =
    [];

let transactionActivityKey =
    '';

let notifications =
    [];


/* =========================================
   HELPERS
========================================== */

function formatNaira(
    amount
) {

    const numericAmount =
        Number(
            amount
        );


    if (
        !Number.isFinite(
            numericAmount
        )
    ) {

        return '₦0.00';

    }


    return `₦${numericAmount.toLocaleString(
        'en-NG',
        {
            minimumFractionDigits:
                2,

            maximumFractionDigits:
                2
        }
    )}`;

}


function formatDate(
    timestamp
) {

    if (!timestamp) {

        return 'Just now';

    }


    try {

        const date =
            typeof timestamp.toDate ===
            'function'

                ? timestamp.toDate()

                : new Date(
                    timestamp
                );


        return date.toLocaleString(
            'en-NG',
            {
                day:
                    'numeric',

                month:
                    'short',

                year:
                    'numeric',

                hour:
                    'numeric',

                minute:
                    '2-digit'
            }
        );

    } catch {

        return 'Just now';

    }

}


function escapeHtml(
    value
) {

    return String(
        value ?? ''
    )
        .replaceAll(
            '&',
            '&amp;'
        )
        .replaceAll(
            '<',
            '&lt;'
        )
        .replaceAll(
            '>',
            '&gt;'
        )
        .replaceAll(
            '"',
            '&quot;'
        )
        .replaceAll(
            "'",
            '&#039;'
        );

}


function getTimestampMillis(
    timestamp
) {

    if (!timestamp) {

        return null;

    }


    try {

        if (
            typeof timestamp.toMillis ===
            'function'
        ) {

            return timestamp.toMillis();

        }


        if (
            typeof timestamp.toDate ===
            'function'
        ) {

            return timestamp
                .toDate()
                .getTime();

        }


        if (
            timestamp instanceof Date
        ) {

            return timestamp.getTime();

        }


        const value =
            new Date(
                timestamp
            ).getTime();


        return Number.isFinite(
            value
        )

            ? value

            : null;

    } catch {

        return null;

    }

}


function getDepositExpiryMillis(
    transaction
) {

    const explicitExpiry =
        getTimestampMillis(
            transaction.expiresAt
        );


    if (explicitExpiry) {

        return explicitExpiry;

    }


    const createdAtMillis =
        getTimestampMillis(
            transaction.createdAt
        );


    if (createdAtMillis) {

        return (
            createdAtMillis +
            DEPOSIT_EXPIRY_SECONDS *
            1000
        );

    }


    return null;

}


function getRemainingSeconds(
    transaction
) {

    const expiryMillis =
        getDepositExpiryMillis(
            transaction
        );


    if (!expiryMillis) {

        return DEPOSIT_EXPIRY_SECONDS;

    }


    return Math.max(
        0,
        Math.ceil(
            (
                expiryMillis -
                Date.now()
            ) / 1000
        )
    );

}


function isPendingDepositExpired(
    transaction
) {

    const status =
        String(
            transaction.status ||
            'pending'
        ).toLowerCase();


    if (
        status !== 'pending'
    ) {

        return false;

    }


    return (
        getRemainingSeconds(
            transaction
        ) <= 0
    );

}


function formatDuration(
    totalSeconds
) {

    const seconds =
        Math.max(
            0,
            Math.floor(
                Number(
                    totalSeconds
                ) || 0
            )
        );


    const hours =
        Math.floor(
            seconds / 3600
        );


    const minutes =
        Math.floor(
            (
                seconds % 3600
            ) / 60
        );


    const remainingSeconds =
        seconds % 60;


    return (
        `${String(hours).padStart(
            2,
            '0'
        )}:` +

        `${String(minutes).padStart(
            2,
            '0'
        )}:` +

        `${String(
            remainingSeconds
        ).padStart(
            2,
            '0'
        )}`
    );

}


/* =========================================
   WALLET BALANCE
========================================== */

function updateDisplayedWalletBalance(
    userData
) {

    if (!userData) {

        walletBalance.textContent =
            '₦0.00';

        headerCashBalance.textContent =
            '₦0.00';

        profileWalletBalance.textContent =
            '₦0.00';

        return;

    }


    let balance = 0;


    if (
        typeof userData.cashBalance ===
        'number'
    ) {

        balance =
            userData.cashBalance;

    } else if (
        typeof userData.walletBalance ===
        'number'
    ) {

        balance =
            userData.walletBalance;

    } else if (
        typeof userData.balance ===
        'number'
    ) {

        balance =
            userData.balance;

    } else if (
        typeof userData.availableBalance ===
        'number'
    ) {

        balance =
            userData.availableBalance;

    }


    const formattedBalance =
        formatNaira(
            balance
        );


    walletBalance.textContent =
        formattedBalance;

    headerCashBalance.textContent =
        formattedBalance;

    profileWalletBalance.textContent =
        formattedBalance;

    /*
     * Additive local cache: keep the last known spendable wallet amount
     * so the balance can be painted immediately on the next app open.
     * Firestore remains the only source of truth for actual transactions.
     * This helper is declared later in the file and function declarations
     * are hoisted, so every Firestore wallet snapshot can refresh the cache.
     */
    try {
        if (
            typeof memewalletFastCacheWalletBalance ===
            'function' &&
            currentUser?.uid
        ) {
            memewalletFastCacheWalletBalance(
                balance,
                currentUser
            );
        }
    } catch (cacheError) {
        console.warn(
            'MEMEWALLET WALLET BALANCE CACHE UPDATE FAILED',
            cacheError
        );
    }

}


function listenForUserWallet(
    user
) {

    if (
        unsubscribeUserWallet
    ) {

        unsubscribeUserWallet();

        unsubscribeUserWallet =
            null;

    }


    if (!user) {

        updateDisplayedWalletBalance(
            null
        );

        return;

    }


    const userRef =
        doc(
            db,
            'users',
            user.uid
        );


    unsubscribeUserWallet =
        onSnapshot(
            userRef,

            snapshot => {

                if (
                    !snapshot.exists()
                ) {

                    updateDisplayedWalletBalance(
                        null
                    );

                    return;

                }


                const userData =
                    snapshot.data();


                updateDisplayedWalletBalance(
                    userData
                );


                console.log(
                    'Wallet balance updated:',
                    userData.cashBalance ??
                    userData.walletBalance ??
                    userData.balance ??
                    userData.availableBalance ??
                    0
                );

            },

            error => {

                console.error(
                    'Wallet balance listener error:',
                    error
                );


                updateDisplayedWalletBalance(
                    null
                );

            }
        );

}


/* =========================================
   NOTIFICATIONS
========================================== */

function getNotificationStorageKey() {

    if (!currentUser) {

        return 'memewallet_notifications_guest';

    }


    return (
        `memewallet_notifications_${currentUser.uid}`
    );

}


function loadNotifications() {

    try {

        const saved =
            localStorage.getItem(
                getNotificationStorageKey()
            );


        if (!saved) {

            notifications =
                [];

            renderNotifications();

            return;

        }


        const parsed =
            JSON.parse(
                saved
            );


        notifications =
            Array.isArray(
                parsed
            )

                ? parsed

                : [];

    } catch (error) {

        console.error(
            'Load notifications error:',
            error
        );

        notifications =
            [];

    }


    renderNotifications();

}


function saveNotifications() {

    try {

        localStorage.setItem(
            getNotificationStorageKey(),
            JSON.stringify(
                notifications
            )
        );

    } catch (error) {

        console.error(
            'Save notifications error:',
            error
        );

    }

}


function addExpiredTransactionNotification(
    transaction
) {

    if (
        !currentUser ||
        !transaction
    ) {

        return false;

    }


    const transactionId =
        transaction.id;


    if (!transactionId) {

        return false;

    }


    const exists =
        notifications.some(
            notification =>

                notification.type ===
                    'deposit_expired'

                &&

                notification.transactionId ===
                    transactionId
        );


    if (exists) {

        return false;

    }


    const notification = {

        id:
            `expired_${transactionId}`,

        transactionId:
            transactionId,

        type:
            'deposit_expired',

        title:
            'Deposit expired',

        message:
            `Your ${formatNaira(
                Number(
                    transaction.amount ||
                    0
                )
            )} deposit request expired after 8 hours.`,

        amount:
            Number(
                transaction.amount ||
                0
            ),

        createdAt:
            Date.now(),

        transactionCreatedAt:
            getTimestampMillis(
                transaction.createdAt
            ) ||
            Date.now(),

        read:
            false

    };


    notifications.unshift(
        notification
    );


    saveNotifications();

    renderNotifications();


    return true;

}


function processExpiredTransactions(
    transactions
) {

    if (
        !currentUser ||
        !Array.isArray(
            transactions
        )
    ) {

        return;

    }


    let changed =
        false;


    transactions.forEach(
        transaction => {

            if (
                isPendingDepositExpired(
                    transaction
                )
            ) {

                const created =
                    addExpiredTransactionNotification(
                        transaction
                    );


                if (created) {

                    changed =
                        true;

                }

            }

        }
    );


    if (changed) {

        renderNotifications();

    }

}


function memewalletNotificationIconMarkup(notification) {

    const type =
        String(
            notification?.type ||
            ''
        ).toLowerCase().trim();

    const title =
        String(
            notification?.title ||
            ''
        ).toLowerCase().trim();

    let background = 'bg-[#f4f4f2]';
    let foreground = 'text-[#737373]';
    let svg = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <circle cx="12" cy="12" r="8" stroke="currentColor" stroke-width="1.7"></circle>
            <path d="M12 8V12L15 14" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"></path>
        </svg>
    `;

    if (
        type === 'deposit' ||
        type === 'deposit_pending' ||
        title.includes('deposit pending') ||
        title.includes('deposit received') ||
        title.includes('deposit approved') ||
        title.includes('deposit successful')
    ) {
        background = 'bg-[#eefaf2]';
        foreground = 'text-[#21854a]';

        svg = `
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M12 4V17" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"></path>
                <path d="M6.5 11.5L12 17L17.5 11.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></path>
                <path d="M5 20H19" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"></path>
            </svg>
        `;
    }

    if (
        type === 'deposit_expired' ||
        title.includes('deposit expired')
    ) {
        background = 'bg-[#fff0f0]';
        foreground = 'text-[#c44848]';

        svg = `
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M12 3L21 19H3L12 3Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"></path>
                <path d="M12 9V13" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"></path>
                <circle cx="12" cy="16.5" r="0.8" fill="currentColor"></circle>
            </svg>
        `;
    }

    if (
        type === 'withdrawal' ||
        type === 'withdraw' ||
        title.includes('withdrawal') ||
        title.includes('withdraw')
    ) {
        background = 'bg-[#f2f5ff]';
        foreground = 'text-[#4f67b8]';

        svg = `
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M12 20V7" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"></path>
                <path d="M6.5 13L12 7L17.5 13" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></path>
                <path d="M5 20H19" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"></path>
            </svg>
        `;
    }

    if (type === 'prediction_buy') {
        background = 'bg-[#fff7e6]';
        foreground = 'text-[#a66a00]';

        svg = `
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M5 18L9.5 13.5L12.5 16.5L19 10" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></path>
                <path d="M15 10H19V14" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></path>
                <circle cx="6" cy="18" r="1" fill="currentColor"></circle>
            </svg>
        `;
    }

    if (type === 'prediction_win') {
        background = 'bg-[#eefaf2]';
        foreground = 'text-[#21854a]';

        svg = `
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <circle cx="12" cy="12" r="8.5" stroke="currentColor" stroke-width="1.7"></circle>
                <path d="M8 12.5L10.6 15L16 9.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></path>
            </svg>
        `;
    }

    if (type === 'prediction_loss') {
        background = 'bg-[#fff0f0]';
        foreground = 'text-[#c44848]';

        svg = `
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <circle cx="12" cy="12" r="8.5" stroke="currentColor" stroke-width="1.7"></circle>
                <path d="M9 9L15 15" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"></path>
                <path d="M15 9L9 15" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"></path>
            </svg>
        `;
    }

    if (type === 'prediction_refund') {
        background = 'bg-[#f2f5ff]';
        foreground = 'text-[#4f67b8]';

        svg = `
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M7 8H17L14 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></path>
                <path d="M17 16H7L10 19" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></path>
                <path d="M17 8C18.3 9.2 19 10.5 19 12C19 13.5 18.3 14.8 17 16" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"></path>
            </svg>
        `;
    }

    if (
        type === 'prediction_activity' ||
        title === 'prediction activity' ||
        title.includes('prediction')
    ) {
        if (
            type !== 'prediction_buy' &&
            type !== 'prediction_win' &&
            type !== 'prediction_loss' &&
            type !== 'prediction_refund'
        ) {
            background = 'bg-[#f4f4f2]';
            foreground = 'text-[#171717]';

            svg = `
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <path d="M5 19V10" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"></path>
                    <path d="M12 19V5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"></path>
                    <path d="M19 19V8" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"></path>
                </svg>
            `;
        }
    }

    return `
        <div
            class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${background} ${foreground}"
        >
            ${svg}
        </div>
    `;
}


function renderNotifications() {

    if (
        !notificationList ||
        !notificationsEmpty
    ) {

        return;

    }


    const sortedNotifications =
        [
            ...notifications
        ].sort(
            (a, b) =>

                Number(
                    b.createdAt ||
                    0
                )

                -

                Number(
                    a.createdAt ||
                    0
                )
        );


    if (
        sortedNotifications.length ===
        0
    ) {

        notificationList.innerHTML =
            '';

        notificationList.classList.add(
            'hidden'
        );

        notificationsEmpty.classList.remove(
            'hidden'
        );

        updateNotificationBadge();

        return;

    }


    notificationsEmpty.classList.add(
        'hidden'
    );

    notificationList.classList.remove(
        'hidden'
    );


    notificationList.innerHTML =
        sortedNotifications
            .map(
                notification => {

                    return `

                        <div
                            class="flex items-start gap-3 px-5 py-4 ${
                                notification.read
                                    ? 'bg-white'
                                    : 'bg-[#fafaf8]'
                            }"
                        >

                            ${memewalletNotificationIconMarkup(notification)}


                            <div class="min-w-0 flex-1">

                                <div class="flex items-start justify-between gap-3">

                                    <p class="text-[12px] font-semibold">

                                        ${escapeHtml(
                                            notification.title
                                        )}

                                    </p>


                                    ${
                                        !notification.read
                                            ? `

                                                <span
                                                    class="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-black"
                                                ></span>

                                            `
                                            : ''
                                    }

                                </div>


                                <p class="mt-1 text-[11px] leading-5 text-[#737373]">

                                    ${escapeHtml(
                                        notification.message
                                    )}

                                </p>


                                <p class="mt-2 text-[9px] font-medium text-[#999]">

                                    ${escapeHtml(
                                        formatDate(
                                            notification.createdAt
                                        )
                                    )}

                                </p>

                            </div>

                        </div>

                    `;

                }
            )
            .join(
                ''
            );


    updateNotificationBadge();

}


function updateNotificationBadge() {

    if (!notificationBadge) {

        return;

    }


    const unreadCount =
        notifications.filter(
            notification =>
                !notification.read
        ).length;


    if (
        unreadCount <= 0
    ) {

        notificationBadge.classList.add(
            'hidden'
        );

        notificationBadge.classList.remove(
            'flex'
        );

        notificationBadge.textContent =
            '0';

        return;

    }


    notificationBadge.textContent =
        unreadCount > 9

            ? '9+'

            : String(
                unreadCount
            );


    notificationBadge.classList.remove(
        'hidden'
    );

    notificationBadge.classList.add(
        'flex'
    );

}


function openNotificationPanel() {

    notificationPanel.classList.remove(
        'hidden'
    );


    let changed =
        false;


    notifications =
        notifications.map(
            notification => {

                if (
                    !notification.read
                ) {

                    changed =
                        true;


                    return {
                        ...notification,
                        read: true
                    };

                }


                return notification;

            }
        );


    if (changed) {

        saveNotifications();

    }


    renderNotifications();

}


function closeNotificationPanelUI() {

    notificationPanel.classList.add(
        'hidden'
    );

}


function toggleNotificationPanel() {

    if (
        notificationPanel.classList.contains(
            'hidden'
        )
    ) {

        openNotificationPanel();

    } else {

        closeNotificationPanelUI();

    }

}


notificationButton.addEventListener(
    'click',
    event => {

        event.stopPropagation();

        toggleNotificationPanel();

    }
);


closeNotificationPanel.addEventListener(
    'click',
    event => {

        event.stopPropagation();

        closeNotificationPanelUI();

    }
);


notificationPanel.addEventListener(
    'click',
    event => {

        event.stopPropagation();

    }
);


document.addEventListener(
    'click',
    event => {

        if (

            !notificationPanel.contains(
                event.target
            )

            &&

            event.target !==
                notificationButton

            &&

            !notificationButton.contains(
                event.target
            )

        ) {

            closeNotificationPanelUI();

        }

    }
);


/* =========================================
   PAGE NAVIGATION
========================================== */

function showPage(
    pageName
) {

    if (!pageName) {

        return;

    }


    currentPage =
        pageName;


    const homeCategoryBar =
        document.getElementById(
            'homeCategoryBar'
        );


    if (homeCategoryBar) {

        homeCategoryBar.classList.toggle(
            'hidden',
            pageName !==
            'home'
        );

    }


    pages.forEach(
        page => {

            page.classList.toggle(
                'hidden',
                page.id !==
                `page-${pageName}`
            );

        }
    );


    mobileNavItems.forEach(
        item => {

            const active =
                item.dataset.mobilePage ===
                pageName;


            item.classList.toggle(
                'bg-black/[0.06]',
                active
            );


            item.classList.toggle(
                'text-[#171717]',
                active
            );


            item.classList.toggle(
                'text-[#8a8a8a]',
                !active
            );

        }
    );


    window.scrollTo(
        {
            top:
                0,

            behavior:
                'smooth'
        }
    );

}


document
    .querySelectorAll(
        '[data-page-target]'
    )
    .forEach(
        item => {

            item.addEventListener(
                'click',
                () => {

                    showPage(
                        item.dataset.pageTarget
                    );

                }
            );

        }
    );


mobileNavItems.forEach(
    item => {

        item.addEventListener(
            'click',
            () => {

                showPage(
                    item.dataset.mobilePage
                );

            }
        );

    }
);


/* =========================================
   MARKET CATEGORIES
========================================== */

document
    .querySelectorAll(
        '[data-market-category]'
    )
    .forEach(
        button => {

            button.addEventListener(
                'click',
                () => {

                    document
                        .querySelectorAll(
                            '[data-market-category]'
                        )
                        .forEach(
                            category => {

                                category.classList.remove(
                                    'bg-white',
                                    'text-[#171717]'
                                );

                                category.classList.add(
                                    'text-[#737373]'
                                );

                            }
                        );


                    button.classList.remove(
                        'text-[#737373]'
                    );

                    button.classList.add(
                        'bg-white',
                        'text-[#171717]'
                    );


                    const selectedCategory =
                        button.dataset.marketCategory;

                    const cryptoMarketsContent =
                        document.getElementById(
                            'cryptoMarketsContent'
                        );

                    if (cryptoMarketsContent) {

                        cryptoMarketsContent.classList.toggle(
                            'hidden',
                            selectedCategory !== 'Crypto'
                        );

                    }


                    showToast(
                        `${button.textContent.trim()} markets`
                    );

                }
            );

        }
    );


/* =========================================
   DRAWERS
========================================== */

function openDrawer(
    drawer
) {

    drawerBackdrop.classList.remove(
        'pointer-events-none',
        'opacity-0'
    );


    drawerBackdrop.classList.add(
        'pointer-events-auto',
        'opacity-100'
    );


    depositDrawer.classList.add(
        'translate-y-full'
    );


    withdrawDrawer.classList.add(
        'translate-y-full'
    );


    drawer.classList.remove(
        'translate-y-full'
    );

}


function closeDrawers() {

    drawerBackdrop.classList.add(
        'pointer-events-none',
        'opacity-0'
    );


    drawerBackdrop.classList.remove(
        'pointer-events-auto',
        'opacity-100'
    );


    depositDrawer.classList.add(
        'translate-y-full'
    );


    withdrawDrawer.classList.add(
        'translate-y-full'
    );


    stopDepositTimer();

    selectedDepositId =
        null;

}


document
    .querySelectorAll(
        '[data-open-deposit]'
    )
    .forEach(
        button => {

            button.addEventListener(
                'click',
                () => {

                    openDrawer(
                        depositDrawer
                    );

                    resetDepositFlow();

                }
            );

        }
    );


document
    .querySelectorAll(
        '[data-close-drawer]'
    )
    .forEach(
        button => {

            button.addEventListener(
                'click',
                closeDrawers
            );

        }
    );


drawerBackdrop.addEventListener(
    'click',
    closeDrawers
);


document.addEventListener(
    'keydown',
    event => {

        if (
            event.key ===
            'Escape'
        ) {

            closeDrawers();

            closeNotificationPanelUI();

        }

    }
);


/* =========================================
   DEPOSIT FLOW
========================================== */

function resetDepositFlow() {

    selectedDepositId =
        null;


    bankTransferCard.classList.remove(
        'hidden'
    );


    depositAmountCard.classList.add(
        'hidden'
    );


    depositAccountCard.classList.add(
        'hidden'
    );


    depositAmountInput.value =
        '';


    selectedDepositNumericAmount =
        0;


    selectedDepositAmount.textContent =
        '₦0.00';


    depositFee.textContent =
        '-₦100';


    depositTimerLabel.textContent =
        'Accounts expire in';


    depositTimer.textContent =
        '08:00:00';


    depositAmountOptions.forEach(
        item => {

            item.classList.remove(
                'border-[#171717]',
                'bg-[#171717]',
                'text-white'
            );


            item.classList.add(
                'border-[#e5e5e3]',
                'bg-[#f7f7f5]',
                'text-[#444]'
            );

        }
    );


    updateNextButton();

    stopDepositTimer();

    setTransferButtonActive();

}


function updateNextButton() {

    const rawValue =
        depositAmountInput.value.replace(
            /[^\d]/g,
            ''
        );


    const amount =
        Number(
            rawValue
        );


    const validAmount =
        Number.isFinite(
            amount
        ) &&

        amount >=
            500 &&

        amount <=
            1000000;


    depositNextButton.disabled =
        !validAmount;


    if (validAmount) {

        depositNextButton.classList.remove(
            'cursor-not-allowed',
            'bg-[#d6d6d4]',
            'text-[#999999]'
        );


        depositNextButton.classList.add(
            'cursor-pointer',
            'bg-black',
            'text-white',
            'hover:bg-[#242424]'
        );

    } else {

        depositNextButton.classList.remove(
            'cursor-pointer',
            'bg-black',
            'text-white',
            'hover:bg-[#242424]'
        );


        depositNextButton.classList.add(
            'cursor-not-allowed',
            'bg-[#d6d6d4]',
            'text-[#999999]'
        );

    }

}


function updateDepositFee(
    amount
) {

    if (
        Number.isFinite(
            amount
        ) &&

        amount >=
            100000
    ) {

        depositFee.textContent =
            '-₦1,000';

    } else {

        depositFee.textContent =
            '-₦100';

    }

}


function setTransferButtonActive() {

    transferredFundsButton.disabled =
        false;


    transferredFundsButton.textContent =
        'I have transferred funds';


    transferredFundsButton.classList.remove(
        'cursor-not-allowed',
        'bg-[#d6d6d4]',
        'text-[#999999]'
    );


    transferredFundsButton.classList.add(
        'cursor-pointer',
        'bg-black',
        'text-white',
        'hover:bg-[#242424]'
    );

}


function setTransferButtonExpired() {

    transferredFundsButton.disabled =
        true;


    transferredFundsButton.textContent =
        'Deposit expired';


    transferredFundsButton.classList.remove(
        'cursor-pointer',
        'bg-black',
        'text-white',
        'hover:bg-[#242424]'
    );


    transferredFundsButton.classList.add(
        'cursor-not-allowed',
        'bg-[#d6d6d4]',
        'text-[#999999]'
    );

}


bankDepositOption.addEventListener(
    'click',
    () => {

        bankTransferCard.classList.add(
            'hidden'
        );


        depositAmountCard.classList.remove(
            'hidden'
        );


        depositAccountCard.classList.add(
            'hidden'
        );


        updateNextButton();


        setTimeout(
            () => {

                depositAmountInput.focus();

            },
            180
        );

    }
);


depositAmountOptions.forEach(
    option => {

        option.addEventListener(
            'click',
            () => {

                const amount =
                    option.dataset.depositAmount ||
                    '';


                const numericAmount =
                    Number(
                        amount
                    );


                depositAmountInput.value =
                    numericAmount.toLocaleString(
                        'en-NG'
                    );


                depositAmountOptions.forEach(
                    item => {

                        item.classList.remove(
                            'border-[#171717]',
                            'bg-[#171717]',
                            'text-white'
                        );


                        item.classList.add(
                            'border-[#e5e5e3]',
                            'bg-[#f7f7f5]',
                            'text-[#444]'
                        );

                    }
                );


                option.classList.remove(
                    'border-[#e5e5e3]',
                    'bg-[#f7f7f5]',
                    'text-[#444]'
                );


                option.classList.add(
                    'border-[#171717]',
                    'bg-[#171717]',
                    'text-white'
                );


                updateDepositFee(
                    numericAmount
                );


                updateNextButton();

            }
        );

    }
);


depositAmountInput.addEventListener(
    'input',
    event => {

        const rawValue =
            event.target.value.replace(
                /[^\d]/g,
                ''
            );


        if (!rawValue) {

            event.target.value =
                '';


            depositAmountOptions.forEach(
                item => {

                    item.classList.remove(
                        'border-[#171717]',
                        'bg-[#171717]',
                        'text-white'
                    );


                    item.classList.add(
                        'border-[#e5e5e3]',
                        'bg-[#f7f7f5]',
                        'text-[#444]'
                    );

                }
            );


            depositFee.textContent =
                '-₦100';


            updateNextButton();


            return;

        }


        let numericValue =
            Number(
                rawValue
            );


        if (
            numericValue >
            1000000
        ) {

            numericValue =
                1000000;

        }


        event.target.value =
            numericValue.toLocaleString(
                'en-NG'
            );


        depositAmountOptions.forEach(
            item => {

                const itemAmount =
                    Number(
                        item.dataset.depositAmount
                    );


                if (
                    itemAmount ===
                    numericValue
                ) {

                    item.classList.remove(
                        'border-[#e5e5e3]',
                        'bg-[#f7f7f5]',
                        'text-[#444]'
                    );


                    item.classList.add(
                        'border-[#171717]',
                        'bg-[#171717]',
                        'text-white'
                    );

                } else {

                    item.classList.remove(
                        'border-[#171717]',
                        'bg-[#171717]',
                        'text-white'
                    );


                    item.classList.add(
                        'border-[#e5e5e3]',
                        'bg-[#f7f7f5]',
                        'text-[#444]'
                    );

                }

            }
        );


        updateDepositFee(
            numericValue
        );


        updateNextButton();

    }
);


/* =========================================
   DEPOSIT TIMER
========================================== */

function startDepositTimer(
    startingSeconds =
        DEPOSIT_EXPIRY_SECONDS
) {

    stopDepositTimer();


    depositSecondsRemaining =
        Math.max(
            0,
            Math.floor(
                Number(
                    startingSeconds
                ) || 0
            )
        );


    updateDepositTimerDisplay();


    if (
        depositSecondsRemaining <=
        0
    ) {

        handleDepositTimerExpired();

        return;

    }


    depositTimerInterval =
        setInterval(
            () => {

                depositSecondsRemaining--;


                if (
                    depositSecondsRemaining <=
                    0
                ) {

                    depositSecondsRemaining =
                        0;


                    updateDepositTimerDisplay();


                    stopDepositTimer();


                    handleDepositTimerExpired();


                    return;

                }


                updateDepositTimerDisplay();

            },
            1000
        );

}


function stopDepositTimer() {

    if (depositTimerInterval) {

        clearInterval(
            depositTimerInterval
        );


        depositTimerInterval =
            null;

    }

}


function updateDepositTimerDisplay() {

    depositTimer.textContent =
        formatDuration(
            depositSecondsRemaining
        );

}


function handleDepositTimerExpired() {

    depositTimer.textContent =
        '00:00:00';


    depositTimerLabel.textContent =
        'This deposit has expired';


    depositTimer.classList.add(
        'text-[#c44848]'
    );


    setTransferButtonExpired();


    if (
        selectedDepositId &&
        allTransactions.length
    ) {

        const expiredTransaction =
            allTransactions.find(
                transaction =>
                    transaction.id ===
                    selectedDepositId
            );


        if (
            expiredTransaction &&
            isPendingDepositExpired(
                expiredTransaction
            )
        ) {

            addExpiredTransactionNotification(
                expiredTransaction
            );


            renderTransactionActivity();

        }

    }

}


/* =========================================
   CREATE PENDING DEPOSIT
========================================== */

async function createPendingDeposit(
    amount
) {

    if (!currentUser) {

        showToast(
            'Please log in again.'
        );


        return null;

    }


    const numericAmount =
        Number(
            amount
        );


    if (
        !Number.isFinite(
            numericAmount
        ) ||
        numericAmount <
            500 ||
        numericAmount >
            1000000
    ) {

        showToast(
            'Invalid deposit amount.'
        );


        return null;

    }


    try {

        const depositsRef =
            collection(
                db,
                'users',
                currentUser.uid,
                'deposits'
            );


        const expiresAt =
            Timestamp.fromMillis(
                Date.now() +
                (
                    DEPOSIT_EXPIRY_SECONDS *
                    1000
                )
            );


        const depositData = {

            userId:
                currentUser.uid,

            userEmail:
                currentUser.email ||
                '',

            type:
                'deposit',

            amount:
                numericAmount,

            currency:
                'NGN',

            status:
                'pending',

            method:
                'bank_transfer',

            createdAt:
                serverTimestamp(),

            expiresAt:
                expiresAt,

            updatedAt:
                serverTimestamp()

        };


        const depositDocument =
            await addDoc(
                depositsRef,
                depositData
            );


        console.log(
            'Pending deposit created:',
            depositDocument.id
        );


        return depositDocument.id;

    } catch (error) {

        console.error(
            'Create deposit error:',
            error
        );


        showToast(
            'Unable to create deposit. Please try again.'
        );


        return null;

    }

}


/* =========================================
   NEXT BUTTON
========================================== */

depositNextButton.addEventListener(
    'click',
    async () => {

        if (
            depositNextButton.disabled
        ) {

            return;

        }


        const rawValue =
            depositAmountInput.value.replace(
                /[^\d]/g,
                ''
            );


        const amount =
            Number(
                rawValue
            );


        if (
            !Number.isFinite(
                amount
            ) ||

            amount <
                500 ||

            amount >
                1000000
        ) {

            return;

        }


        depositNextButton.disabled =
            true;


        depositNextButton.textContent =
            'Creating deposit…';


        const depositId =
            await createPendingDeposit(
                amount
            );


        if (!depositId) {

            depositNextButton.textContent =
                'Next';


            updateNextButton();


            return;

        }


        selectedDepositId =
            depositId;


        selectedDepositNumericAmount =
            amount;


        selectedDepositAmount.textContent =
            formatNaira(
                amount
            );


        updateDepositFee(
            amount
        );


        depositAmountCard.classList.add(
            'hidden'
        );


        depositAccountCard.classList.remove(
            'hidden'
        );


        depositTimerLabel.textContent =
            'Accounts expire in';


        depositTimer.classList.remove(
            'text-[#c44848]'
        );


        setTransferButtonActive();


        startDepositTimer(
            DEPOSIT_EXPIRY_SECONDS
        );


        showToast(
            'Deposit created and marked pending.'
        );


        depositNextButton.textContent =
            'Next';


        updateNextButton();

    }
);


/* =========================================
   OPEN PENDING DEPOSIT DETAILS
========================================== */

function openPendingDepositDetails(
    transaction
) {

    if (!transaction) {

        return;

    }


    if (
        String(
            transaction.status ||
            ''
        ).toLowerCase() !==
        'pending'
    ) {

        return;

    }


    const remainingSeconds =
        getRemainingSeconds(
            transaction
        );


    if (
        remainingSeconds <=
        0
    ) {

        addExpiredTransactionNotification(
            transaction
        );


        renderTransactionActivity();


        showToast(
            'This deposit has expired.'
        );


        return;

    }


    selectedDepositId =
        transaction.id;


    selectedDepositNumericAmount =
        Number(
            transaction.amount ||
            0
        );


    bankTransferCard.classList.add(
        'hidden'
    );


    depositAmountCard.classList.add(
        'hidden'
    );


    depositAccountCard.classList.remove(
        'hidden'
    );


    selectedDepositAmount.textContent =
        formatNaira(
            selectedDepositNumericAmount
        );


    updateDepositFee(
        selectedDepositNumericAmount
    );


    depositTimer.classList.remove(
        'text-[#c44848]'
    );


    depositTimerLabel.textContent =
        'Accounts expire in';


    setTransferButtonActive();


    startDepositTimer(
        remainingSeconds
    );


    openDrawer(
        depositDrawer
    );

}


/* =========================================
   TRANSACTION / ACTIVITY DETAIL SHEET
========================================== */

let memewalletActivityDetailOverlay = null;
let memewalletActivityDetailPreviousOverflow = '';


function memewalletActivityDetailTimestampMs(value) {
    try {
        if (!value) {
            return 0;
        }

        if (typeof value.toMillis === 'function') {
            return value.toMillis();
        }

        if (typeof value.toDate === 'function') {
            return value.toDate().getTime();
        }

        const numeric = Number(value);
        if (Number.isFinite(numeric) && numeric > 0) {
            return numeric;
        }

        const parsed = new Date(value).getTime();
        return Number.isFinite(parsed) ? parsed : 0;
    } catch {
        return 0;
    }
}


function memewalletActivityDetailDate(value) {
    const millis =
        memewalletActivityDetailTimestampMs(value);

    if (!millis) {
        return 'Just now';
    }

    try {
        return new Date(millis).toLocaleString(
            'en-NG',
            {
                day: 'numeric',
                month: 'short',
                hour: '2-digit',
                minute: '2-digit',
                hourCycle: 'h23'
            }
        );
    } catch {
        return formatDate(value);
    }
}


function memewalletActivityDetailTime(value) {
    const millis =
        memewalletActivityDetailTimestampMs(value);

    if (!millis) {
        return '—';
    }

    try {
        return new Date(millis).toLocaleTimeString(
            'en-NG',
            {
                hour: '2-digit',
                minute: '2-digit',
                hourCycle: 'h23'
            }
        );
    } catch {
        return '—';
    }
}


function memewalletActivityDetailWindow(startValue, endValue) {
    const start =
        memewalletActivityDetailTimestampMs(startValue);

    const end =
        memewalletActivityDetailTimestampMs(endValue);

    if (!start && !end) {
        return '—';
    }

    if (start && end) {
        const startDate = new Date(start);
        const endDate = new Date(end);

        try {
            const datePart = startDate.toLocaleDateString(
                'en-NG',
                {
                    day: 'numeric',
                    month: 'short'
                }
            );

            const startTime =
                memewalletActivityDetailTime(start);
            const endTime =
                memewalletActivityDetailTime(end);

            return `${datePart}, ${startTime}–${endTime}`;
        } catch {
            return `${formatDate(startValue)}–${formatDate(endValue)}`;
        }
    }

    return formatDate(startValue || endValue);
}


function memewalletActivityDetailChoice(record) {
    const explicit = String(
        record?.choiceLabel ||
        record?.choice ||
        ''
    ).trim();

    if (explicit) {
        const normalized = explicit.toLowerCase();

        if (
            normalized === 'yes' ||
            normalized === 'up'
        ) {
            return 'Up';
        }

        if (
            normalized === 'no' ||
            normalized === 'down'
        ) {
            return 'Down';
        }

        return explicit;
    }

    const asset = String(record?.asset || '').toUpperCase();
    if (asset === 'BTC' || asset === 'SOL') {
        return 'Up';
    }

    return 'Share';
}


function memewalletActivityDetailAsset(record) {
    const asset =
        String(record?.asset || '').toUpperCase();

    if (asset === 'BTC' || asset === 'BITCOIN') {
        return {
            short: '₿',
            className: 'bg-[#f7931a] text-white',
            name: 'Bitcoin'
        };
    }

    if (asset === 'SOL' || asset === 'SOLANA') {
        return {
            short: 'S',
            className: 'bg-[#111111] text-white',
            name: 'Solana'
        };
    }

    return {
        short: '₦',
        className: 'bg-[#f4f4f2] text-[#171717]',
        name: 'MemeWallet'
    };
}


function memewalletActivityDetailMoney(value, signed = false) {
    const amount = Number(value || 0);
    const safeAmount = Number.isFinite(amount) ? amount : 0;

    if (!signed) {
        return formatNaira(safeAmount);
    }

    return `${safeAmount >= 0 ? '+' : '−'}${formatNaira(Math.abs(safeAmount))}`;
}


function memewalletActivityDetailRow(label, value, extraClass = '') {
    return `
        <div class="flex items-center justify-between gap-6 py-2.5 ${extraClass}">
            <span class="text-[13px] text-[#858585]">${escapeHtml(label)}</span>
            <span class="text-right text-[13px] font-medium text-[#171717]">${escapeHtml(value)}</span>
        </div>
    `;
}


function memewalletActivityDetailRecordMeta(record, kind = 'transaction') {
    const type = String(
        record?.type ||
        ''
    ).toLowerCase();

    const isPrediction =
        kind === 'prediction-position' ||
        kind === 'prediction-trade' ||
        type.startsWith('prediction_');

    if (!isPrediction) {
        const status = String(
            record?.status ||
            'pending'
        ).toLowerCase();

        let title = 'Transaction';
        let amount = Number(record?.amount || 0);
        let statusText = 'Pending';
        let statusClass = 'bg-[#fff7e6] text-[#a66a00]';

        if (status === 'completed' || status === 'approved') {
            statusText = 'Completed';
            statusClass = 'bg-[#eefaf2] text-[#21854a]';
        } else if (
            status === 'failed' ||
            status === 'cancelled'
        ) {
            statusText = status === 'failed' ? 'Failed' : 'Cancelled';
            statusClass = 'bg-[#fff0f0] text-[#c44848]';
        }

        if (type === 'deposit') {
            title = status === 'pending'
                ? 'Deposit pending'
                : 'Deposit';
        } else if (
            type === 'withdrawal' ||
            type === 'withdraw'
        ) {
            title = 'Withdrawal';
            amount = -Math.abs(amount);
        } else {
            title = String(record?.title || record?.description || 'Transaction');
        }

        if (
            type === 'deposit' &&
            status !== 'failed' &&
            status !== 'cancelled'
        ) {
            amount = Math.abs(amount);
        }

        return {
            title,
            amount,
            amountDisplay: memewalletActivityDetailMoney(amount, true),
            statusText,
            statusClass,
            isPrediction: false
        };
    }

    const choice = memewalletActivityDetailChoice(record);
    const stake = Number(
        record?.stake ??
        record?.amount ??
        0
    );
    const payout = Number(
        record?.payout ??
        record?.potentialPayout ??
        0
    );
    const profit = Number(
        record?.profit ??
        (payout - stake)
    );

    let title = `Bought ${choice}`;
    let amount = -Math.abs(stake);
    let statusText = 'On trade';
    let statusClass = 'bg-[#fff7e6] text-[#a66a00]';

    if (type === 'prediction_win' || record?.outcome === record?.choice) {
        title = `Won ${choice}`;
        amount = Math.abs(payout);
        statusText = 'Won';
        statusClass = 'bg-[#eefaf2] text-[#21854a]';
    } else if (type === 'prediction_refund' || record?.outcome === 'Refund') {
        title = `Refunded ${choice}`;
        amount = Math.abs(payout || stake);
        statusText = 'Refunded';
        statusClass = 'bg-[#eefaf2] text-[#21854a]';
    } else if (type === 'prediction_loss') {
        title = `Lost ${choice}`;
        amount = -Math.abs(stake);
        statusText = 'Lost';
        statusClass = 'bg-[#fff0f0] text-[#c44848]';
    } else if (String(record?.status || '').toLowerCase() === 'settled') {
        if (profit > 0) {
            title = `Won ${choice}`;
            amount = Math.abs(payout);
            statusText = 'Won';
            statusClass = 'bg-[#eefaf2] text-[#21854a]';
        } else if (profit === 0) {
            title = `Refunded ${choice}`;
            amount = Math.abs(payout || stake);
            statusText = 'Refunded';
            statusClass = 'bg-[#eefaf2] text-[#21854a]';
        } else {
            title = `Lost ${choice}`;
            amount = -Math.abs(stake);
            statusText = 'Lost';
            statusClass = 'bg-[#fff0f0] text-[#c44848]';
        }
    }

    return {
        title,
        amount,
        amountDisplay: memewalletActivityDetailMoney(amount, true),
        statusText,
        statusClass,
        isPrediction: true
    };
}


function memewalletOpenActivityDetail(record, kind = 'transaction') {
    if (!record) {
        return;
    }

    const meta =
        memewalletActivityDetailRecordMeta(
            record,
            kind
        );

    const prediction =
        meta.isPrediction;

    const asset =
        memewalletActivityDetailAsset(record);

    const timestamp =
        record?.settledAt ||
        record?.createdAt ||
        Date.now();

    const predictionTitle =
        String(
            record?.predictionTitle ||
            'Hourly prediction'
        );

    const predictionAssetName =
        asset.name ||
        String(record?.asset || '');

    const choice =
        memewalletActivityDetailChoice(record);

    const price = Number(
        record?.price ||
        0
    );

    const shares = Number(
        record?.shares ||
        0
    );

    const stake = Number(
        record?.stake ??
        record?.amount ??
        0
    );

    const fee = Number(
        record?.fee ||
        0
    );

    const potentialPayout = Number(
        record?.potentialPayout ||
        0
    );

    const windowStart =
        record?.marketHourStart ||
        record?.createdAt;

    const windowEnd =
        record?.marketHourEnd ||
        record?.expiresAt;

    const isPendingDeposit =
        !prediction &&
        String(record?.type || 'deposit').toLowerCase() === 'deposit' &&
        String(record?.status || 'pending').toLowerCase() === 'pending' &&
        !isPendingDepositExpired(record);

    const detailRows = prediction
        ? `
            ${memewalletActivityDetailRow('Event', `${predictionTitle} · Hourly`)}
            ${memewalletActivityDetailRow('Window', memewalletActivityDetailWindow(windowStart, windowEnd))}
            ${memewalletActivityDetailRow('Chance', price > 0 ? `${price.toFixed(2)}%` : '—')}
            ${memewalletActivityDetailRow('Shares', shares > 0 ? shares.toFixed(2) : '—')}
            ${memewalletActivityDetailRow('Cost', formatNaira(stake))}
            ${memewalletActivityDetailRow('Fee', formatNaira(fee))}
            ${memewalletActivityDetailRow('Max payout', potentialPayout > 0 ? formatNaira(potentialPayout) : '—')}
        `
        : `
            ${memewalletActivityDetailRow('Event', String(record?.type || 'deposit').toLowerCase() === 'deposit' ? 'Wallet deposit' : String(record?.title || 'Wallet transaction'))}
            ${memewalletActivityDetailRow('Status', meta.statusText)}
            ${memewalletActivityDetailRow('Date', memewalletActivityDetailDate(timestamp))}
            ${memewalletActivityDetailRow('Amount', formatNaira(Math.abs(Number(record?.amount || 0))))}
        `;

    const overlay = document.createElement('div');
    overlay.id = 'memewalletActivityDetailOverlay';
    overlay.className = 'fixed inset-0 z-[120] flex items-end justify-center bg-black/35 backdrop-blur-[4px]';
    overlay.innerHTML = `
        <div
            data-activity-detail-sheet
            class="w-full max-w-[520px] max-h-[92vh] overflow-y-auto rounded-t-[30px] bg-white pb-6 shadow-[0_-14px_50px_rgba(0,0,0,.18)]"
        >
            <div class="flex justify-center pt-3">
                <div class="h-1 w-14 rounded-full bg-[#ededeb]"></div>
            </div>

            <div class="flex items-center justify-end px-5 pt-2">
                <button
                    type="button"
                    data-activity-detail-close
                    aria-label="Close transaction details"
                    class="flex h-11 w-11 items-center justify-center rounded-full bg-[#f4f4f2] text-[#777] transition active:scale-95"
                >
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                        <path d="M6 6L18 18" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"></path>
                        <path d="M18 6L6 18" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"></path>
                    </svg>
                </button>
            </div>

            <div class="px-6 pb-2 pt-2 text-center">
                <div class="mx-auto flex h-20 w-20 items-center justify-center rounded-full text-[38px] font-semibold ${escapeHtml(asset.className)}">
                    ${escapeHtml(asset.short)}
                </div>

                <div class="mt-4 text-[22px] font-semibold tracking-[-0.03em] text-[#171717]">
                    ${escapeHtml(meta.title)}
                </div>

                <div class="mt-1 text-[30px] font-semibold tracking-[-0.045em] text-[#171717]">
                    ${escapeHtml(meta.amountDisplay)}
                </div>

                <div class="mt-1 text-[15px] text-[#858585]">
                    ${escapeHtml(memewalletActivityDetailDate(timestamp))}
                </div>
            </div>

            <div class="mx-5 mt-7 rounded-[24px] bg-[#f7f7f6] px-5 py-4">
                ${detailRows}

                <div class="mt-1 flex items-center justify-between gap-4 border-t border-black/[0.04] pt-4">
                    <span class="text-[13px] text-[#858585]">Result</span>
                    <span class="rounded-full px-3 py-1.5 text-[10px] font-semibold ${escapeHtml(meta.statusClass)}">
                        ${escapeHtml(meta.statusText)}
                    </span>
                </div>
            </div>

            <div class="px-5 pt-4">
                ${prediction
                    ? `
                        <div class="rounded-[16px] bg-[#fafaf8] px-4 py-3 text-[10px] leading-5 text-[#858585]">
                            ${escapeHtml(predictionAssetName)} · ${escapeHtml(choice)} prediction activity
                        </div>
                    `
                    : isPendingDeposit
                        ? `
                            <button
                                type="button"
                                data-activity-detail-continue-deposit
                                class="mt-1 w-full rounded-[16px] bg-[#171717] px-5 py-4 text-[13px] font-semibold text-white transition active:scale-[0.99]"
                            >
                                Open deposit
                            </button>
                        `
                        : ''
                }
            </div>
        </div>
    `;

    if (memewalletActivityDetailOverlay) {
        memewalletActivityDetailOverlay.remove();
    }

    memewalletActivityDetailOverlay = overlay;
    memewalletActivityDetailPreviousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    document.body.appendChild(overlay);

    overlay.addEventListener('click', event => {
        if (
            event.target === overlay ||
            event.target.closest('[data-activity-detail-close]')
        ) {
            memewalletCloseActivityDetail();
            return;
        }

        const continueDeposit =
            event.target.closest('[data-activity-detail-continue-deposit]');

        if (continueDeposit) {
            memewalletCloseActivityDetail();
            openPendingDepositDetails(record);
        }
    });
}


function memewalletCloseActivityDetail() {
    if (memewalletActivityDetailOverlay) {
        memewalletActivityDetailOverlay.remove();
        memewalletActivityDetailOverlay = null;
    }

    document.body.style.overflow =
        memewalletActivityDetailPreviousOverflow || '';
}


document.addEventListener(
    'keydown',
    event => {
        if (
            event.key === 'Escape' &&
            memewalletActivityDetailOverlay
        ) {
            memewalletCloseActivityDetail();
        }
    }
);


/* =========================================
   V2 / PREDICTION ACTIVITY CLICK EVENTS
========================================== */

document.addEventListener(
    'click',
    event => {
        const v2Row =
            event.target.closest(
                '[data-memewallet-v2-detail-id]'
            );

        if (v2Row) {
            const id =
                v2Row.dataset.memewalletV2DetailId || '';

            const position =
                memewalletV2Positions.find(
                    item =>
                        String(item?.id || '') === String(id)
                );

            if (position) {
                memewalletOpenActivityDetail(
                    position,
                    'prediction-position'
                );
            }

            return;
        }

        const tradeRow =
            event.target.closest(
                '[data-memewallet-trade-detail-id]'
            );

        if (tradeRow) {
            const id =
                tradeRow.dataset.memewalletTradeDetailId || '';

            const trade =
                memewalletTrades.find(
                    item =>
                        String(item?.id || '') === String(id)
                );

            if (trade) {
                memewalletOpenActivityDetail(
                    trade,
                    'prediction-trade'
                );
            }
        }
    }
);


/* =========================================
   TRANSACTION CLICK EVENTS
========================================== */

transactionList.addEventListener(
    'click',
    event => {

        const transactionButton =
            event.target.closest(
                '[data-transaction-id]'
            );


        if (!transactionButton) {

            return;

        }


        event.preventDefault();


        const transactionId =
            transactionButton.dataset.transactionId;


        const transaction =
            allTransactions.find(
                item =>
                    item.id ===
                    transactionId
            );


        if (!transaction) {

            return;

        }


        if (
            isPendingDepositExpired(
                transaction
            )
        ) {

            addExpiredTransactionNotification(
                transaction
            );


            renderTransactionActivity();


            showToast(
                'This deposit has expired.'
            );


            return;

        }


        memewalletOpenActivityDetail(
            transaction,
            'transaction'
        );

    }
);


/* =========================================
   FIRESTORE TRANSACTIONS
========================================== */

function listenForTransactions(
    user
) {

    if (
        unsubscribeTransactions
    ) {

        unsubscribeTransactions();

        unsubscribeTransactions =
            null;

    }


    pendingTransactions =
        [];


    allTransactions =
        [];


    transactionActivityKey =
        '';


    transactionList.innerHTML =
        '';


    transactionList.classList.add(
        'hidden'
    );


    transactionsEmpty.classList.remove(
        'hidden'
    );


    if (!user) {

        return;

    }


    transactionLoading.classList.remove(
        'hidden'
    );


    const depositsRef =
        collection(
            db,
            'users',
            user.uid,
            'deposits'
        );


    const depositsQuery =
        query(
            depositsRef,
            orderBy(
                'createdAt',
                'desc'
            )
        );


    unsubscribeTransactions =
        onSnapshot(
            depositsQuery,
            snapshot => {

                transactionLoading.classList.add(
                    'hidden'
                );


                allTransactions =
                    snapshot.docs.map(
                        documentSnapshot => {

                            return {

                                id:
                                    documentSnapshot.id,

                                ...documentSnapshot.data()

                            };

                        }
                    );


                processExpiredTransactions(
                    allTransactions
                );


                renderTransactionActivity();

            },
            error => {

                transactionLoading.classList.add(
                    'hidden'
                );


                console.error(
                    'Transaction listener error:',
                    error
                );


                transactionsEmpty.classList.remove(
                    'hidden'
                );


                transactionList.classList.add(
                    'hidden'
                );


                showToast(
                    'Unable to load transactions.'
                );

            }
        );

}


/* =========================================
   TRANSACTION ACTIVITY
========================================== */

function renderTransactionActivity() {

    const activeTransactions =
        allTransactions.filter(
            transaction =>
                !isPendingDepositExpired(
                    transaction
                )
        );


    pendingTransactions =
        activeTransactions.filter(
            transaction => {

                return String(
                    transaction.status ||
                    'pending'
                ).toLowerCase() ===
                'pending';

            }
        );


    const newActivityKey =
        activeTransactions
            .map(
                transaction => {

                    return [

                        transaction.id,

                        String(
                            transaction.status ||
                            'pending'
                        ).toLowerCase(),

                        getDepositExpiryMillis(
                            transaction
                        ) || ''

                    ].join(':');

                }
            )
            .join('|');


    if (
        newActivityKey ===
        transactionActivityKey
    ) {

        updatePendingTransactionCountdowns();

        return;

    }


    transactionActivityKey =
        newActivityKey;


    if (
        activeTransactions.length ===
        0
    ) {

        transactionList.innerHTML =
            '';


        transactionList.classList.add(
            'hidden'
        );


        transactionsEmpty.classList.remove(
            'hidden'
        );


        return;

    }


    transactionsEmpty.classList.add(
        'hidden'
    );


    transactionList.classList.remove(
        'hidden'
    );


    transactionList.innerHTML =
        activeTransactions
            .map(
                transaction =>
                    renderTransaction(
                        transaction
                    )
            )
            .join('');


    updatePendingTransactionCountdowns();

}


/* =========================================
   TRANSACTION UI
========================================== */

function renderTransaction(
    transaction
) {

    const amount =
        Number(
            transaction.amount ||
            0
        );


    const type =
        String(
            transaction.type ||
            'deposit'
        ).toLowerCase();


    let status =
        String(
            transaction.status ||
            'pending'
        ).toLowerCase();


    let statusText =
        'Pending';


    let statusClasses =
        'bg-[#fff7e6] text-[#a66a00]';


    if (
        status ===
        'completed'
    ) {

        statusText =
            'Completed';


        statusClasses =
            'bg-[#eefaf2] text-[#21854a]';

    }


    if (
        status ===
            'failed'

        ||

        status ===
            'cancelled'
    ) {

        statusText =
            status ===
                'failed'

                ? 'Failed'

                : 'Cancelled';


        statusClasses =
            'bg-[#fff0f0] text-[#c44848]';

    }


    const label =
        type ===
            'deposit'

            ? 'Deposit'

            : 'Transaction';


    const amountPrefix =
        type ===
            'deposit'

            ? '+'

            : '';


    const remainingSeconds =
        status ===
            'pending'

            ? getRemainingSeconds(
                transaction
            )

            : 0;


    const clickable =
        true;


    return `

        <button
            type="button"
            data-transaction-id="${escapeHtml(
                transaction.id
            )}"
            class="w-full text-left ${
                clickable

                    ? 'cursor-pointer transition hover:bg-[#fafaf8]'

                    : 'cursor-default'
            }"
        >

            <div class="flex items-center gap-3 py-4">

                <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#f4f4f2] text-[#171717]">

                    <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                    >

                        <path
                            d="M12 17V3"
                            stroke="currentColor"
                            stroke-width="1.8"
                            stroke-linecap="round"
                        ></path>

                        <path
                            d="M6 11L12 17L18 11"
                            stroke="currentColor"
                            stroke-width="1.8"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                        ></path>

                        <path
                            d="M5 21H19"
                            stroke="currentColor"
                            stroke-width="1.8"
                            stroke-linecap="round"
                        ></path>

                    </svg>

                </div>


                <div class="min-w-0 flex-1">

                    <div class="flex items-center justify-between gap-3">

                        <p class="truncate text-[13px] font-semibold">

                            ${escapeHtml(
                                label
                            )}

                        </p>


                        <strong class="shrink-0 text-[13px] font-semibold tracking-[-0.02em]">

                            ${amountPrefix}${formatNaira(
                                amount
                            )}

                        </strong>

                    </div>


                    <div class="mt-1 flex items-center gap-2">

                        <span
                            data-status-badge="${escapeHtml(
                                transaction.id
                            )}"
                            class="rounded-full px-2 py-1 text-[9px] font-semibold ${statusClasses}"
                        >

                            ${escapeHtml(
                                statusText
                            )}

                        </span>


                        <span class="truncate text-[10px] text-[#858585]">

                            ${escapeHtml(
                                formatDate(
                                    transaction.createdAt
                                )
                            )}

                        </span>


                        ${
                            status ===
                            'pending'

                                ? `

                                    <span
                                        data-pending-timer="${escapeHtml(
                                            transaction.id
                                        )}"
                                        class="ml-auto shrink-0 text-[10px] font-semibold text-[#a66a00]"
                                    >

                                        ${
                                            remainingSeconds >
                                            0

                                                ? `${formatDuration(
                                                    remainingSeconds
                                                )} left`

                                                : 'Expired'
                                        }

                                    </span>

                                  `

                                : ''
                        }

                    </div>

                </div>

            </div>

        </button>

    `;

}


/* =========================================
   LIVE PENDING TRANSACTION TIMERS
========================================== */

function updatePendingTransactionCountdowns() {

    const timerElements =
        transactionList.querySelectorAll(
            '[data-pending-timer]'
        );


    if (
        !timerElements.length
    ) {

        return;

    }


    timerElements.forEach(
        timerElement => {

            const transactionId =
                timerElement.dataset.pendingTimer;


            const transaction =
                pendingTransactions.find(
                    item =>
                        item.id ===
                        transactionId
                );


            if (!transaction) {

                return;

            }


            const remainingSeconds =
                getRemainingSeconds(
                    transaction
                );


            if (
                remainingSeconds <=
                0
            ) {

                addExpiredTransactionNotification(
                    transaction
                );


                renderTransactionActivity();


                if (
                    selectedDepositId ===
                    transactionId
                ) {

                    stopDepositTimer();


                    selectedDepositId =
                        null;


                    handleDepositTimerExpired();

                }


                return;

            }


            timerElement.textContent =
                `${formatDuration(
                    remainingSeconds
                )} left`;


            timerElement.classList.remove(
                'text-[#c44848]'
            );


            timerElement.classList.add(
                'text-[#a66a00]'
            );

        }
    );

}


setInterval(
    () => {

        if (
            !currentUser ||
            allTransactions.length ===
                0
        ) {

            return;

        }


        processExpiredTransactions(
            allTransactions
        );


        renderTransactionActivity();

    },
    1000
);


/* =========================================
   COPY BUTTONS
========================================== */

document
    .querySelectorAll(
        '[data-copy-value]'
    )
    .forEach(
        button => {

            button.addEventListener(
                'click',
                async event => {

                    event.stopPropagation();


                    const value =
                        button.dataset.copyValue ||
                        '';


                    try {

                        await navigator.clipboard.writeText(
                            value
                        );


                        showToast(
                            'Copied'
                        );


                    } catch (error) {

                        const temporaryInput =
                            document.createElement(
                                'input'
                            );


                        temporaryInput.value =
                            value;


                        document.body.appendChild(
                            temporaryInput
                        );


                        temporaryInput.select();


                        document.execCommand(
                            'copy'
                        );


                        temporaryInput.remove();


                        showToast(
                            'Copied'
                        );

                    }

                }
            );

        }
    );


/* =========================================
   TRANSFER BUTTON
========================================== */

transferredFundsButton.addEventListener(
    'click',
    () => {

        if (
            transferredFundsButton.disabled
        ) {

            return;

        }


        if (!selectedDepositId) {

            showToast(
                'This deposit is not ready.'
            );


            return;

        }


        const transaction =
            allTransactions.find(
                item =>
                    item.id ===
                    selectedDepositId
            );


        if (
            transaction &&
            isPendingDepositExpired(
                transaction
            )
        ) {

            addExpiredTransactionNotification(
                transaction
            );


            renderTransactionActivity();


            showToast(
                'This deposit has expired.'
            );


            return;

        }


        showToast(
            'Transfer submitted. Your deposit is still pending verification.'
        );

    }
);


/* =========================================
   WITHDRAW
========================================== */

document
    .getElementById(
        'withdrawButton'
    )
    .addEventListener(
        'click',
        () => {

            openDrawer(
                withdrawDrawer
            );

        }
    );


document
    .getElementById(
        'bankWithdrawOption'
    )
    .addEventListener(
        'click',
        () => {

            showToast(
                'Bank withdrawal will be connected to your backend.'
            );

        }
    );


/* =========================================
   OTHER BUTTONS
========================================== */

document
    .getElementById(
        'explorePredictions'
    )
    .addEventListener(
        'click',
        () => {

            showPage(
                'home'
            );

        }
    );


document
    .getElementById(
        'claimTradingCredit'
    )
    .addEventListener(
        'click',
        () => {

            showToast(
                'Trading credit will be available when the promotion is active.'
            );

        }
    );


document
    .getElementById(
        'profileButton'
    )
    .addEventListener(
        'click',
        () => {

            showPage(
                'profile'
            );

        }
    );


document
    .getElementById(
        'marketSearch'
    )
    .addEventListener(
        'keydown',
        event => {

            if (
                event.key !==
                'Enter'
            ) {

                return;

            }


            const queryValue =
                event.target.value.trim();


            if (!queryValue) {

                return;

            }


            showPage(
                'home'
            );


            showToast(
                `Searching markets for "${queryValue}"`
            );

        }
    );


document
    .getElementById(
        'headerSearchButton'
    )
    .addEventListener(
        'click',
        () => {

            const searchInput =
                document.getElementById(
                    'marketSearch'
                );


            if (searchInput) {

                searchInput.focus();

            }

        }
    );


/* =========================================
   PROFILE PAGE ACTIONS
========================================== */

const profileNotificationButton =
    document.getElementById(
        'profileNotificationButton'
    );

const profileSettingsButton =
    document.getElementById(
        'profileSettingsButton'
    );


if (profileNotificationButton) {

    profileNotificationButton.addEventListener(
        'click',
        event => {

            event.stopPropagation();

            openNotificationPanel();

        }
    );

}


if (profileSettingsButton) {

    profileSettingsButton.addEventListener(
        'click',
        () => {

            showToast(
                'Account settings will be connected here.'
            );

        }
    );

}


/* =========================================
   TOAST
========================================== */

function showToast(
    message
) {

    toast.textContent =
        message;


    toast.classList.remove(
        'opacity-0',
        'translate-y-2'
    );


    toast.classList.add(
        'opacity-100',
        'translate-y-0'
    );


    clearTimeout(
        toastTimer
    );


    toastTimer =
        setTimeout(
            () => {

                toast.classList.add(
                    'opacity-0',
                    'translate-y-2'
                );


                toast.classList.remove(
                    'opacity-100',
                    'translate-y-0'
                );

            },
            2800
        );

}


/* =========================================
   USER UI
========================================== */

function getInitials(
    email
) {

    if (!email) {

        return 'M';

    }


    return email
        .split('@')[0]
        .slice(
            0,
            2
        )
        .toUpperCase();

}


function updateUserUI(
    user
) {

    if (!user) {

        return;

    }


    const email =
        user.email ||
        'MemeWallet User';


    const initials =
        getInitials(
            email
        );


    const displayName =
        user.displayName ||
        email.split('@')[0];


    headerAvatar.textContent =
        initials;


    profileAvatar.textContent =
        initials;


    headerUserEmail.textContent =
        email;


    profileDisplayName.textContent =
        displayName;


    profileDisplayEmail.textContent =
        email;


    profileUserId.textContent =
        user.uid;


    if (profileAccountEmail) {

        profileAccountEmail.textContent =
            email;

    }


    if (profileAccountName) {

        profileAccountName.textContent =
            displayName;

    }

}


/* =========================================
   LOGOUT
========================================== */

document
    .getElementById(
        'logoutButton'
    )
    .addEventListener(
        'click',
        async () => {

            try {

                await signOut(
                    auth
                );


                if (
                    unsubscribeTransactions
                ) {

                    unsubscribeTransactions();

                    unsubscribeTransactions =
                        null;

                }


                if (
                    unsubscribeUserWallet
                ) {

                    unsubscribeUserWallet();

                    unsubscribeUserWallet =
                        null;

                }


                currentUser =
                    null;


                allTransactions =
                    [];


                pendingTransactions =
                    [];


                notifications =
                    [];


                transactionActivityKey =
                    '';


                updateDisplayedWalletBalance(
                    null
                );


                closeNotificationPanelUI();


                window.location.href =
                    '/';

            } catch (error) {

                console.error(
                    'Logout error:',
                    error
                );


                showToast(
                    'Unable to log out. Please try again.'
                );

            }

        }
    );


/* =========================================
   AUTH STATE
========================================== */

onAuthStateChanged(
    auth,
    user => {

        if (!user) {

            if (
                unsubscribeTransactions
            ) {

                unsubscribeTransactions();

                unsubscribeTransactions =
                    null;

            }


            if (
                unsubscribeUserWallet
            ) {

                unsubscribeUserWallet();

                unsubscribeUserWallet =
                    null;

            }


            currentUser =
                null;


            allTransactions =
                [];


            pendingTransactions =
                [];


            notifications =
                [];


            transactionActivityKey =
                '';


            updateDisplayedWalletBalance(
                null
            );


            closeNotificationPanelUI();


            window.location.href =
                '/';

            return;

        }


        currentUser =
            user;


        console.log(
            'MemeWallet logged-in Gmail:',
            user.email
        );


        updateUserUI(
            user
        );


        listenForUserWallet(
            user
        );


        loadNotifications();


        listenForTransactions(
            user
        );

    }
);


/* =========================================
   INITIAL
========================================== */

showPage(
    'wallet'
);

updateNextButton();

updateDisplayedWalletBalance(
    null
);

/*
 * Fast startup paint: Firebase may take a moment to restore the local
 * authenticated session and read /users/{uid}. Paint the last-known Gmail
 * balance cache as soon as this module finishes evaluating. Firestore still
 * replaces it with the live value, and cached data is never used to approve
 * buys, withdrawals, deposits, or other wallet writes.
 */
setTimeout(() => {
    try {
        if (
            typeof memewalletFastApplyCachedAuthProfile ===
            'function'
        ) {
            memewalletFastApplyCachedAuthProfile();
        } else if (
            typeof memewalletFastApplyCachedWalletBalance ===
            'function'
        ) {
            memewalletFastApplyCachedWalletBalance();
        }
    } catch (cacheError) {
        console.warn(
            'MEMEWALLET STARTUP WALLET CACHE PAINT FAILED',
            cacheError
        );
    }
}, 0);


/* ================================================================
   ADDED: PREDICTION TRADE WALLET / STAKE / SETTLEMENT SYSTEM
   ----------------------------------------------------------------
   This block is intentionally additive. Existing wallet/deposit/
   navigation functions above are left unchanged.

   Behaviour added:
     1. Buy Yes/No using the existing trade drawer callback.
     2. Atomically deduct the stake from the user's current balance.
     3. Store the open position under users/{uid}/trades.
     4. Track the amount as "on trade" until the hourly market ends.
     5. Resolve BTC and SOL hourly markets from Binance 1H candles.
     6. Pay the calculated share payout back into the wallet on a win.
     7. Return the stake on a flat/refund outcome.
     8. Record buy/win/loss/refund activity in a separate collection.
     9. Show active positions + settlement history in the wallet page.

   IMPORTANT:
   The existing trade drawer continues to own its UI/selection logic.
   This block only supplies the wallet operation requested by it.
================================================================ */

const MEMEWALLET_TRADE_SYSTEM = {
    tradesCollection: 'trades',
    activityCollection: 'tradeActivities',
    tradeStatusOpen: 'open',
    tradeStatusSettled: 'settled',
    requestTimeoutMs: 3500,
    settlementPollMs: 2500,
    maxHistoryRows: 20
};

let memewalletTradeUser = null;
let memewalletTradeUnsubscribe = null;
let memewalletTradeTimer = null;
let memewalletTrades = [];
let memewalletTradeSettlementBusy = new Set();
let memewalletTradeUi = null;


function memewalletTradeBalanceField(
    userData
) {
    if (
        userData &&
        typeof userData.cashBalance === 'number'
    ) {
        return 'cashBalance';
    }

    if (
        userData &&
        typeof userData.walletBalance === 'number'
    ) {
        return 'walletBalance';
    }

    if (
        userData &&
        typeof userData.balance === 'number'
    ) {
        return 'balance';
    }

    if (
        userData &&
        typeof userData.availableBalance === 'number'
    ) {
        return 'availableBalance';
    }

    return 'cashBalance';
}


function memewalletTradeCurrentBalance(
    userData
) {
    if (!userData) {
        return 0;
    }

    const fields = [
        'cashBalance',
        'walletBalance',
        'balance',
        'availableBalance'
    ];

    for (
        const field of fields
    ) {
        const value = Number(
            userData[field]
        );

        if (
            Number.isFinite(value)
        ) {
            return Math.max(
                0,
                value
            );
        }
    }

    return 0;
}


function memewalletTradeAsset(
    predictionTitle,
    predictionId
) {
    const value = `${String(
        predictionTitle || ''
    )} ${String(
        predictionId || ''
    )}`.toLowerCase();

    if (
        /bitcoin|\bbtc\b/.test(value)
    ) {
        return {
            asset: 'BTC',
            symbol: 'BTCUSDT',
            display: 'Bitcoin'
        };
    }

    if (
        /solana|\bsol\b/.test(value)
    ) {
        return {
            asset: 'SOL',
            symbol: 'SOLUSDT',
            display: 'Solana'
        };
    }

    return null;
}


function memewalletNextUtcHourStart(
    timestamp = Date.now()
) {
    const date = new Date(
        timestamp
    );

    return Date.UTC(
        date.getUTCFullYear(),
        date.getUTCMonth(),
        date.getUTCDate(),
        date.getUTCHours() + 1,
        0,
        0,
        0
    );
}


function memewalletHourStart(
    timestamp = Date.now()
) {
    const date = new Date(
        timestamp
    );

    return Date.UTC(
        date.getUTCFullYear(),
        date.getUTCMonth(),
        date.getUTCDate(),
        date.getUTCHours(),
        0,
        0,
        0
    );
}


function memewalletTradeTimestampMillis(
    value
) {
    return getTimestampMillis(
        value
    );
}


async function memewalletFetchJsonWithTimeout(
    url,
    timeoutMs = MEMEWALLET_TRADE_SYSTEM.requestTimeoutMs
) {
    const controller =
        new AbortController();

    const timer =
        setTimeout(
            () => controller.abort(),
            timeoutMs
        );

    try {
        const response =
            await fetch(
                url,
                {
                    method: 'GET',
                    cache: 'no-store',
                    signal: controller.signal,
                    headers: {
                        Accept: 'application/json'
                    }
                }
            );

        if (!response.ok) {
            throw new Error(
                `HTTP ${response.status}`
            );
        }

        return await response.json();
    } finally {
        clearTimeout(timer);
    }
}


function memewalletBinanceKlineUrls(
    symbol,
    hourStartMs
) {
    const query =
        `symbol=${encodeURIComponent(symbol)}` +
        `&interval=1h` +
        `&startTime=${encodeURIComponent(String(hourStartMs))}` +
        `&limit=1`;

    return [
        `https://data-api.binance.vision/api/v3/klines?${query}`,
        `https://api.binance.com/api/v3/klines?${query}`,
        `https://api1.binance.com/api/v3/klines?${query}`,
        `https://api2.binance.com/api/v3/klines?${query}`
    ];
}


async function memewalletGetHourlyCandle(
    symbol,
    hourStartMs
) {
    const urls =
        memewalletBinanceKlineUrls(
            symbol,
            hourStartMs
        );

    let lastError = null;

    for (
        const url of urls
    ) {
        try {
            const data =
                await memewalletFetchJsonWithTimeout(
                    url
                );

            if (
                !Array.isArray(data) ||
                !data.length
            ) {
                throw new Error(
                    'Binance returned no hourly candle.'
                );
            }

            const row = data.find(
                item =>
                    Number(item?.[0]) ===
                    Number(hourStartMs)
            ) || data[0];

            const open = Number(
                row?.[1]
            );

            const close = Number(
                row?.[4]
            );

            const openTime = Number(
                row?.[0]
            );

            const closeTime = Number(
                row?.[6]
            );

            if (
                !Number.isFinite(open) ||
                open <= 0 ||
                !Number.isFinite(close) ||
                close <= 0 ||
                !Number.isFinite(openTime)
            ) {
                throw new Error(
                    'Binance returned an invalid hourly candle.'
                );
            }

            return {
                symbol,
                open,
                close,
                openTime,
                closeTime: Number.isFinite(closeTime)
                    ? closeTime
                    : openTime + 3600000 - 1
            };
        } catch (error) {
            lastError = error;
        }
    }

    throw (
        lastError ||
        new Error(
            'Unable to load Binance hourly market data.'
        )
    );
}


function memewalletHourlyOutcome(
    open,
    close
) {
    const start = Number(open);
    const end = Number(close);

    if (
        !Number.isFinite(start) ||
        start <= 0 ||
        !Number.isFinite(end) ||
        end <= 0
    ) {
        return {
            result: null,
            move: 0
        };
    }

    const move =
        ((end - start) / start) * 100;

    if (
        move > 0.005
    ) {
        return {
            result: 'Yes',
            move
        };
    }

    if (
        move < -0.005
    ) {
        return {
            result: 'No',
            move
        };
    }

    return {
        result: 'Refund',
        move
    };
}


function memewalletTradeOutcomeLabel(
    trade
) {
    const status =
        String(
            trade?.status || ''
        ).toLowerCase();

    const outcome =
        String(
            trade?.outcome || ''
        );

    if (
        status ===
        MEMEWALLET_TRADE_SYSTEM.tradeStatusOpen
    ) {
        return 'On trade';
    }

    if (
        outcome === 'Refund'
    ) {
        return 'Refunded';
    }

    if (
        outcome === String(trade?.choice || '')
    ) {
        return 'Won';
    }

    return 'Lost';
}


function memewalletTradeStatusClasses(
    label
) {
    if (
        label === 'Won'
    ) {
        return 'bg-[#eefaf2] text-[#21854a]';
    }

    if (
        label === 'Lost'
    ) {
        return 'bg-[#fff0f0] text-[#c44848]';
    }

    if (
        label === 'Refunded'
    ) {
        return 'bg-[#f4f4f2] text-[#737373]';
    }

    return 'bg-[#fff7e6] text-[#a66a00]';
}


function memewalletTradeLabel(
    trade
) {
    const choice =
        String(
            trade?.choiceLabel ||
            trade?.choice ||
            ''
        ).trim();

    const asset =
        String(
            trade?.asset ||
            ''
        ).trim();

    return `${trade?.mode === 'Sell' ? 'Sell' : 'Buy'} ${choice || 'share'}${asset ? ` · ${asset}` : ''}`;
}


function memewalletTradeRemainingMs(
    trade
) {
    const expires =
        memewalletTradeTimestampMillis(
            trade?.expiresAt
        );

    if (!expires) {
        return 0;
    }

    return Math.max(
        0,
        expires - Date.now()
    );
}


function memewalletFormatTradeCountdown(
    remainingMs
) {
    const seconds =
        Math.max(
            0,
            Math.ceil(
                Number(remainingMs || 0) /
                    1000
            )
        );

    const hours =
        Math.floor(seconds / 3600);

    const minutes =
        Math.floor(
            (seconds % 3600) / 60
        );

    const sec =
        seconds % 60;

    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
}


function memewalletEnsureTradeUi() {
    if (
        memewalletTradeUi &&
        memewalletTradeUi.isConnected
    ) {
        return memewalletTradeUi;
    }

    const walletPage =
        document.getElementById(
            'page-wallet'
        );

    if (!walletPage) {
        return null;
    }

    let card =
        document.getElementById(
            'memewalletTradeActivityCard'
        );

    if (!card) {
        card = document.createElement(
            'section'
        );

        card.id =
            'memewalletTradeActivityCard';

        card.className =
            'mt-3 rounded-[22px] bg-white p-5 shadow-[0_10px_35px_rgba(0,0,0,.035)]';

        card.innerHTML = `
            <div class="flex items-center justify-between gap-3">
                <div>
                    <h2 class="text-base font-semibold tracking-[-0.02em]">Prediction activity</h2>
                    <p class="mt-1 text-[10px] leading-5 text-[#858585]">Your stake stays locked until the hourly market settles.</p>
                </div>
                <span id="memewalletTradeActivityBalance" class="text-[11px] font-semibold text-[#858585]">₦0.00</span>
            </div>
            <div id="memewalletActivePositions" class="mt-4"></div>
            <div id="memewalletTradeHistory" class="mt-4 border-t border-[#eeeeec] pt-3"></div>
        `;

        walletPage.appendChild(card);
    }

    memewalletTradeUi = card;
    return card;
}


function memewalletRenderTradeUi() {
    const card =
        memewalletEnsureTradeUi();

    if (!card) {
        return;
    }

    const active = card.querySelector(
        '#memewalletActivePositions'
    );

    const history = card.querySelector(
        '#memewalletTradeHistory'
    );

    const balance = card.querySelector(
        '#memewalletTradeActivityBalance'
    );

    if (balance && memewalletTradeUser) {
        balance.textContent =
            walletBalance?.textContent ||
            '₦0.00';
    }

    const openTrades =
        memewalletTrades
            .filter(
                trade =>
                    String(trade?.status || '') ===
                    MEMEWALLET_TRADE_SYSTEM.tradeStatusOpen
            )
            .sort(
                (a, b) =>
                    (memewalletTradeTimestampMillis(b?.createdAt) || 0) -
                    (memewalletTradeTimestampMillis(a?.createdAt) || 0)
            );

    if (active) {
        if (!openTrades.length) {
            active.innerHTML = `
                <div class="rounded-[16px] bg-[#f7f7f5] px-4 py-3 text-[10px] leading-5 text-[#858585]">
                    No active positions. Your bought shares will appear here while they are on trade.
                </div>
            `;
        } else {
            active.innerHTML = `
                <div class="mb-2 text-[10px] font-semibold uppercase tracking-[0.08em] text-[#9a9a98]">Active positions</div>
                <div class="space-y-2">
                    ${openTrades.map(trade => {
                        const stake = Number(trade?.stake || 0);
                        const payout = Number(trade?.potentialPayout || 0);
                        const remaining = memewalletTradeRemainingMs(trade);
                        return `
                            <div class="cursor-pointer rounded-[17px] border border-[#eeeeec] px-4 py-3 transition hover:bg-[#fafaf8]" data-memewallet-trade-row="${escapeHtml(trade.id)}" data-memewallet-trade-detail-id="${escapeHtml(trade.id)}" role="button" tabindex="0">
                                <div class="flex items-center justify-between gap-3">
                                    <div class="min-w-0">
                                        <div class="truncate text-[12px] font-semibold">${escapeHtml(memewalletTradeLabel(trade))}</div>
                                        <div class="mt-1 truncate text-[10px] text-[#858585]">${escapeHtml(String(trade?.predictionTitle || 'Prediction'))}</div>
                                    </div>
                                    <span class="shrink-0 rounded-full px-2 py-1 text-[9px] font-semibold bg-[#fff7e6] text-[#a66a00]">On trade</span>
                                </div>
                                <div class="mt-3 grid grid-cols-3 gap-2 text-[10px]">
                                    <div>
                                        <span class="block text-[#999]">Staked</span>
                                        <strong class="mt-0.5 block text-[11px]">${escapeHtml(formatNaira(stake))}</strong>
                                    </div>
                                    <div>
                                        <span class="block text-[#999]">Potential</span>
                                        <strong class="mt-0.5 block text-[11px]">${escapeHtml(formatNaira(payout))}</strong>
                                    </div>
                                    <div class="text-right">
                                        <span class="block text-[#999]">Ends in</span>
                                        <strong class="mt-0.5 block text-[11px]" data-memewallet-trade-countdown="${escapeHtml(trade.id)}">${memewalletFormatTradeCountdown(remaining)}</strong>
                                    </div>
                                </div>
                            </div>
                        `;
                    }).join('')}
                </div>
            `;
        }
    }

    const settled =
        memewalletTrades
            .filter(
                trade =>
                    String(trade?.status || '').toLowerCase() ===
                    MEMEWALLET_TRADE_SYSTEM.tradeStatusSettled
            )
            .sort(
                (a, b) =>
                    (memewalletTradeTimestampMillis(b?.settledAt || b?.createdAt) || 0) -
                    (memewalletTradeTimestampMillis(a?.settledAt || a?.createdAt) || 0)
            )
            .slice(
                0,
                MEMEWALLET_TRADE_SYSTEM.maxHistoryRows
            );

    if (history) {
        if (!settled.length) {
            history.innerHTML = `
                <div class="text-[10px] leading-5 text-[#858585]">No settled prediction history yet.</div>
            `;
        } else {
            history.innerHTML = `
                <div class="mb-2 text-[10px] font-semibold uppercase tracking-[0.08em] text-[#9a9a98]">History</div>
                <div class="divide-y divide-[#eeeeec]">
                    ${settled.map(trade => {
                        const label = memewalletTradeOutcomeLabel(trade);
                        const payout = Number(trade?.payout || 0);
                        const stake = Number(trade?.stake || 0);
                        const net = Number(trade?.profit || (payout - stake));
                        const timestamp = trade?.settledAt || trade?.createdAt;
                        const amountText =
                            label === 'Won'
                                ? `+${formatNaira(payout)}`
                                : label === 'Refunded'
                                    ? `+${formatNaira(payout)}`
                                    : formatNaira(Math.max(0, net));

                        return `
                            <div class="flex cursor-pointer items-center gap-3 py-3 transition hover:bg-[#fafaf8]" data-memewallet-trade-detail-id="${escapeHtml(trade.id)}" role="button" tabindex="0">
                                <div class="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#f4f4f2] text-[11px] font-semibold">
                                    ${escapeHtml(String(trade?.choice || '?').slice(0, 1).toUpperCase())}
                                </div>
                                <div class="min-w-0 flex-1">
                                    <div class="flex items-center justify-between gap-3">
                                        <div class="truncate text-[11px] font-semibold">${escapeHtml(memewalletTradeLabel(trade))}</div>
                                        <strong class="shrink-0 text-[11px] font-semibold">${escapeHtml(amountText)}</strong>
                                    </div>
                                    <div class="mt-1 flex items-center gap-2">
                                        <span class="rounded-full px-2 py-1 text-[8px] font-semibold ${memewalletTradeStatusClasses(label)}">${escapeHtml(label)}</span>
                                        <span class="truncate text-[9px] text-[#858585]">${escapeHtml(formatDate(timestamp))}</span>
                                    </div>
                                </div>
                            </div>
                        `;
                    }).join('')}
                </div>
            `;
        }
    }
}


function memewalletUpdateTradeCountdownUi() {
    const card = memewalletTradeUi;

    if (!card) {
        return;
    }

    card.querySelectorAll(
        '[data-memewallet-trade-countdown]'
    ).forEach(
        element => {
            const trade = memewalletTrades.find(
                item =>
                    String(item?.id || '') ===
                    String(element.dataset.memewalletTradeCountdown || '')
            );

            if (!trade) {
                return;
            }

            const remaining =
                memewalletTradeRemainingMs(trade);

            element.textContent =
                memewalletFormatTradeCountdown(
                    remaining
                );

            element.classList.toggle(
                'text-[#c43d3d]',
                remaining > 0 && remaining <= 60000
            );
        }
    );
}


async function memewalletCompletePredictionTrade(
    tradeInput
) {
    if (!memewalletTradeUser) {
        showToast(
            'Please log in again before trading.'
        );

        return {
            success: false
        };
    }

    const amount = Number(
        tradeInput?.amount
    );

    const price = Number(
        tradeInput?.price
    );

    const choice =
        String(
            tradeInput?.choice || 'Yes'
        ) === 'No'
            ? 'No'
            : 'Yes';

    const mode =
        String(
            tradeInput?.mode || 'Buy'
        ) === 'Sell'
            ? 'Sell'
            : 'Buy';

    const predictionId =
        String(
            tradeInput?.predictionId || ''
        );

    const predictionTitle =
        String(
            tradeInput?.predictionTitle ||
            'Prediction'
        );

    if (
        mode !== 'Buy'
    ) {
        showToast(
            'Selling is not enabled by the new wallet stake system yet.'
        );

        return {
            success: false
        };
    }

    if (
        !Number.isFinite(amount) ||
        amount <= 0
    ) {
        showToast(
            'Enter a valid trade amount.'
        );

        return {
            success: false
        };
    }

    if (
        !Number.isFinite(price) ||
        price <= 0 ||
        price > 100
    ) {
        showToast(
            'This market does not have a valid share price right now.'
        );

        return {
            success: false
        };
    }

    const assetInfo =
        memewalletTradeAsset(
            predictionTitle,
            predictionId
        );

    if (!assetInfo) {
        showToast(
            'Hourly wallet settlement is currently enabled for Bitcoin and Solana markets.'
        );

        return {
            success: false
        };
    }

    const now = Date.now();
    const marketHourStart =
        memewalletHourStart(now);
    const marketExpiresAt =
        memewalletNextUtcHourStart(now);

    let marketCandle;

    try {
        marketCandle =
            await memewalletGetHourlyCandle(
                assetInfo.symbol,
                marketHourStart
            );
    } catch (error) {
        console.error(
            'MEMEWALLET TRADE MARKET DATA FAILED',
            error
        );

        showToast(
            `Unable to read live ${assetInfo.display} market data. Please try again.`
        );

        return {
            success: false
        };
    }

    const potentialPayout =
        amount *
        (100 / price);

    const shares =
        amount / price;

    const walletRef =
        doc(
            db,
            'users',
            memewalletTradeUser.uid
        );

    const tradeRef =
        doc(
            collection(
                db,
                'users',
                memewalletTradeUser.uid,
                MEMEWALLET_TRADE_SYSTEM.tradesCollection
            )
        );

    try {
        await runTransaction(
            db,
            async transaction => {
                const walletSnapshot =
                    await transaction.get(
                        walletRef
                    );

                if (
                    !walletSnapshot.exists()
                ) {
                    throw new Error(
                        'WALLET_NOT_FOUND'
                    );
                }

                const walletData =
                    walletSnapshot.data();

                const balance =
                    memewalletTradeCurrentBalance(
                        walletData
                    );

                if (
                    balance + 0.00000001 <
                    amount
                ) {
                    throw new Error(
                        `INSUFFICIENT_BALANCE:${balance}`
                    );
                }

                const balanceField =
                    memewalletTradeBalanceField(
                        walletData
                    );

                const newBalance =
                    Math.max(
                        0,
                        balance - amount
                    );

                transaction.update(
                    walletRef,
                    {
                        [balanceField]:
                            newBalance,
                        updatedAt:
                            serverTimestamp()
                    }
                );

                transaction.set(
                    tradeRef,
                    {
                        userId:
                            memewalletTradeUser.uid,
                        userEmail:
                            memewalletTradeUser.email || '',
                        status:
                            MEMEWALLET_TRADE_SYSTEM.tradeStatusOpen,
                        mode,
                        choice,
                        choiceLabel:
                            String(
                                tradeInput?.choiceLabel ||
                                choice
                            ),
                        predictionId,
                        predictionTitle,
                        asset:
                            assetInfo.asset,
                        symbol:
                            assetInfo.symbol,
                        stake:
                            amount,
                        price,
                        fee:
                            Number(tradeInput?.fee || 0),
                        shares,
                        potentialPayout,
                        marketHourStart:
                            Timestamp.fromMillis(
                                marketHourStart
                            ),
                        marketStartPrice:
                            Number(
                                marketCandle.open
                            ),
                        createdAt:
                            serverTimestamp(),
                        expiresAt:
                            Timestamp.fromMillis(
                                marketExpiresAt
                            ),
                        walletBalanceBefore:
                            balance,
                        walletBalanceAfter:
                            newBalance
                    }
                );

                const activityRef =
                    doc(
                        collection(
                            db,
                            'users',
                            memewalletTradeUser.uid,
                            MEMEWALLET_TRADE_SYSTEM.activityCollection
                        )
                    );

                transaction.set(
                    activityRef,
                    {
                        userId:
                            memewalletTradeUser.uid,
                        tradeId:
                            tradeRef.id,
                        type:
                            'prediction_buy',
                        status:
                            'completed',
                        amount:
                            amount,
                        direction:
                            'out',
                        predictionId,
                        predictionTitle,
                        asset:
                            assetInfo.asset,
                        symbol:
                            assetInfo.symbol,
                        choice,
                        choiceLabel:
                            String(
                                tradeInput?.choiceLabel ||
                                choice
                            ),
                        price,
                        shares,
                        createdAt:
                            serverTimestamp()
                    }
                );
            }
        );
    } catch (error) {
        console.error(
            'MEMEWALLET CREATE PREDICTION TRADE FAILED',
            error
        );

        const message =
            String(
                error?.message || ''
            );

        if (
            message.startsWith(
                'INSUFFICIENT_BALANCE:'
            )
        ) {
            const balance =
                Number(
                    message.split(':')[1]
                );

            showToast(
                `Insufficient balance. Available ${formatNaira(balance)}`
            );
        } else if (
            message ===
            'WALLET_NOT_FOUND'
        ) {
            showToast(
                'Wallet account was not found.'
            );
        } else {
            showToast(
                'Trade failed. Your wallet was not charged.'
            );
        }

        return {
            success: false
        };
    }

    showToast(
        `${choice} trade placed. ${formatNaira(amount)} is now on trade until the hour ends.`
    );

    return {
        success: true,
        tradeId: tradeRef.id,
        amount,
        potentialPayout,
        expiresAt: marketExpiresAt
    };
}


window.__memewalletCompletePredictionTrade =
    memewalletCompletePredictionTrade;


async function memewalletSettleOneTrade(
    trade
) {
    if (
        !trade ||
        !memewalletTradeUser
    ) {
        return false;
    }

    const tradeId =
        String(
            trade.id || ''
        );

    if (!tradeId) {
        return false;
    }

    if (
        memewalletTradeSettlementBusy.has(
            tradeId
        )
    ) {
        return false;
    }

    if (
        String(
            trade.status || ''
        ) !==
        MEMEWALLET_TRADE_SYSTEM.tradeStatusOpen
    ) {
        return false;
    }

    const expiresAt =
        memewalletTradeTimestampMillis(
            trade.expiresAt
        );

    if (
        !expiresAt ||
        Date.now() < expiresAt
    ) {
        return false;
    }

    const assetInfo =
        memewalletTradeAsset(
            trade.predictionTitle,
            trade.predictionId
        );

    if (!assetInfo) {
        return false;
    }

    const marketHourStart =
        memewalletTradeTimestampMillis(
            trade.marketHourStart
        ) ||
        Number(trade.marketHourStart || 0);

    if (
        !Number.isFinite(marketHourStart) ||
        marketHourStart <= 0
    ) {
        console.warn(
            'MEMEWALLET TRADE HAS NO MARKET HOUR START',
            tradeId
        );
        return false;
    }

    memewalletTradeSettlementBusy.add(
        tradeId
    );

    try {
        let candle = null;

        try {
            candle =
                await memewalletGetHourlyCandle(
                    assetInfo.symbol,
                    marketHourStart
                );
        } catch (error) {
            console.warn(
                'MEMEWALLET SETTLEMENT MARKET DATA RETRY',
                tradeId,
                error
            );

            return false;
        }

        // Do not settle against a candle that is still open.
        if (
            Date.now() <
            Number(candle.closeTime || 0)
        ) {
            return false;
        }

        const outcome =
            memewalletHourlyOutcome(
                trade.marketStartPrice || candle.open,
                candle.close
            );

        if (!outcome.result) {
            return false;
        }

        const walletRef =
            doc(
                db,
                'users',
                memewalletTradeUser.uid
            );

        const tradeRef =
            doc(
                db,
                'users',
                memewalletTradeUser.uid,
                MEMEWALLET_TRADE_SYSTEM.tradesCollection,
                tradeId
            );

        let settlementResult = null;

        await runTransaction(
            db,
            async transaction => {
                const walletSnapshot =
                    await transaction.get(
                        walletRef
                    );

                const tradeSnapshot =
                    await transaction.get(
                        tradeRef
                    );

                if (
                    !walletSnapshot.exists() ||
                    !tradeSnapshot.exists()
                ) {
                    return;
                }

                const liveTrade =
                    tradeSnapshot.data();

                if (
                    String(
                        liveTrade?.status || ''
                    ) !==
                    MEMEWALLET_TRADE_SYSTEM.tradeStatusOpen
                ) {
                    settlementResult = {
                        alreadySettled: true
                    };
                    return;
                }

                const walletData =
                    walletSnapshot.data();

                const currentBalance =
                    memewalletTradeCurrentBalance(
                        walletData
                    );

                const balanceField =
                    memewalletTradeBalanceField(
                        walletData
                    );

                const selectedChoice =
                    String(
                        liveTrade?.choice || ''
                    );

                const isRefund =
                    outcome.result ===
                    'Refund';

                const isWinner =
                    !isRefund &&
                    selectedChoice ===
                    outcome.result;

                const stake =
                    Number(
                        liveTrade?.stake || 0
                    );

                const potentialPayout =
                    Number(
                        liveTrade?.potentialPayout ||
                        stake *
                            (
                                100 /
                                Number(
                                    liveTrade?.price ||
                                    100
                                )
                            )
                    );

                const payout =
                    isWinner
                        ? Math.max(
                            0,
                            potentialPayout
                        )
                        : isRefund
                            ? Math.max(
                                0,
                                stake
                            )
                            : 0;

                const newBalance =
                    currentBalance +
                    payout;

                const profit =
                    payout -
                    stake;

                transaction.update(
                    tradeRef,
                    {
                        status:
                            MEMEWALLET_TRADE_SYSTEM.tradeStatusSettled,
                        outcome:
                            outcome.result,
                        finalPrice:
                            Number(
                                candle.close
                            ),
                        finalMove:
                            Number(
                                outcome.move
                            ),
                        payout,
                        profit,
                        settledAt:
                            serverTimestamp(),
                        walletBalanceBefore:
                            currentBalance,
                        walletBalanceAfter:
                            newBalance
                    }
                );

                if (
                    payout > 0
                ) {
                    transaction.update(
                        walletRef,
                        {
                            [balanceField]:
                                newBalance,
                            updatedAt:
                                serverTimestamp()
                        }
                    );
                }

                const activityRef =
                    doc(
                        collection(
                            db,
                            'users',
                            memewalletTradeUser.uid,
                            MEMEWALLET_TRADE_SYSTEM.activityCollection
                        )
                    );

                transaction.set(
                    activityRef,
                    {
                        userId:
                            memewalletTradeUser.uid,
                        tradeId,
                        type:
                            isWinner
                                ? 'prediction_win'
                                : isRefund
                                    ? 'prediction_refund'
                                    : 'prediction_loss',
                        status:
                            'completed',
                        amount:
                            payout,
                        direction:
                            payout > 0
                                ? 'in'
                                : 'none',
                        stake,
                        payout,
                        profit,
                        outcome:
                            outcome.result,
                        finalPrice:
                            Number(
                                candle.close
                            ),
                        finalMove:
                            Number(
                                outcome.move
                            ),
                        predictionId:
                            String(
                                liveTrade?.predictionId || ''
                            ),
                        predictionTitle:
                            String(
                                liveTrade?.predictionTitle || ''
                            ),
                        asset:
                            String(
                                liveTrade?.asset ||
                                assetInfo.asset
                            ),
                        symbol:
                            String(
                                liveTrade?.symbol ||
                                assetInfo.symbol
                            ),
                        choice:
                            selectedChoice,
                        choiceLabel:
                            String(
                                liveTrade?.choiceLabel ||
                                selectedChoice
                            ),
                        createdAt:
                            serverTimestamp()
                    }
                );

                settlementResult = {
                    settled: true,
                    isWinner,
                    isRefund,
                    payout,
                    profit,
                    outcome: outcome.result,
                    finalPrice:
                        Number(candle.close)
                };
            }
        );

        if (
            settlementResult?.settled
        ) {
            if (
                settlementResult.isWinner
            ) {
                showToast(
                    `You won ${formatNaira(settlementResult.payout)} on ${trade.choice}.`
                );
            } else if (
                settlementResult.isRefund
            ) {
                showToast(
                    `Hourly market was flat. Your ${formatNaira(settlementResult.payout)} stake was returned.`
                );
            } else {
                showToast(
                    `Hourly ${assetInfo.display} market settled ${settlementResult.outcome}.`
                );
            }
        }

        return Boolean(
            settlementResult?.settled ||
            settlementResult?.alreadySettled
        );
    } finally {
        memewalletTradeSettlementBusy.delete(
            tradeId
        );
    }
}


async function memewalletSettleDueTrades() {
    if (
        !memewalletTradeUser ||
        !memewalletTrades.length
    ) {
        return;
    }

    const dueTrades =
        memewalletTrades.filter(
            trade =>
                String(
                    trade?.status || ''
                ) ===
                MEMEWALLET_TRADE_SYSTEM.tradeStatusOpen &&
                memewalletTradeRemainingMs(trade) <= 0
        );

    for (
        const trade of dueTrades
    ) {
        await memewalletSettleOneTrade(
            trade
        );
    }
}


function memewalletStartTradeListener(
    user
) {
    if (
        memewalletTradeUnsubscribe
    ) {
        memewalletTradeUnsubscribe();
        memewalletTradeUnsubscribe = null;
    }

    if (
        memewalletTradeTimer
    ) {
        clearInterval(
            memewalletTradeTimer
        );
        memewalletTradeTimer = null;
    }

    memewalletTrades = [];
    memewalletTradeSettlementBusy =
        new Set();
    memewalletTradeUser = user || null;
    memewalletRenderTradeUi();

    if (!user) {
        return;
    }

    const tradesRef =
        collection(
            db,
            'users',
            user.uid,
            MEMEWALLET_TRADE_SYSTEM.tradesCollection
        );

    memewalletTradeUnsubscribe =
        onSnapshot(
            tradesRef,
            snapshot => {
                memewalletTrades =
                    snapshot.docs
                        .map(documentSnapshot => ({
                            id:
                                documentSnapshot.id,
                            ...documentSnapshot.data()
                        }))
                        .sort(
                            (a, b) =>
                                (memewalletTradeTimestampMillis(b?.createdAt) || 0) -
                                (memewalletTradeTimestampMillis(a?.createdAt) || 0)
                        );

                memewalletRenderTradeUi();
                memewalletSettleDueTrades();
            },
            error => {
                console.error(
                    'MEMEWALLET TRADE LISTENER ERROR',
                    error
                );
            }
        );

    memewalletTradeTimer =
        setInterval(
            () => {
                memewalletUpdateTradeCountdownUi();
                memewalletSettleDueTrades();
            },
            MEMEWALLET_TRADE_SYSTEM.settlementPollMs
        );
}


onAuthStateChanged(
    auth,
    user => {
        memewalletStartTradeListener(
            user
        );
    }
);


/* Keep the added activity panel responsive to the existing wallet listener. */
setInterval(
    () => {
        memewalletUpdateTradeCountdownUi();

        if (
            memewalletTradeUi
        ) {
            const balance =
                memewalletTradeUi.querySelector(
                    '#memewalletTradeActivityBalance'
                );

            if (
                balance &&
                walletBalance
            ) {
                balance.textContent =
                    walletBalance.textContent ||
                    '₦0.00';
            }
        }
    },
    1000
);


/* ================================================================
   MEMEWALLET V2 ADDITION: FIRESTORE HOURLY MARKET + PREDICTION TRADES
   ----------------------------------------------------------------
   Existing functions above are intentionally left unchanged.

   New V2 behaviour:
     • Reads the current BTC/SOL hourly market from
       hourlyPredictionMarkets/{ASSET}_{YYYY-MM-DD-HH}.
     • Does NOT call Binance when the user buys.
     • Debits the wallet atomically with the V2 prediction position.
     • Stores the stake in users/{uid}/predictionPositionsV2.
     • Settles from the Firestore market record only.
     • Shows open stakes + settled history in the Home > Your predictions
       section.
     • The existing Gmail authentication remains untouched.
================================================================ */

const MEMEWALLET_V2_MARKET_COLLECTION =
    'hourlyPredictionMarkets';

const MEMEWALLET_V2_POSITION_COLLECTION =
    'predictionPositionsV2';

const MEMEWALLET_V2_ACTIVITY_COLLECTION =
    'predictionActivitiesV2';

const MEMEWALLET_V2_OPEN =
    'open';

const MEMEWALLET_V2_SETTLED =
    'settled';

let memewalletV2User = null;
let memewalletV2Positions = [];
let memewalletV2PositionsUnsubscribe = null;
let memewalletV2SettlementBusy = new Set();
let memewalletV2UiRefreshTimer = null;
let memewalletV2MarketCache = new Map();


function memewalletV2AssetInfo(
    title,
    predictionId
) {
    const value =
        `${String(title || '')} ${String(predictionId || '')}`.toLowerCase();

    if (/\bbitcoin\b|\bbtc\b/.test(value)) {
        return {
            asset: 'BTC',
            symbol: 'BTCUSDT',
            name: 'Bitcoin'
        };
    }

    if (/\bsolana\b|\bsol\b/.test(value)) {
        return {
            asset: 'SOL',
            symbol: 'SOLUSDT',
            name: 'Solana'
        };
    }

    return null;
}


function memewalletV2HourStart(
    timestamp = Date.now()
) {
    const d = new Date(timestamp);

    return Date.UTC(
        d.getUTCFullYear(),
        d.getUTCMonth(),
        d.getUTCDate(),
        d.getUTCHours(),
        0,
        0,
        0
    );
}


function memewalletV2HourKey(
    timestamp = Date.now()
) {
    const d = new Date(timestamp);

    return [
        d.getUTCFullYear(),
        String(d.getUTCMonth() + 1).padStart(2, '0'),
        String(d.getUTCDate()).padStart(2, '0'),
        String(d.getUTCHours()).padStart(2, '0')
    ].join('-');
}


function memewalletV2MarketId(
    asset,
    hourStartMs
) {
    return `${String(asset || '').toUpperCase()}_${memewalletV2HourKey(hourStartMs)}`;
}


function memewalletV2TimestampMs(
    value
) {
    try {
        if (!value) {
            return 0;
        }

        if (typeof value.toMillis === 'function') {
            return value.toMillis();
        }

        if (value instanceof Date) {
            return value.getTime();
        }

        if (typeof value === 'number') {
            return value;
        }

        if (typeof value === 'string') {
            const parsed = Date.parse(value);
            return Number.isFinite(parsed) ? parsed : 0;
        }

        return 0;
    } catch {
        return 0;
    }
}


function memewalletV2CurrentBalance(
    userData
) {
    const fields = [
        'cashBalance',
        'walletBalance',
        'balance',
        'availableBalance'
    ];

    for (const field of fields) {
        const value = Number(userData?.[field]);

        if (Number.isFinite(value)) {
            return Math.max(0, value);
        }
    }

    return 0;
}


function memewalletV2BalanceField(
    userData
) {
    const fields = [
        'cashBalance',
        'walletBalance',
        'balance',
        'availableBalance'
    ];

    for (const field of fields) {
        if (typeof userData?.[field] === 'number') {
            return field;
        }
    }

    return 'cashBalance';
}


function memewalletV2FormatCountdown(
    milliseconds,
    options = {}
) {
    const totalSeconds =
        Math.max(
            0,
            Math.floor(
                Number(milliseconds || 0) / 1000
            )
        );

    // Hourly BTC/SOL markets keep the compact clock format.
    if (options?.hourly === true) {
        const hours =
            Math.floor(totalSeconds / 3600);

        const minutes =
            Math.floor((totalSeconds % 3600) / 60);

        const seconds =
            totalSeconds % 60;

        return (
            `${String(hours).padStart(2, '0')}:` +
            `${String(minutes).padStart(2, '0')}:` +
            `${String(seconds).padStart(2, '0')}`
        );
    }

    if (totalSeconds <= 0) {
        return 'Ended';
    }

    const totalMinutes =
        Math.max(
            1,
            Math.ceil(totalSeconds / 60)
        );

    const days =
        Math.floor(totalMinutes / 1440);

    const hours =
        Math.floor((totalMinutes % 1440) / 60);

    const minutes =
        totalMinutes % 60;

    const parts = [];

    if (days > 0) {
        parts.push(
            `${days} ${days === 1 ? 'day' : 'days'}`
        );
    }

    if (hours > 0) {
        parts.push(
            `${hours} ${hours === 1 ? 'hour' : 'hours'}`
        );
    }

    if (days === 0 && minutes > 0) {
        parts.push(
            `${minutes} ${minutes === 1 ? 'minute' : 'minutes'}`
        );
    }

    return parts.join(' ') || 'less than 1 minute';
}


function memewalletV2PositionIsHourly(position) {
    const explicit =
        position?.isHourly ??
        position?.hourly ??
        position?.isHourlyMarket;

    if (typeof explicit === 'boolean') {
        return explicit;
    }

    const marketType =
        String(
            position?.marketType ||
            position?.timeframe ||
            position?.durationLabel ||
            ''
        ).toLowerCase();

    if (marketType.includes('hour')) {
        return true;
    }

    return Boolean(
        position?.marketHourStart ||
        position?.marketHourEnd
    );
}


function memewalletV2Escape(
    value
) {
    if (typeof escapeHtml === 'function') {
        return escapeHtml(value);
    }

    return String(value ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}


function memewalletV2MarketForAsset(
    asset
) {
    const key =
        String(asset || '').toUpperCase();

    return (
        memewalletV2MarketCache.get(key) ||
        null
    );
}


function memewalletV2PredictionLabels(
    position
) {
    const choice =
        String(position?.choice || 'Yes') === 'No'
            ? 'No'
            : 'Yes';

    const asset =
        String(position?.asset || '');

    if (asset === 'BTC' || asset === 'SOL') {
        return choice === 'Yes'
            ? 'UP'
            : 'DOWN';
    }

    return choice;
}


function memewalletV2RenderPredictionSection() {
    const container =
        document.getElementById(
            'memewalletV2PredictionPortfolio'
        );

    if (!container) {
        return;
    }

    const currentBalance =
        document.getElementById(
            'walletBalance'
        )?.textContent ||
        '₦0.00';

    const openPositions =
        memewalletV2Positions
            .filter(
                position =>
                    String(position?.status || '') ===
                    MEMEWALLET_V2_OPEN
            )
            .sort(
                (a, b) =>
                    (
                        memewalletV2TimestampMs(
                            a?.createdAt
                        ) || 0
                    ) -
                    (
                        memewalletV2TimestampMs(
                            b?.createdAt
                        ) || 0
                    )
            );

    const settledPositions =
        memewalletV2Positions
            .filter(
                position =>
                    String(position?.status || '') ===
                    MEMEWALLET_V2_SETTLED
            )
            .sort(
                (a, b) =>
                    (
                        memewalletV2TimestampMs(
                            b?.settledAt ||
                            b?.createdAt
                        ) || 0
                    ) -
                    (
                        memewalletV2TimestampMs(
                            a?.settledAt ||
                            a?.createdAt
                        ) || 0
                    )
            )
            .slice(
                0,
                20
            );

    const openHtml =
        openPositions.length
            ? `
                <div class="space-y-2">
                    ${openPositions.map(position => {
                        const stake =
                            Number(position?.stake || 0);

                        const potential =
                            Number(
                                position?.potentialPayout ||
                                0
                            );

                        const expiresAt =
                            memewalletV2TimestampMs(
                                position?.expiresAt
                            );

                        const remaining =
                            Math.max(
                                0,
                                expiresAt - Date.now()
                            );

                        const label =
                            memewalletV2PredictionLabels(
                                position
                            );

                        return `
                            <div
                                class="rounded-[17px] border border-[#eeeeec] px-4 py-3"
                                data-memewallet-v2-position="${memewalletV2Escape(position?.id || '')}"
                                data-memewallet-v2-detail-id="${memewalletV2Escape(position?.id || '')}"
                                role="button"
                                tabindex="0"
                            >
                                <div class="flex items-start justify-between gap-3">
                                    <div class="min-w-0">
                                        <div class="truncate text-[12px] font-semibold text-[#171717]">
                                            ${memewalletV2Escape(label)} · ${memewalletV2Escape(position?.asset || '')}
                                        </div>

                                        <div class="mt-1 truncate text-[10px] text-[#858585]">
                                            ${memewalletV2Escape(position?.predictionTitle || 'Hourly prediction')}
                                        </div>
                                    </div>

                                    <span class="shrink-0 rounded-full bg-[#fff7e6] px-2 py-1 text-[9px] font-semibold text-[#a66a00]">
                                        On trade
                                    </span>
                                </div>

                                <div class="mt-3 grid grid-cols-3 gap-2 text-[10px]">
                                    <div>
                                        <span class="block text-[#999999]">Staked</span>
                                        <strong class="mt-0.5 block text-[11px] text-[#171717]">
                                            ${memewalletV2Escape(formatNaira(stake))}
                                        </strong>
                                    </div>

                                    <div>
                                        <span class="block text-[#999999]">Potential</span>
                                        <strong class="mt-0.5 block text-[11px] text-[#171717]">
                                            ${memewalletV2Escape(formatNaira(potential))}
                                        </strong>
                                    </div>

                                    <div class="text-right">
                                        <span class="block text-[#999999]">Ends in</span>
                                        <strong
                                            class="mt-0.5 block text-[11px] text-[#171717]"
                                            data-memewallet-v2-countdown="${memewalletV2Escape(position?.id || '')}"
                                        >
                                            ${memewalletV2FormatCountdown(remaining, { hourly: memewalletV2PositionIsHourly(position) })}
                                        </strong>
                                    </div>
                                </div>

                                <div class="mt-2 text-[9px] text-[#999999]">
                                    Price ${Number(position?.price || 0).toFixed(0)}% · ${Number(position?.shares || 0).toFixed(6)} shares
                                </div>
                            </div>
                        `;
                    }).join('')}
                </div>
            `
            : `
                <div class="rounded-[16px] bg-[#f7f7f5] px-4 py-3 text-[10px] leading-5 text-[#858585]">
                    No active positions. Your stake will appear here immediately after a prediction is bought.
                </div>
            `;

    const historyHtml =
        settledPositions.length
            ? `
                <div class="mt-4 border-t border-[#eeeeec] pt-3">
                    <div class="mb-2 text-[10px] font-semibold uppercase tracking-[0.08em] text-[#9a9a98]">
                        Settlement history
                    </div>

                    <div class="space-y-2">
                        ${settledPositions.map(position => {
                            const payout =
                                Number(position?.payout || 0);

                            const stake =
                                Number(position?.stake || 0);

                            const profit =
                                Number(
                                    position?.profit ??
                                    (payout - stake)
                                );

                            const outcome =
                                String(
                                    position?.outcome || '—'
                                );

                            const won =
                                outcome ===
                                String(position?.choice || '');

                            return `
                                <div
                                    class="flex cursor-pointer items-center justify-between gap-3 rounded-[15px] bg-[#f7f7f5] px-4 py-3 transition hover:bg-[#f1f1ef]"
                                    data-memewallet-v2-detail-id="${memewalletV2Escape(position?.id || '')}"
                                    role="button"
                                    tabindex="0"
                                >
                                    <div class="min-w-0">
                                        <div class="truncate text-[11px] font-semibold">
                                            ${memewalletV2Escape(memewalletV2PredictionLabels(position))} · ${memewalletV2Escape(position?.asset || '')}
                                        </div>
                                        <div class="mt-1 truncate text-[9px] text-[#858585]">
                                            ${memewalletV2Escape(position?.predictionTitle || 'Hourly prediction')}
                                        </div>
                                    </div>

                                    <div class="shrink-0 text-right">
                                        <div class="text-[9px] ${won ? 'text-[#18794e]' : profit === 0 ? 'text-[#858585]' : 'text-[#b54c00]'}">
                                            ${memewalletV2Escape(outcome)}
                                        </div>

                                        <strong class="mt-0.5 block text-[11px]">
                                            ${memewalletV2Escape(formatNaira(payout))}
                                        </strong>

                                        <span class="text-[9px] ${profit >= 0 ? 'text-[#18794e]' : 'text-[#b54c00]'}">
                                            ${profit >= 0 ? '+' : ''}${memewalletV2Escape(formatNaira(profit))}
                                        </span>
                                    </div>
                                </div>
                            `;
                        }).join('')}
                    </div>
                </div>
            `
            : '';

    container.innerHTML = `
        <div class="rounded-[18px] border border-black/[0.04] bg-white">
            <div class="flex items-center justify-between gap-3 px-4 pt-4">
                <div>
                    <div class="text-[12px] font-semibold tracking-[-0.02em]">
                        Prediction trade
                    </div>

                    <div class="mt-0.5 text-[9px] text-[#858585]">
                        Hourly BTC/SOL positions are locked until settlement.
                    </div>
                </div>

                <div class="text-right">
                    <div class="text-[8px] text-[#999999]">Available</div>
                    <strong class="text-[11px] font-semibold">
                        ${memewalletV2Escape(currentBalance)}
                    </strong>
                </div>
            </div>

            <div class="px-4 pb-4 pt-3">
                ${openHtml}
                ${historyHtml}
            </div>
        </div>
    `;
}


function memewalletV2UpdateCountdowns() {
    document
        .querySelectorAll(
            '[data-memewallet-v2-countdown]'
        )
        .forEach(
            element => {
                const id =
                    String(
                        element.dataset.memewalletV2Countdown ||
                        ''
                    );

                const position =
                    memewalletV2Positions.find(
                        item =>
                            String(item?.id || '') === id
                    );

                if (!position) {
                    return;
                }

                const expiresAt =
                    memewalletV2TimestampMs(
                        position?.expiresAt
                    );

                element.textContent =
                    memewalletV2FormatCountdown(
                        Math.max(
                            0,
                            expiresAt - Date.now()
                        ),
                        { hourly: memewalletV2PositionIsHourly(position) }
                    );
            }
        );
}


function memewalletV2EnsurePortfolioUi() {
    let container =
        document.getElementById(
            'memewalletV2PredictionPortfolio'
        );

    if (container) {
        return container;
    }

    const homeSection =
        document.querySelector(
            '#page-home .home-your-predictions'
        );

    if (!homeSection) {
        return null;
    }

    container =
        document.createElement(
            'div'
        );

    container.id =
        'memewalletV2PredictionPortfolio';

    container.className =
        'mt-4';

    homeSection.appendChild(
        container
    );

    return container;
}


async function memewalletV2CompletePredictionTrade(
    tradeInput
) {
    const user =
        memewalletV2User ||
        currentUser;

    if (!user) {
        showToast(
            'Please log in again before trading.'
        );

        return {
            success: false
        };
    }

    const amount =
        Number(
            tradeInput?.amount
        );

    const mode =
        String(
            tradeInput?.mode || 'Buy'
        ) === 'Sell'
            ? 'Sell'
            : 'Buy';

    if (mode !== 'Buy') {
        showToast(
            'Selling is not enabled for the hourly prediction trade system.'
        );

        return {
            success: false
        };
    }

    if (!Number.isFinite(amount) || amount <= 0) {
        showToast(
            'Enter a valid trade amount.'
        );

        return {
            success: false
        };
    }

    const choice =
        String(
            tradeInput?.choice || 'Yes'
        ) === 'No'
            ? 'No'
            : 'Yes';

    const predictionId =
        String(
            tradeInput?.predictionId || ''
        );

    const predictionTitle =
        String(
            tradeInput?.predictionTitle ||
            'Hourly prediction'
        );

    const assetInfo =
        memewalletV2AssetInfo(
            predictionTitle,
            predictionId
        );

    if (!assetInfo) {
        showToast(
            'Only Bitcoin and Solana hourly predictions can use the new stake system.'
        );

        return {
            success: false
        };
    }

    const now =
        Date.now();

    const hourStart =
        memewalletV2HourStart(
            now
        );

    const hourEnd =
        hourStart +
        3600000;

    const marketId =
        memewalletV2MarketId(
            assetInfo.asset,
            hourStart
        );

    const marketRef =
        doc(
            db,
            MEMEWALLET_V2_MARKET_COLLECTION,
            marketId
        );

    const walletRef =
        doc(
            db,
            'users',
            user.uid
        );

    const positionRef =
        doc(
            collection(
                db,
                'users',
                user.uid,
                MEMEWALLET_V2_POSITION_COLLECTION
            )
        );

    const activityRef =
        doc(
            collection(
                db,
                'users',
                user.uid,
                MEMEWALLET_V2_ACTIVITY_COLLECTION
            )
        );

    let resultData = null;

    try {
        await runTransaction(
            db,
            async transaction => {
                // Reads come first. The market record is the only source of
                // the current share price for this transaction.
                const [
                    marketSnapshot,
                    walletSnapshot
                ] = await Promise.all([
                    transaction.get(marketRef),
                    transaction.get(walletRef)
                ]);

                if (!marketSnapshot.exists()) {
                    throw new Error(
                        'HOURLY_MARKET_NOT_FOUND'
                    );
                }

                if (!walletSnapshot.exists()) {
                    throw new Error(
                        'WALLET_NOT_FOUND'
                    );
                }

                const market =
                    marketSnapshot.data();

                const marketHourStart =
                    Number(
                        market?.hourStartMs ||
                        memewalletV2TimestampMs(
                            market?.hourStart
                        ) ||
                        0
                    );

                if (
                    marketHourStart !==
                    hourStart
                ) {
                    throw new Error(
                        'HOURLY_MARKET_MISMATCH'
                    );
                }

                const marketStatus =
                    String(
                        market?.status || ''
                    ).toLowerCase();

                if (
                    marketStatus !== 'open'
                ) {
                    throw new Error(
                        'HOURLY_MARKET_CLOSED'
                    );
                }

                if (
                    Date.now() >=
                    hourEnd
                ) {
                    throw new Error(
                        'HOURLY_MARKET_EXPIRED'
                    );
                }

                const yesPrice =
                    Number(
                        market?.yesPrice ??
                        market?.yes ??
                        50
                    );

                const noPrice =
                    Number(
                        market?.noPrice ??
                        market?.no ??
                        50
                    );

                const selectedPrice =
                    choice === 'Yes'
                        ? yesPrice
                        : noPrice;

                if (
                    !Number.isFinite(selectedPrice) ||
                    selectedPrice <= 0 ||
                    selectedPrice > 100
                ) {
                    throw new Error(
                        'HOURLY_MARKET_PRICE_INVALID'
                    );
                }

                const walletData =
                    walletSnapshot.data();

                const currentBalance =
                    memewalletV2CurrentBalance(
                        walletData
                    );

                if (
                    currentBalance + 0.00000001 <
                    amount
                ) {
                    throw new Error(
                        `INSUFFICIENT_BALANCE:${currentBalance}`
                    );
                }

                const balanceField =
                    memewalletV2BalanceField(
                        walletData
                    );

                const newBalance =
                    Math.max(
                        0,
                        currentBalance - amount
                    );

                const shares =
                    amount /
                    selectedPrice;

                const potentialPayout =
                    shares * 100;

                /*
                 * Keep a real traded-volume counter on the hourly market.
                 * This is the total stake traded on this market across
                 * signed-in users, not a fake/static HTML volume value.
                 */
                const existingMarketVolume =
                    Number(
                        market?.volume ??
                        market?.tradedVolume ??
                        0
                    );

                const nextMarketVolume =
                    (Number.isFinite(existingMarketVolume)
                        ? Math.max(0, existingMarketVolume)
                        : 0) +
                    amount;

                if (selectedMarket.ref) {
                    transaction.update(
                        selectedMarket.ref,
                        {
                            volume:
                                nextMarketVolume,
                            tradedVolume:
                                nextMarketVolume,
                            updatedAt:
                                serverTimestamp()
                        }
                    );
                }

                transaction.update(
                    walletRef,
                    {
                        [balanceField]:
                            newBalance,
                        ...memewalletFinalHotfixPredictionAuditFields(
                            positionRef.id,
                            'buy'
                        )
                    }
                );

                transaction.set(
                    positionRef,
                    {
                        userId:
                            user.uid,
                        userEmail:
                            user.email || '',
                        status:
                            MEMEWALLET_V2_OPEN,
                        mode:
                            'Buy',
                        choice,
                        choiceLabel:
                            String(
                                tradeInput?.choiceLabel ||
                                choice
                            ),
                        predictionId,
                        predictionTitle,
                        asset:
                            assetInfo.asset,
                        symbol:
                            assetInfo.symbol,
                        marketId,
                        marketHourStart:
                            Timestamp.fromMillis(
                                hourStart
                            ),
                        marketHourEnd:
                            Timestamp.fromMillis(
                                hourEnd
                            ),
                        stake:
                            amount,
                        price:
                            selectedPrice,
                        shares,
                        potentialPayout,
                        walletBalanceBefore:
                            currentBalance,
                        walletBalanceAfter:
                            newBalance,
                        createdAt:
                            serverTimestamp(),
                        expiresAt:
                            Timestamp.fromMillis(
                                hourEnd
                            )
                    }
                );

                transaction.set(
                    activityRef,
                    {
                        userId:
                            user.uid,
                        positionId:
                            positionRef.id,
                        type:
                            'prediction_buy',
                        status:
                            'completed',
                        direction:
                            'out',
                        amount:
                            amount,
                        stake:
                            amount,
                        price:
                            selectedPrice,
                        shares,
                        potentialPayout,
                        predictionId,
                        predictionTitle,
                        asset:
                            assetInfo.asset,
                        symbol:
                            assetInfo.symbol,
                        choice,
                        createdAt:
                            serverTimestamp()
                    }
                );

                resultData = {
                    id:
                        positionRef.id,
                    amount,
                    selectedPrice,
                    potentialPayout,
                    expiresAt:
                        hourEnd
                };
            }
        );
    } catch (error) {
        console.error(
            'MEMEWALLET V2 PREDICTION BUY FAILED',
            error
        );

        const message =
            String(
                error?.message || ''
            );

        if (
            message.startsWith(
                'INSUFFICIENT_BALANCE:'
            )
        ) {
            const currentBalance =
                Number(
                    message.split(':')[1]
                );

            showToast(
                `Insufficient balance. Available ${formatNaira(currentBalance)}`
            );
        } else if (
            message === 'HOURLY_MARKET_NOT_FOUND'
        ) {
            showToast(
                'This hourly market has not been published yet. Please try again in a moment.'
            );
        } else if (
            message === 'HOURLY_MARKET_CLOSED' ||
            message === 'HOURLY_MARKET_EXPIRED'
        ) {
            showToast(
                'This hourly market has already closed.'
            );
        } else if (
            message === 'HOURLY_MARKET_MISMATCH'
        ) {
            showToast(
                'The hourly market changed. Please open the prediction again.'
            );
        } else if (
            message === 'HOURLY_MARKET_PRICE_INVALID'
        ) {
            showToast(
                'No valid odds are available for this hourly market.'
            );
        } else if (
            message === 'WALLET_NOT_FOUND'
        ) {
            showToast(
                'Wallet account was not found.'
            );
        } else {
            showToast(
                'Prediction trade failed. Your wallet was not charged.'
            );
        }

        return {
            success: false
        };
    }

    showToast(
        `${choice} trade placed. ${formatNaira(amount)} is now on trade until the hour ends.`
    );

    memewalletV2RenderPredictionSection();

    return {
        success: true,
        tradeId:
            resultData.id,
        amount:
            resultData.amount,
        potentialPayout:
            resultData.potentialPayout,
        expiresAt:
            resultData.expiresAt,
        source:
            'firestore-hourly-market'
    };
}


/*
   Existing trade-drawer code already calls this global callback.
   The original implementation above is not edited; this V2 callback
   becomes the additive Firestore-only bridge used by the existing UI.
*/
window.__memewalletCompletePredictionTrade =
    memewalletV2CompletePredictionTrade;



async function memewalletV2SettlePosition(
    position
) {
    if (
        !memewalletV2User ||
        !position
    ) {
        return false;
    }

    const positionId =
        String(position?.id || '');

    const marketId =
        String(position?.marketId || '');

    if (!positionId || !marketId) {
        return false;
    }

    if (
        memewalletV2SettlementBusy.has(
            positionId
        )
    ) {
        return false;
    }

    if (
        String(position?.status || '') !==
        MEMEWALLET_V2_OPEN
    ) {
        return false;
    }

    const expiresAt =
        memewalletV2TimestampMs(
            position?.expiresAt
        );

    if (
        !expiresAt ||
        Date.now() < expiresAt
    ) {
        return false;
    }

    const marketRef =
        doc(
            db,
            MEMEWALLET_V2_MARKET_COLLECTION,
            marketId
        );

    const walletRef =
        doc(
            db,
            'users',
            memewalletV2User.uid
        );

    const positionRef =
        doc(
            db,
            'users',
            memewalletV2User.uid,
            MEMEWALLET_V2_POSITION_COLLECTION,
            positionId
        );

    const activityRef =
        doc(
            collection(
                db,
                'users',
                memewalletV2User.uid,
                MEMEWALLET_V2_ACTIVITY_COLLECTION
            )
        );

    const walletTransactionRef =
        doc(
            collection(
                db,
                'users',
                memewalletV2User.uid,
                'transactions'
            )
        );

    let settlementData = null;

    memewalletV2SettlementBusy.add(
        positionId
    );

    try {
        /*
         * IMPORTANT:
         * Do not depend only on the background publisher.
         * If the hourly market was not marked settled, settle it here
         * first once the hour has ended.
         */
        await memewalletReliableEnsureMarketSettled(
            marketId
        );

        await runTransaction(
            db,
            async transaction => {

                const [
                    marketSnapshot,
                    walletSnapshot,
                    positionSnapshot
                ] = await Promise.all([
                    transaction.get(
                        marketRef
                    ),
                    transaction.get(
                        walletRef
                    ),
                    transaction.get(
                        positionRef
                    )
                ]);

                if (
                    !marketSnapshot.exists() ||
                    !walletSnapshot.exists() ||
                    !positionSnapshot.exists()
                ) {
                    return;
                }

                const livePosition =
                    positionSnapshot.data() || {};

                if (
                    String(
                        livePosition?.status || ''
                    ) !==
                    MEMEWALLET_V2_OPEN
                ) {
                    settlementData = {
                        alreadySettled: true
                    };

                    return;
                }

                const market =
                    marketSnapshot.data() || {};

                const marketStatus =
                    String(
                        market?.status || ''
                    ).toLowerCase();

                if (
                    marketStatus !==
                    'settled'
                ) {
                    return;
                }

                const outcome =
                    String(
                        market?.outcome || ''
                    );

                if (
                    outcome !== 'Yes' &&
                    outcome !== 'No' &&
                    outcome !== 'Refund'
                ) {
                    return;
                }

                const stake =
                    Number(
                        livePosition?.stake || 0
                    );

                if (
                    !Number.isFinite(stake) ||
                    stake <= 0
                ) {
                    return;
                }

                const selectedChoice =
                    String(
                        livePosition?.choice || ''
                    );

                const isRefund =
                    outcome === 'Refund';

                const isWinner =
                    !isRefund &&
                    selectedChoice === outcome;

                const storedPayout =
                    Number(
                        livePosition?.potentialPayout || 0
                    );

                const payout =
                    isWinner
                        ? Math.max(
                            0,
                            storedPayout
                        )
                        : isRefund
                            ? stake
                            : 0;

                /*
                 * The BUY path has the tolerant balance helpers.
                 * Use the exact same helpers here so a wallet field
                 * stored as a numeric string is still credited correctly.
                 */
                const walletData =
                    walletSnapshot.data() || {};

                const balanceField =
                    memewalletFinalHotfixBalanceField(
                        walletData
                    );

                const currentBalance =
                    memewalletFinalHotfixBalance(
                        walletData
                    );

                const newBalance =
                    Math.max(
                        0,
                        currentBalance + payout
                    );

                const profit =
                    payout - stake;

                /*
                 * Close the position exactly once.
                 */
                transaction.update(
                    positionRef,
                    {
                        status:
                            MEMEWALLET_V2_SETTLED,

                        outcome,

                        marketOutcome:
                            outcome,

                        finalPrice:
                            Number(
                                market?.finalPrice ||
                                market?.currentPrice ||
                                0
                            ),

                        finalMovePercent:
                            Number(
                                market?.movePercent ||
                                0
                            ),

                        payout,

                        profit,

                        settledAt:
                            serverTimestamp(),

                        walletBalanceBefore:
                            currentBalance,

                        walletBalanceAfter:
                            newBalance
                    }
                );

                /*
                 * LOSS:
                 * payout is 0, therefore the already withdrawn
                 * stake remains out of the wallet.
                 *
                 * WIN/REFUND:
                 * payout is added back to the wallet.
                 */
                if (
                    payout > 0
                ) {
                    transaction.update(
                        walletRef,
                        {
                            [balanceField]:
                                newBalance,

                            lastPredictionPositionId:
                                positionId,

                            lastPredictionAction:
                                'settle'
                        }
                    );
                } else {
                    transaction.update(
                        walletRef,
                        {
                            lastPredictionPositionId:
                                positionId,

                            lastPredictionAction:
                                'settle'
                        }
                    );
                }

                /*
                 * Prediction activity record.
                 */
                transaction.set(
                    activityRef,
                    {
                        userId:
                            memewalletV2User.uid,

                        positionId,

                        type:
                            isWinner
                                ? 'prediction_win'
                                : isRefund
                                    ? 'prediction_refund'
                                    : 'prediction_loss',

                        status:
                            'completed',

                        direction:
                            payout > 0
                                ? 'in'
                                : 'none',

                        amount:
                            payout,

                        stake,

                        payout,

                        profit,

                        outcome,

                        predictionId:
                            String(
                                livePosition?.predictionId ||
                                ''
                            ),

                        predictionTitle:
                            String(
                                livePosition?.predictionTitle ||
                                ''
                            ),

                        asset:
                            String(
                                livePosition?.asset ||
                                ''
                            ),

                        symbol:
                            String(
                                livePosition?.symbol ||
                                ''
                            ),

                        choice:
                            selectedChoice,

                        createdAt:
                            serverTimestamp()
                    }
                );

                /*
                 * Also create a normal wallet transaction record.
                 * This lets prediction settlement appear alongside
                 * ordinary wallet transactions.
                 */
                transaction.set(
                    walletTransactionRef,
                    {
                        userId:
                            memewalletV2User.uid,

                        type:
                            isWinner
                                ? 'prediction_win'
                                : isRefund
                                    ? 'prediction_refund'
                                    : 'prediction_loss',

                        status:
                            'completed',

                        direction:
                            payout > 0
                                ? 'in'
                                : 'none',

                        amount:
                            payout,

                        stake,

                        payout,

                        profit,

                        outcome,

                        positionId,

                        predictionId:
                            String(
                                livePosition?.predictionId ||
                                ''
                            ),

                        predictionTitle:
                            String(
                                livePosition?.predictionTitle ||
                                ''
                            ),

                        asset:
                            String(
                                livePosition?.asset ||
                                ''
                            ),

                        symbol:
                            String(
                                livePosition?.symbol ||
                                ''
                            ),

                        choice:
                            selectedChoice,

                        createdAt:
                            serverTimestamp()
                    }
                );

                settlementData = {
                    settled:
                        true,

                    isWinner,

                    isRefund,

                    payout,

                    profit,

                    outcome,

                    positionId
                };
            }
        );

        if (
            settlementData?.settled
        ) {
            if (
                settlementData.isWinner
            ) {
                showToast(
                    `You won ${formatNaira(settlementData.profit)}. ${formatNaira(settlementData.payout)} has been returned to your wallet.`
                );
            } else if (
                settlementData.isRefund
            ) {
                showToast(
                    `Your ${formatNaira(settlementData.payout)} stake was returned.`
                );
            } else {
                showToast(
                    `Prediction lost. Your ${formatNaira(
                        Number(position?.stake || 0)
                    )} stake remains withdrawn.`
                );
            }
        }

        return Boolean(
            settlementData?.settled ||
            settlementData?.alreadySettled
        );

    } catch (error) {

        console.error(
            'MEMEWALLET V2 SETTLEMENT FAILED',
            positionId,
            error
        );

        return false;

    } finally {

        memewalletV2SettlementBusy.delete(
            positionId
        );
    }
}


async function memewalletV2SettleDuePositions() {
    if (
        !memewalletV2User ||
        !memewalletV2Positions.length
    ) {
        return;
    }

    const due =
        memewalletV2Positions.filter(
            position =>
                String(position?.status || '') ===
                MEMEWALLET_V2_OPEN &&
                memewalletV2TimestampMs(
                    position?.expiresAt
                ) > 0 &&
                Date.now() >=
                memewalletV2TimestampMs(
                    position?.expiresAt
                )
        );

    for (const position of due) {
        await memewalletV2SettlePosition(
            position
        );
    }
}


function memewalletV2StartPositionListener(
    user
) {
    if (
        memewalletV2PositionsUnsubscribe
    ) {
        memewalletV2PositionsUnsubscribe();
        memewalletV2PositionsUnsubscribe = null;
    }

    if (
        memewalletV2UiRefreshTimer
    ) {
        clearInterval(
            memewalletV2UiRefreshTimer
        );
        memewalletV2UiRefreshTimer = null;
    }

    memewalletV2User =
        user || null;

    memewalletV2Positions =
        [];

    memewalletV2SettlementBusy =
        new Set();

    memewalletV2EnsurePortfolioUi();
    memewalletV2RenderPredictionSection();

    if (!user) {
        return;
    }

    const positionsRef =
        collection(
            db,
            'users',
            user.uid,
            MEMEWALLET_V2_POSITION_COLLECTION
        );

    memewalletV2PositionsUnsubscribe =
        onSnapshot(
            positionsRef,
            snapshot => {
                memewalletV2Positions =
                    snapshot.docs
                        .map(
                            item => ({
                                id:
                                    item.id,
                                ...item.data()
                            })
                        );

                memewalletV2RenderPredictionSection();

                memewalletV2SettleDuePositions();
            },
            error => {
                console.error(
                    'MEMEWALLET V2 POSITION LISTENER ERROR',
                    error
                );
            }
        );

    memewalletV2UiRefreshTimer =
        setInterval(
            () => {
                memewalletV2UpdateCountdowns();
                memewalletV2SettleDuePositions();
            },
            1000
        );
}


function memewalletV2StartMarketCacheListener() {
    /*
       This listener is intentionally scoped to the two current hourly
       records only. The trade path itself uses a direct transaction read
       of its exact Firestore market document.
    */
    const assets = [
        'BTC',
        'SOL'
    ];

    assets.forEach(
        asset => {
            const refreshMarketCache = () => {
                const hourStart =
                    memewalletV2HourStart(
                        Date.now()
                    );

                const marketId =
                    memewalletV2MarketId(
                        asset,
                        hourStart
                    );

                const marketRef =
                    doc(
                        db,
                        MEMEWALLET_V2_MARKET_COLLECTION,
                        marketId
                    );

                return onSnapshot(
                    marketRef,
                    snapshot => {
                        if (snapshot.exists()) {
                            memewalletV2MarketCache.set(
                                asset,
                                {
                                    id:
                                        snapshot.id,
                                    ...snapshot.data()
                                }
                            );
                        } else {
                            memewalletV2MarketCache.delete(
                                asset
                            );
                        }

                        memewalletV2RenderPredictionSection();
                    },
                    error => {
                        console.warn(
                            'MEMEWALLET V2 MARKET CACHE ERROR',
                            asset,
                            error
                        );
                    }
                );
            };

            /*
               Fire-and-forget current record cache. It is only for UI
               convenience; buy/settlement still use Firestore transactions.
            */
            refreshMarketCache();
        }
    );
}


onAuthStateChanged(
    auth,
    user => {
        memewalletV2StartPositionListener(
            user
        );
        memewalletV2EnsurePortfolioUi();
        memewalletV2RenderPredictionSection();
    }
);

memewalletV2EnsurePortfolioUi();

memewalletV2StartMarketCacheListener();

setInterval(
    () => {
        memewalletV2UpdateCountdowns();
    },
    1000
);

/* =====================================================================
   MEMEWALLET FINAL ADDITIVE HOTFIX
   ---------------------------------------------------------------------
   Nothing above is removed. This block is intentionally appended so the
   existing UI/functions keep their names while the final global trade
   bridge becomes more tolerant of the actual Firestore hourly records.

   Fixes:
     1. Buy Yes/No uses the current Firestore hourly BTC/SOL record.
     2. Supports UTC and Africa/Lagos hourly document keys.
     3. Accepts common hourly Firestore field-name variants.
     4. Detects the real wallet balance field even when stored as a string.
     5. Performs wallet debit + position + activity in ONE transaction.
     6. Adds detailed error diagnostics without exposing internal errors to UI.
     7. Keeps a Google/Gmail sign-in helper available for pages/buttons that
        already use this Firebase project.
===================================================================== */

const MEMEWALLET_FINAL_HOTFIX_VERSION = '2026-09-30-prediction-wallet-gmail';


/* -------------------------- GMAIL / GOOGLE --------------------------- */

async function memewalletConfigureGooglePersistence() {
    try {
        await setPersistence(
            auth,
            browserLocalPersistence
        );
    } catch (error) {
        console.warn(
            'MEMEWALLET GOOGLE AUTH PERSISTENCE SETUP FAILED',
            error
        );
    }
}


async function memewalletFinishGoogleRedirect() {
    try {
        await getRedirectResult(auth);
    } catch (error) {
        console.error(
            'MEMEWALLET GOOGLE REDIRECT RESULT FAILED',
            error
        );

        const code = String(error?.code || '');

        if (code === 'auth/unauthorized-domain') {
            showToast(
                'Google sign-in is not enabled for this website domain.'
            );
        }
    }
}


async function memewalletSignInWithGoogle() {
    const provider =
        new GoogleAuthProvider();

    provider.setCustomParameters({
        prompt: 'select_account'
    });

    try {
        await memewalletConfigureGooglePersistence();

        const result =
            await signInWithPopup(
                auth,
                provider
            );

        const user =
            result?.user ||
            auth.currentUser ||
            null;

        if (user) {
            currentUser = user;
            updateUserUI(user);
            listenForUserWallet(user);
            loadNotifications();
            listenForTransactions(user);
        }

        return {
            success: true,
            user
        };
    } catch (error) {
        const code = String(
            error?.code || ''
        );

        console.error(
            'MEMEWALLET GOOGLE SIGN-IN FAILED',
            code,
            error
        );

        if (
            code === 'auth/popup-blocked' ||
            code === 'auth/popup-closed-by-user' ||
            code === 'auth/cancelled-popup-request'
        ) {
            try {
                await signInWithRedirect(
                    auth,
                    provider
                );

                return {
                    success: true,
                    redirected: true
                };
            } catch (redirectError) {
                console.error(
                    'MEMEWALLET GOOGLE REDIRECT FALLBACK FAILED',
                    redirectError
                );

                showToast(
                    'Google sign-in could not start. Please try again.'
                );

                return {
                    success: false,
                    error: redirectError
                };
            }
        }

        if (code === 'auth/account-exists-with-different-credential') {
            showToast(
                'This Gmail already uses another sign-in method.'
            );
        } else if (code === 'auth/unauthorized-domain') {
            showToast(
                'Add this website domain to Firebase Authentication authorized domains.'
            );
        } else if (code === 'auth/operation-not-allowed') {
            showToast(
                'Google sign-in is not enabled in Firebase Authentication.'
            );
        } else if (code === 'auth/network-request-failed') {
            showToast(
                'Network error during Google sign-in. Check your connection and try again.'
            );
        } else {
            showToast(
                'Google sign-in failed. Please try again.'
            );
        }

        return {
            success: false,
            error
        };
    }
}


window.__memewalletSignInWithGoogle =
    memewalletSignInWithGoogle;

window.__memewalletSignInWithGmail =
    memewalletSignInWithGoogle;

window.__memewalletAuth = auth;
window.__memewalletFirebaseAuth = auth;

void memewalletConfigureGooglePersistence();
void memewalletFinishGoogleRedirect();


/* --------------------- HOURLY MARKET RESOLUTION ---------------------- */

function memewalletFinalHotfixTimeKey(
    timestamp = Date.now(),
    timeZone = 'UTC'
) {
    try {
        const parts =
            new Intl.DateTimeFormat(
                'en-CA',
                {
                    timeZone,
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit',
                    hour: '2-digit',
                    hour12: false
                }
            ).formatToParts(
                new Date(timestamp)
            );

        const values = {};

        parts.forEach(part => {
            if (part.type !== 'literal') {
                values[part.type] = part.value;
            }
        });

        let hour = String(
            values.hour || '00'
        );

        // Intl can represent midnight as 24 in some environments.
        if (hour === '24') {
            hour = '00';
        }

        return [
            values.year,
            values.month,
            values.day,
            hour
        ].join('-');
    } catch {
        return memewalletV2HourKey(
            timestamp
        );
    }
}


function memewalletFinalHotfixMarketCandidates(
    asset,
    timestamp,
    explicitMarketId = ''
) {
    const normalizedAsset =
        String(asset || '')
            .trim()
            .toUpperCase();

    const utcKey =
        memewalletFinalHotfixTimeKey(
            timestamp,
            'UTC'
        );

    const lagosKey =
        memewalletFinalHotfixTimeKey(
            timestamp,
            'Africa/Lagos'
        );

    const ids = [];

    const pushUnique = id => {
        const clean =
            String(id || '').trim();

        if (
            clean &&
            !ids.includes(clean)
        ) {
            ids.push(clean);
        }
    };

    pushUnique(explicitMarketId);

    pushUnique(
        `${normalizedAsset}_${utcKey}`
    );

    pushUnique(
        `${normalizedAsset}_${lagosKey}`
    );


    return ids;
}


function memewalletFinalHotfixTimestampMs(
    value
) {
    try {
        if (!value) {
            return 0;
        }

        if (typeof value.toMillis === 'function') {
            return value.toMillis();
        }

        if (typeof value.toDate === 'function') {
            return value.toDate().getTime();
        }

        if (value instanceof Date) {
            return value.getTime();
        }

        if (typeof value === 'number') {
            return Number.isFinite(value)
                ? value
                : 0;
        }

        if (typeof value === 'string') {
            const parsed = Date.parse(value);
            return Number.isFinite(parsed)
                ? parsed
                : 0;
        }

        return 0;
    } catch {
        return 0;
    }
}


function memewalletFinalHotfixHourFromId(
    marketId
) {
    const value = String(
        marketId || ''
    );

    const match =
        value.match(
            /_(\d{4})-(\d{2})-(\d{2})-(\d{2})(?:$|\D)/
        );

    if (!match) {
        return 0;
    }

    return Date.UTC(
        Number(match[1]),
        Number(match[2]) - 1,
        Number(match[3]),
        Number(match[4]),
        0,
        0,
        0
    );
}


function memewalletFinalHotfixMarketHourStart(
    market,
    marketId
) {
    const values = [
        market?.hourStartMs,
        market?.marketHourStartMs,
        market?.hourStart,
        market?.marketHourStart,
        market?.startAt,
        market?.opensAt,
        market?.openedAt,
        market?.hourKey,
        market?.marketHourKey,
        market?.hourId
    ];

    for (const value of values) {
        const timestamp =
            memewalletFinalHotfixTimestampMs(
                value
            );

        if (timestamp > 0) {
            return timestamp >= 0
                ? memewalletV2HourStart(timestamp)
                : 0;
        }

        const text =
            String(value || '');

        const parsed =
            memewalletFinalHotfixHourFromId(
                text
            );

        if (parsed) {
            return parsed;
        }

        const keyMatch =
            text.match(
                /(\d{4})-(\d{2})-(\d{2})[-T](\d{2})/
            );

        if (keyMatch) {
            return Date.UTC(
                Number(keyMatch[1]),
                Number(keyMatch[2]) - 1,
                Number(keyMatch[3]),
                Number(keyMatch[4]),
                0,
                0,
                0
            );
        }
    }

    return (
        memewalletFinalHotfixHourFromId(
            marketId
        ) || 0
    );
}


function memewalletFinalHotfixIsOpenMarket(
    market
) {
    const status =
        String(
            market?.status ||
            market?.state ||
            ''
        )
            .trim()
            .toLowerCase();

    if (
        [
            'closed',
            'settled',
            'expired',
            'cancelled',
            'canceled',
            'locked',
            'resolved'
        ].includes(status)
    ) {
        return false;
    }

    if (
        [
            'open',
            'active',
            'trading',
            'accepting',
            'accepting_orders'
        ].includes(status)
    ) {
        return true;
    }

    if (
        market?.active === false ||
        market?.isOpen === false ||
        market?.closed === true ||
        market?.settled === true
    ) {
        return false;
    }

    // If no status field was stored, the deterministic hourly document
    // itself remains usable unless the record explicitly says otherwise.
    return true;
}


function memewalletFinalHotfixPrice(
    market,
    choice
) {
    const isYes =
        String(choice || '') === 'Yes';

    const variants =
        isYes
            ? [
                market?.yesPrice,
                market?.yes,
                market?.yesOdds,
                market?.yesProbability,
                market?.upPrice,
                market?.up,
                market?.upOdds,
                market?.upProbability
            ]
            : [
                market?.noPrice,
                market?.no,
                market?.noOdds,
                market?.noProbability,
                market?.downPrice,
                market?.down,
                market?.downOdds,
                market?.downProbability
            ];

    for (const value of variants) {
        const number =
            Number(value);

        if (
            Number.isFinite(number) &&
            number > 0 &&
            number <= 100
        ) {
            return number;
        }
    }

    return 0;
}


function memewalletFinalHotfixBalanceField(
    userData
) {
    const fields = [
        'cashBalance',
        'walletBalance',
        'balance',
        'availableBalance'
    ];

    for (const field of fields) {
        const value =
            Number(
                userData?.[field]
            );

        if (
            Number.isFinite(value)
        ) {
            return field;
        }
    }

    return 'cashBalance';
}


function memewalletFinalHotfixBalance(
    userData
) {
    const field =
        memewalletFinalHotfixBalanceField(
            userData
        );

    const value =
        Number(
            userData?.[field]
        );

    return Number.isFinite(value)
        ? Math.max(0, value)
        : 0;
}


function memewalletFinalHotfixPredictionAuditFields(
    positionId,
    action
) {
    return {
        lastPredictionPositionId:
            String(positionId || ''),
        lastPredictionAction:
            String(action || '')
    };
}


function memewalletFinalHotfixErrorMessage(
    error
) {
    const code =
        String(
            error?.code || ''
        );

    const message =
        String(
            error?.message || ''
        );

    return `${code}${code && message ? ': ' : ''}${message}`;
}


/* --------------------------- FINAL BUY PATH -------------------------- */

async function memewalletFinalPredictionBuy(
    tradeInput
) {
    const user =
        auth.currentUser ||
        memewalletV2User ||
        currentUser ||
        null;

    if (!user) {
        showToast(
            'Please log in again before trading.'
        );

        return {
            success: false
        };
    }

    const amount =
        Number(
            tradeInput?.amount
        );

    if (
        !Number.isFinite(amount) ||
        amount <= 0
    ) {
        showToast(
            'Enter a valid trade amount.'
        );

        return {
            success: false
        };
    }

    const mode =
        String(
            tradeInput?.mode || 'Buy'
        ) === 'Sell'
            ? 'Sell'
            : 'Buy';

    if (mode !== 'Buy') {
        showToast(
            'Selling is not enabled for the hourly prediction trade system.'
        );

        return {
            success: false
        };
    }

    const choice =
        String(
            tradeInput?.choice || 'Yes'
        ) === 'No'
            ? 'No'
            : 'Yes';

    const predictionId =
        String(
            tradeInput?.predictionId || ''
        );

    const predictionTitle =
        String(
            tradeInput?.predictionTitle ||
            'Hourly prediction'
        );

    const assetInfo =
        memewalletV2AssetInfo(
            predictionTitle,
            predictionId
        );

    if (!assetInfo) {
        showToast(
            'Only Bitcoin and Solana hourly predictions can use the wallet stake system.'
        );

        return {
            success: false
        };
    }

    const now = Date.now();
    const hourStart =
        memewalletV2HourStart(
            now
        );
    const hourEnd =
        hourStart + 3600000;

    // The prediction card price supplied by the UI is deliberately NOT the
    // authority here. The Firestore hourly record is the authority.
    const explicitMarketId =
        String(
            tradeInput?.marketId ||
            tradeInput?.hourlyMarketId ||
            ''
        );

    const candidateMarketIds =
        memewalletFinalHotfixMarketCandidates(
            assetInfo.asset,
            now,
            explicitMarketId
        );

    const walletRef =
        doc(
            db,
            'users',
            user.uid
        );

    const marketRefs =
        candidateMarketIds.map(
            marketId =>
                ({
                    marketId,
                    ref: doc(
                        db,
                        MEMEWALLET_V2_MARKET_COLLECTION,
                        marketId
                    )
                })
        );

    const positionRef =
        doc(
            collection(
                db,
                'users',
                user.uid,
                MEMEWALLET_V2_POSITION_COLLECTION
            )
        );

    const activityRef =
        doc(
            collection(
                db,
                'users',
                user.uid,
                MEMEWALLET_V2_ACTIVITY_COLLECTION
            )
        );

    let resultData = null;

    try {
        await runTransaction(
            db,
            async transaction => {
                /*
                   IMPORTANT: all transaction reads happen before any writes.
                   Firestore guarantees atomicity for the complete set.
                */
                const walletSnapshot =
                    await transaction.get(
                        walletRef
                    );

                const marketSnapshots = [];

                for (const candidate of marketRefs) {
                    marketSnapshots.push({
                        marketId:
                            candidate.marketId,
                        snapshot:
                            await transaction.get(
                                candidate.ref
                            )
                    });
                }

                if (!walletSnapshot.exists()) {
                    throw new Error(
                        'WALLET_NOT_FOUND'
                    );
                }

                let selectedMarket = null;

                for (const item of marketSnapshots) {
                    if (!item.snapshot.exists()) {
                        continue;
                    }

                    const data =
                        item.snapshot.data() || {};

                    const recordHourStart =
                        memewalletFinalHotfixMarketHourStart(
                            data,
                            item.marketId
                        );

                    const hourMatches =
                        !recordHourStart ||
                        recordHourStart === hourStart;

                    if (
                        hourMatches &&
                        memewalletFinalHotfixIsOpenMarket(data)
                    ) {
                        selectedMarket = {
                            id:
                                item.marketId,
                            data,
                            ref:
                                marketRefs.find(
                                    candidate =>
                                        candidate.marketId ===
                                        item.marketId
                                )?.ref || null
                        };

                        break;
                    }
                }

                if (!selectedMarket) {
                    // Give a more precise error when a record exists but is closed.
                    const existing =
                        marketSnapshots.find(
                            item =>
                                item.snapshot.exists()
                        );

                    if (
                        existing &&
                        !memewalletFinalHotfixIsOpenMarket(
                            existing.snapshot.data() || {}
                        )
                    ) {
                        throw new Error(
                            'HOURLY_MARKET_CLOSED'
                        );
                    }

                    throw new Error(
                        'HOURLY_MARKET_NOT_FOUND'
                    );
                }

                const market =
                    selectedMarket.data;

                const marketHourStart =
                    memewalletFinalHotfixMarketHourStart(
                        market,
                        selectedMarket.id
                    );

                if (
                    marketHourStart &&
                    marketHourStart !== hourStart
                ) {
                    throw new Error(
                        'HOURLY_MARKET_MISMATCH'
                    );
                }

                if (
                    Date.now() >=
                    hourEnd
                ) {
                    throw new Error(
                        'HOURLY_MARKET_EXPIRED'
                    );
                }

                const selectedPrice =
                    memewalletFinalHotfixPrice(
                        market,
                        choice
                    );

                if (
                    !Number.isFinite(selectedPrice) ||
                    selectedPrice <= 0 ||
                    selectedPrice > 100
                ) {
                    throw new Error(
                        'HOURLY_MARKET_PRICE_INVALID'
                    );
                }

                const walletData =
                    walletSnapshot.data() || {};

                const balanceField =
                    memewalletFinalHotfixBalanceField(
                        walletData
                    );

                const currentBalance =
                    memewalletFinalHotfixBalance(
                        walletData
                    );

                if (
                    currentBalance + 0.00000001 <
                    amount
                ) {
                    throw new Error(
                        `INSUFFICIENT_BALANCE:${currentBalance}`
                    );
                }

                const newBalance =
                    Math.max(
                        0,
                        currentBalance - amount
                    );

                const shares =
                    amount / selectedPrice;

                const potentialPayout =
                    shares * 100;

                transaction.update(
                    walletRef,
                    {
                        [balanceField]:
                            newBalance,
                        lastPredictionPositionId:
                            positionRef.id,
                        lastPredictionAction:
                            'buy'
                    }
                );

                transaction.set(
                    positionRef,
                    {
                        userId:
                            user.uid,
                        userEmail:
                            user.email || '',
                        status:
                            MEMEWALLET_V2_OPEN,
                        mode:
                            'Buy',
                        choice,
                        choiceLabel:
                            String(
                                tradeInput?.choiceLabel ||
                                choice
                            ),
                        predictionId,
                        predictionTitle,
                        asset:
                            assetInfo.asset,
                        symbol:
                            assetInfo.symbol,
                        marketId:
                            selectedMarket.id,
                        marketCollection:
                            MEMEWALLET_V2_MARKET_COLLECTION,
                        marketHourStart:
                            Timestamp.fromMillis(
                                hourStart
                            ),
                        marketHourEnd:
                            Timestamp.fromMillis(
                                hourEnd
                            ),
                        stake:
                            amount,
                        price:
                            selectedPrice,
                        priceSource:
                            'firestore-hourly-market',
                        shares,
                        potentialPayout,
                        walletBalanceBefore:
                            currentBalance,
                        walletBalanceAfter:
                            newBalance,
                        createdAt:
                            serverTimestamp(),
                        expiresAt:
                            Timestamp.fromMillis(
                                hourEnd
                            )
                    }
                );

                transaction.set(
                    activityRef,
                    {
                        userId:
                            user.uid,
                        positionId:
                            positionRef.id,
                        type:
                            'prediction_buy',
                        status:
                            'completed',
                        direction:
                            'out',
                        amount:
                            amount,
                        stake:
                            amount,
                        price:
                            selectedPrice,
                        priceSource:
                            'firestore-hourly-market',
                        shares,
                        potentialPayout,
                        predictionId,
                        predictionTitle,
                        asset:
                            assetInfo.asset,
                        symbol:
                            assetInfo.symbol,
                        marketId:
                            selectedMarket.id,
                        choice,
                        choiceLabel:
                            String(
                                tradeInput?.choiceLabel ||
                                choice
                            ),
                        walletBalanceBefore:
                            currentBalance,
                        walletBalanceAfter:
                            newBalance,
                        createdAt:
                            serverTimestamp()
                    }
                );

                resultData = {
                    id:
                        positionRef.id,
                    marketId:
                        selectedMarket.id,
                    amount,
                    selectedPrice,
                    potentialPayout,
                    expiresAt:
                        hourEnd,
                    walletBalanceBefore:
                        currentBalance,
                    walletBalanceAfter:
                        newBalance
                };
            }
        );
    } catch (error) {
        const details =
            memewalletFinalHotfixErrorMessage(
                error
            );

        console.error(
            'MEMEWALLET FINAL PREDICTION BUY FAILED',
            {
                details,
                uid: user.uid,
                email: user.email || '',
                amount,
                choice,
                asset: assetInfo.asset,
                candidateMarketIds
            }
        );

        if (
            details.startsWith(
                'INSUFFICIENT_BALANCE:'
            )
        ) {
            const available =
                Number(
                    details.split(':')[1]
                );

            showToast(
                `Insufficient balance. Available ${formatNaira(available)}`
            );
        } else if (
            details.includes(
                'permission-denied'
            )
        ) {
            showToast(
                'Prediction could not be placed because Firestore Security Rules blocked the prediction transaction. Check the wallet, hourly market, position, and activity rules.'
            );
        } else if (
            details.includes(
                'failed-precondition'
            ) &&
            details.toLowerCase().includes('transaction')
        ) {
            showToast(
                'Prediction could not be placed right now. Please try again.'
            );
        } else if (
            details === 'WALLET_NOT_FOUND'
        ) {
            showToast(
                'Wallet account was not found.'
            );
        } else if (
            details === 'HOURLY_MARKET_NOT_FOUND'
        ) {
            showToast(
                'This hourly market has not been published for the current hour yet.'
            );
        } else if (
            details === 'HOURLY_MARKET_CLOSED' ||
            details === 'HOURLY_MARKET_EXPIRED'
        ) {
            showToast(
                'This hourly market has already closed.'
            );
        } else if (
            details === 'HOURLY_MARKET_MISMATCH'
        ) {
            showToast(
                'The hourly market changed. Please open the prediction again.'
            );
        } else if (
            details === 'HOURLY_MARKET_PRICE_INVALID'
        ) {
            showToast(
                'No valid Yes/No odds are available in the current hourly Firestore record.'
            );
        } else {
            showToast(
                'Prediction trade failed. Your wallet was not charged.'
            );
        }

        return {
            success: false,
            errorCode:
                String(
                    error?.code || ''
                )
        };
    }

    showToast(
        `${choice} trade placed. ${formatNaira(amount)} is now on trade until the hour ends.`
    );

    memewalletV2RenderPredictionSection();

    return {
        success: true,
        tradeId:
            resultData.id,
        marketId:
            resultData.marketId,
        amount:
            resultData.amount,
        selectedPrice:
            resultData.selectedPrice,
        potentialPayout:
            resultData.potentialPayout,
        expiresAt:
            resultData.expiresAt,
        source:
            'firestore-hourly-market',
        walletBalanceBefore:
            resultData.walletBalanceBefore,
        walletBalanceAfter:
            resultData.walletBalanceAfter
    };
}


/*
   FINAL global bridge. The existing HTML trade-drawer code already calls
   window.__memewalletCompletePredictionTrade(), so no UI function needs
   to be edited or removed.
*/
window.__memewalletCompletePredictionTrade =
    memewalletFinalPredictionBuy;



/* ================================================================
   ADDITIVE HOURLY MARKET PUBLISHER
   ---------------------------------------------------------------
   The existing prediction BUY path reads hourlyPredictionMarkets/{id}.
   The current wallet file previously had only a read/cache listener for
   that collection and no active publisher. This additive worker creates
   the current BTC/SOL hourly records before a user buys.

   Existing trade, wallet, Gmail, chart, deposit and transaction functions
   are intentionally left untouched.
================================================================ */

const MEMEWALLET_ADDITIVE_HOURLY_COLLECTION =
    'hourlyPredictionMarkets';

let memewalletAdditiveHourlyPublisherTimer =
    null;

let memewalletAdditiveHourlyPublisherBusy =
    false;

let memewalletAdditiveHourlyPublisherLastHour =
    null;


function memewalletAdditiveUtcHourStart(
    timestamp = Date.now()
) {
    const date =
        new Date(timestamp);

    return Date.UTC(
        date.getUTCFullYear(),
        date.getUTCMonth(),
        date.getUTCDate(),
        date.getUTCHours(),
        0,
        0,
        0
    );
}


function memewalletAdditiveHourlyMarketId(
    asset,
    hourStart
) {
    return `${String(asset || '').toUpperCase()}_${memewalletV2HourKey(hourStart)}`;
}


function memewalletAdditiveOddsFromPreviousCandle(
    candle
) {
    const open =
        Number(candle?.open);

    const close =
        Number(candle?.close);

    if (
        !Number.isFinite(open) ||
        !Number.isFinite(close) ||
        open <= 0 ||
        close <= 0
    ) {
        return {
            yesPrice: 50,
            noPrice: 50,
            prediction: 'Yes'
        };
    }

    const move =
        ((close - open) / open) * 100;

    const strength =
        Math.max(
            5,
            Math.min(
                40,
                Math.round(Math.abs(move) * 12)
            )
        );

    if (move > 0) {
        return {
            yesPrice: 50 + strength,
            noPrice: 50 - strength,
            prediction: 'Yes'
        };
    }

    if (move < 0) {
        return {
            yesPrice: 50 - strength,
            noPrice: 50 + strength,
            prediction: 'No'
        };
    }

    return {
        yesPrice: 50,
        noPrice: 50,
        prediction: 'Yes'
    };
}


async function memewalletAdditiveFetchHourlyCandles(
    symbol,
    startTimeMs = null,
    endTimeMs = null,
    limit = 3
) {
    const encodedSymbol =
        encodeURIComponent(
            String(symbol || '').toUpperCase()
        );

    const safeLimit =
        Math.min(
            1000,
            Math.max(
                1,
                Number(limit) || 3
            )
        );

    const hasRange =
        Number.isFinite(Number(startTimeMs)) &&
        Number.isFinite(Number(endTimeMs)) &&
        Number(startTimeMs) >= 0 &&
        Number(endTimeMs) > Number(startTimeMs);

    const querySuffix =
        hasRange
            ? `&startTime=${encodeURIComponent(Number(startTimeMs))}` +
              `&endTime=${encodeURIComponent(Number(endTimeMs))}&limit=${safeLimit}`
            : `&limit=${safeLimit}`;

    const urls = [
        `https://data-api.binance.vision/api/v3/klines?symbol=${encodedSymbol}&interval=1h${querySuffix}`,
        `https://api.binance.com/api/v3/klines?symbol=${encodedSymbol}&interval=1h${querySuffix}`,
        `https://api1.binance.com/api/v3/klines?symbol=${encodedSymbol}&interval=1h${querySuffix}`
    ];

    let lastError = null;

    for (const url of urls) {
        try {
            const controller =
                new AbortController();

            const timer =
                setTimeout(
                    () => controller.abort(),
                    7000
                );

            const response =
                await fetch(
                    url,
                    {
                        method: 'GET',
                        cache: 'no-store',
                        signal: controller.signal
                    }
                );

            clearTimeout(timer);

            if (!response.ok) {
                throw new Error(
                    `Binance HTTP ${response.status}`
                );
            }

            const data =
                await response.json();

            if (!Array.isArray(data)) {
                throw new Error(
                    'Invalid Binance hourly response.'
                );
            }

            return data
                .map(row => ({
                    openTime: Number(row?.[0]),
                    open: Number(row?.[1]),
                    high: Number(row?.[2]),
                    low: Number(row?.[3]),
                    close: Number(row?.[4]),
                    closeTime: Number(row?.[6])
                }))
                .filter(
                    candle =>
                        Number.isFinite(candle.openTime) &&
                        Number.isFinite(candle.open) &&
                        Number.isFinite(candle.close) &&
                        candle.open > 0 &&
                        candle.close > 0
                )
                .sort(
                    (a, b) =>
                        a.openTime - b.openTime
                );
        } catch (error) {
            lastError = error;
        }
    }

    throw (
        lastError ||
        new Error(
            'Unable to load Binance hourly candles.'
        )
    );
}


async function memewalletAdditivePublishOneAsset(
    assetInfo,
    hourStart
) {
    const candles =
        await memewalletAdditiveFetchHourlyCandles(
            assetInfo.symbol
        );

    if (!candles.length) {
        return false;
    }

    const currentCandle =
        candles.find(
            candle =>
                Number(candle.openTime) ===
                Number(hourStart)
        )
        ||
        candles.find(
            candle =>
                Number(candle.openTime) <= Date.now() &&
                Number(candle.closeTime) >= Date.now()
        );

    const previousCandle =
        candles.find(
            candle =>
                Number(candle.openTime) ===
                Number(hourStart) - 3600000
        );

    if (!currentCandle) {
        return false;
    }

    const currentMarketId =
        memewalletAdditiveHourlyMarketId(
            assetInfo.asset,
            hourStart
        );

    const currentRef =
        doc(
            db,
            MEMEWALLET_ADDITIVE_HOURLY_COLLECTION,
            currentMarketId
        );

    const currentOdds =
        memewalletAdditiveOddsFromPreviousCandle(
            previousCandle
        );

    const hourEnd =
        hourStart + 3600000;

    await runTransaction(
        db,
        async transaction => {
            const snapshot =
                await transaction.get(
                    currentRef
                );

            if (
                snapshot.exists()
            ) {
                const existing =
                    snapshot.data() || {};

                const existingStatus =
                    String(
                        existing.status ||
                        ''
                    ).toLowerCase();

                if (
                    existingStatus === 'settled' ||
                    existingStatus === 'closed'
                ) {
                    return;
                }

                transaction.set(
                    currentRef,
                    {
                        schemaVersion: 4,
                        marketId: currentMarketId,
                        asset: assetInfo.asset,
                        symbol: assetInfo.symbol,
                        hourStartMs: hourStart,
                        hourEndMs: hourEnd,
                        hourStart: Timestamp.fromMillis(hourStart),
                        hourEnd: Timestamp.fromMillis(hourEnd),
                        status: 'open',
                        prediction:
                            existing.prediction ||
                            currentOdds.prediction,
                        signal:
                            existing.signal ||
                            currentOdds.prediction,
                        yesPrice:
                            Number(existing.yesPrice) ||
                            currentOdds.yesPrice,
                        noPrice:
                            Number(existing.noPrice) ||
                            currentOdds.noPrice,
                        yesMultiplier:
                            Number(existing.yesMultiplier) ||
                            Number((100 / currentOdds.yesPrice).toFixed(6)),
                        noMultiplier:
                            Number(existing.noMultiplier) ||
                            Number((100 / currentOdds.noPrice).toFixed(6)),
                        startPrice:
                            Number(currentCandle.open),
                        currentPrice:
                            Number(currentCandle.close),
                        signalSource:
                            'previous_completed_hour',
                        updatedAt:
                            serverTimestamp()
                    },
                    { merge: true }
                );

                return;
            }

            transaction.set(
                currentRef,
                {
                    schemaVersion: 4,
                    marketId: currentMarketId,
                    asset: assetInfo.asset,
                    symbol: assetInfo.symbol,
                    hourStartMs: hourStart,
                    hourEndMs: hourEnd,
                    hourStart: Timestamp.fromMillis(hourStart),
                    hourEnd: Timestamp.fromMillis(hourEnd),
                    hourLabel:
                        `${memewalletV2HourKey(hourStart)} → ${memewalletV2HourKey(hourEnd)}`,
                    status: 'open',
                    prediction:
                        currentOdds.prediction,
                    signal:
                        currentOdds.prediction,
                    yesPrice:
                        Number(currentOdds.yesPrice),
                    noPrice:
                        Number(currentOdds.noPrice),
                    yesMultiplier:
                        Number((100 / currentOdds.yesPrice).toFixed(6)),
                    noMultiplier:
                        Number((100 / currentOdds.noPrice).toFixed(6)),
                    signalSource:
                        'previous_completed_hour',
                    previousHourMovePercent:
                        previousCandle
                            ? Number(
                                (
                                    ((previousCandle.close - previousCandle.open) /
                                    previousCandle.open) *
                                    100
                                ).toFixed(8)
                            )
                            : 0,
                    startPrice:
                        Number(currentCandle.open),
                    currentPrice:
                        Number(currentCandle.close),
                    createdAt:
                        serverTimestamp(),
                    updatedAt:
                        serverTimestamp()
                },
                { merge: true }
            );
        }
    );

    return true;
}


async function memewalletAdditiveSettlePreviousAsset(
    assetInfo,
    hourStart
) {
    const previousHourStart =
        hourStart - 3600000;

    const previousMarketId =
        memewalletAdditiveHourlyMarketId(
            assetInfo.asset,
            previousHourStart
        );

    const previousRef =
        doc(
            db,
            MEMEWALLET_ADDITIVE_HOURLY_COLLECTION,
            previousMarketId
        );

    try {
        const snapshot =
            await getDoc(
                previousRef
            );

        if (!snapshot.exists()) {
            return false;
        }

        const data =
            snapshot.data() || {};

        if (
            ['settled', 'closed']
                .includes(
                    String(data.status || '').toLowerCase()
                ) &&
            data.outcome
        ) {
            return true;
        }

        const candles =
            await memewalletAdditiveFetchHourlyCandles(
                assetInfo.symbol
            );

        const candle =
            candles.find(
                item =>
                    Number(item.openTime) ===
                    Number(previousHourStart)
            );

        if (!candle) {
            return false;
        }

        let outcome =
            'Refund';

        if (
            Number(candle.close) >
            Number(candle.open)
        ) {
            outcome = 'Yes';
        } else if (
            Number(candle.close) <
            Number(candle.open)
        ) {
            outcome = 'No';
        }

        await runTransaction(
            db,
            async transaction => {
                const latest =
                    await transaction.get(
                        previousRef
                    );

                if (!latest.exists()) {
                    return;
                }

                const latestData =
                    latest.data() || {};

                const latestStatus =
                    String(
                        latestData.status || ''
                    ).toLowerCase();

                if (
                    ['settled', 'closed'].includes(latestStatus) &&
                    latestData.outcome
                ) {
                    return;
                }

                transaction.set(
                    previousRef,
                    {
                        status: 'settled',
                        outcome,
                        finalPrice:
                            Number(candle.close),
                        movePercent:
                            Number(
                                (
                                    ((candle.close - candle.open) /
                                    candle.open) *
                                    100
                                ).toFixed(8)
                            ),
                        settledAt:
                            serverTimestamp(),
                        updatedAt:
                            serverTimestamp()
                    },
                    { merge: true }
                );
            }
        );

        return true;
    } catch (error) {
        console.warn(
            'MEMEWALLET ADDITIVE HOURLY SETTLE FAILED',
            assetInfo.asset,
            error
        );

        return false;
    }
}



async function memewalletAdditivePublishCurrentHourlyMarkets(
    force = false
) {
    if (
        memewalletAdditiveHourlyPublisherBusy
    ) {
        return false;
    }

    const user =
        auth.currentUser;

    if (!user) {
        return false;
    }

    const hourStart =
        memewalletAdditiveUtcHourStart(
            Date.now()
        );

    if (
        !force &&
        memewalletAdditiveHourlyPublisherLastHour ===
        hourStart
    ) {
        return true;
    }

    memewalletAdditiveHourlyPublisherBusy =
        true;

    let allPublished =
        true;

    try {
        const assets = [
            {
                asset: 'BTC',
                symbol: 'BTCUSDT'
            },
            {
                asset: 'SOL',
                symbol: 'SOLUSDT'
            }
        ];

        const results =
            await Promise.all(
                assets.map(
                    async assetInfo => {

                        let published =
                            false;

                        try {
                            /*
                             * Settle the previous hour first.
                             */
                            await memewalletAdditiveSettlePreviousAsset(
                                assetInfo,
                                hourStart
                            );

                            /*
                             * Then make absolutely sure the
                             * current hour exists.
                             */
                            published =
                                await memewalletAdditivePublishOneAsset(
                                    assetInfo,
                                    hourStart
                                );

                        } catch (error) {

                            console.warn(
                                'MEMEWALLET HOURLY ASSET PUBLISH FAILED',
                                assetInfo.asset,
                                error
                            );

                            published =
                                false;
                        }

                        return published;
                    }
                )
            );

        allPublished =
            results.length === 2 &&
            results.every(
                Boolean
            );

        /*
         * Only mark the hour complete if BOTH markets were actually
         * created/confirmed. Otherwise the 15-second timer keeps retrying.
         */
        if (
            allPublished
        ) {
            memewalletAdditiveHourlyPublisherLastHour =
                hourStart;
        } else {
            memewalletAdditiveHourlyPublisherLastHour =
                null;
        }

        return allPublished;

    } catch (error) {

        console.warn(
            'MEMEWALLET ADDITIVE HOURLY PUBLISHER FAILED',
            error
        );

        memewalletAdditiveHourlyPublisherLastHour =
            null;

        return false;

    } finally {

        memewalletAdditiveHourlyPublisherBusy =
            false;
    }
}


function memewalletAdditiveStartHourlyPublisher() {
    if (
        memewalletAdditiveHourlyPublisherTimer
    ) {
        clearInterval(
            memewalletAdditiveHourlyPublisherTimer
        );
    }

    memewalletAdditiveHourlyPublisherLastHour =
        null;

    memewalletAdditivePublishCurrentHourlyMarkets(
        true
    );

    memewalletAdditiveHourlyPublisherTimer =
        setInterval(
            () => {
                memewalletAdditivePublishCurrentHourlyMarkets();
            },
            15000
        );
}


function memewalletAdditiveStopHourlyPublisher() {
    if (
        memewalletAdditiveHourlyPublisherTimer
    ) {
        clearInterval(
            memewalletAdditiveHourlyPublisherTimer
        );

        memewalletAdditiveHourlyPublisherTimer =
            null;
    }

    memewalletAdditiveHourlyPublisherBusy =
        false;
    memewalletAdditiveHourlyPublisherLastHour =
        null;
}


onAuthStateChanged(
    auth,
    user => {
        if (user) {
            memewalletAdditiveStartHourlyPublisher();
        } else {
            memewalletAdditiveStopHourlyPublisher();
        }
    }
);

window.__memewalletHourlyPublisherReady =
    true;


window.__memewalletPredictionWalletHotfixVersion =
    MEMEWALLET_FINAL_HOTFIX_VERSION;

console.log(
    'MemeWallet prediction wallet hotfix active:',
    MEMEWALLET_FINAL_HOTFIX_VERSION
);




/* =====================================================================
   FINAL RELIABILITY PATCH
   ---------------------------------------------------------------------
   Self-healing hourly publication + settlement recovery.
===================================================================== */

async function memewalletReliableEnsureCurrentHourlyMarket(
    assetInfo,
    hourStart
) {
    if (!assetInfo?.asset || !assetInfo?.symbol) {
        return false;
    }

    const marketId =
        memewalletAdditiveHourlyMarketId(
            assetInfo.asset,
            hourStart
        );

    const marketRef =
        doc(
            db,
            MEMEWALLET_ADDITIVE_HOURLY_COLLECTION,
            marketId
        );

    for (
        let attempt = 0;
        attempt < 3;
        attempt += 1
    ) {
        try {
            const existing =
                await getDoc(
                    marketRef
                );

            if (
                existing.exists()
            ) {
                const data =
                    existing.data() || {};

                const status =
                    String(
                        data.status || ''
                    ).toLowerCase();

                const dataHourStart =
                    Number(
                        data.hourStartMs || 0
                    );

                if (
                    dataHourStart === hourStart &&
                    status !== 'settled' &&
                    status !== 'closed'
                ) {
                    return true;
                }
            }

            /*
             * Force the publisher to try immediately.
             */
            await memewalletAdditivePublishCurrentHourlyMarkets(
                true
            );

            const afterPublish =
                await getDoc(
                    marketRef
                );

            if (
                afterPublish.exists()
            ) {
                const data =
                    afterPublish.data() || {};

                const status =
                    String(
                        data.status || ''
                    ).toLowerCase();

                if (
                    Number(
                        data.hourStartMs || 0
                    ) === hourStart &&
                    status !== 'settled' &&
                    status !== 'closed'
                ) {
                    return true;
                }
            }

        } catch (error) {

            console.warn(
                'MEMEWALLET CURRENT HOURLY MARKET CHECK FAILED',
                assetInfo.asset,
                attempt + 1,
                error
            );
        }

        /*
         * Give another 500ms attempt a chance.
         */
        await new Promise(
            resolve =>
                setTimeout(
                    resolve,
                    500
                )
        );
    }

    return false;
}


async function memewalletReliableEnsureMarketSettled(
    marketId
) {
    const marketRef =
        doc(
            db,
            MEMEWALLET_ADDITIVE_HOURLY_COLLECTION,
            marketId
        );

    try {
        const snapshot =
            await getDoc(
                marketRef
            );

        if (!snapshot.exists()) {
            console.warn(
                'MEMEWALLET SETTLEMENT RECOVERY: MARKET NOT FOUND',
                marketId
            );
            return false;
        }

        const market =
            snapshot.data() || {};

        const status =
            String(
                market.status || ''
            ).toLowerCase();

        if (
            status === 'settled' &&
            market.outcome
        ) {
            return true;
        }

        /*
         * Older records can contain either the numeric millisecond
         * fields or Firestore Timestamp fields. Support both so a
         * position from a previous build can still be recovered.
         */
        const hourStart =
            Number(
                market.hourStartMs ||
                memewalletV2TimestampMs(
                    market.hourStart
                ) ||
                0
            );

        const hourEnd =
            Number(
                market.hourEndMs ||
                memewalletV2TimestampMs(
                    market.hourEnd
                ) ||
                (
                    hourStart > 0
                        ? hourStart + 3600000
                        : 0
                )
            );

        if (!hourStart || !hourEnd) {
            console.warn(
                'MEMEWALLET SETTLEMENT RECOVERY: INVALID MARKET TIME',
                marketId,
                market
            );
            return false;
        }

        if (Date.now() < hourEnd) {
            return false;
        }

        const asset =
            String(
                market.asset || ''
            ).toUpperCase();

        const symbol =
            String(
                market.symbol || ''
            ).toUpperCase();

        const validSymbol =
            symbol ||
            (
                asset === 'SOL'
                    ? 'SOLUSDT'
                    : 'BTCUSDT'
            );

        /*
         * CRITICAL FIX:
         * The old code requested only the latest 3 hourly candles.
         * That works for the current/previous hour, but a position
         * left open since yesterday cannot find its exact candle.
         * Request the exact expired hour instead.
         */
        let candles =
            await memewalletAdditiveFetchHourlyCandles(
                validSymbol,
                hourStart,
                hourEnd - 1,
                1
            );

        let candle =
            candles.find(
                item =>
                    Number(item.openTime) === hourStart
            );

        /*
         * Very small fallback window for providers that ignore the
         * exact endTime boundary.
         */
        if (!candle) {
            candles =
                await memewalletAdditiveFetchHourlyCandles(
                    validSymbol,
                    hourStart - 3600000,
                    hourEnd + 3600000,
                    5
                );

            candle =
                candles.find(
                    item =>
                        Number(item.openTime) === hourStart
                );
        }

        if (!candle) {
            console.warn(
                'MEMEWALLET SETTLEMENT RECOVERY: EXACT HOURLY CANDLE NOT FOUND',
                {
                    marketId,
                    validSymbol,
                    hourStart,
                    hourEnd
                }
            );
            return false;
        }

        const open =
            Number(candle.open);

        const close =
            Number(candle.close);

        if (
            !Number.isFinite(open) ||
            !Number.isFinite(close) ||
            open <= 0 ||
            close <= 0
        ) {
            return false;
        }

        let outcome = 'Refund';

        if (close > open) {
            outcome = 'Yes';
        } else if (close < open) {
            outcome = 'No';
        }

        const movePercent =
            Number(
                (
                    ((close - open) / open) * 100
                ).toFixed(8)
            );

        let wroteSettlement = false;

        await runTransaction(
            db,
            async transaction => {

                const latest =
                    await transaction.get(
                        marketRef
                    );

                if (!latest.exists()) {
                    return;
                }

                const latestData =
                    latest.data() || {};

                const latestStatus =
                    String(
                        latestData.status || ''
                    ).toLowerCase();

                if (
                    latestStatus === 'settled' &&
                    latestData.outcome
                ) {
                    wroteSettlement = true;
                    return;
                }

                transaction.set(
                    marketRef,
                    {
                        status: 'settled',
                        outcome,
                        finalPrice: close,
                        movePercent,
                        currentPrice: close,
                        updatedAt: serverTimestamp(),
                        settledAt: serverTimestamp()
                    },
                    {
                        merge: true
                    }
                );

                wroteSettlement = true;
            }
        );

        if (!wroteSettlement) {
            return false;
        }

        console.log(
            'MEMEWALLET SETTLEMENT RECOVERY COMPLETE',
            {
                marketId,
                validSymbol,
                outcome,
                open,
                close,
                movePercent
            }
        );

        return true;

    } catch (error) {

        console.warn(
            'MEMEWALLET RELIABLE MARKET SETTLEMENT FAILED',
            marketId,
            error
        );

        return false;
    }
}



/*
 * Wrap the final trade bridge so the market is guaranteed to exist
 * before the already-existing BUY transaction is attempted.
 */
const memewalletOriginalCompletePredictionTrade =
    window.__memewalletCompletePredictionTrade;

window.__memewalletCompletePredictionTrade =
    async function (
        tradeInput
    ) {

        try {

            const title =
                String(
                    tradeInput?.predictionTitle ||
                    ''
                );

            const predictionId =
                String(
                    tradeInput?.predictionId ||
                    ''
                );

            const assetInfo =
                memewalletV2AssetInfo(
                    title,
                    predictionId
                );

            const hourStart =
                memewalletV2HourStart(
                    Date.now()
                );

            const available =
                await memewalletReliableEnsureCurrentHourlyMarket(
                    assetInfo,
                    hourStart
                );

            if (
                !available
            ) {
                showToast(
                    'The hourly market is still syncing. Please try again.'
                );

                return {
                    success:
                        false
                };
            }

        } catch (error) {

            console.warn(
                'MEMEWALLET PRE-BUY MARKET SYNC FAILED',
                error
            );
        }

        return memewalletOriginalCompletePredictionTrade(
            tradeInput
        );
    };


/* =====================================================================
   MEMEWALLET PREDICTION CENTER / NOTIFICATION BRIDGE
   ---------------------------------------------------------------------
   Additive only. Existing wallet, chart, deposit, Gmail, navigation and
   trade functions remain in place. This bridge changes only where the
   prediction activity UI is displayed and connects V2 prediction activity
   records to the existing notification panel.

   Behaviour:
     - Removes the old Prediction activity card from the Cash Wallet page.
     - Places the live prediction trade/activity card in the Predictions page.
     - Keeps stakes out of the wallet transaction list/UI.
     - Every V2 prediction BUY/WIN/LOSS/REFUND becomes a notification.
     - WIN: wallet receives the original stake + winnings (the stored payout).
     - LOSS: no money is returned; the already-withdrawn stake stays gone.
     - REFUND: the stake is returned (for a flat/refund market result).
===================================================================== */

const MEMEWALLET_PREDICTION_CENTER_VERSION =
    '2026-10-01-prediction-center-notifications';

let memewalletPredictionActivityUnsubscribe =
    null;

let memewalletPredictionActivityUser =
    null;

let memewalletPredictionCenterUiTimer =
    null;


function memewalletPredictionCenterHost() {
    const predictionPage =
        document.getElementById(
            'page-predictions'
        );

    if (!predictionPage) {
        return null;
    }

    const dedicatedHost =
        document.getElementById(
            'memewalletV3PredictionCenter'
        );

    if (dedicatedHost) {
        return dedicatedHost;
    }

    return predictionPage;
}


function memewalletRemoveLegacyWalletPredictionUi() {
    const legacyCard =
        document.getElementById(
            'memewalletTradeActivityCard'
        );

    if (legacyCard) {
        legacyCard.remove();
    }
}


function memewalletMoveV2PredictionUiToPredictions() {
    const host =
        memewalletPredictionCenterHost();

    if (!host) {
        return;
    }

    const v2Portfolio =
        document.getElementById(
            'memewalletV2PredictionPortfolio'
        );

    if (
        v2Portfolio &&
        v2Portfolio.parentElement !== host
    ) {
        host.appendChild(
            v2Portfolio
        );
    }
}


function memewalletHideStaticPredictionPlaceholders() {
    const predictionPage =
        document.getElementById(
            'page-predictions'
        );

    if (!predictionPage) {
        return;
    }

    /*
       The original HTML contains a static placeholder card. The V2 live
       prediction portfolio replaces it so users see one authoritative
       active-position/history area in the Predictions page.
    */
    const staticActiveCard =
        predictionPage.querySelector(
            ':scope > section'
        );

    if (
        staticActiveCard &&
        staticActiveCard.id !== 'memewalletV3PredictionCenter'
    ) {
        staticActiveCard.style.display = 'none';
        staticActiveCard.setAttribute(
            'data-memewallet-hidden-static-prediction',
            'true'
        );
    }

    const staticMessage =
        Array.from(
            predictionPage.querySelectorAll(
                'div'
            )
        ).find(
            element =>
                String(
                    element.textContent || ''
                ).trim() ===
                'No prediction activity yet'
        );

    if (staticMessage) {
        staticMessage.style.display = 'none';
    }
}


function memewalletRefreshPredictionCenterPlacement() {
    memewalletRemoveLegacyWalletPredictionUi();
    memewalletMoveV2PredictionUiToPredictions();
    memewalletHideStaticPredictionPlaceholders();
}


function memewalletPredictionNotificationKey(
    activityId,
    activity
) {
    const id =
        String(
            activityId ||
            ''
        ).trim();

    if (id) {
        return `prediction_activity_${id}`;
    }

    const type =
        String(
            activity?.type ||
            'prediction_activity'
        );

    const positionId =
        String(
            activity?.positionId ||
            ''
        );

    return `prediction_activity_${type}_${positionId}`;
}


function memewalletPredictionNotificationAmount(
    value
) {
    const amount =
        Number(value);

    return Number.isFinite(amount)
        ? amount
        : 0;
}


function memewalletAddPredictionActivityNotification(
    activityId,
    activity
) {
    if (!currentUser || !activity) {
        return false;
    }

    const key =
        memewalletPredictionNotificationKey(
            activityId,
            activity
        );

    const alreadyExists =
        notifications.some(
            item =>
                String(
                    item?.predictionNotificationKey ||
                    ''
                ) === key
        );

    if (alreadyExists) {
        return false;
    }

    const type =
        String(
            activity?.type ||
            ''
        ).toLowerCase();

    const asset =
        String(
            activity?.asset ||
            ''
        ).trim();

    const choice =
        String(
            activity?.choiceLabel ||
            activity?.choice ||
            ''
        ).trim();

    const title =
        String(
            activity?.predictionTitle ||
            'Hourly prediction'
        ).trim();

    const stake =
        memewalletPredictionNotificationAmount(
            activity?.stake ||
            activity?.amount
        );

    const payout =
        memewalletPredictionNotificationAmount(
            activity?.payout ||
            activity?.amount
        );

    const profit =
        memewalletPredictionNotificationAmount(
            activity?.profit
        );

    let notificationTitle =
        'Prediction activity';

    let notificationMessage =
        title;

    if (type === 'prediction_buy') {
        notificationTitle =
            'Prediction placed';

        notificationMessage =
            `Buy ${choice || 'share'}${asset ? ` · ${asset}` : ''}: ${formatNaira(stake)} is now on trade.`;
    } else if (type === 'prediction_win') {
        notificationTitle =
            'Prediction won';

        notificationMessage =
            `${choice || 'Your prediction'}${asset ? ` · ${asset}` : ''}: ${formatNaira(payout)} was returned to your wallet${profit > 0 ? `, including ${formatNaira(profit)} won.` : '.'}`;
    } else if (type === 'prediction_loss') {
        notificationTitle =
            'Prediction lost';

        notificationMessage =
            `${choice || 'Your prediction'}${asset ? ` · ${asset}` : ''}: ${formatNaira(stake)} stake was lost. Nothing was returned to the wallet.`;
    } else if (type === 'prediction_refund') {
        notificationTitle =
            'Prediction refunded';

        notificationMessage =
            `${choice || 'Your prediction'}${asset ? ` · ${asset}` : ''}: ${formatNaira(payout)} stake returned to your wallet.`;
    }

    notifications.unshift({
        id:
            key,
        predictionNotificationKey:
            key,
        predictionActivityId:
            String(activityId || ''),
        type,
        title:
            notificationTitle,
        message:
            notificationMessage,
        amount:
            type === 'prediction_loss'
                ? -stake
                : payout || stake,
        createdAt:
            memewalletV2TimestampMs(
                activity?.createdAt
            ) || Date.now(),
        read:
            false
    });

    saveNotifications();
    renderNotifications();

    return true;
}


function memewalletStartPredictionActivityNotificationListener(
    user
) {
    if (
        memewalletPredictionActivityUnsubscribe
    ) {
        memewalletPredictionActivityUnsubscribe();
        memewalletPredictionActivityUnsubscribe = null;
    }

    memewalletPredictionActivityUser =
        user || null;

    if (!user) {
        return;
    }

    const activityRef =
        collection(
            db,
            'users',
            user.uid,
            MEMEWALLET_V2_ACTIVITY_COLLECTION
        );

    memewalletPredictionActivityUnsubscribe =
        onSnapshot(
            activityRef,
            snapshot => {
                snapshot.docs.forEach(
                    activityDoc => {
                        const data =
                            activityDoc.data() || {};

                        memewalletAddPredictionActivityNotification(
                            activityDoc.id,
                            data
                        );
                    }
                );
            },
            error => {
                console.warn(
                    'MEMEWALLET PREDICTION NOTIFICATION LISTENER ERROR',
                    error
                );
            }
        );
}


function memewalletStartPredictionCenterUiBridge() {
    memewalletRefreshPredictionCenterPlacement();

    if (
        memewalletPredictionCenterUiTimer
    ) {
        clearInterval(
            memewalletPredictionCenterUiTimer
        );
    }

    memewalletPredictionCenterUiTimer =
        setInterval(
            () => {
                memewalletRefreshPredictionCenterPlacement();
            },
            750
        );
}


onAuthStateChanged(
    auth,
    user => {
        memewalletStartPredictionActivityNotificationListener(
            user
        );

        memewalletRefreshPredictionCenterPlacement();
    }
);


memewalletStartPredictionCenterUiBridge();


window.__memewalletPredictionCenterNotificationsReady =
    true;

window.__memewalletPredictionCenterVersion =
    MEMEWALLET_PREDICTION_CENTER_VERSION;

console.log(
    'MemeWallet prediction center/notification bridge active:',
    MEMEWALLET_PREDICTION_CENTER_VERSION
);



/* =====================================================================
   MEMEWALLET FAST AUTH CACHE + PER-PREDICTION VOLUME / DRAWER BRIDGE
   ---------------------------------------------------------------------
   Additive only. Existing Gmail/Firebase authentication remains the
   source of truth. localStorage is used only to paint the last-known
   Gmail/profile information immediately while Firebase restores the real
   authenticated session. No password, refresh token, or Firebase
   credential is stored by this bridge.

   Also:
     - keeps every prediction card's drawer explicitly tied to that card
     - shows the real hourly market traded volume on BTC/SOL cards
     - caches the last known market volume for instant first paint
     - updates volume immediately after a successful BUY
===================================================================== */

const MEMEWALLET_FAST_AUTH_CACHE_KEY =
    'memewallet_fast_auth_profile_v2';

const MEMEWALLET_FAST_MARKET_VOLUME_CACHE_KEY =
    'memewallet_fast_market_volume_v2';

let memewalletFastMarketVolumeUnsubscribers = [];
let memewalletFastMarketVolumeCache = {};
let memewalletFastPredictionVolumeObserver = null;
let memewalletFastPredictionVolumeRefreshTimer = null;
let memewalletFastMarketVolumeHourKey = '';


function memewalletFastStorageGetJson(key, fallback = null) {
    try {
        const raw =
            localStorage.getItem(key);

        if (!raw) {
            return fallback;
        }

        const parsed =
            JSON.parse(raw);

        return parsed ?? fallback;
    } catch {
        return fallback;
    }
}


function memewalletFastStorageSetJson(key, value) {
    try {
        localStorage.setItem(
            key,
            JSON.stringify(value)
        );
    } catch {
        // Some browser/private-mode storage implementations can fail.
    }
}


function memewalletFastCacheAuthProfile(user) {
    if (!user) {
        return;
    }

    const previous =
        memewalletFastStorageGetJson(
            MEMEWALLET_FAST_AUTH_CACHE_KEY,
            {}
        ) || {};

    const sameUser =
        String(previous.uid || '') ===
        String(user.uid || '');

    const previousBalance =
        sameUser
            ? Number(previous.walletBalance)
            : NaN;

    memewalletFastStorageSetJson(
        MEMEWALLET_FAST_AUTH_CACHE_KEY,
        {
            uid:
                String(user.uid || ''),
            email:
                String(user.email || ''),
            displayName:
                String(user.displayName || ''),
            photoURL:
                String(user.photoURL || ''),
            walletBalance:
                Number.isFinite(previousBalance)
                    ? Math.max(
                        0,
                        previousBalance
                    )
                    : null,
            cachedAt:
                Date.now()
        }
    );
}


function memewalletFastCacheWalletBalance(
    balance,
    user = currentUser
) {
    const uid =
        String(
            user?.uid ||
            currentUser?.uid ||
            ''
        );

    if (!uid) {
        return;
    }

    const numericBalance =
        Number(balance);

    if (
        !Number.isFinite(numericBalance) ||
        numericBalance < 0
    ) {
        return;
    }

    const previous =
        memewalletFastStorageGetJson(
            MEMEWALLET_FAST_AUTH_CACHE_KEY,
            {}
        ) || {};

    memewalletFastStorageSetJson(
        MEMEWALLET_FAST_AUTH_CACHE_KEY,
        {
            ...previous,
            uid:
                uid,
            email:
                String(
                    user?.email ||
                    previous.email ||
                    ''
                ),
            displayName:
                String(
                    user?.displayName ||
                    previous.displayName ||
                    ''
                ),
            photoURL:
                String(
                    user?.photoURL ||
                    previous.photoURL ||
                    ''
                ),
            walletBalance:
                Math.round(
                    numericBalance * 100
                ) / 100,
            cachedAt:
                Date.now()
        }
    );
}


function memewalletFastGetCachedWalletBalance(
    expectedUid = ''
) {
    const cached =
        memewalletFastStorageGetJson(
            MEMEWALLET_FAST_AUTH_CACHE_KEY,
            null
        );

    if (!cached) {
        return null;
    }

    const cachedUid =
        String(cached.uid || '');

    if (
        expectedUid &&
        cachedUid &&
        cachedUid !== String(expectedUid)
    ) {
        return null;
    }

    const cachedAt =
        Number(cached.cachedAt || 0);

    if (
        cachedAt > 0 &&
        Date.now() - cachedAt >
            30 * 24 * 60 * 60 * 1000
    ) {
        return null;
    }

    const balance =
        Number(cached.walletBalance);

    return Number.isFinite(balance) && balance >= 0
        ? balance
        : null;
}


function memewalletFastApplyCachedWalletBalance(
    expectedUid = ''
) {
    const balance =
        memewalletFastGetCachedWalletBalance(
            expectedUid
        );

    if (balance === null) {
        return false;
    }

    const formattedBalance =
        formatNaira(
            balance
        );

    if (walletBalance) {
        walletBalance.textContent =
            formattedBalance;
    }

    if (headerCashBalance) {
        headerCashBalance.textContent =
            formattedBalance;
    }

    if (profileWalletBalance) {
        profileWalletBalance.textContent =
            formattedBalance;
    }

    return true;
}


function memewalletFastApplyCachedAuthProfile() {
    const cached =
        memewalletFastStorageGetJson(
            MEMEWALLET_FAST_AUTH_CACHE_KEY,
            null
        );

    if (!cached?.uid || !cached?.email) {
        return false;
    }

    /*
     * Keep the cache reasonably fresh, but allow it to paint instantly
     * during normal app reopen/startup.
     */
    const cachedAt =
        Number(cached.cachedAt || 0);

    if (
        cachedAt > 0 &&
        Date.now() - cachedAt >
            30 * 24 * 60 * 60 * 1000
    ) {
        return false;
    }

    try {
        updateUserUI({
            uid:
                cached.uid,
            email:
                cached.email,
            displayName:
                cached.displayName ||
                cached.email.split('@')[0]
        });

        memewalletFastApplyCachedWalletBalance(
            cached.uid
        );

        return true;
    } catch (error) {
        console.warn(
            'MEMEWALLET FAST AUTH CACHE PAINT FAILED',
            error
        );

        return false;
    }
}


/*
 * Paint the cached Gmail/profile before Firebase's auth observer finishes
 * restoring the real local Firebase session.
 */
memewalletFastApplyCachedAuthProfile();


onAuthStateChanged(
    auth,
    user => {
        if (user) {
            /*
             * Paint the last-known balance immediately for this UID, then
             * let the Firestore wallet listener replace it with the live
             * balance as soon as the document arrives.
             */
            memewalletFastApplyCachedWalletBalance(
                user.uid
            );

            memewalletFastCacheAuthProfile(user);
        } else {
            try {
                localStorage.removeItem(
                    MEMEWALLET_FAST_AUTH_CACHE_KEY
                );
            } catch {
                // Ignore storage cleanup failures.
            }
        }
    }
);


/* =====================================================================
   REAL HOURLY MARKET VOLUME
===================================================================== */

function memewalletFastUtcHourStart(
    timestamp = Date.now()
) {
    const value =
        new Date(timestamp);

    value.setUTCMinutes(0, 0, 0);

    return value.getTime();
}


function memewalletFastCurrentMarketId(
    asset
) {
    const safeAsset =
        String(asset || '').toUpperCase();

    if (
        typeof memewalletAdditiveHourlyMarketId ===
        'function'
    ) {
        return memewalletAdditiveHourlyMarketId(
            safeAsset,
            memewalletFastUtcHourStart()
        );
    }

    const d =
        new Date(memewalletFastUtcHourStart());

    const key =
        [
            d.getUTCFullYear(),
            String(d.getUTCMonth() + 1).padStart(2, '0'),
            String(d.getUTCDate()).padStart(2, '0'),
            String(d.getUTCHours()).padStart(2, '0')
        ].join('-');

    return `${safeAsset}_${key}`;
}


function memewalletFastFormatTradedVolume(
    value
) {
    const amount =
        Number(value);

    if (!Number.isFinite(amount) || amount <= 0) {
        return '₦0 traded';
    }

    const rounded =
        Math.round((amount + Number.EPSILON) * 100) / 100;

    return (
        '₦' +
        rounded.toLocaleString(
            'en-NG',
            {
                minimumFractionDigits:
                    rounded % 1 === 0 ? 0 : 2,
                maximumFractionDigits: 2
            }
        ) +
        ' traded'
    );
}


function memewalletFastLoadVolumeCache() {
    const cached =
        memewalletFastStorageGetJson(
            MEMEWALLET_FAST_MARKET_VOLUME_CACHE_KEY,
            {}
        );

    if (
        cached &&
        typeof cached === 'object' &&
        !Array.isArray(cached)
    ) {
        memewalletFastMarketVolumeCache =
            cached;
    } else {
        memewalletFastMarketVolumeCache =
            {};
    }
}


function memewalletFastSaveVolumeCache() {
    memewalletFastStorageSetJson(
        MEMEWALLET_FAST_MARKET_VOLUME_CACHE_KEY,
        memewalletFastMarketVolumeCache
    );
}


function memewalletFastSetMarketVolume(
    marketId,
    volume
) {
    const key =
        String(marketId || '').trim();

    if (!key) {
        return;
    }

    const numeric =
        Number(volume);

    memewalletFastMarketVolumeCache[key] =
        Number.isFinite(numeric)
            ? Math.max(0, numeric)
            : 0;

    memewalletFastSaveVolumeCache();
    memewalletFastApplyPredictionVolumes();
}


function memewalletFastGetCardAsset(
    shell
) {
    const article =
        shell?.querySelector('article');

    if (!article) {
        return '';
    }

    if (
        article.dataset.solanaPrediction ===
        'true'
    ) {
        return 'SOL';
    }

    if (
        article.dataset.bitcoinPrediction ===
        'true'
    ) {
        return 'BTC';
    }

    const title =
        String(
            article.querySelector('h3')?.textContent ||
            ''
        ).toLowerCase();

    if (title.includes('solana')) {
        return 'SOL';
    }

    if (title.includes('bitcoin')) {
        return 'BTC';
    }

    return '';
}


function memewalletFastFindVolumeNode(
    article
) {
    if (!article) {
        return null;
    }

    const existing =
        article.querySelector(
            '[data-memewallet-traded-volume]'
        );

    if (existing) {
        return existing;
    }

    const candidates =
        Array.from(
            article.querySelectorAll('span')
        );

    return (
        candidates.find(
            span =>
                /traded/i.test(
                    String(span.textContent || '')
                )
        ) || null
    );
}


function memewalletFastApplyPredictionVolumes() {
    const shells =
        document.querySelectorAll(
            '[data-prediction-shell]'
        );

    shells.forEach(
        shell => {
            const article =
                shell.querySelector('article');

            if (!article) {
                return;
            }

            const asset =
                memewalletFastGetCardAsset(shell);

            if (!asset) {
                return;
            }

            const marketId =
                memewalletFastCurrentMarketId(asset);

            const cachedVolume =
                memewalletFastMarketVolumeCache[marketId];

            const volumeNode =
                memewalletFastFindVolumeNode(article);

            if (!volumeNode) {
                return;
            }

            volumeNode.dataset.memewalletTradedVolume =
                'true';

            volumeNode.textContent =
                memewalletFastFormatTradedVolume(
                    cachedVolume || 0
                );
        }
    );
}


function memewalletFastEnsurePredictionDrawers() {
    const shells =
        document.querySelectorAll(
            '[data-prediction-shell]'
        );

    shells.forEach(
        (shell, index) => {
            const predictionId =
                String(
                    shell.dataset.predictionId ||
                    `prediction_${index}`
                );

            const drawer =
                shell.querySelector(
                    '[data-trade-role="predictionTradeDrawer"]'
                );

            if (!drawer) {
                return;
            }

            const safeId =
                predictionId.replace(
                    /[^a-zA-Z0-9_-]/g,
                    '_'
                );

            drawer.dataset.memewalletPredictionId =
                predictionId;

            drawer.dataset.memewalletDrawerId =
                `prediction-trade-drawer-${safeId}`;

            if (!drawer.id) {
                drawer.id =
                    `prediction-trade-drawer-${safeId}`;
            }

            drawer.setAttribute(
                'data-prediction-id',
                predictionId
            );
        }
    );
}


function memewalletFastStartPredictionDomBridge() {
    memewalletFastApplyPredictionVolumes();
    memewalletFastEnsurePredictionDrawers();

    const host =
        document.getElementById(
            'cryptoMarketsContent'
        );

    if (
        host &&
        !memewalletFastPredictionVolumeObserver
    ) {
        memewalletFastPredictionVolumeObserver =
            new MutationObserver(
                () => {
                    clearTimeout(
                        memewalletFastPredictionVolumeRefreshTimer
                    );

                    memewalletFastPredictionVolumeRefreshTimer =
                        setTimeout(
                            () => {
                                memewalletFastApplyPredictionVolumes();
                                memewalletFastEnsurePredictionDrawers();
                            },
                            0
                        );
                }
            );

        memewalletFastPredictionVolumeObserver.observe(
            host,
            {
                childList: true,
                subtree: true
            }
        );
    }
}


function memewalletFastStartHourlyMarketVolumeListeners() {
    memewalletFastLoadVolumeCache();
    memewalletFastMarketVolumeHourKey =
        String(memewalletFastUtcHourStart());
    memewalletFastStartPredictionDomBridge();

    memewalletFastMarketVolumeUnsubscribers.forEach(
        unsubscribe => {
            try {
                unsubscribe();
            } catch {
                // Ignore stale listener cleanup failures.
            }
        }
    );

    memewalletFastMarketVolumeUnsubscribers = [];

    ['BTC', 'SOL'].forEach(
        asset => {
            const marketId =
                memewalletFastCurrentMarketId(asset);

            const marketRef =
                doc(
                    db,
                    'hourlyPredictionMarkets',
                    marketId
                );

            const unsubscribe =
                onSnapshot(
                    marketRef,
                    snapshot => {
                        if (!snapshot.exists()) {
                            memewalletFastSetMarketVolume(
                                marketId,
                                0
                            );
                            return;
                        }

                        const data =
                            snapshot.data() || {};

                        memewalletFastSetMarketVolume(
                            marketId,
                            Number(
                                data.volume ??
                                data.tradedVolume ??
                                0
                            )
                        );
                    },
                    error => {
                        console.warn(
                            'MEMEWALLET HOURLY MARKET VOLUME LISTENER FAILED',
                            asset,
                            error
                        );
                    }
                );

            memewalletFastMarketVolumeUnsubscribers.push(
                unsubscribe
            );
        }
    );
}


onAuthStateChanged(
    auth,
    user => {
        if (!user) {
            memewalletFastMarketVolumeUnsubscribers.forEach(
                unsubscribe => {
                    try {
                        unsubscribe();
                    } catch {
                        // Ignore cleanup failures.
                    }
                }
            );

            memewalletFastMarketVolumeUnsubscribers = [];
            return;
        }

        memewalletFastStartHourlyMarketVolumeListeners();
    }
);


/* =====================================================================
   INSTANT VOLUME UPDATE AFTER BUY
===================================================================== */

const memewalletVolumeOriginalTradeBridge =
    window.__memewalletCompletePredictionTrade;

if (
    typeof memewalletVolumeOriginalTradeBridge ===
    'function'
) {
    window.__memewalletCompletePredictionTrade =
        async function (
            tradeInput
        ) {
            const result =
                await memewalletVolumeOriginalTradeBridge(
                    tradeInput
                );

            if (result?.success) {
                const marketId =
                    String(
                        result.marketId ||
                        ''
                    );

                const amount =
                    Number(
                        result.amount ||
                        tradeInput?.amount ||
                        0
                    );

                if (
                    marketId &&
                    Number.isFinite(amount) &&
                    amount > 0
                ) {
                    const previous =
                        Number(
                            memewalletFastMarketVolumeCache[marketId] ||
                            0
                        );

                    memewalletFastSetMarketVolume(
                        marketId,
                        previous + amount
                    );
                }
            }

            return result;
        };
}


/*
 * Keep the per-prediction volume listener alive when the app moves
 * between pages. The actual Firestore listener remains lightweight.
 */
if (
    document.readyState === 'loading'
) {
    document.addEventListener(
        'DOMContentLoaded',
        memewalletFastStartPredictionDomBridge,
        { once: true }
    );
} else {
    memewalletFastStartPredictionDomBridge();
}


console.log(
    'MemeWallet fast Gmail cache + prediction volume/drawer bridge active.'
);



/*
 * The market document changes every UTC hour. Repoint the two lightweight
 * Firestore listeners when a new hour begins so the card never remains
 * attached to yesterday's market volume document.
 */
setInterval(
    () => {
        const hourKey =
            String(
                memewalletFastUtcHourStart()
            );

        if (
            hourKey ===
            memewalletFastMarketVolumeHourKey
        ) {
            return;
        }

        memewalletFastMarketVolumeHourKey =
            hourKey;

        if (auth.currentUser) {
            memewalletFastStartHourlyMarketVolumeListeners();
        }
    },
    10000
);
