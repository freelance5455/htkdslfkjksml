# CGD V117 — Socle 1.8 : Intergalactique des Clubs (AGD)

## Source et responsabilité

Le moteur V116 `CGDClubWorldCup` fournit le format de référence. V116 affichait l'autorité FGD ; V117 applique la décision institutionnelle récente de l'utilisateur : les deux compétitions intergalactiques relèvent de l'AGD.

## Format historique conservé

- Une édition tous les quatre cycles/saisons (4, 8, 12...).
- 32 clubs, 4 chapeaux de 8, 8 groupes de 4.
- Chaque groupe joue trois journées, deux matchs par groupe et par journée : 48 matchs de groupes.
- Les deux premiers de chaque groupe se qualifient : 16 clubs.
- Huitièmes, quarts, demi-finales et finale en match unique : 15 matchs.
- Pas de petite finale. Total : 63 rencontres.
- Tableau croisé conservé : A1 contre B2, C1 contre D2, B1 contre A2, D1 contre C2, puis même principe entre groupes E à H ; cela évite une revanche de groupe avant les demi-finales.
- Éliminations sur terrain neutre ; égalité départagée par prolongation puis tirs au but.
- Licence active et absence de suspension exigées.
- Prime de 2 500 000 Gold au champion, conservée depuis le registre d'administration V116.

## Correction anti-clubs fictifs

Le code V116 complétait artificiellement le tableau avec des noms `Club Astra Nova 1`, `Club Orion 1`, etc. si moins de 32 clubs étaient disponibles. V117 n'utilise plus ces faux participants. Il sélectionne au maximum 32 clubs réellement présents dans les divisions actives et éligibles. Si moins de 32 clubs ont une licence active et ne sont pas suspendus, l'édition est bloquée et indique le nombre manquant.

Le tirage reste réparti en quatre chapeaux ; V117 utilise un tirage déterministe afin qu'une même sauvegarde produise le même tableau. Le classement de sélection repose sur les points, la force moyenne des deux damistes et le budget, car le modèle V117 ne possède pas le champ `fans` utilisé par l'ancienne formule V116.

## Calendrier officiel AGD

La date AGD renseignée est le jour d'ouverture de la fenêtre et du tirage au sort. Le programme historique V116 est respecté : tirage à l'ouverture, puis journées de compétition aux offsets +2, +6, +10, +14, +18, +21 et +24 jours (jours 8, 12, 16, 20, 24, 27 et 30 du mois réservé).

La fenêtre dure donc 24 jours à partir de son ouverture. Si les deux compétitions AGD sont dues la même saison, leurs fenêtres doivent être séparées en fonction de la durée réelle de la première fenêtre, avec au moins un jour complet libre avant l'ouverture de la suivante.

## Intégration V117

- Module : `src/intergalactic-clubs.js`.
- 32 identifiants de clubs réels, sans noms de remplissage.
- Éligibilité par statut de licence et suspension.
- 8 groupes, tables, 48 rencontres, 16 qualifiés, tableau à 15 rencontres.
- Simulation automatique par le moteur commun de dames.
- Le match du club dirigé peut être joué manuellement.
- Résultats inscrits au calendrier central et statistiques propres à la compétition.
- Prolongation et tirs au but déterministes en cas d'égalité.
- Prime du champion : 2 500 000 Gold.
- Anti-double-homologation, historique des champions et contrôles de structure.

## Tests et limites

- Tests métier de l'Intergalactique des Clubs : six scénarios couvrant l'édition quadriennale, le tirage, l'absence de faux clubs, le match manuel, les 63 rencontres et l'anti-doublon.
- Vérification navigateur réelle non certifiée ; Chromium headless n'a pas terminé son exécution dans l'environnement.
- Le moteur Dame d'Or reste à intégrer ; le lancement global de la saison demeure protégé tant que ce moteur et les calendriers officiels nécessaires ne sont pas prêts.

## Vérification finale du socle 1.8

- Suite complète du projet : 126 tests réussis, 0 échec.
- `node --check` réussi pour `intergalactic-clubs.js`, `season-engine.js`, `app.js`, `competition-calendar.js` et `match-ui.js`.
- Archive ZIP contrôlée après création.
- Le test interactif Chromium n'a pas terminé dans l'environnement d'exécution ; la validation navigateur et Android reste donc ouverte.
