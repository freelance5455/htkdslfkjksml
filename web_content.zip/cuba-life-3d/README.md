# CUBA LIFE 3D

**El simulador de vida en Cuba** — Videojuego 3D de mundo abierto en HTML5 / Three.js optimizado para Android.

## Cómo ejecutar

### En el navegador (escritorio o Android)

1. Sirve la carpeta con un servidor local (necesario por los módulos ES):

```bash
# Desde la carpeta cuba-life-3d
npx serve .
# o
python -m http.server 8080
```

2. Abre en el navegador: `http://localhost:3000` (o el puerto que use serve).

3. En Android: abre la misma URL en Chrome, o empaqueta como WebView/APK.

### Controles

**Táctil (Android):**
- Joystick izquierdo → mover
- 🏃 Correr
- ⬆️ Saltar
- ✋ Interactuar (hablar / comprar)
- 🚗 Entrar/salir de vehículo (aparece cerca de uno)

**Teclado:**
- WASD / Flechas → mover
- Shift → correr
- Espacio → saltar
- E → interactuar
- F → entrar/salir vehículo

## Sistemas implementados

| Sistema | Estado |
|---------|--------|
| Ciclo de apagones (5 min ON / 20 min OFF) | ✅ Completo y persistente |
| Reloj interno + día/noche | ✅ |
| Economía CUP + tiendas | ✅ |
| Inventario + uso de objetos | ✅ |
| Comida cubana (congrí, ropa vieja, tostones...) | ✅ |
| Gasolina / aceite / lubricantes | ✅ |
| Vehículos (Lada, clásico, moto) + conducción | ✅ |
| NPCs con diálogos y reacción a apagones | ✅ |
| Misiones | ✅ |
| Guardado / carga (localStorage) | ✅ |
| Interfaz completa + teléfono virtual | ✅ |
| Controles táctiles | ✅ |
| Clima básico | ✅ |
| Negocios propios | ✅ (compra y generación de ingresos) |
| Mapa de zonas de Cuba | ✅ (visual + marcadores) |

## Convertir a APK

Lee el archivo **APK-INSTRUCCIONES.md** (está en esta misma carpeta).

Ahí tienes 3 métodos claros y paso a paso:

1. **PWABuilder** → la forma más fácil (online, sin instalar nada)
2. **Capacitor** → la más profesional
3. **WebView nativo** en Android Studio

El `index.html` ya está en la **raíz** del proyecto y listo para empaquetar.

## Estructura del proyecto

```
cuba-life-3d/
├── index.html
├── css/style.css
├── js/
│   ├── main.js
│   ├── Game.js
│   ├── UI.js
│   ├── InputManager.js
│   ├── systems/
│   │   ├── PowerSystem.js      ← Ciclo de electricidad
│   │   ├── TimeSystem.js
│   │   ├── Economy.js
│   │   ├── Inventory.js
│   │   ├── MissionSystem.js
│   │   ├── WeatherSystem.js
│   │   └── SaveSystem.js
│   ├── entities/
│   │   ├── Player.js
│   │   ├── NPCManager.js
│   │   └── VehicleManager.js
│   └── world/
│       └── World.js
└── README.md
```

## Notas de autenticidad

El juego ofrece una representación **ficticia y respetuosa** inspirada en la vida cotidiana cubana contemporánea (arquitectura, gastronomía, transporte, apagones, economía informal de combustible, etc.). No pretende ser un simulador político ni histórico literal. Los nombres de provincias y barrios se usan de forma reconocible pero el mapa es modular y jugable, no una reproducción exacta de la geografía real.

## Rendimiento en Android

- Calidad gráfica configurable (Baja / Media / Alta)
- Límite de NPCs activos
- Sombras y pixel ratio adaptativos
- Recomendado: dispositivos con al menos 3 GB de RAM

¡Disfruta de La Habana virtual y sobrevive a los apagones!
