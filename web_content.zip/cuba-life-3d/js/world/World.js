/**
 * World - Modular zones inspired by Cuban cities
 * Centro Habana as starting playable area + travel markers
 */
import * as THREE from 'three';

export class World {
  constructor(game) {
    this.game = game;
    this.buildings = [];
    this.streetLights = [];
    this.interactables = [];
    this.zones = this.defineZones();
    this.currentZone = 'centro-habana';
    this.ground = null;
  }

  defineZones() {
    return {
      'centro-habana': { name: 'Centro Habana', x: 0, z: 0, color: 0x4a90d9 },
      'habana-vieja': { name: 'Habana Vieja', x: -60, z: 20, color: 0xc9a66b },
      'vedado': { name: 'Vedado', x: 50, z: 40, color: 0x5dade2 },
      'miramar': { name: 'Miramar', x: 80, z: 10, color: 0x58d68d },
      'playa': { name: 'Playa', x: 70, z: -40, color: 0xf5b041 },
      'santiago': { name: 'Santiago de Cuba', x: 200, z: 300, color: 0xe74c3c },
      'varadero': { name: 'Varadero', x: 100, z: -80, color: 0x1abc9c },
      'trinidad': { name: 'Trinidad', x: 120, z: 150, color: 0xd4a017 },
      'pinar': { name: 'Pinar del Río', x: -150, z: 50, color: 0x27ae60 },
      'matanzas': { name: 'Matanzas', x: 60, z: -60, color: 0x8e44ad }
    };
  }

  async build() {
    // Ground
    const groundGeo = new THREE.PlaneGeometry(200, 200);
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x5a5a5a, roughness: 0.9 });
    this.ground = new THREE.Mesh(groundGeo, groundMat);
    this.ground.rotation.x = -Math.PI / 2;
    this.ground.receiveShadow = true;
    this.game.scene.add(this.ground);

    // Roads
    this.createRoads();

    // Buildings - Centro Habana style (colonial + soviet mix)
    this.createBuildings();

    // Street furniture & lights
    this.createStreetLights();

    // Shops markers
    this.createShopMarkers();

    // Vegetation
    this.createTrees();

    // Zone travel points (distant markers)
    this.createZoneMarkers();
  }

  createRoads() {
    const roadMat = new THREE.MeshStandardMaterial({ color: 0x333333 });
    // Main avenues
    const road1 = new THREE.Mesh(new THREE.PlaneGeometry(12, 180), roadMat);
    road1.rotation.x = -Math.PI / 2;
    road1.position.set(0, 0.02, 0);
    this.game.scene.add(road1);

    const road2 = new THREE.Mesh(new THREE.PlaneGeometry(180, 10), roadMat);
    road2.rotation.x = -Math.PI / 2;
    road2.position.set(0, 0.02, 0);
    this.game.scene.add(road2);

    // Sidewalks
    const sideMat = new THREE.MeshStandardMaterial({ color: 0x888888 });
    for (let i = -1; i <= 1; i += 2) {
      const side = new THREE.Mesh(new THREE.PlaneGeometry(3, 180), sideMat);
      side.rotation.x = -Math.PI / 2;
      side.position.set(i * 7.5, 0.03, 0);
      this.game.scene.add(side);
    }
  }

  createBuildings() {
    const colors = [0xd4a574, 0xe8d5b7, 0xc9b896, 0xa67c52, 0x8b7355, 0xf5e6c8, 0x7d6b5a];
    const roofColors = [0x8b4513, 0x654321, 0x5c4033, 0x3d2b1f];

    // Grid of buildings around main streets
    for (let gx = -4; gx <= 4; gx++) {
      for (let gz = -4; gz <= 4; gz++) {
        if (Math.abs(gx) < 1 && Math.abs(gz) < 1) continue; // leave center open
        if (Math.random() < 0.25) continue;

        const x = gx * 14 + (Math.random() - 0.5) * 3;
        const z = gz * 14 + (Math.random() - 0.5) * 3;
        const w = 4 + Math.random() * 5;
        const d = 4 + Math.random() * 5;
        const h = 4 + Math.random() * 10;

        const geo = new THREE.BoxGeometry(w, h, d);
        const mat = new THREE.MeshStandardMaterial({
          color: colors[Math.floor(Math.random() * colors.length)],
          roughness: 0.85
        });
        const b = new THREE.Mesh(geo, mat);
        b.position.set(x, h / 2, z);
        b.castShadow = true;
        b.receiveShadow = true;
        this.game.scene.add(b);
        this.buildings.push(b);

        // Simple roof
        const roof = new THREE.Mesh(
          new THREE.BoxGeometry(w + 0.3, 0.4, d + 0.3),
          new THREE.MeshStandardMaterial({ color: roofColors[Math.floor(Math.random() * roofColors.length)] })
        );
        roof.position.set(x, h + 0.2, z);
        this.game.scene.add(roof);

        // Windows (emissive when power on)
        if (h > 5) {
          for (let floor = 1; floor < h / 2.2; floor++) {
            const win = new THREE.Mesh(
              new THREE.PlaneGeometry(0.6, 0.8),
              new THREE.MeshStandardMaterial({
                color: 0x88ccff,
                emissive: 0x224466,
                emissiveIntensity: 0.3
              })
            );
            win.position.set(x + w / 2 + 0.01, floor * 2.2, z);
            win.rotation.y = -Math.PI / 2;
            win.userData.isWindow = true;
            this.game.scene.add(win);
            this.buildings.push(win);
          }
        }
      }
    }

    // Special buildings: Bodega, CUPET, etc.
    this.createLandmark(12, -8, 6, 4, 5, 0xc0392b, 'Bodega El Centro');
    this.createLandmark(-18, 15, 8, 5, 4, 0xf1c40f, 'Servicentro CUPET');
    this.createLandmark(5, 22, 5, 4, 4, 0x7f8c8d, 'Ferretería');
  }

  createLandmark(x, z, w, d, h, color, name) {
    const geo = new THREE.BoxGeometry(w, h, d);
    const mat = new THREE.MeshStandardMaterial({ color });
    const b = new THREE.Mesh(geo, mat);
    b.position.set(x, h / 2, z);
    b.castShadow = true;
    b.userData.interactable = true;
    b.userData.name = name;
    this.game.scene.add(b);
    this.buildings.push(b);
    this.interactables.push({
      mesh: b,
      name,
      type: 'shop',
      action: () => this.game.ui.openShopNear(name)
    });
  }

  createStreetLights() {
    for (let i = -70; i <= 70; i += 18) {
      this.addStreetLight(i, 6);
      this.addStreetLight(i, -6);
      this.addStreetLight(6, i);
      this.addStreetLight(-6, i);
    }
  }

  addStreetLight(x, z) {
    const pole = new THREE.Mesh(
      new THREE.CylinderGeometry(0.08, 0.1, 5, 6),
      new THREE.MeshStandardMaterial({ color: 0x333333 })
    );
    pole.position.set(x, 2.5, z);
    this.game.scene.add(pole);

    const lamp = new THREE.Mesh(
      new THREE.SphereGeometry(0.25, 8, 8),
      new THREE.MeshStandardMaterial({
        color: 0xffeeaa,
        emissive: 0xffcc66,
        emissiveIntensity: 0.8
      })
    );
    lamp.position.set(x, 5.1, z);
    lamp.userData.isLight = true;
    this.game.scene.add(lamp);
    this.streetLights.push(lamp);

    // Point light (performance: limited)
    if (this.streetLights.length < 12) {
      const pl = new THREE.PointLight(0xffeeaa, 0.6, 18);
      pl.position.set(x, 5, z);
      pl.userData.isLight = true;
      this.game.scene.add(pl);
      this.streetLights.push(pl);
    }
  }

  createShopMarkers() {
    // Already handled via landmarks
  }

  createTrees() {
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x5d4037 });
    const leafMat = new THREE.MeshStandardMaterial({ color: 0x2e7d32 });
    for (let i = 0; i < 40; i++) {
      const x = (Math.random() - 0.5) * 160;
      const z = (Math.random() - 0.5) * 160;
      if (Math.abs(x) < 10 && Math.abs(z) < 10) continue;

      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.3, 2.5, 6), trunkMat);
      trunk.position.set(x, 1.25, z);
      this.game.scene.add(trunk);

      const leaves = new THREE.Mesh(new THREE.SphereGeometry(1.4, 8, 8), leafMat);
      leaves.position.set(x, 3.2, z);
      this.game.scene.add(leaves);
    }
  }

  createZoneMarkers() {
    // Visual markers for distant zones (simplified travel)
    for (const [id, z] of Object.entries(this.zones)) {
      if (id === 'centro-habana') continue;
      const marker = new THREE.Mesh(
        new THREE.CylinderGeometry(0.5, 0.5, 8, 8),
        new THREE.MeshStandardMaterial({ color: z.color, emissive: z.color, emissiveIntensity: 0.3 })
      );
      // Place at scaled position for visibility
      const scale = 0.3;
      marker.position.set(z.x * scale, 4, z.z * scale);
      marker.userData.zoneId = id;
      marker.userData.interactable = true;
      marker.userData.name = z.name;
      this.game.scene.add(marker);
    }
  }

  setLights(on) {
    for (const l of this.streetLights) {
      if (l.isLight) {
        l.intensity = on ? 0.6 : 0;
      } else if (l.material) {
        l.material.emissiveIntensity = on ? 0.8 : 0.05;
      }
    }
    // Building windows
    for (const b of this.buildings) {
      if (b.userData.isWindow && b.material) {
        b.material.emissiveIntensity = on ? 0.4 : 0.02;
      }
    }
  }

  onPowerChange(isOn) {
    this.setLights(isOn);
  }

  update(dt) {
    // Future: dynamic loading of zones
  }

  getNearbyInteractable(playerPos, radius = 3) {
    for (const inter of this.interactables) {
      const d = playerPos.distanceTo(inter.mesh.position);
      if (d < radius) return inter;
    }
    return null;
  }
}
