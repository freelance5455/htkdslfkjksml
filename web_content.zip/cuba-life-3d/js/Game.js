/**
 * CUBA LIFE 3D - Core Game Engine
 */
import * as THREE from 'three';
import { PowerSystem } from './systems/PowerSystem.js';
import { TimeSystem } from './systems/TimeSystem.js';
import { Economy } from './systems/Economy.js';
import { Inventory } from './systems/Inventory.js';
import { Player } from './entities/Player.js';
import { World } from './world/World.js';
import { NPCManager } from './entities/NPCManager.js';
import { VehicleManager } from './entities/VehicleManager.js';
import { MissionSystem } from './systems/MissionSystem.js';
import { WeatherSystem } from './systems/WeatherSystem.js';
import { SaveSystem } from './systems/SaveSystem.js';
import { InputManager } from './InputManager.js';

export class Game {
  constructor(ui) {
    this.ui = ui;
    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.clock = new THREE.Clock();
    this.running = false;
    this.quality = 'medium';
    this.renderDistance = 150;

    // Systems
    this.power = new PowerSystem(this);
    this.time = new TimeSystem(this);
    this.economy = new Economy(this);
    this.inventory = new Inventory(this);
    this.missions = new MissionSystem(this);
    this.weather = new WeatherSystem(this);
    this.save = new SaveSystem(this);
    this.input = new InputManager(this);

    // Entities
    this.player = null;
    this.world = null;
    this.npcs = null;
    this.vehicles = null;

    // State
    this.playerData = {
      name: 'Carlos',
      money: 250,
      bank: 0,
      hunger: 80,
      thirst: 75,
      energy: 90,
      health: 100,
      reputation: 50,
      skinColor: '#C68642',
      clothes: 'casual',
      position: { x: 0, y: 1, z: 0 },
      zone: 'centro-habana'
    };
  }

  async init() {
    // Renderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: this.quality !== 'low',
      powerPreference: 'high-performance',
      alpha: false
    });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, this.quality === 'low' ? 1 : 1.5));
    this.renderer.shadowMap.enabled = this.quality !== 'low';
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setClearColor(0x87CEEB);
    document.body.appendChild(this.renderer.domElement);

    // Scene & Camera
    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.Fog(0x87CEEB, 40, this.renderDistance);

    this.camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 400);
    this.camera.position.set(0, 8, 12);

    // Lights
    this.ambientLight = new THREE.AmbientLight(0xffffff, 0.55);
    this.scene.add(this.ambientLight);

    this.sunLight = new THREE.DirectionalLight(0xfff5e0, 1.1);
    this.sunLight.position.set(50, 80, 30);
    this.sunLight.castShadow = this.quality !== 'low';
    this.sunLight.shadow.mapSize.width = this.quality === 'high' ? 2048 : 1024;
    this.sunLight.shadow.mapSize.height = this.quality === 'high' ? 2048 : 1024;
    this.sunLight.shadow.camera.near = 1;
    this.sunLight.shadow.camera.far = 200;
    this.sunLight.shadow.camera.left = -60;
    this.sunLight.shadow.camera.right = 60;
    this.sunLight.shadow.camera.top = 60;
    this.sunLight.shadow.camera.bottom = -60;
    this.scene.add(this.sunLight);

    // Hemisphere for better ambient
    this.hemi = new THREE.HemisphereLight(0x87CEEB, 0x444422, 0.35);
    this.scene.add(this.hemi);

    // World
    this.world = new World(this);
    await this.world.build();

    // Player
    this.player = new Player(this);
    this.scene.add(this.player.mesh);

    // NPCs & Vehicles
    this.npcs = new NPCManager(this);
    this.vehicles = new VehicleManager(this);

    // Input
    this.input.init();

    // Resize
    window.addEventListener('resize', () => this.onResize());

    // Initial missions
    this.missions.generateStarterMissions();
  }

  startNewGame(name, skin, clothes) {
    this.playerData.name = name;
    this.playerData.skinColor = skin;
    this.playerData.clothes = clothes;
    this.playerData.money = 250;
    this.playerData.bank = 0;
    this.playerData.hunger = 80;
    this.playerData.thirst = 75;
    this.playerData.energy = 90;
    this.playerData.health = 100;
    this.playerData.reputation = 50;
    this.playerData.position = { x: 0, y: 1, z: 0 };
    this.playerData.zone = 'centro-habana';

    this.player.setAppearance(skin, clothes);
    this.player.mesh.position.set(0, 1, 0);
    this.inventory.reset();
    this.inventory.addItem('dinero', 250);
    this.inventory.addItem('pan_cubano', 2);
    this.inventory.addItem('agua', 1);
    this.inventory.addItem('linterna', 1);
    this.economy.reset();
    this.power.reset();
    this.time.reset();
    this.missions.reset();
    this.missions.generateStarterMissions();
    this.npcs.spawnZoneNPCs('centro-habana');
    this.vehicles.spawnZoneVehicles('centro-habana');
    this.ui.notify(`¡Bienvenido a La Habana, ${name}!`, 4000);
  }

  start() {
    this.running = true;
    this.clock.start();
    this.power.start();
    this.time.start();
    this.animate();
  }

  animate() {
    if (!this.running) return;
    requestAnimationFrame(() => this.animate());

    const dt = Math.min(this.clock.getDelta(), 0.05); // cap delta

    // Systems update (order matters)
    this.power.update(dt);
    this.time.update(dt);
    this.weather.update(dt);
    this.input.update(dt);
    this.player.update(dt);
    this.npcs.update(dt);
    this.vehicles.update(dt);
    this.missions.update(dt);
    this.world.update(dt);

    // Needs drain
    this.updateNeeds(dt);

    // Camera follow
    this.updateCamera(dt);

    // UI
    this.ui.update(dt);

    // Render
    this.renderer.render(this.scene, this.camera);
  }

  updateNeeds(dt) {
    const rate = dt * 0.15; // slow drain
    this.playerData.hunger = Math.max(0, this.playerData.hunger - rate * 0.8);
    this.playerData.thirst = Math.max(0, this.playerData.thirst - rate * 1.1);
    this.playerData.energy = Math.max(0, this.playerData.energy - rate * 0.4);

    if (this.playerData.hunger < 15 || this.playerData.thirst < 15) {
      this.playerData.health = Math.max(0, this.playerData.health - rate * 2);
    }
    if (this.playerData.health <= 0) {
      this.ui.notify('¡Estás muy débil! Busca comida y agua.', 3000);
      this.playerData.health = 5;
    }
  }

  updateCamera(dt) {
    const p = this.player.mesh.position;
    const target = new THREE.Vector3(p.x, p.y + 6, p.z + 10);
    this.camera.position.lerp(target, 4 * dt);
    this.camera.lookAt(p.x, p.y + 1.2, p.z);
  }

  onResize() {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  }

  // Public helpers used by other systems
  getMoney() { return this.playerData.money; }
  addMoney(amount) {
    this.playerData.money += amount;
    this.ui.updateMoney();
    if (amount > 0) this.ui.notify(`+${amount} CUP`, 2000);
    else this.ui.notify(`${amount} CUP`, 2000);
  }
  spendMoney(amount) {
    if (this.playerData.money >= amount) {
      this.playerData.money -= amount;
      this.ui.updateMoney();
      return true;
    }
    this.ui.notify('No tienes suficiente dinero', 2500);
    return false;
  }

  isPowerOn() { return this.power.isOn; }

  notify(msg, duration = 3000) {
    this.ui.notify(msg, duration);
  }

  saveGame() {
    return this.save.save();
  }

  loadGame() {
    return this.save.load();
  }

  setQuality(q) {
    this.quality = q;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, q === 'low' ? 1 : q === 'high' ? 2 : 1.5));
    this.renderer.shadowMap.enabled = q !== 'low';
    this.sunLight.castShadow = q !== 'low';
  }
}
