/**
 * CUBA LIFE 3D - Main Entry Point
 * Full systems: Power cycle, economy, world, NPCs, vehicles, save, UI
 */

import * as THREE from 'three';
import { Game } from './Game.js';
import { UI } from './UI.js';

let game = null;
let ui = null;

// Loading progress helper
function setProgress(pct, text) {
  const fill = document.getElementById('progress-fill');
  const txt = document.getElementById('loading-text');
  if (fill) fill.style.width = pct + '%';
  if (txt) txt.textContent = text;
}

async function init() {
  setProgress(10, 'Inicializando motor 3D...');
  await new Promise(r => setTimeout(r, 200));

  setProgress(30, 'Cargando sistemas de juego...');
  ui = new UI();
  game = new Game(ui);
  window.game = game; // debug

  setProgress(60, 'Generando mundo de La Habana...');
  await game.init();

  setProgress(90, 'Preparando interfaz...');
  ui.bindGame(game);

  setProgress(100, '¡Listo!');
  await new Promise(r => setTimeout(r, 400));

  document.getElementById('loading-screen').style.display = 'none';
  document.getElementById('start-menu').style.display = 'flex';

  // Menu handlers
  document.getElementById('btn-new-game').onclick = () => {
    document.getElementById('character-creator').classList.remove('hidden');
    document.getElementById('btn-new-game').style.display = 'none';
    document.getElementById('btn-continue').style.display = 'none';
  };

  document.getElementById('btn-continue').onclick = () => {
    if (game.loadGame()) {
      startGame();
    } else {
      alert('No hay partida guardada.');
    }
  };

  document.getElementById('btn-start').onclick = () => {
    const name = document.getElementById('player-name').value.trim() || 'Carlos';
    const skin = document.getElementById('skin-color').value;
    const clothes = document.getElementById('clothes').value;
    game.startNewGame(name, skin, clothes);
    startGame();
  };
}

function startGame() {
  document.getElementById('start-menu').style.display = 'none';
  document.getElementById('ui-root').style.display = 'block';
  game.start();
}

// Prevent default touch behaviors that break controls
document.addEventListener('touchmove', e => {
  if (e.target.closest('#joystick-zone') || e.target.closest('.action-btn')) {
    e.preventDefault();
  }
}, { passive: false });

window.addEventListener('load', init);
