/**
 * Time System - Day/Night cycle, calendar
 * 1 real second ≈ 1 game minute for playable pacing
 */
export class TimeSystem {
  constructor(game) {
    this.game = game;
    this.day = 1;
    this.month = 1;
    this.year = 2026;
    this.hour = 8;
    this.minute = 0;
    this.second = 0;
    this.speed = 60; // 1 real sec = 60 game sec → 1 real min ≈ 1 game hour
    this.running = false;
    this.totalGameSeconds = 8 * 3600; // start at 08:00
    this.weekDays = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
    this.months = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
  }

  start() { this.running = true; }
  reset() {
    this.day = 1; this.month = 1; this.year = 2026;
    this.hour = 8; this.minute = 0;
    this.totalGameSeconds = 8 * 3600;
  }

  update(dt) {
    if (!this.running) return;
    this.totalGameSeconds += dt * this.speed;
    this.recalc();
    this.applyLighting();
    this.updateUI();
  }

  recalc() {
    const total = Math.floor(this.totalGameSeconds);
    this.second = total % 60;
    const totalMin = Math.floor(total / 60);
    this.minute = totalMin % 60;
    const totalHour = Math.floor(totalMin / 60);
    this.hour = totalHour % 24;
    const totalDays = Math.floor(totalHour / 24);
    this.day = (totalDays % 30) + 1;
    this.month = (Math.floor(totalDays / 30) % 12) + 1;
  }

  applyLighting() {
    // Day/night intensity based on hour
    const h = this.hour + this.minute / 60;
    let sunIntensity = 0;
    let ambient = 0.1;
    let skyColor = 0x0a0a20;

    if (h >= 5.5 && h < 7) { // dawn
      const t = (h - 5.5) / 1.5;
      sunIntensity = t * 0.9;
      ambient = 0.15 + t * 0.35;
      skyColor = 0xff9966;
    } else if (h >= 7 && h < 17.5) { // day
      sunIntensity = 1.1;
      ambient = 0.55;
      skyColor = 0x87CEEB;
    } else if (h >= 17.5 && h < 19.5) { // dusk
      const t = (h - 17.5) / 2;
      sunIntensity = 1.1 * (1 - t);
      ambient = 0.55 - t * 0.4;
      skyColor = 0xff6644;
    } else { // night
      sunIntensity = 0.05;
      ambient = 0.12;
      skyColor = 0x0a0a28;
    }

    // Blackout overrides
    if (!this.game.power.isOn) {
      sunIntensity *= 0.15;
      ambient = Math.min(ambient, 0.12);
    }

    if (this.game.sunLight) this.game.sunLight.intensity = sunIntensity;
    if (this.game.ambientLight) this.game.ambientLight.intensity = ambient;
    if (this.game.renderer) this.game.renderer.setClearColor(skyColor);
    if (this.game.scene?.fog) this.game.scene.fog.color.setHex(skyColor);
  }

  updateUI() {
    const el = document.getElementById('time-value');
    if (!el) return;
    const h = String(this.hour).padStart(2, '0');
    const m = String(this.minute).padStart(2, '0');
    const wd = this.weekDays[(this.day + 2) % 7]; // rough
    el.textContent = `${h}:${m} · ${wd} Día ${this.day}`;
  }

  getSeason() {
    if (this.month >= 5 && this.month <= 10) return 'Lluviosa';
    return 'Seca';
  }

  serialize() {
    return { totalGameSeconds: this.totalGameSeconds, day: this.day, month: this.month, year: this.year };
  }
  deserialize(d) {
    this.totalGameSeconds = d.totalGameSeconds || 8 * 3600;
    this.day = d.day || 1;
    this.month = d.month || 1;
    this.year = d.year || 2026;
    this.recalc();
  }
}
