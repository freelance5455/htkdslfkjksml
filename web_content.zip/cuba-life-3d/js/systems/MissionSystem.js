/**
 * Mission System - procedural + designed missions
 */
export class MissionSystem {
  constructor(game) {
    this.game = game;
    this.active = [];
    this.completed = [];
    this.idCounter = 1;
  }

  reset() {
    this.active = [];
    this.completed = [];
    this.idCounter = 1;
  }

  generateStarterMissions() {
    this.addMission({
      title: 'Primeros pasos en La Habana',
      description: 'Compra pan y agua en la bodega. Explora el barrio.',
      type: 'tutorial',
      objectives: [
        { id: 'buy_bread', text: 'Comprar pan cubano', done: false },
        { id: 'buy_water', text: 'Comprar agua', done: false }
      ],
      reward: { money: 100, items: { cafe: 1 } },
      zone: 'centro-habana'
    });

    this.addMission({
      title: 'Buscar trabajo',
      description: 'Habla con el dueño de la cafetería o visita el taller mecánico.',
      type: 'job',
      objectives: [
        { id: 'talk_job', text: 'Preguntar por empleo', done: false }
      ],
      reward: { money: 50 },
      zone: 'centro-habana'
    });

    this.addMission({
      title: 'Prepararse para el apagón',
      description: 'Consigue una linterna antes de que se vaya la luz.',
      type: 'survival',
      objectives: [
        { id: 'get_flashlight', text: 'Tener una linterna', done: false }
      ],
      reward: { money: 80, items: { bateria: 1 } }
    });
  }

  addMission(data) {
    const m = {
      id: this.idCounter++,
      status: 'active',
      ...data
    };
    this.active.push(m);
    this.game.ui?.refreshMissions();
    return m;
  }

  completeObjective(missionId, objId) {
    const m = this.active.find(x => x.id === missionId);
    if (!m) return;
    const obj = m.objectives.find(o => o.id === objId);
    if (obj && !obj.done) {
      obj.done = true;
      this.game.notify(`Objetivo completado: ${obj.text}`);
      if (m.objectives.every(o => o.done)) {
        this.completeMission(m);
      }
      this.game.ui?.refreshMissions();
    }
  }

  completeMission(m) {
    m.status = 'completed';
    this.active = this.active.filter(x => x.id !== m.id);
    this.completed.push(m);

    if (m.reward?.money) this.game.addMoney(m.reward.money);
    if (m.reward?.items) {
      for (const [id, qty] of Object.entries(m.reward.items)) {
        this.game.inventory.addItem(id, qty);
      }
    }
    this.game.notify(`¡Misión completada: ${m.title}!`);
    this.game.playerData.reputation = Math.min(100, this.game.playerData.reputation + 5);
    this.game.ui?.refreshMissions();

    // Chain next missions
    this.maybeGenerateNext(m);
  }

  maybeGenerateNext(prev) {
    if (prev.type === 'tutorial') {
      this.addMission({
        title: 'Ganar un poco de dinero',
        description: 'Trabaja una hora como dependiente o vende algo en la calle.',
        type: 'job',
        objectives: [{ id: 'earn_200', text: 'Ganar 200 CUP', done: false, track: 'money' }],
        reward: { money: 150 }
      });
    }
  }

  onItemBought(itemId) {
    for (const m of this.active) {
      if (itemId === 'pan_cubano') this.completeObjective(m.id, 'buy_bread');
      if (itemId === 'agua') this.completeObjective(m.id, 'buy_water');
      if (itemId === 'linterna') this.completeObjective(m.id, 'get_flashlight');
    }
  }

  onBusinessOpened(type) {
    // future
  }

  update(dt) {
    // Track money goals etc.
    for (const m of this.active) {
      for (const obj of m.objectives) {
        if (obj.track === 'money' && !obj.done && this.game.playerData.money >= 450) {
          // rough
          this.completeObjective(m.id, obj.id);
        }
      }
    }
  }

  serialize() {
    return { active: this.active, completed: this.completed, idCounter: this.idCounter };
  }
  deserialize(d) {
    this.active = d.active || [];
    this.completed = d.completed || [];
    this.idCounter = d.idCounter || 1;
  }
}
