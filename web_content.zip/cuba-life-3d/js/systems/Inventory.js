/**
 * Inventory System
 */
export class Inventory {
  constructor(game) {
    this.game = game;
    this.slots = {}; // itemId -> quantity
    this.maxSlots = 30;
    this.selected = null;

    this.itemDefs = {
      dinero: { name: 'Dinero', icon: '💵', usable: false },
      arroz: { name: 'Arroz', icon: '🍚', usable: true, hunger: 15 },
      frijoles: { name: 'Frijoles', icon: '🫘', usable: true, hunger: 18 },
      pan_cubano: { name: 'Pan Cubano', icon: '🥖', usable: true, hunger: 12 },
      agua: { name: 'Agua', icon: '💧', usable: true, thirst: 30 },
      cafe: { name: 'Café', icon: '☕', usable: true, energy: 20, thirst: 5 },
      ropa_vieja: { name: 'Ropa Vieja', icon: '🍲', usable: true, hunger: 40 },
      congris: { name: 'Congrí', icon: '🍛', usable: true, hunger: 35 },
      tostones: { name: 'Tostones', icon: '🍌', usable: true, hunger: 20 },
      yuca: { name: 'Yuca', icon: '🥔', usable: true, hunger: 18 },
      maduros: { name: 'Maduros', icon: '🍌', usable: true, hunger: 15 },
      croquetas: { name: 'Croquetas', icon: '🧆', usable: true, hunger: 22 },
      jugo: { name: 'Jugo', icon: '🧃', usable: true, thirst: 25 },
      batido: { name: 'Batido', icon: '🥤', usable: true, thirst: 20, hunger: 10 },
      cerdo: { name: 'Cerdo Asado', icon: '🥩', usable: true, hunger: 50 },
      gasolina: { name: 'Gasolina', icon: '⛽', usable: false },
      diesel: { name: 'Diésel', icon: '🛢️', usable: false },
      aceite_motor: { name: 'Aceite de Motor', icon: '🧴', usable: false },
      lubricante: { name: 'Lubricante', icon: '🛢️', usable: false },
      linterna: { name: 'Linterna', icon: '🔦', usable: true },
      bateria: { name: 'Batería', icon: '🔋', usable: false },
      generador: { name: 'Generador', icon: '🔌', usable: true },
      panel_solar: { name: 'Panel Solar', icon: '☀️', usable: true },
      camisa: { name: 'Camisa', icon: '👕', usable: true },
      pantalon: { name: 'Pantalón', icon: '👖', usable: true },
      zapatos: { name: 'Zapatos', icon: '👟', usable: true },
      gorra: { name: 'Gorra', icon: '🧢', usable: true },
      llaves_moto: { name: 'Llaves de Moto', icon: '🔑', usable: false },
      herramientas: { name: 'Herramientas', icon: '🔧', usable: false }
    };
  }

  reset() {
    this.slots = {};
    this.selected = null;
  }

  addItem(id, qty = 1) {
    if (!this.itemDefs[id]) {
      this.itemDefs[id] = { name: id, icon: '📦', usable: false };
    }
    this.slots[id] = (this.slots[id] || 0) + qty;
    this.game.ui?.refreshInventory();
  }

  removeItem(id, qty = 1) {
    if (!this.slots[id] || this.slots[id] < qty) return false;
    this.slots[id] -= qty;
    if (this.slots[id] <= 0) delete this.slots[id];
    this.game.ui?.refreshInventory();
    return true;
  }

  hasItem(id, qty = 1) {
    return (this.slots[id] || 0) >= qty;
  }

  getCount(id) {
    return this.slots[id] || 0;
  }

  useItem(id) {
    const def = this.itemDefs[id];
    if (!def || !def.usable || !this.hasItem(id)) return false;

    const pd = this.game.playerData;
    if (def.hunger) pd.hunger = Math.min(100, pd.hunger + def.hunger);
    if (def.thirst) pd.thirst = Math.min(100, pd.thirst + def.thirst);
    if (def.energy) pd.energy = Math.min(100, pd.energy + def.energy);

    this.removeItem(id, 1);
    this.game.notify(`Usaste ${def.name}`);
    this.game.ui.updateNeeds();
    return true;
  }

  getItems() {
    return Object.entries(this.slots).map(([id, qty]) => ({
      id, qty, ...this.itemDefs[id]
    }));
  }

  serialize() {
    return { slots: { ...this.slots } };
  }
  deserialize(d) {
    this.slots = d.slots || {};
  }
}
