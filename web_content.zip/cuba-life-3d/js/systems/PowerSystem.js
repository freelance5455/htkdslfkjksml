/**
 * CUBA LIFE 3D - Power / Blackout System
 * Exact cycle: 5 minutes ON → 20 minutes OFF → repeat
 * Timer is real-time based (performance.now), independent of FPS
 */

export class PowerSystem {
  constructor(game) {
    this.game = game;
    this.isOn = true;
    this.cycleStart = 0;          // performance.now() when current phase started
    this.onDuration = 5 * 60 * 1000;   // 5 minutes in ms
    this.offDuration = 20 * 60 * 1000; // 20 minutes in ms
    this.running = false;
    this.lastAnnouncement = 0;
  }

  start() {
    this.running = true;
    this.cycleStart = performance.now();
    this.isOn = true;
    this.updateUI();
  }

  reset() {
    this.isOn = true;
    this.cycleStart = performance.now();
    this.lastAnnouncement = 0;
    this.updateUI();
    this.applyWorldState();
  }

  update(dt) {
    if (!this.running) return;

    const now = performance.now();
    const elapsed = now - this.cycleStart;
    const phaseDuration = this.isOn ? this.onDuration : this.offDuration;

    if (elapsed >= phaseDuration) {
      // Switch phase
      this.isOn = !this.isOn;
      this.cycleStart = now;
      this.onPhaseChange();
    }

    this.updateUI();
  }

  onPhaseChange() {
    const ui = this.game.ui;
    if (this.isOn) {
      ui.notify('¡LA ELECTRICIDAD HA REGRESADO!', 5000);
      // Ambient light back
      if (this.game.ambientLight) this.game.ambientLight.intensity = 0.55;
      if (this.game.sunLight) this.game.sunLight.intensity = 1.1;
    } else {
      ui.notify('¡APAGÓN! La electricidad se ha interrumpido.', 5000);
      // Dim lights
      if (this.game.ambientLight) this.game.ambientLight.intensity = 0.12;
      if (this.game.sunLight) this.game.sunLight.intensity = 0.15;
    }
    this.applyWorldState();
    this.game.npcs?.onPowerChange(this.isOn);
    this.game.world?.onPowerChange(this.isOn);
  }

  applyWorldState() {
    const overlay = document.getElementById('blackout-overlay');
    if (overlay) {
      if (this.isOn) {
        overlay.classList.add('hidden');
        overlay.classList.remove('active');
      } else {
        overlay.classList.remove('hidden');
        overlay.classList.add('active');
      }
    }

    // Street lights / building lights would be toggled here
    if (this.game.world) {
      this.game.world.setLights(this.isOn);
    }
  }

  updateUI() {
    const statusEl = document.getElementById('power-status');
    const timerEl = document.getElementById('power-timer');
    const display = document.getElementById('power-display');
    if (!statusEl || !timerEl) return;

    const now = performance.now();
    const elapsed = now - this.cycleStart;
    const remaining = Math.max(0, (this.isOn ? this.onDuration : this.offDuration) - elapsed);
    const mins = Math.floor(remaining / 60000);
    const secs = Math.floor((remaining % 60000) / 1000);
    const timeStr = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;

    if (this.isOn) {
      statusEl.textContent = 'ELECTRICIDAD: ACTIVA';
      timerEl.textContent = `PRÓXIMO APAGÓN: ${timeStr}`;
      display?.classList.remove('blackout');
    } else {
      statusEl.textContent = '¡APAGÓN! ELECTRICIDAD: INTERRUMPIDA';
      timerEl.textContent = `REGRESO ESTIMADO: ${timeStr}`;
      display?.classList.add('blackout');
    }
  }

  getRemainingMs() {
    const elapsed = performance.now() - this.cycleStart;
    return Math.max(0, (this.isOn ? this.onDuration : this.offDuration) - elapsed);
  }

  // For save/load
  serialize() {
    return {
      isOn: this.isOn,
      cycleStartOffset: performance.now() - this.cycleStart // remaining offset
    };
  }

  deserialize(data) {
    this.isOn = data.isOn;
    this.cycleStart = performance.now() - (data.cycleStartOffset || 0);
    this.applyWorldState();
    this.updateUI();
  }
}
