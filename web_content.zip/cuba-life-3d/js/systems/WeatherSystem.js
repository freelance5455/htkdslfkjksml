/**
 * Simple Weather System
 */
export class WeatherSystem {
  constructor(game) {
    this.game = game;
    this.current = 'clear'; // clear, cloudy, rain, storm
    this.intensity = 0;
    this.timer = 0;
    this.nextChange = 120 + Math.random() * 180; // seconds
    this.rainParticles = null;
  }

  update(dt) {
    this.timer += dt;
    if (this.timer > this.nextChange) {
      this.changeWeather();
      this.timer = 0;
      this.nextChange = 90 + Math.random() * 200;
    }
  }

  changeWeather() {
    const roll = Math.random();
    if (roll < 0.5) this.current = 'clear';
    else if (roll < 0.75) this.current = 'cloudy';
    else if (roll < 0.92) this.current = 'rain';
    else this.current = 'storm';

    this.intensity = this.current === 'storm' ? 1 : this.current === 'rain' ? 0.6 : 0;

    if (this.current === 'rain' || this.current === 'storm') {
      this.game.notify(this.current === 'storm' ? '¡Tormenta fuerte!' : 'Empieza a llover', 3000);
      this.game.npcs?.onWeatherChange(this.current);
    }
  }

  isRaining() {
    return this.current === 'rain' || this.current === 'storm';
  }

  serialize() {
    return { current: this.current, intensity: this.intensity };
  }
  deserialize(d) {
    this.current = d.current || 'clear';
    this.intensity = d.intensity || 0;
  }
}
