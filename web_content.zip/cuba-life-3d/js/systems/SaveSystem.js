/**
 * Save / Load using localStorage
 */
export class SaveSystem {
  constructor(game) {
    this.game = game;
    this.key = 'cuba_life_3d_save_v1';
  }

  save() {
    try {
      const data = {
        version: 1,
        timestamp: Date.now(),
        player: { ...this.game.playerData },
        inventory: this.game.inventory.serialize(),
        economy: this.game.economy.serialize(),
        power: this.game.power.serialize(),
        time: this.game.time.serialize(),
        missions: this.game.missions.serialize(),
        weather: this.game.weather.serialize(),
        position: {
          x: this.game.player.mesh.position.x,
          y: this.game.player.mesh.position.y,
          z: this.game.player.mesh.position.z
        }
      };
      localStorage.setItem(this.key, JSON.stringify(data));
      this.game.notify('Partida guardada', 2500);
      return true;
    } catch (e) {
      console.error(e);
      this.game.notify('Error al guardar', 3000);
      return false;
    }
  }

  load() {
    try {
      const raw = localStorage.getItem(this.key);
      if (!raw) return false;
      const data = JSON.parse(raw);

      Object.assign(this.game.playerData, data.player);
      this.game.inventory.deserialize(data.inventory);
      this.game.economy.deserialize(data.economy);
      this.game.power.deserialize(data.power);
      this.game.time.deserialize(data.time);
      this.game.missions.deserialize(data.missions);
      this.game.weather.deserialize(data.weather);

      if (data.position && this.game.player) {
        this.game.player.mesh.position.set(data.position.x, data.position.y, data.position.z);
      }

      this.game.player.setAppearance(this.game.playerData.skinColor, this.game.playerData.clothes);
      this.game.ui.updateAll();
      this.game.notify('Partida cargada', 2500);
      return true;
    } catch (e) {
      console.error(e);
      return false;
    }
  }

  hasSave() {
    return !!localStorage.getItem(this.key);
  }
}
