/**
 * Economy System - CUP currency, prices, shops, businesses
 */
export class Economy {
  constructor(game) {
    this.game = game;
    this.prices = {
      // Food
      arroz: 25, frijoles: 30, pan_cubano: 15, agua: 10, cafe: 20,
      ropa_vieja: 80, congris: 60, tostones: 40, yuca: 25, maduros: 30,
      croquetas: 35, jugo: 25, batido: 40, cerdo: 120,
      // Fuel & oil
      gasolina: 180, diesel: 160, aceite_motor: 220, lubricante: 90,
      // Clothes
      camisa: 250, pantalon: 300, zapatos: 400, gorra: 80,
      // Tools / energy
      linterna: 150, bateria: 200, generador: 3500, panel_solar: 8000,
      // Housing
      alquiler_habitacion: 800, alquiler_casa: 2500
    };
    this.shops = this.createShops();
    this.businesses = []; // player-owned
    this.priceModifiers = { scarcity: 1.0, event: 1.0 };
  }

  reset() {
    this.businesses = [];
    this.priceModifiers = { scarcity: 1.0, event: 1.0 };
  }

  createShops() {
    return [
      {
        id: 'bodega_centro',
        name: 'Bodega El Centro',
        zone: 'centro-habana',
        type: 'food',
        stock: { arroz: 50, frijoles: 40, pan_cubano: 30, agua: 60, cafe: 25, congris: 15, tostones: 20 },
        position: { x: 12, z: -8 }
      },
      {
        id: 'cupet_gas',
        name: 'Servicentro CUPET',
        zone: 'centro-habana',
        type: 'fuel',
        stock: { gasolina: 200, diesel: 150, aceite_motor: 40, lubricante: 30 },
        position: { x: -18, z: 15 }
      },
      {
        id: 'tienda_ropa',
        name: 'Tienda La Moda',
        zone: 'vedado',
        type: 'clothes',
        stock: { camisa: 15, pantalon: 12, zapatos: 10, gorra: 20 },
        position: { x: 40, z: 30 }
      },
      {
        id: 'ferreteria',
        name: 'Ferretería El Constructor',
        zone: 'centro-habana',
        type: 'tools',
        stock: { linterna: 10, bateria: 15, generador: 3, panel_solar: 1 },
        position: { x: 5, z: 22 }
      }
    ];
  }

  getPrice(itemId) {
    const base = this.prices[itemId] || 50;
    return Math.round(base * this.priceModifiers.scarcity * this.priceModifiers.event);
  }

  buy(itemId, qty = 1, shopId = null) {
    const price = this.getPrice(itemId) * qty;
    if (!this.game.spendMoney(price)) return false;

    // Reduce shop stock if applicable
    if (shopId) {
      const shop = this.shops.find(s => s.id === shopId);
      if (shop && shop.stock[itemId] !== undefined) {
        if (shop.stock[itemId] < qty) {
          this.game.addMoney(price); // refund
          this.game.notify('No hay suficiente stock');
          return false;
        }
        shop.stock[itemId] -= qty;
      }
    }

    this.game.inventory.addItem(itemId, qty);
    this.game.notify(`Compraste ${qty}x ${itemId.replace('_', ' ')}`);
    return true;
  }

  sell(itemId, qty = 1) {
    if (!this.game.inventory.hasItem(itemId, qty)) {
      this.game.notify('No tienes ese objeto');
      return false;
    }
    const price = Math.round(this.getPrice(itemId) * 0.6 * qty); // sell at 60%
    this.game.inventory.removeItem(itemId, qty);
    this.game.addMoney(price);
    this.game.notify(`Vendiste ${qty}x ${itemId.replace('_', ' ')} por ${price} CUP`);
    return true;
  }

  // Simple business ownership
  buyBusiness(type, cost) {
    if (!this.game.spendMoney(cost)) return false;
    const biz = {
      id: 'biz_' + Date.now(),
      type,
      name: this.businessNames[type] || type,
      level: 1,
      incomePerHour: Math.round(cost * 0.02),
      employees: 0,
      reputation: 40,
      inventory: {},
      zone: this.game.playerData.zone
    };
    this.businesses.push(biz);
    this.game.notify(`¡Has abierto ${biz.name}!`);
    this.game.missions?.onBusinessOpened(type);
    return true;
  }

  businessNames = {
    cafeteria: 'Cafetería El Rincón',
    restaurante: 'Restaurante Cubano',
    taller: 'Taller Mecánico',
    tienda: 'Mi Tienda',
    bar: 'Bar La Esquina',
    lubricantes: 'Comercio de Lubricantes'
  };

  // Passive income from businesses (called periodically)
  tickBusinesses(gameHours) {
    for (const b of this.businesses) {
      const income = Math.round(b.incomePerHour * gameHours * (0.7 + b.reputation / 200));
      if (income > 0) {
        this.game.addMoney(income);
        // silent or small notif
      }
    }
  }

  serialize() {
    return {
      businesses: this.businesses,
      priceModifiers: this.priceModifiers,
      shops: this.shops.map(s => ({ id: s.id, stock: { ...s.stock } }))
    };
  }
  deserialize(d) {
    if (d.businesses) this.businesses = d.businesses;
    if (d.priceModifiers) this.priceModifiers = d.priceModifiers;
    if (d.shops) {
      for (const sd of d.shops) {
        const shop = this.shops.find(s => s.id === sd.id);
        if (shop) shop.stock = { ...shop.stock, ...sd.stock };
      }
    }
  }
}
