/**
 * Touch + keyboard input for Android / desktop
 */
export class InputManager {
  constructor(game) {
    this.game = game;
    this.moveVector = { x: 0, y: 0 };
    this.keys = {};
    this.joystickActive = false;
    this.joystickOrigin = { x: 0, y: 0 };
    this.joystickCurrent = { x: 0, y: 0 };
  }

  init() {
    // Keyboard
    window.addEventListener('keydown', e => {
      this.keys[e.code] = true;
      if (e.code === 'Space') this.game.player.jump();
      if (e.code === 'KeyE') this.interact();
      if (e.code === 'KeyF') this.vehicleToggle();
      if (e.code === 'ShiftLeft') this.game.player.setRunning(true);
    });
    window.addEventListener('keyup', e => {
      this.keys[e.code] = false;
      if (e.code === 'ShiftLeft') this.game.player.setRunning(false);
    });

    // Joystick
    const zone = document.getElementById('joystick-zone');
    const knob = document.getElementById('joystick-knob');
    const base = document.getElementById('joystick-base');

    const start = (e) => {
      e.preventDefault();
      this.joystickActive = true;
      const t = e.touches ? e.touches[0] : e;
      const rect = base.getBoundingClientRect();
      this.joystickOrigin.x = rect.left + rect.width / 2;
      this.joystickOrigin.y = rect.top + rect.height / 2;
      move(e);
    };
    const move = (e) => {
      if (!this.joystickActive) return;
      e.preventDefault();
      const t = e.touches ? e.touches[0] : e;
      let dx = t.clientX - this.joystickOrigin.x;
      let dy = t.clientY - this.joystickOrigin.y;
      const max = 40;
      const len = Math.sqrt(dx * dx + dy * dy);
      if (len > max) {
        dx = (dx / len) * max;
        dy = (dy / len) * max;
      }
      knob.style.transform = `translate(${dx}px, ${dy}px)`;
      this.moveVector.x = dx / max;
      this.moveVector.y = dy / max; // forward is negative y in screen but we map later
      // Invert Y so up = forward
      this.moveVector.y = -this.moveVector.y;
    };
    const end = () => {
      this.joystickActive = false;
      knob.style.transform = 'translate(0,0)';
      this.moveVector.x = 0;
      this.moveVector.y = 0;
    };

    zone.addEventListener('touchstart', start, { passive: false });
    zone.addEventListener('touchmove', move, { passive: false });
    zone.addEventListener('touchend', end);
    zone.addEventListener('mousedown', start);
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', end);

    // Action buttons
    document.getElementById('btn-run').addEventListener('touchstart', () => this.game.player.setRunning(true));
    document.getElementById('btn-run').addEventListener('touchend', () => this.game.player.setRunning(false));
    document.getElementById('btn-jump').addEventListener('click', () => this.game.player.jump());
    document.getElementById('btn-interact').addEventListener('click', () => this.interact());
    document.getElementById('btn-enter-vehicle').addEventListener('click', () => this.vehicleToggle());
  }

  update(dt) {
    // Keyboard fallback
    if (!this.joystickActive) {
      let x = 0, y = 0;
      if (this.keys['KeyW'] || this.keys['ArrowUp']) y = 1;
      if (this.keys['KeyS'] || this.keys['ArrowDown']) y = -1;
      if (this.keys['KeyA'] || this.keys['ArrowLeft']) x = -1;
      if (this.keys['KeyD'] || this.keys['ArrowRight']) x = 1;
      this.moveVector.x = x;
      this.moveVector.y = y;
    }

    // Show enter vehicle button when near
    const btn = document.getElementById('btn-enter-vehicle');
    if (btn && !this.game.vehicles.currentVehicle) {
      const near = this.game.vehicles.vehicles.some(v =>
        v.mesh.position.distanceTo(this.game.player.mesh.position) < 3.5
      );
      btn.style.display = near ? 'block' : 'none';
    }
  }

  interact() {
    const pos = this.game.player.mesh.position;
    // NPC
    const npc = this.game.npcs.getNearbyNPC(pos);
    if (npc) {
      this.game.ui.showDialogue(npc.name, npc.dialogue);
      return;
    }
    // Shop / interactable
    const inter = this.game.world.getNearbyInteractable(pos);
    if (inter) {
      inter.action();
      return;
    }
    // Vehicle buy
    this.game.vehicles.buyNearby();
  }

  vehicleToggle() {
    if (this.game.vehicles.currentVehicle) {
      this.game.vehicles.exit();
    } else {
      this.game.vehicles.tryEnter();
    }
  }
}
