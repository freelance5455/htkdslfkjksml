/**
 * Vehicle Manager - simple driveable vehicles
 */
import * as THREE from 'three';

export class VehicleManager {
  constructor(game) {
    this.game = game;
    this.vehicles = [];
    this.currentVehicle = null;
  }

  spawnZoneVehicles(zoneId) {
    for (const v of this.vehicles) {
      this.game.scene.remove(v.mesh);
    }
    this.vehicles = [];

    // Spawn a few classic cars / motos
    this.spawnVehicle('lada', -8, 8);
    this.spawnVehicle('moto', 10, -5);
    this.spawnVehicle('americano', 20, 12);
  }

  spawnVehicle(type, x, z) {
    let mesh, speed, fuelCap, name, price;

    if (type === 'moto') {
      const group = new THREE.Group();
      const body = new THREE.Mesh(
        new THREE.BoxGeometry(0.6, 0.5, 1.6),
        new THREE.MeshStandardMaterial({ color: 0x222222 })
      );
      body.position.y = 0.5;
      group.add(body);
      const wheelMat = new THREE.MeshStandardMaterial({ color: 0x111111 });
      const w1 = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.15, 10), wheelMat);
      w1.rotation.z = Math.PI / 2;
      w1.position.set(0, 0.3, 0.55);
      group.add(w1);
      const w2 = w1.clone();
      w2.position.z = -0.55;
      group.add(w2);
      mesh = group;
      speed = 14;
      fuelCap = 12;
      name = 'Moto';
      price = 4500;
    } else {
      // Car
      const group = new THREE.Group();
      const body = new THREE.Mesh(
        new THREE.BoxGeometry(1.8, 0.7, 3.8),
        new THREE.MeshStandardMaterial({ color: type === 'lada' ? 0xcc3333 : 0x2266aa })
      );
      body.position.y = 0.6;
      group.add(body);
      const cabin = new THREE.Mesh(
        new THREE.BoxGeometry(1.6, 0.55, 1.8),
        new THREE.MeshStandardMaterial({ color: 0x88aacc, transparent: true, opacity: 0.7 })
      );
      cabin.position.set(0, 1.15, -0.2);
      group.add(cabin);
      mesh = group;
      speed = type === 'lada' ? 11 : 13;
      fuelCap = 40;
      name = type === 'lada' ? 'Lada' : 'Clásico Americano';
      price = type === 'lada' ? 12000 : 28000;
    }

    mesh.position.set(x, 0, z);
    mesh.castShadow = true;
    this.game.scene.add(mesh);

    this.vehicles.push({
      mesh,
      type,
      name,
      speed,
      fuel: fuelCap * 0.7,
      fuelCap,
      price,
      owner: null, // null = for sale / NPC
      health: 100
    });
  }

  update(dt) {
    if (!this.currentVehicle) return;

    const v = this.currentVehicle;
    const input = this.game.input;
    const move = input.moveVector;

    // Simple vehicle control
    const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(v.mesh.quaternion);
    const right = new THREE.Vector3(1, 0, 0).applyQuaternion(v.mesh.quaternion);

    if (Math.abs(move.y) > 0.1 && v.fuel > 0) {
      v.mesh.position.add(forward.multiplyScalar(move.y * v.speed * dt));
      v.fuel = Math.max(0, v.fuel - dt * 0.8);
    }
    if (Math.abs(move.x) > 0.1) {
      v.mesh.rotation.y -= move.x * 1.8 * dt;
    }

    // Player follows vehicle
    this.game.player.mesh.position.copy(v.mesh.position);
    this.game.player.mesh.position.y = 1.2;
    this.game.player.mesh.visible = false;
  }

  tryEnter() {
    const playerPos = this.game.player.mesh.position;
    for (const v of this.vehicles) {
      if (v.mesh.position.distanceTo(playerPos) < 3.5) {
        if (v.owner === null || v.owner === 'player') {
          this.currentVehicle = v;
          this.game.player.mesh.visible = false;
          this.game.notify(`Entraste al ${v.name}. Combustible: ${Math.round(v.fuel)}L`);
          document.getElementById('btn-enter-vehicle').style.display = 'none';
          return true;
        }
      }
    }
    return false;
  }

  exit() {
    if (!this.currentVehicle) return;
    const v = this.currentVehicle;
    this.game.player.mesh.position.copy(v.mesh.position);
    this.game.player.mesh.position.x += 2;
    this.game.player.mesh.position.y = 1;
    this.game.player.mesh.visible = true;
    this.currentVehicle = null;
    this.game.notify('Saliste del vehículo');
  }

  buyNearby() {
    const playerPos = this.game.player.mesh.position;
    for (const v of this.vehicles) {
      if (v.owner === null && v.mesh.position.distanceTo(playerPos) < 4) {
        if (this.game.spendMoney(v.price)) {
          v.owner = 'player';
          this.game.notify(`¡Compraste el ${v.name}!`);
          this.game.inventory.addItem('llaves_moto', 1);
          return true;
        }
      }
    }
    return false;
  }
}
