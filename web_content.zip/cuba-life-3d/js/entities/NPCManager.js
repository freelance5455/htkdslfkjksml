/**
 * NPC Manager - simple AI, routines, blackout reactions
 */
import * as THREE from 'three';

const NAMES = [
  'Miguel', 'Yolanda', 'Pedro', 'Caridad', 'José', 'María', 'Luis', 'Ana',
  'Roberto', 'Elena', 'Carlos', 'Isabel', 'Fernando', 'Rosa', 'Antonio', 'Carmen'
];

export class NPCManager {
  constructor(game) {
    this.game = game;
    this.npcs = [];
    this.maxActive = 18;
  }

  spawnZoneNPCs(zoneId) {
    // Clear previous
    for (const n of this.npcs) {
      this.game.scene.remove(n.mesh);
    }
    this.npcs = [];

    const count = Math.min(12, this.maxActive);
    for (let i = 0; i < count; i++) {
      this.spawnNPC(zoneId);
    }
  }

  spawnNPC(zoneId) {
    const name = NAMES[Math.floor(Math.random() * NAMES.length)];
    const color = new THREE.Color().setHSL(Math.random(), 0.4, 0.45);

    const body = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.3, 0.9, 4, 6),
      new THREE.MeshStandardMaterial({ color })
    );
    body.position.set(
      (Math.random() - 0.5) * 60,
      1,
      (Math.random() - 0.5) * 60
    );
    body.castShadow = true;
    this.game.scene.add(body);

    const npc = {
      mesh: body,
      name,
      state: 'walk', // walk, talk, work, shelter
      target: null,
      speed: 1.2 + Math.random() * 0.8,
      timer: Math.random() * 5,
      dialogue: this.generateDialogue(name),
      hasFlashlight: Math.random() < 0.3
    };
    this.npcs.push(npc);
  }

  generateDialogue(name) {
    const lines = [
      [`Hola, ¿cómo andas?`, `Bien, gracias.`, `El apagón de ayer fue largo.`],
      [`¿Buscas trabajo? En la cafetería a veces necesitan gente.`, `Gracias por el dato.`],
      [`La gasolina está cara últimamente.`, `Sí, todo sube.`],
      [`¿Tienes linterna? Nunca se sabe con la electricidad.`, `Sí, mejor prevenir.`],
      [`Buenos días. El café de la esquina está bueno.`, `Lo tendré en cuenta.`]
    ];
    return lines[Math.floor(Math.random() * lines.length)];
  }

  update(dt) {
    const powerOn = this.game.power.isOn;
    const playerPos = this.game.player.mesh.position;

    for (const npc of this.npcs) {
      npc.timer -= dt;

      if (npc.state === 'walk') {
        if (!npc.target || npc.timer <= 0) {
          // New random target nearby
          npc.target = new THREE.Vector3(
            npc.mesh.position.x + (Math.random() - 0.5) * 20,
            1,
            npc.mesh.position.z + (Math.random() - 0.5) * 20
          );
          npc.timer = 4 + Math.random() * 6;
        }
        const dir = npc.target.clone().sub(npc.mesh.position);
        dir.y = 0;
        if (dir.length() > 0.5) {
          dir.normalize();
          npc.mesh.position.add(dir.multiplyScalar(npc.speed * dt));
          npc.mesh.rotation.y = Math.atan2(dir.x, dir.z);
        }
      }

      // React to blackout
      if (!powerOn && npc.state !== 'shelter') {
        if (Math.random() < 0.002) {
          npc.state = 'shelter';
          // Move closer to buildings / stop
          npc.speed *= 0.5;
        }
      } else if (powerOn && npc.state === 'shelter') {
        npc.state = 'walk';
        npc.speed = 1.2 + Math.random() * 0.8;
      }

      // Face player if close
      const dist = npc.mesh.position.distanceTo(playerPos);
      if (dist < 4) {
        const look = playerPos.clone().sub(npc.mesh.position);
        npc.mesh.rotation.y = Math.atan2(look.x, look.z);
      }
    }
  }

  onPowerChange(isOn) {
    if (!isOn) {
      this.game.notify('Los vecinos sacan linternas y conversan en la oscuridad...', 4000);
      for (const npc of this.npcs) {
        if (Math.random() < 0.4) npc.state = 'shelter';
      }
    } else {
      for (const npc of this.npcs) {
        npc.state = 'walk';
        npc.speed = 1.2 + Math.random() * 0.8;
      }
    }
  }

  onWeatherChange(weather) {
    if (weather === 'rain' || weather === 'storm') {
      for (const npc of this.npcs) {
        npc.speed *= 0.6;
      }
    }
  }

  getNearbyNPC(playerPos, radius = 2.5) {
    for (const npc of this.npcs) {
      if (npc.mesh.position.distanceTo(playerPos) < radius) return npc;
    }
    return null;
  }
}
