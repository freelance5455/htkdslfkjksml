/**
 * Player Entity
 */
import * as THREE from 'three';

export class Player {
  constructor(game) {
    this.game = game;
    this.speed = 5.5;
    this.runMultiplier = 1.7;
    this.velocity = new THREE.Vector3();
    this.isRunning = false;
    this.onGround = true;
    this.jumpVelocity = 0;

    // Simple capsule-like body
    const bodyGeo = new THREE.CapsuleGeometry(0.35, 1.0, 4, 8);
    const bodyMat = new THREE.MeshStandardMaterial({ color: 0xC68642 });
    this.mesh = new THREE.Mesh(bodyGeo, bodyMat);
    this.mesh.position.set(0, 1, 0);
    this.mesh.castShadow = true;
    this.mesh.receiveShadow = true;

    // Head
    const headGeo = new THREE.SphereGeometry(0.28, 12, 12);
    const headMat = new THREE.MeshStandardMaterial({ color: 0xC68642 });
    this.head = new THREE.Mesh(headGeo, headMat);
    this.head.position.y = 0.95;
    this.mesh.add(this.head);

    // Simple clothes indicator
    const shirtGeo = new THREE.CylinderGeometry(0.38, 0.36, 0.55, 8);
    this.shirt = new THREE.Mesh(shirtGeo, new THREE.MeshStandardMaterial({ color: 0x2266aa }));
    this.shirt.position.y = 0.25;
    this.mesh.add(this.shirt);
  }

  setAppearance(skinHex, clothes) {
    const skin = new THREE.Color(skinHex);
    this.mesh.material.color.copy(skin);
    this.head.material.color.copy(skin);

    const colors = {
      casual: 0x2266aa,
      work: 0x555555,
      sport: 0x22aa44
    };
    this.shirt.material.color.setHex(colors[clothes] || 0x2266aa);
  }

  update(dt) {
    const input = this.game.input;
    const move = input.moveVector;

    // Horizontal movement
    this.velocity.x = move.x * this.speed * (this.isRunning ? this.runMultiplier : 1);
    this.velocity.z = move.y * this.speed * (this.isRunning ? this.runMultiplier : 1);

    // Simple gravity / jump
    if (!this.onGround) {
      this.jumpVelocity -= 20 * dt;
      this.mesh.position.y += this.jumpVelocity * dt;
      if (this.mesh.position.y <= 1) {
        this.mesh.position.y = 1;
        this.onGround = true;
        this.jumpVelocity = 0;
      }
    }

    this.mesh.position.x += this.velocity.x * dt;
    this.mesh.position.z += this.velocity.z * dt;

    // Face movement direction
    if (move.length() > 0.1) {
      const angle = Math.atan2(move.x, move.y);
      this.mesh.rotation.y = angle;
    }

    // World bounds (simple)
    this.mesh.position.x = THREE.MathUtils.clamp(this.mesh.position.x, -80, 80);
    this.mesh.position.z = THREE.MathUtils.clamp(this.mesh.position.z, -80, 80);

    // Sync playerData position
    this.game.playerData.position = {
      x: this.mesh.position.x,
      y: this.mesh.position.y,
      z: this.mesh.position.z
    };
  }

  jump() {
    if (this.onGround) {
      this.onGround = false;
      this.jumpVelocity = 8;
    }
  }

  setRunning(v) {
    this.isRunning = v;
  }
}
