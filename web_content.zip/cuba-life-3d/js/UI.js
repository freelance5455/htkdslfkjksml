/**
 * UI Manager - HUD, panels, dialogue, notifications
 */
export class UI {
  constructor() {
    this.game = null;
    this.notifQueue = [];
  }

  bindGame(game) {
    this.game = game;
    this.bindButtons();
    this.updateAll();
  }

  bindButtons() {
    // Bottom HUD
    document.getElementById('btn-inventory').onclick = () => this.togglePanel('panel-inventory');
    document.getElementById('btn-phone').onclick = () => this.togglePanel('panel-phone');
    document.getElementById('btn-map').onclick = () => this.togglePanel('panel-map');
    document.getElementById('btn-missions').onclick = () => this.togglePanel('panel-missions');
    document.getElementById('btn-vehicle').onclick = () => this.game.input.vehicleToggle();
    document.getElementById('btn-business').onclick = () => this.showBusinessMenu();
    document.getElementById('btn-pause').onclick = () => this.togglePanel('panel-pause');

    // Close buttons
    document.querySelectorAll('.close-btn').forEach(btn => {
      btn.onclick = () => {
        btn.closest('.panel').classList.add('hidden');
      };
    });

    // Pause actions
    document.getElementById('btn-save').onclick = () => this.game.saveGame();
    document.getElementById('btn-load').onclick = () => this.game.loadGame();
    document.getElementById('btn-settings').onclick = () => {
      document.getElementById('settings-content').classList.toggle('hidden');
    };
    document.getElementById('quality-select').onchange = (e) => {
      this.game.setQuality(e.target.value);
    };

    // Phone apps
    document.querySelectorAll('.phone-apps button').forEach(btn => {
      btn.onclick = () => this.openPhoneApp(btn.dataset.app);
    });

    // Map zones (simple)
    this.buildMap();
  }

  togglePanel(id) {
    const panel = document.getElementById(id);
    const wasHidden = panel.classList.contains('hidden');
    // Close others
    document.querySelectorAll('.panel').forEach(p => p.classList.add('hidden'));
    if (wasHidden) {
      panel.classList.remove('hidden');
      if (id === 'panel-inventory') this.refreshInventory();
      if (id === 'panel-missions') this.refreshMissions();
    }
  }

  update(dt) {
    this.updateNeeds();
    this.updateMoney();
    this.drawMinimap();
  }

  updateAll() {
    this.updateMoney();
    this.updateNeeds();
    this.refreshInventory();
    this.refreshMissions();
  }

  updateMoney() {
    const el = document.getElementById('money-value');
    if (el) el.textContent = Math.floor(this.game.playerData.money);
  }

  updateNeeds() {
    const pd = this.game.playerData;
    const set = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.style.width = Math.max(0, Math.min(100, val)) + '%';
    };
    set('hunger-bar', pd.hunger);
    set('thirst-bar', pd.thirst);
    set('energy-bar', pd.energy);
    set('health-bar', pd.health);
  }

  refreshInventory() {
    const grid = document.getElementById('inventory-grid');
    if (!grid) return;
    grid.innerHTML = '';
    const items = this.game.inventory.getItems();
    for (const item of items) {
      const slot = document.createElement('div');
      slot.className = 'inv-slot';
      slot.innerHTML = `${item.icon}<span class="qty">x${item.qty}</span>`;
      slot.onclick = () => {
        document.querySelectorAll('.inv-slot').forEach(s => s.classList.remove('selected'));
        slot.classList.add('selected');
        const info = document.getElementById('inventory-info');
        info.innerHTML = `<strong>${item.name}</strong><br>
          <button onclick="window.game.inventory.useItem('${item.id}')">Usar</button>
          <button onclick="window.game.economy.sell('${item.id}',1)">Vender</button>`;
      };
      grid.appendChild(slot);
    }
  }

  refreshMissions() {
    const list = document.getElementById('missions-list');
    if (!list) return;
    list.innerHTML = '';
    for (const m of this.game.missions.active) {
      const card = document.createElement('div');
      card.className = 'mission-card';
      let objs = m.objectives.map(o => `${o.done ? '✅' : '⬜'} ${o.text}`).join('<br>');
      card.innerHTML = `<h3>${m.title}</h3><p>${m.description}</p>
        <div>${objs}</div>
        <div class="reward">Recompensa: ${m.reward?.money || 0} CUP</div>`;
      list.appendChild(card);
    }
    if (this.game.missions.active.length === 0) {
      list.innerHTML = '<p style="opacity:0.7">No hay misiones activas.</p>';
    }
  }

  openPhoneApp(app) {
    const content = document.getElementById('phone-content');
    const pd = this.game.playerData;
    switch (app) {
      case 'bank':
        content.innerHTML = `
          <p><strong>Banco Nacional (ficticio)</strong></p>
          <p>Efectivo: ${Math.floor(pd.money)} CUP</p>
          <p>Cuenta: ${Math.floor(pd.bank)} CUP</p>
          <button onclick="window.game.playerData.bank += window.game.playerData.money; window.game.playerData.money=0; window.game.ui.updateMoney(); window.game.ui.openPhoneApp('bank')">Depositar todo</button>
          <button onclick="const a=Math.min(window.game.playerData.bank,100); window.game.playerData.bank-=a; window.game.addMoney(a); window.game.ui.openPhoneApp('bank')">Retirar 100</button>`;
        break;
      case 'power':
        const rem = this.game.power.getRemainingMs();
        const mins = Math.floor(rem / 60000);
        const secs = Math.floor((rem % 60000) / 1000);
        content.innerHTML = `
          <p><strong>Estado Eléctrico</strong></p>
          <p>${this.game.power.isOn ? '🟢 Electricidad ACTIVA' : '🔴 APAGÓN'}</p>
          <p>Tiempo restante fase: ${mins}:${String(secs).padStart(2,'0')}</p>
          <p>Ciclo: 5 min ON → 20 min OFF</p>
          <p>Consejo: Ten linterna y considera un generador.</p>`;
        break;
      case 'jobs':
        content.innerHTML = `
          <p><strong>Ofertas de trabajo</strong></p>
          <button onclick="window.game.addMoney(80); window.game.notify('Trabajaste 1h como dependiente (+80 CUP)')">Dependiente de bodega (80 CUP/h)</button>
          <button onclick="window.game.addMoney(120); window.game.notify('Trabajaste en el taller (+120 CUP)')">Ayudante de mecánico (120 CUP/h)</button>
          <button onclick="window.game.addMoney(100); window.game.notify('Repartiste con bicitaxi (+100 CUP)')">Bicitaxi (100 CUP/h)</button>`;
        break;
      case 'shop':
        content.innerHTML = `<p>Usa el botón ✋ cerca de una tienda o bodega para comprar.</p>
          <p>Bodega El Centro, CUPET y Ferretería están marcadas en el mapa.</p>`;
        break;
      case 'business':
        content.innerHTML = `
          <p><strong>Mis Negocios</strong></p>
          ${this.game.economy.businesses.map(b => `<p>${b.name} · Nivel ${b.level} · Ingresos ~${b.incomePerHour} CUP/h</p>`).join('') || '<p>Aún no tienes negocios.</p>'}
          <hr>
          <p>Abrir nuevo:</p>
          <button onclick="window.game.economy.buyBusiness('cafeteria',2500)">Cafetería (2500 CUP)</button>
          <button onclick="window.game.economy.buyBusiness('taller',5000)">Taller (5000 CUP)</button>
          <button onclick="window.game.economy.buyBusiness('lubricantes',4000)">Lubricantes (4000 CUP)</button>`;
        break;
      case 'news':
        content.innerHTML = `
          <p><strong>Noticias (ficticias)</strong></p>
          <p>• El ciclo de apagones continúa en la capital.</p>
          <p>• Precios de gasolina estables esta semana.</p>
          <p>• Feria de productos en Vedado el fin de semana.</p>`;
        break;
      case 'messages':
        content.innerHTML = `<p>No tienes mensajes nuevos.</p>`;
        break;
      case 'contacts':
        content.innerHTML = `<p>Miguel (vecino)<br>Yolanda (bodega)<br>Pedro (taller)</p>`;
        break;
      default:
        content.innerHTML = '';
    }
  }

  showBusinessMenu() {
    this.togglePanel('panel-phone');
    this.openPhoneApp('business');
  }

  openShopNear(name) {
    // Simple shop UI via phone content or notification + buy buttons
    const content = document.getElementById('phone-content');
    document.getElementById('panel-phone').classList.remove('hidden');
    let html = `<p><strong>${name}</strong></p>`;
    const shop = this.game.economy.shops.find(s => s.name.includes(name.split(' ')[0]) || name.includes(s.name.split(' ')[0]));
    if (shop) {
      for (const [item, stock] of Object.entries(shop.stock)) {
        if (stock <= 0) continue;
        const price = this.game.economy.getPrice(item);
        html += `<button onclick="window.game.economy.buy('${item}',1,'${shop.id}'); window.game.missions.onItemBought('${item}'); window.game.ui.openShopNear('${name}')">
          ${item.replace('_',' ')} - ${price} CUP (stock ${stock})</button>`;
      }
    } else {
      html += '<p>Habla con el dependiente o vuelve más tarde.</p>';
    }
    content.innerHTML = html;
  }

  showDialogue(name, lines) {
    const box = document.getElementById('dialogue-box');
    document.getElementById('dialogue-name').textContent = name;
    let step = 0;
    const showStep = () => {
      if (step >= lines.length) {
        box.classList.add('hidden');
        return;
      }
      document.getElementById('dialogue-text').textContent = lines[step];
      const opts = document.getElementById('dialogue-options');
      opts.innerHTML = '';
      const btn = document.createElement('button');
      btn.textContent = step < lines.length - 1 ? 'Continuar' : 'Adiós';
      btn.onclick = () => { step++; showStep(); };
      opts.appendChild(btn);
    };
    box.classList.remove('hidden');
    showStep();
  }

  notify(msg, duration = 3000) {
    const container = document.getElementById('notifications');
    const el = document.createElement('div');
    el.className = 'notification';
    el.textContent = msg;
    container.appendChild(el);
    setTimeout(() => el.remove(), duration);
  }

  buildMap() {
    const map = document.getElementById('world-map');
    if (!map) return;
    map.innerHTML = '';
    const zones = this.game?.world?.zones || {};
    // Simplified visual map
    const positions = {
      'centro-habana': [50, 50],
      'habana-vieja': [30, 40],
      'vedado': [65, 35],
      'miramar': [80, 45],
      'playa': [75, 70],
      'varadero': [70, 85],
      'matanzas': [60, 75],
      'santiago': [85, 20],
      'trinidad': [55, 25],
      'pinar': [15, 40]
    };
    for (const [id, pos] of Object.entries(positions)) {
      const m = document.createElement('div');
      m.className = 'zone-marker' + (id === 'centro-habana' ? ' current' : '');
      m.style.left = pos[0] + '%';
      m.style.top = pos[1] + '%';
      m.title = zones[id]?.name || id;
      m.onclick = () => {
        this.notify(`Viajar a ${zones[id]?.name || id} (próximamente con costo y tiempo)`);
      };
      map.appendChild(m);
    }
  }

  drawMinimap() {
    const canvas = document.getElementById('minimap');
    if (!canvas || !this.game?.player) return;
    const ctx = canvas.getContext('2d');
    const w = canvas.width, h = canvas.height;
    ctx.fillStyle = 'rgba(10,40,70,0.85)';
    ctx.fillRect(0, 0, w, h);

    const px = this.game.player.mesh.position.x;
    const pz = this.game.player.mesh.position.z;
    const scale = 1.2;

    // Player
    ctx.fillStyle = '#ffd700';
    ctx.beginPath();
    ctx.arc(w / 2, h / 2, 5, 0, Math.PI * 2);
    ctx.fill();

    // Nearby NPCs
    ctx.fillStyle = '#88ccff';
    for (const npc of this.game.npcs.npcs) {
      const dx = (npc.mesh.position.x - px) * scale;
      const dz = (npc.mesh.position.z - pz) * scale;
      if (Math.abs(dx) < w / 2 && Math.abs(dz) < h / 2) {
        ctx.fillRect(w / 2 + dx - 2, h / 2 + dz - 2, 4, 4);
      }
    }

    // Vehicles
    ctx.fillStyle = '#ff6666';
    for (const v of this.game.vehicles.vehicles) {
      const dx = (v.mesh.position.x - px) * scale;
      const dz = (v.mesh.position.z - pz) * scale;
      if (Math.abs(dx) < w / 2 && Math.abs(dz) < h / 2) {
        ctx.fillRect(w / 2 + dx - 3, h / 2 + dz - 2, 6, 4);
      }
    }
  }
}
