# Cómo convertir CUBA LIFE 3D en APK para Android

El juego ya está listo para empaquetarse. Elige **una** de estas 3 formas (la más fácil primero).

---

## OPCIÓN 1 — La más fácil: PWABuilder (online, sin instalar nada)

1. Sube toda la carpeta `cuba-life-3d` a cualquier hosting gratuito (GitHub Pages, Netlify, Vercel, Cloudflare Pages…).
2. Entra en → https://www.pwabuilder.com
3. Pega la URL de tu juego.
4. Pulsa **Package for stores** → Android → Generate.
5. Descarga el `.apk` o el proyecto Android Studio.

Ventaja: no necesitas instalar Node ni Android Studio.

---

## OPCIÓN 2 — Capacitor (recomendado para control total)

### Requisitos
- Node.js 18+ instalado
- Android Studio instalado (con SDK)

### Pasos exactos

```bash
# 1. Entra en la carpeta del juego
cd cuba-life-3d

# 2. Inicializa npm
npm init -y

# 3. Instala Capacitor
npm install @capacitor/core @capacitor/cli @capacitor/android

# 4. Inicializa Capacitor
npx cap init "CUBA LIFE 3D" "com.cubalife3d.game" --web-dir .

# 5. Añade la plataforma Android
npx cap add android

# 6. Sincroniza los archivos
npx cap sync

# 7. Abre Android Studio
npx cap open android
```

En Android Studio:
- Espera a que Gradle termine.
- Conecta tu teléfono o usa un emulador.
- Pulsa el botón **Run** (triángulo verde).
- Para generar APK firmado: **Build → Generate Signed Bundle / APK**.

---

## OPCIÓN 3 — WebView nativo (Android Studio desde cero)

1. Abre Android Studio → New Project → Empty Views Activity.
2. Nombre: `CubaLife3D`, package: `com.cubalife3d.game`.
3. Copia **todo el contenido** de la carpeta `cuba-life-3d` dentro de:
   `app/src/main/assets/`
4. En `MainActivity.java` (o Kotlin) pon esto:

```java
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        WebView webView = new WebView(this);
        setContentView(webView);
        
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");
    }
}
```

5. En `AndroidManifest.xml` añade dentro de `<application>`:
```xml
android:usesCleartextTraffic="true"
```
Y el permiso de internet:
```xml
<uses-permission android:name="android.permission.INTERNET" />
```

6. Build → Build APK.

---

## Nota sobre Three.js (internet)

El juego carga Three.js desde unpkg.com.  
Para que funcione **100% offline** en el APK:

1. Descarga:
   - https://unpkg.com/three@0.160.0/build/three.module.js
2. Ponlo en `js/vendor/three.module.js`
3. Cambia el importmap en `index.html` a:
```html
"three": "./js/vendor/three.module.js"
```

---

## Icono de la app

Crea un icono 512×512 px (preferiblemente con la bandera o un diseño cubano) y:
- En Capacitor se configura en `android/app/src/main/res/`
- En PWABuilder se sube al generar el paquete.

---

¡Listo! Con cualquiera de estas opciones tendrás el APK instalable en cualquier Android.
