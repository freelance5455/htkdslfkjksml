# Nova AI Android build project

This project builds a debug APK using GitHub Actions. It contains the Nova AI browser interface as an offline asset, so the APK can launch immediately in demo mode.

## Important: connecting your existing Python/Gradio agent

The Android wrapper currently opens `app/src/main/assets/index.html` in demo mode. To open your real Python/Gradio agent, first deploy the actual Python project to a working HTTPS host (for example, a Hugging Face Gradio Space). Then edit `app/src/main/java/com/praveen/novaai/MainActivity.java` and set:

`private static final String HOSTED_AGENT_URL = "https://YOUR-SPACE-URL.hf.space";`

Commit the change and run the workflow again. Do not put API keys in the Android source or in a public repository. A WebView wrapper does not itself run Python; the Gradio backend must remain hosted online.

## Build from a phone using GitHub web UI

1. Download and extract this ZIP.
2. Open your existing repository `https://github.com/bpravin9/ai-agent`.
3. Upload the *contents* of this project (including the `.github` folder and `app` folder) into the repository root. Keep your existing Python files; do not delete them. If prompted, merge folders rather than replace unrelated files.
4. Open the repository's **Actions** tab and choose **Build Nova AI APK**. If GitHub asks, enable Actions, then tap **Run workflow**.
5. Open the completed run, scroll to **Artifacts**, and download `NovaAI-debug-apk`. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.
6. Open the APK on the Android phone and allow installation from that browser/file manager if Android asks.

This is a debug APK for personal testing, not a Play Store release-signed APK. The default build uses offline demo mode until you deploy the backend and set its HTTPS URL.
