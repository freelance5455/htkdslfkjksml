# CGD V117 — Socle 4.0 : modèles détaillés et présentation des damistes

## Objectif
Faire évoluer les figurines 3D vers des modèles humanoïdes plus lisibles et articulés, et renforcer la présentation des deux camps avant une rencontre, sans remplacer le moteur WebGL ni toucher aux règles de dames, aux compétitions ou à la carrière.

## Évolutions intégrées
- Jambes construites en segments distincts avec genoux, pieds et chaussures.
- Bras articulés en épaule, coude et main, avec points de flexion visibles.
- Détails de visage enrichis : yeux, pupilles, sourcils, nez et bouche ; inclinaison de tête et regard varient selon les attitudes.
- Démarche animée pendant le déplacement : oscillation des jambes et du buste synchronisée à la trajectoire du pion.
- Gestes dédiés à la réflexion, à la prise, à la présentation, à la victoire et à la défaite.
- Les deux camps conservent leur séquence de présentation avant le début du match.
- Les réactions de la foule sont modulées lors des poses de célébration et de défaite.
- Le moteur WebGL, la caméra manuelle/cinématique et le repli classique restent en place.

## Correction de cohérence
Le contrôle de départ du paquet 3.9 a révélé six tests en échec concernant des articulations et expressions annoncées par des tests mais absentes du code source. Le Socle 4.0 rétablit ces fonctions et leurs assertions ; il ne masque pas les tests.

## Protection des acquis
Aucune règle de déplacement, prise, promotion, horloge, résultat, compétition, calendrier, contrat, transfert, finance ou sauvegarde n'a été modifiée intentionnellement. Les améliorations sont confinées à la représentation et à l'animation 3D.

## Validation
- Suite automatisée : 240 tests réussis, 0 échec.
- Syntaxe JavaScript : `node --check` sur tous les fichiers `src/` et `tests/`.
- Archive ZIP : contrôle d'intégrité après création.
- Limite : aucune validation visuelle réelle sur téléphone ou navigateur mobile n'a été effectuée dans cet environnement. Le rendu reste stylisé et ne doit pas être présenté comme photoréaliste.
