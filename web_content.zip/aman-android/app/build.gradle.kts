plugins {
    id("com.android.application")
}

android {
    namespace = "com.aman.finance"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.aman.finance"
        minSdk = 23
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }
}
