# أمان Android

مشروع Android Studio يحوّل تطبيق أمان إلى تطبيق Android. ملفات الواجهة مضمنة، وتبقى بيانات المستخدم في تخزين WebView المحلي. يحتاج التطبيق إلى اتصال الإنترنت وصلاحية INTERNET لجلب أسعار الذهب والعملات؛ تبقى بيانات الدخل والديون على الجهاز.

## إنشاء APK

1. افتح هذا المجلد في Android Studio.
2. وافق على تثبيت Android SDK Platform 36 إذا طُلب ذلك. صلاحية الإنترنت مضافة في AndroidManifest.xml.
3. انتظر انتهاء Gradle Sync.
4. اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. ستجد نسخة Debug في `app/build/outputs/apk/debug/app-debug.apk`، ويمكن تثبيتها مباشرة على الهاتف.

يتطلب المشروع Android Gradle Plugin 9.4.1 وGradle 9.6.0 وJDK 17. يمكن لـ Android Studio تنزيل مكونات البناء عند فتح المشروع.
