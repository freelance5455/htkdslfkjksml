NOHLAN V2 — PUBLICATION NETLIFY

CONTENU
- index.html : application principale (version fournie, avec ajout de la configuration PWA).
- manifest.webmanifest : identité et paramètres d’installation de l’application.
- sw.js : cache de l’application et solution de repli hors connexion pour la page principale.
- icons/ : icônes Android et raccourci iOS dérivés du logo V2 intégré à l’application.

PUBLICATION
1. Décompresser V2.zip.
2. Ouvrir le dossier V2.
3. Déposer le CONTENU du dossier V2 dans la zone de déploiement Netlify (index.html doit être à la racine publiée).
4. Attendre la fin du déploiement et ouvrir l’URL HTTPS du site.
5. Sur Android, ouvrir le site dans Chrome, puis menu ⋮ > Installer l’application (ou Ajouter à l’écran d’accueil).

NOTES IMPORTANTES
- Le site doit être servi en HTTPS pour le service worker et l’installation PWA.
- Les données sont stockées localement dans le navigateur de l’appareil ; elles ne sont pas synchronisées entre appareils et peuvent être perdues si les données du navigateur sont effacées.
- Les logos de services tiers chargés depuis des sites externes nécessitent une connexion Internet.
- Google Agenda, Revolut, CoinMarketCap et l’agent IA sont présentés dans cette version comme éléments/états d’interface ; aucune authentification ni synchronisation API réelle n’est configurée dans le fichier fourni.
- Les réveils sont locaux : ils nécessitent que l’application reste active et ne garantissent pas une sonnerie lorsque le navigateur ou l’application est fermé(e), suspendu(e) par Android ou que l’appareil est éteint.
- Le cache hors connexion conserve le shell de l’application, mais ne rend pas disponibles les services externes.
