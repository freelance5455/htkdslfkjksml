# Hangero+ – Android projekt

Ez egy kész Android Studio projekt modern WebView-alapú felülettel és natív Android hangerősítéssel.

## Mit tud?

- **Eredeti hangerő** – extra erősítés kikapcsolva.
- **+50% erősítés** – natív `LoudnessEnhancer` +500 mB.
- **+100% erősítés** – natív `LoudnessEnhancer` +1000 mB.
- **Telefonhíváskor** az extra erősítés automatikusan 0-ra áll.
- **Hívás után** visszaáll a korábban kiválasztott erősítés.
- Nagy **Kilépés** gomb.
- Modern, sötét, mobilbarát kezelőfelület.

## Fontos Android-korlát

Az Android nem engedi, hogy egy egyszerű HTML-oldal tetszőlegesen a teljes rendszer hangját 150–200%-ra emelje. Ezért a projekt natív `LoudnessEnhancer` API-t használ.

A tényleges eredmény telefon- és Android-verziófüggő: egyes gyártók korlátozzák vagy részben figyelmen kívül hagyják a globális audio effectet. Ez nem garantálható minden készüléken és minden alkalmazásnál.

A +50% / +100% itt **erősítési mód**, nem a telefon hangerőcsúszkájának 150/200%-ra állítása. A decibel-erősítés és az észlelt hangerő nem ugyanaz.

## Fordítás APK-ra

### Android Studio
1. Csomagold ki a ZIP-et.
2. Nyisd meg az egész `Hangero_Modern_Android` mappát Android Studio-ban.
3. Várd meg a Gradle szinkronizálását.
4. `Build` → `Build APK(s)`.
5. Az elkészült APK telepíthető Androidra.

### Ha HTML → APK konvertert használsz
A pusztán HTML-t APK-vá alakító szolgáltatások többsége **nem fogja tudni a natív LoudnessEnhancer funkciót**, ezért ehhez Android-projektet kell támogatnia a szolgáltatásnak, vagy Android Studio-val kell fordítani.

## Engedélyek

- `MODIFY_AUDIO_SETTINGS`: hangerő/audio effect kezeléséhez.
- `READ_PHONE_STATE`: a hívás állapotának érzékeléséhez.

A program nem módosítja a telefonbeszélgetés hangerejét; hívás közben az extra média-erősítést kapcsolja ki.
