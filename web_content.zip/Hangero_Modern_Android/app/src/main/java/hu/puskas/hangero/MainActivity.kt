package hu.puskas.hangero

import android.media.AudioAttributes
import android.media.audiofx.LoudnessEnhancer
import android.os.Bundle
import android.telephony.PhoneStateListener
import android.telephony.TelephonyManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var enhancer: LoudnessEnhancer? = null
    private var selectedGain = 0
    private var inCall = false
    private lateinit var telephony: TelephonyManager
    private var phoneListener: PhoneStateListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)

        setupEnhancer()
        setupPhoneListener()
    }

    private fun setupEnhancer() {
        try {
            // Session 0 targets the global output mix where supported by the device.
            enhancer = LoudnessEnhancer(0).apply {
                enabled = true
                setTargetGain(0)
            }
        } catch (_: Throwable) {
            enhancer = null
        }
    }

    private fun setupPhoneListener() {
        telephony = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
        phoneListener = object : PhoneStateListener() {
            override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                when (state) {
                    TelephonyManager.CALL_STATE_RINGING,
                    TelephonyManager.CALL_STATE_OFFHOOK -> {
                        inCall = true
                        applyGain(0)
                        runOnUiThread {
                            web.evaluateJavascript("setCall(true)", null)
                        }
                    }
                    TelephonyManager.CALL_STATE_IDLE -> {
                        if (inCall) {
                            inCall = false
                            applyGain(selectedGain)
                            runOnUiThread {
                                web.evaluateJavascript("setCall(false)", null)
                            }
                        }
                    }
                }
            }
        }
        try {
            @Suppress("DEPRECATION")
            telephony.listen(phoneListener, PhoneStateListener.LISTEN_CALL_STATE)
        } catch (_: SecurityException) {
            // Permission can be requested by a converter/host environment.
        }
    }

    private fun applyGain(millibels: Int) {
        val e = enhancer ?: return
        try {
            e.setTargetGain(millibels)
            e.enabled = true
        } catch (_: Throwable) {}
    }

    inner class Bridge {
        @JavascriptInterface
        fun setGain(millibels: Int) {
            selectedGain = millibels.coerceIn(0, 1000)
            if (!inCall) applyGain(selectedGain)
        }

        @JavascriptInterface
        fun exitApp() {
            runOnUiThread { finishAndRemoveTask() }
        }
    }

    override fun onDestroy() {
        try {
            @Suppress("DEPRECATION")
            telephony.listen(phoneListener, PhoneStateListener.LISTEN_NONE)
        } catch (_: Throwable) {}
        try { enhancer?.release() } catch (_: Throwable) {}
        super.onDestroy()
    }
}
