THE END — 3D MONSTER SURVIVAL

HOW TO PLAY
1. Extract the ZIP file.
2. Open index.html in a modern browser (Chrome, Edge, Firefox).
3. Internet is required because Three.js is loaded from jsDelivr.
4. Press ENTER THE NIGHT.

DESKTOP
- WASD: move
- Mouse: aim
- Left click: shoot
- R: reload
- Shift: sprint
- 1 / 2: switch weapons

MOBILE
- Left thumb pad: move
- FIRE: shoot
- R: reload

GAMEPLAY
Survive increasingly difficult waves of monsters. Runners are quick, Brutes are tough,
and Night Stalkers are dangerous. Your score is the number of monsters defeated.
