# FormulaVerse AI Tutor — Setup Guide

## ✅ Current status: already active, no setup required

FormulaVerse's AI Tutor now works **out of the box** using **Puter.js** — a
service that lets the browser call real AI models (OpenAI, Anthropic,
Google, etc.) directly, with **no backend server and no API key** anywhere
in this project. Each user covers their own usage by signing in with a free
Puter.com account (Puter's "User-Pays" model), so this costs the
FormulaVerse developer nothing and requires no secret keys.

### What you (the student/user) need to do — one time

1. Open the **AI Tutor** screen in FormulaVerse.
2. You'll see a card that says **"One step to activate the AI Tutor"**.
3. Click **"Connect AI Tutor →"**.
4. A popup window opens from Puter.com. Either:
   - **Sign in** if you already have a free Puter.com account, or
   - **Sign up** (free, takes under a minute) if you don't.
5. Once the popup closes, you're connected — type a question and press
   **Send**. (If you skip step 3 and just type a question right away,
   the same sign-in popup will open automatically when you hit Send.)

That's the entire setup. No code, no environment variables, no deployment.

### Is this really free?

- **For you (the developer running this app): yes.** Puter.js is keyless and
  serverless — there's nothing for you to pay for or configure.
- **For each student using it:** Puter gives new accounts free usage
  credits, and many everyday tutoring questions fit comfortably within that.
  Very heavy usage may eventually draw on a user's own Puter account
  balance — this is between the student and Puter, not something
  FormulaVerse bills for. This is an honest trade-off of the "no backend,
  no API key" approach: see "Option B" below if you'd rather pay for and
  centrally control AI usage yourself.

### What this does NOT give you

- A hard, server-enforced daily quota. FormulaVerse still shows a "10
  messages/day" counter in the AI Tutor screen, but — like any purely
  client-side limit — it's a courtesy counter stored in this browser, not a
  secure per-account restriction. It is clearly labelled as such in the UI.
- A FormulaVerse-managed account system. "Connected" means signed in to a
  **Puter** account, not a FormulaVerse account.

### Changing the AI model

Edit `VITE_AI_MODEL` (a build-time environment variable) to switch models,
e.g. `anthropic/claude-haiku-4.5` or `google/gemini-3.8-flash`. The default,
`openai/gpt-4o-mini`, is a fast, capable, widely-available choice for
tutoring. No code changes needed — see `src/ai/config.ts`.

---

## Option B (advanced, optional): self-hosted backend

If you'd rather:
- centrally pay for and control AI costs yourself instead of each student
  needing a Puter account, and/or
- enforce a **hard, server-side daily quota** that can't be bypassed by
  clearing browser storage,

...you can still deploy your own backend exactly as before. Setting the
`VITE_AI_TUTOR_ENDPOINT` build-time environment variable switches
FormulaVerse over to that backend instead of Puter.js automatically (see
`src/ai/config.ts` — `AI_PROVIDER` becomes `"custom"`).

### Recommended provider (verified, current as of this writing)

**OpenAI `gpt-4o-mini`** — $0.15 per 1M input tokens / $0.60 per 1M output
tokens (OpenAI's own pricing, checked 2026). A typical tutoring exchange
costs roughly $0.0004–0.0005. **This is a paid API** — you need an OpenAI
account with billing enabled.

### Recommended backend host (free tier, verified)

**Cloudflare Workers** — 100,000 requests/day free, with Workers KV for
server-side quota tracking.

### Step-by-step

1. Create an OpenAI account, add billing, generate an API key.
2. Install Wrangler and create a Worker:
   ```bash
   npm install -g wrangler
   wrangler init formulaverse-ai-tutor
   ```
3. Copy `server-examples/cloudflare-worker-ai-tutor.js` into your Worker.
4. Create a KV namespace for quota tracking:
   ```bash
   wrangler kv:namespace create AI_QUOTA
   ```
   Add the returned `id` to `wrangler.toml` under `[[kv_namespaces]]`.
5. Store your key as a secret (never in source control):
   ```bash
   wrangler secret put OPENAI_API_KEY
   ```
6. Set `DAILY_LIMIT` and `ALLOWED_ORIGIN` in `wrangler.toml`.
7. Deploy: `wrangler deploy` — note the printed URL.
8. Set `VITE_AI_TUTOR_ENDPOINT` to that URL and rebuild FormulaVerse:
   ```bash
   VITE_AI_TUTOR_ENDPOINT=https://formulaverse-ai-tutor.<you>.workers.dev npm run build
   ```
9. Reopen the AI Tutor screen and ask a question to confirm it's live.

This path still has no API keys in the frontend — the secret lives only in
the Cloudflare Worker's environment.
