const modes={text:"Text to Video",image:"Photo to Video",talk:"Talking Photo",cartoon:"3D Cartoon",cinema:"Cinematic Film",reels:"Shorts / Reels"};
let selectedMode="text";
const $=id=>document.getElementById(id);
const apiBase=$('apiBase');
apiBase.value=localStorage.getItem('aiVideoBackendUrl')||'';
$('accessCode').value=sessionStorage.getItem('aiVideoAccessCode')||'';
apiBase.addEventListener('change',()=>localStorage.setItem('aiVideoBackendUrl',apiBase.value.trim().replace(/\/$/,'')));
$('accessCode').addEventListener('change',()=>sessionStorage.setItem('aiVideoAccessCode',$('accessCode').value));
document.querySelectorAll('.mode').forEach(btn=>btn.addEventListener('click',()=>{
 document.querySelectorAll('.mode').forEach(b=>b.classList.remove('active'));btn.classList.add('active');selectedMode=btn.dataset.mode;
 const examples={text:'एक रहस्यमयी भारतीय जंगल, धुंध, सिनेमैटिक कैमरा मूवमेंट...',image:'इस फोटो को स्वाभाविक गति और हल्के कैमरा मूवमेंट के साथ एनिमेट करें...',talk:'कैरेक्टर कैमरे की ओर देखकर हिंदी में बोले...',cartoon:'रंगीन 3D कार्टून कैरेक्टर, सुंदर बैकग्राउंड, स्मूद एनिमेशन...',cinema:'फिल्म जैसा दृश्य, नाटकीय रोशनी, वाइड शॉट, स्मूद कैमरा मूवमेंट...',reels:'आकर्षक वर्टिकल वीडियो, पहले 2 सेकंड में दमदार हुक...'};
 $('prompt').placeholder=examples[selectedMode];$('ratio').value=selectedMode==='reels'?'9:16':$('ratio').value;
}));
$('photo').addEventListener('change',e=>{const f=e.target.files&&e.target.files[0],p=$('preview');if(!f){p.hidden=true;return}if(!f.type.startsWith('image/')){alert('कृपया फोटो फ़ाइल चुनें।');e.target.value='';return}p.src=URL.createObjectURL(f);p.hidden=false});
function promptText(){return `Mode: ${modes[selectedMode]}\nPrompt: ${$('prompt').value.trim()}\nAspect ratio: ${$('ratio').value}\nDuration: ${$('duration').value} seconds\nImage attached: ${$('photo').files.length?'Yes':'No'}`}
function setStatus(msg){$('status').textContent=msg}
function fileToDataUrl(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file)})}
$('generate').addEventListener('click',async()=>{
 const prompt=$('prompt').value.trim();if(!prompt){alert('पहले वीडियो का विवरण लिखें।');return}
 const base=apiBase.value.trim().replace(/\/$/,'');localStorage.setItem('aiVideoBackendUrl',base);sessionStorage.setItem('aiVideoAccessCode',$('accessCode').value);if(!base){$('resultText').textContent=promptText();$('result').hidden=false;setStatus('Backend URL डालें और Save करें। अभी केवल prompt तैयार हुआ है।');$('result').scrollIntoView({behavior:'smooth'});return}
 if(selectedMode==='talk'){setStatus('Talking Photo/lip-sync के लिए अलग model integration चाहिए। अभी सामान्य video generation की कोशिश होगी।')}
 const btn=$('generate');btn.disabled=true;btn.textContent='⏳ AI वीडियो बन रहा है…';setStatus('Backend से संपर्क हो रहा है। वीडियो बनने में कुछ मिनट लग सकते हैं।');$('result').hidden=false;$('videoWrap').hidden=true;
 try{
   let imageDataUrl=null;const f=$('photo').files&&$('photo').files[0];if(f) imageDataUrl=await fileToDataUrl(f);
   const response=await fetch(base+'/api/generate',{method:'POST',headers:{'Content-Type':'application/json','x-app-access-code':$('accessCode').value},body:JSON.stringify({prompt,mode:selectedMode,aspectRatio:$('ratio').value,duration:Number($('duration').value),imageDataUrl})});
   const data=await response.json().catch(()=>({error:'Backend से सही जवाब नहीं मिला।'}));if(!response.ok)throw new Error(data.error||`Server error (${response.status})`);
   $('resultText').textContent=`${modes[selectedMode]}\n${data.message||'वीडियो तैयार है।'}\nRequest ID: ${data.requestId||'—'}`;
   if(data.videoUrl){$('generatedVideo').src=data.videoUrl;$('videoLink').href=data.videoUrl;$('videoWrap').hidden=false;setStatus('वीडियो तैयार है। इसे चलाएं या लिंक खोलें।')}else{setStatus(data.message||'Backend ने request स्वीकार की, लेकिन video URL नहीं मिला।')}
 }catch(err){$('resultText').textContent=promptText();setStatus('त्रुटि: '+(err.message||'Backend से कनेक्ट नहीं हो पाया।'));}
 finally{btn.disabled=false;btn.textContent='✨ AI वीडियो बनाएं';$('result').scrollIntoView({behavior:'smooth'})}
});
$('copy').addEventListener('click',async()=>{const t=promptText();try{await navigator.clipboard.writeText(t);alert('प्रॉम्प्ट कॉपी हो गया।')}catch{alert('कॉपी नहीं हुआ; टेक्स्ट को चुनकर कॉपी करें।')}});
$('downloadPrompt').addEventListener('click',()=>{const blob=new Blob([promptText()],{type:'text/plain;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='ai-video-prompt.txt';a.click();URL.revokeObjectURL(url)});

$('testBackend').addEventListener('click',async()=>{
 const base=apiBase.value.trim().replace(/\/$/,'');
 if(!base){setStatus('पहले Backend URL डालें।');return}
 setStatus('Backend की जाँच हो रही है…');
 try{const r=await fetch(base+'/api/health',{headers:{'x-app-access-code':$('accessCode').value}});const d=await r.json();if(!r.ok)throw new Error(d.error||`HTTP ${r.status}`);setStatus(d.ok?`Backend online है। API key configured: ${d.configured?'हाँ':'नहीं'}; access code जरूरी: ${d.authRequired?'हाँ':'नहीं'}`:'Backend जवाब मिला, लेकिन status सही नहीं है।')}catch(e){setStatus('Backend कनेक्शन नहीं हुआ: '+(e.message||'URL/इंटरनेट जाँचें।'))}
});
