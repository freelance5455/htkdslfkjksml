AI VIDEO STUDIO — Android App + AI Backend (Hindi Setup)
========================================================

इस ZIP में Android app का source, Node.js backend और cloud APK build workflow है। यह ZIP खुद install होने वाली APK नहीं है। APK GitHub Actions से build की जा सकती है; backend और AI provider के लिए अलग setup ज़रूरी है।

अभी उपलब्ध
-----------
1. Text-to-video API integration (Wan v2.6 text-to-video)
2. Photo-to-video API integration (Wan v2.6 image-to-video)
3. 9:16 / 16:9 / 1:1 ratio और 5/10/15 sec विकल्प
4. Cartoon, cinematic और Reels prompt styles
5. Video preview / result link
6. Backend health-check button
7. API key app के बजाय backend environment में रखी जाती है
8. GitHub Actions workflow से cloud पर debug APK build करने की सुविधा

सीमाएँ और लागत
--------------
- AI generation के लिए fal.ai account/API key चाहिए; generation paid हो सकती है। Current pricing/credits जाँचें और किसी payment से पहले parent/guardian की मदद लें।
- Talking Photo/lip-sync का UI मौजूद है, लेकिन असली lip-sync model integration इस build में नहीं है। यह mode साफ error message देगा, झूठा result नहीं दिखाएगा।
- AI provider अपने model IDs/input parameters बदल सकता है।
- Backend में basic rate limit और optional access code है; यह पूर्ण account/billing system नहीं है।
- Generated video URL provider की hosting पर होता है; इसे सुरक्षित जगह सेव करें।

A. BACKEND DEPLOY (मोबाइल से भी, लेकिन account/hosting चाहिए)
-------------------------------------------------------------
1. ZIP extract करें।
2. GitHub पर नया PRIVATE repository बनाएँ; इस folder की files repository में upload करें।
3. Render या किसी Node.js/Docker hosting service में नया Web Service बनाएँ।
4. Service root directory `backend` रखें और Docker runtime चुनें (या Node runtime पर `npm install` / `npm start` चलाएँ)।
5. Environment variables जोड़ें:
   FAL_KEY = fal.ai से मिली निजी API key
   APP_ACCESS_CODE = एक लंबा, अनुमान न लगाया जा सकने वाला निजी code
   FAL_TEXT_MODEL = wan/v2.6/text-to-video
   FAL_IMAGE_MODEL = wan/v2.6/image-to-video
6. Deploy करें। Hosting से मिला HTTPS URL कॉपी करें।
7. Browser में `https://YOUR-BACKEND-URL/api/health` खोलें। `ok:true` और `configured:true` दिखना चाहिए।
8. Android app में Backend URL और वही App access code डालें, फिर “Backend कनेक्शन जाँचें” दबाएँ।

सुरक्षा: FAL_KEY को app source, GitHub files, screenshots या public chat में कभी न डालें। इसे सिर्फ hosting के Environment Variables में रखें। Backend URL/access code भी सार्वजनिक न करें।

B. APK BUILD (केवल Android फोन हो तो cloud build)
--------------------------------------------------
1. GitHub account/repository चाहिए; भरोसेमंद बड़े व्यक्ति की मदद ले सकते हैं।
2. इस project की सभी files PRIVATE GitHub repository में upload करें। `.env` या API key upload न करें।
3. ऊपर `Actions` tab खोलें। पहली बार workflow enable करने का prompt आए तो enable करें।
4. `Build Android APK` workflow खोलें और `Run workflow` दबाएँ; या `main` branch में code push करें।
5. Workflow के पूरा होने तक प्रतीक्षा करें। सफल run खोलें। नीचे `Artifacts` में `AI-Video-Studio-debug-APK` डाउनलोड करें।
6. ZIP artifact extract करें और APK पर tap करके install करें। Android पूछे तो केवल उसी APK को install करें जिसे आपने अपनी निजी repository के workflow से बनाया है।
7. Install न हो तो Android Settings में उस browser/file manager के लिए “Install unknown apps” अनुमति अस्थायी रूप से दें, फिर काम होने पर बंद कर दें।

Official Android build docs: https://developer.android.com/build/build-for-release
Official fal text model docs: https://fal.ai/models/wan/v2.6/text-to-video
Official fal image model docs: https://fal.ai/models/wan/v2.6/image-to-video

ध्यान दें: मैं इस चैट से आपके GitHub/hosting account में login, server deploy, API key बनाना या remote build शुरू नहीं कर सकता। इसलिए अभी live backend URL या ready APK का दावा नहीं कर रहा हूँ। यह project उन steps को पूरा करने के लिए तैयार किया गया है।
