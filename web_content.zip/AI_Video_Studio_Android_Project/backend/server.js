import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import { fal } from '@fal-ai/client';

const app = express();
const PORT = Number(process.env.PORT || 8080);
const ACCESS_CODE = process.env.APP_ACCESS_CODE || '';
const TEXT_MODEL = process.env.FAL_TEXT_MODEL || 'wan/v2.6/text-to-video';
const IMAGE_MODEL = process.env.FAL_IMAGE_MODEL || 'wan/v2.6/image-to-video';

if (process.env.FAL_KEY) fal.config({ credentials: process.env.FAL_KEY });
app.disable('x-powered-by');
app.use(cors({ origin: true, methods: ['GET', 'POST'], allowedHeaders: ['Content-Type', 'x-app-access-code'] }));
app.use(express.json({ limit: '12mb' }));
app.use(rateLimit({ windowMs: 60 * 1000, limit: 5, standardHeaders: 'draft-7', legacyHeaders: false }));

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'AI Video Studio backend', configured: Boolean(process.env.FAL_KEY), authRequired: Boolean(ACCESS_CODE) }));

app.post('/api/generate', async (req, res) => {
  if (ACCESS_CODE && req.get('x-app-access-code') !== ACCESS_CODE) {
    return res.status(401).json({ error: 'Access code गलत है। Backend सेट करने वाले व्यक्ति से सही code लें।' });
  }
  if (!process.env.FAL_KEY) return res.status(503).json({ error: 'Backend पर FAL_KEY सेट नहीं है। Server admin को environment variable सेट करना होगा।' });

  const { prompt, mode = 'text', aspectRatio = '9:16', duration = 5, imageDataUrl = null } = req.body || {};
  if (typeof prompt !== 'string' || !prompt.trim()) return res.status(400).json({ error: 'Prompt खाली है।' });
  if (prompt.length > 4500) return res.status(400).json({ error: 'Prompt बहुत लंबा है; 4500 characters से कम रखें।' });
  if (![ '9:16', '16:9', '1:1', '4:3', '3:4' ].includes(aspectRatio)) return res.status(400).json({ error: 'Aspect ratio समर्थित नहीं है।' });
  const seconds = Number(duration);
  if (![5, 10, 15].includes(seconds)) return res.status(400).json({ error: 'Duration 5, 10 या 15 seconds होनी चाहिए।' });
  if (imageDataUrl && (typeof imageDataUrl !== 'string' || !/^data:image\/(png|jpeg|jpg|webp);base64,/i.test(imageDataUrl))) {
    return res.status(400).json({ error: 'केवल PNG, JPG या WebP फोटो अपलोड करें।' });
  }
  if (imageDataUrl && imageDataUrl.length > 10_000_000) return res.status(413).json({ error: 'फोटो बड़ी है। छोटी फोटो (लगभग 7 MB से कम) इस्तेमाल करें।' });

  if (mode === 'talk') return res.status(501).json({ error: 'Talking Photo/lip-sync अभी सक्रिय नहीं है। इसके लिए अलग lip-sync AI model और provider API जोड़नी होगी। बाकी video modes काम कर सकते हैं।' });

  const useImage = Boolean(imageDataUrl);
  const model = useImage ? IMAGE_MODEL : TEXT_MODEL;
  let finalPrompt = prompt.trim();
  if (mode === 'cartoon') finalPrompt += ', polished 3D cartoon animation, expressive characters, smooth motion';
  if (mode === 'cinema') finalPrompt += ', cinematic composition, dramatic lighting, smooth camera movement, filmic color grading';
  if (mode === 'reels') finalPrompt += ', vertical social video, strong opening, clear subject, fast visual storytelling';
  if (mode === 'talk') finalPrompt += ', character facing the camera, natural facial movement';

  try {
    const input = useImage
      ? { prompt: finalPrompt, image_url: imageDataUrl, aspect_ratio: aspectRatio, duration: String(seconds), resolution: '720p', enable_safety_checker: true }
      : { prompt: finalPrompt, aspect_ratio: aspectRatio, duration: String(seconds), resolution: '720p', enable_safety_checker: true };
    const result = await fal.subscribe(model, { input, logs: false });
    const videoUrl = result?.data?.video?.url || result?.data?.video_url || null;
    if (!videoUrl) return res.status(502).json({ error: 'AI provider ने video URL नहीं लौटाया। Model input settings जाँचें।' });
    return res.json({ ok: true, videoUrl, requestId: result.requestId || null, model, message: 'वीडियो तैयार है। इसे चलाएं या अलग से खोलें।' });
  } catch (error) {
    console.error('AI generation failed:', error?.message || error);
    const status = error?.status || error?.statusCode;
    if (status === 401 || status === 403) return res.status(502).json({ error: 'AI provider की API key/permissions सही नहीं हैं। Server admin को key जाँचनी होगी।' });
    return res.status(502).json({ error: 'AI वीडियो नहीं बन पाया। Provider का model ID, API balance/credits और server logs जाँचें।' });
  }
});

app.listen(PORT, '0.0.0.0', () => console.log(`AI Video Studio backend listening on ${PORT}`));
