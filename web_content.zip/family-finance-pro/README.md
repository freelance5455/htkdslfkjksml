# Family Finance Pro — Android source project

Offline-first family expense tracker. The Android wrapper loads the bundled local HTML app in a WebView. It does not request Internet, SMS, contacts, location, or bank permissions.

## Build an APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this `family-finance-pro` folder in Android Studio.
3. Allow Gradle sync (Android Gradle Plugin 8.7.3; JDK 17 recommended).
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio writes the debug APK under `app/build/outputs/apk/debug/app-debug.apk`.
6. For personal installation, transfer that APK to your Android phone and allow installation from that source. For distribution, create a signed release APK using **Build → Generate Signed Bundle / APK**.

## Features
- Manual transaction entry with date/time, amount, type, category, item, payer, beneficiary, payment method, nature, planned/unplanned, merchant and notes.
- Expense, income, transfer, investment, loan principal and interest classifications.
- Family profiles, shared household label, category/member/family budgets.
- Monthly, Indian FY quarterly (Apr–Jun, Jul–Sep, Oct–Dec, Jan–Mar), and annual reports.
- Category and payer breakdowns, monthly trend, small/unplanned spend analysis, print-to-PDF, CSV export/import, JSON backup/restore.
- Local WebView storage only. No cloud sync or automatic bank/SMS access.

## Fold compatibility
There is no direct Fold API integration in this build. Import a CSV exported from Fold if your Fold account/app version offers transaction export. CSV import is a best-effort generic mapper; inspect imported rows and remove duplicates.

## Data safety
Data is stored in the app's local WebView storage. Export a JSON backup regularly. Clearing app data or uninstalling the app can delete local records. This project intentionally does not request Internet, SMS, or bank credentials.
