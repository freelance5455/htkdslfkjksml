# High-School Physics Formula Explanations

Each formula includes its equation, meaning, symbol guide, SI unit, when to use it, an example or worked method, and a common caution.

**General method:** write the known values, convert to SI units, choose the equation, substitute, calculate, and include the unit.

## Mechanics · Speed
**Formula:** `v = d / t`
**Meaning:** Average speed = distance travelled ÷ time taken.
**Symbols:** v: speed or velocity (m/s); d: distance (m); t: time (s)
**SI unit:** m/s
**When to use:** Use when distance and time are known.
**Worked example:** A cyclist travels 120 m in 20 s. v = d/t = 120/20 = 6 m/s.
**Common caution:** Use when distance and time are known.

## Mechanics · Velocity
**Formula:** `v = displacement / time`
**Meaning:** Average velocity = displacement ÷ time.
**Symbols:** v: speed or velocity (m/s)
**SI unit:** m/s
**When to use:** Velocity includes direction; speed does not.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into v = displacement / time, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Velocity includes direction; speed does not.

## Mechanics · Acceleration
**Formula:** `a = (v − u) / t`
**Meaning:** Change in velocity per unit time.
**Symbols:** v: speed or velocity (m/s); t: time (s); u: initial velocity (m/s); a: acceleration (m/s²)
**SI unit:** m/s²
**When to use:** u is initial velocity and v is final velocity.
**Worked example:** A car changes speed from 4 m/s to 16 m/s in 3 s. a = (16−4)/3 = 4 m/s².
**Common caution:** u is initial velocity and v is final velocity.

## Mechanics · First equation of motion
**Formula:** `v = u + at`
**Meaning:** Final velocity after constant acceleration.
**Symbols:** v: speed or velocity (m/s); u: initial velocity (m/s)
**SI unit:** m/s
**When to use:** Valid for constant acceleration.
**Worked example:** u=2 m/s, a=3 m/s², t=4 s. v=2+(3×4)=14 m/s.
**Common caution:** Valid for constant acceleration.

## Mechanics · Second equation of motion
**Formula:** `s = ut + ½at²`
**Meaning:** Displacement after time t under constant acceleration.
**Symbols:** s: displacement (m)
**SI unit:** m
**When to use:** Use when final velocity is not needed.
**Worked example:** u=3 m/s, a=2 m/s², t=5 s. s=3×5+½×2×25=40 m.
**Common caution:** Use when final velocity is not needed.

## Mechanics · Third equation of motion
**Formula:** `v² = u² + 2as`
**Meaning:** Relates velocity and displacement without time.
**Symbols:** v: speed or velocity (m/s); u: initial velocity (m/s)
**SI unit:** m²/s²
**When to use:** Use when time is not given.
**Worked example:** u=4 m/s, a=3 m/s², s=8 m. v²=16+48=64, therefore v=8 m/s.
**Common caution:** Use when time is not given.

## Mechanics · Displacement
**Formula:** `s = ½(u + v)t`
**Meaning:** Displacement for constant acceleration.
**Symbols:** v: speed or velocity (m/s); t: time (s); s: displacement (m); u: initial velocity (m/s)
**SI unit:** m
**When to use:** Average velocity × time.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into s = ½(u + v)t, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Average velocity × time.

## Mechanics · Newton's second law
**Formula:** `F = ma`
**Meaning:** Net force equals mass multiplied by acceleration.
**Symbols:** F: force (N)
**SI unit:** N
**When to use:** Use the resultant force, not just one force.
**Worked example:** A net force of 12 N acts on 3 kg. a=F/m=12/3=4 m/s².
**Common caution:** Use the resultant force, not just one force.

## Mechanics · Weight
**Formula:** `W = mg`
**Meaning:** Gravitational force on an object.
**Symbols:** W: work (J) or weight (N), depending on context
**SI unit:** N
**When to use:** Near Earth, g ≈ 9.8 m/s² (sometimes 10 m/s²).
**Worked example:** For m=5 kg and g=9.8 m/s², W=mg=5×9.8=49 N.
**Common caution:** Near Earth, g ≈ 9.8 m/s² (sometimes 10 m/s²).

## Mechanics · Momentum
**Formula:** `p = mv`
**Meaning:** Mass multiplied by velocity.
**Symbols:** p: momentum (kg·m/s) or pressure (Pa), depending on context
**SI unit:** kg·m/s
**When to use:** Momentum is a vector.
**Worked example:** A 2 kg ball moves at 5 m/s. p=mv=2×5=10 kg·m/s.
**Common caution:** Momentum is a vector.

## Mechanics · Impulse
**Formula:** `J = FΔt = Δp`
**Meaning:** Force multiplied by time equals change in momentum.
**Symbols:** t: time (s); F: force (N); p: momentum (kg·m/s) or pressure (Pa), depending on context; J: impulse (N·s)
**SI unit:** N·s
**When to use:** For constant force; impulse is change in momentum.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into J = FΔt = Δp, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** For constant force; impulse is change in momentum.

## Mechanics · Force from impulse
**Formula:** `F = Δp / Δt`
**Meaning:** Average force during a time interval.
**Symbols:** t: time (s); F: force (N); p: momentum (kg·m/s) or pressure (Pa), depending on context
**SI unit:** N
**When to use:** Useful in collision questions.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into F = Δp / Δt, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Useful in collision questions.

## Mechanics · Friction
**Formula:** `f = μN`
**Meaning:** Friction magnitude for kinetic friction or limiting friction model.
**Symbols:** f: frequency (Hz); N: number of turns/particles
**SI unit:** N
**When to use:** μ is coefficient of friction; check whether friction is static or kinetic.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into f = μN, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** μ is coefficient of friction; check whether friction is static or kinetic.

## Mechanics · Centripetal acceleration
**Formula:** `a_c = v² / r = ω²r`
**Meaning:** Acceleration directed toward the centre of circular motion.
**Symbols:** v: speed or velocity (m/s); a: acceleration (m/s²); r: radius/separation (m); ω: angular speed/frequency (rad/s); c: specific heat capacity or speed of light, depending on context
**SI unit:** m/s²
**When to use:** The direction continually changes.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into a_c = v² / r = ω²r, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** The direction continually changes.

## Mechanics · Centripetal force
**Formula:** `F_c = mv² / r`
**Meaning:** Net inward force needed for circular motion.
**Symbols:** F: force (N); r: radius/separation (m); c: specific heat capacity or speed of light, depending on context
**SI unit:** N
**When to use:** Not a new type of force; it is the resultant inward force.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into F_c = mv² / r, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Not a new type of force; it is the resultant inward force.

## Mechanics · Angular speed
**Formula:** `ω = θ / t`
**Meaning:** Angular displacement per unit time.
**Symbols:** t: time (s); ω: angular speed/frequency (rad/s); θ: angle
**SI unit:** rad/s
**When to use:** For uniform circular motion, ω = 2π/T.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into ω = θ / t, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** For uniform circular motion, ω = 2π/T.

## Mechanics · Linear-angular speed
**Formula:** `v = ωr`
**Meaning:** Tangential speed in circular motion.
**Symbols:** v: speed or velocity (m/s); r: radius/separation (m)
**SI unit:** m/s
**When to use:** r is radius.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into v = ωr, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** r is radius.

## Mechanics · Period and frequency
**Formula:** `f = 1/T`
**Meaning:** Frequency is the number of cycles per second.
**Symbols:** f: frequency (Hz); T: period (s) or absolute temperature (K), depending on context
**SI unit:** Hz
**When to use:** T is period in seconds.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into f = 1/T, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** T is period in seconds.

## Mechanics · Circular period
**Formula:** `T = 2πr / v = 2π / ω`
**Meaning:** Time for one complete revolution.
**Symbols:** v: speed or velocity (m/s); T: period (s) or absolute temperature (K), depending on context; r: radius/separation (m); ω: angular speed/frequency (rad/s)
**SI unit:** s
**When to use:** For uniform circular motion.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into T = 2πr / v = 2π / ω, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** For uniform circular motion.

## Mechanics · Work
**Formula:** `W = Fd cosθ`
**Meaning:** Work done by a constant force.
**Symbols:** W: work (J) or weight (N), depending on context
**SI unit:** J
**When to use:** θ is angle between force and displacement.
**Worked example:** A 20 N force moves an object 3 m in its direction. W=20×3×cos0°=60 J.
**Common caution:** θ is angle between force and displacement.

## Mechanics · Kinetic energy
**Formula:** `K.E. = ½mv²`
**Meaning:** Energy due to motion.
**Symbols:** E: energy (J) or electric field (N/C), depending on context
**SI unit:** J
**When to use:** Speed is squared.
**Worked example:** A 2 kg object moves at 3 m/s. K.E.=½×2×3²=9 J.
**Common caution:** Speed is squared.

## Mechanics · Gravitational potential energy
**Formula:** `P.E. = mgh`
**Meaning:** Energy due to height in a uniform gravitational field.
**Symbols:** P: power (W) or pressure (Pa), depending on context; E: energy (J) or electric field (N/C), depending on context
**SI unit:** J
**When to use:** Choose a reference level for h.
**Worked example:** A 2 kg bag is lifted 4 m with g=10 m/s². P.E.=2×10×4=80 J.
**Common caution:** Choose a reference level for h.

## Mechanics · Elastic potential energy
**Formula:** `E = ½kx²`
**Meaning:** Energy stored in a stretched or compressed spring.
**Symbols:** E: energy (J) or electric field (N/C), depending on context
**SI unit:** J
**When to use:** Within Hooke's-law limit.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into E = ½kx², calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Within Hooke's-law limit.

## Mechanics · Power
**Formula:** `P = W / t = E / t`
**Meaning:** Rate of doing work or transferring energy.
**Symbols:** t: time (s); W: work (J) or weight (N), depending on context; P: power (W) or pressure (Pa), depending on context; E: energy (J) or electric field (N/C), depending on context
**SI unit:** W
**When to use:** 1 watt = 1 joule per second.
**Worked example:** A machine does 600 J of work in 10 s. P=W/t=600/10=60 W.
**Common caution:** 1 watt = 1 joule per second.

## Mechanics · Power at constant speed
**Formula:** `P = Fv`
**Meaning:** Power when force and velocity are parallel.
**Symbols:** P: power (W) or pressure (Pa), depending on context
**SI unit:** W
**When to use:** More generally use P = Fv cosθ.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into P = Fv, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** More generally use P = Fv cosθ.

## Mechanics · Efficiency
**Formula:** `η = (useful output / total input) × 100%`
**Meaning:** Percentage of input converted to useful output.
**Symbols:** η: efficiency
**SI unit:** %
**When to use:** Use the same type of quantity in numerator and denominator.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into η = (useful output / total input) × 100%, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Use the same type of quantity in numerator and denominator.

## Mechanics · Hooke's law
**Formula:** `F = kx`
**Meaning:** Spring force magnitude is proportional to extension/compression.
**Symbols:** F: force (N)
**SI unit:** N
**When to use:** Restoring force acts opposite to displacement.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into F = kx, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Restoring force acts opposite to displacement.

## Mechanics · Gravitational force
**Formula:** `F = Gm₁m₂ / r²`
**Meaning:** Attractive force between two point masses.
**Symbols:** F: force (N); m: mass (kg); r: radius/separation (m)
**SI unit:** N
**When to use:** r is distance between centres.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into F = Gm₁m₂ / r², calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** r is distance between centres.

## Mechanics · Gravitational field strength
**Formula:** `g = F / m = GM / r²`
**Meaning:** Force per unit mass.
**Symbols:** F: force (N); m: mass (kg); g: gravitational acceleration/field strength (m/s² or N/kg); r: radius/separation (m)
**SI unit:** N/kg
**When to use:** Near Earth's surface g is approximately 9.8 N/kg.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into g = F / m = GM / r², calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Near Earth's surface g is approximately 9.8 N/kg.

## Mechanics · Density
**Formula:** `ρ = m / V`
**Meaning:** Mass per unit volume.
**Symbols:** m: mass (kg); V: potential difference (V) or volume (m³), depending on context; ρ: density (kg/m³) or resistivity (Ω·m), depending on context
**SI unit:** kg/m³
**When to use:** Convert units before substituting.
**Worked example:** A 200 g object has volume 100 cm³. Density=2 g/cm³ (200 kg/m³).
**Common caution:** Convert units before substituting.

## Mechanics · Pressure
**Formula:** `p = F / A`
**Meaning:** Normal force per unit area.
**Symbols:** F: force (N); p: momentum (kg·m/s) or pressure (Pa), depending on context; A: area (m²) or amplitude (m), depending on context
**SI unit:** Pa
**When to use:** 1 Pa = 1 N/m².
**Worked example:** A 100 N force acts on 2 m². p=F/A=100/2=50 Pa.
**Common caution:** 1 Pa = 1 N/m².

## Mechanics · Liquid pressure
**Formula:** `p = ρgh`
**Meaning:** Gauge pressure at depth h in a liquid.
**Symbols:** p: momentum (kg·m/s) or pressure (Pa), depending on context
**SI unit:** Pa
**When to use:** Add atmospheric pressure for absolute pressure.
**Worked example:** At 2 m depth in water, p=1000×9.8×2=19,600 Pa gauge pressure.
**Common caution:** Add atmospheric pressure for absolute pressure.

## Mechanics · Upthrust
**Formula:** `F_B = ρ_fluid g V_displaced`
**Meaning:** Buoyant force equals weight of displaced fluid.
**Symbols:** F: force (N); g: gravitational acceleration/field strength (m/s² or N/kg); V: potential difference (V) or volume (m³), depending on context; ρ: density (kg/m³) or resistivity (Ω·m), depending on context; B: magnetic flux density (T)
**SI unit:** N
**When to use:** Archimedes' principle.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into F_B = ρ_fluid g V_displaced, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Archimedes' principle.

## Mechanics · Moment of force
**Formula:** `τ = Fd⊥`
**Meaning:** Turning effect of a force.
**Symbols:** τ: torque (N·m)
**SI unit:** N·m
**When to use:** d⊥ is perpendicular distance from pivot.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into τ = Fd⊥, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** d⊥ is perpendicular distance from pivot.

## Mechanics · Equilibrium condition
**Formula:** `ΣF = 0 and Στ = 0`
**Meaning:** For translational and rotational equilibrium.
**Symbols:** F: force (N); τ: torque (N·m)
**SI unit:** —
**When to use:** Both conditions are needed for a rigid body.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into ΣF = 0 and Στ = 0, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Both conditions are needed for a rigid body.

## Mechanics · Projectile horizontal range
**Formula:** `R = (u² sin 2θ) / g`
**Meaning:** Range for launch and landing at the same height.
**Symbols:** u: initial velocity (m/s); g: gravitational acceleration/field strength (m/s² or N/kg); R: resistance (Ω) or range (m), depending on context; θ: angle
**SI unit:** m
**When to use:** Neglect air resistance.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into R = (u² sin 2θ) / g, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Neglect air resistance.

## Mechanics · Projectile maximum height
**Formula:** `H = u² sin²θ / (2g)`
**Meaning:** Maximum vertical rise above launch point.
**Symbols:** u: initial velocity (m/s); g: gravitational acceleration/field strength (m/s² or N/kg); θ: angle
**SI unit:** m
**When to use:** Neglect air resistance.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into H = u² sin²θ / (2g), calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Neglect air resistance.

## Mechanics · Projectile time of flight
**Formula:** `T = 2u sinθ / g`
**Meaning:** Total flight time when landing at launch height.
**Symbols:** u: initial velocity (m/s); g: gravitational acceleration/field strength (m/s² or N/kg); T: period (s) or absolute temperature (K), depending on context
**SI unit:** s
**When to use:** Neglect air resistance.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into T = 2u sinθ / g, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Neglect air resistance.

## Waves & sound · Wave speed
**Formula:** `v = fλ`
**Meaning:** Wave speed = frequency × wavelength.
**Symbols:** v: speed or velocity (m/s); f: frequency (Hz)
**SI unit:** m/s
**When to use:** Works for periodic waves.
**Worked example:** A wave has f=5 Hz and λ=2 m. v=fλ=5×2=10 m/s.
**Common caution:** Works for periodic waves.

## Waves & sound · Wave period
**Formula:** `T = 1/f`
**Meaning:** Time for one complete oscillation.
**Symbols:** f: frequency (Hz); T: period (s) or absolute temperature (K), depending on context
**SI unit:** s
**When to use:** Frequency is measured in hertz.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into T = 1/f, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Frequency is measured in hertz.

## Waves & sound · Wave frequency
**Formula:** `f = 1/T`
**Meaning:** Number of cycles per second.
**Symbols:** f: frequency (Hz); T: period (s) or absolute temperature (K), depending on context
**SI unit:** Hz
**When to use:** Use this equation when the known quantities match the variables shown and the situation is wave frequency.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into f = 1/T, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Check units, signs and direction. Make sure the physical conditions for this equation are satisfied.

## Waves & sound · Echo distance
**Formula:** `d = vt / 2`
**Meaning:** Distance to reflecting surface using echo time.
**Symbols:** d: distance (m)
**SI unit:** m
**When to use:** Sound travels to the surface and back.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into d = vt / 2, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Sound travels to the surface and back.

## Waves & sound · String wave speed
**Formula:** `v = √(F_T / μ)`
**Meaning:** Wave speed on a stretched string.
**Symbols:** v: speed or velocity (m/s); F: force (N); T: period (s) or absolute temperature (K), depending on context; μ: coefficient of friction or mass per unit length
**SI unit:** m/s
**When to use:** μ is mass per unit length.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into v = √(F_T / μ), calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** μ is mass per unit length.

## Waves & sound · Intensity
**Formula:** `I = P / A`
**Meaning:** Power transmitted per unit area.
**Symbols:** I: current (A) or intensity (W/m²), depending on context; P: power (W) or pressure (Pa), depending on context; A: area (m²) or amplitude (m), depending on context
**SI unit:** W/m²
**When to use:** For a point source, intensity spreads over a sphere.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into I = P / A, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** For a point source, intensity spreads over a sphere.

## Waves & sound · Inverse-square intensity
**Formula:** `I ∝ 1/r²`
**Meaning:** Intensity from a point source decreases with square of distance.
**Symbols:** I: current (A) or intensity (W/m²), depending on context; r: radius/separation (m)
**SI unit:** —
**When to use:** Assumes uniform spreading and negligible absorption.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into I ∝ 1/r², calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Assumes uniform spreading and negligible absorption.

## Waves & sound · Doppler effect (general)
**Formula:** `f' = f (v ± v_o) / (v ∓ v_s)`
**Meaning:** Observed frequency when source or observer moves.
**Symbols:** v: speed or velocity (m/s); s: displacement (m); f: frequency (Hz)
**SI unit:** Hz
**When to use:** Choose signs so approaching gives higher frequency.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into f' = f (v ± v_o) / (v ∓ v_s), calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Choose signs so approaching gives higher frequency.

## Waves & sound · Beat frequency
**Formula:** `f_b = |f₁ − f₂|`
**Meaning:** Number of beats per second from two close frequencies.
**Symbols:** f: frequency (Hz)
**SI unit:** Hz
**When to use:** Use this equation when the known quantities match the variables shown and the situation is beat frequency.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into f_b = |f₁ − f₂|, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Check units, signs and direction. Make sure the physical conditions for this equation are satisfied.

## Waves & sound · Simple pendulum period
**Formula:** `T = 2π√(L/g)`
**Meaning:** Period for small oscillations.
**Symbols:** g: gravitational acceleration/field strength (m/s² or N/kg); T: period (s) or absolute temperature (K), depending on context; L: length (m) or latent heat (J/kg)
**SI unit:** s
**When to use:** Small-angle approximation.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into T = 2π√(L/g), calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Small-angle approximation.

## Waves & sound · Mass-spring period
**Formula:** `T = 2π√(m/k)`
**Meaning:** Period of an ideal mass-spring oscillator.
**Symbols:** m: mass (kg); T: period (s) or absolute temperature (K), depending on context; k: spring constant (N/m) or another constant, depending on context
**SI unit:** s
**When to use:** Use this equation when the known quantities match the variables shown and the situation is mass-spring period.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into T = 2π√(m/k), calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Check units, signs and direction. Make sure the physical conditions for this equation are satisfied.

## Waves & sound · SHM acceleration
**Formula:** `a = −ω²x`
**Meaning:** Acceleration in simple harmonic motion.
**Symbols:** a: acceleration (m/s²); ω: angular speed/frequency (rad/s)
**SI unit:** m/s²
**When to use:** Negative sign means toward equilibrium.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into a = −ω²x, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Negative sign means toward equilibrium.

## Waves & sound · SHM displacement
**Formula:** `x = A cos(ωt + φ)`
**Meaning:** One possible equation for SHM displacement.
**Symbols:** t: time (s); A: area (m²) or amplitude (m), depending on context; φ: phase angle or work function
**SI unit:** m
**When to use:** Choice of sine/cosine depends on initial conditions.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into x = A cos(ωt + φ), calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Choice of sine/cosine depends on initial conditions.

## Waves & sound · SHM angular frequency
**Formula:** `ω = 2πf = 2π/T`
**Meaning:** Angular frequency of oscillation.
**Symbols:** f: frequency (Hz); T: period (s) or absolute temperature (K), depending on context; ω: angular speed/frequency (rad/s)
**SI unit:** rad/s
**When to use:** Use this equation when the known quantities match the variables shown and the situation is shm angular frequency.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into ω = 2πf = 2π/T, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Check units, signs and direction. Make sure the physical conditions for this equation are satisfied.

## Thermal physics · Heat energy
**Formula:** `Q = mcΔT`
**Meaning:** Heat transferred for a temperature change without phase change.
**Symbols:** Q: heat energy (J) or charge (C), depending on context; T: period (s) or absolute temperature (K), depending on context
**SI unit:** J
**When to use:** c is specific heat capacity.
**Worked example:** Heat 2 kg of water by 5°C; c=4200 J/(kg·°C). Q=2×4200×5=42,000 J.
**Common caution:** c is specific heat capacity.

## Thermal physics · Specific heat capacity
**Formula:** `c = Q / (mΔT)`
**Meaning:** Heat needed per kilogram per kelvin.
**Symbols:** m: mass (kg); Q: heat energy (J) or charge (C), depending on context; T: period (s) or absolute temperature (K), depending on context; c: specific heat capacity or speed of light, depending on context
**SI unit:** J/(kg·K)
**When to use:** Use this equation when the known quantities match the variables shown and the situation is specific heat capacity.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into c = Q / (mΔT), calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Check units, signs and direction. Make sure the physical conditions for this equation are satisfied.

## Thermal physics · Latent heat
**Formula:** `Q = mL`
**Meaning:** Energy for a change of state at constant temperature.
**Symbols:** Q: heat energy (J) or charge (C), depending on context
**SI unit:** J
**When to use:** L is specific latent heat.
**Worked example:** Melt 0.5 kg with L=334,000 J/kg. Q=mL=167,000 J.
**Common caution:** L is specific latent heat.

## Thermal physics · Linear expansion
**Formula:** `ΔL = αL₀ΔT`
**Meaning:** Change in length due to temperature change.
**Symbols:** T: period (s) or absolute temperature (K), depending on context; L: length (m) or latent heat (J/kg)
**SI unit:** m
**When to use:** For small temperature changes.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into ΔL = αL₀ΔT, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** For small temperature changes.

## Thermal physics · Ideal gas law
**Formula:** `pV = nRT`
**Meaning:** Relationship among pressure, volume, amount and temperature.
**Symbols:** Use the definitions given in your textbook for the symbols in this equation.
**SI unit:** Pa·m³
**When to use:** Use absolute temperature in kelvin.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into pV = nRT, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Use absolute temperature in kelvin.

## Thermal physics · Combined gas law
**Formula:** `p₁V₁/T₁ = p₂V₂/T₂`
**Meaning:** For a fixed amount of ideal gas.
**Symbols:** p: momentum (kg·m/s) or pressure (Pa), depending on context; V: potential difference (V) or volume (m³), depending on context; T: period (s) or absolute temperature (K), depending on context
**SI unit:** —
**When to use:** Temperatures must be in kelvin.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into p₁V₁/T₁ = p₂V₂/T₂, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Temperatures must be in kelvin.

## Thermal physics · Boyle's law
**Formula:** `p₁V₁ = p₂V₂`
**Meaning:** Pressure is inversely proportional to volume at constant temperature.
**Symbols:** p: momentum (kg·m/s) or pressure (Pa), depending on context; V: potential difference (V) or volume (m³), depending on context
**SI unit:** —
**When to use:** Fixed amount of gas.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into p₁V₁ = p₂V₂, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Fixed amount of gas.

## Thermal physics · Charles's law
**Formula:** `V₁/T₁ = V₂/T₂`
**Meaning:** Volume is proportional to absolute temperature at constant pressure.
**Symbols:** V: potential difference (V) or volume (m³), depending on context; T: period (s) or absolute temperature (K), depending on context
**SI unit:** —
**When to use:** Temperatures in kelvin.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into V₁/T₁ = V₂/T₂, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Temperatures in kelvin.

## Thermal physics · Pressure law
**Formula:** `p₁/T₁ = p₂/T₂`
**Meaning:** Pressure is proportional to absolute temperature at constant volume.
**Symbols:** p: momentum (kg·m/s) or pressure (Pa), depending on context; T: period (s) or absolute temperature (K), depending on context
**SI unit:** —
**When to use:** Temperatures in kelvin.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into p₁/T₁ = p₂/T₂, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Temperatures in kelvin.

## Thermal physics · First law of thermodynamics
**Formula:** `ΔU = Q − W`
**Meaning:** Change in internal energy equals heat added minus work done by the system.
**Symbols:** W: work (J) or weight (N), depending on context; Q: heat energy (J) or charge (C), depending on context
**SI unit:** J
**When to use:** Sign convention stated here: W is work done by the system.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into ΔU = Q − W, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Sign convention stated here: W is work done by the system.

## Electricity · Electric current
**Formula:** `I = Q / t`
**Meaning:** Charge passing a point per unit time.
**Symbols:** t: time (s); Q: heat energy (J) or charge (C), depending on context; I: current (A) or intensity (W/m²), depending on context
**SI unit:** A
**When to use:** For changing current, this is average current.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into I = Q / t, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** For changing current, this is average current.

## Electricity · Potential difference
**Formula:** `V = W / Q`
**Meaning:** Work done per unit charge.
**Symbols:** W: work (J) or weight (N), depending on context; Q: heat energy (J) or charge (C), depending on context; V: potential difference (V) or volume (m³), depending on context
**SI unit:** V
**When to use:** Use this equation when the known quantities match the variables shown and the situation is potential difference.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into V = W / Q, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Check units, signs and direction. Make sure the physical conditions for this equation are satisfied.

## Electricity · Ohm's law
**Formula:** `V = IR`
**Meaning:** Potential difference across an ohmic conductor.
**Symbols:** V: potential difference (V) or volume (m³), depending on context
**SI unit:** V
**When to use:** At constant physical conditions.
**Worked example:** A 12 V supply is across 4 Ω. I=V/R=12/4=3 A.
**Common caution:** At constant physical conditions.

## Electricity · Resistance
**Formula:** `R = V / I`
**Meaning:** Ratio of voltage to current for an ohmic conductor.
**Symbols:** I: current (A) or intensity (W/m²), depending on context; V: potential difference (V) or volume (m³), depending on context; R: resistance (Ω) or range (m), depending on context
**SI unit:** Ω
**When to use:** Use this equation when the known quantities match the variables shown and the situation is resistance.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into R = V / I, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Check units, signs and direction. Make sure the physical conditions for this equation are satisfied.

## Electricity · Resistivity
**Formula:** `R = ρL / A`
**Meaning:** Resistance of a uniform wire.
**Symbols:** R: resistance (Ω) or range (m), depending on context; A: area (m²) or amplitude (m), depending on context; L: length (m) or latent heat (J/kg)
**SI unit:** Ω
**When to use:** ρ is resistivity, not density.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into R = ρL / A, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** ρ is resistivity, not density.

## Electricity · Series resistance
**Formula:** `R_total = R₁ + R₂ + …`
**Meaning:** Equivalent resistance in series.
**Symbols:** R: resistance (Ω) or range (m), depending on context
**SI unit:** Ω
**When to use:** Same current through each resistor.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into R_total = R₁ + R₂ + …, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Same current through each resistor.

## Electricity · Parallel resistance
**Formula:** `1/R_total = 1/R₁ + 1/R₂ + …`
**Meaning:** Equivalent resistance in parallel.
**Symbols:** R: resistance (Ω) or range (m), depending on context
**SI unit:** Ω
**When to use:** Same voltage across each branch.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into 1/R_total = 1/R₁ + 1/R₂ + …, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Same voltage across each branch.

## Electricity · Electric power
**Formula:** `P = VI = I²R = V²/R`
**Meaning:** Rate of electrical energy transfer.
**Symbols:** I: current (A) or intensity (W/m²), depending on context; V: potential difference (V) or volume (m³), depending on context; R: resistance (Ω) or range (m), depending on context; P: power (W) or pressure (Pa), depending on context
**SI unit:** W
**When to use:** Choose form using known quantities.
**Worked example:** A device uses 12 V and 2 A. P=VI=24 W.
**Common caution:** Choose form using known quantities.

## Electricity · Electrical energy
**Formula:** `E = Pt = VIt`
**Meaning:** Energy transferred by an electrical device.
**Symbols:** E: energy (J) or electric field (N/C), depending on context
**SI unit:** J or kWh
**When to use:** 1 kWh = 3.6 × 10⁶ J.
**Worked example:** A 100 W lamp runs for 60 s. E=Pt=6000 J.
**Common caution:** 1 kWh = 3.6 × 10⁶ J.

## Electricity · Coulomb's law
**Formula:** `F = k|q₁q₂| / r²`
**Meaning:** Electric force between two point charges.
**Symbols:** F: force (N); r: radius/separation (m); k: spring constant (N/m) or another constant, depending on context; q: electric charge (C)
**SI unit:** N
**When to use:** Like charges repel; unlike charges attract.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into F = k|q₁q₂| / r², calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Like charges repel; unlike charges attract.

## Electricity · Electric field strength
**Formula:** `E = F / q`
**Meaning:** Force per unit positive test charge.
**Symbols:** F: force (N); E: energy (J) or electric field (N/C), depending on context; q: electric charge (C)
**SI unit:** N/C
**When to use:** Use this equation when the known quantities match the variables shown and the situation is electric field strength.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into E = F / q, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Check units, signs and direction. Make sure the physical conditions for this equation are satisfied.

## Electricity · Uniform electric field
**Formula:** `E = V / d`
**Meaning:** Field strength between parallel plates (ideal uniform field).
**Symbols:** d: distance (m); V: potential difference (V) or volume (m³), depending on context; E: energy (J) or electric field (N/C), depending on context
**SI unit:** V/m
**When to use:** d is plate separation.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into E = V / d, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** d is plate separation.

## Electricity · Capacitance
**Formula:** `C = Q / V`
**Meaning:** Charge stored per unit potential difference.
**Symbols:** Q: heat energy (J) or charge (C), depending on context; V: potential difference (V) or volume (m³), depending on context; C: capacitance (F) or critical angle symbol
**SI unit:** F
**When to use:** Use this equation when the known quantities match the variables shown and the situation is capacitance.
**Worked example:** A capacitor stores 6 C at 3 V. C=Q/V=6/3=2 F.
**Common caution:** Check units, signs and direction. Make sure the physical conditions for this equation are satisfied.

## Electricity · Capacitor energy
**Formula:** `U = ½CV² = ½QV = Q²/(2C)`
**Meaning:** Energy stored in a capacitor.
**Symbols:** Q: heat energy (J) or charge (C), depending on context; C: capacitance (F) or critical angle symbol
**SI unit:** J
**When to use:** Use this equation when the known quantities match the variables shown and the situation is capacitor energy.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into U = ½CV² = ½QV = Q²/(2C), calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Check units, signs and direction. Make sure the physical conditions for this equation are satisfied.

## Electricity · Charge quantization
**Formula:** `Q = ne`
**Meaning:** Charge is an integer multiple of elementary charge.
**Symbols:** Q: heat energy (J) or charge (C), depending on context
**SI unit:** C
**When to use:** e = 1.602 × 10⁻¹⁹ C.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into Q = ne, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** e = 1.602 × 10⁻¹⁹ C.

## Magnetism & EM · Magnetic force on wire
**Formula:** `F = BIL sinθ`
**Meaning:** Force on a current-carrying conductor in a magnetic field.
**Symbols:** F: force (N)
**SI unit:** N
**When to use:** θ is angle between current and magnetic field.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into F = BIL sinθ, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** θ is angle between current and magnetic field.

## Magnetism & EM · Magnetic force on charge
**Formula:** `F = qvB sinθ`
**Meaning:** Magnetic force on a moving charge.
**Symbols:** F: force (N)
**SI unit:** N
**When to use:** Velocity perpendicular to field gives maximum force.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into F = qvB sinθ, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Velocity perpendicular to field gives maximum force.

## Magnetism & EM · Magnetic flux
**Formula:** `Φ = BA cosθ`
**Meaning:** Magnetic flux through a flat area in a uniform field.
**Symbols:** Φ: magnetic flux (Wb)
**SI unit:** Wb
**When to use:** θ is angle between field and area normal.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into Φ = BA cosθ, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** θ is angle between field and area normal.

## Magnetism & EM · Faraday's law
**Formula:** `ε = −N ΔΦ / Δt`
**Meaning:** Induced emf depends on rate of change of magnetic flux linkage.
**Symbols:** t: time (s); N: number of turns/particles; Φ: magnetic flux (Wb); ε: emf (V)
**SI unit:** V
**When to use:** Negative sign represents Lenz's law.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into ε = −N ΔΦ / Δt, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Negative sign represents Lenz's law.

## Magnetism & EM · Transformer ratio
**Formula:** `V_s/V_p = N_s/N_p`
**Meaning:** Ideal transformer voltage and turns ratio.
**Symbols:** s: displacement (m); p: momentum (kg·m/s) or pressure (Pa), depending on context; V: potential difference (V) or volume (m³), depending on context; N: number of turns/particles
**SI unit:** —
**When to use:** For an ideal transformer, input power ≈ output power.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into V_s/V_p = N_s/N_p, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** For an ideal transformer, input power ≈ output power.

## Magnetism & EM · Ideal transformer current ratio
**Formula:** `I_s/I_p = N_p/N_s`
**Meaning:** Ideal transformer current ratio.
**Symbols:** s: displacement (m); p: momentum (kg·m/s) or pressure (Pa), depending on context; I: current (A) or intensity (W/m²), depending on context; N: number of turns/particles
**SI unit:** —
**When to use:** Current ratio is inverse of turns ratio.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into I_s/I_p = N_p/N_s, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Current ratio is inverse of turns ratio.

## Magnetism & EM · Electromagnetic wave speed
**Formula:** `c = fλ`
**Meaning:** Speed, frequency and wavelength relation.
**Symbols:** f: frequency (Hz); c: specific heat capacity or speed of light, depending on context
**SI unit:** m/s
**When to use:** In vacuum c ≈ 3.00 × 10⁸ m/s.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into c = fλ, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** In vacuum c ≈ 3.00 × 10⁸ m/s.

## Optics · Refractive index
**Formula:** `n = c / v`
**Meaning:** Ratio of light speed in vacuum to speed in a medium.
**Symbols:** v: speed or velocity (m/s); c: specific heat capacity or speed of light, depending on context; n: amount (mol), refractive index, or integer number, depending on context
**SI unit:** —
**When to use:** Use this equation when the known quantities match the variables shown and the situation is refractive index.
**Worked example:** Light travels at 2.0×10⁸ m/s in glass. n=3.0×10⁸/2.0×10⁸=1.5.
**Common caution:** Check units, signs and direction. Make sure the physical conditions for this equation are satisfied.

## Optics · Snell's law
**Formula:** `n₁ sinθ₁ = n₂ sinθ₂`
**Meaning:** Refraction at a boundary.
**Symbols:** n: amount (mol), refractive index, or integer number, depending on context
**SI unit:** —
**When to use:** Angles are measured from the normal.
**Worked example:** n₁=1.0, θ₁=30°, n₂=1.5. sinθ₂=(1/1.5)×sin30°=1/3, so θ₂≈19.5°.
**Common caution:** Angles are measured from the normal.

## Optics · Critical angle
**Formula:** `sin C = n₂ / n₁`
**Meaning:** Critical angle when light travels from higher to lower refractive index.
**Symbols:** n: amount (mol), refractive index, or integer number, depending on context; C: capacitance (F) or critical angle symbol
**SI unit:** —
**When to use:** For n₁ > n₂.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into sin C = n₂ / n₁, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** For n₁ > n₂.

## Optics · Mirror/lens equation
**Formula:** `1/f = 1/u + 1/v`
**Meaning:** Thin lens or spherical mirror relation under the usual school sign convention.
**Symbols:** v: speed or velocity (m/s); u: initial velocity (m/s); f: frequency (Hz)
**SI unit:** m⁻¹
**When to use:** Check the sign convention used by your textbook.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into 1/f = 1/u + 1/v, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Check the sign convention used by your textbook.

## Optics · Magnification
**Formula:** `m = image height / object height = v/u`
**Meaning:** Image size ratio; sign depends on convention.
**Symbols:** v: speed or velocity (m/s); u: initial velocity (m/s); m: mass (kg)
**SI unit:** —
**When to use:** Use magnitudes if only size is requested.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into m = image height / object height = v/u, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Use magnitudes if only size is requested.

## Optics · Lens power
**Formula:** `P = 1/f`
**Meaning:** Converging/diverging lens power when f is in metres.
**Symbols:** P: power (W) or pressure (Pa), depending on context; f: frequency (Hz)
**SI unit:** dioptre (D)
**When to use:** Use this equation when the known quantities match the variables shown and the situation is lens power.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into P = 1/f, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Check units, signs and direction. Make sure the physical conditions for this equation are satisfied.

## Modern physics · Photon energy
**Formula:** `E = hf = hc/λ`
**Meaning:** Energy of a photon.
**Symbols:** E: energy (J) or electric field (N/C), depending on context; λ: wavelength (m) or decay constant (s⁻¹), depending on context
**SI unit:** J
**When to use:** h is Planck's constant.
**Worked example:** For f=6.0×10¹⁴ Hz, E=hf≈6.626×10⁻³⁴×6.0×10¹⁴=3.98×10⁻¹⁹ J.
**Common caution:** h is Planck's constant.

## Modern physics · Photoelectric equation
**Formula:** `hf = φ + K_max`
**Meaning:** Photon energy supplies work function and maximum electron kinetic energy.
**Symbols:** φ: phase angle or work function
**SI unit:** J
**When to use:** Use this equation when the known quantities match the variables shown and the situation is photoelectric equation.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into hf = φ + K_max, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Check units, signs and direction. Make sure the physical conditions for this equation are satisfied.

## Modern physics · Maximum kinetic energy
**Formula:** `K_max = eV_s`
**Meaning:** Maximum photoelectron kinetic energy from stopping potential.
**Symbols:** s: displacement (m)
**SI unit:** J
**When to use:** V_s is stopping potential magnitude.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into K_max = eV_s, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** V_s is stopping potential magnitude.

## Modern physics · de Broglie wavelength
**Formula:** `λ = h/p = h/(mv)`
**Meaning:** Matter-wave wavelength of a particle.
**Symbols:** p: momentum (kg·m/s) or pressure (Pa), depending on context; λ: wavelength (m) or decay constant (s⁻¹), depending on context; h: height (m) or Planck constant h (J·s)
**SI unit:** m
**When to use:** Non-relativistic form for p = mv.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into λ = h/p = h/(mv), calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Non-relativistic form for p = mv.

## Modern physics · Mass-energy equivalence
**Formula:** `E = mc²`
**Meaning:** Rest energy equivalent of mass.
**Symbols:** E: energy (J) or electric field (N/C), depending on context
**SI unit:** J
**When to use:** Use this equation when the known quantities match the variables shown and the situation is mass-energy equivalence.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into E = mc², calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Check units, signs and direction. Make sure the physical conditions for this equation are satisfied.

## Modern physics · Radioactive decay
**Formula:** `N = N₀e^(−λt)`
**Meaning:** Number of undecayed nuclei after time t.
**Symbols:** t: time (s); N: number of turns/particles; e: elementary charge (C)
**SI unit:** —
**When to use:** λ is decay constant.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into N = N₀e^(−λt), calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** λ is decay constant.

## Modern physics · Half-life
**Formula:** `T₁/₂ = 0.693 / λ`
**Meaning:** Time for half the radioactive nuclei to decay.
**Symbols:** T: period (s) or absolute temperature (K), depending on context; λ: wavelength (m) or decay constant (s⁻¹), depending on context
**SI unit:** s
**When to use:** Use consistent time units.
**Worked example:** If λ=0.231 min⁻¹, T½=0.693/0.231=3 min.
**Common caution:** Use consistent time units.

## Modern physics · Activity
**Formula:** `A = λN`
**Meaning:** Decays per second.
**Symbols:** A: area (m²) or amplitude (m), depending on context; N: number of turns/particles
**SI unit:** Bq
**When to use:** 1 becquerel = 1 decay per second.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into A = λN, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** 1 becquerel = 1 decay per second.

## Modern physics · Photon momentum
**Formula:** `p = h/λ`
**Meaning:** Momentum carried by a photon.
**Symbols:** p: momentum (kg·m/s) or pressure (Pa), depending on context; λ: wavelength (m) or decay constant (s⁻¹), depending on context; h: height (m) or Planck constant h (J·s)
**SI unit:** kg·m/s
**When to use:** Use this equation when the known quantities match the variables shown and the situation is photon momentum.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into p = h/λ, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Check units, signs and direction. Make sure the physical conditions for this equation are satisfied.

## Mathematics & units · Percentage error
**Formula:** `% error = (absolute error / measured value) × 100%`
**Meaning:** Relative size of an error as a percentage.
**Symbols:** Use the definitions given in your textbook for the symbols in this equation.
**SI unit:** %
**When to use:** Use the accepted value as denominator when calculating percentage error from a reference.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into % error = (absolute error / measured value) × 100%, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Use the accepted value as denominator when calculating percentage error from a reference.

## Mathematics & units · Gradient
**Formula:** `gradient = Δy / Δx`
**Meaning:** Slope of a straight-line graph.
**Symbols:** Use the definitions given in your textbook for the symbols in this equation.
**SI unit:** varies
**When to use:** Read axes and units carefully.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into gradient = Δy / Δx, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Read axes and units carefully.

## Mathematics & units · Pythagorean theorem
**Formula:** `c² = a² + b²`
**Meaning:** For a right-angled triangle.
**Symbols:** a: acceleration (m/s²); c: specific heat capacity or speed of light, depending on context
**SI unit:** —
**When to use:** c is the hypotenuse.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into c² = a² + b², calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** c is the hypotenuse.

## Mathematics & units · Vector resultant (perpendicular)
**Formula:** `R = √(A² + B²)`
**Meaning:** Magnitude of two perpendicular vectors.
**Symbols:** R: resistance (Ω) or range (m), depending on context; A: area (m²) or amplitude (m), depending on context; B: magnetic flux density (T)
**SI unit:** same as A and B
**When to use:** For non-perpendicular vectors, use components or cosine rule.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into R = √(A² + B²), calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** For non-perpendicular vectors, use components or cosine rule.

## Mathematics & units · Vector components
**Formula:** `Aₓ = A cosθ; Aᵧ = A sinθ`
**Meaning:** Resolve a vector at angle θ from positive x-axis.
**Symbols:** A: area (m²) or amplitude (m), depending on context
**SI unit:** same as A
**When to use:** Check which axis the angle is measured from.
**Worked example:** Worked method: identify the known values, convert them to SI units, substitute into Aₓ = A cosθ; Aᵧ = A sinθ, calculate, and write the correct unit. Check the conditions of the formula.
**Common caution:** Check which axis the angle is measured from.
