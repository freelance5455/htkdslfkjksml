BIHARI TADKA Android App - शुरुआती Android Studio प्रोजेक्ट

इस प्रोजेक्ट में मौजूदा BIHARI TADKA ऑर्डरिंग वेब इंटरफेस Android WebView में खुलता है।
मेन्यू, कार्ट और चेकआउट स्क्रीन शामिल हैं। डिलीवरी सेटिंग की अपेक्षा: Narengi Tiniali, Guwahati से 5 km और ₹30।

महत्वपूर्ण सीमाएँ:
1. यह अभी टेस्ट/प्रोटोटाइप ऐप है। ऑनलाइन पेमेंट अभी वास्तविक रूप से प्रोसेस नहीं होता।
2. ऑर्डर अपने-आप रेस्टोरेंट तक नहीं पहुँचते; इसके लिए सुरक्षित backend/API और order database चाहिए।
3. वास्तविक UPI/card भुगतान के लिए Razorpay जैसे भुगतान प्रदाता का merchant account, server-side order creation और payment verification जोड़ें। ऐप में केवल UPI विकल्प दिखाना असली payment integration नहीं है।
4. Google Play पर प्रकाशित करने से पहले privacy policy, Data safety form, app icon, screenshots, content rating, signed Android App Bundle (.aab), और Play Console account आवश्यक हैं। Play Console की वर्तमान फीस/आवश्यकताएँ Google पर जाँचें।
5. Google Play पर सीधे APK की बजाय सामान्यतः signed Android App Bundle (.aab) अपलोड किया जाता है।

Build करने के चरण:
1. Android Studio इंस्टॉल करें (developer.android.com/studio)।
2. Android Studio में इस पूरे BihariTadkaAndroid फोल्डर को Open करें।
3. Gradle sync पूरा होने दें। Android SDK 35 डाउनलोड करने को कहे तो स्वीकार करें।
4. टेस्ट के लिए Run दबाएँ।
5. Play Store के लिए Build > Generate Signed Bundle / APK > Android App Bundle चुनें।
6. अपना upload key सुरक्षित रखें; इसे किसी के साथ साझा न करें।
7. Google Play Console में ऐप बनाएँ, Store listing और Data safety पूरी करें, फिर AAB अपलोड करें।

डिलीवरी शुल्क और दूरी:
इस HTML प्रोटोटाइप में checkout अभी वास्तविक दूरी calculate नहीं करता और delivery charge को backend में enforce नहीं करता। लाइव करने से पहले backend में 5 km radius और ₹30 fee लागू करें; बाहर के पते अस्वीकार करें या अलग व्यवस्था दिखाएँ।
