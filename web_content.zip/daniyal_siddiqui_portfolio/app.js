import { initializeApp } from "https://www.gstatic.com/firebasejs/13.0.0/firebase-app.js";
import {
  getAuth, GoogleAuthProvider, signInWithPopup, createUserWithEmailAndPassword,
  signInWithEmailAndPassword, sendPasswordResetEmail, onAuthStateChanged, signOut
} from "https://www.gstatic.com/firebasejs/13.0.0/firebase-auth.js";

// Firebase web config is public client configuration. Protect data with Firebase rules
// and enable only the authentication providers you intend to support.
const firebaseConfig = {
  apiKey: "AIzaSyDGllYxQWm_3Szwmffzv6wE3UsZzIzYxGU",
  authDomain: "dipro-daniyal-assistant.firebaseapp.com",
  databaseURL: "https://dipro-daniyal-assistant-default-rtdb.firebaseio.com",
  projectId: "dipro-daniyal-assistant",
  storageBucket: "dipro-daniyal-assistant.firebasestorage.app",
  messagingSenderId: "954706207642",
  appId: "1:954706207642:web:f3ac65be05f5d30a2a1023",
  measurementId: "G-6Y7XDYL5BY"
};

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const toast = (message) => {
  const el = $("#toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove("show"), 3200);
};
$("#year").textContent = new Date().getFullYear();

let auth = null;
let authReady = false;
try {
  const app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  authReady = true;
  onAuthStateChanged(auth, user => {
    const signInButton = $("#openAuth");
    if (user) {
      signInButton.textContent = "Hi, " + ((user.displayName || user.email || "there").split(" ")[0].slice(0, 18));
      signInButton.title = "Click to sign out";
      signInButton.dataset.signedIn = "true";
    } else {
      signInButton.textContent = "Sign in";
      signInButton.title = "Sign in";
      signInButton.dataset.signedIn = "false";
    }
  });
} catch (error) {
  console.error("Firebase initialization failed:", error);
}

const authModal = $("#authModal");
let authMode = "signin";
function openAuth(mode = "signin") {
  setAuthMode(mode);
  authModal.hidden = false;
  document.body.style.overflow = "hidden";
  setTimeout(() => $("#authEmail").focus(), 50);
}
function closeModal(id) {
  $("#" + id).hidden = true;
  if ($("#authModal").hidden && $("#settingsModal").hidden) document.body.style.overflow = "";
}
function setAuthMode(mode) {
  authMode = mode;
  $$(".auth-tab").forEach(tab => tab.classList.toggle("selected", tab.dataset.mode === mode));
  $("#authTitle").textContent = mode === "signup" ? "Create your account." : "Good to see you.";
  $("#authSubmit").innerHTML = mode === "signup" ? "Create account <span>→</span>" : "Sign in <span>→</span>";
  $("#forgotPassword").style.display = mode === "signup" ? "none" : "block";
  $("#authPassword").autocomplete = mode === "signup" ? "new-password" : "current-password";
  $("#authMessage").textContent = "";
}
$("#openAuth").addEventListener("click", () => {
  if ($("#openAuth").dataset.signedIn === "true" && auth) {
    signOut(auth).then(() => toast("You have signed out.")).catch(showAuthError);
  } else openAuth("signin");
});
$("#openSignup").addEventListener("click", () => openAuth("signup"));
$("#contactSignIn").addEventListener("click", () => openAuth("signin"));
$$(".auth-tab").forEach(tab => tab.addEventListener("click", () => setAuthMode(tab.dataset.mode)));
$$("[data-close]").forEach(btn => btn.addEventListener("click", () => closeModal(btn.dataset.close)));
[authModal, $("#settingsModal")].forEach(modal => modal.addEventListener("click", e => {
  if (e.target === modal) closeModal(modal.id);
}));
document.addEventListener("keydown", e => { if (e.key === "Escape") { closeModal("authModal"); closeModal("settingsModal"); } });

function showAuthError(error) {
  const messages = {
    "auth/invalid-credential": "Email or password is incorrect.",
    "auth/email-already-in-use": "That email already has an account. Try signing in.",
    "auth/weak-password": "Choose a stronger password with at least 6 characters.",
    "auth/invalid-email": "Please enter a valid email address.",
    "auth/popup-closed-by-user": "The Google sign-in window was closed.",
    "auth/unauthorized-domain": "This website domain is not authorised in Firebase Console.",
    "auth/operation-not-allowed": "This sign-in method is not enabled in Firebase Console.",
    "auth/network-request-failed": "Network issue. Check your internet connection and try again.",
    "auth/too-many-requests": "Too many attempts. Please wait a while and try again."
  };
  $("#authMessage").textContent = messages[error?.code] || error?.message || "Something went wrong. Check Firebase setup and try again.";
}
$("#authForm").addEventListener("submit", async event => {
  event.preventDefault();
  const email = $("#authEmail").value.trim();
  const password = $("#authPassword").value;
  const button = $("#authSubmit");
  if (!authReady || !auth) { $("#authMessage").textContent = "Firebase could not start. Check your internet connection and configuration."; return; }
  button.disabled = true; button.textContent = authMode === "signup" ? "Creating account…" : "Signing in…";
  try {
    if (authMode === "signup") await createUserWithEmailAndPassword(auth, email, password);
    else await signInWithEmailAndPassword(auth, email, password);
    closeModal("authModal"); toast(authMode === "signup" ? "Account created successfully." : "You are signed in.");
    $("#authForm").reset();
  } catch (error) { showAuthError(error); }
  finally { button.disabled = false; button.innerHTML = authMode === "signup" ? "Create account <span>→</span>" : "Sign in <span>→</span>"; }
});
$("#googleSignIn").addEventListener("click", async () => {
  if (!authReady || !auth) { $("#authMessage").textContent = "Firebase could not start. Check your internet connection and configuration."; return; }
  const button = $("#googleSignIn"); button.disabled = true; button.textContent = "Opening Google sign-in…";
  try {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: "select_account" });
    await signInWithPopup(auth, provider);
    closeModal("authModal"); toast("Google sign-in successful.");
  } catch (error) { showAuthError(error); }
  finally { button.disabled = false; button.innerHTML = '<span class="google-g">G</span> Continue with Google'; }
});
$("#forgotPassword").addEventListener("click", async () => {
  const email = $("#authEmail").value.trim();
  if (!email) { $("#authMessage").textContent = "Enter your email address first."; return; }
  if (!auth) { $("#authMessage").textContent = "Firebase is not available right now."; return; }
  try { await sendPasswordResetEmail(auth, email); $("#authMessage").textContent = "If an account exists for that email, a reset email has been sent."; }
  catch (error) { showAuthError(error); }
});

// Settings are applied immediately and stored only in this browser.
const settingsModal = $("#settingsModal");
$("#openSettings").addEventListener("click", () => { settingsModal.hidden = false; document.body.style.overflow = "hidden"; });
$("#footerSettings").addEventListener("click", () => { settingsModal.hidden = false; document.body.style.overflow = "hidden"; });
$("#doneSettings").addEventListener("click", () => closeModal("settingsModal"));
function applyTheme(isDark) {
  document.body.classList.toggle("light", !isDark);
  $("#themeToggle").checked = isDark;
  try { localStorage.setItem("daniyal-theme", isDark ? "dark" : "light"); } catch {}
}
function applyMotion(reduced) {
  document.body.classList.toggle("reduce-motion", reduced);
  $("#motionToggle").checked = reduced;
  try { localStorage.setItem("daniyal-motion", reduced ? "reduce" : "normal"); } catch {}
}
function applyAccent(accent) {
  const map = {
    yellow: ["#ffe11a", "255,225,26"],
    pink: ["#ff3ca6", "255,60,166"],
    blue: ["#63a6ff", "99,166,255"]
  };
  const [color, rgb] = map[accent] || map.yellow;
  document.documentElement.style.setProperty("--accent", color);
  document.documentElement.style.setProperty("--accent-rgb", rgb);
  $$(".accent-choice").forEach(btn => btn.classList.toggle("chosen", btn.dataset.accent === accent));
  try { localStorage.setItem("daniyal-accent", accent); } catch {}
}
try {
  applyTheme(localStorage.getItem("daniyal-theme") !== "light");
  applyMotion(localStorage.getItem("daniyal-motion") === "reduce");
  applyAccent(localStorage.getItem("daniyal-accent") || "yellow");
} catch { applyTheme(true); applyMotion(false); applyAccent("yellow"); }
$("#themeToggle").addEventListener("change", e => applyTheme(e.target.checked));
$("#motionToggle").addEventListener("change", e => applyMotion(e.target.checked));
$$(".accent-choice").forEach(btn => btn.addEventListener("click", () => applyAccent(btn.dataset.accent)));

// Responsive navigation and active section state.
$("#menuToggle").addEventListener("click", () => {
  const open = $("#mainNav").classList.toggle("open");
  $("#menuToggle").setAttribute("aria-expanded", String(open));
});
$$(".nav-link").forEach(link => link.addEventListener("click", () => {
  $$(".nav-link").forEach(item => item.classList.remove("active"));
  link.classList.add("active");
  $("#mainNav").classList.remove("open");
  $("#menuToggle").setAttribute("aria-expanded", "false");
}));
