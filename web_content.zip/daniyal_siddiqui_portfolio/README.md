# Daniyal Siddiqui — Personal Portfolio

A responsive personal portfolio website built with HTML, CSS, vanilla JavaScript modules, and Firebase Authentication.

## Included features

- Responsive layout for mobile, tablet, and desktop
- About, interests, football favourites, and goals sections
- Sign in and account creation with email/password
- Google sign-in using Firebase Authentication
- Password reset email
- Settings panel: light/dark theme, reduce motion, and yellow/pink/blue accents
- Theme preferences saved in the current browser
- Accessible labels, status messages, and keyboard Escape handling
- No framework build step required

## Run locally

Firebase browser modules need to be served over HTTP(S), rather than opening `index.html` directly as a `file://` URL.

### Option A — Python

1. Install Python if needed.
2. Open a terminal in this folder.
3. Run:

   ```bash
   python -m http.server 8000
   ```

4. Open `http://localhost:8000` in your browser.

### Option B — VS Code

Install the Live Server extension, right-click `index.html`, and choose **Open with Live Server**.

## Firebase setup

This project is configured with the Firebase web app configuration supplied by the site owner. Firebase web configuration is not a server secret; secure your project with Firebase Console settings and security rules.

1. Open the Firebase Console for project `dipro-daniyal-assistant`.
2. Go to **Authentication → Get started → Sign-in method**.
3. Enable **Email/Password**.
4. Enable **Google** and select a support email if prompted.
5. Under **Authentication → Settings → Authorized domains**, add the domain where you will host the site. For local testing, add `localhost` if it is not already listed.
6. Serve the website over HTTPS when publishing.
7. Test sign-up, sign-in, Google sign-in, sign-out, and password reset.

The code uses the Firebase JavaScript SDK via browser ES modules from `gstatic.com`, so no npm install or bundler is required.

## Important security and privacy notes

- This project does not create a database or store portfolio profile data in Firebase.
- Do not put passwords, service-account credentials, or private server keys in browser code.
- If you later add a database, set strict Firebase Security Rules before deploying.
- Google sign-in can fail until Google provider and the current domain are configured in Firebase Console.
- As the portfolio owner is a minor, involve a parent or guardian before enabling public accounts or publishing personal information. Consider removing the birth date or limiting it to a private page before making the site public.
- Firebase Authentication availability depends on the project settings, authorised domain, browser support, and network access.

## Project files

- `index.html` — page structure and dialogs
- `styles.css` — responsive styling and themes
- `app.js` — Firebase Authentication and settings behaviour

## Deployment

Upload the three website files to a static host that supports HTTPS (for example Firebase Hosting, GitHub Pages, or Netlify). For Firebase Hosting, initialise Hosting in the Firebase CLI and set the public directory to this folder. Make sure the deployed hostname is listed in Firebase Authentication's authorised domains.

## Copyright

© Daniyal Siddiqui. All rights reserved. You may edit this project for your own personal website.
