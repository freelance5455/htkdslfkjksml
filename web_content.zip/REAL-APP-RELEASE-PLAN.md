# SOCIAL MEDIA — Real App Release Plan

## What is already real
- Firebase Authentication hooks are wired for email/password sign-up and login.
- Firebase UID is used as the account identity.
- User profiles are stored in Cloud Firestore.
- Local fake login is not used.
- The UI no longer fabricates thousands of rooms or fake listeners.

## What still needs a real backend before public launch
1. Firebase project configuration in `social-media/firebase-config.js`.
2. Firestore collections/rules for users, rooms, room members, messages, reports and moderation.
3. A real voice-media service (WebRTC SFU such as LiveKit/Agora/etc.) for reliable 10–15 person rooms. A browser-only mesh is not suitable as the production architecture for a public app.
4. Server-side/admin authorization for room hosts and moderators. Never trust a client-side `adminMode` flag.
5. Push notifications, abuse/report handling, blocking, account deletion, privacy policy and terms.
6. Android packaging as an Android App Bundle (AAB), signing, testing, and Play Console release.

## Firebase connection
Create a Firebase project, register a Web app, enable Authentication > Email/Password, and create Firestore. Then copy the Web App config into `firebase-config.js`. Firebase's official web setup and password-auth documentation are the source of truth.

## Admin panel
There is no secure admin panel in the current ZIP. Do not expose an `admin=true` client flag as authorization. The next implementation should use server-verified roles (for example a custom claim or a dedicated admin role document protected by backend rules) and a separate `/admin` interface.

## Android phone testing
This ZIP is a web project. It is not yet an APK/AAB. After Firebase + voice backend are connected, wrap/build the web app as an Android project, test on a real phone, then generate a signed AAB for Google Play.

## Google Play
As of August 31, 2026, new Google Play apps and updates must target Android 16 / API 36 or higher. Play Console uses Android App Bundles for delivery. Personal developer accounts created after November 13, 2023 have specific testing requirements before production availability.

## Important
The ZIP is a cleaned release-preparation build, not a claim that the voice network is already production-ready. The remaining backend/media work is required before real users can safely rely on live voice rooms.
