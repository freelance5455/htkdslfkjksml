// QR decorativo e NON scansionabile: solo per il mockup
function build(){
  let s=20260915;const r=()=>(s=(s*1664525+1013904223)>>>0)/4294967296;
  const N=29,fp=[[0,0],[N-7,0],[0,N-7]];let d='';
  for(let y=0;y<N;y++)for(let x=0;x<N;x++){
    let on=r()>.5;
    for(const [a,b] of fp){const dx=x-a,dy=y-b;if(dx>=-1&&dx<=7&&dy>=-1&&dy<=7){
      on=dx>=0&&dx<=6&&dy>=0&&dy<=6&&(dx==0||dx==6||dy==0||dy==6||(dx>=2&&dx<=4&&dy>=2&&dy<=4));}}
    if(on)d+='M'+x+' '+y+'h1v1h-1z';
  }
  return '<path d="'+d+'" fill="#000"/>';
}
// Il QR è l'immagine qr.png (stessa cartella). Se manca, usa il QR demo.
const fallback='data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 29 29" shape-rendering="crispEdges"><rect width="29" height="29" fill="#fff"/>'+build()+'</svg>');
const qrImg=document.getElementById('qr');
qrImg.onerror=()=>{qrImg.onerror=null;qrImg.src=fallback};

const ov=document.getElementById('ov');
document.getElementById('zoom').onclick=()=>{document.getElementById('qr2').src=qrImg.currentSrc||qrImg.src;ov.classList.add('on')};
ov.onclick=()=>ov.classList.remove('on');

const panel=document.getElementById('panel'),tg=document.getElementById('toggle');
tg.onclick=()=>{panel.classList.toggle('closed');tg.setAttribute('aria-expanded',!panel.classList.contains('closed'))};

const appHeader=document.getElementById('app-header');
const updateHeaderSticky=()=>appHeader.classList.toggle('is-hidden',window.scrollY>64);
window.addEventListener('scroll',updateHeaderSticky,{passive:true});
updateHeaderSticky();

document.getElementById('passenger-count').textContent=Math.floor(Math.random()*601)+100;

const p=n=>String(n).padStart(2,'0'),now=new Date();
const fmt=d=>p(d.getDate())+'/'+p(d.getMonth()+1)+'/'+d.getFullYear()+' - '+p(d.getHours())+':'+p(d.getMinutes())+':'+p(d.getSeconds());
document.getElementById('act').textContent=fmt(now);
document.getElementById('iss').textContent=fmt(now);

const total=90*60,cycles=3,cycleDuration=total/cycles,t0=Date.now(),clockStart=now.getHours()*3600+now.getMinutes()*60+now.getSeconds();function tick(){
  const el=Math.floor((Date.now()-t0)/1000);
  const c=clockStart+el;                       // l'orario sale
  document.getElementById('timer').textContent=p(Math.floor(c/3600)%24)+':'+p(Math.floor(c%3600/60))+':'+p(c%60);
  const fill=document.getElementById('fill');
  const cycle=Math.min(Math.floor(el/cycleDuration),cycles-1);
  const cycleElapsed=el>=total?cycleDuration:el%cycleDuration;
  fill.classList.toggle('orange',cycle===1);
  fill.style.width=((cycleDuration-cycleElapsed)/cycleDuration*100)+'%';
}
tick();
setInterval(tick,1000);
