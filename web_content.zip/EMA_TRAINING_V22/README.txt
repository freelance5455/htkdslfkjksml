E.M.A TRAINING v2.2 — Projet léger
====================================

Contenu :
- index.html : application en français
- assets/ema-logo.png : logo fourni, utilisé dans l'interface
- manifest.webmanifest et sw.js : prise en charge PWA hors ligne sur hébergement HTTPS

Fonctionnalités :
- Menu principal avec le logo MAMB'SKET
- Cours dribble, passe et tir avec schémas, conseils, erreurs à éviter, exercices et quiz
- Séances du samedi
- Groupes U8/U10/U12/U14, filles/garçons
- Présences et évaluations
- Calendrier des matchs/événements
- Vidéothèque locale : importer des vidéos autorisées depuis le téléphone, puis les lire hors ligne sur cet appareil

IMPORTANT :
Ce ZIP est le projet web/source reconstruit, pas un APK Android compilé.
Pour en faire une application installable, il faut l'importer dans un outil Android WebView/PWA puis générer et signer l'APK.
Pour le mode PWA avec cache hors ligne, héberger les fichiers sur un site HTTPS puis ouvrir le site avec Chrome et choisir « Installer l'application » / « Ajouter à l'écran d'accueil ».
Les vidéos ajoutées sont stockées dans le navigateur de l'appareil et ne sont pas intégrées au fichier APK.
Les vidéos YouTube ne sont pas téléchargées automatiquement. Ajoute uniquement des fichiers vidéo que tu possèdes ou as l'autorisation d'utiliser.
