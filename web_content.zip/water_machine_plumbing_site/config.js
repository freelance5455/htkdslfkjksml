// After deploying the Cloudflare Worker, set this to its exact API base URL. Leave blank for static-only operation.
window.WM_API_URL = '';
