WATER MACHINE PLUMBING AND SERVICES — COMPLETE UPDATE PACKAGE

INCLUDED
- Responsive website, logo, gallery and original provided photos (cropped/resized for display; source appearance preserved).
- Services: plumbing/repairs, leaks/drains, pumps, tanks, solar geysers, borehole and supply systems, bathroom/kitchen plumbing.
- Zimbabwe coverage with Bulawayo/Harare area lists and nationwide enquiries.
- Contact/WhatsApp/call: +263 714 188 181.
- Emergency request messaging: response target within 30 minutes only where location and availability allow.
- Local instant plumbing FAQ chatbot; owner/management handoff to WhatsApp; no external AI key needed.
- PWA install/offline shell (basic browser install support).
- Optional Cloudflare Worker + D1 activity feed for chat messages and visits.
- Admin page email allowlist label: watermachineplumbiningandservices@gmail.com.

IMPORTANT SECURITY
No password is embedded. The password shared in chat must be changed. Secure the owner dashboard AND Worker API using Cloudflare Access. Access email policy must allow ONLY watermachineplumbiningandservices@gmail.com. The Worker also checks the Cloudflare Access JWT, audience, issuer, expiry and email. Never publish admin page unprotected.

STATIC WEBSITE DEPLOY (QUICK)
1. Extract ZIP. Upload the folder contents (index.html, assets, style.css, chatbot.js, etc.) to Cloudflare Pages Direct Upload.
2. Static website/chatbot works without backend. Owner dashboard/API activity logging is disabled until backend is configured.
3. Cloudflare Pages Direct Upload is for static files. For Functions or a Worker, deploy the backend separately as described below.

ACTIVITY DASHBOARD BACKEND SETUP (REQUIRES CLOUDFLARE ACCOUNT)
1. Create a Cloudflare D1 database named e.g. water-machine-events. Run backend/schema.sql in its SQL console.
2. Deploy backend/worker.js as a Worker. Bind D1 as DB. Set Worker variables: ALLOWED_ORIGIN=https://YOUR-PAGES-DOMAIN.pages.dev; CF_ACCESS_TEAM_DOMAIN=YOURTEAM.cloudflareaccess.com (team domain only); CF_ACCESS_AUD=the Access application AUD tag.
3. Create Cloudflare Access application protecting the Worker API hostname/path and admin.html. Policy: Allow email equals watermachineplumbiningandservices@gmail.com; default deny.
4. Set up Access JWT validation: Worker requires CF-Access-Jwt-Assertion, checks audience, issuer and admin email. Use Access application AUD value in CF_ACCESS_AUD.
5. Configure API URL in admin.html dashboard (save locally in your browser). To log events, set window.WM_API_URL before chatbot script or save API URL on the admin dashboard; use your actual Worker URL. A website event logger is included; configure the API URL in config.js and redeploy.
6. In config.js on the public website, set window.WM_API_URL to the Worker API base URL (without a trailing slash), then redeploy the Pages site.
7. Protect Worker and admin page with Access; verify login from a non-allowed email is denied.

NOTIFICATIONS / DASHBOARD LIMITS
- Activity feed logs page visits and chatbot messages once API URL is configured. It does not currently send push notifications or email alerts.
- Phone pop-up/push alerts require push provider setup (VAPID keys, push subscription, service-worker push handler) and have not been enabled.
- Visitor IPs are not collected. Chat messages may contain personal information; inform visitors and limit retention/access.
- Social links open platform search pages because exact official profile URLs were not provided. Replace these with verified profile URLs when available.

CHATBOT
It is a deterministic local FAQ bot, not a live generative AI. It answers common service/plumbing questions and sends uncertain/owner enquiries to WhatsApp.

TEST BEFORE LAUNCH
- Test phone and WhatsApp buttons.
- Test all gallery images load.
- Test chat with leak, blocked drain, pump, tank, quote, areas, emergency, owner requests.
- Check responsive layout on mobile.
- If backend is enabled, test Access login and event feed; ensure unauthorized email is rejected.
