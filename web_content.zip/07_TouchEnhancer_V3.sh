#!/bin/bash
# TouchEnhancer V3.0
# Todos com 2>/dev/null || true
# (Original usa binário - aqui comandos de sistema de touch)

echo "Aplicando TouchEnhancer V3..."

settings put system pointer_speed 7 2>/dev/null || true
settings put secure long_press_timeout 130 2>/dev/null || true
settings put secure multi_press_timeout 100 2>/dev/null || true
settings put system touch_slop 2 2>/dev/null || true
settings put system view.touch_slop 1 2>/dev/null || true
setprop ro.min_pointer_dur 0 2>/dev/null || true
setprop windowsmgr.max_events_per_sec 300 2>/dev/null || true
setprop view.touch_slop 1 2>/dev/null || true
setprop ro.min.fling_velocity 160 2>/dev/null || true
setprop ro.max.fling_velocity 25000 2>/dev/null || true
setprop debug.input.enable_game_mode 1 2>/dev/null || true
setprop persist.vendor.touch.game_mode 1 2>/dev/null || true
setprop ro.vendor.touch_sensitivity 1 2>/dev/null || true
settings put global window_animation_scale 0 2>/dev/null || true
settings put global transition_animation_scale 0 2>/dev/null || true
settings put global animator_duration_scale 0 2>/dev/null || true

echo "TouchEnhancer V3 aplicado!"
echo "Nota: O original usa binário nativo. Este é a versão de comandos de sistema."
