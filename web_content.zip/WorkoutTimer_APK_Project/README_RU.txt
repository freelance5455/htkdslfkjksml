WORKOUT TIMER — Android-проект

Это готовый проект-обёртка для workout_timer_ticks.html.

Сборка на Android:
1. Открой папку проекта в AndroidIDE.
2. Дождись синхронизации Gradle.
3. Выбери Build -> Assemble Debug.
4. APK появится примерно в:
   app/build/outputs/apk/debug/app-debug.apk

В приложении HTML работает локально через Android WebView.
Экран не гаснет во время тренировки.
