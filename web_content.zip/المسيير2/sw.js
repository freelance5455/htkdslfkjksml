const CACHE_VERSION = "v1.0.0";
const STATIC_CACHE = `tasyir-static-${CACHE_VERSION}`;
const DYNAMIC_CACHE = `tasyir-dynamic-${CACHE_VERSION}`;

// قائمة الملفات الأساسية التي سيتم تخزينها مسبقاً للعمل أوفلاين
const ASSETS_TO_CACHE = [
  "./",
  "./index.html",
  "./manifest.json",
  "./css/style.css",
  "./js/app.js",
  "./icons/icon-192x192.png",
  "./icons/icon-512x512.png"
];

// 1. مرحلة التثبيت (Install): تخزين الملفات الأساسية وحذف أي أخطاء تمنع التثبيت
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) => {
      return Promise.allSettled(
        ASSETS_TO_CACHE.map((url) =>
          cache.add(url).catch((err) => {
            console.warn(`تعذر تخزين الملف مؤقتاً: ${url}`, err);
          })
        )
      );
    }).then(() => self.skipWaiting())
  );
});

// 2. مرحلة التفعيل (Activate): حذف الكاش القديم وتفعيل النسخة الجديدة فوراً
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== STATIC_CACHE && name !== DYNAMIC_CACHE)
          .map((name) => caches.delete(name))
      );
    }).then(() => self.clients.claim())
  );
});

// 3. اعتراض الطلبات (Fetch): استراتيجية Cache First للملفات، مع Fallback لصفحة index.html عند التنقل
self.addEventListener("fetch", (event) => {
  const { request } = event;

  // تجاهل الطلبات غير GET أو الطلبات الخارجية غير HTTP/HTTPS
  if (request.method !== "GET" || !request.url.startsWith("http")) {
    return;
  }

  // التعامل مع طلبات التنقل بين الصفحات (HTML Navigation)
  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then((networkResponse) => {
          const responseClone = networkResponse.clone();
          caches.open(DYNAMIC_CACHE).then((cache) => cache.put(request, responseClone));
          return networkResponse;
        })
        .catch(async () => {
          const cachedPage = await caches.match(request);
          return cachedPage || caches.match("./index.html");
        })
    );
    return;
  }

  // استراتيجية Cache First لبقية الملفات (CSS, JS, الصور، الخطوط)
  event.respondWith(
    caches.match(request).then((cachedResponse) => {
      if (cachedResponse) {
        return cachedResponse;
      }

      return fetch(request)
        .then((networkResponse) => {
          // تخزين الاستجابات الناجحة فقط من نفس النطاق أو المصادر الصالحة
          if (
            networkResponse &&
            networkResponse.status === 200 &&
            networkResponse.type !== "opaque"
          ) {
            const responseClone = networkResponse.clone();
            caches.open(DYNAMIC_CACHE).then((cache) => {
              cache.put(request, responseClone);
            });
          }
          return networkResponse;
        })
        .catch(() => {
          // في حال فشل الشبكة وعدم وجود الملف في الكاش
          return new Response("غير متصل بالإنترنت", {
            status: 503,
            statusText: "Service Unavailable",
            headers: { "Content-Type": "text/plain; charset=utf-8" }
          });
        });
    })
  );
});
