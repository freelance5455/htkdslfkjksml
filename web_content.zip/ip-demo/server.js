const express = require("express");
const app = express();

app.use(express.static("public"));

let lastVisit = null;

app.get("/visit", (req, res) => {
  const ip = (req.headers["x-forwarded-for"] || req.socket.remoteAddress || "")
    .split(",")[0].trim();

  lastVisit = {
    ip: ip.replace(/^::ffff:/, ""),
    time: new Date().toISOString()
  };

  res.send(`
    <!doctype html><meta charset="utf-8">
    <title>IP Demo</title>
    <h2>تم تسجيل عنوان IP لهذا الاختبار.</h2>
    <p>تم ذلك لأغراض تجريبية وبموافقة صاحب الجهاز.</p>
  `);
});

app.get("/my-panel", (req, res) => {
  res.json(lastVisit || {message: "لم يفتح أحد رابط الاختبار بعد."});
});

app.listen(process.env.PORT || 3000, () =>
  console.log("IP demo running")
);
