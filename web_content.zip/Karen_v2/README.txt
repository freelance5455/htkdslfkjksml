KAREN — VERSÃO 2

Use este ZIP no seu aplicativo HTML to APK.

Mudanças:
- Fundo claro, futurista e suave; removido o fundo azul/preto da versão anterior.
- Removida a bola branca.
- Personagem visual da Karen incluída em assets/karen.png.
- Animação suave da personagem e efeito de fala.
- Campo de texto e botão de envio.
- Microfone separado para transformar fala em texto quando o WebView oferecer Speech Recognition.
- Botão separado “Ouvir resposta” para a Karen ler a última resposta por voz.
- Voz em português do Brasil.
- Nome inicial Peter e possibilidade de trocar o apelido.
- Histórico automático no armazenamento local.

Observação:
O arquivo HTML não consegue, sozinho, garantir controle de outros aplicativos Android. A integração para abrir/controlar YouTube, Instagram etc. será feita em uma etapa nativa do Android.
