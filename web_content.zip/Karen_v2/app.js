const $=id=>document.getElementById(id);
let name=localStorage.getItem("karen_name")||"Peter";
let current=[],history=JSON.parse(localStorage.getItem("karen_history")||"[]");
let lastKaren="";

function save(){localStorage.setItem("karen_history",JSON.stringify(history))}
function add(text,who="karen"){
 const d=document.createElement("div");d.className="msg "+who;d.textContent=text;$('chat').appendChild(d);
 $('chat').scrollTop=$('chat').scrollHeight;current.push({text,who,at:Date.now()});
 if(who==="karen") lastKaren=text;
}
function persist(){if(!current.length)return;history.push({title:(current[0]?.text||"Conversa").slice(0,45),date:new Date().toLocaleString("pt-BR"),messages:current});save();current=[];}
function speak(text){
 if(!('speechSynthesis' in window)){alert('A leitura por voz não está disponível neste aparelho.');return}
 speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang='pt-BR';u.rate=.96;u.pitch=1.08;
 u.onstart=()=>{$('character').classList.add('speaking');$('listenState').textContent='Karen está falando...'};
 u.onend=()=>{$('character').classList.remove('speaking');$('listenState').textContent='Pronta para conversar'};
 speechSynthesis.speak(u);
}

// Banco local: combinações de respostas para evitar respostas repetidas.
const bank={
 greet:["Olá, {name}! Eu sou a Karen. Como posso ajudar?","Oi, {name}! Karen aqui. Pode mandar sua pergunta.","Olá, {name}! Estou pronta. O que vamos fazer hoje?","Oi! Que bom falar com você, {name}. Em que posso ajudar?","Olá novamente, {name}. Estou ouvindo.","Oi, {name}! Pode escrever ou falar comigo.","Olá! Karen na área, {name}. Qual é a missão?","Oi, {name}. Vamos resolver isso juntos?"],
 thanks:["Por nada, {name}!","Sempre à disposição, {name}.","De nada! Pode contar comigo.","Imagina, {name}. Vamos continuar.","É um prazer ajudar você."],
 identity:["Eu sou a Karen, sua assistente virtual. Posso conversar, explicar assuntos, organizar informações e ajudar a montar respostas.","Meu nome é Karen. Fui criada para conversar com você de forma natural e ajudar nas tarefas que você pedir.","Sou a Karen. Você pode falar comigo por voz ou texto, e eu tento entender o que você precisa."],
 how:["Claro. Me diga o objetivo e eu posso separar a resposta em passos.","Vamos por partes: diga o que você quer conseguir e eu organizo um passo a passo.","Consigo ajudar melhor se você me disser o resultado que quer. Aí eu monto as etapas."],
 compliment:["Obrigado, {name}! Fico feliz que você tenha gostado.","Que bom ouvir isso, {name}! Vamos deixar a Karen cada vez melhor.","Valeu, {name}! Pode continuar me dizendo o que você quer melhorar."],
 yes:["Sim, {name}.","Sim — vamos nessa.","Pode deixar. Entendi o que você quer.","Certo. Vou considerar isso na conversa."],
 no:["Não exatamente, {name}. Deixa eu explicar de outro jeito.","Ainda não. Mas podemos pensar em uma alternativa.","Não por enquanto. Se você quiser, posso sugerir outro caminho."],
 fallback:["Entendi, {name}. Vou organizar isso com você.","Certo, {name}. Vamos separar essa ideia em partes.","Entendi. Pode continuar explicando que eu acompanho o contexto.","Peguei a ideia, {name}. O que você quer fazer primeiro?","Certo. Vou levar em conta o que você acabou de dizer.","Entendi, {name}. Se houver vários pedidos, posso responder por tópicos."]
};
const pick=a=>a[Math.floor(Math.random()*a.length)].replaceAll('{name}',name);

function clean(s){return s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim()}
function numbered(topic,n=5){
 n=Math.max(1,Math.min(20,n));
 const ideas=[
  `Defina primeiro o objetivo de ${topic}.`,
  `Separe ${topic} em partes pequenas.`,
  `Pesquise ou confira as informações mais importantes sobre ${topic}.`,
  `Faça um teste simples antes de mudar tudo.`,
  `Anote o que funcionou e o que precisa melhorar.`,
  `Compare duas alternativas antes de escolher.`,
  `Comece pela opção mais simples de ${topic}.`,
  `Verifique os detalhes antes de concluir.`,
  `Se aparecer um erro, isole a causa e teste novamente.`,
  `Depois de testar, faça uma segunda melhoria.`
 ];
 return `Claro, {name}. Aqui estão ${n} itens sobre ${topic}:\n`+Array.from({length:n},(_,i)=>`${i+1}. ${ideas[i%ideas.length]}`).join('\n');
}
function calc(expr){
 const x=expr.replace(/[^0-9+\-*/().,% ]/g,'').replace(/,/g,'.');
 if(!/[0-9]/.test(x)||!/[+\-*/]/.test(x))return null;
 try{if(/[^0-9+\-*/().% ]/.test(x))return null; const v=Function('"use strict";return ('+x+')')(); return Number.isFinite(v)?`O resultado é ${v}.`:null}catch(e){return null}
}
function respond(raw){
 const t=raw.trim();if(!t)return;add(t,'user');
 const l=clean(t);let r;
 // Nome/apelido
 if(/^(me chama|me chame|meu nome e|pode me chamar)( de)?\b/.test(l)){
   const m=t.match(/(?:me chama|me chame|meu nome é|pode me chamar)(?: de)?\s+(.+)/i);
   if(m){name=m[1].replace(/[.!?]+$/,'').trim();localStorage.setItem('karen_name',name);r=`Perfeito, ${name}. A partir de agora vou chamar você assim.`} else r=`Claro, ${name}.`;
 }
 // Listas / pedidos de itens — aproxima o comportamento de uma IA conversacional.
 else if(/\b(\d+|dez|vinte|cinco|tres|três)\s+(itens|coisas|exemplos|opcoes|opções|dicas|passos|ideias)\b/.test(l)){
   const nm=l.match(/\b(\d+)\b/);const n=nm?parseInt(nm[1]):5;const topic=t.replace(/^.*?\b(itens|coisas|exemplos|opcoes|opções|dicas|passos|ideias)\b/i,'').replace(/^\s*(de|sobre|para)\s*/i,'').trim()||'o assunto que você pediu';r=numbered(topic,n);
 }
 // Matemática simples
 else if(/^\s*(quanto e|calcule|calcula|qual e o resultado de)\b/.test(l)){const expr=t.replace(/^.*?\b(de)\b/i,'');r=calc(expr)||'Consigo fazer contas simples. Tente escrever, por exemplo: "calcule 25*4".';}
 else if(/^(oi|ola|e ai|eai|hey|bom dia|boa tarde|boa noite)\b/.test(l)) r=pick(bank.greet);
 else if(/(quem e voce|se apresente|qual seu nome|voce e quem)/.test(l)) r=pick(bank.identity);
 else if(/(obrigad|valeu|tmj|brigad)/.test(l)) r=pick(bank.thanks);
 else if(/(como faco|como fazer|me ensina|passo a passo|me ajuda a fazer)/.test(l)) r=pick(bank.how);
 else if(/(voce e boa|ficou bom|muito bom|legal|top|bacana|gostei|parabens)/.test(l)) r=pick(bank.compliment);
 else if(/^(sim|s|isso|exato|correto|pode|beleza|blz)\b/.test(l)) r=pick(bank.yes);
 else if(/^(nao|n|negativo)\b/.test(l)) r=pick(bank.no);
 else if(/(o que e|que significa|explique|explica|me explique)/.test(l)){
   const topic=t.replace(/^(me )?(explique|explica|o que e|que significa)\s*/i,'').trim()||'isso';
   r=`{name}, ${topic} é um assunto que posso explicar. Para uma resposta mais útil, posso dividir em: definição, como funciona, exemplos e pontos importantes.`;
 } else if(/(resuma|resumir|resumo)/.test(l)) r=`{name}, eu posso resumir. Envie o texto ou diga qual assunto você quer resumir, e eu organizo os pontos principais.`;
 else if(/(compare|comparar|diferença entre|qual e melhor|qual é melhor)/.test(l)) r=`Posso comparar, {name}. Me diga as duas opções e eu separo em vantagens, desvantagens e qual faz mais sentido para cada situação.`;
 else r=pick(bank.fallback);
 setTimeout(()=>{r=r.replaceAll('{name}',name);add(r,'karen');$('hello').textContent=`Pronta para você, ${name}.`;},220);
}

$('sendBtn').onclick=()=>{const v=$('input').value;$('input').value='';respond(v)};
$('input').addEventListener('keydown',e=>{if(e.key==='Enter')$('sendBtn').click()});
$('speakLast').onclick=()=>lastKaren&&speak(lastKaren);

const SR=window.SpeechRecognition||window.webkitSpeechRecognition;let rec=null;
if(SR){
 rec=new SR();rec.lang='pt-BR';rec.interimResults=false;rec.continuous=false;
 rec.onstart=()=>{$('micBtn').classList.add('listening');$('status').textContent='Ouvindo você...';$('listenState').textContent='Estou ouvindo...'};
 rec.onend=()=>{$('micBtn').classList.remove('listening');$('status').textContent=`Online • pronta para você, ${name}`;if(!$('character').classList.contains('speaking'))$('listenState').textContent='Pronta para conversar'};
 rec.onerror=()=>{$('micBtn').classList.remove('listening');$('status').textContent='Não consegui ouvir • tente novamente'};
 rec.onresult=e=>{const text=e.results[0][0].transcript;$('input').value=text;respond(text);$('input').value=''};
}
$('micBtn').onclick=()=>{if(!rec){alert('O reconhecimento de voz não está disponível neste WebView. Para o APK funcionar com microfone de forma confiável, será necessária uma ponte nativa Android na próxima versão.');return}try{rec.start()}catch(e){}};

function renderHistory(){
 const box=$('historyList');box.innerHTML='';
 if(!history.length){box.innerHTML='<p style="color:#898498">Nenhuma conversa salva ainda.</p>';return}
 [...history].reverse().forEach(h=>{const d=document.createElement('div');d.className='history-item';d.innerHTML=`<b>${h.title}</b><br><small>${h.date}</small>`;d.onclick=()=>{$('chat').innerHTML='';(h.messages||[]).forEach(m=>add(m.text,m.who));$('drawer').classList.add('hidden')};box.appendChild(d)})
}
$('historyBtn').onclick=()=>{$('drawer').classList.remove('hidden');renderHistory()};
$('closeHistory').onclick=()=>$('drawer').classList.add('hidden');
$('newChat').onclick=()=>{persist();$('chat').innerHTML='';$('drawer').classList.add('hidden');add(`Olá, ${name}! Eu sou a Karen.`,'karen')};
add(`Olá, ${name}! Eu sou a Karen.`,'karen');
