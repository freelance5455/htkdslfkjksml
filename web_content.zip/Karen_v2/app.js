const $=id=>document.getElementById(id);
let name=localStorage.getItem("karen_name")||"Peter";
let current=[],history=JSON.parse(localStorage.getItem("karen_history")||"[]");
let lastKaren="";

function save(){localStorage.setItem("karen_history",JSON.stringify(history))}
function add(text,who="karen"){
 const d=document.createElement("div");d.className="msg "+who;d.textContent=text;$("chat").appendChild(d);
 $("chat").scrollTop=$("chat").scrollHeight;current.push({text,who,at:Date.now()});
 if(who==="karen") lastKaren=text;
}
function persist(){
 if(!current.length)return;
 history.push({title:(current[0]?.text||"Conversa").slice(0,45),date:new Date().toLocaleString("pt-BR"),messages:current});
 save();current=[];
}
function speak(text){
 if(!("speechSynthesis" in window)){alert("A leitura por voz não está disponível neste WebView.");return}
 speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang="pt-BR";u.rate=.96;u.pitch=1.08;
 u.onstart=()=>{$("character").classList.add("speaking");$("listenState").textContent="Karen está falando..."}
 u.onend=()=>{$("character").classList.remove("speaking");$("listenState").textContent="Pronta para conversar"}
 speechSynthesis.speak(u)
}
function respond(raw){
 const t=raw.trim();if(!t)return;add(t,"user");
 const l=t.toLowerCase();let r="";
 if(/(me chama|me chame|meu nome é|pode me chamar)/.test(l)){
   const m=t.match(/(?:me chama|me chame|meu nome é|pode me chamar)(?: de)?\s+(.+)/i);
   if(m){name=m[1].replace(/[.!?]+$/,"").trim();localStorage.setItem("karen_name",name);r=`Perfeito. A partir de agora vou chamar você de ${name}.`}
   else r=`Claro, ${name}.`;
 }else if(/^(oi|olá|ola|e aí|eai|hey)\b/.test(l)) r=`Olá, ${name}! Eu sou a Karen. Como posso ajudar você?`;
 else if(/(quem é você|se apresente|se apresentar)/.test(l)) r=`Eu sou a Karen, sua assistente pessoal. Você pode falar comigo pelo microfone ou escrever aqui.`;
 else if(/(obrigad|valeu)/.test(l)) r=`De nada, ${name}. Estou aqui.`;
 else r=`Entendi, ${name}. Essa é a primeira versão da Karen. A conexão com uma IA avançada e o controle de outros aplicativos, como YouTube e Instagram, serão adicionados na próxima etapa.`;
 setTimeout(()=>{add(r,"karen");$("hello").textContent=`Pronta para você, ${name}.`;},300);
}
$("sendBtn").onclick=()=>{const v=$("input").value;$("input").value="";respond(v)};
$("input").addEventListener("keydown",e=>{if(e.key==="Enter")$("sendBtn").click()});
$("speakLast").onclick=()=>lastKaren&&speak(lastKaren);

const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
let rec=null;
if(SR){
 rec=new SR();rec.lang="pt-BR";rec.interimResults=false;rec.continuous=false;
 rec.onstart=()=>{$("micBtn").classList.add("listening");$("status").textContent="Ouvindo você...";$("listenState").textContent="Estou ouvindo..."}
 rec.onend=()=>{$("micBtn").classList.remove("listening");$("status").textContent=`Online • pronta para você, ${name}`;if(!$("character").classList.contains("speaking"))$("listenState").textContent="Pronta para conversar"}
 rec.onerror=e=>{ $("micBtn").classList.remove("listening"); $("status").textContent="Não consegui ouvir • tente novamente"; }
 rec.onresult=e=>{const text=e.results[0][0].transcript;$("input").value=text;respond(text);$("input").value=""}
}
$("micBtn").onclick=()=>{
 if(!rec){alert("O reconhecimento de voz depende do suporte de voz do WebView. Se o botão não abrir o microfone no APK, a próxima versão poderá usar a ponte nativa do Android.");return}
 try{rec.start()}catch(e){}
};

function renderHistory(){
 const box=$("historyList");box.innerHTML="";
 if(!history.length){box.innerHTML='<p style="color:#898498">Nenhuma conversa salva ainda.</p>';return}
 [...history].reverse().forEach(h=>{
  const d=document.createElement("div");d.className="history-item";
  d.innerHTML=`<b>${h.title}</b><br><small>${h.date}</small>`;
  d.onclick=()=>{ $("chat").innerHTML=""; (h.messages||[]).forEach(m=>add(m.text,m.who));$("drawer").classList.add("hidden") };
  box.appendChild(d);
 })
}
$("historyBtn").onclick=()=>{$("drawer").classList.remove("hidden");renderHistory()};
$("closeHistory").onclick=()=>$("drawer").classList.add("hidden");
$("newChat").onclick=()=>{persist();$("chat").innerHTML="";$("drawer").classList.add("hidden");add(`Olá, ${name}! Eu sou a Karen.`,"karen")};
add(`Olá, ${name}! Eu sou a Karen.`,"karen");
