# Movie Player

## Option A: Install as an app (easiest, no Android Studio)
1. Upload the `www` folder to Netlify (app.netlify.com/drop), GitHub Pages or Vercel.
2. Open the https link in Chrome on Android -> menu -> "Install app".
   On a computer, click the install icon in the address bar.

## Option B: Build an APK (Android Studio)
Requires Node.js 18+ and Android Studio.
1. `npm install`
2. `npx cap add android`
3. `npm run android`   (syncs the www folder and opens Android Studio)
4. In Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
   For Play Store upload choose Build > Generate Signed Bundle (AAB).

## Option C: Build an APK without coding
Host the www folder (Option A), then paste the link into pwabuilder.com and pick Android.

Change the app id in capacitor.config.json (com.movieplayer.app) to your own before publishing.
