
const stages=[{name:'Rented Room',rent:2500,next:'Studio Apartment',cost:12000},{name:'Studio Apartment',rent:6000,next:'City Apartment',cost:85000},{name:'City Apartment',rent:12000,next:'Modern Condo',cost:350000},{name:'Modern Condo',rent:25000,next:'My First Home',cost:1500000},{name:'My First Home',rent:0,next:null,cost:0}];
const items=[{id:'bed',name:'Bed',emoji:'🛏️',cost:50,rate:1},{id:'fridge',name:'Mini Fridge',emoji:'🧊',cost:200,rate:3},{id:'stove',name:'Electric Stove',emoji:'🍳',cost:600,rate:8},{id:'shower',name:'Shower',emoji:'🚿',cost:1500,rate:20},{id:'chair',name:'Office Chair',emoji:'🪑',cost:3000,rate:35},{id:'plants',name:'Plants',emoji:'🪴',cost:6500,rate:70},{id:'sofa',name:'Sofa',emoji:'🛋️',cost:14000,rate:150},{id:'tv',name:'Television',emoji:'📺',cost:32000,rate:350}];
let s={money:0,stage:0,owned:[],skill:0,last:Date.now()};try{let old=JSON.parse(localStorage.getItem('kris-home-v2'));if(old&&typeof old.money==='number')s={...s,...old}}catch(e){}s.stage=Math.max(0,Math.min(4,s.stage));s.owned=Array.isArray(s.owned)?s.owned:[];const fmt=n=>'₱'+Math.floor(n).toLocaleString('en-US');const mult=()=>Math.pow(8,s.stage);const rate=()=>items.filter(x=>s.owned.includes(x.id)).reduce((a,x)=>a+x.rate*mult(),0);const tap=()=>1+s.skill*2;const skillCost=()=>Math.round(100*Math.pow(2.4,s.skill));const save=()=>{s.last=Date.now();try{localStorage.setItem('kris-home-v2',JSON.stringify(s))}catch(e){}};
// Animation and scene are visual only; existing economy and save schema remain unchanged.
const canvas=document.getElementById('scene'),ctx=canvas.getContext('2d');ctx.imageSmoothingEnabled=false;
const scene=document.getElementById('room');let kris={x:260,y:326,target:260,action:'idle',until:0,step:0,face:1,pending:null};let lastFrame=performance.now(),nextAction=performance.now()+2500;
const palettes=[['#9aadb0','#806b65','#6a5b58'],['#a8b6b7','#ac8975','#806b62'],['#a7c1d4','#a48977','#7b655b'],['#c9b9b3','#9b8d80','#71685f'],['#d4cdb5','#c6a47b','#967b58']];
function rect(x,y,w,h,c){ctx.fillStyle=c;ctx.fillRect(Math.round(x),Math.round(y),w,h)}
function outline(x,y,w,h,c='#273044'){rect(x-2,y-2,w+4,h+4,c)}
function furniture(id){return s.owned.includes(id)}
function line(x,y,w,h,c){rect(x,y,w,h,c)}
function tile(x,y,w,h,base,light,shade){rect(x,y,w,h,shade);rect(x+2,y+2,w-4,h-4,base);rect(x+3,y+3,w-6,2,light)}
const nightWindowSheet=new Image();nightWindowSheet.src='assets/sprites/furniture/window_night_sheet.png';
function windowArt(t){
 if(nightWindowSheet.complete&&nightWindowSheet.naturalWidth){
  const frame=Math.floor(t/220)%6;
  ctx.drawImage(nightWindowSheet,frame*140,0,140,122,103,9,125,103);
 }else{
  rect(111,19,103,83,'#614b75');rect(115,22,95,76,'#122648');
  rect(159,24,5,72,'#b78d70');rect(118,57,89,5,'#b78d70');
 }
}
const deskPixel=new Image();deskPixel.src='assets/sprites/furniture/desk_pixel.png';
function drawDesk(t){
 if(deskPixel.complete && deskPixel.naturalWidth){
  ctx.drawImage(deskPixel,0,0,438,435,8,98,108,106);
  const pulse=.10+.17*(.5+.5*Math.sin(t/420));
  ctx.fillStyle=`rgba(85,235,255,${pulse})`;ctx.fillRect(47,130,29,14);
  ctx.fillStyle=`rgba(190,250,255,${pulse*.6})`;ctx.fillRect(51,133,21,2);
 }else{rect(10,158,99,7,'#50344c');rect(13,151,96,8,'#b67b65');rect(18,163,6,37,'#704d56');rect(95,163,6,37,'#704d56');tile(30,109,58,40,'#384976','#77b8cc','#292c52')}
}
function drawBed(t){
 rect(126,168,91,41,'#6c4a6a');rect(130,163,83,35,'#8b647d');rect(134,166,77,31,'#d68ca9');rect(135,166,29,12,'#f4d5c5');
 rect(165,170,44,25,'#e6a2b7');for(let i=0;i<5;i++)rect(170+i*8,171,2,22,'#f2c0c1');rect(129,200,89,7,'#493751');
 rect(119,209,102,4,'#d9a8b4');rect(121,213,98,2,'#835f80');
}
const fridgeSheet=new Image();fridgeSheet.src='assets/sprites/furniture/fridge_sheet.png';
function drawFridge(t){
 const using=kris.action==='fridge' && !kris.pending;
 const frame=using ? Math.floor(t/170)%8 : 0;
 if(fridgeSheet.complete && fridgeSheet.naturalWidth===1520){
  ctx.drawImage(fridgeSheet,frame*190,0,190,232,455,149,109,183);
 }else{tile(455,149,109,183,'#c6d7dc','#f6eff1','#5d6685');}
}
const ovenSheet=new Image();ovenSheet.src='assets/sprites/furniture/oven_sheet.png';
function drawStove(t){
 if(ovenSheet.complete && ovenSheet.naturalWidth===288){
  const cooking=kris.action==='cook' || kris.pending==='cook';
  const frame=cooking ? 1+(Math.floor(t/240)%5) : 0;
  ctx.drawImage(ovenSheet,frame*48,0,48,64,277,145,48,64);
 } else {rect(279,145,37,54,'#777487');rect(284,166,27,24,'#34313f');}
}
const showerPixel=new Image();showerPixel.src='assets/sprites/furniture/shower_pixel.png';
function drawShower(t){
 if(showerPixel.complete && showerPixel.naturalWidth){
  ctx.drawImage(showerPixel,0,0,436,436,265,13,66,126);
  if(kris.action==='shower')for(let i=0;i<9;i++)rect(284+(i*11)%29,60+((t/16+i*13)%59),2,6,'#c5f4ff');
 }else{tile(275,19,39,109,'#85b5c6','#bde4e6','#536784')}
}
const chairSprite=new Image();chairSprite.src='assets/sprites/furniture/office_chair.png';
function drawChair(){
 if(chairSprite.complete&&chairSprite.naturalWidth){
  ctx.drawImage(chairSprite,94,151,39,48);
 }else{rect(109,157,7,30,'#49415c');rect(99,157,24,25,'#58567e');rect(101,162,20,16,'#79789e');rect(102,186,21,4,'#46445f');rect(112,190,3,7,'#45445c')}
}
const plantSwaySheet=new Image();plantSwaySheet.src='assets/sprites/furniture/plant_sway_sheet.png';
function drawPlant(x,y,t){
 if(plantSwaySheet.complete&&plantSwaySheet.naturalWidth){
  const frame=Math.floor(t/220)%6;
  ctx.drawImage(plantSwaySheet,frame*80,0,80,84,x-12,y-20,58,65);
 }else{rect(x+8,y+24,16,15,'#b46f66');rect(x+5,y+22,22,5,'#dc9a7e');rect(x+15,y+4,3,20,'#47794f')}
}
const sofaBackSheet=new Image();sofaBackSheet.src='assets/sprites/furniture/sofa_back_sheet.png';
const tvSheet=new Image();tvSheet.src='assets/sprites/furniture/tv_sheet.png';
function drawSofa(t){
 if(sofaBackSheet.complete&&sofaBackSheet.naturalWidth){
  const frame=Math.floor(t/250)%8;
  ctx.drawImage(sofaBackSheet,frame*150,0,150,102,108,132,125,90);
 }else{rect(120,179,98,24,'#4b4666');rect(123,167,92,31,'#6b97a1');rect(122,199,97,6,'#3c4562')}
}
function drawTV(t){
 if(tvSheet.complete&&tvSheet.naturalWidth){
  const frame=Math.floor(t/250)%8;
  ctx.drawImage(tvSheet,frame*94,0,94,84,210,48,76,69);
 }else{tile(222,69,49,36,'#3d678e','#83c4d2','#323750');rect(231,76,30,18,'#75b8bd')}
}
// Larger 640x360 room. All furniture is anchored to dedicated positions.
function place(draw,x,y,scale=1){ctx.save();ctx.translate(x,y);ctx.scale(scale,scale);draw();ctx.restore()}
// Room v1.5: larger kitchen appliances against the right wall; plants moved left.
const bedSleepSheet=new Image();bedSleepSheet.src='assets/sprites/furniture/bed_sleep_sheet.png';
const bedEmpty=new Image();bedEmpty.src='assets/sprites/furniture/bed_empty.png';
function drawVerticalBed(t){
 if(bedSleepSheet.complete&&bedSleepSheet.naturalWidth){
  let sleeping=kris.action==='sleep'&&!kris.pending;
  if(!sleeping && bedEmpty.complete && bedEmpty.naturalWidth){
   ctx.drawImage(bedEmpty,263,170,116,160);
  }else if(sleeping){
   let frame=Math.floor(t/220)%8;
   ctx.drawImage(bedSleepSheet,frame*116,0,116,160,263,170,116,160);
  }else{ctx.drawImage(bedSleepSheet,0,0,116,160,263,170,116,160);}
 }else{
  rect(263,170,116,160,'#63445d');rect(270,175,102,147,'#9d6889');
  rect(277,181,88,46,'#e6b1bf');rect(281,186,80,34,'#f9dbe0');
  rect(275,222,92,94,'#c87b9c');rect(280,227,82,80,'#e69fba');
 }
}
function drawSleepingKris(){/* Kris is included in the bed animation sprite. */}
// Layout coordinates are in the 640 x 360 canvas, saved separately per home.
const EDIT_KEY='kris-home-layout-v1';
const defaults={
 kris:{x:0,y:0,scale:1,width:1,height:1},
 desk:{x:26,y:0,scale:1},chair:{x:0,y:0,scale:1},
 bed:{x:0,y:0,scale:1},fridge:{x:0,y:0,scale:1},
 stove:{x:0,y:0,scale:1},plants:{x:0,y:0,scale:1},
 shower:{x:0,y:0,scale:1},tv:{x:0,y:0,scale:1},sofa:{x:0,y:0,scale:1},
 window:{x:0,y:0,scale:1}
};
let savedLayouts={};try{savedLayouts=JSON.parse(localStorage.getItem(EDIT_KEY))||{}}catch(e){}
let editMode=false,selected='desk',dragging=false,dragStart=null;
const editable=[
 ['kris','Kris (Character)',{x:196,y:203,w:128,h:134}],
 ['desk','Desk', {x:26,y:0,w:160,h:210}],
 ['chair','Office Chair',{x:120,y:275,w:50,h:75}],
 ['bed','Bed',{x:263,y:170,w:116,h:165}],
 ['fridge','Mini Fridge',{x:455,y:149,w:109,h:183}],
 ['stove','Electric Stove',{x:567,y:163,w:91,h:125}],
 ['plants','Plants',{x:65,y:65,w:85,h:80}],
 ['shower','Shower',{x:40,y:25,w:60,h:150}],
 ['tv','Television',{x:175,y:110,w:75,h:55}],
 ['sofa','Sofa',{x:70,y:240,w:100,h:75}],
 ['window','Window',{x:228,y:53,w:170,h:160}]
];
const boxes=Object.fromEntries(editable.map(([id,n,b])=>[id,b]));
function currentLayout(){let key=String(s.stage);if(!savedLayouts[key])savedLayouts[key]={};return savedLayouts[key]}
function layout(id){return {...defaults[id],...(currentLayout()[id]||{})}}
function storeLayout(){try{localStorage.setItem(EDIT_KEY,JSON.stringify(savedLayouts))}catch(e){}}
function adjustable(id,fn){let v=layout(id);ctx.save();ctx.translate(v.x,v.y);ctx.translate(boxes[id].x,boxes[id].y);ctx.scale(v.scale,v.scale);ctx.translate(-boxes[id].x,-boxes[id].y);fn();ctx.restore()}
function characterLayout(){return layout('kris')}
function getBox(id){
 let b=boxes[id],v=layout(id);
 if(id==='kris'){
  let w=128*v.scale*(v.width||1),h=134*v.scale*(v.height||1);
  return {x:kris.x+v.x-w/2,y:FLOOR_Y+v.y-h,w,h};
 }
 return {x:b.x+v.x,y:b.y+v.y,w:b.w*v.scale,h:b.h*v.scale};
}
function available(id){return ['desk','window','kris'].includes(id)||furniture(id)}
function refreshEditor(){
 document.getElementById('editPanel').hidden=!editMode;
 document.getElementById('editToggle').textContent=editMode?'Done Editing':'✏️ Edit Room';
 scene.classList.toggle('editing',editMode);
 if(!editMode)return;
 let picker=document.getElementById('editItem');
 picker.innerHTML=editable.filter(([id])=>available(id)).map(([id,name])=>`<option value="${id}">${name}</option>`).join('');
 if(!available(selected))selected='desk';picker.value=selected;
 let v=layout(selected);document.getElementById('editScale').value=Math.round(v.scale*100);
 document.getElementById('characterDimensions').hidden=selected!=='kris';
 if(selected==='kris'){
  document.getElementById('editWidth').value=Math.round((v.width||1)*100);
  document.getElementById('editHeight').value=Math.round((v.height||1)*100);
  document.getElementById('keepProportions').checked=!!v.locked;
  document.getElementById('widthValue').textContent=Math.round((v.width||1)*100)+'%';
  document.getElementById('heightValue').textContent=Math.round((v.height||1)*100)+'%';
 }
 document.getElementById('editSizeValue').textContent=Math.round(v.scale*100)+'%';
 document.getElementById('editCoords').textContent='X '+Math.round(v.x)+' · Y '+Math.round(v.y);
}
function paintScene(t){
 const walls=['#d7a6b3','#d7aeb6','#b3b8d1','#c7b8c9','#e1c8aa'];
 const floors=['#b98885','#c99a92','#a9a0ad','#b7a49b','#d6b595'];
 rect(0,0,640,360,walls[s.stage]);rect(0,0,640,15,'#655071');rect(0,17,640,4,'#e6c2b9');
 rect(0,225,640,135,floors[s.stage]);rect(0,220,640,7,'#71546b');
 for(let y=238;y<360;y+=30){rect(0,y,640,2,'#8e6d77');for(let x=(Math.floor(y/30)%2)*32;x<640;x+=64)rect(x,y,2,30,'#97777c')}
 // Window centered precisely above the head of the vertical bed.
 adjustable('window',()=>place(()=>windowArt(t),53,20,1.65));
 if(s.stage>0){rect(20,70,70,9,'#80566b');for(let i=0;i<5;i++)rect(28+i*12,43,8,27,['#8e5c75','#f3d1a8','#789c9b','#d1a4a4','#7a86b7'][i]);}
 if(furniture('shower'))adjustable('shower',()=>place(()=>drawShower(t),-240,0,1.3));
 if(furniture('tv'))adjustable('tv',()=>place(()=>drawTV(t),-50,40,1.15));
 // Desk is included from day one; chair is ONLY drawn after purchase.
 adjustable('desk',()=>place(()=>drawDesk(t),10,0,1.6));
 if(furniture('chair'))adjustable('chair',()=>place(()=>drawChair(),-38,24,1.6));
 if(furniture('bed'))adjustable('bed',()=>drawVerticalBed(t));
 if(furniture('sofa'))adjustable('sofa',()=>place(()=>drawSofa(t),-50,65,1.0));
 // Larger appliances flush against the back/right wall.
 if(furniture('fridge'))adjustable('fridge',()=>drawFridge(t));
 if(furniture('stove'))adjustable('stove',()=>place(()=>drawStove(t),27,-120,1.95));
 if(furniture('plants'))adjustable('plants',()=>{
  // Plants are placed on the left wall shelf, away from the cooking area.
  rect(65,111,83,7,'#795069');rect(69,118,6,9,'#5c4057');rect(137,118,6,9,'#5c4057');
  place(()=>drawPlant(0,0,t),86,57,1.35);drawPlant(8,180,t);
 });
 // Hide the walking character while actually asleep, draw in-bed instead.
 if(kris.action==='sleep' && !kris.pending && furniture('bed')){/* Bed animation already includes sleeping Kris. */}
 else paintKris(t);
 if(editMode){for(const [id] of editable){if(!available(id))continue;let b=getBox(id);ctx.strokeStyle=id===selected?'#ffe17c':'#d6e7ff88';ctx.lineWidth=id===selected?4:2;ctx.strokeRect(b.x,b.y,b.w,b.h);if(id===selected){ctx.fillStyle='#ffe17c';ctx.fillRect(b.x+b.w-7,b.y+b.h-7,14,14)}}}
 rect(0,350,640,3,'#886d80');
 for(let i=0;i<7;i++){let x=(i*97+Math.floor(t/1900)*7)%625+4,y=30+i*29;rect(x,y,2,2,'#fbe1bf66')}
}
// Main playable character from Character_Design_Kris-Idle (1).zip.
// Atlas: 6 columns, 3 rows, 80x80 transparent cells.
const krisAtlas=new Image();krisAtlas.src='assets/sprites/kris_main.png';
// Activity sprites from the user-supplied Kris cooking and sleeping packs.
const activitySprites={};
for(const [activity,folder] of Object.entries({cook:'cooking',sleep:'sleeping'})){
 activitySprites[activity]={};
 for(const facing of ['east','west']){
  const img=new Image();img.src=`assets/sprites/kris_activities/${folder}/${facing}.png`;
  activitySprites[activity][facing]=img;
 }
}

const FLOOR_Y=337;
const stations={work:140,sleep:321,cook:587,fridge:478,shower:62,sit:143,idle:390};
function stationX(action){let id=({work:'desk',sleep:'bed',cook:'stove',fridge:'fridge',shower:'shower',sit:'chair'})[action];if(!id)return stations[action]??175;let b=getBox(id);return Math.round(action==='sleep'?b.x+b.w*.5:action==='cook'?b.x+4:action==='fridge'?b.x-20:b.x+b.w*.55)}

function paintKris(t){
 const walking=Math.abs(kris.target-kris.x)>1.2;
 const row=walking?(kris.face<0?2:1):0;
 const frame=walking?Math.floor(t/115)%6:0;
 const v=characterLayout(),x=Math.round(kris.x+v.x),y=FLOOR_Y+v.y;
 ctx.save();ctx.translate(x,y);ctx.scale(v.scale*(v.width||1),v.scale*(v.height||1));ctx.translate(-x,-y);
 // When Kris reaches a station, show the matching real activity sprite.
 const activityImage=!walking && !kris.pending && activitySprites[kris.action]?.[kris.face<0?'west':'east'];
 if(activityImage?.complete && activityImage.naturalWidth>0){
  if(kris.action==='sleep' && furniture('bed')){
   ctx.restore();return;
  } else {
   const w=112,h=135;
   ctx.drawImage(activityImage,x-Math.round(w/2),y-h,w,h);
  }
  ctx.restore();return;
 }
 // Scale the 80px source art without cropping; foot position remains fixed.
 if(krisAtlas.complete && krisAtlas.naturalWidth===480){
  ctx.drawImage(krisAtlas,frame*80,row*80,80,80,x-64,y-134,128,134);
 } else {
  rect(x-9,y-39,18,22,'#30243d');rect(x-7,y-20,14,19,'#f2e7dc');
 }
 ctx.restore();
}
function setActivity(a){
 kris.action=a;
 document.getElementById('activity').textContent=({work:'Kris is at the laptop',sleep:'Kris is sleeping',cook:'Kris is cooking',fridge:'Kris is getting food',shower:'Kris is by the shower',sit:'Kris is by the chair',idle:'Kris is exploring'})[a]||'Kris is exploring';
}
function goTo(action,t){
 const x=stationX(action);
 kris.target=Math.max(48,Math.min(607,x));
 kris.pending=action;
 kris.until=t+2500;
 setActivity('idle');
}
function chooseAction(t){
 const choices=['work','idle'];
 if(furniture('bed'))choices.push('sleep');
 if(furniture('stove'))choices.push('cook');
 if(furniture('fridge'))choices.push('fridge');
 if(furniture('shower'))choices.push('shower');
 if(furniture('chair'))choices.push('sit');
 const action=choices[Math.floor(Math.random()*choices.length)];
 goTo(action,t);
}
function animate(t){
 const dt=Math.min(.06,Math.max(0,(t-lastFrame)/1000));lastFrame=t;
 if(!editMode && t>nextAction){chooseAction(t);nextAction=t+5000+Math.random()*2600;}
 const d=kris.target-kris.x;
 if(!editMode && Math.abs(d)>1.2){kris.x+=Math.sign(d)*Math.min(Math.abs(d),dt*65);kris.face=Math.sign(d);}
 else if(!editMode) {kris.x=kris.target;if(kris.pending){setActivity(kris.pending);kris.pending=null;}}
 kris.y=FLOOR_Y;
 paintScene(t);
 requestAnimationFrame(animate);
}
function fx(symbol,x,y,kind='pop'){let p=document.createElement('span');p.className=kind;p.textContent=symbol;p.style.left=(x/640*100)+'%';p.style.top=(y/360*100)+'%';scene.appendChild(p);setTimeout(()=>p.remove(),900)}
function purchaseFx(){scene.classList.remove('flash');void scene.offsetWidth;scene.classList.add('flash');for(let i=0;i<9;i++)fx(i%2?'✦':'✧',100+Math.random()*440,80+Math.random()*180,'spark')}
requestAnimationFrame(animate);
const offline=Math.min(8*3600,Math.max(0,(Date.now()-s.last)/1000));s.money+=offline*rate();function draw(){document.getElementById('cash').textContent=fmt(s.money);document.getElementById('rate').textContent=fmt(rate())+'/sec';document.getElementById('taprate').textContent=fmt(tap())+'/tap';document.getElementById('stageName').textContent=stages[s.stage].name+(s.stage<4?' · Rent ₱'+stages[s.stage].rent.toLocaleString()+'/month':' · Homeowner!');document.getElementById('room').dataset.stage=s.stage;document.getElementById('shop').innerHTML=items.map(x=>{let owned=s.owned.includes(x.id),cost=x.cost*mult();return `<div class="item"><span class="emoji">${x.emoji}</span><div class="info"><strong>${x.name}</strong><small>${owned?'Purchased · +'+fmt(x.rate*mult())+'/sec':'+'+fmt(x.rate*mult())+'/sec'}</small></div><button data-buy="${x.id}" data-owned="${owned}" ${owned||s.money<cost?'disabled':''}>${owned?'Owned':fmt(cost)}</button></div>`}).join('');document.querySelectorAll('[data-buy]').forEach(b=>b.onclick=()=>{let x=items.find(i=>i.id===b.dataset.buy);let cost=x.cost*mult();if(!s.owned.includes(x.id)&&s.money>=cost){s.money-=cost;s.owned.push(x.id);purchaseFx();nextAction=performance.now()+600;save();draw()}});let st=stages[s.stage],finished=s.stage===4;document.getElementById('nextDesc').textContent=finished?'Kris has finally bought her first home! Keep decorating and earning.':'Save enough money to move into a '+st.next.toLowerCase()+'. Furniture is purchased again at each new location.';document.getElementById('nextTitle').textContent=finished?'🎉 Dream achieved!':st.next;document.getElementById('nextCost').textContent=finished?'Your very own home':fmt(st.cost)+' moving / purchase goal';document.getElementById('progress').style.width=(finished?100:Math.min(100,s.money/st.cost*100))+'%';let b=document.getElementById('move');b.disabled=finished||s.money<st.cost;b.textContent=finished?'Homeowner!':'Move to '+st.next;document.getElementById('skillInfo').textContent='Level '+s.skill+' · '+fmt(tap())+' per tap';document.getElementById('skillBtn').textContent=fmt(skillCost());document.getElementById('skillBtn').disabled=s.money<skillCost()}
function earn(e){if(editMode)return;let bounds=scene.getBoundingClientRect();let x=(e.clientX-bounds.left)/bounds.width*640,y=(e.clientY-bounds.top)/bounds.height*360;if(x>190||y<185||y>285)return;s.money+=tap();fx('+'+fmt(tap()),105,195);goTo('work',performance.now());nextAction=performance.now()+2800;draw()}
function canvasPoint(e){let r=canvas.getBoundingClientRect();return {x:(e.clientX-r.left)/r.width*640,y:(e.clientY-r.top)/r.height*360}}
scene.addEventListener('pointerdown',e=>{
 if(!editMode){earn(e);return}
 let p=canvasPoint(e),hits=editable.filter(([id])=>available(id)).reverse();
 let found=(selected==='kris'?hits.filter(([id])=>id==='kris'):hits).find(([id])=>{let b=getBox(id);return p.x>=b.x&&p.x<=b.x+b.w&&p.y>=b.y&&p.y<=b.y+b.h});
 if(!found)found=hits.find(([id])=>{let b=getBox(id);return p.x>=b.x&&p.x<=b.x+b.w&&p.y>=b.y&&p.y<=b.y+b.h});
 if(found)selected=found[0];
 let v=layout(selected);dragStart={px:p.x,py:p.y,x:v.x,y:v.y};dragging=!!found;
 if(dragging)scene.setPointerCapture(e.pointerId);
 refreshEditor();
});
scene.addEventListener('pointermove',e=>{
 if(!editMode||!dragging)return;
 let p=canvasPoint(e),v=layout(selected);
 if(selected==='kris'){
  v.x=Math.round(Math.max(-kris.x+12,Math.min(628-kris.x,dragStart.x+p.x-dragStart.px)));
  v.y=Math.round(Math.max(-FLOOR_Y+35,Math.min(360-FLOOR_Y,dragStart.y+p.y-dragStart.py)));
 }else{
  v.x=Math.round(Math.max(-boxes[selected].x,Math.min(640-boxes[selected].x-boxes[selected].w*v.scale,dragStart.x+p.x-dragStart.px)));
  v.y=Math.round(Math.max(-boxes[selected].y,Math.min(360-boxes[selected].y-boxes[selected].h*v.scale,dragStart.y+p.y-dragStart.py)));
 }
 currentLayout()[selected]=v;refreshEditor();
});
function finishDrag(){if(dragging)storeLayout();dragging=false}
scene.addEventListener('pointerup',finishDrag);scene.addEventListener('pointercancel',finishDrag);
document.getElementById('editToggle').onclick=()=>{editMode=!editMode;dragging=false;refreshEditor();if(!editMode)storeLayout()};
document.getElementById('editItem').onchange=e=>{selected=e.target.value;refreshEditor()};
for(const [id,prop] of [['editWidth','width'],['editHeight','height']]){
 document.getElementById(id).oninput=e=>{
  let v=characterLayout(),value=Number(e.target.value)/100;
  v[prop]=value;
  if(document.getElementById('keepProportions').checked){v.width=value;v.height=value;}
  currentLayout().kris=v;storeLayout();refreshEditor();
 };
}
document.getElementById('keepProportions').onchange=e=>{
 let v=characterLayout();v.locked=e.target.checked;
 if(v.locked)v.height=v.width;
 currentLayout().kris=v;storeLayout();refreshEditor();
};
document.getElementById('editScale').oninput=e=>{currentLayout()[selected]={...layout(selected),scale:Number(e.target.value)/100};refreshEditor();storeLayout()};
document.querySelectorAll('[data-nudge]').forEach(b=>b.onclick=()=>{let [dx,dy]=b.dataset.nudge.split(',').map(Number),v=layout(selected);currentLayout()[selected]={...v,x:v.x+dx,y:v.y+dy};storeLayout();refreshEditor()});
document.getElementById('resetLayout').onclick=()=>{if(confirm('Reset furniture and Kris settings for this home?')){delete savedLayouts[String(s.stage)];storeLayout();refreshEditor()}};
scene.addEventListener('keydown',e=>{if(editMode){e.preventDefault();return}if(e.key==='Enter'||e.key===' '){e.preventDefault();s.money+=tap();fx('+'+fmt(tap()),105,195);draw()}});

document.getElementById('skillBtn').onclick=()=>{if(s.money>=skillCost()){s.money-=skillCost();s.skill++;purchaseFx();save();draw()}};document.getElementById('move').onclick=()=>{let st=stages[s.stage];if(s.stage<4&&s.money>=st.cost&&confirm('Move to '+st.next+'? Your furniture and passive income will reset.')){s.money-=st.cost;s.stage++;s.owned=[];kris.x=275;kris.y=FLOOR_Y;kris.target=275;kris.pending=null;setActivity("idle");purchaseFx();save();draw();refreshEditor()}};setInterval(()=>{s.money+=rate()/4;draw()},250);setInterval(save,5000);document.addEventListener('visibilitychange',()=>{if(document.hidden)save()});window.addEventListener('pagehide',save);draw();
