# Release Notes - INTRACO Feed Costing App

## Version 2.0 update
1. Added two 100 kg swine formulas from the supplied reference image.
2. Expanded farm summaries by enterprise.
3. Converted downloads to table-formatted PDF reports.
4. Added titles and relevant metadata to PDF files.
5. Removed prototype payment-data wording.
6. Removed old workbook/UGX footer wording.
7. Added INTRACO startup splash and company motto.
8. Applied professional blue/red/white visual theme.

## Developer acceptance tests
- Select Swine and confirm F31/F32 each total exactly 100 kg.
- Edit ingredient prices and verify cost/kg changes.
- Edit concentrate prices and verify cost/kg changes.
- Download a formula PDF and confirm a table is present.
- Download a farm summary PDF for all four enterprise tabs.
- Relaunch app and confirm the INTRACO splash appears.
- Install as PWA and verify icon/manifest.
