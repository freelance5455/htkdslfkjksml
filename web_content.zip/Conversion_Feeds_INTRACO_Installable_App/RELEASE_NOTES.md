# Release Notes - Conversion Feeds Ltd. | INTRACO Feed Costing App

## Update: 18 October 2026
1. Updated Intraco concentrate retail prices to match the Conversion Feeds price list effective 15 October 2026: Pre-Starter UGX 122,000; Layer 20% UGX 229,000; Layer 10% UGX 240,000; Layer 5% UGX 251,000; Broiler 35% UGX 225,000; Broiler Grower 5% UGX 245,000; Broiler Starter 5% UGX 255,000; Fatpig 30% UGX 236,000; Piglet Weaning 20% UGX 183,000; Piglet Starter 10% UGX 198,000; Milky Strucs UGX 155,000; Dairy 10% UGX 112,000; Fokkamel UGX 273,000.
2. Updated shared Broken Maize to UGX 1,500/kg and Maize Bran to UGX 1,000/kg. A one-time migration updates existing installations and preserves future edits.
3. Added a persistent Print tab in the app navigation. It prints the currently open section, including visible tables.
4. Upgraded Concentrate Brand Comparison PDF export to a comprehensive report with selected formulas from Intraco, Hendrix and Galldus/KLC, ingredient inclusions, current prices/kg, line costs, mix shares, batch totals, cost/kg and cost per 50 kg equivalent.

## Existing features retained
- Hendrix Layer 5%, 10%, 20% and Galldus/KLC Layer 5%, 10%, 20% and KBC 30/35 broiler formula references.
- Shared editable raw-material price book and concentrate price book.
- Layer Feeding & Performance Calculator using the supplied chart from 8 to 90 weeks.
- Farmer Guide, housing/equipment calculator, farm calculator, custom formulas and PDF reports.

## Notes
- Competitor concentrate prices use the supplied Tunga Nutrition retail price list and Kaffica central shop price list.
- Some competitor chart stage totals differ from the sum of listed inclusions. The app costs the actual sum of listed quantities rather than silently forcing the chart's printed total.
- A cost comparison alone does not establish nutritional equivalence. Confirm formula suitability with a qualified animal nutritionist before production use.
