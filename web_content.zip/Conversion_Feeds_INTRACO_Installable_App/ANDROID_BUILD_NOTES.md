# Android Build Notes

Use the contents of this folder as the updated web assets for the existing Android wrapper project.

## Required web assets
- index.html
- manifest.json
- sw.js
- conversion-feeds-intraco-logo.jpg
- icon-192.png
- icon-512.png
- poultry-illustration.svg
- assets/*

## Acceptance checks before release
1. Open Feed Costing > Swine and confirm formulas 31 and 32 are visible.
2. Confirm each swine formula has a 100 kg base batch and inclusion total of exactly 100 kg.
3. Change maize/bran/soya/concentrate prices and confirm cost/kg changes.
4. Farm Calculator: test all Layer/Broiler/Dairy/Swine summaries.
5. Test every Download PDF button. Confirm the generated file is PDF and uses a table layout with a title and relevant metadata.
6. Relaunch the app and confirm the INTRACO splash screen appears with: EXPERT ADVICE AND RESPONSIBLE SOLUTIONS.
7. Confirm old footer wording and the old prototype payment-data statement are absent.
8. Test offline after the first successful load.

## Google Play
Use the previously prepared Android Studio project, replace its web assets with this folder's updated assets, then create a signed APK for device testing and a signed AAB for Play Console submission.
