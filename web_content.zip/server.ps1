$port = 8080
$folder = Split-Path -Parent $MyInvocation.MyCommand.Path

# Get local IP
$localIp = "192.168.1.12"
try {
    $dnsIp = ([System.Net.Dns]::GetHostAddresses([System.Net.Dns]::GetHostName()) | Where-Object { 
        $_.AddressFamily -eq 'InterNetwork' -and $_.IPAddressToString -notlike '127.*' -and $_.IPAddressToString -notlike '169.254.*'
    } | Select-Object -First 1).IPAddressToString
    if ($dnsIp) { $localIp = $dnsIp }
} catch {}

Clear-Host
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "       JUZISOUND ETHNO PRO - KORG Pa600 SERVER            " -ForegroundColor Yellow
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "[1] Laptop: http://localhost:$($port)" -ForegroundColor Green
Write-Host "[2] Phone (Huawei): http://$($localIp):$($port)" -ForegroundColor Yellow
Write-Host ""
Write-Host "Server is ACTIVE! Waiting for connections..." -ForegroundColor White
Write-Host "==========================================================" -ForegroundColor Cyan

$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Any, $port)
$listener.Server.SetSocketOption([System.Net.Sockets.SocketOptionLevel]::Socket, [System.Net.Sockets.SocketOptionName]::ReuseAddress, $true)
$listener.Start()

while ($true) {
    try {
        $client = $listener.AcceptTcpClient()
        $client.ReceiveTimeout = 4000
        $client.SendTimeout = 4000

        $stream = $client.GetStream()
        $reader = [System.IO.StreamReader]::new($stream, [System.Text.Encoding]::UTF8)

        $requestLine = $reader.ReadLine()
        if (-not $requestLine) {
            $client.Close()
            continue
        }

        # Drain remaining headers
        while ($line = $reader.ReadLine()) {
            if ($line.Trim() -eq "") { break }
        }

        $parts = $requestLine.Split(" ")
        $url = if ($parts.Length -ge 2) { $parts[1] } else { "/" }
        if ($url -eq "/" -or $url -eq "") { $url = "/index.html" }
        $url = $url.Split("?")[0].TrimStart("/")

        $filePath = Join-Path $folder $url

        if (Test-Path $filePath -PathType Leaf) {
            $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
            $mime = switch ($ext) {
                ".html" { "text/html; charset=utf-8" }
                ".css"  { "text/css; charset=utf-8" }
                ".js"   { "application/javascript; charset=utf-8" }
                ".json" { "application/json; charset=utf-8" }
                ".png"  { "image/png" }
                ".svg"  { "image/svg+xml" }
                default { "application/octet-stream" }
            }

            $bytes = [System.IO.File]::ReadAllBytes($filePath)
            $header = "HTTP/1.1 200 OK`r`nContent-Type: $mime`r`nContent-Length: $($bytes.Length)`r`nAccess-Control-Allow-Origin: *`r`nConnection: close`r`n`r`n"
            $headerBytes = [System.Text.Encoding]::ASCII.GetBytes($header)

            $stream.Write($headerBytes, 0, $headerBytes.Length)
            $stream.Write($bytes, 0, $bytes.Length)
            $stream.Flush()
            Write-Host "[OK 200] $url" -ForegroundColor Green
        } else {
            $notFound = "HTTP/1.1 404 Not Found`r`nContent-Type: text/plain`r`nConnection: close`r`n`r`n404 Not Found"
            $notFoundBytes = [System.Text.Encoding]::ASCII.GetBytes($notFound)
            $stream.Write($notFoundBytes, 0, $notFoundBytes.Length)
            $stream.Flush()
            Write-Host "[404] $url" -ForegroundColor Red
        }

        $client.Close()
    } catch {
        # Catch socket aborts/disconnects without crashing the server!
        if ($client) {
            try { $client.Close() } catch {}
        }
    }
}
