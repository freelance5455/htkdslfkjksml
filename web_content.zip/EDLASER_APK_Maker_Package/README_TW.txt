EDLASER 手機報價管理 - HTML to APK 封裝素材

請將此 ZIP 上傳至支援 HTML/ZIP to APK 的建置工具。

APP 名稱：EDLASER 報價管理
入口檔案：index.html
用途：個人 Android 手機使用的本機報價管理原型。

重要限制：
1. 此包是網頁型 App 素材，不是已編譯 APK。
2. 報價資料儲存在 App WebView 的本機儲存區；清除 App 資料或解除安裝可能遺失，請定期匯出 JSON 備份。
3. JPG 匯出會從網路載入 html2canvas，因此需要網路連線。
4. 生成 APK 後請先測試新增/儲存報價、PDF 列印及資料備份功能。
