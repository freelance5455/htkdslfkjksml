School Saathi Offline Android Project

यह Android Studio project आपकी SchoolSaathi HTML फाइल को Android WebView ऐप में खोलता है।

APK बनाने के लिए:
1. Android Studio install करें (Android SDK सहित)।
2. इस ZIP को extract करें।
3. Android Studio में extracted SchoolSaathi_Offline_APK_Project folder खोलें।
4. Gradle sync पूरा होने दें और SDK Platform 35 install करने का prompt आए तो install करें।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. APK सामान्यतः app/build/outputs/apk/debug/app-debug.apk में बनेगा।

ध्यान दें:
- HTML में XLSX, PDF.js और Tesseract.js की कुछ libraries CDN से load होती हैं। इसलिए ऐप का मुख्य HTML स्थानीय रूप से खुलेगा, लेकिन इन libraries पर निर्भर import/OCR/PDF सुविधाओं को पहली बार या इंटरनेट के बिना इस्तेमाल करने में समस्या हो सकती है। पूरी तरह offline बनाने के लिए इन libraries को local assets में शामिल करना होगा।
- डेटा HTML के local storage में रहने पर ऐप data clear/uninstall करने से मिट सकता है। नियमित backup रखें।
- यह source project है; इस environment में Android SDK/Gradle उपलब्ध नहीं था, इसलिए compiled APK सीधे नहीं बन सका।
