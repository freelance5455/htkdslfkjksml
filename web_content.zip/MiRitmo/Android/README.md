# Mi Ritmo Android — proyecto inicial

Proyecto Android nativo en Kotlin + Jetpack Compose. Incluye una primera pantalla y lectura de pasos, energía total y frecuencia cardiaca desde Health Connect, con permisos solicitados al usuario.

## Requisitos
- Android Studio actualizado.
- JDK 17.
- Android SDK 35.
- Teléfono Android compatible y Health Connect instalado/actualizado cuando corresponda.

## Abrir
1. Descomprime `MiRitmoAndroid.zip`.
2. En Android Studio selecciona **Open** y elige la carpeta `MiRitmoAndroid`.
3. Espera a que Gradle sincronice.
4. Conecta el teléfono por USB con depuración USB habilitada, o usa la opción de ejecución inalámbrica de Android Studio.
5. Ejecuta la app y concede únicamente los permisos de salud que quieras compartir.

## Estado de las integraciones
- Health Connect: base inicial de permisos y lectura de pasos, calorías y pulso de las últimas 24 horas.
- Samsung Health: puede aportar datos a través de Health Connect si la app Samsung Health los comparte y el usuario autoriza esos tipos de datos. La integración directa con Samsung Health Data SDK requiere descargar el SDK oficial, usar su archivo AAR y cumplir su proceso de registro/desarrollo.
- Mi Fitness: se leerán datos si la versión/región de Mi Fitness los escribe en Health Connect.
- Bluetooth directo: pendiente de conocer el modelo exacto del reloj/banda. Los accesorios usan perfiles y protocolos distintos; no se puede prometer compatibilidad universal.

## Importante
Este proyecto es una base de desarrollo, no un APK ya compilado ni una app médica. La lectura depende de los permisos, los datos que existan y la compatibilidad del proveedor. Revisa y prueba el proyecto en un teléfono real.
