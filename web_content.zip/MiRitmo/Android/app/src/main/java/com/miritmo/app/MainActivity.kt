package com.miritmo.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.TotalCaloriesBurnedRecord
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Instant
import java.time.temporal.ChronoUnit

private val Purple = Color(0xFFB52CFF)
private val Deep = Color(0xFF080414)
private val Card = Color(0xFF170A35)
private val Muted = Color(0xFFC5B3E8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MiRitmoApp() }
    }
}

@Composable
fun MiRitmoApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val client = remember { HealthConnectClient.getOrCreate(context) }
    val scope = rememberCoroutineScope()
    val permissions = remember {
        setOf(
            HealthPermission.getReadPermission(HeartRateRecord::class),
            HealthPermission.getReadPermission(StepsRecord::class),
            HealthPermission.getReadPermission(TotalCaloriesBurnedRecord::class)
        )
    }

    var granted by remember { mutableStateOf(false) }
    var steps by remember { mutableStateOf("--") }
    var calories by remember { mutableStateOf("--") }
    var heart by remember { mutableStateOf("--") }
    var info by remember { mutableStateOf("Aún no hay datos sincronizados.") }
    var busy by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { result ->
        granted = result.containsAll(permissions)
        if (granted) info = "Permisos concedidos. Pulsa «Actualizar datos»."
        else info = "No se concedieron todos los permisos. Puedes cambiarlos después en Health Connect."
    }

    suspend fun refreshData() {
        busy = true
        try {
            val now = Instant.now()
            val start = now.minus(1, ChronoUnit.DAYS)
            val stepResult = client.aggregate(
                androidx.health.connect.client.request.AggregateRequest(
                    metrics = setOf(StepsRecord.COUNT_TOTAL),
                    timeRangeFilter = TimeRangeFilter.between(start, now)
                )
            )
            val calorieResult = client.aggregate(
                androidx.health.connect.client.request.AggregateRequest(
                    metrics = setOf(TotalCaloriesBurnedRecord.ENERGY_TOTAL),
                    timeRangeFilter = TimeRangeFilter.between(start, now)
                )
            )
            val heartRecords = client.readRecords(
                ReadRecordsRequest(
                    recordType = HeartRateRecord::class,
                    timeRangeFilter = TimeRangeFilter.between(start, now),
                    ascendingOrder = false,
                    pageSize = 100
                )
            )
            steps = stepResult[StepsRecord.COUNT_TOTAL]?.toString() ?: "0"
            calories = calorieResult[TotalCaloriesBurnedRecord.ENERGY_TOTAL]
                ?.inKilocalories?.toInt()?.toString() ?: "0"
            val latestSample = heartRecords.records.firstOrNull()?.samples?.lastOrNull()
            heart = latestSample?.beatsPerMinute?.toString() ?: "—"
            info = "Datos consultados desde Health Connect en las últimas 24 horas."
        } catch (e: Exception) {
            info = "No se pudieron leer los datos: ${e.localizedMessage ?: "error desconocido"}"
        } finally {
            busy = false
        }
    }

    LaunchedEffect(Unit) {
        try { granted = client.permissionController.getGrantedPermissions().containsAll(permissions) }
        catch (_: Exception) { info = "Health Connect no está disponible en este teléfono." }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple,
        background = Deep,
        surface = Card,
        onBackground = Color.White,
        onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF180637), Deep, Color.Black)))
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("💜 Mi Ritmo", fontSize = 31.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text("Tu actividad, en un solo lugar", color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("●", color = if (granted) Color(0xFF20E88A) else Color(0xFFFFC04D))
                Text(if (granted) "Health Connect autorizado" else "Esperando autorización", color = Muted)
            }
            MetricCard("♥  Tu ritmo cardíaco", heart, "LPM", "Último dato disponible")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.weight(1f)) { MetricCard("👟 Pasos", steps, "pasos", "Últimas 24 h") }
                Box(Modifier.weight(1f)) { MetricCard("🔥 Energía", calories, "kcal", "Últimas 24 h") }
            }
            Button(
                onClick = { permissionLauncher.launch(permissions) },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7020B9))
            ) { Text("Conectar Health Connect") }

            Button(
                onClick = { scope.launch { refreshData() } },
                enabled = granted && !busy,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF351064))
            ) { Text(if (busy) "Consultando…" else "Actualizar datos") }

            Text(info, color = Muted, fontSize = 13.sp)
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF21113D)),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Conexiones", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("• Samsung Health: se puede integrar mediante Health Connect cuando comparta los tipos de datos autorizados.", color = Muted)
                    Text("• Mi Fitness: aparecerán los datos que Mi Fitness exporte a Health Connect en tu región y versión.", color = Muted)
                    Text("• Bluetooth: la conexión directa depende del modelo de reloj o banda y de su protocolo. Aún falta configurar el dispositivo exacto.", color = Muted)
                }
            }
            Text("Mi Ritmo es una herramienta de bienestar, no un dispositivo médico. Los datos dependen de las aplicaciones y sensores conectados.", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, unit: String, detail: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Card),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(title, color = Color(0xFFE4C8FF), fontWeight = FontWeight.SemiBold)
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(value, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                Text(unit, color = Purple, modifier = Modifier.padding(bottom = 5.dp))
            }
            Text(detail, color = Muted, fontSize = 12.sp)
        }
    }
}
