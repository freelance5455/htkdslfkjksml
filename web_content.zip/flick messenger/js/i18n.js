/* Orbita i18n: Russian, Ukrainian, English. Dictionaries live in lang-*.js */
(function () {
  'use strict';
  var O = window.Orbita;

  var LANGS = ['ru', 'uk', 'en'];
  var LOCALES = { ru: 'ru-RU', uk: 'uk-UA', en: 'en-US' };
  var dict = { ru: {}, uk: {}, en: {} };
  var lang = 'ru';

  function detect() {
    var nav = (navigator.languages && navigator.languages[0]) || navigator.language || 'ru';
    nav = String(nav).toLowerCase();
    if (nav.indexOf('uk') === 0) {
      return 'uk';
    }
    if (nav.indexOf('en') === 0) {
      return 'en';
    }
    return 'ru';
  }

  function valid(value) {
    return LANGS.indexOf(value) >= 0;
  }

  function lookup(key) {
    var table = dict[lang];
    if (table && Object.prototype.hasOwnProperty.call(table, key)) {
      return table[key];
    }
    if (Object.prototype.hasOwnProperty.call(dict.en, key)) {
      return dict.en[key];
    }
    return key;
  }

  function fill(text, vars) {
    if (!vars) {
      return text;
    }
    return text.replace(/\{(\w+)\}/g, function (match, name) {
      return Object.prototype.hasOwnProperty.call(vars, name) ? String(vars[name]) : match;
    });
  }

  function pluralIndex(n) {
    var abs = Math.abs(n);
    if (lang === 'en') {
      return abs === 1 ? 0 : 1;
    }
    var m10 = abs % 10;
    var m100 = abs % 100;
    if (m10 === 1 && m100 !== 11) {
      return 0;
    }
    if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) {
      return 1;
    }
    return 2;
  }

  O.t = function (key, vars) {
    return fill(String(lookup(key)), vars);
  };

  /* O.plural('h.count', 5) where the entry is "one|few|many" (ru, uk) or "one|other" (en) */
  O.plural = function (key, n, vars) {
    var forms = String(lookup(key)).split('|');
    var idx = Math.min(pluralIndex(n), forms.length - 1);
    var all = { n: n };
    if (vars) {
      Object.keys(vars).forEach(function (k) {
        all[k] = vars[k];
      });
    }
    return fill(forms[idx], all);
  };

  O.i18n = {
    langs: LANGS,
    names: { ru: 'Русский', uk: 'Українська', en: 'English' },
    short: { ru: 'RU', uk: 'UA', en: 'EN' },
    add: function (code, entries) {
      Object.keys(entries).forEach(function (key) {
        dict[code][key] = entries[key];
      });
    },
    keys: function (code) {
      return Object.keys(dict[code] || {});
    },
    current: function () {
      return lang;
    },
    detect: detect,
    set: function (code) {
      if (valid(code)) {
        O.settings.set('lang', code);
      }
    },
    apply: function (root) {
      var scope = root || document;
      O.$$('[data-i18n]', scope).forEach(function (node) {
        node.textContent = O.t(node.getAttribute('data-i18n'));
      });
      O.$$('[data-i18n-title]', scope).forEach(function (node) {
        var text = O.t(node.getAttribute('data-i18n-title'));
        node.setAttribute('title', text);
        node.setAttribute('aria-label', text);
      });
      O.$$('[data-i18n-placeholder]', scope).forEach(function (node) {
        node.setAttribute('placeholder', O.t(node.getAttribute('data-i18n-placeholder')));
      });
    }
  };

  /* ---------- locale aware formatting ---------- */
  O.fmt = {
    locale: function () {
      return LOCALES[lang];
    },
    time: function (ts) {
      return new Date(ts).toLocaleTimeString(LOCALES[lang], { hour: '2-digit', minute: '2-digit' });
    },
    date: function (ts, options) {
      return new Date(ts).toLocaleDateString(LOCALES[lang], options || { day: 'numeric', month: 'long' });
    },
    dayKey: function (ts) {
      var d = new Date(ts);
      return d.getFullYear() + '-' + O.pad2(d.getMonth() + 1) + '-' + O.pad2(d.getDate());
    },
    dayLabel: function (ts) {
      var now = new Date();
      var key = O.fmt.dayKey(ts);
      if (key === O.fmt.dayKey(now.getTime())) {
        return O.t('h.today');
      }
      var yesterday = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
      if (key === O.fmt.dayKey(yesterday.getTime())) {
        return O.t('h.yesterday');
      }
      return O.fmt.date(ts, { weekday: 'long', day: 'numeric', month: 'long' });
    },
    number: function (n, digits) {
      return new Intl.NumberFormat(LOCALES[lang], { maximumFractionDigits: digits === undefined ? 2 : digits }).format(n);
    }
  };

  function sync() {
    var wanted = O.settings.get('lang');
    var next = valid(wanted) ? wanted : detect();
    var changed = next !== lang;
    lang = next;
    document.documentElement.setAttribute('lang', lang);
    if (changed) {
      O.i18n.apply(document);
      O.emit('lang', lang);
    }
  }

  lang = valid(O.settings.get('lang')) ? O.settings.get('lang') : detect();
  document.documentElement.setAttribute('lang', lang);

  O.on('settings:lang', sync);
  O.on('settings', function (change) {
    if (change.key === '*') {
      sync();
    }
  });
})();
