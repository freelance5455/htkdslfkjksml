/* Orbita wallpaper: gradient presets or your own picture behind the page (stored only in this browser) */
(function () {
  'use strict';
  var O = window.Orbita;
  var t = O.t;

  var PRESETS = [
    { id: 'dusk', a: '#3a2c8f', b: '#d4497a', c: '#ff9a62', angle: 160 },
    { id: 'ocean', a: '#032b4f', b: '#0a7ea4', c: '#5fd4c4', angle: 150 },
    { id: 'forest', a: '#0b2a1f', b: '#1f6b4a', c: '#a6d96a', angle: 165 },
    { id: 'ember', a: '#2a0c0c', b: '#b3261e', c: '#ffb347', angle: 155 },
    { id: 'violet', a: '#1a1040', b: '#6a3df0', c: '#e08cff', angle: 145 },
    { id: 'mint', a: '#0d3b3b', b: '#2fb5a0', c: '#e5ffd1', angle: 170 },
    { id: 'steel', a: '#10131c', b: '#2f3b55', c: '#8fa3c7', angle: 160 },
    { id: 'sand', a: '#5a3e2b', b: '#c98f5d', c: '#fbe3b8', angle: 150 }
  ];
  var MAX_SIDE = 1600;

  var wallEl = null;

  function defaults() {
    return { kind: 'preset', id: 'dusk', data: '', dim: 35, blur: 0 };
  }

  function read() {
    var saved = O.store.get('wallpaper', null);
    var base = defaults();
    if (saved && typeof saved === 'object') {
      Object.keys(base).forEach(function (key) {
        if (saved[key] !== undefined) {
          base[key] = saved[key];
        }
      });
    }
    base.dim = O.clamp(Number(base.dim) || 0, 0, 80);
    base.blur = O.clamp(Number(base.blur) || 0, 0, 20);
    return base;
  }

  function write(next) {
    O.store.set('wallpaper', next);
    apply();
    O.emit('wallpaper', next);
  }

  function presetCss(p) {
    return 'linear-gradient(' + p.angle + 'deg, ' + p.a + ' 0%, ' + p.b + ' 55%, ' + p.c + ' 100%)';
  }

  function presetById(id) {
    for (var i = 0; i < PRESETS.length; i++) {
      if (PRESETS[i].id === id) {
        return PRESETS[i];
      }
    }
    return PRESETS[0];
  }

  function apply() {
    var root = document.documentElement;
    var on = O.settings.get('bg') === 'photo';
    root.classList.toggle('has-wall', on);
    if (!wallEl) {
      return;
    }
    if (!on) {
      wallEl.style.backgroundImage = '';
      return;
    }
    var w = read();
    var image = w.kind === 'image' && w.data ? 'url("' + w.data + '")' : presetCss(presetById(w.id));
    wallEl.style.backgroundImage = image;
    wallEl.style.setProperty('--wall-dim', String(w.dim / 100));
    wallEl.style.setProperty('--wall-blur', w.blur + 'px');
  }

  /* resize a chosen file to a JPEG that fits the browser storage */
  function shrink(file) {
    return new Promise(function (resolve, reject) {
      if (!file || !/^image\//.test(file.type || '')) {
        reject(new Error('bad file'));
        return;
      }
      var url = URL.createObjectURL(file);
      var img = new Image();
      img.onload = function () {
        try {
          var w = img.naturalWidth;
          var h = img.naturalHeight;
          if (!w || !h) {
            throw new Error('empty image');
          }
          var k = Math.min(1, MAX_SIDE / Math.max(w, h));
          var canvas = document.createElement('canvas');
          canvas.width = Math.round(w * k);
          canvas.height = Math.round(h * k);
          canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
          URL.revokeObjectURL(url);
          resolve(canvas.toDataURL('image/jpeg', 0.82));
        } catch (err) {
          URL.revokeObjectURL(url);
          reject(err);
        }
      };
      img.onerror = function () {
        URL.revokeObjectURL(url);
        reject(new Error('cannot decode'));
      };
      img.src = url;
    });
  }

  function useImage(file) {
    shrink(file).then(function (data) {
      var w = read();
      w.kind = 'image';
      w.data = data;
      try {
        write(w);
      } catch (err) {
        O.toast(t('wp.err'), { kind: 'bad', icon: 'image' });
        return;
      }
      O.settings.set('bg', 'photo');
      O.toast(t('wp.saved'), { kind: 'good', icon: 'image' });
    }).catch(function () {
      O.toast(t('wp.err'), { kind: 'bad', icon: 'image' });
    });
  }

  /* settings block, used by the settings page */
  function control() {
    var box = O.el('div', { class: 'wp' });

    function paint() {
      O.clear(box);
      var w = read();
      var grid = O.el('div', { class: 'wp__grid', role: 'radiogroup', 'aria-label': t('wp.title') });
      PRESETS.forEach(function (p) {
        var active = O.settings.get('bg') === 'photo' && w.kind === 'preset' && w.id === p.id;
        var btn = O.el('button', {
          class: 'wp__tile' + (active ? ' is-on' : ''),
          type: 'button',
          role: 'radio',
          'aria-checked': active ? 'true' : 'false',
          title: t('wp.p.' + p.id)
        }, [O.icon('check', 16)]);
        btn.style.backgroundImage = presetCss(p);
        btn.addEventListener('click', function () {
          var cur = read();
          cur.kind = 'preset';
          cur.id = p.id;
          write(cur);
          O.settings.set('bg', 'photo');
          paint();
        });
        grid.appendChild(btn);
      });

      var mine = O.el('label', { class: 'wp__tile wp__tile--mine filepick' + (w.kind === 'image' && O.settings.get('bg') === 'photo' ? ' is-on' : ''), title: t('wp.upload') }, [
        O.icon('upload', 20),
        O.el('span', { text: t('wp.upload') })
      ]);
      if (w.kind === 'image' && w.data) {
        mine.style.backgroundImage = 'url("' + w.data + '")';
        mine.classList.add('has-image');
      }
      var input = O.el('input', { type: 'file', accept: 'image/*', class: 'filepick__input', 'aria-label': t('wp.upload') });
      input.addEventListener('change', function () {
        var file = input.files && input.files[0];
        input.value = '';
        if (file) {
          useImage(file);
        }
      });
      mine.appendChild(input);
      grid.appendChild(mine);
      box.appendChild(grid);

      function slider(label, key, max, unit) {
        var out = O.el('output', { class: 'range__out', text: w[key] + unit });
        var range = O.el('input', { type: 'range', class: 'range', min: '0', max: String(max), step: '1', value: String(w[key]), 'aria-label': label });
        range.addEventListener('input', function () {
          var cur = read();
          cur[key] = Number(range.value);
          out.textContent = range.value + unit;
          O.store.set('wallpaper', cur);
          apply();
        });
        return O.el('div', { class: 'wp__slider' }, [
          O.el('span', { class: 'wp__label', text: label }),
          O.el('div', { class: 'range__wrap' }, [range, out])
        ]);
      }
      box.appendChild(slider(t('wp.dim'), 'dim', 80, '%'));
      box.appendChild(slider(t('wp.blur'), 'blur', 20, 'px'));

      if (w.kind === 'image' && w.data) {
        var drop = O.el('button', { class: 'btn btn--ghost', type: 'button' }, [O.icon('trash', 16), O.el('span', { text: t('wp.remove') })]);
        drop.addEventListener('click', function () {
          var cur = read();
          cur.kind = 'preset';
          cur.data = '';
          write(cur);
          paint();
        });
        box.appendChild(drop);
      }
    }
    paint();
    var off = O.on('settings:bg', paint);
    box.__dispose = off;
    return box;
  }

  O.wallpaper = {
    control: control,
    apply: apply,
    presets: PRESETS
  };

  O.on('settings:bg', apply);
  O.on('import', apply);
  document.addEventListener('DOMContentLoaded', function () {
    wallEl = document.getElementById('wall');
    apply();
  });
  if (document.readyState !== 'loading') {
    wallEl = document.getElementById('wall');
    apply();
  }
})();
