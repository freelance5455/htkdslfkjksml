/* Orbita effects: canvas background (orbit, stars, aurora), card tilt and spotlight, button ripple */
(function () {
  'use strict';
  var O = window.Orbita;

  var TAU = Math.PI * 2;
  var canvas = null;
  var ctx = null;
  var w = 0;
  var h = 0;
  var dpr = 1;
  var raf = 0;
  var lastFrame = 0;
  var clock = 0;
  var mode = 'orbit';
  var scene = null;
  var pointer = { x: 0, y: 0, tx: 0, ty: 0 };
  var colors = { accent: [90, 100, 240], fg: [255, 255, 255], light: false };

  function rand(lo, hi) {
    return lo + Math.random() * (hi - lo);
  }

  function rgba(c, a) {
    return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a.toFixed(3) + ')';
  }

  function parseColor(value) {
    ctx.fillStyle = '#000000';
    ctx.fillStyle = value;
    var s = String(ctx.fillStyle);
    if (s.charAt(0) === '#' && s.length === 7) {
      return [parseInt(s.substr(1, 2), 16), parseInt(s.substr(3, 2), 16), parseInt(s.substr(5, 2), 16)];
    }
    var m = s.match(/rgba?\(([^)]+)\)/);
    if (m) {
      var p = m[1].split(',').map(parseFloat);
      return [p[0] | 0, p[1] | 0, p[2] | 0];
    }
    return [128, 128, 128];
  }

  function refreshColors() {
    if (!ctx) {
      return;
    }
    var cs = getComputedStyle(document.documentElement);
    colors.accent = parseColor(cs.getPropertyValue('--accent').trim() || '#5a64f0');
    colors.fg = parseColor(cs.getPropertyValue('--fg').trim() || '#ffffff');
    colors.light = document.documentElement.getAttribute('data-eff') === 'light';
  }

  /* ---------- scenes ---------- */
  function buildOrbit() {
    var count = Math.round(O.clamp((w * h) / 15000, 34, 86));
    var parts = [];
    for (var i = 0; i < count; i++) {
      parts.push({
        ring: Math.floor(rand(0, 5)),
        ang: rand(0, TAU),
        speed: rand(0.05, 0.19) * (Math.random() < 0.5 ? -1 : 1),
        size: rand(0.9, 2.6),
        a: rand(0.25, 0.75),
        hot: Math.random() < 0.28
      });
    }
    return { type: 'orbit', parts: parts };
  }

  function buildStars() {
    var count = Math.round(O.clamp((w * h) / 6200, 60, 230));
    var stars = [];
    for (var i = 0; i < count; i++) {
      stars.push({
        x: rand(0, w),
        y: rand(0, h),
        z: rand(0.2, 1),
        phase: rand(0, TAU),
        rate: rand(0.6, 2.4),
        hot: Math.random() < 0.18
      });
    }
    return { type: 'stars', stars: stars, shoot: null, nextShoot: 3 };
  }

  function buildAurora() {
    var blobs = [];
    for (var i = 0; i < 4; i++) {
      blobs.push({
        fx: rand(0.05, 0.12),
        fy: rand(0.04, 0.1),
        phase: rand(0, TAU),
        r: rand(0.28, 0.46),
        swap: i % 2 === 1
      });
    }
    return { type: 'aurora', blobs: blobs };
  }

  function build() {
    if (mode === 'stars') {
      scene = buildStars();
    } else if (mode === 'aurora') {
      scene = buildAurora();
    } else if (mode === 'orbit') {
      scene = buildOrbit();
    } else {
      scene = null;
    }
  }

  /* ---------- drawing ---------- */
  function drawOrbit(t) {
    var cx = w * 0.5 + (pointer.x - w * 0.5) * 0.025;
    var cy = Math.min(h * 0.3, 280) + (pointer.y - h * 0.5) * 0.02;
    var base = Math.max(w, 520) * 0.5;
    var tilt = -0.1;
    var cosT = Math.cos(tilt);
    var sinT = Math.sin(tilt);
    var ringAlpha = colors.light ? 0.09 : 0.075;
    var i;

    ctx.lineWidth = 1;
    for (i = 0; i < 5; i++) {
      var rx0 = base * (0.35 + i * 0.2);
      var ry0 = rx0 * 0.34;
      ctx.strokeStyle = rgba(colors.fg, ringAlpha);
      ctx.beginPath();
      ctx.ellipse(cx, cy, rx0, ry0, tilt, 0, TAU);
      ctx.stroke();
    }

    scene.parts.forEach(function (p) {
      var rx = base * (0.35 + p.ring * 0.2);
      var ry = rx * 0.34;
      var a = p.ang + t * p.speed;
      var ex = Math.cos(a) * rx;
      var ey = Math.sin(a) * ry;
      var x = cx + ex * cosT - ey * sinT;
      var y = cy + ex * sinT + ey * cosT;
      var color = p.hot ? colors.accent : colors.fg;
      var alpha = p.a * (colors.light ? 0.55 : 0.8) * (p.hot ? 1 : 0.7);
      ctx.fillStyle = rgba(color, alpha);
      ctx.beginPath();
      ctx.arc(x, y, p.size, 0, TAU);
      ctx.fill();
      if (p.hot) {
        ctx.fillStyle = rgba(colors.accent, alpha * 0.18);
        ctx.beginPath();
        ctx.arc(x, y, p.size * 4.2, 0, TAU);
        ctx.fill();
      }
    });
  }

  function drawStars(t, dt) {
    var px = (pointer.x - w * 0.5) * 0.03;
    var py = (pointer.y - h * 0.5) * 0.03;
    scene.stars.forEach(function (s) {
      var tw = 0.5 + 0.5 * Math.sin(s.phase + t * s.rate);
      var alpha = (0.18 + 0.6 * tw) * s.z * (colors.light ? 0.7 : 1);
      var x = s.x + px * s.z;
      var y = s.y + py * s.z;
      ctx.fillStyle = rgba(s.hot ? colors.accent : colors.fg, alpha);
      ctx.beginPath();
      ctx.arc(x, y, 0.5 + s.z * 1.5, 0, TAU);
      ctx.fill();
    });

    scene.nextShoot -= dt;
    if (!scene.shoot && scene.nextShoot <= 0) {
      scene.shoot = {
        x: rand(w * 0.1, w * 0.9),
        y: rand(0, h * 0.4),
        vx: rand(380, 560) * (Math.random() < 0.5 ? -1 : 1),
        vy: rand(150, 260),
        life: 0
      };
      scene.nextShoot = rand(5, 11);
    }
    if (scene.shoot) {
      var s2 = scene.shoot;
      s2.life += dt;
      s2.x += s2.vx * dt;
      s2.y += s2.vy * dt;
      var fade = Math.max(0, 1 - s2.life / 0.9);
      var grad = ctx.createLinearGradient(s2.x, s2.y, s2.x - s2.vx * 0.12, s2.y - s2.vy * 0.12);
      grad.addColorStop(0, rgba(colors.fg, 0.9 * fade));
      grad.addColorStop(1, rgba(colors.fg, 0));
      ctx.strokeStyle = grad;
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(s2.x, s2.y);
      ctx.lineTo(s2.x - s2.vx * 0.12, s2.y - s2.vy * 0.12);
      ctx.stroke();
      if (s2.life > 0.9) {
        scene.shoot = null;
      }
    }
  }

  function drawAurora(t) {
    var span = Math.max(w, h);
    var px = (pointer.x - w * 0.5) * 0.04;
    var py = (pointer.y - h * 0.5) * 0.04;
    scene.blobs.forEach(function (b) {
      var x = w * (0.5 + 0.38 * Math.sin(t * b.fx + b.phase)) + px;
      var y = h * (0.34 + 0.26 * Math.cos(t * b.fy + b.phase * 1.3)) + py;
      var r = span * b.r;
      var tone = b.swap ? [colors.accent[2], colors.accent[0], colors.accent[1]] : colors.accent;
      var peak = colors.light ? 0.16 : 0.26;
      var grad = ctx.createRadialGradient(x, y, 0, x, y, r);
      grad.addColorStop(0, rgba(tone, peak));
      grad.addColorStop(1, rgba(tone, 0));
      ctx.fillStyle = grad;
      ctx.fillRect(x - r, y - r, r * 2, r * 2);
    });
  }

  function paint(dt) {
    if (!ctx) {
      return;
    }
    ctx.clearRect(0, 0, w, h);
    if (!scene) {
      return;
    }
    pointer.x += (pointer.tx - pointer.x) * 0.06;
    pointer.y += (pointer.ty - pointer.y) * 0.06;
    if (scene.type === 'orbit') {
      drawOrbit(clock);
    } else if (scene.type === 'stars') {
      drawStars(clock, dt);
    } else if (scene.type === 'aurora') {
      drawAurora(clock);
    }
  }

  function frame(now) {
    raf = 0;
    if (document.hidden || !scene || !O.animated()) {
      paint(0);
      return;
    }
    var dt = lastFrame ? Math.min(0.05, (now - lastFrame) / 1000) : 0.016;
    lastFrame = now;
    clock += dt * (O.motionLevel() === 'calm' ? 0.45 : 1);
    paint(dt);
    raf = requestAnimationFrame(frame);
  }

  function start() {
    if (raf || !ctx) {
      return;
    }
    lastFrame = 0;
    raf = requestAnimationFrame(frame);
  }

  function stop() {
    if (raf) {
      cancelAnimationFrame(raf);
      raf = 0;
    }
  }

  function resize() {
    if (!canvas) {
      return;
    }
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    w = window.innerWidth;
    h = window.innerHeight;
    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h * dpr);
    canvas.style.width = w + 'px';
    canvas.style.height = h + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    pointer.x = pointer.tx = w * 0.5;
    pointer.y = pointer.ty = h * 0.4;
    build();
    paint(0);
    start();
  }

  function setMode(next) {
    mode = next;
    build();
    stop();
    paint(0);
    start();
  }

  /* ---------- pointer driven card effects ---------- */
  function onMove(event) {
    pointer.tx = event.clientX;
    pointer.ty = event.clientY;
    var target = event.target;
    if (!target || !target.closest) {
      return;
    }
    var card = target.closest('[data-tilt], .spot');
    if (!card) {
      return;
    }
    var rect = card.getBoundingClientRect();
    var x = event.clientX - rect.left;
    var y = event.clientY - rect.top;
    card.style.setProperty('--mx', x.toFixed(0) + 'px');
    card.style.setProperty('--my', y.toFixed(0) + 'px');
    if (card.hasAttribute('data-tilt') && O.motionLevel() === 'full') {
      var px = x / rect.width - 0.5;
      var py = y / rect.height - 0.5;
      card.style.setProperty('--rx', (-py * 9).toFixed(2) + 'deg');
      card.style.setProperty('--ry', (px * 11).toFixed(2) + 'deg');
    }
  }

  function onOut(event) {
    var target = event.target;
    if (!target || !target.closest) {
      return;
    }
    var card = target.closest('[data-tilt]');
    if (!card || (event.relatedTarget && card.contains(event.relatedTarget))) {
      return;
    }
    card.style.setProperty('--rx', '0deg');
    card.style.setProperty('--ry', '0deg');
  }

  var RIPPLE_SELECTOR = '.btn, .icon-btn, .seg__btn, .chip, .tile, .omni__go, .menu__item, .keypad__btn';

  function onDown(event) {
    if (!O.animated() || !event.target || !event.target.closest) {
      return;
    }
    var host = event.target.closest(RIPPLE_SELECTOR);
    if (!host) {
      return;
    }
    var rect = host.getBoundingClientRect();
    var size = Math.max(rect.width, rect.height) * 1.6;
    var dot = document.createElement('span');
    dot.className = 'ripple';
    dot.style.width = dot.style.height = size + 'px';
    dot.style.left = (event.clientX - rect.left - size / 2) + 'px';
    dot.style.top = (event.clientY - rect.top - size / 2) + 'px';
    host.appendChild(dot);
    setTimeout(function () {
      if (dot.parentNode) {
        dot.parentNode.removeChild(dot);
      }
    }, 620);
  }

  O.fx = {
    init: function (node) {
      canvas = node;
      ctx = canvas.getContext('2d');
      mode = O.settings.get('bg');
      refreshColors();
      resize();
    },
    setMode: setMode,
    refresh: refreshColors,
    start: start,
    stop: stop
  };

  window.addEventListener('resize', O.debounce(function () {
    resize();
  }, 120));
  window.addEventListener('pointermove', onMove, { passive: true });
  document.addEventListener('pointerout', onOut);
  document.addEventListener('pointerdown', onDown);
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) {
      stop();
    } else {
      start();
    }
  });

  O.on('settings:bg', function (value) {
    setMode(value);
  });
  O.on('settings:motion', function () {
    stop();
    paint(0);
    start();
  });
  O.on('theme', function () {
    refreshColors();
    paint(0);
  });
})();
