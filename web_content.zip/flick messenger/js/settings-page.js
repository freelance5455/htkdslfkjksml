/* Orbita Settings page: appearance, language, search, home blocks, data */
(function () {
  'use strict';
  var O = window.Orbita;
  var t = O.t;

  function group(iconName, title, rows) {
    return O.el('section', { class: 'sgroup' }, [
      O.el('h2', { class: 'sgroup__title' }, [O.icon(iconName, 18), O.el('span', { text: title })]),
      O.el('div', { class: 'sgroup__body' }, rows)
    ]);
  }

  function row(title, desc, control, stacked) {
    return O.el('div', { class: 'srow2' + (stacked ? ' srow2--stack' : '') }, [
      O.el('div', { class: 'srow2__text' }, [
        O.el('span', { class: 'srow2__title', text: title }),
        desc ? O.el('span', { class: 'srow2__desc', text: desc }) : null
      ]),
      O.el('div', { class: 'srow2__control' }, control)
    ]);
  }

  function toggleRow(key, title, desc) {
    return row(title, desc, [
      O.switchEl(!!O.settings.get(key), function (on) {
        O.settings.set(key, on);
      }, title)
    ]);
  }

  function exportData() {
    var out = { app: 'orbita', version: 1, exportedAt: new Date().toISOString(), data: {} };
    O.store.keys.forEach(function (key) {
      out.data[key] = O.store.get(key, null);
    });
    return JSON.stringify(out, null, 2);
  }

  function importData(text) {
    var parsed;
    try {
      parsed = JSON.parse(text);
    } catch (err) {
      return false;
    }
    if (!parsed || parsed.app !== 'orbita' || !parsed.data || typeof parsed.data !== 'object') {
      return false;
    }
    var d = parsed.data;
    if (d.settings && typeof d.settings === 'object') {
      O.settings.replace(d.settings);
    }
    if (Array.isArray(d.sites)) {
      O.sites.replaceAll(d.sites);
    }
    if (Array.isArray(d.history)) {
      O.history.replaceAll(d.history);
    }
    if (typeof d.notes === 'string') {
      O.store.set('notes', d.notes);
    }
    if (Array.isArray(d.todos)) {
      O.store.set('todos', d.todos);
    }
    if (d.icons && typeof d.icons === 'object') {
      O.avatars.replaceAll(d.icons);
    }
    if (Array.isArray(d.reading)) {
      O.store.set('reading', d.reading);
      O.emit('reading');
    }
    if (d.wallpaper && typeof d.wallpaper === 'object') {
      O.store.set('wallpaper', d.wallpaper);
      O.wallpaper.apply();
    }
    if (d.tools2 && typeof d.tools2 === 'object') {
      O.store.set('tools2', d.tools2);
    }
    return true;
  }

  function openImport() {
    var area = O.el('textarea', {
      class: 'field__area',
      id: 'import-area',
      rows: '8',
      placeholder: t('s.import.ph'),
      spellcheck: 'false',
      'data-autofocus': ''
    });
    var err = O.el('p', { class: 'field__error', text: t('s.import.bad'), hidden: true });
    O.modal.open({
      title: t('s.import'),
      size: 'md',
      content: O.el('div', { class: 'form' }, [area, err]),
      actions: [
        { label: t('c.cancel'), kind: 'ghost' },
        {
          label: t('s.import.do'),
          kind: 'primary',
          onClick: function () {
            if (importData(area.value)) {
              O.toast(t('s.import.ok'), { kind: 'good' });
              return true;
            }
            err.hidden = false;
            return false;
          }
        }
      ]
    });
  }

  function build(root) {
    var page = O.el('div', { class: 'page page--settings' });
    page.appendChild(O.pageHead('gear', t('s.title'), t('s.sub')));

    /* ----- appearance ----- */
    var themeSeg = O.segmented([
      { value: 'system', label: t('s.theme.system'), icon: 'gear' },
      { value: 'light', label: t('s.theme.light'), icon: 'sun' },
      { value: 'dark', label: t('s.theme.dark'), icon: 'moon' },
      { value: 'black', label: t('s.theme.black'), icon: 'contrast' }
    ], O.settings.get('theme'), function (value, event) {
      O.theme.set(value, event);
    }, t('s.theme'));
    themeSeg.classList.add('seg--wrap');

    var accents = O.el('div', { class: 'swatches', role: 'radiogroup', 'aria-label': t('s.accent') });
    function paintSwatches() {
      O.clear(accents);
      var chosen = O.settings.get('accent');
      O.theme.order.forEach(function (name) {
        var btn = O.el('button', {
          class: 'swatch' + (name === chosen ? ' is-on' : ''),
          type: 'button',
          role: 'radio',
          'aria-checked': name === chosen ? 'true' : 'false',
          'aria-label': t('s.accent.' + name),
          title: t('s.accent.' + name)
        }, [O.icon('check', 14)]);
        btn.style.setProperty('--sw', O.theme.color(name));
        btn.addEventListener('click', function () {
          O.settings.set('accent', name);
        });
        accents.appendChild(btn);
      });
    }
    paintSwatches();
    var offTheme = O.on('theme', paintSwatches);

    var bgSeg = O.segmented([
      { value: 'orbit', label: t('s.bg.orbit') },
      { value: 'stars', label: t('s.bg.stars') },
      { value: 'aurora', label: t('s.bg.aurora') },
      { value: 'photo', label: t('wp.title') },
      { value: 'none', label: t('s.bg.none') }
    ], O.settings.get('bg'), function (value) {
      O.settings.set('bg', value);
    }, t('s.bg'));
    bgSeg.classList.add('seg--wrap');

    var motionSeg = O.segmented([
      { value: 'full', label: t('s.motion.full') },
      { value: 'calm', label: t('s.motion.calm') },
      { value: 'off', label: t('s.motion.off') }
    ], O.settings.get('motion'), function (value) {
      O.settings.set('motion', value);
    }, t('s.motion'));

    var densitySeg = O.segmented([
      { value: 'cozy', label: t('s.density.cozy') },
      { value: 'compact', label: t('s.density.compact') }
    ], O.settings.get('density'), function (value) {
      O.settings.set('density', value);
    }, t('s.density'));

    var fontOut = O.el('output', { class: 'range__out', text: Math.round(O.settings.get('fontScale') * 100) + '%' });
    var fontRange = O.el('input', {
      class: 'range',
      id: 'font-scale',
      type: 'range',
      min: '85',
      max: '120',
      step: '5',
      value: String(Math.round(O.settings.get('fontScale') * 100)),
      'aria-label': t('s.font')
    });
    fontRange.addEventListener('input', function () {
      var v = parseInt(fontRange.value, 10);
      fontOut.textContent = v + '%';
      O.settings.set('fontScale', v / 100);
    });

    page.appendChild(group('palette', t('s.appearance'), [
      row(t('s.theme'), t('s.theme.d'), [themeSeg], true),
      row(t('s.accent'), null, [accents]),
      row(t('s.bg'), t('s.bg.d'), [bgSeg], true),
      row(t('wp.title'), t('wp.d'), [O.wallpaper.control()], true),
      row(t('s.motion'), t('s.motion.d'), [motionSeg]),
      row(t('s.density'), null, [densitySeg]),
      row(t('s.font'), null, [O.el('div', { class: 'range__wrap' }, [fontRange, fontOut])])
    ]));

    /* ----- language ----- */
    var langBox = O.el('div', { class: 'langs', role: 'radiogroup', 'aria-label': t('s.language') });
    function paintLangs() {
      O.clear(langBox);
      var cur = O.i18n.current();
      O.i18n.langs.forEach(function (code) {
        var btn = O.el('button', {
          class: 'lang' + (code === cur ? ' is-on' : ''),
          type: 'button',
          role: 'radio',
          'aria-checked': code === cur ? 'true' : 'false'
        }, [
          O.el('span', { class: 'lang__code', text: O.i18n.short[code] }),
          O.el('span', { class: 'lang__name', text: O.i18n.names[code] })
        ]);
        btn.addEventListener('click', function () {
          O.i18n.set(code);
        });
        langBox.appendChild(btn);
      });
    }
    paintLangs();
    page.appendChild(group('globe', t('s.language'), [langBox]));

    /* ----- search ----- */
    var engineSeg = O.segmented(O.search.choices.map(function (id) {
      return { value: id, label: O.search.engineName(id) };
    }), O.settings.get('engine'), function (value) {
      O.settings.set('engine', value);
    }, t('s.engine'));
    engineSeg.classList.add('seg--wrap');
    page.appendChild(group('search', t('s.search'), [
      row(t('s.engine'), t('s.engine.d'), [engineSeg], true),
      toggleRow('saveHistory', t('s.history.save'), t('s.history.save.d'))
    ]));

    /* ----- home ----- */
    page.appendChild(group('home', t('s.home'), [
      toggleRow('showClaude', t('s.home.claude'), null),
      toggleRow('showClock', t('s.home.clock'), null),
      toggleRow('showChips', t('s.home.chips'), null)
    ]));

    /* ----- data ----- */
    var exportBtn = O.el('button', { class: 'btn btn--ghost', type: 'button' }, [O.icon('copy', 16), O.el('span', { text: t('s.export') })]);
    exportBtn.addEventListener('click', function () {
      O.copy(exportData()).then(function (ok) {
        O.toast(ok ? t('s.exported') : t('h.copyFail'), { kind: ok ? 'good' : 'warn' });
      });
    });
    var importBtn = O.el('button', { class: 'btn btn--ghost', type: 'button' }, [O.icon('upload', 16), O.el('span', { text: t('s.import') })]);
    importBtn.addEventListener('click', openImport);
    var resetBtn = O.el('button', { class: 'btn btn--danger-ghost', type: 'button' }, [O.icon('reset', 16), O.el('span', { text: t('s.reset') })]);
    resetBtn.addEventListener('click', function () {
      O.modal.confirm({ title: t('s.reset'), message: t('s.reset.confirm'), confirmLabel: t('s.reset'), danger: true }).then(function (yes) {
        if (yes) {
          O.settings.reset();
          O.sites.reset();
          O.toast(t('s.reset.done'), { kind: 'good' });
        }
      });
    });
    page.appendChild(group('download', t('s.data'), [
      row(t('s.export'), t('s.export.d'), [exportBtn]),
      row(t('s.import'), t('s.import.d'), [importBtn]),
      row(t('s.reset'), t('s.reset.d'), [resetBtn]),
      O.el('p', { class: 'sgroup__note', text: t('s.local') })
    ]));

    root.appendChild(page);
    O.stagger(page, '.sgroup');

    var offAccent = O.on('settings:accent', paintSwatches);
    var offThemeValue = O.on('settings:theme', function (value) {
      themeSeg.setValue(value);
    });
    return function () {
      offTheme();
      offAccent();
      offThemeValue();
    };
  }

  O.registerPage('settings', {
    icon: 'gear',
    titleKey: 'tab.settings',
    singleton: true,
    build: build
  });
})();
