/* Orbita phone mode: bottom navigation, tab switcher, swipe between tabs */
(function () {
  'use strict';
  var O = window.Orbita;
  var t = O.t;

  var mq = window.matchMedia ? window.matchMedia('(max-width: 760px)') : { matches: false };
  var nav = null;
  var buttons = {};
  var countEl = null;
  var switcher = null;

  function isMobile() {
    return !!mq.matches;
  }

  /* ---------- bottom navigation ---------- */
  var ITEMS = [
    { id: 'home', icon: 'home', label: 'tab.home', types: ['home'] },
    { id: 'ai', icon: 'spark', label: 'tab.ai', types: ['ai'] },
    { id: 'tabs', icon: null, label: 'nav.tabs', types: [] },
    { id: 'tools', icon: 'tools', label: 'tab.tools', types: ['tools'] },
    { id: 'more', icon: 'menu', label: 'nav.more', types: [] }
  ];

  function run(id, node) {
    if (id === 'home') {
      O.tabs.focus('home');
    } else if (id === 'ai') {
      O.tabs.open('ai');
    } else if (id === 'tabs') {
      openSwitcher();
    } else if (id === 'tools') {
      O.tabs.open('tools');
    } else if (id === 'more') {
      O.mainMenu(node);
    }
  }

  function buildNav() {
    O.clear(nav);
    buttons = {};
    ITEMS.forEach(function (item) {
      var visual;
      if (item.id === 'tabs') {
        countEl = O.el('span', { class: 'mnav__count', text: String(O.tabs.count()) });
        visual = O.el('span', { class: 'mnav__icon mnav__icon--tabs' }, [countEl]);
      } else {
        visual = O.el('span', { class: 'mnav__icon' }, [O.icon(item.icon, 22)]);
      }
      var btn = O.el('button', { class: 'mnav__btn', type: 'button', data: { id: item.id } }, [
        visual,
        O.el('span', { class: 'mnav__label', text: t(item.label) })
      ]);
      btn.addEventListener('click', function () {
        run(item.id, btn);
      });
      buttons[item.id] = btn;
      nav.appendChild(btn);
    });
    paintNav();
  }

  function paintNav() {
    if (!nav) {
      return;
    }
    var tab = O.tabs.active();
    var type = tab ? tab.type : '';
    ITEMS.forEach(function (item) {
      var on = item.types.indexOf(type) >= 0;
      var btn = buttons[item.id];
      if (btn) {
        btn.classList.toggle('is-on', on);
        if (on) {
          btn.setAttribute('aria-current', 'page');
        } else {
          btn.removeAttribute('aria-current');
        }
      }
    });
    if (countEl) {
      countEl.textContent = String(O.tabs.count());
    }
  }

  /* ---------- tab switcher ---------- */
  function openSwitcher() {
    if (switcher) {
      return;
    }
    var previous = document.activeElement;
    var closed = false;
    var grid = O.el('div', { class: 'switcher__grid', role: 'list' });
    var title = O.el('h2', { class: 'switcher__title' });

    var closeBtn = O.el('button', { class: 'icon-btn', type: 'button', 'aria-label': t('c.close') }, [O.icon('close', 22)]);
    var addBtn = O.el('button', { class: 'btn btn--primary switcher__add', type: 'button' }, [
      O.icon('plus', 18),
      O.el('span', { text: t('tab.new') })
    ]);
    var othersBtn = O.el('button', { class: 'btn btn--ghost', type: 'button' }, [
      O.icon('trash', 16),
      O.el('span', { text: t('tab.closeOthers') })
    ]);

    var panel = O.el('div', { class: 'switcher', role: 'dialog', 'aria-modal': 'true', 'aria-label': t('nav.tabs') }, [
      O.el('div', { class: 'switcher__head' }, [title, closeBtn]),
      grid,
      O.el('div', { class: 'switcher__foot' }, [othersBtn, addBtn])
    ]);
    var backdrop = O.el('div', { class: 'overlay overlay--switcher' }, [panel]);

    var entry = {
      close: function () {
        if (closed) {
          return;
        }
        closed = true;
        switcher = null;
        O.ui.pop(entry);
        offA();
        offB();
        backdrop.classList.add('is-leaving');
        setTimeout(function () {
          if (backdrop.parentNode) {
            backdrop.parentNode.removeChild(backdrop);
          }
        }, O.animated() ? 200 : 0);
        if (previous && previous.focus) {
          try { previous.focus(); } catch (err) { /* ignore */ }
        }
      }
    };

    function paint() {
      O.clear(grid);
      var list = O.tabs.list();
      var activeTab = O.tabs.active();
      title.textContent = O.plural('nav.tabs.count', list.length);
      list.forEach(function (tab) {
        var isActive = !!activeTab && activeTab.id === tab.id;
        var card = O.el('div', {
          class: 'swcard' + (isActive ? ' is-active' : ''),
          role: 'listitem'
        });
        var open = O.el('button', { class: 'swcard__open', type: 'button' }, [
          O.el('span', { class: 'swcard__icon' }, [O.icon(O.tabs.iconOf(tab), 22)]),
          O.el('span', { class: 'swcard__title', text: O.tabs.titleOf(tab) }),
          tab.pinned ? O.el('span', { class: 'swcard__pin' }, [O.icon('pin', 14), O.el('span', { text: t('tab.pin.short') })]) : null
        ]);
        open.addEventListener('click', function () {
          O.tabs.activate(tab.id);
          entry.close();
        });
        card.appendChild(open);

        var pin = O.el('button', {
          class: 'icon-btn icon-btn--sm swcard__pinbtn',
          type: 'button',
          'aria-label': tab.pinned ? t('tab.unpin') : t('tab.pin'),
          title: tab.pinned ? t('tab.unpin') : t('tab.pin')
        }, [O.icon('pin', 16)]);
        pin.addEventListener('click', function () {
          O.tabs.togglePin(tab.id);
        });
        card.appendChild(pin);

        if (!tab.pinned) {
          var x = O.el('button', { class: 'icon-btn icon-btn--sm swcard__x', type: 'button', 'aria-label': t('tab.close'), title: t('tab.close') }, [O.icon('close', 16)]);
          x.addEventListener('click', function () {
            O.tabs.close(tab.id);
          });
          card.appendChild(x);
        }
        grid.appendChild(card);
      });
      O.stagger(grid);
    }

    var offA = O.on('tab:active', function () {
      setTimeout(paint, O.animated() ? 200 : 0);
    });
    var offB = O.on('tabs', paint);

    closeBtn.addEventListener('click', entry.close);
    addBtn.addEventListener('click', function () {
      O.tabs.open('home');
      entry.close();
    });
    othersBtn.addEventListener('click', function () {
      var tab = O.tabs.active();
      if (tab) {
        O.tabs.closeOthers(tab.id);
      }
    });

    paint();
    O.ui.overlayRoot().appendChild(backdrop);
    O.ui.push(entry);
    switcher = entry;
    setTimeout(function () {
      var on = O.$('.swcard.is-active .swcard__open', backdrop);
      if (on) {
        on.focus();
      }
    }, 40);
  }

  /* ---------- swipe between tabs ---------- */
  var touch = null;
  var BLOCKED = '.seg, input, textarea, select, .tabs, .hours__cols, .sw__laps, .range, .todo__list, [data-noswipe]';

  function scrollsSideways(node) {
    var el = node;
    while (el && el !== document.body && el.nodeType === 1) {
      var style = window.getComputedStyle(el);
      var scrollable = /(auto|scroll)/.test(style.overflowX);
      if (scrollable && el.scrollWidth > el.clientWidth + 2) {
        return true;
      }
      el = el.parentNode;
    }
    return false;
  }

  function onTouchStart(event) {
    touch = null;
    if (!isMobile() || event.touches.length !== 1 || O.ui.hasOverlay()) {
      return;
    }
    var target = event.target;
    if (!target || !target.closest || target.closest(BLOCKED) || scrollsSideways(target)) {
      return;
    }
    var point = event.touches[0];
    touch = { x: point.clientX, y: point.clientY, at: Date.now() };
  }

  function onTouchEnd(event) {
    if (!touch) {
      return;
    }
    var point = event.changedTouches[0];
    var dx = point.clientX - touch.x;
    var dy = point.clientY - touch.y;
    var dt = Date.now() - touch.at;
    touch = null;
    if (Math.abs(dx) < 90 || Math.abs(dy) > Math.abs(dx) * 0.45 || dt > 700 || O.tabs.count() < 2) {
      return;
    }
    if (dx < 0) {
      O.tabs.next();
    } else {
      O.tabs.prev();
    }
    var now = O.tabs.active();
    if (now) {
      O.toast(O.tabs.titleOf(now), { icon: O.tabs.iconOf(now), ms: 900 });
    }
  }

  O.mobile = {
    isMobile: isMobile,
    openSwitcher: openSwitcher,
    init: function () {
      nav = O.$('#mnav');
      if (!nav) {
        return;
      }
      buildNav();
      var views = O.$('#views');
      if (views) {
        views.addEventListener('touchstart', onTouchStart, { passive: true });
        views.addEventListener('touchend', onTouchEnd, { passive: true });
      }
      O.on('tab:active', paintNav);
      O.on('tabs', paintNav);
      O.on('lang', buildNav);
    }
  };
})();
