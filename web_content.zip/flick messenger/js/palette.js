/* Orbita command palette (Ctrl+K) and the keyboard shortcuts sheet */
(function () {
  'use strict';
  var O = window.Orbita;
  var t = O.t;

  var current = null;

  function commands() {
    var list = [];

    function add(group, icon, label, run, extra) {
      list.push({
        group: group,
        icon: icon,
        label: label,
        run: run,
        hint: extra && extra.hint,
        kw: (extra && extra.kw) || ''
      });
    }

    var gNav = t('p.nav');
    add(gNav, 'plus', t('p.newtab'), function () { O.tabs.open('home'); }, { hint: 'Alt T', kw: 'new tab home' });
    add(gNav, 'shield', 'Орбита VPN', function () {
      O.history.add({ type: 'site', text: 'Орбита VPN', url: O.sites.vpnUrl });
      O.open(O.sites.vpnUrl);
    }, { kw: 'vpn впн' });
    add(gNav, 'spark', t('tab.ai'), function () { O.tabs.open('ai'); }, { kw: 'ai claude chatgpt gemini' });
    add(gNav, 'grid', t('tab.widgets'), function () { O.tabs.open('widgets'); }, { kw: 'widgets timer todo notes' });
    add(gNav, 'bookmark', t('tab.reading'), function () { O.tabs.open('reading'); }, { kw: 'reading list read later читать позже' });
    add(gNav, 'clock', t('tab.recent'), function () { O.tabs.open('recent'); }, { kw: 'recent' });
    add(gNav, 'history', t('tab.history'), function () { O.tabs.open('history'); }, { kw: 'history' });
    add(gNav, 'star', t('tab.bookmarks'), function () { O.tabs.open('bookmarks'); }, { kw: 'sites bookmarks' });
    add(gNav, 'tools', t('tab.tools'), function () { O.tabs.open('tools'); }, { kw: 'tools calculator' });
    add(gNav, 'gear', t('tab.settings'), function () { O.tabs.open('settings'); }, { kw: 'settings' });

    add(t('p.actions'), O.settings.get('saveHistory') ? 'eyeoff' : 'eye', t('m.private'), function () { O.togglePrivate(); }, { kw: 'private incognito инкогнито приватный' });
    add(t('p.actions'), 'image', t('wp.title'), function () { O.tabs.open('settings'); }, { kw: 'wallpaper обои шпалери background' });

    var gTheme = t('p.theme');
    [['system', 'gear'], ['light', 'sun'], ['dark', 'moon'], ['black', 'contrast']].forEach(function (pair) {
      add(gTheme, pair[1], t('s.theme') + ': ' + t('s.theme.' + pair[0]), function () { O.theme.set(pair[0]); }, { kw: 'theme' });
    });

    var gLang = t('p.lang');
    O.i18n.langs.forEach(function (code) {
      add(gLang, 'globe', t('s.language') + ': ' + O.i18n.names[code], function () { O.i18n.set(code); }, { kw: 'language ' + code });
    });

    var gAccent = t('p.accent');
    O.theme.order.forEach(function (name) {
      add(gAccent, 'palette', t('s.accent') + ': ' + t('s.accent.' + name), function () { O.settings.set('accent', name); }, { kw: 'accent color' });
    });

    var gAct = t('p.actions');
    add(gAct, 'reload', t('bar.reload'), function () { O.tabs.reload(); }, { kw: 'reload refresh' });
    add(gAct, 'shield', O.settings.get('saveHistory') ? t('p.history.off') : t('p.history.on'), function () {
      O.settings.set('saveHistory', !O.settings.get('saveHistory'));
    }, { kw: 'private incognito history' });
    add(gAct, 'trash', t('h.clear'), function () {
      O.modal.confirm({ title: t('h.clear'), message: t('h.clear.confirm'), confirmLabel: t('h.clear.yes'), danger: true }).then(function (yes) {
        if (yes) {
          O.history.clear();
          O.toast(t('h.cleared'), { kind: 'good' });
        }
      });
    }, { kw: 'clear history' });
    add(gAct, 'keyboard', t('k.title'), function () { O.palette.showShortcuts(); }, { hint: '?', kw: 'keyboard shortcuts help' });

    return list;
  }

  function open(initial) {
    if (current) {
      current.focus();
      return;
    }
    var all = commands();
    var shown = [];
    var active = 0;

    var input = O.el('input', {
      class: 'palette__input',
      type: 'text',
      placeholder: t('p.placeholder'),
      'aria-label': t('p.placeholder'),
      autocomplete: 'off',
      spellcheck: 'false',
      role: 'combobox',
      'aria-expanded': 'true'
    });
    var list = O.el('div', { class: 'palette__list', role: 'listbox' });

    var panel = O.el('div', { class: 'palette', role: 'dialog', 'aria-modal': 'true', 'aria-label': t('p.placeholder') }, [
      O.el('div', { class: 'palette__bar' }, [O.icon('command', 20), input, O.el('kbd', { class: 'kbd', text: 'Esc' })]),
      list,
      O.el('div', { class: 'palette__foot' }, [
        O.el('span', {}, [O.el('kbd', { class: 'kbd', text: '↑↓' }), ' ' + t('p.hint.move')]),
        O.el('span', {}, [O.el('kbd', { class: 'kbd', text: '↵' }), ' ' + t('p.hint.run')])
      ])
    ]);
    var backdrop = O.el('div', { class: 'overlay overlay--palette' }, [panel]);
    var previous = document.activeElement;
    var closed = false;

    var entry = {
      close: function () {
        if (closed) {
          return;
        }
        closed = true;
        current = null;
        O.ui.pop(entry);
        backdrop.classList.add('is-leaving');
        setTimeout(function () {
          if (backdrop.parentNode) {
            backdrop.parentNode.removeChild(backdrop);
          }
        }, O.animated() ? 180 : 0);
        if (previous && previous.focus) {
          try { previous.focus(); } catch (err) { /* ignore */ }
        }
      },
      focus: function () {
        input.focus();
      }
    };

    function run(item) {
      entry.close();
      if (item.run) {
        item.run();
      }
    }

    function paint() {
      O.clear(list);
      if (!shown.length) {
        list.appendChild(O.el('p', { class: 'palette__empty', text: t('p.empty') }));
        return;
      }
      var lastGroup = null;
      shown.forEach(function (item, idx) {
        if (item.group !== lastGroup) {
          lastGroup = item.group;
          list.appendChild(O.el('div', { class: 'palette__group', text: item.group }));
        }
        var row = O.el('button', {
          class: 'palette__row' + (idx === active ? ' is-active' : ''),
          type: 'button',
          role: 'option',
          'aria-selected': idx === active ? 'true' : 'false'
        }, [
          O.icon(item.icon, 18),
          O.el('span', { class: 'palette__label', text: item.label }),
          item.hint ? O.el('kbd', { class: 'kbd', text: item.hint }) : null
        ]);
        row.addEventListener('click', function () { run(item); });
        row.addEventListener('pointermove', function () {
          if (active !== idx) {
            active = idx;
            paint();
          }
        });
        list.appendChild(row);
      });
      var on = O.$('.is-active', list);
      if (on && on.scrollIntoView) {
        on.scrollIntoView({ block: 'nearest' });
      }
    }

    function filter() {
      var q = input.value.trim().toLowerCase();
      shown = [];
      var scored = [];
      all.forEach(function (cmd, idx) {
        var hay = (cmd.label + ' ' + cmd.kw).toLowerCase();
        var pos = q ? hay.indexOf(q) : 0;
        if (pos >= 0) {
          scored.push({ cmd: cmd, pos: pos, idx: idx });
        }
      });
      scored.sort(function (a, b) {
        return a.pos - b.pos || a.idx - b.idx;
      });
      var matched = scored.slice(0, q ? 9 : 14).map(function (s) {
        return s.cmd;
      });
      /* a command that matches what you typed comes first; otherwise the search row leads */
      if (q && matched.length) {
        shown = matched.slice();
      }
      if (q) {
        var action = O.search.resolve(input.value);
        shown.push({
          group: t('p.search'),
          icon: action.kind === 'site' ? 'globe' : 'search',
          label: action.kind === 'site' ? t('search.open', { host: action.label }) : t('search.in', { engine: action.label, text: action.text }),
          hint: '↵',
          run: function () { O.search.go(input.value); }
        });
        if (q.length >= 2) {
          var hits = 0;
          O.history.all().some(function (item) {
            if (item.text.toLowerCase().indexOf(q) < 0) {
              return false;
            }
            shown.push({
              group: t('tab.history'),
              icon: item.type === 'site' ? 'globe' : 'clock',
              label: item.text,
              run: function () {
                var url = O.search.urlFor(item);
                O.history.add({ type: item.type, text: item.text, url: url });
                O.open(url);
              }
            });
            hits++;
            return hits >= 3;
          });
        }
      }
      if (!q || !matched.length) {
        matched.forEach(function (cmd) {
          shown.push(cmd);
        });
      }
      active = 0;
      paint();
    }

    input.addEventListener('input', filter);
    input.addEventListener('keydown', function (event) {
      if (event.key === 'ArrowDown') {
        event.preventDefault();
        active = shown.length ? (active + 1) % shown.length : 0;
        paint();
      } else if (event.key === 'ArrowUp') {
        event.preventDefault();
        active = shown.length ? (active - 1 + shown.length) % shown.length : 0;
        paint();
      } else if (event.key === 'Enter') {
        event.preventDefault();
        if (shown[active]) {
          run(shown[active]);
        }
      }
    });
    backdrop.addEventListener('pointerdown', function (event) {
      if (event.target === backdrop) {
        entry.close();
      }
    });

    O.ui.overlayRoot().appendChild(backdrop);
    O.ui.push(entry);
    current = entry;
    if (initial) {
      input.value = initial;
    }
    filter();
    setTimeout(function () { input.focus(); }, 20);
  }

  function showShortcuts() {
    var rows = [
      ['k.palette', 'Ctrl K'],
      ['k.focus', '/'],
      ['k.newTab', 'Alt T'],
      ['k.closeTab', 'Alt W'],
      ['k.prevTab', 'Alt ,'],
      ['k.nextTab', 'Alt .'],
      ['k.theme', 'Alt D'],
      ['k.help', '?'],
      ['k.close', 'Esc']
    ];
    var table = O.el('dl', { class: 'keys' });
    rows.forEach(function (row) {
      table.appendChild(O.el('div', { class: 'keys__row' }, [
        O.el('dt', { text: t(row[0]) }),
        O.el('dd', {}, row[1].split(' ').map(function (k) {
          return O.el('kbd', { class: 'kbd', text: k });
        }))
      ]));
    });
    table.appendChild(O.el('p', { class: 'keys__note', text: t('k.bangs') }));
    O.modal.open({ title: t('k.title'), size: 'sm', content: table, actions: [{ label: t('c.close'), kind: 'primary' }] });
  }

  O.palette = {
    open: open,
    showShortcuts: showShortcuts
  };
})();
