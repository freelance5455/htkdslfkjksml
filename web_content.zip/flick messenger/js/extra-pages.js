/* Orbita pages opened from the menu: "Всё под рукой" (widgets) and "Недавнее" (recent activity) */
(function () {
  'use strict';
  var O = window.Orbita;
  var t = O.t;

  /* ---------- widgets page ---------- */
  function buildWidgets(root) {
    var disposers = [];
    var page = O.el('div', { class: 'page page--wide page--widgets' });
    page.appendChild(O.pageHead('grid', t('tab.widgets'), t('wp.sub')));

    var grid = O.el('div', { class: 'widgets' });
    var clock = O.widgets.analogClock();
    disposers.push(clock.dispose);

    [O.widgets.pomodoro(), O.widgets.todo(), O.widgets.notes(), O.widgets.today()].forEach(function (part) {
      disposers.push(part.dispose);
      grid.appendChild(part.el);
    });

    grid.appendChild(O.el('article', { class: 'widget widget--clock spot' }, [
      O.el('header', { class: 'widget__head' }, [
        O.el('span', { class: 'widget__icon' }, [O.icon('clock', 18)]),
        O.el('h3', { class: 'widget__title', text: t('w.clock') })
      ]),
      O.el('div', { class: 'widget__body widget__body--center' }, [
        clock.el,
        O.el('p', { class: 'clockcard__date', text: O.fmt.date(Date.now(), { weekday: 'long', day: 'numeric', month: 'long' }) })
      ])
    ]));

    O.stagger(grid);
    page.appendChild(grid);
    root.appendChild(page);

    return function () {
      disposers.forEach(O.run);
    };
  }

  /* ---------- recent page ---------- */
  function buildRecent(root) {
    var page = O.el('div', { class: 'page page--recent' });
    var all = O.el('button', { class: 'btn btn--ghost', type: 'button' }, [
      O.icon('history', 16),
      O.el('span', { text: t('home.allHistory') })
    ]);
    all.addEventListener('click', function () {
      O.tabs.open('history');
    });
    page.appendChild(O.pageHead('clock', t('tab.recent'), t('rp.sub'), [all]));

    var list = O.el('div', { class: 'recent recent--page' });
    page.appendChild(list);
    root.appendChild(page);

    function paint() {
      O.clear(list);
      var items = O.history.recent(30);
      if (!items.length) {
        list.appendChild(O.emptyState('clock', t('h.empty'), t('home.recent.empty')));
        return;
      }
      var lastDay = null;
      items.forEach(function (item) {
        var day = O.fmt.dayKey(item.ts);
        if (day !== lastDay) {
          lastDay = day;
          list.appendChild(O.el('h3', { class: 'recent__day', text: O.fmt.dayLabel(item.ts) }));
        }
        var a = O.el('a', { class: 'recent__row' }, [
          O.el('span', { class: 'recent__icon' }, [O.icon(item.type === 'site' ? 'globe' : 'search', 16)]),
          O.el('span', { class: 'recent__text', text: item.text }),
          O.el('span', { class: 'recent__time', text: O.fmt.time(item.ts) })
        ]);
        O.link(a, O.search.urlFor(item), { type: item.type, text: item.text, url: O.search.urlFor(item) });
        list.appendChild(a);
      });
    }

    paint();
    var off = O.on('history', paint);
    return function () {
      off();
    };
  }

  O.registerPage('widgets', {
    icon: 'grid',
    titleKey: 'tab.widgets',
    singleton: true,
    build: buildWidgets
  });

  O.registerPage('recent', {
    icon: 'clock',
    titleKey: 'tab.recent',
    singleton: true,
    build: buildRecent
  });
})();
