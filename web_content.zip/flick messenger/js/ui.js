/* Orbita UI kit: toasts, modals, menus, segmented controls, switches, page chrome helpers */
(function () {
  'use strict';
  var O = window.Orbita;

  var overlayRoot = null;
  var toastRoot = null;
  var stack = [];
  var openMenu = null;

  /* ---------- toasts ---------- */
  O.toast = function (message, opts) {
    opts = opts || {};
    if (!toastRoot) {
      return;
    }
    var icons = { good: 'check', warn: 'bolt', bad: 'close', info: 'spark' };
    var kind = opts.kind || 'info';
    var node = O.el('div', { class: 'toast toast--' + kind, role: 'status' }, [
      O.icon(opts.icon || icons[kind] || 'spark', 18),
      O.el('span', { class: 'toast__text', text: message })
    ]);
    toastRoot.appendChild(node);
    while (toastRoot.children.length > 4) {
      toastRoot.removeChild(toastRoot.firstChild);
    }
    setTimeout(function () {
      node.classList.add('is-leaving');
      setTimeout(function () {
        if (node.parentNode) {
          node.parentNode.removeChild(node);
        }
      }, 260);
    }, opts.ms || 3200);
  };

  /* ---------- overlay stack ---------- */
  function pushOverlay(entry) {
    stack.push(entry);
    document.documentElement.classList.add('has-overlay');
  }

  function popOverlay(entry) {
    var i = stack.indexOf(entry);
    if (i >= 0) {
      stack.splice(i, 1);
    }
    if (!stack.length) {
      document.documentElement.classList.remove('has-overlay');
    }
  }

  function focusables(container) {
    return O.$$('a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])', container)
      .filter(function (node) {
        return node.offsetParent !== null;
      });
  }

  function trapTab(container, event) {
    if (event.key !== 'Tab') {
      return;
    }
    var items = focusables(container);
    if (!items.length) {
      event.preventDefault();
      return;
    }
    var first = items[0];
    var last = items[items.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }

  /* ---------- modal ---------- */
  O.modal = {
    open: function (cfg) {
      var previous = document.activeElement;
      var closed = false;
      var backdrop = O.el('div', { class: 'overlay overlay--modal' });
      var titleId = O.uid();

      var closeBtn = O.el('button', {
        class: 'icon-btn modal__x',
        type: 'button',
        'aria-label': O.t('c.close')
      }, [O.icon('close', 18)]);

      var head = O.el('div', { class: 'modal__head' }, [
        O.el('h2', { class: 'modal__title', id: titleId, text: cfg.title || '' }),
        closeBtn
      ]);

      var body = O.el('div', { class: 'modal__body' }, cfg.content);
      var foot = O.el('div', { class: 'modal__foot' });

      var dialog = O.el('div', {
        class: 'modal' + (cfg.size ? ' modal--' + cfg.size : ''),
        role: 'dialog',
        'aria-modal': 'true',
        'aria-labelledby': titleId
      }, [head, body, foot]);

      var api = {
        el: dialog,
        close: function () {
          if (closed) {
            return;
          }
          closed = true;
          popOverlay(entry);
          backdrop.classList.add('is-leaving');
          setTimeout(function () {
            if (backdrop.parentNode) {
              backdrop.parentNode.removeChild(backdrop);
            }
          }, O.animated() ? 200 : 0);
          if (previous && previous.focus) {
            try { previous.focus(); } catch (err) { /* ignore */ }
          }
          if (cfg.onClose) {
            cfg.onClose();
          }
        }
      };

      var entry = { close: api.close };

      (cfg.actions || []).forEach(function (action) {
        var btn = O.el('button', {
          class: 'btn btn--' + (action.kind || 'ghost'),
          type: 'button',
          text: action.label
        });
        btn.addEventListener('click', function () {
          var keep = action.onClick ? action.onClick(api) : undefined;
          if (keep !== false) {
            api.close();
          }
        });
        foot.appendChild(btn);
      });
      if (!(cfg.actions && cfg.actions.length)) {
        foot.hidden = true;
      }

      closeBtn.addEventListener('click', api.close);
      backdrop.addEventListener('pointerdown', function (event) {
        if (event.target === backdrop) {
          api.close();
        }
      });
      dialog.addEventListener('keydown', function (event) {
        trapTab(dialog, event);
      });

      backdrop.appendChild(dialog);
      overlayRoot.appendChild(backdrop);
      pushOverlay(entry);

      setTimeout(function () {
        var target = O.$('[data-autofocus]', dialog) || focusables(dialog)[0];
        if (target) {
          target.focus();
        }
      }, 30);

      return api;
    },

    confirm: function (cfg) {
      return new Promise(function (resolve) {
        O.modal.open({
          title: cfg.title,
          size: 'sm',
          content: O.el('p', { class: 'modal__text', text: cfg.message }),
          actions: [
            { label: cfg.cancelLabel || O.t('c.cancel'), kind: 'ghost', onClick: function () { resolve(false); } },
            { label: cfg.confirmLabel || O.t('c.ok'), kind: cfg.danger ? 'danger' : 'primary', onClick: function () { resolve(true); } }
          ],
          onClose: function () {
            resolve(false);
          }
        });
      });
    }
  };

  /* ---------- popup menu ---------- */
  O.menu = {
    close: function () {
      if (openMenu) {
        openMenu.close();
      }
    },
    open: function (anchor, items, opts) {
      O.menu.close();
      opts = opts || {};
      var menu = O.el('div', { class: 'menu', role: 'menu' });
      var closed = false;
      var scrim = null;

      var entry = {
        close: function () {
          if (closed) {
            return;
          }
          closed = true;
          openMenu = null;
          popOverlay(entry);
          document.removeEventListener('pointerdown', onOutside, true);
          menu.classList.add('is-leaving');
          setTimeout(function () {
            if (menu.parentNode) {
              menu.parentNode.removeChild(menu);
            }
          }, O.animated() ? 140 : 0);
          if (scrim) {
            scrim.classList.add('is-leaving');
            setTimeout(function () {
              if (scrim && scrim.parentNode) {
                scrim.parentNode.removeChild(scrim);
              }
            }, O.animated() ? 140 : 0);
          }
          if (anchor && anchor.focus) {
            try { anchor.focus(); } catch (err) { /* ignore */ }
          }
        }
      };

      function onOutside(event) {
        if (!menu.contains(event.target) && !(anchor && anchor.contains(event.target))) {
          entry.close();
        }
      }

      items.forEach(function (item) {
        if (item.separator) {
          menu.appendChild(O.el('div', { class: 'menu__sep', role: 'separator' }));
          return;
        }
        var row = O.el('button', {
          class: 'menu__item' + (item.kind ? ' menu__item--' + item.kind : '') + (item.checked ? ' is-checked' : ''),
          type: 'button',
          role: item.checked !== undefined ? 'menuitemradio' : 'menuitem',
          'aria-checked': item.checked === undefined ? null : (item.checked ? 'true' : 'false')
        }, [
          item.icon ? O.icon(item.icon, 18) : O.el('span', { class: 'menu__gap' }),
          O.el('span', { class: 'menu__label', text: item.label }),
          item.hint ? O.el('span', { class: 'menu__hint', text: item.hint }) : null,
          item.checked ? O.icon('check', 16) : null
        ]);
        row.addEventListener('click', function () {
          entry.close();
          if (item.onClick) {
            item.onClick();
          }
        });
        menu.appendChild(row);
      });

      menu.addEventListener('keydown', function (event) {
        var rows = O.$$('.menu__item', menu);
        var idx = rows.indexOf(document.activeElement);
        if (event.key === 'ArrowDown') {
          event.preventDefault();
          rows[(idx + 1) % rows.length].focus();
        } else if (event.key === 'ArrowUp') {
          event.preventDefault();
          rows[(idx - 1 + rows.length) % rows.length].focus();
        }
      });

      /* on phones a menu is a sheet that slides up from the bottom */
      var sheet = !!(O.mobile && O.mobile.isMobile());
      if (sheet) {
        scrim = O.el('div', { class: 'menu-scrim' });
        scrim.addEventListener('pointerdown', function () {
          entry.close();
        });
        overlayRoot.appendChild(scrim);
        menu.classList.add('menu--sheet');
      }
      overlayRoot.appendChild(menu);
      var rect = anchor.getBoundingClientRect();
      var width = menu.offsetWidth;
      var left = opts.align === 'left' ? rect.left : rect.right - width;
      left = O.clamp(left, 8, Math.max(8, window.innerWidth - width - 8));
      var top = rect.bottom + 8;
      var height = menu.offsetHeight;
      if (top + height > window.innerHeight - 8) {
        top = Math.max(8, rect.top - height - 8);
      }
      if (!sheet) {
        menu.style.left = left + 'px';
        menu.style.top = top + 'px';
      }

      openMenu = entry;
      pushOverlay(entry);
      document.addEventListener('pointerdown', onOutside, true);
      var first = O.$('.menu__item', menu);
      if (first) {
        first.focus();
      }
      return entry;
    }
  };

  O.ui = {
    init: function (overlays, toasts) {
      overlayRoot = overlays;
      toastRoot = toasts;
    },
    closeTop: function () {
      var top = stack[stack.length - 1];
      if (top) {
        top.close();
        return true;
      }
      return false;
    },
    hasOverlay: function () {
      return stack.length > 0;
    },
    overlayRoot: function () {
      return overlayRoot;
    },
    push: pushOverlay,
    pop: popOverlay
  };

  /* ---------- controls ---------- */

  /* options: [{ value, label, icon, title }] */
  O.segmented = function (options, value, onChange, label) {
    var wrap = O.el('div', { class: 'seg', role: 'radiogroup', 'aria-label': label || '' });
    var buttons = [];

    function paint(next) {
      buttons.forEach(function (btn) {
        var on = btn.dataset.value === String(next);
        btn.classList.toggle('is-on', on);
        btn.setAttribute('aria-checked', on ? 'true' : 'false');
        btn.tabIndex = on ? 0 : -1;
      });
    }

    options.forEach(function (opt) {
      var btn = O.el('button', {
        class: 'seg__btn',
        type: 'button',
        role: 'radio',
        title: opt.title || opt.label,
        data: { value: opt.value }
      }, [
        opt.icon ? O.icon(opt.icon, 16) : null,
        opt.label ? O.el('span', { text: opt.label }) : null
      ]);
      btn.addEventListener('click', function (event) {
        paint(opt.value);
        if (onChange) {
          onChange(opt.value, event);
        }
      });
      btn.addEventListener('keydown', function (event) {
        var i = buttons.indexOf(btn);
        var step = event.key === 'ArrowRight' || event.key === 'ArrowDown' ? 1 : (event.key === 'ArrowLeft' || event.key === 'ArrowUp' ? -1 : 0);
        if (step) {
          event.preventDefault();
          buttons[(i + step + buttons.length) % buttons.length].click();
          buttons[(i + step + buttons.length) % buttons.length].focus();
        }
      });
      buttons.push(btn);
      wrap.appendChild(btn);
    });

    paint(value);
    wrap.setValue = paint;
    return wrap;
  };

  O.switchEl = function (checked, onChange, label) {
    var btn = O.el('button', {
      class: 'switch' + (checked ? ' is-on' : ''),
      type: 'button',
      role: 'switch',
      'aria-checked': checked ? 'true' : 'false',
      'aria-label': label || ''
    }, [O.el('span', { class: 'switch__knob' })]);
    btn.addEventListener('click', function () {
      var next = !btn.classList.contains('is-on');
      btn.classList.toggle('is-on', next);
      btn.setAttribute('aria-checked', next ? 'true' : 'false');
      if (onChange) {
        onChange(next);
      }
    });
    return btn;
  };

  /* page header used by every internal page */
  O.pageHead = function (icon, title, sub, actions) {
    return O.el('header', { class: 'page__head' }, [
      O.el('div', { class: 'page__badge' }, [O.icon(icon, 22)]),
      O.el('div', { class: 'page__titles' }, [
        O.el('h1', { class: 'page__title', text: title }),
        sub ? O.el('p', { class: 'page__sub', text: sub }) : null
      ]),
      actions ? O.el('div', { class: 'page__actions' }, actions) : null
    ]);
  };

  O.emptyState = function (icon, title, text) {
    return O.el('div', { class: 'empty' }, [
      O.el('div', { class: 'empty__art' }, [O.icon(icon, 30)]),
      O.el('p', { class: 'empty__title', text: title }),
      text ? O.el('p', { class: 'empty__text', text: text }) : null
    ]);
  };

  /* monogram tile used for sites */
  O.monogram = function (name, hue, large) {
    var letter = String(name || '?').trim().charAt(0).toUpperCase() || '?';
    var node = O.el('span', { class: 'mono' + (large ? ' mono--lg' : ''), text: letter, 'aria-hidden': 'true' });
    node.style.setProperty('--h', String(hue));
    return node;
  };
})();
