/* Orbita search: resolves what you type (query, bang shortcut, or address), builds Google URLs, shows suggestions */
(function () {
  'use strict';
  var O = window.Orbita;
  var t = O.t;

  var ENGINES = {
    google: { name: 'Google', url: 'https://www.google.com/search?q=%s' },
    yandex: { name: 'Яндекс', url: 'https://yandex.com/search/?text=%s' },
    bing: { name: 'Bing', url: 'https://www.bing.com/search?q=%s' },
    duckduckgo: { name: 'DuckDuckGo', url: 'https://duckduckgo.com/?q=%s' },
    brave: { name: 'Brave', url: 'https://search.brave.com/search?q=%s' },
    youtube: { name: 'YouTube', url: 'https://www.youtube.com/results?search_query=%s' },
    wikipedia: { name: 'Wikipedia', url: 'https://%l.wikipedia.org/w/index.php?search=%s' },
    maps: { name: 'Maps', url: 'https://www.google.com/maps/search/%s' },
    github: { name: 'GitHub', url: 'https://github.com/search?q=%s' },
    translate: { name: 'Translate', url: 'https://translate.google.com/?sl=auto&tl=%l&text=%s&op=translate' },
    images: { name: 'Google Images', url: 'https://www.google.com/search?tbm=isch&q=%s' },
    news: { name: 'Google News', url: 'https://www.google.com/search?tbm=nws&q=%s' }
  };

  var CHOICES = ['google', 'yandex', 'bing', 'duckduckgo', 'brave'];

  var BANGS = {
    g: 'google',
    ya: 'yandex',
    bing: 'bing',
    ddg: 'duckduckgo',
    br: 'brave',
    yt: 'youtube',
    w: 'wikipedia',
    m: 'maps',
    gh: 'github',
    tr: 'translate',
    img: 'images',
    news: 'news'
  };

  function engineName(id) {
    return ENGINES[id] ? ENGINES[id].name : ENGINES.google.name;
  }

  function buildUrl(engineId, query) {
    var engine = ENGINES[engineId] || ENGINES.google;
    return engine.url
      .replace('%l', O.i18n.current())
      .replace('%s', encodeURIComponent(query));
  }

  function resolve(raw) {
    var text = String(raw || '').trim();
    var engineId = ENGINES[O.settings.get('engine')] ? O.settings.get('engine') : 'google';

    if (!text) {
      return { kind: 'site', url: 'https://www.google.com/', label: 'google.com', text: 'google.com', empty: true };
    }

    var aiBang = text.match(/^!ai\s+([\s\S]+)$/i);
    if (aiBang && O.ai) {
      var ai = O.ai.chosen();
      var question = aiBang[1].trim();
      return { kind: 'site', url: O.ai.askUrl(ai, question), label: ai.name, text: ai.name + ': ' + question };
    }

    var bang = text.match(/^!(\w+)\s+([\s\S]+)$/);
    if (bang && BANGS[bang[1].toLowerCase()]) {
      var id = BANGS[bang[1].toLowerCase()];
      var q = bang[2].trim();
      return { kind: 'search', engine: id, url: buildUrl(id, q), label: engineName(id), text: q };
    }

    if (O.url.looksLikeUrl(text)) {
      var url = O.url.normalize(text);
      if (url) {
        return { kind: 'site', url: url, label: O.url.host(url), text: O.url.host(url) };
      }
    }

    return { kind: 'search', engine: engineId, url: buildUrl(engineId, text), label: engineName(engineId), text: text };
  }

  /* link for a history entry: searches follow the engine chosen now, sites keep their address */
  function urlFor(item) {
    if (item.type === 'search') {
      return buildUrl(ENGINES[O.settings.get('engine')] ? O.settings.get('engine') : 'google', item.text);
    }
    return item.url || 'https://www.google.com/';
  }

  function log(result) {
    if (result.empty) {
      return;
    }
    O.history.add({ type: result.kind, text: result.text, url: result.url });
  }

  /* ---------- suggestions ---------- */
  function suggestionsFor(raw) {
    var text = String(raw || '').trim();
    var rows = [];
    var lower = text.toLowerCase();

    if (!text) {
      O.history.recent(5, 'search').forEach(function (item) {
        rows.push({
          kind: 'history',
          icon: 'clock',
          label: item.text,
          sub: t('search.recent'),
          url: urlFor(item),
          meta: { type: 'search', text: item.text, url: urlFor(item) }
        });
      });
      return rows;
    }

    if (/^![a-z]*$/i.test(text)) {
      Object.keys(BANGS).forEach(function (code) {
        if (('!' + code).indexOf(lower) === 0) {
          rows.push({
            kind: 'bang',
            icon: 'bolt',
            label: '!' + code,
            sub: engineName(BANGS[code]),
            fill: '!' + code + ' '
          });
        }
      });
      if (rows.length) {
        return rows.slice(0, 6);
      }
    }

    var action = resolve(text);
    rows.push({
      kind: 'action',
      icon: action.kind === 'site' ? 'globe' : 'search',
      label: action.kind === 'site' ? t('search.open', { host: action.label }) : t('search.in', { engine: action.label, text: action.text }),
      sub: '',
      url: action.url,
      meta: { type: action.kind, text: action.text, url: action.url },
      enter: true
    });

    var seen = {};
    seen[lower] = true;
    var added = 0;
    O.history.all().some(function (item) {
      if (item.type !== 'search') {
        return false;
      }
      var key = item.text.toLowerCase();
      if (seen[key] || key.indexOf(lower) < 0) {
        return false;
      }
      seen[key] = true;
      rows.push({
        kind: 'history',
        icon: 'clock',
        label: item.text,
        sub: t('search.recent'),
        url: urlFor(item),
        meta: { type: 'search', text: item.text, url: urlFor(item) }
      });
      added++;
      return added >= 4;
    });

    var sitesAdded = 0;
    O.sites.all().some(function (site) {
      var hay = (site.name + ' ' + O.url.host(site.url)).toLowerCase();
      if (hay.indexOf(lower) < 0) {
        return false;
      }
      rows.push({
        kind: 'site',
        icon: 'globe',
        label: site.name,
        sub: O.url.host(site.url),
        url: site.url,
        meta: { type: 'site', text: site.name, url: site.url },
        site: site
      });
      sitesAdded++;
      return sitesAdded >= 3;
    });

    return rows;
  }

  /* ---------- search box factory ---------- */
  function create(cfg) {
    var input = cfg.input;
    var go = cfg.go;
    var box = cfg.dropdown;
    var rows = [];
    var active = -1;

    input.setAttribute('role', 'combobox');
    input.setAttribute('aria-autocomplete', 'list');
    input.setAttribute('aria-expanded', 'false');
    if (box.id) {
      input.setAttribute('aria-controls', box.id);
    }

    function syncGo() {
      go.href = resolve(input.value).url;
    }

    function close() {
      box.hidden = true;
      active = -1;
      input.setAttribute('aria-expanded', 'false');
    }

    function setActive(i) {
      active = i;
      rows.forEach(function (row, idx) {
        row.classList.toggle('is-active', idx === i);
        row.setAttribute('aria-selected', idx === i ? 'true' : 'false');
      });
      if (rows[i] && rows[i].scrollIntoView) {
        rows[i].scrollIntoView({ block: 'nearest' });
      }
    }

    function buildRow(item) {
      var inner = [
        O.el('span', { class: 'suggest__icon' }, [O.icon(item.icon, 18)]),
        O.el('span', { class: 'suggest__label', text: item.label }),
        item.sub ? O.el('span', { class: 'suggest__sub', text: item.sub }) : null,
        item.enter ? O.el('kbd', { class: 'suggest__key', text: '↵' }) : null
      ];
      var el;
      if (item.fill) {
        el = O.el('button', { class: 'suggest__row', type: 'button', role: 'option' }, inner);
        el.addEventListener('click', function () {
          input.value = item.fill;
          input.focus();
          syncGo();
          render();
        });
        return el;
      }
      el = O.el('a', { class: 'suggest__row', role: 'option' }, inner);
      O.link(el, item.url, item.meta);
      el.addEventListener('click', function () {
        close();
      });
      return el;
    }

    function render() {
      var items = suggestionsFor(input.value);
      O.clear(box);
      rows = [];
      if (!items.length) {
        close();
        return;
      }
      items.forEach(function (item) {
        var el = buildRow(item);
        el.addEventListener('pointermove', function () {
          var idx = rows.indexOf(el);
          if (idx !== active) {
            setActive(idx);
          }
        });
        rows.push(el);
        box.appendChild(el);
      });
      box.hidden = false;
      input.setAttribute('aria-expanded', 'true');
      setActive(-1);
    }

    function onInput() {
      syncGo();
      render();
    }

    function onKey(event) {
      if (event.key === 'ArrowDown') {
        event.preventDefault();
        if (box.hidden) {
          render();
        }
        if (rows.length) {
          setActive((active + 1) % rows.length);
        }
      } else if (event.key === 'ArrowUp') {
        event.preventDefault();
        if (rows.length) {
          setActive((active - 1 + rows.length) % rows.length);
        }
      } else if (event.key === 'Enter') {
        event.preventDefault();
        if (active >= 0 && rows[active]) {
          rows[active].click();
        } else {
          go.click();
        }
      } else if (event.key === 'Escape') {
        if (!box.hidden) {
          event.stopPropagation();
          close();
        }
      } else if (event.key === 'Tab') {
        close();
      }
    }

    function onGo() {
      var result = resolve(input.value);
      go.href = result.url;
      log(result);
      close();
    }

    function onOutside(event) {
      if (!box.contains(event.target) && event.target !== input && !input.contains(event.target)) {
        close();
      }
    }

    input.addEventListener('input', onInput);
    input.addEventListener('focus', render);
    input.addEventListener('keydown', onKey);
    go.addEventListener('click', onGo);
    document.addEventListener('pointerdown', onOutside);
    var offEngine = O.on('settings:engine', function () {
      syncGo();
      if (!box.hidden) {
        render();
      }
    });
    syncGo();

    return {
      refresh: render,
      close: close,
      focus: function () {
        input.focus();
        input.select();
      },
      destroy: function () {
        document.removeEventListener('pointerdown', onOutside);
        offEngine();
      }
    };
  }

  O.search = {
    engines: ENGINES,
    choices: CHOICES,
    bangs: BANGS,
    engineName: engineName,
    buildUrl: buildUrl,
    urlFor: urlFor,
    resolve: resolve,
    create: create,

    /* run a query from code (palette, shortcuts); must be called inside a user gesture */
    go: function (text) {
      var result = resolve(text);
      log(result);
      O.open(result.url);
    },

    pickEngine: function (anchor) {
      var current = O.settings.get('engine');
      O.menu.open(anchor, CHOICES.map(function (id) {
        return {
          label: ENGINES[id].name,
          checked: id === current,
          onClick: function () {
            O.settings.set('engine', id);
          }
        };
      }), { align: 'left' });
    }
  };
})();
