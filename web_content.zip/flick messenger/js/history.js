/* Orbita history: what was searched and which sites were opened, plus the History page */
(function () {
  'use strict';
  var O = window.Orbita;
  var t = O.t;

  var MAX_ITEMS = 1500;
  var PAGE_SIZE = 40;

  var items = O.store.get('history', []);
  if (!Array.isArray(items)) {
    items = [];
  }

  function save() {
    O.store.set('history', items);
  }

  function startOfDay(ts) {
    var d = new Date(ts);
    return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  }

  /* ---------- data API ---------- */
  O.history = {
    add: function (entry) {
      if (!O.settings.get('saveHistory')) {
        return null;
      }
      var text = String(entry.text || '').trim();
      if (!text) {
        return null;
      }
      var type = entry.type === 'site' ? 'site' : 'search';
      var now = Date.now();
      var last = items[0];
      if (last && last.text === text && last.type === type && now - last.ts < 8000) {
        return last;
      }
      var record = { id: O.uid(), type: type, text: text, url: entry.url || '', ts: now };
      items.unshift(record);
      if (items.length > MAX_ITEMS) {
        items.length = MAX_ITEMS;
      }
      save();
      O.emit('history', record);
      return record;
    },
    all: function () {
      return items.slice();
    },
    get: function (id) {
      for (var i = 0; i < items.length; i++) {
        if (items[i].id === id) {
          return items[i];
        }
      }
      return null;
    },
    remove: function (id) {
      var before = items.length;
      items = items.filter(function (item) {
        return item.id !== id;
      });
      if (items.length !== before) {
        save();
        O.emit('history');
      }
    },
    clear: function () {
      items = [];
      save();
      O.emit('history');
    },
    replaceAll: function (list) {
      items = Array.isArray(list) ? list.filter(function (x) {
        return x && typeof x.text === 'string' && typeof x.ts === 'number';
      }).slice(0, MAX_ITEMS) : [];
      save();
      O.emit('history');
    },
    recent: function (count, type) {
      var out = [];
      for (var i = 0; i < items.length && out.length < count; i++) {
        if (!type || items[i].type === type) {
          out.push(items[i]);
        }
      }
      return out;
    },
    stats: function () {
      var today0 = startOfDay(Date.now());
      var res = {
        total: items.length,
        searches: 0,
        sites: 0,
        todaySearches: 0,
        todaySites: 0,
        topQueries: [],
        topSites: [],
        hours: []
      };
      var q = {};
      var s = {};
      var i;
      for (i = 0; i < 24; i++) {
        res.hours.push(0);
      }
      items.forEach(function (item) {
        var isToday = item.ts >= today0;
        if (item.type === 'search') {
          res.searches++;
          if (isToday) {
            res.todaySearches++;
          }
          var key = item.text.toLowerCase();
          q[key] = q[key] || { text: item.text, count: 0 };
          q[key].count++;
        } else {
          res.sites++;
          if (isToday) {
            res.todaySites++;
          }
          var host = O.url.host(item.url || item.text);
          s[host] = s[host] || { text: host, count: 0 };
          s[host].count++;
        }
        res.hours[new Date(item.ts).getHours()]++;
      });
      function top(map) {
        return Object.keys(map).map(function (k) {
          return map[k];
        }).sort(function (a, b) {
          return b.count - a.count;
        }).slice(0, 5);
      }
      res.topQueries = top(q);
      res.topSites = top(s);
      return res;
    }
  };

  /* ---------- History page ---------- */
  function iconFor(type) {
    return type === 'site' ? 'globe' : 'search';
  }

  function buildPage(root) {
    var filter = 'all';
    var query = '';
    var limit = PAGE_SIZE;

    var page = O.el('div', { class: 'page page--history' });
    var statsBox = O.el('section', { class: 'insights' });
    var listBox = O.el('section', { class: 'hlist' });
    var moreBox = O.el('div', { class: 'hmore' });

    var clearBtn = O.el('button', { class: 'btn btn--danger-ghost', type: 'button' }, [
      O.icon('trash', 16),
      O.el('span', { text: t('h.clear') })
    ]);
    clearBtn.addEventListener('click', function () {
      if (!items.length) {
        return;
      }
      O.modal.confirm({
        title: t('h.clear'),
        message: t('h.clear.confirm'),
        confirmLabel: t('h.clear.yes'),
        danger: true
      }).then(function (yes) {
        if (yes) {
          O.history.clear();
          O.toast(t('h.cleared'), { kind: 'good' });
        }
      });
    });

    page.appendChild(O.pageHead('history', t('h.title'), t('h.sub'), [clearBtn]));
    page.appendChild(statsBox);

    var finder = O.el('input', {
      class: 'field__input',
      type: 'search',
      placeholder: t('h.find'),
      'aria-label': t('h.find'),
      autocomplete: 'off',
      id: 'history-find'
    });
    finder.addEventListener('input', O.debounce(function () {
      query = finder.value.trim().toLowerCase();
      limit = PAGE_SIZE;
      renderList();
    }, 120));

    var seg = O.segmented([
      { value: 'all', label: t('h.filter.all') },
      { value: 'search', label: t('h.filter.search'), icon: 'search' },
      { value: 'site', label: t('h.filter.site'), icon: 'globe' }
    ], filter, function (value) {
      filter = value;
      limit = PAGE_SIZE;
      renderList();
    }, t('h.title'));

    page.appendChild(O.el('div', { class: 'hbar' }, [
      O.el('label', { class: 'field field--search', for: 'history-find' }, [O.icon('search', 18), finder]),
      seg
    ]));
    page.appendChild(listBox);
    page.appendChild(moreBox);
    root.appendChild(page);

    /* ----- insights ----- */
    function statCard(label, value, icon) {
      var num = O.el('strong', { class: 'stat__num', text: '0' });
      O.countTo(num, value, 700, function (v) {
        return O.fmt.number(Math.round(v), 0);
      });
      return O.el('div', { class: 'stat spot' }, [
        O.el('span', { class: 'stat__icon' }, [O.icon(icon, 18)]),
        num,
        O.el('span', { class: 'stat__label', text: label })
      ]);
    }

    function barList(title, rows, empty) {
      var box = O.el('div', { class: 'bars' }, [O.el('h3', { class: 'bars__title', text: title })]);
      if (!rows.length) {
        box.appendChild(O.el('p', { class: 'bars__empty', text: empty }));
        return box;
      }
      var max = rows[0].count;
      rows.forEach(function (row, i) {
        var fill = O.el('span', { class: 'bars__fill' });
        fill.style.setProperty('--w', Math.max(6, Math.round((row.count / max) * 100)) + '%');
        fill.style.setProperty('--d', (i * 70) + 'ms');
        box.appendChild(O.el('div', { class: 'bars__row' }, [
          O.el('span', { class: 'bars__name', text: row.text, title: row.text }),
          O.el('span', { class: 'bars__track' }, [fill]),
          O.el('span', { class: 'bars__count', text: String(row.count) })
        ]));
      });
      return box;
    }

    function hoursChart(hours) {
      var max = Math.max.apply(null, hours.concat([1]));
      var chart = O.el('div', { class: 'hours' }, [O.el('h3', { class: 'bars__title', text: t('h.hours') })]);
      var cols = O.el('div', { class: 'hours__cols' });
      hours.forEach(function (n, hour) {
        var col = O.el('span', { class: 'hours__col', title: O.pad2(hour) + ':00  ' + n });
        col.style.setProperty('--h', Math.max(n ? 8 : 3, Math.round((n / max) * 100)) + '%');
        col.style.setProperty('--d', (hour * 22) + 'ms');
        if (n) {
          col.classList.add('has');
        }
        cols.appendChild(col);
      });
      chart.appendChild(cols);
      chart.appendChild(O.el('div', { class: 'hours__axis' }, [
        O.el('span', { text: '00' }),
        O.el('span', { text: '06' }),
        O.el('span', { text: '12' }),
        O.el('span', { text: '18' }),
        O.el('span', { text: '23' })
      ]));
      return chart;
    }

    function renderStats() {
      O.clear(statsBox);
      var st = O.history.stats();
      statsBox.appendChild(O.el('div', { class: 'stats' }, [
        statCard(t('h.stat.total'), st.total, 'history'),
        statCard(t('h.stat.searches'), st.searches, 'search'),
        statCard(t('h.stat.sites'), st.sites, 'globe'),
        statCard(t('h.stat.today'), st.todaySearches + st.todaySites, 'bolt')
      ]));
      statsBox.appendChild(O.el('div', { class: 'insights__grid' }, [
        barList(t('h.top.queries'), st.topQueries, t('h.nothing')),
        barList(t('h.top.sites'), st.topSites, t('h.nothing')),
        hoursChart(st.hours)
      ]));
    }

    /* ----- list ----- */
    function matches(item) {
      if (filter !== 'all' && item.type !== filter) {
        return false;
      }
      if (query) {
        var hay = (item.text + ' ' + (item.url || '')).toLowerCase();
        return hay.indexOf(query) >= 0;
      }
      return true;
    }

    function row(item) {
      var open = O.el('a', { class: 'icon-btn', 'aria-label': t('h.open'), title: t('h.open') }, [O.icon('external', 16)]);
      O.link(open, O.search.urlFor(item), { type: item.type, text: item.text, url: O.search.urlFor(item) });

      var copy = O.el('button', { class: 'icon-btn', type: 'button', 'aria-label': t('h.copy'), title: t('h.copy') }, [O.icon('copy', 16)]);
      copy.addEventListener('click', function () {
        O.copy(item.text).then(function (ok) {
          O.toast(ok ? t('h.copied') : t('h.copyFail'), { kind: ok ? 'good' : 'warn' });
        });
      });

      var del = O.el('button', { class: 'icon-btn icon-btn--danger', type: 'button', 'aria-label': t('h.delete'), title: t('h.delete') }, [O.icon('trash', 16)]);
      del.addEventListener('click', function () {
        O.history.remove(item.id);
      });

      var meta = item.type === 'site' ? O.url.host(item.url || item.text) : t('h.kind.search');
      return O.el('div', { class: 'hrow ' + 'hrow--' + item.type }, [
        O.el('span', { class: 'hrow__icon' }, [O.icon(iconFor(item.type), 18)]),
        O.el('div', { class: 'hrow__main' }, [
          O.el('span', { class: 'hrow__text', text: item.text }),
          O.el('span', { class: 'hrow__meta', text: meta + ' · ' + O.fmt.time(item.ts) })
        ]),
        O.el('div', { class: 'hrow__actions' }, [open, copy, del])
      ]);
    }

    function renderList() {
      O.clear(listBox);
      O.clear(moreBox);
      var all = items.filter(matches);
      if (!all.length) {
        listBox.appendChild(O.emptyState('history', t('h.empty'), items.length ? t('h.empty.filtered') : t('h.empty.sub')));
        return;
      }
      var shown = all.slice(0, limit);
      var groups = [];
      var current = null;
      shown.forEach(function (item) {
        var key = O.fmt.dayKey(item.ts);
        if (!current || current.key !== key) {
          current = { key: key, ts: item.ts, rows: [] };
          groups.push(current);
        }
        current.rows.push(item);
      });
      groups.forEach(function (group) {
        var block = O.el('div', { class: 'hgroup' }, [
          O.el('h3', { class: 'hgroup__title' }, [
            O.el('span', { text: O.fmt.dayLabel(group.ts) }),
            O.el('small', { text: String(group.rows.length) })
          ])
        ]);
        group.rows.forEach(function (item) {
          block.appendChild(row(item));
        });
        listBox.appendChild(block);
      });
      O.stagger(listBox, '.hrow');
      if (all.length > shown.length) {
        var more = O.el('button', { class: 'btn btn--ghost', type: 'button', text: t('h.more', { n: all.length - shown.length }) });
        more.addEventListener('click', function () {
          limit += PAGE_SIZE;
          renderList();
        });
        moreBox.appendChild(more);
      }
    }

    renderStats();
    renderList();

    var off = O.on('history', function () {
      renderStats();
      renderList();
    });
    return function () {
      off();
    };
  }

  O.registerPage('history', {
    icon: 'history',
    titleKey: 'tab.history',
    singleton: true,
    build: buildPage
  });
})();
