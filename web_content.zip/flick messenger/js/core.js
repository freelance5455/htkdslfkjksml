/* Orbita core: storage, events, DOM helpers, URL helpers */
(function () {
  'use strict';
  var O = window.Orbita = window.Orbita || {};
  var has = Object.prototype.hasOwnProperty;

  /* ---------- page registry ---------- */
  O.pages = {};
  O.registerPage = function (type, def) {
    O.pages[type] = def;
  };

  /* ---------- storage (localStorage with an in-memory fallback) ---------- */
  var PREFIX = 'orbita:';
  var memory = {};

  O.store = {
    keys: ['settings', 'sites', 'history', 'tabs', 'notes', 'todos', 'pomodoro', 'calc', 'icons', 'reading', 'wallpaper', 'tools2', 'vpn'],
    get: function (key, fallback) {
      try {
        var raw = window.localStorage.getItem(PREFIX + key);
        if (raw !== null) {
          return JSON.parse(raw);
        }
      } catch (err) {
        /* storage blocked or corrupted: fall through to memory */
      }
      return has.call(memory, key) ? memory[key] : fallback;
    },
    set: function (key, value) {
      memory[key] = value;
      try {
        window.localStorage.setItem(PREFIX + key, JSON.stringify(value));
      } catch (err) {
        /* quota or blocked: memory copy keeps the session working */
      }
    },
    remove: function (key) {
      delete memory[key];
      try {
        window.localStorage.removeItem(PREFIX + key);
      } catch (err) { /* ignore */ }
    }
  };

  /* ---------- tiny event bus ---------- */
  var handlers = {};

  O.on = function (name, fn) {
    if (!handlers[name]) {
      handlers[name] = [];
    }
    handlers[name].push(fn);
    return function () {
      O.off(name, fn);
    };
  };

  O.off = function (name, fn) {
    var list = handlers[name];
    if (!list) {
      return;
    }
    var i = list.indexOf(fn);
    if (i >= 0) {
      list.splice(i, 1);
    }
  };

  O.emit = function (name, payload) {
    var list = handlers[name];
    if (!list) {
      return;
    }
    list.slice().forEach(function (fn) {
      try {
        fn(payload);
      } catch (err) {
        if (window.console) {
          console.error('[orbita] handler for "' + name + '" failed', err);
        }
      }
    });
  };

  /* ---------- DOM helpers ---------- */
  O.$ = function (selector, root) {
    return (root || document).querySelector(selector);
  };

  O.$$ = function (selector, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(selector));
  };

  function appendKids(node, kids) {
    if (kids === undefined || kids === null || kids === false) {
      return;
    }
    if (Array.isArray(kids)) {
      kids.forEach(function (kid) {
        appendKids(node, kid);
      });
      return;
    }
    if (typeof kids === 'string' || typeof kids === 'number') {
      node.appendChild(document.createTextNode(String(kids)));
      return;
    }
    node.appendChild(kids);
  }

  /* O.el('div', { class: 'x', text: 'hi', on: { click: fn }, data: { id: 1 } }, [children]) */
  O.el = function (tag, props, kids) {
    var node = document.createElement(tag);
    props = props || {};
    Object.keys(props).forEach(function (key) {
      var val = props[key];
      if (val === undefined || val === null || val === false) {
        return;
      }
      if (key === 'class') {
        node.className = val;
      } else if (key === 'text') {
        node.textContent = val;
      } else if (key === 'html') {
        node.innerHTML = val;
      } else if (key === 'style') {
        node.style.cssText = val;
      } else if (key === 'data') {
        Object.keys(val).forEach(function (d) {
          node.dataset[d] = val[d];
        });
      } else if (key === 'on') {
        Object.keys(val).forEach(function (evt) {
          node.addEventListener(evt, val[evt]);
        });
      } else if (key === 'value' || key === 'checked' || key === 'disabled' || key === 'hidden' || key === 'selected') {
        node[key] = val;
      } else {
        node.setAttribute(key, val === true ? '' : val);
      }
    });
    appendKids(node, kids);
    return node;
  };

  O.clear = function (node) {
    while (node.firstChild) {
      node.removeChild(node.firstChild);
    }
    return node;
  };

  O.vars = function (node, map) {
    Object.keys(map).forEach(function (name) {
      node.style.setProperty(name, map[name]);
    });
    return node;
  };

  O.run = function (fn) {
    try {
      if (typeof fn === 'function') {
        fn();
      }
    } catch (err) { /* disposers must never break teardown */ }
  };

  O.uid = function () {
    return 'o' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  };

  O.pad2 = function (n) {
    return (n < 10 ? '0' : '') + n;
  };

  O.clamp = function (v, lo, hi) {
    return Math.min(hi, Math.max(lo, v));
  };

  O.debounce = function (fn, ms) {
    var timer = null;
    return function () {
      var args = arguments;
      var self = this;
      clearTimeout(timer);
      timer = setTimeout(function () {
        fn.apply(self, args);
      }, ms);
    };
  };

  /* ---------- motion ---------- */
  O.motionLevel = function () {
    return document.documentElement.getAttribute('data-motion') || 'full';
  };

  O.animated = function () {
    return O.motionLevel() !== 'off';
  };

  /* give each child a --i index so CSS can stagger its entrance */
  O.stagger = function (container, selector) {
    var kids = selector ? O.$$(selector, container) : Array.prototype.slice.call(container.children);
    kids.forEach(function (kid, i) {
      kid.style.setProperty('--i', i);
    });
  };

  O.countTo = function (node, target, ms, format) {
    var fmt = format || function (v) { return String(Math.round(v)); };
    if (!O.animated() || !window.requestAnimationFrame) {
      node.textContent = fmt(target);
      return;
    }
    var from = 0;
    var start = null;
    var dur = ms || 700;
    function frame(now) {
      if (start === null) {
        start = now;
      }
      var p = Math.min(1, (now - start) / dur);
      var eased = 1 - Math.pow(1 - p, 3);
      node.textContent = fmt(from + (target - from) * eased);
      if (p < 1 && node.isConnected) {
        requestAnimationFrame(frame);
      } else {
        node.textContent = fmt(target);
      }
    }
    requestAnimationFrame(frame);
  };

  /* ---------- URLs ---------- */
  O.url = {
    host: function (value) {
      try {
        return new URL(value).hostname.replace(/^www\./, '');
      } catch (err) {
        return String(value || '');
      }
    },
    looksLikeUrl: function (value) {
      var s = String(value || '').trim();
      if (!s || /\s/.test(s)) {
        return false;
      }
      if (/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) {
        return true;
      }
      if (/^localhost(:\d+)?([\/?#]|$)/i.test(s)) {
        return true;
      }
      if (/^\d{1,3}(\.\d{1,3}){3}(:\d+)?([\/?#]|$)/.test(s)) {
        return true;
      }
      return /^[^\s\/@]+\.[a-zа-яёіїєґ]{2,}(:\d+)?([\/?#]\S*)?$/i.test(s);
    },
    normalize: function (value) {
      var s = String(value || '').trim();
      if (!s) {
        return null;
      }
      if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) {
        s = 'https://' + s;
      }
      try {
        var u = new URL(s);
        if (u.protocol !== 'http:' && u.protocol !== 'https:') {
          return null;
        }
        if (!u.hostname || (u.hostname.indexOf('.') < 0 && u.hostname !== 'localhost')) {
          return null;
        }
        return u.href;
      } catch (err) {
        return null;
      }
    }
  };

  /* open a URL in a new browser tab (must run inside a user gesture) */
  O.open = function (url) {
    var a = document.createElement('a');
    a.href = url;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  /* turn an anchor into an external link that is written to history on click */
  O.link = function (a, url, meta) {
    a.href = url;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    if (meta) {
      a.addEventListener('click', function () {
        if (O.history) {
          O.history.add({ type: meta.type, text: meta.text, url: meta.url || url });
        }
      });
    }
    return a;
  };

  /* ---------- clipboard ---------- */
  function fallbackCopy(text) {
    var area = document.createElement('textarea');
    area.value = text;
    area.setAttribute('readonly', '');
    area.style.cssText = 'position:fixed;top:0;left:0;opacity:0;pointer-events:none;';
    document.body.appendChild(area);
    area.select();
    var ok = false;
    try {
      ok = document.execCommand('copy');
    } catch (err) {
      ok = false;
    }
    document.body.removeChild(area);
    return ok;
  }

  O.copy = function (text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).then(function () {
        return true;
      }, function () {
        return fallbackCopy(text);
      });
    }
    return Promise.resolve(fallbackCopy(text));
  };
})();
