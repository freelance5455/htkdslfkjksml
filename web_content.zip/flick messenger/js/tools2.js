/* Orbita extra tools: color converter, text counter, world clock, countdown, random, percent */
(function () {
  'use strict';
  var O = window.Orbita;
  var t = O.t;

  O.toolExtras = O.toolExtras || [];

  function saved() {
    var data = O.store.get('tools2', {});
    return data && typeof data === 'object' ? data : {};
  }

  function put(key, value) {
    var data = saved();
    data[key] = value;
    O.store.set('tools2', data);
  }

  function copyBtn(getText) {
    var btn = O.el('button', { class: 'icon-btn icon-btn--sm', type: 'button', title: t('h.copy'), 'aria-label': t('h.copy') }, [O.icon('copy', 16)]);
    btn.addEventListener('click', function () {
      O.copy(getText()).then(function (ok) {
        O.toast(ok ? t('h.copied') : t('h.copyFail'), { kind: ok ? 'good' : 'bad', icon: 'copy' });
      });
    });
    return btn;
  }

  function field(label, input) {
    return O.el('label', { class: 'fld' }, [O.el('span', { class: 'fld__label', text: label }), input]);
  }

  /* ================= color ================= */
  function hexToRgb(hex) {
    var m = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(String(hex).trim());
    if (!m) {
      return null;
    }
    var h = m[1];
    if (h.length === 3) {
      h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
    }
    return { r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16) };
  }

  function rgbToHex(c) {
    return '#' + [c.r, c.g, c.b].map(function (v) {
      return ('0' + Math.round(v).toString(16)).slice(-2);
    }).join('');
  }

  function rgbToHsl(c) {
    var r = c.r / 255;
    var g = c.g / 255;
    var b = c.b / 255;
    var max = Math.max(r, g, b);
    var min = Math.min(r, g, b);
    var l = (max + min) / 2;
    var h = 0;
    var s = 0;
    if (max !== min) {
      var d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      if (max === r) {
        h = (g - b) / d + (g < b ? 6 : 0);
      } else if (max === g) {
        h = (b - r) / d + 2;
      } else {
        h = (r - g) / d + 4;
      }
      h *= 60;
    }
    return { h: Math.round(h), s: Math.round(s * 100), l: Math.round(l * 100) };
  }

  function luminance(c) {
    var parts = [c.r, c.g, c.b].map(function (v) {
      var x = v / 255;
      return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * parts[0] + 0.7152 * parts[1] + 0.0722 * parts[2];
  }

  function contrast(a, b) {
    var l1 = luminance(a);
    var l2 = luminance(b);
    return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
  }

  function colorTool(card) {
    var start = saved().color || '#3b4cf0';
    var picker = O.el('input', { type: 'color', class: 'clr__picker', value: start, 'aria-label': t('tool.color') });
    var hexInput = O.el('input', { class: 'field__input', type: 'text', value: start, maxlength: '7', spellcheck: 'false', autocapitalize: 'off', 'aria-label': 'HEX' });
    var swatch = O.el('div', { class: 'clr__swatch' });
    var rows = O.el('div', { class: 'clr__rows' });
    var ratio = O.el('p', { class: 'clr__ratio' });
    var current = hexToRgb(start);

    function line(label, getText) {
      var value = O.el('output', { class: 'clr__value' });
      rows.appendChild(O.el('div', { class: 'clr__row' }, [
        O.el('span', { class: 'clr__key', text: label }),
        value,
        copyBtn(function () { return value.textContent; })
      ]));
      return function () { value.textContent = getText(); };
    }

    var paints = [
      line('HEX', function () { return rgbToHex(current).toUpperCase(); }),
      line('RGB', function () { return 'rgb(' + current.r + ', ' + current.g + ', ' + current.b + ')'; }),
      line('HSL', function () {
        var h = rgbToHsl(current);
        return 'hsl(' + h.h + ', ' + h.s + '%, ' + h.l + '%)';
      })
    ];

    function paint(fromText) {
      swatch.style.background = rgbToHex(current);
      paints.forEach(function (fn) { fn(); });
      var w = contrast(current, { r: 255, g: 255, b: 255 });
      var k = contrast(current, { r: 0, g: 0, b: 0 });
      ratio.textContent = t('tool.color.contrast') + ': ' + w.toFixed(1) + ' : 1 / ' + k.toFixed(1) + ' : 1';
      if (!fromText) {
        hexInput.value = rgbToHex(current);
      }
      picker.value = rgbToHex(current);
      put('color', rgbToHex(current));
    }

    picker.addEventListener('input', function () {
      current = hexToRgb(picker.value) || current;
      paint(false);
    });
    hexInput.addEventListener('input', function () {
      var rgb = hexToRgb(hexInput.value);
      hexInput.setAttribute('aria-invalid', rgb ? 'false' : 'true');
      if (rgb) {
        current = rgb;
        paint(true);
      }
    });
    var random = O.el('button', { class: 'btn btn--ghost', type: 'button' }, [O.icon('swap', 16), O.el('span', { text: t('tool.color.random') })]);
    random.addEventListener('click', function () {
      current = { r: Math.floor(Math.random() * 256), g: Math.floor(Math.random() * 256), b: Math.floor(Math.random() * 256) };
      paint(false);
    });
    paint(false);
    return card('palette', t('tool.color'), [
      O.el('div', { class: 'clr__top' }, [picker, hexInput, random]),
      swatch,
      rows,
      ratio
    ]);
  }

  /* ================= text counter ================= */
  function textTool(card) {
    var area = O.el('textarea', { class: 'field__area txt__area', rows: '5', placeholder: t('tool.text.ph'), 'aria-label': t('tool.text'), spellcheck: 'false' });
    area.value = saved().text || '';
    var stats = O.el('dl', { class: 'txt__stats' });

    function stat(key) {
      var dd = O.el('dd', { text: '0' });
      stats.appendChild(O.el('div', { class: 'txt__stat' }, [O.el('dt', { text: t(key) }), dd]));
      return dd;
    }
    var cChars = stat('tool.text.chars');
    var cNoSp = stat('tool.text.nospace');
    var cWords = stat('tool.text.words');
    var cSent = stat('tool.text.sentences');
    var cLines = stat('tool.text.lines');
    var cRead = stat('tool.text.read');

    var save = O.debounce(function () {
      put('text', area.value.slice(0, 20000));
    }, 400);

    function paint() {
      var v = area.value;
      var words = v.trim() ? v.trim().split(/\s+/).length : 0;
      var sentences = (v.match(/[^.!?…]+[.!?…]+|[^.!?…]+$/g) || []).filter(function (s) { return /\S/.test(s); }).length;
      cChars.textContent = String(v.length);
      cNoSp.textContent = String(v.replace(/\s/g, '').length);
      cWords.textContent = String(words);
      cSent.textContent = String(sentences);
      cLines.textContent = String(v ? v.split(/\n/).length : 0);
      var mins = words / 200;
      cRead.textContent = words ? (mins < 1 ? '< 1 ' : Math.round(mins) + ' ') + t('tool.text.min') : '0';
      save();
    }
    area.addEventListener('input', paint);

    function action(label, fn) {
      var b = O.el('button', { class: 'btn btn--ghost btn--sm', type: 'button', text: label });
      b.addEventListener('click', function () {
        area.value = fn(area.value);
        paint();
      });
      return b;
    }
    var buttons = O.el('div', { class: 'txt__acts' }, [
      action('AA', function (v) { return v.toUpperCase(); }),
      action('aa', function (v) { return v.toLowerCase(); }),
      action('Aa', function (v) {
        return v.toLowerCase().replace(/(^|[\s\-"(«])(\S)/g, function (m, a, b) { return a + b.toUpperCase(); });
      }),
      action(t('tool.text.trim'), function (v) { return v.replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim(); }),
      action(t('tool.text.clear'), function () { return ''; })
    ]);
    buttons.appendChild(copyBtn(function () { return area.value; }));
    paint();
    return card('type', t('tool.text'), [area, stats, buttons]);
  }

  /* ================= world clock ================= */
  var ZONES = [
    ['Europe/Kyiv', 'Kyiv'], ['Europe/London', 'London'], ['Europe/Berlin', 'Berlin'], ['Europe/Warsaw', 'Warsaw'],
    ['America/New_York', 'New York'], ['America/Los_Angeles', 'Los Angeles'], ['America/Sao_Paulo', 'São Paulo'],
    ['Asia/Dubai', 'Dubai'], ['Asia/Kolkata', 'Delhi'], ['Asia/Tokyo', 'Tokyo'], ['Asia/Shanghai', 'Shanghai'],
    ['Australia/Sydney', 'Sydney'], ['Pacific/Auckland', 'Auckland'], ['Africa/Cairo', 'Cairo']
  ];

  function zoneOk(id) {
    try {
      new Intl.DateTimeFormat('en', { timeZone: id });
      return true;
    } catch (err) {
      return false;
    }
  }

  function zoneOffsetMin(id, at) {
    var parts = new Intl.DateTimeFormat('en-US', {
      timeZone: id, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric'
    }).formatToParts(at);
    var map = {};
    parts.forEach(function (p) { map[p.type] = parseInt(p.value, 10); });
    var asUtc = Date.UTC(map.year, map.month - 1, map.day, map.hour, map.minute, map.second);
    return Math.round((asUtc - Math.floor(at.getTime() / 1000) * 1000) / 60000);
  }

  function worldTool(card) {
    var chosen = saved().zones;
    if (!Array.isArray(chosen) || !chosen.length) {
      chosen = ['Europe/Kyiv', 'Europe/London', 'America/New_York', 'Asia/Tokyo'];
    }
    chosen = chosen.filter(zoneOk);
    var list = O.el('ul', { class: 'wc__list' });
    var select = O.el('select', { class: 'field__select', 'aria-label': t('tool.world.add') });
    var timer = null;

    function label(id) {
      for (var i = 0; i < ZONES.length; i++) {
        if (ZONES[i][0] === id) {
          return ZONES[i][1];
        }
      }
      return id.split('/').pop().replace(/_/g, ' ');
    }

    function fillSelect() {
      O.clear(select);
      select.appendChild(O.el('option', { value: '', text: t('tool.world.add') }));
      ZONES.forEach(function (z) {
        if (chosen.indexOf(z[0]) < 0 && zoneOk(z[0])) {
          select.appendChild(O.el('option', { value: z[0], text: z[1] }));
        }
      });
    }

    function tick() {
      var now = new Date();
      var here = -now.getTimezoneOffset();
      O.$$('.wc__item', list).forEach(function (li) {
        var id = li.getAttribute('data-zone');
        var time = new Intl.DateTimeFormat(O.fmt.locale(), { timeZone: id, hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }).format(now);
        var day = new Intl.DateTimeFormat(O.fmt.locale(), { timeZone: id, weekday: 'short', day: 'numeric', month: 'short' }).format(now);
        var diff = (zoneOffsetMin(id, now) - here) / 60;
        var tag = diff === 0 ? t('tool.world.same') : (diff > 0 ? '+' : '') + (Math.round(diff * 10) / 10) + t('tool.world.h');
        O.$('.wc__time', li).textContent = time;
        O.$('.wc__day', li).textContent = day + ' · ' + tag;
      });
    }

    function paint() {
      O.clear(list);
      chosen.forEach(function (id) {
        var rm = O.el('button', { class: 'icon-btn icon-btn--sm', type: 'button', title: t('tab.close'), 'aria-label': t('tab.close') }, [O.icon('close', 14)]);
        rm.addEventListener('click', function () {
          chosen = chosen.filter(function (x) { return x !== id; });
          put('zones', chosen);
          paint();
        });
        list.appendChild(O.el('li', { class: 'wc__item', data: { zone: id } }, [
          O.el('div', { class: 'wc__name' }, [
            O.el('b', { text: label(id) }),
            O.el('span', { class: 'wc__day' })
          ]),
          O.el('output', { class: 'wc__time' }),
          rm
        ]));
      });
      fillSelect();
      tick();
    }

    select.addEventListener('change', function () {
      if (select.value && chosen.indexOf(select.value) < 0 && chosen.length < 8) {
        chosen.push(select.value);
        put('zones', chosen);
        paint();
      } else if (chosen.length >= 8) {
        O.toast(t('tool.world.max'), { kind: 'warn', icon: 'globe' });
        select.value = '';
      }
    });

    paint();
    timer = setInterval(tick, 1000);
    var node = card('globe', t('tool.world'), [list, select]);
    node.__dispose = function () {
      clearInterval(timer);
    };
    return node;
  }

  /* ================= countdown ================= */
  function countdownTool(card) {
    var data = saved().countdown || {};
    var nameInput = O.el('input', { class: 'field__input', type: 'text', maxlength: '40', value: data.name || '', placeholder: t('tool.cd.name'), 'aria-label': t('tool.cd.name') });
    var dateInput = O.el('input', { class: 'field__input', type: 'datetime-local', value: data.at || '', 'aria-label': t('tool.cd.date') });
    var out = O.el('div', { class: 'cd__out', 'aria-live': 'off' });
    var title = O.el('p', { class: 'cd__title' });
    var timer = null;

    function unit(n, key) {
      return O.el('div', { class: 'cd__unit' }, [O.el('b', { text: String(n) }), O.el('span', { text: t(key) })]);
    }

    function tick() {
      O.clear(out);
      var at = dateInput.value ? new Date(dateInput.value).getTime() : NaN;
      title.textContent = nameInput.value.trim();
      if (isNaN(at)) {
        out.appendChild(O.el('p', { class: 'cd__hint', text: t('tool.cd.hint') }));
        return;
      }
      var left = at - Date.now();
      if (left <= 0) {
        out.appendChild(O.el('p', { class: 'cd__hint cd__hint--done', text: t('tool.cd.done') }));
        return;
      }
      var s = Math.floor(left / 1000);
      var d = Math.floor(s / 86400);
      var h = Math.floor((s % 86400) / 3600);
      var m = Math.floor((s % 3600) / 60);
      out.appendChild(unit(d, 'tool.cd.d'));
      out.appendChild(unit(h, 'tool.cd.h'));
      out.appendChild(unit(m, 'tool.cd.m'));
      out.appendChild(unit(s % 60, 'tool.cd.s'));
    }

    function store() {
      put('countdown', { name: nameInput.value.slice(0, 40), at: dateInput.value });
      tick();
    }
    nameInput.addEventListener('input', store);
    dateInput.addEventListener('input', store);
    tick();
    timer = setInterval(tick, 1000);
    var node = card('hourglass', t('tool.cd'), [nameInput, dateInput, title, out]);
    node.__dispose = function () {
      clearInterval(timer);
    };
    return node;
  }

  /* ================= random ================= */
  function randomTool(card) {
    var result = O.el('output', { class: 'rnd__out', text: '—' });
    var note = O.el('span', { class: 'rnd__note' });
    var min = O.el('input', { class: 'field__input', type: 'number', inputmode: 'numeric', value: '1', 'aria-label': t('tool.rnd.min') });
    var max = O.el('input', { class: 'field__input', type: 'number', inputmode: 'numeric', value: '100', 'aria-label': t('tool.rnd.max') });

    function show(value, text) {
      result.textContent = String(value);
      note.textContent = text;
      if (O.animated()) {
        result.classList.remove('is-pop');
        void result.offsetWidth;
        result.classList.add('is-pop');
      }
    }

    function roll(sides) {
      return Math.floor(Math.random() * sides) + 1;
    }

    function btn(label, fn) {
      var b = O.el('button', { class: 'btn btn--ghost', type: 'button', text: label });
      b.addEventListener('click', fn);
      return b;
    }

    var range = btn(t('tool.rnd.number'), function () {
      var lo = Math.floor(Number(min.value));
      var hi = Math.floor(Number(max.value));
      if (isNaN(lo) || isNaN(hi)) {
        return;
      }
      if (lo > hi) {
        var tmp = lo;
        lo = hi;
        hi = tmp;
      }
      show(lo + Math.floor(Math.random() * (hi - lo + 1)), lo + ' … ' + hi);
    });

    return card('bolt', t('tool.rnd'), [
      result,
      note,
      O.el('div', { class: 'rnd__btns' }, [
        btn('d6', function () { show(roll(6), 'd6'); }),
        btn('d20', function () { show(roll(20), 'd20'); }),
        btn(t('tool.rnd.coin'), function () {
          show(Math.random() < 0.5 ? t('tool.rnd.heads') : t('tool.rnd.tails'), t('tool.rnd.coin'));
        })
      ]),
      O.el('div', { class: 'rnd__range' }, [min, max, range])
    ]);
  }

  /* ================= percent ================= */
  function percentTool(card) {
    var a = O.el('input', { class: 'field__input', type: 'number', inputmode: 'decimal', step: 'any', 'aria-label': 'A' });
    var b = O.el('input', { class: 'field__input', type: 'number', inputmode: 'decimal', step: 'any', 'aria-label': 'B' });
    var mode = 'of';
    var out = O.el('output', { class: 'pc__out', text: '—' });

    function fmt(n) {
      return isFinite(n) ? String(Math.round(n * 10000) / 10000) : '—';
    }

    function calc() {
      var x = parseFloat(a.value);
      var y = parseFloat(b.value);
      if (isNaN(x) || isNaN(y)) {
        out.textContent = '—';
        return;
      }
      if (mode === 'of') {
        out.textContent = fmt(x / 100 * y);
      } else if (mode === 'is') {
        out.textContent = y === 0 ? '—' : fmt(x / y * 100) + '%';
      } else {
        out.textContent = x === 0 ? '—' : (y >= x ? '+' : '') + fmt((y - x) / Math.abs(x) * 100) + '%';
      }
    }

    var labelA = O.el('span', { class: 'fld__label' });
    var labelB = O.el('span', { class: 'fld__label' });
    function labels() {
      labelA.textContent = t('tool.pc.a.' + mode);
      labelB.textContent = t('tool.pc.b.' + mode);
    }
    var seg = O.segmented([
      { value: 'of', label: t('tool.pc.of') },
      { value: 'is', label: t('tool.pc.is') },
      { value: 'chg', label: t('tool.pc.chg') }
    ], mode, function (value) {
      mode = value;
      labels();
      calc();
    }, t('tool.pc'));
    a.addEventListener('input', calc);
    b.addEventListener('input', calc);
    labels();
    return card('stats', t('tool.pc'), [
      seg,
      O.el('div', { class: 'pc__grid' }, [
        O.el('label', { class: 'fld' }, [labelA, a]),
        O.el('label', { class: 'fld' }, [labelB, b])
      ]),
      out
    ]);
  }

  [colorTool, textTool, worldTool, countdownTool, randomTool, percentTool].forEach(function (make) {
    O.toolExtras.push(make);
  });
})();
