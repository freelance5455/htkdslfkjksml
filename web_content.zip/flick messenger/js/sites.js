/* Orbita quick access: the list of sites (with Claude first), editor, and the Sites page */
(function () {
  'use strict';
  var O = window.Orbita;
  var t = O.t;

  var DEFAULTS = [
    { id: 'claude', name: 'Claude', url: 'https://claude.ai/', tone: 'clay' },
    { id: 'vpn', name: 'Орбита VPN', url: 'https://claude.ai/artifact/Fn3cAkh4BnPaEzS4Zi6pNY' },
    { id: 'google', name: 'Google', url: 'https://www.google.com/' },
    { id: 'youtube', name: 'YouTube', url: 'https://www.youtube.com/' },
    { id: 'telegram', name: 'Telegram', url: 'https://web.telegram.org/' },
    { id: 'gmail', name: 'Gmail', url: 'https://mail.google.com/' },
    { id: 'maps', name: 'Maps', url: 'https://www.google.com/maps' },
    { id: 'wiki', name: 'Wikipedia', url: 'https://www.wikipedia.org/' },
    { id: 'github', name: 'GitHub', url: 'https://github.com/' },
    { id: 'translate', name: 'Translate', url: 'https://translate.google.com/' },
    { id: 'drive', name: 'Drive', url: 'https://drive.google.com/' }
  ];

  function clone(list) {
    return list.map(function (site) {
      return Object.assign({}, site);
    });
  }

  var list = O.store.get('sites', null);
  if (!Array.isArray(list) || !list.length) {
    list = clone(DEFAULTS);
  }

  /* people who already saved their own list get the VPN tile once, right after Claude */
  if (!O.store.get('seed-vpn', false)) {
    var hasVpn = list.some(function (site) {
      return site.id === 'vpn';
    });
    if (!hasVpn) {
      list.splice(Math.min(1, list.length), 0, clone([DEFAULTS[1]])[0]);
      O.store.set('sites', list);
    }
    O.store.set('seed-vpn', true);
  }

  function save() {
    O.store.set('sites', list);
    O.emit('sites');
  }

  function indexOf(id) {
    for (var i = 0; i < list.length; i++) {
      if (list[i].id === id) {
        return i;
      }
    }
    return -1;
  }

  function hueOf(site) {
    if (site.tone === 'clay') {
      return 16;
    }
    var seed = String(site.id || site.name);
    var h = 0;
    for (var i = 0; i < seed.length; i++) {
      h = (h * 31 + seed.charCodeAt(i)) % 360;
    }
    return h;
  }

  O.sites = {
    vpnUrl: DEFAULTS[1].url,
    defaults: DEFAULTS,
    all: function () {
      return list.slice();
    },
    get: function (id) {
      var i = indexOf(id);
      return i >= 0 ? list[i] : null;
    },
    /* Claude shares its picture with the AI mode page */
    iconKey: function (site) {
      return site.id === 'claude' ? 'ai:claude' : 'site:' + site.id;
    },
    hue: hueOf,
    add: function (name, url) {
      var clean = O.url.normalize(url);
      if (!clean || !String(name || '').trim()) {
        return null;
      }
      var site = { id: O.uid(), name: String(name).trim().slice(0, 24), url: clean };
      list.push(site);
      save();
      return site;
    },
    update: function (id, name, url) {
      var i = indexOf(id);
      var clean = O.url.normalize(url);
      if (i < 0 || !clean || !String(name || '').trim()) {
        return false;
      }
      list[i].name = String(name).trim().slice(0, 24);
      list[i].url = clean;
      save();
      return true;
    },
    remove: function (id) {
      var i = indexOf(id);
      if (i >= 0) {
        var gone = list[i];
        list.splice(i, 1);
        O.avatars.remove(O.sites.iconKey(gone));
        save();
      }
    },
    move: function (id, delta) {
      var i = indexOf(id);
      var j = i + delta;
      if (i < 0 || j < 0 || j >= list.length) {
        return;
      }
      var item = list.splice(i, 1)[0];
      list.splice(j, 0, item);
      save();
    },
    reset: function () {
      list = clone(DEFAULTS);
      save();
    },
    replaceAll: function (next) {
      if (!Array.isArray(next)) {
        return;
      }
      var clean = [];
      next.forEach(function (site) {
        var url = site && O.url.normalize(site.url);
        if (url && site.name) {
          clean.push({ id: site.id || O.uid(), name: String(site.name).slice(0, 24), url: url, tone: site.tone });
        }
      });
      list = clean.length ? clean : clone(DEFAULTS);
      save();
    },

    /* modal for adding or editing a site */
    openEditor: function (site) {
      var editing = !!site;
      var nameInput = O.el('input', {
        class: 'field__input',
        id: 'site-name',
        type: 'text',
        maxlength: '24',
        value: editing ? site.name : '',
        placeholder: t('b.name.ph'),
        autocomplete: 'off',
        'data-autofocus': ''
      });
      var urlInput = O.el('input', {
        class: 'field__input',
        id: 'site-url',
        type: 'text',
        inputmode: 'url',
        value: editing ? site.url : '',
        placeholder: 'example.com',
        autocomplete: 'off',
        autocapitalize: 'off',
        spellcheck: 'false'
      });
      /* picture: undefined = unchanged, null = remove, string = new data URL */
      var pending;
      var key = editing ? O.sites.iconKey(site) : null;
      var preview = O.el('div', { class: 'iconrow__preview' });
      function paintPreview() {
        O.clear(preview);
        var src = pending === undefined ? (key ? O.avatars.get(key) : null) : pending;
        var hue = editing ? O.sites.hue(site) : 230;
        preview.appendChild(src ? O.avatars.fromData(src, true) : O.monogram(nameInput.value || '?', hue, true));
      }
      var upload = O.avatars.picker('btn btn--ghost btn--sm', [O.icon('upload', 14), O.el('span', { text: t('ic.upload') })], t('ic.upload'), function (data) {
        pending = data;
        paintPreview();
      });
      var reset = O.el('button', { class: 'btn btn--ghost btn--sm', type: 'button', text: t('ic.remove') });
      reset.addEventListener('click', function () {
        pending = null;
        paintPreview();
      });
      nameInput.addEventListener('input', paintPreview);
      paintPreview();
      var iconRow = O.el('div', { class: 'form__row' }, [
        O.el('span', { class: 'form__label', text: t('ic.title') }),
        O.el('div', { class: 'iconrow' }, [preview, O.el('div', { class: 'iconrow__buttons' }, [upload, reset])]),
        O.el('p', { class: 'iconrow__hint', text: t('ic.hint') })
      ]);

      var nameErr = O.el('p', { class: 'field__error', text: t('b.err.name'), hidden: true });
      var urlErr = O.el('p', { class: 'field__error', text: t('b.err.url'), hidden: true });

      var form = O.el('div', { class: 'form' }, [
        O.el('label', { class: 'form__row', for: 'site-name' }, [O.el('span', { class: 'form__label', text: t('b.name') }), nameInput, nameErr]),
        O.el('label', { class: 'form__row', for: 'site-url' }, [O.el('span', { class: 'form__label', text: t('b.url') }), urlInput, urlErr]),
        iconRow
      ]);

      function commit(modal) {
        var okName = nameInput.value.trim().length > 0;
        var okUrl = !!O.url.normalize(urlInput.value);
        nameErr.hidden = okName;
        urlErr.hidden = okUrl;
        if (!okName || !okUrl) {
          return false;
        }
        if (editing) {
          O.sites.update(site.id, nameInput.value, urlInput.value);
          if (pending === null) {
            O.avatars.remove(key);
          } else if (typeof pending === 'string') {
            O.avatars.set(key, pending);
          }
          O.toast(t('b.saved'), { kind: 'good' });
        } else {
          var created = O.sites.add(nameInput.value, urlInput.value);
          if (created && typeof pending === 'string') {
            O.avatars.set(O.sites.iconKey(created), pending);
          }
          O.toast(t('b.added'), { kind: 'good' });
        }
        return true;
      }

      var api = O.modal.open({
        title: editing ? t('b.edit') : t('b.add'),
        size: 'sm',
        content: form,
        actions: [
          { label: t('c.cancel'), kind: 'ghost' },
          { label: t('c.save'), kind: 'primary', onClick: function (modal) { return commit(modal); } }
        ]
      });

      form.addEventListener('keydown', function (event) {
        if (event.key === 'Enter') {
          event.preventDefault();
          if (commit(api)) {
            api.close();
          }
        }
      });
    }
  };

  /* ---------- Sites page ---------- */
  function buildPage(root) {
    var page = O.el('div', { class: 'page page--sites' });
    var listBox = O.el('section', { class: 'slist' });

    var addBtn = O.el('button', { class: 'btn btn--primary', type: 'button' }, [
      O.icon('plus', 16),
      O.el('span', { text: t('b.add') })
    ]);
    addBtn.addEventListener('click', function () {
      O.sites.openEditor(null);
    });

    page.appendChild(O.pageHead('star', t('b.title'), t('b.sub'), [addBtn]));
    page.appendChild(listBox);

    var resetBtn = O.el('button', { class: 'btn btn--ghost', type: 'button' }, [
      O.icon('reset', 16),
      O.el('span', { text: t('b.reset') })
    ]);
    resetBtn.addEventListener('click', function () {
      O.modal.confirm({ title: t('b.reset'), message: t('b.reset.confirm'), confirmLabel: t('b.reset') }).then(function (yes) {
        if (yes) {
          O.sites.reset();
          O.toast(t('b.defaults'), { kind: 'good' });
        }
      });
    });
    page.appendChild(O.el('div', { class: 'page__foot' }, [resetBtn]));
    root.appendChild(page);

    function render() {
      O.clear(listBox);
      var all = O.sites.all();
      all.forEach(function (site, i) {
        var up = O.el('button', { class: 'icon-btn', type: 'button', 'aria-label': t('b.moveUp'), title: t('b.moveUp'), disabled: i === 0 }, [O.icon('up', 16)]);
        var down = O.el('button', { class: 'icon-btn', type: 'button', 'aria-label': t('b.moveDown'), title: t('b.moveDown'), disabled: i === all.length - 1 }, [O.icon('down', 16)]);
        var edit = O.el('button', { class: 'icon-btn', type: 'button', 'aria-label': t('b.edit'), title: t('b.edit') }, [O.icon('edit', 16)]);
        var del = O.el('button', { class: 'icon-btn icon-btn--danger', type: 'button', 'aria-label': t('b.delete'), title: t('b.delete') }, [O.icon('trash', 16)]);

        up.addEventListener('click', function () { O.sites.move(site.id, -1); });
        down.addEventListener('click', function () { O.sites.move(site.id, 1); });
        edit.addEventListener('click', function () { O.sites.openEditor(site); });
        del.addEventListener('click', function () {
          O.sites.remove(site.id);
          O.toast(t('b.removed'), { kind: 'info' });
        });

        var link = O.el('a', { class: 'srow__link' }, [
          O.el('span', { class: 'srow__name', text: site.name }),
          O.el('span', { class: 'srow__host', text: O.url.host(site.url) })
        ]);
        O.link(link, site.url, { type: 'site', text: site.name, url: site.url });

        listBox.appendChild(O.el('div', { class: 'srow' }, [
          O.avatars.el(O.sites.iconKey(site), site.name, hueOf(site)),
          link,
          O.el('div', { class: 'srow__actions' }, [up, down, edit, del])
        ]));
      });
      O.stagger(listBox);
    }

    render();
    var off = O.on('sites', render);
    var offIcons = O.on('icons', render);
    return function () {
      off();
      offIcons();
    };
  }

  O.registerPage('bookmarks', {
    icon: 'star',
    titleKey: 'tab.bookmarks',
    singleton: true,
    build: buildPage
  });
})();
