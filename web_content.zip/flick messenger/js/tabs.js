/* Orbita tabs: internal tabs (home, history, sites, tools, settings) with animated open, close, reorder */
(function () {
  'use strict';
  var O = window.Orbita;
  var t = O.t;

  var MAX_TABS = 12;
  var state = { list: [], active: null };
  var views = {};
  var stripEl = null;
  var viewsEl = null;
  var freshId = null;
  var dragId = null;

  function byId(id) {
    for (var i = 0; i < state.list.length; i++) {
      if (state.list[i].id === id) {
        return state.list[i];
      }
    }
    return null;
  }

  function indexOf(id) {
    for (var i = 0; i < state.list.length; i++) {
      if (state.list[i].id === id) {
        return i;
      }
    }
    return -1;
  }

  function persist() {
    O.store.set('tabs', { list: state.list, active: state.active });
  }

  function load() {
    var saved = O.store.get('tabs', null);
    if (saved && Array.isArray(saved.list)) {
      state.list = saved.list.filter(function (tab) {
        return tab && O.pages[tab.type];
      }).map(function (tab) {
        return { id: tab.id || O.uid(), type: tab.type, pinned: !!tab.pinned };
      });
      state.active = saved.active;
    }
    if (!state.list.length) {
      state.list = [{ id: O.uid(), type: 'home' }];
    }
    if (!byId(state.active)) {
      state.active = state.list[0].id;
    }
  }

  function titleOf(tab) {
    var def = O.pages[tab.type];
    return def.title ? def.title(tab) : t(def.titleKey);
  }

  /* ---------- views ---------- */
  function ensureView(tab) {
    var v = views[tab.id];
    if (v) {
      return v;
    }
    var el = O.el('section', {
      class: 'view',
      role: 'tabpanel',
      data: { tab: tab.id },
      hidden: true
    });
    viewsEl.appendChild(el);
    v = views[tab.id] = { el: el, built: false, dispose: null };
    return v;
  }

  function disposeView(v) {
    if (v && v.dispose) {
      O.run(v.dispose);
      v.dispose = null;
    }
  }

  function buildView(tab) {
    var v = ensureView(tab);
    disposeView(v);
    O.clear(v.el);
    var result = O.pages[tab.type].build(v.el, tab);
    if (typeof result === 'function') {
      v.dispose = result;
    }
    O.i18n.apply(v.el);
    v.built = true;
  }

  /* ---------- strip ---------- */
  function renderStrip() {
    if (!stripEl) {
      return;
    }
    O.clear(stripEl);
    state.list.forEach(function (tab) {
      var def = O.pages[tab.type];
      var active = tab.id === state.active;
      var close = O.el('button', {
        class: 'tab__close',
        type: 'button',
        tabindex: '-1',
        'aria-label': t('tab.close')
      }, [O.icon('close', 14)]);

      var node = O.el('div', {
        class: 'tab' + (active ? ' is-active' : '') + (tab.pinned ? ' is-pinned' : '') + (tab.id === freshId ? ' is-new' : ''),
        role: 'tab',
        'aria-selected': active ? 'true' : 'false',
        tabindex: active ? '0' : '-1',
        draggable: 'true',
        title: titleOf(tab),
        data: { id: tab.id }
      }, [
        O.icon(def.icon, 16),
        O.el('span', { class: 'tab__title', text: titleOf(tab) }),
        tab.pinned ? null : close
      ]);

      node.addEventListener('click', function () {
        activate(tab.id);
      });
      node.addEventListener('auxclick', function (event) {
        if (event.button === 1) {
          event.preventDefault();
          requestClose(tab.id);
        }
      });
      node.addEventListener('contextmenu', function (event) {
        event.preventDefault();
        openContext(node, tab);
      });
      node.addEventListener('keydown', function (event) {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          activate(tab.id);
        } else if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') {
          event.preventDefault();
          var step = event.key === 'ArrowRight' ? 1 : -1;
          var next = state.list[(indexOf(tab.id) + step + state.list.length) % state.list.length];
          activate(next.id);
          var again = O.$('.tab.is-active', stripEl);
          if (again) {
            again.focus();
          }
        } else if (event.key === 'Delete') {
          requestClose(tab.id);
        }
      });
      close.addEventListener('click', function (event) {
        event.stopPropagation();
        requestClose(tab.id);
      });

      node.addEventListener('dragstart', function (event) {
        dragId = tab.id;
        node.classList.add('is-dragging');
        if (event.dataTransfer) {
          event.dataTransfer.effectAllowed = 'move';
          try { event.dataTransfer.setData('text/plain', tab.id); } catch (err) { /* ignore */ }
        }
      });
      node.addEventListener('dragover', function (event) {
        if (dragId && dragId !== tab.id) {
          event.preventDefault();
          node.classList.add('is-over');
        }
      });
      node.addEventListener('dragleave', function () {
        node.classList.remove('is-over');
      });
      node.addEventListener('drop', function (event) {
        event.preventDefault();
        if (dragId && dragId !== tab.id) {
          reorder(dragId, tab.id);
        }
        dragId = null;
      });
      node.addEventListener('dragend', function () {
        dragId = null;
        renderStrip();
      });

      stripEl.appendChild(node);
    });
    freshId = null;
    var on = O.$('.tab.is-active', stripEl);
    if (on && on.scrollIntoView) {
      on.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    }
  }

  function reorder(fromId, toId) {
    var from = indexOf(fromId);
    var to = indexOf(toId);
    if (from < 0 || to < 0) {
      return;
    }
    var item = state.list.splice(from, 1)[0];
    state.list.splice(to, 0, item);
    persist();
    renderStrip();
  }

  function openContext(anchor, tab) {
    O.menu.open(anchor, [
      { label: t('tab.reload'), icon: 'reload', onClick: function () { reload(tab.id); } },
      { label: tab.pinned ? t('tab.unpin') : t('tab.pin'), icon: 'pin', onClick: function () { togglePin(tab.id); } },
      { label: t('tab.duplicate'), icon: 'copy', onClick: function () { open(tab.type, null, { after: tab.id, force: true }); } },
      { separator: true },
      { label: t('tab.close'), icon: 'close', onClick: function () { requestClose(tab.id); } },
      { label: t('tab.closeOthers'), icon: 'trash', kind: 'danger', onClick: function () { closeOthers(tab.id); } }
    ], { align: 'left' });
  }

  /* ---------- actions ---------- */
  function activate(id) {
    var tab = byId(id);
    if (!tab) {
      return;
    }
    state.active = id;
    var v = ensureView(tab);
    if (!v.built) {
      buildView(tab);
    }
    Object.keys(views).forEach(function (key) {
      views[key].el.hidden = key !== id;
      views[key].el.classList.remove('is-entering');
    });
    v.el.hidden = false;
    void v.el.offsetWidth;
    v.el.classList.add('is-entering');
    var def = O.pages[tab.type];
    if (def.onShow) {
      def.onShow(v.el, tab);
    }
    renderStrip();
    persist();
    O.emit('tab:active', tab);
  }

  function open(type, params, opts) {
    opts = opts || {};
    var def = O.pages[type];
    if (!def) {
      return null;
    }
    if (def.singleton && !opts.force) {
      for (var i = 0; i < state.list.length; i++) {
        if (state.list[i].type === type) {
          activate(state.list[i].id);
          return state.list[i];
        }
      }
    }
    if (state.list.length >= MAX_TABS) {
      O.toast(t('tab.limit'), { kind: 'warn' });
      return null;
    }
    var tab = { id: O.uid(), type: type, pinned: false };
    var at = state.list.length;
    if (opts.after) {
      at = indexOf(opts.after) + 1;
    } else if (state.active) {
      at = indexOf(state.active) + 1;
    }
    /* new tabs never land among the pinned ones */
    var pinnedCount = state.list.filter(function (x) { return x.pinned; }).length;
    at = Math.max(at, pinnedCount);
    state.list.splice(at, 0, tab);
    freshId = tab.id;
    activate(tab.id);
    return tab;
  }

  function close(id) {
    var idx = indexOf(id);
    if (idx < 0) {
      return;
    }
    var wasActive = state.active === id;
    var v = views[id];
    if (v) {
      disposeView(v);
      if (v.el.parentNode) {
        v.el.parentNode.removeChild(v.el);
      }
      delete views[id];
    }
    state.list.splice(idx, 1);
    if (!state.list.length) {
      var fresh = { id: O.uid(), type: 'home' };
      state.list.push(fresh);
      state.active = fresh.id;
      freshId = fresh.id;
    } else if (wasActive) {
      state.active = state.list[Math.min(idx, state.list.length - 1)].id;
    }
    activate(state.active);
  }

  function requestClose(id) {
    var target = byId(id);
    if (target && target.pinned) {
      O.toast(t('tab.pinned.warn'), { kind: 'warn', icon: 'pin' });
      return;
    }
    var node = stripEl ? O.$('.tab[data-id="' + id + '"]', stripEl) : null;
    if (node && O.animated()) {
      node.classList.add('is-leaving');
      setTimeout(function () {
        close(id);
      }, 170);
    } else {
      close(id);
    }
  }

  function closeOthers(id) {
    state.list.slice().forEach(function (tab) {
      if (tab.id !== id) {
        var v = views[tab.id];
        if (v) {
          disposeView(v);
          if (v.el.parentNode) {
            v.el.parentNode.removeChild(v.el);
          }
          delete views[tab.id];
        }
      }
    });
    state.list = state.list.filter(function (tab) {
      return tab.id === id || tab.pinned;
    });
    activate(id);
  }

  /* pinned tabs stay first, narrow, and cannot be closed by accident */
  function togglePin(id) {
    var tab = byId(id);
    if (!tab) {
      return;
    }
    tab.pinned = !tab.pinned;
    var pinned = state.list.filter(function (x) { return x.pinned; });
    var rest = state.list.filter(function (x) { return !x.pinned; });
    state.list = pinned.concat(rest);
    persist();
    renderStrip();
    O.emit('tabs');
  }

  /* bring the first tab of a type to the front, or open one */
  function focusType(type) {
    for (var i = 0; i < state.list.length; i++) {
      if (state.list[i].type === type) {
        activate(state.list[i].id);
        return state.list[i];
      }
    }
    return open(type);
  }

  function step(delta) {
    if (state.list.length < 2) {
      return;
    }
    var next = state.list[(indexOf(state.active) + delta + state.list.length) % state.list.length];
    activate(next.id);
  }

  function reload(id) {
    var tab = byId(id || state.active);
    if (!tab) {
      return;
    }
    buildView(tab);
    var v = views[tab.id];
    v.el.classList.remove('is-entering');
    void v.el.offsetWidth;
    v.el.classList.add('is-entering');
  }

  O.tabs = {
    init: function (strip, viewsContainer) {
      stripEl = strip;
      viewsEl = viewsContainer;
      load();
      activate(state.active);
    },
    open: open,
    close: requestClose,
    activate: activate,
    next: function () { step(1); },
    prev: function () { step(-1); },
    reload: reload,
    togglePin: togglePin,
    focus: focusType,
    list: function () { return state.list.slice(); },
    titleOf: titleOf,
    iconOf: function (tab) { return O.pages[tab.type].icon; },
    closeOthers: closeOthers,
    active: function () { return byId(state.active); },
    count: function () { return state.list.length; }
  };

  /* language change: rebuild every tab that was already built, then refresh titles */
  O.on('lang', function () {
    state.list.forEach(function (tab) {
      var v = views[tab.id];
      if (v && v.built) {
        buildView(tab);
      }
    });
    renderStrip();
  });
})();
