/* Orbita home page: wordmark with orbit, search, quick queries, Claude card, sites, widgets, recent */
(function () {
  'use strict';
  var O = window.Orbita;
  var t = O.t;

  var HOME_KEYS = ['showClaude', 'showClock', 'showChips'];

  function orbitSvg() {
    var id = 'op' + Math.random().toString(36).slice(2, 8);
    return '<svg viewBox="0 0 720 150" preserveAspectRatio="xMidYMid meet" aria-hidden="true">' +
      '<ellipse cx="360" cy="75" rx="345" ry="38" class="orbit__ring orbit__ring--outer" transform="rotate(-6 360 75)"/>' +
      '<ellipse id="' + id + '" cx="360" cy="75" rx="300" ry="52" class="orbit__ring" transform="rotate(-6 360 75)"/>' +
      '<g transform="rotate(-6 360 75)">' +
      '<circle r="6" class="orbit__dot"><animateMotion dur="14s" repeatCount="indefinite"><mpath href="#' + id + '"/></animateMotion></circle>' +
      '<circle r="3" class="orbit__dot orbit__dot--small"><animateMotion dur="23s" begin="-7s" repeatCount="indefinite" keyPoints="1;0" keyTimes="0;1" calcMode="linear"><mpath href="#' + id + '"/></animateMotion></circle>' +
      '</g></svg>';
  }

  function greetingKey(hour) {
    if (hour < 5) {
      return 'home.greet.night';
    }
    if (hour < 12) {
      return 'home.greet.morning';
    }
    if (hour < 18) {
      return 'home.greet.day';
    }
    return 'home.greet.evening';
  }

  function build(root) {
    var disposers = [];
    var wrap = O.el('div', { class: 'home' });
    var tilesSection = null;
    root.appendChild(wrap);

    function track(fn) {
      disposers.push(fn);
    }

    /* ----- hero ----- */
    function hero() {
      var block = O.el('section', { class: 'hero' });

      if (O.settings.get('showClock')) {
        var greet = O.el('span', { class: 'hero__greet' });
        var date = O.el('span', { class: 'hero__date' });
        var clock = O.el('span', { class: 'hero__clock' });
        var tick = function () {
          var d = new Date();
          greet.textContent = t(greetingKey(d.getHours()));
          date.textContent = O.fmt.date(d.getTime(), { weekday: 'long', day: 'numeric', month: 'long' });
          clock.textContent = O.pad2(d.getHours()) + ':' + O.pad2(d.getMinutes());
        };
        tick();
        var timer = setInterval(tick, 15000);
        track(function () { clearInterval(timer); });
        block.appendChild(O.el('div', { class: 'hero__meta' }, [
          O.el('div', { class: 'hero__when' }, [greet, date]),
          clock
        ]));
      }

      block.appendChild(O.el('div', { class: 'hero__mark' }, [
        O.el('div', { class: 'hero__orbit', html: orbitSvg() }),
        O.el('h1', { class: 'hero__word', text: 'Орбита' })
      ]));
      return block;
    }

    /* ----- search ----- */
    function searchBlock() {
      var listId = 'sg' + O.uid();
      var input = O.el('input', {
        class: 'bar__input',
        type: 'text',
        placeholder: t('search.placeholder'),
        'aria-label': t('search.placeholder'),
        autocomplete: 'off',
        autocapitalize: 'off',
        spellcheck: 'false',
        enterkeyhint: 'search'
      });
      var go = O.el('a', { class: 'btn btn--primary bar__go', target: '_blank', rel: 'noopener noreferrer' }, [
        O.el('span', { text: t('search.go') }),
        O.icon('arrow', 16)
      ]);
      var engineText = O.el('span', { text: O.search.engineName(O.settings.get('engine')) });
      var engine = O.el('button', { class: 'bar__engine', type: 'button', title: t('search.engine'), 'aria-label': t('search.engine') }, [
        engineText,
        O.icon('down', 14)
      ]);
      engine.addEventListener('click', function () {
        O.search.pickEngine(engine);
      });
      track(O.on('settings:engine', function (id) {
        engineText.textContent = O.search.engineName(id);
      }));

      var hint = O.el('p', { class: 'hint' });
      function paintHint() {
        hint.textContent = t('search.hint', { engine: O.search.engineName(O.settings.get('engine')) });
      }
      paintHint();
      track(O.on('settings:engine', paintHint));

      var box = O.el('div', { class: 'suggest', id: listId, role: 'listbox', hidden: true });
      var bar = O.el('div', { class: 'bar spot' }, [
        O.el('span', { class: 'bar__icon' }, [O.icon('search', 20)]),
        input,
        engine,
        go
      ]);
      var sb = O.search.create({ input: input, go: go, dropdown: box });
      track(sb.destroy);

      return O.el('section', { class: 'searchblock' }, [
        O.el('div', { class: 'searchbox' }, [bar, box]),
        hint
      ]);
    }

    /* ----- quick queries ----- */
    function chips() {
      var box = O.el('div', { class: 'chips', role: 'list' });
      var links = [];
      function paint() {
        links.forEach(function (item) {
          item.a.href = O.search.resolve(item.q).url;
        });
      }
      for (var i = 1; i <= 5; i++) {
        links.push(makeChip(t('chip.' + i)));
        box.appendChild(links[links.length - 1].a);
      }
      function makeChip(q) {
        var a = O.el('a', { class: 'chip', role: 'listitem', target: '_blank', rel: 'noopener noreferrer' }, [O.icon('search', 14), O.el('span', { text: q })]);
        a.addEventListener('click', function () {
          var result = O.search.resolve(q);
          a.href = result.url;
          O.history.add({ type: 'search', text: q, url: result.url });
        });
        return { a: a, q: q };
      }
      paint();
      track(O.on('settings:engine', paint));
      return box;
    }

    /* ----- Claude card ----- */
    function claudeCard() {
      var url = 'https://claude.ai/';
      var a = O.el('a', { class: 'claude spot', 'data-tilt': '' }, [
        O.avatars.el('ai:claude', 'Claude', 16, true),
        O.el('div', { class: 'claude__text' }, [
          O.el('span', { class: 'claude__tag', text: t('claude.tag') }),
          O.el('strong', { class: 'claude__name', text: 'Claude' }),
          O.el('span', { class: 'claude__sub', text: t('claude.sub') })
        ]),
        O.el('span', { class: 'claude__go' }, [O.el('span', { text: t('claude.open') }), O.icon('arrow', 16)]),
        O.el('span', { class: 'claude__sheen', 'aria-hidden': 'true' })
      ]);
      O.link(a, url, { type: 'site', text: 'Claude', url: url });
      return a;
    }

    /* ----- sites ----- */
    function tiles() {
      var grid = O.el('div', { class: 'tiles' });
      O.sites.all().forEach(function (site) {
        var a = O.el('a', { class: 'tile' + (site.tone === 'clay' ? ' tile--claude' : ''), 'data-tilt': '', title: site.url }, [
          O.avatars.el(O.sites.iconKey(site), site.name, O.sites.hue(site)),
          O.el('span', { class: 'tile__name', text: site.name })
        ]);
        O.link(a, site.url, { type: 'site', text: site.name, url: site.url });
        grid.appendChild(a);
      });
      var add = O.el('button', { class: 'tile tile--add', type: 'button', 'data-tilt': '', 'aria-label': t('home.add') }, [
        O.el('span', { class: 'mono mono--plain' }, [O.icon('plus', 22)]),
        O.el('span', { class: 'tile__name', text: t('home.add') })
      ]);
      add.addEventListener('click', function () {
        O.sites.openEditor(null);
      });
      grid.appendChild(add);
      O.stagger(grid);

      var manage = O.el('button', { class: 'link-btn', type: 'button', text: t('home.manage') });
      manage.addEventListener('click', function () {
        O.tabs.open('bookmarks');
      });

      return O.el('section', { class: 'block block--sites' }, [
        O.el('div', { class: 'block__head' }, [O.el('h2', { class: 'block__title', text: t('home.sites') }), manage]),
        grid
      ]);
    }

    /* ----- compose ----- */
    function render() {
      disposers.splice(0).forEach(O.run);
      O.clear(wrap);
      wrap.appendChild(hero());
      wrap.appendChild(searchBlock());
      if (O.settings.get('showChips')) {
        wrap.appendChild(chips());
      }
      if (O.settings.get('showClaude')) {
        wrap.appendChild(claudeCard());
      }
      tilesSection = tiles();
      wrap.appendChild(tilesSection);
      O.stagger(wrap);
    }

    render();

    var offSites = O.on('sites', function () {
      if (!tilesSection || !tilesSection.parentNode) {
        return;
      }
      var fresh = tiles();
      wrap.replaceChild(fresh, tilesSection);
      tilesSection = fresh;
    });
    var offIcons = O.on('icons', render);
    var offSettings = O.on('settings', function (change) {
      if (change.key === '*' || HOME_KEYS.indexOf(change.key) >= 0) {
        render();
      }
    });

    return function () {
      offSites();
      offIcons();
      offSettings();
      disposers.splice(0).forEach(O.run);
    };
  }

  O.registerPage('home', {
    icon: 'home',
    titleKey: 'tab.home',
    build: build
  });
})();
