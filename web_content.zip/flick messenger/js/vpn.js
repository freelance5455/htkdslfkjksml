/* Orbita VPN panel: first card in Tools plus its own page. It is the app's interface:
   pick a country, store a subscription key, press connect. A web page cannot route device traffic,
   so connecting reports ERROR_SMG_01 (no server attached) instead of pretending to work. */
(function () {
  'use strict';
  var O = window.Orbita;
  var t = O.t;

  var REGIONS = null;

  function flag(code) {
    return String.fromCodePoint(0x1f1e6 + code.charCodeAt(0) - 65, 0x1f1e6 + code.charCodeAt(1) - 65);
  }

  /* every country the browser can name, in the page language */
  function regions() {
    var lang = O.fmt.locale();
    if (REGIONS && REGIONS.lang === lang) {
      return REGIONS.list;
    }
    var list = [];
    var names = null;
    try {
      names = new Intl.DisplayNames([lang], { type: 'region' });
    } catch (err) {
      names = null;
    }
    var A = 65;
    for (var i = 0; i < 26; i++) {
      for (var j = 0; j < 26; j++) {
        var code = String.fromCharCode(A + i, A + j);
        var name = names ? names.of(code) : code;
        if (name && name !== code && !/^(unknown|невідом|неизвест)/i.test(name) && !/^(EU|UN|EZ|XA|XB|AC|CP|DG|EA|IC|TA)$/.test(code)) {
          list.push({ code: code, name: name });
        }
      }
    }
    list.sort(function (a, b) { return a.name.localeCompare(b.name, lang); });
    REGIONS = { lang: lang, list: list };
    return list;
  }

  function load() {
    var s = O.store.get('vpn', {});
    s = s && typeof s === 'object' ? s : {};
    return { key: String(s.key || ''), country: s.country || 'NL', log: Array.isArray(s.log) ? s.log : [] };
  }

  function save(s) {
    s.log = s.log.slice(0, 30);
    O.store.set('vpn', s);
    O.emit('vpn');
  }

  function nameOf(code) {
    var r = regions();
    for (var i = 0; i < r.length; i++) {
      if (r[i].code === code) {
        return flag(code) + ' ' + r[i].name;
      }
    }
    return code;
  }

  function maskKey(key) {
    if (!key) {
      return '';
    }
    return key.length <= 14 ? key.slice(0, 3) + '…' : key.slice(0, 8) + '…' + key.slice(-4);
  }

  var ERRORS = {
    ERROR_SMG_01: 'vpn.e.smg',
    ERROR_SUB_02: 'vpn.e.sub',
    ERROR_NET_03: 'vpn.e.net'
  };

  function pickCountry(done) {
    var list = O.el('div', { class: 'vpn__countries' });
    var search = O.el('input', { class: 'field__input', type: 'search', autocomplete: 'off', placeholder: t('vpn.search'), 'aria-label': t('vpn.search') });
    var current = load().country;
    var modal;
    function paint() {
      var q = search.value.trim().toLowerCase();
      O.clear(list);
      regions().forEach(function (r) {
        if (q && r.name.toLowerCase().indexOf(q) < 0 && r.code.toLowerCase() !== q) {
          return;
        }
        var b = O.el('button', { class: 'vpn__country' + (r.code === current ? ' is-on' : ''), type: 'button' }, [
          O.el('span', { class: 'vpn__flag', text: flag(r.code) }),
          O.el('span', { class: 'vpn__cname', text: r.name }),
          r.code === current ? O.icon('check', 16) : null
        ]);
        b.addEventListener('click', function () {
          var s = load();
          s.country = r.code;
          save(s);
          modal.close();
          done();
        });
        list.appendChild(b);
      });
      if (!list.firstChild) {
        list.appendChild(O.el('p', { class: 'vpn__none', text: t('p.empty') }));
      }
    }
    search.addEventListener('input', paint);
    paint();
    modal = O.modal.open({
      title: t('vpn.country'),
      size: 'md',
      content: [search, list]
    });
  }

  function build(root) {
    var page = O.el('div', { class: 'page page--vpn' });
    var state = 'idle';
    var timer = null;

    var ring = O.el('button', { class: 'vpn__power', type: 'button', 'aria-label': t('vpn.connect') }, [O.icon('shield', 54)]);
    var status = O.el('p', { class: 'vpn__status' });
    var errBox = O.el('div', { class: 'vpn__error', role: 'alert', hidden: true });
    var countryBtn = O.el('button', { class: 'vpn__pick', type: 'button' });
    var keyInput = O.el('input', { class: 'field__input', type: 'text', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', placeholder: t('vpn.key.ph'), 'aria-label': t('vpn.key') });
    var keyState = O.el('p', { class: 'vpn__keystate' });
    var logEl = O.el('ul', { class: 'vpn__log' });

    function paint() {
      var s = load();
      countryBtn.textContent = '';
      countryBtn.appendChild(O.el('span', { class: 'vpn__pickname', text: nameOf(s.country) }));
      countryBtn.appendChild(O.icon('chevron', 18));
      keyState.textContent = s.key ? t('vpn.key.saved', { key: maskKey(s.key) }) : t('vpn.key.none');
      page.classList.toggle('is-connecting', state === 'connecting');
      page.classList.toggle('is-failed', state === 'failed');
      ring.disabled = state === 'connecting';
      status.textContent = state === 'connecting' ? t('vpn.connecting') : (state === 'failed' ? t('vpn.failed') : t('vpn.off'));
      O.clear(logEl);
      if (!s.log.length) {
        logEl.appendChild(O.el('li', { class: 'vpn__logempty', text: t('vpn.log.empty') }));
      }
      s.log.forEach(function (e) {
        logEl.appendChild(O.el('li', {}, [
          O.el('b', { text: e.code }),
          O.el('span', { text: t(ERRORS[e.code] || 'vpn.e.smg') }),
          O.el('time', { text: O.fmt.time(e.ts) })
        ]));
      });
    }

    function fail(code) {
      state = 'failed';
      var s = load();
      s.log.unshift({ code: code, ts: Date.now(), country: s.country });
      save(s);
      O.clear(errBox);
      errBox.hidden = false;
      errBox.appendChild(O.el('b', { class: 'vpn__code', text: code }));
      errBox.appendChild(O.el('span', { text: t(ERRORS[code]) }));
      paint();
    }

    ring.addEventListener('click', function () {
      if (state === 'connecting') {
        return;
      }
      errBox.hidden = true;
      if (state === 'failed') {
        state = 'idle';
        paint();
      }
      state = 'connecting';
      paint();
      timer = setTimeout(function () {
        timer = null;
        if (navigator.onLine === false) {
          fail('ERROR_NET_03');
        } else if (!load().key) {
          fail('ERROR_SUB_02');
        } else {
          fail('ERROR_SMG_01');
        }
      }, O.animated() ? 1800 : 100);
    });

    countryBtn.addEventListener('click', function () {
      pickCountry(paint);
    });

    var saveKey = O.el('button', { class: 'btn btn--primary', type: 'button' }, [O.icon('key', 16), O.el('span', { text: t('c.save') })]);
    saveKey.addEventListener('click', function () {
      var v = keyInput.value.trim();
      if (v.length < 8 || /\s/.test(v)) {
        O.toast(t('vpn.key.bad'), { kind: 'warn', icon: 'key' });
        return;
      }
      var s = load();
      s.key = v.slice(0, 2000);
      save(s);
      keyInput.value = '';
      O.toast(t('vpn.key.ok'), { kind: 'good', icon: 'key' });
      paint();
    });
    var dropKey = O.el('button', { class: 'btn btn--ghost', type: 'button' }, [O.icon('trash', 16), O.el('span', { text: t('vpn.key.remove') })]);
    dropKey.addEventListener('click', function () {
      var s = load();
      s.key = '';
      save(s);
      paint();
    });
    var clearLog = O.el('button', { class: 'link-btn', type: 'button', text: t('vpn.log.clear') });
    clearLog.addEventListener('click', function () {
      var s = load();
      s.log = [];
      save(s);
      paint();
    });
    var openApp = O.el('a', { class: 'btn btn--ghost' }, [O.icon('external', 16), O.el('span', { text: t('vpn.openApp') })]);
    O.link(openApp, O.sites.vpnUrl, { type: 'site', text: 'Орбита VPN', url: O.sites.vpnUrl });

    page.appendChild(O.pageHead('shield', 'Орбита VPN', t('vpn.sub'), [openApp]));
    page.appendChild(O.el('section', { class: 'vpn__hero' }, [ring, status, errBox, countryBtn]));
    page.appendChild(O.el('section', { class: 'sgroup' }, [
      O.el('h2', { class: 'sgroup__title' }, [O.icon('key', 18), O.el('span', { text: t('vpn.key') })]),
      O.el('p', { class: 'vpn__hint', text: t('vpn.key.hint') }),
      keyInput,
      keyState,
      O.el('div', { class: 'vpn__row' }, [saveKey, dropKey])
    ]));
    page.appendChild(O.el('section', { class: 'sgroup' }, [
      O.el('h2', { class: 'sgroup__title' }, [O.icon('list', 18), O.el('span', { text: t('vpn.errors') }), clearLog]),
      O.el('p', { class: 'vpn__hint', text: t('vpn.note') }),
      logEl
    ]));
    root.appendChild(page);
    paint();
    var off = O.on('lang', paint);
    return function () {
      off();
      if (timer) {
        clearTimeout(timer);
      }
    };
  }

  O.registerPage('vpn', { icon: 'shield', title: function () { return 'Орбита VPN'; }, singleton: true, build: build });

  /* the lead card of the Tools page */
  O.toolLead = function (card) {
    var s = load();
    var open = O.el('button', { class: 'btn btn--primary', type: 'button' }, [O.icon('shield', 16), O.el('span', { text: t('vpn.open') })]);
    open.addEventListener('click', function () { O.tabs.open('vpn'); });
    var node = card('shield', 'Орбита VPN', [
      O.el('p', { class: 'vpn__lead', text: s.key ? t('vpn.lead.key') : t('vpn.lead.nokey') }),
      O.el('div', { class: 'vpn__row' }, [open, O.el('span', { class: 'vpn__chip', text: nameOf(s.country) })])
    ], 'tool--vpn');
    return node;
  };
})();
