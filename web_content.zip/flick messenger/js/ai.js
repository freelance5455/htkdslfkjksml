/* Orbita AI mode: Claude is pinned as the main assistant, other assistants can be picked and asked */
(function () {
  'use strict';
  var O = window.Orbita;
  var t = O.t;

  /* ask: link template that takes the question (%s). Without it the site opens and the question is copied. */
  var LIST = [
    { id: 'claude', name: 'Claude', by: 'Anthropic', url: 'https://claude.ai/', ask: 'https://claude.ai/new?q=%s', hue: 16, main: true },
    { id: 'chatgpt', name: 'ChatGPT', by: 'OpenAI', url: 'https://chatgpt.com/', ask: 'https://chatgpt.com/?q=%s', hue: 165 },
    { id: 'gemini', name: 'Gemini', by: 'Google', url: 'https://gemini.google.com/app', ask: null, hue: 222 },
    { id: 'grok', name: 'Grok', by: 'xAI', url: 'https://grok.com/', ask: 'https://grok.com/?q=%s', hue: 270 },
    { id: 'perplexity', name: 'Perplexity', by: 'Perplexity AI', url: 'https://www.perplexity.ai/', ask: 'https://www.perplexity.ai/search?q=%s', hue: 190 },
    { id: 'copilot', name: 'Copilot', by: 'Microsoft', url: 'https://copilot.microsoft.com/', ask: 'https://copilot.microsoft.com/?q=%s', hue: 205 },
    { id: 'deepseek', name: 'DeepSeek', by: 'DeepSeek', url: 'https://chat.deepseek.com/', ask: null, hue: 232 },
    { id: 'mistral', name: 'Le Chat', by: 'Mistral AI', url: 'https://chat.mistral.ai/chat', ask: 'https://chat.mistral.ai/chat?q=%s', hue: 28 }
  ];

  function byId(id) {
    for (var i = 0; i < LIST.length; i++) {
      if (LIST[i].id === id) {
        return LIST[i];
      }
    }
    return null;
  }

  function chosen() {
    return byId(O.settings.get('aiChoice')) || LIST[0];
  }

  function askUrl(ai, question) {
    return ai.ask ? ai.ask.replace('%s', encodeURIComponent(question)) : ai.url;
  }

  /* send a question; call inside a click or key handler so the new tab is allowed to open */
  function ask(ai, question) {
    var q = String(question || '').trim();
    var url = q ? askUrl(ai, q) : ai.url;
    if (q && !ai.ask) {
      O.copy(q).then(function (ok) {
        O.toast(ok ? t('ai.copied', { name: ai.name }) : t('h.copyFail'), { kind: ok ? 'good' : 'warn', icon: 'spark', ms: 4600 });
      });
    }
    O.history.add({ type: 'site', text: q ? ai.name + ': ' + q : ai.name, url: url });
    O.open(url);
  }

  O.ai = {
    list: LIST,
    get: byId,
    chosen: chosen,
    askUrl: askUrl,
    ask: ask
  };

  /* ---------- page ---------- */
  function build(root) {
    var draft = '';
    var page = O.el('div', { class: 'page page--ai' });
    root.appendChild(page);

    function askPanel() {
      var ai = chosen();
      var input = O.el('textarea', {
        class: 'aiask__input',
        id: 'ai-question',
        rows: '3',
        placeholder: t('ai.ask.ph'),
        'aria-label': t('ai.ask.ph'),
        maxlength: '2000'
      });
      input.value = draft;
      input.addEventListener('input', function () {
        draft = input.value;
      });

      var send = O.el('button', { class: 'btn btn--primary', type: 'button' }, [
        O.icon('spark', 16),
        O.el('span', { text: t('ai.ask.in', { name: ai.name }) })
      ]);
      function submit() {
        if (!draft.trim()) {
          O.toast(t('ai.empty'), { kind: 'warn' });
          input.focus();
          return;
        }
        ask(ai, draft);
      }
      send.addEventListener('click', submit);
      input.addEventListener('keydown', function (event) {
        if (event.key === 'Enter' && (event.ctrlKey || event.metaKey)) {
          event.preventDefault();
          submit();
        }
      });

      return O.el('section', { class: 'aiask spot' }, [
        O.el('div', { class: 'aiask__who' }, [
          O.avatars.el('ai:' + ai.id, ai.name, ai.hue),
          O.el('div', { class: 'aiask__text' }, [
            O.el('span', { class: 'aiask__label', text: t('ai.asking') }),
            O.el('strong', { text: ai.name })
          ])
        ]),
        input,
        O.el('div', { class: 'aiask__foot' }, [
          O.el('span', { class: 'aiask__note', text: ai.ask ? t('ai.note.direct') : t('ai.note.copy') }),
          send
        ])
      ]);
    }

    function openLink(ai, label, cls) {
      var a = O.el('a', { class: cls || 'btn btn--ghost' }, [O.el('span', { text: label }), O.icon('external', 16)]);
      O.link(a, ai.url, { type: 'site', text: ai.name, url: ai.url });
      return a;
    }

    function pickButton(ai) {
      var on = chosen().id === ai.id;
      var btn = O.el('button', {
        class: 'btn ' + (on ? 'btn--primary' : 'btn--ghost') + ' btn--sm',
        type: 'button',
        'aria-pressed': on ? 'true' : 'false'
      }, [on ? O.icon('check', 14) : null, O.el('span', { text: on ? t('ai.picked') : t('ai.pick') })]);
      btn.addEventListener('click', function () {
        O.settings.set('aiChoice', ai.id);
      });
      return btn;
    }

    function pinned() {
      var ai = LIST[0];
      return O.el('section', { class: 'aipin spot' }, [
        O.avatars.el('ai:' + ai.id, ai.name, ai.hue, true),
        O.el('div', { class: 'aipin__text' }, [
          O.el('span', { class: 'aipin__badge' }, [O.icon('star', 14), O.el('span', { text: t('ai.main') })]),
          O.el('strong', { class: 'aipin__name', text: ai.name }),
          O.el('span', { class: 'aipin__by', text: ai.by }),
          O.el('span', { class: 'aipin__desc', text: t('ai.claude.d') })
        ]),
        O.el('div', { class: 'aipin__actions' }, [openLink(ai, t('ai.open'), 'btn btn--primary'), pickButton(ai)].concat(O.avatars.buttons('ai:' + ai.id)))
      ]);
    }

    function grid() {
      var box = O.el('div', { class: 'aigrid' });
      LIST.slice(1).forEach(function (ai) {
        var on = chosen().id === ai.id;
        box.appendChild(O.el('article', { class: 'aicard spot' + (on ? ' is-on' : '') }, [
          O.el('div', { class: 'aicard__top' }, [
            O.avatars.el('ai:' + ai.id, ai.name, ai.hue),
            O.el('div', { class: 'aicard__id' }, [
              O.el('strong', { text: ai.name }),
              O.el('span', { text: ai.by })
            ])
          ]),
          O.el('p', { class: 'aicard__desc', text: t('ai.' + ai.id + '.d') }),
          O.el('div', { class: 'aicard__actions' }, [openLink(ai, t('ai.open')), pickButton(ai)].concat(O.avatars.buttons('ai:' + ai.id)))
        ]));
      });
      O.stagger(box);
      return box;
    }

    function render() {
      O.clear(page);
      page.appendChild(O.pageHead('spark', t('tab.ai'), t('ai.sub')));
      page.appendChild(askPanel());
      page.appendChild(pinned());
      page.appendChild(O.el('h2', { class: 'block__title', text: t('ai.others') }));
      page.appendChild(grid());
      page.appendChild(O.el('p', { class: 'sgroup__note', text: t('ai.local') }));
    }

    render();
    var off = O.on('settings:aiChoice', render);
    var offIcons = O.on('icons', render);
    return function () {
      off();
      offIcons();
    };
  }

  O.registerPage('ai', {
    icon: 'spark',
    titleKey: 'tab.ai',
    singleton: true,
    build: build
  });
})();
