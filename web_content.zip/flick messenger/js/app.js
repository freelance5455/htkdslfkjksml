/* Orbita app: wires the browser chrome, shortcuts, and starts everything */
(function () {
  'use strict';
  var O = window.Orbita;
  var t = O.t;

  function isTyping(target) {
    if (!target || !target.tagName) {
      return false;
    }
    var tag = target.tagName.toLowerCase();
    return tag === 'input' || tag === 'textarea' || tag === 'select' || target.isContentEditable;
  }

  function themeIcon() {
    var chosen = O.settings.get('theme');
    var eff = chosen === 'system' ? O.theme.effective() : chosen;
    return eff === 'light' ? 'sun' : (eff === 'dark' ? 'moon' : 'contrast');
  }

  function mainMenu(anchor) {
    var items = [
      { label: t('tab.ai'), icon: 'spark', onClick: function () { O.tabs.open('ai'); } },
      {
        label: 'Орбита VPN',
        icon: 'shield',
        onClick: function () {
          O.history.add({ type: 'site', text: 'Орбита VPN', url: O.sites.vpnUrl });
          O.open(O.sites.vpnUrl);
        }
      },
      { label: t('tab.widgets'), icon: 'grid', onClick: function () { O.tabs.open('widgets'); } },
      { label: t('tab.reading'), icon: 'bookmark', onClick: function () { O.tabs.open('reading'); } },
      { label: t('tab.recent'), icon: 'clock', onClick: function () { O.tabs.open('recent'); } },
      { label: t('tab.history'), icon: 'history', onClick: function () { O.tabs.open('history'); } },
      { label: t('tab.bookmarks'), icon: 'star', onClick: function () { O.tabs.open('bookmarks'); } },
      { label: t('tab.tools'), icon: 'tools', onClick: function () { O.tabs.open('tools'); } },
      { label: t('tab.settings'), icon: 'gear', onClick: function () { O.tabs.open('settings'); } },
      { separator: true }
    ];
    if (O.mobile && O.mobile.isMobile()) {
      items.push({ label: t('bar.theme'), icon: themeIcon(), onClick: function () { O.theme.next(); } });
      items.push({
        label: t('bar.lang'),
        icon: 'globe',
        hint: O.i18n.short[O.i18n.current()],
        onClick: function () {
          var next = O.i18n.langs[(O.i18n.langs.indexOf(O.i18n.current()) + 1) % O.i18n.langs.length];
          O.i18n.set(next);
          O.toast(O.i18n.names[next], { icon: 'globe' });
        }
      });
      items.push({ label: t('bar.palette'), icon: 'command', onClick: function () { O.palette.open(); } });
    } else {
      items.push({ label: t('k.title'), icon: 'keyboard', hint: '?', onClick: function () { O.palette.showShortcuts(); } });
    }
    O.menu.open(anchor, items);
  }
  O.mainMenu = mainMenu;

  function boot() {
    /* icons for static buttons */
    O.$$('[data-icon]').forEach(function (node) {
      node.insertBefore(O.icon(node.getAttribute('data-icon'), parseInt(node.getAttribute('data-icon-size') || '20', 10)), node.firstChild);
    });

    O.ui.init(O.$('#overlays'), O.$('#toasts'));
    O.fx.init(O.$('#fx'));
    O.i18n.apply(document);

    /* ----- toolbar ----- */
    var themeBtn = O.$('#btnTheme');
    var langBtn = O.$('#btnLang');

    function paintToolbar() {
      var holder = O.$('.ic-wrap', themeBtn);
      if (holder) {
        themeBtn.replaceChild(O.icon(themeIcon(), 20), holder);
      }
      langBtn.textContent = O.i18n.short[O.i18n.current()];
      var st = O.settings.get('saveHistory');
      document.documentElement.classList.toggle('is-private', !st);
      ['#btnPrivate', '#btnPrivateM'].forEach(function (sel) {
        var b = O.$(sel);
        var h = b && O.$('.ic-wrap', b);
        if (h) {
          b.replaceChild(O.icon(st ? 'eye' : 'eyeoff', sel === '#btnPrivateM' ? 22 : 20), h);
        }
        if (b) {
          b.classList.toggle('is-on', !st);
        }
      });
    }
    paintToolbar();
    O.on('theme', paintToolbar);
    O.on('lang', function () {
      paintToolbar();
      O.i18n.apply(document);
    });
    O.on('settings:saveHistory', paintToolbar);

    themeBtn.addEventListener('click', function (event) {
      O.theme.next(event);
    });

    langBtn.addEventListener('click', function () {
      var cur = O.i18n.current();
      O.menu.open(langBtn, O.i18n.langs.map(function (code) {
        return {
          label: O.i18n.names[code],
          hint: O.i18n.short[code],
          checked: code === cur,
          onClick: function () { O.i18n.set(code); }
        };
      }));
    });

    O.$('#btnPalette').addEventListener('click', function () { O.palette.open(); });
    O.$('#btnReload').addEventListener('click', function (event) {
      var icon = event.currentTarget.querySelector('.ic-wrap');
      if (icon && O.animated()) {
        icon.classList.remove('spin');
        void icon.offsetWidth;
        icon.classList.add('spin');
      }
      O.tabs.reload();
    });
    O.$('#btnHome').addEventListener('click', function () {
      var tab = O.tabs.active();
      if (tab && tab.type !== 'home') {
        O.tabs.open('home');
      } else {
        O.tabs.reload();
      }
    });
    O.$('#brand').addEventListener('click', function () {
      O.tabs.open('home');
    });
    O.$('#newTab').addEventListener('click', function () {
      O.tabs.open('home');
    });

    O.$('#btnMenu').addEventListener('click', function (event) {
      mainMenu(event.currentTarget);
    });

    /* phone extras */
    O.$('#brandM').addEventListener('click', function () {
      O.tabs.focus('home');
    });
    function togglePrivate() {
      var on = !O.settings.get('saveHistory');
      O.settings.set('saveHistory', on);
      O.toast(on ? t('m.private.off') : t('m.private.on'), { icon: on ? 'eye' : 'eyeoff' });
    }
    O.$('#btnPrivate').addEventListener('click', togglePrivate);
    O.$('#btnPrivateM').addEventListener('click', togglePrivate);
    O.togglePrivate = togglePrivate;

    /* omnibox */
    var omniInput = O.$('#omniInput');
    O.search.create({
      input: omniInput,
      go: O.$('#omniGo'),
      dropdown: O.$('#omniSuggest')
    });

    /* ----- tabs ----- */
    O.tabs.init(O.$('#tabs'), O.$('#views'));
    O.mobile.init();

    /* ----- keyboard ----- */
    document.addEventListener('keydown', function (event) {
      var key = event.key;
      var mod = event.ctrlKey || event.metaKey;

      if (mod && key.toLowerCase() === 'k') {
        event.preventDefault();
        O.palette.open();
        return;
      }
      if (key === 'Escape') {
        if (O.ui.closeTop()) {
          event.preventDefault();
        }
        return;
      }
      if (event.altKey && !mod) {
        var k = key.toLowerCase();
        if (k === 't') {
          event.preventDefault();
          O.tabs.open('home');
        } else if (k === 'w') {
          event.preventDefault();
          var active = O.tabs.active();
          if (active) {
            O.tabs.close(active.id);
          }
        } else if (key === ',' || key === '<') {
          event.preventDefault();
          O.tabs.prev();
        } else if (key === '.' || key === '>') {
          event.preventDefault();
          O.tabs.next();
        } else if (k === 'd') {
          event.preventDefault();
          O.theme.next();
        }
        return;
      }
      if (isTyping(event.target) || mod || O.ui.hasOverlay()) {
        return;
      }
      if (key === '/') {
        event.preventDefault();
        var target = O.$('#views .view:not([hidden]) .bar__input') || omniInput;
        target.focus();
        target.select();
      } else if (key === '?') {
        event.preventDefault();
        O.palette.showShortcuts();
      }
    });

    /* first visit welcome */
    if (!O.store.get('welcomed', false)) {
      O.store.set('welcomed', true);
      setTimeout(function () {
        O.toast(t(O.mobile.isMobile() ? 'toast.welcome.m' : 'toast.welcome'), { kind: 'info', icon: 'orbit', ms: 5200 });
      }, 900);
    }

    document.documentElement.classList.add('is-ready');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
