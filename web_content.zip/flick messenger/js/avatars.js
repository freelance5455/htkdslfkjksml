/* Orbita avatars: your own pictures instead of letters for sites and AI assistants.
   Pictures are resized in the page and stored only in this browser. */
(function () {
  'use strict';
  var O = window.Orbita;
  var t = O.t;

  var SIZE = 128;
  var MAX_FILE = 8 * 1024 * 1024;

  var map = O.store.get('icons', {});
  if (!map || typeof map !== 'object' || Array.isArray(map)) {
    map = {};
  }

  function save() {
    O.store.set('icons', map);
    O.emit('icons');
  }

  /* read an image file and return a square PNG data URL (center crop) */
  function fit(file) {
    return new Promise(function (resolve, reject) {
      if (!file || !/^image\//.test(file.type) || file.size > MAX_FILE) {
        reject(new Error('bad file'));
        return;
      }
      var url = URL.createObjectURL(file);
      var img = new Image();
      img.onload = function () {
        try {
          var side = Math.min(img.naturalWidth, img.naturalHeight);
          if (!side) {
            throw new Error('empty image');
          }
          var sx = (img.naturalWidth - side) / 2;
          var sy = (img.naturalHeight - side) / 2;
          var canvas = document.createElement('canvas');
          canvas.width = SIZE;
          canvas.height = SIZE;
          canvas.getContext('2d').drawImage(img, sx, sy, side, side, 0, 0, SIZE, SIZE);
          URL.revokeObjectURL(url);
          resolve(canvas.toDataURL('image/png'));
        } catch (err) {
          URL.revokeObjectURL(url);
          reject(err);
        }
      };
      img.onerror = function () {
        URL.revokeObjectURL(url);
        reject(new Error('cannot decode'));
      };
      img.src = url;
    });
  }

  /* open the file picker; resolves with a data URL, or null when nothing was chosen */
  function choose() {
    return new Promise(function (resolve, reject) {
      var input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.style.display = 'none';
      var settled = false;
      input.addEventListener('change', function () {
        settled = true;
        var file = input.files && input.files[0];
        if (input.parentNode) {
          input.parentNode.removeChild(input);
        }
        if (!file) {
          resolve(null);
          return;
        }
        fit(file).then(resolve, reject);
      });
      input.addEventListener('cancel', function () {
        if (!settled) {
          resolve(null);
        }
        if (input.parentNode) {
          input.parentNode.removeChild(input);
        }
      });
      document.body.appendChild(input);
      input.click();
    });
  }

  /* A button that is really a <label> with the file input stretched over it.
     The tap lands on the input itself, so the picker opens on phones and in embedded viewers
     where a script calling input.click() is silently ignored. */
  function picker(className, children, title, onData) {
    var input = O.el('input', { type: 'file', accept: 'image/*', class: 'filepick__input', 'aria-label': title });
    var label = O.el('label', { class: className + ' filepick', title: title }, children);
    label.appendChild(input);
    input.addEventListener('change', function () {
      var file = input.files && input.files[0];
      if (!file) {
        return;
      }
      fit(file).then(onData, function () {
        O.toast(t('ic.bad'), { kind: 'warn' });
      }).then(function () {
        input.value = '';
      });
    });
    return label;
  }

  function imageNode(src, large) {
    var node = O.el('span', { class: 'mono mono--img' + (large ? ' mono--lg' : ''), 'aria-hidden': 'true' });
    node.appendChild(O.el('img', { src: src, alt: '', draggable: 'false' }));
    return node;
  }

  O.avatars = {
    get: function (key) {
      return Object.prototype.hasOwnProperty.call(map, key) ? map[key] : null;
    },
    has: function (key) {
      return !!O.avatars.get(key);
    },
    set: function (key, dataUrl) {
      if (typeof dataUrl === 'string' && dataUrl.indexOf('data:image/') === 0) {
        map[key] = dataUrl;
        save();
      }
    },
    remove: function (key) {
      if (O.avatars.has(key)) {
        delete map[key];
        save();
      }
    },
    all: function () {
      return Object.assign({}, map);
    },
    replaceAll: function (next) {
      map = {};
      if (next && typeof next === 'object' && !Array.isArray(next)) {
        Object.keys(next).forEach(function (key) {
          if (typeof next[key] === 'string' && next[key].indexOf('data:image/') === 0) {
            map[key] = next[key];
          }
        });
      }
      save();
    },
    choose: choose,

    /* choose a picture and store it under a key, with a toast for the result */
    pick: function (key) {
      return choose().then(function (data) {
        if (data) {
          O.avatars.set(key, data);
          O.toast(t('ic.saved'), { kind: 'good', icon: 'check' });
        }
      }).catch(function () {
        O.toast(t('ic.bad'), { kind: 'warn' });
      });
    },

    picker: picker,
    fromData: imageNode,

    /* the avatar for a key: your picture if there is one, otherwise the letter tile */
    el: function (key, name, hue, large) {
      var src = O.avatars.get(key);
      return src ? imageNode(src, large) : O.monogram(name, hue, large);
    },

    /* two small buttons (set picture, remove picture) for cards */
    buttons: function (key) {
      var set = picker('icon-btn icon-btn--sm', [O.icon('upload', 16)], t('ic.set'), function (data) {
        O.avatars.set(key, data);
        O.toast(t('ic.saved'), { kind: 'good', icon: 'check' });
      });
      var list = [set];
      if (O.avatars.has(key)) {
        var del = O.el('button', { class: 'icon-btn icon-btn--sm icon-btn--danger', type: 'button', 'aria-label': t('ic.remove'), title: t('ic.remove') }, [O.icon('trash', 16)]);
        del.addEventListener('click', function () {
          O.avatars.remove(key);
        });
        list.push(del);
      }
      return list;
    }
  };
})();
