/* Orbita themes: system / light / dark / black, accent colors, animated theme switch */
(function () {
  'use strict';
  var O = window.Orbita;

  var ACCENTS = {
    indigo: { light: '#2d4bff', dark: '#7b8fff', black: '#8a9bff' },
    violet: { light: '#8b3dff', dark: '#b88cff', black: '#c39cff' },
    teal: { light: '#009e6e', dark: '#2fe0a8', black: '#3ee8b2' },
    amber: { light: '#e8a800', dark: '#ffc933', black: '#ffd24d' },
    rose: { light: '#ff3d8b', dark: '#ff6fa8', black: '#ff7db0' },
    clay: { light: '#ff6b1a', dark: '#ff8a4a', black: '#ff9660' }
  };

  var ORDER = ['indigo', 'violet', 'teal', 'amber', 'rose', 'clay'];
  var CYCLE = ['light', 'dark', 'black'];

  var mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

  function hexToRgb(hex) {
    var h = hex.replace('#', '');
    return [parseInt(h.substr(0, 2), 16), parseInt(h.substr(2, 2), 16), parseInt(h.substr(4, 2), 16)];
  }

  function luma(hex) {
    var c = hexToRgb(hex).map(function (v) {
      var s = v / 255;
      return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
  }

  function alpha(hex, a) {
    var c = hexToRgb(hex);
    return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')';
  }

  function effective() {
    var chosen = O.settings.get('theme');
    if (chosen === 'light' || chosen === 'dark' || chosen === 'black') {
      return chosen;
    }
    return mq && mq.matches ? 'dark' : 'light';
  }

  function colorFor(name, eff) {
    var set = ACCENTS[name] || ACCENTS.indigo;
    return set[eff || effective()];
  }

  function apply() {
    var root = document.documentElement;
    var chosen = O.settings.get('theme');
    if (chosen === 'system') {
      root.removeAttribute('data-theme');
    } else {
      root.setAttribute('data-theme', chosen);
    }
    var eff = effective();
    var color = colorFor(O.settings.get('accent'), eff);
    root.style.setProperty('--accent', color);
    root.style.setProperty('--on-accent', luma(color) > 0.5 ? '#10121f' : '#ffffff');
    root.style.setProperty('--accent-soft', alpha(color, eff === 'light' ? 0.12 : 0.18));
    root.style.setProperty('--accent-line', alpha(color, 0.5));
    root.setAttribute('data-eff', eff);
    O.emit('theme', eff);
  }

  O.theme = {
    accents: ACCENTS,
    order: ORDER,
    cycle: CYCLE,
    effective: effective,
    color: colorFor,
    apply: apply,
    /* change theme; the new theme spreads out as a circle from the click point */
    set: function (value, event) {
      if (O.settings.get('theme') === value) {
        return;
      }
      var commit = function () {
        O.settings.set('theme', value);
      };
      var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      if (typeof document.startViewTransition !== 'function' || !O.animated() || reduced) {
        commit();
        return;
      }
      var x = event && typeof event.clientX === 'number' && event.clientX > 0 ? event.clientX : window.innerWidth / 2;
      var y = event && typeof event.clientY === 'number' && event.clientY > 0 ? event.clientY : 40;
      var radius = Math.hypot(Math.max(x, window.innerWidth - x), Math.max(y, window.innerHeight - y));
      try {
        var transition = document.startViewTransition(commit);
        transition.ready.then(function () {
          document.documentElement.animate({
            clipPath: [
              'circle(0px at ' + x + 'px ' + y + 'px)',
              'circle(' + radius + 'px at ' + x + 'px ' + y + 'px)'
            ]
          }, {
            duration: 620,
            easing: 'cubic-bezier(.2,.7,.2,1)',
            pseudoElement: '::view-transition-new(root)'
          });
        }).catch(function () { /* transition skipped */ });
      } catch (err) {
        commit();
      }
    },
    next: function (event) {
      var chosen = O.settings.get('theme');
      var current = chosen === 'system' ? effective() : chosen;
      var idx = CYCLE.indexOf(current);
      O.theme.set(CYCLE[(idx + 1) % CYCLE.length], event);
    }
  };

  O.on('settings:theme', apply);
  O.on('settings:accent', apply);
  O.on('settings', function (change) {
    if (change.key === '*') {
      apply();
    }
  });

  if (mq) {
    var onSystemChange = function () {
      if (O.settings.get('theme') === 'system') {
        apply();
      }
    };
    if (mq.addEventListener) {
      mq.addEventListener('change', onSystemChange);
    } else if (mq.addListener) {
      mq.addListener(onSystemChange);
    }
  }

  apply();
})();
