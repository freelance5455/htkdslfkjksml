/* Orbita reading list: save links to read later, mark as read, filter and search */
(function () {
  'use strict';
  var O = window.Orbita;
  var t = O.t;

  var LIMIT = 300;

  function load() {
    var list = O.store.get('reading', []);
    return Array.isArray(list) ? list.filter(function (x) { return x && x.url; }) : [];
  }

  function save(list) {
    O.store.set('reading', list.slice(0, LIMIT));
    O.emit('reading');
  }

  function hueOf(text) {
    var h = 0;
    for (var i = 0; i < text.length; i++) {
      h = (h * 31 + text.charCodeAt(i)) % 360;
    }
    return h;
  }

  function add(rawUrl, rawTitle) {
    var url = O.url.normalize(rawUrl);
    if (!url) {
      return { ok: false, reason: 'url' };
    }
    var list = load();
    for (var i = 0; i < list.length; i++) {
      if (list[i].url === url) {
        return { ok: false, reason: 'dup' };
      }
    }
    var title = String(rawTitle || '').trim() || O.url.host(url);
    list.unshift({ id: O.uid(), url: url, title: title.slice(0, 140), ts: Date.now(), read: false });
    save(list);
    return { ok: true };
  }

  function remove(id) {
    save(load().filter(function (x) { return x.id !== id; }));
  }

  function toggle(id) {
    var list = load();
    list.forEach(function (x) {
      if (x.id === id) {
        x.read = !x.read;
      }
    });
    save(list);
  }

  function build(root) {
    var page = O.el('div', { class: 'page page--reading' });
    var state = { filter: 'all', q: '' };

    var urlInput = O.el('input', { class: 'field__input', type: 'text', inputmode: 'url', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', 'aria-label': t('rl.url'), placeholder: t('rl.url') });
    var titleInput = O.el('input', { class: 'field__input', type: 'text', autocomplete: 'off', 'aria-label': t('rl.title'), placeholder: t('rl.title') });
    var addBtn = O.el('button', { class: 'btn btn--primary', type: 'submit' }, [O.icon('plus', 18), O.el('span', { text: t('rl.add') })]);
    var form = O.el('form', { class: 'rl__form spot' }, [
      O.el('div', { class: 'rl__fields' }, [urlInput, titleInput]),
      addBtn
    ]);
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      var res = add(urlInput.value, titleInput.value);
      if (res.ok) {
        urlInput.value = '';
        titleInput.value = '';
        O.toast(t('rl.added'), { kind: 'good', icon: 'bookmark' });
      } else {
        O.toast(res.reason === 'dup' ? t('rl.dup') : t('b.err.url'), { kind: 'warn', icon: 'bookmark' });
        urlInput.focus();
      }
    });

    var counter = O.el('span', { class: 'rl__count' });
    var clearBtn = O.el('button', { class: 'link-btn', type: 'button', text: t('rl.clearRead') });
    clearBtn.addEventListener('click', function () {
      save(load().filter(function (x) { return !x.read; }));
    });
    var seg = O.segmented([
      { value: 'all', label: t('rl.f.all') },
      { value: 'unread', label: t('rl.f.unread') },
      { value: 'read', label: t('rl.f.read') }
    ], 'all', function (value) {
      state.filter = value;
      paint();
    }, t('rl.title'));
    var search = O.el('input', { class: 'field__input', type: 'search', autocomplete: 'off', 'aria-label': t('rl.search'), placeholder: t('rl.search') });
    search.addEventListener('input', function () {
      state.q = search.value.trim().toLowerCase();
      paint();
    });
    var bar = O.el('div', { class: 'rl__bar' }, [
      O.el('div', { class: 'field--search' }, [O.icon('search', 16), search]),
      seg
    ]);
    var listEl = O.el('div', { class: 'rl__list' });

    page.appendChild(O.pageHead('bookmark', t('rl.heading'), t('rl.sub')));
    page.appendChild(form);
    page.appendChild(bar);
    page.appendChild(O.el('div', { class: 'rl__meta' }, [counter, clearBtn]));
    page.appendChild(listEl);
    root.appendChild(page);

    function row(item) {
      var host = O.url.host(item.url);
      var a = O.el('a', { class: 'rl__link' }, [
        O.el('span', { class: 'rl__title', text: item.title }),
        O.el('span', { class: 'rl__host', text: host + ' · ' + O.fmt.date(item.ts) })
      ]);
      O.link(a, item.url, { type: 'site', text: item.title, url: item.url });
      var done = O.el('button', {
        class: 'icon-btn rl__done' + (item.read ? ' is-on' : ''),
        type: 'button',
        title: item.read ? t('rl.markUnread') : t('rl.markRead'),
        'aria-label': item.read ? t('rl.markUnread') : t('rl.markRead'),
        'aria-pressed': item.read ? 'true' : 'false'
      }, [O.icon('check', 18)]);
      done.addEventListener('click', function () { toggle(item.id); });
      var copy = O.el('button', { class: 'icon-btn icon-btn--sm', type: 'button', title: t('rl.copy'), 'aria-label': t('rl.copy') }, [O.icon('copy', 16)]);
      copy.addEventListener('click', function () {
        O.copy(item.url).then(function () {
          O.toast(t('h.copied'), { kind: 'good', icon: 'copy' });
        });
      });
      var del = O.el('button', { class: 'icon-btn icon-btn--sm', type: 'button', title: t('rl.remove'), 'aria-label': t('rl.remove') }, [O.icon('trash', 16)]);
      del.addEventListener('click', function () { remove(item.id); });
      var node = O.el('div', { class: 'rl__row spot' + (item.read ? ' is-read' : '') }, [
        done,
        O.monogram(host, hueOf(host)),
        a,
        O.el('div', { class: 'rl__acts' }, [copy, del])
      ]);
      return node;
    }

    function paint() {
      var all = load();
      var shown = all.filter(function (x) {
        if (state.filter === 'unread' && x.read) {
          return false;
        }
        if (state.filter === 'read' && !x.read) {
          return false;
        }
        return !state.q || (x.title + ' ' + x.url).toLowerCase().indexOf(state.q) >= 0;
      });
      var unread = all.filter(function (x) { return !x.read; }).length;
      counter.textContent = O.plural('rl.count', all.length, { u: unread });
      clearBtn.hidden = all.length === unread;
      O.clear(listEl);
      if (!shown.length) {
        listEl.appendChild(all.length
          ? O.emptyState('search', t('rl.noMatch'))
          : O.emptyState('bookmark', t('rl.empty'), t('rl.empty.d')));
        return;
      }
      shown.forEach(function (item) {
        listEl.appendChild(row(item));
      });
      O.stagger(listEl);
    }

    paint();
    var off = O.on('reading', paint);
    return function () {
      off();
    };
  }

  O.readlist = { add: add, load: load, remove: remove };

  O.registerPage('reading', {
    icon: 'bookmark',
    titleKey: 'tab.reading',
    singleton: true,
    build: build
  });
})();
