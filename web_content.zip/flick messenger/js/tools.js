/* Orbita tools page: calculator (own parser, no eval), unit converter, stopwatch, password generator */
(function () {
  'use strict';
  var O = window.Orbita;
  var t = O.t;

  function toolCard(iconName, title, nodes, cls) {
    return O.el('article', { class: 'tool spot ' + (cls || '') }, [
      O.el('header', { class: 'tool__head' }, [
        O.el('span', { class: 'widget__icon' }, [O.icon(iconName, 18)]),
        O.el('h2', { class: 'tool__title', text: title })
      ]),
      O.el('div', { class: 'tool__body' }, nodes)
    ]);
  }

  /* ================= calculator ================= */
  var FUNCS = {
    sqrt: Math.sqrt,
    sin: Math.sin,
    cos: Math.cos,
    tan: Math.tan,
    ln: Math.log,
    log: function (x) { return Math.log(x) / Math.LN10; },
    abs: Math.abs,
    round: Math.round,
    floor: Math.floor,
    ceil: Math.ceil
  };

  /* recursive descent: expr -> term (+|- term)*, term -> power (*|/ power)*, power -> unary (^ power)? */
  function evaluate(source) {
    var text = String(source)
      .replace(/×/g, '*')
      .replace(/÷/g, '/')
      .replace(/−/g, '-')
      .replace(/,/g, '.')
      .replace(/\s+/g, '');
    var pos = 0;

    function peek() {
      return text.charAt(pos);
    }

    function fail() {
      throw new Error('bad expression');
    }

    function number() {
      var start = pos;
      while (/[0-9.]/.test(peek())) {
        pos++;
      }
      if (start === pos) {
        fail();
      }
      var raw = text.slice(start, pos);
      if ((raw.match(/\./g) || []).length > 1) {
        fail();
      }
      return parseFloat(raw);
    }

    function identifier() {
      var start = pos;
      while (/[a-z]/i.test(peek())) {
        pos++;
      }
      return text.slice(start, pos).toLowerCase();
    }

    function primary() {
      var c = peek();
      var value;
      if (c === '(') {
        pos++;
        value = expr();
        if (peek() !== ')') {
          fail();
        }
        pos++;
      } else if (/[a-z]/i.test(c)) {
        var name = identifier();
        if (name === 'pi') {
          value = Math.PI;
        } else if (name === 'e') {
          value = Math.E;
        } else if (FUNCS[name] && peek() === '(') {
          pos++;
          var arg = expr();
          if (peek() !== ')') {
            fail();
          }
          pos++;
          value = FUNCS[name](arg);
        } else {
          fail();
        }
      } else {
        value = number();
      }
      while (peek() === '%') {
        pos++;
        value = value / 100;
      }
      return value;
    }

    function unary() {
      if (peek() === '-') {
        pos++;
        return -unary();
      }
      if (peek() === '+') {
        pos++;
        return unary();
      }
      return primary();
    }

    function power() {
      var base = unary();
      if (peek() === '^') {
        pos++;
        return Math.pow(base, power());
      }
      return base;
    }

    function term() {
      var value = power();
      while (peek() === '*' || peek() === '/') {
        var op = text.charAt(pos++);
        var rhs = power();
        value = op === '*' ? value * rhs : value / rhs;
      }
      return value;
    }

    function expr() {
      var value = term();
      while (peek() === '+' || peek() === '-') {
        var op = text.charAt(pos++);
        var rhs = term();
        value = op === '+' ? value + rhs : value - rhs;
      }
      return value;
    }

    if (!text) {
      fail();
    }
    var result = expr();
    if (pos !== text.length || !isFinite(result)) {
      fail();
    }
    return result;
  }

  function formatResult(value) {
    var rounded = parseFloat(value.toPrecision(12));
    return O.fmt.number(rounded, 10);
  }

  function calculator() {
    var history = O.store.get('calc', []);
    if (!Array.isArray(history)) {
      history = [];
    }

    var input = O.el('input', {
      class: 'calc__input',
      id: 'calc-input',
      type: 'text',
      inputmode: 'decimal',
      placeholder: t('tool.calc.ph'),
      'aria-label': t('tool.calc'),
      autocomplete: 'off',
      spellcheck: 'false'
    });
    var preview = O.el('output', { class: 'calc__preview', 'aria-live': 'polite' });
    var log = O.el('ul', { class: 'calc__log' });

    function paintLog() {
      O.clear(log);
      history.slice(0, 4).forEach(function (entry) {
        var li = O.el('li', {}, [
          O.el('span', { class: 'calc__expr', text: entry.expr }),
          O.el('b', { text: '= ' + entry.result })
        ]);
        li.addEventListener('click', function () {
          input.value = entry.expr;
          update();
          input.focus();
        });
        log.appendChild(li);
      });
    }

    function update() {
      var raw = input.value;
      if (!raw.trim()) {
        preview.textContent = '';
        preview.classList.remove('is-error');
        return;
      }
      try {
        preview.textContent = '= ' + formatResult(evaluate(raw));
        preview.classList.remove('is-error');
      } catch (err) {
        preview.textContent = '';
      }
    }

    function commit() {
      var raw = input.value.trim();
      if (!raw) {
        return;
      }
      try {
        var value = evaluate(raw);
        var res = formatResult(value);
        history.unshift({ expr: raw, result: res });
        history = history.slice(0, 12);
        O.store.set('calc', history);
        input.value = String(parseFloat(value.toPrecision(12)));
        preview.textContent = '';
        preview.classList.remove('is-error');
        paintLog();
      } catch (err) {
        preview.textContent = t('tool.err');
        preview.classList.add('is-error');
      }
    }

    input.addEventListener('input', update);
    input.addEventListener('keydown', function (event) {
      if (event.key === 'Enter') {
        event.preventDefault();
        commit();
      }
    });

    var keys = [
      ['C', 'clear', 'keypad__btn--fn'], ['(', '(', 'keypad__btn--fn'], [')', ')', 'keypad__btn--fn'], ['÷', '/', 'keypad__btn--op'],
      ['7', '7'], ['8', '8'], ['9', '9'], ['×', '*', 'keypad__btn--op'],
      ['4', '4'], ['5', '5'], ['6', '6'], ['−', '-', 'keypad__btn--op'],
      ['1', '1'], ['2', '2'], ['3', '3'], ['+', '+', 'keypad__btn--op'],
      ['0', '0'], ['.', '.'], ['⌫', 'back', 'keypad__btn--fn'], ['=', 'equals', 'keypad__btn--eq'],
      ['%', '%', 'keypad__btn--fn'], ['^', '^', 'keypad__btn--fn'], ['√', 'sqrt(', 'keypad__btn--fn'], ['π', 'pi', 'keypad__btn--fn']
    ];
    var pad = O.el('div', { class: 'keypad' });
    keys.forEach(function (k) {
      var btn = O.el('button', { class: 'keypad__btn ' + (k[2] || ''), type: 'button', text: k[0] });
      btn.addEventListener('click', function () {
        if (k[1] === 'clear') {
          input.value = '';
        } else if (k[1] === 'back') {
          input.value = input.value.slice(0, -1);
        } else if (k[1] === 'equals') {
          commit();
          return;
        } else {
          input.value += k[1];
        }
        update();
      });
      pad.appendChild(btn);
    });

    paintLog();
    return toolCard('calc', t('tool.calc'), [input, preview, pad, log], 'tool--calc');
  }

  /* ================= converter ================= */
  var UNITS = {
    length: { m: 1, km: 1000, cm: 0.01, mm: 0.001, mi: 1609.344, ft: 0.3048, in: 0.0254, yd: 0.9144 },
    mass: { kg: 1, g: 0.001, mg: 0.000001, t: 1000, lb: 0.45359237, oz: 0.028349523125 },
    speed: { 'km/h': 1 / 3.6, 'm/s': 1, mph: 0.44704, kn: 0.514444 },
    data: { B: 1, KB: 1024, MB: 1048576, GB: 1073741824, TB: 1099511627776 },
    temp: { '°C': 1, '°F': 1, K: 1 }
  };

  function convertTemp(value, from, to) {
    var c;
    if (from === '°C') {
      c = value;
    } else if (from === '°F') {
      c = (value - 32) * 5 / 9;
    } else {
      c = value - 273.15;
    }
    if (to === '°C') {
      return c;
    }
    if (to === '°F') {
      return c * 9 / 5 + 32;
    }
    return c + 273.15;
  }

  function converter() {
    var category = 'length';
    var amount = O.el('input', {
      class: 'field__input',
      id: 'conv-amount',
      type: 'text',
      inputmode: 'decimal',
      value: '1',
      'aria-label': t('tool.conv.value'),
      autocomplete: 'off'
    });
    var from = O.el('select', { class: 'field__select', id: 'conv-from', 'aria-label': t('tool.conv.from') });
    var to = O.el('select', { class: 'field__select', id: 'conv-to', 'aria-label': t('tool.conv.to') });
    var out = O.el('output', { class: 'conv__out', 'aria-live': 'polite' });
    var swap = O.el('button', { class: 'icon-btn', type: 'button', 'aria-label': t('tool.conv.swap'), title: t('tool.conv.swap') }, [O.icon('swap', 18)]);

    function fillUnits() {
      var names = Object.keys(UNITS[category]);
      [from, to].forEach(function (sel, idx) {
        O.clear(sel);
        names.forEach(function (name) {
          sel.appendChild(O.el('option', { value: name, text: name }));
        });
        sel.value = names[idx === 0 ? 0 : Math.min(1, names.length - 1)];
      });
    }

    function compute() {
      var raw = parseFloat(String(amount.value).replace(',', '.'));
      if (!isFinite(raw)) {
        out.textContent = '—';
        return;
      }
      var result;
      if (category === 'temp') {
        result = convertTemp(raw, from.value, to.value);
      } else {
        var table = UNITS[category];
        result = raw * table[from.value] / table[to.value];
      }
      out.textContent = O.fmt.number(parseFloat(result.toPrecision(10)), 8) + ' ' + to.value;
    }

    var seg = O.segmented([
      { value: 'length', label: t('tool.conv.length') },
      { value: 'mass', label: t('tool.conv.mass') },
      { value: 'temp', label: t('tool.conv.temp') },
      { value: 'speed', label: t('tool.conv.speed') },
      { value: 'data', label: t('tool.conv.data') }
    ], category, function (value) {
      category = value;
      fillUnits();
      compute();
    }, t('tool.conv'));
    seg.classList.add('seg--wrap');

    amount.addEventListener('input', compute);
    from.addEventListener('change', compute);
    to.addEventListener('change', compute);
    swap.addEventListener('click', function () {
      var a = from.value;
      from.value = to.value;
      to.value = a;
      compute();
    });

    fillUnits();
    compute();

    return toolCard('swap', t('tool.conv'), [
      seg,
      O.el('div', { class: 'conv__row' }, [amount, from, swap, to]),
      out
    ], 'tool--conv');
  }

  /* ================= stopwatch (state is module level so it survives re-renders) ================= */
  var sw = { running: false, base: 0, startedAt: 0, laps: [], raf: 0, listeners: [] };

  function swElapsed() {
    return sw.base + (sw.running ? Date.now() - sw.startedAt : 0);
  }

  function swEmit() {
    sw.listeners.slice().forEach(function (fn) {
      fn();
    });
  }

  function swLoop() {
    swEmit();
    if (sw.running) {
      sw.raf = requestAnimationFrame(swLoop);
    }
  }

  function fmtMs(ms) {
    var total = Math.floor(ms / 10);
    var cs = total % 100;
    var s = Math.floor(total / 100) % 60;
    var m = Math.floor(total / 6000);
    return O.pad2(m) + ':' + O.pad2(s) + '.' + O.pad2(cs);
  }

  function stopwatch() {
    var readout = O.el('output', { class: 'sw__time' });
    var laps = O.el('ol', { class: 'sw__laps' });
    var startIcon = O.icon('play', 18);
    var startLabel = O.el('span', { text: t('tool.sw.start') });
    var start = O.el('button', { class: 'btn btn--primary', type: 'button' }, [startIcon, startLabel]);
    var lap = O.el('button', { class: 'btn btn--ghost', type: 'button' }, [O.icon('flag', 16), O.el('span', { text: t('tool.sw.lap') })]);
    var reset = O.el('button', { class: 'icon-btn', type: 'button', 'aria-label': t('tool.sw.reset'), title: t('tool.sw.reset') }, [O.icon('reset', 18)]);

    function paintLaps() {
      O.clear(laps);
      sw.laps.slice().reverse().forEach(function (ms, i) {
        var idx = sw.laps.length - i;
        var prev = idx > 1 ? sw.laps[idx - 2] : 0;
        laps.appendChild(O.el('li', {}, [
          O.el('span', { text: '#' + idx }),
          O.el('span', { text: '+' + fmtMs(ms - prev) }),
          O.el('b', { text: fmtMs(ms) })
        ]));
      });
    }

    function paint() {
      readout.textContent = fmtMs(swElapsed());
      var want = sw.running ? 'pause' : 'play';
      if (startIcon.getAttribute('data-icon') !== want) {
        var fresh = O.icon(want, 18);
        fresh.setAttribute('data-icon', want);
        start.replaceChild(fresh, startIcon);
        startIcon = fresh;
      }
      startLabel.textContent = sw.running ? t('tool.sw.stop') : t('tool.sw.start');
    }

    start.addEventListener('click', function () {
      if (sw.running) {
        sw.base = swElapsed();
        sw.running = false;
        cancelAnimationFrame(sw.raf);
        swEmit();
      } else {
        sw.startedAt = Date.now();
        sw.running = true;
        swLoop();
      }
    });
    lap.addEventListener('click', function () {
      if (swElapsed() > 0) {
        sw.laps.push(swElapsed());
        paintLaps();
      }
    });
    reset.addEventListener('click', function () {
      sw.running = false;
      cancelAnimationFrame(sw.raf);
      sw.base = 0;
      sw.laps = [];
      paintLaps();
      swEmit();
    });

    sw.listeners.push(paint);
    paint();
    paintLaps();

    var node = toolCard('timer', t('tool.stopwatch'), [
      readout,
      O.el('div', { class: 'sw__controls' }, [start, lap, reset]),
      laps
    ], 'tool--sw');
    node.__dispose = function () {
      var i = sw.listeners.indexOf(paint);
      if (i >= 0) {
        sw.listeners.splice(i, 1);
      }
    };
    return node;
  }

  /* ================= password generator ================= */
  var SETS = {
    lower: 'abcdefghijklmnopqrstuvwxyz',
    upper: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
    digits: '0123456789',
    symbols: '!@#$%^&*()-_=+[]{};:,.?'
  };

  function secureInt(max) {
    var cryptoObj = window.crypto || window.msCrypto;
    if (cryptoObj && cryptoObj.getRandomValues) {
      var buf = new Uint32Array(1);
      var limit = Math.floor(4294967296 / max) * max;
      do {
        cryptoObj.getRandomValues(buf);
      } while (buf[0] >= limit);
      return buf[0] % max;
    }
    return Math.floor(Math.random() * max);
  }

  function passwordTool() {
    var opts = { length: 16, lower: true, upper: true, digits: true, symbols: false };
    var out = O.el('output', { class: 'pass__out', 'aria-live': 'polite' });
    var meter = O.el('span', { class: 'meter__fill' });
    var meterLabel = O.el('span', { class: 'meter__label' });
    var lenLabel = O.el('span', { class: 'pass__len' });
    var slider = O.el('input', {
      class: 'range',
      id: 'pass-length',
      type: 'range',
      min: '8',
      max: '48',
      value: String(opts.length),
      'aria-label': t('tool.pass.len')
    });

    function generate() {
      var pool = '';
      var required = [];
      ['lower', 'upper', 'digits', 'symbols'].forEach(function (k) {
        if (opts[k]) {
          pool += SETS[k];
          required.push(SETS[k]);
        }
      });
      if (!pool) {
        out.textContent = '';
        meter.style.setProperty('--w', '0%');
        meterLabel.textContent = '';
        return;
      }
      var chars = required.map(function (set) {
        return set.charAt(secureInt(set.length));
      });
      while (chars.length < opts.length) {
        chars.push(pool.charAt(secureInt(pool.length)));
      }
      for (var i = chars.length - 1; i > 0; i--) {
        var j = secureInt(i + 1);
        var tmp = chars[i];
        chars[i] = chars[j];
        chars[j] = tmp;
      }
      out.textContent = chars.slice(0, opts.length).join('');
      var bits = opts.length * Math.log(pool.length) / Math.LN2;
      var level = bits < 45 ? 'weak' : bits < 70 ? 'ok' : bits < 100 ? 'strong' : 'great';
      meter.style.setProperty('--w', Math.min(100, Math.round(bits)) + '%');
      meter.setAttribute('data-level', level);
      meterLabel.textContent = t('tool.pass.' + level) + ' · ' + Math.round(bits) + ' bit';
    }

    slider.addEventListener('input', function () {
      opts.length = parseInt(slider.value, 10);
      lenLabel.textContent = String(opts.length);
      generate();
    });
    lenLabel.textContent = String(opts.length);

    function toggleRow(key, label) {
      var sw2 = O.switchEl(opts[key], function (on) {
        opts[key] = on;
        if (!opts.lower && !opts.upper && !opts.digits && !opts.symbols) {
          opts.lower = true;
        }
        generate();
      }, label);
      return O.el('div', { class: 'pass__opt' }, [O.el('span', { text: label }), sw2]);
    }

    var gen = O.el('button', { class: 'btn btn--primary', type: 'button' }, [O.icon('reload', 16), O.el('span', { text: t('tool.pass.gen') })]);
    var copy = O.el('button', { class: 'btn btn--ghost', type: 'button' }, [O.icon('copy', 16), O.el('span', { text: t('tool.pass.copy') })]);
    gen.addEventListener('click', generate);
    copy.addEventListener('click', function () {
      if (!out.textContent) {
        return;
      }
      O.copy(out.textContent).then(function (ok) {
        O.toast(ok ? t('h.copied') : t('h.copyFail'), { kind: ok ? 'good' : 'warn' });
      });
    });

    generate();

    return toolCard('key', t('tool.pass'), [
      out,
      O.el('div', { class: 'meter' }, [O.el('span', { class: 'meter__bar' }, [meter]), meterLabel]),
      O.el('div', { class: 'pass__len-row' }, [O.el('span', { text: t('tool.pass.len') }), lenLabel]),
      slider,
      O.el('div', { class: 'pass__opts' }, [
        toggleRow('upper', t('tool.pass.upper')),
        toggleRow('lower', t('tool.pass.lower')),
        toggleRow('digits', t('tool.pass.digits')),
        toggleRow('symbols', t('tool.pass.symbols'))
      ]),
      O.el('div', { class: 'pass__buttons' }, [gen, copy])
    ], 'tool--pass');
  }

  /* ================= page ================= */
  function buildPage(root) {
    var page = O.el('div', { class: 'page page--tools' });
    page.appendChild(O.pageHead('tools', t('tool.title'), t('tool.sub')));
    var grid = O.el('div', { class: 'toolgrid' });
    var sw3 = stopwatch();
    var nodes = [calculator(), converter(), sw3, passwordTool()];
    var lead = O.toolLead ? O.toolLead(toolCard) : null;
    if (lead) {
      nodes.unshift(lead);
    }
    (O.toolExtras || []).forEach(function (make) {
      var extra = make(toolCard);
      if (extra) {
        nodes.push(extra);
      }
    });
    nodes.forEach(function (node) {
      grid.appendChild(node);
    });
    O.stagger(grid);
    page.appendChild(grid);
    root.appendChild(page);
    return function () {
      nodes.forEach(function (node) {
        if (node.__dispose) {
          node.__dispose();
        }
      });
    };
  }

  O.registerPage('tools', {
    icon: 'tools',
    titleKey: 'tab.tools',
    singleton: true,
    build: buildPage
  });
})();
