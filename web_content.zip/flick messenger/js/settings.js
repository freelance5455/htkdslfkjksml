/* Orbita settings: values, persistence, base application (density, motion, font size) */
(function () {
  'use strict';
  var O = window.Orbita;
  var has = Object.prototype.hasOwnProperty;

  var DEFAULTS = {
    lang: null,
    theme: 'system',
    accent: 'indigo',
    bg: 'orbit',
    motion: 'full',
    density: 'cozy',
    fontScale: 1,
    engine: 'google',
    saveHistory: true,
    showClaude: true,
    showClock: true,
    showChips: true,
    aiChoice: 'claude'
  };

  var current = {};

  function load() {
    var saved = O.store.get('settings', {});
    if (!saved || typeof saved !== 'object') {
      saved = {};
    }
    current = {};
    Object.keys(DEFAULTS).forEach(function (key) {
      current[key] = has.call(saved, key) ? saved[key] : DEFAULTS[key];
    });
  }

  load();

  function prefersReducedMotion() {
    return !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  }

  O.settings = {
    defaults: DEFAULTS,
    get: function (key) {
      return current[key];
    },
    all: function () {
      var copy = {};
      Object.keys(current).forEach(function (key) {
        copy[key] = current[key];
      });
      return copy;
    },
    set: function (key, value) {
      if (!has.call(DEFAULTS, key) || current[key] === value) {
        return;
      }
      current[key] = value;
      O.store.set('settings', current);
      O.emit('settings', { key: key, value: value });
      O.emit('settings:' + key, value);
    },
    replace: function (map) {
      Object.keys(DEFAULTS).forEach(function (key) {
        current[key] = has.call(map, key) ? map[key] : DEFAULTS[key];
      });
      O.store.set('settings', current);
      O.settings.applyBase();
      O.emit('settings', { key: '*', value: null });
    },
    reset: function () {
      O.settings.replace({});
    },
    applyBase: function () {
      var root = document.documentElement;
      var motion = current.motion;
      if (motion !== 'off' && prefersReducedMotion()) {
        motion = 'off';
      }
      root.setAttribute('data-motion', motion);
      root.setAttribute('data-density', current.density);
      root.style.fontSize = (16 * current.fontScale).toFixed(2) + 'px';
    }
  };

  O.on('settings', function (change) {
    if (change.key === 'motion' || change.key === 'density' || change.key === 'fontScale') {
      O.settings.applyBase();
    }
  });

  O.settings.applyBase();
})();
