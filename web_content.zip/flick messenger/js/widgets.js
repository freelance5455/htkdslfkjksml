/* Orbita widgets for the home page: clock, notes, to-do list, pomodoro timer, today stats */
(function () {
  'use strict';
  var O = window.Orbita;
  var t = O.t;

  var SVG_NS = 'http://www.w3.org/2000/svg';

  function card(extraClass, iconName, title, bodyNodes, headActions) {
    return O.el('article', { class: 'widget spot ' + (extraClass || '') }, [
      O.el('header', { class: 'widget__head' }, [
        O.el('span', { class: 'widget__icon' }, [O.icon(iconName, 18)]),
        O.el('h3', { class: 'widget__title', text: title }),
        headActions ? O.el('div', { class: 'widget__actions' }, headActions) : null
      ]),
      O.el('div', { class: 'widget__body' }, bodyNodes)
    ]);
  }

  function svg(tag, attrs) {
    var node = document.createElementNS(SVG_NS, tag);
    Object.keys(attrs || {}).forEach(function (k) {
      node.setAttribute(k, attrs[k]);
    });
    return node;
  }

  /* ---------- analog clock ---------- */
  function analogClock() {
    var face = svg('svg', { viewBox: '0 0 120 120', class: 'aclock', role: 'img', 'aria-hidden': 'true' });
    face.appendChild(svg('circle', { cx: 60, cy: 60, r: 56, class: 'aclock__face' }));
    var i;
    for (i = 0; i < 60; i++) {
      var major = i % 5 === 0;
      var a = (i / 60) * Math.PI * 2;
      var r1 = major ? 48 : 52;
      var r2 = 55;
      face.appendChild(svg('line', {
        x1: 60 + Math.sin(a) * r1,
        y1: 60 - Math.cos(a) * r1,
        x2: 60 + Math.sin(a) * r2,
        y2: 60 - Math.cos(a) * r2,
        class: major ? 'aclock__tick aclock__tick--major' : 'aclock__tick'
      }));
    }
    var hour = svg('line', { x1: 60, y1: 62, x2: 60, y2: 36, class: 'aclock__hand aclock__hand--h' });
    var minute = svg('line', { x1: 60, y1: 64, x2: 60, y2: 22, class: 'aclock__hand aclock__hand--m' });
    var second = svg('line', { x1: 60, y1: 68, x2: 60, y2: 16, class: 'aclock__hand aclock__hand--s' });
    face.appendChild(hour);
    face.appendChild(minute);
    face.appendChild(second);
    face.appendChild(svg('circle', { cx: 60, cy: 60, r: 3.4, class: 'aclock__pin' }));

    function tick() {
      var d = new Date();
      var s = d.getSeconds() + d.getMilliseconds() / 1000;
      var m = d.getMinutes() + s / 60;
      var h = (d.getHours() % 12) + m / 60;
      hour.setAttribute('transform', 'rotate(' + (h * 30) + ' 60 60)');
      minute.setAttribute('transform', 'rotate(' + (m * 6) + ' 60 60)');
      second.setAttribute('transform', 'rotate(' + (s * 6) + ' 60 60)');
    }

    var timer = null;
    function run() {
      tick();
      timer = setInterval(tick, O.animated() ? 120 : 1000);
    }
    run();

    return {
      el: face,
      dispose: function () {
        clearInterval(timer);
      }
    };
  }

  /* ---------- notes ---------- */
  function notes() {
    var saved = O.store.get('notes', '');
    var area = O.el('textarea', {
      class: 'notes__area',
      id: 'notes-area',
      placeholder: t('w.notes.ph'),
      'aria-label': t('w.notes'),
      spellcheck: 'false',
      rows: '6'
    });
    area.value = typeof saved === 'string' ? saved : '';

    var count = O.el('span', { class: 'notes__count' });
    var state = O.el('span', { class: 'notes__state', text: '' });

    function words(text) {
      var m = text.trim().match(/\S+/g);
      return m ? m.length : 0;
    }

    function updateCount() {
      count.textContent = O.plural('w.notes.words', words(area.value));
    }

    var flash = null;
    var persist = O.debounce(function () {
      O.store.set('notes', area.value);
      state.textContent = t('w.notes.saved');
      state.classList.add('is-on');
      clearTimeout(flash);
      flash = setTimeout(function () {
        state.classList.remove('is-on');
      }, 1400);
    }, 450);

    area.addEventListener('input', function () {
      updateCount();
      persist();
    });
    updateCount();

    var clear = O.el('button', { class: 'icon-btn', type: 'button', 'aria-label': t('w.notes.clear'), title: t('w.notes.clear') }, [O.icon('trash', 16)]);
    clear.addEventListener('click', function () {
      if (!area.value) {
        return;
      }
      area.value = '';
      O.store.set('notes', '');
      updateCount();
      area.focus();
    });

    var el = card('widget--notes', 'note', t('w.notes'), [
      area,
      O.el('div', { class: 'notes__foot' }, [count, state])
    ], [clear]);

    return { el: el, dispose: function () { clearTimeout(flash); } };
  }

  /* ---------- to-do list ---------- */
  function todo() {
    var list = O.store.get('todos', null);
    if (!Array.isArray(list)) {
      list = [];
    }

    function save() {
      O.store.set('todos', list);
    }

    var CIRC = 2 * Math.PI * 15;
    var ringFill = svg('circle', { cx: 18, cy: 18, r: 15, class: 'ring__fill' });
    ringFill.style.strokeDasharray = String(CIRC);
    var ring = svg('svg', { viewBox: '0 0 36 36', class: 'ring', 'aria-hidden': 'true' });
    ring.appendChild(svg('circle', { cx: 18, cy: 18, r: 15, class: 'ring__track' }));
    ring.appendChild(ringFill);
    var ringText = O.el('span', { class: 'ring__text' });
    var progress = O.el('div', { class: 'ringbox' }, [ring, ringText]);

    var input = O.el('input', {
      class: 'field__input',
      id: 'todo-input',
      type: 'text',
      placeholder: t('w.todo.ph'),
      'aria-label': t('w.todo.ph'),
      autocomplete: 'off',
      maxlength: '120'
    });
    var addBtn = O.el('button', { class: 'icon-btn icon-btn--accent', type: 'button', 'aria-label': t('w.todo.add'), title: t('w.todo.add') }, [O.icon('plus', 18)]);
    var ul = O.el('ul', { class: 'todo__list' });
    var summary = O.el('span', { class: 'todo__summary' });
    var clearDone = O.el('button', { class: 'link-btn', type: 'button', text: t('w.todo.clear') });

    function paintProgress() {
      var done = list.filter(function (x) { return x.done; }).length;
      var total = list.length;
      var ratio = total ? done / total : 0;
      ringFill.style.strokeDashoffset = String(CIRC * (1 - ratio));
      ringText.textContent = total ? Math.round(ratio * 100) + '%' : '0%';
      summary.textContent = total ? t('w.todo.left', { n: total - done }) : '';
      clearDone.hidden = done === 0;
    }

    function render() {
      O.clear(ul);
      if (!list.length) {
        ul.appendChild(O.el('li', { class: 'todo__empty', text: t('w.todo.empty') }));
      }
      list.forEach(function (item) {
        var box = O.el('button', {
          class: 'check' + (item.done ? ' is-on' : ''),
          type: 'button',
          role: 'checkbox',
          'aria-checked': item.done ? 'true' : 'false',
          'aria-label': item.text
        }, [O.icon('check', 14)]);
        var del = O.el('button', { class: 'icon-btn icon-btn--danger icon-btn--sm', type: 'button', 'aria-label': t('h.delete'), title: t('h.delete') }, [O.icon('close', 14)]);
        var li = O.el('li', { class: 'todo__item' + (item.done ? ' is-done' : '') }, [
          box,
          O.el('span', { class: 'todo__text', text: item.text }),
          del
        ]);
        box.addEventListener('click', function () {
          item.done = !item.done;
          save();
          li.classList.toggle('is-done', item.done);
          box.classList.toggle('is-on', item.done);
          box.setAttribute('aria-checked', item.done ? 'true' : 'false');
          paintProgress();
        });
        del.addEventListener('click', function () {
          li.classList.add('is-leaving');
          setTimeout(function () {
            list = list.filter(function (x) { return x !== item; });
            save();
            render();
          }, O.animated() ? 180 : 0);
        });
        ul.appendChild(li);
      });
      paintProgress();
    }

    function add() {
      var text = input.value.trim();
      if (!text) {
        return;
      }
      list.unshift({ id: O.uid(), text: text, done: false });
      save();
      input.value = '';
      render();
      var first = O.$('.todo__item', ul);
      if (first) {
        first.classList.add('is-new');
      }
    }

    input.addEventListener('keydown', function (event) {
      if (event.key === 'Enter') {
        event.preventDefault();
        add();
      }
    });
    addBtn.addEventListener('click', add);
    clearDone.addEventListener('click', function () {
      list = list.filter(function (x) { return !x.done; });
      save();
      render();
    });

    render();

    var el = card('widget--todo', 'list', t('w.todo'), [
      O.el('div', { class: 'todo__top' }, [progress, O.el('div', { class: 'todo__add' }, [input, addBtn])]),
      ul,
      O.el('div', { class: 'todo__foot' }, [summary, clearDone])
    ]);
    return { el: el, dispose: function () {} };
  }

  /* ---------- pomodoro (engine lives outside the widget so it survives re-renders) ---------- */
  var MODES = { focus: 25 * 60, short: 5 * 60, long: 15 * 60 };
  var pomo = {
    mode: 'focus',
    total: MODES.focus,
    left: MODES.focus,
    running: false,
    endAt: 0,
    timer: null,
    done: 0,
    listeners: []
  };

  (function restorePomo() {
    var saved = O.store.get('pomodoro', null);
    var today = O.fmt.dayKey(Date.now());
    if (saved && saved.day === today && typeof saved.done === 'number') {
      pomo.done = saved.done;
    }
  })();

  function pomoEmit() {
    pomo.listeners.slice().forEach(function (fn) {
      fn();
    });
  }

  function beep() {
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) {
        return;
      }
      var ac = new AC();
      [0, 0.22, 0.44].forEach(function (delay, i) {
        var osc = ac.createOscillator();
        var gain = ac.createGain();
        osc.type = 'sine';
        osc.frequency.value = 660 + i * 110;
        gain.gain.setValueAtTime(0.0001, ac.currentTime + delay);
        gain.gain.exponentialRampToValueAtTime(0.18, ac.currentTime + delay + 0.03);
        gain.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + delay + 0.22);
        osc.connect(gain);
        gain.connect(ac.destination);
        osc.start(ac.currentTime + delay);
        osc.stop(ac.currentTime + delay + 0.25);
      });
    } catch (err) { /* audio is optional */ }
  }

  function pomoFinish() {
    clearInterval(pomo.timer);
    pomo.running = false;
    pomo.left = 0;
    if (pomo.mode === 'focus') {
      pomo.done++;
      O.store.set('pomodoro', { day: O.fmt.dayKey(Date.now()), done: pomo.done });
    }
    beep();
    O.toast(t('w.pomo.done'), { kind: 'good', icon: 'timer', ms: 5000 });
    pomoEmit();
  }

  function pomoTick() {
    pomo.left = Math.max(0, Math.round((pomo.endAt - Date.now()) / 1000));
    if (pomo.left <= 0) {
      pomoFinish();
      return;
    }
    pomoEmit();
  }

  var pomoApi = {
    start: function () {
      if (pomo.running) {
        return;
      }
      if (pomo.left <= 0) {
        pomo.left = pomo.total;
      }
      pomo.running = true;
      pomo.endAt = Date.now() + pomo.left * 1000;
      pomo.timer = setInterval(pomoTick, 250);
      pomoEmit();
    },
    pause: function () {
      if (!pomo.running) {
        return;
      }
      pomoTick();
      clearInterval(pomo.timer);
      pomo.running = false;
      pomoEmit();
    },
    reset: function () {
      clearInterval(pomo.timer);
      pomo.running = false;
      pomo.left = pomo.total;
      pomoEmit();
    },
    setMode: function (mode) {
      clearInterval(pomo.timer);
      pomo.running = false;
      pomo.mode = mode;
      pomo.total = MODES[mode];
      pomo.left = pomo.total;
      pomoEmit();
    }
  };

  function pomodoro() {
    var CIRC = 2 * Math.PI * 52;
    var arc = svg('circle', { cx: 60, cy: 60, r: 52, class: 'dial__arc', transform: 'rotate(-90 60 60)' });
    arc.style.strokeDasharray = String(CIRC);
    var dial = svg('svg', { viewBox: '0 0 120 120', class: 'dial', 'aria-hidden': 'true' });
    dial.appendChild(svg('circle', { cx: 60, cy: 60, r: 52, class: 'dial__track' }));
    dial.appendChild(arc);

    var readout = O.el('span', { class: 'pomo__time', role: 'timer' });
    var sub = O.el('span', { class: 'pomo__mode' });
    var face = O.el('div', { class: 'pomo__face' }, [dial, O.el('div', { class: 'pomo__center' }, [readout, sub])]);

    var toggleIcon = O.icon('play', 18);
    var toggleLabel = O.el('span', { text: t('w.pomo.start') });
    var toggle = O.el('button', { class: 'btn btn--primary', type: 'button' }, [toggleIcon, toggleLabel]);
    var reset = O.el('button', { class: 'icon-btn', type: 'button', 'aria-label': t('w.pomo.reset'), title: t('w.pomo.reset') }, [O.icon('reset', 18)]);
    var sessions = O.el('span', { class: 'pomo__sessions' });

    var seg = O.segmented([
      { value: 'focus', label: t('w.pomo.focus') },
      { value: 'short', label: t('w.pomo.short') },
      { value: 'long', label: t('w.pomo.long') }
    ], pomo.mode, function (value) {
      pomoApi.setMode(value);
    }, t('w.pomo'));

    toggle.addEventListener('click', function () {
      if (pomo.running) {
        pomoApi.pause();
      } else {
        pomoApi.start();
      }
    });
    reset.addEventListener('click', pomoApi.reset);

    function paint() {
      var m = Math.floor(pomo.left / 60);
      var s = pomo.left % 60;
      readout.textContent = O.pad2(m) + ':' + O.pad2(s);
      arc.style.strokeDashoffset = String(CIRC * (1 - pomo.left / pomo.total));
      sub.textContent = t('w.pomo.' + pomo.mode);
      face.classList.toggle('is-running', pomo.running);
      var next = pomo.running ? 'pause' : 'play';
      if (toggleIcon.getAttribute('data-icon') !== next) {
        var fresh = O.icon(next, 18);
        fresh.setAttribute('data-icon', next);
        toggle.replaceChild(fresh, toggleIcon);
        toggleIcon = fresh;
      }
      toggleLabel.textContent = pomo.running ? t('w.pomo.pause') : t('w.pomo.start');
      sessions.textContent = O.plural('w.pomo.sessions', pomo.done);
      seg.setValue(pomo.mode);
    }

    pomo.listeners.push(paint);
    paint();

    var el = card('widget--pomo', 'timer', t('w.pomo'), [
      face,
      O.el('div', { class: 'pomo__controls' }, [toggle, reset]),
      seg,
      sessions
    ]);

    return {
      el: el,
      dispose: function () {
        var i = pomo.listeners.indexOf(paint);
        if (i >= 0) {
          pomo.listeners.splice(i, 1);
        }
      }
    };
  }

  /* ---------- today stats ---------- */
  function today() {
    var searchNum = O.el('strong', { class: 'tstat__num', text: '0' });
    var siteNum = O.el('strong', { class: 'tstat__num', text: '0' });
    var totalNum = O.el('strong', { class: 'tstat__num', text: '0' });

    function paint() {
      var st = O.history.stats();
      O.countTo(searchNum, st.todaySearches, 600);
      O.countTo(siteNum, st.todaySites, 600);
      O.countTo(totalNum, st.total, 800, function (v) {
        return O.fmt.number(Math.round(v), 0);
      });
    }
    paint();
    var off = O.on('history', paint);

    var el = card('widget--today', 'stats', t('w.today'), [
      O.el('div', { class: 'tstat' }, [searchNum, O.el('span', { class: 'tstat__label', text: t('w.today.searches') })]),
      O.el('div', { class: 'tstat' }, [siteNum, O.el('span', { class: 'tstat__label', text: t('w.today.sites') })]),
      O.el('div', { class: 'tstat tstat--soft' }, [totalNum, O.el('span', { class: 'tstat__label', text: t('w.today.total') })])
    ]);
    return { el: el, dispose: off };
  }

  O.widgets = {
    analogClock: analogClock,
    notes: notes,
    todo: todo,
    pomodoro: pomodoro,
    today: today
  };
})();
