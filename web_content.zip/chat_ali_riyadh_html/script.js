// شات علي رياض - نسخة HTML تجريبية محلية.
// رمز الإدارة الافتراضي للمعاينة فقط. غيّره قبل أي استخدام حقيقي.
const ADMIN_PIN = "2468";
const $ = (id) => document.getElementById(id);
const keys = {
  name: "aliChatName",
  joined: "aliChatJoinedAt",
  publicMessages: "aliChatPublicMessages",
  adminMessages: "aliChatAdminMessages"
};
let currentRoom = "public";
let adminUnlocked = false;

function readMessages(room) {
  try { return JSON.parse(localStorage.getItem(room === "public" ? keys.publicMessages : keys.adminMessages) || "[]"); }
  catch { return []; }
}
function saveMessages(room, messages) {
  localStorage.setItem(room === "public" ? keys.publicMessages : keys.adminMessages, JSON.stringify(messages));
}
function currentName() { return ($("username").value.trim() || "زائر"); }
function rankForDays(days) {
  if (days >= 30) return "عضو ذهبي";
  if (days >= 14) return "عضو مميز";
  if (days >= 7) return "عضو نشيط";
  if (days >= 3) return "عضو مشارك";
  return "عضو جديد";
}
function updateRank() {
  const joined = Number(localStorage.getItem(keys.joined) || Date.now());
  if (!localStorage.getItem(keys.joined)) localStorage.setItem(keys.joined, String(joined));
  const days = Math.floor((Date.now() - joined) / 86400000);
  $("rank").textContent = rankForDays(days);
  $("avatar").textContent = currentName().slice(0,1);
}
function renderMessages() {
  const area = $("messages");
  area.innerHTML = "";
  if (currentRoom === "admin" && !adminUnlocked) {
    area.classList.add("hidden");
    $("messageForm").classList.add("hidden");
    return;
  }
  area.classList.remove("hidden");
  $("messageForm").classList.remove("hidden");
  const list = readMessages(currentRoom);
  if (!list.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = currentRoom === "public" ? "أهلاً بيك بشات علي رياض 👋\\nاكتب أول رسالة حتى تبدأ الدردشة." : "غرفة الإدارة فارغة حالياً.";
    area.appendChild(empty);
    return;
  }
  list.forEach(msg => {
    const wrap = document.createElement("div");
    wrap.className = "message" + (msg.name === currentName() ? " mine" : "");
    const meta = document.createElement("div");
    meta.className = "message-meta";
    const name = document.createElement("b"); name.textContent = msg.name;
    const time = document.createElement("span"); time.textContent = msg.time;
    meta.append(name, time);
    const body = document.createElement("div");
    body.className = "message-text";
    body.textContent = msg.text;
    wrap.append(meta, body);
    area.appendChild(wrap);
  });
  area.scrollTop = area.scrollHeight;
}
function switchRoom(room) {
  currentRoom = room;
  document.querySelectorAll(".room-tab").forEach(btn => btn.classList.toggle("active", btn.dataset.room === room));
  $("roomTitle").textContent = room === "public" ? "الغرفة العامة" : "غرفة الإدارة";
  $("roomDesc").textContent = room === "public" ? "مكان دردشة الجميع" : "مساحة خاصة للإدارة";
  $("roomPill").textContent = room === "public" ? "عامة" : "خاصة";
  $("pinArea").classList.toggle("hidden", room !== "admin" || adminUnlocked);
  $("pinError").textContent = "";
  $("messageInput").placeholder = room === "public" ? "اكتب رسالتك هنا..." : "اكتب رسالة الإدارة...";
  renderMessages();
}
$("username").value = localStorage.getItem(keys.name) || "";
$("saveName").addEventListener("click", () => {
  const name = $("username").value.trim();
  if (!name) { alert("اكتب اسمك أولاً."); return; }
  localStorage.setItem(keys.name, name);
  updateRank(); renderMessages();
});
$("username").addEventListener("change", updateRank);
document.querySelectorAll(".room-tab").forEach(btn => btn.addEventListener("click", () => switchRoom(btn.dataset.room)));
$("unlockAdmin").addEventListener("click", () => {
  if ($("pinInput").value === ADMIN_PIN) {
    adminUnlocked = true;
    $("pinArea").classList.add("hidden");
    $("pinError").textContent = "";
    renderMessages();
  } else {
    $("pinError").textContent = "رمز PIN غير صحيح.";
  }
});
$("pinInput").addEventListener("keydown", e => { if (e.key === "Enter") $("unlockAdmin").click(); });
$("messageForm").addEventListener("submit", e => {
  e.preventDefault();
  const text = $("messageInput").value.trim();
  if (!text) return;
  if (currentRoom === "admin" && !adminUnlocked) return;
  const messages = readMessages(currentRoom);
  messages.push({ name: currentName(), text, time: new Date().toLocaleTimeString("ar-IQ", {hour:"2-digit", minute:"2-digit"}) });
  saveMessages(currentRoom, messages.slice(-250));
  $("messageInput").value = "";
  renderMessages();
});
updateRank();
renderMessages();
