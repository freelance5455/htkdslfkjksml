package com.sleepplan.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import java.util.Calendar;

public class Scheduler {

    static PendingIntent pi(Context c, int req, int id, boolean snooze) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.putExtra("id", id);
        i.putExtra("snooze", snooze);
        return PendingIntent.getBroadcast(c, req, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static PendingIntent showPi(Context c) {
        Intent i = new Intent(c, MainActivity.class);
        return PendingIntent.getActivity(c, 999, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static void scheduleAll(Context c) {
        for (int i = 0; i < Blocks.N; i++) {
            if (Blocks.enabled(c, i)) schedule(c, i, 0);
            else cancel(c, i);
        }
    }

    public static void cancel(Context c, int i) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(pi(c, i, i, false));
    }

    /** schedules the next daily pre-alert of block i */
    public static void schedule(Context c, int i, long marginMs) {
        long t = next(i, Blocks.lead(c), marginMs);
        set(c, t, pi(c, i, i, false));
    }

    public static void snooze(Context c, int i) {
        set(c, System.currentTimeMillis() + 5 * 60 * 1000L, pi(c, 100 + i, i, true));
    }

    static long next(int i, int lead, long marginMs) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.add(Calendar.MINUTE, Blocks.START[i] - lead);
        while (cal.getTimeInMillis() <= System.currentTimeMillis() + marginMs) {
            cal.add(Calendar.DAY_OF_YEAR, 1);
        }
        return cal.getTimeInMillis();
    }

    static void set(Context c, long t, PendingIntent p) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        try {
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(t, showPi(c)), p);
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p);
        }
    }
}
