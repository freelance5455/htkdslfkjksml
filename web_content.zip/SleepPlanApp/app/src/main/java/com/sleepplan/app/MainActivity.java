package com.sleepplan.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Set;

public class MainActivity extends Activity {
    WebView wv;
    TextToSpeech vt;
    boolean vtReady;
    boolean night;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        int bg = night ? 0xFF10131B : 0xFFF5F3EE;

        if (getIntent().getBooleanExtra("alert", false) && Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        if (!night && Build.VERSION.SDK_INT >= 23) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }

        wv = new WebView(this);
        wv.setBackgroundColor(bg);
        wv.setFitsSystemWindows(true);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        wv.addJavascriptInterface(new Bridge(), "Android");
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                v.evaluateJavascript("document.documentElement.setAttribute('data-theme','"
                        + (night ? "dark" : "light") + "');", null);
            }
        });
        setContentView(wv);
        wv.loadUrl("file:///android_asset/index.html");

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }

        vt = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int st) {
                vtReady = (st == TextToSpeech.SUCCESS);
            }
        });
        Scheduler.scheduleAll(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Scheduler.scheduleAll(this);
        wv.evaluateJavascript("if(window.refresh)refresh();", null);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        wv.evaluateJavascript("if(window.refresh)refresh();", null);
    }

    @Override
    protected void onDestroy() {
        try { if (vt != null) vt.shutdown(); } catch (Exception e) { /* ignore */ }
        super.onDestroy();
    }

    boolean notifOk() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        boolean ok = nm.areNotificationsEnabled();
        if (Build.VERSION.SDK_INT >= 33) {
            ok = ok && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        }
        return ok;
    }

    boolean exactOk() {
        if (Build.VERSION.SDK_INT >= 31) {
            return ((AlarmManager) getSystemService(ALARM_SERVICE)).canScheduleExactAlarms();
        }
        return true;
    }

    boolean battOk() {
        if (Build.VERSION.SDK_INT >= 23) {
            return ((PowerManager) getSystemService(POWER_SERVICE)).isIgnoringBatteryOptimizations(getPackageName());
        }
        return true;
    }

    void open(Intent i) {
        try {
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e2) { /* ignore */ }
        }
    }

    class Bridge {
        @JavascriptInterface
        public String getState() {
            try {
                Context c = MainActivity.this;
                JSONObject o = new JSONObject();
                o.put("lead", Blocks.lead(c));
                o.put("vol", Blocks.vol(c));
                o.put("voice", Blocks.voice(c));
                JSONArray en = new JSONArray();
                for (int i = 0; i < Blocks.N; i++) en.put(Blocks.enabled(c, i));
                o.put("en", en);
                JSONObject p = new JSONObject();
                p.put("notif", notifOk());
                p.put("exact", exactOk());
                p.put("battery", battOk());
                o.put("perm", p);
                JSONArray vs = new JSONArray();
                if (vtReady && vt != null) {
                    Set<Voice> set = vt.getVoices();
                    if (set != null) {
                        for (Voice v : set) {
                            if (v.getLocale() != null && "ar".equals(v.getLocale().getLanguage())) {
                                vs.put(v.getName());
                            }
                        }
                    }
                }
                o.put("voices", vs);
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void setLead(int n) {
            Blocks.p(MainActivity.this).edit().putInt("lead", n).apply();
            Scheduler.scheduleAll(MainActivity.this);
        }

        @JavascriptInterface
        public void setEnabled(int i, boolean on) {
            Blocks.p(MainActivity.this).edit().putBoolean("en" + i, on).apply();
            Scheduler.scheduleAll(MainActivity.this);
        }

        @JavascriptInterface
        public void setVol(int v) {
            Blocks.p(MainActivity.this).edit().putInt("vol", v).apply();
        }

        @JavascriptInterface
        public void setVoice(String name) {
            Blocks.p(MainActivity.this).edit().putString("voice", name == null ? "" : name).apply();
        }

        @JavascriptInterface
        public void testAlert() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent s = new Intent(MainActivity.this, AlertService.class);
                    s.setAction(AlertService.ACT_PLAY);
                    s.putExtra("id", Blocks.nextIndex());
                    try {
                        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s);
                        else startService(s);
                    } catch (Exception e) { /* ignore */ }
                }
            });
        }

        @JavascriptInterface
        public void askPerm(final String kind) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    String pkg = getPackageName();
                    if ("notif".equals(kind)) {
                        if (Build.VERSION.SDK_INT >= 33
                                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
                        } else {
                            Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                            i.putExtra(Settings.EXTRA_APP_PACKAGE, pkg);
                            open(i);
                        }
                    } else if ("exact".equals(kind)) {
                        if (Build.VERSION.SDK_INT >= 31) {
                            open(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + pkg)));
                        }
                    } else if ("battery".equals(kind)) {
                        open(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + pkg)));
                    } else if ("tts".equals(kind)) {
                        open(new Intent("com.android.settings.TTS_SETTINGS"));
                    }
                }
            });
        }
    }
}
