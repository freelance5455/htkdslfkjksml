package com.sleepplan.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        int id = in.getIntExtra("id", 0);
        boolean snooze = in.getBooleanExtra("snooze", false);

        // schedule tomorrow's alert first, so it is never lost
        if (!snooze && Blocks.enabled(c, id)) Scheduler.schedule(c, id, 60000);

        Intent s = new Intent(c, AlertService.class);
        s.setAction(AlertService.ACT_PLAY);
        s.putExtra("id", id);
        try {
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(s);
            else c.startService(s);
        } catch (Exception e) {
            AlertService.fallback(c, id);
        }
    }
}
