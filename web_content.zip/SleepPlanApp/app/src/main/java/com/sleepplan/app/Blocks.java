package com.sleepplan.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;

import java.util.Calendar;
import java.util.Set;

public class Blocks {
    public static final int N = 7;

    public static final String[] NAME = {
            "النوم الأساسي", "الصلاة", "طلب العلم - الجزء الأول", "النوم",
            "طلب العلم - الجزء الثاني", "العمل", "إغلاق الهاتف والاستعداد للنوم"};

    public static final String[] SPOKEN = {
            "النوم الأساسي", "الصلاة", "طلب العلم، الجزء الأول", "النوم",
            "طلب العلم، الجزء الثاني", "العمل", "إغلاق الهاتف والاستعداد للنوم"};

    public static final String[] EMOJI = {"🌌", "🕌", "📖", "😴", "📖", "💼", "📵"};

    // start of each block, in minutes after midnight
    public static final int[] START = {1410, 270, 300, 510, 600, 720, 1380};

    public static final String[] START_L = {"11:30 م", "4:30 ص", "5:00 ص", "8:30 ص", "10:00 ص", "12:00 ظ", "11:00 م"};
    public static final String[] END_L = {"4:30 ص", "5:00 ص", "8:30 ص", "10:00 ص", "12:00 ظ", "11:00 م", "11:30 م"};

    public static final int[] COLOR = {
            0xFF3B5BDB, 0xFFD4A017, 0xFF1F9D8A, 0xFF8A63D2, 0xFF1F9D8A, 0xFFE8803A, 0xFFC2255C};

    public static SharedPreferences p(Context c) {
        return c.getSharedPreferences("plan", Context.MODE_PRIVATE);
    }

    public static int lead(Context c) { return p(c).getInt("lead", 10); }

    public static int vol(Context c) { return p(c).getInt("vol", 90); }

    public static String voice(Context c) { return p(c).getString("voice", ""); }

    public static boolean enabled(Context c, int i) { return p(c).getBoolean("en" + i, true); }

    /** index of the block that starts next (used for the test alert) */
    public static int nextIndex() {
        Calendar now = Calendar.getInstance();
        int m = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);
        int best = 0;
        int bestD = 100000;
        for (int i = 0; i < N; i++) {
            int d = ((START[i] - m) % 1440 + 1440) % 1440;
            if (d == 0) d = 1440;
            if (d < bestD) {
                bestD = d;
                best = i;
            }
        }
        return best;
    }

    /** picks an Arabic voice: the saved one, else one that looks male, else any Arabic voice */
    public static Voice pickVoice(TextToSpeech t, String saved) {
        try {
            Set<Voice> vs = t.getVoices();
            if (vs == null) return null;
            Voice any = null;
            Voice male = null;
            for (Voice v : vs) {
                if (v.getLocale() == null || !"ar".equals(v.getLocale().getLanguage())) continue;
                if (saved != null && !saved.isEmpty() && v.getName().equals(saved)) return v;
                if (any == null) any = v;
                String n = v.getName().toLowerCase();
                if (male == null && n.contains("male") && !n.contains("female")) male = v;
            }
            return male != null ? male : any;
        } catch (Exception e) {
            return null;
        }
    }
}
