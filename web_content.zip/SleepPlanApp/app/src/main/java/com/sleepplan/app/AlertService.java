package com.sleepplan.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import java.util.Locale;

public class AlertService extends Service {
    public static final String ACT_PLAY = "play";
    public static final String ACT_STOP = "stop";
    public static final String ACT_SNOOZE = "snooze";
    static final String CH = "alert_v1";
    static final String FB = "alert_fallback_v1";

    MediaPlayer mp;
    TextToSpeech tts;
    AudioManager am;
    AudioFocusRequest focus;
    PowerManager.WakeLock wl;
    Handler h = new Handler(Looper.getMainLooper());
    int id;
    boolean started, finished, chimeDone, chimeRepeat, ttsReady, ttsFailed, spoke;

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public int onStartCommand(Intent in, int flags, int startId) {
        String a = in == null ? ACT_PLAY : in.getAction();
        id = in == null ? 0 : in.getIntExtra("id", 0);
        if (id < 0 || id >= Blocks.N) id = 0;

        if (ACT_STOP.equals(a)) {
            end(true);
            return START_NOT_STICKY;
        }
        if (ACT_SNOOZE.equals(a)) {
            Scheduler.snooze(this, id);
            end(true);
            return START_NOT_STICKY;
        }
        if (started) return START_NOT_STICKY;
        started = true;

        channels(this);
        Notification n = buildNotif(this, id, CH);
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(100 + id, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(100 + id, n);
        }

        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sleepplan:alert");
            wl.acquire(120000);
        } catch (Exception e) { /* ignore */ }

        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        try {
            int max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM);
            int v = Math.max(1, max * Blocks.vol(this) / 100);
            am.setStreamVolume(AudioManager.STREAM_ALARM, v, 0);
        } catch (Exception e) { /* ignore */ }

        try {
            if (Build.VERSION.SDK_INT >= 26) {
                focus = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                        .setAudioAttributes(attrs()).build();
                am.requestAudioFocus(focus);
            } else {
                am.requestAudioFocus(null, AudioManager.STREAM_ALARM, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
            }
        } catch (Exception e) { /* ignore */ }

        startTts();
        playChime();
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                end(false);
            }
        }, 100000);
        return START_NOT_STICKY;
    }

    static AudioAttributes attrs() {
        return new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
    }

    void playChime() {
        try {
            if (mp != null) {
                mp.release();
                mp = null;
            }
            mp = new MediaPlayer();
            mp.setAudioAttributes(attrs());
            AssetFileDescriptor afd = getResources().openRawResourceFd(R.raw.chime);
            mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            mp.setVolume(1f, 1f);
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer m) {
                    chimeDone = true;
                    next();
                }
            });
            mp.prepare();
            mp.start();
        } catch (Exception e) {
            chimeDone = true;
            next();
        }
    }

    void startTts() {
        try {
            tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int status) {
                    if (finished || tts == null) return;
                    if (status != TextToSpeech.SUCCESS) {
                        ttsFailed = true;
                        next();
                        return;
                    }
                    try {
                        tts.setAudioAttributes(attrs());
                        int r = tts.setLanguage(new Locale("ar"));
                        String saved = Blocks.voice(AlertService.this);
                        Voice v = Blocks.pickVoice(tts, saved);
                        boolean chosen = v != null && !saved.isEmpty() && v.getName().equals(saved);
                        if (v != null) {
                            tts.setVoice(v);
                        } else if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                            ttsFailed = true;
                            next();
                            return;
                        }
                        tts.setPitch(chosen ? 0.95f : 0.8f);
                        tts.setSpeechRate(0.9f);
                        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                            @Override
                            public void onStart(String utteranceId) { }

                            @Override
                            public void onDone(String utteranceId) {
                                if ("u2".equals(utteranceId)) h.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        end(false);
                                    }
                                });
                            }

                            @Override
                            public void onError(String utteranceId) {
                                h.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        end(false);
                                    }
                                });
                            }
                        });
                        ttsReady = true;
                        next();
                    } catch (Exception e) {
                        ttsFailed = true;
                        next();
                    }
                }
            });
        } catch (Exception e) {
            ttsFailed = true;
        }
    }

    /** runs after the chime ends and after the voice engine is ready */
    void next() {
        if (finished || !chimeDone) return;
        if (ttsFailed) {
            if (!chimeRepeat) {
                chimeRepeat = true;
                playChime();
            } else {
                end(false);
            }
            return;
        }
        if (ttsReady && !spoke) {
            spoke = true;
            speak();
        }
    }

    void speak() {
        try {
            String t = "اقترب موعد " + Blocks.SPOKEN[id];
            Bundle b = new Bundle();
            b.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_ALARM);
            b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1f);
            tts.speak(t, TextToSpeech.QUEUE_FLUSH, b, "u1");
            tts.playSilentUtterance(900, TextToSpeech.QUEUE_ADD, "s1");
            tts.speak(t, TextToSpeech.QUEUE_ADD, b, "u2");
        } catch (Exception e) {
            end(false);
        }
    }

    void cleanup() {
        h.removeCallbacksAndMessages(null);
        try { if (mp != null) { mp.release(); mp = null; } } catch (Exception e) { /* ignore */ }
        try { if (tts != null) { tts.stop(); tts.shutdown(); tts = null; } } catch (Exception e) { /* ignore */ }
        try {
            if (am != null && Build.VERSION.SDK_INT >= 26 && focus != null) am.abandonAudioFocusRequest(focus);
        } catch (Exception e) { /* ignore */ }
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception e) { /* ignore */ }
    }

    void end(boolean removeNotif) {
        if (finished) return;
        finished = true;
        cleanup();
        try {
            stopForeground(removeNotif ? Service.STOP_FOREGROUND_REMOVE : Service.STOP_FOREGROUND_DETACH);
        } catch (Exception e) { /* ignore */ }
        if (removeNotif) {
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancel(100 + id);
        }
        stopSelf();
    }

    @Override
    public void onDestroy() {
        finished = true;
        cleanup();
        super.onDestroy();
    }

    // ---------------------------------------------------------------- notification

    static PendingIntent svc(Context c, String action, int id, int req) {
        Intent i = new Intent(c, AlertService.class);
        i.setAction(action);
        i.putExtra("id", id);
        return PendingIntent.getService(c, req, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void channels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);

        NotificationChannel ch = new NotificationChannel(CH, "تنبيهات الخطة", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("إشعار قبل موعد كل فترة من خطتك اليومية");
        ch.setSound(null, null);
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[]{0, 500, 300, 500, 300, 500});
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        ch.setBypassDnd(true);
        nm.createNotificationChannel(ch);

        NotificationChannel fb = new NotificationChannel(FB, "تنبيه احتياطي بالصوت", NotificationManager.IMPORTANCE_HIGH);
        fb.setSound(Uri.parse("android.resource://" + c.getPackageName() + "/" + R.raw.chime), attrs());
        fb.enableVibration(true);
        fb.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        fb.setBypassDnd(true);
        nm.createNotificationChannel(fb);
    }

    static Notification buildNotif(Context c, int id, String channel) {
        Intent oi = new Intent(c, MainActivity.class);
        oi.putExtra("alert", true);
        oi.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent open = PendingIntent.getActivity(c, id, oi,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, channel)
                : new Notification.Builder(c);

        b.setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(Blocks.EMOJI[id] + "  اقترب موعد: " + Blocks.NAME[id])
                .setContentText("يبدأ الساعة " + Blocks.START_L[id])
                .setStyle(new Notification.BigTextStyle().bigText(
                        "يبدأ الساعة " + Blocks.START_L[id] + "\nينتهي الساعة " + Blocks.END_L[id]))
                .setColor(Blocks.COLOR[id])
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setAutoCancel(true)
                .setContentIntent(open)
                .setFullScreenIntent(open, true)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true)
                .addAction(R.drawable.ic_stat, "إيقاف الصوت", svc(c, ACT_STOP, id, 200 + id))
                .addAction(R.drawable.ic_stat, "ذكّرني بعد 5 دقائق", svc(c, ACT_SNOOZE, id, 300 + id));

        if (Build.VERSION.SDK_INT >= 26) b.setColorized(true);
        else b.setPriority(Notification.PRIORITY_MAX);
        return b.build();
    }

    /** used only if the service could not be started: loud notification with the alarm sound */
    static void fallback(Context c, int id) {
        try {
            channels(c);
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.notify(100 + id, buildNotif(c, id, FB));
        } catch (Exception e) { /* ignore */ }
    }
}
