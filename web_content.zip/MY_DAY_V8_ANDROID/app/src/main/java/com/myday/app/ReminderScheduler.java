package com.myday.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

public final class ReminderScheduler {
    private static final String PREF = "myday_notifications";
    private static final String KEY = "payload";
    private static final String IDS = "ids";

    static void replaceAll(Context c, String json) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, json == null ? "[]" : json).apply();
        schedulePayload(c, json);
    }

    static void rescheduleFromStorage(Context c) {
        schedulePayload(c, c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]"));
    }

    private static void schedulePayload(Context c, String json) {
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        String old = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(IDS, "");
        for (String id : old.split("\\|")) if (!id.isEmpty()) cancel(c, am, id.hashCode());
        ArrayList<String> ids = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(json == null ? "[]" : json);
            long now = System.currentTimeMillis();
            for (int i=0;i<arr.length();i++) {
                JSONObject o = arr.getJSONObject(i);
                long when = o.optLong("when", 0);
                if (when <= now - 30000) continue;
                String id = o.optString("id", "r" + i);
                schedule(c, am, id, o.optString("title", "Promemoria"), o.optString("sub", ""), when);
                ids.add(id);
            }
        } catch (Exception ignored) {}
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(IDS, String.join("|", ids)).apply();
    }

    private static void schedule(Context c, AlarmManager am, String id, String title, String sub, long when) {
        int req = id.hashCode();
        Intent i = new Intent(c, ReminderReceiver.class).putExtra("title", title).putExtra("sub", sub).putExtra("id", req);
        PendingIntent pi = PendingIntent.getBroadcast(c, req, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        } else if (Build.VERSION.SDK_INT >= 23) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        } else {
            am.setExact(AlarmManager.RTC_WAKEUP, when, pi);
        }
    }

    private static void cancel(Context c, AlarmManager am, int req) {
        Intent i = new Intent(c, ReminderReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(c, req, i, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pi != null) { am.cancel(pi); pi.cancel(); }
    }
}
