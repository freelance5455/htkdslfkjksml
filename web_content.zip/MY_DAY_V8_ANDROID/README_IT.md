# MY DAY V8 — Android WebView + notifiche native

Versione semplificata per builder online.

- MY DAY V6 come interfaccia e dati
- WebView locale, nessun server e nessuna dipendenza esterna
- notifica all'orario dell'impegno sempre attiva
- anticipazioni opzionali: 10 minuti, 1 ora, 1 giorno, 1 settimana
- sincronizzazione automatica degli allarmi Android
- ripristino degli allarmi dopo riavvio/aggiornamento
- allegati e file tramite selettore Android
- Gradle/AGP ridotti per compatibilità con builder online

Build consigliata: APK debug.
