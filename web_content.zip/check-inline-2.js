
/* ===== Study Hub v1.9 — Study Planner + Boards Roadmap. Additive module: reads ScoreDeck globals, never edits them. ===== */
(function(){
'use strict';
const SK=Object.keys(subjects),hasS=k=>Object.prototype.hasOwnProperty.call(subjects,k),nm=k=>hasS(k)?subjects[k].name:k,TITLE=document.title;
const defaults=()=>({daily:{},rules:{},learn:{},plan:{},focus:{},focusPending:[],rev:[],week:{},ans:{},cov:{},exam:'',start:'',timer:null,sub:'today',len:45,routine:{}});
function sanitize(o){const d=defaults(),r={};for(const k in d){const v=o&&o[k];r[k]=(v!==undefined&&v!==null&&Array.isArray(v)===Array.isArray(d[k])&&(typeof v===typeof d[k]))?v:d[k]}if(!['today','focus','revise','strategy','progress','exam'].includes(r.sub))r.sub='today';if(![25,45,60].includes(r.len))r.len=45;if(!r.routine||typeof r.routine!=='object'||Array.isArray(r.routine))r.routine={};for(const b of TT){const saved=r.routine[b.id];r.routine[b.id]=saved&&typeof saved==='object'?{t:String(saved.t||b.t).slice(0,30),n:String(saved.n||b.n).slice(0,48),f:String(saved.f||b.f).slice(0,100)}:{t:b.t,n:b.n,f:b.f}}
 if(r.timer&&!(typeof r.timer==='object'&&Number.isFinite(r.timer.end)&&Number.isFinite(r.timer.len)&&Number.isFinite(r.timer.startedAt)&&typeof r.timer.sid==='string'))r.timer=null;
 r.focusPending=Array.isArray(r.focusPending)?r.focusPending.filter(x=>x&&typeof x.sessionId==='string'&&Number.isFinite(x.startedAt)&&Number.isFinite(x.endedAt)&&Number.isFinite(x.durationSeconds)).slice(-50):[];
 const dre=/^\d{4}-\d{2}-\d{2}$/;if(r.exam&&!dre.test(r.exam))r.exam='';if(r.start&&!dre.test(r.start))r.start='';
 r.rev=r.rev.filter(x=>x&&hasS(x.key)&&typeof x.ch==='string'&&dre.test(x.start)).map(x=>({id:x.id||Date.now()+Math.random(),key:x.key,ch:x.ch,start:x.start,done:[0,1,2].map(i=>!!(Array.isArray(x.done)&&x.done[i]))}));
 return r}
const hs=()=>{try{save('hub',H)}catch(e){}};
const pad=n=>String(n).padStart(2,'0');
const iso=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
const today=()=>iso(new Date());
const add=(s,n)=>{const d=new Date(s+'T00:00:00');d.setDate(d.getDate()+n);return iso(d)};
const fmt=s=>new Date(s+'T00:00:00').toLocaleDateString(undefined,{day:'numeric',month:'short'});
const wk=()=>{const d=new Date();d.setDate(d.getDate()-((d.getDay()+6)%7));return iso(d)};
const TT=[
{id:'a',t:'8:00–8:30',s:480,e:510,n:'Settle in + active recall',f:'Review yesterday’s notes; choose today’s targets',c:1},
{id:'rest1',t:'8:30–8:45',s:510,e:525,n:'Short break',f:'Water, stretch, rest your eyes'},
{id:'b',t:'8:45–9:45',s:525,e:585,n:'Deep study block 1',f:'A difficult topic: learn, then solve a few questions',c:1},
{id:'rest2',t:'9:45–10:15',s:585,e:615,n:'Breakfast + screen-free break',f:'Eat and step away from the desk'},
{id:'c',t:'10:15–11:15',s:615,e:675,n:'Practice block',f:'Numericals or application questions; show full working',c:1},
{id:'rest3',t:'11:15–11:35',s:675,e:695,n:'Walk / reset',f:'Take a real break before the next block'},
{id:'d',t:'11:35–12:20',s:695,e:740,n:'Theory + NCERT block',f:'Read actively; recall headings and key terms',c:1},
{id:'meal1',t:'12:20–1:30',s:740,e:810,n:'Lunch + rest',f:'Eat, relax, and allow time away from study'},
{id:'e',t:'1:30–2:15',s:810,e:855,n:'Language / second subject',f:'English writing or literature; rotate with another subject',c:1},
{id:'rest4',t:'2:15–3:30',s:855,e:930,n:'Long rest / movement',f:'Nap, exercise, or personal time; no study required'},
{id:'f',t:'3:30–4:15',s:930,e:975,n:'Revision + mistake review',f:'Revisit weak points and correct earlier errors',c:1},
{id:'rest5',t:'4:15–6:00',s:975,e:1080,n:'Free time + evening snack',f:'Unstructured rest, family time, or a walk'},
{id:'g',t:'6:00–6:30',s:1080,e:1110,n:'Light recap + plan tomorrow',f:'Recall key learning; write three priorities for tomorrow',c:1},
{id:'rest6',t:'6:30–8:00',s:1110,e:1200,n:'Dinner + unwind',f:'Finish study for the day and rest'},
{id:'rest7',t:'8:00–10:00',s:1200,e:1320,n:'Personal time + sleep routine',f:'Prepare for a consistent night of sleep'}];
const IDS=TT.filter(r=>r.c).map(r=>r.id);
let H=sanitize(load('hub',{}));
/* Phase 2 — Focus Mode cloud sync. Local timer/progress remains the source of truth.
   Cloud writes happen only when a session is finalized; failed writes stay queued locally. */
const focusSyncState={running:false};
const focusUuid=()=>{try{if(window.crypto&&typeof crypto.randomUUID==='function')return crypto.randomUUID()}catch(e){}return 'focus-'+Date.now()+'-'+Math.random().toString(36).slice(2,10)};
function focusDateFromMs(ms){const d=new Date(ms);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
function focusQueue(){if(!Array.isArray(H.focusPending))H.focusPending=[];return H.focusPending}
async function flushFocusSync(){
 if(!supabaseClient||!scoreDeckUser||focusSyncState.running)return;
 const q=focusQueue();if(!q.length)return;
 focusSyncState.running=true;
 try{
  for(let i=0;i<q.length;){
   const item=q[i];
   if(!item||!item.sessionId||!Number.isFinite(item.durationSeconds)||item.durationSeconds<0){q.splice(i,1);continue}
   if(!item.sessionSynced){
    const {data,error}=await supabaseClient.rpc('complete_focus_session',{
      p_session_id:item.sessionId,
      p_started_at:new Date(item.startedAt).toISOString(),
      p_ended_at:new Date(item.endedAt).toISOString(),
      p_duration_seconds:Math.floor(item.durationSeconds)
    });
    if(error){console.warn('ScoreDeck focus session sync failed:',error.message);break}
    item.sessionSynced=true;item.statsSynced=true;hs();
   }
   if(item.sessionSynced&&item.statsSynced)q.splice(i,1);else i++;
  }
  hs();
 }finally{focusSyncState.running=false}
}
function queueFocusSession(startedAt,endedAt,durationSeconds){
 const item={sessionId:focusUuid(),startedAt,endedAt,durationSeconds:Math.max(0,Math.floor(durationSeconds)),sessionSynced:false,statsSynced:false};
 focusQueue().push(item);hs();flushFocusSync();
}
window.flushScoreDeckFocusSync=flushFocusSync;
window.queueScoreDeckFocusSession=queueFocusSession;
/* Phase 7 — Full Online Competition. Focus sync is preserved; the other categories use the existing weekly competition backend. */
const competitionState={loading:false,category:'focus',subject:'accountancy'};
const competitionSubjects=[['accountancy','Accountancy'],['business_studies','Business Studies'],['economics','Economics'],['applied_mathematics','Applied Mathematics'],['english_core','English Core']];
const competitionCategories=[
 ['focus','🕒 Focus Time','Most completed focus time this week.'],
 ['practice','🎯 Practice Performance','Best weekly accuracy after at least 10 completed practice questions.'],
 ['improvement','📈 Improvement','Biggest weekly accuracy improvement versus the previous week.'],
 ['consistency','🔥 Consistency','Most active study days this week.'],
 ['subject','📚 Subject Challenges','Best weekly accuracy in the selected subject after at least 10 questions.']
];
function formatFocusSeconds(sec){sec=Math.max(0,Math.floor(Number(sec)||0));const h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60);return h?`${h}h ${m}m`:`${m}m`}
function competitionArea(){return document.getElementById('competitionArea')}
function competitionStatus(msg){const el=document.getElementById('competitionStatus');if(el)el.textContent=msg||''}
async function loadCompetitionOptIn(){
 if(!supabaseClient||!scoreDeckUser)return false;
 const {data,error}=await supabaseClient.from('profiles').select('display_name,competition_opt_in').eq('id',scoreDeckUser.id).maybeSingle();
 if(error){console.warn('ScoreDeck competition profile load failed:',error.message);return false}
 return !!data?.competition_opt_in;
}
async function setCompetitionOptIn(enabled){
 if(!supabaseClient||!scoreDeckUser){competitionStatus('Sign in first to join Competition.');return}
 competitionStatus('Saving your competition preference…');
 const {error}=await supabaseClient.rpc('set_focus_competition_opt_in',{p_enabled:!!enabled});
 if(error){competitionStatus('Could not update competition preference. Please try again.');console.warn('ScoreDeck competition opt-in failed:',error.message);return}
 competitionStatus(enabled?'You are now visible in ScoreDeck competitions.':'You are hidden from all competition leaderboards. Your private data is unchanged.');
 await renderCompetition();
}
async function refreshCompetitionDisplayName(){
 if(!supabaseClient||!scoreDeckUser)return;
 const name=String(scoreDeckUser.user_metadata?.display_name||'ScoreDeck user').trim().slice(0,40)||'ScoreDeck user';
 const {error}=await supabaseClient.from('profiles').update({display_name:name,updated_at:new Date().toISOString()}).eq('id',scoreDeckUser.id);
 if(error)console.warn('ScoreDeck profile name sync failed:',error.message);
}
function competitionMetric(category,r){
 if(category==='focus')return `${formatFocusSeconds(r.focus_seconds)} • ${Number(r.focus_sessions)||0} sessions`;
 if(category==='practice')return `${r.accuracy==null?'—':Number(r.accuracy).toFixed(1)+'%'} accuracy • ${Number(r.practice_questions)||0} questions`;
 if(category==='improvement')return `${Number(r.improvement_points||0)>0?'+':''}${Number(r.improvement_points||0).toFixed(1)} pts • ${Number(r.accuracy||0).toFixed(1)}% current`;
 if(category==='consistency')return `${Number(r.active_days)||0}/7 active days • ${Number(r.practice_questions)||0} questions`;
 return `${r.accuracy==null?'—':Number(r.accuracy).toFixed(1)+'%'} accuracy • ${Number(r.practice_questions)||0} questions`;
}
function competitionSubtitle(category){return competitionCategories.find(x=>x[0]===category)?.[2]||''}
function competitionTabHtml(){return `<div class="competition-category-tabs">${competitionCategories.map(([k,n])=>`<button type="button" class="competition-cat ${competitionState.category===k?'active':''}" data-cat="${k}">${n}</button>`).join('')}</div>`}
async function syncPracticeHistoryToSupabase(){
 if(!supabaseClient||!scoreDeckUser)return {uploaded:0,failed:0};
 let history=[];try{history=JSON.parse(localStorage.getItem(STORAGE+'practiceHistory')||'[]')}catch(e){history=[]}
 if(!Array.isArray(history))return {uploaded:0,failed:0};
 let uploaded=0,failed=0;
 for(const s of history){
  if(!s||s.status!=='completed'||!s.sessionId||!Array.isArray(s.session)||s.sessionId.startsWith('ps-mistakes-')===false&&false)continue;
  const total=Number(s.total||s.session.length||0),attempted=Number(s.attempted||0),correct=Number(s.correct||0),skipped=Number(s.skipped||0),marks=Number(s.obtained||0),maxMarks=Number(s.max||0);
  const mode=s.chapter&&s.chapter!=='All'?'chapter_test':'quick_practice';
  const payload={user_id:scoreDeckUser.id,subject:String(s.subject||''),mode,chapter:s.chapter&&s.chapter!=='All'?String(s.chapter):null,difficulty:s.difficulty&&s.difficulty!=='All'?String(s.difficulty).toLowerCase():'mixed',total_questions:Math.max(0,total),answered_questions:Math.max(0,attempted),correct_questions:Math.max(0,correct),skipped_questions:Math.max(0,skipped),marks_obtained:Math.max(0,marks),total_marks:Math.max(0,maxMarks),accuracy:s.accuracy==null?null:Number(s.accuracy),status:'completed',started_at:new Date(Number(s.startTime||s.completedAt||Date.now())).toISOString(),completed_at:new Date(Number(s.completedAt||Date.now())).toISOString(),client_attempt_id:String(s.sessionId)};
  const {data:attempt,error}=await supabaseClient.from('practice_attempts').upsert(payload,{onConflict:'client_attempt_id'}).select('id').maybeSingle();
  if(error||!attempt?.id){failed++;continue}
  const answers=[];const qs=s.session||[], amap=s.answers||{}, submitted=s.submitted||{}, states=s.questionStates||{};
  for(const q of qs){const isSubmitted=!!submitted[q.id]||states[q.id]==='submitted-correct'||states[q.id]==='submitted-incorrect';if(!isSubmitted)continue;let ok=null;if(q.options||q.finalAnswer!=null){try{ok=pmCorrect(q,amap[q.id])}catch(e){ok=null}}const marksAwarded=ok===true?Number(q.marks||0):0;answers.push({attempt_id:attempt.id,question_id:String(q.id),answer_text:amap[q.id]==null?null:String(amap[q.id]),is_correct:ok,marks_awarded:marksAwarded,mistake_category:null,answered_at:new Date(Number(s.completedAt||Date.now())).toISOString()})}
  if(answers.length){const {error:ae}=await supabaseClient.from('practice_answers').upsert(answers,{onConflict:'attempt_id,question_id'});if(ae){failed++;continue}}
  uploaded++;
 }
 return {uploaded,failed};
}
async function loadCompetitionLeaderboard(category,subject){
 if(!supabaseClient||!scoreDeckUser)return {data:null,error:new Error('Sign in required')};
 try{await syncPracticeHistoryToSupabase();}catch(e){console.warn('ScoreDeck practice online sync warning:',e)}
 const {error:refreshError}=await supabaseClient.rpc('refresh_competition_stats');
 if(refreshError)console.warn('ScoreDeck competition refresh warning:',refreshError.message);
 return await supabaseClient.rpc('get_competition_leaderboard',{p_category:category,p_subject_key:category==='subject'?subject:null});
}
async function renderCompetition(){
 const root=competitionArea();if(!root)return;
 if(!scoreDeckUser){root.innerHTML=`<div class="competition-hero"><h2>ScoreDeck Competition</h2><p>Compete through Focus Time, Practice Performance, Improvement, Consistency and Subject Challenges.</p></div><div class="card competition-card"><h3>Sign in to participate</h3><p class="competition-note">Your local ScoreDeck practice and Focus Mode continue to work without an account. Sign in to sync online competition data.</p><button class="primary" onclick="openAuthDialog()">Sign in / Create account</button></div>`;return}
 if(competitionState.loading)return;competitionState.loading=true;
 root.innerHTML=`<div class="competition-hero"><h2>ScoreDeck Competition</h2><p>Five academic competitions. Only your chosen display name and aggregate competition statistics are shown.</p></div><div class="card competition-card"><h3>Participation</h3><label class="competition-switch"><input id="competitionOptIn" type="checkbox"><span><b>Show me on the leaderboards</b><br><span class="competition-note">Turn this off anytime. Your private practice answers and Focus history are not made public.</span></span></label><div id="competitionStatus" class="competition-status"></div></div><div class="card competition-card"><div class="section-head" style="margin-top:0"><h3>Competitions</h3><button id="competitionRefresh">Refresh</button></div>${competitionTabHtml()}<div id="competitionSubjectWrap" style="display:${competitionState.category==='subject'?'block':'none'};margin:8px 0"><label class="small">Subject<select id="competitionSubject">${competitionSubjects.map(([k,n])=>`<option value="${k}" ${competitionState.subject===k?'selected':''}>${n}</option>`).join('')}</select></label></div><p class="competition-note" id="competitionDescription">${competitionSubtitle(competitionState.category)}</p><div id="competitionRows"><p class="competition-note">Loading…</p></div></div>`;
 try{
  const opt=await loadCompetitionOptIn();const box=document.getElementById('competitionOptIn');if(box){box.checked=opt;box.onchange=()=>setCompetitionOptIn(box.checked)}
  document.querySelectorAll('.competition-cat').forEach(btn=>btn.addEventListener('click',()=>{competitionState.category=btn.dataset.cat;renderCompetition()}));
  const sub=document.getElementById('competitionSubject');if(sub)sub.onchange=()=>{competitionState.subject=sub.value;renderCompetition()};
  document.getElementById('competitionRefresh')?.addEventListener('click',()=>renderCompetition());
  const {data,error}=await loadCompetitionLeaderboard(competitionState.category,competitionState.subject);const rows=document.getElementById('competitionRows');
  if(error){if(rows)rows.innerHTML='<p class="competition-note">Leaderboard is temporarily unavailable. Your local ScoreDeck data is unaffected.</p>';console.warn('ScoreDeck competition leaderboard failed:',error.message);return}
  if(!data?.length){if(rows)rows.innerHTML='<div class="empty">No eligible participants yet for this competition. Complete the minimum activity shown above and try again.</div>';return}
  if(rows)rows.innerHTML=data.map(r=>`<div class="competition-row"><div class="competition-rank">${Number(r.rank)||''}</div><div><div class="competition-name">${esc(r.display_name||'ScoreDeck user')}${r.user_id===scoreDeckUser.id?' <span class="badge">You</span>':''}</div><div class="competition-meta">${competitionMetric(competitionState.category,r)}</div></div><div class="competition-time">${competitionState.category==='focus'?formatFocusSeconds(r.focus_seconds):(competitionState.category==='consistency'?`${Number(r.active_days)||0}/7`:competitionState.category==='improvement'?`${Number(r.improvement_points||0)>0?'+':''}${Number(r.improvement_points||0).toFixed(1)}`:`${r.accuracy==null?'—':Number(r.accuracy).toFixed(1)+'%'}`)}</div></div>`).join('');
 }finally{competitionState.loading=false}
}
window.renderScoreDeckCompetition=renderCompetition;


const prog=d=>{const o=H.daily[d]||{};return IDS.filter(i=>o[i]).length/IDS.length};
const RULES=['Phone away or on focus mode','Practised Accountancy today','Used keywords and proper headings','Updated the Mistake Book','Slept properly last night'];
const TIPS={accountancy:['Understand the logic and format before memorising steps','Practise every day, even 30–45 minutes','Write complete working notes and use proper formats','After a chapter, solve mixed questions without the solution','Keep a list of common errors: calculation, format, adjustment, narration'],
businessStudies:['Read NCERT carefully: definitions, features, importance, processes, examples','Make short keyword notes instead of copying paragraphs','Practise 3-, 4- and 6-mark answers with headings and sub-points','Connect each point to the exact question asked'],
economics:['Build concepts first, then numericals and diagrams','Keep a formula and definition sheet for quick revision','Write clear explanations with diagrams where required','After each chapter, test yourself without the textbook'],
appliedMathematics:['Concept → formula → examples → representative exercise questions','Practise a little every day and show full working','Log repeated errors (calculation, formula, application) in the Mistake Book'],
englishCore:['Learn the writing formats and practise under time limits','Prepare themes, characters and references in your own words','Practise unseen passages and check why each answer is correct']};
const WEEK=['Completed planned chapters/topics','Practised Accountancy consistently','Revised Economics and BST, not just read once','Completed at least one timed test or sample paper','Analysed every mistake from the test','Cleared my important doubts','Planned the next week'];
const PH=[['Build',['Complete concepts and class notes','Finish chapter-wise questions','Create concise revision sheets']],['Strengthen',['Revise weak chapters more often','Solve previous and sample questions','Practise answer presentation and time management']],['Exam mode',['Attempt full-length papers in exam conditions','Check marks lost: knowledge, presentation or time','Revise mistakes and high-frequency concepts','Avoid learning huge new portions at the last moment']]];
const ANS=['Read the question and identify exactly what it asks','Use headings and subheadings','Show steps and working in numericals','Use correct terminology and keywords','Leave a few minutes at the end for checking'];
const STAGES=[['Same day',0,'Recall key points, solve 2–5 questions (10–20 min)'],['Day 7',7,'Test yourself without notes (20–40 min)'],['Day 30',30,'Mixed revision + past mistakes (30–60 min)']];
const SUBS=[['today','Today'],['focus','Focus'],['revise','Revise'],['strategy','Strategy'],['progress','Progress'],['exam','Exam']];
const ck=(t,k,l,on)=>`<label class="hb-ck"><input type="checkbox" data-t="${t}" data-k="${esc(k)}" ${on?'checked':''}><span>${l}</span></label>`;
const nest={daily:today,rules:today,week:wk};
const opts=()=>SK.map(k=>`<option value="${k}">${esc(nm(k))}</option>`).join('');
const dueCount=()=>{const t=today();return H.rev.filter(r=>STAGES.some((s,i)=>!r.done[i]&&add(r.start,s[1])<=t)).length};
function streak(){let n=0,d=today();if(prog(d)<.8)d=add(d,-1);while(prog(d)>=.8&&n<4000){n++;d=add(d,-1)}return n}
function roadYear(){const n=new Date(),m=n.getMonth(),y=n.getFullYear();return m<=1?y-1:y}
function phase(){const n=new Date(),m=n.getMonth(),y=roadYear(),t=new Date(today()+'T00:00:00');
 const days=d=>Math.ceil((d-t)/864e5);
 if(m===9||m===10)return{i:m-9,name:m===9?'October · Build knowledge':'November · Finish syllabus',line:Math.max(0,days(new Date(y,10,30)))+' days to syllabus lock (30 Nov)'};
 if(m===11||m===0)return{i:m===11?2:3,name:m===11?'December · Revision + papers':'January · Exam mode',line:Math.max(0,days(new Date(y+1,1,1)))+' days to 1 Feb'};
 return{i:-1,name:m===1?'Roadmap complete':'Roadmap starts 1 October',line:''}}

/* ---------- timer ---------- */
const T={iv:0};
const FOCUS_DAILY_LIMIT_MINUTES=480;
function focusElapsedSeconds(active,now=Date.now()){if(!active)return 0;const planned=Math.max(0,Number(active.len)||0)*60000;const remaining=active.paused?Math.max(0,Number(active.remainingMs)||0):Math.max(0,(Number(active.end)||now)-now);return Math.floor(Math.min(planned,Math.max(0,planned-remaining))/1000)}
function clockText(){const active=H.timer;const r=!active?H.len*6e4:(active.paused?Math.max(0,Number(active.remainingMs)||0):Math.max(0,active.end-Date.now()));return pad(Math.floor(r/6e4))+':'+pad(Math.floor(r%6e4/1e3))}
function tick(){if(!H.timer)return;const c=document.getElementById('hbClk');if(c)c.textContent=clockText();document.title=clockText()+' · Focus';if(!H.timer.paused&&H.timer.end-Date.now()<=0)fin(H.timer.len,true,focusElapsedSeconds(H.timer))}
function fin(mins,completed=false,durationSecondsOverride=null){
 const active=H.timer;
 if(!active)return; // Idempotency guard: a second completion callback must not log the same session twice.
 clearInterval(T.iv);T.iv=0;H.timer=null;
 const durationSeconds=Number.isFinite(durationSecondsOverride)?Math.max(0,Math.floor(durationSecondsOverride)):focusElapsedSeconds(active);
 const loggedMinutes=Math.floor(durationSeconds/60);
 const sessionDate=focusDateFromMs(Number(active.startedAt)||Date.now());
 if(loggedMinutes>0)H.focus[sessionDate]=Math.min(FOCUS_DAILY_LIMIT_MINUTES,(H.focus[sessionDate]||0)+loggedMinutes);
 if(active&&durationSeconds>0)window.queueScoreDeckFocusSession?.(Number(active.startedAt)||Date.now()-durationSeconds*1000,Date.now(),durationSeconds);
 hs();document.title=TITLE;if(completed)showTimerAlert('focus','Your Focus session is complete');redraw();window.flushScoreDeckFocusSync?.()}

/* ---------- planner views ---------- */
function vToday(){
 const d=today(),o=H.daily[d]||{},n=new Date(),m=n.getHours()*60+n.getMinutes(),c=IDS.filter(i=>o[i]).length,ru=H.rules[d]||{};
 const rows=TT.map(r=>{const x=H.routine[r.id]||r;return `<div class="hb-row${m>=r.s&&m<r.e?' now':''}${r.c?'':' rest'}"><span class="hb-tm">${esc(x.t)}</span><span class="hb-nm"><b>${esc(x.n)}</b><span>${esc(x.f)}</span></span>${r.c?`<input type="checkbox" data-t="daily" data-k="${r.id}" ${o[r.id]?'checked':''} aria-label="${esc(x.n)} done">`:'<span class="rest-mark">•</span>'}</div>`}).join('');
 const editor=TT.map(r=>{const x=H.routine[r.id]||r;return `<div class="routine-edit-row"><b>${esc(r.c?'Study block':'Break / rest')}</b><label>Time<input data-routine="${r.id}" data-field="t" value="${esc(x.t)}" maxlength="30"></label><label>Activity<input data-routine="${r.id}" data-field="n" value="${esc(x.n)}" maxlength="48"></label><label>Notes<input data-routine="${r.id}" data-field="f" value="${esc(x.f)}" maxlength="100"></label></div>`}).join('');
 return `<div class="card hb-card hb-ledger" style="padding:0"><div class="hb-spread" style="padding:14px 12px 6px"><h3 style="margin:0">Today's ledger</h3><span class="small">Self-study day • streak at 80%</span></div>${rows}<div class="hb-total"><span>Study blocks done</span><span>${c} / ${IDS.length}</span></div></div><details class="card hb-card routine-editor"><summary>Edit today’s routine</summary><p class="small">Adjust times, activities and notes to fit your day. Your checked study blocks and streak history are kept.</p>${editor}</details>
 <div class="card hb-card"><h3>Jump into practice</h3><div class="hb-chips">${SK.map(k=>`<button data-h="subj" data-k="${k}">${subjects[k].icon} ${esc(subjects[k].short||nm(k))}</button>`).join('')}<button data-h="mb">❌ Mistake Book</button></div></div>
 <div class="card hb-card"><h3>Daily rules</h3>${RULES.map((r,i)=>ck('rules',i,r,ru[i])).join('')}</div>
 <div class="card hb-card"><h3>What did I learn today?</h3><p class="small">Write a short recall in your own words.</p><textarea data-i="learn" placeholder="In your own words…">${esc(H.learn[d]||'')}</textarea><h3 style="margin-top:12px">Three priorities for tomorrow</h3><textarea data-i="plan" placeholder="1. …">${esc(H.plan[d]||'')}</textarea></div>`;
}

function vFocus(){
 const d=today(),mins=H.focus[d]||0,remaining=Math.max(0,FOCUS_DAILY_LIMIT_MINUTES-mins),pct=Math.min(100,mins/FOCUS_DAILY_LIMIT_MINUTES*100),run=!!H.timer;
 const days=[...Array(7)].map((_,i)=>add(d,i-6)),mx=Math.max(60,...days.map(x=>H.focus[x]||0));
 const timerControls=run?(H.timer.paused?'<button class="primary" data-h="resume">Resume session</button>':'<button data-h="pause">Pause session</button>')+'<button data-h="stop">Stop and log time</button>':(remaining>0?'<button class="primary" data-h="start">Start session</button>':'<button disabled>8-hour daily limit reached</button>');
 return `<div class="card hb-card"><h3>Focus session</h3><div class="hb-clock" id="hbClk">${clockText()}</div>
 <div class="hb-center">${[25,45,60].map(x=>`<button data-h="len" data-k="${x}" class="${H.len==x?'on':''}" ${run||remaining<=0?'disabled':''}>${x} min</button>`).join('')}</div>
 <div class="hb-center">${timerControls}</div>
 <p class="small" style="text-align:center">Choose a 25, 45 or 60 minute focus block. The last block is shortened if needed to fit the remaining daily limit. Pause/resume preserves your session and paused time is not counted. Your session survives closing the app.</p></div>
 <div class="card hb-card"><div class="hb-spread"><h3 style="margin:0">Focused today</h3><b>${Math.floor(mins/60)}h ${mins%60}m</b></div><div class="progress"><div class="bar" style="width:${pct}%"></div></div><p class="small">Daily Focus limit: 8 hours. Remaining today: ${Math.floor(remaining/60)}h ${remaining%60}m.</p>
 <h3>Last 7 days</h3><div class="hb-cols">${days.map(x=>`<div style="height:${(H.focus[x]||0)/mx*100}%"><span>${new Date(x+'T00:00:00').toLocaleDateString(undefined,{weekday:'narrow'})}</span></div>`).join('')}</div></div>`;
}
function vRevise(){
 const t=today(),due=H.rev.filter(r=>STAGES.some((s,i)=>!r.done[i]&&add(r.start,s[1])<=t));
 const item=r=>{const idx=subjects[r.key]?subjects[r.key].chapters.indexOf(r.ch):-1;return `<div class="hb-item"><div class="hb-spread"><b>${esc(r.ch)}</b><span><span class="hb-tag">${esc(nm(r.key))}</span> <button class="ghost" data-h="rdel" data-k="${r.id}">Remove</button></span></div>${STAGES.map((s,i)=>{const dd=add(r.start,s[1]),late=!r.done[i]&&dd<t;return `<label class="hb-ck"><input type="checkbox" data-h="rv" data-k="${r.id}" data-s="${i}" ${r.done[i]?'checked':''}><span>${s[0]} · ${fmt(dd)}${late?' <span class="hb-tag w">overdue</span>':dd===t&&!r.done[i]?' <span class="hb-tag">due today</span>':''}<br><span class="small">${s[2]}</span></span></label>`}).join('')}<div class="hb-chips"><button data-h="subj" data-k="${r.key}">Open ${esc(subjects[r.key]?subjects[r.key].short||nm(r.key):'subject')}</button>${idx>=0?`<button class="primary" data-h="rprac" data-k="${r.id}">Practise this chapter</button>`:''}</div></div>`};
 const first=SK[0];
 return `<div class="card hb-card"><h3>Add a chapter you studied</h3><p class="small">The 1–7–30 system schedules three reviews for you.</p>
 <form id="hbRevForm"><div class="hb-g"><select name="k" id="hbRk" aria-label="Subject">${opts()}</select><input type="text" name="c" id="hbRc" list="hbCh" placeholder="Chapter or topic" required autocomplete="off"><datalist id="hbCh">${subjects[first].chapters.map(c=>`<option value="${esc(c)}">`).join('')}</datalist></div><button class="primary">Add chapter</button></form></div>
 <div class="card hb-card ${due.length?'hb-warn':''}"><h3>Due now (${due.length})</h3>${due.map(item).join('')||'<p class="small">Nothing due. Add a chapter after studying it today.</p>'}</div>
 <div class="card hb-card"><h3>All chapters (${H.rev.length})</h3>${H.rev.map(item).join('')||'<p class="small">No chapters yet.</p>'}</div>`;
}
function vStrategy(){
 return `<div class="card hb-card"><h3>The 5-step study cycle</h3><p>Learn → Recall (close the book) → Practise → Check → Improve (log mistakes).</p><p class="small">In ScoreDeck, wrong answers go into your Mistake Book automatically. Classify each error: concept, memory, application, calculation, presentation or time.</p><div class="hb-chips"><button data-h="mb">Open Mistake Book</button><button data-h="sp">Sample Papers</button></div></div>
 <div class="card hb-card"><h3>Subject strategies</h3>${SK.map((k,i)=>`<details ${i===0?'open':''}><summary>${subjects[k].icon} ${esc(nm(k))}</summary><ul>${(TIPS[k]||[]).map(x=>`<li>${x}</li>`).join('')}</ul></details>`).join('')}</div>`;
}
function vProgress(){
 const wkd=H.week[wk()]||{},wc=WEEK.filter((_,i)=>wkd[i]).length,t=today();
 let g;
 if(H.start){let done=0;const cells=[...Array(30)].map((_,i)=>{const d=add(H.start,i),ok=d<=t&&prog(d)>=.8;if(ok)done++;return `<div class="${ok?'d':d<t?'m':''} ${d===t?'t':''}" title="${fmt(d)}">${i+1}</div>`}).join('');g=`<div class="hb-spread"><b>${done} / 30 days</b><button class="ghost" data-h="cstart">Restart</button></div><div class="hb-grid30" style="margin-top:8px">${cells}</div><p class="small">A day counts when 80% of its ledger blocks are done.</p>`}
 else g='<p>Study 30 days without relying on motivation.</p><button class="primary" data-h="cstart">Start from today</button>';
 const cov=SK.map(k=>{const ch=subjects[k].chapters,n=ch.filter(c=>chapterDone(k,c)).length,p=ch.length?Math.round(n/ch.length*100):0;return `<div style="margin:8px 0"><div class="hb-spread"><span>${subjects[k].icon} ${esc(nm(k))}</span><span class="small">${n}/${ch.length} chapters · ${p}%</span></div><div class="progress"><div class="bar" style="width:${p}%"></div></div></div>`}).join('');
 return `<div class="card hb-card"><h3>Chapter coverage</h3><p class="small">Live from the chapter ticks inside each ScoreDeck subject.</p>${cov}</div>
 <div class="card hb-card"><h3>30-day challenge</h3>${g}</div>
 <div class="card hb-card"><div class="hb-spread"><h3 style="margin:0">Weekly scorecard</h3><b>${wc} / 7</b></div><p class="small">Week of ${fmt(wk())} · resets every Monday</p>${WEEK.map((w,i)=>ck('week',i,w,wkd[i])).join('')}</div>
 <div class="card hb-card"><details><summary>Backup or move planner data</summary><p class="small">Copy this text to keep a backup. Paste a saved backup and press Load to restore the planner and roadmap ticks.</p><textarea id="hbBk" style="min-height:100px">${esc(JSON.stringify(H))}</textarea><div class="hb-chips"><button data-h="load">Load pasted data</button></div></details></div>`;
}
function vExam(){
 const dl=H.exam?Math.ceil((new Date(H.exam+'T00:00:00')-new Date(today()+'T00:00:00'))/864e5):null;
 return `<div class="card hb-card"><h3>Board exam countdown</h3><input type="date" id="hbEx" value="${esc(H.exam)}" aria-label="First board exam date">${dl!==null?`<div class="hb-clock" style="font-size:44px">${Math.max(0,dl)}</div><p style="text-align:center;margin:0">${dl>=0?'days to go':'exam started'}</p>`:'<p class="small">Add your first paper date to see days left.</p>'}<div class="hb-chips"><button data-h="sp">Open Sample Papers</button></div></div>
 ${PH.map((p,i)=>`<div class="card hb-card"><h3>Phase ${i+1}: ${p[0]}</h3>${p[1].map((x,j)=>ck('ans','p'+i+'_'+j,x,H.ans['p'+i+'_'+j])).join('')}</div>`).join('')}
 <div class="card hb-card"><h3>Answer-writing checklist</h3><p class="small">Tick these off during every timed paper.</p>${ANS.map((x,j)=>ck('ans','a'+j,x,H.ans['a'+j])).join('')}<button class="ghost" data-h="clr">Clear ticks</button></div>`;
}
const VIEW={today:vToday,focus:vFocus,revise:vRevise,strategy:vStrategy,progress:vProgress,exam:vExam};
function hubRender(){const el=document.getElementById('hubPanel');if(!el)return;
 el.innerHTML=`<div class="hb"><div class="hb-head"><h2>📒 Study Planner</h2><span class="small">${streak()} day streak</span></div><div class="hb-sub">${SUBS.map(([k,l])=>`<button data-h="tab" data-k="${k}" class="${k===H.sub?'on':''}">${l}</button>`).join('')}</div>${VIEW[H.sub]()}</div>`;
 const rk=document.getElementById('hbRk');if(rk)rk.addEventListener('change',()=>{const dl=document.getElementById('hbCh');if(dl)dl.innerHTML=subjects[rk.value].chapters.map(c=>`<option value="${esc(c)}">`).join('')})}

/* ---------- roadmap ---------- */
function rmRender(anim){const el=document.getElementById('roadmapPanel');if(!el)return;
 const ph=phase(),n=SK.filter(k=>H.cov[k]).length,months=[['October','Build knowledge','Major syllabus coverage'],['November','Finish syllabus','Patch weak chapters'],['December','Revision + papers','Convert knowledge into marks'],['January','Exam mode','Papers + targeted revision']];
 const octD={accountancy:'Concepts → illustrations → selected exercises → working-note/formula/format notes.',businessStudies:'NCERT → headings → keywords → definitions → case-study concepts.',economics:'NCERT → concepts → definitions → graphs → formulas → basic numericals.',appliedMathematics:'Concept → formula → examples → representative exercise questions.',englishCore:'Literature → themes/characters/incidents → writing formats; keep reading active.'};
 el.innerHTML=`<div class="rm${anim?' rm-anim':''}"><div class="rm-hero"><span class="badge">1 October → 1 February</span><h2>Class 12 Boards Roadmap</h2><p>Finish the syllabus by 30 November. Start revision + sample papers on 1 December.</p>${ph.line?`<p style="margin-top:10px"><span class="badge">${esc(ph.name)}</span> <span class="badge">${esc(ph.line)}</span></p>`:`<p style="margin-top:10px"><span class="badge">${esc(ph.name)}</span></p>`}</div>
 <div class="rm-timeline">${months.map((m,i)=>`<div class="rm-card${ph.i===i?' cur':''}"><h3>${m[0]}</h3><b>${m[1]}</b><br>${m[2]}</div>`).join('')}</div>
 <div class="rm-sec"><h2>October — Build the foundation</h2><p>Learn chapters, create concise revision resources, and use representative questions to verify understanding. Do not try to exhaust every exercise before moving forward.</p><div class="rm-grid">${SK.map((k,i)=>`<details ${i===0?'open':''}><summary>${subjects[k].icon} ${esc(nm(k))}</summary>${octD[k]||''}<div class="hb-chips"><button data-h="subj" data-k="${k}">Open ${esc(subjects[k].short||nm(k))}</button></div></details>`).join('')}</div></div>
 <div class="rm-sec"><h2>November — Syllabus lock</h2><p>By 15 November, most major chapters should be covered. From 16–30 November, audit every chapter and eliminate anything completely untouched.</p>${SK.map(k=>{const ch=subjects[k].chapters,d=ch.filter(c=>chapterDone(k,c)).length;return `<label class="rm-check"><input type="checkbox" data-t="cov" data-k="${k}" ${H.cov[k]?'checked':''}><span>100% ${esc(nm(k))} first coverage<span class="small">ScoreDeck chapters ticked: ${d} / ${ch.length}</span></span></label>`}).join('')}<div class="rm-track"><div class="rm-fill" id="rmFill" style="width:${n/SK.length*100}%"></div></div><p class="badge" id="rmCount" style="margin-top:10px">${n} / ${SK.length} complete</p></div>
 <div class="rm-sec"><h2>December — Revision + Sample Papers</h2><details open><summary>1–15 December</summary><p>Chapter revision → PYQs/board-pattern questions → sample-paper exposure → analyse mistakes → repair weak chapters.</p></details><br><details><summary>16–31 December</summary><p>Mixed full-syllabus revision + regular sample papers. Analyse every lost mark instead of simply counting scores.</p><div class="hb-chips"><button data-h="sp">Open Sample Papers</button></div></details></div>
 <div class="rm-sec"><h2>January — Exam application</h2><div class="rm-grid"><details><summary>1–15 January</summary><p>Continue sample papers and targeted revision. Classify errors: concept, memory, application, calculation, presentation, time.</p></details><details><summary>16–31 January</summary><p>Increase exam-condition practice. Narrow resources to notes, NCERT, PYQs, formula/format sheets, mistake book and sample papers.</p><div class="hb-chips"><button data-h="mb">Open Mistake Book</button></div></details></div></div>
 <div class="rm-sec"><h2>The resource progression</h2><div class="rm-card"><p><b>October:</b> Books → concepts</p><p><b>November:</b> Books → concepts + basic application</p><p><b>December:</b> Revision + PYQs + sample papers</p><p><b>January:</b> Sample papers + mistake correction + revision</p></div></div>
 <div class="rm-foot">Core transition: Build knowledge → Complete knowledge → Convert knowledge into marks → Make performance reliable.</div></div>`}

/* ---------- home card ---------- */
function homeCard(){const el=document.getElementById('hubHome');if(!el)return;
 const d=today(),o=H.daily[d]||{},c=IDS.filter(i=>o[i]).length,m=H.focus[d]||0,ph=phase(),due=dueCount();
 el.innerHTML=`<div class="section-head home-section-title"><h3>Study planner</h3><span class="small">${streak()} day streak</span></div><div class="stats home-stats"><div class="stat"><div class="label">Today's ledger</div><div class="num">${c}/${IDS.length}</div></div><div class="stat"><div class="label">Focused today</div><div class="num">${Math.floor(m/60)}h ${m%60}m</div></div><div class="stat"><div class="label">Revisions due</div><div class="num">${due}</div></div><div class="stat"><div class="label">Roadmap</div><div class="small" style="margin-top:6px;font-weight:700;color:var(--text)">${esc(ph.name)}</div><div class="small">${esc(ph.line)}</div></div></div><div class="actions" style="margin:9px 0 12px"><button class="primary" data-h="open" data-k="planner">Open Planner</button><button data-h="open" data-k="roadmap">Boards Roadmap</button></div>`}

function redraw(){hubRender();homeCard()}
function openHub(k){if(k==='roadmap'){rmRender(true);showPanel('roadmapPanel')}else{hubRender();showPanel('hubPanel')}}

/* ---------- events (delegated, scoped to hub containers) ---------- */
const inHub=t=>t&&t.closest&&t.closest('#hubPanel,#roadmapPanel,#hubHome');
document.addEventListener('click',e=>{
 const b=e.target.closest&&e.target.closest('[data-h]');if(!b||!inHub(b)||b.type==='checkbox')return;
 const a=b.dataset.h,k=b.dataset.k;
 if(a==='open'){openHub(k);return}
 if(a==='subj'){if(hasS(k))openSubject(k);return}
 if(a==='mb'){renderReview();showPanel('reviewPanel');return}
 if(a==='sp'){renderSamplePapers();showPanel('samplePapersPanel');return}
 if(a==='rprac'){const r=H.rev.find(x=>String(x.id)===k);const i=r&&subjects[r.key]?subjects[r.key].chapters.indexOf(r.ch):-1;if(i>=0){openPracticeSetup(r.key,i);showPanel(r.key)}return}
 if(a==='tab'){H.sub=k}
 else if(a==='len'){if(!H.timer)H.len=+k}
 else if(a==='start'){if(!H.timer){const remaining=Math.max(0,FOCUS_DAILY_LIMIT_MINUTES-(H.focus[today()]||0));if(remaining<=0){alert('You have reached the 8-hour Focus limit for today.');return}const len=Math.min(H.len,remaining),now=Date.now(),durationMs=len*6e4;H.timer={sid:focusUuid(),startedAt:now,lastResumedAt:now,end:now+durationMs,len,elapsedMs:0,remainingMs:durationMs,paused:false};clearInterval(T.iv);T.iv=setInterval(tick,500)}}
 else if(a==='pause'){if(H.timer&&!H.timer.paused){H.timer.remainingMs=Math.max(0,H.timer.end-Date.now());H.timer.elapsedMs=Math.max(0,H.timer.len*6e4-H.timer.remainingMs);H.timer.paused=true;H.timer.end=null;clearInterval(T.iv);T.iv=0}}
 else if(a==='resume'){if(H.timer&&H.timer.paused&&H.timer.remainingMs>0){const now=Date.now();H.timer.end=now+H.timer.remainingMs;H.timer.lastResumedAt=now;H.timer.paused=false;clearInterval(T.iv);T.iv=setInterval(tick,500)}}
 else if(a==='stop'){if(H.timer){const expired=!H.timer.paused&&H.timer.end<=Date.now();fin(H.timer.len,expired,focusElapsedSeconds(H.timer));return}}
 else if(a==='rdel'){H.rev=H.rev.filter(r=>String(r.id)!==k)}
 else if(a==='cstart'){if(!H.start||confirm('Restart the 30-day challenge from today?'))H.start=today()}
 else if(a==='clr'){H.ans={}}
 else if(a==='load'){try{const o=JSON.parse(document.getElementById('hbBk').value);if(!o||typeof o!=='object'||Array.isArray(o))throw 0;H=sanitize(o);H.timer=null;clearInterval(T.iv);T.iv=0;rmRender()}catch(x){alert('That text is not valid backup data.');return}}
 hs();redraw();
});
document.addEventListener('change',e=>{
 const el=e.target;if(!inHub(el))return;
 if(el.dataset.h==='rv'){const r=H.rev.find(x=>String(x.id)===el.dataset.k);if(r)r.done[+el.dataset.s]=el.checked}
 else if(el.dataset.t==='cov'){if(!hasS(el.dataset.k))return;if(el.checked)H.cov[el.dataset.k]=1;else delete H.cov[el.dataset.k];hs();const n=SK.filter(k=>H.cov[k]).length,f=document.getElementById('rmFill'),c=document.getElementById('rmCount');if(f)f.style.width=n/SK.length*100+'%';if(c)c.textContent=n+' / '+SK.length+' complete';return}
 else if(el.dataset.t){const t=el.dataset.t;let o=H[t];if(!o||typeof o!=='object')return;if(nest[t]){const k=nest[t]();o=o[k]=o[k]||{}}if(el.checked)o[el.dataset.k]=1;else delete o[el.dataset.k]}
 else if(el.id==='hbEx'){H.exam=el.value}
 else return;
 hs();redraw();
});
document.addEventListener('input',e=>{const el=e.target,i=el.dataset&&el.dataset.i;if(inHub(el)&&el.tagName==='TEXTAREA'&&(i==='learn'||i==='plan')){H[i][today()]=el.value;hs();return}if(inHub(el)&&el.dataset&&el.dataset.routine){const id=el.dataset.routine,field=el.dataset.field,b=TT.find(x=>x.id===id);if(!b||!['t','n','f'].includes(field))return;H.routine[id][field]=el.value.slice(0,field==='f'?100:field==='n'?48:30);hs()}});
document.addEventListener('submit',e=>{
 if(e.target.id!=='hbRevForm')return;e.preventDefault();
 const f=new FormData(e.target),k=f.get('k'),c=String(f.get('c')||'').trim();if(!hasS(k)||!c)return;
 H.rev.unshift({id:Date.now(),key:k,ch:c,start:today(),done:[false,false,false]});hs();redraw();
});
[['hubPanel',()=>hubRender()],['roadmapPanel',()=>rmRender(true)]].forEach(([p,fn])=>{const t=document.querySelector('.tab[data-panel="'+p+'"]');if(t)t.addEventListener('click',fn)});

/* ---------- init ---------- */
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&H.timer&&!H.timer.paused&&H.timer.end<=Date.now())fin(H.timer.len,true,focusElapsedSeconds(H.timer))});
if(H.timer){if(!H.timer.paused&&H.timer.end<=Date.now())fin(H.timer.len,true,focusElapsedSeconds(H.timer));else if(!H.timer.paused)T.iv=setInterval(tick,500)}
redraw();
let lastDay=today();
setInterval(()=>{const a=document.activeElement,busy=a&&inHub(a)&&/INPUT|TEXTAREA|SELECT/.test(a.tagName),nd=today()!==lastDay;lastDay=today();homeCard();
 if(document.getElementById('hubPanel').classList.contains('active')&&!busy&&(nd||H.sub==='today'))hubRender();
 if(nd&&document.getElementById('roadmapPanel').classList.contains('active')&&!busy)rmRender()},60000);
})();

/* Optional Progress & Mastery layer. Legacy ScoreDeck storage is read-only here. */
const PM_KEY='scoredeck_mastery_v1';
const pmEmpty=()=>({version:1,events:{},bests:{practice:{},sample:{}},goals:{}});
let pmUnavailable=false,pmNotice='',pmDirty=false,pmData=pmEmpty();
function pmPlain(x){return !!x&&typeof x==='object'&&!Array.isArray(x)}
function pmValid(x){return pmPlain(x)&&x.version===1&&pmPlain(x.events)&&Object.values(x.events).every(e=>pmPlain(e)&&typeof e.type==='string'&&Number.isFinite(Number(e.xp))&&Number(e.xp)>=0)&&pmPlain(x.bests)&&pmPlain(x.bests.practice)&&pmPlain(x.bests.sample)&&[...Object.values(x.bests.practice),...Object.values(x.bests.sample)].every(b=>pmPlain(b)&&Number.isFinite(Number(b.score)))&&pmPlain(x.goals)&&Object.values(x.goals).every(g=>pmPlain(g)&&Array.isArray(g.items)&&g.items.every(i=>pmPlain(i)&&typeof i.id==='string'&&typeof i.kind==='string'))}
try{const raw=localStorage.getItem(PM_KEY);if(raw!==null){const parsed=JSON.parse(raw);if(pmValid(parsed))pmData=parsed;else{pmUnavailable=true;pmNotice='Progress data is unreadable. Existing ScoreDeck records remain untouched.'}}}catch(e){pmUnavailable=true;pmNotice='Progress data could not be read. Existing ScoreDeck records remain untouched.'}
function pmSave(){if(pmUnavailable||!pmDirty)return;try{localStorage.setItem(PM_KEY,JSON.stringify(pmData));pmDirty=false}catch(e){pmUnavailable=true;pmNotice='Progress could not be saved. Existing ScoreDeck records remain untouched.'}}
function pmDay(ts=Date.now()){const d=new Date(Number(ts)||Date.now());return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
function pmAddEvent(id,type,xp,details={},at=Date.now(),countsForStreak=false){if(pmUnavailable||pmData.events[id])return false;const n=Number(xp)||0;pmData.events[id]={type,xp:Math.max(0,n),details,at:Number(at)||0,day:countsForStreak?pmDay(at):null};pmDirty=true;return true}
function pmXP(){return Object.values(pmData.events).reduce((a,e)=>a+Math.max(0,Number(e?.xp)||0),0)}
function pmHistory(){try{const h=JSON.parse(localStorage.getItem(STORAGE+'practiceHistory')||'[]');return Array.isArray(h)?h:[]}catch(e){return []}}
function pmMistakes(){try{const m=getMistakeBook();return Array.isArray(m)?m:[]}catch(e){return []}}
function pmCorrect(q,answer){if(!q)return false;if(Array.isArray(q.options))return norm(answer)===norm(q.correctAnswer);if(q.finalAnswer==null)return false;const expected=String(q.finalAnswer);if(/[A-Za-z><=]/.test(expected))return norm(answer)===norm(expected);const a=numericValues(answer),b=numericValues(expected);return !!(a.length&&b.length&&a.length===b.length&&a.every((v,i)=>Number.isFinite(v)&&Math.abs(v-b[i])<=Math.max(.01,Math.abs(b[i])*.001)))}
function pmSubject(q,s){if(s&&subjects[s.subject])return s.subject;const name=q?.subject;return Object.keys(subjects).find(k=>subjects[k].name===name)||''}
function pmSessionId(s,i){return String(s.sessionId||('legacy-'+String(s.completedAt||s.startTime||i)))}
function pmComparable(s,graded){const f=s.filters||{};return [s.subject||'',f.chapter||s.chapter||'All',f.difficulty||s.difficulty||'All',f.questionType||s.questionType||'All','n='+graded].join('|')}
function pmBest(kind,key,score,n,sid,label,at,subject){const old=pmData.bests[kind][key];if(old&&score<=Number(old.score))return false;pmData.bests[kind][key]={score,n,sessionId:sid,label,at,subject};pmDirty=true;if(old)pmAddEvent('best:'+kind+':'+sid+':'+encodeURIComponent(key),'personal_best',10,{kind,key,subject,score,previous:Number(old.score)},at,false);return true}
function pmPracticeSession(s,index,stats,record=true){const sid=pmSessionId(s,index),questions=Array.isArray(s.session)?s.session:[],submitted=s.submitted||{},answers=s.answers||{},byChapter={};let correct=0,hardCount=0,attempted=0,graded=0;for(const q of questions){const sent=!!submitted[q.id]||['submitted-correct','submitted-incorrect'].includes(s.questionStates?.[q.id]);if(!sent)continue;attempted++;const sk=pmSubject(q,s);if(sk){const ss=stats[sk],ch=ss.chapters[q.chapter]||(ss.chapters[q.chapter]={attempted:0,graded:0,correct:0});ss.attempted++;ch.attempted++;byChapter[q.chapter]=(byChapter[q.chapter]||0)+1;if(String(q.difficulty).toLowerCase()==='hard'){hardCount++;ss.hardAttempted++}if(Array.isArray(q.options)||q.finalAnswer!=null){graded++;ss.graded++;ch.graded++;const d=ss.difficulty[q.difficulty]||(ss.difficulty[q.difficulty]={attempted:0,correct:0});d.attempted++;if(pmCorrect(q,answers[q.id])){correct++;ss.correct++;ch.correct++;d.correct++}}}}
 if(!record)return;
 const completedAt=Number(s.completedAt||s.updatedAt||s.startTime||0);if(attempted>=3)pmAddEvent('practice:'+sid,'practice_complete',10+Math.min(10,correct*2),{sessionId:sid,subject:s.subject,attempted,correct,graded,hardCount,byChapter},completedAt,true);
 if(String(s.sessionId||'').startsWith('ps-mistakes-')){const saved=new Set(pmMistakes().map(m=>m.questionId));for(const q of questions)if(saved.has(q.id)&&(submitted[q.id]||s.questionStates?.[q.id]==='submitted-correct')&&pmCorrect(q,answers[q.id]))pmAddEvent('recovery:'+sid+':'+q.id,'mistake_recovered',5,{sessionId:sid,questionId:q.id,subject:pmSubject(q,s),chapter:q.chapter},completedAt||Date.now(),true)}
 if(graded>=3){const key=pmComparable(s,graded),rate=correct/graded;pmBest('practice',key,rate,graded,sid,subjects[s.subject]?.name||s.subject,completedAt,s.subject)}
}
function pmBuildStats(record=true){const stats={};for(const k of Object.keys(subjects)){stats[k]={attempted:0,graded:0,correct:0,hardAttempted:0,chapters:{},difficulty:{}};for(const ch of subjects[k].chapters)stats[k].chapters[ch]={attempted:0,graded:0,correct:0};for(const d of ['Easy','Medium','Hard'])stats[k].difficulty[d]={attempted:0,correct:0}}
 const sessions=pmHistory().map((s,i)=>({s,i})).filter(x=>x.s&&(x.s.status==='completed'||x.s.completed===true)&&Array.isArray(x.s.session)).sort((a,b)=>(Number(a.s.completedAt||a.s.startTime)||0)-(Number(b.s.completedAt||b.s.startTime)||0));const seen=new Set();for(const {s,i} of sessions){const sid=pmSessionId(s,i);if(seen.has(sid))continue;seen.add(sid);pmPracticeSession(s,i,stats,record)}return stats}
function pmSync(){if(pmUnavailable)return pmBuildStats(false);pmDirty=false;const stats=pmBuildStats();const papers=Array.isArray(samplePaperSessions)?samplePaperSessions:[];for(const s of papers){if(!s||s.status!=='completed'||s.selfEnteredMarks==null)continue;const paper=samplePaperById(s.samplePaperId);if(!paper||!Number.isFinite(Number(s.selfEnteredMarks)))continue;const sid=String(s.sessionId||'sample-legacy-'+s.samplePaperId+'-'+String(s.startTime||0)),at=Number(s.startTime||s.timeFinished||Date.now());pmAddEvent('sample:'+sid,'sample_result',15,{sessionId:sid,paperId:s.samplePaperId,subject:paper.subjectKey,score:Number(s.selfEnteredMarks),maximum:paper.maximumMarks},at,true);pmBest('sample',s.samplePaperId,Number(s.selfEnteredMarks)/paper.maximumMarks,1,sid,paper.subject,at,paper.subjectKey)}
 for(const key of Object.keys(subjects))for(const ch of subjects[key].chapters)if(chapterDone(key,ch))pmAddEvent('chapter:'+key+':'+encodeURIComponent(ch),'chapter_complete',10,{subject:key,chapter:ch},0,false);pmSave();return stats}
function pmTrend(){
 const hs=pmHistory().filter(s=>s&&(s.status==='completed'||s.completed===true)&&Array.isArray(s.session)).slice().sort((a,b)=>(Number(a.completedAt||a.startTime)||0)-(Number(b.completedAt||b.startTime)||0)).slice(-8);
 return hs.map(s=>{let graded=0,correct=0;for(const q of s.session){if(!s.submitted?.[q.id]&&!['submitted-correct','submitted-incorrect'].includes(s.questionStates?.[q.id]))continue;if(Array.isArray(q.options)||q.finalAnswer!=null){graded++;if(pmCorrect(q,s.answers?.[q.id]))correct++}}return{subject:s.subject,at:Number(s.completedAt||s.startTime)||0,graded,correct,rate:graded?correct/graded:null}}).filter(x=>x.graded>0);
}
function pmSampleAnalytics(){
 const rows=(Array.isArray(samplePaperSessions)?samplePaperSessions:[]).filter(s=>s&&s.status==='completed'&&s.selfEnteredMarks!=null).map(s=>{const p=samplePaperById(s.samplePaperId);if(!p)return null;const marks=Number(s.selfEnteredMarks),max=Number(p.maximumMarks||80);return{subject:p.subjectKey,name:p.subject,marks,max,rate:max?marks/max:0,at:Number(s.timeFinished||s.startTime||0)}}).filter(Boolean);
 const by={};for(const r of rows){(by[r.subject]||(by[r.subject]=[])).push(r)};return{rows,by};
}
function pmMistakeAnalytics(){const out={};for(const m of pmMistakes()){const k=m.reason||'Needs review';out[k]=(out[k]||0)+1}return Object.entries(out).sort((a,b)=>b[1]-a[1]);}
function pmSummary(stats){let totalAttempted=0,totalGraded=0,totalCorrect=0;for(const x of Object.values(stats)){totalAttempted+=x.attempted;totalGraded+=x.graded;totalCorrect+=x.correct}return{totalAttempted,totalGraded,totalCorrect}}
function pmStreak(){const days=new Set(Object.values(pmData.events).filter(e=>e&&e.day&&['practice_complete','mistake_recovered','sample_result'].includes(e.type)).map(e=>e.day));let d=pmDay();if(!days.has(d)){const x=new Date(d+'T00:00:00');x.setDate(x.getDate()-1);d=pmDay(x.getTime())}if(!days.has(d))return 0;let n=0;while(days.has(d)&&n<4000){n++;const x=new Date(d+'T00:00:00');x.setDate(x.getDate()-1);d=pmDay(x.getTime())}return n}
function pmReadiness(stats){const keys=Object.keys(subjects),eligible=keys.filter(k=>stats[k].graded>=5),graded=eligible.reduce((a,k)=>a+stats[k].graded,0);if(eligible.length<3||graded<20)return{enough:false,eligible:eligible.length,graded};let correct=0,coverage=0;for(const k of eligible){const s=stats[k];correct+=s.correct;const practiced=Object.values(s.chapters).filter(c=>c.attempted>0).length;coverage+=subjects[k].chapters.length?practiced/subjects[k].chapters.length:0}const acc=graded?correct/graded:0,cov=eligible.length?coverage/eligible.length:0;return{enough:true,eligible:eligible.length,graded,accuracy:acc,coverage:cov,score:Math.round((acc*.8+cov*.2)*100)}}
function pmWeak(stats){const out=[];for(const k of Object.keys(subjects))for(const [chapter,c] of Object.entries(stats[k].chapters))if(c.graded>=3)out.push({subject:k,chapter,graded:c.graded,correct:c.correct,rate:c.correct/c.graded});return out.sort((a,b)=>a.rate-b.rate||b.graded-a.graded)}
function pmMakeGoals(stats,day){if(pmUnavailable)return[];if(pmData.goals[day]?.items)return pmData.goals[day].items;const items=[],used=new Set(),evs=Object.values(pmData.events),recoveredToday=new Set(evs.filter(e=>e.type==='mistake_recovered'&&e.day===day).map(e=>e.details?.questionId));const mistakes=pmMistakes();const m=mistakes.find(x=>!recoveredToday.has(x.questionId));if(m){const sk=Object.keys(subjects).find(k=>subjects[k].name===m.subject);items.push({id:'recovery-'+m.questionId,kind:'recovery',questionId:m.questionId,subject:sk,chapter:m.chapter,title:'Correctly retry one saved mistake',note:(subjects[sk]?.short||m.subject)+' • '+m.chapter});used.add(sk+'|'+m.chapter)}
 const weak=pmWeak(stats).find(x=>!used.has(x.subject+'|'+x.chapter));if(weak&&items.length<3){items.push({id:'weak-'+weak.subject+'-'+encodeURIComponent(weak.chapter),kind:'practice',subject:weak.subject,chapter:weak.chapter,title:'Practise 3 questions in a weak chapter',note:subjects[weak.subject].short+' • '+weak.chapter+' ('+Math.round(weak.rate*100)+'% on '+weak.graded+' auto-graded)'});used.add(weak.subject+'|'+weak.chapter)}
 const least=Object.keys(subjects).sort((a,b)=>stats[a].attempted-stats[b].attempted);for(const k of least){if(items.length>=3)break;if([...used].some(x=>x.startsWith(k+'|')))continue;items.push({id:'practice-'+k,kind:'practice',subject:k,chapter:'',title:'Complete a short practice set',note:subjects[k].short+' • submit at least 3 answers'});used.add(k+'|')}
 pmData.goals[day]={createdAt:Date.now(),items};pmDirty=true;pmSave();return items}
function pmGoalDone(g,day){return Object.values(pmData.events).some(e=>{if(!e||e.day!==day)return false;const d=e.details||{};if(g.kind==='recovery')return e.type==='mistake_recovered'&&d.questionId===g.questionId;if(e.type!=='practice_complete'||d.subject!==g.subject)return false;return g.chapter?Number(d.byChapter?.[g.chapter]||0)>=3:Number(d.attempted||0)>=3})}
function pmNext(stats){const weak=pmWeak(stats)[0];if(weak)return{...weak,label:`Practise ${weak.chapter} in ${subjects[weak.subject].short}`,reason:`${weak.correct}/${weak.graded} auto-graded answers correct`};const key=Object.keys(subjects).sort((a,b)=>stats[a].attempted-stats[b].attempted)[0];const chapter=subjects[key].chapters.find(c=>!stats[key].chapters[c]?.attempted)||subjects[key].chapters[0];return{subject:key,chapter,label:`Start with ${chapter} in ${subjects[key].short}`,reason:stats[key].attempted?`${stats[key].attempted} submitted answers recorded so far`:'No completed practice recorded for this subject yet'}}
function pmOpenGoal(i){const items=pmMakeGoals(pmSync(),pmDay()),g=items[i];if(!g)return;if(g.kind==='recovery'){renderReview();showPanel('reviewPanel');startMistakePractice();return}const ix=g.chapter?subjects[g.subject].chapters.indexOf(g.chapter):-1;openPracticeSetup(g.subject,ix>=0?ix:null);showPanel(g.subject)}
function updateMasteryHome(){const el=document.getElementById('masteryHomeSummary');if(!el)return;const stats=pmSync(),sum=pmSummary(stats),r=pmReadiness(stats);el.innerHTML=pmUnavailable?`<span class="small">${esc(pmNotice)}</span>`:`<span class="small">${sum.totalAttempted} submitted practice answers • ${r.enough?'Readiness signal '+r.score+'%':'Readiness: not enough data'} • ${pmXP()} XP</span>`}
function renderProgressPanel(){const stats=pmSync(),day=pmDay(),sum=pmSummary(stats),ready=pmReadiness(stats),goals=pmMakeGoals(stats,day),xp=pmXP(),level=Math.floor(xp/100)+1,inside=xp%100,streak=pmStreak(),recovered=Object.values(pmData.events).filter(e=>e?.type==='mistake_recovered').length,sampleEvents=Object.values(pmData.events).filter(e=>e?.type==='sample_result').length;
 const subjectHtml=Object.keys(subjects).map(k=>{const s=stats[k],chs=subjects[k].chapters.map(ch=>{const c=s.chapters[ch]||{attempted:0,graded:0,correct:0};const mastery=c.graded>=3?Math.round(c.correct/c.graded*100)+'%':'Building evidence';return `<div class="pm-row"><span>${esc(ch)}<small>${c.attempted} submitted • ${c.correct}/${c.graded} auto-correct • ${mastery}</small></span></div>`}).join('');const diff=['Easy','Medium','Hard'].map(d=>{const x=s.difficulty[d];return `${d}: ${x.correct}/${x.attempted}`}).join(' • ');return `<details class="card pm-subject"><summary><b>${subjects[k].icon} ${esc(subjects[k].name)}</b><span>${s.correct}/${s.graded} correct • ${s.attempted} submitted</span></summary><div class="small pm-difficulty">Difficulty (auto-graded correct/attempted): ${diff}</div>${chs}</details>`}).join('');
 const goalHtml=goals.map((g,i)=>{const done=pmGoalDone(g,day);return `<div class="pm-goal ${done?'is-done':''}"><span class="pm-check">${done?'✓':'○'}</span><div class="pm-grow"><b>${esc(g.title)}</b><small>${esc(g.note)}</small></div><button ${done?'disabled':''} onclick="pmOpenGoal(${i})">${done?'Done':g.kind==='recovery'?'Review':'Practice'}</button></div>`}).join('');
 const achievements=[['First practice',Object.values(pmData.events).some(e=>e?.type==='practice_complete'),'Complete a practice set'],['Chapter completed',Object.values(pmData.events).some(e=>e?.type==='chapter_complete'),'Mark a chapter complete'],['Mistake recovered',recovered>0,'Correctly retry a saved mistake'],['Hard practice',Object.values(pmData.events).some(e=>e?.type==='practice_complete'&&e.details?.hardCount>0),'Submit a hard question in a completed set'],['Personal best improved',Object.values(pmData.events).some(e=>e?.type==='personal_best'),'Beat a comparable personal result'],['Sample paper checked',sampleEvents>0,'Save a Sample Paper result']];
 const bests=[...Object.values(pmData.bests.practice),...Object.values(pmData.bests.sample)].filter(Boolean).sort((a,b)=>Number(b.at||0)-Number(a.at||0));const bestHtml=bests.slice(0,8).map(b=>`<div class="pm-row"><span>${esc(b.label||b.subject||'Practice')}<small>${b.n>1?b.n+' auto-graded questions • ':''}${Math.round(Number(b.score)*1000)/10}% personal best</small></span></div>`).join('')||'<p class="small">Personal bests appear after comparable results are recorded.</p>';
 const weak=pmWeak(stats),trend=pmTrend(),mistakeBreakdown=pmMistakeAnalytics(),sample=pmSampleAnalytics();
 const weakHtml=weak.length?weak.slice(0,10).map((w,i)=>`<div class="pm-row"><span><b>${i+1}. ${esc(subjects[w.subject].short||subjects[w.subject].name)} — ${esc(w.chapter)}</b><small>${w.correct}/${w.graded} auto-graded correct • ${Math.round(w.rate*100)}% • minimum evidence met</small></span><button onclick="openPracticeSetup('${w.subject}',${subjects[w.subject].chapters.indexOf(w.chapter)});showPanel('${w.subject}')">Practice</button></div>`).join(''):'<p class="small">No chapter has enough auto-graded evidence yet. Keep practising to build a reliable signal.</p>';
 const trendHtml=trend.length?trend.map(x=>`<span class="badge" style="margin:3px">${esc(subjects[x.subject]?.short||x.subject)} • ${Math.round(x.rate*100)}%</span>`).join(''):'<p class="small">Complete auto-gradable practice to see your recent accuracy trend.</p>';
 const mistakeHtml=mistakeBreakdown.length?mistakeBreakdown.map(([k,v])=>`<div class="pm-row"><span>${esc(k)}<small>${v} saved mistake${v===1?'':'s'}</small></span></div>`).join(''):'<p class="small">Your mistake categories will appear after the first saved mistake.</p>';
 const sampleHtml=sample.rows.length?Object.entries(sample.by).map(([k,rows])=>{const avg=rows.reduce((a,r)=>a+r.rate,0)/rows.length;const latest=rows.slice().sort((a,b)=>b.at-a.at)[0];return `<div class="pm-row"><span>${esc(subjects[k]?.short||k)}<small>${rows.length} saved result${rows.length===1?'':'s'} • average ${Math.round(avg*100)}% • latest ${latest.marks}/${latest.max}</small></span></div>`}).join(''):'<p class="small">Save a Sample Paper result to build paper-level analytics.</p>';
 const next=pmNext(stats),nextIdx=subjects[next.subject].chapters.indexOf(next.chapter),readinessHtml=ready.enough?`<strong class="pm-readiness-score">${ready.score}%</strong><p class="small">Practice readiness signal • based on ${ready.graded} auto-graded answers across ${ready.eligible} subjects.</p><div class="pm-bar"><i style="width:${ready.score}%"></i></div>`:`<strong>Not enough data</strong><p class="small">Need at least 20 auto-graded submitted answers, with at least 5 in each of 3 subjects. Current: ${ready.graded} across ${ready.eligible} qualifying subjects.</p>`;
 document.getElementById('progressArea').innerHTML=`<div class="hero"><div class="eyebrow">OPTIONAL STUDY SUMMARY</div><h2>Progress &amp; Mastery</h2><p>Based only on completed in-app practice, confirmed mistake retries, chapter check-offs, and saved Sample Paper results. This is a personal study aid—not a CBSE score or exam prediction.</p></div>${pmUnavailable?`<div class="notice">${esc(pmNotice)} Progress is shown as an empty state; this feature will not overwrite that data.</div>`:''}<div class="pm-top-grid"><div class="card pm-stat"><span>Mastery XP</span><b>${xp}</b><small>Level ${level} • ${100-inside} XP to next level</small><div class="pm-bar"><i style="width:${inside}%"></i></div></div><div class="card pm-stat"><span>Study streak</span><b>${streak} ${streak===1?'day':'days'}</b><small>Only meaningful recorded study days count.</small></div><div class="card pm-stat"><span>Mistakes recovered</span><b>${recovered}</b><small>Correct retries from Mistake Book practice.</small></div><div class="card pm-stat"><span>Sample papers checked</span><b>${sampleEvents}</b><small>Saved results, not just opened papers.</small></div></div><div class="card pm-card"><h3>Board readiness estimate</h3>${readinessHtml}<p class="small">When available: 80% auto-graded correctness + 20% chapter coverage among the subjects with enough evidence. Written answers and paper-only section marks are not treated as auto-graded question evidence.</p></div><div class="card pm-card"><div class="section-head" style="margin-top:0"><div><h3>Today’s focus</h3><span class="small">Goals complete only when matching app data confirms the activity.</span></div></div>${goalHtml||'<p class="small">No goals are available yet.</p>'}</div><div class="card pm-card"><h3>Recommended next practice</h3><p><b>${esc(next.label)}</b><br><span class="small">${esc(next.reason)}</span></p><button class="primary" onclick="openPracticeSetup('${next.subject}',${nextIdx>=0?nextIdx:'null'});showPanel('${next.subject}')">Start practice</button></div><div class="section-head"><h3>Weak Areas &amp; Revision Queue</h3><span class="small">Ranked only when at least 3 auto-graded answers exist.</span></div><div class="card pm-card">${weakHtml}</div><div class="card pm-card"><h3>Recent Accuracy Trend</h3><div style="margin-top:6px">${trendHtml}</div><p class="small">This shows your most recent completed practice sets with auto-gradable answers; it is not a predicted board score.</p></div><div class="card pm-card"><h3>Mistake Pattern</h3>${mistakeHtml}</div><div class="card pm-card"><h3>Sample Paper Performance</h3>${sampleHtml}</div><div class="section-head"><h3>Subject &amp; chapter mastery</h3><span class="small">Submitted / correct values use completed sessions.</span></div><p class="small">Only MCQ and numeric answers with a known answer key count toward correctness and difficulty performance. Written-answer correctness is not inferred from the current saved records.</p>${subjectHtml}<div class="card pm-card"><h3>Personal bests</h3><p class="small">Practice bests compare the same subject, filters and number of auto-graded questions; Sample Paper bests compare attempts of the same paper.</p>${bestHtml}</div><div class="card pm-card"><h3>Achievements</h3><div class="pm-achievements">${achievements.map(([name,ok,desc])=>`<div class="pm-achievement ${ok?'earned':''}"><b>${ok?'✓':'○'} ${esc(name)}</b><small>${esc(desc)}</small></div>`).join('')}</div></div><details class="card pm-card"><summary><b>How XP and estimates work</b></summary><div class="small pm-rules"><p>• Completing practice with at least 3 submitted answers: 10 XP, plus 2 XP per auto-graded correct answer (up to 10 bonus XP). Wrong answers never reduce XP.</p><p>• Correctly retrying a saved mistake in Mistake Book practice: 5 XP per question, once per retry session.</p><p>• Checking a chapter complete: 10 XP the first time. Saving a Sample Paper result: 15 XP. Improving a comparable personal best: 10 XP; the first result sets the baseline.</p><p>• Levels advance every 100 XP. Streaks use the device’s local calendar date and count completed practice sets, successful mistake retries, or saved Sample Paper results. Chapter check-offs alone do not extend a streak.</p><p>• Readiness requires 20 auto-graded answers and 5 in each of 3 subjects. It is an in-app practice signal; it is not a CBSE score or prediction.</p></div></details>`;
}
function openProgressPanel(){renderProgressPanel();showPanel('progressPanel')}

const sdOriginalFinishPractice=finishPractice;finishPractice=async function(){sdOriginalFinishPractice();try{await syncPracticeHistoryToSupabase()}catch(e){console.warn('ScoreDeck practice sync after finish failed:',e)}};
const pmOriginalSubmit=submitAnswer;submitAnswer=function(q){const already=!!state.submitted[q.id],sid=state.sessionId||'',wasSaved=pmMistakes().some(m=>m.questionId===q.id);pmOriginalSubmit(q);if(!already&&state.submitted[q.id]&&wasSaved&&sid.startsWith('ps-mistakes-')&&pmCorrect(q,state.answers[q.id])){pmAddEvent('recovery:'+sid+':'+q.id,'mistake_recovered',5,{sessionId:sid,questionId:q.id,subject:pmSubject(q,{subject:state.currentSubject}),chapter:q.chapter},Date.now(),true);pmSave();updateMasteryHome()}};
const pmOriginalFinish=finishPractice;finishPractice=function(){pmOriginalFinish();pmSync();updateMasteryHome()};
const pmOriginalChapter=toggleChapterDone;toggleChapterDone=function(key,ch,checked){const was=chapterDone(key,ch);pmOriginalChapter(key,ch,checked);if(checked&&!was){pmAddEvent('chapter:'+key+':'+encodeURIComponent(ch),'chapter_complete',10,{subject:key,chapter:ch},Date.now(),false);pmSave();updateMasteryHome()}};
const pmOriginalSampleResult=saveSampleResult;saveSampleResult=function(id){const before=getSampleSession(id),wasCompleted=!!(before&&before.status==='completed'&&before.selfEnteredMarks!=null),beforeMarks=before?.selfEnteredMarks,beforeRows=JSON.stringify(before?.questionMarks||{});pmOriginalSampleResult(id);const s=getSampleSession(id),p=s&&samplePaperById(s.samplePaperId),changed=s&&s.status==='completed'&&s.selfEnteredMarks!=null&&(!wasCompleted||beforeMarks!==s.selfEnteredMarks||beforeRows!==JSON.stringify(s.questionMarks||{}));if(changed&&p){const sid=String(s.sessionId||id),at=Date.now();pmAddEvent('sample:'+sid,'sample_result',15,{sessionId:sid,paperId:s.samplePaperId,subject:p.subjectKey,score:Number(s.selfEnteredMarks),maximum:p.maximumMarks},at,true);pmBest('sample',s.samplePaperId,Number(s.selfEnteredMarks)/p.maximumMarks,1,sid,p.subject,at,p.subjectKey);pmSave();updateMasteryHome()}};
pmSync();updateMasteryHome();
// Fetch active Update Centre announcements at app startup.
loadScoreDeckUpdates();
if($('accountBtn'))$('accountBtn').onclick=openAuthDialog;if($('authClose'))$('authClose').onclick=closeAuthDialog;if($('authCloseSignedIn'))$('authCloseSignedIn').onclick=closeAuthDialog;if($('authSignIn'))$('authSignIn').onclick=scoreDeckSignIn;if($('authSignUp'))$('authSignUp').onclick=scoreDeckSignUp;if($('authSignOut'))$('authSignOut').onclick=scoreDeckSignOut;if($('authDialog'))$('authDialog').addEventListener('click',e=>{if(e.target===$('authDialog'))closeAuthDialog()});initScoreDeckAuth();initScoreDeckUpdates();
