package com.mpscmo.tracker;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;
    private SharedPreferences prefs;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("mpsc_tracker", MODE_PRIVATE);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(false);
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(this), "AndroidBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                String topic = prefs.getString("topic", "Open the app to see today's topic");
                view.evaluateJavascript("window.setReminderTopic && window.setReminderTopic(" +
                    org.json.JSONObject.quote(topic) + ")", null);
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        createChannel();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
        }
        if (!prefs.getBoolean("reminderConfigured", false)) {
            ReminderReceiver.schedule(this, 9, 0);
            prefs.edit().putBoolean("reminderConfigured", true).putInt("hour",9).putInt("minute",0).apply();
        }
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            android.app.NotificationChannel ch = new android.app.NotificationChannel("mpsc_daily", "Daily study reminder", android.app.NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Daily reminder for your MPSC MO study topic");
            getSystemService(android.app.NotificationManager.class).createNotificationChannel(ch);
        }
    }
    public class Bridge {
        private final Context context;
        Bridge(Context c) { context = c; }
        @JavascriptInterface public void scheduleReminder(int hour, int minute, String topic, String startDate) {
            hour = Math.max(0, Math.min(23, hour)); minute = Math.max(0, Math.min(59, minute));
            prefs.edit().putInt("hour", hour).putInt("minute", minute).putString("topic", topic).putString("startDate", startDate).putBoolean("reminderConfigured", true).apply();
            ReminderReceiver.schedule(context, hour, minute);
        }
        @JavascriptInterface public void updateTopic(String topic) {
            prefs.edit().putString("topic", topic).apply();
        }
        @JavascriptInterface public void cancelReminder() {
            android.app.AlarmManager am = (android.app.AlarmManager) getSystemService(ALARM_SERVICE);
            Intent i = new Intent(context, ReminderReceiver.class);
            android.app.PendingIntent pi = android.app.PendingIntent.getBroadcast(context, 411, i, android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE);
            am.cancel(pi);
            prefs.edit().putBoolean("reminderConfigured", false).apply();
        }
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
