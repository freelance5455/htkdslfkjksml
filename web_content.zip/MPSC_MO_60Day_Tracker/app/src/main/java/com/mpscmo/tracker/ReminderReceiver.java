package com.mpscmo.tracker;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.app.Notification;
import android.app.NotificationManager;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class ReminderReceiver extends BroadcastReceiver {
    static PendingIntent pending(Context c) {
        Intent i = new Intent(c, ReminderReceiver.class);
        return PendingIntent.getBroadcast(c, 411, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    public static void schedule(Context c, int hour, int minute) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, hour); cal.set(Calendar.MINUTE, minute); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0);
        if (!cal.after(Calendar.getInstance())) cal.add(Calendar.DAY_OF_YEAR, 1);
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pending(c));
    }
    private String[] currentTopic(Context c, SharedPreferences p) {
        String start = p.getString("startDate", "2026-10-23");
        int day = 1;
        try {
            SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            fmt.setLenient(false);
            Date startDate = fmt.parse(start);
            Calendar a = Calendar.getInstance(); a.setTime(startDate); a.set(Calendar.HOUR_OF_DAY,0); a.set(Calendar.MINUTE,0); a.set(Calendar.SECOND,0); a.set(Calendar.MILLISECOND,0);
            Calendar b = Calendar.getInstance(); b.set(Calendar.HOUR_OF_DAY,0); b.set(Calendar.MINUTE,0); b.set(Calendar.SECOND,0); b.set(Calendar.MILLISECOND,0);
            day = (int)((b.getTimeInMillis()-a.getTimeInMillis())/86400000L)+1;
        } catch (Exception ignored) {}
        day = Math.max(1, Math.min(60, day));
        String topic = p.getString("topic", "Open the app to see today's MPSC MO topic");
        try (BufferedReader br = new BufferedReader(new InputStreamReader(c.getAssets().open("plan.json")))) {
            StringBuilder sb = new StringBuilder(); String line; while ((line=br.readLine())!=null) sb.append(line);
            JSONArray arr = new JSONArray(sb.toString());
            JSONObject item = arr.getJSONObject(day-1);
            topic = "Day " + day + ": " + item.optString("topic", topic);
        } catch (Exception ignored) {}
        p.edit().putString("topic", topic).putInt("day", day).apply();
        return new String[]{String.valueOf(day), topic};
    }
    @Override public void onReceive(Context context, Intent intent) {
        SharedPreferences p = context.getSharedPreferences("mpsc_tracker", Context.MODE_PRIVATE);
        if (!p.getBoolean("reminderConfigured", false)) return;
        String[] current = currentTopic(context, p);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(context, "mpsc_daily") : new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_popup_reminder)
         .setContentTitle("MPSC MO • Today's study")
         .setContentText(current[1])
         .setStyle(new Notification.BigTextStyle().bigText(current[1]))
         .setAutoCancel(true);
        NotificationManager nm = (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        try { nm.notify(411, b.build()); } catch (SecurityException ignored) {}
        schedule(context, p.getInt("hour",9), p.getInt("minute",0));
    }
}
