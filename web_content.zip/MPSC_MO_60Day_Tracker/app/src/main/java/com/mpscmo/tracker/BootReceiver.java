package com.mpscmo.tracker;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        SharedPreferences p = c.getSharedPreferences("mpsc_tracker", Context.MODE_PRIVATE);
        if (p.getBoolean("reminderConfigured", false)) ReminderReceiver.schedule(c, p.getInt("hour",9), p.getInt("minute",0));
    }
}
