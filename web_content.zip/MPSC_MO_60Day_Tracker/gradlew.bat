@echo off
setlocal
set "GRADLE_VERSION=8.9"
if defined GRADLE_USER_HOME (set "GH=%GRADLE_USER_HOME%\mpsc-wrapper\gradle-%GRADLE_VERSION%") else (set "GH=%USERPROFILE%\.gradle\mpsc-wrapper\gradle-%GRADLE_VERSION%")
if exist "%GH%\bin\gradle.bat" goto run
where gradle >nul 2>nul
if %errorlevel%==0 (gradle %* & exit /b %errorlevel%)
echo Gradle 8.9 is not installed. Install Gradle or use Android Studio to sync the project.
exit /b 1
:run
call "%GH%\bin\gradle.bat" -p "%~dp0" %*
exit /b %errorlevel%
