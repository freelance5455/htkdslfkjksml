package com.turboboost.pro;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.os.PowerManager;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;
import java.io.File;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new NativeBridge(this), "AndroidBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class NativeBridge {
        private final Context ctx;
        NativeBridge(Context context) { ctx = context; }

        @JavascriptInterface public String getDeviceInfo() {
            JSONObject j = new JSONObject();
            try {
                j.put("manufacturer", Build.MANUFACTURER);
                j.put("brand", Build.BRAND);
                j.put("model", Build.MODEL);
                j.put("device", Build.DEVICE);
                j.put("android", Build.VERSION.RELEASE);
                j.put("sdk", Build.VERSION.SDK_INT);
                j.put("cores", Runtime.getRuntime().availableProcessors());
                j.put("screen", getResources().getDisplayMetrics().widthPixels + " × " +
                        getResources().getDisplayMetrics().heightPixels);
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                ActivityManager am = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
                am.getMemoryInfo(mi);
                j.put("ramTotal", mi.totalMem);
                j.put("ramAvailable", mi.availMem);
            } catch (Exception ignored) {}
            return j.toString();
        }

        @JavascriptInterface public String getLiveStats() {
            JSONObject j = new JSONObject();
            try {
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                ActivityManager am = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
                am.getMemoryInfo(mi);
                j.put("ramTotal", mi.totalMem);
                j.put("ramAvailable", mi.availMem);
                j.put("lowMemory", mi.lowMemory);

                Intent battery = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                if (battery != null) {
                    int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                    j.put("battery", (level >= 0 && scale > 0) ? Math.round(level * 100f / scale) : -1);
                    j.put("charging", battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ==
                            BatteryManager.BATTERY_STATUS_CHARGING);
                    int temp = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
                    j.put("batteryTempC", temp >= 0 ? temp / 10.0 : JSONObject.NULL);
                }

                File path = Environment.getDataDirectory();
                StatFs stat = new StatFs(path.getPath());
                long total = stat.getTotalBytes();
                long free = stat.getAvailableBytes();
                j.put("storageTotal", total);
                j.put("storageFree", free);
                j.put("storageUsedPercent", total > 0 ? Math.round((total-free)*100f/total) : -1);

                if (Build.VERSION.SDK_INT >= 29) {
                    PowerManager pm = (PowerManager)ctx.getSystemService(POWER_SERVICE);
                    j.put("thermalStatus", pm.getCurrentThermalStatus());
                } else {
                    j.put("thermalStatus", -1);
                }
            } catch (Exception ignored) {}
            return j.toString();
        }

        @JavascriptInterface public String clearAppCache() {
            try {
                File cache = ctx.getCacheDir();
                long before = folderSize(cache);
                deleteContents(cache);
                JSONObject result = new JSONObject();
                result.put("success", true);
                result.put("freedBytes", before);
                return result.toString();
            } catch (Exception e) {
                JSONObject result = new JSONObject();
                try { result.put("success", false); result.put("error", e.getMessage()); } catch(Exception ignored) {}
                return result.toString();
            }
        }

        @JavascriptInterface public void openAppSettings() {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + ctx.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        }

        @JavascriptInterface public void openBatterySettings() {
            Intent i = new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try { ctx.startActivity(i); }
            catch (Exception e) { openAppSettings(); }
        }

        private long folderSize(File f) {
            if (f == null || !f.exists()) return 0;
            if (f.isFile()) return f.length();
            long n = 0; File[] list = f.listFiles();
            if (list != null) for (File x : list) n += folderSize(x);
            return n;
        }
        private void deleteContents(File f) {
            if (f == null || !f.exists()) return;
            File[] list = f.listFiles();
            if (list != null) for (File x : list) {
                if (x.isDirectory()) { deleteContents(x); x.delete(); }
                else x.delete();
            }
        }
    }
}
