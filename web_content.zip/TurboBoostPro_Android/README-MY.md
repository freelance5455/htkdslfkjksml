# TurboBoost Pro — Projek Android

## Kandungan
- Projek Android Studio berasaskan Java + WebView.
- Maklumat peranti sebenar melalui Android API.
- Bacaan RAM sistem (jumlah dan tersedia), bateri, storan dan suhu bateri jika peranti menyokongnya.
- Pembersihan cache aplikasi TurboBoost Pro sahaja.
- Pintasan ke tetapan aplikasi dan Battery Saver.

## Bina APK
1. Muat turun dan ekstrak ZIP ini.
2. Buka folder `TurboBoostPro_Android` melalui Android Studio pada komputer.
3. Benarkan Gradle Sync dan pemasangan Android SDK yang diminta.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Had Android yang perlu diketahui
- Aplikasi biasa tidak boleh membunuh proses aplikasi lain atau mengosongkan RAM global.
- Aplikasi biasa tidak boleh memadam cache aplikasi lain tanpa kebenaran khas/sistem.
- Aplikasi ini tidak mengawal kipas/voltan/clock CPU dan tidak boleh menjamin peningkatan FPS.
- Suhu yang dipaparkan ialah suhu bateri; status haba sistem memerlukan Android 10+.
- Statistik RAM ialah maklumat sistem yang dilaporkan Android, bukan bacaan CPU load.

## Keperluan
- Android Studio versi semasa dengan Android SDK 35.
- JDK 17 (biasanya disediakan bersama Android Studio).
- Min Android: Android 6.0 (API 23).
