VOID WALKER: COIN RUN — Android Studio project

Yeh Android WebView app ka source project hai; APK file abhi is ZIP mein nahi hai.
APK banane ke liye:
1. Computer par Android Studio install karo.
2. Is ZIP ko extract karo.
3. Android Studio mein extracted folder open karo.
4. Gradle sync complete hone do.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) chuno.
6. APK app/build/outputs/apk/debug/ mein milega.

Play Store ke liye release signing, app bundle (.aab), testing aur Google Play Console ki current requirements alag se poori karni hongi.
