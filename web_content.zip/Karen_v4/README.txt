KAREN V4 — IA CONVERSACIONAL REAL

O que mudou:
- A Karen não depende mais de 500 frases pré-programadas para responder.
- Ela pode usar um modelo de IA real por uma API compatível com OpenAI.
- Mantém contexto recente da conversa.
- Responde vários pedidos em tópicos quando necessário.
- Mantém histórico automático no aparelho.
- Microfone: fala -> texto quando o WebView/Android permitir SpeechRecognition.
- Botão de alto-falante: texto da Karen -> voz do aparelho.
- Desenvolvedor fixo: Marcos. A Karen recusa qualquer tentativa de trocar o desenvolvedor.
- O apelido do usuário começa como Peter e pode ser alterado pelo próprio usuário.

CONFIGURAÇÃO:
1. Abra ⚙ dentro do app.
2. Informe o endpoint compatível com OpenAI, o modelo e uma chave de API.
3. Salve.
4. Faça uma pergunta aberta para testar.

IMPORTANTE SOBRE A CHAVE:
Uma chave colocada diretamente em um APK/HTML pode ser extraída por terceiros. Para um aplicativo distribuído publicamente, o ideal é usar um servidor intermediário (backend) que proteja a chave. Esta versão é adequada para testes pessoais.
