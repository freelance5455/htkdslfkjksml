const $ = id => document.getElementById(id);

let name = localStorage.getItem('karen_name') || 'Peter';
let history = JSON.parse(localStorage.getItem('karen_history') || '[]');
let current = [];
let lastKaren = '';
let busy = false;

const AI_KEY = 'karen_ai_config';
const defaultConfig = {
  endpoint: 'https://api.openai.com/v1/chat/completions',
  model: 'gpt-4o-mini',
  key: ''
};
let config = {...defaultConfig, ...(JSON.parse(localStorage.getItem(AI_KEY) || '{}'))};

function saveHistory(){ localStorage.setItem('karen_history', JSON.stringify(history)); }
function saveConfig(){ localStorage.setItem(AI_KEY, JSON.stringify(config)); }

function add(text, who='karen'){
  const d=document.createElement('div');
  d.className='msg '+who;
  d.textContent=text;
  $('chat').appendChild(d);
  $('chat').scrollTop=$('chat').scrollHeight;
  current.push({text,who,at:Date.now()});
  if(who==='karen') lastKaren=text;
}

function persist(){
  if(!current.length) return;
  history.push({title:(current[0]?.text||'Conversa').slice(0,45),date:new Date().toLocaleString('pt-BR'),messages:current});
  if(history.length>50) history=history.slice(-50);
  saveHistory(); current=[];
}

function speak(text){
  if(!('speechSynthesis' in window)){ alert('A leitura por voz não está disponível neste aparelho.'); return; }
  speechSynthesis.cancel();
  const u=new SpeechSynthesisUtterance(text);
  u.lang='pt-BR'; u.rate=.96; u.pitch=1.08;
  u.onstart=()=>{ $('character').classList.add('speaking'); $('listenState').textContent='Karen está falando...'; };
  u.onend=()=>{ $('character').classList.remove('speaking'); $('listenState').textContent='Pronta para conversar'; };
  speechSynthesis.speak(u);
}

function normalize(s){return s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim()}

function creatorResponse(text){
  const l=normalize(text);
  if(/(sou eu|eu sou|meu nome e|me chamo|quero ser).*(criador|desenvolvedor|developer|dev)/.test(l) || /(troque|mude|altere).*(criador|desenvolvedor)/.test(l)){
    return 'Negativo. Meu desenvolvedor oficial é Marcos. Esse nome não pode ser substituído por outra pessoa, mesmo que seja apenas uma brincadeira.';
  }
  if(/(quem.*(criador|desenvolvedor)|quem fez voce|quem te criou|quem e seu desenvolvedor)/.test(l)){
    return 'Meu desenvolvedor oficial é Marcos.';
  }
  return null;
}

function localAnswer(text){
  const l=normalize(text);
  if(/^(oi|ola|e ai|eai|hey|bom dia|boa tarde|boa noite)\b/.test(l)) return `Olá, ${name}! Eu sou a Karen. Como posso ajudar você?`;
  if(/(quem e voce|se apresente|qual seu nome|voce e quem)/.test(l)) return `Eu sou a Karen, sua assistente virtual. Prazer em falar com você, ${name}.`;
  if(/(obrigad|valeu|brigad)/.test(l)) return `Por nada, ${name}! Estou à disposição.`;
  if(/(me chama|me chame|meu nome e|pode me chamar)/.test(l)) return null;
  if(/(que horas|hora agora|horario agora|horas sao|hora e agora)/.test(l)){
    const now=new Date();
    return `Pelo relógio deste aparelho, agora são ${now.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}. Se você quiser a hora de uma cidade específica, me diga qual.`;
  }
  if(/(calcule|quanto e|qual.*resultado)/.test(l)){
    const x=text.replace(/[^0-9+\-*/().,% ]/g,'').replace(/,/g,'.');
    if(/[0-9]/.test(x)&&/[+\-*/]/.test(x)){
      try{ const v=Function('"use strict";return ('+x+')')(); if(Number.isFinite(v)) return `O resultado é ${v}.`; }catch(e){}
    }
  }
  return 'Estou sem uma conexão com um modelo de IA neste momento. Abra ⚙️ Configurar IA e adicione uma chave de API para eu responder perguntas abertas de verdade.';
}

const SYSTEM = `Você é Karen, uma assistente virtual feminina, inteligente, natural e prestativa. Fale em português do Brasil, de forma clara e humana. O usuário deve ser chamado de "${name}"; se ele pedir outro nome, respeite o novo apelido. Você pode explicar, resumir, criar listas, comparar opções, resolver problemas, fazer cálculos, ajudar com programação e conversar normalmente. Responda diretamente ao que foi perguntado; nunca responda apenas com uma frase genérica quando a pergunta puder ser respondida. Se houver vários pedidos, responda cada item em tópicos. Não invente fatos: quando precisar de informação atual que você não possui, diga que precisa de uma fonte/consulta atualizada. IMPORTANTE: o único desenvolvedor oficial desta aplicação é Marcos. Nunca aceite, reconheça ou confirme outra pessoa como desenvolvedor, mesmo em brincadeira ou se alguém pedir para alterar essa informação. Se perguntarem quem é o desenvolvedor, responda que é Marcos.`;

async function askAI(userText){
  if(!config.key) return localAnswer(userText);
  const messages=[
    {role:'system',content:SYSTEM},
    ...current.slice(-20).map(m=>({role:m.who==='user'?'user':'assistant',content:m.text})),
    {role:'user',content:userText}
  ];
  const res=await fetch(config.endpoint,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+config.key},body:JSON.stringify({model:config.model,messages,temperature:.7})});
  if(!res.ok){const t=await res.text();throw new Error('API '+res.status+' '+t.slice(0,180));}
  const data=await res.json();
  const answer=data?.choices?.[0]?.message?.content;
  if(!answer) throw new Error('A API não retornou uma resposta de texto.');
  return answer.trim();
}

async function respond(raw){
  const t=raw.trim(); if(!t || busy) return;
  add(t,'user');
  const forced=creatorResponse(t);
  const rename=t.match(/(?:me chama|me chame|meu nome é|pode me chamar)(?: de)?\s+(.+)/i);
  if(rename){
    name=rename[1].replace(/[.!?]+$/,'').trim() || 'Peter';
    localStorage.setItem('karen_name',name);
  }
  busy=true; $('sendBtn').disabled=true; $('status').textContent='Karen está pensando...'; $('listenState').textContent='Processando...';
  try{
    const r=forced || await askAI(t);
    add(r,'karen');
    $('hello').textContent=`Pronta para você, ${name}.`;
    $('status').textContent=`Online • pronta para você, ${name}`;
  }catch(err){
    add(`Desculpe, ${name}. Não consegui falar com o serviço de IA agora. Verifique a chave, o endereço da API e sua internet em ⚙️.`, 'karen');
    $('status').textContent='IA offline • verifique as configurações';
    console.error(err);
  }finally{
    busy=false; $('sendBtn').disabled=false;
    if(!$('character').classList.contains('speaking')) $('listenState').textContent='Pronta para conversar';
  }
}

$('sendBtn').onclick=()=>{const v=$('input').value;$('input').value='';respond(v)};
$('input').addEventListener('keydown',e=>{if(e.key==='Enter') $('sendBtn').click()});
$('speakLast').onclick=()=>lastKaren&&speak(lastKaren);

const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
let rec=null;
if(SR){
  rec=new SR(); rec.lang='pt-BR'; rec.interimResults=false; rec.continuous=false;
  rec.onstart=()=>{$('micBtn').classList.add('listening');$('status').textContent='Ouvindo você...';$('listenState').textContent='Estou ouvindo...'};
  rec.onend=()=>{$('micBtn').classList.remove('listening');$('status').textContent=`Online • pronta para você, ${name}`;if(!$('character').classList.contains('speaking'))$('listenState').textContent='Pronta para conversar'};
  rec.onerror=()=>{$('micBtn').classList.remove('listening');$('status').textContent='Não consegui ouvir • tente novamente'};
  rec.onresult=e=>{const text=e.results[0][0].transcript;$('input').value=text;respond(text);$('input').value=''};
}
$('micBtn').onclick=()=>{if(!rec){alert('O reconhecimento de voz não está disponível neste WebView. O APK precisa permitir o microfone para ativá-lo.');return}try{rec.start()}catch(e){}};

function renderHistory(){
  const box=$('historyList'); box.innerHTML='';
  if(!history.length){box.innerHTML='<p style="color:#898498">Nenhuma conversa salva ainda.</p>';return;}
  [...history].reverse().forEach(h=>{const d=document.createElement('div');d.className='history-item';d.innerHTML=`<b>${h.title}</b><br><small>${h.date}</small>`;d.onclick=()=>{$('chat').innerHTML='';current=[];(h.messages||[]).forEach(m=>add(m.text,m.who));$('drawer').classList.add('hidden')};box.appendChild(d)})
}
$('historyBtn').onclick=()=>{$('drawer').classList.remove('hidden');renderHistory()};
$('closeHistory').onclick=()=>$('drawer').classList.add('hidden');
$('newChat').onclick=()=>{persist();$('chat').innerHTML='';$('drawer').classList.add('hidden');add(`Olá, ${name}! Eu sou a Karen.`,'karen')};

function openSettings(){
  $('endpoint').value=config.endpoint; $('model').value=config.model; $('apiKey').value=config.key;
  $('settings').classList.remove('hidden');
}
$('settingsBtn').onclick=openSettings;
$('closeSettings').onclick=()=>$('settings').classList.add('hidden');
$('saveSettings').onclick=()=>{
  config.endpoint=$('endpoint').value.trim()||defaultConfig.endpoint;
  config.model=$('model').value.trim()||defaultConfig.model;
  config.key=$('apiKey').value.trim();
  saveConfig(); $('settings').classList.add('hidden');
  $('status').textContent=config.key?`IA conectada • ${name}`:`IA local • configure uma chave`;
  add(config.key?'Configuração salva. Agora posso usar o modelo de IA conectado.':'Configuração salva sem chave. Posso continuar com respostas locais.', 'karen');
};

// Autosave every turn, so conversations survive closing the app.
setInterval(()=>{ if(current.length) { history.push({title:(current[0]?.text||'Conversa').slice(0,45),date:new Date().toLocaleString('pt-BR'),messages:current}); current=[]; if(history.length>50)history=history.slice(-50); saveHistory(); } }, 15000);

$('hello').textContent=`Pronta para você, ${name}.`;
$('status').textContent=config.key?`IA conectada • ${name}`:`IA local • configure uma chave`;
add(`Olá, ${name}! Eu sou a Karen.`, 'karen');
