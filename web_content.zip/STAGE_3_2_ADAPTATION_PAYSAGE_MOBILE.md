# CGD V117 — Socle 3.2 : adaptation paysage mobile

## Objectif
Adapter l'interface du CGD V117 aux téléphones en donnant la priorité à l'affichage horizontal, sans supprimer de rubriques, de contenus ou de fonctions.

## Réalisations
- Suppression de la largeur minimale fixe de 720 px appliquée au document, qui provoquait un défilement horizontal global sur téléphone.
- Ajout de règles CSS dédiées au paysage mobile : en-tête compact, panneaux resserrés, quatre colonnes de compétitions et zone de match en deux colonnes (damier + informations).
- Dimensionnement du damier selon la hauteur disponible en paysage ; panneau d'informations de match défilable indépendamment.
- Ajout d'une présentation de secours en portrait : sections conservées, compétitions en colonne, damier redimensionné et informations de match accessibles sous le plateau.
- Ajout d'un conseil d'orientation sur les petits écrans tactiles tenus verticalement, avec deux choix : tenter le passage en paysage ou continuer en portrait.
- Le verrouillage paysage est tenté uniquement après action de l'utilisateur et seulement si le navigateur le prend en charge. Le jeu reste utilisable si cette API est absente ou refusée.
- Aucun moteur de compétition, de calendrier, de contrat, de transfert, de règles de dames ou de scène 3D n'a été modifié.

## Vérifications
- 186 tests automatisés : 178 tests précédents et 8 tests ajoutés pour le socle 3.2.
- Vérification syntaxique Node.js de tous les fichiers JavaScript.
- Contrôle des identifiants des principales sections afin de confirmer leur conservation.

## Limite connue
Le navigateur et le système d'exploitation gardent le contrôle final de la rotation physique. Le CGD optimise l'affichage paysage et peut demander un verrouillage après interaction, mais ne peut pas imposer cette rotation sur tous les téléphones et navigateurs.
