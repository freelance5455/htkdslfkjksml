# Vinz Touch Panel

Android WebView app with Shizuku permission request flow and Free Fire MAX launch button.

- App label: Vinz Touch Panel
- Package: com.vinz.optimize
- Includes HTML slider panel and Shizuku permission check/request.
- This project does NOT implement actual touchscreen X/Y sensitivity or touch acceleration. Android/ColorOS does not expose a verified public API for these exact game controls, and Shizuku permission alone does not create one.
- FF MAX launch target is com.dts.freefiremax; adjust if the installed variant uses another package.

Build requires Android Studio/Gradle environment and JDK 17. This ZIP is source code, not an APK.
