package com.vinz.optimize;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int REQUEST_CODE = 7321;
    private TextView status;
    private WebView web;

    private final Shizuku.OnRequestPermissionResultListener permissionListener =
        (requestCode, grantResult) -> runOnUiThread(() -> {
            if (requestCode != REQUEST_CODE) return;
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                status.setText("Shizuku: izin diberikan. Belum ada API touchscreen X/Y yang terverifikasi.");
            } else {
                status.setText("Shizuku: izin ditolak.");
            }
        });

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(8, 13, 22));

        LinearLayout bar = new LinearLayout(this);
        bar.setPadding(12, 8, 12, 8);
        Button connect = new Button(this);
        connect.setText("CONNECT SHIZUKU");
        Button launch = new Button(this);
        launch.setText("OPEN FREE FIRE MAX");
        bar.addView(connect, new LinearLayout.LayoutParams(0, -2, 1));
        bar.addView(launch, new LinearLayout.LayoutParams(0, -2, 1));
        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setPadding(16, 10, 16, 10);
        status.setText("Vinz Touch Panel • Memeriksa Shizuku…");
        root.addView(bar);
        root.addView(status);

        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(8, 13, 22));
        web.getSettings().setJavaScriptEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.loadUrl("file:///android_asset/index.html");
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        Shizuku.addRequestPermissionResultListener(permissionListener);
        connect.setOnClickListener(v -> requestShizuku());
        launch.setOnClickListener(v -> openGame());
        refreshShizukuStatus();
    }

    private void refreshShizukuStatus() {
        try {
            if (!Shizuku.pingBinder()) status.setText("Shizuku belum aktif. Jalankan service Shizuku dahulu.");
            else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED)
                status.setText("Shizuku aktif • izin sudah diberikan. Dukungan kontrol touchscreen belum terverifikasi.");
            else status.setText("Shizuku aktif • izin aplikasi belum diberikan. Tekan CONNECT SHIZUKU.");
        } catch (Exception e) {
            status.setText("Tidak dapat memeriksa Shizuku: " + e.getClass().getSimpleName());
        }
    }

    private void requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                status.setText("Shizuku tidak terhubung. Aktifkan Shizuku dahulu.");
                return;
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                status.setText("Izin Shizuku sudah ada. Belum ada command touchscreen X/Y yang terbukti didukung.");
                return;
            }
            Shizuku.requestPermission(REQUEST_CODE);
            status.setText("Permintaan izin dikirim. Pilih Allow pada dialog Shizuku.");
        } catch (Exception e) {
            status.setText("Permintaan izin gagal: " + e.getClass().getSimpleName());
        }
    }

    private void openGame() {
        Intent intent = getPackageManager().getLaunchIntentForPackage("com.dts.freefiremax");
        if (intent == null) {
            Toast.makeText(this, "Free Fire MAX tidak ditemukan. Periksa package game.", Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(intent);
    }

    @Override protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
