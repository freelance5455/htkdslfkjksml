'use strict';
const $=id=>document.getElementById(id);
const state={history:[],bookmarks:[],downloads:[]};
function go(raw){const q=raw.trim();if(!q)return;let url;if(/^https?:\/\//i.test(q))url=q;else if(/^[\w.-]+\.[a-z]{2,}([/:?#].*)?$/i.test(q))url='https://'+q;else url='https://www.google.com/search?q='+encodeURIComponent(q);try{const u=new URL(url);if(u.protocol!=='https:'&&u.protocol!=='http:')throw Error();state.history.push(url);window.open(url,'_blank','noopener,noreferrer')}catch{alert('Please enter a valid web address.')}} 
$('searchForm').addEventListener('submit',e=>{e.preventDefault();go($('search').value)});
$('address').addEventListener('keydown',e=>{if(e.key==='Enter')go($('address').value)});
document.querySelectorAll('[data-url]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.url)));
function show(which){const names={history:'History',bookmarks:'Bookmarks',downloads:'Downloads',privacy:'Privacy & ad blocking',desktop:'Desktop site',clear:'Clear browsing data'};const data=state[which];$('status').innerHTML='';const h=document.createElement('h2');h.textContent=names[which]||'Browser tools';$('status').append(h);const p=document.createElement('p');p.textContent=Array.isArray(data)&&data.length?data.join('\n'):'No items yet. This starter UI does not yet implement full browser-engine storage or network filtering.';$('status').append(p);$('status').scrollIntoView({behavior:'smooth'});}
$('privacy').onclick=()=>show('privacy');$('downloads').onclick=()=>show('downloads');$('bookmarks').onclick=()=>show('bookmarks');$('history').onclick=()=>show('history');
$('menu').onclick=$('menuBottom').onclick=()=>$('menuDialog').showModal();$('closeMenu').onclick=()=>$('menuDialog').close();
document.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>{show(b.dataset.action);$('menuDialog').close()});
$('newTab').onclick=()=>{ $('address').value='';$('address').focus();};$('tabCount').onclick=()=>alert('Tab management is planned for the native Android browser engine build.');
$('refresh').onclick=()=>alert('Open pages in a full browser tab to refresh them.');$('back').onclick=()=>history.back();$('home').onclick=()=>window.scrollTo({top:0,behavior:'smooth'});
$('bookmark').onclick=()=>{const v=$('address').value.trim();if(v)state.bookmarks.push(v);show('bookmarks')};
if('serviceWorker'in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('./sw.js').catch(()=>{});
