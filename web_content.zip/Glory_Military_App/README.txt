GLORY MILITARY - prototype starter
=================================

This is a mobile-friendly web-app prototype with:
- Command dashboard
- Public military schedule
- Events and tasks boards
- Recruitment form (demo only; not connected to a server)
- Creative archive sections
- Vision, mission, and starter organization rules
- Installable PWA setup (manifest + service worker)

IMPORTANT:
This ZIP is source code, NOT an APK. It does not yet include a real login system,
database, admin moderation, or server-side recruitment submission. Those require
backend setup and security rules.

To preview:
1. Upload/extract these files into a web project or static hosting service.
2. Serve over HTTPS to enable PWA installation/service worker.
3. Open the published HTTPS URL in Android Chrome and choose "Add to Home screen"
   or "Install app" if offered.

To produce a native Android APK, the web app must be packaged and built with an
Android wrapper/build tool. This ZIP alone cannot be installed as an APK.
