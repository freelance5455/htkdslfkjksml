import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  Heart,
  Bookmark,
  Share2,
  Flag,
  Trash2,
  Send,
  Calendar,
  Tag,
  Clock,
  AlertTriangle,
  Maximize2
} from 'lucide-react';
import { supabase, uploadVoiceComment } from '../supabase';
import { useAuth } from '../context/AuthContext';
import VoiceRecorder from '../components/VoiceRecorder';
import LightboxModal from '../components/LightboxModal';

export default function ArtworkDetailPage() {
  const { id } = useParams();
  const { user, isAdmin } = useAuth();
  const navigate = useNavigate();

  const [artwork, setArtwork] = useState(null);
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [isLiked, setIsLiked] = useState(false);
  const [isFavorited, setIsFavorited] = useState(false);
  const [showReportBox, setShowReportBox] = useState(false);
  const [reportReason, setReportReason] = useState('');
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [submittingComment, setSubmittingComment] = useState(false);

  useEffect(() => {
    loadArtworkDetails();
  }, [id, user]);

  const loadArtworkDetails = async () => {
    setLoading(true);
    try {
      const { data: artData, error } = await supabase
        .from('artworks')
        .select('*')
        .eq('id', id)
        .maybeSingle();

      if (error || !artData) {
        setArtwork(null);
        return;
      }
      setArtwork(artData);

      // جلب التعليقات مع بيانات المعلقين
      const { data: commentsData } = await supabase
        .from('comments')
        .select('*, profiles:user_id(artist_name, full_name, avatar_url)')
        .eq('artwork_id', id)
        .order('created_at', { ascending: true });

      setComments(commentsData || []);

      if (user) {
        const [{ data: likeRow }, { data: favRow }] = await Promise.all([
          supabase.from('likes').select('id').eq('artwork_id', id).eq('user_id', user.id).maybeSingle(),
          supabase.from('favorites').select('id').eq('artwork_id', id).eq('user_id', user.id).maybeSingle()
        ]);
        setIsLiked(Boolean(likeRow));
        setIsFavorited(Boolean(favRow));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleToggleLike = async () => {
    if (!user) return alert('يرجى تسجيل الدخول أولاً');
    if (isLiked) {
      await supabase.from('likes').delete().eq('artwork_id', id).eq('user_id', user.id);
      setIsLiked(false);
      setArtwork((prev) => ({ ...prev, likes_count: Math.max((prev.likes_count || 1) - 1, 0) }));
    } else {
      const { error } = await supabase.from('likes').insert({ artwork_id: id, user_id: user.id });
      if (!error) {
        setIsLiked(true);
        setArtwork((prev) => ({ ...prev, likes_count: (prev.likes_count || 0) + 1 }));
        if (artwork.user_id !== user.id) {
          await supabase.from('notifications').insert({
            user_id: artwork.user_id,
            actor_id: user.id,
            type: 'like',
            title: 'إعجاب جديد',
            message: `أُعجب مستخدم بلوحتك "${artwork.title}"`,
            link: `/artwork/${id}`
          });
        }
      }
    }
  };

  const handleToggleFavorite = async () => {
    if (!user) return alert('يرجى تسجيل الدخول أولاً');
    if (isFavorited) {
      await supabase.from('favorites').delete().eq('artwork_id', id).eq('user_id', user.id);
      setIsFavorited(false);
    } else {
      await supabase.from('favorites').insert({ artwork_id: id, user_id: user.id });
      setIsFavorited(true);
    }
  };

  const handleAddTextComment = async (e) => {
    e.preventDefault();
    if (!user) return alert('يرجى تسجيل الدخول للتعليق');
    if (!newComment.trim() || submittingComment) return;

    setSubmittingComment(true);
    try {
      const { error } = await supabase.from('comments').insert({
        artwork_id: id,
        user_id: user.id,
        content: newComment.trim()
      });

      if (error) throw error;

      if (artwork.user_id !== user.id) {
        await supabase.from('notifications').insert({
          user_id: artwork.user_id,
          actor_id: user.id,
          type: 'comment',
          title: 'تعليق جديد على لوحتك',
          message: `علّق أحد المتابعين على "${artwork.title}"`,
          link: `/artwork/${id}`
        });
      }

      setNewComment('');
      loadArtworkDetails();
    } catch (err) {
      alert(err.message);
    } finally {
      setSubmittingComment(false);
    }
  };

  const handleSendVoiceComment = async (blob, duration) => {
    if (!user) return alert('يرجى تسجيل الدخول لإرسال تعليق صوتي');
    const audioUrl = await uploadVoiceComment(blob, user.id);
    const { error } = await supabase.from('comments').insert({
      artwork_id: id,
      user_id: user.id,
      audio_url: audioUrl,
      audio_duration: duration
    });
    if (error) throw error;

    if (artwork.user_id !== user.id) {
      await supabase.from('notifications').insert({
        user_id: artwork.user_id,
        actor_id: user.id,
        type: 'comment',
        title: 'تعليق صوتي جديد',
        message: `أرسل مستخدم تعليقاً صوتياً على "${artwork.title}"`,
        link: `/artwork/${id}`
      });
    }
    loadArtworkDetails();
  };

  const handleDeleteArtwork = async () => {
    if (!window.confirm('هل أنت متأكد من حذف هذا العمل الفني نهائياً؟')) return;
    const { error } = await supabase.from('artworks').delete().eq('id', id);
    if (!error) {
      navigate('/explore');
    } else {
      alert('تعذر حذف العمل: ' + error.message);
    }
  };

  const handleSubmitReport = async (e) => {
    e.preventDefault();
    if (!user) return alert('يرجى تسجيل الدخول لإرسال بلاغ');
    if (!reportReason.trim()) return;

    const { error } = await supabase.from('reports').insert({
      reporter_id: user.id,
      artwork_id: id,
      reason: reportReason.trim()
    });

    if (!error) {
      alert('تم استلام بلاغك بنجاح وستتم مراجعته من قِبل إدارة المنصة.');
      setShowReportBox(false);
      setReportReason('');
    }
  };

  if (loading) {
    return <div className="container page-wrapper text-center">جاري تحميل تفاصيل العمل الفني...</div>;
  }

  if (!artwork) {
    return (
      <div className="container page-wrapper empty-state-box">
        <h2>العمل الفني غير موجود أو قيد المراجعة</h2>
        <p className="text-muted">لا تظهر الأعمال المعلقة للعامة إلا بعد اعتمادها من إدارة الرسيم السوداني.</p>
        <Link to="/explore" className="btn btn-gold mt-3">العودة للمعرض</Link>
      </div>
    );
  }

  const canDelete = user && (user.id === artwork.user_id || isAdmin);

  return (
    <div className="container page-wrapper">
      {artwork.status !== 'approved' && (
        <div className="alert-banner warning mb-4">
          <Clock size={18} />
          <span>
            حالة هذا العمل: <strong>{artwork.status === 'pending' ? 'قيد المراجعة الإدارية (غير مرئي للعامة)' : 'مرفوض'}</strong>
            {artwork.rejection_reason ? ` — السبب: ${artwork.rejection_reason}` : ''}
          </span>
        </div>
      )}

      <div className="artwork-detail-layout">
        {/* عرض اللوحة */}
        <div className="artwork-stage">
          <img src={artwork.image_url} alt={artwork.title} onClick={() => setLightboxOpen(true)} />
          <button
            type="button"
            className="btn btn-dark-glass expand-btn"
            onClick={() => setLightboxOpen(true)}
          >
            <Maximize2 size={16} />
            <span>عرض بالحجم الكامل</span>
          </button>
        </div>

        {/* تفاصيل اللوحة والتفاعل */}
        <div className="artwork-sidebar">
          <div className="detail-card">
            <span className="art-category-pill">
              <Tag size={14} /> {artwork.category || 'رسم تشكيلي'}
            </span>
            <h1 className="detail-title">{artwork.title}</h1>

            <Link to={`/artist/${artwork.user_id}`} className="artist-box-link">
              <div className="avatar-md avatar-fallback">{(artwork.artist_name || 'ف')[0]}</div>
              <div>
                <span className="text-xs text-muted">الفنان</span>
                <h4>{artwork.artist_name || 'فنان سوداني'}</h4>
              </div>
            </Link>

            <p className="detail-description">
              {artwork.description || 'عمل تشكيلي أصيل يعبّر عن الرؤية الفنية لصاحبه.'}
            </p>

            <div className="detail-date">
              <Calendar size={15} />
              <span>تاريخ النشر: {new Date(artwork.created_at).toLocaleDateString('ar-SD')}</span>
            </div>

            <div className="detail-actions-bar">
              <button
                type="button"
                className={`btn ${isLiked ? 'btn-gold' : 'btn-outline'}`}
                onClick={handleToggleLike}
              >
                <Heart size={18} fill={isLiked ? 'currentColor' : 'none'} />
                <span>إعجاب ({artwork.likes_count || 0})</span>
              </button>

              <button
                type="button"
                className={`btn ${isFavorited ? 'btn-gold' : 'btn-outline'}`}
                onClick={handleToggleFavorite}
              >
                <Bookmark size={18} fill={isFavorited ? 'currentColor' : 'none'} />
                <span>{isFavorited ? 'محفوظة' : 'مفضلة'}</span>
              </button>

              <button
                type="button"
                className="icon-btn"
                onClick={() => {
                  navigator.clipboard?.writeText(window.location.href);
                  alert('تم نسخ رابط العمل الفني');
                }}
                title="مشاركة الرابط"
              >
                <Share2 size={18} />
              </button>

              {user && user.id !== artwork.user_id && (
                <button
                  type="button"
                  className="icon-btn"
                  onClick={() => setShowReportBox(!showReportBox)}
                  title="إبلاغ عن مخالفة"
                >
                  <Flag size={18} />
                </button>
              )}

              {canDelete && (
                <button type="button" className="icon-btn danger-text" onClick={handleDeleteArtwork} title="حذف العمل">
                  <Trash2 size={18} />
                </button>
              )}
            </div>

            {showReportBox && (
              <form onSubmit={handleSubmitReport} className="report-form mt-3">
                <label className="text-sm flex-center gap-1">
                  <AlertTriangle size={15} className="gold-text" /> الإبلاغ عن محتوى مخالف
                </label>
                <input
                  type="text"
                  required
                  value={reportReason}
                  onChange={(e) => setReportReason(e.target.value)}
                  placeholder="اذكر سبب البلاغ (انتهاك حقوق ملكية، محتوى غير لائق...)"
                />
                <button type="submit" className="btn btn-danger btn-sm">إرسال البلاغ</button>
              </form>
            )}
          </div>

          {/* قسم التعليقات النصية والصوتية */}
          <div className="detail-card mt-4">
            <h3>التعليقات والانطباعات ({comments.length})</h3>

            {user ? (
              <div className="comment-composer">
                <form onSubmit={handleAddTextComment} className="text-comment-form">
                  <input
                    type="text"
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="اكتب نقداً فنياً أو كلمة تشجيع للفنان..."
                  />
                  <button type="submit" className="btn btn-gold btn-sm" disabled={submittingComment}>
                    <Send size={16} />
                  </button>
                </form>

                <VoiceRecorder onSendVoice={handleSendVoiceComment} disabled={submittingComment} />
              </div>
            ) : (
              <p className="text-sm text-muted mb-3">
                <Link to="/auth" className="gold-text">سجّل الدخول</Link> لإضافة تعليق نصي أو صوتي.
              </p>
            )}

            <div className="comments-list">
              {comments.length === 0 ? (
                <p className="text-muted text-sm">لا توجد تعليقات بعد. كن أول من يعلّق على هذه اللوحة!</p>
              ) : (
                comments.map((c) => {
                  const commenterName =
                    c.profiles?.artist_name || c.profiles?.full_name || 'مستخدم';
                  return (
                    <div key={c.id} className="comment-item">
                      <div className="comment-header">
                        <Link to={`/artist/${c.user_id}`} className="comment-author">
                          {commenterName}
                        </Link>
                        <span className="text-xs text-muted">
                          {new Date(c.created_at).toLocaleDateString('ar-SD')}
                        </span>
                      </div>
                      {c.content && <p className="comment-text">{c.content}</p>}
                      {c.audio_url && (
                        <div className="comment-audio-wrap">
                          <audio controls src={c.audio_url} />
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>

      {lightboxOpen && <LightboxModal artwork={artwork} onClose={() => setLightboxOpen(false)} />}
    </div>
  );
}
