import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { UserPlus, UserCheck, Edit3, Camera, MapPin, Palette, Save, X } from 'lucide-react';
import { supabase, uploadArtworkFile } from '../supabase';
import { useAuth } from '../context/AuthContext';
import ArtworkCard from '../components/ArtworkCard';
import LightboxModal from '../components/LightboxModal';

export default function ArtistProfilePage() {
  const { id } = useParams();
  const { user, refreshProfile } = useAuth();

  const [artist, setArtist] = useState(null);
  const [artworks, setArtworks] = useState([]);
  const [followersCount, setFollowersCount] = useState(0);
  const [followingCount, setFollowingCount] = useState(0);
  const [isFollowing, setIsFollowing] = useState(false);
  const [editing, setEditing] = useState(false);
  const [lightboxArt, setLightboxArt] = useState(null);
  const [loading, setLoading] = useState(true);

  // حقول تعديل الحساب
  const [editArtistName, setEditArtistName] = useState('');
  const [editBio, setEditBio] = useState('');
  const [editCity, setEditCity] = useState('');
  const [editSpecialty, setEditSpecialty] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);

  const isOwnProfile = user && user.id === id;

  useEffect(() => {
    loadArtistProfile();
  }, [id, user]);

  const loadArtistProfile = async () => {
    setLoading(true);
    try {
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', id)
        .maybeSingle();

      setArtist(profileData);
      if (profileData) {
        setEditArtistName(profileData.artist_name || profileData.full_name || '');
        setEditBio(profileData.bio || '');
        setEditCity(profileData.city || '');
        setEditSpecialty(profileData.specialty || '');
      }

      // جلب أعمال الفنان (لصاحب الحساب تظهر كل أعماله بما فيها المعلقة، وللزوار المعتمدة فقط)
      let artQuery = supabase
        .from('artworks')
        .select('*')
        .eq('user_id', id)
        .order('created_at', { ascending: false });

      if (!isOwnProfile) {
        artQuery = artQuery.eq('status', 'approved');
      }

      const { data: artList } = await artQuery;
      setArtworks(artList || []);

      // إحصائيات المتابعة
      const [{ count: followers }, { count: following }] = await Promise.all([
        supabase.from('follows').select('*', { count: 'exact', head: true }).eq('following_id', id),
        supabase.from('follows').select('*', { count: 'exact', head: true }).eq('follower_id', id)
      ]);
      setFollowersCount(followers || 0);
      setFollowingCount(following || 0);

      if (user && !isOwnProfile) {
        const { data: followRow } = await supabase
          .from('follows')
          .select('id')
          .eq('follower_id', user.id)
          .eq('following_id', id)
          .maybeSingle();
        setIsFollowing(Boolean(followRow));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleToggleFollow = async () => {
    if (!user) return alert('يرجى تسجيل الدخول لمتابعة الفنانين');
    if (isFollowing) {
      await supabase.from('follows').delete().eq('follower_id', user.id).eq('following_id', id);
      setIsFollowing(false);
      setFollowersCount((c) => Math.max(c - 1, 0));
    } else {
      const { error } = await supabase.from('follows').insert({ follower_id: user.id, following_id: id });
      if (!error) {
        setIsFollowing(true);
        setFollowersCount((c) => c + 1);
        await supabase.from('notifications').insert({
          user_id: id,
          actor_id: user.id,
          type: 'follow',
          title: 'متابع جديد',
          message: 'بدأ أحد الزوار بمتابعة ملفك الفني',
          link: `/artist/${user.id}`
        });
      }
    }
  };

  const handleAvatarUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file || !isOwnProfile) return;
    try {
      const avatarUrl = await uploadArtworkFile(file, user.id, 'avatars');
      await supabase.from('profiles').update({ avatar_url: avatarUrl }).eq('id', user.id);
      setArtist((prev) => ({ ...prev, avatar_url: avatarUrl }));
      await refreshProfile();
    } catch (err) {
      alert(err.message);
    }
  };

  const handleSaveProfile = async (e) => {
    e.preventDefault();
    if (!isOwnProfile) return;
    setSavingProfile(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          artist_name: editArtistName.trim(),
          full_name: editArtistName.trim(),
          bio: editBio.trim(),
          city: editCity.trim(),
          specialty: editSpecialty.trim(),
          updated_at: new Date().toISOString()
        })
        .eq('id', user.id);

      if (error) throw error;
      setEditing(false);
      await loadArtistProfile();
      await refreshProfile();
    } catch (err) {
      alert(err.message);
    } finally {
      setSavingProfile(false);
    }
  };

  if (loading) return <div className="container page-wrapper text-center">جاري تحميل ملف الفنان...</div>;

  if (!artist) {
    return (
      <div className="container page-wrapper empty-state-box">
        <h2>لم يتم العثور على ملف الفنان</h2>
        <Link to="/artists" className="btn btn-gold mt-3">تصفح الفنانين</Link>
      </div>
    );
  }

  return (
    <div className="container page-wrapper">
      {/* رأس الملف الشخصي */}
      <div className="profile-header-card">
        <div className="profile-avatar-section">
          {artist.avatar_url ? (
            <img src={artist.avatar_url} alt={artist.artist_name} className="profile-avatar-xl" />
          ) : (
            <div className="profile-avatar-xl avatar-fallback">
              {(artist.artist_name || 'ف')[0]}
            </div>
          )}

          {isOwnProfile && (
            <label className="avatar-upload-badge" title="تغيير الصورة الشخصية">
              <Camera size={16} />
              <input type="file" accept="image/*" hidden onChange={handleAvatarUpload} />
            </label>
          )}
        </div>

        <div className="profile-info-section">
          {!editing ? (
            <>
              <div className="profile-top-row">
                <div>
                  <h1>{artist.artist_name || artist.full_name}</h1>
                  <div className="profile-badges">
                    <span><Palette size={15} /> {artist.specialty || 'فنان تشكيلي'}</span>
                    {artist.city && <span><MapPin size={15} /> {artist.city}</span>}
                  </div>
                </div>

                {isOwnProfile ? (
                  <button type="button" className="btn btn-outline btn-sm" onClick={() => setEditing(true)}>
                    <Edit3 size={16} />
                    <span>تعديل الملف الشخصي</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    className={`btn ${isFollowing ? 'btn-outline' : 'btn-gold'}`}
                    onClick={handleToggleFollow}
                  >
                    {isFollowing ? <UserCheck size={18} /> : <UserPlus size={18} />}
                    <span>{isFollowing ? 'متابَع' : 'متابعة الفنان'}</span>
                  </button>
                )}
              </div>

              <p className="profile-bio">
                {artist.bio || 'فنان تشكيلي سوداني يشارك أعماله وإبداعاته على منصة الرسيم السوداني.'}
              </p>

              <div className="profile-stats-bar">
                <div><strong>{artworks.length}</strong> <span>عمل فني</span></div>
                <div><strong>{followersCount}</strong> <span>متابِع</span></div>
                <div><strong>{followingCount}</strong> <span>يتابِع</span></div>
              </div>
            </>
          ) : (
            <form onSubmit={handleSaveProfile} className="profile-edit-form">
              <div className="form-row-2">
                <div className="form-group">
                  <label>الاسم الفني</label>
                  <input
                    type="text"
                    required
                    value={editArtistName}
                    onChange={(e) => setEditArtistName(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label>التخصص الفني</label>
                  <input
                    type="text"
                    value={editSpecialty}
                    onChange={(e) => setEditSpecialty(e.target.value)}
                    placeholder="مثال: رسم تشكيلي، بورتريه، رسم رقمي"
                  />
                </div>
              </div>
              <div className="form-group">
                <label>المدينة / الولاية</label>
                <input
                  type="text"
                  value={editCity}
                  onChange={(e) => setEditCity(e.target.value)}
                  placeholder="الخرطوم، أم درمان، بورتسودان، ود مدني..."
                />
              </div>
              <div className="form-group">
                <label>النبذة التعريفية</label>
                <textarea
                  rows="3"
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  placeholder="اكتب نبذة عن مسيرتك الفنية وأسلوبك..."
                />
              </div>
              <div className="flex-center gap-2">
                <button type="submit" className="btn btn-gold btn-sm" disabled={savingProfile}>
                  <Save size={16} />
                  <span>{savingProfile ? 'جاري الحفظ...' : 'حفظ التعديلات'}</span>
                </button>
                <button type="button" className="btn btn-outline btn-sm" onClick={() => setEditing(false)}>
                  <X size={16} />
                  <span>إلغاء</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>

      {/* معرض أعمال الفنان */}
      <div className="section mt-4">
        <div className="section-header">
          <h2>معرض أعمال {artist.artist_name || 'الفنان'}</h2>
          {isOwnProfile && (
            <Link to="/publish" className="btn btn-gold btn-sm">
              + إضافة عمل جديد
            </Link>
          )}
        </div>

        {artworks.length === 0 ? (
          <div className="empty-state-box">
            <p>لم يتم نشر أي أعمال فنية في هذا الملف بعد.</p>
          </div>
        ) : (
          <div className="artworks-grid">
            {artworks.map((art) => (
              <ArtworkCard key={art.id} artwork={art} onOpenLightbox={setLightboxArt} />
            ))}
          </div>
        )}
      </div>

      <LightboxModal artwork={lightboxArt} onClose={() => setLightboxArt(null)} />
    </div>
  );
}
