import React, { useEffect, useState } from 'react';
import { Bell, CheckCheck } from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase } from '../supabase';
import { useAuth } from '../context/AuthContext';

export default function NotificationsPage() {
  const { user, setUnreadNotifications } = useAuth();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) loadNotifications();
  }, [user]);

  const loadNotifications = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(50);

    setItems(data || []);
    setLoading(false);
  };

  const markAllRead = async () => {
    await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('user_id', user.id)
      .eq('is_read', false);

    setItems((prev) => prev.map((n) => ({ ...n, is_read: true })));
    setUnreadNotifications(0);
  };

  if (!user) return null;

  return (
    <div className="container page-wrapper max-w-2xl">
      <div className="section-header">
        <div className="flex-center gap-2">
          <Bell size={24} className="gold-text" />
          <h1>إشعارات التفاعل</h1>
        </div>
        {items.some((n) => !n.is_read) && (
          <button type="button" className="btn btn-outline btn-sm" onClick={markAllRead}>
            <CheckCheck size={16} />
            <span>تحديد الكل كمقروء</span>
          </button>
        )}
      </div>

      {loading ? (
        <p>جاري تحميل الإشعارات...</p>
      ) : items.length === 0 ? (
        <div className="empty-state-box">لا توجد إشعارات جديدة حالياً.</div>
      ) : (
        <div className="notifications-list">
          {items.map((n) => (
            <Link
              key={n.id}
              to={n.link || '/'}
              className={`notification-card ${n.is_read ? '' : 'unread'}`}
            >
              <div>
                <h4>{n.title}</h4>
                <p className="text-sm text-muted">{n.message}</p>
              </div>
              <span className="text-xs text-muted">
                {new Date(n.created_at).toLocaleDateString('ar-SD')}
              </span>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
