import React, { useEffect, useState } from 'react';
import {
  ShieldCheck,
  Users,
  Image as ImageIcon,
  Heart,
  MessageSquare,
  Check,
  X,
  Trash2,
  Trophy,
  Landmark,
  Flag,
  Award
} from 'lucide-react';
import { supabase } from '../../supabase';
import { useAuth } from '../../context/AuthContext';

export default function AdminDashboard() {
  const { user, isAdmin, loading: authLoading } = useAuth();
  const [activeTab, setActiveTab] = useState('pending');

  const [stats, setStats] = useState({ users: 0, artworks: 0, likes: 0, comments: 0 });
  const [pendingArtworks, setPendingArtworks] = useState([]);
  const [allArtworks, setAllArtworks] = useState([]);
  const [usersList, setUsersList] = useState([]);
  const [contests, setContests] = useState([]);
  const [contestEntries, setContestEntries] = useState([]);
  const [exhibitions, setExhibitions] = useState([]);
  const [reports, setReports] = useState([]);

  // نماذج إضافة مسابقة ومعرض
  const [contestForm, setContestForm] = useState({
    title: '',
    description: '',
    rules: '',
    prize_details: '',
    start_date: '',
    end_date: ''
  });
  const [exhibitionForm, setExhibitionForm] = useState({
    title: '',
    theme: '',
    description: '',
    curator_name: 'إدارة الرسيم السوداني'
  });

  useEffect(() => {
    if (isAdmin) {
      loadAdminData();
    }
  }, [isAdmin]);

  const loadAdminData = async () => {
    // إحصائيات حقيقية من قاعدة البيانات
    const [
      { count: usersCount },
      { count: artworksCount },
      { count: likesCount },
      { count: commentsCount }
    ] = await Promise.all([
      supabase.from('profiles').select('*', { count: 'exact', head: true }),
      supabase.from('artworks').select('*', { count: 'exact', head: true }),
      supabase.from('likes').select('*', { count: 'exact', head: true }),
      supabase.from('comments').select('*', { count: 'exact', head: true })
    ]);

    setStats({
      users: usersCount || 0,
      artworks: artworksCount || 0,
      likes: likesCount || 0,
      comments: commentsCount || 0
    });

    // الأعمال المعلقة للمراجعة
    const { data: pending } = await supabase
      .from('artworks')
      .select('*')
      .eq('status', 'pending')
      .order('created_at', { ascending: true });
    setPendingArtworks(pending || []);

    // جميع الأعمال للتحكم في المحتوى
    const { data: allArts } = await supabase
      .from('artworks')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50);
    setAllArtworks(allArts || []);

    // المستخدمون
    const { data: profilesData } = await supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });
    setUsersList(profilesData || []);

    // المسابقات والمشاركات
    const { data: contestsData } = await supabase
      .from('contests')
      .select('*')
      .order('created_at', { ascending: false });
    setContests(contestsData || []);

    const { data: entriesData } = await supabase
      .from('contest_entries')
      .select('*, artworks(title, artist_name), contests(title)');
    setContestEntries(entriesData || []);

    // المعارض الافتراضية
    const { data: exData } = await supabase
      .from('exhibitions')
      .select('*')
      .order('created_at', { ascending: false });
    setExhibitions(exData || []);

    // البلاغات
    const { data: repData } = await supabase
      .from('reports')
      .select('*, artworks(title, image_url)')
      .order('created_at', { ascending: false });
    setReports(repData || []);
  };

  // قبول أو رفض عمل معلق
  const handleReviewArtwork = async (art, decision) => {
    let rejectionReason = null;
    if (decision === 'rejected') {
      rejectionReason = window.prompt('اذكر سبب رفض العمل الفني (سيظهر للفنان):') || 'غير مطابق لمعايير النشر';
    }

    const { error } = await supabase
      .from('artworks')
      .update({
        status: decision,
        rejection_reason: rejectionReason,
        updated_at: new Date().toISOString()
      })
      .eq('id', art.id);

    if (error) {
      alert('تعذر تنفيذ العملية (تحقق من صلاحيات المدير في RLS): ' + error.message);
      return;
    }

    // إرسال إشعار للفنان
    await supabase.from('notifications').insert({
      user_id: art.user_id,
      actor_id: user.id,
      type: decision === 'approved' ? 'artwork_approved' : 'artwork_rejected',
      title: decision === 'approved' ? 'تمت الموافقة على نشر لوحتك!' : 'ملاحظة بخصوص لوحتك المرفوعة',
      message:
        decision === 'approved'
          ? `لوحتك "${art.title}" أصبحت متاحة الآن للجمهور في معرض الرسيم السوداني.`
          : `تم رفض نشر "${art.title}". السبب: ${rejectionReason}`,
      link: `/artwork/${art.id}`
    });

    loadAdminData();
  };

  const handleDeleteArtwork = async (artId) => {
    if (!window.confirm('هل أنت متأكد من حذف هذا العمل المخالف نهائياً؟')) return;
    await supabase.from('artworks').delete().eq('id', artId);
    loadAdminData();
  };

  const handleToggleFeaturedArtist = async (profileItem) => {
    await supabase
      .from('profiles')
      .update({ is_featured: !profileItem.is_featured })
      .eq('id', profileItem.id);
    loadAdminData();
  };

  const handleCreateContest = async (e) => {
    e.preventDefault();
    const { error } = await supabase.from('contests').insert({
      ...contestForm,
      created_by: user.id,
      status: 'active'
    });
    if (error) return alert(error.message);
    setContestForm({ title: '', description: '', rules: '', prize_details: '', start_date: '', end_date: '' });
    loadAdminData();
  };

  const handleDeclareWinner = async (entry) => {
    const rankStr = window.prompt('أدخل مركز الفائز (1، 2، 3...):', '1');
    if (!rankStr) return;
    const certUrl = window.prompt('رابط شهادة التقدير أو الجائزة (اختياري):', '') || null;

    await supabase
      .from('contest_entries')
      .update({
        is_winner: true,
        winner_rank: parseInt(rankStr, 10) || 1,
        certificate_url: certUrl
      })
      .eq('id', entry.id);

    await supabase.from('notifications').insert({
      user_id: entry.user_id,
      actor_id: user.id,
      type: 'contest_win',
      title: 'تهانينا! فزت في مسابقة الرسيم السوداني',
      message: `حصل عملك "${entry.artworks?.title}" على المركز #${rankStr}`,
      link: '/contests'
    });

    loadAdminData();
  };

  const handleCreateExhibition = async (e) => {
    e.preventDefault();
    const { error } = await supabase.from('exhibitions').insert({
      ...exhibitionForm,
      is_active: true
    });
    if (error) return alert(error.message);
    setExhibitionForm({ title: '', theme: '', description: '', curator_name: 'إدارة الرسيم السوداني' });
    loadAdminData();
  };

  const handleAddArtworkToExhibition = async (artworkId) => {
    if (exhibitions.length === 0) return alert('أنشئ معرضاً افتراضياً أولاً من تبويب المعارض');
    const targetExId = exhibitions[0].id;
    const { error } = await supabase.from('exhibition_artworks').insert({
      exhibition_id: targetExId,
      artwork_id: artworkId
    });
    if (!error) alert(`تم تعليق اللوحة في معرض: ${exhibitions[0].title}`);
  };

  const handleResolveReport = async (reportId, status) => {
    await supabase.from('reports').update({ status }).eq('id', reportId);
    loadAdminData();
  };

  if (authLoading) {
    return <div className="container page-wrapper text-center">جاري التحقق من صلاحيات الإدارة...</div>;
  }

  // حراسة أمنية صارمة مدعومة بـ RLS في قاعدة البيانات
  if (!user || !isAdmin) {
    return (
      <div className="container page-wrapper empty-state-box">
        <ShieldCheck size={48} className="danger-text" />
        <h2>وصول غير مصرح به</h2>
        <p className="text-muted">هذه المنطقة مخصصة لإدارة منصة الرسيم السوداني فقط ومحمية بسياسات قاعدة البيانات.</p>
      </div>
    );
  }

  return (
    <div className="container page-wrapper">
      <div className="page-header">
        <div className="flex-center gap-2">
          <ShieldCheck size={28} className="gold-text" />
          <h1>لوحة تحكم المدير | Admin Dashboard</h1>
        </div>
        <p className="text-muted">إدارة المحتوى، مراجعة اللوحات المعلقة، المسابقات، والبلاغات</p>
      </div>

      {/* بطاقات الإحصائيات */}
      <div className="admin-stats-grid">
        <div className="stat-card">
          <Users size={24} className="gold-text" />
          <div>
            <span>المستخدمون</span>
            <h3>{stats.users}</h3>
          </div>
        </div>
        <div className="stat-card">
          <ImageIcon size={24} className="gold-text" />
          <div>
            <span>الأعمال الفنية</span>
            <h3>{stats.artworks}</h3>
          </div>
        </div>
        <div className="stat-card">
          <Heart size={24} className="gold-text" />
          <div>
            <span>الإعجابات</span>
            <h3>{stats.likes}</h3>
          </div>
        </div>
        <div className="stat-card">
          <MessageSquare size={24} className="gold-text" />
          <div>
            <span>التعليقات</span>
            <h3>{stats.comments}</h3>
          </div>
        </div>
      </div>

      {/* تبويبات الإدارة */}
      <div className="admin-tabs">
        <button className={activeTab === 'pending' ? 'active' : ''} onClick={() => setActiveTab('pending')}>
          الأعمال المعلقة ({pendingArtworks.length})
        </button>
        <button className={activeTab === 'artworks' ? 'active' : ''} onClick={() => setActiveTab('artworks')}>
          إدارة المحتوى ({allArtworks.length})
        </button>
        <button className={activeTab === 'users' ? 'active' : ''} onClick={() => setActiveTab('users')}>
          المستخدمون ({usersList.length})
        </button>
        <button className={activeTab === 'contests' ? 'active' : ''} onClick={() => setActiveTab('contests')}>
          المسابقات ({contests.length})
        </button>
        <button className={activeTab === 'exhibitions' ? 'active' : ''} onClick={() => setActiveTab('exhibitions')}>
          المعارض الافتراضية ({exhibitions.length})
        </button>
        <button className={activeTab === 'reports' ? 'active' : ''} onClick={() => setActiveTab('reports')}>
          البلاغات ({reports.filter((r) => r.status === 'open').length})
        </button>
      </div>

      {/* 1. مراجعة الأعمال المعلقة */}
      {activeTab === 'pending' && (
        <div className="admin-panel-box">
          <h3>أعمال تنتظر الموافقة للنشر ({pendingArtworks.length})</h3>
          {pendingArtworks.length === 0 ? (
            <p className="text-muted">لا توجد أعمال معلقة حالياً.</p>
          ) : (
            <div className="pending-review-grid">
              {pendingArtworks.map((art) => (
                <div key={art.id} className="review-card">
                  <img src={art.image_url} alt={art.title} />
                  <div className="review-card-body">
                    <h4>{art.title}</h4>
                    <p className="text-xs gold-text">الفنان: {art.artist_name} — {art.category}</p>
                    <p className="text-sm text-muted">{art.description}</p>
                    <div className="review-actions">
                      <button
                        type="button"
                        className="btn btn-gold btn-sm"
                        onClick={() => handleReviewArtwork(art, 'approved')}
                      >
                        <Check size={16} /> قبول ونشر
                      </button>
                      <button
                        type="button"
                        className="btn btn-danger btn-sm"
                        onClick={() => handleReviewArtwork(art, 'rejected')}
                      >
                        <X size={16} /> رفض
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 2. التحكم في جميع الأعمال */}
      {activeTab === 'artworks' && (
        <div className="admin-panel-box">
          <h3>جميع الأعمال الفنية المنشورة والمراجعة</h3>
          <div className="admin-table-wrap">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>العمل</th>
                  <th>الفنان</th>
                  <th>الحالة</th>
                  <th>الإعجابات</th>
                  <th>إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {allArtworks.map((art) => (
                  <tr key={art.id}>
                    <td className="flex-center gap-2">
                      <img src={art.image_url} alt="" className="table-thumb" />
                      <span>{art.title}</span>
                    </td>
                    <td>{art.artist_name}</td>
                    <td>{art.status}</td>
                    <td>{art.likes_count || 0}</td>
                    <td className="flex-center gap-2">
                      {art.status === 'approved' && (
                        <button
                          type="button"
                          className="btn btn-outline btn-sm"
                          onClick={() => handleAddArtworkToExhibition(art.id)}
                        >
                          + للمعرض الافتراضي
                        </button>
                      )}
                      <button
                        type="button"
                        className="icon-btn danger-text"
                        onClick={() => handleDeleteArtwork(art.id)}
                        title="حذف العمل"
                      >
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. إدارة المستخدمين */}
      {activeTab === 'users' && (
        <div className="admin-panel-box">
          <h3>إدارة الفنانين والمستخدمين</h3>
          <div className="admin-table-wrap">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>الاسم الفني</th>
                  <th>المدينة</th>
                  <th>التخصص</th>
                  <th>فنان مميز</th>
                </tr>
              </thead>
              <tbody>
                {usersList.map((u) => (
                  <tr key={u.id}>
                    <td>{u.artist_name || u.full_name}</td>
                    <td>{u.city || '-'}</td>
                    <td>{u.specialty || '-'}</td>
                    <td>
                      <button
                        type="button"
                        className={`btn btn-sm ${u.is_featured ? 'btn-gold' : 'btn-outline'}`}
                        onClick={() => handleToggleFeaturedArtist(u)}
                      >
                        <Award size={15} />
                        <span>{u.is_featured ? 'مميز حالياً' : 'تمييز الفنان'}</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4. إدارة المسابقات */}
      {activeTab === 'contests' && (
        <div className="admin-panel-box">
          <h3>إطلاق مسابقة فنية جديدة</h3>
          <form onSubmit={handleCreateContest} className="admin-subform mb-4">
            <div className="form-row-2">
              <input
                type="text"
                required
                placeholder="اسم المسابقة (مثال: جائزة النيل للفن التشكيلي)"
                value={contestForm.title}
                onChange={(e) => setContestForm({ ...contestForm, title: e.target.value })}
              />
              <input
                type="text"
                placeholder="الجوائز والشهادات"
                value={contestForm.prize_details}
                onChange={(e) => setContestForm({ ...contestForm, prize_details: e.target.value })}
              />
            </div>
            <textarea
              required
              rows="2"
              placeholder="وصف المسابقة"
              value={contestForm.description}
              onChange={(e) => setContestForm({ ...contestForm, description: e.target.value })}
            />
            <textarea
              rows="2"
              placeholder="شروط المشاركة"
              value={contestForm.rules}
              onChange={(e) => setContestForm({ ...contestForm, rules: e.target.value })}
            />
            <div className="form-row-2">
              <div>
                <label className="text-xs">تاريخ البداية</label>
                <input
                  type="date"
                  required
                  value={contestForm.start_date}
                  onChange={(e) => setContestForm({ ...contestForm, start_date: e.target.value })}
                />
              </div>
              <div>
                <label className="text-xs">تاريخ النهاية</label>
                <input
                  type="date"
                  required
                  value={contestForm.end_date}
                  onChange={(e) => setContestForm({ ...contestForm, end_date: e.target.value })}
                />
              </div>
            </div>
            <button type="submit" className="btn btn-gold btn-sm">
              <Trophy size={16} /> إنشاء المسابقة
            </button>
          </form>

          <h3>المشاركات المقدمة في المسابقات واختيار الفائزين</h3>
          {contestEntries.length === 0 ? (
            <p className="text-muted">لا توجد مشاركات بعد.</p>
          ) : (
            <div className="admin-table-wrap">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>المسابقة</th>
                    <th>اللوحة المشاركة</th>
                    <th>الفنان</th>
                    <th>النتيجة</th>
                  </tr>
                </thead>
                <tbody>
                  {contestEntries.map((entry) => (
                    <tr key={entry.id}>
                      <td>{entry.contests?.title}</td>
                      <td>{entry.artworks?.title}</td>
                      <td>{entry.artworks?.artist_name}</td>
                      <td>
                        {entry.is_winner ? (
                          <span className="gold-text">فائز بالمركز #{entry.winner_rank}</span>
                        ) : (
                          <button
                            type="button"
                            className="btn btn-gold btn-sm"
                            onClick={() => handleDeclareWinner(entry)}
                          >
                            اختيار كفائز وإصدار شهادة
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* 5. إدارة المعارض الافتراضية */}
      {activeTab === 'exhibitions' && (
        <div className="admin-panel-box">
          <h3>افتتاح معرض فني افتراضي جديد</h3>
          <form onSubmit={handleCreateExhibition} className="admin-subform mb-4">
            <div className="form-row-2">
              <input
                type="text"
                required
                placeholder="اسم المعرض الافتراضي"
                value={exhibitionForm.title}
                onChange={(e) => setExhibitionForm({ ...exhibitionForm, title: e.target.value })}
              />
              <input
                type="text"
                placeholder="ثيمة المعرض (مثال: ملامح من التراث النوبي)"
                value={exhibitionForm.theme}
                onChange={(e) => setExhibitionForm({ ...exhibitionForm, theme: e.target.value })}
              />
            </div>
            <textarea
              required
              rows="2"
              placeholder="وصف المعرض الافتراضي"
              value={exhibitionForm.description}
              onChange={(e) => setExhibitionForm({ ...exhibitionForm, description: e.target.value })}
            />
            <button type="submit" className="btn btn-gold btn-sm">
              <Landmark size={16} /> نشر المعرض الافتراضي
            </button>
          </form>

          <p className="text-xs text-muted">
            ملاحظة: لإضافة لوحات إلى المعرض الافتراضي، انتقل إلى تبويب "إدارة المحتوى" واضغط "+ للمعرض الافتراضي" بجانب أي عمل معتمد.
          </p>
        </div>
      )}

      {/* 6. مراجعة البلاغات */}
      {activeTab === 'reports' && (
        <div className="admin-panel-box">
          <h3>بلاغات المستخدمين ({reports.length})</h3>
          {reports.length === 0 ? (
            <p className="text-muted">لا توجد بلاغات مسجلة.</p>
          ) : (
            <div className="admin-table-wrap">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>العمل المُبلّغ عنه</th>
                    <th>سبب البلاغ</th>
                    <th>الحالة</th>
                    <th>الإجراء</th>
                  </tr>
                </thead>
                <tbody>
                  {reports.map((rep) => (
                    <tr key={rep.id}>
                      <td>{rep.artworks?.title || 'عمل محذوف'}</td>
                      <td>{rep.reason}</td>
                      <td>{rep.status}</td>
                      <td className="flex-center gap-2">
                        {rep.artwork_id && (
                          <button
                            type="button"
                            className="btn btn-danger btn-sm"
                            onClick={() => {
                              handleDeleteArtwork(rep.artwork_id);
                              handleResolveReport(rep.id, 'resolved');
                            }}
                          >
                            حذف العمل وإغلاق البلاغ
                          </button>
                        )}
                        <button
                          type="button"
                          className="btn btn-outline btn-sm"
                          onClick={() => handleResolveReport(rep.id, 'dismissed')}
                        >
                          تجاهل البلاغ
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
