import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { UploadCloud, Image as ImageIcon, CheckCircle2, Info } from 'lucide-react';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { Capacitor } from '@capacitor/core';
import { supabase, uploadArtworkFile } from '../supabase';
import { useAuth } from '../context/AuthContext';
import { ART_CATEGORIES } from '../i18n/translations';

export default function PublishArtworkPage() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();

  const [title, setTitle] = useState('');
  const [artistName, setArtistName] = useState('');
  const [category, setCategory] = useState('رسم تشكيلي');
  const [description, setDescription] = useState('');
  const [file, setFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState('');
  const [uploading, setUploading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }
    if (profile?.artist_name) {
      setArtistName(profile.artist_name);
    }
  }, [user, profile, navigate]);

  const handleFileChange = (e) => {
    const selected = e.target.files?.[0];
    if (!selected) return;
    setErrorMsg('');
    setFile(selected);
    setPreviewUrl(URL.createObjectURL(selected));
  };

  // دعم التقاط أو اختيار صورة على هواتف Android عبر Capacitor Camera
  const handleNativePhotoPick = async () => {
    try {
      const photo = await Camera.getPhoto({
        quality: 90,
        allowEditing: false,
        resultType: CameraResultType.Uri,
        source: CameraSource.Prompt
      });
      if (photo.webPath) {
        const response = await fetch(photo.webPath);
        const blob = await response.blob();
        const fileObj = new File([blob], `artwork_${Date.now()}.${photo.format || 'jpg'}`, {
          type: `image/${photo.format || 'jpeg'}`
        });
        setFile(fileObj);
        setPreviewUrl(photo.webPath);
      }
    } catch {
      // ألغى المستخدم الاختيار
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg('');

    if (!file) {
      setErrorMsg('يرجى اختيار صورة العمل الفني أولاً.');
      return;
    }
    if (!title.trim()) {
      setErrorMsg('يرجى كتابة عنوان العمل الفني.');
      return;
    }

    setUploading(true);
    try {
      // 1. رفع الصورة إلى حاوية artworks في Supabase Storage
      const publicImageUrl = await uploadArtworkFile(file, user.id, 'paintings');

      // 2. إدراج سجل العمل في جدول artworks بحالة pending إجبارية
      const { error: insertError } = await supabase.from('artworks').insert({
        user_id: user.id,
        title: title.trim(),
        artist_name: artistName.trim() || profile?.artist_name || 'فنان سوداني',
        category,
        description: description.trim(),
        image_url: publicImageUrl,
        status: 'pending'
      });

      if (insertError) throw insertError;

      setSubmitted(true);
    } catch (err) {
      setErrorMsg(err.message || 'حدث خطأ أثناء رفع العمل الفني.');
    } finally {
      setUploading(false);
    }
  };

  if (submitted) {
    return (
      <div className="container page-wrapper">
        <div className="success-box">
          <CheckCircle2 size={54} className="gold-text" />
          <h2>تم إرسال عملك الفني للمراجعة بنجاح!</h2>
          <p>
            عملك الآن في قائمة المراجعة الإدارية (<strong>Pending</strong>). سيظهر في المعرض العام فور موافقة إدارة منصة الرسيم السوداني، وسيصلك إشعار بذلك.
          </p>
          <div className="flex-center gap-3 mt-4">
            <button
              type="button"
              className="btn btn-gold"
              onClick={() => {
                setSubmitted(false);
                setTitle('');
                setDescription('');
                setFile(null);
                setPreviewUrl('');
              }}
            >
              رفع عمل آخر
            </button>
            <button type="button" className="btn btn-outline" onClick={() => navigate(`/artist/${user.id}`)}>
              الذهاب لملفي الشخصي
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container page-wrapper max-w-2xl">
      <div className="page-header">
        <h1>نشر عمل فني جديد</h1>
        <p className="text-muted">شارك لوحتك أو رسمتك الرقمية مع مجتمع الفن التشكيلي السوداني</p>
      </div>

      <div className="alert-banner info mb-4">
        <Info size={18} />
        <span>لضمان جودة المعرض، تخضع جميع الأعمال المرفوعة للمراجعة من قِبل الإدارة قبل نشرها للزوار.</span>
      </div>

      {errorMsg && <div className="alert-banner error mb-4">{errorMsg}</div>}

      <form onSubmit={handleSubmit} className="form-card">
        {/* منطقة رفع الصورة */}
        <div className="upload-dropzone">
          {previewUrl ? (
            <div className="upload-preview-wrap">
              <img src={previewUrl} alt="معاينة العمل" />
              <label className="btn btn-outline btn-sm mt-2">
                تغيير الصورة
                <input type="file" accept="image/jpeg,image/png,image/webp,image/gif" hidden onChange={handleFileChange} />
              </label>
            </div>
          ) : (
            <div className="upload-placeholder">
              <UploadCloud size={44} className="gold-text" />
              <p>اختر صورة اللوحة (JPG, PNG, WEBP — بحد أقصى 10MB)</p>
              <div className="flex-center gap-2 mt-2">
                <label className="btn btn-gold btn-sm">
                  <ImageIcon size={16} />
                  <span>اختيار من الجهاز</span>
                  <input type="file" accept="image/jpeg,image/png,image/webp,image/gif" hidden onChange={handleFileChange} />
                </label>
                {Capacitor.isNativePlatform() && (
                  <button type="button" className="btn btn-outline btn-sm" onClick={handleNativePhotoPick}>
                    التقاط بالكاميرا
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        <div className="form-group">
          <label>عنوان العمل الفني *</label>
          <input
            type="text"
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="مثال: شروق على ضفاف النيل الأزرق"
          />
        </div>

        <div className="form-row-2">
          <div className="form-group">
            <label>اسم الفنان *</label>
            <input
              type="text"
              required
              value={artistName}
              onChange={(e) => setArtistName(e.target.value)}
              placeholder="الاسم الفني الذي سيظهر أسفل اللوحة"
            />
          </div>

          <div className="form-group">
            <label>التصنيف الفني</label>
            <select value={category} onChange={(e) => setCategory(e.target.value)}>
              {ART_CATEGORIES.filter((c) => c.id !== 'all').map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.labelAr}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="form-group">
          <label>وصف العمل والخامات المستخدمة</label>
          <textarea
            rows="4"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="تحدث عن فكرة اللوحة، الألوان المستخدمة (زيت، أكريليك، رسم رقمي...)، وأبعادها..."
          />
        </div>

        <button type="submit" className="btn btn-gold w-full btn-lg" disabled={uploading}>
          {uploading ? 'جاري رفع اللوحة وحفظها...' : 'إرسال العمل الفني للمراجعة'}
        </button>
      </form>
    </div>
  );
}
