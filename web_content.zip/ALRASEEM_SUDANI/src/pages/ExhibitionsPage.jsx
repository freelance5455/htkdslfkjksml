import React, { useEffect, useState } from 'react';
import { Landmark, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase } from '../supabase';
import LightboxModal from '../components/LightboxModal';

export default function ExhibitionsPage() {
  const [exhibitions, setExhibitions] = useState([]);
  const [lightboxArt, setLightboxArt] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadExhibitions();
  }, []);

  const loadExhibitions = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('exhibitions')
      .select('*, exhibition_artworks(artworks(*))')
      .eq('is_active', true)
      .order('created_at', { ascending: false });
    setExhibitions(data || []);
    setLoading(false);
  };

  return (
    <div className="container page-wrapper">
      <div className="page-header">
        <div className="flex-center gap-2">
          <Landmark size={28} className="gold-text" />
          <h1>المعارض الفنية الافتراضية</h1>
        </div>
        <p className="text-muted">قاعات عرض رقمية منسّقة تحتفي بموضوعات ومدارس الفن التشكيلي السوداني</p>
      </div>

      {loading ? (
        <p>جاري تجهيز قاعات العرض...</p>
      ) : exhibitions.length === 0 ? (
        <div className="empty-state-box">
          <p>لا توجد معارض افتراضية مفتوحة حالياً.</p>
        </div>
      ) : (
        <div className="exhibitions-stack">
          {exhibitions.map((ex) => {
            const works = (ex.exhibition_artworks || [])
              .map((item) => item.artworks)
              .filter((a) => a && a.status === 'approved');

            return (
              <section key={ex.id} className="exhibition-hall">
                <div className="exhibition-hall-header">
                  <div>
                    <span className="hero-badge">
                      <Sparkles size={14} /> {ex.theme || 'معرض افتراضي خاص'}
                    </span>
                    <h2>{ex.title}</h2>
                    <p className="text-muted">{ex.description}</p>
                    <span className="text-xs gold-text">تنسيق المعرض: {ex.curator_name}</span>
                  </div>
                </div>

                {works.length === 0 ? (
                  <p className="text-sm text-muted">جاري تعليق اللوحات في هذه القاعة...</p>
                ) : (
                  <div className="virtual-wall-grid">
                    {works.map((art) => (
                      <div key={art.id} className="museum-frame" onClick={() => setLightboxArt(art)}>
                        <div className="museum-mat">
                          <img src={art.image_url} alt={art.title} />
                        </div>
                        <div className="museum-plaque">
                          <h4>{art.title}</h4>
                          <Link to={`/artist/${art.user_id}`} onClick={(e) => e.stopPropagation()}>
                            {art.artist_name || 'فنان سوداني'}
                          </Link>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </section>
            );
          })}
        </div>
      )}

      <LightboxModal artwork={lightboxArt} onClose={() => setLightboxArt(null)} />
    </div>
  );
}
