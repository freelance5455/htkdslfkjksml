import React, { useEffect, useState } from 'react';
import { Trophy, Calendar, Award, CheckCircle, Send } from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase } from '../supabase';
import { useAuth } from '../context/AuthContext';

export default function ContestsPage() {
  const { user } = useAuth();
  const [contests, setContests] = useState([]);
  const [myArtworks, setMyArtworks] = useState([]);
  const [entriesByContest, setEntriesByContest] = useState({});
  const [selectedArtworkId, setSelectedArtworkId] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadContests();
  }, [user]);

  const loadContests = async () => {
    setLoading(true);
    try {
      const { data: contestsData } = await supabase
        .from('contests')
        .select('*')
        .order('created_at', { ascending: false });

      setContests(contestsData || []);

      // جلب المشاركات والفائزين
      const { data: entriesData } = await supabase
        .from('contest_entries')
        .select('*, artworks(id, title, image_url, artist_name), profiles:user_id(artist_name, full_name)');

      const grouped = {};
      (entriesData || []).forEach((entry) => {
        if (!grouped[entry.contest_id]) grouped[entry.contest_id] = [];
        grouped[entry.contest_id].push(entry);
      });
      setEntriesByContest(grouped);

      if (user) {
        const { data: userArts } = await supabase
          .from('artworks')
          .select('id, title')
          .eq('user_id', user.id)
          .eq('status', 'approved');
        setMyArtworks(userArts || []);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleJoinContest = async (contestId) => {
    if (!user) return alert('يرجى تسجيل الدخول للمشاركة في المسابقة');
    const artworkId = selectedArtworkId[contestId];
    if (!artworkId) return alert('اختر إحدى لوحاتك المعتمدة للمشاركة بها');

    const { error } = await supabase.from('contest_entries').insert({
      contest_id: contestId,
      artwork_id: artworkId,
      user_id: user.id
    });

    if (error) {
      if (error.code === '23505') {
        alert('لقد شاركت بالفعل في هذه المسابقة.');
      } else {
        alert(error.message);
      }
    } else {
      alert('تم تسجيل مشاركتك في المسابقة بنجاح!');
      loadContests();
    }
  };

  return (
    <div className="container page-wrapper">
      <div className="page-header">
        <div className="flex-center gap-2">
          <Trophy size={28} className="gold-text" />
          <h1>المسابقات والجوائز الفنية</h1>
        </div>
        <p className="text-muted">نافس بأعمالك الفنية واحصل على جوائز وشهادات تقدير معتمدة من الرسيم السوداني</p>
      </div>

      {loading ? (
        <p>جاري تحميل المسابقات...</p>
      ) : contests.length === 0 ? (
        <div className="empty-state-box">
          <p>لا توجد مسابقات نشطة حالياً. ترقّب الإعلان عن المسابقة القادمة!</p>
        </div>
      ) : (
        <div className="contests-list">
          {contests.map((contest) => {
            const entries = entriesByContest[contest.id] || [];
            const winners = entries.filter((e) => e.is_winner);
            const userAlreadyEntered = user && entries.some((e) => e.user_id === user.id);

            return (
              <div key={contest.id} className="contest-card">
                <div className="contest-header">
                  <div>
                    <span className={`status-pill ${contest.status}`}>
                      {contest.status === 'active'
                        ? 'مفتوحة للمشاركة'
                        : contest.status === 'completed'
                        ? 'منتهية — أُعلنت النتائج'
                        : 'قيد التحكيم'}
                    </span>
                    <h2>{contest.title}</h2>
                  </div>
                  <div className="contest-dates">
                    <span>
                      <Calendar size={15} /> البداية: {new Date(contest.start_date).toLocaleDateString('ar-SD')}
                    </span>
                    <span>
                      <Calendar size={15} /> النهاية: {new Date(contest.end_date).toLocaleDateString('ar-SD')}
                    </span>
                  </div>
                </div>

                <p className="contest-desc">{contest.description}</p>

                {contest.rules && (
                  <div className="contest-rules">
                    <strong>شروط المشاركة:</strong>
                    <p>{contest.rules}</p>
                  </div>
                )}

                {contest.prize_details && (
                  <div className="contest-prize">
                    <Award size={18} className="gold-text" />
                    <span><strong>الجوائز والشهادات:</strong> {contest.prize_details}</span>
                  </div>
                )}

                {/* عرض الفائزين والشهادات */}
                {winners.length > 0 && (
                  <div className="winners-showcase">
                    <h3>الفائزون في المسابقة</h3>
                    <div className="winners-grid">
                      {winners.map((w) => (
                        <div key={w.id} className="winner-card">
                          <span className="winner-rank">المركز #{w.winner_rank || 1}</span>
                          {w.artworks?.image_url && (
                            <img src={w.artworks.image_url} alt={w.artworks.title} />
                          )}
                          <h4>{w.profiles?.artist_name || w.artworks?.artist_name || 'فنان فائز'}</h4>
                          <p className="text-xs text-muted">{w.artworks?.title}</p>
                          {w.certificate_url && (
                            <a
                              href={w.certificate_url}
                              target="_blank"
                              rel="noreferrer"
                              className="btn btn-gold btn-sm mt-2"
                            >
                              عرض شهادة التقدير
                            </a>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* نموذج تقديم مشاركة */}
                {contest.status === 'active' && (
                  <div className="contest-entry-box">
                    {!user ? (
                      <Link to="/auth" className="btn btn-outline btn-sm">
                        سجّل الدخول للمشاركة في المسابقة
                      </Link>
                    ) : userAlreadyEntered ? (
                      <div className="text-sm gold-text flex-center gap-1">
                        <CheckCircle size={16} /> تم تسجيل مشاركتك في هذه المسابقة ({entries.length} مشارك)
                      </div>
                    ) : myArtworks.length === 0 ? (
                      <p className="text-sm text-muted">
                        تحتاج إلى عمل فني معتمد واحد على الأقل للمشاركة.{' '}
                        <Link to="/publish" className="gold-text">ارفع عملك الآن</Link>
                      </p>
                    ) : (
                      <div className="entry-submit-row">
                        <select
                          value={selectedArtworkId[contest.id] || ''}
                          onChange={(e) =>
                            setSelectedArtworkId({ ...selectedArtworkId, [contest.id]: e.target.value })
                          }
                        >
                          <option value="">-- اختر لوحتك المعتمدة للمشاركة --</option>
                          {myArtworks.map((art) => (
                            <option key={art.id} value={art.id}>
                              {art.title}
                            </option>
                          ))}
                        </select>
                        <button
                          type="button"
                          className="btn btn-gold btn-sm"
                          onClick={() => handleJoinContest(contest.id)}
                        >
                          <Send size={15} />
                          <span>إرسال المشاركة</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
