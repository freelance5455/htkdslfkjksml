import React, { useEffect, useState } from 'react';
import { Heart } from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase } from '../supabase';
import { useAuth } from '../context/AuthContext';
import ArtworkCard from '../components/ArtworkCard';
import LightboxModal from '../components/LightboxModal';

export default function FavoritesPage() {
  const { user } = useAuth();
  const [favorites, setFavorites] = useState([]);
  const [lightboxArt, setLightboxArt] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) loadFavorites();
  }, [user]);

  const loadFavorites = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('favorites')
      .select('artwork_id, artworks(*)')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    const validArts = (data || []).map((row) => row.artworks).filter(Boolean);
    setFavorites(validArts);
    setLoading(false);
  };

  if (!user) {
    return (
      <div className="container page-wrapper empty-state-box">
        <p>يرجى تسجيل الدخول لعرض قائمة المفضلة الخاصة بك.</p>
        <Link to="/auth" className="btn btn-gold mt-3">تسجيل الدخول</Link>
      </div>
    );
  }

  return (
    <div className="container page-wrapper">
      <div className="page-header">
        <div className="flex-center gap-2">
          <Heart size={26} className="gold-text" />
          <h1>لوحاتي المفضلة</h1>
        </div>
        <p className="text-muted">الأعمال الفنية التي قمت بحفظها للرجوع إليها لاحقاً</p>
      </div>

      {loading ? (
        <p>جاري التحميل...</p>
      ) : favorites.length === 0 ? (
        <div className="empty-state-box">
          <p>قائمة المفضلة فارغة حالياً.</p>
          <Link to="/explore" className="btn btn-gold mt-3">استكشف المعرض</Link>
        </div>
      ) : (
        <div className="artworks-grid">
          {favorites.map((art) => (
            <ArtworkCard
              key={art.id}
              artwork={art}
              isFavorited={true}
              onToggleFavorite={(id, fav) => {
                if (!fav) setFavorites((list) => list.filter((item) => item.id !== id));
              }}
              onOpenLightbox={setLightboxArt}
            />
          ))}
        </div>
      )}

      <LightboxModal artwork={lightboxArt} onClose={() => setLightboxArt(null)} />
    </div>
  );
}
