import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '../supabase';
import { translations } from '../i18n/translations';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [lang, setLang] = useState(() => localStorage.getItem('alraseem_lang') || 'ar');
  const [unreadNotifications, setUnreadNotifications] = useState(0);

  const t = translations[lang] || translations.ar;

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    localStorage.setItem('alraseem_lang', lang);
  }, [lang]);

  const toggleLanguage = () => {
    setLang((prev) => (prev === 'ar' ? 'en' : 'ar'));
  };

  const fetchUserMetadata = async (currentUser) => {
    if (!currentUser) {
      setProfile(null);
      setIsAdmin(false);
      setUnreadNotifications(0);
      return;
    }

    try {
      // 1. جلب الملف الشخصي
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', currentUser.id)
        .maybeSingle();

      if (profileData) {
        setProfile(profileData);
      } else {
        // إنشاء سجل ملف شخصي في حال لم يكن موجوداً لحساب قديم
        const fallbackName =
          currentUser.user_metadata?.artist_name ||
          currentUser.user_metadata?.full_name ||
          currentUser.email?.split('@')[0] ||
          'فنان سوداني';
        const { data: createdProfile } = await supabase
          .from('profiles')
          .upsert({
            id: currentUser.id,
            full_name: fallbackName,
            artist_name: fallbackName
          })
          .select()
          .maybeSingle();
        setProfile(createdProfile || { id: currentUser.id, artist_name: fallbackName });
      }

      // 2. التحقق الفعلي من صلاحية المدير من جدول admin_users المحمي بـ RLS
      const { data: adminRecord } = await supabase
        .from('admin_users')
        .select('user_id, role')
        .eq('user_id', currentUser.id)
        .maybeSingle();

      setIsAdmin(Boolean(adminRecord));

      // 3. عدد الإشعارات غير المقروءة
      const { count } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', currentUser.id)
        .eq('is_read', false);

      setUnreadNotifications(count || 0);
    } catch (err) {
      console.error('خطأ في تحميل بيانات المستخدم:', err);
    }
  };

  useEffect(() => {
    let mounted = true;

    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!mounted) return;
      const sessionUser = session?.user || null;
      setUser(sessionUser);
      fetchUserMetadata(sessionUser).finally(() => {
        if (mounted) setLoading(false);
      });
    });

    const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
      const sessionUser = session?.user || null;
      setUser(sessionUser);
      fetchUserMetadata(sessionUser);
    });

    return () => {
      mounted = false;
      authListener?.subscription?.unsubscribe();
    };
  }, []);

  const refreshProfile = async () => {
    if (user) {
      await fetchUserMetadata(user);
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setProfile(null);
    setIsAdmin(false);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        isAdmin,
        loading,
        lang,
        t,
        toggleLanguage,
        unreadNotifications,
        setUnreadNotifications,
        refreshProfile,
        signOut
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
