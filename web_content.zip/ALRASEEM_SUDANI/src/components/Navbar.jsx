import React, { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import {
  Palette,
  PlusCircle,
  Bell,
  Heart,
  User,
  ShieldCheck,
  LogOut,
  LogIn,
  Menu,
  X,
  Globe,
  Trophy,
  Landmark,
  Users,
  Compass
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import Logo from './Logo';

export default function Navbar() {
  const { user, profile, isAdmin, t, lang, toggleLanguage, unreadNotifications, signOut } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = async () => {
    await signOut();
    setMobileMenuOpen(false);
    navigate('/');
  };

  return (
    <header className="navbar">
      <div className="container navbar-inner">
        <Link to="/" className="navbar-brand" onClick={() => setMobileMenuOpen(false)}>
          <Logo size="md" />
        </Link>

        {/* روابط سطح المكتب */}
        <nav className="nav-links desktop-only">
          <NavLink to="/" end className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
            {t.navHome}
          </NavLink>
          <NavLink to="/explore" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
            <Compass size={16} />
            <span>{t.navExplore}</span>
          </NavLink>
          <NavLink to="/artists" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
            <Users size={16} />
            <span>{t.navArtists}</span>
          </NavLink>
          <NavLink to="/contests" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
            <Trophy size={16} />
            <span>{t.navContests}</span>
          </NavLink>
          <NavLink to="/exhibitions" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
            <Landmark size={16} />
            <span>{t.navExhibitions}</span>
          </NavLink>
          {isAdmin && (
            <NavLink to="/admin" className={({ isActive }) => `nav-link admin-link ${isActive ? 'active' : ''}`}>
              <ShieldCheck size={16} />
              <span>{t.navAdmin}</span>
            </NavLink>
          )}
        </nav>

        {/* أزرار الإجراءات */}
        <div className="nav-actions">
          <button
            type="button"
            onClick={toggleLanguage}
            className="icon-btn"
            title={lang === 'ar' ? 'Switch to English' : 'التبديل للعربية'}
          >
            <Globe size={18} />
            <span className="lang-code">{lang === 'ar' ? 'EN' : 'ع'}</span>
          </button>

          {user ? (
            <>
              <Link to="/publish" className="btn btn-gold btn-sm publish-cta">
                <PlusCircle size={17} />
                <span>{t.publishArt}</span>
              </Link>

              <Link to="/favorites" className="icon-btn desktop-only" title={t.navFavorites}>
                <Heart size={19} />
              </Link>

              <Link to="/notifications" className="icon-btn notif-btn" title="الإشعارات">
                <Bell size={19} />
                {unreadNotifications > 0 && (
                  <span className="notif-badge">{unreadNotifications > 9 ? '9+' : unreadNotifications}</span>
                )}
              </Link>

              <Link to={`/artist/${user.id}`} className="user-pill desktop-only">
                {profile?.avatar_url ? (
                  <img src={profile.avatar_url} alt={profile.artist_name} className="avatar-xs" />
                ) : (
                  <div className="avatar-xs avatar-fallback">
                    {(profile?.artist_name || 'ف')[0]}
                  </div>
                )}
                <span className="user-pill-name">{profile?.artist_name || 'حسابي'}</span>
              </Link>

              <button type="button" onClick={handleLogout} className="icon-btn desktop-only" title={t.logout}>
                <LogOut size={18} />
              </button>
            </>
          ) : (
            <div className="auth-btns desktop-only">
              <Link to="/auth" className="btn btn-outline btn-sm">
                <LogIn size={16} />
                <span>{t.login}</span>
              </Link>
              <Link to="/auth?mode=register" className="btn btn-gold btn-sm">
                <Palette size={16} />
                <span>{t.register}</span>
              </Link>
            </div>
          )}

          <button
            type="button"
            className="icon-btn mobile-menu-btn"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="القائمة"
          >
            {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* قائمة الهاتف / Android */}
      {mobileMenuOpen && (
        <div className="mobile-drawer">
          <div className="mobile-drawer-links">
            <NavLink to="/" end onClick={() => setMobileMenuOpen(false)}>
              {t.navHome}
            </NavLink>
            <NavLink to="/explore" onClick={() => setMobileMenuOpen(false)}>
              {t.navExplore}
            </NavLink>
            <NavLink to="/artists" onClick={() => setMobileMenuOpen(false)}>
              {t.navArtists}
            </NavLink>
            <NavLink to="/contests" onClick={() => setMobileMenuOpen(false)}>
              {t.navContests}
            </NavLink>
            <NavLink to="/exhibitions" onClick={() => setMobileMenuOpen(false)}>
              {t.navExhibitions}
            </NavLink>

            {user ? (
              <>
                <NavLink to="/publish" onClick={() => setMobileMenuOpen(false)} className="gold-text">
                  + {t.publishArt}
                </NavLink>
                <NavLink to={`/artist/${user.id}`} onClick={() => setMobileMenuOpen(false)}>
                  ملفي الفني ({profile?.artist_name || 'الفنان'})
                </NavLink>
                <NavLink to="/favorites" onClick={() => setMobileMenuOpen(false)}>
                  {t.navFavorites}
                </NavLink>
                <NavLink to="/notifications" onClick={() => setMobileMenuOpen(false)}>
                  الإشعارات ({unreadNotifications})
                </NavLink>
                {isAdmin && (
                  <NavLink to="/admin" onClick={() => setMobileMenuOpen(false)} className="admin-mobile-link">
                    لوحة تحكم المدير
                  </NavLink>
                )}
                <button type="button" onClick={handleLogout} className="btn btn-outline w-full mt-2">
                  <LogOut size={16} />
                  <span>{t.logout}</span>
                </button>
              </>
            ) : (
              <div className="mobile-auth-grid">
                <Link to="/auth" onClick={() => setMobileMenuOpen(false)} className="btn btn-outline">
                  {t.login}
                </Link>
                <Link to="/auth?mode=register" onClick={() => setMobileMenuOpen(false)} className="btn btn-gold">
                  {t.register}
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
