import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, Bookmark, Maximize2, MessageCircle, Share2, Clock, AlertCircle } from 'lucide-react';
import { Share } from '@capacitor/share';
import { Capacitor } from '@capacitor/core';
import { supabase } from '../supabase';
import { useAuth } from '../context/AuthContext';

export default function ArtworkCard({
  artwork,
  isLiked = false,
  isFavorited = false,
  onToggleLike,
  onToggleFavorite,
  onOpenLightbox
}) {
  const { user } = useAuth();
  const [busyLike, setBusyLike] = useState(false);
  const [busyFav, setBusyFav] = useState(false);

  const artistDisplay =
    artwork.artist_name ||
    artwork.profiles?.artist_name ||
    artwork.profiles?.full_name ||
    'فنان سوداني';

  const handleLikeClick = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!user) {
      alert('يرجى تسجيل الدخول للإعجاب بالأعمال الفنية');
      return;
    }
    if (busyLike) return;
    setBusyLike(true);
    try {
      if (isLiked) {
        await supabase.from('likes').delete().eq('artwork_id', artwork.id).eq('user_id', user.id);
      } else {
        const { error } = await supabase.from('likes').insert({
          artwork_id: artwork.id,
          user_id: user.id
        });
        if (!error && artwork.user_id !== user.id) {
          await supabase.from('notifications').insert({
            user_id: artwork.user_id,
            actor_id: user.id,
            type: 'like',
            title: 'إعجاب جديد بلوحتك',
            message: `أُعجب أحد الزوار بلوحتك "${artwork.title}"`,
            link: `/artwork/${artwork.id}`
          });
        }
      }
      if (onToggleLike) onToggleLike(artwork.id, !isLiked);
    } finally {
      setBusyLike(false);
    }
  };

  const handleFavoriteClick = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!user) {
      alert('يرجى تسجيل الدخول لحفظ اللوحات في المفضلة');
      return;
    }
    if (busyFav) return;
    setBusyFav(true);
    try {
      if (isFavorited) {
        await supabase.from('favorites').delete().eq('artwork_id', artwork.id).eq('user_id', user.id);
      } else {
        await supabase.from('favorites').insert({
          artwork_id: artwork.id,
          user_id: user.id
        });
      }
      if (onToggleFavorite) onToggleFavorite(artwork.id, !isFavorited);
    } finally {
      setBusyFav(false);
    }
  };

  const handleShare = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    const shareUrl = `${window.location.origin}/artwork/${artwork.id}`;
    try {
      if (Capacitor.isNativePlatform()) {
        await Share.share({
          title: artwork.title,
          text: `شاهد لوحة "${artwork.title}" للفنان ${artistDisplay} على منصة الرسيم السوداني`,
          url: shareUrl,
          dialogTitle: 'مشاركة العمل الفني'
        });
      } else if (navigator.share) {
        await navigator.share({
          title: artwork.title,
          text: `لوحة "${artwork.title}" - الرسيم السوداني`,
          url: shareUrl
        });
      } else {
        await navigator.clipboard.writeText(shareUrl);
        alert('تم نسخ رابط اللوحة للمشاركة');
      }
    } catch {
      // تجاهل إلغاء المشاركة
    }
  };

  return (
    <article className="art-card">
      <div className="art-card-media">
        <Link to={`/artwork/${artwork.id}`} className="art-img-link">
          <img src={artwork.image_url} alt={artwork.title} loading="lazy" />
        </Link>

        {artwork.status === 'pending' && (
          <span className="status-badge status-pending">
            <Clock size={13} /> قيد المراجعة
          </span>
        )}
        {artwork.status === 'rejected' && (
          <span className="status-badge status-rejected">
            <AlertCircle size={13} /> مرفوض
          </span>
        )}

        <div className="art-card-overlay">
          {onOpenLightbox && (
            <button
              type="button"
              className="overlay-icon-btn"
              onClick={() => onOpenLightbox(artwork)}
              title="تكبير اللوحة"
            >
              <Maximize2 size={18} />
            </button>
          )}
          <button
            type="button"
            className={`overlay-icon-btn ${isFavorited ? 'active-gold' : ''}`}
            onClick={handleFavoriteClick}
            title="حفظ في المفضلة"
          >
            <Bookmark size={18} fill={isFavorited ? 'currentColor' : 'none'} />
          </button>
          <button type="button" className="overlay-icon-btn" onClick={handleShare} title="مشاركة">
            <Share2 size={18} />
          </button>
        </div>

        <span className="art-category-tag">{artwork.category || 'رسم تشكيلي'}</span>
      </div>

      <div className="art-card-body">
        <Link to={`/artwork/${artwork.id}`} className="art-title">
          {artwork.title}
        </Link>

        <div className="art-meta-row">
          <Link to={`/artist/${artwork.user_id}`} className="art-artist-link">
            <div className="avatar-xs avatar-fallback">
              {artistDisplay[0]}
            </div>
            <span>{artistDisplay}</span>
          </Link>

          <div className="art-stats">
            <button
              type="button"
              className={`stat-action-btn ${isLiked ? 'liked' : ''}`}
              onClick={handleLikeClick}
              aria-label="إعجاب"
            >
              <Heart size={16} fill={isLiked ? '#D4AF37' : 'none'} />
              <span>{artwork.likes_count || 0}</span>
            </button>

            <Link to={`/artwork/${artwork.id}`} className="stat-action-btn" aria-label="التعليقات">
              <MessageCircle size={16} />
            </Link>
          </div>
        </div>
      </div>
    </article>
  );
}
