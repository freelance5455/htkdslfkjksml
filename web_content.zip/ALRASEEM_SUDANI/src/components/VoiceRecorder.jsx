import React, { useState, useRef } from 'react';
import { Mic, Square, Trash2, Send } from 'lucide-react';

export default function VoiceRecorder({ onSendVoice, disabled }) {
  const [recording, setRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState(null);
  const [audioPreviewUrl, setAudioPreviewUrl] = useState('');
  const [seconds, setSeconds] = useState(0);
  const [sending, setSending] = useState(false);

  const mediaRecorderRef = useRef(null);
  const chunksRef = useRef([]);
  const timerRef = useRef(null);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: mediaRecorder.mimeType || 'audio/webm' });
        setAudioBlob(blob);
        setAudioPreviewUrl(URL.createObjectURL(blob));
        stream.getTracks().forEach((t) => t.stop());
      };

      mediaRecorder.start();
      setRecording(true);
      setSeconds(0);
      timerRef.current = setInterval(() => {
        setSeconds((s) => {
          if (s >= 59) {
            stopRecording();
            return 60;
          }
          return s + 1;
        });
      }, 1000);
    } catch {
      alert('تعذر الوصول إلى الميكروفون. يرجى منح الإذن للتسجيل الصوتي.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && recording) {
      mediaRecorderRef.current.stop();
      setRecording(false);
      clearInterval(timerRef.current);
    }
  };

  const resetRecording = () => {
    setAudioBlob(null);
    setAudioPreviewUrl('');
    setSeconds(0);
  };

  const handleSend = async () => {
    if (!audioBlob || sending) return;
    setSending(true);
    try {
      await onSendVoice(audioBlob, seconds);
      resetRecording();
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="voice-recorder-box">
      {!recording && !audioBlob && (
        <button
          type="button"
          className="btn btn-outline btn-sm"
          onClick={startRecording}
          disabled={disabled}
        >
          <Mic size={16} className="gold-text" />
          <span>تسجيل تعليق صوتي</span>
        </button>
      )}

      {recording && (
        <div className="voice-active-bar">
          <span className="pulse-dot" />
          <span>جاري التسجيل... 00:{seconds < 10 ? `0${seconds}` : seconds}</span>
          <button type="button" className="btn btn-danger btn-sm" onClick={stopRecording}>
            <Square size={14} />
            <span>إيقاف</span>
          </button>
        </div>
      )}

      {audioBlob && !recording && (
        <div className="voice-preview-bar">
          <audio controls src={audioPreviewUrl} className="voice-audio-player" />
          <div className="voice-preview-actions">
            <button type="button" className="icon-btn" onClick={resetRecording} title="حذف">
              <Trash2 size={16} />
            </button>
            <button
              type="button"
              className="btn btn-gold btn-sm"
              onClick={handleSend}
              disabled={sending}
            >
              <Send size={15} />
              <span>{sending ? 'جاري الإرسال...' : 'إرسال الصوت'}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
