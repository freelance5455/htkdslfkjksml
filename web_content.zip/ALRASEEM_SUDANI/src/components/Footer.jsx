import React from 'react';
import { Link } from 'react-router-dom';
import Logo from './Logo';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div className="footer-brand">
          <Logo size="md" />
          <p className="footer-desc">
            منصة فنية سودانية متكاملة تهدف إلى تمكين الرسامين والفنانين التشكيليين السودانيين، وعرض إبداعاتهم للعالم بهوية بصرية أصيلة.
          </p>
        </div>

        <div className="footer-col">
          <h4>استكشف المنصة</h4>
          <ul>
            <li><Link to="/explore">المعرض التشكيلي</Link></li>
            <li><Link to="/artists">الفنانون السودانيون</Link></li>
            <li><Link to="/contests">المسابقات والجوائز</Link></li>
            <li><Link to="/exhibitions">المعارض الافتراضية</Link></li>
          </ul>
        </div>

        <div className="footer-col">
          <h4>للفنانين</h4>
          <ul>
            <li><Link to="/publish">نشر عمل فني جديد</Link></li>
            <li><Link to="/auth?mode=register">إنشاء ملف فنان</Link></li>
            <li><Link to="/favorites">الأعمال المحفوظة</Link></li>
          </ul>
        </div>
      </div>

      <div className="container footer-bottom">
        <p>© {new Date().getFullYear()} الرسيم السوداني | ALRASEEM SUDANI — جميع الحقوق محفوظة.</p>
        <p className="footer-tagline">صُنع بشغف لدعم الفن التشكيلي السوداني</p>
      </div>
    </footer>
  );
}
