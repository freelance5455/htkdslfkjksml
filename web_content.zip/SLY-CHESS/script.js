/* CHESS ARENA - UI + game flow */
(function () {
  'use strict';
  const E = window.ChessEngine, B = window.ChessBots, S = window.ChessSound;
  const $ = (id) => document.getElementById(id);
  const PROFILE_KEY = 'chessArena.profile.v1';
  const SOUND_KEY = 'chessArena.sound.v1';
  const START_ELO = 400;
  const K = 32;

  // ---------- state ----------
  let profile = loadProfile();
  let lang = (function () { try { return localStorage.getItem('slyChess.lang') === 'en' ? 'en' : 'ar'; } catch (e) { return 'ar'; } })();
  function T(k, vars) {
    let str = (window.I18N[lang] && window.I18N[lang][k]) || window.I18N.ar[k] || k;
    if (vars) for (const key of Object.keys(vars)) str = str.replace('{' + key + '}', vars[key]);
    return str;
  }
  const countryName = (bot) => (lang === 'en' ? bot.countryEn : bot.country);
  const styleText = (bot) => (lang === 'en' && bot.styleEn ? bot.styleEn : bot.style);
  let pickColor = 'random';
  let game = null;            // { bot, you, state, plies:[{before,move,san,after}], keys:[], busy, over, settled }
  let selected = -1;
  let flipped = false;
  let lastMove = null;
  let dragging = null;
  let squares = [];           // 64 square elements in visual order (top-left first)
  let pieceEls = new Map();   // sq -> <img>

  function loadProfile() {
    try {
      const p = JSON.parse(localStorage.getItem(PROFILE_KEY));
      if (p && typeof p.elo === 'number') return Object.assign({ wins: 0, losses: 0, draws: 0, puzzles: {} }, p);
    } catch (e) { /* ignore */ }
    return { elo: START_ELO, wins: 0, losses: 0, draws: 0, puzzles: {} };
  }
  function saveProfile() { try { localStorage.setItem(PROFILE_KEY, JSON.stringify(profile)); } catch (e) { /* ignore */ } }

  function loadSound() {
    try {
      const s = JSON.parse(localStorage.getItem(SOUND_KEY));
      if (s) { S.setEnabled(!!s.enabled); S.setVolume(s.volume); }
    } catch (e) { /* ignore */ }
  }
  function saveSound() {
    try { localStorage.setItem(SOUND_KEY, JSON.stringify({ enabled: S.isEnabled(), volume: S.getVolume() })); } catch (e) { /* ignore */ }
  }

  // In-app confirmation dialog: native confirm() is unreliable in Android WebView/file previews.
  let confirmAction = null;
  function askConfirm(message, onYes) {
    const layer = $('app-confirm');
    $('app-confirm-message').textContent = message;
    $('app-confirm-yes').textContent = lang === 'ar' ? 'نعم، متأكد' : 'Yes, continue';
    $('app-confirm-no').textContent = lang === 'ar' ? 'إلغاء' : 'Cancel';
    confirmAction = onYes;
    layer.classList.add('show');
  }
  function closeConfirm(accept) {
    $('app-confirm').classList.remove('show');
    const action = confirmAction;
    confirmAction = null;
    if (accept && action) action();
  }

  const pieceCode = (c) => (c === c.toUpperCase() ? 'w' : 'b') + c.toUpperCase();
  const pieceColor = (c) => (c === c.toUpperCase() ? 'w' : 'b');
  const imgPath = (folder, name) => `assets/${folder}/${name}.png`;
  const visCol = (sq) => (flipped ? 7 - (sq & 7) : (sq & 7));
  const visRow = (sq) => (flipped ? (sq >> 3) : 7 - (sq >> 3));
  function setPos(el, sq) { el.style.left = visCol(sq) * 12.5 + '%'; el.style.top = visRow(sq) * 12.5 + '%'; }

  function showScreen(id) {
    document.querySelectorAll('.screen').forEach((s) => s.classList.toggle('active', s.id === 'screen-' + id));
    document.getElementById('screen-game').classList.toggle('puzzle-mode', !!(game && game.puzzle));
    window.scrollTo(0, 0);
  }

  // ---------- home ----------
  function updateHome() {
    $('home-elo').textContent = profile.elo;
    $('home-w').textContent = profile.wins;
    $('home-l').textContent = profile.losses;
    $('home-d').textContent = profile.draws;
    $('pl-elo').textContent = profile.elo;
  }

  function buildBotGrid() {
    const grid = $('bot-grid');
    grid.innerHTML = '';
    B.BOTS.forEach((bot) => {
      const card = document.createElement('button');
      card.className = 'bot' + (bot.id === 'salman' ? ' top' : '');
      card.innerHTML = `
        <img class="avatar" src="${imgPath('avatars', bot.id)}" alt="${bot.name}" />
        <div class="nm">${bot.name}</div>
        <div class="ct"><img class="flag" src="${imgPath('flags', bot.id)}" alt="" />${countryName(bot)}</div>
        <div class="el">${bot.elo} ELO</div>
        <span class="tag">${T(B.difficultyOf(bot.elo))}</span>
        <div class="sty">${styleText(bot)}</div>`;
      card.addEventListener('click', () => startGame(bot));
      grid.appendChild(card);
    });
  }

  // ---------- board ----------
  function buildBoard() {
    const board = $('board');
    board.innerHTML = '';
    squares = [];
    for (let i = 0; i < 64; i++) {
      const d = document.createElement('div');
      d.className = 'sq';
      board.appendChild(d);
      squares.push(d);
    }
  }

  function renderBoard() {
    if (!game) return;
    const st = game.state;
    const targets = new Map();
    if (selected >= 0) {
      for (const m of E.legalMoves(st)) if (m.f === selected) targets.set(m.t, !!st.b[m.t] || !!m.ep);
    }
    const checkSq = E.inCheck(st, st.turn) ? st.b.indexOf(st.turn === 'w' ? 'K' : 'k') : -1;
    for (let vr = 0; vr < 8; vr++) {
      for (let vc = 0; vc < 8; vc++) {
        const el = squares[vr * 8 + vc];
        const rank = flipped ? vr : 7 - vr;
        const file = flipped ? 7 - vc : vc;
        const sq = rank * 8 + file;
        const light = (file + rank) % 2 === 1;
        let cls = 'sq ' + (light ? 'cream' : 'olive');
        if (lastMove && (sq === lastMove.f || sq === lastMove.t)) cls += ' last';
        if (sq === selected) cls += ' sel';
        if (targets.has(sq)) cls += targets.get(sq) ? ' cap' : ' dot';
        if (sq === checkSq) cls += ' check';
        el.className = cls;
        el.dataset.sq = sq;
        el.innerHTML = '';
        if (vc === 0) el.insertAdjacentHTML('beforeend', `<span class="lbl rank">${rank + 1}</span>`);
        if (vr === 7) el.insertAdjacentHTML('beforeend', `<span class="lbl file">${E.FILES[file]}</span>`);
      }
    }
  }

  // diff-based piece rendering so moves animate instead of teleporting
  function renderPieces(animMove) {
    const want = new Map();
    game.state.b.forEach((c, sq) => { if (c) want.set(sq, pieceCode(c)); });
    const next = new Map();
    const orphans = [];
    for (const [sq, el] of pieceEls) {
      if (want.get(sq) === el.dataset.p) { next.set(sq, el); want.delete(sq); }
      else orphans.push({ sq, el });
    }
    for (const [sq, code] of want) {
      let idx = -1;
      if (animMove && sq === animMove.t) idx = orphans.findIndex((o) => o.sq === animMove.f);
      if (idx < 0) idx = orphans.findIndex((o) => o.el.dataset.p === code);
      let el;
      if (idx >= 0) {
        el = orphans[idx].el;
        orphans.splice(idx, 1);
        if (el.dataset.p !== code) { el.dataset.p = code; el.src = imgPath('pieces', code); }
      } else {
        el = document.createElement('img');
        el.className = 'piece appear';
        el.alt = '';
        el.draggable = false;
        el.dataset.p = code;
        el.src = imgPath('pieces', code);
        setPos(el, sq);
        $('board').appendChild(el);
      }
      setPos(el, sq);
      next.set(sq, el);
    }
    for (const o of orphans) {
      o.el.classList.add('gone');
      o.el.style.pointerEvents = 'none';
      setTimeout(() => o.el.remove(), 220);
    }
    pieceEls = next;
  }

  function renderMoves() {
    const box = $('move-list');
    box.innerHTML = '';
    const plies = game.plies;
    for (let i = 0; i < plies.length; i += 2) {
      const row = document.createElement('div');
      row.className = 'mrow';
      const cur = (j) => (j === plies.length - 1 ? ' cur' : '');
      row.innerHTML = `<span class="n">${i / 2 + 1}.</span>
        <span class="m${cur(i)}">${plies[i].san}</span>
        <span class="m${i + 1 < plies.length ? cur(i + 1) : ''}">${i + 1 < plies.length ? plies[i + 1].san : ''}</span>`;
      box.appendChild(row);
    }
    box.scrollTop = box.scrollHeight;
  }

  function updateStatus() {
    if (!game) return;
    const st = game.state;
    let label, dotCls = st.turn === 'w' ? 'white' : 'black';
    if (game.over) label = T('over');
    else if (game.busy) label = game.bot ? T('thinking', { name: game.bot.name }) : T('puzzle_defender');
    else if (st.turn === game.you) label = T('turn_you');
    else label = T('turn_opp');
    $('turn-text').textContent = label;
    $('turn-dot').className = 'turn-dot ' + dotCls;
    const inCheck = !game.over && E.inCheck(st, st.turn);
    $('check-badge').classList.toggle('hidden', !inCheck);
    $('pl-color').textContent = T(game.you === 'w' ? 'white' : 'black');
  }

  function render() {
    renderBoard();
    renderPieces(lastMove);
    renderMoves();
    updateStatus();
  }

  // ---------- game flow ----------
  function startGame(bot) {
    S.unlock();
    const you = pickColor === 'random' ? (Math.random() < 0.5 ? 'w' : 'b') : pickColor;
    game = { bot, you, state: E.newGame(), plies: [], keys: [], busy: false, over: false, settled: false };
    game.keys.push(E.posKey(game.state));
    lastMove = null;
    selected = -1;
    dragging = null;
    flipped = you === 'b';
    fillOpponentHeader(bot);
    $('pl-elo').textContent = profile.elo;
    $('result').classList.remove('show');
    showScreen('game');
    buildBoard();
    pieceEls.forEach((el) => el.remove());
    pieceEls = new Map();
    render();
    if (game.state.turn !== game.you) botTurn();
  }

  function fillOpponentHeader(bot) {
    $('ob-avatar').src = imgPath('avatars', bot.id);
    $('ob-avatar').alt = bot.name;
    $('ob-flag').src = imgPath('flags', bot.id);
    $('ob-name').textContent = bot.name;
    $('ob-country').textContent = countryName(bot);
    $('ob-elo').textContent = bot.elo + ' ELO';
    $('ob-diff').textContent = T(B.difficultyOf(bot.elo));
    $('ob-style').textContent = styleText(bot);
  }

  function legalFrom(sq) { return E.legalMoves(game.state).filter((m) => m.f === sq); }

  function tryMove(from, to) {
    if (game.puzzle) {
      const st = game.state;
      const cands = legalFrom(from).filter((m) => m.t === to && puzzleValid(st, m, game.stage));
      if (!cands.length) { selected = -1; renderBoard(); setPuzzleMsg(T('wrong_move'), 'bad'); return true; }
      if (cands.length > 1) { askPromotion(cands); return true; }
      commitMove(cands[0]);
      return true;
    }
    const cands = legalFrom(from).filter((m) => m.t === to);
    if (!cands.length) return false;
    if (cands.length > 1) { askPromotion(cands); return true; }
    commitMove(cands[0]);
    return true;
  }

  function commitMove(m, opts) {
    const g = game;
    const st = g.state;
    const notation = E.san(st, m);
    const isCap = !!st.b[m.t] || !!m.ep;
    const next = E.applyMove(st, m);
    g.plies.push({ before: st, move: m, san: notation, after: next });
    g.state = next;
    g.keys.push(E.posKey(next));
    lastMove = m;
    selected = -1;
    const stat = E.status(next, g.keys.slice(0, -1));
    if (stat.over) g.over = true;
    if (stat.over && stat.result === 'checkmate') S.play('checkmate');
    else if (stat.check) S.play('check');
    else if (isCap) S.play('capture');
    else S.play('move');
    render();
    if (g.puzzle) { puzzleAfterMove(m, stat, !!(opts && opts.defender)); return; }
    if (stat.over) { setTimeout(() => endGame(stat), 700); return; }
    if (next.turn !== g.you) botTurn();
  }

  function botTurn() {
    const g = game;
    g.busy = true;
    updateStatus();
    setTimeout(async () => {
      if (game !== g || g.over) return;
      // SLY Engine v2 is the primary and only bot engine in this build.
      // It runs locally and does not require Stockfish files or an internet connection.
      let m = null;
      try { m = B.chooseMove(g.bot, g.state); }
      catch (e) { console.error('SLY Engine search failed:', e); }
      if (game !== g || g.over) return;
      g.busy = false;
      if (!m) { updateStatus(); return; }
      commitMove(m);
    }, 350 + Math.random() * 450);
  }

  function undo() {
    if (!game || game.busy || game.over) return;
    if (game.plies.length < 2 || game.state.turn !== game.you) return;
    game.plies.splice(-2, 2);
    game.keys.splice(-2, 2);
    game.state = game.plies.length ? game.plies[game.plies.length - 1].after : E.newGame();
    lastMove = game.plies.length ? game.plies[game.plies.length - 1].move : null;
    selected = -1;
    S.play('select');
    render();
  }

  function askPromotion(cands) {
    const box = $('promo-choices');
    box.innerHTML = '';
    for (const m of cands) {
      const b = document.createElement('button');
      b.className = 'promo-btn';
      const img = document.createElement('img');
      img.src = imgPath('pieces', (game.you === 'w' ? 'w' : 'b') + m.promo.toUpperCase());
      img.alt = m.promo;
      b.appendChild(img);
      b.addEventListener('click', () => {
        $('promo').classList.remove('show');
        commitMove(m);
      });
      box.appendChild(b);
    }
    $('promo').classList.add('show');
  }

  // ---------- end of game ----------
  function endGame(stat) {
    if (!game || game.settled) return;
    const g = game;
    g.settled = true;
    g.over = true;
    let outcome, reason, playBefore = false;
    if (stat.resign) { outcome = 'loss'; reason = T('reason_resign'); }
    else if (stat.result === 'checkmate') {
      outcome = stat.winner === g.you ? 'win' : 'loss';
      reason = T('reason_mate');
      playBefore = true;
    } else {
      outcome = 'draw';
      reason = { stalemate: T('reason_stalemate'), draw50: T('reason_50'), repetition: T('reason_rep'), insufficient: T('reason_ins') }[stat.result] || T('reason_draw');
    }

    const before = profile.elo;
    const expected = 1 / (1 + Math.pow(10, (g.bot.elo - before) / 400));
    const score = outcome === 'win' ? 1 : outcome === 'draw' ? 0.5 : 0;
    const change = Math.round(K * (score - expected));
    profile.elo = Math.max(100, before + change);
    if (outcome === 'win') profile.wins++;
    else if (outcome === 'loss') profile.losses++;
    else profile.draws++;
    saveProfile();
    updateHome();

    const sound = outcome === 'win' ? 'win' : outcome === 'loss' ? 'lose' : 'draw';
    if (playBefore) setTimeout(() => S.play(sound), 700);
    else S.play(sound);

    // show result immediately, fill accuracy after analysis
    $('res-title').textContent = outcome === 'win' ? T('result_win') : outcome === 'loss' ? T('result_loss') : T('result_draw');
    $('res-title').className = 'res-title ' + outcome;
    $('res-reason').textContent = reason;
    $('res-avatar').src = imgPath('avatars', g.bot.id);
    $('res-flag').src = imgPath('flags', g.bot.id);
    $('res-name').textContent = g.bot.name;
    $('res-opp-elo').textContent = `${g.bot.elo} ELO · ${countryName(g.bot)}`;
    $('res-before').textContent = before;
    $('res-after').textContent = profile.elo;
    $('res-change').textContent = (change > 0 ? '+' : '') + change;
    $('res-change').style.color = change > 0 ? 'var(--green)' : change < 0 ? '#ff8a80' : 'var(--text)';
    $('res-moves').textContent = Math.ceil(g.plies.length / 2);
    $('res-acc').textContent = '...';
    $('res-blunders').textContent = '...';
    $('res-best').textContent = '...';
    $('res-insight').textContent = T('analyzing');
    $('result').classList.add('show');

    const states = g.plies.map((p) => p.before);
    const moves = g.plies.map((p) => p.move);
    setTimeout(() => {
      let an = { moves: 0 };
      if (moves.length) an = B.analyzeGame(states, moves, g.you);
      g.analysis = an;
      $('res-acc').textContent = an.moves ? an.accuracy + '%' : '—';
      $('res-blunders').textContent = an.moves ? an.blunders : '—';
      $('res-best').textContent = an.moves ? an.best : '—';
      $('res-insight').textContent = insight(an, outcome, reason);
      $('res-reason').textContent = reason;
    }, 30);
  }

  function analysisText(key) {
    const ar = {
      title: 'تحليل المباراة', accuracy: 'دقة لعبك', blunders: 'أخطاء فادحة', mistakes: 'أخطاء', inaccuracies: 'نقلات غير دقيقة',
      moves: 'كل نقلات المباراة', empty: 'اختر نقلة من القائمة لمراجعتها.', played: 'نقلتك', best: 'أفضل نقلة', loss: 'فرق التقييم',
      note: 'التقييم تقريبي باستخدام محرك اللعبة الحالي، وليس تقييم Stockfish.', foot: 'الأرقام تقريبية وتعتمد على عمق بحث محدود.', back: 'العودة للنتيجة',
      bestGrade: 'أفضل نقلة', good: 'جيدة', inaccuracy: 'غير دقيقة', mistake: 'خطأ', blunder: 'خطأ فادح',
      bestExplain: 'أحسنت! نقلتك قريبة جدًا من أفضل اختيار للمحرك.', goodExplain: 'نقلة جيدة. يوجد اختيار أدق قليلًا.',
      inaccuracyExplain: 'النقلة فقدت بعض الأفضلية. جرّب مقارنة البديل المقترح.', mistakeExplain: 'كان هناك اختيار أقوى يحافظ على وضعك بشكل أفضل.',
      blunderExplain: 'هذه النقلة أضاعت أفضلية كبيرة أو سمحت بفرصة مهمة للمنافس.'
    };
    const en = {
      title: 'Game analysis', accuracy: 'Your accuracy', blunders: 'Blunders', mistakes: 'Mistakes', inaccuracies: 'Inaccuracies',
      moves: 'All game moves', empty: 'Choose a move from the list to review it.', played: 'Your move', best: 'Best move', loss: 'Evaluation loss',
      note: 'Approximate review using the built-in game engine, not Stockfish.', foot: 'Scores are approximate and use a limited search depth.', back: 'Back to result',
      bestGrade: 'Best move', good: 'Good', inaccuracy: 'Inaccuracy', mistake: 'Mistake', blunder: 'Blunder',
      bestExplain: 'Great choice! Your move is very close to the engine’s top choice.', goodExplain: 'A good move. There was a slightly more accurate option.',
      inaccuracyExplain: 'This move gave up some advantage. Compare it with the suggested alternative.', mistakeExplain: 'A stronger choice would have kept your position in better shape.',
      blunderExplain: 'This move lost a significant advantage or allowed an important chance.'
    };
    return (lang === 'en' ? en : ar)[key] || key;
  }

  let analysisSelectedIndex = -1;
  function renderAnalysis() {
    if (!game || !game.analysis) return;
    analysisSelectedIndex = -1;
    const an = game.analysis;
    const ids = {
      'analysis-title': 'title', 'analysis-accuracy-label': 'accuracy', 'analysis-blunders-label': 'blunders',
      'analysis-mistakes-label': 'mistakes', 'analysis-inaccuracies-label': 'inaccuracies', 'analysis-moves-heading': 'moves',
      'analysis-empty': 'empty', 'analysis-played-label': 'played', 'analysis-best-label': 'best',
      'analysis-loss-label': 'loss', 'analysis-note': 'note', 'analysis-footnote': 'foot', 'btn-analysis-done': 'back'
    };
    Object.keys(ids).forEach((id) => { if ($(id)) $(id).textContent = analysisText(ids[id]); });
    $('analysis-accuracy').textContent = an.moves ? an.accuracy + '%' : '—';
    $('analysis-blunders').textContent = an.blunders || 0;
    $('analysis-mistakes').textContent = an.mistakes || 0;
    $('analysis-inaccuracies').textContent = an.inaccuracies || 0;
    const list = $('analysis-move-list');
    list.innerHTML = '';
    (an.details || []).forEach((d, n) => {
      const item = document.createElement('button');
      item.type = 'button';
      item.className = 'analysis-move ' + d.grade;
      item.dataset.index = String(d.index);
      item.innerHTML = `<span class="analysis-num">${Math.floor(d.index / 2) + 1}${d.color === 'w' ? '.' : '…'}</span><strong></strong><span class="analysis-side ${d.color === 'w' ? 'white-side' : 'black-side'}">${d.color === 'w' ? 'W' : 'B'}</span><span class="analysis-grade-dot"></span>`;
      item.querySelector('strong').textContent = d.playedSan;
      item.addEventListener('click', () => showAnalysisDetail(d, item));
      list.appendChild(item);
      if (n === 0) setTimeout(() => showAnalysisDetail(d, item), 0);
    });
    if (!an.details || !an.details.length) {
      $('analysis-empty').textContent = lang === 'en' ? 'There were not enough moves to analyze.' : 'عدد النقلات غير كافٍ للتحليل.';
      $('analysis-empty').classList.remove('hidden');
      $('analysis-detail-content').classList.add('hidden');
    }
  }

  function showAnalysisDetail(d, item) {
    analysisSelectedIndex = d.index;
    document.querySelectorAll('.analysis-move.active').forEach((el) => el.classList.remove('active'));
    if (item) item.classList.add('active');
    const gradeName = analysisText(d.grade === 'best' ? 'bestGrade' : d.grade);
    $('analysis-empty').classList.add('hidden');
    $('analysis-detail-content').classList.remove('hidden');
    $('analysis-move-number').textContent = `${lang === 'en' ? (d.color === 'w' ? 'White' : 'Black') : (d.color === 'w' ? 'الأبيض' : 'الأسود')} · ${lang === 'en' ? 'Move' : 'النقلة'} ${Math.floor(d.index / 2) + 1}`;
    $('analysis-step-count').textContent = `${d.index + 1} / ${game.analysis.totalMoves || game.analysis.details.length}`;
    $('analysis-board-caption').textContent = lang === 'en' ? 'Position before this move' : 'الوضع قبل تنفيذ النقلة';
    renderAnalysisBoard(d.beforeFen, d.index);
    $('analysis-prev').disabled = !game.analysis.details.some(x => x.index < d.index);
    $('analysis-next').disabled = !game.analysis.details.some(x => x.index > d.index);
    $('analysis-grade').textContent = gradeName;
    $('analysis-grade').className = 'analysis-grade ' + d.grade;
    $('analysis-played').textContent = d.playedSan;
    $('analysis-best').textContent = d.bestSan;
    $('analysis-loss-value').textContent = d.cpl + ' cp';
    const explainKey = d.grade === 'best' ? 'bestExplain' : d.grade + 'Explain';
    $('analysis-explanation').textContent = analysisText(explainKey);
  }

  function renderAnalysisBoard(fen, plyIndex) {
    const host = $('analysis-board');
    if (!host || !fen) return;
    const st = E.fromFen(fen);
    host.innerHTML = '';
    for (let vr = 0; vr < 8; vr++) {
      for (let vc = 0; vc < 8; vc++) {
        const rank = flipped ? vr : 7 - vr;
        const file = flipped ? 7 - vc : vc;
        const sq = rank * 8 + file;
        const cell = document.createElement('div');
        cell.className = 'analysis-square ' + (((file + rank) % 2) ? 'light' : 'dark');
        const detail = game.analysis.details.find(x => x.index === plyIndex);
        if (detail && (sq === detail.playedMove.f || sq === detail.playedMove.t)) cell.classList.add('hint-square');
        const piece = st.b[sq];
        if (piece) {
          const img = document.createElement('img');
          img.src = imgPath('pieces', pieceCode(piece));
          img.alt = '';
          cell.appendChild(img);
        }
        host.appendChild(cell);
      }
    }
  }

  function stepAnalysis(delta) {
    if (!game || !game.analysis) return;
    const details = game.analysis.details || [];
    const pos = details.findIndex(d => d.index === analysisSelectedIndex);
    const next = details[Math.max(0, Math.min(details.length - 1, (pos < 0 ? 0 : pos) + delta))];
    if (!next) return;
    const item = $('analysis-move-list').querySelector(`[data-index="${next.index}"]`);
    showAnalysisDetail(next, item);
    if (item && item.scrollIntoView) item.scrollIntoView({ block: 'nearest' });
  }

  function openAnalysis() {
    if (!game || !game.analysis) return;
    renderAnalysis();
    $('analysis-overlay').classList.add('show');
  }

  function closeAnalysis() { $('analysis-overlay').classList.remove('show'); }

  function insight(an, outcome) {
    if (!an.moves) return T('short_game');
    if (outcome === 'win' && an.blunders === 0) return T('ins_clean_win');
    if (an.blunders >= 2) return T('ins_blunders', { n: an.blunders });
    if (an.accuracy >= 88) return T('ins_strong');
    if (an.best <= 2) return T('ins_best');
    return T('ins_avg');
  }

  function resign() {
    if (!game || game.over) return;
    askConfirm(T('confirm_resign'), () => endGame({ resign: true }));
  }

  function leaveGame() {
    if (game && game.puzzle) { game = null; showScreen('puzzles'); renderPuzzleScreen(); return; }
    if (game && !game.over) {
      askConfirm(T('confirm_leave'), () => endGame({ resign: true }));
      return;
    }
    game = null;
    $('result').classList.remove('show');
    showScreen('home');
    updateHome();
  }

  function newGame() {
    if (!game) return;
    if (game.puzzle) { startPuzzle(game.puzzle, game.daily); return; }
    if (!game.over) {
      askConfirm(T('confirm_new'), () => endGame({ resign: true }));
      return;
    }
    startGame(game.bot);
  }

  // ---------- pointer input (mouse, touch, pen) ----------
  function sqAt(x, y) {
    const rect = $('board').getBoundingClientRect();
    if (x < rect.left || x > rect.right || y < rect.top || y > rect.bottom) return -1;
    const vc = Math.min(7, Math.floor((x - rect.left) / rect.width * 8));
    const vr = Math.min(7, Math.floor((y - rect.top) / rect.height * 8));
    const rank = flipped ? vr : 7 - vr;
    const file = flipped ? 7 - vc : vc;
    return rank * 8 + file;
  }

  function onDown(e) {
    if (!game || game.over || game.busy || game.state.turn !== game.you) return;
    const sq = sqAt(e.clientX, e.clientY);
    if (sq < 0) return;
    // tap a highlighted target with a piece already selected
    if (selected >= 0 && legalFrom(selected).some((m) => m.t === sq)) {
      e.preventDefault();
      tryMove(selected, sq);
      return;
    }
    const p = game.state.b[sq];
    if (p && pieceColor(p) === game.you) {
      const wasSel = selected === sq;
      selected = sq;
      if (!wasSel) S.play('select');
      renderBoard();
      const el = pieceEls.get(sq);
      dragging = { sq, el, x0: e.clientX, y0: e.clientY, moved: false, wasSel };
      if (el) el.classList.add('drag');
      e.preventDefault();
    } else {
      selected = -1;
      renderBoard();
    }
  }

  function onMove(e) {
    if (!dragging) return;
    const dx = e.clientX - dragging.x0, dy = e.clientY - dragging.y0;
    if (!dragging.moved && Math.hypot(dx, dy) > 6) dragging.moved = true;
    if (dragging.moved && dragging.el) dragging.el.style.transform = `translate(${dx}px, ${dy}px)`;
  }

  function onUp(e) {
    if (!dragging) return;
    const d = dragging;
    dragging = null;
    if (d.el) { d.el.classList.remove('drag'); d.el.style.transform = ''; }
    if (!d.moved) {
      if (d.wasSel) { selected = -1; renderBoard(); }
      return;
    }
    const target = sqAt(e.clientX, e.clientY);
    if (target >= 0 && target !== d.sq && legalFrom(d.sq).some((m) => m.t === target)) {
      tryMove(d.sq, target);
    } else {
      renderBoard();
    }
  }

  // ---------- sound controls ----------
  function refreshSoundBtn() {
    $('btn-sound').textContent = T(S.isEnabled() ? 'sound_on' : 'sound_off');
    $('vol').value = Math.round(S.getVolume() * 100);
  }

  // ---------- wire up ----------
  function applyLang() {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = T(el.dataset.i18n); });
    $('btn-lang').textContent = T('lang_btn');
    buildBotGrid();
    updateHome();
    refreshSoundBtn();
    if (game) { if (game.bot) fillOpponentHeader(game.bot); updateStatus(); renderMoves(); }
  }

  let inited = false;
  function init() {
    if (inited) return;
    inited = true;
    loadSound();
    buildBoard();
    applyLang();
    $('btn-lang').addEventListener('click', () => {
      lang = lang === 'ar' ? 'en' : 'ar';
      try { localStorage.setItem('slyChess.lang', lang); } catch (e) { /* ignore */ }
      applyLang();
    });

    document.querySelectorAll('#color-seg button').forEach((b) => b.addEventListener('click', () => {
      pickColor = b.dataset.color;
      document.querySelectorAll('#color-seg button').forEach((x) => x.classList.toggle('on', x === b));
    }));
    $('go-select').addEventListener('click', () => { S.unlock(); S.play('select'); showScreen('select'); });
    document.querySelectorAll('[data-back]').forEach((b) => b.addEventListener('click', () => { showScreen(b.dataset.back); updateHome(); }));

    $('btn-leave').addEventListener('click', leaveGame);
    $('app-confirm-yes').addEventListener('click', () => closeConfirm(true));
    $('app-confirm-no').addEventListener('click', () => closeConfirm(false));
    $('app-confirm').addEventListener('click', (e) => { if (e.target === $('app-confirm')) closeConfirm(false); });
    $('btn-new').addEventListener('click', newGame);
    $('btn-undo').addEventListener('click', undo);
    $('btn-resign').addEventListener('click', resign);
    $('btn-flip').addEventListener('click', () => { flipped = !flipped; buildBoard(); renderBoardInitial(); });
    $('btn-sound').addEventListener('click', () => { S.setEnabled(!S.isEnabled()); S.unlock(); saveSound(); refreshSoundBtn(); });
    $('vol').addEventListener('input', (e) => { S.setVolume(e.target.value / 100); saveSound(); });

    $('btn-rematch').addEventListener('click', () => { closeAnalysis(); if (game) startGame(game.bot); });
    $('btn-analysis').addEventListener('click', openAnalysis);
    $('btn-analysis-close').addEventListener('click', closeAnalysis);
    $('btn-analysis-done').addEventListener('click', closeAnalysis);
    $('analysis-prev').addEventListener('click', () => stepAnalysis(-1));
    $('analysis-next').addEventListener('click', () => stepAnalysis(1));
    $('analysis-overlay').addEventListener('click', (e) => { if (e.target === $('analysis-overlay')) closeAnalysis(); });
    $('go-puzzles').addEventListener('click', () => { S.unlock(); showScreen('puzzles'); renderPuzzleScreen(); });
    $('btn-hint').addEventListener('click', puzzleHint);
    $('btn-retry').addEventListener('click', () => { if (game && game.puzzle) startPuzzle(game.puzzle, game.daily); });
    $('btn-next').addEventListener('click', () => { game = null; showScreen('puzzles'); renderPuzzleScreen(); });
    $('btn-change').addEventListener('click', () => { closeAnalysis(); $('result').classList.remove('show'); game = null; showScreen('select'); });

    const board = $('board');
    board.addEventListener('pointerdown', onDown);
    window.addEventListener('pointermove', onMove, { passive: true });
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onUp);
    board.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  // re-create board squares and pieces after orientation change
  function renderBoardInitial() {
    pieceEls.forEach((el) => el.remove());
    pieceEls = new Map();
    renderBoard();
    renderPieces(null);
  }

  // ---------- puzzles ----------
  const PUZ_LEVELS = [
    { level: 1, name: 'pz_l1', desc: 'pz_l1d' },
    { level: 2, name: 'pz_l2', desc: 'pz_l2d' },
    { level: 3, name: 'pz_l3', desc: 'pz_l3d' },
    { level: 4, name: 'pz_l4', desc: 'pz_l4d' },
  ];
  const puzzleList = (level) => (window.PUZZLES || []).filter((p) => p.level === level);
  const isSolved = (id) => !!(profile.puzzles && profile.puzzles[id]);
  function dailyPuzzle(level) {
    const list = puzzleList(level);
    if (!list.length) return null;
    const day = Math.floor(Date.now() / 86400000);
    return list[(day * 7 + level * 5) % list.length];
  }
  const isMateNow = (t) => E.inCheck(t, t.turn) && E.legalMoves(t).length === 0;
  const canMate1Pos = (s) => E.legalMoves(s).some((m) => isMateNow(E.applyMove(s, m)));
  function puzzleValid(s, m, stage) {
    const t = E.applyMove(s, m);
    if (isMateNow(t)) return true;
    if (game.puzzle.mate === 2 && stage === 0) {
      const replies = E.legalMoves(t);
      return replies.length > 0 && replies.every((r) => canMate1Pos(E.applyMove(t, r)));
    }
    return false;
  }

  function setPuzzleMsg(text, kind) {
    const el = $('puzzle-msg');
    el.textContent = text;
    el.className = 'puzzle-msg ' + (kind || '');
    if (kind === 'bad') { void el.offsetWidth; el.classList.add('shake'); }
  }
  function setPuzzleButtons(solved) {
    $('btn-hint').classList.toggle('hidden', !!solved);
    $('btn-next').classList.toggle('hidden', !solved);
  }

  function startPuzzle(p, daily) {
    if (!p) return;
    S.unlock();
    const st = E.fromFen(p.fen);
    game = { bot: null, you: st.turn, state: st, plies: [], keys: [E.posKey(st)], busy: false, over: false, settled: false, puzzle: p, stage: 0, daily: !!daily };
    lastMove = null;
    selected = -1;
    dragging = null;
    flipped = st.turn === 'b';
    $('result').classList.remove('show');
    showScreen('game');
    buildBoard();
    pieceEls.forEach((el) => el.remove());
    pieceEls = new Map();
    setPuzzleButtons(false);
    setPuzzleMsg(T(p.mate === 1 ? 'puzzle_mate_in_1' : 'puzzle_mate_in_2'), '');
    render();
  }

  function puzzleAfterMove(m, stat, defender) {
    const g = game;
    if (defender) {
      g.busy = false;
      if (stat.over) { puzzleFailed(); return; }
      updateStatus();
      setPuzzleMsg(T('puzzle_your_turn'), '');
      return;
    }
    if (stat.over && stat.result === 'checkmate') { solvedPuzzle(); return; }
    if (stat.over || g.puzzle.mate !== 2 || g.stage !== 0) { puzzleFailed(); return; }
    g.stage = 1;
    g.busy = true;
    updateStatus();
    setPuzzleMsg(T('puzzle_defender'), '');
    setTimeout(() => {
      if (game !== g) return;
      const replies = E.legalMoves(g.state);
      if (!replies.length) { puzzleFailed(); return; }
      commitMove(replies[Math.floor(Math.random() * replies.length)], { defender: true });
    }, 500);
  }

  function puzzleFailed() {
    game.busy = false;
    updateStatus();
    setPuzzleMsg(T('wrong_move'), 'bad');
  }

  function solvedPuzzle() {
    const g = game;
    g.over = true;
    g.settled = true;
    profile.puzzles = profile.puzzles || {};
    profile.puzzles[g.puzzle.id] = true;
    saveProfile();
    setTimeout(() => S.play('win'), 700);
    setPuzzleMsg(T('mate_found'), 'ok');
    updateStatus();
    setPuzzleButtons(true);
  }

  function puzzleHint() {
    const g = game;
    if (!g || !g.puzzle || g.over || g.busy) return;
    const cands = E.legalMoves(g.state).filter((m) => puzzleValid(g.state, m, g.stage));
    if (!cands.length) return;
    selected = cands[0].f;
    renderBoard();
    setPuzzleMsg(T('hint_sent'), '');
  }

  function renderPuzzleScreen() {
    const grid = $('level-grid');
    grid.innerHTML = '';
    $('daily-date').textContent = new Date().toLocaleDateString(lang === 'en' ? 'en-US' : 'ar-EG', { weekday: 'long', day: 'numeric', month: 'long' });
    PUZ_LEVELS.forEach((info) => {
      const list = puzzleList(info.level);
      const solved = list.filter((p) => isSolved(p.id)).length;
      const d = dailyPuzzle(info.level);
      const card = document.createElement('div');
      card.className = 'card level-card';
      card.innerHTML = `
        <div class="lvl-head"><span class="lvl-num">${info.level}</span>
          <div><strong>${T(info.name)}</strong><div class="muted">${T(info.desc)}</div></div></div>
        <div class="muted lvl-meta">${solved}/${list.length} ${T('solved')}</div>
        <div class="lvl-actions">
          <button class="btn gold" data-daily="${info.level}">${T('daily_puzzle')}${d && isSolved(d.id) ? ' ✓' : ''}</button>
          <button class="btn" data-lib="${info.level}">${T('library')}</button>
        </div>
        <div class="chips hidden" data-chips="${info.level}"></div>`;
      grid.appendChild(card);
    });
    grid.querySelectorAll('[data-daily]').forEach((b) => b.addEventListener('click', () => startPuzzle(dailyPuzzle(+b.dataset.daily), true)));
    grid.querySelectorAll('[data-lib]').forEach((b) => b.addEventListener('click', () => toggleChips(+b.dataset.lib)));
  }

  function toggleChips(level) {
    const box = document.querySelector(`[data-chips="${level}"]`);
    if (!box) return;
    if (!box.classList.contains('hidden')) { box.classList.add('hidden'); return; }
    box.innerHTML = '';
    puzzleList(level).forEach((p, i) => {
      const c = document.createElement('button');
      c.className = 'chip' + (isSolved(p.id) ? ' done' : '');
      c.textContent = i + 1;
      c.addEventListener('click', () => startPuzzle(p, false));
      box.appendChild(c);
    });
    box.classList.remove('hidden');
  }

  document.addEventListener('DOMContentLoaded', init);
  if (document.readyState !== 'loading') init();
})();
