/* CHESS ARENA - synthesized sound effects (Web Audio API, no files needed) */
(function (root) {
  'use strict';
  let ctx = null, master = null, enabled = true, volume = 0.6;
  const lastPlayed = {};

  function ensure() {
    if (!ctx) {
      const AC = root.AudioContext || root.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
      master = ctx.createGain();
      master.gain.value = volume;
      master.connect(ctx.destination);
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }

  function tone(freq, start, dur, type, vol, endFreq) {
    const c = ensure(); if (!c) return;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type || 'sine';
    const t0 = c.currentTime + start;
    o.frequency.setValueAtTime(freq, t0);
    if (endFreq) o.frequency.exponentialRampToValueAtTime(endFreq, t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol || 0.3, t0 + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(master);
    o.start(t0); o.stop(t0 + dur + 0.02);
  }

  function noise(start, dur, vol, cutoff) {
    const c = ensure(); if (!c) return;
    const len = Math.floor(c.sampleRate * dur);
    const buf = c.createBuffer(1, len, c.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = c.createBufferSource(); src.buffer = buf;
    const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = cutoff || 2500;
    const g = c.createGain(); g.gain.value = vol || 0.25;
    src.connect(f); f.connect(g); g.connect(master);
    src.start(c.currentTime + start);
  }

  const SOUNDS = {
    move: () => { noise(0, 0.035, 0.22, 3000); tone(520, 0, 0.05, 'triangle', 0.12, 380); },
    capture: () => { noise(0, 0.12, 0.42, 1800); tone(180, 0, 0.12, 'sine', 0.2, 90); },
    check: () => { tone(880, 0, 0.12, 'square', 0.08); tone(660, 0.12, 0.18, 'square', 0.08); },
    checkmate: () => { [523, 659, 784, 1046].forEach((f, i) => tone(f, i * 0.16, 0.5, 'triangle', 0.2)); },
    win: () => { [523, 659, 784, 1046, 1318].forEach((f, i) => tone(f, i * 0.12, 0.35, 'triangle', 0.18)); },
    lose: () => { [392, 330, 262, 196].forEach((f, i) => tone(f, i * 0.22, 0.4, 'sine', 0.2)); },
    draw: () => { tone(440, 0, 0.25, 'sine', 0.16); tone(440, 0.28, 0.25, 'sine', 0.16); },
    select: () => { tone(960, 0, 0.03, 'sine', 0.08); },
  };

  const api = {
    play(name) {
      if (!enabled || !SOUNDS[name]) return;
      const now = Date.now();
      const gap = name === 'select' ? 30 : 60;
      if (lastPlayed[name] && now - lastPlayed[name] < gap) return;
      lastPlayed[name] = now;
      try { SOUNDS[name](); } catch (e) { /* audio unavailable */ }
    },
    unlock() { ensure(); },
    setEnabled(v) { enabled = !!v; },
    isEnabled() { return enabled; },
    setVolume(v) { volume = Math.max(0, Math.min(1, v)); if (master) master.gain.value = volume; },
    getVolume() { return volume; },
  };
  root.ChessSound = api;
})(typeof window !== 'undefined' ? window : globalThis);
