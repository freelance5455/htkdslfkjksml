/* SLY ENGINE v2 - upgraded in-house chess search.
 * Pure JavaScript, no Stockfish dependency. Strength is not Stockfish-calibrated.
 */
(function (root) {
  'use strict';
  const CE = root.ChessEngine || (typeof require !== 'undefined' ? require('./chess-engine.js') : null);
  const MATE = 100000, INF = 1000000;
  const VAL = { p: 100, n: 320, b: 335, r: 500, q: 900, k: 0 };
  const TT_EXACT = 0, TT_LOWER = 1, TT_UPPER = 2;
  const TT_LIMIT = 90000;
  let lastSearchInfo = { depth: 0, nodes: 0, score: 0, engine: 'SLY Engine v2' };

  const PST = {
    p: [0,0,0,0,0,0,0,0, 50,50,50,50,50,50,50,50, 10,10,20,30,30,20,10,10, 5,5,10,25,25,10,5,5,
        0,0,0,20,20,0,0,0, 5,-5,-10,0,0,-10,-5,5, 5,10,10,-20,-20,10,10,5, 0,0,0,0,0,0,0,0],
    n: [-50,-40,-30,-30,-30,-30,-40,-50, -40,-20,0,0,0,0,-20,-40, -30,0,10,15,15,10,0,-30, -30,5,15,20,20,15,5,-30,
        -30,0,15,20,20,15,0,-30, -30,5,10,15,15,10,5,-30, -40,-20,0,5,5,0,-20,-40, -50,-40,-30,-30,-30,-30,-40,-50],
    b: [-20,-10,-10,-10,-10,-10,-10,-20, -10,0,0,0,0,0,0,-10, -10,0,5,10,10,5,0,-10, -10,5,5,10,10,5,5,-10,
        -10,0,10,10,10,10,0,-10, -10,10,10,10,10,10,10,-10, -10,5,0,0,0,0,5,-10, -20,-10,-10,-10,-10,-10,-10,-20],
    r: [0,0,0,0,0,0,0,0, 5,10,10,10,10,10,10,5, -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5,
        -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5, 0,0,0,5,5,0,0,0],
    q: [-20,-10,-10,-5,-5,-10,-10,-20, -10,0,0,0,0,0,0,-10, -10,0,5,5,5,5,0,-10, -5,0,5,5,5,5,0,-5,
        0,0,5,5,5,5,0,-5, -10,5,5,5,5,5,0,-10, -10,0,5,0,0,0,0,-10, -20,-10,-10,-5,-5,-10,-10,-20],
    k: [-30,-40,-40,-50,-50,-40,-40,-30, -30,-40,-40,-50,-50,-40,-40,-30, -30,-40,-40,-50,-50,-40,-40,-30,
        -30,-40,-40,-50,-50,-40,-40,-30, -20,-30,-30,-40,-40,-30,-30,-20, -10,-20,-20,-20,-20,-20,-20,-10,
        20,20,0,0,0,0,20,20, 20,30,10,0,0,10,30,20]
  };

  const sign = s => s.turn === 'w' ? 1 : -1;
  const pieceColor = p => p === p.toUpperCase() ? 'w' : 'b';
  const enemy = c => c === 'w' ? 'b' : 'w';
  const sqColor = sq => ((sq >> 3) + (sq & 7)) & 1;

  // Static evaluation from White's point of view. Includes material, PST,
  // bishop pair, pawn structure/passed pawns, rook files and king activity.
  function evaluate(b) {
    let score = 0, phase = 0, bishopsW = 0, bishopsB = 0;
    const pawns = { w: Array(8).fill(0), b: Array(8).fill(0) };
    const king = { w: -1, b: -1 };
    for (let sq = 0; sq < 64; sq++) {
      const p = b[sq]; if (!p) continue;
      const t = p.toLowerCase(), c = pieceColor(p), white = c === 'w';
      const r = sq >> 3, f = sq & 7;
      const idx = white ? (7-r)*8+f : r*8+f;
      let v = VAL[t] + PST[t][idx];
      if (t === 'p') pawns[c][f]++;
      if (t === 'b') { if (white) bishopsW++; else bishopsB++; }
      if (t === 'k') king[c] = sq;
      if (t === 'n' || t === 'b') phase += 1;
      if (t === 'r') phase += 2;
      if (t === 'q') phase += 4;
      score += white ? v : -v;
    }
    if (bishopsW >= 2) score += 28;
    if (bishopsB >= 2) score -= 28;

    // Pawn structure: doubled/isolated penalties and passed-pawn bonuses.
    for (const c of ['w','b']) {
      const dir = c === 'w' ? 1 : -1, signC = c === 'w' ? 1 : -1;
      for (let f = 0; f < 8; f++) {
        const count = pawns[c][f];
        if (count > 1) score -= signC * 13 * (count - 1);
        const adjacent = (f > 0 ? pawns[c][f-1] : 0) + (f < 7 ? pawns[c][f+1] : 0);
        if (count && !adjacent) score -= signC * 11 * count;
        if (!count) continue;
        for (let r = 0; r < 8; r++) {
          const sq = r*8+f;
          if (b[sq] !== (c === 'w' ? 'P' : 'p')) continue;
          let passed = true;
          for (let rr = r + dir; rr >= 0 && rr < 8 && passed; rr += dir) {
            for (let ff = Math.max(0,f-1); ff <= Math.min(7,f+1); ff++) {
              if (b[rr*8+ff] === (c === 'w' ? 'p' : 'P')) { passed = false; break; }
            }
          }
          if (passed) {
            const advance = c === 'w' ? r : 7-r;
            score += signC * (12 + advance*advance*4);
          }
        }
      }
    }

    // Rooks on open/semi-open files and king centralization in simplified endings.
    for (let sq = 0; sq < 64; sq++) {
      const p = b[sq]; if (!p || p.toLowerCase() !== 'r') continue;
      const c = pieceColor(p), f = sq & 7, s = c === 'w' ? 1 : -1;
      const own = c === 'w' ? pawns.w[f] : pawns.b[f];
      const opp = c === 'w' ? pawns.b[f] : pawns.w[f];
      if (!own && !opp) score += s * 18;
      else if (!own) score += s * 9;
    }
    if (phase <= 6) {
      for (const c of ['w','b']) if (king[c] >= 0) {
        const sq = king[c], f = sq & 7, r = sq >> 3;
        const central = 7 - (Math.abs(3.5-f) + Math.abs(3.5-r));
        score += (c === 'w' ? 1 : -1) * Math.round(central * 8);
      }
    }
    return score;
  }

  function moveKey(m) { return `${m.f},${m.t},${m.promo || ''}`; }
  function ttKey(s) { return CE.posKey(s) + ':' + s.half; }
  function createContext(maxNodes) {
    return { nodes: 0, maxNodes: maxNodes || 50000, stopped: false, tt: new Map(), killers: Array.from({length: 64}, () => [null,null]), history: new Int32Array(4096) };
  }
  function captureValue(s,m) {
    const victim = m.ep ? 100 : (VAL[(s.b[m.t] || '').toLowerCase()] || 0);
    const attacker = VAL[(s.b[m.f] || '').toLowerCase()] || 0;
    return victim * 16 - attacker + (m.promo ? VAL[m.promo] : 0);
  }
  function orderMoves(s, moves, ctx, ply, ttMove) {
    const killers = ctx.killers[ply] || [];
    return moves.slice().sort((a,b) => {
      function score(m) {
        if (ttMove && moveKey(m) === ttMove) return 2e7;
        if (m.cap || m.ep) return 1e7 + captureValue(s,m);
        if (m.promo) return 9e6 + (VAL[m.promo] || 0);
        const k = moveKey(m);
        if (killers[0] === k) return 8e6;
        if (killers[1] === k) return 7.9e6;
        return ctx.history[m.f*64+m.t] || 0;
      }
      return score(b)-score(a);
    });
  }
  function rememberQuiet(ctx,m,ply,depth) {
    const k = moveKey(m), arr = ctx.killers[ply];
    if (arr && arr[0] !== k) { arr[1] = arr[0]; arr[0] = k; }
    const idx = m.f*64+m.t;
    ctx.history[idx] = Math.min(100000, ctx.history[idx] + depth*depth*12);
  }

  function quiesce(s, alpha, beta, ply, qply, ctx) {
    if (ctx.stopped) return 0;
    if (++ctx.nodes > ctx.maxNodes) { ctx.stopped = true; return 0; }
    const checked = CE.inCheck(s,s.turn);
    let stand = sign(s) * evaluate(s.b);
    if (!checked) {
      if (stand >= beta) return stand;
      if (stand > alpha) alpha = stand;
      if (qply >= 7) return stand;
    } else if (qply >= 9) {
      return stand - 80;
    }
    let moves = CE.legalMoves(s);
    if (!moves.length) return checked ? -(MATE-ply) : stand;
    if (!checked) moves = moves.filter(m => m.cap || m.ep || m.promo);
    moves = orderMoves(s,moves,ctx,ply,null);
    for (const m of moves) {
      const score = -quiesce(CE.applyMove(s,m),-beta,-alpha,ply+1,qply+1,ctx);
      if (ctx.stopped) return 0;
      if (score >= beta) return score;
      if (score > alpha) alpha = score;
    }
    return alpha;
  }

  function negamax(s, depth, alpha, beta, ply, ctx) {
    if (ctx.stopped) return 0;
    if (++ctx.nodes > ctx.maxNodes) { ctx.stopped = true; return 0; }
    if (s.half >= 100 || CE.insufficientMaterial(s.b)) return 0;
    const inCheck = CE.inCheck(s,s.turn);
    // Detect mate and stalemate even exactly at the horizon.
    if (depth <= 0) {
      const leafMoves = CE.legalMoves(s);
      if (!leafMoves.length) return inCheck ? -(MATE-ply) : 0;
      return quiesce(s,alpha,beta,ply,0,ctx);
    }

    const key = ttKey(s), alphaOrig = alpha, betaOrig = beta;
    const entry = ctx.tt.get(key);
    let ttMove = null;
    if (entry) {
      ttMove = entry.move;
      if (entry.depth >= depth) {
        const v = entry.score;
        if (entry.flag === TT_EXACT) return v;
        if (entry.flag === TT_LOWER && v > alpha) alpha = v;
        else if (entry.flag === TT_UPPER && v < beta) beta = v;
        if (alpha >= beta) return v;
      }
    }

    const moves = CE.legalMoves(s);
    if (!moves.length) return inCheck ? -(MATE-ply) : 0;
    let best = -INF, bestMove = null;
    for (const m of orderMoves(s,moves,ctx,ply,ttMove)) {
      const quiet = !m.cap && !m.ep && !m.promo;
      const score = -negamax(CE.applyMove(s,m),depth-1,-beta,-alpha,ply+1,ctx);
      if (ctx.stopped) return 0;
      if (score > best) { best = score; bestMove = moveKey(m); }
      if (score > alpha) alpha = score;
      if (alpha >= beta) {
        if (quiet) rememberQuiet(ctx,m,ply,depth);
        break;
      }
    }
    let flag = TT_EXACT;
    if (best <= alphaOrig) flag = TT_UPPER;
    else if (best >= betaOrig) flag = TT_LOWER;
    if (ctx.tt.size >= TT_LIMIT) ctx.tt.clear();
    ctx.tt.set(key,{depth,score:best,flag,move:bestMove});
    return best;
  }

  function scoreMoves(s, depth) {
    const ctx = createContext(80000), res = [];
    const legal = orderMoves(s,CE.legalMoves(s),ctx,0,null);
    for (const m of legal) {
      const child = CE.applyMove(s,m);
      const score = -negamax(child,Math.max(0,depth-1),-INF,INF,1,ctx);
      if (ctx.stopped) break;
      res.push({m,score});
    }
    lastSearchInfo = { depth, nodes: ctx.nodes, score: res.length ? Math.max(...res.map(x=>x.score)) : 0, engine: 'SLY Engine v2' };
    return res;
  }

  function searchBestMove(s, targetDepth, maxNodes) {
    const ctx = createContext(maxNodes), rootMoves = CE.legalMoves(s);
    if (!rootMoves.length) return null;
    let bestMove = rootMoves[0], bestScore = -INF, completedDepth = 0;
    let pvMove = null;
    for (let depth=1; depth<=targetDepth; depth++) {
      let iterationBest = null, iterationScore = -INF, alpha = -INF;
      const ordered = orderMoves(s,rootMoves,ctx,0,pvMove);
      for (const m of ordered) {
        const score = -negamax(CE.applyMove(s,m),depth-1,-INF,-alpha,1,ctx);
        if (ctx.stopped) break;
        if (score > iterationScore) { iterationScore=score; iterationBest=m; }
        if (score > alpha) alpha=score;
      }
      if (ctx.stopped || !iterationBest) break;
      bestMove = iterationBest; bestScore = iterationScore; pvMove = moveKey(bestMove); completedDepth=depth;
      // Reuse the transposition table between iterative-deepening passes.
    }
    lastSearchInfo = { depth: completedDepth, nodes: ctx.nodes, score: bestScore, engine: 'SLY Engine v2' };
    return bestMove;
  }

  const BOTS = [
    { id: 'pavel', name: 'Pavel', elo: 100, country: 'بولندا', countryEn: 'Poland', depth: 1, blunder: 0.55, noise: 320, style: 'يترك الفرص الواضحة ويلعب بعشوائية', styleEn: 'Leaves obvious chances and plays randomly' },
    { id: 'lucia', name: 'Lucía', elo: 200, country: 'إسبانيا', countryEn: 'Spain', depth: 1, blunder: 0.45, noise: 260, style: 'يحاول الهجوم لكن يخطئ كثيرًا', styleEn: 'Attacks often but makes many mistakes' },
    { id: 'noah', name: 'Noah', elo: 300, country: 'كندا', countryEn: 'Canada', depth: 1, blunder: 0.36, noise: 210, style: 'يلعب الأساسيات ويفوّت التهديدات', styleEn: 'Plays the basics and misses threats' },
    { id: 'yuki', name: 'Yuki', elo: 400, country: 'اليابان', countryEn: 'Japan', depth: 1, blunder: 0.27, noise: 170, style: 'يرى التهديدات المباشرة فقط', styleEn: 'Only sees direct threats' },
    { id: 'mateo', name: 'Mateo', elo: 500, country: 'الأرجنتين', countryEn: 'Argentina', depth: 2, blunder: 0.2, noise: 130, style: 'يطور القطع ويسيطر على الوسط', styleEn: 'Develops pieces and controls the center' },
    { id: 'amina', name: 'Amina', elo: 600, country: 'المغرب', countryEn: 'Morocco', depth: 2, blunder: 0.15, noise: 105, style: 'يلعب بهدوء ويقلل المخاطر', styleEn: 'Calm play, avoids risks' },
    { id: 'lars', name: 'Lars', elo: 700, country: 'النرويج', countryEn: 'Norway', depth: 2, blunder: 0.12, noise: 85, style: 'لعب مرتب مع بعض الأخطاء', styleEn: 'Tidy play with a few mistakes' },
    { id: 'maya', name: 'Maya', elo: 800, country: 'الهند', countryEn: 'India', depth: 2, blunder: 0.1, noise: 65, style: 'يسيطر على الوسط بشكل جيد', styleEn: 'Controls the center well' },
    { id: 'theo', name: 'Theo', elo: 900, country: 'فرنسا', countryEn: 'France', depth: 2, blunder: 0.07, noise: 50, style: 'تكتيكات أساسية ويلاحظ التهديدات', styleEn: 'Basic tactics, spots some threats' },
    { id: 'olga', name: 'Olga', elo: 1000, country: 'أوكرانيا', countryEn: 'Ukraine', depth: 2, blunder: 0.05, noise: 40, style: 'يبحث عن الأخذ المجاني', styleEn: 'Looks for free captures' },
    { id: 'daniel', name: 'Daniel', elo: 1100, country: 'بريطانيا', countryEn: 'United Kingdom', depth: 2, blunder: 0.04, noise: 35, style: 'لعب ثابت مع خطط بسيطة', styleEn: 'Solid play with simple plans' },
    { id: 'sofia', name: 'Sofia', elo: 1200, country: 'إيطاليا', countryEn: 'Italy', depth: 2, blunder: 0.03, noise: 30, style: 'تلعب بأمان وتستغل الأخطاء', styleEn: 'Plays safe and punishes errors' },
    { id: 'kenji', name: 'Kenji', elo: 1300, country: 'اليابان', countryEn: 'Japan', depth: 3, blunder: 0.02, noise: 25, style: 'خطط أفضل وأخطاء أقل', styleEn: 'Better plans, fewer mistakes' },
    { id: 'nour', name: 'Nour', elo: 1400, country: 'تونس', countryEn: 'Tunisia', depth: 3, blunder: 0.015, noise: 20, style: 'تنسيق جيد بين القطع', styleEn: 'Good coordination between pieces' },
    { id: 'carlos', name: 'Carlos', elo: 1500, country: 'المكسيك', countryEn: 'Mexico', depth: 3, blunder: 0.01, noise: 15, style: 'يلعب بثبات ويستغل الضعف', styleEn: 'Steady play, exploits weaknesses' },
    { id: 'erik', name: 'Erik', elo: 1600, country: 'السويد', countryEn: 'Sweden', depth: 3, blunder: 0.008, noise: 10, style: 'يخطط للمدى البعيد', styleEn: 'Plans for the long term' },
    { id: 'mila', name: 'Mila', elo: 1700, country: 'صربيا', countryEn: 'Serbia', depth: 3, blunder: 0.004, noise: 6, style: 'بحث تكتيكي قوي', styleEn: 'Strong tactical search' },
    { id: 'arjun', name: 'Arjun', elo: 1800, country: 'الهند', countryEn: 'India', depth: 3, blunder: 0, noise: 4, style: 'منافس قوي يرى الكمائن', styleEn: 'Strong opponent who sees traps' },
    { id: 'viktor', name: 'Viktor', elo: 1900, country: 'روسيا', countryEn: 'Russia', depth: 3, blunder: 0, noise: 2, style: 'قليل الأخطاء ويستغل كل فرصة', styleEn: 'Rarely errs and punishes every chance' },
    { id: 'roxy', name: 'Roxy', elo: 1900, country: 'بولندا', countryEn: 'Poland', depth: 3, blunder: 0, noise: 2, style: 'تلعب بهجوم سريع وتستغل كل خطأ', styleEn: 'Fast attacking play that punishes every error' },
    { id: 'kareem', name: 'Kareem', elo: 1980, country: 'السعودية', countryEn: 'Saudi Arabia', depth: 3, blunder: 0, noise: 3, style: 'أسلوب هجومي وضغط مستمر والبحث عن فرص التكتيك', styleEn: 'Aggressive play, constant pressure, and tactical chances' },
    { id: 'salman', name: 'Salman', elo: 2000, country: 'مصر', countryEn: 'Egypt', depth: 4, blunder: 0, noise: 0, style: 'أسلوب دفاعي صلب، يحمي القطع ويقلل المخاطر', styleEn: 'Solid defensive play, protects pieces, and minimizes risk' },
  ];

  function difficultyOf(elo) {
    if (elo <= 400) return 'diff_beginner';
    if (elo <= 800) return 'diff_easy';
    if (elo <= 1200) return 'diff_medium';
    if (elo <= 1600) return 'diff_good';
    if (elo <= 1900) return 'diff_strong';
    return 'diff_expert';
  }


  function chooseMove(bot, s) {
    const legal = CE.legalMoves(s);
    if (!legal.length) return null;
    if (Math.random() < (bot.blunder || 0)) return legal[Math.floor(Math.random()*legal.length)];
    const targetDepth = Math.max(1,Math.min(7,(bot.depth || 1) + (bot.elo >= 1700 ? 2 : bot.elo >= 1200 ? 1 : 0)));
    const maxNodes = bot.elo >= 1700 ? 65000 : bot.elo >= 1000 ? 42000 : 22000;
    const best = searchBestMove(s,targetDepth,maxNodes);
    return best || legal[0];
  }

  // Per-move review. The same upgraded search evaluates each legal candidate.
  function analyzeGame(states, moves, playerColor) {
    const details=[];
    for (let i=0;i<moves.length;i++) {
      const before=states[i]; if (before.turn!==playerColor) continue;
      const scored=scoreMoves(before,3);
      if (!scored.length) continue;
      scored.sort((a,b)=>b.score-a.score);
      const bestScore=scored[0].score, bestMove=scored[0].m;
      const played=scored.find(r=>r.m.f===moves[i].f && r.m.t===moves[i].t && (r.m.promo||'')===(moves[i].promo||''));
      const playedScore=played?played.score:bestScore;
      const cpl=Math.min(1000,Math.max(0,bestScore-playedScore));
      const acc=Math.max(0,Math.min(100,103.1*Math.exp(-0.004*cpl)-3.1));
      const grade=cpl<=10?'best':cpl<=50?'good':cpl<=100?'inaccuracy':cpl<=200?'mistake':'blunder';
      const after=CE.applyMove(before,moves[i]);
      details.push({cpl,acc,index:i,grade,playedSan:CE.san(before,moves[i]),bestSan:CE.san(before,bestMove),
        bestMove:{f:bestMove.f,t:bestMove.t,promo:bestMove.promo||''},beforeFen:CE.toFen(before),afterFen:CE.toFen(after),
        evalAfter:evaluate(after.b)*(playerColor==='w'?1:-1)});
    }
    const avg=details.length?details.reduce((a,d)=>a+d.acc,0)/details.length:0;
    return {accuracy:Math.round(avg*10)/10,blunders:details.filter(d=>d.grade==='blunder').length,
      mistakes:details.filter(d=>d.grade==='mistake').length,inaccuracies:details.filter(d=>d.grade==='inaccuracy').length,
      best:details.filter(d=>d.grade==='best').length,moves:details.length,details};
  }

  function getSearchInfo() { return Object.assign({},lastSearchInfo); }
  function clearSearchCache() { lastSearchInfo={depth:0,nodes:0,score:0,engine:'SLY Engine v2'}; }
  const api={BOTS,difficultyOf,chooseMove,scoreMoves,analyzeGame,evaluate,MATE,getSearchInfo,clearSearchCache};
  if(typeof module!=='undefined'&&module.exports) module.exports=api;
  root.ChessBots=api;
})(typeof window!=='undefined'?window:globalThis);
