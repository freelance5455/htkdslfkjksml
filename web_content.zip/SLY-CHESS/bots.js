/* CHESS ARENA - opponents + minimax/alpha-beta search.
 * Strength levels are approximate and internal to the game (not Chess.com-calibrated).
 */
(function (root) {
  'use strict';
  const CE = root.ChessEngine || (typeof require !== 'undefined' ? require('./chess-engine.js') : null);
  const MATE = 100000;
  const VAL = { p: 100, n: 320, b: 330, r: 500, q: 900, k: 0 };

  const PST = {
    p: [0,0,0,0,0,0,0,0, 50,50,50,50,50,50,50,50, 10,10,20,30,30,20,10,10, 5,5,10,25,25,10,5,5,
        0,0,0,20,20,0,0,0, 5,-5,-10,0,0,-10,-5,5, 5,10,10,-20,-20,10,10,5, 0,0,0,0,0,0,0,0],
    n: [-50,-40,-30,-30,-30,-30,-40,-50, -40,-20,0,0,0,0,-20,-40, -30,0,10,15,15,10,0,-30, -30,5,15,20,20,15,5,-30,
        -30,0,15,20,20,15,0,-30, -30,5,10,15,15,10,5,-30, -40,-20,0,5,5,0,-20,-40, -50,-40,-30,-30,-30,-30,-40,-50],
    b: [-20,-10,-10,-10,-10,-10,-10,-20, -10,0,0,0,0,0,0,-10, -10,0,5,10,10,5,0,-10, -10,5,5,10,10,5,5,-10,
        -10,0,10,10,10,10,0,-10, -10,10,10,10,10,10,10,-10, -10,5,0,0,0,0,5,-10, -20,-10,-10,-10,-10,-10,-10,-20],
    r: [0,0,0,0,0,0,0,0, 5,10,10,10,10,10,10,5, -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5,
        -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5, 0,0,0,5,5,0,0,0],
    q: [-20,-10,-10,-5,-5,-10,-10,-20, -10,0,0,0,0,0,0,-10, -10,0,5,5,5,5,0,-10, -5,0,5,5,5,5,0,-5,
        0,0,5,5,5,5,0,-5, -10,5,5,5,5,5,0,-10, -10,0,5,0,0,0,0,-10, -20,-10,-10,-5,-5,-10,-10,-20],
    k: [-30,-40,-40,-50,-50,-40,-40,-30, -30,-40,-40,-50,-50,-40,-40,-30, -30,-40,-40,-50,-50,-40,-40,-30,
        -30,-40,-40,-50,-50,-40,-40,-30, -20,-30,-30,-40,-40,-30,-30,-20, -10,-20,-20,-20,-20,-20,-20,-10,
        20,20,0,0,0,0,20,20, 20,30,10,0,0,10,30,20],
  };

  // static evaluation in centipawns from WHITE's point of view
  function evaluate(b) {
    let sc = 0;
    for (let sq = 0; sq < 64; sq++) {
      const p = b[sq];
      if (!p) continue;
      const t = p.toLowerCase();
      const isW = p === p.toUpperCase();
      const r = sq >> 3, f = sq & 7;
      const idx = isW ? (7 - r) * 8 + f : r * 8 + f;
      const v = VAL[t] + PST[t][idx];
      sc += isW ? v : -v;
    }
    return sc;
  }

  const sign = (s) => (s.turn === 'w' ? 1 : -1);

  function quiesce(s, alpha, beta, qd) {
    const stand = sign(s) * evaluate(s.b);
    if (stand >= beta) return stand;
    if (stand > alpha) alpha = stand;
    if (qd > 4) return stand;
    const caps = CE.legalMoves(s).filter((m) => m.cap || m.promo);
    caps.sort((a, b) => (VAL[s.b[b.t]?.toLowerCase()] || 0) - (VAL[s.b[a.t]?.toLowerCase()] || 0));
    for (const m of caps) {
      const score = -quiesce(CE.applyMove(s, m), -beta, -alpha, qd + 1);
      if (score >= beta) return score;
      if (score > alpha) alpha = score;
    }
    return alpha;
  }

  function order(s, moves) {
    return moves.slice().sort((a, b) => {
      const va = (a.cap ? VAL[s.b[a.t]?.toLowerCase()] || 100 : 0) + (a.promo ? 800 : 0);
      const vb = (b.cap ? VAL[s.b[b.t]?.toLowerCase()] || 100 : 0) + (b.promo ? 800 : 0);
      return vb - va;
    });
  }

  function negamax(s, depth, alpha, beta, ply) {
    if (s.half >= 100) return 0;
    const moves = CE.legalMoves(s);
    if (moves.length === 0) {
      return CE.inCheck(s, s.turn) ? -(MATE - ply) : 0;
    }
    if (depth <= 0) return quiesce(s, alpha, beta, 0);
    let best = -Infinity;
    for (const m of order(s, moves)) {
      const score = -negamax(CE.applyMove(s, m), depth - 1, -beta, -alpha, ply + 1);
      if (score > best) best = score;
      if (best > alpha) alpha = best;
      if (alpha >= beta) break;
    }
    return best;
  }

  // score every legal root move (side to move perspective)
  function scoreMoves(s, depth) {
    const res = [];
    let alpha = -Infinity;
    for (const m of order(s, CE.legalMoves(s))) {
      const child = CE.applyMove(s, m);
      const sc = -negamax(child, depth - 1, -Infinity, -alpha === Infinity ? Infinity : -alpha, 1);
      res.push({ m, score: sc });
      if (sc > alpha) alpha = sc;
    }
    return res;
  }

  // Bot roster. depth = search depth, blunder = chance to play a random legal move,
  // noise = random centipawn jitter on root scores (weaker = sloppier).
  const BOTS = [
    { id: 'pavel', name: 'Pavel', elo: 100, country: 'بولندا', countryEn: 'Poland', depth: 1, blunder: 0.55, noise: 320, style: 'يترك الفرص الواضحة ويلعب بعشوائية', styleEn: 'Leaves obvious chances and plays randomly' },
    { id: 'lucia', name: 'Lucía', elo: 200, country: 'إسبانيا', countryEn: 'Spain', depth: 1, blunder: 0.45, noise: 260, style: 'يحاول الهجوم لكن يخطئ كثيرًا', styleEn: 'Attacks often but makes many mistakes' },
    { id: 'noah', name: 'Noah', elo: 300, country: 'كندا', countryEn: 'Canada', depth: 1, blunder: 0.36, noise: 210, style: 'يلعب الأساسيات ويفوّت التهديدات', styleEn: 'Plays the basics and misses threats' },
    { id: 'yuki', name: 'Yuki', elo: 400, country: 'اليابان', countryEn: 'Japan', depth: 1, blunder: 0.27, noise: 170, style: 'يرى التهديدات المباشرة فقط', styleEn: 'Only sees direct threats' },
    { id: 'mateo', name: 'Mateo', elo: 500, country: 'الأرجنتين', countryEn: 'Argentina', depth: 2, blunder: 0.2, noise: 130, style: 'يطور القطع ويسيطر على الوسط', styleEn: 'Develops pieces and controls the center' },
    { id: 'amina', name: 'Amina', elo: 600, country: 'المغرب', countryEn: 'Morocco', depth: 2, blunder: 0.15, noise: 105, style: 'يلعب بهدوء ويقلل المخاطر', styleEn: 'Calm play, avoids risks' },
    { id: 'lars', name: 'Lars', elo: 700, country: 'النرويج', countryEn: 'Norway', depth: 2, blunder: 0.12, noise: 85, style: 'لعب مرتب مع بعض الأخطاء', styleEn: 'Tidy play with a few mistakes' },
    { id: 'maya', name: 'Maya', elo: 800, country: 'الهند', countryEn: 'India', depth: 2, blunder: 0.1, noise: 65, style: 'يسيطر على الوسط بشكل جيد', styleEn: 'Controls the center well' },
    { id: 'theo', name: 'Theo', elo: 900, country: 'فرنسا', countryEn: 'France', depth: 2, blunder: 0.07, noise: 50, style: 'تكتيكات أساسية ويلاحظ التهديدات', styleEn: 'Basic tactics, spots some threats' },
    { id: 'olga', name: 'Olga', elo: 1000, country: 'أوكرانيا', countryEn: 'Ukraine', depth: 2, blunder: 0.05, noise: 40, style: 'يبحث عن الأخذ المجاني', styleEn: 'Looks for free captures' },
    { id: 'daniel', name: 'Daniel', elo: 1100, country: 'بريطانيا', countryEn: 'United Kingdom', depth: 2, blunder: 0.04, noise: 35, style: 'لعب ثابت مع خطط بسيطة', styleEn: 'Solid play with simple plans' },
    { id: 'sofia', name: 'Sofia', elo: 1200, country: 'إيطاليا', countryEn: 'Italy', depth: 2, blunder: 0.03, noise: 30, style: 'تلعب بأمان وتستغل الأخطاء', styleEn: 'Plays safe and punishes errors' },
    { id: 'kenji', name: 'Kenji', elo: 1300, country: 'اليابان', countryEn: 'Japan', depth: 3, blunder: 0.02, noise: 25, style: 'خطط أفضل وأخطاء أقل', styleEn: 'Better plans, fewer mistakes' },
    { id: 'nour', name: 'Nour', elo: 1400, country: 'تونس', countryEn: 'Tunisia', depth: 3, blunder: 0.015, noise: 20, style: 'تنسيق جيد بين القطع', styleEn: 'Good coordination between pieces' },
    { id: 'carlos', name: 'Carlos', elo: 1500, country: 'المكسيك', countryEn: 'Mexico', depth: 3, blunder: 0.01, noise: 15, style: 'يلعب بثبات ويستغل الضعف', styleEn: 'Steady play, exploits weaknesses' },
    { id: 'erik', name: 'Erik', elo: 1600, country: 'السويد', countryEn: 'Sweden', depth: 3, blunder: 0.008, noise: 10, style: 'يخطط للمدى البعيد', styleEn: 'Plans for the long term' },
    { id: 'mila', name: 'Mila', elo: 1700, country: 'صربيا', countryEn: 'Serbia', depth: 3, blunder: 0.004, noise: 6, style: 'بحث تكتيكي قوي', styleEn: 'Strong tactical search' },
    { id: 'arjun', name: 'Arjun', elo: 1800, country: 'الهند', countryEn: 'India', depth: 3, blunder: 0, noise: 4, style: 'منافس قوي يرى الكمائن', styleEn: 'Strong opponent who sees traps' },
    { id: 'viktor', name: 'Viktor', elo: 1900, country: 'روسيا', countryEn: 'Russia', depth: 3, blunder: 0, noise: 2, style: 'قليل الأخطاء ويستغل كل فرصة', styleEn: 'Rarely errs and punishes every chance' },
    { id: 'roxy', name: 'Roxy', elo: 1900, country: 'بولندا', countryEn: 'Poland', depth: 3, blunder: 0, noise: 2, style: 'تلعب بهجوم سريع وتستغل كل خطأ', styleEn: 'Fast attacking play that punishes every error' },
    { id: 'kareem', name: 'Kareem', elo: 1980, country: 'السعودية', countryEn: 'Saudi Arabia', depth: 3, blunder: 0, noise: 3, style: 'لعب هادئ ومنظم يبحث عن الفرص المتأخرة', styleEn: 'Calm, organized play that waits for late chances' },
    { id: 'salman', name: 'Salman', elo: 2000, country: 'مصر', countryEn: 'Egypt', depth: 4, blunder: 0, noise: 0, style: 'أقوى منافس في اللعبة', styleEn: 'The strongest opponent in the game' },
  ];

  function difficultyOf(elo) {
    if (elo <= 400) return 'diff_beginner';
    if (elo <= 800) return 'diff_easy';
    if (elo <= 1200) return 'diff_medium';
    if (elo <= 1600) return 'diff_good';
    if (elo <= 1900) return 'diff_strong';
    return 'diff_expert';
  }

  // choose a move for bot config `bot` in state `s`
  function chooseMove(bot, s) {
    const legal = CE.legalMoves(s);
    if (!legal.length) return null;
    if (Math.random() < bot.blunder) return legal[Math.floor(Math.random() * legal.length)];
    const scored = scoreMoves(s, bot.depth);
    let best = null, bestVal = -Infinity;
    for (const r of scored) {
      const j = bot.noise ? (Math.random() * 2 - 1) * bot.noise : 0;
      const v = r.score + j;
      if (v > bestVal) { bestVal = v; best = r.m; }
    }
    return best;
  }

  // Post-game analysis: centipawn loss per player move (approximate, depth-2 search)
  function analyzeGame(states, moves, playerColor) {
    const details = [];
    for (let i = 0; i < moves.length; i++) {
      const before = states[i];
      if (before.turn !== playerColor) continue;
      const scored = scoreMoves(before, 2);
      if (!scored.length) continue;
      const bestScore = Math.max(...scored.map((r) => r.score));
      const played = scored.find((r) => r.m.f === moves[i].f && r.m.t === moves[i].t && (r.m.promo || '') === (moves[i].promo || ''));
      const playedScore = played ? played.score : bestScore;
      const cpl = Math.min(1000, Math.max(0, bestScore - playedScore));
      const acc = Math.max(0, Math.min(100, 103.1 * Math.exp(-0.004 * cpl) - 3.1));
      details.push({ cpl, acc, index: i });
    }
    const avgAcc = details.length ? details.reduce((a, d) => a + d.acc, 0) / details.length : 0;
    return {
      accuracy: Math.round(avgAcc * 10) / 10,
      blunders: details.filter((d) => d.cpl >= 200).length,
      mistakes: details.filter((d) => d.cpl >= 100 && d.cpl < 200).length,
      inaccuracies: details.filter((d) => d.cpl >= 50 && d.cpl < 100).length,
      best: details.filter((d) => d.cpl <= 10).length,
      moves: details.length,
    };
  }

  const api = { BOTS, difficultyOf, chooseMove, scoreMoves, analyzeGame, evaluate, MATE };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.ChessBots = api;
})(typeof window !== 'undefined' ? window : globalThis);
