# SLY CHESS

Web chess game with 20 bot opponents (100 to 2000 ELO). Plain HTML, CSS and JavaScript. No build step.

## How to run
1. Unzip the project.
2. Open `index.html` in a browser. For the smoothest experience (and to avoid any local file restrictions), serve the folder:
   - `python3 -m http.server 8000` then open http://localhost:8000
3. Works on desktop and phone. Mouse, touch and drag-to-move are all supported.

## Files
- `index.html`: screens (home, opponent select, game, result)
- `style.css`: dark theme, olive/cream board, gold accents, responsive layout
- `script.js`: UI, board rendering, drag/tap input, game flow, rating, result screen
- `i18n.js`: Arabic and English interface strings
- `chess-engine.js`: full rules engine (castling, en passant, promotion, check/mate, stalemate, 50-move, repetition, insufficient material)
- `bots.js`: 20 opponents, minimax with alpha-beta and quiescence, post-game accuracy analysis
- `sound.js`: synthesized sound effects via Web Audio API (no audio files needed)
- `assets/pieces/`: chess pieces cut from the supplied board image (white and black, PNG with transparency)
- `assets/avatars/`: 20 player portraits cut from the supplied group image, one per bot
- `assets/flags/`: flags of each bot's country

## Notes
- Opponent levels are approximate and internal to the game. They are not calibrated to Chess.com.
- Accuracy is a rough estimate from a shallow depth-2 search. It is not a full engine analysis.
- Your rating starts at 400 and is saved in your browser (localStorage). It uses a K-factor of 32.
- Leaving or starting a new game mid-match counts as a resignation.
- Sounds are generated in the browser, so there is no `assets/sounds` folder to download.
