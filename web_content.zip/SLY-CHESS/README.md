# SLY CHESS

Web chess game with 22 bot opponents (100 to 2000 ELO labels). Plain HTML, CSS and JavaScript. No build step and no external chess-engine binaries required.

## How to run
1. Unzip the project.
2. Open `index.html` in a browser. For the smoothest experience, serve the folder from any static host.
3. Works on desktop and phone. Mouse, touch and drag-to-move are supported.

## Engine: SLY Engine v2
The game now uses its own local JavaScript engine for all bot moves. It does not require Stockfish, WASM files, an internet connection, or a Worker. Improvements include:
- Iterative deepening, so the engine keeps the best completed search if it reaches its node budget.
- Transposition table to reuse previously searched positions.
- Better move ordering using captures, promotions, transposition-table moves, killer moves and history scores.
- Alpha-beta negamax with quiescence search; quiescence searches all legal evasions when in check.
- Improved positional evaluation: piece-square tables, bishop pair, pawn structure, passed pawns, rook files and king activity in simplified endings.
- Node budgets tuned by opponent level to keep browser play responsive.

The displayed opponent ELO values are game difficulty labels, not independently measured or Chess.com-calibrated ratings. This is a meaningful upgrade to the previous lightweight engine, but it is not claimed to match Stockfish.

## Files
- `index.html` / `SLY-CHESS.html`: game screens
- `style.css`: responsive interface and board styling
- `script.js`: UI, board rendering, game flow, rating and analysis screens
- `chess-engine.js`: chess rules (castling, en passant, promotion, check/mate, stalemate, 50-move, repetition, insufficient material)
- `bots.js`: 22 opponents and SLY Engine v2 search/evaluation
- `i18n.js`: Arabic and English interface strings
- `puzzles.js`: puzzles
- `sound.js`: synthesized sound effects
- `assets/`: piece, avatar and flag images

## Post-game analysis
After a bot game ends, use the **تحليل المباراة / Game analysis** button on the result panel to review your moves. It reports approximate accuracy, move grades, centipawn loss and a suggested alternative. Analysis uses the in-house engine at a limited depth, so it is educational guidance rather than professional engine analysis.

## Notes
- Your rating and preferences are saved in the browser's local storage.
- The game is fully local after the files are downloaded.
