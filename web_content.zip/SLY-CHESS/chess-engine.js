/* CHESS ARENA - rules engine (no external deps)
 * Board: array of 64 chars. index = rank*8 + file, a1 = 0, h8 = 63.
 * White pieces uppercase (PNBRQK), black lowercase. '' = empty.
 * Supports: all piece moves, captures, check, checkmate, stalemate,
 * castling, en passant, promotion, 50-move rule, threefold repetition,
 * insufficient material.
 */
(function (root) {
  'use strict';
  const FILES = 'abcdefgh';
  const KN = [[1, 2], [2, 1], [-1, 2], [-2, 1], [1, -2], [2, -1], [-1, -2], [-2, -1]];
  const KG = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
  const DIAG = [[1, 1], [1, -1], [-1, 1], [-1, -1]];
  const ORTH = [[1, 0], [-1, 0], [0, 1], [0, -1]];
  const START_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

  const sqFromAlg = (s) => (s.charCodeAt(1) - 49) * 8 + (s.charCodeAt(0) - 97);
  const algOf = (i) => FILES[i & 7] + ((i >> 3) + 1);
  const isWhitePiece = (c) => !!c && c === c.toUpperCase();
  const colorOf = (c) => (isWhitePiece(c) ? 'w' : 'b');

  function fromFen(fen) {
    const p = fen.trim().split(/\s+/);
    const b = new Array(64).fill('');
    const rows = p[0].split('/');
    for (let r = 0; r < 8; r++) {
      let f = 0;
      for (const ch of rows[7 - r]) {
        if (/\d/.test(ch)) f += +ch;
        else { b[r * 8 + f] = ch; f++; }
      }
    }
    return {
      b,
      turn: p[1] || 'w',
      cr: (p[2] || '-') === '-' ? '' : p[2],
      ep: p[3] && p[3] !== '-' ? sqFromAlg(p[3]) : -1,
      half: +(p[4] || 0),
      full: +(p[5] || 1),
    };
  }

  function toFen(s) {
    let out = '';
    for (let r = 7; r >= 0; r--) {
      let e = 0, row = '';
      for (let f = 0; f < 8; f++) {
        const c = s.b[r * 8 + f];
        if (!c) e++;
        else { if (e) { row += e; e = 0; } row += c; }
      }
      if (e) row += e;
      out += row + (r ? '/' : '');
    }
    return `${out} ${s.turn} ${s.cr || '-'} ${s.ep >= 0 ? algOf(s.ep) : '-'} ${s.half} ${s.full}`;
  }

  function newGame() { return fromFen(START_FEN); }

  // is square sq attacked by color 'by'?
  function isAttacked(b, sq, by) {
    const f = sq & 7, r = sq >> 3;
    const pr = by === 'w' ? r - 1 : r + 1;
    const pawn = by === 'w' ? 'P' : 'p';
    if (pr >= 0 && pr < 8) {
      for (const df of [-1, 1]) {
        const pf = f + df;
        if (pf >= 0 && pf < 8 && b[pr * 8 + pf] === pawn) return true;
      }
    }
    const N = by === 'w' ? 'N' : 'n', K = by === 'w' ? 'K' : 'k';
    const B = by === 'w' ? 'B' : 'b', R = by === 'w' ? 'R' : 'r', Q = by === 'w' ? 'Q' : 'q';
    for (const [df, dr] of KN) {
      const ff = f + df, rr = r + dr;
      if (ff >= 0 && ff < 8 && rr >= 0 && rr < 8 && b[rr * 8 + ff] === N) return true;
    }
    for (const [df, dr] of KG) {
      const ff = f + df, rr = r + dr;
      if (ff >= 0 && ff < 8 && rr >= 0 && rr < 8 && b[rr * 8 + ff] === K) return true;
    }
    for (const [dirs, a, c] of [[DIAG, B, Q], [ORTH, R, Q]]) {
      for (const [df, dr] of dirs) {
        let ff = f + df, rr = r + dr;
        while (ff >= 0 && ff < 8 && rr >= 0 && rr < 8) {
          const p = b[rr * 8 + ff];
          if (p) { if (p === a || p === c) return true; break; }
          ff += df; rr += dr;
        }
      }
    }
    return false;
  }

  function kingSq(b, color) { return b.indexOf(color === 'w' ? 'K' : 'k'); }

  function inCheck(s, color) {
    const k = kingSq(s.b, color);
    if (k < 0) return false;
    return isAttacked(s.b, k, color === 'w' ? 'b' : 'w');
  }

  // pseudo-legal moves (may leave own king in check)
  function pseudo(s) {
    const out = [];
    const b = s.b, us = s.turn, them = us === 'w' ? 'b' : 'w';
    const isUs = (c) => !!c && colorOf(c) === us;
    const isThem = (c) => !!c && colorOf(c) !== us;
    for (let sq = 0; sq < 64; sq++) {
      const p = b[sq];
      if (!p || !isUs(p)) continue;
      const t = p.toLowerCase();
      const f = sq & 7, r = sq >> 3;
      if (t === 'p') {
        const dir = us === 'w' ? 1 : -1;
        const startR = us === 'w' ? 1 : 6;
        const promoR = us === 'w' ? 7 : 0;
        const nr = r + dir;
        if (nr < 0 || nr > 7) continue;
        const pushPawn = (from, to, cap, ep) => {
          if ((to >> 3) === promoR) {
            for (const pr of ['q', 'r', 'b', 'n']) out.push({ f: from, t: to, promo: pr, cap: !!cap, ep: !!ep });
          } else out.push({ f: from, t: to, cap: !!cap, ep: !!ep });
        };
        const one = nr * 8 + f;
        if (!b[one]) {
          pushPawn(sq, one, false, false);
          if (r === startR && !b[one + 8 * dir]) out.push({ f: sq, t: one + 8 * dir, dbl: true });
        }
        for (const df of [-1, 1]) {
          const ff = f + df;
          if (ff < 0 || ff > 7) continue;
          const to = nr * 8 + ff;
          if (isThem(b[to])) pushPawn(sq, to, true, false);
          else if (to === s.ep) pushPawn(sq, to, true, true);
        }
      } else if (t === 'n' || t === 'k') {
        const offs = t === 'n' ? KN : KG;
        for (const [df, dr] of offs) {
          const ff = f + df, rr = r + dr;
          if (ff < 0 || ff > 7 || rr < 0 || rr > 7) continue;
          const to = rr * 8 + ff;
          if (!isUs(b[to])) out.push({ f: sq, t: to, cap: !!b[to] });
        }
        if (t === 'k') {
          const homeR = us === 'w' ? 0 : 7;
          if (sq === homeR * 8 + 4 && !isAttacked(b, sq, them)) {
            const K = us === 'w' ? 'K' : 'k', Q = us === 'w' ? 'Q' : 'q', R = us === 'w' ? 'R' : 'r';
            const base = homeR * 8;
            if (s.cr.includes(K) && b[base + 7] === R && !b[base + 5] && !b[base + 6] &&
                !isAttacked(b, base + 5, them) && !isAttacked(b, base + 6, them)) {
              out.push({ f: sq, t: base + 6, castle: 'k' });
            }
            if (s.cr.includes(Q) && b[base] === R && !b[base + 1] && !b[base + 2] && !b[base + 3] &&
                !isAttacked(b, base + 3, them) && !isAttacked(b, base + 2, them)) {
              out.push({ f: sq, t: base + 2, castle: 'q' });
            }
          }
        }
      } else {
        const dirs = t === 'b' ? DIAG : t === 'r' ? ORTH : DIAG.concat(ORTH);
        for (const [df, dr] of dirs) {
          let ff = f + df, rr = r + dr;
          while (ff >= 0 && ff < 8 && rr >= 0 && rr < 8) {
            const to = rr * 8 + ff;
            if (isUs(b[to])) break;
            out.push({ f: sq, t: to, cap: !!b[to] });
            if (b[to]) break;
            ff += df; rr += dr;
          }
        }
      }
    }
    return out;
  }

  function applyMove(s, m) {
    const b = s.b.slice();
    const us = s.turn;
    const piece = b[m.f];
    const t = piece.toLowerCase();
    let captured = b[m.t];
    b[m.t] = piece;
    b[m.f] = '';
    if (m.ep) {
      const capSq = m.t + (us === 'w' ? -8 : 8);
      captured = b[capSq];
      b[capSq] = '';
    }
    if (m.castle) {
      const base = (m.f >> 3) * 8;
      if (m.castle === 'k') { b[base + 5] = b[base + 7]; b[base + 7] = ''; }
      else { b[base + 3] = b[base]; b[base] = ''; }
    }
    if (m.promo) b[m.t] = us === 'w' ? m.promo.toUpperCase() : m.promo;
    let cr = s.cr;
    const strip = (chars) => { for (const c of chars) cr = cr.replace(c, ''); };
    if (t === 'k') strip(us === 'w' ? 'KQ' : 'kq');
    for (const sq of [m.f, m.t]) {
      if (sq === 0) strip('Q');
      else if (sq === 7) strip('K');
      else if (sq === 56) strip('q');
      else if (sq === 63) strip('k');
    }
    return {
      b,
      turn: us === 'w' ? 'b' : 'w',
      cr,
      ep: m.dbl ? (m.f + m.t) >> 1 : -1,
      half: t === 'p' || captured ? 0 : s.half + 1,
      full: us === 'b' ? s.full + 1 : s.full,
    };
  }

  function legalMoves(s) {
    const res = [];
    for (const m of pseudo(s)) {
      const n = applyMove(s, m);
      if (!isAttacked(n.b, kingSq(n.b, s.turn), s.turn === 'w' ? 'b' : 'w')) res.push(m);
    }
    return res;
  }

  function insufficientMaterial(b) {
    const minors = [];
    for (const c of b) {
      if (!c || c === 'K' || c === 'k') continue;
      const t = c.toLowerCase();
      if (t === 'p' || t === 'r' || t === 'q') return false;
      minors.push(c);
    }
    if (minors.length <= 1) return true;
    // all bishops on same colour
    if (minors.every((c) => c.toLowerCase() === 'b')) {
      let colors = new Set();
      b.forEach((c, i) => { if (c && c.toLowerCase() === 'b') colors.add(((i >> 3) + (i & 7)) % 2); });
      return colors.size === 1;
    }
    return false;
  }

  function posKey(s) { return s.b.join('') + s.turn + s.cr + s.ep; }

  // status: { over, result, winner, check, moves }
  // history: array of posKey strings of previous positions (optional)
  function status(s, history) {
    const moves = legalMoves(s);
    const check = inCheck(s, s.turn);
    if (moves.length === 0) {
      return check
        ? { over: true, result: 'checkmate', winner: s.turn === 'w' ? 'b' : 'w', check, moves }
        : { over: true, result: 'stalemate', winner: null, check, moves };
    }
    if (s.half >= 100) return { over: true, result: 'draw50', winner: null, check, moves };
    if (insufficientMaterial(s.b)) return { over: true, result: 'insufficient', winner: null, check, moves };
    if (history) {
      const key = posKey(s);
      let n = 0;
      for (const k of history) if (k === key) n++;
      if (n >= 2) return { over: true, result: 'repetition', winner: null, check, moves };
    }
    return { over: false, result: null, winner: null, check, moves };
  }

  // SAN notation for move m played from s
  function san(s, m) {
    const piece = s.b[m.f];
    const t = piece.toLowerCase();
    let out;
    if (m.castle) out = m.castle === 'k' ? 'O-O' : 'O-O-O';
    else {
      const cap = !!s.b[m.t] || m.ep;
      if (t === 'p') {
        out = cap ? FILES[m.f & 7] + 'x' : '';
        out += algOf(m.t);
        if (m.promo) out += '=' + m.promo.toUpperCase();
      } else {
        out = t.toUpperCase();
        const others = legalMoves(s).filter((x) => x.f !== m.f && x.t === m.t && s.b[x.f] === piece);
        if (others.length) {
          const sameFile = others.some((x) => (x.f & 7) === (m.f & 7));
          const sameRank = others.some((x) => (x.f >> 3) === (m.f >> 3));
          if (!sameFile) out += FILES[m.f & 7];
          else if (!sameRank) out += String((m.f >> 3) + 1);
          else out += algOf(m.f);
        }
        if (cap) out += 'x';
        out += algOf(m.t);
      }
    }
    const after = applyMove(s, m);
    if (inCheck(after, after.turn)) out += legalMoves(after).length ? '+' : '#';
    return out;
  }

  function findMove(s, from, to, promo) {
    return legalMoves(s).find((m) => m.f === from && m.t === to && (!m.promo || m.promo === (promo || 'q')));
  }

  function perft(s, d) {
    if (d === 0) return 1;
    let n = 0;
    for (const m of legalMoves(s)) n += perft(applyMove(s, m), d - 1);
    return n;
  }

  const api = {
    FILES, START_FEN, fromFen, toFen, newGame, isAttacked, inCheck, pseudo,
    applyMove, legalMoves, status, san, findMove, perft, posKey, algOf, sqFromAlg,
    colorOf, insufficientMaterial,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.ChessEngine = api;
})(typeof window !== 'undefined' ? window : globalThis);
