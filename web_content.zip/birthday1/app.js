
const btnYok = document.querySelector(".yok");
const btn_howa = document.querySelector(".btn_howa");
const main_box = document.querySelector(".main-box");
const hitten = document.querySelector(".hitten");

const bodyy = document.querySelector(".main-box");
 
btnYok.addEventListener("click", (e) => {
    const maxWidth = window.innerWidth - btnYok.offsetWidth - 20;
    const maxHeight = window.innerHeight - btnYok.offsetHeight - 20;
    
    const randomX = Math.max(10, Math.floor(Math.random() * maxWidth));
    const randomY = Math.max(10, Math.floor(Math.random() * maxHeight));
    
    btnYok.style.position = "absolute";
    btnYok.style.left = `${randomX}px`;
    btnYok.style.top = `${randomY}px`;
});

btn_howa.addEventListener("click", (e) => {
    bodyy.className = "hitten";
    hitten.className = "init";
    hitten.className = "main-box";
});