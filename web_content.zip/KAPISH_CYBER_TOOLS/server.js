const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=process.env.PORT||3000, ROOT=__dirname, DATA=path.join(ROOT,'data.json');
const PASSWORD=process.env.ADMIN_PASSWORD||'change-this-password'; let tools=load(), clients=new Set();
function load(){try{return JSON.parse(fs.readFileSync(DATA,'utf8'))}catch{return []}}
function save(){fs.writeFileSync(DATA,JSON.stringify(tools,null,2));broadcast()}
function send(res,status,obj,type='application/json'){res.writeHead(status,{'Content-Type':type,'Cache-Control':'no-store','Access-Control-Allow-Origin':'*'});res.end(type.includes('json')?JSON.stringify(obj):obj)}
function body(req){return new Promise((ok,no)=>{let d='';req.on('data',c=>d+=c);req.on('end',()=>{try{ok(d?JSON.parse(d):{})}catch(e){no(e)}});req.on('error',no)})}
function authorized(req,b){let t=(req.headers.authorization||'').replace(/^Bearer\s+/,'')||b.password||'';let a=Buffer.from(t),c=Buffer.from(PASSWORD);return a.length===c.length&&crypto.timingSafeEqual(a,c)}
function broadcast(){let msg='data: '+JSON.stringify(tools)+'\n\n';for(const r of clients){try{r.write(msg)}catch{clients.delete(r)}}}
const server=http.createServer(async(req,res)=>{let u=new URL(req.url,'http://localhost');
 if(u.pathname==='/api/tools'&&req.method==='GET')return send(res,200,tools);
 if(u.pathname==='/api/stream'&&req.method==='GET'){res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive','Access-Control-Allow-Origin':'*'});res.write('retry: 1000\n\n');res.write('data: '+JSON.stringify(tools)+'\n\n');clients.add(res);req.on('close',()=>clients.delete(res));return}
 if(u.pathname==='/api/tools'&&req.method==='POST'){let b=await body(req).catch(()=>null);if(!b)return send(res,400,{error:'Invalid JSON'});if(!authorized(req,b))return send(res,401,{error:'Unauthorized'});if(!b.tool?.name)return send(res,400,{error:'Tool name required'});tools.push(b.tool);save();return send(res,201,b.tool)}
 let m=u.pathname.match(/^\/api\/tools\/(\d+)$/);if(m&&(req.method==='PUT'||req.method==='DELETE')){let b=await body(req).catch(()=>null)||{};if(!authorized(req,b))return send(res,401,{error:'Unauthorized'});let i=+m[1];if(i<0||i>=tools.length)return send(res,404,{error:'Not found'});if(req.method==='DELETE')tools.splice(i,1);else{if(!b.tool?.name)return send(res,400,{error:'Tool name required'});tools[i]=b.tool}save();return send(res,200,{ok:true,tool:tools[i]})}
 let f=u.pathname==='/'?'/index.html':decodeURIComponent(u.pathname),full=path.normalize(path.join(ROOT,f));if(!full.startsWith(ROOT))return send(res,403,'Forbidden','text/plain');
 fs.readFile(full,(e,d)=>{if(e)return send(res,404,'Not found','text/plain');let ext=path.extname(full),mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.txt':'text/plain'}[ext]||'application/octet-stream';res.writeHead(200,{'Content-Type':mime,'Cache-Control':'no-cache'});res.end(d)})
});server.listen(PORT,()=>console.log('KAPISH CYBER LIVE on port '+PORT));
