#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js nahi mila. Pehle: pkg update && pkg install nodejs"
  exit 1
fi
if [ -z "${ADMIN_PASSWORD:-}" ]; then
  printf "Admin password set karo: "
  read -r ADMIN_PASSWORD
  export ADMIN_PASSWORD
fi
export PORT="${PORT:-3000}"
echo
node server.js
