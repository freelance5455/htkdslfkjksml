KAPISH CYBER — LIVE ADMIN EDITION

This version uses a real server-side data.json file instead of browser LocalStorage.
Admin Add/Edit/Delete updates the public website, and open pages receive the change live through SSE.

LOCAL TEST (Termux/PC):
1. Install Node.js.
2. cd into KAPISH_CYBER_TOOLS.
3. Run: node server.js
4. Open http://localhost:3000/
5. Admin: http://localhost:3000/admin.html
6. Set a real password before deployment: ADMIN_PASSWORD=your-strong-password node server.js

ONLINE:
Deploy this folder on a Node.js hosting service. Set ADMIN_PASSWORD as a server environment variable and use HTTPS.
Do not publish the password in HTML/JS.

Original catalog: 221 real cybersecurity tool entries.
