const express = require('express');
const authController = require('../controllers/authController');
const transactionController = require('../controllers/transactionController');
const jobController = require('../controllers/jobController');
const { authenticate, requireAdmin } = require('../middleware/auth');

const router = express.Router();

// ========== AUTH ==========
router.post('/auth/register', authController.register);
router.post('/auth/login', authController.login);
router.get('/auth/me', authenticate, authController.me);
router.post('/auth/logout', authenticate, authController.logout);

// ========== TRANSACTIONS / TOP-UP ==========
router.get('/transactions/packages', authenticate, transactionController.getPackages);
router.post('/transactions/create', authenticate, transactionController.createTransaction);
router.post('/transactions/:id/confirm', authenticate, transactionController.confirmTransfer);
router.get('/transactions/my', authenticate, transactionController.myTransactions);

// Admin top-up dashboard
router.get('/admin/transactions/pending', authenticate, requireAdmin, transactionController.adminPendingList);
router.post('/admin/transactions/:id/approve', authenticate, requireAdmin, transactionController.adminApprove);
router.post('/admin/transactions/:id/reject', authenticate, requireAdmin, transactionController.adminReject);

// ========== RENDER JOBS ==========
router.post('/jobs/create', authenticate, jobController.createJob);
router.get('/jobs', authenticate, jobController.listMyJobs);
router.get('/jobs/:id', authenticate, jobController.getJob);
router.get('/jobs/:id/download', authenticate, jobController.downloadVideo);

// Health
router.get('/health', (req, res) => {
  res.json({ success: true, message: 'Threads-to-Video API is running', time: new Date().toISOString() });
});

module.exports = router;
