const { z } = require('zod');
const prisma = require('../utils/prisma');
const config = require('../config');
const { isAdmin } = require('../middleware/auth');
const {
  hasEnoughCredits,
  holdCredit,
  refundCredit,
} = require('../services/creditService');
const { addRenderJob } = require('../queues/renderQueue');

/**
 * POST /api/jobs/create
 * Create single or bulk (admin only) render job
 */
async function createJob(req, res) {
  try {
    const schema = z.object({
      url: z.string().url().optional(),
      urls: z.array(z.string().url()).optional(),
    });
    const body = schema.parse(req.body);

    const user = req.user;
    const isBulk = Array.isArray(body.urls) && body.urls.length > 0;

    if (isBulk && !isAdmin(user)) {
      return res.status(403).json({
        success: false,
        message: 'Chỉ Admin mới được dùng Bulk Render',
      });
    }

    let threadsUrls = [];
    if (isBulk) {
      threadsUrls = body.urls;
    } else if (body.url) {
      threadsUrls = [body.url];
    } else {
      return res.status(400).json({
        success: false,
        message: 'Cần cung cấp url hoặc urls (array)',
      });
    }

    // Validate Threads URL pattern roughly
    const threadsPattern = /threads\.(net|com)/i;
    for (const u of threadsUrls) {
      if (!threadsPattern.test(u)) {
        return res.status(400).json({
          success: false,
          message: `URL không hợp lệ (phải là link Threads công khai): ${u}`,
        });
      }
    }

    const creditNeeded = threadsUrls.length; // 1 credit per link

    if (!isAdmin(user)) {
      const enough = await hasEnoughCredits(user.id, creditNeeded);
      if (!enough) {
        return res.status(402).json({
          success: false,
          message: `Không đủ Credit. Cần ${creditNeeded}, bạn còn ${user.freeCredits + user.paidCredits}`,
        });
      }
    }

    // Hold credits (for non-admin)
    let held = { creditType: 'FREE', amount: 0 };
    if (!isAdmin(user)) {
      try {
        // For multi: hold sequentially or total. Here hold total from free first then paid.
        // Simple: loop hold 1 by 1, but for atomicity better one transaction.
        // Current holdCredit does 1. For bulk we call multiple times or enhance.
        // For now support single primarily; for bulk admin only so amount=0.
        if (creditNeeded === 1) {
          held = await holdCredit(user.id, 1);
        } else {
          // Fallback: hold total paid/free mix is complex; since bulk is admin, skip.
          held = { creditType: 'FREE', amount: 0 };
        }
      } catch (e) {
        return res.status(402).json({ success: false, message: e.message });
      }
    }

    const priority = isAdmin(user) ? 10 : 0;

    const job = await prisma.renderJob.create({
      data: {
        userId: user.id,
        threadsUrl: threadsUrls[0],
        isBulk,
        threadsUrls: isBulk ? JSON.stringify(threadsUrls) : null,
        status: 'QUEUED',
        progress: 0,
        priority,
        heldCreditType: held.creditType,
        heldAmount: held.amount || creditNeeded,
        expiresAt: new Date(Date.now() + config.videoTtlHours * 60 * 60 * 1000),
      },
    });

    // Add to BullMQ queue (high priority for admin)
    await addRenderJob({
      jobId: job.id,
      userId: user.id,
      urls: threadsUrls,
      priority,
      heldCreditType: held.creditType,
      heldAmount: held.amount,
    });

    return res.status(201).json({
      success: true,
      message: isBulk
        ? `Đã thêm ${threadsUrls.length} link vào hàng đợi (ưu tiên cao)`
        : 'Đã thêm vào hàng đợi render',
      data: {
        jobId: job.id,
        status: job.status,
        progress: job.progress,
        isBulk,
        count: threadsUrls.length,
      },
    });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ success: false, message: err.errors[0].message });
    }
    console.error('Create job error:', err);
    return res.status(500).json({ success: false, message: 'Lỗi server' });
  }
}

/**
 * GET /api/jobs/:id
 * Get job status + progress
 */
async function getJob(req, res) {
  try {
    const { id } = req.params;
    const job = await prisma.renderJob.findFirst({
      where: {
        id,
        OR: [
          { userId: req.user.id },
          // Admin can see all
          ...(isAdmin(req.user) ? [{}] : []),
        ],
      },
    });

    // Fix query for admin
    let found = job;
    if (!found && isAdmin(req.user)) {
      found = await prisma.renderJob.findUnique({ where: { id } });
    }
    if (!found) {
      return res.status(404).json({ success: false, message: 'Job không tồn tại' });
    }
    if (found.userId !== req.user.id && !isAdmin(req.user)) {
      return res.status(403).json({ success: false, message: 'Không có quyền xem job này' });
    }

    return res.json({
      success: true,
      data: {
        id: found.id,
        status: found.status,
        progress: found.progress,
        videoPath: found.videoPath,
        thumbnailPath: found.thumbnailPath,
        errorMessage: found.errorMessage,
        isBulk: found.isBulk,
        createdAt: found.createdAt,
        completedAt: found.completedAt,
        expiresAt: found.expiresAt,
      },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: 'Lỗi server' });
  }
}

/**
 * GET /api/jobs
 * List my jobs
 */
async function listMyJobs(req, res) {
  try {
    const jobs = await prisma.renderJob.findMany({
      where: { userId: req.user.id },
      orderBy: { createdAt: 'desc' },
      take: 30,
      select: {
        id: true,
        threadsUrl: true,
        status: true,
        progress: true,
        videoPath: true,
        thumbnailPath: true,
        isBulk: true,
        createdAt: true,
        completedAt: true,
        expiresAt: true,
      },
    });
    return res.json({ success: true, data: jobs });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Lỗi server' });
  }
}

/**
 * GET /api/jobs/:id/download
 * Redirect or stream video (protected)
 */
async function downloadVideo(req, res) {
  try {
    const { id } = req.params;
    const type = req.query.type || 'video'; // video | thumbnail

    const job = await prisma.renderJob.findUnique({ where: { id } });
    if (!job) {
      return res.status(404).json({ success: false, message: 'Job không tồn tại' });
    }
    if (job.userId !== req.user.id && !isAdmin(req.user)) {
      return res.status(403).json({ success: false, message: 'Không có quyền' });
    }
    if (job.status !== 'COMPLETED') {
      return res.status(400).json({ success: false, message: 'Video chưa sẵn sàng' });
    }

    const path = type === 'thumbnail' ? job.thumbnailPath : job.videoPath;
    if (!path) {
      return res.status(404).json({ success: false, message: 'File không tồn tại' });
    }

    // In production serve from static or signed URL. Here return path for frontend.
    return res.json({
      success: true,
      data: {
        url: `/uploads/${path.split('/').pop()}`,
        type,
        expiresAt: job.expiresAt,
      },
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Lỗi server' });
  }
}

module.exports = {
  createJob,
  getJob,
  listMyJobs,
  downloadVideo,
};
