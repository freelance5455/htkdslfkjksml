const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { z } = require('zod');
const prisma = require('../utils/prisma');
const config = require('../config');
const { getBalanceDisplay } = require('../services/creditService');

const registerSchema = z.object({
  username: z.string().min(3).max(30).regex(/^[a-zA-Z0-9_]+$/, 'Username chỉ chứa chữ, số, _'),
  password: z.string().min(6).max(100),
});

const loginSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1),
});

/**
 * POST /api/auth/register
 */
async function register(req, res) {
  try {
    const body = registerSchema.parse(req.body);

    const existing = await prisma.user.findUnique({
      where: { username: body.username },
    });
    if (existing) {
      return res.status(400).json({ success: false, message: 'Username đã tồn tại' });
    }

    const passwordHash = await bcrypt.hash(body.password, 12);

    const user = await prisma.user.create({
      data: {
        username: body.username,
        passwordHash,
        role: 'USER',
        freeCredits: config.freeCreditsDaily,
        paidCredits: 0,
      },
      select: {
        id: true,
        username: true,
        role: true,
        freeCredits: true,
        paidCredits: true,
        createdAt: true,
      },
    });

    const token = jwt.sign({ userId: user.id, role: user.role }, config.jwt.secret, {
      expiresIn: config.jwt.expiresIn,
    });

    return res.status(201).json({
      success: true,
      message: 'Đăng ký thành công',
      data: {
        user: {
          ...user,
          balance: getBalanceDisplay(user),
        },
        token,
      },
    });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ success: false, message: err.errors[0].message });
    }
    console.error('Register error:', err);
    return res.status(500).json({ success: false, message: 'Lỗi server' });
  }
}

/**
 * POST /api/auth/login
 */
async function login(req, res) {
  try {
    const body = loginSchema.parse(req.body);

    const user = await prisma.user.findUnique({
      where: { username: body.username },
    });
    if (!user) {
      return res.status(401).json({ success: false, message: 'Sai username hoặc mật khẩu' });
    }

    const valid = await bcrypt.compare(body.password, user.passwordHash);
    if (!valid) {
      return res.status(401).json({ success: false, message: 'Sai username hoặc mật khẩu' });
    }

    const token = jwt.sign({ userId: user.id, role: user.role }, config.jwt.secret, {
      expiresIn: config.jwt.expiresIn,
    });

    return res.json({
      success: true,
      message: 'Đăng nhập thành công',
      data: {
        user: {
          id: user.id,
          username: user.username,
          role: user.role,
          freeCredits: user.freeCredits,
          paidCredits: user.paidCredits,
          balance: getBalanceDisplay(user),
        },
        token,
      },
    });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ success: false, message: err.errors[0].message });
    }
    console.error('Login error:', err);
    return res.status(500).json({ success: false, message: 'Lỗi server' });
  }
}

/**
 * GET /api/auth/me
 */
async function me(req, res) {
  try {
    const user = req.user;
    return res.json({
      success: true,
      data: {
        ...user,
        balance: getBalanceDisplay(user),
      },
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Lỗi server' });
  }
}

/**
 * POST /api/auth/logout (client-side mainly, optional blacklist later)
 */
async function logout(req, res) {
  return res.json({ success: true, message: 'Đăng xuất thành công' });
}

module.exports = {
  register,
  login,
  me,
  logout,
};
