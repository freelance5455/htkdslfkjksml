const { z } = require('zod');
const { v4: uuidv4 } = require('uuid');
const prisma = require('../utils/prisma');
const config = require('../config');
const { isAdmin } = require('../middleware/auth');

/**
 * GET /api/transactions/packages
 * List available top-up packages
 */
function getPackages(req, res) {
  return res.json({
    success: true,
    data: config.packages,
  });
}

/**
 * POST /api/transactions/create
 * User creates a top-up order -> returns VietQR URL + content
 */
async function createTransaction(req, res) {
  try {
    const schema = z.object({
      amount: z.number().int().positive(),
    });
    const { amount } = schema.parse(req.body);

    const pkg = config.packages.find((p) => p.amount === amount);
    if (!pkg) {
      return res.status(400).json({
        success: false,
        message: 'Gói nạp không hợp lệ. Chọn 20000, 50000 hoặc 100000',
      });
    }

    const user = req.user;
    // Unique content: NAP <shortUserId> <random>
    const shortId = uuidv4().split('-')[0].toUpperCase();
    const content = `NAP ${user.id.slice(0, 8)} ${shortId}`;

    const tx = await prisma.transaction.create({
      data: {
        userId: user.id,
        amount: pkg.amount,
        credits: pkg.credits,
        content,
        status: 'PENDING',
      },
    });

    // Build VietQR image URL (free public service)
    const accountNameEncoded = encodeURIComponent(config.bank.accountName);
    const addInfoEncoded = encodeURIComponent(content);
    const vietqrUrl = `https://img.vietqr.io/image/${config.bank.id}-${config.bank.accountNo}-compact2.png?amount=${pkg.amount}&addInfo=${addInfoEncoded}&accountName=${accountNameEncoded}`;

    return res.status(201).json({
      success: true,
      message: 'Tạo đơn nạp thành công. Vui lòng chuyển khoản đúng nội dung.',
      data: {
        transactionId: tx.id,
        amount: tx.amount,
        credits: tx.credits,
        content: tx.content,
        vietqrUrl,
        bank: {
          id: config.bank.id,
          accountNo: config.bank.accountNo,
          accountName: config.bank.accountName,
        },
        status: tx.status,
      },
    });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ success: false, message: err.errors[0].message });
    }
    console.error('Create transaction error:', err);
    return res.status(500).json({ success: false, message: 'Lỗi server' });
  }
}

/**
 * POST /api/transactions/:id/confirm
 * User clicks "Tôi đã chuyển khoản"
 */
async function confirmTransfer(req, res) {
  try {
    const { id } = req.params;
    const tx = await prisma.transaction.findFirst({
      where: { id, userId: req.user.id },
    });
    if (!tx) {
      return res.status(404).json({ success: false, message: 'Đơn không tồn tại' });
    }
    if (tx.status !== 'PENDING') {
      return res.status(400).json({ success: false, message: 'Đơn đã được xử lý' });
    }
    // Just acknowledge, status stays PENDING for admin review
    return res.json({
      success: true,
      message: 'Đã ghi nhận. Admin sẽ kiểm tra và duyệt trong thời gian sớm nhất.',
      data: { transactionId: tx.id, status: tx.status },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: 'Lỗi server' });
  }
}

/**
 * GET /api/transactions/my
 * User's own transactions
 */
async function myTransactions(req, res) {
  try {
    const list = await prisma.transaction.findMany({
      where: { userId: req.user.id },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
    return res.json({ success: true, data: list });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Lỗi server' });
  }
}

/**
 * GET /api/admin/transactions/pending
 * Admin: list PENDING + count badge
 */
async function adminPendingList(req, res) {
  try {
    const [list, count] = await Promise.all([
      prisma.transaction.findMany({
        where: { status: 'PENDING' },
        include: {
          user: { select: { id: true, username: true } },
        },
        orderBy: { createdAt: 'asc' },
      }),
      prisma.transaction.count({ where: { status: 'PENDING' } }),
    ]);

    return res.json({
      success: true,
      data: {
        count,
        transactions: list,
      },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: 'Lỗi server' });
  }
}

/**
 * POST /api/admin/transactions/:id/approve
 * Admin approve -> add paid_credits
 */
async function adminApprove(req, res) {
  try {
    const { id } = req.params;

    const result = await prisma.$transaction(async (tx) => {
      const transaction = await tx.transaction.findUnique({ where: { id } });
      if (!transaction) throw new Error('NOT_FOUND');
      if (transaction.status !== 'PENDING') throw new Error('ALREADY_PROCESSED');

      // Update transaction
      const updated = await tx.transaction.update({
        where: { id },
        data: {
          status: 'APPROVED',
          approvedAt: new Date(),
          approvedBy: req.user.username,
        },
      });

      // Add credits to user
      await tx.user.update({
        where: { id: transaction.userId },
        data: {
          paidCredits: { increment: transaction.credits },
        },
      });

      return updated;
    });

    return res.json({
      success: true,
      message: `Đã duyệt +${result.credits} Credit cho user`,
      data: result,
    });
  } catch (err) {
    if (err.message === 'NOT_FOUND') {
      return res.status(404).json({ success: false, message: 'Đơn không tồn tại' });
    }
    if (err.message === 'ALREADY_PROCESSED') {
      return res.status(400).json({ success: false, message: 'Đơn đã được xử lý' });
    }
    console.error(err);
    return res.status(500).json({ success: false, message: 'Lỗi server' });
  }
}

/**
 * POST /api/admin/transactions/:id/reject
 */
async function adminReject(req, res) {
  try {
    const { id } = req.params;
    const transaction = await prisma.transaction.findUnique({ where: { id } });
    if (!transaction) {
      return res.status(404).json({ success: false, message: 'Đơn không tồn tại' });
    }
    if (transaction.status !== 'PENDING') {
      return res.status(400).json({ success: false, message: 'Đơn đã được xử lý' });
    }

    const updated = await prisma.transaction.update({
      where: { id },
      data: {
        status: 'REJECTED',
        approvedAt: new Date(),
        approvedBy: req.user.username,
      },
    });

    return res.json({
      success: true,
      message: 'Đã từ chối đơn nạp',
      data: updated,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: 'Lỗi server' });
  }
}

module.exports = {
  getPackages,
  createTransaction,
  confirmTransfer,
  myTransactions,
  adminPendingList,
  adminApprove,
  adminReject,
};
