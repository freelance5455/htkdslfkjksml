/**
 * TTS Service using edge-tts (free, high quality Vietnamese voices)
 */

const { exec } = require('child_process');
const util = require('util');
const path = require('path');
const fs = require('fs');
const execPromise = util.promisify(exec);

const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || './uploads');

const VOICES = {
  female: 'vi-VN-HoaiMyNeural',
  male: 'vi-VN-NamMinhNeural',
};

/**
 * Generate speech + SRT subtitle from text
 * Returns { audioPath, srtPath, duration }
 */
async function generateTTS(text, options = {}) {
  const voice = options.voice || VOICES.female;
  const rate = options.rate || '+0%';
  const jobId = options.jobId || Date.now();

  const audioPath = path.join(UPLOAD_DIR, `tts_${jobId}.mp3`);
  const srtPath = path.join(UPLOAD_DIR, `tts_${jobId}.srt`);
  const vttPath = path.join(UPLOAD_DIR, `tts_${jobId}.vtt`);

  // Clean text a bit
  const cleanText = text
    .replace(/\s+/g, ' ')
    .replace(/[^\p{L}\p{N}\p{P}\p{Z}]/gu, '')
    .trim()
    .slice(0, 1200); // limit length

  if (!cleanText) {
    throw new Error('Empty text for TTS');
  }

  // edge-tts command
  // --write-media and --write-subtitles
  const cmd = `python3 -m edge_tts --voice "${voice}" --rate="${rate}" --text ${JSON.stringify(
    cleanText
  )} --write-media "${audioPath}" --write-subtitles "${vttPath}"`;

  try {
    await execPromise(cmd, { timeout: 60000 });
  } catch (err) {
    console.error('[TTS] edge-tts failed:', err.message);
    // Fallback: create silent audio of ~ length based on text
    const estimatedSec = Math.max(5, Math.ceil(cleanText.length / 12));
    await execPromise(
      `ffmpeg -y -f lavfi -i anullsrc=r=44100:cl=mono -t ${estimatedSec} -q:a 9 -acodec libmp3lame "${audioPath}"`,
      { timeout: 15000 }
    );
    // Simple SRT
    const srtContent = `1\n00:00:00,000 --> 00:00:${String(estimatedSec).padStart(2, '0')},000\n${cleanText.slice(0, 80)}\n`;
    fs.writeFileSync(srtPath, srtContent);
    return { audioPath, srtPath, duration: estimatedSec, voice };
  }

  // Convert VTT to SRT if needed
  if (fs.existsSync(vttPath)) {
    const vtt = fs.readFileSync(vttPath, 'utf8');
    const srt = vttToSrt(vtt);
    fs.writeFileSync(srtPath, srt);
  } else {
    // Generate basic SRT
    const estimatedSec = Math.max(5, Math.ceil(cleanText.length / 14));
    fs.writeFileSync(
      srtPath,
      `1\n00:00:00,000 --> 00:00:${String(estimatedSec).padStart(2, '0')},000\n${cleanText}\n`
    );
  }

  // Get duration
  let duration = 10;
  try {
    const { stdout } = await execPromise(
      `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "${audioPath}"`
    );
    duration = parseFloat(stdout.trim()) || 10;
  } catch (e) {}

  return { audioPath, srtPath, duration, voice };
}

function vttToSrt(vtt) {
  // Simple VTT -> SRT converter
  let srt = vtt
    .replace(/^WEBVTT\s*\n/i, '')
    .replace(/(\d{2}:\d{2}:\d{2})\.(\d{3})/g, '$1,$2')
    .replace(/(\d+)\n(\d{2}:\d{2}:\d{2},\d{3} --> \d{2}:\d{2}:\d{2},\d{3})/g, '$1\n$2');
  // Ensure numbering
  const lines = srt.trim().split(/\n\s*\n/);
  return lines
    .map((block, i) => {
      const parts = block.trim().split('\n');
      if (parts.length >= 2) {
        return `${i + 1}\n${parts.join('\n')}`;
      }
      return block;
    })
    .join('\n\n');
}

/**
 * Build full script text from scraped data for TTS
 */
function buildScriptFromPost(postData) {
  const { author, content, comments } = postData;
  let script = `Bài viết của ${author}. ${content}`;

  if (comments && comments.length > 0) {
    script += ' Các bình luận nổi bật: ';
    comments.slice(0, 3).forEach((c, i) => {
      script += `Bình luận ${i + 1}: ${c.text}. `;
    });
  }

  script += ' Cảm ơn các bạn đã theo dõi.';
  return script;
}

module.exports = {
  generateTTS,
  buildScriptFromPost,
  VOICES,
};
