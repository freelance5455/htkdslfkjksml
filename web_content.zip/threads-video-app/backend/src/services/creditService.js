/**
 * Credit Service
 * - Hold / Deduct / Refund logic
 * - Priority: free_credits first, then paid_credits
 * - Admin: unlimited (skip checks)
 */

const prisma = require('../utils/prisma');
const { isAdmin } = require('../middleware/auth');
const config = require('../config');

/**
 * Check if user has enough credits (or is admin)
 */
async function hasEnoughCredits(userId, amount = 1) {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) return false;
  if (isAdmin(user)) return true;
  return user.freeCredits + user.paidCredits >= amount;
}

/**
 * Hold 1 credit (prefer free). Returns { creditType, amount } or throws
 * Does NOT deduct permanently yet.
 */
async function holdCredit(userId, amount = 1) {
  return await prisma.$transaction(async (tx) => {
    const user = await tx.user.findUnique({ where: { id: userId } });
    if (!user) throw new Error('User not found');

    if (isAdmin(user)) {
      return { creditType: 'FREE', amount: 0 }; // Admin free
    }

    if (user.freeCredits >= amount) {
      // Temporarily reduce freeCredits (hold)
      await tx.user.update({
        where: { id: userId },
        data: { freeCredits: { decrement: amount } },
      });
      return { creditType: 'FREE', amount };
    }

    if (user.paidCredits >= amount) {
      await tx.user.update({
        where: { id: userId },
        data: { paidCredits: { decrement: amount } },
      });
      return { creditType: 'PAID', amount };
    }

    throw new Error('Insufficient credits');
  });
}

/**
 * Permanently confirm the hold (already deducted in hold). No-op for tracking.
 * Or if we want separate hold table, mark as deducted.
 */
async function confirmDeduct(userId, jobId, creditType, amount) {
  // Since hold already decremented, just log or update job
  // For simplicity we already decremented on hold.
  // If fail later we refund.
  return true;
}

/**
 * Refund the held amount back to the correct wallet
 */
async function refundCredit(userId, creditType, amount) {
  if (amount <= 0) return;

  return await prisma.$transaction(async (tx) => {
    const user = await tx.user.findUnique({ where: { id: userId } });
    if (!user || isAdmin(user)) return;

    if (creditType === 'FREE') {
      await tx.user.update({
        where: { id: userId },
        data: { freeCredits: { increment: amount } },
      });
    } else if (creditType === 'PAID') {
      await tx.user.update({
        where: { id: userId },
        data: { paidCredits: { increment: amount } },
      });
    }
  });
}

/**
 * Daily reset free_credits = 3 (no accumulate) at 00:00 Asia/Ho_Chi_Minh
 * Called by cron
 */
async function resetFreeCreditsDaily() {
  // Set freeCredits = 3 for all non-admin users whose lastFreeReset is before today (VN time)
  const now = new Date();
  // Get start of today in VN (UTC+7)
  const vnOffsetMs = 7 * 60 * 60 * 1000;
  const vnNow = new Date(now.getTime() + vnOffsetMs);
  const startOfTodayVN = new Date(Date.UTC(
    vnNow.getUTCFullYear(),
    vnNow.getUTCMonth(),
    vnNow.getUTCDate(),
    0, 0, 0, 0
  ));
  // Convert back to UTC for comparison
  const startOfTodayUTC = new Date(startOfTodayVN.getTime() - vnOffsetMs);

  const result = await prisma.user.updateMany({
    where: {
      role: 'USER',
      lastFreeReset: { lt: startOfTodayUTC },
    },
    data: {
      freeCredits: config.freeCreditsDaily,
      lastFreeReset: now,
    },
  });

  console.log(`[CRON] Reset free_credits for ${result.count} users at ${now.toISOString()}`);
  return result.count;
}

/**
 * Get balance summary for header
 */
function getBalanceDisplay(user) {
  if (isAdmin(user)) {
    return { free: '∞', paid: '∞', isAdmin: true };
  }
  return {
    free: user.freeCredits,
    freeMax: config.freeCreditsDaily,
    paid: user.paidCredits,
    isAdmin: false,
  };
}

module.exports = {
  hasEnoughCredits,
  holdCredit,
  confirmDeduct,
  refundCredit,
  resetFreeCreditsDaily,
  getBalanceDisplay,
};
