/**
 * Advanced Video Render Service - FFmpeg 9:16
 * Features:
 * - Multiple dark cinematic backgrounds
 * - Ambient background music (loop + duck under TTS)
 * - SFX (whoosh, pop) on transitions
 * - Meme-style reaction cards + comment cards
 * - Karaoke subtitles
 * - Thumbnail
 */

const { exec } = require('child_process');
const util = require('util');
const path = require('path');
const fs = require('fs');
const execPromise = util.promisify(exec);

const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || './uploads');
const ASSETS = path.resolve(__dirname, '../../assets');

const MUSIC = path.join(ASSETS, 'music/ambient_soft.mp3');
const SFX_WHOOSH = path.join(ASSETS, 'sfx/whoosh.mp3');
const SFX_POP = path.join(ASSETS, 'sfx/pop.mp3');

/**
 * Main render
 */
async function renderVideo({ jobId, postData, audioPath, srtPath, duration }) {
  const width = 1080;
  const height = 1920;
  const fps = 30;

  const videoOut = path.join(UPLOAD_DIR, `video_${jobId}.mp4`);
  const thumbOut = path.join(UPLOAD_DIR, `thumb_${jobId}.jpg`);
  const workDir = path.join(UPLOAD_DIR, `work_${jobId}`);
  fs.mkdirSync(workDir, { recursive: true });

  const { author, content, comments = [], username } = postData;
  const safeAuthor = escapeText(author || 'User');
  const safeUser = escapeText(username || 'user');
  const safeContent = escapeText((content || '').slice(0, 320));

  const totalDur = Math.max(duration || 12, 11);
  const introDur = 2.8;
  const contentDur = Math.min(7, totalDur * 0.38);
  const remaining = Math.max(totalDur - introDur - contentDur, 4);
  const perComment = remaining / Math.max(Math.min(comments.length, 4), 1);

  // 1. Cinematic background
  const bgPath = path.join(workDir, 'bg.png');
  await createCinematicBg(bgPath, width, height);

  // 2. Segments
  const segments = [];

  // Intro + Post
  const introSeg = path.join(workDir, 'seg_intro.mp4');
  await createStyledSegment({
    outPath: introSeg,
    bgPath,
    duration: introDur + contentDur,
    width,
    height,
    type: 'post',
    title: 'THREADS',
    lines: [
      { text: '@' + safeUser, size: 36, y: 320, color: '0xA78BFA' },
      { text: safeAuthor, size: 52, y: 390, color: 'white' },
      { text: safeContent, size: 34, y: 520, color: '0xE5E5E5', wrap: true },
    ],
  });
  segments.push({ path: introSeg, sfx: SFX_WHOOSH });

  // Comments / Meme cards
  const maxComments = Math.min(comments.length, 4);
  for (let i = 0; i < maxComments; i++) {
    const c = comments[i];
    const segPath = path.join(workDir, 'seg_c' + i + '.mp4');
    const cAuthor = escapeText(c.author || 'Comment');
    const cText = escapeText((c.text || '').slice(0, 180));
    const isMeme = i % 2 === 1;

    await createStyledSegment({
      outPath: segPath,
      bgPath,
      duration: Math.max(2.8, perComment),
      width,
      height,
      type: isMeme ? 'meme' : 'comment',
      title: isMeme ? 'REACTION' : 'COMMENT ' + (i + 1),
      lines: [
        { text: cAuthor, size: 40, y: 380, color: isMeme ? '0xFBBF24' : 'white' },
        { text: cText, size: 34, y: 480, color: '0xE0E0E0', wrap: true },
      ],
      emoji: isMeme ? getRandomEmoji() : null,
    });
    segments.push({ path: segPath, sfx: SFX_POP });
  }

  // 3. Concat
  const concatList = path.join(workDir, 'list.txt');
  fs.writeFileSync(concatList, segments.map((s) => "file '" + s.path + "'").join('\n'));

  const silentVideo = path.join(workDir, 'silent.mp4');
  await execPromise(
    'ffmpeg -y -f concat -safe 0 -i "' + concatList + '" -c:v libx264 -preset fast -crf 22 -pix_fmt yuv420p -r ' + fps + ' "' + silentVideo + '"',
    { timeout: 90000 }
  );

  // 4. Mix audio
  const mixedAudio = path.join(workDir, 'mixed_audio.mp3');
  await mixAudio({
    ttsPath: audioPath,
    musicPath: MUSIC,
    sfxList: segments.map((s) => s.sfx).filter(Boolean),
    outPath: mixedAudio,
    totalDuration: totalDur,
  });

  // 5. Final + subtitles
  let vf = '';
  if (srtPath && fs.existsSync(srtPath)) {
    const escapedSrt = srtPath.replace(/\\/g, '/').replace(/:/g, '\\:').replace(/'/g, "\\'");
    vf = '-vf "subtitles=\'' + escapedSrt + '\':force_style=\'FontName=Arial,FontSize=24,PrimaryColour=&H00FFFFFF,OutlineColour=&H90000000,BorderStyle=3,Outline=2,Shadow=1,MarginV=100,Alignment=2\'"';
  }

  const finalCmd = 'ffmpeg -y -i "' + silentVideo + '" -i "' + mixedAudio + '" ' + vf + ' -c:v libx264 -preset fast -crf 21 -c:a aac -b:a 160k -shortest -movflags +faststart "' + videoOut + '"';
  await execPromise(finalCmd, { timeout: 120000 });

  // 6. Thumbnail
  await execPromise(
    'ffmpeg -y -i "' + videoOut + '" -ss 2.2 -vframes 1 -q:v 2 "' + thumbOut + '"',
    { timeout: 15000 }
  );

  try { fs.rmSync(workDir, { recursive: true, force: true }); } catch (e) {}

  let finalDur = totalDur;
  try {
    const { stdout } = await execPromise('ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "' + videoOut + '"');
    finalDur = parseFloat(stdout.trim()) || totalDur;
  } catch (e) {}

  return {
    videoPath: path.basename(videoOut),
    thumbnailPath: path.basename(thumbOut),
    duration: finalDur,
    fullVideoPath: videoOut,
    fullThumbPath: thumbOut,
  };
}

async function createCinematicBg(outPath, w, h) {
  await execPromise(
    'ffmpeg -y -f lavfi -i "color=c=0x0B0B18:s=' + w + 'x' + h + '" -vf "geq=r=\'16+20*exp(-((X-' + w/2 + ')^2+(Y-' + h/2 + ')^2)/180000)\':g=\'12+15*exp(-((X-' + w/2 + ')^2+(Y-' + h/2 + ')^2)/180000)\':b=\'28+40*exp(-((X-' + w/2 + ')^2+(Y-' + h/2 + ')^2)/160000)\'" -frames:v 1 "' + outPath + '"',
    { timeout: 20000 }
  );
}

async function createStyledSegment({ outPath, bgPath, duration, width, height, type, title, lines, emoji }) {
  const filters = [];
  filters.push('drawbox=x=0:y=0:w=' + width + ':h=110:color=0x1A1A2E@0.95:t=fill');

  if (title) {
    const titleColor = type === 'meme' ? '0xFBBF24' : type === 'post' ? '0xA78BFA' : '0x818CF8';
    filters.push("drawtext=text='" + escapeText(title) + "':fontcolor=" + titleColor + ":fontsize=26:x=(w-text_w)/2:y=42");
  }

  const cardColor = type === 'meme' ? '0x1F1A10@0.9' : '0x16162A@0.9';
  filters.push('drawbox=x=50:y=200:w=' + (width - 100) + ':h=980:color=' + cardColor + ':t=fill');

  const accent = type === 'meme' ? '0xF59E0B' : '0x6366F1';
  filters.push('drawbox=x=50:y=200:w=8:h=980:color=' + accent + ':t=fill');

  if (emoji) {
    filters.push("drawtext=text='" + emoji + "':fontsize=90:x=(w-text_w)/2:y=280");
  }

  lines.forEach((line, idx) => {
    let y = line.y || 400;
    if (emoji && idx === 0) y += 60;
    const size = line.size || 38;
    const color = line.color || 'white';
    let text = line.text || '';

    if (line.wrap && text.length > 42) {
      const words = text.split(' ');
      let line1 = '', line2 = '';
      for (const w of words) {
        if ((line1 + ' ' + w).trim().length < 42) line1 = (line1 + ' ' + w).trim();
        else line2 = (line2 + ' ' + w).trim();
      }
      filters.push("drawtext=text='" + line1 + "':fontcolor=" + color + ":fontsize=" + size + ":x=90:y=" + y);
      if (line2) {
        filters.push("drawtext=text='" + line2 + "':fontcolor=" + color + ":fontsize=" + size + ":x=90:y=" + (y + size + 14));
      }
    } else {
      filters.push("drawtext=text='" + text + "':fontcolor=" + color + ":fontsize=" + size + ":x=90:y=" + y);
    }
  });

  filters.push("drawtext=text='Threads \\xe2\\x86\\x92 Video':fontcolor=0x4B5563:fontsize=22:x=(w-text_w)/2:y=" + (height - 70));

  const vf = filters.join(',');
  await execPromise(
    'ffmpeg -y -loop 1 -i "' + bgPath + '" -t ' + duration + ' -vf "' + vf + '" -c:v libx264 -preset ultrafast -crf 24 -pix_fmt yuv420p -r 30 "' + outPath + '"',
    { timeout: 45000 }
  );
}

async function mixAudio({ ttsPath, musicPath, sfxList, outPath, totalDuration }) {
  const inputs = [];
  if (ttsPath && fs.existsSync(ttsPath)) inputs.push('-i "' + ttsPath + '"');
  else inputs.push('-f lavfi -i anullsrc=r=44100:cl=mono');

  if (musicPath && fs.existsSync(musicPath)) inputs.push('-i "' + musicPath + '"');
  else inputs.push('-f lavfi -i anullsrc=r=44100:cl=mono');

  const hasSfx = sfxList && sfxList.length > 0 && fs.existsSync(sfxList[0]);
  let filter = '';
  if (hasSfx) {
    inputs.push('-i "' + sfxList[0] + '"');
    filter = '[1]volume=0.18,afade=t=in:st=0:d=1.5[bg];[0]volume=1.0[voice];[2]volume=0.55,adelay=300|300[sfx];[bg][voice]amix=inputs=2:duration=first:dropout_transition=2[mix1];[mix1][sfx]amix=inputs=2:duration=first:dropout_transition=1[aout]';
  } else {
    filter = '[1]volume=0.18,afade=t=in:st=0:d=1.5[bg];[0]volume=1.0[voice];[bg][voice]amix=inputs=2:duration=first:dropout_transition=2[aout]';
  }

  const cmd = 'ffmpeg -y ' + inputs.join(' ') + ' -filter_complex "' + filter + '" -map "[aout]" -t ' + (totalDuration + 1) + ' -c:a libmp3lame -q:a 4 "' + outPath + '"';
  await execPromise(cmd, { timeout: 60000 });
}

function escapeText(str) {
  if (!str) return '';
  return String(str)
    .replace(/\\\\/g, '\\\\\\\\')
    .replace(/'/g, "'\\\\''")
    .replace(/:/g, '\\\\:')
    .replace(/\\n/g, ' ')
    .replace(/%/g, '%%')
    .slice(0, 280);
}

function getRandomEmoji() {
  const list = ['🔥', '😂', '🤯', '💯', '👀', '👏', '❤️', '🚀', '✨', '🙌'];
  return list[Math.floor(Math.random() * list.length)];
}

module.exports = { renderVideo };
