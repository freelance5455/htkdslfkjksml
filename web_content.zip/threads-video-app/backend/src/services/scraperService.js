/**
 * Threads Scraper Service
 * Uses Playwright to extract public post content, author, avatar, and top comments.
 * Falls back to mock data if scrape fails (for demo / rate limit).
 */

const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || './uploads');

async function scrapeThreadsPost(url) {
  let browser = null;
  try {
    browser = await chromium.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'],
    });
    const context = await browser.newContext({
      userAgent:
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      viewport: { width: 1280, height: 900 },
      locale: 'vi-VN',
    });
    const page = await context.newPage();

    await page.goto(url, { waitUntil: 'networkidle', timeout: 45000 });
    await page.waitForTimeout(2500);

    // Extract main post data via JS evaluation (Threads DOM changes often)
    const data = await page.evaluate(() => {
      const getText = (sel) => {
        const el = document.querySelector(sel);
        return el ? el.innerText.trim() : null;
      };

      // Try multiple selectors for robustness
      let author = null;
      let username = null;
      let content = null;
      let avatar = null;

      // Author name
      const authorEl =
        document.querySelector('a[href*="/@"] span') ||
        document.querySelector('[data-pressable-container] span') ||
        document.querySelector('h1, h2');
      if (authorEl) author = authorEl.innerText.trim();

      // Username from URL or link
      const userLink = document.querySelector('a[href*="/@"]');
      if (userLink) {
        const href = userLink.getAttribute('href') || '';
        const match = href.match(/@([\w.]+)/);
        if (match) username = match[1];
      }

      // Post text - look for the main text container
      const textCandidates = Array.from(
        document.querySelectorAll('div[dir="auto"], span[dir="auto"]')
      ).filter((el) => {
        const t = el.innerText.trim();
        return t.length > 20 && t.length < 2000 && !t.includes('Follow') && !t.includes('Log in');
      });
      if (textCandidates.length > 0) {
        content = textCandidates[0].innerText.trim();
      }

      // Avatar
      const img = document.querySelector('img[alt*="profile"], img[src*="cdninstagram"], img[src*="scontent"]');
      if (img) avatar = img.src;

      // Comments (top ones)
      const comments = [];
      const commentNodes = document.querySelectorAll('div[role="article"], div[data-pressable-container]');
      commentNodes.forEach((node, idx) => {
        if (idx > 8) return;
        const txt = node.innerText || '';
        if (txt.length > 15 && txt.length < 500 && !txt.includes('Like') && comments.length < 6) {
          const lines = txt.split('\n').filter((l) => l.trim().length > 5);
          if (lines.length >= 1) {
            comments.push({
              author: lines[0].slice(0, 30),
              text: lines.slice(1).join(' ').slice(0, 200) || lines[0].slice(0, 200),
            });
          }
        }
      });

      return {
        author: author || username || 'Threads User',
        username: username || 'user',
        content: content || 'Không lấy được nội dung bài viết.',
        avatar,
        comments: comments.slice(0, 5),
        url: window.location.href,
      };
    });

    // Download avatar if possible
    let avatarPath = null;
    if (data.avatar) {
      try {
        const avatarResp = await page.request.get(data.avatar);
        if (avatarResp.ok()) {
          const buf = await avatarResp.body();
          avatarPath = path.join(UPLOAD_DIR, `avatar_${Date.now()}.jpg`);
          fs.writeFileSync(avatarPath, buf);
          data.avatarLocal = avatarPath;
        }
      } catch (e) {
        // ignore
      }
    }

    await browser.close();
    return { success: true, data };
  } catch (err) {
    if (browser) await browser.close().catch(() => {});
    console.error('[Scraper] Error:', err.message);

    // Fallback mock for demo / when Threads blocks
    return {
      success: false,
      error: err.message,
      data: {
        author: 'Demo User',
        username: 'demouser',
        content:
          'Đây là nội dung demo vì không scrape được Threads lúc này. Hệ thống vẫn render video đầy đủ với TTS và phụ đề karaoke.',
        avatar: null,
        comments: [
          { author: 'User A', text: 'Bài hay quá, cảm ơn bạn đã chia sẻ!' },
          { author: 'User B', text: 'Mình cũng nghĩ vậy, rất thực tế.' },
          { author: 'User C', text: 'Follow ngay để không bỏ lỡ content chất lượng.' },
        ],
        url,
        isMock: true,
      },
    };
  }
}

module.exports = { scrapeThreadsPost };
