/**
 * Cron jobs
 * - Daily free_credits reset at 00:00 Asia/Ho_Chi_Minh
 * - Optional: clean expired videos every hour
 */

const cron = require('node-cron');
const { resetFreeCreditsDaily } = require('../services/creditService');
const prisma = require('../utils/prisma');
const fs = require('fs');
const path = require('path');
const config = require('../config');

function startCronJobs() {
  // Every day at 00:00 Vietnam time (UTC+7)
  // Cron expression: 0 0 * * * with timezone
  cron.schedule(
    '0 0 * * *',
    async () => {
      console.log('[CRON] Running daily free_credits reset...');
      try {
        const count = await resetFreeCreditsDaily();
        console.log(`[CRON] Done. Reset ${count} users.`);
      } catch (err) {
        console.error('[CRON] Reset failed:', err);
      }
    },
    {
      timezone: 'Asia/Ho_Chi_Minh',
    }
  );

  // Clean expired jobs/files every hour
  cron.schedule('0 * * * *', async () => {
    try {
      const now = new Date();
      const expired = await prisma.renderJob.findMany({
        where: {
          status: 'COMPLETED',
          expiresAt: { lt: now },
        },
        select: { id: true, videoPath: true, thumbnailPath: true },
      });

      for (const job of expired) {
        // Delete files if exist
        const uploadDir = path.resolve(config.uploadDir);
        if (job.videoPath) {
          const vp = path.join(uploadDir, path.basename(job.videoPath));
          if (fs.existsSync(vp)) fs.unlinkSync(vp);
        }
        if (job.thumbnailPath) {
          const tp = path.join(uploadDir, path.basename(job.thumbnailPath));
          if (fs.existsSync(tp)) fs.unlinkSync(tp);
        }
        await prisma.renderJob.update({
          where: { id: job.id },
          data: {
            videoPath: null,
            thumbnailPath: null,
            status: 'CANCELLED', // or keep COMPLETED but cleared
          },
        });
      }
      if (expired.length > 0) {
        console.log(`[CRON] Cleaned ${expired.length} expired videos`);
      }
    } catch (err) {
      console.error('[CRON] Cleanup failed:', err);
    }
  });

  console.log('✅ Cron jobs started (daily reset @ 00:00 Asia/Ho_Chi_Minh + hourly cleanup)');
}

module.exports = { startCronJobs };
