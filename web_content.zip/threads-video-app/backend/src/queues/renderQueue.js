/**
 * BullMQ Render Queue - Full real pipeline
 * Scrape → Script → TTS → FFmpeg Render 9:16
 */

const { Queue, Worker } = require('bullmq');
const IORedis = require('ioredis');
const path = require('path');
const fs = require('fs');
const config = require('../config');
const prisma = require('../utils/prisma');
const { refundCredit } = require('../services/creditService');
const { scrapeThreadsPost } = require('../services/scraperService');
const { generateTTS, buildScriptFromPost } = require('../services/ttsService');
const { renderVideo } = require('../services/renderService');

const connection = new IORedis({
  host: config.redis.host,
  port: config.redis.port,
  password: config.redis.password || undefined,
  maxRetriesPerRequest: null,
});

const QUEUE_NAME = 'render-video';

const renderQueue = new Queue(QUEUE_NAME, {
  connection,
  defaultJobOptions: {
    attempts: 2,
    backoff: { type: 'exponential', delay: 8000 },
    removeOnComplete: 50,
    removeOnFail: 30,
  },
});

async function addRenderJob(data) {
  // BullMQ: lower number = higher priority
  const bullPriority = data.priority >= 10 ? 1 : 10;
  return renderQueue.add('render', data, {
    priority: bullPriority,
    jobId: data.jobId,
  });
}

function startRenderWorker() {
  const worker = new Worker(
    QUEUE_NAME,
    async (bullJob) => {
      const { jobId, userId, urls, heldCreditType, heldAmount } = bullJob.data;
      console.log(`[Worker] ▶ START job ${jobId} | urls=${urls.length}`);

      const updateProgress = async (progress, status = 'PROCESSING') => {
        await prisma.renderJob.update({
          where: { id: jobId },
          data: { status, progress },
        });
      };

      try {
        // ===== 1. SCRAPE =====
        await updateProgress(10);
        console.log(`[Worker] ${jobId} - Scraping Threads...`);
        const scrapeResult = await scrapeThreadsPost(urls[0]);
        const postData = scrapeResult.data;
        console.log(`[Worker] ${jobId} - Scrape done. Author: ${postData.author}, mock=${!!postData.isMock}`);

        await updateProgress(25);

        // ===== 2. BUILD SCRIPT =====
        const script = buildScriptFromPost(postData);
        console.log(`[Worker] ${jobId} - Script length: ${script.length} chars`);

        await updateProgress(35);

        // ===== 3. TTS =====
        console.log(`[Worker] ${jobId} - Generating TTS (vi-VN)...`);
        const tts = await generateTTS(script, { jobId, voice: 'vi-VN-HoaiMyNeural' });
        console.log(`[Worker] ${jobId} - TTS done. Duration: ${tts.duration.toFixed(1)}s`);

        await updateProgress(55);

        // ===== 4. RENDER VIDEO =====
        console.log(`[Worker] ${jobId} - Rendering 9:16 MP4 with FFmpeg...`);
        const renderResult = await renderVideo({
          jobId,
          postData,
          audioPath: tts.audioPath,
          srtPath: tts.srtPath,
          duration: tts.duration,
        });

        await updateProgress(90);

        // ===== 5. COMPLETE =====
        await prisma.renderJob.update({
          where: { id: jobId },
          data: {
            status: 'COMPLETED',
            progress: 100,
            videoPath: renderResult.videoPath,
            thumbnailPath: renderResult.thumbnailPath,
            completedAt: new Date(),
            resultData: JSON.stringify({
              author: postData.author,
              username: postData.username,
              isMock: !!postData.isMock,
              duration: renderResult.duration,
              commentsCount: (postData.comments || []).length,
            }),
          },
        });

        // Cleanup TTS temp
        try {
          if (tts.audioPath && fs.existsSync(tts.audioPath)) fs.unlinkSync(tts.audioPath);
          if (tts.srtPath && fs.existsSync(tts.srtPath)) fs.unlinkSync(tts.srtPath);
        } catch (e) {}

        console.log(`[Worker] ✅ COMPLETED job ${jobId} → ${renderResult.videoPath}`);
        return { success: true, video: renderResult.videoPath };
      } catch (err) {
        console.error(`[Worker] ❌ FAILED job ${jobId}:`, err.message);

        // Refund
        if (heldAmount > 0 && heldCreditType) {
          try {
            await refundCredit(userId, heldCreditType, heldAmount);
            console.log(`[Worker] Refunded ${heldAmount} ${heldCreditType}`);
          } catch (re) {
            console.error('Refund error:', re.message);
          }
        }

        await prisma.renderJob.update({
          where: { id: jobId },
          data: {
            status: 'FAILED',
            errorMessage: (err.message || 'Unknown error').slice(0, 500),
            progress: 0,
          },
        });

        throw err;
      }
    },
    {
      connection,
      concurrency: 1,
    }
  );

  worker.on('completed', (job) => console.log(`[Worker] Job ${job.id} finished`));
  worker.on('failed', (job, err) => console.error(`[Worker] Job ${job?.id} failed:`, err.message));

  console.log('✅ Real Render Worker started (Scrape + TTS + FFmpeg)');
  return worker;
}

module.exports = {
  renderQueue,
  addRenderJob,
  startRenderWorker,
};
