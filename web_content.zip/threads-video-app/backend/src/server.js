/**
 * Threads-to-Video Backend Server
 * Phase 1: Auth + Credits + VietQR + Queue skeleton
 */

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');

const config = require('./config');
const routes = require('./routes');
const { startCronJobs } = require('./jobs/cron');
const { startRenderWorker } = require('./queues/renderQueue');

const app = express();

// Ensure upload dir exists
const uploadDir = path.resolve(config.uploadDir);
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Middleware
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(
  cors({
    origin: [config.frontendUrl, 'http://localhost:5173', 'http://localhost:3000'],
    credentials: true,
  })
);
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));

// Rate limit
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api/', limiter);

// Static uploads (videos & thumbs)
app.use('/uploads', express.static(uploadDir));

// Serve Frontend PWA (static)
const frontendPath = path.resolve(__dirname, '../../frontend/public');
app.use(express.static(frontendPath));

// API routes
app.use('/api', routes);

// SPA fallback for PWA
app.get('*', (req, res) => {
  if (req.path.startsWith('/api') || req.path.startsWith('/uploads')) {
    return res.status(404).json({ success: false, message: 'Not found' });
  }
  res.sendFile(path.join(frontendPath, 'index.html'));
});

// Error handler
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ success: false, message: 'Internal server error' });
});

// Start
async function bootstrap() {
  try {
    // Start worker (requires Redis)
    try {
      startRenderWorker();
    } catch (e) {
      console.warn('⚠️  Render worker could not start (Redis may be down):', e.message);
      console.warn('   Jobs will still be created in DB but not processed until Redis is available.');
    }

    // Cron
    startCronJobs();

    app.listen(config.port, () => {
      console.log(`
🚀 Threads-to-Video Backend running
   Port:     ${config.port}
   Env:      ${config.nodeEnv}
   Frontend: ${config.frontendUrl}
   Upload:   ${uploadDir}
   Bank:     ${config.bank.id} - ${config.bank.accountNo} (${config.bank.accountName})
      `);
    });
  } catch (err) {
    console.error('Failed to start server:', err);
    process.exit(1);
  }
}

bootstrap();
