require('dotenv').config();

module.exports = {
  port: parseInt(process.env.PORT || '3001', 10),
  nodeEnv: process.env.NODE_ENV || 'development',
  jwt: {
    secret: process.env.JWT_SECRET || 'dev_secret_change_me_immediately_32chars',
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  },
  redis: {
    host: process.env.REDIS_HOST || '127.0.0.1',
    port: parseInt(process.env.REDIS_PORT || '6379', 10),
    password: process.env.REDIS_PASSWORD || undefined,
  },
  bank: {
    id: process.env.BANK_ID || 'MB',
    accountNo: process.env.BANK_ACCOUNT_NO || '0383940536',
    accountName: process.env.BANK_ACCOUNT_NAME || 'NGUYEN QUOC HUY',
  },
  uploadDir: process.env.UPLOAD_DIR || './uploads',
  videoTtlHours: parseInt(process.env.VIDEO_TTL_HOURS || '24', 10),
  frontendUrl: process.env.FRONTEND_URL || 'http://localhost:5173',
  freeCreditsDaily: 3,
  packages: [
    { amount: 20000, credits: 15, label: '20.000đ = 15 Credit' },
    { amount: 50000, credits: 40, label: '50.000đ = 40 Credit' },
    { amount: 100000, credits: 90, label: '100.000đ = 90 Credit' },
  ],
};
