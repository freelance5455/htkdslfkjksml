/**
 * Seed script: Create default Admin account
 * Username: Admin
 * Password: staffhypervn
 * Role: ADMIN
 * freeCredits & paidCredits: unlimited effectively (checked in code)
 */

const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  const adminUsername = 'Admin';
  const adminPassword = 'staffhypervn';

  const existing = await prisma.user.findUnique({
    where: { username: adminUsername },
  });

  if (existing) {
    console.log('✅ Admin account already exists. Skipping seed.');
    return;
  }

  const passwordHash = await bcrypt.hash(adminPassword, 12);

  const admin = await prisma.user.create({
    data: {
      username: adminUsername,
      passwordHash,
      role: 'ADMIN',
      freeCredits: 999999, // effectively unlimited
      paidCredits: 999999,
      lastFreeReset: new Date(),
    },
  });

  console.log('✅ Seeded Admin account successfully:');
  console.log(`   Username: ${admin.username}`);
  console.log(`   Role: ${admin.role}`);
  console.log(`   ID: ${admin.id}`);
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
