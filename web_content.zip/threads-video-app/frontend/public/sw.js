// Simple service worker for PWA installability
const CACHE = 'threads-video-v1';
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(['/', '/manifest.json'])));
  self.skipWaiting();
});
self.addEventListener('fetch', (e) => {
  // Network first for API, cache for static
  if (e.request.url.includes('/api/')) return;
  e.respondWith(
    caches.match(e.request).then(r => r || fetch(e.request))
  );
});
