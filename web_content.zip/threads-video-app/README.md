# Threads-to-Video Web App (PWA)

Tự động biến link bài viết Threads công khai thành video dọc MP4 9:16 + Thumbnail.

Tương tự các tool như ThreadViral / VuTruCom.

## Tech Stack

**Backend**
- Node.js + Express
- Prisma + SQLite (dễ dev) / PostgreSQL (prod)
- JWT + bcrypt
- BullMQ + Redis (queue ưu tiên Admin)
- node-cron (reset free credit 00:00 Asia/Ho_Chi_Minh)
- Playwright (scrape) → Gemini/OpenAI (script) → Edge-TTS → FFmpeg/Remotion (render)

**Frontend** (Phase 2)
- React + Tailwind CSS (Dark mode)
- PWA (manifest.json + service worker)
- Responsive mobile-first

## Cấu trúc thư mục

```
threads-video-app/
├── backend/
│   ├── prisma/
│   │   ├── schema.prisma
│   │   └── seed.js
│   ├── src/
│   │   ├── config/
│   │   ├── controllers/
│   │   ├── middleware/
│   │   ├── routes/
│   │   ├── services/
│   │   ├── queues/
│   │   ├── jobs/
│   │   ├── utils/
│   │   └── server.js
│   ├── .env.example
│   ├── package.json
│   └── uploads/          # video + thumbnail (auto clean 24h)
├── frontend/             # Phase 2
└── README.md
```

## Database Schema (Prisma)

- **User**: id, username, passwordHash, role (USER|ADMIN), freeCredits (default 3), paidCredits (default 0), lastFreeReset
- **Transaction**: id, userId, amount (VND), credits, content (NAP <uid> <code>), status (PENDING|APPROVED|REJECTED)
- **RenderJob**: id, userId, threadsUrl / threadsUrls (bulk), status, progress, priority, heldCreditType, videoPath, thumbnailPath, expiresAt

## Tài khoản mặc định (Seed)

```
Username: Admin
Password: staffhypervn
Role: ADMIN
```

Admin có:
- Huy hiệu ADMIN
- Credit ∞ (không trừ)
- High Priority Queue
- Bulk Render (nhiều link cùng lúc)
- Admin Top-up Dashboard (duyệt nạp)

## Hệ thống Credit 2 ví

| Ví            | Mặc định | Reset hàng ngày          | Ghi chú                  |
|---------------|----------|--------------------------|--------------------------|
| free_credits  | 3        | 00:00 Asia/Ho_Chi_Minh   | Không cộng dồn           |
| paid_credits  | 0        | Không bao giờ            | Từ nạp VietQR            |

**Hold → Deduct → Refund**:
1. Khi tạo job: hold 1 free trước, hết free mới hold paid
2. Render thành công: giữ nguyên (đã hold = đã trừ)
3. Lỗi: refund đúng ví đã hold

## Nạp Credit (VietQR MB Bank)

Cấu hình trong `.env`:
```
BANK_ID=MB
BANK_ACCOUNT_NO=0383940536
BANK_ACCOUNT_NAME=NGUYEN QUOC HUY
```

Gói:
- 20.000đ = 15 Credit
- 50.000đ = 40 Credit
- 100.000đ = 90 Credit

Luồng:
1. User chọn gói → tạo Transaction PENDING + mã `NAP <uid> <code>`
2. Hiển thị ảnh VietQR động: `https://img.vietqr.io/image/MB-0383940536-compact2.png?...`
3. User chuyển khoản → bấm "Tôi đã chuyển khoản"
4. Admin vào tab Duyệt nạp → kiểm tra app MB Bank → Duyệt (+Credit) hoặc Từ chối

## Chạy Backend (Phase 1)

### Yêu cầu
- Node.js >= 18
- Redis (cho BullMQ)
- (Tùy chọn) Playwright browsers sau này

```bash
cd backend
cp .env.example .env
# Sửa JWT_SECRET, DATABASE_URL nếu cần

npm install
npx prisma generate
npx prisma migrate dev --name init
npm run prisma:seed

# Chạy Redis (nếu chưa có)
# docker run -d -p 6379:6379 redis:alpine

npm run dev
```

API base: `http://localhost:3001/api`

### Endpoints chính

**Auth**
- `POST /auth/register` `{ username, password }`
- `POST /auth/login` `{ username, password }`
- `GET  /auth/me` (Bearer token)

**Transactions**
- `GET  /transactions/packages`
- `POST /transactions/create` `{ amount: 20000|50000|100000 }`
- `POST /transactions/:id/confirm`
- `GET  /transactions/my`

**Admin**
- `GET  /admin/transactions/pending`
- `POST /admin/transactions/:id/approve`
- `POST /admin/transactions/:id/reject`

**Jobs**
- `POST /jobs/create` `{ url: "https://www.threads.net/..." }` hoặc `{ urls: [...] }` (admin)
- `GET  /jobs`
- `GET  /jobs/:id`
- `GET  /jobs/:id/download?type=video|thumbnail`

## Phase tiếp theo

2. Frontend React + Tailwind + PWA (dark mode, progress bar, VietQR modal, Admin dashboard)
3. Full pipeline:
   - Playwright scrape post + comments + avatar
   - Gemini API filter comment hay + chia nhịp kịch bản
   - Edge-TTS (vi-VN) + karaoke subtitle
   - FFmpeg / Remotion render khung Threads style trên nền 9:16
4. Deploy (Docker + Nginx + Redis + PostgreSQL)

## Ghi chú quan trọng

- Worker hiện tại là **MOCK** (simulate progress 15→35→55→75→95→100). File video thật sẽ được tạo ở phase pipeline.
- Redis bắt buộc để queue chạy. Nếu không có Redis, job vẫn được lưu DB nhưng không process.
- File video/thumbnail tự xóa sau 24h (cron).

---
Author: Senior Fullstack & Video Automation Developer
Date: 2026-11-23
