FIXSIS 2.0 - ANDROID PROJESI

Bu klasor, mevcut FixSis HTML uygulamasini Android WebView uygulamasi olarak paketlemek icin hazirlandi.

APK OLUSTURMA:
1. Bilgisayara Android Studio kurun.
2. Android Studio > Open ile bu klasoru secin.
3. Gradle senkronizasyonunun tamamlanmasini bekleyin.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) secin.
5. APK, app/build/outputs/apk/debug/app-debug.apk konumunda olusur.

Notlar:
- Uygulama internet izniyle calisir; Firebase ve CDN kaynaklari icin internet gerekir.
- WebView yerel depolamasi aciktir; uygulama verileri silinmedigi surece cihazda kalir.
- Bu ortamda Android SDK/Gradle ve internet erisimi olmadigindan dogrudan APK derlemesi yapilamadi.
