# Al Saif Communication — Simple Daily Hisab

## Start
1. Extract the ZIP file.
2. Open `index.html` in Chrome on your Android phone.
3. Select the business date once at the top. Every sale and wallet entry you save is assigned to that date.
4. Use **Daily Hisab** to see all figures grouped by date.

## Simplified features
- No stock management and no separate Easypaisa/JazzCash account selection
- One simple wallet ledger
- Wallet transaction amount and commission fields
- Separate commission totals for transfer/receive and cash withdrawal
- Sales total, cost, and sales profit shown separately
- Daily total profit = sales profit + all wallet commissions
- Date range report includes every date, even dates with zero activity
- Edit/delete entries, JSON backup/restore, CSV report export
- Responsive mobile layout and Urdu/English direction toggle

## Storage note
This version saves to the browser's localStorage on this device only. Clearing browser data can erase records. Export JSON backups regularly. It does not provide cloud sync or multi-device login.
