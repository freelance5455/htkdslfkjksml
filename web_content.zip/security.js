/* Kurumsal Envanter — offline administrative access gate.
   PBKDF2 protects an admin password verifier; it is NOT database encryption or
   server-enforced authorization. Physical/local browser access still matters. */
(function(){
'use strict';
const KEY='kurumsal_envanter_admin_auth_v1';
const SESS='kurumsal_envanter_admin_session_v1';
const LOCK_MS=5*60*1000, IDLE_MS=20*60*1000, ITERATIONS=310000;
const te=new TextEncoder();
const b64=(bytes)=>btoa(String.fromCharCode(...bytes));
const from64=str=>Uint8Array.from(atob(str),ch=>ch.charCodeAt(0));
const read=()=>{try{return JSON.parse(localStorage.getItem(KEY))||null;}catch{return null;}};
const save=value=>localStorage.setItem(KEY,JSON.stringify(value));
const bytesEqual=(a,b)=>{if(a.length!==b.length)return false;let x=0;for(let i=0;i<a.length;i++)x|=a[i]^b[i];return x===0;};
async function derive(pass,salt,iters){
 const key=await crypto.subtle.importKey('raw',te.encode(pass),'PBKDF2',false,['deriveBits']);
 return new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',salt,iterations:iters,hash:'SHA-256'},key,256));
}
function validate(pass){return typeof pass==='string'&&pass.length>=12&&pass.length<=128;}
async function create(pass){
 if(read())throw new Error('Yönetici parolası zaten oluşturulmuş.');
 if(!validate(pass))throw new Error('Parola 12–128 karakter olmalıdır.');
 const salt=crypto.getRandomValues(new Uint8Array(16));const digest=await derive(pass,salt,ITERATIONS);
 save({v:1,salt:b64(salt),hash:b64(digest),iterations:ITERATIONS,failures:0,lockedUntil:0,createdAt:new Date().toISOString()});
 sessionStorage.setItem(SESS,JSON.stringify({until:Date.now()+IDLE_MS}));
}
async function verify(pass){
 const conf=read();if(!conf||conf.v!==1||!conf.salt||!conf.hash)return {ok:false,message:'Yönetici parolası ayarlanmamış.'};
 if(conf.lockedUntil&&Date.now()<conf.lockedUntil)return {ok:false,message:'Çok fazla deneme. '+Math.ceil((conf.lockedUntil-Date.now())/60000)+' dakika sonra yeniden deneyin.'};
 let good=false;
 try{good=bytesEqual(await derive(pass,from64(conf.salt),conf.iterations),from64(conf.hash));}catch{return {ok:false,message:'Parola doğrulanamadı.'};}
 if(!good){conf.failures=(conf.failures||0)+1;if(conf.failures>=5){conf.lockedUntil=Date.now()+LOCK_MS;conf.failures=0;}save(conf);return {ok:false,message:conf.lockedUntil?'Çok fazla yanlış deneme. 5 dakika kilitlendi.':'Parola hatalı.'};}
 conf.failures=0;conf.lockedUntil=0;save(conf);
 sessionStorage.setItem(SESS,JSON.stringify({until:Date.now()+IDLE_MS}));
 return {ok:true};
}
function authorized(){
 try{const sess=JSON.parse(sessionStorage.getItem(SESS));return !!(read()&&sess&&sess.until>Date.now());}catch{return false;}
}
function touch(){if(authorized())sessionStorage.setItem(SESS,JSON.stringify({until:Date.now()+IDLE_MS}));}
function logout(){sessionStorage.removeItem(SESS);location.reload();}
async function change(oldPass,newPass){
 if(!validate(newPass))throw new Error('Yeni parola 12–128 karakter olmalıdır.');
 const res=await verify(oldPass);if(!res.ok)throw new Error(res.message);
 const old=read();const salt=crypto.getRandomValues(new Uint8Array(16));const hash=await derive(newPass,salt,ITERATIONS);
 save({...old,iterations:ITERATIONS,salt:b64(salt),hash:b64(hash),failures:0,lockedUntil:0,changedAt:new Date().toISOString()});
 sessionStorage.removeItem(SESS);
}
async function encryptBackup(data,pass){
 if(!validate(pass))throw new Error('Yedek parolası 12–128 karakter olmalıdır.');
 const salt=crypto.getRandomValues(new Uint8Array(16)),iv=crypto.getRandomValues(new Uint8Array(12));
 const raw=await derive(pass,salt,ITERATIONS);const key=await crypto.subtle.importKey('raw',raw,'AES-GCM',false,['encrypt']);
 const cipher=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv},key,te.encode(JSON.stringify(data))));
 return {format:'KENV-ENCRYPTED-BACKUP-1',kdf:'PBKDF2-SHA256',iterations:ITERATIONS,salt:b64(salt),iv:b64(iv),ciphertext:b64(cipher)};
}
async function decryptBackup(data,pass){
 if(!data||data.format!=='KENV-ENCRYPTED-BACKUP-1'||data.kdf!=='PBKDF2-SHA256'||data.iterations!==ITERATIONS)throw Error('Uyumsuz şifreli yedek dosyası.');
 const salt=from64(data.salt),iv=from64(data.iv),cipher=from64(data.ciphertext);
 if(salt.length!==16||iv.length!==12||cipher.length>20*1024*1024)throw Error('Geçersiz yedek boyutu.');
 const raw=await derive(pass,salt,data.iterations),key=await crypto.subtle.importKey('raw',raw,'AES-GCM',false,['decrypt']);
 try{return JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({name:'AES-GCM',iv},key,cipher)));}catch{throw Error('Yedek parolası yanlış veya dosya bozuk.');}
}
function startAdmin(){
 const layout=document.querySelector('.admin-layout');if(!layout)return;
 const shell=document.createElement('div');shell.id='auth-shell';layout.before(shell);layout.hidden=true;
 let started=false;
 const displayAdmin=()=>{
  if(started)return;started=true;layout.hidden=false;shell.hidden=true;
  const script=document.createElement('script');script.src='admin.js';document.body.append(script);
  const onInput=()=>touch();document.addEventListener('click',onInput);document.addEventListener('change',onInput);document.addEventListener('keydown',onInput);
  window.addEventListener('focus',()=>{if(!authorized())location.reload();});
  document.addEventListener('visibilitychange',()=>{if(!document.hidden&&!authorized())location.reload();});
  setInterval(()=>{if(!authorized())location.reload();},30000);
 };
 if(!window.crypto||!crypto.subtle){shell.innerHTML='<main class="auth-page"><div class="auth-card"><h1>Güvenli bağlantı gerekli</h1><p>Bu panelin parola koruması için HTTPS veya yerel kurulum gerekir.</p></div></main>';return;}
 if(authorized()){displayAdmin();return;}
 const setup=!read();
 shell.innerHTML=`<main class="auth-page"><div class="auth-card"><div class="auth-mark">🔐</div><h1>${setup?'Yönetici Parolası Oluştur':'Kullanıcı Paneli Girişi'}</h1><p>${setup?'Bu cihazda ilk kullanım için en az 12 karakterli yönetici parolası belirleyin.':'Yönetim ayarlarına erişmek için parolanızı girin.'}</p><form id="auth-form"><div class="field"><label class="label" for="auth-pass">${setup?'Yeni Yönetici Parolası':'Yönetici Parolası'}</label><input id="auth-pass" class="control" type="password" autocomplete="${setup?'new-password':'current-password'}" required minlength="${setup?12:1}" maxlength="128"></div>${setup?'<div class="field"><label class="label" for="auth-confirm">Parolayı Tekrar Girin</label><input id="auth-confirm" class="control" type="password" autocomplete="new-password" required minlength="12" maxlength="128"></div>':''}<p id="auth-msg" class="auth-message" role="alert" aria-live="polite"></p><button id="auth-submit" class="btn primary" type="submit">${setup?'Parolayı Kaydet ve Aç':'Giriş Yap'}</button></form><p class="auth-footnote">Yerel erişim korumasıdır; kayıtlar bu cihazda depolanır. Parolanızı güvenli yerde saklayın.</p><a class="back" href="index.html">Ana ekrana dön</a></div></main>`;
 shell.querySelector('#auth-form').addEventListener('submit',async(e)=>{
  e.preventDefault();const btn=shell.querySelector('#auth-submit'),msg=shell.querySelector('#auth-msg');btn.disabled=true;msg.textContent='';
  const password=shell.querySelector('#auth-pass').value;
  try{
   if(setup){if(password!==shell.querySelector('#auth-confirm').value)throw Error('Parolalar uyuşmuyor.');await create(password);}
   else{const result=await verify(password);if(!result.ok)throw Error(result.message);}
   displayAdmin();
  }catch(ex){msg.textContent=ex.message||'İşlem tamamlanamadı.';}finally{btn.disabled=false;}
 });
}
window.EnvanterSecurity={startAdmin,authorized,logout,change,encryptBackup,decryptBackup};
})();
