(() => {
  'use strict';

  // Couche de protection côté client pour la version Web → APK.
  // Elle ne remplace pas une sécurité serveur : Syllabe fonctionne localement,
  // donc les données du téléphone ne peuvent pas être considérées comme secrètes.
  const blockedSchemes = /^(javascript|data|vbscript):/i;

  document.addEventListener('click', (event) => {
    const link = event.target && event.target.closest ? event.target.closest('a[href]') : null;
    if (!link) return;
    const href = link.getAttribute('href') || '';
    if (blockedSchemes.test(href.trim())) {
      event.preventDefault();
      event.stopPropagation();
    }
  }, true);

  // Empêche les formulaires d'envoyer des données vers un site externe.
  document.addEventListener('submit', (event) => {
    event.preventDefault();
  }, true);

  // Aucune exécution dynamique de code n'est autorisée par l'application.
  // On neutralise aussi les fenêtres d'ouverture vers une cible externe.
  document.querySelectorAll('a[target]').forEach((a) => a.removeAttribute('target'));
})();
