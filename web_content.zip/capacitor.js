/* Stub for browser development.
   In a real Capacitor build this file is injected by the runtime.
   Keep it empty/minimal so the page loads without 404 errors. */
(function () {
  'use strict';
  if (typeof window.Capacitor === 'undefined') {
    window.Capacitor = {
      isNativePlatform: function () { return false; },
      Plugins: {}
    };
  }
})();
