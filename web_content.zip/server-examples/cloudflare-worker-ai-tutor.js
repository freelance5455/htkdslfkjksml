/**
 * FormulaVerse AI Tutor — example Cloudflare Worker backend.
 *
 * This is REFERENCE CODE to deploy separately (see AI_TUTOR_SETUP.md). It is
 * not executed as part of the FormulaVerse frontend build. It:
 *   1. Accepts { deviceId, system, messages } from the FormulaVerse frontend.
 *   2. Enforces a per-device daily quota using Workers KV (server-side, so
 *      it cannot be bypassed by clearing browser storage or refreshing).
 *   3. Calls OpenAI's Chat Completions API using a secret stored in the
 *      Worker's environment (never exposed to the browser).
 *   4. Returns { reply, remainingToday, resetAt } as plain JSON.
 *
 * Required setup (see AI_TUTOR_SETUP.md for full steps):
 *   - `wrangler secret put OPENAI_API_KEY`
 *   - A KV namespace bound as `AI_QUOTA`
 *   - Environment vars: DAILY_LIMIT, ALLOWED_ORIGIN
 */

export default {
  async fetch(request, env) {
    const origin = env.ALLOWED_ORIGIN || "*";
    const corsHeaders = {
      "Access-Control-Allow-Origin": origin,
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders });
    }

    if (request.method !== "POST") {
      return json({ message: "Method not allowed" }, 405, corsHeaders);
    }

    let body;
    try {
      body = await request.json();
    } catch {
      return json({ message: "Invalid JSON body" }, 400, corsHeaders);
    }

    const { deviceId, system, messages } = body || {};
    if (!deviceId || typeof deviceId !== "string") {
      return json({ message: "Missing deviceId" }, 400, corsHeaders);
    }
    if (!Array.isArray(messages) || messages.length === 0) {
      return json({ message: "Missing messages" }, 400, corsHeaders);
    }
    // Keep requests bounded: cap message count and total length.
    const trimmedMessages = messages.slice(-10).map((m) => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || "").slice(0, 4000),
    }));

    const dailyLimit = parseInt(env.DAILY_LIMIT || "10", 10);
    const todayUTC = new Date().toISOString().slice(0, 10);
    const quotaKey = `${deviceId}:${todayUTC}`;

    const currentRaw = await env.AI_QUOTA.get(quotaKey);
    const current = currentRaw ? parseInt(currentRaw, 10) : 0;

    if (current >= dailyLimit) {
      const resetAt = nextUtcMidnightISO();
      return json(
        { message: `Daily limit of ${dailyLimit} AI messages reached for this device. Resets at ${resetAt}.`, remainingToday: 0, resetAt },
        429,
        corsHeaders
      );
    }

    let reply;
    try {
      reply = await callOpenAI(env.OPENAI_API_KEY, system, trimmedMessages);
    } catch (err) {
      return json({ message: `AI provider error: ${err.message || "unknown error"}` }, 502, corsHeaders);
    }

    // Increment quota AFTER a successful call, with expiry so it
    // self-cleans at the next UTC day boundary (~26h TTL is safely > 24h).
    const newCount = current + 1;
    await env.AI_QUOTA.put(quotaKey, String(newCount), { expirationTtl: 60 * 60 * 26 });

    return json(
      {
        reply,
        remainingToday: Math.max(0, dailyLimit - newCount),
        resetAt: nextUtcMidnightISO(),
      },
      200,
      corsHeaders
    );
  },
};

async function callOpenAI(apiKey, system, messages) {
  if (!apiKey) throw new Error("OPENAI_API_KEY is not configured on the server");

  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "gpt-4o-mini",
      messages: [{ role: "system", content: system || "You are a helpful tutor." }, ...messages],
      temperature: 0.3,
      max_tokens: 700,
    }),
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`OpenAI responded with ${res.status}: ${text.slice(0, 200)}`);
  }

  const data = await res.json();
  const content = data?.choices?.[0]?.message?.content;
  if (!content) throw new Error("OpenAI returned no content");
  return content;
}

function nextUtcMidnightISO() {
  const now = new Date();
  const next = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1, 0, 0, 0));
  return next.toISOString();
}

function json(obj, status, headers) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json", ...headers },
  });
}
