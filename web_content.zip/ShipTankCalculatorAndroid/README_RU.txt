SHIP TANK CALCULATOR — Android project

Проект уже содержит калькулятор и таблицы 8 танков внутри приложения. Интернет приложению не нужен.

Сборка на телефоне:
1) Установить AndroidIDE из официального GitHub Releases.
2) Распаковать этот ZIP.
3) В AndroidIDE открыть папку ShipTankCalculator.
4) Дождаться синхронизации Gradle.
5) Build -> Assemble/Build APK.
6) APK будет в app/build/outputs/apk/debug/app-debug.apk.

Важно: AndroidIDE больше официально не поддерживается, поэтому если оно не запускается на вашем Android, этот проект можно собрать другим Android-совместимым IDE/сервисом.
