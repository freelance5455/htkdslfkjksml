// Adresse du serveur Murmure (sans / à la fin)
window.API_URL = 'http://169.58.54.10:25782';
