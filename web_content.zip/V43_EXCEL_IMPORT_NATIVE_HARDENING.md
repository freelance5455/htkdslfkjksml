V43 Excel Import Native Hardening

- Built directly from V42.
- Android Download Excel Template now saves directly to Downloads on Android 10+ and uses the system Save dialog only as a fallback.
- Android Choose File uses ACTION_GET_CONTENT with ACTION_OPEN_DOCUMENT fallback.
- Android-selected CSV/TXT/XLSX files are parsed natively and passed into the existing preview/validation UI, avoiding WebView XLSX decompression limitations.
- Browser/web fallback remains available through the normal file input and existing parser.
- Existing Supabase import logic is unchanged.
- No Supabase schema/functions were changed.
- Android versionCode 15 / versionName 2.11.
