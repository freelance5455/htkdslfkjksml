package com.ffproxy.engine;

public class FeatureConfig {
    public static volatile boolean esp = false;
    public static volatile boolean aimHead = false;
    public static volatile boolean aimNeck = false;
    public static volatile boolean magicBullet = false;
    public static volatile boolean aimDrag = false;
    public static volatile boolean highFps = false;
    public static volatile boolean antiban = false;

    public static void reset() {
        esp = aimHead = aimNeck = magicBullet = aimDrag = highFps = antiban = false;
    }
}
