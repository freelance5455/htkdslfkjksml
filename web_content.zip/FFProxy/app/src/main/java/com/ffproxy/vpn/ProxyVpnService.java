package com.ffproxy.vpn;

import android.content.Intent;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

import com.ffproxy.engine.PacketEngine;
import com.ffproxy.engine.FeatureConfig;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;

/**
 * Local VPN that captures Free Fire traffic only.
 * PacketEngine decides pass / drop / modify.
 */
public class ProxyVpnService extends VpnService implements Runnable {

    private Thread worker;
    private ParcelFileDescriptor iface;
    private volatile boolean running = false;
    private static final String CH = "ffproxy_vpn";

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (running) return START_STICKY;

        startForegroundNoti();

        Builder b = new Builder();
        b.setSession("FFProxy")
         .addAddress("10.8.0.2", 32)
         .addRoute("0.0.0.0", 0)
         .addDnsServer("8.8.8.8")
         .setMtu(1500)
         .setBlocking(true);

        // Only Free Fire packages – reduces detection surface
        String[] pkgs = {
                "com.dts.freefireth",
                "com.dts.freefiremax",
                "com.dts.freefirein",
                "com.garena.game.freefire",
                "com.garena.game.kgth"
        };
        for (String p : pkgs) {
            try { b.addAllowedApplication(p); } catch (Exception ignored) {}
        }

        iface = b.establish();
        if (iface == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        running = true;
        worker = new Thread(this, "FF-VPN-Worker");
        worker.start();
        return START_STICKY;
    }

    private void startForegroundNoti() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CH, "FF Proxy", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
            Notification n = new Notification.Builder(this, CH)
                    .setContentTitle("FF Proxy")
                    .setContentText("MITM running")
                    .setSmallIcon(android.R.drawable.ic_lock_lock)
                    .build();
            startForeground(1, n);
        }
    }

    @Override
    public void run() {
        FileInputStream in = new FileInputStream(iface.getFileDescriptor());
        FileOutputStream out = new FileOutputStream(iface.getFileDescriptor());
        ByteBuffer buf = ByteBuffer.allocate(32767);

        while (running) {
            try {
                int n = in.read(buf.array());
                if (n > 0) {
                    buf.limit(n);
                    byte[] result = PacketEngine.process(buf.array(), n);
                    if (result != null) {
                        out.write(result);
                    }
                    // null = drop (lag / filter)
                    buf.clear();
                }
            } catch (Exception e) {
                if (running) break;
            }
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        try { if (iface != null) iface.close(); } catch (Exception ignored) {}
        super.onDestroy();
    }
}
