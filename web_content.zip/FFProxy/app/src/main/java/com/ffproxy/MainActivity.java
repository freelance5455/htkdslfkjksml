package com.ffproxy;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.ffproxy.engine.FeatureConfig;
import com.ffproxy.engine.FeatureEngine;
import com.ffproxy.util.RootUtil;
import com.ffproxy.vpn.ProxyVpnService;

/**
 * Free Fire MITM Proxy + Cheat Menu
 * by Trần phi thiên
 *
 * Flow: Root + Overlay + Storage → Start → Menu
 */
public class MainActivity extends Activity {

    private WebView webView;
    private static final int REQ_VPN = 100;
    private static final int REQ_OVERLAY = 101;
    private boolean waitingOverlay = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        gatePermissions();
    }

    private void gatePermissions() {
        // 1. Manage all files
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                    i.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                }
                toast("Cấp quyền Quản lý tất cả tệp");
                return;
            }
        } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE},
                    102);
            return;
        }

        // 2. Overlay
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            waitingOverlay = true;
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, REQ_OVERLAY);
            toast("Cấp quyền Hiển thị trên ứng dụng khác");
            return;
        }

        // 3. Root
        if (!RootUtil.isRoot()) {
            new AlertDialog.Builder(this)
                    .setTitle("Cần ROOT")
                    .setMessage("Proxy MITM + ESP/Aim cần ROOT (Magisk).\nCấp xong mở lại app.")
                    .setPositiveButton("OK", (d, w) -> finish())
                    .setCancelable(false)
                    .show();
            return;
        }

        showStartScreen();
    }

    private void showStartScreen() {
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        webView.addJavascriptInterface(new Bridge(), "Android");
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/start.html");
    }

    private void showMenu() {
        webView.loadUrl("file:///android_asset/menu.html");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (waitingOverlay) {
            waitingOverlay = false;
            gatePermissions();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_VPN) {
            if (resultCode == RESULT_OK) {
                startService(new Intent(this, ProxyVpnService.class));
                showMenu();
                toast("VPN Proxy đã bật");
            } else {
                toast("Bạn từ chối VPN");
            }
        } else if (requestCode == REQ_OVERLAY) {
            gatePermissions();
        }
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }

    public class Bridge {
        @JavascriptInterface
        public void startProxy() {
            Intent prepare = VpnService.prepare(MainActivity.this);
            if (prepare != null) {
                startActivityForResult(prepare, REQ_VPN);
            } else {
                startService(new Intent(MainActivity.this, ProxyVpnService.class));
                runOnUiThread(() -> showMenu());
            }
        }

        @JavascriptInterface
        public void stopProxy() {
            stopService(new Intent(MainActivity.this, ProxyVpnService.class));
            toast("Đã tắt proxy");
        }

        @JavascriptInterface
        public void setEsp(boolean on) { FeatureConfig.esp = on; }

        @JavascriptInterface
        public void setAimHead(boolean on) { FeatureConfig.aimHead = on; }

        @JavascriptInterface
        public void setAimNeck(boolean on) { FeatureConfig.aimNeck = on; }

        @JavascriptInterface
        public void setMagicBullet(boolean on) { FeatureConfig.magicBullet = on; }

        @JavascriptInterface
        public void setAimDrag(boolean on) { FeatureConfig.aimDrag = on; }

        @JavascriptInterface
        public void setHighFps(boolean on) { FeatureConfig.highFps = on; }

        @JavascriptInterface
        public void setAntiban(boolean on) { FeatureConfig.antiban = on; }

        @JavascriptInterface
        public void apply() {
            FeatureEngine.apply(MainActivity.this);
        }

        @JavascriptInterface
        public void reset() {
            FeatureConfig.reset();
            FeatureEngine.reset();
            toast("Reset all");
        }

        @JavascriptInterface
        public boolean isRoot() { return RootUtil.isRoot(); }

        @JavascriptInterface
        public void toast(String m) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, m, Toast.LENGTH_SHORT).show());
        }
    }
}
