package com.ffproxy.engine;

import android.content.Context;
import android.widget.Toast;

import com.ffproxy.util.RootUtil;

/**
 * Applies memory-side / system-side helpers that complement the VPN proxy.
 * ESP / Aim that actually work on current Free Fire almost always need
 * memory read/write (Frida / external) in addition to packet path.
 */
public class FeatureEngine {

    private static final String FF_PKG = "com.dts.freefireth";
    private static final String DIR = "/sdcard/FFProxy/";

    public static void apply(Context ctx) {
        if (!RootUtil.isRoot()) {
            toast(ctx, "Cần ROOT");
            return;
        }
        RootUtil.su("mkdir -p " + DIR);

        StringBuilder msg = new StringBuilder();

        if (FeatureConfig.highFps) {
            // Common system tweaks (device dependent)
            RootUtil.su("setprop debug.sf.high_fps 1 2>/dev/null");
            RootUtil.su("settings put system pointer_speed 7 2>/dev/null");
            msg.append("HighFPS ");
        }

        if (FeatureConfig.antiban) {
            // Basic hygiene
            RootUtil.su("setprop ro.debuggable 0 2>/dev/null");
            RootUtil.su("resetprop ro.boot.verifiedbootstate green 2>/dev/null");
            msg.append("Antiban ");
        }

        if (FeatureConfig.esp || FeatureConfig.aimHead || FeatureConfig.aimNeck
                || FeatureConfig.magicBullet || FeatureConfig.aimDrag) {
            // Write Frida skeleton for memory path (must re-offset every update)
            writeEspScript();
            writeAimScript();
            // Launch only if frida-server is present
            RootUtil.su("frida -U -f " + FF_PKG + " -l " + DIR + "esp.js --no-pause >/dev/null 2>&1 &");
            msg.append("MemoryScripts ");
        }

        toast(ctx, "Applied: " + (msg.length() == 0 ? "none" : msg.toString()));
    }

    public static void reset() {
        RootUtil.su("killall frida 2>/dev/null");
        FeatureConfig.reset();
    }

    private static void writeEspScript() {
        // Skeleton – class/field names MUST be re-derived per version
        String js =
            "// FF ESP skeleton – update offsets after each patch\n" +
            "Java.perform(function(){\n" +
            "  // TODO: find player list / position / team via il2cpp or native\n" +
            "  console.log('[FF] ESP script loaded – waiting offsets');\n" +
            "});\n";
        RootUtil.su("cat > " + DIR + "esp.js << 'EOF'\n" + js + "EOF");
    }

    private static void writeAimScript() {
        String js =
            "// FF Aim / MagicBullet skeleton\n" +
            "Java.perform(function(){\n" +
            "  console.log('[FF] Aim script loaded – waiting offsets');\n" +
            "  // TODO: hook camera / bullet spawn / bone matrix\n" +
            "});\n";
        RootUtil.su("cat > " + DIR + "aim.js << 'EOF'\n" + js + "EOF");
    }

    private static void toast(Context ctx, String m) {
        if (ctx instanceof android.app.Activity) {
            ((android.app.Activity) ctx).runOnUiThread(() ->
                    Toast.makeText(ctx, m, Toast.LENGTH_LONG).show());
        }
    }
}
