# FF Proxy MITM + Menu
**by Trần phi thiên**

## Flow
1. Cấp quyền: Quản lý tệp → Overlay → Root
2. Mở app → **START** → chấp nhận VPN
3. Menu hiện → bật ESP / Aim / MagicBullet / … → **ÁP DỤNG**
4. Vào Free Fire (sảnh → trận)

## Cấu trúc
```
FFProxy/
├── app/src/main/java/com/ffproxy/
│   ├── MainActivity.java
│   ├── vpn/ProxyVpnService.java     ← bắt traffic FF only
│   ├── engine/
│   │   ├── FeatureConfig.java
│   │   ├── PacketEngine.java        ← pass/drop/modify packet
│   │   └── FeatureEngine.java       ← Frida skeleton + system tweaks
│   └── util/RootUtil.java
├── assets/
│   ├── start.html
│   └── menu.html
└── AndroidManifest.xml
```

## Tính năng menu
- ESP
- Aim Head / Aim Neck (ghim cổ)
- Magic Bullet
- Aim Drag
- High FPS
- Antiban mitigation

## Sự thật kỹ thuật (để có hiệu lực thật)
- Traffic Free Fire **mã hóa**. Packet MITM thuần hầu như không đọc được tọa độ/đạn.
- ESP / Aim / MagicBullet hoạt động thực tế gần như luôn cần **memory path** (Frida / external) + offset live.
- Mỗi bản cập nhật Free Fire → offset chết → phải dump + sửa lại script.
- **Không tồn tại antiban 100% vĩnh viễn** trước ACE. Chỉ có giảm risk.

## Build
Android Studio → Open → Sync → Build APK.

## Yêu cầu
- Magisk Root
- Frida server (cho memory scripts)
- Android 8+
