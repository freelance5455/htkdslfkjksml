# Kokari Location : projet APK

Ce dossier contient l'application Kokari Location prête à être transformée en fichier APK (Android).
L'application est dans `www/index.html`. Le reste sert à la compiler.

Important : ce projet n'a pas pu être compilé là où il a été préparé (pas d'accès aux outils Android).
La première compilation peut demander un petit ajustement.

## Ce que l'APK fait et ne fait pas

- Il fonctionne sans internet sur la plupart des téléphones Android récents. Les polices du titre ne s'affichent que si le téléphone est en ligne, sinon une police standard les remplace.
- Les données restent **sur le téléphone** où l'application est installée. Il n'y a pas de sauvegarde en ligne ni de partage entre téléphones dans cette version.
- Si l'application est désinstallée ou si ses données sont effacées, tout est perdu. Utilisez de temps en temps
  « Sécurité et sauvegarde » > « Copier la sauvegarde » et gardez le texte dans une note ou un message à vous-même.
- Le fichier produit est un APK de test (« debug »). Il s'installe directement sur un téléphone.
  Pour le publier sur Google Play, il faudra une version signée (étape suivante).

## Méthode A : compiler avec GitHub (sans installer Android Studio)

1. Créez un compte gratuit sur github.com, puis un nouveau dépôt (« New repository »), par exemple `kokari-location`.
2. Dans le dépôt, « Add file » > « Upload files » : envoyez `package.json`, `capacitor.config.json`
   et le dossier `www` (avec `index.html` dedans).
3. Créez le fichier du workflow : « Add file » > « Create new file », écrivez comme nom
   `.github/workflows/build-apk.yml` (les « / » créent les dossiers), collez le contenu de `workflow/build-apk.yml`,
   puis « Commit changes ».
4. Ouvrez l'onglet « Actions ». Le travail « Construire l'APK » démarre seul (3 à 8 minutes).
   S'il ne démarre pas : choisissez-le dans la liste puis « Run workflow ».
5. Quand il est vert, ouvrez-le et téléchargez « Kokari-Location-APK » en bas de la page (fichier zip contenant `app-debug.apk`).
6. Envoyez l'APK sur le téléphone, ouvrez-le et autorisez l'installation depuis cette source si Android le demande.

Si le travail devient rouge, ouvrez l'étape en erreur, copiez le message et envoyez-le moi : je corrigerai.

## Méthode B : compiler sur un ordinateur avec Android Studio

1. Installez Node.js 20 et Android Studio (avec JDK 17).
2. Dans ce dossier : `npm install`, puis `npx cap add android`, puis `npx cap sync android`.
3. `npx cap open android` ouvre le projet dans Android Studio.
   Menu « Build » > « Build Bundle(s) / APK(s) » > « Build APK(s) ».
4. L'APK se trouve dans `android/app/build/outputs/apk/debug/`.

## Pour modifier l'application

Remplacez `www/index.html` par la nouvelle version, puis recompilez (la méthode A se relance toute seule à chaque envoi).
