NT HAVA ULTRA — ZIP paket
==========================

İçindəkilər:
- index.html: mobilə uyğun hava tətbiqi (HTML/CSS/JavaScript)
- README.txt: bu təlimat

İşə salmaq:
1. ZIP-i açın.
2. index.html faylını internetə yerləşdirin (məsələn, Vercel-də layihənin public qovluğuna).
3. Saytı Android telefonunuzda Chrome ilə açın.
4. İstəyə görə Chrome menyusundan “Ana ekrana əlavə et” seçin.

Funksiyalar:
- Şəhər axtarışı və GPS məkanı
- Cari hava, hiss edilən temperatur, rütubət, külək, yağıntı və UV
- Saatlıq və 7 günlük proqnoz
- Günəşin doğuş/batış vaxtları
- Ağıllı geyim, gəzinti, sürücülük, çətir və UV tövsiyələri
- Hava keyfiyyəti (AQI, PM2.5, PM10 — API məlumatı mövcud olduqda)
- Sadə risk bildirişləri
- Seçilmiş şəhərləri cihazda saxlamaq
- Celsius/Fahrenheit keçidi

Vacib:
- Canlı məlumat üçün internet lazımdır.
- Məlumatlar Open-Meteo API-lərindən alınır. API açarı tələb olunmur.
- GPS icazəsi bəzi brauzerlərdə yalnız HTTPS üzərindən işləyir.
- Bu paket veb tətbiqdir, hazır APK deyil. Android APK üçün ayrıca qablaşdırma mərhələsi lazımdır.
- Bu tətbiqin xəbərdarlıq mətnləri rəsmi fövqəladə xəbərdarlıqları əvəz etmir.
