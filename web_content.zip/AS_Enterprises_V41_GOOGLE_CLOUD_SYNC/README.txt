AS Enterprises V41 - Google Cloud Sync

- Existing V41 UI/features preserved from the latest automatic-stock/backup/restore build.
- App opens directly to Dashboard; login is optional in Settings.
- Google Login uses Firebase Authentication.
- Cloud data is stored under users/{uid}/as_enterprises/main in Firestore.
- Same Google account on Phone 1 + Phone 2 gives the same cloud dataset.
- Local storage + IndexedDB remain as safety fallback; data is not cleared by login.
- google-services.json is included for Android/native build and uses package com.rrprohub.app.

Firebase Console checklist (one-time):
1. Authentication -> Sign-in method -> Google -> Enable.
2. Add the app's SHA-1: 97:51:77:49:AD:93:F6:CB:B9:E0:D6:C1:10:48:D2:54:D3:59:5E:0D
3. Firestore Database -> create database.
4. Publish firestore.rules from this folder (or equivalent rules).
5. If using a hosted web build, add its domain in Authentication -> Settings -> Authorized domains.

Important: This package does not contain private keys or passwords. Actual Firebase Console changes must be done in the project owner account.
