# FF Sensitivity Guide (ZIP project)

A simple, mobile-friendly Free Fire sensitivity guide website.

## Run it
1. Extract this ZIP file.
2. Open `index.html` in Chrome or another browser.
3. Choose your phone brand and play style.
4. Tap **Show suggested settings**.

## Publish it free
You can upload these files to a static website host such as GitHub Pages or Netlify. Upload `index.html`, `style.css`, and `app.js` together.

## Important
- The numbers are starting points, not guaranteed best settings.
- This project does not change game files or automate gameplay.
- It is not affiliated with or endorsed by Garena.
- This is a website project, not an installable Android APK.
