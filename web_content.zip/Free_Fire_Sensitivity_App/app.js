const presets = {
  balanced: {general:190, redDot:185, scope2:175, scope4:160, sniper:95, freeLook:150, fire:48},
  headshot: {general:195, redDot:190, scope2:180, scope4:165, sniper:100, freeLook:150, fire:46},
  rush: {general:200, redDot:195, scope2:180, scope4:155, sniper:90, freeLook:160, fire:50},
  steady: {general:175, redDot:170, scope2:160, scope4:145, sniper:85, freeLook:140, fire:44}
};

function showSettings() {
  const style = document.getElementById('playstyle').value;
  const brand = document.getElementById('brand').value;
  const model = document.getElementById('model').value.trim();
  const p = {...presets[style]};

  // Gentle starting-point adjustments only; no claim that a brand has one perfect setup.
  if (brand === 'iPhone') { p.general -= 5; p.redDot -= 5; }
  if (brand === 'Samsung' || brand === 'Redmi' || brand === 'Realme') { p.fire += 1; }
  if (brand === 'OPPO' || brand === 'Vivo') { p.general -= 2; }

  document.getElementById('general').textContent = p.general;
  document.getElementById('redDot').textContent = p.redDot;
  document.getElementById('scope2').textContent = p.scope2;
  document.getElementById('scope4').textContent = p.scope4;
  document.getElementById('sniper').textContent = p.sniper;
  document.getElementById('freeLook').textContent = p.freeLook;
  document.getElementById('fireSize').textContent = p.fire + '%';
  document.getElementById('dpi').textContent = 'Keep default DPI first';

  const device = model ? `${brand} ${model}` : brand;
  document.getElementById('resultNote').textContent =
    `Starting point for ${device}. Test in Training Ground; change one value by 5–10 points at a time. These are community-style suggestions, not official or guaranteed settings.`;
}
document.getElementById('generate').addEventListener('click', showSettings);
showSettings();
