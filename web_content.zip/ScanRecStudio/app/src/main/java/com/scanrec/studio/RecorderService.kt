package com.scanrec.studio

import android.Manifest
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.os.SystemClock
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.io.File

class RecorderService : Service() {
    companion object {
        const val STOP = "scanrec.STOP"
        @Volatile var startedAt = 0L
    }

    private var proj: MediaProjection? = null
    private var rec: MediaRecorder? = null
    private var vd: VirtualDisplay? = null
    private var file: File? = null

    override fun onBind(i: Intent?): IBinder? = null

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == STOP) { stopRec(); stopSelf(); return START_NOT_STICKY }
        val n = notif("Recording screen")
        if (Build.VERSION.SDK_INT >= 29) {
            var t = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            if (Build.VERSION.SDK_INT >= 30 && hasMic()) t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(1, n, t)
        } else startForeground(1, n)
        @Suppress("DEPRECATION")
        val data = i?.getParcelableExtra<Intent>("data")
        val code = i?.getIntExtra("code", 0) ?: 0
        if (data != null) startRec(code, data) else stopSelf()
        return START_NOT_STICKY
    }

    private fun startRec(code: Int, data: Intent) {
        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val p = mpm.getMediaProjection(code, data)
            p.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopRec() } }, null)
            proj = p
            val dm = resources.displayMetrics
            val w = dm.widthPixels and 1.inv()
            val hh = dm.heightPixels and 1.inv()
            val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES)
            val out = File(dir, "rec_${System.currentTimeMillis()}.mp4")
            file = out
            val r = MediaRecorder()
            if (hasMic()) r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            if (hasMic()) r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setVideoSize(w, hh)
            r.setVideoFrameRate(30)
            r.setVideoEncodingBitRate(8_000_000)
            r.setOutputFile(out.path)
            r.prepare()
            vd = p.createVirtualDisplay("rec", w, hh, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
            r.start()
            rec = r
            startedAt = SystemClock.elapsedRealtime()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start recording: ${e.message}", Toast.LENGTH_LONG).show()
            stopRec(); stopSelf()
        }
    }

    private fun stopRec() {
        val was = startedAt > 0
        startedAt = 0
        try { rec?.stop() } catch (_: Exception) {}
        rec?.release(); rec = null
        vd?.release(); vd = null
        proj?.stop(); proj = null
        if (was) Toast.makeText(this, "Saved: ${file?.path}", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() { stopRec(); super.onDestroy() }
}
