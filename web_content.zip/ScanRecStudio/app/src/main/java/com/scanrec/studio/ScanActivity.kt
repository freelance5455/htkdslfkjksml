package com.scanrec.studio

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Scan text from a picture or from your drawing.
 *  - "AI online" reads ANY language (Urdu, Arabic, Hindi, Chinese ...) using your Anthropic API key.
 *  - "Offline" engines run on the phone (Latin, Devanagari, Chinese, Japanese, Korean). They do NOT read Urdu/Arabic.
 */
class ScanActivity : AppCompatActivity() {
    companion object { const val MODEL = "claude-sonnet-5-5" }

    private var bmp: Bitmap? = null
    private lateinit var img: ImageView
    private lateinit var out: TextView
    private lateinit var spin: Spinner

    private val engines = listOf(
        "AI online - all languages (Urdu, Arabic, Hindi, ...)",
        "Offline - Latin (English, French, ...)",
        "Offline - Devanagari (Hindi, Marathi, ...)",
        "Offline - Chinese",
        "Offline - Japanese",
        "Offline - Korean"
    )

    private val pick = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) setBitmap(decode(uri))
    }

    private fun setBitmap(b: Bitmap?) {
        bmp = b
        img.setImageBitmap(b)
        if (b == null) Toast.makeText(this, "Could not open image", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; minWidth = 0; minimumWidth = 0; setOnClickListener { f() } }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(28), dp(12), dp(8)) }
        root.addView(TextView(this).apply { text = "AI Scan"; textSize = 22f })
        spin = Spinner(this).apply { adapter = ArrayAdapter(this@ScanActivity, android.R.layout.simple_spinner_dropdown_item, engines) }
        root.addView(spin)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(btn("Pick image") { pick.launch("image/*") }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(btn("Scan") { scan() }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(btn("API key") { askKey() }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)
        img = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER }
        root.addView(img, LinearLayout.LayoutParams(-1, dp(220)))
        out = TextView(this).apply {
            textSize = 16f; setTextIsSelectable(true)
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }
        root.addView(ScrollView(this).apply { addView(out) }, LinearLayout.LayoutParams(-1, 0, 1f))
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottom.addView(btn("Copy") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("scan", out.text))
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(btn("Close") { finish() }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(bottom)
        setContentView(root)

        intent.getStringExtra("path")?.let { setBitmap(BitmapFactory.decodeFile(it)) }
    }

    private fun prefs() = getSharedPreferences("scanrec", MODE_PRIVATE)

    private fun askKey() {
        val et = EditText(this).apply { hint = "sk-ant-..."; setSingleLine(); setText(prefs().getString("key", "")) }
        AlertDialog.Builder(this)
            .setTitle("Anthropic API key")
            .setMessage("Needed only for 'AI online' (reads Urdu & every language). Stored on this phone only.")
            .setView(et)
            .setPositiveButton("Save") { _, _ -> prefs().edit().putString("key", et.text.toString().trim()).apply() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun scan() {
        val b = bmp ?: run { Toast.makeText(this, "Pick an image first", Toast.LENGTH_SHORT).show(); return }
        val pos = spin.selectedItemPosition
        out.text = "Scanning..."
        if (pos == 0) {
            val key = prefs().getString("key", "") ?: ""
            if (key.isBlank()) { out.text = ""; askKey(); return }
            Thread {
                try {
                    val r = aiScan(b, key)
                    runOnUiThread { done(b, r) }
                } catch (e: Exception) {
                    runOnUiThread { out.text = "Error: ${e.message}" }
                }
            }.start()
        } else {
            val rec: TextRecognizer = when (pos) {
                1 -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                2 -> TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
                3 -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
                4 -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
                else -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
            }
            rec.process(InputImage.fromBitmap(b, 0))
                .addOnSuccessListener { done(b, it.text) }
                .addOnFailureListener { out.text = "Error: ${it.message}" }
        }
    }

    private fun done(b: Bitmap, text: String) {
        if (text.isBlank()) { out.text = "(no text found)"; return }
        out.text = text
        HistoryStore.add(this, "scan", text.trim().replace("\n", " ").take(40), b, text)
    }

    private fun decode(uri: Uri): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var sample = 1
        while (maxOf(o.outWidth, o.outHeight) / sample > 2048) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
    } catch (e: Exception) { null }

    private fun aiScan(src: Bitmap, key: String): String {
        val max = 1568f
        val k = minOf(1f, max / maxOf(src.width, src.height))
        val w = (src.width * k).toInt().coerceAtLeast(1)
        val h = (src.height * k).toInt().coerceAtLeast(1)
        val flat = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(flat)
        c.drawColor(Color.WHITE)
        c.drawBitmap(Bitmap.createScaledBitmap(src, w, h, true), 0f, 0f, null)
        val bos = ByteArrayOutputStream()
        flat.compress(Bitmap.CompressFormat.JPEG, 90, bos)
        val b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)

        val prompt = "Read all the text in this image (printed or handwritten), in ANY language or script " +
            "(Urdu, Arabic, Hindi, Chinese, English, ...). Return only the exact text in its original " +
            "language and script, keeping line breaks. If there is no text, describe the drawing in one short sentence."
        val content = JSONArray()
            .put(JSONObject().put("type", "image").put("source",
                JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", b64)))
            .put(JSONObject().put("type", "text").put("text", prompt))
        val body = JSONObject().put("model", MODEL).put("max_tokens", 2000)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))

        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 20000; conn.readTimeout = 60000
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-api-key", key)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val txt = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) throw Exception("HTTP $code ${txt.take(200)}")
        val arr = JSONObject(txt).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i)
            if (p.optString("type") == "text") sb.append(p.getString("text"))
        }
        return sb.toString().trim()
    }
}
