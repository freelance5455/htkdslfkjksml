package com.scanrec.studio

import android.graphics.BitmapFactory
import android.os.Bundle
import android.text.format.DateFormat
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.MediaController
import android.widget.VideoView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** Everything you drew, scanned or launched. Tap an item to view, save, relaunch or delete it. */
class HistoryActivity : AppCompatActivity() {
    private lateinit var list: ListView
    private lateinit var empty: TextView
    private var items = listOf<Entry>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = (resources.displayMetrics.density * 12).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(p, p * 3, p, p) }
        root.addView(TextView(this).apply { text = "History"; textSize = 22f })
        empty = TextView(this).apply { text = "Nothing here yet"; setPadding(0, p, 0, p) }
        root.addView(empty)
        list = ListView(this)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        list.setOnItemClickListener { _, _, pos, _ -> open(items[pos]) }
    }

    override fun onResume() { super.onResume(); reload() }

    private fun label(e: Entry): String {
        val icon = when (e.type) { "draw" -> "🎨"; "scan" -> "🔎"; "video" -> "🎬"; else -> "🎮" }
        val t = DateFormat.format("dd MMM HH:mm", e.time)
        return "$icon  ${e.title}\n      $t"
    }

    private fun reload() {
        items = HistoryStore.all(this)
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items.map { label(it) })
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun open(e: Entry) {
        val pad = (resources.displayMetrics.density * 12).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        val file = HistoryStore.fileOf(this, e)
        if (e.type == "video" && file != null && file.exists()) {
            val vv = VideoView(this)
            val mc = MediaController(this)
            mc.setAnchorView(vv)
            vv.setMediaController(mc)
            vv.setVideoPath(file.absolutePath)
            vv.setOnPreparedListener { vv.start() }
            col.addView(vv, LinearLayout.LayoutParams(-1, (resources.displayMetrics.density * 320).toInt()))
        } else if (file != null && file.exists()) {
            col.addView(ImageView(this).apply {
                adjustViewBounds = true
                setImageBitmap(BitmapFactory.decodeFile(file.absolutePath))
            }, LinearLayout.LayoutParams(-1, -2))
        }
        if (!e.text.isNullOrEmpty()) {
            col.addView(TextView(this).apply {
                text = e.text; textSize = 16f; setTextIsSelectable(true)
                textDirection = View.TEXT_DIRECTION_FIRST_STRONG
                textAlignment = View.TEXT_ALIGNMENT_VIEW_START
                setPadding(0, pad, 0, 0)
            })
        }
        if (e.type == "launch") {
            col.addView(TextView(this).apply { text = "${e.title}\n${e.pkg}"; textSize = 16f })
        }
        val b = AlertDialog.Builder(this)
            .setTitle(e.title.take(40))
            .setView(ScrollView(this).apply { addView(col) })
            .setNeutralButton("Delete") { _, _ -> HistoryStore.remove(this, e.id); reload() }
            .setNegativeButton("Close", null)
        if (e.type == "launch") {
            b.setPositiveButton("Launch") { _, _ ->
                val i = e.pkg?.let { packageManager.getLaunchIntentForPackage(it) }
                if (i != null) startActivity(i) else Toast.makeText(this, "App not installed", Toast.LENGTH_SHORT).show()
            }
        } else {
            b.setPositiveButton("Save") { _, _ ->
                val msgs = mutableListOf<String>()
                if (file != null && file.exists()) msgs += if (e.type == "video") Exporter.saveVideo(this, file) else Exporter.saveImage(this, file)
                if (!e.text.isNullOrEmpty()) msgs += Exporter.saveText(this, e.text)
                Toast.makeText(this, msgs.joinToString("\n"), Toast.LENGTH_LONG).show()
            }
        }
        b.show()
    }
}
