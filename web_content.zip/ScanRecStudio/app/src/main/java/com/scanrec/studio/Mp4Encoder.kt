package com.scanrec.studio

import android.graphics.Bitmap
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File

/** Turns a list of drawn frames into a real H.264 MP4 (no external library). */
object Mp4Encoder {
    fun encode(frames: List<Bitmap>, animFps: Int, out: File) {
        require(frames.isNotEmpty())
        val outFps = 30
        val hold = maxOf(1, outFps / maxOf(1, animFps))
        val k = minOf(1f, 1280f / maxOf(frames[0].width, frames[0].height))
        val w = maxOf(16, ((frames[0].width * k).toInt() / 16) * 16)
        val h = maxOf(16, ((frames[0].height * k).toInt() / 16) * 16)

        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            setInteger(MediaFormat.KEY_BIT_RATE, 4_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, outFps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val info = MediaCodec.BufferInfo()
        var track = -1
        var started = false

        fun drain(wait: Boolean) {
            while (true) {
                val i = codec.dequeueOutputBuffer(info, if (wait) 10000L else 0L)
                if (i == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (!wait) return
                } else if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = muxer.addTrack(codec.outputFormat); muxer.start(); started = true
                } else if (i >= 0) {
                    val buf = codec.getOutputBuffer(i)!!
                    if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                    if (info.size > 0 && started) {
                        buf.position(info.offset); buf.limit(info.offset + info.size)
                        muxer.writeSampleData(track, buf, info)
                    }
                    codec.releaseOutputBuffer(i, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                }
            }
        }

        try {
            var pts = 0L
            val px = IntArray(w * h)
            for (f in frames) {
                val sb = if (f.width == w && f.height == h) f else Bitmap.createScaledBitmap(f, w, h, true)
                sb.getPixels(px, 0, w, 0, 0, w, h)
                repeat(hold) {
                    var idx = codec.dequeueInputBuffer(10000L)
                    while (idx < 0) { drain(false); idx = codec.dequeueInputBuffer(10000L) }
                    fill(codec.getInputImage(idx)!!, px, w, h)
                    codec.queueInputBuffer(idx, 0, w * h * 3 / 2, pts, 0)
                    pts += 1_000_000L / outFps
                    drain(false)
                }
            }
            var idx = codec.dequeueInputBuffer(10000L)
            while (idx < 0) { drain(false); idx = codec.dequeueInputBuffer(10000L) }
            codec.queueInputBuffer(idx, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            drain(true)
        } finally {
            try { codec.stop() } catch (_: Exception) {}
            codec.release()
            if (started) try { muxer.stop() } catch (_: Exception) {}
            muxer.release()
        }
    }

    private fun fill(img: Image, px: IntArray, w: Int, h: Int) {
        val yp = img.planes[0]; val up = img.planes[1]; val vp = img.planes[2]
        val yb = yp.buffer; val ub = up.buffer; val vb = vp.buffer
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                val p = px[row + x]
                val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
                yb.put(y * yp.rowStride + x * yp.pixelStride, (((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).toByte())
            }
        }
        for (y in 0 until h / 2) {
            for (x in 0 until w / 2) {
                val p = px[(2 * y) * w + 2 * x]
                val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
                ub.put(y * up.rowStride + x * up.pixelStride, (((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128).toByte())
                vb.put(y * vp.rowStride + x * vp.pixelStride, (((112 * r - 94 * g - 18 * b + 128) shr 8) + 128).toByte())
            }
        }
    }
}
