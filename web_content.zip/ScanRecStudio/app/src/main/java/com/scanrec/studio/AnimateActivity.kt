package com.scanrec.studio

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File

/** Flipbook animation maker: draw frames, play them, export a real MP4. */
class AnimateActivity : AppCompatActivity() {
    private lateinit var dv: DrawView
    private lateinit var lbl: TextView
    private lateinit var playBtn: Button
    private lateinit var fpsBtn: Button
    private val frames = mutableListOf<Bitmap>()
    private var idx = 0
    private var fps = 8
    private var playing = false
    private var pi = 0
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            if (!playing || frames.isEmpty()) return
            dv.load(frames[pi % frames.size])
            lbl.text = "Playing ${pi % frames.size + 1}/${frames.size}"
            pi++
            h.postDelayed(this, 1000L / fps)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; minWidth = 0; minimumWidth = 0; setOnClickListener { f() }
        }
        dv = DrawView(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(28), dp(8), dp(8)) }

        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(Color.BLACK, Color.RED, Color.BLUE, Color.rgb(0, 150, 60), Color.rgb(255, 152, 0), Color.rgb(156, 39, 176))
            .forEach { col ->
                val sw = View(this).apply { setBackgroundColor(col); setOnClickListener { dv.color = col } }
                tools.addView(sw, LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            }
        tools.addView(btn("Eraser") { dv.color = Color.WHITE })
        tools.addView(btn("-") { dv.size = maxOf(2f, dv.size - 3f) })
        tools.addView(btn("+") { dv.size = minOf(60f, dv.size + 3f) })
        tools.addView(btn("Undo") { dv.undo() })
        root.addView(HorizontalScrollView(this).apply { addView(tools) })
        root.addView(dv, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(6) })

        lbl = TextView(this).apply { text = "Frame 1/1"; textSize = 14f; setPadding(dp(4), dp(6), dp(4), dp(2)) }
        root.addView(lbl)

        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun w1(v: View) = r1.addView(v, LinearLayout.LayoutParams(0, -2, 1f))
        w1(btn("<") { stopIfPlaying(); ensure(); if (idx > 0) go(idx - 1) })
        w1(btn(">") { stopIfPlaying(); ensure(); if (idx < frames.size - 1) go(idx + 1) })
        w1(btn("+ Frame") { stopIfPlaying(); newFrame() })
        w1(btn("Delete") { stopIfPlaying(); deleteFrame() })
        root.addView(r1)

        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun w2(v: View) = r2.addView(v, LinearLayout.LayoutParams(0, -2, 1f))
        playBtn = btn("Play") { togglePlay() }
        fpsBtn = btn("FPS 8") {
            fps = when (fps) { 4 -> 8; 8 -> 12; 12 -> 24; else -> 4 }
            fpsBtn.text = "FPS $fps"
        }
        w2(playBtn); w2(fpsBtn)
        w2(btn("Export MP4") { export() })
        w2(btn("Close") { finish() })
        root.addView(r2)
        setContentView(root)
    }

    private fun ensure() { if (frames.isEmpty()) dv.snapshot()?.let { frames.add(it) } }

    private fun commit() {
        ensure()
        dv.snapshot()?.let { if (idx < frames.size) frames[idx] = it }
    }

    private fun updateLabel() { lbl.text = "Frame ${idx + 1}/${maxOf(1, frames.size)}" }

    private fun go(i: Int) {
        commit()
        idx = i
        dv.load(frames[i])
        dv.ghost = if (i > 0) frames[i - 1] else null
        updateLabel()
    }

    private fun newFrame() {
        commit()
        val blank = Bitmap.createBitmap(dv.width, dv.height, Bitmap.Config.ARGB_8888)
        blank.eraseColor(Color.WHITE)
        frames.add(idx + 1, blank)
        go(idx + 1)
    }

    private fun deleteFrame() {
        ensure()
        if (frames.size <= 1) { dv.load(null); frames[0] = dv.snapshot() ?: frames[0]; return }
        frames.removeAt(idx)
        idx = minOf(idx, frames.size - 1)
        dv.load(frames[idx])
        dv.ghost = if (idx > 0) frames[idx - 1] else null
        updateLabel()
    }

    private fun togglePlay() {
        if (!playing) {
            commit()
            playing = true; dv.locked = true; dv.ghost = null; pi = 0
            playBtn.text = "Stop"
            h.post(tick)
        } else stopIfPlaying()
    }

    private fun stopIfPlaying() {
        if (!playing) return
        playing = false; dv.locked = false
        h.removeCallbacks(tick)
        playBtn.text = "Play"
        go(minOf(idx, frames.size - 1))
    }

    private fun export() {
        stopIfPlaying()
        commit()
        if (frames.isEmpty()) return
        val copy = frames.toList()
        val rate = fps
        Toast.makeText(this, "Creating video...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val f = File(cacheDir, "anim_${System.currentTimeMillis()}.mp4")
                Mp4Encoder.encode(copy, rate, f)
                HistoryStore.addVideo(this, "Animation (${copy.size} frames)", f)
                val msg = Exporter.saveVideo(this, f)
                runOnUiThread { Toast.makeText(this, "Video ready. $msg", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Export failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    override fun onDestroy() { h.removeCallbacks(tick); super.onDestroy() }
}
