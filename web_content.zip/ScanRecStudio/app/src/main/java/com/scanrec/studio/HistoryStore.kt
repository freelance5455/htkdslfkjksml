package com.scanrec.studio

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** One history row: a drawing, a scan result, or a launched game. */
data class Entry(
    val id: Long, val type: String, val title: String, val time: Long,
    val file: String?, val text: String?, val pkg: String?
)

object HistoryStore {
    private fun dir(c: Context) = File(c.filesDir, "history").apply { mkdirs() }
    private fun index(c: Context) = File(dir(c), "history.json")

    @Synchronized
    fun all(c: Context): List<Entry> {
        val f = index(c)
        if (!f.exists()) return emptyList()
        return try {
            val a = JSONArray(f.readText())
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Entry(
                    o.getLong("id"), o.getString("type"), o.getString("title"), o.getLong("time"),
                    if (o.has("file")) o.getString("file") else null,
                    if (o.has("text")) o.getString("text") else null,
                    if (o.has("pkg")) o.getString("pkg") else null
                )
            }
        } catch (e: Exception) { emptyList() }
    }

    private fun write(c: Context, list: List<Entry>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("type", it.type).put("title", it.title)
                .put("time", it.time).put("file", it.file).put("text", it.text).put("pkg", it.pkg))
        }
        index(c).writeText(a.toString())
    }

    @Synchronized
    fun add(c: Context, type: String, title: String, bitmap: Bitmap? = null, text: String? = null, pkg: String? = null) {
        val id = System.currentTimeMillis()
        var name: String? = null
        if (bitmap != null) {
            name = "$id.png"
            File(dir(c), name).outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        }
        val old = all(c)
        old.drop(299).forEach { e -> e.file?.let { File(dir(c), it).delete() } }
        write(c, (listOf(Entry(id, type, title, id, name, text, pkg)) + old).take(300))
    }

    @Synchronized
    fun addVideo(c: Context, title: String, src: File) {
        val id = System.currentTimeMillis()
        val name = "$id.mp4"
        src.copyTo(File(dir(c), name), true)
        val old = all(c)
        old.drop(299).forEach { e -> e.file?.let { File(dir(c), it).delete() } }
        write(c, (listOf(Entry(id, "video", title, id, name, null, null)) + old).take(300))
    }

    @Synchronized
    fun remove(c: Context, id: Long) {
        val list = all(c)
        list.firstOrNull { it.id == id }?.file?.let { File(dir(c), it).delete() }
        write(c, list.filter { it.id != id })
    }

    fun fileOf(c: Context, e: Entry): File? = e.file?.let { File(dir(c), it) }
}

/** Saves images / text so they appear in the phone gallery and Downloads. */
object Exporter {
    fun saveImage(c: Context, src: File): String {
        val name = "ScanRec_${System.currentTimeMillis()}.png"
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/ScanRec")
                }
                val uri = c.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)!!
                c.contentResolver.openOutputStream(uri)!!.use { o -> src.inputStream().use { it.copyTo(o) } }
                "Saved to Pictures/ScanRec"
            } else {
                val d = File(c.getExternalFilesDir(Environment.DIRECTORY_PICTURES), name)
                src.copyTo(d, true)
                "Saved: ${d.absolutePath}"
            }
        } catch (e: Exception) { "Save failed: ${e.message}" }
    }

    fun saveVideo(c: Context, src: File): String {
        val name = "ScanRec_${System.currentTimeMillis()}.mp4"
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ScanRec")
                }
                val uri = c.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)!!
                c.contentResolver.openOutputStream(uri)!!.use { o -> src.inputStream().use { it.copyTo(o) } }
                "Saved to Movies/ScanRec"
            } else {
                val d = File(c.getExternalFilesDir(Environment.DIRECTORY_MOVIES), name)
                src.copyTo(d, true)
                "Saved: ${d.absolutePath}"
            }
        } catch (e: Exception) { "Save failed: ${e.message}" }
    }

    fun saveText(c: Context, text: String): String {
        val name = "ScanRec_${System.currentTimeMillis()}.txt"
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = c.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
                c.contentResolver.openOutputStream(uri)!!.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                "Saved to Downloads/$name"
            } else {
                val d = File(c.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), name)
                d.writeText(text, Charsets.UTF_8)
                "Saved: ${d.absolutePath}"
            }
        } catch (e: Exception) { "Save failed: ${e.message}" }
    }
}
