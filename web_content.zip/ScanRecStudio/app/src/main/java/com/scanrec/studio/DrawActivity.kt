package com.scanrec.studio

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File

/** Canvas: touching the screen puts a small dot, dragging draws a line. */
class DrawView(ctx: Context) : View(ctx) {
    private var bmp: Bitmap? = null
    private var cv: Canvas? = null
    private val undoList = mutableListOf<Bitmap>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()
    private var lx = 0f
    private var ly = 0f
    var color = Color.BLACK
    var size = 8f
    var locked = false
    var ghost: Bitmap? = null            // faint previous frame (onion skin) for animation
    private val ghostPaint = Paint().apply { alpha = 70 }

    /** Replace the canvas content with [b] (or blank white). */
    fun load(b: Bitmap?) {
        val c = cv ?: return
        c.drawColor(Color.WHITE)
        if (b != null) c.drawBitmap(Bitmap.createScaledBitmap(b, width, height, true), 0f, 0f, null)
        undoList.clear()
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        if (w <= 0 || h <= 0) return
        val nb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(nb)
        c.drawColor(Color.WHITE)
        bmp?.let { c.drawBitmap(it, 0f, 0f, null) }
        bmp = nb; cv = c
    }

    override fun onDraw(canvas: Canvas) {
        bmp?.let { canvas.drawBitmap(it, 0f, 0f, null) }
        ghost?.let { canvas.drawBitmap(Bitmap.createScaledBitmap(it, width, height, false), 0f, 0f, ghostPaint) }
    }

    private fun pushUndo() {
        val b = bmp ?: return
        undoList.add(b.copy(Bitmap.Config.ARGB_8888, false))
        if (undoList.size > 8) undoList.removeAt(0)
    }

    fun undo() {
        if (undoList.isEmpty()) return
        val last = undoList.removeAt(undoList.size - 1)
        cv?.drawBitmap(last, 0f, 0f, null)
        invalidate()
    }

    fun clear() { pushUndo(); cv?.drawColor(Color.WHITE); invalidate() }

    fun snapshot(): Bitmap? = bmp?.copy(Bitmap.Config.ARGB_8888, false)

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (locked) return true
        val c = cv ?: return false
        val x = e.x; val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pushUndo()
                paint.color = color; paint.strokeWidth = size; dot.color = color
                c.drawCircle(x, y, maxOf(size / 2f, 3f), dot)   // tap = small dot
                path.reset(); path.moveTo(x, y); lx = x; ly = y
            }
            MotionEvent.ACTION_MOVE -> {
                path.quadTo(lx, ly, (x + lx) / 2f, (y + ly) / 2f)
                c.drawPath(path, paint)
                lx = x; ly = y
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> path.reset()
        }
        invalidate()
        return true
    }
}

class DrawActivity : AppCompatActivity() {
    private lateinit var dv: DrawView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; minWidth = 0; minimumWidth = 0; setOnClickListener { f() }
        }
        dv = DrawView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(28), dp(8), dp(8))
        }
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(Color.BLACK, Color.RED, Color.BLUE, Color.rgb(0, 150, 60), Color.rgb(255, 152, 0), Color.rgb(156, 39, 176))
            .forEach { col ->
                val sw = View(this).apply { setBackgroundColor(col); setOnClickListener { dv.color = col } }
                tools.addView(sw, LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            }
        tools.addView(btn("Eraser") { dv.color = Color.WHITE })
        tools.addView(btn("-") { dv.size = maxOf(2f, dv.size - 3f) })
        tools.addView(btn("+") { dv.size = minOf(60f, dv.size + 3f) })
        tools.addView(btn("Undo") { dv.undo() })
        tools.addView(btn("Clear") { dv.clear() })
        root.addView(HorizontalScrollView(this).apply { addView(tools) })
        root.addView(dv, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(6) })

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun w(v: View) = bottom.addView(v, LinearLayout.LayoutParams(0, -2, 1f))
        w(btn("Save") { save() })
        w(btn("AI Scan") { scan() })
        w(btn("History") { startActivity(Intent(this, HistoryActivity::class.java)) })
        w(btn("Close") { finish() })
        root.addView(bottom)
        setContentView(root)
    }

    private fun tmp(bm: Bitmap, name: String): File {
        val f = File(cacheDir, name)
        f.outputStream().use { bm.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return f
    }

    private fun save() {
        val bm = dv.snapshot() ?: return
        HistoryStore.add(this, "draw", "Drawing", bitmap = bm)
        val msg = Exporter.saveImage(this, tmp(bm, "draw_save.png"))
        Toast.makeText(this, "Saved in History. $msg", Toast.LENGTH_LONG).show()
    }

    private fun scan() {
        val bm = dv.snapshot() ?: return
        val f = tmp(bm, "draw_scan.png")
        startActivity(Intent(this, ScanActivity::class.java).putExtra("path", f.absolutePath))
    }
}
