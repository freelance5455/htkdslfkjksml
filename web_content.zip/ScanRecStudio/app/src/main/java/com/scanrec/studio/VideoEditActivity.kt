package com.scanrec.studio

import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File

/** Simple real video editor: pick a video, trim, rotate, mute, export MP4. */
@androidx.annotation.OptIn(markerClass = [UnstableApi::class])
class VideoEditActivity : AppCompatActivity() {
    private var uri: Uri? = null
    private var durMs = 0L
    private var rot = 0
    private lateinit var vv: VideoView
    private lateinit var info: TextView
    private lateinit var sStart: SeekBar
    private lateinit var sEnd: SeekBar
    private lateinit var mute: CheckBox
    private lateinit var status: TextView

    private val pick = registerForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) load(u) }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; minWidth = 0; minimumWidth = 0; setOnClickListener { f() } }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(28), dp(12), dp(8)) }
        root.addView(TextView(this).apply { text = "Video Editor"; textSize = 22f })
        vv = VideoView(this)
        root.addView(vv, LinearLayout.LayoutParams(-1, 0, 1f))
        info = TextView(this).apply { text = "Pick a video"; setPadding(0, dp(6), 0, dp(2)) }
        root.addView(info)
        sStart = SeekBar(this).apply { max = 1000 }
        sEnd = SeekBar(this).apply { max = 1000; progress = 1000 }
        val l = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) {
                if (u) { if (sStart.progress >= sEnd.progress) { if (sb === sStart) sStart.progress = maxOf(0, sEnd.progress - 1) else sEnd.progress = minOf(1000, sStart.progress + 1) } ; refresh() }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) { if (sb === sStart) vv.seekTo((durMs * sStart.progress / 1000).toInt()) }
        }
        sStart.setOnSeekBarChangeListener(l); sEnd.setOnSeekBarChangeListener(l)
        root.addView(TextView(this).apply { text = "Start" }); root.addView(sStart)
        root.addView(TextView(this).apply { text = "End" }); root.addView(sEnd)
        mute = CheckBox(this).apply { text = "Mute audio" }
        root.addView(mute)
        status = TextView(this)
        root.addView(status)
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r1.addView(btn("Pick video") { pick.launch("video/*") }, LinearLayout.LayoutParams(0, -2, 1f))
        r1.addView(btn("Play") { if (vv.isPlaying) vv.pause() else vv.start() }, LinearLayout.LayoutParams(0, -2, 1f))
        r1.addView(btn("Rotate") { rot = (rot + 90) % 360; refresh() }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(r1)
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r2.addView(btn("Export") { export() }, LinearLayout.LayoutParams(0, -2, 1f))
        r2.addView(btn("Close") { finish() }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(r2)
        setContentView(root)
    }

    private fun fmt(ms: Long) = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)

    private fun refresh() {
        val a = durMs * sStart.progress / 1000
        val b = durMs * sEnd.progress / 1000
        info.text = "Keep ${fmt(a)} - ${fmt(b)} of ${fmt(durMs)}   rotate $rot°"
    }

    private fun load(u: Uri) {
        uri = u
        val m = MediaMetadataRetriever()
        durMs = try {
            m.setDataSource(this, u)
            m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) { 0L } finally { try { m.release() } catch (_: Exception) {} }
        vv.setVideoURI(u)
        vv.setOnPreparedListener { vv.seekTo(1) }
        sStart.progress = 0; sEnd.progress = 1000; rot = 0
        refresh()
    }

    private fun export() {
        val u = uri ?: run { Toast.makeText(this, "Pick a video first", Toast.LENGTH_SHORT).show(); return }
        val s = durMs * sStart.progress / 1000
        val e = durMs * sEnd.progress / 1000
        if (e - s < 500) { Toast.makeText(this, "Selection too short", Toast.LENGTH_SHORT).show(); return }
        val clip = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(s).setEndPositionMs(e).build()
        val item = MediaItem.Builder().setUri(u).setClippingConfiguration(clip).build()
        val fx = mutableListOf<Effect>()
        if (rot != 0) fx.add(ScaleAndRotateTransformation.Builder().setRotationDegrees(rot.toFloat()).build())
        val edited = EditedMediaItem.Builder(item)
            .setRemoveAudio(mute.isChecked)
            .setEffects(Effects(emptyList(), fx))
            .build()
        val out = File(cacheDir, "edit_${System.currentTimeMillis()}.mp4")
        status.text = "Exporting..."
        val t = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    HistoryStore.addVideo(this@VideoEditActivity, "Edited video", out)
                    status.text = Exporter.saveVideo(this@VideoEditActivity, out)
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    status.text = "Export failed: ${exportException.message}"
                }
            })
            .build()
        t.start(edited, out.absolutePath)
    }
}
