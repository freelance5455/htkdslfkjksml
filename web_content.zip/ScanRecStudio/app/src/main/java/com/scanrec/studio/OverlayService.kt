package com.scanrec.studio

import android.app.ActivityManager
import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class OverlayService : Service() {
    companion object { @Volatile var running = false }

    private lateinit var wm: WindowManager
    private var box: LinearLayout? = null
    private lateinit var bubble: TextView
    private lateinit var stats: TextView
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            val rec = RecorderService.startedAt
            bubble.text = if (rec > 0) {
                val s = (SystemClock.elapsedRealtime() - rec) / 1000
                "REC %02d:%02d".format(s / 60, s % 60)
            } else "READY"
            stats.text = statsText()
            h.postDelayed(this, 1000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val n = notif("Overlay is on")
        if (Build.VERSION.SDK_INT >= 34) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(2, n)
        if (box == null) build()
        running = true
        return START_STICKY
    }

    private fun statsText(): String {
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val lvl = (b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0) * 100 / (b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100)
        return "RAM free ${mi.availMem / 1048576} MB\nBattery $lvl%  $temp C"
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

    private fun build() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dp = resources.displayMetrics.density
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 300 }
        val pad = (8 * dp).toInt()
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xDD101418.toInt())
            setPadding(pad, pad, pad, pad)
        }
        bubble = TextView(this).apply { text = "READY"; setTextColor(0xFF00E5A0.toInt()); textSize = 16f; setPadding(pad, pad, pad, pad) }
        stats = TextView(this).apply { setTextColor(0xFFFFFFFF.toInt()); textSize = 12f }
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        panel.addView(stats)
        panel.addView(btn("Record") {
            if (RecorderService.startedAt > 0) Toast.makeText(this, "Already recording", Toast.LENGTH_SHORT).show()
            else startActivity(Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("rec", true))
        })
        panel.addView(btn("Stop") {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.STOP))
        })
        panel.addView(btn("Hide") { stopSelf() })
        b.addView(bubble); b.addView(panel)
        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; dx = e.rawX; dy = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - dx).toInt(); val my = (e.rawY - dy).toInt()
                    if (abs(mx) > 10 || abs(my) > 10) moved = true
                    lp.x = sx + mx; lp.y = sy + my
                    wm.updateViewLayout(b, lp)
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) panel.visibility = if (panel.visibility == View.GONE) View.VISIBLE else View.GONE
                    wm.updateViewLayout(b, lp)
                }
            }
            true
        }
        wm.addView(b, lp)
        box = b
        h.post(tick)
    }

    override fun onDestroy() {
        running = false
        h.removeCallbacks(tick)
        box?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        box = null
        super.onDestroy()
    }
}
