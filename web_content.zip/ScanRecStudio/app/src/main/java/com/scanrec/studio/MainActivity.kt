package com.scanrec.studio

import android.Manifest
import android.app.ActivityManager
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

data class App(val name: String, val pkg: String, val game: Boolean)

class MainActivity : AppCompatActivity() {
    private var all = listOf<App>()
    private var shown = listOf<App>()
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var search: EditText
    private lateinit var gamesOnly: CheckBox

    private val projection = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == RESULT_OK && d != null) {
            val i = Intent(this, RecorderService::class.java).putExtra("code", r.resultCode).putExtra("data", d)
            ContextCompat.startForegroundService(this, i)
            Toast.makeText(this, "Recording started. Go back to your game.", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        }
    }
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = (resources.displayMetrics.density * 12).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(p, p * 3, p, p) }
        root.addView(TextView(this).apply { text = "ScanRec Studio"; textSize = 22f })
        search = EditText(this).apply { hint = "Search app or game"; setSingleLine() }
        gamesOnly = CheckBox(this).apply { text = "Games only"; setOnCheckedChangeListener { _, _ -> filter() } }
        root.addView(search)
        root.addView(gamesOnly)
        val row = LinearLayout(this)
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        row.addView(btn("Overlay") { toggleOverlay() })
        row.addView(btn("Record") { askRecord() })
        row.addView(btn("Turbo") { turbo() })
        root.addView(row)
        val list = ListView(this)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf<String>())
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> launchApp(shown[pos].pkg) }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { filter() }
        })
        loadApps()
        filter()
        val req = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) req += Manifest.permission.POST_NOTIFICATIONS
        perms.launch(req.toTypedArray())
        handle(intent)
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handle(i) }

    private fun handle(i: Intent?) {
        if (i?.getBooleanExtra("rec", false) == true) { i.removeExtra("rec"); askRecord() }
    }

    private fun loadApps() {
        val pm = packageManager
        all = pm.getInstalledApplications(0)
            .filter { it.packageName != packageName && pm.getLaunchIntentForPackage(it.packageName) != null }
            .map {
                val g = it.category == ApplicationInfo.CATEGORY_GAME || (it.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                App(pm.getApplicationLabel(it).toString(), it.packageName, g)
            }
            .sortedBy { it.name.lowercase() }
    }

    private fun filter() {
        if (!::adapter.isInitialized) return
        val q = search.text.toString().trim().lowercase()
        shown = all.filter { (!gamesOnly.isChecked || it.game) && it.name.lowercase().contains(q) }
        adapter.clear(); adapter.addAll(shown.map { it.name }); adapter.notifyDataSetChanged()
    }

    private fun needOverlay(): Boolean {
        if (Settings.canDrawOverlays(this)) return false
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        Toast.makeText(this, "Allow 'Display over other apps', then try again", Toast.LENGTH_LONG).show()
        return true
    }

    private fun toggleOverlay() {
        if (needOverlay()) return
        if (OverlayService.running) stopService(Intent(this, OverlayService::class.java))
        else ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
    }

    private fun askRecord() {
        val m = getSystemService(MediaProjectionManager::class.java)
        projection.launch(m.createScreenCaptureIntent())
    }

    private fun launchApp(pkg: String) {
        if (needOverlay()) return
        if (!OverlayService.running) ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
        packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
    }

    private fun turbo() {
        val am = getSystemService(ActivityManager::class.java)
        fun free(): Long { val m = ActivityManager.MemoryInfo(); am.getMemoryInfo(m); return m.availMem / 1048576 }
        val before = free()
        all.forEach { am.killBackgroundProcesses(it.pkg) }
        window.decorView.postDelayed({
            Toast.makeText(this, "Free RAM: $before MB -> ${free()} MB (background apps only)", Toast.LENGTH_LONG).show()
        }, 900)
    }
}
