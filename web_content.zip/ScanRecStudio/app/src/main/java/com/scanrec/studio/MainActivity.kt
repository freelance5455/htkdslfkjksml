package com.scanrec.studio

import android.Manifest
import android.app.ActivityManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.Environment
import android.os.StatFs
import android.content.pm.ApplicationInfo
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

data class App(val name: String, val pkg: String, val game: Boolean, val installed: Boolean = true)

/** Popular games: if one is not installed it still shows in the list and opens its Play Store page. */
val GAME_CATALOG = listOf(
    "PUBG Mobile" to "com.tencent.ig", "BGMI" to "com.pubg.imobile",
    "Free Fire" to "com.dts.freefireth", "Free Fire MAX" to "com.dts.freefiremax",
    "Call of Duty Mobile" to "com.activision.callofduty.shooter", "Clash of Clans" to "com.supercell.clashofclans",
    "Clash Royale" to "com.supercell.clashroyale", "Brawl Stars" to "com.supercell.brawlstars",
    "Minecraft" to "com.mojang.minecraftpe", "Roblox" to "com.roblox.client",
    "Subway Surfers" to "com.kiloo.subwaysurf", "Temple Run 2" to "com.imangi.templerun2",
    "Mobile Legends" to "com.mobile.legends", "Genshin Impact" to "com.miHoYo.GenshinImpact",
    "Among Us" to "com.innersloth.spacemafia", "Candy Crush Saga" to "com.king.candycrushsaga",
    "8 Ball Pool" to "com.miniclip.eightballpool", "Carrom Pool" to "com.miniclip.carrom",
    "eFootball" to "com.konami.pesam", "Asphalt 9" to "com.gameloft.android.ANMP.GloftA9HM"
)

class MainActivity : AppCompatActivity() {
    private var all = listOf<App>()
    private var shown = listOf<App>()
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var search: EditText
    private lateinit var gamesOnly: CheckBox
    private lateinit var live: TextView
    private val ui = Handler(Looper.getMainLooper())
    private val liveTick = object : Runnable { override fun run() { live.text = deviceInfo(); ui.postDelayed(this, 2000) } }

    private val projection = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == RESULT_OK && d != null) {
            val i = Intent(this, RecorderService::class.java).putExtra("code", r.resultCode).putExtra("data", d)
            ContextCompat.startForegroundService(this, i)
            Toast.makeText(this, "Recording started. Go back to your game.", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        }
    }
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = (resources.displayMetrics.density * 12).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(p, p * 3, p, p) }
        root.addView(TextView(this).apply { text = "ScanRec Studio"; textSize = 22f })
        live = TextView(this).apply { textSize = 12f; setPadding(0, 0, 0, p / 2) }
        root.addView(live)
        search = EditText(this).apply { hint = "Search app or game"; setSingleLine() }
        gamesOnly = CheckBox(this).apply { text = "Games only"; setOnCheckedChangeListener { _, _ -> filter() } }
        root.addView(search)
        root.addView(gamesOnly)
        val row = LinearLayout(this)
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        row.addView(btn("Overlay") { toggleOverlay() })
        row.addView(btn("Record") { askRecord() })
        row.addView(btn("Turbo") { turbo() })
        root.addView(row)
        val row2 = LinearLayout(this)
        row2.addView(btn("Draw") { startActivity(Intent(this, DrawActivity::class.java)) })
        row2.addView(btn("AI Scan") { startActivity(Intent(this, ScanActivity::class.java)) })
        row2.addView(btn("History") { startActivity(Intent(this, HistoryActivity::class.java)) })
        root.addView(row2)
        val row3 = LinearLayout(this)
        row3.addView(btn("Animate") { startActivity(Intent(this, AnimateActivity::class.java)) })
        row3.addView(btn("Video Edit") { startActivity(Intent(this, VideoEditActivity::class.java)) })
        row3.addView(btn("Premium") { startActivity(Intent(this, PremiumActivity::class.java)) })
        root.addView(row3)
        val list = ListView(this)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf<String>())
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            val a = shown[pos]
            AlertDialog.Builder(this)
                .setTitle(a.name)
                .setMessage(if (a.installed) a.pkg else "Not installed. Launch opens Play Store.")
                .setPositiveButton(if (a.installed) "Launch" else "Install") { _, _ -> launchApp(a) }
                .setNegativeButton("Cancel", null)
                .show()
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { filter() }
        })
        loadApps()
        filter()
        val req = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) req += Manifest.permission.POST_NOTIFICATIONS
        perms.launch(req.toTypedArray())
        handle(intent)
    }

    override fun onResume() {
        super.onResume()
        if (::adapter.isInitialized) { loadApps(); filter() }   // picks up games installed from Play Store
        ui.post(liveTick)
    }

    override fun onPause() { ui.removeCallbacks(liveTick); super.onPause() }

    /** Real numbers from this phone: RAM, battery, temperature, storage. */
    private fun deviceInfo(): String {
        val mi = ActivityManager.MemoryInfo()
        getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = (b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0) * 100 / (b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100)
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, 0)
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val sf = StatFs(Environment.getDataDirectory().path)
        val freeGb = String.format("%.1f", sf.availableBytes / 1073741824.0)
        val chg = if (charging) " (charging)" else ""
        return "RAM free ${mi.availMem / 1048576} / ${mi.totalMem / 1048576} MB   " +
            "Battery ${lvl}%$chg $temp C   Storage free $freeGb GB"
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handle(i) }

    private fun handle(i: Intent?) {
        if (i?.getBooleanExtra("rec", false) == true) { i.removeExtra("rec"); askRecord() }
    }

    private fun loadApps() {
        val pm = packageManager
        all = pm.getInstalledApplications(0)
            .filter { it.packageName != packageName && pm.getLaunchIntentForPackage(it.packageName) != null }
            .map {
                val g = it.category == ApplicationInfo.CATEGORY_GAME || (it.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                App(pm.getApplicationLabel(it).toString(), it.packageName, g)
            }
            .let { installed ->
                val have = installed.map { it.pkg }.toSet()
                installed + GAME_CATALOG.filter { it.second !in have }.map { App(it.first, it.second, true, false) }
            }
            .sortedBy { it.name.lowercase() }
    }

    private fun filter() {
        if (!::adapter.isInitialized) return
        val q = search.text.toString().trim().lowercase()
        shown = all.filter { (!gamesOnly.isChecked || it.game) && it.name.lowercase().contains(q) }
        adapter.clear(); adapter.addAll(shown.map { if (it.installed) it.name else "${it.name}   (Play Store)" }); adapter.notifyDataSetChanged()
    }

    private fun needOverlay(): Boolean {
        if (Settings.canDrawOverlays(this)) return false
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        Toast.makeText(this, "Allow 'Display over other apps', then try again", Toast.LENGTH_LONG).show()
        return true
    }

    private fun toggleOverlay() {
        if (needOverlay()) return
        if (OverlayService.running) stopService(Intent(this, OverlayService::class.java))
        else ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
    }

    private fun askRecord() {
        val m = getSystemService(MediaProjectionManager::class.java)
        projection.launch(m.createScreenCaptureIntent())
    }

    private fun launchApp(a: App) {
        val i = packageManager.getLaunchIntentForPackage(a.pkg)
        if (i == null) { openStore(a); return }          // not installed -> Play Store
        HistoryStore.add(this, "launch", a.name, pkg = a.pkg)
        // Always ensure overlay permission so floating REC/RAM shows inside the game
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Display over other apps' for overlay, then Launch again", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            // still launch the game
        } else {
            if (!OverlayService.running) {
                ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
            }
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun openStore(a: App) {
        Toast.makeText(this, "${a.name} is not installed - opening Play Store", Toast.LENGTH_SHORT).show()
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${a.pkg}")))
        } catch (e: ActivityNotFoundException) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=${a.pkg}")))
        }
    }

    private fun turbo() {
        val am = getSystemService(ActivityManager::class.java)
        fun free(): Long { val m = ActivityManager.MemoryInfo(); am.getMemoryInfo(m); return m.availMem / 1048576 }
        val before = free()
        all.forEach { am.killBackgroundProcesses(it.pkg) }
        window.decorView.postDelayed({
            Toast.makeText(this, "Free RAM: $before MB -> ${free()} MB (background apps only)", Toast.LENGTH_LONG).show()
        }, 900)
    }
}
