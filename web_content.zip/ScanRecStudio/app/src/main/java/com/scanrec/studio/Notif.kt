package com.scanrec.studio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service

fun Service.notif(text: String): Notification {
    val nm = getSystemService(NotificationManager::class.java)
    nm.createNotificationChannel(NotificationChannel("scanrec", "ScanRec", NotificationManager.IMPORTANCE_LOW))
    return Notification.Builder(this, "scanrec")
        .setContentTitle("ScanRec Studio")
        .setContentText(text)
        .setSmallIcon(android.R.drawable.ic_media_play)
        .build()
}
