package com.scanrec.studio

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Premium / VIP unlock screen.
 * Users only REDEEM a code. Codes are generated only by admin
 * from the separate code-generator.html / code_generator.c files.
 * Contact for purchase: 0315-777-42662 (Pakistan)
 */
class PremiumActivity : AppCompatActivity() {

    private val PREF = "scanrec_premium"
    private val KEY_ON = "premium_on"
    private val KEY_CODE = "premium_code"
    private val KEY_USED = "used_codes"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val prefs = getSharedPreferences(PREF, Context.MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(16))
        }

        root.addView(TextView(this).apply {
            text = "⭐ Premium / VIP Unlock"
            textSize = 22f
            setPadding(0, 0, 0, dp(12))
        })

        // ---- Code input on TOP ----
        root.addView(TextView(this).apply {
            text = "Valid code daalo (sirf admin generated code se unlock)"
            textSize = 14f
            setPadding(0, 0, 0, dp(6))
        })

        val codeInput = EditText(this).apply {
            hint = "e.g. VIP-A3K9-P2M7"
            setSingleLine()
            textSize = 16f
        }
        root.addView(codeInput, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(8)
        })

        val status = TextView(this).apply {
            textSize = 14f
            setPadding(0, dp(4), 0, dp(12))
        }
        fun refreshStatus() {
            if (prefs.getBoolean(KEY_ON, false)) {
                status.text = "✅ Premium / VIP active"
                status.setTextColor(0xFF22C55E.toInt())
            } else {
                status.text = "Premium locked — valid code daalo"
                status.setTextColor(0xFF94A3B8.toInt())
            }
        }
        refreshStatus()
        root.addView(status)

        root.addView(Button(this).apply {
            text = "Unlock Premium"
            setOnClickListener {
                val code = codeInput.text.toString().trim().uppercase()
                if (code.isEmpty()) {
                    status.text = "Code daalo"
                    status.setTextColor(0xFFF59E0B.toInt())
                    return@setOnClickListener
                }
                // Format: XXX-XXXX-XXXX
                val okFormat = Regex("^(VIP|GEM|PRE|POI)-[A-Z0-9]{4}-[A-Z0-9]{4}$").matches(code)
                if (!okFormat) {
                    status.text = "❌ Invalid code format"
                    status.setTextColor(0xFFEF4444.toInt())
                    return@setOnClickListener
                }
                val used = prefs.getStringSet(KEY_USED, emptySet())?.toMutableSet() ?: mutableSetOf()
                if (code in used) {
                    status.text = "❌ Code already used"
                    status.setTextColor(0xFFF59E0B.toInt())
                    return@setOnClickListener
                }
                used.add(code)
                prefs.edit()
                    .putBoolean(KEY_ON, true)
                    .putString(KEY_CODE, code)
                    .putStringSet(KEY_USED, used)
                    .apply()
                status.text = "✅ Premium / VIP unlocked!"
                status.setTextColor(0xFF22C55E.toInt())
                Toast.makeText(this@PremiumActivity, "Premium activated", Toast.LENGTH_SHORT).show()
            }
        })

        // ---- Benefits ----
        root.addView(TextView(this).apply {
            text = """
                
                Premium me milta hai:
                • Unlimited video recording (low-end optimised)
                • Face-cam + mic + mute/unmute
                • Live stream support
                • Animate: text, gallery sound, background
                • Button click sounds
                • Points system
                • Strong History
                • VIP / Gemini Pro Max
            """.trimIndent()
            textSize = 14f
            setPadding(0, dp(16), 0, dp(12))
        })

        root.addView(TextView(this).apply {
            text = "Premium kharidne ke liye contact:"
            textSize = 14f
        })
        root.addView(TextView(this).apply {
            text = "0315-777-42662"
            textSize = 22f
            setTextColor(0xFF22C55E.toInt())
            setPadding(0, dp(6), 0, dp(4))
        })
        root.addView(TextView(this).apply {
            text = "(Pakistan) – WhatsApp / Call"
            textSize = 13f
            setPadding(0, 0, 0, dp(16))
        })

        root.addView(Button(this).apply {
            text = "Call / WhatsApp"
            setOnClickListener {
                try {
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:+923157742662")))
                } catch (e: Exception) {
                    Toast.makeText(this@PremiumActivity, "0315-777-42662", Toast.LENGTH_LONG).show()
                }
            }
        })

        root.addView(Button(this).apply {
            text = "Copy Number"
            setOnClickListener {
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("premium", "031577742662"))
                Toast.makeText(this@PremiumActivity, "Number copied", Toast.LENGTH_SHORT).show()
            }
        })

        setContentView(root)
    }
}
