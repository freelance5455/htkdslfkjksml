package com.scanrec.studio

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Premium Shop screen.
 * Contact for purchase: 0315-777-42662 (Pakistan)
 */
class PremiumActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(16))
        }

        root.addView(TextView(this).apply {
            text = "⭐ Premium Shop"
            textSize = 22f
            setPadding(0, 0, 0, dp(12))
        })

        root.addView(TextView(this).apply {
            text = """
                Premium me milta hai:
                • Unlimited video recording (low-end optimised)
                • Face-cam + mic + mute/unmute
                • Live stream support with any app
                • Animate: text overlay, gallery sound, background banners
                • Button click sounds on every control
                • Points system – log your achievements
                • Strong History (original storage files)
                • VIP / Gemini Pro Max one-time codes
            """.trimIndent()
            textSize = 15f
            setPadding(0, 0, 0, dp(16))
        })

        root.addView(TextView(this).apply {
            text = "Premium kharidne ke liye contact:"
            textSize = 14f
        })

        root.addView(TextView(this).apply {
            text = "0315-777-42662"
            textSize = 24f
            setPadding(0, dp(8), 0, dp(4))
            setTextColor(0xFF22C55E.toInt())
        })

        root.addView(TextView(this).apply {
            text = "(Pakistan) – WhatsApp / Call"
            textSize = 13f
            setPadding(0, 0, 0, dp(20))
        })

        fun btn(label: String, action: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { action() }
        }

        root.addView(btn("Call / WhatsApp") {
            try {
                startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:+923157742662")))
            } catch (e: Exception) {
                Toast.makeText(this@PremiumActivity, "0315-777-42662", Toast.LENGTH_LONG).show()
            }
        })

        root.addView(btn("Copy Number") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("premium", "031577742662"))
            Toast.makeText(this, "Number copied: 0315-777-42662", Toast.LENGTH_SHORT).show()
        })

        root.addView(TextView(this).apply {
            text = "\nPoints: recording, launches aur draws se points milte hain. History me original files dikhte hain – click karke save / check kar sakte ho."
            textSize = 13f
            setPadding(0, dp(12), 0, 0)
        })

        setContentView(root)
    }
}
