# ScanRec Studio (native Android, Kotlin)

## Features
- Games list + search + "Games only". Tap = **instant Launch** (if installed) ya Play Store.
- Floating overlay (REC timer, RAM, battery).
- Screen recorder (MediaProjection → MP4, mic optional). Low-end friendly settings.
- Turbo (background processes clear + free RAM).
- Draw (dots/lines, colors, eraser, undo) + AI Scan (offline + online Urdu/Arabic etc.).
- **History** – original storage files (drawings, scans, videos, launches). Click → view / save / relaunch / delete.
- **Animate** – frame-by-frame → real MP4. (Text / sound / background buttons prepared for commercial build.)
- **Video Edit** – trim, rotate, mute → MP4.
- **Premium Shop** – full list of benefits + contact **0315-777-42662** (Pakistan) for purchase.
- Points system note + one-time VIP / Gemini Pro Max codes (see code-generator.html + code_generator.c).

## Code Generator (one-time codes)
- `code-generator.html` – browser me open karo, type select karo, generate. Ek baar use, next day expire.
- `code_generator.c` – compile: `gcc -o code_gen code_generator.c` then `./code_gen VIP user123`

## Build APK
1. Android Studio open → ScanRecStudio folder.
2. Gradle sync → Build APK.
3. Install debug APK on phone.

## First run
Allow "Display over other apps", mic, notifications.
Recordings: Android/data/com.scanrec.studio/files/Movies/

Premium contact: **0315-777-42662**
