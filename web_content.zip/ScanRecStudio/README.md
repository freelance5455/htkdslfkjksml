# ScanRec Studio (native Android, Kotlin)

Features in this build: installed apps/games list with search + "Games only",
tap = launch app and show a draggable floating overlay (REC timer, RAM, battery temp/%),
screen recorder (MediaProjection -> MP4, mic optional), Record/Stop from the overlay,
Turbo (clears background processes, shows free RAM before/after).

NOT in this build: scan/draw, editor, vault, location tools, per-game profiles,
real FPS/CPU/ping, facecam, screenshots. FPS/CPU of other apps are not available to normal apps.

## Build the APK
1. Install Android Studio (Hedgehog or newer) and let it install SDK 34.
2. File > Open > select this ScanRecStudio folder, wait for Gradle sync (needs internet once).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK: app/build/outputs/apk/debug/app-debug.apk -> copy to phone and install.

## First run
Allow "Display over other apps" when asked, allow microphone and notifications.
Recordings are saved in Android/data/com.scanrec.studio/files/Movies/ on the phone.
QUERY_ALL_PACKAGES is fine for personal install but Play Store needs a justification.
