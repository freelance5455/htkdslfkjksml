THE APOCALIPSE ZOMBIE: SURVIVAL — PROJETO ANDROID

Este pacote transforma o jogo HTML incluído em um aplicativo Android offline usando WebView.
O projeto é uma base para gerar APK/AAB; não é um APK já compilado.

COMO GERAR O APK
1. Instale o Android Studio em um computador.
2. Extraia este ZIP.
3. No Android Studio, escolha Open e selecione a pasta ApocalipseZombieAndroid.
4. Aguarde a sincronização do Gradle e instale os componentes do Android SDK solicitados.
5. Para testar: menu Build > Build Bundle(s) / APK(s) > Build APK(s).
6. O Android Studio mostrará a opção para localizar o APK gerado.

PARA PUBLICAR NA GOOGLE PLAY
- Gere um Android App Bundle (.aab) em Build > Generate Signed Bundle / APK.
- Crie e guarde com segurança uma chave de assinatura própria.
- Configure nome, ícone, imagens, classificação indicativa, política de privacidade e os requisitos atuais do Google Play Console.
- A publicação depende da análise e das regras vigentes da Google Play.

OBSERVAÇÕES
- O jogo carrega de app/src/main/assets/index.html e funciona sem hospedagem web.
- Para atualizar o jogo, substitua esse index.html pela nova versão e aumente versionCode/versionName em app/build.gradle.
- Multiplayer online real exige backend/servidor; não está incluído neste projeto offline.
- O HTML incluído é a versão jogável/protótipo atualmente disponível, não a implementação completa de todos os sistemas planejados nas 11 etapas.
- compileSdk 35 e Android Gradle Plugin 8.7.3 são usados nesta base. O Android Studio pode solicitar atualização de SDK/Gradle conforme sua instalação.
