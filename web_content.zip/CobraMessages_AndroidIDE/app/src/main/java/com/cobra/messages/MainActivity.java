package com.cobra.messages;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.*;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends Activity {
 WebView webView;
 // غيّر المفتاح لعبارة طويلة وفريدة، وضع نفس القيمة عند صاحبك.
 static final String SHARED_SECRET = "Cobra-Shared-Secret-Change-This-2026";
 public void onCreate(Bundle b) {
  super.onCreate(b); webView=new WebView(this);
  webView.getSettings().setJavaScriptEnabled(true);
  webView.getSettings().setDomStorageEnabled(true);
  webView.setWebViewClient(new WebViewClient());
  webView.addJavascriptInterface(new CryptoBridge(),"CobraCrypto");
  setContentView(webView); webView.loadUrl("file:///android_asset/index.html");
 }
 SecretKeySpec key() throws Exception {
  byte[] h=MessageDigest.getInstance("SHA-256").digest(SHARED_SECRET.getBytes(StandardCharsets.UTF_8));
  return new SecretKeySpec(h,"AES");
 }
 public class CryptoBridge {
  @JavascriptInterface public String encrypt(String s) {
   try {
    byte[] iv=new byte[12]; new SecureRandom().nextBytes(iv);
    Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
    c.init(Cipher.ENCRYPT_MODE,key(),new GCMParameterSpec(128,iv));
    byte[] e=c.doFinal(s.getBytes(StandardCharsets.UTF_8));
    byte[] all=new byte[iv.length+e.length];
    System.arraycopy(iv,0,all,0,iv.length); System.arraycopy(e,0,all,iv.length,e.length);
    return Base64.encodeToString(all,Base64.NO_WRAP);
   } catch(Exception e){return "ERROR";}
  }
  @JavascriptInterface public String decrypt(String s) {
   try {
    byte[] all=Base64.decode(s.trim(),Base64.DEFAULT); if(all.length<13)return "الرموز ناقصة.";
    byte[] iv=new byte[12], data=new byte[all.length-12];
    System.arraycopy(all,0,iv,0,12); System.arraycopy(all,12,data,0,data.length);
    Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
    c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,iv));
    return new String(c.doFinal(data),StandardCharsets.UTF_8);
   } catch(Exception e){return "فك التشفير فشل؛ اتأكد من الرسالة والمفتاح.";}
  }
 }
}