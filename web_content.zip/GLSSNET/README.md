# GLSSNET – Fondation (étape 1)

Monorepo de développement : `backend/` (FastAPI, PostgreSQL, Redis) et `frontend/` (Next.js, TypeScript).

## Lancer
```
cp .env.example .env     # puis changer SECRET_KEY
docker compose up --build
```
- Interface : http://localhost:3000
- API et documentation : http://localhost:8000/docs
- Santé : http://localhost:8000/api/health

## Depuis un téléphone
Aucune installation locale : créer un dépôt GitHub, y importer ce dossier, puis ouvrir un
GitHub Codespace (ou travailler avec Claude Code) et lancer les commandes ci-dessus.

## Contenu
- Comptes : `POST /api/auth/register`, `POST /api/auth/login`, `GET /api/auth/me` (JWT, mots de passe hachés avec bcrypt).
- Recherche : `GET /api/search?q=...&module=web|images|news`, avec quota quotidien (Redis) et historique.
- `services/providers.py` : branchement du fournisseur de recherche (renvoie une liste vide tant qu'il n'est pas configuré).
- Tables : users, search_history, collections, collection_items.

## Avant la production
Migrations Alembic, limitation de débit sur /auth, vérification d'e-mail, CORS et HTTPS restrictifs,
gestion des secrets, sauvegardes, tests automatisés.

## Maquette HTML
`maquette/index.html` : maquette de l'interface (fichier unique, à ouvrir dans Chrome).
L'IA, l'analyse de photo et la dictée avancée ne fonctionnent que dans la version en ligne ouverte depuis Claude.
