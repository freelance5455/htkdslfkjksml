"use client";
import { useState } from "react";

const API = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";
type Result = { title: string; url: string; snippet: string };

export default function Home() {
  const [q, setQ] = useState("");
  const [results, setResults] = useState<Result[]>([]);
  const [notice, setNotice] = useState("");

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!q.trim()) return;
    try {
      const r = await fetch(`${API}/api/search?q=${encodeURIComponent(q)}`);
      const data = await r.json();
      setResults(data.results ?? []);
      setNotice(data.notice ?? (r.ok ? "" : data.detail ?? "Erreur"));
    } catch {
      setNotice("Serveur injoignable.");
    }
  }

  return (
    <main>
      <h1>GLSSNET</h1>
      <p className="muted" style={{ textAlign: "center" }}>The World at Your Search.</p>
      <form onSubmit={onSubmit}>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Rechercher sur GLSSNET" />
        <button type="submit">Chercher</button>
      </form>
      {notice && <p className="muted">{notice}</p>}
      {results.map((r) => (
        <div className="res" key={r.url}>
          <a href={r.url}>{r.title}</a>
          <div className="muted">{r.snippet}</div>
        </div>
      ))}
    </main>
  );
}
