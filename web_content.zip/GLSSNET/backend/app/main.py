from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .config import settings
from .db import Base, engine
from .routers import auth, search

app = FastAPI(title="GLSSNET API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in settings.cors_origins.split(",")],
    allow_methods=["GET", "POST"],
    allow_headers=["Authorization", "Content-Type"],
)
app.include_router(auth.router)
app.include_router(search.router)


@app.on_event("startup")
def create_tables():
    # Développement seulement : remplacer par des migrations (Alembic) avant la production.
    Base.metadata.create_all(engine)


@app.get("/api/health")
def health():
    return {"status": "ok"}
