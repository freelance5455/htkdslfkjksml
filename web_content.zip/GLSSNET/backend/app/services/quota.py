import datetime as dt

import redis

from ..config import settings

_r = redis.from_url(settings.redis_url, decode_responses=True)


def check_and_count(ident: str, limit: int) -> bool:
    """Retourne False si la limite journalière est dépassée."""
    key = f"quota:search:{ident}:{dt.date.today().isoformat()}"
    try:
        n = _r.incr(key)
        if n == 1:
            _r.expire(key, 86400)
        return n <= limit
    except redis.RedisError:
        return True  # si Redis est indisponible, on ne bloque pas
