"""Fournisseurs de recherche. Brancher ici une API de recherche autorisée.

Aucun faux résultat n'est renvoyé : sans fournisseur configuré, la liste est vide.
"""
from dataclasses import dataclass

from ..config import settings


@dataclass
class Result:
    title: str
    url: str
    snippet: str


class SearchProvider:
    def search(self, q: str, module: str) -> list[Result]:
        raise NotImplementedError


class StubProvider(SearchProvider):
    def search(self, q: str, module: str) -> list[Result]:
        return []


def get_provider() -> SearchProvider:
    if settings.search_provider == "stub":
        return StubProvider()
    # TODO: ajouter ici le fournisseur choisi (clé dans SEARCH_API_KEY, côté serveur uniquement)
    raise RuntimeError(f"Fournisseur inconnu : {settings.search_provider}")
