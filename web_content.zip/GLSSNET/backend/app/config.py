from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = "postgresql+psycopg://glssnet:glssnet@db:5432/glssnet"
    redis_url: str = "redis://redis:6379/0"
    secret_key: str = "change-me"
    access_token_minutes: int = 60
    free_daily_searches: int = 50
    search_provider: str = "stub"
    search_api_key: str = ""
    cors_origins: str = "http://localhost:3000"


settings = Settings()
