from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.orm import Session

from ..config import settings
from ..db import get_db
from ..models import SearchHistory, User
from ..security import optional_user
from ..services.providers import get_provider
from ..services.quota import check_and_count

router = APIRouter(prefix="/api", tags=["search"])
MODULES = {"web", "images", "news"}  # périmètre du MVP


@router.get("/search")
def search(
    request: Request,
    q: str = Query(..., min_length=1, max_length=300),
    module: str = Query("web"),
    user: User | None = Depends(optional_user),
    db: Session = Depends(get_db),
):
    if module not in MODULES:
        raise HTTPException(400, "Module non disponible")
    ident = f"u{user.id}" if user else f"ip{request.client.host if request.client else 'x'}"
    if not check_and_count(ident, settings.free_daily_searches):
        raise HTTPException(429, "Limite quotidienne atteinte")
    results = get_provider().search(q.strip(), module)
    if user:
        db.add(SearchHistory(user_id=user.id, query=q.strip(), module=module))
        db.commit()
    notice = "" if results else "Aucun fournisseur de recherche configuré."
    return {"query": q, "module": module, "results": [r.__dict__ for r in results], "notice": notice}
