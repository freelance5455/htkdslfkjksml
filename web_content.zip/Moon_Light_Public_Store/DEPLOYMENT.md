# Moon Light public game store — starter build

## Included
- Responsive Moon Light web app/PWA
- Public catalog, search, category filters, saved library, game player and HTML downloads
- Creator-only publishing and unpublishing, protected by a server-side admin token
- SQLite catalog database and server-side game file storage
- Capacitor configuration for later Android/iOS native project generation

## Run locally
Install Node.js LTS, then in this folder:

```sh
npm install
```

Set a long secret admin token and start the server.

macOS/Linux:
```sh
export ADMIN_TOKEN='use-a-long-random-secret-of-at-least-32-characters'
npm start
```

Windows PowerShell:
```powershell
$env:ADMIN_TOKEN='use-a-long-random-secret-of-at-least-32-characters'
npm start
```

Open `http://localhost:3000`. The creator token is entered only on the Publish or Creator Hub screens. Keep it private.

## Make it public
1. Deploy to a Node.js host that supports a persistent process and persistent disk/volume.
2. Configure `ADMIN_TOKEN` on the host. Do not commit it to source control or place it in frontend code.
3. Enable HTTPS.
4. Keep the `data/` directory persistent and back it up; it contains the database and uploaded HTML games.
5. Test publishing, opening, downloading, and unpublishing from a second device.
6. Add a privacy policy, terms, abuse/reporting contact, and manual review/moderation before opening widely.

Do not use ephemeral serverless file storage for this build. It relies on SQLite and files on persistent disk.

## Android and iPhone
This project is a mobile-friendly PWA first, which is the quickest way to share the same app across Android and iPhone. After deploying it over HTTPS, native Capacitor builds can be prepared:

```sh
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Android builds require Android Studio and its SDK. iOS requires a Mac with Xcode:

```sh
npx cap add ios
npx cap sync ios
npx cap open ios
```

Configure signing, app icons, privacy details and store listing before submitting. Store approval is not guaranteed: Apple may reject thin website wrappers or apps designed mainly to download/execute code that changes app functionality. Review the current Apple App Review Guidelines and Google Play policies before submission. A PWA can be installed from the browser without waiting for app-store approval.

## Important limits and security
- This starter accepts one `.html`/`.htm` file up to 5 MB. CSS and JavaScript should be embedded in the HTML. ZIPs, APKs, IPA files and multi-file game projects are not supported yet.
- Uploaded game code is untrusted. The app uses a sandboxed iframe and a restrictive Content Security Policy, but these are not a substitute for reviewing each game. Only publish games you have inspected.
- There are no player accounts, comments, ratings, payments, automated malware scanning or user-submitted uploads. Only the owner with the admin token can publish/remove games.
- Downloading an HTML file does not install it as an Android APK or iOS app. The downloaded game is a web game.
- Sample cards are placeholders displayed when the public API has no published games or cannot be reached; they are not real downloadable games.
