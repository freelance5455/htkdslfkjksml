const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const multer = require('multer');
const Database = require('better-sqlite3');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const app = express();
const PORT = Number(process.env.PORT || 3000);
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || '';
const DATA = path.join(__dirname, 'data');
const GAMES = path.join(DATA, 'games');
fs.mkdirSync(GAMES, { recursive: true });
if (!ADMIN_TOKEN || ADMIN_TOKEN.length < 24) console.warn('WARNING: Set ADMIN_TOKEN to a long random secret before public deployment.');
const db = new Database(path.join(DATA, 'moon-light.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS games (id TEXT PRIMARY KEY,title TEXT NOT NULL,description TEXT NOT NULL DEFAULT '',category TEXT NOT NULL DEFAULT 'Other',icon TEXT NOT NULL DEFAULT '🌙',filename TEXT NOT NULL,created_at TEXT NOT NULL,published INTEGER NOT NULL DEFAULT 1,downloads INTEGER NOT NULL DEFAULT 0)`);
app.disable('x-powered-by');
app.use(helmet({contentSecurityPolicy:{directives:{defaultSrc:["'self'"],scriptSrc:["'self'","'unsafe-inline'"],styleSrc:["'self'","'unsafe-inline'"],imgSrc:["'self'",'data:','blob:'],connectSrc:["'self'"],frameSrc:["'self'",'blob:'],objectSrc:["'none'"],baseUri:["'self'"],upgradeInsecureRequests:null}}}));
app.use(express.json({limit:'30kb'}));
app.use('/api/',rateLimit({windowMs:60000,limit:120,standardHeaders:true,legacyHeaders:false}));
app.use(express.static(path.join(__dirname,'public'),{extensions:['html']}));
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:5*1024*1024,files:1}});
function adminOnly(req,res,next){const token=req.get('x-admin-token')||'';if(!ADMIN_TOKEN||token.length!==ADMIN_TOKEN.length||!crypto.timingSafeEqual(Buffer.from(token),Buffer.from(ADMIN_TOKEN)))return res.status(401).json({error:'Creator authorization failed.'});next();}
function clean(v,n){return String(v||'').trim().replace(/\s+/g,' ').slice(0,n);}
function view(g){return {id:g.id,title:g.title,description:g.description,category:g.category,icon:g.icon,createdAt:g.created_at,downloads:g.downloads,downloadUrl:`/api/games/${encodeURIComponent(g.id)}/download`,playUrl:`/games/${encodeURIComponent(g.filename)}`};}
app.get('/api/health',(req,res)=>res.json({ok:true,app:'Moon Light'}));
app.get('/api/games',(req,res)=>{const q=clean(req.query.q,80).toLowerCase(),cat=clean(req.query.category,40);let rows=db.prepare('SELECT * FROM games WHERE published=1 ORDER BY created_at DESC').all();if(cat&&cat!=='All')rows=rows.filter(g=>g.category===cat);if(q)rows=rows.filter(g=>`${g.title} ${g.description} ${g.category}`.toLowerCase().includes(q));res.json({games:rows.map(view)});});
app.get('/api/games/:id',(req,res)=>{const g=db.prepare('SELECT * FROM games WHERE id=? AND published=1').get(req.params.id);if(!g)return res.status(404).json({error:'Game not found.'});res.json({game:view(g)});});
app.get('/api/games/:id/download',(req,res)=>{const g=db.prepare('SELECT * FROM games WHERE id=? AND published=1').get(req.params.id);if(!g)return res.status(404).send('Game not found.');db.prepare('UPDATE games SET downloads=downloads+1 WHERE id=?').run(g.id);res.setHeader('Content-Type','text/html; charset=utf-8');res.setHeader('Content-Disposition',`attachment; filename="${g.title.replace(/[^a-z0-9_-]/gi,'_')}.html"`);res.sendFile(path.join(GAMES,g.filename));});
app.get('/games/:filename',(req,res)=>{const filename=path.basename(req.params.filename);const g=db.prepare('SELECT id FROM games WHERE filename=? AND published=1').get(filename);if(!g)return res.status(404).send('Game not found.');res.setHeader('Content-Security-Policy',"default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval' blob: data:; style-src 'unsafe-inline' data:; img-src data: blob:; media-src data: blob:; font-src data:; connect-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'self'");res.setHeader('X-Content-Type-Options','nosniff');res.sendFile(path.join(GAMES,filename));});
app.post('/api/admin/games',adminOnly,upload.single('game'),(req,res)=>{try{if(!req.file)return res.status(400).json({error:'Choose an HTML game file.'});if(!/\.html?$/i.test(req.file.originalname))return res.status(400).json({error:'Only .html or .htm files are accepted.'});const title=clean(req.body.title,70);if(!title)return res.status(400).json({error:'Game title is required.'});const id=crypto.randomUUID(),filename=`${id}.html`;fs.writeFileSync(path.join(GAMES,filename),req.file.buffer,{flag:'wx'});db.prepare('INSERT INTO games(id,title,description,category,icon,filename,created_at,published,downloads) VALUES(?,?,?,?,?,?,?,1,0)').run(id,title,clean(req.body.description,500),clean(req.body.category,30)||'Other',clean(req.body.icon,8)||'🌙',filename,new Date().toISOString());res.status(201).json({game:view(db.prepare('SELECT * FROM games WHERE id=?').get(id))});}catch(e){console.error(e);res.status(500).json({error:'Could not publish this game.'});}});
app.get('/api/admin/games',adminOnly,(req,res)=>res.json({games:db.prepare('SELECT * FROM games ORDER BY created_at DESC').all().map(view)}));
app.delete('/api/admin/games/:id',adminOnly,(req,res)=>{const g=db.prepare('SELECT * FROM games WHERE id=?').get(req.params.id);if(!g)return res.status(404).json({error:'Game not found.'});db.prepare('DELETE FROM games WHERE id=?').run(g.id);fs.rmSync(path.join(GAMES,g.filename),{force:true});res.json({ok:true});});
app.get('*path',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`Moon Light is running on port ${PORT}`));
