MOON LIGHT — PUBLIC GAME STORE STARTER

This is the next build of Moon Light: a responsive PWA-style public catalog, a Node.js backend, owner-only publishing, HTML game downloads, and a Creator Hub.

Quick start:
1. Install Node.js LTS.
2. Extract the ZIP and open a terminal in Moon_Light_Public_Store.
3. Run: npm install
4. Set ADMIN_TOKEN to a long random secret (at least 32 characters).
5. Run: npm start
6. Open http://localhost:3000

Read DEPLOYMENT.md for hosting and Android/iOS steps. The backend must be deployed with persistent storage and HTTPS before public publishing works for everyone. Do not share your admin token.
