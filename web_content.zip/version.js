window.BLURE_VERSION='0.8.0';
