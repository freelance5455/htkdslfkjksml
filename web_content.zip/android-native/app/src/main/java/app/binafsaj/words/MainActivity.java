package app.binafsaj.words;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import java.util.Arrays;

/**
 * «بنفسج»: يعرض الواجهة المضمَّنة في assets/index.html محليًا. لا يفتح أي رابط إنترنت لتشغيل الواجهة.
 * الترتيب: (1) https://appassets.androidplatform.net/assets/index.html عبر WebViewAssetLoader (أصل آمن للتخزين المحلي)،
 * (2) file:///android_asset/index.html إن فشل الأول، (3) صفحة خطأ داخلية تشرح السبب بدل صفحة «لا يمكن الوصول إلى الموقع».
 * سجل الأخطاء: adb logcat -s Binafsaj
 */
public class MainActivity extends Activity {

    private static final String TAG = "Binafsaj";
    private static final String HOST = "appassets.androidplatform.net";
    private static final String URL_ASSET_LOADER = "https://" + HOST + "/assets/index.html";
    private static final String URL_FILE = "file:///android_asset/index.html";

    private WebView web;
    private WebViewAssetLoader loader;
    private int attempt = 0; // 0 = AssetLoader، 1 = file، 2 = صفحة الخطأ

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#7c3aed"));

        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true);   // chrome://inspect أثناء التطوير فقط
        }

        loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#faf7ff"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // لحفظ المفضلة (localStorage)
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage m) {
                Log.d(TAG, "JS " + m.messageLevel() + ": " + m.message() + " (" + m.sourceId() + ":" + m.lineNumber() + ")");
                return true;
            }
        });

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String sc = u.getScheme();
                if ("file".equals(sc) || "about".equals(sc) || "data".equals(sc) || HOST.equals(u.getHost())) {
                    return false;               // صفحات التطبيق نفسه
                }
                try {                           // أي رابط خارجي يُفتح في المتصفح
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) {
                    Log.w(TAG, "cannot open external link " + u, e);
                }
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    fail(request.getUrl().toString(), error.getErrorCode() + " " + error.getDescription());
                }
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse response) {
                if (request.isForMainFrame()) {
                    fail(request.getUrl().toString(), "HTTP " + response.getStatusCode());
                }
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                Log.e(TAG, "WebView render process gone; recreating activity");
                recreate();
                return true;
            }
        });

        start();
    }

    /** يتحقق أن index.html موجود فعلًا داخل الحزمة ثم يفتحه. */
    private void start() {
        try {
            String[] list = getAssets().list("");
            boolean found = false;
            if (list != null) {
                for (String n : list) {
                    if ("index.html".equals(n)) {
                        found = true;
                    }
                }
            }
            if (!found) {
                Log.e(TAG, "assets/index.html is MISSING. assets = " + Arrays.toString(list));
                showError("لم يُعثر على index.html داخل حزمة التطبيق (assets).",
                        "الملفات الموجودة في assets: " + Arrays.toString(list)
                                + "\nأعد بناء المشروع بعد التأكد من وجود app/src/main/assets/index.html");
                return;
            }
        } catch (Exception e) {
            Log.e(TAG, "cannot list assets", e);
        }
        attempt = 0;
        Log.i(TAG, "loading " + URL_ASSET_LOADER);
        web.loadUrl(URL_ASSET_LOADER);
    }

    private void fail(String url, String why) {
        Log.e(TAG, "main frame load failed: " + url + " -> " + why + " (attempt " + attempt + ")");
        if (attempt == 0) {
            attempt = 1;
            Log.i(TAG, "falling back to " + URL_FILE);
            web.loadUrl(URL_FILE);
        } else if (attempt == 1) {
            showError("تعذّر فتح الصفحة الرئيسية من داخل التطبيق.", "الرابط: " + url + "\nالسبب: " + why);
        }
    }

    private void showError(String title, String details) {
        attempt = 2;
        String html = "<html dir='rtl'><head><meta charset='utf-8'>"
                + "<meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                + "<body style='font-family:sans-serif;margin:0;padding:24px;background:#faf7ff;color:#241a33'>"
                + "<h2 style='color:#7c3aed'>💜 بنفسج</h2><p><b>" + esc(title) + "</b></p>"
                + "<pre style='white-space:pre-wrap;background:#fff;padding:12px;border-radius:12px;font-size:13px'>"
                + esc(details) + "</pre>"
                + "<button style='padding:12px 22px;border:0;border-radius:24px;background:#7c3aed;color:#fff;font-size:16px'"
                + " onclick='AndroidBridge.reload()'>إعادة المحاولة</button></body></html>";
        web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
    }

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    /** جسر بين الصفحة والنظام: المشاركة والنسخ وإعادة المحاولة. */
    private class Bridge {
        @JavascriptInterface
        public void share(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(i, "مشاركة"));
                }
            });
        }

        @JavascriptInterface
        public boolean copy(String text) {
            ClipboardManager c = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (c == null) {
                return false;
            }
            c.setPrimaryClip(ClipData.newPlainText("بنفسج", text));
            return true;
        }

        @JavascriptInterface
        public void reload() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    start();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();                       // التنقل بين صفحات التطبيق
        } else {
            super.onBackPressed();
        }
    }
}
