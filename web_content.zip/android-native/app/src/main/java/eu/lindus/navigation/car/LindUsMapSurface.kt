package eu.lindus.navigation.car

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.view.Surface
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import eu.lindus.navigation.LindUsLocationState
import eu.lindus.navigation.LindUsRouteState\nimport eu.lindus.navigation.LindUsSpeedLimitProvider
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import kotlin.math.floor
import kotlin.math.pow

/** OSM raster map preview on the Android Auto host Surface.
 * The native OSRM route geometry is drawn over the OSM raster map.
 */
class LindUsMapSurface : SurfaceCallback {
    @Volatile private var surface: Surface? = null
    @Volatile private var width = 0
    @Volatile private var height = 0
    @Volatile private var generation = 0
    private val worker = Executors.newSingleThreadExecutor()
    private val zoom = 14
    private val cache = object : android.util.LruCache<String, Bitmap>(36) {}

    override fun onSurfaceAvailable(surfaceContainer: SurfaceContainer) {
        surface = surfaceContainer.surface
        width = surfaceContainer.width
        height = surfaceContainer.height
        generation++
        LindUsLocationState.addListener(locationListener)
        LindUsRouteState.addListener(routeListener)
        render(generation)
    }

    override fun onSurfaceDestroyed(surfaceContainer: SurfaceContainer) {
        generation++
        LindUsLocationState.removeListener(locationListener)
        LindUsRouteState.removeListener(routeListener)
        val old = surface
        surface = null
        try { old?.release() } catch (_: Exception) {}
    }

    private val routeListener: () -> Unit = { generation++; render(generation) }

    private val locationListener: () -> Unit = {
        generation++
        render(generation)
    }

    private fun render(id: Int) {
        val w = width
        val h = height
        if (w <= 0 || h <= 0) return
        worker.execute {
            val n = 2.0.pow(zoom.toDouble())
            val position = LindUsLocationState.current
            // If permission has not yet produced a fix, show Munich as a neutral fallback.
            val centerLat = position?.latitude ?: 48.1372
            val centerLon = position?.longitude ?: 11.5756
            val lat = Math.toRadians(centerLat.coerceIn(-85.0, 85.0))
            val cx = (centerLon + 180.0) / 360.0 * n * 256.0
            val cy = (1.0 - kotlin.math.ln(kotlin.math.tan(lat) + 1.0 / kotlin.math.cos(lat)) / Math.PI) / 2.0 * n * 256.0
            val left = cx - w / 2.0
            val top = cy - h / 2.0
            val minX = floor(left / 256.0).toInt()
            val minY = floor(top / 256.0).toInt()
            val maxX = floor((left + w) / 256.0).toInt()
            val maxY = floor((top + h) / 256.0).toInt()
            val tiles = mutableListOf<Triple<Bitmap, Float, Float>>()
            for (ty in minY..maxY) for (tx in minX..maxX) {
                if (id != generation) return@execute
                val key = "$zoom/$tx/$ty"
                val bmp = cache.get(key) ?: fetchTile(zoom, tx, ty)?.also { cache.put(key, it) }
                if (bmp != null) tiles.add(Triple(bmp, (tx * 256.0 - left).toFloat(), (ty * 256.0 - top).toFloat()))
            }
            if (id == generation) draw(tiles, w, h)
        }
    }

    private fun fetchTile(z: Int, x: Int, y: Int): Bitmap? {
        val count = 2.0.pow(z.toDouble()).toInt()
        if (y !in 0 until count) return null
        val wrappedX = ((x % count) + count) % count
        var conn: HttpURLConnection? = null
        return try {
            conn = URL("https://tile.openstreetmap.org/$z/$wrappedX/$y.png").openConnection() as HttpURLConnection
            conn.connectTimeout = 5000
            conn.readTimeout = 7000
            conn.setRequestProperty("User-Agent", "LIND-US-Navigation/1.9 (Android Auto prototype)")
            conn.setRequestProperty("Accept", "image/png")
            conn.connect()
            if (conn.responseCode == 200) conn.inputStream.use { BitmapFactory.decodeStream(it) } else null
        } catch (_: Exception) { null } finally { conn?.disconnect() }
    }

    private fun draw(tiles: List<Triple<Bitmap, Float, Float>>, w: Int, h: Int) {
        val target = surface ?: return
        var canvas: Canvas? = null
        try {
            canvas = target.lockCanvas(null)
            canvas.drawColor(Color.rgb(8, 17, 24))
            val position = LindUsLocationState.current
            val bearing = position?.bearingDegrees
            val mapSave = canvas.save()
            if (bearing != null) canvas.rotate(-bearing, w / 2f, h / 2f)
            val dst = Rect()
            for ((bmp, x, y) in tiles) {
                dst.set(x.toInt(), y.toInt(), x.toInt() + bmp.width, y.toInt() + bmp.height)
                canvas.drawBitmap(bmp, null, dst, null)
            }
            // Project route geometry into the current Web Mercator tile pixel space.
            val activeRoute = LindUsRouteState.current
            if (activeRoute != null && activeRoute.points.isNotEmpty()) {
                val routePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.rgb(0, 178, 210)
                    style = Paint.Style.STROKE
                    strokeWidth = 11f
                    strokeCap = Paint.Cap.ROUND
                    strokeJoin = Paint.Join.ROUND
                }
                val nRoute = 2.0.pow(zoom.toDouble())
                val path = android.graphics.Path()
                activeRoute.points.forEachIndexed { index, point ->
                    val latRad = Math.toRadians(point.first.coerceIn(-85.0, 85.0))
                    val px = (point.second + 180.0) / 360.0 * nRoute * 256.0
                    val py = (1.0 - kotlin.math.ln(kotlin.math.tan(latRad) + 1.0 / kotlin.math.cos(latRad)) / Math.PI) / 2.0 * nRoute * 256.0
                    val current = LindUsLocationState.current
                    val centerLat = current?.latitude ?: 48.1372
                    val centerLon = current?.longitude ?: 11.5756
                    val centerRad = Math.toRadians(centerLat.coerceIn(-85.0, 85.0))
                    val centerPx = (centerLon + 180.0) / 360.0 * nRoute * 256.0
                    val centerPy = (1.0 - kotlin.math.ln(kotlin.math.tan(centerRad) + 1.0 / kotlin.math.cos(centerRad)) / Math.PI) / 2.0 * nRoute * 256.0
                    val sx = (px - centerPx).toFloat() + w / 2f
                    val sy = (py - centerPy).toFloat() + h / 2f
                    if (index == 0) path.moveTo(sx, sy) else path.lineTo(sx, sy)
                }
                canvas.drawPath(path, routePaint)
            }

            canvas.restoreToCount(mapSave)

            // Heading-up vehicle marker: arrow points to the top of the display.
            val markerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(0, 178, 210)
                style = Paint.Style.FILL
                setShadowLayer(8f, 0f, 0f, Color.BLACK)
            }
            val markerPath = android.graphics.Path().apply {
                moveTo(w / 2f, h / 2f - 22f)
                lineTo(w / 2f - 13f, h / 2f + 15f)
                lineTo(w / 2f, h / 2f + 8f)
                lineTo(w / 2f + 13f, h / 2f + 15f)
                close()
            }
            canvas.drawPath(markerPath, markerPaint)
            val attribution = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.DKGRAY; textSize = 19f; setShadowLayer(2f,1f,1f,Color.WHITE)
            }
            canvas.drawText("© OpenStreetMap contributors", 12f, h-14f, attribution)

            val hud = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = 22f
                setShadowLayer(3f, 1f, 1f, Color.BLACK)
            }
            val speed = position?.speedMetersPerSecond?.let { (it * 3.6f).toInt() }
            val accuracy = position?.accuracyMeters?.let { "GPS ±${it.toInt()} m" } ?: "GPS keresése…"
            canvas.drawText(if (speed != null) "$speed km/h" else "Sebesség —", 16f, 34f, hud)
            canvas.drawText(accuracy, 16f, 62f, hud)
            if (LindUsRouteState.navigationActive) {
                canvas.drawText("Limit: ${LindUsSpeedLimitProvider.currentLabel}", 16f, 90f, hud)
            }
        } catch (_: Exception) {
        } finally {
            if (canvas != null) try { target.unlockCanvasAndPost(canvas) } catch (_: Exception) {}
        }
    }
}
