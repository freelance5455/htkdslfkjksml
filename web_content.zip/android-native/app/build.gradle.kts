plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "eu.lindus.navigation"
    compileSdk = 35

    defaultConfig {
        applicationId = "eu.lindus.navigation"
        minSdk = 26
        targetSdk = 35
        versionCode = 21
        versionName = "2.1"
    }
}

dependencies {
    implementation("androidx.car.app:app:1.7.0")
    implementation("androidx.core:core-ktx:1.15.0")
}
