const toast=document.getElementById('toast');
function notify(t){toast.textContent=t;toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),2200)}
async function share(){if(navigator.share){try{await navigator.share({title:'Sanket Morya — Digital Resume',text:'Web Developer & Technical Executive',url:location.href})}catch(e){}}else{await navigator.clipboard?.writeText(location.href);notify('Resume link copied')}}
document.getElementById('shareBtn').onclick=share;document.getElementById('shareTop').onclick=share;
document.getElementById('menuBtn').onclick=()=>notify('Digital Resume • Sanket Morya');

