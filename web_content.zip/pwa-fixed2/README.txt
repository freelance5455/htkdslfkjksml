SANKET MORYA — DIGITAL RESUME PWA

This package is install-ready as a Progressive Web App (PWA).

MOBILE INSTALL (Android Chrome):
1. Upload this folder to any HTTPS web host.
2. Open the website in Chrome on Android.
3. Tap the browser menu (⋮).
4. Tap “Install app” or “Add to Home screen”.
5. Confirm. The resume opens like a standalone mobile app and works offline after first load.

IMPORTANT:
- PWA installation requires HTTPS when hosted online (localhost is also suitable for development).
- The manifest, service worker, icons, resume PDF, and profile photo are included.
- For an Android APK/Play Store package, use the hosted HTTPS URL with PWABuilder.
