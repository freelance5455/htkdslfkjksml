Mukesh ❤️ Mausumi — Our Little World
======================================

HOW TO USE
1. Extract this ZIP file.
2. Open index.html in Chrome or another modern browser.
3. Enter any name and password to enter the demo.

IMPORTANT LIMITATIONS
- This is a front-end demo, not a secure private online service.
- Login is only a local demo; it does not verify an account.
- Notes, memories and chat messages are saved in the current browser/device only.
- Two people using different phones will NOT see each other's messages.
- Do not store sensitive/private information in this demo.

For real private login, password recovery, and chat syncing between Mukesh's
and Mausumi's phones, the app needs a secure backend (for example Firebase
Authentication + Firestore/Realtime Database) with proper security rules.
