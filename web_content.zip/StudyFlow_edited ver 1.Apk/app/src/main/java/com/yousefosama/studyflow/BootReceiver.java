package com.yousefosama.studyflow;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import java.util.Map;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;

        SharedPreferences prefs =
            context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);

        for (Map.Entry<String, ?> entry : prefs.getAll().entrySet()) {
            if (!(entry.getValue() instanceof String)) continue;

            String[] parts = ((String) entry.getValue()).split("\\n", 3);
            if (parts.length != 3) continue;

            try {
                long triggerAt = Long.parseLong(parts[2]);
                if (triggerAt > System.currentTimeMillis()) {
                    MainActivity.scheduleReminder(
                        context, entry.getKey(), parts[0], parts[1], triggerAt
                    );
                } else {
                    prefs.edit().remove(entry.getKey()).apply();
                }
            } catch (Exception ignored) {}
        }
    }
}
