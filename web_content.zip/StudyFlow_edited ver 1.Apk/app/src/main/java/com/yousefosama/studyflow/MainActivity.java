package com.yousefosama.studyflow;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.core.app.NotificationCompat;

import java.io.InputStream;
import java.security.MessageDigest;

public class MainActivity extends Activity {
    private static final String EXPECTED_SHA256 = "9cdac58c0068a9f099974e208f6e6d840c6521908e1654fdf2cda49374629e09";
    public static final String CHANNEL_ID = "studyflow_reminders";
    private static final int NOTIFICATION_PERMISSION = 1001;
    public static final String PREFS = "studyflow_reminders";

    private String sha256Asset(String assetName) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = getAssets().open(assetName)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) md.update(buf, 0, n);
        }
        StringBuilder sb = new StringBuilder();
        for (byte b : md.digest()) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    private boolean isOriginalFile() {
        try {
            return EXPECTED_SHA256.equalsIgnoreCase(sha256Asset("index.html"));
        } catch (Exception e) {
            return false;
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "StudyFlow reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            );
            channel.setDescription("Study session and student reminders");
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(channel);
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION);
        }
    }

    public static void scheduleReminder(Context context, String id, String title, String message, long triggerAt) {
        if (triggerAt <= System.currentTimeMillis()) return;

        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.putExtra("id", id);
        intent.putExtra("title", title);
        intent.putExtra("message", message);

        int requestCode = Math.abs(id.hashCode());
        PendingIntent pi = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am != null) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        }

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(id, title + "\n" + message + "\n" + triggerAt)
            .apply();
    }

    public static void cancelReminder(Context context, String id) {
        Intent intent = new Intent(context, ReminderReceiver.class);
        int requestCode = Math.abs(id.hashCode());
        PendingIntent pi = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(pi);
        pi.cancel();

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().remove(id).apply();
    }

    public class StudyFlowBridge {
        @JavascriptInterface
        public void requestNotifications() {
            runOnUiThread(() -> requestNotificationPermissionIfNeeded());
        }

        @JavascriptInterface
        public void scheduleReminder(String id, String title, String message, long triggerAt) {
            if (id == null || id.isEmpty()) return;
            scheduleReminder(MainActivity.this, id, title, message, triggerAt);
        }

        @JavascriptInterface
        public void cancelReminder(String id) {
            if (id == null || id.isEmpty()) return;
            cancelReminder(MainActivity.this, id);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        createNotificationChannel();
        requestNotificationPermissionIfNeeded();

        WebView web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);

        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new StudyFlowBridge(), "StudyFlowAndroid");
        web.loadUrl("file:///android_asset/index.html");

        if (!isOriginalFile()) {
            web.evaluateJavascript(
                "window.StudyFlowSecurity && window.StudyFlowSecurity.setBlocked();", null
            );
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
