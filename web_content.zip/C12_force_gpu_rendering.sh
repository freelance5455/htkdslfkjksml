#!/system/bin/sh
# C12_force_gpu_rendering — force gpu rendering
# Force hardware-accelerated 2D rendering on for every app that supports it.
MODULE_ID="C12_force_gpu_rendering"
. "$(dirname "$0")/../lib/core.sh"
vcg_init
apply() {
    vcg_apply_or_skip C12_ENABLED || return 0
    vcg_put global hardware_accelerated_rendering_enabled 1
}
revert() {
    vcg_restore_setting global hardware_accelerated_rendering_enabled
}
case "${1:-apply}" in apply) apply ;; revert) revert ;; *) exit 1 ;; esac
