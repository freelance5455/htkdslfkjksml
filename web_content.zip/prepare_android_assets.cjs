const fs = require('fs');
const path = require('path');

const rootDir = process.cwd();
const distDir = path.join(rootDir, 'dist');
const assetsDistDir = path.join(distDir, 'assets');

console.log('🔧 Running prepare_android_assets.cjs...');

// 1. Read built artifacts
const bundleJsPath = path.join(assetsDistDir, 'app-bundle.js');
const indexCssPath = path.join(assetsDistDir, 'index.css');
const distHtmlPath = path.join(distDir, 'index.html');

if (!fs.existsSync(bundleJsPath) || !fs.existsSync(indexCssPath) || !fs.existsSync(distHtmlPath)) {
  console.error('❌ Build artifacts missing in dist/! Please run vite build first.');
  process.exit(1);
}

const bundleJs = fs.readFileSync(bundleJsPath, 'utf8');
const indexCss = fs.readFileSync(indexCssPath, 'utf8');
let distHtml = fs.readFileSync(distHtmlPath, 'utf8');

// 2. Create standalone, fully inlined HTML
// Replace CSS link in <head> with inline style
distHtml = distHtml.replace(
  /<link\s+rel="stylesheet"\s+crossorigin\s+href="[^"]*index\.css"[^>]*>/i,
  `<style id="inlined-app-styles">\n${indexCss}\n</style>`
);

// Remove external app-bundle.js script tag from <head>
distHtml = distHtml.replace(
  /<script\s+type="module"\s+crossorigin\s+src="[^"]*app-bundle\.js"[^>]*><\/script>/i,
  ''
);

// Remove any lingering src/main.tsx script tag
distHtml = distHtml.replace(
  /<script\s+type="module"\s+src="[^"]*main\.tsx"[^>]*><\/script>/i,
  ''
);

// Place inlined JavaScript bundle at the bottom of <body> (right before </body>)
// so that the DOM structure (<div id="root">) is fully parsed and available for React
const scriptBlock = `\n    <script type="text/javascript" id="inlined-app-bundle">\n${bundleJs}\n    </script>\n  </body>`;
distHtml = distHtml.replace(/<\/body>/i, scriptBlock);

console.log('✅ Generated standalone inlined HTML (' + (distHtml.length / 1024).toFixed(1) + ' KB)');

// 3. Define target directories in android/app/src/main/assets/
const androidAssetsBase = path.join(rootDir, 'android/app/src/main/assets');

// Clean up any old duplicate nested directories if they exist
const toRemove = [
  path.join(androidAssetsBase, 'public/preview'),
  path.join(androidAssetsBase, 'preview/preview'),
  path.join(androidAssetsBase, 'preview/src'),
  path.join(androidAssetsBase, 'public/src'),
  path.join(androidAssetsBase, 'src'),
];
for (const p of toRemove) {
  if (fs.existsSync(p)) {
    fs.rmSync(p, { recursive: true, force: true });
  }
}

const targetHtmlPaths = [
  path.join(androidAssetsBase, 'index.html'),
  path.join(androidAssetsBase, 'preview/index.html'),
  path.join(androidAssetsBase, 'public/index.html'),
  path.join(distDir, 'index.html'),
  path.join(distDir, 'preview/index.html'),
];

for (const targetPath of targetHtmlPaths) {
  fs.mkdirSync(path.dirname(targetPath), { recursive: true });
  fs.writeFileSync(targetPath, distHtml, 'utf8');
  console.log('  -> Wrote inlined HTML to:', path.relative(rootDir, targetPath));
}

// 4. Copy app-bundle.js and index.css only to the essential candidate asset directories
const targetAssetDirs = [
  path.join(androidAssetsBase, 'preview/assets'),
  path.join(androidAssetsBase, 'public/assets'),
  path.join(androidAssetsBase, 'assets'),
];

for (const dir of targetAssetDirs) {
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'app-bundle.js'), bundleJs, 'utf8');
  fs.writeFileSync(path.join(dir, 'index.css'), indexCss, 'utf8');
  console.log('  -> Synced bundle & css to:', path.relative(rootDir, dir));
}

// 5. Provide lightweight fallback loaders for src/main.tsx / src/main.js
// so that any stray request is seamlessly fulfilled in < 200 bytes
const lightweightLoader = `// Hebrew Calendar Fallback Loader
(function() {
  var w = window as any;
  if (w.__bundleFallbackAttempted) return;
  w.__bundleFallbackAttempted = true;
  var s = document.createElement('script');
  s.src = './assets/app-bundle.js';
  s.onerror = function() {
    var s2 = document.createElement('script');
    s2.src = '/preview/assets/app-bundle.js';
    document.body.appendChild(s2);
  };
  document.body.appendChild(s);
})();
export {};
`;

const mainScriptTargets = [
  path.join(androidAssetsBase, 'src/main.tsx'),
  path.join(androidAssetsBase, 'src/main.js'),
  path.join(androidAssetsBase, 'preview/src/main.tsx'),
  path.join(androidAssetsBase, 'preview/src/main.js'),
];

for (const p of mainScriptTargets) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, lightweightLoader, 'utf8');
}

console.log('🎉 All Android assets prepared successfully!');
