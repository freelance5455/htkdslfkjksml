ÚT A VÉGTELENBE – ANDROID / WEB PROTOTÍPUS 0.1
================================================

A csomag egy játszható, fekvő nézetű, HTML5 Canvas alapú pixel-art játékot tartalmaz, valamint egy Android Studio projektet, amely WebView-ban futtatja a játékot teljes képernyőn.

FŐBB ELEMEK
-----------
- karakterenként megjelenő bevezető történet írógépszerű hanggal;
- garázs-jelenet, pakolás, motorindítás és fényszóró;
- autószín-választás: barna, zöld, kék, piros, sárga;
- öt zóna: romos város, ipari rommező, lángoló erdő, vörös kanyon, sötét barlang;
- többrétegű, görgetett pixel-art égbolt és hegyek, füst, tűz, romok és kristályok;
- járműgyorsítás, fékezés, előre/hátra haladás, üzemanyag, kaszni, életerő és fejlesztési pontok;
- meteorok, becsapódási kráterek, villámok, rámpák, roncsok, radioaktív zóna;
- benzinkutas checkpoint, tankolás, mentés, motor/kerék/kaszni fejlesztések és véletlen alkatrészek;
- tábor, evés, alvás és talált levelek olvasása;
- üzemanyag kifogyása után gyalogos roncsátvizsgálás és gyógykészlet-használat;
- generatív, saját készítésű szintetizált posztapokaliptikus zene és effektusok;
- a mentés kizárólag benzinkutas checkpointnál történik, az adott eszköz helyi tárhelyére.

ANDROID APK KÉSZÍTÉSE
--------------------
Ebben a futtatókörnyezetben nincs telepített Android SDK vagy Gradle, és nem érhető el a letöltésük, ezért itt nem készült .apk bináris. A natív Android projekt forrása viszont teljesen benne van a csomagban.

1. Telepítsd az Android Studio-t egy számítógépre.
2. Csomagold ki az Android-projekt ZIP-et, majd nyisd meg az ut_a_vegtelenbe_android mappát Android Studio projektként.
3. Várd meg, amíg a Gradle szinkronizálása befejeződik. Az Android Studio ekkor letöltheti a szükséges build eszközöket.
4. Válaszd: Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Az Android Studio által létrehozott APK-t másold a telefonra és telepítsd. Szükség esetén engedélyezd az adott fájlkezelőnek az ismeretlen alkalmazások telepítését.

GYORS PRÓBA / WEBES TELEPÍTÉS
-----------------------------
Az Ut_a_vegtelenbe.html közvetlenül megnyitható modern böngészőben. A webes csomag PWA-fájlokat is tartalmaz. A Chrome „Telepítés” funkciójához a csomagot HTTPS-tárhelyre kell feltölteni; a PWA telepítése a file:// megnyitásból nem működik.

IRÁNYÍTÁS
---------
- Érintőképernyő: bal alul gáz/fék, jobb alul előre/hátra.
- Billentyűzet: W / ↑ gáz, S / ↓ fék, D / → előre, A / ← hátra, E / Enter interakció, M zene, H gyógykészlet gyalogos módban.
- Benzinkútnál lassíts le vagy állj meg, majd érintsd meg a középen megjelenő interakció gombot.
- A checkpoint-képernyőn tankolhatsz, fejleszthetsz, táborozhatsz és menthetsz.

FONTOS
------
Ez egy működő, bővíthető 0.1-es prototípus. A teljes elképzelés több külön pályaelemet, animációt, egyedi sprite-ot és hangot igényel, ezért néhány esemény egyszerűsített. A csomag nem tartalmaz kész .apk fájlt; az Android Studio projektből kell lefordítani.
