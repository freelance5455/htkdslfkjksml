OPEN THIS FOLDER IN ANDROID STUDIO

Build > Build Bundle(s) / APK(s) > Build APK(s)

APK output: app/build/outputs/apk/debug/app-debug.apk
