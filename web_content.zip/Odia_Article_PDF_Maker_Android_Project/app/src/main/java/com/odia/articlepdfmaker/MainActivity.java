package com.odia.articlepdfmaker;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(15, 23, 42));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(15, 23, 42));
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setDefaultTextEncodingName("UTF-8");
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
                if ("file".equals(scheme) || "data".equals(scheme) || "blob".equals(scheme) || "about".equals(scheme)) {
                    return false;
                }
                if ("https".equals(scheme) || "http".equals(scheme)) {
                    // Keep the app's local page in WebView; open user-clicked web links externally.
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (Exception ignored) { }
                    return true;
                }
                return true;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Uri uri = Uri.parse(url);
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
                if ("file".equals(scheme) || "data".equals(scheme) || "blob".equals(scheme) || "about".equals(scheme)) return false;
                if ("https".equals(scheme) || "http".equals(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
                }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private static String safeFilename(String filename) {
        String name = filename == null ? "odia-article.pdf" : filename;
        name = name.replaceAll("[\\\\/:*?\"<>|]", "-").replaceAll("\\s+", "-");
        if (name.trim().isEmpty()) name = "odia-article.pdf";
        if (!name.toLowerCase(Locale.ROOT).endsWith(".pdf")) name += ".pdf";
        if (name.length() > 80) name = name.substring(0, 76) + ".pdf";
        return name;
    }

    private byte[] decodePdf(String base64) {
        if (base64 == null) throw new IllegalArgumentException("No PDF data received.");
        int comma = base64.indexOf(',');
        if (base64.startsWith("data:") && comma >= 0) base64 = base64.substring(comma + 1);
        byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
        if (bytes.length < 5 || bytes[0] != '%' || bytes[1] != 'P' || bytes[2] != 'D' || bytes[3] != 'F' || bytes[4] != '-') {
            throw new IllegalArgumentException("The generated file is not a valid PDF.");
        }
        return bytes;
    }

    private String savePdf(byte[] bytes, String filename) throws IOException {
        filename = safeFilename(filename);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
            values.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("Could not create the PDF in Downloads.");
            try (OutputStream output = getContentResolver().openOutputStream(uri)) {
                if (output == null) throw new IOException("Could not open the Downloads file.");
                output.write(bytes);
                output.flush();
            } catch (IOException e) {
                getContentResolver().delete(uri, null, null);
                throw e;
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            getContentResolver().update(uri, done, null, null);
            return "PDF saved in Downloads: " + filename;
        } else {
            File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            if (dir == null) dir = getFilesDir();
            if (!dir.exists() && !dir.mkdirs()) throw new IOException("Could not create the Downloads folder.");
            File file = new File(dir, filename);
            try (FileOutputStream output = new FileOutputStream(file)) {
                output.write(bytes);
                output.flush();
            }
            return "PDF saved: " + file.getAbsolutePath();
        }
    }

    public class AndroidBridge {
        private final Activity activity;
        AndroidBridge(Activity activity) { this.activity = activity; }

        @JavascriptInterface
        public String savePdfBase64(String base64, String filename) {
            try {
                String result = savePdf(decodePdf(base64), filename);
                activity.runOnUiThread(() -> Toast.makeText(activity, result, Toast.LENGTH_LONG).show());
                return result;
            } catch (Exception e) {
                String message = "PDF save failed: " + (e.getMessage() == null ? "Unknown error" : e.getMessage());
                activity.runOnUiThread(() -> Toast.makeText(activity, message, Toast.LENGTH_LONG).show());
                return message;
            }
        }

        @JavascriptInterface
        public String sharePdfBase64(String base64, String filename) {
            try {
                byte[] bytes = decodePdf(base64);
                String name = safeFilename(filename);
                File dir = new File(activity.getCacheDir(), "shared");
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("Could not prepare the share file.");
                File file = new File(dir, name);
                try (FileOutputStream output = new FileOutputStream(file)) {
                    output.write(bytes);
                    output.flush();
                }
                Uri uri = FileProvider.getUriForFile(activity, "com.odia.articlepdfmaker.fileprovider", file);
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("application/pdf");
                intent.putExtra(Intent.EXTRA_STREAM, uri);
                intent.putExtra(Intent.EXTRA_SUBJECT, name);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                activity.runOnUiThread(() -> activity.startActivity(Intent.createChooser(intent, "Share PDF")));
                return "Opening Android share menu...";
            } catch (Exception e) {
                String message = "PDF share failed: " + (e.getMessage() == null ? "Unknown error" : e.getMessage());
                activity.runOnUiThread(() -> Toast.makeText(activity, message, Toast.LENGTH_LONG).show());
                return message;
            }
        }
    }
}
