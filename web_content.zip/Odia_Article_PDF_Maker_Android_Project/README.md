# Odia Article PDF Maker — Android project

This is an Android Studio WebView wrapper for the supplied `Odia_Article_PDF_Maker.html`.

## Included features
- Odia article text entry and character/word count
- Writer and topic fields
- Font, font-size, spacing, margins, page-count and paper-size settings
- Page preview generation
- Save PDF directly into the Android Downloads folder (Android 10+)
- Share the generated PDF using the Android share sheet
- Clear/reset controls

## Build the APK
1. Install **Android Studio** on a computer.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the extracted `Odia_Article_PDF_Maker_Android_Project` folder.
4. Allow Gradle sync to finish (internet is needed the first time to download Android Gradle Plugin and AndroidX dependencies).
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. When it finishes, choose **locate** in the build notification. The APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
7. Copy the APK to your Android phone and install it. On the phone, allow installation from that file manager when Android asks.

## Important notes
- The app needs internet access for jsPDF, html2canvas, and the optional Google-hosted Odia fonts referenced by the original HTML. The Tailwind utility stylesheet is already embedded, so its CDN loader was removed.
- The project preserves the supplied page-maker logic and adds an Android bridge for PDF saving and sharing. It has not been compiled or run on a physical device in this environment.
- All Google/Gemini host-injected scripts were removed from the HTML before packaging because they are not part of the page-maker app and contain host-session/token scaffolding. The actual app code and page-maker features were retained.
- Minimum Android version: Android 6.0 (API 23). Target SDK: 35.
