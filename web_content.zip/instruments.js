/* TAMIM WORLD MUSIC STUDIO
   Every instrument here is synthesized live with the Web Audio API.
   No sample files, no downloads: it works offline, straight from disk.
   Engines: tone (bowed/wind/brass/reed/organ/synth), pluck (Karplus-Strong strings),
   mallet (bells, bars, gongs, piano), drum (membranes, shakers, cymbals), kit (drum set). */
(function () {
  'use strict';

  /* ---------- audio graph ---------- */
  var bus = null, master = null, wet = null, noiseBuf = null, waveCache = {}, ksCache = {}, ksKeys = [];
  var vol = 0.75, rev = 0.22;

  function ac() {
    var a = getCtx();
    if (!bus) {
      master = a.createGain(); master.gain.value = vol;
      var comp = a.createDynamicsCompressor();
      comp.threshold.value = -16; comp.knee.value = 10; comp.ratio.value = 5;
      comp.attack.value = 0.003; comp.release.value = 0.2;
      master.connect(comp); comp.connect(a.destination);
      bus = a.createGain(); bus.connect(master);
      var conv = a.createConvolver(); conv.buffer = impulse(a, 2.2, 2.6);
      wet = a.createGain(); wet.gain.value = rev;
      bus.connect(conv); conv.connect(wet); wet.connect(master);
    }
    return a;
  }
  function impulse(a, sec, decay) {
    var n = Math.floor(a.sampleRate * sec), b = a.createBuffer(2, n, a.sampleRate);
    for (var ch = 0; ch < 2; ch++) {
      var d = b.getChannelData(ch);
      for (var i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, decay);
    }
    return b;
  }
  function noise(a) {
    if (!noiseBuf) {
      var n = a.sampleRate * 2; noiseBuf = a.createBuffer(1, n, a.sampleRate);
      var d = noiseBuf.getChannelData(0);
      for (var i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    }
    return noiseBuf;
  }
  function pwave(a, h) {
    var k = h.join(',');
    if (!waveCache[k]) {
      var re = new Float32Array(h.length + 1), im = new Float32Array(h.length + 1);
      for (var i = 0; i < h.length; i++) im[i + 1] = h[i];
      waveCache[k] = a.createPeriodicWave(re, im);
    }
    return waveCache[k];
  }
  function clampF(f) { return Math.max(30, Math.min(f, 18000)); }
  function track(f, p) { return p.b ? p.b * Math.pow(f / 261.63, p.k == null ? 0.5 : p.k) : f; }
  function filt(a, type, f, q, gain) {
    var b = a.createBiquadFilter(); b.type = type; b.frequency.value = clampF(f);
    if (q != null) b.Q.value = q; if (gain != null) b.gain.value = gain; return b;
  }
  function chain(a, first, p) { // peaks, highpass, lowpass(abs)
    var last = first;
    (p.pk || []).forEach(function (k) { var b = filt(a, 'peaking', k[0], k[1], k[2]); last.connect(b); last = b; });
    if (p.hp) { var h = filt(a, 'highpass', p.hp, 0.7); last.connect(h); last = h; }
    if (p.lpa) { var l = filt(a, 'lowpass', p.lpa, 0.7); last.connect(l); last = l; }
    return last;
  }
  function fade(a, g, nodes, R) {
    var now = a.currentTime;
    if (g.gain.cancelAndHoldAtTime) g.gain.cancelAndHoldAtTime(now);
    else { var v = g.gain.value; g.gain.cancelScheduledValues(now); g.gain.setValueAtTime(v, now); }
    g.gain.setTargetAtTime(0.0001, now, Math.max(0.01, R / 4));
    nodes.forEach(function (n) { try { n.stop(now + R * 1.6 + 0.05); } catch (e) {} });
  }
  function softClip(k) {
    var n = 1024, c = new Float32Array(n), norm = Math.tanh(k);
    for (var i = 0; i < n; i++) { var x = i * 2 / n - 1; c[i] = Math.tanh(k * x) / norm; }
    return c;
  }

  /* ---------- engine: tone (sustained, bowed, blown, organ, synth) ---------- */
  function tone(a, f, p, t) {
    var out = a.createGain(), pre = a.createGain(), nodes = [];
    var peak = p.g || 0.3, wave = p.h ? pwave(a, p.h) : null, uni = p.uni || [0];
    pre.gain.value = 1 / Math.sqrt(uni.length);
    var lg = null;
    if (p.vib) {
      var lfo = a.createOscillator(); lfo.frequency.value = p.vib[0];
      lg = a.createGain(); var vd = t + (p.vib[2] || 0);
      lg.gain.setValueAtTime(0, t); lg.gain.setValueAtTime(0, vd); lg.gain.linearRampToValueAtTime(p.vib[1], vd + 0.35);
      lfo.connect(lg); lfo.start(t); nodes.push(lfo);
    }
    function osc(freq, c, amp) {
      var o = a.createOscillator();
      if (wave) o.setPeriodicWave(wave); else o.type = p.w || 'sawtooth';
      o.frequency.setValueAtTime(freq, t);
      if (p.bend) { o.detune.setValueAtTime(c + p.bend * 100, t); o.detune.linearRampToValueAtTime(c, t + (p.bt || 0.1)); }
      else o.detune.setValueAtTime(c, t);
      if (lg) lg.connect(o.detune);
      var og = a.createGain(); og.gain.value = amp; o.connect(og); og.connect(pre);
      o.start(t); nodes.push(o);
    }
    uni.forEach(function (c) { osc(f, c, 1); });
    if (p.drone) osc(p.drone, 0, 0.6);
    var last = pre;
    if (p.lp) {
      var fl = filt(a, 'lowpass', f * p.lp, p.q || 0.8), cut = clampF(f * p.lp);
      if (p.fe) { fl.frequency.setValueAtTime(clampF(f * p.lp * p.fe), t); fl.frequency.setTargetAtTime(cut, t, p.ft || 0.15); }
      last.connect(fl); last = fl;
    }
    last = chain(a, last, p);
    last.connect(out);
    if (p.n) {
      var ns = a.createBufferSource(); ns.buffer = noise(a); ns.loop = true;
      var nb = filt(a, 'bandpass', f * (p.nf || 2), p.nq || 1.5), ng = a.createGain(); ng.gain.value = p.n;
      ns.connect(nb); nb.connect(ng); ng.connect(out); ns.start(t, Math.random()); nodes.push(ns);
    }
    var A = p.a || 0.01, D = p.d || 0.3, S = p.s == null ? 0.8 : p.s, R = p.r || 0.2;
    out.gain.setValueAtTime(0.0001, t); out.gain.linearRampToValueAtTime(peak, t + A);
    if (S > 0) out.gain.setTargetAtTime(peak * S, t + A, D / 3);
    else {
      out.gain.setTargetAtTime(0.0001, t + A, D / 4);
      nodes.forEach(function (n) { n.stop(t + A + D * 1.6 + 0.05); });
    }
    out.connect(bus);
    var done = false;
    return { stop: function () { if (done) return; done = true; if (S > 0 || p.damp) fade(a, out, nodes, R); } };
  }

  /* ---------- engine: pluck (Karplus-Strong string) ---------- */
  function ks(a, f, p, id) {
    var key = id + '|' + Math.round(f * 8);
    if (ksCache[key]) return ksCache[key];
    var sr = a.sampleRate, dur = p.dur || 2.5, n = Math.floor(sr * dur);
    var bl = p.bl == null ? 0.5 : p.bl, period = sr / f;
    var N = Math.max(2, Math.floor(period - (1 - bl)));
    var line = new Float32Array(N), br = p.br == null ? 0.6 : p.br, lp = 0, mean = 0, i;
    for (i = 0; i < N; i++) { lp += br * ((Math.random() * 2 - 1) - lp); line[i] = lp; mean += lp; }
    mean /= N; var mx = 0.0001;
    for (i = 0; i < N; i++) { line[i] -= mean; mx = Math.max(mx, Math.abs(line[i])); }
    for (i = 0; i < N; i++) line[i] /= mx;
    var buf = a.createBuffer(1, n, sr), d = buf.getChannelData(0);
    var g = Math.pow(0.001, 1 / (f * (p.t60 || 2))), idx = 0;
    for (i = 0; i < n; i++) {
      var cur = line[idx], nx = line[idx + 1 < N ? idx + 1 : 0];
      line[idx] = g * (bl * cur + (1 - bl) * nx); d[i] = cur;
      idx++; if (idx >= N) idx = 0;
    }
    if (p.bz) { // jawari-style buzz: soft clipping keeps upper harmonics alive
      var k = 1 + p.bz * 5, nm = Math.tanh(k);
      for (i = 0; i < n; i++) d[i] = Math.tanh(k * d[i]) / nm;
    }
    var fadeN = Math.min(n, Math.floor(sr * 0.05));
    for (i = 0; i < fadeN; i++) d[n - 1 - i] *= i / fadeN;
    var res = { buf: buf, rate: f * (N + 1 - bl) / sr };
    ksCache[key] = res; ksKeys.push(key);
    if (ksKeys.length > 240) delete ksCache[ksKeys.shift()];
    return res;
  }
  function pluck(a, f, p, t, id) {
    var out = a.createGain(), inp = a.createGain(), nodes = [];
    out.gain.value = p.g || 0.5;
    var cnt = p.cr ? 2 : 1;
    for (var c = 0; c < cnt; c++) {
      var b = ks(a, f, p, id), s = a.createBufferSource(); s.buffer = b.buf;
      var rate = b.rate * (c ? Math.pow(2, p.cr / 1200) : 1), st = t + c * 0.012;
      if (p.sl) { s.playbackRate.setValueAtTime(rate * Math.pow(2, p.sl / 12), st); s.playbackRate.linearRampToValueAtTime(rate, st + (p.st || 0.15)); }
      else s.playbackRate.setValueAtTime(rate, st);
      var sg = a.createGain(); sg.gain.value = cnt > 1 ? 0.7 : 1;
      s.connect(sg); sg.connect(inp); s.start(st); nodes.push(s);
    }
    var last = inp;
    if (p.dist) { var ws = a.createWaveShaper(); ws.curve = softClip(p.dist); ws.oversample = '2x'; last.connect(ws); last = ws; }
    last = chain(a, last, p);
    last.connect(out); out.connect(bus);
    var done = false;
    return { stop: function () { if (done) return; done = true; if (p.damp) fade(a, out, nodes, p.r || 0.2); } };
  }

  /* ---------- engine: mallet (bars, bells, gongs, piano) ---------- */
  function mallet(a, f, p, t) {
    f = track(f, p);
    var out = a.createGain(), nodes = [], T = p.t || 1.5, A = p.a || 0.002, ny = a.sampleRate / 2 - 200;
    out.gain.value = p.g || 0.35;
    p.pt.forEach(function (q) {
      var fr = f * q[0]; if (fr > ny) return;
      var o = a.createOscillator(); o.type = 'sine'; o.frequency.value = fr;
      var g = a.createGain(), dk = T * (q[2] || 1);
      g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(q[1], t + A);
      g.gain.setTargetAtTime(0, t + A, dk / 5);
      o.connect(g); g.connect(out); o.start(t); o.stop(t + dk * 1.3 + 0.1); nodes.push(o);
    });
    if (p.c) {
      var ns = a.createBufferSource(); ns.buffer = noise(a);
      var nb = filt(a, 'bandpass', f * (p.cf || 3), 1.2), ng = a.createGain();
      ng.gain.setValueAtTime(p.c, t); ng.gain.setTargetAtTime(0, t, 0.008);
      ns.connect(nb); nb.connect(ng); ng.connect(out); ns.start(t, Math.random()); ns.stop(t + 0.1);
    }
    if (p.tr) {
      var lfo = a.createOscillator(), lg = a.createGain();
      lfo.frequency.value = p.tr[0]; lg.gain.value = (p.g || 0.35) * p.tr[1];
      lfo.connect(lg); lg.connect(out.gain); lfo.start(t); lfo.stop(t + T * 1.5 + 0.2); nodes.push(lfo);
    }
    chain(a, out, p).connect(bus);
    var done = false;
    return { stop: function () { if (done) return; done = true; if (p.damp) fade(a, out, nodes, p.r || 0.3); } };
  }

  /* ---------- engine: drum (membranes, shakers, jingles, cymbals) ---------- */
  var METAL = [2, 3, 4.16, 5.43, 6.79, 8.21];
  function drum(a, f, p, t) {
    var F = track(f, p), out = a.createGain(), T = p.t || 0.3;
    out.gain.value = p.g || 0.7;
    if (p.tone !== 0) (p.pt || [[1, 1]]).forEach(function (q) {
      var o = a.createOscillator(); o.type = p.w || 'sine';
      var fr = clampF(F * q[0]);
      o.frequency.setValueAtTime(clampF(fr * (p.dr || 1)), t);
      o.frequency.exponentialRampToValueAtTime(fr, t + (p.dt || 0.05));
      var g = a.createGain(), dk = T * (q[2] || 1);
      g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(q[1], t + 0.002);
      g.gain.setTargetAtTime(0, t + 0.002, dk / 5);
      o.connect(g); g.connect(out); o.start(t); o.stop(t + dk * 1.3 + 0.1);
    });
    if (p.n) (p.hits || [0]).forEach(function (h, i) {
      var ns = a.createBufferSource(); ns.buffer = noise(a);
      var nf = filt(a, p.nt || 'bandpass', p.nf || 2000, p.nq || 1), ng = a.createGain(), st = t + h, amp = p.n * (i ? 0.8 : 1);
      ng.gain.setValueAtTime(0, st); ng.gain.linearRampToValueAtTime(amp, st + 0.001);
      ng.gain.setTargetAtTime(0, st + 0.001, (p.nd || 0.05) / 4);
      ns.connect(nf); nf.connect(ng); ng.connect(out); ns.start(st, Math.random()); ns.stop(st + (p.nd || 0.05) * 2 + 0.05);
    });
    if (p.m) {
      var mg = a.createGain(), hp = filt(a, 'highpass', 7000, 0.7), md = p.md || 0.3;
      mg.gain.setValueAtTime(0, t); mg.gain.linearRampToValueAtTime(p.mg || 0.3, t + 0.001);
      mg.gain.setTargetAtTime(0, t + 0.001, md / 5);
      METAL.forEach(function (r) {
        var o = a.createOscillator(); o.type = 'square'; o.frequency.value = p.m * r;
        var og = a.createGain(); og.gain.value = 0.18; o.connect(og); og.connect(hp); o.start(t); o.stop(t + md * 1.3 + 0.1);
      });
      hp.connect(mg); mg.connect(out);
    }
    chain(a, out, p).connect(bus);
    return { stop: function () {} };
  }

  /* ---------- harmonic recipes ---------- */
  var H = {
    flute: [1, .5, .12, .06, .03, .01],
    clar: [1, .02, .75, .02, .5, .02, .14, .02, .5, .02, .12, .01, .17],
    oboe: [.5, 1, .9, .6, .5, .35, .3, .2, .15, .1, .08],
    sax: [1, .8, .6, .55, .4, .35, .25, .2, .15, .1, .08, .06],
    organ: [1, 1, .6, .8, 0, .5, 0, .6, 0, 0, 0, .3, 0, 0, 0, .25],
    rock: [1, 1, 1, .2, 0, .5, 0, .8, 0, 0, 0, .2],
    reed: [1, .7, .6, .5, .45, .4, .35, .3, .25, .2, .18, .15, .12, .1],
    horn: [1, .6, .4, .25, .15, .1, .05],
    duduk: [1, .6, .5, .3, .2, .1, .05]
  };

  /* ---------- drum kit pieces ---------- */
  var KIT = [
    ['KICK', { b: 55, k: 0, t: .45, dr: 2.8, dt: .06, n: .08, nf: 3000, nd: .01, g: 1 }],
    ['RIM', { b: 820, k: 0, pt: [[1, 1], [2.3, .4]], t: .04, n: .3, nf: 2500, nd: .01, g: .5 }],
    ['SNARE', { b: 190, k: 0, pt: [[1, 1], [1.5, .4]], t: .12, dr: 1.4, dt: .02, n: .8, nt: 'highpass', nf: 1800, nd: .16, g: .6 }],
    ['CLAP', { tone: 0, n: .9, nf: 1200, nq: 1, nd: .06, hits: [0, .012, .024, .036], g: .7 }],
    ['SNARE 2', { b: 230, k: 0, pt: [[1, 1]], t: .1, dr: 1.3, n: .7, nt: 'highpass', nf: 2500, nd: .12, g: .6 }],
    ['LO TOM', { b: 90, k: 0, t: .45, dr: 1.6, dt: .05, g: .8 }],
    ['HI-HAT', { tone: 0, m: 40, mg: .45, md: .05, n: .15, nt: 'highpass', nf: 8000, nd: .04, g: .5 }],
    ['MID TOM', { b: 130, k: 0, t: .4, dr: 1.6, dt: .05, g: .8 }],
    ['PEDAL HAT', { tone: 0, m: 40, mg: .35, md: .08, g: .5 }],
    ['HI TOM', { b: 185, k: 0, t: .35, dr: 1.6, dt: .05, g: .8 }],
    ['OPEN HAT', { tone: 0, m: 40, mg: .45, md: .45, n: .15, nt: 'highpass', nf: 8000, nd: .3, g: .5 }],
    ['CRASH', { tone: 0, m: 40, mg: .5, md: 1.5, n: .35, nt: 'highpass', nf: 5000, nd: 1, g: .5 }],
    ['RIDE', { tone: 0, m: 62, mg: .35, md: 1.1, n: .08, nt: 'highpass', nf: 9000, nd: .4, g: .5 }],
    ['COWBELL', { w: 'square', b: 560, k: 0, pt: [[1, 1], [1.48, .7]], t: .3, lpa: 2500, g: .25 }]
  ];

  /* ---------- the instrument catalog ---------- */
  var I = [];
  function add(r, ty, em, n, bn, e, p, o) { I.push({ r: r, ty: ty, em: em, n: n, bn: bn, e: e, p: p, o: o || 0 }); }

  // Bangladesh & the subcontinent
  add('bd', 'perc', '🪘', 'Tabla (Dayan)', 'তবলা', 'drum', { b: 330, k: 1, pt: [[1, 1, 1], [2, .6, .7], [3, .4, .5], [4, .25, .4], [5, .15, .3]], t: 1.2, dr: 1.02, dt: .02, n: .25, nf: 3500, nq: 1.5, nd: .02, g: .5 });
  add('bd', 'perc', '🪘', 'Bayan (Tabla Bass)', 'বায়া', 'drum', { b: 85, k: .4, pt: [[1, 1], [2, .3, .6]], t: 1, dr: .75, dt: .18, n: .15, nf: 600, nd: .03, g: .9 });
  add('bd', 'perc', '🥁', 'Dhol', 'ঢোল', 'drum', { b: 105, k: .4, pt: [[1, 1], [1.6, .4, .6]], t: .5, dr: 1.8, dt: .06, n: .35, nf: 1800, nq: .8, nd: .06, g: .9 });
  add('bd', 'perc', '🥁', 'Dhak', 'ঢাক', 'drum', { b: 150, k: .4, pt: [[1, 1], [1.5, .5, .5], [2.3, .3, .4]], t: .45, dr: 1.6, dt: .05, n: .6, nf: 2600, nq: .7, nd: .09, g: .8 });
  add('bd', 'perc', '🪘', 'Khol (Kirtan)', 'খোল', 'drum', { b: 200, k: .7, pt: [[1, 1], [2, .5, .7], [3, .3, .5]], t: .7, dr: 1.15, dt: .04, n: .2, nf: 2500, nd: .03, g: .7 });
  add('bd', 'perc', '🪘', 'Mridangam', 'মৃদঙ্গ', 'drum', { b: 240, k: 1, pt: [[1, 1], [2, .7, .8], [3, .45, .6], [4, .3, .4]], t: .6, dr: 1.05, dt: .02, n: .35, nf: 4000, nd: .015, g: .6 });
  add('bd', 'perc', '🥁', 'Dholak', 'ঢোলক', 'drum', { b: 190, k: .6, pt: [[1, 1], [1.7, .35, .5]], t: .35, dr: 1.5, dt: .04, n: .3, nf: 3000, nd: .03, g: .8 });
  add('bd', 'perc', '🏺', 'Ghatam (Clay Pot)', 'ঘটম', 'drum', { b: 380, k: .6, pt: [[1, 1], [2.4, .4, .5]], t: .18, dr: 1.1, dt: .02, n: .6, nf: 2200, nq: 2, nd: .03, g: .7 });
  add('bd', 'perc', '🪇', 'Dubki (Baul Tambourine)', 'ডুবকি', 'drum', { b: 200, k: .3, pt: [[1, .5]], t: .15, n: .5, nt: 'highpass', nf: 6000, nd: .12, hits: [0, .02, .045], m: 520, mg: .18, md: .25, g: .6 });
  add('bd', 'perc', '🔔', 'Ghungroo', 'ঘুঙুর', 'drum', { tone: 0, n: .4, nf: 7500, nq: 2, nd: .06, hits: [0, .025, .05, .08], m: 700, mg: .12, md: .2, g: .6 });
  add('bd', 'perc', '🥣', 'Mandira / Kartal', 'মন্দিরা / করতাল', 'mallet', { b: 1800, k: .3, pt: [[1, 1, 1], [2.41, .6, .6], [3.9, .4, .4], [5.2, .25, .3]], t: 2.2, c: .3, cf: 3, g: .18 });
  add('bd', 'str', '🪕', 'Ektara', 'একতারা', 'pluck', { t60: 1.6, br: .8, bz: .35, sl: -1.2, st: .25, pk: [[700, 2, 5], [2200, 3, 4]], g: .6 });
  add('bd', 'str', '🪕', 'Dotara', 'দোতারা', 'pluck', { t60: 2, br: .75, bz: .15, pk: [[900, 2, 5]], g: .6 });
  add('bd', 'str', '🪕', 'Khamak', 'খমক', 'pluck', { t60: .7, br: .9, bz: .5, sl: 2, st: .15, pk: [[500, 3, 8]], g: .6 }, -1);
  add('bd', 'str', '🪕', 'Sitar', 'সেতার', 'pluck', { t60: 3.5, dur: 3.5, br: .95, bz: .6, sl: -.7, st: .12, pk: [[1200, 2, 6], [3200, 3, 6]], hp: 120, g: .5 });
  add('bd', 'str', '🪕', 'Sarod', 'সরোদ', 'pluck', { t60: 2.4, br: .7, bz: .2, sl: -1, st: .3, pk: [[800, 1.5, 5]], g: .6 });
  add('bd', 'str', '🪕', 'Veena', 'বীণা', 'pluck', { t60: 4, dur: 4, br: .6, bz: .35, pk: [[600, 1.5, 5]], g: .6 }, -1);
  add('bd', 'str', '🪕', 'Tanpura (Drone)', 'তানপুরা', 'pluck', { t60: 5, dur: 5, br: .7, bz: .8, pk: [[1500, 1, 6]], g: .5 }, -1);
  add('bd', 'str', '🎼', 'Santoor', 'সন্তুর', 'pluck', { t60: 2.5, br: 1, cr: 6, pk: [[2500, 2, 4]], g: .5 });
  add('bd', 'str', '🎻', 'Sarangi', 'সারেঙ্গী', 'tone', { w: 'sawtooth', a: .15, d: .4, s: .85, r: .25, lp: 7, q: .7, vib: [5.5, 22, .25], bend: -.8, bt: .2, pk: [[1100, 3, 7], [2600, 4, 6]], g: .17 });
  add('bd', 'str', '🎻', 'Esraj', 'এস্রাজ', 'tone', { w: 'sawtooth', a: .2, d: .5, s: .8, r: .3, lp: 4, vib: [5, 15, .3], pk: [[900, 2, 5]], g: .18 });
  add('bd', 'wind', '🎋', 'Bansuri (Bamboo Flute)', 'বাঁশি', 'tone', { h: H.flute, a: .08, d: .3, s: .9, r: .15, vib: [5, 14, .25], bend: -.4, bt: .08, n: .12, nf: 2, nq: 1.2, g: .35 }, 1);
  add('bd', 'wind', '🎺', 'Shehnai', 'সানাই', 'tone', { h: H.oboe, a: .05, d: .2, s: .9, r: .12, lp: 10, vib: [6, 28, .15], bend: -.5, bt: .07, pk: [[1500, 3, 8], [3000, 4, 4]], g: .2 }, 1);
  add('bd', 'key', '🪗', 'Harmonium', 'হারমোনিয়াম', 'tone', { w: 'sawtooth', uni: [-5, 0, 6], a: .07, d: .3, s: .9, r: .15, lp: 5, pk: [[1000, 1, 3]], g: .16 });
  add('bd', 'wind', '🐍', 'Been / Pungi', 'বীণ / পুঙ্গি', 'tone', { h: H.clar, a: .04, d: .2, s: .9, r: .1, vib: [6.5, 35, .1], pk: [[1300, 4, 8]], drone: 130.81, g: .18 }, 1);
  add('bd', 'wind', '🐚', 'Shankha (Conch)', 'শঙ্খ', 'tone', { w: 'sawtooth', a: .35, d: .6, s: .8, r: .4, lp: 2.5, fe: .4, ft: .3, bend: -2, bt: .5, vib: [4, 10, .5], n: .15, nf: 1.5, g: .25 }, -1);
  add('bd', 'perc', '💧', 'Jaltarang (Water Bowls)', 'জলতরঙ্গ', 'mallet', { pt: [[1, 1, 1], [2.32, .25, .4], [4.25, .08, .2]], t: 1.6, c: .05, g: .35 }, 1);

  // Orchestra
  add('or', 'key', '🎹', 'Grand Piano', 'গ্র্যান্ড পিয়ানো', 'mallet', { pt: [[1, 1, 1], [2.002, .55, .7], [3.005, .32, .5], [4.01, .2, .4], [5.02, .12, .3], [6.03, .08, .25], [7.05, .04, .2]], t: 4, a: .003, c: .06, cf: 4, damp: 1, r: .3, g: .3 });
  add('or', 'key', '🎹', 'Harpsichord', 'হার্পসিকর্ড', 'pluck', { t60: 1.5, br: 1, bl: .15, hp: 200, pk: [[3000, 1, 4]], damp: 1, r: .15, g: .45 });
  add('or', 'key', '⛪', 'Pipe Organ', 'পাইপ অর্গান', 'tone', { h: H.organ, uni: [0, 3], a: .06, s: 1, r: .25, g: .15 });
  add('or', 'key', '✨', 'Celesta', 'চেলেস্তা', 'mallet', { pt: [[1, 1, 1], [2, .3, .4], [4.02, .1, .2]], t: 1.5, c: .05, g: .35 }, 1);
  add('or', 'str', '🎻', 'Violin', 'বেহালা', 'tone', { w: 'sawtooth', a: .12, s: .85, r: .2, lp: 8, vib: [5.8, 18, .2], pk: [[500, 2, 4], [3000, 2, 5]], hp: 180, g: .17 }, 1);
  add('or', 'str', '🎻', 'Viola', 'ভায়োলা', 'tone', { w: 'sawtooth', a: .14, s: .85, r: .22, lp: 6, vib: [5.5, 16, .2], pk: [[400, 2, 4], [2200, 2, 4]], hp: 120, g: .18 });
  add('or', 'str', '🎻', 'Cello', 'চেলো', 'tone', { w: 'sawtooth', a: .15, s: .85, r: .3, lp: 6, vib: [5.2, 15, .25], pk: [[250, 2, 5], [1500, 2, 3]], g: .2 }, -1);
  add('or', 'str', '🎻', 'Double Bass', 'ডাবল বেস', 'tone', { w: 'sawtooth', a: .12, s: .85, r: .3, lp: 5, vib: [5, 10, .3], pk: [[150, 2, 5]], g: .25 }, -2);
  add('or', 'str', '🎻', 'String Ensemble', 'স্ট্রিং অর্কেস্ট্রা', 'tone', { w: 'sawtooth', uni: [-9, -3, 4, 10], a: .35, s: .9, r: .6, lp: 5, vib: [5.5, 8, .3], g: .14 });
  add('or', 'str', '🪉', 'Concert Harp', 'হার্প', 'pluck', { t60: 3, br: .5, g: .6 });
  add('or', 'wind', '🪈', 'Flute', 'ফ্লুট', 'tone', { h: H.flute, a: .06, s: .9, r: .15, vib: [5, 12, .3], n: .08, nf: 2, g: .35 }, 1);
  add('or', 'wind', '🪈', 'Piccolo', 'পিকোলো', 'tone', { h: [1, .3, .08], a: .04, s: .9, r: .1, vib: [5.5, 12, .3], n: .06, nf: 2, g: .3 }, 2);
  add('or', 'wind', '🎷', 'Clarinet', 'ক্লারিনেট', 'tone', { h: H.clar, a: .05, s: .9, r: .12, vib: [5, 6, .4], g: .25 });
  add('or', 'wind', '🎷', 'Oboe', 'ওবো', 'tone', { h: H.oboe, a: .05, s: .9, r: .12, vib: [5.5, 12, .3], pk: [[1400, 2, 5]], g: .22 }, 1);
  add('or', 'wind', '🎷', 'Bassoon', 'বাসুন', 'tone', { h: H.reed, a: .06, s: .9, r: .15, lp: 6, pk: [[500, 2, 5]], g: .22 }, -1);
  add('or', 'wind', '🎷', 'Alto Saxophone', 'স্যাক্সোফোন', 'tone', { h: H.sax, a: .05, s: .85, r: .15, lp: 8, fe: .5, ft: .1, vib: [5, 14, .3], n: .06, nf: 3, pk: [[1200, 2, 4]], g: .22 });
  add('or', 'wind', '🎷', 'Tenor Saxophone', 'টেনর স্যাক্স', 'tone', { h: H.sax, a: .05, s: .85, r: .15, lp: 6, fe: .5, ft: .1, vib: [4.8, 14, .3], n: .06, nf: 3, pk: [[800, 2, 4]], g: .24 }, -1);
  add('or', 'wind', '🎺', 'Trumpet', 'ট্রাম্পেট', 'tone', { w: 'sawtooth', a: .04, s: .85, r: .1, lp: 8, fe: .25, ft: .06, bend: -.3, bt: .05, vib: [5.5, 10, .35], pk: [[1500, 1.5, 5]], g: .17 }, 1);
  add('or', 'wind', '🎺', 'Trombone', 'ট্রমবোন', 'tone', { w: 'sawtooth', a: .06, s: .85, r: .15, lp: 5, fe: .3, ft: .08, bend: -.6, bt: .08, pk: [[600, 1.5, 4]], g: .2 }, -1);
  add('or', 'wind', '📯', 'French Horn', 'ফ্রেঞ্চ হর্ন', 'tone', { w: 'sawtooth', a: .08, s: .85, r: .2, lp: 3, fe: .4, ft: .1, vib: [5, 6, .4], g: .25 });
  add('or', 'wind', '🎺', 'Tuba', 'টুবা', 'tone', { w: 'sawtooth', a: .07, s: .85, r: .15, lp: 4, fe: .4, ft: .1, g: .3 }, -2);
  add('or', 'perc', '🥁', 'Timpani', 'টিম্পানি', 'drum', { b: 110, k: .8, pt: [[1, 1, 1], [1.5, .5, .8], [1.98, .35, .6], [2.44, .2, .5]], t: 2.2, dr: 1.02, n: .2, nf: 800, nd: .05, g: .8 });
  add('or', 'perc', '🥁', 'Snare Drum', 'স্নেয়ার ড্রাম', 'drum', { b: 200, k: .2, pt: [[1, 1], [1.6, .5]], t: .15, dr: 1.3, n: .7, nt: 'highpass', nf: 1500, nd: .18, g: .6 });
  add('or', 'perc', '🥁', 'Concert Bass Drum', 'বেস ড্রাম', 'drum', { b: 55, k: .2, t: 1.2, dr: 1.3, dt: .08, n: .2, nf: 200, nd: .08, g: 1 });
  add('or', 'perc', '💥', 'Orchestral Cymbals', 'সিম্বল', 'drum', { tone: 0, m: 40, mg: .5, md: 1.8, n: .3, nt: 'highpass', nf: 6000, nd: 1.2, g: .5 });
  add('or', 'perc', '🔺', 'Triangle', 'ট্রায়াঙ্গেল', 'mallet', { b: 3200, k: .2, pt: [[1, 1, 1], [2.76, .5, .8], [5.4, .3, .6]], t: 3, c: .1, g: .12 });
  add('or', 'perc', '🔔', 'Glockenspiel', 'গ্লকেনস্পিল', 'mallet', { pt: [[1, 1, 1], [2.76, .4, .5], [5.4, .2, .3], [8.93, .1, .2]], t: 2, c: .05, g: .25 }, 2);
  add('or', 'perc', '🎵', 'Xylophone', 'জাইলোফোন', 'mallet', { pt: [[1, 1, 1], [3, .3, .5], [6, .1, .3]], t: .5, c: .2, g: .4 }, 1);
  add('or', 'perc', '🎵', 'Marimba', 'মারিম্বা', 'mallet', { pt: [[1, 1, 1], [4, .35, .4], [10, .08, .2]], t: 1.2, c: .1, g: .45 });
  add('or', 'perc', '🎵', 'Vibraphone', 'ভাইব্রাফোন', 'mallet', { pt: [[1, 1, 1], [4, .25, .4]], t: 3.5, tr: [5.5, .35], damp: 1, r: .6, g: .3 });
  add('or', 'perc', '🔔', 'Tubular Bells', 'টিউবুলার বেল', 'mallet', { pt: [[1, 1, 1], [2.02, .5, .8], [3.02, .3, .6], [4.2, .25, .5], [5.4, .15, .4]], t: 4, c: .1, cf: 2, g: .2 });
  add('or', 'wind', '🎤', 'Choir (Aah)', 'কোরাস', 'tone', { w: 'sawtooth', uni: [-8, 0, 7], a: .3, s: .9, r: .5, lp: 6, pk: [[700, 4, 10], [1150, 5, 8], [2800, 5, 6]], vib: [5, 12, .3], g: .12 });

  // Band & electronic
  add('mo', 'str', '🎸', 'Acoustic Guitar', 'অ্যাকুস্টিক গিটার', 'pluck', { t60: 2.5, br: .65, pk: [[110, 1, 4], [2500, 2, 3]], g: .6 }, -1);
  add('mo', 'str', '🎸', '12-String Guitar', '১২-তারের গিটার', 'pluck', { t60: 2.5, br: .75, cr: 8, pk: [[2500, 2, 3]], g: .55 }, -1);
  add('mo', 'str', '🎸', 'Electric Guitar (Clean)', 'ইলেকট্রিক গিটার', 'pluck', { t60: 3, br: .5, lpa: 4500, pk: [[1200, 1, 3]], g: .55 }, -1);
  add('mo', 'str', '🤘', 'Distortion Guitar', 'ডিস্টরশন গিটার', 'pluck', { t60: 3, br: .6, dist: 30, lpa: 3500, pk: [[800, 1, 4]], damp: 1, r: .15, g: .16 }, -1);
  add('mo', 'str', '🎸', 'Bass Guitar', 'বেস গিটার', 'pluck', { t60: 2, br: .4, lpa: 1800, damp: 1, r: .1, g: .9 }, -2);
  add('mo', 'key', '🎛️', 'Synth Bass', 'সিনথ বেস', 'tone', { w: 'sawtooth', a: .005, d: .25, s: .5, r: .08, lp: 3, fe: 6, ft: .08, q: 6, g: .25 }, -2);
  add('mo', 'key', '🎹', 'Electric Piano', 'ইলেকট্রিক পিয়ানো', 'mallet', { pt: [[1, 1, 1], [2, .25, .4], [3, .08, .3], [14, .06, .05]], t: 2.5, tr: [4, .15], damp: 1, r: .3, g: .35 });
  add('mo', 'key', '🎹', 'Rock Organ', 'রক অর্গান', 'tone', { h: H.rock, uni: [0, 6], a: .01, s: 1, r: .08, g: .13 });
  add('mo', 'key', '🎛️', 'Synth Lead', 'সিনথ লিড', 'tone', { w: 'square', uni: [-8, 8], a: .01, s: .8, r: .15, lp: 6, fe: 3, q: 3, vib: [6, 15, .25], g: .1 });
  add('mo', 'key', '🌌', 'Synth Pad', 'সিনথ প্যাড', 'tone', { w: 'sawtooth', uni: [-12, -5, 5, 12], a: .6, s: .9, r: 1.2, lp: 3, fe: .3, ft: .8, g: .1 });
  add('mo', 'key', '👾', '8-bit Chiptune', '৮-বিট গেম সাউন্ড', 'tone', { w: 'square', a: .002, d: .1, s: .6, r: .03, g: .09 });
  add('mo', 'key', '🛸', 'Theremin', 'থেরেমিন', 'tone', { w: 'sine', a: .15, s: .9, r: .3, vib: [6, 30, .2], bend: -1, bt: .15, g: .35 }, 1);
  add('mo', 'perc', '🥁', 'Drum Kit', 'ড্রাম কিট', 'kit', {});

  // East Asia
  add('ea', 'str', '🎏', 'Koto (Japan)', 'কোতো', 'pluck', { t60: 2.5, br: .85, pk: [[1500, 2, 5]], g: .55 });
  add('ea', 'str', '🎏', 'Shamisen (Japan)', 'শামিসেন', 'pluck', { t60: .9, br: 1, bz: .45, pk: [[1800, 2, 7]], hp: 150, g: .55 });
  add('ea', 'wind', '🎍', 'Shakuhachi (Japan)', 'শাকুহাচি', 'tone', { h: [1, .3, .08, .03], a: .12, s: .85, r: .2, vib: [4.5, 20, .4], bend: -.8, bt: .2, n: .35, nf: 2, nq: .8, g: .33 });
  add('ea', 'perc', '🥁', 'Taiko (Japan)', 'তাইকো', 'drum', { b: 70, k: .3, pt: [[1, 1], [1.8, .3, .5]], t: 1, dr: 1.7, dt: .08, n: .3, nf: 900, nd: .06, g: 1 });
  add('ea', 'str', '🎻', 'Erhu (China)', 'আরহু', 'tone', { w: 'sawtooth', a: .12, s: .85, r: .2, lp: 6, vib: [6, 30, .15], bend: -1, bt: .15, pk: [[1000, 3, 8], [2200, 3, 4]], hp: 250, g: .17 }, 1);
  add('ea', 'str', '🏮', 'Guzheng (China)', 'গুঝেং', 'pluck', { t60: 3, br: .8, sl: -.5, st: .2, pk: [[2000, 2, 4]], g: .55 });
  add('ea', 'str', '🏮', 'Pipa (China)', 'পিপা', 'pluck', { t60: 1.2, br: .95, pk: [[1200, 2, 5]], g: .55 });
  add('ea', 'wind', '🎋', 'Dizi (China)', 'ডিজি', 'tone', { h: [1, .4, .15, .08, .05], a: .05, s: .9, r: .12, vib: [5.5, 14, .25], n: .2, nf: 2, pk: [[3000, 3, 6]], g: .3 }, 1);
  add('ea', 'str', '🏮', 'Yangqin (China)', 'ইয়াংচিন', 'pluck', { t60: 2, br: 1, cr: 7, pk: [[2200, 2, 4]], g: .5 });
  add('ea', 'wind', '🎐', 'Sheng (China)', 'শেং', 'tone', { h: H.reed, uni: [0, 702], a: .05, s: .9, r: .12, lp: 6, g: .13 });
  add('ea', 'str', '🇰🇷', 'Gayageum (Korea)', 'গায়াগেউম', 'pluck', { t60: 2, br: .6, sl: -.8, st: .3, pk: [[1000, 2, 4]], g: .6 });
  add('ea', 'perc', '🥮', 'Chinese Gong', 'গং', 'mallet', { b: 110, k: .3, pt: [[1, 1, 1.2], [1.48, .6, 1], [2.04, .5, .9], [2.67, .4, .7], [3.12, .3, .6], [4.2, .2, .5]], t: 5, a: .02, c: .2, cf: 2, g: .3 });
  add('ea', 'perc', '🪵', 'Wood Block', 'উড ব্লক', 'drum', { b: 900, k: .5, pt: [[1, 1], [2.6, .3]], t: .06, n: .2, nf: 2000, nd: .01, g: .6 });
  add('ea', 'perc', '🥣', 'Singing Bowl (Tibet)', 'সিংগিং বোল', 'mallet', { pt: [[1, 1, 1], [2.71, .5, .8], [5.1, .25, .6]], t: 6, a: .05, tr: [4, .2], g: .3 });

  // Middle East & Central Asia
  add('me', 'str', '🪕', 'Oud', 'উদ', 'pluck', { t60: 1.6, br: .7, cr: 4, pk: [[250, 1.5, 5], [1200, 2, 3]], g: .55 }, -1);
  add('me', 'str', '🎼', 'Qanun', 'কানুন', 'pluck', { t60: 2, br: .95, cr: 5, pk: [[2000, 2, 4]], g: .5 });
  add('me', 'wind', '🎋', 'Ney', 'নেই বাঁশি', 'tone', { h: [1, .25, .1, .04], a: .15, s: .85, r: .25, vib: [5, 15, .4], n: .45, nf: 1.8, nq: .9, bend: -.5, bt: .2, g: .3 });
  add('me', 'wind', '🎷', 'Duduk (Armenia)', 'দুদুক', 'tone', { h: H.duduk, a: .12, s: .9, r: .2, lp: 4, vib: [5, 18, .35], bend: -.7, bt: .2, pk: [[600, 2, 5]], g: .25 });
  add('me', 'wind', '🎺', 'Zurna', 'জুর্না', 'tone', { h: H.oboe, a: .03, s: .9, r: .1, lp: 12, vib: [6, 20, .2], pk: [[1800, 2, 9]], g: .16 }, 1);
  add('me', 'str', '🎻', 'Kamancheh (Persia)', 'কামানচে', 'tone', { w: 'sawtooth', a: .15, s: .85, r: .25, lp: 6, vib: [6, 25, .2], bend: -.6, bt: .15, pk: [[1300, 3, 7]], hp: 200, g: .17 });
  add('me', 'str', '🪕', 'Saz / Bağlama (Turkey)', 'সাজ', 'pluck', { t60: 1.8, br: .9, cr: 3, bz: .1, pk: [[1500, 2, 6]], g: .55 });
  add('me', 'str', '🪕', 'Tar (Persia)', 'তার', 'pluck', { t60: 1.5, br: .85, cr: 5, pk: [[1100, 3, 6]], g: .55 });
  add('me', 'str', '🪕', 'Rubab (Afghanistan)', 'রুবাব', 'pluck', { t60: 2.2, br: .8, bz: .2, pk: [[700, 2, 5]], g: .55 });
  add('me', 'str', '🪕', 'Dombra (Kazakhstan)', 'দোমব্রা', 'pluck', { t60: 1.3, br: .7, pk: [[900, 2, 4]], g: .6 });
  add('me', 'perc', '🪘', 'Darbuka', 'দারবুকা', 'drum', { b: 180, k: .9, pt: [[1, 1], [2.1, .3]], t: .35, dr: 1.25, dt: .03, n: .3, nf: 5000, nd: .02, g: .7 });
  add('me', 'perc', '🪘', 'Daf (Frame Drum)', 'দফ', 'drum', { b: 120, k: .4, t: .4, dr: 1.3, n: .5, nt: 'highpass', nf: 3000, nd: .15, m: 500, mg: .12, md: .3, g: .7 });
  add('me', 'perc', '🪇', 'Riq (Tambourine)', 'রিক', 'drum', { tone: 0, n: .5, nt: 'highpass', nf: 7000, nd: .1, hits: [0, .015], m: 600, mg: .2, md: .3, g: .6 });

  // Africa
  add('af', 'perc', '🪘', 'Djembe', 'জেম্বে', 'drum', { b: 260, k: .7, pt: [[1, 1], [1.6, .3, .5]], t: .25, dr: 1.4, dt: .03, n: .45, nf: 2500, nq: .8, nd: .04, g: .8 });
  add('af', 'perc', '🥁', 'Talking Drum', 'টকিং ড্রাম', 'drum', { b: 180, k: .6, pt: [[1, 1], [1.5, .3]], t: .5, dr: .75, dt: .2, n: .15, nf: 1500, nd: .02, g: .9 });
  add('af', 'perc', '🎶', 'Kalimba / Mbira', 'কালিম্বা', 'mallet', { pt: [[1, 1, 1], [5.4, .25, .3], [8.8, .1, .2]], t: 2, c: .15, cf: 2, g: .4 }, 1);
  add('af', 'str', '🪉', 'Kora', 'কোরা', 'pluck', { t60: 3, br: .6, pk: [[300, 1, 4], [2000, 2, 3]], g: .6 });
  add('af', 'perc', '🎵', 'Balafon', 'বালাফোন', 'mallet', { pt: [[1, 1, 1], [3.9, .4, .4], [9.5, .15, .2]], t: .7, c: .3, cf: 2.5, tr: [38, .3], g: .4 });
  add('af', 'perc', '🪇', 'Shekere', 'শেকেরে', 'drum', { tone: 0, n: .6, nf: 4500, nq: .8, nd: .12, hits: [0, .03, .06], g: .6 });
  add('af', 'perc', '🏺', 'Udu (Clay Pot Drum)', 'উডু', 'drum', { b: 110, k: .5, t: .6, dr: .6, dt: .12, n: .1, nf: 400, nd: .02, g: 1 });
  add('af', 'str', '🪕', 'Ngoni', 'এনগোনি', 'pluck', { t60: 1.4, br: .85, bz: .2, pk: [[1200, 2, 5]], g: .55 });
  add('af', 'str', '🎻', 'Masenqo (Ethiopia)', 'মাসেনকো', 'tone', { w: 'sawtooth', a: .1, s: .8, r: .2, lp: 5, vib: [6, 25, .2], pk: [[800, 2, 5]], g: .18 });
  add('af', 'perc', '🔔', 'Agogo Bells', 'আগোগো বেল', 'mallet', { pt: [[1, 1, 1], [2.4, .4, .6], [3.9, .2, .4]], t: .9, c: .3, cf: 2, g: .25 }, 1);

  // The Americas
  add('am', 'perc', '🛢️', 'Steel Drum (Trinidad)', 'স্টিল ড্রাম', 'mallet', { pt: [[1, 1, 1], [2, .6, .7], [3, .3, .5], [4.03, .15, .3]], a: .004, t: 1.4, c: .08, g: .3 }, 1);
  add('am', 'wind', '🎋', 'Pan Flute (Andes)', 'প্যান ফ্লুট', 'tone', { h: [1, .15, .05], a: .05, s: .8, r: .2, n: .5, nf: 1.5, nq: 1, vib: [5, 10, .3], g: .3 }, 1);
  add('am', 'wind', '🪈', 'Quena (Andes)', 'কেনা', 'tone', { h: H.flute, a: .06, s: .85, r: .15, n: .25, nf: 2, vib: [5.5, 16, .25], g: .3 }, 1);
  add('am', 'str', '🪕', 'Charango (Andes)', 'চারাঙ্গো', 'pluck', { t60: 1.5, br: .9, cr: 10, pk: [[2500, 2, 4]], g: .5 }, 1);
  add('am', 'str', '🪕', 'Banjo', 'ব্যাঞ্জো', 'pluck', { t60: 1, br: 1, bl: .2, hp: 300, pk: [[2000, 2, 6]], g: .5 });
  add('am', 'wind', '🎵', 'Harmonica', 'হারমোনিকা', 'tone', { h: H.reed, uni: [0, 10], a: .03, s: .85, r: .1, lp: 5, vib: [5, 10, .3], bend: -.3, bt: .06, g: .17 }, 1);
  add('am', 'perc', '🪘', 'Congas (Cuba)', 'কঙ্গা', 'drum', { b: 200, k: .6, pt: [[1, 1], [1.5, .3]], t: .4, dr: 1.15, dt: .03, n: .3, nf: 2000, nd: .02, g: .8 });
  add('am', 'perc', '🪘', 'Bongos (Cuba)', 'বঙ্গো', 'drum', { b: 400, k: .6, t: .2, dr: 1.1, dt: .02, n: .3, nf: 4000, nd: .015, g: .7 });
  add('am', 'perc', '📦', 'Cajón (Peru)', 'কাহোন', 'drum', { b: 90, k: .4, t: .25, dr: 1.4, dt: .03, n: .5, nf: 2500, nq: .6, nd: .08, g: .9 });
  add('am', 'perc', '🪇', 'Maracas', 'মারাকাস', 'drum', { tone: 0, n: .6, nt: 'highpass', nf: 5000, nd: .06, hits: [0, .04], g: .6 });
  add('am', 'perc', '🪵', 'Güiro', 'গুইরো', 'drum', { tone: 0, n: .5, nf: 3000, nq: 3, nd: .015, hits: [0, .03, .06, .09, .12, .15, .18], g: .7 });
  add('am', 'perc', '🥢', 'Claves', 'ক্লেভস', 'mallet', { b: 2500, k: .3, pt: [[1, 1, 1], [2.6, .2, .4]], t: .25, c: .2, g: .3 });
  add('am', 'perc', '🐄', 'Cowbell', 'কাউবেল', 'drum', { w: 'square', b: 560, k: .3, pt: [[1, 1], [1.48, .7]], t: .3, lpa: 2500, g: .25 });
  add('am', 'wind', '🥚', 'Ocarina', 'ওকারিনা', 'tone', { h: [1, .1], a: .04, s: .85, r: .12, vib: [5, 12, .3], n: .1, nf: 2, g: .35 }, 1);
  add('am', 'key', '🪗', 'Bandoneón (Tango)', 'বান্দোনিয়ন', 'tone', { w: 'sawtooth', uni: [-4, 4], a: .05, s: .9, r: .12, lp: 4, pk: [[1200, 1, 3]], g: .14 });

  // Southeast Asia & Oceania
  add('so', 'perc', '🔔', 'Gamelan Saron (Indonesia)', 'গামেলান সারোন', 'mallet', { pt: [[1, 1, 1], [2.39, .5, .7], [4.13, .3, .5], [5.9, .15, .3]], t: 2.5, c: .2, cf: 3, g: .3 });
  add('so', 'perc', '🔔', 'Gamelan Gendér (Bali)', 'গামেলান গেন্ডার', 'mallet', { pt: [[1, 1, 1], [1.008, .8, 1], [2.39, .3, .6], [4.13, .15, .4]], t: 3, c: .1, damp: 1, r: .4, g: .25 });
  add('so', 'perc', '🥮', 'Bonang (Gong Kettles)', 'বোনাং', 'mallet', { pt: [[1, 1, 1], [1.52, .4, .7], [2.68, .3, .5], [3.95, .15, .3]], t: 2, a: .004, c: .15, g: .3 });
  add('so', 'perc', '🎋', 'Angklung (Bamboo)', 'আংক্লুং', 'mallet', { pt: [[1, 1, 1], [2, .5, .6], [3, .2, .4]], t: .9, tr: [12, .9], c: .1, g: .35 }, 1);
  add('so', 'perc', '🥮', 'Kulintang (Philippines)', 'কুলিনটাং', 'mallet', { pt: [[1, 1, 1], [2.3, .4, .6], [3.6, .15, .4]], t: 1.5, c: .15, g: .3 });
  add('so', 'perc', '🎵', 'Ranat (Thailand)', 'রানাট', 'mallet', { pt: [[1, 1, 1], [3.2, .3, .4], [6.5, .1, .2]], t: .6, c: .2, g: .4 }, 1);
  add('so', 'str', '🎐', 'Đàn bầu (Vietnam)', 'দান বাউ', 'pluck', { t60: 2.5, br: .3, sl: -2, st: .4, lpa: 2500, g: .7 });
  add('so', 'wind', '🎐', 'Khene (Laos)', 'খেন', 'tone', { h: H.reed, uni: [0, 700], a: .04, s: .9, r: .12, lp: 5, g: .13 });
  add('so', 'wind', '🪵', 'Didgeridoo (Australia)', 'ডিজেরিডু', 'tone', { w: 'sawtooth', a: .1, s: .9, r: .2, lp: 4, pk: [[400, 4, 12], [1200, 5, 8]], vib: [2, 6, 0], g: .3 }, -2);
  add('so', 'str', '🌺', 'Ukulele (Hawaii)', 'ইউকুলেলে', 'pluck', { t60: 1.3, br: .7, pk: [[400, 1.5, 4], [2000, 2, 3]], g: .55 });
  add('so', 'str', '🌴', 'Hawaiian Steel Guitar', 'হাওয়াইয়ান গিটার', 'pluck', { t60: 3, br: .6, sl: -2, st: .4, g: .6 }, -1);
  add('so', 'perc', '🪵', 'Slit Log Drum (Pacific)', 'লগ ড্রাম', 'drum', { b: 180, k: .7, pt: [[1, 1], [2.5, .3]], t: .4, dr: 1.02, n: .2, nf: 1500, nd: .02, g: .8 });

  // European folk & more
  add('eu', 'wind', '🏴', 'Bagpipes (Scotland)', 'ব্যাগপাইপ', 'tone', { h: H.oboe, a: .03, s: 1, r: .08, lp: 10, pk: [[1800, 2, 6]], drone: 130.81, g: .13 }, 1);
  add('eu', 'key', '🪗', 'Accordion', 'অ্যাকর্ডিয়ন', 'tone', { w: 'sawtooth', uni: [-12, 0, 12], a: .04, s: .9, r: .12, lp: 4, pk: [[1500, 1, 3]], g: .13 });
  add('eu', 'wind', '☘️', 'Tin Whistle (Ireland)', 'টিন হুইসেল', 'tone', { h: [1, .2, .05], a: .03, s: .85, r: .1, n: .15, nf: 2, vib: [5.5, 12, .3], g: .3 }, 2);
  add('eu', 'wind', '🪈', 'Recorder', 'রেকর্ডার', 'tone', { h: [1, .12, .06, .02], a: .03, s: .85, r: .1, n: .08, nf: 2, g: .32 }, 1);
  add('eu', 'perc', '🥁', 'Bodhrán (Ireland)', 'বোধরান', 'drum', { b: 80, k: .4, t: .35, dr: 1.5, dt: .04, n: .3, nf: 700, nd: .05, g: .9 });
  add('eu', 'str', '🎡', 'Hurdy-Gurdy', 'হার্ডি-গার্ডি', 'tone', { w: 'sawtooth', a: .05, s: .9, r: .1, lp: 6, pk: [[1500, 3, 6]], drone: 130.81, g: .12 });
  add('eu', 'str', '🔺', 'Balalaika (Russia)', 'বালালাইকা', 'pluck', { t60: 1.2, br: .9, pk: [[1500, 2, 5]], g: .55 }, 1);
  add('eu', 'str', '🪕', 'Bouzouki (Greece)', 'বুজুকি', 'pluck', { t60: 2, br: .9, cr: 6, pk: [[1800, 2, 4]], g: .5 });
  add('eu', 'str', '🪕', 'Lute', 'লিউট', 'pluck', { t60: 1.8, br: .5, cr: 3, pk: [[500, 1, 4]], g: .6 });
  add('eu', 'str', '🎼', 'Hammered Dulcimer', 'হ্যামারড ডালসিমার', 'pluck', { t60: 2.5, br: 1, cr: 6, pk: [[2500, 2, 3]], g: .5 });
  add('eu', 'str', '🪕', 'Mandolin (Italy)', 'ম্যান্ডোলিন', 'pluck', { t60: 1.2, br: .9, cr: 7, g: .5 }, 1);
  add('eu', 'str', '🪉', 'Celtic Harp', 'কেল্টিক হার্প', 'pluck', { t60: 2.5, br: .7, pk: [[1500, 1, 3]], g: .6 });
  add('eu', 'str', '🎻', 'Folk Fiddle', 'ফিডল', 'tone', { w: 'sawtooth', a: .06, s: .8, r: .12, lp: 10, vib: [6, 12, .25], pk: [[600, 2, 4], [3000, 2, 6]], hp: 200, g: .15 }, 1);
  add('eu', 'wind', '🏔️', 'Alphorn (Switzerland)', 'আলপহর্ন', 'tone', { h: H.horn, a: .15, s: .9, r: .4, lp: 3, bend: -.6, bt: .15, g: .3 }, -1);
  add('eu', 'perc', '🛸', 'Hang Drum (Switzerland)', 'হ্যাং ড্রাম', 'mallet', { pt: [[1, 1, 1], [2, .5, .8], [3, .2, .5]], t: 3, a: .006, c: .05, cf: 1, g: .35 });
  add('eu', 'perc', '🔔', 'Church Bell', 'গির্জার ঘণ্টা', 'mallet', { pt: [[.5, .6, 1.4], [1, 1, 1], [1.19, .5, .8], [1.5, .4, .6], [2, .35, .5], [2.5, .2, .4], [3, .15, .3]], t: 4, c: .15, cf: 2, g: .2 }, -1);
  add('eu', 'perc', '🎁', 'Music Box', 'মিউজিক বক্স', 'mallet', { pt: [[1, 1, 1], [4, .2, .3], [7.1, .08, .2]], t: 1.6, c: .1, cf: 5, g: .3 }, 2);
  add('eu', 'key', '🥂', 'Glass Harmonica', 'গ্লাস হারমোনিকা', 'tone', { w: 'sine', a: .3, s: .9, r: .6, vib: [4, 6, .3], g: .35 }, 1);

  /* ---------- play a note ---------- */
  var NOTE = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  var SARGAM = ['সা', '', 'রে', '', 'গা', 'মা', '', 'পা', '', 'ধা', '', 'নি'];
  function noteOn(idx, midi) {
    var inst = I[idx], a = ac(), t = a.currentTime + 0.005, f = 440 * Math.pow(2, (midi - 69) / 12), p = inst.p;
    if (inst.e === 'kit') { var piece = KIT[((midi % KIT.length) + KIT.length) % KIT.length]; return drum(a, 261.63, piece[1], t); }
    if (inst.e === 'tone') return tone(a, f, p, t);
    if (inst.e === 'pluck') return pluck(a, f, p, t, idx);
    if (inst.e === 'mallet') return mallet(a, f, p, t);
    return drum(a, f, p, t);
  }

  /* ---------- UI ---------- */
  var REG = { all: '🌐 সব', bd: '🇧🇩 বাংলাদেশ ও উপমহাদেশ', or: '🎻 অর্কেস্ট্রা', mo: '🎸 ব্যান্ড ও ইলেকট্রনিক', ea: '🏮 পূর্ব এশিয়া', me: '🕌 মধ্যপ্রাচ্য ও মধ্য এশিয়া', af: '🌍 আফ্রিকা', am: '🌎 আমেরিকা', so: '🌏 দক্ষিণ-পূর্ব এশিয়া ও ওশেনিয়া', eu: '🏰 ইউরোপ' };
  var TY = { all: 'সব ধরন', str: '🎻 তারের যন্ত্র', wind: '🎺 ফুঁ দেওয়া যন্ত্র', key: '🎹 কিবোর্ড', perc: '🥁 তাল ও ড্রাম' };
  var MEL = {
    bd: [0, 2, 4, 7, 9, 12, 9, 7, 4, 2, 0],
    or: [4, 4, 5, 7, 7, 5, 4, 2, 0, 0, 2, 4, 4, 2, 2],
    mo: [0, 3, 5, 7, 10, 7, 5, 3, 0, 12, 10, 7],
    ea: [0, 2, 4, 7, 9, 12, 9, 7, 4, 2, 0],
    me: [0, 1, 4, 5, 7, 8, 10, 12, 10, 8, 7, 5, 4, 1, 0],
    af: [0, 3, 5, 7, 10, 12, 10, 7, 5, 3, 0],
    am: [0, 4, 7, 12, 7, 4, 5, 9, 7, 4, 0],
    so: [0, 1, 3, 7, 8, 12, 8, 7, 3, 1, 0],
    eu: [0, 2, 4, 5, 7, 9, 7, 5, 4, 2, 0]
  };
  var RHY = [0, 0, 7, 0, 12, 0, 7, 5, 0, 0, 7, 0, 12, 7, 5, 0];
  var KIT_RHY = [0, 6, 2, 6, 0, 0, 2, 6, 0, 6, 2, 6, 0, 9, 2, 11];
  // computer keys -> keyboard index (0..24)
  var KEYMAP = { z: 0, s: 1, x: 2, d: 3, c: 4, v: 5, g: 6, b: 7, h: 8, n: 9, j: 10, m: 11, ',': 12,
    q: 12, '2': 13, w: 14, '3': 15, e: 16, r: 17, '5': 18, t: 19, '6': 20, y: 21, '7': 22, u: 23, i: 24 };
  var KEYLBL = {}; Object.keys(KEYMAP).forEach(function (k) { if (k !== ',') KEYLBL[KEYMAP[k]] = k.toUpperCase(); });

  var root = document.getElementById('studio');
  if (!root) return;
  var $ = function (s) { return root.querySelector(s); };
  var grid = $('#instGrid'), kb = $('#kb'), nowEl = $('#studioNow'), infoEl = $('#instInfo'), search = $('#instSearch');
  var cur = 0, oct = 4, region = 'all', type = 'all', held = {}, demoTimers = [], keyEls = [];

  $('#instCount').textContent = I.length;

  function chips(box, map, getter, setter) {
    box.innerHTML = '';
    Object.keys(map).forEach(function (k) {
      var b = document.createElement('button'); b.type = 'button'; b.className = 'chip' + (getter() === k ? ' on' : '');
      b.textContent = map[k]; b.onclick = function () { setter(k); chips(box, map, getter, setter); renderGrid(); };
      box.appendChild(b);
    });
  }
  chips($('#regChips'), REG, function () { return region; }, function (k) { region = k; });
  chips($('#typeChips'), TY, function () { return type; }, function (k) { type = k; });

  function renderGrid() {
    var q = (search.value || '').trim().toLowerCase(), shown = 0;
    grid.innerHTML = '';
    I.forEach(function (inst, i) {
      if (region !== 'all' && inst.r !== region) return;
      if (type !== 'all' && inst.ty !== type) return;
      if (q && (inst.n + ' ' + inst.bn).toLowerCase().indexOf(q) < 0) return;
      var b = document.createElement('button'); b.type = 'button';
      b.className = 'inst' + (i === cur ? ' on' : '');
      b.innerHTML = '<span class="em" aria-hidden="true">' + inst.em + '</span><b></b><small></small>';
      b.querySelector('b').textContent = inst.bn; b.querySelector('small').textContent = inst.n;
      b.onclick = function () { select(i, true); };
      grid.appendChild(b); shown++;
    });
    if (!shown) grid.innerHTML = '<p class="empty">কিছু পাওয়া যায়নি 😅 অন্য নামে খুঁজে দেখো</p>';
  }
  search.addEventListener('input', renderGrid);

  function select(i, preview) {
    stopAll(); cur = i; var inst = I[i];
    grid.querySelectorAll('.inst').forEach(function (el) { el.classList.remove('on'); });
    renderGrid();
    infoEl.innerHTML = '<span class="big" aria-hidden="true">' + inst.em + '</span><div><b></b><small></small></div>';
    infoEl.querySelector('b').textContent = inst.bn + ' — ' + inst.n;
    infoEl.querySelector('small').textContent = REG[inst.r] + ' · ' + TY[inst.ty];
    labelKeys(); setStudioKeys(true);
    if (preview) { var v = noteOn(i, baseMidi() + (inst.e === 'kit' ? 0 : 0)); setTimeout(function () { v.stop(); }, 450); }
    nowEl.textContent = '🎵 বেছে নিয়েছো: ' + inst.em + ' ' + inst.bn + ' — এখন নিচের কি চাপো!';
  }

  function baseMidi() { return 12 * (oct + 1) + I[cur].o * 12; }

  // build keyboard: 25 keys, C to C two octaves up
  var WHITE = [0, 2, 4, 5, 7, 9, 11];
  (function buildKb() {
    var w = 0;
    for (var k = 0; k <= 24; k++) {
      var pc = k % 12, isW = WHITE.indexOf(pc) >= 0, el = document.createElement('div');
      el.className = 'k ' + (isW ? 'w' : 'b');
      if (isW) { el.style.left = (w * 40) + 'px'; w++; } else el.style.left = (w * 40 - 13) + 'px';
      el.dataset.k = k; el.innerHTML = '<span class="nm"></span><span class="hk"></span>';
      kb.appendChild(el); keyEls[k] = el;
    }
    kb.style.width = (w * 40) + 'px';
  })();

  function labelKeys() {
    var inst = I[cur], bm = baseMidi();
    keyEls.forEach(function (el, k) {
      var midi = bm + k, pc = ((midi % 12) + 12) % 12, nm;
      if (inst.e === 'kit') nm = KIT[((midi % KIT.length) + KIT.length) % KIT.length][0];
      else if (inst.r === 'bd' && SARGAM[pc]) nm = SARGAM[pc];
      else nm = el.classList.contains('w') ? NOTE[pc] + (Math.floor(midi / 12) - 1) : '';
      el.querySelector('.nm').textContent = nm;
      el.querySelector('.hk').textContent = KEYLBL[k] || '';
    });
    $('#octLbl').textContent = 'অক্টেভ ' + oct;
  }

  function start(k) {
    if (held[k]) return;
    var midi = baseMidi() + k, inst = I[cur];
    if (midi < 12 || midi > 120) return;
    try { held[k] = noteOn(cur, midi); }
    catch (e) { nowEl.textContent = '⚠️ সাউন্ড চালু করো / ব্রাউজার আপডেট করো'; return; }
    keyEls[k].classList.add('on');
    var label = inst.e === 'kit' ? KIT[((midi % KIT.length) + KIT.length) % KIT.length][0] : NOTE[((midi % 12) + 12) % 12] + (Math.floor(midi / 12) - 1);
    nowEl.textContent = '🎵 বাজতেছে: ' + inst.em + ' ' + inst.bn + ' → ' + label;
  }
  function end(k) {
    var v = held[k]; if (!v) return;
    delete held[k]; v.stop(); keyEls[k].classList.remove('on');
  }
  function stopAll() {
    demoTimers.forEach(clearTimeout); demoTimers = [];
    Object.keys(held).forEach(end);
    keyEls.forEach(function (el) { el.classList.remove('on'); });
  }

  // pointer input (mouse + multi-touch + glissando)
  var down = {};
  kb.addEventListener('pointerdown', function (e) {
    var el = e.target.closest('.k'); if (!el) return;
    e.preventDefault();
    if (el.releasePointerCapture) try { el.releasePointerCapture(e.pointerId); } catch (x) {}
    down[e.pointerId] = +el.dataset.k; start(+el.dataset.k);
  });
  kb.addEventListener('pointerover', function (e) {
    if (!(e.pointerId in down)) return;
    var el = e.target.closest('.k'); if (!el) return;
    var k = +el.dataset.k; if (down[e.pointerId] === k) return;
    end(down[e.pointerId]); down[e.pointerId] = k; start(k);
  });
  function lift(e) { if (e.pointerId in down) { end(down[e.pointerId]); delete down[e.pointerId]; } }
  window.addEventListener('pointerup', lift);
  window.addEventListener('pointercancel', lift);
  kb.addEventListener('contextmenu', function (e) { e.preventDefault(); });

  // computer keyboard
  function setStudioKeys(on) {
    window.TAMIM_STUDIO_KEYS = on;
    var b = $('#kbMode');
    b.textContent = on ? '⌨️ কম্পিউটার কিবোর্ড: স্টুডিও চালু' : '⌨️ কম্পিউটার কিবোর্ড: ড্রাম মেশিন (চাপো স্টুডিওতে আনতে)';
    b.classList.toggle('on', on);
  }
  $('#kbMode').onclick = function () { setStudioKeys(!window.TAMIM_STUDIO_KEYS); };
  root.addEventListener('pointerdown', function () { if (!window.TAMIM_STUDIO_KEYS) setStudioKeys(true); });
  document.querySelectorAll('.drum-pad, [data-drum-zone]').forEach(function (el) {
    el.addEventListener('pointerdown', function () { setStudioKeys(false); });
  });
  function typing(e) { var t = e.target; return t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable); }
  document.addEventListener('keydown', function (e) {
    if (!window.TAMIM_STUDIO_KEYS || typing(e) || e.ctrlKey || e.metaKey || e.altKey) return;
    var key = (e.key || '').toLowerCase();
    if (key === 'arrowleft' || key === 'arrowright') { e.preventDefault(); shiftOct(key === 'arrowright' ? 1 : -1); return; }
    if (!(key in KEYMAP)) return;
    e.preventDefault(); if (e.repeat) return;
    start(KEYMAP[key]);
  });
  document.addEventListener('keyup', function (e) {
    var key = (e.key || '').toLowerCase(); if (!(key in KEYMAP)) return;
    end(KEYMAP[key]);
  });
  window.addEventListener('blur', stopAll);
  document.addEventListener('visibilitychange', function () { if (document.hidden) stopAll(); });

  // controls
  function shiftOct(d) { stopAll(); oct = Math.max(1, Math.min(6, oct + d)); labelKeys(); }
  $('#octDown').onclick = function () { shiftOct(-1); };
  $('#octUp').onclick = function () { shiftOct(1); };
  $('#stStop').onclick = function () { stopAll(); nowEl.textContent = '⏹️ সব থামানো হইছে'; };
  $('#stRandom').onclick = function () { var i; do { i = Math.floor(Math.random() * I.length); } while (i === cur && I.length > 1); region = 'all'; type = 'all'; search.value = ''; chips($('#regChips'), REG, function () { return region; }, function (k) { region = k; }); chips($('#typeChips'), TY, function () { return type; }, function (k) { type = k; }); select(i, true); scrollToCurrent(); };
  $('#stVol').addEventListener('input', function () { vol = this.value / 100; if (master) master.gain.value = vol; });
  $('#stRev').addEventListener('input', function () { rev = this.value / 100; if (wet) wet.gain.value = rev; });
  function scrollToCurrent() { var el = grid.querySelector('.inst.on'); if (el && grid.scrollTo) grid.scrollTop = el.offsetTop - grid.offsetTop - 10; }

  $('#stDemo').onclick = function () {
    stopAll(); ac();
    var inst = I[cur], perc = inst.ty === 'perc' && inst.e !== 'mallet';
    var seq = inst.e === 'kit' ? KIT_RHY : perc ? RHY : MEL[inst.r], step = perc || inst.e === 'kit' ? 180 : 380;
    var kitBase = 0;
    if (inst.e === 'kit') { // find key offsets whose kit piece matches the rhythm pieces
      var bm = baseMidi(); kitBase = ((-bm % KIT.length) + KIT.length) % KIT.length;
    }
    nowEl.textContent = '▶️ ডেমো: ' + inst.em + ' ' + inst.bn + ' বাজতেছে...';
    seq.forEach(function (n, j) {
      var k = inst.e === 'kit' ? Math.min(24, kitBase + n) : n;
      demoTimers.push(setTimeout(function () { start(k); }, j * step));
      demoTimers.push(setTimeout(function () { end(k); }, j * step + step * 0.85));
    });
    demoTimers.push(setTimeout(function () { nowEl.textContent = '✅ ডেমো শেষ — এবার তুমি বাজাও!'; }, seq.length * step + 200));
  };

  // iOS / Safari: unlock audio on the first real tap
  function unlock() {
    try { var a = ac(), b = a.createBuffer(1, 1, 22050), s = a.createBufferSource(); s.buffer = b; s.connect(a.destination); s.start(0); } catch (e) {}
    document.removeEventListener('touchend', unlock); document.removeEventListener('click', unlock);
  }
  document.addEventListener('touchend', unlock); document.addEventListener('click', unlock);

  renderGrid(); select(0, false); setStudioKeys(false);
  nowEl.textContent = '🌍 ' + I.length + 'টা বাদ্যযন্ত্র রেডি — একটা বেছে নিয়ে বাজাও!';

  window.TAMIM_STUDIO = { instruments: I, noteOn: noteOn };
})();
