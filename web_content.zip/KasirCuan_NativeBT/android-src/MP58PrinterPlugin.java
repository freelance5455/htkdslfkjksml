package com.kqmparfum.kasircuan;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Build;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.PermissionCallback;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

@CapacitorPlugin(
    name = "MP58Printer",
    permissions = {
        @Permission(alias = "bluetoothConnect", strings = { Manifest.permission.BLUETOOTH_CONNECT })
    }
)
public class MP58PrinterPlugin extends Plugin {
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private boolean hasConnectPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S || getPermissionState("bluetoothConnect") == com.getcapacitor.PermissionState.GRANTED;
    }

    @PluginMethod
    public void listPairedDevices(PluginCall call) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !hasConnectPermission()) {
            requestPermissionForAlias("bluetoothConnect", call, "listPermissionCallback");
            return;
        }
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null) { call.reject("HP ini tidak memiliki Bluetooth."); return; }
            if (!adapter.isEnabled()) { call.reject("Aktifkan Bluetooth HP terlebih dahulu."); return; }
            JSArray arr = new JSArray();
            Set<BluetoothDevice> devices = adapter.getBondedDevices();
            for (BluetoothDevice d : devices) {
                JSObject item = new JSObject();
                item.put("name", d.getName() == null ? "Printer Bluetooth" : d.getName());
                item.put("address", d.getAddress());
                arr.put(item);
            }
            JSObject result = new JSObject(); result.put("devices", arr); call.resolve(result);
        } catch (SecurityException e) { call.reject("Izin Bluetooth ditolak. Izinkan akses perangkat Bluetooth.", e); }
          catch (Exception e) { call.reject("Gagal membaca perangkat Bluetooth: " + e.getMessage(), e); }
    }

    @PermissionCallback
    private void listPermissionCallback(PluginCall call) {
        if (hasConnectPermission()) listPairedDevices(call);
        else call.reject("Izin Bluetooth tidak diberikan.");
    }

    @PluginMethod
    public void printText(PluginCall call) {
        String address = call.getString("address");
        String text = call.getString("text", "");
        if (address == null || address.trim().isEmpty()) { call.reject("Alamat printer tidak ada."); return; }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !hasConnectPermission()) {
            requestPermissionForAlias("bluetoothConnect", call, "printPermissionCallback");
            return;
        }
        doPrint(call, address, text);
    }

    @PermissionCallback
    private void printPermissionCallback(PluginCall call) {
        if (!hasConnectPermission()) { call.reject("Izin Bluetooth tidak diberikan."); return; }
        String address = call.getString("address");
        String text = call.getString("text", "");
        if (address == null) { call.reject("Alamat printer tidak ada."); return; }
        doPrint(call, address, text);
    }

    private void doPrint(PluginCall call, String address, String text) {
        new Thread(() -> {
            BluetoothSocket socket = null;
            try {
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null || !adapter.isEnabled()) throw new Exception("Aktifkan Bluetooth HP terlebih dahulu.");
                BluetoothDevice device = adapter.getRemoteDevice(address);
                try { adapter.cancelDiscovery(); } catch (Exception ignored) {}
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                socket.connect();
                OutputStream out = socket.getOutputStream();
                out.write(new byte[] { 0x1B, 0x40 }); // ESC/POS initialize
                out.write(new byte[] { 0x1B, 0x61, 0x00 }); // align left
                // Most 58mm thermal printers use a legacy code page. Keep common Indonesian text readable.
                String printable = text.replace("✨", "").replace("🧾", "").replace("📱", "")
                    .replace("—", "-").replace("–", "-").replace("•", "-")
                    .replace("’", "'").replace("“", "\"").replace("”", "\"");
                byte[] payload = printable.getBytes(Charset.forName("CP437"));
                out.write(payload);
                out.write(new byte[] { 0x0A, 0x0A, 0x0A });
                out.flush();
                JSObject result = new JSObject(); result.put("success", true); result.put("device", device.getName());
                call.resolve(result);
            } catch (Exception e) {
                call.reject("Gagal mencetak ke MP-58: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()), e);
            } finally {
                if (socket != null) try { socket.close(); } catch (Exception ignored) {}
            }
        }).start();
    }
}
