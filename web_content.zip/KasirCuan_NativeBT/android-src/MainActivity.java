package com.kqmparfum.kasircuan;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(MP58PrinterPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
