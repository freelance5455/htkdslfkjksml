from pathlib import Path
import re, shutil
root = Path(__file__).resolve().parents[1]
android = root / 'android'
manifest = android / 'app/src/main/AndroidManifest.xml'
main = android / 'app/src/main/java/com/kqmparfum/kasircuan/MainActivity.java'
plugin = android / 'app/src/main/java/com/kqmparfum/kasircuan/MP58PrinterPlugin.java'
plugin.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(root / 'android-src/MP58PrinterPlugin.java', plugin)
shutil.copy2(root / 'android-src/MainActivity.java', main)
s = manifest.read_text()
perms = '''\n    <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />\n    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />\n    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />\n'''
if 'android.permission.BLUETOOTH_CONNECT' not in s:
    s = re.sub(r'(<manifest\b[^>]*>)', r'\1' + perms, s, count=1)
manifest.write_text(s)
print('Native MP-58 plugin and Bluetooth permissions added.')
