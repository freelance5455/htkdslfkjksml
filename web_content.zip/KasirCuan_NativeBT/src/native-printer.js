import { registerPlugin } from '@capacitor/core';
window.MP58Printer = registerPlugin('MP58Printer');
