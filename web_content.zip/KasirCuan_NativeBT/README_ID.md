# Kasir Cuan — sumber APK dengan Bluetooth Classic/SPP

Paket ini berisi HTML Kasir Cuan PrintFix dan sumber plugin Android native untuk mencoba cetak teks struk melalui Bluetooth Classic/SPP (ESC/POS) pada printer thermal seperti MP-58 ECO.

## Yang sudah disiapkan
- `www/index.html`: HTML Kasir Cuan yang jadi basis aplikasi.
- `src/native-printer.js`: JavaScript proxy yang dibundle saat build.
- `android-src/MP58PrinterPlugin.java`: plugin native untuk membaca daftar perangkat yang sudah dipasangkan dan mengirim teks melalui Bluetooth SPP.
- `android-src/MainActivity.java`: mendaftarkan plugin native.
- `scripts/patch_android.py`: menyalin plugin dan menambahkan izin Android.
- `.github/workflows/build-apk.yml`: alur build APK di cloud melalui GitHub Actions.

## Penting — status integrasi
Ini adalah **sumber proyek**, bukan APK siap pasang. Belum bisa dianggap berhasil sebelum build dan tes fisik. Printer harus dipasangkan terlebih dahulu dari Pengaturan Bluetooth Android. Plugin mengirim teks ESC/POS sederhana, bukan merender semua grafis/font dari template; hasil cetak native pertama adalah versi teks. Charset/ukuran kolom bisa perlu disetel sesuai firmware MP-58 ECO.

## Build cloud
1. Buat repository GitHub baru dan unggah isi ZIP ini ke branch `main`.
2. Buka tab Actions lalu pilih workflow `Build Kasir Cuan APK` dan jalankan `Run workflow`.
3. Jika build sukses, unduh artifact `Kasir-Cuan-APK`; di dalamnya ada `app-debug.apk`.
4. Pasang APK di HP Android. Pasangkan printer melalui Settings > Bluetooth terlebih dahulu.
5. Buka struk lalu tekan `Cetak Bluetooth`. Pilih printer yang sudah dipasangkan saat diminta.

## Batasan
- Build ini memakai Capacitor 6.2.1.
- Dukungan Bluetooth Classic bergantung pada perangkat, izin Android, dan apakah printer menerima RFCOMM SPP UUID standar `00001101-0000-1000-8000-00805F9B34FB`.
- Plugin ini belum dites pada perangkat MP-58 ECO fisik.
- Jangan pakai untuk transaksi produksi sebelum dites. Simpan file HTML asli dan ekspor/cadangkan data kasir sebelum pindah ke APK.
