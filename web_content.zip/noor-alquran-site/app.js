const API="https://api.alquran.cloud/v1";
const $=s=>document.querySelector(s);
let surahs=[],currentSurah=1,fontSize=29,reader="ar.alafasy",audioQueue=[];
const audio=$("#audio");
const reciterNames={"ar.alafasy":"مشاري راشد العفاسي","ar.abdulbasit":"عبد الباسط عبد الصمد","ar.husary":"محمود خليل الحصري","ar.minshawi":"محمد صديق المنشاوي"};
document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".tab,.panel").forEach(x=>x.classList.remove("active"));btn.classList.add("active");$("#"+btn.dataset.tab).classList.add("active")}));
async function loadSurahs(){try{const r=await fetch(`${API}/surah`);const j=await r.json();if(j.code!==200)throw Error();surahs=j.data;$("#surahSelect").innerHTML=surahs.map(s=>`<option value="${s.number}">${s.number}. ${s.name}</option>`).join("");$("#surahSelect").value=currentSurah;loadSurah(1)}catch(e){$("#surahTitle").textContent="تعذر تحميل السور";$("#ayahs").textContent="تحقق من اتصال الإنترنت ثم أعد تحميل الصفحة."}}
async function loadSurah(n){currentSurah=Math.max(1,Math.min(114,n));$("#surahSelect").value=currentSurah;$("#ayahs").textContent="جاري تحميل آيات السورة الشريفة...";const meta=surahs[currentSurah-1];$("#surahTitle").textContent=meta?meta.name:"";$("#surahMeta").textContent=meta?`${meta.revelationType==="Meccan"?"مكية":"مدنية"} · ${meta.numberOfAyahs} آية · اضغط على أي آية للاستماع منها`:"";
try{const r=await fetch(`${API}/surah/${currentSurah}`);const j=await r.json();const ayahs=j.data.ayahs;$("#ayahs").innerHTML=ayahs.map(a=>`<span class="ayah-segment" data-ayah="${a.numberInSurah}" title="استماع من الآية ${a.numberInSurah}">${a.text}</span><span class="ayah-badge">${toArabic(a.numberInSurah)}</span>`).join(" ");document.querySelectorAll(".ayah-segment").forEach(el=>el.addEventListener("click",()=>playFromAyah(Number(el.dataset.ayah))))}catch(e){$("#ayahs").textContent="تعذر تحميل الآيات. يرجى المحاولة مرة أخرى."}}
function toArabic(n){return String(n).replace(/\d/g,d=>"٠١٢٣٤٥٦٧٨٩"[d])}
function playFromAyah(n){const url=`https://cdn.islamic.network/quran/audio-surah/128/${reader}/${currentSurah}.mp3`;playAudio(url,`${reciterNames[reader]||"القارئ"} — ${surahs[currentSurah-1]?.name||""}`);document.querySelectorAll(".ayah-segment").forEach(x=>x.classList.toggle("active",Number(x.dataset.ayah)===n));}
function playAudio(url,title){audio.src=url;audio.play().catch(()=>{});$("#audioTitle").textContent=reciterNames[reader]||"القارئ";$("#audioSubtitle").textContent=title}
$("#surahSelect").addEventListener("change",e=>loadSurah(Number(e.target.value)));
$("#readerSelect").addEventListener("change",e=>{reader=e.target.value;$("#audioTitle").textContent=reciterNames[reader]});
$("#prevSurah").addEventListener("click",()=>loadSurah(currentSurah-1));
$("#nextSurah").addEventListener("click",()=>loadSurah(currentSurah+1));
$("#fontUp").addEventListener("click",()=>{fontSize=Math.min(44,fontSize+2);$("#ayahs").style.fontSize=fontSize+"px"});
$("#fontDown").addEventListener("click",()=>{fontSize=Math.max(20,fontSize-2);$("#ayahs").style.fontSize=fontSize+"px"});
document.querySelectorAll(".reciter-card").forEach(card=>card.addEventListener("click",()=>{reader=card.dataset.reader;$("#readerSelect").value=reader;$("#audioTitle").textContent=reciterNames[reader];document.querySelector('[data-tab="quran"]').click();playFromAyah(1)}));
$("#reciterSearch").addEventListener("input",e=>{const q=e.target.value.trim();document.querySelectorAll(".reciter-card").forEach(c=>c.hidden=!c.textContent.includes(q))});
loadSurahs();