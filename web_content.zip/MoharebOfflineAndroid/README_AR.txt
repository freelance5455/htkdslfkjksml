محارب الابتزاز - مشروع أندرويد محلي

هذا المشروع يضم صفحة index.html داخل WebView ويضيف معالج اختيار ملفات أندرويد (onShowFileChooser).
يستخدم منتقي الملفات النظامي (Storage Access Framework)، لذلك لا يحتاج إلى إذن عام للوصول إلى كل ملفات الهاتف.
لا توجد صلاحية INTERNET في AndroidManifest.

البناء:
1) افتح المجلد MoharebOfflineAndroid في Android Studio حديث.
2) انتظر مزامنة Gradle وتنزيل أدوات البناء المطلوبة.
3) اختر Build > Build APK(s).
4) يوجد APK الناتج عادة في app/build/outputs/apk/debug/app-debug.apk.

ملاحظة: هذا مشروع المصدر، وليس ملف APK جاهزًا. لم يتم تجميعه أو اختباره على جهاز أندرويد في هذه البيئة لعدم توفر Android SDK/Gradle هنا.
