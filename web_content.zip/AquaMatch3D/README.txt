AQUA MATCH 3D - Android project (WebView + AdMob)

1. Open this folder in Android Studio (File > Open). Let Gradle sync (it downloads Gradle 8.9 automatically).
2. Run on a device/emulator. Test ads show by default (Google test IDs).
3. Before publishing, replace the TODO values:
   - app/src/main/AndroidManifest.xml  -> your AdMob App ID (ca-app-pub-...~...)
   - app/src/main/java/com/yourcompany/aquamatch/MainActivity.kt -> AdIds.REWARDED / AdIds.INTERSTITIAL
   - Package name "com.yourcompany.aquamatch" in build.gradle.kts, MainActivity.kt and its folder path
4. Upload app-ads.txt to the root of the website on your Play Store listing (https://yourdomain.com/app-ads.txt).
5. Game source: app/src/main/assets/index.html (same as aqua-match-3d.html, playable in any browser).
Ads: only optional rewarded ads are used (player taps a button to watch). Interstitials are disabled.
Never tap your own live ads.
