AQUA MATCH 3D - Android project (WebView + AdMob)

1. Open this folder in Android Studio (File > Open). Let Gradle sync (it downloads Gradle 8.9 automatically).
2. Run on a device/emulator. Your real AdMob IDs are already set (App ID in the manifest, Rewarded unit in MainActivity.kt). These are LIVE ads: do not tap them yourself; add your phone as a test device in AdMob first.
3. Before publishing, set your real package name (must match AdMob and Galaxy Store):
   - Package name "com.yourcompany.aquamatch" in build.gradle.kts, MainActivity.kt and its folder path
4. Upload app-ads.txt to the root of the website on your Play Store listing (https://yourdomain.com/app-ads.txt).
5. Game source: app/src/main/assets/index.html (same as aqua-match-3d.html, playable in any browser).
Ads: only optional rewarded ads are used (player taps a button to watch). Interstitials are disabled.
Never tap your own live ads.
