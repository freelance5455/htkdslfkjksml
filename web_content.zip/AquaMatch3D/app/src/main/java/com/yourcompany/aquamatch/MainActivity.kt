package com.yourcompany.aquamatch

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.ads.*
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

/**
 * AD UNIT IDs
 * These are Google's official TEST ids, safe to click while developing.
 * Before publishing, create two ad units in AdMob (Rewarded + Interstitial) and paste YOUR ids here,
 * and put YOUR AdMob App ID (ca-app-pub-...~...) in AndroidManifest.xml.
 * Never click your own live ads: that can get the account suspended.
 */
object AdIds {
    const val REWARDED = "ca-app-pub-3940256099942544/5224354917"      // TODO: replace with your rewarded unit id
    const val ENABLE_INTERSTITIAL = false   // OFF: only optional rewarded ads are shown
    const val INTERSTITIAL = "ca-app-pub-3940256099942544/1033173712"  // TODO: replace with your interstitial unit id
}

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var rewarded: RewardedAd? = null
    private var interstitial: InterstitialAd? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this).apply {
            setBackgroundColor(0xFF08113A.toInt())
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true            // game saves level/pearls in localStorage
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = WebViewClient()
            addJavascriptInterface(Bridge(), "Android")  // -> window.Android in the game
        }
        window.decorView.setBackgroundColor(0xFF08113A.toInt())
        setContentView(web)

        // Keep the game clear of status/navigation bars and camera cutouts (Android 15 forces edge-to-edge)
        ViewCompat.setOnApplyWindowInsetsListener(web) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        web.loadUrl("file:///android_asset/index.html")

        MobileAds.initialize(this) {
            loadRewarded()
            if (AdIds.ENABLE_INTERSTITIAL) loadInterstitial()
        }
    }

    // ---------- JS bridge: called from the game as window.Android.xxx() ----------
    inner class Bridge {
        @JavascriptInterface
        fun showRewardedAd() = runOnUiThread { showRewarded() }

        @JavascriptInterface
        fun showInterstitialAd() = runOnUiThread { showInterstitial() }
    }

    private fun js(code: String) = web.evaluateJavascript(code, null)

    // ---------- Rewarded ----------
    private fun loadRewarded() {
        RewardedAd.load(this, AdIds.REWARDED, AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) { rewarded = ad }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewarded = null
                    web.postDelayed({ loadRewarded() }, 30_000) // retry in 30s
                }
            })
    }

    private fun showRewarded() {
        val ad = rewarded
        if (ad == null) {
            Toast.makeText(this, "Ad not ready yet, try again in a moment", Toast.LENGTH_SHORT).show()
            loadRewarded()
            js("onRewardedAdResult(false)")
            return
        }
        var earned = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewarded = null
                loadRewarded()
                js("onRewardedAdResult($earned)")        // true only if the player earned the reward
            }
            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                rewarded = null
                loadRewarded()
                js("onRewardedAdResult(false)")
            }
        }
        ad.show(this) { earned = true }
    }

    // ---------- Interstitial ----------
    private fun loadInterstitial() {
        InterstitialAd.load(this, AdIds.INTERSTITIAL, AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) { interstitial = ad }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitial = null
                    web.postDelayed({ loadInterstitial() }, 30_000)
                }
            })
    }

    private fun showInterstitial() {
        if (!AdIds.ENABLE_INTERSTITIAL) return
        val ad = interstitial ?: run { loadInterstitial(); return }  // not ready: skip silently
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { interstitial = null; loadInterstitial() }
            override fun onAdFailedToShowFullScreenContent(error: AdError) { interstitial = null; loadInterstitial() }
        }
        ad.show(this)
    }

    override fun onPause() { web.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
