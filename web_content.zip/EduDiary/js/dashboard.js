
function dashboardHTML(){
return `
<div class="page-head"><div><h1>🏠 Общо табло</h1><p>Добре дошли в електронния дневник.</p></div><div class="actions"><button class="btn primary" onclick="openAdd('Бързо действие')">➕ Добави</button><button class="btn" onclick="window.print()">🖨️ Печат</button></div></div>
<div class="stats">
<div class="stat"><div class="stat-icon">👨‍🎓</div><div class="stat-value">126</div><div class="stat-label">Ученици</div></div>
<div class="stat"><div class="stat-icon">📚</div><div class="stat-value">6</div><div class="stat-label">Днешни часове</div></div>
<div class="stat"><div class="stat-icon">📝</div><div class="stat-value">42</div><div class="stat-label">Последни оценки</div></div>
<div class="stat"><div class="stat-icon">🚫</div><div class="stat-value">18</div><div class="stat-label">Отсъствия</div></div>
</div>
<div class="grid">
<div class="card"><div class="card-head"><h3>📅 Днешни часове</h3><button class="btn" onclick="openModule('schedule')">Разписание</button></div><div class="card-body">
<div class="lesson"><div class="lesson-time">08:00</div><div class="lesson-info"><b>Математика</b><small>8А • Кабинет 201</small></div><span class="badge ok">Проведен</span></div>
<div class="lesson"><div class="lesson-time">09:00</div><div class="lesson-info"><b>Информатика</b><small>10Б • Компютърен кабинет</small></div><span class="badge info">Предстоящ</span></div>
<div class="lesson"><div class="lesson-time">10:00</div><div class="lesson-info"><b>Математика</b><small>9А • Кабинет 201</small></div><span class="badge info">Предстоящ</span></div>
<div class="lesson"><div class="lesson-time">11:00</div><div class="lesson-info"><b>Консултация</b><small>Кабинет 201</small></div><span class="badge muted">Свободен</span></div>
</div></div>
<div class="card"><div class="card-head"><h3>🔔 Известия</h3><span class="badge bad">5</span></div><div class="card-body">
<div class="notice warning">⚠️ 8Б има 5 нови отсъствия.</div><div class="notice info">📋 Контролно по математика утре.</div><div class="notice success">🏆 Ново постижение на ученик.</div><div class="notice danger">🚫 Непотвърдено отсъствие.</div>
</div></div>
</div>
<div class="card"><div class="card-head"><h3>📝 Последни оценки</h3><button class="btn" onclick="openModule('grades')">Всички</button></div><div class="table-wrap"><table><thead><tr><th>Ученик</th><th>Клас</th><th>Предмет</th><th>Оценка</th><th>Дата</th></tr></thead><tbody>
<tr><td>Александър Иванов</td><td>8А</td><td>Математика</td><td><span class="badge ok">6</span></td><td>28.09.2026</td></tr>
<tr><td>Мария Георгиева</td><td>8А</td><td>Математика</td><td><span class="badge info">5</span></td><td>28.09.2026</td></tr>
<tr><td>Николай Димитров</td><td>9Б</td><td>Информатика</td><td><span class="badge warn">4</span></td><td>27.09.2026</td></tr>
</tbody></table></div></div>`;
}
