
const names=["Александър Иванов","Мария Георгиева","Николай Димитров","Елена Петрова","Георги Стоянов","Анна Николова"];
const subjects=["Математика","Информатика","Изобразително изкуство","Графичен дизайн","История","Английски език"];

function buildMenu(){
 const menu=document.getElementById("menu"); let html="";
 modules.forEach((m,i)=>{
   if(i===0) html+='<div class="menu-title">Основно</div>';
   if(i===15) html+='<div class="menu-title">Учебен процес</div>';
   if(i===27) html+='<div class="menu-title">Администрация</div>';
   if(i===43) html+='<div class="menu-title">Система</div>';
   html+=`<button class="menu-item" data-id="${m[0]}" onclick="openModule('${m[0]}')"><span class="mi">${m[1]}</span>${m[2]}</button>`;
 });
 menu.innerHTML=html;
}
function openModule(id){
 document.querySelectorAll(".menu-item").forEach(b=>b.classList.toggle("active",b.dataset.id===id));
 document.getElementById("content").innerHTML=id==="dashboard"?dashboardHTML():moduleHTML(modules.find(m=>m[0]===id));
 window.scrollTo(0,0);
}
function moduleHTML(m){
 const rows=names.map((n,i)=>`<tr><td><input type="checkbox"></td><td>${i+1}</td><td><b>${n}</b><br><small>${m[2]}</small></td><td>${["8А","8Б","9А","9Б","10А","10Б"][i]}</td><td>${subjects[i]}</td><td><span class="badge ${i%3===0?"ok":i%3===1?"info":"warn"}">${i%3===0?"Активен":i%3===1?"Предстоящ":"За проверка"}</span></td><td>${28-i}.09.2026</td><td><button class="btn" onclick="viewItem('${n}')">👁️</button> <button class="btn" onclick="editItem('${n}')">✏️</button> <button class="btn" onclick="deleteItem('${n}')">🗑️</button></td></tr>`).join("");
 return `<div class="page-head"><div><h1>${m[1]} ${m[2]}</h1><p>Управление на модул „${m[2]}“.</p></div><div class="actions"><button class="btn primary" onclick="openAdd('${m[2]}')">➕ Добави</button><button class="btn" onclick="window.print()">🖨️ Печат</button><button class="btn" onclick="toast('Експортът е стартиран')">📥 Експорт</button></div></div>
 <div class="toolbar"><div class="filters"><input id="tableSearch" class="control" placeholder="🔍 Търси..." oninput="filterTable(this.value)"><select class="control"><option>Всички</option><option>Активни</option><option>Архив</option></select><select class="control"><option>Всички класове</option><option>8А</option><option>8Б</option><option>9А</option><option>10Б</option></select></div><div class="actions"><button class="btn" onclick="toast('Филтрите са приложени')">🔽 Филтрирай</button><button class="btn" onclick="toast('Сортиране')">↕️ Сортирай</button><button class="btn" onclick="toast('Данните са запазени')">💾 Запази</button></div></div>
 <div class="module-card"><div class="table-wrap"><table id="dataTable"><thead><tr><th>✓</th><th>№</th><th>Основна информация</th><th>Клас</th><th>Предмет</th><th>Статус</th><th>Дата</th><th>Действия</th></tr></thead><tbody>${rows}</tbody></table></div></div>`;
}
function filterTable(v){document.querySelectorAll("#dataTable tbody tr").forEach(r=>r.style.display=r.innerText.toLowerCase().includes(v.toLowerCase())?"":"none")}
function openAdd(title){document.getElementById("modalTitle").textContent="➕ "+title;document.getElementById("modalBody").innerHTML=`<div class="form-grid"><div class="form-group"><label>Име / Заглавие</label><input placeholder="Въведете данни"></div><div class="form-group"><label>Клас</label><select><option>8А</option><option>8Б</option><option>9А</option><option>9Б</option><option>10А</option><option>10Б</option></select></div><div class="form-group"><label>Предмет</label><input placeholder="Предмет"></div><div class="form-group"><label>Дата</label><input type="date"></div><div class="form-group"><label>Статус</label><select><option>Активен</option><option>Предстоящ</option><option>Завършен</option><option>Архив</option></select></div><div class="form-group"><label>Файл</label><input type="file"></div><div class="form-group full"><label>Бележки</label><textarea rows="5"></textarea></div></div>`;document.getElementById("modal").classList.add("show")}
function viewItem(name){document.getElementById("modalTitle").textContent="👁️ Преглед";document.getElementById("modalBody").innerHTML=`<h3>${name}</h3><p><b>Клас:</b> 8А</p><p><b>Предмет:</b> Математика</p><p><b>Статус:</b> <span class="badge ok">Активен</span></p><p>Това е демонстрационен преглед на записа.</p>`;document.getElementById("modal").classList.add("show")}
function editItem(name){openAdd("Редактиране — "+name)}
function deleteItem(name){if(confirm("Изтриване на "+name+"?"))toast("Записът е изтрит.")}
function saveModal(){closeModal();toast("Данните са запазени успешно ✓")}
function closeModal(){document.getElementById("modal").classList.remove("show")}
function toggleDark(){document.body.classList.toggle("dark");localStorage.setItem("dark",document.body.classList.contains("dark"))}
function toggleSidebar(){document.getElementById("sidebar").classList.toggle("open")}
function showNotifications(){toast("Имате 5 нови известия")}
function toast(msg){const d=document.createElement("div");d.className="toast";d.textContent=msg;document.getElementById("toastContainer").appendChild(d);setTimeout(()=>d.remove(),3000)}
function globalSearch(v){if(!v.trim())return;const m=modules.find(x=>x[2].toLowerCase().includes(v.toLowerCase()));if(m)openModule(m[0])}
buildMenu();
if(localStorage.getItem("dark")==="true")document.body.classList.add("dark");
openModule("dashboard");
