# As Ilhas de Auralis — edição expandida (v2)

Esta edição mantém os seis níveis originais e amplia a campanha até 200 níveis.

## O que foi ajustado / implementado

### Tela e controles
- Orientação horizontal forçada (canvas 896×512, aspect 7/4).
- Aviso de rotação em celular na vertical.
- Controles de teclado + botões touch.

### Campanha de 200 fases
- Fases 1–6: autorais (Campos de Vento, Ponte Que Canta, Caverna, Ruínas, Guardião de Turbina, Farol).
- Fases 7–200: geradas com famílias de cenário (10 temas) que mudam a cada 20 níveis.
- Fases longas e densas: muitos inimigos, plataformas, hazards, canhões, pedras rolantes, fragmentos e poderes temporários.
- Chefes nos níveis 50, 100, 150 e 200 (Sentinela de Musgo → Aranha de Obsidiana → Cavaleiro das Marés → Rainha das Cinzas), com vida escalada pela progressão e pelo modificador de dificuldade.

### Baú-Sacrifício (a cada 25 fases)
- Ao completar fase 25, 50, 75, 100… aparece o Baú-Sacrifício.
- Custa moedas (fragmentos coletados viram moedas).
- Escolha ÚNICA e permanente entre 3 poderes:
  - Asas de Vento (pulo duplo permanente) → dificuldade +10%
  - Escudo de Luz (1 bloqueio por fase) → dificuldade +25%
  - Botas de Éter (velocidade permanente) → dificuldade +40%
- A escolha altera a dificuldade dos chefes e o ritmo do jogo (variedade real).

### Espada
- Começa em madeira.
- Nível 1 (tutorial): falar com Mara entrega a Espada de Bronze.
- Upgrades em marcos: Ferro (fase 10/25), Ouro (40/50), Diamante (80/75).
- Código secreto AUR-7K9-ESPADA (revelado por NPC no nível 42) desbloqueia a Herdeira (lâmina máxima).

### Progressão e save
- Save local (fase, moedas, espada, poderes permanentes, segredo).
- Menu inicial com Continuar.
- Final só no nível 200 (“A Última Aurora”).

### História
- Marcos narrativos a cada 20 níveis.
- Final da jornada reservado ao 200; o antigo nível 6 (Farol) não encerra mais a campanha.

### Observações
- Níveis procedurais são controlados (sempre há caminho, densidade de inimigos e colecionáveis).
- Teste recomendado em Chrome/Edge/Firefox. Servidor local é preferível para áudio/save.
- Código secreto também pode ser digitado a qualquer momento durante o jogo.
