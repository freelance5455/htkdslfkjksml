BAKING HUB BY ZAINAB — FIREBASE CONNECTED PACKAGE

Files:
- index.html: cake customizer with Firebase Google redirect sign-in and notification registration UI.
- firebase-messaging-sw.js: required service worker for background push notifications.

IMPORTANT SETUP BEFORE TESTING
1. Upload BOTH files to the ROOT of an HTTPS website. Do not open index.html directly as file://.
2. Firebase Console > Authentication > Settings > Authorized domains: add your website hostname (for example, your-site.web.app or your custom domain). Do not include https:// or a path.
3. Google provider must remain Enabled in Authentication > Sign-in method.
4. Cloud Messaging > Web Push certificates: the public VAPID key is already added to index.html.
5. Test on a supported browser (Chrome on Android is a good choice). Open the hosted HTTPS URL, sign in with Google, then tap Enable notifications and allow permission.
6. For a test notification, use Firebase Console > Messaging / Notifications composer and its test-message flow with the FCM registration token shown by the website. Actual ongoing/order notifications need a trusted server or Cloud Functions to send messages; do not put service-account credentials in this website.

LIMITATIONS
- Facebook sign-in is not configured; its button explains this.
- This package registers the browser/device with FCM and supports background notification display. It does not include a bakery admin backend, order database, or automatic order-status notification sender.
- Google sign-in will not work from file://. HTTPS hosting and the authorized domain are required.
- The FCM token identifies this browser installation; keep it private and do not post it publicly.
- Price shown in the cake builder is an estimate; bakery confirms final price.

The Firebase web config and VAPID public key are client-side public configuration values. Never add a Firebase service-account private key or admin SDK secret to these files.
