/* Firebase Cloud Messaging background service worker.
   Required at the website root and served over HTTPS. */
importScripts('https://www.gstatic.com/firebasejs/13.1.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/13.1.0/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: 'AIzaSyDN2rzU5sSI8IWrEkZoAZZna1s080LvbbA',
  authDomain: 'my-first-app-1b46e.firebaseapp.com',
  projectId: 'my-first-app-1b46e',
  storageBucket: 'my-first-app-1b46e.firebasestorage.app',
  messagingSenderId: '995879304206',
  appId: '1:995879304206:web:20f7650e919c4c31b6d05f',
  measurementId: 'G-LLWSHJKZVN'
});

const messaging = firebase.messaging();
messaging.onBackgroundMessage(payload => {
  const title = payload.notification?.title || 'Baking Hub By Zainab';
  const options = {
    body: payload.notification?.body || 'You have a new update.',
    icon: './icon-192.png',
    data: payload.data || {}
  };
  self.registration.showNotification(title, options);
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil(clients.openWindow('./'));
});
