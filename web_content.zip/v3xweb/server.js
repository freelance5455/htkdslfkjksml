// server.js | v3xCloud EVS Gen | Node.js Express
const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const licenseRoutes = require('./routes/license');
const genRoutes     = require('./routes/gen');
const authRoutes    = require('./routes/auth');

const app  = express();
const PORT = process.env.PORT || 3000;

// Data dir
if (!fs.existsSync('./data')) fs.mkdirSync('./data');

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: 'v3xcloud_secret_893',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 24 * 60 * 60 * 1000 }
}));

// Routes
app.use('/api/auth',    authRoutes);
app.use('/api/license', licenseRoutes);
app.use('/api/gen',     genRoutes);

// Serve frontend
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`v3xCloud EVS Gen running on port ${PORT}`);
});
