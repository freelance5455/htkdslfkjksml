// routes/license.js | License Manager
const express = require('express');
const router  = express.Router();
const fs      = require('fs');
const { v4: uuidv4 } = require('uuid');
const crypto  = require('crypto');

const LIC_FILE = './data/licenses.json';
const TOK_FILE = './data/tokens.json';

function loadLicenses() {
  if (!fs.existsSync(LIC_FILE)) return {};
  try { return JSON.parse(fs.readFileSync(LIC_FILE)); } catch { return {}; }
}

function saveLicenses(data) {
  fs.writeFileSync(LIC_FILE, JSON.stringify(data, null, 2));
}

function validateLicense(key, hwid) {
  const lics = loadLicenses();
  if (!lics[key]) return { ok: false, msg: 'Invalid license key.' };
  const entry = lics[key];
  const hwidHash = crypto.createHash('sha256').update(hwid).digest('hex').slice(0, 16);
  if (!entry.usedBy) {
    entry.usedBy = hwidHash;
    entry.usedAt = new Date().toISOString();
    saveLicenses(lics);
    return { ok: true, msg: 'License activated!' };
  }
  if (entry.usedBy === hwidHash) return { ok: true, msg: 'License valid.' };
  return { ok: false, msg: 'License already used on another device.' };
}

function generateLicense(note = '') {
  const key = 'V3X-' + uuidv4().replace(/-/g,'').slice(0,8).toUpperCase() + '-' + uuidv4().replace(/-/g,'').slice(0,4).toUpperCase();
  const lics = loadLicenses();
  lics[key] = { note, created: new Date().toISOString(), usedBy: null, usedAt: null };
  saveLicenses(lics);
  return key;
}

function revokeLicense(key) {
  const lics = loadLicenses();
  if (!lics[key]) return false;
  delete lics[key];
  saveLicenses(lics);
  return true;
}

function listLicenses() {
  const lics = loadLicenses();
  return Object.entries(lics).map(([k, v]) => ({ key: k, ...v }));
}

// middleware: owner only
function ownerOnly(req, res, next) {
  if (!req.session.isOwner) return res.status(403).json({ ok: false, msg: 'Owner only' });
  next();
}

// Routes
router.post('/generate', ownerOnly, (req, res) => {
  const key = generateLicense(req.body.note || '');
  res.json({ ok: true, key });
});

router.get('/list', ownerOnly, (req, res) => {
  res.json({ ok: true, licenses: listLicenses() });
});

router.post('/revoke', ownerOnly, (req, res) => {
  const ok = revokeLicense(req.body.key);
  res.json({ ok, msg: ok ? 'Revoked.' : 'Key not found.' });
});

router.get('/tokens', ownerOnly, (req, res) => {
  let tokens = [];
  if (fs.existsSync(TOK_FILE)) {
    try { tokens = JSON.parse(fs.readFileSync(TOK_FILE)); } catch {}
  }
  res.json({ ok: true, tokens });
});

module.exports = router;
module.exports.validateLicense = validateLicense;
module.exports.getHWID = (ip, ua) => crypto.createHash('sha256').update(ip + ua).digest('hex').slice(0, 16);
