// routes/auth.js | Owner + License Auth
const express = require('express');
const router  = express.Router();
const { validateLicense, getHWID } = require('./license');

const OWNER_ID   = 'v3xcloud';
const OWNER_PASS = 'v3xcloud@890';

// Owner login
router.post('/owner', (req, res) => {
  const { id, pass } = req.body;
  if (id === OWNER_ID && pass === OWNER_PASS) {
    req.session.isOwner = true;
    return res.json({ ok: true });
  }
  res.json({ ok: false, msg: 'Wrong credentials' });
});

// License activation
router.post('/activate', (req, res) => {
  const { key } = req.body;
  const hwid = req.ip + req.headers['user-agent'];
  const result = validateLicense(key, hwid);
  if (result.ok) {
    req.session.licensed = true;
    req.session.hwid = hwid;
  }
  res.json(result);
});

// Check session
router.get('/status', (req, res) => {
  res.json({
    licensed: !!req.session.licensed,
    isOwner:  !!req.session.isOwner
  });
});

router.post('/logout', (req, res) => {
  req.session.destroy();
  res.json({ ok: true });
});

module.exports = router;
