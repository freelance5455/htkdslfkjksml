// routes/gen.js | Generator Engine | v3xCloud EVS Gen
const express = require('express');
const router  = express.Router();
const axios   = require('axios');
const fs      = require('fs');
const crypto  = require('crypto');

const TOK_FILE = './data/tokens.json';

const RANDOM_STATUSES = [
  'vibing with v3xCloud 🔥',
  'v3x or nothing 🚀',
  'built different, v3x edition',
  'certified v3xCloud member 💀',
  'the cloud chose me',
  'on that v3x grind frfr',
  'v3xCloud ran so others could walk',
  'no cap, v3x is goated',
  'eating good with v3xCloud',
  'running on v3x fuel',
];

const V3X_BIO = 'v3xcloud is the goat 🐐 | v3xCloud';
const DISCORD_API = 'https://discord.com/api/v9';

const USER_AGENTS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/123.0.0.0 Safari/537.36',
];

// In-memory captcha waiting room: genId -> { resolve, reject }
const captchaWaiters = {};
// SSE clients: genId -> res
const sseClients = {};

function rand(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function randomUser() {
  const adj  = ['Dark','Neon','Ghost','Cyber','Void','Storm','Blaze','Hyper','Ultra','Apex'];
  const noun = ['Wolf','Fox','Hawk','Void','Cloud','Node','Byte','Core','Flux','Edge'];
  return `${rand(adj)}${rand(noun)}${Math.floor(Math.random()*9000)+1000}`;
}
function randomPass() {
  const c = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$';
  return Array.from({length:14}, () => c[Math.floor(Math.random()*c.length)]).join('');
}
function randomDOB() {
  const y = Math.floor(Math.random()*12)+1990;
  const m = String(Math.floor(Math.random()*12)+1).padStart(2,'0');
  const d = String(Math.floor(Math.random()*27)+1).padStart(2,'0');
  return `${y}-${m}-${d}`;
}

function discordHeaders(token = null) {
  const h = {
    'User-Agent': rand(USER_AGENTS),
    'Content-Type': 'application/json',
    'X-Discord-Locale': 'en-US',
  };
  if (token) h['Authorization'] = token;
  return h;
}

function sendLog(genId, msg) {
  if (sseClients[genId]) {
    sseClients[genId].write(`data: ${JSON.stringify({ type: 'log', msg })}\n\n`);
  }
}

function sendCaptcha(genId, url) {
  if (sseClients[genId]) {
    sseClients[genId].write(`data: ${JSON.stringify({ type: 'captcha', url })}\n\n`);
  }
}

function sendDone(genId, results) {
  if (sseClients[genId]) {
    sseClients[genId].write(`data: ${JSON.stringify({ type: 'done', results })}\n\n`);
    sseClients[genId].end();
    delete sseClients[genId];
  }
}

// Temp mail providers
async function createMail(provider = 'random') {
  const providers = ['mailtm', 'onesecmail', 'guerrilla'];
  const p = provider === 'random' ? rand(providers) : provider;

  if (p === 'mailtm') {
    const domains = await axios.get('https://api.mail.tm/domains').then(r => r.data['hydra:member']);
    const domain  = domains[0].domain;
    const user    = Math.random().toString(36).slice(2, 12);
    const address = `${user}@${domain}`;
    const password = Math.random().toString(36).slice(2, 14);
    await axios.post('https://api.mail.tm/accounts', { address, password });
    const tok = await axios.post('https://api.mail.tm/token', { address, password }).then(r => r.data.token);
    return {
      address,
      waitForMail: async (keyword = 'discord', timeout = 120000) => {
        const deadline = Date.now() + timeout;
        while (Date.now() < deadline) {
          const msgs = await axios.get('https://api.mail.tm/messages', {
            headers: { Authorization: `Bearer ${tok}` }
          }).then(r => r.data['hydra:member']).catch(() => []);
          for (const m of msgs) {
            if (m.subject.toLowerCase().includes(keyword)) {
              return await axios.get(`https://api.mail.tm/messages/${m.id}`, {
                headers: { Authorization: `Bearer ${tok}` }
              }).then(r => r.data);
            }
          }
          await sleep(4000);
        }
        return null;
      }
    };
  }

  if (p === 'onesecmail') {
    const addr = await axios.get('https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1').then(r => r.data[0]);
    const [login, domain] = addr.split('@');
    return {
      address: addr,
      waitForMail: async (keyword = 'discord', timeout = 120000) => {
        const deadline = Date.now() + timeout;
        while (Date.now() < deadline) {
          const msgs = await axios.get(`https://www.1secmail.com/api/v1/?action=getMessages&login=${login}&domain=${domain}`).then(r => r.data).catch(() => []);
          for (const m of msgs) {
            if (m.subject.toLowerCase().includes(keyword)) {
              return await axios.get(`https://www.1secmail.com/api/v1/?action=readMessage&login=${login}&domain=${domain}&id=${m.id}`).then(r => r.data);
            }
          }
          await sleep(4000);
        }
        return null;
      }
    };
  }

  // guerrilla fallback
  const g = await axios.get('https://api.guerrillamail.com/ajax.php?f=get_email_address').then(r => r.data);
  return {
    address: g.email_addr,
    waitForMail: async (keyword = 'discord', timeout = 120000) => {
      const deadline = Date.now() + timeout;
      while (Date.now() < deadline) {
        const msgs = await axios.get(`https://api.guerrillamail.com/ajax.php?f=get_email_list&offset=0&sid_token=${g.sid_token}`).then(r => r.data.list || []).catch(() => []);
        for (const m of msgs) {
          if ((m.mail_subject || '').toLowerCase().includes(keyword)) {
            return await axios.get(`https://api.guerrillamail.com/ajax.php?f=fetch_email&email_id=${m.mail_id}&sid_token=${g.sid_token}`).then(r => r.data);
          }
        }
        await sleep(4000);
      }
      return null;
    }
  };
}

async function genOne(genId, opts) {
  const result = {};

  // Mail
  sendLog(genId, '📧 Creating temp email...');
  let mail;
  try {
    mail = await createMail(opts.mailProvider || 'random');
  } catch(e) {
    return { error: `Mail failed: ${e.message}` };
  }
  result.email = mail.address;
  sendLog(genId, `📧 Email: ${mail.address}`);
  if (opts.humanizer) await sleep(1500 + Math.random() * 2000);

  // Register
  const username = randomUser();
  const password = randomPass();
  result.username = username;
  result.password = password;
  sendLog(genId, `👤 Registering: ${username}`);

  let regData;
  try {
    const regRes = await axios.post(`${DISCORD_API}/auth/register`, {
      email: mail.address, username, password,
      date_of_birth: randomDOB(),
      consent: true,
      gift_code_sku_id: null,
      invite: null,
      promotional_email_opt_in: false,
    }, { headers: discordHeaders() });
    regData = regRes.data;
  } catch(e) {
    regData = e.response?.data || { error: e.message };
  }

  // Captcha?
  if (regData.captcha_key || regData.captcha_sitekey) {
    sendLog(genId, '🤖 Captcha required — waiting for you to solve...');
    const sitekey = regData.captcha_sitekey || '';
    const captchaUrl = `https://discord.com/register?sitekey=${sitekey}`;
    sendCaptcha(genId, captchaUrl);

    // Wait for user to submit captcha token (max 5 min)
    const captchaToken = await new Promise((resolve) => {
      captchaWaiters[genId] = resolve;
      setTimeout(() => { delete captchaWaiters[genId]; resolve(null); }, 300000);
    });

    if (!captchaToken) return { ...result, error: 'Captcha timeout.' };

    try {
      const r2 = await axios.post(`${DISCORD_API}/auth/register`, {
        email: mail.address, username, password,
        date_of_birth: randomDOB(),
        consent: true, captcha_key: captchaToken,
      }, { headers: discordHeaders() });
      regData = r2.data;
    } catch(e) {
      regData = e.response?.data || {};
    }
  }

  if (!regData.token) return { ...result, error: `Register failed: ${JSON.stringify(regData)}` };

  const token = regData.token;
  result.token = token;
  sendLog(genId, `🔑 Token: ${token.slice(0,24)}...`);
  if (opts.humanizer) await sleep(1000 + Math.random() * 1500);

  // Verify email
  sendLog(genId, '📬 Waiting for verification email...');
  const mailMsg = await mail.waitForMail('discord', 120000);
  if (mailMsg) {
    const body = JSON.stringify(mailMsg);
    const match = body.match(/token=([A-Za-z0-9._\-]+)/);
    if (match) {
      try {
        const vr = await axios.post(`${DISCORD_API}/auth/verify`, { token: match[1] }, { headers: discordHeaders(token) });
        if (vr.data.token) result.token = vr.data.token;
        result.verified = true;
        sendLog(genId, '✅ Email verified!');
      } catch {}
    }
  } else {
    sendLog(genId, '⚠️ Verify email timed out');
  }
  if (opts.humanizer) await sleep(800 + Math.random() * 1200);

  // Bio
  if (opts.setBio) {
    try {
      await axios.patch(`${DISCORD_API}/users/@me/profile`, { bio: V3X_BIO }, { headers: discordHeaders(result.token) });
      sendLog(genId, '📝 Bio set.');
    } catch {}
    if (opts.humanizer) await sleep(600 + Math.random() * 800);
  }

  // Status
  if (opts.setStatus) {
    const status = RANDOM_STATUSES[Math.floor(Math.random() * RANDOM_STATUSES.length)];
    try {
      await axios.patch(`${DISCORD_API}/users/@me/settings`, {
        custom_status: { text: status, emoji_name: '🔥' }
      }, { headers: discordHeaders(result.token) });
      result.status = status;
      sendLog(genId, `💬 Status: ${status}`);
    } catch {}
    if (opts.humanizer) await sleep(600 + Math.random() * 800);
  }

  // HypeSquad
  if (opts.hypesquad) {
    const houses = { bravery: 1, brilliance: 2, balance: 3 };
    const houseNames = Object.keys(houses);
    const house = rand(houseNames);
    try {
      await axios.post(`${DISCORD_API}/hypesquad/online`, { house_id: houses[house] }, { headers: discordHeaders(result.token) });
      result.hypesquad = house;
      sendLog(genId, `🏠 HypeSquad: ${house}`);
    } catch {}
    if (opts.humanizer) await sleep(600 + Math.random() * 800);
  }

  // Trial trigger
  if (opts.trialTrigger) {
    try {
      await axios.get(`${DISCORD_API}/users/@me/billing/subscriptions`, { headers: discordHeaders(result.token) });
      sendLog(genId, '🎁 Trial trigger fired.');
    } catch {}
  }

  return result;
}

// SSE stream endpoint
router.get('/stream/:genId', (req, res) => {
  if (!req.session.licensed && !req.session.isOwner) {
    return res.status(403).end();
  }
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();
  sseClients[req.params.genId] = res;
  req.on('close', () => { delete sseClients[req.params.genId]; });
});

// Start generation
router.post('/start', async (req, res) => {
  if (!req.session.licensed && !req.session.isOwner) {
    return res.status(403).json({ ok: false, msg: 'No license' });
  }
  const { count = 1, opts = {}, genId } = req.body;
  if (!genId) return res.status(400).json({ ok: false, msg: 'No genId' });

  res.json({ ok: true });

  // Run gen async
  (async () => {
    const results = [];
    for (let i = 0; i < Math.min(count, 10); i++) {
      sendLog(genId, `\n[${i+1}/${count}] Starting...`);
      const r = await genOne(genId, opts);
      results.push(r);
      // Save token
      let tokens = [];
      if (fs.existsSync(TOK_FILE)) { try { tokens = JSON.parse(fs.readFileSync(TOK_FILE)); } catch {} }
      tokens.push(r);
      fs.writeFileSync(TOK_FILE, JSON.stringify(tokens, null, 2));
      sendLog(genId, `[${i+1}/${count}] ${r.token ? '✅ Done' : '❌ Failed'}: ${r.email || '?'}`);
      if (i < count - 1 && opts.humanizer) await sleep(3000 + Math.random() * 4000);
    }
    sendDone(genId, results);
  })();
});

// Submit captcha token
router.post('/captcha', (req, res) => {
  const { genId, token } = req.body;
  if (captchaWaiters[genId]) {
    captchaWaiters[genId](token);
    delete captchaWaiters[genId];
    return res.json({ ok: true });
  }
  res.json({ ok: false, msg: 'No waiter found' });
});

module.exports = router;
