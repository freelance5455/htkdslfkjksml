# v3xCloud EVS Gen — Deploy Guide

## Quick Deploy (Railway — Free)
1. Go to https://railway.app → New Project → Deploy from GitHub
2. Upload this folder or push to a GitHub repo
3. Railway auto-detects Node.js, sets PORT env var
4. Done — you get a live URL like `https://v3xevs.railway.app`

## Quick Deploy (Render — Free)
1. Go to https://render.com → New Web Service
2. Connect repo or upload zip
3. Build command: `npm install`
4. Start command: `node server.js`
5. Done

## Run Locally
```
npm install
node server.js
```
Open http://localhost:3000

## Owner Login
- ID: `v3xcloud`
- Password: `v3xcloud@890`

## Flow
1. Owner logs in → creates license keys
2. Users enter key → get access → generate accounts
3. If Discord needs captcha → page shows URL → user solves → pastes token → gen resumes
