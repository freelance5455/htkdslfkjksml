DukaanJor v2 starter
- Customer list with a separate amount box and + button beside each name.
- Payment and history button per customer.
- Local storage, search, backup/restore.
- Still not an APK and not cloud-synced. Shared data for both phones requires backend setup and hosting.
- Do not use for real records without regular backups and testing.
