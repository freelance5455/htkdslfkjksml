CATATAN KEUANGAN - PROJECT ANDROID

Fitur:
- Bisa digunakan offline karena HTML disimpan di dalam aplikasi.
- Data transaksi dan logo disimpan lokal di perangkat (WebView localStorage).
- Logo bisa diganti sendiri melalui tombol "Ganti Logo" dan dihapus lewat "Hapus Logo".
- Backup/Impor transaksi JSON tetap tersedia.

Membuat APK:
1. Ekstrak ZIP ini.
2. Buka folder CatatanKeuanganAndroid di Android Studio.
3. Tunggu Gradle Sync selesai (butuh internet untuk mengunduh komponen build pertama kali).
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug biasanya ada di app/build/outputs/apk/debug/app-debug.apk.

Catatan: Folder project ini adalah source project Android, bukan APK yang sudah dikompilasi.
Data transaksi disimpan di perangkat yang sama. Hapus data aplikasi dapat menghapus data lokal, jadi lakukan backup berkala.
