-- Hapus batas jumlah story (sebelumnya maks 10 aktif per pengguna). Jalankan sekali di Supabase SQL Editor.
create or replace function public.batas_story()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  return new;
end;
$$;
