-- Jalankan sekali di Supabase > SQL Editor (setelah telsaone-chat.sql dan telsaone-admin.sql).
-- Membuat: status game (terbit / arsip, diatur admin) dan papan peringkat publik per game.

-- 1) Status game: semua orang boleh membaca, hanya admin yang boleh mengubah
create table if not exists public.games (
  id text primary key,
  judul text not null,
  status text not null default 'published' check (status in ('published', 'archived')),
  updated_at timestamptz not null default now()
);
alter table public.games enable row level security;

drop policy if exists "game dibaca semua" on public.games;
create policy "game dibaca semua" on public.games for select using (true);
drop policy if exists "game admin insert" on public.games;
create policy "game admin insert" on public.games for insert to authenticated with check (public.is_admin());
drop policy if exists "game admin update" on public.games;
create policy "game admin update" on public.games for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "game admin delete" on public.games;
create policy "game admin delete" on public.games for delete to authenticated using (public.is_admin());

insert into public.games (id, judul, status) values ('brick', 'Brick Breaker', 'published')
on conflict (id) do nothing;

-- 2) Skor terbaik tiap pemain per game (satu baris per pemain per game)
create table if not exists public.game_scores (
  game_id text not null,
  user_id uuid not null references public.profiles(id) on delete cascade,
  skor int not null default 0 check (skor >= 0),
  level int not null default 1,
  plays int not null default 0,
  best_at timestamptz not null default now(),
  last_played timestamptz not null default now(),
  primary key (game_id, user_id)
);
create index if not exists game_scores_rank_idx on public.game_scores (game_id, skor desc, best_at);
alter table public.game_scores enable row level security;

-- Papan peringkat publik: semua orang boleh membaca
drop policy if exists "skor dibaca semua" on public.game_scores;
create policy "skor dibaca semua" on public.game_scores for select using (true);
-- Pemain TIDAK menulis langsung ke tabel; hanya lewat fungsi kirim_skor di bawah.
-- Admin boleh menghapus skor (moderasi)
drop policy if exists "skor hapus admin" on public.game_scores;
create policy "skor hapus admin" on public.game_scores for delete to authenticated using (public.is_admin());

-- 3) Kirim skor: hanya untuk yang login, game yang diarsipkan ditolak, skor terbaik disimpan otomatis
create or replace function public.kirim_skor(p_game text, p_skor int, p_level int)
returns int
language plpgsql
security definer
set search_path = public
as $$
declare
  terbaik int;
begin
  if auth.uid() is null then
    raise exception 'Harus login';
  end if;
  if p_skor is null or p_skor < 0 or p_skor > 1000000 then
    raise exception 'Skor tidak valid';
  end if;
  if exists (select 1 from public.games where id = p_game and status = 'archived') then
    raise exception 'Game sudah diarsipkan';
  end if;

  insert into public.game_scores as t (game_id, user_id, skor, level, plays)
  values (p_game, auth.uid(), p_skor, greatest(coalesce(p_level, 1), 1), 1)
  on conflict (game_id, user_id) do update set
    plays = t.plays + 1,
    last_played = now(),
    skor = greatest(t.skor, excluded.skor),
    level = case when excluded.skor > t.skor then excluded.level else t.level end,
    best_at = case when excluded.skor > t.skor then now() else t.best_at end;

  select skor into terbaik from public.game_scores where game_id = p_game and user_id = auth.uid();
  return terbaik;
end;
$$;

revoke all on function public.kirim_skor(text, int, int) from public;
grant execute on function public.kirim_skor(text, int, int) to authenticated;
