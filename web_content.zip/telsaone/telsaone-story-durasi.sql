-- Jalankan sekali di Supabase > SQL Editor (setelah telsaone-story.sql). Aman dijalankan ulang.
-- Durasi story bisa diatur admin: 1 jam ... 7 hari, atau PERMANEN (tidak pernah dihapus).
-- Pengguna biasa tetap 24 jam.

-- 1) Kolom durasi. expires_at = kapan hilang; permanen = true berarti tidak pernah hilang (expires_at kosong).
alter table public.stories add column if not exists expires_at timestamptz;
alter table public.stories add column if not exists permanen boolean not null default false;
update public.stories set expires_at = created_at + interval '24 hours' where expires_at is null and not permanen;
create index if not exists stories_expires_idx on public.stories (expires_at);

-- 2) Saat story dibuat: pengguna biasa dipaksa 24 jam; hanya admin yang boleh memilih durasi/permanen
create or replace function public.story_atur_durasi()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then
    new.permanen := false;
    new.expires_at := now() + interval '24 hours';
  elsif new.permanen then
    new.expires_at := null;
  else
    new.expires_at := least(greatest(coalesce(new.expires_at, now() + interval '24 hours'), now() + interval '1 minute'), now() + interval '365 days');
  end if;
  return new;
end;
$$;
drop trigger if exists story_atur_durasi on public.stories;
create trigger story_atur_durasi before insert on public.stories for each row execute function public.story_atur_durasi();

-- 3) Ubah durasi story yang sudah terbit (khusus admin). p_permanen = true -> permanen; selain itu p_jam jam dari SEKARANG.
create or replace function public.atur_durasi_story(p_id bigint, p_jam int, p_permanen boolean default false)
returns timestamptz language plpgsql security definer set search_path = public as $$
declare hasil timestamptz;
begin
  if not public.is_admin() then raise exception 'Hanya admin yang boleh mengatur durasi story.'; end if;
  if p_permanen then
    update public.stories set permanen = true, expires_at = null, hapus_req = null, hapus_at = null where id = p_id;
    return null;
  end if;
  if p_jam is null or p_jam < 1 or p_jam > 8760 then raise exception 'Durasi tidak valid.'; end if;
  hasil := now() + make_interval(hours => p_jam);
  update public.stories set permanen = false, expires_at = hasil, hapus_req = null, hapus_at = null where id = p_id;
  return hasil;
exception when undefined_column then
  -- kolom hapus_req/hapus_at belum ada (telsaone-story-cron.sql belum dijalankan)
  if p_permanen then
    update public.stories set permanen = true, expires_at = null where id = p_id;
    return null;
  end if;
  hasil := now() + make_interval(hours => p_jam);
  update public.stories set permanen = false, expires_at = hasil where id = p_id;
  return hasil;
end;
$$;
revoke all on function public.atur_durasi_story(bigint, int, boolean) from public, anon;
grant execute on function public.atur_durasi_story(bigint, int, boolean) to authenticated;

-- 4) Terapkan durasi ke semua aturan lama (baca publik, batas, pembersihan)
drop policy if exists "story dibaca publik 24 jam" on public.stories;
drop policy if exists "story dibaca publik" on public.stories;
create policy "story dibaca publik" on public.stories for select
  using (permanen or expires_at > now() or user_id = auth.uid() or public.is_admin());

-- Maksimal 10 story aktif per pengguna biasa (admin bebas)
create or replace function public.batas_story()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() and (select count(*) from public.stories
       where user_id = new.user_id and (permanen or expires_at > now())) >= 10 then
    raise exception 'Maksimal 10 story aktif dalam 24 jam.';
  end if;
  return new;
end;
$$;

create or replace function public.story_kedaluwarsa(p_path text)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.stories where media_path = p_path and not permanen and expires_at < now());
$$;
create or replace function public.daftar_story_kedaluwarsa()
returns table (id bigint, media_path text) language sql stable security definer set search_path = public as $$
  select s.id, s.media_path from public.stories s where not s.permanen and s.expires_at < now() order by s.expires_at limit 30;
$$;
create or replace function public.hapus_story_kedaluwarsa(p_ids bigint[])
returns void language sql security definer set search_path = public as $$
  delete from public.stories where id = any(p_ids) and not permanen and expires_at < now();
$$;

notify pgrst, 'reload schema';
