-- Penghapusan story TEPAT WAKTU dari server (tanpa menunggu ada pengunjung).
-- Siapkan dulu:
--  1) Supabase > Database > Extensions: aktifkan "pg_cron" dan "pg_net".
--  2) Ganti dua nilai di bagian RAHASIA di bawah: URL proyek dan service_role key
--     (Supabase > Settings > API). Key ini rahasia: jangan dibagikan ke siapa pun.
-- Aman dijalankan ulang.

create extension if not exists pg_net;
create extension if not exists pg_cron;

alter table public.stories add column if not exists hapus_req bigint;
alter table public.stories add column if not exists hapus_at timestamptz;

-- RAHASIA: tersimpan terenkripsi di Vault, tidak terlihat oleh pengunjung situs
do $$ begin
  if not exists (select 1 from vault.secrets where name = 'story_url') then
    perform vault.create_secret('https://GANTI-ID-PROYEK.supabase.co', 'story_url');
  end if;
  if not exists (select 1 from vault.secrets where name = 'story_service_key') then
    perform vault.create_secret('GANTI_DENGAN_SERVICE_ROLE_KEY', 'story_service_key');
  end if;
end $$;

-- (Butuh telsaone-story-durasi.sql: story permanen tidak pernah dihapus, durasi memakai kolom expires_at.)
-- Hapus file di Storage lewat API resmi, baru hapus barisnya setelah file benar-benar terhapus
create or replace function public.bersihkan_story_server()
returns int language plpgsql security definer set search_path = public as $$
declare url text; kunci text; r record; n int := 0; st int; rid bigint;
begin
  select decrypted_secret into url from vault.decrypted_secrets where name = 'story_url';
  select decrypted_secret into kunci from vault.decrypted_secrets where name = 'story_service_key';
  if url is null or kunci is null or url like '%GANTI%' or kunci like 'GANTI%' then return -1; end if;
  url := rtrim(url, '/');

  -- Tahap 2: periksa hasil permintaan hapus sebelumnya
  for r in select id, hapus_req, hapus_at from public.stories where not permanen and expires_at < now() and hapus_req is not null loop
    select status_code into st from net._http_response where id = r.hapus_req;
    if found then
      if st in (200, 204, 404) then
        delete from public.stories where id = r.id;
        n := n + 1;
      else
        update public.stories set hapus_req = null, hapus_at = null where id = r.id; -- gagal: coba lagi
      end if;
    elsif r.hapus_at < now() - interval '1 hour' then
      update public.stories set hapus_req = null, hapus_at = null where id = r.id; -- jawaban hilang: kirim ulang
    end if;
  end loop;

  -- Tahap 1: kirim permintaan hapus file untuk story yang sudah > 24 jam
  for r in select id, media_path from public.stories where not permanen and expires_at < now() and hapus_req is null order by expires_at limit 50 loop
    rid := net.http_delete(url := url || '/storage/v1/object/stories/' || r.media_path,
                           headers := jsonb_build_object('Authorization', 'Bearer ' || kunci));
    update public.stories set hapus_req = rid, hapus_at = now() where id = r.id;
  end loop;
  return n;
end;
$$;
revoke all on function public.bersihkan_story_server() from public, anon, authenticated;

-- Jadwal: tiap 5 menit
do $$ begin
  perform cron.unschedule(jobid) from cron.job where jobname = 'bersihkan-story';
  perform cron.schedule('bersihkan-story', '*/5 * * * *', 'select public.bersihkan_story_server()');
end $$;

-- Uji manual: hasil -1 = rahasia belum diganti; angka >= 0 = jumlah story yang selesai dihapus
-- select public.bersihkan_story_server();
