# Template email Supabase (versi kode)

Buka Supabase > Authentication > Emails > Templates, lalu ganti isi dua template berikut.
Variabel `{{ .Token }}` adalah kode angka; jangan pakai `{{ .ConfirmationURL }}` lagi.

## Confirm sign up
Subject: Kode konfirmasi akun Anda

```html
<h2>Selamat datang!</h2>
<p>Masukkan kode berikut di web untuk mengonfirmasi akun Anda:</p>
<h1 style="letter-spacing:8px;font-size:36px">{{ .Token }}</h1>
<p>Abaikan email ini jika Anda tidak merasa mendaftar.</p>
```

## Reset password
Subject: Kode reset password Anda

```html
<h2>Atur ulang password</h2>
<p>Masukkan kode berikut di web untuk membuat password baru:</p>
<h1 style="letter-spacing:8px;font-size:36px">{{ .Token }}</h1>
<p>Abaikan email ini jika Anda tidak meminta reset password.</p>
```

Panjang dan masa berlaku kode diatur di Authentication > Sign In / Providers > Email
(Email OTP Length dan Email OTP Expiration).
