-- Jalankan sekali di Supabase > SQL Editor SETELAH telsaone-hadiah.sql. Aman dijalankan ulang.
-- Menambah: (1) Dana Kaget per level yang diselesaikan, (2) reset skor juara otomatis / manual dari panel admin.
-- Link tetap diunggah lewat Admin > HADIAH (satu stok bersama dengan hadiah juara).

-- 1) Jenis hadiah: 'juara' (peringkat 1 bertahan) atau 'level' (menyelesaikan level)
alter table public.dana_kaget_hadiah add column if not exists jenis text not null default 'juara';
alter table public.dana_kaget_hadiah add column if not exists level int;
create unique index if not exists dana_kaget_level_unik on public.dana_kaget_hadiah (user_id, game_id, level) where jenis = 'level';

-- 2) Level yang sudah diselesaikan tiap pemain (rahasia: hanya admin yang bisa membaca)
create table if not exists public.level_selesai (
  game_id text not null,
  user_id uuid not null references public.profiles(id) on delete cascade,
  level int not null check (level between 1 and 500),
  selesai_at timestamptz not null default now(),
  primary key (game_id, user_id, level)
);
alter table public.level_selesai enable row level security;
drop policy if exists "level admin baca" on public.level_selesai;
create policy "level admin baca" on public.level_selesai for select to authenticated using (public.is_admin());

-- 3) Pengaturan dari site_content, kunci 'dana_kaget'
create or replace function public.level_aktif()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select value->>'level_aktif' from public.site_content where key = 'dana_kaget'), 'true') <> 'false';
$$;
create or replace function public.level_maks()
returns int language sql stable security definer set search_path = public as $$
  select coalesce((select case when value->>'level_maks' ~ '^[0-9]{1,3}$' then (value->>'level_maks')::int end
    from public.site_content where key = 'dana_kaget'), 10);
$$;
create or replace function public.reset_juara_aktif()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select value->>'reset_juara' from public.site_content where key = 'dana_kaget'), 'true') <> 'false';
$$;

-- 4) Pemain melapor level selesai. Harus berurutan (level 1, 2, 3, ...) dan minimal 12 detik sejak level sebelumnya.
create or replace function public.selesai_level(p_game text, p_level int)
returns void language plpgsql security definer set search_path = public as $$
declare baru int;
begin
  if auth.uid() is null then return; end if;
  if p_level is null or p_level < 1 or p_level > 500 then return; end if;
  if exists (select 1 from public.games where id = p_game and status = 'archived') then return; end if;
  if p_level > 1 and not exists (select 1 from public.level_selesai where game_id = p_game and user_id = auth.uid() and level = p_level - 1)
     and coalesce((select gs.level from public.game_scores gs where gs.game_id = p_game and gs.user_id = auth.uid()), 1) < p_level then return; end if;
  if exists (select 1 from public.level_selesai where game_id = p_game and user_id = auth.uid() and selesai_at > now() - interval '12 seconds') then return; end if;

  insert into public.level_selesai (game_id, user_id, level) values (p_game, auth.uid(), p_level) on conflict do nothing;
  get diagnostics baru = row_count;
  if baru = 0 or not public.level_aktif() or not public.kaget_aktif() or p_level > public.level_maks() then return; end if;

  insert into public.dana_kaget_hadiah (game_id, user_id, jenis, level) values (p_game, auth.uid(), 'level', p_level) on conflict do nothing;
  perform public.isi_hadiah_tertunda();
end;
$$;

-- 4b) Level tempat pemain melanjutkan: level terjauh yang pernah dicapai (selesai + 1, atau level di skor terbaiknya)
create or replace function public.level_saya(p_game text)
returns int language sql stable security definer set search_path = public as $$
  select greatest(
    coalesce((select max(level) + 1 from public.level_selesai where game_id = p_game and user_id = auth.uid()), 1),
    coalesce((select level from public.game_scores where game_id = p_game and user_id = auth.uid()), 1));
$$;
revoke all on function public.level_saya(text) from public, anon;
grant execute on function public.level_saya(text) to authenticated;

-- 5) hadiah_saya sekarang menyertakan jenis & level
drop function if exists public.hadiah_saya();
create function public.hadiah_saya()
returns table (id bigint, game_id text, url text, menang_at timestamptz, jenis text, level int)
language sql stable security definer set search_path = public as $$
  select h.id, h.game_id, k.url, h.menang_at, h.jenis, h.level
  from public.dana_kaget_hadiah h
  join public.dana_kaget_link k on k.id = h.link_id
  where h.user_id = auth.uid() and h.dilihat_at is null
  order by h.id;
$$;

-- 6) Setelah juara menerima hadiah, skornya direset ke 0 (jika pengaturan "reset otomatis" aktif).
--    Ronde baru dimulai: peringkat 1 berikutnya mulai menghitung jam dari nol.
create or replace function public.proses_dana_kaget()
returns void language plpgsql security definer set search_path = public as $$
declare g record; j public.juara_game%rowtype;
begin
  if auth.uid() is null then return; end if;
  perform pg_advisory_xact_lock(7001);
  for g in select distinct game_id from public.game_scores loop
    if exists (select 1 from public.games where id = g.game_id and status = 'archived') then continue; end if;
    perform public.sinkron_juara(g.game_id);
    select * into j from public.juara_game where game_id = g.game_id;
    if j.game_id is not null and not j.hadiah_diberikan
       and now() - j.sejak >= make_interval(hours => public.jam_kaget()) then
      if public.beri_hadiah(g.game_id, j.user_id) then
        update public.juara_game set hadiah_diberikan = true where game_id = g.game_id;
        if public.reset_juara_aktif() then
          update public.game_scores set skor = 0, level = 1 where game_id = g.game_id and user_id = j.user_id;
          delete from public.juara_game where game_id = g.game_id;
          perform public.sinkron_juara(g.game_id);
        end if;
      end if;
    end if;
  end loop;
  perform public.isi_hadiah_tertunda();
end;
$$;

-- 7) Reset manual oleh admin: 'juara' = skor pemegang peringkat 1 jadi 0, 'semua' = hapus semua skor game itu
create or replace function public.reset_skor_game(p_game text, p_mode text)
returns void language plpgsql security definer set search_path = public as $$
declare u uuid;
begin
  if not public.is_admin() then raise exception 'Hanya admin'; end if;
  perform pg_advisory_xact_lock(7001);
  if p_mode = 'semua' then
    delete from public.game_scores where game_id = p_game;
  else
    select user_id into u from public.juara_game where game_id = p_game;
    if u is not null then update public.game_scores set skor = 0, level = 1 where game_id = p_game and user_id = u; end if;
  end if;
  delete from public.juara_game where game_id = p_game;
  perform public.sinkron_juara(p_game);
end;
$$;

revoke all on function public.level_aktif() from public, anon, authenticated;
revoke all on function public.level_maks() from public, anon, authenticated;
revoke all on function public.reset_juara_aktif() from public, anon, authenticated;
revoke all on function public.selesai_level(text, int) from public, anon;
grant execute on function public.selesai_level(text, int) to authenticated;
revoke all on function public.hadiah_saya() from public, anon;
grant execute on function public.hadiah_saya() to authenticated;
revoke all on function public.proses_dana_kaget() from public, anon;
grant execute on function public.proses_dana_kaget() to authenticated;
revoke all on function public.reset_skor_game(text, text) from public, anon;
grant execute on function public.reset_skor_game(text, text) to authenticated;

-- Muat ulang cache skema API Supabase agar fungsi baru langsung dikenali
notify pgrst, 'reload schema';
