-- OPSIONAL tapi disarankan. Jalankan sekali di Supabase > SQL Editor. Aman dijalankan ulang.
-- Password hanya boleh dibuat/diganti untuk akun yang punya login email.
-- Akun yang hanya masuk lewat Google/GitHub tidak bisa diberi password (reset/ganti ditolak server).
create or replace function public.blok_password_non_email()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.encrypted_password is distinct from old.encrypted_password
     and coalesce(new.encrypted_password, '') <> ''
     and not exists (select 1 from auth.identities i where i.user_id = new.id and i.provider = 'email') then
    raise exception 'Akun ini masuk lewat Google/GitHub dan tidak memakai password.';
  end if;
  return new;
end;
$$;

drop trigger if exists blok_password_non_email on auth.users;
create trigger blok_password_non_email
  before update of encrypted_password on auth.users
  for each row execute function public.blok_password_non_email();
