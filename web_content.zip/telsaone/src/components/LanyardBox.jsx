import Lanyard from "./Lanyard";
import { Selotip } from "./Hiasan";
import { useContent } from "../lib/content";

// Kotak lanyard: komponen <Lanyard /> asli React Bits (tidak diubah), tema bawaan (pita hitam, kartu putih).
// Gambar kartu penuh diatur admin di Admin > LANYARD (disimpan di site_content, kunci "lanyard").
export default function LanyardBox() {
  const gambar = useContent()?.lanyard?.gambar || undefined;
  return (
    <div className="relative w-full">
      <Selotip className="-top-3 left-8 -rotate-6" />
      <Selotip warna="bg-sky-300" className="-top-3 right-8 rotate-6" />
      <div className="relative overflow-hidden border-4 border-black bg-white shadow-[6px_6px_0_#111]">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 opacity-70"
          style={{ backgroundImage: "radial-gradient(rgba(0,0,0,.14) 1.5px, transparent 1.5px)", backgroundSize: "9px 9px" }}
        />
        <div style={{ width: "100%", height: "600px" }} className="relative max-h-[78vh] min-h-[440px]">
          {/* Gambar yang sama dipakai di depan dan belakang kartu */}
          <Lanyard frontImage={gambar} />
        </div>
      </div>
    </div>
  );
}
