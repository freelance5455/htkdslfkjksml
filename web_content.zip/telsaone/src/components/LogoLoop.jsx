import { memo, useEffect, useRef, useState } from "react";

// LogoLoop: deretan logo/ikon yang berjalan tanpa henti (JavaScript + Tailwind).
// Didukung: layout "line" & "wave", arah left/right/up/down, speed, hoverSpeed, pauseOnHover, fadeOut,
// scaleOnHover, muted, labels, draggable (geser + lempar), intro, renderItem.
// Props lain dari versi lengkap (arc/orbit, focus, magnify, tiltX/Y, step, scrollBoost) diterima tetapi diabaikan.

const SMOOTH_TAU = 0.25;
const GLIDE_TAU = 0.8;
const DRAG_THRESHOLD = 6;
const MAX_FLING = 4000;

const cx = (...p) => p.filter(Boolean).join(" ");
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const smootherstep = (t) => t * t * t * (t * (t * 6 - 15) + 10);
const toCss = (v) => (typeof v === "number" ? `${v}px` : v ?? undefined);

// Pudar lembut di kedua ujung: mask transparan, jadi cocok di latar apa pun
const fadeMask = (size, vertical) => {
  const span = clamp(size, 0, 0.5) * 100;
  if (span <= 0) return undefined;
  const stops = [];
  for (let i = 0; i <= 12; i++) stops.push(`rgba(0,0,0,${smootherstep(i / 12).toFixed(4)}) ${((span * i) / 12).toFixed(3)}%`);
  for (let i = 12; i >= 0; i--) stops.push(`rgba(0,0,0,${smootherstep(i / 12).toFixed(4)}) ${(100 - (span * i) / 12).toFixed(3)}%`);
  return `linear-gradient(${vertical ? "to bottom" : "to right"}, ${stops.join(", ")})`;
};

const Logo = memo(function Logo({ item, index, height, labels }) {
  const isi = item.node ? (
    <span className="inline-flex items-center justify-center leading-none" style={{ fontSize: height, height }}>{item.node}</span>
  ) : (
    <img src={item.src} alt={item.alt || item.title || ""} draggable={false} loading="lazy" style={{ height, width: "auto", maxWidth: "none" }} />
  );
  const judul = item.title || item.alt;
  const dalam = (
    <span className="ll-inner flex items-center gap-2" style={{ flexDirection: labels === "below" ? "column" : "row" }}>
      {isi}
      {(labels === "inline" || labels === "below") && judul && <span className="ll-label whitespace-nowrap font-body text-sm font-bold">{judul}</span>}
    </span>
  );
  return (
    <li className="ll-item relative shrink-0" style={{ "--ll-hover": item.hoverColor, "--i": Math.min(index, 14) }}>
      {item.href ? (
        <a href={item.href} target="_blank" rel="noreferrer noopener" aria-label={judul} draggable={false} className="block outline-none focus-visible:outline-2 focus-visible:outline-black">{dalam}</a>
      ) : dalam}
      {labels === "hover" && judul && <span className="ll-tip" aria-hidden="true">{judul}</span>}
    </li>
  );
});

export default function LogoLoop({
  logos, speed = 120, direction = "left", width = "100%", logoHeight = 28, gap = 32,
  hoverSpeed, pauseOnHover, fadeOut = true, fadeOutWidth = 0.12, scaleOnHover = false,
  layout = "line", bend = 0.5, muted = 0, labels = "none", draggable = true, intro = true,
  renderItem, ariaLabel = "Partner logos", className, style,
}) {
  const root = useRef(null);
  const track = useRef(null);
  const seq = useRef(null);
  const [copies, setCopies] = useState(2);
  const [masuk, setMasuk] = useState(false);
  const cfg = useRef({});
  const st = useRef({ offset: 0, vel: 0, period: 0, len: 0, items: [], hovered: false, focused: false, drag: null, glide: false, hold: 0, visible: true });

  const vertical = direction === "up" || direction === "down";
  const arah = direction === "left" || direction === "up" ? 1 : -1;
  const wave = layout === "wave";
  const amp = wave ? clamp(bend, -1, 1) * logoHeight * 0.5 : 0;
  const pad = Math.ceil(Math.abs(amp) + (scaleOnHover ? logoHeight * 0.12 : 0) + (labels === "hover" ? logoHeight * 0.5 : 0) + 2);
  cfg.current = { vertical, arah, speed, hoverSpeed, pauseOnHover, wave, amp, gap, draggable };

  // Ukur: panjang satu deret, jumlah salinan agar selalu penuh, dan titik tengah tiap logo (untuk gelombang)
  useEffect(() => {
    const r = root.current, t = track.current, s = seq.current;
    if (!r || !t || !s) return undefined;
    const ukur = () => {
      const c = cfg.current;
      const period = c.vertical ? s.offsetHeight : s.offsetWidth;
      const len = c.vertical ? r.clientHeight : r.clientWidth;
      st.current.period = period;
      st.current.len = len;
      st.current.items = Array.from(t.querySelectorAll("li")).map((el) => ({ el, center: c.vertical ? el.offsetTop + el.offsetHeight / 2 : el.offsetLeft + el.offsetWidth / 2 }));
      if (period > 0) setCopies(Math.max(2, Math.ceil(len / period) + 1));
    };
    ukur();
    const ro = new ResizeObserver(ukur);
    ro.observe(r); ro.observe(s);
    document.fonts?.ready?.then(ukur);
    return () => ro.disconnect();
  }, [logos, logoHeight, gap, vertical, labels, copies]);

  // Muncul pertama kali: logo naik berurutan; jeda animasi saat di luar layar
  useEffect(() => {
    const r = root.current;
    if (!r || typeof IntersectionObserver === "undefined") { setMasuk(true); return undefined; }
    const io = new IntersectionObserver(([e]) => { st.current.visible = e.isIntersecting; if (e.isIntersecting) setMasuk(true); }, { threshold: 0 });
    io.observe(r);
    return () => io.disconnect();
  }, []);

  // Mesin gerak
  useEffect(() => {
    const s = st.current;
    const reduced = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    let raf = 0, last = performance.now();
    const tick = (now) => {
      raf = requestAnimationFrame(tick);
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const c = cfg.current;
      if (!s.visible || s.period <= 0) return;
      const base = reduced ? 0 : c.arah * c.speed;
      let target = base;
      if (s.hovered || s.focused) target = c.hoverSpeed !== undefined ? Math.sign(base || c.arah) * c.hoverSpeed : c.pauseOnHover === false ? base : 0;
      if (!s.drag) {
        const tau = s.glide ? GLIDE_TAU : SMOOTH_TAU;
        s.vel += (target - s.vel) * (1 - Math.exp(-dt / tau));
        if (s.glide && Math.abs(s.vel - target) < 2) s.glide = false;
        s.offset += s.vel * dt;
      }
      s.offset = ((s.offset % s.period) + s.period) % s.period;
      const tr = track.current;
      if (tr) tr.style.transform = c.vertical ? `translate3d(0, ${-s.offset.toFixed(2)}px, 0)` : `translate3d(${-s.offset.toFixed(2)}px, 0, 0)`;
      if (c.wave) {
        const wl = clamp(s.len / 1.25, 220, 520);
        for (const it of s.items) {
          const y = c.amp * Math.sin(((it.center - s.offset) / wl) * Math.PI * 2);
          it.el.style.transform = c.vertical ? `translate3d(${y.toFixed(2)}px, 0, 0)` : `translate3d(0, ${y.toFixed(2)}px, 0)`;
        }
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  // Geser & lempar
  const onDown = (e) => {
    if (!cfg.current.draggable || (e.pointerType === "mouse" && e.button !== 0)) return;
    const s = st.current;
    s.drag = { x: e.clientX, y: e.clientY, t: performance.now(), moved: false, v: 0 };
  };
  const onMove = (e) => {
    const s = st.current, d = s.drag, c = cfg.current;
    if (!d) return;
    const now = performance.now();
    const dx = c.vertical ? e.clientY - d.y : e.clientX - d.x;
    if (!d.moved) {
      if (Math.abs(dx) < DRAG_THRESHOLD) return;
      d.moved = true;
      try { root.current.setPointerCapture(e.pointerId); } catch { /* abaikan */ }
    }
    const dt = Math.max(1, now - d.t) / 1000;
    s.offset -= dx;
    d.v = d.v * 0.6 + (-dx / dt) * 0.4;
    d.x = e.clientX; d.y = e.clientY; d.t = now;
  };
  const onUp = () => {
    const s = st.current, d = s.drag;
    s.drag = null;
    if (!d?.moved) return;
    s.hold = performance.now() + 60; // cegah klik tautan setelah menggeser
    s.vel = clamp(d.v, -MAX_FLING, MAX_FLING);
    s.glide = true;
  };

  const mask = fadeOut ? fadeMask(fadeOutWidth, vertical) : undefined;
  return (
    <div ref={root} role="region" aria-label={ariaLabel}
      className={cx("ll-root relative select-none overflow-hidden", intro && "ll-intro", masuk && "ll-in", muted > 0 && "ll-muted", scaleOnHover && "ll-scale", draggable && "cursor-grab active:cursor-grabbing", className)}
      style={{
        width: toCss(width), height: vertical ? "100%" : undefined, touchAction: vertical ? "pan-x" : "pan-y",
        paddingBlock: vertical ? undefined : pad, paddingInline: vertical ? pad : undefined,
        maskImage: mask, WebkitMaskImage: mask, "--ll-muted": muted, ...style,
      }}
      onPointerEnter={(e) => { if (e.pointerType === "mouse") st.current.hovered = true; }}
      onPointerLeave={() => { st.current.hovered = false; }}
      onFocus={() => { st.current.focused = true; }}
      onBlur={() => { st.current.focused = false; }}
      onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp}
      onClickCapture={(e) => { if (performance.now() < st.current.hold) { e.preventDefault(); e.stopPropagation(); } }}
      onDragStart={(e) => e.preventDefault()}>
      <div ref={track} className="relative flex will-change-transform" style={{ flexDirection: vertical ? "column" : "row", width: vertical ? undefined : "max-content" }}>
        {Array.from({ length: copies }, (_, c) => (
          <ul key={c} ref={c === 0 ? seq : undefined} aria-hidden={c > 0 || undefined} className="m-0 flex list-none p-0"
            style={{ flexDirection: vertical ? "column" : "row", gap, [vertical ? "paddingBottom" : "paddingRight"]: gap, alignItems: "center" }}>
            {logos.map((item, i) => (renderItem ? renderItem(item, `${c}-${i}`) : <Logo key={i} item={item} index={i} height={logoHeight} labels={labels} />))}
          </ul>
        ))}
      </div>
    </div>
  );
}
