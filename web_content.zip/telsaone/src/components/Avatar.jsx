import { useEffect, useState } from "react";
import { AVATAR_ICONS, fotoUser } from "../lib/avatars";

export default function Avatar({ user, size = 40 }) {
  const m = user?.user_metadata || {};
  const foto = fotoUser(m);
  const [rusak, setRusak] = useState(false);
  useEffect(() => setRusak(false), [foto]);

  const base = "flex shrink-0 items-center justify-center overflow-hidden rounded-full border-[3px] border-black font-comic";
  const style = { width: size, height: size };
  const Ikon = AVATAR_ICONS[m.avatar_icon];
  if (Ikon)
    return (
      <div className={base} style={{ ...style, background: m.avatar_bg || "#ffe45e" }}>
        <Ikon size={size * 0.55} strokeWidth={2.5} />
      </div>
    );
  if (foto && !rusak)
    return <img src={foto} alt="" referrerPolicy="no-referrer" onError={() => setRusak(true)} className={base + " object-cover"} style={style} />;
  const huruf = (m.full_name || user?.email || "?").trim()[0]?.toUpperCase();
  return <div className={base} style={{ ...style, background: "#ffe45e", fontSize: size * 0.5 }}>{huruf}</div>;
}
