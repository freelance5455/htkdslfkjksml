import { Star, Zap, Sparkles } from "lucide-react";

// Hiasan khas komik untuk panel profil. Semua dekoratif: tidak bisa diklik & disembunyikan dari pembaca layar.

function Stiker({ teks, warna, className = "", delay = 0, tilt = -8 }) {
  return (
    <div aria-hidden className={`pointer-events-none absolute z-0 ${className}`}>
      <div className="stiker relative h-16 w-16 md:h-24 md:w-24" style={{ "--tilt": `${tilt}deg`, animationDelay: `${delay}ms` }}>
        <div className="burst absolute inset-0 bg-black" />
        <div className="burst absolute inset-[3px] md:inset-1" style={{ background: warna }} />
        <span className="absolute inset-0 flex items-center justify-center font-comic text-lg tracking-wider md:text-2xl" style={{ transform: `rotate(${tilt}deg)` }}>
          {teks}
        </span>
      </div>
    </div>
  );
}

// Latar panel: titik halftone yang bergeser + stiker onomatope
export function PanelDekor() {
  return (
    <>
      <div aria-hidden className="halftone halftone-pink pointer-events-none absolute -right-10 -top-10 z-0 h-44 w-44 md:h-56 md:w-56" />
      <div aria-hidden className="halftone halftone-sky pointer-events-none absolute -bottom-12 -left-12 z-0 h-44 w-44 md:h-56 md:w-56" />
      <Stiker teks="POW!" warna="#ff9ec4" className="left-2 top-2 md:left-5 md:top-5" tilt={-10} />
      <Stiker teks="WOW!" warna="#7ed6ff" className="right-2 top-2 md:right-5 md:top-6" tilt={9} delay={400} />
      <Stiker teks="ZAP!" warna="#9df0a8" className="hidden md:block md:bottom-6 md:right-8" tilt={-6} delay={800} />
    </>
  );
}

const ORBIT = [
  { a: 0, Ikon: Star, fill: "#ffe45e" },
  { a: 90, Ikon: Zap, fill: "#7ed6ff" },
  { a: 180, Ikon: Sparkles, fill: "#ff9ec4" },
  { a: 270, Ikon: Star, fill: "#9df0a8" },
];

// Di belakang & mengelilingi avatar: sinar berputar, cincin putus-putus, bintang mengorbit
export function AvatarDekor() {
  return (
    <>
      <div aria-hidden className="rays pointer-events-none absolute left-1/2 top-1/2 -z-10 h-[22rem] w-[22rem] -translate-x-1/2 -translate-y-1/2" />
      <div aria-hidden className="pointer-events-none absolute left-1/2 top-1/2 h-[15rem] w-[15rem] -translate-x-1/2 -translate-y-1/2">
        <div className="orbit absolute inset-0 rounded-full border-[3px] border-dashed border-black/70">
          {ORBIT.map(({ a, Ikon, fill }, i) => (
            <div key={i} className="absolute left-1/2 top-1/2 -ml-3.5 -mt-3.5" style={{ transform: `rotate(${a}deg) translateX(7.5rem) rotate(${-a}deg)` }}>
              <div className="counter twinkle" style={{ animationDelay: `${i * 300}ms` }}>
                <Ikon size={28} strokeWidth={2.5} fill={fill} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
