import { useCallback, useEffect, useState } from "react";
import { Archive, Eye, RefreshCw, Trash2, Trophy, Users, Gamepad2 } from "lucide-react";
import { supabase } from "../lib/supabase";
import { GAME_META, statusGame } from "../lib/games";
import Avatar from "./Avatar";

const jadiUser = (p) => ({
  user_metadata: { full_name: p?.nama, avatar_icon: p?.avatar_icon, avatar_bg: p?.avatar_bg, avatar_url: p?.avatar_url },
});

const waktu = (v) => {
  const d = new Date(v);
  return d.toLocaleDateString("id-ID", { day: "numeric", month: "short" }) + ", " + d.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });
};

function Angka({ label, bg, children }) {
  return (
    <div className={`border-[3px] border-black px-2 py-1 text-center shadow-[3px_3px_0_#111] ${bg}`}>
      <div className="font-comic text-xs leading-none tracking-widest">{label}</div>
      <div className="mt-0.5 truncate font-comic text-2xl leading-tight tracking-wide">{children}</div>
    </div>
  );
}

// Panel admin untuk memantau game: terbit / arsip, jumlah pemain, total main, skor tertinggi, aktivitas terbaru
export default function GameAdmin({ onToast }) {
  const [status, setStatus] = useState({});
  const [skor, setSkor] = useState(null);
  const [galat, setGalat] = useState("");
  const [busy, setBusy] = useState("");
  const [hapus, setHapus] = useState(""); // konfirmasi dua langkah: "game:user"

  const muat = useCallback(async () => {
    if (!supabase) return setGalat("Supabase belum dikonfigurasi.");
    const [g, s] = await Promise.all([
      supabase.from("games").select("id,status"),
      supabase
        .from("game_scores")
        .select("game_id,user_id,skor,level,plays,best_at,last_played,profiles(nama,avatar_icon,avatar_bg,avatar_url)")
        .order("skor", { ascending: false })
        .limit(1000),
    ]);
    if (g.error || s.error) {
      setGalat("Tabel game belum ada. Jalankan telsaone-game.sql di Supabase > SQL Editor.");
      setSkor([]);
      return;
    }
    setGalat("");
    setStatus(Object.fromEntries(g.data.map((r) => [r.id, r.status])));
    setSkor(s.data);
  }, []);

  useEffect(() => { muat(); }, [muat]);

  const ubahStatus = async (meta, baru) => {
    setBusy(meta.id);
    const { error } = await supabase.from("games").upsert({ id: meta.id, judul: meta.judul, status: baru, updated_at: new Date().toISOString() });
    if (error) onToast(error.message || "Gagal mengubah status.");
    else {
      setStatus((s) => ({ ...s, [meta.id]: baru }));
      onToast(baru === "published" ? `${meta.judul} diterbitkan.` : `${meta.judul} diarsipkan. Tidak tampil lagi untuk pengunjung.`);
    }
    setBusy("");
  };

  const hapusSkor = async (gameId, userId) => {
    const kunci = gameId + ":" + userId;
    if (hapus !== kunci) { setHapus(kunci); return; }
    setHapus("");
    const { error } = await supabase.from("game_scores").delete().eq("game_id", gameId).eq("user_id", userId);
    if (error) return onToast(error.message || "Gagal menghapus skor.");
    setSkor((l) => l.filter((r) => !(r.game_id === gameId && r.user_id === userId)));
    onToast("Skor dihapus dari peringkat.");
  };

  if (skor === null) return <p className="py-8 text-center font-comic text-2xl tracking-wide">MEMUAT...</p>;

  return (
    <div className="space-y-5">
      {galat && <p className="border-[3px] border-dashed border-black bg-pink-100 p-3 font-body font-bold">{galat}</p>}

      <button type="button" onClick={muat} className="btn inline-flex items-center gap-2 bg-sky-200 px-4 py-1 text-lg">
        <RefreshCw size={18} strokeWidth={2.5} /> SEGARKAN
      </button>

      {GAME_META.map((meta) => {
        const st = statusGame(status, meta.id);
        const terbit = st === "published";
        const baris = skor.filter((r) => r.game_id === meta.id);
        const totalMain = baris.reduce((a, r) => a + r.plays, 0);
        const puncak = baris[0]; // sudah diurutkan skor tertinggi
        const terbaru = [...baris].sort((a, b) => new Date(b.last_played) - new Date(a.last_played)).slice(0, 8);
        const Ikon = meta.Ikon;
        return (
          <div key={meta.id} className="border-[3px] border-black bg-white p-4 shadow-[4px_4px_0_#111]">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <div className="flex h-11 w-11 items-center justify-center rounded-full border-[3px] border-black bg-yellow-300"><Ikon size={22} strokeWidth={2.5} /></div>
                <div>
                  <p className="font-comic text-2xl leading-none tracking-wide">{meta.judul}</p>
                  <span className={`mt-1 inline-block border-2 border-black px-2 font-comic text-sm tracking-wider ${terbit ? "bg-green-200" : "bg-zinc-200"}`}>
                    {terbit ? "TERBIT" : "DIARSIPKAN"}
                  </span>
                </div>
              </div>
              <button
                type="button"
                disabled={busy === meta.id}
                onClick={() => ubahStatus(meta, terbit ? "archived" : "published")}
                className={`btn inline-flex items-center gap-2 px-4 py-1 text-lg disabled:opacity-60 ${terbit ? "bg-pink-200" : "bg-green-200"}`}
              >
                {terbit ? <Archive size={18} strokeWidth={2.5} /> : <Eye size={18} strokeWidth={2.5} />}
                {terbit ? "ARSIPKAN" : "TERBITKAN"}
              </button>
            </div>

            <div className="mt-3 grid grid-cols-3 gap-2">
              <Angka label="PEMAIN" bg="bg-sky-200">{baris.length}</Angka>
              <Angka label="TOTAL MAIN" bg="bg-pink-200">{totalMain}</Angka>
              <Angka label="SKOR TERTINGGI" bg="bg-yellow-300">{puncak ? puncak.skor : 0}</Angka>
            </div>
            {puncak && (
              <p className="mt-2 flex items-center gap-1 font-body text-sm font-bold text-neutral-600">
                <Trophy size={15} strokeWidth={2.5} /> Pemegang rekor: {puncak.profiles?.nama || "Pengguna"}
              </p>
            )}

            <h4 className="mt-4 flex items-center gap-2 font-comic text-xl tracking-wide"><Users size={18} strokeWidth={2.5} /> AKTIVITAS TERBARU</h4>
            {terbaru.length === 0 ? (
              <p className="mt-1 border-[3px] border-dashed border-black p-3 text-center font-body font-bold text-neutral-500">Belum ada yang bermain.</p>
            ) : (
              <ul className="mt-1 space-y-1.5">
                {terbaru.map((r) => (
                  <li key={r.user_id} className="flex items-center gap-2 border-2 border-black bg-neutral-50 px-2 py-1">
                    <Avatar user={jadiUser(r.profiles)} size={30} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-comic text-lg leading-tight tracking-wide">{r.profiles?.nama || "Pengguna"}</p>
                      <p className="font-body text-xs font-bold text-neutral-500">{waktu(r.last_played)} · {r.plays}x main</p>
                    </div>
                    <span className="font-comic text-xl tracking-wide">{r.skor}</span>
                  </li>
                ))}
              </ul>
            )}

            <h4 className="mt-4 flex items-center gap-2 font-comic text-xl tracking-wide"><Gamepad2 size={18} strokeWidth={2.5} /> PERINGKAT (MODERASI)</h4>
            {baris.length === 0 ? (
              <p className="mt-1 font-body text-sm font-bold text-neutral-500">Kosong.</p>
            ) : (
              <ol className="papan-scroll mt-1 max-h-72 space-y-1.5 overflow-y-auto pr-2">
                {baris.map((r, i) => {
                  const kunci = r.game_id + ":" + r.user_id;
                  return (
                    <li key={r.user_id} className="flex items-center gap-2 border-2 border-black bg-white px-2 py-1">
                      <span className="w-7 shrink-0 text-center font-comic text-lg">{i + 1}</span>
                      <span className="min-w-0 flex-1 truncate font-comic text-lg tracking-wide">{r.profiles?.nama || "Pengguna"}</span>
                      <span className="font-comic text-lg tracking-wide">{r.skor}</span>
                      <button
                        type="button"
                        onClick={() => hapusSkor(r.game_id, r.user_id)}
                        aria-label="Hapus skor"
                        className={`btn flex items-center gap-1 px-1.5 py-0.5 text-sm ${hapus === kunci ? "bg-red-300" : "bg-pink-200"}`}
                      >
                        <Trash2 size={15} strokeWidth={3} /> {hapus === kunci ? "YAKIN?" : ""}
                      </button>
                    </li>
                  );
                })}
              </ol>
            )}
          </div>
        );
      })}
    </div>
  );
}
