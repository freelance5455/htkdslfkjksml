import { Music, Play, Pause, SkipBack, SkipForward, Volume2 } from "lucide-react";
import { useMusic } from "../lib/music";
import { useContent } from "../lib/content";

const fmt = (s) => (isNaN(s) ? "0:00" : `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`);

export default function MusicPlayer() {
  const { list, i, cur, playing, time, dur, vol, toggle, go, pilih, seek, changeVol } = useMusic();
  const ready = !!cur?.src;
  const { teks } = useContent();

  return (
    <div className="panel p-5 md:p-6" style={{ transform: "none" }}>
      <div className="flex flex-col items-center gap-5 sm:flex-row">
        <div className="relative flex h-36 w-36 shrink-0 items-center justify-center rounded-full border-4 border-black bg-neutral-900 shadow-[5px_5px_0_#111]"
          style={{ animation: playing ? "spin 5s linear infinite" : "none" }}>
          <div className="absolute inset-3 rounded-full border-2 border-neutral-600" />
          <div className="absolute inset-7 rounded-full border-2 border-neutral-600" />
          <div className="flex h-14 w-14 items-center justify-center rounded-full border-4 border-black bg-yellow-300"><Music size={24} strokeWidth={2.5} /></div>
        </div>
        <div className="w-full min-w-0 flex-1">
          <p className="font-comic text-sm tracking-wider text-red-500">{playing ? teks.mp_diputar : teks.mp_label}</p>
          <h4 className="truncate font-comic text-3xl tracking-wide">{cur?.title}</h4>
          <p className="truncate font-body font-bold text-neutral-600">{cur?.artist}</p>
          {!ready && <p className="mt-1 font-body text-sm font-bold text-neutral-500">{list.length ? teks.mp_tanpa_file : teks.mp_kosong}</p>}

          <input type="range" min="0" max={dur || 0} step="0.1" value={time} disabled={!ready} onChange={(e) => seek(+e.target.value)}
            aria-label="Posisi lagu" className="mt-3 w-full accent-black" />
          <div className="flex justify-between font-body text-sm font-bold"><span>{fmt(time)}</span><span>{fmt(dur)}</span></div>

          <div className="mt-2 flex flex-wrap items-center gap-3">
            <button onClick={() => go(-1)} aria-label="Sebelumnya" className="btn flex items-center bg-white px-3 py-2"><SkipBack size={22} fill="currentColor" /></button>
            <button onClick={toggle} aria-label={playing ? "Jeda" : "Putar"} className="btn flex items-center bg-yellow-300 px-5 py-2">{playing ? <Pause size={26} fill="currentColor" /> : <Play size={26} fill="currentColor" />}</button>
            <button onClick={() => go(1)} aria-label="Berikutnya" className="btn flex items-center bg-white px-3 py-2"><SkipForward size={22} fill="currentColor" /></button>
            <label className="ml-auto flex items-center gap-2 font-body font-bold"><Volume2 size={22} strokeWidth={2.5} />
              <input type="range" min="0" max="1" step="0.05" value={vol} onChange={(e) => changeVol(+e.target.value)} className="w-24 accent-black" />
            </label>
          </div>
        </div>
      </div>

      <ul className="mt-5 divide-y-[3px] divide-black border-[3px] border-black">
        {list.map((t, n) => (
          <li key={n}>
            <button onClick={() => pilih(n)}
              className={`flex w-full items-center gap-3 px-3 py-2 text-left font-body font-bold transition-colors ${n === i ? "bg-yellow-200" : "bg-white hover:bg-neutral-100"}`}>
              <span className="flex w-6 justify-center font-comic text-xl">{n === i && playing ? <Play size={16} fill="currentColor" /> : n + 1}</span>
              <span className="min-w-0 flex-1 truncate">{t.title}</span>
              <span className="text-sm text-neutral-500">{t.artist}</span>
            </button>
          </li>
        ))}
      </ul>

    </div>
  );
}
