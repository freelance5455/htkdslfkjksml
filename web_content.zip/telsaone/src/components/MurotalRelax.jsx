import { useEffect, useRef, useState } from "react";
import { BookOpen, ChevronDown, Film, Pause, Play, SkipBack, SkipForward, Volume2 } from "lucide-react";
import { useContent } from "../lib/content";
import { useMusic } from "../lib/music";

const fmt = (s) => (!isFinite(s) || isNaN(s) ? "0:00" : `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`);

function Equalizer({ on }) {
  return (
    <span aria-hidden="true" className="inline-flex h-4 items-end gap-[2px]">
      {[0, 0.2, 0.1, 0.3].map((d, n) => (
        <span
          key={n}
          className="h-full w-[3px] origin-bottom bg-black"
          style={{ transform: on ? undefined : "scaleY(.3)", animation: on ? `hk-eq 0.9s ease-in-out ${d}s infinite` : "none" }}
        />
      ))}
    </span>
  );
}

// Playlist murotal. Komponen ini HANYA dipasang di halaman Game, jadi murotal otomatis berhenti
// begitu pengunjung pindah halaman. Memutar murotal menghentikan musik global, dan menyalakan musik
// kembali akan menjeda murotal (tidak pernah dua suara sekaligus).
// Hanya ADA SATU video relax (diatur di Admin > MUROTAL) yang diputar berulang tanpa suara selama murotal
// berjalan. Setiap item playlist cukup berupa file audio (.mp3 / .m4a), jadi tidak perlu satu video per audio.
export default function MurotalRelax({ ringkas = false }) {
  const { teks, murotal: MUROTAL, murotalVideo } = useContent(); // daftar diatur di Admin > MUROTAL (bawaan: src/data.js)
  const { playing: musikMain, jeda: jedaMusik } = useMusic();
  const [i, setI] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [dur, setDur] = useState(0);
  const [vol, setVol] = useState(0.8);
  const [buka, setBuka] = useState(!ringkas);
  const audio = useRef(null);
  const video = useRef(null);
  const auto = useRef(false); // putar otomatis setelah ganti trek

  const cur = MUROTAL[i] ?? MUROTAL[0];
  // Data lama yang hanya berisi video tetap bisa diputar: suaranya diambil dari file itu lewat <audio>
  const sumber = (t) => t?.audio || t?.video || "";
  const siap = !!sumber(cur);
  const videoSrc = murotalVideo; // satu video relax untuk semua audio
  const ada = (t) => !!sumber(t);
  const media = () => audio.current;

  // Saat game dibuka/ditutup: lipat/buka daftar & video (kontrol tetap tampil)
  useEffect(() => { setBuka(!ringkas); }, [ringkas]);

  // Volume hanya untuk audio; video relax selalu bisu
  useEffect(() => {
    if (audio.current) audio.current.volume = vol;
    if (video.current) video.current.muted = true;
  }, [vol, videoSrc]);

  // Berhenti total saat komponen dilepas (pindah halaman)
  useEffect(() => {
    const a = audio.current, v = video.current;
    return () => { a?.pause(); v?.pause(); };
  }, []);

  // Ganti trek: lanjut putar bila diminta
  useEffect(() => {
    setTime(0); setDur(0);
    if (auto.current && siap) mulai();
    else if (!siap) { audio.current?.pause(); video.current?.pause(); setPlaying(false); }
  }, [i]); // eslint-disable-line react-hooks/exhaustive-deps

  // Musik dinyalakan -> murotal dijeda
  useEffect(() => {
    const m = media();
    if (musikMain && m && !m.paused) { m.pause(); auto.current = false; setPlaying(false); }
  }, [musikMain]); // eslint-disable-line react-hooks/exhaustive-deps

  // Video relax berjalan (loop) selama murotal diputar, dan tidak mulai ulang saat ganti audio
  useEffect(() => {
    const v = video.current;
    if (!v) return;
    if (playing) v.play().catch(() => {});
    else v.pause();
  }, [playing, videoSrc]);

  function mulai() {
    const a = media();
    if (!a || !siap) return;
    jedaMusik(); // musik berhenti otomatis
    a.play().then(() => { setPlaying(true); auto.current = true; }).catch(() => setPlaying(false));
  }

  const toggle = () => {
    const a = media();
    if (!a || !siap) return;
    if (a.paused) mulai();
    else { a.pause(); auto.current = false; setPlaying(false); }
  };

  const pilih = (n) => {
    if (!MUROTAL.length) return;
    const m = ((n % MUROTAL.length) + MUROTAL.length) % MUROTAL.length;
    if (!ada(MUROTAL[m])) return;
    auto.current = true;
    if (m === i) { const md = media(); if (md) md.currentTime = 0; mulai(); } else setI(m);
  };
  const lompat = (d) => {
    // lewati trek yang belum berisi audio
    for (let k = 1; k <= MUROTAL.length; k++) {
      const m = (((i + d * k) % MUROTAL.length) + MUROTAL.length) % MUROTAL.length;
      if (ada(MUROTAL[m])) { auto.current = playing || auto.current; if (m === i) { const md = media(); if (md) md.currentTime = 0; if (auto.current) mulai(); } else setI(m); return; }
    }
  };

  const seek = (v) => { const md = media(); if (md) md.currentTime = v; setTime(v); };

  // Event untuk <audio>
  const ev = {
    onLoadedMetadata: (e) => { e.target.volume = vol; setDur(e.target.duration); },
    onTimeUpdate: (e) => setTime(e.target.currentTime),
    onPlay: () => { setPlaying(true); auto.current = true; jedaMusik(); }, // lewat jalur apa pun murotal mulai, musik pasti berhenti
    onPause: (e) => { if (!e.target.ended) setPlaying(false); },
    onEnded: () => lompat(1),
  };

  return (
    <section aria-label={teks.murotal_judul} className="relative mt-5 border-[3px] border-black bg-green-100 p-3 shadow-[5px_5px_0_#111] sm:p-4">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="halftone halftone-sky absolute -right-8 -top-8 h-32 w-32" />
        <div className="halftone halftone-pink absolute -bottom-10 -left-8 h-28 w-28" />
      </div>

      <div className="relative">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border-[3px] border-black bg-green-300 shadow-[3px_3px_0_#111]">
              <BookOpen size={22} strokeWidth={2.5} />
            </div>
            <div>
              <h2 className="font-comic text-2xl leading-none tracking-wide sm:text-3xl">{teks.murotal_judul}</h2>
              <p className="mt-1 inline-flex items-center gap-1.5 border-2 border-black bg-white px-1.5 font-comic text-sm leading-tight tracking-wider">
                <Equalizer on={playing} /> {playing ? teks.murotal_diputar : teks.murotal_label}
              </p>
            </div>
          </div>
          {ringkas && (
            <button type="button" onClick={() => setBuka((b) => !b)} aria-expanded={buka} className="btn inline-flex items-center gap-1 bg-white px-2 text-base leading-7">
              {teks.murotal_tampil} <ChevronDown size={16} strokeWidth={3} className={`transition-transform ${buka ? "rotate-180" : ""}`} />
            </button>
          )}
        </div>

        {/* Selalu dipasang (hanya disembunyikan saat dilipat) supaya video tidak mulai dari awal */}
        <div className={buka ? "relative mt-3 aspect-video overflow-hidden border-[3px] border-black bg-sky-200 shadow-[3px_3px_0_#111]" : "hidden"}>
          {videoSrc ? (
            <video ref={video} key={videoSrc} src={videoSrc} loop muted playsInline preload="metadata" className="h-full w-full object-cover" />
          ) : (
            <div className="flex h-full w-full flex-col items-center justify-center gap-2 text-center">
              <div className="halftone halftone-pink absolute inset-0 rounded-none" />
              <div className="float relative flex h-14 w-14 items-center justify-center rounded-full border-[3px] border-black bg-yellow-300 shadow-[3px_3px_0_#111]"><Film size={26} strokeWidth={2.5} /></div>
              <p className="relative font-comic text-xl tracking-wide">{teks.murotal_video_kosong}</p>
            </div>
          )}
          {siap && (
            <span className="absolute bottom-2 left-2 max-w-[85%] truncate border-2 border-black bg-yellow-300 px-2 font-comic text-base tracking-wider shadow-[2px_2px_0_#111]">{cur.judul}</span>
          )}
        </div>

        <div className="mt-3 border-[3px] border-black bg-white p-2.5 shadow-[3px_3px_0_#111]">
          <h3 className="truncate font-comic text-2xl leading-tight tracking-wide">{cur?.judul}</h3>
          <p className="truncate font-body text-sm font-bold text-neutral-600">{siap ? cur.qari : teks.murotal_kosong}</p>

          <input type="range" min="0" max={dur || 0} step="0.1" value={time} disabled={!siap} onChange={(e) => seek(+e.target.value)}
            aria-label="Posisi murotal" className="mt-2 w-full accent-black" />
          <div className="flex justify-between font-body text-sm font-bold"><span>{fmt(time)}</span><span>{fmt(dur)}</span></div>

          <div className="mt-1 flex flex-wrap items-center gap-3">
            <button onClick={() => lompat(-1)} aria-label="Sebelumnya" className="btn flex items-center bg-white px-3 py-2"><SkipBack size={20} fill="currentColor" /></button>
            <button onClick={toggle} disabled={!siap} aria-label={playing ? "Jeda" : "Putar"} className="btn flex items-center bg-green-300 px-5 py-2 disabled:opacity-50">
              {playing ? <Pause size={24} fill="currentColor" /> : <Play size={24} fill="currentColor" />}
            </button>
            <button onClick={() => lompat(1)} aria-label="Berikutnya" className="btn flex items-center bg-white px-3 py-2"><SkipForward size={20} fill="currentColor" /></button>
            <label className="ml-auto flex items-center gap-2 font-body font-bold"><Volume2 size={20} strokeWidth={2.5} />
              <input type="range" min="0" max="1" step="0.05" value={vol} onChange={(e) => setVol(+e.target.value)} aria-label="Volume murotal" className="w-20 accent-black" />
            </label>
          </div>
        </div>

        {buka && (
          <ul className="mt-3 divide-y-[3px] divide-black border-[3px] border-black bg-white">
            {MUROTAL.map((t, n) => (
              <li key={n}>
                <button
                  onClick={() => pilih(n)}
                  disabled={!ada(t)}
                  className={`flex w-full items-center gap-3 px-3 py-2 text-left font-body font-bold transition-colors disabled:cursor-not-allowed disabled:opacity-50 ${n === i ? "bg-green-200" : "bg-white enabled:hover:bg-neutral-100"}`}
                >
                  <span className="flex w-6 justify-center font-comic text-xl">{n === i && playing ? <Equalizer on /> : n + 1}</span>
                  <span className="min-w-0 flex-1 truncate">{t.judul}</span>
                  <span className="truncate text-sm text-neutral-500">{t.qari}</span>
                </button>
              </li>
            ))}
          </ul>
        )}

        <p className="mt-3 font-body text-xs font-bold leading-snug text-neutral-600">{teks.murotal_catatan}</p>
      </div>

      <audio ref={audio} src={sumber(cur) || undefined} preload="metadata" {...ev} />
    </section>
  );
}
