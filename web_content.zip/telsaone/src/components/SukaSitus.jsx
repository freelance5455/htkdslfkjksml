import { useEffect, useState } from "react";
import PulseHeart from "./PulseHeart";
import Reveal from "./Reveal";
import { supabase } from "../lib/supabase";
import { useContent } from "../lib/content";

// Suka untuk website: satu akun hanya bisa memberi satu suka, dan tidak bisa dibatalkan.
export default function SukaSitus({ onToast }) {
  const [info, setInfo] = useState(null); // { jumlah, sudah }
  const [versi, setVersi] = useState(0);
  const { teks } = useContent();

  useEffect(() => {
    if (!supabase) return undefined;
    let batal = false;
    supabase.rpc("info_suka").then(({ data, error }) => {
      const r = Array.isArray(data) ? data[0] : data;
      if (batal || error || !r) return; // SQL belum dijalankan: panel disembunyikan
      setInfo({ jumlah: Number(r.jumlah) || 0, sudah: !!r.sudah });
    });
    return () => { batal = true; };
  }, [versi]);

  if (!info) return null;

  const suka = async (liked) => {
    if (!liked || info.sudah) return;
    const { data, error } = await supabase.rpc("suka_situs");
    if (error) {
      onToast?.(teks.suka_gagal);
      setVersi((v) => v + 1); // muat ulang keadaan sebenarnya
      return;
    }
    setInfo({ jumlah: Number(data) || info.jumlah + 1, sudah: true });
  };

  return (
    <Reveal>
      <div className="mt-6 flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-center">
        <span className="font-comic text-lg tracking-wide">{teks.suka_judul}</span>
        <div className="rounded-[22px] border-[3px] border-black shadow-[2px_2px_0_#111]">
          <PulseHeart
            key={versi}
            liked={info.sudah}
            count={info.jumlah}
            onChange={suka}
            disabled={info.sudah}
            className="disabled:!opacity-100"
            size={26}
            corner={18}
            pillColor="#fde047"
            idleColor="#111111"
            likedColor="#ef4444"
            textColor="#111111"
            label="Suka website ini"
          />
        </div>
        <span className="font-body text-xs font-bold text-neutral-500" aria-live="polite">
          {info.sudah ? teks.suka_sudah : teks.suka_belum}
        </span>
      </div>
    </Reveal>
  );
}
