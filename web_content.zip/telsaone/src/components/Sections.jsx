import { PartyPopper, Music, Image, Film, ArrowUp } from "lucide-react";
import Reveal from "./Reveal";
import { HiasanHero, HiasanIsi, HiasanPenutup, OrbitBintang, Selotip } from "./Hiasan";
import MusicPlayer from "./MusicPlayer";
import LanyardBox from "./LanyardBox";
import AnimasiSiswa from "./AnimasiSiswa";
import UltahSiswa from "./UltahSiswa";
import { useContent } from "../lib/content";

export function Pengenalan({ user }) {
  const { teks } = useContent();
  const nama = user?.user_metadata?.full_name?.split(" ")[0];
  return (
    <section id="pengenalan" className="relative isolate mx-auto flex min-h-screen max-w-5xl flex-col items-center justify-center gap-10 px-5 pb-32 pt-10 md:flex-row">
      <HiasanHero />
      <Reveal className="flex-1">
        <div className="bubble panel rounded-[2rem] p-6 md:p-8" style={{ transform: "none" }}>
          <span className="inline-block border-2 border-black bg-pink-300 px-2 font-comic tracking-wider">{teks.pengenalan_label}</span>
          <p className="mt-2 font-comic text-xl tracking-wider text-red-500">{nama ? teks.sapa_nama.replace("{nama}", nama.toUpperCase()) : teks.sapa_tamu}</p>
          <h1 className="font-comic text-5xl leading-none tracking-wide md:text-7xl">
            {teks.judul_1} <span className="bg-yellow-300 px-2">{teks.judul_2}</span>
          </h1>
          <p className="mt-4 whitespace-pre-line font-body text-lg font-bold text-neutral-700">{teks.pengenalan}</p>
          <p className="mt-2 flex items-center gap-2 font-comic text-2xl tracking-wide">{teks.pengenalan_salam} <PartyPopper size={26} strokeWidth={2.5} /></p>
          <div className="mt-6 flex flex-wrap gap-3">
            <a href="#isi" className="btn bg-yellow-300 px-5 py-2 text-xl">{teks.tombol_mulai}</a>
            <a href="#penutup" className="btn bg-white px-5 py-2 text-xl">{teks.tombol_penutup}</a>
          </div>
        </div>
      </Reveal>
      <Reveal delay={150}>
        <div className="float relative flex h-60 w-60 items-center justify-center md:h-72 md:w-72">
          <OrbitBintang />
          <div className="burst absolute inset-0 bg-black" />
          <div className="burst absolute inset-2 bg-yellow-300" />
          <span className="relative -rotate-6 font-comic text-6xl tracking-wider md:text-7xl">{teks.yeay}</span>
        </div>
      </Reveal>
    </section>
  );
}

function MediaSlot({ m, kosong }) {
  const box = "panel flex aspect-video items-center justify-center overflow-hidden p-0";
  if (m.src && m.type === "video") return <div className={box}><video src={m.src} controls className="h-full w-full object-cover" /></div>;
  if (m.src) return <div className={box}><img src={m.src} alt={m.title} loading="lazy" className="h-full w-full object-cover" /></div>;
  const Icon = m.type === "video" ? Film : Image;
  return (
    <div className={box} style={{ backgroundImage: "radial-gradient(rgba(0,0,0,.14) 1.5px, transparent 1.5px)", backgroundSize: "9px 9px" }}>
      <div className="flex flex-col items-center text-center">
        <Icon size={44} strokeWidth={2.25} />
        <p className="font-comic text-xl tracking-wide">{m.title}</p>
        <p className="font-body text-sm font-bold text-neutral-500">{kosong}</p>
      </div>
    </div>
  );
}

export function Isi() {
  const { media, teks } = useContent();
  return (
    <section id="isi" className="relative isolate mx-auto max-w-5xl px-5 py-20">
      <HiasanIsi />
      <Reveal><h2 className="mb-8 font-comic text-5xl tracking-wide">{teks.isi_1} <span className="bg-sky-300 px-2">{teks.isi_2}</span></h2></Reveal>

      <Reveal delay={50}><h3 className="mb-4 flex items-center gap-2 font-comic text-3xl tracking-wide"><Music size={28} strokeWidth={2.5} /> {teks.judul_musik}</h3></Reveal>
      <Reveal delay={100}>
        <div className="relative">
          <Selotip className="-top-3 left-8 -rotate-6" />
          <Selotip warna="bg-sky-300" className="-top-3 right-8 rotate-6" />
          <MusicPlayer />
        </div>
      </Reveal>

      <Reveal><h3 className="mb-4 mt-14 flex items-center gap-2 font-comic text-3xl tracking-wide"><Image size={28} strokeWidth={2.5} /> {teks.judul_media}</h3></Reveal>
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {media.map((m, i) => (
          <Reveal key={i} delay={(i % 3) * 100}>
            <MediaSlot m={m} kosong={teks.media_kosong} />
          </Reveal>
        ))}
      </div>

      <AnimasiSiswa />

      <Reveal>
        <div className="mx-auto mt-14 max-w-md">
          <LanyardBox />
        </div>
      </Reveal>

      <UltahSiswa />
    </section>
  );
}

export function Penutup() {
  const { teks } = useContent();
  return (
    <section id="penutup" className="relative isolate mx-auto max-w-3xl px-5 pb-24 pt-20">
      <HiasanPenutup />
      <Reveal>
        <div className="bubble panel rounded-[2rem] p-6 text-center md:p-10" style={{ transform: "none" }}>
          <span className="inline-block border-2 border-black bg-green-300 px-2 font-comic tracking-wider">{teks.penutup_label}</span>
          <h2 className="mt-2 font-comic text-5xl tracking-wide md:text-6xl">{teks.penutup_1} <span className="bg-yellow-300 px-2">{teks.penutup_2}</span></h2>
          <p className="mx-auto mt-4 max-w-xl whitespace-pre-line font-body text-lg font-bold text-neutral-700">{teks.penutup}</p>
          <a href="#pengenalan" className="btn mt-6 inline-flex items-center gap-2 bg-yellow-300 px-6 py-2 text-xl">{teks.tombol_atas} <ArrowUp size={22} strokeWidth={3} /></a>
        </div>
      </Reveal>
    </section>
  );
}
