import { useEffect, useMemo, useRef, useState } from "react";
import { useContent } from "../lib/content";
import { ChevronLeft, ChevronRight, Clock, Film, ImagePlus, Infinity as IkonTakHingga, Plus, Sparkles, Trash2, Volume2, VolumeX, X } from "lucide-react";
import { AVATAR_ICONS } from "../lib/avatars";
import { isAdmin } from "../lib/admin";
import { supabase } from "../lib/supabase";
import { OPSI_STORY, STORY_MAKS_MB, akanDikompres, hapusFile, pathDariUrl, unggah } from "../lib/upload";
import { aturDurasi, lalu, sisaTeks, useStories, waktuHilang } from "../lib/stories";
import DurasiGeser, { INDEKS_24J, LANGKAH, indeksDari } from "./DurasiGeser";

const DURASI_FOTO = 6000; // ms
const CINCIN_BARU = { background: "conic-gradient(from 200deg, #fde047, #f9a8d4, #7dd3fc, #fde047)" };
const CINCIN_LAMA = { background: "#d4d4d4" };
const bayang = { textShadow: "2px 2px 0 #111" };

function Ava({ p = {}, size = 52 }) {
  const Ikon = AVATAR_ICONS[p.avatar_icon];
  const base = "flex shrink-0 items-center justify-center overflow-hidden rounded-full border-[3px] border-black font-comic";
  const st = { width: size, height: size };
  if (Ikon) return <div className={base} style={{ ...st, background: p.avatar_bg || "#ffe45e" }}><Ikon size={size * 0.55} strokeWidth={2.5} /></div>;
  if (p.avatar_url) return <img src={p.avatar_url} alt="" referrerPolicy="no-referrer" className={`${base} object-cover`} style={st} />;
  return <div className={base} style={{ ...st, background: "#ffe45e", fontSize: size * 0.5 }}>{(p.nama || "?")[0]?.toUpperCase()}</div>;
}

const pesanError = (err) => {
  const m = err?.message || "";
  if (/atur_durasi_story|expires_at|permanen/i.test(m)) return "Fitur durasi belum aktif. Jalankan telsaone-story-durasi.sql di Supabase.";
  if (/relation|schema cache|does not exist|bucket/i.test(m)) return "Fitur story belum aktif. Jalankan telsaone-story.sql di Supabase.";
  return m || "Gagal mengunggah story.";
};

// ---------- Penonton layar penuh ----------
function Penonton({ daftar, gi: gi0, ii: ii0, user, onClose, onHapus, tandai, onToast, onMuat }) {
  const { teks } = useContent();
  const [gi, setGi] = useState(gi0);
  const [ii, setIi] = useState(ii0);
  const [p, setP] = useState(0);
  const [jeda, setJeda] = useState(false);
  const [bisu, setBisu] = useState(false);
  const [yakin, setYakin] = useState(false);
  const [menu, setMenu] = useState(false);
  const [idx, setIdx] = useState(INDEKS_24J);
  const [simpan, setSimpan] = useState(false);
  const [buffer, setBuffer] = useState(false); // video sedang menunggu data
  const [gagal, setGagal] = useState(0);        // 0 = normal, >0 = gagal (angka dipakai untuk muat ulang)
  const [ulang, setUlang] = useState(0);
  const [ubah, setUbah] = useState({}); // durasi yang baru diatur admin: { [id]: { expires_at, permanen } }
  const g = daftar[gi];
  const it = { ...g.items[ii], ...ubah[g.items[ii].id] };
  const diam = jeda || menu; // menu durasi terbuka = story berhenti sejenak
  const menuRef = useRef(false); menuRef.current = menu;

  // Muat lebih dulu foto story berikutnya supaya perpindahan tidak tersendat
  useEffect(() => {
    const next = g.items[ii + 1] || daftar[gi + 1]?.items[0];
    if (next?.media_type === "image") { const im = new Image(); im.src = next.media_url; return undefined; }
    // Video berikutnya: hanya ambil bagian awal (metadata) supaya siap cepat tanpa menghabiskan kuota
    if (next?.media_type === "video") {
      const v = document.createElement("video");
      v.preload = "metadata"; v.muted = true; v.src = next.media_url;
      return () => { v.removeAttribute("src"); v.load(); };
    }
    return undefined;
  }, [gi, ii]); // eslint-disable-line react-hooks/exhaustive-deps

  // Tombol kembali (HP / browser) hanya menutup story, bukan pindah ke halaman sebelumnya (misalnya Profil).
  // Caranya: saat story dibuka kita tambah satu entri riwayat; kembali = membuang entri itu.
  useEffect(() => {
    window.history.pushState({ ...window.history.state, story: true }, "");
    let lewatTombol = false;
    const pop = () => { lewatTombol = true; onClose(); };
    window.addEventListener("popstate", pop);
    return () => {
      window.removeEventListener("popstate", pop);
      // Ditutup lewat tombol X / selesai: buang entri tadi supaya riwayat kembali seperti semula
      if (!lewatTombol && window.history.state?.story) window.history.back();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const admin = isAdmin(user);
  const vid = useRef(null);
  const lewat = useRef(0);
  const tekan = useRef(null);
  const boleh = it.user_id === user?.id || admin;
  // Teks sisa waktu: saat menu durasi terbuka, ikut berubah mengikuti pilihan di slider (langsung, sebelum disimpan)
  const pilih = LANGKAH[idx];
  const infoHilang = menu
    ? (pilih.jam === 0 ? "permanen ∞" : `hilang ${pilih.teks.toLowerCase()} lagi`)
    : (it.permanen ? "permanen ∞" : `hilang ${sisaTeks(it)} lagi`);

  const maju = () => {
    if (ii < g.items.length - 1) setIi(ii + 1);
    else if (gi < daftar.length - 1) { setGi(gi + 1); setIi(0); }
    else onClose();
  };
  const mundur = () => {
    if (ii > 0) setIi(ii - 1);
    else if (gi > 0) { setGi(gi - 1); setIi(daftar[gi - 1].items.length - 1); }
    else { lewat.current = 0; setP(0); if (vid.current) vid.current.currentTime = 0; }
  };
  const majuRef = useRef(maju); majuRef.current = maju;
  const mundurRef = useRef(mundur); mundurRef.current = mundur;

  useEffect(() => { lewat.current = 0; setP(0); setYakin(false); setMenu(false); setBuffer(false); setGagal(0); setUlang(0); tandai(it.id); }, [it.id]); // eslint-disable-line react-hooks/exhaustive-deps

  // Foto: berjalan 6 detik, berhenti saat ditahan
  useEffect(() => {
    if (it.media_type !== "image" || diam) return undefined;
    let raf, last = performance.now();
    const loop = () => {
      const n = performance.now();
      lewat.current += n - last; last = n;
      const v = lewat.current / DURASI_FOTO;
      setP(Math.min(1, v));
      if (v >= 1) majuRef.current(); else raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [it.id, it.media_type, diam]);

  // Video: langsung diputar dengan suara (ketukan membuka story sudah mengizinkan). Jika browser tetap memblokir, putar tanpa suara.
  useEffect(() => {
    const v = vid.current;
    if (!v) return;
    v.muted = false;
    setBisu(false);
    v.play().catch(() => { v.muted = true; setBisu(true); v.play().catch(() => {}); });
  }, [it.id, ulang]);
  useEffect(() => { const v = vid.current; if (v) { if (diam) v.pause(); else if (v.paused) v.play().catch(() => {}); } }, [diam]);
  useEffect(() => { if (vid.current) vid.current.muted = bisu; }, [bisu]);
  // Layar penuh sungguhan (menyembunyikan bilah browser) bila didukung perangkat
  useEffect(() => {
    if (!document.fullscreenElement) document.documentElement.requestFullscreen?.().catch(() => {});
    return () => { if (document.fullscreenElement) document.exitFullscreen?.().catch(() => {}); };
  }, []);

  useEffect(() => {
    const k = (e) => { if (e.key === "Escape") { if (menuRef.current) setMenu(false); else onClose(); } else if (e.key === "ArrowRight") majuRef.current(); else if (e.key === "ArrowLeft") mundurRef.current(); };
    window.addEventListener("keydown", k);
    const o = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", k); document.body.style.overflow = o; };
  }, [onClose]);

  const turun = (e) => { tekan.current = { t: Date.now(), x: e.clientX, y: e.clientY }; setJeda(true); };
  const naik = (e) => {
    const s = tekan.current; tekan.current = null; setJeda(false);
    if (!s || Date.now() - s.t > 250 || Math.hypot(e.clientX - s.x, e.clientY - s.y) > 12) return;
    const r = e.currentTarget.getBoundingClientRect();
    (e.clientX - r.left < r.width * 0.33 ? mundur : maju)();
  };
  const batal = () => { tekan.current = null; setJeda(false); };

  const bukaMenu = () => { setIdx(indeksDari(waktuHilang(it) === null ? null : waktuHilang(it) - Date.now())); setMenu(true); };
  // Dipanggil begitu admin selesai memilih (jari dilepas): langsung disimpan ke server, popup menutup, tulisan hilang ikut berubah.
  const simpanDurasi = async (n = idx) => {
    if (simpan) return;
    const l = LANGKAH[n];
    setIdx(n);
    setSimpan(true);
    await new Promise((r) => setTimeout(r, 280)); // sebentar, supaya pilihan terakhir sempat terlihat
    const { error } = await aturDurasi(it.id, l.jam, l.jam === 0);
    setSimpan(false);
    if (error) return onToast(pesanError(error)); // gagal: popup tetap terbuka
    setUbah((o) => ({ ...o, [it.id]: { permanen: l.jam === 0, expires_at: l.jam === 0 ? null : new Date(Date.now() + l.jam * 3600000).toISOString() } }));
    setMenu(false);
    onToast(l.jam === 0 ? "Story jadi permanen ∞" : `Story akan hilang dalam ${l.teks.toLowerCase()}.`);
    onMuat?.();
  };

  const nav = "absolute top-1/2 z-10 hidden h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border-[3px] border-black bg-yellow-300 shadow-[3px_3px_0_#111] sm:flex";

  return (
    <div className="fixed inset-0 z-[90] bg-black" role="dialog" aria-modal="true" aria-label={`Story ${g.profil.nama || ""}`}>
      <div className="relative h-[100dvh] w-full">
        <button type="button" aria-label="Story sebelumnya" onClick={mundur} className={`${nav} left-4`}><ChevronLeft size={22} strokeWidth={3} /></button>
        <button type="button" aria-label="Story berikutnya" onClick={maju} className={`${nav} right-4`}><ChevronRight size={22} strokeWidth={3} /></button>

        <div className="relative h-full w-full overflow-hidden bg-black">
          <div className="absolute inset-0 touch-none select-none" onPointerDown={turun} onPointerUp={naik} onPointerCancel={batal} onPointerLeave={batal}>
            {it.media_type === "video" ? (
              gagal ? (
                <div className="flex h-full w-full flex-col items-center justify-center gap-3 px-6 text-center" onPointerDown={(e) => e.stopPropagation()} onPointerUp={(e) => e.stopPropagation()}>
                  <p className="font-body text-base font-bold text-white">Video gagal diputar. Periksa koneksi atau URL video.</p>
                  <button type="button" onClick={() => { setGagal(0); setUlang((n) => n + 1); }} className="btn bg-yellow-300 px-4 py-2 text-xl">COBA LAGI</button>
                </div>
              ) : (
                <video key={`${it.id}-${ulang}`} ref={vid} src={`${it.media_url}#t=0.001`} playsInline preload="auto" className="h-full w-full object-contain"
                  onWaiting={() => setBuffer(true)} onCanPlay={() => setBuffer(false)} onPlaying={() => setBuffer(false)}
                  onError={() => { setBuffer(false); setGagal(1); }}
                  onTimeUpdate={(e) => setP(e.currentTarget.duration ? e.currentTarget.currentTime / e.currentTarget.duration : 0)}
                  onEnded={() => majuRef.current()} />
              )
            ) : (
              <img key={it.id} src={it.media_url} alt={it.caption || "Story"} draggable={false} className="h-full w-full object-contain" />
            )}
          </div>

          {buffer && !gagal && it.media_type === "video" && (
            <div className="pointer-events-none absolute inset-0 z-[5] flex items-center justify-center" aria-label="Memuat video" role="status">
              <span className="h-12 w-12 animate-spin rounded-full border-4 border-white/30 border-t-yellow-300" />
            </div>
          )}

          <div className="pointer-events-none absolute inset-x-0 top-0 bg-gradient-to-b from-black/70 to-transparent px-3 pb-8 pt-[max(0.75rem,env(safe-area-inset-top))]">
           <div className="mx-auto max-w-[560px]">
            <div className="flex gap-1">
              {g.items.map((x, n) => (
                <div key={x.id} className="h-2 flex-1 border-2 border-black bg-white/30">
                  <div className="h-full bg-yellow-300" style={{ width: n < ii ? "100%" : n === ii ? `${p * 100}%` : "0%" }} />
                </div>
              ))}
            </div>
            <div className="mt-2.5 flex items-center gap-2">
              <Ava p={g.profil} size={38} />
              <div className="min-w-0 flex-1 leading-tight">
                <p className="truncate font-comic text-xl tracking-wide text-white" style={bayang}>{g.profil.nama || "Pengguna"}</p>
                <p className="font-body text-xs font-bold text-white/90" style={bayang}>{lalu(it.created_at)} · <span key={infoHilang} className="pop inline-block">{infoHilang}</span></p>
              </div>
              <div className="pointer-events-auto flex items-center gap-1.5">
                {it.media_type === "video" && (
                  <button type="button" onClick={() => setBisu((b) => !b)} aria-label={bisu ? "Nyalakan suara" : "Matikan suara"} className="btn flex bg-white p-1.5 !shadow-[2px_2px_0_#111]">
                    {bisu ? <VolumeX size={16} strokeWidth={2.75} /> : <Volume2 size={16} strokeWidth={2.75} />}
                  </button>
                )}
                {admin && (
                  <button type="button" onClick={bukaMenu} aria-label="Atur durasi story" aria-haspopup="dialog"
                    className={`btn flex items-center gap-1 p-1.5 !shadow-[2px_2px_0_#111] ${it.permanen ? "bg-pink-300" : "bg-sky-200"}`}>
                    {it.permanen ? <IkonTakHingga size={16} strokeWidth={3.25} /> : <Clock size={16} strokeWidth={2.75} />}
                  </button>
                )}
                {boleh && (
                  <button type="button" onClick={() => (yakin ? onHapus(it) : setYakin(true))} aria-label="Hapus story"
                    className={`btn flex items-center gap-1 p-1.5 !shadow-[2px_2px_0_#111] ${yakin ? "bg-red-400 px-2" : "bg-pink-200"}`}>
                    <Trash2 size={16} strokeWidth={2.75} />{yakin && <span className="text-sm">{teks.story_yakin}</span>}
                  </button>
                )}
                <button type="button" onClick={onClose} aria-label="Tutup" className="btn flex bg-white p-1.5 !shadow-[2px_2px_0_#111]"><X size={16} strokeWidth={3} /></button>
              </div>
            </div>
           </div>
          </div>

          {menu && (
            <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/45 p-4" onClick={() => !simpan && setMenu(false)}>
              <div role="dialog" aria-modal="true" aria-label="Atur durasi story" onClick={(e) => e.stopPropagation()}
                className="pop relative w-full max-w-sm border-4 border-black bg-white p-4 shadow-[6px_6px_0_#111]">
                <span className="absolute -top-3.5 left-4 -rotate-3 border-[3px] border-black bg-pink-300 px-2 py-0.5 font-comic text-sm tracking-wider">{teks.story_admin_badge}</span>
                <h3 className="flex items-center gap-2 font-comic text-2xl tracking-wide"><Clock size={22} strokeWidth={3} /> {teks.story_durasi_judul}</h3>
                <p className="font-body text-sm font-bold text-neutral-600">{teks.story_durasi_info}</p>
                <div className="mt-2"><DurasiGeser nilai={idx} onUbah={setIdx} onSelesai={simpanDurasi} disabled={simpan} /></div>
                <div className="mt-3 flex items-center gap-3">
                  <p className="flex-1 font-comic text-lg tracking-wide text-neutral-600" aria-live="polite">{simpan ? "MENERAPKAN..." : ""}</p>
                  <button type="button" onClick={() => setMenu(false)} disabled={simpan} className="btn bg-white px-4 py-2 text-xl disabled:opacity-50">{teks.story_tutup}</button>
                </div>
              </div>
            </div>
          )}

          {it.caption && (
            <p className="pointer-events-none absolute inset-x-4 bottom-[max(2rem,env(safe-area-inset-bottom))] mx-auto max-w-[480px] -rotate-1 border-[3px] border-black bg-yellow-300 px-3 py-2 text-center font-body text-base font-bold shadow-[4px_4px_0_#111]">
              {it.caption}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

// ---------- Form buat story ----------
function Tulis({ user, onClose, onSelesai, onToast }) {
  const { teks } = useContent();
  const [file, setFile] = useState(null);
  const [lihat, setLihat] = useState("");
  const [cap, setCap] = useState("");
  const [status, setStatus] = useState("");
  const [sibuk, setSibuk] = useState(false);
  const [idx, setIdx] = useState(INDEKS_24J);
  const input = useRef(null);
  const admin = isAdmin(user);
  const durasi = LANGKAH[idx];
  const video = file?.type.startsWith("video/");
  const ukuranMB = file ? file.size / 1048576 : 0;
  const kompres = file ? akanDikompres(file) : false;
  const batasMB = video ? OPSI_STORY.video.minMB : OPSI_STORY.gambar.minMB; // sampai segini diunggah apa adanya

  useEffect(() => () => { if (lihat) URL.revokeObjectURL(lihat); }, [lihat]);
  useEffect(() => {
    const k = (e) => e.key === "Escape" && !sibuk && onClose();
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [onClose, sibuk]);

  const pilih = async (e) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    if (!/^(image|video)\//.test(f.type)) return onToast(teks.story_toast_pilih_file);
    setFile(f);
    setLihat(URL.createObjectURL(f));
  };

  const kirim = async () => {
    if (!file || sibuk) return;
    setSibuk(true);
    let url = "";
    try {
      url = await unggah(file, user.id, STORY_MAKS_MB, setStatus, "stories", OPSI_STORY);
      setStatus("Menerbitkan story...");
      const { error } = await supabase.from("stories").insert({
        user_id: user.id, media_path: pathDariUrl(url, "stories"), media_url: url,
        media_type: video ? "video" : "image", caption: cap.trim(),
        // Hanya admin yang boleh memilih durasi; pilihan standar (24 jam) tidak perlu mengirim kolom tambahan
        ...(admin && idx !== INDEKS_24J ? (durasi.jam === 0 ? { permanen: true } : { expires_at: new Date(Date.now() + durasi.jam * 3600000).toISOString() }) : {}),
      });
      if (error) throw error;
      onToast(admin && durasi.jam === 0 ? teks.story_toast_permanen : teks.story_toast_terbit.replace("{waktu}", admin ? durasi.teks.toLowerCase() : "24 jam"));
      onSelesai();
    } catch (err) {
      if (url) hapusFile(url, "stories");
      onToast(pesanError(err));
      setSibuk(false);
      setStatus("");
    }
  };

  return (
    <div className="fixed inset-0 z-[85] flex items-center justify-center bg-black/55 p-4" role="dialog" aria-modal="true" aria-label="Buat story" onClick={() => !sibuk && onClose()}>
      <div className="pop panel relative max-h-full w-full max-w-sm overflow-y-auto p-5" style={{ transform: "none" }} onClick={(e) => e.stopPropagation()}>
        <span className="absolute -top-3.5 left-4 -rotate-3 border-[3px] border-black bg-pink-300 px-2 py-0.5 font-comic text-sm tracking-wider">{teks.story_badge_baru}</span>
        <h2 className="flex items-center gap-2 font-comic text-3xl tracking-wide"><Sparkles size={26} strokeWidth={2.5} /> {teks.story_baru_judul}</h2>
        <p className="font-body text-sm font-bold text-neutral-600">{teks.story_baru_info.replace("{video_mb}", OPSI_STORY.video.minMB).replace("{foto_mb}", OPSI_STORY.gambar.minMB)}{isAdmin(user) ? teks.story_info_admin : teks.story_info_user}</p>

        {file ? (
          <div className="mt-3 flex h-72 items-center justify-center border-4 border-black bg-black">
            {video ? <video src={lihat} controls muted playsInline className="max-h-full max-w-full" /> : <img src={lihat} alt="Pratinjau story" className="max-h-full max-w-full object-contain" />}
          </div>
        ) : (
          <button type="button" onClick={() => input.current?.click()}
            className="mt-3 flex h-44 w-full flex-col items-center justify-center gap-2 border-4 border-dashed border-black bg-yellow-100 font-comic text-xl tracking-wide transition-colors hover:bg-yellow-200">
            <span className="flex gap-3"><ImagePlus size={34} strokeWidth={2.5} /><Film size={34} strokeWidth={2.5} /></span>
            {teks.story_pilih}
          </button>
        )}
        {file && (
          <p className="mt-2 font-body text-sm font-bold text-neutral-600">
            {ukuranMB.toFixed(1)} MB · {kompres ? `lebih dari ${batasMB} MB, dikompres otomatis (tetap mulus, kualitas sedikit berkurang)` : `di bawah batas ${batasMB} MB, diunggah apa adanya tanpa kompres`}
          </p>
        )}
        <input ref={input} type="file" accept="image/*,video/*" onChange={pilih} className="hidden" />

        {admin && (
          <div className="mt-3 border-[3px] border-black bg-sky-50 pb-1 pt-2 shadow-[3px_3px_0_#111]">
            <p className="px-3 font-comic text-lg tracking-wide">{teks.story_durasi_tayang}</p>
            <DurasiGeser nilai={idx} onUbah={setIdx} disabled={sibuk} />
          </div>
        )}

        <label className="mt-3 block">
          <span className="font-comic text-lg tracking-wide">{teks.story_keterangan} <span className="font-body text-sm font-bold text-neutral-500">({cap.length}/140)</span></span>
          <input value={cap} maxLength={140} onChange={(e) => setCap(e.target.value)} placeholder={teks.story_placeholder}
            className="mt-1 w-full border-[3px] border-black bg-white px-3 py-2 font-body font-bold shadow-[3px_3px_0_#111] outline-none focus:bg-yellow-50" />
        </label>

        {status && <p className="mt-2 font-body text-sm font-bold text-neutral-700" role="status">{status}</p>}
        <div className="mt-4 flex flex-wrap gap-3">
          <button type="button" onClick={kirim} disabled={!file || sibuk} className="btn inline-flex items-center gap-2 bg-yellow-300 px-5 py-2 text-xl disabled:opacity-50"><Plus size={20} strokeWidth={3} /> {sibuk ? teks.story_mengunggah : teks.story_terbitkan}</button>
          {file && !sibuk && <button type="button" onClick={() => { setFile(null); setLihat(""); }} className="btn bg-sky-200 px-4 py-2 text-xl">{teks.story_ganti}</button>}
          <button type="button" onClick={onClose} disabled={sibuk} className="btn bg-white px-4 py-2 text-xl disabled:opacity-50">{teks.story_batal}</button>
        </div>
      </div>
    </div>
  );
}

// ---------- Baris story (dipasang di Beranda dan Obrolan) ----------
export default function StoryBar({ user, onLogin, onToast = () => {} }) {
  const { teks } = useContent();
  const { grup, siap, seen, muat, tandai } = useStories();
  const [lihat, setLihat] = useState(null);
  const [tulis, setTulis] = useState(false);

  const urut = useMemo(() => {
    const punyaku = (g) => (g.uid === user?.id ? 0 : 1);
    const baru = (g) => (g.items.some((i) => !seen.has(i.id)) ? 0 : 1);
    return [...grup].sort((a, b) => punyaku(a) - punyaku(b) || baru(a) - baru(b) || new Date(b.items.at(-1).created_at) - new Date(a.items.at(-1).created_at));
  }, [grup, seen, user?.id]);

  if (!supabase) return null;

  const tambah = () => { if (user) setTulis(true); else { onToast(teks.story_toast_masuk); onLogin?.(); } };
  const buka = (gi) => {
    const k = urut[gi].items.findIndex((i) => !seen.has(i.id));
    setLihat({ daftar: urut, gi, ii: Math.max(0, k) }); // lanjut dari story yang belum dilihat
  };
  const hapus = async (it) => {
    const { error } = await supabase.from("stories").delete().eq("id", it.id);
    if (error) return onToast(teks.story_toast_gagal_hapus);
    supabase.storage.from("stories").remove([it.media_path]);
    onToast(teks.story_toast_dihapus);
    setLihat(null);
    muat();
  };

  return (
    <section aria-label="Story">
      <div className="panel relative p-3 pt-5" style={{ transform: "none" }}>
        <span className="absolute -top-3.5 left-4 -rotate-2 border-[3px] border-black bg-pink-300 px-2 py-0.5 font-comic text-sm tracking-wider">{teks.story_badge_bar}</span>
        <div className="flex gap-4 overflow-x-auto px-1 pb-1 pt-1" style={{ scrollbarWidth: "none" }}>
          <button type="button" onClick={tambah} className="group flex w-[72px] shrink-0 flex-col items-center gap-1" aria-label="Buat story">
            <span className="flex h-[66px] w-[66px] items-center justify-center rounded-full border-[3px] border-dashed border-black bg-yellow-300 shadow-[3px_3px_0_#111] transition-transform group-hover:-translate-y-0.5 group-active:translate-y-0.5">
              <Plus size={30} strokeWidth={3.5} />
            </span>
            <span className="font-comic text-sm tracking-wide">{teks.story_tambah}</span>
          </button>

          {urut.map((g, n) => {
            const baru = g.items.some((i) => !seen.has(i.id));
            const aku = g.uid === user?.id;
            return (
              <button key={g.uid} type="button" onClick={() => buka(n)} className="group flex w-[72px] shrink-0 flex-col items-center gap-1" aria-label={`Lihat story ${g.profil.nama || ""}`}>
                <span className="rounded-full p-[3px] shadow-[3px_3px_0_#111] transition-transform group-hover:-translate-y-0.5 group-active:translate-y-0.5" style={baru ? CINCIN_BARU : CINCIN_LAMA}>
                  <span className="block rounded-full bg-white p-[2px]"><Ava p={g.profil} size={54} /></span>
                </span>
                <span className="w-full truncate text-center font-comic text-sm tracking-wide">{aku ? "KAMU" : (g.profil.nama || "Pengguna").toUpperCase()}</span>
              </button>
            );
          })}

          {siap && !urut.length && <p className="self-center pl-1 font-body text-sm font-bold text-neutral-500">{teks.story_kosong}</p>}
        </div>
      </div>

      {lihat && <Penonton {...lihat} user={user} onClose={() => setLihat(null)} onHapus={hapus} tandai={tandai} onToast={onToast} onMuat={muat} />}
      {tulis && <Tulis user={user} onClose={() => setTulis(false)} onSelesai={() => { setTulis(false); muat(); }} onToast={onToast} />}
    </section>
  );
}
