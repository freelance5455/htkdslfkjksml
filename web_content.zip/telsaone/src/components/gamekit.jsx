import { ArrowLeft, RotateCcw } from "lucide-react";

// Potongan tampilan kecil yang dipakai bersama oleh game-game baru (Minesweeper, 2048, Tic Tac Toe, Snake).
// Gayanya sama dengan Brick Breaker: kotak berbingkai hitam, bayangan keras, font komik.

export function Kotak({ label, bg = "bg-white", children }) {
  return (
    <div className={`min-w-0 border-[3px] border-black px-2 py-1 text-center shadow-[3px_3px_0_#111] ${bg}`}>
      <p className="truncate font-comic text-xs leading-none tracking-wider text-neutral-700">{label}</p>
      <p className="truncate font-comic text-2xl leading-tight tracking-wide">{children}</p>
    </div>
  );
}

export function TombolAtas({ onBack, onUlang, ulangLabel = "ULANG", children }) {
  return (
    <div className="mt-3 flex flex-wrap gap-2">
      <button onClick={onBack} className="btn inline-flex items-center gap-1 bg-white px-3 py-1 text-lg">
        <ArrowLeft size={18} strokeWidth={2.5} /> KEMBALI
      </button>
      {children}
      {onUlang && (
        <button onClick={onUlang} className="btn inline-flex items-center gap-1 bg-pink-200 px-3 py-1 text-lg">
          <RotateCcw size={18} strokeWidth={2.5} /> {ulangLabel}
        </button>
      )}
    </div>
  );
}

// Pilihan bersekat (segmented): opsi = [{ id, label }]
export function Pilihan({ opsi, nilai, onPilih, kecil = false }) {
  return (
    <div className="flex gap-2">
      {opsi.map((o) => (
        <button
          key={o.id}
          type="button"
          onClick={() => onPilih(o.id)}
          aria-pressed={nilai === o.id}
          className={`btn flex-1 px-2 ${kecil ? "py-0.5 text-base" : "py-1 text-lg"} ${nilai === o.id ? "bg-yellow-300" : "bg-white"}`}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

// Kartu di atas papan (menu / game over / jeda)
export function Overlay({ children, lebar = 280 }) {
  return (
    <div className="absolute inset-0 z-10 flex items-center justify-center bg-white/75 p-3">
      <div className="pop w-full border-4 border-black bg-white p-4 text-center shadow-[5px_5px_0_#111]" style={{ maxWidth: lebar }}>
        {children}
      </div>
    </div>
  );
}

export function InfoMasuk({ user, onLogin }) {
  if (user) return <p className="mt-1 font-body text-xs font-bold text-neutral-600">Skor terbaikmu otomatis masuk papan peringkat.</p>;
  return (
    <div className="mt-2 border-2 border-dashed border-black bg-sky-100 p-2">
      <p className="font-body text-xs font-bold text-neutral-700">Login dulu agar skormu masuk papan peringkat.</p>
      {onLogin && <button onClick={onLogin} className="btn mt-1 bg-pink-200 px-3 py-0.5 text-base">MASUK</button>}
    </div>
  );
}

export const bacaAngka = (kunci) => {
  try { return parseInt(localStorage.getItem(kunci), 10) || 0; } catch { return 0; }
};
export const simpanAngka = (kunci, n) => {
  try { localStorage.setItem(kunci, String(n)); } catch { /* storage diblokir */ }
};
