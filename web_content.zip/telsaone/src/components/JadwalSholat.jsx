import { useEffect, useMemo, useState } from "react";
import { ChevronDown } from "lucide-react";
import { useContent } from "../lib/content";
import { BULAN, HARI, deretWajib, jadwalHari, jamMenit, pad, wib } from "../lib/shalat";

const ITEM = [
  { id: "subuh", nama: "SUBUH" },
  { id: "terbit", nama: "TERBIT" },
  { id: "dzuhur", nama: "DZUHUR" },
  { id: "ashar", nama: "ASHAR" },
  { id: "maghrib", nama: "MAGHRIB" },
  { id: "isya", nama: "ISYA" },
];

// Hari Jumat: waktu Dzuhur disebut Jum'at
const namaWaktu = (id, ms) => (id === "dzuhur" && wib(ms).hari === 5 ? "JUM'AT" : ITEM.find((x) => x.id === id).nama);

// ringkas = tampilan kecil (dipakai saat game dimainkan) agar area permainan tidak terdorong jauh ke bawah
export default function JadwalSholat({ ringkas = false }) {
  const { teks } = useContent();
  const [now, setNow] = useState(() => Date.now());
  const [buka, setBuka] = useState(!ringkas);

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  const w = wib(now);
  const kunci = `${w.y}-${w.m}-${w.d}`;
  const hariIni = useMemo(() => jadwalHari(w.y, w.m, w.d), [kunci]);
  const deret = useMemo(() => deretWajib(w.y, w.m, w.d), [kunci]);

  const berikut = deret.find((e) => e.t > now);
  const sisa = Math.max(0, Math.floor((berikut.t - now) / 1000));
  const berikutHariIni = wib(berikut.t).d === w.d;

  return (
    <section aria-label={teks.shalat_judul} className="mt-5 border-[3px] border-black bg-white p-3 shadow-[4px_4px_0_#111] sm:p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-comic text-2xl leading-none tracking-wide sm:text-3xl">{teks.shalat_judul}</h2>
          <p className="mt-1 font-body text-xs font-bold text-neutral-600">{teks.shalat_wilayah}</p>
        </div>
        <div className="border-[3px] border-black bg-black px-3 py-1 text-right shadow-[3px_3px_0_#f9a8d4]">
          <p className="font-comic text-4xl leading-none tracking-widest text-yellow-300 tabular-nums sm:text-5xl">
            {pad(w.jam)}:{pad(w.menit)}:{pad(w.detik)}
          </p>
          <p className="mt-0.5 font-body text-xs font-bold leading-tight text-white sm:text-sm">
            {HARI[w.hari]}, {w.d} {BULAN[w.m - 1]} {w.y} · WIB
          </p>
        </div>
      </div>

      <div className="mt-3 flex items-center justify-between gap-3 border-[3px] border-black bg-yellow-200 px-3 py-2">
        <div className="min-w-0">
          <p className="font-body text-xs font-bold leading-tight text-neutral-700">{teks.shalat_berikut}</p>
          <p className="truncate font-comic text-2xl leading-tight tracking-wide">
            {namaWaktu(berikut.id, berikut.t)} {jamMenit(berikut.t)}
          </p>
        </div>
        <p className="shrink-0 font-comic text-3xl leading-none tracking-wider tabular-nums" role="timer" aria-label={`${teks.shalat_berikut} ${namaWaktu(berikut.id, berikut.t)}`}>
          {pad(Math.floor(sisa / 3600))}:{pad(Math.floor((sisa % 3600) / 60))}:{pad(sisa % 60)}
        </p>
      </div>

      {buka && (
        <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-6">
          {ITEM.map(({ id }) => {
            const t = hariIni[id];
            const aktif = berikutHariIni && berikut.id === id;
            return (
              <div key={id} className={`border-2 border-black px-1 py-1.5 text-center ${aktif ? "bg-yellow-300" : "bg-white"} ${now >= t ? "opacity-50" : ""}`}>
                <p className="font-body text-xs font-bold leading-tight">{namaWaktu(id, t)}</p>
                <p className="font-comic text-xl leading-tight tracking-wide tabular-nums">{jamMenit(t)}</p>
              </div>
            );
          })}
        </div>
      )}

      <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
        <p className="max-w-md font-body text-xs font-bold leading-snug text-neutral-500">{teks.shalat_catatan}</p>
        {ringkas && (
          <button type="button" onClick={() => setBuka((b) => !b)} aria-expanded={buka} className="btn inline-flex items-center gap-1 bg-white px-2 text-base leading-7">
            {teks.shalat_semua} <ChevronDown size={16} strokeWidth={3} className={`transition-transform ${buka ? "rotate-180" : ""}`} />
          </button>
        )}
      </div>
    </section>
  );
}
