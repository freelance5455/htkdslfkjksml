import { Link } from "react-router-dom";
import { NAV } from "../data";
import Avatar from "./Avatar";
import SplitText from "./SplitText";
import { useGoSection } from "../lib/nav";
import { isAdmin } from "../lib/admin";
import { useContent } from "../lib/content";

export default function Navbar({ active, user, onLogin, onRegister, onLogout }) {
  const go = useGoSection();
  const { teks } = useContent();
  const nama = user?.user_metadata?.full_name?.split(" ")[0] || "Profil";
  return (
    <header className="fixed inset-x-0 top-0 z-40 px-3" style={{ paddingTop: "env(safe-area-inset-top, 0px)" }}>
      <nav className="mx-auto mt-3 flex max-w-5xl items-center justify-between rounded-xl border-4 border-black bg-white px-4 py-2 shadow-[5px_5px_0_#111]">
        <a href="/" onClick={go("pengenalan")} className="flex items-center font-comic text-2xl leading-none tracking-wider" aria-label="telsaone">
          <SplitText
            tag="span"
            text="telsaone"
            className="logo-split"
            textAlign="left"
            effect="rise"
            splitType="chars"
            trigger="load"
            delay={90}
            duration={1.4}
            loop
            loopDelay={3.5}
          />
        </a>
        <ul className="hidden gap-1 md:flex">
          {NAV.map((n) => (
            <li key={n.id}>
              <a href={"/#" + n.id} onClick={go(n.id)}
                className={`rounded-md px-3 py-1 font-comic text-lg tracking-wide transition-all duration-300 ${active === n.id ? "-rotate-2 bg-yellow-300 shadow-[2px_2px_0_#111]" : "hover:bg-neutral-100"}`}>
                {teks["nav_" + n.id] || n.label}
              </a>
            </li>
          ))}
          <li>
            <Link to="/game"
              className={`rounded-md px-3 py-1 font-comic text-lg tracking-wide transition-all duration-300 ${active === "game" ? "-rotate-2 bg-yellow-300 shadow-[2px_2px_0_#111]" : "hover:bg-neutral-100"}`}>
              {teks.nav_game}
            </Link>
          </li>
          <li>
            <Link to="/chat"
              className={`rounded-md px-3 py-1 font-comic text-lg tracking-wide transition-all duration-300 ${active === "chat" ? "-rotate-2 bg-yellow-300 shadow-[2px_2px_0_#111]" : "hover:bg-neutral-100"}`}>
              {teks.nav_chat}
            </Link>
          </li>
          {isAdmin(user) && (
            <li>
              <Link to="/admin"
                className={`rounded-md px-3 py-1 font-comic text-lg tracking-wide transition-all duration-300 ${active === "admin" ? "-rotate-2 bg-yellow-300 shadow-[2px_2px_0_#111]" : "hover:bg-neutral-100"}`}>
                {teks.nav_admin}
              </Link>
            </li>
          )}
        </ul>
        {user ? (
          <div className="flex items-center gap-2">
            <Link to="/profil" className={`btn kilau flex items-center gap-2 bg-yellow-300 px-2 py-1 text-lg`}>
              <Avatar user={user} size={28} />
              <span className="hidden max-w-[7rem] truncate sm:inline">{nama}</span>
            </Link>
            <button onClick={onLogout} className="btn hidden bg-pink-200 px-3 py-1 text-lg sm:inline-block">{teks.nav_keluar}</button>
          </div>
        ) : (
          <div className="flex gap-2">
            <button onClick={onRegister} className="btn hidden bg-white px-3 py-1 text-lg sm:inline-block">{teks.nav_daftar}</button>
            <button onClick={onLogin} className="btn bg-yellow-300 px-4 py-1 text-lg">{teks.nav_masuk}</button>
          </div>
        )}
      </nav>
    </header>
  );
}
