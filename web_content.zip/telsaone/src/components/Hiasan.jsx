// Hiasan komik untuk Beranda: kilau, plus, cincin, zig-zag, selotip, pita berjalan.
// Semua dekoratif (aria-hidden), tidak bisa disentuh, dan animasinya pelan serta mati bila pengguna memilih "kurangi gerakan".
import { Camera, Gamepad2, Gift, MessageCircle, Music, Trophy } from "lucide-react";
import LogoLoop from "./LogoLoop";

const HITAM = "#111";

export function Kilau({ w = 28, warna = "#fde047", className = "", style }) {
  return (
    <svg viewBox="0 0 24 24" width={w} height={w} className={className} style={style} aria-hidden="true">
      <path d="M12 1.5C12.9 7.5 16.5 11.1 22.5 12C16.5 12.9 12.9 16.5 12 22.5C11.1 16.5 7.5 12.9 1.5 12C7.5 11.1 11.1 7.5 12 1.5Z"
        fill={warna} stroke={HITAM} strokeWidth="1.7" strokeLinejoin="round" />
    </svg>
  );
}
function Plus({ w = 24, warna = "#f9a8d4" }) {
  return (
    <svg viewBox="0 0 24 24" width={w} height={w} aria-hidden="true">
      <path d="M12 4v16M4 12h16" stroke={HITAM} strokeWidth="7" strokeLinecap="round" />
      <path d="M12 4v16M4 12h16" stroke={warna} strokeWidth="3.2" strokeLinecap="round" />
    </svg>
  );
}
function Cincin({ w = 26, warna = "#7dd3fc" }) {
  return (
    <svg viewBox="0 0 24 24" width={w} height={w} aria-hidden="true">
      <circle cx="12" cy="12" r="7.5" fill="none" stroke={HITAM} strokeWidth="6.5" />
      <circle cx="12" cy="12" r="7.5" fill="none" stroke={warna} strokeWidth="3" />
    </svg>
  );
}
function Zigzag({ w = 64 }) {
  return (
    <svg viewBox="0 0 60 16" width={w} height={(w * 16) / 60} aria-hidden="true">
      <polyline points="3,12 13,4 23,12 33,4 43,12 53,4" fill="none" stroke={HITAM} strokeWidth="3.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

// Lapisan latar selebar layar, di belakang isi bagian (bagian harus "relative isolate")
function Lapisan({ children }) {
  return (
    <div aria-hidden="true" className="pointer-events-none absolute inset-y-0 left-1/2 -z-10 w-screen -translate-x-1/2 overflow-hidden">
      {children}
    </div>
  );
}
// Satu hiasan: posisi (kelas Tailwind), jenis gerak, durasi, jeda, putaran awal
function Item({ pos, gerak = "melayang", t = 9, d = 0, r = 0, dx = 0, dy = -14, children }) {
  return (
    <span className={`absolute ${pos}`}>
      <span className={`block hias-${gerak}`} style={{ "--t": `${t}s`, "--d": `${d}s`, "--r": `${r}deg`, "--dx": `${dx}px`, "--dy": `${dy}px` }}>
        {children}
      </span>
    </span>
  );
}

export function HiasanHero() {
  return (
    <Lapisan>
      <div className="halftone halftone-pink absolute -left-16 top-6 h-56 w-56 md:h-72 md:w-72" />
      <div className="halftone halftone-sky absolute -right-10 bottom-8 h-60 w-60 md:h-72 md:w-72" />
      <Item pos="left-[6%] top-[13%]" gerak="kedip" t={2.6}><Kilau w={34} /></Item>
      <Item pos="left-[46%] top-[7%]" gerak="kedip" t={3.1} d={0.8}><Kilau w={20} warna="#f9a8d4" /></Item>
      <Item pos="right-[7%] top-[20%]" gerak="kedip" t={2.8} d={1.4}><Kilau w={28} warna="#7dd3fc" /></Item>
      <Item pos="left-[3%] top-[56%]" t={10} r={-10} dx={10}><Plus /></Item>
      <Item pos="right-[4%] top-[58%] hidden sm:block" t={11} d={1} dx={-8}><Cincin /></Item>
      <Item pos="left-[12%] bottom-[12%] hidden sm:block" t={12} r={-14} dy={-10} dx={14}><Zigzag /></Item>
      <Item pos="right-[28%] bottom-[7%]" gerak="kedip" t={3.4} d={0.4}><Kilau w={18} /></Item>
    </Lapisan>
  );
}

export function HiasanIsi() {
  return (
    <Lapisan>
      <div className="halftone halftone-sky absolute -left-20 top-24 h-64 w-64" />
      <div className="halftone halftone-pink absolute -right-16 top-[46%] h-72 w-72" />
      <Item pos="right-[8%] top-[5%]" gerak="kedip" t={2.7}><Kilau w={30} warna="#f9a8d4" /></Item>
      <Item pos="left-[4%] top-[34%] hidden sm:block" t={10} r={8} dx={8}><Plus warna="#fde047" /></Item>
      <Item pos="right-[5%] top-[28%] hidden sm:block" t={12} d={2} r={-8}><Zigzag w={56} /></Item>
      <Item pos="left-[7%] bottom-[10%]" gerak="kedip" t={3.2} d={1}><Kilau w={24} warna="#7dd3fc" /></Item>
      <Item pos="right-[9%] bottom-[6%] hidden sm:block" t={9} d={0.6}><Cincin warna="#fde047" w={24} /></Item>
    </Lapisan>
  );
}

export function HiasanPenutup() {
  return (
    <Lapisan>
      <div className="halftone halftone-pink absolute left-[8%] top-4 h-48 w-48" />
      <Item pos="left-[10%] top-[18%]" gerak="kedip" t={2.5}><Kilau w={32} /></Item>
      <Item pos="right-[10%] top-[12%]" gerak="kedip" t={3} d={0.9}><Kilau w={22} warna="#7dd3fc" /></Item>
      <Item pos="right-[7%] bottom-[20%]" t={11} r={10} dx={-8}><Plus warna="#86efac" /></Item>
      <Item pos="left-[6%] bottom-[16%] hidden sm:block" t={10} d={1.2} dx={10}><Cincin warna="#f9a8d4" /></Item>
      <Item pos="left-[44%] bottom-[3%]" gerak="kedip" t={3.3} d={0.5}><Kilau w={18} warna="#f9a8d4" /></Item>
    </Lapisan>
  );
}

// Cincin kecil yang mengorbit di sekitar bintang "YEAY!"
export function OrbitBintang() {
  return (
    <div className="orbit pointer-events-none absolute -inset-5" aria-hidden="true">
      <Kilau w={22} className="absolute left-1/2 top-0 -translate-x-1/2" />
      <span className="absolute bottom-3 left-2 h-3.5 w-3.5 rounded-full border-[3px] border-black bg-pink-300" />
      <span className="absolute right-0 top-1/2 h-4 w-4 -translate-y-1/2 rounded-full border-[3px] border-black bg-sky-300" />
      <Kilau w={16} warna="#7dd3fc" className="absolute bottom-0 right-8" />
    </div>
  );
}

// Selotip (washi tape) untuk menempel kotak
export function Selotip({ warna = "bg-pink-300", className = "" }) {
  return (
    <span aria-hidden="true" className={`pointer-events-none absolute z-10 h-6 w-20 border-2 border-dashed border-black/60 opacity-90 ${warna} ${className}`}
      style={{ backgroundImage: "repeating-linear-gradient(135deg, rgba(255,255,255,.4) 0 6px, transparent 6px 12px)" }} />
  );
}

// Stiker kecil bergaya komik untuk pita
const chip = (Ikon, teks, warna) => ({
  title: teks,
  node: (
    <span className="flex items-center gap-2.5 font-comic text-2xl tracking-widest">
      <span className={`flex h-10 w-10 items-center justify-center rounded-full border-[3px] border-black ${warna} shadow-[2px_2px_0_#111]`}><Ikon size={20} strokeWidth={2.75} /></span>
      {teks}
    </span>
  ),
});
const STIKER = [
  chip(Music, "MUSIK", "bg-pink-300"), chip(Gamepad2, "GAME", "bg-sky-300"), chip(Camera, "STORY", "bg-white"),
  chip(MessageCircle, "OBROLAN", "bg-green-300"), chip(Trophy, "PERINGKAT", "bg-pink-300"), chip(Gift, "DANA KAGET", "bg-sky-300"),
];

// Pita di antara bagian awal dan isi: stiker berjalan bergelombang, bisa digeser/dilempar
export function Pita() {
  return (
    <div className="overflow-hidden py-5">
      <div className="-mx-4 -rotate-1 border-y-4 border-black bg-yellow-300 shadow-[0_5px_0_#111]">
        <LogoLoop logos={STIKER} speed={60} logoHeight={40} gap={44} layout="wave" bend={0.5} scaleOnHover hoverSpeed={15}
          fadeOutWidth={0.08} ariaLabel="Fitur telsaone" />
      </div>
    </div>
  );
}
