import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { ChevronDown, GripHorizontal, Music, Pause, Play, SkipBack, SkipForward, Star } from "lucide-react";
import { useLocation } from "react-router-dom";
import { useMusic } from "../lib/music";

const POS_KEY = "hk_mini_pos";
const bacaPos = () => {
  try { const p = JSON.parse(localStorage.getItem(POS_KEY)); return p && Number.isFinite(p.x) && Number.isFinite(p.y) ? p : null; } catch { return null; }
};
const IDLE_MS = 5000; // diam selama ini (tanpa disentuh) -> mengecil jadi ikon musik
const fmt = (s) => (!s || isNaN(s) ? "0:00" : `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`);
const titik = { backgroundImage: "radial-gradient(rgba(17,17,17,.16) 1.2px, transparent 1.2px)", backgroundSize: "9px 9px" };
const garis = { backgroundImage: "repeating-linear-gradient(-45deg, #ef4444 0 6px, #f87171 6px 12px)" };

// Batang equalizer kecil yang bergerak saat lagu diputar
function Eq({ on, warna = "bg-red-500" }) {
  return (
    <span className="flex h-3.5 items-end gap-[2px]" aria-hidden="true">
      {[0, 0.25, 0.1, 0.35].map((d, n) => (
        <i key={n} className={`block w-[3px] origin-bottom ${warna}`}
          style={{ height: "100%", transform: on ? undefined : "scaleY(.3)", animation: on ? `hk-eq 0.9s ease-in-out ${d}s infinite` : "none" }} />
      ))}
    </span>
  );
}

function Piringan({ playing }) {
  return (
    <div className="relative flex h-14 w-14 shrink-0 items-center justify-center rounded-full border-[3px] border-black bg-neutral-900 shadow-[3px_3px_0_#111]"
      style={{ animation: playing ? "spin 4s linear infinite" : "none" }}>
      <div className="absolute inset-1.5 rounded-full border border-neutral-600" />
      <div className="absolute inset-3 rounded-full border border-neutral-700" />
      <div className="flex h-6 w-6 items-center justify-center rounded-full border-[3px] border-black bg-pink-300"><Music size={11} strokeWidth={3} /></div>
    </div>
  );
}

// Pemutar mini di halaman selain beranda. Secara bawaan hanya ikon musik kecil supaya tidak
// mengganggu; ketuk untuk membuka kontrol penuh, otomatis mengecil lagi bila tidak disentuh.
export default function MiniPlayer() {
  const { pathname } = useLocation();
  const { cur, playing, time, dur, toggle, go, seek } = useMusic();
  const [buka, setBuka] = useState(false);
  const [sentuhan, setSentuhan] = useState(0);
  const [aktif, setAktif] = useState(false); // pernah diputar & belum lewat 5 detik sejak berhenti
  const tampil = playing || aktif;

  // Posisi bebas: pemain bisa menggeser pemutar ke mana saja (disimpan di perangkat)
  const [pos, setPos] = useState(bacaPos);
  const kotak = useRef(null);
  const geser = useRef(null);
  const barusGeser = useRef(false);
  const jepit = (x, y) => {
    const el = kotak.current;
    const w = el?.offsetWidth || 44, h = el?.offsetHeight || 44;
    return { x: Math.round(Math.min(Math.max(4, x), window.innerWidth - w - 4)), y: Math.round(Math.min(Math.max(4, y), window.innerHeight - h - 4)) };
  };
  const mulaiGeser = (e) => {
    if (e.pointerType === "mouse" && e.button !== 0) return;
    const r = kotak.current.getBoundingClientRect();
    geser.current = { sx: e.clientX, sy: e.clientY, ox: r.left, oy: r.top, pindah: false };
    e.currentTarget.setPointerCapture?.(e.pointerId);
  };
  const gerak = (e) => {
    const g = geser.current;
    if (!g) return;
    const dx = e.clientX - g.sx, dy = e.clientY - g.sy;
    if (!g.pindah && Math.hypot(dx, dy) < 6) return;
    g.pindah = true;
    setPos(jepit(g.ox + dx, g.oy + dy));
    setSentuhan((n) => n + 1);
  };
  const selesaiGeser = () => {
    const g = geser.current;
    geser.current = null;
    if (!g?.pindah) return;
    barusGeser.current = true; // cegah "klik" ikut terbaca setelah menggeser
    setTimeout(() => { barusGeser.current = false; }, 80);
    const r = kotak.current?.getBoundingClientRect();
    if (r) try { localStorage.setItem(POS_KEY, JSON.stringify({ x: Math.round(r.left), y: Math.round(r.top) })); } catch { /* diblokir */ }
  };
  const gaya = pos ? { left: pos.x, top: pos.y, right: "auto", bottom: "auto" } : {};
  const awal = pos ? "" : "bottom-24 right-3";

  useLayoutEffect(() => { // ukuran berubah (ikon <-> kartu): pastikan tetap di dalam layar
    if (!pos || !kotak.current) return;
    const c = jepit(pos.x, pos.y);
    if (c.x !== pos.x || c.y !== pos.y) setPos(c);
  }, [buka]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    const f = () => setPos((p) => (p ? jepit(p.x, p.y) : p));
    window.addEventListener("resize", f);
    return () => window.removeEventListener("resize", f);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { setBuka(false); }, [pathname]);
  // Musik berhenti (dijeda / diganti murotal) -> 5 detik kemudian pop up hilang. Diputar lagi -> muncul lagi.
  useEffect(() => {
    if (playing) { setAktif(true); return undefined; }
    if (!aktif) return undefined;
    const t = setTimeout(() => { setAktif(false); setBuka(false); }, IDLE_MS);
    return () => clearTimeout(t);
  }, [playing, aktif, sentuhan]);
  useEffect(() => {
    if (!buka) return;
    const t = setTimeout(() => setBuka(false), IDLE_MS);
    return () => clearTimeout(t);
  }, [buka, sentuhan]);

  if (pathname === "/" || !cur?.src || !tampil) return null;

  const sentuh = () => setSentuhan((n) => n + 1); // setiap sentuhan menunda pengecilan

  if (!buka) {
    return (
      <button ref={kotak} onClick={() => { if (!barusGeser.current) setBuka(true); }} aria-label={`Buka pemutar: ${cur.title}. Tahan lalu geser untuk memindahkan`}
        onPointerDown={mulaiGeser} onPointerMove={gerak} onPointerUp={selesaiGeser} onPointerCancel={selesaiGeser}
        className={`btn fixed ${awal} z-40 flex h-11 w-11 touch-none items-center justify-center rounded-2xl bg-yellow-300 !shadow-[3px_3px_0_#111]`}
        style={{ ...gaya, animation: "hk-pop .25s ease-out" }}>
        <Music size={20} strokeWidth={2.75} style={{ animation: playing ? "hk-bob 1.2s ease-in-out infinite" : "none" }} />
        {playing && <span className="absolute -right-2 -top-2.5 flex rotate-6 rounded-md border-2 border-black bg-pink-300 px-[4px] py-[3px]"><Eq on warna="bg-black" /></span>}
      </button>
    );
  }

  return (
    <div ref={kotak} onPointerDown={sentuh} style={{ ...gaya, animation: "hk-pop .2s ease-out" }}
      className={`fixed ${awal} z-40 w-[17.5rem] max-w-[calc(100vw-1.5rem)] border-4 border-black bg-white shadow-[6px_6px_0_#111]`}>
      <span className="pointer-events-none absolute -top-3.5 left-3 z-10 -rotate-3 border-[3px] border-black bg-pink-300 px-2 py-0.5 font-comic text-xs tracking-wider">
        {playing ? "SEDANG DIPUTAR!" : "DIJEDA"}
      </span>
      <Star size={26} strokeWidth={2.5} fill="#fde047" className="float absolute -right-3.5 -top-4 z-10 rotate-12" aria-hidden="true" />

      <div onPointerDown={mulaiGeser} onPointerMove={gerak} onPointerUp={selesaiGeser} onPointerCancel={selesaiGeser}
        className="relative flex cursor-grab touch-none items-center gap-3 border-b-[3px] border-black bg-yellow-200 p-3 pt-5 active:cursor-grabbing" style={titik} title="Geser untuk memindahkan">
        <GripHorizontal size={16} strokeWidth={3} className="pointer-events-none absolute left-1/2 top-1 -translate-x-1/2 text-black/40" aria-hidden="true" />
        <Piringan playing={playing} />
        <div className="min-w-0 flex-1">
          <p className="truncate font-comic text-xl leading-tight tracking-wide">{cur.title}</p>
          <div className="flex items-center gap-1.5">
            <Eq on={playing} />
            <p className="truncate font-body text-xs font-bold text-neutral-700">{cur.artist || "Musik telsaone"}</p>
          </div>
        </div>
        <button onClick={() => setBuka(false)} onPointerDown={(e) => e.stopPropagation()} aria-label="Kecilkan pemutar"
          className="btn flex shrink-0 items-center justify-center self-start bg-white p-1 !shadow-[2px_2px_0_#111]"><ChevronDown size={16} strokeWidth={3} /></button>
      </div>

      <div className="flex items-center gap-2 px-3 pt-3 font-body text-[11px] font-bold">
        <span className="w-8 tabular-nums">{fmt(time)}</span>
        <div role="slider" aria-label="Posisi lagu" aria-valuemin={0} aria-valuemax={Math.floor(dur || 0)} aria-valuenow={Math.floor(time || 0)}
          className="h-3.5 flex-1 cursor-pointer touch-none border-[3px] border-black bg-white"
          onPointerDown={(e) => {
            if (!dur) return;
            const r = e.currentTarget.getBoundingClientRect();
            seek(Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * dur);
          }}>
          <div className="h-full" style={{ ...garis, width: `${dur ? Math.min(100, (time / dur) * 100) : 0}%` }} />
        </div>
        <span className="w-8 text-right tabular-nums">{fmt(dur)}</span>
      </div>

      <div className="flex items-center justify-center gap-3 p-3">
        <button onClick={() => go(-1)} aria-label="Sebelumnya" className="btn flex items-center justify-center bg-sky-200 p-2 !shadow-[3px_3px_0_#111]"><SkipBack size={16} fill="currentColor" /></button>
        <button onClick={toggle} aria-label={playing ? "Jeda" : "Putar"} className="btn flex items-center justify-center bg-yellow-300 px-6 py-2 !shadow-[3px_3px_0_#111]">
          {playing ? <Pause size={22} fill="currentColor" /> : <Play size={22} fill="currentColor" />}
        </button>
        <button onClick={() => go(1)} aria-label="Berikutnya" className="btn flex items-center justify-center bg-pink-200 p-2 !shadow-[3px_3px_0_#111]"><SkipForward size={16} fill="currentColor" /></button>
      </div>
    </div>
  );
}
