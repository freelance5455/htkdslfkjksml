import { useCallback, useEffect, useRef, useState } from "react";
import { useContent } from "../lib/content";
import { supabase } from "../lib/supabase";
import { ArrowLeft, BrickWall, Heart, Pause, Play, RotateCcw, Trophy } from "lucide-react";
import { BS, COLS, H, P, PALET, POWER, ROWS, TOP, W, launch, makeGame, movePaddle, update } from "../lib/brickEngine";

const KEY_HI = "telsaone:brick:hi";
const FONT = "Bangers, Impact, sans-serif";

const loadHi = () => {
  try { return parseInt(localStorage.getItem(KEY_HI), 10) || 0; } catch { return 0; }
};
const keyLv = (uid) => `telsaone:brick:lv:${uid || "tamu"}`;
const loadLv = (uid) => {
  try { return Math.max(1, parseInt(localStorage.getItem(keyLv(uid)), 10) || 1); } catch { return 1; }
};
const persistLv = (uid, n) => {
  try { localStorage.setItem(keyLv(uid), String(n)); } catch { /* diblokir */ }
};
const persistHi = (n) => {
  try { localStorage.setItem(KEY_HI, String(n)); } catch { /* storage penuh / diblokir */ }
};

// ---------- Gambar (Canvas) ----------
const IKON = {};
const ikon = (k, d) => (IKON[k] ||= new Path2D(d));
const NAMA_FX = { chain: "C", fire: "F", blast: "X", laser: "L", wide: "W", slow: "S" };

function render(cv, g, ready) {
  const ctx = cv.getContext("2d");
  if (!ctx) return;
  const s = cv.width / W;
  ctx.setTransform(s, 0, 0, s, 0, 0);
  ctx.clearRect(0, 0, W, H);
  ctx.fillStyle = "#7a2f9e";
  ctx.fillRect(2, 14, W - 4, 3); // garis atas

  let last = "";
  for (let r = 0; r < ROWS; r++) {
    const row = g.grid[r];
    for (let c = 0; c < COLS; c++) {
      const v = row[c];
      if (!v) continue;
      if (v !== last) { ctx.fillStyle = PALET[v]; last = v; }
      ctx.fillRect(c * P, TOP + r * P, BS, BS);
    }
  }

  for (const q of g.particles) {
    ctx.globalAlpha = Math.max(0, q.life / q.max);
    ctx.fillStyle = q.color;
    ctx.fillRect(q.x, q.y, q.s, q.s);
  }
  ctx.globalAlpha = 1;

  ctx.fillStyle = "#b8ff3c";
  for (const t of g.shots) ctx.fillRect(t.x - 0.8, t.y, 1.6, 8);

  // Power-up jatuh: bola cahaya kecil berikon, berdenyut dan berekor
  for (const w of g.powers) {
    const R = 8.5 + Math.sin(g.t * 7 + w.x) * 0.7;
    for (let i = 1; i <= 3; i++) {
      ctx.globalAlpha = 0.28 - i * 0.07;
      ctx.fillStyle = w.def.c;
      ctx.beginPath(); ctx.arc(w.x, w.y - i * 5, R * (1 - i * 0.18), 0, 6.2832); ctx.fill();
    }
    ctx.globalAlpha = 1;
    ctx.shadowColor = w.def.c; ctx.shadowBlur = 14;
    const gr = ctx.createRadialGradient(w.x - 2.5, w.y - 3, 1, w.x, w.y, R);
    gr.addColorStop(0, "#fff"); gr.addColorStop(0.45, w.def.c); gr.addColorStop(1, "rgba(30,0,60,.9)");
    ctx.fillStyle = w.def.c;
    ctx.beginPath(); ctx.arc(w.x, w.y, R, 0, 6.2832); ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = gr;
    ctx.beginPath(); ctx.arc(w.x, w.y, R, 0, 6.2832); ctx.fill();
    ctx.lineWidth = 1.3; ctx.strokeStyle = "#fff";
    ctx.beginPath(); ctx.arc(w.x, w.y, R, 0, 6.2832); ctx.stroke();
    ctx.save();
    ctx.translate(w.x - 6.5, w.y - 6.5);
    ctx.scale(13 / 24, 13 / 24);
    ctx.fillStyle = "#26094d";
    ctx.fill(ikon(w.def.k, w.def.d));
    ctx.restore();
    const a = g.t * 4 + w.x; // kilau berputar
    ctx.fillStyle = "#fff";
    ctx.beginPath(); ctx.arc(w.x + Math.cos(a) * (R + 3), w.y + Math.sin(a) * (R + 3), 1.1, 0, 6.2832); ctx.fill();
  }

  const p = g.paddle;
  ctx.fillStyle = g.fx.laser > 0 ? "#b8ff3c" : "#ff7a45";
  ctx.beginPath(); ctx.roundRect(p.x, p.y, p.w, p.h, 2); ctx.fill();

  const fire = g.fx.fire > 0;
  ctx.shadowColor = fire ? "#ff9f1c" : "#fff"; ctx.shadowBlur = fire ? 10 : 5;
  ctx.fillStyle = fire ? "#ffd166" : "#fff";
  for (const b of g.balls) { ctx.beginPath(); ctx.arc(b.x, b.y, 2.6, 0, 6.2832); ctx.fill(); }
  ctx.shadowBlur = 0;

  // Skill aktif (pojok bawah)
  let x = 8;
  ctx.font = `10px ${FONT}`;
  for (const k in NAMA_FX) {
    if (g.fx[k] <= 0) continue;
    const def = POWER.find((q) => q.k === k);
    ctx.fillStyle = def.c;
    ctx.fillText(`${NAMA_FX[k]} ${Math.ceil(g.fx[k])}`, x + 12, H - 8);
    x += 34;
  }

  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  if (g.banner > 0 && ready) {
    ctx.globalAlpha = Math.min(1, g.banner * 2);
    ctx.font = `44px ${FONT}`;
    ctx.fillStyle = "#fff";
    ctx.fillText(g.bannerText, W / 2, H * 0.6);
    ctx.globalAlpha = 1;
  }
  if (g.phase === "ready" && ready) {
    ctx.font = `16px ${FONT}`;
    ctx.fillStyle = "#e9d5ff";
    ctx.fillText("TAP / SPASI UNTUK LUNCURKAN", W / 2, H * 0.72);
  }
}

// ---------- UI ----------
function Kotak({ label, bg, children }) {
  return (
    <div className={`border-[3px] border-black px-1.5 py-1 text-center shadow-[3px_3px_0_#111] ${bg}`}>
      <div className="font-comic text-xs leading-none tracking-widest">{label}</div>
      <div className="flex h-7 items-center justify-center font-comic text-xl leading-none tracking-wide">{children}</div>
    </div>
  );
}

const LEGENDA = [...POWER.map((q) => ({ c: q.c, t: q.t, d: q.d })), { c: PALET[9], t: "Abu-abu: kebal" }];

export default function BrickBreaker({ onBack, user, onLogin, onSelesai }) {
  const { teks } = useContent();
  const cvRef = useRef(null);
  const gRef = useRef(null);
  if (!gRef.current) gRef.current = makeGame(loadLv(user?.id));
  const [screen, setScreen] = useState("menu"); // menu | play | pause | over
  const [hud, setHud] = useState({ score: 0, lives: 3, level: gRef.current.level });
  const [hi, setHi] = useState(loadHi);
  const [baru, setBaru] = useState(false);
  const screenRef = useRef(screen);
  screenRef.current = screen;
  const hiRef = useRef(hi);
  const hudRef = useRef(hud);
  const drag = useRef(null);
  const userRef = useRef(user);
  userRef.current = user;
  // Level terjauh yang boleh dimainkan: main lagi = lanjut dari sana, bukan dari level 1
  const lvRef = useRef(loadLv(user?.id));
  const [startLv, setStartLv] = useState(gRef.current.level);
  const setLevelMulai = useCallback((n) => {
    if (n <= lvRef.current) return;
    lvRef.current = n;
    persistLv(userRef.current?.id, n);
    setStartLv(n);
  }, []);
  const laporRef = useRef(onSelesai);
  laporRef.current = onSelesai;

  // Laporkan skor ke papan peringkat (sekali per permainan)
  const lapor = useCallback(() => {
    const g = gRef.current;
    if (g.reported || g.score <= 0) return;
    g.reported = true;
    laporRef.current?.({ score: g.score, level: g.level });
  }, []);

  // Level selesai: lapor ke server (hadiah Dana Kaget), lalu minta pop-up hadiah dimuat
  const klaimLevel = useCallback((lv) => {
    if (!supabase || !userRef.current) return;
    supabase.rpc("selesai_level", { p_game: "brick", p_level: lv }).then(({ error }) => {
      if (!error) window.dispatchEvent(new Event("hadiah:muat"));
    });
  }, []);

  const draw = useCallback(() => {
    const cv = cvRef.current;
    if (cv) render(cv, gRef.current, screenRef.current === "play");
  }, []);

  const syncHud = useCallback((g) => {
    const h = hudRef.current;
    if (h.score !== g.score || h.lives !== g.lives || h.level !== g.level) {
      hudRef.current = { score: g.score, lives: g.lives, level: g.level };
      setHud(hudRef.current);
    }
  }, []);

  const simpanHi = useCallback((skor) => {
    if (skor > hiRef.current) {
      hiRef.current = skor;
      persistHi(skor);
      setHi(skor);
      return true;
    }
    return false;
  }, []);

  const gameBaru = useCallback((lv) => {
    gRef.current = makeGame(lv ?? lvRef.current);
    syncHud(gRef.current);
  }, [syncHud]);

  const mulai = (lv) => {
    lapor();
    simpanHi(gRef.current.score);
    gameBaru(typeof lv === "number" ? lv : undefined);
    setBaru(false);
    setScreen("play");
  };
  const keMenu = () => {
    lapor();
    simpanHi(gRef.current.score);
    gameBaru();
    setBaru(false);
    setScreen("menu");
  };
  // Saat akun berganti / dibuka: muat level terakhir (lokal + server agar ikut di perangkat lain)
  useEffect(() => {
    const uid = user?.id;
    let batal = false;
    const lokal = loadLv(uid);
    lvRef.current = lokal;
    setStartLv(lokal);
    if (screenRef.current === "menu") { gRef.current = makeGame(lokal); syncHud(gRef.current); draw(); }
    if (supabase && uid) {
      supabase.rpc("level_saya", { p_game: "brick" }).then(({ data, error }) => {
        if (batal || error || !Number.isInteger(data) || data <= lvRef.current) return;
        setLevelMulai(data);
        if (screenRef.current === "menu") { gRef.current = makeGame(data); syncHud(gRef.current); draw(); }
      });
    }
    return () => { batal = true; };
  }, [user?.id, syncHud, draw, setLevelMulai]);

  const jeda = useCallback(() => setScreen((s) => (s === "play" ? "pause" : s === "pause" ? "play" : s)), []);

  // Loop animasi: hanya berjalan saat layar "play"; berhenti saat jeda, menu, game over, atau komponen dilepas
  useEffect(() => {
    gRef.current.keys.l = gRef.current.keys.r = false;
    if (screen !== "play") {
      draw();
      return undefined;
    }
    let raf = 0;
    let last = performance.now();
    const frame = (now) => {
      const g = gRef.current;
      const dt = Math.min(0.05, Math.max(0, (now - last) / 1000));
      last = now;
      update(g, dt);
      if (g.cleared) { const lv = g.cleared; g.cleared = 0; klaimLevel(lv); setLevelMulai(lv + 1); }
      draw();
      syncHud(g);
      if (g.dead) {
        setBaru(simpanHi(g.score));
        lapor();
        setScreen("over");
        return;
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }, [screen, draw, syncHud, simpanHi, lapor, klaimLevel, setLevelMulai]);

  // Sesuaikan resolusi canvas dengan ukuran tampil (maks 2x agar HP lemah tetap ringan)
  useEffect(() => {
    const cv = cvRef.current;
    if (!cv) return undefined;
    const fit = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = Math.max(200, Math.round(cv.clientWidth * dpr));
      const h = Math.round((w * H) / W);
      if (cv.width !== w || cv.height !== h) {
        cv.width = w;
        cv.height = h;
      }
      draw();
    };
    fit();
    let ro;
    if (typeof ResizeObserver !== "undefined") {
      ro = new ResizeObserver(fit);
      ro.observe(cv);
    } else window.addEventListener("resize", fit);
    return () => {
      ro?.disconnect();
      window.removeEventListener("resize", fit);
    };
  }, [draw]);

  // Keyboard + otomatis jeda saat tab disembunyikan
  useEffect(() => {
    const typing = (e) => /^(INPUT|TEXTAREA|SELECT)$/.test(e.target?.tagName || "");
    const down = (e) => {
      if (typing(e) || e.ctrlKey || e.metaKey || e.altKey) return;
      const sc = screenRef.current;
      const g = gRef.current;
      const k = e.key;
      if (sc === "play") {
        if (k === "ArrowLeft" || k === "a" || k === "A") { g.keys.l = true; e.preventDefault(); }
        else if (k === "ArrowRight" || k === "d" || k === "D") { g.keys.r = true; e.preventDefault(); }
        else if (k === " " || k === "ArrowUp") { launch(g); e.preventDefault(); }
      }
      if ((k === "p" || k === "P" || k === "Escape") && (sc === "play" || sc === "pause")) { setScreen(sc === "play" ? "pause" : "play"); e.preventDefault(); }
    };
    const up = (e) => {
      const g = gRef.current;
      if (e.key === "ArrowLeft" || e.key === "a" || e.key === "A") g.keys.l = false;
      if (e.key === "ArrowRight" || e.key === "d" || e.key === "D") g.keys.r = false;
    };
    const vis = () => { if (document.hidden && screenRef.current === "play") setScreen("pause"); };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    document.addEventListener("visibilitychange", vis);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      document.removeEventListener("visibilitychange", vis);
      persistHi(Math.max(hiRef.current, gRef.current.score)); // simpan rekor saat pindah halaman
      lapor(); // skor yang sedang berjalan tetap tercatat
    };
  }, [lapor]);

  // Sentuhan / mouse
  const toX = (e) => {
    const r = cvRef.current.getBoundingClientRect();
    return (e.clientX - r.left) * (W / r.width);
  };
  const onDown = (e) => {
    if (screenRef.current !== "play") return;
    const g = gRef.current;
    cvRef.current.setPointerCapture?.(e.pointerId);
    drag.current = { x0: e.clientX, y0: e.clientY, off: g.paddle.x - toX(e), moved: false };
    if (e.pointerType === "mouse") movePaddle(g, toX(e) - g.paddle.w / 2);
  };
  const onMove = (e) => {
    if (screenRef.current !== "play") return;
    const g = gRef.current;
    if (e.pointerType === "mouse") {
      movePaddle(g, toX(e) - g.paddle.w / 2); // mouse: paddle mengikuti kursor tanpa perlu klik
      if (drag.current && Math.hypot(e.clientX - drag.current.x0, e.clientY - drag.current.y0) > 10) drag.current.moved = true;
    } else if (drag.current) {
      if (Math.hypot(e.clientX - drag.current.x0, e.clientY - drag.current.y0) > 10) drag.current.moved = true;
      movePaddle(g, toX(e) + drag.current.off); // sentuhan: geser relatif, paddle tidak tertutup jari
    }
  };
  const onUp = () => {
    const d = drag.current;
    drag.current = null;
    if (d && !d.moved && screenRef.current === "play") launch(gRef.current); // tap = luncurkan bola
  };

  const aktif = screen === "play" || screen === "pause";
  const rekor = Math.max(hi, hud.score);

  return (
    <div className="brick-wrap mx-auto">
      {/* Panel skor ala kotak komik */}
      <div className="grid grid-cols-4 gap-2">
        <Kotak label={teks.bb_skor} bg="bg-yellow-300">{hud.score}</Kotak>
        <Kotak label={teks.bb_rekor_kotak} bg="bg-sky-200">{rekor}</Kotak>
        <Kotak label={teks.bb_nyawa} bg="bg-pink-200">
          <span className="flex gap-0.5">
            {[0, 1, 2].map((i) => (
              <Heart key={i} size={17} strokeWidth={2.5} fill={i < hud.lives ? "#f43f5e" : "none"} />
            ))}
          </span>
        </Kotak>
        <Kotak label={teks.bb_level} bg="bg-green-200">{hud.level}</Kotak>
      </div>

      <div className="mt-3 flex flex-wrap gap-2">
        <button onClick={() => { lapor(); onBack?.(); }} className="btn inline-flex items-center gap-1 bg-white px-3 py-1 text-lg">
          <ArrowLeft size={18} strokeWidth={2.5} /> {teks.bb_kembali}
        </button>
        <button onClick={jeda} disabled={!aktif} className="btn inline-flex items-center gap-1 bg-sky-200 px-3 py-1 text-lg disabled:opacity-50">
          {screen === "pause" ? <Play size={18} strokeWidth={2.5} /> : <Pause size={18} strokeWidth={2.5} />}
          {screen === "pause" ? teks.bb_lanjut : teks.bb_jeda}
        </button>
        <button onClick={mulai} disabled={screen === "menu"} className="btn inline-flex items-center gap-1 bg-pink-200 px-3 py-1 text-lg disabled:opacity-50">
          <RotateCcw size={18} strokeWidth={2.5} /> {teks.bb_ulang}
        </button>
      </div>

      {/* Papan permainan */}
      <div
        className="relative mt-4 border-4 border-black shadow-[6px_6px_0_#111]"
        style={{ backgroundColor: "#1c0540" }}
      >
        <canvas
          ref={cvRef}
          width={W}
          height={H}
          className="block w-full select-none"
          style={{ aspectRatio: `${W} / ${H}`, touchAction: "none", cursor: screen === "play" ? "none" : "default" }}
          onPointerDown={onDown}
          onPointerMove={onMove}
          onPointerUp={onUp}
          onPointerCancel={() => { drag.current = null; }}
          aria-label="Papan permainan Brick Breaker"
        />

        {screen === "menu" && (
          <div className="absolute inset-0 z-10 flex items-center justify-center bg-white/75 p-3">
            <div className="pop w-full max-w-[300px] border-4 border-black bg-white p-4 text-center shadow-[5px_5px_0_#111]">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full border-4 border-black bg-pink-200 shadow-[3px_3px_0_#111]">
                <BrickWall size={28} strokeWidth={2.5} />
              </div>
              <h2 className="mt-2 font-comic text-4xl leading-none tracking-wide">{teks.bb_judul}</h2>
              <p className="mt-2 font-body text-sm font-bold leading-snug text-neutral-600">
                {teks.bb_petunjuk}
              </p>
              <p className="mt-1 font-body text-xs font-bold leading-snug text-pink-600">
                {user ? "Selesaikan level = hadiah Dana Kaget!" : "Login dulu agar hadiah Dana Kaget tiap level bisa diklaim."}
              </p>
              <div className="mt-2 grid grid-cols-2 gap-x-2 gap-y-0.5 text-left text-[10px]">
                {LEGENDA.map((l) => (
                  <div key={l.t} className="flex items-center gap-1.5 font-body text-xs font-bold">
                    {l.d ? (
                      <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 rounded-full border-2 border-black p-[1px]" style={{ background: l.c }}><path d={l.d} fill="#26094d" /></svg>
                    ) : (
                      <span className="inline-block h-3.5 w-4 shrink-0 border-2 border-black" style={{ background: l.c }} />
                    )}
                    {l.t}
                  </div>
                ))}
              </div>
              <div className="mt-2 inline-flex items-center gap-1 border-2 border-black bg-sky-200 px-2 font-comic tracking-wider">
                <Trophy size={15} strokeWidth={2.5} /> {teks.bb_rekor.replace("{n}", hi)}
              </div>
              <button onClick={mulai} className="btn mt-3 w-full bg-yellow-300 px-4 py-2 text-3xl">{startLv > 1 ? teks.bb_lanjut_level.replace("{level}", startLv) : teks.bb_main}</button>
              {startLv > 1 && (
                <button onClick={() => mulai(1)} className="mt-2 font-body text-sm font-bold text-neutral-600 underline">{teks.bb_dari_awal}</button>
              )}
            </div>
          </div>
        )}

        {screen === "pause" && (
          <div className="absolute inset-0 z-10 flex items-center justify-center bg-white/75 p-3">
            <div className="pop w-full max-w-[260px] border-4 border-black bg-white p-4 text-center shadow-[5px_5px_0_#111]">
              <h2 className="font-comic text-4xl leading-none tracking-wide">{teks.bb_dijeda}</h2>
              <div className="mt-3 flex flex-col gap-2">
                <button onClick={jeda} className="btn inline-flex items-center justify-center gap-2 bg-yellow-300 px-4 py-2 text-2xl">
                  <Play size={22} strokeWidth={2.5} /> {teks.bb_lanjut}
                </button>
                <button onClick={mulai} className="btn inline-flex items-center justify-center gap-2 bg-pink-200 px-4 py-2 text-xl">
                  <RotateCcw size={20} strokeWidth={2.5} /> {teks.bb_ulang}
                </button>
                <button onClick={keMenu} className="btn bg-white px-4 py-1 text-lg">{teks.bb_menu}</button>
              </div>
            </div>
          </div>
        )}

        {screen === "over" && (
          <div className="absolute inset-0 z-10 flex items-center justify-center bg-white/75 p-3">
            <div className="pop w-full max-w-[280px] border-4 border-black bg-white p-4 text-center shadow-[5px_5px_0_#111]">
              <h2 className="font-comic text-4xl leading-none tracking-wide text-rose-500" style={{ WebkitTextStroke: "1.5px #111" }}>{teks.bb_game_over}</h2>
              {baru && (
                <div className="mx-auto mt-2 inline-block -rotate-2 border-[3px] border-black bg-yellow-300 px-2 font-comic text-lg tracking-wider shadow-[2px_2px_0_#111]">
                  {teks.bb_rekor_baru}
                </div>
              )}
              <div className="mt-3 grid grid-cols-2 gap-2">
                <Kotak label={teks.bb_skor} bg="bg-yellow-300">{hud.score}</Kotak>
                <Kotak label={teks.bb_level} bg="bg-green-200">{hud.level}</Kotak>
              </div>
              <p className="mt-2 font-comic text-lg tracking-wide">{teks.bb_rekor_tertinggi.replace("{n}", hi)}</p>
              {user ? (
                <p className="mt-1 font-body text-xs font-bold text-neutral-600">{teks.bb_skor_masuk}</p>
              ) : (
                <div className="mt-2 border-2 border-dashed border-black bg-sky-100 p-2">
                  <p className="font-body text-xs font-bold text-neutral-700">{teks.bb_masuk_dulu}</p>
                  {onLogin && <button onClick={onLogin} className="btn mt-1 bg-pink-200 px-3 py-0.5 text-base">{teks.bb_masuk}</button>}
                </div>
              )}
              <div className="mt-3 flex flex-col gap-2">
                <button onClick={mulai} className="btn inline-flex items-center justify-center gap-2 bg-yellow-300 px-4 py-2 text-2xl">
                  <RotateCcw size={22} strokeWidth={2.5} /> {teks.bb_main_lagi}
                </button>
                <button onClick={keMenu} className="btn bg-white px-4 py-1 text-lg">{teks.bb_menu}</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
