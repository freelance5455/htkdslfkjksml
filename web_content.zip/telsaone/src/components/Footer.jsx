import { NAV } from "../data";
import { useContent } from "../lib/content";
import { useGoSection } from "../lib/nav";

export default function Footer() {
  const go = useGoSection();
  const { sosial, teks } = useContent();
  return (
    <footer className="relative border-t-8 border-black bg-yellow-300 pb-32 pt-14"
      style={{ backgroundImage: "radial-gradient(rgba(0,0,0,.15) 1.5px, transparent 1.5px)", backgroundSize: "10px 10px" }}>
      <div className="absolute -top-6 left-1/2 -translate-x-1/2 -rotate-3 border-4 border-black bg-white px-4 py-1 font-comic text-2xl tracking-widest shadow-[4px_4px_0_#111]">
        {teks.footer_bersambung}
      </div>

      <div className="mx-auto grid max-w-5xl gap-8 px-5 md:grid-cols-3">
        <div>
          <p className="font-comic text-4xl tracking-wider">telsa<span className="text-red-500">one</span></p>
          <p className="mt-2 font-body font-bold">{teks.footer}</p>
        </div>

        <div>
          <p className="font-comic text-2xl tracking-wide">{teks.footer_jelajahi}</p>
          <ul className="mt-2 space-y-1">
            {NAV.map((n) => {
              const Icon = n.icon;
              return (
                <li key={n.id}>
                  <a href={"/#" + n.id} onClick={go(n.id)}
                    className="inline-flex items-center gap-2 font-body font-bold transition-transform duration-200 hover:translate-x-1 hover:underline">
                    <Icon size={18} strokeWidth={2.5} /> {teks["nav_" + n.id] || n.label}
                  </a>
                </li>
              );
            })}
          </ul>
        </div>

        <div>
          <p className="font-comic text-2xl tracking-wide">{teks.footer_ikuti}</p>
          <div className="mt-2 flex flex-wrap gap-3">
            {sosial.map((s) => {
              const Icon = s.icon;
              return (
                <a key={s.label} href={s.href} target={s.href.startsWith("http") ? "_blank" : undefined} rel="noopener noreferrer" aria-label={s.label} title={s.label}
                  className="btn flex h-11 w-11 items-center justify-center bg-white"><Icon size={22} strokeWidth={2.5} /></a>
              );
            })}
          </div>
        </div>
      </div>

      <div className="mx-auto mt-10 flex max-w-5xl flex-col items-center justify-center gap-2 px-5 pt-5 font-body text-sm font-bold md:flex-row">
        <p>{teks.footer_hak.replace("{tahun}", new Date().getFullYear())}</p>
      </div>
    </footer>
  );
}
