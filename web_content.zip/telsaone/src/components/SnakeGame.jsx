import { useCallback, useEffect, useRef, useState } from "react";
import { Pause, Play } from "lucide-react";
import { Kotak, Overlay, TombolAtas, InfoMasuk, bacaAngka, simpanAngka } from "./gamekit";

// Snake: gerakkan ular dengan joystick analog (atau tombol panah / WASD), makan apel,
// jangan menabrak tembok atau badan sendiri. Ular & apel digambar di canvas, gerakannya diinterpolasi supaya mulus.
const N = 15;            // petak per sisi
const CS = 360;          // ukuran kanvas logis (px)
const CELL = CS / N;
const KUNCI_HI = "telsaone:snake:hi";
const ARAH = { atas: { x: 0, y: -1 }, bawah: { x: 0, y: 1 }, kiri: { x: -1, y: 0 }, kanan: { x: 1, y: 0 } };

const lerp = (a, b, t) => a + (b - a) * t;
// Gradasi warna badan dihitung sekali (kepala -> ekor), bukan di setiap frame
const SKALA = 24;
const gradasi = (A, B) => Array.from({ length: SKALA }, (_, i) => {
  const t = i / (SKALA - 1);
  return `rgb(${Math.round(lerp(A[0], B[0], t))},${Math.round(lerp(A[1], B[1], t))},${Math.round(lerp(A[2], B[2], t))})`;
});
const PAL_HIDUP = gradasi([22, 163, 74], [74, 222, 128]);
const PAL_MATI = gradasi([107, 143, 120], [167, 196, 176]);

// Latar kotak-kotak digambar sekali ke kanvas tersembunyi, lalu tinggal ditempel tiap frame
let LATAR = null;
function kanvasLatar(dpr) {
  if (LATAR && LATAR.dpr === dpr) return LATAR.cv;
  const cv = document.createElement("canvas");
  cv.width = CS * dpr;
  cv.height = CS * dpr;
  const c = cv.getContext("2d");
  c.setTransform(dpr, 0, 0, dpr, 0, 0);
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    c.fillStyle = (x + y) % 2 ? "#dcfce7" : "#ecfdf5";
    c.fillRect(x * CELL, y * CELL, CELL + 0.5, CELL + 0.5);
  }
  LATAR = { dpr, cv };
  return cv;
}

function gameBaru() {
  const y = Math.floor(N / 2);
  const cur = [{ x: 4, y }, { x: 3, y }, { x: 2, y }];
  return {
    cur, prev: cur, dir: ARAH.kanan, q: [], apple: { x: 10, y }, apples: 0, alive: true,
    tick: 150, acc: -450, fx: null,
  };
}

function taruhApel(S) {
  const isi = new Set(S.cur.map((p) => p.y * N + p.x));
  const kosong = [];
  for (let i = 0; i < N * N; i++) if (!isi.has(i)) kosong.push(i);
  if (!kosong.length) return false;
  const p = kosong[Math.floor(Math.random() * kosong.length)];
  S.apple = { x: p % N, y: Math.floor(p / N) };
  return true;
}

// Satu langkah permainan. Mengembalikan "makan" | "mati" | "jalan".
function langkah(S) {
  if (S.q.length) S.dir = S.q.shift();
  const h = S.cur[0];
  const nh = { x: h.x + S.dir.x, y: h.y + S.dir.y };
  const makan = nh.x === S.apple.x && nh.y === S.apple.y;
  const badan = makan ? S.cur : S.cur.slice(0, -1); // ekor ikut maju kalau tidak makan
  if (nh.x < 0 || nh.y < 0 || nh.x >= N || nh.y >= N || badan.some((p) => p.x === nh.x && p.y === nh.y)) {
    S.alive = false;
    S.prev = S.cur;
    return "mati";
  }
  const lama = S.cur;
  S.prev = makan ? [...lama, lama[lama.length - 1]] : lama;
  S.cur = [nh, ...(makan ? lama : lama.slice(0, -1))];
  if (makan) {
    S.apples += 1;
    S.tick = Math.max(85, 150 - S.apples * 2.2);
    S.fx = { x: nh.x, y: nh.y, t0: performance.now() };
    if (!taruhApel(S)) { S.alive = false; return "mati"; }
    return "makan";
  }
  return "jalan";
}

function mintaArah(S, d) {
  const terakhir = S.q.length ? S.q[S.q.length - 1] : S.dir;
  if (d.x === terakhir.x && d.y === terakhir.y) return;
  if (d.x === -terakhir.x && d.y === -terakhir.y) return; // tidak boleh berbalik 180°
  if (S.q.length < 2) S.q.push(d);
}

// ---------- Gambar ----------
function gambarApel(ctx, cx, cy, tms) {
  const R = CELL * 0.33;
  cy += Math.sin(tms / 260) * 0.8;
  ctx.fillStyle = "rgba(0,0,0,.12)";
  ctx.beginPath(); ctx.ellipse(cx, cy + R * 1.05, R * 0.85, R * 0.28, 0, 0, Math.PI * 2); ctx.fill();
  const bulat = (dx, r, warna) => { ctx.fillStyle = warna; ctx.beginPath(); ctx.arc(cx + dx, cy + R * 0.1, r, 0, Math.PI * 2); ctx.fill(); };
  bulat(-R * 0.28, R * 0.78 + 1.6, "#111"); bulat(R * 0.28, R * 0.78 + 1.6, "#111");
  bulat(-R * 0.28, R * 0.78, "#ef4444"); bulat(R * 0.28, R * 0.78, "#ef4444");
  // kilau
  ctx.fillStyle = "rgba(255,255,255,.6)";
  ctx.beginPath(); ctx.ellipse(cx - R * 0.5, cy - R * 0.1, R * 0.2, R * 0.34, -0.5, 0, Math.PI * 2); ctx.fill();
  // tangkai
  ctx.lineCap = "round";
  ctx.strokeStyle = "#111"; ctx.lineWidth = 3.2;
  ctx.beginPath(); ctx.moveTo(cx, cy - R * 0.45); ctx.lineTo(cx + R * 0.1, cy - R * 1.25); ctx.stroke();
  ctx.strokeStyle = "#92400e"; ctx.lineWidth = 1.7;
  ctx.beginPath(); ctx.moveTo(cx, cy - R * 0.45); ctx.lineTo(cx + R * 0.1, cy - R * 1.25); ctx.stroke();
  // daun
  const daun = (rx, ry, warna) => { ctx.fillStyle = warna; ctx.beginPath(); ctx.ellipse(cx + R * 0.62, cy - R * 1.12, rx, ry, -0.5, 0, Math.PI * 2); ctx.fill(); };
  daun(R * 0.5 + 1.4, R * 0.27 + 1.4, "#111"); daun(R * 0.5, R * 0.27, "#4ade80");
}

function gambarUlar(ctx, S, t, tms) {
  const n = S.cur.length;
  const P = S.cur.map((c, i) => {
    const p = S.prev[i] || c;
    return { x: (lerp(p.x, c.x, t) + 0.5) * CELL, y: (lerp(p.y, c.y, t) + 0.5) * CELL };
  });
  // titik-titik rapat sepanjang badan (kepala -> ekor)
  const pts = [];
  for (let i = 0; i < n - 1; i++) {
    for (let k = 0; k < 4; k++) pts.push({ x: lerp(P[i].x, P[i + 1].x, k / 4), y: lerp(P[i].y, P[i + 1].y, k / 4) });
  }
  pts.push(P[n - 1]);
  const m = pts.length;
  const rad = (j) => CELL * (0.44 - 0.2 * (j / Math.max(1, m - 1)));
  const hidup = S.alive;
  const pal = hidup ? PAL_HIDUP : PAL_MATI;

  const head = P[0];
  const d = S.dir;
  const rKepala = rad(0);

  // lidah (di belakang kepala)
  if (hidup && tms % 1500 < 260) {
    const bx = head.x + d.x * rKepala * 0.9, by = head.y + d.y * rKepala * 0.9;
    const ex = bx + d.x * CELL * 0.42, ey = by + d.y * CELL * 0.42;
    ctx.lineCap = "round"; ctx.strokeStyle = "#111"; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(ex, ey);
    ctx.moveTo(ex, ey); ctx.lineTo(ex + d.x * 3 + d.y * 3, ey + d.y * 3 + d.x * 3);
    ctx.moveTo(ex, ey); ctx.lineTo(ex + d.x * 3 - d.y * 3, ey + d.y * 3 - d.x * 3);
    ctx.stroke();
    ctx.strokeStyle = "#ef4444"; ctx.lineWidth = 1.4;
    ctx.stroke();
  }

  // bingkai hitam, lalu warna (dari ekor ke kepala supaya kepala di atas)
  ctx.fillStyle = "#111";
  for (let j = m - 1; j >= 0; j--) { ctx.beginPath(); ctx.arc(pts[j].x, pts[j].y, rad(j) + 1.8, 0, Math.PI * 2); ctx.fill(); }
  for (let j = m - 1; j >= 0; j--) {
    ctx.fillStyle = pal[Math.round((j / Math.max(1, m - 1)) * (SKALA - 1))];
    ctx.beginPath(); ctx.arc(pts[j].x, pts[j].y, rad(j), 0, Math.PI * 2); ctx.fill();
  }
  // kilau di punggung
  ctx.strokeStyle = "rgba(255,255,255,.28)"; ctx.lineWidth = CELL * 0.13; ctx.lineCap = "round"; ctx.lineJoin = "round";
  ctx.beginPath();
  for (let j = 3; j < m - 2; j++) { const q = pts[j]; if (j === 3) ctx.moveTo(q.x - 1.5, q.y - 1.5); else ctx.lineTo(q.x - 1.5, q.y - 1.5); }
  ctx.stroke();
  // bercak punggung
  ctx.fillStyle = "rgba(20,83,45,.5)";
  for (let j = 8; j < m - 3; j += 6) { ctx.beginPath(); ctx.arc(pts[j].x, pts[j].y, rad(j) * 0.3, 0, Math.PI * 2); ctx.fill(); }

  // mata
  const sx = -d.y, sy = d.x; // arah samping
  for (const sisi of [-1, 1]) {
    const ex = head.x + d.x * rKepala * 0.25 + sx * sisi * rKepala * 0.52;
    const ey = head.y + d.y * rKepala * 0.25 + sy * sisi * rKepala * 0.52;
    if (hidup) {
      ctx.fillStyle = "#111"; ctx.beginPath(); ctx.arc(ex, ey, rKepala * 0.36 + 1, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(ex, ey, rKepala * 0.36, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#111"; ctx.beginPath(); ctx.arc(ex + d.x * rKepala * 0.12, ey + d.y * rKepala * 0.12, rKepala * 0.17, 0, Math.PI * 2); ctx.fill();
    } else {
      const k = rKepala * 0.2;
      ctx.strokeStyle = "#111"; ctx.lineWidth = 1.8; ctx.lineCap = "round";
      ctx.beginPath(); ctx.moveTo(ex - k, ey - k); ctx.lineTo(ex + k, ey + k); ctx.moveTo(ex + k, ey - k); ctx.lineTo(ex - k, ey + k); ctx.stroke();
    }
  }
}

function render(cv, S, t, tms) {
  const ctx = cv.getContext("2d");
  if (!ctx) return;
  const dpr = cv.width / CS;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.drawImage(kanvasLatar(dpr), 0, 0);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  // apel
  gambarApel(ctx, (S.apple.x + 0.5) * CELL, (S.apple.y + 0.5) * CELL, tms);
  // efek makan: lingkaran memudar
  if (S.fx) {
    const u = (tms - S.fx.t0) / 320;
    if (u >= 1) S.fx = null;
    else {
      ctx.strokeStyle = `rgba(239,68,68,${1 - u})`; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc((S.fx.x + 0.5) * CELL, (S.fx.y + 0.5) * CELL, CELL * (0.3 + u * 0.7), 0, Math.PI * 2); ctx.stroke();
    }
  }
  gambarUlar(ctx, S, t, tms);
}

// ---------- Joystick analog ----------
function Joystik({ onArah }) {
  const dasar = useRef(null);
  const kenop = useRef(null);
  const aktif = useRef(false);
  const arahSkrg = useRef("");
  const BATAS = 38; // jarak geser maksimum kenop (px)

  const pindah = (e) => {
    const r = dasar.current.getBoundingClientRect();
    let dx = e.clientX - (r.left + r.width / 2);
    let dy = e.clientY - (r.top + r.height / 2);
    const jarak = Math.hypot(dx, dy);
    if (jarak > BATAS) { dx = (dx / jarak) * BATAS; dy = (dy / jarak) * BATAS; }
    if (kenop.current) { kenop.current.style.transition = "none"; kenop.current.style.transform = `translate(${dx}px, ${dy}px)`; }
    if (jarak < 14) return; // zona mati di tengah
    const a = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? "kanan" : "kiri") : dy > 0 ? "bawah" : "atas";
    if (a !== arahSkrg.current) { arahSkrg.current = a; onArah(ARAH[a]); }
  };
  const turun = (e) => {
    aktif.current = true;
    arahSkrg.current = "";
    try { dasar.current.setPointerCapture?.(e.pointerId); } catch { /* abaikan */ }
    pindah(e);
  };
  const gerak = (e) => { if (aktif.current) pindah(e); };
  const angkat = () => {
    aktif.current = false;
    arahSkrg.current = "";
    if (kenop.current) { kenop.current.style.transition = "transform .14s ease-out"; kenop.current.style.transform = "translate(0px, 0px)"; }
  };

  return (
    <div
      ref={dasar}
      onPointerDown={turun}
      onPointerMove={gerak}
      onPointerUp={angkat}
      onPointerCancel={angkat}
      className="relative mx-auto h-[136px] w-[136px] select-none rounded-full border-4 border-black bg-white shadow-[4px_4px_0_#111]"
      style={{ touchAction: "none" }}
      role="group"
      aria-label="Joystick untuk mengarahkan ular"
    >
      {/* penanda arah, samar */}
      <span className="absolute left-1/2 top-2 h-0 w-0 -translate-x-1/2 border-x-[6px] border-b-[9px] border-x-transparent border-b-neutral-300" />
      <span className="absolute bottom-2 left-1/2 h-0 w-0 -translate-x-1/2 border-x-[6px] border-t-[9px] border-x-transparent border-t-neutral-300" />
      <span className="absolute left-2 top-1/2 h-0 w-0 -translate-y-1/2 border-y-[6px] border-r-[9px] border-y-transparent border-r-neutral-300" />
      <span className="absolute right-2 top-1/2 h-0 w-0 -translate-y-1/2 border-y-[6px] border-l-[9px] border-y-transparent border-l-neutral-300" />
      <div
        ref={kenop}
        className="absolute left-1/2 top-1/2 -ml-[27px] -mt-[27px] h-[54px] w-[54px] rounded-full border-[3px] border-black bg-yellow-300 shadow-[2px_2px_0_#111]"
        style={{ transform: "translate(0px, 0px)", pointerEvents: "none" }}
      />
    </div>
  );
}

export default function SnakeGame({ onBack, user, onLogin, onSelesai }) {
  const [layar, setLayar] = useState("menu"); // menu | play | pause | over
  const [hud, setHud] = useState({ skor: 0, apel: 0 });
  const [hi, setHi] = useState(() => bacaAngka(KUNCI_HI));
  const [baru, setBaru] = useState(false);
  const cvRef = useRef(null);
  const S = useRef(null);
  if (!S.current) S.current = gameBaru();
  const layarRef = useRef(layar);
  layarRef.current = layar;
  const dikirim = useRef(true); // true = tidak ada skor yang menunggu dikirim
  const laporRef = useRef(onSelesai);
  laporRef.current = onSelesai;

  const lapor = useCallback(() => {
    if (dikirim.current) return;
    dikirim.current = true;
    const apel = S.current.apples;
    if (apel > 0) laporRef.current?.({ score: apel * 10, level: 1 + Math.floor(apel / 5) });
  }, []);

  const mati = useCallback(() => {
    const skor = S.current.apples * 10;
    const rekor = bacaAngka(KUNCI_HI);
    if (skor > rekor) { simpanAngka(KUNCI_HI, skor); setHi(skor); setBaru(true); } else setBaru(false);
    setHud({ skor, apel: S.current.apples });
    setLayar("over");
    lapor();
  }, [lapor]);

  const mulai = useCallback(() => {
    lapor(); // skor permainan sebelumnya (kalau diulang di tengah jalan) tetap terkirim
    S.current = gameBaru();
    dikirim.current = false;
    setHud({ skor: 0, apel: 0 });
    setBaru(false);
    setLayar("play");
  }, [lapor]);

  const jeda = () => setLayar((l) => (l === "play" ? "pause" : l === "pause" ? "play" : l));
  const keluar = () => { lapor(); onBack?.(); };

  // Keluar halaman saat main = skor tetap terkirim
  useEffect(() => () => lapor(), [lapor]);

  const minta = useCallback((d) => { if (layarRef.current === "play") mintaArah(S.current, d); }, []);

  // Keyboard
  useEffect(() => {
    const PETA = { ArrowUp: "atas", ArrowDown: "bawah", ArrowLeft: "kiri", ArrowRight: "kanan", w: "atas", s: "bawah", a: "kiri", d: "kanan", W: "atas", S: "bawah", A: "kiri", D: "kanan" };
    const onKey = (e) => {
      const tag = e.target?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || e.ctrlKey || e.metaKey || e.altKey) return;
      if (e.key === " " && (layarRef.current === "play" || layarRef.current === "pause")) { e.preventDefault(); jeda(); return; }
      const a = PETA[e.key];
      if (!a) return;
      e.preventDefault();
      minta(ARAH[a]);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [minta]);

  // Pindah tab / layar mati = otomatis dijeda, supaya ular tidak mati sendiri dan tidak membebani
  useEffect(() => {
    const sembunyi = () => { if (document.hidden) setLayar((l) => (l === "play" ? "pause" : l)); };
    document.addEventListener("visibilitychange", sembunyi);
    return () => document.removeEventListener("visibilitychange", sembunyi);
  }, []);

  // Kanvas tajam di layar retina
  useEffect(() => {
    const cv = cvRef.current;
    if (!cv) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = CS * dpr;
    cv.height = CS * dpr;
  }, []);

  // Putaran game: langkah dengan waktu tetap, gambar tiap frame dengan interpolasi
  useEffect(() => {
    let raf;
    let terakhir = performance.now();
    let gambarTerakhir = 0;
    const putar = (now) => {
      const dt = Math.min(64, now - terakhir);
      terakhir = now;
      const s = S.current;
      if (layarRef.current === "play" && s.alive) {
        s.acc += dt;
        let n = 0;
        while (s.acc >= s.tick && n++ < 4) {
          s.acc -= s.tick;
          const h = langkah(s);
          if (h === "makan") setHud({ skor: s.apples * 10, apel: s.apples });
          if (h === "mati") { s.acc = 0; mati(); break; }
        }
      }
      const t = s.alive ? Math.min(1, Math.max(0, s.acc) / s.tick) : 1;
      // saat main: maks ±70 fps (hemat baterai di layar 120 Hz); saat menu/jeda/game over: cukup ±8 fps
      const batas = layarRef.current === "play" ? 14 : 120;
      if (cvRef.current && now - gambarTerakhir >= batas) { render(cvRef.current, s, t, now); gambarTerakhir = now; }
      raf = requestAnimationFrame(putar);
    };
    raf = requestAnimationFrame(putar);
    return () => cancelAnimationFrame(raf);
  }, [mati]);

  const aktif = layar === "play" || layar === "pause";

  return (
    <div className="mx-auto w-full max-w-[400px]">
      <div className="grid grid-cols-3 gap-2">
        <Kotak label="SKOR" bg="bg-yellow-300">{hud.skor}</Kotak>
        <Kotak label="REKOR" bg="bg-sky-200">{Math.max(hi, hud.skor)}</Kotak>
        <Kotak label="APEL" bg="bg-green-200">{hud.apel}</Kotak>
      </div>

      <TombolAtas onBack={keluar} onUlang={layar === "menu" ? undefined : mulai}>
        <button onClick={jeda} disabled={!aktif} className="btn inline-flex items-center gap-1 bg-sky-200 px-3 py-1 text-lg disabled:opacity-50">
          {layar === "pause" ? <Play size={18} strokeWidth={2.5} /> : <Pause size={18} strokeWidth={2.5} />}
          {layar === "pause" ? "LANJUT" : "JEDA"}
        </button>
      </TombolAtas>

      <div className="relative mt-4 border-4 border-black bg-emerald-50 shadow-[6px_6px_0_#111]">
        <canvas ref={cvRef} width={CS} height={CS} className="block aspect-square w-full select-none" aria-label="Papan permainan Snake" />

        {layar === "menu" && (
          <Overlay lebar={290}>
            <h2 className="font-comic text-5xl leading-none tracking-wide">SNAKE</h2>
            <p className="mt-2 font-body text-sm font-bold leading-snug text-neutral-600">
              Geser joystick di bawah papan untuk mengarahkan ular. Makan apel, tapi jangan menabrak tembok atau badanmu sendiri.
            </p>
            {hi > 0 && <div className="mt-2 inline-block border-2 border-black bg-sky-200 px-2 font-comic tracking-wider">REKOR {hi}</div>}
            <button onClick={mulai} className="btn mt-3 w-full bg-yellow-300 px-4 py-2 text-3xl">MAIN</button>
          </Overlay>
        )}
        {layar === "pause" && (
          <Overlay lebar={240}>
            <h2 className="font-comic text-4xl leading-none tracking-wide">DIJEDA</h2>
            <button onClick={jeda} className="btn mt-3 inline-flex w-full items-center justify-center gap-2 bg-yellow-300 px-4 py-2 text-2xl"><Play size={22} strokeWidth={2.5} /> LANJUT</button>
          </Overlay>
        )}
        {layar === "over" && (
          <Overlay lebar={270}>
            <h2 className="font-comic text-4xl leading-none tracking-wide text-rose-500" style={{ WebkitTextStroke: "1.5px #111" }}>GAME OVER</h2>
            {baru && <div className="mx-auto mt-2 inline-block -rotate-2 border-[3px] border-black bg-yellow-300 px-2 font-comic text-lg tracking-wider shadow-[2px_2px_0_#111]">REKOR BARU!</div>}
            <div className="mt-3 grid grid-cols-2 gap-2">
              <Kotak label="SKOR" bg="bg-yellow-300">{hud.skor}</Kotak>
              <Kotak label="APEL" bg="bg-green-200">{hud.apel}</Kotak>
            </div>
            <InfoMasuk user={user} onLogin={onLogin} />
            <button onClick={mulai} className="btn mt-3 w-full bg-yellow-300 px-4 py-2 text-2xl">MAIN LAGI</button>
          </Overlay>
        )}
      </div>

      <div className="mt-5">
        <Joystik onArah={minta} />
        <p className="mt-3 text-center font-body text-xs font-bold leading-snug text-neutral-600">
          Geser joystick ke arah yang diinginkan. Di komputer bisa pakai tombol panah / WASD, spasi untuk jeda.
        </p>
      </div>
    </div>
  );
}
