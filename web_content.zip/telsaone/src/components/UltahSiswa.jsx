import { useMemo, useState } from "react";
import { useContent } from "../lib/content";
import { Link } from "react-router-dom";
import { Cake, CalendarDays, ChevronDown, ChevronUp, MessageCircle, PartyPopper } from "lucide-react";
import Reveal from "./Reveal";
import { Selotip } from "./Hiasan";
import { BIRTHDAYS, photoOf } from "../lib/siswa";

const DAY_MS = 24 * 60 * 60 * 1000;
const JUMLAH_AWAL = 6; // berapa siswa yang tampil di bawah sorotan sebelum "LIHAT SEMUA"

const fmtLengkap = new Intl.DateTimeFormat("id-ID", { day: "numeric", month: "long", year: "numeric" });
const fmtTanggal = new Intl.DateTimeFormat("id-ID", { day: "numeric", month: "long" });
const fmtBulan = new Intl.DateTimeFormat("id-ID", { month: "long" });

// Warna kartu bergantian (tulis penuh agar terbaca Tailwind)
const WARNA_KARTU = ["bg-pink-100", "bg-yellow-100", "bg-sky-100", "bg-green-100"];
const WARNA_KONFETI = ["#f9a8d4", "#fde047", "#7dd3fc", "#86efac", "#fca5a5"];
const KONFETI = Array.from({ length: 22 }, (_, i) => ({
  kiri: (i * 47 + 9) % 100,
  tunda: (i % 7) * 0.4,
  durasi: 2.8 + (i % 5) * 0.45,
  ukuran: 8 + (i % 3) * 4,
  warna: WARNA_KONFETI[i % WARNA_KONFETI.length],
  bulat: i % 3 === 0,
}));

// Kejadian ulang tahun berikutnya (hari ini juga dihitung), jam 00:00 lokal
function berikutnya(b, hariIni) {
  const tahunIni = new Date(hariIni.getFullYear(), b.month - 1, b.day);
  return tahunIni >= hariIni ? tahunIni : new Date(hariIni.getFullYear() + 1, b.month - 1, b.day);
}

function labelHari(n, teks) {
  if (n === 0) return teks.ultah_hari;
  if (n === 1) return teks.ultah_besok;
  return teks.ultah_n_hari.replace("{n}", n);
}
function warnaLencana(n) {
  if (n <= 7) return "bg-pink-300";
  if (n <= 30) return "bg-yellow-300";
  return "bg-white";
}

function Foto({ u, kelas }) {
  const src = photoOf(u);
  if (src) return <img src={src} alt="" loading="lazy" decoding="async" draggable={false} className={`${kelas} object-cover object-top`} />;
  return <span className={`${kelas} flex items-center justify-center bg-yellow-200 font-comic text-xl`}>{u.name[0]}</span>;
}

function Konfeti() {
  return (
    <div aria-hidden="true" className="pointer-events-none absolute inset-0 z-20 overflow-hidden">
      <style>{`@keyframes ultah-jatuh { 0% { transform: translateY(-24px) rotate(0deg); opacity: 0; } 12% { opacity: 1; } 100% { transform: translateY(420px) rotate(420deg); opacity: .85; } }`}</style>
      {KONFETI.map((k, i) => (
        <span
          key={i}
          className="absolute top-0 border-2 border-black"
          style={{
            left: `${k.kiri}%`, width: k.ukuran, height: k.ukuran, background: k.warna,
            borderRadius: k.bulat ? "9999px" : 0,
            animation: `ultah-jatuh ${k.durasi}s linear ${k.tunda}s infinite`,
          }}
        />
      ))}
    </div>
  );
}

function Sorotan({ u, bareng, sebulan }) {
  const { teks } = useContent();
  const hariIni = u.daysLeft === 0;
  const usia = u.year ? u.next.getFullYear() - u.year : null;
  const namaDepan = u.name.split(" ")[0];

  return (
    <div className="relative">
      <Selotip className="-top-3 left-8 -rotate-6" />
      <Selotip warna="bg-sky-300" className="-top-3 right-8 rotate-6" />
      <div className="panel relative overflow-hidden p-5 pb-7 sm:p-8" style={{ transform: "none" }}>
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 opacity-70"
          style={{ backgroundImage: "radial-gradient(rgba(0,0,0,.14) 1.5px, transparent 1.5px)", backgroundSize: "9px 9px" }}
        />
        {hariIni && <Konfeti />}

        <div className="relative flex flex-col items-center gap-9 sm:flex-row sm:gap-10">
          {/* Foto ala polaroid + stiker hitung mundur */}
          <div className="relative shrink-0 px-6 pt-4 sm:ml-6">
            <div aria-hidden="true" className="rays pointer-events-none absolute left-1/2 top-1/2 h-[19rem] w-[19rem] -translate-x-1/2 -translate-y-1/2" />
            <div className="relative -rotate-3 border-4 border-black bg-white p-2 pb-10 shadow-[6px_6px_0_#111]">
              <Selotip warna="bg-yellow-300" className="-top-4 left-1/2 -translate-x-1/2 rotate-3" />
              <div className="aspect-[2/3] w-44 overflow-hidden border-2 border-black bg-sky-200 sm:w-48">
                <Foto u={u} kelas="h-full w-full" />
              </div>
              <span className="absolute inset-x-0 bottom-1.5 truncate px-2 text-center font-comic text-xl tracking-wide">{namaDepan}</span>
            </div>
            <div className="stiker absolute -right-1 -top-1 z-10 h-24 w-24 sm:h-28 sm:w-28" style={{ "--tilt": "-10deg" }}>
              <div className="burst absolute inset-0 bg-black" />
              <div className="burst absolute inset-[3px] bg-yellow-300" />
              <div className="relative flex h-full w-full flex-col items-center justify-center text-center font-comic leading-none">
                {hariIni ? (
                  <span className="text-2xl tracking-wide">{teks.ultah_hari}</span>
                ) : (
                  <>
                    <span className="text-4xl sm:text-5xl">{u.daysLeft}</span>
                    <span className="text-sm tracking-wider">{teks.ultah_hari_lagi}</span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Keterangan */}
          <div className="relative min-w-0 flex-1 text-center sm:text-left">
            <span className="inline-flex items-center gap-1.5 border-2 border-black bg-pink-300 px-2 font-comic tracking-wider">
              {hariIni ? <PartyPopper size={18} strokeWidth={2.5} /> : <Cake size={18} strokeWidth={2.5} />}
              {hariIni ? teks.ultah_selamat : teks.ultah_terdekat}
            </span>
            <h4 className="mt-2 break-words font-comic text-4xl leading-tight tracking-wide md:text-5xl">
              <span className="bg-yellow-300 px-2 [box-decoration-break:clone] [-webkit-box-decoration-break:clone]">{u.name}</span>
            </h4>

            <p className="mt-4 inline-flex items-center gap-2 border-2 border-black bg-white px-3 py-1 font-comic text-2xl tracking-wide shadow-[3px_3px_0_#111]">
              <CalendarDays size={22} strokeWidth={2.5} /> {fmtLengkap.format(u.next)}
            </p>
            {usia ? (
              <p className="mt-3 font-body text-lg font-bold text-neutral-700">
                {teks.ultah_naik_1} <span className="border-2 border-black bg-sky-300 px-2 font-comic text-2xl tracking-wide">{usia}</span> {teks.ultah_naik_2}
              </p>
            ) : null}
            {bareng.length > 0 && (
              <p className="mt-2 font-body text-base font-bold text-neutral-600">
                Ultah bareng: {bareng.map((b) => b.name).join(" & ")}
              </p>
            )}

            <div className="mt-4 flex flex-wrap justify-center gap-2 sm:justify-start">
              <span className="border-2 border-black bg-green-200 px-2 font-comic tracking-wider">
                {sebulan} ULTAH DI BULAN {fmtBulan.format(u.next).toUpperCase()}
              </span>
            </div>

            <Link to="/chat" className="btn mt-5 inline-flex items-center justify-center gap-2 bg-yellow-300 px-5 py-2 text-xl">
              <MessageCircle size={22} strokeWidth={2.5} /> {teks.ultah_ucapkan}
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

function Kartu({ u, i }) {
  const { teks } = useContent();
  const usia = u.year ? u.next.getFullYear() - u.year : null;
  return (
    <li className={`relative flex min-w-0 items-center gap-3 border-4 border-black ${WARNA_KARTU[i % WARNA_KARTU.length]} p-2.5 shadow-[4px_4px_0_#111] transition duration-200 hover:-translate-y-1 hover:shadow-[6px_6px_0_#111]`}>
      <Foto u={u} kelas="h-14 w-14 shrink-0 rounded-full border-2 border-black bg-white" />
      <div className="min-w-0 flex-1">
        <p className="truncate font-body text-base font-bold leading-tight" title={u.name}>{u.name}</p>
        <p className="truncate font-body text-sm font-bold text-neutral-600">
          {fmtTanggal.format(u.next)}{usia ? ` · ${usia} th` : ""}
        </p>
      </div>
      <span className={`shrink-0 border-2 border-black px-2 py-0.5 font-comic text-base tracking-wide ${warnaLencana(u.daysLeft)}`}>
        {labelHari(u.daysLeft, teks)}
      </span>
    </li>
  );
}

// Kelompokkan daftar (sudah urut terdekat) per bulan kejadian berikutnya
function perBulan(daftar) {
  const hasil = [];
  for (const u of daftar) {
    const kunci = `${u.next.getFullYear()}-${u.next.getMonth()}`;
    let g = hasil[hasil.length - 1];
    if (!g || g.kunci !== kunci) {
      g = { kunci, tahun: u.next.getFullYear(), bulan: fmtBulan.format(u.next).toUpperCase(), isi: [] };
      hasil.push(g);
    }
    g.isi.push(u);
  }
  return hasil;
}

export default function UltahSiswa() {
  const { teks } = useContent();
  const [semua, setSemua] = useState(false);

  const { urut, tahunIni } = useMemo(() => {
    const now = new Date();
    const hariIni = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const urut = BIRTHDAYS.map((b) => {
      const next = berikutnya(b, hariIni);
      return { ...b, next, daysLeft: Math.round((next.getTime() - hariIni.getTime()) / DAY_MS) };
    }).sort((a, b) => a.daysLeft - b.daysLeft);
    return { urut, tahunIni: hariIni.getFullYear() };
  }, []);

  const judul = (
    <Reveal>
      <h3 className="mb-4 mt-14 flex items-center gap-2 font-comic text-3xl tracking-wide">
        <Cake size={28} strokeWidth={2.5} /> {teks.ultah_judul}
      </h3>
    </Reveal>
  );

  if (!urut.length) {
    return (
      <div>
        {judul}
        <Reveal>
          <div className="panel p-6 text-center font-comic text-2xl tracking-wide" style={{ transform: "none" }}>{teks.ultah_menyusul}</div>
        </Reveal>
      </div>
    );
  }

  // Sorotan = yang paling dekat; siswa yang ultahnya sama persis ikut disebut ("bareng") dan tidak diulang di daftar
  const terdekat = urut.filter((u) => u.daysLeft === urut[0].daysLeft);
  const [pertama, ...bareng] = terdekat;
  const sebulan = urut.filter((u) => u.next.getMonth() === pertama.next.getMonth() && u.next.getFullYear() === pertama.next.getFullYear()).length;
  const sisa = urut.slice(terdekat.length);
  const tampil = semua ? sisa : sisa.slice(0, JUMLAH_AWAL);
  let nomor = 0;

  return (
    <div>
      {judul}
      <Reveal delay={100}>
        <Sorotan u={pertama} bareng={bareng} sebulan={sebulan} />
      </Reveal>

      {sisa.length > 0 && (
        <Reveal>
          <div className="mt-10">
            <h4 className="mb-1 font-comic text-2xl tracking-wide">
              {teks.ultah_berikutnya} <span className="font-body text-base font-bold text-neutral-500">({sisa.length} {teks.ultah_siswa})</span>
            </h4>

            {perBulan(tampil).map((g) => (
              <div key={g.kunci}>
                <div className="mb-3 mt-5 flex items-center gap-3">
                  <span className="border-2 border-black bg-sky-300 px-2 font-comic text-xl tracking-wider">
                    {g.bulan}{g.tahun !== tahunIni ? ` ${g.tahun}` : ""}
                  </span>
                  <span aria-hidden="true" className="flex-1 border-t-4 border-dashed border-black" />
                </div>
                <ul className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  {g.isi.map((u) => <Kartu key={`${u.name}-${u.month}-${u.day}`} u={u} i={nomor++} />)}
                </ul>
              </div>
            ))}

            {sisa.length > JUMLAH_AWAL && (
              <div className="mt-7 flex justify-center">
                <button type="button" onClick={() => setSemua((v) => !v)} className="btn inline-flex items-center justify-center gap-2 bg-white px-5 py-2 text-xl" aria-expanded={semua}>
                  {semua ? <>{teks.ultah_tutup} <ChevronUp size={22} strokeWidth={3} /></> : <>{teks.ultah_lihat_semua} ({sisa.length}) <ChevronDown size={22} strokeWidth={3} /></>}
                </button>
              </div>
            )}
          </div>
        </Reveal>
      )}
    </div>
  );
}
