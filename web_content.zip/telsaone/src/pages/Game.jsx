import { Suspense, lazy, useCallback, useEffect, useState } from "react";
import { Archive, Gamepad2, Play } from "lucide-react";
import Reveal from "../components/Reveal";
import { useContent } from "../lib/content";
import Leaderboard from "../components/Leaderboard";
import JadwalSholat from "../components/JadwalSholat";
import MurotalRelax from "../components/MurotalRelax";
import GameBoundary from "../components/GameBoundary";
import { isAdmin } from "../lib/admin";
import { GAME_META, kirimSkor, statusGame, useGameStatus } from "../lib/games";

// Game dimuat malas (lazy) supaya halaman lain tetap ringan.
// Game baru: tambahkan metadata di lib/games.js dan komponennya di sini.
const KOMPONEN = {
  brick: lazy(() => import("../components/BrickBreaker")),
  minesweeper: lazy(() => import("../components/Minesweeper")),
  "2048": lazy(() => import("../components/Game2048")),
  tictactoe: lazy(() => import("../components/TicTacToe")),
  snake: lazy(() => import("../components/SnakeGame")),
};

export default function Game({ user, onLogin, onToast }) {
  const [aktif, setAktif] = useState(null);
  const [segar, setSegar] = useState(0); // naik tiap skor terkirim -> peringkat dimuat ulang
  const { status, ready } = useGameStatus();
  const admin = isAdmin(user);
  const { teks } = useContent();

  useEffect(() => { window.scrollTo(0, 0); }, [aktif]);

  // Admin melihat semua game (yang diarsipkan diberi tanda); pengunjung hanya yang terbit
  const daftar = GAME_META.filter((g) => KOMPONEN[g.id] && (admin || statusGame(status, g.id) === "published"));
  const game = daftar.find((g) => g.id === aktif);
  const Komponen = game ? KOMPONEN[game.id] : null;

  // Skor terbaik pemain masuk papan peringkat (hanya jika sudah login)
  const selesai = useCallback(
    async (gameId, { score, level }) => {
      if (!user) return;
      const { best, error } = await kirimSkor(gameId, score, level);
      if (error) return onToast?.(teks.game_toast_gagal);
      setSegar((k) => k + 1);
      if (score >= best) onToast?.(teks.game_toast_ok);
    },
    [user, onToast]
  );

  return (
    <section className="mx-auto max-w-3xl px-5 pb-32 pt-28">
      <Reveal>
        <div className="panel p-5 md:p-6" style={{ transform: "none" }}>
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h1 className="flex items-center gap-2 font-comic text-4xl tracking-wide">
              <Gamepad2 size={34} strokeWidth={2.5} /> {game ? game.judul.toUpperCase() : teks.game_judul}
            </h1>
            <span className="border-2 border-black bg-sky-200 px-2 font-comic tracking-wider">{daftar.length} GAME</span>
          </div>

          {/* Jadwal sholat Kab. Banyumas: penuh di daftar game, ringkas saat game dimainkan */}
          <JadwalSholat key={game ? "main" : "daftar"} ringkas={!!game} />

          {/* Murotal + video relax: hanya ada di halaman ini; memutar murotal menghentikan musik */}
          <MurotalRelax ringkas={!!game} />

          {game ? (
            <div className="mt-5">
              <GameBoundary key={game.id} onBack={() => setAktif(null)}>
                <Suspense fallback={<p className="py-10 text-center font-comic text-2xl tracking-wide">{teks.memuat}</p>}>
                  <Komponen onBack={() => setAktif(null)} user={user} onLogin={onLogin} onSelesai={(r) => selesai(game.id, r)} />
                </Suspense>
              </GameBoundary>
              <Leaderboard gameId={game.id} user={user} refreshKey={segar} />
            </div>
          ) : !ready ? (
            <p className="py-10 text-center font-comic text-2xl tracking-wide">{teks.memuat}</p>
          ) : daftar.length === 0 ? (
            <div className="mt-6 border-[3px] border-dashed border-black p-8 text-center">
              <div className="float mx-auto flex h-20 w-20 items-center justify-center rounded-full border-4 border-black bg-yellow-300 shadow-[4px_4px_0_#111]">
                <Gamepad2 size={38} strokeWidth={2.5} />
              </div>
              <p className="mt-4 font-comic text-3xl tracking-wide">{teks.game_kosong_judul}</p>
              <p className="mt-1 font-body font-bold text-neutral-600">{teks.game_kosong_pesan}</p>
            </div>
          ) : (
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              {daftar.map(({ id, judul, deskripsi, Ikon }) => {
                const arsip = statusGame(status, id) === "archived";
                return (
                  <button key={id} onClick={() => setAktif(id)} className="btn bg-white p-4 text-left" style={{ letterSpacing: "normal" }}>
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex h-11 w-11 items-center justify-center rounded-full border-[3px] border-black bg-yellow-300"><Ikon size={22} strokeWidth={2.5} /></div>
                      {arsip && (
                        <span className="inline-flex items-center gap-1 border-2 border-black bg-zinc-200 px-1.5 font-comic text-sm tracking-wider">
                          <Archive size={14} strokeWidth={2.5} /> {teks.game_arsip}
                        </span>
                      )}
                    </div>
                    <p className="mt-2 font-comic text-2xl tracking-wide">{judul}</p>
                    <p className="font-body font-bold text-neutral-600">{deskripsi}</p>
                    <span className="mt-3 inline-flex items-center gap-1 border-2 border-black bg-pink-200 px-3 font-comic text-lg tracking-wider shadow-[2px_2px_0_#111]">
                      <Play size={16} strokeWidth={2.5} /> {teks.game_main}
                    </span>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </Reveal>
    </section>
  );
}
