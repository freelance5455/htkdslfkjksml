
# Toolbox for MCPE

- App name: Toolbox for MCPE
- Version: 1.0
- Version code / build number: 2
- Android application ID: com.toolbox.mcpe
- Requested Minecraft version choices: 26.30, 26.45, 26.40.5

## Features
- Mobile-friendly HTML interface
- Minecraft version selector
- Toolbox information cards
- Saved server labels for 2b2tpe and 6b6t
- Android WebView entry point

## Limitations
This starter project is a companion interface, not a Minecraft mod.
It does not join servers, detect the installed game version, alter
inventory, provide an in-game overlay, or verify server compatibility.

The HTML files must be copied into android/app/src/main/assets/.
A compatible Android SDK, JDK, and Gradle setup are required to build an APK.
