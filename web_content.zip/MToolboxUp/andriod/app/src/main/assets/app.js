
"use strict";

const versionSelect = document.getElementById("version");
const versionInfo = document.getElementById("versionInfo");
const toolResult = document.getElementById("toolResult");
const serverResult = document.getElementById("serverResult");

const supportedChoices = ["26.30", "26.45", "26.40.5"];

function showMessage(element, message) {
  element.textContent = message;
  element.hidden = false;
}

versionSelect.addEventListener("change", () => {
  const selected = versionSelect.value;

  if (!supportedChoices.includes(selected)) {
    showMessage(versionInfo, "Please choose a listed version.");
    return;
  }

  showMessage(
    versionInfo,
    `Selected version: ${selected}. This is your selection, not an automatic compatibility check.`
  );
});

document.querySelectorAll("[data-tool]").forEach((button) => {
  button.addEventListener("click", () => {
    const tool = button.dataset.tool;

    const messages = {
      "Server list": "Scroll down to view the saved server labels.",
      "Version checker":
        `Selected version: ${versionSelect.value}. Live game detection is not available.`,
      "Game information":
        "This companion app does not inspect or modify the Minecraft game.",
      "Settings":
        "Toolbox for MCPE · Version 1.0 · Build 2."
    };

    showMessage(toolResult, messages[tool] || "Tool unavailable.");
  });
});

document.querySelectorAll("[data-server]").forEach((button) => {
  button.addEventListener("click", () => {
    const server = button.dataset.server;

    showMessage(
      serverResult,
      `${server}: No server address has been configured. Obtain the correct address and port from the server's official source, then add it in Minecraft. This button does not connect to the server.`
    );
  });
});
