
package com.toolbox.mcpe

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri

object MinecraftLauncher {

    private const val MINECRAFT_PACKAGE =
        "com.mojang.minecraftpe"

    sealed class LaunchResult {
        data object Launched : LaunchResult()
        data object MinecraftNotInstalled : LaunchResult()
        data class Failed(val message: String) : LaunchResult()
    }

    /**
     * Attempts to open Minecraft.
     *
     * Opening Minecraft does not guarantee that it will join
     * the requested server. Server deep-link support varies
     * by Minecraft version and Android configuration.
     */
    fun openMinecraft(context: Context): LaunchResult {
        val launchIntent =
            context.packageManager.getLaunchIntentForPackage(
                MINECRAFT_PACKAGE
            ) ?: return LaunchResult.MinecraftNotInstalled

        return try {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            LaunchResult.Launched
        } catch (_: ActivityNotFoundException) {
            LaunchResult.MinecraftNotInstalled
        } catch (e: SecurityException) {
            LaunchResult.Failed(
                e.message ?: "Android blocked the launch."
            )
        }
    }

    /**
     * Tries a Minecraft URI supplied by the caller.
     * This does not construct or guarantee a server-join URI.
     */
    fun openMinecraftUri(
        context: Context,
        uri: Uri
    ): LaunchResult {
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage(MINECRAFT_PACKAGE)
        }

        return try {
            context.startActivity(intent)
            LaunchResult.Launched
        } catch (_: ActivityNotFoundException) {
            LaunchResult.Failed(
                "Minecraft cannot handle this link."
            )
        } catch (e: SecurityException) {
            LaunchResult.Failed(
                e.message ?: "Android blocked the link."
            )
        }
    }
}
