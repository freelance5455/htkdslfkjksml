package com.blockquest.puzzle

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.FrameLayout
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var interstitial: InterstitialAd? = null
    private var rewarded: RewardedAd? = null
    private var banner: AdView? = null

    // User's production ad unit IDs. Use Google test ad IDs during testing until release readiness.
    private val bannerId = "ca-app-pub-6154008308939027/6277586897"
    private val interstitialId = "ca-app-pub-6154008308939027/5994068750"
    private val rewardedId = "ca-app-pub-6154008308939027/8592311936"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this) {}
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF10152B.toInt()) }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            addJavascriptInterface(AdBridge(), "AndroidAds")
            loadUrl("file:///android_asset/game.html")
        }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        banner = AdView(this).apply {
            adUnitId = bannerId
            setAdSize(AdSize.BANNER)
            loadAd(AdRequest.Builder().build())
        }
        root.addView(banner, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        loadInterstitial()
        loadRewarded()
    }

    private fun loadInterstitial() {
        InterstitialAd.load(this, interstitialId, AdRequest.Builder().build(), object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) { interstitial = ad }
            override fun onAdFailedToLoad(error: LoadAdError) { interstitial = null }
        })
    }
    private fun showInterstitial() {
        val ad = interstitial
        if (ad == null) { loadInterstitial(); return }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { interstitial = null; loadInterstitial() }
            override fun onAdFailedToShowFullScreenContent(error: com.google.android.gms.ads.AdError) { interstitial = null; loadInterstitial() }
        }
        ad.show(this)
    }
    private fun loadRewarded() {
        RewardedAd.load(this, rewardedId, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) { rewarded = ad }
            override fun onAdFailedToLoad(error: LoadAdError) { rewarded = null }
        })
    }
    private fun showRewarded() {
        val ad = rewarded
        if (ad == null) { loadRewarded(); runOnUiThread { web.evaluateJavascript("alert('Reward ad is not ready yet. Please try again shortly.');", null) }; return }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { rewarded = null; loadRewarded() }
        }
        ad.show(this) { reward -> runOnUiThread { web.evaluateJavascript("window.rewardFromAd && window.rewardFromAd(${reward.amount});", null) } }
    }
    inner class AdBridge {
        @JavascriptInterface fun showInterstitial() { runOnUiThread { showInterstitial() } }
        @JavascriptInterface fun showRewarded() { runOnUiThread { showRewarded() } }
    }
    override fun onDestroy() {
        banner?.destroy()
        web.destroy()
        super.onDestroy()
    }
}
