Block Quest Android project (source)

This is an Android Studio project containing the puzzle game and AdMob SDK integration.
AdMob IDs configured:
App ID: ca-app-pub-6154008308939027~3751048793
Banner: ca-app-pub-6154008308939027/6277586897
Interstitial: ca-app-pub-6154008308939027/5994068750
Rewarded: ca-app-pub-6154008308939027/8592311936

Important:
- This source project is NOT a compiled APK.
- Before testing, replace the live ad unit IDs with Google's test IDs, or register your test device. Never click your own live ads.
- Rewarded currently opens when Hint is tapped; the game's existing hint logic is separate. The callback is wired to a JS reward hook; add actual reward handling before production release.
- Review privacy disclosures, consent requirements, AdMob policy, and Play Console requirements before publishing.
- Build in Android Studio using Gradle sync, then Build > Build APK(s).
