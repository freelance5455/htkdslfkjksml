LUTONG PINOY ANDROID PROJECT
=============================

Ito ay Android Studio project para gawing installable APK ang Lutong Pinoy.
May 50 recipes, search, categories, favorites at grocery list. Ang app content
ay naka-embed locally kaya hindi kailangan ng internet para sa pangunahing features.

PAANO GUMAWA NG APK SA COMPUTER
1. Mag-install ng Android Studio mula sa opisyal na website:
   https://developer.android.com/studio
2. I-extract ang LutongPinoyAndroid.zip.
3. Sa Android Studio, piliin ang Open at piliin ang folder na LutongPinoyAndroid.
4. Hintaying matapos ang Gradle sync at kung may prompt, i-install ang Android SDK
   Platform 35 at Build Tools gamit ang SDK Manager.
5. Piliin ang Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Pagkatapos, piliin ang locate sa notification. Karaniwang output:
   app/build/outputs/apk/debug/app-debug.apk
7. Ilipat ang APK sa Android phone, buksan ito, at payagan ang "Install unknown apps"
   para sa app na ginamit sa pagbukas ng APK kung hingin ng Android.

PARA MAG-INSTALL DIREKTA SA PHONE
Hindi pa APK ang ZIP na ito; source project ito na kailangang i-build sa Android Studio
o compatible cloud build environment. Ang kasalukuyang execution environment ay walang
Android SDK/Gradle setup para makapag-compile at makapag-verify ng APK rito.

SA PHONE
Kapag na-install na ang APK, buksan ang Lutong Pinoy mula sa app drawer.
