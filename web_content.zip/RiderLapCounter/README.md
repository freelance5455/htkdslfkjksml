# คำนวณรอบวิ่งไรเดอร์ (Android Studio project)

โปรเจกต์นี้ห่อหน้าเว็บคำนวณรอบวิ่งไว้ใน Android WebView และเปิดใช้งานแบบออฟไลน์ได้
ข้อมูลตัวเลขบันทึกใน localStorage ของแอป

## วิธีสร้างไฟล์ APK
1. ติดตั้ง Android Studio บนคอมพิวเตอร์
2. แตกไฟล์ ZIP นี้
3. เปิดโฟลเดอร์ `RiderLapCounter` ด้วย Android Studio
4. รอ Gradle Sync และติดตั้ง Android SDK Platform 35 หากโปรแกรมแจ้งให้ติดตั้ง
5. เลือกเมนู Build > Build Bundle(s) / APK(s) > Build APK(s)
6. ไฟล์ APK จะอยู่ที่ `app/build/outputs/apk/debug/app-debug.apk`

ต้องใช้ Android Studio/Android SDK เพื่อคอมไพล์ APK; ZIP นี้เป็นซอร์สโปรเจกต์ ไม่ใช่ไฟล์ APK ที่คอมไพล์แล้ว
