# JJP — Phone-Only APK Build

This version is designed so you can work from an Android phone without installing Android Studio.

## What happens

Your phone uploads this project to GitHub. GitHub Actions does the heavy Android build in the cloud and produces an APK artifact.

## Phone steps

1. Create or sign in to a GitHub account.
2. Create a new repository, for example `JJP-NYC-Studios`.
3. Upload the **contents** of this ZIP into the repository (make sure `.github/workflows/build-apk.yml` is included).
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab.
6. Open **Build JJP Android APK**.
7. The workflow will run automatically after a push to `main`. You can also choose **Run workflow** manually.
8. When it finishes successfully, open the workflow run and scroll to **Artifacts**.
9. Download `JJP-NYC-Studios-debug-apk.zip` to your phone.
10. Extract it, tap `app-debug.apk`, and install it.

## Important

- This project uses official Capacitor 8 packages.
- No Godot is required.
- Android Studio is not required on your phone because GitHub Actions performs the Android build.
- The first build can take several minutes.
- Android may ask you to allow installation from the browser/file manager. Only enable that for the app you trust, then install the APK.

## Local Termux option

If you later want to run the JavaScript side directly on your phone, Termux can be used for Node/npm tasks. The APK workflow above is still the simpler phone-only build route because the native Android toolchain is heavy.
