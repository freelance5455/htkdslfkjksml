# CGD — Étape 6.9 : écran 09, Préparation du match (disposition FM27)

- Le bouton « Jouer le match » du calendrier ouvre d'abord la préparation (dans la section Arène), au lieu de lancer la partie directement.
- Colonne gauche : adversaire, niveau moyen, forme, rappel tactique.
- Colonne droite : damistes du club du joueur, le meilleur est proposé comme titulaire ; un appui change le titulaire.
- « Lancer le match » démarre la rencontre (moteur inchangé) et affiche le titulaire sous « Ton club » ; « Retour » ferme la préparation.
- Code : `src/match-prep.js` (données et affichage), branchement dans `src/app.js`, styles dans le bloc `fm27-terrain` de `index.html`, tests dans `tests/match-prep.test.js`.
- Non branchés : remplaçants en dehors du titulaire (liste simple), choix de tactique (écran 08).
