# Tamim Music Vault (Android source project)

A starter Android project for a local video-folder organizer with a WebView UI and native Media3 playback.

## Features implemented
- Create, rename (long-press/right-click a folder), and delete local folders.
- Pick multiple existing videos through Android's system document picker.
- Save persisted content-URI references; video files are not copied into the app.
- Remove a video from a folder without deleting the original Gallery file.
- 12-second shared folder intro animation; Android Back is ignored during the animation.
- Open a native ExoPlayer video screen.
- Start a native Media3 foreground playback service for screen-off/background audio.
- Local-only folder metadata using SharedPreferences; no Firebase or cloud storage.

## Build
1. Open this project folder in Android Studio or a compatible Android IDE that supports Gradle Android projects.
2. Allow Gradle to sync and download dependencies.
3. Build > Build APK(s).
4. Install the generated debug APK on your Android phone.

Recommended build environment: JDK 17, Android Gradle Plugin 8.7.3, Gradle 8.9, Android SDK 35.

## Important notes
- This is Android source code, not a prebuilt APK. It must be built with an Android Gradle toolchain.
- The app stores video URI references, not duplicate video files. If the original file is deleted or its permission is revoked, it may no longer play.
- Background audio starts only after the user taps the **Play audio in background** button in the native player. It continues with the screen off while Android allows the foreground media service to run.
- A fully powered-off phone cannot play audio.
- The 12-second intro cannot block Android system Home/Power controls or force the user to remain in the app; it only ignores the app's Back action during the animation.
- This is a first working foundation. Test on the target phone; Android vendor battery restrictions may require allowing background activity for reliable playback.
