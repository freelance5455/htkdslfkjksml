package com.tamim.musicvault

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private val prefs by lazy { getSharedPreferences("vault_library", MODE_PRIVATE) }
    private var selectedFolderId: String? = null
    @Volatile private var introRunning = false

    private val videoPicker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val folderId = selectedFolderId
        if (folderId != null && uris.isNotEmpty()) {
            uris.forEach { uri ->
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                addVideoToFolder(folderId, uri)
            }
            val payload = JSONObject().put("library", libraryJson()).toString()
            webView.evaluateJavascript("window.onLibraryUpdated && window.onLibraryUpdated($payload);", null)
        }
        selectedFolderId = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowContentAccess = true
        webView.settings.mediaPlaybackRequiresUserGesture = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(AppBridge(), "Android")
        webView.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (introRunning) return
                webView.evaluateJavascript("window.handleAndroidBack && window.handleAndroidBack();", null)
            }
        })
    }

    inner class AppBridge {
        @JavascriptInterface fun getLibrary(): String = libraryJson().toString()
        @JavascriptInterface fun createFolder(name: String): String {
            val clean = name.trim().take(48)
            if (clean.isEmpty()) return libraryJson().toString()
            val lib = libraryJson()
            val folders = lib.optJSONArray("folders") ?: JSONArray()
            val folder = JSONObject().put("id", UUID.randomUUID().toString()).put("name", clean).put("videos", JSONArray())
            folders.put(folder); lib.put("folders", folders); saveLibrary(lib)
            return lib.toString()
        }
        @JavascriptInterface fun renameFolder(id: String, name: String): String {
            val lib = libraryJson(); val folders = lib.optJSONArray("folders") ?: JSONArray()
            for (i in 0 until folders.length()) { val f = folders.optJSONObject(i) ?: continue; if (f.optString("id") == id) f.put("name", name.trim().take(48)) }
            saveLibrary(lib); return lib.toString()
        }
        @JavascriptInterface fun deleteFolder(id: String): String {
            val lib = libraryJson(); val old = lib.optJSONArray("folders") ?: JSONArray(); val fresh = JSONArray()
            for (i in 0 until old.length()) { val f = old.optJSONObject(i) ?: continue; if (f.optString("id") != id) fresh.put(f) }
            lib.put("folders", fresh); saveLibrary(lib); return lib.toString()
        }
        @JavascriptInterface fun pickVideos(folderId: String) {
            runOnUiThread { selectedFolderId = folderId; videoPicker.launch(arrayOf("video/*")) }
        }
        @JavascriptInterface fun removeVideo(folderId: String, uri: String): String {
            val lib = libraryJson(); val folders = lib.optJSONArray("folders") ?: JSONArray()
            for (i in 0 until folders.length()) {
                val f = folders.optJSONObject(i) ?: continue
                if (f.optString("id") == folderId) {
                    val old = f.optJSONArray("videos") ?: JSONArray(); val fresh = JSONArray()
                    for (j in 0 until old.length()) { val v = old.optJSONObject(j) ?: continue; if (v.optString("uri") != uri) fresh.put(v) }
                    f.put("videos", fresh)
                }
            }
            saveLibrary(lib); return lib.toString()
        }
        @JavascriptInterface fun playVideo(uri: String, title: String) {
            runOnUiThread { startActivity(Intent(this@MainActivity, PlayerActivity::class.java).putExtra("uri", uri).putExtra("title", title)) }
        }
        @JavascriptInterface fun setIntroRunning(running: Boolean) { introRunning = running }
        @JavascriptInterface fun exitApp() { runOnUiThread { finish() } }
    }

    private fun libraryJson(): JSONObject = try { JSONObject(prefs.getString("library", "{\"folders\":[]}") ?: "{\"folders\":[]}") } catch (_: Exception) { JSONObject().put("folders", JSONArray()) }
    private fun saveLibrary(value: JSONObject) { prefs.edit().putString("library", value.toString()).apply() }

    private fun addVideoToFolder(folderId: String, uri: Uri) {
        val lib = libraryJson(); val folders = lib.optJSONArray("folders") ?: JSONArray()
        val name = queryDisplayName(uri)
        val duration = try {
            val retriever = android.media.MediaMetadataRetriever()
            retriever.setDataSource(this, uri)
            val ms = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            retriever.release(); ms
        } catch (_: Exception) { 0L }
        for (i in 0 until folders.length()) {
            val f = folders.optJSONObject(i) ?: continue
            if (f.optString("id") == folderId) {
                val videos = f.optJSONArray("videos") ?: JSONArray()
                var exists = false
                for (j in 0 until videos.length()) if (videos.optJSONObject(j)?.optString("uri") == uri.toString()) exists = true
                if (!exists) videos.put(JSONObject().put("uri", uri.toString()).put("name", name).put("duration", duration))
                f.put("videos", videos); break
            }
        }
        saveLibrary(lib)
    }

    private fun queryDisplayName(uri: Uri): String {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) ?: "Video" else "Video"
            } ?: "Video"
        } catch (_: Exception) { "Video" }
    }
}
