package com.tamim.musicvault

import android.content.Intent
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class AudioPlaybackService : MediaSessionService() {
    private var player: ExoPlayer? = null
    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        player = ExoPlayer.Builder(this).build()
        mediaSession = MediaSession.Builder(this, player!!).build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            player?.stop()
            stopSelf()
            return START_NOT_STICKY
        }
        val uri = intent?.getStringExtra(EXTRA_URI)
        val title = intent?.getStringExtra(EXTRA_TITLE) ?: "Tamim Music Vault"
        if (!uri.isNullOrBlank()) {
            val item = MediaItem.Builder()
                .setUri(uri)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist("Tamim Music Vault").build())
                .build()
            player?.apply { setMediaItem(item); prepare(); playWhenReady = true }
        }
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onDestroy() {
        mediaSession?.release(); mediaSession = null
        player?.release(); player = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_PLAY = "com.tamim.musicvault.PLAY_AUDIO"
        const val ACTION_STOP = "com.tamim.musicvault.STOP_AUDIO"
        const val EXTRA_URI = "extra_uri"
        const val EXTRA_TITLE = "extra_title"
    }
}
