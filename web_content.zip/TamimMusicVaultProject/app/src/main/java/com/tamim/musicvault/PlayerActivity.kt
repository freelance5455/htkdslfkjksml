package com.tamim.musicvault

import android.content.Intent
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private lateinit var uri: String
    private lateinit var title: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        uri = intent.getStringExtra("uri") ?: run { finish(); return }
        title = intent.getStringExtra("title") ?: "Video"

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.BLACK)
        }
        val playerView = PlayerView(this).apply {
            useController = true
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        val backgroundButton = Button(this).apply {
            text = "Play audio in background"
            setOnClickListener {
                val serviceIntent = Intent(this@PlayerActivity, AudioPlaybackService::class.java).apply {
                    action = AudioPlaybackService.ACTION_PLAY
                    putExtra(AudioPlaybackService.EXTRA_URI, uri)
                    putExtra(AudioPlaybackService.EXTRA_TITLE, title)
                }
                ContextCompat.startForegroundService(this@PlayerActivity, serviceIntent)
                player?.pause()
                text = "Background audio started — screen can turn off"
            }
        }
        root.addView(playerView)
        root.addView(backgroundButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)

        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.setMediaItem(MediaItem.fromUri(uri))
            exo.prepare()
            exo.playWhenReady = true
        }
    }

    override fun onStop() {
        player?.release(); player = null
        super.onStop()
    }
}
