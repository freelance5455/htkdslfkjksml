package com.hussain.wifitools;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.wifi.WifiManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiConfiguration;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.location.LocationManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.content.Intent;
import android.provider.Settings;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;
    private WifiManager wifi;
    private static final int REQ_PERMS = 44;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        web = new WebView(this);
        web.setBackgroundColor(0xFF07130F);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "NativeWifi");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        askPermissions();
    }

    private void askPermissions() {
        if (Build.VERSION.SDK_INT >= 23) {
            String[] p = new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
            if (checkSelfPermission(p[0]) != PackageManager.PERMISSION_GRANTED)
                requestPermissions(p, REQ_PERMS);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (web != null) web.evaluateJavascript("refreshWifi()", null);
    }

    public class Bridge {
        @JavascriptInterface public String wifiInfo() {
            try {
                WifiInfo info = wifi.getConnectionInfo();
                String ssid = info.getSSID();
                if (ssid == null || ssid.equals("<unknown ssid>")) ssid = "Not available";
                int rssi = info.getRssi();
                int level = WifiManager.calculateSignalLevel(rssi, 5);
                int ip = info.getIpAddress();
                String ipStr = String.format(Locale.US, "%d.%d.%d.%d", ip & 0xff, (ip >> 8) & 0xff, (ip >> 16) & 0xff, (ip >> 24) & 0xff);
                ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo ni = cm.getActiveNetworkInfo();
                boolean online = ni != null && ni.isConnected();
                return "{\"ssid\":\""+esc(ssid)+"\",\"rssi\":"+rssi+",\"level\":"+level+",\"ip\":\""+ipStr+"\",\"online\":"+online+",\"linkSpeed\":"+info.getLinkSpeed()+"}";
            } catch (Exception e) { return "{\"error\":\"Wi-Fi information unavailable. Check permissions and Wi-Fi.\"}"; }
        }
        @JavascriptInterface public String scanWifi() {
            try {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                    return "{\"error\":\"Location permission required for Wi-Fi scanning on this Android version.\"}";
                LocationManager lm = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
                if (Build.VERSION.SDK_INT >= 23 && !lm.isLocationEnabled())
                    return "{\"error\":\"Turn on Location to scan nearby Wi-Fi networks.\"}";
                wifi.startScan();
                List<ScanResult> results = wifi.getScanResults();
                StringBuilder b = new StringBuilder("{\"networks\":[");
                boolean first = true;
                for (ScanResult r : results) {
                    if (!first) b.append(",");
                    first = false;
                    b.append("{\"ssid\":\"").append(esc(r.SSID)).append("\",\"bssid\":\"").append(esc(r.BSSID))
                     .append("\",\"rssi\":").append(r.level).append(",\"frequency\":").append(r.frequency)
                     .append(",\"security\":\"").append(esc(r.capabilities)).append("\"}");
                }
                b.append("]}");
                return b.toString();
            } catch (Exception e) { return "{\"error\":\"Wi-Fi scan failed. Android may restrict scan frequency.\"}"; }
        }
        @JavascriptInterface public void openWifiSettings() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)));
        }
        @JavascriptInterface public void openAppSettings() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                android.net.Uri.parse("package:" + getPackageName()))));
        }
        private String esc(String s) {
            if (s == null) return "";
            return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n"," ").replace("\r"," ");
        }
    }
}
