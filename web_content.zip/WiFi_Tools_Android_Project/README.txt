WiFi Tools Android Project (starter source)
==========================================
This ZIP contains an Android Studio project source, not a ready-built APK.

Implemented in source:
- Dark neon dashboard
- Native Android current Wi-Fi connection info (SSID, RSSI, local IP, reported link speed)
- Nearby Wi-Fi scan via Android WifiManager (subject to permission, Location setting and OS restrictions)
- Wi-Fi settings shortcut
- Online speed estimate and basic connectivity check (uses Cloudflare endpoints)
- Local-only password strength estimate
- Network details view
- No app account, no app-side history storage, no Wi-Fi password upload

Limitations:
- The app does NOT reveal saved Wi-Fi passwords or hack Wi-Fi networks.
- Connected-device discovery is not implemented as a full router inventory; the screen explicitly says so.
- Wi-Fi scan results vary by Android version/manufacturer and may be throttled.
- Speed test is a rough estimate, not a certified benchmark.
- No APK was built or installed/tested in this environment. Source compilation and device testing remain necessary.
- Gradle wrapper is not included; open in Android Studio or a compatible Android IDE with internet access to download Gradle/Android Gradle Plugin.

Build:
1. Extract ZIP.
2. Open the WiFi_Tools_Android_Project folder in Android Studio/compatible Android IDE.
3. Let Gradle sync and install required Android SDK (compile SDK 35).
4. Build > Build APK(s).
5. Install the APK on your own phone and grant Location permission for Wi-Fi scanning; enable Location services if required.
