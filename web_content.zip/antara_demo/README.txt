ANTARA Demo

1. Extract this ZIP file.
2. Open antara_demo.html in Chrome.
3. Register, then log in.
4. Open Website Shortcuts to see visual shortcut cards for Aadhaar/UIDAI, myAadhaar, NPCI, and Google.

This is a local demo only. Wallet balance and recharge are simulated; no real payment or recharge occurs. Use only official websites and never enter Aadhaar numbers or OTPs into this demo.
