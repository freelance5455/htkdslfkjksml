package com.tsb.pingbooster;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.content.pm.PackageManager;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int OVERLAY_REQUEST = 4401;
    private static final int NOTIFICATION_REQUEST = 4402;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF080B16);
        Button overlay = new Button(this);
        overlay.setText("Запустить плавающее окно TSB поверх Roblox");
        overlay.setOnClickListener(v -> enableOverlay());
        root.addView(overlay, new LinearLayout.LayoutParams(-1, -2));
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface public void startFloating() { runOnUiThread(() -> enableOverlay()); }
        }, "TSBAndroid");
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        webView.loadUrl("file:///android_asset/index.html");

        // Первый запуск: сразу открыть системную страницу разрешения поверх других приложений.
        // Если разрешение уже выдано, повторно настройки не открываем.
        boolean alreadyAsked = getPreferences(MODE_PRIVATE).getBoolean("overlay_permission_prompted", false);
        if (!alreadyAsked && Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            getPreferences(MODE_PRIVATE).edit().putBoolean("overlay_permission_prompted", true).apply();
            new Handler(Looper.getMainLooper()).postDelayed(this::openOverlayPermissionSettings, 500);
        }
    }

    private void enableOverlay() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            openOverlayPermissionSettings();
            Toast.makeText(this, "Разреши отображение поверх других приложений, затем вернись в TSB", Toast.LENGTH_LONG).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, NOTIFICATION_REQUEST);
            return;
        }
        startFloatingService();
    }

    private void startFloatingService() {
        try {
            Intent service = new Intent(this, FloatingPingService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
            Toast.makeText(this, "Плавающее окно TSB запущено", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось запустить окно TSB: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void openOverlayPermissionSettings() {
        try {
            Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(permission, OVERLAY_REQUEST);
        } catch (Exception e) {
            // Резервный вариант для прошивок, которые не поддерживают адресную страницу приложения.
            try {
                startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION), OVERLAY_REQUEST);
            } catch (Exception ignored) {
                Toast.makeText(this, "Открой настройки и разреши TSB показываться поверх других приложений", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQUEST) {
            if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) {
                enableOverlay();
            } else {
                Toast.makeText(this, "Разреши TSB показываться поверх других приложений и нажми кнопку запуска", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATION_REQUEST) {
            // Запуск foreground service продолжается и при отказе в уведомлениях.
            startFloatingService();
        }
    }
}
