package com.tsb.pingbooster;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class FloatingPingService extends Service {
    private static final String CHANNEL = "tsb_floating_monitor";
    private WindowManager windowManager;
    private View bubble;
    private TextView pingText, stateText;
    private ScheduledExecutorService scheduler;
    private volatile boolean running = true;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification = new Notification.Builder(this, CHANNEL)
                .setContentTitle("TSB Ping Booster работает")
                .setContentText("Плавающий монитор задержки активен")
                .setSmallIcon(android.R.drawable.stat_notify_sync_noanim)
                .setContentIntent(pi).setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(22, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(22, notification);
        showBubble();
        scheduler = Executors.newSingleThreadScheduledExecutor();
        scheduler.scheduleAtFixedRate(this::measure, 0, 3, TimeUnit.SECONDS);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "TSB floating monitor", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private void showBubble() {
        windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(18, 12, 18, 12);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xEE101A31); bg.setCornerRadius(28); bg.setStroke(2, 0xFF36DDF5);
        box.setBackground(bg);
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = new TextView(this); brand.setText("● TSB  PING"); brand.setTextColor(0xFF45E5FF); brand.setTypeface(null, Typeface.BOLD); brand.setTextSize(13);
        Button close = new Button(this); close.setText("×"); close.setTextSize(16); close.setMinWidth(42); close.setMinHeight(38);
        close.setOnClickListener(v -> stopSelf());
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1)); header.addView(close);
        pingText = new TextView(this); pingText.setText("— ms"); pingText.setTextColor(Color.WHITE); pingText.setTextSize(25); pingText.setTypeface(null, Typeface.BOLD);
        stateText = new TextView(this); stateText.setText("Подключение…"); stateText.setTextColor(0xFFB8C8E8); stateText.setTextSize(12);
        TextView hint = new TextView(this); hint.setText("HTTP до Google • не ping Roblox"); hint.setTextColor(0xFF8FA2C5); hint.setTextSize(9);
        box.addView(header); box.addView(pingText); box.addView(stateText); box.addView(hint);
        final WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START; p.x = 20; p.y = 180;
        box.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY; float downX, downY;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) { startX=p.x; startY=p.y; downX=e.getRawX(); downY=e.getRawY(); return true; }
                if (e.getAction() == MotionEvent.ACTION_MOVE) { p.x=startX+(int)(e.getRawX()-downX); p.y=startY+(int)(e.getRawY()-downY); windowManager.updateViewLayout(box,p); return true; }
                return e.getAction()==MotionEvent.ACTION_UP;
            }
        });
        bubble = box;
        try { windowManager.addView(bubble, p); } catch (Exception e) { stopSelf(); }
    }

    private void measure() {
        long start = System.nanoTime(); int code = -1; String error = null;
        HttpURLConnection conn = null;
        try {
            URL url = new URL("https://www.google.com/generate_204?ts=" + System.currentTimeMillis());
            conn = (HttpURLConnection)url.openConnection(); conn.setConnectTimeout(2500); conn.setReadTimeout(2500); conn.setRequestMethod("GET");
            code = conn.getResponseCode();
            long ms = TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-start);
            updateUi(ms, code >= 200 && code < 500 ? "Ответ сервера • HTTP " + code : "HTTP " + code);
        } catch (Exception e) { error = e.getClass().getSimpleName(); updateUi(-1, "Нет ответа • " + error); }
        finally { if (conn != null) conn.disconnect(); }
    }

    private void updateUi(long ms, String state) {
        if (pingText == null) return;
        pingText.post(() -> { if (pingText != null) { pingText.setText(ms >= 0 ? ms + " ms" : "— ms"); stateText.setText(state); } });
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public void onDestroy() {
        running = false;
        if (scheduler != null) scheduler.shutdownNow();
        if (windowManager != null && bubble != null) try { windowManager.removeView(bubble); } catch (Exception ignored) {}
        bubble = null; super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
