CLASSCHECK PHOTO PICKER FIX
1. Extract the ZIP using your phone's Files app.
2. Open the extracted folder and tap index.html.
3. If it opens in a preview app, choose Open with > Chrome.
4. Login as Admin (initial demo password: AdminChange123!).
5. Go to Students & Accounts > Choose photo from phone.
6. Select Gallery/Photos/Files and choose a JPG or PNG.
7. Confirm the selected filename appears, then Create account.

If tapping Choose photo still does nothing, the HTML is likely being opened in a file preview/in-app viewer that blocks file selection. Open it in Chrome instead. This prototype stores data only in that browser/device; it is not a secure multi-device production system.
