LEVELUP — SELF DEVELOPMENT APP

Included: Fitness and workout logging, water counter, protein logging, food/junk-food log, homework/extra/foundation study checklist, self-improvement practice checklist, skill list, and skill work log.

HOW TO USE
1. Open index.html in a modern browser (Chrome recommended).
2. The app saves your progress in that browser on that device using local storage.
3. On Android Chrome, open the page and use the browser menu (⋮) > Add to Home screen / Install app if available.

ABOUT APK
This package is a working offline-friendly web app, not a compiled Android APK. Building a real APK requires Android build tooling/signing which is not available in this environment. You can use the app in Chrome or package it as an APK later using Android Studio/Capacitor.

Privacy: your entries stay in the browser storage on your device; this app does not send data to a server. Clearing browser site data may erase saved entries.
