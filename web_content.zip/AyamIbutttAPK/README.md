# Ayam Ibuttt — Android App

Project Android Studio untuk membungkus sistem dashboard Ayam Ibuttt yang sudah dibuat menjadi aplikasi Android offline berbasis WebView.

Fitur yang dibawa dari sistem HTML:
- Dashboard omzet, laba, ayam terjual, transaksi
- Penjualan
- Stok
- Pengeluaran
- Laporan
- Menu & Harga
- Penyimpanan data lokal melalui localStorage/DOM Storage

## Cara build APK
1. Buka folder ini di Android Studio.
2. Tunggu Gradle Sync selesai.
3. Pilih Build > Build APK(s).
4. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

Catatan: environment ChatGPT ini tidak memiliki Android SDK/Gradle sehingga APK binary tidak dapat dikompilasi langsung di sini. Source project sudah disiapkan untuk build.
