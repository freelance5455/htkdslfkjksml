Rajmarg Runner - AppsGeyser Web/HTML ZIP

Upload this ZIP as a complete HTML/ZIP web project if AppsGeyser offers a ZIP upload option.
Entry file: index.html
The game includes its Three.js engine inline; three.min.js is included as a companion file.
