HYPER PANEL 2.0 — NEON MOR / FUŞYA PREMIUM

Bu ZIP Android Studio ile açılabilen Android WebView projesidir. APK değildir.

101 ÖZELLİK MERKEZİ
- Ana menüde özellik kartları görünür.
- 101 Özellik sekmesinde 101 modülün tamamı listelenir.
- Üst gezinme çubuğundaki “Özellik seç” listesinden bir özelliğe doğrudan geçilir.
- Özellik arama ve kategori filtreleme bulunur.
- Özellik kartları ilgili uygulama bölümüne yönlendirir; hızlı hesap/gelir/gider/satış kısayolları ilgili mevcut formları açar.

MEVCUT İŞLEVLER
Gelir-gider kayıtları, hesap/stok yönetimi, satış akışı, satış geçmişi, raporlar, takvim, çöp kutusu, JSON yedekleme/geri yükleme, PIN ve çevrimdışı PWA desteği.

GÜVENLİK NOTU
Veriler cihazın yerel depolamasında tutulur. PIN ve hesap giriş bilgileri bu sürümde şifreli kasa değildir. Hassas şifreleri saklarken dikkatli ol.

DERLEME
Projeyi Android Studio'da aç, Gradle eşitlemesini tamamla ve APK'yı kendin derle. Gerçek cihazda kurulum ve iş akışı testi yap.
