package com.hyperpanel.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  WebView w=new WebView(this); setContentView(w);
  WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
  w.loadUrl("file:///android_asset/index.html");
 }
 @Override public void onBackPressed(){ super.onBackPressed(); }
}