JAAT KA PDF - HTML VERSION

HOW TO USE
1. Extract this ZIP file.
2. Open index.html in Chrome on Android or any modern browser.
3. Tap SELECT PHOTOS and choose one or more images.
4. Tap CREATE PDF.
5. In the print screen, choose "Save as PDF" and save the file.

TO MAKE AN ANDROID APK
Import this HTML into an Android WebView project or use an HTML-to-APK builder that supports local HTML assets.
Keep index.html as the app's local start page.

NOTE
The PDF export uses the browser's built-in Print / Save as PDF feature.
For best results, use Chrome and choose A4 paper if that setting is shown.
