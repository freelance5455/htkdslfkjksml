require("dotenv").config();
const express = require("express");
const path = require("path");
const OpenAI = require("openai");

const app = express();
const port = process.env.PORT || 3000;
const client = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

app.use(express.json({ limit: "12mb" }));
app.use(express.static(path.join(__dirname, "public")));

const MASTER = `
You are RIA, an advanced AI assistant with three core platforms: Agriculture, Health & Food, and Study.
You can also answer general questions. Follow the RIA master instructions:
- Be accurate, useful, transparent about uncertainty.
- Answer simply first, then add detail.
- Never invent facts, tests, diagnoses, certifications, yields, or guarantees.
- Health: education only, not diagnosis; urgent symptoms need professional care.
- Agriculture: image identification is preliminary; don't invent chemical labels or guaranteed treatments.
- Study: teach step-by-step; don't help cheat on active assessments.
Preferred response structure:
SUMMARY
WHAT I SEE / UNDERSTAND
ANSWER
NEXT STEP
For health/safety topics, include SAFETY NOTE.
`;

function demoReply(platform, question) {
  const label = platform === "agriculture" ? "Agriculture" :
    platform === "health-food" ? "Health & Food" :
    platform === "study" ? "Study" : "General";
  return `RIA Demo Mode — ${label}

SUMMARY
I received: “${question}”

ANSWER
Your RIA interface is working. Connect an OpenAI API key in .env to enable live AI answers, web grounding, and scanner analysis.

NEXT STEP
Ask the same question after adding your API key.`;
}

async function runAI({platform, question, imageDataUrl}) {
  if (!client) return demoReply(platform, question || "Analyze this");

  const context = platform === "agriculture" ? "The user is in the Agriculture platform." :
    platform === "health-food" ? "The user is in the Health & Food platform." :
    platform === "study" ? "The user is in the Study platform." :
    "The user is in General AI mode.";

  const input = [{ role: "user", content: [
    { type: "input_text", text: `${context}\n\nUser request:\n${question || "Analyze the supplied image."}` },
    ...(imageDataUrl ? [{ type: "input_image", image_url: imageDataUrl }] : [])
  ]}];

  const tools = [];
  if (String(process.env.ENABLE_WEB_SEARCH).toLowerCase() === "true") {
    tools.push({ type: "web_search_preview" });
  }
  if (process.env.OPENAI_VECTOR_STORE_ID) {
    tools.push({
      type: "file_search",
      vector_store_ids: process.env.OPENAI_VECTOR_STORE_ID.split(",").map(s => s.trim()).filter(Boolean)
    });
  }

  const response = await client.responses.create({
    model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
    instructions: MASTER,
    input,
    ...(tools.length ? { tools } : {})
  });

  return response.output_text || "RIA could not produce a response.";
}

app.post("/api/chat", async (req, res) => {
  try {
    const { platform = "general", question = "" } = req.body || {};
    if (!question.trim()) return res.status(400).json({ error: "Question is required." });
    const answer = await runAI({ platform, question });
    res.json({ answer });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "RIA AI request failed. Check your API key, model name, and server log." });
  }
});

app.post("/api/scan", async (req, res) => {
  try {
    const { platform = "general", question = "", imageDataUrl } = req.body || {};
    if (!imageDataUrl) return res.status(400).json({ error: "No scanner image was supplied." });
    const answer = await runAI({
      platform,
      question: question || "Scan this image. Extract what you can see, explain it in the selected platform, and clearly state uncertainty.",
      imageDataUrl
    });
    res.json({ answer });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Scanner analysis failed. Check your API key, model vision support, and server log." });
  }
});

app.get("*", (_, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(port, () => console.log(`RIA AI running at http://localhost:${port}`));
