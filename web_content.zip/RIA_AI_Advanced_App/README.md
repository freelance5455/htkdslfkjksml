# RIA AI — Advanced 3-Platform Prototype

RIA is a web app prototype with three primary interfaces:
- Agriculture
- Health & Food
- Study

It also includes:
- General AI mode
- Image/document scanner interface using camera or file upload
- OCR-ready image pipeline
- AI image analysis endpoint
- Voice input button using the browser Speech Recognition API when supported
- Conversation history in the browser
- Quick actions for each platform
- Optional web grounding
- Optional private vector-store grounding
- Server-side API key handling

## Run
1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Put your API key in `.env`.
6. Set `OPENAI_MODEL` to a model available to your API account.
7. Run `npm start`.
8. Open http://localhost:3000

## Demo mode
If no API key is configured, the interface still runs and provides a local demo response. The real AI/scanner analysis requires an API key.

## Scanner
On a phone, use the Scanner screen and choose the camera option. The browser will provide camera capture where supported. The selected image is sent to the server for model vision analysis.

Never upload passwords, payment cards, private credentials, or other sensitive documents to an AI scanner.
