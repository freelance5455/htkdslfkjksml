"""Build self-contained subject-specific v13 lessons from the reviewed learning outline.
All originals keep IDs, saved quiz progress, and order; v13 appends new IDs only."""
from pathlib import Path
from collections import Counter
import json
ROOT=Path(__file__).resolve().parent.parent
records=[]
for i,line in enumerate((ROOT/'authoring/v13_outline.txt').read_text().splitlines(),1):
    if not line.strip() or line.startswith('#'):continue
    parts=line.strip().split('|')
    if len(parts)!=5:raise ValueError(f'line {i}: expected 5 fields, got {len(parts)}')
    sub,stage,title,concept,task=parts
    if stage not in ['B','I','A'] or any(len(x)<12 for x in [title,concept,task]):raise ValueError(f'invalid {i}')
    records.append({'sub':sub,'stage':stage,'title':title,'concept':concept,'task':task})
assert len(records)==423,len(records)
assert len(set(r['title'] for r in records))==len(records)
counts=Counter(r['sub'] for r in records)
assert len(counts)==36
js = r'''/* Loonie Academy v13 | authored extension: 423 topic-specific learning modules.
 * Append-only IDs. Legacy lesson IDs, state, quiz scoring and save format remain untouched. */
(function(){
"use strict";
const ROWS = __ROWS__;
const SHIELD = new Set(['safety','elec','weld','pipe','het','auto','inst','hvac','oilf','pweng','crane','mill','carp','mfg','avia','hlth']);
const LEVELS={B:'Beginner',I:'Intermediate',A:'Advanced'};
const esc13=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
const bySub={};for(const row of ROWS)(bySub[row.sub]||(bySub[row.sub]=[])).push(row);
const existing=new Set(LESSONS.map(l=>l.title.toLowerCase().trim()));
const added={};let id=Math.max(...LESSONS.map(l=>l.id));
for(const r of ROWS){
  const subj=SUBJ(r.sub);if(!subj)throw new Error('V13 unknown subject '+r.sub);
  if(existing.has(r.title.toLowerCase().trim()))throw new Error('V13 duplicate lesson '+r.title);
  existing.add(r.title.toLowerCase().trim());
  r.id=++id;r.lv=LEVELS[r.stage];
  const peer=bySub[r.sub].filter(x=>x.title!==r.title);
  const ix=peer.findIndex(x=>x.stage===r.stage);const others=peer.length>=3? [peer[ix<0?0:ix%peer.length],peer[(ix+7)%peer.length],peer[(ix+13)%peer.length]]:peer;
  // Answer texts are sourced from distinct topics within the SAME subject.
  const different = items => [...new Set(items.filter(x=>x&&x!==items[0]))].slice(0,3);
  const wrongFacts=different([null,...others.map(x=>x.concept)]);
  const wrongTasks=different([null,...others.map(x=>x.task)]);
  while(wrongFacts.length<3)wrongFacts.push('A different topic that does not explain the specific question.');
  while(wrongTasks.length<3)wrongTasks.push('A different kind of practice activity.');
  const safety=SHIELD.has(r.sub)?`<div class="box warn"><span class="lbl">🛡️ Learning safely</span><p>${r.sub==='hlth'?'This is educational health science, not medical advice or a diagnostic tool.':r.sub==='avia'?'Conceptual aviation material is not pilot instruction or authorization to operate equipment.':'This is theory and simulated analysis. Do not perform energized, pressurized, hazardous, regulated or elevated work without proper training, authorization and current procedures.'}</p></div>`:'';
  const body=`<div class="box kid"><span class="lbl">🎯 Your learning goal</span><p>Explain <strong>${esc13(r.title)}</strong>, apply the idea to a realistic decision, and identify information you would need before making a real-world claim.</p></div>
   <h3>The important idea</h3><p>${esc13(r.concept)}</p>
   <div class="box ex"><span class="lbl">🧭 Guided application</span><p>${esc13(r.task)}</p><ol><li>Describe what the problem is asking and list the evidence or inputs needed.</li><li>Connect the problem to the principle: <strong>${esc13(r.concept)}</strong></li><li>Explain your proposed approach, stating any assumptions that could change the result.</li><li>Check the result against the constraints and record anything that still needs expert or source verification.</li></ol></div>
   <h3>Work it through</h3><div class="box tip"><span class="lbl">✍️ Practice before revealing</span><p>${esc13(r.task)}</p><details class="deep"><summary>Reveal the model reasoning</summary><p>A well-supported answer should begin with this principle: ${esc13(r.concept)} The next step is to use that principle on the stated task, check supporting measurements or sources, and explain limitations instead of guessing.</p></details></div>
   <h3>Go beyond memorization</h3><p>What new evidence might change your answer? What important assumption could be false? Write a short reflection or explain the concept aloud to Lou, then try a changed scenario with different inputs.</p>
   ${safety}<div class="terms"><span>${esc13(r.lv)} theory</span><span>Applied reasoning</span><span>Evidence check</span></div>`;
  const quiz=[
    {q:`Which statement best explains “${r.title}”?`,o:[r.concept,...wrongFacts],a:0,why:r.concept},
    {q:`Which practice task most directly applies “${r.title}”?`,o:[r.task,...wrongTasks],a:0,why:`The correct application is: ${r.task} The key reason is: ${r.concept}`},
    {q:`You're writing an evidence-based answer about “${r.title}”. What should you do?`,o:[`Link the conclusion to the relevant principle and verify assumptions and evidence.`,`State the conclusion confidently even if the evidence is missing.`,`Copy an unrelated explanation and change its title.`,`Treat the first guess as a confirmed finding.`],a:0,why:`Apply the specific principle carefully: ${r.concept}`},
    {q:`What best demonstrates advanced understanding of “${r.title}”?`,o:[`Apply the idea, justify the choice, and explain its limits.`,`Memorize the heading without using the concept.`,`Ignore competing interpretations and changing conditions.`,`Use an unsupported result simply because it looks plausible.`],a:0,why:`Use this practice prompt to prove your understanding: ${r.task}`}
  ];
  // Do not put all right answers in option A. Deterministically rotate choices per item.
  quiz.forEach((item,j)=>{const shift=(r.id*7+j*3)%4;item.o=item.o.slice(shift).concat(item.o.slice(0,shift));item.a=(4-shift)%4;});
  LESSONS.push({id:r.id,lv:r.lv,icon:subj.icon||'📘',mins:r.stage==='A'?19:r.stage==='I'?16:13,title:r.title,sub:r.concept.slice(0,138),body,quiz});
  KEYS[r.id]=[r.concept,`Practice: ${r.task}`,`Before applying: verify evidence, assumptions, and context.`];
  if(!added[r.sub])added[r.sub]={B:[],I:[],A:[]};added[r.sub][r.stage].push(r.id);
  GLOSSARY.push([r.title,r.concept,subj.name]);
}
// Do not reorder old units: career-v11 uses existing positional lesson references.
// New modules attach in parallel; the v13 course UI displays a pedagogical level-based sequence.
for(const [sid,stages] of Object.entries(added)){
 const s=SUBJ(sid);
 for(const [stage,label] of [['B','Foundation studio'],['I','Applied workshop'],['A','Advanced investigations']]){
   const ids=stages[stage];if(ids.length)s.units.push([label+' · v13',ids]);
 }
}
window.LOONIE_CURRICULUM_V13={version:13,count:ROWS.length,bySubject:Object.fromEntries(Object.entries(added).map(([k,v])=>[k, v.B.length+v.I.length+v.A.length])),stages:added,validate:()=>{
 const issues=[];const counts=SUBJECTS.map(s=>({id:s.id,name:s.name,count:subjIds(s).length,levels:Object.fromEntries(['Beginner','Intermediate','Advanced'].map(l=>[l,subjIds(s).filter(id=>LEVEL(id)===l).length]))}));
 if(LESSONS.length!==807)issues.push('Lesson count '+LESSONS.length+' expected 807');
 if(SUBJECTS.length!==37)issues.push('Expected 37 subjects');
 if(counts.some(s=>s.count<20))issues.push('Some subjects still have fewer than 20 lessons');
 const ids=LESSONS.map(l=>l.id);if(new Set(ids).size!==ids.length)issues.push('Duplicate IDs');
 if(LESSONS.some(l=>l.quiz.length<4))issues.push('Unexpectedly short quiz');
 return {ok:!issues.length,issues,lessons:LESSONS.length,subjects:SUBJECTS.length,questions:LESSONS.reduce((x,l)=>x+l.quiz.length,0),counts};
}};
})();'''.replace('__ROWS__',json.dumps(records,ensure_ascii=False,separators=(',',':')))
(ROOT/'curriculum-v13.js').write_text(js)
print('Wrote',len(records),'new lessons and',(ROOT/'curriculum-v13.js').stat().st_size,'bytes')
