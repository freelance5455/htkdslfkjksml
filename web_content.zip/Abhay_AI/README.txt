ABHAY AI - HTML TO APK

Admin Panel:
Username: AbhayGaming
Password: 2074

Open Admin: long-press the round RGB logo for about 2 seconds.

Admin can edit:
- Welcome message
- Abhay information
- Website
- Telegram
- YouTube
- Instagram
- Facebook
- WhatsApp
- Logo photo URL

Important: this is an HTML-only local admin panel. It stores edits in localStorage on the device. It is not a secure server-side admin system.

The chat UI and voice input/output are included. For real AI answers, connect a secure backend/API later.
