# Ridgeline on Android

The game can run on Android in two ways:

1. **Install the web app (no build tools required).** Open the hosted page in Chrome and choose
   **Get app → Install on this device** (or Chrome’s ⋮ menu → **Install app**). It gets a home-screen
   icon, a fullscreen standalone window, safe-area handling, and offline play. This is the fastest way
   to play on a phone.
2. **Compile a native APK.** A complete [Capacitor 7](https://capacitorjs.com) Android project lives in
   `android/`, branded with a custom launcher icon, splash screens and a dark theme.

This repository is a web project, so the APK itself is produced by Gradle on your machine — Android
SDKs and a JDK cannot ship inside the project. The project is already generated and synced, so the
commands below are all you need.

## Requirements

| Tool | Version |
| --- | --- |
| Node.js | 20 or newer |
| JDK | 21 (the JDK bundled with Android Studio works) |
| Android SDK | API 35 platform + build tools |
| Gradle | provided by `android/gradlew` |

## Build a debug APK

```bash
npm install
npm run build
npx cap sync android
cd android
./gradlew assembleDebug
```

The APK is written to `android/app/build/outputs/apk/debug/app-debug.apk`.

Or use the helper script from the project root:

```bash
./scripts/build-android.sh
```

It builds the web bundle, syncs Capacitor, compiles the APK and copies it to
`ridgeline-debug.apk` in the project root.

Install it on a device with USB debugging enabled:

```bash
adb install -r ridgeline-debug.apk
```

### Android Studio (alternative)

1. Open the `android/` folder in Android Studio.
2. Let Gradle sync (accept any SDK download prompts).
3. Choose **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
4. Click **Locate** in the success notification.

## Build a signed release APK / AAB

```bash
keytool -genkeypair -v -keystore ridgeline.keystore \
  -alias ridgeline -keyalg RSA -keysize 2048 -validity 10000
```

Add a signing config to `android/app/build.gradle`:

```gradle
android {
  signingConfigs {
    release {
      storeFile file("../../ridgeline.keystore")
      storePassword System.getenv("RIDGELINE_STORE_PASSWORD")
      keyAlias "ridgeline"
      keyPassword System.getenv("RIDGELINE_KEY_PASSWORD")
    }
  }
  buildTypes {
    release {
      signingConfig signingConfigs.release
      minifyEnabled false
    }
  }
}
```

Then:

```bash
./scripts/build-android.sh --release   # APK
./scripts/build-android.sh --bundle    # AAB for Google Play
```

Keep the keystore and passwords out of version control.

## Project details

| Item | Value |
| --- | --- |
| App ID | `club.ridgeline.game` |
| App name | Ridgeline |
| Version | 1.0.0 (versionCode 1) |
| Web directory | `dist` (single-file build) |
| Config | `capacitor.config.ts` |
| Theme | dark `#080d0a`, edge-to-edge splash + launcher icon |
| Orientation | sensor / any (portrait and landscape layouts are supported) |

Native behaviour included:

- Hardware **Back** closes menus, pauses an active hunt, or exits from camp.
- The hunt auto-pauses when the app goes to the background.
- Immersive dark status/navigation bars and Android safe-area padding.
- `largeHeap` + hardware acceleration for the WebGL renderer.

To change icons or splash art, replace the PNGs in
`android/app/src/main/res/mipmap-*` and `android/app/src/main/res/drawable*`.
Web/PWA icons live in `public/icons/`.

## Refresh after web changes

```bash
npm run build && npx cap sync android
```

`npx cap sync` copies the latest `dist/` bundle into the native project and updates plugins.

## Troubleshooting

- **`SDK location not found`** — create `android/local.properties` with `sdk.dir=/path/to/Android/Sdk`.
- **`Unsupported class file major version`** — use JDK 21 and set `JAVA_HOME`.
- **Blank WebGL view on an old device** — the game needs WebGL 2; most phones from 2018 onward are fine.
- **Touch controls missing** — they appear under 820px width or on coarse-pointer devices.
  Enable them on larger tablets from **Get app → Controls, maps & ammo**.

## Offline / PWA notes

`public/manifest.webmanifest` and `public/sw.js` provide installability and offline caching on the web.
The service worker is skipped inside the native app, where Capacitor already bundles every asset.
