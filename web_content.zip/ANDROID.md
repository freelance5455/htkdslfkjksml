# MICHILICIAS: GATITOS MÁGICOS — Guía para generar el APK de Android

## Estado honesto del proyecto
- El juego está completo y funcional como aplicación web (React + Vite + Tailwind).
- Está **preparado para Android con Capacitor** (`capacitor.config.ts`, `@capacitor/core` y `@capacitor/cli` ya instalados, nombre de app e icono configurados).
- **En este entorno de desarrollo NO hay Android SDK, JDK ni Gradle**, y no existe una terminal para ejecutar comandos, por lo que **el archivo .apk todavía no se ha compilado aquí**. Nadie debe afirmar lo contrario.
- Con los pasos de abajo, en un ordenador normal se genera el APK en unos 10–15 minutos.

## Requisitos en tu ordenador
1. **Node.js 18+** y el proyecto descargado.
2. **Android Studio** (incluye Android SDK y JDK 17). Descarga: https://developer.android.com/studio
3. (Opcional) Un teléfono Android con "Depuración USB" activada, o el emulador de Android Studio.

## Pasos exactos para compilar el APK
```bash
# 1. Instalar dependencias
npm install

# 2. Compilar la web (genera la carpeta dist/)
npm run build

# 3. Crear la plataforma Android (solo la primera vez)
npx cap add android

# 4. (Opcional, recomendado) Generar iconos y pantalla de inicio nativos
#    a partir de public/icon.png (512×512 o superior)
npm install -D @capacitor/assets
npx @capacitor/assets generate --android

# 5. Sincronizar la web dentro del proyecto Android
#    (repetir tras cada cambio del juego)
npx cap sync android

# 6a. Opción fácil: abrir en Android Studio y compilar
npx cap open android
#    En Android Studio: menú Build > Build App Bundle(s) / APK(s) > Build APK(s)
#    El APK queda en: android/app/build/outputs/apk/debug/app-debug.apk

# 6b. Opción automática con el teléfono conectado por USB:
npx cap run android
```

## Datos de la app ya configurados
- **Nombre visible:** MICHILICIAS: GATITOS MÁGICOS (`appName` en `capacitor.config.ts`)
- **ID de paquete:** `com.michilicias.gatitosmagicos`
- **Icono:** `public/icon.png` (gatita negra de ojos esmeralda). Para el lanzador de Android, el paso 4 genera todas las densidades.
- **Pantalla de inicio:** la app muestra su propia splash (logo + título) al abrir; con el paso 4 también se genera la splash nativa.
- **Sin conexión:** todo el juego (incluidos los artículos ya desbloqueados) funciona offline; el progreso se guarda en el almacenamiento local del WebView.

## Para publicar en Google Play (más adelante)
1. En Android Studio: Build > Generate Signed Bundle / APK, crea tu clave de firma (guárdala bien, es para siempre).
2. Genera un **AAB** (Android App Bundle) firmado y súbelo a Play Console.
3. Nunca subas el APK de depuración a la tienda.

## Conexión con la tienda web (códigos de regalo)
Flujo previsto y ya soportado por el código (`src/lib/codes.ts` → `GIFT_API`):
1. La tienda confirma el pago y registra el pedido.
2. El administrador genera el código (panel **Admin** del juego o el servidor de la tienda) y lo asocia al pedido.
3. El cliente recibe el código y lo canjea en el juego (botón **Códigos**).
4. El juego valida el código, registra el canje y entrega los regalos de forma permanente e idempotente (sin duplicados).

**Importante:** mientras la tienda no tenga servidor, el registro de códigos vive en el dispositivo donde se generaron. Para vender a clientes en otros teléfonos, la fuente de verdad debe ser el servidor: basta con poner la URL en `GIFT_API.baseUrl` y descomentar la llamada `fetch` incluida en `src/lib/codes.ts`. Ninguna contraseña administrativa ni clave secreta está guardada dentro del APK: el panel Admin guarda solo la huella (hash SHA-256) de la contraseña en el dispositivo del administrador.
