# ShifaCare Android app (APK)

The Android app is a native shell (Capacitor) that opens the live ShifaCare website. Content changes made in the admin dashboard appear in the app immediately; you only rebuild the APK when the app's own settings change.

## 1. Point the app at your live website

The app loads the URL in `CAPACITOR_SERVER_URL`. It must be the **public HTTPS address of your deployed ShifaCare website**. Phones cannot reach development or preview addresses, so a build made against a preview link will show an error screen.

```bash
export CAPACITOR_SERVER_URL=https://www.your-domain.ma
npx cap sync android
```

Deploy the website first (Node.js hosting with PostgreSQL, such as a VPS or a platform that supports Next.js), then build the APK against that domain.

## 1b. Offer the APK download on the website

1. Copy the release APK to a public folder of the deployed site, for example `public/downloads/shifacare-android-1.0.0.apk`.
2. Set `NEXT_PUBLIC_ANDROID_APK_URL=https://www.your-domain.ma/downloads/shifacare-android-1.0.0.apk` in `.env`, then rebuild the website.

Until that variable is set, the home page shows a "Get the app on WhatsApp" button instead.

## 2. Build requirements

- JDK 21 (`JAVA_HOME` pointing to it)
- Android SDK with platform 35 and build-tools 35.0.0 (`ANDROID_HOME`, or `android/local.properties` with `sdk.dir=...`)
- Android Studio is the easiest option, or use the command line below.

## 3. Build the APK

```bash
cd android
./gradlew assembleDebug     # test APK: android/app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease   # signed APK: android/app/build/outputs/apk/release/app-release.apk
```

Release builds are signed with `android/keys/shifacare-release.jks`, configured in `android/keystore.properties`.

> **Keep the keystore and `keystore.properties` safe and backed up.** If you lose them you cannot publish updates to the same app on Google Play. Never commit them to a public repository.

## 4. Install on a phone

Copy the APK to the phone (or download it from the website's home page), open it, allow installation from this source, then tap Install.

## 5. Publish on Google Play (optional)

Google Play requires an Android App Bundle (AAB) instead of an APK:

```bash
cd android && ./gradlew bundleRelease   # android/app/build/outputs/bundle/release/app-release.aab
```

Create a Google Play Console developer account, upload the `.aab`, and complete the store listing and privacy policy (the app processes health-related booking data).

## Changing the app icon or name

- Icon: replace the PNGs in `android/app/src/main/res/mipmap-*` (or regenerate them from `public/icons/icon-512.png`).
- Name: `capacitor.config.ts` (`appName`) and `android/app/src/main/res/values/strings.xml`.
- Package ID: `appId` in `capacitor.config.ts` (changing it after publishing creates a new app).
