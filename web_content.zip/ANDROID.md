# O Caminho do Poder — empacotamento Android

Jogo web (HTML5 + Canvas) empacotado em um app Android nativo com WebView.
**Sem dependências externas** (sem AndroidX, sem Cordova, sem Capacitor) → APK pequeno
(~170 KB) e inicialização instantânea, ideal para aparelhos de baixo desempenho.

```
android/
├── app/
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── java/br/com/caminhodopoder/MainActivity.java
│   │   └── res/  (ícones, cores, tema)
│   ├── build.gradle
│   └── proguard-rules.pro
├── build-apk.sh        ← build do APK sem Gradle (aapt2 + d8 + apksigner)
├── build.gradle
├── settings.gradle
└── gradle.properties
```

---

## 1. Gerar o APK pronto (recomendado — sem internet, sem Gradle)

Requisitos: **JDK 17** (`javac`, `keytool`) e **Android SDK** com
`build-tools;34.0.0` e `platforms;android-34`.

```bash
export ANDROID_HOME=$HOME/android-sdk
./android/build-apk.sh
```

O script executa:

| Etapa | Ferramenta | O que faz |
|---|---|---|
| 1 | `vite build` | gera `dist/index.html` (jogo completo em um arquivo) |
| 2 | `aapt2 compile` | compila `res/` (ícones, tema) |
| 3 | `aapt2 link` | gera o APK base e injeta `assets/www/` |
| 4 | `javac` | compila `MainActivity.java` |
| 5 | `d8` | converte as classes em `classes.dex` |
| 6 | `zipalign` | alinha o APK em blocos de 4 bytes |
| 7 | `apksigner` | assina o APK (v1 + v2 + v3) |

Saída: **`apk/O-Caminho-do-Poder-1.0.0.apk`** (~170 KB).

Instalar no aparelho:

```bash
adb install -r apk/O-Caminho-do-Poder-1.0.0.apk
```

> A chave de assinatura é gerada automaticamente em `android/build/release.keystore`
> (senha `caminho`). Guarde esse arquivo se quiser publicar atualizações — sem ele
> o Android não aceita o APK como atualização do anterior.

---

## 2. Gerar o APK pelo Android Studio / Gradle

```bash
cd android
gradle wrapper --gradle-version 8.5     # só na primeira vez
./gradlew assembleRelease
# saída: android/app/build/outputs/apk/release/app-release.apk
```

O Gradle copia `dist/` para `app/src/main/assets/www/` automaticamente
(tarefa `copyWebAssets`). Se alterar o jogo, rode antes:

```bash
npm install
npm run build
```

Depois abra a pasta `android/` no Android Studio e use *Build → Build Bundle(s)/APK(s)*.

---

## 3. Como o jogo roda dentro do app

* `MainActivity` cria um `WebView` em tela cheia imersiva, com:
  * JavaScript e **DOM Storage (localStorage) habilitados** → o save funciona;
  * `setMediaPlaybackRequiresUserGesture(false)` → a música ambiente toca;
  * `setTextZoom(100)` → a fonte do sistema não quebra o layout do jogo;
  * cache desligado e sem zoom por pinch.
* Os arquivos são servidos em `https://appassets.androidplatform.net/index.html`
  (interceptados por `shouldInterceptRequest`) para que o WebView trate o jogo como
  uma origem **https real** — é isso que garante que o `localStorage` (save) seja
  gravado em disco e sobreviva ao fechamento do app.
  Se algo falhar, há fallback automático para `file:///android_asset/www/index.html`.
* **Botão voltar do Android**: fecha primeiro dialogue/painel abertos
  (`window.__gameBack`) e só depois sai do app.
* **App em segundo plano**: `window.__gamePause()` salva o progresso e silencia a
  música; ao voltar, `window.__gameResume()` retoma a trilha.

---

## 4. Ajustes de desempenho para aparelhos fracos

O jogo já foi medido com CPU estrangulada (Chrome DevTools, 4× e 6×):

| Cenário | Resultado |
|---|---|
| Desktop 1280×720 | 60 fps (16,6 ms/quadro) |
| Celular 412×915, CPU 4× | 60 fps (16,6 ms/quadro) |
| Celular 412×915, CPU 6× | 60 fps (16,8 ms/quadro) |

Otimizações já aplicadas no jogo:

* canvas com resolução **lógica** fixa (480×272 no paisagem, 232×320 no retrato) e
  escala CSS com `image-rendering: pixelated` → menos pixels para rasterizar;
* mapa estático de cada área pré-renderizado em um canvas offscreen (só entidades,
  partículas e luz são redesenhados);
* camada de iluminação **reutilizada** e com sprites radiais pré-renderizados
  (sem `createRadialGradient` por quadro);
* sprites de personagens em cache (nada de redesenho de pixel art por quadro);
* limite de partículas (140) e de avisos em tela;
* laço de renderização com `requestAnimationFrame` e `delta` limitado (sem saltos
  ao voltar do segundo plano).

---

## 5. Permissões

O manifesto pede apenas `INTERNET` e `VIBRATE`. O jogo funciona **100% offline**:
todo o conteúdo (arte, som, missões) está dentro do APK.
