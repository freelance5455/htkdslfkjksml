# SPIRIT_PLAYZYT AI v1.3

A starter Android Studio project for a black/neon-purple personal assistant.

## Included in this project
- Text chat and Android speech recognition input.
- Android Text-to-Speech output with a best-effort female English voice selection (voice availability depends on the device's installed TTS engine and language packs).
- Friendly Jarvis greeting and selectable personality modes: Boss, Friend, Girlfriend-style fictional companion, and Familiar.
- Confirmation dialogs before opening Android Settings or launching an installed app.
- Configurable HTTPS AI backend endpoint.
- Voice provider preference (Android, Google Cloud TTS, ElevenLabs) and optional custom voice ID passed to the backend.

## Important: API keys
Google Cloud Text-to-Speech requires a Google Cloud API key or service-account-backed server authentication. ElevenLabs requires an ElevenLabs API key. **Configure provider credentials on your HTTPS backend as environment secrets. Do not hard-code keys into the APK, commit them to source control, or send them in chat.** A key embedded in an Android APK can be extracted. The Android app intentionally does not collect or store provider API keys.

The app sends this JSON to the configured backend:

```json
{
  "message": "User's message",
  "assistant": "SPIRIT_PLAYZYT AI",
  "personality": "friend",
  "voice_provider": "android",
  "voice_id": "optional-provider-voice-id"
}
```

The backend should return JSON containing a `reply` string. To enable Google/ElevenLabs audio, the backend must implement the selected provider, synthesize the response, and return a documented audio URL or audio payload; this starter client currently speaks replies with Android Text-to-Speech. Provider selection and voice ID are configuration metadata, not a completed remote audio playback integration.

## Backend security checklist
- Serve only over HTTPS.
- Store Google and ElevenLabs credentials in server-side secret storage/environment variables.
- Authenticate app requests and apply rate limits/usage limits.
- Never log API keys or full sensitive user prompts.
- Validate voice IDs and provider selection on the server.

## Build an APK
1. Open this folder in Android Studio.
2. Allow Gradle sync and install the Android SDK platform/build tools requested by the project.
3. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Android Studio will show the generated APK location after a successful build.

This is source code, not a precompiled or tested APK. Build and test it on a physical Android device before everyday use.


## Custom SPIRIT_PLAYZYT AI branding (v1.4)
- The supplied neon-purple SPIRIT_PLAYZYT AI artwork is included at `app/src/main/res/drawable-nodpi/spirit_playzyt_brand_logo.png`.
- The Android launcher icon now uses the matching purple character artwork in density-specific mipmap folders.
- Android 8+ adaptive launcher icon resources and a dark-purple background are included.
- The manifest now points to `@mipmap/ic_launcher`.

This remains an Android Studio source project, not a compiled APK. Build it with Android Studio and test the launcher icon on your device.


## Launcher icon update
The launcher icon and full branding artwork were updated using the exact image supplied by the user in this conversation. Rebuild the APK to see the new icon on the Android launcher.
