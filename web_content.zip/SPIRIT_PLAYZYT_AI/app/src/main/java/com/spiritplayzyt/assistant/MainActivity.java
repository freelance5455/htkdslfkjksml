package com.spiritplayzyt.assistant;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 42;
    private static final String PREFS = "spirit_settings";
    private LinearLayout messages;
    private EditText input;
    private ScrollView scroll;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private SharedPreferences prefs;
    private final ExecutorService network = Executors.newSingleThreadExecutor();
    private boolean speakReplies = true;
    private String pendingAction = "";
    private final int bg = Color.rgb(9, 7, 17);
    private final int panel = Color.rgb(22, 17, 34);
    private final int purple = Color.rgb(180, 92, 255);
    private final int white = Color.rgb(244, 239, 255);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) configureFemaleVoice();
        });
        buildUi();
        addMessage("SPIRIT_PLAYZYT AI", "Hey! I'm your friendly Jarvis-style assistant. I can chat, listen, speak, tell the time, and open apps after you confirm. Connect your private AI server in Settings for full AI answers.", false);
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
    }

    private void configureFemaleVoice() {
        tts.setLanguage(Locale.US);
        tts.setPitch(1.12f);
        tts.setSpeechRate(0.96f);
        try {
            for (Voice voice : tts.getVoices()) {
                String n = voice.getName().toLowerCase(Locale.ROOT);
                if (voice.getLocale().getLanguage().equals("en") && (n.contains("female") || n.contains("woman") || n.contains("samantha") || n.contains("zira"))) {
                    tts.setVoice(voice); break;
                }
            }
        } catch (Exception ignored) { }
    }

    private GradientDrawable shape(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius);
        if (stroke != 0) d.setStroke(2, stroke); return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18, 14, 18, 12); root.setBackgroundColor(bg);
        setContentView(root);
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout heading = new LinearLayout(this); heading.setOrientation(LinearLayout.VERTICAL);
        heading.addView(text("SPIRIT_PLAYZYT AI", 22, white, true));
        heading.addView(text(prefs.getString("personality", "Friend") .toUpperCase(Locale.ROOT) + " MODE  •  CUSTOM VOICE", 10, purple, true));
        header.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
        Button settings = button("⚙", false); header.addView(settings, new LinearLayout.LayoutParams(48, 46));
        settings.setOnClickListener(v -> showSettings()); header.setPadding(4, 8, 4, 14); root.addView(header);
        TextView orb = text("✦", 30, purple, true); orb.setGravity(Gravity.CENTER); orb.setBackground(shape(panel, 100, purple));
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(76, 76); op.gravity = Gravity.CENTER; op.bottomMargin = 12; root.addView(orb, op);
        scroll = new ScrollView(this); scroll.setFillViewport(false); scroll.setBackground(shape(panel, 22, 0));
        messages = new LinearLayout(this); messages.setOrientation(LinearLayout.VERTICAL); messages.setPadding(12, 12, 12, 12); scroll.addView(messages);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout controls = new LinearLayout(this); controls.setOrientation(LinearLayout.HORIZONTAL); controls.setGravity(Gravity.CENTER_VERTICAL); controls.setPadding(0, 12, 0, 0);
        input = new EditText(this); input.setSingleLine(true); input.setTextColor(white); input.setHintTextColor(0xFF9B91AA); input.setHint("Message your AI..."); input.setTextSize(14); input.setPadding(14, 10, 14, 10); input.setBackground(shape(panel, 18, 0));
        controls.addView(input, new LinearLayout.LayoutParams(0, 52, 1));
        Button mic = button("🎙", false); Button send = button("SEND", true);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(52, 52); bp.leftMargin = 7; controls.addView(mic, bp);
        bp = new LinearLayout.LayoutParams(76, 52); bp.leftMargin = 7; controls.addView(send, bp);
        root.addView(controls);
        mic.setOnClickListener(v -> startListening()); send.setOnClickListener(v -> sendTyped());
        input.setOnEditorActionListener((v, action, event) -> { sendTyped(); return true; });
    }
    private Button button(String label, boolean filled) {
        Button b = new Button(this); b.setText(label); b.setTextSize(12); b.setTextColor(white); b.setAllCaps(false);
        b.setBackground(shape(filled ? 0xFF7136B8 : panel, 18, filled ? 0 : purple)); return b;
    }
    private void addMessage(String who, String body, boolean user) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(12, 9, 12, 9); card.setBackground(shape(user ? 0xFF38204F : 0xFF171222, 16, user ? 0 : 0xFF382A4D));
        TextView name = text(who, 10, user ? 0xFFE0BFFF : purple, true); TextView msg = text(body, 14, white, false); msg.setPadding(0, 4, 0, 0);
        card.addView(name); card.addView(msg); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.bottomMargin = 9; messages.addView(card, p);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }
    private void sendTyped() {
        String q = input.getText().toString().trim(); if (q.isEmpty()) return;
        input.setText(""); ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(), 0); handleQuery(q);
    }
    private void handleQuery(String q) {
        addMessage("YOU", q, true);
        String lower = q.toLowerCase(Locale.ROOT).trim();
        if (lower.matches(".*\\b(hello|hi|hey)\\b.*")) reply("Hey there! What shall we do today?");
        else if (lower.contains("time")) reply("It's " + DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date()) + ".");
        else if (lower.contains("date") || lower.contains("day")) reply("Today is " + DateFormat.getDateInstance(DateFormat.FULL).format(new Date()) + ".");
        else if (lower.contains("your name") || lower.contains("who are you")) reply("I'm SPIRIT_PLAYZYT AI, your friendly personal assistant.");
        else if (lower.equals("cancel") || lower.equals("never mind")) { pendingAction = ""; reply("No problem. I cancelled that action."); }
        else if (lower.contains("open settings")) confirmAction("Open Android Settings?", "settings", "Opening Android Settings.");
        else if (lower.startsWith("open ")) confirmAction("Open the app named \"" + q.substring(5).trim() + "\"?", "app:" + q.substring(5).trim(), "Okay, I'll look for that app.");
        else if (lower.contains("help")) reply("You can ask me the time or date, say 'open settings', or say 'open YouTube' (if installed). Set an HTTPS AI server URL in ⚙ Settings to enable full AI conversations.");
        else askAiBackend(q);
    }
    private void reply(String answer) { addMessage("SPIRIT_PLAYZYT AI", answer, false); speak(answer); }
    private void confirmAction(String prompt, String action, String acknowledgement) {
        pendingAction = action;
        new AlertDialog.Builder(this).setTitle("SPIRIT_PLAYZYT AI").setMessage(prompt)
            .setPositiveButton("Confirm", (d, w) -> { String a = pendingAction; pendingAction = ""; runAction(a); })
            .setNegativeButton("Cancel", (d, w) -> { pendingAction = ""; reply("All right, I won't do that."); }).show();
    }
    private void runAction(String action) {
        if ("settings".equals(action)) {
            try { startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); reply("Opening Android Settings."); }
            catch (Exception e) { reply("I couldn't open Settings on this device."); }
            return;
        }
        if (action.startsWith("app:")) {
            String wanted = action.substring(4).trim();
            Intent query = new Intent(Intent.ACTION_MAIN, null); query.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> apps = getPackageManager().queryIntentActivities(query, 0);
            for (ResolveInfo ri : apps) {
                String label = ri.loadLabel(getPackageManager()).toString();
                if (label.equalsIgnoreCase(wanted) || label.toLowerCase(Locale.ROOT).contains(wanted.toLowerCase(Locale.ROOT))) {
                    Intent launch = getPackageManager().getLaunchIntentForPackage(ri.activityInfo.packageName);
                    if (launch != null) { launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(launch); reply("Opening " + label + "."); return; }
                }
            }
            reply("I couldn't find an installed app matching '" + wanted + "'. Check the app name and try again.");
        }
    }
    private void showSettings() {
        LinearLayout box = new LinearLayout(this); box.setPadding(20, 8, 20, 4); box.setOrientation(LinearLayout.VERTICAL);
        TextView note = text("Connect an HTTPS AI backend. For Google Cloud or ElevenLabs, put provider API keys on your backend as environment secrets. Do not paste keys into the APK or share them in chat.", 12, white, false);
        box.addView(note);

        EditText endpoint = new EditText(this); endpoint.setSingleLine(true); endpoint.setTextColor(white); endpoint.setHintTextColor(0xFF9B91AA); endpoint.setHint("https://your-server.example/chat"); endpoint.setText(prefs.getString("endpoint", "")); box.addView(endpoint);

        TextView personalityLabel = text("PERSONALITY MODE", 11, purple, true); personalityLabel.setPadding(0, 14, 0, 4); box.addView(personalityLabel);
        String[] modes = {"Boss", "Friend", "Girlfriend", "Familiar"};
        Button personality = button("Mode: " + prefs.getString("personality", "Friend"), false); box.addView(personality);
        personality.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Choose personality").setItems(modes, (d, which) -> {
            prefs.edit().putString("personality", modes[which]).apply(); personality.setText("Mode: " + modes[which]);
        }).show());

        TextView voiceLabel = text("VOICE PROVIDER", 11, purple, true); voiceLabel.setPadding(0, 14, 0, 4); box.addView(voiceLabel);
        String[] providers = {"Android built-in voice", "Google Cloud TTS", "ElevenLabs"};
        String[] providerIds = {"android", "google", "elevenlabs"};
        int current = 0; String savedProvider = prefs.getString("voice_provider", "android");
        for (int i = 0; i < providerIds.length; i++) if (providerIds[i].equals(savedProvider)) current = i;
        final int[] selectedProvider = {current};
        Button provider = button("Voice: " + providers[current], false); box.addView(provider);
        provider.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Choose voice provider").setSingleChoiceItems(providers, selectedProvider[0], (d, which) -> {
            selectedProvider[0] = which; provider.setText("Voice: " + providers[which]); d.dismiss();
        }).show());

        EditText voiceId = new EditText(this); voiceId.setSingleLine(true); voiceId.setTextColor(white); voiceId.setHintTextColor(0xFF9B91AA); voiceId.setHint("Custom voice ID (optional)"); voiceId.setText(prefs.getString("voice_id", "")); box.addView(voiceId);
        TextView keyNote = text("API key requirements: Google Cloud API key is needed for Google TTS; ElevenLabs API key is needed for ElevenLabs. Configure the selected provider's key securely on your backend. The app sends only provider name, voice ID and text to your HTTPS backend.", 11, 0xFFBDB2CC, false);
        keyNote.setPadding(0, 10, 0, 4); box.addView(keyNote);

        new AlertDialog.Builder(this).setTitle("SPIRIT_PLAYZYT AI settings").setView(box)
            .setPositiveButton("Save", (d, w) -> {
                String value = endpoint.getText().toString().trim();
                if (!value.isEmpty() && !value.startsWith("https://")) { Toast.makeText(this, "Use a secure HTTPS address.", Toast.LENGTH_LONG).show(); return; }
                prefs.edit().putString("endpoint", value).putString("voice_provider", providerIds[selectedProvider[0]]).putString("voice_id", voiceId.getText().toString().trim()).apply();
                Toast.makeText(this, value.isEmpty() ? "Settings saved. AI backend not connected." : "Settings saved.", Toast.LENGTH_SHORT).show();
            }).setNeutralButton("Clear backend", (d, w) -> { prefs.edit().remove("endpoint").apply(); Toast.makeText(this, "AI backend disconnected.", Toast.LENGTH_SHORT).show(); })
            .setNegativeButton("Close", null).show();
    }
    private void askAiBackend(String question) {
        String endpoint = prefs.getString("endpoint", "");
        if (endpoint.isEmpty()) { reply("I can handle basic phone commands, but my full AI brain isn't connected yet. Open ⚙ Settings and add your own HTTPS AI backend address."); return; }
        addMessage("SPIRIT_PLAYZYT AI", "Thinking...", false);
        network.execute(() -> {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(endpoint).openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(12000); c.setReadTimeout(20000);
                c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json; charset=utf-8"); c.setRequestProperty("Accept", "application/json");
                JSONObject body = new JSONObject(); body.put("message", question); body.put("assistant", "SPIRIT_PLAYZYT AI"); body.put("personality", prefs.getString("personality", "Friend").toLowerCase(Locale.ROOT));
                body.put("voice_provider", prefs.getString("voice_provider", "android"));
                body.put("voice_id", prefs.getString("voice_id", ""));
                try (OutputStream os = c.getOutputStream()) { os.write(body.toString().getBytes("UTF-8")); }
                int code = c.getResponseCode(); InputStream stream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8")); StringBuilder out = new StringBuilder(); String line;
                while ((line = reader.readLine()) != null) out.append(line); reader.close();
                if (code < 200 || code >= 300) throw new Exception("Server returned HTTP " + code);
                JSONObject response = new JSONObject(out.toString()); String answer = response.optString("reply", "").trim();
                if (answer.isEmpty()) throw new Exception("The server response did not contain a 'reply' field.");
                runOnUiThread(() -> reply(answer));
            } catch (Exception e) {
                runOnUiThread(() -> reply("I couldn't reach the AI server. Check the HTTPS address and connection, then try again."));
            } finally { if (c != null) c.disconnect(); }
        });
    }
    private void speak(String s) { if (speakReplies && tts != null) tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "spirit_reply"); }
    private void startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { Toast.makeText(this, "Speech recognition is not available on this device.", Toast.LENGTH_LONG).show(); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO); return; }
        try {
            if (recognizer != null) recognizer.destroy(); recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                public void onReadyForSpeech(Bundle p) { Toast.makeText(MainActivity.this, "Listening...", Toast.LENGTH_SHORT).show(); }
                public void onBeginningOfSpeech() {} public void onRmsChanged(float r) {} public void onBufferReceived(byte[] b) {} public void onEndOfSpeech() {}
                public void onError(int e) { Toast.makeText(MainActivity.this, "Couldn't hear that. Tap the mic and try again.", Toast.LENGTH_SHORT).show(); }
                public void onResults(Bundle b) { ArrayList<String> a = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if (a != null && !a.isEmpty()) handleQuery(a.get(0)); }
                public void onPartialResults(Bundle b) {} public void onEvent(int t, Bundle p) {}
            });
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault()); i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to SPIRIT_PLAYZYT AI"); recognizer.startListening(i);
        } catch (Exception e) { Toast.makeText(this, "Voice input could not start.", Toast.LENGTH_SHORT).show(); }
    }
    @Override protected void onDestroy() { if (recognizer != null) recognizer.destroy(); if (tts != null) { tts.stop(); tts.shutdown(); } network.shutdownNow(); super.onDestroy(); }
}
