package app.vtuber;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    private WebView wv;
    private PermissionRequest pending;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        wv = new WebView(this);
        setContentView(wv);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        wv.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
        });
        wv.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest r) {
                runOnUiThread(new Runnable() { public void run() {
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        r.grant(r.getResources());
                    } else { pending = r; requestPermissions(new String[]{Manifest.permission.CAMERA}, 1); }
                }});
            }
        });
        wv.addJavascriptInterface(new Object() {
            @JavascriptInterface public void startOverlay(final int dp) {
                runOnUiThread(new Runnable() { public void run() { begin(dp); }});
            }
        }, "Android");
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS}, 2);
        else requestPermissions(new String[]{Manifest.permission.CAMERA}, 2);
        wv.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private void begin(int dp) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Ative “Exibir sobre outros apps” e toque em Flutuar de novo", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            return;
        }
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 2);
            return;
        }
        startForegroundService(new Intent(this, OverlayService.class).putExtra("w", dp));
        moveTaskToBack(true);
    }

    @Override public void onRequestPermissionsResult(int code, String[] p, int[] g) {
        if (code == 1 && pending != null) {
            if (g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) pending.grant(pending.getResources());
            else pending.deny();
            pending = null;
        }
    }
}
