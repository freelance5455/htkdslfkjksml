package app.vtuber;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.ContextThemeWrapper;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;

public class OverlayService extends Service {
    private WindowManager wm;
    private WebView wv;
    private WindowManager.LayoutParams lp;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent in, int flags, int id) {
        if (in != null && "STOP".equals(in.getAction())) { stopSelf(); return START_NOT_STICKY; }
        getSystemService(NotificationManager.class).createNotificationChannel(
            new NotificationChannel("vt", "Mini VTuber", NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop = PendingIntent.getService(this, 0,
            new Intent(this, OverlayService.class).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent open = PendingIntent.getActivity(this, 0,
            new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "vt")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Mini VTuber ativo").setContentText("Avatar flutuando na tela")
            .setContentIntent(open).addAction(0, "Parar", stop).build();
        if (Build.VERSION.SDK_INT >= 30) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA);
        else startForeground(1, n);
        show(in == null ? 220 : in.getIntExtra("w", 220));
        return START_NOT_STICKY;
    }

    private void show(int dp) {
        hide();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        float d = getResources().getDisplayMetrics().density;
        lp = new WindowManager.LayoutParams((int) (dp * d), (int) (dp * 1.25f * d),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = (int) (16 * d);
        lp.y = (int) (120 * d);

        wv = new WebView(new ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault));
        wv.setBackgroundColor(Color.TRANSPARENT);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        wv.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
        });
        wv.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest r) { r.grant(r.getResources()); }
        });

        // Arrastar para mover; toque duplo para recentrar o rosto
        final GestureDetector gd = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDoubleTap(MotionEvent e) {
                wv.evaluateJavascript("if(window.recal)recal()", null);
                return true;
            }
        });
        wv.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy; int sx, sy;
            public boolean onTouch(View v, MotionEvent e) {
                gd.onTouchEvent(e);
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    dx = e.getRawX(); dy = e.getRawY(); sx = lp.x; sy = lp.y;
                } else if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    lp.x = sx + (int) (e.getRawX() - dx);
                    lp.y = sy + (int) (e.getRawY() - dy);
                    wm.updateViewLayout(wv, lp);
                }
                return true;
            }
        });
        wv.loadUrl("https://appassets.androidplatform.net/assets/index.html?overlay=1");
        wm.addView(wv, lp);
    }

    private void hide() {
        if (wv != null) {
            try { wm.removeView(wv); } catch (Exception ignored) {}
            wv.destroy();
            wv = null;
        }
    }

    @Override public void onDestroy() { hide(); super.onDestroy(); }
}
