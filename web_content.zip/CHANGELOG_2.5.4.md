# ANONYMOUX STUDIO 2.5.4 — Visual & Billing Planning Update

- Cropped the four user-provided references into 19 optimized WebP visual assets.
- Applied user-provided imagery to landing hero background, workspace thumbnails and a new responsive visual showcase mosaic.
- Preserved original source imagery outside the website asset directory; generated cropped assets only.
- Added Admin > Models cross-workspace billing rollout matrix with explicit readiness states.
- Added BILLING-PRICING-PLAN-2.5.4.md documenting the 100% target markup, ₦10/credit planning conversion, ceiling rounding, candidate Decart rate card, package proposal, and required settlement safeguards.
- Preserved existing Image/Video price settings and wallet reservation logic. No unverified new workspace charging has been enabled.
