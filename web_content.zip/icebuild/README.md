# Ice Cream Stock Manager — Android Studio APK Project

This project is prepared for building the Android APK in Android Studio.

## App features
- Owner / Employee mode
- Owner PIN protection (default PIN: 1234)
- Add sales
- Shop/customer management
- Shop orders and delivery status
- Current stock and low-stock alerts
- Purchases
- Wastage
- Outstanding/credit tracking
- Local phone storage

## Build the APK in Android Studio
1. Extract this ZIP.
2. Open the **icebuild** folder in Android Studio (do not open the ZIP itself).
3. Let Android Studio finish Gradle Sync and install any requested Android SDK/Build Tools.
4. Select **Build → Build APK(s)**.
5. The APK will be at:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Copy that APK to your Android phone and install it.

### Recommended Android Studio setup
- Use Android Studio with JDK 17.
- The project uses Android Gradle Plugin 8.7.3 and compile/target SDK 35.
- If Android Studio asks to upgrade Gradle/AGP, choose **Cancel/keep the project versions** for the first build.

### Owner / Employee
- Default mode is Owner.
- Tap **Switch Mode** to enter Employee Mode.
- To return to Owner Mode, enter PIN `1234`.
- Change the PIN from the app's settings when that feature is added.

### Important
The current app stores its business data locally on the phone. Keep regular backups before changing or uninstalling the app.
