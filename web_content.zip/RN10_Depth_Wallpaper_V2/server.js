const express=require("express");
const path=require("path");
const app=express();
const PORT=process.env.PORT||3000;
app.use(express.static(path.join(__dirname,"public")));
app.get("/api/wallpapers",(req,res)=>{
  res.sendFile(path.join(__dirname,"public","wallpapers.json"));
});
app.listen(PORT,()=>console.log(`RN10 Wallpaper Server: http://localhost:${PORT}`));
