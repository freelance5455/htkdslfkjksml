RN10 Depth Wallpaper V2
=========================

Features:
- Server-loaded wallpaper library
- Categories and search
- Favorites stored locally
- 12 wallpapers included as a starter library
- Theme selector
- Live 12/24-hour clock
- Depth/parallax motion effect
- Custom photo upload
- Brightness and clock customization
- Fullscreen mode
- Auto wallpaper rotation

Run locally:
1. Install Node.js.
2. Open terminal in this folder.
3. Run: npm install
4. Run: npm start
5. Open: http://localhost:3000

To add wallpapers:
Edit public/wallpapers.json and add entries to the wallpapers array.
You can also replace the image URLs with your own CDN/server URLs.

Note:
The included images are loaded from Unsplash URLs. For production, use your own image CDN/server and confirm the image licenses/terms.
