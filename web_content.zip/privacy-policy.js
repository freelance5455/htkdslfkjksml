export const privacyPolicy = {
  nl: {
    title: 'Privacybeleid voor SaldoGrip',
    updated: 'Laatst bijgewerkt: 7 oktober 2026',
    intro: 'Dit privacybeleid is van toepassing op de mobiele applicatie SaldoGrip (hierna “de App”). Wij hechten grote waarde aan de privacy van onze gebruikers. Dit document legt op een eenvoudige en transparante manier uit hoe de App omgaat met uw gegevens.',
    sections: [
      {
        title: '1. Verzameling en gebruik van gegevens',
        intro: 'De App is ontworpen als een standalone, lokale applicatie.',
        bullets: [
          '<strong>Geen persoonlijke gegevens:</strong> De App verzamelt, registreert of verwerkt geen persoonlijke gegevens (zoals uw naam, e-mailadres, telefoonnummer of locatie).',
          '<strong>Volledig lokale opslag:</strong> Alle gegevens die u invoert in de App (zoals spaardoelen, bedragen en datums) worden uitsluitend en direct opgeslagen in de lokale database van uw eigen apparaat. Deze gegevens verlaten uw apparaat nooit.'
        ]
      },
      { title: '2. Delen van gegevens met derden', body: 'Aangezien er geen gegevens worden verzameld of centraal worden opgeslagen, worden er geen gegevens gedeeld, verkocht of doorgegeven aan derden, externe servers of marketingbedrijven.' },
      { title: '3. Cookies en tracking', body: 'De App maakt geen gebruik van cookies, tracking-pixels of andere technologieën om uw surfgedrag of apparaatgebruik te monitoren.' },
      { title: '4. Advertenties', body: 'De App bevat geen advertenties van externe advertentienetwerken. U zult in deze App geen banners, pop-ups of tracking-gebaseerde reclame tegenkomen.' },
      { title: '5. Beveiliging van uw gegevens', body: 'Omdat uw gegevens uitsluitend lokaal op uw eigen telefoon of tablet staan, is de beveiliging van uw spaardata afhankelijk van de beveiliging van uw eigen apparaat (zoals uw toegangscode, vingerafdruk of gezichtsherkenning). Indien u de App verwijdert, worden alle lokaal opgeslagen spaargegevens definitief van uw apparaat gewist.' },
      { title: '6. Wijzigingen in dit privacybeleid', body: 'Wij kunnen dit privacybeleid van tijd tot tijd bijwerken om te voldoen aan veranderende wetgeving of app-updates. Wijzigingen worden op deze pagina gepubliceerd.' },
      { title: '7. Contact', body: 'Als u vragen heeft over dit privacybeleid, kunt u contact opnemen via: <a href="mailto:saldogrip@kudi.nl">saldogrip@kudi.nl</a>' }
    ]
  },
  en: {
    title: 'Privacy Policy for SaldoGrip',
    updated: 'Last updated: October 7, 2026',
    intro: 'This privacy policy applies to the SaldoGrip mobile application (hereinafter “the App”). We highly value the privacy of our users. This document explains in a simple and transparent manner how the App handles your data.',
    sections: [
      {
        title: '1. Collection and Use of Data',
        intro: 'The App is designed as a standalone, local application.',
        bullets: [
          '<strong>No personal data:</strong> The App does not collect, register, or process any personal data (such as your name, email address, phone number, or location).',
          '<strong>Fully local storage:</strong> All data you enter into the App (such as savings goals, amounts, and dates) is stored exclusively and directly within your device’s local database. This data never leaves your device.'
        ]
      },
      { title: '2. Sharing Data with Third Parties', body: 'Since no data is collected or centrally stored, no data is shared, sold, or passed on to third parties, external servers, or marketing companies.' },
      { title: '3. Cookies and Tracking', body: 'The App does not use cookies, tracking pixels, or other technologies to monitor your browsing behavior or device usage.' },
      { title: '4. Advertisements', body: 'The App does not contain advertisements from external ad networks. You will not encounter banners, pop-ups, or tracking-based advertising in this App.' },
      { title: '5. Security of Your Data', body: 'Because your data resides exclusively on your own phone or tablet, the security of your savings data depends on the security of your own device (such as your passcode, fingerprint, or facial recognition). If you uninstall the App, all locally stored savings data will be permanently deleted from your device.' },
      { title: '6. Changes to This Privacy Policy', body: 'We may update this privacy policy from time to time to comply with changing legislation or app updates. Changes will be published on this page.' },
      { title: '7. Contact', body: 'If you have any questions regarding this privacy policy, you can contact us at: <a href="mailto:saldogrip@kudi.nl">saldogrip@kudi.nl</a>' }
    ]
  }
};
