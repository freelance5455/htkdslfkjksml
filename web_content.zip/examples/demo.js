// JavaScript location example
navigator.geolocation?.getCurrentPosition(
  p => console.log(p.coords.latitude, p.coords.longitude),
  e => console.log("Location permission/error:", e.message)
);
