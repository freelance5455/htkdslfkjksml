// Optional Java example.
// Browser GPS permission is handled by JavaScript, not Java.
public class LocationServer {
    public static void main(String[] args) {
        System.out.println("Use a HTTPS web server for the browser map.");
    }
}
