# Optional Python example: location data receiver concept.
# Browser location permission itself must be requested by JavaScript.
from http.server import HTTPServer, SimpleHTTPRequestHandler
print("Open http://localhost:8000/index.html")
HTTPServer(("0.0.0.0", 8000), SimpleHTTPRequestHandler).serve_forever()
