// Optional C++ example.
// Browser Geolocation permission is handled in app.js.
#include <iostream>
int main() {
    std::cout << "Browser Location is requested by JavaScript." << std::endl;
    return 0;
}
