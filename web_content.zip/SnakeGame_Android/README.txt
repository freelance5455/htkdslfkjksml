بازی مار - پروژه آماده برای ساخت APK

پیش‌نیازها:
1. Node.js نصب باشد.
2. Android Studio نصب باشد.

در پوشه پروژه در VS Code ترمینال را باز کن و اجرا کن:

npm install
npx cap add android
npx cap sync
npx cap open android

بعد پروژه Android Studio باز می‌شود.
برای ساخت APK:
Build > Generate App Bundles or APKs > Generate APKs

فایل APK معمولاً در:
android/app/build/outputs/apk/debug/app-debug.apk

قرار می‌گیرد.
