const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const scoreEl = document.getElementById("score");
const highScoreEl = document.getElementById("highScore");
const message = document.getElementById("message");
const startBtn = document.getElementById("startBtn");

const grid = 18;
const cell = canvas.width / grid;

let snake;
let food;
let direction;
let nextDirection;
let score = 0;
let highScore = Number(localStorage.getItem("snakeHighScore") || 0);
let gameLoop = null;
let running = false;

highScoreEl.textContent = highScore;

function resetGame() {
  snake = [
    { x: 9, y: 9 },
    { x: 8, y: 9 },
    { x: 7, y: 9 }
  ];

  direction = { x: 1, y: 0 };
  nextDirection = { x: 1, y: 0 };
  score = 0;
  scoreEl.textContent = score;
  placeFood();
  draw();
}

function placeFood() {
  do {
    food = {
      x: Math.floor(Math.random() * grid),
      y: Math.floor(Math.random() * grid)
    };
  } while (snake.some(part => part.x === food.x && part.y === food.y));
}

function startGame() {
  clearInterval(gameLoop);
  resetGame();
  running = true;
  message.style.display = "none";
  gameLoop = setInterval(update, 115);
}

function endGame() {
  running = false;
  clearInterval(gameLoop);

  if (score > highScore) {
    highScore = score;
    localStorage.setItem("snakeHighScore", highScore);
    highScoreEl.textContent = highScore;
  }

  document.querySelector(".message h2").textContent = "باختی!";
  document.querySelector(".message p").textContent = `امتیاز شما: ${score}`;
  startBtn.textContent = "بازی دوباره";
  message.style.display = "flex";
}

function changeDirection(dir) {
  if (!running) return;

  const opposite =
    dir.x === -direction.x && dir.y === -direction.y;

  if (!opposite) {
    nextDirection = dir;
  }
}

function update() {
  direction = nextDirection;

  const head = {
    x: snake[0].x + direction.x,
    y: snake[0].y + direction.y
  };

  if (
    head.x < 0 ||
    head.x >= grid ||
    head.y < 0 ||
    head.y >= grid ||
    snake.some(part => part.x === head.x && part.y === head.y)
  ) {
    endGame();
    return;
  }

  snake.unshift(head);

  if (head.x === food.x && head.y === food.y) {
    score++;
    scoreEl.textContent = score;
    placeFood();
  } else {
    snake.pop();
  }

  draw();
}

function draw() {
  ctx.fillStyle = "#0b1220";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // خطوط زمین بازی
  ctx.strokeStyle = "rgba(255,255,255,.035)";
  ctx.lineWidth = 1;

  for (let i = 0; i <= grid; i++) {
    ctx.beginPath();
    ctx.moveTo(i * cell, 0);
    ctx.lineTo(i * cell, canvas.height);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(0, i * cell);
    ctx.lineTo(canvas.width, i * cell);
    ctx.stroke();
  }

  // غذا
  ctx.fillStyle = "#ef4444";
  ctx.beginPath();
  ctx.arc(
    food.x * cell + cell / 2,
    food.y * cell + cell / 2,
    cell * 0.34,
    0,
    Math.PI * 2
  );
  ctx.fill();

  // مار
  snake.forEach((part, index) => {
    ctx.fillStyle = index === 0 ? "#4ade80" : "#22c55e";

    const padding = index === 0 ? 1.5 : 2.5;
    ctx.fillRect(
      part.x * cell + padding,
      part.y * cell + padding,
      cell - padding * 2,
      cell - padding * 2
    );
  });

  // چشم‌های سر مار
  const head = snake[0];
  ctx.fillStyle = "#111827";

  let eyes = [];
  if (direction.x !== 0) {
    eyes = [
      { x: head.x * cell + cell / 2 + direction.x * cell * .22,
        y: head.y * cell + cell / 2 - cell * .16 },
      { x: head.x * cell + cell / 2 + direction.x * cell * .22,
        y: head.y * cell + cell / 2 + cell * .16 }
    ];
  } else {
    eyes = [
      { x: head.x * cell + cell / 2 - cell * .16,
        y: head.y * cell + cell / 2 + direction.y * cell * .22 },
      { x: head.x * cell + cell / 2 + cell * .16,
        y: head.y * cell + cell / 2 + direction.y * cell * .22 }
    ];
  }

  eyes.forEach(eye => {
    ctx.beginPath();
    ctx.arc(eye.x, eye.y, cell * .055, 0, Math.PI * 2);
    ctx.fill();
  });
}

startBtn.addEventListener("click", startGame);

document.querySelectorAll(".controls button").forEach(button => {
  button.addEventListener("pointerdown", event => {
    event.preventDefault();
    const dirs = {
      up:    { x: 0, y: -1 },
      down:  { x: 0, y: 1 },
      left:  { x: -1, y: 0 },
      right: { x: 1, y: 0 }
    };
    changeDirection(dirs[button.dataset.dir]);
  });
});

// صفحه‌کلید برای کامپیوتر
document.addEventListener("keydown", event => {
  const keys = {
    ArrowUp: { x: 0, y: -1 },
    w: { x: 0, y: -1 },
    W: { x: 0, y: -1 },
    ArrowDown: { x: 0, y: 1 },
    s: { x: 0, y: 1 },
    S: { x: 0, y: 1 },
    ArrowLeft: { x: -1, y: 0 },
    a: { x: -1, y: 0 },
    A: { x: -1, y: 0 },
    ArrowRight: { x: 1, y: 0 },
    d: { x: 1, y: 0 },
    D: { x: 1, y: 0 }
  };

  if (keys[event.key]) {
    event.preventDefault();
    changeDirection(keys[event.key]);
  }
});

// کنترل با کشیدن انگشت
let touchStartX = 0;
let touchStartY = 0;

canvas.addEventListener("touchstart", event => {
  const touch = event.changedTouches[0];
  touchStartX = touch.clientX;
  touchStartY = touch.clientY;
}, { passive: true });

canvas.addEventListener("touchend", event => {
  const touch = event.changedTouches[0];
  const dx = touch.clientX - touchStartX;
  const dy = touch.clientY - touchStartY;

  if (Math.max(Math.abs(dx), Math.abs(dy)) < 20) return;

  if (Math.abs(dx) > Math.abs(dy)) {
    changeDirection({ x: dx > 0 ? 1 : -1, y: 0 });
  } else {
    changeDirection({ x: 0, y: dy > 0 ? 1 : -1 });
  }
}, { passive: true });

resetGame();
