-- إضافة تصنيف للحلقات دون حذف أو تعديل أي بيانات موجودة.
-- القيم المسموح بها: talqeen / azhar / sharia
ALTER TABLE public.circles
ADD COLUMN IF NOT EXISTS program_type text;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'circles_program_type_check'
      AND conrelid = 'public.circles'::regclass
  ) THEN
    ALTER TABLE public.circles
      ADD CONSTRAINT circles_program_type_check
      CHECK (program_type IS NULL OR program_type IN ('talqeen','azhar','sharia'))
      NOT VALID;
  END IF;
END $$;

ALTER TABLE public.circles
VALIDATE CONSTRAINT circles_program_type_check;

CREATE INDEX IF NOT EXISTS circles_section_program_type_idx
ON public.circles (section, program_type);

-- تحقق: الحلقات الحالية محفوظة، والتصنيف يظل NULL حتى يحدده المدير بنفسه.
SELECT section, program_type, COUNT(*) AS circles_count
FROM public.circles
GROUP BY section, program_type
ORDER BY section, program_type;
