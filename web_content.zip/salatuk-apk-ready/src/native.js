import { LocalNotifications } from '@capacitor/local-notifications';
const IDS=[];
const CHANNELS={adhan:'prayer_adhan',tone1:'prayer_tone1',tone2:'prayer_tone2',tone3:'prayer_tone3'};
async function setup(){for(const [key,id] of Object.entries(CHANNELS))try{await LocalNotifications.createChannel({id,name:key==='adhan'?'أذان الصلاة':'نغمة '+key.slice(-1),description:'تنبيه وقت الصلاة',importance:5,visibility:1,sound:key==='adhan'?'adhan.mp3':key+'.wav'});}catch(e){}}
window.NativeNotify={
 async permission(){await setup();let p=await LocalNotifications.checkPermissions();if(p.display!=='granted')p=await LocalNotifications.requestPermissions();return p.display==='granted'},
 async cancel(){try{if(IDS.length)await LocalNotifications.cancel({notifications:IDS.map(id=>({id}))})}catch(e){}IDS.length=0},
 async schedule(list,sound='tone1'){if(sound==='none')return false;if(!(await this.permission()))return false;await this.cancel();let channelId=CHANNELS[sound]||CHANNELS.tone1;let ns=list.filter(x=>x.at instanceof Date&&x.at.getTime()>Date.now()+30000).map(x=>({id:x.id,title:'🕌 صلاتك',body:'حان الآن وقت صلاة '+x.name,channelId,smallIcon:'ic_launcher',schedule:{at:x.at,allowWhileIdle:true}}));if(!ns.length)return true;await LocalNotifications.schedule({notifications:ns});ns.forEach(n=>IDS.push(n.id));return true}
};setup().finally(()=>window.dispatchEvent(new Event('nativeReady')));
