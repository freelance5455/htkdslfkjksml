# صلاتك

APK-ready Capacitor project with scheduled Android local notifications and selectable tones.

## Add the Ali Ahmed Mulla adhan
The project has an «أذان علي أحمد ملا» option, but the actual recording is not bundled because the YouTube recording is not a redistributable file. If you have a lawful MP3 copy/permission, put it at:
`android/app/src/main/res/raw/adhan.mp3`
Then rebuild. The channel uses that file for the adhan notification.

## Build on GitHub
Upload the project files to the `salatuk` repository. Open Actions → Build Android APK → Run workflow. When it finishes, open Artifacts → `salatuk-debug-apk`, download and unzip it, then install the APK.

On first launch, allow notifications and location. Then Settings → notification sound.
