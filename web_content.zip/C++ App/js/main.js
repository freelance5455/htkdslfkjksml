/* ============================================================
   MAIN SCRIPT — chapter data, rendering, mobile menu
   ============================================================ */

/* -------- CHAPTER DATA --------
   Each chapter will link to its own HTML file in /chapters/.
   We'll create those files one-by-one in later chats.
----------------------------------- */
const CHAPTERS = [
  { num: 1,  title: 'Introduction to Programming',      desc: 'Problem solving, algorithms, pseudocode, and the foundations of coding.', file: 'chapters/ch01-introduction.html' },
  { num: 2,  title: 'Elements of C++',                   desc: 'Program structure, data types, variables, constants, and identifiers.',   file: 'chapters/ch02-elements.html' },
  { num: 3,  title: 'Input and Output',                  desc: 'cin, cout, stream operators, and manipulators for clean I/O.',           file: 'chapters/ch03-io.html' },
  { num: 4,  title: 'Operators and Expressions',         desc: 'Arithmetic, logical, relational operators, casting, and precedence.',     file: 'chapters/ch04-operators.html' },
  { num: 5,  title: 'Conditional Structures',            desc: 'if, else, else-if ladders, switch statements, and branching logic.',      file: 'chapters/ch05-conditionals.html' },
  { num: 6,  title: 'Loop Structures',                   desc: 'while, do-while, for loops, nested loops, and jump statements.',          file: 'chapters/ch06-loops.html' },
  { num: 7,  title: 'Functions',                         desc: 'Modular programming, prototypes, parameter passing, and scope.',          file: 'chapters/ch07-functions.html' },
  { num: 8,  title: 'Arrays',                            desc: '1D and 2D arrays, searching, sorting, and passing arrays to functions.',  file: 'chapters/ch08-arrays.html' },
  { num: 9,  title: 'Strings',                           desc: 'C-strings, string functions, and the std::string class.',                 file: 'chapters/ch09-strings.html' },
  { num: 10, title: 'Structures',                        desc: 'struct definitions, nested structures, and arrays of structures.',        file: 'chapters/ch10-structures.html' },
  { num: 11, title: 'Classes and Objects',               desc: 'OOP fundamentals, access specifiers, and member functions.',              file: 'chapters/ch11-classes.html' },
  { num: 12, title: 'Constructors and Destructors',      desc: 'Default, parameterized, copy constructors, and memory cleanup.',          file: 'chapters/ch12-constructors.html' },
  { num: 13, title: 'Operator Overloading',              desc: 'Unary, binary, relational, and assignment operator overloading.',         file: 'chapters/ch13-operator-overloading.html' },
  { num: 14, title: 'Inheritance',                       desc: 'Code reuse, inheritance modes, types, and constructor chaining.',         file: 'chapters/ch14-inheritance.html' },
  { num: 15, title: 'Polymorphism & Virtual Functions',  desc: 'Early vs. late binding, virtual and pure virtual functions.',             file: 'chapters/ch15-polymorphism.html' },
  { num: 16, title: 'Templates',                         desc: 'Generic programming, function and class templates, specialization.',      file: 'chapters/ch16-templates.html' },
  { num: 17, title: 'Exception Handling',                desc: 'try, catch, throw, multiple exception handling and re-throwing.',         file: 'chapters/ch17-exceptions.html' },
  { num: 18, title: 'Pointers & Memory Management',      desc: 'Pointer basics, arithmetic, new/delete, and the this pointer.',           file: 'chapters/ch18-pointers.html' },
  { num: 19, title: 'Streams, I/O & File Handling',      desc: 'ifstream, ofstream, binary files, file pointers, and error flags.',       file: 'chapters/ch19-file-io.html' },
];

/* -------- RENDER CHAPTER CARDS -------- */
function renderChapters() {
  const grid = document.getElementById('chaptersGrid');
  if (!grid) return;

  grid.innerHTML = CHAPTERS.map(
    (ch) => `
      <a class="chapter-card" href="${ch.file}">
        <span class="chapter-arrow">→</span>
        <span class="chapter-num">Chapter ${String(ch.num).padStart(2, '0')}</span>
        <h3>${ch.title}</h3>
        <p>${ch.desc}</p>
      </a>
    `
  ).join('');
}

/* -------- MOBILE MENU -------- */
function setupMobileMenu() {
  const btn = document.getElementById('mobileMenuBtn');
  const links = document.querySelector('.nav-links');
  if (!btn || !links) return;

  btn.addEventListener('click', () => {
    links.classList.toggle('open');
  });

  // Close on link click
  links.querySelectorAll('a').forEach((a) => {
    a.addEventListener('click', () => links.classList.remove('open'));
  });
}

/* -------- INIT -------- */
document.addEventListener('DOMContentLoaded', () => {
  renderChapters();
  setupMobileMenu();
});