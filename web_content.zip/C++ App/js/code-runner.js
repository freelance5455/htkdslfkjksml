/* ============================================================
   CODE RUNNER — copy button + simulated output system
   ------------------------------------------------------------
   This file provides helpers that chapter pages will use.

   How it will work in chapter pages:
   1. Wrap each code snippet in a .code-block container
   2. The block will have data-output="expected output here"
   3. A copy button and run button will be auto-injected.
   ============================================================ */

/* -------- COPY TO CLIPBOARD -------- */
async function copyCode(text, btn) {
  try {
    await navigator.clipboard.writeText(text);
    const original = btn.innerHTML;
    btn.innerHTML = '✓ Copied!';
    btn.classList.add('copied');
    setTimeout(() => {
      btn.innerHTML = original;
      btn.classList.remove('copied');
    }, 1600);
  } catch (err) {
    console.error('Copy failed:', err);
    btn.innerHTML = '✗ Failed';
    setTimeout(() => (btn.innerHTML = 'Copy'), 1600);
  }
}

/* -------- BUILD A CODE BLOCK --------
   Chapters will call this OR use the auto-init below.
-------------------------------------- */
function initCodeBlocks() {
  document.querySelectorAll('.code-block').forEach((block) => {
    const codeEl = block.querySelector('code');
    if (!codeEl) return;

    const rawCode = codeEl.textContent;
    const expectedOutput = block.dataset.output || '';

    // Build toolbar
    const toolbar = document.createElement('div');
    toolbar.className = 'code-toolbar';

    const copyBtn = document.createElement('button');
    copyBtn.className = 'code-btn';
    copyBtn.innerHTML = '📋 Copy';
    copyBtn.addEventListener('click', () => copyCode(rawCode, copyBtn));

    const runBtn = document.createElement('button');
    runBtn.className = 'code-btn code-btn-run';
    runBtn.innerHTML = '▶ Run';
    runBtn.addEventListener('click', () => {
      const out = block.querySelector('.code-result');
      if (!out) return;
      out.classList.toggle('visible');
      if (out.classList.contains('visible')) {
        out.innerHTML =
          `<span class="run-label">Output:</span><pre>${escapeHtml(expectedOutput)}</pre>`;
      }
    });

    toolbar.appendChild(copyBtn);
    toolbar.appendChild(runBtn);
    block.prepend(toolbar);

    // Add output area if expected output exists
    if (expectedOutput) {
      const out = document.createElement('div');
      out.className = 'code-result';
      block.appendChild(out);
    }
  });
}

/* -------- HTML ESCAPE -------- */
function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

/* -------- AUTO-INIT -------- */
document.addEventListener('DOMContentLoaded', initCodeBlocks);