/* ============================================================
   THEME TOGGLE — persists to localStorage
   ============================================================ */

(function () {
  const STORAGE_KEY = 'cppmastery-theme';
  const root = document.documentElement;
  const toggleBtn = document.getElementById('themeToggle');

  // 1. Apply saved theme (or system preference)
  function getInitialTheme() {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved === 'light' || saved === 'dark') return saved;
    // fall back to system preference
    return window.matchMedia('(prefers-color-scheme: light)').matches
      ? 'light'
      : 'dark';
  }

  function applyTheme(theme) {
    root.setAttribute('data-theme', theme);
    localStorage.setItem(STORAGE_KEY, theme);
  }

  // 2. Init
  applyTheme(getInitialTheme());

  // 3. Toggle on click
  if (toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      const current = root.getAttribute('data-theme');
      applyTheme(current === 'dark' ? 'light' : 'dark');
    });
  }
})();