/* ============================================================
   CHAPTER PAGE SCRIPTS
   - Active TOC highlight on scroll
   - Reading progress bar
   - Interactive MCQ quiz
   - Collapsible exercises
   ============================================================ */

(function () {
  'use strict';

  /* ---------- 1. SCROLL PROGRESS BAR ---------- */
  function setupProgressBar() {
    const bar = document.createElement('div');
    bar.className = 'scroll-progress';
    document.body.appendChild(bar);

    window.addEventListener('scroll', () => {
      const h = document.documentElement;
      const scrolled = h.scrollTop / (h.scrollHeight - h.clientHeight);
      bar.style.width = Math.min(100, scrolled * 100) + '%';
    });
  }

  /* ---------- 2. ACTIVE TOC HIGHLIGHT ---------- */
  function setupTocHighlight() {
    const links = Array.from(document.querySelectorAll('.toc-list a'));
    if (!links.length) return;

    const sections = links
      .map((l) => {
        const id = l.getAttribute('href').slice(1);
        return document.getElementById(id);
      })
      .filter(Boolean);

    function update() {
      const scrollY = window.scrollY + 120;
      let active = sections[0];
      for (const sec of sections) {
        if (sec.offsetTop <= scrollY) active = sec;
      }
      links.forEach((l) =>
        l.classList.toggle('active', l.getAttribute('href') === '#' + active.id)
      );
    }

    window.addEventListener('scroll', update, { passive: true });
    update();
  }

  /* ---------- 3. MCQ QUIZ ---------- */
  function setupQuizzes() {
    document.querySelectorAll('.quiz-card').forEach((card) => {
      const options = card.querySelectorAll('.quiz-option');
      const feedback = card.querySelector('.quiz-feedback');
      const correctIndex = parseInt(card.dataset.answer, 10);

      options.forEach((btn, idx) => {
        btn.addEventListener('click', () => {
          // Already answered
          if (card.classList.contains('answered-correct') ||
              card.classList.contains('answered-wrong')) return;

          const isCorrect = idx === correctIndex;

          options.forEach((b, i) => {
            b.disabled = true;
            if (i === correctIndex) b.classList.add('correct');
            if (i === idx && !isCorrect) b.classList.add('wrong');
          });

          card.classList.add(isCorrect ? 'answered-correct' : 'answered-wrong');

          if (feedback) {
            feedback.classList.add('show', isCorrect ? 'ok' : 'bad');
            feedback.innerHTML = isCorrect
              ? `<strong>✓ Correct!</strong> ${feedback.dataset.ok || ''}`
              : `<strong>✗ Not quite.</strong> ${feedback.dataset.bad || ''}`;
          }
        });
      });
    });
  }

  /* ---------- 4. COLLAPSIBLE EXERCISES ---------- */
  function setupExercises() {
    document.querySelectorAll('.exercise-item').forEach((item) => {
      const header = item.querySelector('.exercise-header');
      if (!header) return;
      header.addEventListener('click', () => item.classList.toggle('open'));
    });
  }

  /* ---------- 5. INIT ---------- */
  document.addEventListener('DOMContentLoaded', () => {
    setupProgressBar();
    setupTocHighlight();
    setupQuizzes();
    setupExercises();
  });
})();