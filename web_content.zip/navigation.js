/* blure shared responsive navigation v0.7.2 */
(function(){'use strict';
 const pages=[['Home','./'],['IDE','./ide.html'],['PHP Playground','./php-playground.php'],['Documentation','./docs.html']];
 const here=location.pathname.split('/').pop().toLowerCase();
 const active=here===''||here==='index.php'||here==='landing.html'?'Home':here==='ide.html'||here==='index.html'||here==='offline.html'?'IDE':here==='php-playground.php'?'PHP Playground':here==='docs.html'?'Documentation':'';
 const nav=document.createElement('div');nav.className='blure-global-nav';nav.setAttribute('role','navigation');nav.setAttribute('aria-label','Site navigation');
 const inner=document.createElement('div');inner.className='blure-nav-inner';nav.append(inner);
 const logo=document.createElement('a');logo.className='blure-nav-logo';logo.href='./';logo.innerHTML='{b<b>}</b> blure';logo.setAttribute('aria-label','blure home');inner.append(logo);
 const toggle=document.createElement('button');toggle.type='button';toggle.className='blure-nav-toggle';toggle.textContent='☰ Menu';toggle.setAttribute('aria-expanded','false');toggle.setAttribute('aria-controls','blure-nav-links');inner.append(toggle);
 const links=document.createElement('div');links.className='blure-nav-links';links.id='blure-nav-links';for(const [name,url] of pages){const a=document.createElement('a');a.href=url;a.textContent=name;if(name===active)a.setAttribute('aria-current','page');links.append(a)}inner.append(links);
 const label=document.createElement('label');label.className='blure-nav-theme';label.append(document.createTextNode('Theme '));const select=document.createElement('select');select.setAttribute('aria-label','Color theme');select.setAttribute('data-blure-theme','');for(const value of ['auto','light','dark']){const o=document.createElement('option');o.value=value;o.textContent=value[0].toUpperCase()+value.slice(1);select.append(o)}select.value=document.documentElement.dataset.themePreference||'auto';select.addEventListener('change',()=>{if(typeof window.blureSetTheme==='function')window.blureSetTheme(select.value)});label.append(select);inner.append(label);
 toggle.addEventListener('click',()=>{const open=nav.dataset.open!=='true';nav.dataset.open=String(open);toggle.setAttribute('aria-expanded',String(open));toggle.textContent=open?'✕ Close':'☰ Menu'});
 links.addEventListener('click',e=>{if(e.target.closest('a')){nav.dataset.open='false';toggle.setAttribute('aria-expanded','false')}});
 document.body.insertBefore(nav,document.body.firstChild);
})();
