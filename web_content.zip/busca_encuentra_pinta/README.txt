Busca, Encuentra y Pinta

Juego web que funciona sin conexión. Abre index.html en el navegador.
Incluye una felicitación de cumpleaños para Argenis Rosas Mejia (38 años) la primera vez que se abre y un nivel de búsqueda especial de cumpleaños que solo se puede jugar una vez por navegador/dispositivo. La música es una melodía sintetizada localmente; no requiere internet.

Nota: para que el estado de una sola vez se conserve, abre el archivo en el mismo navegador y no borres los datos del sitio.
