DOLI TENAZ OFFICIAL - VERSAO CORRIGIDA

Use o index.html na raiz. A pasta images deve permanecer junto dele.
Para converter em APK, escolha um conversor que aceite um site/HTML local (ZIP) e empacote os arquivos locais.
