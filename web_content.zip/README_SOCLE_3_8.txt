CGD V117 — Socle 3.8
Impact réel du staff sur les performances

Ouvrir index.html dans un navigateur moderne ou servir le dossier avec un serveur HTTP local.
Pour lancer les tests : npm test

Voir STAGE_3_8_IMPACT_REEL_DU_STAFF.md et VERIFICATION_SOCLE_3_8.md.
