VED AI Android wrapper project

WHAT THIS BUILDS
- Android APK containing the upgraded VED AI web interface.
- WebView loads the included upgraded HTML from a secure appassets origin.
- Microphone permission is requested when the web app needs audio (voice input / WebRTC).

IMPORTANT LIMITATIONS
- This is not a native cellular dialer. A normal WebView APK cannot automatically detect,
  accept, or reject SIM/mobile-network calls. That requires a separate native Android
  Telecom/role implementation and additional policy-compliant permissions.
- The CALL CENTER's TEST RING is a demo. WebRTC is an internet voice call, not a SIM call.
- Advanced AI needs your own compatible backend URL configured in VED AI settings.
  Do not put private API keys directly into the HTML or APK.

BUILD APK (Windows)
1. Install Android Studio (stable) and Android SDK Platform 35.
2. Extract this ZIP.
3. In Android Studio choose Open, then select the VED_AI_Android folder.
4. Wait for Gradle sync. If asked, install the Android Gradle Plugin / SDK components.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the APK location; usually app/build/outputs/apk/debug/app-debug.apk.
7. Transfer that APK to your Android phone and install it. You may need to allow installation
   from that file manager for this one install.

If Gradle sync fails, update Android Studio and install JDK 17 + Android SDK Platform 35.
