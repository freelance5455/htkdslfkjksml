Put your cover images in this folder.
