(() => {
  "use strict";
  const STORAGE_KEY = "rise_local_v1";
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const todayKey = () => new Date().toLocaleDateString("en-CA");
  const dateFromKey = (key) => new Date(`${key}T12:00:00`);
  const dayDiff = (a, b) => Math.max(0, Math.floor((dateFromKey(b) - dateFromKey(a)) / 86400000));
  const freshState = () => ({
    version: 1, createdAt: todayKey(), lastActive: todayKey(), streakStart: todayKey(),
    xp: 0, completedDays: {}, tasks: {}, reflections: {}, milestoneRewards: {}, theme: "dark",
    reduceMotion: false, reminders: false, history: []
  });
  let state = loadState();
  let toastTimer = null;
  let sosStep = 0;
  const sosSteps = [
    {kicker:"PAUSE FOR A MOMENT", title:"قف لحظة، أنت صاحب الاختيار.", body:"خد شهيقًا هادئًا، واسمح لنفسك بمساحة قبل أي قرار.", icon:"◌"},
    {kicker:"CHANGE THE SCENE", title:"غيّر المكان أو السياق.", body:"اقفل المحفز إن أمكن، وابعد جهازك قليلًا، أو انتقل لمكان مشترك وآمن.", icon:"⌁"},
    {kicker:"LET THE WAVE PASS", title:"اختار بديلًا بسيطًا.", body:"اشرب ماءً، امشِ قليلًا، أو ابدأ نشاطًا قصيرًا يشغل انتباهك. لا تحتاج إلى حل كل شيء الآن.", icon:"✳"},
    {kicker:"RETURN TO YOUR WHY", title:"افتكر أنت بدأت ليه.", body:"استعن بالله بما يناسبك، وارجع لهدفك. لو احتجت، تواصل مع شخص موثوق بدل مواجهة الضيق وحدك.", icon:"♡"}
  ];
  const quotes = [
    "الرغبة موجة، وليست أمرًا. امنح نفسك وقتًا لتختار.",
    "خطوة صغيرة متكررة أقوى من خطة مثالية لا تبدأ.",
    "الرجوع بعد التعثر جزء من التقدم، وليس نقيضه.",
    "أنت تبني طريقة جديدة للتعامل، يومًا بعد يوم.",
    "مش لازم تحس بالحماس عشان تعمل الخطوة الصح."
  ];
  const articles = {
    urge: {category:"علم النفس", title:"الرغبة مش أمر", body:"الدافع أو الرغبة قد يظهر بقوة ثم يتغير مع الوقت. بدل ما تتعامل معه كأنه أمر لازم تنفذه، جرّب تلاحظ ما يحدث دون حكم، وتؤجل القرار قليلًا، وتغيّر السياق. ابتعد عن المحفزات المتاحة واختر نشاطًا قصيرًا يناسبك. تختلف التجربة من شخص لآخر، وهذه إرشادات عامة وليست علاجًا."},
    habits: {category:"بناء العادات", title:"غيّر السياق، مش النية بس", body:"لاحظ الأوقات والمواقف التي تتكرر فيها الرغبة: الملل، السهر، التوتر، أو استخدام الهاتف بلا هدف. لا تحتاج إلى تسجيل تفاصيل خاصة؛ يكفي أن تلاحظ النمط. جهّز بديلًا واضحًا مسبقًا، مثل ترك الهاتف خارج الغرفة أو الانتقال لنشاط آخر. اجعل خطتك واقعية بدل الاعتماد على قوة الإرادة وحدها."},
    faith: {category:"إيماني", title:"بين الرجاء والعمل", body:"يمكن أن يكون الإيمان مصدر رجاء ومعنى وعون. التوبة والاستعانة بالله لا تتعارضان مع الأخذ بالأسباب، وتعلّم المحفزات، وطلب المساندة عند الحاجة. تجنّب تحويل الندم إلى إهانة مستمرة للنفس؛ اجعله دافعًا لخطوة عملية. المحتوى هنا تذكير عام وليس فتوى شخصية."},
    routine: {category:"روتين الحياة", title:"النوم والفراغ والمحفزات", body:"قد تلاحظ أن بعض الأوقات أصعب من غيرها، خاصة مع التعب أو الملل أو العزلة. جرّب روتين نوم مناسبًا، وفترات حركة، وأنشطة قصيرة مخططة، وحدودًا لاستخدام الهاتف. لا توجد وصفة واحدة تناسب الجميع؛ راقب ما يساعدك أنت دون مبالغة أو لوم."}
  };

  function loadState() {
    try {
      const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
      return parsed && parsed.version === 1 ? {...freshState(), ...parsed} : freshState();
    } catch { return freshState(); }
  }
  function saveState() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
    catch { showToast("تعذر الحفظ في هذا المتصفح. صدّر بياناتك للاحتفاظ بها."); }
  }
  function currentStreak() {
    const today = todayKey();
    let cursor = state.lastActive;
    if (!cursor) return 0;
    const activeToday = !!state.completedDays[today];
    if (!activeToday && dayDiff(cursor, today) > 1) return 0;
    const start = state.streakStart || today;
    return dayDiff(start, activeToday ? today : cursor) + 1;
  }
  function level() { return Math.floor(state.xp / 100) + 1; }
  const milestoneRewards = [
    { days: 4, xp: 50, title: "أربعة أيام من التقدم" },
    { days: 7, xp: 100, title: "أسبوع كامل من الالتزام" },
    { days: 14, xp: 200, title: "أسبوعان من النمو" },
    { days: 30, xp: 500, title: "ثلاثون يومًا من التعلّم" }
  ];
  function awardMilestoneRewards() {
    if (!state.milestoneRewards || typeof state.milestoneRewards !== "object") state.milestoneRewards = {};
    const streak = currentStreak();
    const newlyEarned = milestoneRewards.filter(m => streak >= m.days && !state.milestoneRewards[String(m.days)]);
    if (!newlyEarned.length) return "";
    newlyEarned.forEach(m => {
      state.milestoneRewards[String(m.days)] = todayKey();
      state.xp += m.xp;
    });
    const total = newlyEarned.reduce((sum, m) => sum + m.xp, 0);
    return ` إنجاز محطة جديدة! +${total} XP إضافية 🎉`;
  }
  function dailyTasks() {
    return $$("[data-task]").map(input => ({id:input.dataset.task, checked:!!(state.tasks[todayKey()] || {})[input.dataset.task]}));
  }
  function ensureDay() {
    if (!state.milestoneRewards || typeof state.milestoneRewards !== "object") state.milestoneRewards = {};
    const today = todayKey();
    if (!state.tasks[today]) state.tasks[today] = {};
    if (!state.createdAt) state.createdAt = today;
    if (!state.lastActive) state.lastActive = today;
  }
  function setTheme(theme) {
    state.theme = theme;
    document.documentElement.classList.toggle("light-mode", theme === "light");
    document.documentElement.classList.toggle("reduce-motion", !!state.reduceMotion);
    const select = $("#theme-select");
    if (select) select.value = theme;
    saveState();
  }
  function showToast(message) {
    const toast = $("#toast");
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2500);
  }
  function goToPage(name) {
    const page = $(`#page-${name}`);
    if (!page) return;
    $$(".page").forEach(p => p.classList.toggle("active", p === page));
    $$("[data-page]").forEach(btn => btn.classList.toggle("active", btn.dataset.page === name && (btn.classList.contains("nav-item") || btn.closest(".mobile-nav"))));
    const names = {home:"الرئيسية",sos:"مقاومة الرغبة",coach:"الخبير الذكي",progress:"تقدمي وإحصائياتي",library:"مكتبة الوعي",settings:"الإعدادات"};
    $("#page-crumb").textContent = names[name] || "الرئيسية";
    if (name === "progress") renderProgress();
    if (name === "home") renderHome();
    window.scrollTo({top:0, behavior:state.reduceMotion?"auto":"smooth"});
  }
  function renderHome() {
    const streak = currentStreak();
    $("#streak-count").textContent = streak;
    $("#hero-day").textContent = `DAY ${String(streak || 1).padStart(2,"0")}`;
    $("#streak-message").textContent = streak > 0 ? "كل يوم بتختار فيه بوعي هو خطوة تستحق التقدير." : "ابدأ من اليوم، وخلّي كل خطوة محسوبة.";
    $("#hero-level").textContent = String(level()).padStart(2,"0");
    $("#side-level").textContent = `المستوى ${level()} · ${levelName(level())}`;
    $("#xp-count").textContent = state.xp;
    $("#xp-next").textContent = level()*100;
    $("#xp-progress").style.width = `${state.xp % 100}%`;
    const tasks = dailyTasks();
    const count = tasks.filter(t=>t.checked).length;
    $("#task-count").textContent = `${count} من ${tasks.length} مهام`;
    $$("#task-list [data-task]").forEach(input => input.checked = !!(state.tasks[todayKey()]||{})[input.dataset.task]);
    $("#daily-quote").textContent = quotes[Math.floor(Date.now()/86400000)%quotes.length];
    $("#date-orb-text").textContent = new Intl.DateTimeFormat("ar-EG",{weekday:"short"}).format(new Date());
  }
  function levelName(n) {
    if (n >= 10) return "ثابت";
    if (n >= 6) return "متقدم";
    if (n >= 3) return "مستمر";
    return "بداية قوية";
  }
  function renderSos() {
    const step = sosSteps[sosStep];
    $("#sos-step-num").textContent = String(sosStep+1).padStart(2,"0");
    $("#sos-kicker").textContent = step.kicker;
    $("#sos-title").textContent = step.title;
    $("#sos-description").textContent = step.body;
    $("#sos-visual-icon").textContent = step.icon;
    $$("#sos-dots i").forEach((dot,i)=>dot.classList.toggle("selected",i===sosStep));
    $("#sos-next").innerHTML = sosStep === sosSteps.length-1 ? 'ابدأ الخطوات من جديد <span>↻</span>' : 'الخطوة التالية <span>←</span>';
  }
  function localReply(raw) {
    const s = raw.trim().toLocaleLowerCase("ar");
    if (!s) return "اكتب لي جملة بسيطة عن اللي محتاجه، ونختار خطوة عملية سوا.";
    if (/انتحار|أؤذي نفسي|ايذاء نفسي|إيذاء نفسي|مش عايز أعيش/.test(s)) {
      return "أنا آسف إنك بتمر بضيق. الأهم الآن سلامتك: تواصل فورًا مع شخص بالغ موثوق قريب منك، وقل له بوضوح إنك محتاج مساعدة الآن. لو في خطر مباشر، اطلب خدمات الطوارئ المحلية. لا تواجه اللحظة وحدك.";
    }
    if (/رغبة|شهوة|مغري|عايز|مش قادر|دلوقتي|انتكاس|أضعف/.test(s)) {
      return "خلينا نركز على الدقائق الجاية، مش على اليوم كله: ١) ابعد عن المحفز أو اقفل الصفحة. ٢) غيّر مكانك لمكان آمن أو مشترك. ٣) اشرب ماء أو امشِ قليلًا. ٤) اختار نشاطًا قصيرًا يناسبك. الرغبة لا تلزمك بالفعل، ولو تعثرت تقدر تتعلم وتبدأ من جديد.";
    }
    if (/ذنب|ربنا|الله|توبة|صلاة|دعاء|ذكر/.test(s)) {
      return "خلي الجانب الإيماني مصدر رجاء وعون، مش وسيلة لإهانة نفسك. يمكنك الاستعانة بالصلاة أو الذكر بما يناسبك، مع خطوة عملية مثل تغيير المكان وإبعاد المحفز. ولو عندك سؤال شرعي محدد، اسأل أهل العلم الموثوقين.";
    }
    if (/جسم|صحة|ضرر|طبي|علمي|مرض/.test(s)) {
      return "خلينا نفصل بين المعلومة الطبية المؤكدة والتخويف. لا يصح الجزم بأضرار جسدية محددة بلا دليل. لو عندك عرض أو سؤال صحي محدد، اعتمد على مصدر طبي موثوق أو مختص. أقدر أساعدك في تنظيم السؤال وتحديد ما تريد معرفته.";
    }
    if (/خطة|يومي|النهارده|اليوم|روتين/.test(s)) {
      return "خطة خفيفة لليوم: ١) حدد محفزًا واحدًا ستقلل التعرض له. ٢) اختر نشاطًا مفيدًا مدته ١٠ دقائق. ٣) خصص وقتًا قصيرًا للمراجعة أو العبادة بما يناسبك. ٤) قبل النوم، سجّل شيئًا واحدًا نجح معك وشيئًا تريد تعديله غدًا.";
    }
    if (/محفز|مثير|ملل|وحدة|سهر|هاتف|موبايل/.test(s)) {
      return "جرّب تلاحظ النمط من غير لوم: الوقت، المكان، والمشاعر اللي كانت موجودة. بعد كده عدّل عاملًا واحدًا فقط؛ مثل إبعاد الهاتف وقت النوم أو تجهيز نشاط بديل وقت الملل. مش لازم تسجل تفاصيل خاصة.";
    }
    if (/تعثر|فشلت|غلطت|انتكاس/.test(s)) {
      return "التعثر لا يمحو ما تعلمته. خُد لحظة تهدأ، وحدد العامل الذي سبق الموقف دون جلد للذات، ثم غيّر شيئًا واحدًا في خطتك. تقدر تستمر في بقية يومك بدل اعتبار كل شيء ضاع.";
    }
    return "خلينا نحول الموضوع لخطوة صغيرة قابلة للتنفيذ. اسأل نفسك: إيه حاجة واحدة أقدر أغيّرها في المكان أو روتيني خلال الدقائق العشر الجاية؟ أقدر أساعدك بإرشادات محلية، لكني لست نموذج ذكاء اصطناعي كاملًا.";
  }
  function addMessage(text, role) {
    const box = $("#chat-messages");
    const msg = document.createElement("div");
    msg.className = `message ${role}`;
    const avatar = document.createElement("span");
    avatar.className = "message-avatar";
    avatar.textContent = role === "user" ? "ر" : "✳";
    const bubble = document.createElement("div");
    bubble.className = "bubble";
    const p = document.createElement("p");
    p.textContent = text;
    const small = document.createElement("small");
    small.textContent = role === "user" ? "أنت · الآن" : "RISE · مساعد محلي";
    bubble.append(p,small); msg.append(avatar,bubble); box.append(msg);
    box.scrollTop = box.scrollHeight;
  }
  function sendChat(text) {
    const value = (text || $("#chat-input").value).trim();
    if (!value) return;
    addMessage(value,"user");
    $("#chat-input").value = "";
    const reply = localReply(value);
    window.setTimeout(() => addMessage(reply,"assistant"), state.reduceMotion ? 0 : 280);
  }
  function renderProgress() {
    const streak = currentStreak();
    $("#stats-streak").textContent = streak;
    $("#stats-xp").innerHTML = `${state.xp} <em>XP</em>`;
    const totalTasks = Object.values(state.tasks).reduce((sum,day)=>sum+Object.values(day||{}).filter(Boolean).length,0);
    $("#stats-tasks").textContent = totalTasks;
    $("#stats-days").textContent = Math.max(1,dayDiff(state.createdAt,todayKey())+1);
    const chart = $("#week-chart"); chart.replaceChildren();
    const dayLabels = [];
    for (let i=6;i>=0;i--) {
      const d = new Date(); d.setDate(d.getDate()-i);
      const key = d.toLocaleDateString("en-CA");
      const count = Object.values(state.tasks[key]||{}).filter(Boolean).length;
      dayLabels.push({key,label:new Intl.DateTimeFormat("ar-EG",{weekday:"short"}).format(d),count,isToday:i===0});
    }
    dayLabels.forEach(d=>{
      const col=document.createElement("div");col.className=`chart-day${d.isToday?" today":""}`;
      const wrap=document.createElement("div");wrap.className="chart-bar-wrap";
      const bar=document.createElement("div");bar.className="chart-bar";bar.style.height=`${Math.max(d.count?12:3,d.count/3*100)}%`;bar.title=`${d.count} مهام`;
      const label=document.createElement("small");label.textContent=d.label;
      wrap.append(bar);col.append(wrap,label);chart.append(col);
    });
    const milestones = [
      {days:1,title:"أول خطوة",desc:"بدأت تسجيل رحلتك",reward:0},
      {days:3,title:"ثلاثة أيام من الوعي",desc:"استمر في خطواتك الصغيرة",reward:0},
      {days:4,title:"أربعة أيام من التقدم",desc:"مكافأة محطة +50 XP",reward:50},
      {days:7,title:"أسبوع من الالتزام",desc:"مكافأة محطة +100 XP",reward:100},
      {days:14,title:"أسبوعان من النمو",desc:"مكافأة محطة +200 XP",reward:200},
      {days:30,title:"شهر من التعلّم",desc:"مكافأة محطة +500 XP",reward:500}
    ];
    const list=$("#milestone-list");list.replaceChildren();
    milestones.forEach(m=>{
      const done=streak>=m.days;
      const rewarded=!!(state.milestoneRewards||{})[String(m.days)];
      const row=document.createElement("div");row.className=`milestone${done?" done":""}`;
      const status = rewarded ? "حصلت عليها" : done ? "تم" : `${m.days} يوم`;
      row.innerHTML=`<span class="milestone-badge">${done?"✓":"✧"}</span><span><b>${m.title}</b><small>${m.desc}</small></span><span class="milestone-status">${status}</span>`;
      list.append(row);
    });
    const history=$("#history-list");history.replaceChildren();
    const entries=Object.entries(state.tasks).sort((a,b)=>b[0].localeCompare(a[0])).slice(0,7);
    if (!entries.length) {history.innerHTML='<div class="empty-state">لسه مفيش سجل. ابدأ بمهمة بسيطة من الرئيسية.</div>';return;}
    entries.forEach(([key,tasks])=>{
      const count=Object.values(tasks||{}).filter(Boolean).length;
      const row=document.createElement("div");row.className="history-row";
      const d=dateFromKey(key);
      const date=document.createElement("div");date.className="history-date";date.textContent=d.getDate();
      const copy=document.createElement("div");copy.className="history-copy";
      const b=document.createElement("b");b.textContent=new Intl.DateTimeFormat("ar-EG",{weekday:"long",month:"short"}).format(d);
      const small=document.createElement("small");small.textContent=count===3?"أكملت كل مهام اليوم":count?`أكملت ${count} من 3 مهام`:"سجل يومك";
      copy.append(b,small);
      const xp=document.createElement("span");xp.className="history-xp";xp.textContent=`${count*10} XP`;
      row.append(date,copy,xp);history.append(row);
    });
  }
  function exportData() {
    const blob = new Blob([JSON.stringify(state,null,2)],{type:"application/json"});
    const url=URL.createObjectURL(blob);const a=document.createElement("a");
    a.href=url;a.download=`rise-backup-${todayKey()}.json`;document.body.append(a);a.click();a.remove();URL.revokeObjectURL(url);
    showToast("تم تجهيز نسخة من بياناتك.");
  }
  function resetData() {
    if (!window.confirm("هل تريد مسح تقدم RISE المحفوظ على هذا الجهاز؟ لا يمكن التراجع عن ذلك إلا إذا كان لديك ملف تصدير.")) return;
    state=freshState();saveState();ensureDay();applySettings();renderHome();renderProgress();showToast("تمت إعادة ضبط بيانات التجربة.");
  }
  function applySettings() {
    setTheme(state.theme || "dark");
    $("#motion-toggle").checked=!!state.reduceMotion;
    $("#reminder-toggle").checked=!!state.reminders;
  }

  // Navigation
  $$("[data-page]").forEach(button=>button.addEventListener("click",()=>goToPage(button.dataset.page)));
  $("#theme-toggle").addEventListener("click",()=>setTheme(state.theme==="light"?"dark":"light"));
  $("#theme-select").addEventListener("change",e=>setTheme(e.target.value==="system"?"dark":e.target.value));
  $("#motion-toggle").addEventListener("change",e=>{state.reduceMotion=e.target.checked;saveState();applySettings();});
  $("#reminder-toggle").addEventListener("change",e=>{
    state.reminders=e.target.checked;saveState();
    showToast(e.target.checked?"تم حفظ تفضيل التذكيرات؛ إشعارات النظام غير مفعلة في هذه النسخة.":"تم إيقاف تفضيل التذكيرات.");
  });
  $$("#task-list [data-task]").forEach(input=>input.addEventListener("change",()=>{
    ensureDay();const today=todayKey();const id=input.dataset.task;
    const current=!!state.tasks[today][id];
    if (current===input.checked) return;
    state.tasks[today][id]=input.checked;
    state.lastActive=today;
    if (input.checked) {
      state.xp+=10;
      if (!state.completedDays[today]) {state.completedDays[today]=true; if (!state.streakStart || dayDiff(state.streakStart,today)>1) state.streakStart=today;}
      const milestoneMessage = awardMilestoneRewards();
      showToast("إنجاز جديد! +10 XP." + milestoneMessage);
    } else {
      state.xp=Math.max(0,state.xp-10);
      if (!Object.values(state.tasks[today]).some(Boolean)) delete state.completedDays[today];
      showToast("تم تحديث هدفك.");
    }
    saveState();renderHome();
  }));
  $("#sos-next").addEventListener("click",()=>{sosStep=(sosStep+1)%sosSteps.length;renderSos();});
  $("#sos-reset").addEventListener("click",()=>{sosStep=0;renderSos();});
  $("#chat-form").addEventListener("submit",e=>{e.preventDefault();sendChat();});
  $("#chat-input").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendChat();}});
  $$("[data-prompt]").forEach(btn=>btn.addEventListener("click",()=>{
    goToPage("coach");sendChat(btn.dataset.prompt);
  }));
  $$(".article-open").forEach(btn=>btn.addEventListener("click",()=>{
    const article=articles[btn.dataset.article];if(!article)return;
    $("#dialog-category").textContent=article.category;$("#dialog-title").textContent=article.title;
    $("#dialog-body").textContent=article.body;$("#article-dialog").showModal();
  }));
  $("#dialog-close").addEventListener("click",()=>$("#article-dialog").close());
  $("#dialog-done").addEventListener("click",()=>$("#article-dialog").close());
  $("#article-dialog").addEventListener("click",e=>{if(e.target===$("#article-dialog"))$("#article-dialog").close();});
  $("#export-data").addEventListener("click",exportData);
  $("#export-settings").addEventListener("click",exportData);
  $("#reset-data").addEventListener("click",resetData);

  // Date and initial state
  ensureDay();
  const now=new Date();
  $("#today-label").textContent=new Intl.DateTimeFormat("ar-EG",{weekday:"long",day:"numeric",month:"long"}).format(now);
  applySettings();renderHome();renderSos();renderProgress();

  // Lightweight offline support when served from localhost or HTTPS.
  if ("serviceWorker" in navigator && location.hostname !== "appassets.androidplatform.net" && (location.protocol==="https:" || location.hostname==="localhost")) {
    window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
  }
})();
