import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import { STLLoader } from 'three/addons/loaders/STLLoader.js';
import { STLExporter } from 'three/addons/exporters/STLExporter.js';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import { DRACOLoader } from 'three/addons/loaders/DRACOLoader.js';
import { clone as cloneSkeletonSafe } from 'three/addons/utils/SkeletonUtils.js';
import { mergeVertices } from 'three/addons/utils/BufferGeometryUtils.js';
import { MeshoptSimplifier } from 'meshoptimizer';
import { MeshoptDecoder } from 'https://cdn.jsdelivr.net/npm/meshoptimizer@1.3.0/meshopt_decoder.module.js';

const $ = (id) => document.getElementById(id);
const ui = {
  engineState: $('engineState'), fileInput: $('fileInput'), dropZone: $('dropZone'), fileSummary: $('fileSummary'),
  fileName: $('fileName'), fileMeta: $('fileMeta'), fileType: $('fileType'), removeFile: $('removeFile'),
  printMode: $('printMode'), gameMode: $('gameMode'), modeExplainer: $('modeExplainer'), printExtra: $('printExtra'),
  targetSelect: $('targetSelect'), customTargetRow: $('customTargetRow'), customTarget: $('customTarget'),
  qualityValue: $('qualityValue'), qualityButtons: [...document.querySelectorAll('.quality-option')],
  fillSmallHoles: $('fillSmallHoles'), optimizeBtn: $('optimizeBtn'), progressWrap: $('progressWrap'),
  progressTitle: $('progressTitle'), progressPct: $('progressPct'), progressBar: $('progressBar'), progressDetail: $('progressDetail'),
  viewport: $('viewport'), viewportPlaceholder: $('viewportPlaceholder'), viewportBadge: $('viewportBadge'), viewStatus: $('viewStatus'),
  showOriginal: $('showOriginal'), showOptimized: $('showOptimized'), resetView: $('resetView'),
  inputTriangles: $('inputTriangles'), outputTriangles: $('outputTriangles'), reductionPercent: $('reductionPercent'),
  outputSize: $('outputSize'), inputSize: $('inputSize'), reductionLabel: $('reductionLabel'), reductionFill: $('reductionFill'),
  reportState: $('reportState'), integrityBox: $('integrityBox'), integrityIcon: $('integrityBox').querySelector('.integrity-icon'),
  integrityTitle: $('integrityTitle'), integrityText: $('integrityText'), diagnostics: $('diagnostics'),
  downloadBtn: $('downloadBtn'), downloadLabel: $('downloadLabel'), downloadFormat: $('downloadFormat'), exportFootnote: $('exportFootnote'),
  tipText: $('tipText'), helpBtn: $('helpBtn'), helpModal: $('helpModal'), closeHelp: $('closeHelp')
};

let renderer, scene, camera, controls, grid;
let sourceRoot = null;
let optimizedRoot = null;
let activeRoot = null;
let currentFile = null;
let sourceAnimations = [];
let currentMode = 'print';
let qualityMode = 'detail';
let resultBlob = null;
let resultFilename = '';
let resultFormat = '';
let inputFileBytes = 0;
let lastReport = null;
let isBusy = false;

const QUALITY = {
  detail: { label: 'بیشترین حفظ جزئیات', printError: 0.003, gameError: 0.004 },
  balanced: { label: 'تعادل کیفیت و حجم', printError: 0.012, gameError: 0.015 },
  compact: { label: 'کاهش تهاجمی', printError: 0.035, gameError: 0.045 }
};

function initViewport() {
  const w = Math.max(1, ui.viewport.clientWidth);
  const h = Math.max(1, ui.viewport.clientHeight);
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0d1728);
  camera = new THREE.PerspectiveCamera(42, w / h, 0.01, 100000);
  camera.position.set(3.8, 2.7, 4.8);
  renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.8));
  renderer.setSize(w, h, false);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.domElement.setAttribute('aria-label', 'نمایش سه‌بعدی مدل');
  ui.viewport.insertBefore(renderer.domElement, ui.viewport.querySelector('.viewport-placeholder'));

  scene.add(new THREE.HemisphereLight(0xc8e4ff, 0x1a2437, 2.0));
  const keyLight = new THREE.DirectionalLight(0xfff2db, 3.1);
  keyLight.position.set(4, 7, 5);
  scene.add(keyLight);
  const fillLight = new THREE.DirectionalLight(0x75b9ff, 1.7);
  fillLight.position.set(-5, 2, -4);
  scene.add(fillLight);
  const rimLight = new THREE.DirectionalLight(0x58d8cc, 1.1);
  rimLight.position.set(0, -3, 5);
  scene.add(rimLight);

  grid = new THREE.GridHelper(20, 40, 0x36506d, 0x25384f);
  grid.material.transparent = true;
  grid.material.opacity = 0.34;
  scene.add(grid);
  controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.065;
  controls.rotateSpeed = 0.72;
  controls.zoomSpeed = 0.82;
  controls.panSpeed = 0.72;
  controls.minDistance = 0.02;
  controls.maxDistance = 100000;
  const resizeObserver = new ResizeObserver(() => resizeViewport());
  resizeObserver.observe(ui.viewport);
  window.addEventListener('orientationchange', () => setTimeout(resizeViewport, 180));

  const animate = () => {
    requestAnimationFrame(animate);
    controls.update();
    renderer.render(scene, camera);
  };
  animate();
}

function resizeViewport() {
  if (!renderer) return;
  const w = Math.max(1, ui.viewport.clientWidth);
  const h = Math.max(1, ui.viewport.clientHeight);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  renderer.setSize(w, h, false);
}

function fitCamera(root) {
  if (!root) return;
  root.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(root);
  if (box.isEmpty()) return;
  const center = box.getCenter(new THREE.Vector3());
  const size = box.getSize(new THREE.Vector3());
  const maxDim = Math.max(size.x, size.y, size.z, 0.001);
  const distance = maxDim * 2.35;
  camera.position.set(center.x + distance * 0.78, center.y + distance * 0.53, center.z + distance * 0.92);
  camera.near = Math.max(maxDim / 10000, 0.0001);
  camera.far = Math.max(maxDim * 100, 1000);
  camera.updateProjectionMatrix();
  controls.target.copy(center);
  controls.minDistance = Math.max(maxDim * 0.015, 0.002);
  controls.maxDistance = maxDim * 30;
  controls.update();
  grid.position.y = box.min.y - maxDim * 0.025;
  grid.scale.setScalar(Math.max(0.1, maxDim / 12));
}

function setActiveRoot(root, label) {
  if (activeRoot) scene.remove(activeRoot);
  activeRoot = root;
  if (root) {
    scene.add(root);
    fitCamera(root);
    ui.viewportPlaceholder.hidden = true;
    ui.viewportBadge.textContent = label;
  } else {
    ui.viewportPlaceholder.hidden = false;
    ui.viewportBadge.textContent = 'NO MODEL';
  }
}

function setProgress(title, pct, detail) {
  ui.progressWrap.hidden = false;
  ui.progressTitle.textContent = title;
  ui.progressPct.textContent = `${Math.round(pct)}٪`;
  ui.progressBar.style.width = `${Math.max(0, Math.min(100, pct))}%`;
  ui.progressDetail.textContent = detail || '';
}

function setEngineReady(ok, message) {
  ui.engineState.classList.toggle('ready', ok);
  ui.engineState.innerHTML = `<span class="pulse"></span><span>${message}</span>`;
}

function formatNumber(n) {
  if (!Number.isFinite(n)) return '—';
  return Math.round(n).toLocaleString('fa-IR');
}
function formatBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes < 0) return '—';
  const units = ['B', 'KB', 'MB', 'GB'];
  let value = bytes, i = 0;
  while (value >= 1024 && i < units.length - 1) { value /= 1024; i++; }
  return `${value.toFixed(i === 0 ? 0 : 2)} ${units[i]}`;
}
function getTriangleCount(geometry) {
  if (!geometry?.attributes?.position) return 0;
  const total = geometry.index ? geometry.index.count : geometry.attributes.position.count;
  const draw = geometry.drawRange?.count;
  const usable = Number.isFinite(draw) ? Math.min(total, draw) : total;
  return Math.floor(usable / 3);
}
function collectMeshes(root) {
  const out = [];
  root.traverse((obj) => { if (obj.isMesh && obj.geometry?.attributes?.position) out.push(obj); });
  return out;
}
function statsOf(root) {
  let triangles = 0, vertices = 0, meshCount = 0, skipped = 0;
  const seenGeometry = new Map();
  root.traverse((obj) => {
    if (!obj.isMesh || !obj.geometry?.attributes?.position) return;
    meshCount++;
    const multiplier = obj.isInstancedMesh ? obj.count : 1;
    const t = getTriangleCount(obj.geometry) * multiplier;
    triangles += t;
    const key = obj.geometry.uuid;
    if (!seenGeometry.has(key)) {
      seenGeometry.set(key, true);
      vertices += obj.geometry.attributes.position.count;
    }
    if (obj.isSkinnedMesh || (obj.geometry.morphAttributes?.position?.length || 0) > 0) skipped++;
  });
  return { triangles, vertices, meshCount, skipped };
}
function countTextures(root) {
  const textures = new Set();
  root.traverse((obj) => {
    if (!obj.isMesh) return;
    const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
    for (const mat of mats) {
      if (!mat) continue;
      for (const value of Object.values(mat)) {
        if (value?.isTexture) textures.add(value.uuid);
      }
    }
  });
  return textures.size;
}

async function loadFile(file) {
  if (!file) return;
  if (isBusy) return;
  const ext = file.name.split('.').pop().toLowerCase();
  if (!['glb', 'gltf', 'stl', 'obj'].includes(ext)) {
    showError('فرمت پشتیبانی نمی‌شود', 'در این نسخه فقط فایل‌های GLB، GLTF، STL و OBJ قابل ورود هستند.');
    return;
  }
  setProgress('در حال خواندن فایل…', 8, 'ساختار هندسه و اطلاعات مدل بررسی می‌شود.');
  try {
    let root;
    let loadedAnimations = [];
    if (ext === 'glb' || ext === 'gltf') {
      const buffer = await file.arrayBuffer();
      const loader = new GLTFLoader();
      loader.setMeshoptDecoder(MeshoptDecoder);
      const dracoLoader = new DRACOLoader();
      dracoLoader.setDecoderPath('https://www.gstatic.com/draco/versioned/decoders/1.5.7/');
      loader.setDRACOLoader(dracoLoader);
      const gltfAsset = await new Promise((resolve, reject) => loader.parse(buffer, '', resolve, reject));
      root = gltfAsset.scene || gltfAsset.scenes?.[0];
      loadedAnimations = gltfAsset.animations || [];
      if (!root) throw new Error('در فایل GLTF هیچ صحنه‌ای پیدا نشد.');
    } else if (ext === 'stl') {
      const buffer = await file.arrayBuffer();
      const geometry = new STLLoader().parse(buffer);
      geometry.computeVertexNormals();
      root = new THREE.Group();
      root.add(new THREE.Mesh(geometry, new THREE.MeshStandardMaterial({ color: 0xa8b8c8, roughness: 0.72, metalness: 0.08 })));
    } else {
      const text = await file.text();
      root = new OBJLoader().parse(text);
      root.traverse((obj) => {
        if (obj.isMesh && !obj.material) obj.material = new THREE.MeshStandardMaterial({ color: 0xa8b8c8, roughness: 0.75 });
      });
    }
    if (!collectMeshes(root).length) throw new Error('فایل خوانده شد، اما مش سه‌بعدی قابل پردازشی در آن پیدا نشد.');
    sourceRoot = root;
    sourceAnimations = loadedAnimations;
    optimizedRoot = null;
    currentFile = file;
    inputFileBytes = file.size;
    resultBlob = null;
    resultFilename = '';
    resultFormat = '';
    lastReport = null;
    updateFileUI(file, ext, root);
    const stats = statsOf(root);
    ui.inputTriangles.textContent = formatNumber(stats.triangles);
    ui.outputTriangles.textContent = '—';
    ui.reductionPercent.textContent = '—';
    ui.outputSize.textContent = '—';
    ui.inputSize.textContent = `ورودی: ${formatBytes(file.size)}`;
    ui.reductionLabel.textContent = '—';
    ui.reductionFill.style.width = '0%';
    ui.reportState.textContent = 'مدل بارگذاری شد';
    ui.reportState.className = 'report-state';
    setIntegrity('neutral', 'آمادهٔ تحلیل', 'پس از اجرای بهینه‌سازی، وضعیت هندسه و لبه‌ها در این قسمت گزارش می‌شود.');
    ui.diagnostics.hidden = true;
    ui.downloadBtn.disabled = true;
    ui.showOriginal.disabled = false;
    ui.showOptimized.disabled = true;
    ui.showOriginal.classList.add('active');
    ui.showOptimized.classList.remove('active');
    ui.optimizeBtn.disabled = false;
    ui.viewStatus.textContent = `${formatNumber(stats.meshCount)} مش · ${formatNumber(stats.triangles)} مثلث`;
    setActiveRoot(sourceRoot, 'ORIGINAL MODEL');
    ui.progressWrap.hidden = true;
    if (ext === 'gltf') {
      setTip('فایل GLTF ممکن است به فایل‌های BIN و تصویرهای جداگانه نیاز داشته باشد. برای انتقال مطمئن‌تر و حفظ بافت، آن را ابتدا به GLB یکپارچه تبدیل کن.');
    } else if (ext === 'obj') {
      setTip('فایل OBJ به‌تنهایی معمولاً اطلاعات متریال و بافت را کامل ندارد. برای حفظ بافت‌های بازی، ورودی GLB مناسب‌تر است.');
    } else if (stats.triangles > 1200000) {
      setTip('مدل بیش از ۱٫۲ میلیون مثلث دارد و پردازش آن روی گوشی ممکن است حافظهٔ زیادی مصرف کند. برنامه را در حین پردازش در پس‌زمینه قرار نده.');
    } else {
      setTip('برای مجسمه‌های برجسته و پرجزئیات، ابتدا حالت «جزئیات» را امتحان کن؛ سپس فایل را در اسلایسر واقعی بررسی کن.');
    }
  } catch (error) {
    console.error(error);
    ui.progressWrap.hidden = true;
    showError('بارگذاری ناموفق بود', error?.message || 'ساختار فایل قابل خواندن نیست. برای فایل GLTF از نسخهٔ GLB یکپارچه استفاده کن.');
  }
}

function updateFileUI(file, ext, root) {
  ui.dropZone.hidden = true;
  ui.fileSummary.hidden = false;
  ui.fileName.textContent = file.name;
  const stats = statsOf(root);
  ui.fileMeta.textContent = `${formatBytes(file.size)} · ${formatNumber(stats.meshCount)} مش · ${formatNumber(stats.triangles)} مثلث`;
  ui.fileType.textContent = ext.toUpperCase();
}
function resetFile() {
  if (isBusy) return;
  sourceRoot = null; optimizedRoot = null; currentFile = null; sourceAnimations = []; resultBlob = null;
  ui.fileInput.value = '';
  ui.fileSummary.hidden = true;
  ui.dropZone.hidden = false;
  ui.optimizeBtn.disabled = true;
  ui.showOriginal.disabled = true; ui.showOptimized.disabled = true;
  ui.downloadBtn.disabled = true;
  ui.inputTriangles.textContent = '—'; ui.outputTriangles.textContent = '—'; ui.reductionPercent.textContent = '—';
  ui.outputSize.textContent = '—'; ui.inputSize.textContent = 'ورودی: —'; ui.reductionLabel.textContent = '—'; ui.reductionFill.style.width = '0%';
  ui.reportState.textContent = 'منتظر فایل'; ui.reportState.className = 'report-state';
  ui.diagnostics.hidden = true;
  setIntegrity('neutral', 'گزارش سلامت پس از پردازش', 'پس از بارگذاری و پردازش مدل، وضعیت هندسه در این قسمت نمایش داده می‌شود.');
  ui.viewStatus.textContent = 'آمادهٔ دریافت مدل';
  setActiveRoot(null, 'NO MODEL');
}

function setIntegrity(level, title, text) {
  ui.integrityBox.className = `integrity-box${level === 'neutral' ? '' : ` ${level}`}`;
  ui.integrityIcon.textContent = level === 'good' ? '✓' : level === 'warn' ? '!' : level === 'bad' ? '×' : 'i';
  ui.integrityTitle.textContent = title;
  ui.integrityText.textContent = text;
}
function setTip(text) { ui.tipText.textContent = text; }
function showError(title, message) {
  setIntegrity('bad', title, message);
  ui.reportState.textContent = 'خطا';
  ui.reportState.className = 'report-state bad';
}

function setMode(mode) {
  currentMode = mode;
  ui.printMode.classList.toggle('selected', mode === 'print');
  ui.gameMode.classList.toggle('selected', mode === 'game');
  ui.printMode.setAttribute('aria-pressed', String(mode === 'print'));
  ui.gameMode.setAttribute('aria-pressed', String(mode === 'game'));
  ui.printExtra.hidden = mode !== 'print';
  if (mode === 'print') {
    ui.modeExplainer.textContent = 'در مسیر چاپ، رنگ و بافت کنار گذاشته می‌شود؛ هندسه برای بررسی چاپ، یکپارچه و تحلیل می‌شود.';
    ui.downloadFormat.textContent = 'STL';
    ui.exportFootnote.textContent = 'STL فقط هندسهٔ مثلثی را نگه می‌دارد؛ رنگ و بافت را ذخیره نمی‌کند. واحد طول هم داخل STL تعریف نمی‌شود.';
    setTip('برای چاپ مجسمه، هندسهٔ بسته و بدون لبهٔ باز مهم است. پس از دریافت فایل، آن را در اسلایسر واقعی بررسی کن.');
  } else {
    ui.modeExplainer.textContent = 'در مسیر بازی، گروه‌های متریال و ساختار رأس‌ها حفظ می‌شوند تا UV، نرمال و بافت‌ها تا حد ممکن باقی بمانند.';
    ui.downloadFormat.textContent = 'GLB';
    ui.exportFootnote.textContent = 'GLB می‌تواند متریال، مختصات UV، رنگ رأس و بافت‌های تصویری را نگه دارد؛ نتیجه را در موتور بازی خود بررسی کن.';
    setTip('برای مدل بازی، GLB ورودی بهترین انتخاب است؛ این نسخه مش‌های ایستا را کاهش می‌دهد و ریگ و مورف‌تارگت را دست‌نخورده می‌گذارد.');
  }
}
function setQuality(mode) {
  qualityMode = mode;
  ui.qualityButtons.forEach((b) => b.classList.toggle('active', b.dataset.quality === mode));
  ui.qualityValue.textContent = QUALITY[mode].label;
}
function getTarget() {
  if (ui.targetSelect.value === 'custom') {
    const n = Math.floor(Number(ui.customTarget.value));
    if (!Number.isFinite(n) || n < 100) throw new Error('تعداد مثلث دلخواه باید حداقل ۱۰۰ باشد.');
    return Math.min(n, 5000000);
  }
  return Number(ui.targetSelect.value);
}

function cloneRootAndGeometries(root) {
  const copy = cloneSkeletonSafe(root);
  copy.traverse((obj) => {
    if (obj.isMesh && obj.geometry) obj.geometry = obj.geometry.clone();
  });
  copy.updateMatrixWorld(true);
  return copy;
}

function getPositionArray(geometry) {
  const attr = geometry.attributes.position;
  const out = new Float32Array(attr.count * 3);
  for (let i = 0; i < attr.count; i++) {
    out[i * 3] = attr.getX(i);
    out[i * 3 + 1] = attr.getY(i);
    out[i * 3 + 2] = attr.getZ(i);
  }
  return out;
}
function getIndexArray(geometry) {
  if (geometry.index) return Uint32Array.from(geometry.index.array.slice(0, geometry.index.count));
  const count = geometry.attributes.position.count;
  const out = new Uint32Array(count);
  for (let i = 0; i < count; i++) out[i] = i;
  return out;
}
function compactGeometry(sourceGeometry, indexSegments) {
  const fullIndices = [];
  const newGroups = [];
  for (const segment of indexSegments) {
    const start = fullIndices.length;
    for (let i = 0; i < segment.indices.length; i++) fullIndices.push(segment.indices[i]);
    if (segment.materialIndex !== null && segment.materialIndex !== undefined) {
      newGroups.push({ start, count: segment.indices.length, materialIndex: segment.materialIndex });
    }
  }
  const remap = new Map();
  const usedVertices = [];
  const remappedIndices = new Uint32Array(fullIndices.length);
  for (let i = 0; i < fullIndices.length; i++) {
    const oldIndex = fullIndices[i];
    let next = remap.get(oldIndex);
    if (next === undefined) {
      next = usedVertices.length;
      remap.set(oldIndex, next);
      usedVertices.push(oldIndex);
    }
    remappedIndices[i] = next;
  }
  const result = new THREE.BufferGeometry();
  for (const [name, attr] of Object.entries(sourceGeometry.attributes)) {
    if (!attr || attr.isGLBufferAttribute) continue;
    const itemSize = attr.itemSize;
    const sourceArray = attr.isInterleavedBufferAttribute ? attr.data.array : attr.array;
    const stride = attr.isInterleavedBufferAttribute ? attr.data.stride : itemSize;
    const offset = attr.isInterleavedBufferAttribute ? attr.offset : 0;
    const ArrayType = sourceArray.constructor;
    const compact = new ArrayType(usedVertices.length * itemSize);
    for (let i = 0; i < usedVertices.length; i++) {
      const old = usedVertices[i];
      for (let c = 0; c < itemSize; c++) compact[i * itemSize + c] = sourceArray[old * stride + offset + c];
    }
    const attribute = new THREE.BufferAttribute(compact, itemSize, attr.normalized);
    attribute.name = attr.name || name;
    result.setAttribute(name, attribute);
  }
  result.setIndex(new THREE.BufferAttribute(remappedIndices, 1));
  for (const group of newGroups) result.addGroup(group.start, group.count, group.materialIndex);
  result.userData = { ...sourceGeometry.userData };
  result.computeBoundingBox();
  result.computeBoundingSphere();
  return result;
}

function buildAttributePayload(geometry) {
  // Keep shading/texture signals in the simplification error metric, not only in the exported buffers.
  const channels = [
    { name: 'normal', weight: 0.55 },
    { name: 'uv', weight: 1.25 },
    { name: 'uv1', weight: 1.0 },
    { name: 'color', weight: 0.65 },
    { name: 'tangent', weight: 0.35 }
  ];
  const active = channels
    .map((entry) => ({ ...entry, attribute: geometry.attributes[entry.name] }))
    .filter((entry) => entry.attribute && entry.attribute.itemSize >= 1 && entry.attribute.itemSize <= 4);
  const stride = active.reduce((sum, entry) => sum + entry.attribute.itemSize, 0);
  if (!stride || stride > 32) return null;
  const vertexCount = geometry.attributes.position.count;
  const values = new Float32Array(vertexCount * stride);
  const weights = [];
  let offset = 0;
  for (const entry of active) {
    const attr = entry.attribute;
    for (let c = 0; c < attr.itemSize; c++) weights.push(entry.weight);
    for (let i = 0; i < vertexCount; i++) {
      for (let c = 0; c < attr.itemSize; c++) {
        const value = c === 0 ? attr.getX(i) : c === 1 ? attr.getY(i) : c === 2 ? attr.getZ(i) : attr.getW(i);
        values[i * stride + offset + c] = Number.isFinite(value) ? value : 0;
      }
    }
    offset += attr.itemSize;
  }
  return { values, stride, weights };
}

async function simplifyOneIndexSet(indices, positions, targetTriangles, error, flags = [], attributePayload = null) {
  if (indices.length <= 3 || Math.floor(indices.length / 3) <= targetTriangles) return { indices, error: 0, reachedTarget: true };
  const targetCount = Math.max(3, Math.floor(targetTriangles) * 3);
  let simplified, actualError;
  if (attributePayload) {
    [simplified, actualError] = MeshoptSimplifier.simplifyWithAttributes(
      indices, positions, 3,
      attributePayload.values, attributePayload.stride, attributePayload.weights,
      null, targetCount, error, flags
    );
  } else {
    [simplified, actualError] = MeshoptSimplifier.simplify(indices, positions, 3, targetCount, error, flags);
  }
  return { indices: simplified, error: actualError, reachedTarget: simplified.length <= targetCount + 3 };
}

async function optimizeGame(targetTriangles) {
  const work = cloneRootAndGeometries(sourceRoot);
  const meshes = collectMeshes(work);
  const initialStats = statsOf(work);
  const eligible = meshes.filter((mesh) => !mesh.isSkinnedMesh && !(mesh.geometry.morphAttributes?.position?.length) && !mesh.isInstancedMesh);
  const skipped = meshes.length - eligible.length;
  if (!eligible.length) throw new Error('مدل فقط مش‌های ریگ‌شده، Instanced یا دارای Morph Target دارد؛ این نسخه آن‌ها را برای جلوگیری از خرابی تغییر نمی‌دهد.');
  const eligibleTriangles = eligible.reduce((sum, mesh) => sum + getTriangleCount(mesh.geometry), 0);
  if (!eligibleTriangles) throw new Error('در هندسهٔ مدل مثلث قابل پردازشی پیدا نشد.');
  let done = 0;
  let maxError = 0;
  let inputIndexed = 0;
  let outputFaces = 0;
  const maxAllowedError = QUALITY[qualityMode].gameError;

  for (const mesh of eligible) {
    let geometry = mesh.geometry;
    if (!geometry.index) geometry = mergeVertices(geometry, 1e-6);
    if (!geometry.index || geometry.index.count < 3) { done++; continue; }
    const positions = getPositionArray(geometry);
    const attributePayload = buildAttributePayload(geometry);
    const fullIndices = getIndexArray(geometry);
    const geometryTriangles = Math.floor(fullIndices.length / 3);
    const meshTarget = Math.max(1, Math.floor(targetTriangles * geometryTriangles / eligibleTriangles));
    const sourceGroups = geometry.groups?.length
      ? geometry.groups.map((g) => ({ start: Math.max(0, g.start), count: Math.max(0, Math.min(g.count, fullIndices.length - g.start)), materialIndex: g.materialIndex }))
      : [{ start: 0, count: fullIndices.length, materialIndex: null }];
    const pieces = [];
    let groupFaces = 0;
    for (const group of sourceGroups) groupFaces += Math.floor(group.count / 3);
    for (const group of sourceGroups) {
      const slice = fullIndices.slice(group.start, group.start + group.count);
      const groupTriangleCount = Math.floor(slice.length / 3);
      if (groupTriangleCount < 1) continue;
      const groupTarget = Math.max(1, Math.floor(meshTarget * groupTriangleCount / Math.max(1, groupFaces)));
      const result = await simplifyOneIndexSet(slice, positions, groupTarget, maxAllowedError, ['LockBorder'], attributePayload);
      maxError = Math.max(maxError, result.error || 0);
      pieces.push({ indices: result.indices, materialIndex: group.materialIndex });
      outputFaces += result.indices.length / 3;
    }
    if (pieces.length) {
      const compacted = compactGeometry(geometry, pieces);
      if (!compacted.attributes.normal) compacted.computeVertexNormals();
      mesh.geometry = compacted;
    }
    inputIndexed += geometryTriangles;
    done++;
    setProgress('کاهش مش‌های بازی…', 20 + 65 * done / eligible.length, `مش ${formatNumber(done)} از ${formatNumber(eligible.length)} · حفظ UV و متریال`);
    await new Promise((r) => setTimeout(r, 0));
  }
  work.updateMatrixWorld(true);
  const finalStats = statsOf(work);
  return { root: work, before: initialStats, after: finalStats, maxError, skipped, outputFaces, inputIndexed };
}

function collectWorldMeshBounds(root) {
  root.updateMatrixWorld(true);
  const box = new THREE.Box3();
  const temp = new THREE.Vector3();
  let any = false;
  for (const mesh of collectMeshes(root)) {
    const p = mesh.geometry.attributes.position;
    for (let i = 0; i < p.count; i++) {
      temp.set(p.getX(i), p.getY(i), p.getZ(i)).applyMatrix4(mesh.matrixWorld);
      box.expandByPoint(temp); any = true;
    }
  }
  return any ? box : new THREE.Box3(new THREE.Vector3(), new THREE.Vector3());
}

function buildPrintMesh(root) {
  root.updateMatrixWorld(true);
  const meshes = collectMeshes(root).filter((m) => !m.isSkinnedMesh && !m.isInstancedMesh);
  if (!meshes.length) throw new Error('مش ثابت قابل تبدیل به هندسهٔ چاپ پیدا نشد.');
  const worldBox = collectWorldMeshBounds(root);
  const size = worldBox.getSize(new THREE.Vector3());
  const diagonal = Math.max(size.length(), 1e-6);
  const weldEpsilon = Math.max(diagonal * 1e-7, 1e-9);
  const map = new Map();
  const points = [];
  const triangles = [];
  const v = new THREE.Vector3();
  const getOrAdd = (mesh, vertexIndex) => {
    const p = mesh.geometry.attributes.position;
    v.set(p.getX(vertexIndex), p.getY(vertexIndex), p.getZ(vertexIndex)).applyMatrix4(mesh.matrixWorld);
    const x = v.x, y = v.y, z = v.z;
    const key = `${Math.round(x / weldEpsilon)},${Math.round(y / weldEpsilon)},${Math.round(z / weldEpsilon)}`;
    let idx = map.get(key);
    if (idx === undefined) {
      idx = points.length / 3;
      map.set(key, idx);
      points.push(x, y, z);
    }
    return idx;
  };
  for (const mesh of meshes) {
    const geometry = mesh.geometry;
    const position = geometry.attributes.position;
    const index = geometry.index;
    const count = index ? index.count : position.count;
    const drawCount = Number.isFinite(geometry.drawRange?.count) ? Math.min(count, geometry.drawRange.count) : count;
    const start = Math.max(0, geometry.drawRange?.start || 0);
    const end = Math.min(count, start + drawCount);
    for (let i = start; i + 2 < end; i += 3) {
      const a = getOrAdd(mesh, index ? index.getX(i) : i);
      const b = getOrAdd(mesh, index ? index.getX(i + 1) : i + 1);
      const c = getOrAdd(mesh, index ? index.getX(i + 2) : i + 2);
      triangles.push(a, b, c);
    }
  }
  if (triangles.length < 3) throw new Error('پس از تبدیل مدل، مثلث معتبری باقی نماند.');
  const cleaned = cleanAndOrient(new Float32Array(points), new Uint32Array(triangles));
  return { ...cleaned, weldEpsilon, diagonal };
}

function cleanAndOrient(positionInput, indexInput) {
  const positions = positionInput instanceof Float32Array ? positionInput : Float32Array.from(positionInput);
  const facesIn = indexInput instanceof Uint32Array ? indexInput : Uint32Array.from(indexInput);
  const diagonal = getDiagonal(positions);
  const areaCrossLimitSq = Math.pow(Math.max(diagonal, 1e-9), 4) * 1e-24;
  const uniqueFaces = new Set();
  const good = [];
  let degenerateRemoved = 0, duplicateRemoved = 0;
  for (let i = 0; i + 2 < facesIn.length; i += 3) {
    const a = facesIn[i], b = facesIn[i + 1], c = facesIn[i + 2];
    if (a === b || b === c || c === a) { degenerateRemoved++; continue; }
    const ax = positions[a * 3], ay = positions[a * 3 + 1], az = positions[a * 3 + 2];
    const bx = positions[b * 3], by = positions[b * 3 + 1], bz = positions[b * 3 + 2];
    const cx = positions[c * 3], cy = positions[c * 3 + 1], cz = positions[c * 3 + 2];
    const abx = bx - ax, aby = by - ay, abz = bz - az;
    const acx = cx - ax, acy = cy - ay, acz = cz - az;
    const nx = aby * acz - abz * acy, ny = abz * acx - abx * acz, nz = abx * acy - aby * acx;
    if (nx * nx + ny * ny + nz * nz <= areaCrossLimitSq) { degenerateRemoved++; continue; }
    const sorted = [a, b, c].sort((x, y) => x - y);
    const key = `${sorted[0]}_${sorted[1]}_${sorted[2]}`;
    if (uniqueFaces.has(key)) { duplicateRemoved++; continue; }
    uniqueFaces.add(key);
    good.push(a, b, c);
  }
  let indices = Uint32Array.from(good);
  const oriented = orientIndices(positions, indices);
  indices = oriented.indices;
  const compacted = compactPositionOnly(positions, indices);
  const analyzed = analyzeTopology(compacted.positions, compacted.indices);
  const analysis = { ...analyzed, degenerateRemoved, duplicateRemoved, orientationConflicts: oriented.conflicts };
  analysis.watertight = analyzed.watertight && oriented.conflicts === 0 && analyzed.hasVolume;
  return { positions: compacted.positions, indices: compacted.indices, analysis };
}

function orientIndices(positions, indices) {
  const faceCount = Math.floor(indices.length / 3);
  const edgeMap = new Map();
  const addEdge = (a, b, face) => {
    const low = Math.min(a, b), high = Math.max(a, b);
    const key = `${low}_${high}`;
    const dir = a === low ? 1 : -1;
    let list = edgeMap.get(key);
    if (!list) edgeMap.set(key, list = []);
    list.push({ face, dir, a, b });
  };
  for (let f = 0; f < faceCount; f++) {
    const o = f * 3;
    addEdge(indices[o], indices[o + 1], f);
    addEdge(indices[o + 1], indices[o + 2], f);
    addEdge(indices[o + 2], indices[o], f);
  }
  const adjacency = Array.from({ length: faceCount }, () => []);
  for (const list of edgeMap.values()) {
    if (list.length === 2) {
      const [a, b] = list;
      adjacency[a.face].push([b.face, a.dir === b.dir ? 1 : 0]);
      adjacency[b.face].push([a.face, a.dir === b.dir ? 1 : 0]);
    }
  }
  const flip = new Int8Array(faceCount); flip.fill(-1);
  const component = new Int32Array(faceCount); component.fill(-1);
  let compCount = 0, conflicts = 0;
  for (let start = 0; start < faceCount; start++) {
    if (flip[start] !== -1) continue;
    flip[start] = 0;
    component[start] = compCount;
    const stack = [start];
    while (stack.length) {
      const f = stack.pop();
      for (const [n, relation] of adjacency[f]) {
        const expected = flip[f] ^ relation;
        if (flip[n] === -1) { flip[n] = expected; component[n] = compCount; stack.push(n); }
        else if (flip[n] !== expected) conflicts++;
      }
    }
    compCount++;
  }
  for (let f = 0; f < faceCount; f++) {
    if (flip[f] === 1) {
      const o = f * 3, t = indices[o + 1]; indices[o + 1] = indices[o + 2]; indices[o + 2] = t;
    }
  }
  const volume = new Float64Array(compCount);
  for (let f = 0; f < faceCount; f++) {
    const o = f * 3, a = indices[o], b = indices[o + 1], c = indices[o + 2];
    const ax = positions[a * 3], ay = positions[a * 3 + 1], az = positions[a * 3 + 2];
    const bx = positions[b * 3], by = positions[b * 3 + 1], bz = positions[b * 3 + 2];
    const cx = positions[c * 3], cy = positions[c * 3 + 1], cz = positions[c * 3 + 2];
    volume[component[f]] += (ax * (by * cz - bz * cy) + ay * (bz * cx - bx * cz) + az * (bx * cy - by * cx)) / 6;
  }
  for (let f = 0; f < faceCount; f++) {
    if (volume[component[f]] < 0) {
      const o = f * 3, t = indices[o + 1]; indices[o + 1] = indices[o + 2]; indices[o + 2] = t;
    }
  }
  return { indices, conflicts };
}

function compactPositionOnly(positions, indices) {
  const map = new Map();
  const used = [];
  const nextIndices = new Uint32Array(indices.length);
  for (let i = 0; i < indices.length; i++) {
    const old = indices[i];
    let n = map.get(old);
    if (n === undefined) { n = used.length; used.push(old); map.set(old, n); }
    nextIndices[i] = n;
  }
  const nextPositions = new Float32Array(used.length * 3);
  for (let i = 0; i < used.length; i++) {
    const old = used[i];
    nextPositions[i * 3] = positions[old * 3];
    nextPositions[i * 3 + 1] = positions[old * 3 + 1];
    nextPositions[i * 3 + 2] = positions[old * 3 + 2];
  }
  return { positions: nextPositions, indices: nextIndices };
}

function getDiagonal(positions) {
  if (!positions.length) return 0;
  let minX = Infinity, minY = Infinity, minZ = Infinity, maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
  for (let i = 0; i < positions.length; i += 3) {
    const x = positions[i], y = positions[i + 1], z = positions[i + 2];
    if (x < minX) minX = x; if (y < minY) minY = y; if (z < minZ) minZ = z;
    if (x > maxX) maxX = x; if (y > maxY) maxY = y; if (z > maxZ) maxZ = z;
  }
  return Math.hypot(maxX - minX, maxY - minY, maxZ - minZ);
}

function analyzeTopology(positions, indices) {
  const edges = new Map();
  const faceCount = Math.floor(indices.length / 3);
  const add = (a, b) => {
    const key = a < b ? `${a}_${b}` : `${b}_${a}`;
    edges.set(key, (edges.get(key) || 0) + 1);
  };
  for (let i = 0; i < indices.length; i += 3) {
    const a = indices[i], b = indices[i + 1], c = indices[i + 2];
    add(a, b); add(b, c); add(c, a);
  }
  let boundaryEdges = 0, nonManifoldEdges = 0;
  for (const count of edges.values()) {
    if (count === 1) boundaryEdges++;
    else if (count > 2) nonManifoldEdges++;
  }
  const oriented = orientConnectivityCount(indices, faceCount);
  let signedVolume = 0;
  for (let i = 0; i < indices.length; i += 3) {
    const a = indices[i] * 3, b = indices[i + 1] * 3, c = indices[i + 2] * 3;
    const ax = positions[a], ay = positions[a + 1], az = positions[a + 2];
    const bx = positions[b], by = positions[b + 1], bz = positions[b + 2];
    const cx = positions[c], cy = positions[c + 1], cz = positions[c + 2];
    signedVolume += (ax * (by * cz - bz * cy) + ay * (bz * cx - bx * cz) + az * (bx * cy - by * cx)) / 6;
  }
  const diagonal = getDiagonal(positions);
  const hasVolume = Math.abs(signedVolume) > Math.pow(Math.max(diagonal, 1e-9), 3) * 1e-12;
  return { faceCount, vertexCount: positions.length / 3, edgeCount: edges.size, boundaryEdges, nonManifoldEdges, components: oriented.components, signedVolume: Math.abs(signedVolume), hasVolume, watertight: boundaryEdges === 0 && nonManifoldEdges === 0 && hasVolume };
}

function orientConnectivityCount(indices, faceCount) {
  const edgeMap = new Map();
  const add = (a, b, f) => {
    const key = a < b ? `${a}_${b}` : `${b}_${a}`;
    if (!edgeMap.has(key)) edgeMap.set(key, []);
    edgeMap.get(key).push(f);
  };
  for (let f = 0; f < faceCount; f++) {
    const o = f * 3;
    add(indices[o], indices[o + 1], f); add(indices[o + 1], indices[o + 2], f); add(indices[o + 2], indices[o], f);
  }
  const adj = Array.from({ length: faceCount }, () => []);
  for (const fs of edgeMap.values()) if (fs.length === 2) { adj[fs[0]].push(fs[1]); adj[fs[1]].push(fs[0]); }
  const visited = new Uint8Array(faceCount);
  let components = 0;
  for (let i = 0; i < faceCount; i++) {
    if (visited[i]) continue;
    components++;
    const stack = [i]; visited[i] = 1;
    while (stack.length) { const f = stack.pop(); for (const n of adj[f]) if (!visited[n]) { visited[n] = 1; stack.push(n); } }
  }
  return { components };
}

// A simpler robust implementation for optional hole caps; each eligible loop is recorded atomically.
function fillSmallLoopsSafe(meshData) {
  const { positions, indices } = meshData;
  const edgeMap = new Map();
  for (let f = 0; f < indices.length / 3; f++) {
    const o = f * 3;
    for (const [a, b] of [[indices[o], indices[o + 1]], [indices[o + 1], indices[o + 2]], [indices[o + 2], indices[o]]]) {
      const key = a < b ? `${a}_${b}` : `${b}_${a}`;
      if (!edgeMap.has(key)) edgeMap.set(key, []);
      edgeMap.get(key).push({ a, b });
    }
  }
  const boundary = [...edgeMap.values()].filter((list) => list.length === 1).map((list) => list[0]);
  const next = new Map(), prev = new Map();
  for (const e of boundary) {
    if (!next.has(e.a)) next.set(e.a, []);
    if (!prev.has(e.b)) prev.set(e.b, []);
    next.get(e.a).push(e.b); prev.get(e.b).push(e.a);
  }
  const seen = new Set(), newVertices = [], newFaces = [];
  const diag = getDiagonal(positions), maxRadius = diag * 0.015;
  for (const edge of boundary) {
    if (seen.has(edge.a)) continue;
    const loop = [];
    let id = edge.a, valid = true;
    for (let k = 0; k < 32; k++) {
      if (seen.has(id)) { if (id !== edge.a) valid = false; break; }
      seen.add(id); loop.push(id);
      const outs = next.get(id), ins = prev.get(id);
      if (!outs || outs.length !== 1 || !ins || ins.length !== 1) { valid = false; break; }
      id = outs[0];
      if (id === edge.a) break;
      if (k === 31) valid = false;
    }
    if (!valid || id !== edge.a || loop.length < 3 || loop.length > 24) continue;
    const center = new THREE.Vector3();
    for (const n of loop) center.add(new THREE.Vector3(positions[n * 3], positions[n * 3 + 1], positions[n * 3 + 2]));
    center.multiplyScalar(1 / loop.length);
    let radius = 0;
    for (const n of loop) radius = Math.max(radius, center.distanceTo(new THREE.Vector3(positions[n * 3], positions[n * 3 + 1], positions[n * 3 + 2])));
    if (radius * 2 > maxRadius) continue;
    const centerIndex = positions.length / 3 + newVertices.length / 3;
    newVertices.push(center.x, center.y, center.z);
    for (let i = 0; i < loop.length; i++) {
      // Reverse each existing boundary edge to close the oriented surface.
      newFaces.push(loop[(i + 1) % loop.length], loop[i], centerIndex);
    }
  }
  if (!newFaces.length) return { ...meshData, filled: 0 };
  const combinedPositions = new Float32Array(positions.length + newVertices.length);
  combinedPositions.set(positions); combinedPositions.set(newVertices, positions.length);
  const combinedIndices = new Uint32Array(indices.length + newFaces.length);
  combinedIndices.set(indices); combinedIndices.set(newFaces, indices.length);
  const result = cleanAndOrient(combinedPositions, combinedIndices);
  return { ...result, filled: Math.max(0, result.analysis.faceCount - indices.length / 3) };
}

async function optimizePrint(targetTriangles) {
  setProgress('یکپارچه‌سازی و تحلیل اولیه…', 12, 'رأس‌های هم‌مکان و مثلث‌های خراب بررسی می‌شوند.');
  const built = buildPrintMesh(sourceRoot);
  let pre = built;
  let filled = 0;
  if (ui.fillSmallHoles.checked) {
    setProgress('بررسی سوراخ‌های کوچک…', 18, 'فقط حلقه‌های کوچک و ساده بررسی می‌شوند.');
    const filledResult = fillSmallLoopsSafe(pre);
    pre = filledResult;
    filled = filledResult.filled || 0;
  }
  const beforeReport = pre.analysis;
  const beforeFaceCount = pre.indices.length / 3;
  const qualityError = QUALITY[qualityMode].printError;
  setProgress('کاهش هندسه برای چاپ…', 28, 'کاهش با سقف خطای محافظه‌کارانه و قفل مرزها.');
  let simplifiedIndices = pre.indices;
  let maxError = 0;
  if (beforeFaceCount > targetTriangles) {
    const result = await simplifyOneIndexSet(pre.indices, pre.positions, targetTriangles, qualityError, ['LockBorder']);
    simplifiedIndices = result.indices;
    maxError = result.error || 0;
  }
  setProgress('کنترل سلامت هندسه…', 72, 'لبه‌های باز، اتصال سطوح و حجم مدل دوباره بررسی می‌شوند.');
  let candidate = cleanAndOrient(pre.positions, simplifiedIndices);
  let reverted = false;
  if (beforeReport.watertight && !candidate.analysis.watertight) {
    candidate = pre;
    reverted = true;
  } else if (candidate.analysis.nonManifoldEdges > beforeReport.nonManifoldEdges || candidate.analysis.boundaryEdges > beforeReport.boundaryEdges) {
    candidate = pre;
    reverted = true;
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(candidate.positions, 3));
  geometry.setIndex(new THREE.BufferAttribute(candidate.indices, 1));
  geometry.computeVertexNormals();
  geometry.computeBoundingBox(); geometry.computeBoundingSphere();
  const outputRoot = new THREE.Group();
  outputRoot.add(new THREE.Mesh(geometry, new THREE.MeshStandardMaterial({ color: 0xb9c7d4, roughness: 0.78, metalness: 0.04, side: THREE.DoubleSide })));
  return { root: outputRoot, before: statsOf(sourceRoot), after: { triangles: candidate.analysis.faceCount, vertices: candidate.analysis.vertexCount, meshCount: 1 }, report: candidate.analysis, beforeReport, maxError, filled, reverted, reachedTarget: candidate.analysis.faceCount <= targetTriangles };
}

function makeDiagnostics(report, beforeReport, result) {
  const items = [];
  if (result.reverted) items.push('کاهش نهایی به‌دلیل بدتر شدن اتصال لبه‌ها کنار گذاشته شد؛ نسخهٔ پایدارتر نگه داشته شد.');
  if (result.filled > 0) items.push(`${formatNumber(result.filled)} وجه برای بستن حلقه‌های کوچک اضافه شد؛ این ترمیم خودکار را حتماً چشمی بررسی کن.`);
  if (report.boundaryEdges > 0) items.push(`${formatNumber(report.boundaryEdges)} لبهٔ مرزی باز وجود دارد؛ مدل از نظر توپولوژی کاملاً بسته نیست.`);
  if (report.nonManifoldEdges > 0) items.push(`${formatNumber(report.nonManifoldEdges)} لبهٔ غیرمنفولد (دارای بیش از دو وجه مجاور) شناسایی شد.`);
  if (report.degenerateRemoved > 0) items.push(`${formatNumber(report.degenerateRemoved)} مثلث با مساحت صفر یا بسیار ناچیز حذف شد.`);
  if (report.duplicateRemoved > 0) items.push(`${formatNumber(report.duplicateRemoved)} مثلث تکراری حذف شد.`);
  if (report.orientationConflicts > 0) items.push(`${formatNumber(report.orientationConflicts)} تعارض جهت‌یابی سطح باقی مانده است.`);
  if (!report.hasVolume) items.push('حجم محصور قابل تشخیص نیست؛ ممکن است مدل فقط یک پوستهٔ تخت یا سطح باز باشد.');
  if (result.skipped) items.push(`${formatNumber(result.skipped)} مش ریگ‌شده، Instanced یا دارای Morph Target دست‌نخورده باقی ماند.`);
  if (!result.reachedTarget) items.push('تعداد هدف به‌دست نیامد؛ سقف خطای کیفیت یا محدودیت توپولوژی مانع کاهش بیشتر شد.');
  if (report.watertight) items.push('تمام لبه‌ها دقیقاً دو وجه مجاور دارند؛ آزمون پایهٔ بسته‌بودن مش موفق بود.');
  if (report.components > 1) items.push(`مدل شامل ${formatNumber(report.components)} پوسته/جزء جدا از هم است؛ تعداد قطعات را در اسلایسر بررسی کن.`);
  return items;
}

async function exportResult(root, mode) {
  if (mode === 'print') {
    const exporter = new STLExporter();
    const data = exporter.parse(root, { binary: true });
    const buffer = data instanceof DataView ? data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength) : data;
    return new Blob([buffer], { type: 'model/stl' });
  }
  const exporter = new GLTFExporter();
  const result = await exporter.parseAsync(root, { binary: true, onlyVisible: true, trs: false, includeCustomExtensions: true, animations: sourceAnimations });
  return new Blob([result], { type: 'model/gltf-binary' });
}

async function runOptimization() {
  if (!sourceRoot || isBusy) return;
  let target;
  try { target = getTarget(); } catch (error) { showError('تنظیم هدف نامعتبر است', error.message); return; }
  isBusy = true;
  ui.optimizeBtn.disabled = true;
  ui.downloadBtn.disabled = true;
  ui.progressWrap.hidden = false;
  try {
    await MeshoptSimplifier.ready;
    setProgress('شروع پردازش…', 5, 'موتور کاهش مش آماده است.');
    let result;
    if (currentMode === 'print') result = await optimizePrint(target);
    else result = await optimizeGame(target);
    optimizedRoot = result.root;
    setProgress('ساخت فایل خروجی…', 88, currentMode === 'print' ? 'در حال ساخت فایل STL باینری.' : 'در حال ساخت فایل GLB همراه با متریال و بافت‌ها.');
    resultBlob = await exportResult(optimizedRoot, currentMode);
    resultFormat = currentMode === 'print' ? 'STL' : 'GLB';
    const base = (currentFile?.name || 'model').replace(/\.[^.]+$/, '');
    resultFilename = `${base}_meshmaster_optimized.${currentMode === 'print' ? 'stl' : 'glb'}`;
    lastReport = result;
    renderResult(result);
    setProgress('بهینه‌سازی کامل شد', 100, 'خروجی آمادهٔ دریافت است.');
    ui.downloadBtn.disabled = false;
    ui.downloadLabel.textContent = 'دریافت فایل بهینه‌شده';
    ui.downloadFormat.textContent = resultFormat;
    ui.showOriginal.disabled = false; ui.showOptimized.disabled = false;
    ui.showOriginal.classList.remove('active'); ui.showOptimized.classList.add('active');
    setActiveRoot(optimizedRoot, `OPTIMIZED ${resultFormat}`);
    ui.viewStatus.textContent = `مدل بهینه‌شده · ${formatNumber(result.after.triangles)} مثلث`;
    ui.reportState.textContent = 'پردازش موفق';
    ui.reportState.className = 'report-state good';
    setTimeout(() => { ui.progressWrap.hidden = true; }, 2200);
  } catch (error) {
    console.error(error);
    ui.progressWrap.hidden = true;
    showError('پردازش کامل نشد', error?.message || 'خطای ناشناخته هنگام بهینه‌سازی رخ داد.');
    ui.downloadBtn.disabled = true;
  } finally {
    isBusy = false;
    ui.optimizeBtn.disabled = !sourceRoot;
  }
}

function renderResult(result) {
  const before = result.before.triangles;
  const after = result.after.triangles;
  const reduction = before > 0 ? Math.max(0, (1 - after / before) * 100) : 0;
  ui.inputTriangles.textContent = formatNumber(before);
  ui.outputTriangles.textContent = formatNumber(after);
  ui.reductionPercent.textContent = `${reduction.toFixed(1).toLocaleString('fa-IR')}٪`;
  ui.outputSize.textContent = formatBytes(resultBlob?.size || 0);
  ui.inputSize.textContent = `ورودی: ${formatBytes(inputFileBytes)}`;
  ui.reductionLabel.textContent = `${reduction.toFixed(1).toLocaleString('fa-IR')}٪ کاهش`;
  ui.reductionFill.style.width = `${Math.min(100, reduction)}%`;
  const report = result.report;
  if (currentMode === 'print') {
    if (report.watertight) {
      setIntegrity('good', 'مش از نظر لبه‌ها بسته است', `لبهٔ باز: صفر · لبهٔ غیرمنفولد: ${formatNumber(report.nonManifoldEdges)} · اجزای جدا: ${formatNumber(report.components)}. این آزمون جایگزین تست در اسلایسر نیست.`);
    } else {
      setIntegrity('warn', 'مدل هنوز برای چاپ تأیید کامل نمی‌گیرد', `لبهٔ باز: ${formatNumber(report.boundaryEdges)} · لبهٔ غیرمنفولد: ${formatNumber(report.nonManifoldEdges)}. این موارد می‌توانند باعث خطای اسلایسر شوند.`);
    }
  } else {
    setIntegrity('good', 'خروجی GLB ساخته شد', `مثلث‌ها: ${formatNumber(after)} · خطای نسبی گزارش‌شده: ${Number(result.maxError || 0).toFixed(5)} · حفظ متریال و بافت تابع ساختار ورودی است.`);
  }
  const diagnostics = currentMode === 'print'
    ? makeDiagnostics(report, result.beforeReport, result)
    : [
      `خطای بیشینهٔ ساده‌سازی گزارش‌شده: ${Number(result.maxError || 0).toFixed(5)} (مقیاس نسبی الگوریتم).`,
      result.skipped ? `${formatNumber(result.skipped)} مش پیچیده برای جلوگیری از خراب شدن ریگ یا مورف‌تارگت بهینه نشد.` : 'همهٔ مش‌های ایستا قابل پردازش بررسی شدند.',
      result.after.triangles > getTarget() ? 'به تعداد هدف نرسیدیم؛ سقف خطا برای حفظ ظاهر رعایت شد.' : 'تعداد هدف به‌دست آمد یا کمتر از آن شد.',
      'GLB خروجی را در موتور بازی یا نمایشگر GLB خود بررسی کن؛ تفاوت‌های رندر ممکن است بین موتورها رخ دهد.'
    ];
  ui.diagnostics.innerHTML = `<ul>${diagnostics.map((s) => `<li>${escapeHtml(s)}</li>`).join('')}</ul>`;
  ui.diagnostics.hidden = false;
  if (currentMode === 'game') {
    const textures = countTextures(optimizedRoot);
    setTip(`در خروجی ${formatNumber(textures)} تصویر بافت شناسایی شد. پیش از انتشار، UV و متریال را در موتور بازی خود بررسی کن؛ فایل اصلی را نیز نگه دار.`);
  } else if (!report.watertight) {
    setTip('این STL را هنوز آمادهٔ چاپ قطعی تلقی نکن. برای ترمیم سوراخ‌های بزرگ‌تر از Meshmixer، Blender یا قابلیت Repair اسلایسر استفاده کن و دوباره آن را بررسی کن.');
  } else if (result.reverted) {
    setTip('موتور برای محافظت از سلامت توپولوژی، کاهش بیشتری را لغو کرد. در این مدل، هدف کوچک‌تر می‌توانست خطر باز شدن سطح ایجاد کند.');
  } else {
    setTip('گزارش بسته‌بودن مش موفق است؛ با این حال جهت‌گیری، ضخامت دیواره، اندازه و پشتیبانی‌ها را در اسلایسر واقعی بررسی کن.');
  }
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function downloadResult() {
  if (!resultBlob || !resultFilename) return;
  const url = URL.createObjectURL(resultBlob);
  const a = document.createElement('a');
  a.href = url; a.download = resultFilename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

function showHelp(open) {
  ui.helpModal.hidden = !open;
}

// UI events
ui.fileInput.addEventListener('change', (event) => loadFile(event.target.files?.[0]));
ui.dropZone.addEventListener('dragover', (event) => { event.preventDefault(); ui.dropZone.classList.add('dragover'); });
ui.dropZone.addEventListener('dragleave', () => ui.dropZone.classList.remove('dragover'));
ui.dropZone.addEventListener('drop', (event) => { event.preventDefault(); ui.dropZone.classList.remove('dragover'); loadFile(event.dataTransfer.files?.[0]); });
ui.removeFile.addEventListener('click', resetFile);
ui.printMode.addEventListener('click', () => setMode('print'));
ui.gameMode.addEventListener('click', () => setMode('game'));
ui.targetSelect.addEventListener('change', () => { ui.customTargetRow.hidden = ui.targetSelect.value !== 'custom'; });
ui.qualityButtons.forEach((button) => button.addEventListener('click', () => setQuality(button.dataset.quality)));
ui.optimizeBtn.addEventListener('click', runOptimization);
ui.downloadBtn.addEventListener('click', downloadResult);
ui.showOriginal.addEventListener('click', () => { if (sourceRoot) { setActiveRoot(sourceRoot, 'ORIGINAL MODEL'); ui.showOriginal.classList.add('active'); ui.showOptimized.classList.remove('active'); ui.viewStatus.textContent = 'نمایش مدل اصلی'; } });
ui.showOptimized.addEventListener('click', () => { if (optimizedRoot) { setActiveRoot(optimizedRoot, `OPTIMIZED ${resultFormat}`); ui.showOptimized.classList.add('active'); ui.showOriginal.classList.remove('active'); ui.viewStatus.textContent = 'نمایش مدل بهینه‌شده'; } });
ui.resetView.addEventListener('click', () => fitCamera(activeRoot));
ui.helpBtn.addEventListener('click', () => showHelp(true));
ui.closeHelp.addEventListener('click', () => showHelp(false));
ui.helpModal.addEventListener('click', (event) => { if (event.target === ui.helpModal) showHelp(false); });
window.addEventListener('keydown', (event) => { if (event.key === 'Escape') showHelp(false); });

async function boot() {
  window.__meshMasterBooted = true;
  initViewport();
  setMode('print');
  setQuality('detail');
  try {
    await Promise.all([MeshoptSimplifier.ready, MeshoptDecoder.ready]);
    setEngineReady(true, 'موتور آماده است');
    ui.viewStatus.textContent = 'آمادهٔ دریافت مدل';
  } catch (error) {
    console.error(error);
    setEngineReady(false, 'خطای بارگذاری موتور');
    setIntegrity('bad', 'موتور پردازش بارگذاری نشد', 'این نسخه کتابخانه‌های Three.js و meshoptimizer را از اینترنت می‌گیرد. اتصال به cdn.jsdelivr.net، پشتیبانی WebView از JavaScript Modules و فعال بودن JavaScript را بررسی کن.');
  }
}

boot();
