# Église Évangélique Nouvelle — Gestion — prototype de gestion d'église

Interface française responsive, installable comme PWA, conçue pour servir de base à une application Android de gestion de paroisse. Ce projet n'est pas l'application officielle Eklesiaio et ne copie pas son code propriétaire. Il rassemble les modules demandés et des fonctions habituelles de gestion d'église.

## Modules inclus dans ce prototype
- Tableau de bord et indicateurs
- Registre des membres
- Nouveaux visiteurs et étapes de suivi
- Présences aux cultes et réunions
- Finances : entrées, sorties, catégories, solde, export CSV et compte rendu imprimable
- Départements et ministères
- Agenda des événements
- Suivi pastoral / demandes de prière (prototype uniquement; ne pas saisir de données sensibles réelles)
- Rappels programmés stockés dans l'application
- Rapports et exports CSV
- Paramètres, sauvegarde/restauration JSON
- Interface 3D légère, responsive, palette violet/prune, cartes en relief
- Service worker et manifeste PWA

## Lancement rapide
Ouvrir `index.html` dans un navigateur moderne pour un aperçu. Pour l'installation PWA et le service worker, servir le dossier en HTTPS ou via localhost. Les polices web nécessitent Internet, mais l'application utilise des polices de secours.

## Générer un APK
1. Déployer le contenu de ce dossier sur un hébergement HTTPS (par exemple un hébergement statique).
2. Ouvrir https://www.pwabuilder.com/ et saisir l'URL hébergée.
3. Suivre les contrôles PWA, générer le package Android et récupérer les fichiers fournis par PWABuilder.
4. Pour une application de production, ouvrir le projet Android généré dans Android Studio, configurer le nom, l'icône, les permissions et signer le package avant distribution.

Un site de conversion ne peut pas fabriquer un APK à partir du ZIP sans que le contenu soit accessible et correctement configuré. Ce projet est une base PWA; il n'inclut pas encore un serveur ni une APK compilée.

## Limites importantes
- Les données sont enregistrées uniquement dans le `localStorage` du navigateur/appareil. Elles ne sont pas synchronisées entre pasteur, secrétaire et trésorier.
- Aucun système de connexion, rôles, chiffrement serveur, synchronisation cloud, envoi SMS/e-mail ou notification Android exacte n'est encore connecté.
- Les données de démonstration ne doivent pas être considérées comme une comptabilité certifiée. Avant usage réel, faire développer un backend sécurisé avec authentification, autorisations par rôle, journal d'audit, sauvegardes, export fiable et validation des règles comptables.
- Les données de suivi pastoral et religieuses sont particulièrement sensibles : n'y saisir aucune donnée réelle avant mise en place de la sécurité et des règles de confidentialité adaptées.

## Prochaine étape recommandée
Obtenir des captures d'écran de chaque menu de l'application Eklesiaio que vous utilisez, notamment finances, membres, nouveaux chrétiens, caisse, rapports, départements et paramètres. Cela permettra d'aligner les écrans et les champs sur votre version exacte. La recherche publique seule ne permet pas de vérifier tous les écrans d'une application privée ou derrière connexion.


## Personnalisation de cette version
- Logo officiel fourni par l’utilisateur intégré dans la barre latérale et comme icône de l’application.
- Nom affiché : Église Évangélique Nouvelle.
- Navigation Retour : le bouton Retour Android/navigateur revient au module précédent puis au tableau de bord, sans quitter directement l’application.
