STEADY FITNESS APP — WEBSITE ZIP

To open:
1. Extract steady_fitness_app.zip.
2. Open index.html in a web browser.

Features:
- Dashboard and weekly session target
- Quick-start workout logging
- Custom workout entries
- Progress and workout history
- Saves entries in browser local storage on this device

Note: This is the website version, not the Android project. It is a local demo and does not sync across devices.
