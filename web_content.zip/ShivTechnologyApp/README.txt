# Shiv Technology Business Manager — Starter App

## What this version does
- Offline entries stored in the browser's local storage
- Daily income/expense ledger
- Labour call and wage records
- Customer receivables
- Monthly summary with print-to-PDF and Excel-compatible CSV export
- JSON backup and restore

## Important limitation
This starter does **not** yet include automatic cloud backup. It offers manual JSON backup; upload that file to your Google Drive. Automatic online backup needs a Firebase/Google Cloud project, app configuration, and a secure sign-in/sync design.

## Quick start on Android
1. Copy `index.html` to your Android phone.
2. Open it using a browser that supports local HTML files.
3. Add a bookmark for easy access.
4. Use Backup > Download backup regularly; store the JSON file in Google Drive.
5. For PDF, open Monthly Report > PDF/Print, then choose “Save as PDF”.
6. For Excel, download the CSV and open it in Excel or a compatible spreadsheet app.

## Before using for real business
- Test with dummy entries first.
- Keep backup copies; clearing browser data can erase the local entries.
- Do not rely on the “cash flow difference” as a final accounting profit figure. Stock, taxes, unpaid bills, and other liabilities need proper accounting.
