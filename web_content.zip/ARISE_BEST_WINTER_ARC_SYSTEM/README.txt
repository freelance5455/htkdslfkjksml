ARISE BEST – WINTER ARC SYSTEM
Offline mobile-first web app.

FILES
- index.html
- style.css
- script.js
- assets/arise-best.jpg

SETUP
1. Keep the folder structure unchanged.
2. Put the supplied hero image at assets/arise-best.jpg.
3. Open index.html in a modern Android browser or package the folder in a WebView wrapper.
4. No server, backend, login, CDN, or external library is required.

DATA
Progress is stored in localStorage under ariseBestWinterArc_v1.

SAFETY
The workouts use technique-first, non-maximal guidance suitable for teens. The app does not use body-size or weight-loss goals and does not require unsafe locations.
