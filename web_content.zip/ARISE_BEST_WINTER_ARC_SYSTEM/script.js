(() => {
"use strict";
const KEY="ariseBestWinterArc_v1";
const QUESTS=[
 {id:"push",name:"PUSH QUEST",desc:"Controlled pushing work. Keep reps smooth and stop before form breaks.",xp:50,type:"small", ex:{beginner:["Incline push-ups — 2 × 6–10","Wall push-ups — 2 × 8–12"],standard:["Push-ups — 3 × 6–12","Incline push-ups — 2 × 8–12"],challenge:["Push-ups — 3 × 8–15","Slow push-ups — 2 × 5–8"]}, db:["Dumbbell floor press — 3 × 8–12"]},
 {id:"chest",name:"CHEST QUEST",desc:"Chest-focused practice with controlled range of motion.",xp:75,type:"medium",ex:{beginner:["Incline push-ups — 2 × 6–10","Knee push-ups — 2 × 6–10"],standard:["Push-ups — 3 × 8–12","Wide push-ups — 2 × 6–10"],challenge:["Push-ups — 3 × 10–15","Tempo push-ups — 2 × 6–10"]},db:["Dumbbell floor press — 3 × 8–12"]},
 {id:"legs",name:"LEG QUEST",desc:"Build lower-body strength with stable, controlled movement.",xp:100,type:"large",ex:{beginner:["Bodyweight squats — 2 × 8–12","Glute bridges — 2 × 10–15"],standard:["Squats — 3 × 8–15","Reverse lunges — 2 × 6–10/side"],challenge:["Squats — 3 × 10–15","Reverse lunges — 3 × 8–12/side"]},db:["Goblet squat — 3 × 8–12"]},
 {id:"back",name:"BACK QUEST",desc:"Train pulling muscles with safe resistance or bodyweight options.",xp:75,type:"medium",ex:{beginner:["Backpack row — 2 × 8–12","Prone Y-T raise — 2 × 6–10"],standard:["Backpack row — 3 × 8–12","Prone Y-T raise — 2 × 8–12"],challenge:["Backpack row — 3 × 10–15","Prone Y-T raise — 3 × 8–12"]},db:["One-arm dumbbell row — 3 × 8–12/side"]},
 {id:"shoulder",name:"SHOULDER QUEST",desc:"Use a comfortable range and never force overhead movement.",xp:75,type:"medium",ex:{beginner:["Wall slides — 2 × 8–12","Incline pike hold — 2 × 15–20 sec"],standard:["Pike push-ups — 2 × 6–10","Wall slides — 2 × 10–12"],challenge:["Pike push-ups — 3 × 6–10","Wall slides — 3 × 10–15"]},db:["Dumbbell shoulder press — 2 × 8–12"]},
 {id:"core",name:"CORE QUEST",desc:"Brace gently and breathe; quality matters more than speed.",xp:50,type:"small",ex:{beginner:["Dead bug — 2 × 6–10/side","Bird dog — 2 × 6–10/side"],standard:["Dead bug — 3 × 8–12/side","Plank — 2 × 20–35 sec"],challenge:["Dead bug — 3 × 10–15/side","Plank — 3 × 25–45 sec"]},db:[]},
 {id:"arms",name:"ARMS QUEST",desc:"Controlled arm work without swinging or maximal loading.",xp:50,type:"small",ex:{beginner:["Incline close push-up — 2 × 6–10","Isometric towel curl — 2 × 15–20 sec"],standard:["Close push-up — 3 × 6–12","Backpack curl — 2 × 8–12"],challenge:["Close push-up — 3 × 8–12","Backpack curl — 3 × 8–12"]},db:["Dumbbell curl — 2 × 8–12"]},
 {id:"mobility",name:"MOBILITY QUEST",desc:"Move slowly through comfortable ranges; no bouncing or forcing.",xp:50,type:"small",ex:{beginner:["Cat-cow — 2 × 6–8","Hip flexor stretch — 2 × 20 sec/side"],standard:["Cat-cow — 2 × 8–10","Thoracic rotation — 2 × 6–8/side","Hip flexor stretch — 2 × 25 sec/side"],challenge:["Cat-cow — 3 × 8–10","Thoracic rotation — 3 × 8/side","Hip flexor stretch — 2 × 30 sec/side"]},db:[]},
 {id:"recovery",name:"RECOVERY QUEST",desc:"Recovery is part of training. Easy movement, hydration and rest.",xp:50,type:"small",ex:{beginner:["Easy mobility — 5 min","Slow breathing — 2 min"],standard:["Easy mobility — 7 min","Slow breathing — 3 min"],challenge:["Easy mobility — 10 min","Slow breathing — 3 min"]},db:[]}
];
const ACH=[
 ["first","First Quest","Complete your first quest.","⚔️"],
 ["combo3","3 Quest Combo","Complete 3 quests in a combo.","🔥"],
 ["streak7","7 Day Streak","Maintain a 7-day streak.","📅"],
 ["q10","10 Quests Complete","Complete 10 total quests.","🏆"],
 ["q25","25 Quests Complete","Complete 25 total quests.","💎"],
 ["boss","Winter Guardian Defeated","Defeat the weekly boss.","👹"],
 ["srank","S-Rank Unlocked","Reach S-Rank through consistent quest completion.","👑"]
];
const defaults={xp:0,level:1,streak:0,longestStreak:0,combo:0,totalQuests:0,rank:"E",completedToday:[],completedDates:[],bossHp:1000,bossesDefeated:0,achievements:[],mode:"beginner",dumbbells:false,sound:true,animations:true,lastDay:null,bossWeek:"",bonusQuest:false};
let s=load();
const $=id=>document.getElementById(id);
function load(){try{return {...defaults,...JSON.parse(localStorage.getItem(KEY)||"{}")}}catch{return {...defaults}}}
function save(){localStorage.setItem(KEY,JSON.stringify(s))}
function dayKey(d=new Date()){return d.toLocaleDateString("en-CA")}
function weekKey(d=new Date()){const x=new Date(d);x.setHours(0,0,0,0);x.setDate(x.getDate()+4-(x.getDay()||7));const y=new Date(x.getFullYear(),0,1);return `${x.getFullYear()}-${Math.ceil((((x-y)/86400000)+1)/7)}`}
function initDaily(){const today=dayKey(); if(s.lastDay!==today){const prev=s.lastDay;if(prev){const diff=Math.round((new Date(today)-new Date(prev))/86400000);if(diff===1){s.streak=Math.max(1,s.streak)}else if(diff>1){s.streak=0;s.combo=0}}s.completedToday=[];s.lastDay=today}
 const wk=weekKey(); if(s.bossWeek!==wk){s.bossWeek=wk;s.bossHp=1000;s.bonusQuest=false}
 save()}
function totalXpForLevel(){return 250+(s.level-1)*100}
function rankFrom(){const q=s.totalQuests; if(q>=30)return"S";if(q>=20)return"A";if(q>=12)return"B";if(q>=7)return"C";if(q>=3)return"D";return"E"}
function maybeRank(){const old=s.rank;s.rank=rankFrom();if(s.rank==="S"&&!s.achievements.includes("srank")){s.achievements.push("srank");showModal("👑","S-RANK UNLOCKED","You reached S-Rank through consistent quest completion.");}}
function gainXp(amount){
 let levelled=false;s.xp+=amount;
 while(s.xp>=totalXpForLevel()){s.xp-=totalXpForLevel();s.level++;levelled=true}
 if(levelled && s.animations){ $("newLevel").textContent=`LV ${s.level}`;$("levelup").hidden=false;setTimeout(()=>$("levelup").hidden=true,1700)}
}
function completeQuest(id){
 if(s.completedToday.includes(id))return;
 const q=QUESTS.find(x=>x.id===id); if(!q)return;
 s.completedToday.push(id);s.totalQuests++;s.combo++;
 if(s.combo>=3)unlock("combo3");
 if(s.totalQuests===1)unlock("first");
 if(s.totalQuests>=10)unlock("q10");
 if(s.totalQuests>=25)unlock("q25");
 const today=dayKey();
 if(s.completedToday.length===1){if(!s.completedDates.includes(today)){s.completedDates.push(today);s.streak=Math.max(1,s.streak||0);s.longestStreak=Math.max(s.longestStreak,s.streak)}}
 const oldHp=s.bossHp;s.bossHp=Math.max(0,s.bossHp-q.xp);
 gainXp(q.xp);maybeRank();
 if(s.streak>=7)unlock("streak7");
 if(s.bossHp===0&&oldHp>0){s.bossesDefeated++;gainXp(200);unlock("boss");s.bonusQuest=true;showModal("🏆","WINTER GUARDIAN DEFEATED","+200 bonus XP! Mystery reward unlocked.");setTimeout(()=>mysteryReward(),350)}
 else showModal("⚔️","QUEST COMPLETE",`+${q.xp} XP gained. Combo: ${s.combo}.`);
 save();render();
}
function unlock(id){if(!s.achievements.includes(id))s.achievements.push(id)}
function mysteryReward(){const rewards=["XP BOOST","NEW RANK BADGE","NEW SYSTEM TITLE","BONUS QUEST","MYSTERY BADGE"];const r=rewards[Math.floor(Math.random()*rewards.length)];gainXp(50);save();showModal("🎁","MYSTERY REWARD",`${r} unlocked! +50 bonus XP.`);render()}
function showModal(icon,title,text){$("modalIcon").textContent=icon;$("modalTitle").textContent=title;$("modalText").textContent=text;$("modal").hidden=false}
function toast(t){$("toast").textContent=t;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),1800)}
function render(){
 $("level").textContent=s.level;$("pLevel").textContent=s.level;$("pXp").textContent=totalAllXp();
 const req=totalXpForLevel(),pct=Math.min(100,Math.round(s.xp/req*100));$("xpText").textContent=`${s.xp} / ${req} XP`;$("xpPercent").textContent=pct+"%";$("xpBar").style.width=pct+"%";
 $("streak").textContent=s.streak;$("combo").textContent=s.combo;$("todayDone").textContent=s.completedToday.length;$("rankBadge").textContent=s.rank+"-RANK";
 $("bossHpText").textContent=`${s.bossHp} HP`;$("bossBar").style.width=((s.bossHp/1000)*100)+"%";$("bossProgress").textContent=`${1000-s.bossHp} / 1000 damage dealt this week`;
 $("pQuests").textContent=s.totalQuests;$("pStreak").textContent=s.streak;$("pLongest").textContent=s.longestStreak;$("pRank").textContent=s.rank;$("pBosses").textContent=s.bossesDefeated;
 renderModes();renderQuests();renderAchievements();syncSettings();
}
function totalAllXp(){let n=0;for(let i=1;i<s.level;i++)n+=250+(i-1)*100;return n+s.xp}
function renderModes(){$$("#modeSwitch button").forEach(b=>b.classList.toggle("active",b.dataset.mode===s.mode))}
function $$(sel){return [...document.querySelectorAll(sel)]}
function renderQuests(){
 const list=$("questList");list.innerHTML="";
 QUESTS.forEach(q=>{
  const done=s.completedToday.includes(q.id);let ex=[...q.ex[s.mode]];
  if(s.dumbbells&&q.db.length)ex=[q.db[0],...ex.slice(0,Math.max(1,ex.length-1))];
  else if(!s.dumbbells&&q.id==="back")ex=["Backpack row / bodyweight alternative — 2–3 sets",...ex.slice(1)];
  else if(!s.dumbbells&&q.id==="shoulder")ex=["Pike/incline alternative — controlled reps",...ex.slice(1)];
  const el=document.createElement("article");el.className="quest card"+(done?" done":"");
  el.innerHTML=`<div class="quest-head"><h3>${q.name}</h3><span class="xp-pill">+${q.xp} XP</span></div><p>${q.desc}</p>${ex.map(e=>`<div class="exercise">• <b>${e}</b></div>`).join("")}<button class="complete" ${done?"disabled":""}>${done?"✓ COMPLETED":"COMPLETE QUEST"}</button>`;
  el.querySelector("button").onclick=()=>completeQuest(q.id);list.appendChild(el)
 })}
function renderAchievements(){
 $("achievementList").innerHTML=ACH.map(([id,n,d,ic])=>{const ok=s.achievements.includes(id);return `<div class="achievement ${ok?"":"locked"}"><div class="a-icon">${ok?ic:"🔒"}</div><div><b>${n}</b><small>${d}</small></div></div>`}).join("")
}
function syncSettings(){
 $("dbToggle").className="toggle "+(s.dumbbells?"on":"off");$("dbToggle").innerHTML=`<span></span><b>${s.dumbbells?"ON":"OFF"}</b>`;
 $("settingsDb").className="toggle "+(s.dumbbells?"on":"off");$("settingsDb").innerHTML=`<span></span><b>${s.dumbbells?"ON":"OFF"}</b>`;
 $("settingsSound").className="toggle "+(s.sound?"on":"off");$("settingsSound").innerHTML=`<span></span><b>${s.sound?"ON":"OFF"}</b>`;
 $("settingsAnim").className="toggle "+(s.animations?"on":"off");$("settingsAnim").innerHTML=`<span></span><b>${s.animations?"ON":"OFF"}</b>`;
 $("settingsMode").value=s.mode;$("soundBtn").textContent=s.sound?"🔊":"🔇"
}
function nav(page){$$(".page").forEach(p=>p.classList.toggle("active",p.id===page));$$(".bottom-nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===page));window.scrollTo({top:0,behavior:"smooth"})}
$$(".bottom-nav button").forEach(b=>b.onclick=()=>nav(b.dataset.page));
$$("#modeSwitch button").forEach(b=>b.onclick=()=>{s.mode=b.dataset.mode;save();render()});
$("dbToggle").onclick=$("settingsDb").onclick=()=>{s.dumbbells=!s.dumbbells;save();render()};
$("settingsMode").onchange=e=>{s.mode=e.target.value;save();render()};
$("settingsSound").onclick=()=>{s.sound=!s.sound;save();render()};
$("settingsAnim").onclick=()=>{s.animations=!s.animations;save();render()};
$("soundBtn").onclick=()=>{s.sound=!s.sound;save();render()};
$("startQuestBtn").onclick=()=>nav("quests");
$("modalClose").onclick=()=>{$("modal").hidden=true};
$("modal").addEventListener("click",e=>{if(e.target.id==="modal")$("modal").hidden=true});
$("resetBtn").onclick=()=>{if(confirm("Reset ALL ARISE BEST progress? This cannot be undone.")){localStorage.removeItem(KEY);s={...defaults};initDaily();render();nav("home");toast("Progress reset.")}};
document.addEventListener("keydown",e=>{if(e.key==="Escape")$("modal").hidden=true});
initDaily();render();
})();