# تطبيق أكاديمية بداية (مشروع Android)

هذا مشروع Android Studio يضم ملف HTML الأصلي داخل WebView، مع تفعيل JavaScript وDOM Storage لحفظ البيانات محليًا.

## إنشاء APK
1. ثبّت Android Studio على جهاز كمبيوتر.
2. افتح مجلد `AcademyBedaya` من Android Studio.
3. وافق على تثبيت مكونات Android SDK المطلوبة (API 35) ومزامنة Gradle.
4. من القائمة اختر **Build > Build APK(s)**.
5. ستجد الملف عادةً في `app/build/outputs/apk/debug/app-debug.apk`.

## ملاحظات
- اسم التطبيق: أكاديمية بداية.
- ملف HTML موجود في `app/src/main/assets/index.html`.
- الشعار موجود في `app/src/main/res/drawable/academy_logo.png`.
- بعض موارد HTML الحالية تُحمّل من الإنترنت (خط Cairo ومكتبة html2pdf)، لذا قد تتطلب اتصالًا بالإنترنت.
- هذا المشروع يحتاج Android SDK وGradle لتنفيذ عملية البناء؛ لا يحتوي الأرشيف على APK مبني مسبقًا.
