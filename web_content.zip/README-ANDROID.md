# Pembukuan Jualan Offline — Android project

Project Android WebView yang membundel antarmuka pembukuan secara lokal. Setelah diinstal, UI dan asetnya berjalan dari penyimpanan APK; data browser disimpan di WebView DOM storage.

## Membuat APK
Cara termudah:
1. Buat repositori GitHub baru lalu unggah seluruh isi folder project ini.
2. Buka tab **Actions**.
3. Pilih workflow **Build Android APK** lalu klik **Run workflow** (atau push ke branch `main`).
4. Setelah selesai, buka run yang berhasil, unduh artifact **Pembukuan-Jualan-APK**.
5. Ekstrak ZIP artifact untuk mendapatkan `app-debug.apk`, lalu kirim ke HP Android dan instal. Untuk pemasangan dari luar Play Store, izinkan instalasi dari sumber tersebut.

## Build lokal
Butuh JDK 17, Android SDK (platform 35 dan build-tools), serta Gradle 8.9:
`gradle assembleDebug`
APK akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
- Ini adalah APK debug untuk instalasi pribadi, belum ditandatangani sebagai rilis Play Store.
- Data tersimpan di perangkat aplikasi. Hapus data aplikasi/uninstall dapat menghapus data lokal; lakukan backup berkala.
- File PWA asal disertakan di `app/src/main/assets`.
