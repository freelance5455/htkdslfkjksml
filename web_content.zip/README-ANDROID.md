# MAZO HUB POS Android wrapper

This project is now based on the **real MAZO HUB backend/admin project** supplied by the owner.

The Android app is configured to open the existing private POS at:

https://mazo-hub-mazom5242-5664s-projects.vercel.app/admin/

That means the APK does NOT create a second backend or database. It uses the same:
- authentication
- products
- PostgreSQL database
- online orders
- stock
- staff roles
- push backend

## Build the Android project

1. Install Node.js 20+.
2. In this folder run:

```bash
npm install
npx cap add android
npx cap sync android
```

3. Open the generated `android` folder in an Android build environment.
4. Build the APK.

## Important

The URL in `capacitor.config.ts` is the current MAZO HUB deployment supplied for this project. If the production domain changes, change only that URL and run `npx cap sync android` again.

This wrapper intentionally points to `/admin/`, not `/`, so customers do not see the public store inside the POS app.
