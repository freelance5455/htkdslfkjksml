# Jajan.in — Android project (versi 1.1.0)

Proyek Android WebView membundel antarmuka pembukuan secara lokal. Versi ini menambahkan kategori pengeluaran gaji, ringkasan pengeluaran gaji, kategori pada laporan/CSV, dan tema navy-emerald yang lebih profesional.

## Membuat APK
1. Unggah isi folder proyek ini ke repositori GitHub baru.
2. Buka tab **Actions** dan jalankan workflow **Build Android APK**.
3. Unduh artifact **Jajan-in-APK** setelah build berhasil.
4. Ekstrak ZIP artifact untuk memperoleh `app-debug.apk`, lalu instal di HP Android.

## Build lokal
Butuh JDK 17, Android SDK platform 35, dan Gradle 8.9. Jalankan `gradle assembleDebug`. APK ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
- Paket ini adalah proyek sumber; APK belum dikompilasi di lingkungan ini.
- APK debug untuk penggunaan pribadi, bukan rilis Play Store.
- Data tersimpan lokal pada perangkat. Ekspor cadangan JSON secara berkala.
