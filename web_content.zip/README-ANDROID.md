# Social Media Android project

This is an Android Studio project wrapping the existing Social Media web app.
The existing HTML/CSS/JS/assets were kept under:
`app/src/main/assets/social-media/`

Not yet connected:
- Firebase project configuration
- Firebase Authentication/Firestore runtime
- Agora/LiveKit real voice transport

Next step: provide Firebase information/screenshots. Then configure the app
without adding fake/demo users or fake microphone behavior.
