M S FASHION WEBSITE — UPDATED CATALOG

Included sections:
- Handbags
- School bags
- Backpacks
- Peshawari sandals
- Wallets
- Medical coats
- Tailoring / custom stitching
- Other bags

How to preview:
1. Extract the ZIP.
2. Open index.html in a browser.
3. Tap “Add / Manage Products” to add product name, AFN price, category and photo from your phone.

IMPORTANT:
- The website file is a front-end template, not a published live website.
- Product additions/photos saved through the admin panel stay in that browser/device.
- To let everyone online see your new photos and prices, publish the site and connect a shared database or store/CMS.
- You can upload a fresh design photo whenever you add a product. Automatic daily uploads need a shared admin/backend system and someone must upload or schedule the images.
- Demo photos and prices are examples; replace them with actual products/prices.
- Google visibility requires hosting and indexing; it is not instant or guaranteed.

Contact:
0765164903
0730244921

Language: English
Currency: Afghan Afghani (AFN)
