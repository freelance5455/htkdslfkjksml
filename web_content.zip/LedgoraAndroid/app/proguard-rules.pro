# Ledgora does not require custom ProGuard rules.
