# Ledgora — Offline Android App

This is a native Android Studio project wrapping the Ledgora finance UI with all web assets bundled **inside the APK**.

## What is different from the Netlify version?
- No Netlify URL
- No website login/password
- No INTERNET permission
- `index.html` is loaded from `file:///android_asset/`
- Expenses/profile data use local WebView storage on the phone
- App launches directly into Ledgora

## Build the APK
1. Install Android Studio.
2. Open this **LedgoraAndroid** folder.
3. Let Android Studio install/sync the required Android SDK (compile SDK 35) and Gradle dependencies.
4. Select **Build → Build APK(s)**.
5. The debug APK will be under:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Copy that APK to your Android phone and install it.

## No server required
Once installed, Ledgora does not need Netlify or an internet connection to run.
