# Ledgora — Offline Android App

Ledgora is packaged as a self-contained Android app. The finance UI, logic, and data storage run locally in the APK.

## Offline / device-local behavior
- No Netlify, website, API, CDN, analytics, or external URL is used by the app.
- No `INTERNET` permission is declared.
- The WebView is configured to block network loads and prevent navigation away from the bundled app.
- `index.html` is bundled inside the APK and loaded from the app's local assets.
- Expenses, profile settings, categories, currency, and profile picture are stored in local WebView storage.
- The app does not send finance data anywhere.
- Profile pictures are selected from the device and resized before being stored locally.

## Included functionality
- INR / SGD / GBP currency selector in Profile.
- Add and delete categories; changes immediately appear on Home and Add Expense.
- Add expenses with amount, category, date, and note.
- Profile picture selection/removal.
- Local profile settings.
- Animated dark confirmation messages after successful actions.
- Clear-all-expenses confirmation.
- No demo/reset/refresh button.

## Build
Open the `LedgoraAndroid` folder in Android Studio and build the debug APK.

The generated debug APK will normally be:
`app/build/outputs/apk/debug/app-debug.apk`
