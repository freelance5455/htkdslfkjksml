# GTA VI Countdown — Android project
Created by M-OneDesignz.

## Build in Android Studio
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish and install Android SDK 35 if prompted.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK will be under app/build/outputs/apk/debug/app-debug.apk.

For Play Store distribution, use Build > Generate Signed App Bundle / APK and create/use your own signing key.

The countdown web files are bundled locally in app/src/main/assets, so the main countdown screen does not depend on a website being hosted.
