plugins { id("com.android.application") }

android {
    namespace = "com.monedesignz.gta6countdown"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.monedesignz.gta6countdown"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
