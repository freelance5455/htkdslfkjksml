ABC 스트렝스 코치 V8 Android 프로젝트 - WebView 안정화판

수정사항:
- APK 내부 assets/index.html 포함 확인
- file:///android_asset/index.html 직접 로딩 제거
- loadDataWithBaseURL(https://app.local/)로 HTML 로딩
- JavaScript / DOM Storage / localStorage 유지
- 뒤로가기 처리 유지

Android Studio에서 프로젝트를 열고 Gradle Sync 후 Build > Build APK(s)를 선택하세요.
