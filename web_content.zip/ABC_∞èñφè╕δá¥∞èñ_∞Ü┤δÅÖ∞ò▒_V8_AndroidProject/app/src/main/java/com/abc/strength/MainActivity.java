package com.abc.strength;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        loadApp();
    }

    private void loadApp() {
        try {
            InputStream in = getAssets().open("index.html");
            BufferedReader reader = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            StringBuilder html = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                html.append(line).append('\n');
            }
            reader.close();
            // Use a stable HTTPS origin instead of file:///android_asset.
            // This avoids WebView file-URL restrictions on newer Android versions.
            webView.loadDataWithBaseURL(
                "https://app.local/", html.toString(), "text/html", "UTF-8", null
            );
        } catch (Exception e) {
            webView.loadDataWithBaseURL(
                "https://app.local/",
                "<html><body style=\"padding:24px;font-family:sans-serif\"><h2>앱을 불러오지 못했습니다.</h2><p>index.html을 APK에 포함했는지 확인하세요.</p></body></html>",
                "text/html", "UTF-8", null
            );
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
