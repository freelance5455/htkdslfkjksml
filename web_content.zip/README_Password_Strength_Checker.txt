Password Strength Checker - mobile-friendly browser app

1. Open Password_Strength_Checker_App.html in Chrome or another browser.
2. On Android, find the downloaded HTML file and open it with Chrome.
3. In Chrome, use the three-dot menu and choose 'Add to Home screen' if available.

This is a browser app, not an installable APK. It checks sample input locally and does not save or send it. Use sample passwords only.
