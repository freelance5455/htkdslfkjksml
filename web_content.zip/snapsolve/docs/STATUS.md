# Integration & test status (honest list)

## Real provider connections — NOT exercised against live APIs
No API credentials were available while building, and the build sandbox could not reach provider hosts.
The adapters follow each provider's official request/response format and are covered by tests against mock servers
that assert the exact URL, headers, and body shape, but **none has been called against the live service yet.**
After adding a key, press *Test connection* (Settings → Integrations → Manage) — that is the first real proof.

| Integration | Status in this delivery | To activate |
|---|---|---|
| Anthropic Claude (Messages API) | adapter implemented, unconfigured | `ANTHROPIC_API_KEY` (+ `ANTHROPIC_MODEL`) |
| OpenAI (Chat Completions, vision) | adapter implemented, unconfigured | `OPENAI_API_KEY` (+ `OPENAI_MODEL`) |
| Google Gemini (generateContent, vision) | adapter implemented, unconfigured | `GEMINI_API_KEY` (+ `GEMINI_MODEL`) |
| OpenAI-compatible custom endpoint | adapter implemented, unconfigured; **verified end-to-end in the browser test against a local mock** | `COMPAT_API_KEY`, `COMPAT_BASE_URL`, `COMPAT_MODEL` |
| OCR.space | adapter implemented, unconfigured | `OCR_SPACE_API_KEY` |
| SymPy | **working** (tested with SymPy 1.13.3) — needs `pip install sympy` on the server | none |
| Built-in calculator / grapher | **working, offline** | none |
| Wolfram Alpha, Mathpix, Google Vision, etc. | **not implemented** | add an adapter in `src/providers/` |

## Tested (automated)
40 unit/API tests and 18 browser steps (Chromium, fake camera, mock model) — see README → Tests.

## Known limitations
* **Accuracy is the AI model's.** Checks catch arithmetic/algebra slips, not misread photos or wrong set-ups; the UI says so.
* **Perspective correction is not implemented.** Rotation (EXIF + ±8° deskew), margin trimming, contrast stretch, sharpening and manual crop/rotate are.
* Handwriting, diagrams and multi-question separation depend entirely on the vision model; with only OCR.space they are weak and the user must review the text.
* Verification covers: plain arithmetic, the model's own recomputable arithmetic, SymPy-checkable equations/derivatives/integrals/limits, and a second-AI comparison. Physics/chemistry/proofs/essays are typically **"not independently verified"** unless cross-checked.
* Never tested against real photographs of handwriting/diagrams (no sample images or live models available here); image-quality logic was tested on synthetic pages only.
* Rate limiting, caching and daily caps are in-process (single instance).
* PDF export uses the browser's print dialog ("Save as PDF"); text-to-speech and voice input depend on browser support (voice input generally needs Chrome/Edge/Safari and an internet connection).
* Camera requires HTTPS (or localhost). Flash works only where the browser exposes torch control (mostly Android Chrome).
* The service worker caches the app shell only; AI solving never works offline.
