import { openaiComplete } from './openai.js';

/** Any OpenAI-compatible /chat/completions endpoint (OpenRouter, Groq, Together, Mistral, vLLM, Ollama, ...). */
export function createCompatProvider(cfg) {
  return {
    id: 'compat',
    name: cfg.name || 'Custom provider',
    kind: 'llm',
    // Vision is only claimed when the operator says the chosen model supports it (COMPAT_VISION=true).
    capabilities: { vision: !!cfg.vision, text: true, json: false },
    env: ['COMPAT_NAME', 'COMPAT_API_KEY', 'COMPAT_BASE_URL', 'COMPAT_MODEL', 'COMPAT_VISION'],
    docs: 'https://platform.openai.com/docs/api-reference/chat',
    // Many compatible servers predate max_completion_tokens and response_format: stay conservative.
    complete: (req, creds) => openaiComplete(req, creds, { id: 'compat', tokenParam: 'max_tokens', jsonMode: false }),
    needsBaseUrl: true,
    needsModel: true,
  };
}
