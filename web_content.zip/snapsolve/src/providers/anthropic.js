import { postJson } from '../util/fetch.js';
import { ProviderError } from '../util/errors.js';

/** Anthropic Messages API adapter (https://docs.claude.com/en/api/messages). */
export const anthropicProvider = {
  id: 'anthropic',
  name: 'Anthropic Claude',
  kind: 'llm',
  capabilities: { vision: true, text: true, json: true },
  env: ['ANTHROPIC_API_KEY', 'ANTHROPIC_MODEL', 'ANTHROPIC_BASE_URL'],
  docs: 'https://console.anthropic.com/settings/keys',
  async complete(req, creds) {
    const content = [];
    if (req.image) content.push({ type: 'image', source: { type: 'base64', media_type: req.image.mime, data: req.image.data } });
    content.push({ type: 'text', text: req.user });
    const data = await postJson({
      provider: 'anthropic',
      url: `${creds.baseUrl.replace(/\/+$/, '')}/v1/messages`,
      headers: { 'x-api-key': creds.apiKey, 'anthropic-version': '2023-06-01' },
      body: { model: creds.model, max_tokens: req.maxTokens, system: req.system, messages: [{ role: 'user', content }] },
      timeoutMs: req.timeoutMs,
      retries: req.retries,
      signal: req.signal,
    });
    const text = (data?.content || []).filter((b) => b?.type === 'text').map((b) => b.text).join('');
    if (data?.stop_reason === 'refusal') throw new ProviderError({ provider: 'anthropic', code: 'blocked', message: 'anthropic declined to answer this request' });
    if (!text.trim()) throw new ProviderError({ provider: 'anthropic', code: 'bad_output', message: 'anthropic returned an empty response' });
    return {
      text,
      truncated: data?.stop_reason === 'max_tokens',
      usage: { inputTokens: data?.usage?.input_tokens ?? 0, outputTokens: data?.usage?.output_tokens ?? 0 },
    };
  },
};
