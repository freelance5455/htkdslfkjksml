import { ProviderError } from '../util/errors.js';
import { redact } from '../util/redact.js';

/**
 * OCR.space adapter (https://ocr.space/ocrapi). Plain text OCR only: it cannot read diagrams or reliably read
 * handwriting/maths, so the pipeline always asks the user to review OCR-only results before solving.
 */
export const ocrSpaceProvider = {
  id: 'ocrspace',
  name: 'OCR.space',
  kind: 'ocr',
  capabilities: { ocr: true, vision: false, text: false, handwriting: false },
  env: ['OCR_SPACE_API_KEY'],
  docs: 'https://ocr.space/ocrapi/freekey',
  async ocr({ image, language, signal, timeoutMs }, creds) {
    const form = new FormData();
    form.set('base64Image', `data:${image.mime};base64,${image.data}`);
    form.set('language', language === 'ar' ? 'ara' : 'eng');
    form.set('isOverlayRequired', 'false');
    form.set('OCREngine', '2');
    const ctl = new AbortController();
    const onAbort = () => ctl.abort();
    signal?.addEventListener('abort', onAbort, { once: true });
    const timer = setTimeout(() => ctl.abort(), timeoutMs);
    try {
      const res = await globalThis.fetch(creds.baseUrl, { method: 'POST', headers: { apikey: creds.apiKey }, body: form, signal: ctl.signal });
      if (!res.ok) {
        const code = res.status === 401 || res.status === 403 ? 'auth' : res.status === 429 ? 'rate_limited' : res.status >= 500 ? 'server' : 'bad_request';
        throw new ProviderError({ provider: 'ocrspace', code, status: res.status, retryable: code === 'server' || code === 'rate_limited', message: `ocrspace responded ${res.status}` });
      }
      const data = await res.json();
      if (data?.IsErroredOnProcessing) {
        const m = Array.isArray(data.ErrorMessage) ? data.ErrorMessage.join('; ') : String(data.ErrorMessage || 'processing error');
        throw new ProviderError({ provider: 'ocrspace', code: /key/i.test(m) ? 'auth' : 'bad_request', message: `ocrspace: ${redact(m).slice(0, 200)}` });
      }
      const text = (data?.ParsedResults || []).map((r) => r?.ParsedText || '').join('\n').trim();
      return { text };
    } catch (e) {
      if (e instanceof ProviderError) throw e;
      if (signal?.aborted) throw new ProviderError({ provider: 'ocrspace', code: 'aborted', message: 'Request cancelled' });
      throw new ProviderError({ provider: 'ocrspace', code: 'network', retryable: true, message: 'ocrspace network error or timeout' });
    } finally {
      clearTimeout(timer);
      signal?.removeEventListener('abort', onAbort);
    }
  },
};
