import { postJson } from '../util/fetch.js';
import { ProviderError } from '../util/errors.js';

/** Google Gemini adapter: generateContent (https://ai.google.dev/api/generate-content). Key goes in a header, never in the URL. */
export const geminiProvider = {
  id: 'gemini',
  name: 'Google Gemini',
  kind: 'llm',
  capabilities: { vision: true, text: true, json: true },
  env: ['GEMINI_API_KEY', 'GEMINI_MODEL', 'GEMINI_BASE_URL'],
  docs: 'https://aistudio.google.com/apikey',
  async complete(req, creds) {
    const parts = [{ text: req.user }];
    if (req.image) parts.push({ inline_data: { mime_type: req.image.mime, data: req.image.data } });
    const body = {
      systemInstruction: { parts: [{ text: req.system }] },
      contents: [{ role: 'user', parts }],
      generationConfig: {
        temperature: 0.1,
        maxOutputTokens: req.maxTokens,
        ...(req.json ? { responseMimeType: 'application/json' } : {}),
      },
    };
    const url = `${creds.baseUrl.replace(/\/+$/, '')}/models/${encodeURIComponent(creds.model)}:generateContent`;
    const data = await postJson({
      provider: 'gemini',
      url,
      headers: { 'x-goog-api-key': creds.apiKey },
      body,
      timeoutMs: req.timeoutMs,
      retries: req.retries,
      signal: req.signal,
    });
    if (data?.promptFeedback?.blockReason) {
      throw new ProviderError({ provider: 'gemini', code: 'blocked', message: `gemini blocked the prompt (${String(data.promptFeedback.blockReason).slice(0, 40)})` });
    }
    const cand = data?.candidates?.[0];
    const text = (cand?.content?.parts || []).map((p) => p?.text || '').join('');
    if (!text.trim()) throw new ProviderError({ provider: 'gemini', code: 'bad_output', message: 'gemini returned an empty response' });
    return {
      text,
      truncated: cand?.finishReason === 'MAX_TOKENS',
      usage: { inputTokens: data?.usageMetadata?.promptTokenCount ?? 0, outputTokens: data?.usageMetadata?.candidatesTokenCount ?? 0 },
    };
  },
};
