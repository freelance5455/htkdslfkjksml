import fs from 'node:fs';
import path from 'node:path';
import { openaiProvider } from './openai.js';
import { geminiProvider } from './gemini.js';
import { anthropicProvider } from './anthropic.js';
import { createCompatProvider } from './compat.js';
import { ocrSpaceProvider } from './ocrspace.js';
import { AppError, ProviderError } from '../util/errors.js';
import { forgetSecret, registerSecrets } from '../util/redact.js';

const BREAKER_THRESHOLD = 3;
const BREAKER_COOLDOWN_MS = 60_000;
const today = () => new Date().toISOString().slice(0, 10);

/**
 * Owns every provider's runtime state: configured? enabled? priority? last test? usage? circuit breaker?
 * Nothing here ever hands a credential to a caller other than the adapter that needs it.
 */
export function createRegistry(cfg, { logger }) {
  const adapters = [anthropicProvider, openaiProvider, geminiProvider, createCompatProvider(cfg.providers.compat), ocrSpaceProvider];
  const settingsFile = path.join(cfg.dataDir, 'settings.json');
  let saved = {};
  try {
    saved = JSON.parse(fs.readFileSync(settingsFile, 'utf8')).providers || {};
  } catch {
    /* first run */
  }

  const state = new Map();
  adapters.forEach((a) => {
    const orderIdx = cfg.providerOrder.indexOf(a.id);
    const s = saved[a.id] || {};
    state.set(a.id, {
      enabled: s.enabled ?? true,
      priority: Number.isFinite(s.priority) ? s.priority : (orderIdx >= 0 ? orderIdx : 50) * 10 + 10,
      model: typeof s.model === 'string' ? s.model : '',
      runtimeKey: '',
      lastTest: null,
      lastSuccessAt: 0,
      lastError: null,
      consecutiveFailures: 0,
      openUntil: 0,
      stats: { requests: 0, errors: 0, totalMs: 0, inputTokens: 0, outputTokens: 0 },
      day: today(),
      dayCount: 0,
    });
  });
  let global = { day: today(), count: 0 };

  const adapter = (id) => adapters.find((a) => a.id === id);
  const get = (id) => {
    const a = adapter(id);
    if (!a) throw new AppError(404, 'UNKNOWN_PROVIDER', 'Unknown provider.');
    return { a, s: state.get(id) };
  };

  function persist() {
    try {
      fs.mkdirSync(cfg.dataDir, { recursive: true });
      const out = {};
      for (const [id, s] of state) out[id] = { enabled: s.enabled, priority: s.priority, model: s.model || undefined };
      const tmp = settingsFile + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify({ providers: out }, null, 2), { mode: 0o600 });
      fs.renameSync(tmp, settingsFile);
    } catch (e) {
      logger.warn('could not persist provider settings', { error: e.message });
    }
  }

  function creds(id) {
    const { a, s } = get(id);
    const base = cfg.providers[id] || {};
    return {
      apiKey: s.runtimeKey || base.apiKey || '',
      model: s.model || base.model || '',
      baseUrl: base.baseUrl || '',
      _name: a.name,
    };
  }
  const keySource = (id) => {
    const { s } = get(id);
    return s.runtimeKey ? 'runtime' : cfg.providers[id]?.apiKey ? 'env' : 'none';
  };
  function isConfigured(id) {
    const { a } = get(id);
    const c = creds(id);
    if (!c.apiKey) return false;
    if (a.kind === 'llm' && !c.model) return false;
    if (a.needsBaseUrl && !c.baseUrl) return false;
    return true;
  }
  function status(id) {
    const { s } = get(id);
    if (!isConfigured(id)) return 'unconfigured';
    if (!s.enabled) return 'disabled';
    if (s.lastTest && !s.lastTest.ok && s.lastTest.at >= s.lastSuccessAt) return 'error';
    if (s.openUntil > Date.now()) return 'error';
    if (s.lastTest?.ok || s.lastSuccessAt) return 'connected';
    return 'configured'; // key present, never exercised: we do NOT call this "connected"
  }

  function rollDay(s) {
    const d = today();
    if (s.day !== d) { s.day = d; s.dayCount = 0; }
    if (global.day !== d) global = { day: d, count: 0 };
  }

  function underLimits(id) {
    const { s } = get(id);
    rollDay(s);
    return s.dayCount < cfg.limits.providerDaily && global.count < cfg.limits.dailyRequests;
  }

  /** Ordered usable providers. needs: { vision?: bool }, exclude: ids to skip. */
  function candidates({ kind = 'llm', vision = false, exclude = [] } = {}) {
    return adapters
      .filter((a) => a.kind === kind)
      .filter((a) => !exclude.includes(a.id) && isConfigured(a.id) && state.get(a.id).enabled)
      .filter((a) => !vision || a.capabilities.vision)
      .filter((a) => state.get(a.id).openUntil <= Date.now() && underLimits(a.id))
      .sort((x, y) => state.get(x.id).priority - state.get(y.id).priority)
      .map((a) => a.id);
  }

  function record(id, { ok, ms, usage, err }) {
    const { s } = get(id);
    rollDay(s);
    s.dayCount++;
    global.count++;
    s.stats.requests++;
    s.stats.totalMs += ms;
    if (ok) {
      s.lastSuccessAt = Date.now();
      s.consecutiveFailures = 0;
      s.openUntil = 0;
      s.stats.inputTokens += usage?.inputTokens || 0;
      s.stats.outputTokens += usage?.outputTokens || 0;
    } else {
      s.stats.errors++;
      s.lastError = { code: err.code, message: err.message, at: Date.now() };
      // auth/bad_request problems are config faults: open the breaker immediately; transient ones need repeats.
      if (err.code === 'auth') s.consecutiveFailures = BREAKER_THRESHOLD;
      else if (err.code !== 'aborted' && err.code !== 'blocked') s.consecutiveFailures++;
      if (s.consecutiveFailures >= BREAKER_THRESHOLD) s.openUntil = Date.now() + BREAKER_COOLDOWN_MS;
    }
  }

  /**
   * Try providers in order until one succeeds. Returns { result, provider, model, ms, attempts }.
   * `validate(result)` may throw ProviderError('bad_output') to make us fall through to the next provider.
   */
  async function call(ids, req, { signal, validate } = {}) {
    if (!ids.length) throw new AppError(503, 'NO_PROVIDER', 'No AI provider is available for this request. Configure one in Settings → Integrations.');
    const attempts = [];
    for (const id of ids) {
      const { a } = get(id);
      const c = creds(id);
      const t0 = Date.now();
      try {
        let result = await a.complete({ ...req, signal, timeoutMs: cfg.timeouts.providerMs, retries: cfg.timeouts.retries }, c);
        if (validate) result = validate(result);
        const ms = Date.now() - t0;
        record(id, { ok: true, ms, usage: result.usage });
        attempts.push({ provider: id, ok: true, ms });
        return { result, provider: id, model: c.model, ms, attempts };
      } catch (e) {
        const err =
          e instanceof ProviderError
            ? e
            : new ProviderError({ provider: id, code: 'bad_output', message: `${id}: ${e.message}` });
        const ms = Date.now() - t0;
        if (err.code === 'aborted') throw new AppError(499, 'CANCELLED', 'Request cancelled.');
        record(id, { ok: false, ms, err });
        attempts.push({ provider: id, ok: false, ms, code: err.code });
        logger.warn('provider attempt failed', { provider: id, code: err.code, status: err.status, ms });
      }
    }
    const allAuth = attempts.every((x) => x.code === 'auth');
    throw new AppError(
      allAuth ? 503 : 502,
      allAuth ? 'PROVIDER_AUTH' : 'ALL_PROVIDERS_FAILED',
      allAuth
        ? 'The configured AI provider(s) rejected their credentials. An administrator must check the API keys.'
        : 'Every available AI provider failed for this request. Please try again.',
      { attempts },
    );
  }

  /** Tiny real request that proves credentials + model + network work. Costs a few tokens. */
  async function test(id, signal) {
    const { a, s } = get(id);
    if (!isConfigured(id)) {
      const lt = { ok: false, at: Date.now(), ms: 0, error: { code: 'unconfigured', message: 'No credentials/model configured.' } };
      s.lastTest = lt;
      return lt;
    }
    const t0 = Date.now();
    try {
      if (a.kind === 'ocr') {
        // 1x1 white PNG: proves the key is accepted without sending user data.
        const png = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4//8/AwAI/AL+XJ/PNQAAAABJRU5ErkJggg==';
        await a.ocr({ image: { mime: 'image/png', data: png }, language: 'en', signal, timeoutMs: cfg.timeouts.providerMs }, creds(id));
      } else {
        await a.complete(
          { system: 'Reply with the JSON object {"ok":true} and nothing else.', user: 'ping', maxTokens: 256, json: true, signal, timeoutMs: cfg.timeouts.providerMs, retries: 0 },
          creds(id),
        );
      }
      s.lastTest = { ok: true, at: Date.now(), ms: Date.now() - t0 };
      s.openUntil = 0;
      s.consecutiveFailures = 0;
    } catch (e) {
      s.lastTest = { ok: false, at: Date.now(), ms: Date.now() - t0, error: { code: e.code || 'error', message: String(e.message).slice(0, 300) } };
    }
    return s.lastTest;
  }

  function view(id, { admin = false } = {}) {
    const { a, s } = get(id);
    const c = creds(id);
    const pub = {
      id,
      name: a.name,
      kind: a.kind,
      status: status(id),
      enabled: s.enabled,
      priority: s.priority,
      capabilities: a.capabilities,
      model: a.kind === 'llm' ? c.model || null : null,
    };
    if (!admin) return pub;
    const avg = s.stats.requests ? Math.round(s.stats.totalMs / s.stats.requests) : null;
    return {
      ...pub,
      keySource: keySource(id), // "env" | "runtime" | "none" – the key itself is never exposed
      env: a.env,
      docs: a.docs,
      baseUrl: c.baseUrl || null,
      lastTest: s.lastTest,
      lastError: s.lastError ? { code: s.lastError.code, message: s.lastError.message, at: s.lastError.at } : null,
      circuitOpenUntil: s.openUntil > Date.now() ? s.openUntil : null,
      usage: { ...s.stats, avgMs: avg, today: s.dayCount, dailyLimit: cfg.limits.providerDaily },
    };
  }

  return {
    list: (opts) => adapters.map((a) => view(a.id, opts)),
    view,
    candidates,
    call,
    test,
    ocr: (id) => adapter(id),
    ocrCreds: (id) => creds(id),
    isConfigured,
    globalUsage: () => ({ day: global.day, count: global.count, limit: cfg.limits.dailyRequests }),
    update(id, patch) {
      const { s } = get(id);
      if (patch.enabled !== undefined) {
        if (typeof patch.enabled !== 'boolean') throw new AppError(400, 'BAD_INPUT', '"enabled" must be true or false.');
        s.enabled = patch.enabled;
      }
      if (patch.priority !== undefined) {
        if (!Number.isFinite(patch.priority) || patch.priority < 0 || patch.priority > 1000) throw new AppError(400, 'BAD_INPUT', '"priority" must be a number between 0 and 1000.');
        s.priority = Math.round(patch.priority);
      }
      if (patch.model !== undefined) {
        if (typeof patch.model !== 'string' || (patch.model && !/^[\w.\-:/@]{1,100}$/.test(patch.model))) throw new AppError(400, 'BAD_INPUT', 'Invalid model name.');
        s.model = patch.model;
        s.lastTest = null;
      }
      persist();
    },
    setRuntimeKey(id, key) {
      if (!cfg.allowRuntimeKeys) throw new AppError(403, 'RUNTIME_KEYS_DISABLED', 'Runtime key entry is disabled. Set the key in the server environment instead.');
      const { a, s } = get(id);
      if (typeof key !== 'string' || key.length < 8 || key.length > 400 || /\s/.test(key)) throw new AppError(400, 'BAD_INPUT', 'That does not look like an API key.');
      if (s.runtimeKey) forgetSecret(s.runtimeKey);
      s.runtimeKey = key;
      registerSecrets([key]);
      s.lastTest = null;
      s.openUntil = 0;
      s.consecutiveFailures = 0;
      logger.info('runtime key set', { provider: a.id });
    },
    clearRuntimeKey(id) {
      const { s } = get(id);
      if (s.runtimeKey) forgetSecret(s.runtimeKey);
      s.runtimeKey = '';
      s.lastTest = null;
    },
  };
}
