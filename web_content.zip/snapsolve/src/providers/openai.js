import { postJson } from '../util/fetch.js';
import { ProviderError } from '../util/errors.js';

/**
 * OpenAI Chat Completions adapter (https://platform.openai.com/docs/api-reference/chat).
 * Also used for any OpenAI-compatible endpoint via the `compat` provider (see compat.js).
 */
export function buildOpenAIBody({ model, system, user, image, maxTokens, json, tokenParam }) {
  const content = [{ type: 'text', text: user }];
  if (image) content.push({ type: 'image_url', image_url: { url: `data:${image.mime};base64,${image.data}`, detail: 'high' } });
  const body = {
    model,
    messages: [
      { role: 'system', content: system },
      { role: 'user', content: image ? content : user },
    ],
    [tokenParam]: maxTokens,
  };
  if (json) body.response_format = { type: 'json_object' };
  return body;
}

export async function openaiComplete(req, creds, { id, tokenParam = 'max_completion_tokens', jsonMode = true } = {}) {
  const url = `${creds.baseUrl.replace(/\/+$/, '')}/chat/completions`;
  const data = await postJson({
    provider: id,
    url,
    headers: { authorization: `Bearer ${creds.apiKey}` },
    body: buildOpenAIBody({ ...req, model: creds.model, json: req.json && jsonMode, tokenParam }),
    timeoutMs: req.timeoutMs,
    retries: req.retries,
    signal: req.signal,
  });
  const choice = data?.choices?.[0];
  const text = choice?.message?.content;
  if (choice?.finish_reason === 'content_filter') throw new ProviderError({ provider: id, code: 'blocked', message: `${id} blocked the response (content filter)` });
  if (typeof text !== 'string' || !text.trim()) throw new ProviderError({ provider: id, code: 'bad_output', message: `${id} returned an empty response` });
  return {
    text,
    truncated: choice?.finish_reason === 'length',
    usage: { inputTokens: data?.usage?.prompt_tokens ?? 0, outputTokens: data?.usage?.completion_tokens ?? 0 },
  };
}

export const openaiProvider = {
  id: 'openai',
  name: 'OpenAI',
  kind: 'llm',
  capabilities: { vision: true, text: true, json: true },
  env: ['OPENAI_API_KEY', 'OPENAI_MODEL', 'OPENAI_BASE_URL'],
  docs: 'https://platform.openai.com/api-keys',
  complete: (req, creds) => openaiComplete(req, creds, { id: 'openai' }),
};
