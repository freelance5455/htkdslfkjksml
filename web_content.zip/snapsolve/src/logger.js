import { redact, redactDeep } from './util/redact.js';

const LEVELS = { debug: 10, info: 20, warn: 30, error: 40, silent: 99 };

/**
 * Structured (one JSON object per line) logger.
 * Never logs request bodies, images, question text or credentials – only metadata.
 */
export function createLogger({ level = 'info', sink = (line) => process.stdout.write(line + '\n') } = {}) {
  const min = LEVELS[level] ?? LEVELS.info;
  const emit = (lvl, msg, fields) => {
    if (LEVELS[lvl] < min) return;
    const entry = { t: new Date().toISOString(), level: lvl, msg: redact(msg), ...redactDeep(fields || {}) };
    sink(JSON.stringify(entry));
  };
  return {
    debug: (m, f) => emit('debug', m, f),
    info: (m, f) => emit('info', m, f),
    warn: (m, f) => emit('warn', m, f),
    error: (m, f) => emit('error', m, f),
  };
}
