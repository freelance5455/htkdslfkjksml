import fs from 'node:fs';
import path from 'node:path';

/** Load .env (if present) using Node's built-in loader. Real environment variables always win. */
export function loadDotEnv(file = '.env') {
  try {
    if (fs.existsSync(file) && typeof process.loadEnvFile === 'function') process.loadEnvFile(file);
  } catch {
    /* a malformed .env must not crash startup; the problem shows up as "unconfigured" */
  }
}

const num = (env, k, d) => {
  const v = Number.parseInt(String(env[k] ?? '').trim(), 10);
  return Number.isFinite(v) ? v : d;
};
const bool = (env, k, d = false) => {
  const v = String(env[k] ?? '').trim();
  return v === '' ? d : /^(1|true|yes|on)$/i.test(v);
};
const str = (env, k, d = '') => {
  // strip trailing inline comments that people paste from .env.example ("123   # note")
  const raw = String(env[k] ?? d).trim();
  return raw.replace(/\s+#.*$/, '').trim();
};

export function loadConfig(env = process.env) {
  const adminToken = str(env, 'ADMIN_TOKEN');
  const cfg = {
    env: str(env, 'NODE_ENV', 'development'),
    port: num(env, 'PORT', 3000),
    host: str(env, 'HOST', '0.0.0.0'),
    trustProxy: num(env, 'TRUST_PROXY', 0),
    requireHttps: bool(env, 'REQUIRE_HTTPS'),
    corsOrigins: str(env, 'CORS_ORIGINS')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean),
    accessCode: str(env, 'ACCESS_CODE'),
    adminToken: adminToken.length >= 16 ? adminToken : '',
    adminTokenTooShort: adminToken.length > 0 && adminToken.length < 16,
    allowRuntimeKeys: bool(env, 'ALLOW_RUNTIME_KEYS'),
    dataDir: path.resolve(str(env, 'DATA_DIR', './data')),
    logLevel: str(env, 'LOG_LEVEL', 'info'),
    limits: {
      maxImageBytes: num(env, 'MAX_IMAGE_BYTES', 4_000_000),
      maxTextChars: num(env, 'MAX_TEXT_CHARS', 4000),
      maxOutputTokens: num(env, 'MAX_OUTPUT_TOKENS', 4096),
      rateWindowMs: num(env, 'RATE_WINDOW_MS', 60_000),
      rateMax: num(env, 'RATE_MAX', 120),
      solveRateMax: num(env, 'SOLVE_RATE_MAX', 12),
      dailyRequests: num(env, 'DAILY_REQUEST_LIMIT', 2000),
      providerDaily: num(env, 'PROVIDER_DAILY_LIMIT', 1000),
      cacheTtlMs: num(env, 'CACHE_TTL_MS', 600_000),
    },
    timeouts: {
      providerMs: num(env, 'PROVIDER_TIMEOUT_MS', 45_000),
      retries: Math.max(0, Math.min(5, num(env, 'PROVIDER_MAX_RETRIES', 2))),
    },
    autoCrossCheck: bool(env, 'AUTO_CROSS_CHECK'),
    providerOrder: str(env, 'PROVIDER_ORDER', 'anthropic,openai,gemini,compat')
      .split(',')
      .map((s) => s.trim().toLowerCase())
      .filter(Boolean),
    sympy: { enabled: bool(env, 'SYMPY_ENABLED', true), python: str(env, 'PYTHON_BIN', 'python3') },
    providers: {
      openai: {
        apiKey: str(env, 'OPENAI_API_KEY'),
        model: str(env, 'OPENAI_MODEL', 'gpt-4o'),
        baseUrl: str(env, 'OPENAI_BASE_URL', 'https://api.openai.com/v1'),
      },
      gemini: {
        apiKey: str(env, 'GEMINI_API_KEY'),
        model: str(env, 'GEMINI_MODEL', 'gemini-2.5-flash'),
        baseUrl: str(env, 'GEMINI_BASE_URL', 'https://generativelanguage.googleapis.com/v1beta'),
      },
      anthropic: {
        apiKey: str(env, 'ANTHROPIC_API_KEY'),
        model: str(env, 'ANTHROPIC_MODEL', 'claude-sonnet-5-5'),
        baseUrl: str(env, 'ANTHROPIC_BASE_URL', 'https://api.anthropic.com'),
      },
      compat: {
        name: str(env, 'COMPAT_NAME', 'Custom provider'),
        apiKey: str(env, 'COMPAT_API_KEY'),
        model: str(env, 'COMPAT_MODEL'),
        baseUrl: str(env, 'COMPAT_BASE_URL'),
        vision: bool(env, 'COMPAT_VISION'),
      },
      ocrspace: { apiKey: str(env, 'OCR_SPACE_API_KEY'), baseUrl: 'https://api.ocr.space/parse/image' },
    },
  };
  return cfg;
}

/** Every secret value in the config, so the logger/error layer can scrub them. */
export function collectSecrets(cfg) {
  const out = [cfg.accessCode, cfg.adminToken];
  for (const p of Object.values(cfg.providers)) out.push(p.apiKey);
  return out.filter((s) => typeof s === 'string' && s.length >= 6);
}
