import { loadDotEnv, loadConfig } from './config.js';
import { createApp } from './server.js';

loadDotEnv();
const cfg = loadConfig();
const app = createApp(cfg);
await app.start();

const shutdown = (sig) => {
  app.logger.info('shutting down', { signal: sig });
  app.close().then(() => process.exit(0));
  setTimeout(() => process.exit(1), 8000).unref();
};
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('unhandledRejection', (e) => app.logger.error('unhandledRejection', { error: String(e?.message || e) }));
