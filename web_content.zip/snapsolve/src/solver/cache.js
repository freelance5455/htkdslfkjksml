/**
 * Tiny TTL cache + in-flight de-duplication.
 * Identical requests inside the TTL reuse the previous result (no second paid API call), and two identical
 * requests arriving at the same moment share one upstream call. Holds results only – never images – in memory only.
 */
export function createCache({ ttlMs, max = 200 }) {
  const store = new Map(); // key -> { value, expires }
  const inflight = new Map(); // key -> Promise
  return {
    async wrap(key, fn) {
      const now = Date.now();
      const hit = store.get(key);
      if (hit && hit.expires > now) return { value: hit.value, cached: true };
      if (inflight.has(key)) return { value: await inflight.get(key), cached: true };
      const p = (async () => fn())();
      inflight.set(key, p);
      try {
        const value = await p;
        if (ttlMs > 0) {
          if (store.size >= max) store.delete(store.keys().next().value);
          store.set(key, { value, expires: Date.now() + ttlMs });
        }
        return { value, cached: false };
      } finally {
        inflight.delete(key);
      }
    },
    clear: () => store.clear(),
    size: () => store.size,
  };
}
