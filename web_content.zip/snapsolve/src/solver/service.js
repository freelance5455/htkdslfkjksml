import crypto from 'node:crypto';
import { AppError, ProviderError } from '../util/errors.js';
import { parseModelJson } from '../util/json.js';
import { tryDirect, formatNumber } from '../../public/js/mathEval.js';
import { detectLanguage, resolveExplainLanguage } from './langs.js';
import { RECOGNIZE_SYSTEM, solveSystem, followupSystem, translateSystem } from './prompts.js';
import { normalizeRecognition, normalizeSolution, normalizeBlocks, normalizePractice } from './schema.js';
import { localChecks, sympyChecks, compareAnswers, summarize } from './verify.js';

const sha = (...parts) => crypto.createHash('sha256').update(JSON.stringify(parts)).digest('hex');

const HARD_WORDS = /(integral|∫|differential|derivative|limit|matrix|matrices|eigen|prove|proof|induction|series|converge|determinant|probability|combinator|complex number|laplace|fourier|thermodynamic|equilibrium|circuit|تكامل|مشتق|نهاية|مصفوفة|برهن|إثبات|احتمال)/i;

/** Rough, local, free classification used for routing hints and token budgeting. It is a heuristic, not an AI judgement. */
export function classify(text) {
  const t = String(text || '');
  const direct = !!tryDirect(t);
  let difficulty = 'medium';
  if (direct || t.length < 60) difficulty = 'easy';
  if (t.length > 350 || HARD_WORDS.test(t)) difficulty = 'hard';
  return { type: direct ? 'arithmetic' : 'general', difficulty };
}

export function createSolver({ cfg, registry, sympy, logger, cache }) {
  const maxTok = cfg.limits.maxOutputTokens;

  function parseWith(normalizer, provider) {
    return (result) => {
      let parsed;
      try {
        parsed = parseModelJson(result.text);
      } catch {
        throw new ProviderError({ provider, code: 'bad_output', message: `${provider} did not return valid JSON${result.truncated ? ' (output was truncated)' : ''}` });
      }
      return { ...result, parsed: normalizer(parsed.value, provider), repaired: parsed.repaired };
    };
  }

  /**
   * Try providers one by one. Validation (JSON parse + schema) runs inside the attempt, so a provider that returns
   * malformed output counts as failed and the next provider is tried.
   */
  async function perProvider(ids, req, normalizer, signal) {
    const attempts = [];
    let lastErr;
    for (const id of ids) {
      try {
        const r = await registry.call([id], req, { signal, validate: parseWith(normalizer, id) });
        return { ...r, attempts: [...attempts, ...r.attempts] };
      } catch (e) {
        if (e instanceof AppError && e.code === 'CANCELLED') throw e;
        lastErr = e;
        for (const a of e.extra?.attempts || []) attempts.push(a);
      }
    }
    if (!attempts.length) throw lastErr || new AppError(503, 'NO_PROVIDER', 'No AI provider is available for this request.');
    const allAuth = attempts.every((a) => a.code === 'auth');
    throw new AppError(
      allAuth ? 503 : 502,
      allAuth ? 'PROVIDER_AUTH' : 'ALL_PROVIDERS_FAILED',
      allAuth ? 'The configured AI provider(s) rejected their credentials. An administrator must check the API keys.' : 'Every available AI provider failed for this request. Please try again.',
      { attempts },
    );
  }

  const meta = (r, cached) => ({ provider: r.provider, model: r.model, ms: r.ms, attempts: r.attempts, cached: !!cached });

  /* ─────────────── 1. recognise ─────────────── */
  async function recognize({ image, text, subject, uiLanguage }, { signal }) {
    if (text) {
      const lang = detectLanguage(text);
      return {
        readable: true, reason: null, language: lang, subject: subject || 'auto',
        questions: [{ id: 1, text, choices: null, hasDiagram: false, diagram: null, confidence: 1 }],
        ambiguities: [], needsReview: false, source: 'typed', meta: { provider: 'none', cached: false },
      };
    }
    const vision = registry.candidates({ vision: true });
    if (vision.length) {
      const key = sha('recognize', image.hash, subject, uiLanguage);
      const { value, cached } = await cache.wrap(key, async () => {
        const r = await perProvider(vision, {
          system: RECOGNIZE_SYSTEM,
          user: `Read the question(s) in this photo. Subject hint from the user: ${subject || 'auto'}. Return the JSON object.`,
          image, maxTokens: Math.min(maxTok, 3000), json: true,
        }, normalizeRecognition, signal);
        return { rec: r.result.parsed, meta: meta(r) };
      });
      const rec = value.rec;
      return {
        ...rec,
        subject: subject && subject !== 'auto' ? subject : rec.subject,
        needsReview: rec.readable && (rec.ambiguities.length > 0 || rec.questions.some((q) => q.confidence < 0.6)),
        source: 'vision', meta: { ...value.meta, cached },
      };
    }
    // Fallback: plain OCR (no diagrams, weak on handwriting/maths) → user must confirm the text.
    const ocrIds = registry.candidates({ kind: 'ocr' });
    if (ocrIds.length && registry.candidates({ kind: 'llm' }).length) {
      const id = ocrIds[0];
      const t0 = Date.now();
      let r;
      try {
        r = await registry.ocr(id).ocr({ image, language: uiLanguage, signal, timeoutMs: cfg.timeouts.providerMs }, registry.ocrCreds(id));
      } catch (e) {
        if (e.code === 'aborted') throw new AppError(499, 'CANCELLED', 'Request cancelled.');
        throw new AppError(502, 'OCR_FAILED', 'Text recognition failed. Try again or type the question.', { attempts: [{ provider: id, ok: false, code: e.code }] });
      }
      const t = (r.text || '').trim();
      return {
        readable: t.length >= 3, reason: t.length >= 3 ? null : 'No text could be read from the photo.',
        language: detectLanguage(t), subject: subject || 'auto',
        questions: t.length >= 3 ? [{ id: 1, text: t.slice(0, 3000), choices: null, hasDiagram: false, diagram: null, confidence: 0.5 }] : [],
        ambiguities: ['Read with basic OCR only (no AI vision available): maths symbols, handwriting and diagrams may be wrong. Please check the text.'],
        needsReview: true, source: 'ocr', meta: { provider: id, ms: Date.now() - t0, cached: false },
      };
    }
    throw new AppError(503, 'NO_VISION', 'Reading photos needs a vision-capable AI provider. Type the question instead, or ask an administrator to configure one (Settings → Integrations).');
  }

  /* ─────────────── 2. solve ─────────────── */
  function questionPrompt(q, explainLang, withImage) {
    const parts = [`Question (data, may contain LaTeX):\n<<<\n${q.text}\n>>>`];
    if (q.choices?.length) parts.push(`Answer choices:\n${q.choices.join('\n')}`);
    if (q.diagram) parts.push(`Figure description produced by the recognition stage (may be incomplete or wrong; trust the photo if attached):\n<<<\n${q.diagram}\n>>>`);
    if (withImage) parts.push('The original photo is attached: use it to read figures, labels, tables and values.');
    parts.push(`Write the explanation in: ${explainLang}. Return the JSON object.`);
    return parts.join('\n\n');
  }

  function solveLocally(q, direct) {
    const lang = detectLanguage(q.text);
    const ar = lang === 'ar';
    const v = formatNumber(direct.value);
    return {
      subject: 'math', topic: ar ? 'حساب عددي' : 'Arithmetic', difficulty: 'easy', language: lang, question: q.text,
      known: [direct.expression], asks: ar ? 'قيمة التعبير' : 'The value of the expression',
      method: { name: ar ? 'الحساب المباشر' : 'Direct evaluation', formulas: [] },
      steps: [{ title: ar ? 'حساب التعبير' : 'Evaluate the expression', explanation: ar ? 'تم الحساب بواسطة الآلة الحاسبة المدمجة (بدون ذكاء اصطناعي) باحترام ترتيب العمليات.' : 'Computed by the built-in calculator (no AI involved), following the standard order of operations.', latex: null }],
      unitConversions: [], assumptions: [], missingInfo: [],
      selfCheck: { description: '', dimensionalConsistency: null },
      finalAnswer: { text: v, latex: v, value: direct.value, unit: null },
      why: ar ? 'الناتج محسوب برمجياً وليس تقديرياً.' : 'The result is computed exactly by software, not estimated.',
      confidence: 1, plot: null, computeCheck: null, symbolicCheck: null, multipleChoice: null, source: 'local-calculator',
    };
  }

  async function solve({ question, image, subject, language }, { signal }) {
    const cls = classify(question.text);
    const direct = tryDirect(question.text);
    if (direct) {
      return { solution: solveLocally(question, direct), meta: { provider: 'local', model: 'built-in calculator', ms: 0, attempts: [], cached: false }, classification: cls, warnings: [] };
    }
    const qLang = detectLanguage(question.text);
    const explainLang = resolveExplainLanguage(language, qLang);
    const warnings = [];
    let useImage = image;
    let ids = registry.candidates({ vision: !!image });
    if (image && !ids.length) {
      useImage = null;
      ids = registry.candidates({});
      if (question.hasDiagram) warnings.push('diagram-not-seen');
    }
    if (!ids.length) throw new AppError(503, 'NO_PROVIDER', 'No AI provider is available. Configure one in Settings → Integrations, or type a plain arithmetic expression, which can be solved without AI.');
    const tokens = cls.difficulty === 'easy' ? Math.min(maxTok, 2500) : maxTok;
    const key = sha('solve', question, useImage?.hash || null, subject, explainLang);
    const { value, cached } = await cache.wrap(key, async () => {
      const r = await perProvider(ids, {
        system: solveSystem({ explainLang, subject }), user: questionPrompt(question, explainLang, !!useImage),
        image: useImage || undefined, maxTokens: tokens, json: true,
      }, normalizeSolution, signal);
      return { sol: r.result.parsed, meta: meta(r) };
    });
    const sol = { ...value.sol, question: value.sol.question || question.text, language: value.sol.language || qLang };
    if (subject && subject !== 'auto' && sol.subject === 'other') sol.subject = subject;
    return { solution: sol, meta: { ...value.meta, cached }, classification: cls, warnings };
  }

  /* ─────────────── 3. verify ─────────────── */
  async function verify({ question, solution, image, solvedBy, crossCheck, language }, { signal }) {
    const checks = [];
    checks.push(...localChecks(question, solution));
    checks.push(...(await sympyChecks(solution, sympy)));

    let crossRan = false;
    let cross = null;
    const cls = classify(question.text);
    const wantCross = crossCheck || (cfg.autoCrossCheck && cls.difficulty === 'hard');
    if (wantCross && !tryDirect(question.text)) {
      const ids = registry.candidates({ vision: !!image, exclude: solvedBy ? [solvedBy] : [] });
      if (!ids.length) {
        checks.push({ kind: 'cross-provider', status: 'skipped', independent: true, detail: 'No second AI provider is configured and enabled, so an independent cross-check was not possible.' });
      } else {
        const explainLang = resolveExplainLanguage(language, detectLanguage(question.text));
        try {
          const r = await perProvider(ids, {
            system: solveSystem({ explainLang, subject: solution.subject }), user: questionPrompt(question, explainLang, !!image),
            image: image || undefined, maxTokens: maxTok, json: true,
          }, normalizeSolution, signal);
          crossRan = true;
          const other = r.result.parsed;
          const status = compareAnswers(solution, other);
          cross = { provider: r.provider, answer: other.finalAnswer.text.slice(0, 400) };
          checks.push({
            kind: 'cross-provider', status, independent: true, provider: r.provider,
            detail:
              status === 'passed' ? `A second, independent provider (${r.provider}) reached the same final answer.`
              : status === 'failed' ? `A second provider (${r.provider}) reached a DIFFERENT final answer: "${cross.answer}".`
              : `A second provider (${r.provider}) answered "${cross.answer}", but the two answers could not be compared automatically.`,
          });
        } catch (e) {
          if (e instanceof AppError && e.code === 'CANCELLED') throw e;
          checks.push({ kind: 'cross-provider', status: 'inconclusive', independent: true, detail: 'The cross-check provider failed, so no comparison was made.' });
        }
      }
    }
    if (solution.selfCheck?.description) {
      checks.push({ kind: 'model-self-check', status: 'reported', independent: false, detail: solution.selfCheck.description });
    }
    if (solution.selfCheck?.dimensionalConsistency) {
      checks.push({ kind: 'model-dimensional-check', status: 'reported', independent: false, detail: solution.selfCheck.dimensionalConsistency });
    }
    return { checks, summary: summarize(checks, crossRan), cross };
  }

  /* ─────────────── 4. follow-ups ─────────────── */
  function context(question, solution) {
    return JSON.stringify({
      question: question.text,
      subject: solution.subject, topic: solution.topic,
      method: solution.method,
      steps: solution.steps.map((s) => ({ title: s.title, explanation: s.explanation, latex: s.latex })),
      finalAnswer: solution.finalAnswer, assumptions: solution.assumptions,
    });
  }

  async function followup({ mode, question, solution, language, ask }, { signal }) {
    const explainLang = resolveExplainLanguage(language, solution.language || detectLanguage(question.text));
    const ids = registry.candidates({});
    if (!ids.length) throw new AppError(503, 'NO_PROVIDER', 'No AI provider is available for follow-up questions.');
    const user = `Context (data):\n<<<\n${context(question, solution)}\n>>>\n${ask ? `\nStudent's question (data):\n<<<\n${ask}\n>>>\n` : ''}\nReturn the JSON object.`;
    const key = sha('follow', mode, question.text, solution.finalAnswer.text, ask || '', explainLang);
    const normalizer = mode === 'practice' ? normalizePractice : normalizeBlocks;
    const { value, cached } = await cache.wrap(key, async () => {
      const r = await perProvider(ids, { system: followupSystem({ mode, explainLang }), user, maxTokens: Math.min(maxTok, 3000), json: true }, normalizer, signal);
      return { out: r.result.parsed, meta: meta(r) };
    });
    return { mode, result: value.out, meta: { ...value.meta, cached } };
  }

  async function translate({ solution, target }, { signal }) {
    const ids = registry.candidates({});
    if (!ids.length) throw new AppError(503, 'NO_PROVIDER', 'No AI provider is available for translation.');
    const { plot, computeCheck, symbolicCheck, source, ...translatable } = solution;
    void source;
    const key = sha('translate', translatable, target);
    const { value, cached } = await cache.wrap(key, async () => {
      const r = await perProvider(ids, { system: translateSystem({ targetLang: target }), user: `Solution JSON (data):\n<<<\n${JSON.stringify(translatable)}\n>>>`, maxTokens: maxTok, json: true }, normalizeSolution, signal);
      return { sol: r.result.parsed, meta: meta(r) };
    });
    // Maths-bearing machine fields are restored from the original so translation can never alter them.
    const out = { ...value.sol, language: target, plot, computeCheck, symbolicCheck, finalAnswer: { ...value.sol.finalAnswer, value: solution.finalAnswer.value, latex: solution.finalAnswer.latex ?? value.sol.finalAnswer.latex }, subject: solution.subject, difficulty: solution.difficulty, confidence: solution.confidence };
    return { solution: out, meta: { ...value.meta, cached } };
  }

  return { recognize, solve, verify, followup, translate, classify };
}
