import { ProviderError } from '../util/errors.js';
import { SUBJECTS } from '../util/validate.js';

const clip = (v, n = 4000) => (typeof v === 'string' ? v.slice(0, n) : '');
const strArr = (v, max = 30, n = 1000) =>
  (Array.isArray(v) ? v : []).map((x) => (typeof x === 'string' ? x : x == null ? '' : String(x))).map((x) => clip(x, n)).filter(Boolean).slice(0, max);
const num = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : null);
const subj = (v) => (SUBJECTS.includes(v) && v !== 'auto' ? v : 'other');
const bad = (provider, what) => new ProviderError({ provider, code: 'bad_output', message: `${provider} returned malformed ${what}` });

export function normalizeRecognition(obj, provider = 'provider') {
  if (!obj || typeof obj !== 'object') throw bad(provider, 'recognition');
  const readable = obj.readable !== false;
  const questions = (Array.isArray(obj.questions) ? obj.questions : [])
    .slice(0, 10)
    .map((q, i) => ({
      id: i + 1,
      text: clip(q?.text, 3000).trim(),
      choices: Array.isArray(q?.choices) ? strArr(q.choices, 10, 300) : null,
      hasDiagram: q?.hasDiagram === true,
      diagram: q?.diagram ? clip(q.diagram, 1500) : null,
      confidence: Math.min(1, Math.max(0, num(q?.confidence) ?? 0.5)),
    }))
    .filter((q) => q.text);
  if (readable && !questions.length) throw bad(provider, 'recognition (no questions)');
  return {
    readable: readable && questions.length > 0,
    reason: obj.reason ? clip(obj.reason, 300) : null,
    language: clip(obj.language, 12) || 'en',
    subject: subj(obj.subject),
    questions,
    ambiguities: strArr(obj.ambiguities, 10, 300),
  };
}

const CHECK_TYPES = ['equal', 'solve', 'diff', 'integrate', 'limit'];

export function normalizeSolution(obj, provider = 'provider') {
  if (!obj || typeof obj !== 'object') throw bad(provider, 'solution');
  const fa = obj.finalAnswer && typeof obj.finalAnswer === 'object' ? obj.finalAnswer : { text: obj.finalAnswer };
  const finalText = clip(fa.text == null ? '' : String(fa.text), 2000).trim();
  if (!finalText) throw bad(provider, 'solution (no final answer)');
  const steps = (Array.isArray(obj.steps) ? obj.steps : [])
    .slice(0, 30)
    .map((s) => ({ title: clip(s?.title, 200), explanation: clip(s?.explanation, 2500), latex: s?.latex ? clip(String(s.latex), 1500) : null }))
    .filter((s) => s.title || s.explanation || s.latex);

  let symbolicCheck = null;
  const sc = obj.symbolicCheck;
  if (sc && typeof sc === 'object' && CHECK_TYPES.includes(sc.type)) {
    const s = (v) => (typeof v === 'string' || typeof v === 'number' ? String(v).slice(0, 300) : '');
    symbolicCheck = { type: sc.type, a: s(sc.a), b: s(sc.b), equation: s(sc.equation), expression: s(sc.expression), variable: s(sc.variable) || 'x', point: s(sc.point), result: s(sc.result), solutions: strArr(sc.solutions, 10, 100) };
  }
  const cc = obj.computeCheck;
  const computeCheck = cc && typeof cc === 'object' && typeof cc.expression === 'string' ? { expression: cc.expression.slice(0, 300), expected: num(Number(cc.expected)) } : null;
  const pl = obj.plot;
  const plot =
    pl && typeof pl === 'object' && typeof pl.expression === 'string' && num(Number(pl.xMin)) !== null && num(Number(pl.xMax)) !== null && Number(pl.xMax) > Number(pl.xMin)
      ? { expression: pl.expression.slice(0, 200), variable: 'x', xMin: Number(pl.xMin), xMax: Number(pl.xMax) }
      : null;

  return {
    subject: subj(obj.subject),
    topic: clip(obj.topic, 200),
    difficulty: ['easy', 'medium', 'hard'].includes(obj.difficulty) ? obj.difficulty : 'medium',
    language: clip(obj.language, 12) || 'en',
    question: clip(obj.question, 3500),
    known: strArr(obj.known),
    asks: clip(obj.asks, 600),
    method: { name: clip(obj.method?.name, 200), formulas: strArr(obj.method?.formulas, 12, 500) },
    steps,
    unitConversions: strArr(obj.unitConversions, 12, 400),
    assumptions: strArr(obj.assumptions, 12, 500),
    missingInfo: strArr(obj.missingInfo, 12, 500),
    selfCheck: { description: clip(obj.selfCheck?.description, 1200), dimensionalConsistency: obj.selfCheck?.dimensionalConsistency ? clip(String(obj.selfCheck.dimensionalConsistency), 600) : null },
    finalAnswer: { text: finalText, latex: fa.latex ? clip(String(fa.latex), 1500) : null, value: num(typeof fa.value === 'string' ? Number(fa.value) : fa.value), unit: fa.unit ? clip(String(fa.unit), 40) : null },
    why: clip(obj.why, 1500),
    confidence: Math.min(1, Math.max(0, num(obj.confidence) ?? 0.5)),
    plot,
    computeCheck,
    symbolicCheck,
    multipleChoice: obj.multipleChoice && typeof obj.multipleChoice === 'object' && obj.multipleChoice.selected ? { selected: clip(String(obj.multipleChoice.selected), 200), reason: clip(obj.multipleChoice.reason, 800) } : null,
  };
}

export function normalizeBlocks(obj, provider = 'provider') {
  if (!obj || typeof obj !== 'object') throw bad(provider, 'follow-up');
  const blocks = (Array.isArray(obj.blocks) ? obj.blocks : [])
    .slice(0, 20)
    .map((b) => ({ heading: b?.heading ? clip(String(b.heading), 200) : null, text: clip(b?.text, 3000), latex: b?.latex ? clip(String(b.latex), 1500) : null }))
    .filter((b) => b.text || b.latex);
  if (!blocks.length) throw bad(provider, 'follow-up (empty)');
  const fa = obj.finalAnswer && typeof obj.finalAnswer === 'object' && obj.finalAnswer.text ? { text: clip(String(obj.finalAnswer.text), 1500), latex: obj.finalAnswer.latex ? clip(String(obj.finalAnswer.latex), 1000) : null, value: num(obj.finalAnswer.value) } : null;
  return { title: clip(obj.title, 200), blocks, finalAnswer: fa };
}

export function normalizePractice(obj, provider = 'provider') {
  const problems = (Array.isArray(obj?.problems) ? obj.problems : [])
    .slice(0, 6)
    .map((p) => ({ question: clip(p?.question, 1500), hint: p?.hint ? clip(String(p.hint), 600) : null, answer: clip(p?.answer == null ? '' : String(p.answer), 800) }))
    .filter((p) => p.question);
  if (!problems.length) throw bad(provider, 'practice set');
  return { problems };
}
