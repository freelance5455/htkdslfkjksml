import { evaluate, tryDirect, extractNumbers, numbersMatch, formatNumber } from '../../public/js/mathEval.js';

/**
 * Honest verification layer.
 *
 * Every check records WHAT was done, with which engine, and whether that engine is independent of the model that
 * produced the answer. Nothing is ever reported as "verified" unless one of these checks actually ran and passed.
 *
 * kinds:
 *   local-arithmetic  – question is a plain expression; our own evaluator computed it from scratch (strong)
 *   recompute         – our evaluator recomputed the model's own arithmetic expression (catches slips, not mis-setup)
 *   sympy             – SymPy re-solved/differentiated/integrated the model's own algebra (catches algebra/calculus slips)
 *   cross-provider    – a different AI provider solved the question independently and we compared final answers
 */
function answerNumbers(sol) {
  const out = [];
  if (Number.isFinite(sol.finalAnswer.value)) out.push(sol.finalAnswer.value);
  out.push(...extractNumbers(sol.finalAnswer.text));
  if (sol.finalAnswer.latex) out.push(...extractNumbers(sol.finalAnswer.latex));
  return out;
}

export function localChecks(question, sol) {
  const checks = [];
  const nums = answerNumbers(sol);

  const direct = tryDirect(question?.text || '');
  if (direct) {
    const hit = nums.some((n) => numbersMatch(n, direct.value, 1e-6));
    checks.push({
      kind: 'local-arithmetic',
      status: hit ? 'passed' : 'failed',
      independent: true,
      detail: hit
        ? `Computed ${direct.expression} locally = ${formatNumber(direct.value)}, which matches the answer.`
        : `Computed ${direct.expression} locally = ${formatNumber(direct.value)}, which does NOT match the stated answer.`,
      expected: direct.value,
    });
  }

  if (sol.computeCheck) {
    try {
      const v = evaluate(sol.computeCheck.expression);
      const hit = nums.some((n) => numbersMatch(n, v, 1e-4));
      checks.push({
        kind: 'recompute',
        status: hit ? 'passed' : 'failed',
        independent: false,
        detail: hit
          ? `Re-evaluated the solution's calculation (${sol.computeCheck.expression}) = ${formatNumber(v)}; it matches the answer.`
          : `Re-evaluated the solution's calculation (${sol.computeCheck.expression}) = ${formatNumber(v)}; this differs from the stated answer.`,
        expected: v,
      });
    } catch (e) {
      checks.push({ kind: 'recompute', status: 'inconclusive', independent: false, detail: `Could not evaluate the solution's calculation expression (${e.message}).` });
    }
  }
  return checks;
}

export async function sympyChecks(sol, sympy) {
  if (!sol.symbolicCheck) return [];
  if (!sympy.info().available) {
    return [{ kind: 'sympy', status: 'skipped', independent: false, detail: `Symbolic check skipped: ${sympy.info().reason || 'SymPy unavailable'}.` }];
  }
  const spec = { ...sol.symbolicCheck };
  if (spec.type === 'equal' && (!spec.a || !spec.b)) return [];
  const r = await sympy.check(spec);
  if (!r?.ok) return [{ kind: 'sympy', status: 'inconclusive', independent: false, detail: `SymPy check could not run (${r?.error || 'error'}).` }];
  return [{ kind: 'sympy', status: r.status, independent: false, detail: `SymPy: ${r.detail}` }];
}

/** Compare two final answers produced by different providers. */
export function compareAnswers(a, b) {
  if (a.multipleChoice?.selected && b.multipleChoice?.selected) {
    const norm = (s) => String(s).trim().toLowerCase().replace(/[^a-z0-9؀-ۿ]/g, '').slice(0, 3);
    return norm(a.multipleChoice.selected) === norm(b.multipleChoice.selected) ? 'passed' : 'failed';
  }
  const na = answerNumbers(a);
  const nb = answerNumbers(b);
  if (na.length && nb.length) {
    const av = Number.isFinite(a.finalAnswer.value) ? [a.finalAnswer.value] : na;
    const bv = Number.isFinite(b.finalAnswer.value) ? [b.finalAnswer.value] : nb;
    return av.some((x) => bv.some((y) => numbersMatch(x, y, 1e-4))) ? 'passed' : 'failed';
  }
  const t = (s) => s.toLowerCase().replace(/[\s$\\{}.,;:!?'"()\-]/g, '');
  const ta = t(a.finalAnswer.text);
  const tb = t(b.finalAnswer.text);
  if (ta && ta === tb) return 'passed';
  return 'inconclusive';
}

export function summarize(checks, crossCheckRan) {
  const ran = checks.filter((c) => c.status === 'passed' || c.status === 'failed');
  const failed = checks.filter((c) => c.status === 'failed');
  const passed = checks.filter((c) => c.status === 'passed');
  let status = 'unverified';
  if (failed.length) status = 'conflict';
  else if (passed.length) status = 'checked';
  return {
    status, // unverified | checked | conflict
    performed: ran.length,
    passed: passed.length,
    failed: failed.length,
    crossProvider: crossCheckRan,
    note:
      status === 'checked'
        ? 'These checks confirm the arithmetic/algebra, not that the question was read or set up correctly.'
        : status === 'conflict'
          ? 'An automatic check disagrees with the answer. Treat the result as unreliable until resolved.'
          : 'No independent automatic check could be run for this question. The answer comes from the AI model alone.',
  };
}
