import { execFile } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const SCRIPT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '..', 'python', 'sympy_check.py');

/** Optional SymPy engine. Availability is probed once; if Python/SymPy are missing the app reports that honestly. */
export function createSympy(cfg, logger) {
  let availability = null; // { available, version?, reason? }
  const run = (input, timeoutMs) =>
    new Promise((resolve) => {
      const child = execFile(cfg.python, [SCRIPT], { timeout: timeoutMs, maxBuffer: 256 * 1024, env: { ...process.env } }, (err, stdout) => {
        if (err) return resolve({ ok: false, error: err.killed ? 'timeout' : 'exec-failed' });
        try {
          resolve(JSON.parse(stdout.trim().split('\n').pop()));
        } catch {
          resolve({ ok: false, error: 'bad-output' });
        }
      });
      child.stdin.on('error', () => {});
      child.stdin.end(JSON.stringify(input));
    });

  return {
    async probe() {
      if (!cfg.enabled) return (availability = { available: false, reason: 'disabled (SYMPY_ENABLED=false)' });
      const r = await new Promise((resolve) =>
        execFile(cfg.python, ['-c', 'import sympy;print(sympy.__version__)'], { timeout: 15_000 }, (err, out) => resolve(err ? null : out.trim())),
      );
      availability = r ? { available: true, version: r } : { available: false, reason: `python3 with SymPy not found (tried "${cfg.python}"); run: pip install sympy` };
      logger.info('sympy probe', availability);
      return availability;
    },
    info: () => availability || { available: false, reason: 'not probed yet' },
    async check(spec) {
      if (!availability?.available) return { ok: false, error: 'unavailable' };
      return run(spec, 10_000);
    },
  };
}
