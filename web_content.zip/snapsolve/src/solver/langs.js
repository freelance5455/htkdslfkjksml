// Languages the solver can explain in. Add an entry here (and public/i18n/<code>.json, and UI_LANGS in util/validate.js) to add a language.
export const LANGS = {
  en: { name: 'English', dir: 'ltr' },
  ar: { name: 'Arabic (العربية)', dir: 'rtl' },
};

const ARABIC = /[؀-ۿݐ-ݿࢠ-ࣿ]/g;
const LATIN = /[A-Za-z]/g;

/** Cheap local language guess so we never pay for an API call just to detect Arabic vs English. */
export function detectLanguage(text) {
  const ar = (String(text).match(ARABIC) || []).length;
  const la = (String(text).match(LATIN) || []).length;
  if (!ar && !la) return 'en';
  return ar > la * 0.5 ? 'ar' : 'en';
}

export function resolveExplainLanguage(requested, questionLang) {
  if (requested && requested !== 'auto' && LANGS[requested]) return requested;
  return LANGS[questionLang] ? questionLang : 'en';
}
