import { ProviderError } from './errors.js';
import { redact } from './redact.js';

const sleep = (ms, signal) =>
  new Promise((resolve, reject) => {
    const t = setTimeout(resolve, ms);
    signal?.addEventListener(
      'abort',
      () => {
        clearTimeout(t);
        reject(new ProviderError({ provider: '', code: 'aborted', message: 'Request cancelled' }));
      },
      { once: true },
    );
  });

function classify(status) {
  if (status === 401 || status === 403) return { code: 'auth', retryable: false };
  if (status === 408) return { code: 'timeout', retryable: true };
  if (status === 429) return { code: 'rate_limited', retryable: true };
  if (status >= 500) return { code: 'server', retryable: true };
  return { code: 'bad_request', retryable: false };
}

/** Extract a short human-readable error from the many shapes providers use. */
function upstreamMessage(text) {
  try {
    const j = JSON.parse(text);
    const m = j?.error?.message || j?.error?.status || j?.message || j?.error || j?.ErrorMessage;
    if (m) return typeof m === 'string' ? m : JSON.stringify(m);
  } catch {
    /* not JSON */
  }
  return text;
}

/**
 * POST JSON with timeout, bounded retries (network errors, 408, 429, 5xx) and exponential backoff.
 * Uses globalThis.fetch at call time so tests can stub it.
 * Error messages are scrubbed and truncated; response bodies are never forwarded verbatim.
 */
export async function postJson({ provider, url, headers, body, timeoutMs, retries, signal }) {
  let lastErr;
  for (let attempt = 0; attempt <= retries; attempt++) {
    if (signal?.aborted) throw new ProviderError({ provider, code: 'aborted', message: 'Request cancelled' });
    const ctl = new AbortController();
    const onAbort = () => ctl.abort('client');
    signal?.addEventListener('abort', onAbort, { once: true });
    const timer = setTimeout(() => ctl.abort('timeout'), timeoutMs);
    try {
      const res = await globalThis.fetch(url, {
        method: 'POST',
        headers: { 'content-type': 'application/json', ...headers },
        body: typeof body === 'string' ? body : JSON.stringify(body),
        signal: ctl.signal,
      });
      const text = await res.text();
      if (res.ok) {
        try {
          return JSON.parse(text);
        } catch {
          throw new ProviderError({ provider, code: 'bad_output', message: 'Provider returned a non-JSON response' });
        }
      }
      const { code, retryable } = classify(res.status);
      const msg = redact(String(upstreamMessage(text))).slice(0, 300);
      lastErr = new ProviderError({
        provider,
        code,
        status: res.status,
        retryable,
        message: `${provider} responded ${res.status}${msg ? `: ${msg}` : ''}`,
      });
      if (retryable && attempt < retries) {
        const ra = Number(res.headers?.get?.('retry-after'));
        const wait = Number.isFinite(ra) && ra > 0 ? Math.min(ra * 1000, 5000) : 400 * 2 ** attempt + Math.random() * 150;
        await sleep(wait, signal);
        continue;
      }
      throw lastErr;
    } catch (e) {
      if (e instanceof ProviderError) {
        if (e.code === 'aborted') throw Object.assign(e, { provider });
        if (e === lastErr || !e.retryable) throw e;
      }
      if (signal?.aborted) throw new ProviderError({ provider, code: 'aborted', message: 'Request cancelled' });
      const timedOut = ctl.signal.aborted && ctl.signal.reason === 'timeout';
      lastErr = new ProviderError({
        provider,
        code: timedOut ? 'timeout' : 'network',
        retryable: true,
        message: timedOut ? `${provider} timed out after ${timeoutMs} ms` : `${provider} network error`,
      });
      if (attempt < retries) {
        await sleep(400 * 2 ** attempt + Math.random() * 150, signal);
        continue;
      }
      throw lastErr;
    } finally {
      clearTimeout(timer);
      signal?.removeEventListener('abort', onAbort);
    }
  }
  throw lastErr;
}
