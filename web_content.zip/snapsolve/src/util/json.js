// Robust extraction of a JSON object from model output.
//
// Models are asked for strict JSON, but real outputs sometimes arrive wrapped in code fences, preceded by chatter,
// or with LaTeX backslashes written as single "\" (so "\frac" silently turns into a form-feed + "rac" when parsed).
// This module recovers those cases without inventing content.

export function stripFences(text) {
  let s = String(text ?? '').trim();
  const m = s.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);
  if (m) s = m[1].trim();
  return s;
}

/** Find the first balanced {...} block, honouring strings/escapes. */
export function firstJsonObject(s) {
  const start = s.indexOf('{');
  if (start < 0) return null;
  let depth = 0;
  let inStr = false;
  let esc = false;
  for (let i = start; i < s.length; i++) {
    const c = s[i];
    if (inStr) {
      if (esc) esc = false;
      else if (c === '\\') esc = true;
      else if (c === '"') inStr = false;
    } else if (c === '"') inStr = true;
    else if (c === '{') depth++;
    else if (c === '}') {
      depth--;
      if (depth === 0) return s.slice(start, i + 1);
    }
  }
  return null; // unbalanced → truncated output
}

/** Double every backslash that does not start a *valid* JSON escape. ("\frac" is valid JSON "\f"+"rac" – handled later.) */
function fixInvalidEscapes(s) {
  return s.replace(/\\(?!["\\/bfnrtu])/g, '\\\\');
}

// LaTeX commands whose first letter collides with a JSON escape. After parsing, "\frac" became "\f" + "rac".
const CTRL_FIXES = [
  ['\f', '\\f', /^(rac|orall|box|lat)/],
  ['\t', '\\t', /^(heta|imes|ext|au|an(?![a-z])|ilde|riangle|o(?![a-z])|herefore|hinspace|op(?![a-z])|iny)/],
  ['\b', '\\b', /^(eta|ar|inom|oldsymbol|egin|ig(?![a-z])|ullet|ot(?![a-z]))/],
  ['\r', '\\r', /^(ight|ho(?![a-z])|ightarrow|angle|m(?![a-z])|ceil|floor|eal)/],
  // Real newlines are rare in our output, so only unambiguous stems are repaired here (\neq, \nabla, \notin, \newline).
  ['\n', '\\n', /^(eq(?![a-z])|abla|otin|ewline)/],
];

function repairControlChars(str) {
  let out = str;
  for (const [ch, repl, stem] of CTRL_FIXES) {
    if (!out.includes(ch)) continue;
    let res = '';
    for (let i = 0; i < out.length; i++) {
      if (out[i] === ch && stem.test(out.slice(i + 1, i + 14))) res += repl;
      else res += out[i];
    }
    out = res;
  }
  return out;
}

function deepMap(v, fn) {
  if (typeof v === 'string') return fn(v);
  if (Array.isArray(v)) return v.map((x) => deepMap(x, fn));
  if (v && typeof v === 'object') {
    const o = {};
    for (const [k, val] of Object.entries(v)) o[k] = deepMap(val, fn);
    return o;
  }
  return v;
}

/**
 * Parse model output into an object. Returns { value, repaired:boolean } or throws Error('unparseable').
 */
export function parseModelJson(text) {
  const cleaned = stripFences(text);
  const candidates = [cleaned];
  const block = firstJsonObject(cleaned);
  if (block && block !== cleaned) candidates.push(block);
  for (const cand of candidates) {
    for (const [fix, label] of [
      [(s) => s, false],
      [fixInvalidEscapes, true],
    ]) {
      try {
        const parsed = JSON.parse(fix(cand));
        if (parsed && typeof parsed === 'object') {
          return { value: deepMap(parsed, repairControlChars), repaired: label };
        }
      } catch {
        /* try next */
      }
    }
  }
  throw new Error('unparseable');
}
