/** Fixed-window in-memory rate limiter keyed by an arbitrary string (client IP). Per-process; use a shared store when scaling out. */
export function createRateLimiter({ windowMs, max }) {
  const hits = new Map(); // key -> { count, resetAt }
  const sweep = setInterval(() => {
    const now = Date.now();
    for (const [k, v] of hits) if (v.resetAt <= now) hits.delete(k);
  }, Math.max(windowMs, 10_000));
  sweep.unref?.();

  return {
    take(key) {
      const now = Date.now();
      let e = hits.get(key);
      if (!e || e.resetAt <= now) {
        e = { count: 0, resetAt: now + windowMs };
        hits.set(key, e);
      }
      e.count++;
      return {
        ok: e.count <= max,
        remaining: Math.max(0, max - e.count),
        retryAfterSec: Math.max(1, Math.ceil((e.resetAt - now) / 1000)),
        limit: max,
      };
    },
    size: () => hits.size,
    stop: () => clearInterval(sweep),
  };
}
