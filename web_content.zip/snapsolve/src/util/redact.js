// Central secret scrubbing used by the logger and by every error message that may reach a client.
const secrets = new Set();

/** Register exact secret values (API keys, tokens) to be masked wherever they appear. */
export function registerSecrets(list) {
  for (const s of list || []) if (typeof s === 'string' && s.length >= 6) secrets.add(s);
}
export function forgetSecret(s) {
  secrets.delete(s);
}

// Shapes of well-known credentials, as a second line of defence for keys we were never told about.
const PATTERNS = [
  /sk-[A-Za-z0-9_\-]{16,}/g, // OpenAI / Anthropic style
  /AIza[0-9A-Za-z_\-]{20,}/g, // Google
  /Bearer\s+[A-Za-z0-9._\-]{12,}/gi,
  /(api[_-]?key|x-api-key|authorization|apikey)["'\s:=]+[A-Za-z0-9._\-]{10,}/gi,
];

export function redact(input) {
  let s = typeof input === 'string' ? input : String(input ?? '');
  for (const secret of secrets) if (s.includes(secret)) s = s.split(secret).join('[REDACTED]');
  for (const re of PATTERNS) s = s.replace(re, '[REDACTED]');
  return s;
}

/** Deep-redact an object for logging (strings only; also drops obvious payload fields). */
const DROP = new Set(['image', 'imageData', 'data', 'base64', 'apiKey', 'authorization', 'password', 'token']);
export function redactDeep(v, depth = 0) {
  if (depth > 5) return '[depth]';
  if (typeof v === 'string') return redact(v.length > 400 ? v.slice(0, 400) + '…' : v);
  if (Array.isArray(v)) return v.slice(0, 20).map((x) => redactDeep(x, depth + 1));
  if (v && typeof v === 'object') {
    const o = {};
    for (const [k, val] of Object.entries(v)) o[k] = DROP.has(k) ? '[omitted]' : redactDeep(val, depth + 1);
    return o;
  }
  return v;
}
