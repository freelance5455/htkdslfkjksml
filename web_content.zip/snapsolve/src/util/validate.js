import crypto from 'node:crypto';
import { AppError } from './errors.js';

export const SUBJECTS = [
  'auto', 'math', 'physics', 'chemistry', 'biology', 'cs', 'engineering', 'language',
  'history', 'geography', 'economics', 'science', 'other',
];
export const UI_LANGS = ['en', 'ar']; // add a code here (+ public/i18n/<code>.json + src/solver/langs.js) to add a language

const MIME_BY_MAGIC = [
  { mime: 'image/jpeg', test: (b) => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  { mime: 'image/png', test: (b) => b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47 },
  {
    mime: 'image/webp',
    test: (b) => b.slice(0, 4).toString('latin1') === 'RIFF' && b.slice(8, 12).toString('latin1') === 'WEBP',
  },
];

/**
 * Validate a data-URL image: allowed type, size cap, and the *actual bytes* match the declared type.
 * Returns { mime, data (base64), bytes, hash }.
 */
export function validateImage(dataUrl, maxBytes) {
  if (typeof dataUrl !== 'string') throw new AppError(400, 'BAD_IMAGE', 'Image must be a data URL string.');
  const m = /^data:(image\/(?:jpeg|png|webp));base64,/.exec(dataUrl.slice(0, 40));
  if (!m) throw new AppError(400, 'BAD_IMAGE', 'Only JPEG, PNG or WebP images are accepted.');
  const b64 = dataUrl.slice(m[0].length);
  // Reject before decoding: base64 length bounds the decoded size.
  if (b64.length > Math.ceil((maxBytes * 4) / 3) + 8) throw new AppError(413, 'IMAGE_TOO_LARGE', 'Image is too large.');
  if (!/^[A-Za-z0-9+/]+={0,2}$/.test(b64) || b64.length % 4 === 1) throw new AppError(400, 'BAD_IMAGE', 'Image data is not valid base64.');
  const buf = Buffer.from(b64, 'base64');
  if (buf.length < 100) throw new AppError(400, 'BAD_IMAGE', 'Image is empty or corrupt.');
  if (buf.length > maxBytes) throw new AppError(413, 'IMAGE_TOO_LARGE', 'Image is too large.');
  const magic = MIME_BY_MAGIC.find((x) => x.test(buf));
  if (!magic || magic.mime !== m[1]) throw new AppError(400, 'BAD_IMAGE', 'Image content does not match its declared type.');
  return { mime: magic.mime, data: b64, bytes: buf.length, hash: crypto.createHash('sha256').update(buf).digest('hex') };
}

export function validateText(v, max, field = 'text', { required = true } = {}) {
  if (v == null || v === '') {
    if (required) throw new AppError(400, 'BAD_INPUT', `"${field}" is required.`);
    return '';
  }
  if (typeof v !== 'string') throw new AppError(400, 'BAD_INPUT', `"${field}" must be a string.`);
  // eslint-disable-next-line no-control-regex
  const s = v.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').trim();
  if (required && !s) throw new AppError(400, 'BAD_INPUT', `"${field}" is empty.`);
  if (s.length > max) throw new AppError(413, 'TEXT_TOO_LONG', `"${field}" is longer than ${max} characters.`);
  return s;
}

export function validateEnum(v, allowed, field, dflt) {
  if (v == null || v === '') return dflt;
  if (!allowed.includes(v)) throw new AppError(400, 'BAD_INPUT', `"${field}" must be one of: ${allowed.join(', ')}.`);
  return v;
}

export function validateLang(v, field = 'language', dflt = 'auto') {
  if (v == null || v === '') return dflt;
  if (v === 'auto' || UI_LANGS.includes(v)) return v;
  throw new AppError(400, 'BAD_INPUT', `"${field}" is not a supported language.`);
}

export function isPlainObject(o) {
  return o !== null && typeof o === 'object' && !Array.isArray(o);
}
