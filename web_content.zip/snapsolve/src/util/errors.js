/** Error that is safe to show to a client (message must never contain secrets or upstream bodies). */
export class AppError extends Error {
  constructor(status, code, message, extra = {}) {
    super(message);
    this.name = 'AppError';
    this.status = status;
    this.code = code;
    this.extra = extra;
  }
}

/**
 * Failure while talking to an AI/OCR provider.
 * code: auth | rate_limited | timeout | network | server | bad_request | blocked | bad_output | quota | aborted
 */
export class ProviderError extends Error {
  constructor({ provider, code, status = 0, retryable = false, message }) {
    super(message);
    this.name = 'ProviderError';
    this.provider = provider;
    this.code = code;
    this.status = status;
    this.retryable = retryable;
  }
}
