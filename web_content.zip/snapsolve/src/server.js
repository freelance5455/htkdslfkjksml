import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { loadConfig, collectSecrets } from './config.js';
import { createLogger } from './logger.js';
import { registerSecrets, redact } from './util/redact.js';
import { AppError } from './util/errors.js';
import { createRateLimiter } from './util/ratelimit.js';
import { SUBJECTS, UI_LANGS, validateImage, validateText, validateEnum, validateLang, isPlainObject } from './util/validate.js';
import { createRegistry } from './providers/registry.js';
import { createSympy } from './solver/sympy.js';
import { createCache } from './solver/cache.js';
import { createSolver } from './solver/service.js';
import { normalizeSolution } from './solver/schema.js';
import { FOLLOWUP_MODES } from './solver/prompts.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PUBLIC_DIR = path.join(ROOT, 'public');
const VERSION = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version;

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf', '.txt': 'text/plain; charset=utf-8',
};
const COMPRESSIBLE = new Set(['.html', '.js', '.mjs', '.css', '.json', '.webmanifest', '.svg']);

const CSP = [
  "default-src 'self'", "script-src 'self'", "style-src 'self'", "style-src-attr 'unsafe-inline'",
  "img-src 'self' data: blob:", "media-src 'self' blob:", "font-src 'self'", "connect-src 'self'",
  "worker-src 'self'", "manifest-src 'self'", "object-src 'none'", "base-uri 'none'", "form-action 'self'", "frame-ancestors 'none'",
].join('; ');

const sha = (s) => crypto.createHash('sha256').update(String(s)).digest();
const safeEqual = (a, b) => crypto.timingSafeEqual(sha(a), sha(b));

export function createApp(cfg = loadConfig(), { logger } = {}) {
  logger ||= createLogger({ level: cfg.logLevel });
  registerSecrets(collectSecrets(cfg));
  fs.mkdirSync(cfg.dataDir, { recursive: true });

  const registry = createRegistry(cfg, { logger });
  const sympy = createSympy(cfg.sympy, logger);
  const cache = createCache({ ttlMs: cfg.limits.cacheTtlMs });
  const solver = createSolver({ cfg, registry, sympy, logger, cache });
  const generalLimiter = createRateLimiter({ windowMs: cfg.limits.rateWindowMs, max: cfg.limits.rateMax });
  const aiLimiter = createRateLimiter({ windowMs: cfg.limits.rateWindowMs, max: cfg.limits.solveRateMax });
  const adminLimiter = createRateLimiter({ windowMs: 60_000, max: 30 });

  const bodyLimit = Math.ceil((cfg.limits.maxImageBytes * 4) / 3) + 96 * 1024;

  /* ───────── helpers ───────── */
  function clientIp(req) {
    if (cfg.trustProxy > 0) {
      const xff = String(req.headers['x-forwarded-for'] || '').split(',').map((s) => s.trim()).filter(Boolean);
      if (xff.length) return xff[Math.max(0, xff.length - cfg.trustProxy)];
    }
    return req.socket.remoteAddress || 'unknown';
  }
  const isHttps = (req) => !!req.socket.encrypted || (cfg.trustProxy > 0 && String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim() === 'https');

  function securityHeaders(req, res) {
    res.setHeader('Content-Security-Policy', CSP);
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
    res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
    res.setHeader('Permissions-Policy', 'camera=(self), microphone=(self), geolocation=(), payment=(), usb=()');
    if (isHttps(req)) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  }

  function sendJson(res, status, obj, extraHeaders = {}) {
    const body = JSON.stringify(obj);
    res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'content-length': Buffer.byteLength(body), ...extraHeaders });
    res.end(body);
  }

  function errorBody(e) {
    if (e instanceof AppError) {
      const out = { error: { code: e.code, message: e.message } };
      if (e.extra?.attempts) out.error.attempts = e.extra.attempts.map((a) => ({ provider: a.provider, code: a.code || (a.ok ? 'ok' : 'error') }));
      if (e.extra?.retryAfterSec) out.error.retryAfterSec = e.extra.retryAfterSec;
      return out;
    }
    return { error: { code: 'INTERNAL', message: 'Something went wrong on the server. Please try again.' } };
  }

  async function readJson(req) {
    const ct = String(req.headers['content-type'] || '');
    if (!ct.toLowerCase().includes('application/json')) throw new AppError(415, 'UNSUPPORTED_MEDIA_TYPE', 'Send JSON with content-type: application/json.');
    const declared = Number(req.headers['content-length']);
    if (Number.isFinite(declared) && declared > bodyLimit) throw new AppError(413, 'PAYLOAD_TOO_LARGE', 'Request is too large.');
    const chunks = [];
    let size = 0;
    for await (const c of req) {
      size += c.length;
      if (size > bodyLimit) throw new AppError(413, 'PAYLOAD_TOO_LARGE', 'Request is too large.');
      chunks.push(c);
    }
    let obj;
    try {
      obj = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    } catch {
      throw new AppError(400, 'BAD_JSON', 'Request body is not valid JSON.');
    }
    if (!isPlainObject(obj)) throw new AppError(400, 'BAD_JSON', 'Request body must be a JSON object.');
    return obj;
  }

  const hasAccess = (req) => !cfg.accessCode || (typeof req.headers['x-access-code'] === 'string' && safeEqual(req.headers['x-access-code'], cfg.accessCode));
  function requireAccess(req) {
    if (!hasAccess(req)) throw new AppError(401, 'ACCESS_CODE_REQUIRED', 'A valid access code is required.');
  }
  function requireAdmin(req) {
    if (!cfg.adminToken) throw new AppError(403, 'ADMIN_DISABLED', 'The admin interface is disabled. Set ADMIN_TOKEN (16+ characters) on the server to enable it.');
    const m = /^Bearer (.+)$/.exec(String(req.headers.authorization || ''));
    if (!m || !safeEqual(m[1], cfg.adminToken)) throw new AppError(401, 'ADMIN_AUTH', 'Invalid admin token.');
  }
  function takeAi(req) {
    const r = aiLimiter.take(clientIp(req));
    if (!r.ok) throw new AppError(429, 'RATE_LIMITED', 'Too many requests. Please wait a moment and try again.', { retryAfterSec: r.retryAfterSec });
  }

  /* ───────── request parsing for each AI endpoint ───────── */
  function parseQuestion(q) {
    if (!isPlainObject(q)) throw new AppError(400, 'BAD_INPUT', '"question" is required.');
    return {
      text: validateText(q.text, cfg.limits.maxTextChars, 'question.text'),
      choices: Array.isArray(q.choices) ? q.choices.slice(0, 10).map((c) => validateText(String(c), 300, 'choice', { required: false })).filter(Boolean) : null,
      hasDiagram: q.hasDiagram === true,
      diagram: q.diagram ? validateText(q.diagram, 1500, 'question.diagram', { required: false }) : null,
    };
  }
  const optImage = (b) => (b.image ? validateImage(b.image, cfg.limits.maxImageBytes) : null);

  /* ───────── API routes ───────── */
  const api = {
    'GET /api/health': async () => ({ status: 200, body: { ok: true, version: VERSION } }),

    'GET /api/config': async ({ req }) => {
      const authorized = hasAccess(req);
      const base = { version: VERSION, accessCodeRequired: !!cfg.accessCode, authorized };
      if (!authorized) return { status: 200, body: base };
      const providers = registry.list();
      const llm = providers.filter((p) => p.kind === 'llm' && ['connected', 'configured'].includes(p.status));
      return {
        status: 200,
        body: {
          ...base,
          providers,
          features: {
            ai: llm.length > 0,
            vision: llm.some((p) => p.capabilities.vision),
            ocrFallback: providers.some((p) => p.kind === 'ocr' && ['connected', 'configured'].includes(p.status)),
            sympy: sympy.info().available,
            crossCheck: llm.length > 1,
          },
          sympy: sympy.info(),
          limits: { maxImageBytes: cfg.limits.maxImageBytes, maxTextChars: cfg.limits.maxTextChars },
          admin: { enabled: !!cfg.adminToken, runtimeKeys: cfg.allowRuntimeKeys },
          subjects: SUBJECTS, languages: UI_LANGS,
        },
      };
    },

    'POST /api/recognize': async ({ req, signal }) => {
      requireAccess(req); takeAi(req);
      const b = await readJson(req);
      if (!!b.image === !!b.text) throw new AppError(400, 'BAD_INPUT', 'Send exactly one of "image" or "text".');
      const out = await solver.recognize(
        {
          image: optImage(b),
          text: b.text ? validateText(b.text, cfg.limits.maxTextChars, 'text') : '',
          subject: validateEnum(b.subject, SUBJECTS, 'subject', 'auto'),
          uiLanguage: validateLang(b.uiLanguage, 'uiLanguage', 'en'),
        },
        { signal },
      );
      return { status: 200, body: out };
    },

    'POST /api/solve': async ({ req, signal }) => {
      requireAccess(req); takeAi(req);
      const b = await readJson(req);
      const out = await solver.solve(
        { question: parseQuestion(b.question), image: optImage(b), subject: validateEnum(b.subject, SUBJECTS, 'subject', 'auto'), language: validateLang(b.language) },
        { signal },
      );
      return { status: 200, body: out };
    },

    'POST /api/verify': async ({ req, signal }) => {
      requireAccess(req);
      const b = await readJson(req);
      const wantsCross = b.crossCheck === true;
      if (wantsCross) takeAi(req);
      else {
        const r = generalLimiter.take('v:' + clientIp(req));
        if (!r.ok) throw new AppError(429, 'RATE_LIMITED', 'Too many requests.', { retryAfterSec: r.retryAfterSec });
      }
      if (!isPlainObject(b.solution)) throw new AppError(400, 'BAD_INPUT', '"solution" is required.');
      let solution;
      try { solution = normalizeSolution(b.solution, 'client'); } catch { throw new AppError(400, 'BAD_INPUT', '"solution" is malformed.'); }
      const solvedBy = typeof b.solvedBy === 'string' && /^[a-z0-9]{2,20}$/.test(b.solvedBy) ? b.solvedBy : null;
      const out = await solver.verify(
        { question: parseQuestion(b.question), solution, image: optImage(b), solvedBy, crossCheck: wantsCross, language: validateLang(b.language) },
        { signal },
      );
      return { status: 200, body: out };
    },

    'POST /api/followup': async ({ req, signal }) => {
      requireAccess(req); takeAi(req);
      const b = await readJson(req);
      const mode = validateEnum(b.mode, FOLLOWUP_MODES.filter((m) => m !== 'translate'), 'mode', null);
      if (!mode) throw new AppError(400, 'BAD_INPUT', '"mode" is required.');
      const ask = mode === 'ask' ? validateText(b.ask, 1000, 'ask') : '';
      let solution;
      try { solution = normalizeSolution(b.solution, 'client'); } catch { throw new AppError(400, 'BAD_INPUT', '"solution" is malformed.'); }
      const out = await solver.followup({ mode, question: parseQuestion(b.question), solution, language: validateLang(b.language), ask }, { signal });
      return { status: 200, body: out };
    },

    'POST /api/translate': async ({ req, signal }) => {
      requireAccess(req); takeAi(req);
      const b = await readJson(req);
      const target = validateEnum(b.target, UI_LANGS, 'target', null);
      if (!target) throw new AppError(400, 'BAD_INPUT', '"target" is required.');
      let solution;
      try { solution = normalizeSolution(b.solution, 'client'); } catch { throw new AppError(400, 'BAD_INPUT', '"solution" is malformed.'); }
      return { status: 200, body: await solver.translate({ solution, target }, { signal }) };
    },

    /* ── admin ── */
    'GET /api/admin/providers': async ({ req }) => {
      requireAdmin(req);
      const warnings = [];
      if (!cfg.accessCode) warnings.push('ACCESS_CODE is not set: anyone who can reach this server can spend your API credit (rate limits still apply).');
      if (cfg.env === 'production' && cfg.trustProxy === 0) warnings.push('TRUST_PROXY is 0: behind a reverse proxy all users share one rate-limit bucket.');
      return { status: 200, body: { providers: registry.list({ admin: true }), usage: registry.globalUsage(), sympy: sympy.info(), warnings, cache: { entries: cache.size() } } };
    },
    'POST /api/admin/providers/:id/test': async ({ req, signal, params }) => {
      requireAdmin(req);
      registry.view(params.id);
      const lastTest = await registry.test(params.id, signal);
      return { status: 200, body: { provider: registry.view(params.id, { admin: true }), result: lastTest } };
    },
    'PATCH /api/admin/providers/:id': async ({ req, params }) => {
      requireAdmin(req);
      const b = await readJson(req);
      registry.view(params.id);
      registry.update(params.id, { enabled: b.enabled, priority: b.priority, model: b.model });
      return { status: 200, body: { provider: registry.view(params.id, { admin: true }) } };
    },
    'PUT /api/admin/providers/:id/key': async ({ req, params }) => {
      requireAdmin(req);
      const b = await readJson(req);
      registry.setRuntimeKey(params.id, b.apiKey);
      return { status: 200, body: { provider: registry.view(params.id, { admin: true }) } }; // the key is never echoed
    },
    'DELETE /api/admin/providers/:id/key': async ({ req, params }) => {
      requireAdmin(req);
      registry.view(params.id);
      registry.clearRuntimeKey(params.id);
      return { status: 200, body: { provider: registry.view(params.id, { admin: true }) } };
    },
  };

  const routeTable = Object.entries(api).map(([k, h]) => {
    const [method, pattern] = k.split(' ');
    const re = new RegExp('^' + pattern.replace(/:([a-z]+)/g, '(?<$1>[a-z0-9]+)') + '$');
    return { method, re, h };
  });

  async function handleApi(req, res, url) {
    const ip = clientIp(req);
    const t0 = Date.now();
    const ctl = new AbortController();
    res.on('close', () => { if (!res.writableEnded) ctl.abort(); });
    let status = 500;
    let route = url.pathname;
    try {
      const g = generalLimiter.take(ip);
      if (!g.ok) throw new AppError(429, 'RATE_LIMITED', 'Too many requests. Please slow down.', { retryAfterSec: g.retryAfterSec });
      if (url.pathname.startsWith('/api/admin/')) {
        const a = adminLimiter.take(ip);
        if (!a.ok) throw new AppError(429, 'RATE_LIMITED', 'Too many admin requests.', { retryAfterSec: a.retryAfterSec });
      }
      let matched = null;
      let pathMatch = false;
      for (const r of routeTable) {
        const m = r.re.exec(url.pathname);
        if (!m) continue;
        pathMatch = true;
        if (r.method === req.method) { matched = { r, params: m.groups || {} }; break; }
      }
      if (!matched) throw pathMatch ? new AppError(405, 'METHOD_NOT_ALLOWED', 'Method not allowed.') : new AppError(404, 'NOT_FOUND', 'Unknown API route.');
      route = `${req.method} ${url.pathname.replace(/^(\/api\/admin\/providers\/)[a-z0-9]+/, '$1:id')}`;
      const out = await matched.r.h({ req, res, signal: ctl.signal, params: matched.params });
      status = out.status;
      sendJson(res, out.status, out.body);
    } catch (e) {
      status = e instanceof AppError ? e.status : 500;
      if (!(e instanceof AppError)) logger.error('unhandled error', { route, error: redact(e?.message || String(e)) });
      if (res.writableEnded || res.destroyed) return;
      const headers = e.extra?.retryAfterSec ? { 'retry-after': String(e.extra.retryAfterSec) } : {};
      sendJson(res, status === 499 ? 499 : status, errorBody(e), headers);
    } finally {
      // metadata only: never bodies, images, question text or credentials
      logger.info('request', { method: req.method, route, status, ms: Date.now() - t0 });
    }
  }

  /* ───────── static files ───────── */
  const gzipCache = new Map();
  function resolveStatic(pathname) {
    let rel = decodeURIComponent(pathname);
    if (rel.includes('\0')) return null;
    const base = PUBLIC_DIR;
    if (rel === '/' || rel === '') rel = '/index.html';
    const full = path.resolve(base, '.' + path.posix.normalize(rel));
    if (full !== base && !full.startsWith(base + path.sep)) return null;
    return full;
  }

  function serveStatic(req, res, url) {
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405, { allow: 'GET, HEAD' }); return res.end(); }
    let file;
    try { file = resolveStatic(url.pathname); } catch { file = null; }
    let st;
    try { st = file && fs.statSync(file); } catch { st = null; }
    if (!st || !st.isFile()) { res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' }); return res.end('Not found'); }
    const ext = path.extname(file).toLowerCase();
    const etag = `W/"${st.size.toString(16)}-${Math.floor(st.mtimeMs).toString(16)}"`;
    const isSw = path.basename(file) === 'sw.js';
    const headers = {
      'content-type': MIME[ext] || 'application/octet-stream',
      etag,
      'cache-control': isSw || ext === '.html' ? 'no-cache' : ext === '.woff2' || file.includes(`${path.sep}vendor${path.sep}`) ? 'public, max-age=604800' : 'no-cache',
      vary: 'Accept-Encoding',
    };
    if (req.headers['if-none-match'] === etag) { res.writeHead(304, headers); return res.end(); }
    const wantsGzip = COMPRESSIBLE.has(ext) && /\bgzip\b/.test(String(req.headers['accept-encoding'] || '')) && st.size > 1024;
    if (wantsGzip) {
      const ck = file + etag;
      let gz = gzipCache.get(ck);
      if (!gz) { gz = zlib.gzipSync(fs.readFileSync(file), { level: 9 }); if (gzipCache.size > 200) gzipCache.clear(); gzipCache.set(ck, gz); }
      res.writeHead(200, { ...headers, 'content-encoding': 'gzip', 'content-length': gz.length });
      return res.end(req.method === 'HEAD' ? undefined : gz);
    }
    res.writeHead(200, { ...headers, 'content-length': st.size });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  }

  /* ───────── main handler ───────── */
  function handler(req, res) {
    securityHeaders(req, res);
    let url;
    try { url = new URL(req.url, 'http://localhost'); } catch { res.writeHead(400); return res.end(); }
    if (cfg.requireHttps && !isHttps(req) && url.pathname !== '/api/health') {
      res.writeHead(308, { location: `https://${req.headers.host}${req.url}` });
      return res.end();
    }
    const origin = req.headers.origin;
    if (origin && cfg.corsOrigins.includes(origin)) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Vary', 'Origin');
      res.setHeader('Access-Control-Allow-Headers', 'content-type, x-access-code, authorization');
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, PUT, DELETE, OPTIONS');
    }
    if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
    if (url.pathname.startsWith('/api/')) return void handleApi(req, res, url);
    return serveStatic(req, res, url);
  }

  const server = http.createServer(handler);
  server.requestTimeout = 120_000;
  server.headersTimeout = 20_000;
  server.keepAliveTimeout = 15_000;

  return {
    server, registry, sympy, solver, cache, logger,
    async start() {
      await sympy.probe();
      await new Promise((resolve) => server.listen(cfg.port, cfg.host, resolve));
      const addr = server.address();
      if (cfg.env === 'production' && !cfg.accessCode) logger.warn('ACCESS_CODE is not set: the API is open to anyone who can reach this server');
      if (cfg.adminTokenTooShort) logger.warn('ADMIN_TOKEN is shorter than 16 characters and was ignored; admin interface disabled');
      const usable = registry.list().filter((p) => p.status !== 'unconfigured');
      logger.info('listening', { port: addr.port, providers: usable.map((p) => `${p.id}:${p.status}`) });
      if (!usable.length) logger.warn('no AI provider configured – only local arithmetic works until you set an API key (see .env.example)');
      return addr.port;
    },
    close: () => new Promise((resolve) => { server.close(() => resolve()); server.closeAllConnections?.(); generalLimiter.stop(); aiLimiter.stop(); adminLimiter.stop(); }),
  };
}
