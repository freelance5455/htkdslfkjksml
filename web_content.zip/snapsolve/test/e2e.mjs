// End-to-end browser test. Needs Playwright + Chromium (not an app dependency): node test/e2e.mjs
// Boots the real server, points the "custom OpenAI-compatible" provider at a local mock model, and drives the UI
// with a fake camera. Screenshots are written to $SHOTS (default ./e2e-shots).
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';
import assert from 'node:assert/strict';
import { loadConfig } from '../src/config.js';
import { createApp } from '../src/server.js';
import { createLogger } from '../src/logger.js';
import { pngDataUrl } from './helpers.js';

const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const SHOTS = process.env.SHOTS || path.resolve('e2e-shots');
fs.mkdirSync(SHOTS, { recursive: true });

/* ── mock model: answers by stage, deterministic ── */
const calls = [];
const quad = {
  subject: 'math', topic: 'Quadratic equations', difficulty: 'medium', language: 'en', question: 'Solve $x^2-5x+6=0$',
  known: ['$x^2-5x+6=0$'], asks: 'Find all real $x$', method: { name: 'Factorisation', formulas: ['ax^2+bx+c=0'] },
  steps: [{ title: 'Factor', explanation: 'Find two numbers with product $6$ and sum $-5$.', latex: '(x-2)(x-3)=0' }, { title: 'Solve each factor', explanation: 'Set each factor to zero.', latex: 'x=2,\\ x=3' }],
  unitConversions: [], assumptions: [], missingInfo: [], selfCheck: { description: 'Substituting both roots gives 0.', dimensionalConsistency: null },
  finalAnswer: { text: 'x = 2 or x = 3', latex: 'x=2\\ \\text{or}\\ x=3', value: null, unit: null }, why: 'Both values make each factor zero.', confidence: 0.96,
  plot: { expression: 'x^2-5x+6', variable: 'x', xMin: -1, xMax: 6 }, computeCheck: null,
  symbolicCheck: { type: 'solve', equation: 'x**2-5*x+6=0', variable: 'x', solutions: ['2', '3'] }, multipleChoice: null,
};
const mock = http.createServer((req, res) => {
  let b = '';
  req.on('data', (c) => (b += c));
  req.on('end', () => {
    const body = JSON.parse(b || '{}');
    const sys = body.messages?.[0]?.content || '';
    const user = JSON.stringify(body.messages?.[1]?.content || '');
    calls.push({ stage: sys.slice(0, 40), hasImage: user.includes('image_url') });
    let out;
    if (sys.includes('question-recognition stage')) {
      out = user.includes('MULTI')
        ? { readable: true, language: 'en', subject: 'math', questions: [{ text: 'Solve $x^2-5x+6=0$', confidence: 0.95 }, { text: 'Find $2^{5}$ + 3', confidence: 0.55 }], ambiguities: ['Question 2 is partly cut off'] }
        : { readable: true, language: 'en', subject: 'math', questions: [{ text: 'Solve $x^2-5x+6=0$', confidence: 0.96, hasDiagram: false }], ambiguities: [] };
    } else if (sys.includes('solving stage')) {
      out = user.includes('Find $2^{5}$') ? { ...quad, question: 'Find $2^5+3$', topic: 'Powers', finalAnswer: { text: '35', value: 35 }, computeCheck: { expression: '2^5+3', expected: 35 }, symbolicCheck: null, plot: null, steps: [{ title: 'Compute', explanation: '$2^5=32$, plus 3.', latex: '32+3=35' }] } : quad;
    } else if (sys.includes('follow-up stage')) {
      out = { title: 'More detail', blocks: [{ heading: 'Why factoring works', text: 'If $ab=0$ then $a=0$ or $b=0$.', latex: null }], finalAnswer: null };
    } else if (sys.startsWith('Translate')) {
      out = { ...quad, topic: 'المعادلات التربيعية', asks: 'أوجد جميع قيم $x$', why: 'كل قيمة تجعل أحد العاملين صفراً.' };
    } else out = { ok: true };
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ choices: [{ message: { content: JSON.stringify(out) }, finish_reason: 'stop' }], usage: { prompt_tokens: 5, completion_tokens: 5 } }));
  });
});
await new Promise((r) => mock.listen(0, '127.0.0.1', r));
const mockPort = mock.address().port;

const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ss-e2e-'));
const cfg = loadConfig({ PORT: '0', HOST: '127.0.0.1', DATA_DIR: dataDir, LOG_LEVEL: 'warn', ADMIN_TOKEN: 'admin-token-0123456789abcdef', SYMPY_ENABLED: process.env.SYMPY_ENABLED || 'true',
  COMPAT_NAME: 'Mock model', COMPAT_API_KEY: 'mock-key-123456', COMPAT_BASE_URL: `http://127.0.0.1:${mockPort}/v1`, COMPAT_MODEL: 'mock-1', COMPAT_VISION: 'true', PROVIDER_ORDER: 'compat', SOLVE_RATE_MAX: '200', RATE_MAX: '1000' });
const app = createApp(cfg, { logger: createLogger({ level: 'warn' }) });
const port = await app.start();
const base = `http://127.0.0.1:${port}`;

const browser = await chromium.launch({ args: ['--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream'] });
const results = [];
const step = async (name, fn) => { try { await fn(); results.push(['ok', name]); console.log('ok  -', name); } catch (e) { results.push(['FAIL', name, e.message]); console.log('FAIL-', name, '\n     ', e.message.split('\n')[0]); } };
const shot = (page, n) => page.screenshot({ path: path.join(SHOTS, n + '.png') });

const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, permissions: ['camera'], locale: 'en-US' });
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
page.on('console', (m) => { if (m.type() === 'error' && !/favicon|Failed to load resource/.test(m.text())) errors.push('console: ' + m.text()); });
const failedReq = [];
page.on('response', (r) => { if (r.status() >= 400 && !r.url().includes('/api/')) failedReq.push(`${r.status()} ${r.url()}`); });

await step('home loads, camera starts, scan button visible', async () => {
  await page.goto(base);
  await page.waitForFunction(() => window.__snapsolve?.ready);
  await page.waitForFunction(() => { const v = document.getElementById('video'); return v.videoWidth > 0 && !v.paused; }, null, { timeout: 15000 });
  assert.ok(await page.locator('#btn-shutter').isVisible());
  assert.ok(await page.locator('.scan-label').isVisible());
  assert.ok(await page.locator('#btn-upload').isVisible());
  assert.ok(await page.locator('#btn-type').isVisible());
  assert.ok(await page.locator('#subject').isVisible());
  assert.equal(await page.locator('#cam-msg').isHidden(), true);
  await shot(page, '01-home-camera');
});

await step('capture → automatic analysis → full solution with maths typeset and honest verification', async () => {
  await page.click('#btn-shutter');
  await page.waitForSelector('#view-result.active', { timeout: 30000 });
  assert.match(await page.locator('.final .answer').innerText(), /2/);
  assert.ok((await page.locator('#result-body .katex').count()) > 3, 'KaTeX should render');
  assert.ok(await page.locator('.verify-badge.checked').isVisible(), 'SymPy check should have passed');
  const v = await page.locator('.verify-badge').innerText();
  assert.match(v, /automatic check/i);
  assert.ok(await page.locator('canvas.plot').isVisible());
  assert.ok((await page.locator('details.step').count()) >= 2);
  assert.match(await page.locator('#result-body').innerText(), /Quadratic equations/);
  await shot(page, '02-result');
  await page.locator('#result-scroll').evaluate((e) => e.scrollTo(0, 700)); await shot(page, '03-result-steps');
});

await step('mock model received the image on recognition and never got a credential from the browser', async () => {
  assert.ok(calls.some((c) => c.stage.includes('recognition') && c.hasImage));
  const html = await page.content();
  assert.ok(!html.includes('mock-key-123456'));
  const store = await page.evaluate(() => JSON.stringify({ ...localStorage }) + JSON.stringify({ ...sessionStorage }));
  assert.ok(!store.includes('mock-key') && !store.includes('data:image'));
});

await step('follow-up, translate, expand-all, save and history', async () => {
  await page.click('text=Explain more');
  await page.waitForSelector('.follow-card h3:has-text("More detail")', { timeout: 15000 });
  await page.click('#result-actions >> text=Translate');
  await page.waitForSelector('text=المعادلات التربيعية', { timeout: 15000 });
  assert.match(await page.locator('.final .answer').innerText(), /2/); // maths untouched
  await page.click('#result-actions >> text=Show original');
  await page.click('#btn-expand'); // steps start open when there are ≤3, so the first click collapses them…
  assert.equal(await page.locator('details.step[open]').count(), 0, 'collapse-all');
  await page.click('#btn-expand'); // …and the second expands them again
  assert.equal(await page.locator('details.step:not([open])').count(), 0, 'expand-all');
  await page.click('#result-actions >> text=Save');
  await page.click('#view-result .back');
  assert.ok(await page.locator('#recent-list .recent-item').first().isVisible());
  await page.click('#btn-history');
  assert.equal(await page.locator('#hist-list .hist-item').count(), 1, 'history count');
  await page.fill('#hist-search', 'zzzz'); assert.equal(await page.locator('#hist-list .hist-item').count(), 0, 'filter none');
  await page.fill('#hist-search', 'x^2'); assert.equal(await page.locator('#hist-list .hist-item').count(), 1, 'filter x^2');
  await shot(page, '04-history');
  await page.click('#view-history .back');
});

await step('typed arithmetic is solved locally without any AI call (and graphs work)', async () => {
  const before = calls.length;
  await page.click('#btn-type'); await page.fill('#type-text', '(3+5)*2 ='); await page.click('#type-form button[type=submit]');
  await page.waitForSelector('#view-result.active');
  assert.match(await page.locator('.final .answer').innerText(), /16/);
  assert.match(await page.locator('.verify-badge').innerText(), /built-in calculator/i);
  assert.equal(calls.length, before);
  await page.click('#view-result .back');
  await page.click('#btn-type'); await page.fill('#type-text', 'y = x^2 - 4'); await page.click('#type-form button[type=submit]');
  await page.waitForSelector('#view-result.active canvas.plot');
  await page.click('#view-result .back');
});

await step('typed word problem goes through the AI and shows steps', async () => {
  await page.click('#btn-type'); await page.fill('#type-text', 'Solve x^2-5x+6=0'); await page.click('#type-form button[type=submit]');
  await page.waitForSelector('#view-result.active', { timeout: 20000 });
  assert.ok(await page.locator('.verify-badge.checked').isVisible());
  await page.click('#view-result .back');
});

await step('gallery upload with several questions → review screen → edit → solve one', async () => {
  const png = path.join(dataDir, 'multi.png');
  fs.writeFileSync(png, Buffer.from(pngDataUrl(600, 400).split(',')[1], 'base64'));
  // make the mock return two questions for this image by sending MULTI through the subject hint is not possible; patch via route
  await page.route('**/api/recognize', async (route) => {
    const r = await route.fetch();
    const j = await r.json();
    j.questions = [{ id: 1, text: 'Solve $x^2-5x+6=0$', choices: null, hasDiagram: false, diagram: null, confidence: 0.95 }, { id: 2, text: 'Find $2^{5}$ + 3', choices: null, hasDiagram: false, diagram: null, confidence: 0.55 }];
    j.needsReview = true; j.ambiguities = ['Question 2 is partly cut off'];
    await route.fulfill({ response: r, json: j });
  });
  await page.setInputFiles('#file', png);
  await page.waitForSelector('#view-review.active', { timeout: 20000 });
  assert.equal(await page.locator('#review-list .q-card').count(), 2);
  assert.match(await page.locator('#review-banner').innerText(), /2 questions/);
  await shot(page, '05-review');
  await page.locator('#review-list .q-card').nth(1).locator('textarea').fill('Find $2^{5}$ + 3');
  await page.locator('#review-list .q-card').nth(1).locator('button').click();
  await page.waitForSelector('#view-result.active', { timeout: 20000 });
  assert.match(await page.locator('.final .answer').innerText(), /35/);
  assert.equal(await page.locator('#result-body [role=tab]').count(), 2);
  assert.ok(await page.locator('.verify-badge.checked').isVisible(), 'recompute check should pass');
  await page.unroute('**/api/recognize');
  await page.click('#view-result .back'); // → review
  await page.click('#view-review .back');
});

await step('unreadable photo → asks to retake, never invents a question', async () => {
  await page.goto(base); await page.waitForFunction(() => window.__snapsolve?.ready);
  await page.route('**/api/recognize', (route) => route.fulfill({ json: { readable: false, reason: 'The photo is too blurry.', questions: [], ambiguities: [], language: 'en', subject: 'other', source: 'vision', needsReview: false } }));
  const png = path.join(dataDir, 'blur.png'); fs.writeFileSync(png, Buffer.from(pngDataUrl(300, 300).split(',')[1], 'base64'));
  await page.setInputFiles('#file', png);
  await page.waitForSelector('#view-review.active');
  assert.match(await page.locator('#review-banner').innerText(), /couldn't read a question/i);
  assert.equal(await page.locator('#review-list .q-card').count(), 0);
  assert.ok(await page.locator('#btn-review-retake').isVisible());
  await shot(page, '06-unreadable');
  await page.unroute('**/api/recognize');
  await page.click('#btn-review-retake');
});

await step('provider failure shows a clear error with retry (no fake success)', async () => {
  await page.route('**/api/solve', (route) => route.fulfill({ status: 503, json: { error: { code: 'NO_PROVIDER', message: 'x' } } }));
  await page.click('#btn-type'); await page.fill('#type-text', 'What is photosynthesis?'); await page.click('#type-form button[type=submit]');
  await page.waitForSelector('#proc-title:has-text("didn\'t work")');
  assert.match(await page.locator('#proc-note').innerText(), /No AI service is set up/);
  assert.equal(await page.locator('#view-processing li.done').count(), 0);
  await shot(page, '07-error');
  await page.unroute('**/api/solve');
  await page.click('#btn-cancel');
});

await step('settings: language switch to Arabic gives RTL, integrations show real status, admin manager works', async () => {
  await page.click('#btn-settings');
  await page.selectOption('#set-ui', 'ar');
  await page.waitForFunction(() => document.documentElement.dir === 'rtl' && document.documentElement.lang === 'ar');
  assert.match(await page.locator('#set-title').innerText(), /الإعدادات/);
  await shot(page, '08-settings-ar');
  const prov = await page.locator('#integ-public .prov').allInnerTexts();
  assert.ok(prov.some((p) => /Mock model/.test(p) && /متصل/.test(p) && !/غير/.test(p)), 'a provider that has served real requests is connected: ' + prov.join('|'));
  assert.ok(prov.some((p) => /OpenAI/.test(p) && /غير مُعدّ/.test(p)));
  await page.click('#admin-box summary'); await page.fill('#admin-token', 'admin-token-0123456789abcdef'); await page.click('#admin-form button');
  await page.waitForSelector('#admin-out .prov');
  await page.locator('#admin-out .prov[data-provider=compat] >> text=اختبار الاتصال').click();
  await page.waitForSelector('#admin-out .prov[data-provider=compat] .chip.ok', { timeout: 15000 });
  assert.ok(!(await page.content()).includes('mock-key-123456'));
  await shot(page, '09-integrations');
  await page.selectOption('#set-ui', 'en');
  await page.waitForFunction(() => document.documentElement.dir === 'ltr');
});

await step('Arabic UI: question in Arabic digits typed, solved locally, RTL layout intact', async () => {
  await page.selectOption('#set-ui', 'ar'); await page.click('#view-settings .back');
  await page.click('#btn-type'); await page.fill('#type-text', 'احسب ٣ × ٤'); await page.click('#type-form button[type=submit]');
  await page.waitForSelector('#view-result.active');
  assert.match(await page.locator('.final .answer').innerText(), /12/);
  await shot(page, '10-result-ar');
  await page.click('#view-result .back');
  await page.click('#btn-settings'); await page.selectOption('#set-ui', 'en'); await page.click('#view-settings .back');
});

await step('image pipeline: detects blur and darkness, deskews a tilted page, trims surroundings, stays under the size cap', async () => {
  const r = await page.evaluate(async () => {
    const ip = await import('/js/imageproc.js');
    const page = (angle = 0, blur = 0, bright = 1) => {
      const c = document.createElement('canvas'); c.width = 900; c.height = 700;
      const g = c.getContext('2d'); g.fillStyle = '#6b5b45'; g.fillRect(0, 0, 900, 700); // desk
      g.save(); g.translate(450, 350); g.rotate((angle * Math.PI) / 180);
      g.fillStyle = '#fff'; g.fillRect(-300, -220, 600, 440); g.fillStyle = '#111'; g.font = 'bold 26px sans-serif';
      for (let i = 0; i < 9; i++) g.fillText(`${i + 1}. Solve 3x + ${i} = 2x - ${i * 2} and find x ${'+ y'.repeat(i % 3)}`, -270, -170 + i * 44);
      g.restore();
      if (!blur && bright === 1) return c;
      const o = document.createElement('canvas'); o.width = c.width; o.height = c.height; const og = o.getContext('2d');
      og.filter = blur ? `blur(${blur}px) brightness(${bright})` : `brightness(${bright})`; og.drawImage(c, 0, 0); return o;
    };
    const sharp = ip.assessQuality(page()), blurry = ip.assessQuality(page(0, 9)), dark = ip.assessQuality(page(0, 0, 0.08));
    const tilted = page(6);
    const skew = ip.estimateSkew(tilted);
    const straightSkew = ip.estimateSkew(page());
    const after = ip.estimateSkew(ip.rotate(tilted, skew));
    const cropped = ip.autoCrop(page());
    const prep = await ip.prepare(page(3), 150000);
    return { sharp, blurry, dark, skew, after, straightSkew, cropped: cropped.cropped, cw: cropped.canvas.width, ch: cropped.canvas.height, bytes: Math.round((prep.dataUrl.length * 3) / 4), steps: prep.steps };
  });
  assert.equal(r.sharp.level, 'ok', JSON.stringify(r.sharp));
  assert.equal(r.blurry.level, 'blurry', JSON.stringify(r.blurry));
  assert.equal(r.dark.level, 'dark', JSON.stringify(r.dark));
  assert.ok(r.blurry.blur < r.sharp.blur / 3);
  assert.ok(Math.abs(r.skew + 6) <= 1.5, 'correction ' + r.skew + ' should undo a +6° tilt');
  assert.ok(r.after === 0, 'page is straight after correction, residual ' + r.after);
  assert.equal(r.straightSkew, 0);
  assert.ok(r.cropped && r.cw < 900 && r.ch < 700, 'desk margins trimmed');
  assert.ok(r.bytes <= 150000, 'size cap respected: ' + r.bytes);
});

await step('delete all data wipes local storage', async () => {
  await page.click('#btn-settings'); await page.click('#btn-delete-all'); await page.click('#dlg-confirm button[value=yes]');
  await page.waitForTimeout(300);
  assert.equal(await page.evaluate(() => localStorage.getItem('ss.history')), null);
  await page.click('#view-settings .back');
});

await step('desktop layout', async () => {
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.goto(base); await page.waitForFunction(() => window.__snapsolve?.ready); await page.waitForTimeout(800);
  await shot(page, '11-desktop');
  await page.setViewportSize({ width: 390, height: 844 });
});
await ctx.close();

await step('camera permission denied → clear message with upload / type alternatives', async () => {
  const c2 = await browser.newContext({ viewport: { width: 390, height: 844 }, permissions: [] });
  const p2 = await c2.newPage();
  await p2.addInitScript(() => { navigator.mediaDevices.getUserMedia = () => Promise.reject(Object.assign(new Error('denied'), { name: 'NotAllowedError' })); });
  await p2.goto(base); await p2.waitForSelector('#cam-msg:not([hidden])');
  assert.match(await p2.locator('#cam-msg-title').innerText(), /blocked/i);
  for (const id of ['#btn-upload2', '#btn-type2', '#btn-scan-native']) assert.ok(await p2.locator(id).isVisible());
  await shot(p2, '12-camera-denied');
  await c2.close();
});
await step('camera unavailable (no device) → upload / type fallback', async () => {
  const c3 = await browser.newContext({ viewport: { width: 390, height: 844 } });
  const p3 = await c3.newPage();
  await p3.addInitScript(() => { navigator.mediaDevices.getUserMedia = () => Promise.reject(Object.assign(new Error('none'), { name: 'NotFoundError' })); });
  await p3.goto(base); await p3.waitForSelector('#cam-msg:not([hidden])');
  assert.match(await p3.locator('#cam-msg-title').innerText(), /No camera/i);
  await c3.close();
});

await step('offline: banner shows, local calculator still works, AI says offline', async () => {
  const c4 = await browser.newContext({ viewport: { width: 390, height: 844 }, permissions: ['camera'] });
  const p4 = await c4.newPage();
  await p4.goto(base); await p4.waitForFunction(() => window.__snapsolve?.ready);
  await c4.setOffline(true);
  await p4.evaluate(() => window.dispatchEvent(new Event('offline')));
  assert.ok(await p4.locator('#offline').isVisible());
  await p4.click('#btn-type'); await p4.fill('#type-text', '2^10 - 24'); await p4.click('#type-form button[type=submit]');
  await p4.waitForSelector('#view-result.active'); assert.match(await p4.locator('.final .answer').innerText(), /1000/);
  await p4.click('#view-result .back');
  await p4.click('#btn-type'); await p4.fill('#type-text', 'Explain gravity'); await p4.click('#type-form button[type=submit]');
  await p4.waitForSelector('#proc-note:not(:empty)'); assert.match(await p4.locator('#proc-note').innerText(), /offline/i);
  await c4.close();
});

await step('no JS errors or failed static requests during the whole run', async () => {
  assert.deepEqual(errors, []);
  assert.deepEqual(failedReq, []);
});

await browser.close(); await app.close(); mock.close(); fs.rmSync(dataDir, { recursive: true, force: true });
const failed = results.filter((r) => r[0] === 'FAIL');
console.log(`\n${results.length - failed.length}/${results.length} e2e steps passed. Screenshots: ${SHOTS}`);
process.exit(failed.length ? 1 : 0);
