import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluate, tryDirect, extractNumbers, numbersMatch, formatNumber, MathError } from '../public/js/mathEval.js';
import { parseModelJson } from '../src/util/json.js';
import { validateImage, validateText } from '../src/util/validate.js';
import { redact, registerSecrets } from '../src/util/redact.js';
import { createRateLimiter } from '../src/util/ratelimit.js';
import { createCache } from '../src/solver/cache.js';
import { detectLanguage } from '../src/solver/langs.js';
import { localChecks, compareAnswers, summarize } from '../src/solver/verify.js';
import { normalizeSolution } from '../src/solver/schema.js';
import { classify } from '../src/solver/service.js';
import { pngDataUrl, sampleSolution } from './helpers.js';

test('mathEval: precedence, powers, unary minus, implicit multiplication', () => {
  assert.equal(evaluate('2+3*4'), 14);
  assert.equal(evaluate('(2+3)*4'), 20);
  assert.equal(evaluate('2^3^2'), 512);
  assert.equal(evaluate('-2^2'), -4);
  assert.equal(evaluate('2^-1'), 0.5);
  assert.equal(evaluate('2(3+4)'), 14);
  assert.equal(evaluate('3pi'), 3 * Math.PI);
  assert.equal(evaluate('x^2+1', { x: 3 }), 10);
  assert.equal(evaluate('5!'), 120);
  assert.equal(evaluate('50%'), 0.5);
  assert.equal(evaluate('sqrt(16)+√9'), 7);
  assert.ok(Math.abs(evaluate('sin(pi/6)') - 0.5) < 1e-12);
  assert.equal(evaluate('1.5e3'), 1500);
});

test('mathEval: Arabic digits and unicode operators', () => {
  assert.equal(evaluate('٣ × ٤'), 12);
  assert.equal(evaluate('١٠ ÷ ٤'), 2.5);
  assert.equal(evaluate('٣٫٥ + ١'), 4.5);
  assert.equal(evaluate('5²'), 25);
  assert.equal(evaluate('10 − 3'), 7);
});

test('mathEval: errors are reported, never guessed', () => {
  assert.throws(() => evaluate('1/0'), MathError);
  assert.throws(() => evaluate('2+'), MathError);
  assert.throws(() => evaluate('foo(3)'), MathError);
  assert.throws(() => evaluate('y+1'), MathError);
  assert.throws(() => evaluate('(((('.repeat(40) + '1' + '))))'.repeat(40)), MathError);
  assert.throws(() => evaluate('9^9^9^9'), MathError);
  assert.throws(() => evaluate('1 2'), MathError);
  assert.throws(() => evaluate('process.exit()'), MathError);
  assert.throws(() => evaluate('a'.repeat(600)), MathError);
  assert.throws(() => evaluate('constructor'), MathError);
  assert.throws(() => evaluate('__proto__'), MathError);
});

test('tryDirect only accepts whole-input expressions', () => {
  assert.equal(tryDirect('(3+5)*2 =').value, 16);
  assert.equal(tryDirect('Calculate 12/4').value, 3);
  assert.equal(tryDirect('احسب ٣ × ٤').value, 12);
  assert.equal(tryDirect('$2^{3}$'), null); // braces are not plain arithmetic → left to the AI
  assert.equal(tryDirect('42'), null); // a bare number is not a question
  assert.equal(tryDirect('Solve x^2-5x+6=0'), null);
  assert.equal(tryDirect('What is the capital of France?'), null);
  assert.equal(tryDirect('2x+3'), null); // unknown variable
});

test('extractNumbers handles latex fractions, thousands separators, scientific notation and arabic digits', () => {
  assert.ok(extractNumbers('x = \\frac{3}{4}').some((n) => numbersMatch(n, 0.75)));
  assert.ok(extractNumbers('1,234.5 m').includes(1234.5));
  assert.ok(extractNumbers('3 × 10^8 m/s').includes(3e8));
  assert.ok(extractNumbers('الناتج ١٢').includes(12));
  assert.ok(extractNumbers('-7.5').includes(-7.5));
  assert.equal(formatNumber(0.1 + 0.2), '0.3');
});

test('parseModelJson: fences, chatter, single-backslash LaTeX, truncation', () => {
  assert.deepEqual(parseModelJson('```json\n{"a":1}\n```').value, { a: 1 });
  assert.deepEqual(parseModelJson('Sure! Here you go:\n{"a":"b"} hope it helps').value, { a: 'b' });
  // model forgot to double the backslash: JSON.parse turns \f into a form feed – we must put the command back
  assert.equal(parseModelJson('{"latex":"\\frac{1}{2}"}').value.latex, '\\frac{1}{2}');
  assert.equal(parseModelJson('{"latex":"\\theta + \\beta + \\times + \\rightarrow + \\neq"}').value.latex, '\\theta + \\beta + \\times + \\rightarrow + \\neq');
  // invalid escape (\s, \p) → repaired by doubling
  assert.equal(parseModelJson('{"latex":"\\sqrt{2}\\pi"}').value.latex, '\\sqrt{2}\\pi');
  // correctly escaped input is untouched
  assert.equal(parseModelJson('{"latex":"\\\\frac{1}{2}"}').value.latex, '\\frac{1}{2}');
  // legitimate newline in prose is not mangled
  assert.equal(parseModelJson('{"t":"line1\\nline2"}').value.t, 'line1\nline2');
  assert.throws(() => parseModelJson('{"a": [1, 2'), /unparseable/);
  assert.throws(() => parseModelJson('no json here'), /unparseable/);
});

test('validateImage: type, magic bytes, size', () => {
  const ok = validateImage(pngDataUrl(), 100000);
  assert.equal(ok.mime, 'image/png');
  assert.equal(ok.hash.length, 64);
  assert.throws(() => validateImage('data:image/gif;base64,R0lGODlh', 1e6), /JPEG, PNG or WebP/);
  assert.throws(() => validateImage('data:text/html;base64,PHNjcmlwdD4=', 1e6), /JPEG, PNG or WebP/);
  assert.throws(() => validateImage('hello', 1e6));
  assert.throws(() => validateImage(pngDataUrl().replace('image/png', 'image/jpeg'), 1e6), /does not match/);
  assert.throws(() => validateImage('data:image/png;base64,' + Buffer.alloc(500, 1).toString('base64'), 1e6), /does not match/);
  assert.throws(() => validateImage(pngDataUrl(300, 300), 500), /too large/);
  assert.throws(() => validateImage('data:image/png;base64,@@@@', 1e6), /base64/);
});

test('validateText strips control chars and enforces limits', () => {
  assert.equal(validateText(' hi\u0000there ', 50), 'hithere');
  assert.throws(() => validateText('x'.repeat(11), 10), /longer than/);
  assert.throws(() => validateText('   ', 10), /empty/);
  assert.throws(() => validateText(42, 10), /string/);
});

test('redact masks registered secrets and key-shaped strings', () => {
  registerSecrets(['super-secret-value-123']);
  assert.ok(!redact('failed with super-secret-value-123 in header').includes('super-secret'));
  assert.ok(!redact('key sk-abcdefghijklmnopqrstuvwxyz').includes('abcdefghij'));
  assert.ok(!redact('AIzaSyAbcdefghijklmnopqrstuvwxyz0123').includes('Abcdefghij'));
  assert.ok(!redact('Authorization: Bearer abcdef1234567890xyz').includes('abcdef1234567890'));
});

test('rate limiter windows and cache de-duplication', async () => {
  const rl = createRateLimiter({ windowMs: 60000, max: 2 });
  assert.equal(rl.take('a').ok, true);
  assert.equal(rl.take('a').ok, true);
  assert.equal(rl.take('a').ok, false);
  assert.equal(rl.take('b').ok, true);
  rl.stop();

  const cache = createCache({ ttlMs: 1000 });
  let n = 0;
  const slow = async () => { n++; await new Promise((r) => setTimeout(r, 20)); return n; };
  const [x, y] = await Promise.all([cache.wrap('k', slow), cache.wrap('k', slow)]);
  assert.equal(n, 1);
  assert.equal(x.value, y.value);
  assert.equal((await cache.wrap('k', slow)).cached, true);
});

test('language detection and classification heuristics', () => {
  assert.equal(detectLanguage('احسب مساحة الدائرة'), 'ar');
  assert.equal(detectLanguage('Find the area'), 'en');
  assert.equal(detectLanguage('احسب x + 2 = 5 where x'), 'ar');
  assert.equal(classify('2+2').difficulty, 'easy');
  assert.equal(classify('Evaluate the integral of x^2').difficulty, 'hard');
});

test('verification: arithmetic recomputation catches a wrong answer', () => {
  const good = normalizeSolution(sampleSolution({ finalAnswer: { text: '16', value: 16 }, computeCheck: { expression: '(3+5)*2', expected: 16 } }));
  const bad = normalizeSolution(sampleSolution({ finalAnswer: { text: '18', value: 18 }, computeCheck: { expression: '(3+5)*2', expected: 18 } }));
  const q = { text: '(3+5)*2' };
  const g = localChecks(q, good);
  assert.ok(g.every((c) => c.status === 'passed'));
  assert.equal(g.find((c) => c.kind === 'local-arithmetic').independent, true);
  const b = localChecks(q, bad);
  assert.ok(b.some((c) => c.status === 'failed'));
  assert.equal(summarize(b, false).status, 'conflict');
  assert.equal(summarize(g, false).status, 'checked');
  // nothing checkable ⇒ must NOT claim verification
  const none = localChecks({ text: 'Explain photosynthesis' }, normalizeSolution(sampleSolution({ computeCheck: null, symbolicCheck: null, finalAnswer: { text: 'Plants make sugar from light.' } })));
  assert.equal(none.length, 0);
  assert.equal(summarize(none, false).status, 'unverified');
});

test('compareAnswers: numbers, multiple choice, text', () => {
  const s = (text, value = null, mc = null) => normalizeSolution(sampleSolution({ finalAnswer: { text, value }, multipleChoice: mc }));
  assert.equal(compareAnswers(s('x = 4', 4), s('The answer is 4.0', 4)), 'passed');
  assert.equal(compareAnswers(s('x = 4', 4), s('x = 5', 5)), 'failed');
  assert.equal(compareAnswers(s('B', null, { selected: 'B', reason: '' }), s('b', null, { selected: 'B)', reason: '' })), 'passed');
  assert.equal(compareAnswers(s('B', null, { selected: 'B', reason: '' }), s('C', null, { selected: 'C', reason: '' })), 'failed');
  assert.equal(compareAnswers(s('Paris'), s('paris.')), 'passed');
  assert.equal(compareAnswers(s('Paris'), s('The French capital')), 'inconclusive');
});
