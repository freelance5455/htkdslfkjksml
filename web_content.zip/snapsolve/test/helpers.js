import os from 'node:os';
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import { loadConfig } from '../src/config.js';
import { createApp } from '../src/server.js';
import { createLogger } from '../src/logger.js';

export const KEYS = {
  anthropic: 'sk-ant-TESTKEY-aaaaaaaaaaaaaaaaaaaa',
  openai: 'sk-TESTKEY-bbbbbbbbbbbbbbbbbbbbbbbb',
  gemini: 'AIzaTESTKEY-cccccccccccccccccccccc',
};

/** Minimal valid PNG (solid colour) so image validation sees real magic bytes. */
export function pngDataUrl(w = 24, h = 24) {
  const crcTable = Array.from({ length: 256 }, (_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c >>> 0; });
  const crc = (buf) => { let c = 0xffffffff; for (const b of buf) c = crcTable[(c ^ b) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
  const chunk = (type, data) => { const len = Buffer.alloc(4); len.writeUInt32BE(data.length); const td = Buffer.concat([Buffer.from(type), data]); const c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([len, td, c]); };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  const raw = Buffer.alloc((w * 3 + 1) * h);
  let seed = 12345; // deterministic noise so the PNG is not trivially tiny
  for (let i = 0; i < raw.length; i++) { seed = (Math.imul(seed, 1103515245) + 12345) & 0x7fffffff; raw[i] = (seed >> 16) & 0xff; }
  for (let y = 0; y < h; y++) raw[y * (w * 3 + 1)] = 0;
  const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
  return 'data:image/png;base64,' + png.toString('base64');
}

export const sampleSolution = (over = {}) => ({
  subject: 'math', topic: 'Linear equations', difficulty: 'easy', language: 'en', question: 'Solve 2x+3=11',
  known: ['2x+3=11'], asks: 'Find x', method: { name: 'Isolate x', formulas: ['ax+b=c \\Rightarrow x=\\frac{c-b}{a}'] },
  steps: [{ title: 'Subtract 3', explanation: 'Subtract 3 from both sides: $2x=8$.', latex: '2x=8' }, { title: 'Divide by 2', explanation: 'So $x=4$.', latex: 'x=4' }],
  unitConversions: [], assumptions: [], missingInfo: [], selfCheck: { description: 'Substituting x=4 gives 11.', dimensionalConsistency: null },
  finalAnswer: { text: 'x = 4', latex: 'x=4', value: 4, unit: null }, why: 'Both sides balance.', confidence: 0.95,
  plot: null, computeCheck: { expression: '(11-3)/2', expected: 4 }, symbolicCheck: { type: 'solve', equation: '2*x+3=11', variable: 'x', solutions: ['4'] }, multipleChoice: null,
  ...over,
});

export const sampleRecognition = (over = {}) => ({
  readable: true, reason: null, language: 'en', subject: 'math',
  questions: [{ text: 'Solve $2x+3=11$', choices: null, hasDiagram: false, diagram: null, confidence: 0.95 }], ambiguities: [], ...over,
});

const wrap = {
  anthropic: (text) => ({ content: [{ type: 'text', text }], usage: { input_tokens: 10, output_tokens: 20 }, stop_reason: 'end_turn' }),
  openai: (text) => ({ choices: [{ message: { content: text }, finish_reason: 'stop' }], usage: { prompt_tokens: 10, completion_tokens: 20 } }),
  gemini: (text) => ({ candidates: [{ content: { parts: [{ text }] }, finishReason: 'STOP' }], usageMetadata: { promptTokenCount: 10, candidatesTokenCount: 20 } }),
};
export const respond = (provider, obj) => ({ status: 200, json: wrap[provider](typeof obj === 'string' ? obj : JSON.stringify(obj)) });

const HOSTS = { 'api.anthropic.com': 'anthropic', 'api.openai.com': 'openai', 'generativelanguage.googleapis.com': 'gemini', 'compat.test': 'compat', 'api.ocr.space': 'ocrspace' };

/**
 * Boots the real server on an ephemeral port. Calls to AI provider hosts are routed to `handlers[providerId](req)`;
 * everything else (our own server) goes through the real fetch.
 * handler(req) => { status, json?, text?, hang?: true }  — req = { url, headers, body (parsed), signal, n }
 */
export async function startTestApp({ env = {}, handlers = {}, withKeys = [] } = {}) {
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'snapsolve-test-'));
  const keyEnv = {};
  for (const id of withKeys) keyEnv[`${id.toUpperCase()}_API_KEY`] = KEYS[id];
  const cfg = loadConfig({ PORT: '0', HOST: '127.0.0.1', DATA_DIR: dataDir, PROVIDER_MAX_RETRIES: '0', SYMPY_ENABLED: 'false', LOG_LEVEL: 'debug', ...keyEnv, ...env });
  const logs = [];
  const logger = createLogger({ level: 'debug', sink: (l) => logs.push(l) });
  const app = createApp(cfg, { logger });
  const port = await app.start();
  const base = `http://127.0.0.1:${port}`;

  const realFetch = globalThis.fetch;
  const calls = [];
  globalThis.fetch = async (url, init = {}) => {
    const u = new URL(String(url));
    const id = HOSTS[u.host];
    if (!id) return realFetch(url, init);
    let body = init.body;
    try { body = typeof body === 'string' ? JSON.parse(body) : body; } catch { /* leave */ }
    const rec = { provider: id, url: String(url), headers: Object.fromEntries(Object.entries(init.headers || {}).map(([k, v]) => [k.toLowerCase(), v])), body, signal: init.signal, n: calls.filter((c) => c.provider === id).length + 1 };
    calls.push(rec);
    const h = handlers[id];
    if (!h) return new Response(JSON.stringify({ error: { message: 'no handler' } }), { status: 500 });
    const out = await h(rec);
    if (out.hang) {
      return new Promise((_, reject) => init.signal?.addEventListener('abort', () => reject(Object.assign(new Error('aborted'), { name: 'AbortError' })), { once: true }));
    }
    return new Response(out.text ?? JSON.stringify(out.json ?? {}), { status: out.status ?? 200, headers: { 'content-type': 'application/json', ...(out.headers || {}) } });
  };

  const post = (route, body, headers = {}) => realFetch(base + route, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: typeof body === 'string' ? body : JSON.stringify(body) });
  const json = async (res) => { const text = await res.text(); try { return { status: res.status, body: JSON.parse(text), text } } catch { return { status: res.status, body: null, text } } };

  return {
    app, base, cfg, logs, calls, post, json, realFetch,
    get: (route, headers = {}) => realFetch(base + route, { headers }),
    async close() { globalThis.fetch = realFetch; await app.close(); fs.rmSync(dataDir, { recursive: true, force: true }); },
  };
}
