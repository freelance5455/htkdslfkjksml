"""Sanitising parser for expressions that originate from an AI model (and therefore, indirectly, from an untrusted photo).

SymPy's parse_expr() ends up calling eval(), so we never hand it raw text. Instead:
  1. Only a small character set is accepted (no quotes, brackets, backticks, semicolons, '@', '#', ':' ...).
  2. Attribute access ('.name') and dunder names are rejected.
  3. Every identifier is resolved from a fixed whitelist of functions/constants, otherwise it becomes a plain Symbol.
  4. eval() runs with empty builtins.

This module deliberately does NOT import sympy at import time so it can be unit-tested without it.
"""
import re

MAX_LEN = 300
ALLOWED_CHARS = re.compile(r"^[0-9A-Za-z_+\-*/^().,=<>\s]*$")
ATTRIBUTE = re.compile(r"\.\s*[A-Za-z_]")
IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")

FUNC_NAMES = {
    "sin", "cos", "tan", "cot", "sec", "csc", "asin", "acos", "atan", "sinh", "cosh", "tanh",
    "exp", "log", "ln", "sqrt", "cbrt", "Abs", "abs", "floor", "ceiling", "factorial",
    "binomial", "gcd", "lcm", "Max", "Min", "sign",
}
CONST_NAMES = {"pi", "E", "oo", "I", "e"}


class UnsafeExpression(ValueError):
    pass


def check(text: str) -> str:
    if not isinstance(text, str):
        raise UnsafeExpression("not a string")
    if len(text) > MAX_LEN:
        raise UnsafeExpression("expression too long")
    if not ALLOWED_CHARS.match(text):
        raise UnsafeExpression("disallowed character")
    if ATTRIBUTE.search(text) or "__" in text:
        raise UnsafeExpression("attribute access is not allowed")
    for name in IDENT.findall(text):
        if len(name) > 24:
            raise UnsafeExpression("identifier too long")
    return text.replace("^", "**")


def identifiers(text: str):
    return set(IDENT.findall(text))
