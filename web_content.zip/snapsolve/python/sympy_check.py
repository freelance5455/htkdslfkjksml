#!/usr/bin/env python3
"""SymPy verification bridge.  stdin: one JSON request.  stdout: one JSON result.

Request:  {"type": "equal|solve|diff|integrate|limit", ...fields...}
Result:   {"ok": true, "status": "passed|failed|inconclusive", "detail": "..."}  or {"ok": false, "error": "..."}

This script only CHECKS a claimed result by recomputing it; it never trusts the claim.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from safe_expr import CONST_NAMES, FUNC_NAMES, UnsafeExpression, check, identifiers  # noqa: E402

try:
    import sympy as sp
    from sympy.parsing.sympy_parser import (
        convert_xor,
        implicit_multiplication,
        parse_expr,
        standard_transformations,
    )
except Exception as exc:  # pragma: no cover
    print(json.dumps({"ok": False, "error": "sympy-not-installed", "detail": str(exc)[:100]}))
    sys.exit(0)

# Names the parser's own transformations emit (Integer, Float, Rational, Symbol ...). User identifiers never reach this
# namespace: parse() maps every identifier through local_dict first. Builtins stay disabled.
GLOBALS = {}
exec("from sympy import *", GLOBALS)
GLOBALS["__builtins__"] = {}

TRANSFORMS = standard_transformations + (implicit_multiplication, convert_xor)

FUNCS = {
    "sin": sp.sin, "cos": sp.cos, "tan": sp.tan, "cot": sp.cot, "sec": sp.sec, "csc": sp.csc,
    "asin": sp.asin, "acos": sp.acos, "atan": sp.atan, "sinh": sp.sinh, "cosh": sp.cosh, "tanh": sp.tanh,
    "exp": sp.exp, "log": sp.log, "ln": sp.log, "sqrt": sp.sqrt, "cbrt": sp.cbrt, "Abs": sp.Abs, "abs": sp.Abs,
    "floor": sp.floor, "ceiling": sp.ceiling, "factorial": sp.factorial, "binomial": sp.binomial,
    "gcd": sp.gcd, "lcm": sp.lcm, "Max": sp.Max, "Min": sp.Min, "sign": sp.sign,
}
CONSTS = {"pi": sp.pi, "E": sp.E, "e": sp.E, "oo": sp.oo, "I": sp.I}


def parse(text):
    text = check(text)
    local = {}
    for name in identifiers(text):
        if name in FUNC_NAMES:
            local[name] = FUNCS[name]
        elif name in CONST_NAMES:
            local[name] = CONSTS[name]
        else:
            local[name] = sp.Symbol(name)
    return parse_expr(text, local_dict=local, global_dict=GLOBALS, transformations=TRANSFORMS, evaluate=True)


def symbol(name):
    check(name)
    return sp.Symbol(name)


def zero(expr):
    """True when expr is identically zero (symbolically, with a numeric sample fallback)."""
    expr = sp.simplify(expr)
    if expr == 0:
        return True
    free = sorted(expr.free_symbols, key=str)
    if len(free) > 3:
        return False
    import random

    random.seed(7)
    for _ in range(6):
        sub = {s: sp.Rational(random.randint(2, 40), random.randint(3, 17)) for s in free}
        try:
            v = complex(sp.N(expr.subs(sub), 20))
        except Exception:
            continue
        if abs(v) > 1e-9:
            return False
    return True


def run(req):
    t = req.get("type")
    if t == "equal":
        a, b = parse(req["a"]), parse(req["b"])
        ok = zero(a - b)
        return {"status": "passed" if ok else "failed", "detail": "expressions are equal" if ok else f"expressions differ (difference simplifies to {sp.simplify(a - b)})"}

    var = symbol(req.get("variable") or "x")

    if t == "solve":
        eq = req["equation"]
        if eq.count("=") != 1:
            return {"status": "inconclusive", "detail": "equation must contain exactly one '='"}
        lhs, rhs = eq.split("=")
        f = parse(lhs) - parse(rhs)
        claimed = [parse(s) for s in req.get("solutions", [])]
        if not claimed:
            return {"status": "inconclusive", "detail": "no claimed solutions to check"}
        bad = [str(c) for c in claimed if not zero(f.subs(var, c))]
        actual = sp.solve(f, var)
        missing = []
        for r in actual:
            if not any(zero(r - c) for c in claimed):
                missing.append(str(r))
        if bad:
            return {"status": "failed", "detail": f"substituting {', '.join(bad)} does not satisfy the equation; SymPy solves it as {actual}"}
        if missing:
            return {"status": "failed", "detail": f"each claimed solution works, but solutions {missing} are missing"}
        return {"status": "passed", "detail": f"all claimed solutions satisfy the equation and none are missing (SymPy: {actual})"}

    expr = parse(req["expression"])
    claimed = parse(req["result"]) if req.get("result") not in (None, "") else None
    if claimed is None:
        return {"status": "inconclusive", "detail": "no claimed result"}

    if t == "diff":
        d = sp.diff(expr, var)
        ok = zero(d - claimed)
        return {"status": "passed" if ok else "failed", "detail": "derivative recomputed and matches" if ok else f"SymPy's derivative is {d}"}
    if t == "integrate":
        ok = zero(sp.diff(claimed, var) - expr)  # an antiderivative must differentiate back to the integrand
        return {"status": "passed" if ok else "failed", "detail": "claimed antiderivative differentiates back to the integrand" if ok else f"derivative of claimed result is {sp.simplify(sp.diff(claimed, var))}, not the integrand"}
    if t == "limit":
        point = parse(req.get("point") or "0")
        lim = sp.limit(expr, var, point)
        ok = zero(lim - claimed) if lim.is_finite else (lim == claimed)
        return {"status": "passed" if ok else "failed", "detail": "limit recomputed and matches" if ok else f"SymPy's limit is {lim}"}
    return {"status": "inconclusive", "detail": "unsupported check type"}


def main():
    try:
        req = json.loads(sys.stdin.read(20000))
        out = run(req)
        out["ok"] = True
        print(json.dumps(out))
    except UnsafeExpression as exc:
        print(json.dumps({"ok": True, "status": "inconclusive", "detail": f"expression rejected by safety filter: {exc}"}))
    except Exception as exc:
        print(json.dumps({"ok": True, "status": "inconclusive", "detail": f"could not evaluate: {type(exc).__name__}"}))


if __name__ == "__main__":
    main()
