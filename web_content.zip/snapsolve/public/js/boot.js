// Runs synchronously before first paint (no inline scripts are allowed by our CSP): applies theme, language and
// direction from saved settings so there is no flash of the wrong theme/direction.
(function () {
  var s = {};
  try { s = JSON.parse(localStorage.getItem('ss.settings') || '{}') || {}; } catch (e) { /* storage unavailable */ }
  var ui = s.ui || ((navigator.language || 'en').slice(0, 2) === 'ar' ? 'ar' : 'en');
  var root = document.documentElement;
  root.lang = ui;
  root.dir = ui === 'ar' ? 'rtl' : 'ltr';
  var theme = s.theme || 'system';
  if (theme === 'dark' || theme === 'light') root.setAttribute('data-theme', theme);
})();
