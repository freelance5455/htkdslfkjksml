// Integrations manager UI (public status list + token-protected admin controls). Lazy-loaded from Settings.
import { api } from './api.js';
import { t, fmtDate } from './i18n.js';
import { el } from './render.js';

const STATUS_CLASS = { connected: 'ok', configured: 'warn', disabled: '', unconfigured: '', error: 'bad' };
const statusChip = (s) => el('span', { class: `chip ${STATUS_CLASS[s] || ''}`, text: t(`integ.status.${s}`) });
const capText = (c) => Object.entries(c || {}).filter(([, v]) => v).map(([k]) => t(`integ.cap.${k}`)).join(' · ');

export function renderPublic(box, providers) {
  box.textContent = '';
  for (const p of providers || []) {
    box.append(el('div', { class: 'prov' },
      el('header', {}, el('strong', { text: p.name }), statusChip(p.status)),
      el('div', { class: 'small muted', text: [capText(p.capabilities), p.model].filter(Boolean).join(' · ') })));
  }
}

export function setupAdmin({ form, tokenInput, out, onChange, toast }) {
  let token = '';
  try { token = sessionStorage.getItem('ss.admin') || ''; } catch { /* ignore */ }
  const store = (v) => { token = v; try { v ? sessionStorage.setItem('ss.admin', v) : sessionStorage.removeItem('ss.admin'); } catch { /* ignore */ } };

  async function load() {
    out.textContent = '';
    out.append(el('p', { class: 'muted', text: '…' }));
    try {
      const data = await api.admin.list(token);
      draw(data);
    } catch (e) {
      out.textContent = '';
      if (e.status === 401 || e.status === 403) store('');
      out.append(el('p', { class: 'err', text: e.status === 403 ? t('integ.adminDisabled') : e.status === 401 ? t('integ.badToken') : t('err.network') }));
    }
  }

  function draw(data) {
    out.textContent = '';
    for (const w of data.warnings || []) out.append(el('div', { class: 'banner warn', text: w }));
    out.append(el('p', { class: 'small muted', text: t('integ.usageToday', { n: data.usage.count, max: data.usage.limit }) + ' · SymPy: ' + (data.sympy.available ? data.sympy.version : (data.sympy.reason || t('integ.status.unconfigured'))) }));
    for (const p of data.providers) out.append(card(p));
    out.append(el('button', { class: 'btn ghost', type: 'button', onclick: () => { store(''); tokenInput.value = ''; out.textContent = ''; } , text: t('integ.lock') }));
  }

  async function act(fn, ok) {
    try { await fn(); if (ok) toast(ok); await load(); onChange?.(); } catch (e) { toast(e.message || t('err.generic')); }
  }

  function card(p) {
    const enabled = el('input', { type: 'checkbox', ...(p.enabled ? { checked: true } : {}) });
    enabled.checked = p.enabled;
    enabled.addEventListener('change', () => act(() => api.admin.patch(p.id, { enabled: enabled.checked }, token)));
    const prio = el('input', { type: 'number', min: 0, max: 1000, value: p.priority });
    const model = el('input', { type: 'text', value: p.model || '', maxlength: 100, placeholder: p.model || '' });
    const key = el('input', { type: 'password', autocomplete: 'off', placeholder: t('integ.keyPh') });
    const hasModel = p.kind === 'llm';
    const test = p.lastTest;
    return el('div', { class: 'prov', dataset: { provider: p.id } },
      el('header', {}, el('strong', { text: p.name }), statusChip(p.status)),
      el('div', { class: 'small muted', text: capText(p.capabilities) }),
      el('div', { class: 'small', text: `${t('integ.keySource')}: ${t('integ.src.' + p.keySource)} · ${p.env.join(', ')}` }),
      p.docs ? el('div', { class: 'small' }, el('a', { href: p.docs, target: '_blank', rel: 'noopener noreferrer', text: t('integ.getKey') })) : null,
      test ? el('div', { class: 'small ' + (test.ok ? '' : 'err'), text: `${t('integ.lastTest')}: ${test.ok ? t('integ.ok') : (test.error?.message || t('integ.failed'))} \u2066(${test.ms} ms, ${fmtDate(test.at)})\u2069` }) : null,
      p.lastError && !(test && test.ok) ? el('div', { class: 'small err', text: `${t('integ.lastError')}: ${p.lastError.message}` }) : null,
      el('div', { class: 'small muted', text: `${t('integ.usage')}: ${p.usage.requests} · ${t('integ.errors')}: ${p.usage.errors} · ${t('integ.avg')}: \u2066${p.usage.avgMs ?? '–'} ms\u2069 · ${t('integ.today')}: \u2066${p.usage.today}/${p.usage.dailyLimit}\u2069 · tokens \u2066${p.usage.inputTokens}/${p.usage.outputTokens}\u2069` }),
      el('div', { class: 'grid' },
        el('label', {}, t('integ.priority'), prio),
        hasModel ? el('label', {}, t('integ.model'), model) : el('span')),
      el('div', { class: 'row wrap', style: 'margin-top:8px' },
        el('label', { class: 'check row', style: 'flex-direction:row;align-items:center;gap:8px' }, enabled, el('span', { text: t('integ.enabled') })),
        el('span', { class: 'grow' }),
        el('button', { class: 'btn', type: 'button', text: t('integ.save'), onclick: () => act(() => api.admin.patch(p.id, { priority: Number(prio.value), ...(hasModel && model.value !== (p.model || '') ? { model: model.value.trim() } : {}) }, token), t('integ.saved')) }),
        el('button', { class: 'btn primary', type: 'button', text: t('integ.test'), onclick: async (ev) => { ev.target.disabled = true; await act(() => api.admin.test(p.id, token)); } })),
      data_runtime(p, key));
  }

  let runtimeKeys = false;
  function data_runtime(p, key) {
    if (!runtimeKeys) return null;
    return el('div', { class: 'grid one', style: 'margin-top:8px' },
      el('label', {}, t('integ.runtimeKey'), key),
      el('div', { class: 'row' },
        el('button', { class: 'btn', type: 'button', text: t('integ.saveKey'), onclick: () => key.value && act(() => api.admin.setKey(p.id, key.value.trim(), token).then(() => { key.value = ''; }), t('integ.saved')) }),
        p.keySource === 'runtime' ? el('button', { class: 'btn ghost', type: 'button', text: t('integ.removeKey'), onclick: () => act(() => api.admin.clearKey(p.id, token)) }) : null));
  }

  form.addEventListener('submit', (e) => { e.preventDefault(); store(tokenInput.value.trim()); tokenInput.value = ''; if (token) load(); });
  return { setRuntimeKeys: (v) => { runtimeKeys = !!v; }, resume: () => { if (token) load(); } };
}
