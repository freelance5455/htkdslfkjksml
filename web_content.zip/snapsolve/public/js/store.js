// Everything stored on this device lives here: settings and (only when the user chooses to save) solutions.
// Photos are NEVER stored. Storage can be unavailable (private mode / blocked), so every access is guarded.
const SK = 'ss.settings';
const HK = 'ss.history';
const MAX_ITEMS = 200;
const DEFAULTS = { ui: null, explain: 'auto', theme: 'system', autoSave: false, subject: 'auto', accessCode: '' };

let memSettings = null;
let memHistory = [];

function read(key, fallback) {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch { return fallback; }
}
function write(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch { return false; }
}

export function getSettings() {
  if (!memSettings) memSettings = { ...DEFAULTS, ...read(SK, {}) };
  return memSettings;
}
export function saveSettings(patch) {
  memSettings = { ...getSettings(), ...patch };
  write(SK, memSettings);
  return memSettings;
}

export function listHistory() {
  if (!memHistory.length) memHistory = read(HK, []);
  return memHistory;
}
export function saveItem(item) {
  const list = listHistory();
  const i = list.findIndex((x) => x.id === item.id);
  const rec = { ...item, ts: item.ts || Date.now() };
  if (i >= 0) list[i] = rec; else list.unshift(rec);
  while (list.length > MAX_ITEMS) list.pop();
  const ok = write(HK, list);
  return ok;
}
export const isSaved = (id) => listHistory().some((x) => x.id === id);
export function deleteItem(id) {
  memHistory = listHistory().filter((x) => x.id !== id);
  write(HK, memHistory);
}
export function clearHistory() { memHistory = []; try { localStorage.removeItem(HK); } catch { /* ignore */ } }
export function clearAll() {
  clearHistory();
  memSettings = null;
  try { localStorage.removeItem(SK); sessionStorage.clear(); } catch { /* ignore */ }
}
export const newId = () => (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random().toString(16).slice(2));
