// Small, safe, dependency-free arithmetic engine shared by the browser (offline calculator, plotting)
// and the server (independent recomputation of answers). It is a hand-written parser: no eval(), no Function().

export class MathError extends Error {}

const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';
const SUPERSCRIPTS = { '⁰': '0', '¹': '1', '²': '2', '³': '3', '⁴': '4', '⁵': '5', '⁶': '6', '⁷': '7', '⁸': '8', '⁹': '9' };

/** Normalise unicode digits/operators so "٣ × ٤²" and "3*4^2" are the same input. */
export function normalizeExpr(s) {
  return String(s)
    .replace(/[٠-٩]/g, (d) => String(AR_DIGITS.indexOf(d)))
    .replace(/٫/g, '.')
    .replace(/٬/g, '')
    .replace(/[⁰¹²³⁴⁵⁶⁷⁸⁹]+/g, (m) => '^' + [...m].map((c) => SUPERSCRIPTS[c]).join(''))
    .replace(/[×⋅·∙]/g, '*')
    .replace(/[÷∕]/g, '/')
    .replace(/[−–—]/g, '-')
    .replace(/\*\*/g, '^')
    .replace(/π/g, 'pi')
    .replace(/ /g, ' ')
    .trim();
}

const FUNCS = {
  sqrt: Math.sqrt, cbrt: Math.cbrt, abs: Math.abs, exp: Math.exp,
  sin: Math.sin, cos: Math.cos, tan: Math.tan, asin: Math.asin, acos: Math.acos, atan: Math.atan,
  sinh: Math.sinh, cosh: Math.cosh, tanh: Math.tanh,
  ln: Math.log, log: Math.log10, log10: Math.log10, log2: Math.log2,
  floor: Math.floor, ceil: Math.ceil, round: Math.round, sign: Math.sign,
  // degree-based trig helpers
  sind: (x) => Math.sin((x * Math.PI) / 180), cosd: (x) => Math.cos((x * Math.PI) / 180), tand: (x) => Math.tan((x * Math.PI) / 180),
  fact: (n) => factorial(n),
};
const CONSTS = { pi: Math.PI, e: Math.E, tau: 2 * Math.PI };
export const FUNCTION_NAMES = Object.keys(FUNCS);

function factorial(n) {
  if (!Number.isInteger(n) || n < 0 || n > 170) throw new MathError('factorial needs an integer between 0 and 170');
  let r = 1;
  for (let i = 2; i <= n; i++) r *= i;
  return r;
}

function tokenize(src) {
  const t = [];
  let i = 0;
  while (i < src.length) {
    const c = src[i];
    if (c === ' ' || c === '\t') { i++; continue; }
    if ((c >= '0' && c <= '9') || (c === '.' && src[i + 1] >= '0' && src[i + 1] <= '9')) {
      let j = i;
      while (j < src.length && ((src[j] >= '0' && src[j] <= '9') || src[j] === '.')) j++;
      // scientific notation: 1.2e-5 (only when followed by digits, so "2e" stays 2*e)
      const sci = /^[eE][+-]?\d+/.exec(src.slice(j));
      if (sci) j += sci[0].length;
      const text = src.slice(i, j);
      if ((text.match(/\./g) || []).length > 1) throw new MathError('malformed number');
      t.push({ type: 'num', value: Number(text) });
      i = j;
    } else if (/[A-Za-z_]/.test(c)) {
      let j = i;
      while (j < src.length && /[A-Za-z0-9_]/.test(src[j])) j++;
      t.push({ type: 'id', value: src.slice(i, j).toLowerCase() });
      i = j;
    } else if ('+-*/^(),!%√'.includes(c)) {
      t.push({ type: 'op', value: c });
      i++;
    } else throw new MathError(`unexpected character "${c}"`);
  }
  return t;
}

/** Evaluate an arithmetic expression. vars: e.g. { x: 2 }. Returns a finite number or throws MathError. */
export function evaluate(expr, vars = {}) {
  const src = normalizeExpr(expr);
  if (!src) throw new MathError('empty expression');
  if (src.length > 500) throw new MathError('expression too long');
  const toks = tokenize(src);
  let p = 0;
  let depth = 0;
  const peek = () => toks[p];
  const isOp = (v) => peek()?.type === 'op' && peek().value === v;
  const enter = () => { if (++depth > 60) throw new MathError('expression nested too deeply'); };
  const leave = () => { depth--; };

  function parseExpr() {
    enter();
    let v = parseTerm();
    while (isOp('+') || isOp('-')) {
      const op = toks[p++].value;
      const r = parseTerm();
      v = op === '+' ? v + r : v - r;
    }
    leave();
    return v;
  }
  function startsPrimary() {
    const k = peek();
    if (!k) return false;
    return k.type === 'id' || (k.type === 'op' && (k.value === '(' || k.value === '√'));
  }
  function parseTerm() {
    let v = parseUnary();
    for (;;) {
      if (isOp('*')) { p++; v *= parseUnary(); }
      else if (isOp('/')) {
        p++;
        const d = parseUnary();
        if (d === 0) throw new MathError('division by zero');
        v /= d;
      } else if (startsPrimary()) v *= parseUnary(); // implicit multiplication: 2x, 3(4+1), 2pi
      else break;
    }
    return v;
  }
  function parseUnary() {
    if (isOp('-')) { p++; return -parseUnary(); }
    if (isOp('+')) { p++; return parseUnary(); }
    return parsePower();
  }
  function parsePower() {
    const base = parsePostfix();
    if (isOp('^')) {
      p++;
      enter();
      const ex = parseUnary(); // right-associative, allows 2^-3
      leave();
      return Math.pow(base, ex);
    }
    return base;
  }
  function parsePostfix() {
    let v = parsePrimary();
    for (;;) {
      if (isOp('!')) { p++; v = factorial(v); }
      else if (isOp('%')) { p++; v /= 100; }
      else break;
    }
    return v;
  }
  function parsePrimary() {
    const k = toks[p];
    if (!k) throw new MathError('unexpected end of expression');
    if (k.type === 'num') { p++; return k.value; }
    if (k.type === 'op' && k.value === '(') {
      p++;
      const v = parseExpr();
      if (!isOp(')')) throw new MathError('missing )');
      p++;
      return v;
    }
    if (k.type === 'op' && k.value === '√') {
      p++;
      return Math.sqrt(parsePrimary());
    }
    if (k.type === 'id') {
      p++;
      if (FUNCS[k.value] && isOp('(')) {
        p++;
        const arg = parseExpr();
        if (!isOp(')')) throw new MathError('missing )');
        p++;
        return FUNCS[k.value](arg);
      }
      if (Object.hasOwn(vars, k.value)) return Number(vars[k.value]);
      if (Object.hasOwn(CONSTS, k.value)) return CONSTS[k.value];
      throw new MathError(`unknown name "${k.value}"`);
    }
    throw new MathError(`unexpected "${k.value}"`);
  }

  const result = parseExpr();
  if (p < toks.length) throw new MathError(`unexpected "${toks[p].value}"`);
  if (!Number.isFinite(result)) throw new MathError('result is not a finite number');
  return result;
}

const LEAD_WORDS = /^(?:calculate|compute|evaluate|find|what\s+is|what's|solve|simplify|احسب|أوجد|اوجد|جد|ما\s+(?:هو\s+)?ناتج|ناتج|كم\s+يساوي)\s*[:：]?\s*/i;

/**
 * If the whole input is a plain numeric expression ("(3+5)*2 =", "احسب ٣ × ٤"), evaluate it locally.
 * Returns { expression, value } or null (never guesses, never partially parses prose).
 */
export function tryDirect(text) {
  if (typeof text !== 'string') return null;
  let s = normalizeExpr(text.replace(/\$/g, ''));
  s = s.replace(LEAD_WORDS, '').replace(/[=?؟\s]+$/g, '').replace(/^\s*[=]/, '').trim();
  if (!s || s.length > 200) return null;
  if (!/^[0-9a-z_+\-*/^().,!%√\s]+$/i.test(s)) return null;
  if (!/[+\-*/^!%√]|[a-z]\s*\(/i.test(s) || /^-?\d+(\.\d+)?$/.test(s)) return null; // needs an operator or a function
  try {
    const value = evaluate(s);
    return { expression: s, value };
  } catch {
    return null;
  }
}

export function formatNumber(v) {
  if (!Number.isFinite(v)) return String(v);
  if (Number.isInteger(v) && Math.abs(v) < 1e15) return String(v);
  const a = Math.abs(v);
  if (a !== 0 && (a >= 1e15 || a < 1e-6)) return Number(v.toPrecision(10)).toExponential().replace('e+', 'e');
  return String(Number(v.toPrecision(12)));
}

/** Pull candidate numeric values out of free text / LaTeX ("x = \frac{3}{4} m/s", "1,234.5", "3 × 10^8"). */
export function extractNumbers(text) {
  if (typeof text !== 'string') return [];
  let s = normalizeExpr(text)
    .replace(/\\(?:left|right|,|;|!|quad|qquad|text|mathrm|ldots|dots)\b\s*/g, ' ')
    .replace(/\\frac\s*\{([^{}]+)\}\s*\{([^{}]+)\}/g, '($1)/($2)')
    .replace(/\\sqrt\s*\{([^{}]+)\}/g, 'sqrt($1)')
    .replace(/\\(?:times|cdot)/g, '*')
    .replace(/\\pi/g, 'pi')
    .replace(/[{}$]/g, ' ')
    .replace(/\((-?\d+(?:\.\d+)?)\)/g, '$1');
  const out = [];
  // scientific: 3 * 10^8, 3e8
  for (const m of s.matchAll(/(-?\d+(?:\.\d+)?)\s*\*\s*10\s*\^\s*\(?\s*(-?\d+)\s*\)?/g)) out.push(Number(m[1]) * 10 ** Number(m[2]));
  s = s.replace(/(-?\d+(?:\.\d+)?)\s*\*\s*10\s*\^\s*\(?\s*(-?\d+)\s*\)?/g, ' ');
  // simple fractions a/b
  for (const m of s.matchAll(/(-?\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)/g)) if (Number(m[2]) !== 0) out.push(Number(m[1]) / Number(m[2]));
  for (const m of s.matchAll(/-?\d+(?:,\d{3})+(?:\.\d+)?|-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?|-?\.\d+/g)) {
    const raw = m[0].replace(/,(?=\d{3}\b)/g, '');
    const v = Number(raw);
    if (Number.isFinite(v)) out.push(v);
  }
  return out;
}

export function numbersMatch(a, b, rel = 1e-6, abs = 1e-9) {
  if (!Number.isFinite(a) || !Number.isFinite(b)) return false;
  const d = Math.abs(a - b);
  return d <= abs || d <= rel * Math.max(Math.abs(a), Math.abs(b));
}
