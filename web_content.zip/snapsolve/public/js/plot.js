import { evaluate } from './mathEval.js';

/** Draw y=f(x) on a canvas using the safe evaluator (no eval). Returns false if the function cannot be plotted. */
export function drawPlot(canvas, { expression, xMin, xMax }, { dark = false } = {}) {
  const W = 640, H = 400, P = 36;
  canvas.width = W; canvas.height = H;
  const g = canvas.getContext('2d');
  const fg = dark ? '#eaf0ff' : '#0d1630', grid = dark ? 'rgba(160,185,255,.16)' : 'rgba(15,30,80,.12)', bg = dark ? '#121c3f' : '#ffffff';
  g.fillStyle = bg; g.fillRect(0, 0, W, H);
  const N = 500, pts = [];
  let yMin = Infinity, yMax = -Infinity, ok = 0;
  for (let i = 0; i <= N; i++) {
    const x = xMin + ((xMax - xMin) * i) / N;
    let y = NaN;
    try { y = evaluate(expression, { x }); } catch { /* undefined here */ }
    pts.push([x, y]);
    if (Number.isFinite(y)) { ok++; yMin = Math.min(yMin, y); yMax = Math.max(yMax, y); }
  }
  if (ok < 5) return false;
  // clip wild asymptotes using robust percentile bounds
  const ys = pts.map((p) => p[1]).filter(Number.isFinite).sort((a, b) => a - b);
  const lo = ys[Math.floor(ys.length * 0.02)], hi = ys[Math.ceil(ys.length * 0.98) - 1];
  const span = hi - lo || 1;
  yMin = Math.max(yMin, lo - span * 0.15); yMax = Math.min(yMax, hi + span * 0.15);
  if (yMax === yMin) { yMax += 1; yMin -= 1; }
  const sx = (x) => P + ((x - xMin) / (xMax - xMin)) * (W - 2 * P);
  const sy = (y) => H - P - ((y - yMin) / (yMax - yMin)) * (H - 2 * P);
  const nice = (a, b) => { const r = (b - a) / 6, p = 10 ** Math.floor(Math.log10(r)), m = r / p; return (m < 1.5 ? 1 : m < 3.5 ? 2 : m < 7.5 ? 5 : 10) * p; };
  g.font = '12px system-ui,sans-serif'; g.lineWidth = 1;
  const stepX = nice(xMin, xMax), stepY = nice(yMin, yMax);
  g.textAlign = 'center'; g.fillStyle = fg;
  for (let x = Math.ceil(xMin / stepX) * stepX; x <= xMax; x += stepX) { g.strokeStyle = grid; g.beginPath(); g.moveTo(sx(x), P); g.lineTo(sx(x), H - P); g.stroke(); g.fillText(String(+x.toPrecision(4)), sx(x), H - P + 16); }
  g.textAlign = 'right';
  for (let y = Math.ceil(yMin / stepY) * stepY; y <= yMax; y += stepY) { g.strokeStyle = grid; g.beginPath(); g.moveTo(P, sy(y)); g.lineTo(W - P, sy(y)); g.stroke(); g.fillText(String(+y.toPrecision(4)), P - 5, sy(y) + 4); }
  g.strokeStyle = fg; g.lineWidth = 1.5;
  if (xMin <= 0 && xMax >= 0) { g.beginPath(); g.moveTo(sx(0), P); g.lineTo(sx(0), H - P); g.stroke(); }
  if (yMin <= 0 && yMax >= 0) { g.beginPath(); g.moveTo(P, sy(0)); g.lineTo(W - P, sy(0)); g.stroke(); }
  const grad = g.createLinearGradient(0, 0, W, 0); grad.addColorStop(0, '#2f7bff'); grad.addColorStop(1, '#8b5cf6');
  g.strokeStyle = grad; g.lineWidth = 3; g.lineJoin = 'round'; g.beginPath();
  let pen = false, prev = null;
  for (const [x, y] of pts) {
    if (!Number.isFinite(y) || y < yMin - (yMax - yMin) || y > yMax + (yMax - yMin) || (prev !== null && Math.abs(y - prev) > (yMax - yMin) * 1.5)) { pen = false; prev = Number.isFinite(y) ? y : null; continue; }
    if (!pen) { g.moveTo(sx(x), sy(y)); pen = true; } else g.lineTo(sx(x), sy(y));
    prev = y;
  }
  g.stroke();
  return true;
}
