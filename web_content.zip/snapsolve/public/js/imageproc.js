// Client-side image preparation. Everything here is plain canvas maths; nothing leaves the device from this module.
const MAX_DIM = 1600;

export async function fileToCanvas(file) {
  let bmp;
  try { bmp = await createImageBitmap(file, { imageOrientation: 'from-image' }); }
  catch {
    bmp = await new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = rej; im.src = URL.createObjectURL(file); });
  }
  const w = bmp.width || bmp.naturalWidth, h = bmp.height || bmp.naturalHeight;
  if (!w || !h) throw new Error('empty image');
  const k = Math.min(1, 2400 / Math.max(w, h));
  const c = document.createElement('canvas');
  c.width = Math.round(w * k); c.height = Math.round(h * k);
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  bmp.close?.();
  return c;
}

function small(canvas, max = 256) {
  const k = Math.min(1, max / Math.max(canvas.width, canvas.height));
  const c = document.createElement('canvas');
  c.width = Math.max(8, Math.round(canvas.width * k)); c.height = Math.max(8, Math.round(canvas.height * k));
  c.getContext('2d', { willReadFrequently: true }).drawImage(canvas, 0, 0, c.width, c.height);
  return c;
}
function gray(canvas) {
  const { width: w, height: h } = canvas;
  const d = canvas.getContext('2d', { willReadFrequently: true }).getImageData(0, 0, w, h).data;
  const g = new Float32Array(w * h);
  for (let i = 0, j = 0; i < d.length; i += 4, j++) g[j] = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
  return { g, w, h };
}

/** Sharpness (variance of Laplacian), brightness and contrast → a simple, explainable quality verdict. */
export function assessQuality(canvas) {
  const { g, w, h } = gray(small(canvas, 320));
  let sum = 0, sum2 = 0;
  for (const v of g) { sum += v; sum2 += v * v; }
  const n = g.length, mean = sum / n, std = Math.sqrt(Math.max(0, sum2 / n - mean * mean));
  let lap = 0, lap2 = 0, cnt = 0;
  for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) {
    const i = y * w + x, l = 4 * g[i] - g[i - 1] - g[i + 1] - g[i - w] - g[i + w];
    lap += l; lap2 += l * l; cnt++;
  }
  const blur = lap2 / cnt - (lap / cnt) ** 2;
  let level = 'ok';
  if (mean < 40) level = 'dark'; else if (mean > 235 && std < 25) level = 'bright'; else if (blur < 18) level = 'blurry';
  return { blur: Math.round(blur), brightness: Math.round(mean), contrast: Math.round(std), level };
}

/** Trim empty margins around the content. Conservative: only crops when it clearly removes surroundings. */
export function autoCrop(canvas) {
  const s = small(canvas, 200);
  const { g, w, h } = gray(s);
  const edge = new Float32Array(w * h);
  for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) { const i = y * w + x; edge[i] = Math.abs(g[i + 1] - g[i - 1]) + Math.abs(g[i + w] - g[i - w]); }
  const rows = new Float32Array(h), cols = new Float32Array(w);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const e = edge[y * w + x] > 40 ? 1 : 0; rows[y] += e; cols[x] += e; }
  const first = (arr, thr) => { for (let i = 0; i < arr.length; i++) if (arr[i] > thr) return i; return 0; };
  const last = (arr, thr) => { for (let i = arr.length - 1; i >= 0; i--) if (arr[i] > thr) return i; return arr.length - 1; };
  const rt = Math.max(1.5, w * 0.012), ct = Math.max(1.5, h * 0.012);
  let x0 = first(cols, ct), x1 = last(cols, ct), y0 = first(rows, rt), y1 = last(rows, rt);
  const padX = w * 0.05, padY = h * 0.05;
  x0 = Math.max(0, x0 - padX); x1 = Math.min(w - 1, x1 + padX); y0 = Math.max(0, y0 - padY); y1 = Math.min(h - 1, y1 + padY);
  const area = ((x1 - x0) * (y1 - y0)) / (w * h);
  if (!(area < 0.9 && area > 0.2)) return { canvas, cropped: false };
  const k = canvas.width / w;
  const c = document.createElement('canvas');
  c.width = Math.round((x1 - x0) * k); c.height = Math.round((y1 - y0) * k);
  c.getContext('2d').drawImage(canvas, x0 * k, y0 * k, c.width, c.height, 0, 0, c.width, c.height);
  return { canvas: c, cropped: true };
}

/** Estimate small skew (±8°) of text lines with a projection-profile search. Returns the degrees to pass to rotate() to straighten the page (0 if unsure). */
export function estimateSkew(canvas) {
  const { g, w, h } = gray(small(canvas, 180));
  // "ink" = clearly darker than its local neighbourhood (adaptive threshold via an integral image), so a dark desk
  // or uneven lighting around the page does not count as text.
  const bin = new Uint8Array(w * h), I = new Float64Array((w + 1) * (h + 1)), R = 7;
  for (let y = 0; y < h; y++) { let row = 0; for (let x = 0; x < w; x++) { row += g[y * w + x]; I[(y + 1) * (w + 1) + x + 1] = I[y * (w + 1) + x + 1] + row; } }
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const x0 = Math.max(0, x - R), x1 = Math.min(w, x + R + 1), y0 = Math.max(0, y - R), y1 = Math.min(h, y + R + 1);
    const sum = I[y1 * (w + 1) + x1] - I[y0 * (w + 1) + x1] - I[y1 * (w + 1) + x0] + I[y0 * (w + 1) + x0];
    bin[y * w + x] = g[y * w + x] < (sum / ((x1 - x0) * (y1 - y0))) * 0.78 ? 1 : 0;
  }
  let ink = 0; for (const v of bin) ink += v;
  if (ink < w * h * 0.01) return 0;
  const score = (deg) => {
    const a = (deg * Math.PI) / 180, cos = Math.cos(a), sin = Math.sin(a), prof = new Float32Array(h * 2);
    // the outer 10% is ignored: canvas borders / fill created by rotation must not be mistaken for text lines
    for (let y = Math.floor(h * 0.1); y < h * 0.9; y++) for (let x = Math.floor(w * 0.1); x < w * 0.9; x++) if (bin[y * w + x]) {
      const yy = Math.round((x - w / 2) * sin + (y - h / 2) * cos + h);
      if (yy >= 0 && yy < prof.length) prof[yy]++;
    }
    let m = 0, v = 0; for (const p of prof) m += p; m /= prof.length; for (const p of prof) v += (p - m) ** 2;
    return v;
  };
  let best = 0, bestS = score(0);
  for (let d = -8; d <= 8; d += 0.5) { if (d === 0) continue; const s = score(d); if (s > bestS) { bestS = s; best = d; } }
  const base = score(0);
  return Math.abs(best) >= 1.5 && bestS > base * 1.12 ? best : 0;
}

export function rotate(canvas, deg) {
  const r = (deg * Math.PI) / 180, q = Math.abs(deg) % 180 === 90;
  const c = document.createElement('canvas');
  if (q) { c.width = canvas.height; c.height = canvas.width; }
  else {
    const cos = Math.abs(Math.cos(r)), sin = Math.abs(Math.sin(r));
    c.width = Math.round(canvas.width * cos + canvas.height * sin); c.height = Math.round(canvas.width * sin + canvas.height * cos);
  }
  const g = c.getContext('2d');
  g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height);
  g.translate(c.width / 2, c.height / 2); g.rotate(r); g.drawImage(canvas, -canvas.width / 2, -canvas.height / 2);
  return c;
}

/** Stretch contrast (1st–99th percentile) and, if the photo is soft, apply a light unsharp mask. */
export function enhance(canvas, { sharpen = false } = {}) {
  const g = canvas.getContext('2d', { willReadFrequently: true });
  const img = g.getImageData(0, 0, canvas.width, canvas.height), d = img.data;
  const hist = new Uint32Array(256);
  for (let i = 0; i < d.length; i += 4) hist[(0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]) | 0]++;
  const total = d.length / 4;
  let acc = 0, lo = 0, hi = 255;
  for (let v = 0; v < 256; v++) { acc += hist[v]; if (acc >= total * 0.01) { lo = v; break; } }
  acc = 0; for (let v = 255; v >= 0; v--) { acc += hist[v]; if (acc >= total * 0.01) { hi = v; break; } }
  if (hi - lo > 40 && hi - lo < 235) {
    const k = 255 / (hi - lo);
    for (let i = 0; i < d.length; i += 4) for (let c = 0; c < 3; c++) d[i + c] = Math.max(0, Math.min(255, (d[i + c] - lo) * k));
  }
  if (sharpen) {
    const { width: w, height: h } = canvas, src = new Uint8ClampedArray(d), a = 0.5;
    for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) {
      const i = (y * w + x) * 4;
      for (let c = 0; c < 3; c++) {
        const lap = 4 * src[i + c] - src[i + c - 4] - src[i + c + 4] - src[i + c - w * 4] - src[i + c + w * 4];
        d[i + c] = Math.max(0, Math.min(255, src[i + c] + a * lap));
      }
    }
  }
  g.putImageData(img, 0, 0);
  return canvas;
}

/** Downscale and JPEG-encode so the upload stays under the server limit without destroying small print. */
export function encode(canvas, maxBytes) {
  let dim = MAX_DIM, q = 0.86;
  for (let i = 0; i < 8; i++) {
    const k = Math.min(1, dim / Math.max(canvas.width, canvas.height));
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(canvas.width * k)); c.height = Math.max(1, Math.round(canvas.height * k));
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(canvas, 0, 0, c.width, c.height);
    const url = c.toDataURL('image/jpeg', q);
    if ((url.length * 3) / 4 <= maxBytes * 0.92) return url;
    if (q > 0.6) q -= 0.1; else dim = Math.round(dim * 0.8);
  }
  throw new Error('image too large');
}

/** Full automatic pipeline used right after capture/upload. */
export async function prepare(canvas, maxBytes) {
  const quality = assessQuality(canvas);
  let c = canvas, steps = [];
  const skew = estimateSkew(c);
  if (skew) { c = rotate(c, skew); steps.push('deskew'); }
  const ac = autoCrop(c);
  if (ac.cropped) { c = ac.canvas; steps.push('crop'); }
  enhance(c, { sharpen: quality.level === 'blurry' });
  steps.push('enhance');
  return { canvas: c, dataUrl: encode(c, maxBytes), quality, steps };
}
