// Tiny i18n layer. Add a language: create public/i18n/<code>.json, add it to LANG_META, and see src/solver/langs.js on the server.
const LANG_META = { en: { dir: 'ltr', locale: 'en-US', speech: 'en-US' }, ar: { dir: 'rtl', locale: 'ar', speech: 'ar-SA' } };
let dict = {};
let fallback = {};
let current = 'en';

async function load(code) {
  const r = await fetch(`/i18n/${code}.json`, { cache: 'no-cache' });
  if (!r.ok) throw new Error('i18n load failed');
  return r.json();
}

export async function setLanguage(code) {
  if (!LANG_META[code]) code = 'en';
  if (!Object.keys(fallback).length) fallback = await load('en');
  dict = code === 'en' ? fallback : await load(code).catch(() => fallback);
  current = code;
  const root = document.documentElement;
  root.lang = code;
  root.dir = LANG_META[code].dir;
  applyAll();
  return code;
}

export const lang = () => current;
export const meta = () => LANG_META[current];
export const languages = () => Object.keys(LANG_META);

export function t(key, vars) {
  let s = dict[key] ?? fallback[key] ?? key;
  if (vars) for (const [k, v] of Object.entries(vars)) s = s.replaceAll(`{${k}}`, String(v));
  return s;
}

export function applyAll(root = document) {
  root.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
  root.querySelectorAll('[data-i18n-aria]').forEach((el) => { el.setAttribute('aria-label', t(el.dataset.i18nAria)); el.title = t(el.dataset.i18nAria); });
  root.querySelectorAll('[data-i18n-ph]').forEach((el) => { el.placeholder = t(el.dataset.i18nPh); });
}

/** Locale-aware number formatting for UI numbers only (never used inside formulas). */
export const fmtNum = (n) => new Intl.NumberFormat(LANG_META[current].locale).format(n);
export const fmtDate = (ts) => new Intl.DateTimeFormat(LANG_META[current].locale, { dateStyle: 'medium', timeStyle: 'short' }).format(ts);
