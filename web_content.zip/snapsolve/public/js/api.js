import { getSettings } from './store.js';

export class ApiError extends Error {
  constructor(status, code, message, extra) { super(message); this.status = status; this.code = code; this.extra = extra || {}; }
}

function headers(extra = {}) {
  const h = { 'content-type': 'application/json', ...extra };
  const code = getSettings().accessCode;
  if (code) h['x-access-code'] = code;
  return h;
}

async function request(method, url, body, { signal, admin } = {}) {
  let res;
  try {
    res = await fetch(url, { method, headers: headers(admin ? { authorization: `Bearer ${admin}` } : {}), body: body === undefined ? undefined : JSON.stringify(body), signal });
  } catch (e) {
    if (e.name === 'AbortError') throw new ApiError(0, 'CANCELLED', 'cancelled');
    throw new ApiError(0, navigator.onLine ? 'NETWORK' : 'OFFLINE', 'network');
  }
  let data = null;
  try { data = await res.json(); } catch { /* non-JSON */ }
  if (!res.ok) {
    const e = data?.error || {};
    throw new ApiError(res.status, e.code || 'HTTP_' + res.status, e.message || `HTTP ${res.status}`, e);
  }
  return data;
}

export const api = {
  config: (opts) => request('GET', '/api/config', undefined, opts),
  recognize: (body, opts) => request('POST', '/api/recognize', body, opts),
  solve: (body, opts) => request('POST', '/api/solve', body, opts),
  verify: (body, opts) => request('POST', '/api/verify', body, opts),
  followup: (body, opts) => request('POST', '/api/followup', body, opts),
  translate: (body, opts) => request('POST', '/api/translate', body, opts),
  admin: {
    list: (token) => request('GET', '/api/admin/providers', undefined, { admin: token }),
    test: (id, token) => request('POST', `/api/admin/providers/${id}/test`, {}, { admin: token }),
    patch: (id, body, token) => request('PATCH', `/api/admin/providers/${id}`, body, { admin: token }),
    setKey: (id, apiKey, token) => request('PUT', `/api/admin/providers/${id}/key`, { apiKey }, { admin: token }),
    clearKey: (id, token) => request('DELETE', `/api/admin/providers/${id}/key`, undefined, { admin: token }),
  },
};
