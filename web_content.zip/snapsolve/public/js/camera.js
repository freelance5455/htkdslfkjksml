// Camera control on top of getUserMedia. Requires a secure context (HTTPS or localhost) – browsers enforce this.
export function createCamera(video) {
  let stream = null, track = null, facing = 'environment', torchOn = false;

  const stop = () => { stream?.getTracks().forEach((tr) => tr.stop()); stream = null; track = null; torchOn = false; video.srcObject = null; };

  async function start() {
    stop();
    if (!window.isSecureContext) throw Object.assign(new Error('insecure'), { name: 'InsecureContext' });
    if (!navigator.mediaDevices?.getUserMedia) throw Object.assign(new Error('unsupported'), { name: 'Unsupported' });
    const tries = [
      { video: { facingMode: { ideal: facing }, width: { ideal: 1920 }, height: { ideal: 1080 } }, audio: false },
      { video: true, audio: false },
    ];
    let lastErr;
    for (const c of tries) {
      try { stream = await navigator.mediaDevices.getUserMedia(c); break; } catch (e) { lastErr = e; if (e.name === 'NotAllowedError' || e.name === 'SecurityError') break; }
    }
    if (!stream) throw lastErr;
    video.srcObject = stream;
    await video.play().catch(() => {});
    track = stream.getVideoTracks()[0];
    // continuous autofocus where the browser supports it
    try { await track.applyConstraints({ advanced: [{ focusMode: 'continuous' }] }); } catch { /* optional */ }
    return { torch: !!track.getCapabilities?.().torch, facing: track.getSettings?.().facingMode || facing };
  }

  return {
    start, stop,
    get active() { return !!stream; },
    async flip() { facing = facing === 'environment' ? 'user' : 'environment'; return start(); },
    async setTorch(on) { await track.applyConstraints({ advanced: [{ torch: !!on }] }); torchOn = !!on; return torchOn; },
    get torch() { return torchOn; },
    grab() {
      if (!stream || !video.videoWidth) return null;
      const c = document.createElement('canvas');
      c.width = video.videoWidth; c.height = video.videoHeight;
      c.getContext('2d').drawImage(video, 0, 0);
      return c;
    },
  };
}
