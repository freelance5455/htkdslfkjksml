// Manual crop + rotate editor on a canvas (pointer events: works with touch, pen and mouse).
export function createCropper(canvas) {
  let src = null, rect = null, drag = null, scale = 1;
  const H = 22; // handle hit radius in CSS px

  function layout() {
    const maxW = Math.min(canvas.parentElement.clientWidth - 8, 860), maxH = Math.max(160, canvas.parentElement.clientHeight - 8);
    scale = Math.min(maxW / src.width, maxH / src.height, 1);
    canvas.width = Math.round(src.width * scale); canvas.height = Math.round(src.height * scale);
  }
  function draw() {
    const g = canvas.getContext('2d');
    g.clearRect(0, 0, canvas.width, canvas.height);
    g.drawImage(src, 0, 0, canvas.width, canvas.height);
    g.fillStyle = 'rgba(5,10,30,.55)';
    g.fillRect(0, 0, canvas.width, rect.y); g.fillRect(0, rect.y + rect.h, canvas.width, canvas.height - rect.y - rect.h);
    g.fillRect(0, rect.y, rect.x, rect.h); g.fillRect(rect.x + rect.w, rect.y, canvas.width - rect.x - rect.w, rect.h);
    g.strokeStyle = '#4d8dff'; g.lineWidth = 2; g.strokeRect(rect.x, rect.y, rect.w, rect.h);
    g.fillStyle = '#fff'; g.strokeStyle = '#2f7bff';
    for (const [x, y] of corners()) { g.beginPath(); g.arc(x, y, 9, 0, 7); g.fill(); g.stroke(); }
  }
  const corners = () => [[rect.x, rect.y], [rect.x + rect.w, rect.y], [rect.x, rect.y + rect.h], [rect.x + rect.w, rect.y + rect.h]];
  const pos = (e) => { const b = canvas.getBoundingClientRect(); return { x: ((e.clientX - b.left) / b.width) * canvas.width, y: ((e.clientY - b.top) / b.height) * canvas.height }; };
  function hit(p) {
    const r = H * (canvas.width / canvas.getBoundingClientRect().width);
    const idx = corners().findIndex(([x, y]) => Math.hypot(p.x - x, p.y - y) < r);
    if (idx >= 0) return { type: 'corner', idx };
    if (p.x > rect.x && p.x < rect.x + rect.w && p.y > rect.y && p.y < rect.y + rect.h) return { type: 'move' };
    return null;
  }
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  canvas.addEventListener('pointerdown', (e) => {
    if (!src) return;
    const p = pos(e), h = hit(p);
    if (!h) return;
    drag = { ...h, start: p, orig: { ...rect } };
    canvas.setPointerCapture(e.pointerId);
  });
  canvas.addEventListener('pointermove', (e) => {
    if (!drag) return;
    const p = pos(e), dx = p.x - drag.start.x, dy = p.y - drag.start.y, o = drag.orig, min = 40;
    if (drag.type === 'move') {
      rect.x = clamp(o.x + dx, 0, canvas.width - o.w); rect.y = clamp(o.y + dy, 0, canvas.height - o.h);
    } else {
      let x0 = o.x, y0 = o.y, x1 = o.x + o.w, y1 = o.y + o.h;
      if (drag.idx % 2 === 0) x0 = clamp(o.x + dx, 0, x1 - min); else x1 = clamp(o.x + o.w + dx, x0 + min, canvas.width);
      if (drag.idx < 2) y0 = clamp(o.y + dy, 0, y1 - min); else y1 = clamp(o.y + o.h + dy, y0 + min, canvas.height);
      rect = { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
    }
    draw();
  });
  const end = () => { drag = null; };
  canvas.addEventListener('pointerup', end); canvas.addEventListener('pointercancel', end);

  return {
    load(source) { src = source; layout(); rect = { x: 0, y: 0, w: canvas.width, h: canvas.height }; draw(); },
    reset() { rect = { x: 0, y: 0, w: canvas.width, h: canvas.height }; draw(); },
    setSource(source) { src = source; layout(); rect = { x: 0, y: 0, w: canvas.width, h: canvas.height }; draw(); },
    result() {
      const k = 1 / scale, c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(rect.w * k)); c.height = Math.max(1, Math.round(rect.h * k));
      c.getContext('2d').drawImage(src, rect.x * k, rect.y * k, rect.w * k, rect.h * k, 0, 0, c.width, c.height);
      return c;
    },
  };
}
