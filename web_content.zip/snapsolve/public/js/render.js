import { t } from './i18n.js';

// ── KaTeX is loaded lazily (keeps first load small). If it cannot load (offline first run) we show the raw LaTeX honestly.
let katexPromise = null;
export function loadKatex() {
  if (window.katex) return Promise.resolve(window.katex);
  if (!katexPromise) {
    katexPromise = new Promise((resolve) => {
      const css = document.createElement('link');
      css.rel = 'stylesheet'; css.href = '/vendor/katex/katex.min.css';
      document.head.appendChild(css);
      const s = document.createElement('script');
      s.src = '/vendor/katex/katex.min.js';
      s.onload = () => resolve(window.katex || null);
      s.onerror = () => { katexPromise = null; resolve(null); };
      document.head.appendChild(s);
    });
  }
  return katexPromise;
}

export function el(tag, props = {}, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') n.className = v;
    else if (k === 'text') n.textContent = v;
    else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
    else if (k === 'dataset') Object.assign(n.dataset, v);
    else n.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat()) if (kid != null && kid !== false) n.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  return n;
}

function mathNode(latex, display, katex) {
  const span = document.createElement(display ? 'div' : 'span');
  if (katex) {
    try {
      // trust:false → \href, \includegraphics etc. are disabled; output is KaTeX-generated markup only
      span.innerHTML = katex.renderToString(latex, { displayMode: display, throwOnError: false, trust: false, strict: 'ignore', maxSize: 20, maxExpand: 1000 });
      if (display) span.className = 'math-block';
      return span;
    } catch { /* fall through to raw */ }
  }
  span.className = 'raw-math';
  span.textContent = latex;
  return span;
}

const MATH_RE = /\$\$([\s\S]+?)\$\$|\$([^$\n]+?)\$|\\\(([\s\S]+?)\\\)|\\\[([\s\S]+?)\\\]/g;

/** Fill `target` with text where $...$ segments are typeset. All prose goes through textContent (never innerHTML). */
export async function richInto(target, text) {
  const s = String(text ?? '');
  const hasMath = /\$|\\\(|\\\[/.test(s);
  const katex = hasMath ? await loadKatex() : null;
  target.textContent = '';
  let last = 0;
  for (const m of s.matchAll(MATH_RE)) {
    if (m.index > last) target.append(document.createTextNode(s.slice(last, m.index)));
    const display = m[1] != null || m[4] != null;
    target.append(mathNode(m[1] ?? m[2] ?? m[3] ?? m[4], display, katex));
    last = m.index + m[0].length;
  }
  if (last < s.length) target.append(document.createTextNode(s.slice(last)));
  return target;
}
export const rich = (tag, props, text) => { const n = el(tag, props); richInto(n, text); return n; };

export async function latexInto(target, latex, display = true) {
  const katex = await loadKatex();
  target.textContent = '';
  target.append(mathNode(String(latex), display, katex));
  return target;
}
export const latexBlock = (latex, cls = 'formula') => { const n = el('div', { class: cls }); latexInto(n, latex, true); return n; };

/** Plain-text version of a rich string (for copy / share / speech). */
export const plain = (s) => String(s ?? '').replace(/\$\$?([^$]+)\$\$?/g, '$1').replace(/\\\(|\\\)|\\\[|\\\]/g, '').replace(/\\(?:text|mathrm)\{([^}]*)\}/g, '$1').replace(/\\frac\{([^}]*)\}\{([^}]*)\}/g, '($1)/($2)').replace(/\\sqrt\{([^}]*)\}/g, '√($1)').replace(/\\(cdot|times)/g, '×').replace(/\\[a-zA-Z]+/g, '').replace(/[{}]/g, '');

export function solutionToText(sol) {
  const L = [];
  L.push(plain(sol.question), '');
  if (sol.steps?.length) { sol.steps.forEach((s, i) => L.push(`${i + 1}. ${plain(s.title)}${s.explanation ? ': ' + plain(s.explanation) : ''}${s.latex ? '  [' + plain(s.latex) + ']' : ''}`)); L.push(''); }
  L.push(`${t('result.final')}: ${plain(sol.finalAnswer.text)}${sol.finalAnswer.unit ? ' ' + sol.finalAnswer.unit : ''}`);
  return L.join('\n');
}
