import { setLanguage, t, lang, meta, applyAll, fmtDate } from './i18n.js';
import { api, ApiError } from './api.js';
import { getSettings, saveSettings, listHistory, saveItem, isSaved, deleteItem, clearHistory, clearAll, newId } from './store.js';
import { el, richInto, rich, latexBlock, loadKatex, plain, solutionToText } from './render.js';
import { createCamera } from './camera.js';
import { fileToCanvas, prepare, rotate } from './imageproc.js';
import { tryDirect, evaluate, formatNumber } from './mathEval.js';
import { drawPlot } from './plot.js';

const $ = (id) => document.getElementById(id);
const SUBJECTS = ['auto', 'math', 'physics', 'chemistry', 'biology', 'cs', 'engineering', 'language', 'history', 'geography', 'economics', 'science', 'other'];
const S = { cfg: null, stack: ['home'], image: null, canvas: null, rec: null, batch: null, active: 0, current: null, ctl: null, busy: false, showing: 'original', speaking: false, lastAction: null };

/* ───────────────────────── helpers ───────────────────────── */
let toastTimer;
function toast(msg, ms = 3200) {
  const n = $('toast'); n.textContent = msg; n.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { n.hidden = true; }, ms);
}
function confirmDialog(msg) {
  return new Promise((resolve) => {
    const d = $('dlg-confirm'); $('dlg-confirm-msg').textContent = msg;
    d.addEventListener('close', () => resolve(d.returnValue === 'yes'), { once: true });
    d.returnValue = 'no'; d.showModal();
  });
}
const isDark = () => document.documentElement.dataset.theme === 'dark' || (document.documentElement.dataset.theme !== 'light' && matchMedia('(prefers-color-scheme: dark)').matches);

/* ───────────────────────── navigation ───────────────────────── */
const cam = createCamera($('video'));
function show(name, { replace = false } = {}) {
  document.querySelectorAll('.view').forEach((v) => v.classList.toggle('active', v.id === `view-${name}`));
  if (replace) S.stack[S.stack.length - 1] = name;
  else if (S.stack[S.stack.length - 1] !== name) S.stack.push(name);
  if (name === 'home') { S.stack = ['home']; startCamera(); } else cam.stop();
  window.scrollTo(0, 0);
  const focusEl = document.querySelector(`#view-${name} h1, #view-${name} h2`);
  focusEl?.setAttribute('tabindex', '-1'); focusEl?.focus({ preventScroll: true });
}
function back() {
  if (S.ctl) { S.ctl.abort(); S.ctl = null; }
  if (S.stack.length > 1) S.stack.pop();
  const prev = S.stack[S.stack.length - 1] || 'home';
  if (prev === 'processing') { S.stack.pop(); return show(S.stack[S.stack.length - 1] || 'home', { replace: true }); }
  show(prev, { replace: true });
  if (prev === 'home') S.stack = ['home'];
}
document.addEventListener('click', (e) => { if (e.target.closest('[data-back]')) back(); });
window.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !document.querySelector('dialog[open]') && S.stack.length > 1) back(); });

/* ───────────────────────── camera & intake ───────────────────────── */
async function startCamera() {
  $('cam-msg').hidden = true;
  if (S.stack[S.stack.length - 1] !== 'home' || document.hidden) return;
  try {
    const info = await cam.start();
    $('btn-flash').hidden = !info.torch; $('btn-flash').classList.remove('on');
  } catch (e) { showCamError(e); }
}
function showCamError(e) {
  const map = { NotAllowedError: 'denied', SecurityError: 'denied', NotFoundError: 'none', OverconstrainedError: 'none', NotReadableError: 'busy', AbortError: 'busy', InsecureContext: 'insecure', Unsupported: 'unsupported' };
  const k = map[e?.name] || 'generic';
  $('cam-msg-title').textContent = t(`cam.${k}.title`); $('cam-msg-text').textContent = t(`cam.${k}.text`);
  $('cam-msg').hidden = false; $('btn-flash').hidden = true;
}
document.addEventListener('visibilitychange', () => { if (document.hidden) cam.stop(); else if (S.stack[S.stack.length - 1] === 'home') startCamera(); });

$('btn-shutter').addEventListener('click', () => {
  if (!cam.active) return $('file-cam').click();
  const c = cam.grab();
  if (!c) return toast(t('cam.notReady'));
  navigator.vibrate?.(15);
  intake(c);
});
$('btn-scan-native').addEventListener('click', () => $('file-cam').click());
for (const id of ['btn-upload', 'btn-upload2']) $(id).addEventListener('click', () => $('file').click());
for (const id of ['file', 'file-cam']) $(id).addEventListener('change', async (e) => {
  const f = e.target.files[0]; e.target.value = '';
  if (!f) return;
  if (!/^image\//.test(f.type)) return toast(t('err.notImage'));
  try { intake(await fileToCanvas(f)); } catch { toast(t('err.badImage')); }
});
$('btn-switch').addEventListener('click', async () => { try { const i = await cam.flip(); $('btn-flash').hidden = !i.torch; $('cam-msg').hidden = true; } catch (e) { showCamError(e); } });
$('btn-flash').addEventListener('click', async () => { try { const on = await cam.setTorch(!cam.torch); $('btn-flash').classList.toggle('on', on); } catch { toast(t('cam.flashFail')); } });
$('btn-retry-cam').addEventListener('click', startCamera);

async function intake(canvas) {
  if (S.busy) return;
  S.canvas = canvas;
  beginProcessing(null, canvas.toDataURL('image/jpeg', 0.4));
  await tick();
  try {
    const max = S.cfg?.limits?.maxImageBytes || 4_000_000;
    const prep = await prepare(canvas, max);
    S.canvas = prep.canvas; S.image = prep.dataUrl; S.quality = prep.quality;
    $('proc-thumb').src = prep.dataUrl;
    // Only reject locally when the photo is hopeless; otherwise let the vision model judge readability.
    if (prep.quality.level === 'dark' && prep.quality.brightness < 25) return showReview({ unreadable: t('quality.dark') });
    runImage();
  } catch (e) { fail(e); }
}
const tick = () => new Promise((r) => requestAnimationFrame(() => setTimeout(r, 0)));

/* ───────────────────────── processing / stages ───────────────────────── */
const STAGES = { read: 'stage.read', solve: 'stage.solve', verify: 'stage.verify', prepare: 'stage.prepare' };
function beginProcessing(stageIds, thumb) {
  S.busy = true;
  const ids = stageIds || ['read', 'solve', 'verify', 'prepare'];
  const ol = $('proc-stages'); ol.textContent = '';
  for (const id of ids) ol.append(el('li', { dataset: { stage: id } }, el('span', { class: 'dot' }), el('span', { text: t(STAGES[id]) })));
  $('proc-note').textContent = '';
  $('proc-thumb').hidden = !thumb; if (thumb) $('proc-thumb').src = thumb;
  $('proc-title').textContent = t('proc.title');
  document.querySelector('#view-processing .retry-row')?.remove();
  $('btn-cancel').textContent = t('cancel');
  if (S.stack[S.stack.length - 1] !== 'processing') show('processing');
}
function stage(id, state) {
  const li = document.querySelector(`#proc-stages [data-stage="${id}"]`);
  if (!li) return;
  li.className = state;
  const dot = li.querySelector('.dot'); dot.textContent = '';
  if (state === 'done') dot.innerHTML = '<svg><use href="#i-check"/></svg>';
}
function endProcessing() { S.busy = false; S.ctl = null; }
$('btn-cancel').addEventListener('click', () => { if (S.busy) { S.ctl?.abort(); endProcessing(); } back(); });

function errMessage(e) {
  if (!(e instanceof ApiError)) return t('err.generic');
  switch (e.code) {
    case 'OFFLINE': return t('err.offline');
    case 'NETWORK': return t('err.network');
    case 'RATE_LIMITED': return t('err.rate', { s: e.extra?.retryAfterSec || 30 });
    case 'NO_PROVIDER': case 'NO_VISION': return t('err.noProvider');
    case 'PROVIDER_AUTH': return t('err.providerAuth');
    case 'ALL_PROVIDERS_FAILED': return t('err.providersFailed');
    case 'OCR_FAILED': return t('err.ocr');
    case 'PAYLOAD_TOO_LARGE': case 'IMAGE_TOO_LARGE': return t('err.tooLarge');
    case 'TEXT_TOO_LONG': return t('err.textTooLong');
    case 'ACCESS_CODE_REQUIRED': return t('access.title');
    default: return e.message && e.status && e.status < 500 ? e.message : t('err.generic');
  }
}
function fail(e) {
  const wasBusy = S.busy; endProcessing();
  if (e instanceof ApiError && e.code === 'CANCELLED') return;
  if (e instanceof ApiError && e.code === 'ACCESS_CODE_REQUIRED') { openAccess(); }
  console.warn('request failed', e?.code || e?.message);
  if (!wasBusy && S.stack[S.stack.length - 1] !== 'processing') return toast(errMessage(e));
  $('proc-title').textContent = t('proc.failed');
  document.querySelectorAll('#proc-stages li.active').forEach((li) => { li.className = 'failed'; });
  $('proc-note').textContent = errMessage(e);
  $('btn-cancel').textContent = t('back');
  document.querySelector('#view-processing .retry-row')?.remove();
  const row = el('div', { class: 'row wrap retry-row', style: 'justify-content:center' });
  if (S.lastAction && !(e instanceof ApiError && ['NO_PROVIDER', 'NO_VISION', 'PROVIDER_AUTH'].includes(e.code))) row.append(el('button', { class: 'btn primary', type: 'button', text: t('retry'), onclick: () => S.lastAction() }));
  row.append(el('button', { class: 'btn', type: 'button', text: t('type.open'), onclick: () => { back(); openType(); } }));
  if (e instanceof ApiError && ['NO_PROVIDER', 'NO_VISION', 'PROVIDER_AUTH'].includes(e.code)) row.append(el('button', { class: 'btn', type: 'button', text: t('settings.title'), onclick: () => show('settings') }));
  $('proc-note').after(row);
}

/* ───────────────────────── pipeline ───────────────────────── */
const subject = () => $('subject').value || 'auto';
const uiLang = () => lang();
const explainLang = () => getSettings().explain || 'auto';

function runImage() {
  S.lastAction = runImage;
  beginProcessing(null, S.image);
  S.ctl = new AbortController();
  (async () => {
    try {
      stage('read', 'active');
      const rec = await api.recognize({ image: S.image, subject: subject(), uiLanguage: uiLang() }, { signal: S.ctl.signal });
      stage('read', 'done');
      S.rec = rec;
      if (!rec.readable) { endProcessing(); return showReview({ unreadable: rec.reason || t('review.unreadable') }); }
      S.batch = rec.questions.map((q) => ({ q, result: null }));
      if (rec.questions.length > 1 || rec.needsReview) { endProcessing(); return showReview({ rec }); }
      await solveIndex(0, { fromProcessing: true });
    } catch (e) { fail(e); }
  })();
}

function runText(text) {
  S.lastAction = () => runText(text);
  S.image = null; S.canvas = null; S.rec = { source: 'typed', ambiguities: [] };
  S.batch = [{ q: { text, choices: null, hasDiagram: false, diagram: null, confidence: 1 }, result: null }];
  S.ctl = new AbortController();
  const local = localPlot(text) || (tryDirect(text) ? true : null);
  beginProcessing(local ? ['solve', 'prepare'] : ['solve', 'verify', 'prepare']);
  solveIndex(0, { fromProcessing: true }).catch(fail);
}

function localSolution(text) {
  const d = tryDirect(text); if (!d) return null;
  const ar = /[\u0600-\u06FF]/.test(text), v = formatNumber(d.value);
  return { subject: 'math', topic: t('local.topic'), difficulty: 'easy', language: ar ? 'ar' : 'en', question: text, known: [d.expression], asks: t('local.asks'),
    method: { name: t('local.method'), formulas: [] }, steps: [{ title: t('local.stepTitle'), explanation: t('local.stepText'), latex: null }],
    unitConversions: [], assumptions: [], missingInfo: [], selfCheck: { description: '', dimensionalConsistency: null },
    finalAnswer: { text: v, latex: v, value: d.value, unit: null }, why: t('local.why'), confidence: 1, plot: null, computeCheck: null, symbolicCheck: null, multipleChoice: null };
}
function localPlot(text) {
  const m = /^\s*(?:y|f\s*\(\s*x\s*\))\s*=\s*(.+?)\s*$/i.exec(text.replace(/\$/g, ''));
  if (!m || !/x/i.test(m[1])) return null;
  try { evaluate(m[1], { x: 1 }); } catch { try { evaluate(m[1], { x: 0.5 }); } catch { return null; } }
  return { subject: 'math', topic: t('local.plotTopic'), difficulty: 'easy', language: lang(), question: text, known: [], asks: t('local.plotAsks'),
    method: { name: t('local.plotMethod'), formulas: [] }, steps: [], unitConversions: [], assumptions: [t('local.plotRange')], missingInfo: [], selfCheck: { description: '', dimensionalConsistency: null },
    finalAnswer: { text: `y = ${m[1]}`, latex: null, value: null, unit: null }, why: '', confidence: 1,
    plot: { expression: m[1], variable: 'x', xMin: -10, xMax: 10 }, computeCheck: null, symbolicCheck: null, multipleChoice: null };
}

async function solveIndex(i, { fromProcessing = false } = {}) {
  const entry = S.batch[i]; S.active = i;
  if (entry.result) { return openResult(entry.result); }
  if (!fromProcessing) { beginProcessing(['solve', 'verify', 'prepare']); S.ctl = new AbortController(); S.lastAction = () => solveIndex(i); }
  const q = entry.q, signal = S.ctl.signal;
  try {
    stage('solve', 'active');
    const local = localPlot(q.text) || localSolution(q.text);
    let result;
    if (local) {
      result = { id: newId(), question: q, solution: local, meta: { provider: 'local', model: t('local.engine') }, verification: { local: true, checks: [], summary: { status: 'computed' } } };
      stage('solve', 'done'); stage('verify', 'skipped');
    } else {
      if (!navigator.onLine) throw new ApiError(0, 'OFFLINE', 'offline');
      const withImage = S.image && (q.hasDiagram || q.confidence < 0.7);
      const out = await api.solve({ question: { text: q.text, choices: q.choices, hasDiagram: q.hasDiagram, diagram: q.diagram }, image: withImage ? S.image : undefined, subject: subject(), language: explainLang() }, { signal });
      stage('solve', 'done'); stage('verify', 'active');
      let verification;
      try { verification = await api.verify({ question: { text: q.text }, solution: out.solution, solvedBy: out.meta.provider, language: explainLang() }, { signal }); }
      catch (e) { if (e instanceof ApiError && e.code === 'CANCELLED') throw e; verification = { checks: [], summary: { status: 'unverified', note: t('verify.failedToRun') } }; }
      stage('verify', 'done');
      result = { id: newId(), question: q, solution: out.solution, meta: out.meta, verification, warnings: out.warnings || [] };
    }
    stage('prepare', 'active');
    entry.result = result;
    await openResult(result);
    stage('prepare', 'done');
    endProcessing();
  } catch (e) { throw e; }
}

/* ───────────────────────── review screen ───────────────────────── */
function showReview({ unreadable, rec }) {
  endProcessing();
  const banner = $('review-banner'), list = $('review-list');
  list.textContent = '';
  $('review-thumb').hidden = !S.image; if (S.image) $('review-thumb').src = S.image;
  banner.hidden = false;
  if (unreadable) {
    banner.className = 'banner bad'; banner.textContent = `${t('review.unreadableTitle')} ${unreadable} ${t('review.retakeTip')}`;
  } else {
    const amb = rec?.ambiguities || [];
    banner.className = 'banner warn';
    banner.textContent = rec?.source === 'ocr' ? t('review.ocrOnly') : (S.batch.length > 1 ? t('review.several', { n: S.batch.length }) : t('review.check')) + (amb.length ? ' ' + amb.join(' · ') : '');
  }
  (S.batch || []).forEach((entry, i) => {
    const q = entry.q, ta = el('textarea', { rows: 3, maxlength: 4000, 'aria-label': t('review.questionN', { n: i + 1 }) });
    ta.value = q.text; ta.addEventListener('input', () => { q.text = ta.value; q.confidence = 1; });
    const li = el('li', { class: 'card q-card' },
      el('div', { class: 'meta' }, el('strong', { text: t('review.questionN', { n: i + 1 }) }),
        q.hasDiagram ? el('span', { class: 'chip', text: t('review.hasDiagram') }) : null,
        el('span', { class: 'chip ' + (q.confidence >= 0.8 ? 'ok' : 'warn'), text: t('review.conf', { p: Math.round(q.confidence * 100) }) })),
      ta, q.choices?.length ? el('div', { class: 'small muted', text: q.choices.join('   ') }) : null,
      el('div', { class: 'row' }, el('button', { class: 'btn primary', type: 'button', text: t('review.solve'), onclick: () => { if (!ta.value.trim()) return; q.text = ta.value.trim(); S.batch[i].result = null; solveIndex(i); } })));
    list.append(li);
  });
  $('btn-solve-all').hidden = !(S.batch && S.batch.length > 1);
  $('btn-review-adjust').hidden = !S.canvas;
  show('review');
}
$('btn-review-retake').addEventListener('click', () => show('home'));
$('btn-review-type').addEventListener('click', openType);
$('btn-review-adjust').addEventListener('click', openCrop);
$('btn-solve-all').addEventListener('click', async () => {
  beginProcessing(['solve', 'verify', 'prepare']); S.ctl = new AbortController();
  try {
    for (let i = S.batch.length - 1; i >= 0; i--) {
      if (!S.batch[i].result) { const e = S.batch[i]; ['solve', 'verify', 'prepare'].forEach((s) => stage(s, '')); $('proc-note').textContent = t('review.progress', { i: S.batch.length - i, n: S.batch.length }); await solveIndex(i, { fromProcessing: true }); S.busy = true; }
    }
    endProcessing();
  } catch (e) { fail(e); }
});

/* ───────────────────────── crop / adjust ───────────────────────── */
let cropper = null, cropSrc = null;
async function openCrop() {
  if (!S.canvas) return;
  const { createCropper } = await import('./crop.js');
  cropper ||= createCropper($('crop-canvas'));
  cropSrc = S.canvas;
  show('crop');
  requestAnimationFrame(() => cropper.load(cropSrc));
}
$('btn-rot-l').addEventListener('click', () => { cropSrc = rotate(cropSrc, -90); cropper.setSource(cropSrc); });
$('btn-rot-r').addEventListener('click', () => { cropSrc = rotate(cropSrc, 90); cropper.setSource(cropSrc); });
$('btn-crop-reset').addEventListener('click', () => cropper.reset());
$('btn-crop-apply').addEventListener('click', async () => {
  try {
    const c = cropper.result();
    const prep = await prepare(c, S.cfg?.limits?.maxImageBytes || 4_000_000);
    S.canvas = prep.canvas; S.image = prep.dataUrl;
    S.stack = ['home']; runImage();
  } catch { toast(t('err.badImage')); }
});

/* ───────────────────────── result screen ───────────────────────── */
async function openResult(result) {
  S.current = result; S.showing = 'original';
  await renderResult();
  if (getSettings().autoSave) persist(true);
  if (S.stack[S.stack.length - 1] === 'processing') { S.stack.pop(); show('result', { replace: false }); } else show('result');
  $('followups').textContent = '';
}
const viewSolution = () => (S.showing === 'translated' && S.current.translated ? S.current.translated : S.current.solution);

const chip = (text, cls = '') => el('span', { class: `chip ${cls}`, text });
const section = (key) => el('h3', { class: 'sec-h', text: t(key) });
const bullets = (arr) => el('ul', { class: 'list-plain' }, arr.map((x) => rich('li', {}, x)));

function verificationNode(v) {
  const box = el('div');
  const st = v.summary?.status;
  if (v.local || st === 'computed') {
    box.append(el('div', { class: 'verify-badge checked' }, el('div', {}, el('strong', { text: t('verify.computed') }), el('div', { class: 'small', text: t('verify.computedNote') }))));
    return box;
  }
  const label = { checked: t('verify.checked', { n: v.summary.passed }), conflict: t('verify.conflict'), unverified: t('verify.unverified') }[st] || t('verify.unverified');
  box.append(el('div', { class: `verify-badge ${st || 'unverified'}` }, el('div', {}, el('strong', { text: label }), el('div', { class: 'small', text: v.summary?.note || '' }))));
  if (v.checks?.length) {
    box.append(el('details', {}, el('summary', { text: t('verify.details') }),
      el('ul', { class: 'checks' }, v.checks.map((c) => el('li', {}, el('span', { class: 'k', text: t(`check.${c.kind}`) }), el('span', {}, el('span', { class: `chip ${{ passed: 'ok', failed: 'bad', skipped: '', inconclusive: 'warn', reported: '' }[c.status] || ''}`, text: t(`check.status.${c.status}`) }), ' ', c.detail))))));
  }
  return box;
}

async function renderResult() {
  const r = S.current, sol = viewSolution(), body = $('result-body');
  await loadKatex();
  body.textContent = '';
  // question tabs when a photo contained several questions
  if (S.batch && S.batch.length > 1) {
    body.append(el('div', { class: 'chips no-print', role: 'tablist' }, S.batch.map((b, i) => el('button', { class: 'chip-btn' + (i === S.active ? ' on' : ''), role: 'tab', 'aria-selected': i === S.active, type: 'button', text: t('review.questionN', { n: i + 1 }), onclick: () => { if (i !== S.active) solveIndex(i); } }))));
  }
  const qCard = el('div', { class: 'card question-card' }, el('div', { class: 'sec-h', style: 'margin-top:0', text: t('result.question') }), rich('div', {}, sol.question || r.question.text));
  body.append(qCard);
  const chips = el('div', { class: 'chips' }, chip(t(`subj.${sol.subject}`)), sol.topic ? chip(sol.topic) : null, chip(t(`diff.${sol.difficulty}`)),
    r.meta?.provider && r.meta.provider !== 'local' ? chip(`${r.meta.provider}${r.meta.cached ? ' · ' + t('result.cached') : ''}`) : chip(t('verify.noAi'), 'ok'),
    r.meta?.provider !== 'local' ? chip(t('result.modelConf', { p: Math.round(sol.confidence * 100) }), sol.confidence >= 0.75 ? '' : 'warn') : null);
  body.append(chips);
  if (r.warnings?.includes('diagram-not-seen')) body.append(el('div', { class: 'banner warn', text: t('warn.diagram') }));
  if (sol.confidence < 0.5 || sol.missingInfo.length) body.append(el('div', { class: 'banner warn' }, el('strong', { text: t('warn.lowConf') }), sol.missingInfo.length ? bullets(sol.missingInfo) : null));

  // final answer
  const fa = el('div', { class: 'card final', 'aria-live': 'polite' }, el('div', { class: 'label', text: t('result.final') }));
  const ans = el('div', { class: 'answer' });
  fa.append(ans); body.append(fa);
  if (sol.finalAnswer.latex) { ans.append(latexBlock(sol.finalAnswer.latex + (sol.finalAnswer.unit ? `\\ \\text{${sol.finalAnswer.unit.replace(/[\\{}]/g, '')}}` : ''), 'formula')); fa.append(el('div', { class: 'small', style: 'opacity:.9;margin-top:6px' }, rich('span', {}, sol.finalAnswer.text))); }
  else await richInto(ans, sol.finalAnswer.text + (sol.finalAnswer.unit ? ' ' + sol.finalAnswer.unit : ''));
  if (sol.multipleChoice) fa.append(el('div', { class: 'small', style: 'margin-top:6px' }, rich('span', {}, `${t('result.choice')}: ${sol.multipleChoice.selected}`)));

  body.append(verificationNode(r.verification || { checks: [], summary: { status: 'unverified' } }));

  if (sol.known.length) body.append(section('result.known'), el('div', { class: 'card' }, bullets(sol.known)));
  if (sol.asks) body.append(section('result.asks'), el('div', { class: 'card' }, rich('div', {}, sol.asks)));
  if (sol.method.name || sol.method.formulas.length) body.append(section('result.method'), el('div', { class: 'card' }, sol.method.name ? rich('strong', {}, sol.method.name) : null, sol.method.formulas.map((f) => latexBlock(f))));
  if (sol.assumptions.length) body.append(section('result.assumptions'), el('div', { class: 'card' }, bullets(sol.assumptions)));
  if (sol.unitConversions.length) body.append(section('result.units'), el('div', { class: 'card' }, bullets(sol.unitConversions)));
  if (sol.steps.length) {
    body.append(section('result.steps'));
    sol.steps.forEach((s, i) => body.append(el('details', { class: 'step', ...(sol.steps.length <= 3 ? { open: true } : {}) },
      el('summary', {}, el('span', { class: 'n', text: String(i + 1) }), rich('span', {}, s.title || t('result.stepN', { n: i + 1 }))),
      el('div', { class: 'body' }, s.explanation ? rich('div', {}, s.explanation) : null, s.latex ? latexBlock(s.latex) : null))));
  }
  if (sol.plot) {
    const cv = el('canvas', { class: 'plot', role: 'img', 'aria-label': t('result.plot') });
    body.append(section('result.plot'), cv);
    if (!drawPlot(cv, sol.plot, { dark: isDark() })) { cv.replaceWith(el('p', { class: 'muted', text: t('result.plotFail') })); }
  }
  if (sol.why) body.append(section('result.why'), el('div', { class: 'card' }, rich('div', {}, sol.why)));
  if (sol.selfCheck?.description) body.append(el('p', { class: 'small muted' }, `${t('result.selfCheck')}: `, plain(sol.selfCheck.description)));
  if (S.showing === 'translated') body.append(el('p', { class: 'small muted', text: t('result.translatedNote') }));
  renderActions();
}

function actionBtn(label, fn, cls = '') { return el('button', { class: `btn ${cls}`, type: 'button', text: label, onclick: fn }); }
function renderActions() {
  const box = $('result-actions'); box.textContent = '';
  const r = S.current, local = r.meta?.provider === 'local';
  box.append(actionBtn(t('act.copy'), copyAnswer), actionBtn(t('act.save'), () => persist(false), isSaved(r.id) ? 'primary' : ''));
  if (!local) box.append(
    actionBtn(t('act.explain'), () => follow('explain_more')), actionBtn(t('act.simplify'), () => follow('simplify')), actionBtn(t('act.another'), () => follow('another_method')),
    actionBtn(S.showing === 'translated' ? t('act.original') : t('act.translate'), toggleTranslate), actionBtn(t('act.verify'), crossCheck),
    actionBtn(t('act.study'), () => follow('study')), actionBtn(t('act.practice'), () => follow('practice')));
  box.append(actionBtn(S.speaking ? t('act.stop') : t('act.listen'), speak));
  if (navigator.share) box.append(actionBtn(t('act.share'), share));
  box.append(actionBtn(t('act.pdf'), () => window.print()), actionBtn(t('act.retake'), () => show('home'), 'primary'));
  $('ask-form').hidden = local;
}
async function copyAnswer() {
  const txt = solutionToText(viewSolution());
  try { await navigator.clipboard.writeText(txt); toast(t('toast.copied')); } catch { toast(t('toast.copyFail')); }
}
async function share() {
  try { await navigator.share({ title: 'SnapSolve AI', text: solutionToText(viewSolution()) }); } catch { /* cancelled */ }
}
function persist(silent) {
  const r = S.current;
  const ok = saveItem({ id: r.id, question: r.question, solution: r.solution, translated: r.translated || null, meta: { provider: r.meta?.provider }, verification: r.verification, subject: r.solution.subject, topic: r.solution.topic, ts: Date.now() });
  if (!silent) toast(ok ? t('toast.saved') : t('toast.saveFail'));
  renderActions(); renderRecent();
}
function speak() {
  const synth = window.speechSynthesis;
  if (!synth) return toast(t('toast.noSpeech'));
  if (S.speaking) { synth.cancel(); S.speaking = false; return renderActions(); }
  const sol = viewSolution();
  const text = [plain(sol.question), ...sol.steps.map((s) => `${plain(s.title)}. ${plain(s.explanation)}`), `${t('result.final')}: ${plain(sol.finalAnswer.text)}`].join('. ');
  const u = new SpeechSynthesisUtterance(text);
  u.lang = /[\u0600-\u06FF]/.test(sol.question) || sol.language === 'ar' ? 'ar-SA' : 'en-US';
  u.onend = u.onerror = () => { S.speaking = false; renderActions(); };
  S.speaking = true; synth.speak(u); renderActions();
}
$('btn-expand').addEventListener('click', () => {
  const ds = [...document.querySelectorAll('#result-body details.step')];
  const open = ds.some((d) => !d.open); ds.forEach((d) => { d.open = open; });
});

/* follow-ups */
async function guarded(label, fn) {
  if (!navigator.onLine) return toast(t('err.offline'));
  const card = el('div', { class: 'card follow-card' }, el('div', { class: 'row' }, el('span', { class: 'spinner-inline' }), el('span', { class: 'muted', text: label })));
  $('followups').prepend(card);
  card.scrollIntoView?.({ block: 'nearest', behavior: 'smooth' });
  try { await fn(card); } catch (e) { card.textContent = ''; card.append(el('p', { class: 'err', text: errMessage(e) })); if (e.code === 'ACCESS_CODE_REQUIRED') openAccess(); }
}
const ctxBody = () => ({ question: { text: S.current.question.text }, solution: S.current.solution, language: explainLang() });
async function follow(mode, ask) {
  await guarded(t(`act.${{ explain_more: 'explain', simplify: 'simplify', another_method: 'another', study: 'study', practice: 'practice', ask: 'ask' }[mode]}`) + '…', async (card) => {
    const out = await api.followup({ ...ctxBody(), mode, ask }, {});
    card.textContent = '';
    if (mode === 'practice') {
      card.append(el('h3', { text: t('act.practice') }));
      out.result.problems.forEach((p, i) => card.append(el('div', { class: 'practice-item' }, el('strong', { text: `${i + 1}. ` }), rich('span', {}, p.question), p.hint ? el('div', { class: 'small muted' }, rich('span', {}, `${t('practice.hint')}: ${p.hint}`)) : null,
        el('details', {}, el('summary', { text: t('practice.show') }), rich('div', {}, p.answer)))));
      return;
    }
    const res = out.result;
    card.append(el('h3', { text: ask ? ask : res.title || t(`act.${{ explain_more: 'explain', simplify: 'simplify', another_method: 'another', study: 'study', ask: 'ask' }[mode]}`) }));
    res.blocks.forEach((b) => card.append(el('div', {}, b.heading ? el('strong', { text: b.heading }) : null, rich('div', {}, b.text), b.latex ? latexBlock(b.latex) : null)));
    if (res.finalAnswer) card.append(el('div', { class: 'banner ok' }, el('strong', { text: t('result.final') + ': ' }), rich('span', {}, res.finalAnswer.text)));
  });
}
$('ask-form').addEventListener('submit', (e) => { e.preventDefault(); const v = $('ask-input').value.trim(); if (!v) return; $('ask-input').value = ''; follow('ask', v); });

async function toggleTranslate() {
  const r = S.current;
  if (S.showing === 'translated') { S.showing = 'original'; return renderResult(); }
  if (r.translated) { S.showing = 'translated'; return renderResult(); }
  const target = (r.solution.language || 'en').startsWith('ar') ? 'en' : 'ar';
  await guarded(t('act.translate') + '…', async (card) => {
    const out = await api.translate({ solution: r.solution, target }, {});
    r.translated = out.solution; S.showing = 'translated'; card.remove(); await renderResult();
  });
}
async function crossCheck() {
  await guarded(t('act.verify') + '…', async (card) => {
    const r = S.current;
    const out = await api.verify({ ...ctxBody(), question: { text: r.question.text }, solvedBy: r.meta?.provider, crossCheck: true, image: S.image && r.question.hasDiagram ? S.image : undefined }, {});
    r.verification = out; card.remove(); await renderResult();
    const cc = out.checks.find((c) => c.kind === 'cross-provider');
    toast(cc ? t(`crosscheck.${cc.status}`) : t('verify.updated'), 5000);
  });
}

/* ───────────────────────── type / voice ───────────────────────── */
function openType() { $('type-text').value = ''; $('dlg-type').showModal(); $('type-text').focus(); }
$('btn-type').addEventListener('click', openType); $('btn-type2').addEventListener('click', openType);
$('btn-type-cancel').addEventListener('click', () => $('dlg-type').close());
$('type-form').addEventListener('submit', () => { const v = $('type-text').value.trim(); if (v) { S.stack = ['home']; runText(v); } });
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SR) {
  $('btn-voice').hidden = false;
  let rec = null;
  $('btn-voice').addEventListener('click', () => {
    if (rec) { rec.stop(); return; }
    rec = new SR(); rec.lang = meta().speech; rec.interimResults = false;
    rec.onresult = (ev) => { $('type-text').value += (($('type-text').value ? ' ' : '') + ev.results[0][0].transcript); };
    rec.onerror = () => toast(t('toast.voiceFail')); rec.onend = () => { rec = null; $('btn-voice').classList.remove('primary'); };
    $('btn-voice').classList.add('primary'); try { rec.start(); } catch { rec = null; }
  });
}

/* ───────────────────────── history & recent ───────────────────────── */
function renderRecent() {
  const items = listHistory().slice(0, 4), box = $('recent');
  box.hidden = !items.length; const list = $('recent-list'); list.textContent = '';
  for (const it of items) list.append(el('button', { class: 'recent-item', type: 'button', onclick: () => openSaved(it) }, plain(it.solution.question).slice(0, 60), el('small', { text: `${t(`subj.${it.subject}`)} · ${fmtDate(it.ts)}` })));
}
function openSaved(it) {
  S.image = null; S.canvas = null; S.batch = null; S.active = 0;
  S.current = { id: it.id, question: it.question, solution: it.solution, translated: it.translated, meta: it.meta || {}, verification: it.verification || { checks: [], summary: { status: 'unverified' } } };
  renderResult().then(() => { $('followups').textContent = ''; show('result'); });
}
function renderHistory() {
  const q = $('hist-search').value.trim().toLowerCase(), sub = $('hist-subject').value;
  const items = listHistory().filter((it) => (sub === 'auto' || it.subject === sub) && (!q || plain(it.solution.question).toLowerCase().includes(q) || (it.topic || '').toLowerCase().includes(q) || plain(it.solution.finalAnswer.text).toLowerCase().includes(q)));
  const ul = $('hist-list'); ul.textContent = '';
  $('hist-empty').hidden = items.length > 0;
  for (const it of items) ul.append(el('li', { class: 'hist-item' },
    el('button', { class: 'hist-open', type: 'button', onclick: () => openSaved(it) }, el('div', { class: 't', text: plain(it.solution.question) }), el('small', { text: `${t(`subj.${it.subject}`)}${it.topic ? ' · ' + it.topic : ''} · ${fmtDate(it.ts)}` })),
    el('button', { class: 'icon-btn', type: 'button', 'aria-label': t('history.delete'), title: t('history.delete'), onclick: async () => { if (await confirmDialog(t('history.confirmDelete'))) { deleteItem(it.id); renderHistory(); renderRecent(); } } }, (() => { const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); s.innerHTML = '<use href="#i-trash"/>'; return s; })())));
}
$('btn-history').addEventListener('click', () => { renderHistory(); show('history'); });
$('hist-search').addEventListener('input', renderHistory); $('hist-subject').addEventListener('change', renderHistory);
$('btn-hist-clear').addEventListener('click', async () => { if (listHistory().length && await confirmDialog(t('history.confirmClear'))) { clearHistory(); renderHistory(); renderRecent(); } });

/* ───────────────────────── settings ───────────────────────── */
let integ = null;
async function openSettings() {
  const s = getSettings();
  $('set-ui').value = lang(); $('set-explain').value = s.explain; $('set-theme').value = s.theme; $('set-autosave').checked = !!s.autoSave; $('set-access').value = s.accessCode || '';
  $('row-access').hidden = !S.cfg?.accessCodeRequired;
  const f = S.cfg?.features || {};
  $('about-text').textContent = `v${S.cfg?.version || '?'} · ${t('about.ai')}: ${f.ai ? t('yes') : t('no')} · ${t('about.vision')}: ${f.vision ? t('yes') : t('no')} · SymPy: ${f.sympy ? t('yes') : t('no')} · ${t('about.offline')}`;
  show('settings');
  integ ||= await import('./integrations.js');
  integ.renderPublic($('integ-public'), S.cfg?.providers);
  if (!window.__adminBound) {
    window.__adminBound = integ.setupAdmin({ form: $('admin-form'), tokenInput: $('admin-token'), out: $('admin-out'), toast, onChange: async () => { await loadConfig(); integ.renderPublic($('integ-public'), S.cfg?.providers); } });
  }
  window.__adminBound.setRuntimeKeys(S.cfg?.admin?.runtimeKeys);
  window.__adminBound.resume();
}
$('btn-settings').addEventListener('click', openSettings);
$('set-ui').addEventListener('change', async (e) => { saveSettings({ ui: e.target.value }); await setLanguage(e.target.value); fillSubjects(); openSettings(); });
$('set-explain').addEventListener('change', (e) => saveSettings({ explain: e.target.value }));
$('set-theme').addEventListener('change', (e) => { saveSettings({ theme: e.target.value }); const r = document.documentElement; e.target.value === 'system' ? r.removeAttribute('data-theme') : r.setAttribute('data-theme', e.target.value); });
$('set-autosave').addEventListener('change', (e) => saveSettings({ autoSave: e.target.checked }));
$('set-access').addEventListener('change', async (e) => { saveSettings({ accessCode: e.target.value.trim() }); await loadConfig(); });
$('btn-delete-all').addEventListener('click', async () => { if (await confirmDialog(t('settings.confirmDeleteAll'))) { clearAll(); try { const ks = await caches.keys(); await Promise.all(ks.map((k) => caches.delete(k))); } catch { /* ignore */ } toast(t('toast.deleted')); renderRecent(); await setLanguage(lang()); openSettings(); } });
$('subject').addEventListener('change', (e) => saveSettings({ subject: e.target.value }));

/* ───────────────────────── access code ───────────────────────── */
function openAccess() { if (!$('dlg-access').open) { $('access-err').hidden = true; $('dlg-access').showModal(); } }
$('access-form').addEventListener('submit', async (e) => {
  const v = $('access-input').value.trim(); saveSettings({ accessCode: v });
  e.preventDefault();
  await loadConfig();
  if (S.cfg?.authorized) { $('dlg-access').close(); $('access-input').value = ''; fillSubjects(); } else { $('access-err').textContent = t('access.wrong'); $('access-err').hidden = false; }
});

/* ───────────────────────── boot ───────────────────────── */
function fillSubjects() {
  const cur = getSettings().subject || 'auto';
  for (const sel of [$('subject'), $('hist-subject')]) {
    sel.textContent = '';
    for (const id of SUBJECTS) sel.append(el('option', { value: id, text: id === 'auto' ? (sel.id === 'subject' ? t('subj.auto') : t('subj.all')) : t(`subj.${id}`) }));
  }
  $('subject').value = SUBJECTS.includes(cur) ? cur : 'auto';
}
async function loadConfig() {
  try { S.cfg = await api.config(); } catch { S.cfg ||= { offline: true, limits: {}, features: {} }; }
  if (S.cfg.accessCodeRequired && !S.cfg.authorized) openAccess();
}
const updateOnline = () => { $('offline').hidden = navigator.onLine; };
window.addEventListener('online', () => { updateOnline(); loadConfig(); }); window.addEventListener('offline', updateOnline);

(async function init() {
  const s = getSettings();
  await setLanguage(s.ui || ((navigator.language || 'en').startsWith('ar') ? 'ar' : 'en'));
  fillSubjects(); updateOnline(); renderRecent();
  startCamera();
  loadConfig();
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) navigator.serviceWorker.register('/sw.js').catch(() => {});
  window.__snapsolve = { ready: true };
})();
