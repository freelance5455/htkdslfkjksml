// Service worker: caches the app shell so the interface (and local calculator) opens offline.
// It NEVER caches /api/* – solving always needs the network, and answers/photos must not be stored by the worker.
const VERSION = 'snapsolve-v1';
const SHELL = ['/', '/css/app.css', '/js/app.js', '/js/boot.js', '/js/i18n.js', '/js/api.js', '/js/store.js', '/js/render.js', '/js/plot.js', '/js/mathEval.js', '/js/camera.js', '/js/imageproc.js', '/js/crop.js', '/js/integrations.js', '/i18n/en.json', '/i18n/ar.json', '/manifest.webmanifest', '/icon.svg'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => Promise.all(SHELL.map((u) => c.add(u).catch(() => {})))).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== VERSION).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== location.origin || url.pathname.startsWith('/api/')) return;
  // stale-while-revalidate: instant from cache, refreshed in the background
  e.respondWith(caches.open(VERSION).then(async (cache) => {
    const hit = await cache.match(req, { ignoreSearch: true });
    const net = fetch(req).then((res) => { if (res.ok) cache.put(req, res.clone()); return res; }).catch(() => null);
    return hit || (await net) || (req.mode === 'navigate' ? cache.match('/') : Response.error());
  }));
});
