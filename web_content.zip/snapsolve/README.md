# SnapSolve AI

Photograph a question → automatic analysis → step-by-step solution with honest verification.
Mobile-first web app (installable PWA) · Arabic (RTL) + English · dark/light · Node.js backend with **zero npm dependencies**.

```
open app → camera → capture → enhance → read question (vision AI) → solve → check → explain
```

## Quick start

Requires **Node 20.12+** (22 recommended). Python 3 + SymPy are optional (symbolic double-checking).

```bash
cp .env.example .env        # then add at least one provider key (see below)
npm start                   # http://localhost:3000
```

The camera only works on **HTTPS or localhost** (a browser rule). On a phone, deploy behind HTTPS (see *Deployment*).
Without any API key the app still starts: plain arithmetic (`(3+5)*2`, `احسب ٣ × ٤`) and graphs (`y = x^2`) are solved **locally, offline**; everything else tells the user that no AI is configured.

Optional symbolic engine: `pip install sympy` (used to re-solve equations / re-differentiate / re-integrate what the AI claimed).

## Connecting AI providers

Keys live **only on the server** (environment variables). They are never sent to the browser, never logged, and scrubbed from error messages.

| Provider | Env vars | Used for |
|---|---|---|
| Anthropic Claude | `ANTHROPIC_API_KEY`, `ANTHROPIC_MODEL` | vision + text |
| OpenAI | `OPENAI_API_KEY`, `OPENAI_MODEL` | vision + text |
| Google Gemini | `GEMINI_API_KEY`, `GEMINI_MODEL` | vision + text |
| Any OpenAI-compatible endpoint (OpenRouter, Groq, Together, Mistral, vLLM, Ollama…) | `COMPAT_*` | text (vision only if `COMPAT_VISION=true`) |
| OCR.space | `OCR_SPACE_API_KEY` | plain-text OCR fallback only when no vision model exists (user must review the text) |

Model names change; set them in `.env` and press **Test connection** (below) to confirm. Priority order: `PROVIDER_ORDER`, adjustable at runtime.

### Integrations manager
Settings → Integrations lists every provider with its **real** status:
`unconfigured` → `key set – untested` → `connected` (only after a real test or successful request) / `error` / `disabled`.
Set `ADMIN_TOKEN` (16+ chars) to unlock the admin panel: test connection, enable/disable, priority, model, usage/error/latency counters.
`ALLOW_RUNTIME_KEYS=true` additionally lets the admin paste a key (held in server memory only, never returned, lost on restart). Prefer env vars.

## How answers are verified (and what is *not* claimed)

The app never says "verified" unless a check actually ran:

* **Built-in calculator** – plain expressions are computed exactly by software, no AI (badge: *Computed directly by the built-in calculator*).
* **Recomputation** – the model's own arithmetic expression is re-evaluated by our parser.
* **SymPy** – equation solutions are substituted/re-solved; derivatives and antiderivatives are recomputed (needs Python + SymPy; otherwise shown as *skipped*).
* **Second AI** – "Verify with 2nd AI" asks a *different* provider and compares final answers (needs ≥2 providers; `AUTO_CROSS_CHECK=true` does it automatically on hard questions).

Badges: **Passed N automatic checks** / **An automatic check disagrees** / **Not independently verified**. Even "passed" only means the arithmetic/algebra held, not that the photo was read or the problem set up correctly – the UI says so. The model's own "self-check" is displayed but never counted.

## Security & privacy

Server-side API calls only · input validation (type, magic bytes, size, length) · body-size caps · per-IP rate limits (general / AI / admin) · per-provider and global **daily call caps** · timeouts, bounded retries, circuit breaker for rejected credentials · strict CSP, `nosniff`, frame denial, `Permissions-Policy` · path-traversal-safe static server · structured logs containing metadata only (never questions, images or keys) · prompt-injection resistant prompts (question text is delimited data) · SymPy input passes a whitelist parser (no `eval` of raw text).
Photos are processed in memory and **not stored**; only a hash is used for the short in-memory cache. Solutions are saved **only on the user's device** (localStorage) when they tap Save (or enable auto-save). Settings → *Delete all data* wipes it.
Set `ACCESS_CODE` for any public deployment, otherwise strangers can spend your API credit (rate limits and daily caps still apply).

## Tests

```bash
npm test            # 40 unit + API tests (mock providers; no network, no keys needed)
npm run test:e2e    # 18 browser steps – needs Playwright + Chromium installed separately (fake camera, mock model)
```
Covered: camera granted/denied/unavailable · gallery upload · blurry/dark/tilted/cropped images · multiple questions · unreadable photo → retake · Arabic & English · offline · missing/invalid credentials · timeouts, retries, fallback, breaker · duplicate/cached requests · cancellation · rate limits & daily caps · wrong/inconsistent answers flagged · cross-check agree/disagree · secret leakage · injection/traversal · responsive layouts (screenshots).

## Deployment

1. **Docker**: `docker build -t snapsolve . && docker run -d --env-file .env -p 3000:3000 -v snapsolve-data:/app/data snapsolve`
2. **systemd**: `deploy/snapsolve.service`. **HTTPS**: `deploy/Caddyfile` (automatic certificates) or nginx/Cloud Run/Fly – terminate TLS there, then set `TRUST_PROXY=1` and `REQUIRE_HTTPS=true`.
3. Set `ACCESS_CODE`, `ADMIN_TOKEN`, spending limits (`DAILY_REQUEST_LIMIT`, `PROVIDER_DAILY_LIMIT`) and set provider-side spend caps in each provider console.

Rate limits and caches are per process; run one instance or move them to a shared store (e.g. Redis) before scaling horizontally.

## Project layout

```
src/            server.js (routes, security) · providers/ (adapters + registry) · solver/ (prompts, schema, verify, SymPy bridge)
python/         sympy_check.py + safe_expr.py (whitelist parser)
public/         index.html · css · js (app, camera, image processing, crop, KaTeX rendering, plots, i18n) · i18n/*.json · sw.js · vendor/katex
test/           unit.test.js · api.test.js · e2e.mjs
```
Add a language: `public/i18n/<code>.json`, entry in `LANG_META` (`public/js/i18n.js`), `src/solver/langs.js`, `UI_LANGS` in `src/util/validate.js`.

See **docs/STATUS.md** for the exact list of what is tested, configured, unconfigured and not available.
