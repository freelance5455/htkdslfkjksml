import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

dotenv.config();
const app = express();
const PORT = process.env.PORT || 3000;
const MODEL = process.env.OPENAI_MODEL || 'gpt-6-astra';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.resolve(__dirname, '../public');

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '20kb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 12, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use(express.static(publicDir));

app.post('/api/chat', async (req, res) => {
  try {
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) return res.status(503).json({ error: 'Sunucuda OPENAI_API_KEY ayarlanmamış.' });

    const message = typeof req.body?.message === 'string' ? req.body.message.trim().slice(0, 2000) : '';
    if (!message) return res.status(400).json({ error: 'Mesaj boş olamaz.' });

    const rawHistory = Array.isArray(req.body?.history) ? req.body.history.slice(-10) : [];
    const history = rawHistory
      .filter(x => x && ['user', 'assistant'].includes(x.role) && typeof x.content === 'string')
      .map(x => ({ role: x.role, content: x.content.slice(0, 2000) }));

    // Sadece aktivite özeti alınır; GPS koordinatları/rota hiçbir zaman API'ye gönderilmez.
    const a = req.body?.activity || {};
    const activity = {
      steps: Number.isFinite(a.steps) ? Math.max(0, Math.min(100000, Math.round(a.steps))) : 0,
      distanceKm: Number.isFinite(a.distanceKm) ? Math.max(0, Math.min(500, a.distanceKm)) : 0,
      activeMinutes: Number.isFinite(a.activeMinutes) ? Math.max(0, Math.min(1440, Math.round(a.activeMinutes))) : 0,
      savedActivities: Array.isArray(a.savedActivities) ? a.savedActivities.slice(0, 5).map(x => ({
        sport: String(x.sport || 'Aktivite').slice(0, 40),
        minutes: Number.isFinite(x.minutes) ? Math.max(0, Math.min(1440, Math.round(x.minutes))) : 0,
        distanceKm: Number.isFinite(x.distanceKm) ? Math.max(0, Math.min(500, x.distanceKm)) : 0
      })) : []
    };

    const input = [
      ...history,
      { role: 'user', content: `Kullanıcının mesajı: ${message}\n\nSportX günlük aktivite özeti (yaklaşık değerler): ${JSON.stringify(activity)}` }
    ];

    const upstream = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
      body: JSON.stringify({
        model: MODEL,
        instructions: 'Sen SportX uygulamasının yardımcı yapay zekâsısın. Türkçe, anlaşılır, nazik ve kısa yanıt ver. Spor ve günlük hareket konusunda güvenli, dengeli öneriler sun; aşırı egzersiz veya kısıtlayıcı beslenme önerme. Tıbbi teşhis koyma. Aktivite ölçümlerinin yaklaşık olabileceğini belirt. Kullanıcının paylaştığı GPS konumu veya rota bilgisi sende yokmuş gibi davran; konum uydurma. Kullanıcıya her gün hedefi tamamlamak zorunda olmadığını ve dinlenmenin de önemli olduğunu hatırlat.',
        input
      })
    });

    const result = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error('OpenAI API error:', upstream.status, result?.error?.type || 'unknown');
      return res.status(502).json({ error: 'AI servisi şu anda yanıt veremedi. Sunucu ayarlarını ve API kullanım durumunu kontrol et.' });
    }
    const reply = (result.output || []).flatMap(item => item.content || []).filter(part => part.type === 'output_text').map(part => part.text).join('\n').trim();
    if (!reply) return res.status(502).json({ error: 'AI yanıtı alınamadı.' });
    res.json({ reply });
  } catch (error) {
    console.error('Chat endpoint error:', error.message);
    res.status(500).json({ error: 'Sunucuda beklenmeyen bir hata oluştu.' });
  }
});

app.get('/health', (_req, res) => res.json({ ok: true }));
app.listen(PORT, () => console.log(`SportX server listening on ${PORT}`));
