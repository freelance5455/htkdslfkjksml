NEONCHAT Firebase starter
1. Enable Authentication > Sign-in method > Email/Password.
2. Create Firestore Database.
3. Publish firestore.rules in this folder.
4. Put index.html into your HTML-to-APK/WebView builder.
The UI uses username + password. Firebase internally uses username@neonchat.local.
Do not put Admin SDK/private keys in the app.
