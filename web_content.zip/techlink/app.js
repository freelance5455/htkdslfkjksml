const posts = [
  {id:1,user:"Techlink Team",initial:"T",time:"2 h",text:"Bienvenue sur Techlink 🚀 Une plateforme pensée pour connecter les passionnés de technologie, de programmation, d'électronique et de création.",likes:445,comments:72,shares:10,media:true,liked:false},
  {id:2,user:"Code Daily",initial:"C",time:"5 h",text:"Petit défi JavaScript : quelle méthode utiliserais-tu pour transformer un tableau de nombres en un tableau contenant seulement les nombres pairs ?",likes:128,comments:24,shares:7,media:false,liked:false},
  {id:3,user:"Techlink Makers",initial:"M",time:"1 j",text:"Projet du jour : une petite carte électronique contrôlée par microcontrôleur. Partage ton projet avec la communauté ! 🔌",likes:96,comments:13,shares:4,media:true,liked:false}
];

const feed = document.querySelector("#feed");

function renderPosts(){
  feed.innerHTML = posts.map(p=>`
    <article class="post" data-id="${p.id}">
      <div class="post-head">
        <div class="avatar">${p.initial}</div>
        <div class="meta"><b>${p.user}</b><small>${p.time} · 🌐</small></div>
        <button class="more">•••</button>
      </div>
      <div class="post-text">${escapeHTML(p.text)}</div>
      ${p.media ? '<div class="post-media">⚡<span style="font-size:15px;margin-left:8px">TECHLINK</span></div>' : ''}
      <div class="post-stats"><span class="stats-likes">👍 ❤️ ${p.likes}</span><span>${p.comments} commentaires · ${p.shares} partages</span></div>
      <div class="post-actions">
        <button class="like-btn">${p.liked ? "❤️ J’aime" : "👍 J’aime"}</button>
        <button class="comment-btn">💬 Commenter</button>
        <button class="share-btn">↗ Partager</button>
      </div>
      <div class="comment-list">
        ${p.id===1 ? '<div class="comment"><div class="avatar" style="width:32px;height:32px;flex-basis:32px;font-size:12px">K</div><div class="bubble"><b>Kevin</b><br>La plateforme commence vraiment bien ! 🔥<small>J’aime · Répondre</small></div></div>' : ''}
      </div>
      <div class="comment-box"><input placeholder="Commenter en tant que Techlink..."><button class="send-comment">Envoyer</button></div>
    </article>`).join("");
  bindPostEvents();
}

function escapeHTML(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}

function bindPostEvents(){
  document.querySelectorAll(".like-btn").forEach(btn=>btn.onclick=()=>{
    const p=posts.find(x=>x.id==btn.closest(".post").dataset.id);
    p.liked=!p.liked; p.likes += p.liked ? 1 : -1; renderPosts();
  });
  document.querySelectorAll(".comment-btn").forEach(btn=>btn.onclick=()=>{
    btn.closest(".post").querySelector(".comment-box input").focus();
  });
  document.querySelectorAll(".share-btn").forEach(btn=>btn.onclick=()=>{
    const p=posts.find(x=>x.id==btn.closest(".post").dataset.id); p.shares++;
    alert("Publication prête à être partagée !");
    renderPosts();
  });
  document.querySelectorAll(".send-comment").forEach(btn=>btn.onclick=()=>{
    const box=btn.closest(".post"), input=box.querySelector("input"), text=input.value.trim();
    if(!text)return;
    const list=box.querySelector(".comment-list");
    list.insertAdjacentHTML("beforeend",`<div class="comment"><div class="avatar" style="width:32px;height:32px;flex-basis:32px;font-size:12px">A</div><div class="bubble"><b>Toi</b><br>${escapeHTML(text)}<small>À l’instant · J’aime · Répondre</small></div></div>`);
    input.value="";
  });
}
renderPosts();

function openModal(id){document.querySelector(id).classList.remove("hidden")}
function closeModals(){document.querySelectorAll(".modal").forEach(m=>m.classList.add("hidden"))}
document.querySelector("#openComposer").onclick=()=>openModal("#composerModal");
document.querySelector("#createBtn").onclick=()=>openModal("#composerModal");
document.querySelector("#bottomCreate").onclick=()=>openModal("#composerModal");
document.querySelector("#menuBtn").onclick=()=>openModal("#menuModal");
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=closeModals);
document.querySelectorAll(".modal").forEach(m=>m.onclick=e=>{if(e.target===m)closeModals()});

document.querySelector("#publishBtn").onclick=()=>{
  const input=document.querySelector("#postText"), text=input.value.trim();
  if(!text)return;
  posts.unshift({id:Date.now(),user:"Toi",initial:"A",time:"à l'instant",text,likes:0,comments:0,shares:0,media:false,liked:false});
  input.value=""; closeModals(); showPage("home"); renderPosts();
};

document.querySelector("#searchBtn").onclick=()=>{
  document.querySelector("#searchPanel").classList.toggle("hidden");
  document.querySelector("#searchInput").focus();
};
document.querySelector("#searchInput").oninput=e=>{
  const q=e.target.value.toLowerCase();
  document.querySelectorAll(".post").forEach(post=>post.style.display=post.innerText.toLowerCase().includes(q)?"block":"none");
};

function showPage(page){
  document.querySelectorAll(".page").forEach(p=>p.classList.remove("active-page"));
  document.querySelector("#"+page).classList.add("active-page");
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  window.scrollTo({top:0,behavior:"smooth"});
}
document.querySelectorAll("[data-page]").forEach(b=>b.onclick=()=>showPage(b.dataset.page));

document.querySelector("#addStory").onclick=()=>alert("Création de story : sélectionne une photo ou une vidéo dans la prochaine version.");
document.querySelector("#photoBtn").onclick=()=>openModal("#composerModal");
document.querySelector("#modalPhoto").onclick=()=>alert("Ajout de photo : le branchement à un stockage sera ajouté avec le backend.");
document.querySelector("#emojiBtn").onclick=()=>document.querySelector("#postText").value += " 🚀";
