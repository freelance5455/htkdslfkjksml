# Techlink — prototype réseau social

Cette première version contient une interface mobile inspirée de la structure générale montrée dans la vidéo :
- Accueil / fil d'actualité
- Stories
- Création de publication
- Likes, commentaires et partage
- Recherche dans le fil
- Amis
- Messages
- Vidéos
- Notifications
- Techlink Market
- Menu et navigation mobile
- Modales de création

## Lancer
Ouvre simplement `index.html` dans un navigateur.

## Prochaine étape
Pour passer d'un prototype à une vraie application :
1. Frontend React
2. Backend Node.js + Express
3. Base de données
4. Authentification
5. Upload images/vidéos
6. WebSocket pour les messages et notifications
7. API REST pour publications, commentaires, likes et profils
