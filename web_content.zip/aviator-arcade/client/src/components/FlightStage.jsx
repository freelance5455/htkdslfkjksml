import { useMemo } from 'react';
import { Plane, Radio, UsersRound } from 'lucide-react';

const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

export function formatPoints(value) {
  return new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 }).format(Number(value || 0));
}
export function formatMultiplier(value) {
  return `${Number(value || 1).toFixed(2)}x`;
}

export default function FlightStage({ round, connected }) {
  const running = round?.status === 'RUNNING';
  const crashed = ['CRASHED', 'RESULT'].includes(round?.status);
  const waiting = !round?.roundId || round?.status === 'WAITING';
  const progress = useMemo(() => Math.pow(clamp(Math.log(Math.max(1, round?.multiplier || 1)) / Math.log(8), 0, 1), 1.45) * 100, [round?.multiplier]);
  const planeX = 12 + progress * 0.72;
  const planeY = 70 - progress * 0.50;
  const statusText = round?.maintenance ? 'MAINTENANCE' : crashed ? 'ROUND CRASHED' : running ? 'IN FLIGHT' : round?.status === 'COUNTDOWN' ? 'NEXT FLIGHT' : 'PREPARING';

  return (
    <section className={`flight-stage ${running ? 'is-running' : ''} ${crashed ? 'is-crashed' : ''}`}>
      <div className="stage-vignette"/><div className="stage-grain"/>
      <div className="stage-topline">
        <div className="round-label"><span className={`status-pulse ${running ? 'live' : crashed ? 'crash' : ''}`}/><span>{statusText}</span></div>
        <div className="stage-live"><span className={`connection-dot ${connected ? 'online' : 'offline'}`}/>{connected ? 'LIVE SYNC' : 'RECONNECTING'}</div>
      </div>
      <div className="stage-copy"><span className="stage-round">ROUND <b>{round?.roundId || 'CONNECTING…'}</b></span><span className="round-player-count"><UsersRound size={14}/>{round?.playerCount || 0} pilots</span></div>
      <div className="flight-sky">
        <div className="sky-grid"/><div className="sky-stars star-one"/><div className="sky-stars star-two"/><div className="sky-stars star-three"/>
        <div className="sky-orbit orbit-left"/><div className="sky-orbit orbit-right"/>
        <div className="flight-route route-one"/><div className="flight-route route-two"/>
        <div className={`multiplier-display ${crashed ? 'crashed' : running ? 'live' : ''}`} key={round?.roundId || 'idle'}>
          <span className="multiplier-kicker">{round?.status === 'COUNTDOWN' ? 'TAKEOFF IN' : running ? 'CURRENT MULTIPLIER' : crashed ? 'FINAL MULTIPLIER' : 'CURRENT MULTIPLIER'}</span>
          <strong className={round?.status === 'COUNTDOWN' ? 'countdown-number' : ''}>{round?.status === 'COUNTDOWN' ? (round.countdown ?? 'GO') : crashed ? formatMultiplier(round?.crashMultiplier || round?.multiplier) : formatMultiplier(round?.multiplier || 1)}</strong>
          {running && <span className="multiplier-glint"/>}
          {crashed && <span className="crash-stamp">FLIGHT ENDED</span>}
          {round?.status === 'COUNTDOWN' && <span className="waiting-multiplier">SECURE YOUR PLAY BEFORE TAKEOFF</span>}
          {waiting && <span className="waiting-multiplier">READY FOR TAKEOFF</span>}
        </div>
        <div className={`flight-path ${running ? 'moving' : ''}`} style={{ left: `${planeX}%`, top: `${planeY}%` }}>
          <div className="plane-trail"/><div className="plane-halo"/>
          <svg className="plane-svg" viewBox="0 0 80 52" fill="none" aria-label="Animated aircraft"><path d="M4 27.8 72.9 8.9c2.7-.8 4.7 1.9 3.1 4.2L61.8 31.6c-1 1.3-2.7 1.7-4.2 1.1L45.1 28l-9.8 16c-1 1.6-3.3 1.2-3.7-.7l-2.4-11.1-23.8 2.9c-2.6.3-3.4-4.2-.8-5.3Z" fill="url(#aircraftFill)"/><path d="m30 32.1 26.7-9.8" stroke="#fff" strokeWidth="1.8" strokeOpacity=".7"/><defs><linearGradient id="aircraftFill" x1="6" x2="72" y1="48" y2="9" gradientUnits="userSpaceOnUse"><stop stopColor="#827aff"/><stop offset="1" stopColor="#ff916b"/></linearGradient></defs></svg>
        </div>
        <div className="stage-landscape" aria-hidden="true"><span/><span/><span/><span/><span/><span/><span/><span/><span/><span/><span/><span/><span/><span/><span/></div>
      </div>
      <div className="stage-footer">
        <div className="stage-footer-label"><span className={`tiny-signal ${connected ? 'signal-live' : ''}`}><Radio size={13}/></span><span>{round?.maintenance ? 'Arcade maintenance' : running ? 'Multiplier rising live' : round?.status === 'COUNTDOWN' ? 'Launch sequence' : crashed ? 'Round complete' : 'Waiting for next flight'}</span></div>
        <div className="stage-footer-stat"><Plane size={14}/><span>Server synced</span></div>
      </div>
    </section>
  );
}
