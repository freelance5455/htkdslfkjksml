import { ArrowDownRight, ArrowUpRight, CircleDashed, Clock3, Plane, ShieldCheck } from 'lucide-react';
import { formatMultiplier, formatPoints } from './FlightStage';

export default function HistoryPanel({ history, period, setPeriod, loading = false, compact = false }) {
  const periods = [{ id: 'today', label: 'Today' }, { id: '7d', label: '7 days' }, { id: '30d', label: '30 days' }];
  return (
    <section className={`panel history-panel ${compact ? 'compact-history' : ''}`}>
      <div className="panel-heading history-heading">
        <div><p className="section-kicker">FLIGHT LOG</p><h2>Round history</h2></div>
        <div className="segmented">{periods.map((item) => <button key={item.id} className={period === item.id ? 'selected' : ''} onClick={() => setPeriod(item.id)}>{item.label}</button>)}</div>
      </div>
      {loading ? <div className="skeleton-list"><span/><span/><span/></div> : !history?.length ? <div className="empty-state"><span className="empty-icon"><CircleDashed size={20}/></span><strong>No flights in this period</strong><small>Your completed rounds will show up here.</small></div> : (
        <div className="table-scroll"><table className="data-table history-table"><thead><tr><th>Round</th><th>Time</th><th>Multiplier</th><th>Action</th><th>Points used</th><th>Points collected</th><th>Result</th></tr></thead><tbody>
          {history.map((entry) => <tr key={entry.id || `${entry.roundId}-${entry.createdAt}`}>
            <td><span className="round-code">{entry.roundId}</span></td>
            <td className="muted-cell"><Clock3 size={13}/>{new Date(entry.createdAt || entry.roundDate).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</td>
            <td><strong className={entry.result === 'COLLECTED' ? 'value-mint' : entry.result === 'CRASHED' ? 'value-coral' : ''}>{entry.finalMultiplier ? formatMultiplier(entry.finalMultiplier) : '—'}</strong></td>
            <td><span className="action-chip"><Plane size={12}/>{entry.action || 'PLAY'}</span></td>
            <td>{formatPoints(entry.pointsUsed)} <small>pts</small></td>
            <td>{entry.pointsCollected ? <span className="value-mint">+{formatPoints(entry.pointsCollected)} <small>pts</small></span> : <span className="muted-cell">—</span>}</td>
            <td><span className={`result-pill ${String(entry.result || 'PENDING').toLowerCase()}`}>{entry.result === 'COLLECTED' ? <ArrowUpRight size={12}/> : entry.result === 'CRASHED' ? <ArrowDownRight size={12}/> : <ShieldCheck size={12}/>} {entry.result || 'PENDING'}</span></td>
          </tr>)}
        </tbody></table></div>
      )}
      <div className="table-footnote"><ShieldCheck size={13}/> All activity is recorded in virtual points only.</div>
    </section>
  );
}
