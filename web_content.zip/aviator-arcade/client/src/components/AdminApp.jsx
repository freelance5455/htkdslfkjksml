import { useCallback, useEffect, useMemo, useState } from 'react';
import { Activity, ArrowDown, ArrowRight, ArrowUp, BarChart3, Bell, Check, ChevronDown, ChevronLeft, ChevronRight, CircleAlert, CircleHelp, Clock3, Download, Gauge, Gamepad2, History, LayoutDashboard, LockKeyhole, LogOut, Menu, MoreHorizontal, Search, Settings, Shield, ShieldAlert, ShieldCheck, SlidersHorizontal, Sparkles, TerminalSquare, Users, UserRound, X, Zap } from 'lucide-react';
import { api, connectToArcade } from '../lib/api';
import { formatMultiplier, formatPoints } from './FlightStage';

const adminNav = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'users', label: 'Users', icon: Users },
  { id: 'games', label: 'Game management', icon: Gamepad2 },
  { id: 'history', label: 'Round history', icon: History },
  { id: 'reports', label: 'Reports', icon: BarChart3 },
  { id: 'settings', label: 'Settings', icon: Settings },
  { id: 'activity', label: 'Activity logs', icon: TerminalSquare }
];

function StatusPill({ active, children }) { return <span className={`admin-status ${active ? 'status-active' : 'status-muted'}`}><i/>{children}</span>; }
function AdminToast({ toast, dismiss }) { if (!toast) return null; return <div className={`toast toast-${toast.kind || 'success'}`}><span>{toast.kind === 'error' ? '!' : '✓'}</span><div>{toast.message}</div><button onClick={dismiss}><X size={15}/></button></div>; }
function downloadCsv(name, rows) {
  if (!rows?.length) return;
  const columns = Object.keys(rows[0]);
  const csv = [columns.join(','), ...rows.map((row) => columns.map((column) => `"${String(row[column] ?? '').replaceAll('"', '""')}"`).join(','))].join('\n');
  const href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  const anchor = document.createElement('a'); anchor.href = href; anchor.download = name; anchor.click(); URL.revokeObjectURL(href);
}
function MiniBar({ data }) {
  const values = data?.map((row) => Number(row.games || 0)) || [];
  const max = Math.max(1, ...values);
  return <div className="mini-chart" role="img" aria-label="Games per day chart">{data?.length ? data.map((row, i) => <div className="chart-column" key={row.day || i}><div className="chart-bar-wrap"><i style={{ height: `${Math.max(5, (Number(row.games || 0) / max) * 100)}%` }}/></div><small>{new Date(row.day).toLocaleDateString([], { weekday: 'short' })}</small></div>) : <div className="chart-empty">Report data will appear here after rounds are played.</div>}</div>;
}
function StatCard({ label, value, note, icon: Icon, color = 'violet' }) { return <div className={`admin-stat-card admin-${color}`}><div className="admin-stat-head"><span>{label}</span><i>{Icon && <Icon size={16}/>}</i></div><strong>{value}</strong><small>{note}</small></div>; }

function AdminLogin({ onSuccess, onDemo }) {
  const [username, setUsername] = useState(''); const [password, setPassword] = useState(''); const [pending, setPending] = useState(''); const [error, setError] = useState('');
  async function login(event) {
    event.preventDefault(); setPending('login'); setError('');
    try { const result = await api('/admin/login', { method: 'POST', body: { username, password } }); onSuccess(result.admin); }
    catch (err) { setError(err.message); } finally { setPending(''); }
  }
  async function demo() { setPending('demo'); setError(''); try { const result = await api('/admin/demo-session', { method: 'POST', body: {} }); onSuccess(result.admin); } catch (err) { setError(err.message); } finally { setPending(''); } }
  return <main className="admin-login-screen"><div className="admin-login-glow"/><a href="/" className="brand-lockup"><span className="brand-mark"><Shield size={17}/></span><span><strong>SKYLINE</strong><small>ADMIN CONSOLE</small></span></a><section className="admin-login-card panel"><span className="admin-login-icon"><ShieldCheck size={22}/></span><p className="section-kicker">RESTRICTED ACCESS</p><h1>Admin sign in</h1><p>Use your private administrator credentials to manage the sandbox.</p><form onSubmit={login}><label className="field-label">Admin username</label><div className="input-wrap"><UserRound size={16}/><input autoComplete="username" required value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Enter admin username"/></div><label className="field-label">Password</label><div className="input-wrap"><LockKeyhole size={16}/><input type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter password"/></div>{error && <div className="form-error" role="alert">{error}</div>}<button className="button button-primary auth-submit" disabled={Boolean(pending)}>{pending === 'login' ? <><span className="spinner"/> Verifying…</> : <>Secure sign in <ArrowRight size={16}/></>}</button></form><div className="admin-login-foot"><ShieldAlert size={14}/> Passwords are hashed server-side. Admin actions are audit logged.</div><button className="admin-demo-button" onClick={demo} disabled={Boolean(pending)}>{pending === 'demo' ? <span className="spinner"/> : 'Open local demo preview'}</button><a className="back-home" href="/">← Back to Skyline Arcade</a></section><span className="admin-login-safe">PLAY-MONEY SANDBOX · NO PAYMENTS · NO CASH VALUE</span></main>;
}

export default function AdminApp({ initialAdmin }) {
  const [admin, setAdmin] = useState(initialAdmin);
  const [checking, setChecking] = useState(!initialAdmin);
  const [page, setPage] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [toast, setToast] = useState(null);
  const [dashboard, setDashboard] = useState(null);
  const [users, setUsers] = useState([]);
  const [games, setGames] = useState([]);
  const [reports, setReports] = useState([]);
  const [activity, setActivity] = useState([]);
  const [settings, setSettings] = useState({ maintenanceMode: false, countdownSeconds: 3, minStake: 50, maxStake: 5000 });
  const [reportPeriod, setReportPeriod] = useState('7d');
  const [userSearch, setUserSearch] = useState('');
  const [selectedUser, setSelectedUser] = useState(null);
  const [detail, setDetail] = useState(null);
  const [connection, setConnection] = useState(false);
  const [loading, setLoading] = useState(false);
  const [settingsBusy, setSettingsBusy] = useState(false);
  const [passwordForm, setPasswordForm] = useState({ currentPassword: '', newPassword: '' });
  const [isDemo, setIsDemo] = useState(Boolean(initialAdmin?.demo || initialAdmin?.id === 'demo-admin'));

  const notify = useCallback((message, kind = 'success') => { setToast({ message, kind }); window.clearTimeout(window.__adminToast); window.__adminToast = window.setTimeout(() => setToast(null), 3500); }, []);
  const loadPageData = useCallback(async (target = page) => {
    if (!admin) return;
    setLoading(true);
    try {
      if (target === 'dashboard') {
        const [result, activityResult] = await Promise.all([api('/admin/dashboard'), api('/admin/activity')]); setDashboard(result); setSettings((current) => result.settings || current); setActivity(activityResult.activity || []);
      } else if (target === 'users') {
        const result = await api(`/admin/users?search=${encodeURIComponent(userSearch)}`); setUsers(result.users || []);
      } else if (target === 'games' || target === 'history') {
        const result = await api('/admin/games'); setGames(result.rounds || []); setDashboard((previous) => ({ ...(previous || {}), stats: { ...(previous?.stats || {}), currentRound: result.current } }));
      } else if (target === 'reports') {
        const result = await api(`/admin/reports?period=${reportPeriod}`); setReports(result.reports || []);
      } else if (target === 'activity') {
        const result = await api('/admin/activity'); setActivity(result.activity || []);
      } else if (target === 'settings') {
        const result = await api('/admin/settings'); setSettings((current) => result.settings || current);
      }
    } catch (error) { if (error.status === 401) { setAdmin(null); } else notify(error.message, 'error'); }
    finally { setLoading(false); }
  }, [admin, page, userSearch, reportPeriod, notify]);

  useEffect(() => {
    if (initialAdmin) { setAdmin(initialAdmin); setChecking(false); return; }
    api('/admin/me').then((result) => { setAdmin(result.admin || null); setIsDemo(Boolean(result.admin?.demo)); }).catch(() => setAdmin(null)).finally(() => setChecking(false));
  }, [initialAdmin]);
  useEffect(() => { if (admin) loadPageData(page); }, [admin, page, reportPeriod, loadPageData]);
  useEffect(() => {
    if (!admin) return;
    const socket = connectToArcade();
    const update = (state) => setDashboard((previous) => ({ ...(previous || {}), stats: { ...(previous?.stats || {}), currentRound: state } }));
    socket.on('connect', () => setConnection(true)); socket.on('disconnect', () => setConnection(false)); socket.on('round:sync', update); socket.on('round:waiting', update); socket.on('round:countdown', update); socket.on('round:started', update); socket.on('round:crashed', update); socket.on('round:result', update);
    socket.on('round:multiplier', (payload) => setDashboard((previous) => ({ ...(previous || {}), stats: { ...(previous?.stats || {}), currentRound: { ...(previous?.stats?.currentRound || {}), ...payload, status: 'RUNNING' } } })));
    return () => socket.disconnect();
  }, [admin]);

  async function loadUser(id) {
    setSelectedUser(id);
    try { const result = await api(`/admin/users/${id}`); setDetail(result); }
    catch (error) { notify(error.message, 'error'); setSelectedUser(null); }
  }
  async function toggleUser(user) {
    try {
      const result = await api(`/admin/users/${user.id}/status`, { method: 'PATCH', body: { active: !user.active } });
      setUsers((current) => current.map((item) => item.id === user.id ? { ...item, active: result.active } : item));
      notify(result.active ? `${user.username} activated.` : `${user.username} deactivated.`);
    } catch (error) { notify(error.message, 'error'); }
  }
  async function logoutAllUser(user) {
    try { await api(`/admin/users/${user.id}/logout-all`, { method: 'POST', body: {} }); notify(`All sessions for ${user.username} were revoked.`); }
    catch (error) { notify(error.message, 'error'); }
  }
  async function saveSettings(event) {
    event?.preventDefault(); setSettingsBusy(true);
    try {
      const result = await api('/admin/settings', { method: 'PATCH', body: settings }); setSettings(result.settings); notify('Game settings saved.');
    } catch (error) { notify(error.message, 'error'); } finally { setSettingsBusy(false); }
  }
  async function changePassword(event) {
    event.preventDefault(); setSettingsBusy(true);
    try { const result = await api('/admin/security/change-password', { method: 'POST', body: passwordForm }); notify(result.message || 'Password updated.'); setPasswordForm({ currentPassword: '', newPassword: '' }); await logout(); }
    catch (error) { notify(error.message, 'error'); } finally { setSettingsBusy(false); }
  }
  async function logout() {
    try { await api('/admin/logout', { method: 'POST', body: {} }); } catch { /* revoke local view */ }
    setAdmin(null); setIsDemo(false); window.location.href = '/';
  }
  function selectPage(next) { setPage(next); setSidebarOpen(false); }
  if (checking) return <div className="app-loader"><div className="loader-mark">✦</div><span>Verifying admin session…</span></div>;
  if (!admin) return <AdminLogin onSuccess={(value) => { setAdmin(value); setIsDemo(value.id === 'demo-admin'); }} onDemo={(value) => setAdmin(value)}/>;

  const currentRound = dashboard?.stats?.currentRound || { status: 'WAITING', multiplier: 1, roundId: 'Syncing…', playerCount: 0 };
  const completedRounds = games.filter((round) => ['CRASHED', 'RESULT'].includes(round.status));
  const exportHistory = () => downloadCsv('skyline-round-history.csv', games.map((row) => ({ round_id: row.roundId, status: row.status, final_multiplier: row.crashMultiplier ?? '', started_at: row.startedAt || '', ended_at: row.endedAt || '' })));

  return (
    <div className="admin-shell">
      <aside className={`admin-sidebar ${sidebarOpen ? 'drawer-open' : ''}`}>
        <div className="admin-brand-row"><a href="/" className="brand-lockup"><span className="brand-mark"><Shield size={16}/></span><span><strong>SKYLINE</strong><small>ADMIN CONSOLE</small></span></a><button className="mobile-close" onClick={() => setSidebarOpen(false)}><X size={19}/></button></div>
        <div className="admin-workspace"><span className="workspace-dot"/><div><small>WORKSPACE</small><strong>Arcade Sandbox</strong></div><ChevronDown size={14}/></div>
        <span className="sidebar-caption">CONTROL ROOM</span>
        <nav className="admin-nav">{adminNav.map(({ id, label, icon: Icon }) => <button key={id} className={`admin-nav-link ${page === id ? 'active' : ''}`} onClick={() => selectPage(id)}><Icon size={17}/><span>{label}</span>{id === 'activity' && <small className="nav-count">{activity.length || '•'}</small>}</button>)}</nav>
        <div className="admin-sidebar-bottom"><div className="admin-session-card"><span className="admin-session-icon"><ShieldCheck size={15}/></span><div><strong>{isDemo ? 'Preview session' : 'Secure session'}</strong><small>{isDemo ? 'Demo-only controls' : 'Admin authenticated'}</small></div><i className="session-online"/></div><button className="admin-nav-link admin-signout" onClick={logout}><LogOut size={17}/><span>Sign out</span></button><div className="admin-version">SKYLINE ADMIN · 1.0.0</div></div>
      </aside>
      {sidebarOpen && <button aria-label="Close navigation" className="drawer-scrim" onClick={() => setSidebarOpen(false)}/>}
      <div className="admin-main-wrap">
        <header className="admin-topbar"><button className="admin-menu-button" onClick={() => setSidebarOpen(true)} aria-label="Open navigation"><Menu size={20}/></button><div className="admin-breadcrumb"><span>CONTROL ROOM</span><ChevronRight size={14}/><strong>{adminNav.find((item) => item.id === page)?.label}</strong></div><div className="admin-top-actions"><span className={`admin-live-status ${connection ? 'connected' : ''}`}><i/>{connection ? 'Live' : 'Connecting'}</span>{isDemo && <span className="admin-demo-chip"><Sparkles size={12}/> DEMO</span>}<div className="admin-user-chip"><span className="admin-avatar"><ShieldCheck size={15}/></span><span><strong>{admin.username}</strong><small>{admin.role}</small></span></div></div></header>
        <main className="admin-content">
          {page === 'dashboard' && <>
            <div className="admin-page-heading"><div><p className="section-kicker">OVERVIEW / CONTROL ROOM</p><h1>Good day, <span>{admin.username}</span></h1><p>Monitor the virtual arcade at a glance.</p></div><div className="admin-date-chip"><Clock3 size={14}/>{new Date().toLocaleDateString([], { weekday: 'long', month: 'short', day: 'numeric' })}</div></div>
            <div className="admin-stat-grid"><StatCard label="TOTAL USERS" value={formatPoints(dashboard?.stats?.totalUsers || 0)} note={`${formatPoints(dashboard?.stats?.enabledUsers || 0)} accounts active`} icon={Users} color="violet"/><StatCard label="ACTIVE USERS" value={formatPoints(dashboard?.stats?.activeUsers || 0)} note="Last 15 minutes" icon={Activity} color="green"/><StatCard label="CURRENT ROUND" value={currentRound.roundId || '—'} note={currentRound.status || 'WAITING'} icon={Zap} color="coral"/><StatCard label="COMPLETED ROUNDS" value={formatPoints(dashboard?.stats?.completedRounds || 0)} note={`${formatPoints(dashboard?.stats?.totalGames || 0)} player sessions`} icon={Gamepad2} color="blue"/></div>
            <div className="admin-dash-grid"><section className="panel admin-live-card"><div className="panel-heading"><div><p className="section-kicker">REAL-TIME ENGINE</p><h2>Current flight</h2></div><StatusPill active={!settings.maintenanceMode}>{settings.maintenanceMode ? 'Maintenance' : 'System online'}</StatusPill></div><div className="admin-round-display"><div><small>ROUND ID</small><strong>{currentRound.roundId || '—'}</strong></div><div className="round-live-mult"><small>LIVE MULTIPLIER</small><strong className={currentRound.status === 'RUNNING' ? 'value-mint' : currentRound.status === 'CRASHED' ? 'value-coral' : ''}>{formatMultiplier(currentRound.crashMultiplier || currentRound.multiplier)}</strong></div></div><div className="admin-round-progress"><i style={{ width: `${Math.min(100, Math.max(7, Math.log(Math.max(1, currentRound.multiplier || 1)) / Math.log(8) * 100))}%` }}/></div><div className="admin-round-meta"><span><i className="tiny-green-dot"/> {currentRound.status}</span><span><Users size={13}/>{currentRound.playerCount || 0} players</span><span>Round is server-authoritative</span></div><div className="admin-live-foot"><span><ShieldCheck size={14}/> Crash result is generated server-side.</span><button onClick={() => selectPage('games')}>Open game monitor <ArrowRight size={14}/></button></div></section>
              <section className="panel admin-activity-card"><div className="panel-heading"><div><p className="section-kicker">AUDIT TRAIL</p><h2>Latest activity</h2></div><button className="icon-button" onClick={() => selectPage('activity')}><ArrowRight size={15}/></button></div>{activity.slice(0, 5).length ? <div className="admin-recent-activity">{activity.slice(0, 5).map((item) => <div className="recent-activity-row" key={item.id}><span className={`activity-dot ${item.actorType?.toLowerCase() || 'system'}`}/><div><strong>{item.action.replaceAll('.', ' · ')}</strong><small>{item.actorType} {item.actorId ? `· ${String(item.actorId).slice(0, 8)}` : ''}</small></div><time>{new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</time></div>)}</div> : <div className="admin-activity-empty"><Activity size={18}/><span>Recent admin and user activity appears here.</span></div>}<button className="admin-text-link" onClick={() => selectPage('activity')}>View all activity <ArrowRight size={14}/></button></section></div>
            <section className="panel admin-rounds-table"><div className="panel-heading"><div><p className="section-kicker">ROUND MONITOR</p><h2>Recent rounds</h2></div><button className="button button-quiet" onClick={() => selectPage('history')}>View history <ArrowRight size={14}/></button></div><RoundTable rounds={(dashboard?.rounds || []).slice(0, 6)}/></section>
          </>}
          {page === 'users' && <>
            <div className="admin-page-heading"><div><p className="section-kicker">USER MANAGEMENT</p><h1>Know your <span>pilots.</span></h1><p>Review profiles, account status, and virtual-point history.</p></div><div className="admin-heading-count"><strong>{users.length}</strong><small>accounts listed</small></div></div>
            <section className="panel admin-table-panel"><div className="admin-table-toolbar"><div><h2>All users</h2><span>{users.length} accounts in view</span></div><div className="admin-search"><Search size={15}/><input value={userSearch} onChange={(e) => setUserSearch(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && loadPageData('users')} placeholder="Search username…"/><button onClick={() => loadPageData('users')}>Search</button></div></div><div className="table-scroll"><table className="data-table admin-users-table"><thead><tr><th>PILOT</th><th>VIRTUAL POINTS</th><th>GAMES</th><th>SUCCESSFUL</th><th>BEST MULTIPLIER</th><th>STATUS</th><th>ACTIONS</th></tr></thead><tbody>{users.map((user) => <tr key={user.id}><td><button className="user-row-button" onClick={() => loadUser(user.id)}><span className="avatar">{user.avatar || '✦'}</span><span><strong>{user.username}</strong><small>Joined {new Date(user.createdAt).toLocaleDateString()}</small></span></button></td><td><strong>{formatPoints(user.points)}</strong><small> PTS</small></td><td>{formatPoints(user.gamesPlayed)}</td><td>{formatPoints(user.successfulRounds)}</td><td className="leader-best">{formatMultiplier(user.bestMultiplier || 1)}</td><td><StatusPill active={user.active}>{user.active ? 'Active' : 'Paused'}</StatusPill></td><td><div className="row-actions"><button title="View profile" onClick={() => loadUser(user.id)}><UserRound size={14}/></button><button title={user.active ? 'Deactivate account' : 'Activate account'} onClick={() => toggleUser(user)}>{user.active ? <ShieldAlert size={14}/> : <ShieldCheck size={14}/>}</button><button title="Log out all sessions" onClick={() => logoutAllUser(user)}><LogOut size={14}/></button></div></td></tr>)}</tbody></table>{!users.length && <div className="empty-state"><strong>No users found</strong><small>Try a different search.</small></div>}</div><div className="admin-table-foot"><ShieldCheck size={13}/> Account controls change access only. Points remain virtual and non-transferable.</div></section>
          </>}
          {page === 'games' && <>
            <div className="admin-page-heading"><div><p className="section-kicker">GAME MANAGEMENT</p><h1>Watch the <span>engine.</span></h1><p>Live round status and server-generated outcomes.</p></div><StatusPill active={!settings.maintenanceMode}>{settings.maintenanceMode ? 'Maintenance mode' : 'System operational'}</StatusPill></div>
            <div className="game-monitor-grid"><section className="panel monitor-live"><div className="panel-heading"><div><p className="section-kicker">LIVE ROUND MONITOR</p><h2>Current round</h2></div><span className="monitor-signal"><i/> LIVE SYNC</span></div><div className="monitor-round-id">{currentRound.roundId || 'Awaiting round…'}</div><div className={`monitor-multiplier ${currentRound.status === 'RUNNING' ? 'live' : currentRound.status === 'CRASHED' ? 'crashed' : ''}`}>{formatMultiplier(currentRound.crashMultiplier || currentRound.multiplier)}</div><div className="monitor-round-info"><div><small>ROUND STATUS</small><strong>{currentRound.status || 'WAITING'}</strong></div><div><small>PLAYERS</small><strong>{currentRound.playerCount || 0}</strong></div><div><small>STARTED</small><strong>{currentRound.startedAt ? new Date(currentRound.startedAt).toLocaleTimeString() : '—'}</strong></div></div><div className="monitor-note"><ShieldCheck size={15}/><span>Crash multiplier is private until the server emits a crash event.</span></div></section><section className="panel monitor-system"><div className="panel-heading"><div><p className="section-kicker">SYSTEM STATUS</p><h2>Runtime health</h2></div><span className="system-pulse"><i/></span></div><div className="system-list"><div><span>Game engine</span><strong><i className="tiny-green-dot"/> Running</strong></div><div><span>Round sync</span><strong><i className={`tiny-${connection ? 'green' : 'amber'}-dot`}/>{connection ? 'Connected' : 'Reconnecting'}</strong></div><div><span>Virtual point ledger</span><strong><i className="tiny-green-dot"/> Active</strong></div><div><span>Maintenance mode</span><strong>{settings.maintenanceMode ? 'On' : 'Off'}</strong></div></div><button className="button button-quiet full-button" onClick={() => selectPage('settings')}>Configure system <ArrowRight size={14}/></button></section></div>
            <section className="panel admin-table-panel"><div className="admin-table-toolbar"><div><h2>Recent rounds</h2><span>History generated by the server</span></div><button className="button button-quiet" onClick={() => loadPageData('games')}><Zap size={14}/> Refresh</button></div><div className="table-scroll"><RoundTable rounds={games.slice(0, 20)}/></div></section>
          </>}
          {page === 'history' && <>
            <div className="admin-page-heading"><div><p className="section-kicker">ROUND ARCHIVE</p><h1>Past flights, <span>fully logged.</span></h1><p>Round IDs, timestamps, and final server results.</p></div><button className="button button-quiet" onClick={exportHistory}><Download size={15}/> Export CSV</button></div>
            <section className="panel admin-table-panel"><div className="admin-table-toolbar"><div><h2>Round history</h2><span>{completedRounds.length} completed rounds</span></div><div className="history-total-chip"><History size={14}/>{games.length} total rounds</div></div><div className="table-scroll"><RoundTable rounds={games}/></div><div className="admin-table-foot"><ShieldCheck size={13}/> Round outcomes are controlled by the server and cannot be edited from the client.</div></section>
          </>}
          {page === 'reports' && <>
            <div className="admin-page-heading"><div><p className="section-kicker">ANALYTICS</p><h1>Activity at a <span>glance.</span></h1><p>Virtual game activity only. No financial reporting or monetary value.</p></div><button className="button button-quiet" onClick={() => downloadCsv('skyline-activity-report.csv', reports.map((row) => ({ day: new Date(row.day).toISOString().slice(0, 10), games: row.games, successful: row.successful, users: row.users, points_used: row.pointsUsed, points_collected: row.pointsCollected })))}><Download size={15}/> Export report</button></div>
            <div className="report-toolbar"><div className="report-filter-label"><SlidersHorizontal size={15}/> REPORT WINDOW</div><div className="segmented">{[{ id: 'today', label: 'Today' }, { id: '7d', label: '7 days' }, { id: '30d', label: '30 days' }].map((item) => <button key={item.id} className={reportPeriod === item.id ? 'selected' : ''} onClick={() => setReportPeriod(item.id)}>{item.label}</button>)}</div></div>
            <div className="report-metric-grid"><StatCard label="GAMES PLAYED" value={formatPoints(reports.reduce((a, r) => a + Number(r.games || 0), 0))} note="Selected period" icon={Gamepad2} color="violet"/><StatCard label="SUCCESSFUL COLLECTS" value={formatPoints(reports.reduce((a, r) => a + Number(r.successful || 0), 0))} note="Virtual rounds" icon={ArrowUp} color="green"/><StatCard label="UNIQUE PILOTS" value={formatPoints(reports.reduce((a, r) => a + Number(r.users || 0), 0))} note="Daily unique counts" icon={Users} color="blue"/><StatCard label="POINTS COLLECTED" value={formatPoints(reports.reduce((a, r) => a + Number(r.pointsCollected || 0), 0))} note="Virtual points only" icon={Zap} color="coral"/></div>
            <section className="panel report-chart-panel"><div className="panel-heading"><div><p className="section-kicker">DAILY GAME ACTIVITY</p><h2>Rounds played</h2></div><span className="report-key"><i/> Games per day</span></div><MiniBar data={reports}/></section>
            <section className="panel admin-table-panel"><div className="admin-table-toolbar"><div><h2>Daily breakdown</h2><span>Aggregated virtual play</span></div></div><div className="table-scroll"><table className="data-table"><thead><tr><th>DATE</th><th>GAMES</th><th>COLLECTED</th><th>UNIQUE PILOTS</th><th>POINTS PLAYED</th><th>POINTS COLLECTED</th></tr></thead><tbody>{reports.map((row, i) => <tr key={row.day || i}><td>{new Date(row.day).toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' })}</td><td>{row.games}</td><td className="value-mint">{row.successful}</td><td>{row.users}</td><td>{formatPoints(row.pointsUsed)}</td><td>{formatPoints(row.pointsCollected)}</td></tr>)}</tbody></table>{!reports.length && <div className="empty-state"><strong>No report data yet</strong><small>Play activity appears after completed rounds.</small></div>}</div></section>
          </>}
          {page === 'settings' && <>
            <div className="admin-page-heading"><div><p className="section-kicker">SYSTEM CONFIGURATION</p><h1>Keep the arcade <span>in tune.</span></h1><p>Game controls, maintenance, and admin security.</p></div><span className="settings-live-chip"><i className="tiny-green-dot"/> Changes apply server-side</span></div>
            {isDemo && <div className="demo-warning"><Sparkles size={16}/><span><strong>Local preview session.</strong> Settings affect this temporary demo only. Production admin sign-in uses configured server credentials.</span></div>}
            <div className="settings-grid"><section className="panel settings-card"><div className="panel-heading"><div><p className="section-kicker">GAME CONFIGURATION</p><h2>Round settings</h2></div><SlidersHorizontal size={17} className="heading-glyph"/></div><div className="setting-row"><div><strong>Maintenance mode</strong><small>Pause new rounds while you review the system.</small></div><button type="button" role="switch" aria-checked={settings.maintenanceMode} className={`toggle-switch ${settings.maintenanceMode ? 'on' : ''}`} onClick={() => setSettings((current) => ({ ...current, maintenanceMode: !current.maintenanceMode }))}><i/></button></div><div className="setting-row setting-input-row"><div><strong>Countdown duration</strong><small>Seconds before each flight begins.</small></div><select value={settings.countdownSeconds} onChange={(e) => setSettings((current) => ({ ...current, countdownSeconds: Number(e.target.value) }))}>{[3, 4, 5, 6, 7, 8, 9, 10].map((value) => <option key={value} value={value}>{value} seconds</option>)}</select></div><div className="setting-row setting-input-row"><div><strong>Minimum virtual play</strong><small>Smallest points amount per round.</small></div><input type="number" value={settings.minStake} min="1" max={settings.maxStake} onChange={(e) => setSettings((current) => ({ ...current, minStake: Number(e.target.value) }))}/></div><div className="setting-row setting-input-row"><div><strong>Maximum virtual play</strong><small>Largest points amount per round.</small></div><input type="number" value={settings.maxStake} min={settings.minStake} max="1000000" onChange={(e) => setSettings((current) => ({ ...current, maxStake: Number(e.target.value) }))}/></div><div className="settings-footer"><span><ShieldCheck size={14}/> No payment settings exist in this system.</span><button type="button" className="button button-primary" disabled={settingsBusy} onClick={() => saveSettings()}>{settingsBusy ? <><span className="spinner"/> Saving</> : <>Save settings <ArrowRight size={14}/></>}</button></div></section>
              <section className="panel settings-security-card"><div className="panel-heading"><div><p className="section-kicker">ADMIN SECURITY</p><h2>Account protection</h2></div><LockKeyhole size={17} className="heading-glyph"/></div><div className="security-item"><span className="security-item-icon"><ShieldCheck size={17}/></span><div><strong>Role-based access</strong><small>Admin APIs are checked on the server.</small></div><Check size={16} className="value-mint"/></div><div className="security-item"><span className="security-item-icon"><LockKeyhole size={17}/></span><div><strong>Secure session</strong><small>HTTP-only cookie · hashed credentials</small></div><Check size={16} className="value-mint"/></div><div className="security-item"><span className="security-item-icon"><Activity size={17}/></span><div><strong>Audit trail</strong><small>Admin changes are logged.</small></div><Check size={16} className="value-mint"/></div>{!isDemo && <form className="change-password-form" onSubmit={changePassword}><h3>Change admin password</h3><label className="field-label">Current password</label><input type="password" required value={passwordForm.currentPassword} onChange={(e) => setPasswordForm({ ...passwordForm, currentPassword: e.target.value })}/><label className="field-label">New password <small>(14+ characters)</small></label><input type="password" minLength={14} required value={passwordForm.newPassword} onChange={(e) => setPasswordForm({ ...passwordForm, newPassword: e.target.value })}/><button type="submit" className="button button-secondary full-button" disabled={settingsBusy}>Update password</button></form>}<div className="security-warning"><CircleHelp size={14}/><span>Store deployment secrets in your platform's secret manager. Never place them in frontend code.</span></div><button type="button" className="button button-quiet full-button" onClick={async () => { if (isDemo) return notify('This control is unavailable in the temporary preview.', 'info'); try { await api('/admin/security/logout-all', { method: 'POST', body: {} }); setAdmin(null); window.location.href = '/'; } catch (error) { notify(error.message, 'error'); } }}>Log out all admin sessions</button></section></div>
          </>}
          {page === 'activity' && <>
            <div className="admin-page-heading"><div><p className="section-kicker">SECURITY & AUDIT</p><h1>Every action, <span>accounted for.</span></h1><p>Recent user and administrator activity across the sandbox.</p></div><button className="button button-quiet" onClick={() => downloadCsv('skyline-activity-log.csv', activity.map((item) => ({ time: item.createdAt, actor: item.actorType, actor_id: item.actorId || '', action: item.action, details: JSON.stringify(item.details || {}) })))}><Download size={15}/> Export logs</button></div>
            <section className="panel admin-table-panel"><div className="admin-table-toolbar"><div><h2>Activity log</h2><span>Latest {activity.length} events · most recent first</span></div><span className="audit-icon"><ShieldCheck size={16}/></span></div><div className="table-scroll"><table className="data-table activity-table"><thead><tr><th>TIME</th><th>ACTOR</th><th>ACTION</th><th>DETAILS</th><th>REFERENCE</th></tr></thead><tbody>{activity.map((item) => <tr key={item.id}><td className="muted-cell">{new Date(item.createdAt).toLocaleString()}</td><td><span className={`actor-pill ${item.actorType?.toLowerCase()}`}>{item.actorType}</span></td><td><strong>{item.action}</strong></td><td className="activity-details">{JSON.stringify(item.details || {})}</td><td className="mono-cell">{item.actorId ? String(item.actorId).slice(0, 12) : 'System'}</td></tr>)}</tbody></table>{!activity.length && <div className="empty-state"><Activity size={20}/><strong>No activity yet</strong><small>Audit entries will appear here.</small></div>}</div></section>
          </>}
          <footer className="admin-footer"><span>SKYLINE ADMIN CONTROL ROOM <i>•</i> VIRTUAL SANDBOX</span><span>All points are non-monetary game credits.</span></footer>
        </main>
      </div>
      {selectedUser && <div className="modal-backdrop" onClick={(e) => e.target === e.currentTarget && setSelectedUser(null)}><section className="user-detail-modal panel"><div className="modal-header"><div><p className="section-kicker">USER PROFILE</p><h2>Account details</h2></div><button className="icon-button" onClick={() => { setSelectedUser(null); setDetail(null); }}><X size={18}/></button></div>{detail ? <><div className="user-detail-head"><span className="avatar avatar-large">{detail.user.avatar || '✦'}</span><div><strong>{detail.user.username}</strong><small>{detail.user.active ? 'Active pilot' : 'Paused account'} · Joined {new Date(detail.user.createdAt).toLocaleDateString()}</small></div><StatusPill active={detail.user.active}>{detail.user.active ? 'Active' : 'Paused'}</StatusPill></div><div className="user-detail-stats"><div><small>VIRTUAL POINTS</small><strong>{formatPoints(detail.user.points)}</strong></div><div><small>GAMES PLAYED</small><strong>{formatPoints(detail.user.gamesPlayed)}</strong></div><div><small>SUCCESSFUL</small><strong>{formatPoints(detail.user.successfulRounds)}</strong></div><div><small>BEST FLIGHT</small><strong>{formatMultiplier(detail.user.bestMultiplier || 1)}</strong></div></div><div className="modal-section-title">Virtual point history</div>{detail.transactions?.length ? <div className="detail-transaction-list">{detail.transactions.slice(0, 6).map((item) => <div key={item.id}><span>{item.type.replaceAll('_', ' ')}</span><strong className={item.amount >= 0 ? 'value-mint' : 'value-coral'}>{item.amount > 0 ? '+' : ''}{formatPoints(item.amount)} pts</strong><small>{new Date(item.createdAt).toLocaleString()}</small></div>)}</div> : <div className="detail-empty">No point transactions yet.</div>}<div className="modal-section-title">Recent account activity</div>{detail.activity?.length ? <div className="detail-transaction-list">{detail.activity.slice(0, 6).map((item) => <div key={item.id}><span>{item.action}</span><strong className="muted-cell">{item.actorType}</strong><small>{new Date(item.createdAt).toLocaleString()} · {JSON.stringify(item.details || {})}</small></div>)}</div> : <div className="detail-empty">No account activity yet.</div>}<div className="modal-action-row"><button className="button button-quiet" onClick={() => logoutAllUser(detail.user)}><LogOut size={14}/> Revoke sessions</button><button className={`button ${detail.user.active ? 'button-danger' : 'button-primary'}`} onClick={async () => { await toggleUser(detail.user); setDetail((current) => current ? { ...current, user: { ...current.user, active: !current.user.active } } : current); }}><ShieldAlert size={14}/>{detail.user.active ? 'Deactivate' : 'Activate'}</button></div></> : <div className="modal-loading"><span className="spinner"/> Loading account…</div>}</section></div>}
      <AdminToast toast={toast} dismiss={() => setToast(null)}/>
    </div>
  );
}

function RoundTable({ rounds = [] }) {
  if (!rounds.length) return <div className="empty-state round-empty"><span className="empty-icon"><Gamepad2 size={19}/></span><strong>No rounds recorded yet</strong><small>The live server will add round outcomes here.</small></div>;
  return <div className="table-scroll"><table className="data-table round-table"><thead><tr><th>ROUND ID</th><th>STATUS</th><th>FINAL MULTIPLIER</th><th>STARTED</th><th>ENDED</th><th>CREATED</th></tr></thead><tbody>{rounds.map((round) => <tr key={round.id || round.roundId}><td><span className="mono-cell round-id-cell">{round.roundId}</span></td><td><StatusPill active={['RUNNING', 'WAITING', 'COUNTDOWN'].includes(round.status)}>{round.status}</StatusPill></td><td><strong className={round.crashMultiplier ? 'value-coral' : 'muted-cell'}>{round.crashMultiplier ? formatMultiplier(round.crashMultiplier) : '—'}</strong></td><td className="muted-cell">{round.startedAt ? new Date(round.startedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '—'}</td><td className="muted-cell">{round.endedAt ? new Date(round.endedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '—'}</td><td className="muted-cell">{new Date(round.createdAt).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</td></tr>)}</tbody></table></div>;
}
