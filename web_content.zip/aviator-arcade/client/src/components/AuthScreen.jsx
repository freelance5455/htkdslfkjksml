import { useState } from 'react';
import { ArrowRight, LockKeyhole, UserRound, ShieldCheck, Sparkles, Plane, CircleHelp } from 'lucide-react';
import { api } from '../lib/api';

export default function AuthScreen({ onSignedIn, onAdmin }) {
  const [mode, setMode] = useState('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [pending, setPending] = useState('');
  const [error, setError] = useState('');

  async function submit(event) {
    event.preventDefault();
    setError('');
    setPending('auth');
    try {
      const result = await api(`/auth/${mode}`, { method: 'POST', body: { username, password } });
      onSignedIn(result.user);
    } catch (err) { setError(err.message); }
    finally { setPending(''); }
  }
  async function tryDemo() {
    setError('');
    setPending('demo');
    try {
      const result = await api('/auth/demo', { method: 'POST', body: {} });
      onSignedIn(result.user);
    } catch (err) { setError(err.message); }
    finally { setPending(''); }
  }

  return (
    <main className="auth-screen">
      <div className="auth-atmosphere" aria-hidden="true"><span className="glow glow-a"/><span className="glow glow-b"/><div className="skyline-grid"/></div>
      <header className="auth-header">
        <a href="/" className="brand-lockup" aria-label="Skyline Arcade home">
          <span className="brand-mark"><Plane size={19} strokeWidth={2.2}/></span>
          <span><strong>SKYLINE</strong><small>ARCADE SANDBOX</small></span>
        </a>
        <div className="safe-chip"><ShieldCheck size={14}/> PLAY-MONEY ONLY</div>
      </header>
      <section className="auth-layout">
        <div className="auth-pitch">
          <div className="eyebrow"><span className="eyebrow-dot"/> THE RUNWAY IS OPEN</div>
          <h1>Make every<br/><span>second count.</span></h1>
          <p className="auth-copy">A fast, social flight arcade built for the thrill of timing — with points that only live here.</p>
          <div className="auth-art" aria-hidden="true">
            <div className="art-orbit orbit-one"/><div className="art-orbit orbit-two"/>
            <div className="art-sun"/><div className="art-trail"/>
            <svg className="art-plane" viewBox="0 0 120 76" fill="none"><path d="M8 40.5 109.4 13c3.1-.9 5.6 2.2 3.7 4.9L92 45.2c-1.2 1.6-3.3 2.2-5.2 1.5L62 37.3 46 58.6c-1.3 1.8-4.1 1.3-4.6-.9l-3.8-15.5-26.8 4.5c-2.8.4-3.5-4.8-.8-6.2Z" fill="url(#planeGradient)"/><path d="m37.6 42.2 37-14" stroke="#fff" strokeOpacity=".7" strokeWidth="2"/><defs><linearGradient id="planeGradient" x1="17" x2="105" y1="55" y2="13" gradientUnits="userSpaceOnUse"><stop stopColor="#6d64ff"/><stop offset="1" stopColor="#ff825d"/></linearGradient></defs></svg>
            <div className="art-stat"><span>FLIGHT LOG</span><strong>01 <i/> READY</strong></div>
            <div className="art-caption">CHASE THE CURVE <span>↗</span></div>
          </div>
          <div className="auth-features"><span><i className="feature-check">✓</i> Server-synced rounds</span><span><i className="feature-check">✓</i> Virtual points only</span><span><i className="feature-check">✓</i> No payments or cash value</span></div>
        </div>
        <div className="auth-card glass-panel">
          <div className="auth-card-head">
            <span className="auth-card-icon"><Sparkles size={18}/></span>
            <div><p className="sub-label">WELCOME TO SKYLINE</p><h2>{mode === 'login' ? 'Sign in to fly' : 'Create your pilot profile'}</h2></div>
          </div>
          <div className="auth-switch" role="tablist" aria-label="Account access">
            <button className={mode === 'login' ? 'active' : ''} onClick={() => { setMode('login'); setError(''); }}>Sign in</button>
            <button className={mode === 'register' ? 'active' : ''} onClick={() => { setMode('register'); setError(''); }}>Create account</button>
          </div>
          <form className="auth-form" onSubmit={submit}>
            <label className="field-label">Username</label>
            <div className="input-wrap"><UserRound size={17}/><input autoComplete="username" minLength={3} maxLength={24} required value={username} onChange={(e) => setUsername(e.target.value)} placeholder="e.g. sky_pilot"/></div>
            <label className="field-label">Password</label>
            <div className="input-wrap"><LockKeyhole size={17}/><input type="password" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} minLength={10} maxLength={128} required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="At least 10 characters"/></div>
            {mode === 'register' && <div className="form-hint"><CircleHelp size={13}/> New accounts start with 10,000 virtual points.</div>}
            {error && <div className="form-error" role="alert">{error}</div>}
            <button className="button button-primary auth-submit" type="submit" disabled={Boolean(pending)}>{pending === 'auth' ? <span className="spinner"/> : <>{mode === 'login' ? 'Sign in' : 'Create account'} <ArrowRight size={17}/></>}</button>
          </form>
          <div className="auth-divider"><span/> OR TRY THE SANDBOX <span/></div>
          <button className="button button-secondary guest-button" onClick={tryDemo} disabled={Boolean(pending)}>{pending === 'demo' ? <span className="spinner"/> : <><Sparkles size={16}/> Continue as a demo pilot</>}</button>
          <div className="points-note"><ShieldCheck size={14}/><span>Points are for gameplay only. No deposits, withdrawals, payments, or real-world value.</span></div>
          <button className="admin-entry" onClick={onAdmin}>Administrator access <ArrowRight size={14}/></button>
        </div>
      </section>
      <footer className="auth-footer"><span>SKYLINE ARCADE <i>•</i> SANDBOX BUILD</span><span>Built for play. Never for cash.</span></footer>
    </main>
  );
}
