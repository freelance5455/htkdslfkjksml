import { useCallback, useEffect, useMemo, useState } from 'react';
import { Activity, ArrowDownRight, ArrowRight, ArrowUpRight, Bell, ChartNoAxesCombined, ChevronDown, CircleHelp, Clock3, Coins, Gauge, History, House, LogOut, Menu, Medal, Plane, Settings2, ShieldCheck, Sparkles, Trophy, UserRound, UsersRound, Wallet, X } from 'lucide-react';
import { api, connectToArcade } from '../lib/api';
import FlightStage, { formatMultiplier, formatPoints } from './FlightStage';
import HistoryPanel from './HistoryPanel';
import StatCard from './StatCard';

const navItems = [
  { id: 'game', label: 'Flight deck', icon: House },
  { id: 'history', label: 'My history', icon: History },
  { id: 'leaderboard', label: 'Leaderboard', icon: Trophy },
  { id: 'activity', label: 'Activity', icon: Activity },
  { id: 'profile', label: 'Pilot profile', icon: UserRound }
];
const avatars = ['✦', '◈', '✧', '✺', '◉', '⬡'];

function Toast({ toast, dismiss }) {
  if (!toast) return null;
  return <div className={`toast toast-${toast.kind || 'info'}`} role="status"><span>{toast.kind === 'error' ? '!' : '✓'}</span><div>{toast.message}</div><button onClick={dismiss} aria-label="Dismiss"><X size={15}/></button></div>;
}

export default function UserApp({ user: initialUser, setUser: setSessionUser }) {
  const [user, setUser] = useState(initialUser);
  const [view, setView] = useState('game');
  const [round, setRound] = useState({ roundId: null, status: 'WAITING', multiplier: 1, participants: [], playerCount: 0 });
  const [myPlay, setMyPlay] = useState(null);
  const [history, setHistory] = useState([]);
  const [previousRounds, setPreviousRounds] = useState([]);
  const [period, setPeriod] = useState('30d');
  const [leaderboard, setLeaderboard] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [connection, setConnection] = useState(false);
  const [busy, setBusy] = useState('');
  const [stake, setStake] = useState(500);
  const [customStake, setCustomStake] = useState('');
  const [toast, setToast] = useState(null);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [profileName, setProfileName] = useState(initialUser.username);
  const [profileAvatar, setProfileAvatar] = useState(initialUser.avatar || '✦');
  const [searchValue, setSearchValue] = useState('');
  const [isDemo, setIsDemo] = useState(initialUser.username?.startsWith('pilot_'));

  const notify = useCallback((message, kind = 'success') => {
    setToast({ message, kind });
    window.clearTimeout(window.__skyToast);
    window.__skyToast = window.setTimeout(() => setToast(null), 3600);
  }, []);
  const refreshProfile = useCallback(async () => {
    try {
      const result = await api('/user/profile');
      setUser(result.user);
      setSessionUser(result.user);
      setProfileName(result.user.username);
      setProfileAvatar(result.user.avatar || '✦');
    } catch (error) { if (error.status === 401) handleExpired(); }
  }, [setSessionUser]);
  function handleExpired() {
    setUser(null);
    setSessionUser(null);
    notify('Your session has expired. Sign in again.', 'error');
  }
  const fetchHistory = useCallback(async (value = period) => {
    try {
      const [mine, rounds] = await Promise.all([api(`/user/history?period=${value}`), api('/game/history')]);
      setHistory(mine.history || []);
      setPreviousRounds((rounds.rounds || []).filter((r) => r.crashMultiplier).map((r) => ({ id: r.roundId, multiplier: Number(r.crashMultiplier), createdAt: r.endedAt || r.createdAt })).slice(0, 12));
    } catch (error) { notify(error.message, 'error'); }
  }, [period, notify]);

  useEffect(() => {
    let mounted = true;
    Promise.all([api('/game/current'), api('/game/history'), api(`/user/history?period=${period}`), api('/user/activity'), api('/user/leaderboard')]).then(([current, rounds, mine, activity, ranks]) => {
      if (!mounted) return;
      setRound(current);
      setMyPlay(current.myPlay || null);
      setHistory(mine.history || []);
      setPreviousRounds((rounds.rounds || []).filter((r) => r.crashMultiplier).map((r) => ({ id: r.roundId, multiplier: Number(r.crashMultiplier), createdAt: r.endedAt || r.createdAt })).slice(0, 12));
      setTransactions(activity.transactions || []);
      setNotifications(activity.notifications || []);
      setLeaderboard(ranks.leaderboard || []);
    }).catch((error) => { if (mounted && error.status === 401) handleExpired(); });
    return () => { mounted = false; };
  }, []);

  useEffect(() => {
    const socket = connectToArcade();
    const updateRound = (payload) => setRound((previous) => {
      const changed = payload.roundId && payload.roundId !== previous.roundId;
      return { ...previous, ...payload, participants: payload.participants || (changed ? [] : previous.participants || []) };
    });
    socket.on('connect', () => setConnection(true));
    socket.on('disconnect', () => setConnection(false));
    socket.on('connect_error', () => setConnection(false));
    socket.on('round:sync', updateRound);
    socket.on('round:waiting', (payload) => { updateRound(payload); setMyPlay(null); });
    socket.on('round:countdown', updateRound);
    socket.on('round:started', updateRound);
    socket.on('round:multiplier', (payload) => setRound((previous) => ({ ...previous, status: 'RUNNING', multiplier: payload.multiplier })));
    socket.on('round:crashed', (payload) => {
      updateRound(payload);
      setMyPlay((play) => play?.result === 'PENDING' ? { ...play, result: 'CRASHED', finalMultiplier: payload.crashMultiplier } : play);
      fetchHistory('30d');
    });
    socket.on('round:result', updateRound);
    socket.on('player:joined', (payload) => setRound((previous) => ({ ...previous, playerCount: payload.playerCount || previous.playerCount })));
    socket.on('player:updated', (payload) => setRound((previous) => payload.roundId === previous.roundId ? { ...previous, participants: payload.participants || [], playerCount: payload.participants?.length || 0 } : previous));
    socket.on('system:maintenance', (payload) => setRound((previous) => ({ ...previous, maintenance: payload.enabled })));
    return () => socket.disconnect();
  }, [fetchHistory]);

  useEffect(() => { if (view === 'history') fetchHistory(period); }, [view, period, fetchHistory]);
  useEffect(() => {
    if (view === 'leaderboard') api('/user/leaderboard').then((result) => setLeaderboard(result.leaderboard || [])).catch((err) => notify(err.message, 'error'));
    if (view === 'activity') api('/user/activity').then((result) => { setTransactions(result.transactions || []); setNotifications(result.notifications || []); }).catch((err) => notify(err.message, 'error'));
  }, [view, notify]);

  const activeStake = Number(customStake) > 0 ? Number(customStake) : stake;
  const isCurrentBet = myPlay && myPlay.roundId === round.roundId;
  const pendingPlay = isCurrentBet && myPlay.result === 'PENDING';
  const canPlay = ['WAITING', 'COUNTDOWN'].includes(round.status) && !isCurrentBet && !round.maintenance;
  const canCollect = pendingPlay && round.status === 'RUNNING' && !round.maintenance;
  const currentEstimate = Math.floor((myPlay?.pointsUsed || activeStake) * (round.multiplier || 1));

  async function playOrCollect() {
    if (busy) return;
    setBusy(canCollect ? 'collect' : 'play');
    try {
      if (canCollect) {
        const result = await api('/game/collect', { method: 'POST', body: {} });
        setUser((current) => ({ ...current, points: result.balance, successfulRounds: (current.successfulRounds || 0) + 1, bestMultiplier: Math.max(current.bestMultiplier || 0, result.multiplier) }));
        setSessionUser((current) => current ? { ...current, points: result.balance } : current);
        setMyPlay({ roundId: result.roundId, result: 'COLLECTED', pointsUsed: result.pointsUsed, pointsCollected: result.pointsCollected, finalMultiplier: result.multiplier });
        notify(`Collected ${formatPoints(result.pointsCollected)} virtual points at ${formatMultiplier(result.multiplier)}.`);
        const activity = await api('/user/activity'); setTransactions(activity.transactions || []); setNotifications(activity.notifications || []);
      } else if (canPlay) {
        const result = await api('/game/play', { method: 'POST', body: { pointsUsed: activeStake } });
        setUser((current) => ({ ...current, points: result.balance, gamesPlayed: (current.gamesPlayed || 0) + 1 }));
        setSessionUser((current) => current ? { ...current, points: result.balance } : current);
        setMyPlay({ roundId: result.roundId, result: 'PENDING', pointsUsed: result.pointsUsed, pointsCollected: 0 });
        setCustomStake('');
        notify(`${formatPoints(result.pointsUsed)} virtual points added to this round.`);
      }
    } catch (error) {
      notify(error.message, 'error');
      if ([401, 403].includes(error.status)) handleExpired();
      try { const current = await api('/game/current'); setRound(current); setMyPlay(current.myPlay || null); await refreshProfile(); } catch { /* connection may be offline */ }
    } finally { setBusy(''); }
  }

  async function logout() {
    try { await api('/auth/logout', { method: 'POST', body: {} }); } catch { /* local sign out still works */ }
    setSessionUser(null);
    setUser(null);
  }
  async function saveProfile(event) {
    event.preventDefault();
    setBusy('profile');
    try {
      const result = await api('/user/profile', { method: 'PATCH', body: { username: profileName, avatar: profileAvatar } });
      setUser(result.user); setSessionUser(result.user); setIsDemo(false);
      notify('Pilot profile updated.');
    } catch (error) { notify(error.message, 'error'); }
    finally { setBusy(''); }
  }
  function showSection(next) { setView(next); setNotificationsOpen(false); }

  const unreadCount = notifications.filter((n) => !n.readAt).length;
  const successRate = user.gamesPlayed ? Math.round((user.successfulRounds / user.gamesPlayed) * 100) : 0;

  return (
    <div className="arcade-shell">
      <header className="topbar">
        <a className="brand-lockup" href="/" aria-label="Skyline Arcade"><span className="brand-mark"><Plane size={18}/></span><span><strong>SKYLINE</strong><small>ARCADE SANDBOX</small></span></a>
        <div className="topbar-center"><span className="topbar-tag">FLIGHT SYSTEM <i className="connection-dot online"/></span><span className="topbar-separator"/><span className="topbar-round">{round.roundId || 'SYNCING ROUND'}</span></div>
        <div className="topbar-actions">
          <div className="top-balance"><span className="coin-icon"><Coins size={14}/></span><span><small>VIRTUAL POINTS</small><strong>{formatPoints(user.points)}</strong></span></div>
          <div className="notification-wrap">
            <button className={`icon-button ${notificationsOpen ? 'pressed' : ''}`} onClick={() => setNotificationsOpen((value) => !value)} aria-label="Notifications"><Bell size={17}/>{unreadCount > 0 && <i className="notification-badge"/>}</button>
            {notificationsOpen && <div className="notification-popover"><div className="popover-heading"><strong>Notifications</strong><button onClick={() => setNotificationsOpen(false)}><X size={14}/></button></div>{notifications.length ? notifications.slice(0, 5).map((note) => <div className="notification-item" key={note.id}><span className="notification-mark"><Sparkles size={13}/></span><div><strong>{note.title}</strong><p>{note.body}</p><small>{new Date(note.createdAt).toLocaleString()}</small></div></div>) : <div className="popover-empty">You're all caught up.</div>}</div>}
          </div>
          <button className="profile-menu" onClick={() => showSection('profile')}><span className="avatar avatar-small">{user.avatar || '✦'}</span><span className="profile-menu-name"><strong>{user.username}</strong><small>{isDemo ? 'DEMO PILOT' : 'PILOT ACCOUNT'}</small></span><ChevronDown size={14}/></button>
        </div>
      </header>
      <div className="arcade-body">
        <aside className="desktop-sidebar">
          <span className="sidebar-caption">MAIN MENU</span>
          <nav>{navItems.map(({ id, label, icon: Icon }) => <button key={id} className={`side-link ${view === id ? 'active' : ''}`} onClick={() => showSection(id)}><Icon size={17}/><span>{label}</span>{id === 'activity' && unreadCount > 0 && <i className="side-badge"/>}</button>)}</nav>
          <div className="sidebar-spacer"/>
          <div className="sidebar-credit"><span className="sidebar-credit-icon"><ShieldCheck size={15}/></span><div><strong>Sandbox mode</strong><small>No real-world value</small></div></div>
          <button className="side-link side-logout" onClick={logout}><LogOut size={17}/><span>Sign out</span></button>
          <div className="sidebar-version">SKYLINE / BUILD 01</div>
        </aside>
        <main className="app-main">
          {round.maintenance && <div className="maintenance-banner"><Settings2 size={15}/> Arcade maintenance is active. Current round will finish safely; new plays are paused.</div>}
          {view === 'game' && <>
            <div className="page-title-row"><div><p className="section-kicker">YOUR FLIGHT DECK</p><h1>Ready for takeoff, <span>{user.username}</span>?</h1></div><div className={`connection-pill ${connection ? 'connected' : 'disconnected'}`}><i/>{connection ? 'Live connection' : 'Reconnecting'}<span/></div></div>
            <div className="game-layout">
              <div className="game-column">
                <FlightStage round={round} connected={connection}/>
                <div className="previous-strip panel">
                  <div className="previous-label"><span className="history-orb"><History size={14}/></span><div><strong>Previous flights</strong><small>Last round multipliers</small></div></div>
                  <div className="previous-multipliers">{previousRounds.length ? previousRounds.slice(0, 10).map((item, index) => <span key={item.id || index} className={`history-mult ${item.multiplier < 2 ? 'low' : item.multiplier > 5 ? 'high' : ''}`} title={`${item.id} • ${new Date(item.createdAt).toLocaleString()}`}>{formatMultiplier(item.multiplier)}</span>) : <span className="history-empty">First flights are being logged…</span>}</div>
                  <button className="text-arrow" onClick={() => showSection('history')}>Full history <ArrowRight size={14}/></button>
                </div>
                <div className="under-stage-grid">
                  <div className="panel pilots-panel">
                    <div className="panel-heading"><div><p className="section-kicker">IN THIS ROUND</p><h2>Virtual pilots <span className="live-mini"><i/> LIVE</span></h2></div><div className="pilot-count"><UsersRound size={15}/>{round.playerCount || 0}</div></div>
                    {round.participants?.length ? <div className="pilot-list">{round.participants.slice(0, 5).map((pilot, i) => <div className="pilot-row" key={`${pilot.username}-${i}`}><span className="avatar avatar-tiny">{pilot.avatar || '✦'}</span><span className="pilot-name">{pilot.username}{pilot.username === user.username && <small>YOU</small>}</span><span className="pilot-stake">{formatPoints(pilot.pointsUsed)} <small>pts</small></span><span className={`pilot-status ${pilot.status === 'COLLECTED' ? 'collected' : pilot.status === 'CRASHED' ? 'crashed' : 'playing'}`}>{pilot.status === 'COLLECTED' ? formatMultiplier(pilot.multiplier) : pilot.status === 'CRASHED' ? 'CRASHED' : round.status === 'RUNNING' ? formatMultiplier(pilot.multiplier || round.multiplier) : 'FLYING'}</span></div>)}</div> : <div className="pilot-empty"><span className="pilot-empty-icon"><Plane size={17}/></span><div><strong>Waiting for pilots</strong><small>Join the next round to appear on the live board.</small></div></div>}
                    <div className="pilot-foot"><span><i className="tiny-green-dot"/> Activity is synced in real time</span><span>Virtual arena</span></div>
                  </div>
                  <div className="panel quick-stats-panel">
                    <div className="panel-heading"><div><p className="section-kicker">YOUR STATS</p><h2>Flight record</h2></div><ChartNoAxesCombined size={17} className="heading-glyph"/></div>
                    <div className="quick-stats"><div><small>ROUNDS PLAYED</small><strong>{formatPoints(user.gamesPlayed || 0)}</strong></div><div><small>SUCCESS RATE</small><strong className="stat-green">{successRate}%</strong></div><div><small>BEST MULTIPLIER</small><strong className="stat-violet">{formatMultiplier(user.bestMultiplier || 1)}</strong></div></div>
                    <button className="quick-link" onClick={() => showSection('profile')}>View full statistics <ArrowRight size={14}/></button>
                  </div>
                </div>
              </div>
              <aside className="play-column">
                <section className="wallet-panel panel">
                  <div className="wallet-panel-head"><div><p className="section-kicker">YOUR VIRTUAL WALLET</p><span className="wallet-subtitle">Game points only</span></div><span className="wallet-icon"><Wallet size={18}/></span></div>
                  <div className="wallet-balance"><strong>{formatPoints(user.points)}</strong><span>PTS</span></div>
                  <div className="wallet-meta"><span><i className="tiny-green-dot"/> Available to play</span><span>≈ {formatPoints(user.points)} points</span></div>
                  <div className="wallet-progress"><i style={{ width: `${Math.min(100, Math.max(7, (user.points / 10000) * 100))}%` }}/></div>
                  <div className="wallet-safety"><ShieldCheck size={14}/><span>No cash value. Cannot be purchased or redeemed.</span></div>
                </section>
                <section className="play-card panel">
                  <div className="play-card-heading"><div><p className="section-kicker">ROUND CONTROL</p><h2>{pendingPlay ? 'You’re in this flight' : 'Set your points'}</h2></div><span className={`round-state-icon ${round.status === 'RUNNING' ? 'is-live' : round.status === 'CRASHED' ? 'is-crashed' : ''}`}><Plane size={17}/></span></div>
                  <div className="round-state-line"><span className="state-label">ROUND STATUS</span><span className={`state-value ${round.status === 'RUNNING' ? 'state-live' : round.status === 'CRASHED' ? 'state-crashed' : ''}`}><i/>{round.maintenance ? 'MAINTENANCE' : round.status || 'WAITING'}</span></div>
                  <div className="stake-label-row"><label htmlFor="stake-amount">POINTS TO PLAY</label><button className="max-button" onClick={() => { setStake(Math.min(5000, user.points)); setCustomStake(''); }} disabled={!canPlay}>MAX</button></div>
                  <div className="stake-input-wrap"><span className="stake-coin"><Coins size={16}/></span><input id="stake-amount" type="number" min="50" max="5000" step="50" disabled={!canPlay} value={customStake || stake} onChange={(event) => { setCustomStake(event.target.value); }} /><span className="stake-currency">PTS</span></div>
                  <div className="stake-presets">{[100, 500, 1000, 2500].map((amount) => <button key={amount} className={activeStake === amount ? 'chosen' : ''} onClick={() => { setStake(amount); setCustomStake(''); }} disabled={!canPlay}>{formatPoints(amount)}</button>)}</div>
                  <div className="play-estimate"><span>{pendingPlay ? 'CURRENT POINTS AT MULTIPLIER' : 'CURRENT BALANCE AFTER PLAY'}</span><strong>{pendingPlay ? `${formatPoints(currentEstimate)} pts` : `${formatPoints(Math.max(0, user.points - (Number(activeStake) || 0)))} pts`}</strong></div>
                  <button className={`button game-action ${canCollect ? 'collect-action' : ''} ${pendingPlay && !canCollect ? 'joined-action' : ''}`} disabled={Boolean(busy) || (!canPlay && !canCollect)} onClick={playOrCollect}>
                    {busy ? <><span className="spinner"/> {busy === 'collect' ? 'Collecting…' : 'Joining…'}</> : canCollect ? <><ArrowUpRight size={18}/> Collect points <span className="button-multiplier">{formatMultiplier(round.multiplier)}</span></> : canPlay ? <><Plane size={18}/> Play round <ArrowRight size={17}/></> : pendingPlay ? <><Clock3 size={17}/> Joined — waiting for flight</> : round.maintenance ? <><Settings2 size={17}/> Maintenance</> : round.status === 'RUNNING' ? <><Plane size={17}/> Round in flight</> : <><Clock3 size={17}/> Next round soon</>}
                  </button>
                  <div className="play-safety"><ShieldCheck size={13}/><span>{pendingPlay ? 'Crash ends the round and this play is lost.' : 'Points are deducted on entry. No real-money play.'}</span></div>
                  <div className="play-card-footer"><span>MIN {formatPoints(50)} PTS</span><span>MAX {formatPoints(5000)} PTS</span><button onClick={() => notify('Choose virtual points, join before takeoff, then collect them while the multiplier is rising. A crash ends the round.', 'info')}><CircleHelp size={13}/> How it works</button></div>
                </section>
                <div className="points-explainer"><span className="explainer-icon"><Sparkles size={15}/></span><p><strong>Pure sandbox fun</strong><br/>Points are only for this game — no deposits, withdrawals, or prizes.</p></div>
              </aside>
            </div>
          </>}
          {view === 'history' && <>
            <div className="page-title-row"><div><p className="section-kicker">YOUR FLIGHT LOG</p><h1>Every round, <span>on record.</span></h1><p className="page-subtitle">Review your virtual-point activity by date.</p></div><div className="quiet-chip"><ShieldCheck size={14}/> Private to your account</div></div>
            <HistoryPanel history={history} period={period} setPeriod={setPeriod}/>
            <div className="history-summary-grid"><StatCard label="TOTAL ROUNDS" value={formatPoints(user.gamesPlayed || 0)} note="All-time activity" icon={Plane}/><StatCard label="SUCCESSFUL ROUNDS" value={formatPoints(user.successfulRounds || 0)} note="Points collected" icon={ArrowUpRight} tone="green"/><StatCard label="BEST MULTIPLIER" value={formatMultiplier(user.bestMultiplier || 1)} note="Personal record" icon={Gauge} tone="violet"/></div>
          </>}
          {view === 'leaderboard' && <>
            <div className="page-title-row"><div><p className="section-kicker">ARCADE STANDINGS</p><h1>Top pilots, <span>all virtual.</span></h1><p className="page-subtitle">Ranked by in-game points. No cash rewards or prizes.</p></div><div className="quiet-chip"><Trophy size={14}/> Updated live</div></div>
            <div className="panel leaderboard-panel"><div className="leaderboard-hero"><div className="leaderboard-hero-copy"><span className="leaderboard-orbit"><Trophy size={22}/></span><div><p className="section-kicker">THE FLIGHT CLUB</p><h2>Skyline leaderboard</h2><p>Points stay inside this sandbox — play, learn, and fly.</p></div></div><span className="virtual-only-pill"><ShieldCheck size={13}/> VIRTUAL ONLY</span></div>
              <div className="leaderboard-table-wrap"><div className="leaderboard-head"><span>RANK</span><span>PILOT</span><span>VIRTUAL POINTS</span><span>GAMES</span><span>BEST FLIGHT</span><span>SUCCESS</span></div>
                {leaderboard.length ? leaderboard.map((pilot, index) => <div className={`leaderboard-row ${pilot.id === user.id ? 'is-you' : ''}`} key={pilot.id}><span className={`rank-cell ${index < 3 ? `rank-${index + 1}` : ''}`}>{String(index + 1).padStart(2, '0')}{index === 0 && <Medal size={13}/>}</span><span className="leader-pilot"><span className="avatar">{pilot.avatar || '✦'}</span><span><strong>{pilot.username}{pilot.id === user.id && <i>YOU</i>}</strong><small>{pilot.id === user.id ? 'Your profile' : 'Sandbox pilot'}</small></span></span><strong className="leader-points">{formatPoints(pilot.points)} <small>PTS</small></strong><span>{formatPoints(pilot.gamesPlayed)}</span><strong className="leader-best">{formatMultiplier(pilot.bestMultiplier || 1)}</strong><span className="leader-success">{pilot.gamesPlayed ? Math.round((pilot.successfulRounds / pilot.gamesPlayed) * 100) : 0}%</span></div>) : <div className="empty-state"><strong>Standings are warming up</strong><small>Play a round to appear on the board.</small></div>}
              </div><div className="leaderboard-foot"><ShieldCheck size={14}/> This leaderboard tracks virtual points only. There are no monetary rewards.</div>
            </div>
          </>}
          {view === 'activity' && <>
            <div className="page-title-row"><div><p className="section-kicker">ACCOUNT ACTIVITY</p><h1>Your activity, <span>in one place.</span></h1><p className="page-subtitle">Virtual-point transactions and account notifications.</p></div><div className="quiet-chip"><Activity size={14}/> {transactions.length} recent events</div></div>
            <div className="activity-grid"><section className="panel transaction-panel"><div className="panel-heading"><div><p className="section-kicker">POINTS LEDGER</p><h2>Recent point activity</h2></div><span className="ledger-icon"><Coins size={16}/></span></div>
              {transactions.length ? <div className="transaction-list">{transactions.map((item) => <div className="transaction-row" key={item.id}><span className={`transaction-icon ${item.amount >= 0 ? 'positive' : 'negative'}`}>{item.amount >= 0 ? <ArrowDownRight size={15}/> : <ArrowUpRight size={15}/>}</span><div className="transaction-details"><strong>{item.type === 'STARTING_POINTS' ? 'Starting points' : item.type === 'COLLECT' ? 'Points collected' : item.type === 'PLAY' ? 'Round entry' : 'Point update'}</strong><small>{item.note || item.roundId || 'Virtual point balance'}</small><small>{new Date(item.createdAt).toLocaleString()}</small></div><strong className={item.amount >= 0 ? 'value-mint' : 'value-coral'}>{item.amount > 0 ? '+' : ''}{formatPoints(item.amount)} <small>pts</small></strong></div>)}</div> : <div className="empty-state"><strong>No activity yet</strong><small>Your point transactions appear here.</small></div>}
              </section><section className="panel notice-panel"><div className="panel-heading"><div><p className="section-kicker">INBOX</p><h2>Notifications</h2></div><span className="notice-count">{notifications.length}</span></div>
              {notifications.length ? <div className="notice-list">{notifications.map((item) => <div className="notice-item" key={item.id}><span className="notification-mark"><Sparkles size={13}/></span><div><strong>{item.title}</strong><p>{item.body}</p><small>{new Date(item.createdAt).toLocaleString()}</small></div></div>)}</div> : <div className="empty-state"><strong>All caught up</strong><small>We'll keep your game updates here.</small></div>}
              <div className="notice-safety"><ShieldCheck size={14}/> No payment or cash-out alerts exist in this sandbox.</div>
            </section></div>
          </>}
          {view === 'profile' && <>
            <div className="page-title-row"><div><p className="section-kicker">PILOT SETTINGS</p><h1>Make it <span>yours.</span></h1><p className="page-subtitle">Manage your arcade profile and review your stats.</p></div><div className="quiet-chip"><ShieldCheck size={14}/> Account protected</div></div>
            <div className="profile-layout"><section className="panel profile-card"><div className="profile-cover"><div className="cover-orbit cover-a"/><div className="cover-orbit cover-b"/><span className="cover-label"><Plane size={13}/> SKYLINE PILOT</span></div><div className="profile-avatar-large">{user.avatar || '✦'}</div><div className="profile-card-content"><p className="section-kicker">YOUR ACCOUNT</p><h2>{user.username}</h2><p className="profile-since">Pilot since {new Date(user.createdAt || Date.now()).toLocaleDateString([], { month: 'long', year: 'numeric' })}</p><div className="profile-stats"><div><small>VIRTUAL POINTS</small><strong>{formatPoints(user.points)}</strong></div><div><small>ROUNDS PLAYED</small><strong>{formatPoints(user.gamesPlayed || 0)}</strong></div><div><small>BEST MULTIPLIER</small><strong>{formatMultiplier(user.bestMultiplier || 1)}</strong></div></div><div className="profile-badge"><ShieldCheck size={15}/><span>Sandbox account · Points have no cash value</span></div></div></section>
              <section className="panel profile-edit"><div className="panel-heading"><div><p className="section-kicker">PROFILE SETTINGS</p><h2>Edit pilot profile</h2></div><Settings2 size={17} className="heading-glyph"/></div><form onSubmit={saveProfile}><label className="field-label">Display username</label><div className="input-wrap"><UserRound size={17}/><input value={profileName} onChange={(event) => setProfileName(event.target.value)} minLength={3} maxLength={24} required/></div><label className="field-label avatar-label">Choose avatar</label><div className="avatar-picker">{avatars.map((item) => <button type="button" key={item} className={profileAvatar === item ? 'chosen' : ''} onClick={() => setProfileAvatar(item)}>{item}</button>)}</div><button className="button button-primary profile-save" disabled={busy === 'profile'}>{busy === 'profile' ? <><span className="spinner"/> Saving…</> : <>Save profile <ArrowRight size={16}/></>}</button></form><div className="profile-security-note"><ShieldCheck size={14}/><span>Your account uses a secure, HTTP-only session. Never share your password.</span></div></section></div>
          </>}
          <footer className="app-footer"><span>SKYLINE ARCADE <i>•</i> PLAY-MONEY SANDBOX</span><span>Virtual points only. No deposits, withdrawals, or cash value.</span></footer>
        </main>
      </div>
      <nav className="mobile-bottom-nav" aria-label="Main navigation">{navItems.slice(0, 4).map(({ id, label, icon: Icon }) => <button key={id} className={view === id ? 'active' : ''} onClick={() => showSection(id)}><Icon size={18}/><small>{label.replace('Flight deck', 'Play').replace('My history', 'History').replace('Leaderboard', 'Ranks').replace('Activity', 'Activity')}</small></button>)}</nav>
      <Toast toast={toast} dismiss={() => setToast(null)}/>
    </div>
  );
}
