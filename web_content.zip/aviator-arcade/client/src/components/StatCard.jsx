export default function StatCard({ label, value, note, icon: Icon, tone = 'violet' }) {
  return <div className={`stat-card stat-${tone}`}><div className="stat-card-top"><span>{label}</span><i className="stat-icon">{Icon && <Icon size={17}/>}</i></div><strong>{value}</strong>{note && <small>{note}</small>}</div>;
}
