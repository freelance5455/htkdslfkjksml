import { useEffect, useState } from 'react';
import { api } from './lib/api';
import AuthScreen from './components/AuthScreen';
import UserApp from './components/UserApp';
import AdminApp from './components/AdminApp';

export default function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [adminRequested, setAdminRequested] = useState(window.location.pathname.startsWith('/admin'));
  const adminPath = window.location.pathname.startsWith('/admin');

  useEffect(() => {
    let active = true;
    api(adminPath ? '/admin/me' : '/auth/me').then((result) => {
      if (!active) return;
      if (adminPath) {
        setAdminRequested(Boolean(result.admin));
        if (result.admin) setUser({ ...result.admin, isAdmin: true });
      } else setUser(result.user || null);
    }).catch(() => { if (active) setUser(null); }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [adminPath]);

  if (loading) return <div className="app-loader"><div className="loader-mark">✦</div><span>Preparing your runway…</span></div>;
  if (adminPath) return <AdminApp initialAdmin={user?.isAdmin ? user : null} />;
  if (user) return <UserApp user={user} setUser={setUser} />;
  if (adminRequested) return <AdminApp initialAdmin={null} />;
  return <AuthScreen onSignedIn={setUser} onAdmin={() => { window.history.pushState({}, '', '/admin'); setAdminRequested(true); }} />;
}
