const { randomBytes, timingSafeEqual } = require('node:crypto');

function csrfTokenRoute(req, res) {
  if (!req.session.csrfToken) req.session.csrfToken = randomBytes(32).toString('hex');
  res.setHeader('Cache-Control', 'no-store');
  res.json({ csrfToken: req.session.csrfToken });
}

function csrfProtection(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const supplied = req.get('x-csrf-token') || '';
  const expected = req.session?.csrfToken || '';
  const validLength = supplied.length === expected.length && expected.length > 0;
  const valid = validLength && timingSafeEqual(Buffer.from(supplied), Buffer.from(expected));
  if (!valid) return res.status(403).json({ error: 'Your session token expired. Refresh and try again.', code: 'CSRF_INVALID' });
  next();
}

function requireUser(store) {
  return async (req, res, next) => {
    try {
      if (!req.session?.userId) return res.status(401).json({ error: 'Please sign in to continue.', code: 'AUTH_REQUIRED' });
      const user = await store.getUserById(req.session.userId);
      if (!user || !user.active || Number(req.session.userVersion) !== Number(user.sessionVersion)) {
        req.session.destroy(() => {});
        return res.status(401).json({ error: 'Your session has expired. Please sign in again.', code: 'SESSION_INVALID' });
      }
      req.user = user;
      next();
    } catch (error) { next(error); }
  };
}

function requireAdmin(store) {
  return async (req, res, next) => {
    try {
      if (!req.session?.adminId) return res.status(401).json({ error: 'Admin sign-in required.', code: 'ADMIN_AUTH_REQUIRED' });
      const admin = await store.getAdminById(req.session.adminId);
      if (!admin || !admin.active || Number(req.session.adminVersion) !== Number(admin.sessionVersion)) {
        req.session.destroy(() => {});
        return res.status(401).json({ error: 'Admin session expired. Please sign in again.', code: 'ADMIN_SESSION_INVALID' });
      }
      if (!['admin', 'superadmin', 'support'].includes(admin.role)) return res.status(403).json({ error: 'This account does not have admin access.' });
      req.admin = admin;
      next();
    } catch (error) { next(error); }
  };
}

function requireAdminWrite(req, res, next) {
  if (!req.admin || !['admin', 'superadmin'].includes(req.admin.role)) return res.status(403).json({ error: 'Your admin role is read-only.' });
  next();
}

module.exports = { csrfTokenRoute, csrfProtection, requireUser, requireAdmin, requireAdminWrite };
