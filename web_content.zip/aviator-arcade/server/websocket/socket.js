function attachSocketBridge(io, sessionMiddleware, engine, store) {
  io.engine.use(sessionMiddleware);
  io.on('connection', async (socket) => {
    socket.emit('round:sync', engine.snapshot());
    socket.emit('system:maintenance', { enabled: engine.maintenance, message: engine.maintenance ? 'The arcade is in maintenance mode.' : 'The arcade is online.' });
    try {
      if (engine.state?.roundId) socket.emit('player:updated', { roundId: engine.state.roundId, participants: engine.state.participants || [] });
    } catch (error) { console.warn('[socket] initial sync failed:', error.message); }
    socket.on('disconnect', () => {});
  });
}

module.exports = { attachSocketBridge };
