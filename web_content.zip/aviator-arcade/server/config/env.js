const crypto = require('node:crypto');

const production = process.env.NODE_ENV === 'production';
const config = {
  production,
  port: Number(process.env.API_PORT) || 3001,
  appUrl: process.env.APP_URL || '',
  websocketUrl: process.env.WEBSOCKET_URL || '',
  databaseUrl: process.env.DATABASE_URL || '',
  sessionSecret: process.env.AUTH_SECRET || (!production ? crypto.randomBytes(32).toString('hex') : ''),
  demoMode: !production && process.env.DEMO_MODE !== 'false',
  adminUsername: process.env.ADMIN_USERNAME || '',
  adminPassword: process.env.ADMIN_PASSWORD || '',
  pgSsl: process.env.PGSSL === 'true'
};

if (production) {
  const missing = ['AUTH_SECRET', 'DATABASE_URL', 'APP_URL'].filter((key) => !process.env[key]);
  if (missing.length) throw new Error(`Missing required production environment values: ${missing.join(', ')}`);
  if (config.sessionSecret.length < 32) throw new Error('AUTH_SECRET must contain at least 32 characters.');
  if (config.demoMode) throw new Error('DEMO_MODE must be disabled in production.');
}

module.exports = config;
