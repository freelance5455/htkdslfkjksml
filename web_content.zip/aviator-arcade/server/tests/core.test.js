const test = require('node:test');
const assert = require('node:assert/strict');
const bcrypt = require('bcryptjs');
const { EventEmitter } = require('node:events');
const { Store } = require('../services/store');
const { GameEngine } = require('../services/game-engine');
const { canTransition, assertTransition, calculatePayout, createCrashMultiplier } = require('../services/game-rules');
const { requireUser, requireAdmin, requireAdminWrite } = require('../middleware/security');
const { attachSocketBridge } = require('../websocket/socket');

function mockResponse() {
  return { statusCode: 200, body: null, status(code) { this.statusCode = code; return this; }, json(body) { this.body = body; return this; } };
}

test('authentication hashes passwords rather than storing plaintext', async () => {
  const password = 'A-new-demo-password-2026!';
  const hash = await bcrypt.hash(password, 4);
  assert.notEqual(hash, password);
  assert.equal(await bcrypt.compare(password, hash), true);
  assert.equal(await bcrypt.compare('not-the-password', hash), false);
});

test('round lifecycle only accepts the declared server transitions', () => {
  assert.equal(canTransition('WAITING', 'COUNTDOWN'), true);
  assert.equal(canTransition('COUNTDOWN', 'RUNNING'), true);
  assert.equal(canTransition('RUNNING', 'CRASHED'), true);
  assert.equal(canTransition('CRASHED', 'RESULT'), true);
  assert.equal(canTransition('WAITING', 'CRASHED'), false);
  assert.throws(() => assertTransition('WAITING', 'RESULT'), /Invalid round transition/);
});

test('virtual point payout is integer-only and uses the server multiplier', () => {
  assert.equal(calculatePayout(500, 2.34), 1170);
  assert.equal(calculatePayout(99, 1.01), 99);
  assert.throws(() => calculatePayout(1.5, 2), /integer/);
  assert.throws(() => calculatePayout(20, 0.9), /at least 1/);
});

test('generated crash result stays inside its documented sandbox bounds', () => {
  assert.equal(createCrashMultiplier(() => 0), 1.12);
  assert.equal(createCrashMultiplier(() => 1), 9);
});

test('store records a play, collection, point transactions, and updated statistics', async () => {
  const store = new Store();
  const user = await store.createUser({ username: 'test-pilot', passwordHash: 'bcrypt-hash' });
  assert.equal(user.points, 10000);
  const round = await store.createRound('SKY-TEST-001');
  const placed = await store.placeBet(user.id, round.roundId, 250);
  assert.equal(placed.balance, 9750);
  const collected = await store.collectBet(user.id, round.roundId, 2.5);
  assert.equal(collected.pointsCollected, 625);
  assert.equal(collected.balance, 10375);
  const updated = await store.getUserById(user.id);
  assert.equal(updated.gamesPlayed, 1);
  assert.equal(updated.successfulRounds, 1);
  assert.equal(updated.bestMultiplier, 2.5);
  const history = await store.getUserHistory(user.id, '30d');
  assert.equal(history[0].result, 'COLLECTED');
  assert.equal(history[0].pointsUsed, 250);
  assert.equal(history[0].pointsCollected, 625);
  const tx = await store.getPointTransactions(user.id, 10);
  assert.deepEqual(tx.map((item) => item.type), ['COLLECT', 'PLAY', 'STARTING_POINTS']);
});

test('a crash marks pending plays lost without refunding virtual points', async () => {
  const store = new Store();
  const user = await store.createUser({ username: 'crash-pilot', passwordHash: 'bcrypt-hash' });
  await store.createRound('SKY-TEST-002');
  await store.placeBet(user.id, 'SKY-TEST-002', 500);
  await store.crashPendingBets('SKY-TEST-002', 1.6);
  const updated = await store.getUserById(user.id);
  assert.equal(updated.points, 9500);
  const history = await store.getUserHistory(user.id, '30d');
  assert.equal(history[0].result, 'CRASHED');
  assert.equal(history[0].pointsCollected, 0);
});

test('server-authoritative engine denies collection outside a running round', async () => {
  const io = new EventEmitter();
  const store = new Store();
  const user = await store.createUser({ username: 'sync-pilot', passwordHash: 'bcrypt-hash' });
  const engine = new GameEngine({ store, io });
  engine.state = { roundId: 'SKY-TEST-003', status: 'WAITING', multiplier: 1, participants: [] };
  await assert.rejects(() => engine.collect(user), (error) => error.code === 'ROUND_NOT_RUNNING');
  assert.equal(engine.snapshot().crashMultiplier, null);
});

test('current round synchronization redacts the generated result until crash', () => {
  const engine = new GameEngine({ store: new Store(), io: new EventEmitter() });
  engine.state = { roundId: 'SKY-TEST-004', status: 'RUNNING', multiplier: 1.78, crashMultiplier: 4.56, startedAt: new Date().toISOString(), startedAtMs: Date.now(), participants: [] };
  assert.ok(engine.snapshot().multiplier >= 1);
  assert.equal(engine.snapshot().crashMultiplier, null);
  engine.state.status = 'CRASHED';
  assert.equal(engine.snapshot().crashMultiplier, 4.56);
});

test('user API authorization rejects missing sessions and accepts a current version', async () => {
  const store = new Store();
  const user = await store.createUser({ username: 'auth-pilot', passwordHash: 'hash' });
  const middleware = requireUser(store);
  let called = false;
  const denied = mockResponse();
  await middleware({ session: {} }, denied, () => { called = true; });
  assert.equal(denied.statusCode, 401);
  assert.equal(called, false);
  const accepted = mockResponse();
  await middleware({ session: { userId: user.id, userVersion: user.sessionVersion } }, accepted, () => { called = true; });
  assert.equal(called, true);
});

test('admin authorization and write permissions are enforced server-side', async () => {
  const store = new Store();
  const adminMiddleware = requireAdmin(store);
  const denied = mockResponse();
  await adminMiddleware({ session: {} }, denied, () => {});
  assert.equal(denied.statusCode, 401);
  const adminReq = { session: { adminId: 'demo-admin', adminVersion: 1 } };
  let nextCalled = false;
  await adminMiddleware(adminReq, mockResponse(), () => { nextCalled = true; });
  assert.equal(nextCalled, true);
  let writeAllowed = false;
  requireAdminWrite(adminReq, mockResponse(), () => { writeAllowed = true; });
  assert.equal(writeAllowed, true);
  let supportWrite = false;
  const deniedWrite = mockResponse();
  requireAdminWrite({ admin: { role: 'support' } }, deniedWrite, () => { supportWrite = true; });
  assert.equal(supportWrite, false);
  assert.equal(deniedWrite.statusCode, 403);
});

test('Socket.IO bridge sends a consistent snapshot to newly connected clients', async () => {
  const io = new EventEmitter();
  let sessionMounted = false;
  io.engine = { use() { sessionMounted = true; } };
  const received = [];
  const socket = { emit: (name, payload) => received.push({ name, payload }), on() {} };
  const engine = { maintenance: false, state: { roundId: 'SKY-TEST-005' }, snapshot: () => ({ roundId: 'SKY-TEST-005', status: 'RUNNING', multiplier: 1.4 }) };
  attachSocketBridge(io, () => {}, engine, new Store());
  io.emit('connection', socket);
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(sessionMounted, true);
  assert.equal(received[0].name, 'round:sync');
  assert.equal(received[0].payload.roundId, 'SKY-TEST-005');
});

test('virtual points cannot be wagered twice in the same round', async () => {
  const store = new Store();
  const user = await store.createUser({ username: 'duplicate-pilot', passwordHash: 'hash' });
  await store.createRound('SKY-TEST-006');
  await store.placeBet(user.id, 'SKY-TEST-006', 100);
  await assert.rejects(() => store.placeBet(user.id, 'SKY-TEST-006', 100), (error) => error.code === 'ALREADY_JOINED');
  assert.equal((await store.getUserById(user.id)).points, 9900);
});
