const { randomBytes } = require('node:crypto');
const { assertTransition, calculatePayout, createCrashMultiplier } = require('./game-rules');

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const clamp = (value, low, high) => Math.min(high, Math.max(low, value));

class GameEngine {
  constructor({ store, io, countdownSeconds = 3, tickMs = 200 }) {
    this.store = store;
    this.io = io;
    this.countdownSeconds = countdownSeconds;
    this.tickMs = tickMs;
    this.running = false;
    this.maintenance = false;
    this.state = null;
    this.loopPromise = null;
    this.lastMaintenanceNotice = false;
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.loopPromise = this.runLoop();
  }
  async stop() {
    this.running = false;
    if (this.loopPromise) await Promise.race([this.loopPromise, sleep(1000)]);
  }
  setMaintenance(enabled) {
    this.maintenance = Boolean(enabled);
    this.lastMaintenanceNotice = false;
    this.io.emit('system:maintenance', { enabled: this.maintenance, message: this.maintenance ? 'The arcade is in maintenance mode.' : 'The arcade is back online.' });
  }
  async syncSettings() {
    const settings = await this.store.getSettings();
    this.countdownSeconds = clamp(Number(settings.countdownSeconds) || 3, 3, 10);
    this.setMaintenance(Boolean(settings.maintenanceMode));
  }

  snapshot() {
    if (!this.state) return { roundId: null, status: 'WAITING', countdown: null, multiplier: 1, startedAt: null, endedAt: null, crashMultiplier: null, playerCount: 0, participants: [], maintenance: this.maintenance };
    const crashed = ['CRASHED', 'RESULT'].includes(this.state.status);
    const participants = this.state.participants || [];
    return {
      roundId: this.state.roundId,
      status: this.state.status,
      countdown: this.state.countdown ?? null,
      multiplier: this.state.status === 'RUNNING' ? this.currentMultiplier() : this.state.multiplier || 1,
      startedAt: this.state.startedAt || null,
      endedAt: this.state.endedAt || null,
      crashMultiplier: crashed ? this.state.crashMultiplier : null,
      playerCount: participants.length,
      participants: participants.slice(0, 12),
      maintenance: this.maintenance
    };
  }

  async placeBet(user, pointsUsed) {
    const settings = await this.store.getSettings();
    const min = Number(settings.minStake) || 50;
    const max = Number(settings.maxStake) || 5000;
    if (!Number.isInteger(pointsUsed) || pointsUsed < min || pointsUsed > max) {
      throw Object.assign(new Error(`Choose between ${min.toLocaleString()} and ${max.toLocaleString()} virtual points.`), { status: 400, code: 'INVALID_STAKE' });
    }
    if (this.maintenance) throw Object.assign(new Error('The arcade is in maintenance mode. Please try again soon.'), { status: 503, code: 'MAINTENANCE' });
    if (!this.state || !['WAITING', 'COUNTDOWN'].includes(this.state.status)) {
      throw Object.assign(new Error('The next round is not open yet. Watch for the countdown.'), { status: 409, code: 'ROUND_CLOSED' });
    }
    const result = await this.store.placeBet(user.id, this.state.roundId, pointsUsed);
    const player = { username: user.username, avatar: user.avatar, pointsUsed, pointsCollected: 0, status: 'PLAYING', multiplier: 1 };
    this.state.participants = [player, ...(this.state.participants || []).filter((p) => p.username !== user.username)].slice(0, 30);
    this.io.emit('player:joined', { roundId: this.state.roundId, username: player.username, avatar: player.avatar, pointsUsed, playerCount: this.state.participants.length });
    this.io.emit('player:updated', { roundId: this.state.roundId, participants: this.state.participants });
    return { ...result, roundId: this.state.roundId };
  }

  currentMultiplier() {
    if (!this.state || this.state.status !== 'RUNNING') return this.state?.multiplier || 1;
    const elapsed = Math.max(0, Date.now() - this.state.startedAtMs);
    const calculated = Math.exp(elapsed / 8000);
    return Math.min(this.state.crashMultiplier, Math.floor(calculated * 100) / 100);
  }

  async collect(user) {
    if (this.maintenance) throw Object.assign(new Error('The arcade is in maintenance mode.'), { status: 503, code: 'MAINTENANCE' });
    if (!this.state || this.state.status !== 'RUNNING') throw Object.assign(new Error('Points can only be collected during a live round.'), { status: 409, code: 'ROUND_NOT_RUNNING' });
    const multiplier = this.currentMultiplier();
    if (Date.now() - this.state.startedAtMs >= Math.log(this.state.crashMultiplier) * 8000 || multiplier >= this.state.crashMultiplier) {
      throw Object.assign(new Error('That round has already ended. Your points were settled by the server.'), { status: 409, code: 'ROUND_ENDED' });
    }
    const result = await this.store.collectBet(user.id, this.state.roundId, multiplier);
    const participant = this.state.participants?.find((p) => p.username === user.username);
    if (participant) Object.assign(participant, { status: 'COLLECTED', pointsCollected: result.pointsCollected, multiplier });
    this.io.emit('player:updated', { roundId: this.state.roundId, participants: this.state.participants || [] });
    return { ...result, roundId: this.state.roundId };
  }

  async runLoop() {
    while (this.running) {
      try {
        if (this.maintenance) {
          if (!this.lastMaintenanceNotice) {
            this.io.emit('system:maintenance', { enabled: true, message: 'The arcade is in maintenance mode.' });
            this.lastMaintenanceNotice = true;
          }
          await sleep(1000);
          continue;
        }
        await this.runRound();
      } catch (error) {
        console.error('[game-engine]', error.message);
        await sleep(1000);
      }
    }
  }

  async transition(status, patch = {}) {
    if (this.state?.status) assertTransition(this.state.status, status);
    this.state = { ...(this.state || {}), ...patch, status };
    if (this.state.roundId) await this.store.updateRound(this.state.roundId, { status, startedAt: this.state.startedAt, endedAt: this.state.endedAt, crashMultiplier: ['CRASHED', 'RESULT'].includes(status) ? this.state.crashMultiplier : null });
  }

  async runRound() {
    const previous = this.state?.status;
    if (previous && previous !== 'RESULT') throw new Error(`Cannot create a round while previous round is ${previous}`);
    if (previous === 'RESULT') assertTransition(previous, 'WAITING');
    const roundId = `SKY-${Date.now().toString(36).toUpperCase()}-${randomBytes(2).toString('hex').toUpperCase()}`;
    const created = await this.store.createRound(roundId);
    this.state = { roundId: created.roundId, status: 'WAITING', countdown: null, multiplier: 1, startedAt: null, startedAtMs: null, endedAt: null, crashMultiplier: null, participants: [] };
    this.io.emit('round:waiting', this.snapshot());
    await sleep(2600);
    if (!this.running) return;

    await this.transition('COUNTDOWN', { countdown: this.countdownSeconds });
    for (let count = this.countdownSeconds; count >= 1 && this.running; count -= 1) {
      this.state.countdown = count;
      this.io.emit('round:countdown', this.snapshot());
      await sleep(1000);
    }
    if (!this.running) return;

    const crashMultiplier = createCrashMultiplier();
    const startedAt = new Date().toISOString();
    await this.transition('RUNNING', { countdown: null, multiplier: 1, startedAt, startedAtMs: Date.now(), crashMultiplier });
    this.io.emit('round:started', this.snapshot());
    const crashAfter = Math.max(150, Math.log(crashMultiplier) * 8000);
    let lastPlayerUpdate = 0;
    while (this.running && Date.now() - this.state.startedAtMs < crashAfter) {
      const elapsedMs = Date.now() - this.state.startedAtMs;
      const multiplier = Math.min(crashMultiplier, Math.floor(Math.exp(elapsedMs / 8000) * 100) / 100);
      this.state.multiplier = multiplier;
      this.io.emit('round:multiplier', { roundId, multiplier, elapsedMs });
      if (elapsedMs - lastPlayerUpdate >= 900 && this.state.participants?.length) {
        this.state.participants = this.state.participants.map((player) => player.status === 'PLAYING' ? { ...player, multiplier } : player);
        this.io.emit('player:updated', { roundId, participants: this.state.participants });
        lastPlayerUpdate = elapsedMs;
      }
      await sleep(this.tickMs);
    }
    if (!this.running) return;

    const endedAt = new Date().toISOString();
    await this.transition('CRASHED', { endedAt, multiplier: crashMultiplier, crashMultiplier, countdown: null });
    await this.store.crashPendingBets(roundId, crashMultiplier);
    this.io.emit('round:crashed', this.snapshot());
    await sleep(1800);
    if (!this.running) return;
    await this.transition('RESULT', { endedAt, multiplier: crashMultiplier });
    this.io.emit('round:result', this.snapshot());
    await sleep(1800);
  }
}

module.exports = { GameEngine, sleep };
