const ROUND_STATUSES = Object.freeze(['WAITING', 'COUNTDOWN', 'RUNNING', 'CRASHED', 'RESULT']);
const TRANSITIONS = Object.freeze({
  WAITING: ['COUNTDOWN'],
  COUNTDOWN: ['RUNNING'],
  RUNNING: ['CRASHED'],
  CRASHED: ['RESULT'],
  RESULT: ['WAITING']
});

function canTransition(from, to) {
  return Boolean(TRANSITIONS[from]?.includes(to));
}

function assertTransition(from, to) {
  if (!canTransition(from, to)) throw new Error(`Invalid round transition: ${from} → ${to}`);
}

function calculatePayout(pointsUsed, multiplier) {
  if (!Number.isSafeInteger(pointsUsed) || pointsUsed < 0) throw new TypeError('Points must be a non-negative integer.');
  if (!Number.isFinite(multiplier) || multiplier < 1) throw new TypeError('Multiplier must be at least 1.');
  return Math.floor(pointsUsed * multiplier);
}

function createCrashMultiplier(random = Math.random) {
  // Server-only demo distribution, capped to keep rounds short and outcomes bounded.
  const value = 1.12 + Math.pow(random(), 1.55) * 7.88;
  return Math.round(value * 100) / 100;
}

module.exports = { ROUND_STATUSES, TRANSITIONS, canTransition, assertTransition, calculatePayout, createCrashMultiplier };
