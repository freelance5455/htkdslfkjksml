const { randomUUID } = require('node:crypto');
const { calculatePayout } = require('./game-rules');

const DEFAULT_SETTINGS = Object.freeze({ maintenanceMode: false, countdownSeconds: 3, minStake: 50, maxStake: 5000 });
const USER_FIELDS = `id, username, password_hash AS "passwordHash", avatar, virtual_points AS points, is_active AS active, session_version AS "sessionVersion", games_played AS "gamesPlayed", successful_rounds AS "successfulRounds", best_multiplier AS "bestMultiplier", created_at AS "createdAt"`;
const ADMIN_FIELDS = `id, username, password_hash AS "passwordHash", role, is_active AS active, session_version AS "sessionVersion", created_at AS "createdAt"`;

function toUser(row) {
  if (!row) return null;
  return { ...row, points: Number(row.points), gamesPlayed: Number(row.gamesPlayed || 0), successfulRounds: Number(row.successfulRounds || 0), bestMultiplier: Number(row.bestMultiplier || 0), sessionVersion: Number(row.sessionVersion || 1), active: Boolean(row.active) };
}
function toAdmin(row) {
  if (!row) return null;
  return { ...row, sessionVersion: Number(row.sessionVersion || 1), active: Boolean(row.active) };
}
function periodStart(period) {
  const days = period === 'today' ? 1 : period === '7d' ? 7 : period === '30d' ? 30 : null;
  if (!days) return null;
  const date = new Date();
  if (period === 'today') date.setHours(0, 0, 0, 0);
  else date.setDate(date.getDate() - days);
  return date;
}

class Store {
  constructor(pool = null) {
    this.pool = pool;
    this.users = new Map();
    this.admins = new Map();
    this.rounds = new Map();
    this.bets = new Map();
    this.history = [];
    this.transactions = [];
    this.notifications = [];
    this.activity = [];
    this.settings = { ...DEFAULT_SETTINGS };
  }

  async init() {
    if (!this.pool) return;
    for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
      await this.pool.query('INSERT INTO system_settings(key, value) VALUES($1, $2::jsonb) ON CONFLICT (key) DO NOTHING', [key, JSON.stringify(value)]);
    }
  }

  async createUser({ username, passwordHash, avatar = '✦', points = 10000 }) {
    if (this.pool) {
      const client = await this.pool.connect();
      try {
        await client.query('BEGIN');
        const inserted = await client.query(`INSERT INTO users(username,password_hash,avatar,virtual_points) VALUES($1,$2,$3,$4) RETURNING ${USER_FIELDS}`, [username, passwordHash, avatar, points]);
        const user = toUser(inserted.rows[0]);
        await client.query('INSERT INTO virtual_point_transactions(user_id,type,amount,balance_after,note) VALUES($1,$2,$3,$4,$5)', [user.id, 'STARTING_POINTS', points, points, 'Demo starting points']);
        await client.query('INSERT INTO notifications(user_id,title,body) VALUES($1,$2,$3)', [user.id, 'Welcome to Skyline', 'Your points are virtual and stay inside this sandbox.']);
        await client.query('COMMIT');
        return user;
      } catch (error) { await client.query('ROLLBACK'); throw error; } finally { client.release(); }
    }
    const user = toUser({ id: randomUUID(), username, passwordHash, avatar, points, active: true, sessionVersion: 1, gamesPlayed: 0, successfulRounds: 0, bestMultiplier: 0, createdAt: new Date().toISOString() });
    this.users.set(user.id, user);
    this.transactions.unshift({ id: randomUUID(), userId: user.id, roundId: null, type: 'STARTING_POINTS', amount: points, balanceAfter: points, note: 'Demo starting points', createdAt: new Date().toISOString() });
    this.addNotification(user.id, 'Welcome to Skyline', 'Your points are virtual and stay inside this sandbox.');
    return user;
  }

  async findUserByUsername(username) {
    if (this.pool) {
      const { rows } = await this.pool.query(`SELECT ${USER_FIELDS} FROM users WHERE lower(username)=lower($1) LIMIT 1`, [username]);
      return toUser(rows[0]);
    }
    return [...this.users.values()].find((u) => u.username.toLowerCase() === username.toLowerCase()) || null;
  }
  async getUserById(id) {
    if (this.pool) {
      const { rows } = await this.pool.query(`SELECT ${USER_FIELDS} FROM users WHERE id=$1`, [id]);
      return toUser(rows[0]);
    }
    return this.users.get(id) || null;
  }
  async findAdminByUsername(username) {
    if (this.pool) {
      const { rows } = await this.pool.query(`SELECT ${ADMIN_FIELDS} FROM admins WHERE lower(username)=lower($1) LIMIT 1`, [username]);
      return toAdmin(rows[0]);
    }
    return [...this.admins.values()].find((a) => a.username.toLowerCase() === username.toLowerCase()) || null;
  }
  async getAdminById(id) {
    if (id === 'demo-admin') return { id, username: 'Demo admin', role: 'superadmin', active: true, sessionVersion: 1 };
    if (this.pool) {
      const { rows } = await this.pool.query(`SELECT ${ADMIN_FIELDS} FROM admins WHERE id=$1`, [id]);
      return toAdmin(rows[0]);
    }
    return this.admins.get(id) || null;
  }
  async createAdmin({ username, passwordHash, role = 'superadmin' }) {
    if (this.pool) {
      const { rows } = await this.pool.query(`INSERT INTO admins(username,password_hash,role) VALUES($1,$2,$3) RETURNING ${ADMIN_FIELDS}`, [username, passwordHash, role]);
      return toAdmin(rows[0]);
    }
    const admin = toAdmin({ id: randomUUID(), username, passwordHash, role, active: true, sessionVersion: 1, createdAt: new Date().toISOString() });
    this.admins.set(admin.id, admin);
    return admin;
  }
  async changeAdminPassword(id, passwordHash) {
    if (this.pool) {
      await this.pool.query('UPDATE admins SET password_hash=$2, session_version=session_version+1, updated_at=now() WHERE id=$1', [id, passwordHash]);
      return this.getAdminById(id);
    }
    const admin = this.admins.get(id);
    if (admin) { admin.passwordHash = passwordHash; admin.sessionVersion += 1; }
    return admin || null;
  }
  async revokeAdminSessions(id) {
    if (this.pool) {
      const { rows } = await this.pool.query('UPDATE admins SET session_version=session_version+1, updated_at=now() WHERE id=$1 RETURNING session_version AS "sessionVersion"', [id]);
      return Number(rows[0]?.sessionVersion || 1);
    }
    const admin = this.admins.get(id);
    if (admin) admin.sessionVersion += 1;
    return admin?.sessionVersion || 1;
  }

  async updateProfile(id, { username, avatar }) {
    if (this.pool) {
      const { rows } = await this.pool.query(`UPDATE users SET username=COALESCE($2,username), avatar=COALESCE($3,avatar), updated_at=now() WHERE id=$1 RETURNING ${USER_FIELDS}`, [id, username || null, avatar || null]);
      return toUser(rows[0]);
    }
    const user = this.users.get(id);
    if (!user) return null;
    if (username) user.username = username;
    if (avatar) user.avatar = avatar;
    return user;
  }
  async setUserActive(id, active) {
    if (this.pool) {
      const { rows } = await this.pool.query(`UPDATE users SET is_active=$2, updated_at=now() WHERE id=$1 RETURNING ${USER_FIELDS}`, [id, active]);
      return toUser(rows[0]);
    }
    const user = this.users.get(id);
    if (user) user.active = Boolean(active);
    return user || null;
  }
  async revokeUserSessions(id) {
    if (this.pool) {
      const { rows } = await this.pool.query('UPDATE users SET session_version=session_version+1, updated_at=now() WHERE id=$1 RETURNING session_version AS "sessionVersion"', [id]);
      return Number(rows[0]?.sessionVersion || 1);
    }
    const user = this.users.get(id);
    if (user) user.sessionVersion += 1;
    return user?.sessionVersion || 1;
  }

  async createRound(roundCode) {
    if (this.pool) {
      const { rows } = await this.pool.query(`INSERT INTO game_rounds(round_code,status) VALUES($1,'WAITING') RETURNING id, round_code AS "roundId", status, started_at AS "startedAt", ended_at AS "endedAt", crash_multiplier AS "crashMultiplier", created_at AS "createdAt"`, [roundCode]);
      return rows[0];
    }
    const round = { id: randomUUID(), roundId: roundCode, status: 'WAITING', startedAt: null, endedAt: null, crashMultiplier: null, createdAt: new Date().toISOString() };
    this.rounds.set(roundCode, round);
    this.bets.set(roundCode, new Map());
    return round;
  }
  async updateRound(roundCode, patch) {
    if (this.pool) {
      const { rows } = await this.pool.query(`UPDATE game_rounds SET status=COALESCE($2,status), started_at=COALESCE($3,started_at), ended_at=COALESCE($4,ended_at), crash_multiplier=COALESCE($5,crash_multiplier), updated_at=now() WHERE round_code=$1 RETURNING id, round_code AS "roundId", status, started_at AS "startedAt", ended_at AS "endedAt", crash_multiplier AS "crashMultiplier", created_at AS "createdAt"`, [roundCode, patch.status || null, patch.startedAt || null, patch.endedAt || null, patch.crashMultiplier ?? null]);
      return rows[0] || null;
    }
    const round = this.rounds.get(roundCode);
    if (round) Object.assign(round, patch);
    return round || null;
  }

  async placeBet(userId, roundCode, pointsUsed) {
    if (this.pool) {
      const client = await this.pool.connect();
      try {
        await client.query('BEGIN');
        const userRes = await client.query('SELECT virtual_points AS points,is_active AS active FROM users WHERE id=$1 FOR UPDATE', [userId]);
        const user = userRes.rows[0];
        if (!user || !user.active) throw Object.assign(new Error('This account is not active.'), { status: 403, code: 'ACCOUNT_INACTIVE' });
        const roundRes = await client.query('SELECT id FROM game_rounds WHERE round_code=$1 AND status IN (\'WAITING\',\'COUNTDOWN\')', [roundCode]);
        if (!roundRes.rows[0]) throw Object.assign(new Error('This round is no longer accepting players.'), { status: 409, code: 'ROUND_CLOSED' });
        const existing = await client.query('SELECT id FROM game_history WHERE user_id=$1 AND round_id=$2', [userId, roundRes.rows[0].id]);
        if (existing.rows[0]) throw Object.assign(new Error('You already joined this round.'), { status: 409, code: 'ALREADY_JOINED' });
        if (Number(user.points) < pointsUsed) throw Object.assign(new Error('Not enough virtual points.'), { status: 400, code: 'INSUFFICIENT_POINTS' });
        const balance = Number(user.points) - pointsUsed;
        await client.query('UPDATE users SET virtual_points=$2,games_played=games_played+1,updated_at=now() WHERE id=$1', [userId, balance]);
        await client.query('INSERT INTO player_sessions(user_id,round_id,points_used) VALUES($1,$2,$3)', [userId, roundRes.rows[0].id, pointsUsed]);
        await client.query('INSERT INTO game_history(user_id,round_id,action,result,points_used) VALUES($1,$2,\'PLAY\',\'PENDING\',$3)', [userId, roundRes.rows[0].id, pointsUsed]);
        await client.query('INSERT INTO virtual_point_transactions(user_id,round_id,type,amount,balance_after,note) VALUES($1,$2,\'PLAY\',$3,$4,$5)', [userId, roundRes.rows[0].id, -pointsUsed, balance, 'Joined virtual round']);
        await client.query('COMMIT');
        return { balance, pointsUsed };
      } catch (error) { await client.query('ROLLBACK'); throw error; } finally { client.release(); }
    }
    const user = this.users.get(userId);
    if (!user || !user.active) throw Object.assign(new Error('This account is not active.'), { status: 403, code: 'ACCOUNT_INACTIVE' });
    const round = this.rounds.get(roundCode);
    if (!round || !['WAITING', 'COUNTDOWN'].includes(round.status)) throw Object.assign(new Error('This round is no longer accepting players.'), { status: 409, code: 'ROUND_CLOSED' });
    const map = this.bets.get(roundCode) || new Map();
    if (map.has(userId)) throw Object.assign(new Error('You already joined this round.'), { status: 409, code: 'ALREADY_JOINED' });
    if (user.points < pointsUsed) throw Object.assign(new Error('Not enough virtual points.'), { status: 400, code: 'INSUFFICIENT_POINTS' });
    user.points -= pointsUsed;
    user.gamesPlayed += 1;
    const bet = { id: randomUUID(), userId, roundId: roundCode, pointsUsed, pointsCollected: 0, finalMultiplier: null, result: 'PENDING', action: 'PLAY', createdAt: new Date().toISOString() };
    map.set(userId, bet);
    this.bets.set(roundCode, map);
    this.history.unshift(bet);
    this.transactions.unshift({ id: randomUUID(), userId, roundId: roundCode, type: 'PLAY', amount: -pointsUsed, balanceAfter: user.points, note: 'Joined virtual round', createdAt: new Date().toISOString() });
    return { balance: user.points, pointsUsed };
  }

  async collectBet(userId, roundCode, multiplier) {
    if (this.pool) {
      const client = await this.pool.connect();
      try {
        await client.query('BEGIN');
        const roundRes = await client.query('SELECT id FROM game_rounds WHERE round_code=$1 AND status=\'RUNNING\' FOR UPDATE', [roundCode]);
        if (!roundRes.rows[0]) throw Object.assign(new Error('The round is not running.'), { status: 409, code: 'ROUND_NOT_RUNNING' });
        const historyRes = await client.query('SELECT id,points_used AS "pointsUsed" FROM game_history WHERE user_id=$1 AND round_id=$2 AND result=\'PENDING\' FOR UPDATE', [userId, roundRes.rows[0].id]);
        if (!historyRes.rows[0]) throw Object.assign(new Error('No active points to collect in this round.'), { status: 409, code: 'NO_ACTIVE_PLAY' });
        const pointsUsed = Number(historyRes.rows[0].pointsUsed);
        const payout = calculatePayout(pointsUsed, multiplier);
        const userRes = await client.query('UPDATE users SET virtual_points=virtual_points+$2,successful_rounds=successful_rounds+1,best_multiplier=GREATEST(best_multiplier,$3),updated_at=now() WHERE id=$1 RETURNING virtual_points AS points', [userId, payout, multiplier]);
        await client.query('UPDATE game_history SET action=\'COLLECT\',result=\'COLLECTED\',points_collected=$2,final_multiplier=$3,updated_at=now() WHERE id=$1', [historyRes.rows[0].id, payout, multiplier]);
        await client.query('UPDATE player_sessions SET status=\'COLLECTED\',points_collected=$3,current_multiplier=$4,collected_at=now() WHERE user_id=$1 AND round_id=$2', [userId, roundRes.rows[0].id, payout, multiplier]);
        await client.query('INSERT INTO virtual_point_transactions(user_id,round_id,type,amount,balance_after,note) VALUES($1,$2,\'COLLECT\',$3,$4,$5)', [userId, roundRes.rows[0].id, payout, Number(userRes.rows[0].points), `Collected at ${multiplier.toFixed(2)}x`]);
        await client.query('COMMIT');
        return { balance: Number(userRes.rows[0].points), pointsUsed, pointsCollected: payout, multiplier };
      } catch (error) { await client.query('ROLLBACK'); throw error; } finally { client.release(); }
    }
    const bet = this.bets.get(roundCode)?.get(userId);
    const user = this.users.get(userId);
    if (!bet || bet.result !== 'PENDING' || !user) throw Object.assign(new Error('No active points to collect in this round.'), { status: 409, code: 'NO_ACTIVE_PLAY' });
    const payout = calculatePayout(bet.pointsUsed, multiplier);
    user.points += payout;
    user.successfulRounds += 1;
    user.bestMultiplier = Math.max(user.bestMultiplier, multiplier);
    Object.assign(bet, { result: 'COLLECTED', action: 'COLLECT', pointsCollected: payout, finalMultiplier: multiplier, updatedAt: new Date().toISOString() });
    this.transactions.unshift({ id: randomUUID(), userId, roundId: roundCode, type: 'COLLECT', amount: payout, balanceAfter: user.points, note: `Collected at ${multiplier.toFixed(2)}x`, createdAt: new Date().toISOString() });
    return { balance: user.points, pointsUsed: bet.pointsUsed, pointsCollected: payout, multiplier };
  }

  async crashPendingBets(roundCode, crashMultiplier) {
    if (this.pool) {
      const { rows } = await this.pool.query('SELECT id FROM game_rounds WHERE round_code=$1', [roundCode]);
      if (!rows[0]) return;
      await this.pool.query('UPDATE game_history SET action=\'CRASH\',result=\'CRASHED\',final_multiplier=$2,updated_at=now() WHERE round_id=$1 AND result=\'PENDING\'', [rows[0].id, crashMultiplier]);
      await this.pool.query('UPDATE player_sessions SET status=\'CRASHED\',current_multiplier=$2 WHERE round_id=$1 AND status=\'PLAYING\'', [rows[0].id, crashMultiplier]);
      return;
    }
    const map = this.bets.get(roundCode);
    if (!map) return;
    for (const bet of map.values()) if (bet.result === 'PENDING') Object.assign(bet, { result: 'CRASHED', action: 'CRASH', finalMultiplier: crashMultiplier, updatedAt: new Date().toISOString() });
  }

  async getRoundPlayers(roundCode) {
    if (this.pool) {
      const { rows } = await this.pool.query(`SELECT u.username,u.avatar,ps.points_used AS "pointsUsed",ps.points_collected AS "pointsCollected",ps.status,ps.current_multiplier AS multiplier FROM player_sessions ps JOIN game_rounds gr ON gr.id=ps.round_id JOIN users u ON u.id=ps.user_id WHERE gr.round_code=$1 ORDER BY ps.joined_at DESC LIMIT 30`, [roundCode]);
      return rows.map((r) => ({ ...r, pointsUsed: Number(r.pointsUsed), pointsCollected: Number(r.pointsCollected), multiplier: Number(r.multiplier) }));
    }
    const map = this.bets.get(roundCode) || new Map();
    return [...map.values()].map((bet) => {
      const user = this.users.get(bet.userId);
      return { username: user?.username || 'Pilot', avatar: user?.avatar || '✦', pointsUsed: bet.pointsUsed, pointsCollected: bet.pointsCollected, status: bet.result, multiplier: bet.finalMultiplier || 1 };
    });
  }

  async getPlayerRound(userId, roundCode) {
    if (this.pool) {
      const { rows } = await this.pool.query(`SELECT gh.id,gr.round_code AS \"roundId\",gh.result,gh.points_used AS \"pointsUsed\",gh.points_collected AS \"pointsCollected\",gh.final_multiplier AS \"finalMultiplier\" FROM game_history gh JOIN game_rounds gr ON gr.id=gh.round_id WHERE gh.user_id=$1 AND gr.round_code=$2 LIMIT 1`, [userId, roundCode]);
      if (!rows[0]) return null;
      const r = rows[0];
      return { ...r, pointsUsed: Number(r.pointsUsed), pointsCollected: Number(r.pointsCollected), finalMultiplier: r.finalMultiplier == null ? null : Number(r.finalMultiplier) };
    }
    return this.bets.get(roundCode)?.get(userId) || null;
  }

  async addNotification(userId, title, body) {
    if (this.pool) {
      const { rows } = await this.pool.query('INSERT INTO notifications(user_id,title,body) VALUES($1,$2,$3) RETURNING id,title,body,created_at AS "createdAt",read_at AS "readAt"', [userId, title, body]);
      return rows[0];
    }
    const notification = { id: randomUUID(), userId, title, body, createdAt: new Date().toISOString(), readAt: null };
    this.notifications.unshift(notification);
    return notification;
  }
  async getNotifications(userId) {
    if (this.pool) {
      const { rows } = await this.pool.query('SELECT id,title,body,created_at AS "createdAt",read_at AS "readAt" FROM notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT 20', [userId]);
      return rows;
    }
    return this.notifications.filter((n) => n.userId === userId).slice(0, 20);
  }

  async getUserHistory(userId, period = '30d') {
    const start = periodStart(period);
    if (this.pool) {
      const { rows } = await this.pool.query(`SELECT gh.id,gr.round_code AS "roundId",gr.created_at AS "roundDate",gh.created_at AS "createdAt",gh.action,gh.result,gh.points_used AS "pointsUsed",gh.points_collected AS "pointsCollected",gh.final_multiplier AS "finalMultiplier" FROM game_history gh JOIN game_rounds gr ON gr.id=gh.round_id WHERE gh.user_id=$1 AND ($2::timestamptz IS NULL OR gh.created_at >= $2) ORDER BY gh.created_at DESC LIMIT 100`, [userId, start]);
      return rows.map((r) => ({ ...r, pointsUsed: Number(r.pointsUsed), pointsCollected: Number(r.pointsCollected), finalMultiplier: r.finalMultiplier == null ? null : Number(r.finalMultiplier) }));
    }
    return this.history.filter((h) => h.userId === userId && (!start || new Date(h.createdAt) >= start)).slice(0, 100).map((h) => ({ ...h, roundDate: this.rounds.get(h.roundId)?.createdAt || h.createdAt }));
  }
  async getRoundHistory(limit = 30) {
    if (this.pool) {
      const { rows } = await this.pool.query(`SELECT id,round_code AS "roundId",status,started_at AS "startedAt",ended_at AS "endedAt",crash_multiplier AS "crashMultiplier",created_at AS "createdAt" FROM game_rounds ORDER BY created_at DESC LIMIT $1`, [limit]);
      return rows.map((r) => ({ ...r, crashMultiplier: r.crashMultiplier == null ? null : Number(r.crashMultiplier) }));
    }
    return [...this.rounds.values()].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, limit);
  }
  async getLeaderboard(limit = 10) {
    if (this.pool) {
      const { rows } = await this.pool.query(`SELECT id,username,avatar,virtual_points AS points,games_played AS "gamesPlayed",best_multiplier AS "bestMultiplier",successful_rounds AS "successfulRounds" FROM users WHERE is_active=true ORDER BY virtual_points DESC,successful_rounds DESC LIMIT $1`, [limit]);
      return rows.map((r) => ({ ...r, points: Number(r.points), gamesPlayed: Number(r.gamesPlayed), bestMultiplier: Number(r.bestMultiplier), successfulRounds: Number(r.successfulRounds) }));
    }
    return [...this.users.values()].filter((u) => u.active).sort((a, b) => b.points - a.points).slice(0, limit).map(({ id, username, avatar, points, gamesPlayed, bestMultiplier, successfulRounds }) => ({ id, username, avatar, points, gamesPlayed, bestMultiplier, successfulRounds }));
  }

  async getDashboardStats() {
    if (this.pool) {
      const [users, activity, rounds, games] = await Promise.all([
        this.pool.query('SELECT count(*)::int AS total,count(*) FILTER (WHERE is_active)::int AS active FROM users'),
        this.pool.query("SELECT count(DISTINCT actor_id)::int AS active FROM activity_logs WHERE actor_type='USER' AND action IN ('user.login','user.demo_session') AND created_at > now()-interval '15 minutes'"),
        this.pool.query("SELECT count(*)::int AS total,count(*) FILTER (WHERE status IN ('CRASHED','RESULT'))::int AS completed FROM game_rounds"),
        this.pool.query('SELECT count(*)::int AS total FROM game_history')
      ]);
      return { totalUsers: users.rows[0].total, enabledUsers: users.rows[0].active, activeUsers: activity.rows[0].active, completedRounds: rounds.rows[0].completed, totalRounds: rounds.rows[0].total, totalGames: games.rows[0].total, systemStatus: 'Operational' };
    }
    const userList = [...this.users.values()];
    const activeLogs = this.activity.filter((a) => a.actorType === 'USER' && ['user.login', 'user.demo_session'].includes(a.action) && Date.now() - new Date(a.createdAt).getTime() < 15 * 60 * 1000);
    const rounds = [...this.rounds.values()];
    return { totalUsers: userList.length, enabledUsers: userList.filter((u) => u.active).length, activeUsers: new Set(activeLogs.map((a) => a.actorId)).size, completedRounds: rounds.filter((r) => ['CRASHED', 'RESULT'].includes(r.status)).length, totalRounds: rounds.length, totalGames: this.history.length, systemStatus: 'Operational' };
  }

  async listUsers(search = '', limit = 50) {
    if (this.pool) {
      const term = `%${search.trim()}%`;
      const { rows } = await this.pool.query(`SELECT ${USER_FIELDS} FROM users WHERE ($1='' OR username ILIKE $2) ORDER BY created_at DESC LIMIT $3`, [search.trim(), term, Math.min(limit, 100)]);
      return rows.map(toUser);
    }
    return [...this.users.values()].filter((u) => !search || u.username.toLowerCase().includes(search.toLowerCase())).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, limit);
  }
  async getAdminUserDetail(id) {
    const user = await this.getUserById(id);
    if (!user) return null;
    const [history, transactions, activity] = await Promise.all([this.getUserHistory(id, '30d'), this.getPointTransactions(id, 20), this.getActorActivity(id, 20)]);
    return { user, history: history.slice(0, 10), transactions, activity };
  }
  async getPointTransactions(userId, limit = 20) {
    if (this.pool) {
      const { rows } = await this.pool.query(`SELECT id,type,amount,balance_after AS "balanceAfter",note,created_at AS "createdAt" FROM virtual_point_transactions WHERE user_id=$1 ORDER BY created_at DESC LIMIT $2`, [userId, limit]);
      return rows.map((r) => ({ ...r, amount: Number(r.amount), balanceAfter: Number(r.balanceAfter) }));
    }
    return this.transactions.filter((t) => t.userId === userId).slice(0, limit);
  }
  async getActorActivity(actorId, limit = 20) {
    if (this.pool) {
      const { rows } = await this.pool.query('SELECT id,actor_type AS "actorType",actor_id AS "actorId",action,details,created_at AS "createdAt" FROM activity_logs WHERE actor_id=$1 ORDER BY created_at DESC LIMIT $2', [actorId, limit]);
      return rows;
    }
    return this.activity.filter((item) => item.actorId === actorId).slice(0, limit);
  }
  async getActivity(limit = 100) {
    if (this.pool) {
      const { rows } = await this.pool.query('SELECT id,actor_type AS "actorType",actor_id AS "actorId",action,details,created_at AS "createdAt" FROM activity_logs ORDER BY created_at DESC LIMIT $1', [Math.min(limit, 200)]);
      return rows;
    }
    return this.activity.slice(0, limit);
  }
  async logActivity({ actorType = 'SYSTEM', actorId = null, action, details = {}, ipAddress = null }) {
    if (this.pool) {
      const validActorId = actorId && actorId !== 'demo-admin' ? actorId : null;
      const ip = typeof ipAddress === 'string' ? ipAddress.replace(/^::ffff:/, '') : null;
      await this.pool.query('INSERT INTO activity_logs(actor_type,actor_id,action,details,ip_address) VALUES($1,$2,$3,$4::jsonb,$5::inet)', [actorType, validActorId, action, JSON.stringify(details), ip]);
      return;
    }
    this.activity.unshift({ id: randomUUID(), actorType, actorId, action, details, createdAt: new Date().toISOString() });
  }

  async getSettings() {
    if (this.pool) {
      const { rows } = await this.pool.query('SELECT key,value FROM system_settings');
      return { ...DEFAULT_SETTINGS, ...Object.fromEntries(rows.map((r) => [r.key, r.value])) };
    }
    return { ...this.settings };
  }
  async updateSettings(patch, actorId = null) {
    const allowed = Object.keys(DEFAULT_SETTINGS);
    const safe = Object.fromEntries(Object.entries(patch).filter(([key]) => allowed.includes(key)));
    if (this.pool) {
      for (const [key, value] of Object.entries(safe)) {
        await this.pool.query('INSERT INTO system_settings(key,value,updated_by) VALUES($1,$2::jsonb,$3) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_by=EXCLUDED.updated_by,updated_at=now()', [key, JSON.stringify(value), actorId && actorId !== 'demo-admin' ? actorId : null]);
      }
      return this.getSettings();
    }
    this.settings = { ...this.settings, ...safe };
    return this.getSettings();
  }
  async getReports(period = '7d') {
    const start = periodStart(period === 'today' ? 'today' : period === '30d' ? '30d' : '7d');
    if (this.pool) {
      const { rows } = await this.pool.query(`SELECT date_trunc('day',created_at) AS day,count(*)::int AS games,count(*) FILTER (WHERE result='COLLECTED')::int AS successful,count(DISTINCT user_id)::int AS users,COALESCE(sum(points_used),0)::bigint AS "pointsUsed",COALESCE(sum(points_collected),0)::bigint AS "pointsCollected" FROM game_history WHERE created_at >= $1 GROUP BY 1 ORDER BY 1`, [start]);
      return rows.map((r) => ({ ...r, day: r.day, games: Number(r.games), successful: Number(r.successful), users: Number(r.users), pointsUsed: Number(r.pointsUsed), pointsCollected: Number(r.pointsCollected) }));
    }
    const grouped = new Map();
    for (const h of this.history) {
      if (new Date(h.createdAt) < start) continue;
      const day = new Date(h.createdAt).toISOString().slice(0, 10);
      const current = grouped.get(day) || { day, games: 0, successful: 0, usersSet: new Set(), pointsUsed: 0, pointsCollected: 0 };
      current.games += 1;
      if (h.result === 'COLLECTED') current.successful += 1;
      current.usersSet.add(h.userId);
      current.pointsUsed += h.pointsUsed;
      current.pointsCollected += h.pointsCollected || 0;
      grouped.set(day, current);
    }
    return [...grouped.values()].sort((a, b) => a.day.localeCompare(b.day)).map(({ usersSet, ...r }) => ({ ...r, users: usersSet.size }));
  }
}

module.exports = { Store, DEFAULT_SETTINGS, periodStart };
