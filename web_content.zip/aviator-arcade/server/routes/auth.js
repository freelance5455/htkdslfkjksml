const express = require('express');
const bcrypt = require('bcryptjs');
const { randomBytes } = require('node:crypto');
const { z } = require('zod');
const { rateLimit } = require('express-rate-limit');

const credentialsSchema = z.object({
  username: z.string().trim().min(3).max(24).regex(/^[a-zA-Z0-9_.-]+$/, 'Use letters, numbers, dots, dashes, or underscores.'),
  password: z.string().min(10).max(128)
});

function publicUser(user) {
  return { id: user.id, username: user.username, avatar: user.avatar, points: user.points, active: user.active, gamesPlayed: user.gamesPlayed, successfulRounds: user.successfulRounds, bestMultiplier: user.bestMultiplier, createdAt: user.createdAt };
}
function regenerateSession(req, values) {
  return new Promise((resolve, reject) => {
    req.session.regenerate((error) => {
      if (error) return reject(error);
      Object.assign(req.session, values);
      req.session.save((saveError) => saveError ? reject(saveError) : resolve());
    });
  });
}

function createAuthRouter({ store, config }) {
  const router = express.Router();
  const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Too many sign-in attempts. Please wait a little and try again.' } });

  router.post('/register', authLimiter, async (req, res, next) => {
    try {
      const parsed = credentialsSchema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0]?.message || 'Please check your details.' });
      const { username, password } = parsed.data;
      if (await store.findUserByUsername(username)) return res.status(409).json({ error: 'That username is already in use.' });
      const passwordHash = await bcrypt.hash(password, 12);
      const user = await store.createUser({ username, passwordHash, points: 10000 });
      await regenerateSession(req, { userId: user.id, userVersion: user.sessionVersion });
      await store.logActivity({ actorType: 'USER', actorId: user.id, action: 'user.register', ipAddress: req.ip });
      res.status(201).json({ user: publicUser(user) });
    } catch (error) {
      if (error.code === '23505') return res.status(409).json({ error: 'That username is already in use.' });
      next(error);
    }
  });

  router.post('/login', authLimiter, async (req, res, next) => {
    try {
      const parsed = credentialsSchema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ error: 'Username or password is invalid.' });
      const user = await store.findUserByUsername(parsed.data.username);
      if (!user || !user.active || !await bcrypt.compare(parsed.data.password, user.passwordHash || '')) return res.status(401).json({ error: 'Username or password is incorrect.' });
      await regenerateSession(req, { userId: user.id, userVersion: user.sessionVersion });
      await store.logActivity({ actorType: 'USER', actorId: user.id, action: 'user.login', ipAddress: req.ip });
      res.json({ user: publicUser(user) });
    } catch (error) { next(error); }
  });

  router.post('/demo', async (req, res, next) => {
    try {
      if (!config.demoMode) return res.status(404).json({ error: 'Demo sign-in is disabled.' });
      const suffix = randomBytes(3).toString('hex');
      const username = `pilot_${suffix}`;
      const passwordHash = await bcrypt.hash(randomBytes(32).toString('hex'), 10);
      const user = await store.createUser({ username, passwordHash, avatar: ['✦', '◈', '✧', '✺'][Math.floor(Math.random() * 4)], points: 10000 });
      await regenerateSession(req, { userId: user.id, userVersion: user.sessionVersion });
      await store.logActivity({ actorType: 'USER', actorId: user.id, action: 'user.demo_session', ipAddress: req.ip });
      res.status(201).json({ user: publicUser(user), demo: true });
    } catch (error) { next(error); }
  });

  router.get('/me', async (req, res, next) => {
    try {
      if (!req.session?.userId) return res.json({ user: null });
      const user = await store.getUserById(req.session.userId);
      if (!user || !user.active || Number(req.session.userVersion) !== Number(user.sessionVersion)) {
        req.session.destroy(() => {});
        return res.json({ user: null });
      }
      res.json({ user: publicUser(user) });
    } catch (error) { next(error); }
  });

  router.post('/logout', (req, res, next) => {
    const actorId = req.session?.userId;
    if (actorId) store.logActivity({ actorType: 'USER', actorId, action: 'user.logout', ipAddress: req.ip }).catch(() => {});
    req.session.destroy((error) => {
      if (error) return next(error);
      res.clearCookie('skyline.sid', { httpOnly: true, sameSite: 'lax', secure: config.production });
      res.json({ ok: true });
    });
  });

  return router;
}

module.exports = { createAuthRouter, publicUser, regenerateSession };
