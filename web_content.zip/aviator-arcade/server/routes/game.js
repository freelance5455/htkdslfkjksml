const express = require('express');
const { z } = require('zod');
const { requireUser } = require('../middleware/security');

function createGameRouter({ store, engine }) {
  const router = express.Router();
  router.use(requireUser(store));

  router.get('/current', async (req, res, next) => {
    try {
      const state = engine.snapshot();
      const myPlay = state.roundId ? await store.getPlayerRound(req.user.id, state.roundId) : null;
      res.json({ ...state, myPlay: myPlay ? { result: myPlay.result, pointsUsed: myPlay.pointsUsed, pointsCollected: myPlay.pointsCollected, finalMultiplier: myPlay.finalMultiplier } : null });
    } catch (error) { next(error); }
  });

  router.get('/history', async (req, res, next) => {
    try { res.json({ rounds: await store.getRoundHistory(24) }); } catch (error) { next(error); }
  });

  router.post('/play', async (req, res, next) => {
    try {
      const parsed = z.object({ pointsUsed: z.number().int().min(1).max(1000000) }).safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ error: 'Choose a valid amount of virtual points.' });
      const result = await engine.placeBet(req.user, parsed.data.pointsUsed);
      await store.logActivity({ actorType: 'USER', actorId: req.user.id, action: 'game.play', details: { roundId: result.roundId, pointsUsed: result.pointsUsed }, ipAddress: req.ip });
      res.status(201).json(result);
    } catch (error) { next(error); }
  });

  router.post('/collect', async (req, res, next) => {
    try {
      const result = await engine.collect(req.user);
      await store.addNotification(req.user.id, 'Points collected', `${result.pointsCollected.toLocaleString()} virtual points were added to your balance.`);
      await store.logActivity({ actorType: 'USER', actorId: req.user.id, action: 'game.collect', details: { roundId: result.roundId, multiplier: result.multiplier, pointsCollected: result.pointsCollected }, ipAddress: req.ip });
      res.json(result);
    } catch (error) { next(error); }
  });
  return router;
}

module.exports = { createGameRouter };
