const express = require('express');
const { z } = require('zod');
const { requireUser } = require('../middleware/security');
const { publicUser } = require('./auth');

function createUserRouter({ store }) {
  const router = express.Router();
  router.use(requireUser(store));

  router.get('/profile', (req, res) => res.json({ user: publicUser(req.user) }));
  router.patch('/profile', async (req, res, next) => {
    try {
      const schema = z.object({ username: z.string().trim().min(3).max(24).regex(/^[a-zA-Z0-9_.-]+$/).optional(), avatar: z.enum(['✦', '◈', '✧', '✺', '◉', '⬡']).optional() }).refine((value) => Object.keys(value).length > 0);
      const parsed = schema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ error: 'Please choose a valid username or avatar.' });
      if (parsed.data.username && parsed.data.username.toLowerCase() !== req.user.username.toLowerCase()) {
        const existing = await store.findUserByUsername(parsed.data.username);
        if (existing) return res.status(409).json({ error: 'That username is already in use.' });
      }
      const user = await store.updateProfile(req.user.id, parsed.data);
      await store.logActivity({ actorType: 'USER', actorId: req.user.id, action: 'user.profile_update', details: parsed.data, ipAddress: req.ip });
      res.json({ user: publicUser(user) });
    } catch (error) { if (error.code === '23505') return res.status(409).json({ error: 'That username is already in use.' }); next(error); }
  });
  router.get('/history', async (req, res, next) => {
    try {
      const period = ['today', '7d', '30d'].includes(req.query.period) ? req.query.period : '30d';
      res.json({ history: await store.getUserHistory(req.user.id, period), period });
    } catch (error) { next(error); }
  });
  router.get('/activity', async (req, res, next) => {
    try {
      const [transactions, notifications] = await Promise.all([store.getPointTransactions(req.user.id, 30), store.getNotifications(req.user.id)]);
      res.json({ transactions, notifications });
    } catch (error) { next(error); }
  });
  router.get('/notifications', async (req, res, next) => {
    try { res.json({ notifications: await store.getNotifications(req.user.id) }); } catch (error) { next(error); }
  });
  router.get('/leaderboard', async (req, res, next) => {
    try { res.json({ leaderboard: await store.getLeaderboard(20) }); } catch (error) { next(error); }
  });
  return router;
}

module.exports = { createUserRouter };
