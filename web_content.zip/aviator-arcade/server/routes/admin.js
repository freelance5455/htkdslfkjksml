const express = require('express');
const bcrypt = require('bcryptjs');
const { z } = require('zod');
const { rateLimit } = require('express-rate-limit');
const { requireAdmin, requireAdminWrite } = require('../middleware/security');
const { regenerateSession } = require('./auth');

function createAdminRouter({ store, engine, config }) {
  const router = express.Router();
  const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Too many admin sign-in attempts. Please wait and try again.' } });

  router.post('/login', loginLimiter, async (req, res, next) => {
    try {
      const parsed = z.object({ username: z.string().min(1).max(64), password: z.string().min(1).max(128) }).safeParse(req.body);
      if (!parsed.success) return res.status(401).json({ error: 'Admin username or password is incorrect.' });
      const admin = await store.findAdminByUsername(parsed.data.username);
      if (!admin || !admin.active || !await bcrypt.compare(parsed.data.password, admin.passwordHash || '')) return res.status(401).json({ error: 'Admin username or password is incorrect.' });
      await regenerateSession(req, { adminId: admin.id, adminVersion: admin.sessionVersion, adminRole: admin.role });
      await store.logActivity({ actorType: 'ADMIN', actorId: admin.id, action: 'admin.login', ipAddress: req.ip });
      res.json({ admin: { id: admin.id, username: admin.username, role: admin.role } });
    } catch (error) { next(error); }
  });

  router.post('/demo-session', async (req, res, next) => {
    try {
      if (!config.demoMode) return res.status(404).json({ error: 'Admin preview is disabled.' });
      await regenerateSession(req, { adminId: 'demo-admin', adminVersion: 1, adminRole: 'superadmin' });
      await store.logActivity({ actorType: 'ADMIN', actorId: 'demo-admin', action: 'admin.demo_session', ipAddress: req.ip });
      res.json({ admin: { id: 'demo-admin', username: 'Demo admin', role: 'superadmin' }, demo: true });
    } catch (error) { next(error); }
  });

  router.use(requireAdmin(store));
  router.get('/me', (req, res) => res.json({ admin: { id: req.admin.id, username: req.admin.username, role: req.admin.role, demo: req.admin.id === 'demo-admin' } }));
  router.post('/logout', (req, res, next) => {
    if (req.admin?.id) store.logActivity({ actorType: 'ADMIN', actorId: req.admin.id, action: 'admin.logout', ipAddress: req.ip }).catch(() => {});
    req.session.destroy((error) => {
      if (error) return next(error);
      res.clearCookie('skyline.sid', { httpOnly: true, sameSite: 'lax', secure: config.production });
      res.json({ ok: true });
    });
  });

  router.get('/dashboard', async (req, res, next) => {
    try {
      const [stats, rounds, settings] = await Promise.all([store.getDashboardStats(), store.getRoundHistory(8), store.getSettings()]);
      res.json({ stats: { ...stats, currentRound: engine.snapshot() }, rounds, settings, systemStatus: settings.maintenanceMode ? 'Maintenance' : 'Operational' });
    } catch (error) { next(error); }
  });
  router.get('/users', async (req, res, next) => {
    try {
      const search = typeof req.query.search === 'string' ? req.query.search.slice(0, 60) : '';
      const users = await store.listUsers(search, 60);
      res.json({ users: users.map(({ id, username, avatar, points, active, gamesPlayed, successfulRounds, bestMultiplier, createdAt }) => ({ id, username, avatar, points, active, gamesPlayed, successfulRounds, bestMultiplier, createdAt })) });
    } catch (error) { next(error); }
  });
  router.get('/users/:id', async (req, res, next) => {
    try {
      const detail = await store.getAdminUserDetail(req.params.id);
      if (!detail) return res.status(404).json({ error: 'User not found.' });
      const user = detail.user;
      res.json({ user: { id: user.id, username: user.username, avatar: user.avatar, points: user.points, active: user.active, gamesPlayed: user.gamesPlayed, successfulRounds: user.successfulRounds, bestMultiplier: user.bestMultiplier, createdAt: user.createdAt }, history: detail.history, transactions: detail.transactions, activity: detail.activity });
    } catch (error) { next(error); }
  });
  router.patch('/users/:id/status', requireAdminWrite, async (req, res, next) => {
    try {
      const parsed = z.object({ active: z.boolean() }).safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ error: 'A valid account status is required.' });
      const user = await store.setUserActive(req.params.id, parsed.data.active);
      if (!user) return res.status(404).json({ error: 'User not found.' });
      if (!parsed.data.active) await store.revokeUserSessions(user.id);
      await store.logActivity({ actorType: 'ADMIN', actorId: req.admin.id, action: 'admin.user_status', details: { userId: user.id, active: parsed.data.active }, ipAddress: req.ip });
      res.json({ ok: true, active: user.active });
    } catch (error) { next(error); }
  });
  router.post('/users/:id/logout-all', requireAdminWrite, async (req, res, next) => {
    try {
      const user = await store.getUserById(req.params.id);
      if (!user) return res.status(404).json({ error: 'User not found.' });
      await store.revokeUserSessions(user.id);
      await store.logActivity({ actorType: 'ADMIN', actorId: req.admin.id, action: 'admin.user_logout_all', details: { userId: user.id }, ipAddress: req.ip });
      res.json({ ok: true });
    } catch (error) { next(error); }
  });
  router.get('/games', async (req, res, next) => {
    try { res.json({ current: engine.snapshot(), rounds: await store.getRoundHistory(100) }); } catch (error) { next(error); }
  });
  router.get('/reports', async (req, res, next) => {
    try {
      const period = ['today', '7d', '30d'].includes(req.query.period) ? req.query.period : '7d';
      const reports = await store.getReports(period);
      res.json({ period, reports });
    } catch (error) { next(error); }
  });
  router.get('/activity', async (req, res, next) => {
    try { res.json({ activity: await store.getActivity(150) }); } catch (error) { next(error); }
  });
  router.get('/settings', async (req, res, next) => {
    try { res.json({ settings: await store.getSettings() }); } catch (error) { next(error); }
  });
  router.patch('/settings', requireAdminWrite, async (req, res, next) => {
    try {
      const parsed = z.object({ maintenanceMode: z.boolean().optional(), countdownSeconds: z.number().int().min(3).max(10).optional(), minStake: z.number().int().min(1).max(100000).optional(), maxStake: z.number().int().min(100).max(1000000).optional() }).refine((v) => Object.keys(v).length > 0).safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ error: 'Those settings are not valid.' });
      if (parsed.data.minStake !== undefined || parsed.data.maxStake !== undefined) {
        const current = await store.getSettings();
        const min = parsed.data.minStake ?? current.minStake;
        const max = parsed.data.maxStake ?? current.maxStake;
        if (min > max) return res.status(400).json({ error: 'Minimum stake cannot exceed maximum stake.' });
      }
      const settings = await store.updateSettings(parsed.data, req.admin.id);
      engine.countdownSeconds = Number(settings.countdownSeconds);
      engine.setMaintenance(Boolean(settings.maintenanceMode));
      await store.logActivity({ actorType: 'ADMIN', actorId: req.admin.id, action: 'admin.settings_update', details: parsed.data, ipAddress: req.ip });
      res.json({ settings });
    } catch (error) { next(error); }
  });
  router.post('/security/logout-all', requireAdminWrite, async (req, res, next) => {
    try {
      if (req.admin.id === 'demo-admin') return res.status(400).json({ error: 'Session controls are disabled in admin preview.' });
      await store.revokeAdminSessions(req.admin.id);
      await store.logActivity({ actorType: 'ADMIN', actorId: req.admin.id, action: 'admin.logout_all_sessions', ipAddress: req.ip });
      req.session.destroy(() => {});
      res.json({ ok: true });
    } catch (error) { next(error); }
  });
  router.post('/security/change-password', requireAdminWrite, async (req, res, next) => {
    try {
      if (req.admin.id === 'demo-admin') return res.status(400).json({ error: 'Password controls are disabled in admin preview.' });
      const parsed = z.object({ currentPassword: z.string().min(1).max(128), newPassword: z.string().min(14).max(128) }).safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ error: 'Use a new password with at least 14 characters.' });
      if (!await bcrypt.compare(parsed.data.currentPassword, req.admin.passwordHash || '')) return res.status(401).json({ error: 'Current password is incorrect.' });
      const passwordHash = await bcrypt.hash(parsed.data.newPassword, 12);
      await store.changeAdminPassword(req.admin.id, passwordHash);
      await store.logActivity({ actorType: 'ADMIN', actorId: req.admin.id, action: 'admin.password_change', ipAddress: req.ip });
      req.session.destroy(() => {});
      res.json({ ok: true, message: 'Password updated. Please sign in again.' });
    } catch (error) { next(error); }
  });
  return router;
}

module.exports = { createAdminRouter };
