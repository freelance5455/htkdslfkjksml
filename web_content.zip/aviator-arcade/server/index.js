require('dotenv').config();
const path = require('node:path');
const fs = require('node:fs');
const http = require('node:http');
const express = require('express');
const session = require('express-session');
const PgSession = require('connect-pg-simple')(session);
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const { rateLimit } = require('express-rate-limit');
const { Server } = require('socket.io');
const config = require('./config/env');
const { Store } = require('./services/store');
const { GameEngine } = require('./services/game-engine');
const { csrfTokenRoute, csrfProtection } = require('./middleware/security');
const { createAuthRouter } = require('./routes/auth');
const { createUserRouter } = require('./routes/user');
const { createGameRouter } = require('./routes/game');
const { createAdminRouter } = require('./routes/admin');
const { attachSocketBridge } = require('./websocket/socket');

async function createApplication() {
  const pool = config.databaseUrl ? new Pool({ connectionString: config.databaseUrl, ssl: config.pgSsl ? { rejectUnauthorized: false } : undefined, max: 10, idleTimeoutMillis: 30000 }) : null;
  if (config.production && !pool) throw new Error('PostgreSQL is required in production.');
  const store = new Store(pool);
  await store.init();

  if (pool && config.adminUsername && config.adminPassword) {
    if (config.adminPassword.length < 14) throw new Error('ADMIN_PASSWORD must be at least 14 characters for the bootstrap admin.');
    const existing = await store.findAdminByUsername(config.adminUsername);
    if (!existing) {
      const passwordHash = await bcrypt.hash(config.adminPassword, 12);
      await store.createAdmin({ username: config.adminUsername, passwordHash, role: 'superadmin' });
      console.log(`[security] Bootstrapped admin account: ${config.adminUsername}`);
    }
  }

  const app = express();
  const server = http.createServer(app);
  const io = new Server(server, { path: '/socket.io', serveClient: true, transports: ['websocket', 'polling'] });
  const engine = new GameEngine({ store, io });
  const sessionConfig = {
    name: 'skyline.sid',
    secret: config.sessionSecret,
    resave: false,
    saveUninitialized: false,
    rolling: true,
    cookie: { httpOnly: true, sameSite: 'lax', secure: config.production, maxAge: 7 * 24 * 60 * 60 * 1000, path: '/' },
    ...(pool ? { store: new PgSession({ pool, tableName: 'session', createTableIfMissing: false, pruneSessionInterval: 60 }) } : {})
  };
  const sessionMiddleware = session(sessionConfig);

  app.disable('x-powered-by');
  app.set('trust proxy', config.production ? 1 : false);
  app.use(helmet({
    crossOriginEmbedderPolicy: false,
    contentSecurityPolicy: { directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:', 'blob:'],
      connectSrc: ["'self'", 'ws:', 'wss:'],
      fontSrc: ["'self'", 'data:'],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"],
      baseUri: ["'self'"],
      formAction: ["'self'"]
    } }
  }));
  app.use(express.json({ limit: '24kb', strict: true }));
  app.use(sessionMiddleware);
  app.use('/api', rateLimit({ windowMs: 60 * 1000, limit: 240, standardHeaders: 'draft-7', legacyHeaders: false, skip: (req) => req.path === '/health' }));
  app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'skyline-arcade', mode: config.demoMode ? 'demo' : 'production', time: new Date().toISOString() }));
  app.get('/api/csrf', csrfTokenRoute);
  app.use('/api', csrfProtection);
  app.use('/api/auth', createAuthRouter({ store, config }));
  app.use('/api/user', createUserRouter({ store }));
  app.use('/api/game', createGameRouter({ store, engine }));
  app.use('/api/admin', createAdminRouter({ store, engine, config }));
  app.get('/api/leaderboard', async (_req, res, next) => {
    try { res.json({ leaderboard: await store.getLeaderboard(20) }); } catch (error) { next(error); }
  });

  const distPath = path.join(__dirname, '..', 'dist');
  if (fs.existsSync(distPath)) {
    app.use(express.static(distPath, { index: false, maxAge: config.production ? '1h' : 0 }));
    app.get('*', (req, res, next) => {
      if (req.path.startsWith('/api') || req.path.startsWith('/socket.io')) return next();
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }
  app.use((req, res) => res.status(404).json({ error: 'That route was not found.' }));
  app.use((error, _req, res, _next) => {
    const status = Number(error.status) || 500;
    if (status >= 500) console.error('[api]', error.stack || error.message);
    res.status(status).json({ error: status >= 500 ? 'Something went wrong on the server. Please try again.' : error.message, code: error.code || undefined });
  });

  attachSocketBridge(io, sessionMiddleware, engine, store);
  await engine.syncSettings();
  engine.start();
  server.listen(config.port, '0.0.0.0', () => {
    console.log(`[api] Skyline Arcade API listening on 0.0.0.0:${config.port}${config.demoMode ? ' (demo mode)' : ''}`);
  });

  const shutdown = async () => {
    console.log('[api] Shutting down…');
    await engine.stop();
    io.close();
    server.close(async () => {
      if (pool) await pool.end();
      process.exit(0);
    });
    setTimeout(() => process.exit(1), 8000).unref();
  };
  process.once('SIGTERM', shutdown);
  process.once('SIGINT', shutdown);
  return { app, server, io, engine, store, pool };
}

createApplication().catch((error) => {
  console.error('[startup]', error.message);
  process.exit(1);
});
