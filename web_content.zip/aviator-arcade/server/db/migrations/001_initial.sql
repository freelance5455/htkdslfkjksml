CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username varchar(24) NOT NULL UNIQUE,
  password_hash text NOT NULL,
  avatar varchar(12) NOT NULL DEFAULT '✦',
  virtual_points bigint NOT NULL DEFAULT 10000 CHECK (virtual_points >= 0),
  is_active boolean NOT NULL DEFAULT true,
  session_version integer NOT NULL DEFAULT 1,
  games_played integer NOT NULL DEFAULT 0,
  successful_rounds integer NOT NULL DEFAULT 0,
  best_multiplier numeric(10,2) NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS users_username_lower_idx ON users (lower(username));
CREATE INDEX IF NOT EXISTS users_points_rank_idx ON users (virtual_points DESC);
CREATE INDEX IF NOT EXISTS users_created_idx ON users (created_at DESC);

CREATE TABLE IF NOT EXISTS admins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username varchar(64) NOT NULL UNIQUE,
  password_hash text NOT NULL,
  role varchar(24) NOT NULL DEFAULT 'admin' CHECK (role IN ('admin', 'superadmin', 'support')),
  is_active boolean NOT NULL DEFAULT true,
  session_version integer NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS admins_username_lower_idx ON admins (lower(username));

CREATE TABLE IF NOT EXISTS game_rounds (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  round_code varchar(24) NOT NULL UNIQUE,
  status varchar(16) NOT NULL CHECK (status IN ('WAITING', 'COUNTDOWN', 'RUNNING', 'CRASHED', 'RESULT')),
  started_at timestamptz,
  ended_at timestamptz,
  crash_multiplier numeric(10,2),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS game_rounds_created_idx ON game_rounds (created_at DESC);
CREATE INDEX IF NOT EXISTS game_rounds_status_idx ON game_rounds (status, created_at DESC);

CREATE TABLE IF NOT EXISTS player_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  round_id uuid NOT NULL REFERENCES game_rounds(id) ON DELETE CASCADE,
  status varchar(16) NOT NULL DEFAULT 'PLAYING' CHECK (status IN ('PLAYING', 'COLLECTED', 'CRASHED')),
  points_used bigint NOT NULL CHECK (points_used > 0),
  points_collected bigint NOT NULL DEFAULT 0 CHECK (points_collected >= 0),
  current_multiplier numeric(10,2) NOT NULL DEFAULT 1,
  joined_at timestamptz NOT NULL DEFAULT now(),
  collected_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, round_id)
);
CREATE INDEX IF NOT EXISTS player_sessions_round_idx ON player_sessions (round_id, joined_at DESC);
CREATE INDEX IF NOT EXISTS player_sessions_user_idx ON player_sessions (user_id, joined_at DESC);

CREATE TABLE IF NOT EXISTS game_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  round_id uuid NOT NULL REFERENCES game_rounds(id) ON DELETE CASCADE,
  action varchar(16) NOT NULL DEFAULT 'PLAY',
  result varchar(16) NOT NULL DEFAULT 'PENDING' CHECK (result IN ('PENDING', 'COLLECTED', 'CRASHED')),
  points_used bigint NOT NULL CHECK (points_used > 0),
  points_collected bigint NOT NULL DEFAULT 0 CHECK (points_collected >= 0),
  final_multiplier numeric(10,2),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, round_id)
);
CREATE INDEX IF NOT EXISTS game_history_user_created_idx ON game_history (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS game_history_round_idx ON game_history (round_id, result);

CREATE TABLE IF NOT EXISTS virtual_point_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  round_id uuid REFERENCES game_rounds(id) ON DELETE SET NULL,
  type varchar(24) NOT NULL CHECK (type IN ('STARTING_POINTS', 'PLAY', 'COLLECT', 'ADMIN_GRANT', 'ADMIN_ADJUSTMENT')),
  amount bigint NOT NULL,
  balance_after bigint NOT NULL CHECK (balance_after >= 0),
  note varchar(240),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS point_transactions_user_created_idx ON virtual_point_transactions (user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title varchar(100) NOT NULL,
  body varchar(500) NOT NULL,
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS notifications_user_created_idx ON notifications (user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS activity_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_type varchar(16) NOT NULL CHECK (actor_type IN ('USER', 'ADMIN', 'SYSTEM')),
  actor_id uuid,
  action varchar(80) NOT NULL,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  ip_address inet,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS activity_logs_created_idx ON activity_logs (created_at DESC);
CREATE INDEX IF NOT EXISTS activity_logs_actor_idx ON activity_logs (actor_type, actor_id, created_at DESC);

CREATE TABLE IF NOT EXISTS system_settings (
  key varchar(80) PRIMARY KEY,
  value jsonb NOT NULL,
  updated_by uuid REFERENCES admins(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "session" (
  sid varchar NOT NULL PRIMARY KEY,
  sess json NOT NULL,
  expire timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS session_expire_idx ON "session" (expire);
