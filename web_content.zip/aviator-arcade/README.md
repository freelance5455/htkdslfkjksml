# Skyline Arcade — play-money sandbox

A modern, mobile-first Aviator-style arcade demo. **This project has no deposits, withdrawals, payment gateways, cash-out, or real-money value.** Points are virtual gameplay credits only. There is intentionally no bKash/Nagad/card/payment screen and no payment credential storage.

## Stack

- React + Vite client
- Express API and Socket.IO round broadcaster
- PostgreSQL schema/migration and parameterized SQL when `DATABASE_URL` is set
- In-memory development store when no database is configured
- HTTP-only session cookies, bcrypt password hashing, CSRF token checks, rate limits, Helmet, server-side permissions

## Quick start

1. Install Node.js 20+ and PostgreSQL 14+ (PostgreSQL is optional for the local demo).
2. Copy `.env.example` to `.env`. Leave secrets blank only for local demo mode. Generate a strong, unique `AUTH_SECRET` before deployment.
3. Install dependencies: `npm install`.
4. Run the demo: `npm run dev`.
5. Open the Vite URL printed in the terminal. Use **Try the sandbox** to create a demo user. A local **Admin preview** is available in non-production mode unless `DEMO_MODE=false`; it is disabled automatically in production.

The local demo store is in memory and resets when the server restarts. It is only for UI/testing. For durable data and real accounts, configure PostgreSQL and run the migration.

## Environment setup

`.env.example` contains placeholders only. Set at minimum:

- `DATABASE_URL` — PostgreSQL connection string
- `AUTH_SECRET` — at least 32 random bytes; never commit or expose it
- `APP_URL` — canonical app origin, e.g. `https://arcade.example.com`
- `ADMIN_USERNAME` / `ADMIN_PASSWORD` — bootstrap credentials for the first admin. Use a unique password of at least 14 characters. The server stores a bcrypt hash; the environment value is not sent to the client.
- `WEBSOCKET_URL` — optional; blank uses the same origin
- `API_PORT` — API port (default 3001)
- `DEMO_MODE` — `false` in production

The requested admin password and mobile number are **not embedded in source or configuration**. Set new, private production credentials via your deployment secret manager. Do not reuse a chat password.

## Database migration

```bash
cp .env.example .env
# Fill DATABASE_URL and AUTH_SECRET in .env
npm run migrate
```

The first run creates the PostgreSQL schema and bootstraps an admin from `ADMIN_USERNAME` and `ADMIN_PASSWORD` if that username does not exist. Existing admin passwords are never overwritten automatically. The game can also start without PostgreSQL for a disposable in-memory demo.

## Commands

```bash
npm run dev       # Express API + Vite client
npm test          # unit tests for transitions and point calculations
npm run build     # production client bundle
npm start         # production API and static client
npm run migrate   # apply SQL migrations
```

## Production notes

- Set `NODE_ENV=production`, `DEMO_MODE=false`, a strong `AUTH_SECRET`, `APP_URL`, and `DATABASE_URL`.
- Serve behind HTTPS and a trusted reverse proxy. The app uses secure, HTTP-only, same-site session cookies in production.
- Build with `npm run build`; Express serves `dist/` and Socket.IO from the same origin. If deploying separately, configure an HTTPS `WEBSOCKET_URL` and same-site session/CORS policy deliberately.
- The API uses server-authoritative rounds. The browser cannot choose a crash result. Round state is broadcast over Socket.IO; bet and collect requests are validated and settled on the server.
- Admin changes are role-checked and audit logged. Use unique strong secrets and restrict the admin route at the edge if appropriate.
- Back up PostgreSQL and review the migration before applying it to a production database.

## Project structure

```text
client/src/             React screens, components, API client, styles
server/config/          environment and database configuration
server/db/migrations/   PostgreSQL schema
server/middleware/      session, CSRF, auth, validation helpers
server/routes/          auth, user, game, admin APIs
server/services/        store and server-authoritative game engine
server/websocket/       Socket.IO session bridge and event wiring
server/tests/           node:test coverage
```

## Safety boundary

Skyline is a sandbox, not a gambling or payment product. Virtual points cannot be purchased, transferred, redeemed, or exchanged for money or prizes. Do not add payment or cash-out integrations to this project.
