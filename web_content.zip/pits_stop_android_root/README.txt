PITS STOP PRO Android project

To build from a phone using GitHub Actions:
1. Create/sign in to a GitHub account in Chrome.
2. Create a new PUBLIC repository named pits-stop-pro-android (public is easiest for free GitHub Actions).
3. Upload all files and folders from this ZIP to the repository root, preserving the folder structure. Ensure .github/workflows/build-apk.yml is uploaded (GitHub may hide .github in some mobile file pickers; if so use the repository web editor to create the workflow file).
4. Open Actions > Build PITS STOP PRO APK > Run workflow.
5. Wait for the run to finish successfully, open the run, scroll to Artifacts, and download PITS-STOP-PRO-APK.zip.
6. Extract app-debug.apk on the phone and install it. Android may ask to allow Chrome/Files to install unknown apps.

Do not publish customer diagnostic PDFs or personal data in this repository. The included HTML is the app code only.
