VAISHNAV WORLD — ADMIN + DEVOTEE FCM CONNECTION

Firebase project shared by both apps:
- Project ID: hare-krishna-94342
- Realtime Database: https://hare-krishna-94342-default-rtdb.firebaseio.com

HOW THE CONNECTION WORKS
1. The Devotee Android APK gets its native FCM registration token.
2. The Devotee APK saves it at Realtime Database path fcmTokens/<encoded-token>.
3. The Admin app and Devotee app use the same Firebase project/config, so they read/write the same Realtime Database.
4. When an Admin publishing action creates an in-app notification, the Admin app also creates a pushQueue/<id> record.
5. The Cloud Function in functions/index.js watches pushQueue, reads fcmTokens, and sends native Android FCM notifications in batches of at most 500 tokens.
6. Invalid/unregistered tokens are removed. Temporary delivery errors are not automatically deleted.

WHAT MUST BE DONE BEFORE REAL PUSH NOTIFICATIONS WORK
- Deploy the Realtime Database rules appropriate for your app. Do not use open/development rules for a public production database.
- Deploy the Cloud Function from this ZIP's root using Firebase CLI:
    firebase deploy --only functions
- Build/install the Devotee APK with its matching google-services.json.
- Open the Devotee app on each test phone and allow notifications (Android 13+ permission prompt).
- Internet access is required. Cloud Functions deployment may require the Firebase project's billing-enabled plan and can incur usage charges; check billing with a parent/guardian before enabling it.

IMPORTANT
- This ZIP contains source files/projects, not a compiled APK.
- The Admin app's FCM delivery depends on the Cloud Function being deployed. Writing to pushQueue alone does not send a phone notification.
- Both apps must keep using the same Firebase project ID and Realtime Database.
- Do not publish service-account private keys in either APK or web files.
- The existing admin sections and image picker are retained; this patch focuses on the Admin/Devotee shared Firebase project and FCM delivery.
