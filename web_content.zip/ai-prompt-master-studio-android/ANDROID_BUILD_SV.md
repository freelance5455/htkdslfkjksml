# Bygg Android-APK – AI Prompt Master Studio Ultimate 3.0

Projektet är förberett med Capacitor. Android-projektet skapas lokalt med Capacitor CLI.

## Krav
- Node.js 20 eller senare och npm
- Android Studio med Android SDK (API 23 eller senare)
- JDK 17 eller senare

## Viktigt: konfigurera AI-backend
Appen använder Express-endpoints (`/api/gemini/...`). En APK kan inte köra `server.ts` som en vanlig webbserver inne i appen. Distribuera därför backend-servern på en HTTPS-server. Sätt sedan `VITE_API_BASE_URL` till backendens HTTPS-adress innan bygget. Exempel:

```bash
cp .env.android.example .env
# Redigera .env och ange din riktiga backendadress
```

Sätt även `GEMINI_API_KEY` som server-secret i backendmiljön, eller låt användaren ange sin egen nyckel i appens inställningar. Lägg aldrig en hemlig servernyckel i APK-filen.

## Bygg APK
Kör i projektmappen:

```bash
npm install
npm run android:setup
npm run android:sync
npm run android:debug
```

APK-filen skapas normalt här:
`android/app/build/outputs/apk/debug/app-debug.apk`

För release:

```bash
npm run android:release
```

En release-APK måste signeras innan distribution. Öppna `android/` i Android Studio för att konfigurera signering.

## Android Studio
```bash
npm run android:open
```

## Testa
Installera debug-APK på en Android-enhet och kontrollera att lokala promptverktyg fungerar samt att backendens `/api/health` och AI-genereringsendpoints svarar via HTTPS.
