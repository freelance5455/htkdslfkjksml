export type AIMode = 'local' | 'gemini';
export type MediaType = 'image' | 'video';
export type AppTheme = 'dark' | 'light' | 'system';
export type AppLanguage = 'sv' | 'en';

export interface PromptItem {
  id: string;
  title: string;
  category: string;
  type: MediaType;
  prompt: string;
  negativePrompt?: string;
  shortPrompt?: string;
  detailedPrompt?: string;
  professionalPrompt?: string;
  ultimatePrompt?: string;
  aspectRatio?: string;
  platform?: string;
  tags: string[];
  qualityScore?: number;
  qualityBreakdown?: Record<string, number>;
  createdAt: number;
  updatedAt: number;
  isFavorite?: boolean;
  projectId?: string;
  metadata?: Record<string, any>;
  modeUsed?: AIMode;
}

export interface QualityScoreResult {
  totalScore: number;
  breakdown: {
    subject: number; // Max 20
    action: number; // Max 15
    environment: number; // Max 15
    visualStyle: number; // Max 10
    cameraComposition: number; // Max 15
    lighting: number; // Max 10
    technicalSpecs: number; // Max 10
    conflictFree: number; // Max 5
  };
  flaws: string[];
  suggestions: string[];
  conflicts: string[];
  evaluationType: 'local' | 'gemini';
}

export interface CharacterProfile {
  id: string;
  name: string;
  genderOrArchetype: string;
  age: string;
  appearance: string;
  hair: string;
  clothing: string;
  distinctiveFeatures: string;
  notes?: string;
}

export interface StoryboardScene {
  id: string;
  sceneNumber: number;
  title: string;
  description: string;
  subject: string;
  action: string;
  environment: string;
  timeAndWeather: string;
  cameraAngle: string;
  cameraMovement: string;
  lighting: string;
  colorPalette: string;
  startFramePrompt: string;
  endFramePrompt: string;
  videoPrompt: string;
  negativePrompt: string;
  continuityNotes: string;
  durationSeconds?: number;
}

export interface StoryboardProject {
  id: string;
  title: string;
  concept: string;
  style: string;
  scenes: StoryboardScene[];
  createdAt: number;
  updatedAt: number;
}

export interface ContinuousVideoProject {
  id: string;
  title: string;
  characterProfile: CharacterProfile;
  environmentRules: {
    location: string;
    lighting: string;
    colorPalette: string;
    atmosphere: string;
  };
  lockedElements: string[];
  scenes: {
    sceneIndex: number;
    title: string;
    narrativeAction: string;
    subjectStatus: string;
    cameraDirection: string;
    videoPrompt: string;
    negativePrompt: string;
    timelineKeyframes: { second: string; action: string }[];
    continuityChecklist: string[];
  }[];
  createdAt: number;
  updatedAt: number;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  category: string;
  promptIds: string[];
  characters: CharacterProfile[];
  storyboardIds?: string[];
  tags: string[];
  createdAt: number;
  updatedAt: number;
}

export interface AppSettings {
  theme: AppTheme;
  language: AppLanguage;
  aiMode: AIMode;
  geminiModel: string;
  defaultMediaType: MediaType;
  defaultPlatform: string;
  defaultAspectRatio: string;
  defaultDetailLevel: 'short' | 'detailed' | 'professional' | 'ultimate';
  autosave: boolean;
  showQualityScore: boolean;
  confirmDelete: boolean;
}

export interface PlatformProfile {
  id: string;
  name: string;
  type: MediaType;
  badge: string;
  description: string;
  structure: string[];
  syntaxNotes: string;
  recommendedAspectRatios: string[];
  examplePrompt: string;
  exampleNegative?: string;
  tips: string[];
}
