import React from 'react';
import {
  LayoutDashboard,
  Wand2,
  Image as ImageIcon,
  Video,
  Sparkles,
  Sliders,
  ShieldBan,
  MessageSquareCode,
  Film,
  Layers,
  ScanEye,
  GitCompare,
  BookOpen,
  Share2,
  FolderKanban,
  Bookmark,
  History,
  HardDrive,
  FileDown,
  Settings,
  HelpCircle,
  X,
} from 'lucide-react';

interface Props {
  activeSection: string;
  onSelectSection: (section: string) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
  promptCount?: number;
  favoriteCount?: number;
}

export interface NavItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
  highlight?: boolean;
}

export interface NavGroup {
  title: string;
  items: NavItem[];
}

export const NAV_GROUPS: NavGroup[] = [
  {
    title: 'Översikt',
    items: [
      { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
      { id: 'library', label: 'Prompt Library (100+)', icon: BookOpen, badge: '100+' },
      { id: 'projects', label: 'Project Manager', icon: FolderKanban },
      { id: 'favorites', label: 'Favoriter', icon: Bookmark },
      { id: 'history', label: 'Historik', icon: History },
    ],
  },
  {
    title: 'Prompt Studios',
    items: [
      { id: 'prompt-builder', label: 'Ultimate Prompt Builder', icon: Wand2, highlight: true },
      { id: 'image-generator', label: 'Image Prompt Studio', icon: ImageIcon },
      { id: 'video-generator', label: 'Video Prompt Studio', icon: Video },
      { id: 'auto-builder', label: 'Prompt Auto-Builder', icon: Sparkles },
      { id: 'enhancer', label: 'Prompt Enhancer Pro', icon: Sliders },
      { id: 'negative-generator', label: 'Negative Prompt Engine', icon: ShieldBan },
    ],
  },
  {
    title: 'Avancerade Labs',
    items: [
      { id: 'ai-interview', label: 'Intelligent AI Interview', icon: MessageSquareCode },
      { id: 'storyboard', label: 'Storyboard Creator', icon: Film },
      { id: 'continuous-video', label: 'Continuous Video Creator', icon: Layers },
      { id: 'image-analysis', label: 'Image Analysis Lab', icon: ScanEye },
      { id: 'comparison-lab', label: 'Prompt Comparison Lab', icon: GitCompare },
      { id: 'platform-optimizer', label: 'Platform Optimizer', icon: Share2 },
    ],
  },
  {
    title: 'System & Inställningar',
    items: [
      { id: 'storage-manager', label: 'Storage Manager', icon: HardDrive },
      { id: 'import-export', label: 'Import & Export', icon: FileDown },
      { id: 'settings', label: 'Inställningar', icon: Settings },
      { id: 'help-center', label: 'Hjälpcenter (Svenska)', icon: HelpCircle },
    ],
  },
];

export const Sidebar: React.FC<Props> = ({
  activeSection,
  onSelectSection,
  isOpenMobile,
  onCloseMobile,
}) => {
  const content = (
    <div className="flex h-full flex-col justify-between overflow-y-auto px-3 py-4 text-gray-300">
      <div className="space-y-6">
        {NAV_GROUPS.map((group) => (
          <div key={group.title} className="space-y-1">
            <h4 className="px-3 text-[11px] font-bold uppercase tracking-wider text-gray-400">
              {group.title}
            </h4>
            <div className="space-y-0.5">
              {group.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onSelectSection(item.id);
                      onCloseMobile();
                    }}
                    className={`group flex w-full items-center justify-between rounded-xl px-3 py-2 text-xs font-medium transition min-h-[44px] ${
                      isActive
                        ? 'bg-gradient-to-r from-purple-900/60 to-indigo-950/60 text-white font-semibold border border-purple-500/40 shadow-sm'
                        : 'text-gray-400 hover:bg-gray-800/60 hover:text-gray-200'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon
                        className={`w-4 h-4 transition ${
                          isActive
                            ? 'text-sky-400'
                            : 'text-gray-400 group-hover:text-gray-200'
                        }`}
                      />
                      <span className="truncate">{item.label}</span>
                    </div>
                    {item.badge && (
                      <span className="rounded-md bg-purple-500/20 px-1.5 py-0.5 text-[10px] font-bold text-purple-300 border border-purple-500/30">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Footer info in sidebar */}
      <div className="mt-6 rounded-xl border border-gray-800 bg-gray-950/60 p-3 text-[11px] text-gray-400 space-y-1">
        <div className="flex items-center justify-between">
          <span className="font-semibold text-gray-300">AI Prompt Master 3.0</span>
          <span className="text-[10px] text-emerald-400 font-mono">PWA READY</span>
        </div>
        <p className="text-[10px] leading-relaxed text-gray-400">
          Android-first • Offline-kapabel • Dual-Engine
        </p>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 border-r border-gray-800 bg-[#07090e]/95 h-[calc(100vh-4rem)] sticky top-16">
        {content}
      </aside>

      {/* Mobile Drawer */}
      {isOpenMobile && (
        <div className="fixed inset-0 z-50 lg:hidden">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
            onClick={onCloseMobile}
          />
          {/* Slide-out drawer */}
          <div className="fixed inset-y-0 left-0 w-80 max-w-[85vw] bg-[#07090e] border-r border-gray-800 shadow-2xl flex flex-col z-10 animate-in slide-in-from-left duration-200">
            <div className="flex items-center justify-between px-4 py-3.5 border-b border-gray-800">
              <span className="font-bold text-white text-sm">Meny & Verktyg</span>
              <button
                onClick={onCloseMobile}
                className="rounded-xl p-2 text-gray-400 hover:text-white hover:bg-gray-800 transition min-h-[44px] min-w-[44px] flex items-center justify-center"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">{content}</div>
          </div>
        </div>
      )}
    </>
  );
};
