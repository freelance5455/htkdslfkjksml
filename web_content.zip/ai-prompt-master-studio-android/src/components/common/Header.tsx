import React from 'react';
import { AIMode } from '../../types';
import { Sparkles, Cpu, ShieldCheck, Zap, Menu, HelpCircle, Settings as SettingsIcon } from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';

interface Props {
  aiMode: AIMode;
  onToggleMode: (mode: AIMode) => void;
  hasGeminiKey: boolean;
  onOpenMobileMenu: () => void;
  onNavigate: (section: string) => void;
}

export const Header: React.FC<Props> = ({
  aiMode,
  onToggleMode,
  hasGeminiKey,
  onOpenMobileMenu,
  onNavigate,
}) => {
  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-gray-800 bg-[#0a0c13]/90 px-3 sm:px-6 backdrop-blur-md">
      {/* Left: Mobile hamburger & Logo */}
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenMobileMenu}
          className="flex lg:hidden items-center justify-center rounded-xl p-2 text-gray-400 hover:bg-gray-800/80 hover:text-white transition min-h-[44px] min-w-[44px]"
          aria-label="Öppna navigationsmeny"
        >
          <Menu className="w-6 h-6" />
        </button>

        <div
          onClick={() => onNavigate('dashboard')}
          className="flex items-center gap-2.5 cursor-pointer group select-none"
        >
          <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-purple-600 via-indigo-600 to-sky-500 p-0.5 shadow-lg shadow-purple-900/30">
            <div className="flex h-full w-full items-center justify-center rounded-[10px] bg-gray-950">
              <Sparkles className="w-5 h-5 text-sky-400 group-hover:rotate-12 transition duration-300" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold tracking-tight text-white text-sm sm:text-base">
                PROMPT MASTER
              </span>
              <span className="rounded-md bg-purple-500/20 px-1.5 py-0.5 text-[10px] font-bold text-purple-300 border border-purple-500/30">
                v3.0
              </span>
            </div>
            <span className="text-[10px] text-gray-400 block -mt-0.5 tracking-wider uppercase font-semibold">
              Ultimate Edition
            </span>
          </div>
        </div>
      </div>

      {/* Center / Right: Mode Switcher & Status */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Mode Selector Pill */}
        <div className="flex items-center rounded-xl bg-gray-950 p-1 border border-gray-800">
          <button
            onClick={() => onToggleMode('local')}
            className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition min-h-[36px] ${
              aiMode === 'local'
                ? 'bg-emerald-600/90 text-white shadow-sm'
                : 'text-gray-400 hover:text-gray-200'
            }`}
            title="Lokal Promptmotor — 100% offline & oberoende av API"
          >
            <Cpu className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Free</span> Local
          </button>

          <button
            onClick={() => onToggleMode('gemini')}
            className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition min-h-[36px] ${
              aiMode === 'gemini'
                ? 'bg-gradient-to-r from-purple-600 to-sky-600 text-white shadow-sm'
                : 'text-gray-400 hover:text-gray-200'
            }`}
            title="Gemini AI Mode — Drivs av Google Gemini i backend"
          >
            <Sparkles className="w-3.5 h-3.5 text-sky-300" />
            <span>Gemini AI</span>
            {hasGeminiKey && (
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" title="API-nyckel aktiv i backend" />
            )}
          </button>
        </div>

        {/* PWA Install Button */}
        <PWAInstallButton />

        {/* Quick Help & Settings */}
        <button
          onClick={() => onNavigate('help-center')}
          className="hidden md:flex items-center justify-center rounded-xl p-2 text-gray-400 hover:bg-gray-800 hover:text-white transition min-h-[44px] min-w-[44px]"
          title="Hjälpcenter"
        >
          <HelpCircle className="w-5 h-5" />
        </button>

        <button
          onClick={() => onNavigate('settings')}
          className="flex items-center justify-center rounded-xl p-2 text-gray-400 hover:bg-gray-800 hover:text-white transition min-h-[44px] min-w-[44px]"
          title="Inställningar"
        >
          <SettingsIcon className="w-5 h-5" />
        </button>
      </div>
    </header>
  );
};
