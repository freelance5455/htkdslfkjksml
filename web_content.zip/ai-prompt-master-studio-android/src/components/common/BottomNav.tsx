import React from 'react';
import { LayoutDashboard, Wand2, Sliders, Film, BookOpen, Grid } from 'lucide-react';

interface Props {
  activeSection: string;
  onSelectSection: (section: string) => void;
  onOpenMore: () => void;
}

export const BottomNav: React.FC<Props> = ({
  activeSection,
  onSelectSection,
  onOpenMore,
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Hem', icon: LayoutDashboard },
    { id: 'prompt-builder', label: 'Builder', icon: Wand2 },
    { id: 'enhancer', label: 'Enhance', icon: Sliders },
    { id: 'storyboard', label: 'Storyboard', icon: Film },
    { id: 'library', label: 'Bibliotek', icon: BookOpen },
  ];

  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 lg:hidden border-t border-gray-800 bg-[#07090e]/95 backdrop-blur-lg px-2 pb-safe">
      <div className="flex items-center justify-around h-16">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeSection === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectSection(item.id)}
              className={`flex flex-col items-center justify-center flex-1 h-full py-1 text-[11px] font-medium transition min-h-[48px] ${
                isActive ? 'text-sky-400 font-semibold' : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <div
                className={`flex items-center justify-center w-8 h-8 rounded-xl transition ${
                  isActive ? 'bg-purple-900/40 text-sky-400' : 'text-gray-400'
                }`}
              >
                <Icon className="w-5 h-5" />
              </div>
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}

        {/* More Button to trigger full drawer */}
        <button
          onClick={onOpenMore}
          className="flex flex-col items-center justify-center flex-1 h-full py-1 text-[11px] font-medium text-gray-400 hover:text-gray-200 transition min-h-[48px]"
        >
          <div className="flex items-center justify-center w-8 h-8 rounded-xl text-gray-400">
            <Grid className="w-5 h-5" />
          </div>
          <span>Mer</span>
        </button>
      </div>
    </nav>
  );
};
