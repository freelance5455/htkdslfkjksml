import React, { useState } from 'react';
import { Download, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../../hooks/usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // If already running as an installed standalone PWA, hide
  if (isInstalled) {
    return null;
  }

  // Chromium / Android / Desktop flow
  if (isInstallable) {
    return (
      <button
        onClick={install}
        className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-purple-600 to-sky-600 px-3.5 py-2 text-xs font-semibold text-white shadow-lg shadow-purple-900/30 hover:brightness-110 active:scale-95 transition min-h-[44px]"
        title="Installera appen på hemskärmen (Android / Desktop)"
      >
        <Download className="w-4 h-4" />
        <span className="hidden sm:inline">Installera</span> App
      </button>
    );
  }

  // iOS Safari flow
  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className="flex items-center gap-1.5 rounded-xl border border-purple-500/30 bg-purple-950/40 px-3 py-1.5 text-xs font-medium text-purple-300 hover:bg-purple-900/40 transition min-h-[44px]"
        >
          <Smartphone className="w-3.5 h-3.5 text-sky-400" />
          <span>Installera iOS</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
            <div className="w-full max-w-sm rounded-2xl border border-gray-800 bg-gray-900 p-6 shadow-2xl text-white">
              <div className="flex items-center justify-between pb-3 border-b border-gray-800">
                <h3 className="text-base font-semibold text-sky-400">Installera på iPhone / iPad</h3>
                <button onClick={() => setShowIOSGuide(false)} className="text-gray-400 hover:text-white p-1">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="mt-4 space-y-3 text-sm text-gray-300">
                <div className="flex items-start gap-2.5">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-purple-600/30 text-purple-300 text-xs font-bold">1</span>
                  <p>Tryck på <strong>Dela-knappen</strong> (fyrkant med pil uppåt) i Safaris verktygsfält.</p>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-purple-600/30 text-purple-300 text-xs font-bold">2</span>
                  <p>Scrolla nedåt i menyn och välj <strong>Lägg till på hemskärmen</strong>.</p>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-purple-600/30 text-purple-300 text-xs font-bold">3</span>
                  <p>Bekräfta genom att trycka på <strong>Lägg till</strong> i övre högra hörnet.</p>
                </div>
              </div>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="mt-6 w-full rounded-xl bg-gray-800 py-2.5 text-sm font-medium text-gray-200 hover:bg-gray-700 transition min-h-[44px]"
              >
                Jag förstår
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};

export const OfflineIndicator: React.FC = () => {
  const { isOnline } = { isOnline: typeof navigator !== 'undefined' ? navigator.onLine : true };

  if (isOnline) return null;

  return (
    <div className="fixed bottom-16 sm:bottom-4 left-4 z-50 flex items-center gap-2 rounded-xl border border-amber-500/40 bg-amber-950/90 backdrop-blur-md px-3.5 py-2 text-xs font-semibold text-amber-200 shadow-xl">
      <span className="h-2.5 w-2.5 rounded-full bg-amber-400 animate-pulse" />
      <span>Offlineläge — Lokal promptmotor och cache aktiv</span>
    </div>
  );
};
