import React from 'react';
import { QualityScoreResult } from '../../types';
import { Award, AlertTriangle, Lightbulb, CheckCircle2, ShieldAlert } from 'lucide-react';

interface Props {
  result: QualityScoreResult;
  onApplySuggestion?: (suggestion: string) => void;
}

export const QualityScoreCard: React.FC<Props> = ({ result, onApplySuggestion }) => {
  const { totalScore, breakdown, flaws, suggestions, conflicts, evaluationType } = result;

  const getScoreColor = (score: number) => {
    if (score >= 90) return { text: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/30', ring: '#10b981' };
    if (score >= 75) return { text: 'text-sky-400', bg: 'bg-sky-500/10', border: 'border-sky-500/30', ring: '#38bdf8' };
    if (score >= 55) return { text: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/30', ring: '#f59e0b' };
    return { text: 'text-rose-400', bg: 'bg-rose-500/10', border: 'border-rose-500/30', ring: '#f43f5e' };
  };

  const colors = getScoreColor(totalScore);

  const breakdownItems = [
    { label: 'Motiv', value: breakdown.subject, max: 20, desc: 'Huvudmotiv, anatomi & detaljer' },
    { label: 'Handling', value: breakdown.action, max: 15, desc: 'Pose, interaktion & rörelse' },
    { label: 'Miljö', value: breakdown.environment, max: 15, desc: 'Plats, väder & rumslighet' },
    { label: 'Visuell stil', value: breakdown.visualStyle, max: 10, desc: 'Medium, rendering & genre' },
    { label: 'Kamera/Komp', value: breakdown.cameraComposition, max: 15, desc: 'Objektiv, vinkel & bildutsnitt' },
    { label: 'Ljussättning', value: breakdown.lighting, max: 10, desc: 'Ljuskällor, riktning & kontrast' },
    { label: 'Teknisk spec', value: breakdown.technicalSpecs, max: 10, desc: 'Upplösning & render-flaggor' },
    { label: 'Konfliktfrihet', value: breakdown.conflictFree, max: 5, desc: 'Fri från motsägelsefulla termer' },
  ];

  return (
    <div className="rounded-2xl border border-gray-800 bg-gray-900/80 p-4 sm:p-5 backdrop-blur-md shadow-xl space-y-4">
      {/* Header with circular Gauge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-800/80 pb-4">
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-16 h-16 rounded-2xl bg-gray-950 border border-gray-800">
            <svg className="w-14 h-14 -rotate-90">
              <circle
                cx="28"
                cy="28"
                r="22"
                stroke="currentColor"
                strokeWidth="4"
                fill="transparent"
                className="text-gray-800"
              />
              <circle
                cx="28"
                cy="28"
                r="22"
                stroke={colors.ring}
                strokeWidth="4"
                strokeDasharray={138.2}
                strokeDashoffset={138.2 - (138.2 * totalScore) / 100}
                strokeLinecap="round"
                fill="transparent"
                className="transition-all duration-700 ease-out"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className={`text-base font-extrabold ${colors.text}`}>{totalScore}</span>
              <span className="text-[9px] text-gray-500 uppercase tracking-tighter">/ 100</span>
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-1.5">
                <Award className="w-4 h-4 text-purple-400" />
                Prompt Quality Index
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full font-medium bg-gray-800 text-gray-300 border border-gray-700">
                {evaluationType === 'gemini' ? 'Gemini AI Bedömning' : 'Lokal Regelanalys'}
              </span>
            </div>
            <p className="text-xs text-gray-400 mt-0.5">
              {totalScore >= 90
                ? 'Utmärkt! Prompten är fullmatad med optiska, stilistiska och tekniska markörer.'
                : totalScore >= 75
                ? 'God kvalitet. Med några extra detaljer når du mästarklass.'
                : 'Grundläggande. Saknar flera nyckeldimensioner för fotorealism.'}
            </p>
          </div>
        </div>
      </div>

      {/* Conflicts warning if any */}
      {conflicts.length > 0 && (
        <div className="rounded-xl border border-rose-500/40 bg-rose-950/30 p-3 space-y-1.5 text-xs text-rose-200">
          <div className="flex items-center gap-2 font-semibold text-rose-400">
            <ShieldAlert className="w-4 h-4 shrink-0" />
            <span>Upptäckta motsägelser i prompten:</span>
          </div>
          <ul className="list-disc list-inside space-y-0.5 text-gray-300 pl-1">
            {conflicts.map((c, i) => (
              <li key={i}>{c}</li>
            ))}
          </ul>
        </div>
      )}

      {/* 8-Part Breakdown Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        {breakdownItems.map((item) => {
          const pct = Math.round((item.value / item.max) * 100);
          return (
            <div key={item.label} className="rounded-xl border border-gray-800/80 bg-gray-950/60 p-2.5">
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-gray-300 font-medium">{item.label}</span>
                <span className="font-semibold text-gray-100">
                  {item.value}<span className="text-gray-500 font-normal">/{item.max}</span>
                </span>
              </div>
              <div className="w-full bg-gray-800/60 h-1.5 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    pct >= 80 ? 'bg-sky-400' : pct >= 50 ? 'bg-purple-400' : 'bg-amber-400'
                  }`}
                  style={{ width: `${pct}%` }}
                />
              </div>
              <span className="text-[10px] text-gray-500 block mt-1 truncate">{item.desc}</span>
            </div>
          );
        })}
      </div>

      {/* Flaws & Suggestions */}
      {(flaws.length > 0 || suggestions.length > 0) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
          {flaws.length > 0 && (
            <div className="rounded-xl border border-amber-500/20 bg-amber-950/20 p-3 text-xs">
              <div className="flex items-center gap-1.5 font-semibold text-amber-300 mb-2">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Identifierade brister ({flaws.length})</span>
              </div>
              <ul className="space-y-1 text-gray-300">
                {flaws.map((flaw, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>{flaw}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {suggestions.length > 0 && (
            <div className="rounded-xl border border-sky-500/20 bg-sky-950/20 p-3 text-xs">
              <div className="flex items-center gap-1.5 font-semibold text-sky-300 mb-2">
                <Lightbulb className="w-3.5 h-3.5" />
                <span>Konkreta förbättringsförslag ({suggestions.length})</span>
              </div>
              <ul className="space-y-1.5 text-gray-300">
                {suggestions.map((sug, i) => (
                  <li key={i} className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-1.5">
                      <span className="text-sky-400 font-bold">→</span>
                      <span>{sug}</span>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
