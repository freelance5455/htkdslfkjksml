import React, { useState } from 'react';
import { AIMode, CharacterProfile, ContinuousVideoProject } from '../../types';
import { geminiService } from '../../services/geminiService';
import { storageService } from '../../services/storage';
import {
  Layers,
  User,
  Lock,
  Unlock,
  Sparkles,
  Plus,
  Copy,
  Check,
  Save,
  Download,
  Film,
  RefreshCw,
} from 'lucide-react';

interface Props {
  aiMode: AIMode;
  onNavigate: (section: string) => void;
}

export const ContinuousVideoSection: React.FC<Props> = ({ aiMode }) => {
  // Character Profile
  const [character, setCharacter] = useState<CharacterProfile>({
    id: 'char-1',
    name: 'Elena Vance',
    genderOrArchetype: 'Kvinna, Cyberpunk-agent',
    age: '28',
    appearance: 'Kort asymmetriskt platinablont hår, cybernetiskt lysande blått vänsteröga',
    hair: 'Platinablond bob',
    clothing: 'Svart matt läderrock med höga kragar, titanförstärkta axlar och reflexband',
    distinctiveFeatures: 'Litet ärr över höger ögonbryn, neonblå handskar',
  });

  // Environment & Style Locks
  const [environment, setEnvironment] = useState('Stockholms tunnelbana år 2095, glänsande kakel och flimrande cyan-reklam');
  const [colorPalette, setColorPalette] = useState('Teal, cyan och djupt kolsvart LUT');
  const [lighting, setLighting] = useState('Undermålig neonbelysning med skarpa reflektioner i regnvåta pölar');

  // Locks
  const [lockedCharacter, setLockedCharacter] = useState(true);
  const [lockedStyle, setLockedStyle] = useState(true);
  const [lockedPalette, setLockedPalette] = useState(true);

  // Scenes list
  const [scenes, setScenes] = useState<
    {
      sceneIndex: number;
      title: string;
      narrativeAction: string;
      subjectStatus: string;
      cameraDirection: string;
      videoPrompt: string;
      negativePrompt: string;
      timelineKeyframes: { second: string; action: string }[];
      continuityChecklist: string[];
    }[]
  >([
    {
      sceneIndex: 1,
      title: 'Scen 1: Ankomst till Perrongen',
      narrativeAction: 'Elena kliver av ett svävande magnettåg och ser sig omkring.',
      subjectStatus: 'Elena Vance i svart läderrock med uppfälld krage och lysande blått öga',
      cameraDirection: 'Slow tracking shot following her steps from a low angle',
      videoPrompt:
        'Continuous Scene 1: Elena Vance (28, platinum bob hair, cybernetic glowing blue left eye, black matte leather coat with titanium shoulders) steps off a magnetic train onto a deserted futuristic subway platform. Low angle tracking camera follows her boots splashing in shallow neon puddles. Teal and cyan LUT, 35mm cinematic aesthetics, 60fps.',
      negativePrompt: 'changing clothes, morphing face, brown hair, daylight, cheerful atmosphere',
      timelineKeyframes: [
        { second: '0s', action: 'Tågdörrarna öppnas med tryckluftsutsläpp' },
        { second: '3s', action: 'Elena kliver ut på den blöta perrongen' },
        { second: '5s', action: 'Stannar och scannar omgivningen med sitt cyberöga' },
      ],
      continuityChecklist: ['Läderrock bevarad', 'Cyberöga låst på vänster sida', 'Perrongmiljö konsekvent'],
    },
  ]);

  const [nextAction, setNextAction] = useState('Hon upptäcker en avlyssningsdrönare i taket och söker snabbt skydd bakom en pelare');
  const [isContinuing, setIsContinuing] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleContinueStory = async () => {
    if (!nextAction.trim()) return;
    setIsContinuing(true);

    try {
      let newSceneData: any;
      if (aiMode === 'gemini') {
        newSceneData = await geminiService.continuousVideo({
          characterProfile: character,
          environmentRules: { location: environment, lighting, colorPalette, atmosphere: 'Cyberpunk tension' },
          lockedElements: [
            lockedCharacter ? 'Character Face & Wardrobe' : null,
            lockedStyle ? 'Cinematic 35mm Style' : null,
            lockedPalette ? 'Color Palette LUT' : null,
          ].filter(Boolean) as string[],
          previousScenes: scenes,
          nextAction,
          language: 'sv',
        });
      } else {
        // Local continuity generation
        const idx = scenes.length + 1;
        newSceneData = {
          sceneIndex: idx,
          title: `Scen ${idx}: ${nextAction.slice(0, 30)}`,
          narrativeAction: nextAction,
          subjectStatus: `${character.name} med konsekvent klädsel (${character.clothing})`,
          cameraDirection: 'Handheld dynamic tracking following motion',
          videoPrompt: `Continuous Scene ${idx}: ${character.name} (${character.appearance}, wearing ${character.clothing}). Action: ${nextAction}. Location: ${environment}. Camera: Handheld tracking with locked ${lighting}. Consistent ${colorPalette}, 8k raw cinematic frame.`,
          negativePrompt: 'face drift, costume change, hair color change, morphing, flickering',
          timelineKeyframes: [
            { second: '0s', action: 'Börjar direkt från föregående scens slutläge' },
            { second: '3s', action: 'Genomför handlingen' },
            { second: '5s', action: 'Intar ny stabil position för nästa scen' },
          ],
          continuityChecklist: ['Karaktärsdrag låsta', 'Belysning matchar scen 1', 'Färgprofil intakt'],
        };
      }

      setScenes([...scenes, newSceneData]);
      setNextAction('');
    } catch {
      // Local fallback
      const idx = scenes.length + 1;
      const fallbackScene = {
        sceneIndex: idx,
        title: `Scen ${idx}: ${nextAction.slice(0, 30)}`,
        narrativeAction: nextAction,
        subjectStatus: `${character.name} med konsekvent klädsel (${character.clothing})`,
        cameraDirection: 'Handheld dynamic tracking following motion',
        videoPrompt: `Continuous Scene ${idx}: ${character.name} (${character.appearance}, wearing ${character.clothing}). Action: ${nextAction}. Location: ${environment}. Camera: Handheld tracking with locked ${lighting}. Consistent ${colorPalette}, 8k raw cinematic frame.`,
        negativePrompt: 'face drift, costume change, hair color change, morphing, flickering',
        timelineKeyframes: [
          { second: '0s', action: 'Börjar från föregående scens slutposition' },
          { second: '3s', action: 'Utför handlingen' },
          { second: '5s', action: 'Förbereder nästa övergång' },
        ],
        continuityChecklist: ['Karaktär låst', 'Färgton bevarad'],
      };
      setScenes([...scenes, fallbackScene]);
      setNextAction('');
    } finally {
      setIsContinuing(false);
    }
  };

  const handleCopyPrompt = (idx: number, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const handleSaveProject = async () => {
    const project: ContinuousVideoProject = {
      id: `cv-${Date.now()}`,
      title: `Kontinuerlig Video: ${character.name}`,
      characterProfile: character,
      environmentRules: { location: environment, lighting, colorPalette, atmosphere: 'Cinematic' },
      lockedElements: ['character', 'style', 'palette'],
      scenes,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    await storageService.saveContinuousVideo(project);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  const handleExportFullStory = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify({ character, environment, scenes }, null, 2));
    const a = document.createElement('a');
    a.href = dataStr;
    a.download = `continuous-story-${character.name.toLowerCase().replace(/\s+/g, '-')}.json`;
    a.click();
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-800 pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
            <Layers className="w-5 h-5 text-indigo-400" />
            Continuous Video Creator
          </h1>
          <p className="text-xs text-gray-400 mt-1">
            Skapa sammanhängande videoscener där karaktärsutseende, klädsel, belysning och miljö förblir 100% konsistenta.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleSaveProject}
            className="flex items-center gap-1.5 rounded-xl bg-purple-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-purple-500 transition min-h-[44px]"
          >
            {savedSuccess ? <Check className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
            <span>Spara Projekt</span>
          </button>
          <button
            onClick={handleExportFullStory}
            className="flex items-center gap-1.5 rounded-xl border border-gray-800 bg-gray-900 px-3 py-2 text-xs font-semibold text-gray-300 hover:text-white transition min-h-[44px]"
          >
            <Download className="w-4 h-4" />
            <span>Exportera</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Character & Environment Profile */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-gray-800 pb-2">
              <span className="text-xs font-bold text-sky-400 uppercase tracking-wider flex items-center gap-1.5">
                <User className="w-3.5 h-3.5" />
                Låst Karaktärsprofil
              </span>
              <button
                onClick={() => setLockedCharacter(!lockedCharacter)}
                className={`flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full border transition ${
                  lockedCharacter
                    ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300'
                    : 'border-gray-700 bg-gray-800 text-gray-400'
                }`}
              >
                {lockedCharacter ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                <span>{lockedCharacter ? 'Låst' : 'Olåst'}</span>
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div>
                <label className="text-gray-400 block mb-0.5">Namn & Arketyp:</label>
                <input
                  type="text"
                  value={character.name}
                  onChange={(e) => setCharacter({ ...character, name: e.target.value })}
                  className="w-full rounded-xl border border-gray-800 bg-gray-950 p-2 text-white focus:outline-none focus:border-sky-500 min-h-[40px]"
                />
              </div>

              <div>
                <label className="text-gray-400 block mb-0.5">Kläder & Signaturdetaljer:</label>
                <textarea
                  value={character.clothing}
                  onChange={(e) => setCharacter({ ...character, clothing: e.target.value })}
                  rows={2}
                  className="w-full rounded-xl border border-gray-800 bg-gray-950 p-2 text-white focus:outline-none focus:border-sky-500"
                />
              </div>

              <div>
                <label className="text-gray-400 block mb-0.5">Visuella Kännetecken & Ansikte:</label>
                <textarea
                  value={character.appearance}
                  onChange={(e) => setCharacter({ ...character, appearance: e.target.value })}
                  rows={2}
                  className="w-full rounded-xl border border-gray-800 bg-gray-950 p-2 text-white focus:outline-none focus:border-sky-500"
                />
              </div>
            </div>
          </div>

          {/* Environment & Palette Locks */}
          <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-gray-800 pb-2">
              <span className="text-xs font-bold text-purple-400 uppercase tracking-wider">
                Låst Miljö & Färgpalett
              </span>
              <button
                onClick={() => setLockedPalette(!lockedPalette)}
                className={`flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full border transition ${
                  lockedPalette
                    ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300'
                    : 'border-gray-700 bg-gray-800 text-gray-400'
                }`}
              >
                {lockedPalette ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                <span>{lockedPalette ? 'Låst' : 'Olåst'}</span>
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div>
                <label className="text-gray-400 block mb-0.5">Miljö & Plats:</label>
                <input
                  type="text"
                  value={environment}
                  onChange={(e) => setEnvironment(e.target.value)}
                  className="w-full rounded-xl border border-gray-800 bg-gray-950 p-2 text-white min-h-[40px]"
                />
              </div>
              <div>
                <label className="text-gray-400 block mb-0.5">Färgpalett & LUT:</label>
                <input
                  type="text"
                  value={colorPalette}
                  onChange={(e) => setColorPalette(e.target.value)}
                  className="w-full rounded-xl border border-gray-800 bg-gray-950 p-2 text-white min-h-[40px]"
                />
              </div>
            </div>
          </div>

          {/* Next Scene Generator Box */}
          <div className="rounded-2xl border border-indigo-500/30 bg-indigo-950/20 p-4 space-y-3">
            <label className="text-xs font-bold text-indigo-300 uppercase tracking-wider block">
              Nästa handling i berättelsen:
            </label>
            <textarea
              value={nextAction}
              onChange={(e) => setNextAction(e.target.value)}
              placeholder="Vad händer i nästa scen med samma karaktär och miljö?"
              rows={2}
              className="w-full rounded-xl border border-gray-800 bg-gray-950 p-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
            />
            <button
              onClick={handleContinueStory}
              disabled={isContinuing || !nextAction.trim()}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-sky-600 p-3 text-xs font-extrabold text-white shadow-lg hover:brightness-110 active:scale-95 transition disabled:opacity-50 min-h-[44px]"
            >
              {isContinuing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Bygger kontinuerlig scen...</span>
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4" />
                  <span>Generera Nästa Scen ({aiMode === 'gemini' ? 'Gemini AI' : 'Local Mode'})</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right: Sequential Scenes Timeline */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-300 uppercase tracking-wider">
              Sekventiella Videoscener ({scenes.length} scener sammanlänkade)
            </span>
          </div>

          <div className="space-y-4">
            {scenes.map((scene, idx) => (
              <div
                key={idx}
                className="rounded-2xl border border-gray-800 bg-gray-900/80 p-4 space-y-3 shadow-lg"
              >
                <div className="flex items-center justify-between border-b border-gray-800 pb-2">
                  <span className="font-bold text-sm text-sky-400">{scene.title}</span>
                  <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-semibold bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30">
                    <Check className="w-3.5 h-3.5" />
                    <span>Kontinuitet Säkrad</span>
                  </div>
                </div>

                <p className="text-xs text-gray-300">
                  <strong>Handling:</strong> {scene.narrativeAction}
                </p>

                {/* Timeline keyframes */}
                <div className="space-y-1 bg-gray-950/60 p-2.5 rounded-xl border border-gray-800 text-xs">
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
                    Tidslinje & Övergångar:
                  </span>
                  {scene.timelineKeyframes?.map((kf, i) => (
                    <div key={i} className="flex items-center gap-2 text-[11px] text-gray-300">
                      <span className="font-mono text-indigo-400 font-bold">{kf.second}:</span>
                      <span>{kf.action}</span>
                    </div>
                  ))}
                </div>

                {/* Video Prompt */}
                <div className="rounded-xl border border-gray-800 bg-gray-950 p-3 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider">
                      Videoprompt för {scene.title}:
                    </span>
                    <button
                      onClick={() => handleCopyPrompt(idx, scene.videoPrompt)}
                      className="flex items-center gap-1 text-[11px] text-gray-400 hover:text-white"
                    >
                      {copiedIndex === idx ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedIndex === idx ? 'Kopierad' : 'Kopiera'}</span>
                    </button>
                  </div>
                  <p className="text-xs text-gray-200 font-mono select-all leading-relaxed">
                    {scene.videoPrompt}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
