import React, { useState } from 'react';
import { PromptItem } from '../../types';
import { INITIAL_PROMPT_LIBRARY } from '../../data/promptLibrary';
import {
  BookOpen,
  Search,
  Camera,
  Film,
  Copy,
  Check,
  Bookmark,
  Sparkles,
  Wand2,
  Filter,
} from 'lucide-react';

interface Props {
  onSelectPromptForBuilder: (prompt: PromptItem) => void;
  onToggleFavorite: (id: string) => void;
  favorites: string[];
}

export const LibrarySection: React.FC<Props> = ({
  onSelectPromptForBuilder,
  onToggleFavorite,
  favorites,
}) => {
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'image' | 'video'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Extract unique categories
  const categories = Array.from(new Set(INITIAL_PROMPT_LIBRARY.map((p) => p.category))).sort();

  const filteredPrompts = INITIAL_PROMPT_LIBRARY.filter((p) => {
    const matchesSearch =
      search.trim() === '' ||
      p.title.toLowerCase().includes(search.toLowerCase()) ||
      p.prompt.toLowerCase().includes(search.toLowerCase()) ||
      p.tags.some((t) => t.toLowerCase().includes(search.toLowerCase()));

    const matchesType = typeFilter === 'all' || p.type === typeFilter;
    const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;

    return matchesSearch && matchesType && matchesCategory;
  });

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-purple-400" />
              Prompt Library
            </h1>
            <span className="rounded-full bg-purple-500/20 px-2.5 py-0.5 text-xs font-semibold text-purple-300 border border-purple-500/30">
              {INITIAL_PROMPT_LIBRARY.length} Mästerverksprompter
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-1">
            50 studio-optimerade bildprompter och 50 filmiska videoprompter med fullständiga optiska specifikationer och negativa instruktioner.
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Search box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-gray-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Sök bland 100+ prompter på titel, nyckelord, tags..."
              className="w-full rounded-xl border border-gray-800 bg-gray-950 pl-10 pr-4 py-2.5 text-xs sm:text-sm text-white placeholder-gray-500 focus:border-purple-500 focus:outline-none min-h-[44px]"
            />
          </div>

          {/* Type Filter Buttons */}
          <div className="flex rounded-xl bg-gray-950 p-1 border border-gray-800 shrink-0">
            <button
              onClick={() => setTypeFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition min-h-[36px] ${
                typeFilter === 'all' ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              Alla ({INITIAL_PROMPT_LIBRARY.length})
            </button>
            <button
              onClick={() => setTypeFilter('image')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition min-h-[36px] ${
                typeFilter === 'image' ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              <Camera className="w-3.5 h-3.5" />
              Bild (50)
            </button>
            <button
              onClick={() => setTypeFilter('video')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition min-h-[36px] ${
                typeFilter === 'video' ? 'bg-sky-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              <Film className="w-3.5 h-3.5" />
              Video (50)
            </button>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex flex-wrap gap-1.5 pt-1 max-h-24 overflow-y-auto pr-1">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`rounded-xl px-2.5 py-1 text-xs font-medium transition min-h-[32px] ${
              selectedCategory === 'all'
                ? 'bg-gray-800 text-white font-semibold'
                : 'bg-gray-950 text-gray-400 hover:text-gray-200 border border-gray-800'
            }`}
          >
            Alla kategorier
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`rounded-xl px-2.5 py-1 text-xs font-medium transition min-h-[32px] ${
                selectedCategory === cat
                  ? 'bg-purple-600 text-white font-semibold shadow-sm'
                  : 'bg-gray-950 text-gray-400 hover:text-gray-200 border border-gray-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Prompts Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredPrompts.map((p) => {
          const isFav = favorites.includes(p.id) || p.isFavorite;
          return (
            <div
              key={p.id}
              className="rounded-2xl border border-gray-800 bg-gray-900/70 p-4 sm:p-5 space-y-3 flex flex-col justify-between hover:border-gray-700 transition"
            >
              <div className="space-y-2.5">
                <div className="flex items-start justify-between gap-2 border-b border-gray-800 pb-2.5">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-white">{p.title}</span>
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                          p.type === 'video'
                            ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                            : 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                        }`}
                      >
                        {p.type}
                      </span>
                    </div>
                    <span className="text-[11px] text-gray-400 block mt-0.5">
                      {p.category} • {p.platform || 'Multi-platform'}
                    </span>
                  </div>

                  <button
                    onClick={() => onToggleFavorite(p.id)}
                    className={`p-2 rounded-xl transition min-h-[40px] min-w-[40px] flex items-center justify-center ${
                      isFav
                        ? 'text-amber-400 bg-amber-500/10'
                        : 'text-gray-500 hover:text-white hover:bg-gray-800'
                    }`}
                    title="Favoritmarkera"
                  >
                    <Bookmark className="w-4 h-4" />
                  </button>
                </div>

                {/* Prompt Text */}
                <div className="rounded-xl border border-gray-800 bg-gray-950 p-3">
                  <p className="text-xs text-gray-200 font-mono leading-relaxed select-all line-clamp-4">
                    {p.prompt}
                  </p>
                </div>

                {/* Negative Prompt preview if exists */}
                {p.negativePrompt && (
                  <div className="text-[11px] text-rose-300/80 font-mono truncate bg-rose-950/20 px-2.5 py-1.5 rounded-lg border border-rose-500/20">
                    <span className="font-semibold text-rose-400">Negativ:</span> {p.negativePrompt}
                  </div>
                )}

                {/* Tags */}
                <div className="flex flex-wrap gap-1">
                  {p.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-[10px] px-2 py-0.5 rounded-md bg-gray-950 text-gray-400 border border-gray-800/80"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-3 border-t border-gray-800">
                <button
                  onClick={() => handleCopy(p.id, p.prompt)}
                  className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gray-800 px-3 py-2 text-xs font-semibold text-white hover:bg-gray-700 active:scale-95 transition min-h-[40px]"
                >
                  {copiedId === p.id ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Kopierad</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Kopiera</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => onSelectPromptForBuilder(p)}
                  className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-purple-600/30 border border-purple-500/40 px-3 py-2 text-xs font-semibold text-purple-200 hover:bg-purple-600 hover:text-white active:scale-95 transition min-h-[40px]"
                >
                  <Wand2 className="w-3.5 h-3.5" />
                  <span>Öppna i Builder</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
