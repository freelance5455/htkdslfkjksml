import React, { useState, useEffect } from 'react';
import { storageService } from '../../services/storage';
import {
  HardDrive,
  Download,
  Upload,
  Trash2,
  Database,
  RefreshCw,
  Check,
  AlertTriangle,
  ShieldCheck,
} from 'lucide-react';

interface Props {
  onRefreshData: () => void;
}

export const StorageManagerSection: React.FC<Props> = ({ onRefreshData }) => {
  const [stats, setStats] = useState({
    promptsCount: 0,
    projectsCount: 0,
    storyboardsCount: 0,
    continuousCount: 0,
    estimatedKB: 0,
  });
  const [isExporting, setIsExporting] = useState(false);
  const [isClearing, setIsClearing] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const loadStats = async () => {
    const prompts = await storageService.getPrompts();
    const projects = await storageService.getProjects();
    const sbs = await storageService.getStoryboards();
    const cvs = await storageService.getContinuousVideos();

    const jsonStr = JSON.stringify({ prompts, projects, sbs, cvs });
    setStats({
      promptsCount: prompts.length,
      projectsCount: projects.length,
      storyboardsCount: sbs.length,
      continuousCount: cvs.length,
      estimatedKB: Math.round(jsonStr.length / 1024),
    });
  };

  useEffect(() => {
    loadStats();
  }, []);

  const handleDownloadBackup = async () => {
    setIsExporting(true);
    try {
      const backupJson = await storageService.exportFullBackup();
      const blob = new Blob([backupJson], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `prompt-master-backup-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      setStatusMsg({ text: 'Fullständig säkerhetskopia laddades ned framgångsrikt!', type: 'success' });
    } catch (err: any) {
      setStatusMsg({ text: `Export misslyckades: ${err.message}`, type: 'error' });
    } finally {
      setIsExporting(false);
      setTimeout(() => setStatusMsg(null), 3000);
    }
  };

  const handleClearAll = async () => {
    if (confirm('VARNING: Är du säker på att du vill rensa all lokal data? Detta kan inte ångras!')) {
      setIsClearing(true);
      await storageService.clearAllData();
      await loadStats();
      onRefreshData();
      setIsClearing(false);
      setStatusMsg({ text: 'All lokal data har raderats.', type: 'success' });
      setTimeout(() => setStatusMsg(null), 3000);
    }
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="border-b border-gray-800 pb-4">
        <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
          <HardDrive className="w-5 h-5 text-purple-400" />
          Storage Manager (IndexedDB)
        </h1>
        <p className="text-xs text-gray-400 mt-1">
          Lokal och privat databasarkitektur. All data sparas 100% på din enhet i webbläsarens IndexedDB.
        </p>
      </div>

      {statusMsg && (
        <div
          className={`p-3.5 rounded-xl border text-xs font-semibold flex items-center gap-2 animate-in fade-in ${
            statusMsg.type === 'success'
              ? 'border-emerald-500/40 bg-emerald-950/40 text-emerald-300'
              : 'border-rose-500/40 bg-rose-950/40 text-rose-300'
          }`}
        >
          {statusMsg.type === 'success' ? <Check className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
          <span>{statusMsg.text}</span>
        </div>
      )}

      {/* Database Statistics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 space-y-1">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
            Sparade Prompter
          </span>
          <span className="text-xl sm:text-2xl font-black text-white">{stats.promptsCount}</span>
          <span className="text-[10px] text-gray-500 block">I objektlagret 'prompts'</span>
        </div>

        <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 space-y-1">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
            Projekt
          </span>
          <span className="text-xl sm:text-2xl font-black text-white">{stats.projectsCount}</span>
          <span className="text-[10px] text-gray-500 block">I objektlagret 'projects'</span>
        </div>

        <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 space-y-1">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
            Storyboards
          </span>
          <span className="text-xl sm:text-2xl font-black text-white">{stats.storyboardsCount}</span>
          <span className="text-[10px] text-gray-500 block">I objektlagret 'storyboards'</span>
        </div>

        <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 space-y-1">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
            Uppskattad Datastorlek
          </span>
          <span className="text-xl sm:text-2xl font-black text-sky-400">{stats.estimatedKB} KB</span>
          <span className="text-[10px] text-gray-500 block">IndexedDB & Cache</span>
        </div>
      </div>

      {/* Architecture & Privacy Guarantee */}
      <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-5 space-y-3 text-xs">
        <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
          <ShieldCheck className="w-5 h-5" />
          <span>Lokal Dataintegritet & Säkerhetsgaranti</span>
        </div>
        <p className="text-gray-300 leading-relaxed">
          AI Prompt Master Studio 3.0 kräver ingen registrering eller konto för att fungera.
          Dina prompter, anteckningar och inställningar lagras enbart lokalt i din webbläsares IndexedDB.
          Data raderas aldrig automatiskt vid uppdateringar eller app-omstart.
        </p>
      </div>

      {/* Backup and Wipe Actions */}
      <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-5 space-y-4">
        <span className="text-xs font-bold text-gray-200 uppercase tracking-wider block">
          Databasåtgärder
        </span>

        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={handleDownloadBackup}
            disabled={isExporting}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-purple-600 px-4 py-3 text-xs sm:text-sm font-semibold text-white hover:bg-purple-500 transition min-h-[48px]"
          >
            <Download className="w-4 h-4" />
            <span>Ladda ned fullständig säkerhetskopia (JSON)</span>
          </button>

          <button
            onClick={handleClearAll}
            disabled={isClearing}
            className="flex items-center justify-center gap-2 rounded-xl border border-rose-500/30 bg-rose-950/30 px-4 py-3 text-xs sm:text-sm font-semibold text-rose-300 hover:bg-rose-900/40 transition min-h-[48px]"
          >
            <Trash2 className="w-4 h-4" />
            <span>Rensa all data</span>
          </button>
        </div>
      </div>
    </div>
  );
};
