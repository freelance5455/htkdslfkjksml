import React, { useState, useRef } from 'react';
import { AIMode, PromptItem } from '../../types';
import { geminiService } from '../../services/geminiService';
import {
  ScanEye,
  Upload,
  Cpu,
  Sparkles,
  ShieldAlert,
  Copy,
  Check,
  Save,
  Palette,
  Camera,
  Activity,
  Image as ImageIcon,
} from 'lucide-react';

interface Props {
  aiMode: AIMode;
  onSavePrompt: (prompt: PromptItem) => void;
  onNavigate: (section: string) => void;
}

interface LocalImageMetrics {
  fileName: string;
  fileSizeKB: number;
  width: number;
  height: number;
  aspectRatio: string;
  orientation: 'Landskap' | 'Porträtt' | 'Kvadrat';
  brightness: number;
  contrast: number;
  saturation: number;
  dominantColors: string[];
  histogram: number[]; // 32 bins
}

export const ImageAnalysisSection: React.FC<Props> = ({ aiMode, onSavePrompt }) => {
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [localMetrics, setLocalMetrics] = useState<LocalImageMetrics | null>(null);

  // Gemini opt-in state
  const [userConsentedGemini, setUserConsentedGemini] = useState(false);
  const [isGeminiAnalyzing, setIsGeminiAnalyzing] = useState(false);
  const [geminiResult, setGeminiResult] = useState<{
    subject: string;
    environment: string;
    lighting: string;
    composition: string;
    cameraLens: string;
    style: string;
    colorPalette: string[];
    reconstructedPrompt: string;
    negativePrompt: string;
    keyTags: string[];
  } | null>(null);

  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImageFile(file);
    const reader = new FileReader();
    reader.onload = (event) => {
      const src = event.target?.result as string;
      setImageSrc(src);
      analyzeLocalCanvas(src, file);
      setGeminiResult(null);
      setUserConsentedGemini(false);
    };
    reader.readAsDataURL(file);
  };

  const analyzeLocalCanvas = (src: string, file: File) => {
    const img = new Image();
    img.crossOrigin = 'Anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      canvas.width = Math.min(img.width, 300);
      canvas.height = Math.min(img.height, 300);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

      const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imgData.data;

      let totalBrightness = 0;
      let totalR = 0, totalG = 0, totalB = 0;
      const histBins = new Array(32).fill(0);

      for (let i = 0; i < data.length; i += 4) {
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        const lum = 0.299 * r + 0.587 * g + 0.114 * b;
        totalBrightness += lum;
        totalR += r;
        totalG += g;
        totalB += b;

        const bin = Math.min(Math.floor((lum / 256) * 32), 31);
        histBins[bin]++;
      }

      const pixelCount = data.length / 4;
      const avgBrightness = Math.round(totalBrightness / pixelCount);
      const avgR = Math.round(totalR / pixelCount);
      const avgG = Math.round(totalG / pixelCount);
      const avgB = Math.round(totalB / pixelCount);

      // Contrast estimate
      let variance = 0;
      for (let i = 0; i < data.length; i += 4) {
        const lum = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
        variance += Math.pow(lum - avgBrightness, 2);
      }
      const contrast = Math.round(Math.sqrt(variance / pixelCount));

      // Orientation
      const w = img.naturalWidth || canvas.width;
      const h = img.naturalHeight || canvas.height;
      const ratioVal = (w / h).toFixed(2);
      const orientation = w > h ? 'Landskap' : w < h ? 'Porträtt' : 'Kvadrat';

      const dominantColors = [
        `rgb(${avgR}, ${avgG}, ${avgB})`,
        `rgb(${Math.min(255, avgR + 30)}, ${avgG}, ${Math.max(0, avgB - 20)})`,
        `rgb(${Math.max(0, avgR - 30)}, ${Math.min(255, avgG + 20)}, ${avgB})`,
        `rgb(${avgR}, ${Math.max(0, avgG - 20)}, ${Math.min(255, avgB + 40)})`,
      ];

      setLocalMetrics({
        fileName: file.name,
        fileSizeKB: Math.round(file.size / 1024),
        width: w,
        height: h,
        aspectRatio: `${ratioVal}:1 (${orientation})`,
        orientation,
        brightness: avgBrightness,
        contrast,
        saturation: Math.round((Math.max(avgR, avgG, avgB) - Math.min(avgR, avgG, avgB)) / 2.55),
        dominantColors,
        histogram: histBins,
      });
    };
    img.src = src;
  };

  const handleRunGeminiAnalysis = async () => {
    if (!imageSrc) return;
    setUserConsentedGemini(true);
    setIsGeminiAnalyzing(true);

    try {
      const mime = imageFile?.type || 'image/jpeg';
      const res = await geminiService.analyzeImage(imageSrc, mime, 'sv');
      setGeminiResult(res);
    } catch (err: any) {
      alert(`Gemini bildanalys misslyckades: ${err.message || err}`);
    } finally {
      setIsGeminiAnalyzing(false);
    }
  };

  const handleCopyPrompt = () => {
    if (!geminiResult) return;
    navigator.clipboard.writeText(geminiResult.reconstructedPrompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSavePrompt = () => {
    if (!geminiResult) return;
    const item: PromptItem = {
      id: `img-reverse-${Date.now()}`,
      title: `Från bild: ${geminiResult.subject.slice(0, 30)}`,
      category: 'Image Reverse',
      type: 'image',
      prompt: geminiResult.reconstructedPrompt,
      negativePrompt: geminiResult.negativePrompt,
      tags: ['reverse-prompt', 'image-analysis', ...(geminiResult.keyTags || [])],
      createdAt: Date.now(),
      updatedAt: Date.now(),
      modeUsed: 'gemini',
    };
    onSavePrompt(item);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="border-b border-gray-800 pb-4">
        <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
          <ScanEye className="w-5 h-5 text-purple-400" />
          Image Analysis Lab
        </h1>
        <p className="text-xs text-gray-400 mt-1">
          Lokal HTML5 Canvas-telemetri (histogram, färger, kontrast) samt frivillig Gemini multimodal reverse-engineering.
        </p>
      </div>

      {/* Upload Zone */}
      <div
        onClick={() => fileInputRef.current?.click()}
        className="cursor-pointer flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-gray-800 bg-gray-900/40 p-6 sm:p-8 text-center hover:border-purple-500/50 hover:bg-gray-900/70 transition"
      >
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileUpload}
          accept="image/*"
          className="hidden"
        />
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-purple-500/10 text-purple-400 mb-3">
          <Upload className="w-6 h-6" />
        </div>
        <h3 className="font-bold text-sm text-white">Välj eller släpp en bild här</h3>
        <p className="text-xs text-gray-400 mt-1">
          JPG, PNG, WebP upp till 20 MB. Bilden analyseras först 100% lokalt i webbläsaren.
        </p>
      </div>

      {imageSrc && localMetrics && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-in fade-in duration-300">
          {/* Left Preview & Local Canvas Analysis */}
          <div className="lg:col-span-5 space-y-4">
            <div className="rounded-2xl border border-gray-800 bg-gray-900/80 p-4 space-y-3">
              <span className="text-xs font-bold text-gray-200 uppercase tracking-wider block">
                Förhandsvisning & Bildfil
              </span>
              <div className="relative rounded-xl overflow-hidden max-h-72 flex items-center justify-center bg-gray-950">
                <img src={imageSrc} alt="Preview" className="w-full h-full object-contain" />
              </div>
              <div className="flex items-center justify-between text-xs text-gray-400 pt-1">
                <span>{localMetrics.fileName}</span>
                <span>{localMetrics.fileSizeKB} KB</span>
              </div>
            </div>

            {/* Local Canvas Technical Metrics */}
            <div className="rounded-2xl border border-gray-800 bg-gray-900/80 p-4 space-y-3">
              <div className="flex items-center gap-2 border-b border-gray-800 pb-2">
                <Cpu className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Lokal Canvas Analys (På enheten)
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-gray-950/60 p-2.5 rounded-xl border border-gray-800">
                  <span className="text-gray-500 block text-[10px]">Dimensioner</span>
                  <span className="font-semibold text-gray-200">
                    {localMetrics.width} × {localMetrics.height} px
                  </span>
                </div>
                <div className="bg-gray-950/60 p-2.5 rounded-xl border border-gray-800">
                  <span className="text-gray-500 block text-[10px]">Bildförhållande</span>
                  <span className="font-semibold text-gray-200">{localMetrics.aspectRatio}</span>
                </div>
                <div className="bg-gray-950/60 p-2.5 rounded-xl border border-gray-800">
                  <span className="text-gray-500 block text-[10px]">Medelljusstyrka</span>
                  <span className="font-semibold text-gray-200">{localMetrics.brightness} / 255</span>
                </div>
                <div className="bg-gray-950/60 p-2.5 rounded-xl border border-gray-800">
                  <span className="text-gray-500 block text-[10px]">Kontrastomfång</span>
                  <span className="font-semibold text-gray-200">{localMetrics.contrast}</span>
                </div>
              </div>

              {/* Dominant Colors Bar */}
              <div className="space-y-1.5 pt-1">
                <span className="text-[10px] font-semibold text-gray-400 block">Dominerande färgtoner:</span>
                <div className="flex gap-2">
                  {localMetrics.dominantColors.map((col, idx) => (
                    <div
                      key={idx}
                      className="h-7 flex-1 rounded-lg border border-gray-700 shadow-inner"
                      style={{ backgroundColor: col }}
                      title={col}
                    />
                  ))}
                </div>
              </div>

              {/* Histogram Display */}
              <div className="space-y-1 pt-1">
                <span className="text-[10px] font-semibold text-gray-400 block">Luminans-histogram:</span>
                <div className="h-10 flex items-end gap-0.5 bg-gray-950 p-1.5 rounded-lg border border-gray-800">
                  {localMetrics.histogram.map((count, i) => {
                    const maxVal = Math.max(...localMetrics.histogram) || 1;
                    const hPct = Math.round((count / maxVal) * 100);
                    return (
                      <div
                        key={i}
                        className="flex-1 bg-sky-400/70 rounded-t-xs hover:bg-sky-300 transition"
                        style={{ height: `${Math.max(hPct, 4)}%` }}
                      />
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Right Gemini Reverse-Engineering Lab */}
          <div className="lg:col-span-7 space-y-4">
            {/* Gemini Opt-In Consent Box */}
            <div className="rounded-2xl border border-purple-500/30 bg-purple-950/20 p-5 space-y-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-sky-400" />
                <h3 className="font-bold text-sm text-white">
                  Gemini Multimodal Bildförståelse & Reverse Prompting
                </h3>
              </div>

              <p className="text-xs text-gray-300 leading-relaxed">
                Skicka bilden till Google Gemini för att dekonstruera motiv, ljusvinkel, exakt objektiv och generera en mästerprompt som återskapar stilen.
              </p>

              <div className="rounded-xl border border-amber-500/30 bg-amber-950/30 p-2.5 flex items-center gap-2 text-[11px] text-amber-200">
                <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
                <span>
                  <strong>Integritetsnotis:</strong> Bilden lämnar endast din enhet om du klickar på knappen nedan.
                </span>
              </div>

              <button
                onClick={handleRunGeminiAnalysis}
                disabled={isGeminiAnalyzing}
                className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-purple-600 to-sky-600 px-5 py-3 text-xs sm:text-sm font-bold text-white shadow-lg hover:brightness-110 active:scale-95 transition disabled:opacity-50 min-h-[44px]"
              >
                {isGeminiAnalyzing ? (
                  <span>Analyserar med Gemini...</span>
                ) : (
                  <>
                    <ScanEye className="w-4 h-4" />
                    <span>Kör Gemini AI Bildanalys</span>
                  </>
                )}
              </button>
            </div>

            {/* Gemini Result Box */}
            {geminiResult && (
              <div className="rounded-2xl border border-gray-800 bg-gray-900/80 p-5 space-y-4 animate-in fade-in duration-300">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider block">
                  Identifierade Parametrar
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="bg-gray-950 p-3 rounded-xl border border-gray-800">
                    <span className="text-gray-500 block text-[10px]">Motiv & Pose</span>
                    <span className="text-gray-200 font-medium">{geminiResult.subject}</span>
                  </div>
                  <div className="bg-gray-950 p-3 rounded-xl border border-gray-800">
                    <span className="text-gray-500 block text-[10px]">Visuell Stil</span>
                    <span className="text-gray-200 font-medium">{geminiResult.style}</span>
                  </div>
                  <div className="bg-gray-950 p-3 rounded-xl border border-gray-800">
                    <span className="text-gray-500 block text-[10px]">Ljussättning</span>
                    <span className="text-gray-200 font-medium">{geminiResult.lighting}</span>
                  </div>
                  <div className="bg-gray-950 p-3 rounded-xl border border-gray-800">
                    <span className="text-gray-500 block text-[10px]">Uppskattat Objektiv</span>
                    <span className="text-gray-200 font-medium">{geminiResult.cameraLens}</span>
                  </div>
                </div>

                {/* Reconstructed Master Prompt */}
                <div className="rounded-xl border border-purple-500/30 bg-purple-950/20 p-4 space-y-2">
                  <span className="text-xs font-bold text-purple-300 uppercase tracking-wider block">
                    Återskapad Master Prompt (Reverse Engineered):
                  </span>
                  <p className="text-xs sm:text-sm text-gray-100 font-mono leading-relaxed select-all">
                    {geminiResult.reconstructedPrompt}
                  </p>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={handleCopyPrompt}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gray-800 px-4 py-2 text-xs font-semibold text-white hover:bg-gray-700 active:scale-95 transition min-h-[44px]"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    <span>{copied ? 'Kopierad!' : 'Kopiera Master Prompt'}</span>
                  </button>

                  <button
                    onClick={handleSavePrompt}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:brightness-110 active:scale-95 transition min-h-[44px]"
                  >
                    {saved ? <Check className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
                    <span>{saved ? 'Sparad i Projekt!' : 'Spara Prompt'}</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
