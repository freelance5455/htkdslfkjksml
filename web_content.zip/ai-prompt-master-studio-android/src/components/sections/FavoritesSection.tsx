import React, { useState } from 'react';
import { PromptItem } from '../../types';
import {
  Bookmark,
  Search,
  Copy,
  Check,
  Trash2,
  Wand2,
  Camera,
  Film,
} from 'lucide-react';

interface Props {
  favorites: PromptItem[];
  onToggleFavorite: (id: string) => void;
  onSelectPrompt: (prompt: PromptItem) => void;
  onDeletePrompt: (id: string) => void;
  onNavigate: (section: string) => void;
}

export const FavoritesSection: React.FC<Props> = ({
  favorites,
  onToggleFavorite,
  onSelectPrompt,
  onDeletePrompt,
  onNavigate,
}) => {
  const [search, setSearch] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filtered = favorites.filter(
    (p) =>
      p.title.toLowerCase().includes(search.toLowerCase()) ||
      p.prompt.toLowerCase().includes(search.toLowerCase())
  );

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-800 pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
            <Bookmark className="w-5 h-5 text-amber-400" />
            Sparade Favoriter ({favorites.length})
          </h1>
          <p className="text-xs text-gray-400 mt-1">
            Dina stjärnmärkta mästerverksprompter samlade för snabb åtkomst och återanvändning.
          </p>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-gray-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Sök bland dina favoriter..."
          className="w-full rounded-xl border border-gray-800 bg-gray-900/60 pl-10 pr-4 py-2.5 text-xs sm:text-sm text-white placeholder-gray-500 focus:border-amber-500 focus:outline-none min-h-[44px]"
        />
      </div>

      {/* Favorites List */}
      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-gray-800 bg-gray-900/30 p-12 text-center space-y-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-amber-500/10 text-amber-400 mx-auto">
            <Bookmark className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-sm text-gray-200">Inga favoriter än</h3>
          <p className="text-xs text-gray-400 max-w-sm mx-auto">
            Klicka på bokmärkesikonen i Prompt Builder eller Prompt Library för att spara prompter här.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map((item) => (
            <div
              key={item.id}
              className="rounded-2xl border border-gray-800 bg-gray-900/70 p-4 sm:p-5 space-y-3 flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-start justify-between gap-2 border-b border-gray-800 pb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-white">{item.title}</span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-gray-800 text-gray-400 uppercase">
                      {item.type}
                    </span>
                  </div>
                  <button
                    onClick={() => onToggleFavorite(item.id)}
                    className="p-1.5 text-amber-400 hover:text-gray-400 rounded-lg hover:bg-gray-800 transition min-h-[36px] min-w-[36px] flex items-center justify-center"
                    title="Ta bort från favoriter"
                  >
                    <Bookmark className="w-4 h-4 fill-amber-400" />
                  </button>
                </div>

                <div className="rounded-xl border border-gray-800 bg-gray-950 p-3">
                  <p className="text-xs text-gray-200 font-mono leading-relaxed select-all line-clamp-4">
                    {item.prompt}
                  </p>
                </div>

                {item.negativePrompt && (
                  <div className="text-[11px] text-rose-300/80 font-mono truncate bg-rose-950/20 px-2 py-1 rounded">
                    <strong>Negativ:</strong> {item.negativePrompt}
                  </div>
                )}
              </div>

              {/* Action Toolbar */}
              <div className="flex items-center gap-2 pt-2 border-t border-gray-800">
                <button
                  onClick={() => handleCopy(item.id, item.prompt)}
                  className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gray-800 px-3 py-2 text-xs font-semibold text-white hover:bg-gray-700 active:scale-95 transition min-h-[40px]"
                >
                  {copiedId === item.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedId === item.id ? 'Kopierad' : 'Kopiera'}</span>
                </button>

                <button
                  onClick={() => {
                    onSelectPrompt(item);
                    onNavigate('prompt-builder');
                  }}
                  className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-purple-600/30 border border-purple-500/40 px-3 py-2 text-xs font-semibold text-purple-200 hover:bg-purple-600 hover:text-white transition min-h-[40px]"
                >
                  <Wand2 className="w-3.5 h-3.5" />
                  <span>Öppna i Builder</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
