import React, { useState } from 'react';
import { Project, PromptItem, CharacterProfile } from '../../types';
import { storageService } from '../../services/storage';
import {
  FolderKanban,
  Plus,
  Trash2,
  Copy,
  Edit2,
  Tag,
  Users,
  Film,
  Download,
  Check,
  Search,
} from 'lucide-react';

interface Props {
  projects: Project[];
  prompts: PromptItem[];
  onRefreshProjects: () => void;
  onNavigate: (section: string) => void;
}

export const ProjectManagerSection: React.FC<Props> = ({
  projects,
  prompts,
  onRefreshProjects,
  onNavigate,
}) => {
  const [search, setSearch] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newCategory, setNewCategory] = useState('Film & Sci-Fi');
  const [newTags, setNewTags] = useState('cinematic, project');

  const [activeProject, setActiveProject] = useState<Project | null>(projects[0] || null);

  const handleCreateProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const pr: Project = {
      id: `proj-${Date.now()}`,
      title: newTitle.trim(),
      description: newDescription.trim(),
      category: newCategory,
      promptIds: [],
      characters: [],
      tags: newTags.split(',').map((t) => t.trim()).filter(Boolean),
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    await storageService.saveProject(pr);
    setIsCreating(false);
    setNewTitle('');
    setNewDescription('');
    onRefreshProjects();
    setActiveProject(pr);
  };

  const handleDeleteProject = async (id: string) => {
    if (confirm('Är du säker på att du vill ta bort detta projekt?')) {
      await storageService.deleteProject(id);
      onRefreshProjects();
      if (activeProject?.id === id) setActiveProject(null);
    }
  };

  const handleDuplicateProject = async (pr: Project) => {
    const copy: Project = {
      ...pr,
      id: `proj-dup-${Date.now()}`,
      title: `${pr.title} (Kopia)`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    await storageService.saveProject(copy);
    onRefreshProjects();
  };

  const handleExportProject = (pr: Project) => {
    const projectPrompts = prompts.filter((p) => pr.promptIds.includes(p.id));
    const data = { project: pr, prompts: projectPrompts };
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(data, null, 2));
    const a = document.createElement('a');
    a.href = dataStr;
    a.download = `project-${pr.id}.json`;
    a.click();
  };

  const filteredProjects = projects.filter(
    (p) =>
      p.title.toLowerCase().includes(search.toLowerCase()) ||
      p.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-800 pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
            <FolderKanban className="w-5 h-5 text-purple-400" />
            Project Manager
          </h1>
          <p className="text-xs text-gray-400 mt-1">
            Organisera prompter, storyboards, karaktärsprofiler och taggar i sammanhållna kreativa projekt.
          </p>
        </div>

        <button
          onClick={() => setIsCreating(true)}
          className="flex items-center gap-1.5 rounded-xl bg-purple-600 px-4 py-2.5 text-xs font-semibold text-white hover:bg-purple-500 transition min-h-[44px]"
        >
          <Plus className="w-4 h-4" />
          <span>Skapa Nytt Projekt</span>
        </button>
      </div>

      {/* Create Modal / Form */}
      {isCreating && (
        <form
          onSubmit={handleCreateProject}
          className="rounded-2xl border border-purple-500/40 bg-purple-950/20 p-5 space-y-3 animate-in fade-in"
        >
          <span className="font-bold text-sm text-purple-300 block">Skapa Nytt Projekt</span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-gray-400 block mb-1">Projekttitel *</label>
              <input
                type="text"
                required
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="Ex: Cyberpunk Spelfilm 2026"
                className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500 min-h-[40px]"
              />
            </div>
            <div>
              <label className="text-xs text-gray-400 block mb-1">Kategori</label>
              <input
                type="text"
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                placeholder="Ex: Kortfilm, Marknadsföring"
                className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500 min-h-[40px]"
              />
            </div>
          </div>
          <div>
            <label className="text-xs text-gray-400 block mb-1">Beskrivning</label>
            <textarea
              value={newDescription}
              onChange={(e) => setNewDescription(e.target.value)}
              placeholder="Kort sammanfattning av projektets tema och mål..."
              rows={2}
              className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsCreating(false)}
              className="px-4 py-2 rounded-xl text-xs text-gray-400 hover:text-white"
            >
              Avbryt
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-purple-600 text-xs font-semibold text-white hover:bg-purple-500 transition min-h-[40px]"
            >
              Skapa Projekt
            </button>
          </div>
        </form>
      )}

      {/* Projects List & Details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Projects List */}
        <div className="lg:col-span-5 space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 text-gray-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Sök projekt..."
              className="w-full rounded-xl border border-gray-800 bg-gray-950 pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500 min-h-[40px]"
            />
          </div>

          {filteredProjects.length === 0 ? (
            <div className="rounded-2xl border border-gray-800 bg-gray-900/40 p-6 text-center text-xs text-gray-500">
              Inga projekt skapade än.
            </div>
          ) : (
            <div className="space-y-2">
              {filteredProjects.map((pr) => (
                <div
                  key={pr.id}
                  onClick={() => setActiveProject(pr)}
                  className={`cursor-pointer rounded-2xl border p-4 transition ${
                    activeProject?.id === pr.id
                      ? 'border-purple-500 bg-purple-950/20 shadow-md'
                      : 'border-gray-800 bg-gray-900/60 hover:border-gray-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="font-bold text-sm text-white block">{pr.title}</span>
                      <span className="text-[11px] text-gray-400 block mt-0.5">{pr.category}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDuplicateProject(pr);
                        }}
                        className="p-1 text-gray-400 hover:text-white"
                        title="Duplicera"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteProject(pr.id);
                        }}
                        className="p-1 text-gray-400 hover:text-rose-400"
                        title="Radera"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                  {pr.description && (
                    <p className="text-xs text-gray-400 line-clamp-2 mt-2">{pr.description}</p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Active Project Details */}
        <div className="lg:col-span-7">
          {activeProject ? (
            <div className="rounded-2xl border border-gray-800 bg-gray-900/80 p-5 space-y-4">
              <div className="flex items-start justify-between border-b border-gray-800 pb-3">
                <div>
                  <h2 className="text-lg font-bold text-white">{activeProject.title}</h2>
                  <span className="text-xs text-purple-400">{activeProject.category}</span>
                </div>
                <button
                  onClick={() => handleExportProject(activeProject)}
                  className="flex items-center gap-1.5 rounded-xl border border-gray-800 bg-gray-950 px-3 py-1.5 text-xs text-gray-300 hover:text-white transition"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Exportera Projekt</span>
                </button>
              </div>

              {activeProject.description && (
                <p className="text-xs text-gray-300 leading-relaxed">{activeProject.description}</p>
              )}

              {/* Tags */}
              <div className="flex flex-wrap gap-1">
                {activeProject.tags?.map((t) => (
                  <span
                    key={t}
                    className="text-[10px] px-2 py-0.5 rounded-md bg-gray-950 text-gray-400 border border-gray-800"
                  >
                    #{t}
                  </span>
                ))}
              </div>

              {/* Prompts linked to project */}
              <div className="space-y-2 pt-2 border-t border-gray-800">
                <span className="text-xs font-bold text-gray-300 uppercase tracking-wider block">
                  Kopplade Prompter
                </span>
                <p className="text-xs text-gray-400">
                  När du sparar prompter i Prompt Builder kan du koppla dem direkt till detta projekt.
                </p>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center rounded-2xl border border-dashed border-gray-800 p-8 text-center text-xs text-gray-500">
              Välj eller skapa ett projekt i listan till vänster.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
