import React, { useState } from 'react';
import { AIMode, MediaType, PromptItem, QualityScoreResult } from '../../types';
import { localPromptEngine, VOCABULARY } from '../../services/localEngine';
import { geminiService } from '../../services/geminiService';
import { evaluatePromptQuality } from '../../services/qualityScorer';
import { QualityScoreCard } from '../common/QualityScoreCard';
import {
  Wand2,
  Copy,
  Check,
  Save,
  Bookmark,
  RefreshCw,
  Sliders,
  Trash2,
  Download,
  Sparkles,
  Camera,
  Sun,
  Eye,
  Film,
  Layers,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

interface Props {
  aiMode: AIMode;
  onSavePrompt: (prompt: PromptItem) => void;
  selectedPrompt?: PromptItem | null;
  onNavigate: (section: string) => void;
}

export const PromptBuilderSection: React.FC<Props> = ({
  aiMode,
  onSavePrompt,
  selectedPrompt,
  onNavigate,
}) => {
  // Form fields
  const [type, setType] = useState<MediaType>(selectedPrompt?.type || 'image');
  const [subject, setSubject] = useState(selectedPrompt?.prompt || '');
  const [action, setAction] = useState('');
  const [environment, setEnvironment] = useState('');
  const [timeAndWeather, setTimeAndWeather] = useState('');
  const [mood, setMood] = useState('');
  const [visualStyle, setVisualStyle] = useState('');
  const [camera, setCamera] = useState('');
  const [lens, setLens] = useState('');
  const [lighting, setLighting] = useState('');
  const [composition, setComposition] = useState('');
  const [colorPalette, setColorPalette] = useState('');
  const [movement, setMovement] = useState('');
  const [aspectRatio, setAspectRatio] = useState(selectedPrompt?.aspectRatio || '16:9');
  const [videoDuration, setVideoDuration] = useState('5s');
  const [negativeInstructions, setNegativeInstructions] = useState(selectedPrompt?.negativePrompt || '');
  const [platform, setPlatform] = useState(selectedPrompt?.platform || 'Midjourney');
  const [language, setLanguage] = useState<'sv' | 'en'>('sv');
  const [detailLevel, setDetailLevel] = useState<'short' | 'detailed' | 'professional' | 'ultimate'>('ultimate');

  // Generation state
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState<'ultimate' | 'detailed' | 'professional' | 'short' | 'structured' | 'alternatives'>('ultimate');
  const [results, setResults] = useState<{
    shortPrompt: string;
    detailedPrompt: string;
    professionalPrompt: string;
    ultimatePrompt: string;
    structuredPrompt: string;
    negativePrompt: string;
    alternatives: string[];
    quality: QualityScoreResult;
  } | null>(null);

  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [isFavorite, setIsFavorite] = useState(selectedPrompt?.isFavorite || false);
  const [showAdvanced, setShowAdvanced] = useState(false);

  const handleGenerate = async () => {
    if (!subject.trim()) return;
    setIsGenerating(true);

    try {
      if (aiMode === 'gemini') {
        const promptInput = `
Subject: ${subject}
Action: ${action}
Environment: ${environment}
Time & Weather: ${timeAndWeather}
Mood: ${mood}
Visual Style: ${visualStyle}
Camera: ${camera}
Lens: ${lens}
Lighting: ${lighting}
Composition: ${composition}
Color Palette: ${colorPalette}
Movement: ${movement}
Type: ${type}
Platform: ${platform}
Language: ${language}
Negative custom: ${negativeInstructions}
`;
        const res = await geminiService.autoBuild(promptInput, language);
        const quality = evaluatePromptQuality(res.ultimatePrompt || res.professionalPrompt, type, res.negativePrompt);
        quality.evaluationType = 'gemini';

        setResults({
          shortPrompt: res.shortPrompt || '',
          detailedPrompt: res.detailedPrompt || '',
          professionalPrompt: res.professionalPrompt || '',
          ultimatePrompt: res.ultimatePrompt || '',
          structuredPrompt: [
            `[Subject]: ${res.subject || subject}`,
            `[Style]: ${res.visualStyle || visualStyle}`,
            `[Lighting]: ${res.lighting || lighting}`,
            `[Camera]: ${res.cameraAndLens || camera}`,
          ].join('\n'),
          negativePrompt: res.negativePrompt || '',
          alternatives: [
            res.shortPrompt,
            res.detailedPrompt,
            res.professionalPrompt,
          ].filter(Boolean),
          quality,
        });
      } else {
        // Free Local Mode
        const res = localPromptEngine.generatePrompts({
          type,
          subject,
          action,
          environment,
          timeAndWeather,
          visualStyle,
          composition,
          camera,
          lens,
          lighting,
          colorPalette,
          materials: mood,
          aspectRatio,
          negativeInstructions,
          detailLevel,
        });
        setResults(res);
      }
    } catch (err) {
      console.warn('Gemini generate failed, fallback to local engine:', err);
      const res = localPromptEngine.generatePrompts({
        type,
        subject,
        action,
        environment,
        timeAndWeather,
        visualStyle,
        composition,
        camera,
        lens,
        lighting,
        colorPalette,
        materials: mood,
        aspectRatio,
        negativeInstructions,
        detailLevel,
      });
      setResults(res);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopy = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleSave = () => {
    if (!results) return;
    const currentText =
      activeTab === 'short'
        ? results.shortPrompt
        : activeTab === 'detailed'
        ? results.detailedPrompt
        : activeTab === 'professional'
        ? results.professionalPrompt
        : results.ultimatePrompt;

    const newPrompt: PromptItem = {
      id: selectedPrompt?.id || `prompt-${Date.now()}`,
      title: subject.slice(0, 40) || 'Byggd Prompt',
      category: type === 'video' ? 'Video Studio' : 'Image Studio',
      type,
      prompt: currentText,
      negativePrompt: results.negativePrompt,
      shortPrompt: results.shortPrompt,
      detailedPrompt: results.detailedPrompt,
      professionalPrompt: results.professionalPrompt,
      ultimatePrompt: results.ultimatePrompt,
      aspectRatio,
      platform,
      tags: [type, platform.toLowerCase(), 'builder'],
      qualityScore: results.quality.totalScore,
      qualityBreakdown: results.quality.breakdown,
      createdAt: selectedPrompt?.createdAt || Date.now(),
      updatedAt: Date.now(),
      isFavorite,
      modeUsed: aiMode,
    };

    onSavePrompt(newPrompt);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleClear = () => {
    setSubject('');
    setAction('');
    setEnvironment('');
    setTimeAndWeather('');
    setMood('');
    setVisualStyle('');
    setCamera('');
    setLens('');
    setLighting('');
    setComposition('');
    setColorPalette('');
    setMovement('');
    setNegativeInstructions('');
    setResults(null);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
              <Wand2 className="w-5 h-5 text-purple-400" />
              Ultimate Prompt Builder
            </h1>
            <span className="rounded-full bg-purple-500/20 px-2.5 py-0.5 text-xs font-semibold text-purple-300 border border-purple-500/30">
              12 Dimensioner
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-1">
            Bygg prisbelönta prompter med kirurgisk precision. Körs lokalt eller med Gemini AI.
          </p>
        </div>

        {/* Type Toggle & Actions */}
        <div className="flex items-center gap-2">
          <div className="flex rounded-xl bg-gray-950 p-1 border border-gray-800">
            <button
              onClick={() => setType('image')}
              className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition min-h-[36px] ${
                type === 'image'
                  ? 'bg-purple-600 text-white'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Camera className="w-3.5 h-3.5" />
              Bild
            </button>
            <button
              onClick={() => setType('video')}
              className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition min-h-[36px] ${
                type === 'video'
                  ? 'bg-sky-600 text-white'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Film className="w-3.5 h-3.5" />
              Video
            </button>
          </div>

          <button
            onClick={handleClear}
            className="flex items-center gap-1.5 rounded-xl border border-gray-800 bg-gray-900/80 px-3 py-2 text-xs font-medium text-gray-400 hover:text-rose-400 hover:bg-gray-800 transition min-h-[44px]"
            title="Rensa formulär"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Rensa</span>
          </button>
        </div>
      </div>

      {/* Main Builder Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form: 12 Dimensions */}
        <div className="lg:col-span-7 space-y-4">
          {/* Dimension 1: Main Subject (Required) */}
          <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 space-y-2">
            <label className="text-xs font-bold text-gray-200 uppercase tracking-wider flex items-center justify-between">
              <span>1. Huvudmotiv (Subject) *</span>
              <span className="text-[10px] text-purple-400 lowercase font-normal">obligatoriskt</span>
            </label>
            <textarea
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Ex: En 900-tals vikingakrigare med silverflätat skägg och bärnstensögon..."
              rows={3}
              className="w-full rounded-xl border border-gray-800 bg-gray-950 p-3 text-xs sm:text-sm text-white placeholder-gray-500 focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500 transition font-sans"
            />
          </div>

          {/* Dimension 2 & 3: Action & Environment */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-3.5 space-y-1.5">
              <label className="text-xs font-bold text-gray-200 flex items-center gap-1.5">
                <span>2. Handling & Pose (Action)</span>
              </label>
              <input
                type="text"
                value={action}
                onChange={(e) => setAction(e.target.value)}
                placeholder="Ex: står blickstilla och blickar mot horisonten"
                className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white placeholder-gray-500 focus:border-purple-500 focus:outline-none min-h-[44px]"
              />
            </div>

            <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-3.5 space-y-1.5">
              <label className="text-xs font-bold text-gray-200 flex items-center gap-1.5">
                <span>3. Miljö & Plats (Environment)</span>
              </label>
              <input
                type="text"
                value={environment}
                onChange={(e) => setEnvironment(e.target.value)}
                placeholder="Ex: klippavsats ovanför en norsk fjord med barrskog"
                className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white placeholder-gray-500 focus:border-purple-500 focus:outline-none min-h-[44px]"
              />
            </div>
          </div>

          {/* Dimension 4 & 5: Time/Weather & Visual Style */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-3.5 space-y-1.5">
              <label className="text-xs font-bold text-gray-200">
                4. Tid & Väder (Time/Weather)
              </label>
              <input
                type="text"
                value={timeAndWeather}
                onChange={(e) => setTimeAndWeather(e.target.value)}
                placeholder="Ex: tidig gryning med tät morgondimma och frost"
                className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white placeholder-gray-500 focus:border-purple-500 focus:outline-none min-h-[44px]"
              />
            </div>

            <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-3.5 space-y-1.5">
              <label className="text-xs font-bold text-gray-200">
                5. Visuell Stil (Visual Style)
              </label>
              <input
                type="text"
                value={visualStyle}
                onChange={(e) => setVisualStyle(e.target.value)}
                placeholder="Ex: 35mm cinematic film still, photorealistic, analog"
                className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white placeholder-gray-500 focus:border-purple-500 focus:outline-none min-h-[44px]"
              />
            </div>
          </div>

          {/* Advanced Dimensions Accordion */}
          <div className="rounded-2xl border border-gray-800 bg-gray-900/60 overflow-hidden">
            <button
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="flex w-full items-center justify-between p-4 text-xs font-bold uppercase tracking-wider text-gray-300 hover:bg-gray-800/40 transition min-h-[44px]"
            >
              <span className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-sky-400" />
                Avancerade Optik & Ljusdimensioner (6–12)
              </span>
              {showAdvanced ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {showAdvanced && (
              <div className="p-4 pt-0 space-y-3 border-t border-gray-800/60">
                {/* 6. Composition & 7. Camera */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3">
                  <div className="space-y-1">
                    <label className="text-xs font-medium text-gray-300">6. Komposition</label>
                    <input
                      type="text"
                      value={composition}
                      onChange={(e) => setComposition(e.target.value)}
                      placeholder="Ex: gyllene snittet, ledlinjer, djup i tre lager"
                      className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:border-purple-500 focus:outline-none min-h-[44px]"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-medium text-gray-300">7. Kamera & Sensor</label>
                    <input
                      type="text"
                      value={camera}
                      onChange={(e) => setCamera(e.target.value)}
                      placeholder="Ex: Hasselblad H6D-100c eller ARRI Alexa LF"
                      className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:border-purple-500 focus:outline-none min-h-[44px]"
                    />
                  </div>
                </div>

                {/* 8. Lens & 9. Lighting */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs font-medium text-gray-300">8. Objektiv & Bländare</label>
                    <input
                      type="text"
                      value={lens}
                      onChange={(e) => setLens(e.target.value)}
                      placeholder="Ex: 85mm f/1.4 prime, anamorfiskt glas"
                      className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:border-purple-500 focus:outline-none min-h-[44px]"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-medium text-gray-300">9. Ljussättning</label>
                    <input
                      type="text"
                      value={lighting}
                      onChange={(e) => setLighting(e.target.value)}
                      placeholder="Ex: volymetriskt motljus med skarp kantbelysning"
                      className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:border-purple-500 focus:outline-none min-h-[44px]"
                    />
                  </div>
                </div>

                {/* 10. Color & 11. Materials / Movement */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs font-medium text-gray-300">10. Färgpalett & LUT</label>
                    <input
                      type="text"
                      value={colorPalette}
                      onChange={(e) => setColorPalette(e.target.value)}
                      placeholder="Ex: Kodak Portra 400, teal och bärnsten"
                      className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:border-purple-500 focus:outline-none min-h-[44px]"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-medium text-gray-300">
                      {type === 'video' ? '11. Kamerarörelse' : '11. Material & Texturer'}
                    </label>
                    <input
                      type="text"
                      value={type === 'video' ? movement : mood}
                      onChange={(e) => (type === 'video' ? setMovement(e.target.value) : setMood(e.target.value))}
                      placeholder={type === 'video' ? 'Ex: slow dolly in forward, tracking' : 'Ex: grovt ylle, slitet läder, hudporer'}
                      className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:border-purple-500 focus:outline-none min-h-[44px]"
                    />
                  </div>
                </div>

                {/* 12. Negative Instructions */}
                <div className="space-y-1">
                  <label className="text-xs font-medium text-gray-300">12. Negativa Instruktioner (Undvik)</label>
                  <input
                    type="text"
                    value={negativeInstructions}
                    onChange={(e) => setNegativeInstructions(e.target.value)}
                    placeholder="Ex: suddigt, extra fingrar, plastig hud, vattenstämpel"
                    className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:border-purple-500 focus:outline-none min-h-[44px]"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Platform & Format Config */}
          <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-[11px] font-semibold text-gray-300 block mb-1">Målplattform</label>
              <select
                value={platform}
                onChange={(e) => setPlatform(e.target.value)}
                className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:border-purple-500 focus:outline-none min-h-[44px]"
              >
                <option value="Midjourney">Midjourney v6.1</option>
                <option value="FLUX">FLUX.1 [dev]</option>
                <option value="Google Veo">Google Veo</option>
                <option value="Runway Gen-3">Runway Gen-3</option>
                <option value="Sora">OpenAI Sora</option>
                <option value="Leonardo AI">Leonardo AI</option>
                <option value="Stable Diffusion">Stable Diffusion XL</option>
                <option value="Adobe Firefly">Adobe Firefly</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] font-semibold text-gray-300 block mb-1">Bildformat</label>
              <select
                value={aspectRatio}
                onChange={(e) => setAspectRatio(e.target.value)}
                className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:border-purple-500 focus:outline-none min-h-[44px]"
              >
                <option value="16:9">16:9 (Landskap / Video)</option>
                <option value="9:16">9:16 (Vertikal / Story / Reel)</option>
                <option value="1:1">1:1 (Kvadrat)</option>
                <option value="4:5">4:5 (Instagram porträtt)</option>
                <option value="3:2">3:2 (Klassiskt 35mm)</option>
                <option value="21:9">21:9 (Cinemascope)</option>
              </select>
            </div>

            <div className="col-span-2 sm:col-span-1">
              <label className="text-[11px] font-semibold text-gray-300 block mb-1">Språk i Prompt</label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value as 'sv' | 'en')}
                className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:border-purple-500 focus:outline-none min-h-[44px]"
              >
                <option value="sv">Svenska (med engelska nyckelord)</option>
                <option value="en">English (Studio Standard)</option>
              </select>
            </div>
          </div>

          {/* Sticky Generate Button for Mobile & Desktop */}
          <div className="sticky bottom-16 sm:bottom-0 z-20 pt-2 pb-2">
            <button
              onClick={handleGenerate}
              disabled={isGenerating || !subject.trim()}
              className="flex w-full items-center justify-center gap-2.5 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-sky-600 p-4 text-sm sm:text-base font-extrabold text-white shadow-xl shadow-purple-950/50 hover:brightness-110 active:scale-[0.98] transition disabled:opacity-50 min-h-[52px]"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-5 h-5 animate-spin" />
                  <span>Genererar professionella prompter...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 text-sky-300" />
                  <span>Generera Prompter ({aiMode === 'gemini' ? 'Gemini AI' : 'Local Engine'})</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Output: Results & Quality Index */}
        <div className="lg:col-span-5 space-y-4">
          {results ? (
            <div className="space-y-4 animate-in fade-in duration-300">
              {/* Quality Score Card */}
              <QualityScoreCard result={results.quality} />

              {/* Result Format Tabs */}
              <div className="rounded-2xl border border-gray-800 bg-gray-900/80 p-4 space-y-3">
                <div className="flex flex-wrap items-center gap-1.5 border-b border-gray-800 pb-2.5">
                  {(['ultimate', 'professional', 'detailed', 'short', 'structured', 'alternatives'] as const).map(
                    (tab) => (
                      <button
                        key={tab}
                        onClick={() => setActiveTab(tab)}
                        className={`rounded-xl px-2.5 py-1 text-xs font-semibold capitalize transition min-h-[36px] ${
                          activeTab === tab
                            ? 'bg-purple-600 text-white'
                            : 'text-gray-400 hover:text-gray-200 hover:bg-gray-800'
                        }`}
                      >
                        {tab === 'ultimate' ? '★ Ultimate' : tab}
                      </button>
                    )
                  )}
                </div>

                {/* Display Current Prompt */}
                <div className="relative rounded-xl border border-gray-800 bg-gray-950 p-4">
                  <p className="text-xs sm:text-sm text-gray-100 font-mono leading-relaxed select-all whitespace-pre-wrap">
                    {activeTab === 'short' && results.shortPrompt}
                    {activeTab === 'detailed' && results.detailedPrompt}
                    {activeTab === 'professional' && results.professionalPrompt}
                    {activeTab === 'ultimate' && results.ultimatePrompt}
                    {activeTab === 'structured' && results.structuredPrompt}
                    {activeTab === 'alternatives' && (
                      <div className="space-y-3">
                        {results.alternatives.map((alt, idx) => (
                          <div key={idx} className="p-2.5 rounded-lg border border-gray-800 bg-gray-900/60">
                            <span className="text-[10px] text-purple-400 font-bold block mb-1">
                              Alternativ {idx + 1}:
                            </span>
                            <span className="text-xs text-gray-300">{alt}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </p>
                </div>

                {/* Negative Prompt Block */}
                {results.negativePrompt && (
                  <div className="rounded-xl border border-rose-500/20 bg-rose-950/20 p-3 space-y-1">
                    <span className="text-[10px] font-bold text-rose-400 uppercase tracking-wider block">
                      Negativ Prompt (Undvik i generatorn):
                    </span>
                    <p className="text-xs text-rose-200/90 font-mono select-all">
                      {results.negativePrompt}
                    </p>
                  </div>
                )}

                {/* Prompt Action Toolbar */}
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <button
                    onClick={() => {
                      const cur =
                        activeTab === 'short'
                          ? results.shortPrompt
                          : activeTab === 'detailed'
                          ? results.detailedPrompt
                          : activeTab === 'professional'
                          ? results.professionalPrompt
                          : results.ultimatePrompt;
                      handleCopy('main', cur);
                    }}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gray-800 px-3 py-2 text-xs font-semibold text-white hover:bg-gray-700 active:scale-95 transition min-h-[44px]"
                  >
                    {copiedKey === 'main' ? (
                      <>
                        <Check className="w-4 h-4 text-emerald-400" />
                        <span>Kopierad!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        <span>Kopiera</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={handleSave}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 px-3 py-2 text-xs font-semibold text-white hover:brightness-110 active:scale-95 transition min-h-[44px]"
                  >
                    {savedSuccess ? (
                      <>
                        <Check className="w-4 h-4 text-emerald-300" />
                        <span>Sparad i IndexedDB!</span>
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4" />
                        <span>Spara</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => setIsFavorite(!isFavorite)}
                    className={`rounded-xl p-2.5 border transition min-h-[44px] min-w-[44px] flex items-center justify-center ${
                      isFavorite
                        ? 'border-amber-500/40 bg-amber-500/10 text-amber-400'
                        : 'border-gray-800 bg-gray-800 text-gray-400 hover:text-white'
                    }`}
                    title="Märk som favorit"
                  >
                    <Bookmark className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-gray-800 bg-gray-900/30 p-8 text-center space-y-3 min-h-[350px]">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
                <Wand2 className="w-7 h-7" />
              </div>
              <h3 className="font-bold text-sm text-gray-200">Redo att bygga</h3>
              <p className="text-xs text-gray-400 max-w-xs">
                Fyll i ditt huvudmotiv till vänster och klicka på{' '}
                <strong>Generera Prompter</strong>. Du får 6 olika format och kvalitetspoäng direkt.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
