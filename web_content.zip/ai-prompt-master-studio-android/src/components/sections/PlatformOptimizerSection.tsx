import React, { useState } from 'react';
import { AIMode, PlatformProfile, PromptItem } from '../../types';
import { PLATFORM_PROFILES } from '../../data/platformProfiles';
import { geminiService } from '../../services/geminiService';
import {
  Share2,
  Sparkles,
  Copy,
  Check,
  Save,
  Info,
  CheckCircle2,
  ArrowRight,
  Layers,
} from 'lucide-react';

interface Props {
  aiMode: AIMode;
  onSavePrompt: (prompt: PromptItem) => void;
  onNavigate: (section: string) => void;
}

export const PlatformOptimizerSection: React.FC<Props> = ({ aiMode, onSavePrompt }) => {
  const [selectedPlatformId, setSelectedPlatformId] = useState('midjourney');
  const [inputPrompt, setInputPrompt] = useState(
    'En gammal urmakare i sin verkstad med mikroskop, kugghjul, mjukt fönsterljus, fotorealistisk'
  );
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [result, setResult] = useState<{
    optimizedPrompt: string;
    negativePrompt?: string;
    explanation?: string;
  } | null>(null);

  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  const currentProfile =
    PLATFORM_PROFILES.find((p) => p.id === selectedPlatformId) || PLATFORM_PROFILES[0];

  const handleOptimize = async () => {
    if (!inputPrompt.trim()) return;
    setIsOptimizing(true);

    try {
      if (aiMode === 'gemini') {
        const res = await geminiService.optimizePlatform(
          inputPrompt,
          currentProfile.name,
          currentProfile.type
        );
        setResult(res);
      } else {
        // Local platform optimizer
        let adapted = inputPrompt;
        let neg = currentProfile.exampleNegative || 'blurry, low quality, artifacts';

        if (currentProfile.id === 'midjourney') {
          adapted = `${inputPrompt.trim()}, 35mm photograph, Kodak Portra 400 tones, volumetric lighting --ar 16:9 --v 6.1 --stylize 250`;
        } else if (currentProfile.id === 'flux') {
          adapted = `A natural photographic description: ${inputPrompt.trim()}. Crisp depth of field, authentic micro-textures, cinematic natural lighting, shot on 50mm f/1.8 lens.`;
        } else if (currentProfile.id === 'veo') {
          adapted = `Cinematic continuous tracking shot: ${inputPrompt.trim()}. Camera glides smoothly forward at eye level, revealing layered environmental details with golden hour light, 60fps.`;
        } else if (currentProfile.id === 'runway') {
          adapted = `[Tracking Shot forward]: ${inputPrompt.trim()}, volumetric lighting, steady camera movement, cinematic film aesthetic.`;
        } else {
          adapted = `${inputPrompt.trim()}, award-winning ${currentProfile.name} masterpiece, 8k resolution, authentic lighting.`;
        }

        setResult({
          optimizedPrompt: adapted,
          negativePrompt: neg,
          explanation: `Formaterad specifikt för ${currentProfile.name} med hänsyn till modellens syntax, parametrar och kompositionsregler.`,
        });
      }
    } catch {
      // Local fallback
      setResult({
        optimizedPrompt: `${inputPrompt.trim()} --ar 16:9 --v 6.1`,
        negativePrompt: currentProfile.exampleNegative,
        explanation: 'Lokal formatering utförd.',
      });
    } finally {
      setIsOptimizing(false);
    }
  };

  const handleCopy = () => {
    if (!result) return;
    navigator.clipboard.writeText(result.optimizedPrompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSave = () => {
    if (!result) return;
    const item: PromptItem = {
      id: `opt-${Date.now()}`,
      title: `${currentProfile.name}: ${inputPrompt.slice(0, 30)}`,
      category: 'Platform Optimizer',
      type: currentProfile.type,
      prompt: result.optimizedPrompt,
      negativePrompt: result.negativePrompt,
      platform: currentProfile.name,
      tags: ['optimized', currentProfile.id, currentProfile.type],
      createdAt: Date.now(),
      updatedAt: Date.now(),
      modeUsed: aiMode,
    };
    onSavePrompt(item);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="border-b border-gray-800 pb-4">
        <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
          <Share2 className="w-5 h-5 text-sky-400" />
          AI Platform Optimizer
        </h1>
        <p className="text-xs text-gray-400 mt-1">
          Skräddarsy din prompt efter exakta syntaxregler och egenskaper för 11 ledande AI-modeller.
        </p>
      </div>

      {/* Platform Selector Grid */}
      <div className="space-y-2">
        <span className="text-xs font-bold uppercase tracking-wider text-gray-400">
          Välj Målplattform ({PLATFORM_PROFILES.length} motorer):
        </span>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
          {PLATFORM_PROFILES.map((prof) => (
            <button
              key={prof.id}
              onClick={() => {
                setSelectedPlatformId(prof.id);
                setResult(null);
              }}
              className={`flex flex-col items-start p-3 rounded-xl border text-left transition min-h-[58px] ${
                selectedPlatformId === prof.id
                  ? 'border-sky-500 bg-sky-950/40 text-white shadow-sm'
                  : 'border-gray-800 bg-gray-950 text-gray-400 hover:border-gray-700 hover:text-white'
              }`}
            >
              <div className="flex items-center justify-between w-full">
                <span className="font-bold text-xs truncate text-gray-100">{prof.name}</span>
                <span className="text-[9px] px-1 rounded bg-gray-800 text-gray-400 uppercase">
                  {prof.type}
                </span>
              </div>
              <span className="text-[10px] text-gray-400 truncate mt-0.5">{prof.badge}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Input & Selected Platform Profile Info */}
        <div className="lg:col-span-6 space-y-4">
          <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 space-y-2">
            <label className="text-xs font-bold text-gray-200 uppercase tracking-wider block">
              Din basprompt som ska optimeras:
            </label>
            <textarea
              value={inputPrompt}
              onChange={(e) => setInputPrompt(e.target.value)}
              placeholder="Skriv din prompt här..."
              rows={3}
              className="w-full rounded-xl border border-gray-800 bg-gray-950 p-3 text-xs sm:text-sm text-white placeholder-gray-500 focus:border-sky-500 focus:outline-none"
            />
          </div>

          {/* Profile Reference Card */}
          <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 space-y-3 text-xs">
            <div className="flex items-center justify-between border-b border-gray-800 pb-2">
              <span className="font-bold text-sm text-white flex items-center gap-1.5">
                <Info className="w-4 h-4 text-sky-400" />
                Regler för {currentProfile.name}
              </span>
              <span className="text-[10px] font-semibold text-purple-300 bg-purple-950/60 px-2 py-0.5 rounded-full border border-purple-500/30">
                {currentProfile.badge}
              </span>
            </div>

            <p className="text-gray-300 leading-relaxed">{currentProfile.description}</p>

            <div className="space-y-1 bg-gray-950/60 p-2.5 rounded-xl border border-gray-800">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
                Rekommenderad struktur:
              </span>
              <ul className="space-y-0.5 text-gray-300">
                {currentProfile.structure.map((s, i) => (
                  <li key={i}>{s}</li>
                ))}
              </ul>
            </div>

            <div className="text-[11px] text-gray-400">
              <strong>Syntaxnotis:</strong> {currentProfile.syntaxNotes}
            </div>

            {/* Platform Tips */}
            <div className="space-y-1">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
                Plattformstips:
              </span>
              <ul className="list-disc list-inside space-y-0.5 text-gray-300">
                {currentProfile.tips.map((tip, i) => (
                  <li key={i}>{tip}</li>
                ))}
              </ul>
            </div>
          </div>

          <button
            onClick={handleOptimize}
            disabled={isOptimizing || !inputPrompt.trim()}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-sky-600 to-indigo-600 p-4 text-sm font-extrabold text-white shadow-xl hover:brightness-110 active:scale-95 transition disabled:opacity-50 min-h-[52px]"
          >
            <Sparkles className="w-5 h-5 text-sky-300" />
            <span>Optimera för {currentProfile.name} ({aiMode === 'gemini' ? 'Gemini AI' : 'Local Mode'})</span>
          </button>
        </div>

        {/* Right: Optimized Result */}
        <div className="lg:col-span-6 space-y-4">
          {result ? (
            <div className="rounded-2xl border border-gray-800 bg-gray-900/80 p-5 space-y-4 animate-in fade-in duration-300">
              <div className="flex items-center justify-between border-b border-gray-800 pb-3">
                <span className="text-xs font-bold text-sky-400 uppercase tracking-wider flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Optimerad för {currentProfile.name}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-sky-500/20 text-sky-300 font-semibold">
                  Klar för användning
                </span>
              </div>

              {/* Prompt Box */}
              <div className="rounded-xl border border-gray-800 bg-gray-950 p-4 space-y-1">
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
                  Kopiera denna prompt:
                </span>
                <p className="text-xs sm:text-sm text-gray-100 font-mono leading-relaxed select-all">
                  {result.optimizedPrompt}
                </p>
              </div>

              {/* Negative prompt */}
              {result.negativePrompt && (
                <div className="rounded-xl border border-rose-500/20 bg-rose-950/20 p-3 space-y-1">
                  <span className="text-[10px] font-bold text-rose-400 uppercase tracking-wider block">
                    Negativ Prompt:
                  </span>
                  <p className="text-xs text-rose-200 font-mono select-all">
                    {result.negativePrompt}
                  </p>
                </div>
              )}

              {result.explanation && (
                <p className="text-xs text-gray-400 italic bg-gray-950/40 p-3 rounded-xl border border-gray-800">
                  💡 {result.explanation}
                </p>
              )}

              <div className="flex items-center gap-2 pt-2">
                <button
                  onClick={handleCopy}
                  className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gray-800 px-4 py-2.5 text-xs font-semibold text-white hover:bg-gray-700 active:scale-95 transition min-h-[44px]"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  <span>{copied ? 'Kopierad!' : 'Kopiera Optimerad'}</span>
                </button>

                <button
                  onClick={handleSave}
                  className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 px-4 py-2.5 text-xs font-semibold text-white hover:brightness-110 active:scale-95 transition min-h-[44px]"
                >
                  {saved ? <Check className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
                  <span>{saved ? 'Sparad!' : 'Spara Prompt'}</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-gray-800 bg-gray-900/30 p-8 text-center space-y-3 min-h-[350px]">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-sky-500/10 text-sky-400">
                <Share2 className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-sm text-gray-200">Plattformsanpassning</h3>
              <p className="text-xs text-gray-400 max-w-xs">
                Klicka på <strong>Optimera</strong> för att anpassa prompten efter {currentProfile.name}s unika parametrar och syntax.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
