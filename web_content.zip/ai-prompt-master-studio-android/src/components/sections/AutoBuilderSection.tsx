import React, { useState } from 'react';
import { AIMode, PromptItem } from '../../types';
import { localPromptEngine } from '../../services/localEngine';
import { geminiService } from '../../services/geminiService';
import {
  Sparkles,
  Check,
  X,
  Edit2,
  Copy,
  Save,
  RefreshCw,
  Wand2,
  SlidersHorizontal,
} from 'lucide-react';

interface Props {
  aiMode: AIMode;
  onSavePrompt: (prompt: PromptItem) => void;
  onNavigate: (section: string) => void;
}

interface DimensionItem {
  key: string;
  label: string;
  value: string;
  accepted: boolean;
  isEditing: boolean;
}

export const AutoBuilderSection: React.FC<Props> = ({ aiMode, onSavePrompt }) => {
  const [idea, setIdea] = useState('En man går genom Malmö i regnet');
  const [isExpanding, setIsExpanding] = useState(false);
  const [dimensions, setDimensions] = useState<DimensionItem[]>([]);
  const [negativePrompt, setNegativePrompt] = useState('');
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleExpand = async () => {
    if (!idea.trim()) return;
    setIsExpanding(true);

    try {
      let data: any;
      if (aiMode === 'gemini') {
        data = await geminiService.autoBuild(idea, 'sv');
      } else {
        data = localPromptEngine.autoBuildIdea(idea, 'sv');
      }

      const items: DimensionItem[] = [
        { key: 'subject', label: 'Motiv & Utseende', value: data.subject || '', accepted: true, isEditing: false },
        { key: 'action', label: 'Handling & Pose', value: data.action || '', accepted: true, isEditing: false },
        { key: 'environment', label: 'Gatumiljö & Plats', value: data.environment || '', accepted: true, isEditing: false },
        { key: 'timeAndWeather', label: 'Tid & Regnintensitet', value: data.timeAndWeather || '', accepted: true, isEditing: false },
        { key: 'lighting', label: 'Belysning & Reflexer', value: data.lighting || '', accepted: true, isEditing: false },
        { key: 'cameraAndLens', label: 'Kameravinkel & Objektiv', value: data.cameraAndLens || '', accepted: true, isEditing: false },
        { key: 'visualStyle', label: 'Filmstil & Estetik', value: data.visualStyle || '', accepted: true, isEditing: false },
        { key: 'colorGrading', label: 'Färgpalett & LUT', value: data.colorGrading || '', accepted: true, isEditing: false },
        { key: 'materialsAndDetails', label: 'Kläder & Vattendroppar', value: data.materialsAndDetails || '', accepted: true, isEditing: false },
        { key: 'technicalQuality', label: 'Teknisk Kvalitet', value: data.technicalQuality || '8k raw photo, photorealistic', accepted: true, isEditing: false },
      ].filter((item) => Boolean(item.value));

      setDimensions(items);
      setNegativePrompt(data.negativePrompt || 'blurry, low quality, oversaturated, deformed anatomy');
    } catch {
      const data = localPromptEngine.autoBuildIdea(idea, 'sv');
      const items: DimensionItem[] = [
        { key: 'subject', label: 'Motiv & Utseende', value: data.subject, accepted: true, isEditing: false },
        { key: 'action', label: 'Handling & Pose', value: data.action, accepted: true, isEditing: false },
        { key: 'environment', label: 'Gatumiljö & Plats', value: data.environment, accepted: true, isEditing: false },
        { key: 'timeAndWeather', label: 'Tid & Regnintensitet', value: data.timeAndWeather, accepted: true, isEditing: false },
        { key: 'lighting', label: 'Belysning & Reflexer', value: data.lighting, accepted: true, isEditing: false },
        { key: 'cameraAndLens', label: 'Kameravinkel & Objektiv', value: data.cameraAndLens, accepted: true, isEditing: false },
        { key: 'visualStyle', label: 'Filmstil & Estetik', value: data.visualStyle, accepted: true, isEditing: false },
        { key: 'colorGrading', label: 'Färgpalett & LUT', value: data.colorGrading, accepted: true, isEditing: false },
        { key: 'materialsAndDetails', label: 'Kläder & Vattendroppar', value: data.materialsAndDetails, accepted: true, isEditing: false },
        { key: 'technicalQuality', label: 'Teknisk Kvalitet', value: data.technicalQuality, accepted: true, isEditing: false },
      ];
      setDimensions(items);
      setNegativePrompt(data.negativePrompt);
    } finally {
      setIsExpanding(false);
    }
  };

  const toggleAccept = (index: number) => {
    setDimensions((prev) =>
      prev.map((item, i) => (i === index ? { ...item, accepted: !item.accepted } : item))
    );
  };

  const updateValue = (index: number, val: string) => {
    setDimensions((prev) =>
      prev.map((item, i) => (i === index ? { ...item, value: val } : item))
    );
  };

  const toggleEdit = (index: number) => {
    setDimensions((prev) =>
      prev.map((item, i) => (i === index ? { ...item, isEditing: !item.isEditing } : item))
    );
  };

  const composedPrompt = dimensions
    .filter((d) => d.accepted && d.value.trim())
    .map((d) => d.value.trim())
    .join(', ');

  const handleCopy = () => {
    navigator.clipboard.writeText(composedPrompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSave = () => {
    if (!composedPrompt) return;
    const item: PromptItem = {
      id: `autobuild-${Date.now()}`,
      title: idea.slice(0, 35) || 'Auto-byggd Prompt',
      category: 'Auto-Builder',
      type: 'image',
      prompt: composedPrompt,
      negativePrompt,
      tags: ['auto-builder', 'expanded', aiMode],
      createdAt: Date.now(),
      updatedAt: Date.now(),
      modeUsed: aiMode,
    };
    onSavePrompt(item);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="border-b border-gray-800 pb-4">
        <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-400" />
          Prompt Auto-Builder
        </h1>
        <p className="text-xs text-gray-400 mt-1">
          Skriv en kort idé. AI eller lokal regelmotor vecklar ut den i alla kreativa och tekniska detaljer som du kan acceptera, avvisa eller redigera.
        </p>
      </div>

      {/* Input Idea Box */}
      <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 sm:p-5 space-y-3">
        <label className="text-xs font-bold text-gray-200 uppercase tracking-wider block">
          Skriv din korta idé:
        </label>
        <div className="flex flex-col sm:flex-row gap-2.5">
          <input
            type="text"
            value={idea}
            onChange={(e) => setIdea(e.target.value)}
            placeholder="Ex: En man går genom Malmö i regnet..."
            className="flex-1 rounded-xl border border-gray-800 bg-gray-950 px-4 py-3 text-sm text-white placeholder-gray-500 focus:border-purple-500 focus:outline-none min-h-[48px]"
          />
          <button
            onClick={handleExpand}
            disabled={isExpanding || !idea.trim()}
            className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-purple-600 to-sky-600 px-6 py-3 text-xs sm:text-sm font-bold text-white shadow-lg hover:brightness-110 active:scale-95 transition disabled:opacity-50 min-h-[48px]"
          >
            {isExpanding ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Utvecklar idé...</span>
              </>
            ) : (
              <>
                <Wand2 className="w-4 h-4" />
                <span>Utveckla Idén</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Extracted Dimension Cards */}
      {dimensions.length > 0 && (
        <div className="space-y-4 animate-in fade-in duration-300">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-300">
              Genererade Förslag ({dimensions.filter((d) => d.accepted).length}/{dimensions.length} aktiva)
            </h3>
            <span className="text-[11px] text-gray-400">
              Klicka på bocken eller krysset för att inkludera eller utesluta detaljer
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {dimensions.map((dim, idx) => (
              <div
                key={dim.key}
                className={`rounded-2xl border p-3.5 transition ${
                  dim.accepted
                    ? 'border-gray-800 bg-gray-900/80 shadow-sm'
                    : 'border-gray-800/40 bg-gray-950/40 opacity-60'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-sky-400">{dim.label}</span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => toggleEdit(idx)}
                      className="p-1 text-gray-400 hover:text-white rounded hover:bg-gray-800 transition"
                      title="Redigera text"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => toggleAccept(idx)}
                      className={`p-1.5 rounded-lg transition min-h-[36px] min-w-[36px] flex items-center justify-center ${
                        dim.accepted
                          ? 'bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30'
                          : 'bg-rose-500/20 text-rose-400 hover:bg-rose-500/30'
                      }`}
                      title={dim.accepted ? 'Inkluderad (klicka för att utesluta)' : 'Utesluten'}
                    >
                      {dim.accepted ? <Check className="w-4 h-4" /> : <X className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {dim.isEditing ? (
                  <textarea
                    value={dim.value}
                    onChange={(e) => updateValue(idx, e.target.value)}
                    rows={2}
                    className="w-full rounded-lg border border-gray-700 bg-gray-950 p-2 text-xs text-white focus:outline-none focus:border-purple-500"
                  />
                ) : (
                  <p className="text-xs text-gray-200 font-mono leading-relaxed">{dim.value}</p>
                )}
              </div>
            ))}
          </div>

          {/* Synthesized Live Preview */}
          <div className="rounded-2xl border border-purple-500/30 bg-purple-950/20 p-5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                Sammansatt Master Prompt
              </span>
              <span className="text-[11px] text-gray-400 font-mono">
                {composedPrompt.split(/\s+/).filter(Boolean).length} ord
              </span>
            </div>

            <div className="rounded-xl border border-gray-800 bg-gray-950 p-4">
              <p className="text-xs sm:text-sm text-gray-100 font-mono leading-relaxed select-all">
                {composedPrompt || 'Inga detaljer valda.'}
              </p>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={handleCopy}
                className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gray-800 px-4 py-2.5 text-xs font-semibold text-white hover:bg-gray-700 active:scale-95 transition min-h-[44px]"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? 'Kopierad!' : 'Kopiera prompt'}</span>
              </button>

              <button
                onClick={handleSave}
                className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-sky-600 px-4 py-2.5 text-xs font-semibold text-white hover:brightness-110 active:scale-95 transition min-h-[44px]"
              >
                {saved ? <Check className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
                <span>{saved ? 'Sparad i Projekt!' : 'Spara Prompt'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
