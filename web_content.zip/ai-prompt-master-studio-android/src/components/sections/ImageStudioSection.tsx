import React, { useState } from 'react';
import { AIMode, PromptItem } from '../../types';
import { localPromptEngine, NEGATIVE_IMAGE_DEFAULTS } from '../../services/localEngine';
import { geminiService } from '../../services/geminiService';
import { evaluatePromptQuality } from '../../services/qualityScorer';
import { QualityScoreCard } from '../common/QualityScoreCard';
import {
  Camera,
  Sun,
  Layers,
  Sparkles,
  Copy,
  Check,
  Save,
  Bookmark,
  RefreshCw,
  Palette,
  Eye,
} from 'lucide-react';

interface Props {
  aiMode: AIMode;
  onSavePrompt: (prompt: PromptItem) => void;
  onNavigate: (section: string) => void;
}

const CATEGORIES = [
  'Photorealism', 'Cinematic Photography', 'Portrait', 'Fashion', 'Architecture',
  'Nature', 'Landscape', 'Wildlife', 'Automotive', 'Product Photography',
  'Fantasy', 'Science Fiction', 'Cyberpunk', 'Horror', 'Anime', '3D Render',
  'Digital Art', 'Historical', 'Viking', 'Medieval', 'Space', 'Underwater',
  'Disaster', 'Apocalypse', 'Luxury', 'Macro', 'Surrealism'
];

const CAMERAS = [
  { id: '14mm', name: '14mm Ultra-Wide', desc: 'Dramatisk vidvinkel, arkitektur & vidsträckta landskap' },
  { id: '24mm', name: '24mm Wide Angle', desc: 'Klassisk dokumentär & dynamiska miljöporträtt' },
  { id: '35mm', name: '35mm Film Prime', desc: 'Filmisk gatu- & berätterestetik, naturligt synfält' },
  { id: '50mm', name: '50mm Standard f/1.4', desc: 'Ögonhöjd, perfekt naturtrogna proportioner' },
  { id: '85mm', name: '85mm Portrait f/1.2', desc: 'Mjuk bakgrundsbokeh & smickrande porträttkompression' },
  { id: '100mm', name: '100mm Macro IS', desc: 'Mikroskopiska detaljer, kristaller & texturer' },
];

const LIGHTING = [
  'Golden Hour', 'Blue Hour', 'Studio Lighting', 'Volumetric Lighting',
  'Cinematic Lighting', 'Neon Lighting', 'Rim Lighting', 'Backlighting', 'Natural Lighting'
];

const RATIOS = ['1:1', '4:5', '3:2', '16:9', '9:16', '21:9'];

export const ImageStudioSection: React.FC<Props> = ({ aiMode, onSavePrompt }) => {
  const [selectedCategory, setSelectedCategory] = useState('Photorealism');
  const [subject, setSubject] = useState('');
  const [selectedCamera, setSelectedCamera] = useState('85mm');
  const [selectedLighting, setSelectedLighting] = useState('Golden Hour');
  const [selectedRatio, setSelectedRatio] = useState('16:9');
  const [customStyle, setCustomStyle] = useState('Kodak Portra 400, authentic skin pores, 8k');

  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState<{
    prompt: string;
    negative: string;
    quality: any;
  } | null>(null);

  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);

  const handleGenerate = async () => {
    if (!subject.trim()) return;
    setIsGenerating(true);

    const cameraObj = CAMERAS.find((c) => c.id === selectedCamera);
    const cameraText = cameraObj ? cameraObj.name : selectedCamera;

    try {
      if (aiMode === 'gemini') {
        const query = `
Category: ${selectedCategory}
Subject: ${subject}
Camera/Lens: ${cameraText}
Lighting: ${selectedLighting}
Aspect Ratio: ${selectedRatio}
Extra nuances: ${customStyle}
Create a master image synthesis prompt for FLUX/Midjourney. Include a negative prompt.
`;
        const res = await geminiService.autoBuild(query, 'sv');
        const quality = evaluatePromptQuality(res.ultimatePrompt || res.professionalPrompt, 'image', res.negativePrompt);
        quality.evaluationType = 'gemini';

        setResult({
          prompt: res.ultimatePrompt || res.professionalPrompt || '',
          negative: res.negativePrompt || NEGATIVE_IMAGE_DEFAULTS.slice(0, 10).join(', '),
          quality,
        });
      } else {
        // Local engine
        const gen = localPromptEngine.generatePrompts({
          type: 'image',
          subject,
          visualStyle: `${selectedCategory} visual aesthetic`,
          camera: cameraText,
          lighting: `${selectedLighting.toLowerCase()} lighting`,
          aspectRatio: selectedRatio,
          materials: customStyle,
        });

        setResult({
          prompt: gen.ultimatePrompt,
          negative: gen.negativePrompt,
          quality: gen.quality,
        });
      }
    } catch {
      // Local fallback
      const gen = localPromptEngine.generatePrompts({
        type: 'image',
        subject,
        visualStyle: `${selectedCategory} visual aesthetic`,
        camera: cameraText,
        lighting: `${selectedLighting.toLowerCase()} lighting`,
        aspectRatio: selectedRatio,
        materials: customStyle,
      });

      setResult({
        prompt: gen.ultimatePrompt,
        negative: gen.negativePrompt,
        quality: gen.quality,
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSave = () => {
    if (!result) return;
    const item: PromptItem = {
      id: `img-studio-${Date.now()}`,
      title: `${selectedCategory}: ${subject.slice(0, 35)}`,
      category: selectedCategory,
      type: 'image',
      prompt: result.prompt,
      negativePrompt: result.negative,
      aspectRatio: selectedRatio,
      tags: [selectedCategory.toLowerCase(), selectedCamera, selectedLighting.toLowerCase(), 'image-studio'],
      qualityScore: result.quality.totalScore,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      isFavorite,
      modeUsed: aiMode,
    };
    onSavePrompt(item);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="border-b border-gray-800 pb-4">
        <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
          <Camera className="w-5 h-5 text-purple-400" />
          Image Prompt Studio
        </h1>
        <p className="text-xs text-gray-400 mt-1">
          Specialanpassad för professionell fotografering, optiska linser, ljussättning och konstnärliga genrer.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Controls */}
        <div className="lg:col-span-7 space-y-4">
          {/* Categories Horizontal Scroll / Pills */}
          <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 space-y-2">
            <label className="text-xs font-bold text-gray-300 uppercase tracking-wider block">
              1. Genre & Kategori ({CATEGORIES.length} st)
            </label>
            <div className="flex flex-wrap gap-1.5 max-h-40 overflow-y-auto pr-1">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`rounded-xl px-2.5 py-1.5 text-xs font-medium transition min-h-[38px] ${
                    selectedCategory === cat
                      ? 'bg-purple-600 text-white font-semibold shadow-sm'
                      : 'border border-gray-800 bg-gray-950 text-gray-400 hover:text-white hover:bg-gray-800'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Subject description */}
          <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 space-y-2">
            <label className="text-xs font-bold text-gray-200 uppercase tracking-wider block">
              2. Motiv & Idé
            </label>
            <textarea
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Ex: En elegant kvinna i skräddarsydd svart ullkappa stående under regnvåta neonlampor i Stockholm..."
              rows={3}
              className="w-full rounded-xl border border-gray-800 bg-gray-950 p-3 text-xs sm:text-sm text-white placeholder-gray-500 focus:border-purple-500 focus:outline-none"
            />
          </div>

          {/* Camera Selection */}
          <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 space-y-2.5">
            <label className="text-xs font-bold text-gray-200 uppercase tracking-wider flex items-center gap-1.5">
              <Camera className="w-3.5 h-3.5 text-sky-400" />
              <span>3. Kameraval & Brännvidd</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {CAMERAS.map((cam) => (
                <div
                  key={cam.id}
                  onClick={() => setSelectedCamera(cam.id)}
                  className={`cursor-pointer rounded-xl border p-2.5 transition min-h-[44px] ${
                    selectedCamera === cam.id
                      ? 'border-purple-500 bg-purple-950/30'
                      : 'border-gray-800 bg-gray-950/80 hover:border-gray-700'
                  }`}
                >
                  <div className="font-semibold text-xs text-white">{cam.name}</div>
                  <div className="text-[10px] text-gray-400 line-clamp-1">{cam.desc}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Lighting Selection */}
          <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 space-y-2.5">
            <label className="text-xs font-bold text-gray-200 uppercase tracking-wider flex items-center gap-1.5">
              <Sun className="w-3.5 h-3.5 text-amber-400" />
              <span>4. Ljussättning</span>
            </label>
            <div className="flex flex-wrap gap-1.5">
              {LIGHTING.map((light) => (
                <button
                  key={light}
                  onClick={() => setSelectedLighting(light)}
                  className={`rounded-xl px-3 py-1.5 text-xs font-medium transition min-h-[40px] ${
                    selectedLighting === light
                      ? 'bg-amber-600 text-white font-semibold'
                      : 'border border-gray-800 bg-gray-950 text-gray-400 hover:text-white hover:bg-gray-800'
                  }`}
                >
                  {light}
                </button>
              ))}
            </div>
          </div>

          {/* Aspect Ratios & Extra style */}
          <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-gray-300 block mb-1.5">Bildformat</label>
              <div className="flex flex-wrap gap-1.5">
                {RATIOS.map((r) => (
                  <button
                    key={r}
                    onClick={() => setSelectedRatio(r)}
                    className={`rounded-xl px-2.5 py-1 text-xs font-semibold transition min-h-[36px] ${
                      selectedRatio === r
                        ? 'bg-sky-600 text-white'
                        : 'border border-gray-800 bg-gray-950 text-gray-400 hover:text-white'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-gray-300 block mb-1.5">Extra detaljer & Filmton</label>
              <input
                type="text"
                value={customStyle}
                onChange={(e) => setCustomStyle(e.target.value)}
                placeholder="Ex: Kodak Portra 400, mikrotexturer"
                className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:border-purple-500 focus:outline-none min-h-[44px]"
              />
            </div>
          </div>

          {/* Generate Button */}
          <button
            onClick={handleGenerate}
            disabled={isGenerating || !subject.trim()}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-purple-600 to-sky-600 p-4 text-sm font-extrabold text-white shadow-xl shadow-purple-950/50 hover:brightness-110 active:scale-[0.98] transition disabled:opacity-50 min-h-[52px]"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="w-5 h-5 animate-spin" />
                <span>Skapar bildprompt...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 text-sky-300" />
                <span>Generera Bildprompt ({aiMode === 'gemini' ? 'Gemini AI' : 'Local Mode'})</span>
              </>
            )}
          </button>
        </div>

        {/* Output */}
        <div className="lg:col-span-5 space-y-4">
          {result ? (
            <div className="space-y-4 animate-in fade-in duration-300">
              <QualityScoreCard result={result.quality} />

              <div className="rounded-2xl border border-gray-800 bg-gray-900/80 p-4 space-y-3">
                <div className="flex items-center justify-between border-b border-gray-800 pb-2">
                  <span className="text-xs font-bold text-sky-400 uppercase tracking-wider">
                    Färdig Bildprompt ({selectedCategory})
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-gray-800 text-gray-300">
                    --ar {selectedRatio}
                  </span>
                </div>

                <div className="rounded-xl border border-gray-800 bg-gray-950 p-3.5">
                  <p className="text-xs sm:text-sm text-gray-100 font-mono leading-relaxed select-all">
                    {result.prompt}
                  </p>
                </div>

                <div className="rounded-xl border border-rose-500/20 bg-rose-950/20 p-3 space-y-1">
                  <span className="text-[10px] font-bold text-rose-400 uppercase tracking-wider block">
                    Negativ Bildprompt:
                  </span>
                  <p className="text-xs text-rose-200/90 font-mono select-all">
                    {result.negative}
                  </p>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={() => handleCopy(result.prompt)}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gray-800 px-3 py-2 text-xs font-semibold text-white hover:bg-gray-700 active:scale-95 transition min-h-[44px]"
                  >
                    {copied ? (
                      <>
                        <Check className="w-4 h-4 text-emerald-400" />
                        <span>Kopierad!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        <span>Kopiera</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={handleSave}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 px-3 py-2 text-xs font-semibold text-white hover:brightness-110 active:scale-95 transition min-h-[44px]"
                  >
                    {saved ? (
                      <>
                        <Check className="w-4 h-4 text-emerald-300" />
                        <span>Sparad!</span>
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4" />
                        <span>Spara</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => setIsFavorite(!isFavorite)}
                    className={`rounded-xl p-2.5 border transition min-h-[44px] min-w-[44px] flex items-center justify-center ${
                      isFavorite
                        ? 'border-amber-500/40 bg-amber-500/10 text-amber-400'
                        : 'border-gray-800 bg-gray-800 text-gray-400 hover:text-white'
                    }`}
                  >
                    <Bookmark className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-gray-800 bg-gray-900/30 p-8 text-center space-y-3 min-h-[300px]">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-purple-500/10 text-purple-400">
                <Camera className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-sm text-gray-200">Välj kamerainställningar</h3>
              <p className="text-xs text-gray-400 max-w-xs">
                Kombinera genre, objektiv och ljussättning för att skapa studio-optimerade bildprompter.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
