import React, { useState } from 'react';
import {
  HelpCircle,
  BookOpen,
  Cpu,
  Sparkles,
  Camera,
  Film,
  Sliders,
  ShieldBan,
  Layers,
  Share2,
  HardDrive,
  Wifi,
  WifiOff,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

interface FaqItem {
  id: string;
  title: string;
  icon: any;
  content: string;
}

const FAQS: FaqItem[] = [
  {
    id: 'local-vs-gemini',
    title: 'Vad är skillnaden mellan Local Mode och Gemini AI Mode?',
    icon: Cpu,
    content:
      'Mode A (Free Local Mode) körs 100% lokalt i din webbläsare med en avancerad regelbaserad analysmotor, synonymlexikon, konfliktigenkänning och kvalitetsberäkning. Det kräver ingen internetanslutning eller API-nyckel och kostar ingenting. Mode B (Gemini AI Mode) anropar Google Gemini 3.8 Flash via vår säkra backend för djup multimodal förståelse, adaptiva regissörsintervjuer och intelligent scenexpansion.',
  },
  {
    id: 'image-prompts',
    title: 'Hur skapar jag fotorealistiska bildprompter?',
    icon: Camera,
    content:
      'En professionell bildprompt bygger på 11 dimensioner: Motiv, handling, miljö, tid/väder, visuell stil, objektiv (t.ex. 85mm f/1.4 eller 14mm ultravidvinkel), belysning (t.ex. volumetric god rays eller chiaroscuro), komposition (Fibonacci, ledlinjer) och färggradering (t.ex. Kodak Portra 400). Undvik vaga adjektiv som "super vacker" och använd istället konkreta optiska och fysikaliska termer.',
  },
  {
    id: 'video-prompts',
    title: 'Hur konstrueras filmiska videoprompter?',
    icon: Film,
    content:
      'Videomodeller (Veo, Runway Gen-3, Sora, Kling) kräver explicita kamerarörelser (Tracking shot, Dolly in, Crane up, FPV), tidslinjeangivelser (hur handlingen utvecklas från 0s till 10s) och fysiska rörelsevektorer med realistisk gravitation. Vår Video Studio lägger automatiskt till dessa kontinuitetsankare.',
  },
  {
    id: 'enhancer',
    title: 'Hur fungerar Prompt Enhancer Pro?',
    icon: Sliders,
    content:
      'Enhancer Pro tar en befintlig eller enkel prompt och omstrukturerar den genom 14 specialiserade filter. Du kan välja "More Cinematic", "Better Lighting", "Expand", "Shorten" eller helhetsoptimering. Verktyget visar alltid en tydlig lista över genomförda ändringar och den bakomliggande motiveringen.',
  },
  {
    id: 'negative-prompts',
    title: 'Vad gör Negative Prompts och varför behövs de?',
    icon: ShieldBan,
    content:
      'En negativ prompt instruerar bild- och videogeneratorn vad den ska utesluta. För bilder minskar den risken för deformerade händer, extra fingrar, suddighet och vattenstämplar. För video eliminerar den flimrande ljus, kameraryck, morphing och temporära artefakter.',
  },
  {
    id: 'storyboard',
    title: 'Hur fungerar Storyboard Creator och scensekvenser?',
    icon: Layers,
    content:
      'Storyboard Creator låter dig generera mellan 5 och 20 sammanhängande scener utifrån en filmidé. Varje scen har en startbild, slutbild, kamerarigg, tidslinje och kontinuitetsanteckningar. Du kan flytta upp/ned scener, duplicera och exportera hela filmplanen som strukturerad JSON.',
  },
  {
    id: 'continuity',
    title: 'Hur upprätthålls karaktärs- och miljökontinuitet?',
    icon: Layers,
    content:
      'I Continuous Video Creator definieras en "Låst Karaktärsprofil" (klädsel, ärr, frisyr, signaturaccessoarer) samt miljö- och färg-LUT-regler. När du skapar nya scener injiceras dessa låsta tokens i nästa prompt så att modellen inte byter kläder, hårfärg eller ljus mellan klipp.',
  },
  {
    id: 'offline-online',
    title: 'Vad fungerar offline och vad kräver internet?',
    icon: WifiOff,
    content:
      'OFFLINE (100% i webbläsaren): Hela Local Prompt Engine, Prompt Builder, Image Studio, Video Studio, regelbaserad intervju, 100+ prompt-biblioteket, lokal bildtelemetri med Canvas (histogram/kontrast/färger), favoriter, historik, projekt och import/export. INTERNET KRÄVS: Gemini AI Mode, Gemini multimodal bildanalys och Gemini-drivna intervjuer.',
  },
  {
    id: 'storage',
    title: 'Hur fungerar lokal lagring (IndexedDB)?',
    icon: HardDrive,
    content:
      'All din data sparas i webbläsarens inbyggda IndexedDB-databas. Detta innebär att dina projekt, historik och favoriter ligger tryggt på din enhet utan att skickas till någon tredjepartsserver. Du kan när som helst ta en fullständig säkerhetskopia som JSON via Storage Manager.',
  },
  {
    id: 'api-costs',
    title: 'Hur fungerar Gemini-användning och API-kostnader?',
    icon: Sparkles,
    content:
      'När du använder Gemini AI Mode anropas modellen gemini-3.8-flash via backend. I AI Studio tillhandahålls detta via det bifogade projektets API-nyckel i panelen Settings > Secrets. Appen exponerar aldrig några nycklar till webbläsaren.',
  },
  {
    id: 'custom-api-key',
    title: 'Hur lägger jag till min egen Gemini API-nyckel?',
    icon: Sparkles,
    content:
      'Gå till Studio Inställningar i menyn. Under sektionen "Egen Gemini API-nyckel (Custom Gemini API Key)" kan du klistra in din personliga API-nyckel (från t.ex. Google AI Studio på aistudio.google.com/app/apikey). Klicka på "Spara nyckel" och verifiera med knappen "Testa anslutning". Nyckeln sparas säkert krypterad i webbläsaren och skickas enbart via skyddad HTTPS-header till backend-proxyn. Du kan när som helst ta bort nyckeln med knappen "Ta bort egen nyckel".',
  },
];

export const HelpCenterSection: React.FC = () => {
  const [openIds, setOpenIds] = useState<string[]>(['local-vs-gemini', 'image-prompts']);

  const toggleFaq = (id: string) => {
    if (openIds.includes(id)) {
      setOpenIds(openIds.filter((item) => item !== id));
    } else {
      setOpenIds([...openIds, id]);
    }
  };

  return (
    <div className="space-y-6 pb-24 max-w-4xl">
      {/* Header */}
      <div className="border-b border-gray-800 pb-4">
        <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
          <HelpCircle className="w-5 h-5 text-sky-400" />
          Studio Hjälpcenter & Kunskapsbas
        </h1>
        <p className="text-xs text-gray-400 mt-1">
          Komplett guide till promptteknik, skillnaden mellan offline- och AI-läge samt plattformsoptimering.
        </p>
      </div>

      {/* Quick Status Pill Info */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="rounded-2xl border border-emerald-500/30 bg-emerald-950/20 p-4 space-y-1.5 text-xs">
          <div className="flex items-center gap-2 font-bold text-emerald-400">
            <WifiOff className="w-4 h-4" />
            <span>Vad fungerar offline (Local Mode)?</span>
          </div>
          <p className="text-gray-300 leading-relaxed">
            Prompt Builder, regelmotorn, biblioteket med 100+ prompter, lokal bildanalys (Canvas), sparande i IndexedDB och export fungerar utan nätverksanslutning.
          </p>
        </div>

        <div className="rounded-2xl border border-purple-500/30 bg-purple-950/20 p-4 space-y-1.5 text-xs">
          <div className="flex items-center gap-2 font-bold text-purple-300">
            <Wifi className="w-4 h-4 text-sky-400" />
            <span>Vad kräver internet (Gemini Mode)?</span>
          </div>
          <p className="text-gray-300 leading-relaxed">
            Neural textgenerering via Gemini 3.8 Flash, multimodal bildförståelse (omvänd promptning) och dynamisk AI-intervju.
          </p>
        </div>
      </div>

      {/* FAQ Accordion List */}
      <div className="space-y-3">
        <span className="text-xs font-bold text-gray-200 uppercase tracking-wider block">
          Vanliga frågor & användarguider
        </span>

        {FAQS.map((faq) => {
          const isOpen = openIds.includes(faq.id);
          const Icon = faq.icon;
          return (
            <div
              key={faq.id}
              className="rounded-2xl border border-gray-800 bg-gray-900/60 overflow-hidden transition"
            >
              <button
                onClick={() => toggleFaq(faq.id)}
                className="flex w-full items-center justify-between p-4 text-left hover:bg-gray-800/40 transition min-h-[48px]"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-purple-500/10 text-purple-400 shrink-0">
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className="font-bold text-xs sm:text-sm text-gray-100">{faq.title}</span>
                </div>
                {isOpen ? (
                  <ChevronUp className="w-4 h-4 text-gray-400 shrink-0 ml-2" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-gray-400 shrink-0 ml-2" />
                )}
              </button>

              {isOpen && (
                <div className="px-4 pb-4 pt-1 text-xs text-gray-300 leading-relaxed border-t border-gray-800/60">
                  {faq.content}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
