import React, { useState } from 'react';
import { AIMode, PromptItem } from '../../types';
import { localPromptEngine } from '../../services/localEngine';
import { geminiService } from '../../services/geminiService';
import { evaluatePromptQuality } from '../../services/qualityScorer';
import { QualityScoreCard } from '../common/QualityScoreCard';
import {
  Sliders,
  Sparkles,
  Copy,
  Check,
  Save,
  ArrowRight,
  RefreshCw,
  Diff,
  CheckCircle2,
} from 'lucide-react';

interface Props {
  aiMode: AIMode;
  onSavePrompt: (prompt: PromptItem) => void;
  onNavigate: (section: string) => void;
}

const MODES = [
  { id: 'ultimate', label: 'Ultimate Rewrite', desc: 'Total överhalning med optimal estetisk och optisk täthet' },
  { id: 'realistic', label: 'More Realistic', desc: '8k raw photo, autentiska hudporer, mikroteksturer' },
  { id: 'cinematic', label: 'More Cinematic', desc: '35mm anamorfisk filmton, chiaroscuro-ljus, 2.39:1' },
  { id: 'detailed', label: 'More Detailed', desc: 'Rikare förgrund, partiklar och rumsligt djup' },
  { id: 'lighting', label: 'Better Lighting', desc: 'Volymetriska solstrålar, kantbelysning, reflektioner' },
  { id: 'camera', label: 'Better Camera', desc: 'Hasselblad/ARRI, 85mm f/1.4, skärpedjup och bokeh' },
  { id: 'composition', label: 'Better Composition', desc: 'Fibonacci-spiral, ledlinjer och balanserat negativt utrymme' },
  { id: 'movement', label: 'Better Movement', desc: 'Kinetisk energi, vind i kläder och naturlig rörelseoskärpa' },
  { id: 'atmosphere', label: 'Stronger Atmosphere', desc: 'Atmosfärisk dimma, fuktighet och känslomässigt djup' },
  { id: 'professional', label: 'Professional Rewrite', desc: 'Branschstandard med strukturerade studiomarkörer' },
  { id: 'expand', label: 'Expand Prompt', desc: 'Bygger ut enkla instruktioner till en fullskalig scen' },
  { id: 'shorten', label: 'Shorten Prompt', desc: 'Skalar bort utfyllnad och behåller endast kärntermer' },
  { id: 'translate_en', label: 'Translate to English', desc: 'Översätter till professionell engelsk promptstandard' },
  { id: 'translate_sv', label: 'Translate to Swedish', desc: 'Översätter och anpassar till svensk kreativ formulering' },
];

export const EnhancerSection: React.FC<Props> = ({ aiMode, onSavePrompt }) => {
  const [inputPrompt, setInputPrompt] = useState(
    'En vacker kvinna på en gata i Paris på kvällen.'
  );
  const [selectedMode, setSelectedMode] = useState('ultimate');
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [result, setResult] = useState<{
    original: string;
    enhanced: string;
    changes: string[];
    negativePrompt?: string;
    qualityScoreLocal?: number;
    reasoning?: string;
  } | null>(null);

  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleEnhance = async () => {
    if (!inputPrompt.trim()) return;
    setIsEnhancing(true);

    try {
      if (aiMode === 'gemini') {
        const res = await geminiService.enhance(inputPrompt, selectedMode, 'sv');
        setResult(res);
      } else {
        const res = localPromptEngine.enhancePrompt(inputPrompt, selectedMode, 'sv');
        setResult(res);
      }
    } catch {
      // Local fallback
      const res = localPromptEngine.enhancePrompt(inputPrompt, selectedMode, 'sv');
      setResult(res);
    } finally {
      setIsEnhancing(false);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSave = () => {
    if (!result) return;
    const item: PromptItem = {
      id: `enhanced-${Date.now()}`,
      title: `Förbättrad (${selectedMode}): ${inputPrompt.slice(0, 30)}`,
      category: 'Enhancer Pro',
      type: 'image',
      prompt: result.enhanced,
      negativePrompt: result.negativePrompt,
      tags: ['enhancer', selectedMode, aiMode],
      qualityScore: result.qualityScoreLocal || 85,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      modeUsed: aiMode,
    };
    onSavePrompt(item);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="border-b border-gray-800 pb-4">
        <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
          <Sliders className="w-5 h-5 text-indigo-400" />
          Prompt Enhancer Pro
        </h1>
        <p className="text-xs text-gray-400 mt-1">
          Lyft enkla eller otydliga prompter till mästarnivå med 14 specialiserade förädlingslägen.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Input & Modes */}
        <div className="lg:col-span-6 space-y-4">
          <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 space-y-2">
            <label className="text-xs font-bold text-gray-200 uppercase tracking-wider block">
              Ursprunglig Prompt:
            </label>
            <textarea
              value={inputPrompt}
              onChange={(e) => setInputPrompt(e.target.value)}
              placeholder="Skriv eller klistra in prompten du vill förbättra..."
              rows={4}
              className="w-full rounded-xl border border-gray-800 bg-gray-950 p-3 text-xs sm:text-sm text-white placeholder-gray-500 focus:border-indigo-500 focus:outline-none"
            />
          </div>

          {/* Mode Selector Grid */}
          <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 space-y-2.5">
            <label className="text-xs font-bold text-gray-200 uppercase tracking-wider block">
              Välj Förbättringsläge ({MODES.length} st):
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-72 overflow-y-auto pr-1">
              {MODES.map((mode) => (
                <div
                  key={mode.id}
                  onClick={() => setSelectedMode(mode.id)}
                  className={`cursor-pointer rounded-xl border p-2.5 transition min-h-[44px] ${
                    selectedMode === mode.id
                      ? 'border-indigo-500 bg-indigo-950/40 text-white shadow-sm'
                      : 'border-gray-800 bg-gray-950 text-gray-400 hover:border-gray-700 hover:text-gray-200'
                  }`}
                >
                  <div className="font-semibold text-xs text-white">{mode.label}</div>
                  <div className="text-[10px] text-gray-400 line-clamp-1">{mode.desc}</div>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={handleEnhance}
            disabled={isEnhancing || !inputPrompt.trim()}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 p-4 text-sm font-extrabold text-white shadow-xl shadow-indigo-950/50 hover:brightness-110 active:scale-[0.98] transition disabled:opacity-50 min-h-[52px]"
          >
            {isEnhancing ? (
              <>
                <RefreshCw className="w-5 h-5 animate-spin" />
                <span>Optimerar prompt...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 text-sky-300" />
                <span>Förbättra Prompt ({aiMode === 'gemini' ? 'Gemini AI' : 'Local Mode'})</span>
              </>
            )}
          </button>
        </div>

        {/* Comparison & Output */}
        <div className="lg:col-span-6 space-y-4">
          {result ? (
            <div className="space-y-4 animate-in fade-in duration-300">
              {/* Output Result Card */}
              <div className="rounded-2xl border border-gray-800 bg-gray-900/80 p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-gray-800 pb-3">
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    Förbättrad Prompt
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-semibold">
                    {MODES.find((m) => m.id === selectedMode)?.label}
                  </span>
                </div>

                <div className="rounded-xl border border-gray-800 bg-gray-950 p-4">
                  <p className="text-xs sm:text-sm text-gray-100 font-mono leading-relaxed select-all">
                    {result.enhanced}
                  </p>
                </div>

                {/* Changes List */}
                {result.changes && result.changes.length > 0 && (
                  <div className="rounded-xl border border-gray-800 bg-gray-950/60 p-3 space-y-1.5 text-xs">
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1">
                      <Diff className="w-3.5 h-3.5 text-indigo-400" />
                      Genomförda Förbättringar:
                    </span>
                    <ul className="space-y-1 text-gray-300 pl-1">
                      {result.changes.map((c, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="text-emerald-400 font-bold">✓</span>
                          <span>{c}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Reasoning */}
                {result.reasoning && (
                  <p className="text-[11px] text-gray-400 italic bg-gray-950/40 p-2.5 rounded-lg border border-gray-800/60">
                    💡 <strong>Motivering:</strong> {result.reasoning}
                  </p>
                )}

                {/* Actions */}
                <div className="flex items-center gap-2 pt-2">
                  <button
                    onClick={() => handleCopy(result.enhanced)}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gray-800 px-4 py-2.5 text-xs font-semibold text-white hover:bg-gray-700 active:scale-95 transition min-h-[44px]"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    <span>{copied ? 'Kopierad!' : 'Kopiera Förbättrad'}</span>
                  </button>

                  <button
                    onClick={handleSave}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-4 py-2.5 text-xs font-semibold text-white hover:brightness-110 active:scale-95 transition min-h-[44px]"
                  >
                    {saved ? <Check className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
                    <span>{saved ? 'Sparad!' : 'Spara Prompt'}</span>
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-gray-800 bg-gray-900/30 p-8 text-center space-y-3 min-h-[350px]">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-indigo-500/10 text-indigo-400">
                <Sliders className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-sm text-gray-200">Välj läge och förädla</h3>
              <p className="text-xs text-gray-400 max-w-xs">
                Klicka på <strong>Förbättra Prompt</strong> för att analysera och generera en professionell omskrivning med optiska och tekniska markörer.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
