import React, { useState } from 'react';
import { AIMode, PromptItem } from '../../types';
import { localPromptEngine, NEGATIVE_VIDEO_DEFAULTS } from '../../services/localEngine';
import { geminiService } from '../../services/geminiService';
import { evaluatePromptQuality } from '../../services/qualityScorer';
import { QualityScoreCard } from '../common/QualityScoreCard';
import {
  Video,
  Film,
  Camera,
  Clock,
  Sparkles,
  Copy,
  Check,
  Save,
  Bookmark,
  RefreshCw,
  Layers,
  ArrowRight,
} from 'lucide-react';

interface Props {
  aiMode: AIMode;
  onSavePrompt: (prompt: PromptItem) => void;
  onNavigate: (section: string) => void;
}

const VIDEO_CATEGORIES = [
  'Cinematic Video', 'Action', 'Documentary', 'Disaster', 'Nature',
  'Science Fiction', 'Fantasy', 'Music Video', 'Commercial', 'Historical',
  'Travel', 'Horror', 'Automotive', 'Drone', 'FPV', 'Slow Motion', 'Time-lapse', 'Hyperlapse'
];

const CAMERA_MOVEMENTS = [
  'Static Camera', 'Pan', 'Tilt', 'Dolly In', 'Dolly Out', 'Tracking Shot',
  'Orbit Shot', 'Crane Shot', 'Drone Flyover', 'FPV Flight', 'Handheld', 'Slow Motion'
];

const DURATIONS = ['5s', '10s', '15s', '30s', '60s'];

export const VideoStudioSection: React.FC<Props> = ({ aiMode, onSavePrompt }) => {
  const [category, setCategory] = useState('Cinematic Video');
  const [concept, setConcept] = useState('');
  const [cameraMove, setCameraMove] = useState('Tracking Shot');
  const [duration, setDuration] = useState('10s');
  const [fps, setFps] = useState('60fps');
  const [targetPlatform, setTargetPlatform] = useState('Google Veo');

  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState<{
    prompt: string;
    negative: string;
    sceneBreakdown?: {
      sceneDesc: string;
      subject: string;
      movement: string;
      camera: string;
      timeline: string;
      continuity: string;
    };
    quality: any;
  } | null>(null);

  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);

  const handleGenerate = async () => {
    if (!concept.trim()) return;
    setIsGenerating(true);

    try {
      if (aiMode === 'gemini') {
        const query = `
You are a master cinematic video prompt engineer for ${targetPlatform}.
Create a complete 12-dimension video prompt for:
Category: ${category}
Concept: ${concept}
Camera Movement: ${cameraMove}
Duration: ${duration} (${fps})
Platform: ${targetPlatform}

Include:
1. Scene Description
2. Main Subject & Action
3. Exact Camera Movement Rig
4. Environment & Lighting
5. Atmosphere & Visual Effects
6. Timeline Progression (0s to ${duration})
7. Continuity Anchors
8. Negative Prompt
`;
        const resText = await geminiService.generate(query, 'gemini-3.8-flash');
        const quality = evaluatePromptQuality(resText, 'video', NEGATIVE_VIDEO_DEFAULTS.slice(0, 8).join(', '));
        quality.evaluationType = 'gemini';

        setResult({
          prompt: resText,
          negative: NEGATIVE_VIDEO_DEFAULTS.slice(0, 10).join(', '),
          quality,
        });
      } else {
        // Local engine video generation
        const videoPrompt = `Cinematic ${category.toLowerCase()} video (${duration}, ${fps}): ${concept}. Camera: ${cameraMove} executing smooth continuous trajectory. Subject movement is fluid with authentic physical inertia. Volumetric cinematic lighting, rich depth of field, 35mm film color grade. Timeline: Starts at wide framing, smoothly accelerates into dynamic mid-shot. Continuity: locked lighting direction and wardrobe.`;

        const negative = NEGATIVE_VIDEO_DEFAULTS.slice(0, 10).join(', ');
        const quality = evaluatePromptQuality(videoPrompt, 'video', negative);

        setResult({
          prompt: videoPrompt,
          negative,
          sceneBreakdown: {
            sceneDesc: concept,
            subject: 'Huvudkaraktär / fordon med fysisk rörelse',
            movement: 'Flytande acceleration med realistisk dynamik',
            camera: cameraMove,
            timeline: `0s-${duration}: Mjuk etablering övergående i fokuserad rörelse`,
            continuity: 'Låst färgpalett, ljusvinkel och proportioner',
          },
          quality,
        });
      }
    } catch {
      // Local fallback
      const videoPrompt = `Cinematic ${category.toLowerCase()} video (${duration}, ${fps}): ${concept}. Camera: ${cameraMove} executing smooth continuous trajectory. Subject movement is fluid with authentic physical inertia. Volumetric cinematic lighting, rich depth of field, 35mm film color grade. Timeline: Starts at wide framing, smoothly accelerates into dynamic mid-shot. Continuity: locked lighting direction and wardrobe.`;

      const negative = NEGATIVE_VIDEO_DEFAULTS.slice(0, 10).join(', ');
      const quality = evaluatePromptQuality(videoPrompt, 'video', negative);

      setResult({
        prompt: videoPrompt,
        negative,
        quality,
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSave = () => {
    if (!result) return;
    const item: PromptItem = {
      id: `vid-studio-${Date.now()}`,
      title: `${category}: ${concept.slice(0, 35)}`,
      category,
      type: 'video',
      prompt: result.prompt,
      negativePrompt: result.negative,
      platform: targetPlatform,
      tags: [category.toLowerCase(), cameraMove.toLowerCase(), targetPlatform.toLowerCase(), 'video-studio'],
      qualityScore: result.quality.totalScore,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      isFavorite,
      modeUsed: aiMode,
    };
    onSavePrompt(item);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="border-b border-gray-800 pb-4">
        <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
          <Film className="w-5 h-5 text-sky-400" />
          Video Prompt Studio
        </h1>
        <p className="text-xs text-gray-400 mt-1">
          Konstruera tidslinjebaserade videoprompter för Google Veo, Runway Gen-3, OpenAI Sora och Kling AI.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Controls */}
        <div className="lg:col-span-7 space-y-4">
          {/* Categories */}
          <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 space-y-2">
            <label className="text-xs font-bold text-gray-300 uppercase tracking-wider block">
              1. Videogenre ({VIDEO_CATEGORIES.length} st)
            </label>
            <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto pr-1">
              {VIDEO_CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategory(cat)}
                  className={`rounded-xl px-2.5 py-1.5 text-xs font-medium transition min-h-[38px] ${
                    category === cat
                      ? 'bg-sky-600 text-white font-semibold shadow-sm'
                      : 'border border-gray-800 bg-gray-950 text-gray-400 hover:text-white hover:bg-gray-800'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Scene Concept */}
          <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 space-y-2">
            <label className="text-xs font-bold text-gray-200 uppercase tracking-wider block">
              2. Scenbeskrivning & Händelseförlopp
            </label>
            <textarea
              value={concept}
              onChange={(e) => setConcept(e.target.value)}
              placeholder="Ex: En sportbil accelererar genom en kurva på en kustväg i solnedgången medan vågor slår mot klipporna..."
              rows={3}
              className="w-full rounded-xl border border-gray-800 bg-gray-950 p-3 text-xs sm:text-sm text-white placeholder-gray-500 focus:border-sky-500 focus:outline-none"
            />
          </div>

          {/* Camera Movement Selection */}
          <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 space-y-2.5">
            <label className="text-xs font-bold text-gray-200 uppercase tracking-wider flex items-center gap-1.5">
              <Camera className="w-3.5 h-3.5 text-sky-400" />
              <span>3. Kamerarörelse & Rigg ({CAMERA_MOVEMENTS.length} typer)</span>
            </label>
            <div className="flex flex-wrap gap-1.5">
              {CAMERA_MOVEMENTS.map((move) => (
                <button
                  key={move}
                  onClick={() => setCameraMove(move)}
                  className={`rounded-xl px-3 py-1.5 text-xs font-medium transition min-h-[40px] ${
                    cameraMove === move
                      ? 'bg-purple-600 text-white font-semibold'
                      : 'border border-gray-800 bg-gray-950 text-gray-400 hover:text-white hover:bg-gray-800'
                  }`}
                >
                  {move}
                </button>
              ))}
            </div>
          </div>

          {/* Duration & Target Platform */}
          <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-semibold text-gray-300 block mb-1.5">Videolängd</label>
              <div className="flex flex-wrap gap-1">
                {DURATIONS.map((d) => (
                  <button
                    key={d}
                    onClick={() => setDuration(d)}
                    className={`rounded-xl px-2.5 py-1 text-xs font-semibold transition min-h-[36px] ${
                      duration === d
                        ? 'bg-sky-600 text-white'
                        : 'border border-gray-800 bg-gray-950 text-gray-400 hover:text-white'
                    }`}
                  >
                    {d}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-gray-300 block mb-1.5">Bildfrekvens</label>
              <select
                value={fps}
                onChange={(e) => setFps(e.target.value)}
                className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:border-sky-500 focus:outline-none min-h-[44px]"
              >
                <option value="24fps">24 fps (Klassisk biofilm)</option>
                <option value="30fps">30 fps (Standard)</option>
                <option value="60fps">60 fps (Ultra-flytande rörelse)</option>
                <option value="120fps">120 fps (Cinematisk Slow-motion)</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold text-gray-300 block mb-1.5">Målmodell</label>
              <select
                value={targetPlatform}
                onChange={(e) => setTargetPlatform(e.target.value)}
                className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:border-sky-500 focus:outline-none min-h-[44px]"
              >
                <option value="Google Veo">Google Veo</option>
                <option value="Runway Gen-3">Runway Gen-3</option>
                <option value="Sora">OpenAI Sora</option>
                <option value="Kling AI">Kling AI v1.5</option>
              </select>
            </div>
          </div>

          {/* Generate Button */}
          <button
            onClick={handleGenerate}
            disabled={isGenerating || !concept.trim()}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-sky-600 via-indigo-600 to-purple-600 p-4 text-sm font-extrabold text-white shadow-xl shadow-sky-950/50 hover:brightness-110 active:scale-[0.98] transition disabled:opacity-50 min-h-[52px]"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="w-5 h-5 animate-spin" />
                <span>Skapar filmsekvens...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 text-sky-300" />
                <span>Generera Videoprompt ({aiMode === 'gemini' ? 'Gemini AI' : 'Local Mode'})</span>
              </>
            )}
          </button>
        </div>

        {/* Output */}
        <div className="lg:col-span-5 space-y-4">
          {result ? (
            <div className="space-y-4 animate-in fade-in duration-300">
              <QualityScoreCard result={result.quality} />

              <div className="rounded-2xl border border-gray-800 bg-gray-900/80 p-4 space-y-3">
                <div className="flex items-center justify-between border-b border-gray-800 pb-2">
                  <span className="text-xs font-bold text-sky-400 uppercase tracking-wider">
                    {targetPlatform} Videoprompt ({duration})
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-gray-800 text-gray-300">
                    {cameraMove}
                  </span>
                </div>

                <div className="rounded-xl border border-gray-800 bg-gray-950 p-3.5">
                  <p className="text-xs sm:text-sm text-gray-100 font-mono leading-relaxed select-all whitespace-pre-wrap">
                    {result.prompt}
                  </p>
                </div>

                {result.sceneBreakdown && (
                  <div className="rounded-xl border border-gray-800 bg-gray-950/80 p-3 text-xs space-y-1.5 text-gray-300">
                    <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block">
                      Kontinuitetsdata:
                    </span>
                    <p>• <strong>Tidslinje:</strong> {result.sceneBreakdown.timeline}</p>
                    <p>• <strong>Kamera:</strong> {result.sceneBreakdown.camera}</p>
                    <p>• <strong>Ankare:</strong> {result.sceneBreakdown.continuity}</p>
                  </div>
                )}

                <div className="rounded-xl border border-rose-500/20 bg-rose-950/20 p-3 space-y-1">
                  <span className="text-[10px] font-bold text-rose-400 uppercase tracking-wider block">
                    Negativ Videoprompt (Förhindra artefakter):
                  </span>
                  <p className="text-xs text-rose-200/90 font-mono select-all">
                    {result.negative}
                  </p>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={() => handleCopy(result.prompt)}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gray-800 px-3 py-2 text-xs font-semibold text-white hover:bg-gray-700 active:scale-95 transition min-h-[44px]"
                  >
                    {copied ? (
                      <>
                        <Check className="w-4 h-4 text-emerald-400" />
                        <span>Kopierad!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        <span>Kopiera</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={handleSave}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 px-3 py-2 text-xs font-semibold text-white hover:brightness-110 active:scale-95 transition min-h-[44px]"
                  >
                    {saved ? (
                      <>
                        <Check className="w-4 h-4 text-emerald-300" />
                        <span>Sparad!</span>
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4" />
                        <span>Spara</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => setIsFavorite(!isFavorite)}
                    className={`rounded-xl p-2.5 border transition min-h-[44px] min-w-[44px] flex items-center justify-center ${
                      isFavorite
                        ? 'border-amber-500/40 bg-amber-500/10 text-amber-400'
                        : 'border-gray-800 bg-gray-800 text-gray-400 hover:text-white'
                    }`}
                  >
                    <Bookmark className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-gray-800 bg-gray-900/30 p-8 text-center space-y-3 min-h-[300px]">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-sky-500/10 text-sky-400">
                <Video className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-sm text-gray-200">Definiera filmrörelse</h3>
              <p className="text-xs text-gray-400 max-w-xs">
                Skapa videoprompter med exakt kamerarigg, tidslinje och kontinuitetsmarkörer.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
