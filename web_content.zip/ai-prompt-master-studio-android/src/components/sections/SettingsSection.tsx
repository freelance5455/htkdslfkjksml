import React, { useState, useEffect } from 'react';
import { AppSettings, AIMode, AppTheme, AppLanguage, MediaType } from '../../types';
import { storageService } from '../../services/storage';
import {
  geminiService,
  getCustomApiKey,
  setCustomApiKey,
  validateGeminiApiKey,
  maskApiKey,
  TestKeyResult,
} from '../../services/geminiService';
import {
  Settings,
  Moon,
  Sun,
  Globe,
  Cpu,
  Sparkles,
  Save,
  Check,
  RotateCcw,
  ShieldCheck,
  Sliders,
  Key,
  Eye,
  EyeOff,
  Trash2,
  AlertCircle,
  ExternalLink,
  CheckCircle2,
  RefreshCw,
} from 'lucide-react';

interface Props {
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  hasGeminiKey: boolean;
  onApiKeyChanged?: () => void;
}

export const SettingsSection: React.FC<Props> = ({
  settings,
  onUpdateSettings,
  hasGeminiKey,
  onApiKeyChanged,
}) => {
  const [localSettings, setLocalSettings] = useState<AppSettings>(settings);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Custom API key states
  const [customKeyInput, setCustomKeyInput] = useState<string>('');
  const [showKey, setShowKey] = useState<boolean>(false);
  const [savedCustomKey, setSavedCustomKey] = useState<string | null>(null);
  const [keySaveMessage, setKeySaveMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);
  const [isTestingKey, setIsTestingKey] = useState<boolean>(false);
  const [testResult, setTestResult] = useState<TestKeyResult | null>(null);

  // Load existing custom API key on mount
  useEffect(() => {
    const existing = getCustomApiKey();
    if (existing) {
      setSavedCustomKey(existing);
      setCustomKeyInput(existing);
    }
  }, []);

  const handleChange = <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => {
    const updated = { ...localSettings, [key]: value };
    setLocalSettings(updated);
    onUpdateSettings(updated);
    storageService.saveSettings(updated);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  const handleSaveCustomKey = () => {
    const trimmed = customKeyInput.trim();
    if (!trimmed) {
      setKeySaveMessage({
        type: 'error',
        text: 'Vänligen ange en giltig API-nyckel eller klicka på "Ta bort" för att rensa.',
      });
      return;
    }

    // Format validation before saving
    const validation = validateGeminiApiKey(trimmed);
    if (!validation.isValid) {
      setKeySaveMessage({
        type: 'error',
        text: validation.error || 'Ogiltigt format på Gemini API-nyckeln.',
      });
      return;
    }

    const saveResult = setCustomApiKey(trimmed);
    if (!saveResult.success) {
      setKeySaveMessage({
        type: 'error',
        text: saveResult.error || 'Kunde inte spara API-nyckeln i webbläsarens minne.',
      });
      return;
    }

    const cleanKey = validation.cleanedKey || trimmed;
    setSavedCustomKey(cleanKey);
    setKeySaveMessage({
      type: 'success',
      text: 'Format godkänt! Din egna Gemini API-nyckel har sparats krypterad i webbläsaren.',
    });
    setTestResult(null);

    if (onApiKeyChanged) {
      onApiKeyChanged();
    }

    setTimeout(() => {
      setKeySaveMessage(null);
    }, 4000);
  };

  const handleClearCustomKey = () => {
    setCustomApiKey(null);
    setSavedCustomKey(null);
    setCustomKeyInput('');
    setTestResult(null);
    setKeySaveMessage({
      type: 'info',
      text: 'Egen API-nyckel raderad. Serverns standardkonfiguration används nu.',
    });

    if (onApiKeyChanged) {
      onApiKeyChanged();
    }

    setTimeout(() => {
      setKeySaveMessage(null);
    }, 4000);
  };

  const handleTestKey = async () => {
    const trimmed = customKeyInput.trim();
    if (trimmed) {
      const validation = validateGeminiApiKey(trimmed);
      if (!validation.isValid) {
        setKeySaveMessage({
          type: 'error',
          text: `Kan inte testa: ${validation.error}`,
        });
        return;
      }
    }

    const keyToTest = trimmed || undefined;
    setIsTestingKey(true);
    setTestResult(null);
    setKeySaveMessage(null);

    try {
      const res = await geminiService.testApiKey(keyToTest);
      setTestResult(res);
      if (res.success) {
        setKeySaveMessage({
          type: 'success',
          text: `Anslutning lyckades! Modellen ${res.model || 'gemini-3.8-flash'} svarade korrekt.`,
        });
      } else {
        setKeySaveMessage({
          type: 'error',
          text: res.error || 'Kunde inte verifiera API-nyckeln.',
        });
      }
    } catch (err) {
      setTestResult({
        success: false,
        error: err instanceof Error ? err.message : 'Kunde inte ansluta till Gemini backend',
      });
    } finally {
      setIsTestingKey(false);
    }
  };

  const handleResetDefaults = () => {
    const defaults: AppSettings = {
      theme: 'dark',
      language: 'sv',
      aiMode: 'local',
      geminiModel: 'gemini-3.8-flash',
      defaultMediaType: 'image',
      defaultPlatform: 'midjourney',
      defaultAspectRatio: '16:9',
      defaultDetailLevel: 'ultimate',
      autosave: true,
      showQualityScore: true,
      confirmDelete: true,
    };
    setLocalSettings(defaults);
    onUpdateSettings(defaults);
    storageService.saveSettings(defaults);
  };

  const hasActiveKey = Boolean(savedCustomKey || hasGeminiKey);

  return (
    <div className="space-y-6 pb-24 max-w-4xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-800 pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
            <Settings className="w-5 h-5 text-purple-400" />
            Studio Inställningar
          </h1>
          <p className="text-xs text-gray-400 mt-1">
            Konfigurera AI-driftläge, egen Gemini API-nyckel, standardparametrar och lagring.
          </p>
        </div>

        {savedSuccess && (
          <span className="flex items-center gap-1.5 text-xs text-emerald-400 font-semibold bg-emerald-500/10 px-3 py-1.5 rounded-full border border-emerald-500/30">
            <Check className="w-3.5 h-3.5" />
            Sparat automatiskt
          </span>
        )}
      </div>

      {/* 1. Driftläge & Gemini AI */}
      <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-5 space-y-5">
        <span className="text-xs font-bold text-gray-200 uppercase tracking-wider block">
          1. AI Driftläge & Motorkonfiguration
        </span>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div
            onClick={() => handleChange('aiMode', 'local')}
            className={`cursor-pointer rounded-2xl border p-4 transition ${
              localSettings.aiMode === 'local'
                ? 'border-emerald-500 bg-emerald-950/20'
                : 'border-gray-800 bg-gray-950 hover:border-gray-700'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-sm text-white flex items-center gap-1.5">
                <Cpu className="w-4 h-4 text-emerald-400" />
                Mode A: Free Local Mode
              </span>
              {localSettings.aiMode === 'local' && (
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded-full">
                  Valt
                </span>
              )}
            </div>
            <p className="text-xs text-gray-400">
              100% offline-kapabel regelmotor. Inga API-anrop, ingen registrering, obegränsad användning.
            </p>
          </div>

          <div
            onClick={() => handleChange('aiMode', 'gemini')}
            className={`cursor-pointer rounded-2xl border p-4 transition ${
              localSettings.aiMode === 'gemini'
                ? 'border-purple-500 bg-purple-950/20'
                : 'border-gray-800 bg-gray-950 hover:border-gray-700'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-sm text-white flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-purple-400" />
                Mode B: Google Gemini AI
              </span>
              {localSettings.aiMode === 'gemini' && (
                <span className="text-[10px] bg-purple-500/20 text-purple-300 font-bold px-2 py-0.5 rounded-full">
                  Valt
                </span>
              )}
            </div>
            <p className="text-xs text-gray-400">
              Avancerad neural promptgenerering, AI-intervjuer och multimodal bildanalys via server backend.
            </p>
          </div>
        </div>

        {/* Gemini Model Selector */}
        <div>
          <label className="text-xs font-semibold text-gray-300 block mb-1">
            Vald Gemini-modell:
          </label>
          <select
            value={localSettings.geminiModel}
            onChange={(e) => handleChange('geminiModel', e.target.value)}
            className="w-full sm:w-80 rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500 min-h-[44px]"
          >
            <option value="gemini-3.8-flash">gemini-3.8-flash (Standard & Snabb)</option>
            <option value="gemini-4-argon">gemini-4-argon (Komplex Text & Logik)</option>
            <option value="gemini-4-carbon">gemini-4-carbon (Djupgående Resonemang)</option>
          </select>
        </div>

        {/* SECURE CUSTOM GEMINI API KEY INPUT CARD */}
        <div className="rounded-2xl border border-purple-500/40 bg-gradient-to-b from-purple-950/30 to-gray-950 p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-gray-800/80 pb-3">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-purple-500/20 text-purple-300 border border-purple-500/30">
                <Key className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Egen Gemini API-nyckel (Custom Gemini API Key)</h3>
                <p className="text-[11px] text-gray-400">
                  Lägg till din personliga Google Gemini API-nyckel för att driva AI-läget.
                </p>
              </div>
            </div>

            {/* Current status pill */}
            <div className="flex items-center gap-1.5">
              {savedCustomKey ? (
                <span className="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-300 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/30">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  Egen nyckel aktiv: {maskApiKey(savedCustomKey)}
                </span>
              ) : hasGeminiKey ? (
                <span className="flex items-center gap-1.5 text-[11px] font-semibold text-sky-300 bg-sky-500/10 px-2.5 py-1 rounded-full border border-sky-500/30">
                  <ShieldCheck className="w-3.5 h-3.5 text-sky-400" />
                  Servernyckel aktiv (GEMINI_API_KEY)
                </span>
              ) : (
                <span className="flex items-center gap-1.5 text-[11px] font-semibold text-amber-300 bg-amber-500/10 px-2.5 py-1 rounded-full border border-amber-500/30">
                  <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                  Ingen nyckel angiven
                </span>
              )}
            </div>
          </div>

          {/* Secure Input Box */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-gray-300 block">
              Ange din Gemini API-nyckel:
            </label>

            <div className="relative flex items-center">
              <input
                type={showKey ? 'text' : 'password'}
                value={customKeyInput}
                onChange={(e) => setCustomKeyInput(e.target.value)}
                placeholder="AIzaSy... (klistra in din API-nyckel här)"
                autoComplete="off"
                spellCheck={false}
                className="w-full rounded-xl border border-gray-800 bg-gray-950 pl-3.5 pr-24 py-2.5 text-xs text-white placeholder-gray-600 font-mono focus:outline-none focus:border-purple-500 min-h-[46px]"
              />

              <div className="absolute right-2 flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setShowKey(!showKey)}
                  className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition min-h-[36px] min-w-[36px] flex items-center justify-center"
                  title={showKey ? 'Dölj nyckel' : 'Visa nyckel'}
                >
                  {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <p className="text-[11px] text-gray-500 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-purple-400 shrink-0" />
              <span>
                Nyckeln sparas krypterad lokalt i din webbläsare och sänds enbart via skyddad HTTPS-header till backend-proxyn.
              </span>
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <button
              type="button"
              onClick={handleSaveCustomKey}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition shadow-md shadow-purple-900/30 min-h-[44px]"
            >
              <Save className="w-4 h-4" />
              <span>Spara nyckel</span>
            </button>

            <button
              type="button"
              onClick={handleTestKey}
              disabled={isTestingKey || (!customKeyInput.trim() && !hasGeminiKey)}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-gray-800 hover:bg-gray-700 disabled:opacity-40 text-gray-200 text-xs font-semibold transition min-h-[44px]"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTestingKey ? 'animate-spin text-purple-400' : 'text-sky-400'}`} />
              <span>{isTestingKey ? 'Testar...' : 'Testa anslutning'}</span>
            </button>

            {savedCustomKey && (
              <button
                type="button"
                onClick={handleClearCustomKey}
                className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-red-950/40 hover:bg-red-900/50 text-red-300 border border-red-800/50 text-xs font-semibold transition ml-auto min-h-[44px]"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Ta bort egen nyckel</span>
              </button>
            )}
          </div>

          {/* Feedback messages */}
          {keySaveMessage && (
            <div
              className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
                keySaveMessage.type === 'success'
                  ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                  : keySaveMessage.type === 'error'
                  ? 'bg-red-950/40 border-red-500/40 text-red-300'
                  : 'bg-sky-950/40 border-sky-500/40 text-sky-300'
              }`}
            >
              {keySaveMessage.type === 'success' && <CheckCircle2 className="w-4 h-4 shrink-0" />}
              {keySaveMessage.type === 'error' && <AlertCircle className="w-4 h-4 shrink-0" />}
              {keySaveMessage.type === 'info' && <ShieldCheck className="w-4 h-4 shrink-0" />}
              <span>{keySaveMessage.text}</span>
            </div>
          )}

          {/* How to get an API Key guide */}
          <div className="rounded-xl bg-gray-950/80 p-3.5 border border-gray-800/80 space-y-2 text-xs">
            <span className="font-semibold text-purple-300 block">
              Var hämtar jag en egen Gemini API-nyckel?
            </span>
            <p className="text-gray-400 leading-relaxed text-[11px]">
              Du kan skapa och hämta en gratis eller betald API-nyckel direkt från Google AI Studio. Nyckeln har formatet <code>AIzaSy...</code>.
            </p>
            <div className="flex flex-wrap items-center gap-3 pt-1">
              <a
                href="https://aistudio.google.com/app/apikey"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 text-xs text-sky-400 hover:text-sky-300 font-semibold transition hover:underline"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Skapa API-nyckel i Google AI Studio</span>
              </a>
              <span className="text-gray-600">•</span>
              <span className="text-[11px] text-gray-500">
                Alternativt kan utvecklare konfigurera <code>GEMINI_API_KEY</code> i AI Studios Secrets-panel.
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Standardvärden för Prompter */}
      <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-5 space-y-4">
        <span className="text-xs font-bold text-gray-200 uppercase tracking-wider block">
          2. Standardparametrar i Builder
        </span>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="text-xs text-gray-400 block mb-1">Standardtyp</label>
            <select
              value={localSettings.defaultMediaType}
              onChange={(e) => handleChange('defaultMediaType', e.target.value as MediaType)}
              className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500 min-h-[44px]"
            >
              <option value="image">Bild (Image Studio)</option>
              <option value="video">Video (Video Studio)</option>
            </select>
          </div>

          <div>
            <label className="text-xs text-gray-400 block mb-1">Standard Bildförhållande</label>
            <select
              value={localSettings.defaultAspectRatio}
              onChange={(e) => handleChange('defaultAspectRatio', e.target.value)}
              className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500 min-h-[44px]"
            >
              <option value="16:9">16:9 (Standard widescreen)</option>
              <option value="9:16">9:16 (Vertikal)</option>
              <option value="1:1">1:1 (Kvadrat)</option>
              <option value="4:5">4:5 (Porträtt)</option>
              <option value="21:9">21:9 (Cinemascope)</option>
            </select>
          </div>

          <div>
            <label className="text-xs text-gray-400 block mb-1">Standard Målplattform</label>
            <select
              value={localSettings.defaultPlatform}
              onChange={(e) => handleChange('defaultPlatform', e.target.value)}
              className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500 min-h-[44px]"
            >
              <option value="midjourney">Midjourney</option>
              <option value="flux">FLUX.1</option>
              <option value="veo">Google Veo</option>
              <option value="runway">Runway Gen-3</option>
              <option value="sora">Sora</option>
            </select>
          </div>
        </div>

        {/* Toggles */}
        <div className="space-y-2 pt-2 border-t border-gray-800/80">
          <label className="flex items-center gap-2.5 cursor-pointer text-xs text-gray-200 min-h-[36px]">
            <input
              type="checkbox"
              checked={localSettings.autosave}
              onChange={(e) => handleChange('autosave', e.target.checked)}
              className="w-4 h-4 rounded border-gray-700 text-purple-600 focus:ring-0"
            />
            <span>Autospara alla genererade prompter i lokal historik</span>
          </label>

          <label className="flex items-center gap-2.5 cursor-pointer text-xs text-gray-200 min-h-[36px]">
            <input
              type="checkbox"
              checked={localSettings.showQualityScore}
              onChange={(e) => handleChange('showQualityScore', e.target.checked)}
              className="w-4 h-4 rounded border-gray-700 text-purple-600 focus:ring-0"
            />
            <span>Visa Prompt Quality Score (0–100) vid generering</span>
          </label>

          <label className="flex items-center gap-2.5 cursor-pointer text-xs text-gray-200 min-h-[36px]">
            <input
              type="checkbox"
              checked={localSettings.confirmDelete}
              onChange={(e) => handleChange('confirmDelete', e.target.checked)}
              className="w-4 h-4 rounded border-gray-700 text-purple-600 focus:ring-0"
            />
            <span>Bekräfta innan radering av projekt eller prompter</span>
          </label>
        </div>
      </div>

      {/* 3. Återställning */}
      <div className="flex justify-end pt-2">
        <button
          onClick={handleResetDefaults}
          className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white transition px-3 py-2 rounded-xl hover:bg-gray-850 min-h-[44px]"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Återställ standardinställningar</span>
        </button>
      </div>
    </div>
  );
};
