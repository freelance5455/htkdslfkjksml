import React, { useState } from 'react';
import { PromptItem } from '../../types';
import {
  History,
  Search,
  Copy,
  Check,
  Trash2,
  Wand2,
  Calendar,
} from 'lucide-react';

interface Props {
  prompts: PromptItem[];
  onSelectPrompt: (prompt: PromptItem) => void;
  onDeletePrompt: (id: string) => void;
  onNavigate: (section: string) => void;
}

export const HistorySection: React.FC<Props> = ({
  prompts,
  onSelectPrompt,
  onDeletePrompt,
  onNavigate,
}) => {
  const [search, setSearch] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filtered = prompts.filter(
    (p) =>
      p.title.toLowerCase().includes(search.toLowerCase()) ||
      p.prompt.toLowerCase().includes(search.toLowerCase())
  );

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString('sv-SE', {
      dateStyle: 'short',
      timeStyle: 'short',
    });
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-800 pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
            <History className="w-5 h-5 text-sky-400" />
            Prompt Historik ({prompts.length})
          </h1>
          <p className="text-xs text-gray-400 mt-1">
            Alla prompter du har genererat eller sparat sparas automatiskt i lokal IndexedDB.
          </p>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="w-4 h-4 text-gray-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Sök i historiken..."
          className="w-full rounded-xl border border-gray-800 bg-gray-900/60 pl-10 pr-4 py-2.5 text-xs sm:text-sm text-white placeholder-gray-500 focus:border-sky-500 focus:outline-none min-h-[44px]"
        />
      </div>

      {/* History Items */}
      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-gray-800 bg-gray-900/30 p-12 text-center text-xs text-gray-500">
          Ingen historik hittades. Prompter du genererar loggas automatiskt här.
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((item) => (
            <div
              key={item.id}
              className="rounded-2xl border border-gray-800 bg-gray-900/70 p-4 space-y-2.5 hover:border-gray-700 transition"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm text-white">{item.title}</span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-gray-800 text-gray-400 uppercase">
                    {item.type}
                  </span>
                  <span className="text-[10px] text-gray-500 flex items-center gap-1 font-mono">
                    <Calendar className="w-3 h-3" />
                    {formatDate(item.updatedAt)}
                  </span>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleCopy(item.id, item.prompt)}
                    className="p-1.5 text-gray-400 hover:text-white rounded-lg hover:bg-gray-800 transition min-h-[36px] min-w-[36px] flex items-center justify-center"
                    title="Kopiera"
                  >
                    {copiedId === item.id ? (
                      <Check className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>

                  <button
                    onClick={() => onDeletePrompt(item.id)}
                    className="p-1.5 text-gray-500 hover:text-rose-400 rounded-lg hover:bg-gray-800 transition min-h-[36px] min-w-[36px] flex items-center justify-center"
                    title="Ta bort"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <p className="text-xs text-gray-300 font-mono line-clamp-2 bg-gray-950/60 p-2.5 rounded-xl border border-gray-800/60 select-all">
                {item.prompt}
              </p>

              <div className="flex items-center justify-between text-xs pt-1">
                <div className="flex items-center gap-2 text-gray-400">
                  <span>Plattform: {item.platform || 'General'}</span>
                  {item.qualityScore && (
                    <span>• Poäng: {item.qualityScore}/100</span>
                  )}
                </div>

                <button
                  onClick={() => {
                    onSelectPrompt(item);
                    onNavigate('prompt-builder');
                  }}
                  className="text-xs text-sky-400 hover:text-sky-300 flex items-center gap-1 font-medium"
                >
                  <Wand2 className="w-3.5 h-3.5" />
                  <span>Öppna i Builder</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
