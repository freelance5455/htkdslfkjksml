import React from 'react';
import { AIMode, PromptItem, Project } from '../../types';
import {
  Sparkles,
  Cpu,
  Wand2,
  Film,
  ImageIcon,
  Video,
  Sliders,
  BookOpen,
  Bookmark,
  Clock,
  ArrowRight,
  HardDrive,
  Copy,
  Check,
  CheckCircle2,
} from 'lucide-react';

interface Props {
  aiMode: AIMode;
  onToggleMode: (mode: AIMode) => void;
  hasGeminiKey: boolean;
  onNavigate: (section: string) => void;
  prompts: PromptItem[];
  projects: Project[];
  onSelectPrompt: (prompt: PromptItem) => void;
}

export const DashboardSection: React.FC<Props> = ({
  aiMode,
  onToggleMode,
  hasGeminiKey,
  onNavigate,
  prompts,
  projects,
  onSelectPrompt,
}) => {
  const [copiedId, setCopiedId] = React.useState<string | null>(null);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const favoritePrompts = prompts.filter((p) => p.isFavorite);
  const recentPrompts = prompts.slice(0, 4);

  return (
    <div className="space-y-6 pb-20">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl border border-purple-500/30 bg-gradient-to-br from-purple-950/70 via-gray-900 to-indigo-950/80 p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 rounded-full border border-purple-400/30 bg-purple-500/10 px-3 py-1 text-xs font-semibold text-purple-300">
            <Sparkles className="w-3.5 h-3.5 text-sky-400" />
            <span>AI PROMPT MASTER STUDIO ULTIMATE 3.0</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight">
            Skapa, förädla och organisera{' '}
            <span className="bg-gradient-to-r from-sky-400 via-indigo-300 to-purple-400 bg-clip-text text-transparent">
              professionella prompter
            </span>
          </h1>

          <p className="text-xs sm:text-sm text-gray-300 leading-relaxed max-w-2xl">
            Växla sömlöst mellan <strong>Free Local Mode</strong> (100% offline regelmotor) och{' '}
            <strong>Gemini AI Mode</strong> för bild- och videogenerering i världsklass (Midjourney, FLUX, Veo, Sora, Runway).
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => onNavigate('prompt-builder')}
              className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-purple-600 to-sky-600 px-5 py-3 text-xs sm:text-sm font-bold text-white shadow-xl shadow-purple-950/50 hover:brightness-110 active:scale-95 transition min-h-[44px]"
            >
              <Wand2 className="w-4 h-4" />
              <span>Öppna Prompt Builder</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onNavigate('library')}
              className="flex items-center gap-2 rounded-xl border border-gray-700 bg-gray-900/80 px-4 py-3 text-xs sm:text-sm font-medium text-gray-200 hover:bg-gray-800 transition min-h-[44px]"
            >
              <BookOpen className="w-4 h-4 text-purple-400" />
              <span>Utforska 100+ Prompter</span>
            </button>
          </div>
        </div>

        {/* Decorative background glow */}
        <div className="absolute -right-10 -bottom-10 h-64 w-64 rounded-full bg-sky-500/10 blur-3xl pointer-events-none" />
        <div className="absolute right-40 -top-10 h-64 w-64 rounded-full bg-purple-600/15 blur-3xl pointer-events-none" />
      </div>

      {/* Mode Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Local Engine Status */}
        <div
          onClick={() => onToggleMode('local')}
          className={`cursor-pointer rounded-2xl border p-4 sm:p-5 transition ${
            aiMode === 'local'
              ? 'border-emerald-500/50 bg-emerald-950/20 shadow-lg shadow-emerald-950/20'
              : 'border-gray-800 bg-gray-900/60 hover:border-gray-700'
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2.5">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                <Cpu className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm sm:text-base text-white">Mode A: Free Local Mode</h3>
                <span className="text-[11px] text-emerald-400 flex items-center gap-1 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" /> 100% Offline & Gratis
                </span>
              </div>
            </div>
            {aiMode === 'local' && (
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                Aktivt
              </span>
            )}
          </div>
          <p className="text-xs text-gray-400 leading-relaxed">
            Regelbaserad textmotor, nyckelordsdatabaser, synonymer, 8-delat kvalitetsindex och mallar direkt i webbläsaren utan externa anrop eller registrering.
          </p>
        </div>

        {/* Gemini Engine Status */}
        <div
          onClick={() => onToggleMode('gemini')}
          className={`cursor-pointer rounded-2xl border p-4 sm:p-5 transition ${
            aiMode === 'gemini'
              ? 'border-purple-500/50 bg-purple-950/20 shadow-lg shadow-purple-950/20'
              : 'border-gray-800 bg-gray-900/60 hover:border-gray-700'
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2.5">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/30">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm sm:text-base text-white">Mode B: Google Gemini AI</h3>
                <span className="text-[11px] text-sky-400 font-semibold">
                  {hasGeminiKey ? 'Gemini 3.8 Flash ansluten via backend' : 'Backend aktiv (Secrets panel)'}
                </span>
              </div>
            </div>
            {aiMode === 'gemini' && (
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/40">
                Aktivt
              </span>
            )}
          </div>
          <p className="text-xs text-gray-400 leading-relaxed">
            Djup multimodal analys, dynamisk AI-intervju, kontinuerliga scener, bild-till-prompt och intelligent omformulering via säker server-side integration.
          </p>
        </div>
      </div>

      {/* Quick Actions Grid */}
      <div className="space-y-3">
        <h2 className="text-xs font-bold uppercase tracking-wider text-gray-400">Snabbval & Verktyg</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <button
            onClick={() => onNavigate('image-generator')}
            className="flex flex-col items-start gap-2 rounded-2xl border border-gray-800 bg-gray-900/70 p-4 text-left hover:border-purple-500/40 hover:bg-gray-800/80 transition min-h-[90px]"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-sky-500/10 text-sky-400">
              <ImageIcon className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-xs sm:text-sm text-white block">Image Studio</span>
              <span className="text-[11px] text-gray-400">Fotorealism & Optik</span>
            </div>
          </button>

          <button
            onClick={() => onNavigate('video-generator')}
            className="flex flex-col items-start gap-2 rounded-2xl border border-gray-800 bg-gray-900/70 p-4 text-left hover:border-purple-500/40 hover:bg-gray-800/80 transition min-h-[90px]"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-purple-500/10 text-purple-400">
              <Video className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-xs sm:text-sm text-white block">Video Studio</span>
              <span className="text-[11px] text-gray-400">Veo, Sora, Runway</span>
            </div>
          </button>

          <button
            onClick={() => onNavigate('enhancer')}
            className="flex flex-col items-start gap-2 rounded-2xl border border-gray-800 bg-gray-900/70 p-4 text-left hover:border-purple-500/40 hover:bg-gray-800/80 transition min-h-[90px]"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-500/10 text-indigo-400">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-xs sm:text-sm text-white block">Enhancer Pro</span>
              <span className="text-[11px] text-gray-400">Förädla befintlig prompt</span>
            </div>
          </button>

          <button
            onClick={() => onNavigate('storyboard')}
            className="flex flex-col items-start gap-2 rounded-2xl border border-gray-800 bg-gray-900/70 p-4 text-left hover:border-purple-500/40 hover:bg-gray-800/80 transition min-h-[90px]"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-pink-500/10 text-pink-400">
              <Film className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-xs sm:text-sm text-white block">Storyboard</span>
              <span className="text-[11px] text-gray-400">5-20 scener i följd</span>
            </div>
          </button>
        </div>
      </div>

      {/* Recent Prompts & Favorites */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Prompts */}
        <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-gray-800 pb-3">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-purple-400" />
              <h3 className="font-bold text-sm text-white">Senaste Prompterna ({prompts.length})</h3>
            </div>
            <button
              onClick={() => onNavigate('history')}
              className="text-xs text-sky-400 hover:text-sky-300 font-medium"
            >
              Visa alla →
            </button>
          </div>

          {recentPrompts.length === 0 ? (
            <div className="py-8 text-center text-xs text-gray-500">
              Inga sparade prompter än. Skapa din första prompt i Builder!
            </div>
          ) : (
            <div className="space-y-2.5">
              {recentPrompts.map((p) => (
                <div
                  key={p.id}
                  className="rounded-xl border border-gray-800/80 bg-gray-950/60 p-3 hover:border-gray-700 transition"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div
                      className="cursor-pointer flex-1"
                      onClick={() => {
                        onSelectPrompt(p);
                        onNavigate('prompt-builder');
                      }}
                    >
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-xs text-white hover:text-sky-400 transition truncate">
                          {p.title}
                        </span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-gray-800 text-gray-400 uppercase">
                          {p.type}
                        </span>
                      </div>
                      <p className="text-xs text-gray-400 line-clamp-2 mt-1 font-mono">
                        {p.prompt}
                      </p>
                    </div>

                    <button
                      onClick={() => handleCopy(p.id, p.prompt)}
                      className="p-1.5 text-gray-400 hover:text-white rounded-lg hover:bg-gray-800 transition min-h-[36px] min-w-[36px] flex items-center justify-center shrink-0"
                      title="Kopiera prompt"
                    >
                      {copiedId === p.id ? (
                        <Check className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Favorites & Stats */}
        <div className="space-y-4">
          <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-gray-800 pb-3">
              <div className="flex items-center gap-2">
                <Bookmark className="w-4 h-4 text-amber-400" />
                <h3 className="font-bold text-sm text-white">Favoriter ({favoritePrompts.length})</h3>
              </div>
              <button
                onClick={() => onNavigate('favorites')}
                className="text-xs text-sky-400 hover:text-sky-300 font-medium"
              >
                Hantera →
              </button>
            </div>

            {favoritePrompts.length === 0 ? (
              <div className="py-8 text-center text-xs text-gray-500">
                Stjärnmärk prompter för att spara dem i dina favoriter!
              </div>
            ) : (
              <div className="space-y-2">
                {favoritePrompts.slice(0, 3).map((f) => (
                  <div
                    key={f.id}
                    onClick={() => {
                      onSelectPrompt(f);
                      onNavigate('prompt-builder');
                    }}
                    className="cursor-pointer rounded-xl border border-gray-800/80 bg-gray-950/60 p-3 hover:border-gray-700 transition"
                  >
                    <div className="font-semibold text-xs text-white truncate">{f.title}</div>
                    <p className="text-xs text-gray-400 line-clamp-1 mt-0.5">{f.prompt}</p>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* System & Storage Status */}
          <div className="rounded-2xl border border-gray-800 bg-gray-950/60 p-4 flex items-center justify-between text-xs text-gray-400">
            <div className="flex items-center gap-2.5">
              <HardDrive className="w-4 h-4 text-purple-400" />
              <div>
                <span className="font-semibold text-gray-200 block">Lokal Datalagring</span>
                <span>IndexedDB aktiv • Autosparning på</span>
              </div>
            </div>
            <button
              onClick={() => onNavigate('storage-manager')}
              className="text-sky-400 hover:text-sky-300 font-medium"
            >
              Inspektera →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
