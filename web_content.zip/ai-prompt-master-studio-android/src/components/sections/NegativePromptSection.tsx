import React, { useState } from 'react';
import { PromptItem } from '../../types';
import {
  ShieldBan,
  Plus,
  X,
  Copy,
  Check,
  Save,
  Camera,
  Film,
  RotateCcw,
} from 'lucide-react';

interface Props {
  onSavePrompt: (prompt: PromptItem) => void;
}

const DEFAULT_IMAGE_TERMS = [
  'blurry', 'low resolution', 'distorted anatomy', 'extra fingers', 'deformed face',
  'duplicate objects', 'visual artifacts', 'bad composition', 'oversaturated',
  'watermark', 'unwanted text', 'poorly drawn hands', 'amateur photo', 'mutation', 'bad eyes'
];

const DEFAULT_VIDEO_TERMS = [
  'flickering', 'unnatural movement', 'camera shake', 'temporal inconsistency',
  'motion artifacts', 'warped objects', 'duplicate subjects', 'unstable lighting',
  'sudden scene changes', 'jump cuts', 'jittery frames', 'morphing faces'
];

export const NegativePromptSection: React.FC<Props> = ({ onSavePrompt }) => {
  const [targetType, setTargetType] = useState<'image' | 'video'>('image');
  const [selectedTerms, setSelectedTerms] = useState<string[]>(DEFAULT_IMAGE_TERMS);
  const [customTerm, setCustomTerm] = useState('');
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSwitchType = (type: 'image' | 'video') => {
    setTargetType(type);
    setSelectedTerms(type === 'image' ? DEFAULT_IMAGE_TERMS : DEFAULT_VIDEO_TERMS);
  };

  const handleToggleTerm = (term: string) => {
    if (selectedTerms.includes(term)) {
      setSelectedTerms(selectedTerms.filter((t) => t !== term));
    } else {
      setSelectedTerms([...selectedTerms, term]);
    }
  };

  const handleAddCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTerm.trim()) return;
    const clean = customTerm.trim().toLowerCase();
    if (!selectedTerms.includes(clean)) {
      setSelectedTerms([...selectedTerms, clean]);
    }
    setCustomTerm('');
  };

  const handleReset = () => {
    setSelectedTerms(targetType === 'image' ? DEFAULT_IMAGE_TERMS : DEFAULT_VIDEO_TERMS);
  };

  const composedNegative = selectedTerms.join(', ');

  const handleCopy = () => {
    navigator.clipboard.writeText(composedNegative);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSave = () => {
    const item: PromptItem = {
      id: `negative-${Date.now()}`,
      title: `Negativ Prompt (${targetType === 'image' ? 'Bild' : 'Video'})`,
      category: 'Negative Prompts',
      type: targetType,
      prompt: '',
      negativePrompt: composedNegative,
      tags: ['negative', targetType],
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    onSavePrompt(item);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="border-b border-gray-800 pb-4">
        <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
          <ShieldBan className="w-5 h-5 text-rose-400" />
          Negative Prompt Generator
        </h1>
        <p className="text-xs text-gray-400 mt-1">
          Eliminera artefakter, förvrängda extremiteter, flimmer och oskärpa i bild- och videogenerering.
        </p>
      </div>

      {/* Type Toggle & Reset */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex rounded-xl bg-gray-950 p-1 border border-gray-800">
          <button
            onClick={() => handleSwitchType('image')}
            className={`flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition min-h-[38px] ${
              targetType === 'image'
                ? 'bg-rose-600 text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            Bildnegativ ({DEFAULT_IMAGE_TERMS.length})
          </button>
          <button
            onClick={() => handleSwitchType('video')}
            className={`flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition min-h-[38px] ${
              targetType === 'video'
                ? 'bg-sky-600 text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Film className="w-3.5 h-3.5" />
            Videonegativ ({DEFAULT_VIDEO_TERMS.length})
          </button>
        </div>

        <button
          onClick={handleReset}
          className="flex items-center gap-1.5 rounded-xl border border-gray-800 bg-gray-900/80 px-3 py-2 text-xs text-gray-400 hover:text-white transition min-h-[44px]"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Återställ standardtermer</span>
        </button>
      </div>

      {/* Term Selector Chips */}
      <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-5 space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-gray-300 uppercase tracking-wider">
            Klicka för att aktivera / avaktivera termer ({selectedTerms.length} aktiva)
          </span>
        </div>

        <div className="flex flex-wrap gap-2">
          {selectedTerms.map((term) => (
            <button
              key={term}
              onClick={() => handleToggleTerm(term)}
              className="flex items-center gap-1.5 rounded-xl border border-rose-500/40 bg-rose-950/40 px-3 py-1.5 text-xs font-medium text-rose-200 hover:bg-rose-900/40 transition min-h-[38px]"
            >
              <span>{term}</span>
              <X className="w-3.5 h-3.5 text-rose-400" />
            </button>
          ))}
        </div>

        {/* Add custom term input */}
        <form onSubmit={handleAddCustom} className="flex gap-2 pt-2 border-t border-gray-800/80">
          <input
            type="text"
            value={customTerm}
            onChange={(e) => setCustomTerm(e.target.value)}
            placeholder="Lägg till egen negativ term (t.ex. plastic glossy skin, modern wristwatch)..."
            className="flex-1 rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white placeholder-gray-500 focus:border-rose-500 focus:outline-none min-h-[44px]"
          />
          <button
            type="submit"
            className="flex items-center gap-1.5 rounded-xl bg-gray-800 px-4 py-2 text-xs font-semibold text-white hover:bg-gray-700 transition min-h-[44px]"
          >
            <Plus className="w-4 h-4" />
            <span>Lägg till</span>
          </button>
        </form>
      </div>

      {/* Result Display */}
      <div className="rounded-2xl border border-rose-500/30 bg-rose-950/20 p-5 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-rose-300 uppercase tracking-wider">
            Genererad Negativ Master Prompt
          </span>
          <span className="text-xs text-gray-400 font-mono">
            {selectedTerms.length} termer
          </span>
        </div>

        <div className="rounded-xl border border-gray-800 bg-gray-950 p-4">
          <p className="text-xs sm:text-sm text-rose-200/90 font-mono leading-relaxed select-all">
            {composedNegative || 'Inga negativa termer valda.'}
          </p>
        </div>

        <div className="flex items-center gap-2 pt-2">
          <button
            onClick={handleCopy}
            className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gray-800 px-4 py-2.5 text-xs font-semibold text-white hover:bg-gray-700 active:scale-95 transition min-h-[44px]"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Kopierad!' : 'Kopiera Negativ Prompt'}</span>
          </button>

          <button
            onClick={handleSave}
            className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-rose-600 to-indigo-600 px-4 py-2.5 text-xs font-semibold text-white hover:brightness-110 active:scale-95 transition min-h-[44px]"
          >
            {saved ? <Check className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
            <span>{saved ? 'Sparad!' : 'Spara Negativ Prompt'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
