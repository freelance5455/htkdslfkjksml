import React, { useState } from 'react';
import { AIMode, StoryboardProject, StoryboardScene } from '../../types';
import { localPromptEngine, NEGATIVE_VIDEO_DEFAULTS } from '../../services/localEngine';
import { geminiService } from '../../services/geminiService';
import { storageService } from '../../services/storage';
import {
  Film,
  Plus,
  Trash2,
  Copy,
  ChevronUp,
  ChevronDown,
  Edit2,
  Sparkles,
  Download,
  Save,
  Check,
  RefreshCw,
} from 'lucide-react';

interface Props {
  aiMode: AIMode;
  onNavigate: (section: string) => void;
}

export const StoryboardSection: React.FC<Props> = ({ aiMode }) => {
  const [concept, setConcept] = useState('En detektiv jagar en mystisk skepnad genom ett regnigt cyberpunk-Stockholm');
  const [sceneCount, setSceneCount] = useState(6);
  const [visualStyle, setVisualStyle] = useState('Cinematic 35mm film still');
  const [isGenerating, setIsGenerating] = useState(false);
  const [storyboard, setStoryboard] = useState<StoryboardProject | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [editingSceneId, setEditingSceneId] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!concept.trim()) return;
    setIsGenerating(true);

    try {
      let scenes: StoryboardScene[] = [];
      if (aiMode === 'gemini') {
        const rawScenes = await geminiService.storyboard(concept, sceneCount, visualStyle, 'sv');
        scenes = rawScenes.map((s: any, idx: number) => ({
          id: `scene-${Date.now()}-${idx}`,
          sceneNumber: idx + 1,
          title: s.title || `Scen ${idx + 1}`,
          description: s.description || '',
          subject: s.subject || '',
          action: s.action || '',
          environment: s.environment || '',
          timeAndWeather: s.timeAndWeather || '',
          cameraAngle: s.cameraAngle || 'Medium Shot',
          cameraMovement: s.cameraMovement || 'Tracking Shot',
          lighting: s.lighting || 'Cinematic Lighting',
          colorPalette: s.colorPalette || 'Teal and orange',
          startFramePrompt: s.startFramePrompt || '',
          endFramePrompt: s.endFramePrompt || '',
          videoPrompt: s.videoPrompt || '',
          negativePrompt: s.negativePrompt || NEGATIVE_VIDEO_DEFAULTS.slice(0, 8).join(', '),
          continuityNotes: s.continuityNotes || 'Bevara karaktärens klädsel och färgpalett',
          durationSeconds: 5,
        }));
      } else {
        const rawScenes = localPromptEngine.generateLocalStoryboard(concept, sceneCount, visualStyle);
        scenes = rawScenes.map((s: any, idx: number) => ({
          ...s,
          id: `scene-local-${Date.now()}-${idx}`,
        }));
      }

      const project: StoryboardProject = {
        id: `sb-${Date.now()}`,
        title: `Storyboard: ${concept.slice(0, 35)}`,
        concept,
        style: visualStyle,
        scenes,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };

      setStoryboard(project);
    } catch (err) {
      console.warn('Storyboard generation failed, using local engine fallback:', err);
      const rawScenes = localPromptEngine.generateLocalStoryboard(concept, sceneCount, visualStyle);
      const scenes = rawScenes.map((s: any, idx: number) => ({
        ...s,
        id: `scene-local-${Date.now()}-${idx}`,
      }));
      setStoryboard({
        id: `sb-${Date.now()}`,
        title: `Storyboard: ${concept.slice(0, 35)}`,
        concept,
        style: visualStyle,
        scenes,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleAddScene = () => {
    if (!storyboard) return;
    const newNum = storyboard.scenes.length + 1;
    const newScene: StoryboardScene = {
      id: `scene-custom-${Date.now()}`,
      sceneNumber: newNum,
      title: `${newNum}. Ny Scen`,
      description: 'Scenbeskrivning',
      subject: 'Huvudkaraktär',
      action: 'Handling och rörelse',
      environment: 'Miljö och plats',
      timeAndWeather: 'Tid och väder',
      cameraAngle: 'Eye-level Medium Shot',
      cameraMovement: 'Slow Tracking',
      lighting: 'Volumetric cinematic light',
      colorPalette: 'Consistent LUT',
      startFramePrompt: 'Startframe prompt',
      endFramePrompt: 'Endframe prompt',
      videoPrompt: 'Färdig videoprompt',
      negativePrompt: NEGATIVE_VIDEO_DEFAULTS.slice(0, 8).join(', '),
      continuityNotes: 'Bevara kontinuitetsankare',
      durationSeconds: 5,
    };
    setStoryboard({
      ...storyboard,
      scenes: [...storyboard.scenes, newScene],
    });
  };

  const handleDeleteScene = (id: string) => {
    if (!storyboard) return;
    const updated = storyboard.scenes
      .filter((s) => s.id !== id)
      .map((s, idx) => ({ ...s, sceneNumber: idx + 1 }));
    setStoryboard({ ...storyboard, scenes: updated });
  };

  const handleMove = (index: number, direction: 'up' | 'down') => {
    if (!storyboard) return;
    const target = direction === 'up' ? index - 1 : index + 1;
    if (target < 0 || target >= storyboard.scenes.length) return;

    const newScenes = [...storyboard.scenes];
    const temp = newScenes[index];
    newScenes[index] = newScenes[target];
    newScenes[target] = temp;

    const renumbered = newScenes.map((s, idx) => ({ ...s, sceneNumber: idx + 1 }));
    setStoryboard({ ...storyboard, scenes: renumbered });
  };

  const handleDuplicateScene = (index: number) => {
    if (!storyboard) return;
    const item = storyboard.scenes[index];
    const copy: StoryboardScene = {
      ...item,
      id: `scene-dup-${Date.now()}`,
      title: `${item.title} (Kopia)`,
    };
    const newScenes = [...storyboard.scenes];
    newScenes.splice(index + 1, 0, copy);
    const renumbered = newScenes.map((s, idx) => ({ ...s, sceneNumber: idx + 1 }));
    setStoryboard({ ...storyboard, scenes: renumbered });
  };

  const handleCopyPrompt = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSaveStoryboard = async () => {
    if (!storyboard) return;
    await storageService.saveStoryboard(storyboard);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  const handleExportJSON = () => {
    if (!storyboard) return;
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(storyboard, null, 2));
    const a = document.createElement('a');
    a.href = dataStr;
    a.download = `storyboard-${storyboard.id}.json`;
    a.click();
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-800 pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
            <Film className="w-5 h-5 text-pink-400" />
            Storyboard Creator
          </h1>
          <p className="text-xs text-gray-400 mt-1">
            Skapa och hantera 5–20 sammanhängande filmscener med garanterad stil- och karaktärskontinuitet.
          </p>
        </div>

        {storyboard && (
          <div className="flex items-center gap-2">
            <button
              onClick={handleSaveStoryboard}
              className="flex items-center gap-1.5 rounded-xl bg-purple-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-purple-500 transition min-h-[44px]"
            >
              {savedSuccess ? <Check className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
              <span>{savedSuccess ? 'Sparad!' : 'Spara Storyboard'}</span>
            </button>
            <button
              onClick={handleExportJSON}
              className="flex items-center gap-1.5 rounded-xl border border-gray-800 bg-gray-900 px-3 py-2 text-xs font-semibold text-gray-300 hover:text-white hover:bg-gray-800 transition min-h-[44px]"
            >
              <Download className="w-4 h-4" />
              <span>Exportera</span>
            </button>
          </div>
        )}
      </div>

      {/* Generator Input Bar */}
      <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 sm:p-5 space-y-3">
        <label className="text-xs font-bold text-gray-200 uppercase tracking-wider block">
          Filmidé för Storyboard:
        </label>
        <textarea
          value={concept}
          onChange={(e) => setConcept(e.target.value)}
          placeholder="Ex: En rymdfarare kraschlandar på en istäckt måne och söker skydd..."
          rows={2}
          className="w-full rounded-xl border border-gray-800 bg-gray-950 p-3 text-xs sm:text-sm text-white focus:border-pink-500 focus:outline-none"
        />

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          <div>
            <label className="text-[11px] font-semibold text-gray-400 block mb-1">Antal scener (5–20)</label>
            <select
              value={sceneCount}
              onChange={(e) => setSceneCount(Number(e.target.value))}
              className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:border-pink-500 focus:outline-none min-h-[44px]"
            >
              {[5, 6, 8, 10, 12, 16, 20].map((n) => (
                <option key={n} value={n}>
                  {n} Scener
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[11px] font-semibold text-gray-400 block mb-1">Visuell Stil</label>
            <input
              type="text"
              value={visualStyle}
              onChange={(e) => setVisualStyle(e.target.value)}
              className="w-full rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:border-pink-500 focus:outline-none min-h-[44px]"
            />
          </div>

          <div className="flex items-end">
            <button
              onClick={handleGenerate}
              disabled={isGenerating || !concept.trim()}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 px-4 py-2 text-xs font-extrabold text-white shadow-lg hover:brightness-110 active:scale-95 transition disabled:opacity-50 min-h-[44px]"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Genererar {sceneCount} scener...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Generera Storyboard ({aiMode === 'gemini' ? 'Gemini AI' : 'Local Mode'})</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Storyboard Scenes Grid */}
      {storyboard && (
        <div className="space-y-4 animate-in fade-in duration-300">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-300 uppercase tracking-wider">
              Scenöversikt ({storyboard.scenes.length} scener)
            </span>
            <button
              onClick={handleAddScene}
              className="flex items-center gap-1.5 rounded-xl border border-pink-500/40 bg-pink-950/40 px-3 py-1.5 text-xs font-semibold text-pink-300 hover:bg-pink-900/40 transition min-h-[38px]"
            >
              <Plus className="w-4 h-4" />
              <span>Lägg till Scen</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {storyboard.scenes.map((scene, idx) => (
              <div
                key={scene.id}
                className="rounded-2xl border border-gray-800 bg-gray-900/80 p-4 space-y-3 shadow-lg relative group"
              >
                {/* Scene Header */}
                <div className="flex items-center justify-between border-b border-gray-800 pb-2.5">
                  <div className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-pink-500/20 text-pink-300 text-xs font-extrabold border border-pink-500/30">
                      {scene.sceneNumber}
                    </span>
                    <span className="font-bold text-xs sm:text-sm text-white truncate max-w-[180px]">
                      {scene.title}
                    </span>
                  </div>

                  {/* Scene Control Buttons */}
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleMove(idx, 'up')}
                      disabled={idx === 0}
                      className="p-1 text-gray-400 hover:text-white disabled:opacity-30"
                      title="Flytta upp"
                    >
                      <ChevronUp className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleMove(idx, 'down')}
                      disabled={idx === storyboard.scenes.length - 1}
                      className="p-1 text-gray-400 hover:text-white disabled:opacity-30"
                      title="Flytta ned"
                    >
                      <ChevronDown className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDuplicateScene(idx)}
                      className="p-1 text-gray-400 hover:text-white"
                      title="Duplicera scen"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDeleteScene(scene.id)}
                      className="p-1 text-gray-400 hover:text-rose-400"
                      title="Radera scen"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Narrative Description & Camera */}
                <p className="text-xs text-gray-300 leading-relaxed">{scene.description}</p>

                <div className="grid grid-cols-2 gap-2 text-[11px] text-gray-400 bg-gray-950/60 p-2.5 rounded-xl border border-gray-800/80">
                  <div>
                    <span className="text-gray-500 block">Kamerarörelse:</span>
                    <span className="text-gray-200 font-medium">{scene.cameraMovement}</span>
                  </div>
                  <div>
                    <span className="text-gray-500 block">Kameravinkel:</span>
                    <span className="text-gray-200 font-medium">{scene.cameraAngle}</span>
                  </div>
                  <div>
                    <span className="text-gray-500 block">Ljussättning:</span>
                    <span className="text-gray-200 font-medium truncate">{scene.lighting}</span>
                  </div>
                  <div>
                    <span className="text-gray-500 block">Kontinuitet:</span>
                    <span className="text-pink-300 font-medium truncate">{scene.continuityNotes}</span>
                  </div>
                </div>

                {/* Video Prompt */}
                <div className="rounded-xl border border-gray-800 bg-gray-950 p-2.5 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-sky-400 uppercase tracking-wider">
                      Genererad Videoprompt:
                    </span>
                    <button
                      onClick={() => handleCopyPrompt(scene.id, scene.videoPrompt)}
                      className="flex items-center gap-1 text-[11px] text-gray-400 hover:text-white"
                    >
                      {copiedId === scene.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                      <span>{copiedId === scene.id ? 'Kopierad' : 'Kopiera'}</span>
                    </button>
                  </div>
                  <p className="text-xs text-gray-200 font-mono select-all line-clamp-3">
                    {scene.videoPrompt}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
