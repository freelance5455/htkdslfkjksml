import React, { useState, useRef } from 'react';
import { PromptItem, Project } from '../../types';
import { storageService } from '../../services/storage';
import {
  FileDown,
  Upload,
  FileText,
  Check,
  AlertTriangle,
  FolderArchive,
  Download,
} from 'lucide-react';

interface Props {
  prompts: PromptItem[];
  projects: Project[];
  onRefreshData: () => void;
}

export const ImportExportSection: React.FC<Props> = ({
  prompts,
  projects,
  onRefreshData,
}) => {
  const [exportFormat, setExportFormat] = useState<'json' | 'txt' | 'md'>('json');
  const [selectedPrompts, setSelectedPrompts] = useState<string[]>([]);
  const [importStatus, setImportStatus] = useState<{ text: string; success: boolean } | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleSelectAll = () => {
    if (selectedPrompts.length === prompts.length) {
      setSelectedPrompts([]);
    } else {
      setSelectedPrompts(prompts.map((p) => p.id));
    }
  };

  const handleToggleSelect = (id: string) => {
    if (selectedPrompts.includes(id)) {
      setSelectedPrompts(selectedPrompts.filter((p) => p !== id));
    } else {
      setSelectedPrompts([...selectedPrompts, id]);
    }
  };

  const handleExportSelected = () => {
    const toExport = prompts.filter((p) => selectedPrompts.includes(p.id));
    if (toExport.length === 0) return;

    let content = '';
    let mime = 'application/json';
    let ext = 'json';

    if (exportFormat === 'json') {
      content = JSON.stringify(toExport, null, 2);
      mime = 'application/json';
      ext = 'json';
    } else if (exportFormat === 'md') {
      mime = 'text/markdown';
      ext = 'md';
      content = `# AI Prompt Master Studio - Exporterade Prompter\n\nGenererad: ${new Date().toLocaleString()}\n\n` +
        toExport.map((p, i) => `## ${i + 1}. ${p.title} (${p.category})\n**Typ:** ${p.type} | **Plattform:** ${p.platform || 'General'}\n\n\`\`\`\n${p.prompt}\n\`\`\`\n\n${p.negativePrompt ? `**Negativ Prompt:**\n\`\`\`\n${p.negativePrompt}\n\`\`\`\n` : ''}---\n`).join('\n');
    } else {
      mime = 'text/plain';
      ext = 'txt';
      content = toExport.map((p, i) => `[${i + 1}] ${p.title}\nPROMPT: ${p.prompt}\n${p.negativePrompt ? `NEGATIV: ${p.negativePrompt}\n` : ''}\n-----------------------------------\n`).join('\n');
    }

    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `exported-prompts-${new Date().toISOString().slice(0, 10)}.${ext}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      const content = event.target?.result as string;
      try {
        const res = await storageService.importFullBackup(content);
        if (res.success) {
          setImportStatus({ text: `Lyckades importera ${res.count} objekt!`, success: true });
          onRefreshData();
        } else {
          setImportStatus({ text: `Importfel: ${res.error}`, success: false });
        }
      } catch (err: any) {
        setImportStatus({ text: `Ogiltigt filformat: ${err.message}`, success: false });
      }
      setTimeout(() => setImportStatus(null), 4000);
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="border-b border-gray-800 pb-4">
        <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
          <FileDown className="w-5 h-5 text-sky-400" />
          Import & Export Center
        </h1>
        <p className="text-xs text-gray-400 mt-1">
          Exportera prompter som JSON, ren text (TXT) eller Markdown (MD). Importera säkerhetskopior med strikt schema-validering.
        </p>
      </div>

      {importStatus && (
        <div
          className={`p-3.5 rounded-xl border text-xs font-semibold flex items-center gap-2 animate-in fade-in ${
            importStatus.success
              ? 'border-emerald-500/40 bg-emerald-950/40 text-emerald-300'
              : 'border-rose-500/40 bg-rose-950/40 text-rose-300'
          }`}
        >
          {importStatus.success ? <Check className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
          <span>{importStatus.text}</span>
        </div>
      )}

      {/* Import Section */}
      <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-5 space-y-3">
        <span className="text-xs font-bold text-gray-200 uppercase tracking-wider block">
          Importera Data (JSON Säkerhetskopia)
        </span>
        <div
          onClick={() => fileInputRef.current?.click()}
          className="cursor-pointer flex flex-col items-center justify-center rounded-xl border border-dashed border-gray-700 bg-gray-950/60 p-6 text-center hover:border-sky-500 transition"
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept=".json"
            className="hidden"
          />
          <Upload className="w-8 h-8 text-sky-400 mb-2" />
          <span className="text-xs font-semibold text-white">Välj en JSON-fil från din dator</span>
          <span className="text-[10px] text-gray-500 mt-0.5">Alla objekt valideras innan de sparas i IndexedDB</span>
        </div>
      </div>

      {/* Export Section */}
      <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-gray-800 pb-3">
          <span className="text-xs font-bold text-gray-200 uppercase tracking-wider">
            Exportera Prompter ({selectedPrompts.length}/{prompts.length} markerade)
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSelectAll}
              className="text-xs text-sky-400 hover:text-sky-300 font-medium"
            >
              {selectedPrompts.length === prompts.length ? 'Avmarkera alla' : 'Markera alla'}
            </button>
            <div className="flex rounded-lg bg-gray-950 p-1 border border-gray-800">
              {(['json', 'txt', 'md'] as const).map((fmt) => (
                <button
                  key={fmt}
                  onClick={() => setExportFormat(fmt)}
                  className={`px-2.5 py-1 text-xs font-bold uppercase rounded-md transition ${
                    exportFormat === fmt ? 'bg-sky-600 text-white' : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {fmt}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* List of prompts to select */}
        <div className="max-h-60 overflow-y-auto space-y-1.5 pr-1">
          {prompts.map((p) => {
            const isChecked = selectedPrompts.includes(p.id);
            return (
              <div
                key={p.id}
                onClick={() => handleToggleSelect(p.id)}
                className={`cursor-pointer flex items-center justify-between p-2.5 rounded-xl border text-xs transition ${
                  isChecked
                    ? 'border-sky-500/50 bg-sky-950/20 text-white'
                    : 'border-gray-800 bg-gray-950/40 text-gray-400 hover:border-gray-700'
                }`}
              >
                <div className="flex items-center gap-2.5 truncate">
                  <input
                    type="checkbox"
                    checked={isChecked}
                    onChange={() => {}}
                    className="rounded border-gray-700 text-sky-600"
                  />
                  <span className="font-semibold text-gray-200 truncate">{p.title}</span>
                </div>
                <span className="text-[10px] text-gray-500 uppercase shrink-0">{p.type}</span>
              </div>
            );
          })}
        </div>

        <button
          onClick={handleExportSelected}
          disabled={selectedPrompts.length === 0}
          className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 p-3.5 text-xs sm:text-sm font-extrabold text-white shadow-lg hover:brightness-110 active:scale-95 transition disabled:opacity-40 min-h-[48px]"
        >
          <Download className="w-4 h-4" />
          <span>Ladda ned {selectedPrompts.length} prompter som .{exportFormat.toUpperCase()}</span>
        </button>
      </div>
    </div>
  );
};
