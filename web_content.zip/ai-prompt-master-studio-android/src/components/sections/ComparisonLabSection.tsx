import React, { useState } from 'react';
import { AIMode, PromptItem } from '../../types';
import { evaluatePromptQuality } from '../../services/qualityScorer';
import { geminiService } from '../../services/geminiService';
import {
  GitCompare,
  Plus,
  Trash2,
  Sparkles,
  Copy,
  Check,
  Save,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
} from 'lucide-react';

interface Props {
  aiMode: AIMode;
  onSavePrompt: (prompt: PromptItem) => void;
  onNavigate: (section: string) => void;
}

export const ComparisonLabSection: React.FC<Props> = ({ aiMode, onSavePrompt }) => {
  const [prompts, setPrompts] = useState<string[]>([
    'A cyberpunk samurai walking in neo tokyo in heavy rain, neon lights, 35mm film still, sharp focus.',
    'Cinematic wide shot of a futuristic cyborg warrior with glowing katana standing on a wet Shibuya rooftop, volumetric god rays, Hasselblad H6D, award winning photography.',
  ]);

  const [isComparing, setIsComparing] = useState(false);
  const [comparisonResult, setComparisonResult] = useState<{
    common: string[];
    missing: string[];
    hybridPrompt: string;
    scores: number[];
  } | null>(null);

  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleAddPrompt = () => {
    if (prompts.length >= 5) return;
    setPrompts([...prompts, '']);
  };

  const handleRemovePrompt = (idx: number) => {
    if (prompts.length <= 2) return;
    setPrompts(prompts.filter((_, i) => i !== idx));
  };

  const handleUpdatePrompt = (idx: number, val: string) => {
    const arr = [...prompts];
    arr[idx] = val;
    setPrompts(arr);
  };

  const handleRunComparison = async () => {
    const valid = prompts.filter((p) => p.trim());
    if (valid.length < 2) return;
    setIsComparing(true);

    try {
      const scores = valid.map((p) => evaluatePromptQuality(p).totalScore);

      if (aiMode === 'gemini') {
        const res = await geminiService.comparePrompts(valid, 'sv');
        setComparisonResult({
          common: res.commonElements || ['Neonbelysning', 'Cyberpunk-estetik'],
          missing: res.missingElements || ['Exakta objektivbländare', 'Mikrotexturer'],
          hybridPrompt: res.synthesisMasterPrompt || `${valid[0]} with elements of ${valid[1]}`,
          scores,
        });
      } else {
        // Local synthesis
        const hybrid = `${valid[0].trim()}, blended with ${valid[1].trim()}, 8k resolution, volumetric chiaroscuro lighting, master composition.`;
        setComparisonResult({
          common: ['Gemensamt fokus på futuristisk karaktär och stämningsfullt ljus'],
          missing: ['Saknar objektivspecifikation (t.ex. 85mm f/1.4)', 'Ingen explicit negativ prompt'],
          hybridPrompt: hybrid,
          scores,
        });
      }
    } catch {
      const scores = valid.map((p) => evaluatePromptQuality(p).totalScore);
      setComparisonResult({
        common: ['Gemensamma visuella element identifierade'],
        missing: ['Optiska specifikationer'],
        hybridPrompt: `${valid[0]}, ${valid[1]}`,
        scores,
      });
    } finally {
      setIsComparing(false);
    }
  };

  const handleCopyHybrid = () => {
    if (!comparisonResult) return;
    navigator.clipboard.writeText(comparisonResult.hybridPrompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSaveHybrid = () => {
    if (!comparisonResult) return;
    const item: PromptItem = {
      id: `compare-hybrid-${Date.now()}`,
      title: 'Syntetiserad Hybrid Prompt',
      category: 'Comparison Lab',
      type: 'image',
      prompt: comparisonResult.hybridPrompt,
      tags: ['hybrid', 'comparison', 'synthesized'],
      createdAt: Date.now(),
      updatedAt: Date.now(),
      modeUsed: aiMode,
    };
    onSavePrompt(item);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-800 pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
            <GitCompare className="w-5 h-5 text-indigo-400" />
            Prompt Comparison Lab
          </h1>
          <p className="text-xs text-gray-400 mt-1">
            Jämför 2 till 5 prompter sida vid sida och sammanfoga de starkaste komponenterna till en överlägsen hybridprompt.
          </p>
        </div>

        {prompts.length < 5 && (
          <button
            onClick={handleAddPrompt}
            className="flex items-center gap-1.5 rounded-xl border border-gray-800 bg-gray-900 px-3.5 py-2 text-xs font-semibold text-gray-200 hover:text-white hover:bg-gray-800 transition min-h-[44px]"
          >
            <Plus className="w-4 h-4" />
            <span>Lägg till prompt ({prompts.length}/5)</span>
          </button>
        )}
      </div>

      {/* Prompts Side-by-Side Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {prompts.map((p, idx) => {
          const score = evaluatePromptQuality(p).totalScore;
          return (
            <div
              key={idx}
              className="rounded-2xl border border-gray-800 bg-gray-900/60 p-4 space-y-3 flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between border-b border-gray-800 pb-2">
                  <span className="font-bold text-xs text-sky-400 uppercase tracking-wider">
                    Prompt #{idx + 1}
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-emerald-400 font-mono">
                      {score}/100
                    </span>
                    {prompts.length > 2 && (
                      <button
                        onClick={() => handleRemovePrompt(idx)}
                        className="text-gray-500 hover:text-rose-400 p-1"
                        title="Ta bort"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                <textarea
                  value={p}
                  onChange={(e) => handleUpdatePrompt(idx, e.target.value)}
                  placeholder={`Skriv prompt #${idx + 1}...`}
                  rows={4}
                  className="w-full rounded-xl border border-gray-800 bg-gray-950 p-2.5 text-xs text-white placeholder-gray-500 focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div className="text-[11px] text-gray-400">
                Ord: {p.split(/\s+/).filter(Boolean).length} st
              </div>
            </div>
          );
        })}
      </div>

      {/* Compare Button */}
      <button
        onClick={handleRunComparison}
        disabled={isComparing || prompts.filter((p) => p.trim()).length < 2}
        className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 p-4 text-sm font-extrabold text-white shadow-xl hover:brightness-110 active:scale-95 transition disabled:opacity-50 min-h-[52px]"
      >
        <Sparkles className="w-5 h-5 text-sky-300" />
        <span>Kör djupgående jämförelse & Hybrid-syntes</span>
      </button>

      {/* Comparison Results */}
      {comparisonResult && (
        <div className="rounded-2xl border border-gray-800 bg-gray-900/80 p-5 space-y-4 animate-in fade-in duration-300">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="rounded-xl border border-sky-500/20 bg-sky-950/20 p-3.5 text-xs space-y-2">
              <span className="font-bold text-sky-300 flex items-center gap-1.5 uppercase tracking-wider text-[10px]">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Gemensamma element i prompterna:
              </span>
              <ul className="list-disc list-inside space-y-1 text-gray-300">
                {comparisonResult.common.map((c, i) => (
                  <li key={i}>{c}</li>
                ))}
              </ul>
            </div>

            <div className="rounded-xl border border-amber-500/20 bg-amber-950/20 p-3.5 text-xs space-y-2">
              <span className="font-bold text-amber-300 flex items-center gap-1.5 uppercase tracking-wider text-[10px]">
                <Lightbulb className="w-3.5 h-3.5" />
                Saknade nyckelkomponenter:
              </span>
              <ul className="list-disc list-inside space-y-1 text-gray-300">
                {comparisonResult.missing.map((m, i) => (
                  <li key={i}>{m}</li>
                ))}
              </ul>
            </div>
          </div>

          {/* Hybrid Master Prompt */}
          <div className="rounded-xl border border-purple-500/30 bg-purple-950/20 p-4 space-y-2">
            <span className="text-xs font-bold text-purple-300 uppercase tracking-wider block">
              Syntetiserad Hybrid Master Prompt:
            </span>
            <p className="text-xs sm:text-sm text-gray-100 font-mono leading-relaxed select-all">
              {comparisonResult.hybridPrompt}
            </p>
          </div>

          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={handleCopyHybrid}
              className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gray-800 px-4 py-2.5 text-xs font-semibold text-white hover:bg-gray-700 active:scale-95 transition min-h-[44px]"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Kopierad!' : 'Kopiera Hybrid Prompt'}</span>
            </button>

            <button
              onClick={handleSaveHybrid}
              className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-4 py-2.5 text-xs font-semibold text-white hover:brightness-110 active:scale-95 transition min-h-[44px]"
            >
              {saved ? <Check className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
              <span>{saved ? 'Sparad!' : 'Spara Hybrid Prompt'}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
