import React, { useState } from 'react';
import { AIMode, PromptItem } from '../../types';
import { localPromptEngine } from '../../services/localEngine';
import { geminiService } from '../../services/geminiService';
import {
  MessageSquareCode,
  Sparkles,
  ArrowRight,
  Check,
  Copy,
  Save,
  RotateCcw,
  SkipForward,
  FastForward,
  HelpCircle,
  RefreshCw,
} from 'lucide-react';

interface Props {
  aiMode: AIMode;
  onSavePrompt: (prompt: PromptItem) => void;
  onNavigate: (section: string) => void;
}

interface InterviewStep {
  questionNumber: number;
  question: string;
  category: string;
  options: string[];
  insight?: string;
  canFinalize?: boolean;
}

export const InterviewSection: React.FC<Props> = ({ aiMode, onSavePrompt }) => {
  const [idea, setIdea] = useState('En uråldrig trollkarl upptäcker en svävande kristallkula');
  const [stage, setStage] = useState<'initial' | 'interviewing' | 'summary' | 'finalized'>('initial');
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [customInput, setCustomInput] = useState('');
  const [currentQuestion, setCurrentQuestion] = useState<InterviewStep | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Final outputs
  const [summary, setSummary] = useState('');
  const [finalPrompt, setFinalPrompt] = useState('');
  const [finalNegative, setFinalNegative] = useState('');
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  const startInterview = async () => {
    if (!idea.trim()) return;
    setIsLoading(true);
    setAnswers({});
    setCurrentStepIndex(0);

    try {
      if (aiMode === 'gemini') {
        const q = await geminiService.interview(idea, [], 'next', 'sv');
        setCurrentQuestion(q);
      } else {
        const q = localPromptEngine.getLocalInterviewQuestion(0, idea, {});
        setCurrentQuestion(q);
      }
      setStage('interviewing');
    } catch {
      const q = localPromptEngine.getLocalInterviewQuestion(0, idea, {});
      setCurrentQuestion(q);
      setStage('interviewing');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAnswer = async (selectedOption?: string) => {
    const textToSave = selectedOption || customInput;
    if (!textToSave.trim() && !selectedOption) return;

    const nextAnswers = {
      ...answers,
      [currentQuestion?.question || `Fråga ${currentStepIndex + 1}`]: textToSave,
    };
    setAnswers(nextAnswers);
    setCustomInput('');

    // If step >= 3 or canFinalize, proceed to summary
    if (currentStepIndex >= 3 || currentQuestion?.canFinalize) {
      await finalizeInterview(nextAnswers);
      return;
    }

    const nextIndex = currentStepIndex + 1;
    setCurrentStepIndex(nextIndex);
    setIsLoading(true);

    try {
      if (aiMode === 'gemini') {
        const historyArr = Object.entries(nextAnswers).map(([q, a]) => ({ q, a }));
        const nextQ = await geminiService.interview(idea, historyArr, 'next', 'sv');
        setCurrentQuestion(nextQ);
      } else {
        const nextQ = localPromptEngine.getLocalInterviewQuestion(nextIndex, idea, nextAnswers);
        if (nextQ.isDone) {
          await finalizeInterview(nextAnswers);
        } else {
          setCurrentQuestion(nextQ);
        }
      }
    } catch {
      const nextQ = localPromptEngine.getLocalInterviewQuestion(nextIndex, idea, nextAnswers);
      if (nextQ.isDone) {
        await finalizeInterview(nextAnswers);
      } else {
        setCurrentQuestion(nextQ);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleSkip = async () => {
    const nextAnswers = {
      ...answers,
      [currentQuestion?.question || `Fråga ${currentStepIndex + 1}`]: '(Hoppades över)',
    };
    setAnswers(nextAnswers);
    if (currentStepIndex >= 3) {
      await finalizeInterview(nextAnswers);
      return;
    }
    const nextIndex = currentStepIndex + 1;
    setCurrentStepIndex(nextIndex);

    const nextQ = localPromptEngine.getLocalInterviewQuestion(nextIndex, idea, nextAnswers);
    if (nextQ.isDone) {
      await finalizeInterview(nextAnswers);
    } else {
      setCurrentQuestion(nextQ);
    }
  };

  const handleGenerateNow = async () => {
    await finalizeInterview(answers);
  };

  const finalizeInterview = async (allAnswers: Record<string, string>) => {
    setIsLoading(true);
    setStage('summary');

    try {
      if (aiMode === 'gemini') {
        const historyArr = Object.entries(allAnswers).map(([q, a]) => ({ q, a }));
        const res = await geminiService.interview(idea, historyArr, 'finalize', 'sv');
        setSummary(res.summary || 'Kreativ sammanfattning baserad på din vision.');
        setFinalPrompt(res.masterPrompt || '');
        setFinalNegative(res.negativePrompt || 'blurry, low quality, artifacts');
      } else {
        // Local synthesis
        const ansValues = Object.values(allAnswers).filter((v) => v !== '(Hoppades över)').join(', ');
        const master = `Masterpiece cinematic visualization: ${idea}. ${ansValues}. Shot on Hasselblad H6D, 85mm prime lens, volumetric golden hour illumination, 35mm film grain, 8k raw photo clarity.`;
        setSummary(`Baserat på dina svar om belysning, objektiv och stilar har vi sammanställt följande prompt.`);
        setFinalPrompt(master);
        setFinalNegative('blurry, low resolution, deformed anatomy, extra fingers, cartoonish, watermark');
      }
      setStage('finalized');
    } catch {
      const ansValues = Object.values(allAnswers).filter((v) => v !== '(Hoppades över)').join(', ');
      const master = `Masterpiece cinematic visualization: ${idea}. ${ansValues}. Shot on Hasselblad H6D, 85mm prime lens, volumetric illumination, 8k raw photo clarity.`;
      setSummary('Sammanfattning baserad på din vision.');
      setFinalPrompt(master);
      setFinalNegative('blurry, low resolution, deformed anatomy, extra fingers');
      setStage('finalized');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(finalPrompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSave = () => {
    const item: PromptItem = {
      id: `interview-${Date.now()}`,
      title: `AI Interview: ${idea.slice(0, 30)}`,
      category: 'AI Interview',
      type: 'image',
      prompt: finalPrompt,
      negativePrompt: finalNegative,
      tags: ['interview', 'synthesized', aiMode],
      createdAt: Date.now(),
      updatedAt: Date.now(),
      modeUsed: aiMode,
    };
    onSavePrompt(item);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const resetInterview = () => {
    setStage('initial');
    setAnswers({});
    setCurrentStepIndex(0);
    setCurrentQuestion(null);
    setFinalPrompt('');
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="border-b border-gray-800 pb-4">
        <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
          <MessageSquareCode className="w-5 h-5 text-sky-400" />
          Intelligent AI Interview
        </h1>
        <p className="text-xs text-gray-400 mt-1">
          En interaktiv regissörsintervju som identifierar saknade visuella detaljer fråga för fråga.
        </p>
      </div>

      {/* Stage 1: Initial Idea Input */}
      {stage === 'initial' && (
        <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-5 space-y-4 max-w-2xl">
          <label className="text-xs font-bold text-gray-200 uppercase tracking-wider block">
            Beskriv din kreativa grundidé:
          </label>
          <textarea
            value={idea}
            onChange={(e) => setIdea(e.target.value)}
            placeholder="Ex: En uråldrig trollkarl upptäcker en svävande kristallkula i en grotta..."
            rows={3}
            className="w-full rounded-xl border border-gray-800 bg-gray-950 p-3 text-sm text-white placeholder-gray-500 focus:border-sky-500 focus:outline-none"
          />

          <button
            onClick={startInterview}
            disabled={isLoading || !idea.trim()}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-sky-600 to-purple-600 p-4 text-sm font-extrabold text-white shadow-lg hover:brightness-110 active:scale-95 transition disabled:opacity-50 min-h-[48px]"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-5 h-5 animate-spin" />
                <span>Analyserar idé...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                <span>Starta Kreativ Intervju</span>
              </>
            )}
          </button>
        </div>
      )}

      {/* Stage 2: Interviewing Questions */}
      {stage === 'interviewing' && currentQuestion && (
        <div className="rounded-2xl border border-gray-800 bg-gray-900/80 p-5 space-y-5 max-w-2xl animate-in fade-in duration-200">
          {/* Progress bar */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs text-gray-400">
              <span className="font-semibold text-sky-400">
                Fråga {currentStepIndex + 1} av 4
              </span>
              <span>{currentQuestion.category}</span>
            </div>
            <div className="w-full bg-gray-800 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-sky-400 h-full rounded-full transition-all duration-300"
                style={{ width: `${((currentStepIndex + 1) / 4) * 100}%` }}
              />
            </div>
          </div>

          {/* Question Text */}
          <div className="space-y-1">
            <h3 className="text-base sm:text-lg font-bold text-white leading-snug">
              {currentQuestion.question}
            </h3>
            {currentQuestion.insight && (
              <p className="text-xs text-purple-300/80 italic">
                💡 {currentQuestion.insight}
              </p>
            )}
          </div>

          {/* Quick Option Buttons */}
          <div className="space-y-2">
            {currentQuestion.options.map((opt, i) => (
              <button
                key={i}
                onClick={() => handleAnswer(opt)}
                className="flex w-full items-center justify-between rounded-xl border border-gray-800 bg-gray-950 p-3.5 text-xs sm:text-sm text-left text-gray-200 hover:border-sky-500/50 hover:bg-gray-900 transition active:scale-[0.99] min-h-[48px]"
              >
                <span>{opt}</span>
                <ArrowRight className="w-4 h-4 text-gray-500 shrink-0 ml-2" />
              </button>
            ))}
          </div>

          {/* Custom Write-in Answer */}
          <div className="space-y-2 pt-2 border-t border-gray-800/80">
            <label className="text-[11px] font-semibold text-gray-400 block">
              Eller skriv eget anpassat svar:
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={customInput}
                onChange={(e) => setCustomInput(e.target.value)}
                placeholder="Skriv dina egna önskemål här..."
                className="flex-1 rounded-xl border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-white focus:border-sky-500 focus:outline-none min-h-[44px]"
              />
              <button
                onClick={() => handleAnswer()}
                disabled={!customInput.trim()}
                className="rounded-xl bg-sky-600 px-4 py-2 text-xs font-semibold text-white hover:bg-sky-500 disabled:opacity-40 transition min-h-[44px]"
              >
                Svara
              </button>
            </div>
          </div>

          {/* Control Bar: Skip & Generate Now */}
          <div className="flex items-center justify-between pt-3 border-t border-gray-800/80">
            <button
              onClick={handleSkip}
              className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white transition py-2"
            >
              <SkipForward className="w-4 h-4" />
              <span>Hoppa över denna fråga</span>
            </button>

            <button
              onClick={handleGenerateNow}
              className="flex items-center gap-1.5 rounded-xl border border-purple-500/40 bg-purple-950/40 px-3.5 py-2 text-xs font-semibold text-purple-300 hover:bg-purple-900/40 transition min-h-[44px]"
            >
              <FastForward className="w-4 h-4" />
              <span>Generera Nu</span>
            </button>
          </div>
        </div>
      )}

      {/* Stage 3: Finalized Prompt Synthesis */}
      {stage === 'finalized' && (
        <div className="rounded-2xl border border-gray-800 bg-gray-900/80 p-5 space-y-4 max-w-3xl animate-in fade-in duration-300">
          <div className="flex items-center justify-between border-b border-gray-800 pb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-sky-400" />
              <h3 className="font-bold text-base text-white">Syntetiserad Master Prompt</h3>
            </div>
            <button
              onClick={resetInterview}
              className="flex items-center gap-1 text-xs text-gray-400 hover:text-white"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Starta ny intervju</span>
            </button>
          </div>

          {summary && (
            <p className="text-xs text-gray-300 bg-gray-950/60 p-3 rounded-xl border border-gray-800">
              {summary}
            </p>
          )}

          {/* Editable master prompt */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-300">Färdig Prompt (Redigerbar):</label>
            <textarea
              value={finalPrompt}
              onChange={(e) => setFinalPrompt(e.target.value)}
              rows={4}
              className="w-full rounded-xl border border-gray-800 bg-gray-950 p-3.5 text-xs sm:text-sm text-gray-100 font-mono focus:border-sky-500 focus:outline-none"
            />
          </div>

          {/* Negative prompt */}
          <div className="rounded-xl border border-rose-500/20 bg-rose-950/20 p-3 space-y-1">
            <span className="text-[10px] font-bold text-rose-400 uppercase tracking-wider block">
              Negativ Prompt:
            </span>
            <p className="text-xs text-rose-200/90 font-mono select-all">{finalNegative}</p>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2 pt-2">
            <button
              onClick={handleCopy}
              className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gray-800 px-4 py-2.5 text-xs font-semibold text-white hover:bg-gray-700 active:scale-95 transition min-h-[44px]"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Kopierad!' : 'Kopiera prompt'}</span>
            </button>

            <button
              onClick={handleSave}
              className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-sky-600 to-purple-600 px-4 py-2.5 text-xs font-semibold text-white hover:brightness-110 active:scale-95 transition min-h-[44px]"
            >
              {saved ? <Check className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
              <span>{saved ? 'Sparad i Projekt!' : 'Spara Prompt'}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
