import { QualityScoreResult, MediaType } from '../types';

export function evaluatePromptQuality(
  prompt: string,
  mediaType: MediaType = 'image',
  negativePrompt?: string
): QualityScoreResult {
  const text = (prompt || '').toLowerCase();
  const neg = (negativePrompt || '').toLowerCase();

  // 1. Motiv (Subject) - Max 20
  let subjectScore = 0;
  const subjectKeywords = [
    'man', 'woman', 'kvinna', 'person', 'warrior', 'krigare', 'portrait', 'porträtt',
    'creature', 'varelse', 'robot', 'cyborg', 'animal', 'djur', 'cat', 'katt', 'dog', 'hund',
    'vehicle', 'fordon', 'car', 'bil', 'ship', 'skepp', 'spacecraft', 'building', 'byggnad',
    'castle', 'slott', 'temple', 'dragon', 'drake', 'face', 'ansikte', 'eyes', 'ögon',
    'hair', 'hår', 'clothing', 'kläder', 'jacket', 'armor', 'rustning', 'suit', 'dress'
  ];
  let subjectMatches = subjectKeywords.filter(k => text.includes(k)).length;
  if (text.length > 20) subjectScore += 6;
  if (subjectMatches >= 1) subjectScore += 8;
  if (subjectMatches >= 2 || text.length > 50) subjectScore += 6;
  subjectScore = Math.min(20, subjectScore);

  // 2. Handling (Action & Pose) - Max 15
  let actionScore = 0;
  const actionKeywords = [
    'walking', 'går', 'running', 'springer', 'standing', 'står', 'sitting', 'sitter',
    'looking', 'tittar', 'gazing', 'holding', 'håller', 'smiling', 'leende', 'fighting',
    'slåss', 'floating', 'svävar', 'flying', 'flyger', 'exploding', 'exploderar',
    'speaking', 'motion', 'rörelse', 'leaping', 'moving', 'turning', 'reaching'
  ];
  let actionMatches = actionKeywords.filter(k => text.includes(k)).length;
  if (actionMatches >= 1) actionScore += 8;
  if (actionMatches >= 2) actionScore += 5;
  if (mediaType === 'video' && (text.includes('seconds') || text.includes('camera move') || text.includes('pan') || text.includes('dolly'))) {
    actionScore += 2;
  } else if (mediaType === 'image' && actionMatches >= 1) {
    actionScore += 2;
  }
  actionScore = Math.min(15, actionScore);

  // 3. Miljö (Environment) - Max 15
  let envScore = 0;
  const envKeywords = [
    'street', 'gata', 'city', 'stad', 'forest', 'skog', 'mountains', 'berg', 'ocean', 'hav',
    'room', 'rum', 'studio', 'interior', 'interiör', 'exterior', 'exteriör', 'rain', 'regn',
    'snow', 'snö', 'fog', 'dimma', 'night', 'natt', 'day', 'dag', 'sunset', 'solnedgång',
    'dusk', 'skymning', 'cyberpunk', 'desert', 'öken', 'sci-fi', 'space', 'galaxy', 'beach', 'strand'
  ];
  let envMatches = envKeywords.filter(k => text.includes(k)).length;
  if (envMatches >= 1) envScore += 7;
  if (envMatches >= 2) envScore += 5;
  if (envMatches >= 3) envScore += 3;
  envScore = Math.min(15, envScore);

  // 4. Visuell stil (Visual Style) - Max 10
  let styleScore = 0;
  const styleKeywords = [
    'photorealistic', 'fotorealistisk', 'cinematic', 'filmisk', '35mm', 'analog', 'kodak',
    'anime', 'manga', '3d render', 'unreal engine 5', 'octane render', 'oil painting',
    'oljemålning', 'watercolor', 'akvarell', 'digital art', 'cyberpunk', 'baroque',
    'minimalist', 'hyperrealistic', 'film grain', 'editorial'
  ];
  let styleMatches = styleKeywords.filter(k => text.includes(k)).length;
  if (styleMatches >= 1) styleScore += 6;
  if (styleMatches >= 2) styleScore += 4;
  styleScore = Math.min(10, styleScore);

  // 5. Kamera och komposition (Camera & Composition) - Max 15
  let cameraScore = 0;
  const cameraKeywords = [
    '14mm', '24mm', '35mm', '50mm', '85mm', '100mm', 'macro', 'telephoto', 'wide-angle', 'vidvinkel',
    'close-up', 'närbild', 'extreme close-up', 'wide shot', 'establishing shot', 'medium shot',
    'dutch angle', 'low angle', 'grodperspektiv', 'high angle', 'fågelperspektiv', 'eye level',
    'depth of field', 'skärpedjup', 'bokeh', 'f/1.4', 'f/1.8', 'f/2.8', 'rule of thirds',
    'golden ratio', 'framing', 'anamorphic', 'pan', 'tilt', 'dolly', 'tracking shot', 'orbit'
  ];
  let cameraMatches = cameraKeywords.filter(k => text.includes(k)).length;
  if (cameraMatches >= 1) cameraScore += 6;
  if (cameraMatches >= 2) cameraScore += 5;
  if (cameraMatches >= 3) cameraScore += 4;
  cameraScore = Math.min(15, cameraScore);

  // 6. Ljussättning (Lighting) - Max 10
  let lightingScore = 0;
  const lightingKeywords = [
    'golden hour', 'gyllene timmen', 'blue hour', 'blå timmen', 'volumetric light', 'volymetriskt ljus',
    'god rays', 'solstrålar', 'rim light', 'kantljus', 'backlit', 'motljus', 'studio lighting',
    'studioljus', 'softbox', 'neon', 'chiaroscuro', 'dramatic lighting', 'dramatiskt ljus',
    'natural lighting', 'naturligt ljus', 'diffuse', 'diffust', 'hard light', 'cinematic lighting'
  ];
  let lightMatches = lightingKeywords.filter(k => text.includes(k)).length;
  if (lightMatches >= 1) lightingScore += 5;
  if (lightMatches >= 2) lightingScore += 3;
  if (lightMatches >= 3) lightingScore += 2;
  lightingScore = Math.min(10, lightingScore);

  // 7. Teknisk specificitet (Technical Quality) - Max 10
  let techScore = 0;
  const techKeywords = [
    '8k', '4k', 'uhd', 'masterpiece', 'raw photo', 'dslr', 'hasselblad', 'arri', 'red komodo',
    'subsurface scattering', 'photometry', 'ray tracing', 'hdr', 'sharp focus', 'micro textures',
    'color graded', 'färgkorrigerad', 'aspect ratio', '--ar', 'fps', 'shutter speed'
  ];
  let techMatches = techKeywords.filter(k => text.includes(k)).length;
  if (techMatches >= 1) techScore += 4;
  if (techMatches >= 2) techScore += 3;
  if (neg.length > 5 || techMatches >= 3) techScore += 3;
  techScore = Math.min(10, techScore);

  // 8. Konfliktfrihet (Conflict-Free) - Max 5
  let conflictScore = 5;
  const conflicts: string[] = [];

  const conflictPairs = [
    { a: 'photorealistic', b: 'cartoon', reason: 'Konflikt: Fotorealistisk vs tecknad/cartoon' },
    { a: 'fotorealistisk', b: 'tecknad', reason: 'Konflikt: Fotorealistisk vs tecknad' },
    { a: 'daylight', b: 'midnight', reason: 'Konflikt: Dagsljus kombinerat med midnatt' },
    { a: 'dagsljus', b: 'midnatt', reason: 'Konflikt: Dagsljus kombinerat med midnatt' },
    { a: 'macro', b: 'wide landscape', reason: 'Konflikt: Makroobjektiv i kombination med vidsträckt landskap' },
    { a: 'sunny', b: 'heavy rain', reason: 'Möjlig konflikt: Strålande solsken och kraftigt ösregn utan förklaring' },
    { a: 'low quality', b: 'masterpiece', reason: 'Konflikt: Låg kvalitet och mästerverk' },
    { a: 'blurry', b: 'hyper-detailed', reason: 'Konflikt: Suddigt och hyperdetaljerat i samma instruktion' },
  ];

  for (const pair of conflictPairs) {
    if (text.includes(pair.a) && text.includes(pair.b)) {
      conflictScore = Math.max(0, conflictScore - 3);
      conflicts.push(pair.reason);
    }
  }

  // Identify flaws and suggestions
  const flaws: string[] = [];
  const suggestions: string[] = [];

  if (subjectScore < 12) {
    flaws.push('Svagt eller otydligt definierat huvudmotiv');
    suggestions.push('Beskriv motivets utseende, ansiktsuttryck, klädsel eller material mer ingående.');
  }
  if (actionScore < 8) {
    flaws.push('Statisk scen utan tydlig handling eller pose');
    suggestions.push('Lägg till rörelse, blickriktning, gest eller fysisk interaktion med omgivningen.');
  }
  if (envScore < 8) {
    flaws.push('Vag miljöbeskrivning');
    suggestions.push('Definiera bakgrund, väder, arkitektur och rumslig placering.');
  }
  if (styleScore < 5) {
    flaws.push('Saknar uttalad visuell stil');
    suggestions.push('Specificera t.ex. "35mm cinematic film", "hyperrealistic digital art" eller "oil painting".');
  }
  if (cameraScore < 8) {
    flaws.push('Ingen kameravinkel eller objektivangivelse');
    suggestions.push('Lägg till objektiv (t.ex. 50mm f/1.4, 85mm portrait) eller komposition (t.ex. wide-angle, rule of thirds).');
  }
  if (lightingScore < 6) {
    flaws.push('Begränsad ljussättning');
    suggestions.push('Lägg till ljuskällor, t.ex. "golden hour sunlight", "volumetric rim lighting" eller "neon reflections".');
  }
  if (techScore < 5) {
    flaws.push('Saknar tekniska kvalitetsmarkörer');
    suggestions.push('Inkludera termer som "8k raw photo", "micro-textures", eller lägg till en negativ prompt.');
  }

  const totalScore =
    subjectScore +
    actionScore +
    envScore +
    styleScore +
    cameraScore +
    lightingScore +
    techScore +
    conflictScore;

  return {
    totalScore: Math.min(100, Math.max(10, totalScore)),
    breakdown: {
      subject: subjectScore,
      action: actionScore,
      environment: envScore,
      visualStyle: styleScore,
      cameraComposition: cameraScore,
      lighting: lightingScore,
      technicalSpecs: techScore,
      conflictFree: conflictScore,
    },
    flaws,
    suggestions,
    conflicts,
    evaluationType: 'local',
  };
}
