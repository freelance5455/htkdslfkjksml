import { PromptItem, Project, StoryboardProject, ContinuousVideoProject, AppSettings } from '../types';

const DB_NAME = 'ai_prompt_master_studio_db';
const DB_VERSION = 1;

let dbPromise: Promise<IDBDatabase> | null = null;

function getDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      return reject(new Error('IndexedDB not supported'));
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
      const db = (event.target as IDBOpenDBRequest).result;

      if (!db.objectStoreNames.contains('prompts')) {
        const promptStore = db.createObjectStore('prompts', { keyPath: 'id' });
        promptStore.createIndex('updatedAt', 'updatedAt', { unique: false });
        promptStore.createIndex('isFavorite', 'isFavorite', { unique: false });
        promptStore.createIndex('category', 'category', { unique: false });
        promptStore.createIndex('type', 'type', { unique: false });
      }

      if (!db.objectStoreNames.contains('projects')) {
        const projectStore = db.createObjectStore('projects', { keyPath: 'id' });
        projectStore.createIndex('updatedAt', 'updatedAt', { unique: false });
      }

      if (!db.objectStoreNames.contains('storyboards')) {
        const sbStore = db.createObjectStore('storyboards', { keyPath: 'id' });
        sbStore.createIndex('updatedAt', 'updatedAt', { unique: false });
      }

      if (!db.objectStoreNames.contains('continuousVideos')) {
        const cvStore = db.createObjectStore('continuousVideos', { keyPath: 'id' });
        cvStore.createIndex('updatedAt', 'updatedAt', { unique: false });
      }
    };

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onerror = () => {
      reject(request.error);
    };
  });

  return dbPromise;
}

// Generic store operations
async function getAllFromStore<T>(storeName: string): Promise<T[]> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const req = store.getAll();
      req.onsuccess = () => resolve((req.result as T[]) || []);
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn(`Fallback for store ${storeName}:`, err);
    const local = localStorage.getItem(`db_fallback_${storeName}`);
    return local ? JSON.parse(local) : [];
  }
}

async function saveToStore<T extends { id: string }>(storeName: string, item: T): Promise<T> {
  try {
    const db = await getDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      const req = store.put(item);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
    return item;
  } catch (err) {
    console.warn(`Fallback save for ${storeName}:`, err);
    const existing = await getAllFromStore<T>(storeName);
    const index = existing.findIndex((e) => e.id === item.id);
    if (index >= 0) existing[index] = item;
    else existing.push(item);
    localStorage.setItem(`db_fallback_${storeName}`, JSON.stringify(existing));
    return item;
  }
}

async function deleteFromStore(storeName: string, id: string): Promise<void> {
  try {
    const db = await getDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn(`Fallback delete for ${storeName}:`, err);
    const existing = await getAllFromStore<any>(storeName);
    const filtered = existing.filter((e) => e.id !== id);
    localStorage.setItem(`db_fallback_${storeName}`, JSON.stringify(filtered));
  }
}

// High level storage API
export const storageService = {
  // Prompts
  async getPrompts(): Promise<PromptItem[]> {
    const prompts = await getAllFromStore<PromptItem>('prompts');
    return prompts.sort((a, b) => b.updatedAt - a.updatedAt);
  },

  async savePrompt(prompt: PromptItem): Promise<PromptItem> {
    const item: PromptItem = {
      ...prompt,
      updatedAt: Date.now(),
      createdAt: prompt.createdAt || Date.now(),
    };
    return saveToStore<PromptItem>('prompts', item);
  },

  async deletePrompt(id: string): Promise<void> {
    return deleteFromStore('prompts', id);
  },

  async toggleFavorite(id: string): Promise<PromptItem | null> {
    const prompts = await this.getPrompts();
    const prompt = prompts.find((p) => p.id === id);
    if (!prompt) return null;
    const updated = { ...prompt, isFavorite: !prompt.isFavorite };
    return this.savePrompt(updated);
  },

  // Projects
  async getProjects(): Promise<Project[]> {
    const projects = await getAllFromStore<Project>('projects');
    return projects.sort((a, b) => b.updatedAt - a.updatedAt);
  },

  async saveProject(project: Project): Promise<Project> {
    const item: Project = {
      ...project,
      updatedAt: Date.now(),
      createdAt: project.createdAt || Date.now(),
    };
    return saveToStore<Project>('projects', item);
  },

  async deleteProject(id: string): Promise<void> {
    return deleteFromStore('projects', id);
  },

  // Storyboards
  async getStoryboards(): Promise<StoryboardProject[]> {
    const sb = await getAllFromStore<StoryboardProject>('storyboards');
    return sb.sort((a, b) => b.updatedAt - a.updatedAt);
  },

  async saveStoryboard(sb: StoryboardProject): Promise<StoryboardProject> {
    const item: StoryboardProject = {
      ...sb,
      updatedAt: Date.now(),
      createdAt: sb.createdAt || Date.now(),
    };
    return saveToStore<StoryboardProject>('storyboards', item);
  },

  async deleteStoryboard(id: string): Promise<void> {
    return deleteFromStore('storyboards', id);
  },

  // Continuous Videos
  async getContinuousVideos(): Promise<ContinuousVideoProject[]> {
    const cv = await getAllFromStore<ContinuousVideoProject>('continuousVideos');
    return cv.sort((a, b) => b.updatedAt - a.updatedAt);
  },

  async saveContinuousVideo(cv: ContinuousVideoProject): Promise<ContinuousVideoProject> {
    const item: ContinuousVideoProject = {
      ...cv,
      updatedAt: Date.now(),
      createdAt: cv.createdAt || Date.now(),
    };
    return saveToStore<ContinuousVideoProject>('continuousVideos', item);
  },

  async deleteContinuousVideo(id: string): Promise<void> {
    return deleteFromStore('continuousVideos', id);
  },

  // Settings
  getSettings(): AppSettings {
    const defaultSettings: AppSettings = {
      theme: 'dark',
      language: 'sv',
      aiMode: 'local',
      geminiModel: 'gemini-3.8-flash',
      defaultMediaType: 'image',
      defaultPlatform: 'midjourney',
      defaultAspectRatio: '16:9',
      defaultDetailLevel: 'ultimate',
      autosave: true,
      showQualityScore: true,
      confirmDelete: true,
    };

    if (typeof window === 'undefined') return defaultSettings;
    try {
      const stored = localStorage.getItem('prompt_master_settings');
      return stored ? { ...defaultSettings, ...JSON.parse(stored) } : defaultSettings;
    } catch {
      return defaultSettings;
    }
  },

  saveSettings(settings: AppSettings): void {
    if (typeof window !== 'undefined') {
      localStorage.setItem('prompt_master_settings', JSON.stringify(settings));
    }
  },

  // Complete Backup & Restore
  async exportFullBackup(): Promise<string> {
    const prompts = await this.getPrompts();
    const projects = await this.getProjects();
    const storyboards = await this.getStoryboards();
    const continuousVideos = await this.getContinuousVideos();
    const settings = this.getSettings();

    const data = {
      version: '3.0.0',
      exportedAt: new Date().toISOString(),
      prompts,
      projects,
      storyboards,
      continuousVideos,
      settings,
    };

    return JSON.stringify(data, null, 2);
  },

  async importFullBackup(jsonString: string): Promise<{ success: boolean; count: number; error?: string }> {
    try {
      const data = JSON.parse(jsonString);
      let count = 0;

      if (Array.isArray(data.prompts)) {
        for (const p of data.prompts) {
          if (p.id && p.prompt) {
            await this.savePrompt(p);
            count++;
          }
        }
      }

      if (Array.isArray(data.projects)) {
        for (const pr of data.projects) {
          if (pr.id && pr.title) {
            await this.saveProject(pr);
          }
        }
      }

      if (Array.isArray(data.storyboards)) {
        for (const sb of data.storyboards) {
          if (sb.id && sb.title) {
            await this.saveStoryboard(sb);
          }
        }
      }

      if (Array.isArray(data.continuousVideos)) {
        for (const cv of data.continuousVideos) {
          if (cv.id && cv.title) {
            await this.saveContinuousVideo(cv);
          }
        }
      }

      if (data.settings) {
        this.saveSettings(data.settings);
      }

      return { success: true, count };
    } catch (err) {
      return { success: false, count: 0, error: err instanceof Error ? err.message : 'Invalid JSON file' };
    }
  },

  async clearAllData(): Promise<void> {
    const prompts = await this.getPrompts();
    for (const p of prompts) await this.deletePrompt(p.id);

    const projects = await this.getProjects();
    for (const pr of projects) await this.deleteProject(pr.id);

    const sbs = await this.getStoryboards();
    for (const sb of sbs) await this.deleteStoryboard(sb.id);

    const cvs = await this.getContinuousVideos();
    for (const cv of cvs) await this.deleteContinuousVideo(cv.id);

    if (typeof window !== 'undefined') {
      localStorage.removeItem('db_fallback_prompts');
      localStorage.removeItem('db_fallback_projects');
      localStorage.removeItem('db_fallback_storyboards');
      localStorage.removeItem('db_fallback_continuousVideos');
    }
  },
};
