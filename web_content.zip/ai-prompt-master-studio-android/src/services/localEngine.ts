import { MediaType, QualityScoreResult } from '../types';
import { evaluatePromptQuality } from './qualityScorer';

// Synonym and vocabulary dictionary
export const VOCABULARY = {
  lighting: [
    'dramatic chiaroscuro lighting with sharp specular highlights',
    'warm golden hour sunset with soft atmospheric haze',
    'cool blue hour twilight with gentle ambient illumination',
    'volumetric god rays piercing through dense mist',
    'soft studio dual-softbox lighting with subtle rim light',
    'cyberpunk neon glow reflecting off wet asphalt',
    'cinematic moody backlighting with pronounced rim contours',
    'diffuse natural overcast daylight for clean balanced contrast'
  ],
  camera: [
    'shot on Hasselblad H6D-100c with 85mm f/1.4 prime lens',
    'captured with ARRI Alexa Mini LF on 35mm anamorphic glass',
    'ultra-wide 14mm perspective with deep architectural field',
    '50mm f/1.2 lens at eye-level with buttery bokeh separation',
    '100mm macro lens revealing microscopic textural detail',
    'dynamic low-angle tracking shot with steady fluid motion'
  ],
  composition: [
    'centered symmetrical composition following the golden ratio',
    'rule of thirds framing with deliberate negative space',
    'dynamic diagonal leading lines guiding the viewer’s eye',
    'intimate cinematic close-up with shallow depth of field',
    'epic panoramic wide vista with atmospheric scale',
    'layered depth composition with textured foreground elements'
  ],
  colorGrading: [
    'teal and orange cinematic color grade, 35mm Kodak Portra 400 tones',
    'muted melancholic earth tones with desaturated deep greens',
    'vibrant high-contrast cyberpunk palette with electric cyan and magenta',
    'monochromatic noir aesthetics with deep rich blacks and luminous highlights',
    'pastel vintage aesthetic with soft highlights and warm film grain'
  ],
  materials: [
    'intricate micro-textures, authentic skin pores, subsurface scattering',
    'weathered brushed metal, rusted patina, and industrial mechanical rivets',
    'flowing gossamer silk with tactile weave and soft specular drape',
    'gleaming wet asphalt with crisp puddles mirroring environmental lights',
    'carved ancient obsidian stone with faint glowing runes'
  ],
  styles: [
    'photorealistic editorial photography',
    'cinematic dark fantasy film still',
    'retro sci-fi cyberpunk concept art',
    'hyper-detailed architectural visualization',
    'hyperrealistic wildlife documentary still',
    'stylized anime keyframe with high-end digital compositing'
  ]
};

export const NEGATIVE_IMAGE_DEFAULTS = [
  'blurry', 'low resolution', 'distorted anatomy', 'extra fingers', 'deformed face',
  'duplicate limbs', 'visual artifacts', 'bad composition', 'oversaturated', 'watermark',
  'unwanted text', 'signature', 'amateur snapshot', 'jpeg compression artifacts', 'poorly drawn hands'
];

export const NEGATIVE_VIDEO_DEFAULTS = [
  'flickering frames', 'unnatural robotic movement', 'sudden camera shake', 'temporal inconsistency',
  'motion blur artifacts', 'warped morphing objects', 'duplicate subjects', 'unstable lighting flicker',
  'sudden scene jump cuts', 'distorted faces during motion', 'low bitrate artifacts'
];

export interface PromptBuildParams {
  type: MediaType;
  subject: string;
  action?: string;
  environment?: string;
  timeAndWeather?: string;
  visualStyle?: string;
  composition?: string;
  camera?: string;
  lens?: string;
  lighting?: string;
  colorPalette?: string;
  materials?: string;
  technicalQuality?: string;
  aspectRatio?: string;
  negativeInstructions?: string;
  detailLevel?: 'short' | 'detailed' | 'professional' | 'ultimate';
}

export const localPromptEngine = {
  // 1. Core Generator for Prompt Builder
  generatePrompts(params: PromptBuildParams) {
    const s = params.subject.trim() || 'A captivating subject';
    const act = params.action ? `, ${params.action.trim()}` : '';
    const env = params.environment ? `, set in ${params.environment.trim()}` : '';
    const tw = params.timeAndWeather ? `, during ${params.timeAndWeather.trim()}` : '';
    const sty = params.visualStyle || 'photorealistic cinematic style';
    const comp = params.composition ? `, ${params.composition}` : '';
    const cam = params.camera ? `, shot on ${params.camera}` : '';
    const lens = params.lens ? ` with ${params.lens}` : '';
    const light = params.lighting ? `, ${params.lighting}` : '';
    const col = params.colorPalette ? `, ${params.colorPalette}` : '';
    const mat = params.materials ? `, featuring ${params.materials}` : '';
    const tech = params.technicalQuality || '8k UHD, masterpiece, hyper-detailed, ray tracing';

    // 1. Short Prompt (~15-25 words)
    const shortPrompt = `${sty} of ${s}${act}${env}${light}. Crisp focus.`;

    // 2. Detailed Prompt (~50-80 words)
    const detailedPrompt = `${s}${act}${env}${tw}. ${sty}${comp}. Lit by ${light || 'natural balanced lighting'}. Rich textures, vibrant atmosphere, beautifully rendered.`;

    // 3. Professional Prompt
    const professionalPrompt = `Masterpiece ${sty}: ${s}${act}. Setting: ${env || 'atmospheric location'}${tw}. Camera & Optics: ${cam || 'shot on Hasselblad'}${lens || ' 50mm f/1.4'}${comp}. Lighting: ${light || 'cinematic volumetric illumination'}. Color Grading: ${col || 'filmic tone curve'}. Technical: ${tech}.`;

    // 4. Ultimate Prompt (Master synthesis of all 11 dimensions)
    const ultimatePrompt = `${s}${act}${env}${tw}, ${sty}, ${comp}${cam}${lens}, ${light}, ${col}, ${mat}, ${tech}`;

    // 5. Structured Prompt (Annotated for studio reference)
    const structuredPrompt = [
      `[Subject]: ${s}`,
      params.action ? `[Action]: ${params.action}` : null,
      params.environment ? `[Environment]: ${params.environment}` : null,
      params.timeAndWeather ? `[Atmosphere]: ${params.timeAndWeather}` : null,
      `[Style]: ${sty}`,
      params.camera || params.lens ? `[Optics]: ${params.camera || ''} ${params.lens || ''}`.trim() : null,
      params.lighting ? `[Lighting]: ${params.lighting}` : null,
      params.colorPalette ? `[Palette]: ${params.colorPalette}` : null,
      `[Quality]: ${tech}`
    ].filter(Boolean).join('\n');

    // 6. Negative Prompt
    const baseNegatives = params.type === 'video' ? NEGATIVE_VIDEO_DEFAULTS : NEGATIVE_IMAGE_DEFAULTS;
    const customNeg = params.negativeInstructions ? `, ${params.negativeInstructions}` : '';
    const negativePrompt = `${baseNegatives.slice(0, 8).join(', ')}${customNeg}`;

    // 3 Alternative Variations
    const alt1 = `Dramatic perspective: ${s}${act}, enveloped by ${params.environment || 'surrounding environment'}. ${VOCABULARY.lighting[0]}, ${VOCABULARY.camera[1]}, ${col || 'teal and orange grade'}, ultra-realistic 8k.`;
    const alt2 = `Atmospheric mood: ${s}, ${tw || 'misty morning twilight'}. ${VOCABULARY.lighting[3]}, ${VOCABULARY.composition[1]}, ${VOCABULARY.materials[0]}, cinematic film still.`;
    const alt3 = `Studio perfection: ${s}${act}. ${VOCABULARY.lighting[4]}, ${VOCABULARY.camera[0]}, ${VOCABULARY.materials[0]}, pristine clarity, editorial cover shot.`;

    // Quality check
    const quality = evaluatePromptQuality(ultimatePrompt, params.type, negativePrompt);

    return {
      shortPrompt,
      detailedPrompt,
      professionalPrompt,
      ultimatePrompt,
      structuredPrompt,
      negativePrompt,
      alternatives: [alt1, alt2, alt3],
      quality,
    };
  },

  // 2. Local Auto-Builder (Expand brief ideas with rules)
  autoBuildIdea(idea: string, language: 'sv' | 'en' = 'sv') {
    const isSv = language === 'sv';
    const lower = idea.toLowerCase();

    // Determine motif category
    let subject = idea;
    let action = isSv ? 'går i långsamt fokuserat tempo med blicken framåt' : 'walking with purposeful steady pace, looking forward';
    let environment = isSv ? 'gatumiljö med glänsande blöt asfalt, neonskyltar och arkitektoniska fasader' : 'urban street with reflective wet asphalt, glowing storefronts and architectural facades';
    let timeAndWeather = isSv ? 'skymning med kraftigt strilande regn och dimslöjor' : 'dusk with steady falling rain and atmospheric mist';
    let visualStyle = 'cinematic 35mm film still, Kodak Portra aesthetic';
    let cameraAndLens = 'ARRI Alexa LF, 50mm f/1.4 prime lens at eye level';
    let lighting = isSv ? 'reflektioner i vattenpölar, volymetriskt motljus och varma gatlyktor' : 'rain puddles mirroring streetlights, volumetric rim lighting, soft ambient glow';
    let colorGrading = 'cinematic teal and amber grading with deep rich shadows';
    let materialsAndDetails = isSv ? 'fuktig ullrock, vattendroppar på kläder, texturerad stenbeläggning' : 'damp tailored overcoat, water droplets beading on fabrics, weathered cobblestones';
    let technicalQuality = '8k resolution, raw photo clarity, award-winning cinematography';

    if (lower.includes('bil') || lower.includes('car') || lower.includes('fordon')) {
      action = isSv ? 'glider fram längs en kurvig kustväg med tända LED-strålkastare' : 'cruising along a serpentine coastal highway with bright LED headlights cutting through darkness';
      environment = isSv ? 'dramatiska havsklippor vid solnedgång med vågstänk' : 'dramatic sea cliffs at twilight with crashing ocean waves';
      cameraAndLens = 'Russian Arm tracking rig, 35mm wide lens, low perspective';
      lighting = 'golden hour side-lighting catching sculpted aerodynamic contours';
    } else if (lower.includes('porträtt') || lower.includes('portrait') || lower.includes('kvinna') || lower.includes('man')) {
      action = isSv ? 'vänder sig mjukt mot kameran med ett gåtfullt, närvarande uttryck' : 'turning subtly towards camera with an enigmatic, intense gaze';
      cameraAndLens = 'Hasselblad 85mm f/1.2 lens, ultra-shallow depth of field';
      lighting = 'Elinchrom softbox key light, delicate hair rim light';
      materialsAndDetails = 'crisp iris detail, natural skin pores, delicate fabric weave';
    } else if (lower.includes('rymden') || lower.includes('space') || lower.includes('sci-fi')) {
      environment = isSv ? 'omloppsbana ovanför en upplyst planet med stjärnhimmel och nebulosa' : 'high planetary orbit with aurora borealis and distant colorful nebula';
      visualStyle = 'hard science fiction realism, IMAX 70mm';
      lighting = 'stark unfiltered solar glare casting deep geometric shadows';
    }

    const shortPrompt = `${visualStyle} of ${subject}, ${action}, in ${environment}. ${lighting}.`;
    const detailedPrompt = `${subject}, ${action}. Setting: ${environment}, ${timeAndWeather}. Captured in ${visualStyle}. Lighting features ${lighting}. Masterpiece cinematography.`;
    const professionalPrompt = `Shot on ${cameraAndLens}: ${subject}, ${action} in ${environment}. Atmosphere: ${timeAndWeather}. Style: ${visualStyle}. Palette: ${colorGrading}. Details: ${materialsAndDetails}. Quality: ${technicalQuality}.`;
    const ultimatePrompt = `${subject}, ${action}, ${environment}, ${timeAndWeather}, ${visualStyle}, ${cameraAndLens}, ${lighting}, ${colorGrading}, ${materialsAndDetails}, ${technicalQuality}`;
    const negativePrompt = NEGATIVE_IMAGE_DEFAULTS.slice(0, 10).join(', ');

    return {
      subject,
      action,
      environment,
      timeAndWeather,
      visualStyle,
      composition: isSv ? 'Gyllene snittet, balanserad förgrund och djup bakgrund' : 'Golden ratio framing, layered foreground with expansive depth',
      cameraAndLens,
      lighting,
      colorGrading,
      materialsAndDetails,
      technicalQuality,
      shortPrompt,
      detailedPrompt,
      professionalPrompt,
      ultimatePrompt,
      negativePrompt,
    };
  },

  // 3. Local Prompt Enhancer
  enhancePrompt(prompt: string, mode: string, language: 'sv' | 'en' = 'sv') {
    const isSv = language === 'sv';
    let addition = '';
    const changes: string[] = [];

    switch (mode) {
      case 'realistic':
        addition = ', 8k raw photo, shot on Hasselblad H6D-100c, authentic skin pores, subsurface scattering, micro-textures, photorealistic natural lighting';
        changes.push('Lade till optik- och sensorreferenser (Hasselblad H6D-100c)');
        changes.push('Förstärkte ytdetaljer (subsurface scattering, mikroteksturer)');
        break;
      case 'cinematic':
        addition = ', cinematic 35mm anamorphic film still, ARRI Alexa Mini, dramatic chiaroscuro lighting, subtle film grain, 2.39:1 aspect ratio composition';
        changes.push('Lade till filmiskt format och anamorfisk objektivkaraktär');
        changes.push('Integrerade chiaroscuro-kontrastbelysning');
        break;
      case 'detailed':
        addition = ', ultra-detailed foreground elements, atmospheric environmental particles, hyper-intricate craftsmanship, layered spatial depth';
        changes.push('Expanderade rumslig komposition i flera lager');
        changes.push('Lade till atmosfäriska partiklar och förgrundsdetaljer');
        break;
      case 'lighting':
        addition = ', bathed in dramatic golden hour rays with volumetric atmospheric dust, sharp specular rim lighting, soft diffuse shadows';
        changes.push('Förstärkte ljuskällans riktning och volymetriska egenskaper');
        changes.push('Lade till kantbelysning för motivseparation');
        break;
      case 'camera':
        addition = ', 85mm f/1.4 prime lens at eye level, shallow depth of field, creamy bokeh circles in background, razor-sharp focus on subject';
        changes.push('Specificerade brännvidd (85mm) och bländartal (f/1.4)');
        changes.push('Maximerade fokusseparation med bakgrundsbokeh');
        break;
      case 'composition':
        addition = ', composed along Fibonacci spiral, dynamic leading lines, powerful foreground interest, balanced negative space';
        changes.push('Applicerade Fibonacci-spiral och geometriska ledlinjer');
        break;
      case 'movement':
        addition = ', dynamic kinetic motion, subtle shutter motion blur on high-speed elements, wind-blown fabric, dynamic energy';
        changes.push('Lade till kinetisk energi och naturlig rörelseoskärpa');
        break;
      case 'atmosphere':
        addition = ', heavy moody atmospheric fog, mysterious haze, dense emotional ambiance, subtle light scattering';
        changes.push('Förstärkte känslomässig stämning och fuktdimma');
        break;
      case 'shorten': {
        const words = prompt.split(/\s+/).slice(0, 20).join(' ');
        return {
          original: prompt,
          enhanced: `${words}, 8k, photorealistic, cinematic lighting.`,
          changes: ['Kondenserade prompten till de mest kärnfulla visuella termerna'],
          negativePrompt: NEGATIVE_IMAGE_DEFAULTS.slice(0, 6).join(', '),
          qualityScoreLocal: 82,
          reasoning: 'Korta prompter minskar begreppsförvirring hos moderna diffusionsmodeller.',
        };
      }
      case 'expand':
      case 'ultimate':
      default:
        addition = ', cinematic 35mm film still, shot on ARRI Alexa LF, 50mm f/1.4, volumetric lighting, rich color grading, ultra-detailed micro textures, 8k resolution, award-winning visual composition';
        changes.push('Genomförde en helhetsoptimering över alla 8 kvalitetsaxlar');
        changes.push('Lade till objektiv, belysning, komposition och texturkontroll');
        break;
    }

    const enhanced = `${prompt.trim()}${addition}`;
    const quality = evaluatePromptQuality(enhanced);

    return {
      original: prompt,
      enhanced,
      changes,
      negativePrompt: NEGATIVE_IMAGE_DEFAULTS.slice(0, 8).join(', '),
      qualityScoreLocal: quality.totalScore,
      reasoning: isSv
        ? 'Den förbättrade versionen guidar diffusionsmodellen med exakta fysikaliska och optiska parametrar istället för generiska adjektiv.'
        : 'The enhanced prompt provides precise optical, lighting and compositional anchors rather than vague adjectives.',
    };
  },

  // 4. Local Rule-Based Interview
  getLocalInterviewQuestion(step: number, idea: string, answers: Record<string, string>) {
    const questions = [
      {
        question: 'Vilken belysning och tid på dygnet förstärker din vision bäst?',
        category: 'Ljussättning & Tid',
        options: [
          'Gyllene timmen med varma solstrålar och långa skuggor',
          'Blå timmen (skymning) med svala stämningsfulla toner',
          'Natt med neonsken och blöta reflexer',
          'Rent studioljus med mjuk softbox och kantbelysning'
        ],
        insight: 'Ljuset bestämmer kontrast, färgtemperatur och känsloläge i bilden.'
      },
      {
        question: 'Vilket kameraperspektiv och objektiv passar bäst?',
        category: 'Kamera & Komposition',
        options: [
          '85mm porträttobjektiv med krämig bakgrundsbokeh',
          '35mm filmisk komposition i ögonhöjd',
          '14mm vidvinkel med dramatiskt grodperspektiv',
          'Drönarvy från ovan som visar hela landskapet'
        ],
        insight: 'Objektivvalet styr bildens skärpedjup och rumsliga relationer.'
      },
      {
        question: 'Vilken visuell stil och renderingskänsla vill du uppnå?',
        category: 'Visuell Stil',
        options: [
          'Fotorealistisk 35mm analog film med naturligt korn',
          'Hyperrealistisk digital konst med knivskarp skärpa',
          'Mörk filmisk science fiction / cyberpunk',
          'Klassisk oljemålning med synliga penseldrag'
        ],
        insight: 'Stilen definierar bildens materialitet och rendering.'
      },
      {
        question: 'Vilka detaljer i klädsel, material eller rekvisita ska framhävas?',
        category: 'Material & Texturer',
        options: [
          'Sliten läderjacka och grovt stickade naturmaterial',
          'Futuristisk matt pansarrustning med ljuspaneler',
          'Fint skräddarsydd ullkostym med sidenfoder',
          'Enkla tidlösa vardagskläder med naturligt fall'
        ],
        insight: 'Mikrodetaljer ger trovärdighet och förhindrar plastiga AI-ytor.'
      }
    ];

    const current = questions[Math.min(step, questions.length - 1)];
    const isDone = step >= questions.length;

    return {
      questionNumber: step + 1,
      isDone,
      question: current.question,
      category: current.category,
      options: current.options,
      insight: current.insight,
    };
  },

  // 5. Local Rule-Based Storyboard Generator
  generateLocalStoryboard(concept: string, sceneCount: number = 6, style: string = 'Cinematic') {
    const count = Math.min(Math.max(sceneCount, 3), 12);
    const scenes = [];

    const beatNames = [
      'Etablering & Introduktion',
      'Upptrappning & Rörelse',
      'Konfrontation & Upptäckt',
      'Vändpunkt & Intensitet',
      'Klimax & Högspänning',
      'Avslutning & Efterdyning',
      'Epilog & Ny gryning',
      'Mysterium avslöjat',
      'Slutgiltig konfrontation',
      'Reflektion i skymningen',
      'Återkomst till trygghet',
      'Sista ögonkastet'
    ];

    const cameraMoves = [
      'Slow drone flyover with gentle descent',
      'Low-angle tracking shot moving forward alongside subject',
      'Dynamic whip pan to sudden point of interest',
      'Smooth 360-degree orbit shot centered on character',
      'Rapid push-in dolly shot emphasizing emotional shock',
      'Elevating crane shot rising above the landscape'
    ];

    for (let i = 0; i < count; i++) {
      const move = cameraMoves[i % cameraMoves.length];
      const title = beatNames[i % beatNames.length];
      const sceneNum = i + 1;

      scenes.push({
        sceneNumber: sceneNum,
        title: `${sceneNum}. ${title}`,
        description: `Del ${sceneNum} av handlingen kring: ${concept}`,
        subject: `Huvudkaraktär i konsekvent klädsel och utseende från scen 1`,
        action: `Karaktären agerar i enlighet med ${title.toLowerCase()}`,
        environment: `Miljö för ${concept}, konsekvent belysning och arkitektur`,
        timeAndWeather: 'Konsekvent tid och väderförhållande',
        cameraAngle: i % 2 === 0 ? 'Wide establishing shot' : 'Intense medium close-up',
        cameraMovement: move,
        lighting: 'Cinematic lighting matching overall color palette',
        colorPalette: 'Teal, amber and deep shadow grade',
        startFramePrompt: `Frame 0s: ${concept}, scene ${sceneNum} start, ${move}, ${style} style, 8k.`,
        endFramePrompt: `Frame 5s: ${concept}, scene ${sceneNum} climax, transitioning into next shot.`,
        videoPrompt: `Scene ${sceneNum} of ${concept}. ${move}. Character in focus. ${style} visuals, 35mm film aesthetics, photorealistic rendering.`,
        negativePrompt: NEGATIVE_VIDEO_DEFAULTS.slice(0, 8).join(', '),
        continuityNotes: `Scen ${sceneNum}: Bevara karaktärens ansiktsdrag, kläder och omgivande ljusriktning.`,
        durationSeconds: 5,
      });
    }

    return scenes;
  }
};
