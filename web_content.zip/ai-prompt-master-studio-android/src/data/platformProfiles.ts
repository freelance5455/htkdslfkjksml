import { PlatformProfile } from '../types';

export const PLATFORM_PROFILES: PlatformProfile[] = [
  // IMAGE PLATFORMS
  {
    id: 'midjourney',
    name: 'Midjourney v6.1',
    type: 'image',
    badge: 'Image Pioneer',
    description: 'Bäst på konstnärlig komposition, filmiska belysningar och estetisk finish. Föredrar korta till medellånga beskrivningar med kommatecken och explicita flaggor.',
    structure: [
      '1. Huvudmotiv och pose',
      '2. Bakgrund och miljö',
      '3. Ljussättning och atmosfär',
      '4. Kameratyp och objektiv',
      '5. Flaggor (--ar, --v 6.1, --stylize, --chaos)'
    ],
    syntaxNotes: 'Använd inte utfyllnadsord som "photorealistic 8k hyperrealism". Använd specifika kameror som "Hasselblad", "35mm film", eller ljusstilar. Avsluta med flaggor som --ar 16:9 --v 6.1.',
    recommendedAspectRatios: ['16:9', '9:16', '4:5', '3:2', '1:1', '21:9'],
    examplePrompt: 'A weathered Nordic fisherman mending a hemp net inside a wooden boathouse, cold morning fog entering through the open doorway, lit by a single tungsten lantern, shot on 35mm Leica M11, Kodak Tri-X 400 tones --ar 16:9 --v 6.1 --stylize 250',
    exampleNegative: '--no blurry, oversaturated, modern gadgets',
    tips: [
      'Använd --stylize mellan 50 (mer naturtroget) och 750 (mer konstnärligt).',
      'Flaggor som --weird och --chaos kan ge oväntade och unika idéer.',
      '--v 6.1 har överlägsen textrendering om du sätter ord inom citattecken.'
    ]
  },
  {
    id: 'flux',
    name: 'FLUX.1 [dev / schnell]',
    type: 'image',
    badge: 'Precision SOTA',
    description: 'Black Forest Labs flaggskepp. Exceptionell på naturligt språk, komplexa spatiala relationer och exakt typografi.',
    structure: [
      '1. Naturligt löpande mening om motiv och handling',
      '2. Exakt rumslig placering (foreground, midground, background)',
      '3. Fysikalisk ljussättning och färgpalett',
      '4. Text i citattecken om typografi önskas',
      '5. Objektiv och skärpedjup'
    ],
    syntaxNotes: 'FLUX föredrar fullständiga grammatiska meningar framför en lista med kommatecken. Skriv som en scenbeskrivning till en fotograf.',
    recommendedAspectRatios: ['1:1', '16:9', '9:16', '3:2', '4:5'],
    examplePrompt: 'A full-body high-contrast photograph of a woman wearing a yellow raincoat walking down a rainy Stockholm street at dusk. In the background, neon shop windows reflect on the wet pavement. She holds a coffee cup with the text "KAFFE" written on it in clean typography. Shot on 50mm f/1.8 lens.',
    exampleNegative: 'blurry, distorted fingers, low resolution, bad anatomy',
    tips: [
      'Undvik tagg-listor som ", 8k, masterpiece, octane" – FLUX ignorerar dem ofta.',
      'Beskriv text explicit med citattecken: with a neon sign reading "STUDIO".',
      'Guidance Scale runt 3.5 ger bäst realism på FLUX.1 [dev].'
    ]
  },
  {
    id: 'firefly',
    name: 'Adobe Firefly',
    type: 'image',
    badge: 'Commercial Safe',
    description: 'Tränad på Adobe Stock. Särskilt stark på kommersiell renhet, realistisk produktfotografering och illustrationer.',
    structure: [
      '1. Huvudämne och sammanhang',
      '2. Miljö och bakgrundskomposition',
      '3. Ljuskälla och reflektioner',
      '4. Inbyggda Firefly-filter (Foto, Illustration, Makro, etc.)'
    ],
    syntaxNotes: 'Mycket strikt säkerhetsfilter. Undvik termer relaterade till våld, kända personer eller upphovsrättsskyddat material.',
    recommendedAspectRatios: ['1:1', '4:3', '16:9', '9:16'],
    examplePrompt: 'A minimalist Scandinavian oak dining chair standing on a polished concrete floor, soft daylight streaming through large sheer white curtains, clean minimalist interior design, warm earth tones, editorial interior photography.',
    exampleNegative: 'cluttered, shadows too dark, people, modern electronics',
    tips: [
      'Utnyttja Fireflys inbyggda UI-reglage för ljus och vinkel i stället för att överbelasta prompten.',
      'Perfekt för rena kommersiella bilder utan upphovsrättsliga risker.'
    ]
  },
  {
    id: 'leonardo',
    name: 'Leonardo AI (Phoenix / Kino)',
    type: 'image',
    badge: 'Creative Versatility',
    description: 'Erbjuder avancerade Alchemy- och PhotoReal-modeller. Mycket stark på anime, digital konst och fantasy.',
    structure: [
      '1. Motiv och detaljerad utstyrsel',
      '2. Atmosfär och partikeleffekter',
      '3. Konstnärlig renderingsstil',
      '4. Ljussättning och färgschema'
    ],
    syntaxNotes: 'Fungerar bra med både kommaterade taggar och löpande text. Stödjer negativa prompter fullt ut.',
    recommendedAspectRatios: ['1:1', '16:9', '9:16', '3:2'],
    examplePrompt: 'A fantasy elven archer perched on an ancient mossy branch in an enchanted autumn forest. Detailed leather armor with silver filigree, glowing blue runic arrows, mystical floating golden spores, volumetric fog, dynamic lighting, masterpiece digital art.',
    exampleNegative: 'deformed bow, distorted hands, bad anatomy, flat colors, blurry',
    tips: [
      'Aktivera PhotoReal v2 för maximal fotorealism.',
      'Använd negativa prompter aktivt för att rensa bort anatomiska artefakter.'
    ]
  },
  {
    id: 'stablediffusion',
    name: 'Stable Diffusion (SDXL / SD3.5)',
    type: 'image',
    badge: 'Open Ecosystem',
    description: 'Öppen källkod med maximal kontroll över vikter, embeddings, LoRA och detaljerade negativa prompter.',
    structure: [
      '1. Huvudmotiv med vikt (vikt:1.2)',
      '2. Medium och artistisk stil',
      '3. Detaljer i miljö och ljus',
      '4. Lång omfattande negativ prompt'
    ],
    syntaxNotes: 'Använd parenteser för viktning, t.ex. (dramatic lighting:1.3). Kräver ofta noggrant utformade negativa prompter.',
    recommendedAspectRatios: ['1:1', '16:9', '9:16', '3:2', '4:5'],
    examplePrompt: '(masterpiece:1.2), raw photo of an elderly clockmaker in a dusty workshop, (magnifying loupe:1.1), brass gears, soft window light, depth of field, 85mm portrait, Kodak Portra 400',
    exampleNegative: 'easynegative, (worst quality:1.4), (low quality:1.4), blurry, deformed, extra digits, text, watermark',
    tips: [
      'Överbelasta inte vikter över 1.4 då det kan skapa artefakter.',
      'SDXL presterar bäst vid 1024x1024 som basupplösning.'
    ]
  },

  // VIDEO PLATFORMS
  {
    id: 'veo',
    name: 'Google Veo',
    type: 'video',
    badge: 'Cinematic High-Def',
    description: 'Googles avancerade videomodell med djup förståelse för filmiskt språk, kamerarörelser, visuell fysik och temporär kontinuitet.',
    structure: [
      '1. Scenöversikt och genre',
      '2. Huvudmotivets rörelsevektor',
      '3. Kamerarigg och förflyttning (e.g. Dolly in, Crane up, Tracking)',
      '4. Miljö och ljusförändring',
      '5. Visuell stil och stämning'
    ],
    syntaxNotes: 'Använd etablerade filmiska termer som "slow continuous tracking shot", "dolly in", "pan right". Definiera hur rörelser utvecklas över tid.',
    recommendedAspectRatios: ['16:9', '9:16', '21:9'],
    examplePrompt: 'Cinematic wide tracking shot: A vintage red sports car accelerates down a winding coastal highway at sunset. The camera glides alongside the car at wheel level, tracking its motion smoothly as the ocean waves crash against the cliffs in the background. Warm golden rim light, 60fps cinematic fluidity.',
    exampleNegative: 'jittery motion, sudden scene cut, low frame rate, unnatural acceleration, morphing chassis',
    tips: [
      'Beskriv kamerans rörelse explicit i början av prompten.',
      'Håll scenen fokuserad på en sammanhängande handling per klipp.'
    ]
  },
  {
    id: 'runway',
    name: 'Runway Gen-3 Alpha',
    type: 'video',
    badge: 'Industry Standard',
    description: 'Runways professionella videomotor känd för exceptionell temporal koherens, fotorealism och precis kamerastyrning.',
    structure: [
      '1. [Kamerarörelse]: FPV, Orbit, Tracking, Static',
      '2. Motiv och specifik handling',
      '3. Miljö och ljusförhållanden',
      '4. Estetisk referens (35mm film, documentary, commercial)'
    ],
    syntaxNotes: 'Börja gärna med kamerarörelsen inom hakparenteser eller tidigt i prompten, t.ex. "Low angle camera tracks forward with..."',
    recommendedAspectRatios: ['16:9', '9:16'],
    examplePrompt: 'FPP camera moves rapidly through a vibrant futuristic neon greenhouse. Bioluminescent flowers gently pulse with light as gentle water mist sprays from overhead copper pipes. Slow motion water droplets caught in laser light.',
    exampleNegative: 'flicker, static frame, jumpy camera, distorted hands, morphing objects',
    tips: [
      'Undvik för många simultana händelser; en fokuserad handling ger skarpast resultat.',
      'Använd Motion Brush i Runways UI för lokal rörelse.'
    ]
  },
  {
    id: 'sora',
    name: 'OpenAI Sora',
    type: 'video',
    badge: 'Physical World Simulation',
    description: 'Utvecklad för att förstå och simulera den fysiska världen i rörelse, upp till 60 sekunders sekvenser.',
    structure: [
      '1. Detaljerad narrativ scenbeskrivning',
      '2. Subtila interaktioner mellan objekt och gravitation',
      '3. Tidsförlopp och successiv rörelse',
      '4. Komplex ljussättning och reflektioner'
    ],
    syntaxNotes: 'Sora hanterar mycket långa och detaljerade beskrivningar. Du kan specificera exakt vad som händer i början, mitten och slutet.',
    recommendedAspectRatios: ['16:9', '9:16', '1:1', '21:9'],
    examplePrompt: 'A photorealistic slow tracking shot following a stray cat walking across a snow-covered alleyway in old Kyoto at night. The cat’s paws leave distinct soft indentations in the crisp fresh snow. Paper lanterns swing gently in the winter breeze, casting warm dancing shadows across wooden lattices.',
    exampleNegative: 'melting objects, teleporting characters, broken gravity, flickering snow',
    tips: [
      'Var specifik med fysikaliska effekter (vind, snö, vätska, tygfall).',
      'Kan hantera flera karaktärer med oberoende handlingar i samma scen.'
    ]
  },
  {
    id: 'kling',
    name: 'Kling AI (v1.5 Pro)',
    type: 'video',
    badge: 'High Fluidity',
    description: 'Mycket stark på flytande människokroppsrörelser, kampsport, dans och långa scener upp till 10 sekunder med hög dynamik.',
    structure: [
      '1. Karaktär och startposition',
      '2. Detaljerad rörelsekoreografi',
      '3. Kameravinkel och förflyttning',
      '4. Ljus och filmton'
    ],
    syntaxNotes: 'Fungerar bäst när rörelserna beskrivs steg för steg. Utmärkt på att bibehålla ansiktsdrag under dynamiska rörelser.',
    recommendedAspectRatios: ['16:9', '9:16', '1:1'],
    examplePrompt: 'Medium shot of a hip-hop dancer performing a fluid popping and locking routine in an abandoned subway station. The camera slowly orbits around the dancer while maintaining sharp focus on intricate hand gestures. Dust motes float in beams of overhead fluorescent lights.',
    exampleNegative: 'extra limbs, rubbery joints, distorted face during turn, camera judder',
    tips: [
      'Utmärkt för realistisk mimik och talande karaktärer.',
      'Välj "Professional Mode" i Kling för bäst rörelseprecision.'
    ]
  },
  {
    id: 'seedance',
    name: 'Seedance / ByteDance AI',
    type: 'video',
    badge: 'Dynamic Motion',
    description: 'Specialiserad på snabb rörelse, dynamiska kameravinklar och realistiska miljöövergångar.',
    structure: [
      '1. Actionsekvens och hastighet',
      '2. Kameraspårning och panorering',
      '3. Miljöeffekter och ljussättning'
    ],
    syntaxNotes: 'Skriv i presens med aktiva verb som "leaps", "sprints", "sweeps across".',
    recommendedAspectRatios: ['16:9', '9:16'],
    examplePrompt: 'High-speed action tracking shot: An acrobatic parkour runner leaps across rooftops in Paris at sunset, doing a smooth roll over a chimney before catching a steel ladder. Dynamic wide angle lens, realistic momentum.',
    exampleNegative: 'floating runner, slow motion stutter, broken perspective',
    tips: [
      'Fokusera på acceleration och bromsning för naturtrogen tyngdkraft.'
    ]
  },
  {
    id: 'googleflow',
    name: 'Google Flow Video',
    type: 'video',
    badge: 'Generative Transitions',
    description: 'Optimerad för flytande övergångar, visualiseringar av koncept och sömlösa loopande sekvenser.',
    structure: [
      '1. Starttillstånd',
      '2. Transformation eller övergångsmekanism',
      '3. Sluttillstånd',
      '4. Kontinuerlig belysning'
    ],
    syntaxNotes: 'Definiera hur en form eller ett tillstånd flytande övergår i ett annat.',
    recommendedAspectRatios: ['16:9', '1:1', '9:16'],
    examplePrompt: 'A smooth continuous transformation where an intricate blooming pink rose gradually morphs into a swirling galaxy of stars in deep space, retaining its spiral geometry. Gentle camera dolly in, ethereal lighting.',
    exampleNegative: 'jarring morph cuts, pixel noise, lost symmetry',
    tips: [
      'Idealisk för abstrakta introduktioner och visuella metaforer.'
    ]
  }
];
