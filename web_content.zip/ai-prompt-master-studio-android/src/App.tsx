import React, { useState, useEffect } from 'react';
import {
  AIMode,
  PromptItem,
  Project,
  AppSettings,
} from './types';
import { storageService } from './services/storage';
import { geminiService } from './services/geminiService';
import { Header } from './components/common/Header';
import { Sidebar } from './components/common/Sidebar';
import { BottomNav } from './components/common/BottomNav';
import { OfflineIndicator } from './components/common/PWAInstallButton';

// Sections
import { DashboardSection } from './components/sections/DashboardSection';
import { PromptBuilderSection } from './components/sections/PromptBuilderSection';
import { ImageStudioSection } from './components/sections/ImageStudioSection';
import { VideoStudioSection } from './components/sections/VideoStudioSection';
import { AutoBuilderSection } from './components/sections/AutoBuilderSection';
import { EnhancerSection } from './components/sections/EnhancerSection';
import { NegativePromptSection } from './components/sections/NegativePromptSection';
import { InterviewSection } from './components/sections/InterviewSection';
import { StoryboardSection } from './components/sections/StoryboardSection';
import { ContinuousVideoSection } from './components/sections/ContinuousVideoSection';
import { ImageAnalysisSection } from './components/sections/ImageAnalysisSection';
import { ComparisonLabSection } from './components/sections/ComparisonLabSection';
import { LibrarySection } from './components/sections/LibrarySection';
import { PlatformOptimizerSection } from './components/sections/PlatformOptimizerSection';
import { ProjectManagerSection } from './components/sections/ProjectManagerSection';
import { FavoritesSection } from './components/sections/FavoritesSection';
import { HistorySection } from './components/sections/HistorySection';
import { StorageManagerSection } from './components/sections/StorageManagerSection';
import { ImportExportSection } from './components/sections/ImportExportSection';
import { SettingsSection } from './components/sections/SettingsSection';
import { HelpCenterSection } from './components/sections/HelpCenterSection';

export default function App() {
  const [activeSection, setActiveSection] = useState<string>('dashboard');
  const [settings, setSettings] = useState<AppSettings>(() => storageService.getSettings());
  const [aiMode, setAiMode] = useState<AIMode>(settings.aiMode || 'local');
  const [hasGeminiKey, setHasGeminiKey] = useState<boolean>(false);
  const [isOpenMobile, setIsOpenMobile] = useState<boolean>(false);

  const [prompts, setPrompts] = useState<PromptItem[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [selectedPromptForBuilder, setSelectedPromptForBuilder] = useState<PromptItem | null>(null);

  // Initialize and load data from IndexedDB
  const loadData = async () => {
    try {
      const storedPrompts = await storageService.getPrompts();
      setPrompts(storedPrompts);
      setFavorites(storedPrompts.filter((p) => p.isFavorite).map((p) => p.id));

      const storedProjects = await storageService.getProjects();
      setProjects(storedProjects);
    } catch (err) {
      console.warn('Initial storage load error:', err);
    }
  };

  useEffect(() => {
    loadData();

    // Check backend health & Gemini secret availability
    geminiService.checkBackend().then((status) => {
      setHasGeminiKey(status.hasKey);
    });
  }, []);

  const handleToggleMode = (newMode: AIMode) => {
    setAiMode(newMode);
    const updated = { ...settings, aiMode: newMode };
    setSettings(updated);
    storageService.saveSettings(updated);
  };

  const handleNavigate = (sectionId: string) => {
    setActiveSection(sectionId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSavePrompt = async (item: PromptItem) => {
    const saved = await storageService.savePrompt(item);
    setPrompts((prev) => {
      const filtered = prev.filter((p) => p.id !== saved.id);
      return [saved, ...filtered];
    });
  };

  const handleDeletePrompt = async (id: string) => {
    await storageService.deletePrompt(id);
    setPrompts((prev) => prev.filter((p) => p.id !== id));
    setFavorites((prev) => prev.filter((favId) => favId !== id));
  };

  const handleToggleFavorite = async (id: string) => {
    const updated = await storageService.toggleFavorite(id);
    if (updated) {
      setPrompts((prev) => prev.map((p) => (p.id === id ? updated : p)));
      if (updated.isFavorite) {
        setFavorites((prev) => [...prev, id]);
      } else {
        setFavorites((prev) => prev.filter((f) => f !== id));
      }
    }
  };

  const handleSelectPromptForBuilder = (prompt: PromptItem) => {
    setSelectedPromptForBuilder(prompt);
    setActiveSection('prompt-builder');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#07090e] text-gray-100 flex flex-col font-sans selection:bg-purple-600 selection:text-white antialiased">
      {/* Offline Status Badge */}
      <OfflineIndicator />

      {/* Top Header */}
      <Header
        aiMode={aiMode}
        onToggleMode={handleToggleMode}
        hasGeminiKey={hasGeminiKey}
        onOpenMobileMenu={() => setIsOpenMobile(true)}
        onNavigate={handleNavigate}
      />

      <div className="flex flex-1 w-full max-w-[1600px] mx-auto">
        {/* Desktop Sidebar & Mobile Drawer */}
        <Sidebar
          activeSection={activeSection}
          onSelectSection={handleNavigate}
          isOpenMobile={isOpenMobile}
          onCloseMobile={() => setIsOpenMobile(false)}
          promptCount={prompts.length}
          favoriteCount={favorites.length}
        />

        {/* Main Content Area */}
        <main className="flex-1 w-full min-w-0 px-4 sm:px-8 py-6 max-w-7xl">
          {activeSection === 'dashboard' && (
            <DashboardSection
              aiMode={aiMode}
              onToggleMode={handleToggleMode}
              hasGeminiKey={hasGeminiKey}
              onNavigate={handleNavigate}
              prompts={prompts}
              projects={projects}
              onSelectPrompt={handleSelectPromptForBuilder}
            />
          )}

          {activeSection === 'prompt-builder' && (
            <PromptBuilderSection
              aiMode={aiMode}
              onSavePrompt={handleSavePrompt}
              selectedPrompt={selectedPromptForBuilder}
              onNavigate={handleNavigate}
            />
          )}

          {activeSection === 'image-generator' && (
            <ImageStudioSection
              aiMode={aiMode}
              onSavePrompt={handleSavePrompt}
              onNavigate={handleNavigate}
            />
          )}

          {activeSection === 'video-generator' && (
            <VideoStudioSection
              aiMode={aiMode}
              onSavePrompt={handleSavePrompt}
              onNavigate={handleNavigate}
            />
          )}

          {activeSection === 'auto-builder' && (
            <AutoBuilderSection
              aiMode={aiMode}
              onSavePrompt={handleSavePrompt}
              onNavigate={handleNavigate}
            />
          )}

          {activeSection === 'enhancer' && (
            <EnhancerSection
              aiMode={aiMode}
              onSavePrompt={handleSavePrompt}
              onNavigate={handleNavigate}
            />
          )}

          {activeSection === 'negative-generator' && (
            <NegativePromptSection onSavePrompt={handleSavePrompt} />
          )}

          {activeSection === 'ai-interview' && (
            <InterviewSection
              aiMode={aiMode}
              onSavePrompt={handleSavePrompt}
              onNavigate={handleNavigate}
            />
          )}

          {activeSection === 'storyboard' && (
            <StoryboardSection aiMode={aiMode} onNavigate={handleNavigate} />
          )}

          {activeSection === 'continuous-video' && (
            <ContinuousVideoSection aiMode={aiMode} onNavigate={handleNavigate} />
          )}

          {activeSection === 'image-analysis' && (
            <ImageAnalysisSection
              aiMode={aiMode}
              onSavePrompt={handleSavePrompt}
              onNavigate={handleNavigate}
            />
          )}

          {activeSection === 'comparison-lab' && (
            <ComparisonLabSection
              aiMode={aiMode}
              onSavePrompt={handleSavePrompt}
              onNavigate={handleNavigate}
            />
          )}

          {activeSection === 'library' && (
            <LibrarySection
              onSelectPromptForBuilder={handleSelectPromptForBuilder}
              onToggleFavorite={handleToggleFavorite}
              favorites={favorites}
            />
          )}

          {activeSection === 'platform-optimizer' && (
            <PlatformOptimizerSection
              aiMode={aiMode}
              onSavePrompt={handleSavePrompt}
              onNavigate={handleNavigate}
            />
          )}

          {activeSection === 'projects' && (
            <ProjectManagerSection
              projects={projects}
              prompts={prompts}
              onRefreshProjects={loadData}
              onNavigate={handleNavigate}
            />
          )}

          {activeSection === 'favorites' && (
            <FavoritesSection
              favorites={prompts.filter((p) => p.isFavorite)}
              onToggleFavorite={handleToggleFavorite}
              onSelectPrompt={handleSelectPromptForBuilder}
              onDeletePrompt={handleDeletePrompt}
              onNavigate={handleNavigate}
            />
          )}

          {activeSection === 'history' && (
            <HistorySection
              prompts={prompts}
              onSelectPrompt={handleSelectPromptForBuilder}
              onDeletePrompt={handleDeletePrompt}
              onNavigate={handleNavigate}
            />
          )}

          {activeSection === 'storage-manager' && (
            <StorageManagerSection onRefreshData={loadData} />
          )}

          {activeSection === 'import-export' && (
            <ImportExportSection
              prompts={prompts}
              projects={projects}
              onRefreshData={loadData}
            />
          )}

          {activeSection === 'settings' && (
            <SettingsSection
              settings={settings}
              onUpdateSettings={setSettings}
              hasGeminiKey={hasGeminiKey}
              onApiKeyChanged={() => {
                geminiService.checkBackend().then((status) => {
                  setHasGeminiKey(status.hasKey);
                });
              }}
            />
          )}

          {activeSection === 'help-center' && <HelpCenterSection />}
        </main>
      </div>

      {/* Mobile Bottom Navigation with min 44px targets */}
      <BottomNav
        activeSection={activeSection}
        onSelectSection={handleNavigate}
        onOpenMore={() => setIsOpenMobile(true)}
      />
    </div>
  );
}
