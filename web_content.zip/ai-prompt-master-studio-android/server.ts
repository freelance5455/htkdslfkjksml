import express from 'express';
import http from 'http';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();
process.env.DISABLE_HMR = 'true';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);

// CORS: allow the Capacitor Android WebView and an optional deployed frontend origin.
const allowedOrigins = new Set(['capacitor://localhost', 'http://localhost', 'https://localhost', ...(process.env.FRONTEND_ORIGIN ? [process.env.FRONTEND_ORIGIN] : [])]);
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && allowedOrigins.has(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
  }
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-gemini-api-key');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

app.use(express.json({ limit: '25mb' }));

// Helper to get Gemini client
function getGeminiClient(customKey?: string) {
  const apiKey = (customKey && customKey.trim()) || process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Extract custom API key from HTTP header or request body
function extractApiKey(req: express.Request): string | undefined {
  const headerKey = req.headers['x-gemini-api-key'];
  if (typeof headerKey === 'string' && headerKey.trim().length > 0) {
    return headerKey.trim();
  }
  if (req.body && typeof req.body.customApiKey === 'string' && req.body.customApiKey.trim().length > 0) {
    return req.body.customApiKey.trim();
  }
  return undefined;
}

// Health & Status endpoint
app.get('/api/health', (req, res) => {
  const customKey = extractApiKey(req);
  const serverKey = Boolean(process.env.GEMINI_API_KEY);
  const hasKey = Boolean(customKey || serverKey);
  res.json({
    status: 'ok',
    hasGeminiKey: hasKey,
    hasServerKey: serverKey,
    hasCustomKey: Boolean(customKey),
    defaultModel: 'gemini-3.8-flash',
    version: '3.0.0',
    modeSupported: ['local', 'gemini'],
  });
});

// Common Gemini caller with error classification
async function callGemini(
  modelName: string = 'gemini-3.8-flash',
  prompt: string,
  systemInstruction?: string,
  responseMimeType?: string,
  customKey?: string
) {
  const ai = getGeminiClient(customKey);
  if (!ai) {
    throw new Error('MISSING_API_KEY: Ingen Gemini API-nyckel hittades. Ange en egen API-nyckel under Inställningar eller konfigurera GEMINI_API_KEY i Secrets.');
  }

  const validModel = modelName || 'gemini-3.8-flash';
  const config: Record<string, unknown> = {};
  if (systemInstruction) {
    config.systemInstruction = systemInstruction;
  }
  if (responseMimeType) {
    config.responseMimeType = responseMimeType;
  }

  const response = await ai.models.generateContent({
    model: validModel,
    contents: prompt,
    config: Object.keys(config).length > 0 ? config : undefined,
  });

  return response.text || '';
}

// 0. API Key Verification endpoint
app.post('/api/gemini/test-key', async (req, res) => {
  try {
    const customKey = extractApiKey(req);
    const ai = getGeminiClient(customKey);
    if (!ai) {
      return res.status(400).json({
        success: false,
        error: 'Ingen API-nyckel tillhandahålls. Skriv in en nyckel eller ställ in GEMINI_API_KEY.',
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: 'Ping: Svara enbart med ordet OK.',
    });

    res.json({
      success: true,
      model: 'gemini-3.8-flash',
      response: (response.text || '').trim(),
      source: customKey ? 'custom' : 'server',
    });
  } catch (err: unknown) {
    console.error('Test API Key error:', err);
    const msg = err instanceof Error ? err.message : 'Kunde inte verifiera API-nyckeln';
    res.status(400).json({
      success: false,
      error: msg,
    });
  }
});

// 1. Prompt Builder & General Generation
app.post('/api/gemini/generate', async (req, res) => {
  try {
    const { model, prompt, systemInstruction, type } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const sysInstruction =
      systemInstruction ||
      `You are an expert AI prompt engineer specializing in hyper-realistic image synthesis (Midjourney, FLUX, Leonardo) and cinematic video models (Google Veo, Runway Gen-3, Sora, Kling AI). Provide structured, rich, professional prompts with exact camera specifications, lighting nuances, materials, composition, and negative prompt guidelines. Answer in the language requested or Swedish/English as appropriate.`;

    const customKey = extractApiKey(req);
    const text = await callGemini(model, prompt, sysInstruction, undefined, customKey);
    res.json({ result: text });
  } catch (err: unknown) {
    console.error('Gemini Generate Error:', err);
    const message = err instanceof Error ? err.message : 'Unknown generation error';
    res.status(500).json({ error: message });
  }
});

// 2. Prompt Auto-Builder (Expands brief concept into 12 dimensions)
app.post('/api/gemini/auto-build', async (req, res) => {
  try {
    const { idea, language = 'sv', model } = req.body;
    if (!idea) {
      return res.status(400).json({ error: 'Idea is required' });
    }

    const sys = `You are the master AI Prompt Auto-Builder. Given a user's brief idea, extrapolate all creative and technical dimensions.
Return ONLY valid JSON matching this structure:
{
  "subject": "Detailed main subject description, clothing, expressions",
  "action": "Pose, action, subtle movements",
  "environment": "Location, architecture, atmospheric details, weather",
  "timeAndWeather": "Exact time of day, meteorological conditions",
  "visualStyle": "Artistic or photographic style (e.g. 35mm film, hyperrealism)",
  "composition": "Framing, rule of thirds, golden ratio, depth of field",
  "cameraAndLens": "Camera model, lens (e.g., 35mm f/1.4, 85mm portrait)",
  "lighting": "Volumetric, rim light, golden hour, diffuse softbox, neon accents",
  "colorGrading": "Color palette, chromatic grading, tone curves",
  "materialsAndDetails": "Micro-textures, fabrics, surfaces, reflections",
  "technicalQuality": "Resolution, render parameters, octane, raytracing",
  "shortPrompt": "Punchy concise prompt (~25 words)",
  "detailedPrompt": "Rich narrative prompt (~70 words)",
  "professionalPrompt": "Studio grade prompt with photography gear & lighting (~100 words)",
  "ultimatePrompt": "Full master prompt integrating all 11 dimensions with highest aesthetic density",
  "negativePrompt": "Comprehensive negative prompt tailored to this motif"
}`;

    const customKey = extractApiKey(req);
    const promptText = `Analyze and expand this idea in ${language === 'sv' ? 'Swedish and English prompts' : 'English'}: "${idea}"`;
    const raw = await callGemini(model, promptText, sys, 'application/json', customKey);
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      // Clean possible markdown code fences
      const cleaned = raw.replace(/^```json/g, '').replace(/```$/g, '').trim();
      parsed = JSON.parse(cleaned);
    }
    res.json(parsed);
  } catch (err: unknown) {
    console.error('Auto-build error:', err);
    res.status(500).json({ error: err instanceof Error ? err.message : 'Auto-build error' });
  }
});

// 3. Prompt Enhancer Pro
app.post('/api/gemini/enhance', async (req, res) => {
  try {
    const { prompt, mode, language = 'sv', model } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const modeGuides: Record<string, string> = {
      realistic: 'Boost photorealism, subsurface scattering, authentic skin/material textures, 8k raw photo clarity.',
      cinematic: 'Add anamorphic lens characteristics, 35mm film grain, cinematic color grading, dramatic chiaroscuro lighting.',
      detailed: 'Greatly expand visual depth, architectural intricacies, micro-elements, and ambient environmental cues.',
      lighting: 'Supercharge the lighting description with volumetric god rays, rim lighting, specular highlights, and color temperatures.',
      camera: 'Specify high-end professional camera body (Hasselblad H6D-100c, ARRI Alexa Mini LF), focal length, aperture (f/1.2), shutter speed.',
      composition: 'Refine composition using Fibonacci spiral, dynamic symmetry, leading lines, negative space, and depth layering.',
      movement: 'Add kinetic energy, motion blur on fast elements, wind flow, fluid dynamics, and dynamic physics.',
      atmosphere: 'Amplify mood, mist, haze, emotional resonance, weather phenomena, and sensory atmosphere.',
      ultimate: 'Complete overhaul into an award-winning master prompt with optimal token weight and sensory richness.',
      shorten: 'Condense into high-efficiency keyword-dense format removing filler words while retaining aesthetic punch.',
      expand: 'Elaborate into a comprehensive multi-layered visual description covering foreground, midground, background, and rendering subtleties.',
      translate_en: 'Translate accurately to professional English prompt engineering vocabulary.',
      translate_sv: 'Translate accurately to Swedish creative phrasing.',
    };

    const instruction = modeGuides[mode] || modeGuides.ultimate;
    const sys = `You are the AI Prompt Enhancer Pro. Your mission:
${instruction}
Return a JSON object:
{
  "original": "Original input prompt",
  "enhanced": "Enhanced prompt",
  "changes": ["Change 1", "Change 2", "Change 3"],
  "qualityScoreLocal": 85,
  "negativePrompt": "Tailored negative prompt",
  "reasoning": "Explanation of why these improvements boost the generative model output"
}`;

    const customKey = extractApiKey(req);
    const raw = await callGemini(model, `Input prompt: "${prompt}"\nLanguage: ${language}`, sys, 'application/json', customKey);
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      const cleaned = raw.replace(/^```json/g, '').replace(/```$/g, '').trim();
      parsed = JSON.parse(cleaned);
    }
    res.json(parsed);
  } catch (err: unknown) {
    console.error('Enhancer error:', err);
    res.status(500).json({ error: err instanceof Error ? err.message : 'Enhancer error' });
  }
});

// 4. AI Interactive Interview
app.post('/api/gemini/interview', async (req, res) => {
  try {
    const { idea, history = [], action = 'next', language = 'sv', model } = req.body;
    const customKey = extractApiKey(req);

    if (action === 'finalize') {
      const sys = `Synthesize all interview questions and answers into a definitive master image/video prompt.
Return JSON:
{
  "summary": "Summary of user vision",
  "masterPrompt": "The final ultimate prompt ready for Midjourney/FLUX/Veo",
  "negativePrompt": "Complementary negative prompt",
  "technicalSettings": {
    "aspectRatio": "16:9",
    "camera": "Camera & lens choice",
    "lighting": "Lighting setup",
    "style": "Visual style"
  }
}`;
      const content = `Original idea: ${idea}\nInterview history:\n${JSON.stringify(history, null, 2)}`;
      const raw = await callGemini(model, content, sys, 'application/json', customKey);
      return res.json(JSON.parse(raw));
    }

    // Generate next dynamic question
    const sys = `You are conducting an intelligent creative interview to uncover missing visual elements for a professional image or video prompt.
Analyze the idea and previous answers. Ask ONE insightful question focusing on an aspect that has NOT yet been addressed (e.g. subject styling, mood, lighting, camera angle, setting time, artistic style).
Provide 3-4 suggested quick-pick options as well as allowing custom input.
If sufficient detail is already gathered (after 3-5 questions) or user requested, set "canFinalize": true.
Return JSON:
{
  "questionNumber": ${history.length + 1},
  "question": "The question in ${language === 'sv' ? 'Swedish' : 'English'}",
  "category": "Lighting / Camera / Atmosphere / Subject / Action / Environment",
  "options": ["Option 1", "Option 2", "Option 3", "Option 4"],
  "canFinalize": false,
  "insight": "Brief observation about why this detail will elevate the prompt"
}`;

    const promptText = `Initial idea: "${idea}"\nCompleted Q&A rounds:\n${JSON.stringify(history)}`;
    const raw = await callGemini(model, promptText, sys, 'application/json', customKey);
    res.json(JSON.parse(raw));
  } catch (err: unknown) {
    console.error('Interview error:', err);
    res.status(500).json({ error: err instanceof Error ? err.message : 'Interview error' });
  }
});

// 5. Storyboard Creator (5 to 20 scenes)
app.post('/api/gemini/storyboard', async (req, res) => {
  try {
    const { concept, sceneCount = 6, style = 'Cinematic', language = 'sv', model } = req.body;
    const count = Math.min(Math.max(Number(sceneCount) || 6, 3), 20);

    const sys = `You are a Hollywood director and visual prompt architect.
Create a coherent ${count}-scene cinematic storyboard for video generation (Veo, Sora, Runway Gen-3).
Crucial: Maintain character consistency, visual style, color palette, and environmental lighting across all scenes.
Return JSON array of scenes:
[
  {
    "sceneNumber": 1,
    "title": "Scene title",
    "description": "Narrative beat",
    "subject": "Character/focus with clothing & appearance",
    "action": "Specific movement in scene",
    "environment": "Setting and spatial layout",
    "timeAndWeather": "Time of day & weather",
    "cameraAngle": "Wide shot / Close up / Low angle",
    "cameraMovement": "Dolly in / Tracking shot / Crane / Orbit / Static",
    "lighting": "Lighting details",
    "colorPalette": "Dominant tones",
    "startFramePrompt": "Detailed visual description of first frame",
    "endFramePrompt": "Detailed visual description of ending frame",
    "videoPrompt": "Complete ready-to-use prompt for AI video generator including camera direction",
    "negativePrompt": "Negative prompt for video artifacts",
    "continuityNotes": "Continuity anchors to carry into next scene"
  }
]`;

    const customKey = extractApiKey(req);
    const promptText = `Film Concept: "${concept}"\nTotal Scenes: ${count}\nVisual Style: ${style}\nLanguage: ${language === 'sv' ? 'Swedish descriptions with English ready-prompts' : 'English'}`;
    const raw = await callGemini(model, promptText, sys, 'application/json', customKey);
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      const cleaned = raw.replace(/^```json/g, '').replace(/```$/g, '').trim();
      parsed = JSON.parse(cleaned);
    }
    res.json({ scenes: parsed });
  } catch (err: unknown) {
    console.error('Storyboard error:', err);
    res.status(500).json({ error: err instanceof Error ? err.message : 'Storyboard error' });
  }
});

// 6. Continuous Video Creator (Maintains characters, environment, props, lighting)
app.post('/api/gemini/continuous-video', async (req, res) => {
  try {
    const {
      characterProfile,
      environmentRules,
      lockedElements,
      previousScenes = [],
      nextAction,
      language = 'sv',
      model,
    } = req.body;

    const sys = `You are an AI Continuity Master for video generation.
Ensure absolute continuity of:
- Character face, hair, clothing, signature accessories
- Environment geography, props, architecture
- Color grading LUT, lighting direction, focal length
Generate the next sequential scene prompt and continuity delta.
Return JSON:
{
  "sceneIndex": ${previousScenes.length + 1},
  "title": "Scene Title",
  "narrativeAction": "What happens in this scene",
  "subjectStatus": "Character state, pose, expression",
  "cameraDirection": "Exact camera rig movement (e.g. 50mm lens, slow tracking pan left-to-right)",
  "videoPrompt": "Full continuous video prompt incorporating locked character and style tokens",
  "negativePrompt": "Negative prompt preventing morphing, face drifting, wardrobe change",
  "continuityChecklist": [
    "Wardrobe locked",
    "Lighting match verified",
    "Focal depth maintained"
  ],
  "timelineKeyframes": [
    {"second": "0s", "action": "Starting keyframe"},
    {"second": "3s", "action": "Mid-shot transition"},
    {"second": "5s", "action": "Ending state for next continuation"}
  ]
}`;

    const promptText = `
Character Profile: ${JSON.stringify(characterProfile)}
Environment: ${JSON.stringify(environmentRules)}
Locked Elements: ${JSON.stringify(lockedElements)}
Previous Scenes: ${JSON.stringify(previousScenes.slice(-2))}
Next Desired Action: "${nextAction}"
Language: ${language}
`;

    const customKey = extractApiKey(req);
    const raw = await callGemini(model, promptText, sys, 'application/json', customKey);
    res.json(JSON.parse(raw));
  } catch (err: unknown) {
    console.error('Continuous video error:', err);
    res.status(500).json({ error: err instanceof Error ? err.message : 'Continuous video error' });
  }
});

// 7. Image Analysis Lab (Multimodal analysis with Gemini)
app.post('/api/gemini/analyze-image', async (req, res) => {
  try {
    const { imageBase64, mimeType = 'image/jpeg', language = 'sv', model } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ error: 'Image base64 data is required' });
    }

    const customKey = extractApiKey(req);
    const ai = getGeminiClient(customKey);
    if (!ai) {
      throw new Error('MISSING_API_KEY: Gemini API-nyckel krävs för AI-bildanalys. Ange din nyckel under Inställningar.');
    }

    const cleanBase64 = imageBase64.includes('base64,')
      ? imageBase64.split('base64,')[1]
      : imageBase64;

    const promptText = `Deconstruct this image with extreme photographic and artistic precision for prompt engineering.
Return JSON:
{
  "subject": "Subject description, features, clothing, pose",
  "environment": "Environment setting, architectural or natural context",
  "lighting": "Key light, fill light, shadows, reflections, color temperature",
  "composition": "Focal depth, framing, aspect ratio estimation, rule of thirds",
  "cameraLens": "Estimated camera system, focal length (e.g., 50mm, 85mm), aperture",
  "style": "Visual aesthetic (photorealism, anime, baroque, cyberpunk, 35mm film)",
  "colorPalette": ["#hex1", "#hex2", "#hex3", "#hex4", "#hex5"],
  "reconstructedPrompt": "The ultimate prompt that would reproduce this visual quality and style in FLUX/Midjourney",
  "negativePrompt": "Tailored negative prompt to avoid artifacts",
  "keyTags": ["tag1", "tag2", "tag3", "tag4", "tag5"]
}`;

    const response = await ai.models.generateContent({
      model: model || 'gemini-3.8-flash',
      contents: [
        {
          inlineData: {
            mimeType: mimeType,
            data: cleanBase64,
          },
        },
        {
          text: promptText,
        },
      ],
      config: {
        responseMimeType: 'application/json',
      },
    });

    const raw = response.text || '{}';
    res.json(JSON.parse(raw));
  } catch (err: unknown) {
    console.error('Image analysis error:', err);
    res.status(500).json({ error: err instanceof Error ? err.message : 'Image analysis error' });
  }
});

// 8. Prompt Comparison Lab
app.post('/api/gemini/compare', async (req, res) => {
  try {
    const { prompts = [], language = 'sv', model } = req.body;
    if (!Array.isArray(prompts) || prompts.length < 2) {
      return res.status(400).json({ error: 'At least 2 prompts required for comparison' });
    }

    const sys = `Compare and contrast the provided prompts for AI image/video synthesis.
Evaluate strengths, weaknesses, conflicts, redundancies, and missing elements.
Propose a synthesized Master Prompt that merges the strongest elements of each.
Return JSON:
{
  "evaluations": [
    {
      "index": 1,
      "score": 88,
      "strengths": ["Strengths"],
      "weaknesses": ["Weaknesses"],
      "clarity": "High/Med/Low",
      "conflicts": ["Any contradictory terms"]
    }
  ],
  "commonElements": ["Shared concepts"],
  "missingElements": ["Elements none of them specified"],
  "synthesisMasterPrompt": "Merged hybrid prompt taking the best from all",
  "synthesisNegativePrompt": "Complementary negative prompt",
  "recommendations": "Actionable prompt engineering advice"
}`;

    const customKey = extractApiKey(req);
    const promptText = `Compare these prompts:\n${JSON.stringify(prompts, null, 2)}`;
    const raw = await callGemini(model, promptText, sys, 'application/json', customKey);
    res.json(JSON.parse(raw));
  } catch (err: unknown) {
    console.error('Comparison error:', err);
    res.status(500).json({ error: err instanceof Error ? err.message : 'Comparison error' });
  }
});

// 9. Platform Optimizer
app.post('/api/gemini/optimize-platform', async (req, res) => {
  try {
    const { prompt, targetPlatform, mediaType = 'image', model } = req.body;
    if (!prompt || !targetPlatform) {
      return res.status(400).json({ error: 'Prompt and targetPlatform are required' });
    }

    const sys = `You are a specialist in AI model idiosyncrasies.
Target platform: ${targetPlatform} (Type: ${mediaType}).
Optimize the prompt strictly following the platform's syntax, parameter weights, token ordering conventions, and vocabulary strengths.
E.g.:
- Midjourney: comma-separated descriptive phrases, aesthetic terms, --ar, --v, --stylize flags if requested.
- FLUX: natural language narrative, clear spatial relationships, direct typography quotes.
- Stable Diffusion: weighted tokens (keyword:1.2), explicit tag syntax, detailed negative prompt.
- Google Veo: clear camera rig movement, temporal progression, cinematic lighting.
- Runway Gen-3 / Sora / Kling: temporal cues, start/end frames, smooth dynamic vectors.
Return JSON:
{
  "platform": "${targetPlatform}",
  "optimizedPrompt": "Tailored prompt",
  "negativePrompt": "Tailored negative prompt",
  "recommendedSettings": {
    "aspectRatio": "16:9",
    "steps": 30,
    "guidanceScale": 7.0,
    "additionalParams": "Platform specific flags or recommendations"
  },
  "explanation": "Why this formatting yields peak results on this platform"
}`;

    const customKey = extractApiKey(req);
    const raw = await callGemini(model, `Input prompt: "${prompt}"`, sys, 'application/json', customKey);
    res.json(JSON.parse(raw));
  } catch (err: unknown) {
    console.error('Platform optimizer error:', err);
    res.status(500).json({ error: err instanceof Error ? err.message : 'Platform optimizer error' });
  }
});

// Vite middleware in dev or static files in production
async function startServer() {
  const httpServer = http.createServer(app);

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR === 'true' ? false : { server: httpServer },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`AI Prompt Master Studio Ultimate server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
