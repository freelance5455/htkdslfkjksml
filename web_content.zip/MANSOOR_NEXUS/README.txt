MANSOOR NEXUS — Offline Mobile HTML App
Creator: Mansoor Niazi (منصور نیازي)
Languages: Pashto and English
Version: 1.0

HOW TO USE
1. Extract this ZIP on your Android phone.
2. Open index.html using Chrome or another modern browser.
3. Tap the language button to switch Pashto/English.
4. No internet connection or external libraries are required.

FEATURES
- Animated space-themed interface
- Pashto and English UI
- Math-based mind trick (not actual mind reading)
- Touch particle effects
- Offline facts and idea cards
- Calculator, random picker, focus timer
- Local notes saved in browser storage
- Five-question knowledge quiz

NOTE
This is an offline HTML web app, not a compiled Android APK. For notes to persist, open the file in the same browser. Browser behavior for local files can vary.
