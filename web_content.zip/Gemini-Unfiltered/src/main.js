import './style.css';
import { CreateMLCEngine } from '@mlc-ai/web-llm';

const $ = (s) => document.querySelector(s);
const state = {
  mode: localStorage.getItem('gu_mode') || 'local',
  messages: JSON.parse(localStorage.getItem('gu_messages') || '[]'),
  engine: null,
  loading: false
};
const MODEL_ID = 'Llama-3.2-1B-Instruct-q4f16_1-MLC';

$('#app').innerHTML = `
  <aside class="sidebar" id="sidebar">
    <div class="brand"><div class="gem">✦</div><div><b>Gemini Unfiltered</b><small>Assistente híbrido</small></div></div>
    <button class="new-chat" id="newChat">＋ Nova conversa</button>
    <div class="side-label">RECENTES</div>
    <div id="history" class="history"></div>
    <div class="side-bottom">
      <button class="side-link" id="settingsOpen">⚙ Configurações</button>
      <div class="local-note">Suas conversas ficam neste dispositivo.</div>
    </div>
  </aside>
  <main class="main">
    <header><button class="icon-btn mobile-menu" id="menuBtn">☰</button><div class="header-title">Gemini Unfiltered</div><button class="icon-btn" id="settingsTop" aria-label="Configurações">⚙</button></header>
    <section class="chat-wrap">
      <div class="welcome" id="welcome"><div class="welcome-star">✦</div><h1>Olá! O que vamos<br><span>explorar hoje?</span></h1><p>Converse, crie histórias e desenvolva ideias com sua IA.</p>
        <div class="suggestions"><button data-prompt="Crie uma história de fantasia com personagens complexos.">✧ Criar uma história</button><button data-prompt="Ajude-me a desenvolver um personagem fictício.">♧ Desenvolver personagem</button><button data-prompt="Vamos conversar sobre uma ideia que tive.">☼ Explorar uma ideia</button></div>
      </div>
      <div id="messages" class="messages"></div>
    </section>
    <footer>
      <div class="composer">
        <textarea id="prompt" rows="1" placeholder="Converse com o Gemini Unfiltered..." aria-label="Mensagem"></textarea>
        <div class="composer-bottom"><button class="mode-chip" id="modeChip"><span class="status-dot"></span><span id="modeLabel">IA local</span> ▾</button><div class="send-area"><span id="status" class="status"></span><button id="send" class="send-btn" aria-label="Enviar">↑</button></div></div>
      </div>
      <p class="disclaimer">A IA pode cometer erros. Modelos locais e online têm capacidades e políticas próprias.</p>
    </footer>
  </main>
  <div class="modal-backdrop hidden" id="settingsModal">
    <section class="modal">
      <div class="modal-head"><h2>Configurações</h2><button class="icon-btn" id="settingsClose">✕</button></div>
      <label>Modo de conversa</label>
      <div class="mode-options"><button id="chooseLocal" class="mode-option"><b>▣ IA local</b><small>Executada no aparelho. Requer WebGPU e download do modelo.</small></button><button id="chooseOnline" class="mode-option"><b>☁ IA online</b><small>Usa um endpoint compatível com a API da OpenAI.</small></button></div>
      <div class="field"><label for="endpoint">Endpoint online</label><input id="endpoint" placeholder="https://seu-servidor/v1/chat/completions"></div>
      <div class="field"><label for="apiKey">Chave da API</label><input id="apiKey" type="password" placeholder="Cole sua chave (opcional para servidores locais)"></div>
      <div class="field"><label for="modelName">Nome do modelo online</label><input id="modelName" placeholder="ex.: modelo-que-seu-provedor-oferece"></div>
      <p class="small-warning">A chave é guardada somente no armazenamento local deste app. Não use uma chave corporativa ou compartilhada. Para distribuição pública, o ideal é usar um backend/proxy seguro.</p>
      <button class="save-btn" id="saveSettings">Salvar configurações</button>
    </section>
  </div>
  <div class="toast" id="toast"></div>
`;

function persist() {
  localStorage.setItem('gu_messages', JSON.stringify(state.messages));
  localStorage.setItem('gu_mode', state.mode);
}
function escapeHTML(s) {
  return s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function toast(msg) {
  const el = $('#toast'); el.textContent = msg; el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 3200);
}
function render() {
  $('#welcome').classList.toggle('hidden', state.messages.length > 0);
  $('#messages').innerHTML = state.messages.map(m => `
    <article class="message ${m.role}">
      <div class="avatar">${m.role === 'user' ? '●' : '✦'}</div>
      <div class="bubble"><div class="role">${m.role === 'user' ? 'Você' : 'Gemini Unfiltered'}</div><div class="content">${escapeHTML(m.content).replace(/\n/g,'<br>')}</div></div>
    </article>`).join('');
  $('#messages').scrollTop = $('#messages').scrollHeight;
  $('#history').innerHTML = state.messages.length ? `<button class="history-item">${escapeHTML((state.messages.find(m=>m.role==='user')?.content || 'Conversa').slice(0,42))}</button>` : '<div class="empty-history">Suas conversas aparecerão aqui.</div>';
  $('#modeLabel').textContent = state.mode === 'local' ? 'IA local' : 'IA online';
}
function setMode(mode) { state.mode = mode; persist(); render(); }
async function ensureLocalEngine() {
  if (state.engine) return state.engine;
  if (!('gpu' in navigator)) throw new Error('WebGPU não está disponível neste navegador/aparelho. Tente o modo online.');
  $('#status').textContent = 'Preparando modelo local…';
  state.engine = await CreateMLCEngine(MODEL_ID, {
    initProgressCallback: p => { $('#status').textContent = p.text || 'Baixando modelo…'; }
  });
  return state.engine;
}
async function askLocal(history) {
  const engine = await ensureLocalEngine();
  const response = await engine.chat.completions.create({
    messages: [{role:'system', content:'Você é um assistente útil, criativo e respeitoso. Siga as regras de segurança aplicáveis e trate personagens fictícios adultos de forma apropriada.'}, ...history.map(m=>({role:m.role,content:m.content}))],
    temperature: 0.8
  });
  return response.choices?.[0]?.message?.content || 'Não consegui gerar uma resposta.';
}
async function askOnline(history) {
  const endpoint = localStorage.getItem('gu_endpoint') || '';
  const key = localStorage.getItem('gu_key') || '';
  const model = localStorage.getItem('gu_model') || '';
  if (!endpoint || !model) throw new Error('Configure o endpoint e o nome do modelo nas configurações.');
  const headers = {'Content-Type':'application/json'};
  if (key) headers.Authorization = `Bearer ${key}`;
  const res = await fetch(endpoint, {
    method:'POST', headers,
    body:JSON.stringify({model, messages:[{role:'system',content:'Você é um assistente útil, criativo e respeitoso. Siga as regras de segurança aplicáveis.'}, ...history.map(m=>({role:m.role,content:m.content}))], temperature:0.8, stream:false})
  });
  if (!res.ok) throw new Error(`Servidor respondeu HTTP ${res.status}. Confira endpoint, chave e modelo.`);
  const data = await res.json();
  return data.choices?.[0]?.message?.content || 'O servidor não retornou uma resposta.';
}
async function send() {
  const text = $('#prompt').value.trim();
  if (!text || state.loading) return;
  state.loading = true; $('#prompt').value = ''; $('#send').disabled = true;
  state.messages.push({role:'user',content:text}); render(); persist();
  $('#status').textContent = 'Pensando…';
  try {
    const answer = state.mode === 'local' ? await askLocal(state.messages) : await askOnline(state.messages);
    state.messages.push({role:'assistant',content:answer});
  } catch (e) {
    state.messages.push({role:'assistant',content:`Não consegui responder: ${e.message}\n\nVocê pode mudar para IA online ou revisar as configurações.`});
  } finally {
    state.loading = false; $('#send').disabled = false; $('#status').textContent = ''; render(); persist();
  }
}
$('#send').addEventListener('click', send);
$('#prompt').addEventListener('keydown', e => { if(e.key==='Enter' && !e.shiftKey){e.preventDefault();send();} });
$('#newChat').addEventListener('click',()=>{state.messages=[];persist();render();$('#sidebar').classList.remove('open');});
$('#menuBtn').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
function openSettings() {
  $('#endpoint').value = localStorage.getItem('gu_endpoint') || '';
  $('#apiKey').value = localStorage.getItem('gu_key') || '';
  $('#modelName').value = localStorage.getItem('gu_model') || '';
  $('#settingsModal').classList.remove('hidden');
}
$('#settingsOpen').addEventListener('click',openSettings);
$('#settingsTop').addEventListener('click',openSettings);
$('#settingsClose').addEventListener('click',()=>$('#settingsModal').classList.add('hidden'));
$('#chooseLocal').addEventListener('click',()=>{setMode('local');toast('Modo local selecionado.');});
$('#chooseOnline').addEventListener('click',()=>{setMode('online');toast('Modo online selecionado.');});
$('#modeChip').addEventListener('click',()=>{setMode(state.mode==='local'?'online':'local');toast(`Modo ${state.mode==='local'?'local':'online'} selecionado.`);});
$('#saveSettings').addEventListener('click',()=>{
  localStorage.setItem('gu_endpoint',$('#endpoint').value.trim());
  localStorage.setItem('gu_key',$('#apiKey').value.trim());
  localStorage.setItem('gu_model',$('#modelName').value.trim());
  $('#settingsModal').classList.add('hidden'); toast('Configurações salvas neste dispositivo.');
});
document.querySelectorAll('[data-prompt]').forEach(b=>b.addEventListener('click',()=>{$('#prompt').value=b.dataset.prompt;$('#prompt').focus();}));
render();
