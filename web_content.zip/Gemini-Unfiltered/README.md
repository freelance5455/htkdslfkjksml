# Gemini Unfiltered — versão inicial 0.1

Aplicativo Android híbrido com interface de chat, modo local via WebLLM e modo online por endpoint compatível com OpenAI Chat Completions.

## Requisitos
- Node.js 20+
- Android Studio/SDK para compilar localmente, ou GitHub Actions para gerar o APK.
- Para IA local: navegador/WebView com WebGPU e memória suficiente. O primeiro uso baixa o modelo; o tamanho do download pode ser grande.
- Para IA online: endpoint e nome de modelo fornecidos pelo usuário.

## Testar no computador
```bash
npm install
npm run dev
```

## Gerar projeto Android
```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

## Gerar APK pelo GitHub Actions
1. Crie um repositório GitHub vazio.
2. Envie todos os arquivos deste projeto para a branch `main`.
3. Abra a aba Actions e execute **Build Android APK** (ou aguarde o build após o push).
4. Baixe o artefato `Gemini-Unfiltered-debug-apk`.

## Observações importantes
- O nome Gemini Unfiltered é o nome deste projeto independente; ele não é um produto oficial do Google nem contém o modelo Gemini.
- O modo online exige que você tenha acesso legítimo a um provedor e endpoint. Não coloque chaves privadas em repositórios públicos. Nesta versão inicial a chave é guardada no armazenamento local do app; para distribuição, substitua por um backend/proxy seguro.
- O modo local depende de WebGPU, compatibilidade do Android System WebView e memória disponível. A disponibilidade deve ser testada no aparelho.
- O app não remove as políticas dos modelos conectados. Cada provedor/modelo mantém suas próprias regras.
- Esta é uma base funcional inicial, ainda sem sincronização na nuvem, contas, exportação de conversas ou memória persistente avançada.
