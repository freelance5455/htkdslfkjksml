# MangaShelf Android

A simple offline manga reader packaged as an Android WebView app.

## Build
Upload this folder as a ZIP to an Android project builder and choose **Build APK**.

The app supports local manga images through the Add Manga button. The WebView file chooser supports selecting multiple images.
