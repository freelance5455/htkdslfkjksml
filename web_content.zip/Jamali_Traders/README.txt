JAMALI TRADERS — CAMERA + CLEAR KHATA + BILL PAID

CONTENTS
- index.html: the browser-based Jamali Traders preview.

HOW TO OPEN
1. Extract this ZIP on your Android phone.
2. Open the Jamali_Traders folder.
3. Open index.html in Chrome.
4. Use the "Open Camera" button to capture a bill photo.

IMPORTANT LIMITATIONS
- This is an HTML/browser preview, not an Android APK or Android Studio project.
- Camera access depends on your phone/browser support.
- Bill reading is currently DEMO only. It does not perform real AI/OCR.
- Data is stored locally in the browser on that device/browser. It is not synced online.
- For a production Android app, this HTML must be integrated into the Android project and real OCR/backend features must be implemented.
