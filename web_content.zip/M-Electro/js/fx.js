// مؤثرات الاحتراق: وميض + شرر + دخان + صوت + اهتزاز
(() => {
  const NS = 'http://www.w3.org/2000/svg';
  const layer = document.createElementNS(NS, 'g');
  layer.id = 'fx';
  ME.world.appendChild(layer);

  let ac = null;
  ME.initAudio = () => {
    try {
      ac = ac || new (window.AudioContext || window.webkitAudioContext)();
      if (ac.state === 'suspended') ac.resume();
    } catch {}
  };
  function pop() {
    try {
      if (!ac) return;
      const len = Math.floor(0.2 * ac.sampleRate);
      const buf = ac.createBuffer(1, len, ac.sampleRate), d = buf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3);
      const src = ac.createBufferSource(), g = ac.createGain();
      src.buffer = buf; g.gain.value = 0.35;
      src.connect(g); g.connect(ac.destination); src.start();
    } catch {}
  }

  ME.burn = c => {
    const g = document.createElementNS(NS, 'g');
    g.setAttribute('class', 'fx');
    g.setAttribute('transform', `translate(${c.x} ${c.y})`);
    let h = '<circle class="flash" r="34"/>';
    for (let i = 0; i < 9; i++) {
      const a = Math.PI * 2 * i / 9 + Math.random() * 0.5, d = 40 + Math.random() * 45;
      h += `<circle class="spark" r="2.6" style="--dx:${(Math.cos(a) * d).toFixed(1)}px;--dy:${(Math.sin(a) * d).toFixed(1)}px"/>`;
    }
    for (let i = 0; i < 4; i++)
      h += `<circle class="smoke" r="${12 + i * 3}" cx="${((Math.random() - 0.5) * 20).toFixed(1)}" style="--d:${i * 0.25}s;--dx:${((Math.random() - 0.5) * 50).toFixed(1)}px"/>`;
    g.innerHTML = h;
    layer.appendChild(g);
    setTimeout(() => g.remove(), 3400);
    pop();
    try { navigator.vibrate && navigator.vibrate(90); } catch {}
  };
})();