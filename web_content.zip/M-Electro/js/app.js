(() => {
  const $ = id => document.getElementById(id);
  const svg = $('canvas'), world = $('world'), statusEl = $('status');
  const view = { x: 0, y: 0, k: 1 };
  let msg = 'تحديد';

  const paint = () => { statusEl.textContent = `${msg} · ${Math.round(view.k * 100)}%`; };
  const applyView = () => {
    world.setAttribute('transform', `translate(${view.x} ${view.y}) scale(${view.k})`);
    paint();
  };
  window.ME = { svg, world, view, busy: false, setStatus: t => { msg = t; paint(); } };

  // ---- تحريك وتكبير ----
  const pts = new Map();
  let lastDist = 0, lastMid = null;
  const local = e => {
    const r = svg.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };
  const pinchInfo = () => {
    const [a, b] = [...pts.values()];
    return { dist: Math.hypot(a.x - b.x, a.y - b.y), mid: { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 } };
  };

  svg.addEventListener('pointerdown', e => {
    svg.setPointerCapture(e.pointerId);
    pts.set(e.pointerId, local(e));
    if (pts.size === 2) { const p = pinchInfo(); lastDist = p.dist; lastMid = p.mid; }
  });
  svg.addEventListener('pointermove', e => {
    if (!pts.has(e.pointerId)) return;
    const prev = pts.get(e.pointerId), cur = local(e);
    pts.set(e.pointerId, cur);
    if (pts.size === 1) {
      if (!ME.busy) { view.x += cur.x - prev.x; view.y += cur.y - prev.y; }
    } else if (pts.size === 2) {
      const p = pinchInfo();
      const wx = (lastMid.x - view.x) / view.k, wy = (lastMid.y - view.y) / view.k;
      view.k = Math.min(6, Math.max(0.25, view.k * p.dist / lastDist));
      view.x = p.mid.x - wx * view.k; view.y = p.mid.y - wy * view.k;
      lastDist = p.dist; lastMid = p.mid;
    }
    applyView();
  });
  const end = e => { pts.delete(e.pointerId); lastMid = null; };
  svg.addEventListener('pointerup', end);
  svg.addEventListener('pointercancel', end);
  svg.addEventListener('wheel', e => {
    e.preventDefault();
    const m = local(e);
    const wx = (m.x - view.x) / view.k, wy = (m.y - view.y) / view.k;
    view.k = Math.min(6, Math.max(0.25, view.k * (e.deltaY < 0 ? 1.1 : 0.9)));
    view.x = m.x - wx * view.k; view.y = m.y - wy * view.k;
    applyView();
  }, { passive: false });

  // ---- الشاشات ----
  let centered = false;
  const go = s => {
    document.body.dataset.screen = s;
    if (s === 'editor' && !centered) {
      centered = true;
      requestAnimationFrame(() => {
        const r = svg.getBoundingClientRect();
        view.x = r.width / 2; view.y = r.height / 2; applyView();
      });
    }
  };
  $('openFree').addEventListener('click', () => go('editor'));
  $('btnHome').addEventListener('click', () => go('home'));
  $('openAbout').addEventListener('click', () => $('aboutDlg').showModal());

  // ---- السمة ----
  const root = document.documentElement;
  try { root.dataset.theme = localStorage.getItem('me-theme') || 'dark'; }
  catch { root.dataset.theme = 'dark'; }
  document.querySelectorAll('.theme-btn').forEach(b => b.addEventListener('click', () => {
    root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark';
    try { localStorage.setItem('me-theme', root.dataset.theme); } catch {}
  }));

  // ---- زر التشغيل (الحالة تُدار في sim.js) ----
  const run = $('btnRun');
  run.addEventListener('click', () => {
    run.classList.toggle('on');
    run.textContent = run.classList.contains('on') ? '■ إيقاف' : '▶ تشغيل';
  });

  applyView();
})();