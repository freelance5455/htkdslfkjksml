(() => {
  const NS = 'http://www.w3.org/2000/svg';
  const { svg, world, view } = ME;
  const GRID = 20;
  const $ = id => document.getElementById(id);
  const toolbar = $('toolbar'), actions = $('actions'), sheet = $('sheet');
  const dlg = $('valueDlg'), inp = $('valueInput');

  const mk = (tag, attrs = {}) => {
    const el = document.createElementNS(NS, tag);
    for (const k in attrs) el.setAttribute(k, attrs[k]);
    return el;
  };
  const snap = v => Math.round(v / GRID) * GRID;
  const same = (a, b) => a.c === b.c && a.t === b.t;

  const layerWires = mk('g', { id: 'wires' });
  const layerComps = mk('g', { id: 'comps' });
  world.append(layerWires, layerComps);

  const comps = new Map(), wires = new Map(), counters = {};
  let uid = 0, tool = 'select', placing = null, pending = null, selected = null;
  Object.assign(ME, { comps, wires });

  // ---------- الأدوات ----------
  function setTool(t, part) {
    tool = t; placing = part || null;
    toolbar.querySelectorAll('[data-tool]').forEach(b => b.classList.toggle('active', b.dataset.tool === t));
    $('btnAdd').classList.toggle('active', t === 'place');
    clearPending();
    ME.setStatus(t === 'place' ? 'انقر على اللوحة لوضع: ' + PARTS[part].name
                : t === 'wire' ? 'سلك: اختر طرفين' : 'تحديد');
  }
  toolbar.addEventListener('click', e => {
    const b = e.target.closest('.tool');
    if (!b) return;
    if (b.id === 'btnAdd') { sheet.hidden = !sheet.hidden; select(null); return; }
    sheet.hidden = true; select(null); setTool(b.dataset.tool);
  });

  // ---------- المكتبة ----------
  const CATS = { sources: 'المصادر', passive: 'العناصر السلبية', ctrl: 'التحكم والإشارة',
                 meters: 'أجهزة القياس', protect: 'الحماية', semi: 'أشباه الموصلات' };
  function buildSheet() {
    let html = '';
    for (const cat in CATS) {
      const items = Object.entries(PARTS).filter(([, p]) => p.cat === cat);
      if (!items.length) continue;
      html += `<h4>${CATS[cat]}</h4><div class="grid">` + items.map(([k, p]) =>
        `<button class="item" data-part="${k}"><svg viewBox="-75 -75 150 150">${p.draw({ value: p.def })}</svg><span>${p.name}</span></button>`
      ).join('') + '</div>';
    }
    $('sheetBody').innerHTML = html;
  }
  $('sheetBody').addEventListener('click', e => {
    const b = e.target.closest('.item');
    if (!b) return;
    sheet.hidden = true; select(null); setTool('place', b.dataset.part);
  });
  $('sheetClose').addEventListener('click', () => { sheet.hidden = true; });

  // ---------- العناصر ----------
  function addComp(type, x, y, s) {
    const P = PARTS[type];
    counters[P.prefix] = (counters[P.prefix] || 0) + 1;
    const c = { id: 'c' + (++uid), type, x, y, rot: 0, flip: false,
                value: P.def, name: P.prefix + counters[P.prefix] };
    if (s) Object.assign(c, s);
    const g = mk('g', { class: 'comp', 'data-id': c.id });
    layerComps.appendChild(g);
    c.el = g; comps.set(c.id, c);
    render(c);
    return c;
  }

  function render(c) {
    const P = PARTS[c.type];
    const val = P.def == null ? '' : ' · ' + eng(c.value) + P.unit;
    c.el.setAttribute('transform', `translate(${c.x} ${c.y})`);
    c.el.innerHTML =
      `<g class="rot" transform="rotate(${c.rot}) scale(${c.flip ? -1 : 1} 1)">` +
      `<g class="shape">${P.draw(c)}</g>` +
      P.pins.map((p, t) =>
        `<g class="term" data-c="${c.id}" data-t="${t}">` +
        `<circle class="pin" cx="${p[0]}" cy="${p[1]}" r="5"/>` +
        `<circle class="hit" cx="${p[0]}" cy="${p[1]}" r="16"/></g>`).join('') +
      `</g><text class="label" y="${-P.rad - 6}">${c.name}${val}</text>`;
    const bb = c.el.querySelector('.shape').getBBox();
    c.el.querySelector('.rot').prepend(mk('rect', {
      class: 'selbox', x: bb.x - 6, y: bb.y - 6, width: bb.width + 12, height: bb.height + 12, rx: 8 }));
    c.el.classList.toggle('sel', !!selected && selected.kind === 'comp' && selected.id === c.id);
    // النصوص: لا تنعكس عند القلب، ولا تنقلب رأساً على عقب عند 180°
    c.el.querySelectorAll('.rot text').forEach(t => {
      const x = t.getAttribute('x') || 0, y = t.getAttribute('y') || 0;
      t.setAttribute('transform',
        `translate(${x} ${y}) scale(${c.flip ? -1 : 1} 1) rotate(${c.rot === 180 ? 180 : 0}) translate(${-x} ${-y})`);
    });
    if (ME.onRender) ME.onRender(c);
  }

  function moveComp(c, x, y) {
    c.x = x; c.y = y;
    c.el.setAttribute('transform', `translate(${x} ${y})`);
    refreshWires(c.id);
  }
  function delComp(id) {
    wires.forEach(w => { if (w.a.c === id || w.b.c === id) delWire(w.id); });
    comps.get(id).el.remove(); comps.delete(id);
  }

  // ---------- الأسلاك ----------
  function pinPos(ref) {
    const c = comps.get(ref.c), p = PARTS[c.type].pins[ref.t];
    const x = p[0] * (c.flip ? -1 : 1), y = p[1];
    const a = c.rot * Math.PI / 180, co = Math.round(Math.cos(a)), si = Math.round(Math.sin(a));
    const dx = x * co - y * si, dy = x * si + y * co;
    return { x: c.x + dx, y: c.y + dy, dx, dy };
  }
  const dirOf = o => {
    const v = Math.abs(o.dy) >= Math.abs(o.dx);
    return { v, s: Math.sign(v ? o.dy : o.dx) || 1 };
  };
  function route(p, q, dp, dq) {
    const pts = [p];
    if (dp.v && dq.v) {
      const my = dp.s === dq.s ? (dp.s > 0 ? Math.max(p.y, q.y) : Math.min(p.y, q.y)) + dp.s * 30
                               : snap((p.y + q.y) / 2);
      pts.push({ x: p.x, y: my }, { x: q.x, y: my });
    } else if (!dp.v && !dq.v) {
      const mx = dp.s === dq.s ? (dp.s > 0 ? Math.max(p.x, q.x) : Math.min(p.x, q.x)) + dp.s * 30
                               : snap((p.x + q.x) / 2);
      pts.push({ x: mx, y: p.y }, { x: mx, y: q.y });
    } else if (dp.v) pts.push({ x: p.x, y: q.y });
    else pts.push({ x: q.x, y: p.y });
    pts.push(q);
    return 'M' + pts.map(a => a.x + ' ' + a.y).join('L');
  }
  function drawWire(w) {
    const p = pinPos(w.a), q = pinPos(w.b);
    const d = route(p, q, dirOf(p), dirOf(q));
    w.el.querySelectorAll('path').forEach(x => x.setAttribute('d', d));
  }
  const refreshWires = id => wires.forEach(w => { if (w.a.c === id || w.b.c === id) drawWire(w); });

  function addWire(a, b) {
    for (const w of wires.values())
      if ((same(w.a, a) && same(w.b, b)) || (same(w.a, b) && same(w.b, a))) return;
    const id = 'w' + (++uid);
    const g = mk('g', { class: 'wire', 'data-id': id });
    g.innerHTML = '<path class="hit-line"/><path class="line"/>';
    layerWires.appendChild(g);
    const w = { id, a, b, el: g };
    wires.set(id, w); drawWire(w);
  }
  function delWire(id) { wires.get(id).el.remove(); wires.delete(id); }

  function clearPending() {
    layerComps.querySelectorAll('.term.sel').forEach(t => t.classList.remove('sel'));
    pending = null;
  }
  function wireTap(termEl) {
    const ref = { c: termEl.dataset.c, t: +termEl.dataset.t };
    if (!pending) { pending = ref; termEl.classList.add('sel'); ME.setStatus('اختر الطرف الثاني'); return; }
    if (!same(pending, ref)) addWire(pending, ref);
    clearPending(); ME.setStatus('سلك: اختر طرفين');
  }

  // ---------- التحديد والإجراءات ----------
  function select(sel) {
    selected = sel;
    comps.forEach(c => c.el.classList.toggle('sel', !!sel && sel.kind === 'comp' && sel.id === c.id));
    wires.forEach(w => w.el.classList.toggle('sel', !!sel && sel.kind === 'wire' && sel.id === w.id));
    actions.hidden = !sel;
    if (!sel) return;
    const isComp = sel.kind === 'comp';
    actions.querySelectorAll('[data-act]').forEach(b => {
      const a = b.dataset.act;
      b.hidden = a === 'delete' ? false
        : !isComp || (a === 'value' && PARTS[comps.get(sel.id).type].def == null);
    });
  }

  actions.addEventListener('click', e => {
    const b = e.target.closest('[data-act]');
    if (!b || !selected) return;
    const act = b.dataset.act;
    if (selected.kind === 'wire') {
      if (act === 'delete') { delWire(selected.id); select(null); }
      return;
    }
    const c = comps.get(selected.id);
    if (act === 'rotate') { c.rot = (c.rot + 90) % 360; render(c); refreshWires(c.id); }
    else if (act === 'flip') { c.flip = !c.flip; render(c); refreshWires(c.id); }
    else if (act === 'delete') { delComp(c.id); select(null); }
    else if (act === 'value') askValue(c);
  });

  function askValue(c) {
    const P = PARTS[c.type];
    $('valueTitle').textContent = `${c.name} — ${P.name} (${P.unit})`;
    inp.value = eng(c.value);
    dlg.returnValue = '';
    dlg.addEventListener('close', () => {
      if (dlg.returnValue !== 'ok') return;
      const v = parseValue(inp.value);
      if (!(v > 0)) { ME.setStatus('قيمة غير صحيحة'); return; }
      c.value = v; render(c);
    }, { once: true });
    dlg.showModal(); inp.select();
  }
  $('valueCancel').addEventListener('click', () => dlg.close('cancel'));

  // ---------- اللمس ----------
  const ptrs = new Set();
  let down = null, multi = false;
  const toWorld = e => {
    const r = svg.getBoundingClientRect();
    return { x: (e.clientX - r.left - view.x) / view.k, y: (e.clientY - r.top - view.y) / view.k };
  };

  svg.addEventListener('pointerdown', e => {
    ptrs.add(e.pointerId);
    if (ptrs.size > 1) { multi = true; ME.busy = false; return; }
    multi = false;
    down = { x: e.clientX, y: e.clientY, moved: false, drag: null,
             termEl: e.target.closest('.term'),
             compEl: e.target.closest('.comp'),
             wireEl: e.target.closest('.wire') };
    if (tool === 'select' && !ME.running) {
      if (down.compEl) {
        const c = comps.get(down.compEl.dataset.id);
        select({ kind: 'comp', id: c.id });
        const w = toWorld(e);
        down.drag = { c, dx: c.x - w.x, dy: c.y - w.y };
        ME.busy = true;
      } else if (down.wireEl) {
        select({ kind: 'wire', id: down.wireEl.dataset.id });
      }
    }
  });

  svg.addEventListener('pointermove', e => {
    if (!down || multi) return;
    if (!down.moved && Math.hypot(e.clientX - down.x, e.clientY - down.y) > 6) down.moved = true;
    if (down.drag && down.moved) {
      const w = toWorld(e);
      moveComp(down.drag.c, snap(w.x + down.drag.dx), snap(w.y + down.drag.dy));
    }
  });

  function finish(e, tap) {
    ptrs.delete(e.pointerId);
    if (ptrs.size > 0) return;
    const d = down, wasMulti = multi;
    down = null; multi = false; ME.busy = false;
    if (tap && d && !wasMulti && !d.moved) handleTap(d, e);
  }
  svg.addEventListener('pointerup', e => finish(e, true));
  svg.addEventListener('pointercancel', e => finish(e, false));

  function handleTap(d, e) {
    if (!sheet.hidden) { sheet.hidden = true; return; }
    if (tool === 'wire') { if (d.termEl) wireTap(d.termEl); else clearPending(); return; }
    if (tool === 'place') {
      if (d.compEl || d.wireEl) return;
      const w = toWorld(e);
      const c = addComp(placing, snap(w.x), snap(w.y));
      setTool('select'); select({ kind: 'comp', id: c.id });
      return;
    }
    if (!d.compEl && !d.wireEl) select(null);
  }

  // ---------- الحفظ التلقائي ----------
  ME.render = render; ME.select = select;  
  const KEY = 'me-circuit-v1';
  function save() {
    try {
      localStorage.setItem(KEY, JSON.stringify({
        uid, counters,
        comps: [...comps.values()].map(c => ({
          id: c.id, type: c.type, x: c.x, y: c.y, rot: c.rot, flip: c.flip,
          value: c.value, name: c.name, closed: c.closed, pos: c.pos })),
        wires: [...wires.values()].map(w => ({ a: w.a, b: w.b }))
      }));
    } catch {}
  }
  function load() {
    try {
      const d = JSON.parse(localStorage.getItem(KEY) || 'null');
      if (!d) return;
      d.comps.forEach(s => { if (PARTS[s.type]) addComp(s.type, s.x, s.y, s); });
      d.wires.forEach(w => { if (comps.has(w.a.c) && comps.has(w.b.c)) addWire(w.a, w.b); });
      uid = d.uid || uid;
      Object.assign(counters, d.counters || {});
    } catch {}
  }
  load();
  setInterval(save, 1500);

  buildSheet();
  setTool('select');
})();