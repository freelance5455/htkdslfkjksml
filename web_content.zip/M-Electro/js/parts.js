// مكتبة العناصر: كل عنصر = رسم واقعي + مواضع الأطراف (مضاعفات 20)

const BAND = ['#111','#7a4a21','#d32f2f','#f57c00','#fbc02d','#388e3c','#1976d2','#7b1fa2','#9e9e9e','#fafafa'];
const SUF = { p: 1e-12, n: 1e-9, u: 1e-6, 'µ': 1e-6, m: 1e-3, k: 1e3, K: 1e3, M: 1e6, G: 1e9 };

function eng(v) {
  const a = Math.abs(v);
  if (a >= 1e6) return +(v / 1e6).toPrecision(3) + 'M';
  if (a >= 1e3) return +(v / 1e3).toPrecision(3) + 'k';
  if (a >= 1 || a === 0) return +v.toPrecision(3) + '';
  if (a >= 1e-3) return +(v * 1e3).toPrecision(3) + 'm';
  if (a >= 1e-6) return +(v * 1e6).toPrecision(3) + 'µ';
  return +(v * 1e9).toPrecision(3) + 'n';
}

function parseValue(s) {
  const t = String(s).trim().replace(',', '.')
    .replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
  const m = t.match(/^([0-9]*\.?[0-9]+(?:e[+-]?\d+)?)\s*([pnuµmkKMG]?)/);
  return m ? parseFloat(m[1]) * (SUF[m[2]] || 1) : NaN;
}

function bands(v) {
  v = Math.max(v, 0.1);
  let e = Math.floor(Math.log10(v));
  let d = Math.round(v / Math.pow(10, e - 1));
  if (d >= 100) { d = Math.round(d / 10); e++; }
  const mult = e - 1;
  const mc = mult >= 0 ? BAND[Math.min(mult, 9)] : (mult === -1 ? '#d4af37' : '#c0c0c0');
  return [BAND[Math.floor(d / 10)], BAND[d % 10], mc, '#d4af37'];
}

const ferrule = (x, y1, y2, fill) =>
  `<rect x="${x - 4}" y="${y1}" width="8" height="${y2 - y1}" rx="1" fill="${fill}" stroke="rgba(0,0,0,.5)"/>`;

const meter = (unit, cap) => () => `
  ${ferrule(-20, 40, 60, '#c62828')}${ferrule(20, 40, 60, '#222')}
  <rect x="-52" y="-40" width="104" height="80" rx="10" fill="url(#gBlack)" stroke="#000" stroke-width="1.5"/>
  <rect x="-44" y="-32" width="88" height="46" rx="5" fill="#06180f" stroke="#2a4a3a"/>
  <text class="lcd read" x="-8" y="3">0.00</text>
  <text class="lcdsm" x="32" y="3">${unit}</text>
  <text class="tiny" x="0" y="29">${cap}</text>`;

const PARTS = {
  PS: {
    cat: 'sources', name: 'مصدر DC', prefix: 'PS', def: 12, unit: 'V', rad: 70,
    pins: [[40, 40], [-40, 40]],           // 0 = موجب ، 1 = سالب
    draw: c => `
      <rect x="-62" y="-32" width="124" height="64" rx="8" fill="url(#gBlack)" stroke="#000" stroke-width="1.5"/>
      <rect x="-52" y="-24" width="104" height="28" rx="4" fill="#06180f" stroke="#2a4a3a"/>
      <text class="lcd" x="0" y="-4">${eng(c.value)} V</text>
      <text class="tiny" x="0" y="20">DC LAB SUPPLY</text>
      <rect x="34" y="32" width="12" height="8" fill="url(#gMetal)"/>
      <circle cx="40" cy="40" r="8" fill="#c62828" stroke="#600" stroke-width="1.5"/>
      <rect x="-46" y="32" width="12" height="8" fill="url(#gMetal)"/>
      <circle cx="-40" cy="40" r="8" fill="#1b1b1b" stroke="#000" stroke-width="1.5"/>
      <text class="tiny" x="40" y="43">+</text><text class="tiny" x="-40" y="43">−</text>`
  },
  R: {
    cat: 'passive', name: 'مقاومة', prefix: 'R', def: 100, unit: 'Ω', rad: 46,
    pins: [[-40, 0], [40, 0]],
    draw: c => {
      const b = bands(c.value);
      return `
      <rect x="-40" y="-2.5" width="80" height="5" fill="url(#gMetal)"/>
<rect x="-24" y="-9" width="48" height="18" rx="9" fill="${c.blown ? '#2a2a2a' : 'url(#gBeige)'}" stroke="#6b5a3a"/>      
      <rect x="-15" y="-9" width="4" height="18" fill="${b[0]}"/>
      <rect x="-8" y="-9" width="4" height="18" fill="${b[1]}"/>
      <rect x="-1" y="-9" width="4" height="18" fill="${b[2]}"/>
      <rect x="12" y="-9" width="4" height="18" fill="${b[3]}"/>`;
    }
  },
  lamp: {
    cat: 'ctrl', name: 'لمبة بيان', prefix: 'H', def: 12, unit: 'V', rad: 70,
    pins: [[-20, 60], [20, 60]],
    draw: c => `
      ${ferrule(-20, 34, 60, '#e0b400')}${ferrule(20, 34, 60, '#e0b400')}
      <circle r="38" fill="url(#gBlack)" stroke="#000" stroke-width="1.5"/>
      <circle r="31" fill="url(#gMetal)" stroke="#555"/>
<circle class="lens" r="26" stroke="#300" stroke-width="1" ${c.blown ? 'style="fill:#151515"' : ''}/>
      ${c.blown ? '<path d="M-14 -10L-3 0L-12 12M3 -14L8 -2L2 14" stroke="#777" stroke-width="1.5" fill="none"/>' : ''}
      <ellipse cx="-8" cy="-10" rx="10" ry="6" fill="#fff" opacity=".25" transform="rotate(-30 -8 -10)"/>`
  },
  button: {
    cat: 'ctrl', name: 'زر ضغط', prefix: 'S', def: null, unit: '', rad: 70,
    pins: [[-20, 60], [20, 60]],
    draw: () => `
      ${ferrule(-20, 42, 60, '#c62828')}${ferrule(20, 42, 60, '#c62828')}
      <rect x="-42" y="-42" width="84" height="84" rx="8" fill="url(#gBlack)" stroke="#000" stroke-width="1.5"/>
      <circle r="35" fill="url(#gMetal)" stroke="#555"/>
      <circle r="29" fill="#111"/>
      <circle class="cap" r="26" stroke="#063" stroke-width="1"/>
      <ellipse cx="-8" cy="-10" rx="10" ry="6" fill="#fff" opacity=".3" transform="rotate(-30 -8 -10)"/>`
  },
  VM: { cat: 'meters', name: 'فولتميتر', prefix: 'VM', def: null, unit: 'V', rad: 70,
        pins: [[-20, 60], [20, 60]], draw: meter('V', 'DIGITAL VOLTMETER') },
  AM: { cat: 'meters', name: 'أميتر', prefix: 'AM', def: null, unit: 'A', rad: 70,
        pins: [[-20, 60], [20, 60]], draw: meter('A', 'DIGITAL AMMETER') }
};

Object.assign(PARTS, {
  SW: {
    cat: 'ctrl', name: 'مفتاح قلاب', prefix: 'SW', def: null, unit: '', rad: 70,
    pins: [[-20, 60], [20, 60]],
    draw: c => `
      ${ferrule(-20, 42, 60, '#c62828')}${ferrule(20, 42, 60, '#c62828')}
      <rect x="-42" y="-42" width="84" height="84" rx="8" fill="url(#gBlack)" stroke="#000" stroke-width="1.5"/>
      <rect x="-30" y="-30" width="60" height="60" rx="6" fill="url(#gMetal)" stroke="#555"/>
      <rect x="-9" y="-24" width="18" height="48" rx="9" fill="#2b2f36" stroke="#000"/>
      <rect x="-9" y="${c.closed ? 2 : -24}" width="18" height="22" rx="9" fill="${c.closed ? '#22c55e' : '#9aa0a6'}" stroke="#000"/>
      <text class="tiny" x="0" y="38">${c.closed ? 'ON' : 'OFF'}</text>`
  },
  FU: {
    cat: 'protect', name: 'فيوز', prefix: 'F', def: 1, unit: 'A', rad: 46,
    pins: [[-40, 0], [40, 0]],
    draw: c => `
      <rect x="-40" y="-2.5" width="80" height="5" fill="url(#gMetal)"/>
      <rect x="-26" y="-9" width="52" height="18" rx="4" fill="#cfe8f0" fill-opacity=".45" stroke="#7fa6b5"/>
      <rect x="-30" y="-10" width="8" height="20" rx="2" fill="url(#gMetal)" stroke="#555"/>
      <rect x="22" y="-10" width="8" height="20" rx="2" fill="url(#gMetal)" stroke="#555"/>
      ${c.blown
        ? '<path d="M-22 0H-7M7 0H22" stroke="#bbb" stroke-width="1.5"/><circle r="7" fill="#222" opacity=".55"/>'
        : '<path d="M-22 0H22" stroke="#e5e5e5" stroke-width="1.5"/>'}`
  },
  POT: {
    cat: 'passive', name: 'مقاومة متغيرة', prefix: 'RV', def: 10000, unit: 'Ω', rad: 70,
    pins: [[-40, 60], [0, 60], [40, 60]],   // A ، المنزلق ، B
    draw: c => {
      const a = -135 + 270 * (c.pos == null ? 0.5 : c.pos);
      return `
      ${ferrule(-40, 42, 60, '#d0d0d0')}${ferrule(0, 42, 60, '#d0d0d0')}${ferrule(40, 42, 60, '#d0d0d0')}
      <rect x="-52" y="-44" width="104" height="86" rx="10" fill="#1f5fa8" stroke="#0a2a50" stroke-width="1.5"/>
      <circle cy="-6" r="32" fill="url(#gMetal)" stroke="#444" stroke-width="1.5"/>
      <g transform="translate(0 -6) rotate(${a})"><circle r="26" fill="url(#gBlack)"/><rect x="-2.5" y="-24" width="5" height="16" rx="2" fill="#fff"/></g>
      <text class="tiny" x="-40" y="37">A</text><text class="tiny" x="0" y="37">W</text><text class="tiny" x="40" y="37">B</text>`;
    }
  }
});
// ---------- أشباه الموصلات ----------
// model: Is (تيار التشبع) ، n (معامل المثالية) ، imax (تحذير) ، iburn (احتراق)
const ledPart = (name, prefix, on, off, vf) => ({
  cat: 'semi', name, prefix, def: null, unit: '', rad: 70,
  pins: [[-20, 60], [20, 60]],            // 0 = أنود (+) ، 1 = كاثود (−)
  model: { Is: 0.02 / Math.exp(vf / (2 * 0.025852)), n: 2, imax: 0.025, iburn: 0.06, led: true },
  draw: c => `
    ${ferrule(-20, 26, 60, '#c9c9c9')}${ferrule(20, 26, 60, '#c9c9c9')}
    <path class="led-dome" style="--on:${on};--off:${c.blown ? '#2a2a2a' : off}" d="M-30 20V-8A30 30 0 0 1 30 -8V20Z" stroke="rgba(0,0,0,.45)" stroke-width="1.5"/>
    <rect x="-36" y="20" width="72" height="8" rx="3" fill="${c.blown ? '#333' : off}" stroke="rgba(0,0,0,.45)" opacity=".85"/>
    <path d="M30 -2V20" stroke="rgba(0,0,0,.35)" stroke-width="2"/>
    <ellipse cx="-12" cy="-12" rx="7" ry="11" fill="#fff" opacity=".28" transform="rotate(-20 -12 -12)"/>
    <text class="tiny" x="-14" y="14">+</text><text class="tiny" x="14" y="14">−</text>`
});

Object.assign(PARTS, {
  D: {
    cat: 'semi', name: 'ديود 1N4007', prefix: 'D', def: null, unit: '', rad: 46,
    pins: [[-40, 0], [40, 0]],            // 0 = أنود ، 1 = كاثود (الشريط)
    model: { Is: 7e-9, n: 1.8, imax: 1, iburn: 5 },
    draw: c => `
      <rect x="-40" y="-2.5" width="80" height="5" fill="url(#gMetal)"/>
      <rect x="-22" y="-10" width="44" height="20" rx="4" fill="${c.blown ? '#2b1b1b' : 'url(#gBlack)'}" stroke="#000"/>
      <rect x="12" y="-10" width="7" height="20" fill="#d9dcdf"/>
      <text class="tiny" x="-5" y="3">1N4007</text>`
  },
  LEDR: ledPart('LED أحمر',  'LD', '#ff3b30', '#6b1511', 2.0),
  LEDG: ledPart('LED أخضر',  'LD', '#2bff6a', '#0f4a22', 2.2),
  LEDY: ledPart('LED أصفر',  'LD', '#ffd60a', '#6b5a08', 2.1),
  LEDB: ledPart('LED أزرق',  'LD', '#3b9bff', '#10315e', 3.1)
});
