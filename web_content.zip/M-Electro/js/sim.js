// المحاكاة: تحويل الأسلاك إلى عقد ثم استدعاء المحرك وعرض القراءات والتنبيهات
(() => {
  const { svg, comps, wires } = ME;
  const btn = document.getElementById('btnRun');
  const LAMP_W = 5;      // قدرة اللمبة المقننة (واط)
  const R_W = 0.25;      // قدرة المقاومة المقننة (واط)
  const AM_FUSE = 10;    // فيوز الأميتر الداخلي (أمبير)
  const PS_TRIP = 20;    // فصل حماية المصدر عند تيار أكبر من (أمبير)
  let running = false, timer = null, potDrag = null;

  const fmt = x => {
    const a = Math.abs(x);
    return a < 10 ? x.toFixed(3) : a < 100 ? x.toFixed(2) : x.toFixed(1);
  };
  const amp = i => i > 1e4 ? '>10k' : eng(i < 1e-6 ? 0 : i);
  function meterText(c, val) {
    if (Math.abs(val) < 1e-9) val = 0;
    const base = c.type === 'VM' ? 'V' : 'A';
    return Math.abs(val) < 1 ? { t: fmt(val * 1000), u: 'm' + base } : { t: fmt(val), u: base };
  }

  function applyReadout(c) {
    if (c.type !== 'VM' && c.type !== 'AM') return;
    const r = c.blown ? { t: 'FUSE', u: '' }
                      : (c.read || { t: '0.000', u: c.type === 'VM' ? 'V' : 'A' });
    const t = c.el.querySelector('.read'), u = c.el.querySelector('.lcdsm');
    if (t) t.textContent = r.t;
    if (u) u.textContent = r.u;
  }
  function applyTag(c) {
    const l = c.el.querySelector('.label');
    if (!l) return;
    l.textContent = (c.base || '') + (c.tag || '') + (c.warn ? ' ⚠' : '');
    l.style.fill = c.warn ? '#ef4444' : '';
  }
  ME.onRender = c => {
    const l = c.el.querySelector('.label');
    c.base = l ? l.textContent : '';
    applyReadout(c);
    applyTag(c);
  };
  comps.forEach(c => ME.onRender(c));

  function clearAll() {
    comps.forEach(c => {
      c.read = null; c.tag = ''; c.warn = false;
      c.el.classList.remove('on');
      applyTag(c); applyReadout(c);
    });
    wires.forEach(w => w.el.classList.remove('pos', 'gnd'));
  }

  function blow(c, why) {
    c.blown = true; c.why = why;
    ME.render(c);
    if (ME.burn) ME.burn(c);
  }

  // فصل الحماية: إيقاف التشغيل مع إبقاء رسالة السبب على الشاشة
  function trip(issues, at) {
    const keep = issues.slice();
    btn.classList.remove('on');
    btn.textContent = '▶ تشغيل';
    setRunning(false);
    ME.setStatus('⛔ فصلت الحماية');
    Check.show(keep);
    if (at && ME.burn) ME.burn(at);
  }

  let lastT = 0;
  function solve() {
    const now = performance.now();
    const dt = lastT ? Math.min(0.3, (now - lastT) / 1000) : 0.15;
    lastT = now;
    const issues = Check.staticIssues(comps, wires);

    // 1) الأسلاك -> عقد (union-find)
    const parent = new Map();
    const find = k => {
      if (!parent.has(k)) parent.set(k, k);
      let r = k;
      while (parent.get(r) !== r) r = parent.get(r);
      parent.set(k, r);
      return r;
    };
    const key = (c, t) => c + ':' + t;
    comps.forEach(c => PARTS[c.type].pins.forEach((_, t) => find(key(c.id, t))));
    wires.forEach(w => parent.set(find(key(w.a.c, w.a.t)), find(key(w.b.c, w.b.t))));

    // 2) الأرضي = القطب السالب لأول مصدر
    const ps = [...comps.values()].find(c => c.type === 'PS');
    if (!ps) {
      issues.push({ sev: 'error', msg: 'لا يوجد مصدر جهد في الدائرة: أضف مصدر DC من المكتبة' });
      ME.setStatus('أضف مصدر جهد'); clearAll(); Check.show(issues); return;
    }
    const ids = new Map([[find(key(ps.id, 1)), 0]]);
    const node = (c, t) => {
      const r = find(key(c, t));
      if (!ids.has(r)) ids.set(r, ids.size);
      return ids.get(r);
    };

    // 3) العناصر -> نموذج المحرك
    const parts = [];
    comps.forEach(c => {
      const a = node(c.id, 0), b = node(c.id, 1);
      if (c.blown) return;   // العنصر المحترق = دائرة مفتوحة
      if (c.type === 'PS') parts.push({ id: c.id, type: 'V', a, b, value: c.value });
      else if (c.type === 'R') parts.push({ id: c.id, type: 'R', a, b, value: c.value });
      else if (c.type === 'lamp') parts.push({ id: c.id, type: 'R', a, b, value: c.value * c.value / LAMP_W });
      else if (c.type === 'button') { if (c.pressed) parts.push({ id: c.id, type: 'R', a, b, value: 1e-3 }); }
      else if (c.type === 'VM') parts.push({ id: c.id, type: 'R', a, b, value: 10e6 });   // مقاومة داخلية 10MΩ
      else if (c.type === 'AM') parts.push({ id: c.id, type: 'R', a, b, value: 1e-3 });   // مقاومة داخلية 1mΩ
      else if (c.type === 'SW') { if (c.closed) parts.push({ id: c.id, type: 'R', a, b, value: 1e-3 }); }
      else if (c.type === 'FU') parts.push({ id: c.id, type: 'R', a, b, value: 0.01 });
      else if (c.type === 'POT') {
        const e = node(c.id, 2), p = c.pos == null ? 0.5 : c.pos;
        parts.push({ id: c.id + 'a', type: 'R', a, b, value: Math.max(c.value * p, 1e-3) });
        parts.push({ id: c.id + 'b', type: 'R', a: b, b: e, value: Math.max(c.value * (1 - p), 1e-3) });
      }
      else if (PARTS[c.type].model) {
        const m = PARTS[c.type].model;
        parts.push({ id: c.id, type: 'D', a, b, Is: m.Is, n: m.n });
      }
    });
    // مقاومة ضخمة لكل عقدة نحو الأرضي (تمنع العقد العائمة من تعطيل الحل)
    for (let n = 1; n < ids.size; n++) parts.push({ id: 'g' + n, type: 'R', a: n, b: 0, value: 1e9 });

    // تلوين الأسلاك: أحمر = موجب المصدر ، أزرق = سالب (الأرضي)
    const plus = node(ps.id, 0);
    wires.forEach(w => {
      const n = node(w.a.c, w.a.t);
      w.el.classList.toggle('gnd', n === 0);
      w.el.classList.toggle('pos', n === plus && n !== 0);
    });

    let res;
    try { res = Solver.solveDC(parts, ids.size); }
    catch (e) {
      clearAll();
      if (e.message === 'NOCONV') {
        issues.push({ sev: 'error', msg: 'تعذّر حل الدائرة: راجع التوصيل' });
        ME.setStatus('⚠ تعذّر حل الدائرة'); Check.show(issues); return;
      }
      // LED/ديود على المصدر مباشرة بدون مقاومة: يحترق فوراً
      const direct = Check.directDiodes(comps, wires).filter(c => !c.blown);
      if (direct.length) {
        direct.forEach(c => blow(c, `احترق ${c.name}: وُصل مباشرة بالمصدر بدون مقاومة تحدّ التيار. أضف مقاومة على التوالي`));
        comps.forEach(c => { if (c.blown) issues.push({ sev: 'error', id: c.id, msg: c.why }); });
        Check.show(issues); ME.setStatus('⚠ يوجد خطأ في التوصيل'); return;
      }
      issues.push({ sev: 'error', id: ps.id,
        msg: 'قصر دائرة أو مصادر جهد متعارضة: تم فصل المصدر تلقائياً حمايةً للدائرة' });
      trip(issues, ps); return;
    }

    // 4) النتائج + التنبيهات
    let blownNow = false, psMax = 0, psOver = null;
    const blowIt = (c, why) => { blow(c, why); blownNow = true; };

    comps.forEach(c => {
      const r = res.parts[c.id];
      c.tag = ''; c.warn = false;

      if (c.blown) {
        c.tag = c.type === 'FU' ? ' · منصهر' : ' · محترق'; c.warn = true;
        c.el.classList.remove('on');
        issues.push({ sev: 'error', id: c.id, msg: c.why || `${c.name}: معطوب` });
      }
      else if (c.type === 'VM') {
        const v = res.voltages[node(c.id, 0)] - res.voltages[node(c.id, 1)];
        c.read = meterText(c, v);
        if (v < -1e-3) issues.push({ sev: 'info', id: c.id,
          msg: `${c.name}: القراءة سالبة، بدّل المجسّين (الأحمر على الجهد الأعلى)` });
      }
      else if (c.type === 'AM') {
        const i = r.current;
        c.read = meterText(c, i);
        if (Math.abs(i) > AM_FUSE)
          blowIt(c, `احترق فيوز الأميتر ${c.name}: التيار ${amp(Math.abs(i))}A تجاوز ${AM_FUSE}A. الأميتر يوصل على التوالي مع الحمل وليس على التوازي`);
        else if (i < -1e-6) issues.push({ sev: 'info', id: c.id,
          msg: `${c.name}: التيار معكوس (سالب)، بدّل طرفي الأميتر ليدخل التيار من الأحمر` });
      }
      else if (c.type === 'R') {
        const p = r.power;
        c.tag = ' · ' + amp(Math.abs(r.current)) + 'A';
        c.warn = p > R_W;
        // تسخين تدريجي: تحترق بعد ثانية ونصف من تجاوز 4 أضعاف قدرتها
        c.heat = p > 4 * R_W ? (c.heat || 0) + dt : Math.max(0, (c.heat || 0) - dt);
        if (c.heat > 1.5)
          blowIt(c, `احترقت المقاومة ${c.name}: بقيت القدرة ${p.toFixed(2)}W أعلى من 4 أضعاف قدرتها (${R_W}W)`);
        else if (c.warn) issues.push({ sev: 'warn', id: c.id,
          msg: `${c.name}: القدرة ${p.toFixed(2)}W أعلى من المقنن (${R_W}W) وقد تسخن وتحترق، استخدم قيمة أكبر أو قدرة أعلى` });
      }
      else if (c.type === 'PS') {
        const i = Math.max(0, r.current);
        c.tag = ' · ' + amp(i) + 'A';
        psMax = Math.max(psMax, i);
        if (i > PS_TRIP) psOver = c;
        else if (i > 5) issues.push({ sev: 'warn', id: c.id, msg: `${c.name}: تيار عالٍ (${amp(i)}A)، تحقق من الحمل` });
      }
      else if (c.type === 'FU') {
        const i = Math.abs(r.current);
        c.tag = ' · ' + amp(i) + 'A';
        if (i > c.value * 1.5)
          blowIt(c, `انصهر الفيوز ${c.name}: التيار ${amp(i)}A تجاوز 150% من قيمته (${eng(c.value)}A)`);
        else if (i > c.value) { c.warn = true; issues.push({ sev: 'warn', id: c.id,
          msg: `${c.name}: التيار أعلى من قيمة الفيوز وسينصهر قريباً` }); }
      }
      else if (c.type === 'POT') {
        c.tag = ' · ' + Math.round((c.pos == null ? 0.5 : c.pos) * 100) + '%';
      }
      else if (PARTS[c.type].model) {
        const m = PARTS[c.type].model;
        const i = Math.max(0, r.current), v = r.voltage;
        c.tag = ' · ' + amp(i) + 'A';
        c.warn = i > m.imax;
        if (m.led) {
          c.el.classList.toggle('on', i > 5e-4);
          c.el.style.setProperty('--lum', Math.min(1, 0.25 + 0.75 * i / 0.02));
        }
        if (v < -0.3) issues.push({ sev: m.led ? 'warn' : 'info', id: c.id, msg: m.led
          ? `${c.name}: معكوس الاتجاه فلن يضيء، صِل الأنود (+) بجهة الموجب والكاثود (−) بجهة السالب`
          : `${c.name}: الديود معكوس الاتجاه فلا يمرر التيار` });
        if (i > m.iburn)
          blowIt(c, m.led
            ? `احترق ${c.name}: التيار ${amp(i)}A تجاوز ${Math.round(m.iburn * 1000)}mA. أضف مقاومة على التوالي لتحديد التيار`
            : `احترق ${c.name}: التيار ${amp(i)}A تجاوز ${m.iburn}A`);
        else if (c.warn) issues.push({ sev: 'warn', id: c.id,
          msg: `${c.name}: التيار ${amp(i)}A أعلى من الحد (${Math.round(m.imax * 1000)}mA)، أضف مقاومة أكبر على التوالي` });
      }
      else if (c.type === 'lamp') {
        const vd = Math.abs(r.voltage), p = r.power;
        c.el.classList.toggle('on', p > 0.05 * LAMP_W);
        c.el.style.setProperty('--lum', Math.min(1, Math.max(0.25, p / LAMP_W)));
        if (vd > 1.5 * c.value)
          blowIt(c, `احترقت اللمبة ${c.name}: الجهد ${vd.toFixed(1)}V أعلى بكثير من جهدها المقنن (${eng(c.value)}V)`);
        else if (vd > 1.15 * c.value) { c.warn = true; issues.push({ sev: 'warn', id: c.id,
          msg: `${c.name}: تعمل بجهد ${vd.toFixed(1)}V أعلى من المقنن (${eng(c.value)}V) وقد تحترق` }); }
        else if (p > 0.05 * LAMP_W && vd < 0.7 * c.value) issues.push({ sev: 'info', id: c.id,
          msg: `${c.name}: تعمل بجهد أقل من المقنن فتضيء بخفوت` });
      }
      applyTag(c); applyReadout(c);
    });

    if (!blownNow && psOver) {
      issues.push({ sev: 'error', id: psOver.id,
        msg: `${psOver.name}: تيار هائل (${amp(psMax)}A) بسبب قصر في الدائرة. تم فصل المصدر تلقائياً` });
      trip(issues, psOver); return;
    }
    if (!blownNow && psMax < 1e-7)
      issues.push({ sev: 'info', msg: 'لا يمر تيار في الدائرة: تحقق من التوصيل أو من مفتاح مفتوح' });

    Check.show(issues);
    ME.setStatus(issues.some(i => i.sev === 'error') ? '⚠ يوجد خطأ في التوصيل' : 'يعمل ✓');
  }

  function setRunning(on) {
    running = on; ME.running = on;
    clearInterval(timer);
    if (on) {
      Check.reset();
      if (ME.initAudio) ME.initAudio();
      solve();
      if (running) timer = setInterval(solve, 150);
    } else {
      comps.forEach(c => {
        c.pressed = false; c.el.classList.remove('pressed');
        c.heat = 0;
        if (c.blown) { c.blown = false; c.why = ''; ME.render(c); }
      });
      clearAll();
      Check.show([]);
      ME.setStatus('تحديد');
    }
  }
  btn.addEventListener('click', () => setRunning(btn.classList.contains('on')));

  // أثناء التشغيل: زر الضغط يوصل ما دمت ضاغطاً، المفتاح ينقلب بالنقر، المقاومة المتغيرة بالسحب أفقياً
  svg.addEventListener('pointerdown', e => {
    if (!running) return;
    const el = e.target.closest('.comp');
    const c = el && comps.get(el.dataset.id);
    if (!c) return;
    if (c.type === 'button') { c.pressed = true; c.el.classList.add('pressed'); solve(); }
    else if (c.type === 'SW') { c.closed = !c.closed; ME.render(c); solve(); }
    else if (c.type === 'POT') { ME.busy = true; potDrag = { c, x0: e.clientX, p0: c.pos == null ? 0.5 : c.pos }; }
  });
  svg.addEventListener('pointermove', e => {
    if (!potDrag) return;
    const c = potDrag.c;
    c.pos = Math.min(1, Math.max(0, potDrag.p0 + (e.clientX - potDrag.x0) / 160));
    ME.render(c); solve();
  });
  const release = () => {
    potDrag = null;
    let changed = false;
    comps.forEach(c => { if (c.pressed) { c.pressed = false; c.el.classList.remove('pressed'); changed = true; } });
    if (changed && running) solve();
  };
  svg.addEventListener('pointerup', release);
  svg.addEventListener('pointercancel', release);
})();