// فحص التوصيل: تنبيهات ثابتة (من بنية الدائرة) + عرض قائمة التنبيهات على الشاشة
const Check = (() => {
  const $ = id => document.getElementById(id);
  const chip = $('issueChip'), panel = $('issuePanel'), list = $('ipList');
  const ICON = { error: '⛔', warn: '⚠️', info: 'ℹ️' };
  const RANK = { error: 3, warn: 2, info: 1 };
  let lastSig = '', seen = new Set();
  const esc = s => String(s).replace(/[&<>]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[ch]));

  // العقد (الأطراف الموصولة بأسلاك) والعناصر المشتركة في كل عقدة
  function buildNets(comps, wires) {
    const parent = new Map();
    const key = (c, t) => c + ':' + t;
    const find = k => {
      if (!parent.has(k)) parent.set(k, k);
      let r = k;
      while (parent.get(r) !== r) r = parent.get(r);
      parent.set(k, r);
      return r;
    };
    comps.forEach(c => PARTS[c.type].pins.forEach((_, t) => find(key(c.id, t))));
    wires.forEach(w => parent.set(find(key(w.a.c, w.a.t)), find(key(w.b.c, w.b.t))));
    const members = new Map();
    comps.forEach(c => PARTS[c.type].pins.forEach((_, t) => {
      const r = find(key(c.id, t));
      if (!members.has(r)) members.set(r, []);
      members.get(r).push({ c: c.id, t });
    }));
    return { root: (c, t) => find(key(c, t)), members };
  }

  function staticIssues(comps, wires) {
    const out = [], N = buildNets(comps, wires);
    const members = (c, t) => N.members.get(N.root(c.id, t));
    const others = (c, t) => members(c, t).filter(m => m.c !== c.id);

    comps.forEach(c => {
      const P = PARTS[c.type], n = P.pins.length;
      const conn = P.pins.map((_, t) => members(c, t).length > 1);
      const cnt = conn.filter(Boolean).length;

      if (c.type === 'PS' && N.root(c.id, 0) === N.root(c.id, 1))
        out.push({ sev: 'error', id: c.id, msg: `${c.name}: قصر مباشر بين القطب الموجب (+) والسالب (−)` });
      else if (cnt === 0)
        out.push({ sev: 'info', id: c.id, msg: `${c.name}: غير موصول بالدائرة` });
      else if (cnt < n && c.type !== 'POT')
        out.push({ sev: 'warn', id: c.id, msg: `${c.name}: يوجد طرف غير موصول` });

      if (n === 2 && c.type !== 'PS' && cnt > 0 && N.root(c.id, 0) === N.root(c.id, 1))
        out.push({ sev: 'warn', id: c.id, msg: `${c.name}: طرفاه متصلان ببعضهما (مقصور)` });

      if (c.type === 'VM' || c.type === 'AM') {
        const o0 = others(c, 0), o1 = others(c, 1);
        const one = o0.length === 1 && o1.length === 1;
        if (c.type === 'VM' && one && o0[0].c !== o1[0].c)
          out.push({ sev: 'warn', id: c.id,
            msg: `${c.name}: الفولتميتر موصول على التوالي، والصحيح توصيله على التوازي بين طرفي العنصر المراد قياسه` });
        if (c.type === 'AM' && one && o0[0].c === o1[0].c)
          out.push({ sev: 'error', id: c.id,
            msg: `${c.name}: الأميتر موصول على التوازي مباشرة، والصحيح توصيله على التوالي مع الحمل` });
      }
    });
    return out;
  }

  // ديود/LED موصول مباشرة على أطراف المصدر بدون مقاومة
  function directDiodes(comps, wires) {
    const N = buildNets(comps, wires), out = [];
    comps.forEach(c => {
      if (!PARTS[c.type].model) return;
      const ra = N.root(c.id, 0), rb = N.root(c.id, 1);
      comps.forEach(p => {
        if (p.type === 'PS' && N.root(p.id, 0) === ra && N.root(p.id, 1) === rb && !out.includes(c)) out.push(c);
      });
    });
    return out;
  }

  function show(issues) {
    issues = issues.slice().sort((a, b) => RANK[b.sev] - RANK[a.sev]);
    const sig = issues.map(i => i.sev + (i.id || '') + i.msg).join('|');
    if (sig === lastSig) return;
    lastSig = sig;

    ME.comps.forEach(c => c.el.classList.remove('issue-error', 'issue-warn'));
    issues.forEach(i => {
      const c = ME.comps.get(i.id);
      if (c && i.sev !== 'info') c.el.classList.add('issue-' + i.sev);
    });

    if (!issues.length) { chip.hidden = true; panel.hidden = true; list.innerHTML = ''; return; }
    const top = issues[0].sev;
    chip.hidden = false;
    chip.className = 'issue-chip ' + top;
    chip.textContent = ICON[top] + ' ' + issues.length;
    list.innerHTML = issues.map(i =>
      `<button class="ip-item ${i.sev}" data-id="${i.id || ''}"><span>${ICON[i.sev]}</span><span>${esc(i.msg)}</span></button>`
    ).join('');

    const fresh = issues.some(i => i.sev === 'error' && !seen.has(i.msg));
    issues.forEach(i => { if (i.sev === 'error') seen.add(i.msg); });
    if (fresh) panel.hidden = false;
  }

  function reset() { seen.clear(); lastSig = ''; show([]); }

  chip.addEventListener('click', () => { panel.hidden = !panel.hidden; });
  $('ipClose').addEventListener('click', () => { panel.hidden = true; });
  list.addEventListener('click', e => {
    const b = e.target.closest('.ip-item');
    if (b && b.dataset.id && ME.select && ME.comps.has(b.dataset.id)) ME.select({ kind: 'comp', id: b.dataset.id });
  });

  return { staticIssues, directDiodes, show, reset };
})();