// محرك الحل: Modified Nodal Analysis
// - عناصر خطية: R (مقاومة) ، V (مصدر جهد) ، I (مصدر تيار)
// - عناصر غير خطية: D (ديود / LED) بطريقة Newton-Raphson
// العقدة 0 = الأرضي
const Solver = (() => {
  const VT = 0.025852; // الجهد الحراري عند 300K

  function solveLinear(A, b) {
    const n = b.length;
    for (let i = 0; i < n; i++) {
      let p = i;
      for (let r = i + 1; r < n; r++)
        if (Math.abs(A[r][i]) > Math.abs(A[p][i])) p = r;
      if (Math.abs(A[p][i]) < 1e-12) throw new Error('SHORT');
      [A[i], A[p]] = [A[p], A[i]];
      [b[i], b[p]] = [b[p], b[i]];
      for (let r = i + 1; r < n; r++) {
        const f = A[r][i] / A[i][i];
        for (let c = i; c < n; c++) A[r][c] -= f * A[i][c];
        b[r] -= f * b[i];
      }
    }
    const x = new Array(n).fill(0);
    for (let i = n - 1; i >= 0; i--) {
      let s = b[i];
      for (let c = i + 1; c < n; c++) s -= A[i][c] * x[c];
      x[i] = s / A[i][i];
    }
    return x;
  }

  // حل خطي: R / V / I
  function solveLinearDC(parts, nodeCount) {
    const vs = parts.filter(p => p.type === 'V');
    const n = nodeCount - 1;
    const size = n + vs.length;
    const A = Array.from({ length: size }, () => new Array(size).fill(0));
    const z = new Array(size).fill(0);
    const k = x => x - 1;

    parts.forEach(p => {
      if (p.type === 'R') {
        const g = 1 / p.value;
        if (p.a > 0) A[k(p.a)][k(p.a)] += g;
        if (p.b > 0) A[k(p.b)][k(p.b)] += g;
        if (p.a > 0 && p.b > 0) {
          A[k(p.a)][k(p.b)] -= g;
          A[k(p.b)][k(p.a)] -= g;
        }
      } else if (p.type === 'I') {
        if (p.a > 0) z[k(p.a)] -= p.value;
        if (p.b > 0) z[k(p.b)] += p.value;
      }
    });

    vs.forEach((p, j) => {
      const r = n + j;
      if (p.a > 0) { A[r][k(p.a)] += 1; A[k(p.a)][r] += 1; }
      if (p.b > 0) { A[r][k(p.b)] -= 1; A[k(p.b)][r] -= 1; }
      z[r] = p.value;
    });

    const x = solveLinear(A, z);
    const v = [0, ...x.slice(0, n)];
    const result = { voltages: v, parts: {} };
    let j = 0;
    parts.forEach(p => {
      const vd = v[p.a] - v[p.b];
      let i;
      if (p.type === 'R') i = vd / p.value;
      else if (p.type === 'I') i = p.value;
      else { i = -x[n + j]; j++; } // التيار الخارج من القطب الموجب
      result.parts[p.id] = { voltage: vd, current: i, power: vd * i };
    });
    return result;
  }

  // تحديد قفزة الجهد في الديود (من SPICE) لضمان التقارب
  function pnjlim(vnew, vold, vt, vcrit) {
    if (vnew > vcrit && Math.abs(vnew - vold) > 2 * vt) {
      if (vold > 0) {
        const arg = 1 + (vnew - vold) / vt;
        vnew = arg > 0 ? vold + vt * Math.log(arg) : vcrit;
      } else {
        vnew = vt * Math.log(vnew / vt);
      }
    }
    return vnew;
  }

  // parts تقبل أيضاً: {type:'D', a:أنود, b:كاثود, Is, n}
  function solveDC(parts, nodeCount) {
    const diodes = parts.filter(p => p.type === 'D');
    if (!diodes.length) return solveLinearDC(parts, nodeCount);

    const others = parts.filter(p => p.type !== 'D');
    const state = new Map();
    diodes.forEach(d => {
      d.vt = d.n * VT;
      d.vcrit = d.vt * Math.log(d.vt / (Math.SQRT2 * d.Is));
      state.set(d.id, 0);
    });

    let res = null, converged = false;
    for (let it = 0; it < 200 && !converged; it++) {
      const lin = others.slice();
      diodes.forEach(d => {
        const v = state.get(d.id);
        const e = Math.exp(Math.min(v / d.vt, 80));
        const id = d.Is * (e - 1);
        const g = d.Is * e / d.vt + 1e-12;
        lin.push({ id: d.id + '#g', type: 'R', a: d.a, b: d.b, value: 1 / g });
        lin.push({ id: d.id + '#i', type: 'I', a: d.a, b: d.b, value: id - g * v });
      });
      res = solveLinearDC(lin, nodeCount);
      converged = true;
      diodes.forEach(d => {
        const vOld = state.get(d.id);
        const vRaw = res.voltages[d.a] - res.voltages[d.b];
        if (Math.abs(vRaw - vOld) > 1e-7 + 1e-6 * Math.abs(vRaw)) converged = false;
        state.set(d.id, pnjlim(vRaw, vOld, d.vt, d.vcrit));
      });
    }
    if (!converged) throw new Error('NOCONV');

    diodes.forEach(d => {
      const v = res.voltages[d.a] - res.voltages[d.b];
      const i = d.Is * (Math.exp(Math.min(v / d.vt, 80)) - 1);
      res.parts[d.id] = { voltage: v, current: i, power: v * i };
    });
    return res;
  }

  return { solveDC };
})();