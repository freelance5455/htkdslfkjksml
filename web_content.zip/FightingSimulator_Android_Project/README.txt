FIGHTING SIMULATOR - ANDROID PROJECT

This is an Android Studio WebView project containing the playable Fighting Simulator game.

BUILD:
1. Open this folder in Android Studio.
2. Let Gradle sync/download Android Gradle Plugin 8.7.3 and dependencies.
3. Build > Build APK(s).
4. Install the generated APK on an Android phone.

Package: com.fightingsimulator.app
Version: 1.0
Min Android: 6.0 (API 23)
Target SDK: 35
