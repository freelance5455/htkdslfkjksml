plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.bombelite"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.bombelite"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    // The existing Bombe Lite HTML/PWA folder sits beside this Android project.
    sourceSets.getByName("main").assets.srcDir("../../bombe-lite")
}
