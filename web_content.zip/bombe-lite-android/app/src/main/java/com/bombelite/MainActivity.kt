package com.bombelite

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView

    private val appFallbacks = mapOf(
        "com.whatsapp" to "https://wa.me/",
        "com.mojang.minecraftpe" to "https://www.minecraft.net/",
        "com.google.android.youtube" to "https://www.youtube.com/",
        "com.google.android.googlequicksearchbox" to "https://www.google.com/",
        "com.android.vending" to "https://play.google.com/store",
        "com.google.android.gm" to "https://mail.google.com/"
    )

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 19, 38)
        window.navigationBarColor = Color.rgb(7, 19, 38)

        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(7, 19, 38))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            addJavascriptInterface(NativeBridge(), "BombeLite")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    val uri = request?.url ?: return false
                    if (uri.scheme == "file") return false
                    if (uri.scheme == "https" || uri.scheme == "http") {
                        openUrl(uri.toString())
                    }
                    return true
                }
            }
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun openApp(packageName: String, fallbackUrl: String) {
            runOnUiThread { launchInstalledApp(packageName, fallbackUrl) }
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            runOnUiThread { this@MainActivity.openUrl(url) }
        }
    }

    private fun launchInstalledApp(packageName: String, fallbackUrl: String) {
        if (!appFallbacks.containsKey(packageName)) {
            Toast.makeText(this, "Atalho não reconhecido.", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            try {
                startActivity(intent)
            } catch (_: ActivityNotFoundException) {
                openUrl(appFallbacks[packageName] ?: fallbackUrl)
            }
        } else {
            Toast.makeText(this, "App não encontrado; abrindo o site.", Toast.LENGTH_SHORT).show()
            openUrl(appFallbacks[packageName] ?: fallbackUrl)
        }
    }

    private fun openUrl(rawUrl: String) {
        val uri = Uri.parse(rawUrl)
        if (uri.scheme != "https" && uri.scheme != "http") {
            Toast.makeText(this, "Endereço não permitido.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Não encontrei um navegador para abrir o link.", Toast.LENGTH_LONG).show()
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("BombeLite")
            webView.destroy()
        }
        super.onDestroy()
    }
}
