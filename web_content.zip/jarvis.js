/* J.A.R.V.I.S BR 2.4 — APP: a tela principal (HUD, registro, voz, ferramentas e o cérebro no Gemini). */
"use strict";
const { $, $$, ler, guardar, lerJSON, esc, linkar, dobrar } = J;
let C = J.aplicarTema();

// ═══ estado ═════════════════════════════════════════════════════════════════
const S = { estado: "INICIANDO", maos: false, turno: 0, ocupado: false, anexo: null, inicio: Date.now() };
let historico = lerJSON("j_historico", []).slice(-30);
let memorias = lerJSON("j_memorias", []), notas = lerJSON("j_notas", []);
const salvarMem = () => { guardar("j_memorias", memorias.slice(-300)); guardar("j_notas", notas.slice(-300)); };
function setEstado(e) {
  S.estado = e;
  const p = $("#pilula"), mapa = { PRONTO: ["ONLINE", "on"], OUVINDO: ["OUVINDO", "on"], PENSANDO: ["PENSANDO", ""], PROCESSANDO: ["PROCESSANDO", ""], FALANDO: ["FALANDO", "on"], INICIANDO: ["INICIANDO", ""], SEM_CHAVE: ["SEM CHAVE", "ruim"], OFFLINE: ["OFFLINE", "ruim"] };
  const [t, c] = mapa[e] || [e, ""]; p.textContent = t; p.className = "pilula " + c;
}

// ═══ HUD — o núcleo do reator (porta de HudCanvas._paint_core do ui.py) ═══════════
const cv = $("#hud"), g = cv.getContext("2d");
let W = 0, H = 0, dpr = 1, fase = 0, amp = 0, tick = 0, piscar = true, ultimoT = performance.now(), fps = 60, quadros = 0, t0fps = performance.now();
function ajustarHud() { dpr = Math.min(2, devicePixelRatio || 1); const r = cv.getBoundingClientRect(); W = r.width; H = r.height; cv.width = Math.max(1, W * dpr); cv.height = Math.max(1, H * dpr); }
addEventListener("resize", ajustarHud);
const rgb = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16));
function mistura(cor, a) { const [r, gg, b] = rgb(cor), [R, G, B] = rgb(C.BG), k = Math.max(0, Math.min(1, a)); return `rgb(${R + (r - R) * k | 0},${G + (gg - G) * k | 0},${B + (b - B) * k | 0})`; }
function coresNucleo() {
  if (S.estado === "MUTADO") return [C.MUTED_C, C.MUTED_C];
  if (S.estado === "FALANDO") return [C.PRI, C.ACC];
  if (S.estado === "PENSANDO" || S.estado === "PROCESSANDO") return [C.PRI, C.ACC2];
  if (S.estado === "OUVINDO") return [C.PRI, C.GREEN];
  return [C.PRI, C.PRI_DIM];
}
function linha(x1, y1, x2, y2) { g.moveTo(x1, y1); g.lineTo(x2, y2); }
function nucleo(cx, cy, r, w, h) {
  const [main, acc] = coresNucleo(), t = fase, falando = S.estado === "FALANDO", vivo = (falando || amp > 0.04);
  const lift = 1 + 0.55 * amp + (falando ? 0.18 : 0);
  for (const [gr, a0] of [[r * 0.7, 0.3], [r * 0.34, 0.34]]) {
    const gd = g.createRadialGradient(cx, cy, 0, cx, cy, gr);
    gd.addColorStop(0, mistura(main, Math.min(.95, a0 * lift))); gd.addColorStop(.45, mistura(main, Math.min(.95, a0 * lift * .52)));
    gd.addColorStop(.78, mistura(main, Math.min(.95, a0 * lift * .18))); gd.addColorStop(1, mistura(main, 0));
    g.fillStyle = gd; g.beginPath(); g.arc(cx, cy, gr, 0, 7); g.fill();
  }
  // marcas nos cantos e mira
  const m = Math.min(w, h) * 0.035, braco = Math.min(w, h) * 0.055;
  g.strokeStyle = mistura(main, .45); g.lineWidth = 1.4; g.beginPath();
  for (const [sx, sy] of [[1, 1], [-1, 1], [1, -1], [-1, -1]]) { const x = cx + sx * (w / 2 - m), y = cy + sy * (h / 2 - m); linha(x, y, x - sx * braco, y); linha(x, y, x, y - sy * braco); }
  g.stroke();
  const gap = r * 0.62; g.strokeStyle = mistura(main, .16); g.lineWidth = 1; g.beginPath();
  linha(cx - w / 2, cy, cx - gap, cy); linha(cx + gap, cy, cx + w / 2, cy); linha(cx, cy - h / 2, cx, cy - gap); linha(cx, cy + gap, cx, cy + h / 2); g.stroke();
  for (const [rr, a] of [[1, .34], [.93, .16]]) { g.strokeStyle = mistura(main, a); g.beginPath(); g.arc(cx, cy, r * rr, 0, 7); g.stroke(); }
  // graduações
  g.beginPath(); g.strokeStyle = mistura(main, .42); g.lineWidth = 1.3;
  for (let i = 0; i < 72; i += 3) { const a = i * 5 * Math.PI / 180, c = Math.cos(a), s = Math.sin(a); linha(cx + c * r * .885, cy + s * r * .885, cx + c * r * .985, cy + s * r * .985); }
  g.stroke(); g.beginPath(); g.strokeStyle = mistura(main, .18); g.lineWidth = 1;
  for (let i = 0; i < 72; i++) { if (i % 3 === 0) continue; const a = i * 5 * Math.PI / 180, c = Math.cos(a), s = Math.sin(a); linha(cx + c * r * .945, cy + s * r * .945, cx + c * r * .985, cy + s * r * .985); }
  g.stroke();
  // arcos que giram: a velocidade é o estado
  const rate = 1 + (S.estado === "PENSANDO" || S.estado === "PROCESSANDO" ? 1.9 : 0) + (falando ? 1.2 : 0);
  [[.955, 118, 2, 1, acc, .75, 2], [.845, 82, 3, -1, main, .38, 1.3], [.76, 150, 1, 1, acc, .45, 1.6], [.66, 64, 4, -1, main, .26, 1.1], [.545, 128, 2, 1, main, .3, 1.2]]
    .forEach(([rr, span, n, dir, col, a, lw], k) => {
      g.strokeStyle = mistura(col, a); g.lineWidth = lw; const base = ((t * rate * (9 + k * 6) * dir) % 360);
      for (let s = 0; s < n; s++) { const a0 = -(base + s * 360 / n) * Math.PI / 180; g.beginPath(); g.arc(cx, cy, r * rr, a0 - span * Math.PI / 180, a0); g.stroke(); }
    });
  // a voz: anel de espinhos que crescem com o som
  const ring = r * .415; g.beginPath(); g.strokeStyle = mistura(vivo ? acc : main, .25 + .5 * amp); g.lineWidth = 1.6;
  for (let i = 0; i < 60; i++) {
    const a = i * 6 * Math.PI / 180, c = Math.cos(a), s = Math.sin(a), wob = .5 + .5 * Math.sin(t * 2.3 + i * .42), idle = .018 + .012 * Math.sin(t * 1.2 + i * .7);
    const hh = r * (idle + (vivo ? amp * .2 * wob : 0)); linha(cx + c * ring, cy + s * ring, cx + c * (ring + hh), cy + s * (ring + hh));
  }
  g.stroke();
  const inner = r * .355; g.strokeStyle = mistura(acc, .3 + .45 * amp); g.lineWidth = 1.5; g.beginPath(); g.arc(cx, cy, inner, 0, 7); g.stroke();
  if (ler("j_hud", "reator") === "rosto") rosto(cx, cy, inner, acc); else {
    const nome = J.nomeAssistente(), esp = Math.max(1, r * .018), fsz = Math.max(8, Math.min(r * .105, (inner * 1.75) / Math.max(1, nome.length) * 1.6 - esp));
    g.font = `bold ${fsz}px ${getComputedStyle(document.body).fontFamily}`; g.textAlign = "center"; g.textBaseline = "middle"; g.fillStyle = mistura(C.WHITE, .6 + .4 * Math.min(1, amp * 2));
    if ("letterSpacing" in g) g.letterSpacing = esp + "px"; g.fillText(nome, cx, cy);
  }
}
function rosto(cx, cy, r, acc) {          // o rosto holográfico (estilo HUD: ROSTO)
  const pisca = (fase % 5) < 0.12 ? 0.15 : 1, olhar = Math.sin(fase * .4) * r * .04;
  g.save(); g.shadowColor = C.PRI; g.shadowBlur = r * .3; g.fillStyle = C.WHITE;
  for (const lado of [-1, 1]) { g.beginPath(); g.ellipse(cx + lado * r * .36 + olhar, cy - r * .18, r * .11, r * .11 * pisca, 0, 0, 7); g.fill(); }
  g.strokeStyle = S.estado === "FALANDO" ? acc : C.WHITE; g.lineWidth = Math.max(1.5, r * .05); g.lineCap = "round"; g.beginPath();
  const abre = r * (.03 + amp * .28 * (.6 + .4 * Math.sin(fase * 22)));
  g.moveTo(cx - r * .32, cy + r * .32); g.quadraticCurveTo(cx, cy + r * .32 + abre * 2, cx + r * .32, cy + r * .32); g.stroke(); g.restore();
}
function desenhar(agora) {
  const dt = Math.min(.1, (agora - ultimoT) / 1000); ultimoT = agora; fase += dt * 6; tick++;
  quadros++; if (agora - t0fps > 1000) { fps = Math.round(quadros * 1000 / (agora - t0fps)); quadros = 0; t0fps = agora; }
  const alvo = J.nivelAudio(); amp += (alvo - amp) * (alvo > amp ? .45 : .12);
  if (tick % 38 === 0) piscar = !piscar;
  if (!document.hidden && W > 0) {
    g.setTransform(dpr, 0, 0, dpr, 0, 0); g.fillStyle = C.BG; g.fillRect(0, 0, W, H);
    g.fillStyle = C.PRI_GHO; for (let x = 0; x < W; x += 48) for (let y = 0; y < H; y += 48) g.fillRect(x, y, 1.2, 1.2);
    const faixa = Math.max(60, H - 70), r = Math.min(W * .46, faixa / 2 - 6);
    nucleo(W / 2, 8 + faixa / 2, r, W, faixa);
    const sy = faixa + 10;
    let txt, cor;
    const sim = (a, b) => piscar ? a : b;
    switch (S.estado) {
      case "MUTADO": txt = "⊘  MUTADO"; cor = C.MUTED_C; break;
      case "FALANDO": txt = "●  FALANDO"; cor = C.ACC; break;
      case "PENSANDO": txt = sim("◈", "◇") + "  PENSANDO"; cor = C.ACC2; break;
      case "PROCESSANDO": txt = sim("▷", "▶") + "  PROCESSANDO"; cor = C.ACC2; break;
      case "OUVINDO": txt = sim("●", "○") + "  OUVINDO"; cor = C.GREEN; break;
      case "SEM_CHAVE": txt = "⚠  FALTA A CHAVE DO GEMINI"; cor = C.RED; break;
      case "OFFLINE": txt = "⚠  SEM INTERNET"; cor = C.RED; break;
      default: txt = sim("●", "○") + "  " + (S.estado === "INICIANDO" ? "INICIANDO" : "PRONTO"); cor = C.PRI;
    }
    g.font = `bold 11px ${getComputedStyle(document.body).fontFamily}`; g.textAlign = "center"; g.textBaseline = "middle"; if ("letterSpacing" in g) g.letterSpacing = "1px";
    g.fillStyle = cor; g.fillText(txt, W / 2, sy + 6);
    const N = 36, bw = Math.min(8, (W - 20) / N), x0 = (W - N * bw) / 2, mid = (N - 1) / 2, wy = sy + 18;
    for (let i = 0; i < N; i++) {
      const env = Math.pow(1 - Math.abs(i - mid) / mid, .7), sh = .55 + .45 * Math.sin(tick * .18 + i * .7), idle = 3 + 2 * Math.sin(tick * .09 + i * .6);
      const hh = Math.max(2, Math.min(24, idle + amp * 22 * env * sh));
      g.fillStyle = amp > .05 ? (hh > 12 ? C.PRI : C.PRI_DIM) : C.BORDER_B; g.fillRect(x0 + i * bw, wy + 24 - hh, bw - 1, hh);
    }
  }
  requestAnimationFrame(desenhar);
}
cv.addEventListener("click", () => { if (S.estado === "OUVINDO") J.pararOuvir(); else if (S.estado === "FALANDO") interromper(); else falarComigo(); });

// ═══ métricas do aparelho (no PC eram CPU/RAM/GPU; aqui é o que o celular deixa ver) ════
let bateria = null;
try { navigator.getBattery && navigator.getBattery().then(b => { bateria = b; }); } catch (e) {}
function barra(id, pct, txt, inverso) {
  const v = Math.max(0, Math.min(100, pct || 0)), el = $("#b" + id); el.style.width = v + "%";
  const alto = inverso ? v < 15 : v > 85, medio = inverso ? v < 30 : v > 65;
  el.style.background = alto ? C.RED : medio ? C.ACC : C.PRI; const t = $("#v" + id); t.textContent = txt; t.style.color = txt === "--" ? C.TEXT_DIM : (alto ? C.RED : medio ? C.ACC : C.PRI);
}
function estadoAparelho() {
  const c = navigator.connection || {}, pm = performance.memory;
  return { bateria: bateria ? Math.round(bateria.level * 100) : null, carregando: bateria ? bateria.charging : null, online: navigator.onLine !== false,
    rede: c.effectiveType || (navigator.onLine === false ? "offline" : "online"), mbps: c.downlink || null,
    memoria_js: pm ? Math.round(100 * pm.usedJSHeapSize / pm.jsHeapSizeLimit) : null, ram_gb: navigator.deviceMemory || null,
    nucleos: navigator.hardwareConcurrency || null, fps, tela: `${screen.width}x${screen.height}`, hora: new Date().toLocaleString("pt-BR") };
}
function metricas() {
  const e = estadoAparelho();
  barra("Bat", e.bateria ?? 0, e.bateria == null ? "--" : e.bateria + "%" + (e.carregando ? "⚡" : ""), true);
  const redePct = !e.online ? 0 : e.mbps ? Math.min(100, e.mbps * 10) : 70;
  barra("Rede", redePct, !e.online ? "OFF" : (e.rede || "ON").toUpperCase(), true);
  const pm = performance.memory;
  barra("Ram", e.memoria_js ?? 0, pm ? Math.round(pm.usedJSHeapSize / 1048576) + "MB" : (e.ram_gb ? e.ram_gb + "GB" : "--"));
  barra("Fps", Math.min(100, fps / 60 * 100), String(fps), true);
  const d = new Date(); $("#relogio").textContent = d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
  const up = Math.floor((Date.now() - S.inicio) / 1000); $("#uptime").textContent = `UP ${String(Math.floor(up / 3600)).padStart(2, "0")}:${String(Math.floor(up / 60) % 60).padStart(2, "0")}`;
  if (S.estado === "PRONTO" || S.estado === "OFFLINE" || S.estado === "SEM_CHAVE") setEstado(!ler("j_chave") ? "SEM_CHAVE" : !e.online ? "OFFLINE" : "PRONTO");
}

// ═══ registro (LogWidget: digita letra a letra, com as cores de cada um) ═══════════
const fila = []; let digitando = false;
function log(texto, tag = "sys", extra = {}) { fila.push({ texto: String(texto), tag, extra }); if (!digitando) proximo(); }
function proximo() {
  const it = fila.shift(); if (!it) { digitando = false; return; } digitando = true;
  const d = document.createElement("div"); d.className = "l " + it.tag;
  const pref = { you: "VOCÊ ▸", ai: J.nomeAssistente().replace(/\./g, "") + " ▸", err: "ERRO ▸", file: "ARQUIVO ▸", sys: "◈" }[it.tag];
  d.innerHTML = `<span class="p">${esc(pref)}</span><span class="t"></span>`; $("#log").appendChild(d);
  const alvo = d.querySelector(".t"), txt = it.texto; let i = 0;
  const passo = Math.max(2, Math.ceil(txt.length / 90));
  const fim = () => {
    alvo.innerHTML = linkar(txt);
    if (it.extra.pre) { const p = document.createElement("pre"); p.textContent = it.extra.pre; d.appendChild(p); }
    if (it.extra.img) { const im = document.createElement("img"); im.src = it.extra.img; d.appendChild(im); }
    while ($("#log").children.length > 250) $("#log").firstChild.remove();
    $("#log").scrollTop = 1e9; setTimeout(proximo, 15);
  };
  if (document.hidden || fila.length > 3) return fim();
  (function digitar() { i += passo; alvo.textContent = txt.slice(0, i); $("#log").scrollTop = 1e9; if (i < txt.length) setTimeout(digitar, 8); else fim(); })();
}
function toast(t) { const e = $("#toast"); e.textContent = t; e.classList.add("v"); clearTimeout(toast.t); toast.t = setTimeout(() => e.classList.remove("v"), 2600); }

// ═══ janelas ═══════════════════════════════════════════════════════════════
const abrirOv = id => $("#" + id).classList.add("ab"), fecharOv = id => $("#" + id).classList.remove("ab");
$$(".ov").forEach(o => o.addEventListener("click", e => { if (e.target === o && o.id !== "setup" && o.id !== "confirmar") o.classList.remove("ab"); }));
function confirmar(texto) {
  return new Promise(res => {
    $("#cTexto").textContent = texto; abrirOv("confirmar"); J.bip(520, .1);
    $("#cSim").onclick = () => { fecharOv("confirmar"); res(true); }; $("#cNao").onclick = () => { fecharOv("confirmar"); res(false); };
  });
}
// gaveta
const gaveta = a => { $("#gaveta").classList.toggle("aberta", a); $("#veu").style.display = a ? "block" : "none"; };
$("#bGaveta").onclick = () => gaveta(!$("#gaveta").classList.contains("aberta")); $("#veu").onclick = () => gaveta(false);
$$("#gaveta [data-tela]").forEach(b => b.onclick = () => irPara(b.dataset.tela));
function irPara(tela) { J.parar(); J.pararOuvir(); guardar("j_historico", historico.slice(-30)); J.ir(tela); }
function rotulos() {
  $("#gHud").textContent = "◉ HUD: " + (ler("j_hud", "reator") === "rosto" ? "ROSTO HOLOGRÁFICO" : "NÚCLEO REATOR");
  $("#gMatinal").textContent = "☀ RESUMO MATINAL: " + (ler("j_matinal", "0") === "1" ? "SIM" : "NÃO");
  $("#gMatinal").classList.toggle("on", ler("j_matinal", "0") === "1");
  $("#bMaos").textContent = "🎙 MÃOS LIVRES: " + (S.maos ? "SIM" : "NÃO"); $("#bMaos").classList.toggle("on", S.maos);
  $("#logo").textContent = "◈ " + J.nomeAssistente(); document.title = J.nomeAssistente();
  $("#txt").placeholder = `Mande um comando para o ${J.nomeAssistente().replace(/\./g, "")}…`;
}
$("#gHud").onclick = () => { guardar("j_hud", ler("j_hud", "reator") === "rosto" ? "reator" : "rosto"); rotulos(); };
$("#gMatinal").onclick = () => { guardar("j_matinal", ler("j_matinal", "0") === "1" ? "0" : "1"); rotulos(); };
$("#gRemoto").onclick = () => { const pc = ler("j_pc"); if (pc) J.abrirExterno(pc); else { toast("Ponha o endereço do JARVIS do PC em MOTOR & PROVEDORES"); abrirProv(); } };
$("#gTela").onclick = async () => { try { if (document.fullscreenElement) await document.exitFullscreen(); else await document.documentElement.requestFullscreen(); } catch (e) { toast("Tela cheia não disponível aqui"); } };
$("#gLimpar").onclick = async () => { if (await confirmar("Apagar a conversa? (a memória e as notas ficam)")) { historico = []; guardar("j_historico", []); $("#log").innerHTML = ""; log("Conversa apagada.", "sys"); } };
$("#bCarro").onclick = () => { document.body.classList.toggle("carro"); guardar("j_carro", document.body.classList.contains("carro") ? "1" : "0"); requestAnimationFrame(ajustarHud); };

// configuração inicial
$("#sIniciar").onclick = () => {
  const k = $("#sChave").value.trim(); if (!k) { $("#sChave").focus(); toast("Cole a chave do Gemini"); return; }
  guardar("j_chave", k); guardar("j_nome", $("#sNome").value.trim()); guardar("j_cidade", $("#sCidade").value.trim());
  fecharOv("setup"); setEstado("PRONTO"); J.audio(); saudar(true);
};
$("#sDepois").onclick = () => { fecharOv("setup"); setEstado("SEM_CHAVE"); log("Sem a chave eu não penso, mas as telas (Arcade, Player, Missões…) funcionam. Cole a chave em ⚙ → MOTOR & PROVEDORES quando quiser.", "sys"); };
// personalizar
const CORES = ["#00d4ff", "#00ff88", "#ff3355", "#ffcc00", "#ff6b00", "#b47cff", "#ff4fd8", "#e8e8e8"];
let corTmp = ler("j_cor", "#00d4ff");
function hueDe(hex) { const [r, gg, b] = rgb(hex).map(x => x / 255), mx = Math.max(r, gg, b), mn = Math.min(r, gg, b), d = mx - mn; if (!d) return 190; let h = mx === r ? ((gg - b) / d) % 6 : mx === gg ? (b - r) / d + 2 : (r - gg) / d + 4; return Math.round(((h * 60) + 360) % 360); }
function hexDeHue(h) { const f = n => { const k = (n + h / 60) % 6; return Math.round(255 * (1 - Math.max(0, Math.min(k, 4 - k, 1)))); }; return "#" + [f(5), f(3), f(1)].map(x => x.toString(16).padStart(2, "0")).join(""); }
function previaCor(hex) { corTmp = hex; guardar("j_cor_tmp", hex); const old = ler("j_cor", "#00d4ff"); guardar("j_cor", hex); C = J.aplicarTema(); guardar("j_cor", old); $$("#pCores i").forEach(i => i.classList.toggle("on", i.dataset.c === hex)); }
$("#gPerso").onclick = () => {
  gaveta(false); $("#pAssist").value = ler("j_assist", ""); $("#pNome").value = ler("j_nome", ""); $("#pPersona").value = ler("j_persona", "jarvis");
  corTmp = ler("j_cor", "#00d4ff"); $("#pHue").value = hueDe(corTmp);
  $("#pCores").innerHTML = CORES.map(c => `<i data-c="${c}" style="background:${c}"></i>`).join(""); $$("#pCores i").forEach(i => i.onclick = () => { previaCor(i.dataset.c); $("#pHue").value = hueDe(i.dataset.c); });
  previaCor(corTmp); abrirOv("perso");
};
$("#pHue").oninput = e => previaCor(hexDeHue(+e.target.value));
$("#pPadrao").onclick = () => { previaCor("#00d4ff"); $("#pHue").value = hueDe("#00d4ff"); };
$("#pCancelar").onclick = () => { C = J.aplicarTema(); fecharOv("perso"); };
$("#pSalvar").onclick = () => {
  guardar("j_cor", corTmp); guardar("j_assist", $("#pAssist").value.trim()); guardar("j_nome", $("#pNome").value.trim()); guardar("j_persona", $("#pPersona").value);
  C = J.aplicarTema(); rotulos(); metricas(); fecharOv("perso"); toast("Aplicado ✓");
};
// motor & provedores
function abrirProv() {
  gaveta(false); $("#vChave").value = ler("j_chave"); const m = J.modelo(), padrao = [...$("#vModelo").options].some(o => o.value === m);
  $("#vModelo").value = padrao ? m : "outro"; $("#vModeloOutro").value = padrao ? "" : m; $("#vModeloOutro").style.display = padrao ? "none" : "";
  $("#vFalar").value = ler("j_falar", "auto"); $("#vVozGem").value = ler("j_vozgem", ""); $("#vVel").value = ler("j_vel", "1"); $("#vStt").value = ler("j_stt", "auto");
  $("#vCidade").value = ler("j_cidade"); $("#vPc").value = ler("j_pc");
  const vz = J.carregarVozes(); $("#vVoz").innerHTML = vz.length ? vz.map((v, i) => `<option value="${i}">${esc(v.name)} (${v.lang})</option>`).join("") : "<option value='0'>(o aparelho não informou vozes)</option>";
  $("#vVoz").value = ler("j_voz", "0"); abrirOv("prov");
}
$("#gProv").onclick = abrirProv;
$("#vModelo").onchange = () => { $("#vModeloOutro").style.display = $("#vModelo").value === "outro" ? "" : "none"; };
$("#vDetectar").onclick = async () => {
  const chave = $("#vChave").value.trim(); if (!chave) { toast("Cole a chave primeiro"); return; }
  guardar("j_chave", chave); $("#vModelos").textContent = "consultando o Google…";
  try {
    const nomes = await J.listarModelos(), melhor = J.melhorDe(nomes, "texto"), sel = $("#vModelo");
    for (const n of nomes.filter(x => /^gemini-/.test(x) && !/tts|image|live|embed|audio|transcribe/.test(x)))
      if (![...sel.options].some(o => o.value === n)) sel.add(new Option(n, n), sel.options[sel.options.length - 1]);
    if (melhor) { sel.value = melhor; $("#vModeloOutro").style.display = "none"; }
    $("#vModelos").textContent = `${nomes.length} modelo(s) na sua chave. Escolhi o ${melhor || "padrão"}.`;
  } catch (e) { $("#vModelos").textContent = "⚠ " + e.message; }
};
function salvarProv() {
  guardar("j_chave", $("#vChave").value.trim()); guardar("j_modelo", $("#vModelo").value === "outro" ? $("#vModeloOutro").value.trim() : $("#vModelo").value);
  guardar("j_falar", $("#vFalar").value); guardar("j_voz", $("#vVoz").value); guardar("j_vozgem", $("#vVozGem").value); guardar("j_vel", $("#vVel").value);
  guardar("j_stt", $("#vStt").value); guardar("j_cidade", $("#vCidade").value.trim()); guardar("j_pc", $("#vPc").value.trim());
}
$("#vSalvar").onclick = () => { salvarProv(); fecharOv("prov"); metricas(); toast("Salvo ✓"); };
$("#vFechar").onclick = () => fecharOv("prov");
$("#vTestar").onclick = () => { salvarProv(); falarResposta(`Sistemas online, ${J.nomeDono()}. É assim que eu falo.`); };

// memória (memórias, notas, gastos, diário, cápsulas)
const ABAS = { memorias: "🧠 LEMBRANÇAS", notas: "📝 NOTAS", gastos: "💸 GASTOS", diario: "📔 DIÁRIO", capsulas: "⏳ CÁPSULAS" };
let abaMem = "memorias";
function dadosAba(a) { return a === "memorias" ? memorias : a === "notas" ? notas : lerJSON("j_" + a, []); }
function gravarAba(a, l) { if (a === "memorias") memorias = l; else if (a === "notas") notas = l; else guardar("j_" + a, l); salvarMem(); }
function listarMem() {
  $("#mAbas").innerHTML = Object.entries(ABAS).map(([k, v]) => `<button data-a="${k}" class="${k === abaMem ? "on" : ""}">${v}</button>`).join("");
  $$("#mAbas button").forEach(b => b.onclick = () => { abaMem = b.dataset.a; listarMem(); });
  const l = dadosAba(abaMem), dt = ts => new Date(ts).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" });
  const txt = x => abaMem === "gastos" ? `R$ ${(+x.valor).toFixed(2).replace(".", ",")} — ${x.desc || ""} (${x.cat || "geral"})` : abaMem === "capsulas" ? `${x.aberta ? "" : "🔒 "}${x.aberta ? x.texto : "abre em " + new Date(x.abrir).toLocaleDateString("pt-BR")}` : x.texto;
  $("#mLista").innerHTML = l.length ? l.map((x, i) => `<div class="item"><span>${linkar(txt(x))}<small>${dt(x.ts)}</small></span><button data-i="${i}">✕</button></div>`).reverse().join("") : `<div class="item"><span>Nada ainda.</span></div>`;
  $$("#mLista button").forEach(b => b.onclick = () => { const l2 = dadosAba(abaMem); l2.splice(+b.dataset.i, 1); gravarAba(abaMem, l2); listarMem(); });
  if (abaMem === "gastos") { const mes = new Date().toISOString().slice(0, 7), tot = l.filter(x => new Date(x.ts).toISOString().slice(0, 7) === mes).reduce((s, x) => s + +x.valor, 0); $("#mResumo").textContent = `Este mês: R$ ${tot.toFixed(2).replace(".", ",")} em ${l.length} lançamento(s).`; }
  else $("#mResumo").textContent = `Diga "lembra que…", "anota…", "gastei 30 no almoço", "vamos fazer o diário" ou "guarda um recado pro meu eu daqui 1 ano".`;
}
$("#gMem").onclick = () => { gaveta(false); listarMem(); abrirOv("memoria"); };
$("#mFechar").onclick = () => fecharOv("memoria");
function backup() { const d = { versao: "2.4-app", nome: ler("j_nome") }; for (const k of ["memorias", "notas", "gastos", "diario", "capsulas", "missoes", "evolucao", "habitos"]) d[k] = lerJSON("j_" + k, []); return JSON.stringify(d); }
$("#mCopiar").onclick = async () => { if (await J.copiar(backup(), "BACKUP")) toast("Backup copiado ✓"); };
$("#mColar").onclick = async () => {
  const t = await J.caixa({ titulo: "COLAR BACKUP", texto: "Cole aqui o backup copiado de outro aparelho. O que estiver nele substitui o daqui.", editavel: true, ok: "▸ RESTAURAR", cancelar: "CANCELAR" }); if (!t) return;
  try { const d = JSON.parse(t); for (const k of ["memorias", "notas", "gastos", "diario", "capsulas", "missoes", "evolucao", "habitos"]) if (d[k]) guardar("j_" + k, d[k]); if (d.nome) guardar("j_nome", d.nome);
    memorias = lerJSON("j_memorias", []); notas = lerJSON("j_notas", []); listarMem(); toast("Backup restaurado ✓"); } catch (e) { toast("Esse backup não é válido"); }
};

// ═══ plugins e ferramentas ══════════════════════════════════════════════════════
const T = (name, description, props = {}, required = []) => ({ name, description, parameters: { type: "OBJECT", properties: props, required } });
const s = (d) => ({ type: "STRING", ...(d ? { description: d } : {}) }), n = (d) => ({ type: "NUMBER", ...(d ? { description: d } : {}) }), b = (d) => ({ type: "BOOLEAN", ...(d ? { description: d } : {}) });
const PLUGINS = {
  memoria: { nome: "MEMÓRIA", desc: "Lembra de você, notas e listas.", sempre: true, f: [
    T("lembrar", "Guarda um fato duradouro sobre o usuário (gostos, pessoas, projetos, decisões) quando ele contar algo importante ou pedir 'lembra que…'.", { fato: s() }, ["fato"]),
    T("esquecer", "Apaga lembranças que contenham um trecho.", { trecho: s() }, ["trecho"]),
    T("buscar_memoria", "Procura nas lembranças, notas e diário por significado (ex.: 'o que eu decidi sobre o capacete?').", { pergunta: s() }, ["pergunta"]),
    T("anotar", "Guarda uma nota ou item de lista (compras, ideias, tarefas).", { texto: s() }, ["texto"]),
    T("ver_notas", "Lê as notas guardadas."),
    T("apagar_nota", "Apaga notas que contenham um trecho (ou 'tudo').", { trecho: s() }, ["trecho"])] },
  internet: { nome: "INTERNET", desc: "Pesquisa, clima, cotação do dólar e briefing.", f: [
    T("pesquisar", "Pesquisa na internet algo atual (notícias, placares, preços, horários, fatos recentes) e devolve um resumo com fontes.", { pergunta: s() }, ["pergunta"]),
    T("clima", "Clima agora e previsão de hoje e dos próximos dias.", { cidade: s("vazio = a cidade do usuário") }),
    T("cotacao", "Cotação do dólar, euro e bitcoin em reais."),
    T("briefing", "Junta clima, cotação, estado do aparelho, missões do dia e manchetes para o resumo do dia.")] },
  celular: { nome: "CELULAR", desc: "Música, WhatsApp, ligação, rota, agenda, links.", f: [
    T("tocar_musica", "Toca música: abre a busca no Spotify ou no YouTube Music (ou o player local do app).", { pedido: s(), servico: s("spotify | youtube | local") }, ["pedido"]),
    T("youtube", "Busca vídeos no YouTube.", { busca: s() }, ["busca"]),
    T("abrir_link", "Abre um site ou link.", { url: s() }, ["url"]),
    T("mandar_whatsapp", "Prepara uma mensagem de WhatsApp; o usuário escolhe o contato e confirma no WhatsApp.", { texto: s(), numero: s("com DDI e DDD, só números (opcional)") }, ["texto"]),
    T("ligar", "Abre o discador com o número (o usuário confirma).", { numero: s() }, ["numero"]),
    T("rota", "Abre a rota no Google Maps.", { destino: s() }, ["destino"]),
    T("agenda", "Cria um evento no Google Agenda (o usuário confirma lá).", { titulo: s(), inicio: s("AAAA-MM-DDTHH:MM"), minutos: n() }, ["titulo", "inicio"]),
    T("copiar", "Copia um texto para a área de transferência.", { texto: s() }, ["texto"]),
    T("status_aparelho", "Bateria, rede, memória, núcleos e desempenho deste aparelho.")] },
  tempo: { nome: "MISSÕES & TEMPO", desc: "Lembretes, despertador, repetições e pomodoro que sobrevivem ao fechar o app.", f: [
    T("lembrete", "Avisa daqui a N minutos ou numa data/hora.", { texto: s(), minutos: n("daqui a quantos minutos"), quando: s("ou AAAA-MM-DDTHH:MM") }, ["texto"]),
    T("despertador", "Despertador numa hora (HH:MM), opcionalmente todo dia.", { hora: s("HH:MM"), texto: s(), todo_dia: b() }, ["hora"]),
    T("repetir", "Aviso que se repete (ex.: beber água a cada 60 min, 8 vezes).", { texto: s(), a_cada_minutos: n(), vezes: n("0 = sem fim") }, ["texto", "a_cada_minutos"]),
    T("pomodoro", "Pomodoro: foco e pausa em ciclos.", { tarefa: s(), foco: n("min, padrão 25"), pausa: n("min, padrão 5"), ciclos: n("padrão 4") }),
    T("missoes", "Lista, pausa, continua ou cancela missões.", { acao: s("listar | pausar | continuar | cancelar"), id: n() })] },
  telas: { nome: "TELAS", desc: "Abre o Arcade, player, missões, mapa da memória, monitor, armadura, holograma e a visão.", f: [
    T("abrir_tela", "Abre uma tela do app.", { tela: s("arcade | player | missoes | mapa_memoria | monitor | armadura | holograma | visao") }, ["tela"]),
    T("modo_carro", "Liga ou desliga o modo carro (só o essencial, botão grande).", { ligar: b() }, ["ligar"]),
    T("tema", "Muda a cor da interface ou o estilo do HUD.", { cor: s("nome ou #hex"), hud: s("reator | rosto") })] },
  jogos: { nome: "JOGOS", desc: "Xadrez (motor próprio) e damas brasileiras por voz, e o Arcade com 14 jogos.", f: [
    T("xadrez", "Xadrez e damas por voz contra o JARVIS. action='novo' com jogo (xadrez|damas), nivel (facil|medio|dificil), cor (brancas|pretas); action='lance' com o lance exatamente como o usuário falou ('cavalo para f3', 'e2 e4', 'roque pequeno', 'c3 d4'); 'tabuleiro'; 'desistir'. Leia a resposta como veio.", { action: s(), jogo: s(), nivel: s(), cor: s(), lance: s() })] },
  gastos: { nome: "GASTOS", desc: "Controle de gastos por voz com resumo do mês.", f: [
    T("registrar_gasto", "Registra um gasto.", { valor: n("em reais"), descricao: s(), categoria: s("alimentação, transporte, loja, lazer, contas…") }, ["valor"]),
    T("resumo_gastos", "Resumo dos gastos de um mês, por categoria.", { mes: s("AAAA-MM, vazio = este mês") })] },
  vida: { nome: "DIÁRIO & CÁPSULA", desc: "Diário por entrevista e cápsula do tempo.", f: [
    T("diario", "Guarda uma entrada do diário (o que o usuário contou do dia) ou consulta um período.", { acao: s("guardar | consultar"), texto: s(), periodo: s("AAAA-MM ou AAAA-MM-DD") }, ["acao"]),
    T("capsula_tempo", "Guarda um recado para o usuário do futuro; ele só abre na data.", { texto: s(), dias: n("daqui a quantos dias") }, ["texto", "dias"])] },
  seguranca: { nome: "SEGURANÇA", desc: "Senha vazada (sem enviar a senha) e detector de golpe.", f: [
    T("senha_vazada", "Confere se uma senha já apareceu em vazamentos (Have I Been Pwned, só os 5 primeiros caracteres do hash saem do aparelho).", { senha: s() }, ["senha"])] },
  pessoal: { nome: "PERSONALIDADE", desc: "Persona JARVIS/FRIDAY e evolução do jeito de responder.", f: [
    T("trocar_persona", "Troca entre JARVIS e FRIDAY.", { persona: s("jarvis | friday") }, ["persona"]),
    T("evolucao", "O que o assistente aprendeu sobre o jeito preferido de resposta; fixar ou pausar.", { acao: s("placar | fixar_curto | fixar_completo | pausar | continuar | zerar") }, ["acao"])] },
  pc: { nome: "JARVIS DO PC", desc: "Abre o JARVIS completo do PC (controle do PC e da casa).", f: [
    T("abrir_jarvis_pc", "Abre o JARVIS completo do PC, se o endereço estiver configurado e o PC ligado.")] },
  voz: { nome: "MÃOS LIVRES", desc: "Conversa contínua por voz.", sempre: true, f: [
    T("parar_maos_livres", "Desliga o modo mãos livres quando o usuário pedir para parar de ouvir.")] },
};
const plugAtivo = k => PLUGINS[k].sempre || ler("j_plug_" + k, "1") === "1";
function ferramentas() { return Object.keys(PLUGINS).filter(plugAtivo).flatMap(k => PLUGINS[k].f); }
function listarPlugins() {
  $("#plLista").innerHTML = Object.entries(PLUGINS).map(([k, p]) => `<div class="plug"><div><b>${p.nome}</b><small>${esc(p.desc)} · ${p.f.length} ferramenta(s)</small></div><button data-k="${k}" class="${plugAtivo(k) ? "on" : ""}" ${p.sempre ? "disabled" : ""}>${plugAtivo(k) ? "ATIVO" : "INATIVO"}</button></div>`).join("");
  $$("#plLista button").forEach(bt => bt.onclick = () => { guardar("j_plug_" + bt.dataset.k, plugAtivo(bt.dataset.k) ? "0" : "1"); listarPlugins(); });
}
$("#gPlug").onclick = () => { gaveta(false); listarPlugins(); abrirOv("plugins"); };
$("#plFechar").onclick = () => fecharOv("plugins");

const TELAS = { arcade: "arcade.html", jogos: "arcade.html", player: "player.html", musica: "player.html", missoes: "missoes.html", mapa_memoria: "grafo.html", grafo: "grafo.html", memoria: "grafo.html",
  monitor: "monitor.html", armadura: "armadura.html", holograma: "holograma.html", visao: "ar.html", ar: "ar.html", camera: "ar.html" };
const CORNOME = { azul: "#00d4ff", ciano: "#00d4ff", verde: "#00ff88", vermelho: "#ff3355", amarelo: "#ffcc00", dourado: "#ffcc00", laranja: "#ff6b00", roxo: "#b47cff", rosa: "#ff4fd8", branco: "#e8e8e8", cinza: "#e8e8e8" };
const palavras = t => dobrar(t).split(/[^a-z0-9]+/).filter(w => w.length > 2 && !["que", "para", "com", "uma", "das", "dos", "nao", "sim", "por", "mas", "meu", "minha", "sobre", "como", "isso", "esse", "essa", "foi", "ele", "ela"].includes(w));
function parecido(a, b) { const A = new Set(palavras(a).map(w => w.slice(0, 5))), B = palavras(b).map(w => w.slice(0, 5)); if (!A.size || !B.length) return 0; return B.filter(w => A.has(w)).length / Math.sqrt(A.size * B.length); }
async function sha1(t) {
  if (crypto.subtle) { const h = await crypto.subtle.digest("SHA-1", new TextEncoder().encode(t)); return [...new Uint8Array(h)].map(x => x.toString(16).padStart(2, "0")).join("").toUpperCase(); }
  throw new Error("este aparelho não calcula SHA-1 aqui");
}
async function clima(cidade) {
  cidade = cidade || ler("j_cidade") || "Goiânia";
  const geo = await (await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(cidade)}&count=1&language=pt`)).json();
  const lugar = (geo.results || [])[0]; if (!lugar) return { erro: "cidade não encontrada: " + cidade };
  const d = await (await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lugar.latitude}&longitude=${lugar.longitude}&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code&timezone=auto&forecast_days=4`)).json();
  const WMO = { 0: "céu limpo", 1: "quase limpo", 2: "parcialmente nublado", 3: "nublado", 45: "neblina", 48: "neblina", 51: "garoa", 53: "garoa", 55: "garoa forte", 61: "chuva fraca", 63: "chuva", 65: "chuva forte", 80: "pancadas de chuva", 81: "pancadas fortes", 82: "temporal", 95: "trovoadas", 96: "trovoadas com granizo", 99: "trovoadas com granizo" };
  const c = d.current || {}, dd = d.daily || {};
  return { cidade: `${lugar.name}, ${lugar.admin1 || ""}`, agora: `${Math.round(c.temperature_2m)}°C (sensação ${Math.round(c.apparent_temperature)}°C), ${WMO[c.weather_code] || ""}, umidade ${c.relative_humidity_2m}%, vento ${Math.round(c.wind_speed_10m)} km/h`,
    dias: (dd.time || []).map((t, i) => `${t}: ${Math.round(dd.temperature_2m_min[i])}–${Math.round(dd.temperature_2m_max[i])}°C, ${WMO[dd.weather_code[i]] || ""}, chuva ${dd.precipitation_probability_max[i]}%`) };
}
async function cotacao() {
  const d = await (await fetch("https://economia.awesomeapi.com.br/json/last/USD-BRL,EUR-BRL,BTC-BRL")).json();
  const f = k => d[k] ? `R$ ${(+d[k].bid).toLocaleString("pt-BR", { maximumFractionDigits: 2 })} (${(+d[k].pctChange) >= 0 ? "+" : ""}${d[k].pctChange}%)` : "n/d";
  return { dolar: f("USDBRL"), euro: f("EURBRL"), bitcoin: f("BTCBRL") };
}
async function pesquisar(p) {
  const j = await J.gemini({ contents: [{ role: "user", parts: [{ text: p + "\n(Responda em português do Brasil, direto, com os fatos e números atuais.)" }] }], tools: [{ google_search: {} }] });
  const cand = ((j.candidates || [])[0] || {}), fontes = (((cand.groundingMetadata || {}).groundingChunks) || []).map(c => c.web && c.web.title).filter(Boolean).slice(0, 4);
  return { resposta: J.textoDe(j).slice(0, 3500), fontes };
}
const quandoDe = (min, quando) => { if (quando) { const d = new Date(quando); if (!isNaN(d)) return d.getTime(); } return Date.now() + Math.max(0.1, +min || 1) * 60000; };
function externo(url) { log("↗ " + url, "sys"); return J.abrirExterno(url); }
async function executar(nome, a) {
  switch (nome) {
    case "lembrar": memorias.push({ ts: Date.now(), texto: String(a.fato || "").slice(0, 400) }); salvarMem(); log("🧠 Guardado: " + a.fato, "file"); return { ok: true };
    case "esquecer": { const t = dobrar(a.trecho), antes = memorias.length; memorias = memorias.filter(m => !dobrar(m.texto).includes(t)); salvarMem(); return { apagadas: antes - memorias.length }; }
    case "buscar_memoria": {
      const fontes = [...memorias.map(m => ["lembrança", m]), ...notas.map(m => ["nota", m]), ...lerJSON("j_diario", []).map(m => ["diário", m])];
      const r = fontes.map(([tipo, m]) => ({ tipo, texto: m.texto, data: new Date(m.ts).toLocaleDateString("pt-BR"), nota: parecido(a.pergunta, m.texto) })).filter(x => x.nota > 0).sort((x, y) => y.nota - x.nota).slice(0, 8);
      return r.length ? { resultados: r } : { resultados: [], todas_lembrancas: memorias.slice(-40).map(m => m.texto) };
    }
    case "anotar": notas.push({ ts: Date.now(), texto: String(a.texto || "").slice(0, 600) }); salvarMem(); log("📝 " + a.texto, "file"); return { ok: true, total: notas.length };
    case "ver_notas": return { notas: notas.map(x => x.texto) };
    case "apagar_nota": { const t = dobrar(a.trecho), antes = notas.length; notas = t === "tudo" ? [] : notas.filter(x => !dobrar(x.texto).includes(t)); salvarMem(); return { apagadas: antes - notas.length }; }
    case "pesquisar": setEstado("PROCESSANDO"); return await pesquisar(a.pergunta);
    case "clima": return await clima(a.cidade);
    case "cotacao": return await cotacao();
    case "briefing": {
      const r = { hora: new Date().toLocaleString("pt-BR", { weekday: "long", hour: "2-digit", minute: "2-digit" }), aparelho: estadoAparelho(),
        missoes_ativas: Missoes.listar().filter(m => m.estado === "ativa").map(Missoes.descrever).slice(0, 6) };
      await Promise.all([clima().then(x => r.clima = x).catch(() => {}), cotacao().then(x => r.cotacao = x).catch(() => {}), pesquisar("Principais manchetes do Brasil hoje, em 4 tópicos curtos.").then(x => r.manchetes = x.resposta).catch(() => {})]);
      return r;
    }
    case "tocar_musica": {
      const q = encodeURIComponent(a.pedido || ""), sv = dobrar(a.servico);
      if (sv.includes("local")) { irPara("player.html?q=" + q); return { ok: true }; }
      return externo(sv.includes("you") ? `https://music.youtube.com/search?q=${q}` : `https://open.spotify.com/search/${q}`);
    }
    case "youtube": return externo("https://www.youtube.com/results?search_query=" + encodeURIComponent(a.busca || ""));
    case "abrir_link": { let u = String(a.url || ""); if (!/^[a-z]+:/i.test(u)) u = "https://" + u; return externo(u); }
    case "mandar_whatsapp": {
      if (!await confirmar(`Abrir o WhatsApp com a mensagem:\n"${a.texto}"` + (a.numero ? `\npara ${a.numero}?` : "?"))) return { cancelado: true };
      return { ...externo(`https://wa.me/${String(a.numero || "").replace(/\D/g, "")}?text=${encodeURIComponent(a.texto || "")}`), observacao: "o usuário confirma o envio no WhatsApp" };
    }
    case "ligar": { const num = String(a.numero || "").replace(/[^\d+]/g, ""); if (!await confirmar("Ligar para " + num + "?")) return { cancelado: true }; return externo("tel:" + num); }
    case "rota": return externo("https://www.google.com/maps/dir/?api=1&destination=" + encodeURIComponent(a.destino || ""));
    case "agenda": {
      const ini = new Date(a.inicio); if (isNaN(ini)) return { erro: "data inválida" };
      const fim = new Date(ini.getTime() + (+a.minutos || 60) * 60000), f = d => d.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
      return externo(`https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(a.titulo || "")}&dates=${f(ini)}/${f(fim)}`);
    }
    case "copiar": return { ok: await J.copiar(String(a.texto || "")) };
    case "status_aparelho": return estadoAparelho();
    case "lembrete": { const m = Missoes.criar({ tipo: "lembrete", titulo: a.texto, alvo: quandoDe(a.minutos, a.quando) }); return { ok: true, missao: Missoes.descrever(m), observacao: "toca com o app aberto; se ele estiver fechado, toca quando abrir" }; }
    case "despertador": {
      const [hh, mm] = String(a.hora || "07:00").split(":").map(Number), d = new Date(); d.setHours(hh || 0, mm || 0, 0, 0); if (d <= new Date()) d.setDate(d.getDate() + 1);
      const m = Missoes.criar({ tipo: "despertador", titulo: a.texto || "Hora de acordar", alvo: d.getTime(), diario: !!a.todo_dia }); return { ok: true, missao: Missoes.descrever(m), observacao: "deixe o app aberto e a tela ligada (ou o celular na tomada)" };
    }
    case "repetir": { const m = Missoes.criar({ tipo: "repetir", titulo: a.texto, alvo: Date.now() + a.a_cada_minutos * 60000, intervalo: a.a_cada_minutos * 60000, repeticoes: +a.vezes || 0 }); return { ok: true, missao: Missoes.descrever(m) }; }
    case "pomodoro": { const foco = +a.foco || 25; const m = Missoes.criar({ tipo: "pomodoro", titulo: a.tarefa || "Foco", alvo: Date.now() + foco * 60000, foco, pausa: +a.pausa || 5, ciclos: +a.ciclos || 4 }); return { ok: true, missao: Missoes.descrever(m) }; }
    case "missoes": {
      const ac = dobrar(a.acao || "listar");
      if (ac !== "listar" && a.id) return Missoes.comando(ac, a.id);
      return { missoes: Missoes.listar().filter(m => m.estado === "ativa" || m.estado === "pausada").map(m => ({ id: m.id, ...{ descricao: Missoes.descrever(m) } })) };
    }
    case "abrir_tela": { const t = TELAS[dobrar(a.tela).replace(/\s+/g, "_")] || TELAS[Object.keys(TELAS).find(k => dobrar(a.tela).includes(k.split("_")[0]))]; if (!t) return { erro: "tela desconhecida" }; setTimeout(() => irPara(t), 1800); return { ok: true, abrindo: t }; }
    case "modo_carro": document.body.classList.toggle("carro", !!a.ligar); guardar("j_carro", a.ligar ? "1" : "0"); requestAnimationFrame(ajustarHud); return { ok: true };
    case "tema": {
      if (a.cor) { const c = CORNOME[dobrar(a.cor)] || (/^#[0-9a-f]{6}$/i.test(a.cor) ? a.cor : null); if (c) { guardar("j_cor", c); C = J.aplicarTema(); } }
      if (a.hud) guardar("j_hud", dobrar(a.hud).includes("rost") ? "rosto" : "reator"); rotulos(); return { ok: true };
    }
    case "xadrez": { const r = Motor.porVoz(a); if (r.tabuleiro) log("Tabuleiro:", "sys", { pre: r.tabuleiro }); return { fala: r.fala, observacao: "o Arcade (abrir_tela arcade) mostra o mesmo jogo para clicar" }; }
    case "registrar_gasto": { const l = lerJSON("j_gastos", []); l.push({ ts: Date.now(), valor: +a.valor || 0, desc: a.descricao || "", cat: String(a.categoria || "geral").toLowerCase().trim() }); guardar("j_gastos", l); log(`💸 R$ ${(+a.valor).toFixed(2)} — ${a.descricao || ""}`, "file"); return { ok: true }; }
    case "resumo_gastos": {
      const mes = a.mes || new Date().toISOString().slice(0, 7), l = lerJSON("j_gastos", []).filter(x => new Date(x.ts).toISOString().slice(0, 7) === mes), por = {};
      for (const x of l) por[x.cat] = (por[x.cat] || 0) + x.valor; return { mes, total: l.reduce((s2, x) => s2 + x.valor, 0), por_categoria: por, lancamentos: l.length, maiores: l.sort((x, y) => y.valor - x.valor).slice(0, 5).map(x => `${x.desc} R$ ${x.valor}`) };
    }
    case "diario": {
      const l = lerJSON("j_diario", []);
      if (dobrar(a.acao).startsWith("guard")) { l.push({ ts: Date.now(), texto: String(a.texto || "").slice(0, 3000) }); guardar("j_diario", l); return { ok: true }; }
      const p = String(a.periodo || ""); const r = l.filter(x => !p || new Date(x.ts).toISOString().startsWith(p)).slice(-20).map(x => ({ data: new Date(x.ts).toLocaleDateString("pt-BR"), texto: x.texto }));
      return { entradas: r };
    }
    case "capsula_tempo": { const l = lerJSON("j_capsulas", []); const abrir = Date.now() + Math.max(1, +a.dias || 1) * 86400000; l.push({ ts: Date.now(), abrir, texto: a.texto, aberta: false }); guardar("j_capsulas", l); return { ok: true, abre_em: new Date(abrir).toLocaleDateString("pt-BR") }; }
    case "senha_vazada": {
      const h = await sha1(String(a.senha || "")), r = await fetch("https://api.pwnedpasswords.com/range/" + h.slice(0, 5)), txt = await r.text();
      const linha2 = txt.split("\n").find(l => l.startsWith(h.slice(5))); const vezes = linha2 ? +linha2.split(":")[1] : 0;
      return { vazada: vezes > 0, vezes, observacao: "só os 5 primeiros caracteres do hash saíram do aparelho; a senha não foi enviada" };
    }
    case "trocar_persona": { const p = dobrar(a.persona).includes("fri") ? "friday" : "jarvis"; guardar("j_persona", p); if (p === "friday" && !ler("j_assist")) guardar("j_assist", "F.R.I.D.A.Y"); if (p === "jarvis" && ler("j_assist") === "F.R.I.D.A.Y") guardar("j_assist", ""); rotulos(); return { ok: true, persona: p }; }
    case "evolucao": return Evolucao.comando(dobrar(a.acao));
    case "abrir_jarvis_pc": { const pc = ler("j_pc"); if (!pc) return { erro: "o endereço do JARVIS do PC não está configurado (⚙ → MOTOR & PROVEDORES)" }; return externo(pc); }
    case "parar_maos_livres": S.maos = false; rotulos(); J.pararOuvir(); return { ok: true };
  }
  return { erro: "ferramenta desconhecida" };
}

// ═══ evolução: testa jeitos de responder e fica com o que funciona (amostragem de Thompson) ═══
const Evolucao = (() => {
  const EIXOS = { tamanho: ["curto", "completo"], tom: ["formal", "descontraido"], ordem: ["resposta_antes", "passos_antes"] };
  const TXT = { curto: "Responda bem curto (1 a 2 frases).", completo: "Responda completo, mas falável (3 a 5 frases).", formal: "Tom formal e elegante.", descontraido: "Tom descontraído, brasileiro, com gíria leve.",
    resposta_antes: "Dê a resposta/conclusão primeiro.", passos_antes: "Quando houver passos, diga os passos primeiro e conclua no fim." };
  const dados = () => lerJSON("j_evolucao", { placar: {}, fixo: {}, pausado: false, ultimo: null });
  const beta = (a2, b2) => { const ga = k => { let x = 0; for (let i = 0; i < k; i++) x -= Math.log(Math.random()); return x; }; const x = ga(Math.max(1, Math.round(a2))), y = ga(Math.max(1, Math.round(b2))); return x / (x + y); };
  function escolher() {
    const d = dados(), esc2 = {};
    for (const [eixo, ops] of Object.entries(EIXOS)) {
      if (d.fixo[eixo]) { esc2[eixo] = d.fixo[eixo]; continue; }
      if (d.pausado) { esc2[eixo] = ops.reduce((m, o) => ((d.placar[o] || [1, 1])[0] / ((d.placar[o] || [1, 1])[0] + (d.placar[o] || [1, 1])[1])) > ((d.placar[m] || [1, 1])[0] / ((d.placar[m] || [1, 1])[0] + (d.placar[m] || [1, 1])[1])) ? o : m); continue; }
      esc2[eixo] = ops.map(o => [beta(...(d.placar[o] || [1, 1])), o]).sort((x, y) => y[0] - x[0])[0][1];
    }
    d.ultimo = esc2; guardar("j_evolucao", d); return Object.values(esc2).map(o => TXT[o]).join(" ");
  }
  function pontuar(ok) { const d = dados(); if (!d.ultimo) return; for (const o of Object.values(d.ultimo)) { const p = d.placar[o] || [1, 1]; p[ok ? 0 : 1]++; d.placar[o] = p; } d.ultimo = null; guardar("j_evolucao", d); }
  function julgar(texto) {
    const t = dobrar(texto);
    if (/^(nao|errado)\b|nao foi isso|nao e isso|^repete|^o que\??$|^o que\b.{0,6}$|^hein|explica melhor|nao entendi|^resume|mais curto|muito longo/.test(t)) pontuar(false);
    else if (/valeu|perfeito|obrigad|show|top|isso mesmo|boa|otimo|massa/.test(t)) pontuar(true);
    else { const d = dados(); if (d.ultimo) { for (const o of Object.values(d.ultimo)) { const p = d.placar[o] || [1, 1]; p[0] += 0.3; d.placar[o] = p; } d.ultimo = null; guardar("j_evolucao", d); } }
  }
  function comando(ac) {
    const d = dados();
    if (ac.includes("fixar_curto")) d.fixo.tamanho = "curto"; else if (ac.includes("fixar_completo")) d.fixo.tamanho = "completo";
    else if (ac.includes("pausar")) d.pausado = true; else if (ac.includes("continuar")) d.pausado = false; else if (ac.includes("zerar")) { d.placar = {}; d.fixo = {}; }
    guardar("j_evolucao", d);
    const placar = Object.entries(d.placar).map(([o, [a2, b2]]) => `${o.replace("_", " ")}: ${Math.round(100 * a2 / (a2 + b2))}% em ${Math.round(a2 + b2 - 2)} respostas`);
    return { placar, fixo: d.fixo, experimentando: !d.pausado };
  }
  return { escolher, pontuar, julgar, comando };
})();

// ═══ cérebro ═══════════════════════════════════════════════════════════════════
function sistema() {
  const ap = estadoAparelho(), nome = J.nomeDono(), hoje = new Date();
  const desligados = Object.entries(PLUGINS).filter(([k]) => !plugAtivo(k)).map(([, p]) => p.nome);
  return [J.persona(),
    `Você roda como um app (HTML/APK) no celular do usuário, brasileiro. Fale português do Brasil. Chame-o de "${nome}" de vez em quando. As respostas são FALADAS: sem markdown, sem listas longas, sem emojis em excesso.`,
    `Agora: ${hoje.toLocaleString("pt-BR", { weekday: "long", day: "2-digit", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" })}. Aparelho: bateria ${ap.bateria ?? "?"}%${ap.carregando ? " (carregando)" : ""}, rede ${ap.rede}. Cidade: ${ler("j_cidade") || "não informada"}.`,
    "Você TEM ferramentas: quando o pedido estiver ao alcance delas, CHAME a ferramenta em vez de só dizer que vai fazer. Para fatos atuais (notícias, placares, preços) use 'pesquisar' e não invente. Quando ele contar algo duradouro sobre si, use 'lembrar'. Antes de dizer que não sabe algo dele, use 'buscar_memoria'.",
    "Diário por entrevista: se ele pedir 'vamos fazer o diário', pergunte como foi o dia, ouça, faça 1 ou 2 perguntas e guarde com 'diario'. Detector de golpe: se ele colar uma mensagem suspeita, avalie sinais de golpe (urgência, link estranho, pedido de Pix/código) e dê um veredito claro. Cristal Malhas é a loja de moda infantil dele: ajude com roteiros, legendas e posts quando pedir.",
    "Limites honestos: daqui você não controla o PC, a TV nem a casa; para isso há o 'abrir_jarvis_pc'. Lembretes tocam com o app aberto (ou quando ele abrir).",
    desligados.length ? `Plugins desligados pelo usuário (não ofereça): ${desligados.join(", ")}.` : "",
    "Estilo desta resposta: " + Evolucao.escolher(),
    memorias.length ? "O que você já sabe dele: " + memorias.slice(-70).map(m => m.texto).join("; ") + "." : "Você ainda não sabe nada sobre ele."].filter(Boolean).join("\n");
}
function recorte(h, n) {
  let r = h.slice(-n);
  while (r.length && (r[0].role !== "user" || (r[0].parts || []).some(p => p.functionResponse))) r = r.slice(1);
  return r;
}
const semAnexos = parts => parts.map(p => p.inlineData ? { text: `[${p.inlineData.mimeType.split("/")[0] === "image" ? "imagem" : "arquivo"} enviado]` } : p);
async function pensar(texto, anexo) {
  const meu = ++S.turno;
  const partes = [{ text: texto }]; if (anexo) partes.unshift({ inlineData: { mimeType: anexo.tipo, data: anexo.dados } });
  historico.push({ role: "user", parts: partes });
  setEstado("PENSANDO");
  const instrucoes = sistema();
  for (let volta = 0; volta < 6; volta++) {
    const j = await J.gemini({ systemInstruction: { parts: [{ text: instrucoes }] }, contents: recorte(historico, 24), tools: [{ functionDeclarations: ferramentas() }] });
    if (meu !== S.turno) return;
    const pr = J.partesDe(j), chamadas = pr.filter(p => p.functionCall);
    if (!chamadas.length) {
      const resp = pr.map(p => p.text || "").join("").trim() || (((j.candidates || [])[0] || {}).finishReason === "SAFETY" ? "Prefiro não responder isso." : "…");
      historico.push({ role: "model", parts: [{ text: resp }] });
      historico = historico.map(h => ({ ...h, parts: semAnexos(h.parts) })).slice(-30); guardar("j_historico", historico);
      log(resp, "ai"); J.avisarTelas({ fala: resp }); await falarResposta(resp, meu);
      return;
    }
    historico.push({ role: "model", parts: pr });
    setEstado("PROCESSANDO");
    const respostas = [];
    for (const c of chamadas) {
      let r; try { r = await executar(c.functionCall.name, c.functionCall.args || {}); } catch (e) { r = { erro: String(e.message || e) }; }
      respostas.push({ functionResponse: { name: c.functionCall.name, response: r, ...(c.functionCall.id ? { id: c.functionCall.id } : {}) } });
    }
    if (meu !== S.turno) return;
    historico.push({ role: "user", parts: respostas }); setEstado("PENSANDO");
  }
  setEstado("PRONTO");
}
async function falarResposta(texto, meu) {
  await J.falar(texto, { inicio: () => setEstado("FALANDO"), erro: e => { if (!S.avisouVoz) { S.avisouVoz = true; log("A voz não saiu (" + (e.message || e) + "). Troque a VOZ em ⚙ → MOTOR & PROVEDORES, ou deixe só texto.", "sys"); } } });
  if (meu !== undefined && meu !== S.turno) return;
  setEstado("PRONTO");
  if (S.maos) setTimeout(falarComigo, 350);
}
async function enviar(texto) {
  texto = String(texto || "").trim(); const anexo = S.anexo; if (!texto && !anexo) return;
  if (!texto) texto = anexo.tipo.startsWith("image") ? "O que você vê nesta imagem?" : "Resuma este arquivo.";
  S.anexo = null; $("#anexo").style.display = "none";
  log(texto, "you", anexo && anexo.tipo.startsWith("image") ? { img: "data:" + anexo.tipo + ";base64," + anexo.dados } : {});
  Evolucao.julgar(texto); habito(texto);
  if (/^(pode parar|para de ouvir|chega)\b/.test(dobrar(texto)) && S.maos) { S.maos = false; rotulos(); }
  try { await pensar(texto, anexo); }
  catch (e) { setEstado("PRONTO"); log(String(e.message || e), "err"); if (/chave/.test(e.message)) abrirProv(); else if (S.maos) setTimeout(falarComigo, 1500); }
}
function interromper() { S.turno++; J.parar(); J.pararOuvir(); Evolucao.pontuar(false); setEstado("PRONTO"); log("Interrompido.", "sys"); }
$("#bInterromper").onclick = () => { S.maos = false; rotulos(); interromper(); };
$("#entrada").onsubmit = e => { e.preventDefault(); const t = $("#txt").value; $("#txt").value = ""; enviar(t); };

// ═══ ouvir ═══════════════════════════════════════════════════════════════════════
async function falarComigo() {
  if (J.ouvindo()) { J.pararOuvir(); return; }
  if (!ler("j_chave") && !J.temReconhecimento) { abrirOv("setup"); return; }
  J.audio(); $("#mic").classList.add("ouvindo"); setEstado("OUVINDO");
  try {
    const t = await J.ouvir({ parcial: p => { $("#parcial").textContent = p; }, aviso: m => log(m, "sys"), processando: () => { setEstado("PROCESSANDO"); $("#parcial").textContent = "transcrevendo…"; } });
    $("#mic").classList.remove("ouvindo"); $("#parcial").textContent = "";
    if (t) enviar(t); else { setEstado("PRONTO"); if (S.maos && !document.hidden) setTimeout(falarComigo, 500); }
  } catch (e) {
    $("#mic").classList.remove("ouvindo"); $("#parcial").textContent = ""; setEstado("PRONTO");
    const m = String(e.message || e); log(/Permission|NotAllowed|denied/i.test(m) ? "Sem permissão para o microfone. Libere nas configurações do app (Permissões → Microfone) ou use o 🎤 do teclado." : "Microfone: " + m, "err");
    S.maos = false; rotulos();
  }
}
$("#mic").onclick = falarComigo;
$("#bMaos").onclick = () => { S.maos = !S.maos; rotulos(); if (S.maos) { log("Mãos livres: depois de cada resposta eu volto a ouvir. Diga 'pode parar' para desligar.", "sys"); if (!J.ouvindo()) falarComigo(); } else J.pararOuvir(); };
document.addEventListener("visibilitychange", () => { if (document.hidden) { J.pararOuvir(); guardar("j_historico", historico.slice(-30)); } });

// anexos (foto, PDF, texto, áudio)
$("#clip").onclick = () => $("#arquivo").click();
$("#arquivo").onchange = async e => {
  const f = e.target.files[0]; e.target.value = ""; if (!f) return;
  if (f.size > 15 * 1024 * 1024) { log("Arquivo grande demais (máx. 15 MB).", "err"); return; }
  let tipo = f.type || "text/plain"; if (/\.(py|js|md|json|csv|html|txt)$/i.test(f.name)) tipo = "text/plain";
  S.anexo = { tipo, dados: await J.arquivoB64(f), nome: f.name };
  $("#anexoNome").textContent = "📎 " + f.name + " — escreva ou fale o que quer saber"; $("#anexo").style.display = "flex"; $("#txt").focus();
};
$("#anexoX").onclick = () => { S.anexo = null; $("#anexo").style.display = "none"; };

// hábitos: percebe o que você pede na mesma hora e oferece no dia seguinte
function habito(texto) {
  const t = dobrar(texto); const chave = ["clima", "briefing", "musica", "toca", "noticia", "gasto", "diario", "pomodoro"].find(k => t.includes(k)); if (!chave) return;
  const h = lerJSON("j_habitos", {}), hora = new Date().getHours(), k2 = chave + "@" + hora; h[k2] = (h[k2] || 0) + 1; guardar("j_habitos", h);
}

// ═══ início ═══════════════════════════════════════════════════════════════════
Missoes.aoDisparar = (m, texto) => {
  J.vibrar([300, 120, 300, 120, 300]); J.bip(880, .15, .08); setTimeout(() => J.bip(1100, .2, .08), 220);
  log("⏰ " + texto, "ai"); toast("⏰ " + texto); falarResposta("Aviso, " + J.nomeDono() + ": " + texto);
};
function capsulas() {
  const l = lerJSON("j_capsulas", []); let abriu = false;
  for (const c of l) if (!c.aberta && c.abrir <= Date.now()) { c.aberta = true; abriu = true; const quando = new Date(c.ts).toLocaleDateString("pt-BR"); log(`⏳ Cápsula do tempo de ${quando}: "${c.texto}"`, "ai"); setTimeout(() => falarResposta(`Chegou uma cápsula do tempo que você gravou em ${quando}. Ela diz: ${c.texto}`), 2500); }
  if (abriu) guardar("j_capsulas", l);
}
function saudar(primeira) {
  const h = new Date().getHours(), p = h < 12 ? "Bom dia" : h < 18 ? "Boa tarde" : "Boa noite";
  const txt = primeira ? `${p}, ${J.nomeDono()}. Sistemas online. Toque no núcleo ou no 🎤 e fale comigo.` : `${p}, ${J.nomeDono()}. Sistemas online.`;
  log(txt, "ai"); if (primeira) falarResposta(txt);
  const hoje = new Date().toDateString();
  if (ler("j_matinal", "0") === "1" && h >= 5 && h < 12 && ler("j_matinal_dia") !== hoje && ler("j_chave")) { guardar("j_matinal_dia", hoje); setTimeout(() => enviar("Me dá o briefing da manhã."), 1200); }
  const hb = lerJSON("j_habitos", {}), oferta = Object.entries(hb).filter(([k, v]) => v >= 3 && +k.split("@")[1] === h).map(([k]) => k.split("@")[0])[0];
  if (oferta && ler("j_hab_dia") !== hoje + oferta) { guardar("j_hab_dia", hoje + oferta); log(`Você costuma pedir ${oferta} por volta desta hora. Quer que eu faça? É só dizer.`, "sys"); }
}
function boot() {
  rotulos(); ajustarHud(); requestAnimationFrame(desenhar);
  if (ler("j_carro") === "1") document.body.classList.add("carro");
  const linhas = ["INICIANDO SISTEMAS…", "NÚCLEO DO REATOR: ESTÁVEL", `MEMÓRIA: ${memorias.length} LEMBRANÇA(S), ${notas.length} NOTA(S)`, `PLUGINS: ${Object.keys(PLUGINS).filter(plugAtivo).length}/${Object.keys(PLUGINS).length} ATIVOS · ${ferramentas().length} FERRAMENTAS`, `MOTOR: ${J.modelo().toUpperCase()}`];
  linhas.forEach(l => log(l, "sys"));
  for (const h of historico.slice(-6)) { const t = (h.parts || []).map(p => p.text || "").join(""); if (t && !h.parts.some(p => p.functionResponse)) log(t, h.role === "user" ? "you" : "ai"); }
  setInterval(metricas, 2000); window.addEventListener("online", metricas); window.addEventListener("offline", metricas);
  setTimeout(() => {
    setEstado("PRONTO"); metricas();
    if (!ler("j_chave")) { $("#sNome").value = ler("j_nome"); $("#sCidade").value = ler("j_cidade"); abrirOv("setup"); } else saudar(false);
    capsulas();
  }, 1200);
  J.registrarSW();
  const q = new URLSearchParams(J.query()).get("diga"); if (q) setTimeout(() => enviar(q), 1500);
}
boot();
