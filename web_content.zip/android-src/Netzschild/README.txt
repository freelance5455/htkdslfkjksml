Netzschild — Handy-Schutz
========================

Was die App tut
---------------
Netzschild läuft als sichtbarer Hintergrunddienst. Sie richtet ein lokales
VPN nur auf diesem Gerät ein (kein Fernzugriff, kein Account). Darüber sieht
sie jede Domain, bevor eine Verbindung aufgebaut wird.

Bei bekannten Betrugsseiten, Lookalikes (z. B. sparkasse-login-check.tk)
oder unsicheren Signalen erscheint eine Nachfrage:

  Blockieren  ·  Nur diesmal  ·  Immer vertrauen

HTTPS-Inhalte werden NICHT entschlüsselt. Geprüft werden DNS-Namen,
Zieladressen und Vertrauenssignale. Das ist der wirksame Weg gegen
gefälschte Websites, ohne den Datenverkehr mitzulesen.

APK erzeugen
------------
1. Android Studio installieren (kostenlos, developer.android.com).
2. „Open“ → diesen Ordner „Netzschild“ wählen.
3. Warten, bis Gradle fertig ist (erster Start dauert).
4. Handy per USB, USB-Debugging an — oder einen Emulator.
5. Menü Build → Build Bundle(s) / APK(s) → Build APK(s).

Die APK liegt danach unter:
  app/build/outputs/apk/debug/app-debug.apk

Zum Verteilen: Build → Generate Signed Bundle / APK.

Erste Schritte auf dem Handy
----------------------------
Die App fragt nacheinander:
  • Benachrichtigungen
  • VPN-Verbindung (systemeigener Android-Dialog)
  • optional Akku-Optimierung ignorieren, damit der Schutz nicht einschläft
  • optional Einblendung über anderen Apps für die Warnung

Solange Schutz aktiv ist, bleibt die Mitteilung „Netzschild aktiv“ sichtbar.
