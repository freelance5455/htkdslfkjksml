package de.netzschild.app

import android.Manifest
import android.app.AppOpsManager
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import de.netzschild.app.engine.TrafficLog
import de.netzschild.app.engine.TrustStore
import de.netzschild.app.engine.Verdict
import de.netzschild.app.vpn.ShieldVpnService

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var toggle: MaterialSwitch
    private lateinit var adapter: LogAdapter

    private val notifyPerm = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { /* recorded by system */ }

    private val vpnPrepare = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == RESULT_OK) startShield()
        else {
            toggle.isChecked = false
            Toast.makeText(this, R.string.vpn_denied, Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        toggle = findViewById(R.id.toggle)
        adapter = LogAdapter()
        val list = findViewById<RecyclerView>(R.id.traffic)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        toggle.setOnCheckedChangeListener { _, on ->
            if (on) enableProtection() else stopShield()
        }

        findViewById<MaterialButton>(R.id.btn_notify).setOnClickListener { askNotifications() }
        findViewById<MaterialButton>(R.id.btn_battery).setOnClickListener { askBattery() }
        findViewById<MaterialButton>(R.id.btn_overlay).setOnClickListener { askOverlay() }
        findViewById<MaterialButton>(R.id.btn_usage).setOnClickListener { askUsage() }

        TrafficLog.listener = { runOnUiThread { adapter.reload() } }
        adapter.reload()
        refreshStatus(false)
    }

    override fun onDestroy() {
        TrafficLog.listener = null
        super.onDestroy()
    }

    private fun enableProtection() {
        askNotifications()
        val prep = VpnService.prepare(this)
        if (prep != null) vpnPrepare.launch(prep) else startShield()
    }

    private fun startShield() {
        ContextCompat.startForegroundService(
            this,
            Intent(this, ShieldVpnService::class.java),
        )
        getSharedPreferences("netzschild", MODE_PRIVATE).edit().putBoolean("on", true).apply()
        refreshStatus(true)
    }

    private fun stopShield() {
        stopService(Intent(this, ShieldVpnService::class.java))
        getSharedPreferences("netzschild", MODE_PRIVATE).edit().putBoolean("on", false).apply()
        refreshStatus(false)
    }

    private fun refreshStatus(on: Boolean) {
        status.text = getString(if (on) R.string.status_on else R.string.status_off)
        toggle.isChecked = on
    }

    private fun askNotifications() {
        if (Build.VERSION.SDK_INT >= 33) {
            notifyPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun askBattery() {
        if (Build.VERSION.SDK_INT < 23) return
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            Toast.makeText(this, R.string.battery_ok, Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                .setData(Uri.parse("package:$packageName")),
        )
    }

    private fun askOverlay() {
        if (Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.overlay_ok, Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(
            Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName"),
            ),
        )
    }

    private fun askUsage() {
        val appOps = getSystemService(AppOpsManager::class.java)
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName,
        )
        if (mode == AppOpsManager.MODE_ALLOWED) {
            Toast.makeText(this, R.string.usage_ok, Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    }

    private class LogAdapter : RecyclerView.Adapter<LogAdapter.VH>() {
        private var data = TrafficLog.snapshot()
        fun reload() {
            data = TrafficLog.snapshot()
            notifyDataSetChanged()
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_traffic, parent, false)
            return VH(v)
        }
        override fun getItemCount() = data.size
        override fun onBindViewHolder(holder: VH, position: Int) {
            val e = data[position]
            holder.host.text = e.host
            holder.meta.text = when (e.verdict) {
                Verdict.MALICIOUS -> "Gefährlich"
                Verdict.SUSPICIOUS -> "Verdächtig"
                Verdict.TRUSTED -> "Vertrauenswürdig"
                Verdict.UNKNOWN -> "Unbekannt"
            } + " · " + when (e.decision) {
                TrustStore.BLOCK -> "blockiert"
                TrustStore.TRUST -> "vertraut"
                else -> "durchgelassen"
            }
        }
        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val host: TextView = v.findViewById(R.id.item_host)
            val meta: TextView = v.findViewById(R.id.item_meta)
        }
    }
}
