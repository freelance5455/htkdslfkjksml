package de.netzschild.app.engine

import java.util.concurrent.CopyOnWriteArrayList

data class TrafficEntry(
    val at: Long,
    val host: String,
    val verdict: Verdict,
    val decision: String,
)

object TrafficLog {
    private val items = CopyOnWriteArrayList<TrafficEntry>()
    var listener: (() -> Unit)? = null

    fun add(host: String, verdict: Verdict, decision: String) {
        items.add(0, TrafficEntry(System.currentTimeMillis(), host, verdict, decision))
        while (items.size > 300) items.removeAt(items.lastIndex)
        listener?.invoke()
    }

    fun snapshot(): List<TrafficEntry> = items.toList()
}
