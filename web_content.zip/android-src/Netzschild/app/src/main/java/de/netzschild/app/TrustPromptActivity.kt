package de.netzschild.app

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import de.netzschild.app.engine.ReputationEngine
import de.netzschild.app.engine.TrustStore

class TrustPromptActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trust)
        val host = intent.getStringExtra(EXTRA_HOST) ?: run { finish(); return }
        val inspection = ReputationEngine.inspect(host)
        findViewById<TextView>(R.id.host).text = inspection.host
        findViewById<TextView>(R.id.reason).text =
            inspection.findings.joinToString("\n\n") { "${it.title}\n${it.detail}" }
                .ifBlank { intent.getStringExtra(EXTRA_REASON) ?: getString(R.string.ask_fallback) }

        findViewById<MaterialButton>(R.id.btn_block).setOnClickListener {
            TrustStore.put(this, inspection.host, TrustStore.BLOCK)
            finish()
        }
        findViewById<MaterialButton>(R.id.btn_once).setOnClickListener {
            TrustStore.put(this, inspection.host, TrustStore.ALLOW)
            finish()
        }
        findViewById<MaterialButton>(R.id.btn_trust).setOnClickListener {
            TrustStore.put(this, inspection.host, TrustStore.TRUST)
            finish()
        }
    }

    companion object {
        const val EXTRA_HOST = "host"
        const val EXTRA_REASON = "reason"
    }
}
