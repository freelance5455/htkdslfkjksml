package de.netzschild.app.engine

import android.content.Context

object TrustStore {
    const val ALLOW = "allow"
    const val BLOCK = "block"
    const val TRUST = "trust"

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences("netzschild_trust", Context.MODE_PRIVATE)

    fun get(ctx: Context, host: String): String? =
        prefs(ctx).getString(host.lowercase(), null)

    fun put(ctx: Context, host: String, decision: String) {
        prefs(ctx).edit().putString(host.lowercase(), decision).apply()
    }

    fun shouldBlock(ctx: Context, inspection: Inspection): Boolean {
        val stored = get(ctx, inspection.host)
        if (stored == BLOCK) return true
        if (stored == TRUST || stored == ALLOW) return false
        return inspection.verdict == Verdict.MALICIOUS
    }
}
