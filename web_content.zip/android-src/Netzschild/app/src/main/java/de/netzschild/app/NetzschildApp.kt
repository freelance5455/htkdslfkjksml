package de.netzschild.app

import android.app.Application
import de.netzschild.app.notify.ShieldNotifications

class NetzschildApp : Application() {
    override fun onCreate() {
        super.onCreate()
        ShieldNotifications.ensureChannels(this)
    }
}
