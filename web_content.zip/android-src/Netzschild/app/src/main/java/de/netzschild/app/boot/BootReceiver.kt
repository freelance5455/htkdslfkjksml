package de.netzschild.app.boot

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import androidx.core.content.ContextCompat
import de.netzschild.app.vpn.ShieldVpnService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val on = context.getSharedPreferences("netzschild", Context.MODE_PRIVATE)
            .getBoolean("on", false)
        if (!on) return
        if (VpnService.prepare(context) != null) return
        ContextCompat.startForegroundService(
            context,
            Intent(context, ShieldVpnService::class.java),
        )
    }
}
