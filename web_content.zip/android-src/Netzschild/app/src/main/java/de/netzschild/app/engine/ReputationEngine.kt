package de.netzschild.app.engine

data class Finding(val title: String, val detail: String, val danger: Boolean)

enum class Verdict { TRUSTED, UNKNOWN, SUSPICIOUS, MALICIOUS }

data class Inspection(
    val host: String,
    val verdict: Verdict,
    val findings: List<Finding>,
    val brandHit: String?,
)

object ReputationEngine {
    private val riskyTlds = setOf(
        "tk", "gq", "ml", "cf", "ga", "xyz", "top", "click", "link",
        "zip", "mov", "country", "loan", "win", "review", "gdn",
    )
    private val bait = listOf(
        "login", "secure", "update", "verify", "konto", "account",
        "sicherheit", "kundencenter", "paket", "sendung", "tan",
        "freigabe", "restore", "bonus", "gewinn", "alert",
    )
    private val malicious = setOf(
        "sparkasse-sicherheit.tk",
        "sparkasse-login-check.tk",
        "paypal-konto-update.com",
        "paypal-sicherheit-service.net",
        "dhl-paket-sendung.net",
        "dhl-sendungsverfolgung.xyz",
        "appleid-verify-login.com",
        "icloud-account-restore.tk",
        "telekom-kundencenter.xyz",
        "amazon-prime-bonus.top",
        "microsoft-konto-alert.gq",
        "elster-steuerauskunft.click",
        "whatsapp-voice-mail.ml",
        "postbank-tan-freigabe.cf",
        "n26-karten-sperre.ga",
        "secure-paypal-de.net",
        "konto-update-sparkasse.com",
    )
    private val brands = listOf(
        "sparkasse" to "Sparkasse",
        "volksbank" to "Volksbank",
        "deutsche-bank" to "Deutsche Bank",
        "commerzbank" to "Commerzbank",
        "postbank" to "Postbank",
        "paypal" to "PayPal",
        "amazon" to "Amazon",
        "dhl" to "DHL",
        "telekom" to "Telekom",
        "apple" to "Apple",
        "icloud" to "Apple",
        "google" to "Google",
        "microsoft" to "Microsoft",
        "elster" to "ELSTER",
        "whatsapp" to "WhatsApp",
        "n26" to "N26",
        "ing" to "ING",
    )
    private val official = setOf(
        "sparkasse.de", "paypal.com", "paypal.de", "amazon.de", "amazon.com",
        "dhl.de", "dhl.com", "telekom.de", "t-online.de", "apple.com",
        "icloud.com", "google.com", "google.de", "gmail.com", "microsoft.com",
        "live.com", "office.com", "elster.de", "whatsapp.com", "whatsapp.net",
        "n26.com", "ing.de", "postbank.de", "commerzbank.de", "deutsche-bank.de",
        "facebook.com", "instagram.com", "youtube.com",
    )

    fun inspect(raw: String): Inspection {
        val host = normalize(raw)
        if (host.isEmpty()) {
            return Inspection(host, Verdict.UNKNOWN, emptyList(), null)
        }
        val findings = mutableListOf<Finding>()
        var score = 0
        var brandHit: String? = null

        if (host.matches(Regex("""^d{1,3}(.d{1,3}){3}$""")) || host.contains(":")) {
            findings += Finding("IP statt Domain", "Seriöse Dienste nutzen selten eine nackte IP.", true)
            score += 45
        }
        if (host in malicious || registrable(host) in malicious) {
            findings += Finding("Bekannte Betrugsseite", "Eintrag in der lokalen Sperrliste.", true)
            score += 90
        }
        if (host.startsWith("xn--") || host.any { it.code > 127 }) {
            findings += Finding("Versteckte Zeichen", "Punycode oder fremde Schrift — klassischer Lookalike.", true)
            score += 40
        }
        val tld = host.substringAfterLast('.', "")
        if (tld in riskyTlds) {
            findings += Finding("Auffällige Endung .$tld", "Diese Endung wird oft für Phishing missbraucht.", false)
            score += 22
        }
        if (host.count { it == '-' } >= 2) {
            findings += Finding("Viele Bindestriche", "Echte Marken-Domains sind kurz.", false)
            score += 12
        }
        val baitHits = bait.filter { host.contains(it) }
        if (baitHits.isNotEmpty()) {
            findings += Finding(
                "Druck-Wörter in der Domain",
                "Enthält ${baitHits.take(3).joinToString(", ")}.",
                false,
            )
            score += 8 * minOf(baitHits.size, 3)
        }
        for ((needle, label) in brands) {
            val officialHit = official.any { host == it || host.endsWith(".$it") }
            if (!officialHit && host.contains(needle) && registrable(host) !in official) {
                brandHit = label
                findings += Finding("Sieht aus wie $label", "Die Adresse imitiert $label, ist aber nicht offiziell.", true)
                score += 50
                break
            }
        }
        val isOfficial = official.any { host == it || host.endsWith(".$it") }
        if (isOfficial) {
            findings.add(0, Finding("Original-Domain", "Hinterlegter Vertrauensanker.", false))
            score = maxOf(0, score - 70)
        }
        val verdict = when {
            isOfficial && score < 22 -> Verdict.TRUSTED
            score >= 55 -> Verdict.MALICIOUS
            score >= 22 -> Verdict.SUSPICIOUS
            else -> Verdict.UNKNOWN
        }
        return Inspection(host, verdict, findings, brandHit)
    }

    fun needsAsk(inspection: Inspection, stored: String?): Boolean {
        if (stored != null) return false
        return inspection.verdict == Verdict.MALICIOUS || inspection.verdict == Verdict.SUSPICIOUS
    }

    private fun normalize(raw: String): String {
        var s = raw.trim().lowercase().trimEnd('.')
        s = s.removePrefix("https://").removePrefix("http://")
        s = s.substringBefore("/").substringBefore(":")
        return s
    }

    private fun registrable(host: String): String {
        val p = host.split(".").filter { it.isNotEmpty() }
        return if (p.size <= 2) host else p.takeLast(2).joinToString(".")
    }
}
