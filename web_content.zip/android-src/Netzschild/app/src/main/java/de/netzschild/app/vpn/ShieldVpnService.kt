package de.netzschild.app.vpn

import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import de.netzschild.app.engine.ReputationEngine
import de.netzschild.app.engine.TrafficLog
import de.netzschild.app.engine.TrustStore
import de.netzschild.app.engine.Verdict
import de.netzschild.app.notify.ShieldNotifications
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.atomic.AtomicBoolean

class ShieldVpnService : VpnService(), Runnable {
    private val running = AtomicBoolean(false)
    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ShieldNotifications.ensureChannels(this)
        startForeground(ShieldNotifications.ID_ONGOING, ShieldNotifications.ongoing(this))
        startTunnel()
        return START_STICKY
    }

    private fun startTunnel() {
        stopTunnel()
        val builder = Builder()
            .setSession("Netzschild")
            .setMtu(1500)
            .addAddress("10.111.1.2", 32)
            .addDnsServer("10.111.1.1")
            .addRoute("10.111.1.1", 32)
            .setBlocking(true)
        if (Build.VERSION.SDK_INT >= 29) builder.setMetered(false)
        tun = builder.establish() ?: return
        running.set(true)
        worker = Thread(this, "netzschild-tun").also { it.start() }
    }

    private fun stopTunnel() {
        running.set(false)
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        worker = null
    }

    override fun onDestroy() {
        stopTunnel()
        super.onDestroy()
    }

    override fun run() {
        val pfd = tun ?: return
        val input = FileInputStream(pfd.fileDescriptor)
        val output = FileOutputStream(pfd.fileDescriptor)
        val buf = ByteArray(32767)
        while (running.get()) {
            val n = try {
                input.read(buf)
            } catch (_: Exception) {
                break
            }
            if (n <= 0) continue
            handle(buf, n, output)
        }
    }

    private fun handle(pkt: ByteArray, len: Int, out: FileOutputStream) {
        if (len < 28) return
        val version = (pkt[0].toInt() ushr 4) and 0xF
        if (version != 4) return
        val ihl = (pkt[0].toInt() and 0x0F) * 4
        val proto = pkt[9].toInt() and 0xFF
        if (proto != 17) return
        val udp = ihl
        if (len < udp + 8) return
        val dstPort = ((pkt[udp + 2].toInt() and 0xFF) shl 8) or (pkt[udp + 3].toInt() and 0xFF)
        if (dstPort != 53) return
        val dnsOff = udp + 8
        val dns = pkt.copyOfRange(dnsOff, len)
        val host = DnsCodec.readQueryName(dns) ?: return
        val inspection = ReputationEngine.inspect(host)
        val stored = TrustStore.get(this, inspection.host)
        val block = TrustStore.shouldBlock(this, inspection) ||
            (stored == null && inspection.verdict == Verdict.SUSPICIOUS)

        if (ReputationEngine.needsAsk(inspection, stored)) {
            val reason = inspection.findings.firstOrNull()?.title ?: "Unklare Vertrauenslage"
            ShieldNotifications.ask(this, inspection.host, reason)
        }

        val decision = when {
            block -> TrustStore.BLOCK
            stored != null -> stored
            else -> TrustStore.ALLOW
        }
        TrafficLog.add(inspection.host, inspection.verdict, decision)

        if (block) {
            val nx = DnsCodec.nxDomain(dns)
            writeUdpReply(pkt, ihl, nx, out)
            return
        }
        forward(pkt, ihl, dns, out)
    }

    private fun forward(orig: ByteArray, ihl: Int, dns: ByteArray, out: FileOutputStream) {
        try {
            val sock = DatagramSocket()
            protect(sock)
            sock.soTimeout = 2500
            val dest = InetAddress.getByName("1.1.1.1")
            sock.send(DatagramPacket(dns, dns.size, dest, 53))
            val replyBuf = ByteArray(4096)
            val incoming = DatagramPacket(replyBuf, replyBuf.size)
            sock.receive(incoming)
            sock.close()
            writeUdpReply(orig, ihl, incoming.data.copyOf(incoming.length), out)
        } catch (_: Exception) {
            writeUdpReply(orig, ihl, DnsCodec.nxDomain(dns), out)
        }
    }

    private fun writeUdpReply(orig: ByteArray, ihl: Int, payload: ByteArray, out: FileOutputStream) {
        val udpLen = 8 + payload.size
        val total = ihl + udpLen
        val pkt = ByteArray(total)
        System.arraycopy(orig, 0, pkt, 0, ihl + 8)
        // swap src/dst IP
        System.arraycopy(orig, 16, pkt, 12, 4)
        System.arraycopy(orig, 12, pkt, 16, 4)
        pkt[8] = 64
        pkt[10] = 0
        pkt[11] = 0
        val totalHi = (total ushr 8) and 0xFF
        val totalLo = total and 0xFF
        pkt[2] = totalHi.toByte()
        pkt[3] = totalLo.toByte()
        checksum(pkt, 0, ihl, 10)
        // swap ports
        pkt[ihl] = orig[ihl + 2]
        pkt[ihl + 1] = orig[ihl + 3]
        pkt[ihl + 2] = orig[ihl]
        pkt[ihl + 3] = orig[ihl + 1]
        pkt[ihl + 4] = ((udpLen ushr 8) and 0xFF).toByte()
        pkt[ihl + 5] = (udpLen and 0xFF).toByte()
        pkt[ihl + 6] = 0
        pkt[ihl + 7] = 0
        System.arraycopy(payload, 0, pkt, ihl + 8, payload.size)
        udpChecksum(pkt, ihl, udpLen)
        out.write(pkt)
    }

    private fun checksum(buf: ByteArray, off: Int, len: Int, at: Int) {
        buf[at] = 0
        buf[at + 1] = 0
        var sum = 0
        var i = off
        while (i < off + len - 1) {
            sum += ((buf[i].toInt() and 0xFF) shl 8) or (buf[i + 1].toInt() and 0xFF)
            i += 2
        }
        if (len % 2 != 0) sum += (buf[off + len - 1].toInt() and 0xFF) shl 8
        while (sum ushr 16 != 0) sum = (sum and 0xFFFF) + (sum ushr 16)
        val c = sum.inv() and 0xFFFF
        buf[at] = (c ushr 8).toByte()
        buf[at + 1] = (c and 0xFF).toByte()
    }

    private fun udpChecksum(pkt: ByteArray, ihl: Int, udpLen: Int) {
        pkt[ihl + 6] = 0
        pkt[ihl + 7] = 0
        var sum = 0
        // pseudo header
        for (i in 12 until 20 step 2) {
            sum += ((pkt[i].toInt() and 0xFF) shl 8) or (pkt[i + 1].toInt() and 0xFF)
        }
        sum += 17
        sum += udpLen
        var i = ihl
        val end = ihl + udpLen
        while (i < end - 1) {
            sum += ((pkt[i].toInt() and 0xFF) shl 8) or (pkt[i + 1].toInt() and 0xFF)
            i += 2
        }
        if (udpLen % 2 != 0) sum += (pkt[end - 1].toInt() and 0xFF) shl 8
        while (sum ushr 16 != 0) sum = (sum and 0xFFFF) + (sum ushr 16)
        var c = sum.inv() and 0xFFFF
        if (c == 0) c = 0xFFFF
        pkt[ihl + 6] = (c ushr 8).toByte()
        pkt[ihl + 7] = (c and 0xFF).toByte()
    }
}
