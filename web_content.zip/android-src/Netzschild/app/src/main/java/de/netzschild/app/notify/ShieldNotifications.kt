package de.netzschild.app.notify

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import de.netzschild.app.MainActivity
import de.netzschild.app.R
import de.netzschild.app.TrustPromptActivity

object ShieldNotifications {
    const val CHANNEL_STATUS = "status"
    const val CHANNEL_ALERT = "alert"
    const val ID_ONGOING = 41

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_STATUS, "Schutzstatus", NotificationManager.IMPORTANCE_LOW),
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ALERT, "Sicherheitsnachfragen", NotificationManager.IMPORTANCE_HIGH),
        )
    }

    fun ongoing(ctx: Context): Notification {
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(ctx, CHANNEL_STATUS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(ctx.getString(R.string.app_name))
            .setContentText(ctx.getString(R.string.status_on))
            .setOngoing(true)
            .setContentIntent(open)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    fun ask(ctx: Context, host: String, reason: String) {
        val intent = Intent(ctx, TrustPromptActivity::class.java)
            .putExtra(TrustPromptActivity.EXTRA_HOST, host)
            .putExtra(TrustPromptActivity.EXTRA_REASON, reason)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(
            ctx, host.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL_ALERT)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(ctx.getString(R.string.ask_title))
            .setContentText(host)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$host
$reason"))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(host.hashCode() and 0x7fffffff, n)
        try {
            ctx.startActivity(intent)
        } catch (_: Exception) {
            // bleibt als Mitteilung sichtbar
        }
    }
}
