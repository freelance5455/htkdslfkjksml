package de.netzschild.app.vpn

object DnsCodec {
    fun readQueryName(dns: ByteArray): String? {
        if (dns.size < 12) return null
        var i = 12
        val labels = ArrayList<String>()
        while (i < dns.size) {
            val len = dns[i].toInt() and 0xFF
            if (len == 0) break
            if (len and 0xC0 != 0) return null
            if (i + 1 + len > dns.size) return null
            labels += dns.copyOfRange(i + 1, i + 1 + len).toString(Charsets.US_ASCII)
            i += 1 + len
        }
        if (labels.isEmpty()) return null
        return labels.joinToString(".").lowercase()
    }

    fun nxDomain(query: ByteArray): ByteArray {
        val out = query.copyOf()
        if (out.size < 4) return out
        // QR=1, RA=1, RCODE=3 (NXDOMAIN)
        out[2] = ((out[2].toInt() and 0x01) or 0x80).toByte()
        out[3] = 0x83.toByte()
        out[6] = 0
        out[7] = 0
        out[8] = 0
        out[9] = 0
        out[10] = 0
        out[11] = 0
        return out
    }
}
