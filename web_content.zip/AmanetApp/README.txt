AmmaNet - Android (Kotlin + WebView)

1) Android Studio -> File > Open -> bu qovluğu seç (AmanetApp)
2) Gradle sync bitəndən sonra: Build > Build APK(s)
   APK: app/build/outputs/apk/debug/app-debug.apk
3) Telefona qur və ya Run düyməsi ilə birbaşa yüklə.

index.html faylı: app/src/main/assets/index.html
Onu dəyişsən, yenidən build etmək kifayətdir.
