plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android { namespace="com.example.btrecorder"; compileSdk=35
    defaultConfig { applicationId="com.example.btrecorder"; minSdk=21; targetSdk=35; versionCode=1; versionName="1.0" }
}

dependencies { implementation("androidx.core:core-ktx:1.13.1") }


// After a debug APK is built, copy it to a normal local folder automatically.
// Output 1: <project>/APK-Output/BTRecorder-Hybrid-v1.0-debug.apk
// Output 2: <user home>/Downloads/BTRecorder/BTRecorder-Hybrid-v1.0-debug.apk
tasks.register("copyDebugApkToLocalStorage") {
    doLast {
        val apk = layout.buildDirectory.file("outputs/apk/debug/app-debug.apk").get().asFile
        if (!apk.exists()) return@doLast

        val projectOutput = rootProject.file("APK-Output")
        projectOutput.mkdirs()
        apk.copyTo(projectOutput.resolve("BTRecorder-Hybrid-v${android.defaultConfig.versionName}-debug.apk"), overwrite = true)

        val downloads = java.io.File(System.getProperty("user.home"), "Downloads/BTRecorder")
        if (downloads.exists() || downloads.parentFile?.exists() == true) {
            downloads.mkdirs()
            apk.copyTo(downloads.resolve("BTRecorder-Hybrid-v${android.defaultConfig.versionName}-debug.apk"), overwrite = true)
        }
        println("BT Recorder APK copied to: ${projectOutput.absolutePath}")
    }
}

// Compatibility alias: some Android Studio/Gradle run configurations may invoke "assembled".
// Make it a real app task that builds the debug APK.
tasks.register("assembled") {
    group = "build"
    description = "Build the BT Recorder debug APK (compatibility alias)."
    dependsOn("assembleDebug")
}

tasks.named("assembleDebug") {
    finalizedBy("copyDebugApkToLocalStorage")
}
