package com.example.btrecorder

import android.content.Context
import android.webkit.JavascriptInterface
import org.json.JSONObject

class Bridge(private val context: Context) {
    private val activity get() = context as MainActivity

    @JavascriptInterface fun setConfig(json: String) {
        DigitalCaptureService.setConfig(json)
    }

    @JavascriptInterface fun startDigitalCapture() {
        activity.runOnUiThread { activity.requestCapture() }
    }

    @JavascriptInterface fun stopDigitalCapture() {
        DigitalCaptureService.stop(context)
    }

    @JavascriptInterface fun getRecordings(): String = activity.recordingListJson()

    @JavascriptInterface fun deleteRecording(name: String): Boolean = activity.deleteRecording(name)

    @JavascriptInterface fun shareRecording(name: String) {
        activity.runOnUiThread { activity.shareRecording(name) }
    }
}
