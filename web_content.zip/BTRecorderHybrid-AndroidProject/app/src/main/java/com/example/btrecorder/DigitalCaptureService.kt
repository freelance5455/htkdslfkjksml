package com.example.btrecorder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Environment
import android.os.IBinder
import java.io.File
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.pow

/**
 * Native digital playback recorder used by the WebView bridge.
 *
 * This is the native half required for a WebInto.App-style hybrid wrapper.
 * The webpage calls AndroidCapture.startDigitalCapture()/stopDigitalCapture().
 */
class DigitalCaptureService : Service() {
    companion object {
        const val ACTION_START = "com.example.btrecorder.START_CAPTURE"
        const val ACTION_STOP = "com.example.btrecorder.STOP_CAPTURE"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_PROJECTION_DATA = "projectionData"
        private const val CHANNEL_ID = "bt_recorder_capture"
        private const val NOTIFICATION_ID = 4101

        @Volatile private var running = false
        @Volatile private var requestedSampleRate = 48000
        @Volatile private var requestedChannels = 2
        @Volatile private var requestedBitDepth = 16
        @Volatile private var requestedFormat = "wav"
        @Volatile private var requestedOutput = "bluetooth"
        @Volatile private var requestedGainDb = 0.0
        @Volatile private var requestedNoiseReduction = false
        @Volatile private var requestedNoiseGate = false
        @Volatile private var requestedNormalize = false

        fun setConfig(json: String) {
            fun num(key: String, fallback: Int): Int =
                Regex("\\\"$key\\\"\\s*:\\s*(\\d+)").find(json)?.groupValues?.get(1)?.toIntOrNull() ?: fallback
            fun decimal(key: String, fallback: Double): Double =
                Regex("\\\"$key\\\"\\s*:\\s*(-?[0-9]+(?:\\.[0-9]+)?)").find(json)?.groupValues?.get(1)?.toDoubleOrNull() ?: fallback
            fun bool(key: String, fallback: Boolean): Boolean =
                Regex("\\\"$key\\\"\\s*:\\s*(true|false)").find(json)?.groupValues?.get(1)?.toBoolean() ?: fallback
            fun str(key: String, fallback: String): String =
                Regex("\\\"$key\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"").find(json)?.groupValues?.get(1) ?: fallback

            requestedSampleRate = num("sampleRate", 48000)
            requestedChannels = num("channels", 2)
            requestedBitDepth = num("bitDepth", 16)
            requestedFormat = str("format", "wav").lowercase(Locale.US)
            requestedOutput = str("outputMode", "bluetooth").lowercase(Locale.US)
            requestedGainDb = decimal("gain", 0.0).coerceIn(-12.0, 12.0)
            requestedNoiseReduction = bool("noiseReduction", false)
            requestedNoiseGate = bool("noiseGate", false)
            requestedNormalize = bool("normalize", false)

            // Android AudioPlaybackCapture is captured as PCM here.
            // The native recorder currently writes 48 kHz, 16-bit PCM.
            if (requestedSampleRate != 48000) requestedSampleRate = 48000
            if (requestedChannels != 1 && requestedChannels != 2) requestedChannels = 2
            if (requestedBitDepth != 16) requestedBitDepth = 16
            if (requestedFormat != "wav" && requestedFormat != "raw") requestedFormat = "wav"
        }

        fun start(context: Context, resultCode: Int, data: Intent) {
            if (Build.VERSION.SDK_INT < 29) return
            val intent = Intent(context, DigitalCaptureService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_PROJECTION_DATA, data)
                putExtra("captureMode", "digital")
            }
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent)
            else context.startService(intent)
        }

        /**
         * Android 5.0-9.x fallback. Android does not expose AudioPlaybackCapture
         * before API 29, so this records an audio input (microphone or a routed
         * Bluetooth SCO headset microphone) instead of internal app playback.
         */
        fun startMicrophone(context: Context) {
            val intent = Intent(context, DigitalCaptureService::class.java).apply {
                action = ACTION_START
                putExtra("captureMode", "microphone")
            }
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent)
            else context.startService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, DigitalCaptureService::class.java).apply { action = ACTION_STOP })
        }
    }

    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var worker: Thread? = null
    private var record: AudioRecord? = null
    private var output: RandomAccessFile? = null
    private var outputFile: File? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopCaptureInternal()
            stopSelf()
            return START_NOT_STICKY
        }

        if (intent?.action == ACTION_START) {
            startForegroundCompat()
            if (!running) {
                val mode = intent.getStringExtra("captureMode") ?: "digital"
                if (mode == "microphone") {
                    startMicrophoneCapture()
                    return START_NOT_STICKY
                }
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
                val data = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(EXTRA_PROJECTION_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_PROJECTION_DATA)
                }
                if (resultCode != -1 && data != null) startCapture(resultCode, data)
                else stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        if (Build.VERSION.SDK_INT < 29 || running) return

        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        if (projection == null) {
            stopSelf()
            return
        }

        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                stopCaptureInternal()
                stopSelf()
            }
        }
        projection!!.registerCallback(projectionCallback!!, mainLooper)

        val config = AudioPlaybackCaptureConfiguration.Builder(projection!!)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .build()

        val rate = requestedSampleRate
        val channels = requestedChannels
        val channelMask = if (channels == 1) AudioFormat.CHANNEL_IN_MONO else AudioFormat.CHANNEL_IN_STEREO
        val audioFormat = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(rate)
            .setChannelMask(channelMask)
            .build()

        val minBuffer = AudioRecord.getMinBufferSize(rate, channelMask, AudioFormat.ENCODING_PCM_16BIT)
        val bufferSize = maxOf(rate * channels * 2, if (minBuffer > 0) minBuffer * 2 else 8192)

        val audioRecord = AudioRecord.Builder()
            .setAudioFormat(audioFormat)
            .setBufferSizeInBytes(bufferSize)
            .setAudioPlaybackCaptureConfig(config)
            .build()

        if (audioRecord.state != AudioRecord.STATE_INITIALIZED) {
            audioRecord.release()
            stopCaptureInternal()
            stopSelf()
            return
        }

        record = audioRecord
        val dir = getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: filesDir
        if (!dir.exists()) dir.mkdirs()
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        outputFile = File(dir, "BT-$stamp.wav")
        output = RandomAccessFile(outputFile!!, "rw")
        output!!.setLength(0)
        writeHeader(output!!, 0, rate, channels)

        running = true
        audioRecord.startRecording()
        worker = Thread({ captureLoop(rate, channels) }, "BT-DigitalCapture")
        worker!!.start()
    }


    private fun startMicrophoneCapture() {
        if (Build.VERSION.SDK_INT > 28 || running) return

        val rate = requestedSampleRate
        val preferredChannels = requestedChannels
        val candidates = if (preferredChannels == 1) intArrayOf(1) else intArrayOf(2, 1)
        var audioRecord: AudioRecord? = null
        var actualChannels = 1

        for (ch in candidates) {
            val channelMask = if (ch == 1) AudioFormat.CHANNEL_IN_MONO else AudioFormat.CHANNEL_IN_STEREO
            val minBuffer = AudioRecord.getMinBufferSize(rate, channelMask, AudioFormat.ENCODING_PCM_16BIT)
            if (minBuffer <= 0) continue
            val bufferSize = maxOf(rate * ch * 2, minBuffer * 2)
            try {
                val candidate = AudioRecord(
                    MediaRecorder.AudioSource.DEFAULT,
                    rate,
                    channelMask,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize
                )
                if (candidate.state == AudioRecord.STATE_INITIALIZED) {
                    audioRecord = candidate
                    actualChannels = ch
                    break
                }
                candidate.release()
            } catch (_: Exception) { }
        }

        if (audioRecord == null) {
            stopSelf()
            return
        }

        record = audioRecord
        val dir = getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: filesDir
        if (!dir.exists()) dir.mkdirs()
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        outputFile = File(dir, "BT-Mic-$stamp.wav")
        output = RandomAccessFile(outputFile!!, "rw")
        output!!.setLength(0)
        writeHeader(output!!, 0, rate, actualChannels)

        running = true
        try {
            audioRecord.startRecording()
        } catch (_: Exception) {
            running = false
            audioRecord.release()
            record = null
            output?.close()
            output = null
            stopSelf()
            return
        }
        worker = Thread({ captureLoop(rate, actualChannels) }, "BT-MicCapture")
        worker!!.start()
    }

    private fun captureLoop(rate: Int, channels: Int) {
        val audioRecord = record ?: return
        val buf = ByteArray(8192)
        var total = 0
        try {
            while (running) {
                val n = audioRecord.read(buf, 0, buf.size)
                if (n > 0) {
                    processPcm16(buf, n)
                    output?.write(buf, 0, n)
                    total += n
                }
            }
        } finally {
            try { audioRecord.stop() } catch (_: Exception) {}
            audioRecord.release()
            record = null
            output?.let {
                try {
                    it.seek(0)
                    writeHeader(it, total, rate, channels)
                    it.close()
                } catch (_: Exception) {}
            }
            output = null
        }
    }

    private fun stopCaptureInternal() {
        running = false
        try { worker?.join(1200) } catch (_: InterruptedException) {}
        worker = null
        try { projectionCallback?.let { projection?.unregisterCallback(it) } } catch (_: Exception) {}
        projectionCallback = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
    }

    private fun processPcm16(buf: ByteArray, len: Int) {
        val gain = 10.0.pow(requestedGainDb / 20.0)
        var i = 0
        while (i + 1 < len) {
            val v = ((buf[i].toInt() and 0xff) or (buf[i + 1].toInt() shl 8)).toShort().toInt()
            var x = v * gain

            // Conservative low-level attenuation for digital playback capture.
            // This is not a spectral denoiser and does not use microphone NoiseSuppressor.
            if (requestedNoiseGate && abs(x) < 160.0) x = 0.0
            if (requestedNoiseReduction && abs(x) < 220.0) x *= 0.15

            // Normalize is reserved for a future two-pass peak stage. We deliberately
            // do not fake normalization in a streaming single-pass recorder.
            x = x.coerceIn(-32768.0, 32767.0)
            val q = x.toInt()
            buf[i] = (q and 0xff).toByte()
            buf[i + 1] = ((q shr 8) and 0xff).toByte()
            i += 2
        }
    }

    private fun startForegroundCompat() {
        val text = if (Build.VERSION.SDK_INT >= 29) {
            "Capturing eligible digital playback audio"
        } else {
            "Recording audio input"
        }
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("BT Recorder")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("BT Recorder")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
        }

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "BT Recorder Capture", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onDestroy() {
        stopCaptureInternal()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun writeHeader(file: RandomAccessFile, dataLen: Int, rate: Int, channels: Int) {
        file.writeBytes("RIFF")
        file.writeIntLE(36 + dataLen)
        file.writeBytes("WAVE")
        file.writeBytes("fmt ")
        file.writeIntLE(16)
        file.writeShortLE(1)
        file.writeShortLE(channels)
        file.writeIntLE(rate)
        file.writeIntLE(rate * channels * 2)
        file.writeShortLE(channels * 2)
        file.writeShortLE(16)
        file.writeBytes("data")
        file.writeIntLE(dataLen)
    }
}

private fun RandomAccessFile.writeIntLE(v: Int) {
    write(byteArrayOf(v.toByte(), (v shr 8).toByte(), (v shr 16).toByte(), (v shr 24).toByte()))
}

private fun RandomAccessFile.writeShortLE(v: Int) {
    write(byteArrayOf(v.toByte(), (v shr 8).toByte()))
}
