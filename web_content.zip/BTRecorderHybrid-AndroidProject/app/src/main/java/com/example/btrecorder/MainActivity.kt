package com.example.btrecorder

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebViewClient
import android.net.Uri
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.util.Locale
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val captureCode = 5001
    private val notificationRequestCode = 5002
    private val audioPermissionRequestCode = 5003

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val url = request?.url ?: return null
                if (url.scheme.equals("https", true) && url.host.equals("btrecorder.local", true) && url.path?.startsWith("/recordings/") == true) {
                    return serveRecording(url, request.requestHeaders["Range"])
                }
                return super.shouldInterceptRequest(view, request)
            }
        }
        web.addJavascriptInterface(Bridge(this), "AndroidCapture")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), notificationRequestCode)
        }
    }

    fun recordingListJson(): String {
        val dir = getExternalFilesDir(android.os.Environment.DIRECTORY_MUSIC) ?: filesDir
        val files = dir.listFiles()?.filter { it.isFile && it.name.startsWith("BT-") && it.extension.lowercase(Locale.US) in setOf("wav", "raw") }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()
        val items = files.map {
            val name = it.name.replace("\\", "")
            "{\"name\":${org.json.JSONObject.quote(name)},\"size\":${it.length()},\"modified\":${it.lastModified()},\"url\":${org.json.JSONObject.quote(\"https://btrecorder.local/recordings/${Uri.encode(name)}\")}}"
        }
        return "[${items.joinToString(",")}]"
    }

    fun deleteRecording(name: String): Boolean {
        val f = safeRecordingFile(name) ?: return false
        return f.delete()
    }

    fun shareRecording(name: String) {
        val f = safeRecordingFile(name) ?: return
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = if (f.extension.equals("wav", true)) "audio/wav" else "application/octet-stream"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "Share recording"))
    }

    private fun safeRecordingFile(name: String): File? {
        val clean = Uri.decode(name)
        if (clean.contains("/") || clean.contains("\\") || clean.contains("..")) return null
        val dir = getExternalFilesDir(android.os.Environment.DIRECTORY_MUSIC) ?: filesDir
        val f = File(dir, clean).canonicalFile
        return if (f.parentFile?.canonicalFile == dir.canonicalFile && f.isFile) f else null
    }

    private fun serveRecording(url: Uri, rangeHeader: String?): WebResourceResponse? {
        val name = url.path?.removePrefix("/recordings/")?.let(Uri::decode) ?: return null
        val file = safeRecordingFile(name) ?: return null
        val mime = when (file.extension.lowercase(Locale.US)) {
            "wav" -> "audio/wav"
            "raw" -> "application/octet-stream"
            else -> "application/octet-stream"
        }
        val length = file.length()
        var start = 0L
        var end = length - 1
        var status = 200
        val headers = mutableMapOf("Accept-Ranges" to "bytes", "Content-Length" to length.toString())
        if (!rangeHeader.isNullOrBlank() && rangeHeader.startsWith("bytes=")) {
            try {
                val spec = rangeHeader.removePrefix("bytes=").split(",")[0]
                val parts = spec.split("-", limit = 2)
                start = parts[0].toLong()
                end = if (parts.size > 1 && parts[1].isNotBlank()) parts[1].toLong() else length - 1
                if (start >= length || start > end) return WebResourceResponse(mime, null, 416, "Range Not Satisfiable", mapOf("Content-Range" to "bytes */$length"), null)
                end = end.coerceAtMost(length - 1)
                status = 206
                val count = end - start + 1
                headers["Content-Length"] = count.toString()
                headers["Content-Range"] = "bytes $start-$end/$length"
            } catch (_: Exception) { }
        }
        val input = FileInputStream(file)
        if (start > 0) input.skip(start)
        val bounded = object : InputStream() {
            var remaining = end - start + 1
            override fun read(): Int { if (remaining <= 0) return -1; val v=input.read(); if (v >= 0) remaining--; return v }
            override fun read(b: ByteArray, off: Int, len: Int): Int { if (remaining <= 0) return -1; val n=input.read(b, off, minOf(len.toLong(), remaining).toInt()); if (n > 0) remaining -= n; return n }
            override fun close() { input.close() }
        }
        return WebResourceResponse(mime, null, status, if (status == 206) "Partial Content" else "OK", headers, bounded)
    }

    fun requestCapture() {
        if (Build.VERSION.SDK_INT < 29) {
            // Android 5-9 has no public internal playback-capture API.
            // Use microphone/audio-input fallback; a Bluetooth SCO headset mic
            // may be selected by Android when the device routes input to it.
            if (Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequestCode)
            } else {
                startMicrophoneFallback()
            }
            return
        }
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(), captureCode)
    }

    private fun startMicrophoneFallback() {
        DigitalCaptureService.startMicrophone(this)
        Toast.makeText(this, "Android 5-9: recording audio input (not internal playback)", Toast.LENGTH_LONG).show()
        web.evaluateJavascript("window.captureStarted && window.captureStarted()", null)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionRequestCode) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startMicrophoneFallback()
            } else {
                web.evaluateJavascript("window.captureFailed && window.captureFailed('Microphone/audio-input permission was denied')", null)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureCode && resultCode == RESULT_OK && data != null) {
            DigitalCaptureService.start(this, resultCode, data)
            Toast.makeText(this, "Digital playback capture started", Toast.LENGTH_SHORT).show()
            web.evaluateJavascript("window.captureStarted && window.captureStarted()", null)
        } else if (requestCode == captureCode) {
            web.evaluateJavascript("window.captureFailed && window.captureFailed('Android capture permission was cancelled')", null)
        }
    }
}
