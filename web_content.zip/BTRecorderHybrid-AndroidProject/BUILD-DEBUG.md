# BT Recorder Hybrid — Android 5 to 9 + Android 10+

Native Android Studio project. This is **not** the Website2APK project.

## Build Debug APK

1. Open this folder in Android Studio.
2. Let Gradle sync/download dependencies.
3. Select **Build > Select Build Variant > debug**.
4. Select **Build > Build APK(s)**.

Command line:

- Windows: `gradlew.bat assembleDebug`
- Linux/macOS: `./gradlew assembleDebug`

The APK is normally at:
`app/build/outputs/apk/debug/app-debug.apk`

The project also copies the debug APK to:
`APK-Output/BTRecorder-Hybrid-v1.0-debug.apk`

## Audio modes

- Android 10+ (API 29+): Android MediaProjection / playback-capture path.
- Android 5–9 (API 21–28): audio-input fallback. Android 5–9 has no public playback-capture API for other apps' internal audio.

## Gradle

The project uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21. The included wrapper is configured for Gradle 8.9.
