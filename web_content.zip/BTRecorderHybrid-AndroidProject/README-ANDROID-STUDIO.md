# BT Recorder Hybrid — Android 5+ compatibility

## Recording modes

- **Android 10+ (API 29+)**: uses Android `AudioPlaybackCaptureConfiguration` for eligible internal playback audio. Apps that disable playback capture cannot be bypassed.
- **Android 5.0–9.x (API 21–28)**: uses the public `AudioRecord` audio-input API as a fallback. This is **not internal app playback capture**. It records the microphone/audio input available to the device. A compatible Bluetooth SCO headset microphone may be routed as the input on supported devices.

## Build

Open `BTRecorderHybrid-AndroidProject` in Android Studio and build `app`.

- `minSdk = 21` (Android 5.0)
- `targetSdk = 35`
- `compileSdk = 35`

The debug APK is copied to `APK-Output/` after a successful `assembleDebug`.

## Android 5–9 test

1. Install the APK.
2. Open the app.
3. Press **Start Recording**.
4. Grant **Microphone / audio input** permission when Android asks.
5. Play the desired audio through the speaker or a supported Bluetooth route.
6. Stop recording and open the recording list.

### Important limitation

Android 5–9 does not expose the public `AudioPlaybackCaptureConfiguration` API. Therefore this build cannot record another app's internal digital playback directly on those Android versions. If the requirement is specifically silent/internal capture without microphone or an input route, Android 10+ is required for the standard public API.
