SHREE SENDHAV DAIRY V34 - FARMER APP

Base: Shree_Sendhav_Dairy_V34_DESKTOP_BACKUP_LOCAL_DATA_CLEAR_FINAL.zip

This is a separate READ-ONLY Farmer App. It mirrors the V34 Farmer Portal data already published by the desktop software to Firebase.

PLANTS
- Ashta (Firebase ID: main)
- Arandiya (arandiya)
- Narsinggar (narsinggarh)
- Aehmadpur (aehmadpur)

LOGIN
1. Select Plant.
2. Enter Farmer Code.
3. Enter the 4-digit Farmer Login PIN from Desktop Farmer Master.
4. Login.

DATA MIRROR
- Farmer master: name, village, mobile (last 4 digits shown)
- Milk entries: date, shift, animal, milk, FAT, SNF, CLR, rate/formula, amount
- Payments
- Product purchases
- 10-day summary/date-range summary
- Read-only: no edit/delete from Farmer App
- Live Firestore listeners update the screen when Desktop republishes the farmer portal.

IMPORTANT
The desktop V34 must have Firebase connected and must successfully publish Farmer App + PIN Sync. Its current portal publisher uses farmerPortal/{plant}/users/{phoneId} and loginIndex. Existing Firestore rules in the supplied desktop source allow signed-in farmer sessions to read the matching farmer record.

HTML TO APK
Use this folder as the HTML source when creating an Android APK. Keep index.html and manifest.json together. Internet is required for Firebase live mirror.
