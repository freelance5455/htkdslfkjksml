import json
import os
import re
import secrets
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from threading import RLock

from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile, status
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = DATA_DIR / "uploads"
GAMES_FILE = DATA_DIR / "games.json"
ANNOUNCEMENTS_FILE = DATA_DIR / "announcements.json"
ALLOWED_GAME_EXTENSIONS = {".apk", ".zip"}
ALLOWED_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".gif"}
MAX_UPLOAD_CHUNK = 1024 * 1024
SESSION_TTL_SECONDS = 12 * 60 * 60

DATA_DIR.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
for metadata_path in (GAMES_FILE, ANNOUNCEMENTS_FILE):
    if not metadata_path.exists():
        metadata_path.write_text("[]", encoding="utf-8")

app = FastAPI(title="PROGETTO OMEGA")
metadata_lock = RLock()
admin_sessions: dict[str, float] = {}


def read_metadata(path: Path) -> list[dict]:
    with metadata_lock:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            raise HTTPException(status_code=500, detail="Archivio dati non leggibile") from exc
    if not isinstance(data, list):
        raise HTTPException(status_code=500, detail="Formato archivio non valido")
    return data


def write_metadata(path: Path, data: list[dict]) -> None:
    with metadata_lock:
        temporary_path = path.with_suffix(path.suffix + ".tmp")
        temporary_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary_path.replace(path)


def valid_admin_session(request: Request) -> bool:
    token = request.cookies.get("omega_admin_session", "")
    expiry = admin_sessions.get(token)
    now = time.time()
    for session_token, session_expiry in list(admin_sessions.items()):
        if session_expiry <= now:
            admin_sessions.pop(session_token, None)
    return bool(expiry and expiry > now)


def require_admin(request: Request) -> None:
    if not valid_admin_session(request):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Accesso amministratore richiesto")


class LoginRequest(BaseModel):
    code: str = Field(min_length=1, max_length=256)


class AnnouncementRequest(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    body: str = Field(min_length=1, max_length=2000)


async def save_upload(upload: UploadFile, destination: Path) -> int:
    size = 0
    try:
        with destination.open("wb") as output:
            while chunk := await upload.read(MAX_UPLOAD_CHUNK):
                output.write(chunk)
                size += len(chunk)
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    finally:
        await upload.close()
    return size


@app.get("/api/games")
def list_games() -> list[dict]:
    games = read_metadata(GAMES_FILE)
    return sorted(games, key=lambda item: item.get("uploaded_at", ""), reverse=True)


@app.get("/api/announcements")
def list_announcements() -> list[dict]:
    announcements = read_metadata(ANNOUNCEMENTS_FILE)
    return sorted(announcements, key=lambda item: item.get("created_at", ""), reverse=True)


@app.post("/api/admin/login")
def admin_login(payload: LoginRequest, request: Request) -> JSONResponse:
    expected_code = os.environ.get("ADMIN_CODE", "omega2026")
    if not secrets.compare_digest(payload.code, expected_code):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Codice non valido")
    token = secrets.token_urlsafe(32)
    admin_sessions[token] = time.time() + SESSION_TTL_SECONDS
    response = JSONResponse({"authenticated": True})
    response.set_cookie(
        "omega_admin_session",
        token,
        httponly=True,
        secure=request.url.scheme == "https",
        samesite="strict",
        max_age=SESSION_TTL_SECONDS,
        path="/",
    )
    return response


@app.get("/api/admin/session")
def admin_session(request: Request) -> dict:
    return {"authenticated": valid_admin_session(request)}


@app.post("/api/admin/logout")
def admin_logout(request: Request) -> JSONResponse:
    token = request.cookies.get("omega_admin_session", "")
    admin_sessions.pop(token, None)
    response = JSONResponse({"authenticated": False})
    response.delete_cookie("omega_admin_session", path="/")
    return response


@app.post("/api/admin/games", status_code=status.HTTP_201_CREATED)
async def create_game(
    _: None = Depends(require_admin),
    game_file: UploadFile = File(...),
    name: str = Form(..., min_length=1, max_length=120),
    description: str = Form("", max_length=2000),
    cover_url: str = Form("", max_length=1000),
    cover_file: UploadFile | None = File(None),
) -> dict:
    original_name = Path(game_file.filename or "").name
    extension = Path(original_name).suffix.lower()
    if extension not in ALLOWED_GAME_EXTENSIONS:
        await game_file.close()
        if cover_file:
            await cover_file.close()
        raise HTTPException(status_code=400, detail="Sono consentiti solo file .apk o .zip")
    if not name.strip():
        raise HTTPException(status_code=400, detail="Inserisci il nome del gioco")
    if cover_url.strip() and not re.match(r"^(https?://|/api/covers/)", cover_url.strip()):
        raise HTTPException(status_code=400, detail="L'indirizzo della copertina non è valido")

    game_id = uuid.uuid4().hex
    game_filename = f"{game_id}{extension}"
    game_path = UPLOAD_DIR / game_filename
    cover_filename = None
    try:
        file_size = await save_upload(game_file, game_path)
        cover = cover_url.strip()
        if cover_file and cover_file.filename:
            cover_extension = Path(Path(cover_file.filename).name).suffix.lower()
            if cover_extension not in ALLOWED_IMAGE_EXTENSIONS:
                raise HTTPException(status_code=400, detail="Formato copertina non supportato")
            cover_filename = f"{game_id}-cover{cover_extension}"
            await save_upload(cover_file, UPLOAD_DIR / cover_filename)
            cover = f"/api/covers/{cover_filename}"
        elif cover_file:
            await cover_file.close()

        game = {
            "id": game_id,
            "name": name.strip(),
            "description": description.strip(),
            "cover": cover,
            "filename": game_filename,
            "original_filename": original_name,
            "file_size": file_size,
            "uploaded_at": datetime.now(timezone.utc).isoformat(),
        }
        games = read_metadata(GAMES_FILE)
        games.append(game)
        write_metadata(GAMES_FILE, games)
        return game
    except Exception:
        game_path.unlink(missing_ok=True)
        if cover_filename:
            (UPLOAD_DIR / cover_filename).unlink(missing_ok=True)
        raise


@app.get("/api/covers/{filename}")
def get_cover(filename: str) -> FileResponse:
    if not re.fullmatch(r"[a-f0-9]{32}-cover\.(png|jpg|jpeg|webp|gif)", filename):
        raise HTTPException(status_code=404, detail="Copertina non trovata")
    cover_path = UPLOAD_DIR / filename
    if not cover_path.is_file():
        raise HTTPException(status_code=404, detail="Copertina non trovata")
    return FileResponse(cover_path)


@app.get("/api/games/{game_id}/download")
def download_game(game_id: str) -> FileResponse:
    game = next((item for item in read_metadata(GAMES_FILE) if item.get("id") == game_id), None)
    if not game:
        raise HTTPException(status_code=404, detail="Gioco non trovato")
    file_path = UPLOAD_DIR / game["filename"]
    if not file_path.is_file():
        raise HTTPException(status_code=404, detail="File del gioco non trovato")
    return FileResponse(file_path, filename=game.get("original_filename", file_path.name), media_type="application/octet-stream")


@app.delete("/api/admin/games/{game_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_game(game_id: str, _: None = Depends(require_admin)) -> None:
    games = read_metadata(GAMES_FILE)
    game = next((item for item in games if item.get("id") == game_id), None)
    if not game:
        raise HTTPException(status_code=404, detail="Gioco non trovato")
    write_metadata(GAMES_FILE, [item for item in games if item.get("id") != game_id])
    (UPLOAD_DIR / game["filename"]).unlink(missing_ok=True)
    cover = game.get("cover", "")
    match = re.fullmatch(r"/api/covers/([a-f0-9]{32}-cover\.(?:png|jpg|jpeg|webp|gif))", cover)
    if match:
        (UPLOAD_DIR / match.group(1)).unlink(missing_ok=True)


@app.post("/api/admin/announcements", status_code=status.HTTP_201_CREATED)
def create_announcement(payload: AnnouncementRequest, _: None = Depends(require_admin)) -> dict:
    announcement = {
        "id": uuid.uuid4().hex,
        "title": payload.title.strip(),
        "body": payload.body.strip(),
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    if not announcement["title"] or not announcement["body"]:
        raise HTTPException(status_code=400, detail="Titolo e messaggio sono obbligatori")
    announcements = read_metadata(ANNOUNCEMENTS_FILE)
    announcements.append(announcement)
    write_metadata(ANNOUNCEMENTS_FILE, announcements)
    return announcement


@app.delete("/api/admin/announcements/{announcement_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_announcement(announcement_id: str, _: None = Depends(require_admin)) -> None:
    announcements = read_metadata(ANNOUNCEMENTS_FILE)
    if not any(item.get("id") == announcement_id for item in announcements):
        raise HTTPException(status_code=404, detail="Annuncio non trovato")
    write_metadata(ANNOUNCEMENTS_FILE, [item for item in announcements if item.get("id") != announcement_id])


app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="assets")
app.mount("/", StaticFiles(directory=BASE_DIR / "static", html=True), name="static")
