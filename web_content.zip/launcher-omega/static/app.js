const views = ['casa', 'archivio', 'scaricamento', 'amministrazione'];
const viewNames = {casa: 'Casa', archivio: 'Archivio', scaricamento: 'Scaricamento', amministrazione: 'Amministrazione'};
let games = [];
let announcements = [];
let toastTimer;

const $ = (selector) => document.querySelector(selector);
const escapeHTML = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[char]));
const formatDate = (value) => {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '' : new Intl.DateTimeFormat('it-IT', {day: '2-digit', month: 'short', year: 'numeric'}).format(date);
};
const formatSize = (bytes) => bytes < 1024 * 1024 ? `${Math.max(1, Math.round(bytes / 1024))} KB` : `${(bytes / (1024 * 1024)).toFixed(1)} MB`;

function notify(message) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2700);
}

async function api(url, options = {}) {
  const response = await fetch(url, {credentials: 'same-origin', ...options});
  if (!response.ok) {
    let message = 'Si è verificato un errore.';
    try { message = (await response.json()).detail || message; } catch {}
    throw new Error(message);
  }
  if (response.status === 204) return null;
  return response.json();
}

function showView(name) {
  if (!views.includes(name)) return;
  document.querySelectorAll('.view').forEach((view) => view.classList.toggle('active', view.id === `view-${name}`));
  document.querySelectorAll('.nav-item').forEach((button) => button.classList.toggle('active', button.dataset.view === name));
  $('#current-section').textContent = viewNames[name];
  history.replaceState(null, '', `#${name}`);
  if (name === 'amministrazione') refreshAdminState();
  window.scrollTo({top: 0, behavior: 'smooth'});
}

document.querySelectorAll('.nav-item').forEach((button) => button.addEventListener('click', () => showView(button.dataset.view)));
document.querySelectorAll('[data-go]').forEach((button) => button.addEventListener('click', () => showView(button.dataset.go)));

function gameCard(game) {
  const cover = game.cover ? `<img src="${escapeHTML(game.cover)}" alt="Copertina di ${escapeHTML(game.name)}" loading="lazy">` : '';
  return `<article class="game-card"><div class="game-cover">${cover}<span class="cover-tag">OMEGA ARCHIVE</span></div><div class="game-info"><h3>${escapeHTML(game.name)}</h3><p>${escapeHTML(game.description || 'Scopri questo titolo dalla collezione Omega.')}</p><div class="game-actions"><span class="file-meta">${formatSize(game.file_size || 0)} · ${escapeHTML((game.original_filename || '').split('.').pop().toUpperCase())}</span><a class="download-button" href="/api/games/${encodeURIComponent(game.id)}/download" data-download-id="${escapeHTML(game.id)}">SCARICA ↓</a></div></div></article>`;
}

function renderGames() {
  const hasGames = games.length > 0;
  $('#home-games').innerHTML = games.slice(0, 3).map(gameCard).join('');
  $('#home-empty').classList.toggle('hidden', hasGames);
  $('#archive-games').innerHTML = games.map(gameCard).join('');
  $('#archive-empty').classList.toggle('hidden', hasGames);
  $('#managed-games').innerHTML = games.length ? games.map((game) => `<div class="managed-row"><div class="managed-thumb">${game.cover ? `<img src="${escapeHTML(game.cover)}" alt="" style="width:100%;height:100%;object-fit:cover">` : 'Ω'}</div><div class="managed-copy"><strong>${escapeHTML(game.name)}</strong><small>${escapeHTML(game.original_filename)} · ${formatSize(game.file_size || 0)}</small></div><button class="danger-button" data-delete-game="${escapeHTML(game.id)}">ELIMINA</button></div>`).join('') : '<div class="slim-empty">Nessun gioco pubblicato.</div>';
  $('#managed-count').textContent = `${games.length} ${games.length === 1 ? 'GIOCO' : 'GIOCHI'}`;
}

function renderAnnouncements() {
  const list = (items) => items.map((item) => `<article class="announcement-card"><div><h3>${escapeHTML(item.title)}</h3><p>${escapeHTML(item.body)}</p></div><time class="announcement-date">${formatDate(item.created_at)}</time></article>`).join('');
  $('#home-announcements').innerHTML = list(announcements);
  $('#announcements-empty').classList.toggle('hidden', announcements.length > 0);
  $('#managed-announcements').innerHTML = announcements.length ? announcements.map((item) => `<div class="managed-row"><div class="managed-thumb">✦</div><div class="managed-copy"><strong>${escapeHTML(item.title)}</strong><small>${formatDate(item.created_at)} · ${escapeHTML(item.body)}</small></div><button class="danger-button" data-delete-announcement="${escapeHTML(item.id)}">ELIMINA</button></div>`).join('') : '<div class="slim-empty">Nessuna comunicazione pubblicata.</div>';
}

function renderDownloads() {
  let stored = [];
  try { stored = JSON.parse(localStorage.getItem('omega-downloads') || '[]'); } catch { stored = []; }
  const rows = stored.map((entry) => `<div class="download-row"><div class="download-symbol">⇩</div><div><h3>${escapeHTML(entry.name)}</h3><p>Download avviato · ${formatDate(entry.date)}</p></div><span class="download-status">AVVIATO</span></div>`).join('');
  $('#download-list').innerHTML = rows;
  $('#downloads-empty').classList.toggle('hidden', stored.length > 0);
}

async function loadPublicData() {
  try {
    [games, announcements] = await Promise.all([api('/api/games'), api('/api/announcements')]);
    renderGames();
    renderAnnouncements();
    renderDownloads();
  } catch (error) {
    notify(error.message);
  }
}

async function refreshAdminState() {
  try {
    const state = await api('/api/admin/session');
    $('#admin-login').classList.toggle('hidden', state.authenticated);
    $('#admin-panel').classList.toggle('hidden', !state.authenticated);
  } catch {
    $('#admin-login').classList.remove('hidden');
    $('#admin-panel').classList.add('hidden');
  }
}

document.addEventListener('click', async (event) => {
  const downloadLink = event.target.closest('[data-download-id]');
  if (downloadLink) {
    const game = games.find((item) => item.id === downloadLink.dataset.downloadId);
    if (game) {
      let stored = [];
      try { stored = JSON.parse(localStorage.getItem('omega-downloads') || '[]'); } catch { stored = []; }
      stored = [{name: game.name, date: new Date().toISOString(), id: game.id}, ...stored.filter((entry) => entry.id !== game.id)].slice(0, 30);
      localStorage.setItem('omega-downloads', JSON.stringify(stored));
      renderDownloads();
    }
  }
  const deleteGame = event.target.closest('[data-delete-game]');
  const deleteAnnouncement = event.target.closest('[data-delete-announcement]');
  if (deleteGame && confirm('Vuoi eliminare questo gioco?')) {
    try { await api(`/api/admin/games/${encodeURIComponent(deleteGame.dataset.deleteGame)}`, {method: 'DELETE'}); await loadPublicData(); notify('Gioco eliminato.'); }
    catch (error) { notify(error.message); }
  }
  if (deleteAnnouncement && confirm('Vuoi eliminare questa comunicazione?')) {
    try { await api(`/api/admin/announcements/${encodeURIComponent(deleteAnnouncement.dataset.deleteAnnouncement)}`, {method: 'DELETE'}); await loadPublicData(); notify('Comunicazione eliminata.'); }
    catch (error) { notify(error.message); }
  }
});

$('#login-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  $('#login-error').textContent = '';
  const button = event.submitter;
  button.disabled = true;
  try {
    await api('/api/admin/login', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({code: $('#admin-code').value})});
    $('#admin-code').value = '';
    await refreshAdminState();
    await loadPublicData();
    notify('Accesso amministratore effettuato.');
  } catch (error) { $('#login-error').textContent = error.message; }
  finally { button.disabled = false; }
});

$('#logout-button').addEventListener('click', async () => {
  try { await api('/api/admin/logout', {method: 'POST'}); await refreshAdminState(); notify('Sessione chiusa.'); }
  catch (error) { notify(error.message); }
});

$('#game-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const message = $('#game-form-message');
  const button = form.querySelector('button[type="submit"]');
  const file = $('#game-file').files[0];
  if (!file || !/\.(apk|zip)$/i.test(file.name)) { message.textContent = 'Seleziona un file .apk o .zip.'; message.classList.add('error'); return; }
  message.classList.remove('error');
  message.textContent = 'Caricamento in corso…';
  button.disabled = true;
  try {
    await api('/api/admin/games', {method: 'POST', body: new FormData(form)});
    form.reset();
    message.textContent = 'Gioco aggiunto all’archivio.';
    await loadPublicData();
  } catch (error) { message.textContent = error.message; message.classList.add('error'); }
  finally { button.disabled = false; }
});

$('#announcement-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const message = $('#announcement-form-message');
  const button = form.querySelector('button[type="submit"]');
  message.classList.remove('error');
  button.disabled = true;
  try {
    await api('/api/admin/announcements', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({title: form.elements.title.value, body: form.elements.body.value})});
    form.reset();
    message.textContent = 'Comunicazione pubblicata.';
    await loadPublicData();
  } catch (error) { message.textContent = error.message; message.classList.add('error'); }
  finally { button.disabled = false; }
});

const initialView = location.hash.slice(1);
showView(views.includes(initialView) ? initialView : 'casa');
loadPublicData();
if ('serviceWorker' in navigator) navigator.serviceWorker.register('/service-worker.js').catch(() => {});
