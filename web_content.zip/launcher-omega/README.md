# PROGETTO OMEGA

PWA installabile per Android per consultare un archivio giochi e distribuire file APK/ZIP. Interfaccia in italiano, nessuna registrazione; il pannello di amministrazione è pubblico ma protetto da codice.

## Requisiti

- Python 3.10+
- Connessione internet solo per caricare Google Fonts (facoltativo; i font di sistema restano disponibili)

## Avvio

```bash
cd /root/workspace/background/launcher-omega
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
# Facoltativo: imposta un codice personalizzato. Se non impostato, il default è omega2026.
export ADMIN_CODE='il-tuo-codice'
uvicorn main:app --host 0.0.0.0 --port 8000
```

Apri `http://localhost:8000`. Per installare su Android, apri l'app con un'origine HTTPS e scegli “Aggiungi a schermata Home” dal browser. Per sviluppo locale è possibile provare la PWA anche da `localhost`; i browser Android richiedono HTTPS per installare da un host remoto.

I dati persistono in `data/games.json`, `data/announcements.json` e `data/uploads/`. Fai backup dell'intera cartella `data/`.

## Funzioni

- Catalogo giochi pubblico; download diretto di `.apk` o `.zip`.
- Upload streaming su disco, nome/descrizione/coperte URL o immagine caricata.
- Eliminazione giochi e pubblicazione/eliminazione comunicazioni nel pannello admin.
- Login admin validato server-side; cookie HttpOnly, SameSite=Strict e sessione casuale server-side con scadenza di 12 ore.
- Manifest, service worker per la shell offline, layout mobile con navigazione inferiore.

L'immagine hero cerca `/static/bg.jpg`; l'app ha un gradiente di fallback pronto se non è presente. Sostituisci/aggiungi quel file per impostare lo sfondo.

## API

- `GET /api/games`, `GET /api/announcements`
- `POST /api/admin/login` con JSON `{"code":"..."}`; `POST /api/admin/logout`
- `POST /api/admin/games` multipart (`game_file`, `name`, `description`, `cover_url`, `cover_file`)
- `DELETE /api/admin/games/{id}`
- `POST /api/admin/announcements` con JSON `{"title":"...","body":"..."}`
- `DELETE /api/admin/announcements/{id}`

## Test

```bash
python -m pytest tests/test_app.py -x -q
```

The generated gradient background is `static/bg.jpg`, served at `/static/bg.jpg`; replace that file to customize the hero artwork.
