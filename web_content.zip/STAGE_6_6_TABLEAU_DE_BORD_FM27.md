# CGD — Étape 6.6 : écran 06, Tableau de bord (disposition FM27)

- En-tête : nom du club, puis « Division · Saison · Jour · jour de la semaine lunaire » ; le bouton doré affiche l'action de carrière (RÉPONSE REQUISE quand un message attend une réponse).
- Sous-onglets de l'Accueil : Tableau de bord, Actualités, Classement, Divisions, puis Détails du club et carrière.
- Six cartes sur un seul écran, sans défilement (vérifié en 895 × 393 et 844 × 390) : Messages (badge « Réponse requise »), Prochain match, Classement, Calendrier et résultats, Effectif et finances, Conseil et tâches. Style clair, identique aux écrans 07 à 10.
- Actualités : derniers résultats du club et messages ; Classement : tableau complet de la division du club ; Divisions : liste avec leader de chaque division. Lecture seule.
- Code : `src/home-views.js`, branchements dans `src/app.js`, styles dans le bloc `fm27-terrain`, tests mis à jour dans `tests/portal.test.js`.
- Non fait : la pastille « données d'exemple » de la maquette (inutile avec de vraies données).
