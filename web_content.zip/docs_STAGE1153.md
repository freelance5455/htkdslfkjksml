# CPLS V2 — Stage 1153
## Synthetic Candle Isolation
- Aggregated candles are explicitly labeled as sampled/fallback.
- A one-candle fallback is retained only for empty-data UI continuity and is not presented as an exact exchange candle.
- Existing candle integrity, merge, gap, freshness and cadence controls remain active.
