/* =========================================================
   ARAF — Main Menu & Settings Logic
   ========================================================= */

(() => {
  'use strict';

  /* ---------------------------------------------------
     Screen navigation
  --------------------------------------------------- */
  const screens = document.querySelectorAll('.screen');
  const screenHistory = ['mainmenu'];

  function getScreen(name){
    return document.getElementById('screen-' + name);
  }

  function showScreen(name, { pushHistory = true } = {}){
    const target = getScreen(name);
    if (!target) return;

    screens.forEach(s => s.classList.remove('active'));
    target.classList.add('active');

    if (pushHistory){
      if (screenHistory[screenHistory.length - 1] !== name){
        screenHistory.push(name);
      }
    }
  }

  function goBack(){
    if (screenHistory.length > 1){
      screenHistory.pop();
      const prev = screenHistory[screenHistory.length - 1];
      showScreen(prev, { pushHistory:false });
    } else {
      showScreen('mainmenu', { pushHistory:false });
    }
  }

  // Any element with data-screen navigates to that screen
  document.querySelectorAll('[data-screen]').forEach(el => {
    el.addEventListener('click', () => {
      showScreen(el.getAttribute('data-screen'));
    });
  });

  // Any element with data-back returns to the previous screen
  document.querySelectorAll('[data-back]').forEach(el => {
    el.addEventListener('click', goBack);
  });

  // Escape key = back
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape'){
      const current = document.querySelector('.screen.active');
      if (current && current.id !== 'screen-mainmenu') goBack();
    }
  });

  /* ---------------------------------------------------
     Settings: tab switching
  --------------------------------------------------- */
  const settingsTabs = document.querySelectorAll('.settings-tab');
  const settingsPanes = document.querySelectorAll('.settings-pane');

  settingsTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const targetName = tab.getAttribute('data-tab');

      settingsTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      settingsPanes.forEach(p => {
        p.classList.toggle('active', p.getAttribute('data-pane') === targetName);
      });
    });
  });

  /* ---------------------------------------------------
     Toggles
  --------------------------------------------------- */
  document.querySelectorAll('[data-toggle]').forEach(toggle => {
    toggle.addEventListener('click', () => {
      toggle.classList.toggle('on');
    });
  });

  /* ---------------------------------------------------
     Sliders
  --------------------------------------------------- */
  document.querySelectorAll('[data-slider]').forEach(slider => {
    const valueLabel = slider.parentElement.querySelector('.slider-value');

    function updateSlider(){
      const val = slider.value;
      slider.style.setProperty('--val', val + '%');
      if (valueLabel) valueLabel.textContent = val;
    }

    slider.addEventListener('input', updateSlider);
    updateSlider();
  });

  /* ---------------------------------------------------
     Segmented controls
  --------------------------------------------------- */
  document.querySelectorAll('[data-segmented]').forEach(group => {
    const segments = group.querySelectorAll('.segment');
    segments.forEach(seg => {
      seg.addEventListener('click', () => {
        segments.forEach(s => s.classList.remove('active'));
        seg.classList.add('active');
      });
    });
  });

  /* ---------------------------------------------------
     Exit button (placeholder confirmation)
  --------------------------------------------------- */
  const btnExit = document.getElementById('btnExit');
  if (btnExit){
    btnExit.addEventListener('click', () => {
      if (confirm('ARAF\'tan çıkmak istediğinize emin misiniz?')){
        // Placeholder: in a real build this would close the client / return to launcher
        document.body.style.transition = 'opacity .6s ease';
        document.body.style.opacity = '0';
      }
    });
  }

  /* ---------------------------------------------------
     Ambient ember particles
  --------------------------------------------------- */
  const emberField = document.getElementById('emberField');
  const EMBER_COUNT = 26;

  function spawnEmbers(){
    for (let i = 0; i < EMBER_COUNT; i++){
      const ember = document.createElement('span');
      ember.className = 'ember';
      const left = Math.random() * 100;
      const duration = 7 + Math.random() * 10;
      const delay = Math.random() * 12;
      const drift = (Math.random() * 80 - 40) + 'px';
      const size = 1.5 + Math.random() * 2.5;

      ember.style.left = left + '%';
      ember.style.width = size + 'px';
      ember.style.height = size + 'px';
      ember.style.animationDuration = duration + 's';
      ember.style.animationDelay = delay + 's';
      ember.style.setProperty('--drift', drift);

      emberField.appendChild(ember);
    }
  }

  if (emberField) spawnEmbers();

})();
