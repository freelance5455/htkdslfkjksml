// Runtime Resource Overlay (RRO) that targets the Android framework ("android").
// It contains resources only, no code.
plugins {
    id("com.android.application")
}

android {
    namespace = "com.goldenhandles.overlay"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.goldenhandles.overlay"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }

    lint { abortOnError = false }
}
