#!/usr/bin/env bash
# Build + install the overlay and enable it. Needs USB debugging. No root.
set -e
cd "$(dirname "$0")/.."
./gradlew :overlay:assembleDebug :app:assembleDebug
adb install -r overlay/build/outputs/apk/debug/overlay-debug.apk
adb install -r app/build/outputs/apk/debug/app-debug.apk
adb shell cmd overlay enable --user 0 com.goldenhandles.overlay
adb shell cmd overlay list | grep goldenhandles || true
echo "Done. Reopen apps to see the yellow handles."
