#!/usr/bin/env bash
# Restore default handles (disable, then remove the overlay).
adb shell cmd overlay disable --user 0 com.goldenhandles.overlay
adb uninstall com.goldenhandles.overlay
echo "Defaults restored."
