#!/usr/bin/env bash
# ROOT ONLY: package the overlay as a systemless Magisk/KernelSU module.
set -e
cd "$(dirname "$0")/.."
./gradlew :overlay:assembleDebug
rm -rf build/magisk && mkdir -p build/magisk/system/product/overlay
cp magisk/module.prop magisk/service.sh build/magisk/
cp overlay/build/outputs/apk/debug/overlay-debug.apk build/magisk/system/product/overlay/GoldenHandles.apk
(cd build/magisk && zip -r ../GoldenHandles-magisk.zip .)
echo "Flash build/GoldenHandles-magisk.zip in Magisk or KernelSU, then reboot."
