package com.goldenhandles

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.drawable.VectorDrawable
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

/**
 * Companion app. The yellow handles themselves come from the RRO overlay package
 * (com.goldenhandles.overlay). This app detects compatibility, and can enable / disable the
 * overlay when root is available. Without root it shows the exact ADB commands instead.
 * It requests no permissions, draws no windows and uses no accessibility service, so it cannot
 * touch banking apps, secure screens, keyboards or system security.
 */
class MainActivity : Activity() {

    private val overlayPkg = "com.goldenhandles.overlay"
    private lateinit var status: TextView
    private lateinit var toggle: Switch
    private var updatingUi = false

    private val enableCmd get() = "cmd overlay enable --user 0 $overlayPkg"
    private val disableCmd get() = "cmd overlay disable --user 0 $overlayPkg"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        toggle = findViewById(R.id.toggle)

        toggle.setOnCheckedChangeListener { _, on -> if (!updatingUi) apply(on) }
        findViewById<Button>(R.id.run).setOnClickListener { run() }
        findViewById<Button>(R.id.restore).setOnClickListener { apply(false) }
        findViewById<Button>(R.id.copy).setOnClickListener { copyAdb() }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ---------- compatibility detection ----------

    private fun prop(name: String): String = try {
        Runtime.getRuntime().exec(arrayOf("getprop", name))
            .inputStream.bufferedReader().readText().trim()
    } catch (e: Exception) {
        ""
    }

    private fun overlayInstalled(): Boolean = try {
        packageManager.getPackageInfo(overlayPkg, 0); true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    /** Best-effort: if the framework handle drawable now resolves to a vector, the overlay is active. */
    private fun overlayActive(): Boolean? {
        val id = resources.getIdentifier("text_select_handle_left_material", "drawable", "android")
        if (id == 0) return null
        return try {
            @Suppress("DEPRECATION")
            resources.getDrawable(id, null) is VectorDrawable
        } catch (e: Exception) {
            null
        }
    }

    private fun refresh() {
        thread {
            val hyperOs = prop("ro.mi.os.version.name")
            val miui = prop("ro.miui.ui.version.name")
            val rom = when {
                hyperOs.isNotEmpty() -> "Xiaomi HyperOS ($hyperOs)"
                miui.isNotEmpty() -> "Xiaomi MIUI ($miui)"
                else -> "${Build.MANUFACTURER} (not Xiaomi)"
            }
            val installed = overlayInstalled()
            val active = overlayActive()
            val api = Build.VERSION.SDK_INT
            val apiNote = if (api >= 36) "Android 16 or newer: supported" else "Android $api: untested (built for 16)"

            val text = buildString {
                appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
                appendLine("System: $rom")
                appendLine("API level: $api - $apiNote")
                appendLine("Overlay installed: ${if (installed) "yes" else "NO - install overlay APK first"}")
                append(
                    "Overlay active: " + when (active) {
                        true -> "yes (detected)"
                        false -> "no (detected)"
                        null -> "unknown"
                    }
                )
                if (active == true) append("\nIf apps opened earlier still show old handles, reopen them.")
            }
            runOnUiThread {
                status.text = text
                updatingUi = true
                toggle.isChecked = active == true
                toggle.isEnabled = installed
                updatingUi = false
            }
        }
    }

    // ---------- Run ----------

    /** Selects the demo text so the iOS-style handles show right away, then turns the overlay on. */
    private fun run() {
        val demo = findViewById<EditText>(R.id.demo)
        demo.requestFocus()
        demo.setSelection(0, demo.text.length)
        apply(true)
    }

    // ---------- enable / disable ----------

    private fun apply(enable: Boolean) {
        thread {
            val ok = runRoot(if (enable) enableCmd else disableCmd)
            runOnUiThread {
                if (ok) {
                    Toast.makeText(
                        this,
                        if (enable) "Yellow handles enabled" else "Defaults restored",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    showAdbDialog(enable)
                }
                refresh()
            }
        }
    }

    private fun runRoot(cmd: String): Boolean = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
        p.waitFor() == 0
    } catch (e: Exception) {
        false
    }

    private fun showAdbDialog(enable: Boolean) {
        val cmd = if (enable) enableCmd else disableCmd
        AlertDialog.Builder(this)
            .setTitle("Root not available")
            .setMessage(
                "Android does not let a normal app change system-wide resources. " +
                    "Run this from a computer with USB debugging on:\n\nadb shell $cmd"
            )
            .setPositiveButton("Copy") { _, _ -> copy("adb shell $cmd") }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun copyAdb() = copy("adb shell $enableCmd\nadb shell $disableCmd")

    private fun copy(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("adb", text))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
    }
}
