package com.goldenhandles

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.text.Selection
import android.util.AttributeSet
import android.view.MotionEvent
import android.widget.EditText
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * EditText that draws iOS-style selection handles like the reference screenshot:
 * a thin yellow bar along the text line, ball on top of the START bar and under the END bar.
 * Dragging the bars changes the selection. The system handles are hidden by the
 * IosEditText style (see themes.xml). Works only inside this app.
 */
class IosEditText @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.editTextStyle
) : EditText(context, attrs, defStyleAttr) {

    private val d = resources.displayMetrics.density
    private val ballR = 6.5f * d
    private val barW = 2f * d
    private val hit = 26f * d
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE4AE0A.toInt() }
    private var drag = 0 // 1 = start handle, 2 = end handle

    private class Geo(val x: Float, val top: Float, val bottom: Float)

    private fun geo(offset: Int): Geo? {
        val l = layout ?: return null
        val line = l.getLineForOffset(offset)
        return Geo(
            compoundPaddingLeft + l.getPrimaryHorizontal(offset),
            (extendedPaddingTop + l.getLineTop(line)).toFloat(),
            (extendedPaddingTop + l.getLineBottom(line)).toFloat()
        )
    }

    override fun onSelectionChanged(selStart: Int, selEnd: Int) {
        super.onSelectionChanged(selStart, selEnd)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val a = min(selectionStart, selectionEnd)
        val b = max(selectionStart, selectionEnd)
        if (a < 0 || a == b) return
        val s = geo(a) ?: return
        val e = geo(b) ?: return
        // start: bar on the line, ball above it
        canvas.drawRect(s.x - barW / 2, s.top, s.x + barW / 2, s.bottom, paint)
        canvas.drawCircle(s.x, s.top - ballR + d, ballR, paint)
        // end: bar on the line, ball below it
        canvas.drawRect(e.x - barW / 2, e.top, e.x + barW / 2, e.bottom, paint)
        canvas.drawCircle(e.x, e.bottom + ballR - d, ballR, paint)
    }

    private fun pick(x: Float, y: Float): Int {
        val a = min(selectionStart, selectionEnd)
        val b = max(selectionStart, selectionEnd)
        if (a < 0 || a == b) return 0
        val s = geo(a) ?: return 0
        val e = geo(b) ?: return 0
        val inStart = abs(x - s.x) <= hit && y in (s.top - 2 * ballR - 12 * d)..s.bottom
        val inEnd = abs(x - e.x) <= hit && y in e.top..(e.bottom + 2 * ballR + 12 * d)
        return when {
            inStart && inEnd -> if (abs(x - s.x) <= abs(x - e.x)) 1 else 2
            inStart -> 1
            inEnd -> 2
            else -> 0
        }
    }

    private fun moveHandle(x: Float, y: Float) {
        val a = min(selectionStart, selectionEnd)
        val b = max(selectionStart, selectionEnd)
        // finger sits on the ball, so aim at the text line next to it
        val ty = if (drag == 1) y + 14 * d else y - 14 * d
        val off = getOffsetForPosition(x, ty)
        if (off < 0) return
        if (drag == 1) Selection.setSelection(text, min(off, b), b)
        else Selection.setSelection(text, a, max(off, a))
        invalidate()
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                drag = pick(ev.x + scrollX, ev.y + scrollY)
                if (drag != 0) {
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }
            }
            MotionEvent.ACTION_MOVE -> if (drag != 0) {
                moveHandle(ev.x, ev.y)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (drag != 0) {
                drag = 0
                return true
            }
        }
        return super.onTouchEvent(ev)
    }
}
