#!/system/bin/sh
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
sleep 5
cmd overlay enable --user 0 com.goldenhandles.overlay
