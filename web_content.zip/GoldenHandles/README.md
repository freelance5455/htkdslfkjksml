# Golden Handles

Yellow text selection handles, caret and highlight for Android 16 / Xiaomi HyperOS.
Colour sampled from the reference screenshot: `#E4AE0A`, highlight the same yellow at ~35% alpha.
Liquid Glass features are removed.

> **Not compiled or tested on a device.** The sandbox that produced this had no Android SDK.

## Two different things

| | iOS style (bar + ball like the screenshot) | System style (yellow ball) |
|---|---|---|
| Where | **Inside this app only** (`IosEditText`) | Other apps, via the overlay |
| Root needed | No | Usually yes on HyperOS |
| Draggable | Yes | Yes (system handles) |

Why the bar cannot go system-wide: Android always places a handle's drawable *below* the text line
(its top touches the bottom of the line). A replacement drawable therefore cannot draw a bar next to the text
or a ball above the first line. Only a view that draws its own handles can, which is what `IosEditText` does.
Doing this in every app would need an accessibility-service overlay that reads other apps' screens. That conflicts
with the safety rules for this project (banking apps, secure screens, keyboards) and is not included.

## Run button

Run selects the demo text (so you see the iOS handles instantly) and enables the overlay for other apps:
root -> done directly; no root -> a dialog shows the exact `adb shell cmd overlay enable ...` command.

## Modules

* `overlay/` - Runtime Resource Overlay for the framework handle drawables, caret and highlight colour.
* `app/` - companion app: Run, on/off switch, Restore defaults, compatibility detection, two test fields.

## Applying the overlay

* **Rooted (Magisk / KernelSU):** `scripts/make_magisk_zip.sh`, flash, reboot. Most reliable on HyperOS.
* **No root, ADB:** `scripts/apply_adb.sh`. Android 16 / HyperOS may refuse to enable a third-party overlay on
  `android`. If it does, root is required.
* Apps that draw their own handles (many Compose and Flutter apps) keep their own colours.

## Safety

No overlay window, no accessibility service, no permissions. The RRO changes drawables and one colour only, so
`FLAG_SECURE` screens, banking apps, keyboards and system security are untouched. Restore defaults = disable or
uninstall the overlay (`scripts/restore_adb.sh`, the app button, or remove the Magisk module).

## Build

**A. Computer:** open in Android Studio, let it sync, then `./gradlew :overlay:assembleDebug :app:assembleDebug`.
APKs: `app/build/outputs/apk/debug/app-debug.apk` and `overlay/build/outputs/apk/debug/overlay-debug.apk`.

**B. Phone only (GitHub, free):** create a repo, upload everything from this zip (keep the `.github` folder),
open the Actions tab -> "Build APKs" -> Run workflow, then download the `GoldenHandles-APKs` artifact.
Install both APKs (overlay first, then app), open Golden Handles, tap Run.

## Tuning

Overlay handle shapes: `overlay/src/main/res/drawable/text_select_handle_*_material.xml` (44x28 vector).
iOS-style sizes: constants at the top of `IosEditText.kt` (`ballR`, `barW`).
