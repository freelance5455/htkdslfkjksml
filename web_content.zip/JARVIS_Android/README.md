# J.A.R.V.I.S. para Android — projeto APK

Este pacote contém o HTML unificado dentro de um aplicativo Android WebView e um workflow para compilar um APK de depuração.

## Como obter o APK usando GitHub Actions

1. Entre em https://github.com e crie um repositório novo.
2. Extraia este ZIP e envie **todos os arquivos e pastas** para a raiz do repositório.
3. Abra a aba **Actions** e habilite os workflows, se o GitHub pedir.
4. Selecione **Build JARVIS APK** e toque em **Run workflow**. Também pode compilar automaticamente ao enviar arquivos para `main`/`master`.
5. Abra a execução concluída, vá até **Artifacts** e baixe `JARVIS-debug-APK`.
6. Extraia o ZIP do artefato e instale `app-debug.apk` no Android. Talvez seja necessário permitir instalação para o app usado para abrir o arquivo.

## Observações

- É um APK de depuração, adequado para teste e instalação manual; não é um APK publicado na Play Store.
- O código HTML fica empacotado no app.
- A IA online ainda depende de internet, de uma chave válida configurada dentro do JARVIS e da disponibilidade do provedor/modelo.
- Microfone e câmera solicitam permissões do Android. O reconhecimento de voz também depende do suporte do WebView/serviços de voz instalados.
- A chave de API não está incluída no projeto.
