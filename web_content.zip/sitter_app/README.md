# alaga.ph Android prototype

A WebView-based Android Studio project for the Philippines-only babysitter marketplace prototype.

## Included
- alaga.ph branding
- 4,929 fictional sitter profiles for UI, search, filtering and booking-flow testing
- Search across sitter name, region, province, city and official Barangay reference
- Offline region, province, city/municipality and Barangay filters backed by the bundled PSGC dataset
- Local-only demo bookings, favorites and messages
- PostgreSQL backend schema foundation in `database/schema.sql`
- PSGC CSV import template in `data_templates/psgc_import_template.csv`

## Important test-data warning
All generated profiles, rates, ratings, booking counts, skills and placeholder barangay labels are synthetic. They are not real people, genuine reviews, actual availability, identity checks or background checks. Never use demo credentials/status as a production trust signal. Demo records should be isolated from production data.

## Geographic coverage status
The project bundles the operator-provided PSA PSGC publication and validates its expected row counts. Location dropdowns are implemented in the offline WebView. The special geographic row without a parent is retained without inventing a relationship; production-grade handling of special administrative cases still needs QA. Official source: https://psa.gov.ph/classification/psgc

PSA reported the 30 September 2026 PSGC totals as 18 regions, 82 provinces, 149 cities, 1,493 municipalities and 42,010 barangays. City count includes 33 highly urbanized cities, 5 independent component cities and 111 component cities. Revalidate counts against the downloaded publication before accepting an import.

## Android build
Requirements: Android Studio or command-line Android SDK, JDK 21, Gradle wrapper, Android platform/build-tools matching `compileSdk 35`.

1. Open this folder in Android Studio.
2. Install Android SDK Platform 35 and matching Build Tools from SDK Manager.
3. Sync Gradle and build `app` > `assembleDebug`.
4. APK output should be `app/build/outputs/apk/debug/app-debug.apk`.

This project archive has not been successfully compiled in this environment; no APK is included. The execution environment did not have Android SDK / Gradle installed and could not reach the Android download host. Do not treat it as a verified build until it compiles and is tested on a device.

## Backend schema
`database/schema.sql` is a starting point, not a deployed service. It expects PostgreSQL and `pgcrypto` for `gen_random_uuid()` (enable with `CREATE EXTENSION IF NOT EXISTS pgcrypto;`). Authentication, authorization, validation, privacy controls, payment integrations, audit logging, backups and production deployment are still required.

## Nationwide PSGC import + synthetic test-data generator

A reproducible generator is now included at `tools/generate_demo_data.py`. It accepts a normalized CSV based on the official PSA PSGC publication and creates a JSON dataset containing every supplied geographic row plus a configurable number of clearly labelled synthetic sitter profiles per city/municipality. If official barangay rows are present and linked to their city/municipality by parent PSGC code, synthetic profiles are assigned a real reference barangay from that dataset. No names, ratings, skills, or bookings represent real people.

1. Download the latest publication from the official [PSA PSGC page](https://psa.gov.ph/classification/psgc).
2. Convert/map it into `data_templates/psgc_normalized_template.csv` columns. Preserve official PSGC codes and parent relationships; do not guess missing codes.
3. Run: `python tools/generate_demo_data.py your_normalized_psgc.csv --out build/demo-data.json --per-city 3`.
4. Validate official counts, duplicate codes, parent links, and release date before using the generated dataset.
5. Keep the resulting test data in a demo/staging environment only. Do not expose fake sitters or synthetic ratings in production.

Automated generator test: `python -m pytest -q tests`. This tests generator logic against a tiny fixture; it does not validate the full PSA dataset or compile the Android app.

## PSGC nationwide import and validation (new)

Use the Philippine Statistics Authority's official PSGC publication only:
https://psa.gov.ph/classification/psgc
Download the latest **PSGC Publication Datafile** XLSX, note the exact release date,
and keep the original workbook as an audit artifact. Do not manually fabricate place
names or codes.

```bash
python -m pip install openpyxl
python tools/import_psgc_xlsx.py /path/to/official_psgc.xlsx \
  --out data/psgc_normalized.csv \
  --source-version "PSA PSGC as of YYYY-MM-DD" --updated-at "YYYY-MM-DD"
python tools/validate_psgc.py data/psgc_normalized.csv \
  --report build/psgc-validation.json --check-sept-2026
python tools/generate_demo_data.py data/psgc_normalized.csv \
  --out build/demo-data.json --per-city 3
```

Workbook formats can change. If the importer cannot detect the exact header row or
column names, pass `--sheet SHEET_NAME` and `--columns` with a JSON object mapping
canonical keys (`code`, `name`, `level`, `parent`, `region`, `province`, `citymun`,
`urbanrural`) to the exact worksheet header text. Inspect the resulting CSV and
validation report. `--check-sept-2026` uses PSA's published counts as a release-specific
sanity check; remove it when importing a different release and update expected totals.

The importer and validator do not download PSA data automatically. This avoids
silently shipping stale or fabricated official geography. No full nationwide coverage
claim should be made until a real official workbook is imported, the validation report
passes, and the data is loaded into the app/backend.

## Imported PSA PSGC dataset (30 September 2026)

The operator-supplied `PSGC-3Q-2026-Publication-Datafile.xlsx` has been normalized into `data/psgc_normalized.csv` (43,768 rows total, including special geographic entries) and checked against the expected September 2026 counts: 18 regions, 82 provinces, 149 cities, 1,493 municipalities, and 42,010 barangays. Validation report: `build/psgc-validation.json`.

`build/demo-data.json` contains 4,926 clearly labelled synthetic sitter test profiles (3 per each of 1,642 city/municipality rows) and the normalized geographic rows. These are test fixtures only, not real sitter accounts. The source workbook does not explicitly provide parent PSGC columns in a form this importer can safely infer for every special case, so do not treat the CSV's blank parent links as a production-ready navigable hierarchy. Build the parent mapping from official PSGC code semantics and test it before using it for production location navigation. No APK has been built by this project package.


## PSGC import integrated (15 October 2026)

The project now bundles `app/src/main/assets/psgc-data.js`, generated from the user-provided PSA `PSGC-3Q-2026-Publication-Datafile.xlsx` (publication date 30 September 2026). The source records are retained in `data/psgc_normalized.csv`. The app's offline WebView reads the bundled data directly; no network connection is required for the location directory or demo sitter profiles.

Validated source counts: 18 regions, 82 provinces, 149 official `City` level rows, 1,493 municipalities, 42,010 barangays, plus 14 sub-municipalities and two special rows (City of Isabela is preserved separately because the workbook leaves its geographic level blank; Special Geographic Area is also preserved). There are 43,768 source rows in total. One special-area row has no parent in the source hierarchy and is retained without inventing a parent.

The app bundles 4,929 synthetic sitter profiles: three for each of 1,643 city/municipality/special-city hubs. Names, ratings, skills, reviews, bookings and sitter qualifications are test-only and are not real or verified. Favorites, booking requests and messages persist locally on the device via localStorage; no real sitter is contacted and no backend/payment service is connected. Profile display fields are mapped from the bundled synthetic data; Barangay filters use PSGC codes. Booking requests now reject end times that are not later than start times, and the Android back button returns to the home screen when another in-app page is open.

## Build status

Automated Python tests validate the importer/data generator, and the PSGC validator passes the official expected counts. An installable APK is **not included**: this environment has no Android SDK/Gradle installation available to compile it. To build on a machine with Android SDK and Gradle installed, open this project in Android Studio and run the `assembleDebug` Gradle task.
