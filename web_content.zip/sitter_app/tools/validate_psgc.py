#!/usr/bin/env python3
"""Validate normalized PSGC rows; emits a report and fails on integrity errors."""
import argparse,csv,json
from collections import Counter
from pathlib import Path
EXPECTED={'REGION':18,'PROVINCE':82,'CITY':149,'MUNICIPALITY':1493,'BARANGAY':42010}
def main():
 p=argparse.ArgumentParser();p.add_argument('csv_file');p.add_argument('--report',default='build/psgc-validation.json');p.add_argument('--check-sept-2026',action='store_true');a=p.parse_args()
 rows=list(csv.DictReader(open(a.csv_file,encoding='utf-8-sig',newline='')))
 codes=[r['psgc_code'].strip() for r in rows]; cnt=Counter(r['level'].strip().upper() for r in rows)
 errors=[]; warnings=[]
 if len(codes)!=len(set(codes)): errors.append('Duplicate PSGC codes detected')
 bycode={r['psgc_code'].strip():r for r in rows}
 for r in rows:
  code=r['psgc_code'].strip(); parent=r['parent_psgc_code'].strip(); level=r['level'].strip().upper()
  if not code: errors.append('Blank PSGC code'); continue
  if level!='REGION' and parent and parent not in bycode: errors.append(f'{code}: missing parent {parent}')
  if level!='REGION' and not parent: warnings.append(f'{code}: missing parent')
  if level=='UNKNOWN': warnings.append(f'{code}: unknown level')
 if a.check_sept_2026:
  for k,v in EXPECTED.items():
   if cnt[k]!=v: errors.append(f'{k} count {cnt[k]} != PSA Sept 2026 expected {v}')
 report={'rows':len(rows),'counts_by_level':dict(cnt),'errors':errors,'warnings':warnings,'valid':not errors}
 out=Path(a.report);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,indent=2),encoding='utf-8')
 print(json.dumps(report,indent=2)); raise SystemExit(1 if errors else 0)
if __name__=='__main__':main()
