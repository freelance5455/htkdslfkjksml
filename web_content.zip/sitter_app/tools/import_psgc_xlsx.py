#!/usr/bin/env python3
"""Normalize the PSA PSGC Excel publication into a strict hierarchy CSV.

Usage: python tools/import_psgc_xlsx.py input.xlsx --out data/psgc_normalized.csv
Because PSA workbook column names/layout may change between releases, this tool
inspects headers and maps common variants; use --sheet and --columns if needed.
It never invents codes or geographic names.
"""
import argparse, csv, re, sys
from pathlib import Path
try:
    from openpyxl import load_workbook
except ImportError:
    sys.exit('Missing dependency: install openpyxl (python -m pip install openpyxl)')

ALIASES = {
 'code': {'10 digit code','10-digit psgc','psgc code','geographic code','psgc'},
 'name': {'geographic location','name of geographic area','geographic area','location','name'},
 'level': {'geographic level','level','geographic type','type'},
 'parent': {'parent psgc code','parent code','parent geographic code'},
 'region': {'region','region name'}, 'province': {'province','province name'},
 'citymun': {'city/municipality','city / municipality','city municipality','city/municipality name'},
 'urbanrural': {'urban-rural','urban rural','urban/rural classification'},
}
def norm(v): return re.sub(r'\s+',' ',str(v or '').strip().lower())
def main():
 p=argparse.ArgumentParser(); p.add_argument('xlsx'); p.add_argument('--out',default='data/psgc_normalized.csv'); p.add_argument('--sheet'); p.add_argument('--source-version',default='PSA PSGC release: fill in after verification'); p.add_argument('--updated-at',default=''); p.add_argument('--columns',help='Optional JSON mapping canonical keys to exact header strings')
 a=p.parse_args(); wb=load_workbook(a.xlsx,read_only=True,data_only=True)
 ws=wb[a.sheet] if a.sheet else wb.active
 it=ws.iter_rows(values_only=True); header=next(it,None)
 if not header: sys.exit('Selected worksheet is empty')
 headers={norm(v):i for i,v in enumerate(header) if v is not None}
 import json
 custom=json.loads(a.columns) if a.columns else {}
 mapping={}
 for key, aliases in ALIASES.items():
  wanted=norm(custom[key]) if key in custom else None
  found=headers.get(wanted) if wanted else next((headers[x] for x in aliases if x in headers),None)
  if found is not None: mapping[key]=found
 if 'code' not in mapping or 'name' not in mapping:
  sys.exit('Could not identify code/name columns. Inspect headers and pass --columns JSON. Found: '+repr(list(headers)))
 raw=[]
 for vals in it:
  def get(k): return str(vals[mapping[k]] or '').strip() if k in mapping and mapping[k]<len(vals) else ''
  code=re.sub(r'\.0$','',get('code')).strip()
  name=get('name')
  if not code or not name or not re.search(r'\d',code): continue
  lvl=get('level').upper().replace(' ','_')
  raw.append({'psgc_code':code,'official_name':name,'raw_level':lvl,'parent_psgc_code':get('parent'),'region_name':get('region'),'province_name':get('province'),'city_municipality_name':get('citymun'),'urban_rural':get('urbanrural'),'source_version':a.source_version,'source_updated_at':a.updated_at})
 # Preserve official codes and geographic levels. The PSGC code hierarchy has
 # special cases (e.g. NCR and HUCs), so do not invent parent relationships
 # from string prefixes when the workbook does not provide explicit parent columns.
 out=[]
 for r in raw:
  lvl=r.pop('raw_level')
  if 'REGION' in lvl or lvl == 'REG': level='REGION'
  elif 'PROVINCE' in lvl or lvl == 'PROV': level='PROVINCE'
  elif 'BARANGAY' in lvl or lvl == 'BGY': level='BARANGAY'
  elif 'MUNICIPALITY' in lvl or lvl == 'MUN': level='MUNICIPALITY'
  elif 'CITY' in lvl: level='CITY'
  elif 'SUBMUN' in lvl: level='SUBMUNICIPALITY'
  else: level=lvl or 'UNKNOWN'
  r['level']=level
  out.append(r)
 fields=['psgc_code','parent_psgc_code','level','official_name','region_name','province_name','city_municipality_name','urban_rural','source_version','source_updated_at']
 path=Path(a.out); path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(out)
 print(f'Wrote {len(out)} rows to {path}. Review report and validate before app import.')
 print('Levels:', {k:sum(x['level']==k for x in out) for k in sorted({x['level'] for x in out})})
 print('Rows without parent:',sum(not x['parent_psgc_code'] and x['level']!='REGION' for x in out))
if __name__=='__main__': main()
