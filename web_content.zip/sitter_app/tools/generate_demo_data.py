#!/usr/bin/env python3
"""Generate isolated synthetic alaga.ph sitter test data from a normalized PSGC CSV.

Expected CSV headers: psgc_code,parent_psgc_code,level,official_name,region_name,
province_name,city_municipality_name,urban_rural,source_version,source_updated_at
The official location rows are real reference data; every sitter is explicitly synthetic.
"""
import argparse, csv, json, random
from pathlib import Path

FIRST = ['Ana','Bea','Camille','Dina','Ella','Faith','Gia','Hannah','Iris','Joy','Kara','Lia','Mika','Nina','Olive','Pia','Queenie','Rina','Sofia','Tala','Uma','Vera','Wendy','Ysa','Zia']
LAST = ['Santos','Reyes','Cruz','Garcia','Mendoza','Bautista','Ramos','Flores','Aquino','Castillo','Navarro','Rivera','Torres','Villanueva','Gonzales','Perez']
SKILLS = [['Infant care'],['First aid'],['Homework help'],['Infant care','Video intro'],['First aid','Video intro'],['Special needs experience'],['Meal preparation'],['Infant care','First aid']]

def main():
    p=argparse.ArgumentParser()
    p.add_argument('psgc_csv', help='Normalized official PSGC CSV')
    p.add_argument('--out', default='build/demo-data.json')
    p.add_argument('--per-city', type=int, default=3, help='Synthetic profiles per city/municipality')
    p.add_argument('--seed', type=int, default=20261015)
    a=p.parse_args(); random.seed(a.seed)
    rows=list(csv.DictReader(open(a.psgc_csv, newline='', encoding='utf-8-sig')))
    required={'psgc_code','parent_psgc_code','level','official_name','region_name','province_name','city_municipality_name'}
    if not rows or not required.issubset(rows[0]): raise SystemExit('CSV missing required columns: '+', '.join(sorted(required)))
    areas=[]
    codes=set()
    for r in rows:
        code=(r.get('psgc_code') or '').strip()
        if not code: continue
        if code in codes: raise SystemExit('Duplicate PSGC code: '+code)
        codes.add(code)
        areas.append({k:(r.get(k) or '').strip() for k in required | {'urban_rural','source_version','source_updated_at'}})
    parents={x['psgc_code']:x['parent_psgc_code'] for x in areas}
    for x in areas:
        if x['parent_psgc_code'] and x['parent_psgc_code'] not in parents:
            raise SystemExit(f"Missing parent {x['parent_psgc_code']} for {x['psgc_code']}")
    hubs=[x for x in areas if x['level'].upper() in ('CITY','MUNICIPALITY','SPECIAL_CITY')]
    if not hubs: raise SystemExit('No CITY or MUNICIPALITY rows found')
    profiles=[]; pid=1
    for hub in hubs:
        barangays=[x for x in areas if x['level'].upper()=='BARANGAY' and x['parent_psgc_code']==hub['psgc_code']]
        for j in range(max(0,a.per_city)):
            person=f"{FIRST[(pid*7)%len(FIRST)]} {LAST[(pid*11)%len(LAST)]}"
            profiles.append({'id':f'DEMO-{pid:07d}','display_name':person,'age':21+(pid*13)%25,
                'hourly_rate_php':150+(pid*37)%351,'rating':round(4.0+((pid*17)%10)/10,1),
                'review_count':(pid*7)%86,'sample_booking_count':(pid*13)%141,
                'skills':SKILLS[pid%len(SKILLS)],'is_demo':True,'demo_warning':'SYNTHETIC TEST PROFILE — not a real person; no verification or background check performed.',
                'home_area':{'psgc_code':hub['psgc_code'],'city_municipality':hub['official_name'],'province':hub['province_name'],'region':hub['region_name']},
                'barangay':({'psgc_code':barangays[(pid-1)%len(barangays)]['psgc_code'],'name':barangays[(pid-1)%len(barangays)]['official_name']} if barangays else None)})
            pid+=1
    out=Path(a.out); out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps({'data_type':'SYNTHETIC_DEMO_ONLY','source':'Official PSGC normalized CSV supplied by operator','areas':areas,'profiles':profiles},ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'Wrote {len(areas)} geographic rows and {len(profiles)} synthetic profiles to {out}')
    print('Do not import synthetic profiles into production. Verify the PSGC CSV release and totals before release.')
if __name__=='__main__': main()
