import csv, subprocess, sys, tempfile, json
from pathlib import Path
SCRIPT=Path(__file__).resolve().parents[1]/'tools'/'generate_demo_data.py'
def test_generates_only_marked_synthetic_profiles():
    with tempfile.TemporaryDirectory() as d:
        d=Path(d); src=d/'areas.csv'; out=d/'out.json'
        fields=['psgc_code','parent_psgc_code','level','official_name','region_name','province_name','city_municipality_name','urban_rural','source_version','source_updated_at']
        rows=[dict(zip(fields,['R','','REGION','Region X','Region X','','','','Q3 2026','2026-09-30'])),dict(zip(fields,['P','R','PROVINCE','Province Y','Region X','Province Y','','','',''])),dict(zip(fields,['C','P','CITY','Town Z','Region X','Province Y','Town Z','','',''])),dict(zip(fields,['B','C','BARANGAY','Barangay One','Region X','Province Y','Town Z','Urban','','']))]
        with src.open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
        subprocess.run([sys.executable,str(SCRIPT),str(src),'--out',str(out),'--per-city','2'],check=True,capture_output=True,text=True)
        data=json.loads(out.read_text()); assert len(data['areas'])==4; assert len(data['profiles'])==2
        assert all(x['is_demo'] and 'SYNTHETIC' in x['demo_warning'] for x in data['profiles'])
        assert all(x['barangay']['psgc_code']=='B' for x in data['profiles'])
