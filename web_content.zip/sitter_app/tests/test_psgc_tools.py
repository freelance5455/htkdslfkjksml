import csv, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def test_validate_accepts_simple_hierarchy(tmp_path):
 f=tmp_path/'sample.csv'
 fields=['psgc_code','parent_psgc_code','level','official_name','region_name','province_name','city_municipality_name','urban_rural','source_version','source_updated_at']
 rows=[['01','','REGION','Region One','','','','','test',''],['0101','01','PROVINCE','Province One','Region One','','','','test',''],['010101','0101','CITY','City One','Region One','Province One','City One','','test',''],['010101001','010101','BARANGAY','Barangay One','Region One','Province One','City One','','test','']]
 with f.open('w',newline='') as out:
  w=csv.writer(out);w.writerow(fields);w.writerows(rows)
 r=subprocess.run([sys.executable,str(ROOT/'tools/validate_psgc.py'),str(f),'--report',str(tmp_path/'report.json')],capture_output=True,text=True)
 assert r.returncode==0, r.stdout+r.stderr

def test_duplicate_codes_fail(tmp_path):
 f=tmp_path/'dup.csv';f.write_text('psgc_code,parent_psgc_code,level,official_name,region_name,province_name,city_municipality_name\n01,,REGION,One,,,,\n01,,REGION,Duplicate,,,,\n')
 r=subprocess.run([sys.executable,str(ROOT/'tools/validate_psgc.py'),str(f),'--report',str(tmp_path/'report.json')],capture_output=True,text=True)
 assert r.returncode==1
