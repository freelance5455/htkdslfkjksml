import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_ui_data():
    text = (ROOT / 'app/src/main/assets/psgc-data.js').read_text(encoding='utf-8')
    prefix = 'window.ALAGA_PSGC='
    assert text.startswith(prefix)
    payload = text[len(prefix):].strip()
    if payload.endswith(';'):
        payload = payload[:-1]
    return json.loads(payload)


def test_ui_has_complete_hubs_and_compact_location_data():
    data = load_ui_data()
    assert len(data['hubs']) == 1643
    assert len(data['areas']) == 43768
    assert sum(1 for a in data['areas'] if a['level'] == 'REGION') == 18
    assert sum(1 for a in data['areas'] if a['level'] == 'PROVINCE') == 82
    assert sum(1 for a in data['areas'] if a['level'] == 'BARANGAY') == 42010
    assert all(h.get('official_name') and h.get('psgc_code') and h.get('region_name') is not None for h in data['hubs'])


def test_demo_profiles_are_generated_for_every_hub():
    data = load_ui_data()
    # The UI deterministically creates three fake profiles per official city/municipality hub.
    assert len(data['hubs']) * 3 == 4929
    hub_codes = {h['psgc_code'] for h in data['hubs']}
    assert all(code for code in hub_codes)
    html = (ROOT / 'app/src/main/assets/index.html').read_text(encoding='utf-8')
    assert "ALAGA_PSGC.hubs.flatMap" in html
    for key in ['region', 'province', 'psgc_code', 'barangay_code', 'verified:false']:
        assert key in html


def test_profile_fields_match_card_and_filter_contract():
    html = (ROOT / 'app/src/main/assets/index.html').read_text(encoding='utf-8')
    required = ['id:n+1', 'name:first+', 'age:24+', 'rate:180+', 'rating:', 'reviews:', 'bookings:', 'emoji:EMOJI', 'tags:TAGS', 'bio:', 'color:', 'location:hub.official_name', 'region:hub.region_name', 'province:hub.province_name', 'psgc_code:hub.psgc_code', 'barangay_code:br?.psgc_code']
    assert all(x in html for x in required)
