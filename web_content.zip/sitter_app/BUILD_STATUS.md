# alaga.ph — build and release status

Date: 15 October 2026

## Critical runtime fix — 15 October 2026

- Fixed the startup-breaking JavaScript error: the UI referenced `ALAGA_PSGC.hubs`, but the bundled PSGC payload only contained `areas` and `profiles`. This threw before the first render, so the search filters and sitter cards never initialized. The app now derives `hubs` from official CITY, MUNICIPALITY, and SPECIAL_CITY rows.
- Confirmed in Node.js that the bundled dataset loads and exposes 43,768 area rows, 4,929 profiles, and 1,643 city/municipality hubs.
- Rechecked inline JavaScript syntax and Python tests (`3 passed`).
- Important limitation: this is a code/data smoke check, not a device/emulator UI test; no APK has been built in this environment.

## Work completed in this continuation

- Corrected the WebView profile adapter to use the fields actually present in the bundled `psgc-data.js` profiles. The app now displays the synthetic profile names, hourly rates, skills, city/region and ratings from the bundled dataset rather than looking for fields that do not exist.
- Corrected Barangay filter values to use official PSGC codes rather than a combined display label, so the selected Barangay can match a profile's location.
- Replaced the misleading verification dot with a visible `DEMO` label. All profiles remain unverified test data.
- Booking flow now blocks end times equal to or earlier than the start time, instead of producing a zero/negative duration quote.
- Android back button returns to the app's home page before exiting.
- Disabled WebView content access and zoom controls; enabled Safe Browsing where supported.

## Verified in this workspace

- Official workbook supplied by the project owner was imported to `data/psgc_normalized.csv`.
- PSGC validator: 43,768 rows; expected counts match (18 regions, 82 provinces, 149 city-level rows, 1,493 municipalities, 42,010 barangays); no validation errors. One official special-area row has no parent code in the source and is retained without inventing one.
- Bundled WebView data: 43,768 geography rows, 1,643 city/municipality/special-city hubs, 4,929 synthetic profiles.
- Python tests: `3 passed`.
- Inline JavaScript syntax check: passed with Node.js after profile adapter changes.
- ZIP archive integrity checked after packaging.

## Not yet verified / not done

- No APK was compiled: Java 21 is available, but this workspace has no installed Gradle, Android SDK (`android.jar`/`sdkmanager`) or Gradle wrapper JAR. The build script was run and correctly reported that Gradle is missing. Network DNS is unavailable here, so missing build tools cannot be downloaded in this session.
- No emulator or physical-device test was run.
- This is still a local WebView prototype. Favorites/bookings/messages use localStorage; they do not sync between users or devices. No production API, authentication, payment processor, push notifications, identity checks, or hosting has been deployed.
- PSGC totals validate, but the source has one special geographic row without a parent; production-grade handling of special administrative cases and full on-device QA are still required.

## Build the debug APK on a machine with Android Studio

1. Install Android Studio, Android SDK Platform 35 + matching Build Tools, JDK 21, and a compatible Gradle distribution.
2. Open this project folder in Android Studio and let Gradle sync. If prompted, install the requested Android Gradle Plugin/Gradle version.
3. Run **Build > Build Bundle(s) / APK(s) > Build APK(s)**, or from the project root run `gradle :app:assembleDebug` where Gradle is installed and `ANDROID_HOME`/`ANDROID_SDK_ROOT` points to the SDK.
4. Expected output: `app/build/outputs/apk/debug/app-debug.apk`.
5. Install on a test device and verify offline launch, all location dropdowns, profile search, favorites, booking validation and local message flows.

Do not distribute this prototype as a production childcare marketplace until backend, security/privacy review, real account verification, payments and on-device QA are complete.

## 2026-10-15 follow-up: startup/data payload fix

- Replaced the 17.6 MB generated PSGC JavaScript payload with an 8.1 MB compact payload containing only fields consumed by the UI.
- Demo profiles are now generated deterministically at runtime (three per each of 1,643 city/municipality hubs = 4,929 profiles) rather than duplicated inside the large location data file.
- Local-storage parsing now has a guarded fallback, so corrupt persisted demo state does not prevent startup.
- Added/updated UI data contract tests. `pytest -q`: 6 passed. Inline JavaScript syntax check with `node --check`: passed.
- Browser end-to-end test could not be completed in this environment: Chromium navigation is blocked by the environment (`ERR_BLOCKED_BY_ADMINISTRATOR`). Therefore, do not claim the UI was tested in a real browser or Android WebView. APK has not been built.

## 2026-10-15 functional pass

- Android: fixed edge-to-edge overlap on Android 15 (targetSdk 35) via window-insets padding (status bar, nav bar, keyboard); added WebChromeClient; blocked external navigation; rotation no longer reloads the 8 MB page; allowBackup disabled (local data contains addresses); added `gradle/wrapper/gradle-wrapper.properties` (Gradle 8.9, required by AGP 8.7.3) and Java 17 compile options.
- UI: replaced `prompt()` (not working in WebView) with a real in-app chat thread; search button/Enter now opens results; barangay filter no longer returns empty lists (sitters spread over a city's barangays, exact match sorted first); favorites filter; cancel booking; "Become a sitter" now saves a local draft (PHP); all user text HTML-escaped; guarded localStorage writes; home preview now samples sitters nationwide instead of only Caloocan.
- Verified in headless Chromium (file://): full flow search → profile → chat → booking → cancel → favorites → draft → reload persistence, no JS errors. Still NOT verified: Gradle build/APK and a real device/WebView.
