package com.example.littlesitter;

import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
  private WebView web;

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    final int cream = Color.rgb(251, 247, 241);
    getWindow().getDecorView().setBackgroundColor(cream);
    getWindow().setStatusBarColor(cream);
    getWindow().setNavigationBarColor(Color.rgb(255, 253, 250));
    getWindow().getDecorView().setSystemUiVisibility(
        View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

    web = new WebView(this);
    web.setBackgroundColor(cream);
    // Android 15 (targetSdk 35) forces edge-to-edge: pad the WebView so content
    // is not hidden behind the status bar, navigation bar or keyboard.
    web.setOnApplyWindowInsetsListener((v, insets) -> {
      v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
          insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
      return insets.consumeSystemWindowInsets();
    });

    WebSettings settings = web.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    settings.setAllowFileAccess(true);
    settings.setAllowContentAccess(false);
    settings.setSupportZoom(false);
    settings.setBuiltInZoomControls(false);
    settings.setDisplayZoomControls(false);
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      settings.setSafeBrowsingEnabled(true);
    }
    web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        Uri u = request.getUrl();
        return !"file".equals(u.getScheme()); // never navigate away from the bundled app
      }
    });
    setContentView(web);
    WebView.setWebContentsDebuggingEnabled(true); // chrome://inspect for debugging
    web.loadUrl("file:///android_asset/index.html");
  }

  @Override public void onBackPressed() {
    if (web == null) { super.onBackPressed(); return; }
    web.evaluateJavascript("(document.querySelector('.page.active')||{}).id||'home'", value -> {
      if (value == null || value.contains("home")) {
        MainActivity.super.onBackPressed();
      } else if (value.contains("chat")) {
        web.evaluateJavascript("showPage('messages')", null);
      } else {
        web.evaluateJavascript("showPage('home')", null);
      }
    });
  }
}
