-- alaga.ph backend foundation (PostgreSQL). Do not seed real-looking demo data into production.
CREATE TABLE geographic_areas (
  psgc_code VARCHAR(10) PRIMARY KEY,
  parent_psgc_code VARCHAR(10) REFERENCES geographic_areas(psgc_code),
  level VARCHAR(16) NOT NULL CHECK (level IN ('REGION','PROVINCE','CITY','MUNICIPALITY','BARANGAY')),
  official_name TEXT NOT NULL,
  region_name TEXT,
  province_name TEXT,
  city_municipality_name TEXT,
  urban_rural VARCHAR(16),
  source_version TEXT NOT NULL,
  source_updated_at DATE,
  is_active BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE INDEX geographic_parent_idx ON geographic_areas(parent_psgc_code);
CREATE INDEX geographic_name_idx ON geographic_areas USING gin (to_tsvector('simple', official_name));
CREATE INDEX geographic_level_idx ON geographic_areas(level, region_name, province_name);

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  role VARCHAR(16) NOT NULL CHECK (role IN ('FAMILY','SITTER','ADMIN')),
  email TEXT UNIQUE,
  phone_e164 TEXT UNIQUE,
  display_name TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  disabled_at TIMESTAMPTZ
);
CREATE TABLE sitter_profiles (
  user_id UUID PRIMARY KEY REFERENCES users(id),
  bio TEXT NOT NULL DEFAULT '',
  hourly_rate_php NUMERIC(10,2) NOT NULL CHECK (hourly_rate_php >= 0),
  home_barangay_psgc VARCHAR(10) REFERENCES geographic_areas(psgc_code),
  service_area_psgc_codes VARCHAR(10)[] NOT NULL DEFAULT '{}',
  identity_status VARCHAR(16) NOT NULL DEFAULT 'UNVERIFIED' CHECK (identity_status IN ('UNVERIFIED','PENDING','VERIFIED','REJECTED')),
  background_check_status VARCHAR(16) NOT NULL DEFAULT 'NOT_STARTED' CHECK (background_check_status IN ('NOT_STARTED','PENDING','PASSED','FAILED','EXPIRED')),
  video_url TEXT,
  is_demo BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX sitter_service_areas_idx ON sitter_profiles USING gin (service_area_psgc_codes);
CREATE TABLE bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_user_id UUID NOT NULL REFERENCES users(id),
  sitter_user_id UUID NOT NULL REFERENCES users(id),
  service_barangay_psgc VARCHAR(10) NOT NULL REFERENCES geographic_areas(psgc_code),
  starts_at TIMESTAMPTZ NOT NULL,
  ends_at TIMESTAMPTZ NOT NULL,
  children_count SMALLINT NOT NULL CHECK (children_count BETWEEN 1 AND 20),
  status VARCHAR(20) NOT NULL CHECK (status IN ('REQUESTED','ACCEPTED','DECLINED','CANCELLED','COMPLETED')),
  estimated_total_php NUMERIC(10,2) NOT NULL CHECK (estimated_total_php >= 0),
  is_demo BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (ends_at > starts_at)
);
CREATE INDEX bookings_sitter_schedule_idx ON bookings(sitter_user_id, starts_at, ends_at);
CREATE TABLE reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID NOT NULL UNIQUE REFERENCES bookings(id),
  author_user_id UUID NOT NULL REFERENCES users(id),
  sitter_user_id UUID NOT NULL REFERENCES users(id),
  rating SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  review_text TEXT NOT NULL DEFAULT '',
  is_demo BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID REFERENCES bookings(id),
  sender_user_id UUID NOT NULL REFERENCES users(id),
  recipient_user_id UUID NOT NULL REFERENCES users(id),
  body TEXT NOT NULL CHECK (length(body) BETWEEN 1 AND 5000),
  is_demo BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
