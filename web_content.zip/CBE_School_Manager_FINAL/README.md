# CBE School Manager — final merged version

Administrator: **Louis Macharia** — 0715367959 — macharialouise7@gmail.com

This is the final, merged build: the full app you've been using (staff/TSC numbers, learners,
marks, learning areas, timetables, lesson plans, attendance, parent portal, downloadable
backup) now runs on a **real shared database** — a Google Sheet — instead of each phone or
browser keeping its own separate copy. Deploy this once, share the one link, and every
teacher who opens it sees and edits the same live data.

## What changed from the browser-only version
- `getData()` / `saveData()` in `Code.gs` hold the whole app's data as one JSON entry in a
  "Database" sheet. The app still works exactly the way you already built it — same tabs,
  same logins, same screens — it just now syncs instead of staying local to one device.
- A sync badge in the top-right of the app shows "Saving…", "Saved", or a warning if the
  connection drops (in which case it keeps working from this device's own cached copy until
  it can reconnect).
- The "Download database (.json)" / "Restore from a backup file" buttons in Settings still
  work exactly as before — use them for periodic backups regardless of the shared database.

## Deploy it (10 minutes)
1. Go to **sheets.google.com** → Blank spreadsheet → name it e.g. "CBE School Manager DB".
2. **Extensions → Apps Script.**
3. Delete the default `Code.gs` content, paste in this project's `Code.gs`.
4. Click **+** next to Files → HTML → name it exactly `Index` → paste in `Index.html`.
5. In the function dropdown, choose `setup` → click **Run** (authorize when asked — this is
   your own script on your own account). This creates the Database sheet.
6. **Deploy → New deployment** → Type: **Web app** → Execute as: **Me** → Who has access:
   **Anyone** → **Deploy**. Copy the Web app URL — that's your one, final app link.
7. On your Android phone, open that link in Chrome → menu (⋮) → **Add to Home Screen** for
   a real home-screen app icon, full-screen, no browser bar (Android 4.4+).

## Honest limits, so there are no surprises
- **Security matches how you built the app**: logins and passwords live inside the same JSON
  blob, in plain text, in the Sheet — same as before, just shared now instead of local. Anyone
  with edit access to the underlying Google Sheet can see that data directly. If you want the
  stronger version (hashed passwords, encrypted marks/phone numbers, admin-gated teacher
  approval with email verification) ask for a merge with the encrypted multi-sheet backend —
  it's the version with the `Teachers`/`Students`/`Marks` sheets from earlier in this project.
- **Last write wins**: if two teachers save at the exact same moment, the later save is what
  sticks — there's no field-by-field merge. For a single school's normal pace of use this is
  rarely an issue, but it's worth knowing.
- **One cell, ~45,000-character budget**: plenty for a full school's data for several years;
  `saveData()` will refuse to save (with a clear error, not silent data loss) if you ever get
  close to that limit, and the fix at that point is the multi-sheet upgrade mentioned above.
- **No automated bulk SMS**: results still send through your own phone's Messages/Gmail app at
  your normal Safaricom rate — a true backend-triggered bulk SMS needs a paid gateway account,
  which Safaricom doesn't offer to a plain script.
- **Not a compiled Android .apk**: "Add to Home Screen" gives the real home-screen-app
  experience on Android, but a true .apk needs Android Studio and a signing key.
