/**
 * CBE SCHOOL MANAGER — final merged version
 * Backend: Google Apps Script + a Google Sheet as the shared database.
 *
 * Administrator: Louis Macharia — 0715367959 — macharialouise7@gmail.com
 *
 * HOW THIS WORKS
 *   The entire app's data (staff, learners, marks, timetables, lesson plans, attendance)
 *   is one JSON object, managed entirely by Index.html exactly as it was before. This file
 *   just gives that JSON object a shared home — one cell in a "Database" sheet — instead of
 *   each browser keeping its own separate copy. Every teacher who opens the deployed link
 *   reads and writes the same data.
 *
 *   This keeps the app simple and matches the version you already built and are using.
 *   A Sheet cell holds up to ~50,000 characters; saveData() leaves headroom below that.
 *   If the school's data ever grows past that (years of records, large classes), it should
 *   move to the multi-sheet version (separate Students/Marks/Exams/etc. sheets) — ask for
 *   that upgrade if you ever hit the limit warning.
 *
 * DEPLOY (10 minutes) — see README.md
 */

const SHEET_NAME = "Database";
const CELL_LIMIT = 45000; // stay safely under a Sheet cell's ~50,000 character limit

function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
    sheet.getRange("A1").setValue("{}");       // the JSON database
    sheet.getRange("A2").setValue("Last saved"); 
    sheet.getRange("B2").setValue(new Date());
  }
  Logger.log("Setup complete.");
}

function doGet() {
  return HtmlService.createHtmlOutputFromFile("Index")
    .setTitle("CBE School Manager")
    .addMetaTag("viewport", "width=device-width, initial-scale=1");
}

function getSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) { setup(); sheet = ss.getSheetByName(SHEET_NAME); }
  return sheet;
}

// Called by the app on load — returns the current shared database as a JSON string.
function getData() {
  const sheet = getSheet_();
  const val = sheet.getRange("A1").getValue();
  return val ? String(val) : "{}";
}

// Called by the app after every change — overwrites the shared database.
// Last write wins: if two people save within the same moment, the later save sticks.
function saveData(jsonString) {
  if (typeof jsonString !== "string") throw new Error("Invalid data.");
  if (jsonString.length > CELL_LIMIT) {
    throw new Error("Database is getting large (" + jsonString.length +
      " characters). It still saved nothing this time — ask for the multi-sheet upgrade.");
  }
  const sheet = getSheet_();
  sheet.getRange("A1").setValue(jsonString);
  sheet.getRange("B2").setValue(new Date());
  return { ok: true, savedAt: new Date().toISOString(), size: jsonString.length };
}
