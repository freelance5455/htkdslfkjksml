const express = require("express");
const path = require("path");
const app = express();
const PORT = Number(process.env.PORT || 8787);
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || "ASU17-Test-2026-Vlad-9xK4";

app.use(express.json({limit:"100kb"}));
app.use(express.static(path.join(__dirname, "public")));

let current = null;
let nextId = 1;

app.get("/api/notification", (_req, res) => res.json({ notification: current }));
app.post("/api/notification", (req, res) => {
  const auth = req.headers.authorization || "";
  if (auth !== `Bearer ${ADMIN_TOKEN}`) return res.status(401).json({error:"Неправильний тестовий токен"});
  const { region, type, title, body, sound, color } = req.body || {};
  if (!title || !body || !type || !sound) return res.status(400).json({error:"Заповніть тип, заголовок, текст і звук"});
  current = {
    id: nextId++, region: String(region || "Україна"), type: String(type),
    title: String(title), body: String(body), sound: String(sound),
    color: String(color || "#e53935"), createdAt: new Date().toISOString()
  };
  res.json({ok:true, notification:current});
});
app.post("/api/notification/clear", (req, res) => {
  const auth = req.headers.authorization || "";
  if (auth !== `Bearer ${ADMIN_TOKEN}`) return res.status(401).json({error:"Неправильний тестовий токен"});
  current = null;
  res.json({ok:true});
});
app.get("/health", (_req,res)=>res.json({ok:true, port:PORT}));
app.listen(PORT, "0.0.0.0", () => console.log(`AlarmSimulator test server: http://127.0.0.1:${PORT}`));
