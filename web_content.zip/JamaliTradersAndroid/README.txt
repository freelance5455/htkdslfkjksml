JAMALI TRADERS ANDROID PROJECT

This project wraps your supplied offline HTML app in an Android WebView.
It stores app records locally on the device using WebView localStorage.
Backup saves a JSON file into the device Downloads folder; Restore opens Android's file picker.

BUILD AN APK
1. Install Android Studio on a Windows, Mac, or Linux computer.
2. Open this folder in Android Studio (File > Open).
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location (usually app/build/outputs/apk/debug/app-debug.apk).
6. Transfer that APK to your Android phone and tap it to install. You may need to allow installation from that source.

IMPORTANT
- This environment does not have the Android SDK/Gradle build toolchain, so it cannot compile a real APK here.
- The project is ready to open and build in Android Studio, but this ZIP itself is not an APK.
- Keep regular backups. Clearing app data or uninstalling can erase locally stored records.
