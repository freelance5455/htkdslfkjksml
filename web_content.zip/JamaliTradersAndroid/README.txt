JAMALI TRADERS - ANDROID PROJECT

This is an Android Studio project source ZIP, not an installable APK.

Native bill picker:
- The Choose Bill File / Gallery button is handled by Android WebView's file chooser.
- It opens the Android system document/file picker (Downloads, Pictures, Gallery providers, etc.).
- Image files and PDF files are accepted.
- The Open Camera button uses the Android camera permission and native camera intent.

BUILD:
1. Extract this ZIP.
2. Open the JamaliTradersAndroid folder in Android Studio.
3. Allow Gradle sync to finish.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the generated APK on the phone and test both buttons.

IMPORTANT:
This source package has not been compiled or tested on a physical Android phone here.
The installed APK must be tested on the target device. If the app was previously installed,
back up your app data before uninstalling or replacing it.
