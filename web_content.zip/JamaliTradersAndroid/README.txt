JAMALI TRADERS ANDROID PROJECT — UPDATED

Updated entry behavior:
- Weight In / Weight Out are for cotton only and use KG.
- Atom In / Atom Out are for fertilizer, seed, medicine and other shop items.
- Atom quantity uses units such as Bag, Packet, Bottle, Piece, Carton or Other, not KG.
- Payment entries do not show item quantity fields.
- Existing saved records remain compatible; older Atom records without a unit remain readable.

Build APK:
1. Open this project in Android Studio.
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Transfer app/build/outputs/apk/debug/app-debug.apk to your Android phone.

This environment does not have Android SDK/Gradle build tools, so this is an Android Studio project, not a compiled APK.
