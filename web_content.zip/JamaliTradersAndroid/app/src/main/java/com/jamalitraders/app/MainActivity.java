package com.jamalitraders.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private static final int CAMERA_REQUEST = 4102;
    private static final int CAMERA_PERMISSION = 4103;
    private static final int FILE_REQUEST = 4104;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private Uri capturedImageUri;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        webView.addJavascriptInterface(new NativeBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    // Use Android's native document picker so the user can browse
                    // Downloads, Pictures, Gallery providers, and other file sources.
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "application/pdf"});
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    try {
                        startActivityForResult(intent, FILE_REQUEST);
                    } catch (Exception noDocumentsProvider) {
                        // Compatibility fallback for devices without ACTION_OPEN_DOCUMENT.
                        Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
                        fallback.addCategory(Intent.CATEGORY_OPENABLE);
                        fallback.setType("*/*");
                        fallback.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "application/pdf"});
                        startActivityForResult(Intent.createChooser(fallback, "Select bill file"), FILE_REQUEST);
                    }
                } catch (Exception e) {
                    finishFileChooser(null);
                    Toast.makeText(MainActivity.this, "File Manager open nahi ho saka. Dobara koshish karein.", Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class NativeBridge {
        @JavascriptInterface public void takeBillPhoto() {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
                } else launchCamera();
            });
        }
    }

    private void launchCamera() {
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "JamaliBill_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            capturedImageUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            camera.putExtra(MediaStore.EXTRA_OUTPUT, capturedImageUri);
            camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(camera, CAMERA_REQUEST);
        } catch (Exception e) {
            capturedImageUri = null;
            Toast.makeText(this, "Camera open nahi ho saka: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == CAMERA_PERMISSION) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) launchCamera();
            else Toast.makeText(this, "Camera permission allow karein", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_REQUEST) {
            Uri[] result = null;
            if (resultCode == Activity.RESULT_OK) result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            finishFileChooser(result);
        } else if (requestCode == CAMERA_REQUEST) {
            if (resultCode == Activity.RESULT_OK && capturedImageUri != null) {
                try {
                    InputStream in = getContentResolver().openInputStream(capturedImageUri);
                    Bitmap bitmap = BitmapFactory.decodeStream(in);
                    if (in != null) in.close();
                    if (bitmap == null) throw new Exception("Image read nahi hui");
                    int max = 1600;
                    int w = bitmap.getWidth(), h = bitmap.getHeight();
                    float scale = Math.min(1f, (float) max / Math.max(w, h));
                    if (scale < 1f) bitmap = Bitmap.createScaledBitmap(bitmap, Math.round(w * scale), Math.round(h * scale), true);
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 78, out);
                    String b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                    String js = "window.onNativeCameraResult && window.onNativeCameraResult('data:image/jpeg;base64," + b64 + "')";
                    webView.post(() -> webView.evaluateJavascript(js, null));
                } catch (Exception e) {
                    Toast.makeText(this, "Bill photo read nahi ho saki", Toast.LENGTH_LONG).show();
                }
            } else if (capturedImageUri != null) {
                try { getContentResolver().delete(capturedImageUri, null, null); } catch (Exception ignored) {}
            }
            capturedImageUri = null;
        }
    }

    private void finishFileChooser(Uri[] result) {
        if (fileCallback != null) { fileCallback.onReceiveValue(result); fileCallback = null; }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
