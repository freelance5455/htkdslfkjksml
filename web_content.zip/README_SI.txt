IMPACT PLUS – Android APK Build ZIP

මෙම ZIP එකේ Android Studio project එකක් සහ ඔබ එවූ මුල් screenshot වලට සමාන teal/white mobile web UI එකක් ඇතුළත්ය.
Android app එක offline HTML asset එක WebView තුළ විවෘත කරයි. දත්ත browser localStorage තුළ තබයි.

මූලික ක්‍රියාකාරීත්වය:
- සමාජ කිහිපයක් සහ සමාජ අනුව වෙන් වූ දත්ත
- ළමයින් එකතු කිරීම/සංස්කරණය/Recycle Bin
- උපන්දිනයෙන් වයස ගණනය
- ස්ත්‍රී/පුරුෂ, MVC සහ RC ස්වාධීන තේරීම්
- සැසි එකතු කිරීම/සංස්කරණය/Recycle Bin
- එක් සැසියකට පැමිණීම සලකුණු කිරීම
- සැසි වාර්තා සහ CSV export
- MVC+RC දෙකම ඇති දරුවා කාණ්ඩ දෙකේම ගණනය කිරීම
- Backup JSON export/import

APK Build:
1. ZIP එක extract කරන්න.
2. Android Studio එකෙන් project folder එක open කරන්න.
3. Gradle Sync කරන්න.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK එක app/build/outputs/apk/debug/app-debug.apk තුළ ලැබේ.

GitHub Actions:
Project එකේ .github/workflows/build-apk.yml workflow එක ඇත. Repository එකට project files upload කර Actions > Build Impact Plus APK > Run workflow තෝරන්න.

වැදගත්:
මෙය මුල් ක්‍රියාකාරී build එකකි; APK එක මෙහි build/test කර නැත. Admin login, PDF export (CSV සහ Android print-to-PDF workaround ඇත), multi-admin permissions සහ Room Database migration/secure cloud sync තවම ඇතුළත් නැත. Data local browser storage තුළයි; app data clear/uninstall කළොත් backup නැති දත්ත නැති විය හැක. සැබෑ දත්ත ඇතුළත් කිරීමට පෙර පරීක්ෂා කර Backup ගන්න.
