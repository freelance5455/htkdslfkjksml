INITIAL TEST TARGET – APKForge HTML/ZIP V1.2
APKForge HTML/ZIP Upload package.
- 2025 Actual vs 2026 Actual comparison
- 2026 Target entry only
- Reporting period: previous month 21st to selected month 20th
- Individual month report with grouped bar chart: 2025 Actual, 2026 Actual, 2026 Target
- Separate annual reports: 2025 Actual only, 2026 Actual only, 2026 Target only
- Separate report chart and monthly table for each selected report type
- Monthly and yearly Print / Save as PDF
- Offline local storage, JSON backup and restore
