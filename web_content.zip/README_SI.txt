INITIAL TEST TARGET – APKForge HTML/ZIP package

මෙය Android source project එකක් නොවේ. APKForge හි HTML/ZIP Upload හෝ HTML App import ක්‍රමයට භාවිත කිරීමට සකස් කළ web app package එකකි.

1. ZIP එක extract නොකර APKForge හි HTML/ZIP Upload තෝරන්න.
2. InitialTestTarget_APKForge.zip තෝරන්න.
3. index.html entry page ලෙස භාවිත කරන්න (අවශ්‍ය නම්).
4. App preview කර APK build කරන්න.

Features: 2025 vs 2026 monthly comparison, 2026 target only, 21st-to-20th reporting periods, offline local storage, print/save PDF, JSON backup/restore, Sinhala/English labels.
