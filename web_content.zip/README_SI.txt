IMPACT PLUS – CLUB MANAGEMENT SYSTEM
Phone APK build pack (v1.1)

Included:
- Android WebView wrapper project (min Android 8.0 / SDK 26)
- Updated Sinhala HTML app in app/src/main/assets/index.html
- GitHub Actions workflow to build a debug APK
- Created by Deneth Hirusha credit in the app header

Build on GitHub:
1. Extract this ZIP.
2. Upload the extracted project contents to the root of your GitHub repository.
3. Open Actions > Build Impact Plus APK > Run workflow.
4. When the workflow succeeds, open its run page > Artifacts > ImpactPlus-debug-APK.
5. Download the artifact ZIP, extract it, then install app-debug.apk on Android.

Important limitations:
- This project is a Kotlin Android WebView wrapper around the included offline HTML app.
- It is not a native Jetpack Compose + Room implementation.
- App data is stored in the WebView browser storage. Use the in-app Backup regularly.
- APK generation has not been executed or verified in this environment; GitHub Actions must complete successfully.


නව යාවත්කාලීන (2026-11-06): වාර්තාවෙන් “මුළු ළමයින්” සහ “මුළු පැමිණීම” තීරු/සාරාංශ ඉවත් කර ඇත. සැසි වාර්තාවේ දිනය පෙන්වයි. පහළ මෙනුවට Home, ළමයින්, සැසි, වාර්තා, Recycle Bin සහ සැකසුම් සඳහා ගැළපෙන සංකේත යොදා ඇත.
සටහන: මෙය Kotlin WebView wrapper ව්‍යාපෘතියකි. APK එක මෙහිදී build කර Android උපාංගයක පරීක්ෂා කර නැත.

භාෂා පහසුකම (v6)
- පළමු වරට App එක විවෘත කරන විට සිංහල / English / தமிழ் තෝරාගන්න.
- පසුව Settings තුළ Language තෝරා භාෂාව වෙනස් කළ හැක.
- තෝරාගත් භාෂාව මෙම උපාංගයේ සුරැකේ.
- මුද්‍රණය / PDF වාර්තාවත් තෝරාගත් භාෂාවෙන් සකස් වේ.


යාවත්කාලීන කිරීම v7: HTML ගොනුව file:// ලෙස Chrome තුළ විවෘත කළ විට IndexedDB නොමැති/අවසර නොලැබෙන අවස්ථාවල localStorage fallback භාවිතා කරයි.


Version 8 update: Added a language selector directly in the top header (Sinhala / English / Tamil), synchronized with Settings. Added guarded language preference storage for browsers where localStorage access is restricted.
