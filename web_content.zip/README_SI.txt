INS Network Android App — Project Package

මෙය Android Studio හරහා APK එකක් build කිරීමට සකස් කළ project source එකයි.
මෙම ZIP එක දැනටමත් install කළ හැකි APK ගොනුවක් නොවේ.

APK එක හදාගන්න:
1. Computer එකක Android Studio install කරන්න.
2. Android Studio තුළ 'Open' තෝරා මෙම ZIP එක extract කළ folder එක විවෘත කරන්න.
3. Gradle sync අවසන් වනතුරු රැඳී සිටින්න.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) තෝරන්න.
5. APK එක app/build/outputs/apk/debug/app-debug.apk යන ස්ථානයෙන් ලැබේ.
6. APK එක Android phone එකට යවා install කරන්න.

සටහන්:
- මෙය offline/local app එකකි. දත්ත phone එකේ browser storage එකේ තබාගනී.
- Phone එක මාරු කිරීම හෝ app data clear කිරීමෙන් දත්ත නැතිවිය හැකි බැවින් backup export කරන්න.
- මෙම version එකට cloud sync, online login හෝ multi-phone sharing ඇතුළත් නොවේ.
- Production release සඳහා signing, testing සහ data backup ක්‍රමය පරීක්ෂා කළ යුතුය.
