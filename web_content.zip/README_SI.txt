RM LOAN MANAGER – APKForge ZIP Package
=====================================

මෙම ZIP එක APKForge වෙත HTML/ZIP source එකක් ලෙස upload කිරීමට සකස් කර ඇත.
ZIP එකේ index.html ගොනුව ප්‍රධාන මට්ටමේ ඇත.

APKForge භාවිතා කරන විට:
1. APKForge වෙබ් අඩවියට පිවිසෙන්න.
2. HTML / ZIP upload ක්‍රමය තෝරන්න.
3. RM_LOAN_MANAGER_APKForge.zip තෝරන්න.
4. App Name: RM LOAN MANAGER
5. Orientation: Portrait
6. Build කර APK එක ලබාගන්න.

ප්‍රධාන පහසුකම්:
- සිංහල අතුරුමුහුණත සහ කළු/රන්වන් ප්‍රධාන තේමාව.
- පළමු වරට ඉලක්කම් 4ක PIN එකක් සකස් කිරීම; පසුව PIN වෙනස් කළ හැකිය.
- පුද්ගලයන්, එක් පුද්ගලයෙකුට ස්වාධීන ණය ගිණුම් කිහිපයක්.
- මාසික ස්ථිර පොලිය 10%; මාසික සංවත්සර දිනයේ ඉතිරි මුල් මුදල මත ගණනය.
- ගෙවීම් පළමුව හිඟ පොලියට අඩු කරයි; ඉතිරිය පමණක් මුල් ණයට අඩු කරයි.
- හිඟ පොලිය මුල් මුදලට එකතු නොකර වෙනම තබා ගනී.
- ගනුදෙනු නවතම දිනය පළමුව ලෙස පෙන්වයි; Edit/Delete කළ විට ගණනය නැවත සිදු වේ.
- මුල් පිටුවේ පොලී ලැයිස්තුව: දින 7–4කට පෙර කොළ, දින 3–1කට පෙර නිල්, ගෙවිය යුතු දිනයේ සිට දින 3ක් දක්වා කහ, ඉන් පසු රතු.
- ගෙවිය යුතු මුදල, දිනය සහ ඉතිරි/ප්‍රමාද දින ගණන පෙන්වයි.
- අවශ්‍ය විට Phone Storage වෙත JSON Backup; අන්තර්ජාලය තිබේ නම් Share මෙනුවෙන් Google Drive වෙත Backup.
- JSON Backup Restore; අවසන් Backup දිනය/වේලාව පෙන්වයි. ස්වයංක්‍රීය Backup නැත.
- PDF ලෙස සුරැකිය හැකි වාර්තා සහ ගෙවීම් රිසිට්පත්.

දත්ත සහ ආරක්ෂාව:
- සාමාන්‍ය භාවිතයේදී දත්ත IndexedDB තුළ දුරකථනයේම ගබඩා වේ; අන්තර්ජාලය අවශ්‍ය නැත.
- Phone Storage Backup සඳහා Download/Files අවසර සහ APKForge WebView හැසිරීම දුරකථනයේ පරීක්ෂා කරන්න.
- Google Drive Backup සඳහා Share මෙනුවෙන් Google Drive තෝරන්න. Drive නොපෙන්වන්නේ නම් JSON ගොනුව Download කර Drive වෙත අතින් Upload කරන්න.
- Restore කිරීමෙන් දැනට ඇති දත්ත Backup ගොනුවේ දත්තවලින් ප්‍රතිස්ථාපනය වේ. Restore කිරීමට පෙර වත්මන් දත්ත Backup කරගන්න.
- පැරණි RANDIKA schema 1 Backup ගොනුද Restore කිරීම සඳහා පිළිගනී.
- පෙර සංස්කරණයේ දත්ත සහ PIN අඛණ්ඩව භාවිතා කළ හැකි වන පරිදි දේශීය database key සහ PIN hash salt නොවෙනස්ව තබා ඇත.

වැදගත්:
මෙය APKForge HTML/ZIP source එකකි. APKForge තුළ APK එක Build කර ස්ථාපනය කළ පසු සැබෑ දුරකථනයේ offline storage, backup/download, Google Drive share, restore, print/PDF, සහ Back navigation ක්‍රියාකාරීත්වය පරීක්ෂා කරන්න.
