RM LOAN MANAGER – APKForge ZIP Package V4
========================================

මෙම ZIP එක APKForge වෙත HTML/ZIP source එකක් ලෙස upload කිරීමට සකස් කර ඇත. ZIP එකේ index.html ගොනුව ප්‍රධාන මට්ටමේ ඇත.

APKForge:
1. HTML / ZIP upload තෝරන්න.
2. RM_LOAN_MANAGER_APKForge_V4.zip තෝරන්න.
3. App Name: RM LOAN MANAGER; Orientation: Portrait.
4. Build කර APK එක ලබාගන්න.

ප්‍රධාන පහසුකම්:
- සිංහල UI, කළු/රන්වන් තේමාව සහ අඳුරු Date Picker.
- පළමු වරට 4-digit PIN; PIN වෙනස් කිරීම; වෙනම 4-digit Special Authorization Code.
- පුද්ගල නම/දුරකථනය සහ එක් පුද්ගලයෙකුට ස්වාධීන ණය කිහිපයක්.
- ස්ථිර මාසික පොලිය 10%, ඉතිරි මුල් මුදල මත මාසික සංවත්සර දිනයේ ගණනය.
- ගෙවීම් පළමුව හිඟ/නියමිත පොලියට; ඉතිරිය පමණක් මුල් ණයට. හිඟ පොලිය මුල් මුදලට එකතු නොවේ.
- ගෙවීම් Edit/Delete සහ නැවත ගණනය; Delete සඳහා PIN තහවුරු කිරීම.
- සක්‍රිය ණය, සම්පූර්ණ කළ ණය Archive සහ විශේෂ අවසරයෙන් හිඟය ඉතිරිව තිබියදී Archive කිරීම.
- Dashboard: මෙම මාසයේ පොලී එකතුව පමණක්; arrears මුදල Dashboard එකේ නොපෙන්වයි.
- ගෙවිය යුතු දිනයට දින 7කට පෙර සිට due list සහ වර්ණ සලකුණු.
- එක් එක් ගෙවීමේ වෙනම රිසිට්පත; ණය/පුද්ගල වාර්තා Print > Save as PDF.
- PDF සුරැකූ පසු Android Files/Downloads වෙතින් WhatsApp, Bluetooth හෝ වෙනත් App එකකට Share කරන්න.
- Manual JSON Backup/Restore. Phone Storage Backup offline; Google Drive සඳහා internet අවශ්‍ය වේ. Automatic Backup නැත.
- Backup Share බොත්තම Android Share Sheet භාවිත කරයි; Share Sheet සහාය නැතිනම් Download fallback.
- Phone Back: Loan Details → Customer Details → Dashboard. Dashboard හිදී Exit Confirmation පෙන්වයි. Cordova backbutton, browser history සහ Escape/Backspace fallback එකතු කර ඇත.

දත්ත අඛණ්ඩතාව:
- පෙර සංස්කරණවල IndexedDB database name සහ PIN hash salt නොවෙනස්ව තබා ඇත.
- පැරණි Backup schema 1, 2, 3 Restore සඳහා පිළිගනී.
- APK update කිරීමට පෙර Settings > Backup හරහා JSON Backup එකක් අනිවාර්යයෙන් ගන්න. APKForge වෙනම WebView origin එකක් ලබාදුන්නොත් පැරණි දත්ත Restore කළ යුතු විය හැක.

සීමාවන් / පරීක්ෂණ:
- PDF නිර්මාණය WebView/Android Print > Save as PDF මඟින් සිදු වේ; සුරැකුණු PDF එක Files වෙතින් Share කළ හැක.
- Google Drive සෘජු API sync එකක් නොවේ; Android Share Sheet හරහා Drive වෙත යවයි, නැතිනම් Download කර Drive වෙත Upload කරන්න.
- APKForge build සහ HONOR 400 Android 16 මත Back, download, share, restore, offline persistence, print/PDF ක්‍රියාකාරීත්වය තවමත් සැබෑ දුරකථනයේ පරීක්ෂා කර නැත.
- HTML WebView එකකට App එක බලෙන් terminate කිරීමේ Android-native හැකියාවක් නැත. Exit Confirmation පෙන්වයි; host WebView `window.close()` ඉඩ නොදෙන්නේ නම් Recent Apps භාවිතා කර වසන්න.
