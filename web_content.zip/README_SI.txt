YouTube Web-to-APK Project (HTML ZIP)

Files:
- index.html: main mobile-friendly app page

How to use:
1. Upload this ZIP to your HTML-to-APK / Web-to-APK builder if it accepts ZIP projects.
2. Set index.html as the start page if the builder asks.
3. Enable Internet access / network permission.
4. Build the APK and test it on your Android phone.

Important limitations:
- The supplied URL https://m.youtube.com/ is the YouTube homepage, not a specific video URL.
- YouTube may block its homepage from loading inside an iframe. The Open YouTube button navigates to m.youtube.com in the app WebView where the builder supports it.
- The built-in player accepts a specific YouTube video URL and uses YouTube's official embed player. Some videos do not allow embedding.
- The Home button hides the player section without removing its iframe, so an allowed embedded video may continue while navigating within this HTML app.
- This HTML-only project cannot guarantee audio/video playback after leaving the WebView, switching to another app, locking the screen, or closing the app. Reliable background playback requires native Android foreground-media playback support and is also subject to YouTube's terms and playback restrictions.
- For best results, use a Web-to-APK builder that keeps one WebView alive and does not reload index.html on internal navigation.
