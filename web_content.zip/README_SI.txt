RANDIKA – APKForge ZIP Package
================================

මෙම ZIP එක APKForge වෙත HTML/ZIP source එකක් ලෙස upload කිරීමට සකස් කර ඇත.

ZIP එකේ index.html ගොනුව ප්‍රධාන මට්ටමේ ඇත.

APKForge භාවිතා කරන විට:
1. APKForge වෙබ් අඩවියට පිවිසෙන්න.
2. HTML / ZIP upload ක්‍රමය තෝරන්න.
3. RANDIKA_APKForge.zip තෝරන්න.
4. App Name: RANDIKA
5. Orientation: Portrait
6. Build කර APK එක ලබාගන්න.

පළමු වරට App එක විවෘත කරන විට ඉලක්කම් 4ක PIN එකක් සකසන්න.

සටහන්:
- දත්ත IndexedDB තුළ දුරකථනයේම ගබඩා වේ.
- Google Drive Backup බොත්තම Android Share මෙනුව හරහා Drive තෝරාගැනීමට උත්සාහ කරයි. එය නොලැබුණොත් JSON ගොනුව Download කර Google Drive වෙත අතින් Upload කරන්න.
- PDF වාර්තා මුද්‍රණ කවුළුව හරහා Save as PDF තෝරා සුරකින්න. APKForge WebView එකේ print පහසුකම දුරකථනයේ පරීක්ෂා කළ යුතුය.
- මාසික පොලිය 10% ස්ථිරයි. පොලිය සෑම මාසික සංවත්සර දිනයකම ඉතිරි මුල් මුදල මත ගණනය වේ. නොගෙවූ පොලිය මුල් මුදලට එකතු නොවේ.
- ගෙවීම් මුලින් හිඟ පොලියට අඩු කරයි; ඉතිරි මුදල පමණක් මුල් ණයෙන් අඩු කරයි.
- ගනුදෙනු Edit/Delete කිරීමෙන් පසු අදාළ ණය ගණනය නැවත සිදු වේ.

මෙය පළමු ක්‍රියාකාරී ZIP අනුවාදයයි. APKForge තුළ build කර ස්ථාපනය කිරීමෙන් පසු offline, backup/restore, share, සහ print ක්‍රියාකාරීත්වය සැබෑ දුරකථනයේ තවදුරටත් පරීක්ෂා කළ යුතුය.
