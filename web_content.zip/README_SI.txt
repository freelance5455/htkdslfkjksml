INS NETWORK HTML App

භාවිතා කරන ආකාරය:
1. INS_NETWORK.html file එක Android phone එකට download කරගන්න.
2. File Manager එකෙන් එය open කර Chrome වැනි browser එකකින් විවෘත කරන්න.
3. Dashboard එකෙන් balance බලන්න; tabs මඟින් Projects, Income, Expenses, Workers, Advances, Bank In සහ Bank Out එකතු කරන්න.
4. Dashboard > Export Backup මඟින් JSON backup එකක් වරින් වර ගන්න.

Balance logic:
Cash Balance (estimated) = Income - Expenses - Advances
Bank Balance (estimated) = Bank In - Bank Out
Overall Balance (estimated) = Cash Balance + Bank Balance

වැදගත්:
- මෙය HTML browser app එකක්; Android APK එකක් නොවේ.
- දත්ත එම browser එකේ localStorage තුළ පමණක් සුරැකේ.
- Browser data clear කළොත් දත්ත නැතිවිය හැක. Backup ගන්න.
- Cash/Bank ගණනය තවම සරලයි. Cash එකෙන් bank එකට මාරු කරන transaction එකක් දෙපැත්තෙන් සටහන් කළහොත් overall balance වැරදි විය හැක; එවැනි transfer category එකක් වෙනම එක් කළ යුතුය.
