# Build SHAikh ERP APK

1. Install Android Studio.
2. Open this folder as an existing Android Studio project.
3. Let Gradle sync.
4. Select **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will generate the APK under:
   `app/build/outputs/apk/debug/`

This project wraps the included ERP web UI as an Android app.
For production release, create a release keystore and sign the APK.
