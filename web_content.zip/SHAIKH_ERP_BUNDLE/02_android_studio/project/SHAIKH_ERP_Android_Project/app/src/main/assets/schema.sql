CREATE TABLE users (
 id UUID PRIMARY KEY, username VARCHAR(80) UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, role VARCHAR(30) NOT NULL,
 active BOOLEAN NOT NULL DEFAULT TRUE, created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE TABLE parties (
 id UUID PRIMARY KEY, party_type VARCHAR(10) NOT NULL, name TEXT NOT NULL,
 gstin VARCHAR(15), state_code VARCHAR(2), phone TEXT, email TEXT, address TEXT
);
CREATE TABLE box_products (
 id UUID PRIMARY KEY, sku VARCHAR(80) UNIQUE NOT NULL, name TEXT NOT NULL,
 length_mm NUMERIC(12,2), width_mm NUMERIC(12,2), height_mm NUMERIC(12,2),
 ply INTEGER, paper_cost NUMERIC(14,4) DEFAULT 0, wastage_pct NUMERIC(8,3) DEFAULT 0,
 printing_cost NUMERIC(14,4) DEFAULT 0, conversion_cost NUMERIC(14,4) DEFAULT 0,
 labour_overhead NUMERIC(14,4) DEFAULT 0, profit_pct NUMERIC(8,3) DEFAULT 0,
 gst_rate NUMERIC(8,3) DEFAULT 0
);
CREATE TABLE invoices (
 id UUID PRIMARY KEY, invoice_no VARCHAR(40) UNIQUE NOT NULL,
 party_id UUID REFERENCES parties(id), invoice_date DATE NOT NULL,
 taxable_value NUMERIC(16,2) NOT NULL, cgst NUMERIC(16,2) DEFAULT 0,
 sgst NUMERIC(16,2) DEFAULT 0, igst NUMERIC(16,2) DEFAULT 0,
 total_value NUMERIC(16,2) NOT NULL, status VARCHAR(20) DEFAULT 'POSTED',
 created_by UUID REFERENCES users(id), created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE TABLE inventory_items (
 id UUID PRIMARY KEY, sku VARCHAR(80) UNIQUE NOT NULL, name TEXT NOT NULL,
 unit VARCHAR(20) NOT NULL, qty NUMERIC(18,3) DEFAULT 0,
 reorder_level NUMERIC(18,3) DEFAULT 0
);
CREATE TABLE stock_movements (
 id UUID PRIMARY KEY, item_id UUID REFERENCES inventory_items(id),
 movement_type VARCHAR(5) NOT NULL, qty NUMERIC(18,3) NOT NULL,
 reference_type VARCHAR(30), reference_id UUID, created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE TABLE journal_entries (
 id UUID PRIMARY KEY, entry_date DATE NOT NULL,
 reference_type VARCHAR(30), reference_id UUID, narration TEXT
);
CREATE TABLE journal_lines (
 id UUID PRIMARY KEY, journal_id UUID REFERENCES journal_entries(id) ON DELETE CASCADE,
 account_code VARCHAR(40) NOT NULL, debit NUMERIC(16,2) DEFAULT 0,
 credit NUMERIC(16,2) DEFAULT 0
);
