function calculateBoxCost(i) {
 const paper=+i.paperCost||0, waste=(+i.wastagePct||0)/100;
 const manufacturing=paper*(1+waste)+(+i.printingCost||0)+(+i.conversionCost||0)+(+i.labourOverhead||0);
 const selling=manufacturing*(1+(+i.profitPct||0)/100);
 const gst=selling*((+i.gstRate||0)/100);
 const q=+i.quantity||0;
 return {manufacturingCost:manufacturing,sellingBeforeGst:selling,gstAmount:gst,
 sellingIncludingGst:selling+gst,orderValueBeforeGst:selling*q,
 orderGst:gst*q,orderGrandTotal:(selling+gst)*q};
}
module.exports={calculateBoxCost};
