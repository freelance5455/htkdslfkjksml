# SHAIKH ERP — Production Starter
Database-ready architecture for corrugated-box manufacturing ERP.

Modules: secure login, roles, box costing, customers/vendors, GST invoice structure,
inventory, double-entry accounting, reports, backup/restore and GST integration adapter.

This is a production starter, not a live hosted accounting service. Live GST API access
must be connected to an authorised/current provider and validated before use.
