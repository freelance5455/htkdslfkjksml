# Production checklist
- PostgreSQL + schema
- HTTPS
- Argon2id/bcrypt password hashing
- Server-side role authorization and rate limiting
- Current authorised GST/HSN provider
- Automated daily backup + tested restore
- Audit trail for financial changes
- Balanced double-entry journals
- Accountant/tax-professional verification before GST filing
