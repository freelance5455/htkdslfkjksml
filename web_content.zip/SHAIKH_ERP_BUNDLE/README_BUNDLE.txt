SHAIKH ERP - SOURCE BUNDLE
==========================

This bundle contains the current SHAikh ERP prototype/source files created during the project.

01_latest_web_app
- SHAIKH_ERP_Box_Costing_Print_2Part.html : latest costing variant with manual total printing rate divided by box quantity and 1/2 part selector.
- SHAIKH_ERP_Multi_Company.html : multi operating company management.
- SHAIKH_ERP_Final_Dashboard.html : dashboard version.
- SHAIKH_ERP_Final_Standard_Invoice.html : standard GST invoice UI version.
- SHAIKH_ERP_Box_Costing_Print_Lamination.html : printing/lamination costing version.

02_android_studio
- Android Studio starter project and ZIP.
- WebView-based starter; open the project folder in Android Studio and build APK.

03_production_starter
- PostgreSQL starter schema, costing engine, API contract and deployment checklist.

04_previews
- Dashboard, invoice and ERP UI preview images.

IMPORTANT STATUS
----------------
The lifetime/unlimited year-wise database feature was specified but could not be written into a new file in the last tool attempt because the file-generation tool was temporarily rate-limited. Therefore this bundle does NOT claim that the lifetime year-wise SQLite implementation is complete.

For a true production app with long-term storage, use SQLite/Room (Android) or a server database, and store financialYear + companyId on every transaction.

The Android project is a starter and may require Gradle/SDK setup and final integration before production APK release.
