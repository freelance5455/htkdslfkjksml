FIRUZ HISAB BOOK - ANDROID PROJECT

Is ZIP mein Android Studio project ka source code hai. Yeh APK file nahi hai.

APK banane ke liye:
1. Computer par Android Studio install karein.
2. ZIP extract karein.
3. Android Studio > Open > extracted FiruzHisabBook folder select karein.
4. Gradle sync complete hone dein (internet pehli baar dependencies download karne ke liye chahiye).
5. Build > Build Bundle(s) / APK(s) > Build APK(s) select karein.
6. APK Android Studio ke app/build/outputs/apk/debug/ folder mein milega.
7. APK ko phone mein bhej kar install karein. Zarurat pade to Android settings mein is source se install allow karein.

FEATURES:
- Income aur expense entries
- Automatic total income, expense aur balance
- Daily, weekly, monthly aur all-time reports
- Entry date aur description
- Entry delete
- JSON backup aur restore
- Entries phone ke local WebView storage mein save hoti hain; app data clear/uninstall karne se pehle backup banayein.

Package: com.firuz.hisabbook
Version: 1.0
Minimum Android: 6.0 (API 23)
