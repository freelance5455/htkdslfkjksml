BHARATI DRESSES — ADMIN LOGIN PACKAGE

Files included:
- index.html — public storefront
- admin.html — admin login and product management page
- style.css — site styling
- script.js — storefront product scripts

HOW TO ADD PRODUCTS
1. Upload all four files to the SAME hosting folder (keep the filenames unchanged).
2. Open https://YOUR-DOMAIN/admin.html (replace YOUR-DOMAIN with your real hosting domain).
3. Sign in using an admin user created in Firebase Authentication (Email/Password). This ZIP does not create a Firebase account or set a password for you.
4. If login succeeds but says unauthorized, open admin.html and check ADMIN_UID against the UID shown for your admin user in Firebase Authentication.
5. In Firebase Console, enable Authentication > Sign-in method > Email/Password and create the admin user under Authentication > Users.
6. Configure Firestore security rules to permit writes only to that admin UID. A browser-side UID check alone is not secure.
7. In the admin form, enter the product name, price, category, image URL, description and affiliate URL, then save. This version uses an image URL; upload the image to a trusted image host first.

IMPORTANT
- Uploading files to Blogger is not the same as uploading to a static website host. If you are using Blogger, these HTML files cannot simply be uploaded as a ZIP to create a working site.
- Verify that the Firebase project configuration in admin.html and index.html belongs to your project.
- The ZIP archive was checked, but a live Firebase login/product upload cannot be verified without access to your Firebase project and hosting.
