PrivateVault PRO setup

This ZIP is a frontend prototype for the next version.
It includes:
- Terms & Conditions acceptance before login
- Username + password and optional 6-digit PIN
- Photos/videos/files picker
- Vault file list and local previews
- Storage usage
- Admin dashboard demo

IMPORTANT:
The real requirement "I (admin) can see users' uploaded files and storage from another phone" requires a cloud backend.
This prototype does NOT secretly send user files anywhere.

Recommended production backend:
- Supabase Auth for accounts
- Supabase Storage for encrypted/private files
- Database table for user profiles, file metadata and storage usage
- Row Level Security so users can access only their own data
- A server-side admin role so the authorized owner/admin can view users and files
- Privacy Policy/Terms explicitly disclose that authorized admins may access stored content

Do NOT put an admin master password inside the APK in the production version.
