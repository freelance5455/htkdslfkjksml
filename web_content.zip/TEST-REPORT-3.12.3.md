# RISEUP 3.12.3 — Rank unlocks by level

## Implemented
- No rank is displayed or awarded at levels 1–2.
- Rank E unlocks at level 3.
- Rank D unlocks at level 6.
- Rank C unlocks at level 9.
- Rank B unlocks at level 12.
- Rank A unlocks at level 15.
- Rank S unlocks at level 18.
- Rank rewards are granted only up to the eligible rank; previously auto-granted higher-rank rewards are reconciled against the current level.
- Rank-gated dungeon progression uses the same thresholds.
- Existing player XP, tasks, goals, weekly streak, and spiritual path logic were not intentionally changed.

## Automated checks
- `npm run test:static` — PASS
- `npm run test:pwa` — PASS
- `npm run test:gameplay` — PASS

## Limitations
- Not tested on a physical Android device or inside the user's APK wrapper.
