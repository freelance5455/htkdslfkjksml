import { clone, mergeState } from './storage.js';

export function createBackup(state) {
  return { format: 'tagklar-backup', version: 1, exportedAt: new Date().toISOString(), data: clone(state) };
}

export function downloadBackup(state) {
  const blob = new Blob([JSON.stringify(createBackup(state), null, 2)], { type: 'application/json' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `tagklar-backup-${new Date().toISOString().slice(0, 10)}.json`;
  link.click();
  URL.revokeObjectURL(link.href);
}

export async function readBackup(file) {
  const parsed = JSON.parse(await file.text());
  if (parsed?.format !== 'tagklar-backup' || !parsed.data) throw new Error('invalid backup');
  return mergeState(parsed.data);
}

