# JARYAN Capture Workbench V1 — Android Build Bundle

This is the **source-of-truth Android project** intended to produce an APK. It is not a documentation-only handoff.

## Required environment
- Android Studio current stable release
- JDK 17
- Android SDK Platform 35
- Android SDK Build-Tools 35.x
- Internet access for the first Gradle dependency sync

## Build with Android Studio
1. Extract this folder.
2. Open the folder containing `settings.gradle.kts` as the Android Studio project.
3. Let Gradle sync.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Run `app`.
6. For an APK: `Build > Generate App Bundles or APKs > Generate APKs`.

## Build from terminal
Linux/macOS:
```bash
./gradlew clean assembleDebug
```
Windows:
```bat
gradlew.bat clean assembleDebug
```
Output:
`app/build/outputs/apk/debug/app-debug.apk`

## What is implemented natively
- Kotlin + Jetpack Compose UI
- Runtime camera + microphone permission request
- CameraX Preview
- CameraX ImageCapture → MediaStore JPEG
- CameraX VideoCapture → MediaStore MP4
- Camera2 capability discovery
- Sensor discovery
- Pen library model
- Workbench navigation
- Explicit status/error messages

## What is not falsely marked complete
- Native Light Painting temporal renderer
- IMU-synchronized making-video reconstruction
- AI Director execution engine
- RAW/DNG final evidence path
- External hardware drivers
- Physical Redmi Note 13 Pro validation

Those are separate runtime gates and should only be marked complete after implementation and device testing.
