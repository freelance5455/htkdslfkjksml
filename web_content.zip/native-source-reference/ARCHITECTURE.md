# Architecture

World → Hardware → Capture → Workbench Runtime → Interpretation → Artifact.

## Runtime
Registry / Capability Engine / Port Graph / Router / Command Validator / Session Manager / Provenance.

## Performance
Prefer streaming pipelines, bounded queues, frame dropping under backpressure, GPU work for pixel operations, no unbounded frame retention, release ImageProxy/Buffer resources promptly, and stop analysis workers when their action is inactive.

## Security
Request camera/mic/notification permissions at point of use. Do not request storage broad access. Keep exported surface minimal. Treat AI commands as untrusted input; validate capability, parameter ranges and permission scope before execution.
