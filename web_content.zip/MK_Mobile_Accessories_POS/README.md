# MK Mobile Accessories POS — ZIP Project

## Included
- `index.html` — responsive offline-first POS app
- `manifest.json` — PWA metadata
- `sw.js` — caches local app files for supported browser/PWA use
- `assets/mk-icon.svg` — app icon

## Current features
- Dashboard: today's sales, estimated profit, stock count and customer due
- Product inventory: add/edit/delete products, purchase cost, selling price, stock and low-stock threshold
- Billing/cart: quantities, discount, payment received, balance due and automatic stock deduction
- Customer records and ledger: record due/credit and payments received
- Sales history and CSV export
- JSON backup/restore
- Shop details for invoices
- WhatsApp share: opens WhatsApp with a prefilled bill-text message and, when a phone number is present, targets that number
- Print / Save as PDF: uses the device/browser print dialog where supported
- English/Urdu/Pashto language selector (the navigation labels are translated; not every field label is translated yet)

## Important data note
Data is stored in the browser's local storage on that device. Export JSON backups regularly. Clearing browser/app data or uninstalling a wrapper may delete records. This is not a cloud-sync database.

## Run on a phone
1. Extract this ZIP.
2. Open `index.html` in a mobile browser or a local HTML preview app.
3. For best offline PWA behavior, host the files on HTTPS or use a wrapper that loads the local files. Service workers do not run from every `file://` preview.

## Build an APK
This is a plain HTML/JavaScript project, not a precompiled APK.
1. Extract the ZIP on your phone.
2. Use an Android WebView/HTML-to-APK builder that allows you to import a ZIP or local HTML assets and enables JavaScript.
3. Set the start page to `index.html`.
4. Include `manifest.json`, `sw.js`, and the `assets` folder if the builder supports them.
5. Enable file downloads if you want backup/CSV export, and enable external links/intents so WhatsApp opens.
6. Build a test APK and install it.
7. Test: add product → create sale → verify stock falls → tap WhatsApp Share → verify the message is prefilled. Test print/PDF and backup/restore too.

## WhatsApp behavior and limitations
- WhatsApp sharing uses a `wa.me` URL with encoded bill text. It opens WhatsApp/web and pre-fills the message; the user must tap Send.
- A web link cannot silently send messages or force an attachment. To send a PDF invoice as a WhatsApp attachment, the wrapper must support Android share intents / Web Share API with file sharing. This version offers Print / Save PDF as a practical fallback.
- A phone number may need country code formatting; Pakistani numbers beginning with `03` are converted to `92` for the WhatsApp URL.

## Before real shop use
This project is a usable starter, but test it with sample transactions first. It does not yet include user login, multi-device synchronization, tax/FBR integration, barcode camera scanning, or cloud backup.
