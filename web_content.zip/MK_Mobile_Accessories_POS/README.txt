MK Mobile Accessories POS — Starter Project
=============================================

Features
- 5 pages: Dashboard, Products, Billing, Udhaar Ledger, Reports
- Add products, categories, cost/sale prices, stock quantity
- Upload a product picture from your phone
- Create bills, record paid/partial/credit amounts
- Customer-wise remaining udhaar and payment receiving
- Sales/profit summary and JSON backup/restore
- Offline-friendly single HTML file; records are stored in this browser's localStorage

Open on Android
1. Extract this ZIP using your phone's Files app.
2. Open index.html in Acode.
3. In Acode, open Preview (or use a local preview option). If preview doesn't open, open index.html in Chrome.
4. Add products and test a bill.

Important
- This is a starter web POS, not a signed APK yet.
- Data is saved in the browser storage on this device. Clearing browser/app data may erase it.
- Download Backup regularly from Products or Reports.
- Product pictures are stored in browser storage; very large pictures may use a lot of space.
- Before using for real shop accounting, test calculations and keep backup copies.
