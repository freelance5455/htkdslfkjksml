MK MOBILE ACCESSORIES POS — STARTER PROJECT

Included:
- index.html: offline-first POS app
- manifest.json: installable web app metadata
- icon.svg: simple app icon
- README.txt: build/use guide

Features:
- Empty product list (no demo products)
- Product/stock management, low-stock indicators
- Billing with cash, credit and partial payments
- Automatic stock deduction on saved bill
- Credit ledger and payment collection
- Sales, cost and estimated gross profit reports
- JSON backup/restore and CSV export
- English, Urdu and Pashto UI labels
- Shop details for receipts; print bill using browser print dialog

IMPORTANT DATA NOTE:
The app stores data in localStorage on the device/browser profile. It is not cloud synced.
Export a JSON backup regularly. Clearing browser/app data or uninstalling a packaged app may erase data.
Test restore using a copy of your backup before relying on it for business.

USE ON ANDROID:
1. Extract ZIP on your phone or computer.
2. Open index.html in Chrome to test. For better offline installation, serve it through a local web server or package it with a WebView wrapper.
3. To make an APK on mobile, use a reputable HTML-to-APK/WebView packaging service or a trusted Android IDE/build environment that supports loading local assets. Import the index.html and its assets into the app's local assets folder and point the WebView to file:///android_asset/index.html.
4. Enable JavaScript and DOM storage in the WebView. Keep app data storage enabled. Do not use a wrapper that uploads customer data to an unknown server.
5. Build a debug APK, install it, test product add/edit, a test sale, credit payment, backup and restore. Only then use it for real transactions.
6. Future Play Store publishing generally requires an Android App Bundle (.aab), developer account, privacy policy, app icon/screenshots and current Play policy compliance. APK and AAB are different outputs.

MOBILE-FRIENDLY WEBVIEW SETTINGS (for whoever builds the wrapper):
- JavaScript enabled
- DOM storage enabled
- Local content access enabled
- Start URL: file:///android_asset/index.html
- No internet permission is needed for core POS functionality
- Use a maintained Android WebView and target the current Play requirements

ACCOUNTING NOTE:
Gross profit = sale total minus the saved cost of the sold products. It does not include shop expenses, taxes, returns or damaged goods. This is a starter project, not audited accounting software. Keep backups and reconcile cash/stock.
