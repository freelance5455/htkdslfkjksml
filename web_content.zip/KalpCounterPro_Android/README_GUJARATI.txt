Kalp Counter Pro - Android Studio Project

આ Android Studio project છે; તૈયાર APK નથી.

APK બનાવવા માટે:
1. કમ્પ્યુટરમાં Android Studio ઇન્સ્ટોલ કરો.
2. Android Studio માં આ ZIP extract કર્યા પછી Open દ્વારા KalpCounterPro folder ખોલો.
3. Gradle sync પૂર્ણ થવા દો અને જરૂરી Android SDK download/install થવા દો.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) પસંદ કરો.
5. APK app/build/outputs/apk/debug/app-debug.apk માં મળશે.

એપમાં 8 Counter, નામ બદલી શકવાની સુવિધા, Submit પછી Credit ઉમેરવું, current count શૂન્ય કરવો, date/time History અને CSV export છે.
ડેટા આ એપના WebView local storage માં રહે છે. એપ uninstall અથવા app data clear કરવાથી ડેટા મટી શકે છે; સમયાંતરે CSV export કરીને બેકઅપ રાખો.
