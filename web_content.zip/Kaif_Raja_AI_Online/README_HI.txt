Kaif Raja AI Chat GPT — Online AI प्रोजेक्ट

यह ZIP तैयार वेब-ऐप + सर्वर कोड है। असली AI जवाब पाने के लिए सर्वर पर API Key सेट करनी और इसे इंटरनेट पर deploy करना जरूरी है। API Key को HTML या ZIP में न डालें।

आसान बातें:
- index.html को अकेले खोलने पर असली AI जवाब नहीं आएगा; सर्वर चलना जरूरी है।
- Node.js 18 या नया संस्करण चाहिए।
- यह प्रोजेक्ट OpenAI-compatible Chat Completions API इस्तेमाल करता है।

कंप्यूटर/होस्टिंग पर चलाने के चरण:
1. ZIP Extract करें।
2. Node.js 18+ इंस्टॉल करें।
3. टर्मिनल में इस फ़ोल्डर में जाएँ।
4. API Key को environment variable में सेट करें, फ़ाइल में नहीं:
   Linux/macOS: export OPENAI_API_KEY='अपनी_API_KEY'
   Windows PowerShell: $env:OPENAI_API_KEY='अपनी_API_KEY'
5. चलाएँ: node server.js
6. ब्राउज़र में खोलें: http://localhost:3000

मॉडल बदलना हो तो OPENAI_MODEL सेट करें (डिफ़ॉल्ट: gpt-4o-mini)।

महत्वपूर्ण:
- API Key अलग से लेनी होगी; यह ZIP में शामिल नहीं है।
- API प्रदाता की कीमत/कोटा लागू हो सकता है।
- ऑनलाइन इस्तेमाल के लिए सर्वर को सार्वजनिक HTTPS होस्टिंग पर deploy करें।
- Android APK नहीं; यह वेब ऐप प्रोजेक्ट है।
- वॉइस और फोटो अपलोड इस संस्करण में अभी शामिल नहीं हैं।
