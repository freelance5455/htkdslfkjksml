const http = require('http');
const fs = require('fs');
const path = require('path');
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || 'gpt-4o-mini';
const ROOT = path.join(__dirname, 'public');
const mime = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8'};
const server = http.createServer(async (req,res) => {
  res.setHeader('X-Content-Type-Options','nosniff');
  if (req.url === '/api/chat' && req.method === 'POST') {
    if (!API_KEY) { res.writeHead(503, {'Content-Type':'application/json; charset=utf-8'}); return res.end(JSON.stringify({error:'AI API Key सेट नहीं है। README_HI.txt देखें।'})); }
    let raw=''; req.on('data', c => { raw += c; if (raw.length > 100000) req.destroy(); });
    req.on('end', async () => {
      try {
        const body=JSON.parse(raw); const messages=Array.isArray(body.messages)?body.messages.slice(-16):[];
        if (!messages.length) throw new Error('कृपया पहले सवाल लिखें।');
        const upstream=await fetch('https://api.openai.com/v1/chat/completions', {method:'POST',headers:{'Authorization':'Bearer '+API_KEY,'Content-Type':'application/json'},body:JSON.stringify({model:MODEL,messages:[{role:'system',content:'You are Kaif Raja AI Chat GPT. Answer helpfully and accurately. Reply in Hindi when the user writes Hindi. If unsure, say so.'},...messages],temperature:0.7})});
        const data=await upstream.json();
        if (!upstream.ok) { res.writeHead(upstream.status,{'Content-Type':'application/json; charset=utf-8'}); return res.end(JSON.stringify({error:data.error?.message || 'AI सेवा से जवाब नहीं मिला।'})); }
        res.writeHead(200,{'Content-Type':'application/json; charset=utf-8'}); res.end(JSON.stringify({answer:data.choices?.[0]?.message?.content || 'जवाब नहीं मिला।'}));
      } catch(e) { res.writeHead(400,{'Content-Type':'application/json; charset=utf-8'}); res.end(JSON.stringify({error:e.message || 'अनुरोध पूरा नहीं हुआ।'})); }
    }); return;
  }
  const urlPath = req.url.split('?')[0] === '/' ? '/index.html' : decodeURIComponent(req.url.split('?')[0]);
  const file = path.normalize(path.join(ROOT,urlPath));
  if (!file.startsWith(ROOT)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file,(err,data)=>{ if(err){res.writeHead(404);return res.end('Not found');} res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream'});res.end(data); });
});
server.listen(PORT,'0.0.0.0',()=>console.log(`Kaif Raja AI running on port ${PORT}`));
