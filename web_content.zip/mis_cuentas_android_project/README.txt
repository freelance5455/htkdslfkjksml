MIS CUENTAS — PROYECTO ANDROID

Este es el código fuente de una aplicación Android que abre la interfaz de Mis Cuentas dentro de una actividad nativa. La interfaz se incluye localmente en app/src/main/assets/index.html; no necesita conexión para abrirse. No se añade permiso de Internet y se desactiva la copia automática de datos de Android.

IMPORTANTE: este ZIP es un PROYECTO FUENTE, no un APK ya compilado. Para generar el APK hace falta una herramienta de compilación Android compatible, como Code on the Go en el propio teléfono. La primera preparación de la herramienta normalmente requiere conexión y espacio libre. Después de compilar, se podrá instalar el APK generado.

Privacidad: los datos de la interfaz usan almacenamiento local del WebView. No introduzcas datos reales hasta probar altas, cierres/reaperturas y exportación de copia de seguridad. Desinstalar la app puede borrar sus datos; exporta copias periódicas desde la propia aplicación.

Proyecto: Gradle Kotlin DSL, Android Gradle Plugin 8.6.1, Kotlin 2.0.20, compileSdk 35, minSdk 23.
