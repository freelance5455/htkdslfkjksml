import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import * as SkeletonUtils from 'three/addons/utils/SkeletonUtils.js';

/* =====================================================================
   PETUALANGAN ARUNA v3
   - Peta berbasis data (maps/default.json) + editor di dalam game
   - Bisa memakai model 3D peta buatanmu sendiri (GLB/GLTF)
   Pengaturan cepat ada di objek CFG.
   ===================================================================== */
const CFG = {
  moveSpeed: 4.1,
  cameraDistance: 6.2,
  enemyRespawn: 25,
  potionHeal: 50,
  potionPrice: 25,
  saveKey: 'aruna_save_v1',
  mapKey: 'aruna_map_v1',
  defaultMapUrl: './maps/default.json',
  lodDistance: 45,     // pohon lebih jauh dari ini memakai model sederhana
  editorReach: 4,      // jarak kursor editor di depan pemain
  stepUp: 1.0          // tinggi undakan yang masih bisa dinaiki
};

const $ = s => document.querySelector(s);
const messageEl = $('#message');
const talkBtn = $('#talkBtn');
const skillBtn = $('#skillBtn');

/* ---------- Scene, kamera, renderer ---------- */
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x9bc5d2);
scene.fog = new THREE.Fog(0x9bc5d2, 70, 240);

const camera = new THREE.PerspectiveCamera(60, innerWidth / innerHeight, 0.1, 500);
camera.position.set(0, 4, 8);

let maxPixelRatio = 1.5;
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio, maxPixelRatio));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
$('#game').appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xdaf2ff, 0x52603b, 1.8));
const sun = new THREE.DirectionalLight(0xfff0d3, 2.2);
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
sun.shadow.camera.left = -32; sun.shadow.camera.right = 32;
sun.shadow.camera.top = 32; sun.shadow.camera.bottom = -32;
sun.shadow.camera.far = 120;
scene.add(sun, sun.target);
const SUN_OFFSET = new THREE.Vector3(-12, 24, 10);

const world = new THREE.Group();     // semua isi dunia
scene.add(world);
const mapGroup = new THREE.Group();  // isi peta (dibersihkan saat ganti peta)
world.add(mapGroup);

/* ---------- Utilitas ---------- */
function notify(text) {
  messageEl.textContent = text;
  messageEl.classList.add('show');
  clearTimeout(notify.timer);
  notify.timer = setTimeout(() => messageEl.classList.remove('show'), 2200);
}
function mulberry32(a) {
  return function () {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
const rng = mulberry32(20261122);
function turnTo(obj, targetY, dt, rate = 14) {
  let d = targetY - obj.rotation.y;
  d = Math.atan2(Math.sin(d), Math.cos(d));
  obj.rotation.y += d * Math.min(1, rate * dt);
}
const _v = new THREE.Vector3();
const _q = new THREE.Quaternion();
const round1 = n => Math.round(n * 10) / 10;

/* =====================================================================
   DATA PETA (format JSON) — lihat README untuk penjelasan lengkap
   ===================================================================== */
const OBJ_TYPES = {
  pine: { label: 'Pohon pinus' },
  maple: { label: 'Pohon maple' },
  rock: { label: 'Batu' },
  bush: { label: 'Semak' },
  house: { label: 'Rumah' }
};
const EDIT_TYPES = [
  ...Object.keys(OBJ_TYPES),
  'enemy_slime', 'enemy_goblin', 'npc', 'spawn'
];
const EDIT_LABELS = {
  ...Object.fromEntries(Object.entries(OBJ_TYPES).map(([k, v]) => [k, v.label])),
  enemy_slime: 'Spawn Slime', enemy_goblin: 'Spawn Goblin', npc: 'Pindah NPC Pak Raka', spawn: 'Titik awal pemain'
};

const ENEMY_TYPES = {
  slime: { name: 'Slime', hp: 50, dmg: 8, speed: 2.2, aggro: 11, range: 1.5, cd: 1.5, exp: 20, gold: [3, 8], potionChance: 0.18, drop: null, barY: 1.5 },
  goblin: { name: 'Goblin', hp: 110, dmg: 15, speed: 3.1, aggro: 14, range: 1.9, cd: 1.3, exp: 45, gold: [8, 16], potionChance: 0.25, drop: { item: 'fang', chance: 0.6 }, barY: 2.35 }
};

function normalizeMap(d) {
  d = d && typeof d === 'object' ? d : {};
  const num = (v, def) => (Number.isFinite(+v) && v !== null && v !== '' ? +v : def);
  const t = d.terrain || {};
  const m = d.model && d.model.url ? d.model : null;
  const pair = (a, dx, dz) => [num(a?.[0], dx), num(a?.[1], dz)];
  return {
    name: String(d.name || 'Peta Saya').slice(0, 60),
    sky: typeof d.sky === 'string' ? d.sky : '#9bc5d2',
    fog: Array.isArray(d.fog) && d.fog.length === 2 ? [num(d.fog[0], 70), num(d.fog[1], 240)] : [70, 240],
    terrain: {
      type: ['hills', 'flat', 'none'].includes(t.type) ? t.type : 'hills',
      size: Math.max(40, num(t.size, 300)),
      cx: num(t.cx, 0), cz: num(t.cz, 0),
      amp: num(t.amp, 2.4),
      color: typeof t.color === 'string' ? t.color : '#4f8a3c'
    },
    model: m ? {
      url: String(m.url),
      scale: num(m.scale, 1),
      position: [num(m.position?.[0], 0), num(m.position?.[1], 0), num(m.position?.[2], 0)],
      rotY: num(m.rotY, 0),
      groundMeshes: typeof m.groundMeshes === 'string' ? m.groundMeshes : ''
    } : null,
    spawn: pair(d.spawn, 7, 10),
    npc: pair(d.npc, -4, 14),
    objects: (Array.isArray(d.objects) ? d.objects : [])
      .filter(o => o && OBJ_TYPES[o.t] && Number.isFinite(+o.x) && Number.isFinite(+o.z))
      .map(o => ({ t: o.t, x: +o.x, z: +o.z, s: num(o.s, 1), r: num(o.r, 0) })),
    enemies: (Array.isArray(d.enemies) ? d.enemies : [])
      .filter(e => e && ENEMY_TYPES[e.t] && Number.isFinite(+e.x) && Number.isFinite(+e.z))
      .map(e => ({ t: e.t, x: +e.x, z: +e.z }))
  };
}

let mapData = normalizeMap({});

/* =====================================================================
   TANAH: heightfield prosedural ATAU model peta buatanmu
   Semua kode memakai groundHeight(x, z, maxY) agar berpijak di tanah.
   ===================================================================== */
const TP = { type: 'hills', size: 300, cx: 0, cz: 0, amp: 2.4, color: '#4f8a3c' };
const spawnPoint = new THREE.Vector3(7, 0, 10);

function terrainHeight(x, z) {
  if (TP.type === 'flat') return 0;
  const d = Math.hypot(x - spawnPoint.x, z - spawnPoint.z);
  const flat = THREE.MathUtils.smoothstep(d, 14, 34); // area awal dibuat datar
  return (Math.sin(x * 0.045) * Math.cos(z * 0.04) * TP.amp + Math.sin(x * 0.11 + z * 0.07) * TP.amp * 0.25) * flat;
}

// Indeks segitiga untuk model peta: cari tinggi tanah di (x, z) dengan cepat.
class GroundIndex {
  constructor(cell = 4) { this.cell = cell; this.bins = new Map(); this.tris = []; this.big = []; this.box = new THREE.Box3(); }
  key(ix, iz) { return (ix + 32768) * 65536 + (iz + 32768); }
  addMesh(mesh) {
    mesh.updateWorldMatrix(true, false);
    const g = mesh.geometry, pos = g.attributes.position, idx = g.index, m = mesh.matrixWorld;
    const a = new THREE.Vector3(), b = new THREE.Vector3(), c = new THREE.Vector3();
    const n = idx ? idx.count : pos.count;
    for (let i = 0; i + 2 < n; i += 3) {
      const i0 = idx ? idx.getX(i) : i, i1 = idx ? idx.getX(i + 1) : i + 1, i2 = idx ? idx.getX(i + 2) : i + 2;
      a.fromBufferAttribute(pos, i0).applyMatrix4(m);
      b.fromBufferAttribute(pos, i1).applyMatrix4(m);
      c.fromBufferAttribute(pos, i2).applyMatrix4(m);
      this.addTri(a, b, c);
    }
  }
  addTri(a, b, c) {
    const area = Math.abs((b.x - a.x) * (c.z - a.z) - (c.x - a.x) * (b.z - a.z));
    if (area < 1e-6) return; // segitiga tegak lurus: abaikan
    const id = this.tris.push(new Float32Array([a.x, a.y, a.z, b.x, b.y, b.z, c.x, c.y, c.z])) - 1;
    this.box.expandByPoint(a); this.box.expandByPoint(b); this.box.expandByPoint(c);
    const cs = this.cell;
    const x0 = Math.floor(Math.min(a.x, b.x, c.x) / cs), x1 = Math.floor(Math.max(a.x, b.x, c.x) / cs);
    const z0 = Math.floor(Math.min(a.z, b.z, c.z) / cs), z1 = Math.floor(Math.max(a.z, b.z, c.z) / cs);
    if ((x1 - x0 + 1) * (z1 - z0 + 1) > 4000) { this.big.push(id); return; }
    for (let ix = x0; ix <= x1; ix++) for (let iz = z0; iz <= z1; iz++) {
      const k = this.key(ix, iz);
      let arr = this.bins.get(k);
      if (!arr) { arr = []; this.bins.set(k, arr); }
      arr.push(id);
    }
  }
  // tinggi tertinggi di (x, z) yang tidak lebih dari maxY; null jika tidak ada tanah
  query(x, z, maxY) {
    const arr = this.bins.get(this.key(Math.floor(x / this.cell), Math.floor(z / this.cell)));
    if (!arr && !this.big.length) return null;
    let best = null;
    const ids = arr ? (this.big.length ? arr.concat(this.big) : arr) : this.big;
    for (const id of ids) {
      const t = this.tris[id];
      const d = (t[5] - t[8]) * (t[0] - t[6]) + (t[6] - t[3]) * (t[2] - t[8]);
      if (Math.abs(d) < 1e-9) continue;
      const l1 = ((t[5] - t[8]) * (x - t[6]) + (t[6] - t[3]) * (z - t[8])) / d;
      const l2 = ((t[8] - t[2]) * (x - t[6]) + (t[0] - t[6]) * (z - t[8])) / d;
      const l3 = 1 - l1 - l2;
      if (l1 < -1e-4 || l2 < -1e-4 || l3 < -1e-4) continue;
      const y = l1 * t[1] + l2 * t[4] + l3 * t[7];
      if (y <= maxY && (best === null || y > best)) best = y;
    }
    return best;
  }
}

let groundIndex = null;
let terrainMesh = null;
let modelRoot = null;
const colliders = [];   // lingkaran tabrakan {x, z, r}
let bounds = { minX: -100, maxX: 100, minZ: -100, maxZ: 100 };

function groundHeight(x, z, maxY = 1e9) {
  if (groundIndex) return groundIndex.query(x, z, maxY);   // null = di luar model peta
  return TP.type === 'none' ? null : terrainHeight(x, z);
}

function buildTerrain() {
  if (terrainMesh) { mapGroup.remove(terrainMesh); terrainMesh.geometry.dispose(); terrainMesh.material.dispose(); terrainMesh = null; }
  if (TP.type === 'none') return;
  const seg = THREE.MathUtils.clamp(Math.round(TP.size / 4), 40, 200);
  const geo = new THREE.PlaneGeometry(TP.size, TP.size, seg, seg);
  geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes.position;
  const colors = new Float32Array(pos.count * 3);
  const base = new THREE.Color(TP.color), hsl = {};
  base.getHSL(hsl);
  const c = new THREE.Color();
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i) + TP.cx, z = pos.getZ(i) + TP.cz;
    const h = terrainHeight(x, z);
    pos.setXYZ(i, x, h, z);
    const n = (Math.sin(x * 0.31) + Math.sin(z * 0.27) + Math.sin((x + z) * 0.13)) / 3;
    c.setHSL(hsl.h + n * 0.02, hsl.s, THREE.MathUtils.clamp(hsl.l + h * 0.025 + n * 0.035, 0.05, 0.95));
    colors[i * 3] = c.r; colors[i * 3 + 1] = c.g; colors[i * 3 + 2] = c.b;
  }
  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geo.computeVertexNormals();
  terrainMesh = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1, metalness: 0 }));
  terrainMesh.receiveShadow = true;
  mapGroup.add(terrainMesh);
}

function resolveColliders(pos, radius) {
  for (const c of colliders) {
    const dx = pos.x - c.x, dz = pos.z - c.z, min = c.r + radius;
    const d2 = dx * dx + dz * dz;
    if (d2 < min * min) {
      const d = Math.sqrt(d2) || 0.0001;
      pos.x = c.x + dx / d * min;
      pos.z = c.z + dz / d * min;
    }
  }
}
function clampBounds(pos) {
  pos.x = THREE.MathUtils.clamp(pos.x, bounds.minX, bounds.maxX);
  pos.z = THREE.MathUtils.clamp(pos.z, bounds.minZ, bounds.maxZ);
}

/* =====================================================================
   LOADER ASET (lazy load)
   ===================================================================== */
const loader = new GLTFLoader();
const assets = {};
const pending = {};
const FILES = {
  tree: './assets/pine_tree.glb',
  sword: './assets/sword.glb',
  a: './assets/character_a.glb',
  b: './assets/character_b.glb',
  walk: './assets/walk_animation.gltf',
  map: './assets/map.gltf'      // dipakai sebagai sumber pohon maple
};
function loadAsset(key, onProgress) {
  if (assets[key]) return Promise.resolve(assets[key]);
  if (pending[key]) return pending[key];
  pending[key] = loader.loadAsync(FILES[key], onProgress).then(gltf => {
    assets[key] = gltf.scene;
    if (key === 'walk') assets.walkAnimations = gltf.animations || [];
    return gltf.scene;
  }).catch(err => { delete pending[key]; throw err; });
  return pending[key];
}
// SkeletonUtils.clone wajib untuk model ber-skeleton agar tulang ikut ter-clone.
const cloneModel = source => SkeletonUtils.clone(source);

function fitModel(model, desiredHeight, centerXZ = false) {
  model.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(model);
  const size = new THREE.Vector3();
  box.getSize(size);
  const height = Math.max(size.y, size.x, size.z, 0.001);
  model.scale.setScalar(desiredHeight / height);
  model.updateMatrixWorld(true);
  const fitted = new THREE.Box3().setFromObject(model);
  model.position.y -= fitted.min.y;
  if (centerXZ) {
    // Model dari Blender sering tersimpan jauh dari titik pusat; pusatkan.
    model.position.x -= (fitted.min.x + fitted.max.x) / 2;
    model.position.z -= (fitted.min.z + fitted.max.z) / 2;
  }
  model.traverse(obj => {
    if (obj.isMesh) {
      obj.castShadow = true;
      obj.receiveShadow = true;
      if (obj.material) obj.material.side = THREE.DoubleSide;
    }
  });
  return model;
}

function setProgress(p, text) {
  $('#loadFill').style.width = `${Math.round(p * 100)}%`;
  if (text) $('#loadText').textContent = text;
}

/* =====================================================================
   DATA GAME: item, quest, status
   ===================================================================== */
const ITEMS = {
  potion: { name: 'Ramuan HP', desc: `Memulihkan ${CFG.potionHeal} HP`, usable: true },
  fang: { name: 'Taring Goblin', desc: 'Bahan untuk quest Pak Raka' }
};

const QUESTS = [
  {
    id: 'slime', title: 'Bersihkan Slime', type: 'kill', target: 'slime', need: 5,
    intro: 'Selamat datang, Aruna! Slime di hutan ini makin banyak dan mengganggu warga. Bisakah kamu mengalahkan 5 Slime?',
    progress: 'Slime masih berkeliaran. Kalahkan 5 Slime, ya.',
    done: 'Hebat! Hutan jadi lebih tenang. Ini hadiah untukmu.',
    reward: { exp: 80, gold: 40, items: { potion: 2 } }
  },
  {
    id: 'goblin', title: 'Ancaman Goblin', type: 'kill', target: 'goblin', need: 3,
    intro: 'Sekarang ada Goblin yang lebih berbahaya di area yang lebih jauh. Kalahkan 3 Goblin, tapi bawa Ramuan HP!',
    progress: 'Goblin tinggal di area yang lebih jauh dari desa. Hati-hati.',
    done: 'Kamu pemberani! Warga akan aman berkatmu.',
    reward: { exp: 150, gold: 100, items: { potion: 3 } }
  },
  {
    id: 'fang', title: 'Taring Goblin', type: 'collect', item: 'fang', need: 4,
    intro: 'Aku butuh 4 Taring Goblin untuk membuat jimat pelindung desa. Goblin kadang menjatuhkannya.',
    progress: 'Kumpulkan 4 Taring Goblin dari Goblin yang kamu kalahkan.',
    done: 'Sempurna! Jimat ini akan melindungi kita. Terima kasih, pahlawan!',
    reward: { exp: 250, gold: 200, items: { potion: 5 } }
  }
];

const stats = {
  level: 1, exp: 0, hp: 100,
  inv: { potion: 2, gold: 0, fang: 0 },
  questIndex: 0, questStatus: 'inactive', questProgress: 0
};
const maxHp = () => 100 + (stats.level - 1) * 20;
const attackPower = () => 20 + (stats.level - 1) * 5;
const expToNext = () => 50 + stats.level * 50;

/* =====================================================================
   PEMAIN
   ===================================================================== */
const player = new THREE.Group();
world.add(player);
let currentCharacter = 'a';
let characterModel = null;
let weaponPivot = null;
let characterMixer = null;
let walkAction = null;
let characterBaseY = 0;
let switching = false;

const ATTACK_TIME = 0.55;   // lama animasi serang (detik)
const HIT_AT = 0.36;        // saat (0..1) pedang mengenai musuh
let characterRig = null;    // rig animasi prosedural (karakter ber-skeleton)
let anim = null;            // {idle, walk, jump, attack, current}
let hitStop = 0, shake = 0; // efek "feel" serangan
let attackTime = 0, attackHitDone = true;
let jumpVelocity = 0, isGrounded = true;
let skillCooldown = 0;
let walkPhase = 0;
let skillEffects = [];
let playerDead = false;
let invuln = 0;
let sinceHurt = 99;
let joyX = 0, joyY = 0, keyX = 0, keyY = 0;
let cameraYaw = 0, cameraPitch = 0.28;

function addFallbackCharacter(parent) {
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.35, 0.85, 4, 8), new THREE.MeshStandardMaterial({ color: 0x4b91c2 }));
  body.position.y = 0.95; body.castShadow = true; parent.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.25, 16, 12), new THREE.MeshStandardMaterial({ color: 0xe5bd91 }));
  head.position.y = 1.65; head.castShadow = true; parent.add(head);
}


/* =====================================================================
   ANIMASI PROSEDURAL (idle / lompat / serang) untuk model ber-skeleton
   Pose ditulis sebagai ARAH anggota badan dalam koordinat badan
   [kanan, atas, depan]; kodenya menghitung rotasi tulang yang sesuai,
   jadi tidak bergantung pada arah sumbu tulang dari Blender.
   ===================================================================== */
const BONE_CHILD = {
  waist: 'chest', chest: 'shoulder', shoulder: 'neck', neck: 'head',
  rightUpperArm: 'rightForearm', rightForearm: 'rightHand',
  leftUpperArm: 'leftForearm', leftForearm: 'leftHand',
  rightThigh: 'rightCalf', rightCalf: 'rightFoot', rightFoot: 'rightFootToe',
  leftThigh: 'leftCalf', leftCalf: 'leftFoot', leftFoot: 'leftFootToe'
};
const mirrorDir = a => [-a[0], a[1], a[2]];
// aR/aL: [lengan atas, lengan bawah]; lR/lL: [paha, betis, telapak]; sp: [pinggang, dada, bahu, leher]
// Sisi kiri ditulis dalam koordinat "seperti kanan" lalu dicerminkan otomatis.
function poseDirs(o) {
  const d = {};
  if (o.aR) [d.rightUpperArm, d.rightForearm] = o.aR;
  if (o.aL) [d.leftUpperArm, d.leftForearm] = o.aL.map(mirrorDir);
  if (o.lR) [d.rightThigh, d.rightCalf, d.rightFoot] = o.lR;
  if (o.lL) [d.leftThigh, d.leftCalf, d.leftFoot] = o.lL.map(mirrorDir);
  if (o.sp) [d.waist, d.chest, d.shoulder, d.neck] = o.sp;
  return d;
}
const LEG_STAND = [[0.07, -1, 0.02], [0.07, -1, -0.04], [0.1, -0.15, 1]];
const POSE_IDLE_A = { aR: [[0.22, -0.96, 0.08], [0.12, -0.85, 0.5]], aL: [[0.22, -0.96, 0.08], [0.12, -0.85, 0.5]], lR: LEG_STAND, lL: LEG_STAND, sp: [[0, 1, 0.04], [0, 1, 0.05], [0, 1, 0.04], [0, 1, 0.06]] };
const POSE_IDLE_B = { aR: [[0.27, -0.95, 0.05], [0.16, -0.84, 0.46]], aL: [[0.27, -0.95, 0.05], [0.16, -0.84, 0.46]], lR: LEG_STAND, lL: LEG_STAND, sp: [[0, 1, 0.02], [0, 1, 0.03], [0, 1, 0.02], [0, 1, 0.04]], hipY: 0.012 };
const POSE_JUMP = {
  aR: [[0.5, 0.45, 0.75], [0.3, 0.8, 0.55]], aL: [[0.5, 0.45, 0.75], [0.3, 0.8, 0.55]],
  lR: [[0.05, -0.55, 0.82], [0.05, -0.9, -0.45], [0, -0.7, 0.7]],
  lL: [[0.05, -0.95, 0.2], [0.05, -0.8, -0.6], [0, -0.6, 0.8]],
  sp: [[0, 1, 0.12], [0, 1, 0.1], [0, 1, 0.08], [0, 1, 0.1]]
};
const POSE_WINDUP = {
  aR: [[0.35, 0.8, -0.5], [0.3, 0.85, -0.25]], aL: [[0.5, -0.35, 0.6], [0.3, -0.1, 0.85]],
  lR: [[0.12, -0.95, -0.3], [0.1, -0.95, -0.35], [0.1, -0.2, 1]], lL: [[0.12, -0.9, 0.4], [0.1, -0.95, -0.1], [0.1, -0.2, 1]],
  sp: [[0.18, 0.96, -0.2], [0.18, 0.96, -0.2], [0.1, 1, -0.1], [0, 1, 0]], hipY: -0.04
};
const POSE_STRIKE = {
  aR: [[0.1, 0.15, 1], [0, 0.1, 1]], aL: [[0.5, -0.5, 0.45], [0.3, -0.3, 0.6]],
  lR: [[0.1, -0.8, 0.6], [0.1, -1, 0.05], [0.1, -0.2, 1]], lL: [[0.1, -0.85, -0.45], [0.1, -0.7, -0.65], [0.1, -0.5, 0.85]],
  sp: [[-0.15, 0.93, 0.35], [-0.12, 0.95, 0.3], [0, 1, 0.2], [0, 1, 0.1]], hipY: -0.08
};
const POSE_FOLLOW = Object.assign({}, POSE_STRIKE, { aR: [[-0.35, -0.3, 0.9], [-0.35, -0.25, 0.9]], hipY: -0.06 });

function buildRig(model) {
  const bones = {};
  model.traverse(o => { if (o.isBone) bones[o.name] = o; });
  const need = ['hip', 'waist', 'chest', 'shoulder', 'neck', 'head', 'rightThigh', 'leftThigh', 'rightCalf', 'leftCalf',
    'rightFoot', 'leftFoot', 'rightFootToe', 'leftFootToe', 'rightUpperArm', 'leftUpperArm', 'rightForearm', 'leftForearm', 'rightHand'];
  if (need.some(n => !bones[n]) || !bones.hip.parent) return null;
  model.updateMatrixWorld(true);
  const inv = new THREE.Matrix4().copy(model.matrixWorld).invert();
  const rel = o => new THREE.Matrix4().multiplyMatrices(inv, o.matrixWorld);
  const pos = o => new THREE.Vector3().setFromMatrixPosition(rel(o));

  // Sumbu badan (dalam ruang model): kanan, atas, depan
  const lat = pos(bones.rightThigh).sub(pos(bones.leftThigh)).normalize();
  const up = pos(bones.head).sub(pos(bones.hip));
  up.addScaledVector(lat, -up.dot(lat)).normalize();
  const fwd = new THREE.Vector3().crossVectors(up, lat).normalize();
  const toe = pos(bones.rightFootToe).sub(pos(bones.rightFoot)).add(pos(bones.leftFootToe).sub(pos(bones.leftFoot)));
  toe.addScaledVector(up, -toe.dot(up));
  if (toe.lengthSq() > 1e-6 && toe.dot(fwd) < 0) fwd.negate();
  const toWorld = d => lat.clone().multiplyScalar(d[0]).addScaledVector(up, d[1]).addScaledVector(fwd, d[2]).normalize();

  const hip = bones.hip;
  const parentWO = new THREE.Quaternion(), parentScale = new THREE.Vector3();
  rel(hip.parent).decompose(new THREE.Vector3(), parentWO, parentScale);
  const parentInv = parentWO.clone().invert();
  const restQ = new Map();
  for (const b of Object.values(bones)) restQ.set(b, b.quaternion.clone());
  const hipRest = hip.position.clone();

  function solve(dirs) {
    const local = new Map(), world = new Map();
    const visit = (bone, pwo) => {
      let q = restQ.get(bone).clone();
      const d = dirs[bone.name], cn = BONE_CHILD[bone.name];
      if (d && cn && bones[cn]) {
        const cur = bones[cn].position.clone().normalize().applyQuaternion(pwo.clone().multiply(q));
        const D = new THREE.Quaternion().setFromUnitVectors(cur, toWorld(d));
        q = pwo.clone().invert().multiply(D).multiply(pwo).multiply(q);   // lokal baru = pwo^-1 * D * pwo * q
      }
      const wo = pwo.clone().multiply(q);
      local.set(bone, q); world.set(bone, wo);
      for (const c of bone.children) if (c.isBone) visit(c, wo);
    };
    visit(hip, parentWO);
    return { local, world };
  }

  function makeClip(name, keys) {
    const times = keys.map(k => k.t);
    const solved = keys.map(k => solve(poseDirs(k.pose)));
    const tracks = [];
    for (const bone of Object.values(bones)) {
      const vals = [];
      let prev = null;
      for (const sv of solved) {
        const q = (sv.local.get(bone) || restQ.get(bone)).clone();
        if (prev && prev.dot(q) < 0) { q.x = -q.x; q.y = -q.y; q.z = -q.z; q.w = -q.w; }  // jalur slerp terpendek
        vals.push(q.x, q.y, q.z, q.w);
        prev = q;
      }
      tracks.push(new THREE.QuaternionKeyframeTrack(`${bone.name}.quaternion`, times, vals));
    }
    const hv = [];
    for (const k of keys) {   // naik/turun pinggul (satuan model) -> posisi lokal hip
      const off = up.clone().multiplyScalar(k.pose.hipY || 0).applyQuaternion(parentInv).divide(parentScale);
      hv.push(hipRest.x + off.x, hipRest.y + off.y, hipRest.z + off.z);
    }
    tracks.push(new THREE.VectorKeyframeTrack('hip.position', times, hv));
    return new THREE.AnimationClip(name, times[times.length - 1], tracks);
  }

  const clips = {
    idle: makeClip('idle', [{ t: 0, pose: POSE_IDLE_A }, { t: 1.1, pose: POSE_IDLE_B }, { t: 2.2, pose: POSE_IDLE_A }]),
    jump: makeClip('jump', [{ t: 0, pose: POSE_JUMP }, { t: 0.4, pose: POSE_JUMP }]),
    attack: makeClip('attack', [
      { t: 0, pose: POSE_IDLE_A }, { t: 0.12, pose: POSE_WINDUP }, { t: 0.22, pose: POSE_STRIKE },
      { t: 0.38, pose: POSE_FOLLOW }, { t: 0.55, pose: POSE_IDLE_A }
    ])
  };

  // Pegangan pedang: orientasi tangan saat idle -> bilah menunjuk depan-atas
  const idleSolved = solve(poseDirs(POSE_IDLE_A));
  const handWO = idleSolved.world.get(bones.rightHand);
  const blade = up.clone().multiplyScalar(0.7).addScaledVector(fwd, 0.7).normalize();
  const bladeQ = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), blade);
  const holderQuat = handWO.clone().invert().multiply(bladeQ);
  const handScale = new THREE.Vector3();
  rel(bones.rightHand).decompose(new THREE.Vector3(), new THREE.Quaternion(), handScale);
  return { clips, hand: bones.rightHand, holderQuat, holderScale: 1 / (handScale.x || 1) };
}

function playAnim(name, fade = 0.15) {
  if (!anim || (anim.current === name && !anim.restart)) return;
  anim.restart = false;
  const next = anim[name], prev = anim.current ? anim[anim.current] : null;
  next.reset().setEffectiveWeight(1).play();
  if (fade > 0) next.fadeIn(fade);
  if (prev && prev !== next) prev.fadeOut(fade);
  anim.current = name;
}

function addWeaponRig() {
  weaponPivot = null;
  if (!assets.sword || !characterModel || !characterRig) return;
  const k = characterModel.scale.x || 1;
  const holder = new THREE.Group();
  holder.quaternion.copy(characterRig.holderQuat);
  holder.scale.setScalar(characterRig.holderScale);
  const sword = cloneModel(assets.sword);
  fitModel(sword, 0.95 / k);
  sword.position.set(0, 0, 0);
  sword.rotation.set(Math.PI / 2, 0, 0);
  sword.updateMatrixWorld(true);
  const b = new THREE.Box3().setFromObject(sword), c = new THREE.Vector3();
  b.getCenter(c);
  const len = b.max.y - b.min.y;
  sword.position.set(-c.x, -b.min.y - 0.15 * len, -c.z);   // gagang di genggaman
  holder.add(sword);
  characterRig.hand.add(holder);
  weaponPivot = holder;
}

function addWeapon() {
  weaponPivot = null;
  if (characterRig) { addWeaponRig(); return; }
  if (!assets.sword || !characterModel) return;
  weaponPivot = new THREE.Group();
  // Titik awal pedang; sesuaikan jika tangan karakter berada di lokasi lain.
  weaponPivot.position.set(0.42, 1.02, 0.12);
  characterModel.add(weaponPivot);
  const sword = cloneModel(assets.sword);
  fitModel(sword, 0.95);
  sword.rotation.x = Math.PI / 2;
  sword.rotation.z = -0.15;
  sword.position.set(0, 0.05, 0);
  weaponPivot.add(sword);
}

function setCharacter(key, silent) {
  if (characterModel) player.remove(characterModel);
  currentCharacter = key;
  const useWalk = key === 'a' && assets.walk;
  const selectedAsset = useWalk ? assets.walk : (assets[key] || assets.a || assets.b);
  characterMixer = null; walkAction = null; characterRig = null; anim = null; weaponPivot = null;
  characterModel = cloneModel(selectedAsset);
  fitModel(characterModel, 1.8, true);
  player.add(characterModel);
  if (useWalk && assets.walkAnimations?.length) {
    characterMixer = new THREE.AnimationMixer(characterModel);
    const clip = (assets.walkAnimations.find(a => a.name === 'Animation') || assets.walkAnimations[0]).clone();
    // Hapus root motion: kunci posisi X/Z tulang 'hip' agar karakter berjalan di tempat.
    for (const tr of clip.tracks) {
      if (!tr.name.endsWith('.position')) continue;
      const node = characterModel.getObjectByName(tr.name.slice(0, -'.position'.length));
      if (!node || !/^(hip|hips|root|pelvis)$/i.test(node.name)) continue;
      for (let i = 0; i < tr.values.length; i += 3) { tr.values[i] = node.position.x; tr.values[i + 2] = node.position.z; }
    }
    walkAction = characterMixer.clipAction(clip);
    walkAction.setLoop(THREE.LoopRepeat, Infinity);
    characterRig = buildRig(characterModel);   // null jika bukan skeleton humanoid
    if (characterRig) {
      const mk = (clip, once) => {
        const a = characterMixer.clipAction(clip);
        if (once) { a.setLoop(THREE.LoopOnce, 1); a.clampWhenFinished = true; }
        return a;
      };
      anim = { idle: mk(characterRig.clips.idle), walk: walkAction, jump: mk(characterRig.clips.jump),
        attack: mk(characterRig.clips.attack, true), current: null, restart: false };
      anim.attack.timeScale = characterRig.clips.attack.duration / ATTACK_TIME;
      playAnim('idle', 0);
    } else {
      walkAction.play();
      walkAction.paused = true;
    }
  }
  addWeapon();
  characterBaseY = characterModel.position.y;
  if (!silent) notify(key === 'a' ? 'Karakter A dipilih' : 'Karakter B dipilih');
}

async function selectCharacter(key, silent) {
  if (switching) return;
  switching = true;
  try {
    if (key === 'b' && !assets.b) { notify('Memuat Karakter B...'); await loadAsset('b'); }
    if (key === 'a' && !assets.walk && !assets.a) {
      try { await loadAsset('walk'); } catch { await loadAsset('a'); }
    }
    setCharacter(key, silent);
  } catch (err) {
    console.error(err);
    notify('Gagal memuat karakter. Jalankan lewat server lokal Acode.');
  } finally { switching = false; }
}

const groundAt = pos => groundHeight(pos.x, pos.z, pos.y + CFG.stepUp);

/* =====================================================================
   OBJEK PETA (pohon, batu, semak, rumah) + LOD
   ===================================================================== */
const MAPLE_BASE = 2.2;
const mapObjects = [];     // {data, group, high, low, collider, lod}
let _mapleSrc = null;
function mapleSource() {
  if (!_mapleSrc && assets.map) assets.map.traverse(n => { if (!_mapleSrc && n.name && n.name.startsWith('Maple')) _mapleSrc = n; });
  return _mapleSrc;
}

const PROXY = {};
function proxyMats() {
  if (PROXY.ready) return PROXY;
  PROXY.pineLeaf = new THREE.MeshStandardMaterial({ color: 0x2f6b3a, roughness: 1 });
  PROXY.mapleLeaf = new THREE.MeshStandardMaterial({ color: 0x8aa83a, roughness: 1 });
  PROXY.bark = new THREE.MeshStandardMaterial({ color: 0x5a3d26, roughness: 1 });
  PROXY.rock = new THREE.MeshStandardMaterial({ color: 0x8a8d90, roughness: 0.95 });
  PROXY.bush = new THREE.MeshStandardMaterial({ color: 0x3f7a35, roughness: 1 });
  PROXY.wall = new THREE.MeshStandardMaterial({ color: 0xb08a5a, roughness: 0.9 });
  PROXY.roof = new THREE.MeshStandardMaterial({ color: 0x7a3b2a, roughness: 0.9 });
  PROXY.geoPineCone = new THREE.ConeGeometry(2.4, 9, 8);
  PROXY.geoPineTrunk = new THREE.CylinderGeometry(0.35, 0.5, 4, 6);
  PROXY.geoMapleCrown = new THREE.SphereGeometry(6, 10, 8);
  PROXY.geoMapleTrunk = new THREE.CylinderGeometry(0.6, 0.9, 8, 6);
  PROXY.geoRock = new THREE.DodecahedronGeometry(0.9);
  PROXY.geoBush = new THREE.SphereGeometry(0.8, 10, 8);
  PROXY.geoBox = new THREE.BoxGeometry(4, 2.6, 4);
  PROXY.geoRoof = new THREE.ConeGeometry(3.4, 1.6, 4);
  PROXY.ready = true;
  return PROXY;
}
function mesh(geo, mat, x, y, z, cast = true) {
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y, z);
  m.castShadow = cast; m.receiveShadow = true;
  return m;
}

function makeObject(d) {
  const P = proxyMats();
  const g = new THREE.Group();
  const s = d.s || 1;
  g.scale.setScalar(s);
  g.rotation.y = d.r || 0;
  const o = { data: d, group: g, high: null, low: null, collider: null, lod: false, r: 0 };
  switch (d.t) {
    case 'pine': {
      const low = new THREE.Group();
      low.add(mesh(P.geoPineCone, P.pineLeaf, 0, 6.5, 0, false), mesh(P.geoPineTrunk, P.bark, 0, 2, 0, false));
      g.add(low); o.low = low; o.lod = true; o.r = 0.9;
      break;
    }
    case 'maple': {
      const low = new THREE.Group();
      low.add(mesh(P.geoMapleCrown, P.mapleLeaf, 0, 13, 0, false), mesh(P.geoMapleTrunk, P.bark, 0, 4, 0, false));
      g.add(low); o.low = low; o.lod = true; o.r = 0.36 * MAPLE_BASE;
      break;
    }
    case 'rock': {
      const m = mesh(P.geoRock, P.rock, 0, 0.4, 0); m.scale.set(1, 0.7, 1.1);
      g.add(m); o.r = 0.9;
      break;
    }
    case 'bush': {
      const m = mesh(P.geoBush, P.bush, 0, 0.55, 0); m.scale.set(1.2, 0.8, 1.2);
      g.add(m);
      break;
    }
    case 'house': {
      g.add(mesh(P.geoBox, P.wall, 0, 1.3, 0));
      const roof = mesh(P.geoRoof, P.roof, 0, 3.4, 0); roof.rotation.y = Math.PI / 4;
      g.add(roof); o.r = 2.9;
      break;
    }
    default: return null;
  }
  return o;
}

function upgradeObject(o) {
  if (o.high) return;
  const t = o.data.t;
  if (t === 'pine' && assets.tree) {
    const m = cloneModel(assets.tree);
    fitModel(m, 11, true);
    const h = new THREE.Group(); h.add(m);
    o.group.add(h); o.high = h;
  } else if (t === 'maple') {
    const src = mapleSource();
    if (!src) return;
    const m = cloneModel(src);
    m.position.set(0, 0, 0); m.rotation.set(0, 0, 0); m.scale.setScalar(MAPLE_BASE);
    m.traverse(n => { if (n.isMesh) { n.castShadow = true; n.receiveShadow = true; if (n.material) n.material.side = THREE.DoubleSide; } });
    const h = new THREE.Group(); h.add(m);
    o.group.add(h); o.high = h;
  }
}
function upgradeAllObjects() { for (const o of mapObjects) upgradeObject(o); }

function addMapObject(d) {
  const o = makeObject(d);
  if (!o) return null;
  const y = groundHeight(d.x, d.z, 1e9);
  o.group.position.set(d.x, y ?? 0, d.z);
  mapGroup.add(o.group);
  if (o.r > 0) { o.collider = { x: d.x, z: d.z, r: o.r * (d.s || 1) }; colliders.push(o.collider); }
  mapObjects.push(o);
  upgradeObject(o);
  if (d.t === 'maple' && !assets.map) loadAsset('map').then(upgradeAllObjects).catch(() => {});
  return o;
}

function removeMapObject(o) {
  mapGroup.remove(o.group);
  const i = mapObjects.indexOf(o); if (i >= 0) mapObjects.splice(i, 1);
  if (o.collider) { const k = colliders.indexOf(o.collider); if (k >= 0) colliders.splice(k, 1); }
  const j = mapData.objects.indexOf(o.data); if (j >= 0) mapData.objects.splice(j, 1);
}

let lodTimer = 0;
function updateLod(dt) {
  lodTimer -= dt;
  if (lodTimer > 0) return;
  lodTimer = 0.3;
  for (const o of mapObjects) {
    if (!o.lod) continue;
    const d = Math.hypot(o.group.position.x - player.position.x, o.group.position.z - player.position.z);
    const near = d < CFG.lodDistance && !!o.high;
    if (o.high) o.high.visible = near;
    if (o.low) o.low.visible = !near;
  }
}

/* ----- NPC Pak Raka ----- */
let npc = null;
function placeNpc(x, z) {
  if (!npc) {
    const g = new THREE.Group();
    const robe = new THREE.Mesh(new THREE.CapsuleGeometry(0.38, 0.8, 4, 10), new THREE.MeshStandardMaterial({ color: 0x7b4a2a }));
    robe.position.y = 0.95; robe.castShadow = true; g.add(robe);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.26, 16, 12), new THREE.MeshStandardMaterial({ color: 0xe5bd91 }));
    head.position.y = 1.7; head.castShadow = true; g.add(head);
    const hat = new THREE.Mesh(new THREE.ConeGeometry(0.34, 0.5, 14), new THREE.MeshStandardMaterial({ color: 0x2f6f8f }));
    hat.position.y = 2.1; hat.castShadow = true; g.add(hat);
    const marker = new THREE.Mesh(new THREE.OctahedronGeometry(0.2), new THREE.MeshBasicMaterial({ color: 0xffd45a }));
    marker.position.y = 2.75; g.add(marker);
    mapGroup.add(g);
    const collider = { x, z, r: 0.7 };
    colliders.push(collider);
    npc = { group: g, marker, collider };
  }
  npc.group.position.set(x, groundHeight(x, z, 1e9) ?? 0, z);
  npc.collider.x = x; npc.collider.z = z;
  npcMarker();
}

/* =====================================================================
   MUSUH
   ===================================================================== */
const enemies = [];

function makeEnemyMesh(type) {
  const g = new THREE.Group();
  const mats = [];
  if (type === 'slime') {
    const mat = new THREE.MeshStandardMaterial({ color: 0x58d468, transparent: true, opacity: 0.9, roughness: 0.25 });
    mats.push(mat);
    const body = new THREE.Mesh(new THREE.SphereGeometry(0.7, 16, 12), mat);
    body.scale.y = 0.8; body.position.y = 0.55; body.castShadow = true; g.add(body);
    const white = new THREE.MeshBasicMaterial({ color: 0xffffff }), black = new THREE.MeshBasicMaterial({ color: 0x111111 });
    for (const sx of [-0.22, 0.22]) {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 8), white);
      eye.position.set(sx, 0.75, 0.55); g.add(eye);
      const pupil = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8), black);
      pupil.position.set(sx, 0.75, 0.64); g.add(pupil);
    }
    return { group: g, body, mats };
  }
  const skin = new THREE.MeshStandardMaterial({ color: 0x6aa04a, roughness: 0.8 });
  const cloth = new THREE.MeshStandardMaterial({ color: 0x8a4a2f, roughness: 0.9 });
  mats.push(skin, cloth);
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.36, 0.55, 4, 10), cloth);
  body.position.y = 0.9; body.castShadow = true; g.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.3, 14, 12), skin);
  head.position.y = 1.65; head.castShadow = true; g.add(head);
  for (const sx of [-1, 1]) {
    const ear = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.4, 8), skin);
    ear.position.set(sx * 0.36, 1.72, 0); ear.rotation.z = -sx * 1.2; g.add(ear);
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8), new THREE.MeshBasicMaterial({ color: 0xff3030 }));
    eye.position.set(sx * 0.13, 1.7, 0.26); g.add(eye);
  }
  const club = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.14, 0.9, 8), new THREE.MeshStandardMaterial({ color: 0x5a3a22 }));
  club.position.set(0.5, 1.0, 0.25); club.rotation.x = 0.6; club.castShadow = true; g.add(club);
  return { group: g, body, mats };
}

function makeHpBar(y) {
  const bar = new THREE.Group();
  const bg = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 0.13), new THREE.MeshBasicMaterial({ color: 0x220000, depthTest: false, transparent: true }));
  const fgGeo = new THREE.PlaneGeometry(1.1, 0.13); fgGeo.translate(0.55, 0, 0);
  const fg = new THREE.Mesh(fgGeo, new THREE.MeshBasicMaterial({ color: 0xff4040, depthTest: false, transparent: true }));
  fg.position.set(-0.55, 0, 0.001);
  bg.renderOrder = 10; fg.renderOrder = 11;
  bar.add(bg, fg);
  bar.position.y = y;
  bar.visible = false;
  return { bar, fg };
}

function spawnEnemy(type, x, z, data = null) {
  const T = ENEMY_TYPES[type];
  const m = makeEnemyMesh(type);
  const hb = makeHpBar(T.barY);
  m.group.add(hb.bar);
  const y = groundHeight(x, z, 1e9) ?? 0;
  m.group.position.set(x, y, z);
  mapGroup.add(m.group);
  const e = {
    type, T, data, group: m.group, body: m.body, mats: m.mats, hpBar: hb.bar, hpFill: hb.fg,
    hp: T.hp, state: 'alive', spawn: new THREE.Vector3(x, y, z),
    cd: 1, windup: 0, flash: 0, kx: 0, kz: 0, respawn: 0, phase: rng() * 6
  };
  enemies.push(e);
  return e;
}
function removeEnemy(e) {
  mapGroup.remove(e.group);
  const i = enemies.indexOf(e); if (i >= 0) enemies.splice(i, 1);
  if (e.data) { const j = mapData.enemies.indexOf(e.data); if (j >= 0) mapData.enemies.splice(j, 1); }
}

function setEmissive(e, hex) { for (const m of e.mats) m.emissive.setHex(hex); }

function damageEnemy(e, amount, kx = 0, kz = 0) {
  if (e.state !== 'alive') return;
  e.hp -= amount;
  e.flash = 0.14;
  e.kx = kx; e.kz = kz;
  e.hpBar.visible = true;
  e.hpFill.scale.x = Math.max(0.001, e.hp / e.T.hp);
  _v.copy(e.group.position); _v.y += e.T.barY - 0.4;
  floatText(_v, String(Math.round(amount)), 'hit');
  if (e.hp <= 0) killEnemy(e);
}

function killEnemy(e) {
  e.state = 'dead';
  e.respawn = CFG.enemyRespawn;
  e.group.visible = false;
  const T = e.T;
  const gold = Math.round(T.gold[0] + rng() * (T.gold[1] - T.gold[0]));
  stats.inv.gold += gold;
  _v.copy(e.group.position); _v.y += 1.2;
  floatText(_v, `+${gold} Koin`, 'loot');
  const loot = [];
  if (rng() < T.potionChance) { stats.inv.potion++; loot.push('Ramuan HP'); }
  if (T.drop && rng() < T.drop.chance) { stats.inv[T.drop.item]++; loot.push(ITEMS[T.drop.item].name); }
  notify(`${T.name} dikalahkan! +${T.exp} EXP${loot.length ? ' • ' + loot.join(', ') : ''}`);
  const q = QUESTS[stats.questIndex];
  if (q && stats.questStatus === 'active' && q.type === 'kill' && q.target === e.type) {
    stats.questProgress = Math.min(q.need, stats.questProgress + 1);
  }
  refreshQuest();
  gainExp(T.exp);
  updateHud();
  save();
}

function respawnEnemy(e) {
  e.state = 'alive';
  e.hp = e.T.hp;
  e.group.position.copy(e.spawn);
  e.group.visible = true;
  e.hpBar.visible = false;
  e.hpFill.scale.x = 1;
  e.windup = 0; e.cd = 1.5; e.kx = 0; e.kz = 0;
  setEmissive(e, 0x000000);
}

function updateEnemies(dt, t) {
  for (const e of enemies) {
    if (e.state === 'dead') {
      e.respawn -= dt;
      if (e.respawn <= 0) respawnEnemy(e);
      continue;
    }
    const T = e.T, p = e.group.position;
    const prevX = p.x, prevZ = p.z;
    const dx = player.position.x - p.x, dz = player.position.z - p.z;
    const dist = Math.hypot(dx, dz);
    const toSpawn = Math.hypot(e.spawn.x - p.x, e.spawn.z - p.z);
    e.cd = Math.max(0, e.cd - dt);
    let moving = false;

    if (e.flash > 0) {
      e.flash -= dt;
      setEmissive(e, e.flash > 0 ? 0xff3300 : 0x000000);
    } else if (e.windup > 0) setEmissive(e, 0x553300);

    if (Math.abs(e.kx) + Math.abs(e.kz) > 0.05) {
      p.x += e.kx * dt; p.z += e.kz * dt;
      const decay = Math.max(0, 1 - 8 * dt);
      e.kx *= decay; e.kz *= decay;
    }

    const aggro = !playerDead && dist < T.aggro && toSpawn < 45;
    if (e.windup > 0) {
      e.windup -= dt;
      turnTo(e.group, Math.atan2(dx, dz), dt, 12);
      if (e.windup <= 0) {
        setEmissive(e, 0x000000);
        if (dist < T.range + 0.9) hurtPlayer(T.dmg);
        e.cd = T.cd;
      }
    } else if (aggro) {
      turnTo(e.group, Math.atan2(dx, dz), dt, 10);
      if (dist > T.range) {
        const step = T.speed * dt;
        p.x += dx / dist * step; p.z += dz / dist * step;
        moving = true;
      } else if (e.cd <= 0) {
        e.windup = 0.45;
      }
    } else if (toSpawn > 1.5) {
      const hx = e.spawn.x - p.x, hz = e.spawn.z - p.z;
      turnTo(e.group, Math.atan2(hx, hz), dt, 8);
      const step = T.speed * 0.7 * dt;
      p.x += hx / toSpawn * step; p.z += hz / toSpawn * step;
      moving = true;
      if (e.hp < T.hp) { e.hp = Math.min(T.hp, e.hp + T.hp * 0.1 * dt); e.hpFill.scale.x = Math.max(0.001, e.hp / T.hp); }
    }

    resolveColliders(p, 0.5);
    const g = groundHeight(p.x, p.z, p.y + CFG.stepUp);
    if (g === null) { p.x = prevX; p.z = prevZ; }   // tidak ada tanah: jangan keluar peta
    else p.y = g;

    if (e.type === 'slime') {
      const hop = moving ? Math.abs(Math.sin(t * 6 + e.phase)) : 0;
      e.body.position.y = 0.55 + hop * 0.3;
      e.body.scale.set(1 + (1 - hop) * 0.05, 0.8 + hop * 0.2, 1 + (1 - hop) * 0.05);
    } else {
      e.body.position.y = 0.9 + (moving ? Math.abs(Math.sin(t * 8 + e.phase)) * 0.08 : 0);
    }
    if (e.hpBar.visible) e.hpBar.quaternion.copy(_q.copy(e.group.quaternion).invert().multiply(camera.quaternion));
  }
}

/* =====================================================================
   EXP, LEVEL, HP, QUEST, TAS
   ===================================================================== */
function gainExp(n) {
  stats.exp += n;
  let leveled = false;
  while (stats.exp >= expToNext()) {
    stats.exp -= expToNext();
    stats.level++;
    leveled = true;
  }
  if (leveled) {
    stats.hp = maxHp();
    notify(`Level naik! LV ${stats.level} • HP pulih penuh`);
    spawnRing(0xffe27a, 0.15, 5);
  }
  updateHud();
}

function updateHud() {
  const mh = maxHp(), need = expToNext();
  $('#level').textContent = `LV ${stats.level}`;
  $('#goldText').textContent = `${stats.inv.gold} Koin`;
  $('#hpText').textContent = `HP ${Math.ceil(stats.hp)}/${mh}`;
  $('#hpFill').style.width = `${Math.max(0, stats.hp / mh) * 100}%`;
  $('#expText').textContent = `EXP ${stats.exp}/${need}`;
  $('#expFill').style.width = `${Math.min(1, stats.exp / need) * 100}%`;
  $('#potionBtn').textContent = `RAMUAN x${stats.inv.potion}`;
}

function refreshQuest() {
  const q = QUESTS[stats.questIndex];
  const titleEl = $('#questTitle'), descEl = $('#questDesc');
  if (!q) {
    titleEl.textContent = 'Semua quest selesai';
    descEl.textContent = 'Terus berburu monster dan naikkan levelmu!';
    npcMarker();
    return;
  }
  if (stats.questStatus === 'active' && q.type === 'collect') {
    stats.questProgress = Math.min(q.need, stats.inv[q.item] || 0);
  }
  if (stats.questStatus === 'active' && stats.questProgress >= q.need) stats.questStatus = 'ready';
  if (stats.questStatus === 'ready' && q.type === 'collect' && (stats.inv[q.item] || 0) < q.need) stats.questStatus = 'active';

  if (stats.questStatus === 'inactive') {
    titleEl.textContent = q.title;
    descEl.textContent = 'Bicara dengan Pak Raka untuk menerima quest.';
  } else if (stats.questStatus === 'active') {
    titleEl.textContent = q.title;
    descEl.textContent = `${q.type === 'kill' ? 'Kalahkan' : 'Kumpulkan'} ${stats.questProgress}/${q.need}`;
  } else {
    titleEl.textContent = `${q.title} ✔`;
    descEl.textContent = 'Selesai! Kembali ke Pak Raka untuk hadiah.';
  }
  npcMarker();
}

function npcMarker() {
  if (!npc) return;
  const q = QUESTS[stats.questIndex];
  const show = q && (stats.questStatus === 'inactive' || stats.questStatus === 'ready');
  npc.marker.visible = !!show;
  npc.marker.material.color.setHex(stats.questStatus === 'ready' ? 0x7dff9d : 0xffd45a);
}

function completeQuest() {
  const q = QUESTS[stats.questIndex];
  if (!q || stats.questStatus !== 'ready') return;
  if (q.type === 'collect') stats.inv[q.item] -= q.need;
  const r = q.reward;
  stats.inv.gold += r.gold;
  for (const [k, v] of Object.entries(r.items || {})) stats.inv[k] = (stats.inv[k] || 0) + v;
  stats.questIndex++;
  stats.questStatus = 'inactive';
  stats.questProgress = 0;
  notify(`Quest selesai! +${r.exp} EXP, +${r.gold} Koin`);
  gainExp(r.exp);
  refreshQuest();
  updateHud();
  save();
}

function usePotion() {
  if (playerDead) return;
  if (stats.inv.potion <= 0) { notify('Ramuan HP habis'); return; }
  if (stats.hp >= maxHp()) { notify('HP sudah penuh'); return; }
  stats.inv.potion--;
  stats.hp = Math.min(maxHp(), stats.hp + CFG.potionHeal);
  _v.copy(player.position); _v.y += 2;
  floatText(_v, `+${CFG.potionHeal}`, 'heal');
  updateHud(); renderBag(); save();
}

/* ----- Dialog NPC ----- */
let dialogOpen = false, bagOpen = false;
function openDialog() {
  if (playerDead) return;
  dialogOpen = true;
  $('#dialog').classList.remove('hidden');
  renderDialog();
}
function closeDialog() { dialogOpen = false; $('#dialog').classList.add('hidden'); }

function renderDialog() {
  const q = QUESTS[stats.questIndex];
  const opts = [];
  let text;
  if (!q) text = 'Terima kasih, pahlawan! Desa ini aman berkatmu. Mampirlah kalau butuh Ramuan HP.';
  else if (stats.questStatus === 'inactive') {
    text = q.intro;
    opts.push({ label: 'Terima quest', fn: () => { stats.questStatus = 'active'; stats.questProgress = 0; refreshQuest(); save(); renderDialog(); } });
  } else if (stats.questStatus === 'active') {
    text = `${q.progress} (${stats.questProgress}/${q.need})`;
  } else {
    text = q.done;
    opts.push({ label: 'Ambil hadiah', fn: () => { completeQuest(); renderDialog(); } });
  }
  opts.push({ label: `Beli Ramuan HP (${CFG.potionPrice} koin)`, fn: () => {
    if (stats.inv.gold < CFG.potionPrice) { notify('Koin tidak cukup'); return; }
    stats.inv.gold -= CFG.potionPrice; stats.inv.potion++;
    updateHud(); notify('Membeli 1 Ramuan HP'); save();
  } });
  opts.push({ label: 'Tutup', fn: closeDialog });
  $('#dialogText').textContent = text;
  const box = $('#dialogOptions');
  box.textContent = '';
  for (const o of opts) {
    const b = document.createElement('button');
    b.className = 'ui-btn'; b.textContent = o.label;
    b.addEventListener('click', o.fn);
    box.appendChild(b);
  }
}

/* ----- Tas ----- */
function renderBag() {
  $('#bagStats').textContent = `LV ${stats.level} • HP ${Math.ceil(stats.hp)}/${maxHp()} • Serangan ${attackPower()} • EXP ${stats.exp}/${expToNext()} • Koin ${stats.inv.gold}`;
  const list = $('#bagList');
  list.textContent = '';
  let any = false;
  for (const [key, def] of Object.entries(ITEMS)) {
    const n = stats.inv[key] || 0;
    if (n <= 0) continue;
    any = true;
    const li = document.createElement('li');
    const info = document.createElement('div');
    info.textContent = `${def.name} x${n}`;
    const small = document.createElement('small');
    small.textContent = def.desc;
    info.appendChild(small);
    li.appendChild(info);
    if (def.usable) {
      const b = document.createElement('button');
      b.className = 'ui-btn potion'; b.textContent = 'PAKAI';
      b.addEventListener('click', usePotion);
      li.appendChild(b);
    }
    list.appendChild(li);
  }
  if (!any) { const li = document.createElement('li'); li.textContent = 'Tas kosong.'; list.appendChild(li); }
}
function toggleBag(force) {
  if (playerDead) return;
  bagOpen = force ?? !bagOpen;
  $('#bagPanel').classList.toggle('hidden', !bagOpen);
  if (bagOpen) renderBag();
}

/* ----- Simpan / muat progres ----- */
function save() {
  try {
    localStorage.setItem(CFG.saveKey, JSON.stringify({
      v: 1, stats, ch: currentCharacter, map: mapData.name,
      x: player.position.x, z: player.position.z
    }));
  } catch { /* penyimpanan tidak tersedia */ }
}
function loadSave() {
  try {
    const raw = localStorage.getItem(CFG.saveKey);
    if (!raw) return null;
    const d = JSON.parse(raw);
    if (!d || d.v !== 1 || !d.stats) return null;
    const s = d.stats;
    stats.level = Math.max(1, s.level | 0);
    stats.exp = Math.max(0, s.exp | 0);
    stats.hp = Math.min(maxHp(), Math.max(1, Number(s.hp) || maxHp()));
    stats.inv = { potion: 0, gold: 0, fang: 0, ...s.inv };
    stats.questIndex = Math.max(0, s.questIndex | 0);
    stats.questStatus = ['inactive', 'active', 'ready'].includes(s.questStatus) ? s.questStatus : 'inactive';
    stats.questProgress = Math.max(0, s.questProgress | 0);
    return d;
  } catch { return null; }
}

/* =====================================================================
   MEMUAT / MENGGANTI PETA
   ===================================================================== */
const markerSpawn = new THREE.Mesh(
  new THREE.ConeGeometry(0.5, 1.2, 8),
  new THREE.MeshBasicMaterial({ color: 0xffe14a })
);
markerSpawn.rotation.x = Math.PI; markerSpawn.visible = false;
scene.add(markerSpawn);

function clearMap() {
  for (const e of enemies.slice()) mapGroup.remove(e.group);
  enemies.length = 0;
  mapObjects.length = 0;
  colliders.length = 0;
  npc = null;
  groundIndex = null;
  modelRoot = null;
  if (terrainMesh) { terrainMesh.geometry.dispose(); terrainMesh.material.dispose(); terrainMesh = null; }
  while (mapGroup.children.length) mapGroup.remove(mapGroup.children[0]);
}

const DEFAULT_GROUND = /ground|floor|terrain|island|land|tanah|lantai|road|jalan/i;
const NON_GROUND = /^(col|nocol|collider|sky|langit|tree|pohon)/i;

async function loadModelMap(cfg) {
  const gltf = await loader.loadAsync(cfg.url);
  const root = gltf.scene;
  root.scale.setScalar(cfg.scale);
  root.position.set(...cfg.position);
  root.rotation.y = cfg.rotY;
  mapGroup.add(root);
  root.updateMatrixWorld(true);
  modelRoot = root;

  const matcher = cfg.groundMeshes ? new RegExp(cfg.groundMeshes, 'i') : DEFAULT_GROUND;
  const meshes = [];
  root.traverse(o => { if (o.isMesh) meshes.push(o); });
  let groundMeshes = meshes.filter(m => matcher.test(m.name) && !/^(col|nocol)/i.test(m.name));
  if (!groundMeshes.length) groundMeshes = meshes.filter(m => !NON_GROUND.test(m.name));

  const index = new GroundIndex(4);
  for (const m of groundMeshes) index.addMesh(m);
  groundIndex = index.tris.length ? index : null;

  const found = { spawn: null, npc: null, enemies: [] };
  const box = new THREE.Box3(), size = new THREE.Vector3(), center = new THREE.Vector3();
  root.traverse(o => {
    if (o.isMesh) {
      if (/^(col|collider)/i.test(o.name)) {
        // Mesh "col_*" menjadi penghalang tak terlihat (lingkaran berderet untuk dinding panjang)
        o.visible = false;
        box.setFromObject(o); box.getSize(size); box.getCenter(center);
        const horizontal = size.x >= size.z;
        const rr = Math.max(0.3, (horizontal ? size.z : size.x) / 2);
        const len = horizontal ? size.x : size.z;
        const n = Math.max(1, Math.ceil(len / (rr * 2)));
        for (let i = 0; i < n; i++) {
          const f = n === 1 ? 0 : (i / (n - 1) - 0.5) * (len - rr * 2);
          colliders.push({ x: center.x + (horizontal ? f : 0), z: center.z + (horizontal ? 0 : f), r: rr });
        }
      } else {
        o.castShadow = true; o.receiveShadow = true;
        if (o.material) o.material.side = THREE.DoubleSide;
      }
    } else if (o.name) {
      o.getWorldPosition(_v);
      if (/^spawn/i.test(o.name)) found.spawn = [_v.x, _v.z];
      else if (/^npc/i.test(o.name)) found.npc = [_v.x, _v.z];
      else if (/^slime/i.test(o.name)) found.enemies.push({ t: 'slime', x: _v.x, z: _v.z });
      else if (/^goblin/i.test(o.name)) found.enemies.push({ t: 'goblin', x: _v.x, z: _v.z });
    }
  });
  if (groundIndex) {
    const b = groundIndex.box;
    bounds = { minX: b.min.x + 1, maxX: b.max.x - 1, minZ: b.min.z + 1, maxZ: b.max.z - 1 };
  }
  return found;
}

async function loadMap(data, onStatus) {
  clearMap();
  mapData = normalizeMap(data);
  Object.assign(TP, mapData.terrain);
  scene.background = new THREE.Color(mapData.sky);
  scene.fog = new THREE.Fog(mapData.sky, mapData.fog[0], mapData.fog[1]);
  spawnPoint.set(mapData.spawn[0], 0, mapData.spawn[1]);

  let found = { spawn: null, npc: null, enemies: [] };
  let modelError = false;
  if (mapData.model) {
    try { if (onStatus) onStatus('Memuat model peta...'); found = await loadModelMap(mapData.model); }
    catch (err) { console.error(err); modelError = true; notify('Model peta gagal dimuat. Periksa path di JSON.'); }
  }
  // Tanah prosedural: dipakai bila tidak ada model peta (atau model gagal dimuat)
  if (!groundIndex) {
    if (TP.type === 'none' && !mapData.model) TP.type = 'flat';
    if (modelError && TP.type === 'none') TP.type = 'flat';
    buildTerrain();
    const half = TP.size / 2 - 8;
    bounds = { minX: TP.cx - half, maxX: TP.cx + half, minZ: TP.cz - half, maxZ: TP.cz + half };
  }
  if (found.spawn) spawnPoint.set(found.spawn[0], 0, found.spawn[1]);
  spawnPoint.y = groundHeight(spawnPoint.x, spawnPoint.z, 1e9) ?? 0;

  const npcPos = found.npc || mapData.npc;
  placeNpc(npcPos[0], npcPos[1]);
  for (const d of mapData.objects) addMapObject(d);
  for (const e of mapData.enemies) spawnEnemy(e.t, e.x, e.z, e);
  for (const e of found.enemies) spawnEnemy(e.t, e.x, e.z, null);

  markerSpawn.position.set(spawnPoint.x, spawnPoint.y + 2.2, spawnPoint.z);
  refreshQuest();
}

function placePlayerAtSpawn() {
  player.position.set(spawnPoint.x, spawnPoint.y, spawnPoint.z);
  resolveColliders(player.position, 0.45);
  clampBounds(player.position);
  player.position.y = groundHeight(player.position.x, player.position.z, 1e9) ?? spawnPoint.y;
  isGrounded = true; jumpVelocity = 0;
  snapCamera();
}

function saveMapLocal() {
  try { localStorage.setItem(CFG.mapKey, JSON.stringify(mapData)); return true; } catch { return false; }
}

/* =====================================================================
   AKSI PEMAIN
   ===================================================================== */
let editMode = false;
const uiBlocked = () => playerDead || dialogOpen || bagOpen;

function nearestEnemy(maxDist) {
  let best = null, bd = maxDist;
  for (const e of enemies) {
    if (e.state !== 'alive') continue;
    const d = Math.hypot(e.group.position.x - player.position.x, e.group.position.z - player.position.z);
    if (d < bd) { bd = d; best = e; }
  }
  return best;
}

function attack() {
  if (uiBlocked() || editMode || attackTime > 0) return;
  attackTime = ATTACK_TIME;
  attackHitDone = false;
  if (anim) anim.restart = true;
  const target = nearestEnemy(4.5);
  if (target) player.rotation.y = Math.atan2(target.group.position.x - player.position.x, target.group.position.z - player.position.z);
  if (!anim) {   // model tanpa skeleton: condong ke depan + ayunan pedang
    if (weaponPivot) { weaponPivot.rotation.z = -1.35; weaponPivot.rotation.x = -0.35; }
    if (characterModel) characterModel.rotation.x = -0.22;
  }
}

function performHit() {
  const fx = Math.sin(player.rotation.y), fz = Math.cos(player.rotation.y);
  let hit = 0;
  for (const e of enemies.slice()) {
    if (e.state !== 'alive') continue;
    const dx = e.group.position.x - player.position.x, dz = e.group.position.z - player.position.z;
    const d = Math.hypot(dx, dz);
    if (d > 3.2) continue;
    if (d > 0.8 && (dx * fx + dz * fz) / d < 0.15) continue;
    damageEnemy(e, attackPower() * (0.9 + rng() * 0.2), dx / (d || 1) * 5, dz / (d || 1) * 5);
    hit++;
  }
  spawnSlash();
  if (hit) { hitStop = 0.05; shake = 0.12; }
  else notify('Ayunkan pedang!');
}

function spawnSlash() {
  const geo = new THREE.RingGeometry(0.9, 1.7, 20, 1, -Math.PI / 2 - 1.1, 2.2);
  geo.rotateX(-Math.PI / 2);
  const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color: 0xcfefff, transparent: true, opacity: 0.85, side: THREE.DoubleSide, depthWrite: false }));
  m.position.set(player.position.x, player.position.y + 1.0, player.position.z);
  m.rotation.y = player.rotation.y;
  world.add(m);
  skillEffects.push({ mesh: m, life: 0.18, max: 0.18, grow: 0.25 });
}

function jump() {
  if (uiBlocked() || !isGrounded) return;
  jumpVelocity = 7.2;
  isGrounded = false;
}

function spawnRing(color, y, maxScale) {
  const ring = new THREE.Mesh(
    new THREE.TorusGeometry(0.7, 0.09, 8, 36),
    new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.95 })
  );
  ring.rotation.x = Math.PI / 2;
  ring.position.set(player.position.x, player.position.y + y, player.position.z);
  world.add(ring);
  skillEffects.push({ mesh: ring, life: 0.75, max: 0.75, grow: maxScale });
}

function useSkill() {
  if (uiBlocked() || editMode) return;
  if (skillCooldown > 0) { notify(`Skill cooldown ${skillCooldown.toFixed(1)} dtk`); return; }
  skillCooldown = 5;
  spawnRing(0x55ddff, 0.15, 4.5);
  let hit = 0;
  for (const e of enemies.slice()) {
    if (e.state !== 'alive') continue;
    const dx = e.group.position.x - player.position.x, dz = e.group.position.z - player.position.z;
    const d = Math.hypot(dx, dz);
    if (d > 6) continue;
    damageEnemy(e, attackPower() * 1.8, dx / (d || 1) * 9, dz / (d || 1) * 9);
    hit++;
  }
  notify(hit ? `SKILL! ${hit} musuh terkena` : 'SKILL GELOMBANG ENERGI!');
}

function hurtPlayer(amount) {
  if (playerDead || invuln > 0 || editMode) return;
  stats.hp -= amount;
  invuln = 0.45; sinceHurt = 0;
  _v.copy(player.position); _v.y += 2;
  floatText(_v, `-${amount}`, 'hurt');
  const h = $('#hurt');
  h.classList.add('show');
  requestAnimationFrame(() => requestAnimationFrame(() => h.classList.remove('show')));
  shake = 0.15;
  if (stats.hp <= 0) { stats.hp = 0; playerDie(); }
  updateHud();
}

function playerDie() {
  playerDead = true;
  closeDialog(); toggleBag(false);
  joyX = joyY = 0;
  $('#deathScreen').classList.remove('hidden');
  const lost = Math.floor(stats.inv.gold * 0.1);
  stats.inv.gold -= lost;
  save();
}
function revive() {
  playerDead = false;
  stats.hp = maxHp();
  invuln = 2;
  attackTime = 0;
  if (anim) anim.restart = true;
  if (characterModel) characterModel.rotation.x = 0;
  placePlayerAtSpawn();
  $('#deathScreen').classList.add('hidden');
  updateHud(); save();
}

function distToNpc() {
  if (!npc) return Infinity;
  return Math.hypot(npc.group.position.x - player.position.x, npc.group.position.z - player.position.z);
}
function tryTalk() {
  if (uiBlocked() || editMode) return;
  if (distToNpc() < 4) openDialog();
}

/* ---------- Teks melayang (damage/loot) ---------- */
const floaters = [];
function floatText(pos, text, cls) {
  const el = document.createElement('div');
  el.className = `float ${cls || ''}`;
  el.textContent = text;
  document.body.appendChild(el);
  floaters.push({ el, pos: pos.clone(), age: 0 });
}
function updateFloaters(dt) {
  for (let i = floaters.length - 1; i >= 0; i--) {
    const f = floaters[i];
    f.age += dt;
    _v.copy(f.pos); _v.y += f.age * 1.2;
    _v.project(camera);
    if (f.age > 1 || _v.z > 1) { f.el.remove(); floaters.splice(i, 1); continue; }
    f.el.style.transform = `translate(${(_v.x * 0.5 + 0.5) * innerWidth}px, ${(-_v.y * 0.5 + 0.5) * innerHeight}px) translate(-50%, -50%)`;
    f.el.style.opacity = String(1 - f.age * f.age);
  }
}

/* =====================================================================
   EDITOR PETA (di dalam game)
   Kursor cincin di depan kamera. PASANG menaruh objek, HAPUS membuang
   objek terdekat dari kursor. SIMPAN menyimpan ke peramban, EKSPOR
   menghasilkan JSON yang bisa kamu taruh di maps/*.json.
   ===================================================================== */
let editIdx = 0, editScale = 1, editRot = 0;
const cursorMesh = new THREE.Group();
{
  const ring = new THREE.Mesh(new THREE.RingGeometry(0.55, 0.75, 28), new THREE.MeshBasicMaterial({ color: 0x55ddff, side: THREE.DoubleSide, depthTest: false, transparent: true }));
  ring.rotation.x = -Math.PI / 2; ring.renderOrder = 20;
  const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 3, 6), new THREE.MeshBasicMaterial({ color: 0x55ddff, depthTest: false, transparent: true, opacity: 0.7 }));
  beam.position.y = 1.5; beam.renderOrder = 20;
  cursorMesh.add(ring, beam);
  cursorMesh.visible = false;
  scene.add(cursorMesh);
}
const cursorPos = new THREE.Vector3();

function updateCursor() {
  const d = CFG.editorReach;
  cursorPos.set(player.position.x - Math.sin(cameraYaw) * d, 0, player.position.z - Math.cos(cameraYaw) * d);
  cursorPos.x = round1(cursorPos.x); cursorPos.z = round1(cursorPos.z);
  cursorPos.y = groundHeight(cursorPos.x, cursorPos.z, player.position.y + 6) ?? player.position.y;
  cursorMesh.position.copy(cursorPos);
}

function editInfo() {
  const t = EDIT_TYPES[editIdx];
  $('#edType').textContent = EDIT_LABELS[t];
  const isObj = !!OBJ_TYPES[t];
  $('#edInfo').textContent = isObj ? `Skala ${editScale.toFixed(1)} • Putar ${Math.round(editRot * 180 / Math.PI)}°` : '—';
  $('#edCount').textContent = `${mapData.objects.length} objek • ${mapData.enemies.length} musuh`;
}

function setEditMode(on) {
  if (on && playerDead) return;
  editMode = on;
  document.body.classList.toggle('editing', on);
  $('#editorBar').classList.toggle('hidden', !on);
  cursorMesh.visible = on;
  markerSpawn.visible = on;
  if (on) { toggleBag(false); closeDialog(); editInfo(); notify('Editor aktif: geser kanan untuk membidik, jalan untuk pindah'); }
  else { saveMapLocal(); notify('Editor ditutup, peta disimpan'); }
}

function editPlace() {
  const t = EDIT_TYPES[editIdx];
  const x = cursorPos.x, z = cursorPos.z;
  if (groundHeight(x, z, 1e9) === null) { notify('Tidak ada tanah di titik ini'); return; }
  if (OBJ_TYPES[t]) {
    if (mapObjects.length > 400) { notify('Terlalu banyak objek (maks 400)'); return; }
    const d = { t, x, z, s: round1(editScale), r: round1(editRot) };
    mapData.objects.push(d);
    addMapObject(d);
  } else if (t === 'enemy_slime' || t === 'enemy_goblin') {
    const d = { t: t === 'enemy_slime' ? 'slime' : 'goblin', x, z };
    mapData.enemies.push(d);
    spawnEnemy(d.t, x, z, d);
  } else if (t === 'npc') {
    mapData.npc = [x, z];
    placeNpc(x, z);
  } else if (t === 'spawn') {
    mapData.spawn = [x, z];
    spawnPoint.set(x, groundHeight(x, z, 1e9) ?? 0, z);
    markerSpawn.position.set(x, spawnPoint.y + 2.2, z);
  }
  editInfo();
}

function editDelete() {
  let best = null, bd = 3.2, kind = null;
  for (const o of mapObjects) {
    const d = Math.hypot(o.group.position.x - cursorPos.x, o.group.position.z - cursorPos.z) - (o.collider ? o.collider.r : 0.5);
    if (d < bd) { bd = d; best = o; kind = 'obj'; }
  }
  for (const e of enemies) {
    if (!e.data) continue; // musuh dari model peta tidak bisa dihapus di sini
    const d = Math.hypot(e.spawn.x - cursorPos.x, e.spawn.z - cursorPos.z) - 0.8;
    if (d < bd) { bd = d; best = e; kind = 'enemy'; }
  }
  if (!best) { notify('Tidak ada objek dekat kursor'); return; }
  if (kind === 'obj') removeMapObject(best); else removeEnemy(best);
  editInfo();
}

function exportMap() {
  const json = JSON.stringify(mapData, null, 1);
  try { navigator.clipboard.writeText(json).then(() => notify('JSON peta disalin ke clipboard')).catch(() => prompt('Salin JSON peta ini:', json)); }
  catch { prompt('Salin JSON peta ini:', json); }
  try {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([json], { type: 'application/json' }));
    a.download = `${mapData.name.replace(/[^\w-]+/g, '_') || 'peta'}.json`;
    document.body.appendChild(a); a.click(); a.remove();
  } catch { /* unduhan tidak didukung */ }
}

async function importMap() {
  const text = prompt('Tempel JSON peta di sini:');
  if (!text) return;
  try {
    const data = JSON.parse(text);
    await loadMap(data);
    placePlayerAtSpawn();
    saveMapLocal();
    markerSpawn.visible = editMode;
    editInfo();
    notify(`Peta "${mapData.name}" dimuat`);
  } catch (err) { console.error(err); notify('JSON tidak valid'); }
}

function resetMap() {
  if (!confirm('Kembalikan peta ke bawaan (maps/default.json)? Hasil editmu di peramban ini akan dihapus.')) return;
  try { localStorage.removeItem(CFG.mapKey); } catch { /* abaikan */ }
  location.reload();
}

/* =====================================================================
   KAMERA & LOOP UTAMA
   ===================================================================== */
function desiredCamera() {
  const target = player.position.clone().add(new THREE.Vector3(0, 1.35, 0));
  const horizontal = Math.cos(cameraPitch) * CFG.cameraDistance;
  const desired = new THREE.Vector3(
    target.x + Math.sin(cameraYaw) * horizontal,
    target.y + Math.sin(cameraPitch) * CFG.cameraDistance + 0.5,
    target.z + Math.cos(cameraYaw) * horizontal
  );
  const g = groundHeight(desired.x, desired.z, target.y + 4);
  if (g !== null) desired.y = Math.max(desired.y, g + 0.8);   // kamera tidak masuk tanah
  return { target, desired };
}
function updateCamera() {
  const { target, desired } = desiredCamera();
  camera.position.lerp(desired, 0.14);
  camera.lookAt(target);
  if (shake > 0.002) {
    camera.position.x += (Math.random() - 0.5) * shake;
    camera.position.y += (Math.random() - 0.5) * shake;
    shake *= 0.86;
  } else shake = 0;
}
function snapCamera() {
  const { target, desired } = desiredCamera();
  camera.position.copy(desired);
  camera.lookAt(target);
}

let gameStarted = false;
let fpsTime = 0, fpsFrames = 0, lowQuality = false;
const clock = new THREE.Clock();
let elapsed = 0;

function animate() {
  requestAnimationFrame(animate);
  const raw = clock.getDelta();
  const dt = Math.min(raw, 0.04);
  elapsed += dt;
  const paused = dialogOpen || bagOpen;

  fpsTime += raw; fpsFrames++;
  if (fpsTime >= 3) {
    if (!lowQuality && fpsFrames / fpsTime < 28) {
      lowQuality = true;
      maxPixelRatio = 1;
      renderer.setPixelRatio(1);
      renderer.setSize(innerWidth, innerHeight);
      sun.castShadow = false;
      notify('Mode hemat grafis aktif');
    }
    fpsTime = 0; fpsFrames = 0;
  }

  let gdt = dt;
  if (hitStop > 0) { hitStop -= raw; gdt = 0; }   // jeda singkat saat pedang mengenai musuh
  if (!paused) {
    updatePlayer(gdt);
    if (!editMode) updateEnemies(gdt, elapsed);
  }
  updateLod(dt);

  if (editMode) {
    updateCursor();
    cursorMesh.children[1].rotation.y += dt;
    markerSpawn.rotation.y += dt * 2;
  }

  if (npc) {
    npc.marker.position.y = 2.75 + Math.sin(elapsed * 3) * 0.12;
    npc.marker.rotation.y += dt * 2;
    talkBtn.classList.toggle('hidden', !(distToNpc() < 4 && !uiBlocked() && !editMode));
    if (!playerDead) {
      const dx = player.position.x - npc.group.position.x, dz = player.position.z - npc.group.position.z;
      if (Math.hypot(dx, dz) < 12) turnTo(npc.group, Math.atan2(dx, dz), dt, 5);
    }
  }

  skillEffects = skillEffects.filter(effect => {
    effect.life -= dt;
    const progress = 1 - effect.life / effect.max;
    effect.mesh.scale.setScalar(1 + progress * (effect.grow || 4.5));
    effect.mesh.material.opacity = Math.max(0, effect.life / effect.max);
    if (effect.life <= 0) { world.remove(effect.mesh); effect.mesh.geometry.dispose(); effect.mesh.material.dispose(); return false; }
    return true;
  });

  skillBtn.textContent = skillCooldown > 0 ? `SKILL ${skillCooldown.toFixed(1)}` : 'SKILL';
  skillBtn.classList.toggle('cooldown', skillCooldown > 0);

  sun.position.copy(player.position).add(SUN_OFFSET);
  sun.target.position.copy(player.position);

  updateCamera();
  updateFloaters(dt);
  renderer.render(scene, camera);
}

function updatePlayer(dt) {
  const moveX = joyX || keyX, moveY = joyY || keyY;
  const inputLength = playerDead ? 0 : Math.min(1, Math.hypot(moveX, moveY));
  const moving = inputLength > 0.08;
  invuln = Math.max(0, invuln - dt);
  sinceHurt += dt;
  const prevX = player.position.x, prevZ = player.position.z;

  if (moving) {
    const forward = new THREE.Vector3(-Math.sin(cameraYaw), 0, -Math.cos(cameraYaw));
    const right = new THREE.Vector3(Math.cos(cameraYaw), 0, -Math.sin(cameraYaw));
    const direction = forward.multiplyScalar(-moveY).add(right.multiplyScalar(moveX)).normalize();
    player.position.addScaledVector(direction, CFG.moveSpeed * inputLength * dt);
    if (attackTime <= 0) turnTo(player, Math.atan2(direction.x, direction.z), dt, 16);
    walkPhase += dt * 10.5;
  }
  if (attackTime > 0 && !playerDead && 1 - attackTime / ATTACK_TIME < 0.4) {   // maju sedikit saat menebas
    player.position.x += Math.sin(player.rotation.y) * 2.6 * dt;
    player.position.z += Math.cos(player.rotation.y) * 2.6 * dt;
  }
  resolveColliders(player.position, 0.45);
  clampBounds(player.position);

  // Pijakan tanah + lompat
  let ground = groundAt(player.position);
  if (ground === null) {              // tidak ada tanah di depan: batalkan langkah
    player.position.x = prevX; player.position.z = prevZ;
    ground = groundAt(player.position) ?? player.position.y;
  }
  if (!isGrounded) {
    player.position.y += jumpVelocity * dt;
    jumpVelocity -= 18 * dt;
    if (player.position.y <= ground) { player.position.y = ground; jumpVelocity = 0; isGrounded = true; }
  } else {
    const diff = ground - player.position.y;
    if (diff >= 0) player.position.y = ground;
    else if (diff < -0.35) { isGrounded = false; jumpVelocity = 0; }  // tanah turun tajam: jatuh
    else player.position.y = ground;
  }

  if (characterMixer) {
    if (anim) {
      // mesin status animasi: serang > lompat > jalan > diam
      const st = playerDead ? null : attackTime > 0 ? 'attack' : !isGrounded ? 'jump' : moving ? 'walk' : 'idle';
      if (st) playAnim(st, st === 'attack' ? 0.06 : 0.15);
      if (st === 'walk') anim.walk.timeScale = THREE.MathUtils.clamp(inputLength * 1.1, 0.6, 1.2);
    } else if (walkAction) walkAction.paused = !moving || !isGrounded || attackTime > 0;
    characterMixer.update(dt);
  }
  if (characterModel) {
    if (playerDead) {
      characterModel.rotation.x = THREE.MathUtils.damp(characterModel.rotation.x, -1.45, 6, dt);
    } else if (anim) {
      characterModel.position.y = characterBaseY;
      characterModel.rotation.x = THREE.MathUtils.damp(characterModel.rotation.x, 0, 10, dt);
      characterModel.rotation.z = THREE.MathUtils.damp(characterModel.rotation.z, 0, 10, dt);
    } else {
      const walkBob = moving && isGrounded ? Math.abs(Math.sin(walkPhase)) * 0.075 : 0;
      characterModel.position.y = characterBaseY + walkBob;
      characterModel.rotation.z = moving && isGrounded ? Math.sin(walkPhase * 0.5) * 0.055 : THREE.MathUtils.damp(characterModel.rotation.z, 0, 8, dt);
      if (attackTime <= 0) characterModel.rotation.x = THREE.MathUtils.damp(characterModel.rotation.x, moving ? -0.035 : 0, 7, dt);
    }
  }

  if (attackTime > 0) {
    attackTime = Math.max(0, attackTime - dt);
    const progress = 1 - attackTime / ATTACK_TIME;
    if (!attackHitDone && progress >= HIT_AT) { attackHitDone = true; performHit(); }
    if (weaponPivot && !anim) {
      weaponPivot.rotation.z = progress < 0.42 ? THREE.MathUtils.lerp(-1.35, 1.15, progress / 0.42) : THREE.MathUtils.lerp(1.15, 0, (progress - 0.42) / 0.58);
      weaponPivot.rotation.x = THREE.MathUtils.damp(weaponPivot.rotation.x, 0, 10, dt);
    }
  } else if (weaponPivot && !anim) {
    weaponPivot.rotation.z = THREE.MathUtils.damp(weaponPivot.rotation.z, 0, 12, dt);
    weaponPivot.rotation.x = THREE.MathUtils.damp(weaponPivot.rotation.x, 0, 12, dt);
  }

  skillCooldown = Math.max(0, skillCooldown - dt);

  if (!playerDead && sinceHurt > 6 && stats.hp < maxHp()) {
    stats.hp = Math.min(maxHp(), stats.hp + 1.5 * dt);
    updatePlayer.hudTimer = (updatePlayer.hudTimer || 0) + dt;
    if (updatePlayer.hudTimer > 0.25) { updatePlayer.hudTimer = 0; updateHud(); }
  }
}

/* =====================================================================
   INPUT
   ===================================================================== */
function setupJoystick() {
  const base = $('#joystick');
  const stick = $('#stick');
  let activeId = null;
  function move(e) {
    const rect = base.getBoundingClientRect();
    const cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2;
    let dx = e.clientX - cx, dy = e.clientY - cy;
    const max = rect.width * 0.32;
    const len = Math.hypot(dx, dy);
    if (len > max) { dx = dx / len * max; dy = dy / len * max; }
    stick.style.transform = `translate(${dx}px, ${dy}px)`;
    joyX = dx / max; joyY = dy / max;
  }
  base.addEventListener('pointerdown', e => { activeId = e.pointerId; base.setPointerCapture(activeId); move(e); });
  base.addEventListener('pointermove', e => { if (e.pointerId === activeId) move(e); });
  function stop(e) {
    if (e.pointerId !== activeId) return;
    activeId = null; joyX = 0; joyY = 0; stick.style.transform = 'translate(0,0)';
  }
  base.addEventListener('pointerup', stop);
  base.addEventListener('pointercancel', stop);
}
setupJoystick();

// Kamera: hanya satu jari (pointerId) yang mengendalikan kamera, tidak bentrok dengan joystick.
let camPointer = null, lastPointerX = 0, lastPointerY = 0;
renderer.domElement.addEventListener('pointerdown', e => {
  if (camPointer !== null || e.clientX < innerWidth * 0.42) return;
  camPointer = e.pointerId; lastPointerX = e.clientX; lastPointerY = e.clientY;
});
window.addEventListener('pointermove', e => {
  if (e.pointerId !== camPointer) return;
  const dx = e.clientX - lastPointerX, dy = e.clientY - lastPointerY;
  cameraYaw -= dx * 0.006;
  cameraPitch = THREE.MathUtils.clamp(cameraPitch + dy * 0.003, -0.05, 0.75);
  lastPointerX = e.clientX; lastPointerY = e.clientY;
});
const endCam = e => { if (e.pointerId === camPointer) camPointer = null; };
window.addEventListener('pointerup', endCam);
window.addEventListener('pointercancel', endCam);

$('#switchBtn').addEventListener('click', () => { if (!uiBlocked()) selectCharacter(currentCharacter === 'a' ? 'b' : 'a'); });
$('#attackBtn').addEventListener('click', attack);
$('#jumpBtn').addEventListener('click', jump);
skillBtn.addEventListener('click', useSkill);
$('#potionBtn').addEventListener('click', usePotion);
$('#bagBtn').addEventListener('click', () => toggleBag());
$('#bagClose').addEventListener('click', () => toggleBag(false));
talkBtn.addEventListener('click', tryTalk);
$('#reviveBtn').addEventListener('click', revive);
$('#resetBtn').addEventListener('click', () => {
  if (confirm('Hapus simpanan progres dan mulai dari awal? (Peta buatanmu tidak dihapus)')) {
    try { localStorage.removeItem(CFG.saveKey); } catch { /* abaikan */ }
    location.reload();
  }
});

// Editor
$('#editBtn').addEventListener('click', () => setEditMode(true));
$('#edExit').addEventListener('click', () => setEditMode(false));
$('#edPrev').addEventListener('click', () => { editIdx = (editIdx + EDIT_TYPES.length - 1) % EDIT_TYPES.length; editInfo(); });
$('#edNext').addEventListener('click', () => { editIdx = (editIdx + 1) % EDIT_TYPES.length; editInfo(); });
$('#edScaleDn').addEventListener('click', () => { editScale = Math.max(0.3, editScale - 0.2); editInfo(); });
$('#edScaleUp').addEventListener('click', () => { editScale = Math.min(4, editScale + 0.2); editInfo(); });
$('#edRot').addEventListener('click', () => { editRot = (editRot + Math.PI / 4) % (Math.PI * 2); editInfo(); });
$('#edPlace').addEventListener('click', editPlace);
$('#edDelete').addEventListener('click', editDelete);
$('#edSave').addEventListener('click', () => notify(saveMapLocal() ? 'Peta disimpan di peramban' : 'Gagal menyimpan peta'));
$('#edExport').addEventListener('click', exportMap);
$('#edImport').addEventListener('click', importMap);
$('#edReset').addEventListener('click', resetMap);

const pressed = new Set();
function syncKeys() {
  keyY = (pressed.has('s') || pressed.has('arrowdown') ? 1 : 0) - (pressed.has('w') || pressed.has('arrowup') ? 1 : 0);
  keyX = (pressed.has('d') || pressed.has('arrowright') ? 1 : 0) - (pressed.has('a') || pressed.has('arrowleft') ? 1 : 0);
}
window.addEventListener('keydown', e => {
  const k = e.key.toLowerCase();
  if (e.code === 'Space') { e.preventDefault(); jump(); return; }
  if (k === 'escape') { closeDialog(); toggleBag(false); if (editMode) setEditMode(false); return; }
  if (k === 'b') { toggleBag(); return; }
  if (uiBlocked()) return;
  pressed.add(k); syncKeys();
  if (editMode) {
    if (k === 'enter' || k === 'p') editPlace();
    if (k === 'x' || k === 'delete') editDelete();
    return;
  }
  if (k === 'j') attack();
  if (k === 'k') useSkill();
  if (k === 'h') usePotion();
  if (k === 'e') tryTalk();
  if (k === 'c') selectCharacter(currentCharacter === 'a' ? 'b' : 'a');
  if (k === 'm') setEditMode(true);
});
window.addEventListener('keyup', e => { pressed.delete(e.key.toLowerCase()); syncKeys(); });
window.addEventListener('blur', () => { pressed.clear(); syncKeys(); });

async function goLandscape() {
  try { if (!document.fullscreenElement) await document.documentElement.requestFullscreen(); } catch { /* ditolak browser */ }
  try { await screen.orientation.lock('landscape'); }
  catch { notify('Aktifkan rotasi otomatis HP lalu miringkan layar'); }
  $('#rotateHint').classList.add('dismissed');
}
$('#landscapeBtn').addEventListener('click', goLandscape);
$('#portraitBtn').addEventListener('click', () => $('#rotateHint').classList.add('dismissed'));
window.addEventListener('orientationchange', () => setTimeout(() => window.dispatchEvent(new Event('resize')), 250));

window.addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
  renderer.setPixelRatio(Math.min(devicePixelRatio, maxPixelRatio));
});
document.addEventListener('visibilitychange', () => { if (document.hidden && gameStarted) save(); });
setInterval(() => { if (gameStarted && !playerDead) save(); }, 10000);

/* =====================================================================
   MULAI GAME
   ===================================================================== */
async function fetchMapData() {
  const q = new URLSearchParams(location.search).get('map');   // contoh: index.html?map=maps/map_kosong.json
  if (q) {
    try { const r = await fetch(q); if (r.ok) return await r.json(); } catch { /* lanjut */ }
    notify('Peta dari ?map= tidak ditemukan, memakai peta lain');
  }
  try { const raw = localStorage.getItem(CFG.mapKey); if (raw) return JSON.parse(raw); } catch { /* lanjut */ }
  try { const r = await fetch(CFG.defaultMapUrl); if (r.ok) return await r.json(); } catch { /* lanjut */ }
  return {};
}

async function start() {
  try {
    setProgress(0.05, 'Menyiapkan dunia...');
    // Aset penting dulu: model karakter A (berjalan). Aset lain dimuat di latar belakang.
    let pWalk = 0;
    const upd = () => setProgress(0.1 + 0.6 * pWalk, 'Memuat karakter...');
    const walkP = loadAsset('walk', e => { if (e && e.total) pWalk = Math.min(1, e.loaded / e.total); upd(); })
      .then(() => { pWalk = 1; upd(); })
      .catch(() => loadAsset('a').then(() => { pWalk = 1; upd(); }));
    const mapRaw = await fetchMapData();
    const results = await Promise.allSettled([walkP, (async () => {
      setProgress(0.75, 'Memuat peta...');
      await loadMap(mapRaw, t => setProgress(0.8, t));
    })()]);
    if (results[1].status === 'rejected') {
      console.error(results[1].reason);
      notify('Peta bermasalah, memakai peta kosong. Periksa JSON-nya.');
      await loadMap({});
    }

    const saved = loadSave();
    if (saved && saved.map === mapData.name && Number.isFinite(saved.x) && Number.isFinite(saved.z)) {
      player.position.set(saved.x, 0, saved.z);
      resolveColliders(player.position, 0.45);
      clampBounds(player.position);
      const gy = groundHeight(player.position.x, player.position.z, 1e9);
      if (gy === null) placePlayerAtSpawn(); else { player.position.y = gy; snapCamera(); }
    } else placePlayerAtSpawn();

    if (!assets.walk && !assets.a && !assets.b) {
      addFallbackCharacter(player);
      notify('Gagal memuat GLB. Jalankan lewat server lokal Acode dan periksa folder assets.');
    } else {
      await selectCharacter(saved?.ch === 'b' ? 'b' : 'a', true);
    }

    refreshQuest();
    updateHud();
    setProgress(1, 'Siap!');
    $('#loading').classList.add('hidden');
    gameStarted = true;
    animate();
    notify(saved ? 'Selamat datang kembali, Aruna!' : `Dunia siap! ${mapData.name}`);

    loadAsset('sword').then(() => { if (characterModel && !weaponPivot) addWeapon(); }).catch(() => {});
    loadAsset('tree').then(upgradeAllObjects).catch(() => {});
    if (mapData.objects.some(o => o.t === 'maple')) loadAsset('map').then(upgradeAllObjects).catch(() => {});
    if (currentCharacter !== 'b') loadAsset('b').catch(() => {});
  } catch (err) {
    console.error(err);
    $('#loading').classList.add('hidden');
    if (!characterModel) addFallbackCharacter(player);
    if (!gameStarted) { gameStarted = true; animate(); }
    notify('Terjadi kesalahan saat memuat. Periksa konsol dan folder assets.');
  }
}
start();
