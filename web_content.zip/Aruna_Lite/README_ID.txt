# PETUALANGAN ARUNA v3 — RPG 3D untuk Acode

Jalankan `index.html` lewat Preview / server lokal Acode (bukan file://). Butuh internet saat pertama membuka (Three.js dari CDN jsDelivr).

## MEMBUAT MAP SENDIRI (ada 2 cara)

### Cara 1 — Editor di dalam game (paling mudah, bisa di HP)
1. Buka TAS (tombol TAS / tekan B) lalu tekan EDITOR MAP (atau tekan M di PC).
2. Cincin biru = kursor, selalu di depan kamera. Geser area kanan layar untuk membidik, joystick untuk pindah tempat.
3. Pilih jenis dengan tombol segitiga: pohon pinus, pohon maple, batu, semak, rumah, spawn Slime, spawn Goblin, pindah NPC, titik awal pemain.
4. S- / S+ = ukuran, PUTAR = putar 45 derajat, PASANG = taruh di kursor, HAPUS = buang objek/spawn terdekat dari kursor.
5. SIMPAN = simpan di peramban (otomatis saat KELUAR). EKSPOR = salin JSON + unduh file. IMPOR = tempel JSON peta. RESET = kembali ke maps/default.json.
6. Untuk menjadikannya peta tetap: tempel hasil EKSPOR ke `maps/default.json` (atau file baru di folder maps), lalu tekan RESET agar peta peramban tidak menimpa.

### Cara 2 — Model 3D buatanmu sendiri (Blender dll.)
1. Ekspor GLB/GLTF (Y-up, satuan meter), taruh di folder `assets/`.
2. Salin `maps/contoh_model_sendiri.json`, ubah `model.url`, lalu buka game dengan `index.html?map=maps/namafile.json`.
3. Aturan penamaan di Blender:
   - Mesh tanah/lantai: nama mengandung `ground`, `floor`, `terrain`, `island`, `land`, `tanah`, `lantai`, `road` atau `jalan`. (Atau isi `model.groundMeshes` dengan regex nama sendiri. Jika tidak ada yang cocok, semua mesh dianggap tanah kecuali yang diawali col/nocol/sky/tree/pohon.)
   - Penghalang tak terlihat (dinding, batu besar): mesh diawali `col_`. Dibuat jadi lingkaran tabrakan dan disembunyikan.
   - Empty (Plain Axes) diawali `Spawn` = titik awal pemain, `NPC` = posisi Pak Raka, `Slime...` / `Goblin...` = spawn musuh.
   - Pemain bisa menaiki tanjakan/undakan setinggi 1 m dan berjalan di jembatan/lantai bertingkat.
4. Di JSON, `"terrain": {"type": "none"}` berarti hanya model yang jadi tanah. Objek editor (pohon, batu, dsb.) tetap bisa ditambahkan di atas model.

## FORMAT maps/*.json
- name: nama peta (progres posisi hanya dipulihkan jika nama sama)
- sky: warna langit/kabut ("#9bc5d2"); fog: [dekat, jauh]
- terrain: type "hills" | "flat" | "none"; size (meter); cx, cz (pusat); amp (tinggi bukit); color (warna tanah, mis. "#c9a85b" untuk gurun, "#e8eef2" untuk salju)
- model (opsional): url, scale, position [x,y,z], rotY, groundMeshes (regex)
- spawn: [x, z]; npc: [x, z]
- objects: [{t: pine|maple|rock|bush|house, x, z, s (skala), r (rotasi radian)}]
- enemies: [{t: slime|goblin, x, z}]
Contoh: default.json (desa), map_kosong.json, gurun_contoh.json, contoh_model_sendiri.json.
Buka peta lain tanpa mengubah file: `index.html?map=maps/gurun_contoh.json`.

## Kontrol
- HP: joystick kiri = jalan; geser kanan = kamera; SERANG, LOMPAT, SKILL, GANTI KARAKTER, TAS, RAMUAN, BICARA (dekat NPC). Putar HP ke landscape (ada tombol layar penuh).
- PC: WASD/panah, drag mouse kamera, Spasi lompat, J serang, K skill, C ganti karakter, E bicara, H ramuan, B tas, M editor (Enter/P pasang, X hapus), Esc tutup.

## Fitur
Pijakan tanah, musuh Slime/Goblin dengan AI, level/EXP, NPC Pak Raka + 3 quest + toko, tas, simpan otomatis, aset 20 MB (dari 140 MB), pohon jauh memakai model sederhana (LOD) agar ringan.

## Animasi karakter (v3.1)
- Karakter A (ber-skeleton): animasi diam (napas), jalan/lari, lompat (tangan naik, kaki ditekuk), dan serang (ancang-ancang, tebas, lanjutan) dengan transisi halus. Pedang kini dipegang di tangan kanan dan ikut mengayun.
- Pose dibuat lewat kode (POSE_IDLE_A, POSE_JUMP, POSE_WINDUP, POSE_STRIKE di src/main.js) dalam bentuk arah anggota badan [kanan, atas, depan]; mudah diubah tanpa tahu sumbu tulang.
- Rasa serangan: maju sedikit saat menebas, efek garis tebasan, jeda singkat (hit-stop) dan guncangan kamera saat mengenai musuh.
- Karakter B tidak punya tulang/animasi di file GLB-nya, jadi hanya gerak sederhana (condong, naik-turun, ayun pedang). Agar B bisa beranimasi penuh, ekspor ulang B dengan skeleton (mis. dari Mixamo) memakai nama tulang yang sama dengan A (hip, waist, chest, rightUpperArm, dst.).

## Bug yang diperbaiki di v3
- Kamera dan joystick sebelumnya bisa saling ganggu saat dua jari menyentuh layar: kini kamera hanya mengikuti satu jari (pointerId).
- Karakter A tampil jauh dari pedang (mesh tersimpan di z~22 dan animasi punya root motion): dipusatkan dan dibuat jalan di tempat.
- Animasi jalan tidak menggerakkan tulang: kini clone memakai SkeletonUtils.
- Pemain/musuh bisa keluar dari tepi peta model: langkah dibatalkan jika tidak ada tanah.
- Kamera dilompatkan (snap) setelah bangkit/pindah peta agar tidak "terbang" dari jauh.
- Efek ring skill dan pijakan lompat kini memakai tinggi tanah, bukan y=0.

## Belum teruji
Kode belum bisa dijalankan di GPU/Three.js di lingkungan penyusun (hanya cek sintaks dan uji logika indeks tanah). Uji di perangkatmu dan laporkan bug: posisi pedang, arah hadap model, performa, penempatan editor.
