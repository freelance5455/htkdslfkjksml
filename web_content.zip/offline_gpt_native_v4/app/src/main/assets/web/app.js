const API = null; // Native Android bridge only; no localhost/Python backend.
let chats=[]; let currentId=null; let modalMode=null; let modalIndex=-1; let models=[]; let activeModel=null;
const BUILTIN_CATALOG=[
  {id:'llama32-1b',name:'Llama 3.2 1B Instruct',filename:'Llama-3.2-1B-Instruct-Q4_0.gguf',size_human:'737 MiB',ram_gb:2,role:'Leve e rápido'},
  {id:'llama32-3b',name:'Llama 3.2 3B Instruct',filename:'Llama-3.2-3B-Instruct-Q4_0.gguf',size_human:'1.79 GiB',ram_gb:4,role:'Mais capaz, ainda compacto'},
  {id:'deepseek-qwen15',name:'DeepSeek-R1 Distill Qwen 1.5B',filename:'DeepSeek-R1-Distill-Qwen-1.5B-Q4_0.gguf',size_human:'1019 MiB',ram_gb:3,role:'Foco em raciocínio'}
];
const $=id=>document.getElementById(id);
try{activeModel=localStorage.getItem('offline_gpt_active_model')||null}catch(_){}
const messages=$('messages'); const input=$('input');
function toast(t){$('toast').textContent=t;$('toast').classList.remove('hidden');clearTimeout(window.__toast);window.__toast=setTimeout(()=>$('toast').classList.add('hidden'),2600)}
async function api(){throw Error('NATIVE_ONLY')}
function nativeOnly(){ return !!window.OfflineGPTNative; }
function current(){return chats.find(c=>c.id===currentId)}
async function boot(){
  if(!nativeOnly()){
    chats=[{id:'local-preview',title:'Novo chat',messages:[]}]; currentId='local-preview';
    models=BUILTIN_CATALOG.map(x=>({...x,present:false,loaded:false}));
    activeModel='DeepSeek-R1-Distill-Qwen-1.5B-Q4_0.gguf'; renderModelStatus(); render();
    toast('Este projeto precisa ser compilado como aplicativo Android nativo. A visualização HTML não executa o runtime llama.cpp.'); return;
  }
  loadNativeModels(); loadLocalChats(); renderModelStatus(); render();
}
async function refreshModels(){try{let d=await api('/models');models=d.models||[];activeModel=d.active||activeModel;renderModelStatus();}catch(e){if(!models.length)models=BUILTIN_CATALOG.map(x=>({...x,present:false,loaded:false}));if(!activeModel)activeModel='DeepSeek-R1-Distill-Qwen-1.5B-Q4_0.gguf';renderModelStatus()}}
function renderModelStatus(){let m=models.find(x=>x.filename===activeModel)||models.find(x=>x.present)||models[0];let name=m?m.name:'DeepSeek-R1 Distill Qwen 1.5B';let state=m?(m.loaded?'Carregado • local':m.present?'Disponível • local':'Selecionado • aguardando arquivo GGUF'):'Selecionar modelo';$('modelName').textContent=name;$('modelState').textContent=state;$('topModelName').textContent=name;$('topModelState').textContent=state;}
function render(){renderChats();const c=current();$('chatTitle').textContent=c?.title||'Novo chat';messages.innerHTML='';if(!c||!c.messages.length){messages.innerHTML=`<div id="welcome" class="welcome"><div class="welcome-mark">✦</div><h1>Offline GPT</h1><p>Converse com um modelo de IA executado localmente.</p><div class="welcome-grid"><button data-fill="Explique como funciona uma IA local.">IA local</button><button data-fill="Me ajude a criar um projeto em Python.">Programação</button><button data-fill="Conte uma história curta e séria.">Escrita</button></div></div>`;messages.querySelectorAll('[data-fill]').forEach(b=>b.onclick=()=>{input.value=b.dataset.fill;input.focus();resizeInput()});return}c.messages.forEach((m,i)=>renderMessage(m,i));requestAnimationFrame(()=>messages.scrollTop=messages.scrollHeight)}
function renderChats(filter=''){let list=$('chatList');list.innerHTML='';chats.filter(c=>c.title.toLowerCase().includes(filter.toLowerCase())).forEach(c=>{let row=document.createElement('div');row.className='chat-item '+(c.id===currentId?'active':'');row.onclick=()=>{currentId=c.id;render();closeSidebar()};let name=document.createElement('div');name.className='chat-name';name.textContent=c.title;let del=document.createElement('button');del.className='chat-delete';del.textContent='×';del.onclick=async e=>{e.stopPropagation();if(!confirm('Apagar este chat?'))return;if(window.OfflineGPTNative){chats=chats.filter(x=>x.id!==c.id);if(!chats.length)chats=[{id:'local-'+Date.now(),title:'Novo chat',messages:[]}];currentId=chats[0].id;saveLocalChats();render();return}let d=await api('/chat/delete',{method:'POST',body:JSON.stringify({chat_id:c.id})});chats=d.chats;currentId=chats[0]?.id;render()};row.append(name,del);list.append(row)})}
function renderMessage(m,i){let wrap=document.createElement('article');wrap.className='message '+m.role;let av=document.createElement('div');av.className='avatar';av.textContent=m.role==='user'?'U':'AI';let body=document.createElement('div');body.className='message-body';body.textContent=m.content;let acts=document.createElement('div');acts.className='message-actions';
let speak=action('🔊 Ler',()=>speak(m.content));acts.append(speak);
if(m.role==='user')acts.append(action('✎ Editar',()=>openEdit(i,m.content)));else{acts.append(action('↻ Regenerar',()=>regenerate(i)));acts.append(action('↻ + instrução',()=>openInstruction(i)))}acts.append(action('⧉ Copiar',async()=>{await navigator.clipboard?.writeText(m.content);toast('Copiado')}));body.append(acts);wrap.append(av,body);messages.append(wrap)}
function action(t,fn){let b=document.createElement('button');b.textContent=t;b.onclick=fn;return b}
function speak(text){if(!('speechSynthesis'in window)){toast('A leitura em voz alta não está disponível neste WebView');return}speechSynthesis.cancel();let u=new SpeechSynthesisUtterance(text);u.lang='pt-BR';speechSynthesis.speak(u)}
async function generate(payload){
  $('sendBtn').disabled=true; $('typing').classList.remove('hidden');
  if(!nativeOnly()){
    toast('O runtime nativo não está disponível. Compile o projeto Android, não apenas a pasta HTML.');
    $('sendBtn').disabled=false; $('typing').classList.add('hidden'); return;
  }
  try { return nativeGenerate(payload); }
  catch(e){ toast('Falha ao chamar o runtime nativo: '+e.message); $('sendBtn').disabled=false; $('typing').classList.add('hidden'); }
}

function loadLocalChats(){try{chats=JSON.parse(localStorage.getItem('offline_gpt_chats')||'[]')}catch(_){chats=[]}if(!chats.length){chats=[{id:'local-'+Date.now(),title:'Novo chat',messages:[]}]}currentId=chats[0].id;try{activeModel=localStorage.getItem('offline_gpt_active_model')||'DeepSeek-R1-Distill-Qwen-1.5B-Q4_0.gguf'}catch(_){activeModel='DeepSeek-R1-Distill-Qwen-1.5B-Q4_0.gguf'}saveLocalChats()}
function saveLocalChats(){try{localStorage.setItem('offline_gpt_chats',JSON.stringify(chats))}catch(_){} }
function loadNativeModels(){try{const raw=JSON.parse(OfflineGPTNative.availableModels());models=BUILTIN_CATALOG.map(x=>{const n=raw.find(r=>r.id===x.id);return {...x,present:!!n?.present,loaded:false}})}catch(_){models=BUILTIN_CATALOG.map(x=>({...x,present:false,loaded:false}))}if(!activeModel)activeModel='DeepSeek-R1-Distill-Qwen-1.5B-Q4_0.gguf'}
function nativeGenerate(payload){const c=current();const history=JSON.stringify(c?.messages||[]);const requestId='req-'+Date.now()+'-'+Math.random().toString(16).slice(2);window.__nativePending={requestId,payload};try{OfflineGPTNative.generate(requestId,modelIdFromFilename(activeModel),payload.content||'',history)}catch(e){toast('Falha ao chamar o runtime nativo: '+e.message);$('sendBtn').disabled=false;$('typing').classList.add('hidden')}}
function modelIdFromFilename(name){const m=BUILTIN_CATALOG.find(x=>x.filename===name);return m?.id||'deepseek-qwen15'}
window.onNativeGeneration=function(requestId,answer,error){
  if(window.__nativeVariant?.requestId===requestId){const v=window.__nativeVariant;window.__nativeVariant=null;$('typing').classList.add('hidden');if(error){toast(error);return}showVariant(answer,v.instruction,v.index);return}
  if(!window.__nativePending||window.__nativePending.requestId!==requestId)return;
  const payload=window.__nativePending.payload;window.__nativePending=null;const c=current();
  if(error){toast(error);$('sendBtn').disabled=false;$('typing').classList.add('hidden');return}
  if(payload.mode==='new'){c.messages.push({role:'user',content:payload.content},{role:'assistant',content:answer})}
  else if(payload.mode==='regenerate'){c.messages[payload.response_index].content=answer}
  else if(payload.mode==='edit'){c.messages=c.messages.slice(0,payload.index);c.messages.push({role:'user',content:payload.content},{role:'assistant',content:answer})}
  saveLocalChats();render();$('sendBtn').disabled=false;$('typing').classList.add('hidden')
}
$('composer').onsubmit=e=>{e.preventDefault();let t=input.value.trim();if(!t)return;input.value='';resizeInput();generate({mode:'new',content:t})};
async function newChat(){if(window.OfflineGPTNative){const chat={id:'local-'+Date.now(),title:'Novo chat',messages:[]};chats.unshift(chat);currentId=chat.id;saveLocalChats();render();closeSidebar();input.focus();return}let d=await api('/chat/create',{method:'POST',body:JSON.stringify({title:'Novo chat'})});chats.unshift(d.chat);currentId=d.chat.id;render();closeSidebar();input.focus()}
$('newChat').onclick=newChat;$('newChatTop').onclick=newChat;
$('searchChats').oninput=e=>renderChats(e.target.value);
$('menuBtn').onclick=()=>$('sidebar').style.left='0';$('closeSidebar').onclick=closeSidebar;function closeSidebar(){$('sidebar').style.left=''}
$('modelBtn').onclick=openModels;$('modelTop').onclick=openModels;$('drawerBackdrop').onclick=closeModels;$('closeModel').onclick=closeModels;
async function openModels(){await refreshModels();$('drawerBackdrop').classList.remove('hidden');$('modelDrawer').classList.remove('hidden');let list=$('modelList');list.innerHTML='';if(!models.length)models=BUILTIN_CATALOG.map(x=>({...x,present:false,loaded:false}));models.forEach(m=>{let row=document.createElement('div');row.className='model-option '+(m.filename===activeModel?'active':'')+' '+(!m.present?'unavailable':'');let state=m.loaded?'CARREGADO':m.present?'DISPONÍVEL':'NÃO EMBUTIDO';row.innerHTML=`<span class="mi">◉</span><span class="minfo"><b>${esc(m.name)}</b><small>${esc(m.role||'Modelo local')} • ${esc(m.size_human||'')} • ${m.ram_gb||'?'} GB RAM • ${state}</small></span>`;let b=document.createElement('button');b.textContent=m.filename===activeModel?'Ativo':m.present?'Usar':'Ver detalhes';b.disabled=m.filename===activeModel;b.onclick=async e=>{e.stopPropagation();if(m.present)await selectModel(m);else toast(m.name+' ainda não está embutido neste pacote. O GGUF precisa estar em models/.')};row.onclick=()=>{if(m.present && m.filename!==activeModel)selectModel(m)};row.append(b);list.append(row)})}
async function selectModel(m){
  if(!nativeOnly()){toast('A seleção visual funciona, mas a execução exige o APK Android nativo.');return}
  if(!m.present){toast(m.name+' não está embutido neste APK. Coloque o GGUF em app/src/main/assets/models/ e gere o APK novamente.');return}
  activeModel=m.filename; try{localStorage.setItem('offline_gpt_active_model',activeModel)}catch(_){ }
  renderModelStatus(); closeModels(); toast('Modelo selecionado: '+m.name);
}
function closeModels(){$('drawerBackdrop').classList.add('hidden');$('modelDrawer').classList.add('hidden')}
$('titleBtn').onclick=()=>{let c=current();if(!c)return;openModal('Renomear chat',c.title,'rename')};
function openEdit(i,t){openModal('Editar mensagem',t,'edit',i)}
function openInstruction(i){openModal('Regenerar com nova instrução','Seja mais detalhado, mas mantenha o sentido da resposta.','instruction',i)}
function openModal(title,value,mode,index=-1){modalMode=mode;modalIndex=index;$('modalTitle').textContent=title;$('modalInput').value=value;$('modal').classList.remove('hidden');$('modalInput').focus()}
function closeModal(){$('modal').classList.add('hidden');modalMode=null;modalIndex=-1}
$('modalCancel').onclick=closeModal;$('modalSecondary').onclick=closeModal;$('modalOk').onclick=async()=>{let v=$('modalInput').value.trim();if(!v)return;let mode=modalMode,i=modalIndex;closeModal();if(mode==='rename'){if(window.OfflineGPTNative){current().title=v;saveLocalChats();render()}else{let d=await api('/chat/rename',{method:'POST',body:JSON.stringify({chat_id:currentId,title:v})});chats[chats.findIndex(c=>c.id===currentId)]=d.chat;render()}}else if(mode==='edit')await generate({mode:'edit',index:i,content:v});else if(mode==='instruction')await regenerateWithInstruction(i,v)};
async function regenerate(i){await generate({mode:'regenerate',response_index:i})}
async function regenerateWithInstruction(i,instruction){
  if(!nativeOnly()){toast('O runtime nativo não está disponível.');return}
  const c=current(); const prior=c.messages.slice(0,i); const requestId='req-'+Date.now()+'-'+Math.random().toString(16).slice(2);
  $('typing').classList.remove('hidden');
  try{
    OfflineGPTNative.generate(requestId,modelIdFromFilename(activeModel),instruction,JSON.stringify(prior));
    window.__nativeVariant={requestId,index:i,instruction};
  }catch(e){$('typing').classList.add('hidden');toast('Falha ao chamar o runtime nativo: '+e.message)}
}

function showVariant(answer,instruction,index){let old=document.querySelector('.variant');old?.remove();let box=document.createElement('div');box.className='variant';box.innerHTML=`<b>Nova resposta — instrução temporária</b><div class="variant-text"></div><div class="variant-actions"><button>🔊 Ler</button><button>Usar esta resposta</button><button>Fechar</button></div>`;box.querySelector('.variant-text').textContent=answer;let bs=box.querySelectorAll('button');bs[0].onclick=()=>speak(answer);bs[1].onclick=()=>{const c=current();if(c?.messages?.[index]){c.messages[index].content=answer;saveLocalChats();render();box.remove()}};bs[2].onclick=()=>box.remove();document.body.append(box)}
function resizeInput(){input.style.height='auto';input.style.height=Math.min(input.scrollHeight,180)+'px'}input.addEventListener('input',resizeInput);input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();$('composer').requestSubmit()}});
function esc(s){return String(s).replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]))}
boot();
