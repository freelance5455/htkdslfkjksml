Execute ../../../../download_models.sh antes de gerar o APK para embutir os três GGUF.
