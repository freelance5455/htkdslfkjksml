package com.offlinegpt

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import dev.ffmpegkit.llama.Llama
import dev.ffmpegkit.llama.LlamaConfig
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private val scope = CoroutineScope(Dispatchers.IO)
    private val generating = AtomicBoolean(false)
    private val modelNames = mapOf(
        "deepseek-qwen15" to "DeepSeek-R1-Distill-Qwen-1.5B-Q4_0.gguf",
        "llama32-1b" to "Llama-3.2-1B-Instruct-Q4_0.gguf",
        "llama32-3b" to "Llama-3.2-3B-Instruct-Q4_0.gguf"
    )

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "OfflineGPTNative")
        setContentView(web)
        web.loadUrl("file:///android_asset/web/index.html")
    }

    private fun modelFile(id: String): File? {
        val name = modelNames[id] ?: return null
        val dir = File(filesDir, "models")
        if (!dir.exists()) dir.mkdirs()
        val out = File(dir, name)
        if (out.exists() && out.length() > 0) return out
        return try {
            assets.open("models/$name").use { input ->
                FileOutputStream(out).use { output -> input.copyTo(output, 1024 * 1024) }
            }
            if (out.length() > 0) out else null
        } catch (_: Exception) {
            null
        }
    }

    private fun jsCall(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    inner class Bridge {
        @JavascriptInterface
        fun availableModels(): String = modelNames.entries.joinToString(prefix = "[", postfix = "]") { (id, file) ->
            val present = try { assets.open("models/$file").use { true } } catch (_: Exception) { false }
            "{\"id\":\"$id\",\"filename\":\"$file\",\"present\":$present}"
        }

        @JavascriptInterface
        fun generate(requestId: String, modelId: String, prompt: String, historyJson: String) {
            if (!generating.compareAndSet(false, true)) {
                jsCall("window.onNativeGeneration(${js(requestId)}, null, ${js("Outra geração ainda está em andamento.")});")
                return
            }
            scope.launch {
                try {
                    val file = modelFile(modelId)
                    if (file == null) throw IllegalStateException("O GGUF do modelo selecionado não está embutido neste APK.")
                    val history = historyJson.take(120_000)
                    val fullPrompt = buildPrompt(history, prompt)
                    val model = Llama.loadModel(
                        modelPath = file.absolutePath,
                        config = LlamaConfig(contextSize = 4096, threads = maxOf(2, Runtime.getRuntime().availableProcessors().coerceAtMost(6)))
                    )
                    val result = Llama.complete(
                        model,
                        prompt = fullPrompt,
                        systemPrompt = "Você é o Offline GPT. Responda em português do Brasil, seja útil, direto e mantenha o contexto da conversa.",
                        maxTokens = 512
                    )
                    Llama.releaseModel(model)
                    jsCall("window.onNativeGeneration(${js(requestId)}, ${js(result.text)}, null);")
                } catch (e: Exception) {
                    jsCall("window.onNativeGeneration(${js(requestId)}, null, ${js(e.message ?: "Erro ao executar o modelo.")});")
                } finally {
                    generating.set(false)
                }
            }
        }
    }

    private fun buildPrompt(history: String, current: String): String {
        return "Histórico da conversa em JSON:\n$history\n\nNova mensagem do usuário:\n$current\n\nResponda apenas à nova mensagem, levando o histórico em consideração."
    }

    private fun js(s: String): String = "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r") + "\""

    override fun onDestroy() {
        web.removeJavascriptInterface("OfflineGPTNative")
        web.destroy()
        super.onDestroy()
    }
}
