#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
DIR="$ROOT/app/src/main/assets/models"
mkdir -p "$DIR"

declare -A URLS
URLS[DeepSeek-R1-Distill-Qwen-1.5B-Q4_0.gguf]='https://huggingface.co/bartowski/DeepSeek-R1-Distill-Qwen-1.5B-GGUF/resolve/main/DeepSeek-R1-Distill-Qwen-1.5B-Q4_0.gguf'
URLS[Llama-3.2-1B-Instruct-Q4_0.gguf]='https://huggingface.co/bartowski/Llama-3.2-1B-Instruct-GGUF/resolve/main/Llama-3.2-1B-Instruct-Q4_0.gguf'
URLS[Llama-3.2-3B-Instruct-Q4_0.gguf]='https://huggingface.co/bartowski/Llama-3.2-3B-Instruct-GGUF/resolve/main/Llama-3.2-3B-Instruct-Q4_0.gguf'

for name in "${!URLS[@]}"; do
  target="$DIR/$name"
  if [ -s "$target" ]; then echo "OK: $name"; continue; fi
  echo "Baixando $name..."
  curl -L --fail --retry 3 -o "$target" "${URLS[$name]}"
done

echo
ls -lh "$DIR"/*.gguf
