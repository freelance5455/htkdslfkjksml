# Offline GPT Native v4.1

Esta versão é um **projeto Android nativo**. Ela não usa servidor Python e não tenta acessar `127.0.0.1`.

## Arquitetura

HTML/WebView → ponte JavaScript `OfflineGPTNative` → `llama-android`/llama.cpp → GGUF.

A biblioteca `dev.ffmpegkit-maintained:llama-android:0.1.1` fornece execução local de GGUF no Android. A documentação oficial mostra `Llama.loadModel()` e `Llama.complete()` e informa ABI arm64-v8a e API 24+.

## Modelos

- DeepSeek-R1-Distill-Qwen-1.5B-Q4_0.gguf — padrão
- Llama-3.2-1B-Instruct-Q4_0.gguf
- Llama-3.2-3B-Instruct-Q4_0.gguf

Os arquivos GGUF não foram falsificados nem substituídos por arquivos vazios. Eles precisam ser colocados em `app/src/main/assets/models/` antes da compilação para serem realmente embutidos no APK.

## IMPORTANTE: APKForge

Se você importar somente o HTML no APKForge/preview, a interface aparecerá, mas `MainActivity.kt` não será executado. Portanto, a ponte nativa não existirá e o modelo não poderá rodar.

Este ZIP deve ser aberto como **projeto Android/Gradle** (por exemplo, Android Studio) e compilado como APK. Não é um ZIP de página HTML.

## Build

1. Coloque os três GGUF em `app/src/main/assets/models/`.
2. Abra a raiz deste projeto no Android Studio.
3. Faça o Gradle Sync.
4. Gere o APK para `arm64-v8a`.

O DeepSeek fica selecionado por padrão, e o usuário pode trocar pelo seletor manual.
