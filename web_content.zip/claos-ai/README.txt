CLAŌS AI - Asisten Cerdas
=========================

Cara menggunakan:
1. Buka file index.html di browser (Chrome, Firefox, Safari, Edge, atau browser Android).
2. Tanyakan apa saja: matematika, coding, pengetahuan umum, dll.
3. Jawaban dilengkapi dengan link sumber Google Search.

Fitur:
- Chat interface modern mirip Claude / ChatGPT
- Dukungan matematika (hitung, integral, faktorial, dll)
- Bantuan coding (Python, JavaScript, HTML/CSS, dll)
- Sumber jawaban dari Google
- Desain responsif untuk HP & desktop
- Logo resmi CLAŌS

Cara di Android (ZArchiver):
1. Extract file ZIP ini
2. Buka folder CLAOS test
3. Ketuk index.html → buka dengan browser

Dibuat untuk pengguna CLAŌS.
Nama file: CLAOS test.zip
