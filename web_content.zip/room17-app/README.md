# المحقق: سر الغرفة رقم 17

## تشغيله كموقع
افتح `www/index.html` في أي متصفح. (الخطوط العربية تُحمَّل من الإنترنت، وبدونها يستخدم خطوط النظام.)

## بناء ملف APK للأندرويد (باستخدام Capacitor)
المتطلبات: Node.js 18+ و Android Studio.

1. افتح الطرفية داخل هذا المجلد ونفّذ:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
2. في Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)
3. ستجد الملف في: android/app/build/outputs/apk/debug/app-debug.apk

## بدون برمجة
ارفع مجلد `www` على استضافة مجانية (Netlify Drop أو GitHub Pages) ثم استخدم pwabuilder.com لتحويل الرابط إلى APK.

## تعديل اللعبة
كل شيء في ملف واحد: `www/index.html`. بعد أي تعديل نفّذ `npx cap sync android` ثم أعد البناء.
