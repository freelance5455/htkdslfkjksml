const gunnerX = document.getElementById("xA");
const gunnerY = document.getElementById("yA");
const tarX = document.getElementById("xB");
const tarY = document.getElementById("yB");
let range;
let bearing;
let azimuth;
let direction;

function calculate() {

        const xA = parseFloat(gunnerX.value);
        const yA = parseFloat(gunnerY.value);
        const xB = parseFloat(tarX.value);
        const yB = parseFloat(tarY.value);

        // Check that all inputs contain numbers
        if (
            Number.isNaN(xA) ||
            Number.isNaN(yA) ||
            Number.isNaN(xB) ||
            Number.isNaN(yB)
        ) {
            document.getElementById("result").textContent =
                "Enter all values";
            return;
        }

        // Difference between X values
        const dx = xB - xA;

        // Difference between Y values
        const dy = yB - yA;

        // Square each difference, add them,
        // take the square root, then multiply by 100
        range = (Math.sqrt(
            Math.pow(dx, 2) + Math.pow(dy, 2)
        ) * 100).toFixed(2);
        // old ver:Math.atan2(dx, dy) * 180 / Math.PI;
        bearing = (Math.atan2(dx, dy) * 180 / Math.PI + 360) % 360;
        azimuth = bearing * (6400 / 360);
        direction = getDirection(bearing);

    function getDirection(bear) {
        const directions = [
            "N","NE","E","SE","S","SW","W","NW"
        ];

        const index = Math.round(bear / 45) % 8;

    return directions[index];
    }
     // Display result
    document.getElementById("result-range").textContent =
            `~ ${range} meters`;
    document.getElementById("result-bearing").textContent =
            `~ ${bearing.toFixed(2)}° ${direction}`;    
}


    function clearTar() {
        document.getElementById("xB").value = "";
        document.getElementById("yB").value = "";
        document.getElementById("xB").focus();
    }

    function clearAll() {

        document.getElementById("xA").value = "";
        document.getElementById("yA").value = "";
        document.getElementById("xB").value = "";
        document.getElementById("yB").value = "";

        document.getElementById("result-range").textContent = "—";
        document.getElementById("result-bearing").textContent = "—";

        document.getElementById("xA").focus();
    }

    function deleteTarget(button) {
    const targetItem = button.closest(".target-item");

    if (targetItem) {
        targetItem.remove();
    }
}

let count = 0;
function save() {
        if (range === undefined || bearing === undefined || direction === undefined) {
        alert("Calculate the target first.");
        return;
    }
        const targetList = document.querySelector(".list");
        targetList.innerHTML += `
            <div class="target-item">
                <div class="target-info">
                    <div class="target-name">Target #${count += 1} <span class="target-coords">X: ${tarX.value} &nbsp; Y: ${tarY.value}</span></div>
                    <div class="my-coords">From (${"L81 Mortar"}): X: ${gunnerX.value} &nbsp; Y: ${gunnerY.value}</div>
                    <div class="target-details">Azimuth: ~${azimuth} mils <br> Elevation: ${"—"} m (WIP) <br> Estimated impact time: ${"—"}s (WIP)</div>
                </div>
                <div class="target-result">
                    <div class="range-target">
                        <span>Range</span>
                        <strong>~${range}</strong>
                    </div>
                    <div class="bearing-target">
                        <span>Bearing</span>
                        <strong>~${bearing.toFixed(2)}° ${direction}</strong>
                    </div>
                </div>
                <button class="target-delete" onclick="deleteTarget(this)">×</button>
            </div>
        ` 
}