# FitOS

Files: index.html (app), manifest.json, sw.js (offline cache), icons/.

## Run on your phone (free)
Service workers need HTTPS, so host the folder:
1. Netlify: go to app.netlify.com/drop and drag this folder in. Or GitHub Pages: upload the files to a repo, then Settings > Pages.
2. Open the URL in Chrome on Android.
3. Menu (three dots) > Install app / Add to Home screen.

## Edit your plan
Workout tab > pick a day > edit names, sets, reps, rest. Use the arrows to reorder.

## Backup / restore
Settings > Show JSON backup > Copy and save it somewhere. To restore, paste into the box and tap Import JSON.

## Limits
Data is stored in this browser only (localStorage), does not sync between devices, and can be cleared by the browser. Back up regularly.
