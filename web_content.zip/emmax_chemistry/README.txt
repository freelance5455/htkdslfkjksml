EMMAX CHEMISTRY — PROTOTYPE v1.0

WHAT'S INCLUDED
- Responsive chemistry learning dashboard
- Six starter lessons with completion tracking
- Five-question quiz with instant feedback and best score tracking
- Searchable periodic table data for 118 elements
- Safe, educational virtual lab simulations
- Demo chemistry tutor with prepared explanations (not live AI)
- Local progress tracking in the browser

RUN ON ANDROID
1. Download and extract emmax_chemistry_prototype.zip.
2. Open index.html in Chrome on your Android phone.
3. For an app-like experience, use Chrome menu (⋮) > Add to Home screen, if offered.
4. This is a web prototype. A true installable APK requires packaging/build tooling (for example, Android Studio or a web-app wrapper) and testing.

NOTES
- Progress is stored locally in the browser and may not transfer to another device/browser.
- Tutor responses are predefined; live AI needs an AI service and a secure backend. Do not put private API keys in client-side HTML.
- Virtual lab activities are simulations, not instructions for real chemical experiments.
- This prototype needs internet only to download it initially; the HTML itself has no external library dependencies.
