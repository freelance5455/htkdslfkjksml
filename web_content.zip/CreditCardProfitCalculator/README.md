# Credit Card Profit Calculator — Android APK source

This is an Android project for a two-tab calculator:
- Cash Withdrawal: editable transaction amounts; only transactions strictly greater than ₹10,000 count; default commission 0.2%; default transfer fee ₹20 per eligible transaction.
- Bill Payment: editable transaction amounts; defaults are 3% customer charge, 1.5% platform fee, 0.2% commission received and ₹0 other cost per transaction.
- Add/remove transactions, sliders plus manual entry, live totals and copy-calculation action.

## Build the APK without installing Android Studio on your phone

The project includes `.github/workflows/build-apk.yml` for a cloud build using GitHub Actions.

1. On your phone, sign in to GitHub and create a **new private repository**.
2. Upload the contents of this ZIP into the repository, preserving the folder structure. The files inside `CreditCardProfitCalculator/` should be at the repository root, including the hidden `.github` folder. If your mobile upload flow hides dot-folders, create `.github/workflows/build-apk.yml` in GitHub's web editor and paste the workflow content from this ZIP.
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. Select **Build Android APK** and tap **Run workflow**, or push/commit a change to `main`/`master` to trigger it.
5. When the workflow finishes successfully, open that run and download the artifact named `CreditCardProfitCalculator-debug-apk`.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`. Open the APK on your Android phone to install it. Android may ask you to allow installs from that browser/files app.

## Local build

Requires JDK 17 and Gradle 8.9. From this project directory run:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Notes

- This ZIP is the project source, not a prebuilt APK. The APK is created when the build succeeds.
- The app works offline and does not request internet or sensitive permissions.
- All outputs are estimates. Confirm your platform/card issuer permits the intended transactions; bill payment followed by cash withdrawal may be restricted or prohibited.
