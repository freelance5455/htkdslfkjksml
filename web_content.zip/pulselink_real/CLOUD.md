# نشر الخادم على السحابة (خطوة بخطوة)

## 1) أنشئ خادماً سحابياً
أي مزوّد VPS (DigitalOcean أو Hetzner أو AWS Lightsail أو غيرها): Ubuntu 22.04 أو أحدث، بذاكرة 1-2 جيجا تكفي للبداية.
سجّل عنوان IP العام للخادم.

## 2) اشترِ/وجّه دومين
أضف سجل `A` عند مزوّد الدومين يشير لـ IP الخادم (مثال: `app.example.com`). انتظر دقائق حتى ينتشر.

## 3) افتح المنافذ
في جدار حماية المزوّد افتح: 22 (SSH) و80 و443.

## 4) ارفع المشروع وشغّله
```bash
scp pulselink_real.zip root@IP_الخادم:~
ssh root@IP_الخادم
apt-get update && apt-get install -y unzip
unzip pulselink_real.zip && cd pulselink_real
bash deploy.sh
```
السكربت يثبّت Docker، يولّد كل الأسرار ومفاتيح التنبيهات، ويشغّل قاعدة البيانات والخادم وشهادة HTTPS تلقائياً (Caddy).
في النهاية يطبع الرابط ومفتاح الإدارة. **احفظ مفتاح الإدارة** (موجود أيضاً في `.env`).

## 5) تحقق
- `https://دومينك/healthz` يجب أن يعرض `ok`.
- افتح `https://دومينك` على هاتفين، سجّل مصاباً ومسعفاً، ثم وثّق المسعف:
```bash
curl -H "x-admin-key: KEY" https://دومينك/api/admin/rescuers
curl -X POST -H "x-admin-key: KEY" -H "Content-Type: application/json" -d '{"userId":2}' https://دومينك/api/admin/verify
```

## 6) صيانة
- تحديث بعد تعديل الكود: `docker compose up -d --build`
- السجلات: `docker compose logs -f app`
- نسخ احتياطي يومي (أضفه بـ `crontab -e`):
  `0 3 * * * cd ~/pulselink_real && docker compose exec -T db pg_dump -U pulselink pulselink | gzip > ~/backup_$(date +\%F).sql.gz`
  وانقل النسخ خارج الخادم.
- فعّل النسخ الاحتياطي للقرص (snapshots) عند مزوّد السحابة وراقب الخادم بخدمة uptime.

## تنبيه
لا تغيّر مفاتيح VAPID بعد التشغيل، فستتوقف تنبيهات الأجهزة المسجّلة. وراجع قائمة المتطلبات في README.md (رمز SMS، توثيق المسعفين، الجانب القانوني) قبل الاستخدام الحقيقي.
