CREATE EXTENSION IF NOT EXISTS postgis;
CREATE TABLE users(id SERIAL PRIMARY KEY,name TEXT NOT NULL,phone TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN('patient','rescuer')),is_verified BOOLEAN NOT NULL DEFAULT FALSE,created_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE rescuer_profiles(user_id INT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 current_location GEOGRAPHY(Point,4326),is_available BOOLEAN NOT NULL DEFAULT FALSE,last_updated TIMESTAMPTZ DEFAULT NOW());
CREATE INDEX ON rescuer_profiles USING GIST(current_location);
CREATE TABLE push_subscriptions(id SERIAL PRIMARY KEY,user_id INT REFERENCES users(id) ON DELETE CASCADE,endpoint TEXT UNIQUE NOT NULL,data JSONB NOT NULL);
CREATE TABLE emergencies(id SERIAL PRIMARY KEY,patient_id INT NOT NULL REFERENCES users(id),rescuer_id INT REFERENCES users(id),
 incident_location GEOGRAPHY(Point,4326) NOT NULL,emergency_type TEXT,note TEXT DEFAULT '',
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN('pending','accepted','done','cancelled','expired')),
 level INT NOT NULL DEFAULT 0,notified_ids INT[] NOT NULL DEFAULT '{}',
 created_at TIMESTAMPTZ DEFAULT NOW(),accepted_at TIMESTAMPTZ,completed_at TIMESTAMPTZ);
CREATE INDEX ON emergencies(status);
CREATE INDEX ON emergencies USING GIST(incident_location);
CREATE TABLE messages(id SERIAL PRIMARY KEY,emergency_id INT REFERENCES emergencies(id),sender_id INT REFERENCES users(id),body TEXT NOT NULL,created_at TIMESTAMPTZ DEFAULT NOW());
