self.addEventListener('push',e=>{
  const d=e.data?e.data.json():{};
  e.waitUntil(self.registration.showNotification(d.title||'🚨 طوارئ',{body:d.body||'',tag:'em'+d.emergencyId,requireInteraction:true,renotify:true,vibrate:[300,150,300,150,300],data:d}));
});
self.addEventListener('notificationclick',e=>{
  e.notification.close();
  const id=(e.notification.data||{}).emergencyId;
  e.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(l=>{
    if(l.length){l[0].focus();l[0].postMessage({open:id});return}
    return clients.openWindow('/?e='+id);
  }));
});
