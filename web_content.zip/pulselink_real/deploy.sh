#!/usr/bin/env bash
# تشغيل: sudo bash deploy.sh   (على خادم Ubuntu/Debian جديد)
set -e
cd "$(dirname "$0")"
command -v docker >/dev/null || curl -fsSL https://get.docker.com | sh

if [ ! -f .env ]; then
  read -p "الدومين الموجّه لهذا الخادم (مثال: app.example.com): " DOMAIN
  read -p "رقم الإسعاف في بلدك [123]: " NUM; NUM=${NUM:-123}
  read -p "بريدك (لشهادة HTTPS وتنبيهات النظام): " MAIL
  PG=$(openssl rand -hex 16)
  IMG=$(docker build -q .)
  KEYS=$(docker run --rm "$IMG" node -e "const k=require('web-push').generateVAPIDKeys();console.log(k.publicKey+' '+k.privateKey)")
  cat > .env <<ENV
DOMAIN=$DOMAIN
POSTGRES_PASSWORD=$PG
DATABASE_URL=postgres://pulselink:$PG@db:5432/pulselink
JWT_SECRET=$(openssl rand -hex 32)
ADMIN_KEY=$(openssl rand -hex 16)
VAPID_PUBLIC=${KEYS%% *}
VAPID_PRIVATE=${KEYS##* }
VAPID_SUBJECT=mailto:$MAIL
EMERGENCY_NUMBER=$NUM
NOTIFY_RADIUS_M=10000
PORT=3000
ENV
  chmod 600 .env
fi

docker compose up -d --build
echo
echo "تم. افتح: https://$(grep ^DOMAIN= .env | cut -d= -f2)"
echo "مفتاح الإدارة (احفظه): $(grep ^ADMIN_KEY= .env | cut -d= -f2)"
echo "السجلات: docker compose logs -f app"
