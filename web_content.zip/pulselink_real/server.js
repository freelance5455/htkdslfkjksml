require('dotenv').config();
const express=require('express'),http=require('http'),path=require('path'),fs=require('fs'),crypto=require('crypto');
const {Server}=require('socket.io'),{Pool}=require('pg'),webpush=require('web-push');
const jwt=require('jsonwebtoken'),bcrypt=require('bcryptjs'),helmet=require('helmet'),rateLimit=require('express-rate-limit');
const E=process.env;
['DATABASE_URL','JWT_SECRET','ADMIN_KEY','VAPID_PUBLIC','VAPID_PRIVATE'].forEach(k=>{if(!E[k]){console.error('Missing env '+k);process.exit(1)}});
if(E.JWT_SECRET.length<32){console.error('JWT_SECRET too short');process.exit(1)}
webpush.setVapidDetails(E.VAPID_SUBJECT||'mailto:admin@example.com',E.VAPID_PUBLIC,E.VAPID_PRIVATE);
const pool=new Pool({connectionString:E.DATABASE_URL});
const app=express(),server=http.createServer(app),io=new Server(server);
app.set('trust proxy',1);
const page=fs.readFileSync(path.join(__dirname,'public','index.html'),'utf8');
const hashes=[...page.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m=>"'sha256-"+crypto.createHash('sha256').update(m[1]).digest('base64')+"'");
app.use(helmet({contentSecurityPolicy:{directives:{defaultSrc:["'self'"],scriptSrc:["'self'",...hashes],styleSrc:["'self'","'unsafe-inline'"],connectSrc:["'self'","wss:","ws:"],imgSrc:["'self'","data:"]}}}));
app.get('/healthz',(q,s)=>s.send('ok'));
app.use(express.json({limit:'20kb'}));
app.use(rateLimit({windowMs:60000,max:120}));
app.use(express.static(path.join(__dirname,'public')));

const wrap=f=>(q,s)=>f(q,s).catch(e=>{console.error(e);s.status(500).json({error:'خطأ في الخادم'})});
const num=(v,a,b)=>typeof v==='number'&&isFinite(v)&&v>=a&&v<=b;
const sign=u=>jwt.sign({id:u.id,role:u.role},E.JWT_SECRET,{expiresIn:'30d'});
function auth(q,s,n){try{q.user=jwt.verify((q.headers.authorization||'').slice(7),E.JWT_SECRET);n()}catch(e){s.status(401).json({error:'غير مصرّح'})}}
const need=r=>(q,s,n)=>q.user.role===r?n():s.status(403).json({error:'غير مسموح'});
const admin=(q,s,n)=>q.headers['x-admin-key']===E.ADMIN_KEY?n():s.sendStatus(403);
const authLim=rateLimit({windowMs:15*60000,max:20});
const trigLim=rateLimit({windowMs:10*60000,max:6,keyGenerator:q=>'u'+q.user.id});

app.get('/api/config',(q,s)=>s.json({vapid:E.VAPID_PUBLIC,number:E.EMERGENCY_NUMBER||'123'}));

app.post('/api/auth/register',authLim,wrap(async(q,s)=>{
  const {name,phone,password,role}=q.body||{};
  if(!name||!/^\+?\d{8,15}$/.test(phone||'')||!password||password.length<8||!['patient','rescuer'].includes(role))
    return s.status(400).json({error:'بيانات غير صالحة (كلمة المرور 8 أحرف على الأقل)'});
  try{
    const r=await pool.query('INSERT INTO users(name,phone,password_hash,role) VALUES($1,$2,$3,$4) RETURNING id,name,role,is_verified',[String(name).trim().slice(0,60),phone,await bcrypt.hash(password,10),role]);
    if(role==='rescuer')await pool.query('INSERT INTO rescuer_profiles(user_id) VALUES($1)',[r.rows[0].id]);
    s.json({token:sign(r.rows[0])});
  }catch(e){if(e.code==='23505')return s.status(409).json({error:'الرقم مسجّل مسبقاً'});throw e}
}));
app.post('/api/auth/login',authLim,wrap(async(q,s)=>{
  const {phone,password}=q.body||{};
  const r=await pool.query('SELECT id,role,password_hash FROM users WHERE phone=$1',[phone||'']);
  if(!r.rows[0]||!(await bcrypt.compare(String(password||''),r.rows[0].password_hash)))return s.status(401).json({error:'بيانات الدخول غير صحيحة'});
  s.json({token:sign(r.rows[0])});
}));
app.get('/api/me',auth,wrap(async(q,s)=>{
  const r=await pool.query('SELECT id,name,phone,role,is_verified FROM users WHERE id=$1',[q.user.id]);
  r.rows[0]?s.json(r.rows[0]):s.sendStatus(401);
}));
app.post('/api/push/subscribe',auth,wrap(async(q,s)=>{
  const sub=q.body&&q.body.subscription;if(!sub||!sub.endpoint)return s.sendStatus(400);
  await pool.query('INSERT INTO push_subscriptions(user_id,endpoint,data) VALUES($1,$2,$3) ON CONFLICT(endpoint) DO UPDATE SET user_id=$1,data=$3',[q.user.id,sub.endpoint,sub]);
  s.json({ok:true});
}));

async function pushTo(ids,payload){
  if(!ids.length)return;
  const r=await pool.query('SELECT endpoint,data FROM push_subscriptions WHERE user_id=ANY($1)',[ids]);
  await Promise.all(r.rows.map(x=>webpush.sendNotification(x.data,JSON.stringify(payload),{urgency:'high',TTL:90})
    .catch(e=>{if(e.statusCode===404||e.statusCode===410)pool.query('DELETE FROM push_subscriptions WHERE endpoint=$1',[x.endpoint])})));
}
const CASE=`SELECT e.id,e.status,e.emergency_type,e.patient_id,e.rescuer_id,e.notified_ids,e.note,ST_Y(e.incident_location::geometry) lat,ST_X(e.incident_location::geometry) lng,
 p.name patient_name,p.phone patient_phone,r.name rescuer_name,r.phone rescuer_phone FROM emergencies e JOIN users p ON p.id=e.patient_id LEFT JOIN users r ON r.id=e.rescuer_id WHERE e.id=$1`;
const caseOf=async id=>(await pool.query(CASE,[id])).rows[0];
const pub=d=>{if(!d)return null;const x=Object.assign({},d);delete x.notified_ids;return x};
const RADIUS=parseInt(E.NOTIFY_RADIUS_M)||10000; // نطاق التنبيه: 10 كم افتراضياً

async function dispatch(id){
  const e=(await pool.query("SELECT emergency_type,level,notified_ids,ST_Y(incident_location::geometry) lat,ST_X(incident_location::geometry) lng FROM emergencies WHERE id=$1 AND status='pending'",[id])).rows[0];
  if(!e)return 0;
  const r=await pool.query(`SELECT u.id FROM rescuer_profiles r JOIN users u ON u.id=r.user_id
    WHERE r.is_available AND u.is_verified AND r.last_updated>NOW()-INTERVAL '10 minutes' AND NOT(u.id=ANY($3::int[]))
    AND ST_DWithin(r.current_location,ST_SetSRID(ST_MakePoint($1,$2),4326)::geography,$4)`,[e.lng,e.lat,e.notified_ids,RADIUS]);
  const ids=r.rows.map(x=>x.id);
  if(!ids.length)return 0;
  await pool.query('UPDATE emergencies SET notified_ids=notified_ids||$2::int[] WHERE id=$1',[id,ids]);
  const p={emergencyId:id,type:e.emergency_type,lat:e.lat,lng:e.lng,title:'🚨 طوارئ قريبة منك',body:'نوع الحالة: '+e.emergency_type};
  ids.forEach(u=>io.to('user_'+u).emit('new_emergency',p));
  await pushTo(ids,p);
  return ids.length;
}

app.post('/api/emergency/trigger',auth,need('patient'),trigLim,wrap(async(q,s)=>{
  const {lat,lng,emergencyType,note}=q.body||{};
  if(!num(lat,-90,90)||!num(lng,-180,180))return s.status(400).json({error:'إحداثيات غير صالحة'});
  const act=await pool.query("SELECT id FROM emergencies WHERE patient_id=$1 AND status IN('pending','accepted')",[q.user.id]);
  if(act.rows[0])return s.status(409).json({error:'لديك حالة نشطة',emergencyId:act.rows[0].id});
  const r=await pool.query("INSERT INTO emergencies(patient_id,incident_location,emergency_type,note) VALUES($1,ST_SetSRID(ST_MakePoint($2,$3),4326)::geography,$4,$5) RETURNING id",
    [q.user.id,lng,lat,String(emergencyType||'طوارئ عامة').slice(0,40),String(note||'').slice(0,200)]);
  const n=await dispatch(r.rows[0].id);
  s.json({success:true,emergencyId:r.rows[0].id,notified:n});
}));

app.post('/api/emergency/accept',auth,need('rescuer'),wrap(async(q,s)=>{
  const id=parseInt(q.body&&q.body.emergencyId);if(!id)return s.sendStatus(400);
  const c=await pool.connect();let denied=null;
  try{
    await c.query('BEGIN');
    const v=await c.query('SELECT is_verified FROM users WHERE id=$1',[q.user.id]);
    const e=await c.query('SELECT status FROM emergencies WHERE id=$1 FOR UPDATE',[id]);
    if(!v.rows[0]||!v.rows[0].is_verified)denied=[403,'حسابك غير موثّق بعد'];
    else if(!e.rows[0]||e.rows[0].status!=='pending')denied=[409,'قُبلت الحالة مسبقاً أو انتهت'];
    if(denied){await c.query('ROLLBACK')}else{
      await c.query("UPDATE emergencies SET status='accepted',rescuer_id=$1,accepted_at=NOW() WHERE id=$2",[q.user.id,id]);
      await c.query('UPDATE rescuer_profiles SET is_available=FALSE WHERE user_id=$1',[q.user.id]);
      await c.query('COMMIT');
    }
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}
  if(denied)return s.status(denied[0]).json({message:denied[1]});
  const d=await caseOf(id);
  io.to('user_'+d.patient_id).emit('case_update',pub(d));
  d.notified_ids.filter(u=>u!==q.user.id).forEach(u=>io.to('user_'+u).emit('dismiss',{emergencyId:id}));
  s.json({success:true,case:pub(d)});
}));

app.post('/api/emergency/:id/end',auth,wrap(async(q,s)=>{
  const id=parseInt(q.params.id),d=await caseOf(id);
  if(!d||![d.patient_id,d.rescuer_id].includes(q.user.id)||!['pending','accepted'].includes(d.status))return s.sendStatus(404);
  const st=(q.user.id===d.patient_id&&d.status==='pending')?'cancelled':'done';
  await pool.query('UPDATE emergencies SET status=$1,completed_at=NOW() WHERE id=$2',[st,id]);
  if(d.rescuer_id)await pool.query('UPDATE rescuer_profiles SET is_available=TRUE WHERE user_id=$1',[d.rescuer_id]);
  d.status=st;
  [d.patient_id,d.rescuer_id].filter(Boolean).forEach(u=>io.to('user_'+u).emit('case_update',pub(d)));
  d.notified_ids.forEach(u=>io.to('user_'+u).emit('dismiss',{emergencyId:id}));
  s.json({success:true});
}));
app.get('/api/emergency/active',auth,wrap(async(q,s)=>{
  const r=await pool.query("SELECT id FROM emergencies WHERE (patient_id=$1 OR rescuer_id=$1) AND status IN('pending','accepted') ORDER BY id DESC LIMIT 1",[q.user.id]);
  s.json({case:r.rows[0]?pub(await caseOf(r.rows[0].id)):null});
}));
app.get('/api/emergency/pending',auth,need('rescuer'),wrap(async(q,s)=>{
  const r=await pool.query("SELECT id AS \"emergencyId\",emergency_type AS type,ST_Y(incident_location::geometry) lat,ST_X(incident_location::geometry) lng FROM emergencies WHERE status='pending' AND $1=ANY(notified_ids) AND created_at>NOW()-INTERVAL '10 minutes'",[q.user.id]);
  s.json({list:r.rows});
}));
app.get('/api/emergency/:id/messages',auth,wrap(async(q,s)=>{
  const id=parseInt(q.params.id),d=await caseOf(id);
  if(!d||![d.patient_id,d.rescuer_id].includes(q.user.id))return s.sendStatus(404);
  const r=await pool.query('SELECT sender_id AS "from",body AS text FROM messages WHERE emergency_id=$1 ORDER BY id',[id]);
  s.json({list:r.rows});
}));
app.post('/api/rescuer/availability',auth,need('rescuer'),wrap(async(q,s)=>{
  const {available,lat,lng}=q.body||{};
  if(available){
    if(!num(lat,-90,90)||!num(lng,-180,180))return s.status(400).json({error:'الموقع مطلوب'});
    await pool.query('UPDATE rescuer_profiles SET is_available=TRUE,current_location=ST_SetSRID(ST_MakePoint($2,$3),4326)::geography,last_updated=NOW() WHERE user_id=$1',[q.user.id,lng,lat]);
  }else await pool.query('UPDATE rescuer_profiles SET is_available=FALSE WHERE user_id=$1',[q.user.id]);
  s.json({success:true});
}));
app.get('/api/admin/rescuers',admin,wrap(async(q,s)=>s.json((await pool.query("SELECT id,name,phone,is_verified FROM users WHERE role='rescuer' ORDER BY id")).rows)));
app.post('/api/admin/verify',admin,wrap(async(q,s)=>{
  await pool.query('UPDATE users SET is_verified=$2 WHERE id=$1 AND role=\'rescuer\'',[parseInt(q.body.userId),q.body.verified!==false]);s.json({ok:true});
}));

io.use((s,n)=>{try{s.user=jwt.verify(s.handshake.auth.token,E.JWT_SECRET);n()}catch(e){n(new Error('unauthorized'))}});
io.on('connection',s=>{
  s.join('user_'+s.user.id);s.cases=new Set();s.lastChat=0;s.lastLoc=0;
  s.on('join_case',async id=>{
    const d=await caseOf(parseInt(id)).catch(()=>null);
    if(d&&[d.patient_id,d.rescuer_id].includes(s.user.id)){s.cases.add(d.id);s.join('case_'+d.id)}
  });
  s.on('loc',async m=>{
    if(!m||!num(m.lat,-90,90)||!num(m.lng,-180,180)||Date.now()-s.lastLoc<3000)return;
    s.lastLoc=Date.now();
    if(s.user.role==='rescuer')await pool.query('UPDATE rescuer_profiles SET current_location=ST_SetSRID(ST_MakePoint($2,$3),4326)::geography,last_updated=NOW() WHERE user_id=$1',[s.user.id,m.lng,m.lat]).catch(console.error);
    const id=parseInt(m.caseId);
    if(s.cases.has(id))s.to('case_'+id).emit('peer_loc',{lat:m.lat,lng:m.lng});
  });
  s.on('chat',async m=>{
    const id=parseInt(m&&m.caseId),t=String((m&&m.text)||'').trim().slice(0,500);
    if(!t||!s.cases.has(id)||Date.now()-s.lastChat<500)return;
    s.lastChat=Date.now();
    await pool.query('INSERT INTO messages(emergency_id,sender_id,body) VALUES($1,$2,$3)',[id,s.user.id,t]).catch(console.error);
    io.to('case_'+id).emit('chat',{caseId:id,from:s.user.id,text:t});
  });
});

// إعادة البحث بعد 45ث و120ث عن مسعفين أصبحوا متاحين ضمن نفس النطاق، وانتهاء الحالة بعد 10 دقائق
setInterval(async()=>{try{
  const r=await pool.query("SELECT id,patient_id,level,EXTRACT(EPOCH FROM NOW()-created_at) AS age FROM emergencies WHERE status='pending'");
  for(const e of r.rows){
    if(e.age>600){await pool.query("UPDATE emergencies SET status='expired' WHERE id=$1",[e.id]);io.to('user_'+e.patient_id).emit('case_update',pub(await caseOf(e.id)));continue}
    const lvl=e.age>120?2:e.age>45?1:0;
    if(lvl>e.level){await pool.query('UPDATE emergencies SET level=$2 WHERE id=$1',[e.id,lvl]);await dispatch(e.id);io.to('user_'+e.patient_id).emit('escalated',{level:lvl})}
  }
}catch(err){console.error(err)}},15000);

server.listen(E.PORT||3000,()=>console.log('PulseLink on '+(E.PORT||3000)));
