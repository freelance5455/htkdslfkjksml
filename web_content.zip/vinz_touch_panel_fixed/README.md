# Vinz Touch Panel (corrected package)

Application ID/package: `com.vinz.app` (matches the package shown in the user's AX Manager screenshot).

Includes:
- Android WebView wrapper
- Shizuku Binder status check
- Shizuku permission request
- JS bridge to display real authorization state in the page
- Launch intent for package `com.dts.freefiremax`
- X/Y sliders and acceleration toggle (UI only)

Important: this fixes the package mismatch and connects the permission status to the WebView. It does NOT provide a verified ColorOS/touchscreen API to change Free Fire's internal sensitivity or touch acceleration. A Shizuku grant is not proof those controls can be changed.

This is source code, not a prebuilt APK. Build with a compatible Android Gradle environment and JDK 17.
