package com.vinz.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.TextView;
import android.view.View;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int REQUEST_CODE = 7321;
    private WebView web;
    private TextView status;

    private final Shizuku.OnRequestPermissionResultListener permissionListener =
        (requestCode, grantResult) -> {
            if (requestCode == REQUEST_CODE) {
                runOnUiThread(() -> publishStatus(
                    grantResult == PackageManager.PERMISSION_GRANTED
                        ? "AUTHORIZED"
                        : "DENIED"));
            }
        };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        status = new TextView(this);
        status.setPadding(16, 12, 16, 12);
        status.setText("Memeriksa Shizuku…");
        root.addView(status);

        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.addJavascriptInterface(new Bridge(), "VinzNative");
        web.setWebViewClient(new WebViewClient());
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        Shizuku.addRequestPermissionResultListener(permissionListener);
        web.loadUrl("file:///android_asset/index.html");
        refreshStatus();
    }

    private void publishStatus(String state) {
        if (status != null) status.setText("Shizuku: " + state);
        if (web != null) web.evaluateJavascript(
            "window.onShizukuStatus && window.onShizukuStatus('" + state + "')", null);
    }

    private void refreshStatus() {
        try {
            if (!Shizuku.pingBinder()) publishStatus("SERVICE_NOT_RUNNING");
            else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED)
                publishStatus("AUTHORIZED");
            else publishStatus("NOT_AUTHORIZED");
        } catch (Exception e) {
            publishStatus("CHECK_ERROR");
        }
    }

    public class Bridge {
        @JavascriptInterface public String shizukuState() {
            try {
                if (!Shizuku.pingBinder()) return "SERVICE_NOT_RUNNING";
                return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
                    ? "AUTHORIZED" : "NOT_AUTHORIZED";
            } catch (Exception e) { return "CHECK_ERROR"; }
        }
        @JavascriptInterface public void requestShizuku() {
            runOnUiThread(() -> {
                try {
                    if (!Shizuku.pingBinder()) { publishStatus("SERVICE_NOT_RUNNING"); return; }
                    if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                        publishStatus("AUTHORIZED"); return;
                    }
                    Shizuku.requestPermission(REQUEST_CODE);
                    publishStatus("REQUEST_SENT");
                } catch (Exception e) { publishStatus("REQUEST_ERROR"); }
            });
        }
        @JavascriptInterface public void openFreeFire() {
            runOnUiThread(() -> {
                Intent i = getPackageManager().getLaunchIntentForPackage("com.dts.freefiremax");
                if (i != null) startActivity(i); else publishStatus("FFMAX_NOT_FOUND");
            });
        }
    }

    @Override protected void onResume() { super.onResume(); refreshStatus(); }
    @Override protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
