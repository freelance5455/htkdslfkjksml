BRAND CRACK AI — Android Studio Project

এই ZIP-এ Android Studio source project আছে। এটি APK নয়। Android Studio-তে folder open করে Gradle sync/build করে APK তৈরি করতে হবে।

যা আছে:
- আপনার দেওয়া আগের Firebase Realtime Database URL ব্যবহার করে falcon_config এবং users/{name} পড়া/লেখার চেষ্টা
- আগের admin panel আলাদা করে তৈরি করা হয়নি
- স্ক্রিনশট/ছবি থেকে OCR
- LIVE SCREEN SCAN (ANDROID): Android-এর system screen-record permission চাইবে, অনুমতি দিলে একটি frame নিয়ে OCR করবে
- Gemini API key অ্যাপের ভেতরে hardcode করা নেই; Scan screen-এ নিজে দিতে হবে
- ভিডিওর মতো neon scanning/analysis interface

সীমাবদ্ধতা ও নিরাপত্তা:
- Screen capture গোপনে চলে না; Android permission অবশ্যই দিতে হবে। এই build একবারে একটি screen frame নেয়, অবিরাম background scanning নয়।
- Gemini/OCR analysis কোনো গেম/মার্কেটের পরবর্তী ফল নিশ্চিতভাবে বলতে পারে না। UP/BULLISH বা BIG/SMALL-কে নিশ্চিত prediction ভাববেন না।
- Firebase rules/config আপনার বর্তমান ডাটাবেসের ওপর নির্ভরশীল। Login কাজ করতে falcon_config/password এবং users rules সঠিক থাকতে হবে। Database rules খুব খোলা করে দেবেন না।
- Gemini key আগে chat-এ প্রকাশ হয়ে থাকলে Google AI Studio থেকে key revoke করে নতুন key তৈরি করুন। Client app-এ API key দিলে সেটি পুরোপুরি গোপন থাকে না।

Build:
1. ZIP extract করুন।
2. Android Studio > Open > BRAND_CRACK_AI_Android folder।
3. Gradle sync শেষ হলে Build > Build APK(s)।
4. app/build/outputs/apk/debug/app-debug.apk থেকে APK পাবেন।

Internet permission Firebase/Gemini/remote OCR library-র জন্য লাগে। OCR library প্রথমবার download করতে ইন্টারনেট লাগতে পারে।
