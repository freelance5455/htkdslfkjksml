package com.brandcrack.ai;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.Uri;
import android.webkit.ValueCallback;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;

public class MainActivity extends Activity {
  private static final int PICK=44, CAPTURE=45;
  private WebView web; private ValueCallback<Uri[]> upload;
  private MediaProjectionManager projectionManager; private MediaProjection projection;
  private ImageReader reader; private android.hardware.display.VirtualDisplay virtualDisplay;
  private final Handler handler = new Handler(Looper.getMainLooper());

  @Override public void onCreate(Bundle b){super.onCreate(b);
    projectionManager=(MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
    web=new WebView(this); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.getSettings().setAllowFileAccess(true);
    web.setWebViewClient(new WebViewClient());
    web.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){upload=cb;Intent i=new Intent(Intent.ACTION_GET_CONTENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(Intent.createChooser(i,"Choose screenshot"),PICK);return true;}});
    web.addJavascriptInterface(new Bridge(),"NativeScanner"); setContentView(web); web.loadUrl("file:///android_asset/index.html");
  }
  private class Bridge { @JavascriptInterface public void startScreenCapture(){runOnUiThread(()->startActivityForResult(projectionManager.createScreenCaptureIntent(),CAPTURE));} }
  @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);
    if(r==PICK&&upload!=null){upload.onReceiveValue(c==RESULT_OK&&d!=null?new Uri[]{d.getData()}:null);upload=null;}
    if(r==CAPTURE){if(c==RESULT_OK&&d!=null){try{projection=projectionManager.getMediaProjection(c,d);captureOneFrame();}catch(Exception e){sendError(e.getMessage());}}else sendError("Screen capture permission দেওয়া হয়নি।");}
  }
  private void captureOneFrame(){
    DisplayMetrics dm=new DisplayMetrics(); ((WindowManager)getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
    int w=dm.widthPixels,h=dm.heightPixels,dpi=dm.densityDpi;
    reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);
    virtualDisplay=projection.createVirtualDisplay("BrandCrackCapture",w,h,dpi,android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
    handler.postDelayed(()->{Image image=null;try{image=reader.acquireLatestImage();if(image==null){sendError("স্ক্রিন ফ্রেম পাওয়া যায়নি; আবার চেষ্টা করো।");return;}
      Image.Plane plane=image.getPlanes()[0];ByteBuffer buffer=plane.getBuffer();int pixelStride=plane.getPixelStride(),rowStride=plane.getRowStride(),rowPadding=rowStride-pixelStride*w;
      Bitmap padded=Bitmap.createBitmap(w+rowPadding/pixelStride,h,Bitmap.Config.ARGB_8888);padded.copyPixelsFromBuffer(buffer);Bitmap bitmap=Bitmap.createBitmap(padded,0,0,w,h);
      ByteArrayOutputStream out=new ByteArrayOutputStream();bitmap.compress(Bitmap.CompressFormat.JPEG,82,out);String b64=Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);
      web.evaluateJavascript("window.onNativeScreenCapture && window.onNativeScreenCapture('"+b64+"')",null);
    }catch(Exception e){sendError(e.getMessage());}finally{if(image!=null)image.close();stopCapture();}},1200);
  }
  private void sendError(String e){String safe=(e==null?"Unknown error":e).replace("\\","\\\\").replace("'","\\'");web.evaluateJavascript("window.onNativeCaptureError && window.onNativeCaptureError('"+safe+"')",null);stopCapture();}
  private void stopCapture(){try{if(virtualDisplay!=null){virtualDisplay.release();virtualDisplay=null;}if(reader!=null){reader.close();reader=null;}if(projection!=null){projection.stop();projection=null;}}catch(Exception ignored){}}
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
  @Override protected void onDestroy(){stopCapture();super.onDestroy();}
}
