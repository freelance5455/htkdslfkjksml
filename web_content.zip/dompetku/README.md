# DompetKu

Aplikasi pencatatan & pengelolaan keuangan pribadi. 100% offline, tanpa login, tanpa server, semua data tersimpan di perangkat (localStorage di dalam WebView aplikasi).

## Isi Folder

```
DompetKu/
├── android/     ← Proyek Android (buka ini di Android Studio untuk build APK)
│   └── app/src/main/assets/www/   ← Salinan web app yang dibungkus di dalam APK
├── www/         ← Sumber web app asli (HTML/CSS/JS) — bisa juga dibuka langsung
│                   di browser (buka www/index.html) untuk pratinjau cepat
└── README.md    ← File ini
```

## Cara Build APK

1. Install **Android Studio** (versi terbaru) di komputer kamu: https://developer.android.com/studio
2. Ekstrak ZIP ini, lalu buka Android Studio → **Open** → pilih folder **`android/`** (bukan folder DompetKu utama, tapi folder `android` di dalamnya).
3. Tunggu proses **Gradle Sync** selesai (butuh koneksi internet sekali di tahap ini, karena Android Studio akan mengunduh Gradle & dependency Android secara otomatis).
4. Setelah sync selesai, build APK lewat menu:
   **Build → Build App Bundle(s) / APK(s) → Build APK(s)**
5. Setelah selesai, klik notifikasi **locate** (atau cari manual di `android/app/build/outputs/apk/debug/app-debug.apk`).
6. Salin file `app-debug.apk` itu ke HP Android kamu, lalu install (mungkin perlu mengaktifkan "Izinkan instal dari sumber tidak dikenal" di pengaturan HP).

> Catatan: APK hasil build ini adalah **debug build**, cukup untuk pemakaian pribadi. Kalau nanti ingin publish ke Play Store, perlu proses **signing** dengan keystore sendiri (Build → Generate Signed Bundle/APK) — beri tahu saya kalau butuh bantuan langkah ini.

## Fitur yang Sudah Tersedia

- **Beranda**: saldo total, pemasukan & pengeluaran bulan berjalan, sisa dana, grafik donut kategori pengeluaran, ringkasan Target Pengeluaran & Target Dana (terpisah), transaksi terbaru
- **Akun / Sumber Dana**: tambah/edit/hapus akun (Cash, BCA, GoPay, dll), saldo otomatis ter-update
- **Transaksi**: pemasukan, pengeluaran (dengan kategori), transfer antar akun — semua bisa diedit & dihapus, saldo otomatis dikoreksi
- **Kategori Pengeluaran**: 14 kategori bawaan, bisa tambah/edit/hapus sendiri
- **Target Pengeluaran (Anggaran)**: per kategori, periode mingguan/bulanan/tahunan/custom, progress & status melebihi batas
- **Target Dana Jangka Panjang**: terpisah total dari Target Pengeluaran
  - Pemilihan nama via radio button (gaya list, bukan text input) sesuai daftar yang diminta, dengan opsi "Lainnya" untuk nama custom
  - Tempat penyimpanan (Cash/Bank/E-Wallet/Lainnya) juga radio button, termasuk sub-pilihan bank
  - Tanggal mulai & tanggal target ditentukan manual (bukan durasi tetap)
  - Progress circle, rekomendasi menabung per bulan/minggu/hari, riwayat lengkap (tambah/kurang dana, edit, hapus, pindah penyimpanan)
  - Status Aktif / Tercapai / Arsip, deteksi lewat tenggat
  - Mendukung banyak target sekaligus
- **Riwayat Transaksi**: gabungan semua jenis transaksi + histori target dana, dengan filter jenis/akun/kategori
- **Backup & Restore**: ekspor ke file JSON (tersimpan ke folder Download di APK), impor kembali dari file
- **Desain**: hijau + kuning/oranye sesuai identitas DompetKu, ringan, dioptimalkan satu tangan, mendukung mode gelap otomatis

## Catatan Teknis

- Web app dibungkus di dalam `WebView` Android murni (tanpa framework berat), supaya APK kecil dan ringan.
- Data disimpan lewat `localStorage` milik WebView — **khusus untuk instalasi APK itu sendiri**. Jika APK di-uninstall, data ikut hilang, jadi gunakan fitur **Backup** secara berkala.
- Aplikasi tidak melakukan panggilan jaringan apa pun saat digunakan sehari-hari — 100% offline setelah APK terinstal.
