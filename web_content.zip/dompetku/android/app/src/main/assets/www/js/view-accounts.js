/* ==========================================================================
   DompetKu - Halaman Akun / Sumber Dana
   ========================================================================== */

function renderAccounts(main) {
  const s = DB.state();
  const total = s.accounts.reduce((sum, a) => sum + a.balance, 0);
  main.innerHTML = `
    <div class="page">
      <div class="page-header">
        <div class="page-title">Akun / Sumber Dana</div>
        <button class="btn btn-primary btn-sm" onclick="openAccountForm()">${ICON.plus} Tambah</button>
      </div>
      <div class="total-strip">Total Saldo Seluruh Akun: <strong>${formatRupiah(total)}</strong></div>
      <div class="account-list">
        ${s.accounts.length ? s.accounts.map(accountCard).join('') : `<div class="empty-state">${ICON.target}<div>Belum ada akun. Tambahkan sumber dana pertamamu, misalnya Cash atau BCA.</div></div>`}
      </div>
      <div class="bottom-spacer"></div>
    </div>
  `;
}

function accountCard(a) {
  return `
    <div class="account-card">
      <div class="account-card-main" onclick="showAccountDetail('${a.id}')">
        <div class="account-name">${escapeHtml(a.name)}</div>
        ${a.note ? `<div class="account-note">${escapeHtml(a.note)}</div>` : ''}
        <div class="account-balance">${formatRupiah(a.balance)}</div>
      </div>
      <div class="account-card-actions">
        <button class="icon-btn-sm" onclick="openAccountForm('${a.id}')">${ICON.edit}</button>
        <button class="icon-btn-sm" onclick="deleteAccountFlow('${a.id}')">${ICON.trash}</button>
      </div>
    </div>
  `;
}

function showAccountDetail(id) {
  const a = DB.getAccount(id);
  if (!a) return;
  const s = DB.state();
  const txs = s.transactions.filter(t => t.accountId === id || t.toAccountId === id).sort((x, y) => y.createdAt - x.createdAt).slice(0, 10);
  showInfoSheet(a.name, `
    <div class="detail-line">Saldo saat ini: <strong>${formatRupiah(a.balance)}</strong></div>
    ${a.note ? `<div class="detail-line">Catatan: ${escapeHtml(a.note)}</div>` : ''}
    <div class="section-title" style="margin-top:14px">Transaksi Terakhir</div>
    ${txs.length ? txs.map(transactionRow).join('') : '<div class="empty-mini">Belum ada transaksi.</div>'}
  `);
}

function openAccountForm(id) {
  const editing = id ? DB.getAccount(id) : null;
  document.getElementById('accFormTitle').textContent = editing ? 'Edit Akun' : 'Tambah Akun';
  document.getElementById('accFormBody').innerHTML = `
    <form id="accForm">
      <label class="field-label">Nama Akun</label>
      <input id="accName" class="field-input" placeholder="Contoh: BCA, Cash, GoPay" value="${editing ? escapeHtml(editing.name) : ''}" required />
      <label class="field-label">Saldo ${editing ? 'Saat Ini' : 'Awal'}</label>
      <input inputmode="numeric" id="accBalance" class="field-input field-amount" placeholder="Rp0" value="${editing ? formatNumberInput(editing.balance) : ''}" />
      <label class="field-label">Catatan (opsional)</label>
      <input id="accNote" class="field-input" placeholder="Catatan..." value="${editing ? escapeHtml(editing.note || '') : ''}" />
      <button type="submit" class="btn btn-primary btn-block">${editing ? 'Simpan Perubahan' : 'Tambah Akun'}</button>
    </form>
  `;
  bindRupiahInput(document.getElementById('accBalance'));
  document.getElementById('accForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('accName').value.trim();
    if (!name) { toast('Nama akun wajib diisi', 'warn'); return; }
    const balance = parseRupiahInput(document.getElementById('accBalance').value);
    const note = document.getElementById('accNote').value.trim();
    if (editing) {
      DB.updateAccount(editing.id, { name, balance, note });
      toast('Akun diperbarui');
    } else {
      DB.addAccount({ name, balance, note });
      toast('Akun ditambahkan');
    }
    closeModal('accFormModal');
    App.render(App.route);
  }, { once: true });
  openModal('accFormModal');
}

async function deleteAccountFlow(id) {
  const s = DB.state();
  const used = s.transactions.some(t => t.accountId === id || t.toAccountId === id) || s.targets.some(t => t.linkedAccountId === id);
  const msg = used
    ? 'Akun ini memiliki riwayat transaksi/target terkait. Menghapusnya tidak akan menghapus riwayat transaksi, tapi referensi akun pada riwayat akan hilang. Lanjutkan?'
    : 'Hapus akun ini?';
  const ok = await confirmDialog(msg);
  if (!ok) return;
  DB.deleteAccount(id);
  toast('Akun dihapus');
  App.render(App.route);
}
