/* ==========================================================================
   DompetKu - Halaman Beranda
   ========================================================================== */

function renderHome(main) {
  const s = DB.state();
  const { start, end } = currentMonthRange();

  const totalSaldo = s.accounts.reduce((sum, a) => sum + a.balance, 0);

  const monthTx = s.transactions.filter(t => isDateInRange(t.date, start, end));
  const pemasukan = monthTx.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
  const pengeluaran = monthTx.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
  const sisaDana = pemasukan - pengeluaran;

  // Data grafik: pengeluaran per kategori bulan ini
  const byCategory = {};
  monthTx.filter(t => t.type === 'expense').forEach(t => {
    byCategory[t.categoryId] = (byCategory[t.categoryId] || 0) + t.amount;
  });
  const slices = Object.keys(byCategory).map(catId => {
    const cat = DB.getCategory(catId);
    return { label: cat ? cat.name : 'Lainnya', value: byCategory[catId], color: cat ? cat.color : '#94A3B8', categoryId: catId };
  }).sort((a, b) => b.value - a.value);

  const activeBudgets = s.budgets.filter(b => !b.archived);
  const activeTargets = s.targets.filter(t => t.status !== 'archived');
  const recentTx = [...s.transactions].sort((a, b) => b.createdAt - a.createdAt).slice(0, 5);

  main.innerHTML = `
    <div class="page page-home">
      <div class="home-header">
        <div>
          <div class="home-greeting">DompetKu</div>
          <div class="home-sub">${formatDateLong(todayISO())}</div>
        </div>
        <button class="icon-btn" onclick="location.hash='#/settings'" aria-label="Pengaturan">${ICON.settings}</button>
      </div>

      <div class="balance-card">
        <div class="balance-label">Saldo Total</div>
        <div class="balance-value">${formatRupiah(totalSaldo)}</div>
        <div class="balance-row">
          <div class="balance-item">
            <span class="dot dot-in"></span>
            <div><div class="balance-item-label">Pemasukan</div><div class="balance-item-value">${formatRupiah(pemasukan)}</div></div>
          </div>
          <div class="balance-item">
            <span class="dot dot-out"></span>
            <div><div class="balance-item-label">Pengeluaran</div><div class="balance-item-value">${formatRupiah(pengeluaran)}</div></div>
          </div>
        </div>
        <div class="balance-row">
          <div class="balance-item full">
            <span class="dot dot-rest"></span>
            <div><div class="balance-item-label">Sisa Dana Bulan Ini</div><div class="balance-item-value ${sisaDana < 0 ? 'neg' : ''}">${formatRupiah(sisaDana)}</div></div>
          </div>
        </div>
      </div>

      <div class="section-card">
        <div class="section-title">Grafik Pengeluaran Bulan Ini</div>
        ${slices.length ? `
          <div class="donut-wrap">
            <div id="homeDonut" class="donut-container"></div>
            <div class="donut-legend" id="homeLegend"></div>
          </div>
        ` : `<div class="empty-mini">Belum ada pengeluaran bulan ini.</div>`}
      </div>

      <div class="section-card">
        <div class="section-row-head">
          <div class="section-title">Target Pengeluaran</div>
          <a href="#/targets/budget" class="link-more">Lihat semua</a>
        </div>
        ${activeBudgets.length ? activeBudgets.slice(0, 3).map(budgetSummaryRow).join('') : `<div class="empty-mini">Belum ada target pengeluaran. <a href="#/targets/budget">Buat sekarang</a></div>`}
      </div>

      <div class="section-card">
        <div class="section-row-head">
          <div class="section-title">Target Dana</div>
          <a href="#/targets/dana" class="link-more">Lihat semua</a>
        </div>
        ${activeTargets.length ? activeTargets.slice(0, 3).map(targetSummaryRow).join('') : `<div class="empty-mini">Belum ada target dana. <a href="#/targets/dana">Buat sekarang</a></div>`}
      </div>

      <div class="section-card">
        <div class="section-row-head">
          <div class="section-title">Transaksi Terbaru</div>
          <a href="#/transactions" class="link-more">Lihat semua</a>
        </div>
        ${recentTx.length ? recentTx.map(transactionRow).join('') : `<div class="empty-mini">Belum ada transaksi.</div>`}
      </div>
      <div class="bottom-spacer"></div>
    </div>
  `;

  if (slices.length) {
    const container = document.getElementById('homeDonut');
    renderDonutChart(container, slices, {
      centerLabel: 'Pengeluaran',
      centerText: formatRupiah(pengeluaran),
      onSliceClick: (slice) => showCategorySliceInfo(slice, pengeluaran)
    });
    const legend = document.getElementById('homeLegend');
    legend.innerHTML = slices.map(sl => {
      const pct = pengeluaran ? ((sl.value / pengeluaran) * 100).toFixed(1) : '0';
      return `<div class="legend-item" data-cat="${sl.categoryId}">
        <span class="legend-dot" style="background:${sl.color}"></span>
        <span class="legend-name">${escapeHtml(sl.label)}</span>
        <span class="legend-val">${formatRupiah(sl.value)} · ${pct}%</span>
      </div>`;
    }).join('');
    legend.querySelectorAll('.legend-item').forEach(el => {
      el.addEventListener('click', () => {
        const sl = slices.find(x => x.categoryId === el.dataset.cat);
        showCategorySliceInfo(sl, pengeluaran);
      });
    });
  }
}

function showCategorySliceInfo(slice, totalPengeluaran) {
  const s = DB.state();
  const pct = totalPengeluaran ? ((slice.value / totalPengeluaran) * 100).toFixed(1) : '0';
  const budget = s.budgets.find(b => b.categoryId === slice.categoryId && !b.archived);
  let budgetInfo = '<div class="slice-info-row">Belum ada target untuk kategori ini.</div>';
  if (budget) {
    const range = computeBudgetPeriodRange(budget);
    const used = s.transactions.filter(t => t.type === 'expense' && t.categoryId === budget.categoryId && isDateInRange(t.date, range.start, range.end))
      .reduce((sum, t) => sum + t.amount, 0);
    const sisa = budget.limit - used;
    budgetInfo = `
      <div class="slice-info-row">Target Pengeluaran: ${formatRupiah(budget.limit)}</div>
      <div class="slice-info-row">Sisa Target: <span class="${sisa < 0 ? 'neg' : ''}">${formatRupiah(sisa)}</span></div>
    `;
  }
  showInfoSheet(slice.label, `
    <div class="slice-info-row"><strong>${formatRupiah(slice.value)}</strong> (${pct}% dari total pengeluaran)</div>
    ${budgetInfo}
  `);
}

function showInfoSheet(title, html) {
  document.getElementById('infoSheetTitle').textContent = title;
  document.getElementById('infoSheetBody').innerHTML = html;
  openModal('infoSheet');
}

function budgetSummaryRow(b) {
  const cat = DB.getCategory(b.categoryId);
  const s = DB.state();
  const range = computeBudgetPeriodRange(b);
  const used = s.transactions.filter(t => t.type === 'expense' && t.categoryId === b.categoryId && isDateInRange(t.date, range.start, range.end))
    .reduce((sum, t) => sum + t.amount, 0);
  const pct = b.limit > 0 ? Math.min(999, (used / b.limit) * 100) : 0;
  const over = used > b.limit;
  return `
    <div class="mini-row" onclick="location.hash='#/targets/budget'">
      <div class="mini-row-top">
        <span class="mini-row-title">${escapeHtml(cat ? cat.name : '-')}</span>
        <span class="mini-row-value ${over ? 'neg' : ''}">${formatRupiah(used)} / ${formatRupiah(b.limit)}</span>
      </div>
      <div class="bar-track"><div class="bar-fill ${over ? 'bar-over' : ''}" style="width:${Math.min(100, pct)}%; background:${over ? '' : (cat ? cat.color : '#1B8A5A')}"></div></div>
    </div>
  `;
}

function targetSummaryRow(t) {
  const pct = t.targetAmount > 0 ? Math.min(100, (t.currentAmount / t.targetAmount) * 100) : 0;
  return `
    <div class="mini-row" onclick="location.hash='#/target-detail/${t.id}'">
      <div class="mini-row-top">
        <span class="mini-row-title">${escapeHtml(t.name)}</span>
        <span class="mini-row-value">${formatRupiah(t.currentAmount)} / ${formatRupiah(t.targetAmount)}</span>
      </div>
      <div class="bar-track"><div class="bar-fill" style="width:${pct}%; background:#1B8A5A"></div></div>
    </div>
  `;
}

function transactionRow(t) {
  const s = DB.state();
  let icon = ICON.expense, title = '', amountClass = 'neg', amountPrefix = '-';
  if (t.type === 'income') {
    icon = ICON.income; amountClass = 'pos'; amountPrefix = '+';
    const acc = DB.getAccount(t.accountId);
    title = `Pemasukan · ${acc ? acc.name : '-'}`;
  } else if (t.type === 'expense') {
    icon = ICON.expense; amountClass = 'neg'; amountPrefix = '-';
    const cat = DB.getCategory(t.categoryId);
    title = cat ? cat.name : 'Pengeluaran';
  } else if (t.type === 'transfer') {
    icon = ICON.transfer; amountClass = 'neutral'; amountPrefix = '';
    const from = DB.getAccount(t.accountId), to = DB.getAccount(t.toAccountId);
    title = `Transfer · ${from ? from.name : '-'} → ${to ? to.name : '-'}`;
  }
  return `
    <div class="tx-row" onclick="openTransactionDetail('${t.id}')">
      <div class="tx-icon">${icon}</div>
      <div class="tx-mid">
        <div class="tx-title">${escapeHtml(title)}</div>
        <div class="tx-date">${formatDateShort(t.date)}${t.note ? ' · ' + escapeHtml(t.note) : ''}</div>
      </div>
      <div class="tx-amount ${amountClass}">${amountPrefix}${formatRupiah(t.amount)}</div>
    </div>
  `;
}

const ICON = {
  settings: '<svg viewBox="0 0 24 24" fill="none"><path d="M12 15.5a3.5 3.5 0 100-7 3.5 3.5 0 000 7z" stroke="currentColor" stroke-width="1.8"/><path d="M19.4 13a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V19a2 2 0 11-4 0v-.09a1.65 1.65 0 00-1-1.51 1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H4a2 2 0 110-4h.09a1.65 1.65 0 001.51-1 1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06a1.65 1.65 0 001.82.33H10a1.65 1.65 0 001-1.51V4a2 2 0 114 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V10a1.65 1.65 0 001.51 1H20a2 2 0 110 4h-.09a1.65 1.65 0 00-1.51 1z" stroke="currentColor" stroke-width="1.6"/></svg>',
  income: '<svg viewBox="0 0 24 24" fill="none"><path d="M12 19V5M5 12l7-7 7 7" stroke="#1B8A5A" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  expense: '<svg viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12l7 7 7-7" stroke="#E24C4B" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  transfer: '<svg viewBox="0 0 24 24" fill="none"><path d="M7 7h11l-3-3M17 17H6l3 3" stroke="#3B82F6" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  target: '<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.8"/><circle cx="12" cy="12" r="5" stroke="currentColor" stroke-width="1.8"/><circle cx="12" cy="12" r="1.3" fill="currentColor"/></svg>',
  edit: '<svg viewBox="0 0 24 24" fill="none"><path d="M12 20h9M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4L16.5 3.5z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  trash: '<svg viewBox="0 0 24 24" fill="none"><path d="M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2m3 0-1 14a2 2 0 01-2 2H7a2 2 0 01-2-2L4 6h16z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  chevronRight: '<svg viewBox="0 0 24 24" fill="none"><path d="M9 6l6 6-6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  plus: '<svg viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg>',
};
