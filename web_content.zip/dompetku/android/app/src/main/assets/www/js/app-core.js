/* ==========================================================================
   DompetKu - App Core (state, router, navigasi)
   ========================================================================== */

const App = {
  route: 'home',
  init() {
    DB.load();
    this.bindNav();
    this.bindFab();
    this.bindModalCloseButtons();
    window.addEventListener('hashchange', () => this.handleHash());
    this.handleHash();
  },

  bindNav() {
    document.querySelectorAll('.navitem').forEach(btn => {
      btn.addEventListener('click', () => {
        location.hash = '#/' + btn.dataset.route;
      });
    });
  },

  bindFab() {
    document.getElementById('fabAdd').addEventListener('click', () => openAddTransactionChooser());
  },

  bindModalCloseButtons() {
    document.body.addEventListener('click', (e) => {
      if (e.target.matches('[data-close-modal]')) {
        closeModal(e.target.closest('.modal-overlay').id);
      }
      if (e.target.classList.contains('modal-overlay') && e.target.dataset.backdropClose !== 'false') {
        closeModal(e.target.id);
      }
    });
  },

  handleHash() {
    const hash = location.hash.replace('#/', '') || 'home';
    const [route, param] = hash.split('/');
    this.route = route;
    document.querySelectorAll('.navitem').forEach(b => b.classList.toggle('active', b.dataset.route === route));
    this.render(route, param);
    window.scrollTo(0, 0);
  },

  render(route, param) {
    const main = document.getElementById('mainView');
    switch (route) {
      case 'home': return renderHome(main);
      case 'transactions': return renderTransactions(main);
      case 'targets': return renderTargetsHub(main, param);
      case 'accounts': return renderAccounts(main);
      case 'settings': return renderSettings(main);
      case 'target-detail': return renderTargetDetail(main, param);
      default: return renderHome(main);
    }
  }
};

function openModal(id) {
  document.getElementById(id).classList.add('open');
  document.body.classList.add('modal-open');
}
function closeModal(id) {
  document.getElementById(id).classList.remove('open');
  document.body.classList.remove('modal-open');
}

function openAddTransactionChooser() {
  const s = DB.state();
  if (!s.accounts.length) {
    toast('Tambahkan akun/sumber dana terlebih dahulu', 'warn');
    location.hash = '#/accounts';
    return;
  }
  openTransactionForm('expense');
}

document.addEventListener('DOMContentLoaded', () => App.init());
