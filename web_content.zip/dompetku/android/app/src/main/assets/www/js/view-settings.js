/* ==========================================================================
   DompetKu - Pengaturan
   ========================================================================== */

function renderSettings(main) {
  const s = DB.state();
  main.innerHTML = `
    <div class="page">
      <div class="page-header">
        <div class="page-title">Pengaturan</div>
      </div>

      <div class="section-card">
        <div class="section-row-head">
          <div class="section-title">Kategori Pengeluaran</div>
          <button class="btn btn-primary btn-sm" onclick="openCategoryForm()">${ICON.plus} Tambah</button>
        </div>
        <div class="category-chip-list">
          ${s.categories.map(c => `
            <div class="category-chip" style="border-color:${c.color}33">
              <span class="chip-dot" style="background:${c.color}"></span>
              ${escapeHtml(c.name)}
              <button class="chip-edit" onclick="openCategoryForm('${c.id}')">${ICON.edit}</button>
              <button class="chip-edit" onclick="deleteCategoryFlow('${c.id}')">${ICON.trash}</button>
            </div>
          `).join('')}
        </div>
      </div>

      <div class="section-card">
        <div class="section-title">Backup & Restore</div>
        <p class="settings-desc">Semua data DompetKu tersimpan hanya di perangkat ini. Backup secara berkala agar data tidak hilang jika HP berganti atau aplikasi dihapus.</p>
        <button class="btn btn-secondary btn-block" onclick="exportBackup()">Backup Data ke File</button>
        <label class="btn btn-secondary btn-block" style="margin-top:10px; text-align:center; cursor:pointer;">
          Pulihkan dari File Backup
          <input type="file" id="restoreFileInput" accept="application/json" style="display:none" />
        </label>
      </div>

      <div class="section-card">
        <div class="section-title">Tentang</div>
        <div class="about-row"><span class="wallet-logo-mini">${LOGO_SVG_MINI}</span><div><div class="about-name">DompetKu</div><div class="about-desc">Pencatatan keuangan pribadi, 100% offline. Tidak ada login, tidak ada server, semua data tersimpan di perangkatmu.</div></div></div>
      </div>
      <div class="bottom-spacer"></div>
    </div>
  `;

  document.getElementById('restoreFileInput').addEventListener('change', handleRestoreFile);
}

function openCategoryForm(id) {
  const editing = id ? DB.getCategory(id) : null;
  document.getElementById('catFormTitle').textContent = editing ? 'Edit Kategori' : 'Tambah Kategori';
  document.getElementById('catFormBody').innerHTML = `
    <form id="catForm">
      <label class="field-label">Nama Kategori</label>
      <input id="catName" class="field-input" placeholder="Nama kategori..." value="${editing ? escapeHtml(editing.name) : ''}" required />
      <button type="submit" class="btn btn-primary btn-block">${editing ? 'Simpan Perubahan' : 'Tambah Kategori'}</button>
    </form>
  `;
  document.getElementById('catForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('catName').value.trim();
    if (!name) { toast('Nama kategori wajib diisi', 'warn'); return; }
    if (editing) DB.updateCategory(editing.id, { name }); else DB.addCategory(name);
    closeModal('catFormModal');
    toast(editing ? 'Kategori diperbarui' : 'Kategori ditambahkan');
    App.render('settings');
  }, { once: true });
  openModal('catFormModal');
}

async function deleteCategoryFlow(id) {
  const s = DB.state();
  const used = s.transactions.some(t => t.categoryId === id) || s.budgets.some(b => b.categoryId === id);
  const msg = used ? 'Kategori ini masih dipakai di transaksi/target pengeluaran. Riwayat lama tidak akan terhapus, tapi label kategorinya akan hilang. Lanjutkan hapus?' : 'Hapus kategori ini?';
  const ok = await confirmDialog(msg);
  if (!ok) return;
  DB.deleteCategory(id);
  toast('Kategori dihapus');
  App.render('settings');
}

function exportBackup() {
  const data = DB.exportData();
  const dateStr = todayISO();
  const fileName = `dompetku-backup-${dateStr}.json`;

  // Jika berjalan di dalam WebView Android (ada jembatan native), simpan via native ke folder Download.
  if (window.DompetKuAndroid && window.DompetKuAndroid.saveBackupFile) {
    try {
      const base64 = btoa(unescape(encodeURIComponent(data)));
      window.DompetKuAndroid.saveBackupFile(base64, fileName);
      toast('File backup disimpan ke folder Download');
      return;
    } catch (e) {
      console.error(e);
    }
  }

  // Fallback: unduhan biasa via browser
  const blob = new Blob([data], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  toast('File backup diunduh');
}

async function handleRestoreFile(e) {
  const file = e.target.files[0];
  if (!file) return;
  const ok = await confirmDialog('Memulihkan backup akan menimpa data saat ini di aplikasi ini. Lanjutkan?');
  if (!ok) { e.target.value = ''; return; }
  const reader = new FileReader();
  reader.onload = () => {
    try {
      DB.importData(reader.result);
      toast('Data berhasil dipulihkan');
      App.render('home');
      location.hash = '#/home';
    } catch (err) {
      toast('Gagal memulihkan: file tidak valid', 'warn');
    }
  };
  reader.readAsText(file);
  e.target.value = '';
}

const LOGO_SVG_MINI = `<svg viewBox="0 0 48 48" width="40" height="40"><rect width="48" height="48" rx="12" fill="#1B8A5A"/><path d="M10 16a4 4 0 014-4h20a2 2 0 012 2v3H14a2 2 0 000 4h22v11a4 4 0 01-4 4H14a4 4 0 01-4-4V16z" fill="#F5A623"/><circle cx="31" cy="26" r="3.2" fill="#1B8A5A"/></svg>`;
