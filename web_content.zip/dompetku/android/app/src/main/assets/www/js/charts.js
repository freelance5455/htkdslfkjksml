/* ==========================================================================
   DompetKu - Donut Chart (SVG murni, tanpa dependensi)
   ========================================================================== */

function polarToCartesian(cx, cy, r, angleDeg) {
  const a = (angleDeg - 90) * Math.PI / 180;
  return { x: cx + r * Math.cos(a), y: cy + r * Math.sin(a) };
}

function arcPath(cx, cy, r, startAngle, endAngle) {
  const start = polarToCartesian(cx, cy, r, endAngle);
  const end = polarToCartesian(cx, cy, r, startAngle);
  const largeArc = endAngle - startAngle <= 180 ? 0 : 1;
  return `M ${start.x} ${start.y} A ${r} ${r} 0 ${largeArc} 0 ${end.x} ${end.y}`;
}

/**
 * Render donut chart.
 * slices: [{ label, value, color }]
 * remainingLabel/remainingColor: untuk "sisa dana" (hijau)
 */
function renderDonutChart(container, slices, opts) {
  opts = opts || {};
  const size = opts.size || 220;
  const cx = size / 2, cy = size / 2;
  const rOuter = size / 2 - 6;
  const rInner = rOuter - (opts.thickness || 34);
  const total = slices.reduce((s, x) => s + x.value, 0);

  container.innerHTML = '';
  const svgNS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(svgNS, 'svg');
  svg.setAttribute('viewBox', `0 0 ${size} ${size}`);
  svg.setAttribute('class', 'donut-svg');

  if (total <= 0) {
    const circle = document.createElementNS(svgNS, 'circle');
    circle.setAttribute('cx', cx); circle.setAttribute('cy', cy); circle.setAttribute('r', (rOuter + rInner) / 2);
    circle.setAttribute('fill', 'none');
    circle.setAttribute('stroke', '#E5E9E4');
    circle.setAttribute('stroke-width', rOuter - rInner);
    svg.appendChild(circle);
    container.appendChild(svg);
    return;
  }

  let angle = 0;
  const strokeW = rOuter - rInner;
  const rMid = (rOuter + rInner) / 2;

  slices.forEach(slice => {
    if (slice.value <= 0) return;
    const sweep = (slice.value / total) * 360;
    const endAngle = angle + sweep;
    const path = document.createElementNS(svgNS, 'path');
    const gap = slices.length > 1 ? 1.4 : 0;
    const d = arcPath(cx, cy, rMid, angle + gap / 2, Math.max(angle + gap / 2, endAngle - gap / 2));
    path.setAttribute('d', d);
    path.setAttribute('fill', 'none');
    path.setAttribute('stroke', slice.color);
    path.setAttribute('stroke-width', strokeW);
    path.setAttribute('stroke-linecap', slices.length > 1 ? 'round' : 'butt');
    path.setAttribute('class', 'donut-slice');
    path.dataset.label = slice.label;
    path.dataset.value = slice.value;
    path.dataset.pct = ((slice.value / total) * 100).toFixed(1);
    if (opts.onSliceClick) {
      path.addEventListener('click', () => opts.onSliceClick(slice));
      path.style.cursor = 'pointer';
    }
    svg.appendChild(path);
    angle = endAngle;
  });

  container.appendChild(svg);

  if (opts.centerText !== undefined) {
    const centerWrap = document.createElement('div');
    centerWrap.className = 'donut-center';
    centerWrap.innerHTML = `<div class="donut-center-label">${escapeHtml(opts.centerLabel || '')}</div>
      <div class="donut-center-value">${escapeHtml(opts.centerText)}</div>`;
    container.appendChild(centerWrap);
  }
}

function renderProgressCircle(container, pct, opts) {
  opts = opts || {};
  const size = opts.size || 120;
  const stroke = opts.thickness || 12;
  const r = size / 2 - stroke;
  const cx = size / 2, cy = size / 2;
  const circumference = 2 * Math.PI * r;
  const clamped = Math.max(0, Math.min(100, pct));
  const offset = circumference * (1 - clamped / 100);
  const color = opts.color || (clamped >= 100 ? '#1B8A5A' : '#F5A623');

  container.innerHTML = `
    <svg viewBox="0 0 ${size} ${size}" class="progress-circle-svg">
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#E5E9E4" stroke-width="${stroke}"/>
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${color}" stroke-width="${stroke}"
        stroke-linecap="round" stroke-dasharray="${circumference}" stroke-dashoffset="${offset}"
        transform="rotate(-90 ${cx} ${cy})" class="progress-circle-fill"/>
    </svg>
    <div class="progress-circle-label">${clamped.toFixed(0)}%</div>
  `;
}
