/* ==========================================================================
   DompetKu - Helpers
   ========================================================================== */

function formatRupiah(n) {
  n = Number(n) || 0;
  const neg = n < 0;
  n = Math.abs(Math.round(n));
  const str = n.toLocaleString('id-ID');
  return (neg ? '-Rp' : 'Rp') + str;
}

function formatNumberInput(n) {
  n = Number(n) || 0;
  return Math.round(n).toLocaleString('id-ID');
}

function parseRupiahInput(str) {
  if (!str) return 0;
  const cleaned = String(str).replace(/[^0-9]/g, '');
  return cleaned ? parseInt(cleaned, 10) : 0;
}

const MONTHS_ID = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
const MONTHS_SHORT_ID = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
const DAYS_ID = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', "Jum'at", 'Sabtu'];

function formatDateLong(iso) {
  if (!iso) return '-';
  const d = new Date(iso + 'T00:00:00');
  return `${d.getDate()} ${MONTHS_ID[d.getMonth()]} ${d.getFullYear()}`;
}

function formatDateShort(iso) {
  if (!iso) return '-';
  const d = new Date(iso + 'T00:00:00');
  return `${d.getDate()} ${MONTHS_SHORT_ID[d.getMonth()]} ${d.getFullYear()}`;
}

function daysBetween(isoStart, isoEnd) {
  const a = new Date(isoStart + 'T00:00:00');
  const b = new Date(isoEnd + 'T00:00:00');
  return Math.round((b - a) / 86400000);
}

function addDaysISO(iso, days) {
  const d = new Date(iso + 'T00:00:00');
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

function currentMonthRange() {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), 1);
  const end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  const iso = d => d.toISOString().slice(0, 10);
  return { start: iso(start), end: iso(end) };
}

function isDateInRange(dateISO, startISO, endISO) {
  return dateISO >= startISO && dateISO <= endISO;
}

function computeBudgetPeriodRange(budget) {
  const now = new Date();
  if (budget.period === 'weekly') {
    const day = now.getDay();
    const diffToMonday = (day === 0 ? -6 : 1) - day;
    const monday = new Date(now);
    monday.setDate(now.getDate() + diffToMonday);
    const sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 6);
    const iso = d => d.toISOString().slice(0, 10);
    return { start: iso(monday), end: iso(sunday) };
  }
  if (budget.period === 'monthly') {
    return currentMonthRange();
  }
  if (budget.period === 'yearly') {
    const iso = d => d.toISOString().slice(0, 10);
    return { start: iso(new Date(now.getFullYear(), 0, 1)), end: iso(new Date(now.getFullYear(), 11, 31)) };
  }
  // custom
  return { start: budget.startDate, end: budget.endDate };
}

function calcSavingsRecommendation(target) {
  const remaining = Math.max(0, target.targetAmount - target.currentAmount);
  const today = todayISO();
  const totalDays = Math.max(1, daysBetween(target.startDate, target.targetDate));
  let daysLeft = daysBetween(today, target.targetDate);
  if (daysLeft < 0) daysLeft = 0;
  const monthsLeft = Math.max(1 / 30, daysLeft / 30.44);
  const weeksLeft = Math.max(1 / 7, daysLeft / 7);
  return {
    remaining,
    daysLeft,
    perMonth: daysLeft > 0 ? remaining / monthsLeft : remaining,
    perWeek: daysLeft > 0 ? remaining / weeksLeft : remaining,
    perDay: daysLeft > 0 ? remaining / daysLeft : remaining,
    isOverdue: daysBetween(today, target.targetDate) < 0 && target.currentAmount < target.targetAmount
  };
}

function uniqueId() { return uid('x'); }

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function toast(msg, type) {
  const el = document.getElementById('toast');
  if (!el) return;
  el.textContent = msg;
  el.className = 'toast show' + (type ? ' toast-' + type : '');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { el.className = 'toast'; }, 2600);
}

function confirmDialog(message) {
  return new Promise(resolve => {
    const overlay = document.getElementById('confirmOverlay');
    const msgEl = document.getElementById('confirmMessage');
    const yesBtn = document.getElementById('confirmYes');
    const noBtn = document.getElementById('confirmNo');
    msgEl.textContent = message;
    overlay.classList.add('open');
    const cleanup = (result) => {
      overlay.classList.remove('open');
      yesBtn.removeEventListener('click', onYes);
      noBtn.removeEventListener('click', onNo);
      resolve(result);
    };
    const onYes = () => cleanup(true);
    const onNo = () => cleanup(false);
    yesBtn.addEventListener('click', onYes);
    noBtn.addEventListener('click', onNo);
  });
}
