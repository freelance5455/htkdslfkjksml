/* ==========================================================================
   DompetKu - Data Layer
   Semua data disimpan 100% lokal via localStorage. Tidak ada server/cloud.
   ========================================================================== */

const DB_KEY = 'dompetku_data_v1';

const DEFAULT_CATEGORIES = [
  'Makan & Minuman', 'Transportasi', 'BBM', 'Perbaikan Motor',
  'Kebutuhan Bulanan', 'Sabun & Perawatan', 'Skincare', 'Pulsa & Internet',
  'Hiburan', 'Keinginan', 'Belanja', 'Kesehatan', 'Sedekah', 'Lainnya'
];

const TARGET_DANA_NAMES = [
  'Menikah', 'Rumah', 'Dana Darurat', 'Dana Cadangan', 'Restorasi Motor',
  'Touring', 'Kendaraan', 'Pendidikan', 'Liburan', 'Gadget', 'Renovasi',
  'Modal Usaha', 'Sedekah', 'Keinginan', 'Investasi', 'Kebutuhan Keluarga',
  'Lainnya'
];

const CATEGORY_COLORS = [
  '#1B8A5A', '#F5A623', '#3B82F6', '#EF4444', '#8B5CF6',
  '#EC4899', '#14B8A6', '#F97316', '#6366F1', '#84CC16',
  '#06B6D4', '#D946EF', '#64748B', '#A16207'
];

function uid(prefix) {
  return (prefix || 'id') + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
}

function todayISO() {
  const d = new Date();
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 10);
}

function emptyState() {
  return {
    version: 1,
    accounts: [],
    categories: DEFAULT_CATEGORIES.map((n, i) => ({
      id: uid('cat'), name: n, color: CATEGORY_COLORS[i % CATEGORY_COLORS.length], isDefault: true
    })),
    transactions: [],   // income, expense, transfer
    budgets: [],        // Target Pengeluaran
    targets: [],         // Target Dana
    settings: { firstRun: true }
  };
}

const DB = {
  _state: null,

  load() {
    if (this._state) return this._state;
    try {
      const raw = localStorage.getItem(DB_KEY);
      if (raw) {
        this._state = JSON.parse(raw);
        this._migrate();
      } else {
        this._state = emptyState();
        this.save();
      }
    } catch (e) {
      console.error('Gagal memuat data, membuat data baru', e);
      this._state = emptyState();
    }
    return this._state;
  },

  _migrate() {
    // Jaga kompatibilitas data lama: pastikan semua field ada tanpa menghapus data.
    const s = this._state;
    if (!s.accounts) s.accounts = [];
    if (!s.categories || !s.categories.length) {
      s.categories = DEFAULT_CATEGORIES.map((n, i) => ({
        id: uid('cat'), name: n, color: CATEGORY_COLORS[i % CATEGORY_COLORS.length], isDefault: true
      }));
    }
    s.categories.forEach(c => { if (!c.color) c.color = CATEGORY_COLORS[Math.floor(Math.random() * CATEGORY_COLORS.length)]; });
    if (!s.transactions) s.transactions = [];
    if (!s.budgets) s.budgets = [];
    if (!s.targets) s.targets = [];
    s.targets.forEach(t => {
      if (!t.history) t.history = [];
      if (t.allocationMode === undefined) t.allocationMode = 'separated';
      if (t.status === undefined) t.status = 'active';
    });
    if (!s.settings) s.settings = { firstRun: false };
  },

  save() {
    try {
      localStorage.setItem(DB_KEY, JSON.stringify(this._state));
      return true;
    } catch (e) {
      console.error('Gagal menyimpan data', e);
      return false;
    }
  },

  state() { return this.load(); },

  // ---------- Akun ----------
  addAccount({ name, balance, note }) {
    const acc = { id: uid('acc'), name: name.trim(), balance: Number(balance) || 0, note: note || '', createdAt: Date.now() };
    this.load().accounts.push(acc);
    this.save();
    return acc;
  },
  updateAccount(id, patch) {
    const acc = this.load().accounts.find(a => a.id === id);
    if (!acc) return null;
    Object.assign(acc, patch);
    this.save();
    return acc;
  },
  deleteAccount(id) {
    const s = this.load();
    s.accounts = s.accounts.filter(a => a.id !== id);
    this.save();
  },
  getAccount(id) { return this.load().accounts.find(a => a.id === id); },

  // ---------- Kategori ----------
  addCategory(name) {
    const cat = { id: uid('cat'), name: name.trim(), color: CATEGORY_COLORS[this.load().categories.length % CATEGORY_COLORS.length], isDefault: false };
    this.load().categories.push(cat);
    this.save();
    return cat;
  },
  updateCategory(id, patch) {
    const cat = this.load().categories.find(c => c.id === id);
    if (!cat) return null;
    Object.assign(cat, patch);
    this.save();
    return cat;
  },
  deleteCategory(id) {
    const s = this.load();
    s.categories = s.categories.filter(c => c.id !== id);
    this.save();
  },
  getCategory(id) { return this.load().categories.find(c => c.id === id); },

  // ---------- Transaksi ----------
  _applyAccountDelta(accountId, delta) {
    const acc = this.getAccount(accountId);
    if (acc) acc.balance = Math.round((acc.balance + delta) * 100) / 100;
  },

  addTransaction(tx) {
    const s = this.load();
    const record = { id: uid('tx'), createdAt: Date.now(), ...tx };
    if (record.type === 'income') {
      this._applyAccountDelta(record.accountId, record.amount);
    } else if (record.type === 'expense') {
      this._applyAccountDelta(record.accountId, -record.amount);
    } else if (record.type === 'transfer') {
      this._applyAccountDelta(record.accountId, -record.amount);
      this._applyAccountDelta(record.toAccountId, record.amount);
    }
    s.transactions.push(record);
    this.save();
    return record;
  },

  _reverseTransactionEffect(record) {
    if (record.type === 'income') {
      this._applyAccountDelta(record.accountId, -record.amount);
    } else if (record.type === 'expense') {
      this._applyAccountDelta(record.accountId, record.amount);
    } else if (record.type === 'transfer') {
      this._applyAccountDelta(record.accountId, record.amount);
      this._applyAccountDelta(record.toAccountId, -record.amount);
    }
  },

  updateTransaction(id, patch) {
    const s = this.load();
    const record = s.transactions.find(t => t.id === id);
    if (!record) return null;
    this._reverseTransactionEffect(record);
    Object.assign(record, patch);
    if (record.type === 'income') {
      this._applyAccountDelta(record.accountId, record.amount);
    } else if (record.type === 'expense') {
      this._applyAccountDelta(record.accountId, -record.amount);
    } else if (record.type === 'transfer') {
      this._applyAccountDelta(record.accountId, -record.amount);
      this._applyAccountDelta(record.toAccountId, record.amount);
    }
    this.save();
    return record;
  },

  deleteTransaction(id) {
    const s = this.load();
    const record = s.transactions.find(t => t.id === id);
    if (!record) return;
    this._reverseTransactionEffect(record);
    s.transactions = s.transactions.filter(t => t.id !== id);
    this.save();
  },

  // ---------- Target Pengeluaran (Budget) ----------
  addBudget(b) {
    const budget = { id: uid('bud'), createdAt: Date.now(), archived: false, ...b };
    this.load().budgets.push(budget);
    this.save();
    return budget;
  },
  updateBudget(id, patch) {
    const b = this.load().budgets.find(x => x.id === id);
    if (!b) return null;
    Object.assign(b, patch);
    this.save();
    return b;
  },
  deleteBudget(id) {
    const s = this.load();
    s.budgets = s.budgets.filter(b => b.id !== id);
    this.save();
  },

  // ---------- Target Dana ----------
  addTarget(t) {
    const target = {
      id: uid('tgt'),
      createdAt: Date.now(),
      currentAmount: Number(t.initialAmount) || 0,
      status: 'active',
      history: [],
      ...t
    };
    if (t.initialAmount) {
      target.history.push({
        id: uid('th'), type: 'add', amount: Number(t.initialAmount),
        date: t.startDate || todayISO(), note: 'Dana awal', createdAt: Date.now()
      });
    }
    this.load().targets.push(target);
    this.save();
    return target;
  },
  updateTarget(id, patch) {
    const t = this.load().targets.find(x => x.id === id);
    if (!t) return null;
    Object.assign(t, patch);
    this._refreshTargetStatus(t);
    this.save();
    return t;
  },
  deleteTarget(id) {
    const s = this.load();
    s.targets = s.targets.filter(t => t.id !== id);
    this.save();
  },
  getTarget(id) { return this.load().targets.find(t => t.id === id); },

  _refreshTargetStatus(t) {
    if (t.currentAmount >= t.targetAmount) {
      t.status = 'achieved';
    } else if (t.status !== 'archived') {
      t.status = 'active';
    }
  },

  // Tambah dana ke target dari sebuah akun (mode dipisahkan atau virtual)
  addFundsToTarget(targetId, { amount, accountId, note, date }) {
    const t = this.getTarget(targetId);
    if (!t) return null;
    amount = Number(amount);
    this._applyAccountDelta(accountId, -amount);
    t.currentAmount = Math.round((t.currentAmount + amount) * 100) / 100;
    if (!t.linkedAccountId) t.linkedAccountId = accountId;
    const entry = { id: uid('th'), type: 'add', amount, accountId, date: date || todayISO(), note: note || '', createdAt: Date.now() };
    t.history.push(entry);
    this._refreshTargetStatus(t);
    this.save();
    return entry;
  },

  // Kurangi dana target (opsional, dikembalikan ke akun)
  removeFundsFromTarget(targetId, { amount, accountId, note, date }) {
    const t = this.getTarget(targetId);
    if (!t) return null;
    amount = Number(amount);
    t.currentAmount = Math.round((t.currentAmount - amount) * 100) / 100;
    if (accountId) this._applyAccountDelta(accountId, amount);
    const entry = { id: uid('th'), type: 'remove', amount, accountId, date: date || todayISO(), note: note || '', createdAt: Date.now() };
    t.history.push(entry);
    this._refreshTargetStatus(t);
    this.save();
    return entry;
  },

  editTargetHistoryEntry(targetId, entryId, patch) {
    const t = this.getTarget(targetId);
    if (!t) return null;
    const entry = t.history.find(h => h.id === entryId);
    if (!entry) return null;
    // Batalkan efek lama
    const oldAmt = entry.amount, oldType = entry.type, oldAcc = entry.accountId;
    if (oldType === 'add') {
      t.currentAmount -= oldAmt;
      if (oldAcc) this._applyAccountDelta(oldAcc, oldAmt);
    } else {
      t.currentAmount += oldAmt;
      if (oldAcc) this._applyAccountDelta(oldAcc, -oldAmt);
    }
    Object.assign(entry, patch);
    // Terapkan efek baru
    if (entry.type === 'add') {
      t.currentAmount += Number(entry.amount);
      if (entry.accountId) this._applyAccountDelta(entry.accountId, -Number(entry.amount));
    } else {
      t.currentAmount -= Number(entry.amount);
      if (entry.accountId) this._applyAccountDelta(entry.accountId, Number(entry.amount));
    }
    t.currentAmount = Math.round(t.currentAmount * 100) / 100;
    this._refreshTargetStatus(t);
    this.save();
    return entry;
  },

  deleteTargetHistoryEntry(targetId, entryId) {
    const t = this.getTarget(targetId);
    if (!t) return;
    const entry = t.history.find(h => h.id === entryId);
    if (!entry) return;
    if (entry.type === 'add') {
      t.currentAmount -= entry.amount;
      if (entry.accountId) this._applyAccountDelta(entry.accountId, entry.amount);
    } else {
      t.currentAmount += entry.amount;
      if (entry.accountId) this._applyAccountDelta(entry.accountId, -entry.amount);
    }
    t.currentAmount = Math.round(t.currentAmount * 100) / 100;
    t.history = t.history.filter(h => h.id !== entryId);
    this._refreshTargetStatus(t);
    this.save();
  },

  moveTargetStorage(targetId, newStorage) {
    const t = this.getTarget(targetId);
    if (!t) return null;
    const old = { storageType: t.storageType, storageDetail: t.storageDetail, linkedAccountId: t.linkedAccountId };
    Object.assign(t, newStorage);
    t.history.push({
      id: uid('th'), type: 'move', date: todayISO(), createdAt: Date.now(),
      note: `Dipindahkan dari ${old.storageDetail || old.storageType || '-'} ke ${newStorage.storageDetail || newStorage.storageType}`
    });
    this.save();
    return t;
  },

  // ---------- Backup / Restore ----------
  exportData() {
    return JSON.stringify(this.load(), null, 2);
  },
  importData(jsonStr) {
    const parsed = JSON.parse(jsonStr);
    if (!parsed || typeof parsed !== 'object' || !Array.isArray(parsed.accounts)) {
      throw new Error('Format file backup tidak valid');
    }
    this._state = parsed;
    this._migrate();
    this.save();
    return this._state;
  }
};
