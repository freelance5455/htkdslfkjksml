/* ==========================================================================
   DompetKu - Form Target Dana (pemilihan nama & penyimpanan via radio button)
   ========================================================================== */

function openTargetForm(id) {
  const editing = id ? DB.getTarget(id) : null;
  document.getElementById('targetFormTitle').textContent = editing ? 'Edit Target Dana' : 'Buat Target Dana';
  document.getElementById('targetFormBody').innerHTML = `
    <form id="targetForm">
      <label class="field-label">Nama Target</label>
      <div id="namePickerWrap"></div>

      <label class="field-label">Jumlah Dana yang Dibutuhkan</label>
      <input inputmode="numeric" id="tgtAmount" class="field-input field-amount" placeholder="Rp0" value="${editing ? formatNumberInput(editing.targetAmount) : ''}" required />

      ${editing ? '' : `
      <label class="field-label">Dana Awal (opsional)</label>
      <input inputmode="numeric" id="tgtInitial" class="field-input field-amount" placeholder="Rp0" />
      `}

      <label class="field-label">Tanggal Mulai</label>
      <input type="date" id="tgtStart" class="field-input" value="${editing ? editing.startDate : todayISO()}" required />

      <label class="field-label">Tanggal Target</label>
      <input type="date" id="tgtEnd" class="field-input" value="${editing ? editing.targetDate : ''}" required />

      <label class="field-label">Disimpan Di Mana?</label>
      <div id="storagePickerWrapMain"></div>

      <button type="submit" class="btn btn-primary btn-block">${editing ? 'Simpan Perubahan' : 'Buat Target Dana'}</button>
    </form>
  `;

  renderNamePicker(document.getElementById('namePickerWrap'), editing ? editing.name : null, editing ? editing.isCustomName : false);
  renderStoragePicker(document.getElementById('storagePickerWrapMain'), editing ? { storageType: editing.storageType, storageDetail: editing.storageDetail } : {});
  if (document.getElementById('tgtInitial')) bindRupiahInput(document.getElementById('tgtInitial'));
  bindRupiahInput(document.getElementById('tgtAmount'));

  document.getElementById('targetForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const nameVal = readNamePicker();
    if (!nameVal) { toast('Pilih nama target', 'warn'); return; }
    const targetAmount = parseRupiahInput(document.getElementById('tgtAmount').value);
    if (!targetAmount || targetAmount <= 0) { toast('Jumlah dana harus lebih dari 0', 'warn'); return; }
    const startDate = document.getElementById('tgtStart').value;
    const targetDate = document.getElementById('tgtEnd').value;
    if (!startDate || !targetDate) { toast('Lengkapi tanggal mulai dan tanggal target', 'warn'); return; }
    if (targetDate < startDate) { toast('Tanggal target harus setelah tanggal mulai', 'warn'); return; }
    const storageVal = readStoragePicker();
    if (!storageVal) { toast('Pilih tempat penyimpanan dana', 'warn'); return; }

    const payload = {
      name: nameVal.name, isCustomName: nameVal.isCustom,
      targetAmount, startDate, targetDate,
      storageType: storageVal.storageType, storageDetail: storageVal.storageDetail
    };

    if (editing) {
      DB.updateTarget(editing.id, payload);
      toast('Target diperbarui');
      closeModal('targetFormModal');
      App.render('target-detail', editing.id);
    } else {
      const initialAmount = document.getElementById('tgtInitial') ? parseRupiahInput(document.getElementById('tgtInitial').value) : 0;
      payload.initialAmount = initialAmount;
      const t = DB.addTarget(payload);
      toast('Target dana dibuat');
      closeModal('targetFormModal');
      location.hash = '#/target-detail/' + t.id;
    }
  }, { once: true });

  openModal('targetFormModal');
}

/* ---------- Radio-button name picker (mempertahankan gaya versi lama) ---------- */

function renderNamePicker(container, currentName, wasCustom) {
  const isKnown = TARGET_DANA_NAMES.includes(currentName) && !wasCustom;
  container.innerHTML = `
    <div class="radio-list" id="nameRadioList">
      ${TARGET_DANA_NAMES.map(n => `
        <label class="radio-row">
          <span class="radio-row-label">${escapeHtml(n)}</span>
          <input type="radio" name="tgtNameChoice" value="${escapeHtml(n)}" ${currentName === n && (isKnown || n !== 'Lainnya' ? currentName === n && !(wasCustom) : false) ? '' : ''} class="radio-circle" />
        </label>
      `).join('')}
    </div>
    <div id="customNameWrap" style="display:none">
      <input id="customNameInput" class="field-input" placeholder="Tulis nama target..." />
    </div>
  `;
  // Set initial selection correctly
  const radios = container.querySelectorAll('input[name="tgtNameChoice"]');
  let preset = false;
  if (currentName) {
    if (wasCustom) {
      const lainnya = [...radios].find(r => r.value === 'Lainnya');
      if (lainnya) lainnya.checked = true;
      document.getElementById('customNameWrap').style.display = 'block';
      document.getElementById('customNameInput').value = currentName;
      preset = true;
    } else {
      const match = [...radios].find(r => r.value === currentName);
      if (match) { match.checked = true; preset = true; }
    }
  }
  radios.forEach(r => {
    r.addEventListener('change', () => {
      document.getElementById('customNameWrap').style.display = r.value === 'Lainnya' && r.checked ? 'block' : (r.value === 'Lainnya' ? 'none' : document.getElementById('customNameWrap').style.display);
      if (r.checked && r.value === 'Lainnya') {
        document.getElementById('customNameWrap').style.display = 'block';
      } else if (r.checked) {
        document.getElementById('customNameWrap').style.display = 'none';
      }
    });
  });
}

function readNamePicker() {
  const checked = document.querySelector('input[name="tgtNameChoice"]:checked');
  if (!checked) return null;
  if (checked.value === 'Lainnya') {
    const custom = document.getElementById('customNameInput').value.trim();
    if (!custom) return null;
    return { name: custom, isCustom: true };
  }
  return { name: checked.value, isCustom: false };
}

/* ---------- Radio-button storage picker ---------- */

const STORAGE_MAIN_OPTIONS = ['Cash/Tunai', 'Bank', 'E-Wallet', 'Lainnya'];
const STORAGE_BANK_OPTIONS = ['BCA', 'BRI', 'BNI', 'Mandiri', 'Bank lainnya'];

function renderStoragePicker(container, current) {
  current = current || {};
  const mainVal = current.storageType || '';
  container.innerHTML = `
    <div class="radio-list" id="storageMainList">
      ${STORAGE_MAIN_OPTIONS.map(opt => `
        <label class="radio-row">
          <span class="radio-row-label">${escapeHtml(opt)}</span>
          <input type="radio" name="storageMainChoice" value="${escapeHtml(opt)}" class="radio-circle" />
        </label>
      `).join('')}
    </div>
    <div id="storageBankWrap" style="display:none; margin-top:4px">
      <div class="radio-list">
        ${STORAGE_BANK_OPTIONS.map(opt => `
          <label class="radio-row sub">
            <span class="radio-row-label">${escapeHtml(opt)}</span>
            <input type="radio" name="storageBankChoice" value="${escapeHtml(opt)}" class="radio-circle" />
          </label>
        `).join('')}
      </div>
      <div id="storageBankOtherWrap" style="display:none">
        <input id="storageBankOtherInput" class="field-input" placeholder="Nama bank lainnya..." />
      </div>
    </div>
    <div id="storageOtherWrap" style="display:none">
      <input id="storageOtherInput" class="field-input" placeholder="Tulis tempat penyimpanan..." />
    </div>
  `;

  const mainRadios = container.querySelectorAll('input[name="storageMainChoice"]');
  const bankWrap = document.getElementById('storageBankWrap');
  const otherWrap = document.getElementById('storageOtherWrap');
  const bankOtherWrap = document.getElementById('storageBankOtherWrap');

  mainRadios.forEach(r => {
    r.addEventListener('change', () => {
      bankWrap.style.display = r.value === 'Bank' && r.checked ? 'block' : (r.checked ? 'none' : bankWrap.style.display);
      otherWrap.style.display = r.value === 'Lainnya' && r.checked ? 'block' : (r.checked ? 'none' : otherWrap.style.display);
    });
  });

  container.querySelectorAll('input[name="storageBankChoice"]').forEach(r => {
    r.addEventListener('change', () => {
      bankOtherWrap.style.display = r.value === 'Bank lainnya' && r.checked ? 'block' : 'none';
    });
  });

  // Pre-fill kalau edit
  if (mainVal === 'Cash/Tunai' || mainVal === 'E-Wallet') {
    const m = [...mainRadios].find(x => x.value === mainVal);
    if (m) m.checked = true;
  } else if (mainVal === 'Bank') {
    const m = [...mainRadios].find(x => x.value === 'Bank');
    if (m) m.checked = true;
    bankWrap.style.display = 'block';
    const bankName = current.storageDetail;
    const knownBank = STORAGE_BANK_OPTIONS.includes(bankName);
    const bankRadios = container.querySelectorAll('input[name="storageBankChoice"]');
    if (knownBank) {
      const b = [...bankRadios].find(x => x.value === bankName);
      if (b) b.checked = true;
    } else if (bankName) {
      const b = [...bankRadios].find(x => x.value === 'Bank lainnya');
      if (b) b.checked = true;
      bankOtherWrap.style.display = 'block';
      document.getElementById('storageBankOtherInput').value = bankName;
    }
  } else if (mainVal === 'Lainnya') {
    const m = [...mainRadios].find(x => x.value === 'Lainnya');
    if (m) m.checked = true;
    otherWrap.style.display = 'block';
    document.getElementById('storageOtherInput').value = current.storageDetail || '';
  }
}

function readStoragePicker() {
  const main = document.querySelector('input[name="storageMainChoice"]:checked');
  if (!main) return null;
  if (main.value === 'Bank') {
    const bank = document.querySelector('input[name="storageBankChoice"]:checked');
    if (!bank) return null;
    if (bank.value === 'Bank lainnya') {
      const name = document.getElementById('storageBankOtherInput').value.trim();
      if (!name) return null;
      return { storageType: 'Bank', storageDetail: name };
    }
    return { storageType: 'Bank', storageDetail: bank.value };
  }
  if (main.value === 'Lainnya') {
    const name = document.getElementById('storageOtherInput').value.trim();
    if (!name) return null;
    return { storageType: 'Lainnya', storageDetail: name };
  }
  return { storageType: main.value, storageDetail: main.value };
}
