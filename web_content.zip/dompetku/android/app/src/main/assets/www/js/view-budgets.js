/* ==========================================================================
   DompetKu - Target Pengeluaran (Anggaran)
   ========================================================================== */

function renderBudgetsTab(container) {
  const s = DB.state();
  const budgets = s.budgets.filter(b => !b.archived);
  container.innerHTML = `
    <div class="tab-actions">
      <button class="btn btn-primary btn-sm" onclick="openBudgetForm()">${ICON.plus} Buat Target Pengeluaran</button>
    </div>
    <div class="budget-list">
      ${budgets.length ? budgets.map(budgetCard).join('') : `<div class="empty-state">${ICON.target}<div>Belum ada target pengeluaran. Batasi pengeluaran per kategori supaya lebih terkontrol.</div></div>`}
    </div>
  `;
}

function budgetCard(b) {
  const cat = DB.getCategory(b.categoryId);
  const s = DB.state();
  const range = computeBudgetPeriodRange(b);
  const used = s.transactions.filter(t => t.type === 'expense' && t.categoryId === b.categoryId && isDateInRange(t.date, range.start, range.end))
    .reduce((sum, t) => sum + t.amount, 0);
  const sisa = b.limit - used;
  const pct = b.limit > 0 ? (used / b.limit) * 100 : 0;
  const over = used > b.limit;
  const periodLabel = { weekly: 'Mingguan', monthly: 'Bulanan', yearly: 'Tahunan', custom: 'Custom' }[b.period];
  return `
    <div class="budget-card">
      <div class="budget-card-top">
        <div>
          <div class="budget-cat">${escapeHtml(cat ? cat.name : '-')}</div>
          <div class="budget-period">${periodLabel} · ${formatDateShort(range.start)} - ${formatDateShort(range.end)}</div>
        </div>
        <div class="budget-actions">
          <button class="icon-btn-sm" onclick="openBudgetForm('${b.id}')">${ICON.edit}</button>
          <button class="icon-btn-sm" onclick="deleteBudgetFlow('${b.id}')">${ICON.trash}</button>
        </div>
      </div>
      <div class="bar-track lg"><div class="bar-fill ${over ? 'bar-over' : ''}" style="width:${Math.min(100, pct)}%; background:${over ? '' : (cat ? cat.color : '#1B8A5A')}"></div></div>
      <div class="budget-stats">
        <span>Terpakai: <strong class="${over ? 'neg' : ''}">${formatRupiah(used)}</strong></span>
        <span>Sisa: <strong class="${sisa < 0 ? 'neg' : ''}">${formatRupiah(sisa)}</strong></span>
        <span>${pct.toFixed(0)}%</span>
      </div>
      ${over ? `<div class="budget-warning">⚠ Pengeluaran melebihi batas target</div>` : ''}
    </div>
  `;
}

function openBudgetForm(id) {
  const s = DB.state();
  if (!s.categories.length) { toast('Belum ada kategori', 'warn'); return; }
  const editing = id ? s.budgets.find(b => b.id === id) : null;
  document.getElementById('budgetFormTitle').textContent = editing ? 'Edit Target Pengeluaran' : 'Buat Target Pengeluaran';
  document.getElementById('budgetFormBody').innerHTML = `
    <form id="budgetForm">
      <label class="field-label">Kategori</label>
      <select id="budCategory" class="field-input">
        ${s.categories.map(c => `<option value="${c.id}" ${editing && editing.categoryId === c.id ? 'selected' : ''}>${escapeHtml(c.name)}</option>`).join('')}
      </select>
      <label class="field-label">Batas Pengeluaran</label>
      <input inputmode="numeric" id="budLimit" class="field-input field-amount" placeholder="Rp0" value="${editing ? formatNumberInput(editing.limit) : ''}" required />
      <label class="field-label">Periode</label>
      <select id="budPeriod" class="field-input">
        <option value="weekly" ${editing && editing.period === 'weekly' ? 'selected' : ''}>Mingguan</option>
        <option value="monthly" ${!editing || editing.period === 'monthly' ? 'selected' : ''}>Bulanan</option>
        <option value="yearly" ${editing && editing.period === 'yearly' ? 'selected' : ''}>Tahunan</option>
        <option value="custom" ${editing && editing.period === 'custom' ? 'selected' : ''}>Custom</option>
      </select>
      <div id="budCustomRange" style="display:${editing && editing.period === 'custom' ? 'block' : 'none'}">
        <label class="field-label">Tanggal Mulai</label>
        <input type="date" id="budStart" class="field-input" value="${editing ? editing.startDate || '' : todayISO()}" />
        <label class="field-label">Tanggal Berakhir</label>
        <input type="date" id="budEnd" class="field-input" value="${editing ? editing.endDate || '' : ''}" />
      </div>
      <button type="submit" class="btn btn-primary btn-block">${editing ? 'Simpan Perubahan' : 'Buat Target'}</button>
    </form>
  `;
  bindRupiahInput(document.getElementById('budLimit'));
  document.getElementById('budPeriod').addEventListener('change', (e) => {
    document.getElementById('budCustomRange').style.display = e.target.value === 'custom' ? 'block' : 'none';
  });
  document.getElementById('budgetForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const categoryId = document.getElementById('budCategory').value;
    const limit = parseRupiahInput(document.getElementById('budLimit').value);
    if (!limit || limit <= 0) { toast('Batas pengeluaran harus lebih dari 0', 'warn'); return; }
    const period = document.getElementById('budPeriod').value;
    const payload = { categoryId, limit, period };
    if (period === 'custom') {
      payload.startDate = document.getElementById('budStart').value;
      payload.endDate = document.getElementById('budEnd').value;
      if (!payload.startDate || !payload.endDate) { toast('Isi rentang tanggal custom', 'warn'); return; }
    }
    if (editing) DB.updateBudget(editing.id, payload); else DB.addBudget(payload);
    closeModal('budgetFormModal');
    toast(editing ? 'Target diperbarui' : 'Target pengeluaran dibuat');
    App.render(App.route, 'budget');
  }, { once: true });
  openModal('budgetFormModal');
}

async function deleteBudgetFlow(id) {
  const ok = await confirmDialog('Hapus target pengeluaran ini? Riwayat pengeluaran tidak akan terhapus.');
  if (!ok) return;
  DB.deleteBudget(id);
  toast('Target pengeluaran dihapus');
  App.render(App.route, 'budget');
}
