/* ==========================================================================
   DompetKu - Halaman Transaksi & Form Transaksi
   ========================================================================== */

let txFilter = { type: 'all', accountId: 'all', categoryId: 'all', month: '', year: '' };

function renderTransactions(main) {
  const s = DB.state();
  main.innerHTML = `
    <div class="page">
      <div class="page-header">
        <div class="page-title">Riwayat Transaksi</div>
      </div>
      <div class="filter-row">
        <select id="fType" class="select-chip">
          <option value="all">Semua Jenis</option>
          <option value="income">Pemasukan</option>
          <option value="expense">Pengeluaran</option>
          <option value="transfer">Transfer</option>
          <option value="target">Target Dana</option>
        </select>
        <select id="fAccount" class="select-chip">
          <option value="all">Semua Akun</option>
          ${s.accounts.map(a => `<option value="${a.id}">${escapeHtml(a.name)}</option>`).join('')}
        </select>
        <select id="fCategory" class="select-chip">
          <option value="all">Semua Kategori</option>
          ${s.categories.map(c => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join('')}
        </select>
      </div>
      <div id="txList" class="tx-list"></div>
      <div class="bottom-spacer"></div>
    </div>
  `;
  ['fType', 'fAccount', 'fCategory'].forEach(id => {
    document.getElementById(id).addEventListener('change', (e) => {
      const key = id === 'fType' ? 'type' : id === 'fAccount' ? 'accountId' : 'categoryId';
      txFilter[key] = e.target.value;
      renderTxList();
    });
  });
  document.getElementById('fType').value = txFilter.type;
  document.getElementById('fAccount').value = txFilter.accountId;
  document.getElementById('fCategory').value = txFilter.categoryId;
  renderTxList();
}

function renderTxList() {
  const s = DB.state();
  const listEl = document.getElementById('txList');
  if (!listEl) return;

  let items = [...s.transactions];
  // Sertakan histori target dana sebagai entri transaksi juga
  let targetEntries = [];
  s.targets.forEach(t => {
    t.history.forEach(h => {
      if (h.type === 'add' || h.type === 'remove') {
        targetEntries.push({ id: h.id, kind: 'target', targetId: t.id, targetName: t.name, ...h });
      }
    });
  });

  if (txFilter.type !== 'all' && txFilter.type !== 'target') {
    items = items.filter(t => t.type === txFilter.type);
    targetEntries = [];
  } else if (txFilter.type === 'target') {
    items = [];
  }
  if (txFilter.accountId !== 'all') {
    items = items.filter(t => t.accountId === txFilter.accountId || t.toAccountId === txFilter.accountId);
    targetEntries = targetEntries.filter(t => t.accountId === txFilter.accountId);
  }
  if (txFilter.categoryId !== 'all') {
    items = items.filter(t => t.categoryId === txFilter.categoryId);
    if (txFilter.type !== 'all') targetEntries = [];
  }

  const combined = [
    ...items.map(t => ({ sortKey: t.createdAt, html: transactionRow(t) })),
    ...targetEntries.map(t => ({ sortKey: t.createdAt, html: targetHistoryAsTxRow(t) }))
  ].sort((a, b) => b.sortKey - a.sortKey);

  listEl.innerHTML = combined.length ? combined.map(x => x.html).join('') : `<div class="empty-state">${ICON.target}<div>Belum ada transaksi yang cocok.</div></div>`;
}

function targetHistoryAsTxRow(h) {
  const isAdd = h.type === 'add';
  return `
    <div class="tx-row" onclick="location.hash='#/target-detail/${h.targetId}'">
      <div class="tx-icon">${ICON.target}</div>
      <div class="tx-mid">
        <div class="tx-title">${isAdd ? 'Menabung untuk' : 'Ambil dari'} ${escapeHtml(h.targetName)}</div>
        <div class="tx-date">${formatDateShort(h.date)}${h.note ? ' · ' + escapeHtml(h.note) : ''}</div>
      </div>
      <div class="tx-amount ${isAdd ? 'target-add' : 'neg'}">${isAdd ? '+' : '-'}${formatRupiah(h.amount)}</div>
    </div>
  `;
}

function openTransactionDetail(id) {
  const t = DB.state().transactions.find(x => x.id === id);
  if (!t) return;
  let body = '';
  if (t.type === 'expense') {
    const cat = DB.getCategory(t.categoryId);
    const acc = DB.getAccount(t.accountId);
    body = `<div class="detail-line">Kategori: <strong>${escapeHtml(cat ? cat.name : '-')}</strong></div>
      <div class="detail-line">Akun: <strong>${escapeHtml(acc ? acc.name : '-')}</strong></div>`;
  } else if (t.type === 'income') {
    const acc = DB.getAccount(t.accountId);
    body = `<div class="detail-line">Akun Tujuan: <strong>${escapeHtml(acc ? acc.name : '-')}</strong></div>`;
  } else if (t.type === 'transfer') {
    const from = DB.getAccount(t.accountId), to = DB.getAccount(t.toAccountId);
    body = `<div class="detail-line">Dari: <strong>${escapeHtml(from ? from.name : '-')}</strong></div>
      <div class="detail-line">Ke: <strong>${escapeHtml(to ? to.name : '-')}</strong></div>`;
  }
  showInfoSheet(formatRupiah(t.amount), `
    ${body}
    <div class="detail-line">Tanggal: <strong>${formatDateLong(t.date)}</strong></div>
    ${t.note ? `<div class="detail-line">Catatan: <strong>${escapeHtml(t.note)}</strong></div>` : ''}
    <div class="sheet-actions">
      <button class="btn btn-secondary" onclick="closeModal('infoSheet');openTransactionForm('${t.type}','${t.id}')">${ICON.edit} Edit</button>
      <button class="btn btn-danger" onclick="closeModal('infoSheet');deleteTransactionFlow('${t.id}')">${ICON.trash} Hapus</button>
    </div>
  `);
}

async function deleteTransactionFlow(id) {
  const ok = await confirmDialog('Hapus transaksi ini? Saldo akun akan disesuaikan kembali.');
  if (!ok) return;
  DB.deleteTransaction(id);
  toast('Transaksi dihapus');
  App.render(App.route);
}

// ---------------- Form Transaksi ----------------

function openTransactionForm(type, editId) {
  const s = DB.state();
  if (!s.accounts.length) {
    toast('Tambahkan akun terlebih dahulu', 'warn');
    location.hash = '#/accounts';
    return;
  }
  const editing = editId ? s.transactions.find(t => t.id === editId) : null;
  type = editing ? editing.type : type;

  const modalBody = document.getElementById('txFormBody');
  document.getElementById('txFormTitle').textContent = editing ? 'Edit Transaksi' : 'Tambah Transaksi';

  modalBody.innerHTML = `
    <div class="type-switch" id="typeSwitch">
      <button type="button" data-type="expense" class="type-btn ${type === 'expense' ? 'active' : ''}">Pengeluaran</button>
      <button type="button" data-type="income" class="type-btn ${type === 'income' ? 'active' : ''}">Pemasukan</button>
      <button type="button" data-type="transfer" class="type-btn ${type === 'transfer' ? 'active' : ''}">Transfer</button>
    </div>
    <form id="txForm">
      <label class="field-label">Nominal</label>
      <input inputmode="numeric" id="txAmount" class="field-input field-amount" placeholder="Rp0" value="${editing ? formatNumberInput(editing.amount) : ''}" required />

      <div id="txCategoryWrap" style="display:${type === 'expense' ? 'block' : 'none'}">
        <label class="field-label">Kategori</label>
        <select id="txCategory" class="field-input">
          ${s.categories.map(c => `<option value="${c.id}" ${editing && editing.categoryId === c.id ? 'selected' : ''}>${escapeHtml(c.name)}</option>`).join('')}
        </select>
      </div>

      <label class="field-label" id="txAccountLabel">${type === 'transfer' ? 'Dari Akun' : type === 'income' ? 'Akun Tujuan' : 'Akun / Sumber Dana'}</label>
      <select id="txAccount" class="field-input">
        ${s.accounts.map(a => `<option value="${a.id}" ${editing && editing.accountId === a.id ? 'selected' : ''}>${escapeHtml(a.name)} (${formatRupiah(a.balance)})</option>`).join('')}
      </select>

      <div id="txToAccountWrap" style="display:${type === 'transfer' ? 'block' : 'none'}">
        <label class="field-label">Ke Akun</label>
        <select id="txToAccount" class="field-input">
          ${s.accounts.map(a => `<option value="${a.id}" ${editing && editing.toAccountId === a.id ? 'selected' : ''}>${escapeHtml(a.name)} (${formatRupiah(a.balance)})</option>`).join('')}
        </select>
      </div>

      <label class="field-label">Tanggal</label>
      <input type="date" id="txDate" class="field-input" value="${editing ? editing.date : todayISO()}" required />

      <label class="field-label">Catatan (opsional)</label>
      <input id="txNote" class="field-input" placeholder="Catatan..." value="${editing ? escapeHtml(editing.note || '') : ''}" />

      <button type="submit" class="btn btn-primary btn-block">${editing ? 'Simpan Perubahan' : 'Simpan Transaksi'}</button>
    </form>
  `;

  bindRupiahInput(document.getElementById('txAmount'));

  modalBody.querySelectorAll('.type-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      modalBody.querySelectorAll('.type-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const t = btn.dataset.type;
      document.getElementById('txCategoryWrap').style.display = t === 'expense' ? 'block' : 'none';
      document.getElementById('txToAccountWrap').style.display = t === 'transfer' ? 'block' : 'none';
      document.getElementById('txAccountLabel').textContent = t === 'transfer' ? 'Dari Akun' : t === 'income' ? 'Akun Tujuan' : 'Akun / Sumber Dana';
      modalBody.dataset.type = t;
    });
  });
  modalBody.dataset.type = type;

  document.getElementById('txForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const currentType = modalBody.dataset.type;
    const amount = parseRupiahInput(document.getElementById('txAmount').value);
    if (!amount || amount <= 0) { toast('Nominal harus lebih dari 0', 'warn'); return; }
    const date = document.getElementById('txDate').value || todayISO();
    const note = document.getElementById('txNote').value.trim();
    const accountId = document.getElementById('txAccount').value;

    if (currentType === 'transfer') {
      const toAccountId = document.getElementById('txToAccount').value;
      if (accountId === toAccountId) { toast('Akun asal dan tujuan tidak boleh sama', 'warn'); return; }
      const payload = { type: 'transfer', amount, accountId, toAccountId, date, note };
      if (editing) DB.updateTransaction(editing.id, payload); else DB.addTransaction(payload);
    } else if (currentType === 'income') {
      const payload = { type: 'income', amount, accountId, date, note };
      if (editing) DB.updateTransaction(editing.id, payload); else DB.addTransaction(payload);
    } else {
      const categoryId = document.getElementById('txCategory').value;
      const payload = { type: 'expense', amount, accountId, categoryId, date, note };
      if (editing) DB.updateTransaction(editing.id, payload); else DB.addTransaction(payload);
    }
    closeModal('txFormModal');
    toast(editing ? 'Transaksi diperbarui' : 'Transaksi tersimpan');
    App.render(App.route, location.hash.split('/')[2]);
  }, { once: true });

  openModal('txFormModal');
}

function bindRupiahInput(input) {
  input.addEventListener('input', () => {
    const raw = parseRupiahInput(input.value);
    input.value = raw ? formatNumberInput(raw) : '';
  });
}
