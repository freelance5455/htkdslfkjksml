/* ==========================================================================
   DompetKu - Hub Target (Target Pengeluaran & Target Dana)
   ========================================================================== */

function renderTargetsHub(main, tab) {
  tab = tab === 'budget' ? 'budget' : 'dana';
  main.innerHTML = `
    <div class="page">
      <div class="page-header">
        <div class="page-title">Target</div>
      </div>
      <div class="type-switch" id="targetTabSwitch">
        <button type="button" data-tab="dana" class="type-btn ${tab === 'dana' ? 'active' : ''}">Target Dana</button>
        <button type="button" data-tab="budget" class="type-btn ${tab === 'budget' ? 'active' : ''}">Target Pengeluaran</button>
      </div>
      <div id="targetTabBody"></div>
      <div class="bottom-spacer"></div>
    </div>
  `;
  document.querySelectorAll('#targetTabSwitch .type-btn').forEach(btn => {
    btn.addEventListener('click', () => location.hash = '#/targets/' + btn.dataset.tab);
  });
  const body = document.getElementById('targetTabBody');
  if (tab === 'budget') renderBudgetsTab(body);
  else renderTargetDanaTab(body);
}

function renderTargetDanaTab(container) {
  const s = DB.state();
  const active = s.targets.filter(t => t.status === 'active');
  const achieved = s.targets.filter(t => t.status === 'achieved');
  const archived = s.targets.filter(t => t.status === 'archived');
  container.innerHTML = `
    <div class="tab-actions">
      <button class="btn btn-primary btn-sm" onclick="openTargetForm()">${ICON.plus} Buat Target Dana</button>
    </div>
    ${active.length ? `<div class="section-title">Aktif</div><div class="target-list">${active.map(targetCard).join('')}</div>` : ''}
    ${achieved.length ? `<div class="section-title">Tercapai ✓</div><div class="target-list">${achieved.map(targetCard).join('')}</div>` : ''}
    ${archived.length ? `<div class="section-title">Arsip</div><div class="target-list">${archived.map(targetCard).join('')}</div>` : ''}
    ${!s.targets.length ? `<div class="empty-state">${ICON.target}<div>Belum ada Target Dana. Buat target seperti "Menikah", "Dana Darurat", atau "Liburan".</div></div>` : ''}
  `;
}

function targetCard(t) {
  const pct = t.targetAmount > 0 ? Math.min(100, (t.currentAmount / t.targetAmount) * 100) : 0;
  const overdue = t.status === 'active' && daysBetween(todayISO(), t.targetDate) < 0;
  const statusBadge = t.status === 'achieved' ? '<span class="badge badge-success">Tercapai</span>'
    : t.status === 'archived' ? '<span class="badge badge-muted">Arsip</span>'
    : overdue ? '<span class="badge badge-danger">Lewat tenggat</span>' : '';
  return `
    <div class="target-card" onclick="location.hash='#/target-detail/${t.id}'">
      <div class="target-card-top">
        <div class="target-card-name">${escapeHtml(t.name)} ${statusBadge}</div>
        <span class="target-card-pct">${pct.toFixed(0)}%</span>
      </div>
      <div class="bar-track lg"><div class="bar-fill" style="width:${pct}%; background:#1B8A5A"></div></div>
      <div class="target-card-bottom">
        <span>${formatRupiah(t.currentAmount)} / ${formatRupiah(t.targetAmount)}</span>
        <span class="target-card-storage">${escapeHtml(t.storageDetail || t.storageType || '-')}</span>
      </div>
    </div>
  `;
}

/* ---------------- Detail Target Dana ---------------- */

function renderTargetDetail(main, id) {
  const t = DB.getTarget(id);
  if (!t) { location.hash = '#/targets/dana'; return; }
  const rec = calcSavingsRecommendation(t);
  const pct = t.targetAmount > 0 ? Math.min(100, (t.currentAmount / t.targetAmount) * 100) : 0;
  const history = [...t.history].sort((a, b) => b.createdAt - a.createdAt);

  main.innerHTML = `
    <div class="page">
      <div class="page-header">
        <button class="icon-btn" onclick="location.hash='#/targets/dana'">${'<svg viewBox="0 0 24 24" fill="none"><path d="M15 6l-6 6 6 6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>'}</button>
        <div class="page-title">${escapeHtml(t.name)}</div>
        <button class="icon-btn" onclick="openTargetForm('${t.id}')">${ICON.edit}</button>
      </div>

      <div class="section-card center-col">
        <div id="targetProgressCircle" class="progress-circle-wrap"></div>
        <div class="target-detail-amounts">
          <div class="target-detail-collected">${formatRupiah(t.currentAmount)}</div>
          <div class="target-detail-of">dari target ${formatRupiah(t.targetAmount)}</div>
        </div>
        <div class="target-detail-grid">
          <div><span class="tdl">Masih dibutuhkan</span><span class="tdv">${formatRupiah(rec.remaining)}</span></div>
          <div><span class="tdl">Disimpan di</span><span class="tdv">${escapeHtml(t.storageDetail || t.storageType)}</span></div>
          <div><span class="tdl">Mulai</span><span class="tdv">${formatDateShort(t.startDate)}</span></div>
          <div><span class="tdl">Target</span><span class="tdv">${formatDateShort(t.targetDate)}</span></div>
        </div>
        ${rec.isOverdue ? `<div class="budget-warning">⚠ Tanggal target sudah lewat dan dana belum tercapai</div>` :
          t.status === 'achieved' ? `<div class="target-achieved-msg">🎉 Target sudah tercapai!</div>` : `
          <div class="reco-box">
            <div class="reco-title">Rekomendasi Menabung</div>
            <div class="reco-row"><span>Per bulan</span><strong>${formatRupiah(rec.perMonth)}</strong></div>
            <div class="reco-row"><span>Per minggu</span><strong>${formatRupiah(rec.perWeek)}</strong></div>
            <div class="reco-row"><span>Per hari</span><strong>${formatRupiah(rec.perDay)}</strong></div>
          </div>
        `}
        <div class="target-actions-row">
          <button class="btn btn-primary" onclick="openAddFundsForm('${t.id}')">+ Tambah Dana</button>
          <button class="btn btn-secondary" onclick="openMoveStorageForm('${t.id}')">Pindah Penyimpanan</button>
        </div>
        <div class="target-actions-row">
          ${t.status !== 'archived' ? `<button class="btn btn-ghost btn-sm" onclick="archiveTargetFlow('${t.id}')">Arsipkan Target</button>` : `<button class="btn btn-ghost btn-sm" onclick="unarchiveTargetFlow('${t.id}')">Aktifkan Kembali</button>`}
          <button class="btn btn-ghost btn-sm danger-text" onclick="deleteTargetFlow('${t.id}')">Hapus Target</button>
        </div>
      </div>

      <div class="section-card">
        <div class="section-title">Riwayat Target</div>
        ${history.length ? history.map(h => targetHistoryRow(t, h)).join('') : '<div class="empty-mini">Belum ada riwayat.</div>'}
      </div>
      <div class="bottom-spacer"></div>
    </div>
  `;

  renderProgressCircle(document.getElementById('targetProgressCircle'), pct, { size: 140, thickness: 14 });
}

function targetHistoryRow(t, h) {
  let icon = ICON.target, label = '', amountHtml = '';
  if (h.type === 'add') {
    label = 'Menabung' + (h.accountId && DB.getAccount(h.accountId) ? ' dari ' + DB.getAccount(h.accountId).name : '');
    amountHtml = `<span class="tx-amount target-add">+${formatRupiah(h.amount)}</span>`;
  } else if (h.type === 'remove') {
    label = 'Menarik dana' + (h.accountId && DB.getAccount(h.accountId) ? ' ke ' + DB.getAccount(h.accountId).name : '');
    amountHtml = `<span class="tx-amount neg">-${formatRupiah(h.amount)}</span>`;
  } else if (h.type === 'move') {
    label = 'Pindah lokasi penyimpanan';
    amountHtml = '';
  }
  return `
    <div class="tx-row">
      <div class="tx-icon">${icon}</div>
      <div class="tx-mid">
        <div class="tx-title">${escapeHtml(label)}</div>
        <div class="tx-date">${formatDateShort(h.date)}${h.note ? ' · ' + escapeHtml(h.note) : ''}</div>
      </div>
      ${amountHtml}
      ${h.type !== 'move' ? `
      <div class="tx-row-actions">
        <button class="icon-btn-sm" onclick="editTargetHistoryFlow('${t.id}','${h.id}')">${ICON.edit}</button>
        <button class="icon-btn-sm" onclick="deleteTargetHistoryFlow('${t.id}','${h.id}')">${ICON.trash}</button>
      </div>` : ''}
    </div>
  `;
}

async function archiveTargetFlow(id) {
  const ok = await confirmDialog('Arsipkan target ini? Riwayatnya tetap tersimpan.');
  if (!ok) return;
  DB.updateTarget(id, { status: 'archived' });
  toast('Target diarsipkan');
  App.render('target-detail', id);
}
function unarchiveTargetFlow(id) {
  DB.updateTarget(id, { status: 'active' });
  App._refreshAfterTargetChange && App._refreshAfterTargetChange();
  toast('Target diaktifkan kembali');
  App.render('target-detail', id);
}
async function deleteTargetFlow(id) {
  const ok = await confirmDialog('Hapus target ini beserta seluruh riwayatnya? Tindakan ini tidak dapat dibatalkan.');
  if (!ok) return;
  DB.deleteTarget(id);
  toast('Target dihapus');
  location.hash = '#/targets/dana';
}

async function editTargetHistoryFlow(targetId, entryId) {
  const t = DB.getTarget(targetId);
  const entry = t.history.find(h => h.id === entryId);
  if (!entry) return;
  const s = DB.state();
  document.getElementById('fundsFormTitle').textContent = 'Edit Riwayat';
  document.getElementById('fundsFormBody').innerHTML = `
    <form id="fundsForm">
      <label class="field-label">Nominal</label>
      <input inputmode="numeric" id="fundsAmount" class="field-input field-amount" value="${formatNumberInput(entry.amount)}" required />
      <label class="field-label">Akun Terkait</label>
      <select id="fundsAccount" class="field-input">
        <option value="">- Tidak terkait akun -</option>
        ${s.accounts.map(a => `<option value="${a.id}" ${entry.accountId === a.id ? 'selected' : ''}>${escapeHtml(a.name)}</option>`).join('')}
      </select>
      <label class="field-label">Tanggal</label>
      <input type="date" id="fundsDate" class="field-input" value="${entry.date}" required />
      <label class="field-label">Catatan (opsional)</label>
      <input id="fundsNote" class="field-input" value="${escapeHtml(entry.note || '')}" />
      <button type="submit" class="btn btn-primary btn-block">Simpan Perubahan</button>
    </form>
  `;
  bindRupiahInput(document.getElementById('fundsAmount'));
  document.getElementById('fundsForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const amount = parseRupiahInput(document.getElementById('fundsAmount').value);
    const accountId = document.getElementById('fundsAccount').value || null;
    const date = document.getElementById('fundsDate').value;
    const note = document.getElementById('fundsNote').value.trim();
    DB.editTargetHistoryEntry(targetId, entryId, { amount, accountId, date, note });
    closeModal('fundsFormModal');
    toast('Riwayat diperbarui');
    App.render('target-detail', targetId);
  }, { once: true });
  openModal('fundsFormModal');
}

async function deleteTargetHistoryFlow(targetId, entryId) {
  const ok = await confirmDialog('Hapus riwayat ini? Saldo akun dan dana target akan disesuaikan kembali.');
  if (!ok) return;
  DB.deleteTargetHistoryEntry(targetId, entryId);
  toast('Riwayat dihapus');
  App.render('target-detail', targetId);
}

/* ---------------- Tambah Dana ke Target ---------------- */

function openAddFundsForm(targetId) {
  const s = DB.state();
  if (!s.accounts.length) { toast('Tambahkan akun terlebih dahulu', 'warn'); location.hash = '#/accounts'; return; }
  document.getElementById('fundsFormTitle').textContent = 'Tambah Dana ke Target';
  document.getElementById('fundsFormBody').innerHTML = `
    <form id="fundsForm">
      <label class="field-label">Nominal</label>
      <input inputmode="numeric" id="fundsAmount" class="field-input field-amount" placeholder="Rp0" required />
      <label class="field-label">Sumber Dana</label>
      <select id="fundsAccount" class="field-input">
        ${s.accounts.map(a => `<option value="${a.id}">${escapeHtml(a.name)} (${formatRupiah(a.balance)})</option>`).join('')}
      </select>
      <label class="field-label">Tanggal</label>
      <input type="date" id="fundsDate" class="field-input" value="${todayISO()}" required />
      <label class="field-label">Catatan (opsional)</label>
      <input id="fundsNote" class="field-input" placeholder="Catatan..." />
      <button type="submit" class="btn btn-primary btn-block">Tambah Dana</button>
    </form>
  `;
  bindRupiahInput(document.getElementById('fundsAmount'));
  document.getElementById('fundsForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const amount = parseRupiahInput(document.getElementById('fundsAmount').value);
    if (!amount || amount <= 0) { toast('Nominal harus lebih dari 0', 'warn'); return; }
    const accountId = document.getElementById('fundsAccount').value;
    const date = document.getElementById('fundsDate').value;
    const note = document.getElementById('fundsNote').value.trim();
    DB.addFundsToTarget(targetId, { amount, accountId, date, note });
    closeModal('fundsFormModal');
    toast('Dana berhasil ditambahkan ke target');
    App.render('target-detail', targetId);
  }, { once: true });
  openModal('fundsFormModal');
}

function openMoveStorageForm(targetId) {
  const t = DB.getTarget(targetId);
  document.getElementById('fundsFormTitle').textContent = 'Pindah Tempat Penyimpanan';
  document.getElementById('fundsFormBody').innerHTML = `<div id="storagePickerWrap"></div>
    <button type="button" id="saveStorageBtn" class="btn btn-primary btn-block">Simpan</button>`;
  renderStoragePicker(document.getElementById('storagePickerWrap'), { storageType: t.storageType, storageDetail: t.storageDetail });
  document.getElementById('saveStorageBtn').addEventListener('click', () => {
    const val = readStoragePicker();
    if (!val) { toast('Pilih tempat penyimpanan', 'warn'); return; }
    DB.moveTargetStorage(targetId, val);
    closeModal('fundsFormModal');
    toast('Tempat penyimpanan diperbarui');
    App.render('target-detail', targetId);
  });
  openModal('fundsFormModal');
}
