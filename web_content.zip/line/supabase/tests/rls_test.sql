-- Security checks for LINE. Run in Supabase SQL Editor AFTER 001_init.sql.
-- Everything happens inside a transaction that is rolled back, so no test data is kept.
-- If any check fails you get an error naming it; if all pass you see "All security checks passed".
begin;

insert into auth.users (id, instance_id, aud, role, email) values
  ('00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', 'rls-a@test.local'),
  ('00000000-0000-0000-0000-0000000000b2', '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', 'rls-b@test.local'),
  ('00000000-0000-0000-0000-0000000000c3', '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', 'rls-c@test.local');

do $$
declare
  a constant uuid := '00000000-0000-0000-0000-0000000000a1';
  b constant uuid := '00000000-0000-0000-0000-0000000000b2';
  c constant uuid := '00000000-0000-0000-0000-0000000000c3';
  cid uuid;
  n int;
  unread bigint;
begin
  -- As user A: create a conversation with B, twice (must be the same one), then send a message.
  perform set_config('request.jwt.claims', json_build_object('sub', a, 'role', 'authenticated')::text, true);
  set local role authenticated;
  cid := public.start_direct_conversation(b);
  assert cid = public.start_direct_conversation(b), 'FAIL: duplicate direct conversation created';
  insert into public.messages (conversation_id, body, sender_id) values (cid, 'hello', a);

  begin
    perform public.start_direct_conversation(a);
    raise exception 'FAIL: conversation with yourself was allowed';
  exception when raise_exception then
    if sqlerrm like 'FAIL%' then raise; end if;
  end;

  begin
    insert into public.messages (conversation_id, body, sender_id) values (cid, 'spoof', b);
    raise exception 'FAIL: sending as another user was allowed';
  exception when sqlstate '42501' then null;
  end;

  begin
    update public.messages set body = 'edited' where conversation_id = cid;
    raise exception 'FAIL: message edit was allowed';
  exception when sqlstate '42501' then null;
  end;

  begin
    delete from public.messages where conversation_id = cid;
    raise exception 'FAIL: message delete was allowed';
  exception when sqlstate '42501' then null;
  end;

  begin
    insert into public.conversation_members (conversation_id, user_id) values (cid, c);
    raise exception 'FAIL: direct membership insert was allowed';
  exception when sqlstate '42501' then null;
  end;

  -- As user B: sees the message, has 1 unread, then 0 after marking read.
  reset role;
  perform set_config('request.jwt.claims', json_build_object('sub', b, 'role', 'authenticated')::text, true);
  set local role authenticated;
  select count(*) into n from public.messages where conversation_id = cid;
  assert n = 1, 'FAIL: member cannot read messages';
  select unread_count into unread from public.list_conversations() where conversation_id = cid;
  assert unread = 1, 'FAIL: unread count should be 1';
  perform public.mark_conversation_read(cid);
  select unread_count into unread from public.list_conversations() where conversation_id = cid;
  assert unread = 0, 'FAIL: unread count should be 0 after read';

  -- As outsider C: sees nothing and cannot write into the conversation.
  reset role;
  perform set_config('request.jwt.claims', json_build_object('sub', c, 'role', 'authenticated')::text, true);
  set local role authenticated;
  select count(*) into n from public.messages;
  assert n = 0, 'FAIL: outsider can read messages';
  select count(*) into n from public.conversations;
  assert n = 0, 'FAIL: outsider can see conversations';
  select count(*) into n from public.conversation_members;
  assert n = 0, 'FAIL: outsider can see memberships';
  begin
    insert into public.messages (conversation_id, body, sender_id) values (cid, 'intruder', c);
    raise exception 'FAIL: outsider could post into a private conversation';
  exception when sqlstate '42501' then null;
  end;

  -- Signed-out (anon) users get nothing.
  reset role;
  set local role anon;
  begin
    perform count(*) from public.profiles;
    raise exception 'FAIL: anon can read profiles';
  exception when sqlstate '42501' then null;
  end;

  reset role;
  raise notice 'All security checks passed';
end;
$$;

rollback;
