import type { ReactNode } from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { isConfigured } from './lib/supabase';
import AuthPage from './pages/AuthPage';
import MessengerPage from './pages/MessengerPage';
import ResetPasswordPage from './pages/ResetPasswordPage';

function FullScreenLoader() {
  return (
    <div className="center-screen">
      <div className="state">
        <Loader2 className="spin" size={20} /> Loading…
      </div>
    </div>
  );
}

function Protected({ children }: { children: ReactNode }) {
  const { session, profile, loading, refreshProfile, signOut } = useAuth();
  if (loading) return <FullScreenLoader />;
  if (!session) return <Navigate to="/auth" replace />;
  if (!profile)
    return (
      <div className="center-screen">
        <div className="auth-card">
          <h2>We couldn’t load your profile</h2>
          <p className="muted">This is usually a temporary connection problem, or the database setup has not been run yet.</p>
          <div className="btn-row">
            <button type="button" className="btn btn-primary" onClick={() => void refreshProfile()}>
              Try again
            </button>
            <button type="button" className="btn" onClick={() => void signOut()}>
              Sign out
            </button>
          </div>
        </div>
      </div>
    );
  return <>{children}</>;
}

function PublicOnly({ children }: { children: ReactNode }) {
  const { session, loading } = useAuth();
  if (loading) return <FullScreenLoader />;
  if (session) return <Navigate to="/" replace />;
  return <>{children}</>;
}

function SetupRequired() {
  return (
    <div className="center-screen">
      <div className="auth-card">
        <h1 className="wordmark big">LINE</h1>
        <h2>Supabase isn’t configured yet</h2>
        <p>
          LINE needs a Supabase project for accounts, messages and real-time updates. Until it is connected, sign-in and
          messaging are turned off.
        </p>
        <ol className="steps">
          <li>Create a Supabase project and run <code>supabase/migrations/001_init.sql</code>.</li>
          <li>Copy <code>.env.example</code> to <code>.env.local</code> and fill in your project URL and anon key.</li>
          <li>Restart <code>npm run dev</code> (or set the same variables on your hosting provider and redeploy).</li>
        </ol>
        <p className="muted small">The README has the exact steps.</p>
      </div>
    </div>
  );
}

export default function App() {
  if (!isConfigured) return <SetupRequired />;
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/auth" element={<PublicOnly><AuthPage /></PublicOnly>} />
          <Route path="/reset-password" element={<ResetPasswordPage />} />
          <Route path="/" element={<Protected><MessengerPage /></Protected>} />
          <Route path="/c/:conversationId" element={<Protected><MessengerPage /></Protected>} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}
