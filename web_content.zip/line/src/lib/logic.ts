import type { Message, MessageState } from './types';

export const MAX_MESSAGE_LENGTH = 4000;

export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '?';
  const first = Array.from(parts[0])[0];
  if (parts.length === 1) return first.toUpperCase();
  const last = Array.from(parts[parts.length - 1])[0];
  return (first + last).toUpperCase();
}

/** Escape characters that have a special meaning inside SQL LIKE / ILIKE patterns. */
export function escapeLike(q: string): string {
  return q.replace(/[\\%_]/g, (c) => '\\' + c);
}

export function newId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  const b = new Uint8Array(16);
  crypto.getRandomValues(b);
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  const h = Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

export function validateBody(body: string): boolean {
  const t = body.trim();
  return t.length >= 1 && t.length <= MAX_MESSAGE_LENGTH;
}

const isPending = (m: Message) => m.status === 'sending' || m.status === 'failed';
const byTime = (a: Message, b: Message) => {
  const d = Date.parse(a.created_at) - Date.parse(b.created_at);
  return d !== 0 ? d : a.id.localeCompare(b.id);
};

/**
 * Merge messages by client_id. A browser-only copy (sending/failed) never overwrites a copy the
 * database has confirmed; a confirmed copy always replaces a browser-only one. Confirmed messages
 * are sorted by server time, pending ones stay at the end.
 */
export function mergeMessages(existing: Message[], incoming: Message[]): Message[] {
  const map = new Map<string, Message>();
  for (const m of existing) map.set(m.client_id, m);
  for (const m of incoming) {
    const prev = map.get(m.client_id);
    if (prev && !isPending(prev) && isPending(m)) continue;
    map.set(m.client_id, m);
  }
  const all = Array.from(map.values());
  return [...all.filter((m) => !isPending(m)).sort(byTime), ...all.filter(isPending).sort(byTime)];
}

/** State of a message from the viewer's perspective; null for messages sent by the other person. */
export function messageState(msg: Message, myId: string, otherLastReadAt: string | null): MessageState | null {
  if (msg.sender_id !== myId) return null;
  if (msg.status) return msg.status;
  if (otherLastReadAt && Date.parse(otherLastReadAt) >= Date.parse(msg.created_at)) return 'read';
  return 'sent';
}

const startOfDay = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();

export function dayKey(iso: string): string {
  const d = new Date(iso);
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

export function formatDayLabel(iso: string, now: Date = new Date()): string {
  const d = new Date(iso);
  const diffDays = Math.round((startOfDay(now) - startOfDay(d)) / 86_400_000);
  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Yesterday';
  return d.toLocaleDateString(undefined, {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: d.getFullYear() === now.getFullYear() ? undefined : 'numeric',
  });
}

export function formatTime(iso: string): string {
  return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

export function formatListTime(iso: string, now: Date = new Date()): string {
  const d = new Date(iso);
  const diffDays = Math.round((startOfDay(now) - startOfDay(d)) / 86_400_000);
  if (diffDays === 0) return formatTime(iso);
  if (diffDays === 1) return 'Yesterday';
  return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
}

export function friendlyAuthError(message: string): string {
  const m = message.toLowerCase();
  if (m.includes('invalid login credentials')) return 'Incorrect email or password.';
  if (m.includes('email not confirmed')) return 'Please confirm your email first. Check your inbox for the confirmation link.';
  if (m.includes('already registered') || m.includes('already been registered'))
    return 'An account with this email already exists. Try signing in.';
  if (m.includes('rate limit') || m.includes('too many'))
    return 'Too many attempts. Please wait a few minutes and try again.';
  if (m.includes('password should be') || m.includes('weak password'))
    return 'That password is too weak. Use at least 8 characters.';
  if (m.includes('valid email') || m.includes('invalid email')) return 'Enter a valid email address.';
  if (m.includes('failed to fetch') || m.includes('networkerror') || m.includes('network request failed'))
    return 'Network error. Check your connection and try again.';
  if (m.includes('same password') || m.includes('different from the old'))
    return 'Choose a password that is different from your current one.';
  return message || 'Something went wrong. Please try again.';
}
