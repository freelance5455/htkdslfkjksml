import { describe, expect, it } from 'vitest';
import {
  dayKey,
  escapeLike,
  formatDayLabel,
  friendlyAuthError,
  initials,
  mergeMessages,
  messageState,
  newId,
  validateBody,
} from './logic';
import type { Message } from './types';

const msg = (over: Partial<Message> & { client_id: string }): Message => ({
  id: over.client_id,
  conversation_id: 'c1',
  sender_id: 'me',
  body: 'hi',
  created_at: '2026-01-01T10:00:00.000Z',
  ...over,
});

describe('initials', () => {
  it('handles one, two, many words and empty input', () => {
    expect(initials('ada')).toBe('A');
    expect(initials('Ada Lovelace')).toBe('AL');
    expect(initials('  grace  brewster  hopper ')).toBe('GH');
    expect(initials('   ')).toBe('?');
  });
});

describe('escapeLike', () => {
  it('escapes wildcard characters so users cannot widen a search', () => {
    expect(escapeLike('100%_a\\b')).toBe('100\\%\\_a\\\\b');
  });
});

describe('validateBody', () => {
  it('rejects empty/whitespace and over-long messages', () => {
    expect(validateBody('   \n ')).toBe(false);
    expect(validateBody('hello')).toBe(true);
    expect(validateBody('a'.repeat(4000))).toBe(true);
    expect(validateBody('a'.repeat(4001))).toBe(false);
  });
});

describe('newId', () => {
  it('returns unique UUID-shaped strings', () => {
    const a = newId();
    expect(a).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
    expect(newId()).not.toBe(a);
  });
});

describe('mergeMessages', () => {
  it('replaces an optimistic message with the confirmed one (no duplicates)', () => {
    const optimistic = msg({ client_id: 'k1', status: 'sending' });
    const confirmed = msg({ client_id: 'k1', id: 'server-1' });
    const out = mergeMessages([optimistic], [confirmed]);
    expect(out).toHaveLength(1);
    expect(out[0].id).toBe('server-1');
    expect(out[0].status).toBeUndefined();
  });

  it('never lets a pending copy overwrite a confirmed copy', () => {
    const confirmed = msg({ client_id: 'k1', id: 'server-1' });
    const out = mergeMessages([confirmed], [msg({ client_id: 'k1', status: 'failed' })]);
    expect(out[0].id).toBe('server-1');
    expect(out[0].status).toBeUndefined();
  });

  it('sorts confirmed by time and keeps pending messages last', () => {
    const a = msg({ client_id: 'a', created_at: '2026-01-01T10:00:00.000Z' });
    const b = msg({ client_id: 'b', created_at: '2026-01-01T09:00:00.000Z' });
    const p = msg({ client_id: 'p', created_at: '2026-01-01T08:00:00.000Z', status: 'sending' });
    expect(mergeMessages([a, p], [b]).map((m) => m.client_id)).toEqual(['b', 'a', 'p']);
  });

  it('lets a retry replace a failed copy', () => {
    const out = mergeMessages([msg({ client_id: 'k', status: 'failed' })], [msg({ client_id: 'k', status: 'sending' })]);
    expect(out[0].status).toBe('sending');
  });
});

describe('messageState', () => {
  const sent = msg({ client_id: 'k', created_at: '2026-01-01T10:00:00.000Z' });
  it('is null for incoming messages', () => {
    expect(messageState({ ...sent, sender_id: 'other' }, 'me', null)).toBeNull();
  });
  it('is sent until the other person has read it', () => {
    expect(messageState(sent, 'me', null)).toBe('sent');
    expect(messageState(sent, 'me', '2026-01-01T09:59:59.000Z')).toBe('sent');
  });
  it('is read once the other persons read marker passes the message', () => {
    expect(messageState(sent, 'me', '2026-01-01T10:00:00.000Z')).toBe('read');
  });
  it('passes through sending and failed', () => {
    expect(messageState({ ...sent, status: 'failed' }, 'me', '2030-01-01T00:00:00Z')).toBe('failed');
    expect(messageState({ ...sent, status: 'sending' }, 'me', null)).toBe('sending');
  });
});

describe('dates', () => {
  it('labels today, yesterday and older days', () => {
    const now = new Date(2026, 5, 15, 12, 0, 0);
    expect(formatDayLabel(new Date(2026, 5, 15, 8).toISOString(), now)).toBe('Today');
    expect(formatDayLabel(new Date(2026, 5, 14, 23).toISOString(), now)).toBe('Yesterday');
    expect(formatDayLabel(new Date(2026, 5, 1, 9).toISOString(), now)).not.toMatch(/Today|Yesterday/);
  });
  it('gives the same key for the same local day', () => {
    expect(dayKey(new Date(2026, 5, 15, 1).toISOString())).toBe(dayKey(new Date(2026, 5, 15, 23).toISOString()));
  });
});

describe('friendlyAuthError', () => {
  it('translates common Supabase messages', () => {
    expect(friendlyAuthError('Invalid login credentials')).toBe('Incorrect email or password.');
    expect(friendlyAuthError('Email not confirmed')).toMatch(/confirm your email/);
    expect(friendlyAuthError('User already registered')).toMatch(/already exists/);
    expect(friendlyAuthError('TypeError: Failed to fetch')).toMatch(/Network error/);
    expect(friendlyAuthError('Something unexpected')).toBe('Something unexpected');
  });
});
