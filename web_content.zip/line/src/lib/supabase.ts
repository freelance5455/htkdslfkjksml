import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

/** False until real values are provided in .env.local (or the hosting provider's environment settings). */
export const isConfigured = Boolean(
  url && anonKey && url.startsWith('https://') && !url.includes('your-project'),
);

export const supabase = createClient(url ?? 'https://not-configured.invalid', anonKey ?? 'not-configured', {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
});
