export interface Profile {
  id: string;
  display_name: string;
}

/** `status` is only set on messages that exist only in this browser (not yet confirmed by the database). */
export interface Message {
  id: string;
  client_id: string;
  conversation_id: string;
  sender_id: string;
  body: string;
  created_at: string;
  status?: 'sending' | 'failed';
}

export interface ConversationSummary {
  conversation_id: string;
  other_user_id: string;
  other_display_name: string;
  last_message_body: string | null;
  last_message_sender: string | null;
  last_message_at: string;
  unread_count: number;
}

/**
 * sending: only in this browser, request in flight.
 * failed:  the request failed; nothing was confirmed. Can be retried.
 * sent:    the database confirmed it stored the message.
 * read:    the other person opened the conversation after the message was stored.
 * (There is deliberately no "delivered" state: the system cannot know that.)
 */
export type MessageState = 'sending' | 'failed' | 'sent' | 'read';
