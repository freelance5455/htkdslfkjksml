import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { MessageSquare, Settings, WifiOff } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useConversations } from '../hooks/useConversations';
import { supabase } from '../lib/supabase';
import type { Profile } from '../lib/types';
import Avatar from '../components/Avatar';
import ChatView from '../components/ChatView';
import ConversationList from '../components/ConversationList';
import ProfileSettings from '../components/ProfileSettings';

/** Keeps the layout exactly as tall as the visible area, so the composer stays above the mobile keyboard. */
function useViewportHeight() {
  useEffect(() => {
    const vv = window.visualViewport;
    const set = () => {
      document.documentElement.style.setProperty('--app-height', `${vv ? vv.height : window.innerHeight}px`);
      window.scrollTo(0, 0);
    };
    set();
    vv?.addEventListener('resize', set);
    vv?.addEventListener('scroll', set);
    window.addEventListener('resize', set);
    return () => {
      vv?.removeEventListener('resize', set);
      vv?.removeEventListener('scroll', set);
      window.removeEventListener('resize', set);
      document.documentElement.style.removeProperty('--app-height');
    };
  }, []);
}

function useOnline() {
  const [online, setOnline] = useState(navigator.onLine);
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => {
      window.removeEventListener('online', on);
      window.removeEventListener('offline', off);
    };
  }, []);
  return online;
}

export default function MessengerPage() {
  const { profile } = useAuth();
  if (!profile) return null;
  return <Messenger profile={profile} />;
}

function Messenger({ profile }: { profile: Profile }) {
  const { conversationId } = useParams();
  const navigate = useNavigate();
  const [settingsOpen, setSettingsOpen] = useState(false);
  const { items, loading, error, refresh } = useConversations(profile.id);
  const online = useOnline();
  useViewportHeight();

  const active = items.find((c) => c.conversation_id === conversationId) ?? null;

  const startWith = async (userId: string): Promise<string | null> => {
    const { data, error: err } = await supabase.rpc('start_direct_conversation', { other_user: userId });
    if (err || !data) return 'Could not start the conversation. Please try again.';
    await refresh();
    navigate(`/c/${data as string}`);
    return null;
  };

  return (
    <div className={`app ${conversationId ? 'has-chat' : ''}`}>
      <aside className="sidebar">
        <div className="sidebar-head">
          <h1 className="wordmark">LINE</h1>
          <button type="button" className="icon-btn profile-btn" onClick={() => setSettingsOpen(true)} aria-label="Profile and settings">
            <Avatar name={profile.display_name} size={32} />
            <Settings size={16} aria-hidden="true" />
          </button>
        </div>
        {!online && (
          <div className="banner" role="status">
            <WifiOff size={14} /> You’re offline. Messages can’t be sent until you reconnect.
          </div>
        )}
        <ConversationList
          myId={profile.id}
          items={items}
          loading={loading}
          error={error}
          onRetry={() => void refresh()}
          activeId={conversationId}
          onOpen={(id) => navigate(`/c/${id}`)}
          onStartWith={startWith}
        />
      </aside>

      <main className="main">
        {conversationId ? (
          <ChatView
            key={conversationId}
            conversationId={conversationId}
            conversation={active}
            listLoading={loading}
            myId={profile.id}
            onBack={() => navigate('/')}
            onRead={() => void refresh()}
          />
        ) : (
          <div className="empty-main">
            <MessageSquare size={36} aria-hidden="true" />
            <h2>Welcome to LINE, {profile.display_name}</h2>
            <p>Pick a conversation on the left, or search for someone by name to start a new one.</p>
          </div>
        )}
      </main>

      {settingsOpen && <ProfileSettings onClose={() => setSettingsOpen(false)} />}
    </div>
  );
}
