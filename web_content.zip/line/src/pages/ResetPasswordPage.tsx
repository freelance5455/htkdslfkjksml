import { useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { friendlyAuthError } from '../lib/logic';

export default function ResetPasswordPage() {
  const { session, loading } = useAuth();
  const navigate = useNavigate();
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (busy) return;
    setError(null);
    if (password.length < 8) return setError('Use a password of at least 8 characters.');
    if (password !== confirm) return setError('The two passwords do not match.');
    setBusy(true);
    try {
      const { error: err } = await supabase.auth.updateUser({ password });
      if (err) setError(friendlyAuthError(err.message));
      else {
        setDone(true);
        setTimeout(() => navigate('/', { replace: true }), 1500);
      }
    } catch {
      setError('Network error. Check your connection and try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="center-screen">
      <div className="auth-card">
        <h1 className="wordmark big">LINE</h1>
        <h2>Choose a new password</h2>
        {loading ? (
          <div className="state">
            <Loader2 className="spin" size={18} /> Checking your reset link…
          </div>
        ) : !session ? (
          <>
            <div className="form-error" role="alert">
              This reset link is invalid or has expired. Request a new one from the sign-in page.
            </div>
            <Link className="btn" to="/auth">
              Back to sign in
            </Link>
          </>
        ) : done ? (
          <div className="form-notice" role="status">
            Password updated. Taking you to LINE…
          </div>
        ) : (
          <form className="form" onSubmit={onSubmit}>
            <label className="field">
              <span>New password</span>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" required />
            </label>
            <label className="field">
              <span>Confirm new password</span>
              <input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" required />
            </label>
            {error && (
              <div className="form-error" role="alert">
                {error}
              </div>
            )}
            <button type="submit" className="btn btn-primary" disabled={busy}>
              {busy ? 'Saving…' : 'Update password'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
