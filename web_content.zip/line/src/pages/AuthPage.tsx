import { useState, type FormEvent } from 'react';
import { Loader2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { friendlyAuthError } from '../lib/logic';

type Mode = 'signin' | 'signup' | 'forgot';

export default function AuthPage() {
  const [mode, setMode] = useState<Mode>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const switchMode = (m: Mode) => {
    setMode(m);
    setError(null);
    setNotice(null);
  };

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (busy) return;
    setError(null);
    setNotice(null);
    const em = email.trim();

    if (mode === 'signup') {
      if (name.trim().length < 1 || name.trim().length > 50) return setError('Display name must be 1–50 characters.');
      if (password.length < 8) return setError('Use a password of at least 8 characters.');
    }

    setBusy(true);
    try {
      if (mode === 'signin') {
        const { error: err } = await supabase.auth.signInWithPassword({ email: em, password });
        if (err) setError(friendlyAuthError(err.message));
        // On success the auth listener updates the session and the router moves on.
      } else if (mode === 'signup') {
        const { data, error: err } = await supabase.auth.signUp({
          email: em,
          password,
          options: { data: { display_name: name.trim() }, emailRedirectTo: window.location.origin },
        });
        if (err) setError(friendlyAuthError(err.message));
        else if (data.user && data.user.identities && data.user.identities.length === 0)
          setError('An account with this email already exists. Try signing in.');
        else if (!data.session)
          setNotice('Account created. We sent a confirmation link to your email. Open it, then come back here and sign in.');
      } else {
        const { error: err } = await supabase.auth.resetPasswordForEmail(em, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (err) setError(friendlyAuthError(err.message));
        else setNotice('If an account exists for that email, a password reset link is on its way.');
      }
    } catch {
      setError('Network error. Check your connection and try again.');
    } finally {
      setBusy(false);
    }
  }

  const title = mode === 'signin' ? 'Sign in' : mode === 'signup' ? 'Create your account' : 'Reset your password';
  const action = mode === 'signin' ? 'Sign in' : mode === 'signup' ? 'Create account' : 'Send reset link';

  return (
    <div className="center-screen">
      <div className="auth-card">
        <h1 className="wordmark big">LINE</h1>
        <h2>{title}</h2>

        {mode !== 'forgot' && (
          <div className="tabs" role="tablist">
            <button type="button" role="tab" aria-selected={mode === 'signin'} className={mode === 'signin' ? 'on' : ''} onClick={() => switchMode('signin')}>
              Sign in
            </button>
            <button type="button" role="tab" aria-selected={mode === 'signup'} className={mode === 'signup' ? 'on' : ''} onClick={() => switchMode('signup')}>
              Sign up
            </button>
          </div>
        )}

        <form className="form" onSubmit={onSubmit} noValidate={false}>
          {mode === 'signup' && (
            <label className="field">
              <span>Display name</span>
              <input value={name} onChange={(e) => setName(e.target.value)} maxLength={50} autoComplete="nickname" required />
            </label>
          )}
          <label className="field">
            <span>Email</span>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" required />
          </label>
          {mode !== 'forgot' && (
            <label className="field">
              <span>Password</span>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
                minLength={mode === 'signup' ? 8 : undefined}
                required
              />
            </label>
          )}

          {error && (
            <div className="form-error" role="alert">
              {error}
            </div>
          )}
          {notice && (
            <div className="form-notice" role="status">
              {notice}
            </div>
          )}

          <button type="submit" className="btn btn-primary" disabled={busy}>
            {busy && <Loader2 size={14} className="spin" />} {busy ? 'Please wait…' : action}
          </button>
        </form>

        <div className="auth-links">
          {mode === 'signin' && (
            <button type="button" className="link-btn" onClick={() => switchMode('forgot')}>
              Forgot your password?
            </button>
          )}
          {mode === 'forgot' && (
            <button type="button" className="link-btn" onClick={() => switchMode('signin')}>
              Back to sign in
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
