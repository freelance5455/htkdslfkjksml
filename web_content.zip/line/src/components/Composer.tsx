import { useLayoutEffect, useRef, useState, type KeyboardEvent } from 'react';
import { ArrowUp } from 'lucide-react';
import { MAX_MESSAGE_LENGTH } from '../lib/logic';

export default function Composer({ onSend }: { onSend: (text: string) => void }) {
  const [value, setValue] = useState('');
  const ref = useRef<HTMLTextAreaElement>(null);

  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 140)}px`;
  }, [value]);

  const canSend = value.trim().length > 0;

  const submit = () => {
    const text = value.trim();
    if (!text) return;
    setValue(''); // cleared immediately, so a second Enter cannot send the same text twice
    onSend(text);
    ref.current?.focus();
  };

  const onKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault();
      submit();
    }
  };

  return (
    <div className="composer">
      <textarea
        ref={ref}
        className="composer-input"
        rows={1}
        value={value}
        maxLength={MAX_MESSAGE_LENGTH}
        placeholder="Write a message"
        aria-label="Message"
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={onKeyDown}
      />
      <button
        type="button"
        className="send-btn"
        onMouseDown={(e) => e.preventDefault()} /* keeps the mobile keyboard open */
        onClick={submit}
        disabled={!canSend}
        aria-label="Send message"
        title={canSend ? 'Send (Enter)' : 'Type a message to send'}
      >
        <ArrowUp size={18} />
      </button>
    </div>
  );
}
