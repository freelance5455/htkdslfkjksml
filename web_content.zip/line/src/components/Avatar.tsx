import { initials } from '../lib/logic';

export default function Avatar({ name, size = 40 }: { name: string; size?: number }) {
  return (
    <div className="avatar" style={{ width: size, height: size, fontSize: Math.round(size * 0.38) }} aria-hidden="true">
      {initials(name)}
    </div>
  );
}
