import { Fragment, useLayoutEffect, useMemo, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Loader2 } from 'lucide-react';
import { useMessages } from '../hooks/useMessages';
import { dayKey, formatDayLabel, messageState } from '../lib/logic';
import type { ConversationSummary } from '../lib/types';
import Avatar from './Avatar';
import Composer from './Composer';
import MessageBubble from './MessageBubble';

interface Props {
  conversationId: string;
  conversation: ConversationSummary | null;
  listLoading: boolean;
  myId: string;
  onBack: () => void;
  onRead: () => void;
}

export default function ChatView({ conversationId, conversation, listLoading, myId, onBack, onRead }: Props) {
  const m = useMessages(conversationId, myId, conversation?.other_user_id ?? null, onRead);

  const listRef = useRef<HTMLDivElement>(null);
  const stick = useRef(true); // true while the reader is at (or near) the bottom
  const prevFirst = useRef<string | null>(null);
  const lastHeight = useRef(0);

  const onScroll = () => {
    const el = listRef.current;
    if (el) stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
  };

  // Auto-scroll to the newest message; keep the reading position when older pages are prepended.
  useLayoutEffect(() => {
    const el = listRef.current;
    if (!el) return;
    const firstKey = m.messages[0]?.client_id ?? null;
    const prepended = prevFirst.current !== null && firstKey !== prevFirst.current;
    if (prepended) el.scrollTop += el.scrollHeight - lastHeight.current;
    else if (stick.current) el.scrollTop = el.scrollHeight;
    prevFirst.current = firstKey;
    lastHeight.current = el.scrollHeight;
  }, [m.messages, m.loading, m.hasMore, m.loadingOlder]);

  const items = useMemo(() => {
    const out: Array<{ type: 'day'; key: string; label: string } | { type: 'msg'; msg: (typeof m.messages)[number] }> = [];
    let last = '';
    for (const msg of m.messages) {
      const k = dayKey(msg.created_at);
      if (k !== last) {
        out.push({ type: 'day', key: `${k}-${msg.client_id}`, label: formatDayLabel(msg.created_at) });
        last = k;
      }
      out.push({ type: 'msg', msg });
    }
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [m.messages]);

  if (!conversation && listLoading) {
    return (
      <div className="state">
        <Loader2 className="spin" size={18} /> Loading conversation…
      </div>
    );
  }
  if (!conversation) {
    return (
      <div className="state">
        <p>This conversation doesn’t exist or you don’t have access to it.</p>
        <Link className="btn" to="/">
          Back to conversations
        </Link>
      </div>
    );
  }

  const handleSend = (text: string) => {
    stick.current = true;
    void m.send(text);
  };

  return (
    <>
      <header className="chat-head">
        <button type="button" className="icon-btn back-btn" onClick={onBack} aria-label="Back to conversations">
          <ArrowLeft size={20} />
        </button>
        <Avatar name={conversation.other_display_name} size={36} />
        <div className="chat-title">{conversation.other_display_name}</div>
      </header>

      {m.error && (
        <div className="banner" role="alert">
          <span>{m.error}</span>
          <button type="button" className="link-btn" onClick={m.reload}>
            Try again
          </button>
        </div>
      )}

      <div className="msgs" ref={listRef} onScroll={onScroll}>
        {m.loading ? (
          <div className="state">
            <Loader2 className="spin" size={18} /> Loading messages…
          </div>
        ) : (
          <>
            {m.hasMore && (
              <div className="load-older">
                <button type="button" className="btn" onClick={() => void m.loadOlder()} disabled={m.loadingOlder}>
                  {m.loadingOlder ? 'Loading…' : 'Load earlier messages'}
                </button>
              </div>
            )}
            {m.messages.length === 0 && !m.error && (
              <div className="state">
                <p>No messages yet. Say hello to {conversation.other_display_name}.</p>
              </div>
            )}
            {items.map((it) =>
              it.type === 'day' ? (
                <div className="day-sep" key={it.key}>
                  <span>{it.label}</span>
                </div>
              ) : (
                <Fragment key={it.msg.client_id}>
                  <MessageBubble
                    message={it.msg}
                    state={messageState(it.msg, myId, m.otherLastRead)}
                    onRetry={m.retry}
                    onDiscard={m.discard}
                  />
                </Fragment>
              ),
            )}
          </>
        )}
      </div>

      <Composer onSend={handleSend} />
    </>
  );
}
