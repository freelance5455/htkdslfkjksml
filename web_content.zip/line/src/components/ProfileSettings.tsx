import { useEffect, useState, type FormEvent } from 'react';
import { X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import Avatar from './Avatar';

export default function ProfileSettings({ onClose }: { onClose: () => void }) {
  const { profile, user, refreshProfile, signOut } = useAuth();
  const [name, setName] = useState(profile?.display_name ?? '');
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);
  const [confirming, setConfirming] = useState(false);
  const [signingOut, setSigningOut] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  if (!profile) return null;
  const trimmed = name.trim();
  const unchanged = trimmed === profile.display_name;

  async function save(e: FormEvent) {
    e.preventDefault();
    if (saving || !profile) return;
    if (trimmed.length < 1 || trimmed.length > 50) {
      setMsg({ kind: 'err', text: 'Display name must be 1–50 characters.' });
      return;
    }
    setSaving(true);
    setMsg(null);
    const { error } = await supabase.from('profiles').update({ display_name: trimmed }).eq('id', profile.id);
    if (error) setMsg({ kind: 'err', text: 'Could not save your profile. Please try again.' });
    else {
      await refreshProfile();
      setMsg({ kind: 'ok', text: 'Profile saved.' });
    }
    setSaving(false);
  }

  return (
    <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal" role="dialog" aria-modal="true" aria-label="Profile and settings">
        <div className="modal-head">
          <h2>Profile</h2>
          <button type="button" className="icon-btn" onClick={onClose} aria-label="Close">
            <X size={18} />
          </button>
        </div>

        <div className="profile-top">
          <Avatar name={profile.display_name} size={56} />
          <div>
            <div className="profile-name">{profile.display_name}</div>
            <div className="muted">{user?.email}</div>
          </div>
        </div>

        <form onSubmit={save} className="form">
          <label className="field">
            <span>Display name</span>
            <input value={name} onChange={(e) => setName(e.target.value)} maxLength={50} />
          </label>
          <p className="muted small">Other people find you by this name. Your email is never shown to them.</p>
          {msg && (
            <div className={msg.kind === 'ok' ? 'form-notice' : 'form-error'} role="status">
              {msg.text}
            </div>
          )}
          <button type="submit" className="btn btn-primary" disabled={saving || unchanged || trimmed.length === 0}>
            {saving ? 'Saving…' : 'Save changes'}
          </button>
        </form>

        <hr className="divider" />

        {!confirming ? (
          <button type="button" className="btn" onClick={() => setConfirming(true)}>
            Sign out
          </button>
        ) : (
          <div className="form">
            <p>Sign out of LINE on this device?</p>
            <div className="btn-row">
              <button
                type="button"
                className="btn btn-primary"
                disabled={signingOut}
                onClick={() => {
                  setSigningOut(true);
                  void signOut();
                }}
              >
                {signingOut ? 'Signing out…' : 'Sign out'}
              </button>
              <button type="button" className="btn" onClick={() => setConfirming(false)}>
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
