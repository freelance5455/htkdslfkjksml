import { Check, CheckCheck, Loader2, RotateCw } from 'lucide-react';
import { formatTime } from '../lib/logic';
import type { Message, MessageState } from '../lib/types';

interface Props {
  message: Message;
  state: MessageState | null; // null = incoming
  onRetry: (clientId: string) => void;
  onDiscard: (clientId: string) => void;
}

const LABEL: Record<MessageState, string> = {
  sending: 'Sending',
  failed: 'Not sent',
  sent: 'Sent',
  read: 'Read',
};

export default function MessageBubble({ message, state, onRetry, onDiscard }: Props) {
  const mine = state !== null;
  return (
    <div className={`bubble-row ${mine ? 'mine' : 'theirs'}`}>
      <div className={`bubble ${state === 'failed' ? 'failed' : ''}`}>
        <div className="bubble-text">{message.body}</div>
        <div className="bubble-meta">
          <span>{formatTime(message.created_at)}</span>
          {state && (
            <span className="status" title={LABEL[state]}>
              {state === 'sending' && <Loader2 size={12} className="spin" />}
              {state === 'sent' && <Check size={12} />}
              {state === 'read' && <CheckCheck size={12} />}
              {LABEL[state]}
            </span>
          )}
        </div>
        {state === 'failed' && (
          <div className="bubble-actions">
            <button type="button" className="link-btn" onClick={() => onRetry(message.client_id)}>
              <RotateCw size={12} /> Retry
            </button>
            <button type="button" className="link-btn" onClick={() => onDiscard(message.client_id)}>
              Delete
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
