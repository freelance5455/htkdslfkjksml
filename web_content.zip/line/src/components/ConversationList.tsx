import { useEffect, useMemo, useState } from 'react';
import { Loader2, MessageSquare, Search, X } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { escapeLike, formatListTime } from '../lib/logic';
import type { ConversationSummary, Profile } from '../lib/types';
import Avatar from './Avatar';

interface Props {
  myId: string;
  items: ConversationSummary[];
  loading: boolean;
  error: string | null;
  onRetry: () => void;
  activeId?: string;
  onOpen: (conversationId: string) => void;
  /** Returns an error message, or null on success. */
  onStartWith: (userId: string) => Promise<string | null>;
}

export default function ConversationList({ myId, items, loading, error, onRetry, activeId, onOpen, onStartWith }: Props) {
  const [query, setQuery] = useState('');
  const [people, setPeople] = useState<Profile[]>([]);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [startingId, setStartingId] = useState<string | null>(null);
  const [startError, setStartError] = useState<string | null>(null);

  const q = query.trim();

  useEffect(() => {
    if (q.length < 2) {
      setPeople([]);
      setSearchError(null);
      setSearching(false);
      return;
    }
    let active = true;
    setSearching(true);
    const t = setTimeout(async () => {
      const { data, error: err } = await supabase
        .from('profiles')
        .select('id, display_name')
        .ilike('display_name', `%${escapeLike(q)}%`)
        .neq('id', myId)
        .order('display_name')
        .limit(20);
      if (!active) return;
      if (err) setSearchError('Search failed. Check your connection and try again.');
      else {
        setPeople((data ?? []) as Profile[]);
        setSearchError(null);
      }
      setSearching(false);
    }, 300);
    return () => {
      active = false;
      clearTimeout(t);
    };
  }, [q, myId]);

  const filtered = useMemo(
    () => (q ? items.filter((c) => c.other_display_name.toLowerCase().includes(q.toLowerCase())) : items),
    [items, q],
  );

  const start = async (userId: string) => {
    if (startingId) return;
    setStartingId(userId);
    setStartError(null);
    const err = await onStartWith(userId);
    setStartingId(null);
    if (err) setStartError(err);
    else setQuery('');
  };

  const row = (c: ConversationSummary) => {
    const preview =
      c.last_message_body === null
        ? 'No messages yet'
        : `${c.last_message_sender === myId ? 'You: ' : ''}${c.last_message_body}`;
    return (
      <button
        type="button"
        key={c.conversation_id}
        className={`row ${activeId === c.conversation_id ? 'active' : ''}`}
        onClick={() => {
          setQuery('');
          onOpen(c.conversation_id);
        }}
      >
        <Avatar name={c.other_display_name} />
        <div className="row-body">
          <div className="row-top">
            <span className="row-name">{c.other_display_name}</span>
            <span className="row-time">{formatListTime(c.last_message_at)}</span>
          </div>
          <div className="row-bottom">
            <span className={`row-preview ${c.unread_count > 0 ? 'strong' : ''}`}>{preview}</span>
            {c.unread_count > 0 && (
              <span className="badge" aria-label={`${c.unread_count} unread`}>
                {c.unread_count > 99 ? '99+' : c.unread_count}
              </span>
            )}
          </div>
        </div>
      </button>
    );
  };

  return (
    <>
      <div className="search">
        <Search size={16} aria-hidden="true" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search people and conversations"
          aria-label="Search people and conversations"
        />
        {query && (
          <button type="button" className="icon-btn" onClick={() => setQuery('')} aria-label="Clear search">
            <X size={16} />
          </button>
        )}
      </div>

      <div className="list-scroll">
        {startError && (
          <div className="banner" role="alert">
            {startError}
          </div>
        )}

        {q === '' ? (
          loading ? (
            <div className="state">
              <Loader2 className="spin" size={18} /> Loading conversations…
            </div>
          ) : error ? (
            <div className="state">
              <p>{error}</p>
              <button type="button" className="btn" onClick={onRetry}>
                Try again
              </button>
            </div>
          ) : items.length === 0 ? (
            <div className="state">
              <MessageSquare size={28} aria-hidden="true" />
              <p>
                <strong>No conversations yet</strong>
              </p>
              <p>Search for someone by name above to start chatting.</p>
            </div>
          ) : (
            items.map(row)
          )
        ) : (
          <>
            {filtered.length > 0 && <div className="section-title">Conversations</div>}
            {filtered.map(row)}
            <div className="section-title">People</div>
            {q.length < 2 ? (
              <div className="hint">Type at least 2 letters to search for people.</div>
            ) : searching ? (
              <div className="state">
                <Loader2 className="spin" size={18} /> Searching…
              </div>
            ) : searchError ? (
              <div className="hint">{searchError}</div>
            ) : people.length === 0 ? (
              <div className="hint">No people found for “{q}”.</div>
            ) : (
              people.map((p) => (
                <button
                  type="button"
                  key={p.id}
                  className="row"
                  onClick={() => void start(p.id)}
                  disabled={startingId !== null}
                >
                  <Avatar name={p.display_name} />
                  <div className="row-body">
                    <div className="row-top">
                      <span className="row-name">{p.display_name}</span>
                    </div>
                    <div className="row-bottom">
                      <span className="row-preview">
                        {startingId === p.id ? 'Opening conversation…' : 'Start a conversation'}
                      </span>
                    </div>
                  </div>
                </button>
              ))
            )}
          </>
        )}
      </div>
    </>
  );
}
