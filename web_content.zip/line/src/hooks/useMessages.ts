import { useCallback, useEffect, useRef, useState } from 'react';
import type { RealtimeChannel } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import { mergeMessages, newId, validateBody } from '../lib/logic';
import type { Message } from '../lib/types';

const PAGE = 30;
const COLS = 'id, client_id, conversation_id, sender_id, body, created_at';

/**
 * Messages for one conversation: initial page, older pages, Realtime inserts, read markers,
 * optimistic sending with retry, and catch-up after reconnects.
 */
export function useMessages(conversationId: string, myId: string, otherId: string | null, onRead: () => void) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(false);
  const [loadingOlder, setLoadingOlder] = useState(false);
  const [otherLastRead, setOtherLastRead] = useState<string | null>(null);
  const [nonce, setNonce] = useState(0);

  const messagesRef = useRef<Message[]>([]);
  messagesRef.current = messages;
  const onReadRef = useRef(onRead);
  onReadRef.current = onRead;

  const markRead = useCallback(async () => {
    if (document.visibilityState !== 'visible') return;
    const { error: err } = await supabase.rpc('mark_conversation_read', { conv_id: conversationId });
    if (!err) onReadRef.current();
  }, [conversationId]);

  useEffect(() => {
    let cancelled = false;
    let channel: RealtimeChannel | null = null;
    setMessages([]);
    setLoading(true);
    setError(null);
    setHasMore(false);

    // Fetch anything newer than the newest confirmed message (used after subscribe/reconnect/wake).
    const catchUp = async () => {
      const confirmed = messagesRef.current.filter((m) => !m.status);
      const latest = confirmed[confirmed.length - 1];
      let q = supabase
        .from('messages')
        .select(COLS)
        .eq('conversation_id', conversationId)
        .order('created_at', { ascending: true })
        .limit(200);
      if (latest) q = q.gt('created_at', latest.created_at);
      const { data } = await q;
      if (cancelled || !data || data.length === 0) return;
      setMessages((prev) => mergeMessages(prev, data as Message[]));
      if (data.some((m) => m.sender_id !== myId)) void markRead();
    };

    (async () => {
      const { data, error: err } = await supabase
        .from('messages')
        .select(COLS)
        .eq('conversation_id', conversationId)
        .order('created_at', { ascending: false })
        .limit(PAGE);
      if (cancelled) return;
      if (err) {
        setError('Could not load messages.');
        setLoading(false);
        return;
      }
      const rows = (data ?? []) as Message[];
      setMessages((prev) => mergeMessages(prev, [...rows].reverse()));
      setHasMore(rows.length === PAGE);
      setLoading(false);
      void markRead();

      // Subscribe only after the first page is in, so no gap can open between the two.
      const ch = supabase
        .channel(`chat:${conversationId}`)
        .on(
          'postgres_changes',
          { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${conversationId}` },
          (payload) => {
            const row = payload.new as Message;
            setMessages((prev) => mergeMessages(prev, [row]));
            if (row.sender_id !== myId) void markRead();
          },
        )
        .on(
          'postgres_changes',
          {
            event: 'UPDATE',
            schema: 'public',
            table: 'conversation_members',
            filter: `conversation_id=eq.${conversationId}`,
          },
          (payload) => {
            const row = payload.new as { user_id: string; last_read_at: string };
            if (row.user_id !== myId) setOtherLastRead(row.last_read_at);
          },
        )
        .subscribe((status) => {
          if (status === 'SUBSCRIBED') void catchUp();
        });
      if (cancelled) void supabase.removeChannel(ch);
      else channel = ch;
    })();

    const onWake = () => {
      if (document.visibilityState === 'visible') {
        void markRead();
        void catchUp();
      }
    };
    document.addEventListener('visibilitychange', onWake);
    window.addEventListener('online', onWake);

    return () => {
      cancelled = true;
      document.removeEventListener('visibilitychange', onWake);
      window.removeEventListener('online', onWake);
      if (channel) void supabase.removeChannel(channel);
    };
  }, [conversationId, myId, markRead, nonce]);

  // The other person's read marker (drives the "Read" status on my messages).
  useEffect(() => {
    setOtherLastRead(null);
    if (!otherId) return;
    let active = true;
    supabase
      .from('conversation_members')
      .select('last_read_at')
      .eq('conversation_id', conversationId)
      .eq('user_id', otherId)
      .maybeSingle()
      .then(({ data }) => {
        if (active && data) setOtherLastRead(data.last_read_at as string);
      });
    return () => {
      active = false;
    };
  }, [conversationId, otherId]);

  const loadOlder = useCallback(async () => {
    if (loadingOlder || !hasMore) return;
    const oldest = messagesRef.current.find((m) => !m.status);
    if (!oldest) return;
    setLoadingOlder(true);
    const { data, error: err } = await supabase
      .from('messages')
      .select(COLS)
      .eq('conversation_id', conversationId)
      .lt('created_at', oldest.created_at)
      .order('created_at', { ascending: false })
      .limit(PAGE);
    if (err) {
      setError('Could not load older messages.');
    } else {
      const rows = (data ?? []) as Message[];
      setMessages((prev) => mergeMessages(prev, rows));
      setHasMore(rows.length === PAGE);
      setError(null);
    }
    setLoadingOlder(false);
  }, [conversationId, hasMore, loadingOlder]);

  /**
   * Optimistic send. The browser-generated client_id is stored with the row and is unique per sender,
   * so a retry after a lost response can never create a duplicate message.
   */
  const send = useCallback(
    async (body: string, existingClientId?: string) => {
      const text = body.trim();
      if (!validateBody(text)) return;
      const clientId = existingClientId ?? newId();
      const optimistic: Message = {
        id: clientId,
        client_id: clientId,
        conversation_id: conversationId,
        sender_id: myId,
        body: text,
        created_at: new Date().toISOString(),
        status: 'sending',
      };
      setMessages((prev) => mergeMessages(prev, [optimistic]));
      try {
        const { data, error: err } = await supabase
          .from('messages')
          .insert({ conversation_id: conversationId, body: text, client_id: clientId, sender_id: myId })
          .select(COLS)
          .single();
        if (!err && data) {
          setMessages((prev) => mergeMessages(prev, [data as Message]));
          return;
        }
        if (err?.code === '23505') {
          // Already stored (an earlier attempt succeeded but its response was lost): fetch the stored copy.
          const { data: existing } = await supabase
            .from('messages')
            .select(COLS)
            .eq('sender_id', myId)
            .eq('client_id', clientId)
            .maybeSingle();
          if (existing) {
            setMessages((prev) => mergeMessages(prev, [existing as Message]));
            return;
          }
        }
      } catch {
        /* fall through to failed */
      }
      setMessages((prev) => mergeMessages(prev, [{ ...optimistic, status: 'failed' }]));
    },
    [conversationId, myId],
  );

  const retry = useCallback(
    (clientId: string) => {
      const m = messagesRef.current.find((x) => x.client_id === clientId && x.status === 'failed');
      if (m) void send(m.body, clientId);
    },
    [send],
  );

  const discard = useCallback((clientId: string) => {
    setMessages((prev) => prev.filter((m) => !(m.client_id === clientId && m.status === 'failed')));
  }, []);

  const reload = useCallback(() => setNonce((n) => n + 1), []);

  return { messages, loading, error, hasMore, loadingOlder, otherLastRead, send, retry, discard, loadOlder, reload };
}
