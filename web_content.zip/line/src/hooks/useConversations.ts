import { useCallback, useEffect, useRef, useState } from 'react';
import { supabase } from '../lib/supabase';
import type { ConversationSummary } from '../lib/types';

/** Conversation list (preview, unread count, sorted by latest message) kept fresh through Realtime. */
export function useConversations(userId: string) {
  const [items, setItems] = useState<ConversationSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const refresh = useCallback(async () => {
    const { data, error: err } = await supabase.rpc('list_conversations');
    if (err) {
      setError('Could not load your conversations. Check your connection and try again.');
    } else {
      setItems(((data ?? []) as ConversationSummary[]).map((c) => ({ ...c, unread_count: Number(c.unread_count) })));
      setError(null);
    }
    setLoading(false);
  }, []);

  // Coalesce bursts of realtime events into a single refetch.
  const scheduleRefresh = useCallback(() => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => void refresh(), 150);
  }, [refresh]);

  useEffect(() => {
    void refresh();
    const channel = supabase
      .channel(`inbox:${userId}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, scheduleRefresh)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'conversation_members' }, scheduleRefresh)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'conversation_members' }, scheduleRefresh)
      // SUBSCRIBED fires again after every reconnect, so anything missed while offline is refetched.
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') scheduleRefresh();
      });
    const onWake = () => {
      if (document.visibilityState === 'visible') scheduleRefresh();
    };
    document.addEventListener('visibilitychange', onWake);
    window.addEventListener('online', onWake);
    return () => {
      if (timer.current) clearTimeout(timer.current);
      document.removeEventListener('visibilitychange', onWake);
      window.removeEventListener('online', onWake);
      void supabase.removeChannel(channel);
    };
  }, [userId, refresh, scheduleRefresh]);

  return { items, loading, error, refresh };
}
