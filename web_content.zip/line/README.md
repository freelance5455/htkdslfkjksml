# LINE

A minimalist, grey-and-white messenger. React + TypeScript + Vite on the front end; Supabase (Postgres, Auth,
Realtime) as the back end. Version 1 is reliable one-to-one text messaging.

> **Status:** the code is complete, but LINE only works once *you* connect your own Supabase project (steps below).
> Until then the app shows a "Supabase isn't configured" screen. See `TESTING.md` for what to verify.

## What it does
Email/password sign-up and sign-in, password reset, profiles, user search by display name, direct conversations
(never duplicated), persistent real-time messages, older-message loading, unread counts, sent/read status,
retry on failure, reconnect catch-up, mobile and desktop layouts.

### Message status – exact meaning
| Status | Meaning |
|---|---|
| Sending | Only in your browser; the request to the database is still in progress. |
| Not sent | The request failed. Nothing was stored. You can Retry (safe: never creates duplicates) or Delete. |
| Sent | The database confirmed it stored the message. |
| Read | The other person opened the conversation after the message was stored. |

There is no "Delivered" status because the system cannot know whether a device received a message.

## 1. Create the Supabase project
1. Go to <https://supabase.com>, sign up, click **New project**.
2. Choose a name, a strong database password (save it) and the region nearest your users. Wait until it is ready.

## 2. Create the database
1. Dashboard → **SQL Editor** → **New query**.
2. Paste the entire contents of `supabase/migrations/001_init.sql` and click **Run**. Run it once only.
3. (Optional, recommended) New query → paste `supabase/tests/rls_test.sql` → Run. It should print
   `All security checks passed`. It rolls back, so it leaves no data.
4. Check Realtime: **Database → Publications → supabase_realtime** should list `messages` and `conversation_members`
   (the migration adds them).

## 3. Configure authentication
1. **Authentication → Providers → Email**: keep it enabled.
2. **Authentication → Sign In / Providers** (or **Settings**): decide on **Confirm email**.
   - On (default): new users must click an email link before they can sign in. The app tells them so.
   - Off: easier for testing; users are signed in immediately.
3. **Authentication → URL Configuration**:
   - **Site URL**: `http://localhost:5173` while developing; change it to your deployed URL later.
   - **Redirect URLs**: add `http://localhost:5173/**` and, once deployed, `https://YOUR-APP-URL/**`.
4. Supabase's built-in email sender is heavily rate-limited and meant for testing. For real use, set up your own
   SMTP provider under **Authentication → Emails → SMTP Settings**.

## 4. Environment variables
1. Dashboard → **Project Settings → API**. Copy the **Project URL** and the **anon public** key.
2. In the project folder: `cp .env.example .env.local` and fill in:
   ```
   VITE_SUPABASE_URL=https://xxxx.supabase.co
   VITE_SUPABASE_ANON_KEY=eyJ...
   ```
3. Never use or paste the `service_role` key anywhere in this app. The anon key is designed to be public; the
   database security rules (RLS) are what protect data.

## 5. Run locally
Requires Node.js 18 or newer (<https://nodejs.org>).
```
npm install
npm run test        # unit tests
npm run typecheck   # TypeScript check
npm run dev         # http://localhost:5173
```
To try two users, sign up once in a normal window and once in a private window.

## 6. Deploy (free tiers; check each provider's current limits)
**Vercel**
1. Push this folder to a GitHub repository.
2. <https://vercel.com> → **Add New → Project** → import the repository (Framework: Vite; build `npm run build`; output `dist`).
3. Under **Environment Variables** add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`. Deploy.
4. `vercel.json` already makes page refreshes on `/c/...` work.

**Netlify** works the same way (`public/_redirects` handles the refresh routing).

**After deploying**: copy the live URL, then in Supabase → Authentication → URL Configuration set **Site URL** to it and
add `https://YOUR-APP-URL/**` to **Redirect URLs**. Without this, confirmation and reset links will point to the wrong place.

### Costs and limits (verify current numbers on the pricing pages)
Supabase's free plan has caps on database size, monthly active users, Realtime connections and email sending, and free
projects may be paused after a period of inactivity. Vercel and Netlify free tiers have bandwidth/build limits.

## Security model (summary)
- Row-level security is on for every table. Members can read only their own conversations and messages.
- Messages can only be inserted as yourself into conversations you belong to. No edit or delete exists for clients.
- Clients cannot insert or change memberships; conversations are created only by `start_direct_conversation()`, which
  also guarantees one conversation per pair of users.
- Profiles hold only a display name. Email addresses stay in Supabase's private `auth` schema.
- Any signed-in user can search all display names (that is what discovery means). Choose names accordingly.
- Deleting an account deletes that person's messages for everyone (foreign-key cascade).

## Troubleshooting
| Problem | Check |
|---|---|
| "Supabase isn't configured" | `.env.local` exists, values are real, dev server restarted; on hosting, variables set and redeployed. |
| "We couldn't load your profile" | Migration not run, or run partially. Re-check step 2. |
| Sign-up says check your email but nothing arrives | Check spam; built-in email is rate-limited (step 3.4). |
| Confirmation/reset link opens localhost or a wrong site | Site URL / Redirect URLs (step 3.3). |
| `permission denied` / `row-level security` errors | Migration incomplete; re-run it on a fresh project. |
| Messages only appear after refresh | Realtime publication missing tables (step 2.4); confirm Realtime is enabled for the project. |
| Works, then stops after a while | Free project paused; resume it in the dashboard. |
| Blank page after refresh on a deployed `/c/...` URL | The host needs the SPA rewrite (`vercel.json` / `_redirects`). |

## Project layout
```
supabase/migrations/001_init.sql   tables, RLS, functions, realtime
supabase/tests/rls_test.sql        security checks (run in SQL Editor)
src/lib/                           Supabase client, pure logic (+ unit tests), types
src/context/AuthContext.tsx        session + profile
src/hooks/                         useConversations, useMessages (realtime, paging, retry)
src/components/                    ChatView, ConversationList, Composer, MessageBubble, ProfileSettings, Avatar
src/pages/                         AuthPage, ResetPasswordPage, MessengerPage
```

## Not in version 1
Attachments, calls, group chats, message editing/deletion, typing indicators, push notifications.
