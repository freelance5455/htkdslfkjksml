# LINE testing checklist

Mark each item as you go. Use two different browsers (or one normal window and one private window) for the
two-user tests.

## Automated
- [ ] `npm run test` – unit tests for the app logic (message merging, read status, validation, formatting).
- [ ] `npm run typecheck` – no TypeScript errors.
- [ ] `npm run build` – production build succeeds.
- [ ] Supabase SQL Editor: run `supabase/tests/rls_test.sql` – prints "All security checks passed".

## Accounts
- [ ] Sign up with display name, email, password (8+ characters).
- [ ] If email confirmation is on: the "check your email" message appears, the link works, then sign-in works.
- [ ] Wrong password shows "Incorrect email or password."
- [ ] Refresh the page: you stay signed in. Sign out (with confirmation): you return to the sign-in page.
- [ ] Visit `/` while signed out: you are sent to the sign-in page.
- [ ] "Forgot your password?" sends an email; the link opens `/reset-password`; the new password works.
- [ ] Change your display name in Profile; it persists after refresh.

## Discovery and conversations (users A and B)
- [ ] A searches B's name (2+ letters): B appears; A's own name does not.
- [ ] Clicking B opens a conversation; searching and clicking B again opens the same one (no duplicate).
- [ ] The sidebar never shows anyone's email address.

## Messaging
- [ ] A sends "hello": B sees it appear without refreshing; it is on the left for B and on the right for A.
- [ ] B's conversation list shows an unread badge and the preview; the list moves to the top.
- [ ] B opens the conversation: badge disappears and A's message changes from "Sent" to "Read".
- [ ] Enter sends; Shift+Enter adds a new line; empty messages cannot be sent.
- [ ] Send 40+ messages; "Load earlier messages" loads older ones without jumping the scroll position.
- [ ] Messages from different days show date separators.
- [ ] Refresh and sign in again: history is still there.
- [ ] Turn off Wi-Fi, send a message: it shows "Not sent" with Retry. Turn Wi-Fi on, press Retry: it sends once.
- [ ] While B is offline, A sends messages; when B reconnects they appear.

## Layout
- [ ] Desktop: list on the left, chat on the right, welcome screen when nothing is selected.
- [ ] Phone (or browser device mode): list first, chat full-screen, back arrow works.
- [ ] Phone: the keyboard does not cover the message box; no sideways scrolling.

## Security spot checks
- [ ] Open a conversation URL (`/c/<id>`) belonging to other people: "doesn't exist or you don't have access".
- [ ] There is no `service_role` key anywhere in `.env.local`, the code or the hosting settings.
