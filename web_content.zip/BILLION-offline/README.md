# BILLION — controle financeiro offline

Aplicativo simples para Android, sem IA e sem conexão necessária para o uso diário. Registra rendimentos e gastos com data, categoria e descrição; calcula o total do mês escolhido; permite excluir lançamentos e exportar/importar backup JSON. Os dados ficam no armazenamento local do aplicativo/aparelho.

## Gerar APK pelo celular usando GitHub Actions

1. Crie um repositório novo no GitHub chamado `BILLION-offline`.
2. Envie **todos os arquivos desta pasta** para o repositório (pelo site do GitHub no navegador do celular, use Add file → Upload files).
3. Abra a aba **Actions** e habilite workflows se o GitHub pedir.
4. O workflow começa automaticamente depois do envio para a branch `main`. Também pode abrir **Actions → Gerar APK BILLION → Run workflow**.
5. Quando terminar com sucesso, abra a execução e baixe o artefato `BILLION-APK`. Extraia o ZIP baixado e instale `app-debug.apk` no Android. Talvez seja necessário permitir instalação dessa fonte.

O APK de debug é adequado para instalar e testar no próprio celular. Não é uma versão publicada na Play Store.

## Observações

- O projeto Monio enviado usa Next.js, API de servidor e SQLite via `better-sqlite3`; não pode ser simplesmente colocado dentro de um APK offline sem reestruturar a arquitetura. Esta é uma versão leve e independente feita para o requisito descrito: painel local, sem IA, com dados diários e resumo mensal.
- Não apague os dados do aplicativo sem antes exportar um backup. O backup é salvo como arquivo JSON.
