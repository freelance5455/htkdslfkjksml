const dictionary = {
  "choke": { "pos": "v.", "mm": "အစာနင်သည်၊ လည်ချောင်းပိတ်၍ အသက်ရှူကျပ်သည်" },
  "digestion": { "pos": "n.", "mm": "အစာချေဖျက်ခြင်း" },
  "junk": { "pos": "n.", "mm": "အာဟာရမဖြစ်သော အစားအစာ (junk food)" },
  "mindfully": { "pos": "adv.", "mm": "သတိကပ်၍၊ သေချာအာရုံစိုက်၍" },
  "mindlessly": { "pos": "adv.", "mm": "သတိလက်လွတ်၊ အမှတ်တမဲ့" },
  "mineral": { "pos": "n./adj.", "mm": "သတ္တုဓာတ်ပါသော (mineral water = သောက်ရေသန့်)" },
  "obesity": { "pos": "n.", "mm": "အဝလွန်ခြင်း" },
  "sugary": { "pos": "adj.", "mm": "သကြားဓာတ်များသော၊ ချိုလွန်းသော" },
  "presenter": { "pos": "n.", "mm": "အစီအစဉ်တင်ဆက်သူ" },
  "hungry": { "pos": "adj.", "mm": "ဆာလောင်သော" },
  "burgers": { "pos": "n.", "mm": "အသားညှပ်ပေါင်မုန့်များ" },
  "chips": { "pos": "n.", "mm": "အာလူးကြော်များ" },
  "litres": { "pos": "n.", "mm": "လီတာများ" },
  "enjoyable": { "pos": "adj.", "mm": "ပျော်ရွှင်နှစ်သက်ဖွယ်ကောင်းသော" },
  "allow": { "pos": "v.", "mm": "ခွင့်ပြုသည်" },
  "blog": { "pos": "n.", "mm": "အင်တာနက်ပေါ်တွင် ကိုယ်ပိုင်အတွေ့အကြုံများ ရေးသားသော ဝက်ဘ်ဆိုက်" },
  "blogger": { "pos": "n.", "mm": "ဘလော့ဂ်ရေးသားသူ" },
  "responsibility": { "pos": "n.", "mm": "တာဝန်ယူမှု၊ တာဝန်သိစိတ်" },
  "unity": { "pos": "n.", "mm": "စည်းလုံးညီညွတ်မှု" },
  "routine": { "pos": "n.", "mm": "နေ့စဉ်ပုံမှန်လုပ်ငန်းစဉ်" },
  "remind": { "pos": "v.", "mm": "သတိပေးသည်" },
  "variety": { "pos": "n.", "mm": "အမျိုးအစားစုံလင်မှု" },
  "aware": { "pos": "adj.", "mm": "သတိပြုမိသော၊ သိရှိသော" },
  "importance": { "pos": "n.", "mm": "အရေးပါမှု" },
  "balanced": { "pos": "adj.", "mm": "မျှတသော" },
  "diet": { "pos": "n.", "mm": "စားသောက်မှုပုံစံ၊ အစားအစာ" },
  "manners": { "pos": "n.", "mm": "အမူအကျင့်၊ ယဉ်ကျေးမှု (table manners = ထမင်းစားပွဲယဉ်ကျေးမှု)" },
  "occasionally": { "pos": "adv.", "mm": "တစ်ခါတစ်ရံ" },
  "household": { "pos": "adj./n.", "mm": "အိမ်ထောင်စု၊ အိမ်တွင်း" },
  "chores": { "pos": "n.", "mm": "အိမ်မှုကိစ္စများ" },
  "sweeping": { "pos": "v.", "mm": "တံမြက်စည်းလှဲခြင်း" },
  "cooperative": { "pos": "adj.", "mm": "ပူးပေါင်းဆောင်ရွက်တတ်သော" },
  "engage": { "pos": "v.", "mm": "ပါဝင်လုပ်ဆောင်သည်" },
  "outdoor": { "pos": "adj.", "mm": "ပြင်ပ၌လုပ်သော" },
  "indoor": { "pos": "adj.", "mm": "အိမ်တွင်း၌လုပ်သော" },
  "physical": { "pos": "adj.", "mm": "ရုပ်ပိုင်းဆိုင်ရာ" },
  "realise": { "pos": "v.", "mm": "သဘောပေါက်နားလည်သည်" },
  "value": { "pos": "n.", "mm": "တန်ဖိုး" },
  "settled": { "pos": "v.", "mm": "အခြေကျသည်၊ အကျင့်ပါသည်" },
  "beneficial": { "pos": "adj.", "mm": "အကျိုးကျေးဇူးရှိသော" },
  "challenge": { "pos": "n.", "mm": "စိန်ခေါ်မှု၊ အခက်အခဲ" },
  "single": { "pos": "adj.", "mm": "တစ်ဦးတည်းဖြစ်သော" },
  "skips": { "pos": "v.", "mm": "ကျော်သွားသည်၊ မစားဘဲနေသည်" },
  "frequently": { "pos": "adv.", "mm": "မကြာခဏ" },
  "slices": { "pos": "n.", "mm": "အလွှာများ၊ အချပ်များ" },
  "ketchup": { "pos": "n.", "mm": "ခရမ်းချဉ်သီးဆော့စ်" },
  "hardly": { "pos": "adv.", "mm": "မရှိသလောက်နည်းပါးစွာ" },
  "quarter": { "pos": "n.", "mm": "တစ်စိတ် (၁၅ မိနစ်)" },
  "electric": { "pos": "adj.", "mm": "လျှပ်စစ်သုံး" },
  "civil": { "pos": "adj.", "mm": "မြို့ပြဆိုင်ရာ (civil engineer = မြို့ပြအင်ဂျင်နီယာ)" },
  "construction": { "pos": "n.", "mm": "ဆောက်လုပ်ရေး" },
  "weekdays": { "pos": "n.", "mm": "ရုံးဖွင့်ရက်များ (တနင်္လာမှ သောကြာ)" },
  "assigns": { "pos": "v.", "mm": "တာဝန်ခွဲဝေပေးသည်" },
  "resume": { "pos": "v.", "mm": "ပြန်လည်စတင်သည်" },
  "protective": { "pos": "adj.", "mm": "အကာအကွယ်ပေးသော" },
  "inspect": { "pos": "v.", "mm": "စစ်ဆေးကြည့်ရှုသည်" },
  "principal": { "pos": "n.", "mm": "ကျောင်းအုပ်ကြီး" },
  "timetable": { "pos": "n.", "mm": "အချိန်ဇယား" },
  "rules": { "pos": "n.", "mm": "စည်းမျဉ်းစည်းကမ်းများ" },
  "regularly": { "pos": "adv.", "mm": "မှန်မှန်၊ ပုံမှန်" },
  "valuable": { "pos": "adj.", "mm": "တန်ဖိုးကြီးသော" },
  "government": { "pos": "n.", "mm": "အစိုးရ" },
  "private": { "pos": "adj.", "mm": "ပုဂ္ဂလိက၊ ကိုယ်ပိုင်" },
  "monastic": { "pos": "adj.", "mm": "ဘုန်းတော်ကြီးသင်" },
  "shape": { "pos": "v./n.", "mm": "ပုံဖော်သည်၊ ပုံသဏ္ဌာန်" },
  "primary": { "pos": "adj.", "mm": "မူလတန်း၊ အခြေခံ" },
  "mixed": { "pos": "adj.", "mm": "ကျား/မ တွဲဖက်ဖြစ်သော" },
  "strict": { "pos": "adj.", "mm": "စည်းကမ်းတင်းကျပ်သော" },
  "fundamental": { "pos": "adj.", "mm": "အခြေခံကျသော" },
  "solid": { "pos": "adj.", "mm": "ခိုင်မာသော" },
  "foundation": { "pos": "n.", "mm": "အခြေခံအုတ်မြစ်" },
  "strengths": { "pos": "n.", "mm": "အားသာချက်များ" },
  "weaknesses": { "pos": "n.", "mm": "အားနည်းချက်များ" },
  "encouraged": { "pos": "v.", "mm": "အားပေးမြှင့်တင်ခဲ့သည်" },
  "competition": { "pos": "n.", "mm": "ပြိုင်ပွဲ" },
  "inspiring": { "pos": "adj.", "mm": "စိတ်ဓာတ်ခွန်အားဖြစ်စေသော" },
  "secondary": { "pos": "adj.", "mm": "အလယ်တန်း/အထက်တန်းဆင့်" },
  "compound": { "pos": "n.", "mm": "ကျောင်းဝင်း၊ ခြံဝင်း" },
  "dedicated": { "pos": "adj.", "mm": "စိတ်ရောကိုယ်ပါ နှစ်မြှုပ်ထားသော" },
  "ideal": { "pos": "adj.", "mm": "စံပြဖြစ်သော" },
  "concept": { "pos": "n.", "mm": "သဘောတရား၊ အယူအဆ" },
  "feedback": { "pos": "n.", "mm": "အကြံပြုသုံးသပ်ချက်" },
  "stern": { "pos": "adj.", "mm": "တည်ကြည်ခန့်ညားသော၊ စည်းကမ်းကြီးသော" },
  "temper": { "pos": "n.", "mm": "စိတ်တိုခြင်း၊ ဒေါသ" },
  "memorable": { "pos": "adj.", "mm": "အမှတ်တရဖြစ်စေသော" },
  "mentally": { "pos": "adv.", "mm": "စိတ်ပိုင်းဆိုင်ရာအရ" },
  "emotionally": { "pos": "adv.", "mm": "ခံစားချက်ပိုင်းဆိုင်ရာအရ" },
  "pamphlet": { "pos": "n.", "mm": "လက်ကမ်းစာစောင်" },
  "facilities": { "pos": "n.", "mm": "အသုံးအဆောင်နှင့် ဝန်ဆောင်မှုများ" },
  "alumni": { "pos": "n.", "mm": "ကျောင်းသားဟောင်းများ" },
  "knitting": { "pos": "n.", "mm": "သိုးမွှေးထိုးခြင်း" },
  "instructor": { "pos": "n.", "mm": "နည်းပြဆရာ" },
  "woollen": { "pos": "adj.", "mm": "သိုးမွှေးဖြင့်ပြုလုပ်သော" },
  "toolkit": { "pos": "n.", "mm": "ကိရိယာတန်ဆာပလာအိတ်" },
  "needles": { "pos": "n.", "mm": "သိုးမွှေးထိုးအပ်များ" },
  "yarns": { "pos": "n.", "mm": "သိုးမွှေးချည်ခင်များ" },
  "borrow": { "pos": "v.", "mm": "ခဏငှားယူသည်" },
  "lend": { "pos": "v.", "mm": "ခဏပေးငှားသည်" },
  "gloves": { "pos": "n.", "mm": "လက်အိတ်များ" },
  "relaxation": { "pos": "n.", "mm": "စိတ်အပန်းဖြေခြင်း" },
  "reduce": { "pos": "v.", "mm": "လျှော့ချသည်" },
  "stress": { "pos": "n.", "mm": "စိတ်ဖိစီးမှု" },
  "boost": { "pos": "v.", "mm": "မြှင့်တင်ပေးသည်" },
  "creativity": { "pos": "n.", "mm": "တီထွင်ဖန်တီးနိုင်စွမ်း" },
  "shawls": { "pos": "n.", "mm": "ပခုံးခြုံပဝါများ" },
  "violin": { "pos": "n.", "mm": "တယော" },
  "strings": { "pos": "n.", "mm": "တူရိယာကြိုးများ" },
  "bow": { "pos": "n.", "mm": "တယောထိုးတံ" },
  "orchestra": { "pos": "n.", "mm": "သံစုံတီးဝိုင်း" },
  "melody": { "pos": "n.", "mm": "သံစဉ်" },
  "professional": { "pos": "adj.", "mm": "ကျွမ်းကျင်ပညာရှင်ဖြစ်သော" },
  "martial": { "pos": "adj.", "mm": "ကိုယ်ခံပညာနှင့်ဆိုင်သော" },
  "self-defence": { "pos": "n.", "mm": "မိမိကိုယ်ကို ခုခံကာကွယ်ခြင်း" },
  "leisure": { "pos": "n.", "mm": "အားလပ်ချိန်" },
  "strengthen": { "pos": "v.", "mm": "ပိုမိုခိုင်မာအားကောင်းစေသည်" },
  "stamina": { "pos": "n.", "mm": "သက်လုံကောင်းမှု၊ ခံနိုင်ရည်" },
  "champion": { "pos": "n.", "mm": "ချန်ပီယံ၊ အနိုင်ရသူ" },
  "practical": { "pos": "adj.", "mm": "လက်တွေ့ကျသော" },
  "knots": { "pos": "n.", "mm": "ကြိုးထုံးများ" },
  "campsite": { "pos": "n.", "mm": "စခန်းချရာနေရာ" },
  "confident": { "pos": "adj.", "mm": "မိမိကိုယ်ကို ယုံကြည်မှုရှိသော" },
  "wind": { "pos": "n./adj.", "mm": "လေ၊ လေမှုတ်တူရိယာ" },
  "percussion": { "pos": "n.", "mm": "တီးခတ်ရသော တူရိယာ" },
  "brass": { "pos": "n.", "mm": "ကြေးဝါ" },
  "conductor": { "pos": "n.", "mm": "တီးဝိုင်းခေါင်းဆောင်" },
  "urgently": { "pos": "adv.", "mm": "အရေးတကြီး" },
  "citizen": { "pos": "n.", "mm": "နိုင်ငံသား၊ ကမ္ဘာ့သားကောင်း" },
  "teenagers": { "pos": "n.", "mm": "ဆယ်ကျော်သက်လူငယ်များ" },
  "volunteer": { "pos": "v./n.", "mm": "စေတနာ့ဝန်ထမ်း လုပ်ဆောင်သည်" },
  "community": { "pos": "n.", "mm": "ရပ်ရွာလူထု" },
  "campaign": { "pos": "n.", "mm": "လှုပ်ရှားမှုကမ်ပိန်း" },
  "pregnant": { "pos": "adj.", "mm": "ကိုယ်ဝန်ဆောင်သော" },
  "elderly": { "pos": "adj.", "mm": "သက်ကြီးရွယ်အိုဖြစ်သော" },
  "donate": { "pos": "v.", "mm": "လှူဒါန်းသည်" },
  "orphanage": { "pos": "n.", "mm": "မိဘမဲ့ဂေဟာ" },
  "cooperation": { "pos": "n.", "mm": "ပူးပေါင်းဆောင်ရွက်ခြင်း" },
  "qualities": { "pos": "n.", "mm": "အရည်အချင်းများ" },
  "adaptability": { "pos": "n.", "mm": "လိုက်လျောညီထွေ ပြောင်းလဲနိုင်စွမ်း" },
  "survival": { "pos": "n.", "mm": "ရှင်သန်ရပ်တည်နိုင်မှု" },
  "rapidly": { "pos": "adv.", "mm": "အလျင်အမြန်" },
  "cope": { "pos": "v.", "mm": "ရင်ဆိုင်ဖြေရှင်းနိုင်သည်" },
  "observant": { "pos": "adj.", "mm": "စူးစမ်းလေ့လာတတ်သော" },
  "resources": { "pos": "n.", "mm": "သယံဇာတများ" },
  "rubies": { "pos": "n.", "mm": "ပတ္တမြားများ" },
  "jades": { "pos": "n.", "mm": "ကျောက်စိမ်းများ" },
  "gems": { "pos": "n.", "mm": "ကျောက်မျက်ရတနာများ" },
  "hospitality": { "pos": "n.", "mm": "ဧည့်ဝတ်ကျေပွန်မှု" },
  "significant": { "pos": "adj.", "mm": "ထင်ရှားအရေးပါသော" },
  "sincere": { "pos": "adj.", "mm": "ရိုးသားဖြူစင်သော" },
  "altitude": { "pos": "n.", "mm": "ပင်လယ်ရေမျက်နှာပြင်အထက် အမြင့်" },
  "lifeblood": { "pos": "n.", "mm": "အသက်သွေးကြော" },
  "patient": { "pos": "adj.", "mm": "စိတ်ရှည်သည်းခံသော" },
  "snacks": { "pos": "n.", "mm": "မုန့်ပဲသရေစာများ" },
  "careless": { "pos": "adj.", "mm": "ပေါ့ဆသော" },
  "admit": { "pos": "v.", "mm": "ဝန်ခံသည်" },
  "forgives": { "pos": "v.", "mm": "ခွင့်လွှတ်သည်" },
  "desktop": { "pos": "n.", "mm": "စားပွဲတင်ကွန်ပျူတာ" },
  "monitor": { "pos": "n.", "mm": "ကွန်ပျူတာ ဖန်သားပြင်" },
  "output": { "pos": "n.", "mm": "အချက်အလက် ထုတ်ပေးသော" },
  "input": { "pos": "v./n.", "mm": "အချက်အလက် ထည့်သွင်းသည်" },
  "cursor": { "pos": "n.", "mm": "ဖန်သားပြင်ပေါ်ရှိ ညွှန်ပြသင်္ကေတ" },
  "commands": { "pos": "n.", "mm": "ညွှန်ကြားချက်များ" },
  "composed": { "pos": "adj.", "mm": "ဖွဲ့စည်းထားသော" },
  "software": { "pos": "n.", "mm": "ကွန်ပျူတာကို မောင်းနှင်သော ပရိုဂရမ်များ" },
  "hardware": { "pos": "n.", "mm": "ကွန်ပျူတာ၏ ထိတွေ့ကိုင်တွယ်၍ရသော အစိတ်အပိုင်းများ" },
  "formatting": { "pos": "n.", "mm": "စာမျက်နှာပုံစံ ချိန်ညှိခြင်း" },
  "documents": { "pos": "n.", "mm": "စာရွက်စာတမ်းများ" },
  "dialogue": { "pos": "n.", "mm": "စကားပြောခန်း / အပြန်အလှန်ပြောကွက်" },
  "imperatives": { "pos": "n.", "mm": "အမိန့်ပေး/ညွှန်ကြားဝါကျများ" },
  "invisible": { "pos": "adj.", "mm": "မျက်စိဖြင့် မမြင်နိုင်သော" },
  "squeeze": { "pos": "v.", "mm": "ညှစ်သည်" },
  "saline": { "pos": "adj.", "mm": "ဆားရည်ပါသော" },
  "sterilise": { "pos": "v.", "mm": "ပိုးသတ်သန့်စင်သည်" },
  "dissolved": { "pos": "adj.", "mm": "အရည်ပျော်ဝင်သွားသော" },
  "harnessing": { "pos": "v.", "mm": "စွမ်းအင်ထုတ်ယူအသုံးပြုခြင်း" },
  "ecosystem": { "pos": "n.", "mm": "ဂေဟစနစ်" },
  "atmosphere": { "pos": "n.", "mm": "လေထု" },
  "scatters": { "pos": "v.", "mm": "ဖြန့်ကြဲသည်" },
  "interact": { "pos": "v.", "mm": "အပြန်အလှန် အကျိုးပြုဆက်ဆံသည်" },
  "fossil": { "pos": "n.", "mm": "ကျောက်ဖြစ်ရုပ်ကြွင်း" },
  "endangered": { "pos": "adj.", "mm": "မျိုးသုဉ်းရန် အန္တရာယ်ရှိသော" },
  "degraded": { "pos": "adj.", "mm": "အရည်အသွေး ကျဆင်းပျက်စီးသော" },
  "fertilizers": { "pos": "n.", "mm": "မြေဩဇာများ" },
  "emitting": { "pos": "v.", "mm": "ထုတ်လွှတ်နေသော" },
  "greenhouse": { "pos": "n.", "mm": "ဖန်လုံအိမ် (greenhouse gases = ဖန်လုံအိမ်ဓာတ်ငွေ့များ)" },
  "ozone": { "pos": "n.", "mm": "အိုဇုန်းလွှာ" },
  "disposing": { "pos": "v.", "mm": "စွန့်ပစ်နေသော" },
  "pollution": { "pos": "n.", "mm": "ညစ်ညမ်းမှု" },
  "security": { "pos": "n.", "mm": "လုံခြုံဖူလုံမှု (food security = စားနပ်ရိက္ခာဖူလုံမှု)" },
  "disasters": { "pos": "n.", "mm": "သဘာဝဘေးအန္တရာယ်များ" },
  "droughts": { "pos": "n.", "mm": "မိုးခေါင်ရေရှားမှုများ" },
  "landslides": { "pos": "n.", "mm": "မြေပြိုမှုများ" },
  "recycle": { "pos": "v.", "mm": "ပြန်လည်အသုံးပြုရန် ပြုပြင်ထုတ်လုပ်သည်" },
  "generations": { "pos": "n.", "mm": "မျိုးဆက်များ" },
  "tote": { "pos": "n.", "mm": "ချည်လွယ်အိတ် (tote bag)" },
  "prohibition": { "pos": "n.", "mm": "တားမြစ်ချက်" },
  "earpiece": { "pos": "n.", "mm": "ဖုန်းနားထောင်ခွက်" },
  "mouthpiece": { "pos": "n.", "mm": "ဖုန်းစကားပြောခွက်" },
  "adventurous": { "pos": "adj.", "mm": "စွန့်စားရသည်ကို နှစ်သက်သော" },
  "trek": { "pos": "n./v.", "mm": "တောင်တက်ခရီးကြမ်း လျှောက်ခြင်း" },
  "overlooking": { "pos": "prep.", "mm": "အပေါ်စီးမှ မြင်နေရသော" },
  "sunbathing": { "pos": "n.", "mm": "နေပူဆာလှုံခြင်း" },
  "bonfire": { "pos": "n.", "mm": "မီးပုံပွဲ" },
  "extraordinary": { "pos": "adj.", "mm": "ထူးခြားဆန်းပြားသော" },
  "unspoiled": { "pos": "adj.", "mm": "သဘာဝအတိုင်း မပျက်မစီးရှိနေသော" },
  "cruise": { "pos": "n.", "mm": "အပျော်စီးသင်္ဘောခရီးစဉ်" },
  "canoeing": { "pos": "n.", "mm": "လှေလှော်ခြင်း" },
  "snorkelling": { "pos": "n.", "mm": "ရေပေါ်ပိုက်တပ် ရေငုပ်ခြင်း" },
  "lifebuoys": { "pos": "n.", "mm": "အသက်ကယ်ဘောကွင်းများ" },
  "tweets": { "pos": "n.", "mm": "ငှက်မြည်သံများ" },
  "reasonable": { "pos": "adj.", "mm": "သင့်တင့်မျှတသော" },
  "predictions": { "pos": "n.", "mm": "ခန့်မှန်းချက်များ" },
  "invitation": { "pos": "n.", "mm": "ဖိတ်ကြားချက်" },
  "resort": { "pos": "n.", "mm": "အပန်းဖြေစခန်း" },
  "conservation": { "pos": "n.", "mm": "ထိန်းသိမ်းစောင့်ရှောက်ခြင်း" },
  "habitats": { "pos": "n.", "mm": "သဘာဝနေရင်းဒေသများ" },
  "detergent": { "pos": "n.", "mm": "ဆပ်ပြာမှုန့်" },
  "oasis": { "pos": "n.", "mm": "သဲကန္တာရအတွင်းရှိ ရေအိုင်စိမ်းလန်းရာနေရာ" },
  "coastal": { "pos": "adj.", "mm": "ကမ်းရိုးတန်းဒေသနှင့်ဆိုင်သော" },
  "furnished": { "pos": "adj.", "mm": "ပရိဘောဂ အပြည့်အစုံ တပ်ဆင်ထားသော" },
  "spacious": { "pos": "adj.", "mm": "ကျယ်ဝန်းသော" },
  "patio": { "pos": "n.", "mm": "အိမ်ရှေ့မြေကွက်လပ်/ဝရန်တာ" },
  "unique": { "pos": "adj.", "mm": "တစ်မူထူးခြားသော" },
  "bungalows": { "pos": "n.", "mm": "တစ်ထပ်တိုက်ပုလေးများ" },
  "organic": { "pos": "adj.", "mm": "ဓာတုဆေးဝါးကင်းစင်သော (သဘာဝ)" },
  "pluck": { "pos": "v.", "mm": "ခူးဆွတ်သည်" },
  "kitchenette": { "pos": "n.", "mm": "မီးဖိုချောင်ငယ်လေး" },
  "hospitable": { "pos": "adj.", "mm": "ဧည့်ဝတ်ကျေပွန်သော" },
  "panoramic": { "pos": "adj.", "mm": "မြင်ကွင်းကျယ်ဖြစ်သော" },
  "enormous": { "pos": "adj.", "mm": "အလွန်ကြီးမားသော" },
  "breathtaking": { "pos": "adj.", "mm": "ရင်သပ်ရှုမောဖွယ်ကောင်းသော" },
  "boulder": { "pos": "n.", "mm": "ကျောက်တုံးကြီး" },
  "monasteries": { "pos": "n.", "mm": "ဘုန်းတော်ကြီးကျောင်းများ" },
  "plantations": { "pos": "n.", "mm": "စိုက်ခင်းများ" },
  "snow-capped": { "pos": "adj.", "mm": "ဆီးနှင်းများဖုံးလွှမ်းနေသော" },
  "majestically": { "pos": "adv.", "mm": "ခမ်းနားထည်ဝါစွာ" },
  "gloriously": { "pos": "adv.", "mm": "တင့်တယ်ခမ်းနားစွာ" },
  "confluence": { "pos": "n.", "mm": "မြစ်ဆုံရာနေရာ" },
  "carvings": { "pos": "n.", "mm": "ပန်းပုလက်ရာများ" },
  "destination": { "pos": "n.", "mm": "ခရီးပန်းတိုင်၊ သွားရောက်ရာနေရာ" },
  "heritage": { "pos": "n.", "mm": "အမွေအနှစ်" },
  "biodiversity": { "pos": "n.", "mm": "ဇီဝမျိုးစုံမျိုးကွဲများ" },
  "enrichment": { "pos": "n.", "mm": "ကြွယ်ဝတိုးပွားစေခြင်း" },
  "dwellers": { "pos": "n.", "mm": "နေထိုင်သူများ" },
  "mammals": { "pos": "n.", "mm": "နို့တိုက်သတ္တဝါများ" },
  "reptiles": { "pos": "n.", "mm": "တွားသွားသတ္တဝါများ" },
  "impulse": { "pos": "n.", "mm": "ရုတ်တရက် စိတ်ကူးပေါ်ခြင်း" },
  "dilemma": { "pos": "n.", "mm": "အကျပ်အတည်း၊ ဝေခွဲရခက်သော အခြေအနေ" },
  "reluctantly": { "pos": "adv.", "mm": "မပြန်ချင်ပြန်ချင်ဖြင့်" },
  "pastime": { "pos": "n.", "mm": "အားလပ်ချိန် ဝါသနာ" },
  "dressmaker": { "pos": "n.", "mm": "အမျိုးသမီးအဝတ်အထည်ချုပ်သူ" },
  "attendant": { "pos": "n.", "mm": "ဝန်ဆောင်မှုပေးသူ (flight attendant = လေယာဉ်မယ်)" },
  "retired": { "pos": "adj.", "mm": "အငြိမ်းစားယူထားသော" },
  "meditating": { "pos": "v.", "mm": "တရားထိုင်ခြင်း" },
  "majority": { "pos": "n.", "mm": "အများစု" },
  "pressure": { "pos": "n.", "mm": "ဖိအား" },
  "ambitious": { "pos": "adj.", "mm": "ရည်မှန်းချက်ကြီးသော" },
  "well-being": { "pos": "n.", "mm": "ကျန်းမာပျော်ရွှင်မှု" },
  "refresh": { "pos": "v.", "mm": "လန်းဆန်းစေသည်" },
  "satisfaction": { "pos": "n.", "mm": "စိတ်ကျေနပ်မှု" },
  "concentrate": { "pos": "v.", "mm": "အာရုံစူးစိုက်သည်" },
  "gerund": { "pos": "n.", "mm": "နာမ်အဖြစ်သုံးသော -ing ကြိယာ" },
  "nutritious": { "pos": "adj.", "mm": "အာဟာရပြည့်ဝသော" },
  "digital": { "pos": "adj.", "mm": "ဒစ်ဂျစ်တယ်နည်းပညာသုံး" },
  "device": { "pos": "n.", "mm": "စက်ပစ္စည်းကိရိယာ" },
  "portable": { "pos": "adj.", "mm": "သယ်ဆောင်ရလွယ်ကူသော" },
  "laptop": { "pos": "n.", "mm": "လက်တော့ပ် ကွန်ပျူတာ" },
  "tablet": { "pos": "n.", "mm": "တက်ဘလက်" },
  "smartwatch": { "pos": "n.", "mm": "စမတ်နာရီ" },
  "console": { "pos": "n.", "mm": "ဂိမ်းကစားစက် (game console)" },
  "advantages": { "pos": "n.", "mm": "အားသာချက်များ" },
  "disadvantages": { "pos": "n.", "mm": "အားနည်းချက်များ" },
  "communicate": { "pos": "v.", "mm": "ဆက်သွယ်ပြောဆိုသည်" },
  "instant": { "pos": "adj.", "mm": "ချက်ချင်းလက်ငင်းဖြစ်သော" },
  "entertainment": { "pos": "n.", "mm": "ဖျော်ဖြေရေး" },
  "distraction": { "pos": "n.", "mm": "အာရုံပျံ့လွင့်စေသောအရာ" },
  "addicted": { "pos": "adj.", "mm": "စွဲလမ်းနေသော" },
  "eyesight": { "pos": "n.", "mm": "မျက်စိအမြင်အာရုံ" },
  "strain": { "pos": "n./v.", "mm": "ညောင်းညာထိခိုက်ခြင်း (eye strain)" },
  "conditional": { "pos": "adj./n.", "mm": "အခြေအနေပြဝါကျ" },
  "abbreviations": { "pos": "n.", "mm": "အတိုကောက်စကားလုံးများ" },
  "breaking": { "pos": "adj.", "mm": "နောက်ဆုံးရ (သတင်း - breaking news)" },
  "headline": { "pos": "n.", "mm": "သတင်းခေါင်းစဉ်" },
  "forecast": { "pos": "n.", "mm": "ကြိုတင်ခန့်မှန်းချက် (weather forecast = မိုးလေဝသခန့်မှန်းချက်)" },
  "journalist": { "pos": "n.", "mm": "သတင်းထောက်" },
  "broadcast": { "pos": "v./n.", "mm": "ထုတ်လွှင့်သည်" },
  "neighbourhood": { "pos": "n.", "mm": "ပတ်ဝန်းကျင်၊ ရပ်ကွက်" },
  "incident": { "pos": "n.", "mm": "ဖြစ်ရပ်၊ အဖြစ်အပျက်" },
  "rescue": { "pos": "v./n.", "mm": "ကယ်ဆယ်သည်" },
  "damaged": { "pos": "adj.", "mm": "ပျက်စီးသွားသော" },
  "announced": { "pos": "v.", "mm": "ကြေညာခဲ့သည်" },
  "emergency": { "pos": "n.", "mm": "အရေးပေါ်အခြေအနေ" },
  "firefighters": { "pos": "n.", "mm": "မီးသတ်တပ်ဖွဲ့ဝင်များ" },
  "evacuated": { "pos": "v.", "mm": "ဘေးလွတ်ရာသို့ ရွှေ့ပြောင်းပေးခဲ့သည်" },
  "eyewitness": { "pos": "n.", "mm": "မျက်မြင်သက်သေ" },
  "airy": { "pos": "adj.", "mm": "လေကဲ့သို့ ပေါ့ပါးသော၊ မမြင်နိုင်သော" },
  "creatures": { "pos": "n.", "mm": "သတ္တဝါများ၊ အရာများ" },
  "features": { "pos": "n.", "mm": "ထူးခြားသော လက္ခဏာရပ်များ" },
  "pursue": { "pos": "v.", "mm": "လိုက်လံရှာဖွေသည်၊ ကြိုးပမ်းသည်" },
  "clatters": { "pos": "v.", "mm": "တဖြောက်ဖြောက် မြည်သည်" },
  "gushes": { "pos": "v.", "mm": "အရှိန်ပြင်းစွာ စီးဆင်းထွက်ကျသည်" },
  "overflowing": { "pos": "adj.", "mm": "လျှံကျနေသော" },
  "spout": { "pos": "n.", "mm": "ရေတံလျှောက်ပေါက်" },
  "gutter": { "pos": "n.", "mm": "ရေမြောင်း" },
  "roars": { "pos": "v.", "mm": "ဟိန်းဟောက်မြည်ဟည်းသည်" },
  "snare": { "pos": "n.", "mm": "ကျော့ကွင်း၊ ထောင်ချောက်" },
  "aid": { "pos": "n.", "mm": "အကူအညီ" },
  "frightened": { "pos": "adj.", "mm": "ကြောက်ရွံ့ထိတ်လန့်နေသော" },
  "wrinkling": { "pos": "v.", "mm": "တွန့်ရှုံ့နေသော" },
  "paw": { "pos": "n.", "mm": "တိရစ္ဆာန်၏ ခြေဖဝါး" },
  "harbour": { "pos": "n.", "mm": "ဆိပ်ကမ်း" },
  "quays": { "pos": "n.", "mm": "သင်္ဘောဆိပ်ခံတံတားများ" },
  "thieves": { "pos": "n.", "mm": "သူခိုးများ" },
  "squalling": { "pos": "v.", "mm": "စူးရှစွာ အော်ဟစ်နေသော" },
  "howling": { "pos": "v.", "mm": "အူနေသော (ခွေး)" },
  "squeaking": { "pos": "v.", "mm": "တကျွီကျွီ မြည်နေသော" }
};

const unitsData = [
  {
    "title": "Unit 1: Eating Habits & Family Routines (အစားအသောက်နှင့် မိသားစုအလေ့အကျင့်)",
    "sections": [
      {
        "label": "Lesson 1",
        "title": "Lesson 1: Do you have good eating habits?",
        "note": "💡 ဝေါဟာရမှတ်စု: choke (အစာနင်သည်)၊ digestion (အစာချေဖျက်ခြင်း)၊ junk food (အာဟာရမဖြစ်သော အသင့်စားအစာ)၊ mindfully (သတိကပ်၍ စားသုံးခြင်း)၊ obesity (အဝလွန်ခြင်း)၊ sugary (သကြားဓာတ်များသော)။",
        "passage": [
          { "en": "Now, we're going to listen to La Yaung talking about his eating habits.", "mm": "အခု လရောင်က သူ့ရဲ့ စားသောက်မှု အလေ့အကျင့်တွေအကြောင်း ပြောပြတာကို နားထောင်ကြည့်ကြရအောင်ပါ။" },
          { "en": "I'm usually hungry between meals.", "mm": "ကျွန်တော်က ထမင်းစားချိန် တစ်ချိန်နဲ့တစ်ချိန် ကြားထဲမှာ ဗိုက်ဆာလေ့ရှိပါတယ်။" },
          { "en": "At such times, I have fruit like apples or bananas, but I don't eat junk food like burgers and chips as they can cause obesity.", "mm": "အဲဒီလိုအချိန်တွေမှာ ပန်းသီး ဒါမှမဟုတ် ငှက်ပျောသီးလို အသီးအနှံတွေကို စားလေ့ရှိပြီး အဝလွန်ခြင်းကို ဖြစ်စေနိုင်တဲ့ ဘာဂါနဲ့ အာလူးကြော်လို အသင့်စားအစာ (Junk food) တွေကိုတော့ မစားပါဘူး။" },
          { "en": "I always drink enough water. I drink two litres of water every day.", "mm": "ကျွန်တော် ရေကို အမြဲတမ်း လုံလုံလောက်လောက် သောက်ပါတယ်။ နေ့တိုင်း ရေ ၂ လီတာ သောက်ပါတယ်။" },
          { "en": "I am a fast eater. I usually finish my meals in less than 10 minutes. I know it's not good for digestion.", "mm": "ကျွန်တော်က အစာစားတာ မြန်တဲ့သူပါ။ ပုံမှန်အားဖြင့် ၁၀ မိနစ်တောင် မပြည့်ခင် ထမင်းစားပြီးလေ့ရှိပါတယ်။ အဲဒါက အစာချေဖျက်ခြင်းအတွက် မကောင်းဘူးဆိုတာ ကျွန်တော် သိပါတယ်။" },
          { "en": "Although I often eat alone, I love eating with my family as it is enjoyable.", "mm": "ကျွန်တော် တစ်ယောက်တည်း စားရတာ များပေမဲ့ မိသားစုနဲ့ အတူတူ စားရတာ ပျော်စရာကောင်းလို့ အရမ်းနှစ်သက်ပါတယ်။" },
          { "en": "Sometimes, I want to eat in the living room watching TV. But, my mum doesn't allow this as I can choke on the food, so I have to have my meals at the dining table.", "mm": "တစ်ခါတစ်ရံ ဧည့်ခန်းထဲမှာ တီဗွီကြည့်ရင်း ထမင်းစားချင်ပေမဲ့ အစာနင်မှာစိုးလို့ အမေက ခွင့်မပြုပါဘူး၊ ဒါကြောင့် ထမင်းစားပွဲမှာပဲ စားရပါတယ်။" }
        ]
      },
      {
        "label": "Lesson 2",
        "title": "Lesson 2: Learning starts at home (Mummy's World Blog)",
        "note": "💡 ဝေါဟာရမှတ်စု: blog (အင်တာနက်ပေါ်တွင် အတွေ့အကြုံများ ရေးသားသော ဝက်ဘ်ဆိုက်)၊ table manners (ထမင်းစားပွဲ ယဉ်ကျေးမှု)၊ balanced diet (အာဟာရမျှတသော အစားအစာ)။",
        "passage": [
          { "en": "Hello everyone! Welcome to my blog. In this blog, I share my experiences as a mum.", "mm": "အားလုံးပဲ မင်္ဂလာပါရှင်! ကျွန်မရဲ့ ဘလော့ဂ်ကနေ ကြိုဆိုပါတယ်။ ဒီဘလော့ဂ်မှာ မိခင်တစ်ယောက်အနေနဲ့ ကျွန်မရဲ့ အတွေ့အကြုံလေးတွေကို ဝေမျှပေးသွားမှာပါ။" },
          { "en": "I believe that doing some activities together as a whole family brings some benefits to our children such as developing a sense of responsibility and unity, developing life skills, etc.", "mm": "မိသားစုတစ်စုလုံး အတူတကွ လှုပ်ရှားမှုတွေ လုပ်ဆောင်ခြင်းဟာ ကလေးတွေအတွက် တာဝန်ယူစိတ်နဲ့ စည်းလုံးညီညွတ်မှု တိုးပွားစေခြင်း၊ ဘဝတွက်တာ ကျွမ်းကျင်မှုတွေ ဖွံ့ဖြိုးစေခြင်း စတဲ့ အကျိုးကျေးဇူးတွေ ရရှိစေတယ်လို့ ကျွန်မ ယုံကြည်ပါတယ်။" },
          { "en": "This week, I am going to share some of the routine activities of my family.", "mm": "ဒီတစ်ပတ်မှာတော့ ကျွန်မတို့ မိသားစုရဲ့ ပုံမှန်လုပ်ဆောင်နေကျ အလေ့အကျင့်တချို့ကို ဝေမျှပေးချင်ပါတယ်။" },
          { "en": "In my family, we have dinner together every day. Having meals together, I can remind my children to eat a variety of food. Thus, they become aware of the importance of having a balanced diet. They can also learn table manners occasionally.", "mm": "ကျွန်မတို့ မိသားစုမှာ နေ့တိုင်း ညစာကို အတူတကွ စားသုံးကြပါတယ်။ ထမင်းအတူစားခြင်းအားဖြင့် ကလေးတွေကို အစားအစာ စုံလင်အောင်စားဖို့ သတိပေးနိုင်ပါတယ်။ ဒါကြောင့် သူတို့ဟာ အာဟာရမျှတတဲ့ အစားအသောက်ရဲ့ အရေးပါပုံကို သိရှိလာကြပြီး ထမင်းစားပွဲ ယဉ်ကျေးမှုတွေကိုလည်း တစ်ခါတစ်ရံ သင်ယူနိုင်ကြပါတယ်။" },
          { "en": "Every Saturday, we spend time together at home, and we share the household chores like cleaning the windows, sweeping the floor and doing the dishes. In this way, my children become more responsible and cooperative.", "mm": "စနေနေ့တိုင်း အိမ်မှာ အတူတူအချိန်ဖြုန်းကြပြီး ပြတင်းပေါက်သန့်ရှင်းရေးလုပ်တာ၊ ကြမ်းလှဲတာနဲ့ ပန်းကန်ဆေးတာလို အိမ်မှုကိစ္စတွေကို ခွဲဝေလုပ်ဆောင်ကြပါတယ်။ ဒီနည်းအားဖြင့် ကလေးတွေဟာ ပိုပြီး တာဝန်သိတတ်ပြီး ပူးပေါင်းဆောင်ရွက်တတ်လာကြပါတယ်။" },
          { "en": "On Sundays, we usually engage in outdoor activities like jogging or cycling in the park, and sometimes we do indoor activities, especially when it rains. As a result, my children enjoy doing physical exercise and later realise its value.", "mm": "တနင်္ဂနွေနေ့တွေမှာတော့ ပန်းခြံထဲမှာ အပြေးလေ့ကျင့်တာ ဒါမှမဟုတ် စက်ဘီးစီးတာလို ပြင်ပလှုပ်ရှားမှုတွေကို လုပ်ဆောင်လေ့ရှိပြီး အထူးသဖြင့် မိုးရွာတဲ့အခါမျိုးမှာ အိမ်တွင်းလှုပ်ရှားမှုတွေ လုပ်ကြပါတယ်။ ရလဒ်အနေနဲ့ ကလေးတွေဟာ ကိုယ်လက်လှုပ်ရှား အားကစားလုပ်ရတာကို နှစ်သက်လာပြီး နောက်ပိုင်းမှာ သူ့ရဲ့တန်ဖိုးကို နားလည်လာကြပါတယ်။" },
          { "en": "My family has settled into these regular routines. I don't think it is difficult for your family to get into these routines. I hope you will find them beneficial to your family. Why don't you try them out?", "mm": "ကျွန်မတို့ မိသားစုဟာ ဒီပုံမှန်အလေ့အကျင့်တွေမှာ အသားကျနေပါပြီ။ သင့်မိသားစုအတွက်လည်း ဒီအလေ့အကျင့်တွေ လုပ်ဆောင်ဖို့ မခက်ခဲဘူးလို့ ထင်ပါတယ်။ သင့်မိသားစုအတွက် အကျိုးရှိမယ်လို့ မျှော်လင့်ပါတယ်။ စမ်းလုပ်ကြည့်ပါလားရှင်?" }
        ]
      },
      {
        "label": "Lesson 3",
        "title": "Lesson 3: Busy dad! (Adverbs of Frequency)",
        "note": "💡 သဒ္ဒါမှတ်စု: Adverbs of indefinite frequency (always, usually, often, frequently, sometimes, occasionally, rarely, hardly ever, never) တို့ကို Main Verb ရဲ့ အရှေ့နဲ့ 'be' (am/is/are) ရဲ့ အနောက်မှာ ထားရပါတယ်။",
        "passage": [
          { "en": "It is a big challenge for my dad to bring me up as a single father. He is always busy with his office work and household chores.", "mm": "တစ်ကိုယ်တည်းဖခင်တစ်ယောက်အနေနဲ့ ကျွန်တော့်ကို ပြုစုပျိုးထောင်ရတာ အဖေ့အတွက် ကြီးမားတဲ့ စိန်ခေါ်မှုတစ်ခုပါ။ သူဟာ ရုံးအလုပ်တွေနဲ့ အိမ်မှုကိစ္စတွေကြောင့် အမြဲတမ်း အလုပ်ရှုပ်နေပါတယ်။" },
          { "en": "The busiest time of the day for him is the morning. He usually gets up at five o'clock in the morning, and prepares meals for the two of us.", "mm": "သူ့အတွက် တစ်နေ့တာရဲ့ အလုပ်အရှုပ်ဆုံးအချိန်က မနက်ခင်းပါပဲ။ သူဟာ မနက် ၅ နာရီမှာ အိပ်ရာထလေ့ရှိပြီး ကျွန်တော်တို့ နှစ်ယောက်အတွက် အစားအသောက် ပြင်ဆင်ပေးပါတယ်။" },
          { "en": "He starts his day with a cup of coffee. He often skips his breakfast. However, he boils an egg for me, so I can usually have bread and butter with a boiled egg, and coffee for breakfast.", "mm": "သူ့ရဲ့တစ်နေ့တာကို ကော်ဖီတစ်ခွက်နဲ့ စတင်ပါတယ်။ သူက မနက်စာကို မကြာခဏ မစားဘဲ ကျော်သွားလေ့ရှိပါတယ်။ ဒါပေမဲ့ ကျွန်တော့်အတွက် ကြက်ဥပြုတ်ပေးတာမို့ မနက်စာကို ပေါင်မုန့်ထောပတ်၊ ကြက်ဥပြုတ်နဲ့ ကော်ဖီ သောက်ရလေ့ရှိပါတယ်။" },
          { "en": "As he doesn't have much time in the mornings, he frequently packs our lunch boxes with rice, thin slices of boiled meat and ketchup. He fries fish occasionally. He hardly ever cooks meat with vegetables for lunch.", "mm": "မနက်ပိုင်းမှာ အချိန်သိပ်မရတာကြောင့် ထမင်းဘူးထဲကို ထမင်း၊ အသားပြုတ်ပါးပါးလှီးထားတာနဲ့ ခရမ်းချဉ်သီးဆော့စ်တို့ကို မကြာခဏ ထည့်ပေးပါတယ်။ တစ်ခါတစ်ရံ ငါးကြော်ပေးတတ်ပေမဲ့ နေ့လယ်စာအတွက် အသားနဲ့ ဟင်းသီးဟင်းရွက်ရောချက်တာမျိုးတော့ လုပ်ခဲပါတယ်။" },
          { "en": "As soon as the lunch boxes are ready, he works out for a few minutes. Then, he takes a quick shower and gets ready for work. We leave home at a quarter past eight every morning. He always takes me to school on his electric bike first and then, he heads to his office.", "mm": "ထမင်းဘူးတွေ အဆင်သင့်ဖြစ်တာနဲ့ မိနစ်အနည်းငယ် ကိုယ်လက်လှုပ်ရှား လေ့ကျင့်ခန်းလုပ်ပါတယ်။ ပြီးရင် ရေမြန်မြန်ချိုးပြီး အလုပ်သွားဖို့ ပြင်ဆင်ပါတယ်။ မနက်တိုင်း ၈ နာရီ ၁၅ မိနစ်မှာ အိမ်ကထွက်ကြပြီး အဖေက ကျွန်တော့်ကို လျှပ်စစ်စက်ဘီးနဲ့ ကျောင်းအရင်လိုက်ပို့ပြီးမှ သူ့ရုံးကို သွားပါတယ်။" }
        ]
      },
      {
        "label": "Lesson 4",
        "title": "Lesson 4: A day-to-day work routine (Daw Cho Cho)",
        "note": "💡 စာရေးနည်းမှတ်စု: နေ့စဉ်ပုံမှန်လုပ်ဆောင်ချက် (Daily Work Routine) များကို ရေးသားရာတွင် Present Simple Tense နှင့် အချိန်ပြစကားလုံးများ (at 9:00 a.m., after 10:00 a.m., then) ကို အစဉ်လိုက် အသုံးပြုရပါသည်။",
        "passage": [
          { "en": "Daw Cho Cho is a civil engineer working on a construction site. She works from 9:00 a.m. to 5:00 p.m. on weekdays.", "mm": "ဒေါ်ချိုချိုဟာ ဆောက်လုပ်ရေးလုပ်ငန်းခွင်တစ်ခုမှာ အလုပ်လုပ်နေတဲ့ မြို့ပြအင်ဂျင်နီယာတစ်ဦး ဖြစ်ပါတယ်။ သူမဟာ ရုံးဖွင့်ရက်တွေမှာ မနက် ၉ နာရီကနေ ညနေ ၅ နာရီအထိ အလုပ်လုပ်ပါတယ်။" },
          { "en": "Every day, Daw Cho Cho gets up early, has breakfast and leaves for work. When she gets to work, she always puts on a safety jacket, boots and a hard hat.", "mm": "နေ့စဉ် ဒေါ်ချိုချိုဟာ စောစောအိပ်ရာထ၊ မနက်စာစားပြီး အလုပ်ကို ထွက်ခွာပါတယ်။ အလုပ်ရောက်တဲ့အခါ အန္တရာယ်ကင်းရှင်းရေး ဂျာကင်၊ လည်ရှည်ဖိနပ်နဲ့ ဦးထုပ်မာတို့ကို အမြဲဝတ်ဆင်ပါတယ်။" },
          { "en": "At 9:00 a.m., she explains the work plan of the day to all the workers and makes sure every worker is wearing their protective clothing.", "mm": "မနက် ၉ နာရီမှာ အလုပ်သမားအားလုံးကို တစ်နေ့တာ အလုပ်အစီအစဉ် ရှင်းပြပြီး အလုပ်သမားတိုင်း အကာအကွယ်ဝတ်စုံ ဝတ်ဆင်ထားခြင်း ရှိမရှိ စစ်ဆေးပါတယ်။" },
          { "en": "After 10:00 a.m., she has a meeting with her office staff to make a work plan for the next day. At 1:00 p.m., they all have a break for lunch, and resume their work at 2:00 p.m.", "mm": "မနက် ၁၀ နာရီကျော်မှာ ရုံးဝန်ထမ်းတွေနဲ့ အစည်းအဝေးလုပ်ပြီး နောက်တစ်နေ့အတွက် အလုပ်အစီအစဉ် ဆွဲကြပါတယ်။ နေ့လယ် ၁ နာရီမှာ ထမင်းစားနားကြပြီး ၂ နာရီမှာ အလုပ်ပြန်စကြပါတယ်။" },
          { "en": "At 3:00 p.m., she goes to the construction site to inspect their work. She always checks the work done at 5:00 p.m., and assigns the workers what to do the next day.", "mm": "ညနေ ၃ နာရီမှာ ဆောက်လုပ်ရေးလုပ်ငန်းခွင်ထဲ သွားရောက်စစ်ဆေးပါတယ်။ ညနေ ၅ နာရီမှာ ပြီးစီးသမျှ အလုပ်တွေကို စစ်ဆေးပြီး နောက်နေ့လုပ်ရမယ့် အလုပ်တွေကို တာဝန်ပေးပါတယ်။" },
          { "en": "She often gets home at 6:00 p.m. She has a shower and enjoys dinner with her family. Then, she does some reading or watches TV and goes to bed.", "mm": "ညနေ ၆ နာရီမှာ အိမ်ပြန်ရောက်လေ့ရှိပြီး ရေချိုးကာ မိသားစုနဲ့ ညစာစားပါတယ်။ အဲဒီနောက် စာဖတ်ခြင်း ဒါမှမဟုတ် တီဗွီကြည့်ခြင်း ပြုလုပ်ပြီး အိပ်ရာဝင်ပါတယ်။" }
        ]
      }
    ],
    "games": [
      { "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (Unit 1 Vocab)", "q": "'digestion' ဆိုတာ မြန်မာလို ဘာကို ဆိုလိုတာလဲ?", "mode": "mcq", "options": ["အဝလွန်ခြင်း", "အစာချေဖျက်ခြင်း", "အစာနင်ခြင်း", "အချိုရည်သောက်ခြင်း"], "ans": 1, "explain": "'digestion' ဆိုတာ စားလိုက်တဲ့ အစားအစာတွေကို ခန္ဓာကိုယ်က အသုံးပြုနိုင်အောင် ချေဖျက်ပေးခြင်း ဖြစ်ပါတယ်။" },
      { "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Grammar: Adverbs)", "q": "'သူသည် မနက် ၅ နာရီတွင် အိပ်ရာထလေ့ရှိသည်' ကို စာကြောင်းစီပါ။", "mode": "scramble", "words": ["He", "usually", "gets", "up", "at", "five", "o'clock."], "explain": "Adverb of frequency (usually) ကို Main verb (gets up) ရဲ့ အရှေ့မှာ ထားရပါတယ်။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Unit 1 Grammar)", "q": "Thuzar is very punctual. She is _____ late for class.", "mode": "mcq", "options": ["always", "never", "often", "usually"], "ans": 1, "explain": "အချိန်တိကျသူ (punctual) ဖြစ်တဲ့အတွက် အတန်းနောက်ကျလေ့ လုံးဝမရှိပါဘူး ('never')။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Definite Frequency)", "q": "Take this medicine _____ four hours.", "mode": "mcq", "options": ["every", "once", "twice", "always"], "ans": 0, "explain": "'every four hours' (၄ နာရီခြား တစ်ကြိမ်) လို့ သုံးရပါတယ်။" },
      { "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Lesson 1 & 2 Check)", "q": "လရောင် (La Yaung) ရဲ့ အမေက ဧည့်ခန်းထဲမှာ တီဗွီကြည့်ရင်း ထမင်းစားခွင့် ပေးထားပါတယ်။", "mode": "mcq", "options": ["မှန်တယ် (True)", "မှားတယ် (False)"], "ans": 1, "explain": "မှားပါတယ်! အစာနင်မှာ (choke) စိုးလို့ အမေက ခွင့်မပြုဘဲ ထမင်းစားပွဲမှာပဲ စားခိုင်းပါတယ်။" }
    ]
  },
  {
    "title": "Unit 2: At School & My Schooldays (ကျောင်းတော်ကြီးနှင့် ကျောင်းသားဘဝ)",
    "sections": [
      {
        "label": "Lesson 1",
        "title": "Lesson 1: At a new school (Thinzar & Sandi Dialogue)",
        "note": "💡 စကားပြောမှတ်စု: ကျောင်းအသစ်ရောက်လာသော ကျောင်းသူ သဉ္ဇာ (Thinzar) နှင့် အတန်းဖော် စန္ဒီ (Sandi) တို့ ကျောင်းအကြောင်း မေးမြန်းဖြေကြားပုံ စကားပြောခန်း ဖြစ်ပါသည်။",
        "passage": [
          { "en": "Thinzar: Good morning.", "mm": "သဉ္ဇာ: မင်္ဂလာနံနက်ခင်းပါ။" },
          { "en": "Sandi: Good morning. I'm Sandi. Are you a new student?", "mm": "စန္ဒီ: မင်္ဂလာနံနက်ခင်းပါ။ ငါ့နာမည် စန္ဒီပါ။ နင်က ကျောင်းသူအသစ်လား?" },
          { "en": "Thinzar: Yes, I am. I'm Thinzar. Can I ask you some questions?", "mm": "သဉ္ဇာ: ဟုတ်ပါတယ်။ ငါ့နာမည် သဉ္ဇာပါ။ နင့်ကို မေးခွန်းနည်းနည်းလောက် မေးလို့ရမလား?" },
          { "en": "Sandi: Sure. Go ahead.", "mm": "စန္ဒီ: ရတာပေါ့။ မေးပါ။" },
          { "en": "Thinzar: What's the name of our principal?", "mm": "သဉ္ဇာ: တို့ကျောင်းအုပ်ဆရာမကြီး နာမည်က ဘယ်သူလဲဟင်?" },
          { "en": "Sandi: Daw Thet Mon.", "mm": "စန္ဒီ: ဒေါ်သက်မွန်ပါ။" },
          { "en": "Thinzar: What are the school hours?", "mm": "သဉ္ဇာ: ကျောင်းတက်ချိန်၊ ကျောင်းဆင်းချိန်တွေက ဘယ်အချိန်တွေလဲ?" },
          { "en": "Sandi: The school starts at 8 a.m. and is over at 3 p.m. And the lunch break is from 11 to 11:30.", "mm": "စန္ဒီ: ကျောင်းက မနက် ၈ နာရီမှာ စတက်ပြီး ညနေ ၃ နာရီမှာ ဆင်းပါတယ်။ ထမင်းစားဆင်းချိန်ကတော့ ၁၁ နာရီကနေ ၁၁ နာရီခွဲအထိပါ။" },
          { "en": "Thinzar: Is there a library?", "mm": "သဉ္ဇာ: ကျောင်းမှာ စာကြည့်တိုက် ရှိလားဟင်?" },
          { "en": "Sandi: Yes. You can read newspapers, journals and books there.", "mm": "စန္ဒီ: ရှိပါတယ်။ အဲဒီမှာ သတင်းစာတွေ၊ ဂျာနယ်တွေနဲ့ စာအုပ်တွေ ဖတ်လို့ရတယ်။" },
          { "en": "Thinzar: Can you tell me some important school rules?", "mm": "သဉ္ဇာ: အရေးကြီးတဲ့ ကျောင်းစည်းကမ်းတချို့ကို ပြောပြပေးနိုင်မလား?" },
          { "en": "Sandi: Certainly. We must attend school regularly. We mustn't be late for school. And we mustn't bring large sums of money.", "mm": "စန္ဒီ: ပြောပြနိုင်တာပေါ့။ ကျောင်းကို မှန်မှန်တက်ရမယ်။ ကျောင်းနောက်မကျရဘူး။ ပြီးတော့ ပိုက်ဆံအများကြီး ယူမလာရဘူး။" },
          { "en": "Thinzar: Can I bring my mobile phone to school?", "mm": "သဉ္ဇာ: ကျောင်းကို မိုဘိုင်းဖုန်း ယူလာလို့ရလား?" },
          { "en": "Sandi: No, you can't bring valuable things to school.", "mm": "စန္ဒီ: မရဘူး၊ ကျောင်းကို တန်ဖိုးကြီးပစ္စည်းတွေ ယူမလာရဘူး။" },
          { "en": "Thinzar: What do you like most about the school?", "mm": "သဉ္ဇာ: ဒီကျောင်းမှာ နင် အကြိုက်ဆုံးက ဘာလဲဟင်?" },
          { "en": "Sandi: School activities. I enjoy doing them.", "mm": "စန္ဒီ: ကျောင်းလှုပ်ရှားမှုတွေပါ။ အဲဒါတွေ လုပ်ရတာကို ငါ အရမ်းနှစ်သက်တယ်။" }
        ]
      },
      {
        "label": "Lesson 2",
        "title": "Lesson 2: My Schooldays (Paragraphs A, B, C)",
        "note": "💡 ကျောင်းအမျိုးအစားများ: government school (အစိုးရကျောင်း)၊ private school (ပုဂ္ဂလိကကျောင်း)၊ all-girls school (မိန်းကလေးသီးသန့်ကျောင်း)၊ monastic school (ဘုန်းတော်ကြီးသင်ကျောင်း)၊ mixed school (ကျား/မ တွဲဖက်ကျောင်း)။",
        "passage": [
          { "en": "A. Schooldays play an important part in our lives. When we reach school age, our parents send us to school: a government school, a private school or a monastic school. At school, we learn from our teachers. We make friends in our class and learn together. The people we meet at school and the skills we learn there shape our lives.", "mm": "A. ကျောင်းသားဘဝနေ့ရက်တွေဟာ ကျွန်ုပ်တို့ဘဝမှာ အရေးပါတဲ့ အခန်းကဏ္ဍကနေ ပါဝင်ပါတယ်။ ကျောင်းနေအရွယ် ရောက်တဲ့အခါ မိဘတွေက အစိုးရကျောင်း၊ ပုဂ္ဂလိကကျောင်း ဒါမှမဟုတ် ဘုန်းတော်ကြီးသင်ကျောင်းကို ပို့ပေးကြပါတယ်။ ကျောင်းမှာ ဆရာဆရာမတွေဆီက ပညာသင်ယူကြပြီး သူငယ်ချင်းတွေနဲ့ အတူတူ လေ့လာကြပါတယ်။ ကျောင်းမှာ တွေ့ဆုံရတဲ့သူတွေနဲ့ သင်ယူရတဲ့ ကျွမ်းကျင်မှုတွေက ကျွန်ုပ်တို့ဘဝကို ပုံဖော်ပေးပါတယ်။" },
          { "en": "B. My primary school life began when I was five. It was a mixed school which was just around the corner of our street. It was a good school and the teachers were rather strict. We started to develop fundamental skills: reading, writing and mathematics. These skills formed a solid foundation of learning.", "mm": "B. ကျွန်မရဲ့ မူလတန်းကျောင်းသားဘဝကို အသက် ၅ နှစ်အရွယ်မှာ စတင်ခဲ့ပါတယ်။ အဲဒါက လမ်းထောင့်နားလေးမှာပဲရှိတဲ့ ကျား/မ တွဲဖက်ကျောင်းလေးပါ။ ကျောင်းကောင်းတစ်ကျောင်းဖြစ်ပြီး ဆရာဆရာမတွေက အတော်လေး စည်းကမ်းတင်းကျပ်ပါတယ်။ စာဖတ်ခြင်း၊ စာရေးခြင်းနဲ့ သင်္ချာစတဲ့ အခြေခံကျွမ်းကျင်မှုတွေကို စတင်သင်ယူခဲ့ပြီး အဲဒါတွေက ပညာသင်ယူမှုအတွက် ခိုင်မာတဲ့ အုတ်မြစ်ဖြစ်ခဲ့ပါတယ်။" },
          { "en": "My favourite teacher was my Grade 4 class teacher. She was a great teacher. She was aware of the strengths and weaknesses of her students. And she always encouraged us to improve ourselves. Because of her encouragement, I won a prize in an essay competition. As a result, learning at school became a joy for me. I always remember her as an inspiring teacher.", "mm": "ကျွန်မ အနှစ်သက်ဆုံးဆရာမကတော့ Grade 4 အတန်းပိုင်ဆရာမပါပဲ။ သူမဟာ တကယ်တော်တဲ့ ဆရာမတစ်ဦးဖြစ်ပြီး ကျောင်းသူတွေရဲ့ အားသာချက်၊ အားနည်းချက်တွေကို သိရှိနားလည်ပါတယ်။ ကိုယ့်ကိုယ်ကို တိုးတက်အောင်လည်း အမြဲအားပေးခဲ့လို့ သူမရဲ့ အားပေးမှုကြောင့် စာစီစာကုံးပြိုင်ပွဲမှာ ဆုရခဲ့ပါတယ်။ ရလဒ်အနေနဲ့ ကျောင်းမှာ စာသင်ရတာ ပျော်ရွှင်စရာဖြစ်လာပြီး သူမကို စိတ်ဓာတ်ခွန်အားပေးတဲ့ ဆရာမအဖြစ် အမြဲသတိရနေပါတယ်။" },
          { "en": "C. For my secondary education, my father sent me to an all-girls high school. It was quite a big school in a large compound. All the teachers were good at teaching and dedicated to their work. My ideal teacher was our Grade 7 maths teacher. Her teaching was excellent. When teaching a new concept, she gave a simple example and explained step by step. She always made us do a lot of homework and gave us feedback. She looked stern but she never lost her temper with us. She was a truly dedicated teacher.", "mm": "C. အလယ်တန်းနဲ့ အထက်တန်းပညာရေးအတွက် အဖေက မိန်းကလေးသီးသန့် အထက်တန်းကျောင်းကို ပို့ပေးခဲ့ပါတယ်။ ကျောင်းဝင်းကျယ်ကြီးထဲမှာရှိတဲ့ ကျောင်းကြီးတစ်ကျောင်းပါ။ ဆရာမအားလုံး စာသင်ကောင်းကြပြီး အလုပ်အပေါ် စိတ်ရောကိုယ်ပါ နှစ်မြှုပ်ထားကြပါတယ်။ ကျွန်မရဲ့ စံပြဆရာမကတော့ Grade 7 သင်္ချာဆရာမပါ။ သင်ခန်းစာအသစ် သင်တိုင်း ရိုးရှင်းတဲ့ ဥပမာလေးတွေပေးပြီး တစ်ဆင့်ချင်း ရှင်းပြပါတယ်။ အိမ်စာတွေ အများကြီးပေးပြီး ပြန်စစ်ပေးလေ့ရှိပါတယ်။ ရုပ်တည်ပေမဲ့ ကျွန်မတို့ကို ဘယ်တော့မှ ဒေါသမထွက်တတ်ပါဘူး။ တကယ့်ကို စေတနာထားတဲ့ ဆရာမတစ်ဦးပါ။" },
          { "en": "We also went on school trips to interesting places such as the National Museum and People's Park. These trips gave us memorable experiences. We gained knowledge and skills, and we developed physically, mentally and emotionally. My schooldays were the happiest days in my life!", "mm": "ကျွန်မတို့ဟာ အမျိုးသားပြတိုက်နဲ့ ပြည်သူ့ဥယျာဉ်လို စိတ်ဝင်စားစရာနေရာတွေကို ကျောင်းလေ့လာရေးခရီးတွေလည်း ထွက်ခဲ့ကြပါတယ်။ အဲဒီခရီးစဉ်တွေက အမှတ်တရ အတွေ့အကြုံတွေ ပေးစွမ်းခဲ့ပါတယ်။ ဗဟုသုတနဲ့ ကျွမ်းကျင်မှုတွေ ရရှိခဲ့ပြီး ကိုယ်ကာယပိုင်း၊ စိတ်ပိုင်းနဲ့ ခံစားချက်ပိုင်းတွေပါ ဖွံ့ဖြိုးတိုးတက်လာခဲ့ပါတယ်။ ကျွန်မရဲ့ ကျောင်းသားဘဝနေ့ရက်တွေဟာ ဘဝမှာ အပျော်ရွှင်ရဆုံး နေ့ရက်တွေ ဖြစ်ခဲ့ပါတယ်!" }
        ]
      },
      {
        "label": "Lesson 3 & 4",
        "title": "Lesson 3 & 4: Subject/Object Questions & School Pamphlet",
        "note": "💡 သဒ္ဒါမှတ်စု: Subject Question တွင် ပြုလုပ်သူကို မေးသောကြောင့် Who/What နောက်တွင် Verb တိုက်ရိုက်လိုက်သည် (ဥပမာ - Who teaches you English?)။ Object Question တွင် အကူကြိယာ (do/does/did) ခံရသည် (ဥပမာ - What does Daw Thida teach you?)။",
        "passage": [
          { "en": "Subject Question Example: Who teaches you English? — Daw Thida teaches us English.", "mm": "Subject Question ဥပမာ: ဘယ်သူ သင့်ကို အင်္ဂလိပ်စာ သင်ပေးသလဲ? — ဒေါ်သီတာက ကျွန်ုပ်တို့ကို အင်္ဂလိပ်စာ သင်ပေးပါတယ်။" },
          { "en": "Object Question Example: What did Alexander Fleming discover in 1928? — Penicillin.", "mm": "Object Question ဥပမာ: ၁၉၂၈ ခုနှစ်မှာ အလက်ဇန္ဒား ဖလင်းမင်းက ဘာကို ရှာဖွေတွေ့ရှိခဲ့သလဲ? — ပင်နီဆီလင်ဆေးဝါး ဖြစ်ပါတယ်။" },
          { "en": "Basic Education High School Myothit was established in 1970 and is located at No. 10, Main Road.", "mm": "မြို့သစ် အခြေခံပညာ အထက်တန်းကျောင်းကို ၁၉၇၀ ခုနှစ်တွင် တည်ထောင်ခဲ့ပြီး အမှတ် ၁၀၊ လမ်းမကြီးတွင် တည်ရှိပါသည်။" },
          { "en": "There are 40 teachers and 1,200 students in our school. There is a multi-purpose hall, a library, a science lab, a playground, a canteen, two car parks and a bicycle rack.", "mm": "ကျွန်ုပ်တို့ကျောင်းတွင် ဆရာ ၄၀ ဦးနှင့် ကျောင်းသား ၁,၂၀၀ ဦး ရှိပါသည်။ ဘက်စုံသုံးခန်းမ၊ စာကြည့်တိုက်၊ သိပ္ပံဓာတ်ခွဲခန်း၊ ကစားကွင်း၊ မုန့်ဈေးတန်း၊ ကားရပ်နားရာနေရာ နှစ်ခုနှင့် စက်ဘီးထားရာနေရာတို့ ရှိပါသည်။" },
          { "en": "Extra-curricular activities include essay competitions, impromptu talk competitions, school sports, scouting, school trips, basic computer course, first aid training course, school concert and school band.", "mm": "ကျောင်းပြင်ပလှုပ်ရှားမှုများတွင် စာစီစာကုံးပြိုင်ပွဲ၊ ကျပန်းစကားပြောပြိုင်ပွဲ၊ ကျောင်းအားကစား၊ ကင်းထောက်၊ လေ့လာရေးခရီး၊ အခြေခံကွန်ပျူတာသင်တန်း၊ ရှေးဦးသူနာပြုသင်တန်း၊ ကျောင်းကပွဲနှင့် ကျောင်းဘင်ခရာတီးဝိုင်းတို့ ပါဝင်ပါသည်။" }
        ]
      }
    ],
    "games": [
      { "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (Types of Schools)", "q": "ဘုန်းတော်ကြီးကျောင်းမှ ဖွင့်လှစ်သင်ကြားသော ကျောင်းကို အင်္ဂလိပ်လို ဘယ်လိုခေါ်လဲ?", "mode": "mcq", "options": ["government school", "private school", "monastic school", "mixed school"], "ans": 2, "explain": "'monastic school' ဆိုတာ ဘုန်းတော်ကြီးသင်ပညာရေးကျောင်း ဖြစ်ပါတယ်။" },
      { "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Grammar: There is/are)", "q": "'ကျွန်ုပ်တို့ကျောင်းတွင် ဆရာ ၄၀ နှင့် ကျောင်းသား ၁၂၀၀ ရှိသည်' ကို စီပါ။", "mode": "scramble", "words": ["There", "are", "40", "teachers", "and", "1,200", "students."], "explain": "အများကိန်း (40 teachers) ဖြစ်တဲ့အတွက် 'There are' ကို သုံးရပါတယ်။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Subject vs Object Question)", "q": "_____ the play Romeo and Juliet? — William Shakespeare.", "mode": "mcq", "options": ["Who wrote", "Who did write", "What wrote", "Who write"], "ans": 0, "explain": "Subject Question ဖြစ်လို့ 'Who + Verb (wrote)' တိုက်ရိုက်သုံးရပါတယ်။ (Review 1 / Lesson 3)" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Vocabulary)", "q": "We can _____ books from the school library if we have a library card.", "mode": "mcq", "options": ["lend", "borrow", "include", "attend"], "ans": 1, "explain": "စာကြည့်တိုက်မှ စာအုပ်ငှားယူခြင်းကို 'borrow' လို့ သုံးပါတယ်။" },
      { "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Lesson 2 Check)", "q": "စာရေးသူရဲ့ Grade 7 သင်္ချာဆရာမဟာ ရုပ်တည်ပေမဲ့ ကျောင်းသူတွေကို ဘယ်တော့မှ ဒေါသမထွက်တတ်ပါဘူး။", "mode": "mcq", "options": ["မှန်တယ် (True)", "မှားတယ် (False)"], "ans": 0, "explain": "မှန်ပါတယ်! 'She looked stern but she never lost her temper with us' လို့ ဖော်ပြထားပါတယ်။" }
    ]
  },
  {
    "title": "Unit 3: Extra-curricular Activities & School Band (ကျောင်းပြင်ပလှုပ်ရှားမှုများ)",
    "sections": [
      {
        "label": "Lesson 1",
        "title": "Lesson 1: Which activity do you like doing most? (Thandar & Marlar)",
        "note": "💡 Borrow vs Lend: Borrow = သူများဆီက ခဏယူသုံးသည် (May I borrow your pen?)။ Lend = ကိုယ်က သူများကို ပေးငှားသည် (Can you lend me your paintbrush?)။",
        "passage": [
          { "en": "Thandar: Hi, Marlar. Last week, our instructor told us to knit a hat for homework. Have you finished it?", "mm": "သန္တာ: ဟိုင်း မာလာ။ ပြီးခဲ့တဲ့အပတ်က တို့နည်းပြဆရာမက အိမ်စာအဖြစ် ဦးထုပ်တစ်လုံး ထိုးခိုင်းထားတာ ပြီးသွားပြီလား?" },
          { "en": "Marlar: Yes, I have. The homework was rather difficult, but I found it quite interesting. What do you think of our knitting class?", "mm": "မာလာ: ပြီးသွားပါပြီ။ အိမ်စာက နည်းနည်းခက်ပေမဲ့ အတော်လေး စိတ်ဝင်စားဖို့ ကောင်းတယ်။ တို့ရဲ့ သိုးမွှေးထိုးသင်တန်းကို ဘယ်လိုမြင်လဲ?" },
          { "en": "Thandar: Great. I really enjoy knitting. It's relaxing. Now I can make a woollen hat myself.", "mm": "သန္တာ: အရမ်းကောင်းတယ်။ သိုးမွှေးထိုးရတာ စိတ်အပန်းပြေလို့ ငါ အရမ်းသဘောကျတယ်။ အခု ကိုယ်တိုင် သိုးမွှေးဦးထုပ် ထိုးတတ်နေပြီ။" },
          { "en": "Marlar: So can I! My mum said that my hat is really beautiful.", "mm": "မာလာ: ငါလည်း ထိုးတတ်နေပြီ! ငါထိုးထားတဲ့ ဦးထုပ်လေးက အရမ်းလှတယ်လို့ အမေက ပြောတယ်။" },
          { "en": "Thandar: By the way, are you going to the knitting class today?", "mm": "သန္တာ: စကားမစပ် ဒီနေ့ သိုးမွှေးထိုးသင်တန်း သွားမှာလား?" },
          { "en": "Marlar: Yes, of course, but I forgot to bring my toolkit.", "mm": "မာလာ: သွားမှာပေါ့၊ ဒါပေမဲ့ ငါ့ရဲ့ ကိရိယာအိတ် ယူလာဖို့ မေ့သွားတယ်။" },
          { "en": "Thandar: Don't worry. I have extra needles. I'll lend you a pair.", "mm": "သန္တာ: စိတ်မပူပါနဲ့။ ငါ့မှာ အပ်အပို တစ်စုံပါတယ်။ နင့်ကို ငှားပေးမယ်လေ။" },
          { "en": "Marlar: That's very kind of you. Can I borrow some wool yarns too?", "mm": "မာလာ: ကျေးဇူးအရမ်းတင်ပါတယ်ဟာ။ သိုးမွှေးချည်ခင်လေး နည်းနည်းလောက်လည်း ငှားလို့ရမလား?" },
          { "en": "Thandar: Why not? Red, blue, yellow or green?", "mm": "သန္တာ: ရတာပေါ့။ အနီ၊ အပြာ၊ အဝါ ဒါမှမဟုတ် အစိမ်း ဘာအရောင်ယူမလဲ?" },
          { "en": "Marlar: Blue and green, please. Thank you so much. — Thandar: It's my pleasure.", "mm": "မာလာ: အပြာနဲ့ အစိမ်း ပေးပါနော်။ ကျေးဇူးအများကြီးတင်ပါတယ်။ — သန္တာ: ရပါတယ် ဝမ်းသာပါတယ်။" }
        ]
      },
      {
        "label": "Lesson 2",
        "title": "Lesson 2: I love knitting (Yin Moe, Ei Khine, Aung Ko, Min Khant)",
        "note": "💡 ဝေါဟာရမှတ်စု: boost creativity (တီထွင်ဖန်တီးနိုင်စွမ်း မြှင့်တင်သည်)၊ orchestra (သံစုံတီးဝိုင်း)၊ martial art (ကိုယ်ခံပညာ)၊ stamina (သက်လုံကောင်းမှု)။",
        "passage": [
          { "en": "Yin Moe: I practise knitting every day after school. Now I can make my own hats and gloves. My mum is very fond of knitting and she bought me a new toolkit, which includes needles and some colourful yarns. I usually knit for relaxation. It helps to reduce stress and boost creativity. My friends tell me that I am a better knitter than anyone else in my school. I hope that sooner or later I will be able to knit different items of clothing such as shawls, socks and sweaters.", "mm": "ယဉ်မိုး: ကျွန်မ ကျောင်းဆင်းပြီးတိုင်း နေ့စဉ် သိုးမွှေးထိုးလေ့ကျင့်ပါတယ်။ အခု ကိုယ်ပိုင်ဦးထုပ်နဲ့ လက်အိတ်တွေ ထိုးတတ်နေပါပြီ။ အမေက သိုးမွှေးထိုးတာ ဝါသနာပါလို့ အပ်တွေနဲ့ ရောင်စုံသိုးမွှေးချည်တွေပါတဲ့ ကိရိယာအိတ်အသစ် ဝယ်ပေးထားပါတယ်။ စိတ်အပန်းဖြေဖို့ ထိုးလေ့ရှိပြီး စိတ်ဖိစီးမှုလျှော့ချပေးကာ တီထွင်ဖန်တီးနိုင်စွမ်းကို မြှင့်တင်ပေးပါတယ်။ မကြာခင် ပဝါတွေ၊ ခြေအိတ်တွေနဲ့ ဆွယ်တာအင်္ကျီတွေပါ ထိုးနိုင်ဖို့ မျှော်လင့်ပါတယ်။" },
          { "en": "Ei Khine: I practise the violin every day after school. Now, I can read music notes and play some beautiful songs. My dad gave me a new violin as a birthday present. The violin has four strings and we play it with a bow to make music. It is part of an orchestra and I love its beautiful melody. Playing the violin helps to improve our memory and social skills. I wish to be a professional violinist when I grow up.", "mm": "အိခိုင်: ကျွန်မ ကျောင်းဆင်းပြီးတိုင်း နေ့စဉ် တယောထိုးလေ့ကျင့်ပါတယ်။ အခု ဂီတသင်္ကေတ (Notes) တွေ ဖတ်တတ်ပြီး သီချင်းလှလှလေးတွေ တီးတတ်နေပါပြီ။ အဖေက မွေးနေ့လက်ဆောင်အဖြစ် တယောအသစ် ပေးထားပါတယ်။ တယောမှာ ကြိုး ၄ ချောင်းပါပြီး တယောထိုးတံနဲ့ တီးရပါတယ်။ တယောထိုးခြင်းက မှတ်ဉာဏ်နဲ့ လူမှုဆက်ဆံရေးစွမ်းရည်ကို တိုးတက်စေပြီး ကြီးလာရင် ကျွမ်းကျင်တယောပညာရှင် ဖြစ်ချင်ပါတယ်။" },
          { "en": "Aung Ko: I practise karate in the school playground every weekend. Karate is a martial art using moves, punches and kicks. I practise it for reasons of self-defence and health. Doing karate helps to strengthen muscles and build up stamina. My friends tell me I can do karate better than anyone else in my school. I want to be a champion when I grow up.", "mm": "အောင်ကို: ကျွန်တော် အပတ်စဉ်တိုင်း ကျောင်းကစားကွင်းထဲမှာ ကရာတေး လေ့ကျင့်ပါတယ်။ ကရာတေးဟာ လှုပ်ရှားမှုတွေ၊ လက်သီးထိုးချက်နဲ့ ခြေကန်ချက်တွေကို အသုံးပြုရတဲ့ ကိုယ်ခံပညာတစ်ခုပါ။ ကိုယ့်ကိုယ်ကို ခုခံကာကွယ်ဖို့နဲ့ ကျန်းမာရေးအတွက် လေ့ကျင့်တာဖြစ်ပြီး ကြွက်သားတွေ သန်မာစေကာ သက်လုံကောင်းစေပါတယ်။ ကြီးလာရင် ချန်ပီယံတစ်ယောက် ဖြစ်ချင်ပါတယ်။" },
          { "en": "Min Khant: I'm a member of the Myanmar Scouts. As a boy scout, I have to attend several training courses. During training, we have to learn some practical skills such as first aid and how to tie basic knots. We usually go camping during school holidays. At nights, we sing and dance happily together around the campfire. Camping trips make us more confident and responsible. Such trips also help to strengthen our friendship.", "mm": "မင်းခန့်: ကျွန်တော်က မြန်မာကင်းထောက်အဖွဲ့ဝင် တစ်ဦးပါ။ ကင်းထောက်တစ်ယောက်အနေနဲ့ သင်တန်းတွေ တက်ရပြီး ရှေးဦးသူနာပြုစုနည်းနဲ့ အခြေခံကြိုးချည်နည်းတွေ သင်ယူရပါတယ်။ ကျောင်းပိတ်ရက်တွေမှာ စခန်းချခရီးထွက်ကြပြီး ညဘက် မီးပုံဘေးမှာ ပျော်ပျော်ရွှင်ရွှင် သီချင်းဆို ကခုန်ကြပါတယ်။ စခန်းချခရီးတွေက ယုံကြည်မှုနဲ့ တာဝန်သိစိတ် ပိုရှိစေပြီး သူငယ်ချင်းသံယောဇဉ်ကိုလည်း ပိုမိုခိုင်မြဲစေပါတယ်။" }
        ]
      },
      {
        "label": "Lesson 3 & 4",
        "title": "Lesson 3 & 4: Requests/Offers & School Band",
        "note": "💡 သဒ္ဒါမှတ်စု: တောင်းဆိုခြင်း (Can/Could/Would you...?)၊ ကမ်းလှမ်းခြင်း (Would you like...? / Shall I...?)၊ ခွင့်တောင်းခြင်း (May I / Can I / Could I...?)။",
        "passage": [
          { "en": "In a school band, there are two groups of musical instruments: wind instruments and percussion instruments.", "mm": "ကျောင်းဘင်ခရာတီးဝိုင်းတစ်ခုမှာ လေမှုတ်တူရိယာ (Wind instruments) နဲ့ တီးခတ်ရသော တူရိယာ (Percussion instruments) ဆိုပြီး ဂီတတူရိယာ အုပ်စု နှစ်စု ရှိပါတယ်။" },
          { "en": "Wind instruments produce music only when air is blown into them. They are made of wood or brass. The flute and the clarinet are usually made of wood, whereas the trumpet, the trombone and the saxophone are made of brass.", "mm": "လေမှုတ်တူရိယာတွေဟာ အထဲကို လေမှုတ်သွင်းလိုက်မှသာ ဂီတသံ ထွက်ပေါ်လာပါတယ်။ သစ်သား ဒါမှမဟုတ် ကြေးဝါနဲ့ ပြုလုပ်ထားပြီး ပလွေ (flute) နဲ့ clarinet တို့ကို သစ်သားနဲ့ လုပ်လေ့ရှိကာ ထရမ်းပက်၊ ထရွမ်ဘုန်းနဲ့ ဆက်ဆိုဖုန်းတို့ကို ကြေးဝါနဲ့ ပြုလုပ်ထားပါတယ်။" },
          { "en": "Percussion instruments produce sounds when they are struck, or beaten. We use a drumstick or a pair to strike the bass drum or the side drum. We hit two of the cymbals together to make a sound.", "mm": "တီးခတ်ရတဲ့ တူရိယာတွေကတော့ ရိုက်ခတ်လိုက်တဲ့အခါ အသံထွက်ပါတယ်။ ဘေ့စ်ဒရမ်နဲ့ ဘေးဒရမ်တွေကို ဒရမ်ရိုက်တံနဲ့ တီးခတ်ရပြီး လင်းကွင်း (cymbals) နှစ်ချပ်ကို အချင်းချင်း ရိုက်ခတ်ပြီး အသံထွက်စေပါတယ်။" },
          { "en": "We hit the triangle with a metal bar to make a sound. We shake or hit the tambourine with hand to produce a sound. The major mace is an important item held by the conductor in a school band.", "mm": "တြိဂံတူရိယာ (triangle) ကို သတ္တုချောင်းနဲ့ ရိုက်ခတ်ရပြီး ချူတပ်ဗုံ (tambourine) ကို လက်နဲ့ လှုပ်ခါခြင်း သို့မဟုတ် ပုတ်ခြင်းဖြင့် အသံထွက်စေပါတယ်။ ကျောင်းဘင်ခရာတီးဝိုင်းမှာ တီးဝိုင်းခေါင်းဆောင် ကိုင်ဆောင်တဲ့ ကြိမ်လုံး (major mace) ဟာ အရေးပါတဲ့ ပစ္စည်းတစ်ခု ဖြစ်ပါတယ်။" },
          { "en": "Note of Request: May May, Could you please stop at the tailor's and collect my school band uniform on your way back home? And would you buy a pair of white socks? I urgently need them for tomorrow's Opening Ceremony of the Township Football Tournament. Love, Tharlay.", "mm": "အကူအညီတောင်းခံစာ: မေမေရေ... အိမ်အပြန်လမ်းမှာ အပ်ချုပ်ဆိုင်ဝင်ပြီး သားရဲ့ ဘင်ခရာတီးဝိုင်း ဝတ်စုံလေး ဝင်ယူပေးပါဦးနော်။ ပြီးတော့ ခြေအိတ်အဖြူ တစ်စုံလည်း ဝယ်ပေးပါဦး။ မနက်ဖြန် မြို့နယ်ဘောလုံးပြိုင်ပွဲ ဖွင့်ပွဲအခမ်းအနားအတွက် အရေးတကြီး လိုအပ်နေလို့ပါ။ ချစ်သား - သားလေး။" }
        ]
      }
    ],
    "games": [
      { "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (Borrow vs Lend)", "q": "သူငယ်ချင်းဆီက ခဲတံခဏ 'ငှားယူချင်တယ်' ဆိုရင် ဘယ်စကားလုံး သုံးရမလဲ?", "mode": "mcq", "options": ["lend", "borrow", "give", "send"], "ans": 1, "explain": "သူများဆီက ခဏယူသုံးတာကို 'borrow' လို့သုံးပြီး၊ ကိုယ်က သူများကို ပေးငှားတာကို 'lend' လို့ သုံးပါတယ်။" },
      { "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Making Requests)", "q": "'ကျေးဇူးပြု၍ ငါ့ကို ဆားကမ်းပေးနိုင်မလား' ကို စာကြောင်းစီပါ။", "mode": "scramble", "words": ["Can", "you", "pass", "me", "the", "salt,", "please?"], "explain": "ယဉ်ကျေးစွာ တောင်းဆိုတဲ့အခါ 'Can you + V-infinitive..., please?' ပုံစံ သုံးရပါတယ်။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Responses to Offers)", "q": "Shall I pay for the drinks? — _____.", "mode": "mcq", "options": ["Yes, you can.", "That's very kind of you.", "Yes, please.", "Sure."], "ans": 1, "explain": "'Shall I...?' နဲ့ ကမ်းလှမ်းတာကို လက်ခံတဲ့အခါ 'That's very kind of you.' လို့ ယဉ်ကျေးစွာ ဖြေရပါတယ်။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (School Band)", "q": "The flute and the clarinet are _____ instruments made of wood.", "mode": "mcq", "options": ["percussion", "wind", "brass", "string"], "ans": 1, "explain": "Flute နဲ့ Clarinet တို့ဟာ လေမှုတ်တူရိယာ (wind instruments) များ ဖြစ်ကြပါတယ်။" },
      { "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Lesson 1 Check)", "q": "မာလာ (Marlar) က သန္တာ့ဆီကနေ အနီရောင်နဲ့ အဝါရောင် သိုးမွှေးချည်ခင်တွေ ငှားခဲ့ပါတယ်။", "mode": "mcq", "options": ["မှန်တယ် (True)", "မှားတယ် (False)"], "ans": 1, "explain": "မှားပါတယ်! မာလာက အပြာရောင်နဲ့ အစိမ်းရောင် ('Blue and green, please') ကို ငှားခဲ့တာပါ။" }
    ]
  },
  {
    "title": "Unit 4: Personality & Global Citizen (ကိုယ်ရည်ကိုယ်သွေးနှင့် ကမ္ဘာ့သားကောင်း)",
    "sections": [
      {
        "label": "Lesson 1 & 2",
        "title": "Lesson 1 & 2: Qualities of a Global Citizen (A, B, C, D)",
        "note": "💡 ဝေါဟာရမှတ်စု: charming (ဆွဲဆောင်မှုရှိသော)၊ disciplined (စည်းကမ်းရှိသော)၊ sensitive (စာနာနားလည်တတ်သော)၊ volunteer (စေတနာ့ဝန်ထမ်း)၊ adaptability (လိုက်လျောညီထွေ ပြောင်းလဲနိုင်စွမ်း)။",
        "passage": [
          { "en": "A. To create a healthy environment, teenagers are as responsible as adults. Our city celebrates World Environment Day on 5th June every year. My friends and I volunteer to clean up our community area. We plant shady trees like Kha Yay (star-flower) and Magyi (tamarind) on that day. We also join the city's 'No Plastic Bag Campaign' by not using plastic bags. (Yan Lin, Mandalay)", "mm": "A. ကျန်းမာသန့်ရှင်းတဲ့ ပတ်ဝန်းကျင်ကို ဖန်တီးဖို့ လူကြီးတွေနည်းတူ ဆယ်ကျော်သက်လူငယ်တွေမှာလည်း တာဝန်ရှိပါတယ်။ ကျွန်တော်တို့မြို့မှာ နှစ်စဉ် ဇွန်လ ၅ ရက်နေ့တိုင်း ကမ္ဘာ့ပတ်ဝန်းကျင်ထိန်းသိမ်းရေးနေ့ ကျင်းပပါတယ်။ သူငယ်ချင်းတွေနဲ့အတူ ရပ်ရွာသန့်ရှင်းရေးလုပ်ပြီး ခရေပင်နဲ့ မန်ကျည်းပင်လို အရိပ်ရအပင်တွေ စိုက်ပျိုးကြပါတယ်။ ပလတ်စတစ်အိတ် မသုံးရေး လှုပ်ရှားမှုမှာလည်း ပါဝင်ကြပါတယ်။ (ရန်လင်း၊ မန္တလေး)" },
          { "en": "B. In my opinion, we should be kind to everyone we meet. When I see people in need, I do not turn my back on them. I usually offer them food, clothing, or money. For example, I give up my seat to a pregnant woman or an elderly person on the bus. I usually donate clothes and money to the children at the orphanage on my birthday. If people all over the world are kind to one another, the world will be a better place to live in. (Thuzar, Yangon)", "mm": "B. ကျွန်မအမြင်အရ တွေ့ဆုံရသူတိုင်းအပေါ် ကြင်နာသင့်ပါတယ်။ အကူအညီလိုအပ်နေသူတွေကို တွေ့ရင် မျက်နှာလွှဲမသွားဘဲ အစားအစာ၊ အဝတ်အထည် ဒါမှမဟုတ် ငွေကြေး ကူညီလေ့ရှိပါတယ်။ ဘတ်စ်ကားပေါ်မှာ ကိုယ်ဝန်ဆောင်နဲ့ သက်ကြီးရွယ်အိုတွေကို နေရာဖယ်ပေးပြီး မွေးနေ့တိုင်း မိဘမဲ့ဂေဟာက ကလေးတွေကို လှူဒါန်းလေ့ရှိပါတယ်။ တစ်ကမ္ဘာလုံးက လူတွေ တစ်ဦးကိုတစ်ဦး ကြင်နာကြမယ်ဆိုရင် ကမ္ဘာကြီးဟာ ပိုမိုနေချင်စဖွယ် ဖြစ်လာမှာပါ။ (သူဇာ၊ ရန်ကုန်)" },
          { "en": "C. Cooperation is one of the most important qualities a global citizen should have. Nowadays, 'I can do well' is replaced with 'We can do well' at school, at work, and in the community. It is difficult to achieve success in life if we don't work together with others. For example, a number of workers have to cooperate to produce an everyday product like a pencil. Thus, we need to be more cooperative to carry out important tasks successfully. (Toe Aung, Mawlamyine)", "mm": "C. ပူးပေါင်းဆောင်ရွက်မှုဟာ ကမ္ဘာ့သားကောင်းတစ်ဦး ရှိသင့်တဲ့ အရေးအကြီးဆုံး အရည်အချင်းတစ်ခု ဖြစ်ပါတယ်။ ယနေ့ခေတ်မှာ 'ငါတစ်ယောက်တည်း လုပ်နိုင်တယ်' ဆိုတာထက် 'ငါတို့အတူတကွ လုပ်နိုင်တယ်' ဆိုတာက အစားထိုးနေရာယူလာပါပြီ။ ခဲတံတစ်ချောင်း ထုတ်လုပ်ဖို့တောင် အလုပ်သမားအများအပြား ပူးပေါင်းဆောင်ရွက်ရပါတယ်။ ဒါကြောင့် အရေးကြီးတဲ့ လုပ်ငန်းတွေ အောင်မြင်ဖို့ ပိုမိုပူးပေါင်းဆောင်ရွက်တတ်ဖို့ လိုအပ်ပါတယ်။ (တိုးအောင်၊ မော်လမြိုင်)" },
          { "en": "D. Adaptability is a simple secret of survival. The world is changing rapidly. In order to cope with new ideas or challenges in this age, we need to be adaptable. As 21st century youths, we can learn new things if we know how to use ICT. Thanks to the internet, we can easily share information among us. To be able to adapt ourselves to new trends, we must be observant of the changes happening locally and globally. (Chit Su, Nay Pyi Taw)", "mm": "D. လိုက်လျောညီထွေ ပြောင်းလဲနိုင်စွမ်းဟာ ရှင်သန်ရပ်တည်နိုင်မှုရဲ့ ရိုးရှင်းတဲ့ လျှို့ဝှက်ချက် ဖြစ်ပါတယ်။ ကမ္ဘာကြီးဟာ အလျင်အမြန် ပြောင်းလဲနေပါတယ်။ ခေတ်သစ်စိန်ခေါ်မှုတွေကို ရင်ဆိုင်နိုင်ဖို့ လိုက်လျောညီထွေ ရှိရပါမယ်။ ၂၁ ရာစု လူငယ်တွေအနေနဲ့ ICT နည်းပညာကို အသုံးပြုတတ်ရင် အသစ်အဆန်းတွေ သင်ယူနိုင်ပြီး အင်တာနက်ကြောင့် သတင်းအချက်အလက်တွေ အလွယ်တကူ ဝေမျှနိုင်ပါတယ်။ (ချစ်စု၊ နေပြည်တော်)" }
        ]
      },
      {
        "label": "Lesson 3 & 4",
        "title": "Lesson 3 & 4: Myanmar (Superlatives) & Paragraph Structure",
        "note": "💡 သဒ္ဒါမှတ်စု: Superlative Adjectives (အသာလွန်ဆုံးအဆင့်) ၏ အရှေ့တွင် 'the' သို့မဟုတ် Possessive determiner (my, his, their) ထည့်ရပါသည်။ (ဥပမာ - the highest mountain, my youngest sister)။",
        "passage": [
          { "en": "Myanmar is one of the most beautiful countries in Southeast Asia. It is a wonderful country rich in natural resources. Myanmar rubies and jades are the world's finest gems.", "mm": "မြန်မာနိုင်ငံဟာ အရှေ့တောင်အာရှရဲ့ အလှပဆုံး နိုင်ငံတွေထဲက တစ်နိုင်ငံ ဖြစ်ပါတယ်။ သဘာဝသယံဇာတ ပေါကြွယ်ဝတဲ့ နိုင်ငံဖြစ်ပြီး မြန်မာ့ပတ္တမြားနဲ့ ကျောက်စိမ်းတွေဟာ ကမ္ဘာ့အကောင်းဆုံး ကျောက်မျက်ရတနာတွေ ဖြစ်ပါတယ်။" },
          { "en": "The Myanmar are famous for their friendliness and hospitality. Visitors to Myanmar are often amazed by their kindness. The people of Myanmar are said to be the friendliest and the most helpful people in the world. During your visit to Myanmar, the most significant thing you will notice is the sincere smiles on their faces.", "mm": "မြန်မာလူမျိုးတွေဟာ ဖော်ရွေပျူငှာမှုနဲ့ ဧည့်ဝတ်ကျေပွန်မှုတို့ကြောင့် နာမည်ကျော်ကြားပါတယ်။ မြန်မာနိုင်ငံကို လာရောက်လည်ပတ်သူတွေဟာ မြန်မာလူမျိုးတွေရဲ့ ကြင်နာတတ်မှုကို အံ့ဩချီးကျူးကြပြီး မျက်နှာပေါ်က ရိုးသားဖြူစင်တဲ့ အပြုံးလေးတွေကို သတိထားမိကြပါတယ်။" },
          { "en": "There are also a lot of interesting places in Myanmar. Inlay Lake is the only place in Myanmar where you can see leg-rowers. Mt Hkakabo Razi is the highest mountain with an altitude of 18,839 ft. The Ayeyarwady River, the lifeblood of the country, is the longest. Among many beautiful sandy beaches, Ngapali is the most popular.", "mm": "မြန်မာနိုင်ငံမှာ စိတ်ဝင်စားစရာ နေရာတွေလည်း အများကြီး ရှိပါတယ်။ အင်းလေးကန်ဟာ ခြေထောက်နဲ့ လှေလှော်သူတွေကို မြင်တွေ့နိုင်တဲ့ တစ်ခုတည်းသော နေရာဖြစ်ပါတယ်။ ခါကာဘိုရာဇီတောင်ဟာ အမြင့်ပေ ၁၈,၈၃၉ ပေရှိတဲ့ အမြင့်ဆုံးတောင်ဖြစ်ပြီး ဧရာဝတီမြစ်ဟာ အရှည်ဆုံးမြစ် ဖြစ်ပါတယ်။ သဲသောင်ပြင်ကမ်းခြေတွေထဲမှာတော့ ငပလီကမ်းခြေဟာ လူကြိုက်အများဆုံး ဖြစ်ပါတယ်။" },
          { "en": "Nu Nu's Grandmother (Paragraph Structure): My favourite person is my grandmother. She is the most patient person in my family. She never gets angry. She often makes different kinds of snacks for me. Moreover, she always shares the snacks with the neighbours. For these reasons, she is the person I love most.", "mm": "နုနု၏ အဘွား (စာပိုဒ်ဖွဲ့စည်းပုံ): ကျွန်မ အနှစ်သက်ဆုံးသူကတော့ အဘွားပါ။ သူမဟာ မိသားစုထဲမှာ စိတ်အရှည်ဆုံးသူ ဖြစ်ပြီး ဘယ်တော့မှ စိတ်မဆိုးတတ်ပါဘူး။ ကျွန်မအတွက် မုန့်မျိုးစုံ လုပ်ကျွေးတတ်ပြီး အိမ်နီးချင်းတွေကိုလည်း အမြဲဝေမျှပေးပါတယ်။ ဒီအကြောင်းပြချက်တွေကြောင့် အဘွားကို အချစ်ဆုံး ဖြစ်ပါတယ်။" }
        ]
      }
    ],
    "games": [
      { "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (Personality Adjectives)", "q": "သူတစ်ပါးကို အမြဲတမ်း အမိန့်ပေး ခိုင်းစေတတ်သူကို ဘယ်လိုခေါ်လဲ?", "mode": "mcq", "options": ["quiet", "bossy", "modest", "diligent"], "ans": 1, "explain": "'bossy' ဆိုတာ သူများကို ဘာလုပ်ရမယ်ဆိုပြီး အမြဲအမိန့်ပေးတတ်သူကို ခေါ်တာပါ။" },
      { "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Superlative Adjectives)", "q": "'ဧရာဝတီမြစ်သည် မြန်မာနိုင်ငံတွင် အရှည်ဆုံးမြစ် ဖြစ်သည်' ကို စီပါ။", "mode": "scramble", "words": ["The", "Ayeyarwady", "is", "the", "longest", "river", "in", "Myanmar."], "explain": "Superlative (အရှည်ဆုံး) ဖြစ်တဲ့ 'longest' ရဲ့ အရှေ့မှာ 'the' အမြဲထည့်ရပါတယ်။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Superlative Form)", "q": "The people of Myanmar are said to be the friendliest and the _____ people in the world.", "mode": "mcq", "options": ["helpful", "more helpful", "most helpful", "helpfullest"], "ans": 2, "explain": "အသံထွက် နှစ်လုံးနှင့်အထက် (helpful) အတွက် 'the most helpful' လို့ သုံးရပါတယ်။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Paragraph Structure)", "q": "A sentence that introduces the main idea of a paragraph is called a _____.", "mode": "mcq", "options": ["topic sentence", "supporting sentence", "concluding sentence", "question"], "ans": 0, "explain": "စာပိုဒ်တစ်ပိုဒ်ရဲ့ အဓိကအကြောင်းအရာကို မိတ်ဆက်ပေးတဲ့ ဝါကျကို 'topic sentence' လို့ ခေါ်ပါတယ်။" },
      { "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Lesson 2 Check)", "q": "ရန်လင်း (Yan Lin) နဲ့ သူငယ်ချင်းတွေဟာ ကမ္ဘာ့ပတ်ဝန်းကျင်ထိန်းသိမ်းရေးနေ့မှာ ခရေပင်နဲ့ မန်ကျည်းပင်တွေ စိုက်ပျိုးကြပါတယ်။", "mode": "mcq", "options": ["မှန်တယ် (True)", "မှားတယ် (False)"], "ans": 0, "explain": "မှန်ပါတယ်! 'We plant shady trees like Kha Yay (star-flower) and Magyi (tamarind)' လို့ ပါရှိပါတယ်။" }
    ]
  },
  {
    "title": "Unit 5: Computers & Science Experiments (ကွန်ပျူတာနှင့် လက်တွေ့စမ်းသပ်ချက်များ)",
    "sections": [
      {
        "label": "Lesson 1",
        "title": "Lesson 1: Do you know how to use a computer?",
        "note": "💡 ကွန်ပျူတာအစိတ်အပိုင်းများ: Monitor (ဖန်သားပြင်)၊ Keyboard (စာရိုက်ခလုတ်ခုံ)၊ Mouse (မောက်စ်)၊ CPU (ကွန်ပျူတာ၏ ဦးနှောက်)။",
        "passage": [
          { "en": "A desktop computer is a computer designed to be used on a table or desk. It has a monitor, a CPU, a keyboard and a mouse.", "mm": "စားပွဲတင်ကွန်ပျူတာ (Desktop computer) ဆိုတာ စားပွဲပေါ်မှာ တင်သုံးဖို့ ဒီဇိုင်းထုတ်ထားတဲ့ ကွန်ပျူတာဖြစ်ပြီး မော်နီတာ၊ CPU၊ ကီးဘုတ်နဲ့ မောက်စ်တို့ ပါဝင်ပါတယ်။" },
          { "en": "A monitor is an output device that often looks similar to a television screen. It allows you to see what the computer is doing or processing.", "mm": "မော်နီတာဆိုတာ တီဗွီဖန်သားပြင်နဲ့ ဆင်တူတဲ့ Output ပစ္စည်းဖြစ်ပြီး ကွန်ပျူတာ ဘာတွေလုပ်ဆောင်နေလဲဆိုတာ မြင်တွေ့နိုင်စေပါတယ်။" },
          { "en": "A keyboard is a typewriter-style device used to input text into a computer. A mouse is a small device used to guide the cursor on a computer screen.", "mm": "ကီးဘုတ်ဆိုတာ ကွန်ပျူတာထဲ စာသားတွေ ရိုက်ထည့်ဖို့ လက်နှိပ်စက်ပုံစံ ကိရိယာဖြစ်ပြီး၊ မောက်စ်ကတော့ ဖန်သားပြင်ပေါ်က Cursor ကို ရွှေ့ပြောင်းထိန်းချုပ်ဖို့ ကိရိယာငယ်လေး ဖြစ်ပါတယ်။" },
          { "en": "A CPU (Central Processing Unit) is the 'brain' of the computer and performs all types of data processing operations.", "mm": "CPU (ဗဟိုအချက်အလက် စီမံဆောင်ရွက်ရေးယူနစ်) ဟာ ကွန်ပျူတာရဲ့ 'ဦးနှောက်' ဖြစ်ပြီး အချက်အလက် စီမံတွက်ချက်မှု အားလုံးကို လုပ်ဆောင်ပါတယ်။" },
          { "en": "How to start a computer: First, start the power. Next, turn on the monitor. Finally, press the power button on the CPU tower.", "mm": "ကွန်ပျူတာ ဖွင့်နည်း: ပထမဦးစွာ မီးခလုတ် (Power) ကို ဖွင့်ပါ။ နောက်တစ်ဆင့် မော်နီတာကို ဖွင့်ပါ။ နောက်ဆုံးအနေနဲ့ CPU ပုံးပေါ်က ပါဝါခလုတ်ကို နှိပ်ပါ။" }
        ]
      },
      {
        "label": "Lesson 2",
        "title": "Lesson 2: Basics of a computer (Microsoft Word)",
        "note": "💡 ဝေါဟာရမှတ်စု: Software (ပရိုဂရမ်များ)၊ Hardware (ကိုင်တွယ်ထိတွေ့ရသော အစိတ်အပိုင်းများ)၊ Word processing (စာစီစာရိုက် ပြုလုပ်ခြင်း)။",
        "passage": [
          { "en": "All computers are composed of two basic parts: software and hardware. Software means a set of programmes used to operate a computer whereas hardware refers to the objects which are electronic parts of a computer such as keyboard, mouse, speakers, and CPU.", "mm": "ကွန်ပျူတာအားလုံးကို အခြေခံအစိတ်အပိုင်း နှစ်မျိုးဖြစ်တဲ့ ဆော့ဖ်ဝဲ (Software) နဲ့ ဟာ့ဒ်ဝဲ (Hardware) တို့နဲ့ ဖွဲ့စည်းထားပါတယ်။ ဆော့ဖ်ဝဲဆိုတာ ကွန်ပျူတာကို မောင်းနှင်ဖို့ ပရိုဂရမ်အစုအဝေးဖြစ်ပြီး ဟာ့ဒ်ဝဲကတော့ ကီးဘုတ်၊ မောက်စ်၊ စပီကာနဲ့ CPU တို့လို အီလက်ထရွန်နစ် အစိတ်အပိုင်းတွေကို ရည်ညွှန်းပါတယ်။" },
          { "en": "One of the most popular types of software in the world is Microsoft Word, which was developed by Microsoft Corporation, the world's biggest software company. Microsoft Word is a word processing programme. Word processing means the process of creating, editing and formatting documents, and adding graphics to the documents. It is used mainly for creating documents such as letters, learning activities, tests, and projects.", "mm": "ကမ္ဘာပေါ်မှာ လူသုံးအများဆုံး ဆော့ဖ်ဝဲတစ်ခုကတော့ Microsoft ကုမ္ပဏီက ထုတ်လုပ်ထားတဲ့ Microsoft Word ဖြစ်ပါတယ်။ ဒါဟာ စာရွက်စာတမ်းတွေ ဖန်တီးခြင်း၊ ပြင်ဆင်တည်းဖြတ်ခြင်း၊ ပုံစံချခြင်းနဲ့ ရုပ်ပုံတွေ ထည့်သွင်းခြင်းတွေအတွက် အဓိကသုံးတဲ့ စာစီစာရိုက် ပရိုဂရမ်တစ်ခု ဖြစ်ပါတယ်။" },
          { "en": "In Microsoft Word, there are different ways of starting a document. First of all, click Start in the bottom-left corner of the desktop screen. Then, click Microsoft Word from Start Menu, and a new blank document will open up for the user to start typing.", "mm": "Microsoft Word မှာ စာရွက်စာတမ်းအသစ် စတင်ဖွင့်ဖို့ နည်းလမ်းအမျိုးမျိုး ရှိပါတယ်။ ပထမဦးဆုံး ဖန်သားပြင် ဘယ်ဘက်အောက်ထောင့်က Start ခလုတ်ကို နှိပ်ပါ။ ပြီးရင် Start Menu ထဲက Microsoft Word ကို နှိပ်လိုက်ရင် စာစရိုက်ဖို့ စာမျက်နှာအလွတ်တစ်ခု ပွင့်လာပါလိမ့်မယ်။" },
          { "en": "After finishing word processing, the document needs to be saved. First of all, click File Menu in the upper-left corner of the desktop screen. Next, click Save from File Menu, and a Save dialogue box will come up. Then, enter or type a name in the File name box. Finally, click Save at the bottom of the box and the document is stored in the computer.", "mm": "စာရိုက်ပြီးတဲ့အခါ ဖိုင်ကို သိမ်းဆည်းဖို့ လိုပါတယ်။ ပထမဦးဆုံး ဘယ်ဘက်အပေါ်ထောင့်က File Menu ကို နှိပ်ပါ။ နောက်တစ်ဆင့် Save ကို နှိပ်လိုက်ရင် Save ဘောက်စ် ပေါ်လာပါမယ်။ အဲဒီနောက် File name အကွက်ထဲမှာ ဖိုင်နာမည် ရိုက်ထည့်ပြီး အောက်ခြေက Save ခလုတ်ကို နှိပ်လိုက်ရင် ကွန်ပျူတာထဲမှာ သိမ်းဆည်းပြီး ဖြစ်သွားပါတယ်။" }
        ]
      },
      {
        "label": "Lesson 3 & 4",
        "title": "Lesson 3 & 4: Imperatives & Science Experiments",
        "note": "💡 သဒ္ဒါမှတ်စု: လုပ်ငန်းစဉ်အဆင့်ဆင့်ကို ဖော်ပြရာတွင် Imperatives (ကြိယာအရင်း) နှင့် Adverbs of sequence (First, Next, Then, After that, Finally) တို့ကို တွဲဖက်အသုံးပြုရပါသည်။",
        "passage": [
          { "en": "Making Invisible Ink: First, squeeze the juice of half of a lemon into a bowl and add a few drops of water to the juice.", "mm": "မမြင်ရသော မှင်ပြုလုပ်နည်း: ပထမဦးစွာ သံပရာသီး တစ်ခြမ်းရဲ့ အရည်ကို ပန်းကန်လုံးထဲ ညှစ်ထည့်ပြီး ရေအနည်းငယ် ရောထည့်ပါ။" },
          { "en": "Next, stir the juice and water with a spoon. Then, dip a cotton swab or bud into the mixture.", "mm": "နောက်တစ်ဆင့် သံပရာရည်နဲ့ ရေကို ဇွန်းနဲ့ မွှေပါ။ ပြီးရင် ဂွမ်းတံလေးကို အဲဒီအရည်ထဲ နှစ်လိုက်ပါ။" },
          { "en": "After that, write a message on a piece of paper and allow the invisible ink to dry and disappear. Finally, heat the paper using a lamp to see the message.", "mm": "အဲဒီနောက် စာရွက်ပေါ်မှာ စာရေးပြီး မှင်ခြောက်သွားကာ ပျောက်ကွယ်သွားတဲ့အထိ ထားပါ။ နောက်ဆုံးမှာ မီးအိမ်အပူပေးလိုက်ရင် ရေးထားတဲ့စာ ပြန်ပေါ်လာပါလိမ့်မယ်။" },
          { "en": "Making Saline Solution: First, wash your hands thoroughly. Next, sterilise the container and the stirrer by boiling them in water.", "mm": "ဆားရည်ပြုလုပ်နည်း: ပထမဦးစွာ လက်ကို စင်ကြယ်အောင် ဆေးကြောပါ။ နောက်တစ်ဆင့် ဘူးနဲ့ မွှေတံကို ရေနွေးပွက်ပွက်ထဲ ပြုတ်ပြီး ပိုးသတ်ပါ။" },
          { "en": "Then, pour 4 cups of boiled water into the container. After that, mix 2 teaspoons of non-iodised salt in and stir until completely dissolved. Finally, allow the mixture to cool by storing it in the refrigerator.", "mm": "ပြီးရင် ကျိုချက်ထားတဲ့ ရေ ၄ ခွက်ကို ဘူးထဲလောင်းထည့်ပါ။ အဲဒီနောက် အိုင်အိုဒင်းမပါတဲ့ ဆား လက်ဖက်ရည်ဇွန်း ၂ ဇွန်းထည့်ပြီး လုံးဝပျော်ဝင်သွားတဲ့အထိ မွှေပါ။ နောက်ဆုံးမှာ ရေခဲသေတ္တာထဲထည့်ပြီး အအေးခံပါ။" }
        ]
      }
    ],
    "games": [
      { "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (Computer Basics)", "q": "ကွန်ပျူတာရဲ့ 'ဦးနှောက် (Brain)' လို့ တင်စားခေါ်ဝေါ်တဲ့ အစိတ်အပိုင်းက ဘာလဲ?", "mode": "mcq", "options": ["Monitor", "Keyboard", "CPU", "Mouse"], "ans": 2, "explain": "CPU (Central Processing Unit) ဟာ အချက်အလက်အားလုံးကို တွက်ချက်စီမံပေးတဲ့ ကွန်ပျူတာရဲ့ ဦးနှောက်ဖြစ်ပါတယ်။" },
      { "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Grammar: Imperatives)", "q": "'ဆေးကို တစ်နေ့ သုံးကြိမ် သောက်ပါ' ကို ညွှန်ကြားဝါကျ စီပါ။", "mode": "scramble", "words": ["Take", "the", "medicine", "three", "times", "a", "day."], "explain": "ညွှန်ကြားချက် (Imperative) ဝါကျတွေကို ကြိယာအရင်း (Take) နဲ့ တိုက်ရိုက်စတင်ရပါတယ်။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Negative Imperative)", "q": "_____ a socket with wet hands. It is very dangerous.", "mode": "mcq", "options": ["Touch", "Don't touch", "Touching", "Not touch"], "ans": 1, "explain": "မလုပ်ဖို့ တားမြစ်တဲ့အခါ ကြိယာအရှေ့မှာ 'Don't' ထည့်ပြီး 'Don't touch' လို့ သုံးရပါတယ်။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Unit 5 Vocab)", "q": "When you want to open a file on the computer, _____ twice on it.", "mode": "mcq", "options": ["scroll", "click", "input", "process"], "ans": 1, "explain": "ဖိုင်တစ်ခုကို ဖွင့်ချင်ရင် မောက်စ်နဲ့ နှစ်ချက်နှိပ် (click twice / double-click) ရပါတယ်။" },
      { "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Lesson 2 Check)", "q": "Microsoft Word မှာ ဖိုင်သိမ်းဖို့ File Menu ကို ဘယ်ဘက်အပေါ်ထောင့်မှာ ရှာတွေ့နိုင်ပါတယ်။", "mode": "mcq", "options": ["မှန်တယ် (True)", "မှားတယ် (False)"], "ans": 0, "explain": "မှန်ပါတယ်! 'click File Menu in the upper-left corner of the desktop screen' လို့ ပါရှိပါတယ်။" }
    ]
  },
  {
    "title": "Unit 6: Our Environment & Saving Earth (သဘာဝပတ်ဝန်းကျင် ထိန်းသိမ်းရေး)",
    "sections": [
      {
        "label": "Lesson 1",
        "title": "Lesson 1: Our environment (Min Min's Talk on Ecosystem)",
        "note": "💡 ဝေါဟာရမှတ်စု: environment (သဘာဝပတ်ဝန်းကျင်)၊ atmosphere (လေထု)၊ ecosystem (သက်ရှိနှင့် သက်မဲ့တို့ အပြန်အလှန် မှီခိုနေသော ဂေဟစနစ်)။",
        "passage": [
          { "en": "Hi everyone. My name is Min Min. I'm a Grade 8 student. I'm here today to talk about our environment and the ecosystem.", "mm": "အားလုံးပဲ မင်္ဂလာပါ။ ကျွန်တော့်နာမည် မင်းမင်းပါ။ Grade 8 ကျောင်းသားတစ်ဦးဖြစ်ပြီး ဒီနေ့ ကျွန်ုပ်တို့ရဲ့ သဘာဝပတ်ဝန်းကျင်နဲ့ ဂေဟစနစ်အကြောင်း ပြောပြချင်ပါတယ်။" },
          { "en": "First of all, let me explain what 'environment' means. It can be defined as the natural world around us. In other words, it is made up of living things such as people, animals and plants, and non-living things such as air, water, and soil.", "mm": "ပထမဦးဆုံး 'ပတ်ဝန်းကျင်' ဆိုတာ ဘာလဲ ရှင်းပြပါရစေ။ ကျွန်ုပ်တို့ ပတ်လည်မှာရှိတဲ့ သဘာဝလောကကြီးကို ခေါ်တာပါ။ တစ်နည်းအားဖြင့် လူ၊ တိရစ္ဆာန်နဲ့ အပင်တွေလို သက်ရှိအရာတွေနဲ့ လေ၊ ရေ၊ မြေဆီလွှာတို့လို သက်မဲ့အရာတွေနဲ့ ဖွဲ့စည်းထားပါတယ်။" },
          { "en": "A layer of gases (e.g. oxygen) surrounding the earth is called the earth's atmosphere. About 29% of the earth's surface is land, and the remaining 71% is covered with water. The rays of light which the sun scatters on the earth's surface are known as sunlight.", "mm": "ကမ္ဘာမြေကြီးကို ဝန်းရံထားတဲ့ ဓာတ်ငွေ့အလွှာ (ဥပမာ- အောက်ဆီဂျင်) ကို ကမ္ဘာ့လေထုလို့ ခေါ်ပါတယ်။ ကမ္ဘာ့မျက်နှာပြင်ရဲ့ ၂၉% ခန့်ဟာ ကုန်းမြေဖြစ်ပြီး ကျန် ၇၁% က ရေတွေ ဖုံးလွှမ်းထားပါတယ်။" },
          { "en": "A very interesting thing is that living things and non-living things interact with one another in the environment. Plants use sunlight, water, and carbon dioxide from the air to make food for themselves. Obviously, such an interaction is known as the ecosystem. Because of human activities, the ecosystem is not well-balanced anymore.", "mm": "စိတ်ဝင်စားစရာကောင်းတာက သက်ရှိနဲ့ သက်မဲ့တွေ အပြန်အလှန် အကျိုးပြုဆက်ဆံနေကြတာပါပဲ။ အပင်တွေဟာ နေရောင်ခြည်၊ ရေနဲ့ လေထဲက ကာဗွန်ဒိုင်အောက်ဆိုဒ်ကို သုံးပြီး အစာချက်လုပ်ကြပါတယ်။ ဒီလို အပြန်အလှန် ဆက်နွှယ်မှုကို ဂေဟစနစ် (Ecosystem) လို့ ခေါ်ပါတယ်။ လူသားတွေရဲ့ လုပ်ရပ်တွေကြောင့် အခုအခါ ဂေဟစနစ် ဟန်ချက်မညီတော့ပါဘူး။" }
        ]
      },
      {
        "label": "Lesson 2",
        "title": "Lesson 2: Our friendly environment (Problems & The 3 R's)",
        "note": "💡 3 R's: Reduce (အမှိုက်ထွက်နှုန်း လျှော့ချခြင်း)၊ Reuse (တစ်ခါသုံးပြီး လွှင့်မပစ်ဘဲ ပြန်လည်အသုံးပြုခြင်း)၊ Recycle (ပစ္စည်းဟောင်းများကို ကုန်ကြမ်းအဖြစ် ပြန်လည်ပြုပြင်ထုတ်လုပ်ခြင်း)။",
        "passage": [
          { "en": "1. The ecosystem of our earth: The earth on which we live is full of wonderful things. Humans and animals breathe in oxygen, whereas trees breathe in carbon dioxide. The earth's atmosphere provides us with oxygen and the sun gives us warmth, light and energy free of charge. We can get water, which is essential for our daily life, from the rain. We can get our basic needs such as food, clothing and shelter from our natural environment.", "mm": "၁။ ကျွန်ုပ်တို့ကမ္ဘာ၏ ဂေဟစနစ်: ကျွန်ုပ်တို့ နေထိုင်ရာ ကမ္ဘာမြေကြီးဟာ အံ့ဖွယ်ရာတွေနဲ့ ပြည့်နှက်နေပါတယ်။ လူနဲ့ တိရစ္ဆာန်တွေက အောက်ဆီဂျင်ကို ရှူသွင်းပြီး သစ်ပင်တွေက ကာဗွန်ဒိုင်အောက်ဆိုဒ်ကို ရှူသွင်းပါတယ်။ ကမ္ဘာ့လေထုက အောက်ဆီဂျင်ပေးပြီး နေမင်းကြီးက နွေးထွေးမှု၊ အလင်းရောင်နဲ့ စွမ်းအင်တွေကို အခမဲ့ ပေးစွမ်းပါတယ်။" },
          { "en": "2. Human activities that are harmful to the environment: Our environment is now in great danger due to human activities, such as cutting down trees, overfishing, and burning fossil fuels. Many trees are being cut down for housing and farming as the world's population is growing faster. As a result, many wild animals have lost their homes. Some species have disappeared, and some are now endangered.", "mm": "၂။ ပတ်ဝန်းကျင်ကို ထိခိုက်စေသော လူသားတို့၏ လုပ်ရပ်များ: သစ်ပင်ခုတ်ခြင်း၊ ငါးအလွန်အကျွံဖမ်းခြင်းနဲ့ ရုပ်ကြွင်းလောင်စာ မီးရှို့ခြင်းတွေကြောင့် ပတ်ဝန်းကျင်ဟာ ကြီးမားတဲ့ အန္တရာယ်နဲ့ ရင်ဆိုင်နေရပါတယ်။ လူဦးရေ တိုးပွားလာတာနဲ့အမျှ အိမ်ဆောက်ဖို့နဲ့ စိုက်ပျိုးဖို့ သစ်ပင်တွေ ခုတ်လှဲကြတာကြောင့် တောရိုင်းတိရစ္ဆာန်တွေ နေစရာပျောက်ဆုံးပြီး မျိုးစိတ်တချို့ မျိုးသုဉ်းမယ့် အန္တရာယ် ရှိနေပါတယ်။" },
          { "en": "The quality of soil is being degraded because people are using chemical fertilizers to grow plants. Many factories are burning fossil fuels and emitting dangerous greenhouse gases. As a result, the globe is getting warmer and warmer. Moreover, many factories are disposing of their chemical wastes in rivers and seas. This causes water pollution and threatens food security.", "mm": "ဓာတုမြေဩဇာတွေ သုံးစွဲမှုကြောင့် မြေဆီလွှာအရည်အသွေး ကျဆင်းလာပါတယ်။ စက်ရုံတွေက ဖန်လုံအိမ်ဓာတ်ငွေ့တွေ ထုတ်လွှတ်နေလို့ ကမ္ဘာကြီး ပိုပိုပူနွေးလာပါတယ်။ ဒါ့အပြင် စက်ရုံတွေက ဓာတုစွန့်ပစ်ပစ္စည်းတွေကို မြစ်ချောင်းနဲ့ ပင်လယ်တွေထဲ စွန့်ပစ်ကြလို့ ရေထုညစ်ညမ်းမှု ဖြစ်ပေါ်နေပါတယ်။" },
          { "en": "3. Environmental problems & Solutions: As a result of global warming and climate change, we are suffering natural disasters such as floods, storms, landslides, droughts and wildfires. To stop global warming, we must learn the three R's of the environment: reduce, reuse and recycle. We must reduce waste by not using plastic bags, reuse items instead of throwing them away, and recycle old newspapers and plastic bottles to save natural resources.", "mm": "၃။ သဘာဝပတ်ဝန်းကျင် ပြဿနာများနှင့် ဖြေရှင်းနည်းများ: ကမ္ဘာကြီးပူနွေးလာမှုကြောင့် ရေကြီးခြင်း၊ မုန်တိုင်းတိုက်ခြင်း၊ မြေပြိုခြင်း၊ မိုးခေါင်ခြင်းနဲ့ တောမီးလောင်ခြင်းတွေ ခံစားနေရပါတယ်။ ဒါတွေကို တားဆီးဖို့ ပတ်ဝန်းကျင်ထိန်းသိမ်းရေး R သုံးလုံး (Reduce, Reuse, Recycle) ကို ကျင့်သုံးပြီး သဘာဝသယံဇာတတွေကို ကာကွယ်ရပါမယ်။" }
        ]
      },
      {
        "label": "Lesson 3 & 4",
        "title": "Lesson 3 & 4: Obligation/Prohibition & Let's save our earth!",
        "note": "💡 သဒ္ဒါမှတ်စု: Must / Have to = လုပ်ရမည် (တာဝန်ဝတ္တရား)၊ Mustn't = လုံးဝမလုပ်ရ (တားမြစ်ချက်)၊ Don't/Doesn't have to = လုပ်ရန်မလိုအပ်ပါ။",
        "passage": [
          { "en": "Anika (Calcutta, India): I used to go to school by car. My dad drove me to school. But now, I bike to school every day. Definitely, I can save fuel. The air will be cleaner if more people bike instead of driving.", "mm": "အန်နီကာ (ကာလကတ္တား၊ အိန္ဒိယ): အရင်က အဖေက ကားနဲ့ ကျောင်းလိုက်ပို့ပေးပေမဲ့ အခု နေ့တိုင်း စက်ဘီးစီးပြီး ကျောင်းသွားပါတယ်။ လောင်စာဆီ ချွေတာနိုင်ပြီး လူတွေ စက်ဘီးပိုစီးကြရင် လေထုလည်း ပိုသန့်ရှင်းလာမှာပါ။" },
          { "en": "Harry (London, UK): I used a lot of electricity until last year. I now realize that using too much electricity can cause global warming. So, I switch off the computer when I am not using it, and the lights, too. I am happy I can save energy and protect the earth.", "mm": "ဟယ်ရီ (လန်ဒန်၊ ယူကေ): မနှစ်ကအထိ လျှပ်စစ်မီး အများကြီး သုံးခဲ့မိပေမဲ့ အခုတော့ မသုံးတဲ့အခါ ကွန်ပျူတာနဲ့ မီးတွေကို ပိတ်ထားပါတယ်။ စွမ်းအင်ချွေတာပြီး ကမ္ဘာမြေကို ကာကွယ်နိုင်လို့ ပျော်ရွှင်မိပါတယ်။" },
          { "en": "Emily (Wellington, New Zealand): Taking long baths means wasting water. Being aware of this, I have now changed my habit. I take a shower and turn off the tap while I am soaping myself. We must save water to protect the environment.", "mm": "အမ်မလီ (ဝယ်လင်တန်၊ နယူးဇီလန်): ရေချိုးတာ အချိန်ကြာရင် ရေဖြုန်းတီးရာ ရောက်ပါတယ်။ အခုတော့ ရေပန်းနဲ့ပဲ ချိုးပြီး ဆပ်ပြာတိုက်နေချိန်မှာ ရေဘုံဘိုင်ခေါင်းကို ပိတ်ထားပါတယ်။" },
          { "en": "May Mie (Yangon, Myanmar): After studying life skills, I sort the rubbish and put different kinds of rubbish in different dustbins. We must reduce the amount of waste we produce and reuse or recycle paper, plastic bottles and glass.", "mm": "မေမီ (ရန်ကုန်၊ မြန်မာ): ဘဝတွက်တာ ကျွမ်းကျင်စရာ ဘာသာရပ် သင်ယူပြီးနောက် အမှိုက်တွေကို အမျိုးအစားခွဲခြားပြီး သက်ဆိုင်ရာ အမှိုက်ပုံးထဲ ထည့်ပါတယ်။ စက္ကူ၊ ပလတ်စတစ်ပုလင်းနဲ့ ဖန်ခွက်တွေကို ပြန်လည်အသုံးပြုပါတယ်။" },
          { "en": "Abebe (Addis Ababa, Ethiopia): One day, our science teacher told us that trees are important because they produce oxygen, which is essential to all of us. Now, I am growing plants and trees around my house and water them every evening.", "mm": "အဘီဘီ (အက်ဒစ်အဘာဘာ၊ အီသီယိုးပီးယား): သစ်ပင်တွေက မရှိမဖြစ်လိုအပ်တဲ့ အောက်ဆီဂျင် ထုတ်ပေးတယ်လို့ သိပ္ပံဆရာက ပြောပြပြီးကတည်းက အိမ်ပတ်ဝန်းကျင်မှာ သစ်ပင်ပန်းမန်တွေ စိုက်ပျိုးပြီး ညနေတိုင်း ရေလောင်းပါတယ်။" }
        ]
      }
    ],
    "games": [
      { "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (Unit 6 Vocab)", "q": "'free of charge' ဆိုတဲ့ စကားစုရဲ့ အဓိပ္ပာယ်က ဘာလဲ?", "mode": "mcq", "options": ["ဈေးကြီးသော", "အခကြေးငွေ မပေးရဘဲ (အခမဲ့)", "အားသွင်းရန်လိုသော", "ပျက်စီးနေသော"], "ans": 1, "explain": "'free of charge' ဆိုတာ အခကြေးငွေ လုံးဝပေးစရာမလိုဘဲ အခမဲ့ ရရှိတာကို ပြောတာပါ။" },
      { "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Obligation: Must)", "q": "'ကျွန်ုပ်တို့သည် ပလတ်စတစ်ပုလင်းများကို ပြန်လည်အသုံးပြုရမည်' ကို စီပါ။", "mode": "scramble", "words": ["We", "must", "recycle", "paper", "and", "plastic", "bottles."], "explain": "'must' နောက်မှာ ကြိယာအရင်း (recycle) ကို တိုက်ရိုက်ထားရပါတယ်။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Lack of Obligation)", "q": "We bought a washing machine yesterday. We _____ wash the clothes by hand now.", "mode": "mcq", "options": ["mustn't", "don't have to", "have to", "must"], "ans": 1, "explain": "အဝတ်လျှော်စက် ဝယ်ပြီးပြီဖြစ်လို့ လက်နဲ့ လျှော်စရာ 'မလိုတော့ပါဘူး' ('don't have to')။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Ecosystem)", "q": "About 29% of the earth's surface is land, and the remaining _____ is covered with water.", "mode": "mcq", "options": ["50%", "61%", "71%", "81%"], "ans": 2, "explain": "ကမ္ဘာ့မျက်နှာပြင်ရဲ့ ၂၉% ဟာ ကုန်းမြေဖြစ်ပြီး ကျန် ၇၁% က ရေဖုံးလွှမ်းထားပါတယ်။" },
      { "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Lesson 4 Check)", "q": "နယူးဇီလန်နိုင်ငံသူ အမ်မလီ (Emily) ဟာ ရေချွေတာဖို့ ဆပ်ပြာတိုက်နေချိန်မှာ ရေဘုံဘိုင်ခေါင်းကို ပိတ်ထားပါတယ်။", "mode": "mcq", "options": ["မှန်တယ် (True)", "မှားတယ် (False)"], "ans": 0, "explain": "မှန်ပါတယ်! 'turn off the tap while I am soaping myself' လို့ ဖော်ပြထားပါတယ်။" }
    ]
  },
  {
    "title": "Unit 7: Phone Calls & Holiday Plans (ဖုန်းပြောဆိုခြင်းနှင့် အားလပ်ရက်ခရီး)",
    "sections": [
      {
        "label": "Lesson 1",
        "title": "Lesson 1: Who's calling, please? (Telephone Conversation)",
        "note": "💡 ဖုန်းသုံး Phrasal Verbs: pick up (ဖုန်းကိုင်သည်)၊ hold on (ခဏစောင့်ပါ)၊ speak up (အသံကျယ်ကျယ်ပြောပါ)၊ call back (ဖုန်းပြန်ခေါ်သည်)၊ hang up (ဖုန်းချသည်)။",
        "passage": [
          { "en": "Myo Gyi's Mum: Hello.", "mm": "မျိုးကြီး၏အမေ: ဟယ်လို။" },
          { "en": "Nyi Latt: Hello. Can I speak to Myo Gyi, please?", "mm": "ညီလတ်: ဟယ်လို။ မျိုးကြီးနဲ့ စကားပြောလို့ရမလား ခင်ဗျာ?" },
          { "en": "Myo Gyi's Mum: Who's calling, please?", "mm": "မျိုးကြီး၏အမေ: ဘယ်သူ ဖုန်းဆက်တာပါလဲ?" },
          { "en": "Nyi Latt: This is Nyi Latt.", "mm": "ညီလတ်: ကျွန်တော် ညီလတ်ပါ ခင်ဗျ။" },
          { "en": "Myo Gyi's Mum: Hi, Nyi Latt. This is Myo Gyi's mum. Hold on, please.", "mm": "မျိုးကြီး၏အမေ: ဪ ညီလတ်လား။ အန်တီ မျိုးကြီးအမေပါ။ ခဏစောင့်ဦးနော် သား။" },
          { "en": "Myo Gyi: Hello. Myo Gyi speaking.", "mm": "မျိုးကြီး: ဟယ်လို။ မျိုးကြီး ပြောနေပါတယ်။" },
          { "en": "Nyi Latt: Hello, Myo Gyi. Nyi Latt here. I'm calling to ask you what you are going to do this Saturday.", "mm": "ညီလတ်: ဟယ်လို မျိုးကြီး။ ငါ ညီလတ်ပါ။ ဒီစနေနေ့ မင်း ဘာလုပ်ဖို့ အစီအစဉ်ရှိလဲ မေးမလို့ ဖုန်းဆက်လိုက်တာ။" },
          { "en": "Myo Gyi: Nothing special. How about you?", "mm": "မျိုးကြီး: အထူးအထွေ မရှိပါဘူးကွာ။ မင်းရော ဘာလုပ်မှာလဲ?" },
          { "en": "Nyi Latt: We're going to play football in the school playground. Would you like to join us?", "mm": "ညီလတ်: ငါတို့ ကျောင်းကစားကွင်းမှာ ဘောလုံးကန်ကြမလို့။ မင်းရော ပါဝင်ချင်လား?" },
          { "en": "Myo Gyi: I'd love to. When shall we meet? — Nyi Latt: Could we meet at 4:15 on Saturday?", "mm": "မျိုးကြီး: ကန်ချင်တာပေါ့။ ဘယ်အချိန် တွေ့ကြမလဲ? — ညီလတ်: စနေနေ့ ၄ နာရီ ၁၅ မိနစ်မှာ တွေ့ကြမလား?" },
          { "en": "Myo Gyi: I'm sorry. I can't hear you well. The line is bad. Can you speak up?", "mm": "မျိုးကြီး: ဆောရီးကွာ။ ငါ သေချာမကြားရဘူး။ လိုင်းမကောင်းဘူး။ နည်းနည်းကျယ်ကျယ် ပြောပေးပါလား?" },
          { "en": "Nyi Latt: Is it OK for us to meet at 4:15 p.m. this Saturday? — Myo Gyi: That would be fine. See you then. Bye.", "mm": "ညီလတ်: ဒီစနေနေ့ ညနေ ၄ နာရီ ၁၅ မိနစ်မှာ တွေ့ဖို့ အဆင်ပြေလား? — မျိုးကြီး: အဆင်ပြေတယ်ကွာ။ အဲဒီကျမှ တွေ့မယ်။ ဘိုင့်ဘိုင်။" }
        ]
      },
      {
        "label": "Lesson 2",
        "title": "Lesson 2: Are you planning a holiday? (Heaven on Earth Leaflet)",
        "note": "💡 ခရီးသွားအမျိုးအစား ၄ မျိုး: A = Adventure holiday (စွန့်စားခရီး)၊ B = Beach holiday (ကမ်းခြေခရီး)၊ C = Cruise holiday (အပျော်စီးသင်္ဘောခရီး)၊ D = Camping holiday (စခန်းချခရီး)။",
        "passage": [
          { "en": "A (Adventure Holiday): If you are an adventurous person, this is just for you. During the holiday, we'll bring you to the green hills for a trek. You can stay in our camp, where you can rent a bike and take a ride up the hills. As soon as you get to the top of the hill overlooking a valley, you'll get fresh again.", "mm": "A (စွန့်စားခရီးစဉ်): သင်ဟာ စွန့်စားရတာကို နှစ်သက်သူဖြစ်ရင် ဒီခရီးစဉ်က သင့်အတွက်ပါပဲ။ စိမ်းလန်းတဲ့ တောင်တန်းတွေဆီ တောင်တက်ခရီး ခေါ်ဆောင်သွားမှာဖြစ်ပြီး စခန်းမှာ တည်းခိုကာ စက်ဘီးငှားပြီး တောင်ပေါ်တက်စီးနိုင်ပါတယ်။ တောင်ကြားကို အပေါ်စီးက မြင်ရတဲ့ တောင်ထိပ်ရောက်တာနဲ့ လန်းဆန်းသွားမှာပါ။" },
          { "en": "B (Beach Holiday): If you like lying on the sandy beaches, you shouldn't miss this. You'll never get tired of different beach activities like taking a banana boat, riding a horse, making sandcastles and so on. Or if you just love to relax, you can spend the day sunbathing, listening to the sound of sea waves and feeling the breeze. For more fun, we'll arrange a bonfire party, where you can sing and dance happily together.", "mm": "B (ကမ်းခြေအပန်းဖြေခရီး): သဲသောင်ပြင်ပေါ် လှဲလျောင်းရတာ ကြိုက်ရင် ဒီခရီးစဉ်ကို လက်မလွှတ်သင့်ပါဘူး။ ငှက်ပျောသီးလှေစီးတာ၊ မြင်းစီးတာ၊ သဲရဲတိုက်ဆောက်တာတွေ လုပ်နိုင်သလို နေပူဆာလှုံပြီး ပင်လယ်လှိုင်းသံ နားထောင်နိုင်ပါတယ်။ ညဘက်မှာ မီးပုံပွဲလေး စီစဉ်ပေးမှာမို့ အတူတူ သီချင်းဆို ကခုန်နိုင်ပါတယ်။" },
          { "en": "C (Cruise Holiday): If you want to experience an extraordinary holiday, we'll bring you to four unspoiled beaches on a cruise just in a day. You can do a wide variety of watersports such as canoeing, swimming, scuba diving and snorkelling. On your way to the beaches, we'll serve you fresh and delicious seafood. Enough life jackets and lifebuoys are on board for your safety.", "mm": "C (အပျော်စီးသင်္ဘောခရီး): ထူးခြားဆန်းပြားတဲ့ အားလပ်ရက် အတွေ့အကြုံ လိုချင်ရင် တစ်ရက်တည်းနဲ့ သဘာဝအတိုင်း မပျက်စီးသေးတဲ့ ကမ်းခြေ ၄ ခုကို အပျော်စီးသင်္ဘောနဲ့ ပို့ဆောင်ပေးပါမယ်။ လှေလှော်ခြင်း၊ ရေကူးခြင်းနဲ့ ရေငုပ်ခြင်းတွေ လုပ်နိုင်ပြီး လတ်ဆတ်တဲ့ ပင်လယ်စာတွေ ကျွေးမွေးပါမယ်။" },
          { "en": "D (Camping Holiday): If you want to escape from your typical way of living for a while, why not choose this? You will wake up with the tweets of the birds in the early morning, and you will see the stars from your little home at night. You can do a range of activities such as fishing, cooking over a campfire, and walking around on our campsite. Don't worry if you don't have a tent, we have tents and sleeping bags to hire at the most reasonable prices.", "mm": "D (စခန်းချခရီး): ပုံမှန်နေထိုင်မှုပုံစံကနေ ခဏတာ ခွဲထွက်ချင်ရင် ဒီခရီးကို ရွေးချယ်ပါ။ မနက်စောစောမှာ ငှက်ကလေးတွေရဲ့ အသံနဲ့ နိုးထလာပြီး ညဘက် ရွက်ဖျင်တဲလေးထဲကနေ ကြယ်လေးတွေကို မြင်တွေ့ရမှာပါ။ ငါးမျှားခြင်း၊ မီးပုံဖိုချက်ပြုတ်ခြင်းတွေ လုပ်နိုင်ပြီး ရွက်ဖျင်တဲနဲ့ အိပ်ရာလိပ်တွေကိုလည်း သင့်တင့်တဲ့ ဈေးနှုန်းနဲ့ ငှားရမ်းနိုင်ပါတယ်။" }
        ]
      },
      {
        "label": "Lesson 3 & 4",
        "title": "Lesson 3 & 4: Will vs Be going to & Invitation Emails",
        "note": "💡 သဒ္ဒါမှတ်စု: Will = စကားပြောနေစဉ် ရုတ်တရက် ဆုံးဖြတ်လိုက်သော အရာ (It's hot. I will open the window.)။ Be going to = ကြိုတင်စီစဉ် ဆုံးဖြတ်ထားပြီးသော အရာ (I am going to visit Kalaw.)။",
        "passage": [
          { "en": "Bo Bo's Invitation Email: Dear Kan Kaung and Min Min, I've got something very exciting to tell you. You know, Uncle Aung is a trekking guide in Kalaw and he has arranged a two-day camping trip for me and my brother. We can go trekking and enjoy the beautiful landscape. It would be an amazing experience and I'd like you to join us. We've already bought sleeping bags, backpacks and tents, so you don't need to worry about anything. We're leaving on 24th December. Hope you can join us. Best, Bo Bo.", "mm": "ဘိုဘို၏ ဖိတ်ကြားစာ အီးမေးလ်: ချစ်လှစွာသော ကံကောင်းနဲ့ မင်းမင်းရေ... စိတ်လှုပ်ရှားစရာ သတင်းကောင်း ပြောပြစရာရှိတယ်။ ကလောမြို့က တောင်တက်လမ်းညွှန် ဦးလေးအောင်က ငါနဲ့ ငါ့အစ်ကိုအတွက် နှစ်ရက်ကြာ စခန်းချတောင်တက်ခရီး စီစဉ်ပေးထားတယ်။ မင်းတို့ကိုလည်း အတူလိုက်စေချင်တယ်။ အိပ်ရာလိပ်၊ ကျောပိုးအိတ်နဲ့ ရွက်ဖျင်တဲတွေ အကုန်ဝယ်ပြီးသားမို့ ဘာမှစိတ်ပူစရာ မလိုပါဘူး။ ဒီဇင်ဘာ ၂၄ ရက်နေ့ ထွက်ကြမယ်။ ခင်မင်လျက် - ဘိုဘို။" },
          { "en": "Min Min's Reply (Accepting): Hello Bo Bo, Many thanks for your invitation. Yes, I'd love to join you. I've got my parents' permission. I've never been to Kalaw before, so I'm really looking forward to it. I'm sure this is going to be an amazing holiday. I will call you for more details. Hope to see you soon. Yours, Min Min.", "mm": "မင်းမင်း၏ ပြန်စာ (လက်ခံခြင်း): ဟယ်လို ဘိုဘို... ဖိတ်ကြားပေးလို့ ကျေးဇူးအများကြီးတင်ပါတယ်။ ငါ လိုက်ချင်တာပေါ့။ မိဘတွေဆီကလည်း ခွင့်ပြုချက် ရပြီးပြီ။ ကလောကို တစ်ခါမှ မရောက်ဖူးသေးလို့ အရမ်းကို မျှော်လင့်နေပါတယ်။ မကြာခင် တွေ့မယ်နော်။ မင်းရဲ့ - မင်းမင်း။" },
          { "en": "Kan Kaung's Reply (Declining): Hi Bo Bo, Thanks for your invitation. It would be exciting to go camping and trekking with you. But I'm afraid I can't. My grandma who lives in Monywa has fallen ill. I have to go and look after her during the December holiday. I hope I can join you next time. All the best, Kan Kaung.", "mm": "ကံကောင်း၏ ပြန်စာ (ငြင်းပယ်ခြင်း): ဟိုင်း ဘိုဘို... ဖိတ်ကြားပေးလို့ ကျေးဇူးတင်ပါတယ်။ မင်းတို့နဲ့အတူ စခန်းချခရီး သွားရရင် ပျော်စရာကြီး ဖြစ်မှာပါ။ ဒါပေမဲ့ ငါ မလိုက်နိုင်တော့ဘူးကွာ။ မုံရွာမှာနေတဲ့ အဘွား နေမကောင်းဖြစ်နေလို့ ဒီဇင်ဘာကျောင်းပိတ်ရက်မှာ သွားပြုစုပေးရမှာမို့လို့ပါ။ နောက်တစ်ခါကျမှပဲ လိုက်နိုင်ဖို့ မျှော်လင့်ပါတယ်။ ကံကောင်း။" }
        ]
      }
    ],
    "games": [
      { "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (Phone Phrasal Verbs)", "q": "တစ်ဖက်လူ အသံတိုးနေလို့ 'နည်းနည်းကျယ်ကျယ် ပြောပေးပါ' လို့ ပြောချင်ရင် ဘယ်စကားလုံး သုံးမလဲ?", "mode": "mcq", "options": ["pick up", "hold on", "speak up", "hang up"], "ans": 2, "explain": "'speak up' ဆိုတာ အသံပိုကျယ်ကျယ် ပြောပေးဖို့ တောင်းဆိုတာပါ။" },
      { "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Be going to)", "q": "'ကျွန်ုပ်သည် ပုဂံသို့ အပျော်စီးသင်္ဘောဖြင့် သွားမည်' ကို စာကြောင်းစီပါ။", "mode": "scramble", "words": ["I", "am", "going", "to", "take", "a", "cruise", "to", "Bagan."], "explain": "ကြိုတင်ဆုံးဖြတ်ထားပြီးသား အစီအစဉ်တွေအတွက် 'am/is/are going to + V-infinitive' ကို သုံးရပါတယ်။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Will vs Be going to)", "q": "The floor is wet. He _____ slip on it.", "mode": "mcq", "options": ["will", "is going to", "won't", "going to"], "ans": 1, "explain": "လက်ရှိမြင်နေရတဲ့ အထောက်အထား (ကြမ်းပြင်စိုနေခြင်း) ကို ကြည့်ပြီး ခန့်မှန်းတဲ့အခါ 'is going to' ကို သုံးရပါတယ်။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Holiday Types)", "q": "On a _____ holiday, you can do watersports such as canoeing, scuba diving and snorkelling.", "mode": "mcq", "options": ["adventure", "camping", "cruise", "mountain"], "ans": 2, "explain": "အပျော်စီးသင်္ဘောခရီးစဉ် (cruise holiday) မှာ ရေပေါ်အားကစားမျိုးစုံ ကစားနိုင်ပါတယ်။" },
      { "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Lesson 4 Check)", "q": "ကံကောင်း (Kan Kaung) ဟာ မုံရွာမှာရှိတဲ့ အဘွား နေမကောင်းဖြစ်နေလို့ ကလောခရီးစဉ်ကို မလိုက်နိုင်ခဲ့ပါဘူး။", "mode": "mcq", "options": ["မှန်တယ် (True)", "မှားတယ် (False)"], "ans": 0, "explain": "မှန်ပါတယ်! အဘွားကို ပြုစုဖို့ မုံရွာသွားရမှာမို့ ယဉ်ကျေးစွာ ငြင်းပယ်ခဲ့ပါတယ်။" }
    ]
  },
  {
    "title": "Unit 8: Resorts & Comparisons (အပန်းဖြေစခန်းများနှင့် နှိုင်းယှဉ်ပြောဆိုခြင်း)",
    "sections": [
      {
        "label": "Lesson 1",
        "title": "Lesson 1: A weekend at a resort (6 Types of Resorts)",
        "note": "💡 အပန်းဖြေစခန်း ၆ မျိုး: beach resort (ကမ်းခြေ)၊ mountain resort (တောင်ပေါ်)၊ eco-resort (သဘာဝပတ်ဝန်းကျင်ထိန်းသိမ်းရေး)၊ lake resort (ကန်ဘေး)၊ island resort (ကျွန်းပေါ်)၊ desert resort (သဲကန္တာရ)။",
        "passage": [
          { "en": "A resort is a place where many people go for rest and relaxation, sport, or health. There are six different types of resorts which are popular with holiday lovers.", "mm": "အပန်းဖြေစခန်း (Resort) ဆိုတာ လူအများစု အနားယူအပန်းဖြေဖို့၊ အားကစားလုပ်ဖို့ ဒါမှမဟုတ် ကျန်းမာရေးအတွက် သွားရောက်ကြတဲ့ နေရာတစ်ခု ဖြစ်ပါတယ်။" },
          { "en": "A beach resort is located next to the sea. It offers a range of activities such as horseback riding, beach volleyball, snorkelling, kayaking, scuba diving, windsurfing and jet skiing.", "mm": "ကမ်းခြေအပန်းဖြေစခန်းဟာ ပင်လယ်ဘေးမှာ တည်ရှိပြီး မြင်းစီးခြင်း၊ ကမ်းခြေဘော်လီဘော၊ ရေငုပ်ခြင်းနဲ့ လှေလှော်ခြင်းစတဲ့ ကစားနည်းမျိုးစုံကို ဝန်ဆောင်မှုပေးပါတယ်။" },
          { "en": "A mountain resort is a place located in a mountainous area. Visitors can enjoy the scenic views of the mountains and go camping, hiking and trekking.", "mm": "တောင်ပေါ်အပန်းဖြေစခန်းဟာ တောင်တန်းဒေသမှာ တည်ရှိပြီး လှပတဲ့ တောင်တန်းရှုခင်းတွေကို ခံစားရင်း စခန်းချခြင်းနဲ့ တောင်တက်ခရီးထွက်ခြင်းတွေ လုပ်ဆောင်နိုင်ပါတယ်။" },
          { "en": "An eco-resort is a tourist resort whose facilities are intended to have a minimal impact on the local environment. It also focuses on wildlife conservation, so visitors can observe lions, tigers, giraffes, etc. in their natural habitats.", "mm": "သဘာဝပတ်ဝန်းကျင်ထိန်းသိမ်းရေး အပန်းဖြေစခန်း (Eco-resort) ဟာ ဒေသပတ်ဝန်းကျင်ကို ထိခိုက်မှု အနည်းဆုံးဖြစ်အောင် စီမံထားပြီး တောရိုင်းတိရစ္ဆာန် ထိန်းသိမ်းရေးကို အဓိကထားပါတယ်။" },
          { "en": "A lake resort is located near a lake for swimming, boating and fishing. An island resort is located on an island for parasailing and water sports. A desert resort is usually located in an oasis in a desert where visitors can try camel rides, sandboarding, and stargazing.", "mm": "ကန်ဘေးအပန်းဖြေစခန်းမှာ လှေစီး၊ ငါးမျှားနိုင်ပြီး ကျွန်းအပန်းဖြေစခန်းမှာ လေထီးစီး၊ ရေပေါ်ကစားနည်းတွေ ကစားနိုင်ပါတယ်။ သဲကန္တာရအပန်းဖြေစခန်းကတော့ အိုအေစစ်မှာ ရှိပြီး ကုလားအုတ်စီးခြင်းနဲ့ ကြယ်ကြည့်ခြင်းတွေ ပြုလုပ်နိုင်ပါတယ်။" }
        ]
      },
      {
        "label": "Lesson 2",
        "title": "Lesson 2: Heaven or Paradise? (Heaven Resort vs Paradise Resort)",
        "note": "💡 ဝေါဟာရမှတ်စု: spacious (ကျယ်ဝန်းသော)၊ fully furnished (ပရိဘောဂ အပြည့်အစုံပါသော)၊ patio (အိမ်ရှေ့ဝရန်တာ)၊ unique (တစ်မူထူးခြားသော)၊ kitchenette (မီးဖိုချောင်ငယ်လေး)။",
        "passage": [
          { "en": "Heaven Resort: Located on an island in the coastal region of Myanmar, the Heaven Resort is a wonderful place for fun seekers and nature lovers. The best way to get there is by plane.", "mm": "Heaven Resort: မြန်မာနိုင်ငံ ကမ်းရိုးတန်းဒေသရှိ ကျွန်းတစ်ကျွန်းပေါ်မှာ တည်ရှိပြီး ပျော်ရွှင်မှုရှာဖွေသူတွေနဲ့ သဘာဝချစ်မြတ်နိုးသူတွေအတွက် အံ့ဩဖွယ်နေရာတစ်ခု ဖြစ်ပါတယ်။ လေယာဉ်နဲ့ သွားရောက်ဖို့ အကောင်းဆုံး ဖြစ်ပါတယ်။" },
          { "en": "The resort has all the facilities of a five-star hotel - free Wi-Fi, a huge car park, a fitness centre, and a swimming pool. All the rooms are fully furnished and spacious. Moreover, there is also a patio with a beautiful garden for each room.", "mm": "ကြယ်ငါးပွင့်ဟိုတယ်တစ်ခုရဲ့ ဝန်ဆောင်မှုအားလုံး (အခမဲ့ Wi-Fi၊ ကားပါကင်ကြီး၊ အားကစားခန်းမနဲ့ ရေကူးကန်) ပါရှိပါတယ်။ အခန်းတိုင်းမှာ ပရိဘောဂ အပြည့်အစုံပါပြီး ကျယ်ဝန်းကာ လှပတဲ့ ဥယျာဉ်ငယ်ပါတဲ့ ဝရန်တာလေးလည်း ပါရှိပါတယ်။" },
          { "en": "The resort also provides fresh and delicious seafood for food lovers. Nightlife seekers can enjoy the evening music and dance performance by local bands. You can do diving, snorkelling, scuba diving, fishing and sailing, or take a special trip to Mermaid Island.", "mm": "လတ်ဆတ်တဲ့ ပင်လယ်စာတွေ၊ ညနေခင်း ဒေသခံတီးဝိုင်းရဲ့ ဂီတဖျော်ဖြေပွဲတွေ ရှိသလို ရေငုပ်ခြင်း၊ ရွက်လွှင့်ခြင်းနဲ့ Mermaid ကျွန်းဆီ အထူးခရီးစဉ် သွားရောက်ခြင်းတွေ ပြုလုပ်နိုင်ပါတယ်။" },
          { "en": "Paradise Resort: The Paradise Resort is an eco-resort in the northern part of Myanmar. It is an ideal place for families and for those who want to see adventure. You can get there by car, train, or plane.", "mm": "Paradise Resort: မြန်မာနိုင်ငံမြောက်ပိုင်းမှာရှိတဲ့ သဘာဝပတ်ဝန်းကျင်ထိန်းသိမ်းရေး အပန်းဖြေစခန်းဖြစ်ပြီး မိသားစုတွေနဲ့ စွန့်စားခန်းကြိုက်သူတွေအတွက် အသင့်တော်ဆုံး နေရာဖြစ်ပါတယ်။ ကား၊ ရထား ဒါမှမဟုတ် လေယာဉ်နဲ့ သွားနိုင်ပါတယ်။" },
          { "en": "The hotel offers a unique experience of living in a tree house. For those who are afraid of heights, there are also bungalows. Self-catering facilities are available in this resort. There is an organic farm where you can pluck fresh vegetables. You can cook your meals in the kitchenette.", "mm": "သစ်ပင်ပေါ်က အိမ်လေးတွေမှာ နေထိုင်ရတဲ့ ထူးခြားတဲ့ အတွေ့အကြုံကို ပေးစွမ်းပြီး အမြင့်ကြောက်သူတွေအတွက် ဘန်ဂလိုတွေလည်း ရှိပါတယ်။ သဘာဝစိုက်ခင်းထဲက လတ်ဆတ်တဲ့ ဟင်းသီးဟင်းရွက်တွေ ကိုယ်တိုင်ခူးဆွတ်ပြီး မီးဖိုချောင်ငယ်လေးထဲမှာ ချက်ပြုတ်စားသောက်နိုင်ပါတယ်။" },
          { "en": "The resort is surrounded with natural springs and waterfalls, and so you can enjoy swimming and fishing there. You can explore wildlife and put up your own tents on the campsite.", "mm": "သဘာဝစမ်းချောင်းတွေ၊ ရေတံခွန်တွေ ဝန်းရံထားတာကြောင့် ရေကူးခြင်း၊ ငါးမျှားခြင်းတွေ လုပ်နိုင်သလို စခန်းချကွင်းမှာ ကိုယ်ပိုင်ရွက်ဖျင်တဲထိုးပြီး တောတွင်းညအိပ် ခံစားနိုင်ပါတယ်။" }
        ]
      },
      {
        "label": "Lesson 3 & 4",
        "title": "Lesson 3 & 4: Yangon vs Mandalay (Comparatives) & Dream Resorts",
        "note": "💡 သဒ္ဒါမှတ်စု: နှစ်ခုကို နှိုင်းယှဉ်ရာတွင် (၁) adjective-er + than (longer than)၊ (၂) more/less + adjective + than (more expensive than)၊ (၃) more/fewer + countable noun + than (fewer rooms than) တို့ကို သုံးရပါသည်။",
        "passage": [
          { "en": "Yangon and Mandalay, the two major cities in Myanmar, are different in many ways. With an area of 163.8 km², Mandalay is smaller than Yangon with 576 km² in area.", "mm": "မြန်မာနိုင်ငံရဲ့ အဓိကမြို့ကြီး နှစ်မြို့ဖြစ်တဲ့ ရန်ကုန်နဲ့ မန္တလေးတို့ဟာ နည်းလမ်းများစွာနဲ့ ကွဲပြားခြားနားပါတယ်။ ဧရိယာ ၁၆၃.၈ စတုရန်းကီလိုမီတာရှိတဲ့ မန္တလေးမြို့ဟာ ၅၇၆ စတုရန်းကီလိုမီတာရှိတဲ့ ရန်ကုန်မြို့ထက် ပိုသေးငယ်ပါတယ်။" },
          { "en": "Visitors to Mandalay can have the wonderful experience of cycling around the city. There are more bicycles and motorbikes in Mandalay than in Yangon. Yangon, however, is less popular among cyclists than Mandalay as the roads in Yangon are always busy with cars and buses.", "mm": "မန္တလေးကို လာရောက်သူတွေဟာ မြို့အနှံ့ စက်ဘီးစီးရတဲ့ အတွေ့အကြုံကောင်းကို ရရှိနိုင်ပါတယ်။ မန္တလေးမှာ ရန်ကုန်ထက် စက်ဘီးနဲ့ ဆိုင်ကယ် ပိုများပါတယ်။ ရန်ကုန်လမ်းမတွေက ကားနဲ့ ဘတ်စ်ကားတွေ အမြဲရှုပ်နေတာကြောင့် စက်ဘီးစီးသူတွေကြားမှာ ရန်ကုန်က လူကြိုက်ပိုနည်းပါတယ်။" },
          { "en": "Being an ancient capital, Mandalay is more attractive to visitors who want to observe Myanmar traditional arts and handicrafts. Yangon, on the other hand, has more colonial buildings. Being a commercial city, Yangon is more populated and the cost of living is higher than that of Mandalay.", "mm": "ရှေးဟောင်းမြို့တော်ဖြစ်တဲ့ မန္တလေးဟာ မြန်မာ့ရိုးရာ အနုပညာနဲ့ လက်မှုပညာတွေ လေ့လာချင်သူတွေအတွက် ပိုမိုဆွဲဆောင်မှု ရှိပါတယ်။ တစ်ဖက်မှာတော့ ရန်ကုန်မှာ ကိုလိုနီခေတ် အဆောက်အအုံတွေ ပိုများပြီး စီးပွားရေးမြို့တော်ဖြစ်တာကြောင့် လူဦးရေ ပိုထူထပ်ကာ လူနေမှုစရိတ်လည်း ပိုမြင့်မားပါတယ်။" },
          { "en": "The Flamingo Resort: Located near Flamingo Lake in the northern part of the country, it is a pet-friendly lake resort. Guests can stay in a houseboat, go birdwatching, canoeing and swimming, but they must avoid hunting, fishing, shooting birds and littering.", "mm": "Flamingo Resort: နိုင်ငံမြောက်ပိုင်း ဖလမင်ဂိုအင်း (Flamingo Lake) အနီးမှာ တည်ရှိပြီး အိမ်မွေးတိရစ္ဆာန် ခေါ်ဆောင်ခွင့်ပြုတဲ့ ကန်ဘေးအပန်းဖြေစခန်း ဖြစ်ပါတယ်။ ဧည့်သည်တွေဟာ အိမ်လှေပေါ်မှာ တည်းခိုခြင်း၊ ငှက်ကြည့်ခြင်းနဲ့ လှေလှော်ခြင်းတွေ လုပ်နိုင်ပေမဲ့ အမဲလိုက်ခြင်း၊ ငှက်ပစ်ခြင်းနဲ့ အမှိုက်ပစ်ခြင်းတွေကို ရှောင်ကြဉ်ရပါမယ်။" }
        ]
      }
    ],
    "games": [
      { "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (Resort Vocabulary)", "q": "ကိုယ်တိုင် ဟင်းချက်စားလို့ရတဲ့ မီးဖိုချောင်ငယ်လေးကို အင်္ဂလိပ်လို ဘယ်လိုခေါ်လဲ?", "mode": "mcq", "options": ["patio", "bungalow", "kitchenette", "minibar"], "ans": 2, "explain": "'kitchenette' ဆိုတာ အခန်းတွင်းမှာ ပါဝင်တဲ့ မီးဖိုချောင်ငယ်လေးကို ခေါ်တာပါ။" },
      { "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Grammar: Comparatives)", "q": "'ဧရာဝတီမြစ်သည် ချင်းတွင်းမြစ်ထက် ပိုရှည်သည်' ကို စာကြောင်းစီပါ။", "mode": "scramble", "words": ["The", "Ayeyarwady", "River", "is", "longer", "than", "the", "Chindwin."], "explain": "နှစ်ခုကို နှိုင်းယှဉ်တဲ့ Comparative မှာ 'adjective-er + than' ပုံစံ သုံးရပါတယ်။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Countable vs Uncountable)", "q": "The King Hotel has 20 rooms and the Queen Hotel has 40 rooms. The King Hotel has _____ rooms than the Queen Hotel.", "mode": "mcq", "options": ["less", "fewer", "more", "smaller"], "ans": 1, "explain": "'rooms' ဟာ ရေတွက်လို့ရတဲ့ အများကိန်းနာမ် (Countable noun) ဖြစ်လို့ 'ပိုနည်းသည်' အတွက် 'fewer' ကို သုံးရပါတယ်။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Desert Resort)", "q": "A desert resort is usually located in an _____ in a desert.", "mode": "mcq", "options": ["island", "oasis", "waterfall", "valley"], "ans": 1, "explain": "သဲကန္တာရထဲက ရေနှင့် အပင်များရှိရာ အိုအေစစ် ('oasis') မှာ Desert resort တည်ရှိပါတယ်။" },
      { "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Lesson 2 Check)", "q": "Paradise Resort မှာ ဧည့်သည်တွေဟာ သဘာဝစိုက်ခင်းထဲက ဟင်းသီးဟင်းရွက်တွေ ကိုယ်တိုင်ခူးပြီး ချက်ပြုတ်နိုင်ပါတယ်။", "mode": "mcq", "options": ["မှန်တယ် (True)", "မှားတယ် (False)"], "ans": 0, "explain": "မှန်ပါတယ်! Self-catering facilities နဲ့ organic farm ပါရှိပါတယ်။" }
    ]
  },
  {
    "title": "Unit 9: Beautiful Myanmar & Day Trips (လှပသော မြန်မာပြည်နှင့် ခရီးစဉ်များ)",
    "sections": [
      {
        "label": "Lesson 1",
        "title": "Lesson 1: What is the biggest lake in Myanmar? (Mon State Trip)",
        "note": "💡 မြန်မာ့ပထဝီဝင် ဗဟုသုတ: အမြင့်ဆုံးတောင် = ခါကာဘိုရာဇီ (Mt Hkakabo Razi)၊ အရှည်ဆုံးမြစ် = ဧရာဝတီမြစ်၊ အကြီးဆုံးအင်း = အင်းတော်ကြီးအင်း (Indawgyi)၊ အကြီးဆုံးကျွန်း = ရမ်းဗြဲကျွန်း (Ramree)၊ အကြီးဆုံးချိုင့်ဝှမ်း = ဟူးကောင်းချိုင့်ဝှမ်း (Hukawng)။",
        "passage": [
          { "en": "Thiha: Hi, Marlar. I haven't seen you for a week. I heard you went on a trip. How was it?", "mm": "သီဟ: ဟိုင်း မာလာ။ နင့်ကို မတွေ့တာ တစ်ပတ်တောင် ရှိပြီ။ ခရီးထွက်သွားတယ်လို့ ကြားတယ်။ ခရီးစဉ် ဘယ်လိုနေလဲ?" },
          { "en": "Marlar: Amazing! I went to four different places in Mon State. Well, we started off by driving to the Kyaikhtiyo Pagoda near Kyaikhto.", "mm": "မာလာ: အရမ်းမိုက်တယ်! မွန်ပြည်နယ်က မတူညီတဲ့ နေရာ ၄ ခုကို ရောက်ခဲ့တယ်။ ကျိုက်ထိုမြို့အနီးက ကျိုက်ထီးရိုးဘုရားကို ကားမောင်းသွားရင်း ခရီးစတင်ခဲ့တာပေါ့။" },
          { "en": "Thiha: What do you think of the pagoda? — Marlar: Oh, it's a real wonder! It's built on the top of a huge boulder standing on the edge of a mountain. It's also known as the Golden Rock Pagoda.", "mm": "သီဟ: ဘုရားဖူးရတာ ဘယ်လိုနေလဲ? — မာလာ: တကယ့်ကို အံ့ဩစရာပါပဲ! တောင်စွန်းပေါ်မှာ မေးတင်နေတဲ့ ကျောက်တုံးကြီးပေါ်မှာ တည်ထားတာလေ။ Golden Rock Pagoda လို့လည်း လူသိများတယ်။" },
          { "en": "Marlar: Then we drove across the Thanlwin Bridge to Mawlamyine. We spent two nights there, visiting a few ancient pagodas and monasteries, shopping in the daytime, and going out at night.", "mm": "မာလာ: ပြီးတော့ သံလွင်တံတားကို ဖြတ်ပြီး မော်လမြိုင်ကို သွားခဲ့တယ်။ အဲဒီမှာ နှစ်ညအိပ်ပြီး ရှေးဟောင်းဘုရားတွေနဲ့ ဘုန်းတော်ကြီးကျောင်းတွေ လည်ပတ်ခဲ့ကြတယ်။" },
          { "en": "Marlar: Yes, we went to Setse Beach. It's a beautiful sandy beach stretching for about four miles. Finally, we went to Bilu Island. It's a beautiful island with lots of paddy fields and rubber plantations. It's famous for its local products like coconut mats, bamboo hats, wooden pipes and rubber bands.", "mm": "မာလာ: ၄ မိုင်လောက် ရှည်လျားတဲ့ စက်စဲကမ်းခြေကိုလည်း ရောက်ခဲ့တယ်။ နောက်ဆုံးမှာ စပါးခင်းတွေ၊ ရာဘာခြံတွေနဲ့ လှပတဲ့ ဘီလူးကျွန်းကို သွားခဲ့တယ်။ အုန်းဆံဖျာ၊ ဝါးခမောက်၊ သစ်သားဆေးတံနဲ့ သားရေကွင်းလို ဒေသထွက်ကုန်တွေကြောင့် နာမည်ကြီးတယ်လေ။" }
        ]
      },
      {
        "label": "Lesson 2",
        "title": "Lesson 2: Beautiful Myanmar (4 Natural Wonders)",
        "note": "💡 ဝေါဟာရမှတ်စု: majestically (ခမ်းနားထည်ဝါစွာ)၊ confluence (မြစ်ဆုံရာနေရာ)၊ enormous (အလွန်ကြီးမားသော)၊ biodiversity (ဇီဝမျိုးစုံမျိုးကွဲများ)။",
        "passage": [
          { "en": "Snow-capped Mountains: Snow-capped mountains are the birthplace of numerous rivers and lakes. The splendid snow-capped mountains stand majestically in Kachin State, the northernmost part of Myanmar. To enjoy the amazing views of those snow-capped mountains, it is necessary to make a journey to Putao, the northernmost town of Kachin State. Among these mountains, Mt Hkakabo Razi, which is part of the Himalayan mountain range, stands gloriously as the highest mountain in Southeast Asia. It is 5,881 metres high.", "mm": "ဆီးနှင်းဖုံးတောင်တန်းများ: ဆီးနှင်းဖုံးတောင်တန်းတွေဟာ မြစ်ချောင်းနဲ့ အင်းအိုင်များစွာရဲ့ မြစ်ဖျားခံရာ မွေးရပ်မြေ ဖြစ်ပါတယ်။ မြန်မာနိုင်ငံ မြောက်ဘက်အစွန်ဆုံး ကချင်ပြည်နယ်မှာ ခမ်းနားထည်ဝါစွာ တည်ရှိနေပြီး ပူတာအိုမြို့ကို သွားရောက်လည်ပတ်မှ မြင်တွေ့နိုင်ပါတယ်။ ဟိမဝန္တာတောင်တန်းရဲ့ အစိတ်အပိုင်းဖြစ်တဲ့ ခါကာဘိုရာဇီတောင်ဟာ အမြင့် ၅,၈၈၁ မီတာရှိပြီး အရှေ့တောင်အာရှရဲ့ အမြင့်ဆုံးတောင် ဖြစ်ပါတယ်။" },
          { "en": "Sadan Cave: With its beautiful scenery, Sadan Cave is a popular holiday destination. It is located near the city of Hpa-an in Kayin State. It is an enormous cave with lots of Buddha images, wall carvings and beautiful columns of rocks hanging from the roof. When you come out from the cave, there is a small river outside. And you can take a boat trip to enjoy the wonderful views around the cave. Sadan Cave is one of the longest caves in Myanmar.", "mm": "ဆဒ္ဒန်ဂူ: သာယာလှပတဲ့ ရှုခင်းတွေကြောင့် ဆဒ္ဒန်ဂူဟာ နာမည်ကျော် အားလပ်ရက် ခရီးစဉ်နေရာတစ်ခု ဖြစ်ပါတယ်။ ကရင်ပြည်နယ် ဘားအံမြို့အနီးမှာ တည်ရှိပြီး ဗုဒ္ဓရုပ်ပွားတော်တွေ၊ နံရံပန်းပုလက်ရာတွေနဲ့ ကျောက်စက်ပန်းဆွဲတွေ ရှိတဲ့ ဂူကြီးတစ်ဂူပါ။ ဂူအပြင်ဘက်က ချောင်းငယ်လေးမှာ လှေစီးပြီး ရှုခင်းတွေ ကြည့်ရှုနိုင်ပါတယ်။" },
          { "en": "Ngapali Beach: Located on the Bay of Bengal, Ngapali Beach is about 7 kilometres away from the town of Thandwe in Rakhine State of Myanmar. The beach, which stretches for about 3 kilometres, is famous as Myanmar's most impressive tourist attraction, and one of the most beautiful beaches in the world. It is well-known for its soft and creamy sand, its unspoiled water and its green palm trees. You can do kayaking, scuba diving, and snorkelling.", "mm": "ငပလီကမ်းခြေ: ဘင်္ဂလားပင်လယ်အော် ကမ်းခြေမှာ တည်ရှိပြီး ရခိုင်ပြည်နယ် သံတွဲမြို့ကနေ ၇ ကီလိုမီတာခန့် အကွာမှာ ရှိပါတယ်။ ၃ ကီလိုမီတာခန့် ရှည်လျားပြီး နူးညံ့ဖြူဖွေးတဲ့ သဲသောင်ပြင်၊ သန့်ရှင်းကြည်လင်တဲ့ ပင်လယ်ရေနဲ့ စိမ်းလန်းတဲ့ အုန်းပင်တွေကြောင့် ကမ္ဘာ့အလှဆုံး ကမ်းခြေတစ်ခုအဖြစ် ကျော်ကြားပါတယ်။" },
          { "en": "The Ayeyarwady River: The Ayeyarwady River is the longest and largest river in Myanmar. Born of the confluence of the N'Mai Hka and Mali Hka rivers in Kachin State, the Ayeyarwady River makes a long journey of 2,210 kilometres. It flows through the country to its destination - the Andaman Sea. Along its banks stand many ancient capitals of the Kingdoms of Myanmar, which are part of our cultural and historical heritage. In fact, the Ayeyarwady River is the backbone as well as the lifeblood of the people of Myanmar.", "mm": "ဧရာဝတီမြစ်: ဧရာဝတီမြစ်ဟာ မြန်မာနိုင်ငံရဲ့ အရှည်ဆုံးနဲ့ အကြီးဆုံးမြစ် ဖြစ်ပါတယ်။ ကချင်ပြည်နယ်ရှိ မေခနဲ့ မလိခ မြစ်နှစ်သွယ် ပေါင်းဆုံရာကနေ မြစ်ဖျားခံပြီး ကပ္ပလီပင်လယ်အထိ ၂,၂၁၀ ကီလိုမီတာ စီးဆင်းပါတယ်။ မြစ်ကမ်းတစ်လျှောက်မှာ ရှေးဟောင်းမင်းနေပြည်တော်တွေ တည်ရှိပြီး မြန်မာပြည်သူတွေရဲ့ ကျောရိုးမကြီးနဲ့ အသက်သွေးကြော ဖြစ်ပါတယ်။" }
        ]
      },
      {
        "label": "Lesson 3 & 4",
        "title": "Lesson 3 & 4: Hlawga National Park & A Memorable Holiday (Chaung Tha)",
        "note": "💡 သဒ္ဒါမှတ်စု: Prepositions of Time -> in (လ/နှစ်/ရာသီ - in April)၊ at (နာရီအတိအကျ - at 9 a.m.)၊ on (နေ့ရက်/ရက်စွဲ - on Sundays, on 5th October)။",
        "passage": [
          { "en": "Hlawga National Park is a fantastic place for city dwellers who want to explore nature and do outdoor activities. It is located in Mingaladon Township, about an hour's drive from downtown Yangon. It was established on 30th September 1982 and opened to the public in 1989. The park has an area of 1,540 acres, consisting of a wildlife park, a mini-zoo and a buffer zone. You can see various types of mammals, reptiles and birds in the wildlife park.", "mm": "လှော်ကားအမျိုးသားဥယျာဉ်: သဘာဝတရားကို စူးစမ်းလိုတဲ့ မြို့နေလူထုအတွက် အလွန်ကောင်းမွန်တဲ့ နေရာတစ်ခု ဖြစ်ပါတယ်။ ရန်ကုန်မြို့လယ်ကနေ ကားနဲ့ ၁ နာရီခန့် မောင်းရတဲ့ မင်္ဂလာဒုံမြို့နယ်မှာ တည်ရှိပြီး ၁၉၈၂ ခုနှစ် စက်တင်ဘာ ၃၀ ရက်နေ့မှာ တည်ထောင်ခဲ့ပါတယ်။ ဧက ၁,၅၄၀ ကျယ်ဝန်းပြီး နို့တိုက်သတ္တဝါ၊ တွားသွားသတ္တဝါနဲ့ ငှက်မျိုးစုံကို ကြည့်ရှုနိုင်ပါတယ်။" },
          { "en": "A Memorable Holiday (Chaung Tha): Have you ever done anything on impulse? We have. It was in April, last year. It was rather a hot day. My parents, my sister and I were at home, having the usual breakfast - fried rice and fried eggs. I said, 'How lovely it would be to go to a seaside!' My father replied, 'Why not?' We rushed to our rooms, packed our overnight bags, and got into the car. Off we went to Chaung Tha!", "mm": "အမှတ်တရ အားလပ်ရက်ခရီး (ချောင်းသာ): ရုတ်တရက် စိတ်ကူးပေါက်ပြီး ခရီးထွက်ဖူးပါသလား? ပြီးခဲ့တဲ့နှစ် ဧပြီလ ပူပြင်းတဲ့ နေ့တစ်နေ့မှာ မိသားစု မနက်စာစားနေရင်း ပင်လယ်ကမ်းခြေသွားရရင် ကောင်းမှာပဲလို့ ပြောလိုက်ရာ အဖေက သဘောတူတာနဲ့ အိတ်တွေပြင်ပြီး ချောင်းသာကို ချက်ချင်း ထွက်လာခဲ့ကြပါတယ်။" },
          { "en": "Chaung Tha, a popular beach resort located in Ayeyarwady Region, is only a five hours' drive from Yangon. It is famous for its fresh seafood, offshore islands, and fishing villages. At about 1 p.m., we arrived at Chaung Tha. All the hotels were full, so we gave up the plan to stay the night at a hotel. However, we hired some buoys, and made a dash for the blue sea. After an hour or so in the water, we enjoyed delicious fresh seafood - grilled fish and lobsters. Though it was not a perfect holiday, we loved it.", "mm": "ဧရာဝတီတိုင်းဒေသကြီးမှာရှိတဲ့ ချောင်းသာကမ်းခြေဟာ ရန်ကုန်ကနေ ကားနဲ့ ၅ နာရီခန့် မောင်းရပါတယ်။ နေ့လယ် ၁ နာရီမှာ ရောက်သွားတော့ ဟိုတယ်တွေ အကုန်ပြည့်နေတာကြောင့် ညမအိပ်တော့ဘဲ ဘောကွင်းငှားကာ ပင်လယ်ထဲ ရေဆင်းကူးခဲ့ကြပါတယ်။ ပြီးတော့ ငါးကင်နဲ့ ပုစွန်တုပ်လို လတ်ဆတ်တဲ့ ပင်လယ်စာတွေ စားသောက်ပြီး ညနေမှာ ရန်ကုန်ပြန်ခဲ့ကြပါတယ်။" }
        ]
      }
    ],
    "games": [
      { "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (Myanmar Geography)", "q": "မြန်မာနိုင်ငံမှာ အကြီးဆုံး အင်းကြီး (Largest lake) က ဘယ်အင်းလဲ?", "mode": "mcq", "options": ["အင်းလေးကန် (Inlay)", "အင်းတော်ကြီးအင်း (Indawgyi)", "အင်းယားကန် (Inya)", "ကန်တော်ကြီး (Kandawgyi)"], "ans": 1, "explain": "ကချင်ပြည်နယ်မှာရှိတဲ့ အင်းတော်ကြီးအင်း (Indawgyi Lake) ဟာ မြန်မာနိုင်ငံရဲ့ အကြီးဆုံးအင်း ဖြစ်ပါတယ်။" },
      { "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Grammar: Prepositions)", "q": "'ဥယျာဉ်သည် မနက် ၈ နာရီမှ ညနေ ၄ နာရီအထိ ဖွင့်သည်' ကို စာကြောင်းစီပါ။", "mode": "scramble", "words": ["The", "park", "is", "open", "from", "8 a.m.", "to", "4 p.m."], "explain": "အချိန်အစနဲ့ အဆုံးကို ဖော်ပြတဲ့အခါ 'from ... to ...' ကို သုံးရပါတယ်။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Prepositions of Time)", "q": "Hlawga National Park was established _____ 30th September 1982.", "mode": "mcq", "options": ["in", "at", "on", "since"], "ans": 2, "explain": "ရက်စွဲအတိအကျ (Dates) တွေရဲ့ အရှေ့မှာ အမြဲတမ်း 'on' ကို သုံးရပါတယ်။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Mt Popa - Review 3)", "q": "Mt Popa is an extinct volcano _____ central Myanmar, about 50 kilometres from Bagan.", "mode": "mcq", "options": ["in", "on", "at", "above"], "ans": 0, "explain": "ဒေသ/နိုင်ငံ အကျယ်အဝန်းအတွင်း တည်ရှိမှုအတွက် 'in' (in central Myanmar) ကို သုံးရပါတယ်။" },
      { "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Lesson 2 Check)", "q": "ဆဒ္ဒန်ဂူ (Sadan Cave) ဟာ ကရင်ပြည်နယ် ဘားအံမြို့အနီးမှာ တည်ရှိပါတယ်။", "mode": "mcq", "options": ["မှန်တယ် (True)", "မှားတယ် (False)"], "ans": 0, "explain": "မှန်ပါတယ်! 'It is located near the city of Hpa-an in Kayin State' လို့ ဖော်ပြထားပါတယ်။" }
    ]
  },
  {
    "title": "Unit 10: Pastimes & Healthy Lifestyle (အားလပ်ချိန်ဝါသနာနှင့် ကျန်းမာသောဘဝ)",
    "sections": [
      {
        "label": "Lesson 1",
        "title": "Lesson 1: My favourite pastime (4 Age Groups)",
        "note": "💡 အသက်အရွယ်အုပ်စု ၄ မျိုး: Teenager (ဆယ်ကျော်သက်)၊ Young adult (လူငယ်ပိုင်း)၊ Middle-aged adult (လူလတ်ပိုင်း)၊ Senior adult (သက်ကြီးပိုင်း)။",
        "passage": [
          { "en": "Min Min (Teenager): I am Min Min. I am 19 years old. I am a part-time library assistant. As a teenager, there are a lot of things I like doing in my free time. I love listening to music. My favourite pastime is playing football. My aim in life is to become a successful footballer like Messi.", "mm": "မင်းမင်း (ဆယ်ကျော်သက်): ကျွန်တော့်နာမည် မင်းမင်း၊ အသက် ၁၉ နှစ်ပါ။ အချိန်ပိုင်း စာကြည့်တိုက်အကူ ဖြစ်ပါတယ်။ အားလပ်ချိန်မှာ သီချင်းနားထောင်ရတာ နှစ်သက်ပြီး အကြိုက်ဆုံးဝါသနာက ဘောလုံးကန်ခြင်းပါ။ မက်ဆီလို အောင်မြင်တဲ့ ဘောလုံးသမား ဖြစ်ချင်ပါတယ်။" },
          { "en": "Nan San (Young adult): I am Nan San. I am 23. I am a flight attendant. As a young adult, I am active and eager to learn new things. I love jogging in the evenings. It keeps my heart and mind healthy. Moreover, studying languages is my favourite pastime. I can speak four languages. Now I am excited to study the Arabic language online.", "mm": "နန်းစံ (လူငယ်ပိုင်း): ကျွန်မနာမည် နန်းစံ၊ အသက် ၂၃ နှစ်ပါ။ လေယာဉ်မယ်တစ်ဦး ဖြစ်ပါတယ်။ ညနေခင်းတွေမှာ အပြေးလေ့ကျင့်ရတာ နှစ်သက်ပြီး ဘာသာစကားတွေ လေ့လာရတာက အကြိုက်ဆုံး ဝါသနာပါ။ ဘာသာစကား ၄ မျိုး ပြောတတ်ပြီး အခု အာရဗီဘာသာစကားကို အွန်လိုင်းကနေ လေ့လာနေပါတယ်။" },
          { "en": "Soe Soe (Middle-aged adult): I am Soe Soe. I am in my late forties. I am a dressmaker. I love making beautiful dresses. As I am in middle age, I am so busy doing household chores every day. I am lucky though. I can make my living as a dressmaker. And I also love growing indoor and outdoor plants.", "mm": "စိုးစိုး (လူလတ်ပိုင်း): ကျွန်မနာမည် စိုးစိုး၊ အသက် ၄၀ နှောင်းပိုင်း ရှိပါပြီ။ အမျိုးသမီးအဝတ်အထည် ချုပ်လုပ်သူပါ။ နေ့စဉ် အိမ်မှုကိစ္စတွေနဲ့ အလုပ်ရှုပ်ပေမဲ့ အဝတ်ချုပ်ရင်း အသက်မွေးဝမ်းကျောင်း ပြုနိုင်သလို အိမ်တွင်းအိမ်ပြင် အပင်လေးတွေ စိုက်ပျိုးရတာကိုလည်း နှစ်သက်ပါတယ်။" },
          { "en": "U Tin Tun (Senior adult): I am U Tin Tun. I am in my seventies. I am a retired petroleum engineer. I love reading newspapers or journals in English or Myanmar in the mornings. I am also interested in playing golf. As a senior adult, I am now getting into meditating, which is good for my physical and mental health.", "mm": "ဦးတင်ထွန်း (သက်ကြီးပိုင်း): ကျွန်တော်က ဦးတင်ထွန်း၊ အသက် ၇၀ ကျော်ပါပြီ။ အငြိမ်းစား ရေနံအင်ဂျင်နီယာ တစ်ဦးပါ။ မနက်ခင်းတွေမှာ အင်္ဂလိပ်-မြန်မာ သတင်းစာ၊ ဂျာနယ်တွေ ဖတ်ရတာ နှစ်သက်ပြီး ဂေါက်သီးရိုက်တာလည်း ဝါသနာပါပါတယ်။ အခုတော့ ကိုယ်စိတ်နှစ်ပါး ကျန်းမာဖို့ တရားထိုင်ခြင်းကို လုပ်ဆောင်နေပါတယ်။" }
        ]
      },
      {
        "label": "Lesson 2",
        "title": "Lesson 2: More time to relax (Benefits of Leisure Activities)",
        "note": "💡 ဝေါဟာရမှတ်စု: pressure (ဖိအား)၊ well-being (ကျန်းမာပျော်ရွှင်မှု)၊ refresh (လန်းဆန်းစေသည်)၊ satisfaction (စိတ်ကျေနပ်မှု)၊ concentrate (အာရုံစူးစိုက်သည်)။",
        "passage": [
          { "en": "Schooldays are the best days of our lives, but today, life can be hard for the majority of teenagers. This means that most teenagers are always worried about their homework, exams and marks. They get a lot of pressure from their teachers and parents. Ambitious parents want them to do well in the exam. As a result, many teenagers have less time for leisure activities. In fact, they need more time to relax and do what they like to do.", "mm": "ကျောင်းသားဘဝနေ့ရက်တွေဟာ ဘဝရဲ့ အကောင်းဆုံးနေ့ရက်တွေ ဖြစ်ပေမဲ့ ယနေ့ခေတ် ဆယ်ကျော်သက်အများစုဟာ အိမ်စာ၊ စာမေးပွဲနဲ့ အမှတ်တွေအတွက် အမြဲစိုးရိမ်ပူပန်နေရပါတယ်။ ဆရာဆရာမနဲ့ မိဘတွေဆီက ဖိအားတွေကြောင့် အားလပ်ချိန် ဝါသနာလှုပ်ရှားမှုတွေ လုပ်ဖို့ အချိန်နည်းပါးကြပါတယ်။" },
          { "en": "Free time is essential for our mental and physical well-being. Teenagers with hobbies are most likely to feel more relaxed and happier. Leisure activities are particularly important for their health, and a break from study can refresh their mind and body. After sitting at a desk all day, it is good for teenagers to go outside and do exercise.", "mm": "အားလပ်ချိန်ဟာ စိတ်ပိုင်းဆိုင်ရာနဲ့ ရုပ်ပိုင်းဆိုင်ရာ ကျန်းမာပျော်ရွှင်မှုအတွက် မရှိမဖြစ် လိုအပ်ပါတယ်။ ဝါသနာတစ်ခုခုရှိတဲ့ လူငယ်တွေဟာ ပိုပြီး စိတ်အပန်းပြေ ပျော်ရွှင်ကြပါတယ်။ စာကျက်ရာကနေ ခဏနားလိုက်ခြင်းက စိတ်နဲ့ခန္ဓာကို လန်းဆန်းစေပါတယ်။" },
          { "en": "Teenagers can also gain great satisfaction from following their hobbies. For example, when they have cooked a meal or painted a picture, they feel proud and confident. They will then realize that hobbies help them to concentrate more on their studies. Doing some leisure activities is a good way of meeting people and making new friends.", "mm": "မိမိဝါသနာပါရာ လုပ်ဆောင်ခြင်းကနေ စိတ်ကျေနပ်မှု အပြည့်အဝ ရရှိနိုင်ပါတယ်။ ဟင်းတစ်ခွက်ချက်လိုက်နိုင်တဲ့အခါ ဒါမှမဟုတ် ပန်းချီဆွဲလိုက်နိုင်တဲ့အခါ ဂုဏ်ယူစိတ်နဲ့ ယုံကြည်မှု ရရှိပြီး စာထဲမှာလည်း ပိုပြီး အာရုံစူးစိုက်နိုင်လာပါတယ်။" },
          { "en": "As teenagers are busy with their studies, it may be hard to find time to do leisure activities. In fact, having free time is an absolutely essential part of their daily routine. 'Take up a hobby, and have fun doing it, and learn new things'.", "mm": "စာကျက်ရတာနဲ့ အလုပ်ရှုပ်နေပေမဲ့ အားလပ်ချိန်ထားရှိခြင်းဟာ နေ့စဉ်ဘဝရဲ့ မရှိမဖြစ် အစိတ်အပိုင်း ဖြစ်ပါတယ်။ 'ဝါသနာတစ်ခုကို စတင်လုပ်ဆောင်ပါ၊ ပျော်ရွှင်စွာ လုပ်ဆောင်ရင်း အရာသစ်တွေကို သင်ယူပါ'။" }
        ]
      },
      {
        "label": "Lesson 3 & 4",
        "title": "Lesson 3 & 4: Gerunds vs To-infinitives & Healthy Family",
        "note": "💡 သဒ္ဒါမှတ်စု: (၁) Verb + Gerund (-ing): enjoy, avoid, finish, mind, practise, quit, suggest။ (၂) Verb + to-infinitive: decide, want, hope, wish, plan, promise, refuse, afford။ (၃) Do (yoga, karate, judo) / Go (swimming, hiking, fishing) / Play (football, badminton, the guitar)။",
        "passage": [
          { "en": "Swe Swe's Healthy Diet: Swe Swe enjoyed eating chocolate, cheese, sweets and potato chips. Then, she found that she was gaining weight. She decided to go on a diet. Her aunt offered to cook healthy food for her. Swe Swe stopped eating fast food, too. After a month, she had lost a few pounds, but she wanted to lose more. Her aunt also suggested that she should go to the gym. Swe Swe didn't fancy exercising, but she agreed to give it a try. She exercises every day and she looks better now. She hopes to lose more weight.", "mm": "ဆွေဆွေ၏ ကျန်းမာရေးနှင့်ညီညွတ်သော အစားအစာ: ဆွေဆွေဟာ ချောကလက်၊ ချိစ်၊ သကြားလုံးနဲ့ အာလူးကြော်တွေ စားရတာ နှစ်သက်ခဲ့ရာက ကိုယ်အလေးချိန် တက်လာတာကို သိရှိသွားပါတယ်။ ဒါကြောင့် အစားအသောက် ဆင်ခြင်ဖို့ ဆုံးဖြတ်ခဲ့ပြီး အဒေါ်က ကျန်းမာရေးနဲ့ညီညွတ်တဲ့ အစားအစာတွေ ချက်ကျွေးခဲ့ပါတယ်။ အခု နေ့တိုင်း လေ့ကျင့်ခန်းလုပ်ပြီး ကျန်းမာလှပနေပါပြီ။" },
          { "en": "A Happy Healthy Family: We always have a healthy diet to keep ourselves fit. My mum often tells us that eating habits are important for health. She suggests having organic fruit and vegetables. My sister enjoys eating them and she is planning to grow fruit and vegetables. My mum always prepares nutritious meals for us. She also says, 'We must avoid eating too much junk food such as potato chips and sweets'. We all have decided to follow her suggestions.", "mm": "ပျော်ရွှင်ကျန်းမာသော မိသားစု: ကျွန်ုပ်တို့ မိသားစုဟာ ကျန်းမာကြံ့ခိုင်နေစေဖို့ အာဟာရမျှတတဲ့ အစားအစာကို အမြဲစားသုံးကြပါတယ်။ အမေက သဘာဝသစ်သီးဝလံနဲ့ ဟင်းသီးဟင်းရွက်တွေ စားဖို့ အကြံပြုပြီး Junk food တွေ အလွန်အကျွံ မစားဖို့ အမြဲသတိပေးပါတယ်။" },
          { "en": "We usually do physical activities every day to stay healthy. My grandpa exercises every morning and plays golf twice a week. My grandma and my sister go for a walk in the early mornings. My father usually plays badminton with me and my mum does yoga at home for an hour a day. We play board games together after dinner and go hiking in the mountains on holiday.", "mm": "ကျန်းမာနေစေဖို့ နေ့စဉ် ကိုယ်လက်လှုပ်ရှားမှုတွေ လုပ်ကြပါတယ်။ အဘိုးက မနက်တိုင်း လေ့ကျင့်ခန်းလုပ်ပြီး တစ်ပတ်နှစ်ကြိမ် ဂေါက်သီးရိုက်ပါတယ်။ အဖေက ကြက်တောင်ရိုက်ပြီး အမေက ယောဂကျင့်ပါတယ်။ ညစာစားပြီးရင် မိသားစုအတူ ဘုတ်ဂိမ်းကစားကြပြီး ကျောင်းပိတ်ရက်တွေမှာ တောင်တက်ခရီး ထွက်ကြပါတယ်။" }
        ]
      }
    ],
    "games": [
      { "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (Do / Go / Play)", "q": "'aerobics, judo, karate, yoga' စတဲ့ ကိုယ်လက်လှုပ်ရှားမှုတွေနဲ့ တွဲသုံးရမယ့် ကြိယာက ဘာလဲ?", "mode": "mcq", "options": ["play", "go", "do", "make"], "ans": 2, "explain": "ဘောလုံးမပါတဲ့ ကိုယ်ခံပညာနဲ့ လေ့ကျင့်ခန်းတွေ (do karate, do yoga, do aerobics) အတွက် 'do' ကို သုံးပါတယ်။" },
      { "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Gerund vs To-infinitive)", "q": "'သူမသည် ကျန်းမာရေးနှင့်ညီညွတ်သော အစားအစာစားရန် ဆုံးဖြတ်ခဲ့သည်' ကို စီပါ။", "mode": "scramble", "words": ["She", "decided", "to", "eat", "healthy", "food."], "explain": "'decide' ကြိယာနောက်မှာ အမြဲတမ်း 'to + V-infinitive' (to eat) လိုက်ရပါတယ်။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Verb + Gerund)", "q": "Would you mind _____ the kitchen, please? It's rather messy.", "mode": "mcq", "options": ["clean", "to clean", "cleaning", "cleaned"], "ans": 2, "explain": "'Would you mind' နောက်မှာ အမြဲတမ်း Verb-ing (cleaning) ကို သုံးရပါတယ်။ (Lesson 3 Ex. 3)" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Verb + To-infinitive)", "q": "I can't afford _____ an iPhone; it's very expensive.", "mode": "mcq", "options": ["buying", "to buy", "buy", "bought"], "ans": 1, "explain": "'afford' နောက်မှာ 'to + V-infinitive' (to buy) ကို သုံးရပါတယ်။" },
      { "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Lesson 1 Check)", "q": "လေယာဉ်မယ် နန်းစံ (Nan San) ဟာ ဘာသာစကား ၄ မျိုး ပြောတတ်ပြီး အခု အာရဗီဘာသာစကားကို လေ့လာနေပါတယ်။", "mode": "mcq", "options": ["မှန်တယ် (True)", "မှားတယ် (False)"], "ans": 0, "explain": "မှန်ပါတယ်! 'I can speak four languages. Now I am excited to study the Arabic language online' လို့ ပါရှိပါတယ်။" }
    ]
  },
  {
    "title": "Unit 11: Digital Devices & Conditionals (ဒစ်ဂျစ်တယ်ပစ္စည်းများ)",
    "sections": [
      {
        "label": "Lesson 1",
        "title": "Lesson 1: My favourite digital device (Vocabulary & Dialogue)",
        "note": "💡 ဒစ်ဂျစ်တယ်ပစ္စည်းများ: desktop computer (စားပွဲတင်ကွန်ပျူတာ)၊ laptop (လက်တော့ပ်)၊ tablet (တက်ဘလက်)၊ smartphone (စမတ်ဖုန်း)၊ smartwatch (စမတ်နာရီ)၊ digital camera (ဒစ်ဂျစ်တယ်ကင်မရာ)၊ e-book reader (အီးဘွတ်ဖတ်စက်)၊ game console (ဂိမ်းစက်)။",
        "passage": [
          { "en": "A: What is your favourite digital device?", "mm": "A: မင်း အကြိုက်ဆုံး ဒစ်ဂျစ်တယ်ပစ္စည်းက ဘာလဲ?" },
          { "en": "B: My favourite digital device is my smartphone because it is small, lightweight, and portable.", "mm": "B: ငါအကြိုက်ဆုံး ဒစ်ဂျစ်တယ်ပစ္စည်းကတော့ စမတ်ဖုန်းပါပဲ၊ ဘာလို့လဲဆိုတော့ သေးငယ်ပေါ့ပါးပြီး နေရာတကာ သယ်သွားလို့ လွယ်ကူလို့ပါ။" },
          { "en": "A: What do you usually use it for?", "mm": "A: အဲဒါကို ဘာအတွက် အဓိက သုံးလေ့ရှိသလဲ?" },
          { "en": "B: I use it to make phone calls, send text messages, take photos, listen to music, and search for information for my school lessons.", "mm": "B: ဖုန်းခေါ်ဖို့၊ စာတိုပို့ဖို့၊ ဓာတ်ပုံရိုက်ဖို့၊ သီချင်းနားထောင်ဖို့နဲ့ ကျောင်းသင်ခန်းစာအတွက် အချက်အလက်တွေ ရှာဖွေဖို့ သုံးပါတယ်။" },
          { "en": "A: How about your brother? What digital device does he like most?", "mm": "A: မင်းအစ်ကိုကရော? သူက ဘယ်ဒစ်ဂျစ်တယ်ပစ္စည်းကို အကြိုက်ဆုံးလဲ?" },
          { "en": "B: He prefers a laptop because he can type essays, prepare presentations, and attend online classes easily on a bigger screen.", "mm": "B: သူကတော့ ဖန်သားပြင် ပိုကြီးကြီးပေါ်မှာ စာစီစာကုံးရိုက်ဖို့၊ Presentation လုပ်ဖို့နဲ့ အွန်လိုင်းအတန်းတက်ဖို့ လွယ်ကူတာကြောင့် လက်တော့ပ် (Laptop) ကို ပိုကြိုက်ပါတယ်။" }
        ]
      },
      {
        "label": "Lesson 2",
        "title": "Lesson 2: Do you have a mobile phone? (Advantages & Disadvantages)",
        "note": "💡 ဝေါဟာရမှတ်စု: advantages (အားသာချက်များ)၊ disadvantages (အားနည်းချက်များ)၊ instant communication (ချက်ချင်းဆက်သွယ်နိုင်မှု)၊ eye strain (မျက်စိညောင်းညာထိခိုက်ခြင်း)၊ addicted (စွဲလမ်းနေသော)။",
        "passage": [
          { "en": "Today, mobile phones have become one of the most popular digital devices around the world. Almost everyone, including students, uses a mobile phone in daily life. However, using mobile phones has both advantages and disadvantages.", "mm": "ယနေ့ခေတ်မှာ မိုဘိုင်းဖုန်းတွေဟာ ကမ္ဘာတစ်ဝန်း လူသုံးအများဆုံး ဒစ်ဂျစ်တယ်ပစ္စည်းတစ်ခု ဖြစ်လာပါပြီ။ ကျောင်းသားကျောင်းသူတွေ အပါအဝင် လူတိုင်းနီးပါး နေ့စဉ်ဘဝမှာ မိုဘိုင်းဖုန်း သုံးစွဲနေကြပါတယ်။ သို့သော်လည်း မိုဘိုင်းဖုန်း အသုံးပြုခြင်းမှာ အားသာချက်ရော အားနည်းချက်ပါ နှစ်မျိုးစလုံး ရှိပါတယ်။" },
          { "en": "On the one hand, mobile phones are very useful for communication and education. We can make calls, send text messages, and video chat with our family and friends anytime and anywhere. In addition, students can use online dictionaries, educational apps, and the internet to learn English and other school subjects.", "mm": "တစ်ဖက်မှာတော့ မိုဘိုင်းဖုန်းတွေဟာ ဆက်သွယ်ရေးနဲ့ ပညာရေးအတွက် အလွန်အသုံးဝင်ပါတယ်။ အချိန်မရွေး နေရာမရွေး မိသားစု၊ သူငယ်ချင်းတွေနဲ့ ဖုန်းခေါ်ခြင်း၊ စာတိုပို့ခြင်းနဲ့ ဗီဒီယိုခေါ်ဆိုခြင်းတွေ လုပ်နိုင်ပါတယ်။ ဒါ့အပြင် ကျောင်းသူတွေဟာ အွန်လိုင်းအဘိဓာန်တွေ၊ ပညာရေး App တွေနဲ့ အင်တာနက်ကို သုံးပြီး အင်္ဂလိပ်စာနဲ့ တခြားဘာသာရပ်တွေကို လေ့လာနိုင်ပါတယ်။" },
          { "en": "In emergencies, a mobile phone can also save lives because we can quickly call for help from parents, police, or doctors.", "mm": "အရေးပေါ် အခြေအနေတွေမှာလည်း မိဘတွေ၊ ရဲတပ်ဖွဲ့ ဒါမှမဟုတ် ဆရာဝန်တွေဆီ အမြန်ဆုံး အကူအညီတောင်းခံနိုင်တာကြောင့် အသက်ကယ်နိုင်ပါတယ်။" },
          { "en": "On the other hand, spending too much time on mobile phones can cause serious problems. If students play online games or watch videos for many hours, they will neglect their homework and get poor grades in exams.", "mm": "အခြားတစ်ဖက်မှာတော့ မိုဘိုင်းဖုန်းပေါ်မှာ အချိန်အလွန်အကျွံ ကုန်ဆုံးခြင်းက ပြင်းထန်တဲ့ ပြဿနာတွေ ဖြစ်စေနိုင်ပါတယ်။ ကျောင်းသူတွေဟာ အွန်လိုင်းဂိမ်းဆော့တာ ဒါမှမဟုတ် ဗီဒီယိုကြည့်တာကို နာရီပေါင်းများစွာ လုပ်နေမယ်ဆိုရင် အိမ်စာလုပ်ဖို့ လစ်ဟင်းပြီး စာမေးပွဲမှာ အမှတ်နည်းသွားပါလိမ့်မယ်။" },
          { "en": "Furthermore, looking at a bright phone screen for a long time causes eye strain, headaches, and sleep disturbance. Many young people also do less physical exercise because they are addicted to their phones. Therefore, students should use mobile phones wisely and set a time limit every day.", "mm": "ထို့အပြင် တောက်ပတဲ့ ဖုန်းမျက်နှာပြင်ကို အချိန်အကြာကြီး ကြည့်ခြင်းက မျက်စိညောင်းညာခြင်း၊ ခေါင်းကိုက်ခြင်းနဲ့ အိပ်ရေးပျက်ခြင်းတို့ကို ဖြစ်စေပါတယ်။ ဖုန်းစွဲလမ်းမှုကြောင့် ကိုယ်လက်လှုပ်ရှား အားကစားလုပ်တာလည်း နည်းပါးလာပါတယ်။ ဒါကြောင့် ကျောင်းသူတွေအနေနဲ့ မိုဘိုင်းဖုန်းကို အကျိုးရှိရှိ အသုံးချသင့်ပြီး နေ့စဉ် အချိန်ကန့်သတ်ချက် ထားရှိသင့်ပါတယ်။" }
        ]
      },
      {
        "label": "Lesson 3 & 4",
        "title": "Lesson 3 & 4: Zero & First Conditionals & Text Messages",
        "note": "💡 သဒ္ဒါမှတ်စု: (၁) Zero Conditional (အမြဲမှန်ကန်သော သဘာဝတရား): If + Present Simple, Present Simple (If you heat ice, it melts.)။ (၂) First Conditional (ဖြစ်နိုင်ခြေရှိသော အနာဂတ်ရလဒ်): If + Present Simple, will + V-infinitive (If I pass the exam, my dad will buy me a new laptop.)။",
        "passage": [
          { "en": "Zero Conditional Examples: If you don't water plants, they die. If you mix red and yellow, you get orange.", "mm": "Zero Conditional ဥပမာများ: အပင်တွေကို ရေမလောင်းရင် သေသွားတတ်ပါတယ်။ အနီရောင်နဲ့ အဝါရောင် ရောစပ်ရင် လိမ္မော်ရောင် ရပါတယ်။" },
          { "en": "First Conditional Examples: I will buy a new laptop if I get high marks in the final exam. If it rains tomorrow, we will stay at home and study.", "mm": "First Conditional ဥပမာများ: နောက်ဆုံးစာမေးပွဲမှာ အမှတ်ကောင်းကောင်းရရင် လက်တော့ပ်အသစ် တစ်လုံး ဝယ်ပါမယ်။ မနက်ဖြန် မိုးရွာရင် အိမ်မှာပဲ နေပြီး စာကျက်ပါမယ်။" },
          { "en": "Common Text Message Abbreviations: ASAP means As soon as possible. BTW means By the way. CUL8R means See you later. FYI means For your information. GR8 means Great. IDK means I don't know. LOL means Laugh out loud. PLZ means Please. THX means Thanks. TTYL means Talk to you later. UR means Your or You are.", "mm": "စာတိုပေးပို့ရာတွင် အသုံးများသော အတိုကောက်စကားလုံးများ: ASAP (အမြန်ဆုံး)၊ BTW (စကားမစပ်)၊ CUL8R (နောက်မှတွေ့မယ်)၊ FYI (သိထားဖို့)၊ GR8 (အရမ်းကောင်းတယ်)၊ IDK (ငါမသိဘူး)၊ LOL (ဟားတိုက်ရယ်မောခြင်း)၊ PLZ (ကျေးဇူးပြု၍)၊ THX (ကျေးဇူးတင်ပါတယ်)၊ TTYL (နောက်မှပြန်ပြောမယ်)၊ UR (သင့်ရဲ့ / သင်သည်)။" },
          { "en": "Sample Text Message Exchange: Nilar: Hi Thiri! R U free this afternoon? PLZ come to my house at 3 p.m. We can study English together. — Thiri: THX for inviting me! That sounds GR8. I will bring my Grade 8 textbook. CUL8R!", "mm": "နမူနာ စာတိုအပြန်အလှန် ပေးပို့ခြင်း: နီလာ: ဟိုင်း သီရိ! ဒီနေ့မွန်းလွဲပိုင်း နင်အားလား? ကျေးဇူးပြုပြီး ညနေ ၃ နာရီ ငါ့အိမ်လာခဲ့ပါလား။ အင်္ဂလိပ်စာ အတူတူကျက်ရအောင်။ — သီရိ: ဖိတ်ပေးလို့ ကျေးဇူးပဲ! အရမ်းကောင်းတဲ့ အစီအစဉ်ပဲ။ ငါ Grade 8 ပြဋ္ဌာန်းစာအုပ် ယူလာခဲ့မယ်။ နောက်မှတွေ့မယ်နော်!" }
        ]
      }
    ],
    "games": [
      { "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (Text Message Abbreviations)", "q": "စာတိုပို့တဲ့အခါ သုံးတဲ့ 'ASAP' ဆိုတာ ဘာရဲ့ အတိုကောက်လဲ?", "mode": "mcq", "options": ["As slow as possible", "As soon as possible", "Always send a photo", "Ask someone a problem"], "ans": 1, "explain": "'ASAP' ဆိုတာ 'As soon as possible' (တတ်နိုင်သမျှ အမြန်ဆုံး) ရဲ့ အတိုကောက် ဖြစ်ပါတယ်။" },
      { "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (First Conditional)", "q": "'မင်း ကြိုးစားရင် စာမေးပွဲ အောင်လိမ့်မယ်' ကို စာကြောင်းစီပါ။", "mode": "scramble", "words": ["If", "you", "study", "hard,", "you", "will", "pass", "the", "exam."], "explain": "First Conditional မှာ 'If + Present Simple, ... will + V-infinitive' ပုံစံ သုံးရပါတယ်။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Zero Conditional)", "q": "If you _____ red and yellow, you get orange.", "mode": "mcq", "options": ["will mix", "mix", "mixed", "mixing"], "ans": 1, "explain": "အမြဲမှန်ကန်သော အချက်အလက် (Zero Conditional) ဖြစ်လို့ 'If + Present Simple (mix)' ကို သုံးရပါတယ်။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (First Conditional)", "q": "I _____ a new laptop if I get high marks in the exam.", "mode": "mcq", "options": ["buy", "will buy", "bought", "buying"], "ans": 1, "explain": "If-clause မှာ Present Simple (get) ပါတဲ့အတွက် Main clause မှာ 'will buy' ကို သုံးရပါတယ်။" },
      { "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Lesson 2 Check)", "q": "ဖုန်းမျက်နှာပြင်ကို အချိန်အကြာကြီး ကြည့်ခြင်းက မျက်စိညောင်းညာခြင်း (eye strain) နဲ့ အိပ်ရေးပျက်ခြင်းတို့ကို ဖြစ်စေပါတယ်။", "mode": "mcq", "options": ["မှန်တယ် (True)", "မှားတယ် (False)"], "ans": 0, "explain": "မှန်ပါတယ်! ဖုန်းအလွန်အကျွံသုံးခြင်းရဲ့ အားနည်းချက်တစ်ခု ဖြစ်ပါတယ်။" }
    ]
  },
  {
    "title": "Unit 12: Breaking News & Past Events (သတင်းများနှင့် အတိတ်ဖြစ်ရပ်များ)",
    "sections": [
      {
        "label": "Lesson 1",
        "title": "Lesson 1: Breaking news (News Topics & Dialogue)",
        "note": "💡 သတင်းအမျိုးအစားများ: local news (ပြည်တွင်းသတင်း)၊ international news (နိုင်ငံတကာသတင်း)၊ sports news (အားကစားသတင်း)၊ weather forecast (မိုးလေဝသခန့်မှန်းချက်)၊ entertainment news (ဖျော်ဖြေရေးသတင်း)၊ science & technology news (သိပ္ပံနှင့် နည်းပညာသတင်း)။",
        "passage": [
          { "en": "A: Did you watch the evening news on TV last night?", "mm": "A: မနေ့ညက တီဗွီမှာလာတဲ့ ညနေခင်းသတင်း ကြည့်လိုက်မိသေးလား?" },
          { "en": "B: Yes, I did. There was breaking news about a heavy storm approaching the coastal area.", "mm": "B: ကြည့်လိုက်မိတယ်လေ။ ကမ်းရိုးတန်းဒေသဆီ မုန်တိုင်းပြင်းထန်စွာ ဝင်ရောက်လာနေတဲ့ နောက်ဆုံးရ အရေးကြီးသတင်း ပါလာတယ်။" },
          { "en": "A: Oh, really? What did the weather forecast say?", "mm": "A: ဟုတ်လား? မိုးလေဝသခန့်မှန်းချက်မှာ ဘာတွေပြောသလဲ?" },
          { "en": "B: It warned fishermen and villagers near the coast to move to safe shelters immediately.", "mm": "B: ကမ်းရိုးတန်းအနီးက ရေလုပ်သားတွေနဲ့ ရွာသူရွာသားတွေကို ဘေးကင်းရာ ခိုလှုံရာနေရာတွေဆီ ချက်ချင်းရွှေ့ပြောင်းကြဖို့ သတိပေးထားတယ်။" },
          { "en": "A: Which section of the newspaper do you like reading most?", "mm": "A: သတင်းစာထဲမှာ ဘယ်အပိုင်းကို မင်း အဖတ်ချင်ဆုံးလဲ?" },
          { "en": "B: I love reading sports news and science and technology news because they are always exciting and informative.", "mm": "B: ငါက အမြဲတမ်း စိတ်လှုပ်ရှားစရာကောင်းပြီး ဗဟုသုတရစေတဲ့ အားကစားသတင်းနဲ့ သိပ္ပံနှင့်နည်းပညာ သတင်းတွေကို အဖတ်ချင်ဆုံးပါပဲ။" }
        ]
      },
      {
        "label": "Lesson 2",
        "title": "Lesson 2: What is happening in the world today? (Local & International News)",
        "note": "💡 ဝေါဟာရမှတ်စု: local news (ဒေသတွင်း/ပြည်တွင်းသတင်း)၊ international news (ကမ္ဘာ့သတင်း)၊ rescue team (ကယ်ဆယ်ရေးအဖွဲ့)၊ renewable energy (ပြန်လည်ပြည့်ဖြိုးမြဲစွမ်းအင်)။",
        "passage": [
          { "en": "Local News — Community Volunteers Help Flood Victims: Heavy monsoon rains caused sudden flooding in several low-lying villages yesterday afternoon. Local rescue teams, firefighters, and youth volunteers worked together to evacuate elderly people and children to the village monastery.", "mm": "ပြည်တွင်းသတင်း — ရပ်ရွာစေတနာ့ဝန်ထမ်းများ ရေဘေးသင့်ပြည်သူများအား ကူညီ: မနေ့က မွန်းလွဲပိုင်းတွင် မိုးသည်းထန်စွာ ရွာသွန်းမှုကြောင့် မြေနိမ့်ပိုင်းကျေးရွာအချို့တွင် ရုတ်တရက် ရေကြီးမှုဖြစ်ပွားခဲ့သည်။ ဒေသခံကယ်ဆယ်ရေးအဖွဲ့များ၊ မီးသတ်တပ်ဖွဲ့ဝင်များနှင့် လူငယ်စေတနာ့ဝန်ထမ်းများ ပူးပေါင်းကာ သက်ကြီးရွယ်အိုနှင့် ကလေးငယ်များကို ကျေးရွာဘုန်းတော်ကြီးကျောင်းသို့ ရွှေ့ပြောင်းပေးခဲ့ကြသည်။" },
          { "en": "Clean drinking water, dry food packages, and blankets were distributed to over two hundred families. Fortunately, no one was injured in the incident, and the local authorities praised the quick action and unity of the villagers.", "mm": "မိသားစု နှစ်ရာကျော်အတွက် သောက်ရေသန့်၊ အစားအစာထုပ်များနှင့် စောင်များ ဝေငှပေးခဲ့သည်။ ကံကောင်းထောက်မစွာ မည်သူမျှ ထိခိုက်ဒဏ်ရာ မရရှိခဲ့ဘဲ အာဏာပိုင်များက ရွာသားများ၏ စည်းလုံးညီညွတ်မှုကို ချီးကျူးဂုဏ်ပြုခဲ့သည်။" },
          { "en": "International News — Youth Tree-Planting Movement Grows Worldwide: Thousands of school students across Asia and Europe joined an international tree-planting campaign last weekend to fight climate change. Students planted more than fifty thousand young trees in parks, school compounds, and mountain areas.", "mm": "နိုင်ငံတကာသတင်း — ကမ္ဘာတစ်ဝန်း လူငယ်သစ်ပင်စိုက်ပျိုးရေး လှုပ်ရှားမှု ကျယ်ပြန့်လာ: ပြီးခဲ့သည့် စနေ၊ တနင်္ဂနွေက ရာသီဥတုပြောင်းလဲမှုကို တိုက်ဖျက်ရန် အာရှနှင့် ဥရောပတစ်ဝန်းမှ ကျောင်းသားထောင်ပေါင်းများစွာ သစ်ပင်စိုက်ပျိုးရေး လှုပ်ရှားမှုတွင် ပါဝင်ခဲ့ကြသည်။ ကျောင်းဝင်းများနှင့် တောင်တန်းဒေသများတွင် ပျိုးပင်ငါးသောင်းကျော် စိုက်ပျိုးခဲ့ကြသည်။" },
          { "en": "Organizers said that young people play a vital role in protecting our planet and creating a greener future for the next generations.", "mm": "လူငယ်များသည် ကမ္ဘာမြေကို ကာကွယ်စောင့်ရှောက်ရန်နှင့် နောင်မျိုးဆက်သစ်များအတွက် ပိုမိုစိမ်းလန်းသော အနာဂတ်ဖန်တီးရန် အရေးပါသော အခန်းကဏ္ဍမှ ပါဝင်နေကြောင်း ပွဲစီစဉ်သူများက ပြောကြားခဲ့သည်။" }
        ]
      },
      {
        "label": "Lesson 3 & 4",
        "title": "Lesson 3 & 4: Past Tenses & Writing a Short News Story",
        "note": "💡 သဒ္ဒါမှတ်စု: (၁) Past Simple (V2): အတိတ်က ပြီးဆုံးသွားသော အရာ (yesterday, last night, ago)။ (၂) Past Continuous (was/were + V-ing): အတိတ်တစ်ချိန်တွင် ဖြစ်ပျက်နေဆဲ အရာ (while, when)။ (၃) Present Perfect (has/have + V3): ပြီးစီးသွားပြီး အကျိုးဆက်ရှိနေသေးသော အရာ (just, already, yet)။",
        "passage": [
          { "en": "Grammar Examples: While the rescue workers were helping the elderly people, young volunteers brought clean drinking water.", "mm": "သဒ္ဒါဥပမာ: ကယ်ဆယ်ရေးဝန်ထမ်းတွေက သက်ကြီးရွယ်အိုတွေကို ကူညီနေစဉ် (Past Continuous) မှာ လူငယ်စေတနာ့ဝန်ထမ်းတွေက သောက်ရေသန့်တွေ သယ်လာပေးခဲ့ကြပါတယ် (Past Simple)။" },
          { "en": "Present Perfect Examples: The rescue team has already moved all the villagers to safety. Have you heard the latest news yet?", "mm": "Present Perfect ဥပမာ: ကယ်ဆယ်ရေးအဖွဲ့က ရွာသားအားလုံးကို ဘေးကင်းရာဆီ ရွှေ့ပြောင်းပေးပြီးပါပြီ။ နောက်ဆုံးရသတင်းကို ကြားပြီးပြီလား?" },
          { "en": "How to Write a Short News Story (What happened in my neighbourhood?): A good news story has a short catchy Headline, a Lead paragraph answering Who, What, Where, and When, a Body giving details, and a Conclusion.", "mm": "သတင်းတိုတစ်ပုဒ် ရေးသားနည်း: ကောင်းမွန်တဲ့ သတင်းတစ်ပုဒ်မှာ ဆွဲဆောင်မှုရှိတဲ့ ခေါင်းစဉ် (Headline)၊ ဘယ်သူ၊ ဘာဖြစ်၊ ဘယ်နေရာ၊ ဘယ်အချိန်ကို ဖြေဆိုပေးတဲ့ နိဒါန်း (Lead)၊ အသေးစိတ်အချက်အလက် (Body) နဲ့ နိဂုံး (Conclusion) တို့ ပါဝင်ရပါမယ်။" },
          { "en": "Neighbourhood News Story — Quick-Thinking Students Save Lost Child: Yesterday evening at 5:30 p.m., two Grade 8 students found a four-year-old boy crying alone near the town market. They comforted the child, bought him some water, and took him safely to the nearby police station. Within thirty minutes, the boy's worried parents arrived and thanked the two students warmly.", "mm": "ရပ်ကွက်သတင်းတို — ဉာဏ်ကောင်းသော ကျောင်းသူနှစ်ဦး လမ်းပျောက်နေသည့် ကလေးငယ်အား ကယ်တင်: မနေ့ညနေ ၅ နာရီခွဲခန့်က မြို့မဈေးအနီးတွင် တစ်ဦးတည်း ငိုကြွေးနေသော ၄ နှစ်အရွယ် ကလေးငယ်တစ်ဦးကို Grade 8 ကျောင်းသူနှစ်ဦးက တွေ့ရှိခဲ့သည်။ ကလေးကို ချော့မော့ရေတိုက်ပြီး အနီးရှိ ရဲစခန်းသို့ ဘေးကင်းစွာ ပို့ဆောင်ပေးခဲ့ရာ မိနစ် ၃၀ အတွင်း မိဘများ ရောက်ရှိလာပြီး ကျေးဇူးတင်စကား ပြောကြားခဲ့သည်။" }
        ]
      }
    ],
    "games": [
      { "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (News Vocabulary)", "q": "အရေးကြီးပြီး လတ်တလော ဖြစ်ပွားနေတဲ့ သတင်းထူးကို အင်္ဂလိပ်လို ဘယ်လိုခေါ်လဲ?", "mode": "mcq", "options": ["weather forecast", "breaking news", "sports news", "fairy tale"], "ans": 1, "explain": "'breaking news' ဆိုတာ အခုပဲ ဖြစ်ပွားနေတဲ့ နောက်ဆုံးရ အရေးကြီးသတင်းကို ခေါ်တာပါ။" },
      { "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Past Simple & Continuous)", "q": "'မိုးရွာနေစဉ် ကျွန်ုပ် အိမ်စာလုပ်နေခဲ့သည်' ကို စာကြောင်းစီပါ။", "mode": "scramble", "words": ["I", "was", "doing", "my", "homework", "while", "it", "was", "raining."], "explain": "အတိတ်မှာ တစ်ပြိုင်နက်တည်း ဖြစ်ပျက်နေတဲ့ အရာနှစ်ခုအတွက် Past Continuous (was/were + V-ing) ကို သုံးပါတယ်။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Present Perfect - Review 4)", "q": "The rescue team _____ already moved all the villagers to the monastery.", "mode": "mcq", "options": ["have", "has", "was", "did"], "ans": 1, "explain": "'The rescue team' ဟာ အနည်းကိန်းအစုအဖွဲ့ (Singular) ဖြစ်ပြီး 'already' ပါတဲ့အတွက် Present Perfect 'has' ကို သုံးရပါတယ်။" },
      { "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Past Continuous vs Past Simple)", "q": "When the phone _____, I was reading a newspaper.", "mode": "mcq", "options": ["rings", "rang", "was ringing", "ring"], "ans": 1, "explain": "အတိတ်မှာ လုပ်ဆောင်နေဆဲ (was reading) အချိန် ကြားဖြတ်ဖြစ်ပျက်တဲ့ အရာအတွက် Past Simple (rang) ကို သုံးရပါတယ်။" },
      { "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Lesson 4 Check)", "q": "မြို့မဈေးအနီးမှာ လမ်းပျောက်နေတဲ့ ၄ နှစ်အရွယ် ကလေးငယ်ကို Grade 8 ကျောင်းသူနှစ်ဦးက ရဲစခန်းသို့ ဘေးကင်းစွာ ပို့ဆောင်ပေးခဲ့ပါတယ်။", "mode": "mcq", "options": ["မှန်တယ် (True)", "မှားတယ် (False)"], "ans": 0, "explain": "မှန်ပါတယ်! ကျောင်းသူနှစ်ဦးရဲ့ ကူညီမှုကြောင့် မိနစ် ၃၀ အတွင်း မိဘတွေနဲ့ ပြန်လည်ဆုံဆည်းခဲ့ပါတယ်။" }
    ]
  }
];

const poemsData = [
  {
    "title": "Poem 1: On the Vowels (သရအက္ခရာများအကြောင်း)",
    "poet": "Jonathan Swift (Textbook Page 35)",
    "lines": [
      { "en": "We are little airy creatures,", "mm": "ကျွန်ုပ်တို့သည် လေကဲ့သို့ ပေါ့ပါးသော အရာငယ်လေးများ ဖြစ်ကြပြီး၊" },
      { "en": "All of different voice and features;", "mm": "အားလုံးမှာ မတူညီသော အသံနှင့် ပုံသဏ္ဌာန်လက္ခဏာ ကိုယ်စီရှိကြသည်၊" },
      { "en": "One of us in glass is set,", "mm": "ကျွန်ုပ်တို့ထဲမှ တစ်ဦးကို 'glass' (a) တွင် ထည့်သွင်းထားပြီး၊" },
      { "en": "One of us you'll find in jet;", "mm": "နောက်တစ်ဦးကိုမူ 'jet' (e) တွင် သင်တွေ့ရလိမ့်မည်၊" },
      { "en": "T'other you may see in tin,", "mm": "အခြားတစ်ဦးကို 'tin' (i) တွင် မြင်တွေ့နိုင်ပြီး၊" },
      { "en": "And the fourth a box within.", "mm": "စတုတ္ထတစ်ဦးမှာ 'box' (o) အထဲတွင် ရှိနေသည်၊" },
      { "en": "If the fifth you should pursue,", "mm": "အကယ်၍ ပဉ္စမမြောက်တစ်ဦးကို သင်လိုက်လံရှာဖွေမည်ဆိုပါက၊" },
      { "en": "It can never fly from you.", "mm": "ထိုအရာသည် သင့် ('you' - u) ထံမှ မည်သည့်အခါမျှ ပျံပြေးနိုင်မည် မဟုတ်ပေ။" }
    ],
    "note": "💡 ရှင်းလင်းချက်: ဤကဗျာသည် အင်္ဂလိပ်သရ (Vowels) ၅ လုံးဖြစ်သော a, e, i, o, u တို့ကို glass (a), jet (e), tin (i), box (o), you (u) ဟူသော စကားလုံးများဖြင့် ပဟေဠိဆန်ဆန် ဖွဲ့ဆိုထားခြင်း ဖြစ်ပါသည်။"
  },
  {
    "title": "Poem 2: How Beautiful is the Rain! (မိုးရေသည် မည်မျှလှပသနည်း)",
    "poet": "Henry Wadsworth Longfellow (Textbook Page 63)",
    "lines": [
      { "en": "How beautiful is the rain!", "mm": "မိုးရေသည် မည်မျှ လှပလိုက်ပါသနည်း!" },
      { "en": "After the dust and heat,", "mm": "ဖုန်မှုန့်များနှင့် ပူပြင်းခြောက်သွေ့မှုများ ပြီးနောက်၊" },
      { "en": "In the broad and fiery street,", "mm": "ကျယ်ပြန့်ပြီး မီးတောက်မတတ် ပူပြင်းသော လမ်းမကြီးပေါ်တွင်လည်းကောင်း၊" },
      { "en": "In the narrow lane,", "mm": "ကျဉ်းမြောင်းသော လမ်းကြားလေးထဲတွင်လည်းကောင်း၊" },
      { "en": "How beautiful is the rain!", "mm": "မိုးရေသည် မည်မျှ လှပလိုက်ပါသနည်း!" },
      { "en": "How it clatters along the roofs,", "mm": "အိမ်ခေါင်မိုးများပေါ်သို့ တဖြောက်ဖြောက် မြည်ဟည်းကျဆင်းပုံမှာ၊" },
      { "en": "Like the tramp of hoofs!", "mm": "မြင်းခွာသံများ တဒုန်းဒုန်း နင်းလျှောက်နေသကဲ့သို့ပင်!" },
      { "en": "How it gushes and struggles out", "mm": "မိုးရေများသည် အရှိန်ပြင်းစွာ တိုးဝှေ့စီးဆင်းထွက်ကျလာပုံမှာ၊" },
      { "en": "From the throat of the overflowing spout!", "mm": "ရေလျှံကျနေသော ရေတံလျှောက်ပေါက်ဝမှ တဝေါဝေါ စီးကျနေသကဲ့သို့ပင်!" },
      { "en": "Across the window-pane It pours and pours;", "mm": "ပြတင်းပေါက်မှန်ချပ်ကို ဖြတ်ကျော်၍ မိုးရေများ တသွင်သွင် ရွာသွန်းနေသည်၊" },
      { "en": "And swift and wide, With a muddy tide,", "mm": "လျင်မြန်ကျယ်ပြန့်စွာ ရွှံ့ရေစီးကြောင်းများနှင့်အတူ၊" },
      { "en": "Like a river down the gutter roars", "mm": "လမ်းဘေးရေမြောင်းတစ်လျှောက် မြစ်တစ်စင်းပမာ ဟိန်းဟောက်စီးဆင်းနေသော၊" },
      { "en": "The rain, the welcome rain!", "mm": "မိုးရေ၊ လူတိုင်း ကြိုဆိုနှစ်သက်ကြသော မိုးရေပါတကား!" }
    ],
    "note": "💡 ရှင်းလင်းချက်: ပူပြင်းခြောက်သွေ့ပြီး ဖုန်ထူနေချိန်တွင် ရွာချလိုက်သော မိုးရေ၏ အသံနှင့် အလှတရားကို ကဗျာဆရာက ဝမ်းမြောက်ဝမ်းသာ ကြိုဆိုဖွဲ့ဆိုထားခြင်း ဖြစ်ပါသည်။"
  },
  {
    "title": "Poem 3: The Snare (ကျော့ကွင်းမိနေသော ယုန်ကလေး)",
    "poet": "James Stephens (Textbook Page 91)",
    "lines": [
      { "en": "I hear a sudden cry of pain!", "mm": "နာကျင်စွာ ရုတ်တရက် အော်ဟစ်လိုက်သံကို ကျွန်ုပ် ကြားလိုက်ရသည်!" },
      { "en": "There is a rabbit in a snare:", "mm": "ကျော့ကွင်းထဲတွင် ယုန်ကလေးတစ်ကောင် မိနေလေပြီ၊" },
      { "en": "Now I hear the cry again,", "mm": "ယခု အော်သံကို ကျွန်ုပ် ထပ်မံကြားရပြန်သည်၊" },
      { "en": "But I cannot tell from where.", "mm": "သို့သော် မည်သည့်နေရာမှ လာသည်ကို ကျွန်ုပ် မပြောနိုင်ပေ။" },
      { "en": "But I cannot tell from where He is calling out for aid!", "mm": "သူ အကူအညီတောင်းခံ အော်ဟစ်နေသည့် နေရာကို ကျွန်ုပ် ရှာမတွေ့နိုင်ဖြစ်နေသည်!" },
      { "en": "Crying on the frightened air, Making everything afraid!", "mm": "ထိတ်လန့်ဖွယ် လေထုထဲတွင် အော်ဟစ်နေခြင်းက ပတ်ဝန်းကျင်တစ်ခုလုံးကို ကြောက်ရွံ့စေသည်!" },
      { "en": "Making everything afraid! Wrinkling up his little face!", "mm": "ပတ်ဝန်းကျင်တစ်ခုလုံးကို ကြောက်ရွံ့စေရင်း သူ၏ မျက်နှာငယ်လေးမှာ နာကျင်မှုကြောင့် တွန့်ရှုံ့နေရှာသည်!" },
      { "en": "As he cries again for aid; - and I cannot find the place!", "mm": "သူ အကူအညီ ထပ်တောင်းနေသော်လည်း ထိုနေရာကို ကျွန်ုပ် ရှာမတွေ့နိုင်သေးပေ!" },
      { "en": "And I cannot find the place Where his paw is in the snare!", "mm": "သူ၏ ခြေဖဝါးလေး ကျော့ကွင်းမိနေသည့် နေရာကို ကျွန်ုပ် ရှာမတွေ့နိုင်ဖြစ်နေသည်!" },
      { "en": "Little One! Oh, Little One! I am searching everywhere!", "mm": "သတ္တဝါငယ်လေးရေ! အို... ယုန်ကလေးရေ! ကျွန်ုပ် နေရာအနှံ့ လိုက်လံရှာဖွေနေပါသည်!" }
    ],
    "note": "💡 ရှင်းလင်းချက်: ထောင်ချောက်မိ၍ နာကျင်စွာ အော်ဟစ်နေသော ယုန်ကလေးကို ကယ်တင်လိုသော်လည်း နေရာရှာမတွေ့ဖြစ်နေရသည့် ကဗျာဆရာ၏ ကရုဏာစိတ်ကို ဖော်ကျူးထားပါသည်။"
  },
  {
    "title": "Poem 4: The Moon (လမင်းကြီး)",
    "poet": "Robert Louis Stevenson (Textbook Page 119)",
    "lines": [
      { "en": "The moon has a face like the clock in the hall;", "mm": "လမင်းကြီးတွင် ဧည့်ခန်းဆောင်ထဲက နာရီကဲ့သို့ ဝိုင်းစက်သော မျက်နှာရှိသည်၊" },
      { "en": "She shines on thieves on the garden wall,", "mm": "သူမသည် ဥယျာဉ်တံတိုင်းပေါ်မှ သူခိုးများအပေါ်သို့ အလင်းရောင် ဖြာကျစေသည်၊" },
      { "en": "On streets and fields and harbour quays,", "mm": "လမ်းမများ၊ လယ်ကွင်းများနှင့် သင်္ဘောဆိပ်ခံတံတားများ အပေါ်သို့လည်းကောင်း၊" },
      { "en": "And birdies asleep in the forks of the trees.", "mm": "သစ်ပင်ခွကြားတွင် အိပ်မောကျနေသော ငှက်ကလေးများ အပေါ်သို့လည်းကောင်း အလင်းပေးသည်၊" },
      { "en": "The squalling cat and the squeaking mouse,", "mm": "စူးရှစွာ အော်ဟစ်နေသော ကြောင်နှင့် တကျွီကျွီ မြည်နေသော ကြွက်ကလေး၊" },
      { "en": "The howling dog by the door of the house,", "mm": "အိမ်တံခါးဝနားတွင် အူနေသော ခွေးကလေးနှင့်၊" },
      { "en": "The bat that lies in bed at noon,", "mm": "မွန်းတည့်ချိန်တွင် အိပ်စက်လေ့ရှိသော လင်းနို့တို့သည်၊" },
      { "en": "All love to be out by the light of the moon.", "mm": "အားလုံးပင် လမင်းကြီး၏ အလင်းရောင်အောက်၌ အပြင်ထွက်ရသည်ကို နှစ်သက်ကြသည်၊" },
      { "en": "But all of the things that belong to the day", "mm": "သို့သော် နေ့အချိန်နှင့် သက်ဆိုင်သော သက်ရှိအရာအားလုံးကမူ၊" },
      { "en": "Cuddle to sleep to be out of her way;", "mm": "လမင်းကြီး၏ လမ်းကြောင်းမှ ဖယ်ရှားကာ ကွေးကွေးလေး အိပ်စက်ကြတော့သည်၊" },
      { "en": "And flowers and children close their eyes", "mm": "ပန်းကလေးများနှင့် ကလေးငယ်များသည်လည်း မျက်လုံးလေးများ မှိတ်စက်အိပ်ပျော်ကြသည်၊" },
      { "en": "Till up in the morning the sun shall arise.", "mm": "နံနက်ခင်း၌ နေမင်းကြီး ပြန်လည်ထွက်ပေါ်လာသည့် အချိန်အထိပင် ဖြစ်တော့သည်။" }
    ],
    "note": "💡 ရှင်းလင်းချက်: ညအချိန် လရောင်အောက်တွင် လှုပ်ရှားကျက်စားကြသော ညသတ္တဝါများနှင့် အိပ်စက်အနားယူကြသော နေ့သတ္တဝါများအကြောင်းကို ကလေးများ နားလည်လွယ်အောင် ဖွဲ့ဆိုထားပါသည်။"
  }
];

const essaysData = [
  {
    "title": "1. My Favourite Person (Unit 4 Writing)",
    "category": "Paragraph / Essay",
    "sentences": [
      { "en": "My favourite person in my family is my grandmother.", "mm": "ကျွန်မတို့ မိသားစုထဲမှာ ကျွန်မ အချစ်ခင်အနှစ်သက်ဆုံးသူကတော့ အဘွားပဲ ဖြစ်ပါတယ်။" },
      { "en": "She is the most patient and kindest person I have ever met.", "mm": "အဘွားဟာ ကျွန်မ တွေ့ဖူးသမျှထဲမှာ စိတ်အရှည်ဆုံးနဲ့ အကြင်နာတတ်ဆုံး ပုဂ္ဂိုလ်ဖြစ်ပါတယ်။" },
      { "en": "She never gets angry with us and always speaks with a sweet smile.", "mm": "သူမဟာ ကျွန်မတို့ကို ဘယ်တော့မှ စိတ်မဆိုးတတ်ဘဲ ချိုသာတဲ့ အပြုံးလေးနဲ့ အမြဲစကားပြောလေ့ရှိပါတယ်။" },
      { "en": "Moreover, she often makes delicious traditional snacks for me and shares them with our neighbours.", "mm": "ဒါ့အပြင် အဘွားက ကျွန်မအတွက် အရသာရှိတဲ့ ရိုးရာမုန့်လေးတွေ မကြာခဏ လုပ်ကျွေးတတ်ပြီး အိမ်နီးချင်းတွေကိုလည်း ဝေမျှပေးလေ့ရှိပါတယ်။" },
      { "en": "For these reasons, I love and respect my grandmother most.", "mm": "ဒီအကြောင်းပြချက်တွေကြောင့် အဘွားကို ကျွန်မ အချစ်ဆုံးနဲ့ အလေးစားဆုံး ဖြစ်ပါတယ်။" }
    ]
  },
  {
    "title": "2. My School Description (Unit 2 Writing)",
    "category": "Descriptive Essay",
    "sentences": [
      { "en": "I attend Basic Education High School, which is located in a peaceful and green area.", "mm": "ကျွန်မဟာ အေးချမ်းပြီး စိမ်းလန်းစိုပြည်တဲ့ နေရာမှာ တည်ရှိတဲ့ အခြေခံပညာ အထက်တန်းကျောင်းမှာ တက်ရောက်နေပါတယ်။" },
      { "en": "There are forty dedicated teachers and about one thousand students in our school.", "mm": "ကျွန်မတို့ကျောင်းမှာ စေတနာထား သင်ကြားပေးတဲ့ ဆရာဆရာမ ၄၀ ဦးနဲ့ ကျောင်းသားကျောင်းသူ ၁,၀၀၀ ခန့် ရှိပါတယ်။" },
      { "en": "Our school has clean classrooms, a well-equipped science lab, a large library, and a spacious playground.", "mm": "ကျောင်းမှာ သန့်ရှင်းတဲ့ စာသင်ခန်းတွေ၊ ပစ္စည်းစုံလင်တဲ့ သိပ္ပံခန်း၊ စာကြည့်တိုက်ကြီးနဲ့ ကျယ်ဝန်းတဲ့ ကစားကွင်းတို့ ရှိပါတယ်။" },
      { "en": "At weekends, students can take part in extra-curricular activities such as sports, scouting, and school band.", "mm": "ကျောင်းပိတ်ရက်တွေမှာ အားကစား၊ ကင်းထောက်နဲ့ ကျောင်းဘင်ခရာတီးဝိုင်းလို ကျောင်းပြင်ပလှုပ်ရှားမှုတွေမှာ ပါဝင်နိုင်ပါတယ်။" },
      { "en": "I am very proud of my school because it gives us both knowledge and good manners.", "mm": "ပညာဗဟုသုတရော ယဉ်ကျေးလိမ္မာမှုပါ သင်ကြားပေးတဲ့ ကျွန်မတို့ကျောင်းအတွက် အလွန်ဂုဏ်ယူမိပါတယ်။" }
    ]
  },
  {
    "title": "3. How We Can Save Our Environment (Unit 6 Writing)",
    "category": "Expository Essay",
    "sentences": [
      { "en": "Our planet Earth provides us with clean air, fresh water, and natural resources, so we must protect it.", "mm": "ကျွန်ုပ်တို့ရဲ့ ကမ္ဘာမြေကြီးက သန့်ရှင်းတဲ့လေ၊ ရေချိုနဲ့ သဘာဝသယံဇာတတွေ ပေးစွမ်းထားတာကြောင့် ကျွန်ုပ်တို့ ပြန်လည်ကာကွယ်စောင့်ရှောက်ရပါမယ်။" },
      { "en": "First, we must practice the three R's: reduce, reuse, and recycle in our daily lives.", "mm": "ပထမဦးစွာ နေ့စဉ်ဘဝမှာ လျှော့ချခြင်း (Reduce)၊ ပြန်လည်အသုံးပြုခြင်း (Reuse) နဲ့ ပြန်လည်ပြုပြင်ထုတ်လုပ်ခြင်း (Recycle) ဆိုတဲ့ R သုံးလုံးကို ကျင့်သုံးရပါမယ်။" },
      { "en": "We must use tote bags instead of plastic bags when we go shopping.", "mm": "ဈေးဝယ်ထွက်တဲ့အခါ ပလတ်စတစ်အိတ်တွေအစား ချည်လွယ်အိတ်တွေကို အသုံးပြုရပါမယ်။" },
      { "en": "In addition, we must save electricity and water at home and plant more trees around our village.", "mm": "ထို့အပြင် အိမ်မှာ လျှပ်စစ်မီးနဲ့ ရေကို ချွေတာသုံးစွဲရမှာဖြစ်ပြီး ကျေးရွာပတ်ဝန်းကျင်မှာ သစ်ပင်တွေ ပိုမိုစိုက်ပျိုးရပါမယ်။" },
      { "en": "If everyone works together, our environment will become cleaner, greener, and healthier.", "mm": "လူတိုင်း အတူတကွ ပူးပေါင်းလုပ်ဆောင်ကြမယ်ဆိုရင် ပတ်ဝန်းကျင်ဟာ ပိုမိုသန့်ရှင်းစိမ်းလန်းပြီး ကျန်းမာပျော်ရွှင်စရာ ဖြစ်လာပါလိမ့်မယ်။" }
    ]
  },
  {
    "title": "4. A Memorable Holiday (Unit 9 Writing)",
    "category": "Narrative Essay",
    "sentences": [
      { "en": "Last summer holiday, my family and I went on a memorable trip to Ngapali Beach.", "mm": "ပြီးခဲ့တဲ့ နွေရာသီကျောင်းပိတ်ရက်တုန်းက ကျွန်မတို့ မိသားစုဟာ ငပလီကမ်းခြေကို အမှတ်တရ ခရီးတစ်ခု သွားရောက်ခဲ့ကြပါတယ်။" },
      { "en": "We travelled by coach and enjoyed the scenic views of green mountains and villages along the way.", "mm": "ကျွန်မတို့ အဝေးပြေးကားနဲ့ ခရီးထွက်ခဲ့ကြပြီး လမ်းတစ်လျှောက် စိမ်းလန်းတဲ့ တောင်တန်းတွေနဲ့ ကျေးရွာလေးတွေရဲ့ သာယာတဲ့ ရှုခင်းတွေကို ကြည့်ရှုခံစားခဲ့ကြပါတယ်။" },
      { "en": "When we arrived at the beach, the air was fresh and the blue sea water was warm and relaxing.", "mm": "ကမ်းခြေကို ရောက်တဲ့အခါ လေထုက လတ်ဆတ်နေပြီး ပြာလဲ့နေတဲ့ ပင်လယ်ရေက နွေးထွေးအပန်းပြေစေပါတယ်။" },
      { "en": "We swam in the sea, built sandcastles, and ate delicious fresh seafood in the evening.", "mm": "ကျွန်မတို့ ပင်လယ်ထဲမှာ ရေကူးကြတယ်၊ သဲရဲတိုက်လေးတွေ ဆောက်ကြတယ်၊ ညနေခင်းမှာတော့ အရသာရှိတဲ့ ပင်လယ်စာလတ်လတ်ဆတ်ဆတ်တွေ စားသောက်ခဲ့ကြပါတယ်။" },
      { "en": "Although we were tired when we returned home, it was the happiest holiday in my life.", "mm": "အိမ်ပြန်ရောက်တဲ့အခါ ပင်ပန်းနေပေမဲ့လည်း ကျွန်မဘဝမှာ အပျော်ရွှင်ရဆုံး အားလပ်ရက်ခရီးစဉ်တစ်ခု ဖြစ်ခဲ့ပါတယ်။" }
    ]
  },
  {
    "title": "5. An Invitation Email to a Friend (Unit 7 Writing)",
    "category": "Email / Letter",
    "sentences": [
      { "en": "Dear Su Su, How are you? I hope you and your family are doing well.", "mm": "ချစ်လှစွာသော စုစုရေ... နေကောင်းရဲ့လား? နင်နဲ့ နင့်မိသားစုအားလုံး ကျန်းမာပျော်ရွှင်နေမယ်လို့ မျှော်လင့်ပါတယ်။" },
      { "en": "I have some exciting news to tell you about our coming weekend.", "mm": "လာမယ့် စနေ၊ တနင်္ဂနွေ အားလပ်ရက်အတွက် စိတ်လှုပ်ရှားစရာ သတင်းကောင်းတစ်ခု ပြောပြစရာရှိတယ်။" },
      { "en": "My uncle has arranged a two-day camping and trekking trip to the hills, and I would like you to join us.", "mm": "ငါ့ဦးလေးက တောင်တန်းတွေဆီ နှစ်ရက်ကြာ စခန်းချတောင်တက်ခရီးစဉ် စီစဉ်ထားလို့ နင့်ကိုလည်း အတူလိုက်ခဲ့စေချင်တယ်။" },
      { "en": "We have already prepared tents, sleeping bags, and backpacks, so you do not need to worry about anything.", "mm": "ရွက်ဖျင်တဲတွေ၊ အိပ်ရာလိပ်တွေနဲ့ ကျောပိုးအိတ်တွေ အကုန်ပြင်ဆင်ပြီးသားမို့ ဘာမှစိတ်ပူစရာ မလိုပါဘူး။" },
      { "en": "Please ask your parents for permission and let me know soon. Best wishes, Thinzar.", "mm": "မိဘတွေဆီမှာ ခွင့်တောင်းပြီး ငါ့ကို အမြန်ဆုံး အကြောင်းပြန်ပေးပါဦးနော်။ ခင်မင်လျက် - သဉ္ဇာ။" }
    ]
  },
  {
    "title": "6. The Device We Would Like to Have (Project 4 - Page 118)",
    "category": "Project 4 Writing",
    "sentences": [
      { "en": "The digital device that I would like to have is a lightweight tablet.", "mm": "ကျွန်မ အလိုချင်ဆုံး ဒစ်ဂျစ်တယ်ပစ္စည်းကတော့ ပေါ့ပါးတဲ့ တက်ဘလက် (Tablet) တစ်လုံး ဖြစ်ပါတယ်။" },
      { "en": "It is portable and easy to carry in my school bag whenever I go to school or the library.", "mm": "အဲဒါက ကျောင်းသွားတဲ့အခါဖြစ်ဖြစ် စာကြည့်တိုက်သွားတဲ့အခါဖြစ်ဖြစ် ကျောပိုးအိတ်ထဲ ထည့်သယ်သွားဖို့ အရမ်းလွယ်ကူပါတယ်။" },
      { "en": "With a tablet, I can read e-books, look up new English words in an offline dictionary, and watch educational videos.", "mm": "တက်ဘလက်တစ်လုံး ရှိရင် အီးဘွတ်စာအုပ်တွေ ဖတ်နိုင်မယ်၊ အော့ဖ်လိုင်းအဘိဓာန်ထဲမှာ အင်္ဂလိပ်စကားလုံးအသစ်တွေ ရှာနိုင်မယ်၊ ပညာရေးဗီဒီယိုတွေလည်း ကြည့်ရှုနိုင်ပါတယ်။" },
      { "en": "If I study hard and get good grades this year, my parents will buy one for me.", "mm": "ဒီနှစ် စာကြိုးစားပြီး အမှတ်ကောင်းတွေ ရမယ်ဆိုရင် မိဘတွေက ကျွန်မအတွက် တစ်လုံးဝယ်ပေးပါလိမ့်မယ်။" }
    ]
  }
];// ============================================================================
// lessons.js ၏ အောက်ဆုံးတွင် ကူးထည့်ရန် ပေါင်းစပ်ပြင်ဆင်မှု Function (All-in-One Patch)
// ============================================================================
(function patchAndUpgradeLessonsData() {
  // ၁။ Essay၊ ကဗျာ နှင့် သင်ခန်းစာများမှ ကျောင်းသားများ မသိတတ်သော အခြေခံစာလုံး ၁၈၀+ ကို အဘိဓာန်ထဲ ပေါင်းထည့်ခြင်း
  if (typeof dictionary !== "undefined") {
    const additionalVocab = {
      "favourite": { "pos": "adj.", "mm": "အချစ်ခင်အနှစ်သက်ဆုံးသော" },
      "person": { "pos": "n.", "mm": "လူပုဂ္ဂိုလ်" },
      "family": { "pos": "n.", "mm": "မိသားစု" },
      "grandmother": { "pos": "n.", "mm": "အဘွား" },
      "grandpa": { "pos": "n.", "mm": "အဘိုး" },
      "grandma": { "pos": "n.", "mm": "အဘွား" },
      "kindest": { "pos": "adj.", "mm": "အကြင်နာတတ်ဆုံးသော" },
      "angry": { "pos": "adj.", "mm": "စိတ်ဆိုးသော၊ ဒေါသထွက်သော" },
      "speaks": { "pos": "v.", "mm": "စကားပြောသည်" },
      "sweet": { "pos": "adj.", "mm": "ချိုသာသော၊ ချိုမြိန်သော" },
      "smile": { "pos": "n./v.", "mm": "အပြုံး / ပြုံးသည်" },
      "moreover": { "pos": "adv.", "mm": "ထို့အပြင်၊ ဒါ့အပြင်" },
      "delicious": { "pos": "adj.", "mm": "အရသာရှိသော" },
      "traditional": { "pos": "adj.", "mm": "ရိုးရာအစဉ်အလာဖြစ်သော" },
      "shares": { "pos": "v.", "mm": "ဝေမျှပေးသည်" },
      "neighbours": { "pos": "n.", "mm": "အိမ်နီးချင်းများ" },
      "reasons": { "pos": "n.", "mm": "အကြောင်းပြချက်များ" },
      "respect": { "pos": "v./n.", "mm": "လေးစားသည် / လေးစားမှု" },
      "attend": { "pos": "v.", "mm": "တက်ရောက်သည်" },
      "located": { "pos": "adj.", "mm": "တည်ရှိသော" },
      "peaceful": { "pos": "adj.", "mm": "အေးချမ်းသာယာသော" },
      "thousand": { "pos": "n.", "mm": "တစ်ထောင် (၁,၀၀၀)" },
      "classrooms": { "pos": "n.", "mm": "စာသင်ခန်းများ" },
      "well-equipped": { "pos": "adj.", "mm": "ပစ္စည်းကိရိယာ အပြည့်အစုံ တပ်ဆင်ထားသော" },
      "science": { "pos": "n.", "mm": "သိပ္ပံဘာသာရပ်" },
      "library": { "pos": "n.", "mm": "စာကြည့်တိုက်" },
      "playground": { "pos": "n.", "mm": "အားကစားကွင်း၊ ကစားကွင်း" },
      "weekends": { "pos": "n.", "mm": "စနေ၊ တနင်္ဂနွေ အားလပ်ရက်များ" },
      "extra-curricular": { "pos": "adj.", "mm": "ကျောင်းပြင်ပ (သင်ရိုးပြင်ပ) ဖြစ်သော" },
      "activities": { "pos": "n.", "mm": "လှုပ်ရှားမှုများ" },
      "scouting": { "pos": "n.", "mm": "ကင်းထောက်လှုပ်ရှားမှု" },
      "proud": { "pos": "adj.", "mm": "ဂုဏ်ယူသော" },
      "knowledge": { "pos": "n.", "mm": "ဗဟုသုတ၊ အသိပညာ" },
      "planet": { "pos": "n.", "mm": "ဂြိုဟ် / ကမ္ဘာမြေ" },
      "provides": { "pos": "v.", "mm": "ထောက်ပံ့ပေးသည်၊ ပေးစွမ်းသည်" },
      "protect": { "pos": "v.", "mm": "ကာကွယ်စောင့်ရှောက်သည်" },
      "practice": { "pos": "v./n.", "mm": "လက်တွေ့ကျင့်သုံးသည်" },
      "practise": { "pos": "v.", "mm": "လေ့ကျင့်သည်" },
      "instead": { "pos": "adv.", "mm": "၎င်းအစား (instead of = ...အစား)" },
      "plastic": { "pos": "n./adj.", "mm": "ပလတ်စတစ်" },
      "shopping": { "pos": "n.", "mm": "ဈေးဝယ်ထွက်ခြင်း" },
      "addition": { "pos": "n.", "mm": "ထပ်ပေါင်းခြင်း (In addition = ထို့အပြင်)" },
      "electricity": { "pos": "n.", "mm": "လျှပ်စစ်မီး / လျှပ်စစ်စွမ်းအင်" },
      "village": { "pos": "n.", "mm": "ကျေးရွာ" },
      "together": { "pos": "adv.", "mm": "အတူတကွ" },
      "cleaner": { "pos": "adj.", "mm": "ပို၍သန့်ရှင်းသော" },
      "greener": { "pos": "adj.", "mm": "ပို၍စိမ်းလန်းသော" },
      "healthier": { "pos": "adj.", "mm": "ပို၍ကျန်းမာရေးနှင့်ညီညွတ်သော" },
      "summer": { "pos": "n.", "mm": "နွေရာသီ" },
      "holiday": { "pos": "n.", "mm": "အားလပ်ရက် / ကျောင်းပိတ်ရက်" },
      "travelled": { "pos": "v.", "mm": "ခရီးသွားခဲ့သည်" },
      "coach": { "pos": "n.", "mm": "အဝေးပြေးမှန်လုံကားကြီး" },
      "enjoyed": { "pos": "v.", "mm": "နှစ်သက်ပျော်ရွှင်စွာ ခံစားခဲ့သည်" },
      "scenic": { "pos": "adj.", "mm": "ရှုခင်းသာယာလှပသော" },
      "views": { "pos": "n.", "mm": "မြင်ကွင်းများ၊ ရှုခင်းများ" },
      "mountains": { "pos": "n.", "mm": "တောင်တန်းများ" },
      "arrived": { "pos": "v.", "mm": "ရောက်ရှိခဲ့သည်" },
      "beach": { "pos": "n.", "mm": "ပင်လယ်ကမ်းခြေ" },
      "relaxing": { "pos": "adj.", "mm": "စိတ်အပန်းပြေစေသော" },
      "swam": { "pos": "v.", "mm": "ရေကူးခဲ့သည် (swim ၏ အတိတ်ကာလ)" },
      "built": { "pos": "v.", "mm": "တည်ဆောက်ခဲ့သည် (build ၏ အတိတ်ကာလ)" },
      "sandcastles": { "pos": "n.", "mm": "သဲရဲတိုက်များ" },
      "seafood": { "pos": "n.", "mm": "ပင်လယ်စာ" },
      "although": { "pos": "conj.", "mm": "...သော်လည်းပဲ" },
      "tired": { "pos": "adj.", "mm": "ပင်ပန်းနွမ်းနယ်သော" },
      "returned": { "pos": "v.", "mm": "ပြန်လာခဲ့သည်" },
      "happiest": { "pos": "adj.", "mm": "အပျော်ရွှင်ရဆုံးသော" },
      "exciting": { "pos": "adj.", "mm": "စိတ်လှုပ်ရှားဖွယ်ကောင်းသော" },
      "coming": { "pos": "adj.", "mm": "လာမည့် (coming weekend = လာမည့်အားလပ်ရက်)" },
      "uncle": { "pos": "n.", "mm": "ဦးလေး" },
      "arranged": { "pos": "v.", "mm": "စီစဉ်ပေးထားသည်" },
      "camping": { "pos": "n.", "mm": "တောတွင်းစခန်းချခရီးထွက်ခြင်း" },
      "trekking": { "pos": "n.", "mm": "တောင်တက်ခရီးကြမ်း လျှောက်ခြင်း" },
      "hills": { "pos": "n.", "mm": "တောင်ကုန်းတောင်တန်းများ" },
      "prepared": { "pos": "v.", "mm": "ပြင်ဆင်ထားပြီးဖြစ်သည်" },
      "tents": { "pos": "n.", "mm": "ရွက်ဖျင်တဲများ" },
      "sleeping": { "pos": "adj./n.", "mm": "အိပ်စက်ရန် (sleeping bag = အိပ်ရာလိပ်အိတ်)" },
      "backpacks": { "pos": "n.", "mm": "ကျောပိုးအိတ်များ" },
      "worry": { "pos": "v.", "mm": "စိုးရိမ်ပူပန်သည်" },
      "parents": { "pos": "n.", "mm": "မိဘများ" },
      "permission": { "pos": "n.", "mm": "ခွင့်ပြုချက်" },
      "lightweight": { "pos": "adj.", "mm": "ပေါ့ပါးသော" },
      "carry": { "pos": "v.", "mm": "သယ်ဆောင်သည်" },
      "whenever": { "pos": "conj.", "mm": "မည်သည့်အချိန်မဆို" },
      "e-books": { "pos": "n.", "mm": "အီလက်ထရွန်နစ် စာအုပ်များ" },
      "dictionary": { "pos": "n.", "mm": "အဘိဓာန်" },
      "educational": { "pos": "adj.", "mm": "ပညာရေးနှင့်ဆိုင်သော" },
      "grades": { "pos": "n.", "mm": "အဆင့်အမှတ်များ" },
      "habits": { "pos": "n.", "mm": "အလေ့အကျင့်များ" },
      "usually": { "pos": "adv.", "mm": "ပုံမှန်အားဖြင့်၊ အများအားဖြင့်" },
      "between": { "pos": "prep.", "mm": "ကြားထဲတွင်" },
      "meals": { "pos": "n.", "mm": "ထမင်းစားချိန်များ / အစားအစာများ" },
      "enough": { "pos": "adj.", "mm": "လုံလောက်သော" },
      "finish": { "pos": "v.", "mm": "ပြီးဆုံးသည်" },
      "minutes": { "pos": "n.", "mm": "မိနစ်များ" },
      "alone": { "pos": "adj./adv.", "mm": "တစ်ယောက်တည်း" },
      "watching": { "pos": "v.", "mm": "ကြည့်ရှုနေစဉ်" },
      "dining": { "pos": "n.", "mm": "ထမင်းစားခြင်း (dining table = ထမင်းစားပွဲ)" },
      "experiences": { "pos": "n.", "mm": "အတွေ့အကြုံများ" },
      "believe": { "pos": "v.", "mm": "ယုံကြည်သည်" },
      "whole": { "pos": "adj.", "mm": "တစ်ခုလုံး၊ အားလုံးသော" },
      "brings": { "pos": "v.", "mm": "ယူဆောင်လာပေးသည်" },
      "benefits": { "pos": "n.", "mm": "အကျိုးကျေးဇူးများ" },
      "developing": { "pos": "v.", "mm": "ဖွံ့ဖြိုးတိုးတက်စေခြင်း" },
      "skills": { "pos": "n.", "mm": "ကျွမ်းကျင်မှုများ (life skills = ဘဝတွက်တာကျွမ်းကျင်မှု)" },
      "cleaning": { "pos": "v./n.", "mm": "သန့်ရှင်းရေးလုပ်ခြင်း" },
      "dishes": { "pos": "n.", "mm": "ပန်းကန်ခွက်ယောက်များ (doing the dishes = ပန်းကန်ဆေးခြင်း)" },
      "responsible": { "pos": "adj.", "mm": "တာဝန်သိတတ်သော" },
      "jogging": { "pos": "n.", "mm": "အပြေးလေ့ကျင့်ခြင်း" },
      "cycling": { "pos": "n.", "mm": "စက်ဘီးစီးခြင်း" },
      "especially": { "pos": "adv.", "mm": "အထူးသဖြင့်" },
      "exercise": { "pos": "n./v.", "mm": "ကိုယ်လက်လှုပ်ရှား လေ့ကျင့်ခန်း" },
      "difficult": { "pos": "adj.", "mm": "ခက်ခဲသော" },
      "prepares": { "pos": "v.", "mm": "ပြင်ဆင်ပေးသည်" },
      "boils": { "pos": "v.", "mm": "ပြုတ်သည်" },
      "boiled": { "pos": "adj.", "mm": "ပြုတ်ထားသော" },
      "packs": { "pos": "v.", "mm": "ထုပ်ပိုးထည့်ပေးသည်" },
      "vegetables": { "pos": "n.", "mm": "ဟင်းသီးဟင်းရွက်များ" },
      "shower": { "pos": "n.", "mm": "ရေပန်းဖြင့် ရေချိုးခြင်း" },
      "heads": { "pos": "v.", "mm": "ဦးတည်သွားသည်" },
      "engineer": { "pos": "n.", "mm": "အင်ဂျင်နီယာ" },
      "safety": { "pos": "n.", "mm": "ဘေးအန္တရာယ် ကင်းရှင်းရေး" },
      "jacket": { "pos": "n.", "mm": "ဂျာကင်အင်္ကျီ" },
      "boots": { "pos": "n.", "mm": "လည်ရှည်ဖိနပ်များ" },
      "workers": { "pos": "n.", "mm": "အလုပ်သမားများ" },
      "clothing": { "pos": "n.", "mm": "ဝတ်စုံ၊ အဝတ်အထည်" },
      "meeting": { "pos": "n.", "mm": "အစည်းအဝေး" },
      "staff": { "pos": "n.", "mm": "ဝန်ထမ်းများ" }
    };

    Object.keys(additionalVocab).forEach(function(wordKey) {
      if (!dictionary[wordKey]) {
        dictionary[wordKey] = additionalVocab[wordKey];
      }
    });
  }

  if (typeof unitsData === "undefined") return;

  // ၂။ အသံထွက်စနစ် (EN + MM) တွင် ဝါကျမပြတ်တောက်စေရန် အတိုကောက်နှင့် အမှားများကို အလိုအလျောက် သန့်စင်ခြင်း
  unitsData.forEach(function(unit, uIdx) {
    unit.sections.forEach(function(sec) {
      sec.passage.forEach(function(p) {
        // Fix Unit 11 mixed Myanmar text inside English field
        if (uIdx === 10 && p.en.indexOf("ASAP =") !== -1) {
          p.en = "Common Text Message Abbreviations: ASAP means As soon as possible. BTW means By the way. CUL8R means See you later. FYI means For your information. GR8 means Great. IDK means I don't know. LOL means Laugh out loud. PLZ means Please. THX means Thanks. TTYL means Talk to you later. UR means Your or You are.";
          p.mm = "စာတိုပေးပို့ရာတွင် အသုံးများသော အတိုကောက်စကားလုံးများ: ASAP ဆိုသည်မှာ အမြန်ဆုံး၊ BTW ဆိုသည်မှာ စကားမစပ်၊ CUL8R ဆိုသည်မှာ နောက်မှတွေ့မယ်၊ FYI ဆိုသည်မှာ သိထားဖို့၊ GR8 ဆိုသည်မှာ အရမ်းကောင်းတယ်၊ IDK ဆိုသည်မှာ ငါမသိဘူး၊ PLZ ဆိုသည်မှာ ကျေးဇူးပြု၍၊ THX ဆိုသည်မှာ ကျေးဇူးတင်ပါတယ်၊ TTYL ဆိုသည်မှာ နောက်မှပြန်ပြောမယ် ဖြစ်ပါတယ်။";
        }

        // Fix Unit 8 Flamingo Lake typo in Myanmar translation
        if (uIdx === 7 && p.mm.indexOf("ဖလ flaming အင်း") !== -1) {
          p.mm = p.mm.replace("ဖလ flaming အင်း", "ဖလမင်ဂိုအင်း");
        }

        // Normalize abbreviations with periods in English so TTS sentence-splitter never cuts them in half
        p.en = p.en
          .replace(/\ba\.m\./gi, "AM")
          .replace(/\bp\.m\./gi, "PM")
          .replace(/\bNo\.\s*(\d+)/g, "Number $1")
          .replace(/(\d+)\s*ft\./g, "$1 feet")
          .replace(/\bMt\b/g, "Mount")
          .replace(/\be\.g\./gi, "for example");
      });
    });
  });
})();

