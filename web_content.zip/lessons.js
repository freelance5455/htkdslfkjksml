const dictionary = {
  "choke": {
    "pos": "v.",
    "mm": "အစာနင်သည်၊ လည်ချောင်းပိတ်၍ အသက်ရှူကျပ်သည်"
  },
  "digestion": {
    "pos": "n.",
    "mm": "အစာချေဖျက်ခြင်း"
  },
  "junk": {
    "pos": "n.",
    "mm": "အာဟာရမဖြစ်သော (အမှိုက်သရိုက်)"
  },
  "mindfully": {
    "pos": "adv.",
    "mm": "သတိကပ်၍၊ သေချာအာရုံစိုက်၍"
  },
  "mindlessly": {
    "pos": "adv.",
    "mm": "သတိလက်လွတ်၊ အမှတ်တမဲ့"
  },
  "obesity": {
    "pos": "n.",
    "mm": "အဝလွန်ခြင်း"
  },
  "sugary": {
    "pos": "adj.",
    "mm": "သကြားဓာတ်များသော၊ ချိုလွန်းသော"
  },
  "responsibility": {
    "pos": "n.",
    "mm": "တာဝန်ယူမှု၊ တာဝန်သိစိတ်"
  },
  "unity": {
    "pos": "n.",
    "mm": "စည်းလုံးညီညွတ်မှု"
  },
  "balanced": {
    "pos": "adj.",
    "mm": "မျှတသော"
  },
  "diet": {
    "pos": "n.",
    "mm": "စားသောက်မှုပုံစံ၊ အစားအစာ"
  },
  "manners": {
    "pos": "n.",
    "mm": "အမူအကျင့်၊ ယဉ်ကျေးမှု"
  },
  "chores": {
    "pos": "n.",
    "mm": "အိမ်မှုကိစ္စများ"
  },
  "cooperative": {
    "pos": "adj.",
    "mm": "ပူးပေါင်းဆောင်ရွက်တတ်သော"
  },
  "beneficial": {
    "pos": "adj.",
    "mm": "အကျိုးကျေးဇူးရှိသော"
  },
  "believe": {
    "pos": "v.",
    "mm": "ယုံကြည်သည်"
  },
  "activities": {
    "pos": "n.",
    "mm": "လှုပ်ရှားမှုများ"
  },
  "variety": {
    "pos": "n.",
    "mm": "အမျိုးအစားစုံလင်မှု"
  },
  "importance": {
    "pos": "n.",
    "mm": "အရေးပါမှု"
  },
  "household": {
    "pos": "adj./n.",
    "mm": "အိမ်ထောင်စု၊ အိမ်တွင်း"
  },
  "outdoor": {
    "pos": "adj.",
    "mm": "ပြင်ပ၌လုပ်သော"
  },
  "government": {
    "pos": "n.",
    "mm": "အစိုးရ"
  },
  "private": {
    "pos": "adj.",
    "mm": "ပုဂ္ဂလိက၊ ကိုယ်ပိုင်"
  },
  "monastic": {
    "pos": "adj.",
    "mm": "ဘုန်းတော်ကြီးသင်"
  },
  "strict": {
    "pos": "adj.",
    "mm": "စည်းကမ်းတင်းကျပ်သော"
  },
  "fundamental": {
    "pos": "adj.",
    "mm": "အခြေခံကျသော"
  },
  "foundation": {
    "pos": "n.",
    "mm": "အခြေခံအုတ်မြစ်"
  },
  "encouragement": {
    "pos": "n.",
    "mm": "အားပေးမြှင့်တင်မှု"
  },
  "inspiring": {
    "pos": "adj.",
    "mm": "စိတ်ဓာတ်ခွန်အားဖြစ်စေသော"
  },
  "dedicated": {
    "pos": "adj.",
    "mm": "စိတ်ရောကိုယ်ပါ နှစ်မြှုပ်ထားသော"
  },
  "memorable": {
    "pos": "adj.",
    "mm": "အမှတ်တရဖြစ်စေသော"
  },
  "schooldays": {
    "pos": "n.",
    "mm": "ကျောင်းသားဘဝနေ့ရက်များ"
  },
  "secondary": {
    "pos": "adj.",
    "mm": "အလယ်တန်း/အထက်တန်းဆင့်"
  },
  "education": {
    "pos": "n.",
    "mm": "ပညာရေး"
  },
  "knitting": {
    "pos": "n.",
    "mm": "သိုးမွှေးထိုးခြင်း"
  },
  "relaxation": {
    "pos": "n.",
    "mm": "စိတ်အပန်းဖြေခြင်း"
  },
  "creativity": {
    "pos": "n.",
    "mm": "တီထွင်ဖန်တီးနိုင်စွမ်း"
  },
  "orchestra": {
    "pos": "n.",
    "mm": "သံစုံတီးဝိုင်း"
  },
  "melody": {
    "pos": "n.",
    "mm": "သံစဉ်"
  },
  "professional": {
    "pos": "adj.",
    "mm": "ကျွမ်းကျင်ပညာရှင်ဖြစ်သော"
  },
  "martial": {
    "pos": "adj.",
    "mm": "ကိုယ်ခံပညာနှင့်ဆိုင်သော"
  },
  "stamina": {
    "pos": "n.",
    "mm": "သက်လုံကောင်းမှု၊ ခံနိုင်ရည်"
  },
  "confident": {
    "pos": "adj.",
    "mm": "မိမိကိုယ်ကို ယုံကြည်မှုရှိသော"
  },
  "strengthen": {
    "pos": "v.",
    "mm": "ပိုမိုခိုင်မာအားကောင်းစေသည်"
  },
  "reduce": {
    "pos": "v.",
    "mm": "လျှော့ချသည်"
  },
  "stress": {
    "pos": "n.",
    "mm": "စိတ်ဖိစီးမှု"
  },
  "violin": {
    "pos": "n.",
    "mm": "တယော"
  },
  "practical": {
    "pos": "adj.",
    "mm": "လက်တွေ့ကျသော"
  },
  "citizen": {
    "pos": "n.",
    "mm": "နိုင်ငံသား၊ ကမ္ဘာ့သားကောင်း"
  },
  "volunteer": {
    "pos": "v.",
    "mm": "စေတနာ့ဝန်ထမ်း လုပ်ဆောင်သည်"
  },
  "donate": {
    "pos": "v.",
    "mm": "လှူဒါန်းသည်"
  },
  "orphanage": {
    "pos": "n.",
    "mm": "မိဘမဲ့ဂေဟာ"
  },
  "cooperation": {
    "pos": "n.",
    "mm": "ပူးပေါင်းဆောင်ရွက်ခြင်း"
  },
  "adaptability": {
    "pos": "n.",
    "mm": "လိုက်လျောညီထွေ ပြောင်းလဲနိုင်စွမ်း"
  },
  "survival": {
    "pos": "n.",
    "mm": "ရှင်သန်ရပ်တည်နိုင်မှု"
  },
  "observant": {
    "pos": "adj.",
    "mm": "စူးစမ်းလေ့လာတတ်သော"
  },
  "teenagers": {
    "pos": "n.",
    "mm": "ဆယ်ကျော်သက်လူငယ်များ"
  },
  "community": {
    "pos": "n.",
    "mm": "ရပ်ရွာလူထု"
  },
  "achieve": {
    "pos": "v.",
    "mm": "အောင်မြင်စွာ ရရှိသည်"
  },
  "hardware": {
    "pos": "n.",
    "mm": "ကွန်ပျူတာ၏ ထိတွေ့ကိုင်တွယ်၍ရသော အစိတ်အပိုင်းများ"
  },
  "software": {
    "pos": "n.",
    "mm": "ကွန်ပျူတာကို မောင်းနှင်သော ပရိုဂရမ်များ"
  },
  "monitor": {
    "pos": "n.",
    "mm": "ကွန်ပျူတာ ဖန်သားပြင်"
  },
  "keyboard": {
    "pos": "n.",
    "mm": "စာရိုက်ခလုတ်ခုံ"
  },
  "cursor": {
    "pos": "n.",
    "mm": "ဖန်သားပြင်ပေါ်ရှိ ညွှန်ပြသင်္ကေတ"
  },
  "processing": {
    "pos": "n.",
    "mm": "အချက်အလက် စီမံဆောင်ရွက်ခြင်း"
  },
  "formatting": {
    "pos": "n.",
    "mm": "စာမျက်နှာပုံစံ ချိန်ညှိခြင်း"
  },
  "documents": {
    "pos": "n.",
    "mm": "စာရွက်စာတမ်းများ"
  },
  "sterilise": {
    "pos": "v.",
    "mm": "ပိုးသတ်သန့်စင်သည်"
  },
  "dissolve": {
    "pos": "v.",
    "mm": "အရည်ပျော်ဝင်သည်"
  },
  "saline": {
    "pos": "adj.",
    "mm": "ဆားရည်ပါသော"
  },
  "atmosphere": {
    "pos": "n.",
    "mm": "လေထု"
  },
  "ecosystem": {
    "pos": "n.",
    "mm": "ဂေဟစနစ်"
  },
  "interact": {
    "pos": "v.",
    "mm": "အပြန်အလှန် အကျိုးပြုဆက်ဆံသည်"
  },
  "fossil": {
    "pos": "n.",
    "mm": "ကျောက်ဖြစ်ရုပ်ကြွင်း"
  },
  "endangered": {
    "pos": "adj.",
    "mm": "မျိုးသုဉ်းရန် အန္တရာယ်ရှိသော"
  },
  "degraded": {
    "pos": "adj.",
    "mm": "အရည်အသွေး ကျဆင်းပျက်စီးသော"
  },
  "emitting": {
    "pos": "v.",
    "mm": "ထုတ်လွှတ်နေသော"
  },
  "disposing": {
    "pos": "v.",
    "mm": "စွန့်ပစ်နေသော"
  },
  "pollution": {
    "pos": "n.",
    "mm": "ညစ်ညမ်းမှု"
  },
  "recycle": {
    "pos": "v.",
    "mm": "ပြန်လည်အသုံးပြုရန် ပြုပြင်ထုတ်လုပ်သည်"
  },
  "essential": {
    "pos": "adj.",
    "mm": "မရှိမဖြစ် အရေးကြီးသော"
  },
  "adventurous": {
    "pos": "adj.",
    "mm": "စွန့်စားရသည်ကို နှစ်သက်သော"
  },
  "trek": {
    "pos": "n./v.",
    "mm": "တောင်တက်ခရီးကြမ်း လျှောက်ခြင်း"
  },
  "overlooking": {
    "pos": "prep.",
    "mm": "အပေါ်စီးမှ မြင်နေရသော"
  },
  "sunbathing": {
    "pos": "n.",
    "mm": "နေပူဆာလှုံခြင်း"
  },
  "bonfire": {
    "pos": "n.",
    "mm": "မီးပုံပွဲ"
  },
  "extraordinary": {
    "pos": "adj.",
    "mm": "ထူးခြားဆန်းပြားသော"
  },
  "unspoiled": {
    "pos": "adj.",
    "mm": "သဘာဝအတိုင်း မပျက်မစီးရှိနေသော"
  },
  "cruise": {
    "pos": "n.",
    "mm": "အပျော်စီးသင်္ဘောခရီးစဉ်"
  },
  "lifebuoys": {
    "pos": "n.",
    "mm": "အသက်ကယ်ဘောကွင်းများ"
  },
  "reasonable": {
    "pos": "adj.",
    "mm": "သင့်တင့်မျှတသော"
  },
  "coastal": {
    "pos": "adj.",
    "mm": "ကမ်းရိုးတန်းဒေသနှင့်ဆိုင်သော"
  },
  "facilities": {
    "pos": "n.",
    "mm": "ဝန်ဆောင်မှုနှင့် အသုံးအဆောင်ပစ္စည်းများ"
  },
  "furnished": {
    "pos": "adj.",
    "mm": "ပရိဘောဂ အပြည့်အစုံ တပ်ဆင်ထားသော"
  },
  "spacious": {
    "pos": "adj.",
    "mm": "ကျယ်ဝန်းသော"
  },
  "patio": {
    "pos": "n.",
    "mm": "အိမ်ရှေ့မြေကွက်လပ်/ဝရန်တာ"
  },
  "unique": {
    "pos": "adj.",
    "mm": "တစ်မူထူးခြားသော"
  },
  "bungalows": {
    "pos": "n.",
    "mm": "တစ်ထပ်တိုက်ပုလေးများ"
  },
  "organic": {
    "pos": "adj.",
    "mm": "ဓာတုဆေးဝါးကင်းစင်သော (သဘာဝ)"
  },
  "kitchenette": {
    "pos": "n.",
    "mm": "မီးဖိုချောင်ငယ်လေး"
  },
  "hospitable": {
    "pos": "adj.",
    "mm": "ဧည့်ဝတ်ကျေပွန်သော"
  },
  "panoramic": {
    "pos": "adj.",
    "mm": "မြင်ကွင်းကျယ်ဖြစ်သော"
  },
  "snowcapped": {
    "pos": "adj.",
    "mm": "ဆီးနှင်းများဖုံးလွှမ်းနေသော"
  },
  "majestically": {
    "pos": "adv.",
    "mm": "ခမ်းနားထည်ဝါစွာ"
  },
  "confluence": {
    "pos": "n.",
    "mm": "မြစ်ဆုံရာနေရာ"
  },
  "enormous": {
    "pos": "adj.",
    "mm": "အလွန်ကြီးမားသော"
  },
  "carvings": {
    "pos": "n.",
    "mm": "ပန်းပုလက်ရာများ"
  },
  "destination": {
    "pos": "n.",
    "mm": "ခရီးပန်းတိုင်၊ သွားရောက်ရာနေရာ"
  },
  "heritage": {
    "pos": "n.",
    "mm": "အမွေအနှစ်"
  },
  "biodiversity": {
    "pos": "n.",
    "mm": "ဇီဝမျိုးစုံမျိုးကွဲများ"
  },
  "impulse": {
    "pos": "n.",
    "mm": "ရုတ်တရက် စိတ်ကူးပေါ်ခြင်း"
  },
  "dilemma": {
    "pos": "n.",
    "mm": "အကျပ်အတည်း၊ ဝေခွဲရခက်သော အခြေအနေ"
  },
  "pastime": {
    "pos": "n.",
    "mm": "အားလပ်ချိန် ဝါသနာ"
  },
  "meditating": {
    "pos": "v.",
    "mm": "တရားထိုင်ခြင်း"
  },
  "majority": {
    "pos": "n.",
    "mm": "အများစု"
  },
  "pressure": {
    "pos": "n.",
    "mm": "ဖိအား"
  },
  "ambitious": {
    "pos": "adj.",
    "mm": "ရည်မှန်းချက်ကြီးသော"
  },
  "leisure": {
    "pos": "n.",
    "mm": "အားလပ်ချိန်"
  },
  "refresh": {
    "pos": "v.",
    "mm": "လန်းဆန်းစေသည်"
  },
  "satisfaction": {
    "pos": "n.",
    "mm": "စိတ်ကျေနပ်မှု"
  },
  "concentrate": {
    "pos": "v.",
    "mm": "အာရုံစူးစိုက်သည်"
  },
  "gerund": {
    "pos": "n.",
    "mm": "နာမ်အဖြစ်သုံးသော -ing ကြိယာ"
  },
  "digital": {
    "pos": "adj.",
    "mm": "ဒစ်ဂျစ်တယ်နည်းပညာသုံး"
  },
  "device": {
    "pos": "n.",
    "mm": "စက်ပစ္စည်းကိရိယာ"
  },
  "portable": {
    "pos": "adj.",
    "mm": "သယ်ဆောင်ရလွယ်ကူသော"
  },
  "laptop": {
    "pos": "n.",
    "mm": "လက်တော့ပ် ကွန်ပျူတာ"
  },
  "tablet": {
    "pos": "n.",
    "mm": "တက်ဘလက်"
  },
  "smartwatch": {
    "pos": "n.",
    "mm": "စမတ်နာရီ"
  },
  "advantages": {
    "pos": "n.",
    "mm": "အားသာချက်များ"
  },
  "disadvantages": {
    "pos": "n.",
    "mm": "အားနည်းချက်များ"
  },
  "communicate": {
    "pos": "v.",
    "mm": "ဆက်သွယ်ပြောဆိုသည်"
  },
  "entertainment": {
    "pos": "n.",
    "mm": "ဖျော်ဖြေရေး"
  },
  "addicted": {
    "pos": "adj.",
    "mm": "စွဲလမ်းနေသော"
  },
  "eyesight": {
    "pos": "n.",
    "mm": "မျက်စိအမြင်အာရုံ"
  },
  "breaking": {
    "pos": "adj.",
    "mm": "နောက်ဆုံးရ (သတင်း)"
  },
  "headline": {
    "pos": "n.",
    "mm": "သတင်းခေါင်းစဉ်"
  },
  "journalist": {
    "pos": "n.",
    "mm": "သတင်းထောက်"
  },
  "broadcast": {
    "pos": "v./n.",
    "mm": "ထုတ်လွှင့်သည်"
  },
  "neighbourhood": {
    "pos": "n.",
    "mm": "ပတ်ဝန်းကျင်၊ ရပ်ကွက်"
  },
  "incident": {
    "pos": "n.",
    "mm": "ဖြစ်ရပ်၊ အဖြစ်အပျက်"
  },
  "rescue": {
    "pos": "v./n.",
    "mm": "ကယ်ဆယ်သည်"
  },
  "damaged": {
    "pos": "adj.",
    "mm": "ပျက်စီးသွားသော"
  },
  "announced": {
    "pos": "v.",
    "mm": "ကြေညာခဲ့သည်"
  },
  "emergency": {
    "pos": "n.",
    "mm": "အရေးပေါ်အခြေအနေ"
  },
  "airy": {
    "pos": "adj.",
    "mm": "လေကဲ့သို့ ပေါ့ပါးသော၊ မမြင်နိုင်သော"
  },
  "creatures": {
    "pos": "n.",
    "mm": "သတ္တဝါများ၊ အရာများ"
  },
  "features": {
    "pos": "n.",
    "mm": "ထူးခြားသော လက္ခဏာရပ်များ"
  },
  "pursue": {
    "pos": "v.",
    "mm": "လိုက်လံရှာဖွေသည်၊ ကြိုးပမ်းသည်"
  },
  "clatters": {
    "pos": "v.",
    "mm": "တဖြောက်ဖြောက် မြည်သည်"
  },
  "gushes": {
    "pos": "v.",
    "mm": "အရှိန်ပြင်းစွာ စီးဆင်းထွက်ကျသည်"
  },
  "overflowing": {
    "pos": "adj.",
    "mm": "လျှံကျနေသော"
  },
  "spout": {
    "pos": "n.",
    "mm": "ရေတံလျှောက်ပေါက်"
  },
  "gutter": {
    "pos": "n.",
    "mm": "ရေမြောင်း"
  },
  "roars": {
    "pos": "v.",
    "mm": "ဟိန်းဟောက်မြည်ဟည်းသည်"
  },
  "snare": {
    "pos": "n.",
    "mm": "ကျော့ကွင်း၊ ထောင်ချောက်"
  },
  "aid": {
    "pos": "n.",
    "mm": "အကူအညီ"
  },
  "frightened": {
    "pos": "adj.",
    "mm": "ကြောက်ရွံ့ထိတ်လန့်နေသော"
  },
  "wrinkling": {
    "pos": "v.",
    "mm": "တွန့်ရှုံ့နေသော"
  },
  "paw": {
    "pos": "n.",
    "mm": "တိရစ္ဆာန်၏ ခြေဖဝါး"
  },
  "beams": {
    "pos": "n.",
    "mm": "အလင်းတန်းများ"
  },
  "harbour": {
    "pos": "n.",
    "mm": "ဆိပ်ကမ်း"
  },
  "quays": {
    "pos": "n.",
    "mm": "သင်္ဘောဆိပ်ခံတံတားများ"
  },
  "thieves": {
    "pos": "n.",
    "mm": "သူခိုးများ"
  },
  "squalling": {
    "pos": "v.",
    "mm": "စူးရှစွာ အော်ဟစ်နေသော"
  },
  "howling": {
    "pos": "v.",
    "mm": "အူနေသော (ခွေး)"
  },
  "squeaking": {
    "pos": "v.",
    "mm": "တကျွီကျွီ မြည်နေသော"
  },
  "patient": {
    "pos": "adj.",
    "mm": "စိတ်ရှည်သည်းခံသော"
  },
  "snacks": {
    "pos": "n.",
    "mm": "မုန့်ပဲသရေစာများ"
  },
  "neighbours": {
    "pos": "n.",
    "mm": "အိမ်နီးချင်းများ"
  },
  "compound": {
    "pos": "n.",
    "mm": "ခြံဝင်း"
  },
  "excursion": {
    "pos": "n.",
    "mm": "လေ့လာရေးခရီးစဉ်"
  }
};

const unitsData = [
  {
    "title": "Unit 1: Learning starts at home (မိသားစုအလေ့အကျင့်ကောင်းများ)",
    "passage": [
      {
        "en": "I believe that doing some activities together as a whole family brings some benefits to our children such as developing a sense of responsibility and unity, and developing life skills.",
        "mm": "မိသားစုတစ်စုလုံး အတူတကွ လှုပ်ရှားမှုတွေ လုပ်ဆောင်ခြင်းဟာ ကလေးတွေအတွက် တာဝန်ယူစိတ်နဲ့ စည်းလုံးညီညွတ်မှု တိုးပွားစေခြင်း၊ ဘဝတွက်တာ ကျွမ်းကျင်မှုတွေ ဖွံ့ဖြိုးစေခြင်း စတဲ့ အကျိုးကျေးဇူးတွေ ရရှိစေတယ်လို့ ကျွန်မ ယုံကြည်ပါတယ်။"
      },
      {
        "en": "In my family, we have dinner together every day.",
        "mm": "ကျွန်မတို့ မိသားစုမှာ နေ့တိုင်း ညစာကို အတူတကွ စားသုံးကြပါတယ်။"
      },
      {
        "en": "Having meals together, I can remind my children to eat a variety of food so they become aware of the importance of having a balanced diet.",
        "mm": "ထမင်းအတူစားခြင်းအားဖြင့် ကလေးတွေကို အစားအစာ စုံလင်အောင်စားဖို့ သတိပေးနိုင်ပြီး အာဟာရမျှတတဲ့ အစားအသောက်ရဲ့ အရေးပါပုံကို သူတို့ သိရှိလာစေပါတယ်။"
      },
      {
        "en": "Every Saturday, we spend time together at home and share household chores like cleaning the windows, sweeping the floor and doing the dishes.",
        "mm": "စနေနေ့တိုင်း အိမ်မှာ အတူတူအချိန်ဖြုန်းကြပြီး ပြတင်းပေါက်သန့်ရှင်းရေးလုပ်တာ၊ ကြမ်းလှဲတာနဲ့ ပန်းကန်ဆေးတာလို အိမ်မှုကိစ္စတွေကို ခွဲဝေလုပ်ဆောင်ကြပါတယ်။"
      },
      {
        "en": "On Sundays, we usually engage in outdoor activities like jogging or cycling in the park.",
        "mm": "တနင်္ဂနွေနေ့တွေမှာတော့ ပန်းခြံထဲမှာ အပြေးလေ့ကျင့်တာ ဒါမှမဟုတ် စက်ဘီးစီးတာလို ပြင်ပလှုပ်ရှားမှုတွေကို လုပ်ဆောင်လေ့ရှိပါတယ်။"
      }
    ],
    "games": [
      {
        "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (Unit 1 Vocab)",
        "q": "'balanced diet' ဆိုတာ မြန်မာလို ဘာကို ဆိုလိုတာလဲ?",
        "mode": "mcq",
        "options": [
          "အချိုရည်များသောက်ခြင်း",
          "အာဟာရမျှတသော အစားအစာ",
          "အသင့်စား အစားအစာ",
          "တီဗွီကြည့်ရင်း စားခြင်း"
        ],
        "ans": 1,
        "explain": "'balanced diet' ဆိုတာ အသား၊ ငါး၊ ဟင်းသီးဟင်းရွက် စုံလင်မျှတအောင် စားသုံးခြင်း ဖြစ်ပါတယ်။"
      },
      {
        "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Grammar: Adverbs)",
        "q": "'သူသည် မနက် ၅ နာရီတွင် အိပ်ရာထလေ့ရှိသည်' ကို အင်္ဂလိပ်လို စီပါ။",
        "mode": "scramble",
        "words": [
          "He",
          "usually",
          "gets",
          "up",
          "at",
          "five",
          "o'clock."
        ],
        "explain": "Adverb of frequency (usually) ကို Main verb (gets up) ရဲ့ အရှေ့မှာ ထားရပါတယ်။"
      },
      {
        "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Unit 1 Grammar)",
        "q": "Thuzar is very punctual. She is _____ late for class.",
        "mode": "mcq",
        "options": [
          "always",
          "never",
          "often",
          "usually"
        ],
        "ans": 1,
        "explain": "အချိန်တိကျသူ (punctual) ဖြစ်တဲ့အတွက် အတန်းနောက်ကျလေ့ လုံးဝမရှိပါဘူး ('never')။"
      },
      {
        "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Reading Check)",
        "q": "စာပိုဒ်ထဲက မိသားစုဟာ စနေနေ့တိုင်း အိမ်မှုကိစ္စတွေကို အတူတူ ခွဲဝေလုပ်ဆောင်ကြပါတယ်။",
        "mode": "mcq",
        "options": [
          "မှန်တယ် (True)",
          "မှားတယ် (False)"
        ],
        "ans": 0,
        "explain": "မှန်ပါတယ်! 'Every Saturday, we share the household chores' လို့ ဖော်ပြထားပါတယ်။"
      }
    ]
  },
  {
    "title": "Unit 2: My Schooldays (ကျွန်ုပ်၏ ကျောင်းသားဘဝနေ့ရက်များ)",
    "passage": [
      {
        "en": "Schooldays play an important part in our lives because the people we meet and the skills we learn there shape our lives.",
        "mm": "ကျောင်းသားဘဝနေ့ရက်တွေဟာ ကျွန်ုပ်တို့ဘဝမှာ အရေးပါတဲ့ အခန်းကဏ္ဍကနေ ပါဝင်ပါတယ်၊ ဘာလို့လဲဆိုတော့ ကျောင်းမှာ တွေ့ဆုံရတဲ့သူတွေနဲ့ သင်ယူရတဲ့ ကျွမ်းကျင်မှုတွေက ကျွန်ုပ်တို့ဘဝကို ပုံဖော်ပေးလို့ပါပဲ။"
      },
      {
        "en": "My primary school life began when I was five at a mixed school where the teachers were rather strict.",
        "mm": "ကျွန်မရဲ့ မူလတန်းကျောင်းသားဘဝကို အသက် ၅ နှစ်အရွယ်မှာ ဆရာဆရာမတွေ အတော်လေး စည်းကမ်းတင်းကျပ်တဲ့ ကျား/မ တွဲဖက်ကျောင်းလေးမှာ စတင်ခဲ့ပါတယ်။"
      },
      {
        "en": "We started to develop fundamental skills such as reading, writing and mathematics which formed a solid foundation of learning.",
        "mm": "စာဖတ်ခြင်း၊ စာရေးခြင်းနဲ့ သင်္ချာစတဲ့ အခြေခံကျွမ်းကျင်မှုတွေကို စတင်သင်ယူခဲ့ပြီး အဲဒါတွေက ပညာသင်ယူမှုအတွက် ခိုင်မာတဲ့ အုတ်မြစ်ဖြစ်ခဲ့ပါတယ်။"
      },
      {
        "en": "My Grade 4 class teacher always encouraged us to improve ourselves, and I always remember her as an inspiring teacher.",
        "mm": "ကျွန်မရဲ့ Grade 4 အတန်းပိုင်ဆရာမက ကိုယ့်ကိုယ်ကို တိုးတက်အောင် အမြဲအားပေးခဲ့လို့ သူမကို စိတ်ဓာတ်ခွန်အားပေးတဲ့ ဆရာမအဖြစ် အမြဲသတိရနေပါတယ်။"
      },
      {
        "en": "For my secondary education, I went to an all-girls high school where all the teachers were dedicated to their work.",
        "mm": "အလယ်တန်းနဲ့ အထက်တန်းပညာရေးအတွက်တော့ ဆရာမအားလုံး အလုပ်အပေါ် စိတ်ရောကိုယ်ပါ နှစ်မြှုပ်ထားတဲ့ မိန်းကလေးသီးသန့် အထက်တန်းကျောင်းကို တက်ရောက်ခဲ့ပါတယ်။"
      }
    ],
    "games": [
      {
        "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (Types of Schools)",
        "q": "'all-girls school' ဆိုတာ ဘယ်လိုကျောင်းမျိုးလဲ?",
        "mode": "mcq",
        "options": [
          "ကျား/မ တွဲဖက်ကျောင်း",
          "မိန်းကလေးသီးသန့်ကျောင်း",
          "ဘုန်းတော်ကြီးသင်ကျောင်း",
          "ပုဂ္ဂလိကကျောင်း"
        ],
        "ans": 1,
        "explain": "'all-girls school' ဆိုတာ မိန်းကလေးများသာ တက်ရောက်ရသော ကျောင်းဖြစ်ပါတယ်။"
      },
      {
        "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Grammar: There is/are)",
        "q": "'ကျွန်ုပ်တို့ကျောင်းတွင် ဆရာ ၄၀ နှင့် ကျောင်းသား ၁၂၀၀ ရှိသည်' ကို စီပါ။",
        "mode": "scramble",
        "words": [
          "There",
          "are",
          "40",
          "teachers",
          "and",
          "1,200",
          "students."
        ],
        "explain": "အများကိန်း (40 teachers) ဖြစ်တဲ့အတွက် 'There are' ကို သုံးရပါတယ်။"
      },
      {
        "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Subject vs Object Question)",
        "q": "_____ teaches you English? — Daw Thida teaches us English.",
        "mode": "mcq",
        "options": [
          "Who",
          "Who does",
          "What do",
          "Whom"
        ],
        "ans": 0,
        "explain": "ပြုလုပ်သူ (Subject) ကို မေးတဲ့ Subject Question ဖြစ်လို့ 'Who + Verb (teaches)' တိုက်ရိုက်သုံးရပါတယ်။"
      },
      {
        "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Reading Check)",
        "q": "စာရေးသူရဲ့ Grade 4 အတန်းပိုင်ဆရာမရဲ့ အားပေးမှုကြောင့် စာစီစာကုံးပြိုင်ပွဲမှာ ဆုရခဲ့ပါတယ်။",
        "mode": "mcq",
        "options": [
          "မှန်တယ် (True)",
          "မှားတယ် (False)"
        ],
        "ans": 0,
        "explain": "မှန်ပါတယ်! ဆရာမရဲ့ အားပေးမှုကြောင့် Essay ပြိုင်ပွဲမှာ ဆုရခဲ့တာ ဖြစ်ပါတယ်။"
      }
    ]
  },
  {
    "title": "Unit 3: Extra-curricular Activities (ကျောင်းပြင်ပ လှုပ်ရှားမှုများ)",
    "passage": [
      {
        "en": "Yin Moe practises knitting every day after school because it helps to reduce stress and boost creativity.",
        "mm": "ယဉ်မိုးဟာ ကျောင်းဆင်းပြီးတိုင်း နေ့စဉ် သိုးမွှေးထိုးလေ့ကျင့်ပါတယ်၊ ဘာလို့လဲဆိုတော့ အဲဒါက စိတ်ဖိစီးမှုကို လျှော့ချပေးပြီး တီထွင်ဖန်တီးနိုင်စွမ်းကို မြှင့်တင်ပေးလို့ပါပဲ။"
      },
      {
        "en": "Ei Khine plays the violin every day and loves its beautiful melody, which helps to improve memory and social skills.",
        "mm": "အိခိုင်ကတော့ နေ့တိုင်း တယောထိုးလေ့ကျင့်ပြီး သာယာတဲ့ သံစဉ်လေးတွေကို နှစ်သက်ပါတယ်၊ တယောထိုးခြင်းက မှတ်ဉာဏ်နဲ့ လူမှုဆက်ဆံရေးစွမ်းရည်ကို တိုးတက်စေပါတယ်။"
      },
      {
        "en": "Aung Ko practises karate every weekend for self-defence and health, as it helps to strengthen muscles and build up stamina.",
        "mm": "အောင်ကိုကတော့ ကိုယ့်ကိုယ်ကို ခုခံကာကွယ်ဖို့နဲ့ ကျန်းမာရေးအတွက် အပတ်စဉ်တိုင်း ကရာတေးကစားပါတယ်၊ ဒါက ကြွက်သားတွေ သန်မာစေပြီး သက်လုံကောင်းစေပါတယ်။"
      },
      {
        "en": "Min Khant is a boy scout who learns practical skills like first aid and tying knots, and goes camping during school holidays.",
        "mm": "မင်းခန့်ကတော့ ရှေးဦးသူနာပြုစုနည်းနဲ့ ကြိုးချည်နည်းတွေ သင်ယူရတဲ့ ကင်းထောက်လူငယ်တစ်ဦးဖြစ်ပြီး ကျောင်းပိတ်ရက်တွေမှာ စခန်းချခရီး ထွက်လေ့ရှိပါတယ်။"
      }
    ],
    "games": [
      {
        "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (Borrow vs Lend)",
        "q": "သူငယ်ချင်းဆီက ခဲတံခဏ 'ငှားယူချင်တယ်' ဆိုရင် ဘယ်စကားလုံး သုံးရမလဲ?",
        "mode": "mcq",
        "options": [
          "lend",
          "borrow",
          "give",
          "send"
        ],
        "ans": 1,
        "explain": "သူများဆီက ခဏယူသုံးတာကို 'borrow' လို့သုံးပြီး၊ ကိုယ်က သူများကို ပေးငှားတာကို 'lend' လို့ သုံးပါတယ်။"
      },
      {
        "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Making Requests)",
        "q": "'ကျေးဇူးပြု၍ ငါ့ကို ဆားကမ်းပေးနိုင်မလား' ကို စာကြောင်းစီပါ။",
        "mode": "scramble",
        "words": [
          "Can",
          "you",
          "pass",
          "me",
          "the",
          "salt,",
          "please?"
        ],
        "explain": "ယဉ်ကျေးစွာ တောင်းဆိုတဲ့အခါ 'Can you + V-infinitive..., please?' ပုံစံ သုံးရပါတယ်။"
      },
      {
        "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Unit 3 Vocabulary)",
        "q": "Doing karate helps to strengthen muscles and build up _____.",
        "mode": "mcq",
        "options": [
          "melody",
          "yarns",
          "stamina",
          "needles"
        ],
        "ans": 2,
        "explain": "ကရာတေးကစားခြင်းက သက်လုံကောင်းစေ ('build up stamina') ပါတယ်။"
      },
      {
        "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Musical Instruments)",
        "q": "စာပိုဒ်အရ Flute (ပလွေ) နဲ့ Clarinet တို့ဟာ လေမှုတ်တူရိယာ (Wind instruments) များ ဖြစ်ကြပါတယ်။",
        "mode": "mcq",
        "options": [
          "မှန်တယ် (True)",
          "မှားတယ် (False)"
        ],
        "ans": 0,
        "explain": "မှန်ပါတယ်! လေမှုတ်ပြီး အသံထွက်ရတဲ့ တူရိယာတွေကို Wind instruments လို့ ခေါ်ပါတယ်။"
      }
    ]
  },
  {
    "title": "Unit 4: A Global Citizen (ကမ္ဘာ့သားကောင်းတစ်ဦး၏ အရည်အချင်းများ)",
    "passage": [
      {
        "en": "To create a healthy environment, teenagers are as responsible as adults, so we volunteer to clean up our community and plant shady trees.",
        "mm": "ကျန်းမာသန့်ရှင်းတဲ့ ပတ်ဝန်းကျင်ကို ဖန်တီးဖို့ လူကြီးတွေနည်းတူ ဆယ်ကျော်သက်လူငယ်တွေမှာလည်း တာဝန်ရှိတာကြောင့် ရပ်ရွာသန့်ရှင်းရေးနဲ့ အရိပ်ရသစ်ပင်စိုက်ပျိုးရေးတွေမှာ စေတနာ့ဝန်ထမ်း ပါဝင်ကြပါတယ်။"
      },
      {
        "en": "We should be kind to everyone we meet and offer food, clothing, or money to people in need.",
        "mm": "ကျွန်ုပ်တို့ တွေ့ဆုံရသူတိုင်းအပေါ် ကြင်နာသင့်ပြီး အကူအညီလိုအပ်နေသူတွေကို အစားအစာ၊ အဝတ်အထည် ဒါမှမဟုတ် ငွေကြေး လှူဒါန်းကူညီသင့်ပါတယ်။"
      },
      {
        "en": "Cooperation is one of the most important qualities a global citizen should have because it is difficult to achieve success without working together.",
        "mm": "ပူးပေါင်းဆောင်ရွက်မှုဟာ ကမ္ဘာ့သားကောင်းတစ်ဦး ရှိသင့်တဲ့ အရေးအကြီးဆုံး အရည်အချင်းတစ်ခု ဖြစ်ပါတယ်၊ ဘာလို့လဲဆိုတော့ အတူတကွ မလုပ်ဆောင်ဘဲ အောင်မြင်မှုရဖို့ ခက်ခဲလို့ပါပဲ။"
      },
      {
        "en": "Adaptability is a simple secret of survival in a rapidly changing world, so we must be observant of local and global changes.",
        "mm": "လျင်မြန်စွာ ပြောင်းလဲနေတဲ့ ကမ္ဘာကြီးမှာ ရှင်သန်ရပ်တည်ဖို့ လျှို့ဝှက်ချက်ကတော့ လိုက်လျောညီထွေ ပြောင်းလဲနိုင်စွမ်းဖြစ်လို့ ပြည်တွင်းနဲ့ ကမ္ဘာ့အပြောင်းအလဲတွေကို မျက်ခြည်မပြတ် လေ့လာနေရပါမယ်။"
      }
    ],
    "games": [
      {
        "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (Global Citizen Qualities)",
        "q": "'Adaptability' ဆိုတာ ဘယ်လိုအရည်အချင်းမျိုးလဲ?",
        "mode": "mcq",
        "options": [
          "တစ်ကိုယ်ကောင်းဆန်ခြင်း",
          "အခြေအနေသစ်နှင့် လိုက်လျောညီထွေ ပြောင်းလဲနိုင်စွမ်း",
          "စကားအလွန်များခြင်း",
          "အိပ်ချိန်များခြင်း"
        ],
        "ans": 1,
        "explain": "'Adaptability' ဆိုတာ ပြောင်းလဲလာတဲ့ ခေတ်ရေစီးကြောင်းနဲ့ အခြေအနေသစ်တွေအပေါ် အလိုက်သင့် ညှိယူနိုင်စွမ်း ဖြစ်ပါတယ်။"
      },
      {
        "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Superlative Adjectives)",
        "q": "'ဧရာဝတီမြစ်သည် မြန်မာနိုင်ငံတွင် အရှည်ဆုံးမြစ် ဖြစ်သည်' ကို စီပါ။",
        "mode": "scramble",
        "words": [
          "The",
          "Ayeyarwady",
          "is",
          "the",
          "longest",
          "river",
          "in",
          "Myanmar."
        ],
        "explain": "Superlative (အရှည်ဆုံး) ဖြစ်တဲ့ 'longest' ရဲ့ အရှေ့မှာ 'the' အမြဲထည့်ရပါတယ်။"
      },
      {
        "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Superlative Form)",
        "q": "Mt Hkakabo Razi is the _____ mountain in Southeast Asia.",
        "mode": "mcq",
        "options": [
          "high",
          "higher",
          "highest",
          "most high"
        ],
        "ans": 2,
        "explain": "တစ်လုံးတည်းအသံထွက် (One-syllable adjective) 'high' ရဲ့ အမြင့်ဆုံးအဆင့်က 'highest' ဖြစ်ပါတယ်။"
      },
      {
        "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Reading Check)",
        "q": "ကမ္ဘာ့ပတ်ဝန်းကျင်ထိန်းသိမ်းရေးနေ့ (World Environment Day) ကို နှစ်စဉ် ဇွန်လ ၅ ရက်နေ့မှာ ကျင်းပပါတယ်။",
        "mode": "mcq",
        "options": [
          "မှန်တယ် (True)",
          "မှားတယ် (False)"
        ],
        "ans": 0,
        "explain": "မှန်ပါတယ်! စာပိုဒ် (A) ထဲမှာ '5th June every year' လို့ ဖော်ပြထားပါတယ်။"
      }
    ]
  },
  {
    "title": "Unit 5: Basics of a Computer (ကွန်ပျူတာ အခြေခံနှင့် Microsoft Word)",
    "passage": [
      {
        "en": "All computers are composed of two basic parts: software and hardware.",
        "mm": "ကွန်ပျူတာအားလုံးကို အခြေခံအစိတ်အပိုင်း နှစ်မျိုးဖြစ်တဲ့ ဆော့ဖ်ဝဲ (Software) နဲ့ ဟာ့ဒ်ဝဲ (Hardware) တို့နဲ့ ဖွဲ့စည်းထားပါတယ်။"
      },
      {
        "en": "Software means a set of programmes used to operate a computer whereas hardware refers to electronic parts such as keyboard, mouse, speakers, and CPU.",
        "mm": "ဆော့ဖ်ဝဲဆိုတာ ကွန်ပျူတာကို မောင်းနှင်အသုံးပြုဖို့ ပရိုဂရမ်အစုအဝေးကို ဆိုလိုပြီး၊ ဟာ့ဒ်ဝဲကတော့ ကီးဘုတ်၊ မောက်စ်၊ စပီကာနဲ့ CPU တို့လို အီလက်ထရွန်နစ် အစိတ်အပိုင်းတွေကို ရည်ညွှန်းပါတယ်။"
      },
      {
        "en": "Microsoft Word is a popular word processing programme used mainly for creating, editing and formatting documents such as letters, tests, and projects.",
        "mm": "Microsoft Word ဆိုတာ စာစီစာရိုက် ပရိုဂရမ်တစ်ခုဖြစ်ပြီး ပေးစာတွေ၊ စာမေးပွဲမေးခွန်းတွေနဲ့ ပရောဂျက်စာတမ်းတွေ ဖန်တီးခြင်း၊ ပြင်ဆင်တည်းဖြတ်ခြင်းနဲ့ ပုံစံချခြင်းတွေအတွက် အဓိက အသုံးပြုပါတယ်။"
      },
      {
        "en": "After finishing word processing, click File Menu, select Save, type a file name, and click Save to store the document in the computer.",
        "mm": "စာရိုက်ပြီးတဲ့အခါ File Menu ကိုနှိပ်၊ Save ကိုရွေး၊ ဖိုင်နာမည်ရိုက်ထည့်ပြီး Save ခလုတ်ကို နှိပ်လိုက်ရင် စာရွက်စာတမ်းကို ကွန်ပျူတာထဲမှာ သိမ်းဆည်းပြီး ဖြစ်သွားပါတယ်။"
      }
    ],
    "games": [
      {
        "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (Computer Basics)",
        "q": "ကွန်ပျူတာရဲ့ 'ဦးနှောက် (Brain)' လို့ တင်စားခေါ်ဝေါ်တဲ့ အစိတ်အပိုင်းက ဘာလဲ?",
        "mode": "mcq",
        "options": [
          "Monitor",
          "Keyboard",
          "CPU",
          "Mouse"
        ],
        "ans": 2,
        "explain": "CPU (Central Processing Unit) ဟာ အချက်အလက်အားလုံးကို တွက်ချက်စီမံပေးတဲ့ ကွန်ပျူတာရဲ့ ဦးနှောက်ဖြစ်ပါတယ်။"
      },
      {
        "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Grammar: Imperatives)",
        "q": "'ဆေးကို တစ်နေ့ သုံးကြိမ် သောက်ပါ' ကို အမိန့်ပေး/ညွှန်ကြားဝါကျ စီပါ။",
        "mode": "scramble",
        "words": [
          "Take",
          "the",
          "medicine",
          "three",
          "times",
          "a",
          "day."
        ],
        "explain": "ညွှန်ကြားချက် (Imperative) ဝါကျတွေကို ကြိယာအရင်း (Take) နဲ့ တိုက်ရိုက်စတင်ရပါတယ်။"
      },
      {
        "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Negative Imperative)",
        "q": "_____ a socket with wet hands. It is very dangerous.",
        "mode": "mcq",
        "options": [
          "Touch",
          "Don't touch",
          "Touching",
          "Not touch"
        ],
        "ans": 1,
        "explain": "မလုပ်ဖို့ တားမြစ်တဲ့အခါ ကြိယာအရှေ့မှာ 'Don't' ထည့်ပြီး 'Don't touch' လို့ သုံးရပါတယ်။"
      },
      {
        "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Software vs Hardware)",
        "q": "Keyboard နဲ့ Mouse တို့ဟာ Computer Software များ ဖြစ်ကြပါတယ်။",
        "mode": "mcq",
        "options": [
          "မှန်တယ် (True)",
          "မှားတယ် (False)"
        ],
        "ans": 1,
        "explain": "မှားပါတယ်! ကိုင်တွယ်ထိတွေ့လို့ရတဲ့ Keyboard နဲ့ Mouse တို့ဟာ Hardware များ ဖြစ်ကြပါတယ်။"
      }
    ]
  },
  {
    "title": "Unit 6: Our Friendly Environment (ကျွန်ုပ်တို့၏ သဘာဝပတ်ဝန်းကျင်)",
    "passage": [
      {
        "en": "The earth's atmosphere provides us with oxygen and the sun gives us warmth, light and energy free of charge.",
        "mm": "ကမ္ဘာ့လေထုက ကျွန်ုပ်တို့ကို အောက်ဆီဂျင် ပေးစွမ်းပြီး နေမင်းကြီးက နွေးထွေးမှု၊ အလင်းရောင်နဲ့ စွမ်းအင်တွေကို အခမဲ့ ပေးစွမ်းပါတယ်။"
      },
      {
        "en": "However, our environment is now in great danger due to human activities such as cutting down trees, overfishing, and burning fossil fuels.",
        "mm": "သို့သော်လည်း သစ်ပင်ခုတ်ခြင်း၊ ငါးအလွန်အကျွံဖမ်းခြင်းနဲ့ ရုပ်ကြွင်းလောင်စာများ မီးရှို့ခြင်းစတဲ့ လူသားတွေရဲ့ လုပ်ရပ်တွေကြောင့် ပတ်ဝန်းကျင်ဟာ ကြီးမားတဲ့ အန္တရာယ်နဲ့ ရင်ဆိုင်နေရပါတယ်။"
      },
      {
        "en": "Many factories dispose of chemical wastes in rivers and seas, which causes water pollution and reduces clean drinking water.",
        "mm": "စက်ရုံအများအပြားဟာ ဓာတုစွန့်ပစ်ပစ္စည်းတွေကို မြစ်ချောင်းနဲ့ ပင်လယ်တွေထဲ စွန့်ပစ်ကြတာကြောင့် ရေထုညစ်ညမ်းမှု ဖြစ်ပေါ်ပြီး သန့်ရှင်းတဲ့ သောက်သုံးရေ လျော့နည်းလာပါတယ်။"
      },
      {
        "en": "To protect our planet Earth, we must practice the three R's of the environment: reduce, reuse and recycle.",
        "mm": "ကျွန်ုပ်တို့ရဲ့ ကမ္ဘာမြေကြီးကို ကာကွယ်ဖို့ ပတ်ဝန်းကျင်ထိန်းသိမ်းရေး R သုံးလုံးဖြစ်တဲ့ လျှော့ချခြင်း (Reduce)၊ ပြန်လည်အသုံးပြုခြင်း (Reuse) နဲ့ ပြန်လည်ပြုပြင်ထုတ်လုပ်ခြင်း (Recycle) တို့ကို ကျင့်သုံးရပါမယ်။"
      }
    ],
    "games": [
      {
        "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (The Three R's)",
        "q": "ပတ်ဝန်းကျင်ထိန်းသိမ်းရေး '3 R's' ထဲမှာ မပါဝင်တာ ဘယ်တစ်ခုလဲ?",
        "mode": "mcq",
        "options": [
          "Reduce (လျှော့ချခြင်း)",
          "Reuse (ပြန်လည်အသုံးပြုခြင်း)",
          "Recycle (ပြန်လည်ပြုပြင်ထုတ်လုပ်ခြင်း)",
          "Remove (ဖယ်ရှားပစ်ခြင်း)"
        ],
        "ans": 3,
        "explain": "3 R's ဆိုတာ Reduce, Reuse, Recycle တို့ ဖြစ်ပါတယ်။"
      },
      {
        "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Obligation: Must / Mustn't)",
        "q": "'ကျွန်ုပ်တို့သည် ပလတ်စတစ်ပုလင်းများကို ပြန်လည်အသုံးပြုရမည်' ကို စီပါ။",
        "mode": "scramble",
        "words": [
          "We",
          "must",
          "recycle",
          "paper",
          "and",
          "plastic",
          "bottles."
        ],
        "explain": "'must' နောက်မှာ ကြိယာအရင်း (recycle) ကို တိုက်ရိုက်ထားရပါတယ်။"
      },
      {
        "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Prohibition: Mustn't)",
        "q": "You _____ throw away the rubbish carelessly into streams.",
        "mode": "mcq",
        "options": [
          "must",
          "mustn't",
          "have to",
          "don't have to"
        ],
        "ans": 1,
        "explain": "လုံးဝ မလုပ်ရဘူးလို့ တားမြစ်တဲ့အခါ 'mustn't' (must not) ကို သုံးရပါတယ်။"
      },
      {
        "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Reading Check)",
        "q": "ဓာတုမြေဩဇာ (Chemical fertilizers) တွေ အလွန်အကျွံသုံးခြင်းက မြေဆီလွှာအရည်အသွေးကို ပျက်စီးစေပါတယ်။",
        "mode": "mcq",
        "options": [
          "မှန်တယ် (True)",
          "မှားတယ် (False)"
        ],
        "ans": 0,
        "explain": "မှန်ပါတယ်! စာပိုဒ်ထဲမှာ 'The quality of soil is being degraded because people are using chemical fertilizers' လို့ ပါရှိပါတယ်။"
      }
    ]
  },
  {
    "title": "Unit 7: Are you planning a holiday? (အားလပ်ရက် ခရီးစဉ်များ)",
    "passage": [
      {
        "en": "If you are an adventurous person, an adventure holiday will bring you to the green hills for a trek where you can rent a bike and ride up the hills.",
        "mm": "သင်ဟာ စွန့်စားရတာကို နှစ်သက်သူဖြစ်ရင် စွန့်စားခရီးစဉ်က စိမ်းလန်းတဲ့ တောင်တန်းတွေဆီ ခေါ်ဆောင်သွားမှာဖြစ်ပြီး စက်ဘီးငှားပြီး တောင်ပေါ်တက်စီးနိုင်ပါတယ်။"
      },
      {
        "en": "During a beach holiday, you can enjoy making sandcastles, sunbathing, listening to sea waves, and joining a bonfire party at night.",
        "mm": "ကမ်းခြေအပန်းဖြေခရီးမှာတော့ သဲရဲတိုက်ဆောက်တာ၊ နေပူဆာလှုံတာ၊ ပင်လယ်လှိုင်းသံနားထောင်တာနဲ့ ညဘက် မီးပုံပွဲဆင်နွှဲတာတွေ လုပ်ဆောင်နိုင်ပါတယ်။"
      },
      {
        "en": "On a cruise holiday, you can visit four unspoiled beaches in a day and do watersports such as canoeing, scuba diving and snorkelling.",
        "mm": "အပျော်စီးသင်္ဘောခရီးစဉ်မှာတော့ တစ်ရက်တည်းနဲ့ သဘာဝအတိုင်း မပျက်စီးသေးတဲ့ ကမ်းခြေ ၄ ခုကို လည်ပတ်နိုင်ပြီး လှေလှော်တာနဲ့ ရေငုပ်တာလို ရေပေါ်အားကစားတွေ လုပ်နိုင်ပါတယ်။"
      },
      {
        "en": "For a camping holiday, you will wake up with the tweets of birds in the morning and cook over a campfire at the campsite.",
        "mm": "စခန်းချခရီးစဉ်မှာတော့ မနက်ခင်းမှာ ငှက်ကလေးတွေရဲ့ တေးဆိုသံနဲ့အတူ နိုးထလာမှာဖြစ်ပြီး စခန်းချရာနေရာမှာ မီးပုံဖိုပြီး ချက်ပြုတ်စားသောက်နိုင်ပါတယ်။"
      }
    ],
    "games": [
      {
        "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (Phone Call Phrasal Verbs)",
        "q": "ဖုန်းပြောနေရင်း တစ်ဖက်လူကို 'ခဏစောင့်ပါဦး' လို့ ပြောချင်ရင် ဘယ်စကားလုံး သုံးမလဲ?",
        "mode": "mcq",
        "options": [
          "hang up",
          "hold on",
          "call back",
          "pick up"
        ],
        "ans": 1,
        "explain": "'hold on' ဆိုတာ ဖုန်းမချဘဲ ခဏစောင့်ပေးဖို့ ပြောတာပါ။ ('hang up' က ဖုန်းချလိုက်တာ ဖြစ်ပါတယ်)။"
      },
      {
        "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Grammar: Be going to)",
        "q": "'ကျွန်ုပ်သည် ပုဂံသို့ အပျော်စီးသင်္ဘောဖြင့် သွားမည်' ကို စာကြောင်းစီပါ။",
        "mode": "scramble",
        "words": [
          "I",
          "am",
          "going",
          "to",
          "take",
          "a",
          "cruise",
          "to",
          "Bagan."
        ],
        "explain": "ကြိုတင်ဆုံးဖြတ်ထားပြီးသား အစီအစဉ်တွေအတွက် 'am/is/are going to + V-infinitive' ကို သုံးရပါတယ်။"
      },
      {
        "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Will vs Be going to)",
        "q": "The phone is ringing. — I _____ answer it.",
        "mode": "mcq",
        "options": [
          "will",
          "am going to",
          "going to",
          "won't"
        ],
        "ans": 0,
        "explain": "စကားပြောနေတဲ့ အခိုက်အတန့်မှာ ရုတ်တရက် ဆုံးဖြတ်လိုက်တဲ့ ကိစ္စတွေအတွက် 'will' ကို သုံးရပါတယ်။"
      },
      {
        "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Reading Check)",
        "q": "စခန်းချခရီး (Camping holiday) သွားရင် ကိုယ်ပိုင်ရွက်ဖျင်တဲ မပါလည်း စခန်းမှာ ဈေးနှုန်းသက်သာစွာ ငှားရမ်းနိုင်ပါတယ်။",
        "mode": "mcq",
        "options": [
          "မှန်တယ် (True)",
          "မှားတယ် (False)"
        ],
        "ans": 0,
        "explain": "မှန်ပါတယ်! 'we have tents and sleeping bags to hire at the most reasonable prices' လို့ ဖော်ပြထားပါတယ်။"
      }
    ]
  },
  {
    "title": "Unit 8: Heaven or Paradise? (အပန်းဖြေစခန်းများ)",
    "passage": [
      {
        "en": "Located on an island in the coastal region of Myanmar, Heaven Resort is a wonderful place with five-star facilities like free Wi-Fi, a fitness centre, and a swimming pool.",
        "mm": "မြန်မာနိုင်ငံ ကမ်းရိုးတန်းဒေသရှိ ကျွန်းတစ်ကျွန်းပေါ်မှာ တည်ရှိတဲ့ Heaven Resort ဟာ အခမဲ့ Wi-Fi၊ အားကစားခန်းမနဲ့ ရေကူးကန်တို့လို ကြယ်ငါးပွင့်အဆင့် ဝန်ဆောင်မှုတွေ ပြည့်စုံတဲ့ နေရာကောင်းတစ်ခု ဖြစ်ပါတယ်။"
      },
      {
        "en": "Visitors at Heaven Resort can enjoy fresh seafood, evening music performances, and water activities like diving, snorkelling and sailing.",
        "mm": "Heaven Resort ကို လာရောက်သူတွေဟာ လတ်ဆတ်တဲ့ ပင်လယ်စာ၊ ညနေခင်း ဂီတဖျော်ဖြေပွဲတွေနဲ့ ရေငုပ်ခြင်း၊ ရွက်လွှင့်ခြင်းစတဲ့ ရေပေါ်ကစားနည်းတွေကို ပျော်ရွှင်စွာ ဆင်နွှဲနိုင်ပါတယ်။"
      },
      {
        "en": "Paradise Resort is an eco-resort in northern Myanmar that offers a unique experience of living in a tree house or a bungalow.",
        "mm": "Paradise Resort ကတော့ မြန်မာနိုင်ငံမြောက်ပိုင်းမှာရှိတဲ့ သဘာဝပတ်ဝန်းကျင်ထိန်းသိမ်းရေး အပန်းဖြေစခန်းဖြစ်ပြီး သစ်ပင်ပေါ်က အိမ်လေးတွေ ဒါမှမဟုတ် ဘန်ဂလိုတွေမှာ နေထိုင်ရတဲ့ ထူးခြားတဲ့ အတွေ့အကြုံကို ပေးစွမ်းပါတယ်။"
      },
      {
        "en": "Surrounded by natural springs and waterfalls, Paradise Resort has an organic farm where guests can pluck fresh vegetables and cook in a kitchenette.",
        "mm": "သဘာဝစမ်းချောင်းတွေ၊ ရေတံခွန်တွေ ဝန်းရံထားတဲ့ Paradise Resort မှာ သဘာဝစိုက်ခင်းရှိတာကြောင့် ဧည့်သည်တွေဟာ လတ်ဆတ်တဲ့ ဟင်းသီးဟင်းရွက်တွေ ကိုယ်တိုင်ခူးဆွတ်ပြီး မီးဖိုချောင်ငယ်လေးထဲမှာ ချက်ပြုတ်နိုင်ပါတယ်။"
      }
    ],
    "games": [
      {
        "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (Resort Vocabulary)",
        "q": "ကိုယ်တိုင် ဟင်းချက်စားလို့ရတဲ့ မီးဖိုချောင်ငယ်လေးကို အင်္ဂလိပ်လို ဘယ်လိုခေါ်လဲ?",
        "mode": "mcq",
        "options": [
          "patio",
          "bungalow",
          "kitchenette",
          "minibar"
        ],
        "ans": 2,
        "explain": "'kitchenette' ဆိုတာ အခန်းတွင်းမှာ ပါဝင်တဲ့ မီးဖိုချောင်ငယ်လေးကို ခေါ်တာပါ။"
      },
      {
        "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Grammar: Comparatives)",
        "q": "'ချင်းတွင်းမြစ်သည် ဧရာဝတီမြစ်ထက် ပိုတိုသည်' (သို့) 'ဧရာဝတီမြစ်က ပိုရှည်သည်' ကို စီပါ။",
        "mode": "scramble",
        "words": [
          "The",
          "Ayeyarwady",
          "River",
          "is",
          "longer",
          "than",
          "the",
          "Chindwin."
        ],
        "explain": "နှစ်ခုကို နှိုင်းယှဉ်တဲ့ Comparative မှာ 'adjective-er + than' ပုံစံ သုံးရပါတယ်။"
      },
      {
        "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Comparative Adjectives)",
        "q": "Living in Yangon is _____ than living in Mandalay.",
        "mode": "mcq",
        "options": [
          "costly",
          "more costly",
          "most costly",
          "costliest"
        ],
        "ans": 1,
        "explain": "နှိုင်းယှဉ်ပြောဆိုတဲ့အခါ 'more costly than' လို့ သုံးရပါတယ်။"
      },
      {
        "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Reading Check)",
        "q": "သစ်ပင်ပေါ်က အိမ် (Tree house) မှာ နေထိုင်နိုင်တာက Heaven Resort မှာ ဖြစ်ပါတယ်။",
        "mode": "mcq",
        "options": [
          "မှန်တယ် (True)",
          "မှားတယ် (False)"
        ],
        "ans": 1,
        "explain": "မှားပါတယ်! Tree house ရှိတာက မြန်မာနိုင်ငံမြောက်ပိုင်းက Paradise Resort မှာ ဖြစ်ပါတယ်။"
      }
    ]
  },
  {
    "title": "Unit 9: Beautiful Myanmar (လှပသော မြန်မာပြည်)",
    "passage": [
      {
        "en": "Snow-capped mountains stand majestically in Kachin State, where Mt Hkakabo Razi stands gloriously at 5,881 metres as the highest mountain in Southeast Asia.",
        "mm": "ဆီးနှင်းဖုံးလွှမ်းနေတဲ့ တောင်တန်းတွေဟာ ကချင်ပြည်နယ်မှာ ခမ်းနားထည်ဝါစွာ တည်ရှိနေပြီး အမြင့် ၅,၈၈၁ မီတာရှိတဲ့ ခါကာဘိုရာဇီတောင်ဟာ အရှေ့တောင်အာရှရဲ့ အမြင့်ဆုံးတောင် ဖြစ်ပါတယ်။"
      },
      {
        "en": "Sadan Cave, located near Hpa-an in Kayin State, is an enormous cave with Buddha images, wall carvings, and a small river outside for boat trips.",
        "mm": "ကရင်ပြည်နယ် ဘားအံမြို့အနီးမှာရှိတဲ့ ဆဒ္ဒန်ဂူဟာ ဗုဒ္ဓရုပ်ပွားတော်တွေ၊ နံရံပန်းပုလက်ရာတွေနဲ့ ဂူအပြင်ဘက်မှာ လှေစီးလည်ပတ်နိုင်တဲ့ ချောင်းငယ်လေးရှိတဲ့ ဂူကြီးတစ်ဂူ ဖြစ်ပါတယ်။"
      },
      {
        "en": "Ngapali Beach in Rakhine State is well-known for its soft creamy sand, unspoiled water, green palm trees, and exciting water sports.",
        "mm": "ရခိုင်ပြည်နယ်က ငပလီကမ်းခြေဟာ နူးညံ့ဖြူဖွေးတဲ့ သဲသောင်ပြင်၊ ကြည်လင်သန့်ရှင်းတဲ့ ပင်လယ်ရေ၊ စိမ်းလန်းတဲ့ အုန်းပင်တွေနဲ့ ရေပေါ်အားကစားတွေကြောင့် နာမည်ကျော်ကြားပါတယ်။"
      },
      {
        "en": "The Ayeyarwady River, stretching 2,210 kilometres from Kachin State to the Andaman Sea, is the backbone and lifeblood of the Myanmar people.",
        "mm": "ကချင်ပြည်နယ်ကနေ ကပ္ပလီပင်လယ်အထိ ၂,၂၁၀ ကီလိုမီတာ ရှည်လျားတဲ့ ဧရာဝတီမြစ်ကြီးဟာ မြန်မာပြည်သူတွေရဲ့ ကျောရိုးမကြီးနဲ့ အသက်သွေးကြော ဖြစ်ပါတယ်။"
      }
    ],
    "games": [
      {
        "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (Myanmar Geography)",
        "q": "မြန်မာနိုင်ငံမှာ အကြီးဆုံး အင်းကြီး (Largest lake) က ဘယ်အင်းလဲ?",
        "mode": "mcq",
        "options": [
          "အင်းလေးကန် (Inlay)",
          "အင်းတော်ကြီးအင်း (Indawgyi)",
          "အင်းယားကန် (Inya)",
          "ကန်တော်ကြီး (Kandawgyi)"
        ],
        "ans": 1,
        "explain": "ကချင်ပြည်နယ်မှာရှိတဲ့ အင်းတော်ကြီးအင်း (Indawgyi Lake) ဟာ မြန်မာနိုင်ငံရဲ့ အကြီးဆုံးအင်း ဖြစ်ပါတယ်။"
      },
      {
        "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Grammar: Prepositions)",
        "q": "'ဥယျာဉ်သည် မနက် ၈ နာရီမှ ညနေ ၄ နာရီအထိ ဖွင့်သည်' ကို စာကြောင်းစီပါ။",
        "mode": "scramble",
        "words": [
          "The",
          "park",
          "is",
          "open",
          "from",
          "8 a.m.",
          "to",
          "4 p.m."
        ],
        "explain": "အချိန်အစနဲ့ အဆုံးကို ဖော်ပြတဲ့အခါ 'from ... to ...' ကို သုံးရပါတယ်။"
      },
      {
        "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Prepositions of Time)",
        "q": "World Teachers' Day is annually held _____ 5th October.",
        "mode": "mcq",
        "options": [
          "in",
          "at",
          "on",
          "from"
        ],
        "ans": 2,
        "explain": "ရက်စွဲအတိအကျ (Dates) တွေရဲ့ အရှေ့မှာ အမြဲတမ်း 'on' ကို သုံးရပါတယ်။"
      },
      {
        "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Reading Check)",
        "q": "ဧရာဝတီမြစ်ဟာ မေခ (N'Mai Hka) နဲ့ မလိခ (Mali Hka) မြစ်နှစ်သွယ် ပေါင်းဆုံရာကနေ မြစ်ဖျားခံပါတယ်။",
        "mode": "mcq",
        "options": [
          "မှန်တယ် (True)",
          "မှားတယ် (False)"
        ],
        "ans": 0,
        "explain": "မှန်ပါတယ်! 'Born of the confluence of the N'Mai Hka and Mali Hka rivers' လို့ ဖော်ပြထားပါတယ်။"
      }
    ]
  },
  {
    "title": "Unit 10: More Time to Relax (အားလပ်ချိန်နှင့် ဝါသနာများ)",
    "passage": [
      {
        "en": "Most teenagers today are worried about homework, exams and marks, so they have less time for leisure activities.",
        "mm": "ယနေ့ခေတ် ဆယ်ကျော်သက်အများစုဟာ အိမ်စာ၊ စာမေးပွဲနဲ့ အမှတ်တွေအတွက် စိုးရိမ်ပူပန်နေရတာကြောင့် အားလပ်ချိန် ဝါသနာလှုပ်ရှားမှုတွေ လုပ်ဖို့ အချိန်နည်းပါးကြပါတယ်။"
      },
      {
        "en": "Free time is essential for our mental and physical well-being because a break from study can refresh our mind and body.",
        "mm": "အားလပ်ချိန်ဟာ စိတ်ပိုင်းဆိုင်ရာနဲ့ ရုပ်ပိုင်းဆိုင်ရာ ကျန်းမာပျော်ရွှင်မှုအတွက် မရှိမဖြစ် လိုအပ်ပါတယ်၊ ဘာလို့လဲဆိုတော့ စာလုပ်ရာကနေ ခဏနားလိုက်ခြင်းက စိတ်နဲ့ခန္ဓာကို လန်းဆန်းစေလို့ပါပဲ။"
      },
      {
        "en": "When teenagers cook a meal or paint a picture, they feel proud, confident, and gain great satisfaction from their hobbies.",
        "mm": "လူငယ်လေးတွေဟာ ဟင်းတစ်ခွက်ချက်လိုက်နိုင်တဲ့အခါ ဒါမှမဟုတ် ပန်းချီတစ်ချပ်ဆွဲလိုက်နိုင်တဲ့အခါ ဂုဏ်ယူစိတ်၊ ယုံကြည်မှုနဲ့ စိတ်ကျေနပ်မှု အပြည့်အဝ ရရှိကြပါတယ်။"
      },
      {
        "en": "Hobbies also help students concentrate better on their studies and make new friends easily.",
        "mm": "ဝါသနာပါရာ လုပ်ဆောင်ခြင်းက ကျောင်းသူတွေကို စာထဲမှာ ပိုပြီးအာရုံစူးစိုက်နိုင်အောင် ကူညီပေးသလို သူငယ်ချင်းအသစ်တွေလည်း အလွယ်တကူ ရရှိစေပါတယ်။"
      }
    ],
    "games": [
      {
        "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (Do / Go / Play)",
        "q": "'aerobics, judo, karate, yoga' စတဲ့ ကိုယ်လက်လှုပ်ရှားမှုတွေနဲ့ တွဲသုံးရမယ့် ကြိယာက ဘာလဲ?",
        "mode": "mcq",
        "options": [
          "play",
          "go",
          "do",
          "make"
        ],
        "ans": 2,
        "explain": "ဘောလုံးမပါတဲ့ ကိုယ်ခံပညာနဲ့ လေ့ကျင့်ခန်းတွေ (do karate, do yoga, do aerobics) အတွက် 'do' ကို သုံးပါတယ်။"
      },
      {
        "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Gerund vs To-infinitive)",
        "q": "'သူမသည် ကျန်းမာရေးနှင့်ညီညွတ်သော အစားအစာစားရန် ဆုံးဖြတ်ခဲ့သည်' ကို စီပါ။",
        "mode": "scramble",
        "words": [
          "She",
          "decided",
          "to",
          "eat",
          "healthy",
          "food."
        ],
        "explain": "'decide' ကြိယာနောက်မှာ အမြဲတမ်း 'to + V-infinitive' (to eat) လိုက်ရပါတယ်။"
      },
      {
        "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Verb + Gerund)",
        "q": "We must avoid _____ too much junk food like potato chips.",
        "mode": "mcq",
        "options": [
          "eat",
          "to eat",
          "eating",
          "ate"
        ],
        "ans": 2,
        "explain": "'avoid' (ရှောင်ကြဉ်သည်) နောက်မှာ အမြဲတမ်း Verb-ing (Gerund) ဖြစ်တဲ့ 'eating' ကို သုံးရပါတယ်။"
      },
      {
        "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Reading Check)",
        "q": "အားလပ်ချိန်မှာ ဝါသနာပါရာ လုပ်ဆောင်ခြင်းက စာသင်ကြားမှုမှာ အာရုံစူးစိုက်မှုကို လျော့ကျစေပါတယ်။",
        "mode": "mcq",
        "options": [
          "မှန်တယ် (True)",
          "မှားတယ် (False)"
        ],
        "ans": 1,
        "explain": "မှားပါတယ်! ဝါသနာပါရာ လုပ်ဆောင်ခြင်းက စိတ်ကိုလန်းဆန်းစေပြီး စာထဲမှာ ပိုပြီး အာရုံစူးစိုက်နိုင်စေပါတယ်။"
      }
    ]
  },
  {
    "title": "Unit 11: Digital Devices & Mobile Phones (ဒစ်ဂျစ်တယ်ပစ္စည်းများ)",
    "passage": [
      {
        "en": "Digital devices such as smartphones, tablets, and laptops have become an essential part of our daily lives.",
        "mm": "စမတ်ဖုန်း၊ တက်ဘလက်နဲ့ လက်တော့ပ်ကွန်ပျူတာတွေလို ဒစ်ဂျစ်တယ်ပစ္စည်းတွေဟာ ကျွန်ုပ်တို့ နေ့စဉ်ဘဝရဲ့ မရှိမဖြစ် အစိတ်အပိုင်း ဖြစ်လာပါပြီ။"
      },
      {
        "en": "Mobile phones help us communicate easily with friends and family, search for study materials online, and enjoy entertainment.",
        "mm": "မိုဘိုင်းဖုန်းတွေက သူငယ်ချင်းတွေ၊ မိသားစုတွေနဲ့ အလွယ်တကူ ဆက်သွယ်နိုင်ဖို့၊ အွန်လိုင်းကနေ သင်ခန်းစာအထောက်အကူပြုတွေ ရှာဖွေဖို့နဲ့ ဖျော်ဖြေရေးအတွက် ကူညီပေးပါတယ်။"
      },
      {
        "en": "However, if students spend too much time playing online games or using social media, they may neglect their studies.",
        "mm": "သို့သော်လည်း ကျောင်းသူတွေဟာ အွန်လိုင်းဂိမ်းဆော့တာ ဒါမှမဟုတ် ဆိုရှယ်မီဒီယာသုံးတာကို အချိန်အလွန်အကျွံ ပေးမိရင် စာကျက်ဖို့ လစ်ဟင်းသွားနိုင်ပါတယ်။"
      },
      {
        "en": "If you look at a phone screen for many hours without a break, it will harm your eyesight and disturb your sleep.",
        "mm": "အနားမယူဘဲ ဖုန်းမျက်နှာပြင်ကို နာရီပေါင်းများစွာ ကြည့်နေမယ်ဆိုရင် မျက်စိအမြင်အာရုံကို ထိခိုက်စေပြီး အိပ်စက်ခြင်းကိုလည်း အနှောင့်အယှက် ဖြစ်စေပါလိမ့်မယ်။"
      }
    ],
    "games": [
      {
        "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (Digital Vocabulary)",
        "q": "အလွယ်တကူ သယ်ဆောင်သွားလို့ရတဲ့ စက်ပစ္စည်းကို ဘယ်လိုခေါ်လဲ?",
        "mode": "mcq",
        "options": [
          "desktop",
          "portable",
          "heavy",
          "broken"
        ],
        "ans": 1,
        "explain": "'portable' ဆိုတာ နေရာတကာ အလွယ်တကူ သယ်ဆောင်သွားလို့ရတာကို ပြောတာပါ။"
      },
      {
        "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (First Conditional)",
        "q": "'မင်း ကြိုးစားရင် စာမေးပွဲ အောင်လိမ့်မယ်' ကို စာကြောင်းစီပါ။",
        "mode": "scramble",
        "words": [
          "If",
          "you",
          "study",
          "hard,",
          "you",
          "will",
          "pass",
          "the",
          "exam."
        ],
        "explain": "First Conditional မှာ 'If + Present Simple, ... will + V-infinitive' ပုံစံ သုံးရပါတယ်။"
      },
      {
        "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Zero & First Conditional)",
        "q": "If you heat ice, it _____ into water.",
        "mode": "mcq",
        "options": [
          "will melt",
          "melts",
          "melted",
          "melting"
        ],
        "ans": 1,
        "explain": "သိပ္ပံနည်းကျ အမှန်တရား (Zero Conditional) ဖြစ်လို့ နှစ်ဖက်စလုံးမှာ Present Simple (melts) ကို သုံးရပါတယ်။"
      },
      {
        "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Reading Check)",
        "q": "ဖုန်းကို အချိန်အကြာကြီး မနားတမ်းကြည့်ခြင်းက မျက်စိအမြင်အာရုံကို ထိခိုက်စေနိုင်ပါတယ်။",
        "mode": "mcq",
        "options": [
          "မှန်တယ် (True)",
          "မှားတယ် (False)"
        ],
        "ans": 0,
        "explain": "မှန်ပါတယ်! ဖုန်းအလွန်အကျွံသုံးခြင်းက မျက်စိထိခိုက်စေပြီး အိပ်ရေးပျက်စေပါတယ်။"
      }
    ]
  },
  {
    "title": "Unit 12: Breaking News & Local Events (သတင်းနှင့် အဖြစ်အပျက်များ)",
    "passage": [
      {
        "en": "Every day, people read newspapers, watch television, or check online news to learn what is happening locally and around the world.",
        "mm": "နေ့စဉ်နေ့တိုင်း လူတွေဟာ ပြည်တွင်းနဲ့ ကမ္ဘာတစ်ဝန်းမှာ ဘာတွေဖြစ်ပျက်နေလဲဆိုတာ သိရှိဖို့ သတင်းစာဖတ်ခြင်း၊ တီဗွီကြည့်ခြင်း ဒါမှမဟုတ် အွန်လိုင်းသတင်းကြည့်ခြင်းတွေ ပြုလုပ်ကြပါတယ်။"
      },
      {
        "en": "Yesterday afternoon, heavy rain caused a sudden flood in a small town, and local rescue teams quickly helped villagers move to safe places.",
        "mm": "မနေ့က မွန်းလွဲပိုင်းမှာ မိုးသည်းထန်စွာ ရွာသွန်းမှုကြောင့် မြို့ငယ်လေးတစ်မြို့မှာ ရုတ်တရက် ရေကြီးမှုဖြစ်ပွားခဲ့ပြီး ဒေသခံကယ်ဆယ်ရေးအဖွဲ့တွေက ရွာသားတွေကို ဘေးကင်းရာဆီ အမြန်ကူညီရွှေ့ပြောင်းပေးခဲ့ပါတယ်။"
      },
      {
        "en": "While the rescue workers were helping the elderly people, young volunteers brought clean drinking water and food packages.",
        "mm": "ကယ်ဆယ်ရေးဝန်ထမ်းတွေက သက်ကြီးရွယ်အိုတွေကို ကူညီနေစဉ်မှာ လူငယ်စေတနာ့ဝန်ထမ်းတွေက သန့်ရှင်းတဲ့ သောက်ရေနဲ့ စားနပ်ရိက္ခာထုပ်တွေ သယ်ဆောင်လာပေးခဲ့ကြပါတယ်။"
      },
      {
        "en": "Fortunately, nobody was injured in the incident, and the community praised the teamwork of the local heroes.",
        "mm": "ကံကောင်းထောက်မစွာပဲ ဒီဖြစ်ရပ်မှာ ဘယ်သူမှ ထိခိုက်ဒဏ်ရာ မရရှိခဲ့ဘဲ ရပ်ရွာလူထုက ဒေသခံသူရဲကောင်းတွေရဲ့ စုပေါင်းလုပ်ဆောင်မှုကို ချီးကျူးဂုဏ်ပြုခဲ့ကြပါတယ်။"
      }
    ],
    "games": [
      {
        "type": "⚡ စကားလုံး အမြန်ဖမ်းဂိမ်း (News Vocabulary)",
        "q": "အရေးကြီးပြီး လတ်တလော ဖြစ်ပွားနေတဲ့ သတင်းထူးကို ဘယ်လိုခေါ်လဲ?",
        "mode": "mcq",
        "options": [
          "old story",
          "breaking news",
          "fairy tale",
          "advertisement"
        ],
        "ans": 1,
        "explain": "'breaking news' ဆိုတာ အခုပဲ ဖြစ်ပွားနေတဲ့ နောက်ဆုံးရ အရေးကြီးသတင်းကို ခေါ်တာပါ။"
      },
      {
        "type": "🧩 စာကြောင်းတည်ဆောက်ဂိမ်း (Past Simple & Continuous)",
        "q": "'မိုးရွာနေစဉ် ကျွန်ုပ် အိမ်စာလုပ်နေခဲ့သည်' ကို စာကြောင်းစီပါ။",
        "mode": "scramble",
        "words": [
          "I",
          "was",
          "doing",
          "my",
          "homework",
          "while",
          "it",
          "was",
          "raining."
        ],
        "explain": "အတိတ်မှာ တစ်ပြိုင်နက်တည်း ဖြစ်ပျက်နေတဲ့ အရာနှစ်ခုအတွက် Past Continuous (was/were + V-ing) ကို သုံးပါတယ်။"
      },
      {
        "type": "🎯 ကွက်လပ်ဖြည့် စိန်ခေါ်မှု (Present Perfect vs Past Simple)",
        "q": "The rescue team _____ already moved all the villagers to the monastery.",
        "mode": "mcq",
        "options": [
          "have",
          "has",
          "was",
          "did"
        ],
        "ans": 1,
        "explain": "'The rescue team' ဟာ အနည်းကိန်းအစုအဖွဲ့ (Singular) ဖြစ်ပြီး 'already' ပါတဲ့အတွက် Present Perfect 'has' ကို သုံးရပါတယ်။"
      },
      {
        "type": "⏱️ မှန် / မှား မြန်မြန်ရွေး (Reading Check)",
        "q": "မနေ့က ရေကြီးမှုဖြစ်စဉ်မှာ ရွာသားအများအပြား ပြင်းထန်စွာ ဒဏ်ရာရရှိခဲ့ကြပါတယ်။",
        "mode": "mcq",
        "options": [
          "မှန်တယ် (True)",
          "မှားတယ် (False)"
        ],
        "ans": 1,
        "explain": "မှားပါတယ်! 'Fortunately, nobody was injured in the incident' (ဘယ်သူမှ ဒဏ်ရာမရခဲ့ပါ) လို့ ဖော်ပြထားပါတယ်။"
      }
    ]
  }
];

const poemsData = [
  {
    "title": "Poem 1: On the Vowels (သရအက္ခရာများအကြောင်း)",
    "poet": "Jonathan Swift",
    "lines": [
      {
        "en": "We are little airy creatures,",
        "mm": "ကျွန်ုပ်တို့သည် လေကဲ့သို့ ပေါ့ပါးသော အရာငယ်လေးများ ဖြစ်ကြပြီး၊"
      },
      {
        "en": "All of different voice and features;",
        "mm": "အားလုံးမှာ မတူညီသော အသံနှင့် ပုံသဏ္ဌာန်လက္ခဏာ ကိုယ်စီရှိကြသည်၊"
      },
      {
        "en": "One of us in glass is set,",
        "mm": "ကျွန်ုပ်တို့ထဲမှ တစ်ဦးကို 'glass' (a) တွင် ထည့်သွင်းထားပြီး၊"
      },
      {
        "en": "One of us you'll find in jet;",
        "mm": "နောက်တစ်ဦးကိုမူ 'jet' (e) တွင် သင်တွေ့ရလိမ့်မည်၊"
      },
      {
        "en": "T'other you may see in tin,",
        "mm": "အခြားတစ်ဦးကို 'tin' (i) တွင် မြင်တွေ့နိုင်ပြီး၊"
      },
      {
        "en": "And the fourth a box within.",
        "mm": "စတုတ္ထတစ်ဦးမှာ 'box' (o) အထဲတွင် ရှိနေသည်၊"
      },
      {
        "en": "If the fifth you should pursue,",
        "mm": "အကယ်၍ ပဉ္စမမြောက်တစ်ဦးကို သင်လိုက်လံရှာဖွေမည်ဆိုပါက၊"
      },
      {
        "en": "It can never fly from you.",
        "mm": "ထိုအရာသည် သင့် ('you' - u) ထံမှ မည်သည့်အခါမျှ ပျံပြေးနိုင်မည် မဟုတ်ပေ။"
      }
    ],
    "note": "💡 ရှင်းလင်းချက်: ဤကဗျာသည် အင်္ဂလိပ်သရ (Vowels) ၅ လုံးဖြစ်သော a, e, i, o, u တို့ကို glass (a), jet (e), tin (i), box (o), you (u) ဟူသော စကားလုံးများဖြင့် ပဟေဠိဆန်ဆန် ဖွဲ့ဆိုထားခြင်း ဖြစ်ပါသည်။"
  },
  {
    "title": "Poem 2: How Beautiful is the Rain! (မိုးရေသည် မည်မျှလှပသနည်း)",
    "poet": "Henry Wadsworth Longfellow",
    "lines": [
      {
        "en": "How beautiful is the rain!",
        "mm": "မိုးရေသည် မည်မျှ လှပလိုက်ပါသနည်း!"
      },
      {
        "en": "After the dust and heat,",
        "mm": "ဖုန်မှုန့်များနှင့် ပူပြင်းခြောက်သွေ့မှုများ ပြီးနောက်၊"
      },
      {
        "en": "In the broad and fiery street,",
        "mm": "ကျယ်ပြန့်ပြီး မီးတောက်မတတ် ပူပြင်းသော လမ်းမကြီးပေါ်တွင်လည်းကောင်း၊"
      },
      {
        "en": "In the narrow lane,",
        "mm": "ကျဉ်းမြောင်းသော လမ်းကြားလေးထဲတွင်လည်းကောင်း၊"
      },
      {
        "en": "How beautiful is the rain!",
        "mm": "မိုးရေသည် မည်မျှ လှပလိုက်ပါသနည်း!"
      },
      {
        "en": "How it clatters along the roofs,",
        "mm": "အိမ်ခေါင်မိုးများပေါ်သို့ တဖြောက်ဖြောက် မြည်ဟည်းကျဆင်းပုံမှာ၊"
      },
      {
        "en": "Like the tramp of hoofs!",
        "mm": "မြင်းခွာသံများ တဒုန်းဒုန်း နင်းလျှောက်နေသကဲ့သို့ပင်!"
      },
      {
        "en": "How it gushes and struggles out",
        "mm": "မိုးရေများသည် အရှိန်ပြင်းစွာ တိုးဝှေ့စီးဆင်းထွက်ကျလာပုံမှာ၊"
      },
      {
        "en": "From the throat of the overflowing spout!",
        "mm": "ရေလျှံကျနေသော ရေတံလျှောက်ပေါက်ဝမှ တဝေါဝေါ စီးကျနေသကဲ့သို့ပင်!"
      },
      {
        "en": "Across the window-pane It pours and pours;",
        "mm": "ပြတင်းပေါက်မှန်ချပ်ကို ဖြတ်ကျော်၍ မိုးရေများ တသွင်သွင် ရွာသွန်းနေသည်၊"
      },
      {
        "en": "And swift and wide, With a muddy tide,",
        "mm": "လျင်မြန်ကျယ်ပြန့်စွာ ရွှံ့ရေစီးကြောင်းများနှင့်အတူ၊"
      },
      {
        "en": "Like a river down the gutter roars",
        "mm": "လမ်းဘေးရေမြောင်းတစ်လျှောက် မြစ်တစ်စင်းပမာ ဟိန်းဟောက်စီးဆင်းနေသော၊"
      },
      {
        "en": "The rain, the welcome rain!",
        "mm": "မိုးရေ၊ လူတိုင်း ကြိုဆိုနှစ်သက်ကြသော မိုးရေပါတကား!"
      }
    ],
    "note": "💡 ရှင်းလင်းချက်: ပူပြင်းခြောက်သွေ့ပြီး ဖုန်ထူနေချိန်တွင် ရွာချလိုက်သော မိုးရေ၏ အသံနှင့် အလှတရားကို ကဗျာဆရာက ဝမ်းမြောက်ဝမ်းသာ ကြိုဆိုဖွဲ့ဆိုထားခြင်း ဖြစ်ပါသည်။"
  },
  {
    "title": "Poem 3: The Snare (ကျော့ကွင်းမိနေသော ယုန်ကလေး)",
    "poet": "James Stephens",
    "lines": [
      {
        "en": "I hear a sudden cry of pain!",
        "mm": "နာကျင်စွာ ရုတ်တရက် အော်ဟစ်လိုက်သံကို ကျွန်ုပ် ကြားလိုက်ရသည်!"
      },
      {
        "en": "There is a rabbit in a snare:",
        "mm": "ကျော့ကွင်းထဲတွင် ယုန်ကလေးတစ်ကောင် မိနေလေပြီ၊"
      },
      {
        "en": "Now I hear the cry again,",
        "mm": "ယခု အော်သံကို ကျွန်ုပ် ထပ်မံကြားရပြန်သည်၊"
      },
      {
        "en": "But I cannot tell from where.",
        "mm": "သို့သော် မည်သည့်နေရာမှ လာသည်ကို ကျွန်ုပ် မပြောနိုင်ပေ။"
      },
      {
        "en": "But I cannot tell from where He is calling out for aid!",
        "mm": "သူ အကူအညီတောင်းခံ အော်ဟစ်နေသည့် နေရာကို ကျွန်ုပ် ရှာမတွေ့နိုင်ဖြစ်နေသည်!"
      },
      {
        "en": "Crying on the frightened air, Making everything afraid!",
        "mm": "ထိတ်လန့်ဖွယ် လေထုထဲတွင် အော်ဟစ်နေခြင်းက ပတ်ဝန်းကျင်တစ်ခုလုံးကို ကြောက်ရွံ့စေသည်!"
      },
      {
        "en": "Making everything afraid! Wrinkling up his little face!",
        "mm": "ပတ်ဝန်းကျင်တစ်ခုလုံးကို ကြောက်ရွံ့စေရင်း သူ၏ မျက်နှာငယ်လေးမှာ နာကျင်မှုကြောင့် တွန့်ရှုံ့နေရှာသည်!"
      },
      {
        "en": "As he cries again for aid; - and I cannot find the place!",
        "mm": "သူ အကူအညီ ထပ်တောင်းနေသော်လည်း ထိုနေရာကို ကျွန်ုပ် ရှာမတွေ့နိုင်သေးပေ!"
      },
      {
        "en": "And I cannot find the place Where his paw is in the snare!",
        "mm": "သူ၏ ခြေဖဝါးလေး ကျော့ကွင်းမိနေသည့် နေရာကို ကျွန်ုပ် ရှာမတွေ့နိုင်ဖြစ်နေသည်!"
      },
      {
        "en": "Little One! Oh, Little One! I am searching everywhere!",
        "mm": "သတ္တဝါငယ်လေးရေ! အို... ယုန်ကလေးရေ! ကျွန်ုပ် နေရာအနှံ့ လိုက်လံရှာဖွေနေပါသည်!"
      }
    ],
    "note": "💡 ရှင်းလင်းချက်: ထောင်ချောက်မိ၍ နာကျင်စွာ အော်ဟစ်နေသော ယုန်ကလေးကို ကယ်တင်လိုသော်လည်း နေရာရှာမတွေ့ဖြစ်နေရသည့် ကဗျာဆရာ၏ ကရုဏာစိတ်ကို ဖော်ကျူးထားပါသည်။"
  },
  {
    "title": "Poem 4: The Moon (လမင်းကြီး)",
    "poet": "Robert Louis Stevenson",
    "lines": [
      {
        "en": "The moon has a face like the clock in the hall;",
        "mm": "လမင်းကြီးတွင် ဧည့်ခန်းဆောင်ထဲက နာရီကဲ့သို့ ဝိုင်းစက်သော မျက်နှာရှိသည်၊"
      },
      {
        "en": "She shines on thieves on the garden wall,",
        "mm": "သူမသည် ဥယျာဉ်တံတိုင်းပေါ်မှ သူခိုးများအပေါ်သို့ အလင်းရောင် ဖြာကျစေသည်၊"
      },
      {
        "en": "On streets and fields and harbour quays,",
        "mm": "လမ်းမများ၊ လယ်ကွင်းများနှင့် သင်္ဘောဆိပ်ခံတံတားများ အပေါ်သို့လည်းကောင်း၊"
      },
      {
        "en": "And birdies asleep in the forks of the trees.",
        "mm": "သစ်ပင်ခွကြားတွင် အိပ်မောကျနေသော ငှက်ကလေးများ အပေါ်သို့လည်းကောင်း အလင်းပေးသည်၊"
      },
      {
        "en": "The squalling cat and the squeaking mouse,",
        "mm": "စူးရှစွာ အော်ဟစ်နေသော ကြောင်နှင့် တကျွီကျွီ မြည်နေသော ကြွက်ကလေး၊"
      },
      {
        "en": "The howling dog by the door of the house,",
        "mm": "အိမ်တံခါးဝနားတွင် အူနေသော ခွေးကလေးနှင့်၊"
      },
      {
        "en": "The bat that lies in bed at noon,",
        "mm": "မွန်းတည့်ချိန်တွင် အိပ်စက်လေ့ရှိသော လင်းနို့တို့သည်၊"
      },
      {
        "en": "All love to be out by the light of the moon.",
        "mm": "အားလုံးပင် လမင်းကြီး၏ အလင်းရောင်အောက်၌ အပြင်ထွက်ရသည်ကို နှစ်သက်ကြသည်၊"
      },
      {
        "en": "But all of the things that belong to the day",
        "mm": "သို့သော် နေ့အချိန်နှင့် သက်ဆိုင်သော သက်ရှိအရာအားလုံးကမူ၊"
      },
      {
        "en": "Cuddle to sleep to be out of her way;",
        "mm": "လမင်းကြီး၏ လမ်းကြောင်းမှ ဖယ်ရှားကာ ကွေးကွေးလေး အိပ်စက်ကြတော့သည်၊"
      },
      {
        "en": "And flowers and children close their eyes",
        "mm": "ပန်းကလေးများနှင့် ကလေးငယ်များသည်လည်း မျက်လုံးလေးများ မှိတ်စက်အိပ်ပျော်ကြသည်၊"
      },
      {
        "en": "Till up in the morning the sun shall arise.",
        "mm": "နံနက်ခင်း၌ နေမင်းကြီး ပြန်လည်ထွက်ပေါ်လာသည့် အချိန်အထိပင် ဖြစ်တော့သည်။"
      }
    ],
    "note": "💡 ရှင်းလင်းချက်: ညအချိန် လရောင်အောက်တွင် လှုပ်ရှားကျက်စားကြသော ညသတ္တဝါများနှင့် အိပ်စက်အနားယူကြသော နေ့သတ္တဝါများအကြောင်းကို ကလေးများ နားလည်လွယ်အောင် ဖွဲ့ဆိုထားပါသည်။"
  }
];

const essaysData = [
  {
    "title": "1. My Favourite Person (Unit 4 Writing)",
    "category": "Paragraph / Essay",
    "sentences": [
      {
        "en": "My favourite person in my family is my grandmother.",
        "mm": "ကျွန်မတို့ မိသားစုထဲမှာ ကျွန်မ အချစ်ခင်အနှစ်သက်ဆုံးသူကတော့ အဘွားပဲ ဖြစ်ပါတယ်။"
      },
      {
        "en": "She is the most patient and kindest person I have ever met.",
        "mm": "အဘွားဟာ ကျွန်မ တွေ့ဖူးသမျှထဲမှာ စိတ်အရှည်ဆုံးနဲ့ အကြင်နာတတ်ဆုံး ပုဂ္ဂိုလ်ဖြစ်ပါတယ်။"
      },
      {
        "en": "She never gets angry with us and always speaks with a sweet smile.",
        "mm": "သူမဟာ ကျွန်မတို့ကို ဘယ်တော့မှ စိတ်မဆိုးတတ်ဘဲ ချိုသာတဲ့ အပြုံးလေးနဲ့ အမြဲစကားပြောလေ့ရှိပါတယ်။"
      },
      {
        "en": "Moreover, she often makes delicious traditional snacks for me and shares them with our neighbours.",
        "mm": "ဒါ့အပြင် အဘွားက ကျွန်မအတွက် အရသာရှိတဲ့ ရိုးရာမုန့်လေးတွေ မကြာခဏ လုပ်ကျွေးတတ်ပြီး အိမ်နီးချင်းတွေကိုလည်း ဝေမျှပေးလေ့ရှိပါတယ်။"
      },
      {
        "en": "For these reasons, I love and respect my grandmother most.",
        "mm": "ဒီအကြောင်းပြချက်တွေကြောင့် အဘွားကို ကျွန်မ အချစ်ဆုံးနဲ့ အလေးစားဆုံး ဖြစ်ပါတယ်။"
      }
    ]
  },
  {
    "title": "2. My School Description (Unit 2 Writing)",
    "category": "Descriptive Essay",
    "sentences": [
      {
        "en": "I attend Basic Education High School, which is located in a peaceful and green area.",
        "mm": "ကျွန်မဟာ အေးချမ်းပြီး စိမ်းလန်းစိုပြည်တဲ့ နေရာမှာ တည်ရှိတဲ့ အခြေခံပညာ အထက်တန်းကျောင်းမှာ တက်ရောက်နေပါတယ်။"
      },
      {
        "en": "There are forty dedicated teachers and about one thousand students in our school.",
        "mm": "ကျွန်မတို့ကျောင်းမှာ စေတနာထား သင်ကြားပေးတဲ့ ဆရာဆရာမ ၄၀ ဦးနဲ့ ကျောင်းသားကျောင်းသူ ၁,၀၀၀ ခန့် ရှိပါတယ်။"
      },
      {
        "en": "Our school has clean classrooms, a well-equipped science lab, a large library, and a spacious playground.",
        "mm": "ကျောင်းမှာ သန့်ရှင်းတဲ့ စာသင်ခန်းတွေ၊ ပစ္စည်းစုံလင်တဲ့ သိပ္ပံခန်း၊ စာကြည့်တိုက်ကြီးနဲ့ ကျယ်ဝန်းတဲ့ ကစားကွင်းတို့ ရှိပါတယ်။"
      },
      {
        "en": "At weekends, students can take part in extra-curricular activities such as sports, scouting, and school band.",
        "mm": "ကျောင်းပိတ်ရက်တွေမှာ အားကစား၊ ကင်းထောက်နဲ့ ကျောင်းဘင်ခရာတီးဝိုင်းလို ကျောင်းပြင်ပလှုပ်ရှားမှုတွေမှာ ပါဝင်နိုင်ပါတယ်။"
      },
      {
        "en": "I am very proud of my school because it gives us both knowledge and good manners.",
        "mm": "ပညာဗဟုသုတရော ယဉ်ကျေးလိမ္မာမှုပါ သင်ကြားပေးတဲ့ ကျွန်မတို့ကျောင်းအတွက် အလွန်ဂုဏ်ယူမိပါတယ်။"
      }
    ]
  },
  {
    "title": "3. How We Can Save Our Environment (Unit 6 Writing)",
    "category": "Expository Essay",
    "sentences": [
      {
        "en": "Our planet Earth provides us with clean air, fresh water, and natural resources, so we must protect it.",
        "mm": "ကျွန်ုပ်တို့ရဲ့ ကမ္ဘာမြေကြီးက သန့်ရှင်းတဲ့လေ၊ ရေချိုနဲ့ သဘာဝသယံဇာတတွေ ပေးစွမ်းထားတာကြောင့် ကျွန်ုပ်တို့ ပြန်လည်ကာကွယ်စောင့်ရှောက်ရပါမယ်။"
      },
      {
        "en": "First, we must practice the three R's: reduce, reuse, and recycle in our daily lives.",
        "mm": "ပထမဦးစွာ နေ့စဉ်ဘဝမှာ လျှော့ချခြင်း (Reduce)၊ ပြန်လည်အသုံးပြုခြင်း (Reuse) နဲ့ ပြန်လည်ပြုပြင်ထုတ်လုပ်ခြင်း (Recycle) ဆိုတဲ့ R သုံးလုံးကို ကျင့်သုံးရပါမယ်။"
      },
      {
        "en": "We must use tote bags instead of plastic bags when we go shopping.",
        "mm": "ဈေးဝယ်ထွက်တဲ့အခါ ပလတ်စတစ်အိတ်တွေအစား ချည်လွယ်အိတ်တွေကို အသုံးပြုရပါမယ်။"
      },
      {
        "en": "In addition, we must save electricity and water at home and plant more trees around our village.",
        "mm": "ထို့အပြင် အိမ်မှာ လျှပ်စစ်မီးနဲ့ ရေကို ချွေတာသုံးစွဲရမှာဖြစ်ပြီး ကျေးရွာပတ်ဝန်းကျင်မှာ သစ်ပင်တွေ ပိုမိုစိုက်ပျိုးရပါမယ်။"
      },
      {
        "en": "If everyone works together, our environment will become cleaner, greener, and healthier.",
        "mm": "လူတိုင်း အတူတကွ ပူးပေါင်းလုပ်ဆောင်ကြမယ်ဆိုရင် ပတ်ဝန်းကျင်ဟာ ပိုမိုသန့်ရှင်းစိမ်းလန်းပြီး ကျန်းမာပျော်ရွှင်စရာ ဖြစ်လာပါလိမ့်မယ်။"
      }
    ]
  },
  {
    "title": "4. A Memorable Holiday (Unit 9 Writing)",
    "category": "Narrative Essay",
    "sentences": [
      {
        "en": "Last summer holiday, my family and I went on a memorable trip to Ngapali Beach.",
        "mm": "ပြီးခဲ့တဲ့ နွေရာသီကျောင်းပိတ်ရက်တုန်းက ကျွန်မတို့ မိသားစုဟာ ငပလီကမ်းခြေကို အမှတ်တရ ခရီးတစ်ခု သွားရောက်ခဲ့ကြပါတယ်။"
      },
      {
        "en": "We travelled by coach and enjoyed the scenic views of green mountains and villages along the way.",
        "mm": "ကျွန်မတို့ အဝေးပြေးကားနဲ့ ခရီးထွက်ခဲ့ကြပြီး လမ်းတစ်လျှောက် စိမ်းလန်းတဲ့ တောင်တန်းတွေနဲ့ ကျေးရွာလေးတွေရဲ့ သာယာတဲ့ ရှုခင်းတွေကို ကြည့်ရှုခံစားခဲ့ကြပါတယ်။"
      },
      {
        "en": "When we arrived at the beach, the air was fresh and the blue sea water was warm and relaxing.",
        "mm": "ကမ်းခြေကို ရောက်တဲ့အခါ လေထုက လတ်ဆတ်နေပြီး ပြာလဲ့နေတဲ့ ပင်လယ်ရေက နွေးထွေးအပန်းပြေစေပါတယ်။"
      },
      {
        "en": "We swam in the sea, built sandcastles, and ate delicious fresh seafood in the evening.",
        "mm": "ကျွန်မတို့ ပင်လယ်ထဲမှာ ရေကူးကြတယ်၊ သဲရဲတိုက်လေးတွေ ဆောက်ကြတယ်၊ ညနေခင်းမှာတော့ အရသာရှိတဲ့ ပင်လယ်စာလတ်လတ်ဆတ်ဆတ်တွေ စားသောက်ခဲ့ကြပါတယ်။"
      },
      {
        "en": "Although we were tired when we returned home, it was the happiest holiday in my life.",
        "mm": "အိမ်ပြန်ရောက်တဲ့အခါ ပင်ပန်းနေပေမဲ့လည်း ကျွန်မဘဝမှာ အပျော်ရွှင်ရဆုံး အားလပ်ရက်ခရီးစဉ်တစ်ခု ဖြစ်ခဲ့ပါတယ်။"
      }
    ]
  },
  {
    "title": "5. An Invitation Email to a Friend (Unit 7 Writing)",
    "category": "Email / Letter",
    "sentences": [
      {
        "en": "Dear Su Su, How are you? I hope you and your family are doing well.",
        "mm": "ချစ်လှစွာသော စုစုရေ... နေကောင်းရဲ့လား? နင်နဲ့ နင့်မိသားစုအားလုံး ကျန်းမာပျော်ရွှင်နေမယ်လို့ မျှော်လင့်ပါတယ်။"
      },
      {
        "en": "I have some exciting news to tell you about our coming weekend.",
        "mm": "လာမယ့် စနေ၊ တနင်္ဂနွေ အားလပ်ရက်အတွက် စိတ်လှုပ်ရှားစရာ သတင်းကောင်းတစ်ခု ပြောပြစရာရှိတယ်။"
      },
      {
        "en": "My uncle has arranged a two-day camping and trekking trip to the hills, and I would like you to join us.",
        "mm": "ငါ့ဦးလေးက တောင်တန်းတွေဆီ နှစ်ရက်ကြာ စခန်းချတောင်တက်ခရီးစဉ် စီစဉ်ထားလို့ နင့်ကိုလည်း အတူလိုက်ခဲ့စေချင်တယ်။"
      },
      {
        "en": "We have already prepared tents, sleeping bags, and backpacks, so you do not need to worry about anything.",
        "mm": "ရွက်ဖျင်တဲတွေ၊ အိပ်ရာလိပ်တွေနဲ့ ကျောပိုးအိတ်တွေ အကုန်ပြင်ဆင်ပြီးသားမို့ ဘာမှစိတ်ပူစရာ မလိုပါဘူး။"
      },
      {
        "en": "Please ask your parents for permission and let me know soon. Best wishes, Thinzar.",
        "mm": "မိဘတွေဆီမှာ ခွင့်တောင်းပြီး ငါ့ကို အမြန်ဆုံး အကြောင်းပြန်ပေးပါဦးနော်။ ခင်မင်လျက် - သဉ္ဇာ။"
      }
    ]
  }
];
