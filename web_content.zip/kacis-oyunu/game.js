(function () {
  const canvas = document.getElementById('c');
  const ctx = canvas.getContext('2d');
  const bgcanvas = document.getElementById('bgcanvas');
  const bctx = bgcanvas.getContext('2d');
  const wrap = document.getElementById('wrap');
  const scoreEl = document.getElementById('score');
  const bestEl = document.getElementById('best');
  const comboEl = document.getElementById('combo');
  const coinPopup = document.getElementById('coinPopup');
  const sessionCoinsEl = document.getElementById('sessionCoins');
  const overlay = document.getElementById('overlay');
  const startBtn = document.getElementById('startBtn');
  const muteBtn = document.getElementById('muteBtn');
  const pauseBtn = document.getElementById('pauseBtn');
  const menuInfoBtn = document.getElementById('menuInfoBtn');
  const menuLangBtn = document.getElementById('menuLangBtn');
  const infoOverlay = document.getElementById('infoOverlay');
  const closeInfoBtn = document.getElementById('closeInfoBtn');
  const pauseOverlay = document.getElementById('pauseOverlay');
  const resumeBtn = document.getElementById('resumeBtn');
  const pauseRestartBtn = document.getElementById('pauseRestartBtn');
  const pauseHomeBtn = document.getElementById('pauseHomeBtn');
  const confirmOverlay = document.getElementById('confirmOverlay');
  const confirmText = document.getElementById('confirmText');
  const confirmBuyBtn = document.getElementById('confirmBuyBtn');
  const cancelBuyBtn = document.getElementById('cancelBuyBtn');
  const levelEl = document.getElementById('level');
  const levelFlash = document.getElementById('levelFlash');
  const toastFlash = document.getElementById('toastFlash');
  const hintEl = document.getElementById('hint');
  const shieldIcon = document.getElementById('shieldIcon');
  const boostIcon = document.getElementById('boostIcon');
  const dashIcon = document.getElementById('dashIcon');
  const resumeProtectIcon = document.getElementById('resumeProtectIcon');
  const nameContainer = document.getElementById('nameContainer');

  // ---------- Güçlendirilmiş Bellek & Depolama Katmanı ----------
  function safeStorageGet(key, def) {
    try {
      const val = localStorage.getItem(key);
      return val !== null ? val : def;
    } catch (e) {
      return def;
    }
  }

  function safeStorageSet(key, val) {
    try {
      localStorage.setItem(key, String(val));
    } catch (e) {}
  }

  let playerName = safeStorageGet('neonKacisPlayerName', '');

  // ---------- Çok Dilli Sözlük (TR, EN, DE) ----------
  const I18N = {
    tr: {
      codeFirst: 'T',
      codeSecond: 'R',
      gameTitle: 'NEON KAÇIŞ',
      bestPrefix: 'EN İYİ: ',
      levelPrefix: 'SEVİYE ',
      comboSuffix: 'x KOMBO!',
      start: 'BAŞLA',
      restart: 'TEKRAR OYNA',
      shop: 'MAĞAZA',
      closeShop: 'MAĞAZAYI KAPAT',
      hint: 'Sürükle | Çift Tık / Shift: Dash | P: Duraklat',
      brand: '✦ BE STUDIO TARAFINDAN GELİŞTİRİLDİ',
      totalWallet: 'Toplam Cüzdan:',
      thisRunCoins: 'Bu Tur Toplanan: 🪙 ',
      gameOver: 'OYUN BİTTİ',
      yourScore: 'SKORUN',
      bestScore: 'EN İYİ SKOR: ',
      pauseTitle: 'OYUN DURAKLATILDI',
      pauseSub: 'Devam ettiğinde 10 saniye dokunulmazlık kazanırsın.',
      resume: 'DEVAM ET',
      restartGame: 'TEKRAR BAŞLAT',
      home: 'ANA MENÜ',
      guideTitle: 'OYUN REHBERİ',
      guideUnderstood: 'ANLADIM, DÖN',
      confirmTitle: 'SATIN ALMA ONAYI',
      confirmBuy: 'SATIN AL',
      cancel: 'İPTAL',
      confirmMsg: (name, cost, isSkin) => `"${name}" ${isSkin ? 'rengini' : 'atmosferini'} ${cost} 🪙 karşılığında satın almak istiyor musun?`,
      notEnoughCoins: '❌ YETERSİZ COIN!',
      speedWarning: (name) => `⚠️ DİKKAT ${name ? name.toUpperCase() : ''}: HIZ ARTIYOR!`,
      dashToast: '💨 DASH!',
      shieldToast: '🛡 15 SN KALKAN!',
      boostToast: '⚡ SÜPER ŞİMŞEK!',
      resumeToast: '⏳ 10 SN KORUMA!',
      nearMiss: '⚡ SIYRILMA! +25',
      shatter: '+20 PARÇALAMA!',
      shopColors: 'TOP RENGİ',
      shopAtmos: 'ATMOSFER',
      selected: 'SEÇİLİ',
      select: 'SEÇ',
      namePlaceholder: 'Rumuzunu Yaz...',
      pilotBadge: (n) => `PILOT: ${n.toUpperCase()}`,
      legend: [
        'Mavi orb — skor verir, kombo katar',
        'Altın küp — mağaza parası (+1 🪙)',
        'Mor kalkan — 15 sn engelleri parçalar',
        'Yıldırım — çift skor ve hız'
      ],
      guideItems: [
        { label: '🔵 Mavi Orb:', desc: 'Skorunu katlar. Seri toplarsan kombo çarpanı büyür.' },
        { label: '🟡 Altın Küp:', desc: 'Cüzdanına 1 Coin ekler. Mağazada harcamak için topla.' },
        { label: '🟣 Mor Kalkan:', desc: '15 saniye sürer. Engelleri parçalayarak geçmeni sağlar.' },
        { label: '🟢 Şimşek:', desc: 'Kısa süreliğine çift skor ve hız verir.' },
        { label: '💨 Işık Sıçraması (Dash):', desc: 'Çift dokun / Shift tuşuna bas. 0.25 sn hasarsız süzülürsün.' },
        { label: '⚡ Sıyrılma:', desc: 'Engele çarpmadan kıl payı yanından geçersen +25 skor kazanırsın!' }
      ],
      cheers: [
        (n) => `✨ İYİSİN ${n}!`,
        (n) => `🔥 SÜPER GİDİYORSUN ${n}!`,
        (n) => `⚡ EFSANE KOMBO ${n}!`,
        (n) => `👑 WOW İNANILMAZ ${n}!`,
        (n) => `🚀 KİMSE SENİ TUTAMAZ ${n}!`
      ]
    },
    en: {
      codeFirst: 'E',
      codeSecond: 'N',
      gameTitle: 'NEON ESCAPE',
      bestPrefix: 'BEST: ',
      levelPrefix: 'LEVEL ',
      comboSuffix: 'x COMBO!',
      start: 'START',
      restart: 'PLAY AGAIN',
      shop: 'SHOP',
      closeShop: 'CLOSE SHOP',
      hint: 'Drag | Double Tap / Shift: Dash | P: Pause',
      brand: '✦ DEVELOPED BY BE STUDIO',
      totalWallet: 'Total Wallet:',
      thisRunCoins: 'Run Coins: 🪙 ',
      gameOver: 'GAME OVER',
      yourScore: 'YOUR SCORE',
      bestScore: 'BEST SCORE: ',
      pauseTitle: 'GAME PAUSED',
      pauseSub: 'You get 10 seconds of invulnerability upon resuming.',
      resume: 'RESUME',
      restartGame: 'RESTART',
      home: 'MAIN MENU',
      guideTitle: 'HOW TO PLAY',
      guideUnderstood: 'GOT IT, BACK',
      confirmTitle: 'CONFIRM PURCHASE',
      confirmBuy: 'BUY',
      cancel: 'CANCEL',
      confirmMsg: (name, cost, isSkin) => `Purchase "${name}" ${isSkin ? 'color' : 'atmosphere'} for ${cost} 🪙?`,
      notEnoughCoins: '❌ NOT ENOUGH COINS!',
      speedWarning: (name) => `⚠️ WATCH OUT ${name ? name.toUpperCase() : ''}: SPEEDING UP!`,
      dashToast: '💨 DASH!',
      shieldToast: '🛡 15s SHIELD!',
      boostToast: '⚡ SUPER BOOST!',
      resumeToast: '⏳ 10s SHIELD!',
      nearMiss: '⚡ NEAR-MISS! +25',
      shatter: '+20 SHATTER!',
      shopColors: 'BALL COLOR',
      shopAtmos: 'ATMOSPHERE',
      selected: 'EQUIPPED',
      select: 'EQUIP',
      namePlaceholder: 'Enter Alias...',
      pilotBadge: (n) => `PILOT: ${n.toUpperCase()}`,
      legend: [
        'Blue Orb — adds score & combo',
        'Gold Cube — shop currency (+1 🪙)',
        'Purple Shield — shatters hazards for 15s',
        'Lightning — double score & high speed'
      ],
      guideItems: [
        { label: '🔵 Blue Orb:', desc: 'Increases score. Collect in streaks to grow combo multiplier.' },
        { label: '🟡 Gold Cube:', desc: 'Adds 1 Coin to your wallet. Collect to unlock items.' },
        { label: '🟣 Purple Shield:', desc: 'Lasts 15s. Obliterates hazards on collision.' },
        { label: '🟢 Lightning:', desc: 'Grants double score and high agility temporarily.' },
        { label: '💨 Light Dash:', desc: 'Double tap / press Shift to dash invulnerable for 0.25s.' },
        { label: '⚡ Near-Miss:', desc: 'Graze close to hazards without hitting for +25 bonus!' }
      ],
      cheers: [
        (n) => `✨ NICE ${n}!`,
        (n) => `🔥 ON FIRE ${n}!`,
        (n) => `⚡ LEGENDARY COMBO ${n}!`,
        (n) => `👑 WOW INCREDIBLE ${n}!`,
        (n) => `🚀 UNSTOPPABLE ${n}!`
      ]
    },
    de: {
      codeFirst: 'D',
      codeSecond: 'E',
      gameTitle: 'NEON ESCAPE',
      bestPrefix: 'BESTE: ',
      levelPrefix: 'STUFE ',
      comboSuffix: 'x KOMBO!',
      start: 'START',
      restart: 'NOCHMAL',
      shop: 'SHOP',
      closeShop: 'SHOP SCHLIEẞEN',
      hint: 'Ziehen | Doppeltipp / Shift: Dash | P: Pause',
      brand: '✦ ENTWICKELT VON BE STUDIO',
      totalWallet: 'Gesamte Münzen:',
      thisRunCoins: 'Diese Runde: 🪙 ',
      gameOver: 'SPIEL VORBEI',
      yourScore: 'DEIN SCORE',
      bestScore: 'BESTER SCORE: ',
      pauseTitle: 'SPIEL PAUSIERT',
      pauseSub: 'Nach Fortsetzen 10 Sekunden Unverwundbarkeit.',
      resume: 'WEITER',
      restartGame: 'NEUSTART',
      home: 'HAUPTMENÜ',
      guideTitle: 'SPIELANLEITUNG',
      guideUnderstood: 'VERSTANDEN',
      confirmTitle: 'KAUF BESTÄTIGEN',
      confirmBuy: 'KAUFEN',
      cancel: 'ABBRECHEN',
      confirmMsg: (name, cost, isSkin) => `Möchtest du "${name}" für ${cost} 🪙 kaufen?`,
      notEnoughCoins: '❌ ZU WENIG MÜNZEN!',
      speedWarning: (name) => `⚠️ ACHTUNG ${name ? name.toUpperCase() : ''}: SCHNELLER!`,
      dashToast: '💨 DASH!',
      shieldToast: '🛡 15s SCHILD!',
      boostToast: '⚡ SUPER BOOST!',
      resumeToast: '⏳ 10s SCHUTZ!',
      nearMiss: '⚡ KNAPP! +25',
      shatter: '+20 ZERSCHMETTERT!',
      shopColors: 'BALLFARBE',
      shopAtmos: 'ATMOSPHÄRE',
      selected: 'AKTIV',
      select: 'WÄHLEN',
      namePlaceholder: 'Spielername...',
      pilotBadge: (n) => `PILOT: ${n.toUpperCase()}`,
      legend: [
        'Blauer Orb — Punkte & Kombo',
        'Goldener Würfel — Währung (+1 🪙)',
        'Lila Schild — zerstört Gefahren für 15s',
        'Blitz — doppelte Punkte & Tempo'
      ],
      guideItems: [
        { label: '🔵 Blauer Orb:', desc: 'Erhöht Punktzahl. Serie vergrößert den Kombo-Multiplikator.' },
        { label: '🟡 Goldener Würfel:', desc: 'Gibt 1 Münze für den Shop.' },
        { label: '🟣 Lila Schild:', desc: '15s aktiv. Zerstört Hindernisse bei Berührung.' },
        { label: '🟢 Blitz:', desc: 'Kurzzeitig doppelte Punkte und Agilität.' },
        { label: '💨 Licht-Dash:', desc: 'Doppeltippen / Shift: 0.25s unverwundbar dashen.' },
        { label: '⚡ Knapp vorbei:', desc: 'Haarscharf an Gefahren vorbei für +25 Bonuspunkte!' }
      ],
      cheers: [
        (n) => `✨ KLASSE ${n}!`,
        (n) => `🔥 SUPER LAUF ${n}!`,
        (n) => `⚡ LEGENDÄRE KOMBO ${n}!`,
        (n) => `👑 WAHNSINN ${n}!`,
        (n) => `🚀 NICHT ZU STOPPEN ${n}!`
      ]
    }
  };

  const LANG_KEYS = ['tr', 'en', 'de'];
  let currentLang = safeStorageGet('neonKacisLang', 'tr');
  if (!I18N[currentLang]) currentLang = 'tr';

  function tText(key) {
    return I18N[currentLang][key] || I18N['tr'][key];
  }

  // ---------- Tek Seferlik İsim Girişi & Rozet Yapısı ----------
  function renderNameContainer() {
    if (!nameContainer) return;
    const cur = I18N[currentLang];
    if (playerName) {
      nameContainer.innerHTML = `
        <div class="lockedNameBadge">
          <span style="font-size:11px; opacity:0.8;">🔒</span> ${cur.pilotBadge(playerName)}
        </div>
      `;
    } else {
      nameContainer.innerHTML = `
        <div class="nameInputBox">
          <input type="text" id="oneTimeNameInput" maxlength="12" placeholder="${cur.namePlaceholder}" autocomplete="off" />
          <button class="confirmTickBtn" id="confirmTickBtn" aria-label="Onayla">✓</button>
        </div>
      `;
      const input = document.getElementById('oneTimeNameInput');
      const tick = document.getElementById('confirmTickBtn');

      function saveName() {
        const val = input.value.trim();
        playerName = val || 'Pilot';
        safeStorageSet('neonKacisPlayerName', playerName);
        vibrate(30);
        renderNameContainer();
      }

      tick.addEventListener('click', saveName);
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') saveName();
      });
    }
  }

  function applyLanguage() {
    const cur = I18N[currentLang];

    if (menuLangBtn) {
      menuLangBtn.innerHTML = `
        <span class="langBlue">${cur.codeFirst}</span><span class="langWhite">${cur.codeSecond}</span>
      `;
    }

    document.title = cur.gameTitle;
    bestEl.textContent = cur.bestPrefix + best;
    levelEl.textContent = cur.levelPrefix + (level || 1);
    hintEl.textContent = cur.hint;

    const brandEl = document.getElementById('brandText');
    if (brandEl) brandEl.innerHTML = `<span class="brandGlow">✦</span> ${cur.brand.replace('✦ ', '')}`;

    const wLabel = document.getElementById('walletLabel');
    if (wLabel) wLabel.textContent = cur.totalWallet;

    const mTitle = document.getElementById('menuTitle');
    if (mTitle) mTitle.textContent = cur.gameTitle;

    const sBtn = document.getElementById('startBtn');
    if (sBtn) sBtn.textContent = cur.start;

    const shToggle = document.getElementById('shopToggle');
    if (shToggle) {
      const panel = document.getElementById('shopPanel');
      shToggle.textContent = panel && !panel.classList.contains('hidden') ? cur.closeShop : cur.shop;
    }

    const pTitle = document.getElementById('pauseTitle');
    if (pTitle) pTitle.textContent = cur.pauseTitle;
    const pSub = document.getElementById('pauseSub');
    if (pSub) pSub.textContent = cur.pauseSub;
    if (resumeBtn) resumeBtn.textContent = cur.resume;
    if (pauseRestartBtn) pauseRestartBtn.textContent = cur.restartGame;
    if (pauseHomeBtn) pauseHomeBtn.textContent = cur.home;

    const gTitle = document.getElementById('guideTitle');
    if (gTitle) gTitle.textContent = cur.guideTitle;
    if (closeInfoBtn) closeInfoBtn.textContent = cur.guideUnderstood;

    const cTitle = document.getElementById('confirmTitle');
    if (cTitle) cTitle.textContent = cur.confirmTitle;
    if (confirmBuyBtn) confirmBuyBtn.textContent = cur.confirmBuy;
    if (cancelBuyBtn) cancelBuyBtn.textContent = cur.cancel;

    renderNameContainer();

    const guideContent = document.getElementById('guideListContent');
    if (guideContent) {
      guideContent.innerHTML = cur.guideItems.map(item =>
        `<div class="guideItem"><span>${item.label}</span> ${item.desc}</div>`
      ).join('');
    }

    const mLegend = document.getElementById('menuLegend');
    if (mLegend) {
      mLegend.innerHTML = `
        <div><span class="dot" style="background:var(--pc,var(--cyan)); box-shadow:0 0 6px var(--pc,var(--cyan));"></span>${cur.legend[0]}</div>
        <div><span class="dot" style="background:var(--gold); box-shadow:0 0 6px var(--gold);"></span>${cur.legend[1]}</div>
        <div><span class="dot" style="background:var(--violet); box-shadow:0 0 6px var(--violet);"></span>${cur.legend[2]}</div>
        <div><span class="dot" style="background:var(--lime); box-shadow:0 0 6px var(--lime);"></span>${cur.legend[3]}</div>
      `;
    }

    renderShop();
  }

  function cycleLanguage() {
    const nextIdx = (LANG_KEYS.indexOf(currentLang) + 1) % LANG_KEYS.length;
    currentLang = LANG_KEYS[nextIdx];
    safeStorageSet('neonKacisLang', currentLang);
    applyLanguage();
    vibrate(25);
  }

  if (menuLangBtn) menuLangBtn.addEventListener('click', cycleLanguage);

  // ---------- Web Audio & Tok Bas Motoru ----------
  let actx = null;
  let muted = false;
  let musicTimer = null;
  let musicStep = 0;
  const BASS_NOTES = [55, 43.65, 65.41, 49.0];

  try {
    muted = safeStorageGet('neonKacisMuted', '0') === '1';
  } catch (e) {}
  muteBtn.textContent = muted ? '🔇' : '🔊';

  function ensureAudio() {
    if (!actx) {
      try {
        actx = new (window.AudioContext || window.webkitAudioContext)();
      } catch (e) {}
    }
  }

  function tone(freq, dur, type, vol, delay) {
    if (muted || !actx) return;
    delay = delay || 0;
    const t0 = actx.currentTime + delay;
    const osc = actx.createOscillator();
    const gain = actx.createGain();

    osc.type = type || 'sine';
    osc.frequency.setValueAtTime(freq, t0);
    gain.gain.setValueAtTime(0, t0);
    gain.gain.linearRampToValueAtTime(vol || 0.12, t0 + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);

    osc.connect(gain);
    gain.connect(actx.destination);
    osc.start(t0);
    osc.stop(t0 + dur + 0.02);
  }

  function playSynthBass() {
    if (muted || !actx || !running || paused) return;
    const note = BASS_NOTES[musicStep % BASS_NOTES.length];
    const t0 = actx.currentTime;

    const osc = actx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(note, t0);

    const filter = actx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(320, t0);
    filter.frequency.exponentialRampToValueAtTime(90, t0 + 0.22);

    const gain = actx.createGain();
    gain.gain.setValueAtTime(0, t0);
    gain.gain.linearRampToValueAtTime(0.2, t0 + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.24);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(actx.destination);

    osc.start(t0);
    osc.stop(t0 + 0.26);

    musicStep++;
    const interval = Math.max(180, 310 - Math.min(speed, 3.5) * 28);
    musicTimer = setTimeout(playSynthBass, interval);
  }

  function stopSynthBass() {
    if (musicTimer) clearTimeout(musicTimer);
  }

  function sfxCollect(comboN) {
    const base = 520 + Math.min(comboN, 10) * 40;
    tone(base, 0.09, 'triangle', 0.14);
    tone(base * 1.5, 0.09, 'sine', 0.08, 0.03);
  }

  function sfxCoin() {
    tone(750, 0.07, 'square', 0.1);
    tone(1050, 0.08, 'square', 0.08, 0.05);
  }

  function sfxHit() {
    tone(160, 0.28, 'sawtooth', 0.16);
    tone(90, 0.32, 'square', 0.12, 0.03);
  }

  function sfxShieldBreak() {
    tone(300, 0.18, 'square', 0.14);
    tone(180, 0.2, 'sawtooth', 0.1, 0.05);
  }

  function sfxPower() {
    tone(500, 0.08, 'triangle', 0.13);
    tone(750, 0.1, 'triangle', 0.13, 0.07);
    tone(1000, 0.12, 'triangle', 0.14, 0.14);
  }

  function sfxLevelUp() {
    tone(440, 0.1, 'triangle', 0.13);
    tone(554, 0.1, 'triangle', 0.13, 0.09);
    tone(659, 0.1, 'triangle', 0.13, 0.18);
    tone(880, 0.18, 'triangle', 0.14, 0.27);
  }

  function sfxNearMiss() {
    tone(880, 0.06, 'sine', 0.1);
    tone(1320, 0.08, 'triangle', 0.12, 0.03);
  }

  function sfxDash() {
    tone(300, 0.12, 'sawtooth', 0.15);
    tone(600, 0.15, 'sine', 0.12, 0.04);
  }

  function sfxStart() {
    tone(392, 0.09, 'triangle', 0.12);
    tone(523, 0.09, 'triangle', 0.12, 0.08);
    tone(659, 0.14, 'triangle', 0.12, 0.16);
  }

  function vibrate(ms) {
    if ('vibrate' in navigator) {
      try { navigator.vibrate(ms); } catch (e) {}
    }
  }

  muteBtn.addEventListener('click', () => {
    muted = !muted;
    muteBtn.textContent = muted ? '🔇' : '🔊';
    safeStorageSet('neonKacisMuted', muted ? '1' : '0');
    if (muted) stopSynthBass();
    else if (running && !paused) playSynthBass();
  });

  // ---------- Meta (Mağaza) ----------
  let wallet = parseInt(safeStorageGet('neonKacisWallet', '0'), 10) || 0;

  function saveWallet() {
    safeStorageSet('neonKacisWallet', String(wallet));
  }

  const SKINS = [
    { id: 'aqua', name: 'Aqua', color: '#00f0ff', cost: 0 },
    { id: 'solar', name: 'Solar', color: '#ffcf3f', cost: 40 },
    { id: 'rose', name: 'Rose', color: '#ff2ea0', cost: 80 },
    { id: 'lime', name: 'Lime', color: '#7dff4f', cost: 120 }
  ];

  const ATMOS = [
    { id: 'nova', name: 'Nova', a: '#101c3d', b: '#070912', star: '200,220,255', cost: 0 },
    { id: 'ember', name: 'Ember Sky', a: '#3d1a12', b: '#0c0705', star: '255,200,160', cost: 60 },
    { id: 'void', name: 'Void', a: '#241040', b: '#08050f', star: '220,180,255', cost: 100 },
    { id: 'toxic', name: 'Toxic', a: '#123322', b: '#05100a', star: '170,255,200', cost: 140 }
  ];

  function loadIds(key, def) {
    try {
      const data = safeStorageGet(key, null);
      return data ? JSON.parse(data) : def;
    } catch (e) {
      return def;
    }
  }

  let unlockedSkins = loadIds('neonKacisUnlockedSkins', ['aqua']);
  let unlockedAtmos = loadIds('neonKacisUnlockedAtmos', ['nova']);
  let activeSkin = SKINS.find((s) => s.id === safeStorageGet('neonKacisSkin', 'aqua')) || SKINS[0];
  let activeAtmos = ATMOS.find((a) => a.id === safeStorageGet('neonKacisAtmos', 'nova')) || ATMOS[0];

  function applyPreviewColor() {
    const preview = document.getElementById('ballPreview');
    if (preview) preview.style.setProperty('--pc', activeSkin.color);
    const legendDot = document.querySelector('.legend .dot');
    if (legendDot) {
      legendDot.style.background = activeSkin.color;
      legendDot.style.boxShadow = '0 0 6px ' + activeSkin.color;
    }
  }

  let pendingPurchase = null;
  function askPurchaseConfirm(item, type) {
    pendingPurchase = { item, type };
    confirmText.textContent = I18N[currentLang].confirmMsg(item.name, item.cost, type === 'skin');
    confirmOverlay.classList.remove('hidden');
  }

  confirmBuyBtn.addEventListener('click', () => {
    if (!pendingPurchase) return;
    const { item, type } = pendingPurchase;
    if (wallet >= item.cost) {
      wallet -= item.cost;
      saveWallet();
      if (type === 'skin') {
        unlockedSkins.push(item.id);
        safeStorageSet('neonKacisUnlockedSkins', JSON.stringify(unlockedSkins));
        activeSkin = item;
        safeStorageSet('neonKacisSkin', item.id);
      } else {
        unlockedAtmos.push(item.id);
        safeStorageSet('neonKacisUnlockedAtmos', JSON.stringify(unlockedAtmos));
        activeAtmos = item;
        safeStorageSet('neonKacisAtmos', item.id);
      }
      renderShop();
      updateWalletDisplay();
      applyPreviewColor();
      sfxPower();
    }
    confirmOverlay.classList.add('hidden');
    pendingPurchase = null;
  });

  cancelBuyBtn.addEventListener('click', () => {
    confirmOverlay.classList.add('hidden');
    pendingPurchase = null;
  });

  function renderShop() {
    const shop = document.getElementById('shopPanel');
    if (!shop) return;
    const cur = I18N[currentLang];
    shop.innerHTML =
      `<div class="shopLabel">${cur.shopColors}</div><div class="shopRow" id="skinRow"></div><div class="shopLabel">${cur.shopAtmos}</div><div class="shopRow" id="atmosRow"></div>`;

    const skinRow = document.getElementById('skinRow');
    SKINS.forEach((s) => {
      const owned = unlockedSkins.includes(s.id);
      const el = document.createElement('div');
      el.className = 'shopItem' + (activeSkin.id === s.id ? ' sel' : '') + (owned ? '' : ' locked');
      el.style.setProperty('--cc', s.color);
      el.innerHTML = `<div class="shopDot"></div><div class="shopName">${s.name}</div><div class="shopCost">${
        owned ? (activeSkin.id === s.id ? cur.selected : cur.select) : '🪙 ' + s.cost
      }</div>`;

      el.addEventListener('click', () => {
        if (owned) {
          activeSkin = s;
          safeStorageSet('neonKacisSkin', s.id);
          renderShop();
          applyPreviewColor();
        } else if (wallet >= s.cost) {
          askPurchaseConfirm(s, 'skin');
        } else {
          showToast(cur.notEnoughCoins);
        }
      });
      skinRow.appendChild(el);
    });

    const atmosRow = document.getElementById('atmosRow');
    ATMOS.forEach((a) => {
      const owned = unlockedAtmos.includes(a.id);
      const el = document.createElement('div');
      el.className = 'shopItem' + (activeAtmos.id === a.id ? ' sel' : '') + (owned ? '' : ' locked');
      el.style.setProperty('--cc', a.a);
      el.innerHTML = `<div class="shopDot" style="background:linear-gradient(135deg,${a.a},${a.b})"></div><div class="shopName">${a.name}</div><div class="shopCost">${
        owned ? (activeAtmos.id === a.id ? cur.selected : cur.select) : '🪙 ' + a.cost
      }</div>`;

      el.addEventListener('click', () => {
        if (owned) {
          activeAtmos = a;
          safeStorageSet('neonKacisAtmos', a.id);
          renderShop();
        } else if (wallet >= a.cost) {
          askPurchaseConfirm(a, 'atmos');
        } else {
          showToast(cur.notEnoughCoins);
        }
      });
      atmosRow.appendChild(el);
    });
  }

  function updateWalletDisplay() {
    document.querySelectorAll('.walletVal').forEach((el) => { el.textContent = wallet; });
  }

  function attachShopToggle() {
    const btn = document.getElementById('shopToggle');
    if (!btn) return;
    btn.onclick = () => {
      const panel = document.getElementById('shopPanel');
      if (panel) {
        panel.classList.toggle('hidden');
        const isOpen = !panel.classList.contains('hidden');
        btn.textContent = isOpen ? tText('closeShop') : tText('shop');
      }
    };
  }
  attachShopToggle();

  // ---------- Canvas Boyutlandırma ----------
  let W, H, DPR;
  function resize() {
    DPR = Math.min(window.devicePixelRatio || 1, 2);
    W = wrap.clientWidth;
    H = wrap.clientHeight;
    canvas.width = W * DPR;
    canvas.height = H * DPR;
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    bgcanvas.width = W * DPR;
    bgcanvas.height = H * DPR;
    bctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    initStars();
  }
  window.addEventListener('resize', resize);

  let stars = [];
  function initStars() {
    stars = [];
    const n = Math.floor((W * H) / 9000);
    for (let i = 0; i < n; i++) {
      stars.push({
        x: Math.random() * W,
        y: Math.random() * H,
        r: Math.random() * 1.4 + 0.3,
        s: Math.random() * 0.4 + 0.15,
        tw: Math.random() * Math.PI * 2
      });
    }
  }

  const speedRef = { v: 1 };
  function drawBG(dt) {
    bctx.clearRect(0, 0, W, H);
    const lv = Math.min(level || 1, 10);
    const grad = bctx.createRadialGradient(W / 2, H * 0.15, 10, W / 2, H * 0.15, H * 0.9);
    grad.addColorStop(0, activeAtmos.a);
    grad.addColorStop(1, activeAtmos.b);
    bctx.fillStyle = grad;
    bctx.fillRect(0, 0, W, H);

    if (lv > 1) {
      bctx.fillStyle = `rgba(255,45,90,${Math.min((lv - 1) * 0.02, 0.2)})`;
      bctx.fillRect(0, 0, W, H);
    }

    stars.forEach((st) => {
      st.y += st.s * (0.6 + speedRef.v * 0.45);
      if (st.y > H) {
        st.y = -2;
        st.x = Math.random() * W;
      }
      st.tw += dt * 2;
      const a = 0.35 + Math.sin(st.tw) * 0.25;
      bctx.fillStyle = `rgba(${activeAtmos.star},${Math.max(a, 0.08)})`;
      bctx.beginPath();
      bctx.arc(st.x, st.y, st.r, 0, Math.PI * 2);
      bctx.fill();
    });
  }

  let best = parseInt(safeStorageGet('neonKacisBest', '0'), 10) || 0;

  // Oyun Durum Değişkenleri
  let player, obstacles, orbs, powerups, particles, floatingTexts;
  let running = false, paused = false;
  let score, speed, spawnT, orbT, powerT, combo, comboT, shake, t, level, levelFlashT;
  let sessionCoins = 0;
  let shieldTimer = 0, boostT = 0, resumeProtection = 0;
  let dashCooldown = 0, dashActiveT = 0;
  let toastTimer = null;

  const SHIELD_MAX_DURATION = 15;
  const RESUME_PROTECT_DURATION = 10;
  const DASH_COOLDOWN_TIME = 7.0;
  const LEVEL_STEP = 150;

  function showToast(text, duration = 1200) {
    if (toastTimer) clearTimeout(toastTimer);
    toastFlash.textContent = text;
    toastFlash.style.opacity = '1';
    toastFlash.style.transform = 'scale(1.15) translateY(-10px)';
    toastTimer = setTimeout(() => {
      toastFlash.style.opacity = '0';
      toastFlash.style.transform = 'scale(0.9) translateY(0px)';
    }, duration);
  }

  function triggerCoinPopup(amount) {
    coinPopup.textContent = `+${amount} 🪙`;
    coinPopup.style.opacity = '1';
    coinPopup.style.transform = 'translateY(-6px)';
    setTimeout(() => {
      coinPopup.style.opacity = '0';
      coinPopup.style.transform = 'translateY(0)';
    }, 800);
  }

  function triggerDash() {
    if (dashCooldown <= 0 && running && !paused) {
      dashCooldown = DASH_COOLDOWN_TIME;
      dashActiveT = 0.25;
      sfxDash();
      vibrate([20, 20]);
      burst(player.x, player.y, '#ffffff', 20);
      showToast(tText('dashToast'), 1000);
      updateBuffIcons();
    }
  }

  function resetState() {
    player = { x: W / 2, y: H - 90, r: 14, trail: [] };
    obstacles = [];
    orbs = [];
    powerups = [];
    particles = [];
    floatingTexts = [];
    running = true;
    paused = false;
    score = 0;
    sessionCoins = 0;
    speed = 1;
    spawnT = 0;
    orbT = 1.5;
    powerT = 38;
    combo = 0;
    comboT = 0;
    shake = 0;
    t = 0;
    level = 1;
    levelFlashT = 0;
    shieldTimer = 0;
    boostT = 0;
    resumeProtection = 0;
    dashCooldown = 0;
    dashActiveT = 0;

    levelEl.textContent = tText('levelPrefix') + '1';
    sessionCoinsEl.textContent = '0';
    levelFlash.style.opacity = 0;
    updateBuffIcons();
    stopSynthBass();
    playSynthBass();
  }

  function updateBuffIcons() {
    shieldIcon.classList.toggle('on', shieldTimer > 0);
    boostIcon.classList.toggle('on', boostT > 0);
    dashIcon.classList.toggle('on', dashCooldown <= 0);
    resumeProtectIcon.classList.toggle('on', resumeProtection > 0);
  }

  function checkLevel() {
    const newLevel = 1 + Math.floor(score / LEVEL_STEP);
    if (newLevel > level) {
      level = newLevel;
      levelEl.textContent = tText('levelPrefix') + level;
      levelFlash.textContent = tText('levelPrefix') + level;
      const c = ['#00f0ff', '#ff2e9a', '#ffb23f', '#a06bff', '#7dff4f'][level % 5];
      levelFlash.style.color = c;
      levelFlashT = 1.4;
      sfxLevelUp();
      vibrate(60);
      burst(player.x, player.y, c, 26);

      if (level === 10) {
        showToast(I18N[currentLang].speedWarning(playerName), 3000);
      } else {
        const cheers = I18N[currentLang].cheers;
        const cheerFunc = cheers[(level - 2) % cheers.length];
        showToast(cheerFunc(playerName || 'Pilot'), 1400);
      }
    }
  }

  function makeDiag() {
    const len = 70 + Math.random() * 50;
    const fromLeft = Math.random() < 0.5;
    const vx = (fromLeft ? 1 : -1) * (1.1 + Math.random() * 1.1) * (0.6 + speed * 0.15);
    const vy = 2.2 + speed * 0.95 + Math.random() * 0.5;
    const angle = Math.atan2(vy, vx);

    obstacles.push({
      type: 'diag',
      x: fromLeft ? -len : W + len,
      y: -20,
      w: len,
      h: 16,
      vx,
      vy,
      angle,
      hue: Math.random() < 0.5 ? '#ff2e9a' : '#00f0ff',
      nearMissed: false
    });
  }

  function makeCrystal() {
    const r = 18 + Math.random() * 8;
    obstacles.push({
      type: 'crystal',
      x: 24 + r + Math.random() * (W - 48 - r * 2),
      y: -30,
      r,
      vy: 2.3 + speed * 0.9 + Math.random() * 0.5,
      vx: 0,
      angle: 0,
      spin: (Math.random() < 0.5 ? 1 : -1) * (1.6 + Math.random() * 1.4),
      hue: '#ff3366',
      pulse: 0,
      nearMissed: false
    });
  }

  function makeSpin() {
    const r = 16 + Math.random() * 6;
    obstacles.push({
      type: 'spin',
      x: 24 + r + Math.random() * (W - 48 - r * 2),
      y: -30,
      r,
      vy: 2.0 + speed * 0.8 + Math.random() * 0.5,
      vx: 0,
      angle: 0,
      spin: (Math.random() < 0.5 ? 1 : -1) * (1.5 + Math.random() * 1.5),
      hue: '#ff2e9a',
      nearMissed: false
    });
  }

  function spawnObstacle() {
    const roll = Math.random();
    if (level >= 10 && roll < 0.35) {
      makeSpin();
    } else if (roll < 0.6) {
      makeCrystal();
    } else {
      makeDiag();
    }

    if (level >= 10 && Math.random() < 0.45) {
      if (Math.random() < 0.5) makeCrystal();
      else makeDiag();
    }
  }

  function spawnOrb() {
    const coinChance = level < 2 ? 0.1 : Math.min(0.25 + (level - 2) * 0.05, 0.5);
    const isCoin = Math.random() < coinChance;
    orbs.push({
      x: 30 + Math.random() * (W - 60),
      y: -20,
      r: 9,
      vy: 2.1 + speed * 0.6,
      type: isCoin ? 'coin' : 'orb'
    });
  }

  function spawnPower() {
    if (level < 2) return;
    const wantShield = Math.random() < 0.5;
    if (wantShield && shieldTimer > 3) return;
    if (!wantShield && boostT > 0) return;

    powerups.push({
      x: 30 + Math.random() * (W - 60),
      y: -20,
      r: 11,
      vy: 1.8 + speed * 0.5,
      type: wantShield ? 'shield' : 'boost'
    });
  }

  function addFloatingText(x, y, text, color) {
    floatingTexts.push({ x, y, text, color, life: 1 });
  }

  function burst(x, y, color, n) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const sp = 1 + Math.random() * 3.5;
      particles.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 1, color });
    }
  }

  // ---------- Girdiler ----------
  let pointerX = null;
  let lastTapTime = 0;

  function setTargetFromClientX(clientX) {
    const rect = wrap.getBoundingClientRect();
    pointerX = clientX - rect.left;
  }

  canvas.addEventListener('pointerdown', (e) => {
    setTargetFromClientX(e.clientX);
    const now = Date.now();
    if (now - lastTapTime < 280) {
      triggerDash();
    }
    lastTapTime = now;
  });

  canvas.addEventListener('pointermove', (e) => {
    if (e.buttons > 0 || e.pointerType === 'touch') setTargetFromClientX(e.clientX);
  });
  window.addEventListener('touchmove', (e) => {
    if (e.touches[0]) setTargetFromClientX(e.touches[0].clientX);
  }, { passive: true });

  let keys = {};
  window.addEventListener('keydown', (e) => {
    keys[e.key] = true;
    if (e.key === 'p' || e.key === 'P') togglePause();
    if (e.key === 'Shift') triggerDash();
  });
  window.addEventListener('keyup', (e) => { keys[e.key] = false; });

  // Rehber & Duraklatma Yöneticisi (Hata Düzeltildi)
  function openInfo() {
    infoOverlay.classList.remove('hidden');
    if (running && !paused) {
      paused = true;
      stopSynthBass();
    }
  }

  function closeInfo() {
    infoOverlay.classList.add('hidden');
    // Eğer oyun oynanırken açıldıysa devam et, ana menüdeyse ana menüde kal
    if (running && paused) {
      resumeGame();
    }
  }

  function togglePause() {
    if (!running) return;
    paused = !paused;
    if (paused) {
      pauseOverlay.classList.remove('hidden');
      stopSynthBass();
    } else {
      resumeGame();
    }
  }

  function resumeGame() {
    pauseOverlay.classList.add('hidden');
    infoOverlay.classList.add('hidden');
    confirmOverlay.classList.add('hidden');
    paused = false;
    resumeProtection = RESUME_PROTECT_DURATION;
    updateBuffIcons();
    showToast(tText('resumeToast'), 1500);
    playSynthBass();
    last = 0;
    requestAnimationFrame(loop);
  }

  function goToHome() {
    running = false;
    paused = false;
    stopSynthBass();
    pauseOverlay.classList.add('hidden');
    infoOverlay.classList.add('hidden');
    confirmOverlay.classList.add('hidden');
    overlay.classList.remove('hidden');
    applyLanguage();
  }

  function restartFromPause() {
    pauseOverlay.classList.add('hidden');
    begin();
  }

  pauseBtn.addEventListener('click', togglePause);
  resumeBtn.addEventListener('click', resumeGame);
  pauseRestartBtn.addEventListener('click', restartFromPause);
  pauseHomeBtn.addEventListener('click', goToHome);
  if (menuInfoBtn) menuInfoBtn.addEventListener('click', openInfo);
  closeInfoBtn.addEventListener('click', closeInfo);

  // ---------- Fizik & Mantık ----------
  function update(dt) {
    t += dt;

    if (level < 10) {
      speed = 1 + t * 0.025 + (level - 1) * 0.08;
    } else {
      speed = 1.8 + (t * 0.06) + (level - 10) * 0.28;
    }
    speedRef.v = speed;

    if (dashCooldown > 0) {
      dashCooldown -= dt;
      if (dashCooldown <= 0) {
        dashCooldown = 0;
        updateBuffIcons();
      }
    }
    if (dashActiveT > 0) dashActiveT -= dt;

    let followRate = 12 + (level >= 2 ? 3 : 0);
    if (boostT > 0) followRate += 5;
    if (dashActiveT > 0) followRate += 18;

    let keySpeed = 7 + (level >= 2 ? 2 : 0);
    if (boostT > 0) keySpeed += 3;
    if (dashActiveT > 0) keySpeed += 14;

    if (pointerX !== null) {
      player.x += (pointerX - player.x) * Math.min(1, dt * followRate);
    }
    if (keys['ArrowLeft']) player.x -= keySpeed;
    if (keys['ArrowRight']) player.x += keySpeed;
    player.x = Math.max(player.r + 6, Math.min(W - player.r - 6, player.x));

    player.trail.push({ x: player.x, y: player.y, life: 1, isDash: dashActiveT > 0 });
    if (player.trail.length > 16) player.trail.shift();
    player.trail.forEach((p) => (p.life -= dt * (dashActiveT > 0 ? 1.5 : 3)));

    spawnT -= dt;
    orbT -= dt;
    powerT -= dt;

    const spawnEvery = level < 10 ? Math.max(0.65, 1.2 - speed * 0.08) : Math.max(0.3, 0.9 - speed * 0.12);
    if (spawnT <= 0) {
      spawnObstacle();
      spawnT = spawnEvery;
    }
    if (orbT <= 0) {
      spawnOrb();
      orbT = 1.8 + Math.random() * 1.2;
    }
    if (powerT <= 0) {
      spawnPower();
      powerT = 36 + Math.random() * 15;
    }

    if (shieldTimer > 0) {
      shieldTimer -= dt;
      if (shieldTimer <= 0) {
        shieldTimer = 0;
        updateBuffIcons();
      }
    }

    if (resumeProtection > 0) {
      resumeProtection -= dt;
      if (resumeProtection <= 0) {
        resumeProtection = 0;
        updateBuffIcons();
      }
    }

    if (boostT > 0) {
      boostT -= dt;
      if (boostT <= 0) updateBuffIcons();
    }

    // Engeller
    for (let i = obstacles.length - 1; i >= 0; i--) {
      const o = obstacles[i];
      o.y += o.vy;
      o.x += o.vx;
      if (o.type === 'spin' || o.type === 'crystal') o.angle += o.spin * dt;
      if (o.type === 'crystal') o.pulse += dt * 4;

      if (o.y > H + 50 || o.x < -100 || o.x > W + 100) {
        obstacles.splice(i, 1);
        score += 2;
        continue;
      }

      let hit = false;
      let centerDist = 0;
      let hitThreshold = 0;

      if (o.type === 'spin' || o.type === 'crystal') {
        const dx0 = o.x - player.x;
        const dy0 = o.y - player.y;
        centerDist = Math.hypot(dx0, dy0);
        hitThreshold = player.r + o.r * 0.76;
        hit = centerDist < hitThreshold;
      } else if (o.type === 'diag') {
        centerDist = Math.hypot(o.x - player.x, o.y - player.y);
        hitThreshold = player.r + o.h * 0.85;
        hit = centerDist < hitThreshold;
      }

      // Near-Miss
      if (!hit && !o.nearMissed && centerDist > hitThreshold && centerDist < hitThreshold + 16) {
        o.nearMissed = true;
        score += 25;
        sfxNearMiss();
        vibrate(15);
        addFloatingText(player.x, player.y - 25, tText('nearMiss'), '#ffffff');
      }

      if (hit) {
        if (shieldTimer > 0 || resumeProtection > 0 || dashActiveT > 0) {
          sfxShieldBreak();
          vibrate([30, 20]);
          burst(player.x, player.y, '#a06bff', 18);
          obstacles.splice(i, 1);
          score += 20;
          addFloatingText(player.x, player.y - 20, tText('shatter'), '#a06bff');
        } else {
          gameOver();
          return;
        }
      }
    }

    // Orblar
    for (let i = orbs.length - 1; i >= 0; i--) {
      const orb = orbs[i];
      orb.y += orb.vy;
      if (orb.y > H + 20) {
        orbs.splice(i, 1);
        combo = 0;
        continue;
      }
      const dx = orb.x - player.x;
      const dy = orb.y - player.y;
      if (dx * dx + dy * dy < (orb.r + player.r) * (orb.r + player.r)) {
        orbs.splice(i, 1);
        if (orb.type === 'coin') {
          wallet += 1;
          sessionCoins += 1;
          sessionCoinsEl.textContent = sessionCoins;
          saveWallet();
          updateWalletDisplay();
          score += 8;
          sfxCoin();
          vibrate(20);
          burst(orb.x, orb.y, '#ffd23f', 16);
          triggerCoinPopup(1);
          addFloatingText(orb.x, orb.y, '+1 🪙', '#ffd23f');
        } else {
          combo++;
          comboT = 1.2;
          const gained = boostT > 0 ? 20 + combo * 8 : 10 + combo * 4;
          score += gained;
          sfxCollect(combo);
          vibrate(10);
          burst(orb.x, orb.y, activeSkin.color, 14);
          if (combo >= 4 && combo % 3 === 0) {
            showToast(`🔥 ${combo}${tText('comboSuffix')}`, 1200);
          }
        }
      }
    }

    // Power-up
    for (let i = powerups.length - 1; i >= 0; i--) {
      const p = powerups[i];
      p.y += p.vy;
      if (p.y > H + 20) {
        powerups.splice(i, 1);
        continue;
      }
      const dx = p.x - player.x;
      const dy = p.y - player.y;
      if (dx * dx + dy * dy < (p.r + player.r) * (p.r + player.r)) {
        powerups.splice(i, 1);
        sfxPower();
        vibrate([40, 40]);
        if (p.type === 'shield') {
          shieldTimer = SHIELD_MAX_DURATION;
          burst(p.x, p.y, '#a06bff', 22);
          showToast(tText('shieldToast'), 1400);
        } else {
          boostT = 6;
          burst(p.x, p.y, '#7dff4f', 20);
          showToast(tText('boostToast'), 1400);
        }
        updateBuffIcons();
      }
    }

    // Yüzen Metinler
    for (let i = floatingTexts.length - 1; i >= 0; i--) {
      const ft = floatingTexts[i];
      ft.y -= dt * 32;
      ft.life -= dt * 1.5;
      if (ft.life <= 0) floatingTexts.splice(i, 1);
    }

    // Parçacıklar
    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.08;
      p.life -= dt * 1.6;
      if (p.life <= 0) particles.splice(i, 1);
    }

    score += dt * (boostT > 0 ? 18 : 9);
    checkLevel();

    if (comboT > 0) {
      comboT -= dt;
      comboEl.style.opacity = combo > 1 ? 1 : 0;
      comboEl.textContent = combo + tText('comboSuffix');
    } else {
      comboEl.style.opacity = 0;
    }

    if (levelFlashT > 0) {
      levelFlashT -= dt;
      levelFlash.style.opacity = Math.min(1, levelFlashT * 2);
      levelFlash.style.transform = `translateY(${(1.4 - levelFlashT) * -14}px) scale(${1 + (1.4 - levelFlashT) * 0.05})`;
    } else {
      levelFlash.style.opacity = 0;
    }

    if (shake > 0) shake -= dt * 4;
    scoreEl.textContent = Math.floor(score);
  }

  // ---------- Render ----------
  function draw() {
    ctx.clearRect(0, 0, W, H);
    ctx.save();
    if (shake > 0) {
      ctx.translate((Math.random() - 0.5) * shake * 6, (Math.random() - 0.5) * shake * 6);
    }

    // İz
    player.trail.forEach((p) => {
      if (p.life <= 0) return;
      ctx.globalAlpha = p.life * (p.isDash ? 0.6 : (shieldTimer > 0 || resumeProtection > 0 ? 0.18 : 0.35));
      ctx.fillStyle = p.isDash ? '#ffffff' : (boostT > 0 ? '#7dff4f' : activeSkin.color);
      ctx.beginPath();
      ctx.arc(p.x, p.y, player.r * p.life * (p.isDash ? 1.2 : 0.8), 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    });

    // Engeller
    obstacles.forEach((o) => {
      ctx.save();
      if (o.type === 'diag') {
        ctx.translate(o.x, o.y);
        ctx.rotate(o.angle);
        ctx.shadowColor = o.hue;
        ctx.shadowBlur = 18;

        const g = ctx.createLinearGradient(-o.w / 2, 0, o.w / 2, 0);
        g.addColorStop(0, 'rgba(255,255,255,0)');
        g.addColorStop(0.5, o.hue);
        g.addColorStop(1, '#ffffff');

        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.moveTo(-o.w / 2, -2);
        ctx.lineTo(o.w / 2 - 8, -o.h / 2);
        ctx.lineTo(o.w / 2, 0);
        ctx.lineTo(o.w / 2 - 8, o.h / 2);
        ctx.lineTo(-o.w / 2, 2);
        ctx.closePath();
        ctx.fill();
      } else if (o.type === 'crystal') {
        ctx.translate(o.x, o.y);
        ctx.rotate(o.angle);
        ctx.shadowColor = o.hue;
        ctx.shadowBlur = 20;

        const pulseScale = 1 + Math.sin(o.pulse) * 0.12;
        ctx.strokeStyle = o.hue;
        ctx.lineWidth = 2;
        ctx.beginPath();
        for (let i = 0; i < 6; i++) {
          const a = (Math.PI / 3) * i;
          const px = Math.cos(a) * (o.r * pulseScale);
          const py = Math.sin(a) * (o.r * pulseScale);
          i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.stroke();

        ctx.fillStyle = 'rgba(255, 51, 102, 0.25)';
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(0, 0, o.r * 0.35, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.shadowColor = o.hue;
        ctx.shadowBlur = 16;
        const g = ctx.createRadialGradient(o.x, o.y, 1, o.x, o.y, o.r);
        g.addColorStop(0, '#ffffff');
        g.addColorStop(0.4, o.hue);
        g.addColorStop(1, '#b8005f');
        ctx.fillStyle = g;
        ctx.translate(o.x, o.y);
        ctx.rotate(o.angle);
        ctx.beginPath();
        ctx.moveTo(0, -o.r);
        ctx.lineTo(o.r, 0);
        ctx.lineTo(0, o.r);
        ctx.lineTo(-o.r, 0);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();
    });

    // Orblar & Altınlar
    orbs.forEach((orb) => {
      ctx.save();
      if (orb.type === 'coin') {
        ctx.shadowColor = '#ffd23f';
        ctx.shadowBlur = 20;
        ctx.fillStyle = '#ffd23f';
        ctx.translate(orb.x, orb.y);
        ctx.rotate(Math.PI / 4);
        ctx.fillRect(-orb.r * 0.75, -orb.r * 0.75, orb.r * 1.5, orb.r * 1.5);
      } else {
        ctx.shadowColor = activeSkin.color;
        ctx.shadowBlur = 20;
        ctx.fillStyle = activeSkin.color;
        ctx.beginPath();
        ctx.arc(orb.x, orb.y, orb.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    });

    // Power-up
    powerups.forEach((p) => {
      ctx.save();
      if (p.type === 'shield') {
        ctx.shadowColor = '#a06bff';
        ctx.shadowBlur = 22;
        ctx.fillStyle = '#a06bff';
        ctx.translate(p.x, p.y);
        ctx.beginPath();
        for (let k = 0; k < 6; k++) {
          const ang = (Math.PI / 3) * k - Math.PI / 2;
          const px = Math.cos(ang) * p.r;
          const py = Math.sin(ang) * p.r;
          k === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.fill();
      } else {
        ctx.shadowColor = '#7dff4f';
        ctx.shadowBlur = 22;
        ctx.fillStyle = '#7dff4f';
        ctx.translate(p.x, p.y);
        ctx.beginPath();
        ctx.moveTo(-4, -p.r);
        ctx.lineTo(6, -2);
        ctx.lineTo(0, -2);
        ctx.lineTo(4, p.r);
        ctx.lineTo(-6, 2);
        ctx.lineTo(0, 2);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();
    });

    // Parçacıklar
    particles.forEach((p) => {
      ctx.globalAlpha = Math.max(p.life, 0);
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    });

    // Yüzen Metinler
    floatingTexts.forEach((ft) => {
      ctx.save();
      ctx.globalAlpha = Math.max(ft.life, 0);
      ctx.font = 'bold 15px "Space Grotesk", sans-serif';
      ctx.fillStyle = ft.color;
      ctx.shadowColor = ft.color;
      ctx.shadowBlur = 12;
      ctx.fillText(ft.text, ft.x - 14, ft.y);
      ctx.restore();
    });

    // Oyuncu
    ctx.save();
    const isTranslucent = shieldTimer > 0 || resumeProtection > 0 || dashActiveT > 0;
    if (isTranslucent) {
      ctx.globalAlpha = 0.45 + Math.sin(t * 12) * 0.15;
    }

    if (shieldTimer > 0) {
      const shieldRatio = shieldTimer / SHIELD_MAX_DURATION;
      ctx.save();
      ctx.strokeStyle = 'rgba(160,107,255,0.9)';
      ctx.lineWidth = 2.5;
      ctx.shadowColor = '#a06bff';
      ctx.shadowBlur = 18;
      ctx.beginPath();
      ctx.arc(player.x, player.y, player.r + 9, 0, Math.PI * 2);
      ctx.stroke();

      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.arc(player.x, player.y, player.r + 13, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * shieldRatio);
      ctx.stroke();
      ctx.restore();
    } else if (resumeProtection > 0) {
      ctx.save();
      ctx.strokeStyle = 'rgba(0, 240, 255, 0.8)';
      ctx.lineWidth = 2;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.arc(player.x, player.y, player.r + 8, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    if (dashCooldown > 0) {
      const dashRatio = 1 - (dashCooldown / DASH_COOLDOWN_TIME);
      ctx.save();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(player.x, player.y, player.r + 5, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * dashRatio);
      ctx.stroke();
      ctx.restore();
    }

    if (boostT > 0) {
      ctx.save();
      ctx.strokeStyle = 'rgba(125,255,79,0.7)';
      ctx.lineWidth = 2;
      ctx.shadowColor = '#7dff4f';
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.arc(player.x, player.y, player.r + 15, 0, Math.PI * 2 * (boostT / 6));
      ctx.stroke();
      ctx.restore();
    }

    ctx.shadowColor = '#fff';
    ctx.shadowBlur = 24;
    const grad = ctx.createRadialGradient(player.x, player.y, 2, player.x, player.y, player.r);
    grad.addColorStop(0, '#ffffff');
    grad.addColorStop(1, dashActiveT > 0 ? '#ffffff' : (boostT > 0 ? '#7dff4f' : activeSkin.color));
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(player.x, player.y, player.r, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
    ctx.restore();
  }

  let last = 0;
  function loop(ts) {
    if (!running || paused) return;
    if (!last) last = ts;
    const dt = Math.min((ts - last) / 1000, 0.05);
    last = ts;
    update(dt);
    drawBG(dt);
    draw();
    requestAnimationFrame(loop);
  }

  function gameOver() {
    running = false;
    stopSynthBass();
    sfxHit();
    vibrate([80, 50, 80]);
    shake = 1.4;
    burst(player.x, player.y, '#ff2e9a', 30);
    draw();

    const finalScore = Math.floor(score);
    if (finalScore > best) {
      best = finalScore;
      safeStorageSet('neonKacisBest', String(best));
    }
    const cur = I18N[currentLang];
    bestEl.textContent = cur.bestPrefix + best;

    overlay.innerHTML = `
      <div class="topNavControls">
        <button id="menuInfoBtn" class="topNavBtn" aria-label="Rehber">!</button>
        <button id="menuLangBtn" class="topNavBtn langPillBtn" aria-label="Dil Değiştir">
          <span class="langBlue">${cur.codeFirst}</span><span class="langWhite">${cur.codeSecond}</span>
        </button>
      </div>
      <h1>${cur.gameOver}</h1>
      <div class="nameInputWrap" id="nameContainer"></div>
      <div class="stat">${cur.yourScore}</div>
      <div class="statval">${finalScore}</div>
      <div class="stat">${cur.bestScore}${best}</div>
      <div class="walletBadge" style="margin-top:10px;">${cur.thisRunCoins}${sessionCoins}</div>
      <div class="walletBadge">${cur.totalWallet} 🪙 <span class="walletVal">${wallet}</span></div>
      <button class="primary" id="restartBtn" style="margin-top:6px;">${cur.restart}</button>
      <button id="shopToggle">${cur.shop}</button>
      <div id="shopPanel" class="hidden"></div>
      <div class="brandFooter">
        <span class="brandGlow">✦</span> ${cur.brand.replace('✦ ', '')}
      </div>
    `;
    overlay.classList.remove('hidden');

    const mBtn = document.getElementById('menuLangBtn');
    if (mBtn) mBtn.addEventListener('click', cycleLanguage);

    const mInfo = document.getElementById('menuInfoBtn');
    if (mInfo) mInfo.addEventListener('click', openInfo);

    renderNameContainer();
    attachShopToggle();
    renderShop();
    document.getElementById('restartBtn').addEventListener('click', begin);
  }

  function begin() {
    ensureAudio();
    sfxStart();
    overlay.classList.add('hidden');
    pointerX = null;
    resize();
    resetState();
    last = 0;
    requestAnimationFrame(loop);
  }

  startBtn.addEventListener('click', begin);
  resize();
  applyLanguage();
})();