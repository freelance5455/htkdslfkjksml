
const $ = id => document.getElementById(id);

let kucing = JSON.parse(
  localStorage.getItem("catshop_kucing") || "[]"
);

let transaksi = JSON.parse(
  localStorage.getItem("catshop_transaksi") || "[]"
);

const rupiah = angka =>
  Number(angka).toLocaleString("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0
  });

function simpanData() {
  localStorage.setItem("catshop_kucing",
    JSON.stringify(kucing));
  localStorage.setItem("catshop_transaksi",
    JSON.stringify(transaksi));
}

function buatId() {
  return Date.now().toString() +
    Math.random().toString(36).slice(2, 7);
}

function aman(teks) {
  return String(teks ?? "").replace(/[&<>"']/g, huruf => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[huruf]);
}

// Tambah data kucing
$("formKucing").addEventListener("submit", function(e) {
  e.preventDefault();

  const harga = Number($("hargaKucing").value);

  if (!Number.isSafeInteger(harga) || harga <= 0) {
    alert("Masukkan harga kucing yang valid.");
    return;
  }

  kucing.push({
    id: buatId(),
    nama: $("namaKucing").value.trim(),
    ras: $("rasKucing").value,
    umur: $("umurKucing").value.trim(),
    kelamin: $("kelaminKucing").value,
    harga,
    keterangan: $("keteranganKucing").value.trim(),
    terjual: false
  });

  simpanData();
  this.reset();
  tampilkanSemua();
  alert("Data kucing berhasil disimpan!");
});

// Isi pilihan kucing yang belum terjual
function isiPilihanKucing() {
  const pilihan = kucing.filter(k => !k.terjual);

  $("pilihKucing").innerHTML =
    '<option value="">Pilih kucing</option>' +
    pilihan.map(k =>
      `<option value="${aman(k.id)}">
        ${aman(k.nama)} - ${aman(k.ras)}
        (${rupiah(k.harga)})
      </option>`
    ).join("");
}

// Saat memilih kucing, isi harga otomatis
$("pilihKucing").addEventListener("change", function() {
  const k = kucing.find(item => item.id === this.value);

  if (k) {
    $("hargaTransaksi").value = k.harga;
  }

  hitungPembayaran();
});

$("hargaTransaksi").addEventListener(
  "input", hitungPembayaran
);

$("uangDibayar").addEventListener(
  "input", hitungPembayaran
);

function hitungPembayaran() {
  const total = Math.max(
    0, Number($("hargaTransaksi").value) || 0
  );

  const uang = Math.max(
    0, Number($("uangDibayar").value) || 0
  );

  $("totalBayar").textContent = rupiah(total);
  $("uangKembalian").textContent =
    rupiah(Math.max(0, uang - total));

  $("sisaBayar").textContent =
    rupiah(Math.max(0, total - uang));
}

// Simpan transaksi pembelian
$("formTransaksi").addEventListener("submit", function(e) {
  e.preventDefault();

  const idKucing = $("pilihKucing").value;
  const k = kucing.find(item => item.id === idKucing);

  if (!k || k.terjual) {
    alert("Pilih kucing yang masih tersedia.");
    return;
  }

  const namaPembeli = $("namaPembeli").value.trim();
  const hpPembeli = $("hpPembeli").value.trim();
  const total = Number($("hargaTransaksi").value);
  const uang = Number($("uangDibayar").value);

  if (!namaPembeli) {
    alert("Nama pembeli harus diisi.");
    return;
  }

  if (!Number.isSafeInteger(total) || total <= 0 ||
      !Number.isSafeInteger(uang) || uang < 0) {
    alert("Periksa harga dan jumlah uang yang dibayar.");
    return;
  }

  if (uang < total) {
    alert("Pembayaran belum lunas. Transaksi tidak disimpan.");
    return;
  }

  const data = {
    id: buatId(),
    tanggal: new Date().toLocaleString("id-ID"),
    namaPembeli,
    hpPembeli,
    namaKucing: k.nama,
    ras: k.ras,
    harga: total,
    dibayar: uang,
    kembalian: uang - total
  };

  transaksi.push(data);
  k.terjual = true;

  simpanData();
  this.reset();
  hitungPembayaran();
  tampilkanSemua();

  alert("Transaksi berhasil disimpan!");
  cetakBukti(data.id);
});

// Tampilkan daftar kucing
function tampilkanKucing() {
  const tersedia = kucing.filter(k => !k.terjual);

  $("daftarKucing").innerHTML = kucing.length
    ? kucing.map(k => `
      <div class="item">
        <strong>${aman(k.nama)}</strong>
        <p>
          Ras: ${aman(k.ras)}<br>
          Umur: ${aman(k.umur)}<br>
          Kelamin: ${aman(k.kelamin)}<br>
          Harga: ${rupiah(k.harga)}<br>
          Status:
          <span class="status">
            ${k.terjual ? "Terjual" : "Tersedia"}
          </span><br>
          Keterangan: ${aman(k.keterangan || "-")}
        </p>
        ${!k.terjual ? `
          <button type="button"
            onclick="hapusKucing('${k.id}')">
            Hapus Data
          </button>` : ""}
      </div>
    `).join("")
    : '<p class="empty">Belum ada data kucing.</p>';

  $("jumlahKucing").textContent = tersedia.length;
}

// Hapus data kucing yang belum terjual
function hapusKucing(id) {
  const k = kucing.find(item => item.id === id);

  if (!k || k.terjual) return;

  if (confirm("Hapus data kucing " + k.nama + "?")) {
    kucing = kucing.filter(item => item.id !== id);
    simpanData();
    tampilkanSemua();
  }
}

// Tampilkan riwayat transaksi
function tampilkanTransaksi() {
  $("riwayatTransaksi").innerHTML = transaksi.length
    ? [...transaksi].reverse().map(t => `
      <div class="item">
        <strong>Transaksi #${aman(t.id.slice(-6))}</strong>
        <p>
          Tanggal: ${aman(t.tanggal)}<br>
          Pembeli: ${aman(t.namaPembeli)}<br>
          HP: ${aman(t.hpPembeli || "-")}<br>
          Kucing: ${aman(t.namaKucing)} (${aman(t.ras)})<br>
          Total: ${rupiah(t.harga)}<br>
          Dibayar: ${rupiah(t.dibayar)}<br>
          Kembalian: ${rupiah(t.kembalian)}<br>
          Status: Lunas
        </p>
        <button type="button"
          onclick="cetakBukti('${t.id}')">
          Cetak Bukti
        </button>
      </div>
    `).join("")
    : '<p class="empty">Belum ada transaksi.</p>';

  $("jumlahTransaksi").textContent = transaksi.length;

  const total = transaksi.reduce(
    (sum, t) => sum + t.harga, 0
  );

  $("totalPenjualan").textContent = rupiah(total);
}

function tampilkanSemua() {
  isiPilihanKucing();
  tampilkanKucing();
  tampilkanTransaksi();
}

// Cetak bukti transaksi tertentu
function cetakBukti(id) {
  const t = transaksi.find(item => item.id === id);
  if (!t) return;

  const jendela = window.open("", "_blank");

  if (!jendela) {
    alert("Izinkan pop-up browser untuk mencetak bukti.");
    return;
  }

  jendela.document.write(`
    <!DOCTYPE html>
    <html lang="id">
    <head>
      <meta charset="UTF-8">
      <title>Bukti Transaksi CAT SHOP</title>
      <style>
        body {
          font-family: Arial, sans-serif;
          padding: 24px;
          max-width: 500px;
          margin: auto;
        }
        h2, .center { text-align: center; }
        .line {
          border-top: 1px dashed #555;
          margin: 15px 0;
        }
        .row {
          display: flex;
          justify-content: space-between;
          gap: 12px;
          margin: 10px 0;
        }
        .row span:last-child {
          text-align: right;
        }
        @media print {
          button { display: none; }
        }
      </style>
    </head>
    <body>
      <h2>🐱 CAT SHOP</h2>
      <p class="center">BUKTI TRANSAKSI JUAL-BELI KUCING</p>
      <div class="line"></div>
      <p>No. transaksi: ${aman(t.id)}</p>
      <p>Tanggal: ${aman(t.tanggal)}</p>
      <p>Pembeli: ${aman(t.namaPembeli)}</p>
      <p>Nomor HP: ${aman(t.hpPembeli || "-")}</p>
      <div class="line"></div>
      <p>Nama kucing: ${aman(t.namaKucing)}</p>
      <p>Ras: ${aman(t.ras)}</p>
      <div class="line"></div>
      <div class="row">
        <span>Total harga</span>
        <span>${rupiah(t.harga)}</span>
      </div>
      <div class="row">
        <span>Uang dibayar</span>
        <span>${rupiah(t.dibayar)}</span>
      </div>
      <div class="row">
        <span>Kembalian</span>
        <span>${rupiah(t.kembalian)}</span>
      </div>
      <div class="line"></div>
      <p class="center">Terima kasih telah berbelanja.</p>
      <p class="center">Rawat kucing dengan penuh kasih sayang ❤️</p>
      <button onclick="window.print()">Cetak Bukti</button>
    </body>
    </html>
  `);

  jendela.document.close();
}

// Cetak halaman riwayat
function cetakRiwayat() {
  window.print();
}

tampilkanSemua();
