function showForm(formId) {
    // 1. Sembunyikan SEMUA elemen dengan class form-container
    const allForms = document.querySelectorAll('.form-container');
    allForms.forEach(f => f.style.display = 'none');

    // 2. Ambil elemen berdasarkan ID yang dikirim dari tombol
    const target = document.getElementById(formId);

    // 3. Cek apakah elemen ditemukan sebelum mencoba menampilkannya
    if (target) {
        target.style.display = 'block';
        target.scrollIntoView({ behavior: 'smooth' });
    } else {
        console.error("Form dengan ID " + formId + " tidak ditemukan!");
    }
}
