// Fungsi untuk membuka/menutup modal
function toggleAuth(show) {
    const modal = document.getElementById('authModal');
    
    if (modal) {
        modal.style.display = show ? 'block' : 'none';
        console.log("Modal berhasil diubah ke:", show ? 'tampil' : 'sembunyi');
    } else {
        // Pesan error ini membantu Anda saat coding
        console.error("Error: Elemen dengan id 'authModal' tidak ditemukan di HTML!");
    }
}


// Fungsi untuk menutup modal (digunakan tombol X)
function tutupModal() {
    toggleAuth(false);
}

// Fungsi pindah tab
function gantiTab(tipe) {
    const login = document.getElementById('formLogin');
    const daftar = document.getElementById('formDaftar');
    if (login && daftar) {
        login.style.display = (tipe === 'login') ? 'block' : 'none';
        daftar.style.display = (tipe === 'daftar') ? 'block' : 'none';
    }
}
// Fungsi untuk memproses pendaftaran
function prosesDaftar() {
    // Mengambil nilai dari input sesuai ID di HTML
    const user = document.getElementById('userReg').value;
    const email = document.getElementById('emailReg').value;
    const pass = document.getElementById('passReg').value;

    // Validasi sederhana agar input tidak kosong
    if (user === "" || email === "" || pass === "") {
        alert("Mohon isi semua kolom!");
        return;
    }

    // Menyimpan data ke localStorage
    // Kita gunakan kunci yang spesifik agar tidak tertimpa data lain
    localStorage.setItem('savedUser', user);
    localStorage.setItem('savedEmail', email);
    localStorage.setItem('savedPass', pass);

    alert("Pendaftaran berhasil! Silakan login.");

    // Setelah daftar, arahkan user kembali ke form login
    // Pastikan Anda sudah memiliki fungsi gantiTab('login')
    if (typeof gantiTab === 'function') {
        gantiTab('login');
    }
}
// Fungsi proses login
function prosesLogin() {
    const userIn = document.getElementById('userIn').value;
    const passIn = document.getElementById('passIn').value;
    const savedUser = localStorage.getItem('savedUser');
    const savedPass = localStorage.getItem('savedPass');

    if (userIn === savedUser && passIn === savedPass) {
        alert("Login Berhasil!");
        localStorage.setItem('isLoggedIn', 'true');
        toggleAuth(false);
        location.reload(); // Refresh halaman agar tombol Sign In hilang
    } else {
        alert("Username atau Password salah!");
    }
}

// Cek status saat halaman dimuat
window.onload = function() {
    const isLogin = localStorage.getItem('isLoggedIn');
    const btnAuth = document.getElementById('btnAuth');
    
    if (isLogin === 'true') {
        toggleAuth(false);
        if (btnAuth) btnAuth.style.display = 'none'; // Sembunyikan tombol Sign In
    } else {
        toggleAuth(true); // Tampilkan modal
        gantiTab('login');
    }
};
