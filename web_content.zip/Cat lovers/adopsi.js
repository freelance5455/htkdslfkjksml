function showForm(formId) {
    // 1. Ambil semua form dan sembunyikan semuanya
    const allForms = document.querySelectorAll('.form-container');
    allForms.forEach(form => {
        form.style.display = 'none';
    });

    // 2. Tampilkan form yang dipilih
    const selectedForm = document.getElementById(formId);
    if (selectedForm) {
        selectedForm.style.display = 'block';
        selectedForm.scrollIntoView({ behavior: 'smooth' });
    }
}
// Ambil elemen tombol close
const tombolTutup = document.querySelector('.close-btn'); // Sesuaikan class ini dengan HTML Anda

// Tambahkan event listener
tombolTutup.addEventListener('click', function() {
    tutupSemua();
});

function tutupSemua() {
    const allForms = document.querySelectorAll('.form-container');
    allForms.forEach(form => {
        form.style.display = 'none';
    });
}