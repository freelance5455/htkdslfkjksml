package com.minespace.game;

public class WorldGenerator {
    private float planetRadius = 100.0f;
    private BlockSystem blockSystem;

    public WorldGenerator(BlockSystem blockSystem) {
        this.blockSystem = blockSystem;
    }

    // Gezegenin tüm katmanlarını ve blok matrisini oluşturan ana nesil fonksiyonu
    public void generatePlanetWorld() {
        System.out.println("Minespace Dünya Üretimi (World Generation) Başlatıldı...");
        
        // Örnek olarak gezegen merkezinden dışarıya doğru katmanları ve blokları örüyoruz
        int steps = 10; // Katman adım çözünürlüğü
        for (int i = 0; i <= steps; i++) {
            float currentRadius = (planetRadius / steps) * i;
            BlockSystem.Block generatedBlock = blockSystem.generateBlockAtDepth(currentRadius, planetRadius);
            
            System.out.println("Mesafe: " + currentRadius + " birim | Oluşan Blok/Katman Türü: " + generatedBlock.type);
        }
        
        System.out.println("Gezegen Dünyası Başarıyla Oluşturuldu ve Bloklar Yerleştirildi!");
    }
}
