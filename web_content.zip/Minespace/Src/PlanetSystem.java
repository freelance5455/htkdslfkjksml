package com.minespace.game;

public class PlanetSystem {
    private float planetRadius = 100.0f;

    public String checkMiningLayer(float currentDepthFromCenter) {
        if (currentDepthFromCenter > planetRadius * 0.95f) {
            return "Çimen / Toprak (Yüzey)";
        } else if (currentDepthFromCenter > planetRadius * 0.80f) {
            return "Küçük Taşlı Toprak";
        } else if (currentDepthFromCenter > planetRadius * 0.55f) {
            return "Taş (Basit Madenler: Demir, Bakır)";
        } else if (currentDepthFromCenter > planetRadius * 0.30f) {
            return "Derin Taş (Ağır Elementler, Radyoaktif Madenler)";
        } else if (currentDepthFromCenter > planetRadius * 0.15f) {
            return "Magma Taşı";
        } else if (currentDepthFromCenter > planetRadius * 0.05f) {
            return "Lav Okyanusu";
        } else {
            return "Gezegen Çekirdeği";
        }
    }
}
