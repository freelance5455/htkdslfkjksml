package com.minespace.game;

public class PlayerController {
    private float speed = 5.0f;
    private float gravity = 9.8f;

    public void updatePosition(float posX, float posY, float posZ, boolean isGrounded) {
        if (!isGrounded) {
            posY -= gravity * 0.016f; 
        }
    }
}
