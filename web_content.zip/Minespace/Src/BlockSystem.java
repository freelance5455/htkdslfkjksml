package com.minespace.game;

public class BlockSystem {
    public enum BlockType {
        AIR, GRASS, SOIL, SMALL_STONE, STONE, DEEPSTONE, MAGMA_STONE, LAVA, CORE
    }

    public static class Block {
        public BlockType type;
        public int health;
        public boolean isBreakable;

        public Block(BlockType type, int health, boolean isBreakable) {
            this.type = type;
            this.health = health;
            this.isBreakable = isBreakable;
        }
    }

    // Kazılan bloğu derinliğe göre otomatik oluşturan fonksiyon
    public Block generateBlockAtDepth(float depthFromCenter, float maxRadius) {
        float ratio = depthFromCenter / maxRadius;

        if (ratio > 0.95f) return new Block(BlockType.GRASS, 10, true);
        else if (ratio > 0.80f) return new Block(BlockType.SOIL, 15, true);
        else if (ratio > 0.55f) return new Block(BlockType.SMALL_STONE, 25, true);
        else if (ratio > 0.30f) return new Block(BlockType.STONE, 50, true); // Demir/Bakır çıkar
        else if (ratio > 0.15f) return new Block(BlockType.DEEPSTONE, 100, true); // Radyoaktif madenler
        else if (ratio > 0.05f) return new Block(BlockType.MAGMA_STONE, 200, true);
        else if (ratio > 0.01f) return new Block(BlockType.LAVA, 0, false); // Kırılamaz sıvı
        else return new Block(BlockType.CORE, 9999, false); // Kırılamaz Çekirdek
    }

    // Blok kırma mekaniği
    public boolean breakBlock(Block block, int damage) {
        if (!block.isBreakable) return false;
        
        block.health -= damage;
        return block.health <= 0; // True dönerse blok yok olur ve envantere düşer
    }
}
