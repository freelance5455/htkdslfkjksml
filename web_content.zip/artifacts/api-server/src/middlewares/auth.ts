import { getAuth } from "@clerk/express";
import type { NextFunction, Request, Response } from "express";
import { db, usersTable, type User } from "@workspace/db";
import { eq } from "drizzle-orm";

export type AuthenticatedRequest = Request & {
  userId: string;
  dbUser?: User;
};

export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const userId = getAuth(req).userId;
  if (!userId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  (req as AuthenticatedRequest).userId = userId;
  next();
}

export async function getOrCreateUser(clerkUserId: string): Promise<User> {
  const existing = await db.select().from(usersTable).where(eq(usersTable.clerkUserId, clerkUserId)).limit(1);
  if (existing[0]) {
    await db.update(usersTable).set({ updatedAt: new Date() }).where(eq(usersTable.id, existing[0].id));
    return existing[0];
  }

  const inserted = await db.insert(usersTable).values({ clerkUserId }).returning();
  if (!inserted[0]) throw new Error("Could not create user profile");
  return inserted[0];
}