import { randomUUID } from "node:crypto";

const SIDECAR_ENDPOINT = "http://127.0.0.1:1106";

function parseObjectPath(value: string) {
  const normalized = value.startsWith("/") ? value : `/${value}`;
  const parts = normalized.split("/");
  if (parts.length < 3 || !parts[1] || !parts.slice(2).join("/")) {
    throw new Error("Invalid object storage path");
  }
  return { bucketName: parts[1], objectName: parts.slice(2).join("/") };
}

async function signObjectUrl({
  bucketName,
  objectName,
  method,
  ttlSec,
}: {
  bucketName: string;
  objectName: string;
  method: "GET" | "PUT";
  ttlSec: number;
}) {
  const response = await fetch(`${SIDECAR_ENDPOINT}/object-storage/signed-object-url`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      bucket_name: bucketName,
      object_name: objectName,
      method,
      expires_at: new Date(Date.now() + ttlSec * 1000).toISOString(),
    }),
    signal: AbortSignal.timeout(30_000),
  });
  if (!response.ok) {
    throw new Error(`Failed to sign object URL (${response.status})`);
  }
  const body = (await response.json()) as { signed_url?: string };
  if (!body.signed_url) throw new Error("Object storage did not return a signed URL");
  return body.signed_url;
}

export class ObjectStorageService {
  private getPrivateDir() {
    const value = process.env.PRIVATE_OBJECT_DIR;
    if (!value) throw new Error("PRIVATE_OBJECT_DIR is not configured");
    return value.replace(/\/+$/, "");
  }

  async createPosterUpload() {
    const objectId = randomUUID();
    const objectPath = `/objects/uploads/${objectId}`;
    const { bucketName, objectName } = parseObjectPath(`${this.getPrivateDir()}/uploads/${objectId}`);
    const uploadURL = await signObjectUrl({ bucketName, objectName, method: "PUT", ttlSec: 900 });
    return { uploadURL, objectPath };
  }

  async getPosterDownloadUrl(objectPath: string) {
    if (!/^\/objects\/uploads\/[0-9a-f-]{36}$/i.test(objectPath)) {
      throw new Error("Invalid poster path");
    }
    const objectName = objectPath.slice("/objects/".length);
    const { bucketName } = parseObjectPath(this.getPrivateDir());
    const privateDir = this.getPrivateDir().split("/").slice(2).join("/");
    const fullObjectName = `${privateDir}/${objectName}`;
    return signObjectUrl({ bucketName, objectName: fullObjectName, method: "GET", ttlSec: 900 });
  }
}

export const objectStorageService = new ObjectStorageService();