import { Router, type IRouter } from "express";
import { and, desc, eq, inArray, isNull, ne, or } from "drizzle-orm";
import {
  CancelAppointmentParams,
  CancelAppointmentResponse,
  CreateAppointmentBody,
  CreateAppointmentResponse,
  GetPatientDashboardResponse,
  GetProfessionalDashboardResponse,
  ListAppointmentsQueryParams,
  ListAppointmentsResponse,
  MockCheckoutBody,
  MockCheckoutResponse,
} from "@workspace/api-zod";
import {
  db,
} from "@workspace/db";
import {
  availabilityTable,
  appointmentsTable,
  conversationsTable,
  messagesTable,
  notificationsTable,
  paymentsTable,
  professionalsTable,
  usersTable,
} from "@workspace/db/schema";
import { getLocalUser, requireSessionUser } from "../lib/request-auth";

const router: IRouter = Router();

function toAppointment(
  appointment: typeof appointmentsTable.$inferSelect,
  patientName: string,
  professionalName: string,
) {
  return {
    ...appointment,
    id: appointment.id,
    startsAt: appointment.startsAt.toISOString(),
    createdAt: appointment.createdAt.toISOString(),
    amount: Number(appointment.amount),
    notes: appointment.notes,
    patientName,
    professionalName,
  };
}

async function appointmentsForUser(userId: string, status?: string) {
  const rows = await db
    .select()
    .from(appointmentsTable)
    .where(
      and(
        or(
          eq(appointmentsTable.patientId, userId),
          eq(appointmentsTable.professionalId, userId),
        ),
        status
          ? eq(
              appointmentsTable.status,
              status as "PENDING" | "CONFIRMED" | "COMPLETED" | "CANCELLED",
            )
          : undefined,
      ),
    )
    .orderBy(desc(appointmentsTable.startsAt));
  if (rows.length === 0) return [];
  const personIds = Array.from(
    new Set(rows.flatMap((row) => [row.patientId, row.professionalId])),
  );
  const people = await db
    .select({ id: usersTable.id, fullName: usersTable.fullName })
    .from(usersTable)
    .where(inArray(usersTable.id, personIds));
  const names = new Map(people.map((person) => [person.id, person.fullName]));
  return rows.map((row) =>
    toAppointment(
      row,
      names.get(row.patientId) ?? "Patient",
      names.get(row.professionalId) ?? "Professional",
    ),
  );
}

router.get("/appointments", async (req, res): Promise<void> => {
  const userId = requireSessionUser(req, res);
  if (!userId) return;
  const query = ListAppointmentsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const appointments = await appointmentsForUser(userId, query.data.status);
  res.json(ListAppointmentsResponse.parse(appointments));
});

router.post("/appointments", async (req, res): Promise<void> => {
  const userId = requireSessionUser(req, res);
  if (!userId) return;
  const body = CreateAppointmentBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const patient = await getLocalUser(userId);
  if (!patient || patient.role !== "PATIENT") {
    res.status(403).json({ error: "Only patient accounts can book visits" });
    return;
  }
  const [professional] = await db
    .select({
      id: professionalsTable.userId,
      price: professionalsTable.consultationPrice,
      currency: professionalsTable.currency,
      name: usersTable.fullName,
    })
    .from(professionalsTable)
    .innerJoin(usersTable, eq(usersTable.id, professionalsTable.userId))
    .where(
      and(
        eq(professionalsTable.userId, body.data.professionalId),
        eq(professionalsTable.verificationStatus, "APPROVED"),
      ),
    )
    .limit(1);
  if (!professional) {
    res.status(404).json({ error: "Professional not found or not approved" });
    return;
  }
  const startsAt = new Date(body.data.startsAt);
  if (!Number.isFinite(startsAt.getTime()) || startsAt <= new Date()) {
    res.status(400).json({ error: "Choose a future appointment time" });
    return;
  }
  if (body.data.currency !== professional.currency) {
    res.status(400).json({ error: "Appointment currency must match the professional's listed currency" });
    return;
  }
  const requestedMinute = startsAt.getUTCHours() * 60 + startsAt.getUTCMinutes();
  const schedules = await db
    .select()
    .from(availabilityTable)
    .where(eq(availabilityTable.professionalId, professional.id));
  const matchesSchedule = schedules.some((entry) => {
    const [startHour, startMinute] = entry.startTime.split(":").map(Number);
    const [endHour, endMinute] = entry.endTime.split(":").map(Number);
    const scheduleStart = startHour * 60 + startMinute;
    const scheduleEnd = endHour * 60 + endMinute;
    const offset = requestedMinute - scheduleStart;
    return (
      entry.dayOfWeek === startsAt.getUTCDay() &&
      offset >= 0 &&
      offset % entry.slotMinutes === 0 &&
      body.data.durationMinutes <= entry.slotMinutes &&
      requestedMinute + body.data.durationMinutes <= scheduleEnd
    );
  });
  if (!matchesSchedule) {
    res.status(400).json({ error: "Choose an available appointment slot" });
    return;
  }

  const overlapCandidates = await db
    .select({
      startsAt: appointmentsTable.startsAt,
      durationMinutes: appointmentsTable.durationMinutes,
      status: appointmentsTable.status,
    })
    .from(appointmentsTable)
    .where(
      and(
        eq(appointmentsTable.professionalId, professional.id),
        ne(appointmentsTable.status, "CANCELLED"),
      ),
    );
  const requestedEnd = startsAt.getTime() + body.data.durationMinutes * 60_000;
  const slotTaken = overlapCandidates.some((candidate) => {
    const existingStart = candidate.startsAt.getTime();
    const existingEnd =
      existingStart + candidate.durationMinutes * 60_000;
    return startsAt.getTime() < existingEnd && requestedEnd > existingStart;
  });
  if (slotTaken) {
    res.status(409).json({ error: "That appointment time is no longer available" });
    return;
  }

  const appointmentId = `DL-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
  const [appointment] = await db.transaction(async (tx) => {
    const [created] = await tx
      .insert(appointmentsTable)
      .values({
        appointmentId,
        patientId: userId,
        professionalId: professional.id,
        startsAt,
        durationMinutes: body.data.durationMinutes,
        consultationType: body.data.consultationType,
        status: "PENDING",
        amount: Number(professional.price),
        currency: professional.currency,
        paymentStatus: "PENDING",
        notes: body.data.notes?.trim() ?? null,
      })
      .returning();
    await tx
      .insert(conversationsTable)
      .values({ patientId: userId, professionalId: professional.id })
      .onConflictDoNothing();
    await tx.insert(paymentsTable).values({
      appointmentId: created.id,
      amount: Number(professional.price),
      currency: professional.currency,
      status: "PENDING",
      provider: "MOCK",
    });
    await tx.insert(notificationsTable).values([
      {
        userId,
        kind: "BOOKING_CREATED",
        title: "Appointment requested",
        body: `Your request to meet ${professional.name} is pending confirmation.`,
        relatedAppointmentId: created.id,
      },
      {
        userId: professional.id,
        kind: "BOOKING_CREATED",
        title: "New appointment request",
        body: `${patient.fullName} requested a consultation.`,
        relatedAppointmentId: created.id,
      },
    ]);
    return [created];
  });
  res.status(201).json(
    CreateAppointmentResponse.parse(
      toAppointment(appointment, patient.fullName, professional.name),
    ),
  );
});

router.post("/appointments/:appointmentId/cancel", async (req, res): Promise<void> => {
  const userId = requireSessionUser(req, res);
  if (!userId) return;
  const params = CancelAppointmentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [appointment] = await db
    .select()
    .from(appointmentsTable)
    .where(eq(appointmentsTable.id, params.data.appointmentId))
    .limit(1);
  if (
    !appointment ||
    (appointment.patientId !== userId &&
      appointment.professionalId !== userId &&
      (await getLocalUser(userId))?.role !== "ADMIN")
  ) {
    res.status(404).json({ error: "Appointment not found" });
    return;
  }
  if (appointment.status === "COMPLETED" || appointment.status === "CANCELLED") {
    res.status(409).json({ error: "This appointment can no longer be cancelled" });
    return;
  }
  const [updated] = await db
    .update(appointmentsTable)
    .set({ status: "CANCELLED" })
    .where(eq(appointmentsTable.id, appointment.id))
    .returning();
  const recipientId =
    userId === appointment.patientId
      ? appointment.professionalId
      : appointment.patientId;
  await db.insert(notificationsTable).values({
    userId: recipientId,
    kind: "APPOINTMENT_CANCELLED",
    title: "Appointment cancelled",
    body: `Appointment ${appointment.appointmentId} was cancelled.`,
    relatedAppointmentId: appointment.id,
  });
  const people = await db
    .select({ id: usersTable.id, fullName: usersTable.fullName })
    .from(usersTable)
    .where(
      inArray(usersTable.id, [appointment.patientId, appointment.professionalId]),
    );
  const names = new Map(people.map((person) => [person.id, person.fullName]));
  res.json(
    CancelAppointmentResponse.parse(
      toAppointment(
        updated,
        names.get(appointment.patientId) ?? "Patient",
        names.get(appointment.professionalId) ?? "Professional",
      ),
    ),
  );
});

router.get("/dashboard/patient", async (req, res): Promise<void> => {
  const userId = requireSessionUser(req, res);
  if (!userId) return;
  const user = await getLocalUser(userId);
  if (!user || user.role !== "PATIENT") {
    res.status(403).json({ error: "Patient account required" });
    return;
  }
  const appointments = await appointmentsForUser(userId);
  const now = new Date();
  const upcoming = appointments.filter(
    (appointment) =>
      (appointment.status === "PENDING" ||
        appointment.status === "CONFIRMED") &&
      new Date(appointment.startsAt) >= now,
  );
  const [conversations] = await db
    .select({ ids: conversationsTable.id })
    .from(conversationsTable)
    .where(eq(conversationsTable.patientId, userId));
  const conversationRows = await db
    .select({ id: conversationsTable.id })
    .from(conversationsTable)
    .where(eq(conversationsTable.patientId, userId));
  const unread = conversationRows.length
    ? await db
        .select({ id: messagesTable.id })
        .from(messagesTable)
        .where(
          and(
            inArray(
              messagesTable.conversationId,
              conversationRows.map((row) => row.id),
            ),
            ne(messagesTable.senderId, userId),
            isNull(messagesTable.readAt),
          ),
        )
    : [];
  const alerts = await db
    .select()
    .from(notificationsTable)
    .where(eq(notificationsTable.userId, userId))
    .orderBy(desc(notificationsTable.createdAt))
    .limit(5);
  const completedCount = appointments.filter(
    (appointment) => appointment.status === "COMPLETED",
  ).length;
  res.json(
    GetPatientDashboardResponse.parse({
      upcomingCount: upcoming.length,
      completedCount,
      unreadMessages: unread.length,
      nextAppointment: upcoming[0] ?? null,
      appointments: appointments.slice(0, 5),
      notifications: alerts.map((alert) => ({
        ...alert,
        createdAt: alert.createdAt.toISOString(),
        isRead: alert.readAt !== null,
      })),
    }),
  );
});

router.get("/dashboard/professional", async (req, res): Promise<void> => {
  const userId = requireSessionUser(req, res);
  if (!userId) return;
  const user = await getLocalUser(userId);
  if (
    !user ||
    !["DOCTOR", "NURSE", "SPECIALIST", "ADMIN"].includes(user.role)
  ) {
    res.status(403).json({ error: "Professional account required" });
    return;
  }
  const appointments = await appointmentsForUser(userId);
  const start = new Date();
  start.setUTCHours(0, 0, 0, 0);
  const tomorrow = new Date(start.getTime() + 86_400_000);
  const todayCount = appointments.filter(
    (appointment) =>
      appointment.professionalId === userId &&
      new Date(appointment.startsAt) >= start &&
      new Date(appointment.startsAt) < tomorrow &&
      appointment.status !== "CANCELLED",
  ).length;
  const future = appointments.filter(
    (appointment) =>
      appointment.professionalId === userId &&
      new Date(appointment.startsAt) >= new Date() &&
      appointment.status !== "CANCELLED",
  );
  const patientCount = new Set(
    appointments
      .filter((appointment) => appointment.professionalId === userId)
      .map((appointment) => appointment.patientId),
  ).size;
  const [professional] = await db
    .select({
      rating: professionalsTable.rating,
      currency: professionalsTable.currency,
    })
    .from(professionalsTable)
    .where(eq(professionalsTable.userId, userId))
    .limit(1);
  const paidRows = await db
    .select({ amount: appointmentsTable.amount })
    .from(appointmentsTable)
    .where(
      and(
        eq(appointmentsTable.professionalId, userId),
        eq(appointmentsTable.paymentStatus, "DEMO_PAID"),
      ),
    );
  res.json(
    GetProfessionalDashboardResponse.parse({
      todayCount,
      upcomingCount: future.length,
      patientCount,
      earnings: paidRows.reduce((sum, row) => sum + Number(row.amount), 0),
      currency: professional?.currency ?? "DZD",
      rating: Number(professional?.rating ?? 0),
      appointments: future.slice(0, 8),
    }),
  );
});

router.post("/payments/mock-checkout", async (req, res): Promise<void> => {
  const userId = requireSessionUser(req, res);
  if (!userId) return;
  const body = MockCheckoutBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const [appointment] = await db
    .select()
    .from(appointmentsTable)
    .where(eq(appointmentsTable.id, body.data.appointmentId))
    .limit(1);
  if (!appointment || appointment.patientId !== userId) {
    res.status(404).json({ error: "Appointment not found" });
    return;
  }
  if (appointment.status === "CANCELLED") {
    res.status(409).json({ error: "Cancelled appointments cannot be paid" });
    return;
  }
  if (body.data.currency !== appointment.currency) {
    res.status(400).json({ error: "Payment currency must match the appointment currency" });
    return;
  }
  const [payment] = await db
    .insert(paymentsTable)
    .values({
      appointmentId: appointment.id,
      amount: Number(appointment.amount),
      currency: appointment.currency,
      status: "DEMO_PAID",
      provider: "MOCK",
    })
    .onConflictDoUpdate({
      target: paymentsTable.appointmentId,
      set: { status: "DEMO_PAID", currency: appointment.currency },
    })
    .returning();
  const [updated] = await db
    .update(appointmentsTable)
    .set({
      paymentStatus: "DEMO_PAID",
      status:
        appointment.status === "PENDING" ? "CONFIRMED" : appointment.status,
    })
    .where(eq(appointmentsTable.id, appointment.id))
    .returning();
  res.json(
    MockCheckoutResponse.parse({
      id: payment.id,
      appointmentId: updated.id,
      amount: Number(payment.amount),
      currency: payment.currency,
      status: payment.status,
      provider: "MOCK",
      isDemo: true,
    }),
  );
});

export default router;
