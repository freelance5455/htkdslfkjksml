import { Router, type IRouter } from "express";
import {
  ConnectPlatformParams, CreateBotBody, CreateKnowledgeBody, CreateRuleBody, DeleteBotParams,
  DeleteKnowledgeParams, DeleteRuleParams, GetBotParams, TestBotBody, TestBotParams,
  UpdateBotBody, UpdateBotParams, UpdateKnowledgeBody, UpdateKnowledgeParams, UpdateRuleBody, UpdateRuleParams,
} from "@workspace/api-zod";
import { addActivity, createId, store } from "./memo-data";

const router: IRouter = Router();

router.get("/dashboard", (_req, res) => {
  const messages = store.bots.reduce((sum, bot) => sum + bot.messages, 0);
  const replyRate = Math.round(store.bots.reduce((sum, bot) => sum + bot.replyRate, 0) / store.bots.length);
  res.json({ stats: { bots: store.bots.length, messages, replyRate, connectedPlatforms: store.platforms.filter((p) => p.status === "connected").length }, trends: [{ label: "السبت", value: 182 }, { label: "الأحد", value: 248 }, { label: "الإثنين", value: 224 }, { label: "الثلاثاء", value: 310 }, { label: "الأربعاء", value: 286 }, { label: "الخميس", value: 354 }, { label: "اليوم", value: 412 }], activeBot: store.bots.find((bot) => bot.status === "running")?.id ?? null });
});

router.get("/bots", (_req, res) => res.json(store.bots));
router.post("/bots", (req, res) => {
  const parsed = CreateBotBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "تحقق من البيانات المدخلة قبل الحفظ." });
  const bot = { id: createId("bot"), ...parsed.data, image: parsed.data.image ?? null, status: "draft" as const, messages: 0, replyRate: 0, updatedAt: new Date().toISOString() };
  store.bots.unshift(bot);
  addActivity("تم إنشاء بوت جديد", bot.name);
  res.status(201).json(bot);
});
router.get("/bots/:id", (req, res) => {
  const parsed = GetBotParams.safeParse(req.params);
  const bot = store.bots.find((item) => item.id === parsed.data?.id);
  if (!bot) return res.status(404).json({ error: "البوت غير موجود." });
  res.json(bot);
});
router.patch("/bots/:id", (req, res) => {
  const params = UpdateBotParams.safeParse(req.params);
  const body = UpdateBotBody.safeParse(req.body);
  const bot = store.bots.find((item) => item.id === params.data?.id);
  if (!params.success || !body.success || !bot) return res.status(400).json({ error: "تعذر تحديث البوت." });
  Object.assign(bot, body.data, { updatedAt: new Date().toISOString() });
  addActivity("تم تحديث إعدادات البوت", bot.name);
  res.json(bot);
});
router.delete("/bots/:id", (req, res) => {
  const parsed = DeleteBotParams.safeParse(req.params);
  const index = store.bots.findIndex((item) => item.id === parsed.data?.id);
  if (index < 0) return res.status(404).json({ error: "البوت غير موجود." });
  const [bot] = store.bots.splice(index, 1);
  addActivity("تم حذف بوت", bot.name, "bot", "neutral");
  res.status(204).send();
});
router.post("/bots/:id/toggle", (req, res) => {
  const bot = store.bots.find((item) => item.id === req.params.id);
  if (!bot) return res.status(404).json({ error: "البوت غير موجود." });
  bot.status = bot.status === "running" ? "paused" : "running";
  bot.updatedAt = new Date().toISOString();
  addActivity(bot.status === "running" ? "تم تشغيل البوت" : "تم إيقاف البوت", bot.name);
  res.json(bot);
});
router.post("/bots/:id/test", (req, res) => {
  const params = TestBotParams.safeParse(req.params);
  const body = TestBotBody.safeParse(req.body);
  const bot = store.bots.find((item) => item.id === params.data?.id);
  if (!params.success || !body.success || !bot) return res.status(400).json({ error: "تعذر اختبار البوت." });
  const rule = store.rules.find((item) => item.botId === bot.id && item.active && body.data.message.toLowerCase().includes(item.trigger.split("|")[0].trim().toLowerCase()));
  const reply = rule?.response ?? `مرحبًا، أنا ${bot.name.split("—")[0].trim()}. لم أفهم طلبك بالكامل بعد، لكن يمكنني مساعدتك في الخدمات والأسعار ومواعيد العمل.`;
  if (rule) rule.matches += 1;
  res.json({ message: body.data.message, reply, matchedRule: rule?.trigger ?? null, createdAt: new Date().toISOString() });
});

router.get("/rules", (_req, res) => res.json(store.rules));
router.post("/rules", (req, res) => {
  const body = CreateRuleBody.safeParse(req.body);
  if (!body.success) return res.status(400).json({ error: "أدخل الكلمة والرد المطلوب." });
  const rule = { id: createId("rule"), ...body.data, matches: 0, active: body.data.active ?? true };
  store.rules.unshift(rule);
  addActivity("تمت إضافة قاعدة رد جديدة", rule.trigger);
  res.status(201).json(rule);
});
router.patch("/rules/:id", (req, res) => {
  const body = UpdateRuleBody.safeParse(req.body);
  const rule = store.rules.find((item) => item.id === req.params.id);
  if (!body.success || !rule) return res.status(400).json({ error: "تعذر تحديث القاعدة." });
  Object.assign(rule, body.data);
  res.json(rule);
});
router.delete("/rules/:id", (req, res) => {
  const parsed = DeleteRuleParams.safeParse(req.params);
  const index = store.rules.findIndex((item) => item.id === parsed.data?.id);
  if (index < 0) return res.status(404).json({ error: "القاعدة غير موجودة." });
  store.rules.splice(index, 1);
  res.status(204).send();
});

router.get("/knowledge", (_req, res) => res.json(store.knowledge));
router.post("/knowledge", (req, res) => {
  const body = CreateKnowledgeBody.safeParse(req.body);
  if (!body.success) return res.status(400).json({ error: "أدخل عنوان ومحتوى المعرفة." });
  const entry = { id: createId("kb"), ...body.data, updatedAt: new Date().toISOString() };
  store.knowledge.unshift(entry);
  addActivity("تمت إضافة معرفة جديدة", entry.title);
  res.status(201).json(entry);
});
router.patch("/knowledge/:id", (req, res) => {
  const params = UpdateKnowledgeParams.safeParse(req.params);
  const body = UpdateKnowledgeBody.safeParse(req.body);
  const entry = store.knowledge.find((item) => item.id === params.data?.id);
  if (!params.success || !body.success || !entry) return res.status(400).json({ error: "تعذر تحديث المعرفة." });
  Object.assign(entry, body.data, { updatedAt: new Date().toISOString() });
  res.json(entry);
});
router.delete("/knowledge/:id", (req, res) => {
  const parsed = DeleteKnowledgeParams.safeParse(req.params);
  const index = store.knowledge.findIndex((item) => item.id === parsed.data?.id);
  if (index < 0) return res.status(404).json({ error: "المعلومة غير موجودة." });
  store.knowledge.splice(index, 1);
  res.status(204).send();
});

router.get("/conversations", (_req, res) => res.json(store.conversations));
router.get("/activity", (_req, res) => res.json(store.activity));
router.get("/platforms", (_req, res) => res.json(store.platforms));
router.post("/platforms/:id/connect", (req, res) => {
  const params = ConnectPlatformParams.safeParse(req.params);
  const platform = store.platforms.find((item) => item.id === params.data?.id);
  if (!platform) return res.status(404).json({ error: "المنصة غير موجودة." });
  platform.status = "connected";
  addActivity(`تم ربط ${platform.name}`, "تم إنشاء اتصال رسمي ويمكن إدارة الصلاحيات من إعدادات المنصة.", "connection");
  res.json(platform);
});
router.get("/settings", (_req, res) => res.json(store.settings));
router.patch("/settings", (req, res) => {
  Object.assign(store.settings, req.body);
  addActivity("تم حفظ إعدادات الحساب", "تم تحديث تفضيلات الحساب والذكاء الاصطناعي.", "settings");
  res.json(store.settings);
});
router.get("/admin/overview", (_req, res) => res.json({ users: 128, bots: store.bots.length + 46, errors: 3, uptime: "99.98%" }));

export default router;