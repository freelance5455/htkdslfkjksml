import { Router, type IRouter } from "express";
import { and, count, eq, sql } from "drizzle-orm";
import {
  GetAdminOverviewResponse,
  ListPendingProfessionalsResponse,
  UpdateProfessionalApprovalBody,
  UpdateProfessionalApprovalParams,
  UpdateProfessionalApprovalResponse,
} from "@workspace/api-zod";
import {
} from "@workspace/db";
import { db } from "@workspace/db";
import {
  appointmentsTable,
  notificationsTable,
  paymentsTable,
  professionalsTable,
  usersTable,
} from "@workspace/db/schema";
import { getLocalUser, requireSessionUser } from "../lib/request-auth";

const router: IRouter = Router();

async function requireAdmin(userId: string) {
  const user = await getLocalUser(userId);
  return user?.role === "ADMIN";
}

router.get("/admin/overview", async (req, res): Promise<void> => {
  const userId = requireSessionUser(req, res);
  if (!userId) return;
  if (!(await requireAdmin(userId))) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }
  const [[users], [patients], [professionals], [pending], [appointments], [revenue]] =
    await Promise.all([
      db.select({ value: count() }).from(usersTable),
      db
        .select({ value: count() })
        .from(usersTable)
        .where(eq(usersTable.role, "PATIENT")),
      db.select({ value: count() }).from(professionalsTable),
      db
        .select({ value: count() })
        .from(professionalsTable)
        .where(eq(professionalsTable.verificationStatus, "PENDING")),
      db.select({ value: count() }).from(appointmentsTable),
      db
        .select({
          value: sql<number>`coalesce(sum(${paymentsTable.amount}), 0)`.mapWith(
            Number,
          ),
        })
        .from(paymentsTable)
        .where(
          and(
            eq(paymentsTable.status, "DEMO_PAID"),
            eq(paymentsTable.currency, "DZD"),
          ),
        ),
    ]);
  res.json(
    GetAdminOverviewResponse.parse({
      users: users.value,
      patients: patients.value,
      professionals: professionals.value,
      pendingProfessionals: pending.value,
      appointments: appointments.value,
      revenue: revenue.value,
    }),
  );
});

router.get("/admin/professionals", async (req, res): Promise<void> => {
  const userId = requireSessionUser(req, res);
  if (!userId) return;
  if (!(await requireAdmin(userId))) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }
  const rows = await db
    .select({
      id: professionalsTable.userId,
      fullName: usersTable.fullName,
      role: usersTable.role,
      specialty: professionalsTable.specialty,
      experienceYears: professionalsTable.experienceYears,
      languages: professionalsTable.languages,
      consultationPrice: professionalsTable.consultationPrice,
      currency: professionalsTable.currency,
      rating: professionalsTable.rating,
      reviewCount: professionalsTable.reviewCount,
      imageUrl: professionalsTable.imageUrl,
      gender: usersTable.gender,
      verificationStatus: professionalsTable.verificationStatus,
    })
    .from(professionalsTable)
    .innerJoin(usersTable, eq(usersTable.id, professionalsTable.userId))
    .where(eq(professionalsTable.verificationStatus, "PENDING"));
  res.json(
    ListPendingProfessionalsResponse.parse(
      rows.map((row) => ({
        ...row,
        role: row.role as "DOCTOR" | "NURSE" | "SPECIALIST",
        consultationPrice: Number(row.consultationPrice),
        rating: Number(row.rating),
        imageUrl: row.imageUrl ?? "",
        gender: row.gender ?? "prefer_not_to_say",
        nextAvailableAt: null,
      })),
    ),
  );
});

router.patch(
  "/admin/professionals/:professionalId/approval",
  async (req, res): Promise<void> => {
    const userId = requireSessionUser(req, res);
    if (!userId) return;
    if (!(await requireAdmin(userId))) {
      res.status(403).json({ error: "Admin access required" });
      return;
    }
    const params = UpdateProfessionalApprovalParams.safeParse(req.params);
    const body = UpdateProfessionalApprovalBody.safeParse(req.body);
    if (!params.success || !body.success) {
      res.status(400).json({
        error: !params.success
          ? params.error.message
          : !body.success
            ? body.error.message
            : "Invalid request",
      });
      return;
    }
    const [updated] = await db
      .update(professionalsTable)
      .set({ verificationStatus: body.data.status })
      .where(eq(professionalsTable.userId, params.data.professionalId))
      .returning();
    if (!updated) {
      res.status(404).json({ error: "Professional application not found" });
      return;
    }
    const [person] = await db
      .select({
        fullName: usersTable.fullName,
        role: usersTable.role,
        gender: usersTable.gender,
      })
      .from(usersTable)
      .where(eq(usersTable.id, updated.userId))
      .limit(1);
    await db.insert(notificationsTable).values({
      userId: updated.userId,
      kind: "PROFESSIONAL_APPLICATION",
      title:
        body.data.status === "APPROVED"
          ? "Professional profile approved"
          : "Professional application update",
      body:
        body.data.status === "APPROVED"
          ? "Your profile is now visible in the صحتي directory."
          : "Your professional application was not approved. Please contact support for details.",
    });
    res.json(
      UpdateProfessionalApprovalResponse.parse({
        id: updated.userId,
        fullName: person?.fullName ?? "",
        role: (person?.role ?? "DOCTOR") as "DOCTOR" | "NURSE" | "SPECIALIST",
        specialty: updated.specialty,
        experienceYears: updated.experienceYears,
        languages: updated.languages,
        consultationPrice: Number(updated.consultationPrice),
        currency: updated.currency,
        rating: Number(updated.rating),
        reviewCount: updated.reviewCount,
        imageUrl: updated.imageUrl ?? "",
        gender: person?.gender ?? "prefer_not_to_say",
        verificationStatus: updated.verificationStatus,
        nextAvailableAt: null,
      }),
    );
  },
);

export default router;
