import { Router, type IRouter } from "express";
import { and, asc, desc, eq, isNull, ne, or } from "drizzle-orm";
import {
  ListConversationsResponse,
  ListMessagesParams,
  ListMessagesResponse,
  SendMessageBody,
  SendMessageParams,
  SendMessageResponse,
} from "@workspace/api-zod";
import {
  db,
} from "@workspace/db";
import {
  conversationsTable,
  messagesTable,
  notificationsTable,
  usersTable,
} from "@workspace/db/schema";
import { getLocalUser, requireSessionUser } from "../lib/request-auth";

const router: IRouter = Router();

router.get("/conversations", async (req, res): Promise<void> => {
  const userId = requireSessionUser(req, res);
  if (!userId) return;
  const rows = await db
    .select()
    .from(conversationsTable)
    .where(
      or(
        eq(conversationsTable.patientId, userId),
        eq(conversationsTable.professionalId, userId),
      ),
    )
    .orderBy(desc(conversationsTable.updatedAt));

  const conversations = await Promise.all(
    rows.map(async (conversation) => {
      const counterpartId =
        conversation.patientId === userId
          ? conversation.professionalId
          : conversation.patientId;
      const counterpart = await getLocalUser(counterpartId);
      const [lastMessage] = await db
        .select({ content: messagesTable.content })
        .from(messagesTable)
        .where(eq(messagesTable.conversationId, conversation.id))
        .orderBy(desc(messagesTable.sentAt))
        .limit(1);
      const unread = await db
        .select({ id: messagesTable.id })
        .from(messagesTable)
        .where(
          and(
            eq(messagesTable.conversationId, conversation.id),
            ne(messagesTable.senderId, userId),
            isNull(messagesTable.readAt),
          ),
        );
      return {
        id: conversation.id,
        counterpartId,
        counterpartName: counterpart?.fullName ?? "صحتي member",
        counterpartRole: counterpart?.role ?? "PATIENT",
        lastMessage: lastMessage?.content ?? null,
        updatedAt: conversation.updatedAt.toISOString(),
        unreadCount: unread.length,
      };
    }),
  );
  res.json(ListConversationsResponse.parse(conversations));
});

router.get(
  "/conversations/:conversationId/messages",
  async (req, res): Promise<void> => {
    const userId = requireSessionUser(req, res);
    if (!userId) return;
    const params = ListMessagesParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const [conversation] = await db
      .select()
      .from(conversationsTable)
      .where(eq(conversationsTable.id, params.data.conversationId))
      .limit(1);
    if (
      !conversation ||
      (conversation.patientId !== userId &&
        conversation.professionalId !== userId)
    ) {
      res.status(404).json({ error: "Conversation not found" });
      return;
    }
    await db
      .update(messagesTable)
      .set({ readAt: new Date() })
      .where(
        and(
          eq(messagesTable.conversationId, conversation.id),
          ne(messagesTable.senderId, userId),
          isNull(messagesTable.readAt),
        ),
      );
    const rows = await db
      .select({
        id: messagesTable.id,
        conversationId: messagesTable.conversationId,
        senderId: messagesTable.senderId,
        senderName: usersTable.fullName,
        content: messagesTable.content,
        sentAt: messagesTable.sentAt,
        isRead: messagesTable.readAt,
        attachmentPath: messagesTable.attachmentPath,
      })
      .from(messagesTable)
      .innerJoin(usersTable, eq(usersTable.id, messagesTable.senderId))
      .where(eq(messagesTable.conversationId, conversation.id))
      .orderBy(asc(messagesTable.sentAt));
    res.json(
      ListMessagesResponse.parse(
        rows.map((message) => ({
          ...message,
          sentAt: message.sentAt.toISOString(),
          isRead: message.isRead !== null,
        })),
      ),
    );
  },
);

router.post(
  "/conversations/:conversationId/messages",
  async (req, res): Promise<void> => {
    const userId = requireSessionUser(req, res);
    if (!userId) return;
    const params = SendMessageParams.safeParse(req.params);
    const body = SendMessageBody.safeParse(req.body);
    if (!params.success || !body.success) {
      res.status(400).json({
        error: !params.success
          ? params.error.message
          : !body.success
            ? body.error.message
            : "Invalid request",
      });
      return;
    }
    const [conversation] = await db
      .select()
      .from(conversationsTable)
      .where(eq(conversationsTable.id, params.data.conversationId))
      .limit(1);
    if (
      !conversation ||
      (conversation.patientId !== userId &&
        conversation.professionalId !== userId)
    ) {
      res.status(404).json({ error: "Conversation not found" });
      return;
    }
    const sender = await getLocalUser(userId);
    if (!sender) {
      res.status(409).json({ error: "Complete your صحتي profile first" });
      return;
    }
    const [message] = await db
      .insert(messagesTable)
      .values({
        conversationId: conversation.id,
        senderId: userId,
        content: body.data.content.trim(),
      })
      .returning();
    await db
      .update(conversationsTable)
      .set({ updatedAt: new Date() })
      .where(eq(conversationsTable.id, conversation.id));
    const recipientId =
      conversation.patientId === userId
        ? conversation.professionalId
        : conversation.patientId;
    await db.insert(notificationsTable).values({
      userId: recipientId,
      kind: "NEW_MESSAGE",
      title: "New message",
      body: "You have a new message in صحتي.",
    });
    res.status(201).json(
      SendMessageResponse.parse({
        id: message.id,
        conversationId: message.conversationId,
        senderId: userId,
        senderName: sender.fullName,
        content: message.content,
        sentAt: message.sentAt.toISOString(),
        isRead: false,
        attachmentPath: null,
      }),
    );
  },
);

export default router;
