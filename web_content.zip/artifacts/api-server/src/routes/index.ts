import { Router, type IRouter } from "express";
import healthRouter from "./health";
import memoRouter from "./memo";

const router: IRouter = Router();

router.use(healthRouter);
router.use(memoRouter);

export default router;
