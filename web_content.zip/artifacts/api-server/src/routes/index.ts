import { Router, type IRouter } from "express";
import healthRouter from "./health";
import accountRouter from "./account";
import appointmentsRouter from "./appointments";
import messagingRouter from "./messaging";
import medicalRouter from "./medical";
import reviewsNotificationsRouter from "./reviews-notifications";
import adminRouter from "./admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(accountRouter);
router.use(appointmentsRouter);
router.use(messagingRouter);
router.use(medicalRouter);
router.use(reviewsNotificationsRouter);
router.use(adminRouter);

export default router;
