import { Router, type IRouter } from "express";
import healthRouter from "./health";
import smartbizRouter from "./smartbiz";

const router: IRouter = Router();

router.use(healthRouter);
router.use(smartbizRouter);

export default router;
