import { Router, type IRouter } from "express";
import downloadRouter from "./download";
import bounceRouter from "./bounce";
import healthRouter from "./health";
import storageRouter from "./storage";

const router: IRouter = Router();

router.use(healthRouter);
router.use(bounceRouter);
router.use(downloadRouter);
router.use(storageRouter);

export default router;
