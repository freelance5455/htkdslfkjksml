import { Router, type IRouter } from "express";
import { clerkClient } from "@clerk/express";
import { and, desc, eq, gte, ilike, lte, sql } from "drizzle-orm";
import {
  GetCurrentUserResponse,
  GetProfessionalParams,
  GetProfessionalResponse,
  ListProfessionalsQueryParams,
  ListProfessionalsResponse,
  SaveCurrentProfileBody,
  SaveCurrentProfileResponse,
} from "@workspace/api-zod";
import { db } from "@workspace/db";
import {
  availabilityTable,
  professionalsTable,
  usersTable,
  appointmentsTable,
} from "@workspace/db/schema";
import { getLocalUser, requireSessionUser } from "../lib/request-auth";

const router: IRouter = Router();

function currentUserShape(
  user: typeof usersTable.$inferSelect,
  professionalId: string | null,
  onboardingComplete: boolean,
) {
  return {
    id: user.id,
    role: user.role,
    fullName: user.fullName,
    email: user.email,
    phone: user.phone,
    preferredLanguage: user.preferredLanguage as "ar" | "fr" | "en",
    birthDate: user.birthDate,
    gender: user.gender,
    professionalId,
    onboardingComplete,
  };
}

router.get("/me", async (req, res): Promise<void> => {
  const userId = requireSessionUser(req, res);
  if (!userId) return;
  const user = await getLocalUser(userId);
  if (!user) {
    res.status(404).json({ error: "Complete your profile to continue" });
    return;
  }
  const [professional] = await db
    .select({ userId: professionalsTable.userId })
    .from(professionalsTable)
    .where(eq(professionalsTable.userId, userId))
    .limit(1);
  res.json(
    GetCurrentUserResponse.parse(
      currentUserShape(user, professional?.userId ?? null, true),
    ),
  );
});

router.put("/me", async (req, res): Promise<void> => {
  const userId = requireSessionUser(req, res);
  if (!userId) return;
  const parsed = SaveCurrentProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const body = parsed.data;
  const birthDate = body.birthDate
    ? body.birthDate.toISOString().slice(0, 10)
    : null;
  const prior = await getLocalUser(userId);
  const desiredRole = body.role === "ADMIN" ? "PATIENT" : body.role;
  const isProfessional =
    desiredRole === "DOCTOR" ||
    desiredRole === "NURSE" ||
    desiredRole === "SPECIALIST";

  if (
    prior &&
    prior.role !== "PATIENT" &&
    prior.role !== desiredRole
  ) {
    res.status(409).json({ error: "Account role cannot be changed" });
    return;
  }
  if (
    isProfessional &&
    (!body.specialty?.trim() || !body.licenseNumber?.trim())
  ) {
    res.status(400).json({
      error: "Professional applications require a specialty and license number",
    });
    return;
  }

  const clerkUser = await clerkClient.users.getUser(userId);
  const primaryEmail = clerkUser.primaryEmailAddress?.emailAddress;
  const email = primaryEmail ?? prior?.email ?? "";
  const [saved] = await db
    .insert(usersTable)
    .values({
      id: userId,
      email,
      role: prior?.role === "ADMIN" ? "ADMIN" : desiredRole,
      fullName: body.fullName.trim(),
      phone: body.phone?.trim() || clerkUser.primaryPhoneNumber?.phoneNumber || null,
      preferredLanguage: body.preferredLanguage,
      birthDate,
      gender: body.gender ?? null,
    })
    .onConflictDoUpdate({
      target: usersTable.id,
      set: {
        email,
        role: prior?.role === "ADMIN" ? "ADMIN" : desiredRole,
        fullName: body.fullName.trim(),
        phone: body.phone?.trim() || clerkUser.primaryPhoneNumber?.phoneNumber || null,
        preferredLanguage: body.preferredLanguage,
        birthDate,
        gender: body.gender ?? null,
        updatedAt: new Date(),
      },
    })
    .returning();

  let professionalId: string | null = null;
  if (isProfessional) {
    const [professional] = await db
      .insert(professionalsTable)
      .values({
        userId,
        specialty: body.specialty!.trim(),
        licenseNumber: body.licenseNumber!.trim(),
        experienceYears: body.experienceYears ?? 0,
        languages: body.languages?.length
          ? body.languages
          : [body.preferredLanguage],
        bio: body.bio?.trim() ?? "",
        consultationPrice: body.consultationPrice ?? 0,
        currency: body.currency ?? "DZD",
        verificationStatus: "PENDING",
      })
      .onConflictDoUpdate({
        target: professionalsTable.userId,
        set: {
          specialty: body.specialty!.trim(),
          licenseNumber: body.licenseNumber!.trim(),
          experienceYears: body.experienceYears ?? 0,
          languages: body.languages?.length
            ? body.languages
            : [body.preferredLanguage],
          bio: body.bio?.trim() ?? "",
          consultationPrice: body.consultationPrice ?? 0,
          currency: body.currency ?? "DZD",
        },
      })
      .returning();
    professionalId = professional?.userId ?? null;
  }

  res.json(
    SaveCurrentProfileResponse.parse(
      currentUserShape(saved, professionalId, true),
    ),
  );
});

router.get("/professionals", async (req, res): Promise<void> => {
  const parsed = ListProfessionalsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const filters = [
    eq(professionalsTable.verificationStatus, "APPROVED"),
    parsed.data.query
      ? ilike(usersTable.fullName, `%${parsed.data.query.trim()}%`)
      : undefined,
    parsed.data.specialty
      ? ilike(professionalsTable.specialty, `%${parsed.data.specialty.trim()}%`)
      : undefined,
    parsed.data.role
      ? eq(usersTable.role, parsed.data.role)
      : undefined,
    parsed.data.minPrice !== undefined
      ? gte(professionalsTable.consultationPrice, parsed.data.minPrice)
      : undefined,
    parsed.data.maxPrice !== undefined
      ? lte(professionalsTable.consultationPrice, parsed.data.maxPrice)
      : undefined,
    parsed.data.minRating !== undefined
      ? gte(professionalsTable.rating, parsed.data.minRating)
      : undefined,
    parsed.data.gender
      ? eq(usersTable.gender, parsed.data.gender)
      : undefined,
    parsed.data.language
      ? sql`${professionalsTable.languages} @> ARRAY[${parsed.data.language}]::text[]`
      : undefined,
  ];

  const rows = await db
    .select({
      id: professionalsTable.userId,
      fullName: usersTable.fullName,
      role: usersTable.role,
      specialty: professionalsTable.specialty,
      experienceYears: professionalsTable.experienceYears,
      languages: professionalsTable.languages,
      consultationPrice: professionalsTable.consultationPrice,
      currency: professionalsTable.currency,
      rating: professionalsTable.rating,
      reviewCount: professionalsTable.reviewCount,
      imageUrl: professionalsTable.imageUrl,
      gender: usersTable.gender,
      verificationStatus: professionalsTable.verificationStatus,
    })
    .from(professionalsTable)
    .innerJoin(usersTable, eq(usersTable.id, professionalsTable.userId))
    .where(and(...filters))
    .orderBy(desc(professionalsTable.rating), usersTable.fullName)
    .limit(100);

  const result = rows.map((row) => ({
    ...row,
    role: row.role as "DOCTOR" | "NURSE" | "SPECIALIST",
    consultationPrice: Number(row.consultationPrice),
    rating: Number(row.rating),
    imageUrl: row.imageUrl ?? "",
    gender: row.gender ?? "prefer_not_to_say",
    nextAvailableAt: null,
  }));
  res.json(ListProfessionalsResponse.parse(result));
});

router.get("/professionals/:professionalId", async (req, res): Promise<void> => {
  const params = GetProfessionalParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const professionalId = params.data.professionalId;
  const [row] = await db
    .select({
      id: professionalsTable.userId,
      fullName: usersTable.fullName,
      role: usersTable.role,
      specialty: professionalsTable.specialty,
      experienceYears: professionalsTable.experienceYears,
      languages: professionalsTable.languages,
      consultationPrice: professionalsTable.consultationPrice,
      currency: professionalsTable.currency,
      rating: professionalsTable.rating,
      reviewCount: professionalsTable.reviewCount,
      imageUrl: professionalsTable.imageUrl,
      gender: usersTable.gender,
      verificationStatus: professionalsTable.verificationStatus,
      bio: professionalsTable.bio,
      education: professionalsTable.education,
      certifications: professionalsTable.certifications,
    })
    .from(professionalsTable)
    .innerJoin(usersTable, eq(usersTable.id, professionalsTable.userId))
    .where(
      and(
        eq(professionalsTable.userId, professionalId),
        eq(professionalsTable.verificationStatus, "APPROVED"),
      ),
    )
    .limit(1);
  if (!row) {
    res.status(404).json({ error: "Professional not found" });
    return;
  }

  const schedule = await db
    .select()
    .from(availabilityTable)
    .where(eq(availabilityTable.professionalId, professionalId));
  const existing = await db
    .select({
      startsAt: appointmentsTable.startsAt,
      durationMinutes: appointmentsTable.durationMinutes,
      status: appointmentsTable.status,
    })
    .from(appointmentsTable)
    .where(eq(appointmentsTable.professionalId, professionalId));

  const slots: Array<{ startsAt: string; durationMinutes: number }> = [];
  const today = new Date();
  today.setUTCHours(0, 0, 0, 0);
  for (let offset = 0; offset < 14 && slots.length < 24; offset += 1) {
    const day = new Date(today.getTime() + offset * 86_400_000);
    const daySchedule = schedule.filter((entry) => entry.dayOfWeek === day.getUTCDay());
    for (const entry of daySchedule) {
      const [startHour, startMinute] = entry.startTime.split(":").map(Number);
      const [endHour, endMinute] = entry.endTime.split(":").map(Number);
      const start = startHour * 60 + startMinute;
      const end = endHour * 60 + endMinute;
      for (
        let minute = start;
        minute + entry.slotMinutes <= end && slots.length < 24;
        minute += entry.slotMinutes
      ) {
        const slot = new Date(day);
        slot.setUTCHours(Math.floor(minute / 60), minute % 60, 0, 0);
        if (slot <= new Date()) continue;
        const endAt = slot.getTime() + entry.slotMinutes * 60_000;
        const occupied = existing.some((appointment) => {
          if (appointment.status === "CANCELLED") return false;
          const appointmentStart = appointment.startsAt.getTime();
          const appointmentEnd =
            appointmentStart + appointment.durationMinutes * 60_000;
          return slot.getTime() < appointmentEnd && endAt > appointmentStart;
        });
        if (!occupied) {
          slots.push({
            startsAt: slot.toISOString(),
            durationMinutes: entry.slotMinutes,
          });
        }
      }
    }
  }

  res.json(
    GetProfessionalResponse.parse({
      ...row,
      role: row.role as "DOCTOR" | "NURSE" | "SPECIALIST",
      consultationPrice: Number(row.consultationPrice),
      rating: Number(row.rating),
      imageUrl: row.imageUrl ?? "",
      gender: row.gender ?? "prefer_not_to_say",
      bio: row.bio ?? "",
      education: row.education ?? [],
      certifications: row.certifications ?? [],
      slots,
    }),
  );
});

export default router;
