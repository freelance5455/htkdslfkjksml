export type Bot = {
  id: string; name: string; description: string; image: string | null; language: string;
  personality: string; style: string; platform: string; status: "running" | "paused" | "draft" | "error";
  messages: number; replyRate: number; updatedAt: string;
};
export type Rule = { id: string; botId: string; trigger: string; response: string; matches: number; active: boolean };
export type KnowledgeEntry = { id: string; botId: string; category: string; title: string; content: string; updatedAt: string };
export type Activity = { id: string; type: string; title: string; detail: string; time: string; status: string };
export type Conversation = { id: string; botName: string; platform: string; preview: string; status: string; updatedAt: string };
export type Platform = { id: string; name: string; description: string; icon: string; status: "connected" | "available" | "attention"; official: boolean };
export type Settings = { name: string; email: string; language: string; emailNotifications: boolean; securityAlerts: boolean; aiModel: string; retentionDays: number };

const now = () => new Date().toISOString();
const uid = (prefix: string) => `${prefix}_${Math.random().toString(36).slice(2, 10)}`;

export const store = {
  bots: [
    { id: "bot_noura", name: "نورة — خدمة العملاء", description: "مساعدة ودودة للرد على أسئلة العملاء ومتابعة الطلبات.", image: null, language: "العربية", personality: "ودودة واحترافية", style: "مختصر ومباشر", platform: "WhatsApp", status: "running" as const, messages: 1842, replyRate: 96, updatedAt: now() },
    { id: "bot_sahab", name: "سحاب — المبيعات", description: "وكيل مبيعات ذكي يشرح الخدمات ويقترح الباقة المناسبة.", image: null, language: "العربية", personality: "استشاري ومقنع", style: "تفصيلي عند الحاجة", platform: "Instagram", status: "paused" as const, messages: 864, replyRate: 91, updatedAt: now() },
    { id: "bot_lama", name: "لمى — الحجوزات", description: "تنظيم الحجوزات والإجابة على الأسئلة المتكررة طوال اليوم.", image: null, language: "العربية", personality: "هادئة ومنظمة", style: "دافئ وسريع", platform: "Telegram", status: "draft" as const, messages: 0, replyRate: 0, updatedAt: now() },
  ] as Bot[],
  rules: [
    { id: "rule_1", botId: "bot_noura", trigger: "ساعات العمل", response: "نستقبلكم من الأحد إلى الخميس، من 9 صباحًا حتى 6 مساءً.", matches: 347, active: true },
    { id: "rule_2", botId: "bot_noura", trigger: "السعر | الأسعار", response: "يسعدني مساعدتك. أخبرني بالخدمة التي ترغب بمعرفة سعرها.", matches: 218, active: true },
    { id: "rule_3", botId: "bot_sahab", trigger: "الباقة الذهبية", response: "الباقة الذهبية تشمل كل المزايا مع دعم أولوية.", matches: 96, active: false },
  ] satisfies Rule[],
  knowledge: [
    { id: "kb_1", botId: "bot_noura", category: "الأسئلة الشائعة", title: "مواعيد الدعم", content: "فريق الدعم متاح من الأحد إلى الخميس، 9 صباحًا — 6 مساءً بتوقيت الرياض.", updatedAt: now() },
    { id: "kb_2", botId: "bot_noura", category: "الخدمات", title: "سياسة الاسترجاع", content: "يمكن طلب الاسترجاع خلال 14 يومًا من تاريخ الشراء وفق الشروط الموضحة في الفاتورة.", updatedAt: now() },
    { id: "kb_3", botId: "bot_sahab", category: "الأسعار", title: "الباقة الذهبية", content: "اشتراك شهري شامل يبدأ من 249 ريالًا، مع تجربة مجانية لمدة 7 أيام.", updatedAt: now() },
  ] satisfies KnowledgeEntry[],
  conversations: [
    { id: "conv_1", botName: "نورة — خدمة العملاء", platform: "WhatsApp", preview: "هل يمكن معرفة مواعيد الدعم؟", status: "تم الرد", updatedAt: "منذ 4 دقائق" },
    { id: "conv_2", botName: "سحاب — المبيعات", platform: "Instagram", preview: "أرغب في معرفة الفرق بين الباقات.", status: "بانتظار المراجعة", updatedAt: "منذ 22 دقيقة" },
    { id: "conv_3", botName: "نورة — خدمة العملاء", platform: "WhatsApp", preview: "شكرًا، كانت الإجابة مفيدة جدًا.", status: "تم الرد", updatedAt: "منذ ساعة" },
    { id: "conv_4", botName: "نورة — خدمة العملاء", platform: "WhatsApp", preview: "أحتاج مساعدة من موظف.", status: "تصعيد بشري", updatedAt: "منذ ساعتين" },
  ] satisfies Conversation[],
  activity: [
    { id: "act_1", type: "message", title: "تم الرد على محادثة جديدة", detail: "نورة — خدمة العملاء · WhatsApp", time: "منذ 4 دقائق", status: "success" },
    { id: "act_2", type: "connection", title: "اتصال WhatsApp مستقر", detail: "تم التحقق من Webhook الرسمي بنجاح", time: "منذ 18 دقيقة", status: "success" },
    { id: "act_3", type: "bot", title: "تم إيقاف سحاب — المبيعات", detail: "بواسطة مدير الحساب", time: "منذ 22 دقيقة", status: "neutral" },
    { id: "act_4", type: "warning", title: "قاعدة تحتاج مراجعة", detail: "تعارض محتمل في قاعدة الأسعار", time: "منذ ساعة", status: "warning" },
  ] satisfies Activity[],
  platforms: [
    { id: "whatsapp", name: "WhatsApp Business", description: "رسائل العملاء عبر Cloud API الرسمي من Meta.", icon: "whatsapp", status: "connected" as const, official: true },
    { id: "instagram", name: "Instagram", description: "الرد على رسائل Instagram عبر Graph API الرسمي.", icon: "instagram", status: "available" as const, official: true },
    { id: "telegram", name: "Telegram", description: "ربط Bot API الرسمي مع Webhooks آمنة.", icon: "telegram", status: "available" as const, official: true },
    { id: "messenger", name: "Messenger", description: "إدارة رسائل صفحات Facebook عبر Graph API.", icon: "messenger", status: "attention" as const, official: true },
    { id: "discord", name: "Discord", description: "ربط البوت عبر تطبيق Discord الرسمي وBot API.", icon: "discord", status: "available" as const, official: true },
  ] satisfies Platform[],
  settings: { name: "أحمد محمد", email: "ahmad@example.com", language: "ar", emailNotifications: true, securityAlerts: true, aiModel: "memo-smart", retentionDays: 30 } satisfies Settings,
};

export const addActivity = (title: string, detail: string, type = "bot", status = "success") => {
  store.activity.unshift({ id: uid("act"), type, title, detail, time: "الآن", status });
};

export const createId = uid;