import { Router, type IRouter } from "express";
import { and, eq, gt, inArray } from "drizzle-orm";
import {
  DeleteDocumentParams,
  GetDocumentDownloadResponse,
  GetDocumentDownloadParams,
  GetMedicalRecordQueryParams,
  ListDocumentsQueryParams,
  ListDocumentsResponse,
  GetMedicalRecordResponse,
  RegisterDocumentBody,
  RequestDocumentUploadUrlBody,
  SaveMedicalRecordBody,
  SaveMedicalRecordResponse,
} from "@workspace/api-zod";
import {
} from "@workspace/db";
import { db } from "@workspace/db";
import {
  appointmentsTable,
  documentUploadsTable,
  medicalDocumentsTable,
  medicalRecordsTable,
} from "@workspace/db/schema";
import { ObjectStorageService } from "../lib/objectStorage";
import { getLocalUser, requireSessionUser } from "../lib/request-auth";

const router: IRouter = Router();
const objectStorage = new ObjectStorageService();
const permittedTypes = new Set([
  "application/pdf",
  "image/jpeg",
  "image/png",
  "image/webp",
]);
const maxFileBytes = 10 * 1024 * 1024;

async function canAccessPatient(userId: string, patientId: string) {
  if (userId === patientId) return true;
  const user = await getLocalUser(userId);
  if (
    user?.role !== "DOCTOR" &&
    user?.role !== "NURSE" &&
    user?.role !== "SPECIALIST" &&
    user?.role !== "ADMIN"
  ) {
    return false;
  }
  const [relationship] = await db
    .select({ id: appointmentsTable.id })
    .from(appointmentsTable)
    .where(
      and(
        eq(appointmentsTable.professionalId, userId),
        eq(appointmentsTable.patientId, patientId),
      ),
    )
    .limit(1);
  return Boolean(relationship);
}

function documentShape(document: typeof medicalDocumentsTable.$inferSelect) {
  return {
    id: document.id,
    patientId: document.patientId,
    name: document.name,
    size: document.size,
    contentType: document.contentType,
    documentType: document.documentType as
      | "REPORT"
      | "PRESCRIPTION"
      | "IMAGE"
      | "OTHER",
    createdAt: document.createdAt.toISOString(),
  };
}

router.get("/medical-record", async (req, res): Promise<void> => {
  const userId = requireSessionUser(req, res);
  if (!userId) return;
  const query = GetMedicalRecordQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const patientId = query.data.patientId || userId;
  if (!(await canAccessPatient(userId, patientId))) {
    res.status(403).json({ error: "You cannot access this medical record" });
    return;
  }
  const [record] = await db
    .select()
    .from(medicalRecordsTable)
    .where(eq(medicalRecordsTable.patientId, patientId))
    .limit(1);
  res.json(
    GetMedicalRecordResponse.parse({
      patientId,
      allergies: record?.allergies ?? "",
      medicalHistory: record?.medicalHistory ?? "",
      medications: record?.medications ?? "",
      notes: record?.notes ?? "",
      updatedAt: (record?.updatedAt ?? new Date()).toISOString(),
    }),
  );
});

router.put("/medical-record", async (req, res): Promise<void> => {
  const userId = requireSessionUser(req, res);
  if (!userId) return;
  const user = await getLocalUser(userId);
  if (!user || user.role !== "PATIENT") {
    res.status(403).json({ error: "Only patients can edit their own record" });
    return;
  }
  const body = SaveMedicalRecordBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const [record] = await db
    .insert(medicalRecordsTable)
    .values({ patientId: userId, ...body.data })
    .onConflictDoUpdate({
      target: medicalRecordsTable.patientId,
      set: {
        ...body.data,
        updatedAt: new Date(),
      },
    })
    .returning();
  res.json(
    SaveMedicalRecordResponse.parse({
      ...record,
      updatedAt: record.updatedAt.toISOString(),
    }),
  );
});

router.post(
  "/storage/uploads/request-url",
  async (req, res): Promise<void> => {
    const userId = requireSessionUser(req, res);
    if (!userId) return;
    const user = await getLocalUser(userId);
    if (!user || user.role !== "PATIENT") {
      res.status(403).json({ error: "Only patients can add medical documents" });
      return;
    }
    const body = RequestDocumentUploadUrlBody.safeParse(req.body);
    if (!body.success) {
      res.status(400).json({ error: body.error.message });
      return;
    }
    if (
      body.data.size > maxFileBytes ||
      !permittedTypes.has(body.data.contentType) ||
      body.data.name.includes("/") ||
      body.data.name.includes("\\")
    ) {
      res.status(400).json({ error: "Unsupported medical document" });
      return;
    }
    try {
      const uploadURL = await objectStorage.getObjectEntityUploadURL();
      const objectPath = objectStorage.normalizeObjectEntityPath(uploadURL);
      if (!objectPath.startsWith("/objects/uploads/")) {
        res.status(502).json({ error: "Could not create private upload path" });
        return;
      }
      await db.insert(documentUploadsTable).values({
        objectPath,
        ownerId: userId,
        name: body.data.name,
        size: body.data.size,
        contentType: body.data.contentType,
        expiresAt: new Date(Date.now() + 15 * 60_000),
      });
      res.json({ uploadURL, objectPath });
    } catch (error) {
      req.log.error({ err: error }, "Unable to create private document upload URL");
      res.status(503).json({ error: "Document storage is temporarily unavailable" });
    }
  },
);

router.get("/documents", async (req, res): Promise<void> => {
  const userId = requireSessionUser(req, res);
  if (!userId) return;
  const query = ListDocumentsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const user = await getLocalUser(userId);
  const patientId =
    query.data.patientId ??
    (user?.role === "PATIENT" ? userId : undefined);
  if (!patientId) {
    res.json(ListDocumentsResponse.parse([]));
    return;
  }
  if (!(await canAccessPatient(userId, patientId))) {
    res.status(403).json({ error: "You cannot access these documents" });
    return;
  }
  const documents = await db
    .select()
    .from(medicalDocumentsTable)
    .where(eq(medicalDocumentsTable.patientId, patientId))
    .orderBy(medicalDocumentsTable.createdAt);
  res.json(
    ListDocumentsResponse.parse(documents.map((item) => documentShape(item))),
  );
});

router.post("/documents", async (req, res): Promise<void> => {
  const userId = requireSessionUser(req, res);
  if (!userId) return;
  const user = await getLocalUser(userId);
  if (!user || user.role !== "PATIENT") {
    res.status(403).json({ error: "Only patients can add medical documents" });
    return;
  }
  const body = RegisterDocumentBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  if (
    body.data.patientId &&
    body.data.patientId !== userId
  ) {
    res.status(403).json({ error: "Documents can only be added to your own record" });
    return;
  }
  const [pending] = await db
    .select()
    .from(documentUploadsTable)
    .where(
      and(
        eq(documentUploadsTable.objectPath, body.data.objectPath),
        eq(documentUploadsTable.ownerId, userId),
        gt(documentUploadsTable.expiresAt, new Date()),
      ),
    )
    .limit(1);
  if (
    !pending ||
    pending.name !== body.data.name ||
    pending.size !== body.data.size ||
    pending.contentType !== body.data.contentType ||
    !permittedTypes.has(body.data.contentType) ||
    !body.data.objectPath.startsWith("/objects/uploads/")
  ) {
    res.status(403).json({ error: "This upload is not valid for your account" });
    return;
  }
  try {
    const file = await objectStorage.getObjectEntityFile(body.data.objectPath);
    const [metadata] = await file.getMetadata();
    if (
      Number(metadata.size) !== body.data.size ||
      (metadata.contentType &&
        metadata.contentType !== body.data.contentType)
    ) {
      res.status(400).json({ error: "The uploaded file does not match its details" });
      return;
    }
    const [document] = await db.transaction(async (tx) => {
      const [saved] = await tx
        .insert(medicalDocumentsTable)
        .values({
          patientId: userId,
          objectPath: body.data.objectPath,
          name: body.data.name,
          size: body.data.size,
          contentType: body.data.contentType,
          documentType: body.data.documentType,
        })
        .returning();
      await tx
        .delete(documentUploadsTable)
        .where(eq(documentUploadsTable.objectPath, body.data.objectPath));
      return [saved];
    });
    res.status(201).json(documentShape(document));
  } catch (error) {
    req.log.error({ err: error }, "Unable to register private medical document");
    res.status(400).json({ error: "The uploaded file could not be found" });
  }
});

router.get(
  "/documents/:documentId/download",
  async (req, res): Promise<void> => {
    const userId = requireSessionUser(req, res);
    if (!userId) return;
    const params = GetDocumentDownloadParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const [document] = await db
      .select()
      .from(medicalDocumentsTable)
      .where(eq(medicalDocumentsTable.id, params.data.documentId))
      .limit(1);
    if (!document || !(await canAccessPatient(userId, document.patientId))) {
      res.status(404).json({ error: "Document not found" });
      return;
    }
    res.json(
      GetDocumentDownloadResponse.parse({
        downloadUrl: `/api/storage/documents/${document.id}/content`,
      }),
    );
  },
);

router.get(
  "/storage/documents/:documentId/content",
  async (req, res): Promise<void> => {
    const userId = requireSessionUser(req, res);
    if (!userId) return;
    const [document] = await db
      .select()
      .from(medicalDocumentsTable)
      .where(eq(medicalDocumentsTable.id, req.params.documentId))
      .limit(1);
    if (!document || !(await canAccessPatient(userId, document.patientId))) {
      res.status(404).json({ error: "Document not found" });
      return;
    }
    try {
      const file = await objectStorage.getObjectEntityFile(document.objectPath);
      const [metadata] = await file.getMetadata();
      res.setHeader("Content-Type", document.contentType);
      res.setHeader("Content-Length", String(metadata.size ?? document.size));
      res.setHeader(
        "Content-Disposition",
        `attachment; filename*=UTF-8''${encodeURIComponent(document.name)}`,
      );
      res.setHeader("X-Content-Type-Options", "nosniff");
      res.setHeader("Cache-Control", "private, no-store");
      file.createReadStream().on("error", () => {
        if (!res.headersSent) res.status(404).end();
        else res.destroy();
      }).pipe(res);
    } catch (error) {
      req.log.error({ err: error }, "Unable to download private medical document");
      res.status(404).json({ error: "Document not found" });
    }
  },
);

router.delete("/documents/:documentId", async (req, res): Promise<void> => {
  const userId = requireSessionUser(req, res);
  if (!userId) return;
  const params = DeleteDocumentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [document] = await db
    .select()
    .from(medicalDocumentsTable)
    .where(eq(medicalDocumentsTable.id, params.data.documentId))
    .limit(1);
  if (!document || document.patientId !== userId) {
    res.status(404).json({ error: "Document not found" });
    return;
  }
  try {
    const file = await objectStorage.getObjectEntityFile(document.objectPath);
    await file.delete({ ignoreNotFound: true });
  } catch (error) {
    req.log.warn({ err: error }, "Removing a missing medical document object");
  }
  await db
    .delete(medicalDocumentsTable)
    .where(eq(medicalDocumentsTable.id, document.id));
  res.status(204).end();
});

export default router;
