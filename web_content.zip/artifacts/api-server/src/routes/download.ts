import { Router, type IRouter } from "express";
import fs from "node:fs";
import path from "node:path";

const router: IRouter = Router();
const archivePath = [
  path.resolve(process.cwd(), "downloads", "bounce-app-source.zip"),
  path.resolve(process.cwd(), "..", "..", "downloads", "bounce-app-source.zip"),
].find((candidate) => fs.existsSync(candidate));

router.get("/downloads/bounce-app-source.zip", (_req, res, next) => {
  if (!archivePath) {
    res.status(404).json({ error: "Download archive not found" });
    return;
  }

  res.download(archivePath, "bounce-app-source.zip", (error) => {
    if (error && !res.headersSent) {
      next(error);
    }
  });
});

export default router;