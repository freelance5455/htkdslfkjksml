import { Router, type IRouter } from "express";
import { and, desc, eq, sql } from "drizzle-orm";
import {
  CreateReviewBody,
  CreateReviewResponse,
  ListNotificationsResponse,
  ListReviewsQueryParams,
  ListReviewsResponse,
  MarkNotificationReadParams,
  MarkNotificationReadResponse,
} from "@workspace/api-zod";
import {
} from "@workspace/db";
import { db } from "@workspace/db";
import {
  appointmentsTable,
  notificationsTable,
  professionalsTable,
  reviewsTable,
  usersTable,
} from "@workspace/db/schema";
import { getLocalUser, requireSessionUser } from "../lib/request-auth";

const router: IRouter = Router();

router.get("/reviews", async (req, res): Promise<void> => {
  const query = ListReviewsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const rows = await db
    .select({
      id: reviewsTable.id,
      professionalId: reviewsTable.professionalId,
      patientName: usersTable.fullName,
      rating: reviewsTable.rating,
      comment: reviewsTable.comment,
      createdAt: reviewsTable.createdAt,
    })
    .from(reviewsTable)
    .innerJoin(usersTable, eq(usersTable.id, reviewsTable.patientId))
    .where(eq(reviewsTable.professionalId, query.data.professionalId))
    .orderBy(desc(reviewsTable.createdAt))
    .limit(100);
  res.json(
    ListReviewsResponse.parse(
      rows.map((row) => ({ ...row, createdAt: row.createdAt.toISOString() })),
    ),
  );
});

router.post("/reviews", async (req, res): Promise<void> => {
  const userId = requireSessionUser(req, res);
  if (!userId) return;
  const user = await getLocalUser(userId);
  if (!user || user.role !== "PATIENT") {
    res.status(403).json({ error: "Only patients can submit reviews" });
    return;
  }
  const body = CreateReviewBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const [appointment] = await db
    .select()
    .from(appointmentsTable)
    .where(eq(appointmentsTable.id, body.data.appointmentId))
    .limit(1);
  if (
    !appointment ||
    appointment.patientId !== userId ||
    appointment.status !== "COMPLETED"
  ) {
    res.status(403).json({
      error: "Reviews are available only for completed appointments",
    });
    return;
  }
  try {
    const [review] = await db.transaction(async (tx) => {
      const [created] = await tx
        .insert(reviewsTable)
        .values({
          appointmentId: appointment.id,
          patientId: userId,
          professionalId: appointment.professionalId,
          rating: body.data.rating,
          comment: body.data.comment?.trim() ?? "",
        })
        .returning();
      const aggregate = await tx
        .select({
          rating: sql<number>`avg(${reviewsTable.rating})`.mapWith(Number),
          reviewCount: sql<number>`count(*)`.mapWith(Number),
        })
        .from(reviewsTable)
        .where(eq(reviewsTable.professionalId, appointment.professionalId));
      await tx
        .update(professionalsTable)
        .set({
          rating: Number(aggregate[0]?.rating ?? 0),
          reviewCount: Number(aggregate[0]?.reviewCount ?? 0),
        })
        .where(eq(professionalsTable.userId, appointment.professionalId));
      await tx.insert(notificationsTable).values({
        userId: appointment.professionalId,
        kind: "NEW_REVIEW",
        title: "New review",
        body: "A patient left feedback after a consultation.",
      });
      return [created];
    });
    res.status(201).json(
      CreateReviewResponse.parse({
        id: review.id,
        professionalId: review.professionalId,
        patientName: user.fullName,
        rating: review.rating,
        comment: review.comment,
        createdAt: review.createdAt.toISOString(),
      }),
    );
  } catch (error) {
    req.log.info({ err: error }, "Review submission rejected");
    res.status(409).json({ error: "A review already exists for this visit" });
  }
});

router.get("/notifications", async (req, res): Promise<void> => {
  const userId = requireSessionUser(req, res);
  if (!userId) return;
  const rows = await db
    .select()
    .from(notificationsTable)
    .where(eq(notificationsTable.userId, userId))
    .orderBy(desc(notificationsTable.createdAt))
    .limit(100);
  res.json(
    ListNotificationsResponse.parse(
      rows.map((notification) => ({
        id: notification.id,
        kind: notification.kind,
        title: notification.title,
        body: notification.body,
        createdAt: notification.createdAt.toISOString(),
        isRead: notification.readAt !== null,
        relatedAppointmentId: notification.relatedAppointmentId,
      })),
    ),
  );
});

router.post(
  "/notifications/:notificationId/read",
  async (req, res): Promise<void> => {
    const userId = requireSessionUser(req, res);
    if (!userId) return;
    const params = MarkNotificationReadParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const [notification] = await db
      .update(notificationsTable)
      .set({ readAt: new Date() })
      .where(
        and(
          eq(notificationsTable.id, params.data.notificationId),
          eq(notificationsTable.userId, userId),
        ),
      )
      .returning();
    if (!notification) {
      res.status(404).json({ error: "Notification not found" });
      return;
    }
    res.json(
      MarkNotificationReadResponse.parse({
        id: notification.id,
        kind: notification.kind,
        title: notification.title,
        body: notification.body,
        createdAt: notification.createdAt.toISOString(),
        isRead: true,
        relatedAppointmentId: notification.relatedAppointmentId,
      }),
    );
  },
);

export default router;
