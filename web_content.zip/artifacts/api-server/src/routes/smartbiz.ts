import { Router, type IRouter, type NextFunction, type Request, type Response } from "express";
import { getAuth } from "@clerk/express";
import { and, desc, eq, gte, inArray, lte } from "drizzle-orm";
import {
  db,
  businessesTable,
  transactionsTable,
  debtsTable,
  debtPaymentsTable,
  productsTable,
  stockMovementsTable,
  syncChangesTable,
} from "@workspace/db";
import {
  CreateBusinessBody,
  CreateBusinessResponse,
  CreateDebtBody,
  CreateDebtResponse,
  CreateProductBody,
  CreateProductResponse,
  CreateStockMovementBody,
  CreateStockMovementParams,
  CreateStockMovementResponse,
  CreateTransactionBody,
  CreateTransactionResponse,
  DeleteBusinessParams,
  DeleteDebtParams,
  DeleteProductParams,
  DeleteTransactionParams,
  GetBusinessReportQueryParams,
  GetBusinessReportResponse,
  ListBusinessesResponse,
  ListDebtsQueryParams,
  ListDebtsResponse,
  ListDebtPaymentsParams,
  ListDebtPaymentsResponse,
  ListProductsQueryParams,
  ListProductsResponse,
  ListStockMovementsParams,
  ListStockMovementsResponse,
  ListTransactionsQueryParams,
  ListTransactionsResponse,
  PullSyncChangesQueryParams,
  PullSyncChangesResponse,
  PushSyncChangesBody,
  PushSyncChangesResponse,
  RecordDebtPaymentBody,
  RecordDebtPaymentParams,
  RecordDebtPaymentResponse,
  UpdateBusinessBody,
  UpdateBusinessParams,
  UpdateBusinessResponse,
  UpdateDebtBody,
  UpdateDebtParams,
  UpdateDebtResponse,
  UpdateProductBody,
  UpdateProductParams,
  UpdateProductResponse,
  UpdateTransactionBody,
  UpdateTransactionParams,
  UpdateTransactionResponse,
} from "@workspace/api-zod";
import { logger } from "../lib/logger";

type AuthenticatedRequest = Request & { userId: string };
type Entity = "business" | "transaction" | "debt" | "debtPayment" | "product" | "stockMovement";
type SyncOperation = "upsert" | "delete";
type SyncInput = {
  entity: Entity;
  id: string;
  operation: SyncOperation;
  data: Record<string, unknown>;
  updatedAt: string | Date;
};

const router: IRouter = Router();

function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const userId = getAuth(req).userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  (req as AuthenticatedRequest).userId = userId;
  next();
}

function userIdOf(req: Request): string {
  return (req as AuthenticatedRequest).userId;
}

function parseBody<T>(schema: { safeParse: (value: unknown) => { success: true; data: T } | { success: false; error: { message: string } } }, body: unknown, res: Response): T | null {
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return null;
  }
  return parsed.data;
}

function parseParams<T>(schema: { safeParse: (value: unknown) => { success: true; data: T } | { success: false; error: { message: string } } }, params: unknown, res: Response): T | null {
  const parsed = schema.safeParse(params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return null;
  }
  return parsed.data;
}

function dateOnly(value: string | Date | null | undefined): string | null {
  if (value == null) return null;
  if (typeof value === "string") return value.slice(0, 10);
  return value.toISOString().slice(0, 10);
}

function recordData(record: object): Record<string, unknown> {
  return JSON.parse(JSON.stringify(record)) as Record<string, unknown>;
}

async function businessOwned(userId: string, businessId: string): Promise<boolean> {
  const [business] = await db
    .select({ id: businessesTable.id })
    .from(businessesTable)
    .where(and(eq(businessesTable.id, businessId), eq(businessesTable.ownerId, userId)))
    .limit(1);
  return !!business;
}

async function businessOwner(businessId: string): Promise<string | null> {
  const [business] = await db
    .select({ ownerId: businessesTable.ownerId })
    .from(businessesTable)
    .where(eq(businessesTable.id, businessId))
    .limit(1);
  return business?.ownerId ?? null;
}

async function writeSync(
  ownerId: string,
  entity: Entity,
  recordId: string,
  operation: SyncOperation,
  data: Record<string, unknown> = {},
): Promise<void> {
  await db.insert(syncChangesTable).values({
    ownerId,
    entity,
    recordId,
    operation,
    data,
    updatedAt: new Date(),
  });
}

const businessIdQuery = (req: Request, res: Response): string | null => {
  const businessId = typeof req.query.businessId === "string" ? req.query.businessId : "";
  if (!businessId) {
    res.status(400).json({ error: "businessId is required" });
    return null;
  }
  return businessId;
};

router.use(requireAuth);

router.get("/businesses", async (req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(businessesTable)
    .where(eq(businessesTable.ownerId, userIdOf(req)))
    .orderBy(desc(businessesTable.updatedAt));
  res.json(ListBusinessesResponse.parse(rows));
});

router.post("/businesses", async (req, res): Promise<void> => {
  const data = parseBody(CreateBusinessBody, req.body, res);
  if (!data) return;
  const [business] = await db
    .insert(businessesTable)
    .values({ ...data, ownerId: userIdOf(req) })
    .returning();
  await writeSync(userIdOf(req), "business", business.id, "upsert", recordData(business));
  res.status(201).json(CreateBusinessResponse.parse(business));
});

router.patch("/businesses/:businessId", async (req, res): Promise<void> => {
  const params = parseParams(UpdateBusinessParams, req.params, res);
  const data = parseBody(UpdateBusinessBody, req.body, res);
  if (!params || !data) return;
  const [business] = await db
    .update(businessesTable)
    .set({ ...data, updatedAt: new Date() })
    .where(and(eq(businessesTable.id, params.businessId), eq(businessesTable.ownerId, userIdOf(req))))
    .returning();
  if (!business) {
    res.status(404).json({ error: "Business not found" });
    return;
  }
  await writeSync(userIdOf(req), "business", business.id, "upsert", recordData(business));
  res.json(UpdateBusinessResponse.parse(business));
});

router.delete("/businesses/:businessId", async (req, res): Promise<void> => {
  const params = parseParams(DeleteBusinessParams, req.params, res);
  if (!params) return;
  const [business] = await db
    .delete(businessesTable)
    .where(and(eq(businessesTable.id, params.businessId), eq(businessesTable.ownerId, userIdOf(req))))
    .returning();
  if (!business) {
    res.status(404).json({ error: "Business not found" });
    return;
  }
  await writeSync(userIdOf(req), "business", business.id, "delete");
  res.sendStatus(204);
});

router.get("/transactions", async (req, res): Promise<void> => {
  const query = parseBody(ListTransactionsQueryParams, req.query, res);
  if (!query) return;
  if (!(await businessOwned(userIdOf(req), query.businessId))) {
    res.status(404).json({ error: "Business not found" });
    return;
  }
  const filters = [eq(transactionsTable.businessId, query.businessId)];
  if (typeof query.from === "string" && query.from) filters.push(gte(transactionsTable.date, query.from));
  if (typeof query.to === "string" && query.to) filters.push(lte(transactionsTable.date, query.to));
  const rows = await db.select().from(transactionsTable).where(and(...filters)).orderBy(desc(transactionsTable.date), desc(transactionsTable.createdAt));
  res.json(ListTransactionsResponse.parse(rows));
});

router.post("/transactions", async (req, res): Promise<void> => {
  const data = parseBody(CreateTransactionBody, req.body, res);
  if (!data) return;
  if (!(await businessOwned(userIdOf(req), data.businessId))) {
    res.status(404).json({ error: "Business not found" });
    return;
  }
  const [transaction] = await db
    .insert(transactionsTable)
    .values({ ...data, date: dateOnly(data.date)!, createdAt: new Date(), updatedAt: new Date() })
    .returning();
  await writeSync(userIdOf(req), "transaction", transaction.id, "upsert", recordData(transaction));
  res.status(201).json(CreateTransactionResponse.parse(transaction));
});

router.patch("/transactions/:transactionId", async (req, res): Promise<void> => {
  const params = parseParams(UpdateTransactionParams, req.params, res);
  const data = parseBody(UpdateTransactionBody, req.body, res);
  if (!params || !data) return;
  if (!(await businessOwned(userIdOf(req), data.businessId))) {
    res.status(404).json({ error: "Business not found" });
    return;
  }
  const [transaction] = await db
    .update(transactionsTable)
    .set({ ...data, date: dateOnly(data.date)!, updatedAt: new Date() })
    .where(and(eq(transactionsTable.id, params.transactionId), eq(transactionsTable.businessId, data.businessId)))
    .returning();
  if (!transaction || !(await businessOwned(userIdOf(req), transaction.businessId))) {
    res.status(404).json({ error: "Transaction not found" });
    return;
  }
  await writeSync(userIdOf(req), "transaction", transaction.id, "upsert", recordData(transaction));
  res.json(UpdateTransactionResponse.parse(transaction));
});

router.delete("/transactions/:transactionId", async (req, res): Promise<void> => {
  const params = parseParams(DeleteTransactionParams, req.params, res);
  if (!params) return;
  const [transaction] = await db
    .select()
    .from(transactionsTable)
    .where(eq(transactionsTable.id, params.transactionId))
    .limit(1);
  if (!transaction || !(await businessOwned(userIdOf(req), transaction.businessId))) {
    res.status(404).json({ error: "Transaction not found" });
    return;
  }
  await db.delete(transactionsTable).where(eq(transactionsTable.id, transaction.id));
  await writeSync(userIdOf(req), "transaction", transaction.id, "delete");
  res.sendStatus(204);
});

router.get("/debts", async (req, res): Promise<void> => {
  const query = parseBody(ListDebtsQueryParams, req.query, res);
  if (!query) return;
  if (!(await businessOwned(userIdOf(req), query.businessId))) {
    res.status(404).json({ error: "Business not found" });
    return;
  }
  const rows = await db.select().from(debtsTable).where(eq(debtsTable.businessId, query.businessId)).orderBy(desc(debtsTable.updatedAt));
  res.json(ListDebtsResponse.parse(rows));
});

router.post("/debts", async (req, res): Promise<void> => {
  const data = parseBody(CreateDebtBody, req.body, res);
  if (!data) return;
  if (!(await businessOwned(userIdOf(req), data.businessId))) {
    res.status(404).json({ error: "Business not found" });
    return;
  }
  const [debt] = await db
    .insert(debtsTable)
    .values({
      ...data,
      dueDate: dateOnly(data.dueDate),
      amountPaid: 0,
      remainingBalance: data.originalAmount,
    })
    .returning();
  await writeSync(userIdOf(req), "debt", debt.id, "upsert", recordData(debt));
  res.status(201).json(CreateDebtResponse.parse(debt));
});

router.patch("/debts/:debtId", async (req, res): Promise<void> => {
  const params = parseParams(UpdateDebtParams, req.params, res);
  const data = parseBody(UpdateDebtBody, req.body, res);
  if (!params || !data) return;
  if (!(await businessOwned(userIdOf(req), data.businessId))) {
    res.status(404).json({ error: "Business not found" });
    return;
  }
  const [existing] = await db.select().from(debtsTable).where(eq(debtsTable.id, params.debtId)).limit(1);
  if (!existing || existing.businessId !== data.businessId || !(await businessOwned(userIdOf(req), existing.businessId))) {
    res.status(404).json({ error: "Debt not found" });
    return;
  }
  if (data.originalAmount < existing.amountPaid) {
    res.status(400).json({ error: "Original amount cannot be less than payments already recorded" });
    return;
  }
  const [debt] = await db
    .update(debtsTable)
    .set({
      ...data,
      dueDate: dateOnly(data.dueDate),
      remainingBalance: data.originalAmount - existing.amountPaid,
      updatedAt: new Date(),
    })
    .where(eq(debtsTable.id, existing.id))
    .returning();
  await writeSync(userIdOf(req), "debt", debt.id, "upsert", recordData(debt));
  res.json(UpdateDebtResponse.parse(debt));
});

router.delete("/debts/:debtId", async (req, res): Promise<void> => {
  const params = parseParams(DeleteDebtParams, req.params, res);
  if (!params) return;
  const [debt] = await db.select().from(debtsTable).where(eq(debtsTable.id, params.debtId)).limit(1);
  if (!debt || !(await businessOwned(userIdOf(req), debt.businessId))) {
    res.status(404).json({ error: "Debt not found" });
    return;
  }
  await db.delete(debtsTable).where(eq(debtsTable.id, debt.id));
  await writeSync(userIdOf(req), "debt", debt.id, "delete");
  res.sendStatus(204);
});

router.get("/debts/:debtId/payments", async (req, res): Promise<void> => {
  const params = parseParams(ListDebtPaymentsParams, req.params, res);
  if (!params) return;
  const [debt] = await db.select().from(debtsTable).where(eq(debtsTable.id, params.debtId)).limit(1);
  if (!debt || !(await businessOwned(userIdOf(req), debt.businessId))) {
    res.status(404).json({ error: "Debt not found" });
    return;
  }
  const rows = await db.select().from(debtPaymentsTable).where(eq(debtPaymentsTable.debtId, debt.id)).orderBy(desc(debtPaymentsTable.date), desc(debtPaymentsTable.createdAt));
  res.json(ListDebtPaymentsResponse.parse(rows));
});

router.post("/debts/:debtId/payments", async (req, res): Promise<void> => {
  const params = parseParams(RecordDebtPaymentParams, req.params, res);
  const data = parseBody(RecordDebtPaymentBody, req.body, res);
  if (!params || !data) return;
  const [debt] = await db.select().from(debtsTable).where(eq(debtsTable.id, params.debtId)).limit(1);
  if (!debt || !(await businessOwned(userIdOf(req), debt.businessId))) {
    res.status(404).json({ error: "Debt not found" });
    return;
  }
  const outcome = await db.transaction(async (tx) => {
    const [prior] = await tx
      .select()
      .from(debtPaymentsTable)
      .where(and(eq(debtPaymentsTable.debtId, debt.id), eq(debtPaymentsTable.idempotencyKey, data.idempotencyKey)))
      .limit(1);
    if (prior) return { payment: prior, duplicate: true };
    const [current] = await tx
      .select()
      .from(debtsTable)
      .where(eq(debtsTable.id, debt.id))
      .for("update")
      .limit(1);
    if (!current || data.amount > current.remainingBalance) return { payment: null, duplicate: false };
    const [payment] = await tx
      .insert(debtPaymentsTable)
      .values({
        debtId: current.id,
        amount: data.amount,
        date: dateOnly(data.date)!,
        notes: data.notes,
        idempotencyKey: data.idempotencyKey,
      })
      .returning();
    const [updatedDebt] = await tx
      .update(debtsTable)
      .set({
        amountPaid: current.amountPaid + data.amount,
        remainingBalance: Math.max(0, current.remainingBalance - data.amount),
        updatedAt: new Date(),
      })
      .where(eq(debtsTable.id, current.id))
      .returning();
    return { payment, duplicate: false, updatedDebt };
  });
  if (!outcome.payment) {
    res.status(400).json({ error: "Payment exceeds the remaining balance" });
    return;
  }
  if (!outcome.duplicate) {
    await writeSync(userIdOf(req), "debtPayment", outcome.payment.id, "upsert", {
      ...recordData(outcome.payment),
      idempotencyKey: data.idempotencyKey,
    });
    if (outcome.updatedDebt) {
      await writeSync(userIdOf(req), "debt", outcome.updatedDebt.id, "upsert", recordData(outcome.updatedDebt));
    }
  }
  res.status(201).json(RecordDebtPaymentResponse.parse(outcome.payment));
});

router.get("/products", async (req, res): Promise<void> => {
  const query = parseBody(ListProductsQueryParams, req.query, res);
  if (!query) return;
  if (!(await businessOwned(userIdOf(req), query.businessId))) {
    res.status(404).json({ error: "Business not found" });
    return;
  }
  const rows = await db.select().from(productsTable).where(eq(productsTable.businessId, query.businessId)).orderBy(productsTable.name);
  res.json(ListProductsResponse.parse(rows));
});

router.post("/products", async (req, res): Promise<void> => {
  const data = parseBody(CreateProductBody, req.body, res);
  if (!data) return;
  if (!(await businessOwned(userIdOf(req), data.businessId))) {
    res.status(404).json({ error: "Business not found" });
    return;
  }
  const [product] = await db.insert(productsTable).values(data).returning();
  await writeSync(userIdOf(req), "product", product.id, "upsert", recordData(product));
  res.status(201).json(CreateProductResponse.parse(product));
});

router.patch("/products/:productId", async (req, res): Promise<void> => {
  const params = parseParams(UpdateProductParams, req.params, res);
  const data = parseBody(UpdateProductBody, req.body, res);
  if (!params || !data) return;
  if (!(await businessOwned(userIdOf(req), data.businessId))) {
    res.status(404).json({ error: "Business not found" });
    return;
  }
  const [product] = await db
    .update(productsTable)
    .set({ ...data, updatedAt: new Date() })
    .where(and(eq(productsTable.id, params.productId), eq(productsTable.businessId, data.businessId)))
    .returning();
  if (!product || !(await businessOwned(userIdOf(req), product.businessId))) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  await writeSync(userIdOf(req), "product", product.id, "upsert", recordData(product));
  res.json(UpdateProductResponse.parse(product));
});

router.delete("/products/:productId", async (req, res): Promise<void> => {
  const params = parseParams(DeleteProductParams, req.params, res);
  if (!params) return;
  const [product] = await db.select().from(productsTable).where(eq(productsTable.id, params.productId)).limit(1);
  if (!product || !(await businessOwned(userIdOf(req), product.businessId))) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  await db.delete(productsTable).where(eq(productsTable.id, product.id));
  await writeSync(userIdOf(req), "product", product.id, "delete");
  res.sendStatus(204);
});

router.get("/products/:productId/movements", async (req, res): Promise<void> => {
  const params = parseParams(ListStockMovementsParams, req.params, res);
  if (!params) return;
  const [product] = await db.select().from(productsTable).where(eq(productsTable.id, params.productId)).limit(1);
  if (!product || !(await businessOwned(userIdOf(req), product.businessId))) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  const rows = await db.select().from(stockMovementsTable).where(eq(stockMovementsTable.productId, product.id)).orderBy(desc(stockMovementsTable.date), desc(stockMovementsTable.createdAt));
  res.json(ListStockMovementsResponse.parse(rows));
});

router.post("/products/:productId/movements", async (req, res): Promise<void> => {
  const params = parseParams(CreateStockMovementParams, req.params, res);
  const data = parseBody(CreateStockMovementBody, req.body, res);
  if (!params || !data) return;
  const [product] = await db.select().from(productsTable).where(eq(productsTable.id, params.productId)).limit(1);
  if (!product || !(await businessOwned(userIdOf(req), product.businessId))) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  const outcome = await db.transaction(async (tx) => {
    const [prior] = await tx
      .select()
      .from(stockMovementsTable)
      .where(and(eq(stockMovementsTable.productId, product.id), eq(stockMovementsTable.idempotencyKey, data.idempotencyKey)))
      .limit(1);
    if (prior) return { movement: prior, duplicate: true };
    const [currentProduct] = await tx
      .select()
      .from(productsTable)
      .where(eq(productsTable.id, product.id))
      .for("update")
      .limit(1);
    if (!currentProduct) return { movement: null, duplicate: false };
    const nextQuantity =
      data.type === "stock_in"
        ? currentProduct.quantity + data.quantity
        : data.type === "stock_out"
          ? currentProduct.quantity - data.quantity
          : data.quantity;
    if (nextQuantity < 0) return { movement: null, duplicate: false };
    const [movement] = await tx
      .insert(stockMovementsTable)
      .values({
        productId: product.id,
        type: data.type,
        quantity: data.quantity,
        date: dateOnly(data.date)!,
        note: data.note,
        idempotencyKey: data.idempotencyKey,
      })
      .returning();
    const [updatedProduct] = await tx
      .update(productsTable)
      .set({ quantity: nextQuantity, updatedAt: new Date() })
      .where(eq(productsTable.id, currentProduct.id))
      .returning();
    return { movement, duplicate: false, updatedProduct };
  });
  if (!outcome.movement) {
    res.status(400).json({ error: "Stock cannot fall below zero" });
    return;
  }
  if (!outcome.duplicate) {
    await writeSync(userIdOf(req), "stockMovement", outcome.movement.id, "upsert", {
      ...recordData(outcome.movement),
      idempotencyKey: data.idempotencyKey,
    });
    if (outcome.updatedProduct) {
      await writeSync(userIdOf(req), "product", outcome.updatedProduct.id, "upsert", recordData(outcome.updatedProduct));
    }
  }
  res.status(201).json(CreateStockMovementResponse.parse(outcome.movement));
});

router.get("/reports/summary", async (req, res): Promise<void> => {
  const query = parseBody(GetBusinessReportQueryParams, req.query, res);
  if (!query) return;
  if (!(await businessOwned(userIdOf(req), query.businessId))) {
    res.status(404).json({ error: "Business not found" });
    return;
  }
  if (query.from > query.to) {
    res.status(400).json({ error: "from must be on or before to" });
    return;
  }
  const transactions = await db
    .select()
    .from(transactionsTable)
    .where(and(
      eq(transactionsTable.businessId, query.businessId),
      gte(transactionsTable.date, query.from),
      lte(transactionsTable.date, query.to),
    ))
    .orderBy(desc(transactionsTable.date));
  const debts = await db
    .select()
    .from(debtsTable)
    .where(and(
      eq(debtsTable.businessId, query.businessId),
      gte(debtsTable.createdAt, new Date(`${query.from}T00:00:00.000Z`)),
      lte(debtsTable.createdAt, new Date(`${query.to}T23:59:59.999Z`)),
    ));
  const totalIncome = transactions.reduce((sum, row) => sum + (row.type === "income" ? row.amount : 0), 0);
  const totalExpenses = transactions.reduce((sum, row) => sum + (row.type === "expense" ? row.amount : 0), 0);
  res.json(GetBusinessReportResponse.parse({
    businessId: query.businessId,
    from: query.from,
    to: query.to,
    totalIncome,
    totalExpenses,
    netProfit: totalIncome - totalExpenses,
    customerDebt: debts.reduce((sum, row) => sum + (row.direction === "customer_owes" ? row.remainingBalance : 0), 0),
    supplierDebt: debts.reduce((sum, row) => sum + (row.direction === "supplier_owed" ? row.remainingBalance : 0), 0),
    transactionCount: transactions.length,
    transactions,
  }));
});

async function getEntityOwner(entity: Entity, id: string): Promise<string | null> {
  if (entity === "business") return businessOwner(id);
  if (entity === "transaction") {
    const [row] = await db.select({ businessId: transactionsTable.businessId }).from(transactionsTable).where(eq(transactionsTable.id, id)).limit(1);
    return row ? businessOwner(row.businessId) : null;
  }
  if (entity === "debt" || entity === "debtPayment") {
    const [payment] = entity === "debtPayment"
      ? await db.select({ debtId: debtPaymentsTable.debtId }).from(debtPaymentsTable).where(eq(debtPaymentsTable.id, id)).limit(1)
      : [];
    const debtId = entity === "debtPayment" ? payment?.debtId : id;
    if (!debtId) return null;
    const [row] = await db.select({ businessId: debtsTable.businessId }).from(debtsTable).where(eq(debtsTable.id, debtId)).limit(1);
    return row ? businessOwner(row.businessId) : null;
  }
  if (entity === "product") {
    const [row] = await db.select({ businessId: productsTable.businessId }).from(productsTable).where(eq(productsTable.id, id)).limit(1);
    return row ? businessOwner(row.businessId) : null;
  }
  const [movement] = await db.select({ productId: stockMovementsTable.productId }).from(stockMovementsTable).where(eq(stockMovementsTable.id, id)).limit(1);
  if (!movement) return null;
  const [product] = await db.select({ businessId: productsTable.businessId }).from(productsTable).where(eq(productsTable.id, movement.productId)).limit(1);
  return product ? businessOwner(product.businessId) : null;
}

async function applySyncChange(userId: string, change: SyncInput): Promise<void> {
  const data = change.data;
  if (change.operation === "delete") {
    const owner = await getEntityOwner(change.entity, change.id);
    if (owner && owner !== userId) throw new Error("Record belongs to another account");
    if (owner === userId) {
      if (change.entity === "business") await db.delete(businessesTable).where(eq(businessesTable.id, change.id));
      else if (change.entity === "transaction") await db.delete(transactionsTable).where(eq(transactionsTable.id, change.id));
      else if (change.entity === "debt") await db.delete(debtsTable).where(eq(debtsTable.id, change.id));
      else if (change.entity === "debtPayment") await db.delete(debtPaymentsTable).where(eq(debtPaymentsTable.id, change.id));
      else if (change.entity === "product") await db.delete(productsTable).where(eq(productsTable.id, change.id));
      else await db.delete(stockMovementsTable).where(eq(stockMovementsTable.id, change.id));
    }
    await writeSync(userId, change.entity, change.id, "delete");
    return;
  }

  if (change.entity === "business") {
    const body = CreateBusinessBody.parse(data);
    const owner = await getEntityOwner("business", change.id);
    if (owner && owner !== userId) throw new Error("Record belongs to another account");
    const [record] = await db.insert(businessesTable).values({
      id: change.id,
      ownerId: userId,
      ...body,
      updatedAt: new Date(change.updatedAt),
    }).onConflictDoUpdate({
      target: businessesTable.id,
      set: { ownerId: userId, ...body, updatedAt: new Date(change.updatedAt) },
    }).returning();
    await writeSync(userId, "business", record.id, "upsert", recordData(record));
    return;
  }

  if (change.entity === "transaction") {
    const body = CreateTransactionBody.parse(data);
    if (!(await businessOwned(userId, body.businessId))) throw new Error("Business is not available to this account");
    const owner = await getEntityOwner("transaction", change.id);
    if (owner && owner !== userId) throw new Error("Record belongs to another account");
    const [record] = await db.insert(transactionsTable).values({
      id: change.id,
      ...body,
      date: dateOnly(body.date)!,
      updatedAt: new Date(change.updatedAt),
    }).onConflictDoUpdate({
      target: transactionsTable.id,
      set: { ...body, date: dateOnly(body.date)!, updatedAt: new Date(change.updatedAt) },
    }).returning();
    await writeSync(userId, "transaction", record.id, "upsert", recordData(record));
    return;
  }

  if (change.entity === "debt") {
    const body = CreateDebtBody.parse(data);
    if (!(await businessOwned(userId, body.businessId))) throw new Error("Business is not available to this account");
    const owner = await getEntityOwner("debt", change.id);
    if (owner && owner !== userId) throw new Error("Record belongs to another account");
    const [existing] = await db.select().from(debtsTable).where(eq(debtsTable.id, change.id)).limit(1);
    const amountPaid = existing?.amountPaid ?? 0;
    if (body.originalAmount < amountPaid) throw new Error("Original amount cannot be less than payments already recorded");
    const [record] = await db.insert(debtsTable).values({
      id: change.id,
      ...body,
      dueDate: dateOnly(body.dueDate),
      amountPaid,
      remainingBalance: body.originalAmount - amountPaid,
      updatedAt: new Date(change.updatedAt),
    }).onConflictDoUpdate({
      target: debtsTable.id,
      set: {
        ...body,
        dueDate: dateOnly(body.dueDate),
        remainingBalance: body.originalAmount - amountPaid,
        updatedAt: new Date(change.updatedAt),
      },
    }).returning();
    await writeSync(userId, "debt", record.id, "upsert", recordData(record));
    return;
  }

  if (change.entity === "debtPayment") {
    const debtId = typeof data.debtId === "string" ? data.debtId : "";
    const amount = typeof data.amount === "number" ? data.amount : 0;
    const paymentDate = typeof data.date === "string" ? data.date : "";
    const idempotencyKey = typeof data.idempotencyKey === "string" ? data.idempotencyKey : `offline:${change.id}`;
    const [debt] = await db.select().from(debtsTable).where(eq(debtsTable.id, debtId)).limit(1);
    if (!debt || !(await businessOwned(userId, debt.businessId))) throw new Error("Debt is not available to this account");
    const owner = await getEntityOwner("debtPayment", change.id);
    if (owner && owner !== userId) throw new Error("Record belongs to another account");
    const [prior] = await db.select().from(debtPaymentsTable).where(and(
      eq(debtPaymentsTable.debtId, debt.id),
      eq(debtPaymentsTable.idempotencyKey, idempotencyKey),
    )).limit(1);
    if (prior) return;
    if (amount <= 0 || amount > debt.remainingBalance) throw new Error("Payment exceeds the remaining balance");
    const [payment] = await db.insert(debtPaymentsTable).values({
      id: change.id,
      debtId: debt.id,
      amount,
      date: paymentDate,
      notes: typeof data.notes === "string" ? data.notes : null,
      idempotencyKey,
    }).returning();
    const [updatedDebt] = await db.update(debtsTable).set({
      amountPaid: debt.amountPaid + amount,
      remainingBalance: Math.max(0, debt.remainingBalance - amount),
      updatedAt: new Date(),
    }).where(eq(debtsTable.id, debt.id)).returning();
    await writeSync(userId, "debtPayment", payment.id, "upsert", { ...recordData(payment), idempotencyKey });
    await writeSync(userId, "debt", updatedDebt.id, "upsert", recordData(updatedDebt));
    return;
  }

  if (change.entity === "product") {
    const body = CreateProductBody.parse(data);
    if (!(await businessOwned(userId, body.businessId))) throw new Error("Business is not available to this account");
    const owner = await getEntityOwner("product", change.id);
    if (owner && owner !== userId) throw new Error("Record belongs to another account");
    const [record] = await db.insert(productsTable).values({
      id: change.id,
      ...body,
      updatedAt: new Date(change.updatedAt),
    }).onConflictDoUpdate({
      target: productsTable.id,
      set: { ...body, updatedAt: new Date(change.updatedAt) },
    }).returning();
    await writeSync(userId, "product", record.id, "upsert", recordData(record));
    return;
  }

  const productId = typeof data.productId === "string" ? data.productId : "";
  const [product] = await db.select().from(productsTable).where(eq(productsTable.id, productId)).limit(1);
  if (!product || !(await businessOwned(userId, product.businessId))) throw new Error("Product is not available to this account");
  const owner = await getEntityOwner("stockMovement", change.id);
  if (owner && owner !== userId) throw new Error("Record belongs to another account");
  const idempotencyKey = typeof data.idempotencyKey === "string" ? data.idempotencyKey : `offline:${change.id}`;
  const [prior] = await db.select().from(stockMovementsTable).where(and(
    eq(stockMovementsTable.productId, product.id),
    eq(stockMovementsTable.idempotencyKey, idempotencyKey),
  )).limit(1);
  if (prior) return;
  const type = data.type;
  const quantity = typeof data.quantity === "number" ? data.quantity : 0;
  const nextQuantity =
    type === "stock_in" ? product.quantity + quantity :
      type === "stock_out" ? product.quantity - quantity :
        type === "adjustment" ? quantity : -1;
  if (quantity <= 0 || nextQuantity < 0) throw new Error("Invalid stock movement or insufficient stock");
  const [movement] = await db.insert(stockMovementsTable).values({
    id: change.id,
    productId: product.id,
    type: type as "stock_in" | "stock_out" | "adjustment",
    quantity,
    date: typeof data.date === "string" ? data.date : "",
    note: typeof data.note === "string" ? data.note : null,
    idempotencyKey,
  }).returning();
  const [updatedProduct] = await db.update(productsTable).set({ quantity: nextQuantity, updatedAt: new Date() }).where(eq(productsTable.id, product.id)).returning();
  await writeSync(userId, "stockMovement", movement.id, "upsert", { ...recordData(movement), idempotencyKey });
  await writeSync(userId, "product", updatedProduct.id, "upsert", recordData(updatedProduct));
}

router.post("/sync/push", async (req, res): Promise<void> => {
  const body = parseBody(PushSyncChangesBody, req.body, res);
  if (!body) return;
  const accepted: string[] = [];
  const rejected: { id: string; reason: string }[] = [];
  for (const item of body.changes as SyncInput[]) {
    try {
      await applySyncChange(userIdOf(req), item);
      accepted.push(item.id);
    } catch (error) {
      const reason = error instanceof Error ? error.message : "Change could not be applied";
      rejected.push({ id: item.id, reason });
      req.log.warn({ entity: item.entity, recordId: item.id, reason }, "Rejected offline sync change");
    }
  }
  res.json(PushSyncChangesResponse.parse({ accepted, rejected }));
});

router.get("/sync/pull", async (req, res): Promise<void> => {
  const query = parseBody(PullSyncChangesQueryParams, req.query, res);
  if (!query) return;
  const userId = userIdOf(req);
  const businesses = await db.select().from(businessesTable).where(eq(businessesTable.ownerId, userId));
  const ownedBusinessIds = businesses.map((row) => row.id);
  const allTransactions = ownedBusinessIds.length
    ? await db.select().from(transactionsTable).where(inArray(transactionsTable.businessId, ownedBusinessIds))
    : [];
  const allDebts = ownedBusinessIds.length
    ? await db.select().from(debtsTable).where(inArray(debtsTable.businessId, ownedBusinessIds))
    : [];
  const allProducts = ownedBusinessIds.length
    ? await db.select().from(productsTable).where(inArray(productsTable.businessId, ownedBusinessIds))
    : [];
  const ownedDebtIds = allDebts.map((row) => row.id);
  const ownedProductIds = allProducts.map((row) => row.id);
  const debtPayments = ownedDebtIds.length
    ? await db.select().from(debtPaymentsTable).where(inArray(debtPaymentsTable.debtId, ownedDebtIds))
    : [];
  const stockMovements = ownedProductIds.length
    ? await db.select().from(stockMovementsTable).where(inArray(stockMovementsTable.productId, ownedProductIds))
    : [];
  const changedAfter = query.since ? new Date(query.since) : null;
  const events = changedAfter
    ? await db.select().from(syncChangesTable).where(and(
        eq(syncChangesTable.ownerId, userId),
        gte(syncChangesTable.updatedAt, changedAfter),
      )).orderBy(syncChangesTable.updatedAt)
    : [];
  const deleted = events
    .filter((event) => event.operation === "delete")
    .map((event) => ({
      entity: event.entity,
      id: event.recordId,
      operation: event.operation,
      data: event.data,
      updatedAt: event.updatedAt.toISOString(),
    }));
  const cursor = new Date().toISOString();
  res.json(PullSyncChangesResponse.parse({
    cursor,
    businesses,
    transactions: allTransactions,
    debts: allDebts,
    debtPayments,
    products: allProducts,
    stockMovements,
    deleted,
  }));
});

router.use((error: unknown, req: Request, res: Response, _next: NextFunction) => {
  req.log.error({ err: error }, "SMARTBIZ API request failed");
  res.status(500).json({ error: "The request could not be completed" });
});

export default router;
