import { Router, type IRouter, type Request, type Response } from "express";
import { requireAuth } from "../middlewares/auth";
import { objectStorageService } from "../lib/objectStorage";

const router: IRouter = Router();
const allowedContentTypes = new Set(["image/jpeg", "image/png", "image/webp"]);
const maxPosterBytes = 8 * 1024 * 1024;

router.post("/storage/uploads/request-url", requireAuth, async (req: Request, res: Response, next) => {
  try {
    const { name, size, contentType } = req.body ?? {};
    if (
      typeof name !== "string" ||
      name.trim().length < 1 ||
      !Number.isInteger(size) ||
      size < 1 ||
      size > maxPosterBytes ||
      typeof contentType !== "string" ||
      !allowedContentTypes.has(contentType)
    ) {
      res.status(400).json({ error: "Upload a JPEG, PNG, or WebP poster up to 8 MB" });
      return;
    }
    res.json(await objectStorageService.createPosterUpload());
  } catch (error) {
    next(error);
  }
});

router.get("/storage/objects/*objectPath", async (req: Request, res: Response, next) => {
  try {
    const rawPath = req.params.objectPath;
    const objectPath = `/objects/${Array.isArray(rawPath) ? rawPath.join("/") : rawPath}`;
    const signedUrl = await objectStorageService.getPosterDownloadUrl(objectPath);
    const head = await fetch(signedUrl, { method: "HEAD", signal: AbortSignal.timeout(15_000) });
    if (!head.ok) {
      res.status(404).json({ error: "Poster not found" });
      return;
    }
    res.setHeader("Cache-Control", "public, max-age=900");
    res.redirect(302, signedUrl);
  } catch (error) {
    if (error instanceof Error && error.message === "Invalid poster path") {
      res.status(404).json({ error: "Poster not found" });
      return;
    }
    next(error);
  }
});

export default router;