import { and, desc, eq, inArray } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  checkinsTable,
  db,
  eventsTable,
  eventSuggestionsTable,
  reviewsTable,
  savedEventsTable,
  usersTable,
} from "@workspace/db";
import { getAuth } from "@clerk/express";
import { getOrCreateUser, requireAuth, type AuthenticatedRequest } from "../middlewares/auth";
import { objectStorageService } from "../lib/objectStorage";

const router: IRouter = Router();

function toPublicEvent(event: typeof eventsTable.$inferSelect, saved = false, checkedIn = false) {
  return {
    id: event.id,
    name: event.name,
    venue: event.venue,
    address: event.address,
    city: event.city,
    country: event.country,
    eventDate: event.eventDate.toISOString(),
    endDate: event.endDate.toISOString(),
    basePriceJmd: event.basePriceJmd,
    fees: [
      ...(event.serviceFeeJmd ? [{ name: "Venue service fee", amount: event.serviceFeeJmd }] : []),
      ...(event.doorChargeJmd ? [{ name: "Door charge", amount: event.doorChargeJmd }] : []),
    ],
    totalPriceJmd: event.basePriceJmd + event.serviceFeeJmd + event.doorChargeJmd,
    vibeTags: event.vibeTags,
    crowdLevel: event.crowdLevel,
    crowdLabel: event.crowdLabel,
    rating: event.rating,
    reviewCount: event.reviewCount,
    accent: event.accent,
    mark: event.mark,
    description: event.description,
    posterUrl: event.posterPath
      ? `/api/storage/objects/${event.posterPath.replace(/^\/objects\//, "")}`
      : null,
    latitude: event.latitude,
    longitude: event.longitude,
    isSaved: saved,
    isCheckedIn: checkedIn,
  };
}

function parseDate(value: unknown) {
  if (typeof value !== "string") return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function parsePosterExtraction(value: unknown) {
  if (!value || typeof value !== "object") return null;
  const record = value as Record<string, unknown>;
  const numberOrNull = (candidate: unknown) => typeof candidate === "number" && Number.isFinite(candidate) ? candidate : null;
  const stringOrNull = (candidate: unknown) => typeof candidate === "string" && candidate.trim() ? candidate.trim() : null;
  return {
    name: stringOrNull(record.name),
    venue: stringOrNull(record.venue),
    address: stringOrNull(record.address),
    eventDate: stringOrNull(record.eventDate),
    endDate: stringOrNull(record.endDate),
    basePriceJmd: numberOrNull(record.basePriceJmd),
    serviceFeeJmd: numberOrNull(record.serviceFeeJmd),
    doorChargeJmd: numberOrNull(record.doorChargeJmd),
    vibeTags: Array.isArray(record.vibeTags) ? record.vibeTags.filter((tag): tag is string => typeof tag === "string").slice(0, 5) : [],
    description: stringOrNull(record.description),
  };
}

async function getUserEventState(clerkUserId: string | null | undefined, eventIds: number[]) {
  if (!clerkUserId || eventIds.length === 0) return { saved: new Set<number>(), checkedIn: new Set<number>() };
  const user = await getOrCreateUser(clerkUserId);
  const [saved, checkedIn] = await Promise.all([
    db.select({ eventId: savedEventsTable.eventId }).from(savedEventsTable).where(and(eq(savedEventsTable.userId, user.id), inArray(savedEventsTable.eventId, eventIds))),
    db.select({ eventId: checkinsTable.eventId }).from(checkinsTable).where(and(eq(checkinsTable.userId, user.id), inArray(checkinsTable.eventId, eventIds))),
  ]);
  return {
    saved: new Set(saved.map((item) => item.eventId)),
    checkedIn: new Set(checkedIn.map((item) => item.eventId)),
  };
}

router.get("/events", async (req, res, next) => {
  try {
    const filter = typeof req.query.filter === "string" ? req.query.filter : undefined;
    const events = await db.select().from(eventsTable).where(eq(eventsTable.isPublished, true)).orderBy(eventsTable.eventDate);
    const filtered = filter && filter !== "Tonight"
      ? events.filter((event) => event.vibeTags.some((tag) => tag.toLowerCase() === filter.toLowerCase()))
      : events;
    const state = await getUserEventState(getAuth(req).userId, filtered.map((event) => event.id));
    res.json({ events: filtered.map((event) => toPublicEvent(event, state.saved.has(event.id), state.checkedIn.has(event.id))) });
  } catch (error) {
    next(error);
  }
});

router.get("/events/:eventId", async (req, res, next) => {
  try {
    const eventId = Number(req.params.eventId);
    if (!Number.isInteger(eventId)) {
      res.status(400).json({ error: "Invalid event id" });
      return;
    }
    const event = await db.select().from(eventsTable).where(and(eq(eventsTable.id, eventId), eq(eventsTable.isPublished, true))).limit(1);
    if (!event[0]) {
      res.status(404).json({ error: "Event not found" });
      return;
    }
    const reviews = await db.select({
      id: reviewsTable.id,
      rating: reviewsTable.rating,
      comment: reviewsTable.comment,
      tag: reviewsTable.tag,
      createdAt: reviewsTable.createdAt,
      displayName: usersTable.displayName,
    }).from(reviewsTable).innerJoin(usersTable, eq(usersTable.id, reviewsTable.userId)).where(eq(reviewsTable.eventId, eventId)).orderBy(desc(reviewsTable.createdAt)).limit(20);
    const state = await getUserEventState(getAuth(req).userId, [eventId]);
    res.json({
      event: toPublicEvent(event[0], state.saved.has(eventId), state.checkedIn.has(eventId)),
      reviews: reviews.map((review) => ({
        id: review.id,
        rating: review.rating,
        comment: review.comment,
        tag: review.tag,
        createdAt: review.createdAt.toISOString(),
        author: review.displayName || "Bounce member",
        verified: true,
      })),
    });
  } catch (error) {
    next(error);
  }
});

router.get("/me/saved-events", requireAuth, async (req, res, next) => {
  try {
    const user = await getOrCreateUser((req as AuthenticatedRequest).userId);
    const saved = await db.select({ event: eventsTable }).from(savedEventsTable).innerJoin(eventsTable, eq(eventsTable.id, savedEventsTable.eventId)).where(eq(savedEventsTable.userId, user.id)).orderBy(desc(savedEventsTable.createdAt));
    res.json({ events: saved.map(({ event }) => toPublicEvent(event, true, false)) });
  } catch (error) {
    next(error);
  }
});

router.post("/events/:eventId/save", requireAuth, async (req, res, next) => {
  try {
    const eventId = Number(req.params.eventId);
    const user = await getOrCreateUser((req as AuthenticatedRequest).userId);
    const event = await db.select({ id: eventsTable.id }).from(eventsTable).where(eq(eventsTable.id, eventId)).limit(1);
    if (!event[0]) {
      res.status(404).json({ error: "Event not found" });
      return;
    }
    await db.insert(savedEventsTable).values({ userId: user.id, eventId }).onConflictDoNothing();
    res.status(201).json({ saved: true });
  } catch (error) {
    next(error);
  }
});

router.delete("/events/:eventId/save", requireAuth, async (req, res, next) => {
  try {
    const eventId = Number(req.params.eventId);
    const user = await getOrCreateUser((req as AuthenticatedRequest).userId);
    await db.delete(savedEventsTable).where(and(eq(savedEventsTable.userId, user.id), eq(savedEventsTable.eventId, eventId)));
    res.status(204).end();
  } catch (error) {
    next(error);
  }
});

router.post("/events/:eventId/check-in", requireAuth, async (req, res, next) => {
  try {
    const eventId = Number(req.params.eventId);
    const user = await getOrCreateUser((req as AuthenticatedRequest).userId);
    const event = await db.select({ id: eventsTable.id }).from(eventsTable).where(eq(eventsTable.id, eventId)).limit(1);
    if (!event[0]) {
      res.status(404).json({ error: "Event not found" });
      return;
    }
    await db.insert(checkinsTable).values({ userId: user.id, eventId }).onConflictDoNothing();
    res.status(201).json({ checkedIn: true });
  } catch (error) {
    next(error);
  }
});

router.post("/events/:eventId/reviews", requireAuth, async (req, res, next) => {
  try {
    const eventId = Number(req.params.eventId);
    const rating = Number(req.body?.rating);
    const comment = typeof req.body?.comment === "string" ? req.body.comment.trim() : "";
    const tag = typeof req.body?.tag === "string" ? req.body.tag.trim().slice(0, 80) : null;
    if (!Number.isInteger(eventId) || !Number.isInteger(rating) || rating < 1 || rating > 5 || comment.length < 10 || comment.length > 500) {
      res.status(400).json({ error: "Rating must be 1–5 and comment must be 10–500 characters" });
      return;
    }
    const user = await getOrCreateUser((req as AuthenticatedRequest).userId);
    const event = await db.select().from(eventsTable).where(eq(eventsTable.id, eventId)).limit(1);
    if (!event[0]) {
      res.status(404).json({ error: "Event not found" });
      return;
    }
    const existing = await db.select({ id: reviewsTable.id }).from(reviewsTable).where(and(eq(reviewsTable.userId, user.id), eq(reviewsTable.eventId, eventId))).limit(1);
    if (existing[0]) {
      res.status(409).json({ error: "You already reviewed this event" });
      return;
    }
    const checkin = await db.select({ id: checkinsTable.id }).from(checkinsTable).where(and(eq(checkinsTable.userId, user.id), eq(checkinsTable.eventId, eventId))).limit(1);
    if (!checkin[0]) {
      res.status(403).json({ error: "Check in before reviewing this event" });
      return;
    }
    const inserted = await db.insert(reviewsTable).values({ userId: user.id, eventId, rating, comment, tag }).returning();
    const nextCount = event[0].reviewCount + 1;
    const nextRating = ((event[0].rating * event[0].reviewCount) + rating) / nextCount;
    await db.update(eventsTable).set({ reviewCount: nextCount, rating: Number(nextRating.toFixed(2)), updatedAt: new Date() }).where(eq(eventsTable.id, eventId));
    if (!inserted[0]) {
      res.status(500).json({ error: "Could not publish review" });
      return;
    }
    res.status(201).json({
      review: {
        id: inserted[0].id,
        rating: inserted[0].rating,
        comment: inserted[0].comment,
        tag: inserted[0].tag,
        createdAt: inserted[0].createdAt.toISOString(),
        author: user.displayName || "Bounce member",
        verified: true,
      },
    });
  } catch (error) {
    next(error);
  }
});

router.post("/poster-extractions", requireAuth, async (req, res, next) => {
  try {
    const objectPath = typeof req.body?.objectPath === "string" ? req.body.objectPath : "";
    const contentType = typeof req.body?.contentType === "string" ? req.body.contentType : "";
    if (!/^\/objects\/uploads\/[0-9a-f-]{36}$/i.test(objectPath) || !["image/jpeg", "image/png", "image/webp"].includes(contentType)) {
      res.status(400).json({ error: "A valid uploaded poster is required" });
      return;
    }
    if (!process.env.GEMINI_API_KEY) {
      res.status(503).json({ error: "Poster extraction is not configured" });
      return;
    }
    const signedUrl = await objectStorageService.getPosterDownloadUrl(objectPath);
    const posterResponse = await fetch(signedUrl, { signal: AbortSignal.timeout(30_000) });
    if (!posterResponse.ok) {
      res.status(422).json({ error: "The uploaded poster could not be read" });
      return;
    }
    const bytes = Buffer.from(await posterResponse.arrayBuffer());
    if (bytes.byteLength > 8 * 1024 * 1024) {
      res.status(422).json({ error: "Poster is larger than 8 MB" });
      return;
    }
    const prompt = `Read this Jamaican nightlife party poster and return ONLY valid JSON with exactly these keys:
name, venue, address, eventDate, endDate, basePriceJmd, serviceFeeJmd, doorChargeJmd, vibeTags, description.
Use ISO 8601 timestamps with the Jamaica timezone offset when a date and time are visible. If a value is not visible, use null. Prices must be whole numbers in Jamaican dollars, with 0 for fees that are not listed. vibeTags must be a short array of up to five strings. The current date is ${new Date().toISOString().slice(0, 10)}.`;
    const aiResponse = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(process.env.GEMINI_API_KEY)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }, { inline_data: { mime_type: contentType, data: bytes.toString("base64") } }] }],
        generationConfig: { responseMimeType: "application/json", temperature: 0.1 },
      }),
      signal: AbortSignal.timeout(60_000),
    });
    if (!aiResponse.ok) {
      res.status(422).json({ error: "Poster details could not be extracted" });
      return;
    }
    const aiBody = (await aiResponse.json()) as { candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }> };
    const text = aiBody.candidates?.[0]?.content?.parts?.find((part) => part.text)?.text;
    if (!text) {
      res.status(422).json({ error: "Poster details could not be extracted" });
      return;
    }
    const extraction = parsePosterExtraction(JSON.parse(text));
    if (!extraction) {
      res.status(422).json({ error: "Poster details could not be extracted" });
      return;
    }
    res.json(extraction);
  } catch (error) {
    if (error instanceof SyntaxError) {
      res.status(422).json({ error: "Poster details were not valid JSON" });
      return;
    }
    next(error);
  }
});

router.post("/events/from-poster", requireAuth, async (req, res, next) => {
  try {
    const body = req.body ?? {};
    const name = typeof body.name === "string" ? body.name.trim() : "";
    const venue = typeof body.venue === "string" ? body.venue.trim() : "";
    const address = typeof body.address === "string" ? body.address.trim() : "";
    const eventDate = parseDate(body.eventDate);
    const endDate = parseDate(body.endDate);
    const posterPath = typeof body.posterPath === "string" ? body.posterPath : "";
    const vibeTags = Array.isArray(body.vibeTags)
      ? body.vibeTags
        .filter((tag: unknown): tag is string => typeof tag === "string" && tag.trim().length > 0)
        .map((tag: string) => tag.trim())
        .slice(0, 5)
      : [];
    const moneyFields = ["basePriceJmd", "serviceFeeJmd", "doorChargeJmd"] as const;
    const amounts = Object.fromEntries(moneyFields.map((key) => [key, body[key]])) as Record<string, unknown>;
    if (
      name.length < 2 || venue.length < 2 || address.length < 2 ||
      !eventDate || !endDate || endDate <= eventDate ||
      vibeTags.length === 0 || typeof body.description !== "string" || body.description.trim().length < 10 ||
      !/^\/objects\/uploads\/[0-9a-f-]{36}$/i.test(posterPath) ||
      moneyFields.some((key) => !Number.isInteger(amounts[key]) || Number(amounts[key]) < 0)
    ) {
      res.status(400).json({ error: "Confirm the poster details, date, address, price, and vibe before publishing" });
      return;
    }
    const user = await getOrCreateUser((req as AuthenticatedRequest).userId);
    const [created] = await db.insert(eventsTable).values({
      name,
      venue,
      address,
      eventDate,
      endDate,
      basePriceJmd: Number(amounts.basePriceJmd),
      serviceFeeJmd: Number(amounts.serviceFeeJmd),
      doorChargeJmd: Number(amounts.doorChargeJmd),
      vibeTags,
      description: body.description.trim(),
      posterPath,
      latitude: typeof body.latitude === "number" ? body.latitude : 18.0179,
      longitude: typeof body.longitude === "number" ? body.longitude : -76.8099,
      isPublished: true,
      mark: "NEW",
      accent: "#ff4f9a",
    }).returning();
    if (!created) {
      res.status(500).json({ error: "Could not create event" });
      return;
    }
    res.status(201).json({ event: toPublicEvent(created, false, false) });
  } catch (error) {
    next(error);
  }
});

router.post("/event-suggestions", requireAuth, async (req, res, next) => {
  try {
    const name = typeof req.body?.name === "string" ? req.body.name.trim() : "";
    const venue = typeof req.body?.venue === "string" ? req.body.venue.trim() : "";
    const notes = typeof req.body?.notes === "string" ? req.body.notes.trim() : "";
    const eventDate = typeof req.body?.eventDate === "string" ? new Date(req.body.eventDate) : null;
    if (name.length < 2 || venue.length < 2 || notes.length < 5 || (eventDate && Number.isNaN(eventDate.getTime()))) {
      res.status(400).json({ error: "Event name, venue, and notes are required" });
      return;
    }
    const user = await getOrCreateUser((req as AuthenticatedRequest).userId);
    const suggestion = await db.insert(eventSuggestionsTable).values({ userId: user.id, name, venue, notes, eventDate }).returning();
    res.status(201).json({ suggestion: suggestion[0] });
  } catch (error) {
    next(error);
  }
});

export default router;