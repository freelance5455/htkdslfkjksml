import { db, pool } from "@workspace/db";
import {
  availabilityTable,
  professionalsTable,
  usersTable,
} from "@workspace/db/schema";

const providers = [
  {
    id: "demo-doctor-01",
    fullName: "Dr. Lina Benali",
    role: "DOCTOR" as const,
    specialty: "Cardiologie",
    experienceYears: 14,
    price: 3500,
    rating: 4.9,
    reviewCount: 87,
    gender: "female",
    bio: "Cardiologue attentive, spécialisée dans la prévention et le suivi des maladies cardiovasculaires.",
  },
  {
    id: "demo-doctor-02",
    fullName: "Dr. Yacine Haddad",
    role: "DOCTOR" as const,
    specialty: "Médecine générale",
    experienceYears: 11,
    price: 2500,
    rating: 4.8,
    reviewCount: 64,
    gender: "male",
    bio: "Médecin généraliste, accompagne les patients dans leur suivi médical quotidien.",
  },
  {
    id: "demo-doctor-03",
    fullName: "Dr. Amel Khelifi",
    role: "DOCTOR" as const,
    specialty: "Pédiatrie",
    experienceYears: 9,
    price: 3000,
    rating: 4.9,
    reviewCount: 53,
    gender: "female",
    bio: "Pédiatre, assure un suivi bienveillant de la santé des enfants et des adolescents.",
  },
  {
    id: "demo-doctor-04",
    fullName: "Dr. Karim Boudiaf",
    role: "DOCTOR" as const,
    specialty: "Dermatologie",
    experienceYears: 16,
    price: 4000,
    rating: 4.7,
    reviewCount: 72,
    gender: "male",
    bio: "Dermatologue avec une pratique axée sur la prévention et des soins fondés sur les preuves.",
  },
  {
    id: "demo-doctor-05",
    fullName: "Dr. Nouria Amrani",
    role: "DOCTOR" as const,
    specialty: "Médecine générale",
    experienceYears: 7,
    price: 2200,
    rating: 4.8,
    reviewCount: 41,
    gender: "female",
    bio: "Médecin de famille, privilégie l'écoute et des conseils clairs adaptés à chaque patient.",
  },
  {
    id: "demo-nurse-01",
    fullName: "Infirmière Sara Toumi",
    role: "NURSE" as const,
    specialty: "Soins infirmiers",
    experienceYears: 8,
    price: 1800,
    rating: 4.9,
    reviewCount: 32,
    gender: "female",
    bio: "Infirmière diplômée, accompagne les patients dans leurs soins et leur convalescence.",
  },
  {
    id: "demo-nurse-02",
    fullName: "Infirmier Mehdi Ouali",
    role: "NURSE" as const,
    specialty: "Éducation thérapeutique",
    experienceYears: 10,
    price: 2000,
    rating: 4.7,
    reviewCount: 28,
    gender: "male",
    bio: "Infirmier spécialisé dans l'accompagnement et l'éducation thérapeutique des patients.",
  },
  {
    id: "demo-nurse-03",
    fullName: "Infirmière Rania Cherif",
    role: "NURSE" as const,
    specialty: "Suivi à domicile",
    experienceYears: 6,
    price: 1700,
    rating: 4.8,
    reviewCount: 22,
    gender: "female",
    bio: "Infirmière, propose des conseils de suivi et de récupération adaptés à chaque situation.",
  },
  {
    id: "demo-specialist-01",
    fullName: "Dr. Samir Aït Ali",
    role: "SPECIALIST" as const,
    specialty: "Endocrinologie",
    experienceYears: 18,
    price: 4500,
    rating: 4.9,
    reviewCount: 96,
    gender: "male",
    bio: "Endocrinologue, accompagne les patients dans la prise en charge des troubles hormonaux.",
  },
  {
    id: "demo-specialist-02",
    fullName: "Dr. Farah Zemmouri",
    role: "SPECIALIST" as const,
    specialty: "Psychologie clinique",
    experienceYears: 12,
    price: 4000,
    rating: 4.9,
    reviewCount: 58,
    gender: "female",
    bio: "Psychologue clinicienne, offre un espace d'écoute confidentiel et sans jugement.",
  },
  {
    id: "demo-specialist-03",
    fullName: "Dr. Anis Meziane",
    role: "SPECIALIST" as const,
    specialty: "Rhumatologie",
    experienceYears: 15,
    price: 4200,
    rating: 4.8,
    reviewCount: 49,
    gender: "male",
    bio: "Rhumatologue, évalue les douleurs articulaires et propose un suivi personnalisé.",
  },
];

const patients = [
  ["demo-patient-01", "Amira Bensaïd", "female", "1988-02-16"],
  ["demo-patient-02", "Sofiane Merabet", "male", "1992-05-09"],
  ["demo-patient-03", "Nadia Zerrouki", "female", "1979-11-21"],
  ["demo-patient-04", "Riad Bouzid", "male", "1985-08-02"],
  ["demo-patient-05", "Meriem Dahmani", "female", "1996-04-12"],
  ["demo-patient-06", "Walid Saïdi", "male", "1974-10-28"],
  ["demo-patient-07", "Yasmine Belkacem", "female", "1990-07-07"],
  ["demo-patient-08", "Ilyes Azzouz", "male", "2001-01-30"],
  ["demo-patient-09", "Khadidja Kaci", "female", "1968-06-18"],
  ["demo-patient-10", "Mourad Amrouche", "male", "1982-12-04"],
] as const;

async function seedDemoData() {
  const [existing] = await db
    .select({ id: professionalsTable.userId })
    .from(professionalsTable)
    .limit(1);
  if (existing) {
    process.stdout.write("DawaLink demo professionals already exist; no changes made.\n");
    return;
  }

  await db.transaction(async (tx) => {
    await tx.insert(usersTable).values(
      providers.map((provider) => ({
        id: provider.id,
        email: `${provider.id}@demo.dawalink.invalid`,
        role: provider.role,
        fullName: provider.fullName,
        preferredLanguage: "fr",
        gender: provider.gender,
      })),
    );
    await tx.insert(usersTable).values(
      patients.map(([id, fullName, gender, birthDate]) => ({
        id,
        email: `${id}@demo.dawalink.invalid`,
        role: "PATIENT" as const,
        fullName,
        preferredLanguage: "fr",
        gender,
        birthDate,
      })),
    );
    await tx.insert(professionalsTable).values(
      providers.map((provider) => ({
        userId: provider.id,
        specialty: provider.specialty,
        licenseNumber: `DEMO-${provider.id.toUpperCase()}`,
        experienceYears: provider.experienceYears,
        languages: ["fr", "ar"],
        bio: provider.bio,
        education: ["Formation médicale accréditée"],
        certifications: ["Profil de démonstration"],
        consultationPrice: provider.price,
        currency: "DZD",
        rating: provider.rating,
        reviewCount: provider.reviewCount,
        verificationStatus: "APPROVED" as const,
      })),
    );
    await tx.insert(availabilityTable).values(
      providers.flatMap((provider) =>
        [1, 2, 3, 4, 5].map((dayOfWeek) => ({
          id: `demo-${provider.id}-weekday-${dayOfWeek}`,
          professionalId: provider.id,
          dayOfWeek,
          startTime: "09:00",
          endTime: "17:00",
          slotMinutes: 30,
        })),
      ),
    );
  });
  process.stdout.write(
    `Seeded ${providers.length} demo professionals and ${patients.length} demo patients.\n`,
  );
}

seedDemoData()
  .then(() => pool.end())
  .catch(async (error: unknown) => {
    process.stderr.write(
      `DawaLink demo seed failed: ${error instanceof Error ? error.message : String(error)}\n`,
    );
    await pool.end();
    process.exitCode = 1;
  });
