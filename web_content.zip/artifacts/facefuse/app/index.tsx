import React, { useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Image,
  Linking,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import { Feather, Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

type AssetKind = 'image' | 'video';
type Asset = {
  uri: string;
  name: string;
  kind: AssetKind;
  width?: number;
  height?: number;
  duration?: number;
};

type FaceSlot = {
  id: string;
  label: string;
  sourceId: string | null;
  confidence: string;
  position: string;
};

type SourceAsset = Asset & { id: string };
type Model = {
  id: string;
  name: string;
  detail: string;
  badge?: string;
  tags: string[];
  license: string;
};

const models: Model[] = [
  {
    id: 'inswapper',
    name: 'InSwapper 128',
    detail: 'High-fidelity identity transfer',
    badge: 'RECOMMENDED',
    tags: ['Fast', 'Image + video'],
    license: 'InsightFace model license',
  },
  {
    id: 'facefusion',
    name: 'FaceFusion pipeline',
    detail: 'Detector, masker, enhancer orchestration',
    tags: ['Flexible', 'Multi-face'],
    license: 'GPL-3.0 + model licenses',
  },
  {
    id: 'simswap',
    name: 'SimSwap 512',
    detail: 'Higher resolution identity injection',
    tags: ['Detail', 'Profile-ready'],
    license: 'Non-commercial research',
  },
  {
    id: 'comfy',
    name: 'LTX video fusion',
    detail: 'Temporal consistency for fast motion',
    tags: ['Motion', 'Experimental'],
    license: 'Workflow + model dependent',
  },
];

const starterFaces: FaceSlot[] = [
  { id: 'face-1', label: 'Face 01', sourceId: null, confidence: 'Primary', position: 'Center · 92%' },
  { id: 'face-2', label: 'Face 02', sourceId: null, confidence: 'Secondary', position: 'Left · 87%' },
  { id: 'face-3', label: 'Face 03', sourceId: null, confidence: 'Secondary', position: 'Right · 84%' },
];

const storageKey = '@facefuse/recent';

function makeAsset(result: ImagePicker.ImagePickerAsset): Asset {
  const isVideo = result.type === 'video' || result.mimeType?.startsWith('video');
  return {
    uri: result.uri,
    name: result.fileName ?? (isVideo ? 'target-video.mp4' : 'target-image.jpg'),
    kind: isVideo ? 'video' : 'image',
    width: result.width,
    height: result.height,
    duration: result.duration ?? undefined,
  };
}

function formatDuration(duration?: number) {
  if (!duration) return '—';
  const seconds = Math.round(duration / 1000);
  return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`;
}

function IconButton({
  icon,
  label,
  onPress,
  colors,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  onPress: () => void;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <Pressable
      accessibilityLabel={label}
      testID={`icon-${label.toLowerCase().replaceAll(' ', '-')}`}
      onPress={onPress}
      style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]}
    >
      <Ionicons name={icon} size={20} color={colors.foreground} />
    </Pressable>
  );
}

function SectionLabel({ children, colors }: { children: string; colors: ReturnType<typeof useColors> }) {
  return (
    <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>
      {children.toUpperCase()}
    </Text>
  );
}

function MediaCard({
  title,
  asset,
  emptyLabel,
  onPress,
  colors,
}: {
  title: string;
  asset: Asset | null;
  emptyLabel: string;
  onPress: () => void;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <Pressable
      accessibilityLabel={title}
      testID={`media-${title.toLowerCase().replaceAll(' ', '-')}`}
      onPress={onPress}
      style={({ pressed }) => [
        styles.mediaCard,
        { borderColor: asset ? colors.primary : colors.border, backgroundColor: colors.card },
        pressed && styles.pressed,
      ]}
    >
      {asset ? (
        <>
          <Image source={{ uri: asset.uri }} style={styles.mediaPreview} resizeMode="cover" />
          <View style={styles.mediaOverlay}>
            <View style={styles.mediaMeta}>
              <Ionicons name={asset.kind === 'video' ? 'videocam' : 'image'} size={13} color={colors.foreground} />
              <Text style={styles.mediaMetaText}>{asset.kind === 'video' ? formatDuration(asset.duration) : 'Image'}</Text>
            </View>
            <View style={[styles.replacePill, { backgroundColor: colors.background + 'D9' }]}>
              <Feather name="refresh-cw" size={12} color={colors.primary} />
              <Text style={[styles.replaceText, { color: colors.foreground }]}>Replace</Text>
            </View>
          </View>
        </>
      ) : (
        <View style={styles.emptyMedia}>
          <View style={[styles.emptyMediaIcon, { backgroundColor: colors.secondary }]}>
            <Ionicons name="add" size={24} color={colors.primary} />
          </View>
          <Text style={[styles.emptyMediaTitle, { color: colors.foreground }]}>{emptyLabel}</Text>
          <Text style={[styles.emptyMediaHint, { color: colors.mutedForeground }]}>Gallery or URL</Text>
        </View>
      )}
      <View style={styles.mediaTitleRow}>
        <Text style={[styles.mediaTitle, { color: colors.foreground }]}>{title}</Text>
        <Ionicons name="chevron-forward" size={16} color={colors.mutedForeground} />
      </View>
    </Pressable>
  );
}

function SourceChip({
  source,
  selected,
  onPress,
  colors,
}: {
  source: SourceAsset;
  selected: boolean;
  onPress: () => void;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityLabel={`Assign ${source.name}`}
      style={({ pressed }) => [
        styles.sourceChip,
        { borderColor: selected ? colors.primary : colors.border, backgroundColor: selected ? colors.primary + '18' : colors.secondary },
        pressed && styles.pressed,
      ]}
    >
      <Image source={{ uri: source.uri }} style={styles.sourceThumb} />
      <Text numberOfLines={1} style={[styles.sourceName, { color: selected ? colors.primary : colors.foreground }]}>
        {source.name}
      </Text>
      {selected ? <Ionicons name="checkmark-circle" size={16} color={colors.primary} /> : null}
    </Pressable>
  );
}

export default function FaceFuseWorkspace() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [target, setTarget] = useState<Asset | null>(null);
  const [sources, setSources] = useState<SourceAsset[]>([]);
  const [faces, setFaces] = useState<FaceSlot[]>(starterFaces);
  const [selectedModel, setSelectedModel] = useState('inswapper');
  const [fuseModels, setFuseModels] = useState(true);
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [url, setUrl] = useState('');
  const [isPicking, setIsPicking] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [notice, setNotice] = useState('Ready for a target');
  const [recentCount, setRecentCount] = useState(0);

  useEffect(() => {
    AsyncStorage.getItem(storageKey).then((value) => {
      if (value) setRecentCount(JSON.parse(value).length);
    });
  }, []);

  const assignedCount = useMemo(() => faces.filter((face) => face.sourceId).length, [faces]);
  const selectedModelDetails = models.find((model) => model.id === selectedModel) ?? models[0];

  const addRecent = async (item: Asset) => {
    const raw = await AsyncStorage.getItem(storageKey);
    const list: Asset[] = raw ? JSON.parse(raw) : [];
    const next = [item, ...list.filter((entry) => entry.uri !== item.uri)].slice(0, 12);
    await AsyncStorage.setItem(storageKey, JSON.stringify(next));
    setRecentCount(next.length);
  };

  const pickMedia = async (kind: AssetKind) => {
    setIsPicking(true);
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) {
        Alert.alert('Media permission needed', 'Allow FaceFuse to access your photos and videos, then try again.');
        return;
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: kind === 'video' ? ['videos'] : ['images'],
        allowsEditing: false,
        quality: 1,
      });
      if (!result.canceled && result.assets[0]) {
        const asset = makeAsset(result.assets[0]);
        if (kind === 'video') {
          setTarget(asset);
          setNotice('Target loaded · analyze to find faces');
        } else {
          const source: SourceAsset = { ...asset, id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}` };
          setSources((current) => [...current, source]);
          setNotice(`${source.name} added as a source`);
        }
        await addRecent(asset);
        await Haptics.selectionAsync();
      }
    } catch {
      Alert.alert('Could not open media', 'Please try selecting the file again.');
    } finally {
      setIsPicking(false);
    }
  };

  const addImageFromUrl = () => {
    const trimmed = url.trim();
    if (!/^https?:\/\/.+/i.test(trimmed)) {
      Alert.alert('Enter a valid image URL', 'Use a full https:// link to a public image.');
      return;
    }
    const source: SourceAsset = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      uri: trimmed,
      name: `Web source ${sources.length + 1}`,
      kind: 'image',
    };
    setSources((current) => [...current, source]);
    setUrl('');
    setShowUrlInput(false);
    setNotice('Web source added');
  };

  const analyzeTarget = async () => {
    if (!target) {
      Alert.alert('Add a target first', 'Choose an image or video to analyze.');
      return;
    }
    setIsAnalyzing(true);
    setNotice('Analyzing target for faces…');
    await new Promise((resolve) => setTimeout(resolve, 850));
    setIsAnalyzing(false);
    setNotice('3 face regions ready to map');
  };

  const toggleFace = (faceId: string) => {
    if (!sources.length) {
      Alert.alert('Add a source face', 'Import at least one source image, then assign it to each detected face.');
      return;
    }
    setFaces((current) =>
      current.map((face) => {
        if (face.id !== faceId) return face;
        const nextSource = face.sourceId ? null : sources[0].id;
        return { ...face, sourceId: nextSource };
      }),
    );
    Haptics.selectionAsync();
  };

  const process = async () => {
    if (!target || !sources.length || !assignedCount) {
      Alert.alert('Complete the setup', 'Add a target, import a source face, and assign at least one detected face.');
      return;
    }
    setIsProcessing(true);
    setNotice(fuseModels ? 'Preparing fused pipeline…' : `Preparing ${selectedModelDetails.name}…`);
    await new Promise((resolve) => setTimeout(resolve, 1200));
    setIsProcessing(false);
    setNotice('Pipeline configured · GPU render endpoint required');
    Alert.alert(
      'Ready to render',
      'The project is mapped and the selected pipeline is ready. Connect a GPU-backed inference endpoint to render the final image or video.',
    );
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[styles.content, { paddingTop: insets.top + 16, paddingBottom: insets.bottom + 32 }]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View>
            <View style={styles.brandLine}>
              <View style={[styles.brandMark, { backgroundColor: colors.primary }]}>
                <MaterialCommunityIcons name="vector-combine" size={18} color={colors.primaryForeground} />
              </View>
              <Text style={[styles.brand, { color: colors.foreground }]}>facefuse</Text>
            </View>
            <Text style={[styles.kicker, { color: colors.mutedForeground }]}>MULTI-FACE STUDIO</Text>
          </View>
          <View style={[styles.historyBadge, { backgroundColor: colors.secondary }]}>
            <Ionicons name="layers-outline" size={15} color={colors.primary} />
            <Text style={[styles.historyText, { color: colors.foreground }]}>{recentCount}</Text>
          </View>
        </View>

        <LinearGradient
          colors={[colors.primary + '20', colors.card, colors.card]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.hero}
        >
          <View style={styles.heroCopy}>
            <View style={[styles.statusDot, { backgroundColor: colors.primary }]} />
            <Text style={[styles.heroEyebrow, { color: colors.primary }]}>WORKSPACE / 01</Text>
            <Text style={[styles.heroTitle, { color: colors.foreground }]}>Map every face.{'\n'}Keep the scene.</Text>
            <Text style={[styles.heroBody, { color: colors.mutedForeground }]}>
              Build a precise multi-face swap before you render.
            </Text>
          </View>
          <View style={styles.heroGlyph}>
            <MaterialCommunityIcons name="face-recognition" size={60} color={colors.primary + 'A6'} />
            <View style={[styles.heroGlyphLine, { backgroundColor: colors.accent }]} />
          </View>
        </LinearGradient>

        <SectionLabel colors={colors}>1 · Target media</SectionLabel>
        <MediaCard title="Target" asset={target} emptyLabel="Choose target media" onPress={() => pickMedia('video')} colors={colors} />
        <View style={styles.targetActions}>
          <Pressable
            accessibilityLabel="Choose image target"
            testID="choose-image-target"
            onPress={() => pickMedia('image')}
            style={({ pressed }) => [styles.secondaryAction, { borderColor: colors.border }, pressed && styles.pressed]}
          >
            <Ionicons name="image-outline" size={17} color={colors.primary} />
            <Text style={[styles.secondaryActionText, { color: colors.foreground }]}>Image target</Text>
          </Pressable>
          <Pressable
            accessibilityLabel="Analyze faces"
            testID="analyze-faces"
            onPress={analyzeTarget}
            disabled={isAnalyzing}
            style={({ pressed }) => [styles.secondaryAction, { borderColor: colors.border }, pressed && styles.pressed, isAnalyzing && styles.disabled]}
          >
            {isAnalyzing ? <ActivityIndicator size="small" color={colors.primary} /> : <Ionicons name="scan-outline" size={17} color={colors.primary} />}
            <Text style={[styles.secondaryActionText, { color: colors.foreground }]}>Analyze faces</Text>
          </Pressable>
        </View>

        <View style={styles.sectionHeaderRow}>
          <SectionLabel colors={colors}>2 · Source faces</SectionLabel>
          <Text style={[styles.counter, { color: colors.mutedForeground }]}>{sources.length}/12</Text>
        </View>
        <View style={styles.sourceActions}>
          <Pressable
            accessibilityLabel="Add from phone"
            testID="add-from-phone"
            onPress={() => pickMedia('image')}
            style={({ pressed }) => [styles.addSource, { backgroundColor: colors.secondary, borderColor: colors.border }, pressed && styles.pressed]}
          >
            <Ionicons name="phone-portrait-outline" size={19} color={colors.primary} />
            <Text style={[styles.addSourceText, { color: colors.foreground }]}>Phone</Text>
          </Pressable>
          <Pressable
            accessibilityLabel="Add from web"
            testID="add-from-web"
            onPress={() => setShowUrlInput((visible) => !visible)}
            style={({ pressed }) => [styles.addSource, { backgroundColor: colors.secondary, borderColor: colors.border }, pressed && styles.pressed]}
          >
            <Ionicons name="globe-outline" size={19} color={colors.primary} />
            <Text style={[styles.addSourceText, { color: colors.foreground }]}>Web URL</Text>
          </Pressable>
        </View>
        {showUrlInput ? (
          <View style={[styles.urlRow, { borderColor: colors.border, backgroundColor: colors.card }]}>
            <TextInput
              testID="web-url-input"
              value={url}
              onChangeText={setUrl}
              placeholder="https://public-image-url.jpg"
              placeholderTextColor={colors.mutedForeground}
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="url"
              style={[styles.urlInput, { color: colors.foreground }]}
            />
            <Pressable testID="confirm-web-url" onPress={addImageFromUrl} style={[styles.urlSubmit, { backgroundColor: colors.primary }]}>
              <Ionicons name="arrow-up" size={17} color={colors.primaryForeground} />
            </Pressable>
          </View>
        ) : null}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.sourceList}>
          {sources.length ? (
            sources.map((source) => <SourceChip key={source.id} source={source} selected={false} onPress={() => setNotice(`${source.name} is ready to assign`)} colors={colors} />)
          ) : (
            <View style={[styles.sourceEmpty, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Ionicons name="sparkles-outline" size={17} color={colors.accent} />
              <Text style={[styles.sourceEmptyText, { color: colors.mutedForeground }]}>Import up to 12 source identities</Text>
            </View>
          )}
        </ScrollView>

        <View style={styles.sectionHeaderRow}>
          <SectionLabel colors={colors}>3 · Face mapping</SectionLabel>
          <Text style={[styles.counter, { color: colors.primary }]}>{assignedCount} assigned</Text>
        </View>
        <View style={[styles.mappingCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.mappingIntro}>
            <View style={[styles.scanIcon, { backgroundColor: colors.primary + '16' }]}>
              <Ionicons name="scan" size={19} color={colors.primary} />
            </View>
            <View style={styles.mappingIntroCopy}>
              <Text style={[styles.mappingTitle, { color: colors.foreground }]}>Detected face regions</Text>
              <Text style={[styles.mappingSubtitle, { color: colors.mutedForeground }]}>{notice}</Text>
            </View>
            <View style={[styles.readyPill, { backgroundColor: target ? colors.primary + '1A' : colors.secondary }]}>
              <View style={[styles.readyDot, { backgroundColor: target ? colors.primary : colors.mutedForeground }]} />
              <Text style={[styles.readyText, { color: target ? colors.primary : colors.mutedForeground }]}>{target ? 'READY' : 'WAITING'}</Text>
            </View>
          </View>
          {faces.map((face) => {
            const assignedSource = sources.find((source) => source.id === face.sourceId);
            return (
              <Pressable
                key={face.id}
                accessibilityLabel={`Assign ${face.label}`}
                testID={`assign-${face.id}`}
                onPress={() => toggleFace(face.id)}
                style={({ pressed }) => [styles.faceRow, { borderTopColor: colors.border }, pressed && styles.pressed]}
              >
                <View style={[styles.faceNumber, { backgroundColor: assignedSource ? colors.primary : colors.secondary }]}>
                  <Text style={[styles.faceNumberText, { color: assignedSource ? colors.primaryForeground : colors.mutedForeground }]}>
                    {face.label.slice(-2)}
                  </Text>
                </View>
                <View style={styles.faceCopy}>
                  <Text style={[styles.faceLabel, { color: colors.foreground }]}>{face.label}</Text>
                  <Text style={[styles.facePosition, { color: colors.mutedForeground }]}>{face.position}</Text>
                </View>
                {assignedSource ? (
                  <View style={[styles.assignedThumbWrap, { borderColor: colors.primary }]}>
                    <Image source={{ uri: assignedSource.uri }} style={styles.assignedThumb} />
                  </View>
                ) : (
                  <View style={[styles.assignButton, { borderColor: colors.border }]}>
                    <Text style={[styles.assignText, { color: colors.primary }]}>Assign</Text>
                    <Ionicons name="arrow-forward" size={14} color={colors.primary} />
                  </View>
                )}
              </Pressable>
            );
          })}
        </View>

        <View style={styles.sectionHeaderRow}>
          <SectionLabel colors={colors}>4 · Model stack</SectionLabel>
          <Text style={[styles.counter, { color: colors.mutedForeground }]}>{models.length} available</Text>
        </View>
        <View style={styles.modelList}>
          {models.map((model) => {
            const selected = model.id === selectedModel;
            return (
              <Pressable
                key={model.id}
                accessibilityLabel={`Select ${model.name}`}
                testID={`model-${model.id}`}
                onPress={() => {
                  setSelectedModel(model.id);
                  setFuseModels(false);
                  Haptics.selectionAsync();
                }}
                style={({ pressed }) => [
                  styles.modelCard,
                  { backgroundColor: selected ? colors.primary + '12' : colors.card, borderColor: selected ? colors.primary : colors.border },
                  pressed && styles.pressed,
                ]}
              >
                <View style={[styles.modelRadio, { borderColor: selected ? colors.primary : colors.mutedForeground }]}>
                  {selected ? <View style={[styles.modelRadioInner, { backgroundColor: colors.primary }]} /> : null}
                </View>
                <View style={styles.modelCopy}>
                  <View style={styles.modelNameRow}>
                    <Text style={[styles.modelName, { color: colors.foreground }]}>{model.name}</Text>
                    {model.badge ? <Text style={[styles.modelBadge, { color: colors.primary }]}>{model.badge}</Text> : null}
                  </View>
                  <Text style={[styles.modelDetail, { color: colors.mutedForeground }]}>{model.detail}</Text>
                  <View style={styles.tagRow}>
                    {model.tags.map((tag) => <Text key={tag} style={[styles.tag, { color: colors.mutedForeground, backgroundColor: colors.secondary }]}>{tag}</Text>)}
                  </View>
                </View>
                <Ionicons name="information-circle-outline" size={18} color={colors.mutedForeground} />
              </Pressable>
            );
          })}
        </View>
        <View style={[styles.fuseRow, { backgroundColor: colors.secondary }]}>
          <View style={[styles.fuseIcon, { backgroundColor: colors.accent + '22' }]}>
            <MaterialCommunityIcons name="layers-triple-outline" size={20} color={colors.accent} />
          </View>
          <View style={styles.fuseCopy}>
            <Text style={[styles.fuseTitle, { color: colors.foreground }]}>Fuse selected models</Text>
            <Text style={[styles.fuseSubtitle, { color: colors.mutedForeground }]}>Best-of-stack routing for difficult angles</Text>
          </View>
          <Pressable
            accessibilityRole="switch"
            accessibilityState={{ checked: fuseModels }}
            testID="fuse-models"
            onPress={() => setFuseModels((enabled) => !enabled)}
            style={[styles.switch, { backgroundColor: fuseModels ? colors.primary : colors.muted }]}
          >
            <View style={[styles.switchKnob, fuseModels && styles.switchKnobOn]} />
          </Pressable>
        </View>
        <Pressable onPress={() => Linking.openURL('https://github.com/facefusion/facefusion')} style={styles.licenseLink}>
          <Ionicons name="open-outline" size={14} color={colors.mutedForeground} />
          <Text style={[styles.licenseText, { color: colors.mutedForeground }]}>Review model sources & licenses</Text>
        </Pressable>

        <Pressable
          accessibilityLabel="Prepare face swap"
          testID="prepare-face-swap"
          onPress={process}
          disabled={isProcessing || isPicking}
          style={({ pressed }) => [styles.processButton, { backgroundColor: colors.primary }, pressed && styles.pressed, (isProcessing || isPicking) && styles.disabled]}
        >
          {isProcessing ? <ActivityIndicator color={colors.primaryForeground} /> : <MaterialCommunityIcons name="magic-staff" size={20} color={colors.primaryForeground} />}
          <Text style={[styles.processButtonText, { color: colors.primaryForeground }]}>{isProcessing ? 'Preparing pipeline…' : 'Prepare face swap'}</Text>
          {!isProcessing ? <Ionicons name="arrow-forward" size={19} color={colors.primaryForeground} /> : null}
        </Pressable>
        <Text style={[styles.footerNote, { color: colors.mutedForeground }]}>FaceFuse never uploads media without your explicit processing endpoint.</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { paddingHorizontal: 18 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 },
  brandLine: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  brandMark: { width: 29, height: 29, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  brand: { fontSize: 23, fontWeight: '700', letterSpacing: -0.9 },
  kicker: { fontSize: 10, letterSpacing: 2.1, fontWeight: '600', marginTop: 5 },
  historyBadge: { flexDirection: 'row', alignItems: 'center', gap: 7, paddingHorizontal: 12, paddingVertical: 9, borderRadius: 18 },
  historyText: { fontSize: 12, fontWeight: '700' },
  hero: { minHeight: 170, borderRadius: 24, padding: 20, overflow: 'hidden', flexDirection: 'row', marginBottom: 27 },
  heroCopy: { flex: 1 },
  statusDot: { width: 8, height: 8, borderRadius: 4, marginBottom: 12 },
  heroEyebrow: { fontSize: 10, letterSpacing: 1.7, fontWeight: '700', marginBottom: 7 },
  heroTitle: { fontSize: 29, lineHeight: 32, fontWeight: '700', letterSpacing: -1.2 },
  heroBody: { fontSize: 13, lineHeight: 19, marginTop: 11, maxWidth: 220 },
  heroGlyph: { justifyContent: 'center', alignItems: 'center', width: 94, transform: [{ rotate: '-12deg' }] },
  heroGlyphLine: { width: 53, height: 2, marginTop: 10, borderRadius: 2, transform: [{ rotate: '15deg' }] },
  sectionLabel: { fontSize: 10, letterSpacing: 1.6, fontWeight: '700', marginBottom: 10 },
  mediaCard: { height: 205, borderRadius: 20, borderWidth: 1, overflow: 'hidden', marginBottom: 11 },
  mediaPreview: { ...StyleSheet.absoluteFill, width: undefined, height: undefined, opacity: 0.82 },
  mediaOverlay: { position: 'absolute', left: 13, right: 13, top: 13, flexDirection: 'row', justifyContent: 'space-between' },
  mediaMeta: { backgroundColor: '#0B0E13CC', borderRadius: 13, paddingHorizontal: 9, paddingVertical: 6, flexDirection: 'row', gap: 5, alignItems: 'center' },
  mediaMetaText: { color: '#F5F7FA', fontSize: 11, fontWeight: '600' },
  replacePill: { borderRadius: 13, paddingHorizontal: 9, paddingVertical: 6, flexDirection: 'row', gap: 5, alignItems: 'center' },
  replaceText: { fontSize: 11, fontWeight: '600' },
  emptyMedia: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  emptyMediaIcon: { width: 48, height: 48, borderRadius: 16, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  emptyMediaTitle: { fontSize: 16, fontWeight: '600' },
  emptyMediaHint: { fontSize: 12, marginTop: 4 },
  mediaTitleRow: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: 14, backgroundColor: '#0B0E13B8', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  mediaTitle: { fontSize: 13, fontWeight: '600' },
  targetActions: { flexDirection: 'row', gap: 9, marginBottom: 26 },
  secondaryAction: { flex: 1, height: 44, borderWidth: 1, borderRadius: 13, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 7 },
  secondaryActionText: { fontSize: 12, fontWeight: '600' },
  sectionHeaderRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  counter: { fontSize: 11, fontWeight: '600', marginBottom: 10 },
  sourceActions: { flexDirection: 'row', gap: 9, marginBottom: 10 },
  addSource: { flex: 1, height: 46, borderRadius: 14, borderWidth: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  addSourceText: { fontSize: 13, fontWeight: '600' },
  urlRow: { height: 48, borderWidth: 1, borderRadius: 14, flexDirection: 'row', alignItems: 'center', paddingLeft: 12, marginBottom: 10 },
  urlInput: { flex: 1, fontSize: 13 },
  urlSubmit: { width: 38, height: 38, borderRadius: 11, alignItems: 'center', justifyContent: 'center', marginRight: 4 },
  sourceList: { gap: 8, paddingBottom: 27 },
  sourceChip: { minWidth: 145, maxWidth: 175, height: 50, borderRadius: 14, borderWidth: 1, padding: 6, flexDirection: 'row', alignItems: 'center', gap: 8 },
  sourceThumb: { width: 36, height: 36, borderRadius: 10, backgroundColor: '#28303C' },
  sourceName: { flex: 1, fontSize: 12, fontWeight: '600' },
  sourceEmpty: { height: 50, borderRadius: 14, borderWidth: 1, borderStyle: 'dashed', paddingHorizontal: 13, alignItems: 'center', flexDirection: 'row', gap: 8 },
  sourceEmptyText: { fontSize: 12 },
  mappingCard: { borderWidth: 1, borderRadius: 20, overflow: 'hidden', marginBottom: 27 },
  mappingIntro: { padding: 14, flexDirection: 'row', alignItems: 'center', gap: 10 },
  scanIcon: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  mappingIntroCopy: { flex: 1 },
  mappingTitle: { fontSize: 13, fontWeight: '700' },
  mappingSubtitle: { fontSize: 11, marginTop: 3 },
  readyPill: { borderRadius: 12, paddingHorizontal: 8, paddingVertical: 5, flexDirection: 'row', gap: 5, alignItems: 'center' },
  readyDot: { width: 5, height: 5, borderRadius: 3 },
  readyText: { fontSize: 9, fontWeight: '800', letterSpacing: 0.7 },
  faceRow: { minHeight: 68, borderTopWidth: 1, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 11 },
  faceNumber: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  faceNumberText: { fontSize: 11, fontWeight: '800' },
  faceCopy: { flex: 1 },
  faceLabel: { fontSize: 13, fontWeight: '600' },
  facePosition: { fontSize: 11, marginTop: 3 },
  assignButton: { borderWidth: 1, borderRadius: 11, paddingHorizontal: 9, paddingVertical: 7, flexDirection: 'row', gap: 5, alignItems: 'center' },
  assignText: { fontSize: 11, fontWeight: '700' },
  assignedThumbWrap: { width: 35, height: 35, borderRadius: 11, borderWidth: 2, padding: 2 },
  assignedThumb: { flex: 1, borderRadius: 7 },
  modelList: { gap: 8, marginBottom: 9 },
  modelCard: { minHeight: 92, borderRadius: 16, borderWidth: 1, padding: 13, flexDirection: 'row', gap: 10, alignItems: 'flex-start' },
  modelRadio: { width: 18, height: 18, borderRadius: 9, borderWidth: 1.5, marginTop: 2, alignItems: 'center', justifyContent: 'center' },
  modelRadioInner: { width: 9, height: 9, borderRadius: 5 },
  modelCopy: { flex: 1 },
  modelNameRow: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  modelName: { fontSize: 13, fontWeight: '700' },
  modelBadge: { fontSize: 8, fontWeight: '800', letterSpacing: 0.7 },
  modelDetail: { fontSize: 11, marginTop: 4 },
  tagRow: { flexDirection: 'row', gap: 5, marginTop: 8 },
  tag: { fontSize: 9, borderRadius: 6, paddingHorizontal: 6, paddingVertical: 4 },
  fuseRow: { borderRadius: 17, padding: 13, flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 2 },
  fuseIcon: { width: 37, height: 37, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  fuseCopy: { flex: 1 },
  fuseTitle: { fontSize: 13, fontWeight: '700' },
  fuseSubtitle: { fontSize: 11, marginTop: 3 },
  switch: { width: 44, height: 26, borderRadius: 14, padding: 3, justifyContent: 'center' },
  switchKnob: { width: 20, height: 20, borderRadius: 10, backgroundColor: '#F5F7FA' },
  switchKnobOn: { alignSelf: 'flex-end' },
  licenseLink: { alignSelf: 'center', flexDirection: 'row', alignItems: 'center', gap: 5, paddingVertical: 15 },
  licenseText: { fontSize: 11, textDecorationLine: 'underline' },
  processButton: { height: 57, borderRadius: 18, paddingHorizontal: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9, marginTop: 5 },
  processButtonText: { fontSize: 15, fontWeight: '800', flex: 1 },
  footerNote: { textAlign: 'center', fontSize: 10, lineHeight: 15, paddingHorizontal: 28, marginTop: 13 },
  iconButton: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  pressed: { opacity: 0.72, transform: [{ scale: 0.98 }] },
  disabled: { opacity: 0.55 },
});