# FaceFuse model catalog

Research checked on September 29, 2026. “Most advanced” is not a single objective ranking: quality varies with the target angle, motion, resolution, enhancer, detector, GPU, and model license. FaceFuse therefore exposes a router-friendly stack instead of claiming that one model wins every scene.

## Included model options

### InsightFace / InSwapper 128

The default fast identity-transfer option in the app. It is a common open-source building block for image and video face-swap pipelines and pairs naturally with a face detector and ArcFace-style identity embeddings.

- Best fit: general images and video previews
- App tags: Fast, Image + video
- Source: <https://github.com/deepinsight/insightface>
- Licensing: inspect the code and pretrained-model terms separately before commercial use

### FaceFusion pipeline

FaceFusion is treated as an orchestration option: detector, masker, swapper, enhancer, and output settings can be composed into a workflow. It is useful when the processing service needs multiple backends and per-scene controls.

- Best fit: flexible multi-face workflows
- App tags: Flexible, Multi-face
- Source: <https://github.com/facefusion/facefusion>
- Licensing: repository and bundled model licenses must be reviewed together

### SimSwap 512

An identity-injection research pipeline with a higher-resolution model variant. It remains useful as an alternate backend for high-detail stills and profile-heavy experiments, but its research/commercial terms need review.

- Best fit: detail-focused experiments
- App tags: Detail, Profile-ready
- Source: <https://github.com/neuralchen/SimSwap>
- Licensing: non-commercial research terms apply to the upstream project

### LTX video fusion

An experimental video route represented in the UI for temporal-consistency workflows. A production implementation needs a concrete workflow, pinned model weights, GPU sizing, and a video safety policy.

- Best fit: fast motion and temporal consistency experiments
- App tags: Motion, Experimental
- Reference workflow: <https://comfy.org/workflows/bed989744195-bed989744195/>
- Licensing: workflow and model terms vary

## Recommended production routing

1. Detect and align every face with a modern detector.
2. Route frontal and moderate-angle faces to InSwapper or a compatible FaceFusion stack.
3. Route difficult side profiles, occlusion, and rapid motion to a temporal video pipeline rather than repeatedly swapping independent frames.
4. Use a face restoration/enhancement step only after identity transfer; keep it optional because aggressive restoration can change identity.
5. Use frame interpolation, tracking, and temporal smoothing only when the backend can preserve identity across the full clip.
6. Store model identifiers, versions, and licenses with each output for reproducibility.

## What is not bundled

No pretrained model weights are copied into this mobile source package. Weights can be large, license-restricted, and unsafe to redistribute without the original terms. The mobile app exposes the model selection and mapping contract; the inference service owns model downloads, GPU execution, access control, and license compliance.
