# FaceFuse

FaceFuse is an Android-ready Expo app for planning complex image and video face-swap jobs. It provides:

- Image or video target selection from the phone
- Source face import from the phone or a public image URL
- Multiple source identities in one project
- Per-face assignment for up to 3 detected regions in the first UI build
- Selectable model pipelines and an optional fused pipeline
- A render handoff state that is explicit about the need for a GPU-backed inference service
- Local recent-project count persistence with AsyncStorage

## Important processing note

The mobile client is the control surface, not the model runtime. FaceFusion, InsightFace/InSwapper, SimSwap, and video diffusion pipelines are too large and device-dependent to bundle as a reliable Expo Go app. The `Prepare face swap` action validates the project mapping and makes the chosen pipeline ready for a backend render endpoint; it does not pretend to render a finished face swap locally.

To make the app render results, connect the action in `app/index.tsx` to a server that:

1. Receives media over an authenticated, encrypted upload.
2. Detects faces and returns stable face IDs and bounding boxes.
3. Applies the selected model or model router.
4. Tracks a job and returns a result URL.
5. Deletes temporary uploads according to your retention policy.

Do not process or publish a person's likeness without consent. Add consent and provenance controls before shipping this as a public service.

## Run the app

```bash
pnpm install
pnpm --filter @workspace/facefuse run dev
```

Use the Expo preview QR code to open the app on an Android phone with Expo Go.

## Build in Android Studio

This is an Expo source project. From the `artifacts/facefuse` directory on a machine with the Android SDK:

```bash
pnpm install
npx expo prebuild --platform android
```

Then open the generated `android/` directory in Android Studio. The generated native directory is intentionally not committed in this starter package; it is derived from `app.json` and the installed Expo SDK.

## Project layout

- `app/index.tsx` — FaceFuse workspace and all first-build interactions
- `app/_layout.tsx` — Expo providers and routing
- `constants/colors.ts` — shared palette
- `assets/images/icon.png` — FaceFuse app icon
- `MODEL-CATALOG.md` — model choices and source/licensing notes
