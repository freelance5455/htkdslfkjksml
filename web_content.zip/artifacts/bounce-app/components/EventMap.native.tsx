import { Image, StyleSheet, Text, View } from "react-native";
import NativeMapView, { Callout, Marker } from "react-native-maps";
import { Feather } from "@expo/vector-icons";
import type { PublicEvent } from "@workspace/api-client-react";
import { useColors } from "@/hooks/useColors";

const crowdColor: Record<string, string> = {
  Chill: "#7df2c1",
  Buzzing: "#ffd36a",
  Hype: "#ff9567",
  Packed: "#ff4f9a",
};
const money = (amount: number) => `JMD ${amount.toLocaleString("en-JM")}`;
const assetUrl = (path: string | null) =>
  path?.startsWith("http") ? path : path && process.env.EXPO_PUBLIC_DOMAIN ? `https://${process.env.EXPO_PUBLIC_DOMAIN}${path}` : path ?? "";

export default function EventMap({ colors, events, onOpen }: { colors: ReturnType<typeof useColors>; events: PublicEvent[]; onOpen: (event: PublicEvent) => void }) {
  const mappedEvents = events.filter((event) => typeof event.latitude === "number" && typeof event.longitude === "number");
  return (
    <View style={styles.map}>
      <NativeMapView style={StyleSheet.absoluteFillObject} initialRegion={{ latitude: 18.0179, longitude: -76.8099, latitudeDelta: 0.08, longitudeDelta: 0.08 }} showsUserLocation={false} showsCompass toolbarEnabled={false}>
        {mappedEvents.map((event) => (
          <Marker key={event.id} coordinate={{ latitude: event.latitude as number, longitude: event.longitude as number }} pinColor={crowdColor[event.crowdLevel] ?? crowdColor.Buzzing} onCalloutPress={() => onOpen(event)}>
            <View style={[styles.pinCircle, { borderColor: colors.border, backgroundColor: colors.card }]}>
              <View style={[styles.pinDot, { backgroundColor: crowdColor[event.crowdLevel] ?? crowdColor.Buzzing, shadowColor: crowdColor[event.crowdLevel] ?? crowdColor.Buzzing }]} />
            </View>
            <Callout tooltip>
              <View style={[styles.mapCallout, { backgroundColor: colors.backgroundElevated, borderColor: colors.border }]}>
                {event.posterUrl ? <Image source={{ uri: assetUrl(event.posterUrl) }} style={styles.mapCalloutPoster} /> : null}
                <Text numberOfLines={1} style={[styles.mapCalloutTitle, { color: colors.foreground }]}>{event.name}</Text>
                <Text style={[styles.mapCalloutMeta, { color: colors.mutedForeground }]}>{event.venue} · {money(event.totalPriceJmd)}</Text>
                <Text style={[styles.mapCalloutAction, { color: colors.pink }]}>View party log</Text>
              </View>
            </Callout>
          </Marker>
        ))}
      </NativeMapView>
      <View style={[styles.mapChip, { backgroundColor: colors.backgroundElevated, borderColor: colors.border }]}><Feather name="crosshair" size={13} color={colors.mint} /><Text style={[styles.mapChipText, { color: colors.mutedForeground }]}>Kingston event map</Text></View>
      {mappedEvents.length === 0 ? <View style={[styles.mapEmpty, { backgroundColor: colors.backgroundElevated, borderColor: colors.border }]}><Feather name="map-pin" size={18} color={colors.pink} /><Text style={[styles.mapEmptyText, { color: colors.mutedForeground }]}>No mapped spots for this vibe yet.</Text></View> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  map: { flex: 1, minHeight: 420, overflow: "hidden", position: "relative" },
  mapChip: { alignItems: "center", borderRadius: 15, borderWidth: 1, flexDirection: "row", gap: 7, left: 18, paddingHorizontal: 11, paddingVertical: 8, position: "absolute", top: 18 },
  mapChipText: { fontSize: 11, fontWeight: "700" },
  pinCircle: { alignItems: "center", borderRadius: 20, borderWidth: 1, height: 38, justifyContent: "center", width: 38 },
  pinDot: { borderRadius: 10, height: 15, shadowOpacity: 0.8, shadowRadius: 9, width: 15 },
  mapCallout: { borderRadius: 14, borderWidth: 1, gap: 5, overflow: "hidden", padding: 8, width: 190 },
  mapCalloutPoster: { borderRadius: 8, height: 76, resizeMode: "cover", width: "100%" },
  mapCalloutTitle: { fontSize: 13, fontWeight: "900" },
  mapCalloutMeta: { fontSize: 10, lineHeight: 15 },
  mapCalloutAction: { fontSize: 11, fontWeight: "900", marginTop: 2 },
  mapEmpty: { alignItems: "center", borderRadius: 15, borderWidth: 1, flexDirection: "row", gap: 8, left: 24, paddingHorizontal: 12, paddingVertical: 10, position: "absolute", right: 24, top: "48%" },
  mapEmptyText: { flex: 1, fontSize: 12, fontWeight: "700" },
});