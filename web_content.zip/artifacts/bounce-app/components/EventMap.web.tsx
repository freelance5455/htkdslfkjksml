import { Image, Pressable, StyleSheet, Text, View } from "react-native";
import { Feather } from "@expo/vector-icons";
import type { PublicEvent } from "@workspace/api-client-react";
import { useColors } from "@/hooks/useColors";

const crowdColor: Record<string, string> = {
  Chill: "#7df2c1",
  Buzzing: "#ffd36a",
  Hype: "#ff9567",
  Packed: "#ff4f9a",
};
const money = (amount: number) => `JMD ${amount.toLocaleString("en-JM")}`;
const assetUrl = (path: string | null) =>
  path?.startsWith("http") ? path : path && process.env.EXPO_PUBLIC_DOMAIN ? `https://${process.env.EXPO_PUBLIC_DOMAIN}${path}` : path ?? "";

export default function EventMap({ colors, events, onOpen }: { colors: ReturnType<typeof useColors>; events: PublicEvent[]; onOpen: (event: PublicEvent) => void }) {
  return (
    <View style={[styles.map, { backgroundColor: colors.backgroundSoft }]}>
      <View style={[styles.mapRoad, styles.mapRoadOne, { borderColor: `${colors.primary}30` }]} />
      <View style={[styles.mapRoad, styles.mapRoadTwo, { borderColor: `${colors.accent}28` }]} />
      <View style={[styles.mapChip, { backgroundColor: colors.backgroundElevated, borderColor: colors.border }]}><Feather name="map" size={13} color={colors.mint} /><Text style={[styles.mapChipText, { color: colors.mutedForeground }]}>Kingston event map</Text></View>
      {events.map((event, index) => <Pressable key={event.id} onPress={() => onOpen(event)} style={[styles.pin, { left: `${18 + (index * 25) % 64}%`, top: `${25 + (index * 31) % 48}%` }]}><View style={[styles.pinCircle, { borderColor: colors.border, backgroundColor: colors.card }]}><View style={[styles.pinDot, { backgroundColor: crowdColor[event.crowdLevel] ?? crowdColor.Buzzing }]} /></View>{event.posterUrl ? <Image source={{ uri: assetUrl(event.posterUrl) }} style={styles.poster} /> : null}<Text numberOfLines={1} style={[styles.pinLabel, { color: colors.foreground }]}>{event.name}</Text><Text style={[styles.pinMeta, { color: colors.mutedForeground }]}>{event.venue} · {money(event.totalPriceJmd)}</Text></Pressable>)}
      {events.length === 0 ? <View style={[styles.mapEmpty, { backgroundColor: colors.backgroundElevated, borderColor: colors.border }]}><Feather name="map-pin" size={18} color={colors.pink} /><Text style={[styles.mapEmptyText, { color: colors.mutedForeground }]}>No mapped spots for this vibe yet.</Text></View> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  map: { flex: 1, minHeight: 420, overflow: "hidden", position: "relative" },
  mapRoad: { borderRadius: 100, borderWidth: 16, height: 520, position: "absolute", width: 160 },
  mapRoadOne: { left: "10%", top: "-12%", transform: [{ rotate: "35deg" }] },
  mapRoadTwo: { right: "0%", top: "18%", transform: [{ rotate: "-48deg" }] },
  mapChip: { alignItems: "center", borderRadius: 15, borderWidth: 1, flexDirection: "row", gap: 7, left: 18, paddingHorizontal: 11, paddingVertical: 8, position: "absolute", top: 18 },
  mapChipText: { fontSize: 11, fontWeight: "700" },
  pin: { alignItems: "center", position: "absolute", width: 125 },
  pinCircle: { alignItems: "center", borderRadius: 20, borderWidth: 1, height: 38, justifyContent: "center", width: 38 },
  pinDot: { borderRadius: 10, height: 15, width: 15 },
  poster: { borderRadius: 8, height: 38, marginTop: 4, resizeMode: "cover", width: 72 },
  pinLabel: { fontSize: 10, fontWeight: "800", marginTop: 4, textAlign: "center" },
  pinMeta: { fontSize: 9, textAlign: "center" },
  mapEmpty: { alignItems: "center", borderRadius: 15, borderWidth: 1, flexDirection: "row", gap: 8, left: 24, paddingHorizontal: 12, paddingVertical: 10, position: "absolute", right: 24, top: "48%" },
  mapEmptyText: { flex: 1, fontSize: 12, fontWeight: "700" },
});