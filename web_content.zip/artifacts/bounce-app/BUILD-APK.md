# Build the Bounce Android APK

This archive contains the Bounce Expo app and its shared API packages. Replit can run the Expo preview, but the Android SDK is not available in the workspace, so build the APK on a computer with Android Studio installed.

## 1. Install prerequisites

- Node.js 20 or newer
- pnpm
- Java JDK 17
- Android Studio with an Android SDK, Platform Tools, and Build Tools installed

## 2. Install dependencies

From the repository root:

```bash
pnpm install
```

## 3. Configure the mobile app

Before generating the Android project, provide the public API hostname and Clerk publishable key:

```bash
export EXPO_PUBLIC_DOMAIN="your-api-hostname.com"
export EXPO_PUBLIC_CLERK_PUBLISHABLE_KEY="your-clerk-publishable-key"
```

`EXPO_PUBLIC_DOMAIN` must be a hostname without `https://`. The API server, database, Clerk tenant, object storage, and Gemini poster extraction service must already be deployed and reachable from the Android device.

## 4. Generate and build the Android project

```bash
cd artifacts/bounce-app
pnpm exec expo prebuild --platform android
cd android
./gradlew assembleRelease
```

On Windows, run:

```powershell
gradlew.bat assembleRelease
```

The release APK will be at:

```text
android/app/build/outputs/apk/release/app-release.apk
```

Install it on a connected device with:

```bash
adb install -r android/app/build/outputs/apk/release/app-release.apk
```

## Notes

- `react-native-maps` is pinned to `1.18.0` for Expo Go compatibility.
- If Android map tiles are blank in the standalone APK, configure an Android Google Maps SDK key before running `expo prebuild`.
- Keep server-only values such as `GEMINI_API_KEY`, `SESSION_SECRET`, and Clerk secret keys out of the mobile build.