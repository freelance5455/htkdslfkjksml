/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const dark = {
  // Legacy aliases (kept for backward compatibility)
  text: '#f5efff',
  tint: '#a96cff',

  // Bounce night-radar surfaces
  background: '#120d21',
  foreground: '#f5efff',
  card: '#1b132b',
  cardForeground: '#f5efff',
  backgroundElevated: '#251839',
  backgroundSoft: '#211633',

  // Bounce energy
  primary: '#a96cff',
  primaryForeground: '#ffffff',
  accent: '#ff4f9a',
  accentForeground: '#ffffff',
  lavender: '#caa7ff',
  pink: '#ff70aa',
  mint: '#7df2c1',
  yellow: '#ffd36a',
  orange: '#ff9567',

  // Supporting surfaces
  secondary: '#302044',
  secondaryForeground: '#f5efff',
  muted: '#241a32',
  mutedForeground: '#a99db6',
  mutedOnDark: '#796d86',
  destructive: '#ff5d7a',
  destructiveForeground: '#ffffff',
  border: '#3b2a4d',
  input: '#342544',
};

const colors = {
  light: dark,
  dark,
  radius: 18,
};

export default colors;
