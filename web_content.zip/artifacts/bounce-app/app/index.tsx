import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Image,
  KeyboardAvoidingView,
  Linking,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import * as Location from "expo-location";
import * as ImagePicker from "expo-image-picker";
import { File } from "expo-file-system";
import { fetch as expoFetch } from "expo/fetch";
import * as WebBrowser from "expo-web-browser";
import * as AuthSession from "expo-auth-session";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import {
  useAuth,
  useSignIn,
  useSignUp,
  useSSO,
} from "@clerk/expo";
import {
  type CreateReviewRequest,
  type CreateEventFromPosterRequest,
  type FilterParameter,
  type PublicEvent,
  type PosterExtractionResponse,
  useCreateEventFromPoster,
  useCheckInEvent,
  useCreateReview,
  useExtractPoster,
  useGetEvent,
  useListEvents,
  useRequestUploadUrl,
  useSaveEvent,
  useUnsaveEvent,
} from "@workspace/api-client-react";
import { useColors } from "@/hooks/useColors";
import EventMap from "@/components/EventMap";

WebBrowser.maybeCompleteAuthSession();

type Screen =
  | "welcome"
  | "onboarding"
  | "signin"
  | "location"
  | "home"
  | "detail"
  | "checkin"
  | "review"
  | "suggest";
type ViewMode = "list" | "map";

const filters = ["Tonight", "Dancehall", "Soca", "Afrobeats"] as const;
const crowdMeta: Record<string, { color: string; phrase: string }> = {
  Chill: { color: "#7df2c1", phrase: "Easy to get a drink" },
  Buzzing: { color: "#ffd36a", phrase: "Good energy. Getting busy." },
  Hype: { color: "#ff9567", phrase: "It’s popping off right now!" },
  Packed: { color: "#ff4f9a", phrase: "Get here quick or skip the line." },
};

const money = (amount: number) => `JMD ${amount.toLocaleString("en-JM")}`;
const crowd = (level: string) => crowdMeta[level] ?? crowdMeta.Buzzing;
const eventDate = (value: string) =>
  new Intl.DateTimeFormat("en-JM", { weekday: "short", day: "numeric", month: "short" }).format(new Date(value));
const eventTime = (start: string, end: string) =>
  `${new Intl.DateTimeFormat("en-JM", { hour: "numeric", minute: "2-digit" }).format(new Date(start))} – ${new Intl.DateTimeFormat("en-JM", { hour: "numeric", minute: "2-digit" }).format(new Date(end))}`;
const assetUrl = (path: string | null) =>
  path?.startsWith("http") ? path : path && process.env.EXPO_PUBLIC_DOMAIN ? `https://${process.env.EXPO_PUBLIC_DOMAIN}${path}` : path ?? "";

function tap() {
  void Haptics.selectionAsync();
}

function Brand({ colors, compact = false }: { colors: ReturnType<typeof useColors>; compact?: boolean }) {
  return (
    <View style={[styles.brand, compact && styles.brandCompact]}>
      <LinearGradient colors={[colors.lavender, colors.accent]} style={styles.brandMark}>
        <View style={[styles.markLine, { backgroundColor: colors.primaryForeground }]} />
        <View style={[styles.markLine, styles.markLineSecond, { backgroundColor: `${colors.primaryForeground}CC` }]} />
      </LinearGradient>
      <Text style={[styles.brandText, { color: colors.foreground }]}>bounce<Text style={{ color: colors.pink }}>.</Text></Text>
    </View>
  );
}

function IconButton({ colors, icon, label, onPress }: {
  colors: ReturnType<typeof useColors>;
  icon: React.ComponentProps<typeof Feather>["name"];
  label: string;
  onPress: () => void;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={() => { tap(); onPress(); }}
      style={({ pressed }) => [styles.iconButton, { backgroundColor: colors.backgroundSoft, borderColor: colors.border }, pressed && styles.pressed]}
    >
      <Feather name={icon} size={18} color={colors.foreground} />
    </Pressable>
  );
}

function PrimaryButton({ colors, children, icon, onPress, disabled = false }: {
  colors: ReturnType<typeof useColors>;
  children: string;
  icon?: React.ComponentProps<typeof Feather>["name"];
  onPress: () => void;
  disabled?: boolean;
}) {
  return (
    <Pressable disabled={disabled} onPress={() => { tap(); onPress(); }} style={({ pressed }) => [styles.primaryButton, disabled && styles.disabled, pressed && styles.pressed]}>
      <LinearGradient colors={[colors.primary, colors.accent]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={styles.primaryGradient}>
        <Text style={[styles.primaryText, { color: colors.primaryForeground }]}>{children}</Text>
        {icon ? <Feather name={icon} size={18} color={colors.primaryForeground} /> : null}
      </LinearGradient>
    </Pressable>
  );
}

function BackButton({ colors, onPress, label = "Back" }: { colors: ReturnType<typeof useColors>; onPress: () => void; label?: string }) {
  return <IconButton colors={colors} icon="arrow-left" label={label} onPress={onPress} />;
}

function CrowdDot({ colors, level, large = false }: { colors: ReturnType<typeof useColors>; level: string; large?: boolean }) {
  const meta = crowd(level);
  return (
    <View style={styles.crowdRow}>
      <View style={[styles.crowdDot, large && styles.crowdDotLarge, { backgroundColor: meta.color, shadowColor: meta.color }]} />
      <Text style={[styles.crowdLabel, { color: meta.color }]}>{level}</Text>
    </View>
  );
}

function Rating({ colors, value, count }: { colors: ReturnType<typeof useColors>; value: number; count: number }) {
  return (
    <View style={styles.ratingRow}>
      <Feather name="star" size={14} color={colors.yellow} />
      <Text style={[styles.ratingValue, { color: colors.yellow }]}>{value.toFixed(1)}</Text>
      <Text style={[styles.ratingCount, { color: colors.mutedForeground }]}>({count})</Text>
    </View>
  );
}

function Welcome({ colors, insets, go }: { colors: ReturnType<typeof useColors>; insets: ReturnType<typeof useSafeAreaInsets>; go: (screen: Screen) => void }) {
  return (
    <View style={[styles.screen, { backgroundColor: colors.background, paddingTop: insets.top + 20, paddingBottom: insets.bottom + 20 }]}>
      <View style={[styles.glow, styles.glowTop, { backgroundColor: colors.primary }]} />
      <View style={[styles.glow, styles.glowBottom, { backgroundColor: colors.accent }]} />
      <Brand colors={colors} />
      <View style={styles.welcomeCopy}>
        <Text style={[styles.kicker, { color: colors.pink }]}>KINGSTON / AFTER DARK</Text>
        <Text style={[styles.hero, { color: colors.foreground }]}>Don’t scroll.{"\n"}<Text style={{ color: colors.pink }}>Bounce.</Text></Text>
        <Text style={[styles.bodyLarge, { color: colors.mutedForeground }]}>The real-time radar for wherever Kingston is coming alive tonight.</Text>
      </View>
      <View>
        <View style={styles.stepDots}><View style={[styles.stepDotActive, { backgroundColor: colors.accent }]} /><View style={[styles.stepDot, { backgroundColor: colors.border }]} /><View style={[styles.stepDot, { backgroundColor: colors.border }]} /></View>
        <PrimaryButton colors={colors} icon="arrow-right" onPress={() => go("onboarding")}>Find your next move</PrimaryButton>
        <Pressable onPress={() => go("signin")} style={styles.textButton}><Text style={[styles.textButtonLabel, { color: colors.mutedForeground }]}>I already have an account</Text></Pressable>
      </View>
    </View>
  );
}

function Onboarding({ colors, insets, step, setStep, go }: {
  colors: ReturnType<typeof useColors>;
  insets: ReturnType<typeof useSafeAreaInsets>;
  step: number;
  setStep: (value: number) => void;
  go: (screen: Screen) => void;
}) {
  const slides = [
    { kicker: "01 / FIND THE FREQUENCY", title: "See every party near you.", body: "A live radar of community-powered events, from rooftop sessions to street dances.", icon: "crosshair" as const, tint: colors.primary },
    { kicker: "02 / KNOW THE DAMAGE", title: "Know the exact price. No surprises.", body: "Base price plus every mandatory fee, upfront. Keep your JMD for the good stuff.", icon: "dollar-sign" as const, tint: colors.accent },
    { kicker: "03 / MAKE YOUR MOVE", title: "Tap. Bounce. Arrive.", body: "Pick a vibe, get directions, and be there before the next song starts.", icon: "navigation" as const, tint: colors.mint },
  ];
  const slide = slides[step];
  return (
    <View style={[styles.screen, { backgroundColor: colors.background, paddingTop: insets.top + 12, paddingBottom: insets.bottom + 20 }]}>
      <View style={styles.topBar}><BackButton colors={colors} onPress={() => step > 0 ? setStep(step - 1) : go("welcome")} /><Text style={[styles.mono, { color: colors.mutedForeground }]}>{String(step + 1).padStart(2, "0")} / 03</Text><Pressable onPress={() => go("signin")}><Text style={[styles.skip, { color: colors.mutedForeground }]}>Skip</Text></Pressable></View>
      <View style={styles.onboardingBody}>
        <View>
          <View style={[styles.onboardingIcon, { backgroundColor: colors.backgroundSoft, borderColor: colors.border, shadowColor: slide.tint }]}><Feather name={slide.icon} size={34} color={slide.tint} /></View>
          <Text style={[styles.kicker, { color: slide.tint }]}>{slide.kicker}</Text>
          <Text style={[styles.onboardingTitle, { color: colors.foreground }]}>{slide.title}</Text>
          <Text style={[styles.bodyLarge, { color: colors.mutedForeground }]}>{slide.body}</Text>
        </View>
        <View>
          <View style={styles.stepDots}>{slides.map((_, index) => <View key={index} style={[index === step ? styles.stepDotActiveWide : styles.stepDot, { backgroundColor: index === step ? colors.accent : colors.border }]} />)}</View>
          <PrimaryButton colors={colors} icon="arrow-right" onPress={() => step < 2 ? setStep(step + 1) : go("signin")}>{step < 2 ? "Keep going" : "Let’s find a party"}</PrimaryButton>
        </View>
      </View>
    </View>
  );
}

function SignIn({ colors, insets, go, toast }: { colors: ReturnType<typeof useColors>; insets: ReturnType<typeof useSafeAreaInsets>; go: (screen: Screen) => void; toast: (message: string) => void }) {
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [verifying, setVerifying] = useState(false);
  const [verifyCode, setVerifyCode] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { signIn, errors: signInErrors, fetchStatus: signInStatus } = useSignIn();
  const { signUp, errors: signUpErrors, fetchStatus: signUpStatus } = useSignUp();
  const { startSSOFlow } = useSSO();
  const isVerifying = mode === "signup" && verifying;
  const busy = signInStatus === "fetching" || signUpStatus === "fetching";
  const authError = mode === "signin"
    ? signInErrors.fields.identifier?.message ?? signInErrors.fields.password?.message
    : signUpErrors.fields.emailAddress?.message ?? signUpErrors.fields.password?.message ?? signUpErrors.fields.code?.message;

  const submit = async () => {
    try {
      if (mode === "signin") {
        await signIn.password({ emailAddress: email.trim(), password });
        if (signIn.status === "complete") {
          await signIn.finalize();
          go("location");
        }
        return;
      }
      if (!isVerifying) {
        await signUp.password({ emailAddress: email.trim(), password });
        await signUp.verifications.sendEmailCode();
        setVerifying(true);
        toast("Check your inbox for the verification code.");
        return;
      }
      await signUp.verifications.verifyEmailCode({ code: verifyCode.trim() });
      if (signUp.status === "complete") {
        await signUp.finalize();
        go("location");
      }
    } catch (error) {
      toast(error instanceof Error ? error.message : "Authentication failed. Try again.");
    }
  };

  const google = async () => {
    try {
      const { createdSessionId, setActive } = await startSSOFlow({
        strategy: "oauth_google",
        redirectUrl: AuthSession.makeRedirectUri({ scheme: "bounce" }),
      });
      if (createdSessionId) {
        if (setActive) await setActive({ session: createdSessionId });
        go("location");
      }
    } catch (error) {
      toast(error instanceof Error ? error.message : "Google sign-in is unavailable right now.");
    }
  };

  const facebook = async () => {
    try {
      const { createdSessionId, setActive } = await startSSOFlow({
        strategy: "oauth_facebook",
        redirectUrl: AuthSession.makeRedirectUri({ scheme: "bounce" }),
      });
      if (createdSessionId) {
        if (setActive) await setActive({ session: createdSessionId });
        go("location");
      }
    } catch (error) {
      toast(error instanceof Error ? error.message : "Facebook sign-in is unavailable right now.");
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: colors.background }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <ScrollView contentContainerStyle={[styles.scrollScreen, { paddingTop: insets.top + 12, paddingBottom: insets.bottom + 24 }]} keyboardShouldPersistTaps="handled">
        <BackButton colors={colors} onPress={() => go("welcome")} />
        <View style={styles.authIntro}><Brand colors={colors} compact /><Text style={[styles.authTitle, { color: colors.foreground }]}>{isVerifying ? "One more step," : "Your night,"}{"\n"}<Text style={{ color: colors.pink }}>{isVerifying ? "check your email." : "your call."}</Text></Text><Text style={[styles.body, { color: colors.mutedForeground }]}>{isVerifying ? "Enter the code we sent to verify your Bounce account." : "Sign in to see what’s moving around Kingston."}</Text></View>
        {!isVerifying ? <View style={styles.authMode}><Pressable onPress={() => setMode("signin")} style={[styles.authModeItem, mode === "signin" && { backgroundColor: colors.secondary }]}><Text style={[styles.authModeText, { color: mode === "signin" ? colors.foreground : colors.mutedForeground }]}>Sign in</Text></Pressable><Pressable onPress={() => setMode("signup")} style={[styles.authModeItem, mode === "signup" && { backgroundColor: colors.secondary }]}><Text style={[styles.authModeText, { color: mode === "signup" ? colors.foreground : colors.mutedForeground }]}>Create account</Text></Pressable></View> : null}
        <View style={styles.form}>
          <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>{verifying ? "VERIFICATION CODE" : "EMAIL"}</Text>
          {isVerifying ? <TextInput autoCapitalize="none" keyboardType="number-pad" placeholder="123456" placeholderTextColor={colors.mutedOnDark} value={verifyCode} onChangeText={setVerifyCode} style={[styles.input, { color: colors.foreground, backgroundColor: colors.backgroundSoft, borderColor: colors.border }]} /> : <TextInput autoCapitalize="none" keyboardType="email-address" placeholder="you@email.com" placeholderTextColor={colors.mutedOnDark} value={email} onChangeText={setEmail} style={[styles.input, { color: colors.foreground, backgroundColor: colors.backgroundSoft, borderColor: colors.border }]} />}
          {!isVerifying ? <><Text style={[styles.fieldLabel, { color: colors.mutedForeground, marginTop: 8 }]}>PASSWORD</Text><TextInput secureTextEntry placeholder="••••••••" placeholderTextColor={colors.mutedOnDark} value={password} onChangeText={setPassword} style={[styles.input, { color: colors.foreground, backgroundColor: colors.backgroundSoft, borderColor: colors.border }]} /></> : null}
          {authError ? <Text style={[styles.errorText, { color: colors.pink }]}>{authError}</Text> : null}
        </View>
        <PrimaryButton colors={colors} icon="arrow-right" disabled={busy || (isVerifying ? verifyCode.length < 4 : !email.includes("@") || password.length < 8)} onPress={() => { void submit(); }}>{busy ? "Working…" : isVerifying ? "Verify email" : mode === "signin" ? "Continue" : "Create account"}</PrimaryButton>
         {!isVerifying ? <><View style={styles.orRow}><View style={[styles.rule, { backgroundColor: colors.border }]} /><Text style={[styles.orText, { color: colors.mutedOnDark }]}>OR</Text><View style={[styles.rule, { backgroundColor: colors.border }]} /></View><Pressable onPress={() => { void google(); }} style={({ pressed }) => [styles.googleButton, { backgroundColor: colors.backgroundSoft, borderColor: colors.border }, pressed && styles.pressed]}><Text style={styles.googleMark}>G</Text><Text style={[styles.googleText, { color: colors.foreground }]}>Continue with Google</Text></Pressable><Pressable onPress={() => { void facebook(); }} style={({ pressed }) => [styles.googleButton, { backgroundColor: colors.backgroundSoft, borderColor: colors.border }, pressed && styles.pressed]}><Text style={styles.facebookMark}>f</Text><Text style={[styles.googleText, { color: colors.foreground }]}>Continue with Facebook</Text></Pressable></> : null}
        <View style={styles.privacyRow}><Feather name="lock" size={14} color={colors.mutedOnDark} /><Text style={[styles.privacy, { color: colors.mutedOnDark }]}>Your profile stays private. Crowd numbers are always anonymous.</Text></View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

function LocationGate({ colors, insets, permission, requestPermission, go, toast }: { colors: ReturnType<typeof useColors>; insets: ReturnType<typeof useSafeAreaInsets>; permission: Location.PermissionResponse | null; requestPermission: () => Promise<Location.PermissionResponse>; go: (screen: Screen) => void; toast: (message: string) => void }) {
  const requestLocation = async () => {
    if (Platform.OS === "web") { go("home"); return; }
    const result = await requestPermission();
    if (result.granted) { toast("Location is on. Nearby events are ready."); go("home"); }
    else if (!result.canAskAgain) { void Linking.openSettings(); }
    else toast("Location helps Bounce sort what you can reach fastest.");
  };
  const blocked = permission?.status === "denied" && permission.canAskAgain === false;
  return (
    <View style={[styles.screen, { backgroundColor: colors.background, paddingTop: insets.top + 12, paddingBottom: insets.bottom + 20 }]}>
      <BackButton colors={colors} onPress={() => go("signin")} />
      <View style={styles.locationCenter}><View style={[styles.locationOrb, { backgroundColor: `${colors.accent}18`, borderColor: `${colors.accent}70`, shadowColor: colors.primary }]}><Feather name="crosshair" size={42} color={colors.pink} /></View><Text style={[styles.kicker, { color: colors.pink }]}>LOCATION REQUIRED</Text><Text style={[styles.locationTitle, { color: colors.foreground }]}>Know what’s{"\n"}<Text style={{ color: colors.pink }}>near you.</Text></Text><Text style={[styles.body, { color: colors.mutedForeground, textAlign: "center" }]}>Turn on location to see live crowd levels and sort events by what you can reach fastest.</Text></View>
      {blocked ? <Pressable onPress={() => void Linking.openSettings()} style={[styles.secondaryButton, { borderColor: colors.border, backgroundColor: colors.backgroundSoft }]}><Feather name="settings" size={17} color={colors.foreground} /><Text style={[styles.secondaryText, { color: colors.foreground }]}>Open Settings</Text></Pressable> : <PrimaryButton colors={colors} icon="arrow-right" onPress={() => { void requestLocation(); }}>Use my location</PrimaryButton>}
      <Pressable onPress={() => go("home")} style={styles.textButton}><Text style={[styles.textButtonLabel, { color: colors.mutedForeground }]}>Use Kingston for now</Text></Pressable>
    </View>
  );
}

function EventCard({ colors, event, onOpen, onSave, saving }: { colors: ReturnType<typeof useColors>; event: PublicEvent; onOpen: () => void; onSave: () => void; saving: boolean }) {
  return (
    <View style={[styles.eventCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <Pressable onPress={onOpen} style={({ pressed }) => [styles.eventCardPress, pressed && styles.pressed]}>
        <View style={styles.eventTop}>{event.posterUrl ? <Image source={{ uri: assetUrl(event.posterUrl) }} style={styles.eventPosterThumb} /> : <LinearGradient colors={[event.accent, colors.backgroundSoft]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.eventMark}><Text style={[styles.eventMarkText, { color: colors.primaryForeground }]}>{event.mark}</Text></LinearGradient>}<View style={styles.eventMain}><View style={styles.eventNameRow}><Text numberOfLines={1} style={[styles.eventName, { color: colors.foreground }]}>{event.name}</Text><Text style={[styles.distance, { color: colors.mutedForeground }]}>{event.city}</Text></View><Text numberOfLines={1} style={[styles.venue, { color: colors.mutedForeground }]}>{event.venue}</Text><View style={styles.eventMeta}><CrowdDot colors={colors} level={event.crowdLevel} /><Rating colors={colors} value={event.rating} count={event.reviewCount} /></View></View></View>
        <View style={styles.eventBottom}><View><Text style={[styles.mono, { color: colors.mutedOnDark }]}>TOTAL TONIGHT</Text><Text style={[styles.eventPrice, { color: colors.foreground }]}>{money(event.totalPriceJmd)}</Text></View><View style={styles.vibeWrap}>{event.vibeTags.map((tag) => <Text key={tag} style={[styles.vibe, { backgroundColor: colors.backgroundSoft, color: colors.mutedForeground }]}>#{tag}</Text>)}</View></View>
      </Pressable>
      <Pressable disabled={saving} accessibilityLabel={event.isSaved ? `Remove ${event.name} from saved events` : `Save ${event.name}`} onPress={onSave} style={styles.saveButton}><Feather name="heart" size={16} color={event.isSaved ? colors.pink : colors.mutedForeground} /></Pressable>
    </View>
  );
}

function Home({ colors, insets, openEvent, suggest, toast, restart }: { colors: ReturnType<typeof useColors>; insets: ReturnType<typeof useSafeAreaInsets>; openEvent: (event: PublicEvent) => void; suggest: () => void; toast: (message: string) => void; restart: () => void }) {
  const [view, setView] = useState<ViewMode>("list");
  const [filter, setFilter] = useState<(typeof filters)[number]>("Tonight");
  const [menuOpen, setMenuOpen] = useState(false);
  const query = useListEvents(filter === "Tonight" ? undefined : { filter: filter as FilterParameter });
  const saveMutation = useSaveEvent();
  const unsaveMutation = useUnsaveEvent();
  const events = query.data?.events ?? [];
  const save = (event: PublicEvent) => {
    const mutation = event.isSaved ? unsaveMutation : saveMutation;
    mutation.mutate({ eventId: event.id }, { onSuccess: () => { void query.refetch(); toast(event.isSaved ? "Removed from your saved spots" : "Saved for later"); }, onError: () => toast("Could not update saved spots. Try again.") });
  };
  return (
    <View style={[styles.home, { backgroundColor: colors.background }]}>
      <View style={[styles.homeHeader, { paddingTop: insets.top + 12 }]}><View><Brand colors={colors} compact /><View style={styles.locationLabel}><Feather name="map-pin" size={12} color={colors.pink} /><Text style={[styles.locationText, { color: colors.mutedForeground }]}>Kingston, Jamaica</Text></View></View><View style={styles.menuWrap}><IconButton colors={colors} icon="menu" label="Open menu" onPress={() => setMenuOpen((value) => !value)} />{menuOpen ? <View style={[styles.menu, { backgroundColor: colors.backgroundElevated, borderColor: colors.border }]}><Pressable onPress={restart} style={styles.menuItem}><Feather name="rotate-ccw" size={15} color={colors.foreground} /><Text style={[styles.menuText, { color: colors.foreground }]}>Restart walkthrough</Text></Pressable><Pressable onPress={() => toast("Bounce shows verified crowd energy, total prices, and what is happening nearby.")} style={styles.menuItem}><Feather name="help-circle" size={15} color={colors.foreground} /><Text style={[styles.menuText, { color: colors.foreground }]}>How Bounce works</Text></Pressable></View> : null}</View></View>
      <View style={styles.homeIntro}><View><Text style={[styles.kicker, { color: colors.pink }]}>LIVE RADAR <Text style={{ color: colors.mint }}>•</Text></Text><Text style={[styles.homeTitle, { color: colors.foreground }]}>What’s the move?</Text></View><IconButton colors={colors} icon="rotate-ccw" label="Refresh radar" onPress={() => { void query.refetch(); }} /></View>
      <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + 94 }} showsVerticalScrollIndicator={false}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filterRow}>{filters.map((item) => <Pressable key={item} onPress={() => { tap(); setFilter(item); }} style={[styles.filter, { backgroundColor: filter === item ? colors.accent : colors.backgroundSoft, borderColor: filter === item ? colors.accent : colors.border }]}><Text style={[styles.filterText, { color: filter === item ? colors.foreground : colors.mutedForeground }]}>{item}</Text></Pressable>)}</ScrollView>
        <View style={[styles.segment, { backgroundColor: colors.backgroundSoft, borderColor: colors.border }]}><Pressable onPress={() => setView("list")} style={[styles.segmentItem, view === "list" && { backgroundColor: colors.secondary }]}><Feather name="menu" size={14} color={view === "list" ? colors.foreground : colors.mutedForeground} /><Text style={[styles.segmentText, { color: view === "list" ? colors.foreground : colors.mutedForeground }]}>List view</Text></Pressable><Pressable onPress={() => setView("map")} style={[styles.segmentItem, view === "map" && { backgroundColor: colors.secondary }]}><Feather name="map" size={14} color={view === "map" ? colors.foreground : colors.mutedForeground} /><Text style={[styles.segmentText, { color: view === "map" ? colors.foreground : colors.mutedForeground }]}>Map view</Text></Pressable></View>
         {query.isLoading ? <View style={styles.centerState}><ActivityIndicator color={colors.accent} /><Text style={[styles.stateText, { color: colors.mutedForeground }]}>Finding the move…</Text></View> : query.isError ? <View style={styles.centerState}><Feather name="wifi-off" size={24} color={colors.pink} /><Text style={[styles.stateText, { color: colors.mutedForeground }]}>Couldn’t reach the radar.</Text><Pressable onPress={() => { void query.refetch(); }}><Text style={[styles.nearest, { color: colors.pink }]}>Try again</Text></Pressable></View> : view === "list" ? <View style={styles.eventList}><View style={styles.listHeading}><Text style={[styles.listCount, { color: colors.mutedForeground }]}>{events.length} {events.length === 1 ? "spot" : "spots"} nearby</Text><Text style={[styles.nearest, { color: colors.pink }]}>Live now</Text></View>{events.map((event) => <EventCard key={event.id} colors={colors} event={event} onOpen={() => openEvent(event)} onSave={() => save(event)} saving={saveMutation.isPending || unsaveMutation.isPending} />)}{events.length === 0 ? <Text style={[styles.stateText, { color: colors.mutedForeground }]}>No published events match this vibe yet.</Text> : null}<Pressable onPress={suggest} style={[styles.suggestButton, { backgroundColor: `${colors.primary}12`, borderColor: `${colors.primary}70` }]}><Feather name="plus" size={17} color={colors.lavender} /><Text style={[styles.suggestText, { color: colors.lavender }]}>Upload a party poster</Text></Pressable></View> : <EventMap colors={colors} events={events} onOpen={openEvent} />}
      </ScrollView>
      <View style={[styles.bottomNav, { backgroundColor: `${colors.background}F2`, borderColor: colors.border, paddingBottom: insets.bottom + 8 }]}><Pressable onPress={() => setView("list")} style={styles.navItem}><Feather name="compass" size={19} color={colors.pink} /><Text style={[styles.navLabel, { color: colors.pink }]}>Explore</Text></Pressable><Pressable onPress={() => toast("Saved events appear on each event card and stay linked to your account.")} style={styles.navItem}><Feather name="heart" size={19} color={colors.mutedForeground} /><Text style={[styles.navLabel, { color: colors.mutedForeground }]}>Saved</Text></Pressable><Pressable onPress={suggest} style={styles.navItem}><Feather name="send" size={19} color={colors.mutedForeground} /><Text style={[styles.navLabel, { color: colors.mutedForeground }]}>Suggest</Text></Pressable></View>
    </View>
  );
}

function Detail({ colors, insets, event, go, toast }: { colors: ReturnType<typeof useColors>; insets: ReturnType<typeof useSafeAreaInsets>; event: PublicEvent; go: (screen: Screen) => void; toast: (message: string) => void }) {
  const query = useGetEvent(event.id);
  const current = query.data?.event ?? event;
  const reviews = query.data?.reviews ?? [];
  const meta = crowd(current.crowdLevel);
  const share = async () => { await Share.share({ title: current.name, message: `${current.name} at ${current.venue} · ${eventDate(current.eventDate)} · ${money(current.totalPriceJmd)}` }); };
  const directions = () => { const queryText = encodeURIComponent(`${current.address}, ${current.city}, ${current.country}`); void Linking.openURL(`https://www.google.com/maps/search/?api=1&query=${queryText}`); };
  return (
    <View style={[styles.detail, { backgroundColor: colors.background }]}><ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + 26 }} showsVerticalScrollIndicator={false}>
      <LinearGradient colors={[`${current.accent}F2`, `${colors.background}F8`]} start={{ x: 0.1, y: 0 }} end={{ x: 1, y: 1 }} style={[styles.detailHero, { paddingTop: insets.top + 12 }]}>{current.posterUrl ? <Image source={{ uri: assetUrl(current.posterUrl) }} style={styles.detailPoster} /> : null}<View style={styles.detailTop}><BackButton colors={colors} label="Back to discovery" onPress={() => go("home")} /><View style={styles.detailActions}><IconButton colors={colors} icon="share-2" label="Share event" onPress={() => { void share(); }} /><IconButton colors={colors} icon="heart" label={current.isSaved ? "Saved event" : "Save event"} onPress={() => toast(current.isSaved ? "Saved event" : "Save it from the radar")} /></View></View><Text style={[styles.mono, { color: colors.foreground }]}>{current.mark} / KINGSTON</Text><Text style={[styles.detailTitle, { color: colors.foreground }]}>{current.name}</Text></LinearGradient>
      <View style={styles.detailContent}><View style={styles.detailVenue}><View><Text style={[styles.detailVenueName, { color: colors.foreground }]}>{current.venue}</Text><View style={styles.address}><Feather name="map-pin" size={13} color={colors.pink} /><Text style={[styles.addressText, { color: colors.mutedForeground }]}>{current.address}</Text></View></View><Text style={[styles.distancePill, { backgroundColor: colors.backgroundSoft, color: colors.mutedForeground }]}>{current.city}</Text></View>
        <View style={[styles.priceCard, { backgroundColor: colors.backgroundElevated, borderColor: `${colors.accent}70` }]}><View><Text style={[styles.mono, { color: colors.mutedForeground }]}>TOTAL PRICE</Text><Text style={[styles.detailPrice, { color: colors.foreground }]}>{money(current.totalPriceJmd)}</Text><View style={styles.included}><Feather name="check" size={13} color={colors.mint} /><Text style={[styles.includedText, { color: colors.mutedForeground }]}>Everything included</Text></View></View><View style={[styles.dateBlock, { borderColor: colors.border }]}><Text style={[styles.date, { color: colors.mutedForeground }]}>{eventDate(current.eventDate)}</Text><Text style={[styles.time, { color: colors.foreground }]}><Feather name="clock" size={13} color={colors.pink} /> {eventTime(current.eventDate, current.endDate)}</Text></View></View>
        <View style={[styles.breakdown, { backgroundColor: `${colors.backgroundSoft}AA`, borderColor: colors.border }]}><View style={styles.breakdownHeading}><Text style={[styles.breakdownTitle, { color: colors.foreground }]}>Price breakdown</Text><Text style={[styles.mono, { color: colors.mutedOnDark }]}>JMD</Text></View><View style={styles.breakdownRows}><View style={styles.breakdownRow}><Text style={[styles.breakdownLabel, { color: colors.mutedForeground }]}>Base entry</Text><Text style={[styles.breakdownLabel, { color: colors.mutedForeground }]}>{money(current.basePriceJmd)}</Text></View>{current.fees.map((fee) => <View style={styles.breakdownRow} key={fee.name}><Text style={[styles.breakdownLabel, { color: colors.mutedForeground }]}>{fee.name}</Text><Text style={[styles.breakdownLabel, { color: colors.mutedForeground }]}>{money(fee.amount)}</Text></View>)}<View style={[styles.breakdownRow, styles.totalRow, { borderColor: colors.border }]}><Text style={[styles.breakdownLabel, { color: colors.foreground, fontWeight: "700" }]}>Total at the door</Text><Text style={[styles.breakdownLabel, { color: colors.foreground, fontWeight: "700" }]}>{money(current.totalPriceJmd)}</Text></View></View></View>
        <Pressable onPress={directions} style={({ pressed }) => [styles.directionsButton, { backgroundColor: `${colors.mint}18`, borderColor: `${colors.mint}70` }, pressed && styles.pressed]}><Feather name="navigation" size={17} color={colors.mint} /><Text style={[styles.directionsText, { color: colors.mint }]}>Get directions</Text><Feather name="external-link" size={13} color={colors.mint} /></Pressable>
        <View style={[styles.crowdCard, { backgroundColor: `${colors.backgroundSoft}AA`, borderColor: colors.border }]}><View style={[styles.crowdOrb, { backgroundColor: `${meta.color}18`, borderColor: `${meta.color}80`, shadowColor: meta.color }]}><View style={[styles.crowdOrbDot, { backgroundColor: meta.color, shadowColor: meta.color }]} /></View><View><View style={styles.liveRow}><Text style={[styles.crowdTitle, { color: meta.color }]}>{current.crowdLevel} right now</Text><Text style={[styles.livePill, { backgroundColor: colors.backgroundElevated, color: colors.mutedForeground }]}>LIVE</Text></View><Text style={[styles.crowdPhrase, { color: colors.mutedForeground }]}>{current.crowdLabel} · {meta.phrase}</Text></View></View>
        <View style={styles.ratingDetail}><Rating colors={colors} value={current.rating} count={current.reviewCount} /><View style={styles.verified}><Feather name="shield" size={13} color={colors.mint} /><Text style={[styles.verifiedText, { color: colors.mint }]}>Verified attendees</Text></View></View>
        <Text style={[styles.detailDescription, { color: colors.mutedForeground }]}>{current.description}</Text><View style={styles.vibeWrap}>{current.vibeTags.map((tag) => <Text key={tag} style={[styles.detailVibe, { color: colors.lavender, backgroundColor: `${colors.primary}18`, borderColor: `${colors.primary}55` }]}>#{tag}</Text>)}</View>
        <View style={styles.reviewHeading}><Text style={[styles.reviewTitle, { color: colors.foreground }]}>What people said</Text><Text style={[styles.small, { color: colors.mutedForeground }]}>{reviews.length} recent reviews</Text></View>
        {query.isLoading ? <ActivityIndicator color={colors.accent} /> : reviews.length === 0 ? <Text style={[styles.small, { color: colors.mutedForeground }]}>No reviews yet. Be the first verified voice.</Text> : reviews.map((review) => <View key={review.id} style={[styles.reviewCard, { backgroundColor: `${colors.backgroundSoft}AA`, borderColor: colors.border }]}><View style={styles.reviewCardTop}><Text style={[styles.reviewAuthor, { color: colors.foreground }]}>{review.author} <Text style={{ color: colors.mint, fontSize: 10 }}>verified</Text></Text><Text style={[styles.reviewTime, { color: colors.mutedOnDark }]}>{new Date(review.createdAt).toLocaleDateString("en-JM")}</Text></View><View style={styles.stars}>{[1, 2, 3, 4, 5].map((item) => <Feather name="star" key={item} size={13} color={item <= review.rating ? colors.yellow : colors.mutedOnDark} />)}</View><Text style={[styles.reviewCopy, { color: colors.mutedForeground }]}>{review.comment}</Text></View>)}
        <View style={styles.detailCtas}><PrimaryButton colors={colors} icon={current.isCheckedIn ? "check" : "zap"} onPress={() => go("checkin" as Screen)}>{current.isCheckedIn ? "You’re checked in" : "I’m Here!"}</PrimaryButton><Pressable disabled={!current.isCheckedIn} onPress={() => go("review")} style={({ pressed }) => [styles.reviewButton, { backgroundColor: colors.backgroundSoft, borderColor: colors.border }, !current.isCheckedIn && styles.disabled, pressed && styles.pressed]}><Feather name="message-circle" size={16} color={colors.foreground} /><Text style={[styles.reviewButtonText, { color: colors.foreground }]}>Write a Review</Text></Pressable></View>
      </View>
    </ScrollView></View>
  );
}

function CheckIn({ colors, insets, event, go, toast }: { colors: ReturnType<typeof useColors>; insets: ReturnType<typeof useSafeAreaInsets>; event: PublicEvent; go: (screen: Screen) => void; toast: (message: string) => void }) {
  const [done, setDone] = useState(event.isCheckedIn);
  const mutation = useCheckInEvent();
  const checkIn = () => mutation.mutate({ eventId: event.id }, { onSuccess: () => { setDone(true); toast("You’re checked in. Review access unlocked."); }, onError: () => toast("Could not check you in. Try again.") });
  return <View style={[styles.screen, { backgroundColor: colors.background, paddingTop: insets.top + 12, paddingBottom: insets.bottom + 20 }]}><View style={styles.topBar}><BackButton colors={colors} onPress={() => go("detail")} /><Text style={[styles.mono, { color: colors.mutedForeground }]}>CHECK-IN</Text><View style={{ width: 42 }} /></View><View style={styles.locationCenter}><View style={[styles.checkinIcon, { backgroundColor: `${colors.mint}18`, borderColor: `${colors.mint}70`, shadowColor: colors.mint }]}><Feather name={done ? "check" : "zap"} size={42} color={colors.mint} /></View><Text style={[styles.kicker, { color: colors.mint }]}>{done ? "YOU’RE IN" : "AT THE DOOR?"}</Text><Text style={[styles.locationTitle, { color: colors.foreground }]}>{done ? "Welcome to the{" : "Check in at"}{"\n"}<Text style={{ color: colors.pink }}>{done ? event.name : event.venue}</Text></Text><Text style={[styles.body, { color: colors.mutedForeground, textAlign: "center" }]}>{done ? "Your verified review is now unlocked." : "Confirm you’re here to add your voice to the live crowd signal."}</Text></View>{done ? <PrimaryButton colors={colors} icon="message-circle" onPress={() => go("review")}>Write a review</PrimaryButton> : <PrimaryButton colors={colors} icon="check" disabled={mutation.isPending} onPress={checkIn}>{mutation.isPending ? "Checking in…" : "Check me in"}</PrimaryButton>}</View>;
}

function ReviewScreen({ colors, insets, go, submit, submitting }: { colors: ReturnType<typeof useColors>; insets: ReturnType<typeof useSafeAreaInsets>; go: (screen: Screen) => void; submit: (data: CreateReviewRequest) => void; submitting: boolean }) {
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [tag, setTag] = useState("");
  const tags = ["Good vibes", "Amazing DJ", "Great crowd", "Cheap drinks", "Too packed"];
  const valid = rating > 0 && comment.trim().length >= 10;
  return <KeyboardAvoidingView style={{ flex: 1, backgroundColor: colors.background }} behavior={Platform.OS === "ios" ? "padding" : undefined}><ScrollView contentContainerStyle={[styles.scrollScreen, { paddingTop: insets.top + 12, paddingBottom: insets.bottom + 26 }]} keyboardShouldPersistTaps="handled"><View style={styles.topBar}><BackButton colors={colors} onPress={() => go("detail")} label="Back to event" /><Text style={[styles.mono, { color: colors.mutedForeground }]}>VERIFIED REVIEW</Text><View style={{ width: 42 }} /></View><View style={styles.reviewIntro}><Text style={[styles.kicker, { color: colors.pink }]}>YOU WERE THERE</Text><Text style={[styles.authTitle, { color: colors.foreground }]}>How was{"\n"}<Text style={{ color: colors.pink }}>the bounce?</Text></Text><Text style={[styles.body, { color: colors.mutedForeground }]}>Your review helps the next person make a better call.</Text></View><Text style={[styles.formSectionLabel, { color: colors.foreground }]}>Give it a rating</Text><View style={styles.starPicker}>{[1, 2, 3, 4, 5].map((value) => <Pressable key={value} accessibilityLabel={`${value} stars`} onPress={() => setRating(value)}><Feather name="star" size={34} color={value <= rating ? colors.yellow : colors.mutedOnDark} /></Pressable>)}</View><Text style={[styles.formSectionLabel, { color: colors.foreground }]}>Say a little more</Text><TextInput multiline maxLength={500} value={comment} onChangeText={setComment} placeholder="How was the crowd, sound, or service?" placeholderTextColor={colors.mutedOnDark} style={[styles.reviewInput, { color: colors.foreground, backgroundColor: colors.backgroundSoft, borderColor: colors.border }]} /><Text style={[styles.counter, { color: colors.mutedOnDark }]}>{comment.length}/500</Text><Text style={[styles.formSectionLabel, { color: colors.foreground }]}>Tag the vibe</Text><View style={styles.tagPicker}>{tags.map((item) => <Pressable key={item} onPress={() => setTag(tag === item ? "" : item)} style={[styles.tag, { backgroundColor: tag === item ? `${colors.accent}22` : colors.backgroundSoft, borderColor: tag === item ? colors.accent : colors.border }]}><Text style={[styles.tagText, { color: tag === item ? colors.pink : colors.mutedForeground }]}>{item}</Text></Pressable>)}</View><PrimaryButton colors={colors} icon="send" disabled={!valid || submitting} onPress={() => submit({ rating, comment: `${comment.trim()}${tag ? ` ${tag}.` : ""}`, tag: tag || undefined })}>{submitting ? "Publishing…" : "Publish verified review"}</PrimaryButton></ScrollView></KeyboardAvoidingView>;
}

function SuggestEvent({ colors, insets, go, toast }: { colors: ReturnType<typeof useColors>; insets: ReturnType<typeof useSafeAreaInsets>; go: (screen: Screen) => void; toast: (message: string) => void }) {
  const [posterAsset, setPosterAsset] = useState<ImagePicker.ImagePickerAsset | null>(null);
  const [posterPath, setPosterPath] = useState("");
  const [extraction, setExtraction] = useState<PosterExtractionResponse | null>(null);
  const [form, setForm] = useState({
    name: "", venue: "", address: "", eventDate: "", endDate: "",
    basePriceJmd: "", serviceFeeJmd: "0", doorChargeJmd: "0",
    vibeTags: "", description: "",
  });
  const uploadMutation = useRequestUploadUrl();
  const extractMutation = useExtractPoster();
  const createMutation = useCreateEventFromPoster();
  const setField = (field: keyof typeof form, value: string) => setForm((current) => ({ ...current, [field]: value }));
  const isBusy = uploadMutation.isPending || extractMutation.isPending || createMutation.isPending;

  const pickPoster = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images"],
      allowsEditing: false,
      quality: 0.85,
    });
    if (result.canceled || !result.assets[0]) return;
    const selected = result.assets[0];
    const contentType: "image/jpeg" | "image/png" | "image/webp" =
      selected.mimeType === "image/png" ? "image/png" :
      selected.mimeType === "image/webp" ? "image/webp" : "image/jpeg";
    const size = selected.fileSize ?? new File(selected.uri).size;
    if (size && size > 8 * 1024 * 1024) {
      toast("Choose a poster smaller than 8 MB.");
      return;
    }
    setPosterAsset(selected);
    try {
      const upload = await uploadMutation.mutateAsync({ data: { name: selected.fileName ?? "bounce-poster.jpg", size: size || 1, contentType } });
      const file = new File(selected.uri);
      const uploadResponse = await expoFetch(upload.uploadURL, {
        method: "PUT",
        headers: { "Content-Type": contentType },
        body: file,
      });
      if (!uploadResponse.ok) throw new Error("Poster upload failed");
      const parsed = await extractMutation.mutateAsync({ data: { objectPath: upload.objectPath, contentType } });
      setPosterPath(upload.objectPath);
      setExtraction(parsed);
      setForm({
        name: parsed.name ?? "",
        venue: parsed.venue ?? "",
        address: parsed.address ?? "",
        eventDate: parsed.eventDate ?? "",
        endDate: parsed.endDate ?? "",
        basePriceJmd: parsed.basePriceJmd?.toString() ?? "",
        serviceFeeJmd: parsed.serviceFeeJmd?.toString() ?? "0",
        doorChargeJmd: parsed.doorChargeJmd?.toString() ?? "0",
        vibeTags: parsed.vibeTags.join(", "),
        description: parsed.description ?? "",
      });
      toast("Poster read. Check the details before publishing.");
    } catch (error) {
      setPosterAsset(null);
      toast(error instanceof Error ? error.message : "Could not read that poster. Try another image.");
    }
  };

  const submit = () => {
    const vibeTags = form.vibeTags.split(",").map((tag) => tag.trim()).filter(Boolean);
    const parseMoney = (value: string) => Number.parseInt(value.replace(/[^0-9]/g, ""), 10);
    const data: CreateEventFromPosterRequest = {
      name: form.name.trim(),
      venue: form.venue.trim(),
      address: form.address.trim(),
      eventDate: new Date(form.eventDate).toISOString(),
      endDate: new Date(form.endDate).toISOString(),
      basePriceJmd: parseMoney(form.basePriceJmd),
      serviceFeeJmd: parseMoney(form.serviceFeeJmd),
      doorChargeJmd: parseMoney(form.doorChargeJmd),
      vibeTags,
      description: form.description.trim(),
      posterPath,
      latitude: null,
      longitude: null,
    };
    createMutation.mutate({ data }, { onSuccess: () => { toast("Party log published with its poster."); go("home"); }, onError: () => toast("Check every poster detail before publishing.") });
  };

  const valid = Boolean(
    posterPath && extraction && form.name.trim().length >= 2 && form.venue.trim().length >= 2 &&
    form.address.trim().length >= 2 && form.description.trim().length >= 10 &&
    form.vibeTags.split(",").some((tag) => tag.trim()) &&
    Number.isInteger(Number(form.basePriceJmd)) && Number(form.basePriceJmd) >= 0 &&
    Number.isInteger(Number(form.serviceFeeJmd)) && Number(form.serviceFeeJmd) >= 0 &&
    Number.isInteger(Number(form.doorChargeJmd)) && Number(form.doorChargeJmd) >= 0 &&
    !Number.isNaN(new Date(form.eventDate).getTime()) && !Number.isNaN(new Date(form.endDate).getTime()) &&
    new Date(form.endDate) > new Date(form.eventDate),
  );
  const field = (label: string, key: keyof typeof form, placeholder: string, options?: { keyboardType?: "default" | "numeric" }) => (
    <View style={styles.posterField} key={key}>
      <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>{label}</Text>
      <TextInput value={form[key]} onChangeText={(value) => setField(key, value)} placeholder={placeholder} placeholderTextColor={colors.mutedOnDark} keyboardType={options?.keyboardType} style={[styles.input, { color: colors.foreground, backgroundColor: colors.backgroundSoft, borderColor: colors.border }]} />
    </View>
  );
  return <KeyboardAvoidingView style={{ flex: 1, backgroundColor: colors.background }} behavior={Platform.OS === "ios" ? "padding" : undefined}><ScrollView contentContainerStyle={[styles.scrollScreen, { paddingTop: insets.top + 12, paddingBottom: insets.bottom + 26 }]} keyboardShouldPersistTaps="handled"><BackButton colors={colors} onPress={() => go("home")} /><View style={styles.authIntro}><Text style={[styles.kicker, { color: colors.pink }]}>POSTER TO PARTY LOG</Text><Text style={[styles.authTitle, { color: colors.foreground }]}>Put the night{"\n"}<Text style={{ color: colors.pink }}>on the radar.</Text></Text><Text style={[styles.body, { color: colors.mutedForeground }]}>Upload the flyer. Bounce will read the details, then you can correct anything before the party log goes live.</Text></View><Pressable disabled={isBusy} onPress={() => { void pickPoster(); }} style={[styles.posterPicker, { backgroundColor: colors.backgroundSoft, borderColor: colors.border }]}>{posterAsset ? <Image source={{ uri: posterAsset.uri }} style={styles.posterPreview} /> : <><Feather name="upload-cloud" size={28} color={colors.pink} /><Text style={[styles.posterPickerTitle, { color: colors.foreground }]}>Choose a party poster</Text><Text style={[styles.posterPickerMeta, { color: colors.mutedForeground }]}>JPEG, PNG, or WebP · up to 8 MB</Text></>}</Pressable>{isBusy ? <View style={styles.posterStatus}><ActivityIndicator color={colors.accent} /><Text style={[styles.small, { color: colors.mutedForeground }]}>{uploadMutation.isPending ? "Uploading poster…" : extractMutation.isPending ? "Reading party details…" : "Publishing party log…"}</Text></View> : null}{extraction ? <View style={[styles.posterForm, { borderColor: colors.border }]}><Text style={[styles.formSectionLabel, { color: colors.foreground }]}>Confirm the extracted details</Text>{field("EVENT NAME", "name", "Friday night session")}{field("VENUE", "venue", "Venue or neighborhood")}{field("ADDRESS", "address", "Street address, Kingston")}{field("START (ISO OR DATE/TIME)", "eventDate", "2026-09-05T21:00:00-05:00")}{field("END (ISO OR DATE/TIME)", "endDate", "2026-09-06T02:00:00-05:00")}{field("BASE PRICE (JMD)", "basePriceJmd", "2000", { keyboardType: "numeric" })}{field("SERVICE FEE (JMD)", "serviceFeeJmd", "0", { keyboardType: "numeric" })}{field("DOOR CHARGE (JMD)", "doorChargeJmd", "0", { keyboardType: "numeric" })}{field("VIBES (COMMA SEPARATED)", "vibeTags", "Dancehall, Soca")}{<View style={styles.posterField}><Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>DESCRIPTION</Text><TextInput multiline value={form.description} onChangeText={(value) => setField("description", value)} placeholder="What should people know?" placeholderTextColor={colors.mutedOnDark} style={[styles.reviewInput, { color: colors.foreground, backgroundColor: colors.backgroundSoft, borderColor: colors.border }]} /></View>}<PrimaryButton colors={colors} icon="zap" disabled={!valid || isBusy} onPress={submit}>Publish party log</PrimaryButton></View> : null}</ScrollView></KeyboardAvoidingView>;
}

export default function Index() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { isSignedIn } = useAuth();
  const [screen, setScreen] = useState<Screen>("welcome");
  const [onboardingStep, setOnboardingStep] = useState(0);
  const [selectedEvent, setSelectedEvent] = useState<PublicEvent | null>(null);
  const [message, setMessage] = useState("");
  const [permission, requestPermission] = Location.useForegroundPermissions();
  const reviewMutation = useCreateReview();

  useEffect(() => {
    if (!message) return;
    const timer = setTimeout(() => setMessage(""), 2800);
    return () => clearTimeout(timer);
  }, [message]);

  const go = (next: Screen) => { tap(); setMessage(""); setScreen(next); };
  const openEvent = (event: PublicEvent) => { setSelectedEvent(event); go("detail"); };
  const restart = () => { setOnboardingStep(0); go("onboarding"); };
  const submitReview = (data: CreateReviewRequest) => {
    if (!selectedEvent) return;
    reviewMutation.mutate({ eventId: selectedEvent.id, data }, { onSuccess: () => { setMessage("Review posted — thanks for keeping it real."); setScreen("detail"); }, onError: () => setMessage("Check in first, then try publishing again.") });
  };
  const content = screen === "welcome" ? <Welcome colors={colors} insets={insets} go={go} />
    : screen === "onboarding" ? <Onboarding colors={colors} insets={insets} step={onboardingStep} setStep={setOnboardingStep} go={go} />
    : screen === "signin" ? <SignIn colors={colors} insets={insets} go={go} toast={setMessage} />
    : screen === "location" ? <LocationGate colors={colors} insets={insets} permission={permission} requestPermission={requestPermission} go={go} toast={setMessage} />
    : screen === "home" ? <Home colors={colors} insets={insets} openEvent={openEvent} suggest={() => go("suggest")} toast={setMessage} restart={restart} />
    : screen === "detail" && selectedEvent ? <Detail colors={colors} insets={insets} event={selectedEvent} go={go} toast={setMessage} />
    : screen === "checkin" && selectedEvent ? <CheckIn colors={colors} insets={insets} event={selectedEvent} go={go} toast={setMessage} />
    : screen === "review" && selectedEvent ? <ReviewScreen colors={colors} insets={insets} go={go} submit={submitReview} submitting={reviewMutation.isPending} />
    : screen === "suggest" ? <SuggestEvent colors={colors} insets={insets} go={go} toast={setMessage} />
    : <Welcome colors={colors} insets={insets} go={go} />;

  useEffect(() => {
    if (screen !== "welcome" && screen !== "onboarding" && screen !== "signin" && !isSignedIn) setScreen("signin");
  }, [isSignedIn, screen]);

  return <View style={{ flex: 1, backgroundColor: colors.background }}><StatusBar style="light" />{content}{message ? <View style={[styles.toast, { backgroundColor: colors.backgroundElevated, borderColor: colors.border, bottom: insets.bottom + 18 }]}><Text style={[styles.toastText, { color: colors.foreground }]}>{message}</Text><Pressable onPress={() => setMessage("")}><Feather name="x" size={15} color={colors.mutedForeground} /></Pressable></View> : null}</View>;
}

const styles = StyleSheet.create({
  screen: { flex: 1, paddingHorizontal: 24, justifyContent: "space-between", overflow: "hidden" },
  scrollScreen: { paddingHorizontal: 24, flexGrow: 1 },
  brand: { alignItems: "center", flexDirection: "row", gap: 8 },
  brandCompact: { alignSelf: "flex-start" },
  brandMark: { alignItems: "center", borderRadius: 11, height: 32, justifyContent: "center", width: 32 },
  markLine: { borderRadius: 4, height: 3, position: "absolute", transform: [{ rotate: "-42deg" }], width: 16 },
  markLineSecond: { transform: [{ rotate: "-42deg" }, { translateX: 4 }, { translateY: 4 }], width: 12 },
  brandText: { fontSize: 19, fontWeight: "800", letterSpacing: -0.8 },
  glow: { borderRadius: 200, height: 300, opacity: 0.18, position: "absolute", width: 300 },
  glowTop: { right: -130, top: -110 },
  glowBottom: { bottom: -130, left: -130 },
  welcomeCopy: { marginTop: 80 },
  kicker: { fontSize: 11, fontWeight: "600", letterSpacing: 1.3 },
  hero: { fontSize: 54, fontWeight: "900", letterSpacing: -3.8, lineHeight: 51, marginTop: 16 },
  bodyLarge: { fontSize: 16, lineHeight: 24, marginTop: 22, maxWidth: 310 },
  body: { fontSize: 15, lineHeight: 23, marginTop: 12 },
  stepDots: { alignItems: "center", flexDirection: "row", gap: 7, justifyContent: "center", marginBottom: 22 },
  stepDot: { borderRadius: 5, height: 6, width: 6 },
  stepDotActive: { borderRadius: 5, height: 6, width: 32 },
  stepDotActiveWide: { borderRadius: 5, height: 6, width: 36 },
  primaryButton: { borderRadius: 17, minHeight: 54, overflow: "hidden", width: "100%" },
  primaryGradient: { alignItems: "center", flexDirection: "row", gap: 9, justifyContent: "center", minHeight: 54, paddingHorizontal: 20 },
  primaryText: { fontSize: 15, fontWeight: "800" },
  pressed: { opacity: 0.78, transform: [{ scale: 0.985 }] },
  disabled: { opacity: 0.36 },
  textButton: { alignItems: "center", paddingVertical: 13 },
  textButtonLabel: { fontSize: 13, fontWeight: "600" },
  topBar: { alignItems: "center", flexDirection: "row", justifyContent: "space-between" },
  iconButton: { alignItems: "center", borderRadius: 22, borderWidth: 1, height: 42, justifyContent: "center", width: 42 },
  mono: { fontFamily: Platform.select({ ios: "Courier New", android: "monospace", default: "monospace" }), fontSize: 10, fontWeight: "700", letterSpacing: 1.1 },
  skip: { fontSize: 13, fontWeight: "700" },
  onboardingBody: { flex: 1, justifyContent: "space-between", paddingTop: 58 },
  onboardingIcon: { alignItems: "center", borderRadius: 25, borderWidth: 1, elevation: 8, height: 82, justifyContent: "center", marginBottom: 36, shadowOpacity: 0.25, shadowRadius: 24, width: 82 },
  onboardingTitle: { fontSize: 42, fontWeight: "900", letterSpacing: -2.7, lineHeight: 41, marginTop: 7, maxWidth: 340 },
  authIntro: { marginTop: 46 },
  authTitle: { fontSize: 37, fontWeight: "900", letterSpacing: -2.4, lineHeight: 37, marginTop: 32 },
  authMode: { backgroundColor: "transparent", borderRadius: 14, flexDirection: "row", gap: 6, marginTop: 24, padding: 4 },
  authModeItem: { borderRadius: 10, paddingHorizontal: 14, paddingVertical: 10 },
  authModeText: { fontSize: 13, fontWeight: "800" },
  form: { gap: 10, marginBottom: 22, marginTop: 26 },
  fieldLabel: { fontSize: 11, fontWeight: "700", letterSpacing: 1.3 },
  input: { borderRadius: 15, borderWidth: 1, fontSize: 15, height: 56, paddingHorizontal: 16 },
  errorText: { fontSize: 12, lineHeight: 18, marginTop: 4 },
  orRow: { alignItems: "center", flexDirection: "row", gap: 12, marginVertical: 22 },
  rule: { flex: 1, height: 1 },
  orText: { fontSize: 11 },
  googleButton: { alignItems: "center", borderRadius: 17, borderWidth: 1, flexDirection: "row", gap: 12, justifyContent: "center", minHeight: 54 },
  googleMark: { backgroundColor: "#ffffff", borderRadius: 20, color: "#17111f", fontSize: 14, fontWeight: "900", height: 24, lineHeight: 24, textAlign: "center", width: 24 },
  facebookMark: { backgroundColor: "#1877f2", borderRadius: 20, color: "#ffffff", fontSize: 18, fontWeight: "900", height: 24, lineHeight: 27, textAlign: "center", width: 24 },
  googleText: { fontSize: 14, fontWeight: "800" },
  privacyRow: { alignItems: "flex-start", flexDirection: "row", gap: 8, marginTop: 24 },
  privacy: { flex: 1, fontSize: 11, lineHeight: 18 },
  locationCenter: { alignItems: "center", flex: 1, justifyContent: "center", paddingBottom: 30 },
  locationOrb: { alignItems: "center", borderRadius: 80, borderWidth: 1, elevation: 8, height: 144, justifyContent: "center", marginBottom: 36, shadowOpacity: 0.35, shadowRadius: 38, width: 144 },
  checkinIcon: { alignItems: "center", borderRadius: 80, borderWidth: 1, elevation: 8, height: 144, justifyContent: "center", marginBottom: 36, shadowOpacity: 0.35, shadowRadius: 38, width: 144 },
  locationTitle: { fontSize: 42, fontWeight: "900", letterSpacing: -2.7, lineHeight: 41, marginTop: 12, textAlign: "center" },
  secondaryButton: { alignItems: "center", borderRadius: 17, borderWidth: 1, flexDirection: "row", gap: 9, justifyContent: "center", minHeight: 54 },
  secondaryText: { fontSize: 15, fontWeight: "800" },
  home: { flex: 1 },
  homeHeader: { alignItems: "flex-start", flexDirection: "row", justifyContent: "space-between", paddingHorizontal: 24 },
  locationLabel: { alignItems: "center", flexDirection: "row", gap: 5, marginTop: 8 },
  locationText: { fontSize: 11, fontWeight: "600" },
  menuWrap: { position: "relative", zIndex: 5 },
  menu: { borderRadius: 14, borderWidth: 1, gap: 2, padding: 6, position: "absolute", right: 0, top: 48, width: 190 },
  menuItem: { alignItems: "center", flexDirection: "row", gap: 9, paddingHorizontal: 10, paddingVertical: 11 },
  menuText: { fontSize: 12, fontWeight: "700" },
  homeIntro: { alignItems: "flex-end", flexDirection: "row", justifyContent: "space-between", paddingHorizontal: 24, paddingVertical: 28 },
  homeTitle: { fontSize: 31, fontWeight: "900", letterSpacing: -1.6, marginTop: 4 },
  filterRow: { gap: 8, paddingHorizontal: 24, paddingBottom: 16 },
  filter: { borderRadius: 18, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 9 },
  filterText: { fontSize: 12, fontWeight: "800" },
  segment: { borderRadius: 14, borderWidth: 1, flexDirection: "row", marginHorizontal: 24, marginBottom: 18, padding: 4 },
  segmentItem: { alignItems: "center", borderRadius: 10, flex: 1, flexDirection: "row", gap: 7, justifyContent: "center", paddingVertical: 9 },
  segmentText: { fontSize: 12, fontWeight: "800" },
  eventList: { gap: 10, paddingHorizontal: 24 },
  listHeading: { alignItems: "center", flexDirection: "row", justifyContent: "space-between", marginBottom: 2 },
  listCount: { fontSize: 12, fontWeight: "600" },
  nearest: { fontSize: 12, fontWeight: "800" },
  eventCard: { borderRadius: 18, borderWidth: 1, overflow: "hidden", position: "relative" },
  eventCardPress: { padding: 14 },
  eventTop: { flexDirection: "row", gap: 12 },
  eventMark: { alignItems: "center", borderRadius: 12, height: 60, justifyContent: "center", width: 60 },
  eventPosterThumb: { borderRadius: 12, height: 60, resizeMode: "cover", width: 60 },
  eventMarkText: { fontSize: 11, fontWeight: "900", letterSpacing: 1 },
  eventMain: { flex: 1, gap: 4 },
  eventNameRow: { alignItems: "center", flexDirection: "row", gap: 7 },
  eventName: { flex: 1, fontSize: 15, fontWeight: "900" },
  distance: { fontSize: 10, fontWeight: "700" },
  venue: { fontSize: 12 },
  eventMeta: { alignItems: "center", flexDirection: "row", gap: 13, marginTop: 3 },
  crowdRow: { alignItems: "center", flexDirection: "row", gap: 6 },
  crowdDot: { borderRadius: 6, height: 7, shadowOpacity: 0.8, shadowRadius: 6, width: 7 },
  crowdDotLarge: { height: 11, width: 11 },
  crowdLabel: { fontSize: 11, fontWeight: "800" },
  ratingRow: { alignItems: "center", flexDirection: "row", gap: 4 },
  ratingValue: { fontSize: 12, fontWeight: "900" },
  ratingCount: { fontSize: 11 },
  eventBottom: { alignItems: "flex-end", borderTopWidth: 1, borderTopColor: "rgba(255,255,255,0.06)", flexDirection: "row", justifyContent: "space-between", marginTop: 14, paddingTop: 12 },
  eventPrice: { fontSize: 17, fontWeight: "900", marginTop: 4 },
  vibeWrap: { alignItems: "flex-end", flexDirection: "row", flexWrap: "wrap", gap: 5, justifyContent: "flex-end", maxWidth: 180 },
  vibe: { borderRadius: 8, fontSize: 10, overflow: "hidden", paddingHorizontal: 7, paddingVertical: 5 },
  saveButton: { alignItems: "center", height: 42, justifyContent: "center", position: "absolute", right: 8, top: 8, width: 42 },
  suggestButton: { alignItems: "center", borderRadius: 15, borderWidth: 1, flexDirection: "row", gap: 8, justifyContent: "center", marginTop: 4, minHeight: 48 },
  suggestText: { fontSize: 13, fontWeight: "800" },
  centerState: { alignItems: "center", gap: 12, justifyContent: "center", minHeight: 220 },
  stateText: { fontSize: 13, textAlign: "center" },
  bottomNav: { borderTopWidth: 1, bottom: 0, flexDirection: "row", left: 0, paddingHorizontal: 22, paddingTop: 10, position: "absolute", right: 0 },
  navItem: { alignItems: "center", flex: 1, gap: 4 },
  navLabel: { fontSize: 10, fontWeight: "800" },
  map: { flex: 1, minHeight: 420, overflow: "hidden", position: "relative" },
  mapChip: { alignItems: "center", borderRadius: 15, borderWidth: 1, flexDirection: "row", gap: 7, left: 18, paddingHorizontal: 11, paddingVertical: 8, position: "absolute", top: 18 },
  mapChipText: { fontSize: 11, fontWeight: "700" },
  pinCircle: { alignItems: "center", borderRadius: 20, borderWidth: 1, height: 38, justifyContent: "center", width: 38 },
  pinDot: { borderRadius: 10, height: 15, shadowOpacity: 0.8, shadowRadius: 9, width: 15 },
  mapCallout: { borderRadius: 14, borderWidth: 1, gap: 5, overflow: "hidden", padding: 8, width: 190 },
  mapCalloutPoster: { borderRadius: 8, height: 76, resizeMode: "cover", width: "100%" },
  mapCalloutTitle: { fontSize: 13, fontWeight: "900" },
  mapCalloutMeta: { fontSize: 10, lineHeight: 15 },
  mapCalloutAction: { fontSize: 11, fontWeight: "900", marginTop: 2 },
  mapEmpty: { alignItems: "center", borderRadius: 15, borderWidth: 1, flexDirection: "row", gap: 8, left: 24, paddingHorizontal: 12, paddingVertical: 10, position: "absolute", right: 24, top: "48%" },
  mapEmptyText: { flex: 1, fontSize: 12, fontWeight: "700" },
  detail: { flex: 1 },
  detailHero: { minHeight: 230, overflow: "hidden", paddingHorizontal: 24, paddingBottom: 24, position: "relative" },
  detailPoster: { height: "100%", left: 0, opacity: 0.32, position: "absolute", resizeMode: "cover", top: 0, width: "100%" },
  detailTop: { flexDirection: "row", justifyContent: "space-between", marginBottom: 54 },
  detailActions: { flexDirection: "row", gap: 8 },
  detailTitle: { fontSize: 39, fontWeight: "900", letterSpacing: -2.4, lineHeight: 39, marginTop: 8 },
  detailContent: { gap: 16, padding: 24 },
  detailVenue: { alignItems: "center", flexDirection: "row", justifyContent: "space-between" },
  detailVenueName: { fontSize: 17, fontWeight: "900" },
  address: { alignItems: "center", flexDirection: "row", gap: 6, marginTop: 5 },
  addressText: { fontSize: 12 },
  distancePill: { borderRadius: 10, fontSize: 10, fontWeight: "800", overflow: "hidden", paddingHorizontal: 9, paddingVertical: 7 },
  priceCard: { borderRadius: 18, borderWidth: 1, flexDirection: "row", justifyContent: "space-between", padding: 17 },
  detailPrice: { fontSize: 26, fontWeight: "900", marginTop: 4 },
  included: { alignItems: "center", flexDirection: "row", gap: 5, marginTop: 7 },
  includedText: { fontSize: 11 },
  dateBlock: { borderLeftWidth: 1, justifyContent: "center", paddingLeft: 14, width: "42%" },
  date: { fontSize: 11, fontWeight: "700" },
  time: { fontSize: 11, fontWeight: "800", lineHeight: 18, marginTop: 4 },
  breakdown: { borderRadius: 16, borderWidth: 1, padding: 15 },
  breakdownHeading: { flexDirection: "row", justifyContent: "space-between" },
  breakdownTitle: { fontSize: 13, fontWeight: "900" },
  breakdownRows: { gap: 11, marginTop: 14 },
  breakdownRow: { flexDirection: "row", justifyContent: "space-between" },
  breakdownLabel: { fontSize: 12 },
  totalRow: { borderTopWidth: 1, paddingTop: 11 },
  directionsButton: { alignItems: "center", borderRadius: 14, borderWidth: 1, flexDirection: "row", gap: 8, justifyContent: "center", minHeight: 48 },
  directionsText: { fontSize: 13, fontWeight: "900", flex: 1 },
  crowdCard: { alignItems: "center", borderRadius: 17, borderWidth: 1, flexDirection: "row", gap: 13, padding: 14 },
  crowdOrb: { alignItems: "center", borderRadius: 28, borderWidth: 1, height: 54, justifyContent: "center", shadowOpacity: 0.4, shadowRadius: 15, width: 54 },
  crowdOrbDot: { borderRadius: 12, height: 18, shadowOpacity: 0.8, shadowRadius: 10, width: 18 },
  liveRow: { alignItems: "center", flexDirection: "row", gap: 7 },
  crowdTitle: { fontSize: 14, fontWeight: "900" },
  livePill: { borderRadius: 5, fontSize: 9, fontWeight: "900", overflow: "hidden", paddingHorizontal: 5, paddingVertical: 3 },
  crowdPhrase: { fontSize: 11, marginTop: 4 },
  ratingDetail: { alignItems: "center", flexDirection: "row", gap: 14 },
  verified: { alignItems: "center", flexDirection: "row", gap: 5 },
  verifiedText: { fontSize: 11, fontWeight: "800" },
  detailDescription: { fontSize: 14, lineHeight: 22 },
  detailVibe: { borderRadius: 9, borderWidth: 1, fontSize: 11, overflow: "hidden", paddingHorizontal: 8, paddingVertical: 6 },
  reviewHeading: { alignItems: "center", flexDirection: "row", justifyContent: "space-between", marginTop: 5 },
  reviewTitle: { fontSize: 17, fontWeight: "900" },
  small: { fontSize: 11, lineHeight: 17 },
  reviewCard: { borderRadius: 15, borderWidth: 1, gap: 8, padding: 13 },
  reviewCardTop: { flexDirection: "row", justifyContent: "space-between" },
  reviewAuthor: { fontSize: 12, fontWeight: "900" },
  reviewTime: { fontSize: 10 },
  stars: { flexDirection: "row", gap: 2 },
  reviewCopy: { fontSize: 12, lineHeight: 18 },
  detailCtas: { gap: 9, marginTop: 3 },
  reviewButton: { alignItems: "center", borderRadius: 17, borderWidth: 1, flexDirection: "row", gap: 8, justifyContent: "center", minHeight: 54 },
  reviewButtonText: { fontSize: 14, fontWeight: "800" },
  reviewIntro: { marginBottom: 30, marginTop: 28 },
  formSectionLabel: { fontSize: 13, fontWeight: "900", marginBottom: 10, marginTop: 12 },
  starPicker: { flexDirection: "row", gap: 12, marginBottom: 8 },
  reviewInput: { borderRadius: 15, borderWidth: 1, fontSize: 14, minHeight: 120, padding: 15, textAlignVertical: "top" },
  counter: { fontSize: 10, marginTop: -4, textAlign: "right" },
  tagPicker: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 24 },
  tag: { borderRadius: 10, borderWidth: 1, paddingHorizontal: 10, paddingVertical: 8 },
  tagText: { fontSize: 11, fontWeight: "800" },
  toast: { alignItems: "center", borderRadius: 13, borderWidth: 1, bottom: 20, flexDirection: "row", gap: 12, left: 20, maxWidth: "90%", paddingHorizontal: 14, paddingVertical: 12, position: "absolute", right: 20 },
  toastText: { flex: 1, fontSize: 12, fontWeight: "700", lineHeight: 17 },
  posterPicker: { alignItems: "center", borderRadius: 18, borderWidth: 1, justifyContent: "center", marginTop: 8, minHeight: 180, overflow: "hidden", padding: 18 },
  posterPreview: { height: 220, resizeMode: "cover", width: "100%" },
  posterPickerTitle: { fontSize: 14, fontWeight: "900", marginTop: 12 },
  posterPickerMeta: { fontSize: 11, marginTop: 6 },
  posterStatus: { alignItems: "center", flexDirection: "row", gap: 9, justifyContent: "center", marginTop: 14 },
  posterForm: { borderTopWidth: 1, gap: 4, marginTop: 18, paddingTop: 10 },
  posterField: { gap: 7, marginTop: 8 },
});