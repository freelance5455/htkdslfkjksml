export type BusinessIconKey =
  | "farming"
  | "timber"
  | "motorcycle"
  | "airtel-money"
  | "tnm-mpamba"
  | "custom";

export type BusinessDetails = { name: string; category: string; icon: BusinessIconKey };

const iconKeysByType: Record<string, BusinessIconKey> = {
  farming: "farming",
  farm: "farming",
  "farming business": "farming",
  timber: "timber",
  "timber business": "timber",
  motorcycle: "motorcycle",
  motorbike: "motorcycle",
  "motorcycle business": "motorcycle",
  "airtel money": "airtel-money",
  airtel: "airtel-money",
  "tnm mpamba": "tnm-mpamba",
  mpamba: "tnm-mpamba",
  custom: "custom",
};

export function businessIconKeyForType(businessType: string): BusinessIconKey {
  const normalizedType = businessType.trim().toLowerCase().replace(/[_-]+/g, " ").replace(/\s+/g, " ");
  return iconKeysByType[normalizedType] ?? "custom";
}

export function businessDetailsForType(name: string, businessType: string): BusinessDetails {
  const category = businessType.trim() || "Custom";
  return { name: name.trim(), category, icon: businessIconKeyForType(category) };
}
