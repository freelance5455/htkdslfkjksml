import type { SyncChange } from '@workspace/api-client-react';

const DB_NAME = 'smartbiz-local-v1';
const entities = ['business', 'transaction', 'debt', 'debtPayment', 'product', 'stockMovement'] as const;
type EntityName = typeof entities[number];
type Stored = { key: string; userId: string; entity: EntityName; businessId?: string; recordId: string; value: unknown; deleted?: boolean };
type Pending = { key: string; userId: string; change: SyncChange };
export type UserBackup = {
  format: 'smartbiz-pro-backup';
  version: 1;
  ownerId: string;
  createdAt: string;
  records: Omit<Stored, 'key' | 'userId'>[];
  outbox: SyncChange[];
  cursor?: string;
};

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      db.createObjectStore('records', { keyPath: 'key' });
      db.createObjectStore('outbox', { keyPath: 'key' });
      db.createObjectStore('meta', { keyPath: 'key' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function localRecords<T>(userId: string, entity: string, businessId?: string): Promise<T[]> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const request = db.transaction('records').objectStore('records').getAll();
    request.onsuccess = () => resolve((request.result as Stored[])
      .filter((r) => r.userId === userId && r.entity === entity && (!businessId || r.businessId === businessId) && !r.deleted)
      .map((r) => r.value as T));
    request.onerror = () => reject(request.error);
  });
}

export async function localTombstones(userId: string, entity: EntityName): Promise<string[]> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const request = db.transaction('records').objectStore('records').getAll();
    request.onsuccess = () => resolve((request.result as Stored[])
      .filter((record) => record.userId === userId && record.entity === entity && record.deleted)
      .map((record) => record.recordId));
    request.onerror = () => reject(request.error);
  });
}

export async function storeRecord(userId: string, entity: string, id: string, value: unknown, businessId?: string, deleted = false) {
  const db = await openDb();
  const tx = db.transaction('records', 'readwrite');
  const store = tx.objectStore('records');
  const key = `${userId}:${entity}:${id}`;
  await new Promise<void>((resolve, reject) => {
    const request = store.get(key);
    request.onsuccess = () => {
      const previous = request.result as Stored | undefined;
      store.put({
        key, userId, entity: entity as EntityName, recordId: id,
        businessId: businessId ?? previous?.businessId, value, deleted,
      } satisfies Stored);
    };
    request.onerror = () => reject(request.error);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

export async function addPending(userId: string, change: SyncChange) {
  const db = await openDb();
  const tx = db.transaction('outbox', 'readwrite');
  tx.objectStore('outbox').put({ key: `${userId}:${change.entity}:${change.id}`, userId, change } satisfies Pending);
  await new Promise<void>((resolve, reject) => { tx.oncomplete = () => resolve(); tx.onerror = () => reject(tx.error); });
}

export async function pendingChanges(userId: string): Promise<SyncChange[]> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const req = db.transaction('outbox').objectStore('outbox').getAll();
    req.onsuccess = () => {
      const entityOrder: Record<string, number> = { business: 0, transaction: 1, debt: 2, product: 3, debtPayment: 4, stockMovement: 5 };
      const changes = (req.result as Pending[]).filter((p) => p.userId === userId).map((p) => p.change);
      changes.sort((a, b) => a.updatedAt.localeCompare(b.updatedAt) || (entityOrder[a.entity] ?? 9) - (entityOrder[b.entity] ?? 9) || a.id.localeCompare(b.id));
      resolve(changes);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function acknowledge(userId: string, accepted: string[]) {
  const db = await openDb();
  const tx = db.transaction('outbox', 'readwrite');
  const store = tx.objectStore('outbox');
  const acceptedCounts = new Map<string, number>();
  accepted.forEach((id) => acceptedCounts.set(id, (acceptedCounts.get(id) ?? 0) + 1));
  await new Promise<void>((resolve, reject) => {
    const request = store.getAll();
    request.onsuccess = () => {
      for (const item of request.result as Pending[]) {
        if (item.userId !== userId) continue;
        const count = acceptedCounts.get(item.change.id) ?? 0;
        if (!count) continue;
        store.delete(item.key);
        acceptedCounts.set(item.change.id, count - 1);
      }
    };
    request.onerror = () => reject(request.error);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

export async function applyRemoteDeletes(userId: string, deleted: SyncChange[]) {
  const db = await openDb();
  const tx = db.transaction('records', 'readwrite');
  const store = tx.objectStore('records');
  for (const change of deleted.filter((item) => item.operation === 'delete' && entities.includes(item.entity as EntityName))) {
    const key = `${userId}:${change.entity}:${change.id}`;
    const request = store.get(key);
    request.onsuccess = () => {
      const previous = request.result as Stored | undefined;
      const suppliedBusinessId = typeof change.data.businessId === 'string' ? change.data.businessId : undefined;
      store.put({
        key, userId, entity: change.entity as EntityName, recordId: change.id,
        businessId: suppliedBusinessId ?? previous?.businessId, value: change.data, deleted: true,
      } satisfies Stored);
    };
  }
  await new Promise<void>((resolve, reject) => { tx.oncomplete = () => resolve(); tx.onerror = () => reject(tx.error); tx.onabort = () => reject(tx.error); });
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function finite(value: unknown): value is number { return typeof value === 'number' && Number.isFinite(value); }
function isNullableString(value: unknown): boolean { return value === null || typeof value === 'string'; }
function validateEntityRecord(entity: string, record: unknown): record is Record<string, unknown> {
  if (!isObject(record) || typeof record.id !== 'string' || !record.id) return false;
  const s = (key: string) => typeof record[key] === 'string';
  const n = (key: string) => finite(record[key]);
  if (entity === 'business') return s('name') && s('category') && s('icon') && s('createdAt') && s('updatedAt');
  if (entity === 'transaction') return s('businessId') && ['income', 'expense'].includes(String(record.type)) && n('amount') && s('date') && s('description') && s('category') && s('paymentMethod') && s('createdAt') && s('updatedAt');
  if (entity === 'debt') return s('businessId') && ['customer_owes', 'supplier_owed'].includes(String(record.direction)) && s('counterpartyName') && n('originalAmount') && n('amountPaid') && n('remainingBalance') && isNullableString(record.dueDate) && isNullableString(record.notes) && s('createdAt') && s('updatedAt');
  if (entity === 'debtPayment') return s('debtId') && n('amount') && s('date') && isNullableString(record.notes) && s('createdAt');
  if (entity === 'product') return s('businessId') && s('name') && n('quantity') && n('purchasePrice') && n('sellingPrice') && s('createdAt') && s('updatedAt');
  if (entity === 'stockMovement') return s('productId') && ['stock_in', 'stock_out', 'adjustment'].includes(String(record.type)) && n('quantity') && s('date') && isNullableString(record.note) && s('createdAt');
  return false;
}

export async function createUserBackup(userId: string): Promise<UserBackup> {
  const db = await openDb();
  const [records, outbox, cursor] = await Promise.all([
    new Promise<Stored[]>((resolve, reject) => {
      const request = db.transaction('records').objectStore('records').getAll();
      request.onsuccess = () => resolve((request.result as Stored[]).filter((record) => record.userId === userId));
      request.onerror = () => reject(request.error);
    }),
    pendingChanges(userId),
    getCursor(userId),
  ]);
  return {
    format: 'smartbiz-pro-backup', version: 1, ownerId: userId, createdAt: new Date().toISOString(),
    records: records.map(({ entity, recordId, businessId, value, deleted }) => ({ entity, recordId, businessId, value, deleted })),
    outbox, cursor,
  };
}

export async function restoreUserBackup(userId: string, input: unknown): Promise<{ records: number; pending: number }> {
  if (!isObject(input) || input.format !== 'smartbiz-pro-backup' || input.version !== 1 || input.ownerId !== userId ||
    !Array.isArray(input.records) || !Array.isArray(input.outbox) ||
    (input.cursor !== undefined && typeof input.cursor !== 'string')) {
    throw new Error('This is not a valid SMARTBIZ PRO backup for the signed-in account.');
  }
  const records: Omit<Stored, 'key' | 'userId'>[] = [];
  for (const candidate of input.records) {
    if (!isObject(candidate) || typeof candidate.entity !== 'string' || !entities.includes(candidate.entity as EntityName) ||
      typeof candidate.recordId !== 'string' || !candidate.recordId ||
      (candidate.businessId !== undefined && typeof candidate.businessId !== 'string') ||
      (candidate.deleted !== undefined && typeof candidate.deleted !== 'boolean') ||
      (!candidate.deleted && !validateEntityRecord(candidate.entity, candidate.value)) ||
      (isObject(candidate.value) && candidate.value.id !== undefined && candidate.value.id !== candidate.recordId)) {
      throw new Error('The backup contains a malformed business record.');
    }
    records.push(candidate as unknown as Omit<Stored, 'key' | 'userId'>);
  }
  const outbox: SyncChange[] = [];
  for (const change of input.outbox) {
    if (!isObject(change) || typeof change.entity !== 'string' || !entities.includes(change.entity as EntityName) ||
      typeof change.id !== 'string' || !change.id || !['upsert', 'delete'].includes(String(change.operation)) ||
      !isObject(change.data) || typeof change.updatedAt !== 'string' || Number.isNaN(Date.parse(change.updatedAt)) ||
      (change.operation === 'upsert' && !validateEntityRecord(change.entity, change.data))) {
      throw new Error('The backup contains a malformed pending sync change.');
    }
    outbox.push(change as unknown as SyncChange);
  }
  const db = await openDb();
  const tx = db.transaction(['records', 'outbox', 'meta'], 'readwrite');
  for (const record of records) {
    tx.objectStore('records').put({ ...record, userId, key: `${userId}:${record.entity}:${record.recordId}` } satisfies Stored);
  }
  for (const change of outbox) {
    tx.objectStore('outbox').put({ key: `${userId}:${change.entity}:${change.id}`, userId, change } satisfies Pending);
  }
  if (typeof input.cursor === 'string') tx.objectStore('meta').put({ key: `${userId}:cursor`, value: input.cursor });
  await new Promise<void>((resolve, reject) => { tx.oncomplete = () => resolve(); tx.onerror = () => reject(tx.error); tx.onabort = () => reject(tx.error); });
  return { records: records.length, pending: outbox.length };
}

export async function getCursor(userId: string): Promise<string | undefined> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const req = db.transaction('meta').objectStore('meta').get(`${userId}:cursor`);
    req.onsuccess = () => resolve(req.result?.value as string | undefined);
    req.onerror = () => reject(req.error);
  });
}
export async function setCursor(userId: string, value: string) {
  const db = await openDb();
  const tx = db.transaction('meta', 'readwrite');
  tx.objectStore('meta').put({ key: `${userId}:cursor`, value });
  await new Promise<void>((resolve, reject) => { tx.oncomplete = () => resolve(); tx.onerror = () => reject(tx.error); });
}
