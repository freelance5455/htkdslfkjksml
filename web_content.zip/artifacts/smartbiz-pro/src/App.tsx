import { useEffect, useRef, useState, type ChangeEvent, type FormEvent, type ReactNode } from 'react';
import { ClerkProvider, SignIn, SignUp, useAuth, useClerk, useUser } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { Link, Redirect, Route, Router as WouterRouter, Switch, useLocation, useParams } from 'wouter';
import {
  Activity, ArrowDownLeft, ArrowRight, ArrowUpRight, BarChart3, Bike, Boxes, BriefcaseBusiness,
  Check, CircleDollarSign, Cloud, CloudOff, CreditCard, Download, FileText, Filter, Leaf, LogOut, Menu,
  Plus, RefreshCw, Search, Settings2, ShieldCheck, Smartphone, Sprout, Store, Trash2, TrendingDown,
  TrendingUp, Truck, Upload, Wallet, X,
} from 'lucide-react';
import {
  getGetBusinessReportQueryKey, getListBusinessesQueryKey, getListDebtsQueryKey, getListDebtPaymentsQueryKey,
  getListProductsQueryKey, getListStockMovementsQueryKey, getListTransactionsQueryKey, getPullSyncChangesQueryKey,
  useCreateBusiness, useCreateDebt, useCreateProduct, useCreateStockMovement, useCreateTransaction, useDeleteBusiness,
  useDeleteDebt, useDeleteProduct, useDeleteTransaction, useGetBusinessReport, useListBusinesses, useListDebts,
  useListDebtPayments, useListProducts, useListStockMovements, useListTransactions, usePullSyncChanges,
  usePushSyncChanges, useRecordDebtPayment, useUpdateBusiness, useUpdateDebt, useUpdateProduct, useUpdateTransaction,
  type Business, type BusinessReport, type Debt, type DebtPayment, type Product, type StockMovement, type Transaction, type SyncChange,
} from '@workspace/api-client-react';
import {
  acknowledge, addPending, applyRemoteDeletes, createUserBackup, getCursor, localRecords, localTombstones,
  pendingChanges, restoreUserBackup, setCursor, storeRecord,
} from '@/lib/offline';
import { businessDetailsForType, businessIconKeyForType } from '@/lib/business-icons';
import NotFound from '@/pages/not-found';
import './index.css';

const queryClient = new QueryClient({ defaultOptions: { queries: { retry: 1, refetchOnWindowFocus: false } } });
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
function stripBase(path: string) { return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path; }
if (!clerkPubKey) throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');

const appearance = {
  theme: shadcn, cssLayerName: 'clerk',
  options: { logoPlacement: 'inside' as const, logoLinkUrl: basePath || '/', logoImageUrl: `${window.location.origin}${basePath}/logo.svg` },
  variables: { colorPrimary: '#245b45', colorForeground: '#20372e', colorMutedForeground: '#64786d', colorDanger: '#aa443d', colorBackground: '#fffdf6', colorInput: '#f8f5ea', colorInputForeground: '#20372e', colorNeutral: '#d9d5c8', fontFamily: 'Manrope, sans-serif', borderRadius: '0.75rem' },
  elements: {
    rootBox: 'w-full flex justify-center', cardBox: 'bg-[#fffdf6] rounded-2xl w-[440px] max-w-full overflow-hidden shadow-xl',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none', footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#20372e] font-bold', headerSubtitle: 'text-[#64786d]', socialButtonsBlockButtonText: 'text-[#20372e] font-semibold',
    formFieldLabel: 'text-[#344c40] font-semibold', footerActionLink: 'text-[#245b45] font-semibold', footerActionText: 'text-[#64786d]',
    dividerText: 'text-[#64786d]', identityPreviewEditButton: 'text-[#245b45]', formFieldSuccessText: 'text-[#245b45]',
    alertText: 'text-[#20372e]', logoBox: 'mb-2', logoImage: 'h-9', socialButtonsBlockButton: 'border-[#ded9ca] bg-[#fbf8ef]',
    formButtonPrimary: 'bg-[#245b45] hover:bg-[#194633] text-white', formFieldInput: 'bg-[#f8f5ea] border-[#ded9ca] text-[#20372e]',
    footerAction: 'text-[#64786d]', dividerLine: 'bg-[#ded9ca]', alert: 'border-[#ead8bd]', otpCodeFieldInput: 'bg-[#f8f5ea]',
    formFieldRow: 'mb-4', main: 'gap-4',
  },
};
const money = (amount = 0) => `MWK ${new Intl.NumberFormat('en-MW', { maximumFractionDigits: 0 }).format(amount)}`;
const dateToday = () => new Date().toISOString().slice(0, 10);
const monthStart = () => new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().slice(0, 10);
const uid = () => crypto.randomUUID();
function mergeRecords<T extends { id: string; updatedAt?: string }>(remote: T[] | undefined, local: T[]): T[] {
  const records = new Map<string, T>();
  for (const item of remote ?? []) records.set(item.id, item);
  for (const item of local) {
    const current = records.get(item.id);
    if (!current || (item.updatedAt ?? '') >= (current.updatedAt ?? '')) records.set(item.id, item);
  }
  return [...records.values()];
}
function withoutDeleted<T extends { id: string }>(records: T[], deleted: string[] | undefined): T[] {
  if (!deleted?.length) return records;
  const ids = new Set(deleted);
  return records.filter((record) => !ids.has(record.id));
}
const businessIcons = {
  farming: Sprout,
  timber: Boxes,
  motorcycle: Bike,
  'airtel-money': Smartphone,
  'tnm-mpamba': Wallet,
  custom: Store,
};
function BusinessTypeIcon({ category, size = 19 }: { category: string; size?: number }) {
  const Icon = businessIcons[businessIconKeyForType(category)];
  return <Icon size={size} aria-hidden="true" />;
}
const categories = ['Farming', 'Timber Business', 'Motorcycle Business', 'Airtel Money', 'TNM Mpamba', 'Custom'];
type Entity = 'business' | 'transaction' | 'debt' | 'product' | 'payment' | 'movement';
type ModalState = { entity: Entity; value?: Record<string, unknown>; intent?: 'edit' | 'payment' | 'movement' } | null;
type Tab = 'overview' | 'transactions' | 'debts' | 'inventory' | 'reports';
type Fields = { [key: string]: string };
const inputClass = 'w-full rounded-xl border border-[#dedbcc] bg-[#fffdf7] px-3.5 py-3 text-sm text-[#20372e] outline-none transition focus:border-[#4d8669] focus:ring-2 focus:ring-[#4d8669]/15';

function Button({ children, onClick, variant = 'solid', className = '', type = 'button', disabled = false }: { children: ReactNode; onClick?: () => void; variant?: 'solid' | 'soft' | 'ghost' | 'danger'; className?: string; type?: 'button' | 'submit'; disabled?: boolean }) {
  const colors = variant === 'solid' ? 'bg-[#245b45] text-white hover:bg-[#194633]' : variant === 'soft' ? 'bg-[#e9eee6] text-[#245b45] hover:bg-[#dfe8dd]' : variant === 'danger' ? 'text-[#aa443d] hover:bg-[#f8e9e6]' : 'text-[#52675b] hover:bg-[#f0eee6]';
  return <button type={type} onClick={onClick} disabled={disabled} className={`inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold disabled:cursor-not-allowed disabled:opacity-50 ${colors} ${className}`}>{children}</button>;
}

function Brand({ light = false }: { light?: boolean }) {
  return <div className={`flex items-center gap-3 ${light ? 'text-[#f6f2e7]' : 'text-[#20372e]'}`}>
    <span className={`grid h-10 w-10 place-items-center rounded-[14px] ${light ? 'bg-[#d9a84e] text-[#20372e]' : 'bg-[#245b45] text-[#f6f2e7]'}`}><Activity size={21} strokeWidth={2.5} /></span>
    <span className="text-[14px] font-extrabold tracking-[.11em]">SMARTBIZ <span className={light ? 'text-[#d9a84e]' : 'text-[#a87929]'}>PRO</span><small className={`mt-0.5 block text-[9px] font-semibold tracking-[.19em] ${light ? 'text-[#bfc9bd]' : 'text-[#829187]'}`}>BUSINESS, IN GOOD ORDER</small></span>
  </div>;
}

function StatusPill({ online, pending = 0 }: { online: boolean; pending?: number }) {
  return <div data-testid="status-connectivity" className={`inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-[11px] font-bold ${online ? 'bg-[#e6efe5] text-[#326449]' : 'bg-[#f7e8dc] text-[#965a2a]'}`}>
    {online ? <Cloud size={14} /> : <CloudOff size={14} />}{online ? (pending ? `${pending} awaiting sync` : 'Connected') : 'Offline · saved on this device'}
  </div>;
}

function AppShell({ routeBusinessId = '' }: { routeBusinessId?: string }) {
  const { user, isLoaded } = useUser();
  const { signOut } = useClerk();
  const { isSignedIn } = useAuth();
  const [, setLocation] = useLocation();
  const client = useQueryClient();
  const userId = user?.id ?? '';
  const [online, setOnline] = useState(navigator.onLine);
  const [outboxCount, setOutboxCount] = useState(0);
  const [syncCursor, setSyncCursor] = useState<string | undefined>();
  const [syncMessage, setSyncMessage] = useState('');
  const pushSync = usePushSyncChanges();
  const [activeTab, setActiveTab] = useState<Tab>('overview');
  const [selectedBusinessId, setSelectedBusinessId] = useState(routeBusinessId);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [modal, setModal] = useState<ModalState>(null);
  const [backupOpen, setBackupOpen] = useState(false);
  const [notice, setNotice] = useState('');
  const [transactionFilter, setTransactionFilter] = useState('all');
  const [dateFrom, setDateFrom] = useState(monthStart());
  const [dateTo, setDateTo] = useState(dateToday());
  const [search, setSearch] = useState('');
  const [localBusinesses, setLocalBusinesses] = useState<Business[]>([]);
  const [localTransactions, setLocalTransactions] = useState<Transaction[]>([]);
  const [localDebts, setLocalDebts] = useState<Debt[]>([]);
  const [localProducts, setLocalProducts] = useState<Product[]>([]);
  const [localPayments, setLocalPayments] = useState<DebtPayment[]>([]);
  const [localMovements, setLocalMovements] = useState<StockMovement[]>([]);
  const [deletedRecords, setDeletedRecords] = useState<Record<string, string[]>>({});
  const operationTokens = useRef(new Map<string, string>());

  const businessQuery = useListBusinesses({ query: { queryKey: getListBusinessesQueryKey(), enabled: !!userId } });
  const businesses = mergeRecords(withoutDeleted(businessQuery.data ?? [], deletedRecords.business), localBusinesses);
  const activeBusiness = businesses.find((b) => b.id === selectedBusinessId) ?? businesses[0];
  const businessId = activeBusiness?.id ?? '';
  const txParams = { businessId, from: dateFrom, to: dateTo };
  const transactionQuery = useListTransactions(txParams, { query: { queryKey: getListTransactionsQueryKey(txParams), enabled: !!userId && !!businessId } });
  const debtQuery = useListDebts({ businessId }, { query: { queryKey: getListDebtsQueryKey({ businessId }), enabled: !!userId && !!businessId } });
  const productQuery = useListProducts({ businessId }, { query: { queryKey: getListProductsQueryKey({ businessId }), enabled: !!userId && !!businessId } });
  const reportParams = { businessId, from: dateFrom, to: dateTo };
  const reportQuery = useGetBusinessReport(reportParams, { query: { queryKey: getGetBusinessReportQueryKey(reportParams), enabled: !!userId && !!businessId && activeTab === 'reports' } });
  const selectedDebtId = (modal?.entity === 'payment' ? String(modal.value?.id ?? '') : debtQuery.data?.find((debt) => !deletedRecords.debt?.includes(debt.id))?.id ?? localDebts[0]?.id) || '';
  const paymentQuery = useListDebtPayments(selectedDebtId, { query: { queryKey: getListDebtPaymentsQueryKey(selectedDebtId), enabled: !!userId && !!selectedDebtId && activeTab === 'debts' } });
  const selectedProductId = productQuery.data?.find((product) => !deletedRecords.product?.includes(product.id))?.id ?? localProducts[0]?.id ?? '';
  const movementQuery = useListStockMovements(selectedProductId, { query: { queryKey: getListStockMovementsQueryKey(selectedProductId), enabled: !!userId && !!selectedProductId && activeTab === 'inventory' } });
  const pullParams = { since: syncCursor };
  const pullQuery = usePullSyncChanges(pullParams, { query: { queryKey: getPullSyncChangesQueryKey(pullParams), enabled: false } });

  const createBusiness = useCreateBusiness(); const updateBusiness = useUpdateBusiness(); const deleteBusiness = useDeleteBusiness();
  const createTransaction = useCreateTransaction(); const updateTransaction = useUpdateTransaction(); const deleteTransaction = useDeleteTransaction();
  const createDebt = useCreateDebt(); const updateDebt = useUpdateDebt(); const deleteDebt = useDeleteDebt(); const recordPayment = useRecordDebtPayment();
  const createProduct = useCreateProduct(); const updateProduct = useUpdateProduct(); const deleteProduct = useDeleteProduct();
  const createMovement = useCreateStockMovement();

  const transactions = mergeRecords(withoutDeleted(transactionQuery.data ?? [], deletedRecords.transaction), localTransactions.filter((t) => t.businessId === businessId && (!dateFrom || t.date >= dateFrom) && (!dateTo || t.date <= dateTo)));
  const debts = mergeRecords(withoutDeleted(debtQuery.data ?? [], deletedRecords.debt), localDebts.filter((d) => d.businessId === businessId));
  const products = mergeRecords(withoutDeleted(productQuery.data ?? [], deletedRecords.product), localProducts.filter((p) => p.businessId === businessId));
  const payments = mergeRecords(withoutDeleted(paymentQuery.data ?? [], deletedRecords.debtPayment), localPayments);
  const selectedProductIds = new Set(products.map((product) => product.id));
  const movements = mergeRecords(withoutDeleted(movementQuery.data ?? [], deletedRecords.stockMovement), localMovements.filter((movement) => selectedProductIds.has(movement.productId)));
  const [cached, setCached] = useState(false);
  const refreshOutbox = async () => { if (userId) setOutboxCount((await pendingChanges(userId)).length); };
  const refreshLocal = async () => {
    if (!userId) return;
    const [bs, tx, ds, ps, payments, movements, deleted] = await Promise.all([
      localRecords<Business>(userId, 'business'), localRecords<Transaction>(userId, 'transaction'),
      localRecords<Debt>(userId, 'debt'), localRecords<Product>(userId, 'product'),
      localRecords<DebtPayment>(userId, 'debtPayment'), localRecords<StockMovement>(userId, 'stockMovement'),
      Promise.all(['business', 'transaction', 'debt', 'debtPayment', 'product', 'stockMovement'].map(async (entity) => [entity, await localTombstones(userId, entity as 'business' | 'transaction' | 'debt' | 'debtPayment' | 'product' | 'stockMovement')] as const)),
    ]);
    setLocalBusinesses(bs); setLocalTransactions(tx); setLocalDebts(ds); setLocalProducts(ps);
    setLocalPayments(payments); setLocalMovements(movements); setDeletedRecords(Object.fromEntries(deleted)); setCached(true);
  };
  useEffect(() => { const on = () => setOnline(navigator.onLine); window.addEventListener('online', on); window.addEventListener('offline', on); return () => { window.removeEventListener('online', on); window.removeEventListener('offline', on); }; }, []);
  useEffect(() => {
    if (!userId) { setLocalBusinesses([]); setLocalTransactions([]); setLocalDebts([]); setLocalProducts([]); setLocalPayments([]); setLocalMovements([]); setDeletedRecords({}); setCached(false); return; }
    setCached(false);
    setSyncMessage('');
    void getCursor(userId).then((cursor) => setSyncCursor(cursor)).catch(() => undefined);
    refreshLocal().catch(() => setCached(true));
    refreshOutbox();
  }, [userId]);
  useEffect(() => { if (routeBusinessId) setSelectedBusinessId(routeBusinessId); }, [routeBusinessId]);
  useEffect(() => { if (!routeBusinessId && businesses.length && !businesses.some((b) => b.id === selectedBusinessId)) setSelectedBusinessId(businesses[0].id); }, [businesses, selectedBusinessId, routeBusinessId]);
  useEffect(() => {
    if (!userId || !businessQuery.data) return;
    businessQuery.data.forEach((item) => storeRecord(userId, 'business', item.id, item).catch(() => undefined));
  }, [userId, businessQuery.data]);
  useEffect(() => {
    if (!userId) return;
    transactionQuery.data?.forEach((r) => storeRecord(userId, 'transaction', r.id, r, r.businessId).catch(() => undefined));
    debtQuery.data?.forEach((r) => storeRecord(userId, 'debt', r.id, r, r.businessId).catch(() => undefined));
    productQuery.data?.forEach((r) => storeRecord(userId, 'product', r.id, r, r.businessId).catch(() => undefined));
  }, [userId, transactionQuery.data, debtQuery.data, productQuery.data]);
  useEffect(() => {
    if (!userId) return;
    const paymentRows = withoutDeleted(paymentQuery.data ?? [], deletedRecords.debtPayment);
    const movementRows = withoutDeleted(movementQuery.data ?? [], deletedRecords.stockMovement);
    paymentRows.forEach((record) => storeRecord(userId, 'debtPayment', record.id, record).catch(() => undefined));
    movementRows.forEach((record) => storeRecord(userId, 'stockMovement', record.id, record).catch(() => undefined));
    if (paymentRows.length) setLocalPayments((previous) => mergeRecords(paymentRows, previous));
    if (movementRows.length) setLocalMovements((previous) => mergeRecords(movementRows, previous));
  }, [userId, paymentQuery.data, movementQuery.data, deletedRecords.debtPayment, deletedRecords.stockMovement]);

  const syncNow = async () => {
    if (!userId || !online) return;
    setSyncMessage('Checking pending changes…');
    try {
      let confirmedCount = 0;
      let rejectedCount = 0;
      for (let batchNumber = 0; batchNumber < 100; batchNumber += 1) {
        const changes = await pendingChanges(userId);
        if (!changes.length) break;
        const batch = changes.slice(0, 100);
        const result = await pushSync.mutateAsync({ data: { changes: batch } });
        if (result.accepted.length) {
          confirmedCount += result.accepted.length;
          await acknowledge(userId, result.accepted);
        }
        rejectedCount += result.rejected.length;
        // A rejection may be a prerequisite business/product. Keep later changes queued
        // until the rejected change is resolved rather than sending broken dependants.
        if (result.rejected.length || result.accepted.length < batch.length) break;
      }
      const cursor = await getCursor(userId);
      if (cursor) setSyncCursor(cursor);
      const pulled = await pullQuery.refetch();
      if (pulled.data) {
        const data = pulled.data;
        const entities: [string, { id: string; businessId?: string }][] = [
          ...data.businesses.map((r) => ['business', r] as [string, { id: string; businessId?: string }]),
          ...data.transactions.map((r) => ['transaction', r] as [string, { id: string; businessId?: string }]),
          ...data.debts.map((r) => ['debt', r] as [string, { id: string; businessId?: string }]),
          ...data.debtPayments.map((r) => ['debtPayment', r] as [string, { id: string; businessId?: string }]),
          ...data.products.map((r) => ['product', r] as [string, { id: string; businessId?: string }]),
          ...data.stockMovements.map((r) => ['stockMovement', r] as [string, { id: string; businessId?: string }]),
        ];
        await Promise.all(entities.map(([entity, record]) => storeRecord(userId, entity, record.id, record, record.businessId)));
        await applyRemoteDeletes(userId, pulled.data.deleted ?? []);
        await setCursor(userId, data.cursor);
        setSyncCursor(data.cursor);
        invalidateBusinessData();
      }
      setOutboxCount((await pendingChanges(userId)).length);
      await refreshLocal();
      setSyncMessage(rejectedCount
        ? `${rejectedCount} change${rejectedCount === 1 ? '' : 's'} need attention`
        : confirmedCount
          ? `${confirmedCount} change${confirmedCount === 1 ? '' : 's'} confirmed by server`
          : 'No pending changes');
    } catch {
      setSyncMessage('Sync could not be confirmed. Your local changes remain saved.');
    }
  };
  useEffect(() => { if (online && userId) void syncNow(); }, [online, userId]);
  useEffect(() => { if (!notice) return; const timer = window.setTimeout(() => setNotice(''), 3500); return () => window.clearTimeout(timer); }, [notice]);

  const invalidateBusinessData = () => {
    client.invalidateQueries({ queryKey: getListBusinessesQueryKey() });
    if (businessId) {
      client.invalidateQueries({ queryKey: getListTransactionsQueryKey({ businessId }) });
      client.invalidateQueries({ queryKey: getListDebtsQueryKey({ businessId }) });
      client.invalidateQueries({ queryKey: getListProductsQueryKey({ businessId }) });
      client.invalidateQueries({ queryKey: getGetBusinessReportQueryKey({ businessId, from: dateFrom, to: dateTo }) });
    }
  };
  const dropCachedBusinessQueries = () => {
    client.removeQueries({ queryKey: getListBusinessesQueryKey() });
    client.removeQueries({ queryKey: getListTransactionsQueryKey() });
    client.removeQueries({ queryKey: getListDebtsQueryKey() });
    client.removeQueries({ queryKey: getListProductsQueryKey() });
    client.removeQueries({ queryKey: getGetBusinessReportQueryKey() });
  };
  const markLocal = async (entity: SyncChange['entity'], id: string, value: unknown, operation: SyncChange['operation'], recordBusinessId?: string) => {
    if (!userId) return;
    dropCachedBusinessQueries();
    await storeRecord(userId, entity, id, value, recordBusinessId, operation === 'delete');
    await addPending(userId, { entity, id, operation, data: value as Record<string, unknown>, updatedAt: new Date().toISOString() });
    await refreshLocal(); await refreshOutbox();
  };
  const stableOperationId = (key: string) => {
    const existing = operationTokens.current.get(key);
    if (existing) return existing;
    const created = uid();
    operationTokens.current.set(key, created);
    return created;
  };
  const persistOffline = async (entity: Entity, values: Fields, original: Record<string, unknown>, id: string, paymentKey: string, movementKey: string) => {
    if (entity === 'business') {
      const category = values.category === 'Custom' && values.customCategory?.trim() ? values.customCategory.trim() : values.category;
      const record = { id, ...businessDetailsForType(values.name, category), createdAt: String(original.createdAt ?? new Date().toISOString()), updatedAt: new Date().toISOString() };
      await markLocal('business', id, record, 'upsert');
    } else if (entity === 'transaction') {
      const record = { id, businessId, type: values.type as 'income' | 'expense', amount: Number(values.amount), date: values.date, description: values.description.trim(), category: values.category, paymentMethod: values.paymentMethod, createdAt: String(original.createdAt ?? new Date().toISOString()), updatedAt: new Date().toISOString() };
      await markLocal('transaction', id, record, 'upsert', businessId);
    } else if (entity === 'debt') {
      const amount = Number(values.originalAmount);
      const record = { id, businessId, direction: values.direction as 'customer_owes' | 'supplier_owed', counterpartyName: values.counterpartyName.trim(), originalAmount: amount, amountPaid: Number(original.amountPaid ?? 0), remainingBalance: Math.max(0, amount - Number(original.amountPaid ?? 0)), dueDate: values.dueDate || null, notes: values.notes || null, createdAt: String(original.createdAt ?? new Date().toISOString()), updatedAt: new Date().toISOString() };
      await markLocal('debt', id, record, 'upsert', businessId);
    } else if (entity === 'product') {
      const record = { id, businessId, name: values.name.trim(), quantity: Number(values.quantity), purchasePrice: Number(values.purchasePrice), sellingPrice: Number(values.sellingPrice), createdAt: String(original.createdAt ?? new Date().toISOString()), updatedAt: new Date().toISOString() };
      await markLocal('product', id, record, 'upsert', businessId);
    } else if (entity === 'payment') {
      const debtId = String(original.id ?? '');
      const debt = debts.find((item) => item.id === debtId);
      if (!debt) throw new Error('This balance is no longer available in this business book.');
      const amount = Number(values.amount);
      if (amount <= 0 || amount > debt.remainingBalance) throw new Error('Payment exceeds the remaining balance.');
      const payment = { id: paymentKey, debtId, amount, date: values.date, notes: values.notes || null, createdAt: new Date().toISOString() };
      dropCachedBusinessQueries();
      await storeRecord(userId, 'debtPayment', payment.id, payment);
      await addPending(userId, { entity: 'debtPayment', id: payment.id, operation: 'upsert', data: { ...payment, idempotencyKey: paymentKey }, updatedAt: payment.createdAt });
      await storeRecord(userId, 'debt', debtId, { ...debt, amountPaid: debt.amountPaid + amount, remainingBalance: debt.remainingBalance - amount }, businessId);
      await refreshLocal(); await refreshOutbox();
    } else if (entity === 'movement') {
      const productId = String(original.id ?? '');
      const product = products.find((item) => item.id === productId);
      if (!product) throw new Error('This product is no longer available in this business book.');
      const type = values.type as 'stock_in' | 'stock_out' | 'adjustment';
      const quantity = Number(values.quantity);
      if (quantity <= 0) throw new Error('Movement quantity must be greater than zero.');
      if (type === 'stock_out' && quantity > product.quantity) throw new Error('Stock out cannot exceed current on-hand quantity.');
      dropCachedBusinessQueries();
      const movement = { id: movementKey, productId, type, quantity, date: values.date, note: values.note || null, createdAt: new Date().toISOString() };
      await storeRecord(userId, 'stockMovement', movement.id, movement, businessId);
      await addPending(userId, { entity: 'stockMovement', id: movement.id, operation: 'upsert', data: { ...movement, idempotencyKey: movementKey }, updatedAt: movement.createdAt });
      const nextQuantity = type === 'stock_in' ? product.quantity + quantity : type === 'stock_out' ? product.quantity - quantity : quantity;
      await storeRecord(userId, 'product', productId, { ...product, quantity: nextQuantity, updatedAt: new Date().toISOString() }, businessId);
      await refreshLocal(); await refreshOutbox();
    }
  };

  const startCreate = (entity: Entity, value?: Record<string, unknown>) => { setModal({ entity, value, intent: value ? 'edit' : undefined }); };
  const saveRecord = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!modal) return;
    const values = Object.fromEntries(new FormData(event.currentTarget).entries()) as Fields;
    const original = modal.value ?? {};
    const editing = modal.intent === 'edit';
    const id = String(original.id ?? uid());
    const paymentKey = modal.entity === 'payment'
      ? stableOperationId(`payment:${String(original.id ?? '')}:${values.amount}:${values.date}:${values.notes ?? ''}`)
      : '';
    const movementKey = modal.entity === 'movement'
      ? stableOperationId(`movement:${String(original.id ?? '')}:${values.type}:${values.quantity}:${values.date}:${values.note ?? ''}`)
      : '';
    if (modal.entity === 'payment') {
      const debt = debts.find((item) => item.id === String(original.id ?? ''));
      const amount = Number(values.amount);
      if (!debt || amount <= 0 || amount > debt.remainingBalance) {
        setNotice(debt ? 'Payment must be greater than zero and no more than the remaining balance.' : 'This balance is no longer available.');
        return;
      }
    }
    if (modal.entity === 'movement' && values.type === 'stock_out') {
      const product = products.find((item) => item.id === String(original.id ?? ''));
      if (!product || Number(values.quantity) <= 0 || Number(values.quantity) > product.quantity) {
        setNotice(product ? 'Stock out cannot exceed current on-hand quantity.' : 'This product is no longer available.');
        return;
      }
    }
    try {
      if (modal.entity === 'business') {
        const businessCategory = values.category === 'Custom' && values.customCategory?.trim() ? values.customCategory.trim() : values.category;
        const payload = businessDetailsForType(values.name, businessCategory);
        if (online) {
          const record = editing ? await updateBusiness.mutateAsync({ businessId: id, data: payload }) : await createBusiness.mutateAsync({ data: payload });
          await storeRecord(userId, 'business', record.id, record);
          setLocalBusinesses((current) => [record, ...current.filter((business) => business.id !== record.id)]);
          setSelectedBusinessId(record.id);
        } else {
          const record = { ...payload, id, createdAt: String(original.createdAt ?? new Date().toISOString()), updatedAt: new Date().toISOString() };
          await markLocal('business', id, record, 'upsert');
          setSelectedBusinessId(record.id);
        }
      } else if (modal.entity === 'transaction') {
        const payload = { businessId, type: values.type as 'income' | 'expense', amount: Number(values.amount), date: values.date, description: values.description.trim(), category: values.category, paymentMethod: values.paymentMethod };
        if (online) {
          const record = editing ? await updateTransaction.mutateAsync({ transactionId: id, data: payload }) : await createTransaction.mutateAsync({ data: payload });
          await storeRecord(userId, 'transaction', record.id, record, businessId);
        } else {
          await markLocal('transaction', id, { ...payload, id, createdAt: String(original.createdAt ?? new Date().toISOString()), updatedAt: new Date().toISOString() }, 'upsert', businessId);
        }
      } else if (modal.entity === 'debt') {
        const payload = { businessId, direction: values.direction as 'customer_owes' | 'supplier_owed', counterpartyName: values.counterpartyName.trim(), originalAmount: Number(values.originalAmount), dueDate: values.dueDate || null, notes: values.notes || null };
        if (online) {
          const record = editing ? await updateDebt.mutateAsync({ debtId: id, data: payload }) : await createDebt.mutateAsync({ data: payload });
          await storeRecord(userId, 'debt', record.id, record, businessId);
        } else {
          await markLocal('debt', id, { ...payload, id, amountPaid: Number(original.amountPaid ?? 0), remainingBalance: Number(original.remainingBalance ?? payload.originalAmount), createdAt: String(original.createdAt ?? new Date().toISOString()), updatedAt: new Date().toISOString() }, 'upsert', businessId);
        }
      } else if (modal.entity === 'product') {
        const payload = { businessId, name: values.name.trim(), quantity: Number(values.quantity), purchasePrice: Number(values.purchasePrice), sellingPrice: Number(values.sellingPrice) };
        if (online) {
          const record = editing ? await updateProduct.mutateAsync({ productId: id, data: payload }) : await createProduct.mutateAsync({ data: payload });
          await storeRecord(userId, 'product', record.id, record, businessId);
        } else {
          await markLocal('product', id, { ...payload, id, createdAt: String(original.createdAt ?? new Date().toISOString()), updatedAt: new Date().toISOString() }, 'upsert', businessId);
        }
      } else if (modal.entity === 'payment') {
        const debtId = String(original.id ?? '');
        const payload = { amount: Number(values.amount), date: values.date, notes: values.notes || null, idempotencyKey: paymentKey };
        if (online) await recordPayment.mutateAsync({ debtId, data: payload });
        else {
          const debt = debts.find((d) => d.id === debtId);
          if (debt) {
            dropCachedBusinessQueries();
            const payment = { id: payload.idempotencyKey, debtId, amount: payload.amount, date: payload.date, notes: payload.notes, createdAt: new Date().toISOString() };
            await storeRecord(userId, 'debtPayment', payment.id, payment);
            await addPending(userId, { entity: 'debtPayment', id: payment.id, operation: 'upsert', data: { ...payment, idempotencyKey: payload.idempotencyKey }, updatedAt: payment.createdAt });
            await storeRecord(userId, 'debt', debtId, { ...debt, amountPaid: debt.amountPaid + payload.amount, remainingBalance: Math.max(0, debt.remainingBalance - payload.amount) }, businessId);
            await refreshLocal(); await refreshOutbox();
          }
        }
      } else if (modal.entity === 'movement') {
        const productId = String(original.id ?? '');
        const payload = { type: values.type as 'stock_in' | 'stock_out' | 'adjustment', quantity: Number(values.quantity), date: values.date, note: values.note || null, idempotencyKey: movementKey };
        if (online) await createMovement.mutateAsync({ productId, data: payload });
        else {
          const product = products.find((p) => p.id === productId);
          if (product) {
            dropCachedBusinessQueries();
            const movementId = payload.idempotencyKey;
            const movement = { id: movementId, productId, type: payload.type, quantity: payload.quantity, date: payload.date, note: payload.note, createdAt: new Date().toISOString() };
            await storeRecord(userId, 'stockMovement', movementId, movement, businessId);
            await addPending(userId, { entity: 'stockMovement', id: movementId, operation: 'upsert', data: { ...movement, idempotencyKey: payload.idempotencyKey }, updatedAt: movement.createdAt });
            const nextQuantity = payload.type === 'stock_in' ? product.quantity + payload.quantity : payload.type === 'stock_out' ? product.quantity - payload.quantity : payload.quantity;
            await storeRecord(userId, 'product', productId, { ...product, quantity: nextQuantity, updatedAt: new Date().toISOString() }, businessId);
            await refreshLocal(); await refreshOutbox();
          }
        }
      }
      if (modal.entity === 'payment' && businessId) client.invalidateQueries({ queryKey: getListDebtPaymentsQueryKey(String(original.id ?? '')) });
      if (modal.entity === 'movement' && String(original.id ?? '')) client.invalidateQueries({ queryKey: getListStockMovementsQueryKey(String(original.id ?? '')) });
      operationTokens.current.clear();
      await invalidateBusinessData(); await refreshLocal(); setModal(null); setNotice(online ? 'Saved' : 'Saved on this device. It will sync when you reconnect.');
    } catch {
      try {
        await persistOffline(modal.entity, values, original, id, paymentKey, movementKey);
        if (modal.entity === 'business') setSelectedBusinessId(id);
        if (!navigator.onLine) setOnline(false);
        operationTokens.current.clear();
        await invalidateBusinessData();
        await refreshLocal();
        await refreshOutbox();
        setModal(null);
        setNotice('The server did not confirm this save. It is saved on this device and queued for sync.');
      } catch (localError) {
        setNotice(localError instanceof Error ? localError.message : 'Could not save locally. Please try again.');
      }
    }
  };
  const removeRecord = async (entity: 'business' | 'transaction' | 'debt' | 'product', id: string) => {
    if (!window.confirm('Delete this record? This cannot be undone.')) return;
    try {
      if (online) {
        if (entity === 'business') await deleteBusiness.mutateAsync({ businessId: id });
        if (entity === 'transaction') await deleteTransaction.mutateAsync({ transactionId: id });
        if (entity === 'debt') await deleteDebt.mutateAsync({ debtId: id });
        if (entity === 'product') await deleteProduct.mutateAsync({ productId: id });
      }
      if (online) {
        await storeRecord(userId, entity, id, { id, businessId }, businessId, true);
        await refreshLocal();
      } else await markLocal(entity, id, { id, businessId }, 'delete', businessId);
      await invalidateBusinessData();
      if (entity === 'business' && id === selectedBusinessId) setSelectedBusinessId('');
      setNotice(online ? 'Deleted' : 'Deletion queued for sync.');
    } catch { setNotice('Could not delete this record. Please retry.'); }
  };
  if (!isLoaded || !cached) return <div className="grid min-h-[100dvh] place-items-center bg-[#f6f3e9]"><div className="w-[min(430px,88vw)] space-y-4"><div className="h-12 w-48 animate-pulse rounded-xl bg-[#e2e3d6]" /><div className="h-28 animate-pulse rounded-2xl bg-[#e2e3d6]" /><div className="h-48 animate-pulse rounded-2xl bg-[#e2e3d6]" /></div></div>;
  if (!isSignedIn) return <Redirect to="/" />;

  const navItems: { id: Tab; label: string; icon: ReactNode }[] = [
    { id: 'overview', label: 'Overview', icon: <BarChart3 size={17} /> },
    { id: 'transactions', label: 'Transactions', icon: <ArrowUpRight size={17} /> },
    { id: 'debts', label: 'Debts & payments', icon: <CreditCard size={17} /> },
    { id: 'inventory', label: 'Inventory', icon: <Boxes size={17} /> },
    { id: 'reports', label: 'Reports', icon: <FileText size={17} /> },
  ];
  const totalIncome = transactions.filter((t) => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
  const totalExpenses = transactions.filter((t) => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
  const outstanding = debts.filter((d) => d.direction === 'customer_owes').reduce((sum, d) => sum + d.remainingBalance, 0);
  const inventoryValue = products.reduce((sum, p) => sum + p.quantity * p.purchasePrice, 0);
  const filteredTransactions = transactions.filter((t) => (transactionFilter === 'all' || t.type === transactionFilter) && `${t.description} ${t.category} ${t.paymentMethod}`.toLowerCase().includes(search.toLowerCase()));
  const report: BusinessReport | undefined = reportQuery.data;
  const pageTitle = navItems.find((n) => n.id === activeTab)?.label ?? 'Overview';

  return <div className="grain min-h-[100dvh] bg-[#f6f3e9] text-[#20372e]">
    <aside className={`fixed inset-y-0 left-0 z-40 flex w-[264px] flex-col bg-[#183a2e] px-5 pb-5 pt-6 text-[#f4f0e4] transition-transform md:translate-x-0 ${mobileMenu ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="flex items-center justify-between"><Brand light /><button onClick={() => setMobileMenu(false)} className="md:hidden" aria-label="Close navigation"><X size={19} /></button></div>
      <div className="mt-9 text-[10px] font-bold uppercase tracking-[.17em] text-[#a9b7a9]">Your businesses</div>
      <div className="mt-3 space-y-1">
        {businesses.map((business) => <button key={business.id} onClick={() => { setSelectedBusinessId(business.id); setLocation(`/business/${business.id}`); setActiveTab('overview'); setMobileMenu(false); }} data-testid={`business-switch-${business.id}`} className={`group flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left transition ${activeBusiness?.id === business.id ? 'bg-[#315844] text-white' : 'text-[#d4ddd1] hover:bg-white/5'}`}>
          <span className={`grid h-8 w-8 place-items-center rounded-lg ${activeBusiness?.id === business.id ? 'bg-[#d9a84e] text-[#213a2e]' : 'bg-white/10 text-[#d7dbcc]'}`}><BusinessTypeIcon category={business.category} size={17} /></span>
          <span className="min-w-0 flex-1 truncate text-[12px] font-bold">{business.name}</span><span className={`h-1.5 w-1.5 rounded-full ${activeBusiness?.id === business.id ? 'bg-[#e4b64f]' : 'bg-[#6e8875]'}`} />
        </button>)}
        {!businesses.length && <p className="px-3 py-4 text-xs leading-5 text-[#b9c5b7]">Your books will appear here once you add a business.</p>}
      </div>
      <button onClick={() => startCreate('business')} className="mt-2 flex items-center gap-2 rounded-xl border border-dashed border-[#728a74] px-3 py-3 text-xs font-bold text-[#d6dfd3] hover:border-[#d9a84e] hover:text-white"><Plus size={15} /> Add a business</button>
      <div className="mt-8 border-t border-[#496454] pt-5">
        <div className="mb-3 px-1 text-[10px] font-bold uppercase tracking-[.17em] text-[#a9b7a9]">Workspace</div>
        {navItems.map((item) => <button key={item.id} onClick={() => { setActiveTab(item.id); setMobileMenu(false); }} data-testid={`nav-${item.id}`} className={`mb-1 flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-[12px] font-bold ${activeTab === item.id ? 'bg-[#f0ecdf] text-[#245b45]' : 'text-[#d4ddd1] hover:bg-white/5'}`}>{item.icon}{item.label}</button>)}
      </div>
      <div className="mt-auto rounded-2xl border border-[#47604e] bg-[#234637] p-4">
        <div className="flex items-center gap-2 text-xs font-bold text-[#f2e8d1]"><ShieldCheck size={16} />Your books, your view</div>
        <p className="mt-2 text-[10px] leading-4 text-[#bdc9ba]">Each business stays in its own book. Switch any time.</p>
      </div>
      <button onClick={() => setBackupOpen(true)} className="mt-2 flex items-center gap-2 rounded-xl px-3 py-2 text-left text-[11px] font-bold text-[#d4ddd1] hover:bg-white/5"><Download size={14} />Backup & restore</button>
      <div className="mt-4 flex items-center gap-3 border-t border-[#496454] pt-4">
        <div className="grid h-9 w-9 place-items-center rounded-full bg-[#d9a84e] text-xs font-extrabold text-[#20372e]">{(user?.firstName?.[0] ?? user?.username?.[0] ?? 'S').toUpperCase()}</div>
        <div className="min-w-0 flex-1"><div className="truncate text-xs font-bold">{user?.fullName ?? 'My workspace'}</div><div className="truncate text-[10px] text-[#bdc9ba]">{user?.primaryEmailAddress?.emailAddress}</div></div>
        <button onClick={() => signOut({ redirectUrl: basePath || '/' })} title="Sign out" className="rounded-lg p-2 text-[#c4d0c1] hover:bg-white/10"><LogOut size={16} /></button>
      </div>
    </aside>
    {mobileMenu && <button aria-label="Close menu backdrop" onClick={() => setMobileMenu(false)} className="fixed inset-0 z-30 bg-[#14281e]/40 md:hidden" />}
    <main className="min-h-[100dvh] md:ml-[264px]">
      <header className="sticky top-0 z-20 border-b border-[#e6e0d2] bg-[#f6f3e9]/95 px-4 py-3 backdrop-blur-md md:px-8">
        <div className="mx-auto flex max-w-[1440px] items-center gap-3">
          <button aria-label="Open navigation" onClick={() => setMobileMenu(true)} className="rounded-xl p-2 text-[#395b48] hover:bg-[#e9e6dc] md:hidden"><Menu size={20} /></button>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.15em] text-[#879287]"><span>My workspace</span><span>/</span><span className="truncate">{activeBusiness?.name ?? 'Businesses'}</span></div>
            <div className="mt-0.5 text-[16px] font-extrabold tracking-[-.03em] md:text-lg">{activeTab === 'overview' && activeBusiness ? 'Good business starts with a clear view.' : pageTitle}</div>
          </div>
          <StatusPill online={online} pending={outboxCount} />
          <button onClick={() => void syncNow()} disabled={!online || pushSync.isPending} aria-label="Sync now" title={syncMessage || 'Sync pending changes'} className="hidden rounded-xl border border-[#dedbcc] bg-[#fffdf7] p-2.5 text-[#456552] hover:bg-[#eef1e8] disabled:opacity-50 sm:block"><RefreshCw size={16} className={pushSync.isPending ? 'animate-spin' : ''} /></button>
          <Button onClick={() => startCreate(businessId ? 'transaction' : 'business')} className="px-3 py-2.5 text-xs md:px-4 md:text-sm"><Plus size={16} /><span className="hidden sm:inline">{businessId ? 'New entry' : 'Add business'}</span><span className="sm:hidden">Add</span></Button>
        </div>
        {syncMessage && <div className="mx-auto mt-2 max-w-[1440px] text-right text-[10px] text-[#6d7f70]" role="status">{syncMessage}</div>}
      </header>
      <div className="mx-auto max-w-[1440px] px-4 pb-12 pt-6 md:px-8 md:pt-8">
        {!businessId ? <EmptyBusinesses onAdd={() => startCreate('business')} loading={businessQuery.isLoading} error={businessQuery.isError} retry={() => businessQuery.refetch()} /> : <>
          <div className="mb-6 flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
            <div><p className="text-[10px] font-extrabold uppercase tracking-[.18em] text-[#9a7b3c]">{activeBusiness?.category} · BUSINESS BOOK</p><h1 className="mt-1 text-[25px] font-extrabold tracking-[-.05em] md:text-[32px]">{activeBusiness?.name}</h1></div>
            <div className="flex items-center gap-2"><Button variant="soft" onClick={() => startCreate('business', activeBusiness as unknown as Record<string, unknown>)}><Settings2 size={15} /> Edit business</Button><button onClick={() => removeRecord('business', businessId)} title="Delete business" className="rounded-xl p-2.5 text-[#a2473d] hover:bg-[#f7e7e2]"><Trash2 size={16} /></button></div>
          </div>
          {activeTab === 'overview' && <Overview business={activeBusiness} transactions={transactions} debts={debts} products={products} income={totalIncome} expenses={totalExpenses} outstanding={outstanding} inventoryValue={inventoryValue} onView={setActiveTab} onAdd={() => startCreate('transaction')} loading={transactionQuery.isLoading && !transactions.length} />}
          {activeTab === 'transactions' && <Transactions data={filteredTransactions} allCount={transactions.length} filter={transactionFilter} setFilter={setTransactionFilter} search={search} setSearch={setSearch} from={dateFrom} to={dateTo} setFrom={setDateFrom} setTo={setDateTo} onCreate={() => startCreate('transaction')} onEdit={(r) => startCreate('transaction', r as unknown as Record<string, unknown>)} onDelete={(id) => removeRecord('transaction', id)} loading={transactionQuery.isLoading && !transactions.length} error={transactionQuery.isError} retry={() => transactionQuery.refetch()} />}
          {activeTab === 'debts' && <Debts data={debts} payments={paymentQuery.data ?? []} onCreate={() => startCreate('debt')} onEdit={(r) => startCreate('debt', r as unknown as Record<string, unknown>)} onPay={(r) => setModal({ entity: 'payment', value: r as unknown as Record<string, unknown>, intent: 'payment' })} onDelete={(id) => removeRecord('debt', id)} />}
          {activeTab === 'inventory' && <Inventory data={products} movements={movementQuery.data ?? []} onCreate={() => startCreate('product')} onEdit={(r) => startCreate('product', r as unknown as Record<string, unknown>)} onMovement={(p) => setModal({ entity: 'movement', value: p as unknown as Record<string, unknown>, intent: 'movement' })} onDelete={(id) => removeRecord('product', id)} />}
          {activeTab === 'reports' && <Reports report={report} transactions={transactions} income={totalIncome} expenses={totalExpenses} customerDebt={debts.filter((d) => d.direction === 'customer_owes').reduce((s, d) => s + d.remainingBalance, 0)} supplierDebt={debts.filter((d) => d.direction === 'supplier_owed').reduce((s, d) => s + d.remainingBalance, 0)} from={dateFrom} to={dateTo} setFrom={setDateFrom} setTo={setDateTo} loading={reportQuery.isLoading} error={reportQuery.isError} retry={() => reportQuery.refetch()} />}
        </>}
      </div>
    </main>
    {modal && <RecordModal modal={modal} onClose={() => setModal(null)} onSubmit={saveRecord} pending={createBusiness.isPending || updateBusiness.isPending || createTransaction.isPending || updateTransaction.isPending || createDebt.isPending || updateDebt.isPending || createProduct.isPending || updateProduct.isPending || recordPayment.isPending || createMovement.isPending} />}
    {backupOpen && <BackupModal userId={userId} onClose={() => setBackupOpen(false)} onRestored={async () => { await refreshLocal(); await refreshOutbox(); dropCachedBusinessQueries(); invalidateBusinessData(); }} />}
    {notice && <div role="status" className="fixed bottom-5 right-5 z-[70] flex max-w-[min(90vw,420px)] items-center gap-3 rounded-2xl bg-[#20372e] px-4 py-3 text-sm font-semibold text-[#f6f2e7] shadow-xl"><Check size={17} className="text-[#e1b650]" />{notice}<button onClick={() => setNotice('')} aria-label="Dismiss notice"><X size={15} /></button></div>}
  </div>;
}

function EmptyBusinesses({ onAdd, loading, error, retry }: { onAdd: () => void; loading: boolean; error: boolean; retry: () => void }) {
  return <div className="mx-auto max-w-3xl rounded-[30px] border border-[#e3dece] bg-[#fffdf7] p-7 text-center shadow-[var(--shadow-soft)] md:p-14">
    <div className="mx-auto grid h-16 w-16 place-items-center rounded-[22px] bg-[#e9efe4] text-[#245b45]"><BriefcaseBusiness size={28} /></div>
    <div className="mt-6 text-[10px] font-extrabold uppercase tracking-[.2em] text-[#a87929]">One workspace. Separate books.</div>
    <h2 className="mx-auto mt-3 max-w-xl text-3xl font-extrabold tracking-[-.06em] md:text-5xl">Give every business its own place to grow.</h2>
    <p className="mx-auto mt-4 max-w-lg text-sm leading-6 text-[#69786d]">Keep farming, timber, transport, mobile money and your other ventures organized in distinct business books.</p>
    {error && <p role="alert" className="mt-5 text-sm text-[#a2473d]">Your businesses could not be loaded. Your offline books remain available.</p>}
    <div className="mt-7 flex justify-center gap-3">{error && <Button variant="soft" onClick={retry}><RefreshCw size={15} />Retry</Button>}<Button onClick={onAdd}><Plus size={17} />Create your first business</Button></div>
    <div className="mt-9 grid grid-cols-2 gap-2 md:grid-cols-3">{categories.slice(0, 5).map((c) => <div key={c} className="flex items-center gap-2 rounded-xl bg-[#f4f2e9] px-3 py-3 text-left text-xs font-bold text-[#617267]"><span className="text-[#47765a]"><BusinessTypeIcon category={c} /></span>{c}</div>)}</div>
    {loading && <div className="mt-6 text-xs text-[#829086]">Checking your saved business books…</div>}
  </div>;
}

function Overview({ business, transactions, debts, products, income, expenses, outstanding, inventoryValue, onView, onAdd, loading }: {
  business?: Business; transactions: Transaction[]; debts: Debt[]; products: Product[]; income: number; expenses: number; outstanding: number; inventoryValue: number; onView: (tab: Tab) => void; onAdd: () => void; loading: boolean;
}) {
  const recent = [...transactions].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 5);
  const profit = income - expenses;
  return <div className="reveal space-y-6">
    <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
      <Metric label="Income this period" amount={income} icon={<ArrowDownLeft size={17} />} tone="green" detail="Recorded sales & receipts" />
      <Metric label="Expenses this period" amount={expenses} icon={<ArrowUpRight size={17} />} tone="gold" detail="Purchases & operating costs" />
      <Metric label="Net position" amount={profit} icon={profit >= 0 ? <TrendingUp size={17} /> : <TrendingDown size={17} />} tone="dark" detail="Income less expenses" />
      <Metric label="Customers owe" amount={outstanding} icon={<CircleDollarSign size={17} />} tone="rose" detail={`${debts.filter((d) => d.remainingBalance > 0).length} open accounts`} />
    </div>
    <div className="grid gap-5 xl:grid-cols-[1.5fr_1fr]">
      <section className="overflow-hidden rounded-[24px] border border-[#e3dece] bg-[#fffdf7] shadow-[var(--shadow-soft)]">
        <div className="flex items-center justify-between border-b border-[#eee9dc] px-5 py-4 md:px-6"><div><div className="text-sm font-extrabold">Recent activity</div><div className="mt-1 text-xs text-[#829086]">Latest entries in {business?.name}</div></div><button onClick={() => onView('transactions')} className="flex items-center gap-1 text-xs font-extrabold text-[#32654b]">All entries <ArrowRight size={14} /></button></div>
        {loading ? <RowsSkeleton /> : recent.length ? <div className="divide-y divide-[#f0ecdf]">{recent.map((t) => <TransactionRow key={t.id} item={t} />)}</div> : <EmptyPanel icon={<Activity size={20} />} title="No activity recorded yet" text="Your first income or expense will appear here." action={<Button onClick={onAdd}><Plus size={15} />Add first entry</Button>} />}
      </section>
      <div className="space-y-5">
        <section className="rounded-[24px] bg-[#214a39] p-6 text-[#f6f2e7] shadow-[var(--shadow-soft)]">
          <div className="flex items-center justify-between"><span className="text-xs font-bold text-[#c6d4c4]">Inventory at cost</span><Boxes size={18} className="text-[#dfb451]" /></div>
          <div className="mono mt-3 text-[25px] font-medium tracking-[-.06em]">{money(inventoryValue)}</div>
          <div className="mt-1 text-[11px] text-[#bdcbbd]">{products.length} products tracked</div>
          <button onClick={() => onView('inventory')} className="mt-5 flex items-center gap-2 text-xs font-bold text-[#e4bc62]">Review stock <ArrowRight size={14} /></button>
        </section>
        <section className="rounded-[24px] border border-[#e3dece] bg-[#fffdf7] p-5">
          <div className="flex items-center justify-between"><div><div className="text-sm font-extrabold">Business snapshot</div><div className="mt-1 text-xs text-[#829086]">At a glance</div></div><span className="grid h-9 w-9 place-items-center rounded-xl bg-[#f1ead9] text-[#99752f]"><Leaf size={18} /></span></div>
          <div className="mt-4 space-y-3"><Snapshot label="Open customer balances" value={debts.filter((d) => d.direction === 'customer_owes' && d.remainingBalance > 0).length} /><Snapshot label="Supplier balances" value={debts.filter((d) => d.direction === 'supplier_owed' && d.remainingBalance > 0).length} /><Snapshot label="Products below 5 units" value={products.filter((p) => p.quantity < 5).length} /></div>
          <Button variant="soft" onClick={() => onView('debts')} className="mt-4 w-full">Manage balances</Button>
        </section>
      </div>
    </div>
    <div className="flex flex-col justify-between gap-3 rounded-[22px] border border-[#e5dfce] bg-[#eee9dc] px-5 py-4 sm:flex-row sm:items-center">
      <div><div className="text-sm font-extrabold">Need to enter something?</div><div className="mt-1 text-xs text-[#6f7d72]">Keep this book current while the details are fresh.</div></div>
      <div className="flex gap-2"><Button variant="soft" onClick={() => onView('debts')}><CreditCard size={15} />Add debt</Button><Button onClick={onAdd}><Plus size={15} />Add entry</Button></div>
    </div>
  </div>;
}

function Metric({ label, amount, icon, tone, detail, currency = true }: { label: string; amount: number; icon: ReactNode; tone: string; detail: string; currency?: boolean }) {
  const styles: Record<string, string> = { green: 'bg-[#e7efe6] text-[#32654b]', gold: 'bg-[#f3ecd9] text-[#96732e]', dark: 'bg-[#214a39] text-[#f5f0e2]', rose: 'bg-[#f5e8e2] text-[#a25142]' };
  return <div className="rounded-[21px] border border-[#e3dece] bg-[#fffdf7] p-4 shadow-[var(--shadow-soft)] md:p-5"><div className="flex items-center justify-between"><span className="text-[11px] font-bold text-[#728076]">{label}</span><span className={`grid h-8 w-8 place-items-center rounded-xl ${styles[tone]}`}>{icon}</span></div><div className="mono mt-4 truncate text-[22px] font-medium tracking-[-.055em] md:text-[24px]">{currency ? money(amount) : new Intl.NumberFormat('en-MW').format(amount)}</div><div className="mt-2 text-[10px] text-[#8b958b]">{detail}</div></div>;
}
function Snapshot({ label, value }: { label: string; value: number }) { return <div className="flex items-center justify-between text-xs"><span className="text-[#718075]">{label}</span><span className="mono rounded-md bg-[#f2f0e6] px-2 py-1 font-medium">{value}</span></div>; }
function TransactionRow({ item, onEdit, onDelete }: { item: Transaction; onEdit?: () => void; onDelete?: () => void }) {
  return <div className="group flex items-center gap-3 px-5 py-4 md:px-6">
    <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl ${item.type === 'income' ? 'bg-[#e5efe4] text-[#32654b]' : 'bg-[#f5e8e2] text-[#a25142]'}`}>{item.type === 'income' ? <ArrowDownLeft size={17} /> : <ArrowUpRight size={17} />}</span>
    <div className="min-w-0 flex-1"><div className="truncate text-xs font-extrabold">{item.description}</div><div className="mt-1 truncate text-[10px] text-[#89958a]">{item.category} · {item.date} · {item.paymentMethod}</div></div>
    <div className={`mono text-xs font-medium ${item.type === 'income' ? 'text-[#32654b]' : 'text-[#a25142]'}`}>{item.type === 'income' ? '+' : '−'}{money(item.amount)}</div>
    {onEdit && <div className="hidden gap-1 group-hover:flex"><button aria-label="Edit transaction" onClick={onEdit} className="rounded-lg p-1.5 text-[#64766a] hover:bg-[#ece9df]"><Settings2 size={14} /></button><button aria-label="Delete transaction" onClick={onDelete} className="rounded-lg p-1.5 text-[#a2473d] hover:bg-[#f7e7e2]"><Trash2 size={14} /></button></div>}
  </div>;
}
function RowsSkeleton() { return <div className="space-y-4 p-6">{[1, 2, 3].map((n) => <div key={n} className="flex gap-3"><div className="h-9 w-9 animate-pulse rounded-xl bg-[#ebe8dc]" /><div className="flex-1 space-y-2 pt-1"><div className="h-3 w-2/3 animate-pulse rounded bg-[#ebe8dc]" /><div className="h-2 w-1/3 animate-pulse rounded bg-[#ebe8dc]" /></div></div>)}</div>; }
function EmptyPanel({ icon, title, text, action }: { icon: ReactNode; title: string; text: string; action?: ReactNode }) { return <div className="flex min-h-[190px] flex-col items-center justify-center px-5 py-8 text-center"><span className="grid h-11 w-11 place-items-center rounded-2xl bg-[#edf0e7] text-[#467356]">{icon}</span><div className="mt-3 text-sm font-extrabold">{title}</div><p className="mt-1 max-w-sm text-xs leading-5 text-[#879187]">{text}</p>{action && <div className="mt-4">{action}</div>}</div>; }

function Transactions({ data, allCount, filter, setFilter, search, setSearch, from, to, setFrom, setTo, onCreate, onEdit, onDelete, loading, error, retry }: { data: Transaction[]; allCount: number; filter: string; setFilter: (v: string) => void; search: string; setSearch: (v: string) => void; from: string; to: string; setFrom: (v: string) => void; setTo: (v: string) => void; onCreate: () => void; onEdit: (r: Transaction) => void; onDelete: (id: string) => void; loading: boolean; error: boolean; retry: () => void }) {
  return <section className="reveal overflow-hidden rounded-[24px] border border-[#e3dece] bg-[#fffdf7] shadow-[var(--shadow-soft)]">
    <div className="flex flex-col gap-4 border-b border-[#eee9dc] px-5 py-5 md:flex-row md:items-center md:justify-between md:px-6"><div><h2 className="text-base font-extrabold">Transactions</h2><p className="mt-1 text-xs text-[#839086]">{allCount} entries in this business book</p></div><Button onClick={onCreate}><Plus size={15} />Record transaction</Button></div>
    <div className="flex flex-col gap-3 border-b border-[#eee9dc] px-5 py-4 sm:flex-row md:px-6">
      <div className="relative min-w-[190px] flex-1"><Search size={15} className="absolute left-3 top-3 text-[#859187]" /><input aria-label="Search transactions" data-testid="input-search-transactions" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search description, category…" className={`${inputClass} py-2.5 pl-9`} /></div>
      <div className="flex items-center gap-2"><Filter size={15} className="text-[#819087]" />{['all', 'income', 'expense'].map((v) => <button key={v} onClick={() => setFilter(v)} className={`rounded-lg px-3 py-2 text-[11px] font-extrabold capitalize ${filter === v ? 'bg-[#245b45] text-white' : 'bg-[#f1efe6] text-[#68776d]'}`}>{v}</button>)}</div>
      <div className="flex items-center gap-2"><input aria-label="Transactions from" type="date" value={from} onChange={(e) => setFrom(e.target.value)} className={`${inputClass} min-w-0 px-2 py-2 text-[10px] sm:w-[132px]`} /><span className="text-[10px] text-[#89958a]">to</span><input aria-label="Transactions to" type="date" value={to} onChange={(e) => setTo(e.target.value)} className={`${inputClass} min-w-0 px-2 py-2 text-[10px] sm:w-[132px]`} /></div>
    </div>
    {error && <div className="flex items-center justify-between bg-[#fbefeb] px-5 py-3 text-xs text-[#974f42]"><span>Could not refresh from the server. Showing any saved entries.</span><button onClick={retry} className="font-bold underline">Try again</button></div>}
    {loading ? <RowsSkeleton /> : data.length ? <div className="divide-y divide-[#f0ecdf]">{data.map((t) => <TransactionRow key={t.id} item={t} onEdit={() => onEdit(t)} onDelete={() => onDelete(t.id)} />)}</div> : <EmptyPanel icon={<Activity size={20} />} title={allCount ? 'No entries match these filters' : 'Your first entry starts the story'} text={allCount ? 'Try clearing the search or choosing another transaction type.' : 'Record income or expenses for this business only.'} action={!allCount ? <Button onClick={onCreate}><Plus size={15} />Add a transaction</Button> : undefined} />}
  </section>;
}

function Debts({ data, payments, onCreate, onEdit, onPay, onDelete }: { data: Debt[]; payments: { id: string; debtId: string; amount: number; date: string; notes: string | null }[]; onCreate: () => void; onEdit: (r: Debt) => void; onPay: (r: Debt) => void; onDelete: (id: string) => void }) {
  const customer = data.filter((d) => d.direction === 'customer_owes').reduce((s, d) => s + d.remainingBalance, 0);
  const supplier = data.filter((d) => d.direction === 'supplier_owed').reduce((s, d) => s + d.remainingBalance, 0);
  return <div className="reveal space-y-5">
    <div className="grid gap-3 md:grid-cols-3">
      <div className="rounded-[21px] bg-[#214a39] p-5 text-[#f6f2e7]"><div className="text-[11px] font-bold text-[#c4d1c2]">Customers owe</div><div className="mono mt-3 text-2xl">{money(customer)}</div></div>
      <div className="rounded-[21px] border border-[#e3dece] bg-[#fffdf7] p-5"><div className="text-[11px] font-bold text-[#7d897f]">Owed to suppliers</div><div className="mono mt-3 text-2xl">{money(supplier)}</div></div>
      <div className="rounded-[21px] border border-[#e3dece] bg-[#fffdf7] p-5"><div className="text-[11px] font-bold text-[#7d897f]">Open accounts</div><div className="mono mt-3 text-2xl">{data.filter((d) => d.remainingBalance > 0).length}</div></div>
    </div>
    <section className="overflow-hidden rounded-[24px] border border-[#e3dece] bg-[#fffdf7] shadow-[var(--shadow-soft)]">
      <div className="flex items-center justify-between gap-3 border-b border-[#eee9dc] px-5 py-5 md:px-6"><div><h2 className="text-base font-extrabold">Debts & payments</h2><p className="mt-1 text-xs text-[#839086]">Track who owes this business and whom it owes</p></div><Button onClick={onCreate}><Plus size={15} />Add debt</Button></div>
      {!data.length ? <EmptyPanel icon={<CreditCard size={20} />} title="No balances to chase" text="Add customer or supplier balances to keep every promise visible." action={<Button onClick={onCreate}><Plus size={15} />Add a balance</Button>} /> :
        <div className="divide-y divide-[#f0ecdf]">{data.map((d) => <article key={d.id} data-testid={`debt-row-${d.id}`} className="px-5 py-4 md:px-6">
          <div className="flex flex-wrap items-center gap-3">
            <span className={`grid h-9 w-9 place-items-center rounded-xl ${d.direction === 'customer_owes' ? 'bg-[#e5efe4] text-[#32654b]' : 'bg-[#f3ecd9] text-[#96732e]'}`}>{d.direction === 'customer_owes' ? <ArrowDownLeft size={17} /> : <Truck size={17} />}</span>
            <div className="min-w-[130px] flex-1"><div className="text-xs font-extrabold">{d.counterpartyName}</div><div className="mt-1 text-[10px] text-[#89958a]">{d.direction === 'customer_owes' ? 'Customer owes' : 'Supplier balance'}{d.dueDate ? ` · Due ${d.dueDate}` : ''}</div></div>
            <div className="text-right"><div className="mono text-xs font-medium">{money(d.remainingBalance)}</div><div className="mt-1 text-[10px] text-[#89958a]">of {money(d.originalAmount)} remaining</div></div>
            <div className="flex items-center gap-1">
              {d.direction === 'customer_owes' && d.remainingBalance > 0 && <Button variant="soft" className="px-3 py-2 text-[11px]" onClick={() => onPay(d)}><CircleDollarSign size={14} />Payment</Button>}
              <button onClick={() => onEdit(d)} aria-label="Edit debt" className="rounded-lg p-2 text-[#64766a] hover:bg-[#ece9df]"><Settings2 size={15} /></button>
              <button onClick={() => onDelete(d.id)} aria-label="Delete debt" className="rounded-lg p-2 text-[#a2473d] hover:bg-[#f7e7e2]"><Trash2 size={15} /></button>
            </div>
          </div>
          {d.notes && <p className="ml-12 mt-2 text-[11px] text-[#7d897f]">{d.notes}</p>}
          {payments.some((payment) => payment.debtId === d.id) && <div className="ml-12 mt-3 rounded-xl bg-[#f5f2e9] px-3 py-2"><div className="mb-1 text-[9px] font-extrabold uppercase tracking-[.12em] text-[#7f8c7f]">Latest payments</div>{payments.filter((payment) => payment.debtId === d.id).slice(0, 2).map((p) => <div key={p.id} className="flex justify-between py-1 text-[10px]"><span className="text-[#6f7d72]">{p.date}{p.notes ? ` · ${p.notes}` : ''}</span><span className="mono font-medium text-[#32654b]">{money(p.amount)}</span></div>)}</div>}
        </article>)}</div>}
    </section>
  </div>;
}

function Inventory({ data, movements, onCreate, onEdit, onMovement, onDelete }: { data: Product[]; movements: StockMovement[]; onCreate: () => void; onEdit: (r: Product) => void; onMovement: (r: Product) => void; onDelete: (id: string) => void }) {
  const worth = data.reduce((s, p) => s + p.quantity * p.purchasePrice, 0);
  const low = data.filter((p) => p.quantity < 5);
  return <div className="reveal space-y-5">
    <div className="grid gap-3 md:grid-cols-3">
      <div className="rounded-[21px] border border-[#e3dece] bg-[#fffdf7] p-5"><div className="text-[11px] font-bold text-[#7d897f]">Tracked products</div><div className="mono mt-3 text-2xl">{data.length}</div></div>
      <div className="rounded-[21px] bg-[#214a39] p-5 text-[#f6f2e7]"><div className="text-[11px] font-bold text-[#c4d1c2]">Stock at cost</div><div className="mono mt-3 text-2xl">{money(worth)}</div></div>
      <div className={`rounded-[21px] border p-5 ${low.length ? 'border-[#e9d4c7] bg-[#f7ebe3]' : 'border-[#e3dece] bg-[#fffdf7]'}`}><div className="text-[11px] font-bold text-[#7d897f]">Low stock · under 5</div><div className="mono mt-3 text-2xl">{low.length}</div></div>
    </div>
    <section className="overflow-hidden rounded-[24px] border border-[#e3dece] bg-[#fffdf7] shadow-[var(--shadow-soft)]">
      <div className="flex items-center justify-between gap-3 border-b border-[#eee9dc] px-5 py-5 md:px-6"><div><h2 className="text-base font-extrabold">Inventory</h2><p className="mt-1 text-xs text-[#839086]">Products and stock movements for this business</p></div><Button onClick={onCreate}><Plus size={15} />Add product</Button></div>
      {!data.length ? <EmptyPanel icon={<Boxes size={20} />} title="No products in this book" text="Add products to track current quantity and stock value." action={<Button onClick={onCreate}><Plus size={15} />Add first product</Button>} /> :
        <div className="overflow-x-auto"><table className="w-full min-w-[680px] text-left"><thead className="bg-[#f5f2e9] text-[9px] uppercase tracking-[.12em] text-[#849087]"><tr><th className="px-5 py-3">Product</th><th className="px-4 py-3">In stock</th><th className="px-4 py-3">Cost price</th><th className="px-4 py-3">Selling price</th><th className="px-4 py-3">Stock value</th><th className="px-5 py-3"></th></tr></thead><tbody className="divide-y divide-[#f0ecdf]">{data.map((p) => <tr key={p.id} data-testid={`product-row-${p.id}`}><td className="px-5 py-4 text-xs font-extrabold">{p.name}</td><td className="px-4 py-4"><span className={`rounded-lg px-2.5 py-1.5 text-xs font-extrabold ${p.quantity < 5 ? 'bg-[#f7e8dc] text-[#965a2a]' : 'bg-[#e7efe6] text-[#32654b]'}`}>{p.quantity}</span></td><td className="mono px-4 py-4 text-xs">{money(p.purchasePrice)}</td><td className="mono px-4 py-4 text-xs">{money(p.sellingPrice)}</td><td className="mono px-4 py-4 text-xs">{money(p.quantity * p.purchasePrice)}</td><td className="px-5 py-4"><div className="flex justify-end gap-1"><button onClick={() => onMovement(p)} className="rounded-lg bg-[#e9eee6] px-2.5 py-2 text-[10px] font-extrabold text-[#32654b]">Move stock</button><button onClick={() => onEdit(p)} aria-label="Edit product" className="rounded-lg p-2 text-[#64766a] hover:bg-[#ece9df]"><Settings2 size={14} /></button><button onClick={() => onDelete(p.id)} aria-label="Delete product" className="rounded-lg p-2 text-[#a2473d] hover:bg-[#f7e7e2]"><Trash2 size={14} /></button></div></td></tr>)}</tbody></table></div>}
      {movements.length > 0 && <div className="border-t border-[#eee9dc] px-5 py-4 md:px-6"><div className="mb-3 flex items-center gap-2 text-xs font-extrabold"><Activity size={14} className="text-[#497451]" />Recent stock movement</div><div className="flex flex-wrap gap-2">{movements.slice(0, 4).map((m) => <span key={m.id} className="rounded-lg bg-[#f3f0e7] px-3 py-2 text-[10px] text-[#68776d]">{m.type.replace('_', ' ')} · {m.quantity} · {m.date}</span>)}</div></div>}
    </section>
  </div>;
}

function Reports({ report, transactions, income, expenses, customerDebt, supplierDebt, from, to, setFrom, setTo, loading, error, retry }: { report?: BusinessReport; transactions: Transaction[]; income: number; expenses: number; customerDebt: number; supplierDebt: number; from: string; to: string; setFrom: (v: string) => void; setTo: (v: string) => void; loading: boolean; error: boolean; retry: () => void }) {
  const reportIncome = report?.totalIncome ?? income;
  const reportExpenses = report?.totalExpenses ?? expenses;
  const max = Math.max(reportIncome, reportExpenses, 1);
  const txs = report?.transactions ?? transactions;
  return <div className="reveal space-y-5">
    <section className="flex flex-col gap-4 rounded-[24px] border border-[#e3dece] bg-[#fffdf7] p-5 shadow-[var(--shadow-soft)] md:flex-row md:items-end md:justify-between md:px-6">
      <div><div className="text-xs font-extrabold uppercase tracking-[.12em] text-[#98752f]">Period summary</div><h2 className="mt-1 text-xl font-extrabold tracking-[-.04em]">A clearer look at the numbers</h2><p className="mt-1 text-xs text-[#839086]">{report ? 'Report returned by your business server.' : 'Showing entries currently available on this device.'}</p></div>
      <div className="flex flex-wrap items-end gap-2"><label className="text-[10px] font-bold text-[#758177]">From<input data-testid="input-report-from" type="date" value={from} onChange={(e) => setFrom(e.target.value)} className={`${inputClass} mt-1 w-[145px] py-2`} /></label><label className="text-[10px] font-bold text-[#758177]">To<input data-testid="input-report-to" type="date" value={to} onChange={(e) => setTo(e.target.value)} className={`${inputClass} mt-1 w-[145px] py-2`} /></label><button onClick={() => { const csv = ['Date,Type,Description,Category,Payment method,Amount', ...txs.map((t) => [t.date, t.type, `"${t.description.replaceAll('"', '""')}"`, `"${t.category}"`, `"${t.paymentMethod}"`, t.amount].join(','))].join('\n'); const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); const a = document.createElement('a'); a.href = url; a.download = 'smartbiz-report.csv'; a.click(); URL.revokeObjectURL(url); }} className="inline-flex items-center gap-2 rounded-xl bg-[#245b45] px-3 py-2.5 text-xs font-bold text-white hover:bg-[#194633]"><Download size={14} />Export CSV</button></div>
    </section>
    {error && <div className="flex items-center justify-between rounded-xl bg-[#fbefeb] px-4 py-3 text-xs text-[#974f42]"><span>Server report unavailable. Displaying cached transaction totals.</span><button onClick={retry} className="font-bold underline">Try again</button></div>}
    {loading && !report ? <RowsSkeleton /> : <>
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4"><Metric label="Total income" amount={reportIncome} icon={<ArrowDownLeft size={17} />} tone="green" detail="For the selected dates" /><Metric label="Total expenses" amount={reportExpenses} icon={<ArrowUpRight size={17} />} tone="gold" detail="For the selected dates" /><Metric label="Net profit" amount={report?.netProfit ?? reportIncome - reportExpenses} icon={<TrendingUp size={17} />} tone="dark" detail="Income less expenses" /><Metric label="Transactions" amount={report?.transactionCount ?? txs.length} icon={<FileText size={17} />} tone="rose" detail={`${from} to ${to}`} currency={false} /></div>
      <div className="grid gap-5 xl:grid-cols-[1.25fr_1fr]">
        <section className="rounded-[24px] border border-[#e3dece] bg-[#fffdf7] p-5 md:p-6"><div className="text-sm font-extrabold">Income & expenses</div><p className="mt-1 text-xs text-[#839086]">Totals in Malawi kwacha for selected dates</p><div className="mt-7 space-y-5"><ChartBar label="Income" value={reportIncome} max={max} color="bg-[#3e7855]" /><ChartBar label="Expenses" value={reportExpenses} max={max} color="bg-[#d6a548]" /></div></section>
        <section className="rounded-[24px] bg-[#214a39] p-5 text-[#f6f2e7] md:p-6"><div className="text-sm font-extrabold">Balance watch</div><p className="mt-1 text-xs text-[#c4d1c2]">Outstanding accounts included in this book</p><div className="mt-6 space-y-4"><div className="flex justify-between border-b border-white/15 pb-3 text-xs"><span className="text-[#c4d1c2]">Customers owe</span><span className="mono">{money(report?.customerDebt ?? customerDebt)}</span></div><div className="flex justify-between text-xs"><span className="text-[#c4d1c2]">Owed to suppliers</span><span className="mono">{money(report?.supplierDebt ?? supplierDebt)}</span></div></div></section>
      </div>
      <section className="overflow-hidden rounded-[24px] border border-[#e3dece] bg-[#fffdf7]"><div className="border-b border-[#eee9dc] px-5 py-4 text-sm font-extrabold">Transactions in this period</div>{txs.length ? <div className="divide-y divide-[#f0ecdf]">{txs.slice(0, 10).map((t) => <TransactionRow key={t.id} item={t} />)}</div> : <EmptyPanel icon={<FileText size={20} />} title="Nothing in this period" text="Try expanding the date range to include more activity." />}</section>
    </>}
  </div>;
}
function ChartBar({ label, value, max, color }: { label: string; value: number; max: number; color: string }) { return <div><div className="mb-2 flex justify-between text-xs"><span className="font-bold text-[#66766b]">{label}</span><span className="mono">{money(value)}</span></div><div className="h-3 overflow-hidden rounded-full bg-[#efede4]"><div className={`h-full rounded-full ${color} transition-all duration-500`} style={{ width: `${Math.max(value > 0 ? 4 : 0, value / max * 100)}%` }} /></div></div>; }

function RecordModal({ modal, onClose, onSubmit, pending }: { modal: NonNullable<ModalState>; onClose: () => void; onSubmit: (e: FormEvent<HTMLFormElement>) => void; pending: boolean }) {
  const v = modal.value ?? {};
  const editing = modal.intent === 'edit';
  const title = modal.entity === 'payment' ? 'Record a payment' : modal.entity === 'movement' ? `Move stock · ${String(v.name ?? '')}` : `${editing ? 'Edit' : 'Add'} ${modal.entity}`;
  const fields: { name: string; label: string; type?: string; options?: string[]; required?: boolean; step?: string }[] = modal.entity === 'business' ? [
    { name: 'name', label: 'Business name', required: true }, { name: 'category', label: 'Business type', options: [...categories, ...(typeof v.category === 'string' && !categories.includes(v.category) ? [v.category] : [])] },
    { name: 'customCategory', label: 'Custom business type' },
  ] : modal.entity === 'transaction' ? [
    { name: 'type', label: 'Entry type', options: ['income', 'expense'] }, { name: 'amount', label: 'Amount · MWK', type: 'number', required: true, step: '1' },
    { name: 'date', label: 'Date', type: 'date', required: true }, { name: 'description', label: 'What was this for?', required: true },
    { name: 'category', label: 'Category', options: ['Sales', 'Stock purchase', 'Transport', 'Operating costs', 'Mobile money', 'Harvest', 'Other'] },
    { name: 'paymentMethod', label: 'Payment method', options: ['Cash', 'Airtel Money', 'TNM Mpamba', 'Bank transfer', 'Credit', 'Other'] },
  ] : modal.entity === 'debt' ? [
    { name: 'direction', label: 'Balance direction', options: ['customer_owes', 'supplier_owed'] }, { name: 'counterpartyName', label: 'Customer or supplier', required: true },
    { name: 'originalAmount', label: 'Original amount · MWK', type: 'number', required: true }, { name: 'dueDate', label: 'Due date', type: 'date' }, { name: 'notes', label: 'Notes' },
  ] : modal.entity === 'product' ? [
    { name: 'name', label: 'Product name', required: true }, { name: 'quantity', label: 'Quantity in stock', type: 'number', required: true },
    { name: 'purchasePrice', label: 'Purchase price · MWK', type: 'number', required: true }, { name: 'sellingPrice', label: 'Selling price · MWK', type: 'number', required: true },
  ] : modal.entity === 'payment' ? [
    { name: 'amount', label: 'Payment amount · MWK', type: 'number', required: true }, { name: 'date', label: 'Payment date', type: 'date', required: true }, { name: 'notes', label: 'Notes' },
  ] : [
    { name: 'type', label: 'Movement type', options: ['stock_in', 'stock_out', 'adjustment'] }, { name: 'quantity', label: 'Quantity', type: 'number', required: true }, { name: 'date', label: 'Date', type: 'date', required: true }, { name: 'note', label: 'Note' },
  ];
  const defaults: Record<string, unknown> = { date: dateToday(), category: modal.entity === 'business' ? 'Farming' : 'Other', paymentMethod: 'Cash', type: modal.entity === 'transaction' ? 'income' : modal.entity === 'movement' ? 'stock_in' : 'customer_owes', direction: 'customer_owes', ...v };
  return <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#14281e]/50 p-0 backdrop-blur-[2px] sm:items-center sm:p-4" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
    <form onSubmit={onSubmit} className="max-h-[92dvh] w-full max-w-[520px] overflow-y-auto rounded-t-[26px] border border-[#e4dece] bg-[#fffdf7] p-5 shadow-2xl sm:rounded-[26px] sm:p-7">
      <div className="flex items-start justify-between"><div><div className="text-[10px] font-extrabold uppercase tracking-[.17em] text-[#9b7a38]">SMARTBIZ PRO · {modal.entity}</div><h2 className="mt-1 text-xl font-extrabold capitalize tracking-[-.04em]">{title}</h2></div><button type="button" aria-label="Close form" onClick={onClose} className="rounded-xl p-2 text-[#637369] hover:bg-[#efede4]"><X size={18} /></button></div>
      {modal.entity === 'payment' && <div className="mt-4 rounded-xl bg-[#eef1e8] px-3 py-2 text-xs text-[#4a6652]">{String(v.counterpartyName ?? '')} · outstanding {money(Number(v.remainingBalance ?? 0))}</div>}
      <div className="mt-5 grid gap-4 md:grid-cols-2">{fields.map((field) => <label key={field.name} className={`block text-[11px] font-extrabold text-[#637369] ${field.name === 'notes' || field.name === 'description' || field.name === 'name' && modal.entity === 'business' ? 'md:col-span-2' : ''}`}>{field.label}
        {field.options ? <select name={field.name} required={field.required} defaultValue={String(defaults[field.name] ?? field.options[0])} className={`${inputClass} mt-1.5`}><>{field.options.map((o) => <option key={o} value={o}>{o.replaceAll('_', ' ').replace(/\b\w/g, (c) => c.toUpperCase())}</option>)}</></select> :
          <input name={field.name} type={field.type ?? 'text'} required={field.required} step={field.step} min={field.type === 'number' ? '0' : undefined} defaultValue={String(defaults[field.name] ?? '')} className={`${inputClass} mt-1.5`} placeholder={field.type === 'number' ? '0' : ''} />}</label>)}</div>
      <div className="mt-6 flex gap-3"><Button type="submit" disabled={pending} className="flex-1">{pending ? 'Saving…' : <><Check size={15} />Save {modal.entity === 'payment' ? 'payment' : modal.entity === 'movement' ? 'movement' : 'record'}</>}</Button><Button variant="soft" onClick={onClose}>Cancel</Button></div>
      {!navigator.onLine && <div className="mt-3 flex items-start gap-2 text-[10px] leading-4 text-[#8c6735]"><CloudOff size={13} className="mt-0.5 shrink-0" />Changes are saved to this device and queued to sync when you reconnect.</div>}
    </form>
  </div>;
}

function BackupModal({ userId, onClose, onRestored }: { userId: string; onClose: () => void; onRestored: () => Promise<void> }) {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState(false);
  const downloadBackup = async () => {
    setBusy(true); setError(false); setMessage('');
    try {
      const backup = await createUserBackup(userId);
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = `smartbiz-pro-backup-${new Date().toISOString().slice(0, 10)}.json`;
      anchor.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      setMessage(`${backup.records.length} saved records and ${backup.outbox.length} pending changes included.`);
    } catch {
      setError(true); setMessage('Could not prepare this backup. Your saved data has not been changed.');
    } finally { setBusy(false); }
  };
  const restoreFile = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.currentTarget.files?.[0];
    event.currentTarget.value = '';
    if (!file) return;
    setBusy(true); setError(false); setMessage('');
    try {
      if (file.size > 25 * 1024 * 1024) throw new Error('Backup files must be smaller than 25 MB.');
      const parsed: unknown = JSON.parse(await file.text());
      const restored = await restoreUserBackup(userId, parsed);
      await onRestored();
      setMessage(`Restored ${restored.records} records and ${restored.pending} pending changes for this account. Local records were merged.`);
    } catch (cause) {
      setError(true);
      setMessage(cause instanceof Error ? cause.message : 'That backup could not be restored.');
    } finally { setBusy(false); }
  };
  return <div className="fixed inset-0 z-[60] flex items-end justify-center bg-[#14281e]/50 p-0 backdrop-blur-[2px] sm:items-center sm:p-4" onMouseDown={(event) => { if (event.target === event.currentTarget && !busy) onClose(); }}>
    <section className="w-full max-w-[500px] rounded-t-[26px] border border-[#e4dece] bg-[#fffdf7] p-6 shadow-2xl sm:rounded-[26px]">
      <div className="flex items-start justify-between"><div><div className="text-[10px] font-extrabold uppercase tracking-[.17em] text-[#9b7a38]">Your data stays yours</div><h2 className="mt-1 text-xl font-extrabold tracking-[-.04em]">Backup & restore</h2></div><button type="button" aria-label="Close backup dialog" onClick={onClose} disabled={busy} className="rounded-xl p-2 text-[#637369] hover:bg-[#efede4]"><X size={18} /></button></div>
      <p className="mt-3 text-xs leading-5 text-[#718075]">Create a private JSON copy of this account’s local business books, deletion markers and queued sync changes. Restore only accepts a backup created for the currently signed-in account.</p>
      <div className="mt-5 space-y-3">
        <button onClick={() => void downloadBackup()} disabled={busy} className="flex w-full items-center gap-3 rounded-2xl border border-[#e3dece] bg-[#f8f6ee] p-4 text-left hover:border-[#9ab29c] disabled:opacity-50">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-[#e4eee3] text-[#32654b]"><Download size={18} /></span><span className="flex-1"><span className="block text-sm font-extrabold">Download JSON backup</span><span className="mt-1 block text-[10px] text-[#7b887e]">Includes saved records, pending changes and sync cursor.</span></span>
        </button>
        <label className={`flex w-full cursor-pointer items-center gap-3 rounded-2xl border border-[#e3dece] bg-[#f8f6ee] p-4 hover:border-[#9ab29c] ${busy ? 'pointer-events-none opacity-50' : ''}`}>
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-[#f1ead8] text-[#99752f]"><Upload size={18} /></span><span className="flex-1"><span className="block text-sm font-extrabold">Restore from JSON</span><span className="mt-1 block text-[10px] text-[#7b887e]">Validated first, then merged into this account’s local books.</span></span><input type="file" accept=".json,application/json" onChange={restoreFile} className="sr-only" aria-label="Choose SMARTBIZ PRO backup" />
        </label>
      </div>
      {busy && <div className="mt-4 flex items-center gap-2 text-xs font-semibold text-[#526d59]"><RefreshCw size={14} className="animate-spin" />Working with your local backup…</div>}
      {message && <p role={error ? 'alert' : 'status'} className={`mt-4 rounded-xl px-3 py-2.5 text-xs leading-5 ${error ? 'bg-[#fbefeb] text-[#974f42]' : 'bg-[#e8efe5] text-[#32654b]'}`}>{message}</p>}
      <div className="mt-5 flex justify-end"><Button variant="soft" onClick={onClose} disabled={busy}>Done</Button></div>
    </section>
  </div>;
}

function Landing() {
  const { isSignedIn, isLoaded } = useAuth();
  if (isLoaded && isSignedIn) return <Redirect to="/app" />;
  return <div className="min-h-[100dvh] overflow-hidden bg-[#f6f3e9] text-[#20372e]">
    <nav className="mx-auto flex max-w-[1280px] items-center justify-between px-5 py-5 md:px-10"><Brand /><div className="flex items-center gap-2"><Link href="/sign-in" className="rounded-xl px-4 py-2.5 text-xs font-extrabold text-[#456552] hover:bg-[#eae8de]">Sign in</Link><Link href="/sign-up" className="rounded-xl bg-[#245b45] px-4 py-2.5 text-xs font-extrabold text-white hover:bg-[#194633]">Get started <ArrowRight size={14} className="ml-1 inline" /></Link></div></nav>
    <main>
      <section className="relative mx-auto grid max-w-[1280px] items-center gap-8 px-5 pb-16 pt-12 md:grid-cols-[1.12fr_.88fr] md:px-10 md:pb-24 md:pt-20">
        <div className="relative z-10"><div className="inline-flex items-center gap-2 rounded-full border border-[#dcd9c8] bg-[#fffdf7] px-3 py-2 text-[10px] font-extrabold uppercase tracking-[.13em] text-[#527158]"><span className="h-2 w-2 rounded-full bg-[#d5a548]" />Built for the way Malawi does business</div>
          <h1 className="mt-6 max-w-3xl text-[clamp(3.4rem,8vw,6.5rem)] font-extrabold leading-[.94] tracking-[-.085em]">Every venture.<br /><span className="text-[#a87929]">Its own book.</span></h1>
          <p className="mt-6 max-w-xl text-[15px] leading-7 text-[#68786d] md:text-[17px]">One place to keep your farming, timber, motorcycle and mobile money businesses in order. Separate records, a sharper picture, fewer details lost in the day.</p>
          <div className="mt-8 flex flex-wrap gap-3"><Link href="/sign-up" className="inline-flex items-center gap-2 rounded-xl bg-[#245b45] px-5 py-3.5 text-sm font-extrabold text-white shadow-lg shadow-[#245b45]/15 hover:bg-[#194633]">Set up your workspace <ArrowRight size={16} /></Link><Link href="/sign-in" className="inline-flex items-center gap-2 rounded-xl border border-[#dedbcc] bg-[#fffdf7] px-5 py-3.5 text-sm font-extrabold text-[#456552] hover:bg-[#f0eee5]">I already have an account</Link></div>
          <div className="mt-9 flex items-center gap-3 text-[11px] text-[#839086]"><span className="flex -space-x-2"><i className="grid h-7 w-7 place-items-center rounded-full border-2 border-[#f6f3e9] bg-[#d9a84e] not-italic"><Sprout size={13} /></i><i className="grid h-7 w-7 place-items-center rounded-full border-2 border-[#f6f3e9] bg-[#c3d4bd] not-italic"><Boxes size={13} /></i><i className="grid h-7 w-7 place-items-center rounded-full border-2 border-[#f6f3e9] bg-[#d9c4aa] not-italic"><Wallet size={13} /></i></span>Separate books. Clear day-to-day records.</div>
        </div>
        <div className="relative min-h-[400px] md:min-h-[510px]">
          <div className="absolute right-0 top-2 h-[93%] w-[91%] overflow-hidden rounded-[38px] bg-[#dfe8d8]">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_72%_20%,rgba(218,174,79,.44),transparent_32%),linear-gradient(145deg,#d9e5d5,#d0dfcd_42%,#b3c9b8)]" />
            <div className="absolute -right-10 top-14 h-[280px] w-[340px] rotate-[-12deg] rounded-[50%] border-[30px] border-[#7c9d75]/40" />
            <div className="absolute right-[9%] top-[16%] h-[270px] w-[230px] -rotate-6 rounded-[46%_54%_18%_23%] bg-[#748d61] shadow-2xl"><div className="absolute bottom-[-19px] left-[15%] h-[200px] w-3 rotate-[21deg] rounded-full bg-[#927347]" /><div className="absolute bottom-[-14px] right-[8%] h-[200px] w-3 rotate-[-15deg] rounded-full bg-[#927347]" /><div className="absolute left-6 top-12 h-24 w-20 -rotate-12 rounded-[90%_0_90%_0] bg-[#a6ba83]" /><div className="absolute right-4 top-7 h-24 w-20 rotate-[28deg] rounded-[90%_0_90%_0] bg-[#94ae79]" /><div className="absolute bottom-12 left-1/3 h-20 w-16 rotate-[-30deg] rounded-[90%_0_90%_0] bg-[#8ca874]" /></div>
            <div className="absolute bottom-0 left-0 h-[33%] w-full bg-[repeating-linear-gradient(172deg,transparent_0_21px,rgba(71,111,74,.19)_22px_25px)]" />
            <div className="absolute bottom-6 left-7 max-w-[235px] rounded-2xl border border-white/60 bg-[#fffdf7]/90 p-4 shadow-lg backdrop-blur"><div className="text-[9px] font-extrabold uppercase tracking-[.17em] text-[#71836d]">One business book</div><div className="mt-1 text-lg font-extrabold tracking-[-.05em]">Farming business</div><div className="mt-3 text-[10px] text-[#819087]">Income, costs, stock and balances — kept together.</div></div>
          </div>
          <div className="absolute left-0 top-[12%] rounded-2xl border border-[#e7e1d3] bg-[#fffdf7] p-4 shadow-xl"><span className="grid h-9 w-9 place-items-center rounded-xl bg-[#e6efe3] text-[#32654b]"><TrendingUp size={18} /></span><div className="mt-3 text-[10px] text-[#839086]">Entries organized</div><div className="mt-1 text-xl font-extrabold tracking-[-.05em]">By business</div></div>
          <div className="absolute bottom-[17%] right-0 rounded-2xl bg-[#214a39] p-4 text-[#f6f2e7] shadow-xl"><div className="flex items-center gap-2 text-[10px] font-bold text-[#c4d1c2]"><CloudOff size={14} /> Works offline, too</div><div className="mt-2 text-sm font-extrabold">Keep the day moving.</div></div>
        </div>
      </section>
      <section className="border-y border-[#e5dfce] bg-[#efecdf] py-12"><div className="mx-auto max-w-[1280px] px-5 md:px-10"><div className="flex flex-wrap items-end justify-between gap-5"><div><div className="text-[10px] font-extrabold uppercase tracking-[.18em] text-[#a87929]">Your businesses, apart</div><h2 className="mt-2 text-3xl font-extrabold tracking-[-.065em] md:text-4xl">Different work. One steady view.</h2></div><p className="max-w-md text-sm leading-6 text-[#68786d]">Each venture gets its own set of transactions, balances, stock and reports. No accidental mixing.</p></div>
        <div className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">{categories.map((c, i) => <div key={c} className={`rounded-[20px] border border-[#e1dccb] bg-[#fffdf7] p-4 ${i === 0 ? 'xl:-translate-y-2' : i === 4 ? 'xl:translate-y-2' : ''}`}><span className="grid h-10 w-10 place-items-center rounded-xl bg-[#e9efe4] text-[#35694c]"><BusinessTypeIcon category={c} /></span><div className="mt-4 text-xs font-extrabold leading-5">{c}</div><div className="mt-1 text-[10px] text-[#859087]">Separate book</div></div>)}</div>
      </div></section>
      <section className="mx-auto grid max-w-[1280px] gap-12 px-5 py-16 md:grid-cols-2 md:px-10 md:py-24">
        <div><div className="text-[10px] font-extrabold uppercase tracking-[.18em] text-[#a87929]">A practical daily rhythm</div><h2 className="mt-3 text-4xl font-extrabold tracking-[-.07em] md:text-5xl">Know what came in.<br />Know what went out.</h2><p className="mt-5 max-w-md text-sm leading-7 text-[#68786d]">Write down income, costs, outstanding balances and stock movements while they're still easy to remember. Then see the shape of your business over time.</p></div>
        <div className="space-y-3">
          {[['01', 'Record the day', 'Log a payment, purchase, or customer balance in the right business book.'], ['02', 'Keep an eye on stock', 'Track products, quantities and each movement in and out.'], ['03', 'Read the bigger picture', 'Choose a date range and see income, expenses and net position.']].map(([n, title, text]) => <div key={n} className="flex gap-4 rounded-2xl border border-[#e3dece] bg-[#fffdf7] p-5"><span className="mono pt-1 text-xs text-[#a87929]">{n}</span><div><div className="text-sm font-extrabold">{title}</div><p className="mt-1 text-xs leading-5 text-[#758278]">{text}</p></div></div>)}
        </div>
      </section>
      <section className="bg-[#214a39] px-5 py-16 text-[#f5f1e5] md:px-10 md:py-20"><div className="mx-auto flex max-w-[1120px] flex-col items-start justify-between gap-7 md:flex-row md:items-end"><div><div className="text-[10px] font-extrabold uppercase tracking-[.18em] text-[#dfb451]">Take the clutter out of the ledger</div><h2 className="mt-3 max-w-2xl text-4xl font-extrabold tracking-[-.07em] md:text-6xl">Make room to run<br />the business.</h2></div><Link href="/sign-up" className="inline-flex items-center gap-2 rounded-xl bg-[#d9a84e] px-5 py-3.5 text-sm font-extrabold text-[#20372e] hover:bg-[#e5bd69]">Create your account <ArrowRight size={16} /></Link></div></section>
      <footer className="mx-auto flex max-w-[1280px] flex-col justify-between gap-3 px-5 py-6 text-[10px] text-[#839086] sm:flex-row md:px-10"><Brand /><span>SMARTBIZ PRO · Business, in good order.</span></footer>
    </main>
  </div>;
}

function SignInPage() { return <div className="flex min-h-[100dvh] items-center justify-center bg-[#f6f3e9] px-4 py-8"><div className="absolute left-6 top-6"><Link href="/" aria-label="Back to SMARTBIZ PRO home"><Brand /></Link></div><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} /></div>; }
function SignUpPage() { return <div className="flex min-h-[100dvh] items-center justify-center bg-[#f6f3e9] px-4 py-8"><div className="absolute left-6 top-6"><Link href="/" aria-label="Back to SMARTBIZ PRO home"><Brand /></Link></div><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} /></div>; }

function QueryUserReset() {
  const { addListener } = useClerk(); const client = useQueryClient(); const prevUserIdRef = useRef<string | null | undefined>(undefined);
  useEffect(() => { const off = addListener(({ user }) => { const id = user?.id ?? null; if (prevUserIdRef.current !== undefined && prevUserIdRef.current !== id) client.clear(); prevUserIdRef.current = id; }); return off; }, [addListener, client]);
  return null;
}
function AuthenticatedApp() { const { isLoaded, isSignedIn } = useAuth(); return !isLoaded ? <div className="grid min-h-[100dvh] place-items-center bg-[#f6f3e9]"><div className="h-12 w-48 animate-pulse rounded-xl bg-[#e2e3d6]" /></div> : isSignedIn ? <AppShell /> : <Redirect to="/" />; }
function BusinessRoute() {
  const params = useParams<{ businessId: string }>();
  const { isLoaded, isSignedIn } = useAuth();
  if (!isLoaded) return <div className="grid min-h-[100dvh] place-items-center bg-[#f6f3e9]"><div className="h-12 w-48 animate-pulse rounded-xl bg-[#e2e3d6]" /></div>;
  return isSignedIn ? <AppShell routeBusinessId={params.businessId ?? ''} /> : <Redirect to="/" />;
}
function RouterContent() {
  const [, setLocation] = useLocation();
  return <ClerkProvider
    publishableKey={clerkPubKey} proxyUrl={clerkProxyUrl} appearance={appearance}
    signInUrl={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`}
    localization={{ signIn: { start: { title: 'Welcome back', subtitle: 'Pick up where your business left off.' } }, signUp: { start: { title: 'Make a place for every venture', subtitle: 'Your business books start here.' } } }}
    routerPush={(to) => setLocation(stripBase(to))} routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
  >
    <QueryClientProvider client={queryClient}>
      <QueryUserReset />
      <Switch>
        <Route path="/" component={Landing} />
        <Route path="/sign-in/*?" component={SignInPage} />
        <Route path="/sign-up/*?" component={SignUpPage} />
        <Route path="/app" component={AuthenticatedApp} />
        <Route path="/business/:businessId" component={BusinessRoute} />
        <Route component={NotFound} />
      </Switch>
    </QueryClientProvider>
  </ClerkProvider>;
}
function App() {
  return <WouterRouter base={basePath}><RouterContent /></WouterRouter>;
}
export default App;
