import { useEffect, useMemo, useState, type ChangeEvent, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ClerkProvider, SignIn, SignUp, useAuth, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { arSA, enUS, frFR } from '@clerk/localizations';
import {
  Activity, ArrowDownToLine, ArrowLeft, ArrowRight, ArrowUpRight, Bell, CalendarDays,
  Check, CheckCheck, ChevronDown, CircleHelp, FileHeart, FileText, HeartPulse,
  Languages, LogOut, Menu, MessageCircle, Moon, Search, ShieldCheck, Stethoscope,
  Star, Sun, Video, X,
} from 'lucide-react';
import {
  Route, Switch, Link, Redirect, Router as WouterRouter, useLocation, useParams,
} from 'wouter';
import {
  getGetAdminOverviewQueryKey, getGetCurrentUserQueryKey, getGetDocumentDownloadQueryKey,
  getGetMedicalRecordQueryKey, getGetPatientDashboardQueryKey,
  getGetProfessionalDashboardQueryKey, getGetProfessionalQueryKey,
  getListAppointmentsQueryKey, getListConversationsQueryKey,
  getListDocumentsQueryKey, getListMessagesQueryKey, getListNotificationsQueryKey,
  getListPendingProfessionalsQueryKey, getListProfessionalsQueryKey,
  getListReviewsQueryKey, useCancelAppointment, useCreateAppointment,
  useCreateReview, useDeleteDocument, useGetAdminOverview, useGetCurrentUser,
  useGetDocumentDownload, useGetMedicalRecord, useGetPatientDashboard,
  useGetProfessional, useGetProfessionalDashboard, useHealthCheck,
  useListAppointments, useListConversations, useListDocuments, useListMessages,
  useListNotifications, useListPendingProfessionals, useListProfessionals,
  useListReviews, useMarkNotificationRead, useMockCheckout,
  useRegisterDocument, useRequestDocumentUploadUrl, useSaveCurrentProfile,
  useSaveMedicalRecord, useSendMessage, useUpdateProfessionalApproval,
} from '@workspace/api-client-react';
import type {
  Appointment, AppointmentInput, CurrentUser, MedicalDocument, ProfessionalDetail,
  ProfessionalRole, ProfessionalSummary, UserRole,
} from '@workspace/api-client-react';
import { useTranslation } from 'react-i18next';
import './i18n';
import './index.css';

const queryClient = new QueryClient({ defaultOptions: { queries: { retry: 1, refetchOnWindowFocus: false } } });
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

function stripBase(path: string) {
  return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path;
}

function ActionLink({ href, children, className = '', testId }: { href: string; children: ReactNode; className?: string; testId: string }) {
  return <Link href={href} data-testid={testId} className={className}>{children}</Link>;
}

function Brand({ compact = false }: { compact?: boolean }) {
  const { t } = useTranslation();
  return (
    <ActionLink href="/" testId="link-brand-home" className="flex items-center gap-2.5">
      <span className="brand-mark grid h-10 w-10 place-items-center rounded-[14px] text-white shadow-sm"><HeartPulse size={21} strokeWidth={2.3} /></span>
      {!compact && <span><span className="block font-serif text-[21px] font-extrabold leading-none tracking-[-.04em]">{t('brand')}</span><span className="mt-1 block text-[10px] font-semibold tracking-[.1em] text-muted-foreground">{t('tagline')}</span></span>}
    </ActionLink>
  );
}

function LocaleToggle({ light = false }: { light?: boolean }) {
  const { i18n, t } = useTranslation();
  return (
    <label className={`inline-flex items-center gap-2 rounded-xl border px-3 py-2 text-xs font-bold ${light ? 'border-white/25 bg-white/10 text-white' : 'border-border bg-card text-foreground'}`}>
      <Languages size={15} />
      <span className="sr-only">{t('languageSelect')}</span>
      <select aria-label={t('languageSelect')} data-testid="select-language" value={i18n.language.slice(0, 2)} onChange={(event) => void i18n.changeLanguage(event.target.value)} className="cursor-pointer appearance-none bg-transparent outline-none">
        <option value="fr">FR</option><option value="ar">AR</option><option value="en">EN</option>
      </select>
      <ChevronDown size={13} />
    </label>
  );
}

function ThemeToggle() {
  const [dark, setDark] = useState(() => localStorage.getItem('dawalink-theme') === 'dark');
  const { t } = useTranslation();
  useEffect(() => {
    document.documentElement.classList.toggle('dark', dark);
    localStorage.setItem('dawalink-theme', dark ? 'dark' : 'light');
  }, [dark]);
  return <button type="button" aria-label={t('theme')} title={t('theme')} data-testid="button-theme-toggle" onClick={() => setDark((value) => !value)} className="grid h-10 w-10 place-items-center rounded-xl border border-border bg-card text-foreground transition hover:bg-muted">{dark ? <Sun size={17} /> : <Moon size={17} />}</button>;
}

function PublicHeader() {
  const { t } = useTranslation();
  return (
    <header className="relative z-10 mx-auto flex max-w-[1240px] items-center justify-between px-5 py-5 lg:px-9">
      <Brand />
      <nav className="hidden items-center gap-8 text-sm font-semibold text-muted-foreground md:flex" aria-label={t('home')}>
        <ActionLink href="/find-professional" testId="link-find-header" className="transition hover:text-primary">{t('find')}</ActionLink>
        <a href="#how-it-works" data-testid="link-how-it-works" className="transition hover:text-primary">{t('learnMore')}</a>
      </nav>
      <div className="flex items-center gap-2">
        <LocaleToggle /><ThemeToggle />
        <ActionLink href="/sign-in" testId="link-sign-in" className="hidden rounded-xl px-3 py-2.5 text-sm font-bold text-foreground hover:bg-muted sm:inline-flex">{t('signIn')}</ActionLink>
        <ActionLink href="/sign-up" testId="link-sign-up" className="rounded-xl bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground shadow-sm transition hover:-translate-y-0.5">{t('signUp')}</ActionLink>
      </div>
    </header>
  );
}

function HomePage() {
  const { t } = useTranslation();
  const health = useHealthCheck();
  const directory = useListProfessionals();
  return (
    <main className="min-h-[100dvh] overflow-hidden bg-background">
      <div className="relative">
        <div className="pointer-events-none absolute -right-24 top-24 h-[28rem] w-[28rem] rounded-full bg-accent/60 blur-3xl" />
        <PublicHeader />
        <section className="relative mx-auto grid max-w-[1240px] items-center gap-12 px-5 pb-20 pt-12 md:grid-cols-[1.05fr_.95fr] md:pb-28 md:pt-20 lg:px-9">
          <div className="fade-up relative z-[1]">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/15 bg-card px-3.5 py-2 text-xs font-bold text-primary shadow-sm"><ShieldCheck size={15} />{t('heroEyebrow')}</div>
            <h1 className="max-w-[680px] font-serif text-[clamp(2.8rem,6.3vw,5.55rem)] font-extrabold leading-[.99] tracking-[-.065em] text-foreground">{t('heroTitle')}</h1>
            <p className="mt-7 max-w-[570px] text-base leading-7 text-muted-foreground md:text-lg md:leading-8">{t('heroBody')}</p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <ActionLink href="/find-professional" testId="link-find-hero" className="inline-flex items-center gap-3 rounded-2xl bg-primary px-6 py-4 text-sm font-bold text-primary-foreground shadow-[0_12px_26px_-14px_hsl(var(--primary))] transition hover:-translate-y-0.5">{t('start')}<ArrowUpRight size={17} /></ActionLink>
              <ActionLink href="/sign-up" testId="link-create-hero" className="rounded-2xl border border-border bg-card px-5 py-4 text-sm font-bold text-foreground transition hover:bg-muted">{t('signUp')}</ActionLink>
            </div>
            <div className="mt-8 flex items-center gap-3 text-xs font-semibold text-muted-foreground"><span className="flex -space-x-2 rtl:space-x-reverse">{['N', 'A', 'Y'].map((initial, index) => <span key={initial} className={`grid h-8 w-8 place-items-center rounded-full border-2 border-background text-[10px] text-white ${index === 0 ? 'bg-[#337d80]' : index === 1 ? 'bg-[#76a797]' : 'bg-[#d09c68]'}`}>{initial}</span>)}</span>{t('trust')}</div>
            <div className="mt-7 inline-flex items-center gap-2 text-[11px] font-semibold text-muted-foreground" data-testid="status-health"><span className={`h-2 w-2 rounded-full ${health.isError ? 'bg-destructive' : 'bg-[#56aa86]'}`} />{health.isLoading ? t('loading') : health.isError ? t('error') : t('online')}</div>
          </div>
          <div className="relative mx-auto w-full max-w-[500px] py-4 md:py-8">
            <div className="soft-grid absolute inset-3 rotate-3 rounded-[3rem] bg-[#e0eee7] opacity-60" />
            <div className="relative overflow-hidden rounded-[2.3rem] border border-white/70 bg-[#dcece7] p-3 shadow-[0_30px_80px_-32px_rgba(28,88,82,.38)]">
              <div className="relative min-h-[470px] overflow-hidden rounded-[1.8rem] bg-[#bcd8d0] p-7 sm:min-h-[520px]">
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_70%_12%,rgba(255,255,255,.8),transparent_32%),linear-gradient(145deg,#d3e6dd_0%,#a9cfc5_53%,#81b0a6_100%)]" />
                <div className="absolute -right-12 top-16 h-64 w-64 rounded-full border border-white/40 bg-white/15" />
                <div className="absolute -left-20 bottom-[-3rem] h-72 w-72 rounded-full border border-white/30 bg-[#2e7778]/10" />
                <div className="relative flex items-start justify-between">
                  <div className="max-w-[230px] rounded-2xl border border-white/65 bg-white/80 p-4 shadow-lg backdrop-blur">
                    <div className="flex items-center gap-2 text-[11px] font-bold text-primary"><span className="h-2 w-2 rounded-full bg-[#5aac88]" />{t('demoProfile')}</div>
                    <p className="mt-2 font-serif text-xl font-bold tracking-tight">Dr. Lina Benali</p>
                    <p className="mt-1 text-xs text-muted-foreground">{t('cardiology')}</p>
                    <div className="mt-3 flex items-center gap-1 text-xs font-bold text-[#b58240]"><Star size={13} fill="currentColor" /> <span className="text-foreground">4.9</span><span className="font-medium text-muted-foreground">· 87 {t('reviews')}</span></div>
                  </div>
                  <div className="grid h-11 w-11 place-items-center rounded-2xl bg-primary text-white shadow-lg"><Video size={19} /></div>
                </div>
                <div className="absolute bottom-7 left-7 right-7 rounded-[1.65rem] border border-white/65 bg-[#fbfdfb]/90 p-5 shadow-[0_20px_50px_-28px_rgba(11,59,57,.5)] backdrop-blur sm:p-6">
                  <div className="flex items-center justify-between">
                    <div><p className="text-[10px] font-bold uppercase tracking-[.15em] text-muted-foreground">{t('nextAppointment')}</p><p className="mt-2 font-serif text-xl font-bold">{t('exampleAppointment')}</p></div>
                    <div className="grid h-12 w-12 place-items-center rounded-2xl bg-accent text-primary"><CalendarDays size={21} /></div>
                  </div>
                  <div className="mt-5 flex items-center justify-between border-t border-border pt-4">
                    <div className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-full bg-[#dceae1] text-sm font-bold text-primary">LB</span><div><p className="text-sm font-bold">Dr. Lina Benali</p><p className="text-xs text-muted-foreground">{t('video')} · 30 {t('minutes')}</p></div></div>
                    <span className="grid h-9 w-9 place-items-center rounded-xl bg-primary text-primary-foreground"><ArrowRight size={17} /></span>
                  </div>
                </div>
                <div className="absolute bottom-[195px] right-7 rounded-xl bg-white/85 px-3 py-2 text-[11px] font-bold text-primary shadow-lg backdrop-blur"><Check size={13} className="me-1 inline" />{t('secureBadge')}</div>
              </div>
            </div>
          </div>
        </section>
      </div>
      <section className="border-y border-border bg-card/75">
        <div className="mx-auto grid max-w-[1180px] gap-7 px-5 py-9 sm:grid-cols-3 lg:px-9">
          {[{ value: directory.isLoading ? '…' : directory.isError ? '—' : String(directory.data?.length ?? 0), label: 'doctorCount', icon: Stethoscope }, { value: '3', label: 'languages', icon: Languages }, { value: '3', label: 'consultationFormats', icon: Video }].map(({ value, label, icon: Icon }) => <div key={label} className="flex items-center gap-4 sm:justify-center"><div className="grid h-12 w-12 place-items-center rounded-2xl bg-accent text-primary"><Icon size={20} /></div><div><p className="font-serif text-2xl font-extrabold tracking-tight">{value}</p><p className="text-sm text-muted-foreground">{t(label)}</p></div></div>)}
        </div>
      </section>
      <section id="how-it-works" className="mx-auto max-w-[1180px] px-5 py-20 md:py-28 lg:px-9">
        <p className="text-xs font-extrabold uppercase tracking-[.18em] text-primary">{t('tagline')}</p>
        <div className="mt-4 flex flex-col justify-between gap-5 md:flex-row md:items-end"><h2 className="max-w-[600px] font-serif text-4xl font-extrabold leading-[1.05] tracking-[-.05em] sm:text-5xl">{t('howTitle')}</h2><ActionLink href="/find-professional" testId="link-browse-professionals" className="inline-flex items-center gap-2 text-sm font-bold text-primary">{t('browse')}<ArrowUpRight size={16} /></ActionLink></div>
        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {(['stepOne', 'stepTwo', 'stepThree'] as const).map((step, index) => <article key={step} className={`rounded-[1.8rem] border border-border p-7 ${index === 1 ? 'bg-[#e3f0ea] dark:bg-[#18342f]' : 'bg-card'}`}><p className="font-serif text-5xl font-extrabold tracking-[-.06em] text-primary/30">0{index + 1}</p><h3 className="mt-8 font-serif text-xl font-extrabold tracking-tight">{t(step)}</h3><p className="mt-3 text-sm leading-6 text-muted-foreground">{t(`${step}Body`)}</p></article>)}
        </div>
      </section>
      <section className="px-5 pb-20 md:pb-28 lg:px-9">
        <div className="mx-auto flex max-w-[1180px] flex-col justify-between gap-8 overflow-hidden rounded-[2rem] bg-[#174f55] px-7 py-10 text-white md:flex-row md:items-center md:px-14 md:py-14">
          <div><p className="text-xs font-bold uppercase tracking-[.18em] text-[#a8d7c2]">{t('secure')}</p><h2 className="mt-4 max-w-[600px] font-serif text-3xl font-extrabold tracking-[-.04em] md:text-4xl">{t('careTitle')}</h2><p className="mt-3 max-w-[560px] text-sm leading-6 text-white/75">{t('careBody')}</p></div>
          <ActionLink href="/find-professional" testId="link-care-cta" className="inline-flex shrink-0 items-center justify-center gap-2 rounded-2xl bg-[#d3eee0] px-5 py-4 text-sm font-bold text-[#144a4c]">{t('browse')}<ArrowUpRight size={16} /></ActionLink>
        </div>
      </section>
      <footer className="border-t border-border px-5 py-7 text-center text-xs font-semibold text-muted-foreground">{t('footer')}</footer>
    </main>
  );
}

function Guard({ children, admin = false, allowIncomplete = false }: { children: ReactNode; admin?: boolean; allowIncomplete?: boolean }) {
  const { isLoaded, isSignedIn } = useAuth();
  const profile = useGetCurrentUser({ query: { enabled: Boolean(isLoaded && isSignedIn), queryKey: getGetCurrentUserQueryKey() } });
  const user = profile.data;
  const { t } = useTranslation();
  if (!isLoaded) return <div className="grid min-h-[100dvh] place-items-center bg-background"><div className="w-full max-w-md space-y-3 p-8"><div className="skeleton h-10 rounded-xl" /><div className="skeleton h-28 rounded-2xl" /></div></div>;
  if (!isSignedIn) return <Redirect to="/sign-in" />;
  if (!allowIncomplete && profile.error?.status === 404) return <Redirect to="/register" />;
  if (!allowIncomplete && user && user.onboardingComplete === false) return <Redirect to="/register" />;
  if (profile.isLoading) return <div className="grid min-h-[100dvh] place-items-center bg-background"><div className="w-full max-w-md space-y-3 p-8"><div className="skeleton h-10 rounded-xl" /><div className="skeleton h-28 rounded-2xl" /></div></div>;
  if (profile.isError && profile.error.status !== 404) return <ErrorState message={t('error')} retry={() => void profile.refetch()} />;
  if (admin && user?.role !== 'ADMIN') return <Redirect to="/dashboard" />;
  return <>{children}</>;
}

const navItems = [
  { path: '/dashboard', key: 'dashboard', icon: Activity },
  { path: '/find-professional', key: 'find', icon: Search },
  { path: '/appointments', key: 'appointments', icon: CalendarDays },
  { path: '/messages', key: 'messages', icon: MessageCircle },
  { path: '/medical-record', key: 'record', icon: FileHeart },
  { path: '/documents', key: 'documents', icon: FileText },
  { path: '/notifications', key: 'notifications', icon: Bell },
];

function PortalLayout({ children, user }: { children: ReactNode; user?: CurrentUser }) {
  const { t } = useTranslation();
  const { signOut } = useClerk();
  const [mobileMenu, setMobileMenu] = useState(false);
  const [location] = useLocation();
  const isAdmin = user?.role === 'ADMIN';
  return (
    <div className="min-h-[100dvh] bg-background md:flex">
      <aside className={`fixed inset-y-0 start-0 z-30 flex w-[270px] flex-col border-e border-sidebar-border bg-sidebar px-5 py-6 transition-transform md:translate-x-0 ${mobileMenu ? 'translate-x-0' : 'max-md:-translate-x-full rtl:max-md:translate-x-full'}`}>
        <div className="flex items-center justify-between"><Brand /><button type="button" onClick={() => setMobileMenu(false)} aria-label={t('home')} data-testid="button-close-mobile-menu" className="rounded-lg p-2 md:hidden"><X size={18} /></button></div>
        <div className="mt-10"><p className="mb-3 px-3 text-[10px] font-extrabold uppercase tracking-[.17em] text-muted-foreground">{t('dashboard')}</p>
          <nav className="space-y-1" aria-label={t('dashboard')}>
            {navItems.map(({ path, key, icon: Icon }) => <ActionLink key={path} href={path} testId={`link-nav-${key}`} className={`flex items-center gap-3 rounded-xl px-3.5 py-3 text-sm font-semibold transition ${location === path || (path === '/find-professional' && location.startsWith(path)) ? 'bg-primary text-primary-foreground shadow-sm' : 'text-sidebar-foreground/75 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'}`}><Icon size={17} />{t(key)}</ActionLink>)}
            {isAdmin && <ActionLink href="/admin" testId="link-nav-admin" className={`flex items-center gap-3 rounded-xl px-3.5 py-3 text-sm font-semibold ${location === '/admin' ? 'bg-primary text-primary-foreground' : 'text-sidebar-foreground/75 hover:bg-sidebar-accent'}`}><ShieldCheck size={17} />{t('admin')}</ActionLink>}
          </nav>
        </div>
        <div className="mt-auto rounded-2xl bg-[#dcede5] p-4 dark:bg-[#193933]"><div className="grid h-9 w-9 place-items-center rounded-xl bg-white text-primary dark:bg-[#244b44]"><ShieldCheck size={18} /></div><p className="mt-3 text-xs font-bold">{t('secure')}</p><p className="mt-1 text-[11px] leading-5 text-muted-foreground">{t('trust')}</p></div>
        <div className="mt-5 flex items-center gap-3 border-t border-border pt-5"><span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-[#d4e8df] text-sm font-extrabold text-primary">{user?.fullName.split(' ').map((part) => part[0]).slice(0, 2).join('') || 'DL'}</span><div className="min-w-0 flex-1"><p className="truncate text-sm font-bold">{user?.fullName || t('dashboard')}</p><p className="text-xs capitalize text-muted-foreground">{t((user?.role || 'PATIENT').toLowerCase())}</p></div><button type="button" aria-label={t('signOut')} title={t('signOut')} onClick={() => void signOut({ redirectUrl: basePath || '/' })} data-testid="button-sign-out" className="rounded-lg p-2 text-muted-foreground hover:bg-muted"><LogOut size={16} /></button></div>
      </aside>
      {mobileMenu && <button type="button" aria-label={t('home')} className="fixed inset-0 z-20 bg-foreground/20 md:hidden" onClick={() => setMobileMenu(false)} data-testid="button-menu-overlay" />}
      <div className="min-w-0 flex-1 md:ms-[270px]">
        <header className="sticky top-0 z-10 flex h-[74px] items-center justify-between border-b border-border bg-background/90 px-5 backdrop-blur-xl md:px-8">
          <button type="button" aria-label={t('dashboard')} onClick={() => setMobileMenu(true)} data-testid="button-open-mobile-menu" className="grid h-10 w-10 place-items-center rounded-xl border border-border md:hidden"><Menu size={18} /></button>
          <div className="hidden text-xs font-semibold text-muted-foreground md:block"><span className="text-primary">{t('brand')}</span><span className="mx-2">/</span>{t(navItems.find((item) => item.path === location)?.key || (location === '/admin' ? 'admin' : 'dashboard'))}</div>
          <div className="ms-auto flex items-center gap-2"><LocaleToggle /><ThemeToggle /><span className="ms-1 hidden text-sm font-semibold sm:block">{user?.fullName}</span></div>
        </header>
        <main className="mx-auto max-w-[1440px] px-5 py-8 md:px-8 md:py-10">{children}</main>
      </div>
    </div>
  );
}

function Portal({ children, publicPage = false, allowMissingUser = false }: { children: (user?: CurrentUser) => ReactNode; publicPage?: boolean; allowMissingUser?: boolean }) {
  const { isLoaded, isSignedIn } = useAuth();
  const current = useGetCurrentUser({ query: { enabled: Boolean(isLoaded && isSignedIn), queryKey: getGetCurrentUserQueryKey() } });
  const { t } = useTranslation();
  const page = children(current.data);
  if (publicPage) return <div className="min-h-[100dvh] bg-background"><PublicHeader /><main className="mx-auto max-w-[1240px] px-5 py-8 md:px-9 md:py-10">{page}</main></div>;
  if (allowMissingUser && current.error?.status === 404) return <PortalLayout user={current.data}>{page}</PortalLayout>;
  if (allowMissingUser && current.isError) return <PortalLayout user={current.data}><ErrorState message={t('error')} retry={() => void current.refetch()} /></PortalLayout>;
  return <PortalLayout user={current.data}>{current.isLoading ? <LoadingPage /> : current.isError ? <ErrorState message={t('error')} retry={() => void current.refetch()} /> : page}</PortalLayout>;
}

function LoadingPage() {
  const { t } = useTranslation();
  return <div className="mx-auto max-w-5xl space-y-5 py-10" aria-label={t('loading')}><div className="skeleton h-9 w-48 rounded-xl" /><div className="grid gap-4 sm:grid-cols-3"><div className="skeleton h-32 rounded-2xl" /><div className="skeleton h-32 rounded-2xl" /><div className="skeleton h-32 rounded-2xl" /></div><div className="skeleton h-64 rounded-2xl" /></div>;
}

function ErrorState({ message, retry }: { message: string; retry: () => void }) {
  const { t } = useTranslation();
  return <div className="rounded-2xl border border-destructive/25 bg-destructive/5 p-6 text-center" role="alert" data-testid="status-error"><CircleHelp className="mx-auto text-destructive" /><p className="mt-3 text-sm font-semibold">{message}</p><button type="button" onClick={retry} data-testid="button-retry" className="mt-4 rounded-lg bg-primary px-4 py-2 text-sm font-bold text-primary-foreground">{t('retry')}</button></div>;
}

function EmptyState({ title, body }: { title: string; body: string }) {
  return <div className="rounded-2xl border border-dashed border-border bg-card/70 px-6 py-12 text-center" data-testid="state-empty"><div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-accent text-primary"><FileHeart size={20} /></div><p className="mt-4 font-bold">{title}</p><p className="mt-1 text-sm text-muted-foreground">{body}</p></div>;
}

function PageHeading({ eyebrow, title, detail }: { eyebrow?: string; title: string; detail?: string }) {
  return <div className="mb-7"><p className="text-[10px] font-extrabold uppercase tracking-[.18em] text-primary">{eyebrow || 'صحتي'}</p><h1 className="mt-2 font-serif text-3xl font-extrabold tracking-[-.045em] sm:text-4xl" data-testid="text-page-title">{title}</h1>{detail && <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">{detail}</p>}</div>;
}

function DashboardPage() {
  const { t } = useTranslation();
  const current = useGetCurrentUser({ query: { queryKey: getGetCurrentUserQueryKey() } });
  const user = current.data;
  const isPro = Boolean(user && user.role !== 'PATIENT' && user.role !== 'ADMIN');
  const patient = useGetPatientDashboard({ query: { enabled: user?.role === 'PATIENT', queryKey: getGetPatientDashboardQueryKey() } });
  const professional = useGetProfessionalDashboard({ query: { enabled: isPro, queryKey: getGetProfessionalDashboardQueryKey() } });
  const data = isPro ? professional.data : patient.data;
  const loading = isPro ? professional.isLoading : patient.isLoading;
  const failed = isPro ? professional.isError : patient.isError;
  const retry = isPro ? professional.refetch : patient.refetch;
  const appointments = data?.appointments ?? [];
  const upcomingCount = data?.upcomingCount ?? 0;
  const completedCount = isPro ? professional.data?.appointments.filter((item) => item.status === 'COMPLETED').length ?? 0 : patient.data?.completedCount ?? 0;
  const unreadMessages = isPro ? 0 : patient.data?.unreadMessages ?? 0;
  return <Portal>{() => {
    if (loading) return <LoadingPage />;
    if (failed) return <ErrorState message={t('error')} retry={() => void retry()} />;
    return <div className="fade-up">
      <PageHeading eyebrow={t('dashboard')} title={`${t('welcome')}, ${user?.fullName.split(' ')[0] || ''}`} detail={t('overview')} />
      <div className="grid gap-4 sm:grid-cols-3">
        {[{ label: t('upcoming'), value: upcomingCount, icon: CalendarDays }, { label: t('completed'), value: completedCount, icon: CheckCheck }, { label: t('unread'), value: unreadMessages, icon: MessageCircle }].map(({ label, value, icon: Icon }) => <div key={label} className="rounded-2xl border border-border bg-card p-5"><div className="flex items-center justify-between"><span className="text-xs font-bold text-muted-foreground">{label}</span><span className="grid h-9 w-9 place-items-center rounded-xl bg-accent text-primary"><Icon size={17} /></span></div><p className="mt-4 font-serif text-3xl font-extrabold">{value}</p></div>)}
      </div>
      <section className="mt-7 rounded-[1.7rem] border border-border bg-card p-5 sm:p-7">
        <div className="flex items-center justify-between gap-3"><div><p className="text-xs font-bold text-primary">{t('nextAppointment')}</p><h2 className="mt-1 font-serif text-xl font-extrabold">{appointments.length ? appointments[0].professionalName : t('empty')}</h2></div><ActionLink href="/appointments" testId="link-dashboard-appointments" className="text-xs font-bold text-primary">{t('appointments')}<ArrowRight className="ms-1 inline" size={14} /></ActionLink></div>
        {appointments.length ? <div className="mt-5 divide-y divide-border">{appointments.slice(0, 3).map((appointment) => <AppointmentRow key={appointment.id} appointment={appointment} compact />)}</div> : <div className="mt-5 rounded-xl bg-muted/70 p-5 text-sm text-muted-foreground">{t('emptyHint')}<ActionLink href="/find-professional" testId="link-dashboard-find" className="ms-2 font-bold text-primary">{t('browse')}</ActionLink></div>}
      </section>
      {user?.role === 'ADMIN' && <div className="mt-6 rounded-2xl border border-primary/15 bg-accent/60 p-5"><p className="font-bold">{t('adminTitle')}</p><ActionLink href="/admin" testId="link-admin-overview" className="mt-2 inline-flex text-sm font-bold text-primary">{t('admin')}<ArrowRight className="ms-1" size={15} /></ActionLink></div>}
    </div>;
  }}</Portal>;
}

function ProfessionalCard({ professional }: { professional: ProfessionalSummary }) {
  const { t } = useTranslation();
  const isDemoProfile = professional.id.startsWith('demo-');
  return <article className="flex flex-col rounded-[1.5rem] border border-border bg-card p-5 transition hover:-translate-y-1 hover:shadow-[0_18px_45px_-30px_rgba(24,78,71,.35)]" data-testid={`card-professional-${professional.id}`}>
    <div className="flex items-start gap-4">
      {professional.imageUrl ? <img src={professional.imageUrl} alt={professional.fullName} className="h-[68px] w-[68px] rounded-2xl object-cover" data-testid={`img-professional-${professional.id}`} /> : <div className="grid h-[68px] w-[68px] shrink-0 place-items-center rounded-2xl bg-accent font-serif text-xl font-bold text-primary" data-testid={`img-professional-${professional.id}`}>{professional.fullName.split(' ').map((part) => part[0]).slice(0, 2).join('')}</div>}
      <div className="min-w-0 flex-1"><div className="flex items-center gap-1.5"><h2 className="truncate font-bold">{professional.fullName}</h2>{professional.verificationStatus === 'APPROVED' && !isDemoProfile && <ShieldCheck size={15} className="shrink-0 text-primary" />}</div>{isDemoProfile && <p className="mt-1 text-[10px] font-bold text-primary">{t('demoProfile')}</p>}<p className="mt-1 text-xs text-muted-foreground">{professional.specialty}</p><p className="mt-2 text-[11px] font-semibold text-muted-foreground">{professional.experienceYears} {t('years')}</p></div>
    </div>
    <div className="mt-5 flex items-center justify-between border-t border-border pt-4"><span className="flex items-center gap-1 text-xs font-bold text-[#ad7a35]"><Star size={13} fill="currentColor" />{professional.rating.toFixed(1)} <span className="font-medium text-muted-foreground">({professional.reviewCount} {t('reviews')})</span></span><span className="text-sm font-extrabold">{professional.consultationPrice.toLocaleString()} {professional.currency}</span></div>
    <div className="mt-3 flex min-h-6 flex-wrap gap-1.5">{professional.languages.slice(0, 3).map((language) => <span key={language} className="rounded-md bg-muted px-2 py-1 text-[10px] font-bold text-muted-foreground">{language}</span>)}</div>
    <div className="mt-auto flex gap-2 pt-5"><ActionLink href={`/professionals/${professional.id}`} testId={`link-profile-${professional.id}`} className="flex-1 rounded-xl border border-border px-3 py-2.5 text-center text-xs font-bold transition hover:bg-muted">{t('profile')}</ActionLink><ActionLink href={`/professionals/${professional.id}`} testId={`link-book-${professional.id}`} className="flex-1 rounded-xl bg-primary px-3 py-2.5 text-center text-xs font-bold text-primary-foreground">{t('book')}</ActionLink></div>
  </article>;
}

function FindProfessionalPage() {
  const { t } = useTranslation();
  const [query, setQuery] = useState('');
  const [specialty, setSpecialty] = useState('');
  const [role, setRole] = useState('');
  const [language, setLanguage] = useState('');
  const [rating, setRating] = useState('');
  const params = useMemo(() => ({ query: query || undefined, specialty: specialty || undefined, role: role ? role as ProfessionalRole : undefined, language: language || undefined, minRating: rating ? Number(rating) : undefined }), [query, specialty, role, language, rating]);
  const list = useListProfessionals(params);
  const professionals = list.data ?? [];
  return <Portal publicPage>{() => <div className="fade-up">
    <PageHeading eyebrow={t('find')} title={t('searchTitle')} detail={t('heroBody')} />
    <form onSubmit={(event) => event.preventDefault()} className="mb-7 rounded-[1.5rem] border border-border bg-card p-4 sm:p-5">
      <div className="relative"><Search className="absolute start-4 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={t('searchPlaceholder')} data-testid="input-professional-search" className="h-12 w-full rounded-xl border border-input bg-background ps-11 pe-4 text-sm outline-none transition focus:ring-2 focus:ring-ring" /></div>
      <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <label className="text-[11px] font-bold text-muted-foreground">{t('specialty')}<input value={specialty} onChange={(event) => setSpecialty(event.target.value)} placeholder={t('allSpecialties')} data-testid="input-specialty-filter" className="mt-1.5 h-10 w-full rounded-lg border border-input bg-background px-3 text-sm font-medium text-foreground outline-none focus:ring-2 focus:ring-ring" /></label>
        <label className="text-[11px] font-bold text-muted-foreground">{t('role')}<select value={role} onChange={(event) => setRole(event.target.value)} data-testid="select-role-filter" className="mt-1.5 h-10 w-full rounded-lg border border-input bg-background px-3 text-sm font-medium text-foreground outline-none"><option value="">{t('allRoles')}</option><option value="DOCTOR">{t('doctor')}</option><option value="NURSE">{t('nurse')}</option><option value="SPECIALIST">{t('specialist')}</option></select></label>
        <label className="text-[11px] font-bold text-muted-foreground">{t('language')}<select value={language} onChange={(event) => setLanguage(event.target.value)} data-testid="select-language-filter" className="mt-1.5 h-10 w-full rounded-lg border border-input bg-background px-3 text-sm font-medium text-foreground outline-none"><option value="">{t('allLanguages')}</option><option value="fr">Français</option><option value="ar">العربية</option><option value="en">English</option></select></label>
        <label className="text-[11px] font-bold text-muted-foreground">{t('rating')}<select value={rating} onChange={(event) => setRating(event.target.value)} data-testid="select-rating-filter" className="mt-1.5 h-10 w-full rounded-lg border border-input bg-background px-3 text-sm font-medium text-foreground outline-none"><option value="">—</option><option value="3">3+</option><option value="4">4+</option><option value="4.5">4.5+</option></select></label>
      </div>
      <div className="mt-4 flex justify-end"><button type="button" onClick={() => { setQuery(''); setSpecialty(''); setRole(''); setLanguage(''); setRating(''); }} data-testid="button-clear-filters" className="rounded-lg px-3 py-2 text-xs font-bold text-primary hover:bg-accent">{t('clearFilters')}</button></div>
    </form>
    {list.isLoading ? <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{[1, 2, 3].map((item) => <div key={item} className="skeleton h-60 rounded-3xl" />)}</div> : list.isError ? <ErrorState message={t('error')} retry={() => void list.refetch()} /> : professionals.length ? <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{professionals.map((professional) => <ProfessionalCard key={professional.id} professional={professional} />)}</div> : <EmptyState title={t('empty')} body={t('emptyHint')} />}
  </div>}</Portal>;
}

function BookingForm({ professional }: { professional: ProfessionalDetail }) {
  const { t } = useTranslation();
  const { isSignedIn } = useAuth();
  const cache = useQueryClient();
  const mutation = useCreateAppointment();
  const [slot, setSlot] = useState('');
  const [type, setType] = useState<'VIDEO' | 'AUDIO' | 'CHAT'>('VIDEO');
  const [duration, setDuration] = useState<20 | 30>(30);
  const [notes, setNotes] = useState('');
  const [success, setSuccess] = useState(false);
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!slot) return;
    const input: AppointmentInput = { professionalId: professional.id, startsAt: new Date(slot).toISOString(), durationMinutes: duration, consultationType: type, notes, currency: professional.currency };
    mutation.mutate({ data: input }, { onSuccess: () => { setSuccess(true); void cache.invalidateQueries({ queryKey: getListAppointmentsQueryKey() }); } });
  };
  return <form onSubmit={submit} className="rounded-[1.5rem] border border-border bg-card p-5 sm:p-6">
    <h2 className="font-serif text-xl font-extrabold">{t('book')} · {professional.consultationPrice.toLocaleString()} {professional.currency}</h2>
    {success && <p className="mt-3 rounded-lg bg-[#e4f2e9] p-3 text-sm font-bold text-[#256451]" role="status" data-testid="status-booking-success">{t('bookingSuccess')}</p>}
    {mutation.isError && <p role="alert" className="mt-3 text-sm text-destructive" data-testid="status-booking-error">{t('error')}</p>}
    <label className="mt-4 block text-xs font-bold">{t('availability')}{professional.slots?.length ? <select value={slot} onChange={(event) => setSlot(event.target.value)} data-testid="select-booking-slot" required className="mt-1.5 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring"><option value="">{t('choose')}</option>{professional.slots.map((availableSlot) => <option key={availableSlot.startsAt} value={availableSlot.startsAt}>{new Date(availableSlot.startsAt).toLocaleString()} · {availableSlot.durationMinutes} {t('minutes')}</option>)}</select> : <input type="datetime-local" value={slot} onChange={(event) => setSlot(event.target.value)} data-testid="input-booking-slot" required className="mt-1.5 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring" />}</label>
    <div className="mt-4 grid grid-cols-2 gap-3"><label className="text-xs font-bold">{t('consultationType')}<select value={type} onChange={(event) => setType(event.target.value as typeof type)} data-testid="select-consultation-type" className="mt-1.5 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm"><option value="VIDEO">{t('video')}</option><option value="AUDIO">{t('audio')}</option><option value="CHAT">{t('chat')}</option></select></label><label className="text-xs font-bold">{t('duration')}<select value={duration} onChange={(event) => setDuration(Number(event.target.value) as typeof duration)} data-testid="select-consultation-duration" className="mt-1.5 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm">{[20, 30].map((minute) => <option key={minute} value={minute}>{minute} {t('minutes')}</option>)}</select></label></div>
    <label className="mt-4 block text-xs font-bold">{t('notes')}<textarea value={notes} onChange={(event) => setNotes(event.target.value)} placeholder={t('notesPlaceholder')} data-testid="input-booking-notes" rows={3} className="mt-1.5 w-full resize-y rounded-xl border border-input bg-background p-3 text-sm outline-none focus:ring-2 focus:ring-ring" /></label>
     {isSignedIn ? <button disabled={mutation.isPending} type="submit" data-testid="button-confirm-booking" className="mt-4 w-full rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground disabled:opacity-60">{mutation.isPending ? t('loading') : t('confirmBooking')}</button> : <ActionLink href="/sign-in" testId="link-sign-in-to-book" className="mt-4 block w-full rounded-xl bg-primary px-4 py-3 text-center text-sm font-bold text-primary-foreground">{t('signInToBook')}</ActionLink>}
  </form>;
}

function ProfessionalProfilePage() {
  const { professionalId } = useParams<{ professionalId: string }>();
  const { t } = useTranslation();
  const professionalQuery = useGetProfessional(professionalId || '', { query: { queryKey: getGetProfessionalQueryKey(professionalId || ''), enabled: Boolean(professionalId) } });
  const reviewsQuery = useListReviews({ professionalId: professionalId || '' }, { query: { queryKey: getListReviewsQueryKey({ professionalId: professionalId || '' }), enabled: Boolean(professionalId) } });
  const professional = professionalQuery.data;
  return <Portal publicPage>{() => <div>
    {professionalQuery.isLoading ? <LoadingPage /> : professionalQuery.isError || !professional ? <ErrorState message={t('error')} retry={() => void professionalQuery.refetch()} /> : <div className="fade-up">
      <ActionLink href="/find-professional" testId="link-back-to-results" className="mb-5 inline-flex items-center gap-2 text-sm font-bold text-primary"><ArrowLeft size={16} />{t('find')}</ActionLink>
      <div className="grid gap-6 lg:grid-cols-[1fr_370px]">
        <div className="space-y-5">
          <section className="rounded-[1.7rem] border border-border bg-card p-6 sm:p-8">
             <div className="flex flex-col gap-5 sm:flex-row sm:items-center">{professional.imageUrl ? <img src={professional.imageUrl} alt={professional.fullName} className="h-24 w-24 rounded-[1.5rem] object-cover" /> : <span className="grid h-24 w-24 place-items-center rounded-[1.5rem] bg-accent font-serif text-3xl font-bold text-primary">{professional.fullName.split(' ').map((part) => part[0]).slice(0, 2).join('')}</span>}<div><div className="flex flex-wrap items-center gap-2"><h1 className="font-serif text-3xl font-extrabold tracking-tight">{professional.fullName}</h1>{professional.id.startsWith('demo-') ? <span className="rounded-full bg-accent px-2 py-1 text-[10px] font-bold text-primary">{t('demoProfile')}</span> : <ShieldCheck className="text-primary" size={19} />}</div><p className="mt-1 text-sm text-muted-foreground">{professional.specialty} · {t(professional.role.toLowerCase())}</p><p className="mt-2 flex items-center gap-1 text-sm font-semibold text-muted-foreground">{professional.experienceYears} {t('years')} · <Star size={13} className="text-[#ad7a35]" fill="currentColor" /> {professional.rating.toFixed(1)} ({professional.reviewCount} {t('reviews')})</p><p className="mt-1 text-xs text-muted-foreground">{professional.languages.join(' · ')}</p></div></div>
            <div className="mt-7 border-t border-border pt-6"><h2 className="font-serif text-xl font-extrabold">{t('about')}</h2><p className="mt-3 whitespace-pre-line text-sm leading-7 text-muted-foreground">{professional.bio}</p></div>
          </section>
          <div className="grid gap-5 sm:grid-cols-2">
            <section className="rounded-[1.5rem] border border-border bg-card p-5"><h2 className="font-serif text-lg font-extrabold">{t('education')}</h2><ul className="mt-3 space-y-2 text-sm text-muted-foreground">{professional.education.map((item) => <li key={item} className="flex gap-2"><Check size={15} className="mt-0.5 shrink-0 text-primary" />{item}</li>)}</ul></section>
            <section className="rounded-[1.5rem] border border-border bg-card p-5"><h2 className="font-serif text-lg font-extrabold">{t('certifications')}</h2><ul className="mt-3 space-y-2 text-sm text-muted-foreground">{professional.certifications.map((item) => <li key={item} className="flex gap-2"><ShieldCheck size={15} className="mt-0.5 shrink-0 text-primary" />{item}</li>)}</ul></section>
          </div>
          <section className="rounded-[1.5rem] border border-border bg-card p-5 sm:p-6"><div className="flex items-center justify-between"><h2 className="font-serif text-xl font-extrabold">{t('reviews')}</h2><span className="flex items-center gap-1 font-bold text-[#ad7a35]"><Star size={13} fill="currentColor" />{professional.rating.toFixed(1)}</span></div>{reviewsQuery.isLoading ? <div className="skeleton mt-5 h-24 rounded-xl" /> : reviewsQuery.isError ? <p className="mt-4 text-sm text-muted-foreground">{t('error')}</p> : reviewsQuery.data?.length ? <div className="mt-4 divide-y divide-border">{reviewsQuery.data.map((review) => <article key={review.id} className="py-4" data-testid={`review-${review.id}`}><p className="flex items-center gap-2 text-sm font-bold">{review.patientName} <span className="flex items-center gap-1 text-[#ad7a35]"><Star size={12} fill="currentColor" />{review.rating}</span></p><p className="mt-2 text-sm leading-6 text-muted-foreground">{review.comment}</p></article>)}</div> : <p className="mt-4 text-sm text-muted-foreground">{t('empty')}</p>}</section>
        </div>
        <div className="lg:sticky lg:top-24 lg:self-start"><BookingForm professional={professional} /></div>
      </div>
    </div>}
  </div>}</Portal>;
}

function AppointmentRow({ appointment, compact = false }: { appointment: Appointment; compact?: boolean }) {
  const { t } = useTranslation();
  const cancel = useCancelAppointment();
  const checkout = useMockCheckout();
  const cache = useQueryClient();
  const [message, setMessage] = useState('');
  const date = new Date(appointment.startsAt);
  return <div className="flex flex-col gap-4 py-4 sm:flex-row sm:items-center" data-testid={`row-appointment-${appointment.id}`}>
    <div className="flex min-w-0 flex-1 items-center gap-3">
      <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-accent text-primary"><CalendarDays size={19} /></div>
      <div className="min-w-0"><p className="truncate text-sm font-bold">{appointment.professionalName}</p><p className="mt-1 text-xs text-muted-foreground">{date.toLocaleDateString()} · {date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} · {appointment.durationMinutes} {t('minutes')}</p><p className="mt-1 text-[11px] text-muted-foreground">{t(appointment.consultationType.toLowerCase())} · {appointment.amount.toLocaleString()} {appointment.currency}</p></div>
    </div>
    <div className="flex flex-wrap items-center gap-2">
      <span data-testid={`status-appointment-${appointment.id}`} className={`rounded-full px-3 py-1.5 text-[10px] font-extrabold ${appointment.status === 'CANCELLED' ? 'bg-muted text-muted-foreground' : appointment.status === 'COMPLETED' ? 'bg-[#e6f2e9] text-[#327354]' : 'bg-accent text-primary'}`}>{t(`status_${appointment.status}`)}</span>
      {!compact && appointment.status === 'CONFIRMED' && <ActionLink href={`/consultation/${appointment.appointmentId}`} testId={`link-consultation-${appointment.id}`} className="rounded-lg bg-primary px-3 py-2 text-xs font-bold text-primary-foreground">{t('join')}</ActionLink>}
      {!compact && appointment.status === 'PENDING' && appointment.paymentStatus === 'PENDING' && <button type="button" disabled={checkout.isPending} onClick={() => checkout.mutate({ data: { appointmentId: appointment.appointmentId, currency: appointment.currency } }, { onSuccess: () => { setMessage(t('paymentSuccess')); void cache.invalidateQueries({ queryKey: getListAppointmentsQueryKey() }); } })} data-testid={`button-pay-${appointment.id}`} className="rounded-lg bg-primary px-3 py-2 text-xs font-bold text-primary-foreground">{t('pay')}</button>}
      {!compact && ['PENDING', 'CONFIRMED'].includes(appointment.status) && <button type="button" disabled={cancel.isPending} onClick={() => { if (window.confirm(t('cancelConfirm'))) cancel.mutate({ appointmentId: appointment.appointmentId }, { onSuccess: () => void cache.invalidateQueries({ queryKey: getListAppointmentsQueryKey() }) }); }} data-testid={`button-cancel-${appointment.id}`} className="rounded-lg border border-border px-3 py-2 text-xs font-bold text-muted-foreground">{t('cancel')}</button>}
    </div>
    {message && <span role="status" className="text-xs font-bold text-primary" data-testid={`status-payment-${appointment.id}`}>{message}</span>}
    {(cancel.isError || checkout.isError) && <span role="alert" className="text-xs text-destructive" data-testid={`status-appointment-error-${appointment.id}`}>{t('error')}</span>}
  </div>;
}

function AppointmentsPage() {
  const { t } = useTranslation();
  const list = useListAppointments();
  const [ratingById, setRatingById] = useState<Record<string, number>>({});
  const review = useCreateReview();
  const cache = useQueryClient();
  return <Portal>{() => <div>
    <PageHeading eyebrow={t('dashboard')} title={t('appointmentList')} />
    {list.isLoading ? <LoadingPage /> : list.isError ? <ErrorState message={t('error')} retry={() => void list.refetch()} /> : list.data?.length ? <div className="rounded-[1.5rem] border border-border bg-card px-5 sm:px-7">
      {list.data.map((appointment) => <div key={appointment.id}><AppointmentRow appointment={appointment} />{appointment.status === 'COMPLETED' && <form className="mb-4 flex flex-wrap items-center gap-2 rounded-xl bg-muted/70 p-3" onSubmit={(event) => { event.preventDefault(); review.mutate({ data: { appointmentId: appointment.appointmentId, rating: ratingById[appointment.id] || 5 } }, { onSuccess: () => { void cache.invalidateQueries({ queryKey: getListReviewsQueryKey({ professionalId: appointment.professionalId }) }); setRatingById((old) => ({ ...old, [appointment.id]: 0 })); } }); }}><span className="text-xs font-bold">{t('reviews')}</span><select aria-label={t('rating')} value={ratingById[appointment.id] || 5} onChange={(event) => setRatingById((old) => ({ ...old, [appointment.id]: Number(event.target.value) }))} data-testid={`select-review-rating-${appointment.id}`} className="h-8 rounded-lg border border-input bg-background px-2 text-xs">{[5, 4, 3, 2, 1].map((number) => <option key={number} value={number}>{number} / 5</option>)}</select><button type="submit" data-testid={`button-submit-review-${appointment.id}`} className="rounded-lg bg-primary px-3 py-2 text-xs font-bold text-primary-foreground">{t('send')}</button>{review.isError && <span role="alert" className="text-xs text-destructive">{t('error')}</span>}</form>}</div>)}
    </div> : <EmptyState title={t('empty')} body={t('emptyHint')} />}
  </div>}</Portal>;
}

function MessagesPage() {
  const { t } = useTranslation();
  const conversations = useListConversations();
  const [activeId, setActiveId] = useState('');
  const [content, setContent] = useState('');
  const cache = useQueryClient();
  const list = conversations.data ?? [];
  const currentId = list.some((conversation) => conversation.id === activeId) ? activeId : list[0]?.id || '';
  const messages = useListMessages(currentId, { query: { enabled: Boolean(currentId), queryKey: getListMessagesQueryKey(currentId) } });
  const send = useSendMessage();
  const active = list.find((conversation) => conversation.id === currentId);
  const submit = (event: FormEvent) => { event.preventDefault(); if (!content.trim() || !currentId) return; send.mutate({ conversationId: currentId, data: { content: content.trim() } }, { onSuccess: () => { setContent(''); void cache.invalidateQueries({ queryKey: getListMessagesQueryKey(currentId) }); void cache.invalidateQueries({ queryKey: getListConversationsQueryKey() }); } }); };
  return <Portal>{() => <div>
    <PageHeading eyebrow={t('dashboard')} title={t('messages')} />
    {conversations.isLoading ? <LoadingPage /> : conversations.isError ? <ErrorState message={t('error')} retry={() => void conversations.refetch()} /> : list.length === 0 ? <EmptyState title={t('noConversations')} body={t('allMessages')} /> :
      <section className="grid min-h-[570px] overflow-hidden rounded-[1.5rem] border border-border bg-card md:grid-cols-[280px_1fr]">
        <aside className="border-b border-border md:border-b-0 md:border-e"><div className="border-b border-border p-4"><p className="text-xs font-bold text-muted-foreground">{t('conversation')}</p></div>{list.map((conversation) => <button type="button" key={conversation.id} onClick={() => setActiveId(conversation.id)} data-testid={`button-conversation-${conversation.id}`} className={`flex w-full items-center gap-3 border-b border-border/70 p-4 text-start transition ${currentId === conversation.id ? 'bg-accent/60' : 'hover:bg-muted/50'}`}><span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-[#dcebe2] text-xs font-extrabold text-primary">{conversation.counterpartName.split(' ').map((part) => part[0]).slice(0, 2).join('')}</span><span className="min-w-0 flex-1"><span className="block truncate text-sm font-bold">{conversation.counterpartName}</span><span className="mt-1 block truncate text-xs text-muted-foreground">{conversation.lastMessage || t('conversation')}</span></span>{conversation.unreadCount > 0 && <span className="grid h-5 min-w-5 place-items-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">{conversation.unreadCount}</span>}</button>)}</aside>
        <div className="flex min-h-[460px] flex-col"><div className="flex items-center gap-3 border-b border-border p-4"><span className="grid h-9 w-9 place-items-center rounded-full bg-accent text-xs font-extrabold text-primary">{active?.counterpartName.split(' ').map((part) => part[0]).slice(0, 2).join('')}</span><div><p className="text-sm font-bold">{active?.counterpartName}</p><p className="text-[11px] capitalize text-muted-foreground">{t((active?.counterpartRole || 'DOCTOR').toLowerCase())}</p></div></div>
          <div className="flex flex-1 flex-col gap-3 overflow-y-auto p-5">{messages.isLoading ? <div className="space-y-3"><div className="skeleton h-14 w-2/3 rounded-2xl" /><div className="skeleton ms-auto h-14 w-1/2 rounded-2xl" /></div> : messages.isError ? <p className="text-sm text-destructive">{t('error')}</p> : messages.data?.length ? messages.data.map((message) => <div key={message.id} className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-6 ${message.senderId === active?.counterpartId ? 'self-start rounded-es-sm bg-muted' : 'self-end rounded-ee-sm bg-primary text-primary-foreground'}`} data-testid={`message-${message.id}`}><p>{message.content}</p><p className="mt-1 text-[10px] opacity-65">{new Date(message.sentAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p></div>) : <p className="m-auto text-sm text-muted-foreground">{t('empty')}</p>}</div>
          <form onSubmit={submit} className="flex gap-2 border-t border-border p-4"><input value={content} onChange={(event) => setContent(event.target.value)} placeholder={t('writeMessage')} data-testid="input-message" className="h-11 min-w-0 flex-1 rounded-xl border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring" /><button type="submit" disabled={!content.trim() || send.isPending} data-testid="button-send-message" className="rounded-xl bg-primary px-4 text-sm font-bold text-primary-foreground disabled:opacity-50">{t('send')}</button></form>
          {send.isError && <p role="alert" className="px-4 pb-3 text-xs text-destructive">{t('error')}</p>}
        </div>
      </section>}
  </div>}</Portal>;
}

function MedicalRecordPage() {
  const { t } = useTranslation();
  const recordQuery = useGetMedicalRecord();
  const save = useSaveMedicalRecord();
  const cache = useQueryClient();
  const [values, setValues] = useState({ allergies: '', medicalHistory: '', medications: '', notes: '' });
  const [initialized, setInitialized] = useState(false);
  useEffect(() => { if (recordQuery.data && !initialized) { setValues({ allergies: recordQuery.data.allergies || '', medicalHistory: recordQuery.data.medicalHistory || '', medications: recordQuery.data.medications || '', notes: recordQuery.data.notes || '' }); setInitialized(true); } }, [recordQuery.data, initialized]);
  const fields: (keyof typeof values)[] = ['allergies', 'medicalHistory', 'medications', 'notes'];
  const labels: Record<string, string> = { allergies: 'allergies', medicalHistory: 'medicalHistory', medications: 'medications', notes: 'privateNotes' };
  return <Portal>{() => <div>
    <PageHeading eyebrow={t('secure')} title={t('record')} detail={t('careBody')} />
    {recordQuery.isLoading ? <LoadingPage /> : recordQuery.isError ? <ErrorState message={t('error')} retry={() => void recordQuery.refetch()} /> :
      <form onSubmit={(event) => { event.preventDefault(); save.mutate({ data: values }, { onSuccess: () => void cache.invalidateQueries({ queryKey: getGetMedicalRecordQueryKey() }) }); }} className="max-w-3xl rounded-[1.5rem] border border-border bg-card p-5 sm:p-7">
        <div className="mb-5 flex items-center gap-3 rounded-xl bg-accent/70 p-4 text-sm font-semibold text-primary"><ShieldCheck size={18} />{t('secure')}</div>
        <div className="grid gap-4 sm:grid-cols-2">{fields.map((field) => <label key={field} className="text-xs font-bold">{t(labels[field])}<textarea value={values[field]} onChange={(event) => setValues((old) => ({ ...old, [field]: event.target.value }))} rows={field === 'medicalHistory' || field === 'notes' ? 5 : 3} data-testid={`input-record-${field}`} className="mt-1.5 w-full resize-y rounded-xl border border-input bg-background p-3 text-sm font-normal outline-none focus:ring-2 focus:ring-ring" /></label>)}</div>
        {save.isSuccess && <p role="status" className="mt-4 text-sm font-bold text-primary" data-testid="status-record-saved">{t('saved')}</p>}{save.isError && <p role="alert" className="mt-4 text-sm text-destructive">{t('error')}</p>}
        <button type="submit" disabled={save.isPending} data-testid="button-save-record" className="mt-5 rounded-xl bg-primary px-5 py-3 text-sm font-bold text-primary-foreground">{save.isPending ? t('loading') : t('saveRecord')}</button>
      </form>}
  </div>}</Portal>;
}

function DocumentCard({ document, onDelete }: { document: MedicalDocument; onDelete: (document: MedicalDocument) => void }) {
  const { t } = useTranslation();
  const download = useGetDocumentDownload(document.id, { query: { queryKey: getGetDocumentDownloadQueryKey(document.id), enabled: false } });
  const [downloadError, setDownloadError] = useState(false);
  const size = document.size > 1024 * 1024 ? `${(document.size / (1024 * 1024)).toFixed(1)} MB` : `${Math.max(1, Math.round(document.size / 1024))} KB`;
  return <article className="flex flex-col justify-between gap-4 rounded-[1.4rem] border border-border bg-card p-5 sm:flex-row sm:items-center" data-testid={`card-document-${document.id}`}>
    <div className="flex items-center gap-3"><span className="grid h-11 w-11 place-items-center rounded-xl bg-accent text-primary"><FileText size={19} /></span><div><p className="font-bold" data-testid={`text-document-name-${document.id}`}>{document.name}</p><p className="mt-1 text-xs text-muted-foreground">{t(document.documentType)} · {size} · {new Date(document.createdAt).toLocaleDateString()}</p></div></div>
    <div className="flex gap-2"><button type="button" disabled={download.isFetching} onClick={() => { setDownloadError(false); void download.refetch().then((result) => { if (result.data?.downloadUrl) window.open(result.data.downloadUrl, '_blank', 'noopener,noreferrer'); else setDownloadError(true); }).catch(() => setDownloadError(true)); }} data-testid={`button-download-${document.id}`} className="inline-flex items-center gap-2 rounded-lg border border-border px-3 py-2 text-xs font-bold">{download.isFetching ? t('loading') : <><ArrowDownToLine size={14} />{t('download')}</>}</button><button type="button" onClick={() => onDelete(document)} data-testid={`button-delete-document-${document.id}`} className="rounded-lg px-3 py-2 text-xs font-bold text-destructive hover:bg-destructive/10">{t('remove')}</button></div>
    {downloadError && <p role="alert" className="text-xs text-destructive">{t('error')}</p>}
  </article>;
}

function DocumentsPage() {
  const { t } = useTranslation();
  const docs = useListDocuments();
  const askUpload = useRequestDocumentUploadUrl();
  const register = useRegisterDocument();
  const remove = useDeleteDocument();
  const cache = useQueryClient();
  const [documentType, setDocumentType] = useState<'REPORT' | 'PRESCRIPTION' | 'IMAGE' | 'OTHER'>('REPORT');
  const [uploadError, setUploadError] = useState('');
  const [success, setSuccess] = useState(false);
  const onFile = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setUploadError(''); setSuccess(false);
    const validType = ['application/pdf', 'image/jpeg', 'image/png', 'image/webp'].includes(file.type);
    if (!validType || file.size > 10 * 1024 * 1024) { setUploadError(t('error')); return; }
    try {
      const presigned = await askUpload.mutateAsync({ data: { name: file.name, size: file.size, contentType: file.type as 'application/pdf' | 'image/jpeg' | 'image/png' | 'image/webp' } });
      const put = await fetch(presigned.uploadURL, { method: 'PUT', headers: { 'Content-Type': file.type }, body: file });
      if (!put.ok) throw new Error('Private document upload failed');
      await register.mutateAsync({ data: { objectPath: presigned.objectPath, name: file.name, size: file.size, contentType: file.type as 'application/pdf' | 'image/jpeg' | 'image/png' | 'image/webp', documentType } });
      setSuccess(true);
      await cache.invalidateQueries({ queryKey: getListDocumentsQueryKey() });
    } catch { setUploadError(t('error')); }
    event.target.value = '';
  };
  const deleteDocument = (document: MedicalDocument) => { if (window.confirm(t('removeConfirm'))) remove.mutate({ documentId: document.id }, { onSuccess: () => void cache.invalidateQueries({ queryKey: getListDocumentsQueryKey() }) }); };
  return <Portal>{() => <div>
    <PageHeading eyebrow={t('secure')} title={t('documents')} detail={t('secure')} />
    <div className="mb-5 flex flex-col gap-3 rounded-[1.4rem] border border-border bg-card p-4 sm:flex-row sm:items-end sm:justify-between sm:p-5">
      <label className="text-xs font-bold">{t('documentType')}<select value={documentType} onChange={(event) => setDocumentType(event.target.value as typeof documentType)} data-testid="select-document-type" className="mt-1.5 h-10 w-full rounded-lg border border-input bg-background px-3 text-sm sm:w-48">{(['REPORT', 'PRESCRIPTION', 'IMAGE', 'OTHER'] as const).map((type) => <option key={type} value={type}>{t(type)}</option>)}</select></label>
      <label className="inline-flex cursor-pointer items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground">{askUpload.isPending || register.isPending ? t('loading') : <><ArrowUpRight size={16} />{t('upload')}</>}<input type="file" accept=".pdf,.jpg,.jpeg,.png,.webp,application/pdf,image/jpeg,image/png,image/webp" disabled={askUpload.isPending || register.isPending} onChange={(event) => void onFile(event)} data-testid="input-document-upload" className="sr-only" /></label>
    </div>
    <p className="mb-4 text-xs text-muted-foreground">PDF, JPG, PNG, WEBP · 10 MB max. {t('secure')}</p>
    {success && <p role="status" className="mb-4 rounded-xl bg-accent p-3 text-sm font-bold text-primary" data-testid="status-upload-success">{t('saved')}</p>}{uploadError && <p role="alert" className="mb-4 text-sm text-destructive" data-testid="status-upload-error">{uploadError}</p>}
    {docs.isLoading ? <LoadingPage /> : docs.isError ? <ErrorState message={t('error')} retry={() => void docs.refetch()} /> : docs.data?.length ? <div className="space-y-3">{docs.data.map((document) => <DocumentCard key={document.id} document={document} onDelete={deleteDocument} />)}</div> : <EmptyState title={t('empty')} body={t('emptyHint')} />}
    {remove.isError && <p role="alert" className="mt-3 text-sm text-destructive">{t('error')}</p>}
  </div>}</Portal>;
}

function NotificationsPage() {
  const { t } = useTranslation();
  const list = useListNotifications();
  const mark = useMarkNotificationRead();
  const cache = useQueryClient();
  const notifications = list.data ?? [];
  const markRead = (id: string) => mark.mutate({ notificationId: id }, { onSuccess: () => void cache.invalidateQueries({ queryKey: getListNotificationsQueryKey() }) });
  return <Portal>{() => <div>
    <div className="flex flex-wrap items-end justify-between gap-3"><PageHeading eyebrow={t('dashboard')} title={t('notifications')} /><button type="button" disabled={mark.isPending || !notifications.some((item) => !item.isRead)} onClick={() => notifications.filter((item) => !item.isRead).forEach((item) => markRead(item.id))} data-testid="button-mark-all-read" className="mb-7 rounded-xl border border-border bg-card px-4 py-2.5 text-xs font-bold">{t('markAllRead')}</button></div>
    {list.isLoading ? <LoadingPage /> : list.isError ? <ErrorState message={t('error')} retry={() => void list.refetch()} /> : notifications.length ? <div className="divide-y divide-border rounded-[1.5rem] border border-border bg-card px-5">{notifications.map((notification) => <article key={notification.id} className="flex items-start gap-4 py-5" data-testid={`row-notification-${notification.id}`}><span className={`mt-1 grid h-9 w-9 shrink-0 place-items-center rounded-xl ${notification.isRead ? 'bg-muted text-muted-foreground' : 'bg-accent text-primary'}`}><Bell size={17} /></span><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><h2 className="text-sm font-bold">{notification.title}</h2>{!notification.isRead && <span className="h-2 w-2 rounded-full bg-primary" data-testid={`status-unread-${notification.id}`} />}</div><p className="mt-1 text-sm leading-6 text-muted-foreground">{notification.body}</p><p className="mt-2 text-[11px] text-muted-foreground">{new Date(notification.createdAt).toLocaleString()}</p></div>{!notification.isRead && <button type="button" onClick={() => markRead(notification.id)} data-testid={`button-mark-read-${notification.id}`} className="shrink-0 rounded-lg px-3 py-2 text-[11px] font-bold text-primary hover:bg-accent">{t('markRead')}</button>}</article>)}</div> : <EmptyState title={t('empty')} body={t('emptyHint')} />}
  </div>}</Portal>;
}

function ConsultationPage() {
  const { appointmentId } = useParams<{ appointmentId: string }>();
  const { t } = useTranslation();
  const appointments = useListAppointments();
  const [isConnected, setIsConnected] = useState(false);
  const [note, setNote] = useState('');
  const appointment = appointments.data?.find((item) => item.appointmentId === appointmentId || item.id === appointmentId);
  return <Portal>{() => <div>
    <PageHeading eyebrow={t('appointmentList')} title={t('join')} />
    {appointments.isLoading ? <LoadingPage /> : appointments.isError ? <ErrorState message={t('error')} retry={() => void appointments.refetch()} /> : !appointment ? <EmptyState title={t('empty')} body={t('emptyHint')} /> :
      <div className="mx-auto max-w-4xl overflow-hidden rounded-[1.7rem] border border-border bg-card">
        <div className="flex items-center justify-between border-b border-border p-5"><div><p className="font-bold">{appointment.professionalName}</p><p className="mt-1 text-xs text-muted-foreground">{new Date(appointment.startsAt).toLocaleString()} · {appointment.durationMinutes} {t('minutes')}</p></div><span className={`rounded-full px-3 py-1.5 text-xs font-bold ${isConnected ? 'bg-[#e4f2e9] text-[#256451]' : 'bg-accent text-primary'}`}>{isConnected ? t('status_CONFIRMED') : t('consultationType')}</span></div>
        <div className="grid gap-5 p-5 md:grid-cols-[1.4fr_.6fr] md:p-7">
          <div className="flex min-h-[320px] flex-col items-center justify-center rounded-[1.4rem] bg-[#153e43] p-8 text-center text-white"><div className="grid h-24 w-24 place-items-center rounded-full border border-white/20 bg-white/10"><Video size={34} /></div><h2 className="mt-5 font-serif text-2xl font-extrabold">{appointment.professionalName}</h2><p className="mt-2 text-sm text-white/70">{t('brand')} · {t(appointment.consultationType.toLowerCase())}</p><p className="mt-3 text-xs text-white/60">{t('consultationMock')}</p><button type="button" onClick={() => setIsConnected((value) => !value)} data-testid="button-connect-consultation" className="mt-6 rounded-xl bg-[#d3eee0] px-5 py-3 text-sm font-bold text-[#144a4c]">{isConnected ? t('cancel') : t('join')}</button></div>
          <div className="flex flex-col"><div className="flex-1 rounded-[1.4rem] bg-muted/60 p-4"><h3 className="text-sm font-bold">{t('privateNotes')}</h3><p className="mt-2 text-xs leading-5 text-muted-foreground">{t('notesPlaceholder')}</p><textarea value={note} onChange={(event) => setNote(event.target.value)} data-testid="input-consultation-notes" rows={5} className="mt-4 w-full resize-none rounded-xl border border-input bg-background p-3 text-sm outline-none focus:ring-2 focus:ring-ring" /></div><div className="mt-4 flex items-center gap-2 text-xs text-muted-foreground"><ShieldCheck size={15} className="text-primary" />{t('secure')}</div></div>
        </div>
      </div>}
  </div>}</Portal>;
}

function RegisterPage() {
  const { t } = useTranslation();
  const current = useGetCurrentUser({ query: { queryKey: getGetCurrentUserQueryKey() } });
  const save = useSaveCurrentProfile();
  const [, setLocation] = useLocation();
  const [role, setRole] = useState<UserRole>(current.data?.role || 'PATIENT');
  const [fullName, setFullName] = useState(current.data?.fullName || '');
  const [phone, setPhone] = useState(current.data?.phone || '');
  const [birthDate, setBirthDate] = useState(current.data?.birthDate || '');
  const [gender, setGender] = useState(current.data?.gender || '');
  const [specialty, setSpecialty] = useState('');
  const [licenseNumber, setLicenseNumber] = useState('');
  const [experienceYears, setExperienceYears] = useState('0');
  const [bio, setBio] = useState('');
  const [consultationPrice, setConsultationPrice] = useState('0');
  const [currency, setCurrency] = useState<'DZD' | 'EUR' | 'USD'>('DZD');
  const { i18n } = useTranslation();
  useEffect(() => {
    if (current.data) {
      setFullName(current.data.fullName);
      setRole(current.data.role);
      setPhone(current.data.phone || '');
      setBirthDate(current.data.birthDate || '');
      setGender(current.data.gender || '');
    }
  }, [current.data]);
  const isProfessional = ['DOCTOR', 'NURSE', 'SPECIALIST'].includes(role);
  const submit = (event: FormEvent) => {
    event.preventDefault();
    save.mutate({ data: { fullName, role, phone: phone || undefined, birthDate: birthDate || undefined, gender: gender ? gender as 'female' | 'male' | 'other' | 'prefer_not_to_say' : undefined, preferredLanguage: i18n.language.slice(0, 2) as 'ar' | 'fr' | 'en', ...(isProfessional ? { specialty, licenseNumber, experienceYears: Number(experienceYears), bio, consultationPrice: Number(consultationPrice), currency, languages: ['ar', 'fr'] } : {}) } }, { onSuccess: (user) => { void queryClient.invalidateQueries({ queryKey: getGetCurrentUserQueryKey() }); setLocation(user.role === 'ADMIN' ? '/admin' : '/dashboard'); } });
  };
  return <Portal allowMissingUser>{() => <div className="mx-auto max-w-3xl">
    <div className="mb-6 flex items-center justify-between"><Brand /><div className="flex gap-2"><LocaleToggle /><ThemeToggle /></div></div>
    <div className="rounded-[1.7rem] border border-border bg-card p-6 sm:p-9"><PageHeading eyebrow={t('brand')} title={t('registerTitle')} detail={t('careBody')} />
      <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
        <label className="text-xs font-bold sm:col-span-2">{t('role')}<select value={role} onChange={(event) => setRole(event.target.value as UserRole)} data-testid="select-registration-role" className="mt-1.5 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm">{[['PATIENT', 'patient'], ['DOCTOR', 'doctor'], ['NURSE', 'nurse'], ['SPECIALIST', 'specialist']].map(([value, label]) => <option key={value} value={value}>{t(label)}</option>)}</select></label>
        <label className="text-xs font-bold">{t('fullName')}<input value={fullName} onChange={(event) => setFullName(event.target.value)} required minLength={2} data-testid="input-registration-name" className="mt-1.5 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring" /></label>
        <label className="text-xs font-bold">{t('email')}<input value={current.data?.email || ''} readOnly data-testid="input-registration-email" className="mt-1.5 h-11 w-full rounded-xl border border-input bg-muted px-3 text-sm text-muted-foreground" /></label>
        <label className="text-xs font-bold">{t('phone')}<input value={phone} onChange={(event) => setPhone(event.target.value)} data-testid="input-registration-phone" className="mt-1.5 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm" /></label>
        <label className="text-xs font-bold">{t('birthDate')}<input type="date" value={birthDate} onChange={(event) => setBirthDate(event.target.value)} data-testid="input-registration-birthdate" className="mt-1.5 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm" /></label>
        <label className="text-xs font-bold">{t('gender')}<select value={gender} onChange={(event) => setGender(event.target.value)} data-testid="select-registration-gender" className="mt-1.5 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm"><option value="">{t('choose')}</option><option value="female">{t('female')}</option><option value="male">{t('male')}</option><option value="other">{t('other')}</option><option value="prefer_not_to_say">{t('preferNot')}</option></select></label>
        {isProfessional && <><label className="text-xs font-bold">{t('specialty')}<input value={specialty} onChange={(event) => setSpecialty(event.target.value)} required data-testid="input-registration-specialty" className="mt-1.5 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm" /></label><label className="text-xs font-bold">{t('license')}<input value={licenseNumber} onChange={(event) => setLicenseNumber(event.target.value)} required data-testid="input-registration-license" className="mt-1.5 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm" /></label><label className="text-xs font-bold">{t('experience')}<input type="number" min="0" max="80" value={experienceYears} onChange={(event) => setExperienceYears(event.target.value)} data-testid="input-registration-experience" className="mt-1.5 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm" /></label><label className="text-xs font-bold">{t('price')}<input type="number" min="0" value={consultationPrice} onChange={(event) => setConsultationPrice(event.target.value)} data-testid="input-registration-price" className="mt-1.5 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm" /></label><label className="text-xs font-bold">{t('currency')}<select value={currency} onChange={(event) => setCurrency(event.target.value as typeof currency)} data-testid="select-registration-currency" className="mt-1.5 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm"><option value="DZD">DZD · دج</option><option value="EUR">EUR · €</option><option value="USD">USD · $</option></select></label><label className="text-xs font-bold sm:col-span-2">{t('bio')}<textarea value={bio} onChange={(event) => setBio(event.target.value)} rows={4} data-testid="input-registration-bio" className="mt-1.5 w-full rounded-xl border border-input bg-background p-3 text-sm" /></label></>}
        {save.isError && <p className="text-sm text-destructive sm:col-span-2" role="alert" data-testid="status-profile-error">{t('error')}</p>}
        <button type="submit" disabled={save.isPending} data-testid="button-save-profile" className="mt-2 rounded-xl bg-primary px-5 py-3 text-sm font-bold text-primary-foreground sm:col-span-2">{save.isPending ? t('loading') : t('saveProfile')}</button>
      </form>
      {save.isSuccess && <p className="mt-3 text-sm font-bold text-primary" role="status">{t('profileSaved')}</p>}
    </div>
  </div>}</Portal>;
}

function AdminPage() {
  const { t } = useTranslation();
  const overview = useGetAdminOverview();
  const pending = useListPendingProfessionals();
  const approve = useUpdateProfessionalApproval();
  const cache = useQueryClient();
  const approveItem = (professionalId: string, status: 'APPROVED' | 'REJECTED') => approve.mutate({ professionalId, data: { status } }, { onSuccess: () => { void cache.invalidateQueries({ queryKey: getListPendingProfessionalsQueryKey() }); void cache.invalidateQueries({ queryKey: getGetAdminOverviewQueryKey() }); } });
  const overviewData = overview.data;
  return <Portal>{(user) => user?.role !== 'ADMIN' ? <EmptyState title={t('error')} body={t('emptyHint')} /> : <div>
    <PageHeading eyebrow={t('admin')} title={t('adminTitle')} detail={t('pendingProfessionals')} />
    {overview.isLoading ? <LoadingPage /> : overview.isError ? <ErrorState message={t('error')} retry={() => void overview.refetch()} /> : <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{[['users', overviewData?.users], ['patients', overviewData?.patients], ['professionals', overviewData?.professionals], ['pendingProfessionals', overviewData?.pendingProfessionals], ['appointments', overviewData?.appointments], ['revenue', `${overviewData?.revenue?.toLocaleString() || 0} DZD`]].map(([key, value]) => <div key={String(key)} className="rounded-2xl border border-border bg-card p-5" data-testid={`metric-admin-${key}`}><p className="text-xs font-bold text-muted-foreground">{t(String(key))}</p><p className="mt-3 font-serif text-3xl font-extrabold">{value}</p></div>)}</div>}
    <section className="mt-7 rounded-[1.5rem] border border-border bg-card p-5 sm:p-7"><div className="flex items-center justify-between"><h2 className="font-serif text-xl font-extrabold">{t('pendingProfessionals')}</h2><span className="rounded-full bg-accent px-3 py-1 text-xs font-bold text-primary">{pending.data?.length ?? 0}</span></div>
      {pending.isLoading ? <div className="skeleton mt-5 h-32 rounded-2xl" /> : pending.isError ? <div className="mt-5"><ErrorState message={t('error')} retry={() => void pending.refetch()} /></div> : pending.data?.length ? <div className="mt-4 divide-y divide-border">{pending.data.map((person) => <div key={person.id} className="flex flex-col justify-between gap-4 py-5 sm:flex-row sm:items-center" data-testid={`row-pending-professional-${person.id}`}><div className="flex items-center gap-3"><span className="grid h-11 w-11 place-items-center rounded-xl bg-accent font-bold text-primary">{person.fullName.split(' ').map((part) => part[0]).slice(0, 2).join('')}</span><div><p className="font-bold">{person.fullName}</p><p className="mt-1 text-xs text-muted-foreground">{person.specialty} · {t(person.role.toLowerCase())} · {person.experienceYears} {t('years')}</p></div></div><div className="flex gap-2"><button type="button" disabled={approve.isPending} onClick={() => approveItem(person.id, 'APPROVED')} data-testid={`button-approve-${person.id}`} className="rounded-lg bg-primary px-4 py-2.5 text-xs font-bold text-primary-foreground">{t('approve')}</button><button type="button" disabled={approve.isPending} onClick={() => approveItem(person.id, 'REJECTED')} data-testid={`button-reject-${person.id}`} className="rounded-lg border border-border px-4 py-2.5 text-xs font-bold text-destructive">{t('reject')}</button></div></div>)}</div> : <p className="mt-5 text-sm text-muted-foreground">{t('noPending')}</p>}
      {approve.isError && <p role="alert" className="mt-3 text-sm text-destructive">{t('error')}</p>}
    </section>
  </div>}</Portal>;
}

function AuthPage({ kind }: { kind: 'signIn' | 'signUp' }) {
  const { t } = useTranslation();
  const signIn = kind === 'signIn';
  return <main className="relative grid min-h-[100dvh] place-items-center overflow-hidden bg-background px-4 py-10">
    <div className="pointer-events-none absolute -start-32 top-[-6rem] h-[30rem] w-[30rem] rounded-full bg-accent/80 blur-3xl" /><div className="pointer-events-none absolute -end-32 bottom-[-8rem] h-[32rem] w-[32rem] rounded-full bg-[#d8ede4] blur-3xl dark:bg-[#173630]" />
    <div className="absolute inset-x-0 top-0 z-10 mx-auto flex max-w-[1240px] items-center justify-between px-5 py-5"><Brand /><div className="flex gap-2"><LocaleToggle /><ThemeToggle /></div></div>
    <div className="relative z-[1] w-full max-w-[470px] pt-12">
      <div className="mb-6 text-center"><h1 className="font-serif text-3xl font-extrabold tracking-[-.045em]">{t(signIn ? 'welcomeBack' : 'createAccount')}</h1><p className="mt-2 text-sm text-muted-foreground">{t(signIn ? 'authSubtitle' : 'createSubtitle')}</p></div>
      <div className="rounded-[1.8rem] border border-border bg-card p-5 shadow-[0_24px_70px_-45px_rgba(30,76,69,.45)] sm:p-7">
        {signIn ? <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} /> : <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />}
      </div>
      <p className="mt-5 text-center text-xs font-semibold text-muted-foreground">{t('secure')}</p>
    </div>
    <div className="absolute bottom-5 text-xs text-muted-foreground">{t('footer')}</div>
  </main>;
}

function HomeRedirect() {
  const { isLoaded, isSignedIn } = useAuth();
  if (isLoaded && isSignedIn) return <Redirect to="/dashboard" />;
  return <HomePage />;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  return <>{children}</>;
}

function replaceClerkApplicationName<T>(value: T): T {
  if (typeof value === 'string') return value.replace(/\{\{applicationName\}\}/g, 'صحتي') as T;
  if (Array.isArray(value)) return value.map((item) => replaceClerkApplicationName(item)) as T;
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, replaceClerkApplicationName(item)])) as T;
  }
  return value;
}

function ClerkRoutes() {
  const [, setLocation] = useLocation();
  const { i18n } = useTranslation();
  const appearance = {
    theme: shadcn,
    cssLayerName: 'clerk',
    options: { logoPlacement: 'inside' as const, logoLinkUrl: basePath || '/', logoImageUrl: `${window.location.origin}${basePath}/logo.svg` },
    variables: { colorPrimary: '#167e77', colorForeground: '#20333a', colorMutedForeground: '#63777b', colorDanger: '#b94238', colorBackground: '#ffffff', colorInput: '#f7faf8', colorInputForeground: '#20333a', colorNeutral: '#dce7e1', fontFamily: 'DM Sans, Noto Sans Arabic, sans-serif', borderRadius: '0.8rem' },
    elements: {
      rootBox: 'w-full flex justify-center',
      cardBox: 'bg-white rounded-2xl w-[440px] max-w-full overflow-hidden dark:bg-[#19282d]',
      card: '!shadow-none !border-0 !bg-transparent !rounded-none',
      footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
      headerTitle: 'font-bold text-[#20333a]',
      headerSubtitle: 'text-[#63777b]',
      socialButtonsBlockButtonText: 'font-semibold text-[#20333a]',
      formFieldLabel: 'font-semibold text-[#20333a]',
      footerActionLink: 'font-bold text-[#167e77]',
      footerActionText: 'text-[#63777b]',
      dividerText: 'text-[#63777b]',
      identityPreviewEditButton: 'text-[#167e77]',
      formFieldSuccessText: 'text-[#28775a]',
      alertText: 'text-[#a53c34]',
      logoBox: 'rounded-xl',
      logoImage: 'rounded-xl',
      socialButtonsBlockButton: 'rounded-xl border-[#dce7e1]',
      formButtonPrimary: 'rounded-xl font-bold',
      formFieldInput: 'rounded-xl border-[#dce7e1]',
      footerAction: 'text-[#63777b]',
      dividerLine: 'bg-[#dce7e1]',
      alert: 'rounded-xl',
      otpCodeFieldInput: 'rounded-lg',
      formFieldRow: 'gap-2',
      main: 'gap-4',
    },
  };
  const localization = replaceClerkApplicationName(i18n.language.startsWith('ar') ? arSA : i18n.language.startsWith('en') ? enUS : frFR);
  return <ClerkProvider publishableKey={clerkPubKey} proxyUrl={clerkProxyUrl} appearance={appearance} signInUrl={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} localization={localization} routerPush={(to) => setLocation(stripBase(to))} routerReplace={(to) => setLocation(stripBase(to), { replace: true })}>
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={HomeRedirect} />
        <Route path="/sign-in/*?" component={() => <AuthPage kind="signIn" />} />
        <Route path="/sign-up/*?" component={() => <AuthPage kind="signUp" />} />
        <Route path="/register">{() => <Guard allowIncomplete><RegisterPage /></Guard>}</Route>
        <Route path="/find-professional" component={FindProfessionalPage} />
        <Route path="/professionals/:professionalId" component={ProfessionalProfilePage} />
        <Route path="/dashboard">{() => <Guard><DashboardPage /></Guard>}</Route>
        <Route path="/appointments">{() => <Guard><AppointmentsPage /></Guard>}</Route>
        <Route path="/messages">{() => <Guard><MessagesPage /></Guard>}</Route>
        <Route path="/medical-record">{() => <Guard><MedicalRecordPage /></Guard>}</Route>
        <Route path="/documents">{() => <Guard><DocumentsPage /></Guard>}</Route>
        <Route path="/notifications">{() => <Guard><NotificationsPage /></Guard>}</Route>
        <Route path="/consultation/:appointmentId">{() => <Guard><ConsultationPage /></Guard>}</Route>
        <Route path="/admin">{() => <Guard admin><AdminPage /></Guard>}</Route>
        <Route>{() => <NotFoundPage />}</Route>
      </Switch>
    </RoutedErrorBoundary>
  </ClerkProvider>;
}

function NotFoundPage() {
  const { t } = useTranslation();
  return <main className="grid min-h-[100dvh] place-items-center bg-background px-5 text-center"><div><Brand /><h1 className="mt-10 font-serif text-3xl font-extrabold">404</h1><p className="mt-3 text-muted-foreground">{t('notFound')}</p><ActionLink href="/" testId="link-not-found-home" className="mt-6 inline-flex rounded-xl bg-primary px-5 py-3 text-sm font-bold text-primary-foreground">{t('backHome')}</ActionLink></div></main>;
}

function App() {
  if (!clerkPubKey) throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');
  return <QueryClientProvider client={queryClient}><WouterRouter base={basePath}><ClerkRoutes /></WouterRouter></QueryClientProvider>;
}

export default App;
