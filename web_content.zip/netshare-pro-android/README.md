# NetShare Pro — Android WebView prototype

This project packages the supplied HTML interface as an Android APK. Minimum Android version is Android 6 (API 23); Android 12 is supported.

## Important functionality limits
- The hotspot switch opens Android's tethering settings; it does not directly toggle the regular internet-sharing hotspot.
- The supplied HTML's speed, data-use chart, device list, block buttons and countdown are demo/simulated UI, not live device/network controls.
- The QR code reflects the text entered in the UI and may not match the phone's actual hotspot credentials.
- Android manufacturers and OS versions restrict third-party access to hotspot credentials and connected-device controls.
- The page loads Tailwind, Chart.js, Lucide and QRCode.js from CDNs, so those UI features need an internet connection unless dependencies are bundled locally.

## Build a free APK using GitHub Actions
1. Sign in to GitHub and create a new repository named `NetSharePro`.
2. Upload all files and folders from this project into the repository (including the hidden `.github` folder).
3. Open the repository's **Actions** tab and enable workflows if asked.
4. Select **Build NetShare Pro APK**, press **Run workflow**, and wait for the run to finish.
5. Open the completed workflow run, scroll to **Artifacts**, and download `NetShare-Pro-debug-APK`.
6. Extract the ZIP; the APK inside is `app-debug.apk`. Transfer it to your Android phone and install it. Android may ask you to allow installs from that source.

This is a debug APK for personal testing, not a Play Store release build. No keystore or paid account is needed for this debug build.
