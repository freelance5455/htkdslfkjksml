/* Class 9 English Arena — fully offline study app */
const chapters = [
  {title:"The Road Not Taken",author:"Robert Frost",unit:"Poetry",summary:"A traveller stands where two roads diverge in a yellow wood. He cannot travel both, so he chooses one. The roads represent choices in life and the way our decisions shape our journey.",points:["The setting is a yellow wood.","The traveller wishes he could take both roads.","The two roads symbolise choices and decisions.","The poem encourages reflection on the choices we make."],facts:["Poet: Robert Frost","Important image: two roads","Theme: choices and consequences"]},
  {title:"The Sound of Music",author:"Deborah Cowley / lesson on Bismillah Khan",unit:"Prose",summary:"The chapter has two parts. The first tells how Evelyn Glennie overcame hearing loss and learned to feel music through vibrations. The second describes shehnai maestro Bismillah Khan and his dedication to music.",points:["Ron Forbes encouraged Evelyn to sense vibrations.","Evelyn became an internationally recognised percussionist.","Bismillah Khan made the shehnai famous on the classical stage.","The chapter celebrates determination, practice and devotion to music."],facts:["Evelyn's guide: Ron Forbes","Instrument associated with Bismillah Khan: shehnai","Bismillah Khan's birthplace: Dumraon, Bihar"]},
  {title:"Wind",author:"Subramania Bharati",unit:"Poetry",summary:"The poet presents wind as a powerful force. It blows out weak fires but makes strong fires roar. The wind becomes a symbol of challenges: we should build inner strength to face difficulties.",points:["Wind destroys weak things.","Strong fires become stronger in the wind.","The poet asks us to build strong bodies and hearts.","The central message is courage and resilience."],facts:["Poet: Subramania Bharati","Symbol: wind as challenges","Message: become strong and prepared"]},
  {title:"The Little Girl",author:"Katherine Mansfield",unit:"Prose",summary:"Kezia is afraid of her strict father and misunderstands his serious manner. When he comforts her after a nightmare, she begins to recognise his affection and understand him better.",points:["Kezia is the central character.","She is frightened of her father at first.","She makes a pin-cushion using her father's important papers.","Her father's care during the night changes her understanding of him."],facts:["Main character: Kezia","Important object: pin-cushion","Theme: understanding parents and children"]},
  {title:"A Truly Beautiful Mind",author:"Based on Albert Einstein's life",unit:"Prose",summary:"The lesson follows Albert Einstein from childhood to scientific achievement and his concern for peace. It presents him as a gifted scientist who also cared about humanity.",points:["Einstein was born in Ulm, Germany, on 14 March 1879.","He showed a special interest in mathematics and science.","He received the Nobel Prize in Physics in 1921.","He spoke against war and was concerned about the use of atomic energy."],facts:["Birth: 14 March 1879","Birthplace: Ulm, Germany","Nobel Prize in Physics: 1921"]},
  {title:"The Lake Isle of Innisfree",author:"W. B. Yeats",unit:"Poetry",summary:"The poet dreams of leaving city noise and living peacefully on the island of Innisfree. He imagines a small cabin, a simple life and the soothing sounds of nature.",points:["The poet longs for peace in nature.","He imagines building a small cabin.","He describes natural sounds and changing light.","The poem expresses a desire for a quiet, simple life."],facts:["Poet: W. B. Yeats","Destination: Innisfree","Theme: peace and nature"]},
  {title:"The Snake and the Mirror",author:"Vaikom Muhammad Basheer",unit:"Prose",summary:"A young doctor sits in his room, admiring himself in a mirror and thinking about his future. A snake suddenly lands on him and coils around his arm. When it notices its reflection, the doctor gets a chance to escape.",points:["The narrator is a young doctor.","The mirror plays an important role in the incident.","A snake coils around the doctor's arm.","The unexpected event makes the doctor realise his vulnerability."],facts:["Narrator: a doctor","Important object: mirror","Main incident: snake coils around the doctor's arm"]},
  {title:"The Legend of the Northland",author:"Phoebe Cary",unit:"Poetry",summary:"A selfish old woman refuses to give a hungry traveller a cake. Her repeated greed leads to a magical punishment: she is changed into a woodpecker and must search for food by pecking trees.",points:["The traveller is hungry and asks for food.","The old woman is unwilling to share a cake.","Her greed is punished.","The poem teaches kindness and generosity."],facts:["Poet: Phoebe Cary","The old woman becomes a woodpecker","Theme: generosity and compassion"]},
  {title:"My Childhood",author:"A. P. J. Abdul Kalam",unit:"Prose",summary:"Abdul Kalam recalls his childhood in Rameswaram, his parents, friends and teachers. He describes the harmony among people of different communities and the values that shaped him.",points:["Kalam was born in Rameswaram.","His parents were Jainulabdeen and Ashiamma.","His close friends included Ramanadha Sastry, Aravindan and Sivaprakasan.","Sivasubramania Iyer was his science teacher.","The lesson highlights simplicity, equality and hard work."],facts:["Birthplace: Rameswaram","Father: Jainulabdeen","Science teacher: Sivasubramania Iyer"]},
  {title:"No Men Are Foreign",author:"James Kirkup",unit:"Poetry",summary:"The poem reminds us that all people share the same earth, air and human needs. It rejects hatred and war and asks readers to recognise the humanity of people in every country.",points:["All people share the same earth.","People everywhere have similar human needs.","War harms humanity and the world we share.","The poem teaches brotherhood and universal equality."],facts:["Poet: James Kirkup","Theme: universal brotherhood","Message: no human being is truly foreign"]},
  {title:"Reach for the Top",author:"Santosh Yadav / Maria Sharapova profiles",unit:"Prose",summary:"The lesson presents people who reached the top through determination and hard work. Santosh Yadav challenged social expectations, trained in mountaineering and climbed Mount Everest twice.",points:["Santosh Yadav was an Indian mountaineer.","She showed courage, independence and determination.","She became the first woman to climb Mount Everest twice.","The lesson values ambition, discipline and persistence."],facts:["Featured sportsperson: Santosh Yadav","Achievement: climbed Everest twice","Qualities: courage and determination"]},
  {title:"On Killing a Tree",author:"Gieve Patel",unit:"Poetry",summary:"The poem describes how difficult it is to destroy a tree because it has deep roots and the power to grow again. It also draws attention to the violence involved in destroying nature.",points:["A simple cut does not kill a tree.","The tree draws nourishment from the earth.","Its roots are deep and resilient.","The poem makes readers think about the destruction of nature."],facts:["Poet: Gieve Patel","Important part: roots","Theme: resilience of nature and destruction"]},
  {title:"If I Were You",author:"Douglas James",unit:"Drama",summary:"An intruder enters Gerrard's home and plans to take his identity. Gerrard remains calm, thinks quickly and tricks the intruder into believing that escape through a door is necessary. He outsmarts him and calls for help.",points:["Gerrard is a playwright.","An intruder wants to take Gerrard's identity.","Gerrard stays calm and uses intelligence.","The play shows that presence of mind can overcome danger."],facts:["Writer: Douglas James","Main character: Gerrard","Theme: intelligence and presence of mind"]}
];

const qa = [
  {c:0,t:"short",q:"Where does the traveller find himself in 'The Road Not Taken'?",a:"The traveller finds himself in a yellow wood where two roads diverge. He has to choose one of the roads."},
  {c:0,t:"short",q:"What do the two roads symbolise?",a:"The two roads symbolise choices and decisions in life. Each choice can lead us towards a different future."},
  {c:0,t:"long",q:"Explain the central idea of 'The Road Not Taken'.",a:"The poem describes a traveller who comes to a place where two roads separate in a yellow wood. He wishes he could travel both, but he must choose one. The roads represent the choices we face in life. We cannot always know where a decision will lead, and a choice may shape our future. The poem makes us think about decision-making and the paths we take."},
  {c:1,t:"short",q:"Who helped Evelyn Glennie to continue with music?",a:"Ron Forbes, a percussionist, helped Evelyn. He encouraged her to feel musical vibrations through different parts of her body."},
  {c:1,t:"long",q:"How did Ron Forbes help Evelyn to continue with music?",a:"Ron Forbes noticed Evelyn's musical ability and encouraged her to feel music through vibrations. He tuned two large drums to different notes and asked her to sense the vibrations. Evelyn learned to recognise music through different parts of her body. His guidance gave her confidence and helped her continue her musical journey."},
  {c:1,t:"short",q:"What instrument was Bismillah Khan famous for playing?",a:"Bismillah Khan was famous for playing the shehnai."},
  {c:1,t:"short",q:"Where was Bismillah Khan born?",a:"Bismillah Khan was born in Dumraon, Bihar."},
  {c:1,t:"long",q:"When and how did Bismillah Khan get his big break?",a:"Bismillah Khan got an important opportunity in 1938 when All India Radio started in Lucknow. He became a well-known shehnai player on the radio. His performances helped bring the shehnai to a wider audience and establish it as a respected classical instrument."},
  {c:2,t:"short",q:"What does the wind do to weak fires?",a:"The wind blows out weak fires."},
  {c:2,t:"short",q:"What does the wind make strong fires do?",a:"It makes strong fires roar and flourish."},
  {c:2,t:"long",q:"What is the message of the poem 'Wind'?",a:"The poem teaches us to become strong and face difficulties with courage. The wind blows out weak fires but makes strong fires roar and flourish. In the same way, challenges can make weak people feel weaker, while strong and prepared people can face them. The poet advises us to build strong bodies, minds and hearts."},
  {c:3,t:"short",q:"Why was Kezia afraid of her father?",a:"Kezia was afraid because her father appeared strict and frightening. His serious manner and loud voice made her nervous."},
  {c:3,t:"short",q:"What did Kezia use to fill the pin-cushion?",a:"Kezia used the papers of her father's important speech to fill the pin-cushion."},
  {c:3,t:"long",q:"How did Kezia's opinion about her father change?",a:"At first, Kezia thought her father was harsh and frightening. She was afraid to speak freely with him. One night, when she had a nightmare, her father took her to his bed and comforted her. She realised that he cared for her, even though he did not always express his love in a gentle way. Her understanding of him changed."},
  {c:4,t:"short",q:"When and where was Albert Einstein born?",a:"Albert Einstein was born on 14 March 1879 in Ulm, Germany."},
  {c:4,t:"short",q:"Who was Einstein's first wife?",a:"Einstein's first wife was Mileva Maric."},
  {c:4,t:"long",q:"Why did Einstein write a letter to Franklin D. Roosevelt?",a:"In 1939, Einstein wrote to American President Franklin D. Roosevelt because he was concerned that Nazi Germany might develop an atomic weapon. He warned the President about the possible danger and urged the United States to take the matter seriously."},
  {c:5,t:"short",q:"Why did the poet want to go to Innisfree?",a:"The poet wanted to go to Innisfree to live a peaceful life close to nature, away from the noise and rush of the city."},
  {c:5,t:"short",q:"What did the poet plan to build at Innisfree?",a:"He planned to build a small cabin made of clay and wattles."},
  {c:5,t:"long",q:"Describe the peaceful life imagined by the poet in 'The Lake Isle of Innisfree'.",a:"The poet imagines living alone on the island of Innisfree. He wants to build a small cabin, grow beans and keep a hive of honeybees. He dreams of the sounds of bees, birds and the gentle movement of the lake. The island represents peace, simplicity and closeness to nature."},
  {c:6,t:"short",q:"Who is the narrator of 'The Snake and the Mirror'?",a:"The narrator is a young doctor who tells the story of a frightening incident in his room."},
  {c:6,t:"short",q:"What did the snake do in the doctor's room?",a:"The snake landed on the doctor and coiled around his arm. Later, it became interested in its reflection in the mirror."},
  {c:6,t:"long",q:"Describe the incident with the snake in the doctor's room.",a:"The doctor was sitting in his room and looking at himself in a mirror when a snake suddenly landed on him and coiled around his arm. He was frightened and remained still. The snake noticed its reflection in the mirror and moved towards it. The doctor used that moment to escape. When he returned, the snake was gone."},
  {c:7,t:"short",q:"What did the old woman refuse to give the hungry traveller?",a:"The old woman refused to give the hungry traveller a cake, even though he asked for food."},
  {c:7,t:"short",q:"What did the old woman become?",a:"The old woman was changed into a woodpecker."},
  {c:7,t:"long",q:"What lesson does 'The Legend of the Northland' teach?",a:"The poem teaches that people should be kind and generous, especially towards those who are hungry or in need. The old woman refuses to share a cake and is punished for her selfishness. Her story reminds readers that greed and lack of compassion are wrong."},
  {c:8,t:"short",q:"Where was Abdul Kalam's house?",a:"Abdul Kalam's house was on Mosque Street in Rameswaram, Tamil Nadu."},
  {c:8,t:"short",q:"Who was Kalam's science teacher?",a:"Sivasubramania Iyer was Kalam's science teacher."},
  {c:8,t:"short",q:"Who were Abdul Kalam's three close childhood friends?",a:"His three close friends were Ramanadha Sastry, Aravindan and Sivaprakasan."},
  {c:8,t:"long",q:"Who were Abdul Kalam's school friends? What did they later become?",a:"Abdul Kalam's close childhood friends were Ramanadha Sastry, Aravindan and Sivaprakasan. Ramanadha Sastry became the priest of the Rameswaram temple. Aravindan started a business arranging transport for pilgrims. Sivaprakasan became a catering contractor for the Southern Railways."},
  {c:8,t:"long",q:"What values did Kalam learn during his childhood?",a:"Kalam learned honesty, kindness, discipline and respect from his parents and teachers. His friendships with children from different communities taught him equality and communal harmony. His childhood shows the importance of education, hard work and good values."},
  {c:9,t:"short",q:"Who wrote 'No Men Are Foreign'?",a:"The poem 'No Men Are Foreign' was written by James Kirkup."},
  {c:9,t:"short",q:"What is the central message of 'No Men Are Foreign'?",a:"The poem teaches universal brotherhood. All human beings are equal and share the same earth, so we should not hate people from other countries."},
  {c:9,t:"long",q:"Why should we not hate people from other countries?",a:"We should not hate people from other countries because all human beings share the same earth and have similar needs, feelings and hopes. The poem reminds us that people everywhere work, sleep, breathe and depend on nature. War and hatred harm everyone. We should treat all people as members of one human family."},
  {c:10,t:"short",q:"Who was Santosh Yadav?",a:"Santosh Yadav was an Indian mountaineer who became the first woman to climb Mount Everest twice."},
  {c:10,t:"short",q:"Which qualities helped Santosh Yadav reach the top?",a:"Courage, determination, discipline, confidence and hard work helped Santosh Yadav reach the top."},
  {c:10,t:"long",q:"Describe the achievements of Santosh Yadav.",a:"Santosh Yadav was a brave and determined Indian mountaineer. She wanted to make her own choices and followed her interest in mountaineering. She received training and worked hard to improve her climbing skills. She became the first woman in the world to climb Mount Everest twice. Her life shows the value of courage, confidence and determination."},
  {c:11,t:"short",q:"Who wrote 'On Killing a Tree'?",a:"The poem 'On Killing a Tree' was written by Gieve Patel."},
  {c:11,t:"short",q:"What gives a tree the strength to grow again?",a:"The roots help the tree survive and grow again because they remain connected to the earth and draw nourishment."},
  {c:11,t:"long",q:"What is the central idea of 'On Killing a Tree'?",a:"The poem describes the strength and resilience of a tree. A simple cut cannot destroy it because it has deep roots and can grow again. The poem describes the violent process of destroying a tree and makes readers think about the harm humans cause to nature."},
  {c:12,t:"short",q:"What was Gerrard's profession in 'If I Were You'?",a:"Gerrard was a playwright."},
  {c:12,t:"short",q:"What did the intruder want from Gerrard?",a:"The intruder wanted to kill Gerrard and take his identity so that he could live as Gerrard."},
  {c:12,t:"long",q:"How did Gerrard outsmart the intruder?",a:"Gerrard remained calm and spoke cleverly. He made the intruder believe that he himself was involved in crime and that the police might arrive at any moment. He persuaded the intruder to look through a door, then pushed him into a cupboard and called for help. Gerrard's presence of mind saved him."},
  {c:12,t:"long",q:"What is the main message of 'If I Were You'?",a:"The play shows that calm thinking and presence of mind can help a person face a difficult situation. Gerrard does not panic when the intruder threatens him. Instead, he uses intelligence and quick thinking to overcome the problem."}
];

// 80 MCQs: 51 literature, 19 grammar, 5 comprehension, 5 extra vocabulary/grammar.
const mcqs = [
  ["Who is the poet of 'The Road Not Taken'?",["William Wordsworth","Robert Frost","James Kirkup","Gieve Patel"],1,"The Road Not Taken"],
  ["Where did the two roads diverge?",["In a garden","In a yellow wood","Near a river","In a village"],1,"The Road Not Taken"],
  ["What did the traveller regret?",["He could not travel both roads","He lost his bag","He was late","He forgot his way"],0,"The Road Not Taken"],
  ["What do the two roads symbolise?",["Two rivers","Two countries","Choices in life","Two forests"],2,"The Road Not Taken"],
  ["Who was Evelyn Glennie?",["A dancer","A famous percussionist","A singer","A painter"],1,"The Sound of Music"],
  ["Who helped Evelyn understand music through vibrations?",["Bismillah Khan","Ron Forbes","Albert Einstein","Her father"],1,"The Sound of Music"],
  ["Evelyn Glennie was profoundly:",["Blind","Deaf","Lame","Dumb"],1,"The Sound of Music"],
  ["Bismillah Khan played which instrument?",["Tabla","Sitar","Shehnai","Flute"],2,"The Sound of Music"],
  ["Where was Bismillah Khan born?",["Delhi","Dumraon","Mumbai","Kolkata"],1,"The Sound of Music"],
  ["Who was Bismillah Khan's maternal uncle?",["Ali Bux","Ron Forbes","Rasool Bux Khan","Paigambar Bux"],0,"The Sound of Music"],
  ["Who wrote the poem 'Wind'?",["Robert Frost","Subramania Bharati","James Kirkup","Gieve Patel"],1,"Wind"],
  ["What does the wind do to weak fires?",["Makes them stronger","Blows them out","Makes them brighter","Makes them bigger"],1,"Wind"],
  ["What does the wind make strong fires do?",["Disappear","Become weak","Roar and flourish","Stop burning"],2,"Wind"],
  ["What should we make strong according to the poet?",["Our houses","Our bodies and hearts","Our roads","Our clothes"],1,"Wind"],
  ["Who was the main character of 'The Little Girl'?",["Evelyn","Kezia","Santosh","Olga"],1,"The Little Girl"],
  ["What was Kezia afraid of?",["Her mother","Her father","Her grandmother","Her teacher"],1,"The Little Girl"],
  ["What did Kezia make for her father?",["A card","A pin-cushion","A painting","A book"],1,"The Little Girl"],
  ["What did Kezia use to fill the pin-cushion?",["Cotton","Wool","Her father's speech papers","Paper flowers"],2,"The Little Girl"],
  ["When was Albert Einstein born?",["14 March 1879","15 August 1880","2 October 1879","10 January 1885"],0,"A Truly Beautiful Mind"],
  ["Where was Einstein born?",["Berlin","Ulm, Germany","London","Paris"],1,"A Truly Beautiful Mind"],
  ["Einstein was especially gifted in:",["History","Mathematics","Geography","Music"],1,"A Truly Beautiful Mind"],
  ["Einstein received the Nobel Prize in:",["1915","1921","1930","1945"],1,"A Truly Beautiful Mind"],
  ["Who was Einstein's first wife?",["Kezia","Mileva Maric","Evelyn","Olga"],1,"A Truly Beautiful Mind"],
  ["Who wrote 'The Lake Isle of Innisfree'?",["W. B. Yeats","Robert Frost","James Kirkup","Subramania Bharati"],0,"The Lake Isle of Innisfree"],
  ["Where does the poet want to go?",["London","Innisfree","Paris","Dublin city centre"],1,"The Lake Isle of Innisfree"],
  ["What does the poet want to build there?",["A palace","A small cabin","A big hotel","A school"],1,"The Lake Isle of Innisfree"],
  ["Who is the narrator of 'The Snake and the Mirror'?",["A doctor","A teacher","A farmer","A soldier"],0,"The Snake and the Mirror"],
  ["What was the doctor looking at?",["A window","A mirror","A book","A painting"],1,"The Snake and the Mirror"],
  ["What appeared in the doctor's room?",["A lion","A snake","A dog","A monkey"],1,"The Snake and the Mirror"],
  ["What did the snake look at?",["The doctor","The mirror","The window","The door"],1,"The Snake and the Mirror"],
  ["Who wrote 'The Legend of the Northland'?",["Phoebe Cary","Robert Frost","W. B. Yeats","Gieve Patel"],0,"The Legend of the Northland"],
  ["What did the old woman refuse to give the hungry traveller?",["Water","A cake","Milk","Rice"],1,"The Legend of the Northland"],
  ["What did the old woman become?",["A crow","A woodpecker","A pigeon","A sparrow"],1,"The Legend of the Northland"],
  ["Who wrote 'My Childhood'?",["Mahatma Gandhi","A. P. J. Abdul Kalam","Jawaharlal Nehru","Albert Einstein"],1,"My Childhood"],
  ["Where was Abdul Kalam born?",["Chennai","Rameswaram","Delhi","Mumbai"],1,"My Childhood"],
  ["What was Kalam's father's name?",["Jainulabdeen","Ashiamma","Ramanadha","Sivasubramania"],0,"My Childhood"],
  ["Who was Kalam's science teacher?",["Ramanadha Sastry","Sivasubramania Iyer","Aravindan","Sivaprakasan"],1,"My Childhood"],
  ["Who were Kalam's three close childhood friends?",["Ramanadha Sastry, Aravindan and Sivaprakasan","Ron Forbes, Ali Bux and Raman","Mahendra, Iswaran and Sergei","None of these"],0,"My Childhood"],
  ["Who wrote 'No Men Are Foreign'?",["Robert Frost","James Kirkup","Gieve Patel","Phoebe Cary"],1,"No Men Are Foreign"],
  ["What is the main message of the poem?",["War","Brotherhood and equality","Wealth","Competition"],1,"No Men Are Foreign"],
  ["According to the poem, all human beings share the same:",["Language","Earth","Country","Religion"],1,"No Men Are Foreign"],
  ["Who was Santosh Yadav?",["A singer","A mountaineer","A scientist","A dancer"],1,"Reach for the Top"],
  ["Santosh Yadav climbed which mountain?",["K2","Mount Everest","Kanchenjunga","Nanda Devi"],1,"Reach for the Top"],
  ["Santosh Yadav became the first woman to climb Mount Everest how many times?",["Once","Twice","Three times","Four times"],1,"Reach for the Top"],
  ["Who wrote 'On Killing a Tree'?",["Gieve Patel","James Kirkup","Robert Frost","W. B. Yeats"],0,"On Killing a Tree"],
  ["What gives a tree its strength to grow again?",["Its leaves","Its roots","Its flowers","Its branches"],1,"On Killing a Tree"],
  ["According to the poem, what does a tree absorb from the earth?",["Water and nutrients","Plastic","Iron","Smoke"],0,"On Killing a Tree"],
  ["Who wrote 'If I Were You'?",["Douglas James","Robert Frost","Gieve Patel","James Kirkup"],0,"If I Were You"],
  ["What was Gerrard's profession?",["Doctor","Playwright","Teacher","Police officer"],1,"If I Were You"],
  ["Who entered Gerrard's house?",["A policeman","An intruder","A doctor","A postman"],1,"If I Were You"],
  ["What did the intruder want to do?",["Become Gerrard's friend","Take Gerrard's identity","Buy Gerrard's house","Give him money"],1,"If I Were You"],
  ["He ___ to school every day.",["Go","Goes","Going","Gone"],1,"Grammar"],
  ["They ___ playing football.",["Is","Am","Are","Was"],2,"Grammar"],
  ["She ___ a song yesterday.",["Sing","Sings","Sang","Singing"],2,"Grammar"],
  ["I ___ my homework already.",["Have completed","Has complete","Completing","Complete"],0,"Grammar"],
  ["He ___ here tomorrow.",["Came","Comes","Will come","Coming"],2,"Grammar"],
  ["He is ___ honest man.",["A","An","The","No article"],1,"Grammar"],
  ["She is good ___ English.",["On","At","By","From"],1,"Grammar"],
  ["He died ___ cancer.",["Of","On","At","With"],0,"Grammar"],
  ["The book is ___ the table.",["In","On","At","By"],1,"Grammar"],
  ["I have lived here ___ 2020.",["For","Since","From","At"],1,"Grammar"],
  ["Identify the adjective: She is a beautiful girl.",["She","Is","Beautiful","Girl"],2,"Grammar"],
  ["Identify the pronoun: They are playing.",["They","Playing","Are","None"],0,"Grammar"],
  ["Identify the subject: The boys are playing football.",["Playing","Football","The boys","Are"],2,"Grammar"],
  ["Identify the verb: Birds fly in the sky.",["Birds","Fly","Sky","The"],1,"Grammar"],
  ["You ___ obey your parents.",["Should","Was","Is","Has"],0,"Grammar"],
  ["We ___ respect our teachers.",["Must","Is","Am","Was"],0,"Grammar"],
  ["Choose the passive voice: Ram writes a letter.",["A letter was written by Ram.","A letter is written by Ram.","Ram is written by a letter.","A letter wrote Ram."],1,"Grammar"],
  ["Choose the correct sentence.",["He do his work.","He does his work.","He doing his work.","He done his work."],1,"Grammar"],
  ["Choose the correct reported speech: He said, 'I am ill.'",["He said that he is ill.","He said that he was ill.","He says he was ill.","He said I was ill."],1,"Grammar"],
  ["What are forests?",["Natural resources","Buildings","Factories","Roads"],0,"Reading Passage"],
  ["What do forests provide for papermaking?",["Iron","Bamboo","Plastic","Glass"],1,"Reading Passage"],
  ["Forests provide shelter to:",["Machines","Birds and animals","Vehicles","Buildings"],1,"Reading Passage"],
  ["What helps maintain the balance of nature?",["Factories","Forests","Roads","Vehicles"],1,"Reading Passage"],
  ["What should we do to save the environment?",["Cut trees","Burn forests","Plant more trees","Waste resources"],2,"Reading Passage"],
  ["What is the plural of 'Child'?",["Childs","Children","Childes","Childrens"],1,"Vocabulary"],
  ["What is the opposite of 'Beautiful'?",["Pretty","Ugly","Good","Nice"],1,"Vocabulary"],
  ["Choose the synonym of 'Happy'.",["Sad","Angry","Glad","Weak"],2,"Vocabulary"],
  ["Choose the correct spelling.",["Beautifull","Beautiful","Beutiful","Beautifal"],1,"Vocabulary"],
  ["Choose the correct question tag: You are a student, ___?",["Are you","Isn't it","Aren't you","Don't you"],2,"Grammar"]
].map((x,i)=>({q:x[0],opts:x[1],answer:x[2],topic:x[3],id:i+1}));

const blanks = [
  {q:"The poet of 'The Road Not Taken' is ______.",a:["Robert Frost","frost"],hint:"Poet's full name."},
  {q:"The two roads diverged in a ______ wood.",a:["yellow"],hint:"The colour mentioned in the poem."},
  {q:"Ron Forbes helped Evelyn Glennie to feel musical ______.",a:["vibrations","vibration"],hint:"She sensed sound through movement."},
  {q:"Bismillah Khan played the ______.",a:["shehnai","shenai"],hint:"A traditional wind instrument."},
  {q:"The poem 'Wind' was written by ______ Bharati.",a:["Subramania"],hint:"The poet's first name."},
  {q:"Kezia was afraid of her ______.",a:["father"],hint:"A parent in the story."},
  {q:"Kezia made a ______ for her father.",a:["pin-cushion","pincushion","pin cushion"],hint:"A small object used for pins."},
  {q:"Albert Einstein was born in ______, Germany.",a:["Ulm"],hint:"His birthplace."},
  {q:"Einstein received the Nobel Prize in Physics in ______.",a:["1921"],hint:"A year."},
  {q:"The poet of 'The Lake Isle of Innisfree' is W. B. ______.",a:["Yeats","yeats"],hint:"Surname of the poet."},
  {q:"The narrator of 'The Snake and the Mirror' is a ______.",a:["doctor"],hint:"His profession."},
  {q:"The old woman in 'The Legend of the Northland' becomes a ______.",a:["woodpecker"],hint:"A bird that pecks trees."},
  {q:"Abdul Kalam was born in ______.",a:["Rameswaram","rameshwaram"],hint:"A place in Tamil Nadu."},
  {q:"Kalam's science teacher was Sivasubramania ______.",a:["Iyer"],hint:"The teacher's surname."},
  {q:"'No Men Are Foreign' was written by James ______.",a:["Kirkup"],hint:"The poet's surname."},
  {q:"Santosh Yadav climbed Mount ______.",a:["Everest"],hint:"The world's highest mountain above sea level."},
  {q:"'On Killing a Tree' was written by Gieve ______.",a:["Patel"],hint:"The poet's surname."},
  {q:"Gerrard was a ______.",a:["playwright"],hint:"A person who writes plays."},
  {q:"He ______ to school every day. (go/goes)",a:["goes"],hint:"Simple present for he/she/it."},
  {q:"He is ______ honest man. (a/an)",a:["an"],hint:"Use before a vowel sound."},
  {q:"She is good ______ English. (at/on)",a:["at"],hint:"Correct preposition after good."},
  {q:"I have lived here ______ 2020. (since/for)",a:["since"],hint:"Use with a starting point in time."},
  {q:"The children ______ playing outside. (is/are)",a:["are"],hint:"Plural subject."},
  {q:"You ______ respect your teachers. (should/was)",a:["should"],hint:"A modal expressing advice."},
  {q:"The plural of 'child' is ______.",a:["children"],hint:"Irregular plural noun."}
];

const writingTasks = [
  {title:"Indian Festivals",type:"Essay · 8 marks",target:120,prompt:"Write an essay on 'Indian Festivals' in about 120 words. Include examples of festivals and explain how they promote unity.",model:"India is a land of festivals. People of different religions and communities celebrate many festivals throughout the year. Festivals bring happiness, peace and unity among people. Diwali, Holi, Eid, Christmas, Bihu and Wangala are some famous festivals celebrated in India. Diwali is known as the festival of lights. People decorate their homes, light lamps and share sweets. Holi is the festival of colours. Eid teaches love and brotherhood, while Christmas spreads the message of kindness. Festivals help us understand different cultures and traditions. They bring families and friends together. We should celebrate all festivals with respect and care for the environment. Festivals make our country colourful and united."},
  {title:"Application for Absence",type:"Application · Practice",target:100,prompt:"Write an application to your Class Teacher requesting leave because you were ill and could not attend school for a few days.",model:"To,\nThe Class Teacher,\nRongara RMSA Secondary School,\nRongara.\n\nSubject: Application for absence from school.\n\nRespected Sir/Madam,\nWith due respect, I beg to state that I was unable to attend school for a few days due to illness. I have now recovered and am ready to attend my classes regularly. Kindly excuse my absence and grant me leave for those days. I shall be highly grateful to you.\n\nYours obediently,\nABC\nClass: IX | Roll No.: ____\nDate: ____"},
  {title:"Importance of Discipline",type:"Essay · 8 marks practice",target:120,prompt:"Write an essay on 'The Importance of Discipline' in about 120 words.",model:"Discipline is an important quality in human life. It teaches us to obey rules, respect others and use our time properly. A disciplined student attends school regularly, completes homework on time and listens to teachers. Discipline helps us develop good habits, self-control and responsibility. It is important at home, in school and in society. Without discipline, life becomes disorganised. Great people achieve their goals through hard work and discipline. We should follow rules, be punctual and behave politely. Discipline does not mean fear; it means doing the right thing at the right time. Therefore, everyone should practise discipline to become a successful and responsible person."},
  {title:"Letter to the Principal",type:"Formal Letter · Practice",target:100,prompt:"Write a letter to your Principal drawing attention to dirty school toilets and the foul smell coming from them.",model:"To,\nThe Principal,\nRongara RMSA Secondary School,\nRongara.\n\nSubject: Request for cleaning the school toilets.\n\nRespected Madam/Sir,\nI would like to draw your kind attention to the poor condition of the school toilets. They are very dirty and a foul smell comes from them. This makes it difficult for students to use the facilities and may affect everyone's health. I kindly request you to arrange regular cleaning and proper maintenance of the toilets.\n\nThank you.\nYours obediently,\nABC\nClass IX | Roll No. ____"},
  {title:"Importance of Trees",type:"Essay · Practice",target:120,prompt:"Write an essay on 'Importance of Trees' in about 120 words. Mention their benefits and how we can protect them.",model:"Trees are very important for life on Earth. They give us oxygen, fruits, flowers, timber and shade. They provide homes for birds and animals and help keep the environment balanced. Their roots hold the soil and reduce soil erosion. Trees also make the air cleaner and our surroundings beautiful. Unfortunately, many trees are cut down for roads and buildings. We should plant more trees, protect forests and avoid wasting paper. Schools and communities can organise tree-planting programmes. Every person should care for plants and encourage others to do the same. Protecting trees means protecting our future."}
];

const $ = (s,root=document)=>root.querySelector(s);
const $$ = (s,root=document)=>Array.from(root.querySelectorAll(s));
const storeKey="class9EnglishArena_v1";
let saved={practiced:[],quizCorrect:0,quizAnswered:0,drafts:{},completedBlanks:[]};
try{saved={...saved,...JSON.parse(localStorage.getItem(storeKey)||"{}")}}catch(e){}
function persist(){localStorage.setItem(storeKey,JSON.stringify(saved));updateStats()}
function updateStats(){ $('#statDone').textContent=saved.practiced.length+saved.completedBlanks.length; $('#statQuiz').textContent=saved.quizCorrect||0; const pct=Math.round(((saved.quizAnswered||0)/mcqs.length)*100); $('#statStreak').textContent=pct+"%"; }
function toast(msg){const el=$('#toast');el.textContent=msg;el.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove('show'),2200)}
function go(view){$$('.view').forEach(x=>x.classList.toggle('active',x.id==='view-'+view));$$('[data-view]').forEach(x=>x.classList.toggle('active',x.dataset.view===view));window.scrollTo({top:0,behavior:'smooth'});if(view==='qa')renderQA();if(view==='revision')renderChapters();if(view==='practical')renderTasks()}
$$('[data-view]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.view)));
$$('[data-go]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.go)));
$('#homeBrand').addEventListener('click',()=>go('home'));
$('#resetProgress').addEventListener('click',()=>{if(confirm('Reset quiz score, saved writing drafts and practice progress on this device?')){localStorage.removeItem(storeKey);saved={practiced:[],quizCorrect:0,quizAnswered:0,drafts:{},completedBlanks:[]};persist();renderQuiz();renderBlanks();renderTasks();toast('Progress reset. Fresh start!')}});

function renderChapters(filter=""){
 const grid=$('#chapterGrid');const found=chapters.map((c,i)=>({...c,i})).filter(c=>(c.title+" "+c.author).toLowerCase().includes(filter.toLowerCase()));
 $('#chapterCount').textContent=found.length+" chapters";
 grid.innerHTML=found.map(c=>`<button class="chapter-card" data-chapter="${c.i}"><span class="chapter-no">CHAPTER ${String(c.i+1).padStart(2,'0')} · ${c.unit.toUpperCase()}</span><span class="chapter-go">↗</span><b>${c.title}</b><small>${c.author}</small></button>`).join('');
 $$('.chapter-card',grid).forEach(b=>b.addEventListener('click',()=>showChapter(+b.dataset.chapter)));
}
function showChapter(i){const c=chapters[i];const d=$('#chapterDetail');d.classList.remove('hidden');d.innerHTML=`<div class="qa-meta"><span class="tag">${c.unit}</span><span class="tag">${c.author}</span></div><h2>${c.title}</h2><p>${c.summary}</p><h3 style="font:800 12px Manrope;margin:18px 0 9px">KEY REVISION POINTS</h3><div class="key-points">${c.points.map(p=>`<div class="key-point">✦ ${p}</div>`).join('')}</div><h3 style="font:800 12px Manrope;margin:18px 0 9px">REMEMBER THESE FACTS</h3><div class="key-points">${c.facts.map(p=>`<div class="key-point">✓ ${p}</div>`).join('')}</div><div style="display:flex;gap:8px;margin-top:17px;flex-wrap:wrap"><button class="primary-small" id="markChapter">Mark revision complete</button><button class="outline-btn" id="chapterQuestions">Practise chapter Q&A →</button></div>`;
 $('#markChapter').onclick=()=>{const id='rev-'+i;if(!saved.practiced.includes(id))saved.practiced.push(id);persist();toast('Chapter revision saved!')};$('#chapterQuestions').onclick=()=>{go('qa');$('#qaChapter').value=String(i);renderQA()};d.scrollIntoView({behavior:'smooth',block:'nearest'});
}
$('#chapterSearch').addEventListener('input',e=>renderChapters(e.target.value));

function fillQADrop(){const sel=$('#qaChapter');sel.innerHTML='<option value="all">All chapters</option>'+chapters.map((c,i)=>`<option value="${i}">${c.title}</option>`).join('')}
function renderQA(){const chap=$('#qaChapter').value||'all',type=$('#qaType').value||'all',search=($('#qaSearch').value||'').toLowerCase();const items=qa.map((q,i)=>({...q,i})).filter(x=>(chap==='all'||String(x.c)===chap)&&(type==='all'||x.t===type)&&(x.q+' '+chapters[x.c].title).toLowerCase().includes(search));$('#qaList').innerHTML=items.length?items.map(x=>`<article class="qa-card" data-qa="${x.i}"><div class="qa-meta"><span class="tag ${x.t}">${x.t==='short'?'SHORT · 2 MARKS':'LONG · 5 MARKS'}</span><span class="tag">${chapters[x.c].title}</span></div><h3>${x.q}</h3><button class="outline-btn qa-toggle">Show answer ↓</button><div class="answer-box"><b>Model answer:</b><br>${x.a}<br><button class="text-btn mark-answer" style="margin-top:10px">Mark as revised ✓</button></div></article>`).join(''):'<div class="qa-card">No matching questions. Try another chapter or search word.</div>';
 $$('.qa-card', $('#qaList')).forEach(card=>{const btn=$('.qa-toggle',card);if(!btn)return;btn.onclick=()=>{card.classList.toggle('open');btn.textContent=card.classList.contains('open')?'Hide answer ↑':'Show answer ↓'};$('.mark-answer',card).onclick=()=>{const id='qa-'+card.dataset.qa;if(!saved.practiced.includes(id))saved.practiced.push(id);persist();toast('Answer marked as revised!')}})
}
$('#qaChapter').addEventListener('change',renderQA);$('#qaType').addEventListener('change',renderQA);$('#qaSearch').addEventListener('input',renderQA);

let quizIndex=0,quizScore=0,quizAnswered=new Set(),quizChoice=null;
function renderQuiz(){const item=mcqs[quizIndex];const card=$('#quizCard');if(!item){card.innerHTML=`<div style="text-align:center;padding:30px"><div style="font-size:44px">🏆</div><h2>Quiz completed!</h2><p style="color:#8090a8;font-size:12px">You scored <b>${quizScore} / ${mcqs.length}</b>. Keep revising and try again.</p><button class="primary-small" id="finishRestart">Play again ↻</button></div>`;$('#finishRestart').onclick=restartQuiz;return}
 $('#quizScore').textContent=quizScore+" / "+quizAnswered.size;$('#quizProgressBar').style.width=(quizAnswered.size/mcqs.length*100)+'%';
 card.innerHTML=`<div class="quiz-number">QUESTION ${quizIndex+1} OF ${mcqs.length} · ${item.topic.toUpperCase()}</div><h2>${item.q}</h2><div class="option-list">${item.opts.map((o,i)=>`<button class="option-btn" data-opt="${i}"><b>${String.fromCharCode(65+i)}.</b> ${o}</button>`).join('')}</div><div id="quizFeedback"></div><div class="quiz-controls"><button class="text-btn" id="quizSkip">Skip question →</button><button class="primary-small" id="quizNext" disabled>${quizIndex===mcqs.length-1?'Finish quiz':'Next question →'}</button></div>`;
 $$('.option-btn',card).forEach(btn=>btn.onclick=()=>chooseOption(+btn.dataset.opt));$('#quizNext').onclick=nextQuestion;$('#quizSkip').onclick=nextQuestion;
}
function chooseOption(i){if(quizAnswered.has(quizIndex))return;const item=mcqs[quizIndex];const good=i===item.answer;quizChoice=i;quizAnswered.add(quizIndex);if(good)quizScore++;saved.quizAnswered=quizAnswered.size;saved.quizCorrect=quizScore;persist();$$('.option-btn',$('#quizCard')).forEach((b,j)=>{b.disabled=true;if(j===item.answer)b.classList.add('correct');if(j===i&&!good)b.classList.add('wrong')});$('#quizFeedback').innerHTML=`<div class="quiz-feedback ${good?'good':'bad'}"><b>${good?'Correct! ✓':'Not quite.'}</b> Correct answer: <b>${String.fromCharCode(65+item.answer)}. ${item.opts[item.answer]}</b></div>`;$('#quizNext').disabled=false;$('#quizScore').textContent=quizScore+" / "+quizAnswered.size;$('#quizProgressBar').style.width=(quizAnswered.size/mcqs.length*100)+'%';}
function nextQuestion(){quizIndex++;if(quizIndex>=mcqs.length){renderQuiz();toast('Quiz finished!')}else renderQuiz()}
function restartQuiz(){quizIndex=0;quizScore=0;quizAnswered=new Set();quizChoice=null;saved.quizCorrect=0;saved.quizAnswered=0;persist();renderQuiz();toast('Quiz restarted!')}
$('#restartQuiz').addEventListener('click',restartQuiz);

let blankIndex=0,blankScore=0,blankChecked=false;
function renderBlanks(){const item=blanks[blankIndex];if(!item){$('#blankCard').innerHTML=`<div style="text-align:center;padding:25px"><div style="font-size:42px">✨</div><h2>Practice set completed!</h2><p>You got ${blankScore} correct in this round.</p><button class="primary-small" id="blankAgain">Practise again</button></div>`;$('#blankAgain').onclick=()=>{blankIndex=0;blankScore=0;renderBlanks()};$('#blankCount').textContent='Completed';$('#blankScore').textContent=blankScore+' correct';return}
 $('#blankCount').textContent=`Question ${blankIndex+1} of ${blanks.length}`;$('#blankScore').textContent=(saved.completedBlanks||[]).length+' completed';$('#blankCard').innerHTML=`<div class="quiz-number">FILL IN THE BLANK · ${blankIndex+1}/${blanks.length}</div><h2>${item.q}</h2><p style="font-size:10px;color:#93a1b5">Hint: ${item.hint}</p><input class="blank-input" id="blankAnswer" placeholder="Type your answer here..." autocomplete="off" /><div class="feedback-line" id="blankFeedback"></div><div class="quiz-controls"><button class="text-btn" id="blankShow">Show answer</button><button class="primary-small" id="blankCheck">Check answer</button></div>`;
 $('#blankCheck').onclick=checkBlank;$('#blankShow').onclick=()=>{ $('#blankFeedback').innerHTML=`Answer: <b>${item.a[0]}</b>`;$('#blankFeedback').style.color='#7181dc';};$('#blankAnswer').addEventListener('keydown',e=>{if(e.key==='Enter')checkBlank()});blankChecked=false;
}
function checkBlank(){if(blankChecked)return;const item=blanks[blankIndex],v=$('#blankAnswer').value.trim().toLowerCase().replace(/[.!,']/g,'').replace(/\s+/g,' ');if(!v){toast('Type an answer first.');return}const good=item.a.some(a=>a.toLowerCase()===v);const fb=$('#blankFeedback');if(good){blankScore++;if(!saved.completedBlanks.includes(blankIndex))saved.completedBlanks.push(blankIndex);fb.innerHTML='Correct! ✓';fb.style.color='#269b79'}else{fb.innerHTML=`Try again. Correct answer: <b>${item.a[0]}</b>`;fb.style.color='#bd6d67'}blankChecked=true;persist();$('#blankCheck').textContent='Next question →';$('#blankCheck').onclick=()=>{blankIndex++;renderBlanks()};}

let activeTask=0;
function renderTasks(){const list=$('#taskList');list.innerHTML=writingTasks.map((t,i)=>`<button class="task-btn ${i===activeTask?'active':''}" data-task="${i}">${t.title}<small>${t.type}</small></button>`).join('');$$('.task-btn',list).forEach(b=>b.onclick=()=>{activeTask=+b.dataset.task;renderTasks()});renderWorkspace()}
function renderWorkspace(){const t=writingTasks[activeTask],draft=saved.drafts[activeTask]||'';$('#writingWorkspace').innerHTML=`<div class="qa-meta"><span class="tag">${t.type}</span><span class="tag">Target: about ${t.target} words</span></div><h2>${t.title}</h2><p>${t.prompt}</p><textarea id="draftBox" placeholder="Start writing your answer here...">${escapeHtml(draft)}</textarea><div class="writing-meta"><span id="wordCount">0 words</span><span>Your draft stays saved on this device</span></div><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="primary-small" id="saveDraft">Save my practice ✓</button><button class="outline-btn" id="showModel">Show model answer ↓</button><button class="text-btn" id="clearDraft">Clear</button></div><div class="model-answer" id="modelAnswer"><b>MODEL ANSWER</b><br><br>${t.model}</div>`;
 const box=$('#draftBox');const count=()=>{$('#wordCount').textContent=(box.value.trim()?box.value.trim().split(/\s+/).length:0)+' words'};count();box.addEventListener('input',()=>{saved.drafts[activeTask]=box.value;persist();count()});$('#saveDraft').onclick=()=>{saved.drafts[activeTask]=box.value;const id='writing-'+activeTask;if(!saved.practiced.includes(id))saved.practiced.push(id);persist();toast('Your writing practice is saved!')};$('#showModel').onclick=()=>{const m=$('#modelAnswer');m.classList.toggle('show');$('#showModel').textContent=m.classList.contains('show')?'Hide model answer ↑':'Show model answer ↓'};$('#clearDraft').onclick=()=>{if(confirm('Clear your draft for this task?')){box.value='';saved.drafts[activeTask]='';persist();count()}};
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}

fillQADrop();renderChapters();renderQA();renderQuiz();renderBlanks();renderTasks();updateStats();

// Subtle reveal-on-scroll effect for cards created or loaded on screen.
if('IntersectionObserver' in window){const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('seen');observer.unobserve(e.target)}}),{threshold:.08});$$('.reveal').forEach(el=>observer.observe(el));}

// Register local service worker when hosted over HTTPS/localhost (not needed for opening index.html directly).
if('serviceWorker' in navigator && location.protocol.startsWith('http')){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));}
