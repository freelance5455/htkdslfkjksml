CLASS 9 ENGLISH ARENA — PHONE SETUP (ACODE)

FILES
- index.html      Main app screen
- style.css       Premium responsive design and animations
- script.js       Chapters, Q&A, 80 MCQs, fill-in-the-blanks and writing practice
- manifest.json   Optional installable-app metadata
- sw.js           Offline cache when hosted through HTTPS/localhost

OPEN ON ANDROID USING ACODE
1. Extract this ZIP into a folder named CLASS9-ENGLISH-ARENA.
2. Open Acode and open the CLASS9-ENGLISH-ARENA folder.
3. Open index.html.
4. Tap the Preview / Run button in Acode.
5. Use the bottom navigation to switch between Home, Revision, Q&A, MCQ and Practical.

OFFLINE NOTES
- The core app works without an account or API key.
- Progress and writing drafts are saved in the browser's local storage on that device.
- The Google Fonts import is optional; if there is no internet, the app uses system fallback fonts.
- For installable offline caching, host the folder on HTTPS (for example, GitHub Pages or Render static site), open it in Chrome, then use Add to Home screen. Service workers do not run from a file:// preview.

CONTENT NOTE
This is an exam-practice app, not an official or guaranteed annual exam paper. It includes the Class IX English chapters shown in the contents photo and practice Q&A already discussed. A few reading, grammar and writing exercises are additional practice. Please confirm the final annual syllabus and prescribed reader with your teacher.

CHARACTERS
The mascots are original CSS-drawn anime-style study characters, not official depictions of copyrighted anime characters. Monkey decorations are animated emoji.
