FIXED version: HTML is loaded directly with file:///android_asset/index.html.
This avoids the appassets.androidplatform.net ERR_HTTP_RESPONSE_CODE_FAILURE issue.
Open the project in Android Studio and Build -> Build APK(s).
