PHYSICS QUEST — PROYEK APLIKASI ANDROID

Ini adalah proyek sumber aplikasi Android, bukan file APK jadi.
Game disimpan di dalam aplikasi dan dibuka langsung di layar aplikasi (bukan browser),
serta tidak membutuhkan koneksi internet untuk menjalankan game lokalnya.

CARA MEMBUAT APK:
1. Buka proyek ini di Android Studio pada komputer.
2. Tunggu Gradle selesai melakukan sync dan komponen Android yang dibutuhkan terpasang.
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Setelah selesai, pilih Locate. APK debug biasanya ada di app/build/outputs/apk/debug/app-debug.apk.
5. Kirim file APK tersebut lewat WhatsApp atau Bluetooth.

Catatan:
- Android Studio dan Android SDK diperlukan untuk menghasilkan APK.
- File APK belum disertakan karena lingkungan ini tidak memiliki Android SDK/alat build yang diperlukan.
- Jangan mengganti nama ZIP ini menjadi .apk; ZIP ini adalah proyek sumber.
