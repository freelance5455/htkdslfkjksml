const canvas=document.getElementById('game'),ctx=canvas.getContext('2d');
const title=document.getElementById('title'),hint=document.getElementById('hint'),start=document.getElementById('start'),musicBtn=document.getElementById('music');
let W,H,dpr,ground,player,obstacles,score,speed,running,last,spawnTimer,musicOn=true;
const music=new Audio('assets/runner_music.wav'); music.loop=true; music.volume=.22;
function resize(){dpr=devicePixelRatio||1;W=innerWidth;H=innerHeight;canvas.width=W*dpr;canvas.height=H*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);ground=H*.68} addEventListener('resize',resize);resize();
function startGame(){player={x:W*.15,y:ground-58,w:38,h:58,vy:0,onGround:true};obstacles=[];score=0;speed=6;spawnTimer=0;running=true;last=performance.now();title.classList.add('hidden');hint.classList.add('hidden');start.classList.add('hidden');if(musicOn)music.play().catch(()=>{});requestAnimationFrame(loop)}
function jump(){if(!running){startGame();return}if(player.onGround){player.vy=-15;player.onGround=false}}
addEventListener('keydown',e=>{if(e.code==='Space'||e.code==='ArrowUp')jump()});
addEventListener('pointerdown',e=>{if(e.target.tagName!=='BUTTON')jump()});
start.onclick=startGame;
musicBtn.onclick=()=>{musicOn=!musicOn;musicBtn.textContent=musicOn?'🔊 Music':'🔇 Music';if(musicOn){if(running)music.play().catch(()=>{})}else music.pause()};
function spawn(){obstacles.push({x:W+30,y:ground-42,w:30,h:42})}
function collision(a,b){return a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y}
function gameOver(){running=false;music.pause();title.textContent='GAME OVER';title.classList.remove('hidden');hint.textContent='Tap anywhere to play again';hint.classList.remove('hidden');start.textContent='RESTART';start.classList.remove('hidden')}
function loop(t){if(!running)return;const dt=Math.min((t-last)/16.67,2);last=t;player.vy+=.82*dt;player.y+=player.vy*dt;if(player.y+player.h>=ground){player.y=ground-player.h;player.vy=0;player.onGround=true}spawnTimer-=dt;if(spawnTimer<=0){spawn();spawnTimer=65+Math.random()*55}for(const o of obstacles)o.x-=speed*dt;obstacles=obstacles.filter(o=>o.x+o.w>0);for(const o of obstacles)if(collision(player,o)){gameOver();return}score+=.12*dt;speed+=.0015*dt;document.getElementById('score').textContent='Score: '+Math.floor(score);draw();requestAnimationFrame(loop)}
function draw(){ctx.clearRect(0,0,W,H);ctx.fillStyle='#75cfff';ctx.fillRect(0,0,W,ground);ctx.fillStyle='#63b447';ctx.fillRect(0,ground,W,H-ground);ctx.fillStyle='#4c9638';for(let x=0;x<W;x+=50)ctx.fillRect(x,ground,28,7);ctx.fillStyle='#202020';ctx.fillRect(player.x+5,player.y+18,28,40);ctx.fillStyle='#ffd0a5';ctx.beginPath();ctx.arc(player.x+19,player.y+5,15,0,Math.PI*2);ctx.fill();ctx.fillStyle='#202020';ctx.fillRect(player.x+7,player.y-8,25,8);ctx.fillRect(player.x,player.y+52,14,6);ctx.fillRect(player.x+25,player.y+52,14,6);ctx.fillStyle='#7b3f18';for(const o of obstacles)ctx.fillRect(o.x,o.y,o.w,o.h)}
