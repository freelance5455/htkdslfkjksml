AZMAIN RUNNER'S - MUSIC VERSION
Added an original upbeat chiptune-style background music file:
assets/runner_music.wav

Music starts when the game starts. Use the Music button to mute/unmute.
All game files stay inside this folder.
