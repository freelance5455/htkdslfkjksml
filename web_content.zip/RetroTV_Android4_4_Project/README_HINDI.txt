RETRO TV - ANDROID 4.4 TV PROJECT

Is ZIP mein ek simple TV-friendly YouTube search launcher hai.
Yeh YouTube ka official app nahi hai. Search karne par YouTube website khulti hai.
Videos YouTube ke apne player, internet connection aur device support par depend karte hain.

ONLINE APK BUILDER KE LIYE:
1. ZIP ko extract karein.
2. Apne online builder mein HTML5 / WebView / Cordova project ka option dekhein.
3. index.html ko start/home page set karein.
4. Agar builder Cordova config accept karta hai, config.xml bhi import karein.
5. Android minimum version / minSdkVersion ko 19 (Android 4.4) set karein.
6. Landscape orientation aur TV/remote keyboard focus support enable karein.
7. Build karke pehle test APK ko TV par install karein.

ZAROORI BAATEIN:
- Har online APK builder ZIP/Cordova project accept nahi karta. Agar aapke builder mein HTML/Cordova import nahi hai, yeh ZIP seedha APK nahi banayega.
- Android 4.4 bahut purana hai. Naye YouTube pages, HTTPS/TLS, login aur video playback TV ke WebView/browser par kaam na bhi karein.
- Is project mein YouTube API key ki zaroorat nahi, kyunki yeh YouTube search website kholta hai.
- Yeh YouTube videos ko apne app ke andar embed karke play nahi karta.
- YouTube ke terms, copyright aur regional availability lagu hote hain.

TV REMOTE:
Buttons aur search field keyboard/remote focus ke liye banaye gaye hain.
Agar remote ka OK button kaam na kare, builder ke WebView/TV input support ko check karein.
