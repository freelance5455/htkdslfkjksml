(function () {
  var form = document.getElementById('searchForm');
  var input = document.getElementById('query');
  var results = document.getElementById('results');

  function searchYouTube(term) {
    term = (term || '').replace(/^\s+|\s+$/g, '');
    if (!term) { input.focus(); return; }
    var url = 'https://www.youtube.com/results?search_query=' + encodeURIComponent(term);
    results.innerHTML = '';
    var message = document.createElement('p');
    message.textContent = 'Opening YouTube search for: ' + term;
    results.appendChild(message);
    var link = document.createElement('a');
    link.href = url;
    link.target = '_blank';
    link.rel = 'noopener';
    link.textContent = 'OPEN YOUTUBE RESULTS';
    results.appendChild(link);
    // Top-level navigation is more reliable on older Android WebViews.
    window.location.href = url;
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    searchYouTube(input.value);
  });

  var tiles = document.querySelectorAll('.tile');
  for (var i = 0; i < tiles.length; i++) {
    tiles[i].addEventListener('click', function () {
      searchYouTube(this.getAttribute('data-q'));
    });
  }
}());