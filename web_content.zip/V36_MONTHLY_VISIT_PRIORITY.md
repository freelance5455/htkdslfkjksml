V36 CHANGE

Main item lists are dynamically sorted by visits made in the current month. Items with 4, 3, 2, 1, or 0 visits are always placed at the top, in that order (4 down to 0). Items with more than 4 monthly visits follow below, sorted by monthly visits descending, then name.
