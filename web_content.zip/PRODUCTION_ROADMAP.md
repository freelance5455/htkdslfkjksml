# Production roadmap

1. Authentication: Firebase Auth, Supabase Auth, or a secure custom service.
2. Database: users, profiles, circles, posts, comments, reactions, follows,
   reports, blocks, moderation decisions, appeals and audit logs.
3. Storage: private-by-default media storage with signed URLs.
4. Server-side authorization: never trust client-only checks.
5. Moderation: automated pre-filtering + human review + appeals.
6. Safety: rate limits, anti-spam, abuse detection, age-appropriate defaults,
   privacy controls and account recovery.
7. Security: TLS, secure token storage, password hashing via auth provider,
   least-privilege service accounts and regular dependency updates.
8. Compliance: publish Terms, Privacy Policy, Community Guidelines, data
   retention/deletion process, and local legal review for every launch country.
9. Play Store: prepare privacy disclosures, Data Safety form, content rating,
   account deletion flow, and a signed release AAB.
