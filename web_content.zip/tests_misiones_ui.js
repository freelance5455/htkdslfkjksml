const fs=require('fs'),h=fs.readFileSync(__dirname+'/index.html','utf8'),sc=[...h.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
const mk=()=>{const o={style:{},classList:{toggle(){},add(){},remove(){}},children:[],innerHTML:'',textContent:'',dataset:{},
 appendChild(c){this.children.push(c)},querySelector:()=>mk(),querySelectorAll:()=>[],getContext:()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:10}):()=>{},set:()=>true}),addEventListener(){},setAttribute(){},getBoundingClientRect:()=>({left:0,top:0,width:100,height:100})};return o};
const els={};global.document={getElementById:id=>els[id]||(els[id]=mk()),documentElement:mk(),body:mk(),createElement:()=>mk(),addEventListener(){},querySelector:()=>mk(),querySelectorAll:()=>[],hidden:false};
global.getComputedStyle=()=>({paddingTop:'0',paddingBottom:'0'});global.innerWidth=400;global.innerHeight=800;global.devicePixelRatio=1;
const store={};global.localStorage={getItem:k=>store[k]||null,setItem:(k,v)=>{store[k]=v}};
global.addEventListener=()=>{};global.requestAnimationFrame=()=>{};global.navigator={};global.Image=function(){};global.Audio=function(){return mk()};global.AudioContext=undefined;global.window=global;global.setInterval=()=>{};global.performance={now:()=>0};
// guardado antiguo: Colapso elegido, sin campo mi
store.pocket2=JSON.stringify({ess:50,best:12,spins:12,dmg:3,hp:1,spd:0,set:{sfx:1,mus:1,vib:1,dif:3},own:{musguito:1}});
const code=sc[0]+';'+sc[1]+`
;({BAL,M,menu,missions,miClaim,difSel,difOpen,accLv,claimable,miVal,die:typeof die!=='undefined'?die:null,get S(){return S},setRun(a){kills=a.kills;bosses=a.bosses;t=a.t;lv=a.lv;wv=a.wv;bEss=0;p={fm:0};S='play'}})`;
let api;try{api=(0,eval)(code)}catch(e){console.log('ERROR carga',e.stack.split('\n').slice(0,4).join('\n'));process.exit(1)}
const {M,BAL}=api;let ok=0,bad=0;const T=(n,c)=>{c?ok++:(bad++,console.log('FALLA',n))};
T('guardado viejo: dif 3 bloqueada -> Normal',api.difSel()===0);
T('guardado viejo: semana/día nuevos, nada reclamable',api.claimable()===0);
api.menu();T('menu() sin errores',true);
api.missions();T('pantalla misiones renderiza',els.mis.innerHTML.includes('NIVEL DE CUENTA 1')&&els.mis.innerHTML.includes('Pesadilla'));
// reinicio semanal y diario
M.mi.s.kills=500;M.mi.ds.kills=500;M.mi.d['kills100']=1;M.mi.dd['d0']=1;M.mi.xp=100;M.mi.wk='2000-01-03';M.mi.dy='2000-01-03';api.claimable();
T('reinicio semanal: stats y reclamadas a 0',M.mi.s.kills===0&&!M.mi.d.kills100&&M.mi.wk===BAL.weekKey());T('reinicio diario',M.mi.ds.kills===0&&!M.mi.dd.d0&&M.mi.dy===BAL.dayKey());T('XP de cuenta se conserva',M.mi.xp===100);
M.mi.ds.kills=9999;M.mi.ds.wave=99;M.mi.ds.bosses=9;M.mi.ds.runs=9;M.mi.ds.secs=9999;M.mi.ds.lvl=99;M.spins+=5;const c0=api.claimable(),x0=M.mi.xp;api.miClaim(BAL.dailyPick(M.mi.dy));T('diarias reclamables y dan XP',c0>=1&&M.mi.xp>x0);
const x1=M.mi.xp;api.miClaim(BAL.dailyPick(M.mi.dy));T('no se reclama dos veces',M.mi.xp===x1);
M.mi.xp=0;M.mi.s={kills:0,bosses:0,secs:0,runs:0,lvl:0,wave:0};M.mi.ds={kills:0,bosses:0,secs:0,runs:0,lvl:0,wave:0};
// reclamar todo y subir de nivel
const before=api.accLv();api.miClaim(BAL.MI);console.log('nivel tras reclamar misiones listas:',before,'->',api.accLv(),'xp',M.mi.xp);
// simular dar XP para Nv5 y comprobar desbloqueo
M.mi.xp=270;T('Nv5 abre Difícil',api.difOpen(1)&&!api.difOpen(2));
M.set.dif=2;T('elegida Pesadilla bloqueada -> cae a Difícil',api.difSel()===1);
M.mi.xp=BAL.accCum(12);T('Nv12 abre Pesadilla, no Colapso',api.difOpen(2)&&!api.difOpen(3));
M.mi.xp=BAL.accCum(20);T('Nv20 abre Colapso',api.difOpen(3));
M.set.dif=3;api.menu();
// fin de partida guarda estadísticas
api.setRun({kills:300,bosses:2,t:200,lv:11,wv:9});api.die();
T('estadísticas guardadas',M.mi.s.kills===300&&M.mi.s.bosses===2&&M.mi.s.secs===200&&M.mi.s.runs===1&&M.mi.s.lvl===11);
T('mejor oleada por dificultad (Colapso)',M.mi.bd[3]===9);
const saved=JSON.parse(store.pocket2);T('persistido en pocket2',saved.mi&&saved.mi.s.kills===300);
console.log(ok,'ok',bad,'fallos');
