package app.yawmi

import android.content.Context

class Store(c: Context) {
    private val p = c.getSharedPreferences("focus", Context.MODE_PRIVATE)
    fun save(on: Boolean, end: Long, locked: Set<String>) {
        p.edit().putBoolean("on", on).putLong("end", end).putStringSet("locked", HashSet(locked)).apply()
    }
    fun active() = p.getBoolean("on", false) && p.getLong("end", 0) > System.currentTimeMillis()
    fun locked(): Set<String> = p.getStringSet("locked", emptySet()) ?: emptySet()
}
