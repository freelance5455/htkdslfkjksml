package app.yawmi

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var pending: String? = null
    private var ready = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(this), "Native")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, u: String) { ready = true; fire() }
        }
        pending = intent.getStringExtra("blocked")
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        pending = i.getStringExtra("blocked")
        fire()
    }

    private fun fire() {
        val n = pending ?: return
        if (!ready) return
        pending = null
        web.evaluateJavascript("window.onBlocked&&onBlocked(" + JSONObject.quote(n) + ")", null)
    }

    override fun onResume() {
        super.onResume()
        if (ready) web.evaluateJavascript("window.fc&&fc()", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { moveTaskToBack(true) }
}
