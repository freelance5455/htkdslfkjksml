package app.yawmi

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class Bridge(private val a: Activity) {
    private val pm = a.packageManager

    @JavascriptInterface
    fun getApps(): String {
        val home = pm.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            ?.activityInfo?.packageName
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        val arr = JSONArray()
        for (r in pm.queryIntentActivities(i, 0)) {
            val p = r.activityInfo.packageName
            if (p == a.packageName || p == home || p == "com.android.settings" || !seen.add(p)) continue
            arr.put(JSONObject().put("p", p).put("n", r.loadLabel(pm).toString()))
        }
        return arr.toString()
    }

    @JavascriptInterface
    fun getIcon(p: String): String = try {
        val d = pm.getApplicationIcon(p)
        val b = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, 96, 96)
        d.draw(Canvas(b))
        val o = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.PNG, 100, o)
        "data:image/png;base64," + Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    } catch (e: Exception) { "" }

    @JavascriptInterface
    fun sync(j: String) {
        val o = JSONObject(j)
        val l = o.getJSONArray("locked")
        val s = HashSet<String>()
        for (i in 0 until l.length()) s.add(l.getString(i))
        Store(a).save(o.getBoolean("on"), o.getLong("end"), s)
    }

    @JavascriptInterface
    fun openApp(p: String) {
        pm.getLaunchIntentForPackage(p)?.let { a.startActivity(it) }
    }

    @JavascriptInterface
    fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(a.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains(a.packageName + "/")
    }

    @JavascriptInterface
    fun openSettings() {
        a.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }
}
