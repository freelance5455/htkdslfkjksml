NUSANTARA POS — PROYEK ANDROID

Isi:
- Aplikasi WebView Android sederhana.
- HTML kasir berada di app/src/main/assets/index.html.
- Dirancang berjalan offline; data disimpan oleh aplikasi melalui penyimpanan web lokal.

Cara membuat APK:
1. Ekstrak ZIP ini di komputer.
2. Instal Android Studio versi stabil.
3. Buka folder NusantaraPOS melalui Android Studio.
4. Tunggu Gradle Sync selesai dan izinkan Android Studio mengunduh komponen build yang diminta.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug biasanya muncul di app/build/outputs/apk/debug/app-debug.apk.

Catatan:
- ZIP ini adalah proyek sumber Android Studio, BUKAN file APK siap pasang.
- Proyek ini belum dikompilasi atau diuji di perangkat Android dari lingkungan ini.
- Untuk APK rilis, penandatanganan (signing) perlu disiapkan terpisah.
