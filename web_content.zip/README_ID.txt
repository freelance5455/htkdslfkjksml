WARUNG OS v1.4 — REVISI MENU & IKON

Perubahan:
- Saat aplikasi dibuka, langsung masuk ke menu Kasir.
- Urutan menu: Kasir, Produk & Stok, Riwayat, Laporan, Backup, Pengaturan, Dashboard.
- Ikon menu diganti dengan ikon SVG bergaya modern, dengan tombol dan efek visual yang dirapikan.
- Fitur aplikasi lain dipertahankan dari paket v1.3.

ISI PAKET
- index.html: aplikasi utama
- manifest.json: metadata PWA
- sw.js: cache offline

PENTING
- Ini adalah paket sumber aplikasi web, bukan APK siap instal.
- Data aplikasi tersimpan lokal pada perangkat/browser. Jangan hapus data atau instalasi lama sebelum backup JSON dibuat.
- Fitur foto dan cetak struk di APK bergantung pada kemampuan pembungkus Android/WebView dan harus diuji pada perangkat nyata.
