PEAKFIRE WEB ZIP — LITE (<5 MB)
=================================
Ini versi ringan untuk memenuhi batas upload kurang dari 5 MB.
Isi:
- index.html
- loading-screen.jpg
- login-screen.jpg

Catatan:
Versi ringan ini tidak menyertakan model 3D GLB tambahan, jadi bagian arena/karakter 3D yang bergantung pada model eksternal bisa tidak tampil. Loading screen dan login tetap ada. Jika platform mewajibkan game berjalan tanpa internet, CDN Three.js mungkin perlu dibundel secara lokal.
