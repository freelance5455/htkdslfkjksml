WARUNG OS v1.3 — APK FORGE PACKAGE

ISI ZIP (semua file harus berada di ROOT proyek, bukan di dalam folder lain):
- index.html — aplikasi utama
- manifest.json — metadata aplikasi
- sw.js — cache offline untuk browser/PWA yang mendukung service worker

CARA IMPOR DI APK FORGE
1. Backup data dari APK lama terlebih dahulu melalui menu Backup.
2. Buat proyek baru dan impor ZIP ini.
3. Pastikan index.html terlihat langsung di root proyek. Jangan sampai menjadi folder/index.html.
4. Set halaman awal/start page ke index.html.
5. Build APK baru dengan nama versi berbeda agar mudah dibedakan.

NAMA TOKO
1. Buka menu Pengaturan.
2. Isi “Nama toko / warung yang tampil di aplikasi dan struk”.
3. Tekan Simpan pengaturan.
4. Nama itu akan muncul pada header aplikasi dan struk cetak.

CETAK STRUK
- Setelah transaksi disimpan, layar “Transaksi selesai” menawarkan tombol Cetak struk.
- Struk juga dapat dicetak lagi dari menu Riwayat > Detail > Cetak struk.
- Fitur cetak memakai dialog cetak Android/WebView. Ketersediaan printer Bluetooth/Wi-Fi tergantung dukungan cetak pada APK Forge dan perangkat. Jika dialog cetak tidak muncul, pembungkus APK perlu mendukung Android printing.

FOTO PRODUK
- Pemilih file tetap disediakan sebagai input yang terlihat langsung, bukan tombol JavaScript tersembunyi.
- Jika kolom file yang terlihat tetap tidak membuka galeri, kemungkinan pembungkus WebView/APK Forge tidak menyediakan Android file chooser. Ini tidak dapat dijamin selesai dari HTML saja; gunakan mode/fitur APK Forge yang mendukung pemilihan file atau file chooser.

DATA & BACKUP
- Data disimpan lokal di perangkat masing-masing. Dua HP tidak otomatis sinkron saat offline.
- Backup JSON dan pemulihan tersedia di menu Backup.
- Google Drive masih manual: unduh JSON lalu unggah ke Drive. Integrasi upload otomatis memerlukan konfigurasi OAuth Google.
- Jangan menghapus APK lama atau data aplikasi sebelum membuat dan memeriksa backup.
