ZAMGRAM CONNECTED STARTER
1) Buka Supabase Dashboard untuk project lu.
2) SQL Editor > New query > paste schema.sql > Run. Ini membuat tabel dan storage buckets.
3) Upload index.html ke layanan HTML-to-APK yang lu pilih (ZIP ini berisi index.html di root).
4) Nama aplikasi ZAMGRAM, package com.zamgram.app.
5) Daftar akun dari halaman login app.

Koneksi URL dan publishable key sudah dimasukkan ke index.html.
Jangan masukkan service_role key ke aplikasi.
Catatan: Ini versi awal fungsional (auth, postingan media, stories upload/view, reels upload/list, likes, comments, profil, chat dasar). Beberapa fitur lanjutan seperti push notification, follow UI, edit avatar, DM grup, moderasi dan story effects belum dibuat. Periksa RLS sebelum rilis publik.
