# BPSC Test Master — starter prototype
## Run
Open `index.html` in a browser or host the folder on a static web host.
For installable PWA, serve over HTTPS and use the browser's Install/Add to Home Screen option.
## Included
- Subject/topic practice
- Separate mock test entry
- PYQ practice starter screen
- Current affairs quiz starter screen
- Progress stored locally
- Offline cache support
## Important
This starter contains sample questions, not a verified five-year BPSC PYQ database. The Current Affairs section is a UI placeholder; live updates require a news/current-affairs API or backend and source verification.
