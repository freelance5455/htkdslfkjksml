BPSC Test Master rebuilt prototype
Open index.html in browser.
Subject/topic/difficulty/count and Start Practice.
Topics generated from question tags. All topics option.
Current Affairs is marked Coming Soon and no static quiz is presented as live news.
Sample bank is not verified PYQs and not a complete 150-question mock.

UPDATE: Endless AI mode.
Open index.html, set QUESTION SOURCE to "AI-generated", paste your Anthropic API key (console.anthropic.com), then Start.
Questions are generated on demand per syllabus topic; every question shown is fingerprinted and never repeated (stored in this browser).
Use "Report wrong" on a question that looks incorrect. Verify facts against standard books before relying on them.

UPDATE 2: Auto-generated mode (no AI, no internet, no key) is now the default.
- Fact tables (about 600 questions: Polity, History, Geography, Bihar GK, Economy, Science) build MCQs with wrong options picked from the same table.
- Mental Ability (number series, percentages, profit, interest, averages, ratio, speed, work, HCF/LCM, coding) is generated from templates and never runs out.
- Every question shown is remembered and never repeated until you press "Reset seen history".
- "My own question pool": paste lines like "Question | Correct answer" to grow the pool yourself.

UPDATE 3: AI option removed. Subtopics follow the BPSC Prelims GS syllabus areas.
Every subtopic can serve 200 non-repeating questions: distinct fact questions first, then match-the-pair variants. Mental Ability is fully template-generated and endless.
