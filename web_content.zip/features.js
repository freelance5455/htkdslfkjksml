/* GarageLog 2.0: motorische Setups, Fahrwerk-Setups, persönliche Handbuchbibliothek.
 * PDFs werden lokal gespeichert; Textindex bei der ersten Aufnahme mittels PDF.js
 * (für die erstmalige Texterkennung ist eine Internetverbindung notwendig).
 */
'use strict';

Object.assign(ICON_PATHS, {
  engine:'<path d="M4 8h3l2-3h7l2 3h3v9h-4l-2 2H8l-2-2H3V9h1z"/><path d="M9 10h6M9 14h6"/>',
  suspension:'<path d="M8 2v20M16 2v20M5 6h6M13 6h6M5 18h6M13 18h6M5 10l6 4-6 4M19 10l-6 4 6 4"/>',
  book:'<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V3H6.5A2.5 2.5 0 0 0 4 5.5v14z"/><path d="M4 19.5C4 21 5 22 6.5 22H20v-5"/>',
  ai:'<path d="m12 2 2.3 6.5L21 11l-6.7 2.5L12 20l-2.3-6.5L3 11l6.7-2.5z"/><path d="M19 19h4m-2-2v4"/>',
  sliders:'<path d="M4 7h16M4 17h16M9 4v6M15 14v6"/>',
  link:'<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>'
});

const originalVehicleRender = renderVehicle;
let garagePdfjs = null;
const STOP_WORDS = new Set(['der','die','das','des','dem','den','ich','du','und','oder','ein','eine','einer','beim','für','von','mit','wie','viel','ist','sind','am','an','im','in','bei','welches','welche','was','steht','laut','bitte','meine','meinem','meiner','a','the','of','for']);
const TORQUE_SYNONYMS = [
  [/(drehmoment|anzugsdrehmoment|anziehen)/, ['torque','tightening','nm']],
  [/(hinterradachse|hinterachse|achsmutter)/, ['rear axle','rear wheel','axle nut']],
  [/(vorderradachse|vorderachse)/, ['front axle','front wheel']],
  [/(gabelklemmung|gabelbrücke)/, ['fork clamp','triple clamp']],
  [/(zylinderkopf|kopfschrauben)/, ['cylinder head','head bolt']],
  [/(ventilspiel)/, ['valve clearance','valve lash']],
  [/(zündkerze)/, ['spark plug']],
  [/(bremssattel)/, ['brake caliper']],
  [/(schwingenachse)/, ['swingarm pivot']],
  [/(motoröl|ölwechsel)/, ['engine oil','oil change']]
];
function ensureGarageData(){
  if(!state) return;
  if(!Array.isArray(state.manuals))state.manuals=[];
  if(!Array.isArray(state.torqueNotes))state.torqueNotes=[];
  for(const v of state.vehicles){if(!v.powertrain)v.powertrain={engine:'',fuel:''};if(!v.suspension)v.suspension={};if(!Array.isArray(v.suspensionPresets))v.suspensionPresets=[];}
}
function defaultEngine(v){
  if(v?.powertrain?.engine)return v.powertrain.engine;
  if(v?.id==='starter-varg')return 'electric';
  if(v?.id==='starter-sherco')return '2t';
  if(v?.id==='starter-m4')return '4t';
  return '';
}
function defaultFuel(v){if(v?.powertrain?.fuel)return v.powertrain.fuel;return v?.id==='starter-sherco'?'carb':v?.id==='starter-m4'?'injection':''}
function garageVehicleTabs(id){const tabs=[['overview','Übersicht','garage'],['engine','Motor-Setup','engine'],['suspension','Fahrwerk','suspension'],['manuals','Handbücher','book']];return `<div class="vehicle-tabs" role="tablist" aria-label="Fahrzeugbereiche">${tabs.map(([key,label,ico])=>`<button role="tab" aria-selected="${(ui.vehicleTab||'overview')===key}" class="vehicle-tab ${(ui.vehicleTab||'overview')===key?'active':''}" data-action="vehicle-tab" data-id="${esc(id)}" data-tab="${key}">${icon(ico,18)}<span>${label}</span></button>`).join('')}</div>`}
function featureHero(v){return `<div class="content-wrap"><button class="back-button" data-action="navigate" data-view="garage">${icon('back',15)} ZURÜCK ZUR GARAGE</button><div class="feature-hero"><div class="feature-hero-art">${visual(v)}</div><div><div class="eyebrow">FAHRZEUGAKTE · ${esc(kindLabel(v.kind).toUpperCase())}</div><h1>${esc(vehicleName(v))}</h1><p>${esc([v.year,v.plate].filter(Boolean).join(' · ')||'Deine Fahrzeugdaten')}</p></div></div>${garageVehicleTabs(v.id)}`}
renderVehicle=function(id){
  ensureGarageData();
  const v=getVehicle(id);if(!v)return originalVehicleRender(id);
  const tab=ui.vehicleTab||'overview';
  if(tab==='overview')return originalVehicleRender(id).replace('<div class="section-head"><h2>Was möchtest du eintragen?</h2></div>',`${garageVehicleTabs(id)}<div class="section-head"><h2>Was möchtest du eintragen?</h2></div>`);
  let content=tab==='engine'?renderEngineTab(v):tab==='suspension'?renderSuspensionTab(v):renderManualsTab(v);
  return featureHero(v)+content+'</div>';
};

function typeSelect(name,label,opts,value,attr=''){
  return `<div class="field"><label for="feature-${esc(name)}">${esc(label)}</label><select name="${esc(name)}" id="feature-${esc(name)}" ${attr}>${opts.map(([key,txt])=>`<option value="${esc(key)}" ${String(value??'')===String(key)?'selected':''}>${esc(txt)}</option>`).join('')}</select></div>`;
}
function specInput(name,label,source={},unit='',placeholder='',type='text',step='any'){
  const val=source[name]??'';return `<div class="field"><label for="spec-${esc(name)}">${esc(label)}${unit?` <span class="feature-unit">(${esc(unit)})</span>`:''}</label><input id="spec-${esc(name)}" name="${esc(name)}" type="${type}" ${type==='number'?`step="${esc(step)}"`:''} value="${esc(val)}" placeholder="${esc(placeholder)}"></div>`;
}
function specSection(title,ico,fields,source={}){
  return `<details class="feature-section" open><summary>${icon(ico,18)} ${esc(title)}<span class="fold-arrow">⌄</span></summary><div class="feature-field-grid">${fields.map(f=>specInput(f[0],f[1],source,f[2]||'',f[3]||'',f[4]||'text',f[5]||'any')).join('')}</div></details>`;
}
const ENGINE_FIELDS={
  general:[['engineCode','Motorkennung / Hubraum','','z. B. S55B30'],['power','Leistung','PS','optional','number'],['gearingFront','Ritzel vorne','Zähne','z. B. 13','number',1],['gearingRear','Kettenrad hinten','Zähne','z. B. 50','number',1],['fuelType','Kraftstoff / Oktanzahl','','z. B. 102 ROZ'],['airFilter','Luftfilter','','Hersteller / Modell'],['exhaust','Abgasanlage','','Hersteller / Umbau'],['coolant','Kühlmittel','','optional'],['sparkPlug','Zündkerze / Wärmewert','','optional']],
  twostroke:[['premix','Mischungsverhältnis','','z. B. 1:60'],['oil','2T-Ölsorte','','z. B. Motul 800'],['squish','Quetschkante','mm','gemessen','number'],['compVolume','Brennraumvolumen','cm³','gemessen','number'],['exhaustPort','Auslasssteuerung / Einstellung','','optional'],['reed','Membran / Ansaugung','','optional']],
  fourstroke:[['valveIntake','Ventilspiel Einlass','mm','gemessen','number'],['valveExhaust','Ventilspiel Auslass','mm','gemessen','number'],['cam','Nockenwelle / Steuerzeiten','','optional'],['boost','Ladedruck','bar','optional','number'],['compression','Verdichtung','','optional']],
  carb:[['carbMake','Vergaser-Hersteller','','z. B. Keihin'],['carbModel','Vergasermodell / Durchmesser','','z. B. PWK 38'],['mainJet','Hauptdüse','','z. B. 172'],['pilotJet','Leerlaufdüse','','z. B. 38'],['needle','Nadel','','z. B. NEDW'],['clip','Nadelclip-Position','','von oben gezählt'],['needleJet','Nadeldüse','','optional'],['slide','Schieber','','optional'],['airScrew','Luftschraube','Umdr.','ab leicht geschlossen','number'],['float','Schwimmerstand','mm','gemessen','number'],['idle','Standgas','U/min','','number']],
  injection:[['ecu','Steuergerät / ECU','','z. B. Microtec'],['ecuMap','Software / Map','','Versionsstand'],['injectors','Injektoren','','Teilenummer / Durchfluss'],['fuelPressure','Kraftstoffdruck','bar','gemessen','number'],['tps','TPS / Drosselklappensensor','','Einstellung'],['lambda','Lambda / AFR','','optional'],['ignition','Zündkennfeld / Zündwinkel','','optional']],
  electric:[['powerLimit','Leistungsbegrenzung','kW','optional','number'],['torqueLimit','Drehmomentlimit','Nm','nur wenn bekannt','number'],['regen','Rekuperation / Engine Brake','','Einstellung'],['throttleMap','Gasgriff- / Leistungskennlinie','','Map / Profil'],['traction','Traktionskontrolle','','Einstellung'],['battery','Akkustand / Kapazität','','optional'],['firmware','Firmware-Version','','optional']]
};
function renderEngineTab(v){
  const s=v.powertrain||{},eng=defaultEngine(v),fuel=defaultFuel(v);
  const txt=eng==='electric'?'Elektroantrieb hat keinen Vergaser oder Einspritzer.':eng?'Bei 2T und 4T kannst du Vergaser oder Einspritzung auswählen.':'Bitte zuerst den Antriebstyp auswählen.';
  return `<div class="feature-header"><div><div class="eyebrow">FAHRZEUGKONFIGURATION</div><h2>Motor- & Antriebssetup</h2><p>Deine aktuellen Einstellungen bleiben fahrzeugbezogen gespeichert.</p></div><span class="feature-tag">2T · 4T · Elektro</span></div>
  <form id="engine-setup-form" data-id="${esc(v.id)}" class="feature-form"><div class="panel"><h3>Motorart & Gemischaufbereitung</h3><div class="feature-field-grid">${typeSelect('engine','Antrieb',[['','Bitte auswählen'],['2t','2-Takt'],['4t','4-Takt'],['electric','Elektro']],eng)}<div id="feature-fuel-wrap">${typeSelect('fuel','Gemischaufbereitung',[['','Bitte auswählen'],['carb','Vergaser'],['injection','Einspritzung']],eng==='electric'?'':fuel)}</div></div><p id="engine-hint" class="small-note">${esc(txt)}</p></div>
  ${specSection('Allgemeine Motor- / Fahrzeugdaten','engine',ENGINE_FIELDS.general,s)}
  <div data-engine-only="2t">${specSection('2-Takt-spezifisch','sliders',ENGINE_FIELDS.twostroke,s)}</div>
  <div data-engine-only="4t">${specSection('4-Takt-spezifisch','sliders',ENGINE_FIELDS.fourstroke,s)}</div>
  <div data-engine-only="carb">${specSection('Vergaser – Bedüsung & Einstellung','sliders',ENGINE_FIELDS.carb,s)}</div>
  <div data-engine-only="injection">${specSection('Einspritzung – ECU & Sensoren','sliders',ENGINE_FIELDS.injection,s)}</div>
  <div data-engine-only="electric">${specSection('Elektro – Leistung & Fahrprofile','sliders',ENGINE_FIELDS.electric,s)}</div>
  <div class="panel"><div class="field"><label for="engine-notes">Zusätzliche Hinweise / Besonderheiten</label><textarea name="notes" id="engine-notes" placeholder="z. B. Bedüsung für eine bestimmte Höhe, Temperatur, Mapping ...">${esc(s.notes||'')}</textarea></div><button class="button" type="submit">${icon('save',16)} Motor-Setup speichern</button></div></form>`;
}
function updateEngineFields(){const e=document.querySelector('#engine-setup-form');if(!e)return;const engine=e.elements.engine.value;const fuel=e.elements.fuel.value;document.querySelector('#feature-fuel-wrap').hidden=(engine==='electric'||!engine);for(const section of e.querySelectorAll('[data-engine-only]')){const test=section.dataset.engineOnly;section.hidden=test!==engine&&(test!==fuel||engine==='electric');}const hint=document.querySelector('#engine-hint');if(hint)hint.textContent=engine==='electric'?'Beim Elektroantrieb entfallen Vergaser und Einspritzung.':engine?'Wähle danach die Gemischaufbereitung.':'Bitte zuerst den Antriebstyp auswählen.'}

const SUSPENSION_SECTIONS=[
  ['Vorderradgabel – Grunddaten','suspension',[
    ['forkBrand','Gabel / Hersteller','','z. B. KYB A-Kit'],['forkModel','Gabelmodell / Cartridge','','z. B. KYB 48 mm'],['forkDiameter','Standrohrdurchmesser','mm','','number'],['forkSpring','Gabelfederrate','N/mm','','number'],['forkPreload','Federvorspannung','mm','','number'],['forkAirGap','Luftkammer','mm','ohne Feder, eingefedert','number'],['forkOil','Gabelöl / Viskosität','','z. B. KYB 01M'],['forkOilVolume','Ölvolumen je Holm','ml','','number'],['forkTravel','Federweg vorn','mm','','number'],['forkHeight','Gabelüberstand','mm','oberhalb Gabelbrücke','number'],['forkBottoming','Durchschlagsreserve','mm','','number']]],
  ['Vorderradgabel – Dämpfung','sliders',[
    ['forkComp','Druckstufe','Klicks','von geschlossen','number'],['forkCompLow','Druckstufe Low-Speed','Klicks','','number'],['forkCompHigh','Druckstufe High-Speed','Umdr.','','number'],['forkRebound','Zugstufe','Klicks','von geschlossen','number'],['forkReboundLow','Zugstufe Low-Speed','Klicks','','number'],['forkReboundHigh','Zugstufe High-Speed','Umdr.','','number'],['forkBaseValve','Basevalve / Kolben','','optional'],['forkMidValve','Midvalve / Shimstack','','optional'],['forkBleed','Bleed / Entlüftung','','optional'],['forkCompressionStack','Compression Shimstack','','optional'],['forkReboundStack','Rebound Shimstack','','optional']]],
  ['Federbein – Grunddaten','suspension',[
    ['shockBrand','Hersteller / Modell','','z. B. KYB / Trax'],['shockSpring','Federhärte hinten','N/mm','','number'],['shockPreload','Vorspannung','mm','','number'],['shockLength','Federbeinlänge','mm','','number'],['shockStroke','Hub Federbein','mm','','number'],['shockRideHeight','Heckhöhe / Versteller','mm','','number'],['shockGas','Stickstoffdruck','bar','nur falls bekannt','number'],['shockOil','Dämpferöl / Spezifikation','','optional'],['shockLinkage','Umlenkung / Hebelverhältnis','','optional']]],
  ['Federbein – Dämpfung','sliders',[
    ['shockComp','Druckstufe','Klicks','','number'],['shockCompLow','Druckstufe Low-Speed','Klicks','','number'],['shockCompHigh','Druckstufe High-Speed','Umdr.','','number'],['shockRebound','Zugstufe','Klicks','','number'],['shockReboundHigh','Zugstufe High-Speed','Umdr.','','number'],['shockBaseValve','Basevalve / Kolben','','optional'],['shockCompressionStack','Compression Shimstack','','optional'],['shockReboundStack','Rebound Shimstack','','optional']]],
  ['Sag, Fahrer & Geometrie','sliders',[
    ['riderWeight','Fahrergewicht inkl. Ausrüstung','kg','','number'],['staticSag','Statischer Sag hinten','mm','','number'],['riderSag','Negativfederweg mit Fahrer','mm','','number'],['frontSag','Sag vorne','mm','','number'],['wheelbase','Radstand','mm','','number'],['barPosition','Lenkerposition / Neigung','°','','number'],['forkOffset','Gabelbrücken-Offset','mm','','number'],['seatHeight','Sitzhöhe','mm','','number']]],
  ['Reifen, Untergrund & Bedingungen','sliders',[
    ['frontTire','Reifen vorne','','Hersteller / Modell / Mischung'],['rearTire','Reifen hinten','','Hersteller / Modell / Mischung'],['frontPressure','Luftdruck vorne','bar','bei Luftreifen','number'],['rearPressure','Luftdruck hinten','bar','bei Luftreifen','number'],['frontMousse','Mousse vorn','','Marke / Zustand'],['rearMousse','Mousse hinten','','Marke / Zustand'],['terrain','Strecke / Untergrund','','Hard Enduro, Sand, MX ...'],['temperature','Außentemperatur','°C','','number'],['rideFeeling','Fahrverhalten / Symptome','','Durchschlagen, Hoppeln ...']]]
];
function renderSuspensionTab(v){const s=v.suspension||{},presets=v.suspensionPresets||[];return `<div class="feature-header"><div><div class="eyebrow">INDIVIDUELL EINSTELLBAR</div><h2>Fahrwerk-Setup</h2><p>KYB A-Kit als Vorlage – inklusive Klickern, Shims, Sag, Öl und Reifensetup.</p></div><span class="feature-tag">${presets.length} Setups gespeichert</span></div><div class="hint">${icon('info',18)} <span><strong>Einstellwerte sind bewusst leer:</strong> Es werden keine angeblichen KYB-Werkswerte vorgegeben. Klicks/Umdrehungen bitte entsprechend deiner tatsächlichen Versteller <strong>ab vollständig geschlossen</strong> notieren. Nicht jedes A-Kit besitzt alle Regler.</span></div>
  <form class="feature-form" id="suspension-setup-form" data-id="${esc(v.id)}"><div class="panel"><div class="feature-field-grid">${specInput('setupName','Name dieses Setups',s,'','z. B. Hard Enduro – nasse Wurzeln')}${typeSelect('suspensionTemplate','Fahrwerksvorlage',[['','Freie Konfiguration'],['kyb-akit','KYB A-Kit / Racing'],['kyb-standard','KYB Serie'],['wp','WP / Cone Valve / Trax'],['other','Andere']],s.suspensionTemplate||'kyb-akit')}</div><button class="button button-outline small" type="button" data-action="apply-kyb">${icon('suspension',15)} KYB A-Kit als Basis</button></div>
  ${SUSPENSION_SECTIONS.map(section=>specSection(section[0],section[1],section[2],s)).join('')}
  <div class="panel"><div class="field"><label for="suspension-notes">Notizen / Veränderungen / Testeindruck</label><textarea id="suspension-notes" name="notes" placeholder="Was wurde verändert, wie war das Ansprechverhalten?">${esc(s.notes||'')}</textarea></div><div class="feature-button-row"><button class="button" type="submit">${icon('save',16)} Aktuelles Setup sichern</button><button class="button button-outline" type="button" data-action="save-suspension-preset" data-id="${esc(v.id)}">${icon('copy',16)} Als Variante speichern</button></div></div></form>
  <div class="section-head"><h2>Gespeicherte Fahrwerksvarianten</h2><small>${presets.length} Setups</small></div>${presets.length?`<div class="preset-list">${[...presets].reverse().map(p=>`<div class="preset-item"><div><strong>${esc(p.label||'Unbenannt')}</strong><small>${niceDate(p.date)} · ${esc(p.data?.terrain||'ohne Streckenangabe')}</small></div><div class="feature-button-row"><button class="button button-outline small" data-action="restore-suspension-preset" data-id="${esc(p.id)}">Laden</button><button class="icon-button" data-action="delete-suspension-preset" data-id="${esc(p.id)}" aria-label="Setup löschen">${icon('trash',17)}</button></div></div>`).join('')}</div>`:emptyBlock('suspension','Noch keine Variante gespeichert','Beim Testen einfach jedes Fahrwerkssetup als eigene Variante sichern.')}`}
function readFormDetails(form,skip=[]){const result={};for(const [key,value] of new FormData(form)){if(skip.includes(key))continue;result[key]=String(value).trim()}return result}
async function saveEngineSetup(form){const v=getVehicle(form.dataset.id);if(!v)return;let fields=readFormDetails(form);if(fields.engine==='electric')fields.fuel='';v.powertrain=fields;if(await saveState())notify('Motor-Setup gespeichert.');render()}
async function saveSuspensionSetup(form){const v=getVehicle(form.dataset.id);if(!v)return false;v.suspension=readFormDetails(form);return await saveState()}
function applyKybTemplate(){const form=document.querySelector('#suspension-setup-form');if(!form)return;form.elements.forkBrand.value='KYB A-Kit';form.elements.suspensionTemplate.value='kyb-akit';notify('KYB A-Kit als Vorlage übernommen; alle Einstellwerte bleiben frei.');}

/* Handbücher liegen binär separat in IndexedDB; nur der Suchindex ist in der Datensicherung als Textmetadaten enthalten. */
function manualFileDb(method,key,data){return new Promise((resolve,reject)=>{if(!dbConnection||!dbConnection.objectStoreNames.contains('manualFiles'))return reject(new Error('Für PDF-Speicherung ist IndexedDB erforderlich. Öffne die App über HTTPS/localhost.'));const transaction=dbConnection.transaction('manualFiles',method==='get'?'readonly':'readwrite');const store=transaction.objectStore('manualFiles');const req=method==='put'?store.put(data,key):method==='delete'?store.delete(key):method==='clear'?store.clear():store.get(key);req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)})}
function bytesAsBase64(blob){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result).split(',')[1]);r.onerror=()=>reject(r.error||new Error('Lesefehler'));r.readAsDataURL(blob)})}
function base64AsBlob(base64,mime){const binary=atob(base64);const array=new Uint8Array(binary.length);for(let i=0;i<binary.length;i++)array[i]=binary.charCodeAt(i);return new Blob([array],{type:mime||'application/pdf'})}
async function loadPdfjs(){if(garagePdfjs)return garagePdfjs;
  try{garagePdfjs=await import('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.min.mjs');garagePdfjs.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.worker.min.mjs';return garagePdfjs}
  catch(error){throw new Error('PDF-Texterkennung benötigt beim ersten Import Internet (PDF.js konnte nicht geladen werden). Das Handbuch wird trotzdem gespeichert, ist dann aber nur zum Öffnen verfügbar.')}}
async function extractPages(file){
  if(/\.txt$/i.test(file.name)||file.type.startsWith('text/')){const t=await file.text();return [{number:1,text:t.slice(0,5000000)}]}
  const pdfjs=await loadPdfjs();const contents=new Uint8Array(await file.arrayBuffer());const doc=await pdfjs.getDocument({data:contents}).promise;
  const pages=[];let length=0;
  try{for(let n=1;n<=Math.min(doc.numPages,1500);n++){
    const page=await doc.getPage(n);const data=await page.getTextContent();const line=data.items.map(x=>x.str||'').join(' ').replace(/\s+/g,' ').trim();length+=line.length;
    pages.push({number:n,text:line.slice(0,90000)});if(length>18000000)break;
  }}finally{await doc.destroy()}
  return pages;
}
function manualsFor(vId){ensureGarageData();return state.manuals.filter(m=>m.vehicleId===vId)}
function renderManualsTab(v){
  const manuals=manualsFor(v.id),noteCount=state.torqueNotes.filter(x=>x.vehicleId===v.id).length;
  return `<div class="feature-header"><div><div class="eyebrow">DEINE WERKSTATTDOKUMENTATION</div><h2>Werkstatthandbücher</h2><p>PDFs lokal ablegen, Textstellen suchen und mit Quellenangabe an ChatGPT übergeben.</p></div><span class="feature-tag">${manuals.length} Dokumente</span></div>
  <div class="manual-highlight">${icon('book',23)} <div><strong>Drehmoment direkt im Handbuch suchen</strong><p>Beispiel: „Drehmoment Hinterradachse“ oder „Anzugsdrehmoment Zylinderkopf“. Die App zeigt die passende PDF-Seite und einen Textausschnitt. Sie erfindet keine Drehmomentwerte.</p></div></div>
  <div class="panel"><h3>Neues Handbuch hinterlegen</h3><label class="upload-zone manual-upload">${icon('upload',25)}<span>PDF- oder TXT-Handbuch auswählen</span><small>Max. 35 MB pro Dokument · PDF-Datei wird nur lokal gespeichert</small><input type="file" id="manual-file-input" data-id="${esc(v.id)}" accept=".pdf,.txt,application/pdf,text/plain" multiple></label><p class="small-note">Die PDF-Textsuche benötigt beim erstmaligen Einlesen Internet. Einmal eingelesene Seiten bleiben danach offline durchsuchbar. Bildscans ohne Text benötigen zusätzliche OCR.</p><div id="manual-import-status" class="feature-status" aria-live="polite"></div></div>
  <div class="section-head"><h2>Handbuchbibliothek</h2></div>
  ${manuals.length?`<div class="manual-list">${manuals.map(m=>`<div class="manual-item"><div class="manual-icon">${icon('book',24)}</div><div class="manual-description"><strong>${esc(m.name)}</strong><small>${esc([m.pageCount?`${m.pageCount} Seiten`:'Seitenzahl unbekannt',m.indexed?'Textsuche bereit':'nicht indiziert'].join(' · '))}</small></div><div class="feature-button-row"><button class="button button-outline small" data-action="open-manual" data-id="${esc(m.id)}">${icon('book',14)} Öffnen</button>${!m.indexed?`<button class="button button-outline small" data-action="index-manual" data-id="${esc(m.id)}">Indizieren</button>`:''}<button class="icon-button" data-action="delete-manual" data-id="${esc(m.id)}" aria-label="Handbuch löschen">${icon('trash',17)}</button></div></div>`).join('')}</div>`:emptyBlock('book','Noch keine Handbücher','Lade die Werkstatthandbücher deiner Fahrzeuge als PDF hoch.')}
  <div class="section-head"><h2>Suche im Werkstatthandbuch</h2></div>
  <div class="panel"><div class="manual-search-line"><label class="search-wrap">${icon('search',20)}<input type="search" id="manual-search-input" data-id="${esc(v.id)}" aria-label="Handbücher durchsuchen" placeholder="z. B. Drehmoment Hinterradachse" value="${esc(ui.manualQuery||'')}"></label><button class="button" data-action="search-manual" data-id="${esc(v.id)}">Suchen</button></div><div id="manual-results">${renderManualSearch(v.id)}</div></div>
  <div class="section-head"><h2>Eigene Drehmoment-Notizen <span class="data-badge">${noteCount}</span></h2></div>
  <div class="panel"><p class="small-note">Hier kannst du geprüfte Drehmomente mit Bauteil und Handbuchseite für den schnellen Zugriff ablegen.</p><form id="torque-note-form" data-id="${esc(v.id)}"><div class="feature-field-grid">${specInput('component','Bauteil',{},'','z. B. Hinterradachse')}${specInput('torque','Drehmoment',{},'Nm','Wert lt. Handbuch','number')}${specInput('source','Quelle / PDF-Seite',{},'','z. B. Sherco WHB S. 87')}${specInput('conditions','Hinweis / Bedingungen',{},'','trocken, geölt ...')}</div><button class="button" type="submit">${icon('plus',15)} Geprüften Wert speichern</button></form><div class="torque-list">${state.torqueNotes.filter(x=>x.vehicleId===v.id).map(n=>`<div class="torque-row"><div><strong>${esc(n.component)}</strong><small>${esc([n.source,n.conditions].filter(Boolean).join(' · ')||'Quelle nicht angegeben')}</small></div><div class="torque-value">${esc(n.torque)} Nm</div><button data-action="delete-torque" data-id="${esc(n.id)}" class="icon-button" aria-label="Drehmomentnotiz löschen">${icon('trash',16)}</button></div>`).join('')}</div></div>
  <div class="hint">${icon('ai',18)} <span><strong>ChatGPT-Hilfe:</strong> Mit „An ChatGPT übergeben“ kopiert GarageLog deine Frage, das genaue Handbuch und die gefundene Seitenstelle. ChatGPT wird separat geöffnet; dort musst du die kopierte Frage noch einfügen. <strong>Keine automatische Konto- oder API-Verbindung</strong> und kein heimlicher Upload deiner Handbücher.</span></div>`;
}
function normalizeQuery(s){return String(s||'').toLocaleLowerCase('de').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ß/g,'ss')}
function searchManualPages(vehicleId,query){const normalized=normalizeQuery(query).replace(/[^\p{L}\p{N}]+/gu,' ').trim();if(!normalized)return[];
  let tokens=normalized.split(/\s+/).filter(w=>w.length>1&&!STOP_WORDS.has(w));if(!tokens.length)return[];
  const expansions=TORQUE_SYNONYMS.filter(([re])=>re.test(normalized)).flatMap(([,terms])=>terms);
  const results=[];for(const manual of manualsFor(vehicleId)){for(const page of(manual.pages||[])){
    const txt=normalizeQuery(page.text);let score=0;const matched=[];
    for(const word of tokens){if(txt.includes(word)){score+=word.length>5?4:2;matched.push(word)}}
    for(const term of expansions){if(txt.includes(term)){score+=1;matched.push(term)}}
    if(txt.includes(normalized))score+=12;
    if(!score)continue;
    const anchor=matched.map(word=>txt.indexOf(word)).filter(x=>x>=0).sort((a,b)=>a-b)[0]??0;
    const start=Math.max(0,anchor-180),stop=Math.min(page.text.length,anchor+490);
    results.push({manual,page:page.number,score,excerpt:(start?'…':'')+page.text.slice(start,stop)+(stop<page.text.length?'…':'')});
  }}return results.sort((a,b)=>b.score-a.score||a.page-b.page).slice(0,18);
}
function renderManualSearch(vId){const q=String(ui.manualQuery||'').trim();if(!q)return `<p class="small-note">Gib einen Begriff oder eine Frage ein. Die Suche läuft lokal im Text deiner hinterlegten Handbücher.</p>`;
  const hits=searchManualPages(vId,q);ui.manualHits=hits;
  if(!hits.length)return `<div class="search-empty">${icon('search',24)} Keine passenden Textstellen. Prüfe die Schreibweise, suche einzelne Bauteile oder indiziere das PDF erneut. Bildscans benötigen OCR.</div>`;
  return `<div class="manual-result-title">${hits.length} Treffer nach Relevanz · ${esc(q)}</div><div class="manual-results">${hits.map((h,i)=>`<div class="manual-result"><div class="manual-result-head"><strong>${esc(h.manual.name)}</strong><span>Seite ${h.page}</span></div><p>${esc(h.excerpt)}</p><div class="feature-button-row"><button class="button button-outline small" data-action="open-manual" data-id="${esc(h.manual.id)}" data-page="${h.page}">${icon('book',14)} Seite ansehen</button><button class="button button-quiet small" data-action="ask-chatgpt" data-index="${i}" data-id="${esc(vId)}">${icon('ai',15)} An ChatGPT übergeben</button></div></div>`).join('')}</div>`;
}

async function addManual(file,vehicleId){
  if(!getVehicle(vehicleId))throw new Error('Fahrzeug nicht gefunden.');
  if(!(/\.pdf$/i.test(file.name)||/\.txt$/i.test(file.name)))throw new Error('Erlaubt sind PDF und TXT.');
  if(file.size>35*1024*1024)throw new Error(`${file.name}: maximal 35 MB pro Datei.`);
  if(manualsFor(vehicleId).length>=30)throw new Error('Maximal 30 Handbücher pro Fahrzeug.');
  const doc={id:uid(),vehicleId,name:file.name.slice(0,160),mime:/\.txt$/i.test(file.name)?'text/plain':'application/pdf',size:file.size,addedAt:Date.now(),indexed:false,pageCount:null,pages:[]};
  await manualFileDb('put',doc.id,file);
  try{
    const pages=await extractPages(file);
    doc.pages=pages;doc.pageCount=pages.length;doc.indexed=pages.some(p=>p.text.length>25);
    if(!doc.indexed)notify('PDF gespeichert. Keine durchsuchbare Textebene erkannt (Scan?).');
  }catch(e){console.warn('PDF nicht indiziert:',e);doc.indexError=e.message;notify('PDF gespeichert, aber Suchindex noch nicht verfügbar. Öffnen funktioniert.',true)}
  state.manuals.push(doc);
  if(!await saveState()){state.manuals=state.manuals.filter(m=>m.id!==doc.id);await manualFileDb('delete',doc.id);throw new Error('Speichern des Handbuchs fehlgeschlagen.')}
  return doc;
}
async function addManualBatch(files,vehicleId){const status=document.querySelector('#manual-import-status');for(const file of files){if(status)status.textContent=`${file.name} wird abgelegt und eingelesen ...`;try{await addManual(file,vehicleId)}catch(e){notify(e.message,true)}}if(ui.view==='vehicle'&&ui.vehicleTab==='manuals')render();notify('Handbuchimport abgeschlossen.');}
async function reindexManual(id){const doc=state.manuals.find(m=>m.id===id);if(!doc)return;const file=await manualFileDb('get',id);if(!file){notify('PDF-Datei fehlt; bitte erneut importieren.',true);return}notify('Handbuch wird erneut indiziert ...');try{const pages=await extractPages(new File([file],doc.name,{type:doc.mime}));doc.pages=pages;doc.pageCount=pages.length;doc.indexed=pages.some(p=>p.text.length>25);doc.indexError='';await saveState();render();notify(doc.indexed?'Suchindex aktualisiert.':'Keine Textebene gefunden – eventuell Bildscan.')}catch(e){notify(e.message,true)}}
async function openManualPdf(id,page){const doc=state.manuals.find(m=>m.id===id);if(!doc)return;try{const blob=await manualFileDb('get',id);if(!blob){notify('Datei fehlt, bitte PDF neu importieren.',true);return}const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url+(doc.mime==='application/pdf'&&page?`#page=${Number(page)}`:'');link.target='_blank';link.rel='noopener noreferrer';link.click();setTimeout(()=>URL.revokeObjectURL(url),120000);}catch(e){notify(e.message,true)}}
async function deleteManual(id){const m=state.manuals.find(x=>x.id===id);if(!m||!confirm(`Handbuch „${m.name}“ endgültig löschen?`))return;const old=state.manuals;state.manuals=old.filter(x=>x.id!==id);if(await saveState()){try{await manualFileDb('delete',id)}catch(e){console.error(e)}render();notify('Handbuch gelöscht.')}else state.manuals=old;}
async function clearManualsForVehicle(id){for(const m of manualsFor(id)){try{await manualFileDb('delete',m.id)}catch(e){console.warn(e)}}state.manuals=state.manuals.filter(m=>m.vehicleId!==id);state.torqueNotes=state.torqueNotes.filter(m=>m.vehicleId!==id)}
async function clearAllManuals(){try{await manualFileDb('clear')}catch(e){console.warn(e)}}

async function copyToClipboard(text){if(navigator.clipboard?.writeText){try{await navigator.clipboard.writeText(text);return true}catch(e){console.warn(e)}}const ta=document.createElement('textarea');ta.value=text;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();let okay=false;try{okay=document.execCommand('copy')}catch(e){}ta.remove();return okay}
async function askChatGpt(index){const hit=(ui.manualHits||[])[index];if(!hit){notify('Suche bitte zuerst im Handbuch.',true);return}const v=getVehicle(hit.manual.vehicleId),q=ui.manualQuery||'';
  const request=`Bitte hilf mir mit dem Werkstatthandbuch-Auszug bei folgender Frage: ${q}\nFahrzeug: ${vehicleName(v||{})} (${v?.year||'Baujahr nicht angegeben'})\nQuelle: ${hit.manual.name}, PDF-Seite ${hit.page}.\nOriginal-Auszug:\n${hit.excerpt}\n\nAntworte nur mit Informationen, die aus dem Auszug zuverlässig hervorgehen. Nenne die Quelle und Seite. Falls Drehmoment, Gewindeausführung, Baujahr, Schmierung oder Einheit aus dem Text nicht eindeutig hervorgehen, sage das deutlich und fordere die vollständige Handbuchseite an. Erfinde keine Werte.`;
  const pasted=await copyToClipboard(request);
  if(pasted){notify('Frage und Quellenstelle kopiert. In ChatGPT einfügen.');window.open('https://chatgpt.com/','_blank','noopener,noreferrer')}
  else{window.prompt('Text für ChatGPT kopieren:',request)}
}

/* Backups: PDF-Dateien werden als base64 mit exportiert, nicht nur der Suchindex. */
async function exportJson(){
  ensureGarageData();notify('Erstelle vollständige Sicherung inklusive Handbüchern ...');
  const backup={...state,version:2,exportedAt:new Date().toISOString(),manualAttachments:[]};
  for(const manual of state.manuals){try{const blob=await manualFileDb('get',manual.id);if(!blob)throw new Error('Datei nicht mehr auf diesem Gerät');backup.manualAttachments.push({id:manual.id,mime:manual.mime,base64:await bytesAsBase64(blob)})}catch(e){notify(`Sicherung abgebrochen: Handbuch „${manual.name}“ fehlt.`,true);return}}
  saveFile(new Blob([JSON.stringify(backup)],{type:'application/json'}),`garagelog-sicherung-${localToday()}.json`);
  notify(`Sicherung mit ${state.manuals.length} Handbüchern erstellt.`);
}
async function importJson(file){
  if(!file)return;if(file.size>300*1024*1024){notify('Sicherungsdatei zu groß (max. 300 MB).',true);return}
  let next;try{next=verifyData(JSON.parse(await file.text()));}catch(e){notify(`Import fehlgeschlagen: ${e.message}`,true);return}
  const old=state;const docs=Array.isArray(next.manuals)?next.manuals:[];
  if(docs.length&&!dbConnection){notify('Für Handbücher benötigst du IndexedDB. Bitte die HTTPS-Version öffnen.',true);return}
  const attachments=new Map((next.manualAttachments||[]).map(x=>[x.id,x]));
  if(docs.some(d=>!attachments.has(d.id))){notify('Import abgebrochen: Handbuch-Dateien fehlen in der Sicherung. Bitte eine vollständige GarageLog-Sicherung nutzen.',true);return}
  if(!confirm(`Sicherung importieren? Deine aktuellen ${old.vehicles.length} Fahrzeuge, ${old.records.length} Arbeiten und ${(old.manuals||[]).length} Handbücher werden ersetzt.`))return;
  const rollback=new Map();
  try{
    // Die Originaldateien bleiben bei einem Speicherfehler bis zum erfolgreichen Import erhalten.
    for(const m of old.manuals||[]){const blob=await manualFileDb('get',m.id);if(blob)rollback.set(m.id,blob)}
    for(const d of docs){const a=attachments.get(d.id);await manualFileDb('put',d.id,base64AsBlob(a.base64,a.mime))}
    delete next.manualAttachments;next.manuals=docs;next.torqueNotes=Array.isArray(next.torqueNotes)?next.torqueNotes:[];next.introDismissed=true;
    state=next;if(!await saveState())throw new Error('Datenspeicher nicht beschreibbar');
    for(const m of old.manuals||[]){if(!docs.some(d=>d.id===m.id))await manualFileDb('delete',m.id)}
    ui.view='garage';ui.selectedVehicle=null;ui.vehicleTab='overview';ui.manualQuery='';render();notify('Sicherung inklusive Handbüchern importiert.');
  }catch(e){state=old;for(const [id,blob] of rollback)try{await manualFileDb('put',id,blob)}catch{}await saveState();notify(`Import fehlgeschlagen: ${e.message}`,true)}
}

function onGarageFeatureClick(event,el){const action=el.dataset.action;
  switch(action){
    case'open-vehicle':ui.vehicleTab='overview';return false;
    case'vehicle-tab':ui.vehicleTab=el.dataset.tab||'overview';ui.manualQuery='';ui.manualHits=[];render();window.scrollTo({top:0,behavior:'instant'});return true;
    case'apply-kyb':applyKybTemplate();return true;
    case'save-suspension-preset':{
      (async()=>{const form=document.querySelector('#suspension-setup-form');if(!form||!getVehicle(form.dataset.id))return;const v=getVehicle(form.dataset.id);if(!await saveSuspensionSetup(form))return;const p={id:uid(),date:localToday(),label:v.suspension.setupName||`Setup ${v.suspensionPresets.length+1}`,data:{...v.suspension}};v.suspensionPresets.push(p);if(v.suspensionPresets.length>150)v.suspensionPresets.shift();if(await saveState()){render();notify('Fahrwerksvariante gespeichert.')}})();return true}
    case'restore-suspension-preset':{
      (async()=>{const v=getVehicle(ui.selectedVehicle);const p=v?.suspensionPresets?.find(x=>x.id===el.dataset.id);if(!p)return;if(!confirm(`Fahrwerk-Setup „${p.label}“ als aktuelles Setup laden?`))return;v.suspension={...p.data};if(await saveState()){render();notify('Fahrwerkssetup geladen.')}})();return true}
    case'delete-suspension-preset':{
      (async()=>{const v=getVehicle(ui.selectedVehicle);const p=v?.suspensionPresets?.find(x=>x.id===el.dataset.id);if(!p||!confirm(`Variante „${p.label}“ löschen?`))return;v.suspensionPresets=v.suspensionPresets.filter(x=>x.id!==el.dataset.id);if(await saveState()){render();notify('Variante gelöscht.')}})();return true}
    case'open-manual':openManualPdf(el.dataset.id,el.dataset.page);return true;
    case'index-manual':reindexManual(el.dataset.id);return true;
    case'delete-manual':deleteManual(el.dataset.id);return true;
    case'search-manual':{ui.manualQuery=document.querySelector('#manual-search-input')?.value||'';document.querySelector('#manual-results').innerHTML=renderManualSearch(el.dataset.id);return true}
    case'ask-chatgpt':askChatGpt(Number(el.dataset.index));return true;
    case'delete-torque':{
      (async()=>{const note=state.torqueNotes?.find(x=>x.id===el.dataset.id);if(!note||!confirm(`Drehmomentwert „${note.component}“ löschen?`))return;state.torqueNotes=state.torqueNotes.filter(x=>x.id!==el.dataset.id);if(await saveState()){render();notify('Drehmomentwert gelöscht.')}})();return true}
    case'delete-vehicle':{
      (async()=>{const v=getVehicle(el.dataset.id);if(!v)return;const docs=manualsFor(v.id).length;if(!confirm(`„${vehicleName(v)}“, ${recordsOf(v.id).length} Arbeiten und ${docs} Handbücher endgültig löschen?`))return;await clearManualsForVehicle(v.id);state.vehicles=state.vehicles.filter(x=>x.id!==v.id);state.records=state.records.filter(x=>x.vehicleId!==v.id);if(await saveState()){navigate('garage');notify('Fahrzeug inklusive Handbüchern gelöscht.')}})();return true}
    case'delete-all':{
      (async()=>{if(!confirm('Wirklich alle Fahrzeuge, Fotos, PDFs und Wartungseinträge löschen? Dies kann nicht rückgängig gemacht werden.'))return;await clearAllManuals();state={version:2,introDismissed:true,vehicles:[],records:[],manuals:[],torqueNotes:[]};if(await saveState()){navigate('garage');notify('Alle Daten gelöscht.')}})();return true}
    default:return false;
  }
}
function onGarageFeatureChange(event,target){if(target.id==='manual-file-input'){
  const files=Array.from(target.files||[]);target.value='';if(files.length)addManualBatch(files,target.dataset.id);return true;
}
  if(target.id==='feature-engine'||target.id==='feature-fuel'){updateEngineFields();return true}
  return false;
}
function onGarageFeatureSubmit(event){const form=event.target;
  if(form.id==='engine-setup-form'){event.preventDefault();saveEngineSetup(form);return true}
  if(form.id==='suspension-setup-form'){event.preventDefault();saveSuspensionSetup(form).then(ok=>{if(ok)notify('Aktuelles Fahrwerk-Setup gespeichert.')});return true}
  if(form.id==='torque-note-form'){event.preventDefault();const values=readFormDetails(form),v=getVehicle(form.dataset.id);if(!v)return true;if(!values.component||!values.torque){notify('Bauteil und Drehmomentwert eingeben.',true);return true}
    const n=parseNumber(values.torque);if(n===null||n<=0){notify('Ungültiger Nm-Wert.',true);return true}
    state.torqueNotes.push({id:uid(),vehicleId:v.id,component:values.component,torque:n,source:values.source,conditions:values.conditions});saveState().then(ok=>{if(ok){render();notify('Geprüfter Drehmomentwert gespeichert.')}});return true;
  }return false;
}
function onGarageFeatureInput(event){if(event.target.id==='manual-search-input'){
    // Suche mit Enter oder Schaltfläche; keine kostenpflichtige KI-Aktion.
    return;
  }
}
window.GarageLogFeatures={onClick:onGarageFeatureClick,onChange:onGarageFeatureChange,onSubmit:onGarageFeatureSubmit,onInput:onGarageFeatureInput,afterRender:()=>{updateEngineFields()}};

document.addEventListener('keydown',event=>{if(event.key==='Enter'&&event.target.id==='manual-search-input'){event.preventDefault();ui.manualQuery=event.target.value;document.querySelector('#manual-results').innerHTML=renderManualSearch(ui.selectedVehicle)}});
document.addEventListener('DOMContentLoaded',()=>{updateEngineFields()});
