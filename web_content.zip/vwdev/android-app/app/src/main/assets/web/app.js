const $=id=>document.getElementById(id),today=()=>{const d=new Date(),p=n=>String(n).padStart(2,'0');return d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate())};const esc=s=>String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));let me=null,profile=null,quizState=null,quizTimer=null,activeMember=null,members={};
const VW_AVATARS=Array.from({length:12},(_,i)=>'devotee_'+String(i+1).padStart(2,'0'));function avatarFor(x){return VW_AVATARS.includes(x)?x:VW_AVATARS[0];}function avatarHtml(x,cls='leader-avatar'){return '<img class="'+cls+'" src="avatars/'+esc(avatarFor(x))+'.svg" alt="Devotee avatar">';}
function activeKey(){return activeMember?.id||'you'}
function memberPath(feature,extra=''){return feature+'/'+me.uid+'/'+activeKey()+(extra?'/'+extra:'')}
function memberLocalKey(prefix){return 'vw_'+prefix+'_'+me.uid+'_'+activeKey()}
function readMemberLocal(prefix){try{return JSON.parse(localStorage.getItem(memberLocalKey(prefix))||'{}')}catch(e){return {}}}
function writeMemberLocal(prefix,v){localStorage.setItem(memberLocalKey(prefix),JSON.stringify(v))}
const RELATIONS=['You','Son','Daughter','Wife','Husband','Father','Mother','Brother','Sister','Other'];
async function ensureMembers(){
  const base=await db.ref('users/'+me.uid+'/members').once('value');
  members=base.val()||{};
  if(!members.you){members.you={id:'you',name:profile.name||'You',relation:'You',createdAt:Date.now(),updatedAt:Date.now()};await db.ref('users/'+me.uid+'/members/you').set(members.you)}
  if(!activeMember||!members[activeMember.id]) activeMember=members[localStorage.getItem('vwActiveMember_'+me.uid)]||members.you;
}
async function showMemberChooser(force=true){
  await ensureMembers();
  const list=Object.values(members);
  if(!force && list.length<=1)return;
  let box=document.getElementById('memberChooser');
  if(!box){box=document.createElement('div');box.id='memberChooser';box.className='member-overlay';document.body.appendChild(box)}
  box.innerHTML=`<div class="member-modal"><div class="eyebrow">VAISHNAV WORLD</div><h2>Who is using the app?</h2><p class="muted">Choose the member whose bhakti data you want to use.</p><div class="member-list">${list.map(m=>`<button class="member-choice" data-mid="${esc(m.id)}">${avatarHtml(m.avatar,'member-avatar-img')}<span><b>${esc(m.name)}</b><small>${esc(m.relation||'Member')}</small></span><strong>›</strong></button>`).join('')}</div><button class="secondary" id="openAddMember">+ Add Member</button></div>`;
  box.classList.add('show');
  box.querySelectorAll('.member-choice').forEach(b=>b.onclick=async()=>{await switchMember(b.dataset.mid);box.classList.remove('show')});
  document.getElementById('openAddMember').onclick=()=>openAddMember();
}
async function switchMember(id){await ensureMembers();if(!members[id])return;activeMember=members[id];localStorage.setItem('vwActiveMember_'+me.uid,id);profile={...profile,...activeMember};$('hello').textContent='Hare Krishna, '+activeMember.name;$('profileName').textContent=activeMember.name;const av=$('avatarPicker');if(av)av.innerHTML=avatarHtml(activeMember.avatar||profile.avatar,'avatar-image');const hav=$('homeAvatar');if(hav)hav.innerHTML=avatarHtml(activeMember.avatar||profile.avatar,'avatar-image');$('profilePhone').textContent=(activeMember.relation||'Member')+' · +91 '+(activeMember.mobile||profile.mobile||'');loadAll();page('home');loadBirthdayCard();}
function openAddMember(){
 let box=document.getElementById('addMemberModal');if(!box){box=document.createElement('div');box.id='addMemberModal';box.className='member-overlay';document.body.appendChild(box)}
 box.innerHTML=`<div class="member-modal"><div class="eyebrow">FAMILY / MEMBER</div><h2>Add Member</h2><p class="muted">Each member gets separate quiz, shlok, japa, challenge and progress data.</p><label>Name</label><input id="newMemberName" maxlength="60" placeholder="Member name"><label>Relation</label><select id="newMemberRelation">${RELATIONS.filter(x=>x!=='You').map(x=>`<option>${x}</option>`).join('')}</select><label>Mobile (optional)</label><input id="newMemberMobile" inputmode="numeric" maxlength="10" placeholder="10 digit mobile"><label>Gender</label><select id="newMemberGender"><option value="">Select gender</option><option>Male</option><option>Female</option><option>Other</option></select><label>Date of Birth</label><input id="newMemberDob" type="date"><div class="actions"><button class="ghost" id="cancelMember">Cancel</button><button class="primary" id="saveMember">Add Member</button></div></div>`;
 box.classList.add('show');document.getElementById('cancelMember').onclick=()=>box.classList.remove('show');document.getElementById('saveMember').onclick=async()=>{const name=$('newMemberName').value.trim(),relation=$('newMemberRelation').value,mobile=$('newMemberMobile').value.replace(/\D/g,''),dob=$('newMemberDob').value||'';if(name.length<2)return toast('Enter member name.');if(mobile&&mobile.length!==10)return toast('Enter a valid mobile or leave it empty.');if(!dob)return toast('Select date of birth.');const id='m_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7);const gender=$('newMemberGender').value;if(!['Male','Female','Other'].includes(gender))return toast('Select gender.');const m={id,name,relation,mobile,dob,gender,createdAt:Date.now(),updatedAt:Date.now()};await db.ref('users/'+me.uid+'/members/'+id).set(m);members[id]=m;box.classList.remove('show');toast(name+' added');showMemberChooser(false)};
}

function toast(t){$('toast').textContent=t;$('toast').style.display='block';setTimeout(()=>$('toast').style.display='none',2200)}
function page(p){const old=document.querySelector('.page.active')?.id;if(old==='japa'&&p!=='japa'&&musicSource==='japa'){stopMeditationMusic();}if(old==='quiz'&&p!=='quiz'){if(quizTimer)clearInterval(quizTimer);quizTimer=null;if(quizStartedMusic||musicSource==='quiz')stopMeditationMusic();quizStartedMusic=false;quizState=null;}document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));$(p)?.classList.add('active');document.querySelectorAll('[data-page]').forEach(x=>x.classList.toggle('active',x.dataset.page===p));window.scrollTo(0,0);if(p==='notifications')loadNotifications();if(p==='calendar')loadCalendar();if(p==='ekadashi')loadEkadashi();if(p==='japa'&&musicSource!=='japa'){stopMeditationMusic();startMeditationMusic('japa');}if(p==='quiz'){loadQuiz();loadQuizHistory();}if(p==='course')loadCourses();if(p==='shlok')loadShlokChallenge();}
document.addEventListener('click',e=>{const b=e.target.closest('[data-page]');if(b)page(b.dataset.page)});
async function signIn(){const n=$('loginName').value.trim(),m=$('loginMobile').value.replace(/\D/g,''),dob=$('loginDob').value||'';if(n.length<2||m.length!==10)return toast('Enter valid name and 10 digit mobile.');if(!dob)return toast('Select your date of birth.');const g=$('loginGender')?.value||'';if(!g)return toast('Select your gender.');profile={name:n,mobile:m,dob,gender:g};const code=String(Math.floor(100000+Math.random()*900000));sessionStorage.vwCode=code;sessionStorage.vwPending=JSON.stringify(profile);$('demoCode').textContent=code;$('login1').classList.add('hidden');$('login2').classList.remove('hidden')}
$('sendCode').onclick=signIn;$('backLogin').onclick=()=>{$('login2').classList.add('hidden');$('login1').classList.remove('hidden')};$('verifyCode').onclick=async()=>{if($('loginCode').value.trim()!==sessionStorage.vwCode)return toast('Code does not match.');try{const p=JSON.parse(sessionStorage.vwPending);let cred;if(auth.currentUser){cred={user:auth.currentUser}}else{cred=await auth.signInAnonymously()}const u=cred.user;await db.ref('users/'+u.uid).update({...p,uid:u.uid,authType:'anonymous',schemaVersion:2,registeredAt:Date.now(),updatedAt:Date.now()});profile={...p,uid:u.uid,schemaVersion:2};await db.ref('users/'+u.uid+'/members/you').update({id:'you',name:p.name,relation:'You',mobile:p.mobile,dob:p.dob,gender:p.gender,updatedAt:Date.now()});sessionStorage.removeItem('vwCode');sessionStorage.removeItem('vwPending');showApp()}catch(e){console.error(e);toast('Firebase login error: '+(e.code||e.message))}};
async function saveNativeFcmToken(){try{if(window.AndroidFCM&&me){const t=window.AndroidFCM.getToken();if(t)await db.ref('fcmTokens/'+encodeURIComponent(t)).set({token:t,ownerUid:me.uid,memberId:activeKey(),updatedAt:Date.now()});}}catch(e){console.log('native FCM token not saved',e)}}
async function showApp(){me=auth.currentUser;if(!me)return;$('auth').classList.add('hidden');$('app').classList.remove('hidden');$('hello').textContent='Hare Krishna, '+profile.name;$('profileName').textContent=profile.name;const av=$('avatarPicker');if(av)av.innerHTML=avatarHtml(activeMember?.avatar||profile.avatar,'avatar-image');const hav=$('homeAvatar');if(hav)hav.innerHTML=avatarHtml(activeMember?.avatar||profile.avatar,'avatar-image');$('profilePhone').textContent='+91 '+profile.mobile;await ensureMembers();await saveNativeFcmToken();loadAll();page('home');loadBirthdayCard();if(Object.keys(members).length>1 && !localStorage.getItem('vwActiveMember_'+me.uid))await showMemberChooser(true)}
$('logout').onclick=async()=>{
  // Keep the anonymous Firebase session so this device returns to the same UID.
  // This is a local app lock/sign-out screen, not Firebase account deletion.
  $('app').classList.add('hidden');$('auth').classList.remove('hidden');
  $('login1').classList.remove('hidden');$('login2').classList.add('hidden');
  $('loginName').value=profile?.name||'';$('loginMobile').value=profile?.mobile||'';
  $('loginDob').value=profile?.dob||'';$('loginGender').value=profile?.gender||'';
  toast('Signed out on this screen. Your saved profile and progress are kept.');
};
async function loadProfile(){const s=await db.ref('users/'+me.uid).once('value');profile=s.val()||profile;profile.uid=me.uid;$('hello').textContent='Hare Krishna, '+profile.name;$('profileName').textContent=profile.name;$('profilePhone').textContent='+91 '+profile.mobile}
function japaLocalKey(){return memberLocalKey('Japa')}
function readLocalJapa(){try{return JSON.parse(localStorage.getItem(japaLocalKey())||'{}')}catch(e){return {}}}
function writeLocalJapa(v){localStorage.setItem(japaLocalKey(),JSON.stringify(v))}
function japaView(total){
  total=Number(total||0);
  const mala=Math.floor(total/108),current=total%108;
  $('beadCount').textContent=current;$('japaToday').textContent=total;try{if(window.AndroidOverlay)AndroidOverlay.update('📿 '+current+'/108 · +1');}catch(e){}$('malaCount').textContent=mala;$('homeMala').textContent=mala;$('homeMala').title=total+' beads today';
  const pct=Math.min(100,current/108*100),ring=document.querySelector('.ring');
  if(ring)ring.style.background=`radial-gradient(circle,#fff 60%,transparent 61%),conic-gradient(var(--cyan) 0%,var(--blue) ${pct}%,#e4edf8 ${pct}%,#e4edf8 100%)`;
}
function japaChartHtml(v){
  const rows=Object.entries(v||{})
    .filter(([d,x])=>/^\d{4}-\d{2}-\d{2}$/.test(d) && Number(x?.totalBeads||x?.beads||0)>=0)
    .sort((a,b)=>a[0].localeCompare(b[0])).slice(-30);
  if(!rows.length)return '<div class="empty">Japa graph will appear after you count japa.</div>';
  const vals=rows.map(([d,x])=>Number(x?.totalBeads||x?.beads||0)/108);
  const max=Math.max(1,...vals), W=Math.max(620,rows.length*62), H=250, L=42, R=18, T=18, B=58;
  const pw=W-L-R, ph=H-T-B, sx=i=>L+(rows.length===1?pw/2:(i/(rows.length-1))*pw), sy=y=T+ph-(y/max)*ph;
  const points=vals.map((y,i)=>`${sx(i).toFixed(1)},${sy(y).toFixed(1)}`).join(' ');
  const grid=[0,Math.ceil(max/2),Math.ceil(max)];
  const gridHtml=grid.map(y=>{const yy=sy(y);return `<line x1="${L}" y1="${yy}" x2="${W-R}" y2="${yy}" stroke="#dbe5f0" stroke-width="1"/><text x="${L-8}" y="${yy+4}" text-anchor="end" font-size="11" fill="#64748b">${y}</text>`}).join('');
  const labels=rows.map(([d,x],i)=>{const xx=sx(i), y=vals[i], yy=sy(y), label=d.slice(5).replace('-','/'), mala=(Number(x?.totalBeads||x?.beads||0)/108).toFixed(2).replace(/\.00$/,'');return `<g><circle cx="${xx}" cy="${yy}" r="4" fill="#2563eb"><title>${d}: ${mala} mala</title></circle><text x="${xx}" y="${H-28}" text-anchor="middle" font-size="10" fill="#475569">${label}</text></g>`}).join('');
  return `<div class="japa-chart-wrap"><svg class="japa-chart" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" aria-label="Date-wise japa progress">${gridHtml}<polyline points="${points}" fill="none" stroke="#2563eb" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>${labels}</svg></div><div class="small muted">Date-wise japa: higher line = more japa, lower line = less japa. Blue line shows your actual recorded beads.</div>`;
}
function japaHistoryHtml(v){
  const h=Object.entries(v).sort((a,b)=>b[0].localeCompare(a[0])).slice(0,30);
  return h.length?h.map(([k,x])=>`<div class="item"><b>${k}</b><small>${Number(x.totalBeads||0)} beads · ${(Number(x.totalBeads||0)/108).toFixed(2).replace(/\.00$/,'')} mala${x.goalMala?` · Goal ${Number(x.goalMala)} mala`:''}</small></div>`).join(''):'<p class="muted">Your japa history will appear here.</p>';
}
async function loadJapa(){
  const local=readLocalJapa(); let server={};
  try{server=(await db.ref(memberPath('japa','daily')).once('value')).val()||{};}catch(e){}
  // Merge server data into local so the goal remains saved after reload.
  Object.entries(server).forEach(([d,x])=>{
    const serverBeads=Number(x?.totalBeads??x?.beads??0);
    const localRow=local[d]||{};
    local[d]={...localRow,...x,totalBeads:Math.max(serverBeads,Number(localRow.totalBeads||0)),goalMala:Number(x?.goalMala||localRow.goalMala||1),updatedAt:x?.updatedAt||localRow.updatedAt||Date.now()};
  });
  writeLocalJapa(local);
  const d=local[today()]||{totalBeads:0,goalMala:1},totalToday=Number(d.totalBeads||0),goal=Number(d.goalMala||1);
  const goalInput=$('japaGoal'); if(goalInput)goalInput.value=goal;
  const goalText=$('japaGoalText'); if(goalText)goalText.textContent=`Today's goal: ${goal} mala · ${Math.floor(totalToday/108)}/${goal} complete`;
  const totalAll=Object.values(local).reduce((a,x)=>a+Number(x?.totalBeads||0),0);
  $('japaTotal').textContent=totalAll;japaView(totalToday);$('japaHistory').innerHTML=japaHistoryHtml(local);
  const chart=document.getElementById('japaChart');if(chart)chart.innerHTML=japaChartHtml(local);
  loadStats();loadLevel();
}
$('saveJapaGoal').onclick=async()=>{
  const input=$('japaGoal'), n=Math.max(1,Math.min(108,Math.floor(Number(input?.value||1))));
  if(!Number.isFinite(n))return toast('Enter a valid goal between 1 and 108 mala.');
  const v=readLocalJapa(),key=today(),old=v[key]||{};
  v[key]={...old,totalBeads:Number(old.totalBeads||old.beads||0),goalMala:n,updatedAt:Date.now()};
  writeLocalJapa(v);
  try{await db.ref(memberPath('japa','daily/'+key)).set(v[key]);toast(`Today's japa goal set to ${n} mala`);await loadJapa();}catch(e){console.error(e);toast('Could not save japa goal. Check your internet/Firebase connection.');}
};
$('beadBtn').onclick=async()=>{
  const flower=document.createElement('div');flower.className='japa-flower-pop';flower.textContent='🌸';document.querySelector('.ring')?.appendChild(flower);setTimeout(()=>flower.remove(),850);
  const v=readLocalJapa(),key=today(),old=v[key]||{goalMala:1},total=Number(old.totalBeads||old.beads||0),newTotal=total+1,goal=Number(old.goalMala||1);
  v[key]={...old,totalBeads:newTotal,goalMala:goal,updatedAt:Date.now()};writeLocalJapa(v);japaView(newTotal);$('japaTotal').textContent=Object.values(v).reduce((a,x)=>a+Number(x?.totalBeads||0),0);$('japaHistory').innerHTML=japaHistoryHtml(v);
  try{
    await db.ref(memberPath('japa','daily/'+key)).set(v[key]);
    if(newTotal%108===0)await awardPoints(10,'Japa mala',`japa_mala_${key}_${Math.floor(newTotal/108)}`);
    if(newTotal>=goal*108)await awardPoints(20,'Daily japa goal',`japa_goal_${key}`);
    await syncJapaChallengeProgress(newTotal);
    const chart=document.getElementById('japaChart');if(chart)chart.innerHTML=japaChartHtml(v);
  }catch(e){console.error(e);}
  loadStats();loadLevel();loadMonthlyLeaderboard();
};
window.handleFloatingJapaTap=()=>{const b=$('beadBtn');if(b)b.click();};
window.startFloatingJapa=()=>{if(!window.AndroidOverlay){const f=document.getElementById('japaQuickFloat');if(f){f.classList.toggle('show');}return;}AndroidOverlay.start();toast('Allow “Display over other apps”, then tap Enable Floating Counter again.');};
let japaAudioCtx=null,japaOscillators=[],japaMusicOn=false,japaMusicInterval=null,quizStartedMusic=false,musicSource=null;
function stopMeditationMusic(){try{if(japaMusicInterval)clearInterval(japaMusicInterval);japaMusicInterval=null;japaOscillators.forEach(o=>{try{o.stop()}catch(e){}});if(japaAudioCtx)japaAudioCtx.close();}catch(e){}japaOscillators=[];japaAudioCtx=null;japaMusicOn=false;musicSource=null;const btn=$('japaMusicBtn');if(btn)btn.textContent='🔔 Start Meditation BGM';}
function startMeditationMusic(source='japa'){if(japaMusicOn&&musicSource===source){return true;}if(japaMusicOn)stopMeditationMusic();try{const Ctx=window.AudioContext||window.webkitAudioContext;if(!Ctx)throw new Error('Audio not supported');japaAudioCtx=new Ctx();japaAudioCtx.resume?.();const master=japaAudioCtx.createGain();master.gain.value=3.36; // 14x the original 0.24 signal-gain setting.
const limiter=japaAudioCtx.createDynamicsCompressor();limiter.threshold.value=-12;limiter.knee.value=10;limiter.ratio.value=12;limiter.attack.value=0.003;limiter.release.value=0.25;master.connect(limiter);limiter.connect(japaAudioCtx.destination);
// Gentle warm ambient pad: soft sustained notes with slow vibrato, not harsh beeps.
[130.81,196.00,261.63].forEach((hz,i)=>{const o=japaAudioCtx.createOscillator(),g=japaAudioCtx.createGain(),lfo=japaAudioCtx.createOscillator(),lg=japaAudioCtx.createGain();o.type='sine';o.frequency.value=hz;lfo.type='sine';lfo.frequency.value=0.07+i*0.025;lg.gain.value=1.5;o.connect(g);g.connect(master);lfo.connect(lg);lg.connect(o.frequency);g.gain.value=[0.30,0.20,0.12][i];o.start();lfo.start();japaOscillators.push(o,lfo);});
// Slow, soft bell-like notes in a calm pentatonic pattern.
const notes=[392.00,329.63,293.66,261.63,329.63,392.00,440.00,392.00];let ni=0;const playNote=()=>{if(!japaAudioCtx||japaAudioCtx.state==='closed')return;const t=japaAudioCtx.currentTime,o=japaAudioCtx.createOscillator(),g=japaAudioCtx.createGain();o.type='sine';o.frequency.value=notes[ni++%notes.length];g.gain.setValueAtTime(0.0001,t);g.gain.exponentialRampToValueAtTime(0.11,t+0.08);g.gain.exponentialRampToValueAtTime(0.0001,t+2.2);o.connect(g);g.connect(master);o.start(t);o.stop(t+2.25);};playNote();japaMusicInterval=setInterval(playNote,3200);japaMusicOn=true;musicSource=source;const btn=$('japaMusicBtn');if(btn)btn.textContent='🔕 Stop Meditation BGM';return true;}catch(e){console.error(e);toast('Audio could not start on this device.');return false;}}
window.toggleJapaMusic=()=>{if(japaMusicOn){stopMeditationMusic();return;}startMeditationMusic('japa');};
$('resetMala').onclick=async()=>{
  const v=readLocalJapa(),key=today(),old=v[key]||{},total=Number(old.totalBeads||old.beads||0),resetTotal=Math.floor(total/108)*108,goal=Number(old.goalMala||1);
  v[key]={...old,totalBeads:resetTotal,goalMala:goal,updatedAt:Date.now()};writeLocalJapa(v);japaView(resetTotal);$('japaTotal').textContent=Object.values(v).reduce((a,x)=>a+Number(x?.totalBeads||0),0);$('japaHistory').innerHTML=japaHistoryHtml(v);
  try{await db.ref(memberPath('japa','daily/'+key)).set(v[key]);}catch(e){console.error(e);}
  const chart=document.getElementById('japaChart');if(chart)chart.innerHTML=japaChartHtml(v);loadStats();loadLevel();
};
async function loadSadhana(){const s=await db.ref(memberPath('sadhana','entries')).once('value'),v=s.val()||{};$('sadhanaHistory').innerHTML=Object.entries(v).sort((a,b)=>b[0].localeCompare(a[0])).slice(0,12).map(([d,x])=>`<div class="item"><b>${d}</b><small>Wake ${esc(x.wake||'—')} · ${x.mala||0} mala · ${esc(x.reading||'')} · ${esc(x.darshan||'')}</small>${x.note?`<div>${esc(x.note)}</div>`:''}</div>`).join('')||'<p class="muted">No entries yet.</p>';return v}
$('saveSadhana').onclick=async()=>{const d=today();await db.ref(memberPath('sadhana','entries/'+d)).set({wake:$('wakeTime').value,mala:Number($('sadhanaMala').value||0),reading:$('shlokaPath').value.trim(),darshan:$('darshanDone').value.trim(),note:$('sadhanaNote').value.trim(),updatedAt:Date.now()});const awarded=await awardPoints(10,'Daily sadhana',`sadhana_${d}`);toast(awarded?'Sadhana saved · +10 XP':'Sadhana saved · today’s XP already awarded');loadSadhana();loadStats();loadLevel();loadMonthlyLeaderboard()};
function levelInfo(xp){const level=Math.floor(Number(xp||0)/250)+1;const min=(level-1)*250,next=level*250;const names=['Seeker','Bhakta','Sadhak','Nishtha Bhakta','Prem Sadhak','Bhakti Acharya','Mahabhakta'];const name=level<=7?names[level-1]:('Bhakti Level '+level);return {level,name,min,next};}
function levelsEmoji(n){return n.includes('Mahabhakta')?'ॐ':n.includes('Acharya')?'✦':n.includes('Prem')?'🪷':n.includes('Nishtha')?'🙏':n.includes('Sadhak')?'📿':n.includes('Bhakta')?'🕉️':'🌱'}
async function awardPoints(amount,reason,eventKey){
  amount=Number(amount||0); if(amount<=0||!me||!activeMember)return;
  const ek=String(eventKey||reason||Date.now()).replace(/[^A-Za-z0-9_-]/g,'_');
  const eventRef=db.ref(memberPath('pointsEvents',ek));
  const already=await eventRef.once('value'); if(already.exists())return false;
  await eventRef.set({amount,reason,createdAt:Date.now()});
  const memberRef=db.ref('users/'+me.uid+'/members/'+activeKey());
  await memberRef.child('xp').transaction(v=>Number(v||0)+amount);
  const month=today().slice(0,7), key=(me.uid+'_'+activeKey()).replace(/[^A-Za-z0-9_-]/g,'_');
  const lbRef=db.ref('monthlyLeaderboard/'+month+'/'+key);
  await lbRef.transaction(v=>{v=v||{};v.name=activeMember.name||profile.name;v.avatar=avatarFor(activeMember.avatar||profile.avatar);v.relation='';v.uid=me.uid;v.memberId=activeKey();v.points=Number(v.points||0)+amount;v.updatedAt=Date.now();return v});
  return true;
}
async function loadLevel(){
  if(!me||!activeMember)return;
  const m=(await db.ref('users/'+me.uid+'/members/'+activeKey()).once('value')).val()||{};
  const xp=Number(m.xp||0),info=levelInfo(xp),pct=Math.max(0,Math.min(100,Math.round((xp-info.min)/(info.next-info.min)*100)));
  const el=$('levelCard'); if(el)el.innerHTML=`<div class="level-top"><span>${levelsEmoji(info.name)}</span><div><small>BHakti LEVEL</small><h3>Level ${info.level} · ${esc(info.name)}</h3></div><strong>${xp} XP</strong></div><div class="bar"><i style="width:${pct}%"></i></div><p>${info.next-xp} XP to Level ${info.level+1} · Infinite levels</p>`;
  const home=$('homePoints');if(home)home.textContent=xp;
}
async function loadMonthlyLeaderboard(){
  const month=today().slice(0,7); let v={}; try{v=(await db.ref('monthlyLeaderboard/'+month).once('value')).val()||{}}catch(e){}
  const rows=Object.values(v).sort((a,b)=>Number(b.points||0)-Number(a.points||0));
  const html=rows.map((x,i)=>`<div class="item leaderboard-person"><b>#${i+1} · ${avatarHtml(x.avatar,'leader-avatar')} ${esc(x.name||'Devotee')}</b><small>${Number(x.points||0)} total points</small></div>`).join('')||'<p class="muted">No monthly points yet.</p>';
  if($('monthlyLeaderboard'))$('monthlyLeaderboard').innerHTML=html;
  if($('monthlyTitle'))$('monthlyTitle').textContent=`Monthly Leaderboard · ${month}`;
}
async function loadStats(){
  const japa=readLocalJapa();let sadhana={},quiz={},challenge={},shlok={};
  try{sadhana=(await db.ref(memberPath('sadhana','entries')).once('value')).val()||{};}catch(e){}
  try{shlok=(await db.ref(memberPath('shlokChallenge')).once('value')).val()||{};}catch(e){}
  try{quiz=(await db.ref('quiz/results').once('value')).val()||{};}catch(e){}
  try{challenge=(await db.ref('challengeProgress').once('value')).val()||{};}catch(e){}
  const quizDates=Object.entries(quiz).filter(([date,users])=>users&&users[activeKey()]).map(([date])=>date);
  const quizPoints=Object.entries(quiz).reduce((sum,[date,users])=>sum+Number(users?.[activeKey()]?.score||0),0);
  const challengeRows=Object.values(challenge).map(group=>group?.[activeKey()]).filter(Boolean);
  const challengePoints=challengeRows.reduce((sum,r)=>sum+Number(r.points||0),0);
  const totalJapa=Object.values(japa).reduce((sum,x)=>sum+Number(x?.totalBeads||x?.beads||0),0);
  const totalMala=Math.floor(totalJapa/108);
  const sadhanaMala=Object.values(sadhana).reduce((sum,x)=>sum+Number(x?.mala||0),0);
  const shlokDays=Object.values(shlok).filter(x=>x?.done).length;
  $('homeStreak').textContent=Object.keys(sadhana).length;
  $('statsCards').innerHTML=`<div><b>${totalJapa}</b><span>Total Japa beads · lifetime</span></div><div><b>${totalMala}</b><span>Japa Mala · lifetime</span></div><div><b>${quizDates.length}</b><span>Quiz days · lifetime</span></div><div><b>${quizPoints}</b><span>Quiz points · lifetime</span></div><div><b>${challengePoints}</b><span>Challenge pts · recorded total</span></div><div><b>${sadhanaMala}</b><span>Sadhana Mala · lifetime</span></div><div><b>${shlokDays}</b><span>Shlok days · lifetime</span></div>`;
  $('profileStats').innerHTML=$('statsCards').innerHTML;
}

function isJapaChallengeTask(t){
  const kind=String(t?.type||t?.taskType||t?.category||'').toLowerCase();
  const name=String(t?.name||t?.title||'').toLowerCase();
  return kind.includes('japa') || kind.includes('mala') || /\bjapa\b|\bmala\b|108 beads|beads count/.test(name);
}
function japaChallengeTarget(t){
  const raw=t?.targetMala??t?.target_mala??t?.malaTarget??t?.target??t?.goalMala??t?.goal??t?.count??1;
  const n=Number(raw);
  return Math.max(1,Number.isFinite(n)?n:1);
}
async function syncJapaChallengeProgress(totalBeads){
  if(!me||!activeMember)return;
  try{
    const snap=await db.ref('challenges').orderByChild('active').equalTo(true).limitToLast(1).once('value');
    const entry=Object.entries(snap.val()||{})[0];
    if(!entry)return;
    const [id,ch]=entry, tasks=ch.tasks||{};
    const path='challengeProgress/'+id+'/'+activeKey();
    const ps=await db.ref(path).once('value'), p=ps.val()||{tasks:{},points:0};
    const nextTasks={...(p.tasks||{})};
    let changed=false, newlyCompleted=[];
    for(const [key,t] of Object.entries(tasks)){
      if(!isJapaChallengeTask(t))continue;
      const target=japaChallengeTarget(t), progress=Math.min(target,Math.floor(Number(totalBeads||0)/108));
      const complete=progress>=target;
      const old=nextTasks[key];
      if(!old || typeof old!=='object' || old.progress!==progress || !!old.done!==complete){
        nextTasks[key]={done:complete,progress,target,source:'japa',updatedAt:Date.now()};
        changed=true;
      }
      if(complete && !(old===true || old?.done===true))newlyCompleted.push([key,t]);
    }
    if(!changed)return;
    let points=0;
    for(const [key,t] of Object.entries(tasks)){
      const state=nextTasks[key];
      if(state===true || state?.done)points+=Number(t.points||0);
    }
    await db.ref(path).update({name:activeMember.name||profile.name,points,tasks:nextTasks,updatedAt:Date.now()});
    for(const [key,t] of newlyCompleted){
      await awardPoints(Number(t.points||0),'Japa bhakti challenge',`challenge_${id}_${key}`);
    }
  }catch(e){console.warn('Japa challenge sync failed',e);}
}

async function loadChallenges(){await syncJapaChallengeProgress(Number(readLocalJapa()?.[today()]?.totalBeads||0));const s=await db.ref('challenges').orderByChild('active').equalTo(true).limitToLast(1).once('value');const all=s.val()||{};const entry=Object.entries(all)[0];if(!entry){$('challengeTasks').innerHTML='<div class="card">No active challenge yet.</div>';return}const[id,ch]=entry;$('challengeTitleView').textContent=ch.title||'Weekly Bhakti Challenge';$('challengeWeekView').textContent=ch.week||'THIS WEEK';const ps=await db.ref('challengeProgress/'+id+'/'+activeKey()).once('value'),p=ps.val()||{tasks:{},points:0};const tasks=ch.tasks||{};let done=0,total=Object.keys(tasks).length;let html='';for(const[k,t]of Object.entries(tasks)){const state=p.tasks?.[k],checked=state===true||!!state?.done;if(checked)done++;if(isJapaChallengeTask(t)){const target=japaChallengeTarget(t),progress=Math.min(target,Math.floor(Number(readLocalJapa()?.[today()]?.totalBeads||0)/108));html+=`<div class="task japa-challenge-task"><span>📿 ${esc(t.name||'Japa Mala')}</span><span>${progress}/${target} mala</span><span class="pts">+${t.points||0}</span></div>`}else{html+=`<label class="task"><input type="checkbox" data-task="${esc(k)}" ${checked?'checked':''}><span>${esc(t.name)}</span><span class="pts">+${t.points}</span></label>`}}$('challengeTasks').innerHTML=html||'<div class="card">No tasks.</div>';const pct=total?Math.round(done/total*100):0;$('challengePercent').textContent=pct+'%';$('challengeProgress').style.width=pct+'%';loadLevel();document.querySelectorAll('[data-task]').forEach(x=>x.onchange=async()=>{const key=x.dataset.task,newTasks={...(p.tasks||{}),[key]:x.checked};let points=0;for(const[k,t]of Object.entries(tasks))if(newTasks[k])points+=Number(t.points||0);await db.ref('challengeProgress/'+id+'/'+activeKey()).set({name:profile.name,points,tasks:newTasks,updatedAt:Date.now()});if(x.checked){await awardPoints(Number(tasks[key]?.points||0),'Bhakti challenge',`challenge_${id}_${key}`)}loadChallenges();loadLevel();loadMonthlyLeaderboard()});const lb=await db.ref('challengeProgress/'+id).orderByChild('points').limitToLast(20).once('value');const rows=Object.values(lb.val()||{}).sort((a,b)=>Number(b.points||0)-Number(a.points||0));$('myRank').textContent=(rows.findIndex(x=>x.name===profile.name)+1)||'—';$('leaderboardList').innerHTML=rows.map((x,i)=>`<div class="item"><b>#${i+1} · ${esc(x.name||'Devotee')}</b><small>${x.points||0} points</small></div>`).join('')||'<p class="muted">No leaderboard data yet.</p>'}
async function loadShlokChallenge(){
 const d=today(),lang=localStorage.vwLang||'hindi';let progress={},content=null;
 try{progress=(await db.ref(memberPath('shlokChallenge')).once('value')).val()||{}}catch(e){}
 try{content=(await db.ref('shlokaReading/'+d).once('value')).val()}catch(e){}
 const levels=content?.levels||{},saved=progress[d]?.levels||{},doneCount=Object.values(saved).filter(x=>x?.done).length,pct=Math.round(doneCount/5*100);
 if(window.shlokCountdownTimer){clearInterval(window.shlokCountdownTimer);window.shlokCountdownTimer=null;}
 $('shlokSummary').innerHTML=`<h3>📚 ${esc(content?.bookName||'Shlok Reading Challenge')}</h3><p>${esc(content?.skandName||'Bhagwatam')} · ${esc(content?.chapterLabel||'Daily reading')} · ${doneCount}/5 levels complete</p><div class="level-head"><div class="level-ring" style="--pct:${pct}%"><b>${pct}%</b></div><div><b>Daily Smart Meter</b><p class="muted small">Read one shlok, then write its summary. Complete all five levels to finish today's challenge.</p></div></div><div class="actions lang-tabs"><button class="${lang==='hindi'?'primary':'secondary'}" onclick="localStorage.vwLang='hindi';loadShlokChallenge()">हिन्दी</button><button class="${lang==='bengali'?'primary':'secondary'}" onclick="localStorage.vwLang='bengali';loadShlokChallenge()">বাংলা</button></div>`;
 if(doneCount>=5){
  $('shlokList').innerHTML=`<div class="card complete-card"><div class="success-icon">✓</div><h3>आज का Shlok Reading पूरा हुआ!</h3><p>आपने आज के सभी 5 श्लोक और summaries पूरी कर ली हैं। अगला दिन शुरू होने पर नया challenge खुलेगा।</p><h4>अगला challenge खुलने में</h4><div id="shlokCountdown" class="shlok-countdown">--:--:--</div><p class="muted small">Timer midnight तक घटता रहेगा। अगला दिन शुरू होने पर app में नए दिन का Admin-published shlok दिखेगा।</p></div>`;
  const tick=()=>{const now=new Date(),next=new Date(now);next.setHours(24,0,0,0);let sec=Math.max(0,Math.floor((next-now)/1000));const h=Math.floor(sec/3600);sec%=3600;const m=Math.floor(sec/60);const ss=sec%60;const el=$('shlokCountdown');if(el)el.textContent=`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(ss).padStart(2,'0')}`;if(h===0&&m===0&&ss===0){clearInterval(window.shlokCountdownTimer);window.shlokCountdownTimer=null;loadShlokChallenge();}};tick();window.shlokCountdownTimer=setInterval(tick,1000);return;
 }
 if(!content){$('shlokList').innerHTML='<div class="card"><h3>Today’s Shlok</h3><p class="muted">Admin has not published today’s five levels yet.</p></div>';return;}
 const langTitle=lang==='bengali'?'বাংলা':'हिन्दी';let html='<div class="shlok-levels">';
 for(let i=1;i<=5;i++){const x=levels[i]||levels['level'+i]||(i===1?content:null);if(!x){html+=`<article class="shlok-level-card"><div class="level-head"><div class="level-ring" style="--pct:0%"><b>${i}/5</b></div><div><h3>Level ${i}</h3><p class="muted small">Admin has not added this shlok yet.</p></div></div></article>`;continue;}
 const val=saved[i]||saved['level'+i]||{},done=!!val.done,meaning=lang==='bengali'?(x.bengali||x.meaningBengali):(x.hindi||x.meaningHindi),bhavarth=lang==='bengali'?(x.bhavarthBengali||x.bengaliBhavarth):(x.bhavarthHindi||x.hindiBhavarth);
 html+=`<article class="shlok-level-card"><div class="level-head"><div class="level-ring" style="--pct:${done?'100':'0'}%"><b>${done?'✓':i+'/5'}</b></div><div><span class="badge">LEVEL ${i}</span><h3>${esc(x.title||`Shlok ${i}`)}</h3><div class="shlok-range">${esc(x.bookName||content.bookName||'Srimad Bhagavatam')} · ${esc(x.chapterLabel||content.chapterLabel||'Chapter')} · ${esc(x.verseRange||'')}</div></div></div><h4>संस्कृत श्लोक / সংস্কৃত শ্লোক</h4><div class="shlok-text">${esc(x.sanskrit||x.shlok||'')}</div><h4>${langTitle} meaning / অর্থ</h4><p>${esc(meaning||'Meaning not published in this language yet.')}</p><h4>${lang==='bengali'?'ভাবার্থ':'भावार्थ'}</h4><p>${esc(bhavarth||'Admin has not added the bhavarth yet.')}</p><label>${lang==='bengali'?'আপনার সারাংশ লিখুন':'Is shlok ki summary apne shabdon mein likho'}<textarea id="shlokSummary${i}" maxlength="1000" placeholder="${lang==='bengali'?'এই শ্লোকের সারাংশ লিখুন…':'Is shlok ka saar likho…'}" ${done?'disabled':''}>${esc(val.summary||'')}</textarea></label><button class="primary" ${done?'disabled':''} onclick="completeShlokLevel(${i})">${done?'Level completed ✓':'Summary save karein & next level complete karein'}</button></article>`;
 }
 html+='</div>';if(content.prize)html+=`<div class="card"><h3>🎁 Challenge Reward</h3><p>${esc(content.prize)}</p></div>`;$('shlokList').innerHTML=html;
 window.completeShlokLevel=async(i)=>{const summary=($('shlokSummary'+i)?.value||'').trim();if(summary.length<5)return toast('Please write a summary of at least 5 characters.');const path=memberPath('shlokChallenge',d+'/levels/'+i);const snap=await db.ref(path).once('value');if(snap.exists()&&snap.val()?.done)return loadShlokChallenge();const record={done:true,summary,completedAt:Date.now(),memberId:activeKey(),level:i,title:(levels[i]||levels['level'+i]||(i===1?content:{})).title||`Shlok ${i}`,bookName:content.bookName||'',chapterLabel:content.chapterLabel||'',verseRange:(levels[i]||levels['level'+i]||{}).verseRange||''};await db.ref(path).set(record);await db.ref(`shlokSummaries/${d}/${me.uid}/${activeKey()}/level${i}`).set({...record,uid:me.uid,name:activeMember?.name||profile.name,language:lang});await awardPoints(3,'Shlok reading level',`shlok_${d}_level_${i}`);toast(`Level ${i} completed · +3 XP`);loadShlokChallenge();loadProAchievements();loadLevel();loadMonthlyLeaderboard();};
}
async function loadBirthdayCard(){
  const d=today(),md=d.slice(5,10);
  let people=[];
  try{
    const us=(await db.ref('users').once('value')).val()||{};
    Object.entries(us).forEach(([uid,u])=>{
      const arr=[];
      if(u?.dob && String(u.dob).slice(5,10)===md)arr.push({...u,id:'you',uid,relation:'You'});
      Object.values(u?.members||{}).forEach(m=>{if(m?.dob&&String(m.dob).slice(5,10)===md)arr.push({...m,uid});});
      people.push(...arr);
    });
  }catch(e){}
  const box=$('birthdayHome');if(!box)return;
  if(!people.length){box.innerHTML='<div class="card birthday-card"><h3>🎂 Birthday Wishes</h3><p class="muted">No birthday today.</p></div>';return;}
  box.innerHTML='<div class="card birthday-card"><h3>🎂 Birthday Wishes</h3>'+people.map(p=>`<div class="birthday-person"><b>${esc(p.name||'Devotee')}</b><small>${esc(p.relation||'Devotee')}</small><button class="primary birthdayLike" data-uid="${esc(p.uid)}" data-mid="${esc(p.id||'you')}">❤️ Like Birthday</button><div id="bdaylikes_${esc(p.uid)}_${esc(p.id||'you')}" class="muted small">Loading wishes…</div></div>`).join('')+'</div>';
  box.querySelectorAll('.birthdayLike').forEach(async btn=>{const key=d+'_'+btn.dataset.uid+'_'+btn.dataset.mid,ref=db.ref('birthdayLikes/'+key),mine=ref.child('likes/'+(me.uid+'_'+activeKey()).replace(/[^A-Za-z0-9_-]/g,'_'));const snap=await ref.once('value'),data=snap.val()||{},likes=data.likes||{};const panel=$('bdaylikes_'+btn.dataset.uid+'_'+btn.dataset.mid);btn.textContent=likes[(me.uid+'_'+activeKey()).replace(/[^A-Za-z0-9_-]/g,'_')]?'❤️ Liked':'❤️ Like Birthday';if(panel)panel.textContent='❤️ '+Object.keys(likes).length+' likes'+(Object.keys(likes).length?': '+Object.values(likes).map(x=>x.name).join(', '):'');btn.onclick=async()=>{const ss=await mine.once('value');if(ss.exists())await mine.remove();else await mine.set({name:activeMember?.name||profile.name,memberId:activeKey(),createdAt:Date.now()});loadBirthdayCard()}});
  box.querySelectorAll('.birthdayWish').forEach(btn=>btn.onclick=async()=>{
    const name=btn.dataset.name||'Devotee', key=`${d}_${btn.dataset.uid}_${btn.dataset.mid}`;
    try{
      window.__birthdayName=name;const q=pushRef(key); await q;
      toast('Birthday wishes sent 🎉');
      btn.disabled=true;btn.textContent='Wishes Sent ✓';
    }catch(e){toast('Could not send wishes.')}
  });
}
function pushRef(key){
  const r=db.ref('pushQueue').push();
  return r.set({title:'🎂 Birthday Wishes',text:`Please send your heartfelt birthday wishes to ${window.__birthdayName||'today’s devotee'} 🙏`,type:'birthday',route:'home',target:'all',status:'queued',createdAt:Date.now()});
}
async function loadCourses(){const s=await db.ref('courses').once('value'),v=s.val()||{};$('courseList').innerHTML=Object.entries(v).map(([id,c])=>`<div class="course-card"><h3>${esc(c.title)}</h3><p>${esc(c.description||'')}</p><small>${Object.keys(c.days||{}).length} days</small><br><button onclick="openCourse('${id}')">Open course</button></div>`).join('')||'<div class="card">No courses published yet.</div>'}window.openCourse=async id=>{const s=await db.ref('courses/'+id).once('value'),c=s.val();if(!c)return;const prog=(await db.ref('courseProgress/'+id+'/'+activeKey()).once('value')).val()||{};$('courseDetail').classList.remove('hidden');$('courseDetail').innerHTML=`<div class="page-head"><button class="ghost" onclick="$('courseDetail').classList.add('hidden')">← Back</button><div><h2>${esc(c.title)}</h2><p>${esc(c.description||'')}</p></div></div>`+Object.entries(c.days||{}).map(([k,d])=>`<div class="course-card"><h3>${esc(d.title||k)}</h3><p>${esc(d.text||'')}</p><button onclick="window.open('${esc(d.url||'#')}','_blank')">Watch Video</button><button class="secondary" onclick="completeDay('${id}','${k}')">${prog[k]?'Completed ✓':'Mark completed'}</button></div>`).join('')};window.completeDay=async(id,k)=>{const r=await db.ref('courseProgress/'+id+'/'+activeKey()+'/'+k).once('value');if(r.exists())return openCourse(id);await db.ref('courseProgress/'+id+'/'+activeKey()+'/'+k).set(true);await awardPoints(10,'Course lesson',`course_${id}_${k}`);toast('Progress saved · +10 XP');openCourse(id);loadLevel();loadMonthlyLeaderboard()};
function secondsUntilDate(dateKey){const [y,m,d]=dateKey.split('-').map(Number);return Math.max(0,Math.floor((new Date(y,m-1,d,0,0,0).getTime()-Date.now())/1000))}
function countdownMarkup(targetDate,label){return `<div class="countdown-card card"><h3>${label}</h3><div class="live-countdown" data-countdown-target="${targetDate}">Loading…</div><small class="muted">HH : MM : SS</small></div>`}
function startLiveCountdowns(){if(window.vwCountdownInterval)clearInterval(window.vwCountdownInterval);const tick=()=>document.querySelectorAll('[data-countdown-target]').forEach(el=>{const sec=secondsUntilDate(el.dataset.countdownTarget);el.textContent=sec<=0?'00:00:00':[Math.floor(sec/3600),Math.floor(sec%3600/60),sec%60].map(n=>String(n).padStart(2,'0')).join(':')});tick();window.vwCountdownInterval=setInterval(tick,1000)}
async function loadQuiz(){const d=today(),lang=localStorage.vwQuizLang||'hindi';let existing=null;try{existing=(await db.ref('quiz/results/'+d+'/'+activeKey()).once('value')).val()}catch(e){}if(existing){$('quizBox').innerHTML=`<div class="card complete-card"><div class="success-icon">✓</div><h3>Today's Quiz Complete</h3><p>You already played today's quiz as <b>${esc(activeMember?.name||profile.name)}</b>.</p><p>Score: <b>${existing.score}/${existing.total}</b></p><small>Come back tomorrow for the next quiz.</small>${countdownMarkup(new Date(Date.now()+86400000).getFullYear()+'-'+String(new Date(Date.now()+86400000).getMonth()+1).padStart(2,'0')+'-'+String(new Date(Date.now()+86400000).getDate()).padStart(2,'0'),'Next quiz opens in')}</div>`;startLiveCountdowns();renderQuizResult(existing);return}$('quizBox').innerHTML=`<div class="quiz-start card"><span class="badge">${lang.toUpperCase()}</span><h3>Today's 10-question quiz</h3><p>Once submitted, this member cannot play again until tomorrow.</p><div style="display:flex;gap:8px"><button class="secondary" onclick="localStorage.vwQuizLang='hindi';loadQuiz()">Hindi</button><button class="secondary" onclick="localStorage.vwQuizLang='bengali';loadQuiz()">Bengali</button></div><button class="primary" onclick="startQuiz('${lang}','${d}')">Start Quiz</button></div>`;loadQuizLeaderboard(d)}
async function startQuiz(lang,d){quizStartedMusic=true;startMeditationMusic('quiz');const already=await db.ref('quiz/results/'+d+'/'+activeKey()).once('value');if(already.exists()){if(quizStartedMusic){stopMeditationMusic();quizStartedMusic=false;}return loadQuiz();}const s=await db.ref('quiz/daily/'+lang+'/'+d).once('value');const qs=s.val();if(!qs||Object.keys(qs).length<1){if(quizStartedMusic){stopMeditationMusic();quizStartedMusic=false;}return toast('Quiz is not published for today.');}const keys=Object.keys(qs).sort();const overlay=document.createElement('div');overlay.className='countdown';overlay.textContent='3';document.body.appendChild(overlay);let n=3;const it=setInterval(()=>{n--;overlay.textContent=n>0?n:'START';if(n<=0){clearInterval(it);setTimeout(()=>{overlay.remove();quizState={lang,d,qs,keys,i:0,answers:{},started:Date.now()};renderQuestion()},450)}},650)}
function renderQuizResult(r){const lang=(r.language||localStorage.vwQuizLang||'hindi').toLowerCase();const rows=(r.review||[]).map((x,i)=>`<div class="review-item ${x.ok?'ok':'bad'}"><b>Q${i+1}. ${esc(x.question)}</b><div>Your answer: ${esc(x.answer)}</div><div>Correct answer: ${esc(x.correct)}</div><small>${x.ok?'✓ Correct':'✗ Wrong'}</small></div>`).join('');$('quizResultBox').innerHTML=`<div class="card quiz-result"><div class="result-score"><strong>${r.score}/${r.total}</strong><span>${Math.round(Number(r.score||0)/Math.max(1,Number(r.total||1))*100)}%</span></div><h3>${lang==='bengali'?'আজকের কুইজের ফলাফল':'आज के क्विज़ का परिणाम'}</h3><p>${r.correct||r.score} correct · ${r.wrong??(r.total-r.score)} wrong</p><div class="review-list">${rows}</div></div>`}
function renderQuestion(){clearInterval(quizTimer);const q=quizState.qs[quizState.keys[quizState.i]],text=q['question_'+quizState.lang]||q[quizState.lang+'Question']||q.question;let left=59;$('quizBox').innerHTML=`<div class="q-card"><div class="timer" id="quizTimer">${left}</div><p class="muted">Question ${quizState.i+1} / ${quizState.keys.length}</p><h3>${esc(text)}</h3><div class="options">${['A','B','C','D'].map(k=>{const v=q['option'+k+'_'+quizState.lang]||q['option'+k+quizState.lang]||q['option'+k];return `<button class="option ${quizState.answers[quizState.keys[quizState.i]]===k?'selected':''}" onclick="answerQuiz('${k}')">${esc(v)}</button>`}).join('')}</div><button class="primary" onclick="nextQuestion()">${quizState.i===quizState.keys.length-1?'Submit Quiz':'Next'}</button></div>`;quizTimer=setInterval(()=>{$('quizTimer').textContent=--left;if(left<=0){clearInterval(quizTimer);nextQuestion()}},1000)}
window.answerQuiz=k=>{quizState.answers[quizState.keys[quizState.i]]=k;renderQuestion()};window.nextQuestion=async()=>{clearInterval(quizTimer);if(quizState.i<quizState.keys.length-1){quizState.i++;renderQuestion()}else submitQuiz()};
async function submitQuiz(){if(quizStartedMusic){stopMeditationMusic();quizStartedMusic=false;}if(await db.ref('quiz/results/'+quizState.d+'/'+activeKey()).once('value').then(s=>s.exists()))return loadQuiz();let score=0;const review=[];for(const k of quizState.keys){const q=quizState.qs[k],ans=quizState.answers[k]||'Not answered',ok=ans===q.correct;if(ok)score++;const text=q['question_'+quizState.lang]||q[quizState.lang+'Question']||q.question;const av=ans==='Not answered'?'Not answered':(q['option'+ans+'_'+quizState.lang]||q['option'+ans+quizState.lang]||q['option'+ans]);const cv=q['option'+q.correct+'_'+quizState.lang]||q['option'+q.correct+quizState.lang]||q['option'+q.correct];review.push({question:text,answer:av,correct:cv,ok});}const quizResult={ownerUid:me.uid,memberId:activeKey(),name:activeMember.name,mobile:activeMember.mobile||profile.mobile,relation:activeMember.relation,language:quizState.lang,score,total:quizState.keys.length,correct:score,wrong:quizState.keys.length-score,review,submittedAt:Date.now()};await db.ref('quiz/results/'+quizState.d+'/'+activeKey()).set(quizResult);localStorage.setItem(memberLocalKey('Quiz_'+quizState.d),JSON.stringify(quizResult));await awardPoints(score,'Daily quiz',`quiz_${quizState.d}`);renderQuizResult(quizResult);await loadLevel();await loadStats();await loadMonthlyLeaderboard();toast('Quiz submitted — score '+score+'/'+quizState.keys.length)}
async function loadQuizLeaderboard(d){const s=await db.ref('quiz/results/'+d).once('value'),v=s.val()||{};const rows=Object.values(v).sort((a,b)=>Number(b.score)-Number(a.score)||Number(a.submittedAt)-Number(b.submittedAt));$('quizLeaderboardList').innerHTML=rows.map((x,i)=>`<div class="item"><b>${i===0?'🥇':i===1?'🥈':i===2?'🥉':'#'+(i+1)} · ${esc(x.name)}</b><small>${x.score}/${x.total} · ${esc(x.language||'')}</small></div>`).join('')||'<p class="muted">No results yet.</p>'}
async function loadContent(){const s=await db.ref('bhaktiContent').once('value'),v=s.val()||{};$('contentList').innerHTML=Object.values(v).sort((a,b)=>(b.createdAt||0)-(a.createdAt||0)).map(x=>`<article class="content-card"><small>${esc(x.type||'Bhakti')}</small><h3>${esc(x.title)}</h3><p>${esc(x.text||'')}</p></article>`).join('')||'<div class="card">No content published yet.</div>'}
let festivalMonth=new Date();
async function loadCalendar(){
 const s=await db.ref('calendar').once('value'),v=s.val()||{},rows=Object.entries(v).map(([id,x])=>({...x,id}));
 const year=festivalMonth.getFullYear(),month=festivalMonth.getMonth(),days=new Date(year,month+1,0).getDate(),first=new Date(year,month,1).getDay();
 $('calMonthTitle').textContent=festivalMonth.toLocaleDateString(undefined,{month:'long',year:'numeric'});
 let h='';['S','M','T','W','T','F','S'].forEach(x=>h+=`<div class="bhakti-day"><b>${x}</b></div>`);for(let i=0;i<first;i++)h+='<div></div>';
 for(let d=1;d<=days;d++){const key=`${year}-${String(month+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`,events=rows.filter(x=>x.date===key),isToday=key===today();h+=`<button class="bhakti-day ${events.length?'done festival-day':''} ${isToday?'today':''}" data-festival-date="${key}">${d}${events.length?' ✦':''}</button>`}
 $('festivalCalendar').innerHTML=h;
 const showDate=(key)=>{const events=rows.filter(x=>x.date===key);$('festivalDetails').innerHTML=events.length?events.map(x=>`<article class="calendar-card"><small>${esc(x.date)} · ${String(x.type||'festival').toLowerCase().includes('ekadashi')?'EKADASHI':'FESTIVAL'}</small><h3>${esc(x.title||'Festival')}</h3><p>${esc(x.details||'Details will be announced.')}</p>${x.shlokHindi?.sanskrit?`<div class="calendar-shlok"><h4>Hindi · संस्कृत श्लोक</h4><p>${esc(x.shlokHindi.sanskrit)}</p><p><b>अर्थ:</b> ${esc(x.shlokHindi.meaning||'')}</p><p><b>भावार्थ:</b> ${esc(x.shlokHindi.bhavarth||'')}</p></div>`:''}${x.shlokBengali?.sanskrit?`<div class="calendar-shlok"><h4>বাংলা · সংস্কৃত শ্লোক</h4><p>${esc(x.shlokBengali.sanskrit)}</p><p><b>অর্থ:</b> ${esc(x.shlokBengali.meaning||'')}</p><p><b>ভাবার্থ:</b> ${esc(x.shlokBengali.bhavarth||'')}</p></div>`:''}${String(x.type||'').toLowerCase().includes('ekadashi')||String(x.title||'').toLowerCase().includes('ekadashi')?`<button class="primary" onclick="page('ekadashi');loadEkadashi()">Open Ekadashi Vrat</button>`:''}</article>`).join(''):`<p class="muted">No festival published for ${esc(key)}.</p>`};
 document.querySelectorAll('[data-festival-date]').forEach(b=>b.onclick=()=>showDate(b.dataset.festivalDate));
 $('calPrev').onclick=()=>{festivalMonth=new Date(year,month-1,1);loadCalendar()};$('calNext').onclick=()=>{festivalMonth=new Date(year,month+1,1);loadCalendar()};
 $('calendarList').innerHTML=rows.sort((a,b)=>(a.date||'').localeCompare(b.date||'')).map(x=>`<div class="calendar-card"><small>${esc(x.date||'')}</small><h3>${esc(x.title||'Festival')}</h3><p>${esc(x.details||'')}</p></div>`).join('')||'<div class="card">No festival entries yet.</div>';
 showDate(today());
}
async function loadEkadashi(){const box=$('ekadashiContent');if(!box)return;const d=today(),s=await db.ref('calendar').once('value'),rows=Object.entries(s.val()||{}).map(([id,x])=>({...x,id})),event=rows.find(x=>x.date===d&&(String(x.type||'').toLowerCase().includes('ekadashi')||String(x.title||'').toLowerCase().includes('ekadashi')));if(!event){const next=rows.filter(x=>(String(x.type||'').toLowerCase().includes('ekadashi')||String(x.title||'').toLowerCase().includes('ekadashi'))&&x.date>d).sort((a,b)=>a.date.localeCompare(b.date))[0];box.innerHTML=`<div class="card"><h3>🌸 ${next?'Next Ekadashi: '+esc(next.title):'No Ekadashi scheduled yet'}</h3>${next?`<p>${esc(next.date)}</p>${countdownMarkup(next.date,'Ekadashi begins in')}<p>${esc(next.details||'')}</p>`:'<p class="muted">Admin calendar mein Ekadashi date publish karega to countdown yahan dikhega.</p>'}</div>`;if(next)startLiveCountdowns();return;}
 const key=activeKey(),path=memberPath('ekadashi',d),my=(await db.ref(path).once('value')).val()||{};const joined=!!my.joined;let japa={},quiz={},shlok={};try{japa=readLocalJapa()[d]||{}}catch(e){}try{quiz=(await db.ref(`quiz/results/${d}/${key}`).once('value')).val()||{}}catch(e){}try{shlok=(await db.ref(memberPath('shlokChallenge',d)).once('value')).val()||{}}catch(e){}const participants=(await db.ref(`ekadashiParticipants/${d}`).once('value')).val()||{};const pRows=Object.values(participants).sort((a,b)=>Number(b.japa||0)-Number(a.japa||0));
 box.innerHTML=`<div class="card"><span class="badge">EKADASHI · ${esc(d)}</span><h3>${esc(event.title)}</h3><p>${esc(event.details||'Follow your local Vaishnava fasting and parana guidance.')}</p><p>Are you observing Ekadashi today?</p><div class="actions"><button class="primary" id="joinEkadashi">${joined?'Joined ✓':'Yes, I am observing'}</button><button class="secondary" id="skipEkadashi">${my.joined===false?'No · selected':'No'}</button></div><div class="stats-cards"><div><b>${Math.floor(Number(japa.totalBeads||0)/108)}</b><span>Japa mala</span></div><div><b>${quiz.score!=null?'✓':'—'}</b><span>Quiz</span></div><div><b>${shlok.done?'✓':'—'}</b><span>Shlok</span></div><div><b>${my.sadhanaDone?'✓':'—'}</b><span>Sadhana log</span></div></div><label class="task"><input id="ekadashiSadhanaDone" type="checkbox" ${my.sadhanaDone?'checked':''}> Ekadashi Sadhana complete</label><button id="saveEkadashiSadhana" class="primary">Save Sadhana status</button></div><div class="card"><h3>Participants · ${Object.keys(participants).length}</h3><p class="muted small">Only completed activities receive a tick.</p><div>${pRows.map((r,i)=>`<div class="item"><b>#${i+1} · ${esc(r.name||'Devotee')}</b><small>Japa ${r.japa?'✓':'—'} · Quiz ${r.quiz?'✓':'—'} · Shlok ${r.shlok?'✓':'—'} · Sadhana ${r.sadhana?'✓':'—'}</small></div>`).join('')||'<p class="muted">No participants yet.</p>'}</div></div>`;
 $('joinEkadashi').onclick=async()=>{const row={joined:true,name:activeMember?.name||profile.name,memberId:key,uid:me.uid,joinedAt:Date.now(),japa:Math.floor(Number(japa.totalBeads||0)/108)>0,quiz:!!quiz.score,shlok:!!shlok.done,sadhana:!!my.sadhanaDone};await db.ref(path).update({joined:true,joinedAt:Date.now()});await db.ref(`ekadashiParticipants/${d}/${me.uid}_${key}`).update(row);loadEkadashi()};$('skipEkadashi').onclick=async()=>{await db.ref(path).update({joined:false,answeredAt:Date.now()});loadEkadashi()};$('saveEkadashiSadhana').onclick=async()=>{const sadhanaDone=$('ekadashiSadhanaDone').checked;await db.ref(path).update({sadhanaDone});await db.ref(`ekadashiParticipants/${d}/${me.uid}_${key}`).update({joined:joined,name:activeMember?.name||profile.name,memberId:key,uid:me.uid,japa:Math.floor(Number(japa.totalBeads||0)/108)>0,quiz:!!quiz.score,shlok:!!shlok.done,sadhana:sadhanaDone});toast('Ekadashi Sadhana saved');loadEkadashi()};
}
async function loadYoutube(){const s=await db.ref('youtube').once('value'),v=s.val()||{};$('youtubeList').innerHTML=Object.values(v).sort((a,b)=>(b.createdAt||0)-(a.createdAt||0)).map(x=>`<div class="video"><h3>${esc(x.title)}</h3><p>${esc(x.description||'')}</p><button onclick="window.open('${esc(x.url)}','_blank')">Watch Video</button></div>`).join('')||'<div class="card">No videos yet.</div>';$('homeYoutube').innerHTML=Object.values(v).slice(-1).map(x=>`<div class="video"><h3>${esc(x.title)}</h3><button onclick="window.open('${esc(x.url)}','_blank')">Watch Video</button></div>`).join('')||'<div class="card">No daily video yet.</div>'}
async function loadBooks(){const s=await db.ref('books').once('value'),v=s.val()||{};$('bookList').innerHTML=Object.values(v).map(x=>`<div class="book"><h3>${esc(x.title)}</h3><p>${esc(x.author||'')}</p><small>${esc(x.language||'')} · ${esc(x.price||'')}</small><p>${esc(x.description||'')}</p>${x.url?`<button onclick="window.open('${esc(x.url)}','_blank')">View / Buy</button>`:''}</div>`).join('')||'<div class="card">No books added yet.</div>'}
async function loadQuotes(){const s=await db.ref('prabhupadaToday').once('value'),v=s.val()||{};$('quoteList').innerHTML=Object.entries(v).sort((a,b)=>b[0].localeCompare(a[0])).slice(0,20).map(([d,x])=>`<article class="quote-paper"><div class="quote-flower">✿ ❀ ✿</div><small>${esc(d)}</small><h3>🌸 Prabhupada Vani 🌸</h3><section><b>हिन्दी</b><p>“${esc(x.text_hindi||x.text||'')}”</p></section><section><b>বাংলা</b><p>“${esc(x.text_bengali||'')}”</p></section><small>Source: ${esc(x.source||'')}</small><div class="quote-flower">❀ ✿ ❀</div></article>`).join('')||'<div class="card">No daily inspiration yet.</div>'}
async function loadNotifications(){const s=await db.ref('notifications').once('value'),v=s.val()||{};const arr=Object.values(v).sort((a,b)=>(b.createdAt||0)-(a.createdAt||0));$('notificationList').innerHTML=arr.map(x=>`<div class="notice"><h3>${esc(x.title)}</h3><p>${esc(x.text||'')}</p><small>${new Date(x.createdAt||Date.now()).toLocaleString()}</small></div>`).join('')||'<div class="card">No notifications yet.</div>';$('homeUpdates').innerHTML=arr.slice(0,3).map(x=>`<div class="notice"><b>${esc(x.title)}</b><small>${esc(x.text||'')}</small></div>`).join('')||'<div class="card">No updates yet.</div>';if(arr.length)$('dot').style.display='block'}

/* ===== Vaishnav World Pro features: achievements, 30-day challenge, yearly and daily boards ===== */
const VW_BADGE_STEPS=[
 {kind:'mala',label:'Japa Mala',icon:'📿',steps:[100,200,300,500,750,1000]},
 {kind:'quiz',label:'Quiz Points',icon:'🧠',steps:[10,50,100,250,500,1000,2500,5000,10000,25000]},
 {kind:'shlok',label:'Shlok Sadhak',icon:'📖',steps:[7,30,50,100,200,365]},
 {kind:'sadhana',label:'Sadhana Seeker',icon:'🪷',steps:[7,30,50,100,200,365]},
 {kind:'challenge',label:'Challenge Champion',icon:'🏆',steps:[7,30,50,100,200,365]},
 {kind:'ekadashi',label:'Ekadashi Vrat Days',icon:'🌙',steps:[1,3,5,11,21,51,108]}
];
function ensureProPanels(){
 const stats=document.getElementById('stats'); if(!stats)return;
 const smartPanels=[['japa','japaSmartProgress'],['sadhana','sadhanaSmartProgress'],['quiz','quizSmartProgress'],['shlok','shlokSmartProgress'],['challenge','challengeSmartProgress']];
 smartPanels.forEach(([pageId,id])=>{const page=document.getElementById(pageId);if(page&&!document.getElementById(id)){const card=document.createElement('div');card.className='card smart-progress-card';card.id=id;card.innerHTML='<h3>🎯 Your next milestone</h3><p class="muted">Loading your progress…</p>';const anchor=page.querySelector('.page-head');if(anchor)anchor.after(card);else page.prepend(card);}});
 // Achievements are displayed on their own page. Calendar, yearly report and
 // leaderboards are part of Sadhana Statistics.
 if(!document.getElementById('thirtyDayChallenge')){
  const wrap=document.createElement('div');wrap.id='thirtyDayChallenge';wrap.className='pro-section card';wrap.innerHTML=`<h3>🌱 30-Day Bhakti Challenge</h3><p class="muted small">Complete one mindful bhakti activity each day. Your streak and progress are saved per member.</p><div id="challenge30Progress"></div><div id="challenge30Task"></div><div id="challenge30Calendar" class="bhakti-calendar"></div>`;
  const page=document.getElementById('challenge');if(page)page.appendChild(wrap);
 }
}
function proLocalDate(d=new Date()){const x=new Date(d);x.setHours(12,0,0,0);return x.getFullYear()+'-'+String(x.getMonth()+1).padStart(2,'0')+'-'+String(x.getDate()).padStart(2,'0')}
function proSafeNum(v){return Math.max(0,Number(v||0))}
async function loadProAchievements(){
 ensureProPanels();if(!me||!activeMember)return;
 const japa=readLocalJapa();let sadhana={},shlok={},quiz={},challenge={},ekadashi={};
 try{sadhana=(await db.ref(memberPath('sadhana','entries')).once('value')).val()||{}}catch(e){}
 try{shlok=(await db.ref(memberPath('shlokChallenge')).once('value')).val()||{}}catch(e){}
 try{quiz=(await db.ref('quiz/results').once('value')).val()||{}}catch(e){}
 try{challenge=(await db.ref('challengeProgress').once('value')).val()||{}}catch(e){}
 try{ekadashi=(await db.ref(memberPath('ekadashi')).once('value')).val()||{}}catch(e){}
 const year=String(new Date().getFullYear());
 // Lifetime counters drive smart progress and badges; yearly counters are kept separate for the yearly report.
 const allJapaDates=Object.keys(japa).filter(d=>proSafeNum(japa[d]?.totalBeads||japa[d]?.beads)>0);
 const allSadhanaDates=Object.keys(sadhana);
 const allShlokDates=Object.keys(shlok).filter(d=>shlok[d]?.done);
 const allQuizDates=Object.entries(quiz).filter(([d,users])=>users&&users[activeKey()]).map(([d])=>d);
 const allEkadashiDates=Object.keys(ekadashi).filter(d=>ekadashi[d]?.joined===true);
 const allChallengeDates=new Set();Object.values(challenge).forEach(group=>{const r=group?.[activeKey()];if(r&&Number(r.points||0)>0){allChallengeDates.add(r.updatedAt?proLocalDate(new Date(r.updatedAt)):proLocalDate())}});
 const japaDates=allJapaDates.filter(d=>d.startsWith(year));
 const sadhanaDates=allSadhanaDates.filter(d=>d.startsWith(year));
 const shlokDates=allShlokDates.filter(d=>d.startsWith(year));
 const quizDates=allQuizDates.filter(d=>d.startsWith(year));
 const challengeDates=new Set([...allChallengeDates].filter(d=>d.startsWith(year)));
 const totalBeads=Object.values(japa).reduce((a,x)=>a+proSafeNum(x?.totalBeads||x?.beads),0), totals={mala:Math.floor(totalBeads/108),quiz:allQuizDates.length,shlok:allShlokDates.length,sadhana:allSadhanaDates.length,challenge:allChallengeDates.size,ekadashi:allEkadashiDates.length};
 const quizPointsLifetime=Object.entries(quiz).reduce((sum,[date,users])=>sum+Number(users?.[activeKey()]?.score||0),0);const milestoneMap={mala:[10,25,50,100,200,300,500,750,1000,1500,2000,5000,10000],quiz:[10,50,100,250,500,1000,2500,5000,10000,25000],shlok:[1,7,30,50,100,200,365],sadhana:[1,7,30,50,100,200,365],challenge:[1,7,15,30,50,100,200,365],ekadashi:[1,3,5,11,21,51,108]};
 const activityMap=[{id:'japaSmartProgress',kind:'mala',label:'Lifetime Japa',unit:'mala',value:totals.mala,icon:'📿'},{id:'quizSmartProgress',kind:'quiz',label:'Lifetime Quiz Points',unit:'quiz points',value:quizPointsLifetime,icon:'🧠'},{id:'shlokSmartProgress',kind:'shlok',label:'Shlok days completed',unit:'days',value:totals.shlok,icon:'📖'},{id:'sadhanaSmartProgress',kind:'sadhana',label:'Sadhana entries',unit:'days',value:totals.sadhana,icon:'🪷'},{id:'challengeSmartProgress',kind:'challenge',label:'Challenge days',unit:'days',value:totals.challenge,icon:'🏆'},{id:'ekadashiSmartProgress',kind:'ekadashi',label:'Ekadashi Vrat days',unit:'days',value:totals.ekadashi,icon:'🌙'}];
 activityMap.forEach(a=>{const el=document.getElementById(a.id);if(!el)return;const steps=milestoneMap[a.kind]||[],next=steps.find(n=>n>a.value),prev=[0,...steps.filter(n=>n<=a.value)].pop()||0,target=next||((Math.floor(a.value/1000)+1)*1000),progress=Math.max(0,Math.min(100,(a.value-prev)/Math.max(1,target-prev)*100));el.innerHTML=`<h3>🎯 ${a.icon} ${a.label}</h3><div class="smart-progress-meta"><b>${a.value} ${a.unit}</b><span>${target-a.value} to next milestone</span></div><div class="pro-progress"><i style="width:${progress}%"></i></div><p class="muted small">Reach ${target} ${a.unit} to unlock your next achievement card.</p>`;});
 let html='';const earned=[];
 for(const group of VW_BADGE_STEPS){for(const n of group.steps){const id=group.kind+'_'+n,ok=(group.kind==='quiz'?quizPointsLifetime:totals[group.kind])>=n;if(ok)earned.push(id);html+=`<div class="achievement-card ${ok?'unlocked':''}"><span class="achievement-icon">${group.icon}</span><b>${group.label} · ${n}</b><small>${ok?'✓ Unlocked':'Reach '+n+' '+(group.kind==='mala'?'mala':group.kind==='quiz'?'quiz points':group.kind==='ekadashi'?'Ekadashi days':'days')}</small><div class="pro-progress"><i style="width:${Math.min(100,(group.kind==='quiz'?quizPointsLifetime:totals[group.kind])/n*100)}%"></i></div></div>`}}
 const ekadashiCount=allEkadashiDates.length;html='<div class="achievement-summary"><b>🌙 Ekadashi Vrat Days: '+ekadashiCount+'</b><small>Counted from dates you selected “Yes, I am observing”.</small></div>'+html;const box=document.getElementById('proAchievements');if(box)box.innerHTML=html;
 // Award each achievement exactly once, after the threshold is reached.
 for(const id of earned){try{await awardPoints(5,'Achievement badge',`badge_${id}`)}catch(e){}}
 let ekadashiRecords={};try{ekadashiRecords=(await db.ref(memberPath('ekadashi')).once('value')).val()||{}}catch(e){};const cal=document.getElementById('proCalendar');if(cal){const now=new Date(),days=new Date(now.getFullYear(),now.getMonth()+1,0).getDate(),first=new Date(now.getFullYear(),now.getMonth(),1).getDay();let h='';['S','M','T','W','T','F','S'].forEach(x=>h+=`<div class="bhakti-day"><b>${x}</b></div>`);for(let i=0;i<first;i++)h+='<div></div>';for(let d=1;d<=days;d++){const key=proLocalDate(new Date(now.getFullYear(),now.getMonth(),d)),done=proSafeNum(japa[key]?.totalBeads||japa[key]?.beads)>0||sadhana[key]||shlok[key]?.done||quizDates.includes(key)||!!ekadashiRecords[key]?.sadhanaDone;h+=`<div class="bhakti-day ${done?'done':''} ${key===proLocalDate()?'today':''}" title="${key}">${d}${done?' ✓':''}</div>`}cal.innerHTML=h}
 const yearJapa=japaDates.reduce((a,d)=>a+proSafeNum(japa[d]?.totalBeads||japa[d]?.beads),0), yearMala=Math.floor(yearJapa/108),yearEl=document.getElementById('yearlyStats');if(yearEl)yearEl.innerHTML=`<div><b>${yearMala}</b><span>Mala this year</span></div><div><b>${quizDates.length}</b><span>Quiz days</span></div><div><b>${shlokDates.length}</b><span>Shlok days</span></div><div><b>${sadhanaDates.length}</b><span>Sadhana days</span></div><div><b>${challengeDates.size}</b><span>Challenge days</span></div>`;
 const rows=Array.from({length:12},(_,i)=>{const m=String(i+1).padStart(2,'0'),prefix=year+'-'+m,beads=Object.entries(japa).filter(([d])=>d.startsWith(prefix)).reduce((a,[d,x])=>a+proSafeNum(x?.totalBeads||x?.beads),0),sd=sadhanaDates.filter(d=>d.startsWith(prefix)).length,sh=shlokDates.filter(d=>d.startsWith(prefix)).length,qd=quizDates.filter(d=>d.startsWith(prefix)).length;return `<tr><td>${prefix}</td><td>${Math.floor(beads/108)}</td><td>${qd}</td><td>${sh}</td><td>${sd}</td></tr>`}).join('');const yr=document.getElementById('yearlyRows');if(yr)yr.innerHTML=`<div style="overflow-x:auto"><table class="pro-table"><thead><tr><th>Month</th><th>Mala</th><th>Quiz</th><th>Shlok</th><th>Sadhana</th></tr></thead><tbody>${rows}</tbody></table></div>`;
 await loadProYearlyLeaderboard();await loadMonthlyAchievementLeaderboard();await loadProDailyBoard('japa');await loadThirtyDayChallenge();
}
async function loadProDailyBoard(kind='japa'){
 const box=document.getElementById('dailyProBoard');if(!box||!me)return;box.innerHTML='<p class="muted">Loading…</p>';
 try{const date=today();let rows=[];
  if(kind==='quiz'){const s=(await db.ref('quiz/results/'+date).once('value')).val()||{};rows=Object.values(s).map(r=>({name:r.name||'Devotee',avatar:r.avatar||VW_AVATARS[0],score:Number(r.score||0),metric:`${Number(r.score||0)}/${Number(r.total||0)}`})).sort((a,b)=>b.score-a.score)}
  else {const root=kind==='japa'?'japa':kind==='sadhana'?'sadhana':'shlokChallenge',s=(await db.ref(root).once('value')).val()||{};Object.values(s).forEach(users=>Object.values(users||{}).forEach(members=>{if(!members||typeof members!=='object')return;let v;if(kind==='japa')v=members.daily?.[date];else if(kind==='sadhana')v=members.entries?.[date];else v=members[date];if(!v)return;let score=kind==='japa'?Math.floor(proSafeNum(v.totalBeads||v.beads)/108):kind==='sadhana'?1:(v.done?1:0);if(score)rows.push({name:v.name||'Devotee',avatar:v.avatar||'🦚',score,metric:kind==='japa'?score+' mala':kind==='sadhana'?'Completed':'Completed'})}));rows.sort((a,b)=>b.score-a.score)}
  rows=rows.slice(0,10);const boardHtml=rows.length?`<table class="pro-table"><thead><tr><th>#</th><th>Devotee</th><th>${kind==='japa'?'Mala':kind==='quiz'?'Score':'Status'}</th></tr></thead><tbody>${rows.map((r,i)=>`<tr><td>${i===0?'🥇':i===1?'🥈':i===2?'🥉':i+1}</td><td>${avatarHtml(r.avatar)}${esc(r.name)}</td><td>${r.metric}</td></tr>`).join('')}</tbody></table><p class="muted small">Today · ${date}</p>`:'<p class="muted">No entries for this leaderboard yet.</p>';box.innerHTML=boardHtml;if(kind==='japa'&&document.getElementById('japaLeaderboard'))document.getElementById('japaLeaderboard').innerHTML=boardHtml;
 }catch(e){box.innerHTML='<p class="muted">Leaderboard will appear when data is available.</p>'}
}
const VW_30_TASKS=[
 {title:'Complete your chosen Japa goal',detail:'Record today’s Japa in the Japa counter.'},
 {title:'Read today’s Shlok',detail:'Read the published Shlok and write a short summary.'},
 {title:'Complete today’s Quiz',detail:'Try the daily quiz and review your answers.'},
 {title:'Write a Sadhana reflection',detail:'Record a short, sincere note about today’s practice.'}
];
async function loadThirtyDayChallenge(){
 const box=document.getElementById('challenge30Task');if(!box||!me||!activeMember)return;
 const todayKey=today(),ref=db.ref(memberPath('challenge30')),snap=await ref.once('value'),data=snap.val()||{days:{}};data.days=data.days||{};
 const activeDay=Object.keys(data.days).length+1,done=!!data.days[todayKey],task=VW_30_TASKS[(new Date().getDate()-1)%VW_30_TASKS.length],daysDone=Object.values(data.days).filter(x=>x?.done).length;
 const prog=document.getElementById('challenge30Progress');if(prog)prog.innerHTML=`<b>Day ${Math.min(30,daysDone+1)} of 30</b> · ${daysDone}/30 completed<div class="pro-progress"><i style="width:${Math.min(100,daysDone/30*100)}%"></i></div>`;
 box.innerHTML=`<div class="challenge-day"><span style="font-size:25px">${done?'✅':'🌱'}</span><div style="flex:1"><b>${esc(task.title)}</b><div class="muted small">${esc(task.detail)}</div></div><button id="complete30Day" class="primary" ${done||daysDone>=30?'disabled':''}>${done?'Completed':daysDone>=30?'Finished':'Complete day'}</button></div><p class="muted small">Complete the activity in its section first. This is a personal tracking challenge; it does not replace the actual Japa/Quiz/Shlok records.</p>`;
 const cal=document.getElementById('challenge30Calendar');if(cal){let h='';for(let i=1;i<=30;i++){const entry=Object.values(data.days).filter(x=>x?.day===i&&x?.done).length>0;h+=`<div class="bhakti-day ${entry?'done':''}">${i}${entry?' ✓':''}</div>`}cal.innerHTML=h}
 const btn=document.getElementById('complete30Day');if(btn)btn.onclick=async()=>{if(done||daysDone>=30)return;const day=Math.min(30,daysDone+1);data.days[todayKey]={done:true,day,task:task.title,completedAt:Date.now()};data.updatedAt=Date.now();await ref.set(data);await awardPoints(10,'30-Day Bhakti Challenge',`challenge30_${todayKey}`);toast('Bhakti Challenge day complete · +10 XP');await loadThirtyDayChallenge();await loadLevel();await loadMonthlyLeaderboard();};
}

async function loadMonthlyAchievementLeaderboard(){
 const box=document.getElementById('monthlyAchievementLeaderboard');if(!box)return;
 const month=proLocalDate().slice(0,7);
 try{const snap=await db.ref('monthlyLeaderboard/'+month).once('value');const rows=Object.values(snap.val()||{}).sort((a,b)=>Number(b.points||0)-Number(a.points||0)).slice(0,50);
 box.innerHTML=rows.length?`<table class="pro-table"><thead><tr><th>#</th><th>Devotee</th><th>Monthly XP</th></tr></thead><tbody>${rows.map((r,i)=>`<tr><td>${i===0?'🥇':i===1?'🥈':i===2?'🥉':i+1}</td><td>${avatarHtml(r.avatar)}${esc(r.name||'Devotee')}</td><td><b>${Number(r.points||0)}</b></td></tr>`).join('')}</tbody></table><p class="muted small">${month} · highest XP first</p>`:'<p class="muted">Monthly achievement ranking will appear after devotees earn XP.</p>';
 }catch(e){box.innerHTML='<p class="muted">Monthly leaderboard needs read access to monthlyLeaderboard in Firebase.</p>'}
}

async function loadProYearlyLeaderboard(){
 const box=document.getElementById('yearlyLeaderboard');if(!box)return;const year=new Date().getFullYear(),totals={};
 try{
  const months=await Promise.all(Array.from({length:12},(_,i)=>db.ref('monthlyLeaderboard/'+year+'-'+String(i+1).padStart(2,'0')).once('value')));
  months.forEach(s=>Object.entries(s.val()||{}).forEach(([id,r])=>{if(!totals[id])totals[id]={name:r.name||'Devotee',avatar:r.avatar||VW_AVATARS[0],relation:r.relation||'',points:0};totals[id].points+=Number(r.points||0)}));
  const rows=Object.values(totals).sort((a,b)=>b.points-a.points).slice(0,50);
  box.innerHTML=rows.length?`<table class="pro-table"><thead><tr><th>#</th><th>Devotee</th><th>Level</th><th>Year XP</th></tr></thead><tbody>${rows.map((r,i)=>`<tr><td>${i===0?'🥇':i===1?'🥈':i===2?'🥉':i+1}</td><td>${avatarHtml(r.avatar)}${esc(r.name)}</td><td>${Math.floor(r.points/250)+1}</td><td><b>${r.points}</b></td></tr>`).join('')}</tbody></table><p class="muted small">January–December ${year} · highest XP first</p>`:'<p class="muted">Yearly rankings will appear after devotees earn XP.</p>';
 }catch(e){box.innerHTML='<p class="muted">Yearly leaderboard requires read access to monthlyLeaderboard in Firebase.</p>'}
}

document.addEventListener('click',e=>{const b=e.target.closest('[data-proboard]');if(b){document.querySelectorAll('[data-proboard]').forEach(x=>x.classList.toggle('active',x===b));loadProDailyBoard(b.dataset.proboard)}});

async function loadQuizHistory(){
 const box=$('quizHistoryList');if(!box||!me)return;box.innerHTML='<p class="muted">Loading history…</p>';
 try{const all=(await db.ref('quiz/results').once('value')).val()||{},start=profile.registeredAt?new Date(profile.registeredAt):new Date(Date.now()-29*86400000);const days=[];for(let i=0;i<Math.min(365,Math.max(30,Math.ceil((Date.now()-start.getTime())/86400000)+1));i++){const d=new Date();d.setDate(d.getDate()-i);const key=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');if(new Date(key+'T00:00:00')<new Date(start.toDateString()))break;const r=all[key]?.[activeKey()];days.push({date:key,r})}box.innerHTML=days.map(x=>x.r?`<div class="item"><b>✅ ${x.date} · Played</b><small>Score ${Number(x.r.score||0)}/${Number(x.r.total||0)} · +${Number(x.r.score||0)} quiz points · ${esc(x.r.language||'')}</small></div>`:`<div class="item"><b>— ${x.date} · Not played</b><small>No quiz record for this date.</small></div>`).join('')||'<p class="muted">Quiz history will appear here.</p>';
 const scores={};Object.entries(all).forEach(([date,users])=>Object.entries(users||{}).forEach(([mid,r])=>{const key=(r.ownerUid||'')+'_'+mid;const id=(r.ownerUid||'')+'_'+mid;if(!scores[id])scores[id]={name:r.name||'Devotee',points:0};scores[id].points+=Number(r.score||0)}));const rows=Object.values(scores).sort((a,b)=>b.points-a.points).slice(0,50);$('quizLifetimeLeaderboard').innerHTML=rows.map((r,i)=>`<div class="item"><b>#${i+1} · ${esc(r.name)}</b><small>${r.points} lifetime quiz points</small></div>`).join('')||'<p class="muted">No quiz points yet.</p>';
 }catch(e){box.innerHTML='<p class="muted">Quiz history could not load. Check Firebase read permissions.</p>'}
}
async function loadLifetimeAchievementLeaderboard(){const box=$('lifetimeAchievementLeaderboard');if(!box)return;try{const us=(await db.ref('users').once('value')).val()||{},rows=[];Object.entries(us).forEach(([uid,u])=>Object.values(u.members||{}).forEach(m=>rows.push({name:m.name||u.name||'Devotee',avatar:avatarFor(m.avatar||u.avatar),xp:Number(m.xp||0)})));rows.sort((a,b)=>b.xp-a.xp);box.innerHTML=rows.slice(0,100).map((r,i)=>`<div class="item"><b>${i===0?'🥇':i===1?'🥈':i===2?'🥉':'#'+(i+1)} · ${avatarHtml(r.avatar,'leader-avatar')} ${esc(r.name)}</b><small>${r.xp} lifetime XP · Level ${Math.floor(r.xp/250)+1}</small></div>`).join('')||'<p class="muted">No registered member progress yet.</p>'}catch(e){box.innerHTML='<p class="muted">Lifetime ranking needs Firebase read access to users.</p>'}}
async function loadAll(){await loadProfile();await Promise.all([loadJapa(),loadSadhana(),loadStats(),loadLevel(),loadChallenges(),loadCourses(),loadContent(),loadCalendar(),loadYoutube(),loadBooks(),loadQuotes(),loadNotifications(),loadShlokChallenge(),loadMonthlyLeaderboard(),loadProAchievements(),loadQuizHistory(),loadLifetimeAchievementLeaderboard()])}
document.addEventListener('click',e=>{if(e.target.closest('#switchMemberBtn'))showMemberChooser(true);if(e.target.closest('#addMemberBtn'))openAddMember()});
auth.onAuthStateChanged(async u=>{if(u){me=u;const s=await db.ref('users/'+u.uid).once('value');profile=s.val();if(profile&&Number(profile.schemaVersion||0)>=2&&profile.name&&profile.mobile&&profile.dob&&profile.gender)await showApp();else{if(profile){$('loginName').value=profile.name||'';$('loginMobile').value=profile.mobile||'';$('loginDob').value=profile.dob||'';$('loginGender').value=profile.gender||'';}setTimeout(()=>{$('splash').classList.add('hidden');$('auth').classList.remove('hidden')},500)}}else{setTimeout(()=>{$('splash').classList.add('hidden');$('auth').classList.remove('hidden')},900)}});setTimeout(()=>$('splash').classList.add('hidden'),2600);$('homeGrid').innerHTML=[['japa','◉','Japa','108 beads'],['sadhana','◌','Sadhana','Daily log'],['stats','▥','Statistics','Yearly report'],['achievements','🏅','Achievements','Badges & milestones'],['challenge','♛','Challenge','Points & rank'],['shlok','ॐ','Shlok','30-day reading'],['course','▣','Courses','Learn'],['quiz','?','Quiz','10 questions'],['content','☷','Katha','Stories'],['calendar','□','Calendar','Festivals'],['ekadashi','🪷','Ekadashi','Vrat & progress'],['youtube','▶','YouTube','Daily videos'],['books','▤','Books','Book store'],['prabhupada','✦','Prabhupada','Daily inspiration'],['notifications','◉','Updates','Notifications']].map(x=>`<button class="feature" data-page="${x[0]}"><i class="feature-icon">${x[1]}</i><b>${x[2]}</b><small>${x[3]}</small></button>`).join('');

// Per-member ready-made avatar selection; no gallery or Storage required.
(function(){const b=document.getElementById('avatarPicker');if(!b)return;b.addEventListener('click',async()=>{if(!me)return;const current=avatarFor(activeMember?.avatar||profile?.avatar),i=VW_AVATARS.indexOf(current),next=VW_AVATARS[(i+1)%VW_AVATARS.length];b.innerHTML=avatarHtml(next,'avatar-image');const hav=document.getElementById('homeAvatar');if(hav)hav.innerHTML=avatarHtml(next,'avatar-image');if(activeMember){activeMember.avatar=next;members[activeMember.id]=activeMember;try{await db.ref('users/'+me.uid+'/members/'+activeMember.id+'/avatar').set(next);if(activeMember.id==='you'){profile.avatar=next;await db.ref('users/'+me.uid+'/avatar').set(next)}}catch(e){toast('Avatar could not be saved. Check connection.')}}else{profile.avatar=next;try{await db.ref('users/'+me.uid+'/avatar').set(next)}catch(e){toast('Avatar could not be saved.')}}toast('Avatar updated');});})();
