Vaishnav World update notes

Devotee app: added illustrated devotional character gallery (Krishna, Radha, Vishnu, Ganesha, Ram, Lakshmi, Shiva, Chaitanya) and five-level daily Shlok Reading Challenge with Hindi/Bengali meaning, per-level summary, circular progress meter, and challenge prize display. Each level summary is saved to member progress and also to shlokSummaries/YYYY-MM-DD/UID/MEMBER/levelN for Admin review. Shlok badge cards retain existing overall milestones; book/chapter/verse metadata is stored from Admin publishing.

Admin app: Shlok Reading Studio allows a date, book/skand/chapter/verse range, reward, and five levels, each with Sanskrit shlok plus separate Hindi and Bengali meanings. Publish uses shared Firebase path shlokaReading/YYYY-MM-DD.

AI: no AI API has been connected in this ZIP. AI can be added through a secure server/Cloud Function with an API key kept server-side; never put a private AI API key in the app or ZIP.

Validation: ZIP integrity and JavaScript syntax are checked locally; Firebase rules, runtime behavior and Android APK build were not tested. SVG deity artwork is stylized illustration, not actual 3D models.
