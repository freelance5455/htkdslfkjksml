Vaishnav World Devotee ZIP - feature notes

Quiz language separation:
- Devotee quiz selector has Hindi and Bengali options.
- Hindi quiz loads from Firebase path quiz/daily/hindi/YYYY-MM-DD.
- Bengali quiz loads from Firebase path quiz/daily/bengali/YYYY-MM-DD.
- Quiz result screen code is included.

Ekadashi calendar flow:
- Admin should publish an event in the shared calendar with its date and type/title containing Ekadashi.
- On that date, the calendar event card includes an Open Ekadashi Vrat button.
- The dedicated Ekadashi section also checks for today's published Ekadashi event.

Book store/payment status:
- This ZIP does not yet contain a fully integrated, production-ready payment gateway checkout.
- Before taking real payments, choose a payment provider, create/verify the merchant account, configure a secure backend to create orders and verify signed payment webhooks, and configure shipping/returns/privacy details.
- Never put payment secret keys in HTML/JavaScript or the APK.
