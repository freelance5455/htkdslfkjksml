Vaishnav World Devotee ZIP update
- Added HH:MM:SS countdown card for the next published Ekadashi date when no Ekadashi is happening today.
- After a daily quiz is completed, shows a countdown until the next day/quiz window.
- Prabhupada Today displays separate Hindi and Bengali quote areas on a decorative floral paper card.
- Calendar details can display optional Hindi/Bengali Sanskrit shlok, meaning and bhavarth uploaded by Admin.
- Top-three medals added to quiz and daily leaderboard renderers.
- Japa chart is a date-wise blue SVG line chart based on saved bead totals; quick floating button stays inside the app and increments the main counter.

Note: a true Android system overlay above other apps requires the native Android overlay service and user permission. This web button is an in-app floating button; do not treat it as a cross-app overlay. Firebase live rules, APK build/install and device testing are not performed by this ZIP edit.
