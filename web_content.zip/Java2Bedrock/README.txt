# Java2Bedrock — mobile starter website

A browser-based prototype for inspecting Java `.jar` archives and creating a Bedrock `.mcaddon` starter pack.

## Run on Android
1. Extract `Java2Bedrock-Website.zip` using your file manager.
2. Open `index.html` in Chrome.
3. Keep an internet connection on the first load so JSZip can load from jsDelivr.
4. Tap **Choose a .jar mod**, select your mod, then tap **Analyze mod**.
5. Review the report and conversion options, then tap **Build Bedrock .mcaddon**.
6. Open the downloaded `Java2Bedrock.mcaddon` file and choose Minecraft if Android asks which app to use.
7. Test in a NEW world with cheats enabled. Keep a backup of important worlds.

## What works in this prototype
- Reads a JAR as a ZIP archive in the browser.
- Scans file paths for textures, recipes, models, animations, entity/item/block assets and mod metadata.
- Extracts PNG files under `assets/<namespace>/...` into a starter Resource Pack texture folder.
- Attempts a limited conversion of common Java shaped recipe JSON files.
- Creates a Behavior Pack, Resource Pack, `.mcaddon`, and compatibility report.

## Important limitations
This is not a universal Java-to-Bedrock converter. Java mods can contain compiled Java code, Forge/Fabric APIs, custom rendering, AI, networking, and game logic that Bedrock addons cannot directly execute. Those features need to be recreated with Bedrock JSON, Script API, geometry, animation controllers, and resource-pack definitions. The recipe converter supports only a small subset and generated recipes may need manual correction. Extracted textures may need renaming and atlas mapping. Always inspect and test output.

## Privacy
The selected JAR is processed locally in the browser by this page; it is not uploaded to a server. JSZip is loaded from a public CDN.
