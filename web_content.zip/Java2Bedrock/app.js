const $=id=>document.getElementById(id);
let selectedFile=null, zipData=null, scan=null;
const setStatus=(s)=>$('status').textContent=s;
$('modFile').addEventListener('change',e=>{selectedFile=e.target.files[0]||null;$('fileName').textContent=selectedFile?selectedFile.name:'No file selected';$('analyzeBtn').disabled=!selectedFile;$('buildBtn').disabled=true;zipData=null;scan=null;});
function addResult(label,value){const d=document.createElement('div');d.className='result';const a=document.createElement('span'),b=document.createElement('span');a.textContent=label;b.textContent=value;d.append(a,b);$('details').append(d);}
$('analyzeBtn').addEventListener('click',async()=>{
 if(!selectedFile)return;
 if(typeof JSZip==='undefined'){setStatus('Could not load ZIP reader. Connect to the internet and reload this page.');return;}
 setStatus('Reading archive…');$('analyzeBtn').disabled=true;
 try{
  zipData=await JSZip.loadAsync(selectedFile);
  const names=Object.keys(zipData.files).filter(n=>!zipData.files[n].dir);
  const count=(re)=>names.filter(n=>re.test(n)).length;
  const png=names.filter(n=>/\.png$/i.test(n)&&n.startsWith('assets/'));
  const recipes=names.filter(n=>/^data\/[^/]+\/recipes\/.*\.json$/i.test(n));
  const models=count(/(models|geo|geometry)/i), anims=count(/animat/i);
  const entity=count(/(entities|entity)/i), item=count(/items?/i), block=count(/blocks?/i);
  scan={names,png,recipes,models,anims,entity,item,block};
  $('counts').textContent=names.length+' files found';
  $('summary').textContent=`Scanned ${names.length} files. This is an inspection, not a full Java code converter.`;
  $('details').innerHTML='';
  addResult('Textures (PNG)',png.length+' found');
  addResult('Recipe JSON files',recipes.length+' found');
  addResult('Entity/model-related files',entity+' / '+models);
  addResult('Animation-related files',anims+' found');
  addResult('Item/block-related paths',item+' / '+block);
  addResult('Java mod metadata',names.some(n=>/fabric\.mod\.json|META-INF\/mods\.toml|mcmod\.info/i.test(n))?'Detected':'Not detected');
  setStatus('Analysis complete. Review the report, then build the Bedrock starter addon.');
  $('buildBtn').disabled=false;
 }catch(err){console.error(err);setStatus('Could not read this file as a ZIP/JAR archive. It may be damaged or encrypted.');}
 finally{$('analyzeBtn').disabled=false;}
});
function uuid(){return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,c=>{const r=Math.random()*16|0;return(c==='x'?r:(r&3|8)).toString(16)});}
function safeName(s){return s.replace(/[^a-z0-9_.-]/gi,'_').toLowerCase();}
function convertRecipe(raw,sourcePath){
 try{
  const r=JSON.parse(raw), id=sourcePath.match(/^data\/([^/]+)\/recipes\/(.+)\.json$/i);
  if(!id||!r.result)return null;
  let ingredients=[],pattern=[];
  if(Array.isArray(r.ingredients)) ingredients=r.ingredients;
  if(Array.isArray(r.key)&&r.pattern) { // unsupported nonstandard format
    return null;
  }
  if(r.key&&Array.isArray(r.pattern)){
    const keys=Object.keys(r.key);
    for(const row of r.pattern){let out='';for(const ch of row){const k=r.key[ch];out+=k?(typeof k==='string'?k:(k.item||k.tag||'')):' ';}pattern.push(out);}
    ingredients=keys.map(k=>{const v=r.key[k];return {key:k,values:[typeof v==='string'?v:(v.item||v.tag||'') ]};});
  }
  const result=typeof r.result==='string'?r.result:(r.result.item||'');
  if(!result)return null;
  const output={format_version:'1.20.10', 'minecraft:recipe_shaped':{description:{identifier:`j2b:${safeName(id[2])}`},tags:['crafting_table'],pattern, key:Object.fromEntries(ingredients.map(x=>[x.key||'A',{item:x.values?.[0]||x.item||''}])),result:{item:result,count:r.result.count||1}}};
  if(r.type&&r.type.includes('smelting'))return null;
  if(!pattern.length)return null;
  return output;
 }catch(e){return null;}
}
$('buildBtn').addEventListener('click',async()=>{
 if(!scan||!zipData)return;
 $('buildBtn').disabled=true;setStatus('Building Behavior Pack and Resource Pack…');
 try{
  const out=new JSZip(), rp=out.folder('Java2Bedrock_RP'),bp=out.folder('Java2Bedrock_BP');
  const manifest=(name,desc,type)=>({format_version:2,header:{name,description:desc,uuid:uuid(),version:[1,0,0],min_engine_version:[1,20,0]},modules:[{type,uuid:uuid(),version:[1,0,0]}]});
  rp.file('manifest.json',JSON.stringify(manifest('Java2Bedrock Resources','Extracted compatible textures','resources'),null,2));
  bp.file('manifest.json',JSON.stringify(manifest('Java2Bedrock Behavior','Converted supported recipes and compatibility report','data'),null,2));
  let textureCount=0,recipeCount=0,failedRecipes=0;
  if($('optTextures').checked){
   for(const path of scan.png){
    const parts=path.split('/'); if(parts.length<4)continue;
    const ns=parts[1],rest=parts.slice(2).join('/').replace(/\.png$/i,'');
    const blob=await zipData.file(path).async('uint8array');
    rp.file(`textures/${safeName(ns)}/${rest}`,blob);textureCount++;
   }
   rp.file('textures/terrain_texture.json',JSON.stringify({resource_pack_name:'Java2Bedrock Resources',texture_name:'atlas.terrain',padding:8,num_mip_levels:4,texture_data:{}},null,2));
  }
  if($('optRecipes').checked){
   for(const path of scan.recipes){
    const raw=await zipData.file(path).async('text'), converted=convertRecipe(raw,path);
    if(converted){const dest=path.match(/^data\/([^/]+)\/recipes\/(.+)\.json$/i);bp.file(`recipes/${safeName(dest[1])}/${safeName(dest[2])}.json`,JSON.stringify(converted,null,2));recipeCount++;}
    else failedRecipes++;
   }
  }
  if($('optReport').checked){
   const report=[
    'Java2Bedrock compatibility report',
    '===============================',
    `Source: ${selectedFile.name}`,
    `Archive files scanned: ${scan.names.length}`,
    `Textures extracted: ${textureCount}`,
    `Recipes converted: ${recipeCount}`,
    `Recipes skipped: ${failedRecipes}`,
    `Model-like files detected: ${scan.models}`,
    `Animation-like files detected: ${scan.anims}`,
    '',
    'LIMITATIONS:',
    '- Java bytecode, Forge/Fabric hooks, and Java entity logic are not converted.',
    '- Java entity models and animations must be rebuilt in Bedrock geometry/animation formats.',
    '- Items and blocks need Bedrock item/block definitions and identifiers.',
    '- Recipe conversion supports only a limited subset; inspect generated JSON before use.',
    '- Texture paths and atlas definitions may need manual mapping.',
    '',
    'Run the addon through Minecraft Bedrock testing and Content Log. This report does not guarantee compatibility.'
   ].join('\n');
   bp.file('JAVA2BEDROCK_REPORT.txt',report);
  }
  const mcaddon=new JSZip();
  const rpBlob=await rp.generateAsync({type:'uint8array'});
  const bpBlob=await bp.generateAsync({type:'uint8array'});
  mcaddon.file('Java2Bedrock_RP.mcpack',rpBlob);
  mcaddon.file('Java2Bedrock_BP.mcpack',bpBlob);
  const blob=await mcaddon.generateAsync({type:'blob'});
  const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='Java2Bedrock.mcaddon';a.click();URL.revokeObjectURL(url);
  setStatus(`Export created. ${textureCount} textures extracted, ${recipeCount} recipes converted, ${failedRecipes} recipes skipped. Open the .mcaddon with Minecraft, then test in a new world.`);
 }catch(err){console.error(err);setStatus('Build failed: '+err.message);}
 finally{$('buildBtn').disabled=false;}
});
