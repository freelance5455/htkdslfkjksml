# 2048 Obstacles: APK package

The whole game is one file: `www/index.html`. The font and the three sounds are inside it as base64, so there is nothing else to load.

## Test it first (no tools needed)
Open `www/index.html` in a browser. Arrow keys or swipes to play.

## Build the APK (Capacitor)
You need: Node.js, JDK 21, and Android Studio with its Android SDK.
(Those versions were right for Capacitor 8 when I checked. If a step complains, run `npx cap doctor` and read the first error.)

1. In this folder, install Capacitor (this picks the current version for all of them):
   `npm install @capacitor/core @capacitor/app @capacitor/android`
   `npm install -D @capacitor/cli @capacitor/assets`
2. Create the Android project: `npx cap add android`
3. Make the app icon and splash screen from `assets/`: `npm run icons`
4. Build a debug APK: `npm run apk`
   The file appears at `android/app/build/outputs/apk/debug/app-debug.apk`
   (Or: `npm run studio`, then in Android Studio use Build > Build APK(s).)
5. Put it on a phone: `adb install android/app/build/outputs/apk/debug/app-debug.apk`,
   or copy the file to the phone and allow installing from your file manager.

## Before publishing
- Change `appId` in `capacitor.config.json` (`com.example.obstacles2048` is a placeholder). Do it before step 2.
- A Play Store upload needs a signed release bundle: Android Studio > Build > Generate Signed Bundle / APK.

## Notes
- High scores, settings and the saved game use localStorage inside the app's own storage. Uninstalling the app erases them.
- The Android back button closes the settings panel, then goes to the main menu, then exits.
- `www/manifest.webmanifest` and `www/sw.js` are only for hosting the game as a web app (PWA). The APK doesn't need them.
