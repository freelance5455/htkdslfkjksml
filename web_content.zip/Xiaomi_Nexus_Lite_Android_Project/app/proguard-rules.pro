# Keep default Android rules. JavaScript bridge methods are annotated with @JavascriptInterface.
