package com.xiaominexuslite

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.view.Window
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.net.Uri
import org.json.JSONObject
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import androidx.webkit.WebResourceErrorCompat
import androidx.webkit.WebResourceResponseCompat

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private var lastBatteryIntent: Intent? = null

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_BATTERY_CHANGED) {
                lastBatteryIntent = intent
                pushNativeDataToPage()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 14, 20)
        window.navigationBarColor = Color.rgb(12, 14, 20)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.navigationBarDividerColor = Color.rgb(38, 46, 61)
        }
        window.decorView.systemUiVisibility = 0

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this)
        webView.setBackgroundColor(Color.rgb(12, 14, 20))
        webView.overScrollMode = View.OVER_SCROLL_NEVER
        webView.isVerticalScrollBarEnabled = false
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.settings.setSupportMultipleWindows(false)
        webView.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): android.webkit.WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }

            @Suppress("DEPRECATION")
            override fun shouldInterceptRequest(
                view: WebView,
                url: String
            ): android.webkit.WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(Uri.parse(url))
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                // Keep the app on its bundled origin. External URLs are not opened inside the app.
                val uri = request.url
                return uri.host != "appassets.androidplatform.net"
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                pushNativeDataToPage()
            }
        }
        webView.addJavascriptInterface(NativeBridge(), "NexusNative")
        setContentView(webView)
        lastBatteryIntent = registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) pushNativeDataToPage()
    }

    override fun onDestroy() {
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("NexusNative")
            webView.destroy()
        }
        super.onDestroy()
    }

    override fun onBackPressed() {
        webView.evaluateJavascript(
            "(function(){var n=document.getElementById('news-modal');" +
                "if(n && !n.classList.contains('hidden')){if(typeof closeNewsModal==='function')closeNewsModal();return 'handled';}" +
                "var s=document.getElementById('settings-modal');" +
                "if(s && !s.classList.contains('hidden')){if(typeof closeSettingsModal==='function')closeSettingsModal();return 'handled';}" +
                "return 'exit';})()"
        ) { result ->
            if (result != "\"handled\"") finish()
        }
    }

    private fun pushNativeDataToPage() {
        if (!::webView.isInitialized) return
        val payload = JSONObject(getDeviceInfo()).toString()
        val quoted = JSONObject.quote(payload)
        webView.post {
            webView.evaluateJavascript(
                "window.NexusNativeData && window.NexusNativeData($quoted);",
                null
            )
        }
    }

    private fun getDeviceInfo(): JSONObject {
        val intent = lastBatteryIntent
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val health = intent?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1) ?: -1
        val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val tempTenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val voltageMv = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
        val batteryManager = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val currentUa = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        } else -1

        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val statusText = when (status) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Заряжается"
            BatteryManager.BATTERY_STATUS_FULL -> "Заряжена"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "Разряжается"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Не заряжается"
            else -> "Статус неизвестен"
        }
        val healthText = when (health) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Хорошее"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Перегрев"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Неисправна"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Перенапряжение"
            BatteryManager.BATTERY_HEALTH_COLD -> "Переохлаждение"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Ошибка"
            else -> "Неизвестно"
        }
        val pluggedText = when (plugged) {
            BatteryManager.BATTERY_PLUGGED_AC -> "Сеть"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            4 -> "Беспроводная зарядка"
            else -> if (charging) "Источник питания" else "Нет питания"
        }

        return JSONObject().apply {
            put("manufacturer", Build.MANUFACTURER)
            put("model", Build.MODEL)
            put("device", Build.DEVICE)
            put("product", Build.PRODUCT)
            put("brand", Build.BRAND)
            put("androidRelease", Build.VERSION.RELEASE ?: "Неизвестно")
            put("sdkInt", Build.VERSION.SDK_INT)
            put("securityPatch", if (Build.VERSION.SDK_INT >= 23) Build.VERSION.SECURITY_PATCH else "Недоступно")
            put("batteryPercent", pct)
            put("batteryAvailable", pct >= 0)
            put("batteryStatus", statusText)
            put("charging", charging)
            put("plugged", pluggedText)
            put("batteryHealth", healthText)
            put("batteryTempC", if (tempTenths >= 0) tempTenths / 10.0 else JSONObject.NULL)
            put("batteryVoltageMv", if (voltageMv >= 0) voltageMv else JSONObject.NULL)
            put("batteryCurrentUa", if (currentUa != Int.MIN_VALUE && currentUa != 0) currentUa else JSONObject.NULL)
            put("nativeBridge", true)
            put("updatedAtMs", SystemClock.elapsedRealtime())
        }
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun getDeviceInfo(): String = this@MainActivity.getDeviceInfo().toString()
    }
}
