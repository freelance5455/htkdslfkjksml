const input = document.getElementById('videoInput');
const video = document.getElementById('video');
const emptyState = document.getElementById('emptyState');
const videoWrap = document.getElementById('videoWrap');
let currentUrl = null;

input.addEventListener('change', () => {
  const file = input.files && input.files[0];
  if (!file) return;
  if (currentUrl) URL.revokeObjectURL(currentUrl);
  currentUrl = URL.createObjectURL(file);
  video.src = currentUrl;
  video.hidden = false;
  emptyState.hidden = true;
  updatePreview();
});

const controls = [
  ['brightness', 'brightnessOut', value => `brightness(${value}%)`],
  ['contrast', 'contrastOut', value => `contrast(${value}%)`],
  ['saturation', 'saturationOut', value => `saturate(${value}%)`]
];

function updatePreview() {
  const filters = controls.map(([id]) => {
    const el = document.getElementById(id);
    return id === 'brightness' ? `brightness(${el.value}%)` :
      id === 'contrast' ? `contrast(${el.value}%)` : `saturate(${el.value}%)`;
  });
  const sharpness = Number(document.getElementById('sharpness').value);
  // CSS não executa nitidez real; este controle é apenas indicativo na versão inicial.
  video.style.filter = filters.join(' ');
  video.style.outline = sharpness > 0 ? '1px solid rgba(196,181,253,.15)' : 'none';
}

controls.forEach(([id, outputId]) => {
  const el = document.getElementById(id);
  const output = document.getElementById(outputId);
  el.addEventListener('input', () => {
    output.value = `${el.value}%`;
    output.textContent = `${el.value}%`;
    updatePreview();
  });
});
const sharpness = document.getElementById('sharpness');
sharpness.addEventListener('input', () => {
  document.getElementById('sharpnessOut').value = sharpness.value;
  document.getElementById('sharpnessOut').textContent = sharpness.value;
  updatePreview();
});

document.getElementById('exportButton').addEventListener('click', () => {
  const resolution = document.getElementById('resolution').value;
  document.getElementById('exportMessage').textContent =
    `Resolução selecionada: ${resolution}. A exportação real ainda não está implementada nesta versão.`;
});

window.addEventListener('beforeunload', () => {
  if (currentUrl) URL.revokeObjectURL(currentUrl);
});
