const fs = require('node:fs');
const { spawnSync } = require('node:child_process');
const root = require('node:path').resolve(__dirname, '..');
function check(condition, text) { if (!condition) { console.error(`FALHOU: ${text}`); process.exitCode = 1; } else console.log(`OK: ${text}`); }
const js = fs.readFileSync(`${root}/app.js`, 'utf8');
const html = fs.readFileSync(`${root}/index.html`, 'utf8');
const native = fs.readFileSync(`${root}/android/app/src/main/java/com/wquality/editor/WQualityExportPlugin.java`, 'utf8');
const pluginManifest = JSON.parse(fs.readFileSync(`${root}/android/app/src/main/assets/capacitor.plugins.json`, 'utf8'));
const syntax = spawnSync(process.execPath, ['--check', `${root}/app.js`], { encoding: 'utf8' });
check(syntax.status === 0, 'JavaScript passa na verificação de sintaxe');
if (syntax.status !== 0) console.error(syntax.stderr);
for (const [id, description] of [['videoInput','importação de arquivo de vídeo'],['trimStart','início do corte'],['trimEnd','fim do corte'],['brightness','brilho'],['contrast','contraste'],['saturation','saturação'],['filterSelect','seleção de filtro'],['resolution','resolução de saída'],['exportButton','ação de exportar'],['exportProgress','progresso de exportação'],['downloadLink','link de download'],['shareVideoButton','compartilhamento do WebM']]) {
  check(html.includes(`id="${id}"`), `HTML inclui ${description}`);
}
for (const marker of ['MediaRecorder','captureStream','createObjectURL(blob)','video.currentTime','videoBitsPerSecond']) check(js.includes(marker), `implementação contém ${marker}`);
check(fs.existsSync(`${root}/capacitor.config.json`) && fs.existsSync(`${root}/package.json`), 'configuração de empacotamento Capacitor presente');
check(html.includes('assets/w-quality-mark.png') && fs.existsSync(`${root}/assets/w-quality-mark.png`), 'logo enviada está presente e vinculada à interface');
check(js.includes("registerPlugin('WQualityExport'") && js.includes("nativePromise('WQualityExport', method, options)") && js.includes('appendChunk') && js.includes('finishExport'), 'exportação Android chama o bridge nativo e grava em blocos');
check(js.includes("lastIndexOf(',')") && !js.includes("split(',')[1]"), 'blocos WebM preservam Base64 apesar da vírgula em vp8,opus');
check(js.includes('MAX_ANDROID_CLIP_SECONDS = 300') && js.includes('MAX_BROWSER_CLIP_SECONDS = 120'), 'limite Android de cinco minutos e limite web de dois minutos estão explícitos');
check(js.includes('navigator.share({ files: [outputFile]') && js.includes('new File([blob]'), 'fallback Web oferece compartilhamento de um arquivo WebM');
check(js.includes('Plugin Android indisponível: usando gravação Web') && js.includes('fallback Web suporta até 2 minutos'), 'Android permite fallback Web, informa limite de duração e não anuncia salvamento nativo');
check(fs.existsSync(`${root}/android/app/src/main/java/com/wquality/editor/WQualityExportPlugin.java`), 'plugin Android de exportação e salvamento existe');
check(native.includes('startExportNotification') && native.includes('updateExportNotification') && native.includes('completeExportNotification'), 'plugin Android emite notificações de progresso e conclusão');
check(native.includes('POST_NOTIFICATIONS') && fs.readFileSync(`${root}/android/app/src/main/AndroidManifest.xml`, 'utf8').includes('POST_NOTIFICATIONS'), 'permissão de notificação Android 13+ está declarada');
check(pluginManifest.some(plugin => plugin.classpath === 'com.wquality.editor.WQualityExportPlugin'), 'PluginManager Android carrega WQualityExport pelo capacitor.plugins.json');
check(fs.readFileSync(`${root}/package.json`, 'utf8').includes('register-android-plugin.js'), 'sincronização Android restaura o classpath do plugin após cap sync');
if (process.exitCode) process.exit(process.exitCode);
