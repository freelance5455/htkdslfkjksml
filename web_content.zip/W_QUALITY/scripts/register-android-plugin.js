const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const pluginFile = path.join(root, 'android/app/src/main/assets/capacitor.plugins.json');
const gradleFile = path.join(root, 'android/capacitor.settings.gradle');
const classpath = 'com.wquality.editor.WQualityExportPlugin';
if (!fs.existsSync(pluginFile)) throw new Error(`Arquivo não encontrado: ${pluginFile}. Execute npm run android:sync primeiro.`);
if (!fs.existsSync(path.join(root, 'android/app/src/main/java/com/wquality/editor/WQualityExportPlugin.java'))) throw new Error('O código-fonte WQualityExportPlugin.java não foi encontrado.');
const plugins = JSON.parse(fs.readFileSync(pluginFile, 'utf8'));
if (!plugins.some(plugin => plugin.classpath === classpath)) plugins.push({ classpath });
fs.writeFileSync(pluginFile, `${JSON.stringify(plugins, null, 2)}\n`);
if (fs.existsSync(gradleFile)) {
  let gradle = fs.readFileSync(gradleFile, 'utf8');
  gradle = gradle.replace("new File('../node_modules/@capacitor/android/capacitor')", "new File('../vendor/capacitor-android/capacitor')");
  if (!gradle.includes("new File('../vendor/capacitor-android/capacitor')")) throw new Error('Não foi possível apontar o Gradle para a biblioteca Capacitor vendorizada.');
  fs.writeFileSync(gradleFile, gradle);
}
console.log(`Plugin Android registrado em capacitor.plugins.json: ${classpath}`);
