package com.wquality.editor;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Context;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;

import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@CapacitorPlugin(
    name = "WQualityExport",
    permissions = {
        @Permission(alias = "legacyStorage", strings = {Manifest.permission.WRITE_EXTERNAL_STORAGE}),
        @Permission(alias = "notifications", strings = {Manifest.permission.POST_NOTIFICATIONS})
    }
)
public class WQualityExportPlugin extends Plugin {
    private static final String CHANNEL_ID = "w_quality_video_export";
    private static final int NOTIFICATION_ID = 73142;
    private final ConcurrentHashMap<String, File> exports = new ConcurrentHashMap<>();
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    @PluginMethod
    public void beginExport(PluginCall call) {
        try {
            String id = UUID.randomUUID().toString();
            File file = new File(getContext().getCacheDir(), "wquality-" + id + ".webm");
            if (!file.createNewFile()) {
                call.reject("Não foi possível preparar o arquivo temporário.");
                return;
            }
            exports.put(id, file);
            JSObject result = new JSObject();
            result.put("exportId", id);
            call.resolve(result);
        } catch (Exception e) {
            call.reject("Não foi possível preparar a exportação: " + e.getMessage());
        }
    }

    @PluginMethod
    public void appendChunk(PluginCall call) {
        String id = call.getString("exportId");
        String encoded = call.getString("base64");
        File file = id == null ? null : exports.get(id);
        if (file == null || encoded == null) {
            call.reject("Sessão de exportação inválida.");
            return;
        }
        io.execute(() -> {
            try (FileOutputStream output = new FileOutputStream(file, true)) {
                byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
                output.write(bytes);
                JSObject result = new JSObject();
                result.put("bytesWritten", bytes.length);
                call.resolve(result);
            } catch (Exception e) {
                call.reject("Falha ao gravar um bloco do vídeo: " + e.getMessage());
            }
        });
    }

    @PluginMethod
    public void finishExport(PluginCall call) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q
            && getPermissionState("legacyStorage") != PermissionState.GRANTED) {
            requestPermissionForAlias("legacyStorage", call, "storagePermissionCallback");
            return;
        }
        saveExport(call);
    }

    @PermissionCallback
    private void storagePermissionCallback(PluginCall call) {
        if (getPermissionState("legacyStorage") != PermissionState.GRANTED) {
            call.reject("A permissão de armazenamento foi negada; o vídeo não foi salvo.");
            return;
        }
        saveExport(call);
    }

    private void saveExport(PluginCall call) {
        String id = call.getString("exportId");
        File input = id == null ? null : exports.get(id);
        if (input == null) {
            call.reject("Arquivo de exportação não encontrado.");
            return;
        }
        String supplied = call.getString("fileName", "w-quality-video.webm");
        String fileName = supplied == null ? "w-quality-video.webm" : supplied.replaceAll("[^A-Za-z0-9._-]", "_");
        if (!fileName.toLowerCase().endsWith(".webm")) fileName += ".webm";
        final String safeName = fileName;
        io.execute(() -> {
            Uri savedUri = null;
            File legacyFile = null;
            try {
                if (input.length() == 0) throw new IllegalStateException("A gravação não contém dados.");
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Video.Media.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Video.Media.MIME_TYPE, "video/webm");
                    values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/W QUALITY");
                    values.put(MediaStore.Video.Media.IS_PENDING, 1);
                    savedUri = getContext().getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
                    if (savedUri == null) throw new IllegalStateException("O Android não criou o registro do vídeo.");
                    try (InputStream in = new FileInputStream(input);
                         OutputStream out = getContext().getContentResolver().openOutputStream(savedUri, "w")) {
                        if (out == null) throw new IllegalStateException("Não foi possível abrir o destino da galeria.");
                        copy(in, out);
                    }
                    ContentValues ready = new ContentValues();
                    ready.put(MediaStore.Video.Media.IS_PENDING, 0);
                    getContext().getContentResolver().update(savedUri, ready, null, null);
                } else {
                    File folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "W QUALITY");
                    if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Não foi possível criar Movies/W QUALITY.");
                    legacyFile = new File(folder, safeName);
                    try (InputStream in = new FileInputStream(input); OutputStream out = new FileOutputStream(legacyFile)) {
                        copy(in, out);
                    }
                    MediaScannerConnection.scanFile(getContext(), new String[]{legacyFile.getAbsolutePath()}, new String[]{"video/webm"}, null);
                }
                JSObject result = new JSObject();
                result.put("saved", true);
                result.put("uri", savedUri == null ? Uri.fromFile(legacyFile).toString() : savedUri.toString());
                result.put("fileName", safeName);
                call.resolve(result);
            } catch (Exception e) {
                if (savedUri != null) getContext().getContentResolver().delete(savedUri, null, null);
                call.reject("Não foi possível salvar o vídeo em Movies/W QUALITY: " + e.getMessage());
            } finally {
                exports.remove(id);
                if (input.exists()) input.delete();
            }
        });
    }

    @PluginMethod
    public void cancelExport(PluginCall call) {
        String id = call.getString("exportId");
        File file = id == null ? null : exports.remove(id);
        if (file != null && file.exists()) file.delete();
        call.resolve();
    }

    @PluginMethod
    public void startExportNotification(PluginCall call) {
        ensureNotificationChannel();
        if (Build.VERSION.SDK_INT >= 33 && getPermissionState("notifications") != PermissionState.GRANTED) {
            requestPermissionForAlias("notifications", call, "notificationPermissionCallback");
            return;
        }
        postProgressNotification(0);
        resolveNotificationCall(call, true);
    }

    @PermissionCallback
    private void notificationPermissionCallback(PluginCall call) {
        boolean allowed = Build.VERSION.SDK_INT < 33 || getPermissionState("notifications") == PermissionState.GRANTED;
        if (allowed) postProgressNotification(0);
        resolveNotificationCall(call, allowed);
    }

    @PluginMethod
    public void updateExportNotification(PluginCall call) {
        int progress = call.getInt("progress", 0);
        postProgressNotification(Math.max(0, Math.min(100, progress)));
        call.resolve();
    }

    @PluginMethod
    public void completeExportNotification(PluginCall call) {
        postFinalNotification("Exportação concluída", "Vídeo salvo em Filmes/W QUALITY", false);
        call.resolve();
    }

    @PluginMethod
    public void failExportNotification(PluginCall call) {
        String reason = call.getString("message", "Confira o aviso no W QUALITY.");
        postFinalNotification("Exportação não concluída", reason, true);
        call.resolve();
    }

    private void resolveNotificationCall(PluginCall call, boolean shown) {
        JSObject result = new JSObject();
        result.put("shown", shown);
        call.resolve(result);
    }

    private void ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager manager = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null && manager.getNotificationChannel(CHANNEL_ID) == null) {
                NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Exportação de vídeo", NotificationManager.IMPORTANCE_LOW);
                channel.setDescription("Progresso da exportação de vídeos do W QUALITY");
                manager.createNotificationChannel(channel);
            }
        }
    }

    private Notification.Builder notificationBuilder(String title, String text) {
        Context context = getContext();
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(context, CHANNEL_ID)
            : new Notification.Builder(context);
        return builder.setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle(title)
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_PROGRESS)
            .setPriority(Notification.PRIORITY_LOW);
    }

    private void postProgressNotification(int progress) {
        try {
            if (Build.VERSION.SDK_INT >= 33 && getPermissionState("notifications") != PermissionState.GRANTED) return;
            ensureNotificationChannel();
            Notification notification = notificationBuilder("Exportando vídeo", "W QUALITY · " + progress + "%")
                .setProgress(100, progress, false).build();
            NotificationManager manager = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) manager.notify(NOTIFICATION_ID, notification);
        } catch (Exception e) {
            android.util.Log.w("WQualityExport", "Não foi possível atualizar a notificação", e);
        }
    }

    private void postFinalNotification(String title, String text, boolean failed) {
        try {
            if (Build.VERSION.SDK_INT >= 33 && getPermissionState("notifications") != PermissionState.GRANTED) return;
            ensureNotificationChannel();
            Notification notification = notificationBuilder(title, text)
                .setOngoing(false).setAutoCancel(true).setCategory(failed ? Notification.CATEGORY_ERROR : Notification.CATEGORY_STATUS)
                .setProgress(0, 0, false).build();
            NotificationManager manager = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) manager.notify(NOTIFICATION_ID, notification);
        } catch (Exception e) {
            android.util.Log.w("WQualityExport", "Não foi possível mostrar o resultado da exportação", e);
        }
    }

    private static void copy(InputStream input, OutputStream output) throws Exception {
        byte[] buffer = new byte[64 * 1024];
        int count;
        while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
        output.flush();
    }
}
