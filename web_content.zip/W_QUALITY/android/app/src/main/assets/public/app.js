(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const input = $('videoInput'), video = $('video'), empty = $('emptyState');
  const canvas = $('renderCanvas'), ctx = canvas.getContext('2d', { alpha: false });
  const message = $('exportMessage'), button = $('exportButton');
  let sourceUrl = null, outputUrl = null, outputFile = null, exporting = false, nativeExportPlugin = null;
  const filters = { none: '', vivid: 'saturate(1.3) contrast(1.06)', mono: 'grayscale(1)', warm: 'sepia(.18) saturate(1.12)', cool: 'hue-rotate(10deg) saturate(.92)' };
  const MAX_ANDROID_CLIP_SECONDS = 300, MAX_BROWSER_CLIP_SECONDS = 120;
  const num = (id) => Number($(id).value);
  const duration = () => Number.isFinite(video.duration) ? video.duration : 0;
  const clamp = (n, a, b) => Math.min(b, Math.max(a, n));
  const setMessage = (text) => { message.textContent = text; };

  function getNativeExportPlugin() {
    try {
      const cap = window.Capacitor;
      if (cap && cap.getPlatform && cap.getPlatform() === 'android' && cap.registerPlugin) {
        if (nativeExportPlugin) return nativeExportPlugin;
        if (typeof cap.nativePromise !== 'function') throw new Error('A ponte de Promises nativas do Capacitor não foi injetada.');
        const callNative = (method) => (options = {}) => cap.nativePromise('WQualityExport', method, options);
        nativeExportPlugin = cap.registerPlugin('WQualityExport', { android: {
          beginExport: callNative('beginExport'), appendChunk: callNative('appendChunk'),
          finishExport: callNative('finishExport'), cancelExport: callNative('cancelExport'),
          startExportNotification: callNative('startExportNotification'), updateExportNotification: callNative('updateExportNotification'),
          completeExportNotification: callNative('completeExportNotification'), failExportNotification: callNative('failExportNotification')
        } });
        return nativeExportPlugin;
      }
    } catch (error) { console.warn('Plugin nativo W QUALITY indisponível:', error); }
    return null;
  }
  function composedFilter() {
    return `brightness(${num('brightness')}%) contrast(${num('contrast')}%) saturate(${num('saturation')}%) ${filters[$('filterSelect').value] || ''}`.trim();
  }
  function updatePreview() { video.style.filter = composedFilter(); }
  function setTrim(which, value) {
    const d = duration(); if (!d) return;
    let s = clamp(Number(value) || 0, 0, d);
    if (which === 'start') { s = Math.min(s, num('trimEnd') - 0.1); $('trimStart').value = s.toFixed(1); $('startRange').value = String(s / d * 100); }
    else { s = Math.max(s, num('trimStart') + 0.1); $('trimEnd').value = s.toFixed(1); $('endRange').value = String(s / d * 100); }
  }
  input.addEventListener('change', () => {
    const file = input.files && input.files[0]; if (!file) return;
    if (!file.type.startsWith('video/')) { setMessage('Esse arquivo não parece ser um vídeo compatível.'); return; }
    if (sourceUrl) URL.revokeObjectURL(sourceUrl);
    if (outputUrl) { URL.revokeObjectURL(outputUrl); outputUrl = null; }
    outputFile = null; $('downloadLink').hidden = true; $('shareVideoButton').hidden = true;
    sourceUrl = URL.createObjectURL(file); video.src = sourceUrl; video.hidden = false; empty.hidden = true;
    $('fileInfo').hidden = false; $('fileInfo').textContent = `${file.name} · ${formatBytes(file.size)}`;
    video.onloadedmetadata = () => {
      const d = duration(); $('trimStart').value = '0.0'; $('trimEnd').value = d.toFixed(1);
      $('trimStart').max = d; $('trimEnd').max = d; $('startRange').value = 0; $('endRange').value = 100;
      $('exportButton').disabled = false;
      setMessage(`Vídeo pronto · ${formatTime(d)} · ${video.videoWidth} × ${video.videoHeight}.`); updatePreview();
    };
    video.onerror = () => { $('exportButton').disabled = true; setMessage('Não foi possível decodificar este vídeo neste aparelho. Tente outro arquivo.'); };
  });
  function formatTime(s) { const m = Math.floor(s / 60), sec = Math.floor(s % 60); return `${m}:${String(sec).padStart(2,'0')}`; }
  function formatBytes(n) { if (n < 1048576) return `${Math.round(n/1024)} KB`; return `${(n/1048576).toFixed(1)} MB`; }
  function blobToBase64(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = String(reader.result || '');
        const payloadStart = dataUrl.lastIndexOf(',');
        resolve(payloadStart >= 0 ? dataUrl.slice(payloadStart + 1) : '');
      };
      reader.onerror = () => reject(new Error('Não foi possível ler um bloco do vídeo exportado.'));
      reader.readAsDataURL(blob);
    });
  }
  ['brightness','contrast','saturation'].forEach(id => $(id).addEventListener('input', () => {
    $(`${id}Out`).value = `${num(id)}%`; $(`${id}Out`).textContent = `${num(id)}%`; updatePreview();
  }));
  $('filterSelect').addEventListener('change', updatePreview);
  $('trimStart').addEventListener('change', () => setTrim('start', num('trimStart')));
  $('trimEnd').addEventListener('change', () => setTrim('end', num('trimEnd')));
  $('startRange').addEventListener('input', () => setTrim('start', num('startRange') / 100 * duration()));
  $('endRange').addEventListener('input', () => setTrim('end', num('endRange') / 100 * duration()));

  function seek(time) {
    return new Promise((resolve, reject) => {
      if (Math.abs(video.currentTime - time) < 0.04) { resolve(); return; }
      const done = () => { cleanup(); resolve(); }, fail = () => { cleanup(); reject(new Error('Não foi possível posicionar o vídeo.')); };
      const cleanup = () => { video.removeEventListener('seeked', done); video.removeEventListener('error', fail); };
      video.addEventListener('seeked', done, { once: true }); video.addEventListener('error', fail, { once: true });
      video.currentTime = time;
    });
  }
  function canvasFrame() {
    if (!video.videoWidth || !video.videoHeight) return;
    ctx.filter = composedFilter(); ctx.drawImage(video, 0, 0, canvas.width, canvas.height); ctx.filter = 'none';
  }
  function makeFileName() { return `W-QUALITY-${new Date().toISOString().replace(/[:.]/g,'-')}.webm`; }

  $('shareVideoButton').addEventListener('click', async () => {
    if (!outputFile || !navigator.share) { setMessage('Compartilhamento de arquivos não é suportado neste WebView. Tente “Baixar vídeo editado”.'); return; }
    try {
      if (navigator.canShare && !navigator.canShare({ files: [outputFile] })) throw new Error('Este Android não aceita compartilhar esse arquivo.');
      await navigator.share({ files: [outputFile], title: 'W QUALITY', text: 'Vídeo exportado pelo W QUALITY.' });
      setMessage('Compartilhamento aberto. Escolha um app para receber ou salvar o vídeo.');
    } catch (error) {
      if (error.name !== 'AbortError') setMessage(`${error.message || 'Não foi possível compartilhar.'} Tente “Baixar vídeo editado”.`);
    }
  });

  async function exportVideo() {
    if (exporting) return;
    const androidApp = !!(window.Capacitor && window.Capacitor.getPlatform && window.Capacitor.getPlatform() === 'android');
    let nativeWriter = getNativeExportPlugin();
    const showPreparationError = (text) => {
      $('progressWrap').hidden = false; $('exportProgress').value = 0; $('progressPct').textContent = '0%';
      $('progressLabel').textContent = 'Exportação não iniciada'; setMessage(text);
      $('progressWrap').scrollIntoView({ behavior: 'smooth', block: 'center' });
    };
    if (!window.MediaRecorder || !canvas.captureStream) { showPreparationError('Este WebView não oferece gravação de vídeo. Atualize o Android System WebView/Chrome e tente novamente.'); return; }
    const start = num('trimStart'), end = num('trimEnd'), clipLength = end - start;
    if (!(clipLength > 0.15) || end > duration() + 0.1) { showPreparationError('Confira o intervalo: o fim precisa ser maior que o início.'); return; }
    const maxClipSeconds = androidApp && nativeWriter ? MAX_ANDROID_CLIP_SECONDS : MAX_BROWSER_CLIP_SECONDS;
    if (clipLength > maxClipSeconds) { showPreparationError(`Este modo permite até ${Math.floor(maxClipSeconds / 60)} minutos por exportação. Reduza o intervalo de corte e tente novamente.`); return; }
    const maxHeight = Number($('resolution').value), scale = Math.min(1, maxHeight / video.videoHeight);
    canvas.width = Math.max(2, Math.round(video.videoWidth * scale / 2) * 2);
    canvas.height = Math.max(2, Math.round(video.videoHeight * scale / 2) * 2);
    if (canvas.width * canvas.height > 2073600) { showPreparationError('A resolução ultrapassa o limite seguro. Selecione 720p.'); return; }
    if (typeof MediaRecorder.isTypeSupported !== 'function') { showPreparationError('Este WebView não informa codecs de gravação compatíveis; atualize o Android System WebView e tente novamente.'); return; }
    const mime = ['video/webm;codecs=vp8,opus','video/webm;codecs=vp9,opus','video/webm'].find(t => MediaRecorder.isTypeSupported(t));
    if (!mime) { showPreparationError('O aparelho não oferece gravação WebM. Nenhum arquivo foi criado.'); return; }

    exporting = true; button.disabled = true; video.controls = false;
    $('progressWrap').hidden = false; $('downloadLink').hidden = true; $('shareVideoButton').hidden = true; outputFile = null;
    $('exportProgress').value = 0; $('progressPct').textContent = '0%'; $('progressLabel').textContent = 'Preparando vídeo…';
    setMessage(androidApp && !nativeWriter
      ? 'Plugin Android indisponível: usando gravação Web. Limite de 2 min; o resultado não é salvo diretamente na Galeria.'
      : 'Processando em tempo real. Mantenha esta tela aberta.');
    let recorder, stream, raf = 0, timer = 0, ended = false, chunks = [];
    let exportId = null, nativeQueue = Promise.resolve(), lastNoticeProgress = -5;
    const fileName = makeFileName();
    try {
      if (nativeWriter) { try { await nativeWriter.startExportNotification({ fileName }); } catch (error) { console.warn('Notificação indisponível:', error); } }
      await video.pause(); await seek(start);
      if (nativeWriter) {
        try {
          const session = await nativeWriter.beginExport({ fileName });
          exportId = session && session.exportId;
          if (!exportId) throw new Error('O Android não abriu um destino para o arquivo.');
        } catch (error) {
          if (clipLength > MAX_BROWSER_CLIP_SECONDS) throw new Error(`O plugin Android não respondeu e o fallback Web suporta até 2 minutos. Reduza o corte para 2 min ou menos. Detalhe nativo: ${error.message || 'indisponível'}`);
          nativeWriter = null; exportId = null;
          $('progressLabel').textContent = 'Fallback de gravação Web…';
          setMessage('O plugin Android não respondeu. Continuando pela API Web; o arquivo será WebM e não será gravado diretamente na Galeria.');
        }
      }
      canvasFrame();
      try { stream = canvas.captureStream(24); }
      catch (error) { throw new Error(`O Android não iniciou a captura de imagem: ${error.message || 'API indisponível'}`); }
      // Captura de áudio é opcional: alguns WebViews não expõem video.captureStream().
      try {
        if (typeof video.captureStream === 'function') {
          const audioStream = video.captureStream();
          audioStream.getAudioTracks().forEach(track => stream.addTrack(track));
        }
      } catch (error) { console.warn('Exportação continuará sem áudio:', error); }

      recorder = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: maxHeight === 1080 ? 5000000 : 2500000 });
      recorder.ondataavailable = event => {
        if (!event.data || !event.data.size) return;
        if (nativeWriter && exportId) {
          const id = exportId;
          nativeQueue = nativeQueue.then(async () => {
            const base64 = await blobToBase64(event.data);
            await nativeWriter.appendChunk({ exportId: id, base64 });
          });
        } else chunks.push(event.data);
      };
      const result = new Promise((resolve, reject) => {
        recorder.onerror = event => reject(new Error(event.error && event.error.message || 'erro do gravador de vídeo'));
        recorder.onstop = () => resolve();
      });
      recorder.start(1000);
      const draw = () => { if (!exporting) return; canvasFrame(); raf = requestAnimationFrame(draw); };
      raf = requestAnimationFrame(draw);
      video.currentTime = start;
      await video.play();
      $('progressLabel').textContent = 'Exportando vídeo…';
      timer = window.setInterval(() => {
        const elapsed = clamp(video.currentTime - start, 0, clipLength);
        const pct = Math.floor(elapsed / clipLength * 100);
        $('exportProgress').value = pct; $('progressPct').textContent = `${pct}%`;
        if (nativeWriter && pct >= lastNoticeProgress + 5) {
          lastNoticeProgress = pct;
          nativeWriter.updateExportNotification({ progress: pct }).catch(error => console.warn('Notificação indisponível:', error));
        }
        if (video.currentTime >= end || video.ended) {
          if (ended) return; ended = true; clearInterval(timer); cancelAnimationFrame(raf);
          video.pause(); if (recorder.state !== 'inactive') recorder.stop();
        }
      }, 150);
      await result;
      if (nativeWriter && exportId) {
        await nativeQueue;
        const saved = await nativeWriter.finishExport({ exportId, fileName });
        if (!saved || saved.saved !== true) throw new Error('O Android não confirmou o salvamento na galeria.');
        $('exportProgress').value = 100; $('progressPct').textContent = '100%'; $('progressLabel').textContent = 'Salvo em Movies/W QUALITY';
        await nativeWriter.completeExportNotification({});
        setMessage(`Concluído: ${saved.fileName || fileName} foi salvo em Filmes/W QUALITY. Verifique o vídeo na galeria do aparelho.`);
      } else {
        const blob = new Blob(chunks, { type: mime });
        if (!blob.size) throw new Error('A gravação ficou vazia. Tente outro vídeo curto.');
        outputUrl = URL.createObjectURL(blob);
        const link = $('downloadLink'); link.href = outputUrl; link.download = fileName; link.hidden = false;
        outputFile = null;
        try { if (typeof File === 'function') outputFile = new File([blob], fileName, { type: mime }); } catch (_) {}
        const shareButton = $('shareVideoButton');
        try { shareButton.hidden = !(outputFile && navigator.share && (!navigator.canShare || navigator.canShare({ files: [outputFile] }))); }
        catch (_) { shareButton.hidden = true; }
        $('exportProgress').value = 100; $('progressPct').textContent = '100%'; $('progressLabel').textContent = 'Exportação Web concluída';
        setMessage(`Pronto: WebM (${formatBytes(blob.size)}). Use “Compartilhar / salvar” se disponível ou “Baixar vídeo editado”. O modo Web não grava diretamente na Galeria.`);
      }
    } catch (error) {
      if (recorder && recorder.state !== 'inactive') recorder.stop();
      if (nativeWriter && exportId) { try { await nativeWriter.cancelExport({ exportId }); } catch (_) {} }
      if (nativeWriter) { try { await nativeWriter.failExportNotification({ message: error.message || 'Confira o aviso no W QUALITY.' }); } catch (_) {} }
      setMessage(`Exportação interrompida: ${error.message || 'erro inesperado'}`);
    } finally {
      clearInterval(timer); cancelAnimationFrame(raf);
      if (stream) stream.getTracks().forEach(track => track.stop());
      exporting = false; video.controls = true; button.disabled = false;
      if (video.paused && Number.isFinite(start)) { try { await seek(start); } catch (_) {} }
    }
  }
  button.addEventListener('click', exportVideo);
  window.addEventListener('beforeunload', () => { if (sourceUrl) URL.revokeObjectURL(sourceUrl); if (outputUrl) URL.revokeObjectURL(outputUrl); });
})();
