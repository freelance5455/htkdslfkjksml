# W QUALITY — editor local (v0.2.6)

Projeto Android empacotável baseado no protótipo web enviado. A logo W fornecida foi incorporada à interface, ao ícone adaptativo Android e às telas de abertura. A interface foi preservada e ampliada; a edição ocorre localmente no WebView/Capacitor e não envia vídeos a servidor.

## Estado do projeto

**Implementado no código:** importar um vídeo pelo seletor do aparelho; pré-visualizar; definir início e fim do trecho; ajustar brilho, contraste e saturação; aplicar filtros Original, Violeta vivo, Preto e branco, Quente e Frio; exportar em tempo real por `MediaRecorder`/`canvas.captureStream()` para WebM; progresso na tela e, no modo nativo com permissão, notificação; transmissão em blocos ao plugin nativo e gravação em `Movies/W QUALITY` via MediaStore. Quando o plugin nativo não inicia, o APK agora tenta o fallback Web: até 2 minutos, grava em memória como Blob e oferece compartilhamento/baixar. Esse fallback **não promete salvar diretamente na Galeria**. O modo nativo aceita até 5 minutos. A saída 720p ou 1080p não amplia a origem.

**Ainda não implementado:** MP4/H.264; nitidez e redução de ruído; IA de super-resolução/recuperação de detalhes. APK debug v1.7 foi compilado e assinado. O plugin nativo e o fallback Web foram compilados; não foi possível validar o funcionamento em dispositivo Android físico. A exportação exige manter o app em primeiro plano. Gravação WebM e áudio em `captureStream()` dependem da versão do Android/WebView; áudio é opcional.

> Os ajustes/filtros são transformações convencionais, não IA. Eles são aplicados aos pixels exportados. O áudio original é incluído quando o WebView Android oferece `captureStream()` para o vídeo.

## Projeto Android incluído

O ZIP contém `android/`, com wrapper Gradle e assets sincronizados, e `vendor/capacitor-android/capacitor/`, a biblioteca nativa Capacitor necessária para o Gradle. **Para compilar os arquivos exatamente como incluídos, não é necessário instalar Node/npm no celular.** A primeira compilação precisa baixar dependências Maven/Gradle pela internet.

Requisitos de compilação: ambiente IDE Android que aceite Gradle **8.11.1** e Capacitor 7, JDK **21** (a biblioteca Capacitor empacotada usa compatibilidade Java 21) e Android SDK **API 35**. Aplicativo configura minSdk 23 e targetSdk 35.

## Gerar APK usando somente o celular Android

1. Baixe e extraia o ZIP no aparelho.
2. Instale uma IDE Android com suporte a Gradle/JDK 21 (por exemplo, AndroidIDE, se a versão disponível aceitar Gradle 8.11.1 e JDK 21) e instale os componentes Android SDK/API 35 solicitados. As capacidades variam por versão da IDE.
3. Abra/importa a pasta **`W_QUALITY/android`** — não apenas a pasta externa do projeto — e aguarde a sincronização do Gradle. É necessária conexão para baixar o Gradle e dependências Android na primeira compilação.
4. Selecione a tarefa/menu de geração **APK debug**. O wrapper está em `android/gradlew`; o caminho usual da saída é `android/app/build/outputs/apk/debug/app-debug.apk`.
5. Toque no APK no celular e autorize instalação para essa fonte quando solicitado pelo Android.
6. Para distribuir a outras pessoas, gere **APK release assinado** no fluxo de assinatura da IDE. Crie uma keystore e mantenha a chave/senhas em local seguro. Perder a chave pode impedir atualizações do mesmo app. Não coloque keystore no ZIP.

Nem toda versão de AndroidIDE ou IDE no celular aceita JDK 21 e Gradle 8.11.1. Se a sincronização falhar por essa incompatibilidade, será necessário usar Android Studio/ambiente compatível em computador. **O ZIP-fonte contém o projeto Gradle e não inclui APK nem keystore.**

## Alterar e sincronizar o código web

Para recompilar a interface depois de editar HTML/CSS/JS, instale Node.js 20+ e npm. Na pasta `W_QUALITY` execute:

```sh
npm install
npm run android:sync
```

O `android:sync` inclui um passo que restaura o plugin customizado em `capacitor.plugins.json` e a referência vendorizada do Capacitor. Não execute `npx cap add android` porque a pasta nativa já existe no ZIP.

## Verificação e teste manual

Verificações realizadas neste sandbox: testes estáticos JavaScript, compilação Gradle do plugin e do APK, `zipalign` e validação criptográfica da assinatura debug. **A exportação foi compilada, mas não foi possível executá-la num Android físico; teste com um clipe curto no aparelho.**

No celular, teste primeiro um trecho curto em 720p. O modo nativo permite clipes de até cinco minutos e deve salvar em `Filmes/W QUALITY`. Se o plugin falhar antes da gravação, o fallback Web aceita até dois minutos e produz WebM em memória; use o botão de compartilhar se aparecer ou o link de download. Dependendo do WebView, o arquivo pode não ser salvo diretamente na Galeria. O fallback aumenta o uso de memória: feche outros apps e mantenha a tela ativa. Em Android 13+, a notificação depende da autorização do sistema; o progresso também aparece no editor.

Para repetir as verificações JavaScript num ambiente com Node: `npm test`.

## Estrutura

- `index.html`, `style.css`, `app.js`: interface e motor de prévia/exportação.
- `assets/w-quality-mark.png`: monograma extraído da logo fornecida, sem fundo, para a interface.
- `www/`: assets web já sincronizados para o app.
- `android/`: projeto Android Gradle, wrapper, ícones e plugin nativo de exportação/salvamento.
- `vendor/capacitor-android/`: biblioteca Android Capacitor vendorizada e licença.
- `capacitor.config.json`, `package.json`, `package-lock.json`: configuração JS/Capacitor.
- `docs/IA-E-MODELOS.md`: avaliação de modelos e caminhos para uma futura integração real.
- `scripts/`: checagem básica e cópia dos assets web.
