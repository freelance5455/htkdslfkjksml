# W QUALITY — projeto inicial

Este ZIP contém um protótipo web inicial do W QUALITY, feito para abrir no navegador Android e servir como base para o aplicativo.

## O que funciona neste protótipo
- Interface em português brasileiro
- Seleção de vídeo pelo aparelho
- Pré-visualização do vídeo
- Ajustes de brilho, contraste, saturação e nitidez visual (nitidez simulada via CSS)
- Seleção de resolução de saída como configuração de interface

## Limitações importantes
Este é um protótipo web, não um APK Android pronto. Ele ainda não exporta/processa um novo arquivo de vídeo, não implementa IA real e não gera Full HD por si só. Os controles visuais não substituem um motor de edição de vídeo ou um modelo de IA. Para essas funções, será necessário integrar uma biblioteca de processamento de vídeo e, para IA, um modelo/serviço real.

## Como testar no Android
1. Extraia o ZIP em um gerenciador de arquivos.
2. Abra `index.html` no navegador, se o seu aparelho permitir arquivos locais.
3. Toque em **Importar vídeo** e escolha um vídeo da galeria.
4. Experimente os controles de imagem.

Para transformar isso em um app instalável, será necessário empacotar o projeto com uma ferramenta compatível (por exemplo, Android Studio/Capacitor em um ambiente adequado) e implementar o processamento/exportação.
