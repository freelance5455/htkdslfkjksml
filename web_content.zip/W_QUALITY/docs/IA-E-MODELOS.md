# IA de restauração de vídeo: avaliação para W QUALITY

## Situação implementada

**Não há IA neste aplicativo.** Esta entrega não baixa modelos, não chama API e não inventa recuperação de detalhes. Os filtros e ajustes disponíveis são operações convencionais executadas em cada quadro renderizado. O app atual não faz denoising nem super-resolução.

## Modelos candidatos

### Real-ESRGAN

A licença do repositório oficial é BSD-3-Clause. O projeto oferece scripts de inferência de imagem e um script para vídeo, com pesos pré-treinados. A rota Python oficial depende de PyTorch e bibliotecas de visão computacional; isso é grande para incluir num APK e não é apropriado como dependência de aparelho modesto. O projeto também publica executáveis ncnn-Vulkan para Windows, Linux e macOS: eles não são binários Android ARM. Portanto, sua menção não significa que já exista uma integração Android pronta neste ZIP. Um caminho local plausível seria adaptar/converter modelos compatíveis e compilar uma implementação ncnn para Android, validando Vulkan/driver e memória em aparelhos-alvo.

Limites: Real-ESRGAN clássico é sobretudo restauração de imagem; processar cada quadro isoladamente pode gerar cintilação/inconsistência temporal. Modelos específicos de vídeo/anime não são substitutos universais para filmagens reais. Super-resolução generativa pode sintetizar texturas convincentes que não correspondem ao detalhe verdadeiro da cena.

### BasicVSR++

O repositório oficial (Apache-2.0) apresenta super-resolução temporal e disponibiliza pesos para deblurring/denoising; pesos de super-resolução são direcionados ao ecossistema MMEditing. A demonstração recebe um vídeo e checkpoint através de Python. Instalação envolve PyTorch, OpenMIM e `mmcv-full`. Isso caracteriza um candidato de referência para servidor GPU/estação de trabalho ou pesquisa de conversão; não um modelo pronto para executar dentro de um APK pequeno em celulares com pouca RAM.

### VRT / RVRT

O repositório oficial do VRT cobre super-resolução, desfoque e denoising temporal e oferece checkpoints. O README indica Python 3.8, PyTorch >=1.9.1 e plataforma Ubuntu 18.04/CUDA 11.1; o código VRT é majoritariamente CC-BY-NC, que restringe usos comerciais. O próprio projeto aponta RVRT como alternativa com compromisso mais equilibrado de tamanho de modelo, memória de teste e tempo. São referências para pesquisa/servidor, não integração mobile pronta.

## Requisitos e custo prático

- **No aparelho:** grátis por uso e pode manter os arquivos locais, mas requer modelos compactados e quantizados (p.ex. ONNX/TFLite ou ncnn, caso a arquitetura e licença permitam conversão), runtime ARM, pré/pós-processamento, testes de compatibilidade de GPU/NPU e gerenciamento em blocos/quadro. Os pesos e buffers ocupam armazenamento persistente e RAM; vídeo de alta resolução multiplica o custo pelo número de pixels, e modelos temporais precisam de vários quadros simultâneos. Não há um número confiável de GB ou velocidade universal sem escolher checkpoint, runtime e aparelhos-alvo; anúncios de “IA local” em celular modesto sem esses dados seriam enganosos. Em aparelhos limitados, uma implementação deverá usar tiling/quadro menor, processamento lento e fallback sem IA.
- **Servidor próprio:** mantém o modelo fora do APK e é possível usar checkpoints open-source, mas requer GPU, armazenamento, manutenção, fila de jobs, upload do vídeo, política de privacidade e transferência de arquivos. Não é gratuito em escala.
- **API de terceiro:** integração seria mais simples, mas pode cobrar por segundo/minuto, impor limites e exigir envio do vídeo a esse fornecedor. Nenhuma API paga está configurada nem é chamada nesta versão.
- **Licenciamento:** além da licença do código, revisar individualmente pesos, dados de treinamento e restrições comerciais antes de distribuir um modelo no app.

## Recomendações de engenharia

1. Protótipo futuro: testar Real-ESRGAN/ncnn com **clipes curtos**, quadros reduzidos e comparação quadro a quadro em aparelhos Android ARM reais. Acompanhar RSS/memória, temperatura, bateria, throughput e estabilidade temporal.
2. Para vídeo natural e melhoria consistente entre quadros, avaliar primeiro um modelo de vídeo restaurador e o custo de convertê-lo para runtime móvel. BasicVSR++ ou RVRT/VRT servem de base para experimentos, não de promessa de APK imediato.
3. Oferecer explicitamente três modos: sem IA (offline e leve); IA local opcional com download de modelo e aviso de requisitos; ou serviço remoto opt-in com preço e privacidade revelados antes do envio.
4. Não treinar nem incluir pesos no APK inicial. O APK deste ZIP não possui modelos de IA e não faz chamadas a serviço externo.

## Fontes primárias

- BasicVSR++: https://github.com/ckkelvinchan/BasicVSR_PlusPlus (licença, requisitos, checkpoints e inferência de vídeo).
- Real-ESRGAN: https://github.com/xinntao/Real-ESRGAN (BSD-3-Clause; scripts e variantes de inferência; dependências Python/PyTorch e opções ncnn para desktop).
- VRT: https://github.com/JingyunLiang/VRT (tarefas, requisitos declarados, comandos com tiling, checkpoints e CC-BY-NC).
- RVRT: https://github.com/JingyunLiang/RVRT (trabalho relacionado e compromisso entre tamanho/memória/tempo descrito pelo projeto VRT).
