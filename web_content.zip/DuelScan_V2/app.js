/* DuelScan V2: browser prototype. Official full rules and card coverage are not claimed. */
const $=id=>document.getElementById(id);
const API="https://db.ygoprodeck.com/api/v7/cardinfo.php";
const demoCards=[
 {id:89631139,name:"Blue-Eyes White Dragon",type:"Normal Monster",desc:"This legendary dragon is a powerful engine of destruction.",atk:3000,def:2500,level:8,race:"Dragon",attribute:"LIGHT",icon:"🐉"},
 {id:46986414,name:"Dark Magician",type:"Normal Monster",desc:"The ultimate wizard in terms of attack and defense.",atk:2500,def:2100,level:7,race:"Spellcaster",attribute:"DARK",icon:"🪄"},
 {id:10000000,name:"Obelisk the Tormentor",type:"Effect Monster",desc:"Requires 3 Tributes to Normal Summon.",atk:4000,def:4000,level:10,race:"Divine-Beast",attribute:"DIVINE",icon:"⚡"},
 {id:74677422,name:"Red-Eyes Black Dragon",type:"Normal Monster",desc:"A ferocious dragon with a deadly attack.",atk:2400,def:2000,level:7,race:"Dragon",attribute:"DARK",icon:"🔥"},
 {id:03268032,name:"Sage with Eyes of Blue",type:"Tuner Effect Monster",desc:"Blue-Eyes support monster.",atk:0,def:1500,level:1,race:"Spellcaster",attribute:"LIGHT",icon:"🔹"},
 {id:66961194,name:"Dictator of D.",type:"Effect Monster",desc:"Blue-Eyes support monster.",atk:1200,def:1100,level:4,race:"Spellcaster",attribute:"DARK",icon:"👑"},
 {id:83764718,name:"Monster Reborn",type:"Spell Card",desc:"Target 1 monster in either GY; Special Summon it.",icon:"♻️"},
 {id:24094653,name:"Polymerization",type:"Spell Card",desc:"Fusion Summon a Fusion Monster from your Extra Deck.",icon:"🌀"},
 {id:44095762,name:"Mirror Force",type:"Trap Card",desc:"When an opponent's monster declares an attack, demo entry.",icon:"🛡️"},
 {id:05318639,name:"Mystical Space Typhoon",type:"Spell Card",desc:"Target 1 Spell/Trap on the field; destroy it.",icon:"🌪️"},
 {id:89631139+1,name:"Blue-Eyes Alternative White Dragon",type:"Effect Monster",desc:"Demo entry; full effect not implemented.",atk:3000,def:2500,level:8,race:"Dragon",attribute:"LIGHT",icon:"🐲"},
 {id:23995346,name:"The White Stone of Ancients",type:"Tuner Effect Monster",desc:"Blue-Eyes support monster; demo effect only.",atk:600,def:500,level:1,race:"Dragon",attribute:"LIGHT",icon:"💠"}
];
let library=[...demoCards], activeDeck=new Map(), savedDecks={}, selectedHandIndex=-1;
let playerLP=8000,enemyLP=8000,started=false,turn="player",phase="Main Phase 1",playerField=[],enemyField=[],hand=[],playerDeck=[],enemyDeck=[],cameraStream=null,apiOffset=0,searchTimer=null;
function toast(s){const t=$("toast");t.textContent=s;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function log(s){const el=document.createElement("div");el.className="log-line";el.textContent=`${new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})} · ${s}`;$("duelLog").prepend(el)}
function isMonster(c){return /monster/i.test(c.type)&&!/(spell|trap)/i.test(c.type)}
function isSpell(c){return /spell/i.test(c.type)}
function isTrap(c){return /trap/i.test(c.type)}
function totalDeck(){return [...activeDeck.values()].reduce((a,b)=>a+b,0)}
function cardByName(name){return library.find(c=>c.name.toLowerCase()===name.toLowerCase())}
function safeText(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function cardTile(c){
 const el=document.createElement("article");el.className="card-tile";
 const art=document.createElement("div");art.className="card-art";
 if(c.image){const img=document.createElement("img");img.src=c.image;img.alt="";img.loading="lazy";img.onerror=()=>{art.textContent=c.icon||"🃏"};art.append(img)}else art.textContent=c.icon||"🃏";
 const name=document.createElement("div");name.className="card-name";name.textContent=c.name;
 const meta=document.createElement("div");meta.className="card-meta";meta.textContent=c.type;
 const stats=document.createElement("div");stats.className="card-stats";stats.textContent=isMonster(c)?`ATK ${c.atk??"?"} / DEF ${c.def??"?"}`:c.race||"Spell / Trap";
 const btn=document.createElement("button");btn.className="secondary";btn.textContent="+ Add to deck";btn.onclick=()=>addToDeck(c.name);
 el.append(art,name,meta,stats,btn);return el
}
function renderLibrary(){
 const q=$("cardSearch").value.trim().toLowerCase(),filter=$("typeFilter").value;
 const found=library.filter(c=>(!q||`${c.name} ${c.type} ${c.desc||""} ${c.race||""}`.toLowerCase().includes(q))&&(filter==="all"||(filter==="monster"&&isMonster(c))||(filter==="spell"&&isSpell(c))||(filter==="trap"&&isTrap(c))));
 $("libraryCount").textContent=`${found.length} shown · ${library.length} loaded`;
 const grid=$("cardGrid");grid.innerHTML="";found.slice(0,80).forEach(c=>grid.append(cardTile(c)));
 $("loadMoreBtn").hidden=found.length<=80;
}
function renderDeck(){
 const total=totalDeck(),unique=activeDeck.size;$("deckCount").textContent=`${total} cards`;$("mainTotal").textContent=total;$("uniqueTotal").textContent=unique;
 let monsters=0,other=0;for(const [name,n] of activeDeck){const c=cardByName(name);if(c&&isMonster(c))monsters+=n;else other+=n}
 $("monsterTotal").textContent=monsters;$("spellTrapTotal").textContent=other;
 const list=$("deckList");list.innerHTML="";
 if(!unique)list.innerHTML='<div class="empty">Your deck is empty. Add cards from the library, import a list, or scan photos.</div>';
 for(const [name,n] of activeDeck){const row=document.createElement("div");row.className="deck-row";const qty=document.createElement("span");qty.className="qty";qty.textContent=`×${n}`;const nm=document.createElement("span");nm.textContent=name;const minus=document.createElement("button");minus.className="secondary remove";minus.textContent="−";minus.title="Remove one copy";minus.onclick=()=>{if(n<=1)activeDeck.delete(name);else activeDeck.set(name,n-1);renderDeck()};row.append(qty,nm,minus);list.append(row)}
 const warnings=[];if(total<40)warnings.push(`Main deck has ${total} cards; common constructed formats usually require at least 40.`);if(total>60)warnings.push("Main deck exceeds the usual 60-card constructed maximum.");for(const [n,q] of activeDeck)if(q>3)warnings.push(`${n}: ${q} copies (many formats limit a card to 3; check the current banlist).`);
 if(!warnings.length&&total)warnings.push("Basic size/copy-count checks passed. This is not an official legality ruling.");$("deckWarnings").innerHTML=warnings.map(w=>`• ${safeText(w)}`).join("<br>")||"Add cards to see deck checks.";
}
function addToDeck(name){activeDeck.set(name,(activeDeck.get(name)||0)+1);renderDeck();$("deckNotice").textContent=`Added ${name}.`;toast("Card added")}
function setView(id){document.querySelectorAll(".view").forEach(v=>v.classList.toggle("active",v.id===id));document.querySelectorAll(".tab").forEach(t=>t.classList.toggle("active",t.dataset.tab===id));if(id==="libraryView")renderLibrary();if(id==="deckView")renderDeck();window.scrollTo({top:0,behavior:"smooth"})}
document.querySelectorAll(".tab").forEach(t=>t.onclick=()=>setView(t.dataset.tab));
$("goScanner").onclick=()=>setView("scannerView");
$("startDuel").onclick=()=>{setView("duelView");startDuel()};
function shuffle(a){for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
function makeDeckFromMap(map){
 const arr=[];for(const [name,n] of map){const c=cardByName(name);if(c)for(let i=0;i<n;i++)arr.push(c)}
 return shuffle(arr)
}
function startDuel(){
 if(totalDeck()<1) {
  // Demo fallback makes the prototype immediately testable.
  playerDeck=shuffle([demoCards[0],demoCards[1],demoCards[3],demoCards[4],demoCards[5],demoCards[6],demoCards[7],demoCards[8],demoCards[9],demoCards[0],demoCards[1],demoCards[3],demoCards[4],demoCards[5],demoCards[6],demoCards[7],demoCards[8],demoCards[9],demoCards[0],demoCards[1]]);
  log("No custom deck found: using a 20-card demo deck. Build/import a deck to use your own card list.");
 }else playerDeck=makeDeckFromMap(activeDeck);
 // System uses its own separate virtual deck; use chosen saved deck as a challenge if selected, otherwise a built-in sample.
 enemyDeck=shuffle([demoCards[0],demoCards[1],demoCards[2],demoCards[3],demoCards[4],demoCards[5],demoCards[6],demoCards[7],demoCards[8],demoCards[9],...demoCards.slice(0,10)]);
 playerLP=enemyLP=8000;playerField=[];enemyField=[];hand=[];started=true;turn="player";phase="Draw Phase";$("duelLog").innerHTML="";for(let i=0;i<5;i++)drawCard(true);
 log("Duel started. You play against the Duel System. Opening hand drawn.");renderDuel();$("phaseLabel").textContent=phase;
}
function drawCard(initial=false){
 if(!started&&!initial){log("Start a duel first.");return}
 if(turn!=="player"&&!initial){log("It is not your turn.");return}
 if(!playerDeck.length){log("Your deck is empty. You cannot draw.");return}
 const c=playerDeck.pop();hand.push(c);if(!initial)log(`You draw a card (${c.name}).`);renderDuel()
}
function renderDuel(){
 $("playerLP").textContent=playerLP;$("enemyLP").textContent=enemyLP;$("playerBar").style.width=Math.max(0,playerLP/8000*100)+"%";$("enemyBar").style.width=Math.max(0,enemyLP/8000*100)+"%";
 $("turnLabel").textContent=started?(turn==="player"?"Your turn":"System turn"):"Ready";$("phaseLabel").textContent=phase;
 $("playerDeckCount").textContent=`Deck: ${playerDeck.length}`;$("enemyDeckCount").textContent=`Deck: ${enemyDeck.length}`;$("handCount").textContent=`${hand.length} cards`;
 for(const [id,field] of [["playerZones",playerField],["enemyZones",enemyField]]){const el=$(id);el.innerHTML="";for(let i=0;i<3;i++){const c=field[i],z=document.createElement("div");z.className="zone"+(c?"":" empty-zone");if(c){z.textContent=c.name;const stat=document.createElement("span");stat.className="atk";stat.textContent=`ATK ${c.atk??0} / DEF ${c.def??0}`;z.append(stat)}else z.textContent="Monster Zone";el.append(z)}}
 const hc=$("handCards");hc.innerHTML="";if(!hand.length)hc.innerHTML='<span class="muted">No cards in hand.</span>';hand.forEach((c,i)=>{const b=document.createElement("button");b.className="hand-card"+(i===selectedHandIndex?" selected":"");b.textContent=c.name;b.onclick=()=>{selectedHandIndex=i;renderDuel()};hc.append(b)})
}
function summonSelected(nameFromVoice=null){
 if(!started){log("Start a duel first.");return}if(turn!=="player"){log("It is the system's turn.");return}if(playerField.length>=3){log("Demo monster zones are full.");return}
 let idx=selectedHandIndex;if(nameFromVoice){idx=hand.findIndex(c=>c.name.toLowerCase()===nameFromVoice.toLowerCase())}
 if(idx<0||idx>=hand.length){log("Select a monster in your hand first, or say its exact name.");return}
 const c=hand[idx];if(!isMonster(c)){log(`${c.name} is not a monster. Spell/Trap activation is not fully implemented yet.`);return}
 if((c.level||0)>4){log(`${c.name} normally needs Tribute(s) under official rules. Tribute Summoning is not implemented in this demo, so it cannot be summoned here.`);return}
 playerField.push(c);hand.splice(idx,1);selectedHandIndex=-1;phase="Main Phase 1";renderDuel();log(`You summon ${c.name}. Demo rule check: only monsters Level 4 or lower can be summoned without tributes.`);
}
function endTurn(){
 if(!started){log("Start a duel first.");return}if(turn!=="player"){log("The system is already taking its turn.");return}
 turn="system";phase="System Main Phase";renderDuel();log("System turn begins. The opponent evaluates its available demo moves.");setTimeout(systemTurn,500)
}
function systemTurn(){
 if(!started)return;
 // Simple baseline opponent: summon a legal low-level monster if possible, otherwise a high-ATK monster only when field is empty (clearly demo logic).
 const available=enemyDeck.filter(c=>isMonster(c));let chosen=available.find(c=>(c.level||0)<=4);
 if(enemyField.length<3&&chosen){enemyDeck.splice(enemyDeck.indexOf(chosen),1);enemyField.push(chosen);log(`System summons ${chosen.name}.`)}
 else if(enemyField.length<3&&available.length){chosen=available[0];enemyDeck.splice(enemyDeck.indexOf(chosen),1);if((chosen.level||0)<=4){enemyField.push(chosen);log(`System summons ${chosen.name}.`)}}
 if(playerField.length&&enemyField.length){
  const p=playerField[playerField.length-1],e=enemyField[enemyField.length-1];
  if(e.atk>p.atk){const dmg=e.atk-p.atk;playerLP=Math.max(0,playerLP-dmg);playerField.pop();log(`System attacks with ${e.name}; your ${p.name} is defeated in this simplified battle. You lose ${dmg} LP.`)}
  else if(e.atk<p.atk){const dmg=p.atk-e.atk;enemyLP=Math.max(0,enemyLP-dmg);enemyField.pop();log(`Your ${p.name} defeats ${e.name} in this simplified battle. System loses ${dmg} LP.`)}
  else log("The two monsters have equal ATK; no battle damage in this demo.");
 }else if(enemyField.length&&!playerField.length){const attacker=enemyField[enemyField.length-1];playerLP=Math.max(0,playerLP-attacker.atk);log(`Direct attack by ${attacker.name}: you lose ${attacker.atk} LP in this demo.`)}
 if(playerLP<=0||enemyLP<=0){started=false;phase="Duel Ended";log(playerLP<=0?"The Duel System wins.":"You win!");renderDuel();return}
 turn="player";phase="Draw Phase";renderDuel();log("Your turn. Draw a card, then make your move.")
}
function command(raw){
 const s=raw.trim();if(!s)return;log(`Command received: “${s}”`);const lower=s.toLowerCase();
 if(/end turn|pass turn|finish turn/i.test(lower)){endTurn();return}
 if(/draw/i.test(lower)){drawCard();return}
 if(/summon|normal summon|special summon/i.test(lower)){
  const name=library.find(c=>lower.includes(c.name.toLowerCase()))?.name;
  summonSelected(name||null);return
 }
 if(/activate/i.test(lower)){log("Activation intent recognized. Full effect resolution needs the official card text, legal timing, target/cost validation, and chain handling; this demo will not invent an effect.");return}
 if(/battle phase/i.test(lower)){phase="Battle Phase";renderDuel();log("Battle Phase selected. Attack declaration and full battle-step rules are not implemented yet.");return}
 if(/help|commands/i.test(lower)){log("Commands: draw card; summon [exact card name]; battle phase; end turn. You can also select a card in your hand and press Summon.");return}
 log("No supported action matched. Try “draw card”, “summon [card name]”, or “end turn”.")
}
$("drawBtn").onclick=()=>drawCard();
$("summonBtn").onclick=()=>summonSelected();
$("endTurnBtn").onclick=endTurn;
$("runCommand").onclick=()=>{command($("commandInput").value);$("commandInput").value=""};
$("commandInput").addEventListener("keydown",e=>{if(e.key==="Enter")$("runCommand").click()});
$("voiceBtn").onclick=()=>{
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){$("voiceState").textContent="Speech recognition unavailable";toast("Try a supported browser or type commands.");return}
 const rec=new SR();rec.lang="en-US";rec.interimResults=false;rec.maxAlternatives=1;$("voiceState").textContent="Listening…";
 rec.onresult=e=>{const s=e.results[0][0].transcript;$("voiceState").textContent=`Heard: ${s}`;command(s)};
 rec.onerror=e=>{$("voiceState").textContent=`Voice error: ${e.error}`};rec.onend=()=>{if($("voiceState").textContent==="Listening…")$("voiceState").textContent="Microphone idle"};
 try{rec.start()}catch(e){$("voiceState").textContent="Could not start microphone"}
};
$("cardSearch").addEventListener("input",()=>{clearTimeout(searchTimer);searchTimer=setTimeout(renderLibrary,120)});
$("typeFilter").onchange=renderLibrary;
$("refreshLibrary").onclick=()=>loadOnlineCards(false);
$("loadMoreBtn").onclick=()=>loadOnlineCards(true);
async function loadOnlineCards(more){
 const query=$("cardSearch").value.trim();$("libraryNotice").textContent="Loading card data from the public YGOPRODeck API…";
 try{
  let url=API+"?num=80&offset="+(more?apiOffset+80:0);
  if(query)url=API+"?fname="+encodeURIComponent(query)+"&num=80&offset="+(more?apiOffset+80:0);
  const r=await fetch(url);if(!r.ok)throw new Error("API request failed ("+r.status+")");const data=await r.json();
  const incoming=(data.data||[]).map(c=>({id:c.id,name:c.name,type:c.type,desc:c.desc,atk:c.atk,def:c.def,level:c.level,race:c.race,attribute:c.attribute,icon:"🃏",image:c.card_images?.[0]?.image_url}));
  if(!more)library=[...demoCards];for(const c of incoming)if(!library.some(x=>x.id===c.id))library.push(c);
  apiOffset=more?apiOffset+80:0;$("libraryNotice").textContent=`Loaded ${incoming.length} API result(s). Card data is supplied by a third-party service and may have limits or errors.`;renderLibrary();toast("Card library updated");
 }catch(e){$("libraryNotice").textContent="Online card lookup failed. Check your internet connection; the bundled demo library is still available. "+e.message;toast("Online lookup unavailable")}
}
$("newDeckBtn").onclick=()=>{if(totalDeck()&&!confirm("Start a new empty deck? Export the current deck first if you want to keep it."))return;activeDeck=new Map();$("deckName").value="New Deck";renderDeck()};
$("saveDeckBtn").onclick=()=>{const name=$("deckName").value.trim()||"My Deck";savedDecks[name]=new Map(activeDeck);try{localStorage.setItem("duelscan_saved_decks",JSON.stringify(Object.fromEntries(Object.entries(savedDecks).map(([n,m])=>[n,[...m]]))))}catch(e){}$("deckNotice").textContent=`Saved “${name}” in this browser session.`;toast("Deck saved")};
try{const saved=JSON.parse(localStorage.getItem("duelscan_saved_decks")||"{}");for(const [n,arr] of Object.entries(saved))savedDecks[n]=new Map(arr)}catch(e){}
$("exportDeckBtn").onclick=()=>{const body="#created by DuelScan\n#main\n"+[...activeDeck.entries()].flatMap(([name,n])=>Array(n).fill(name)).join("\n")+"\n!side\n";downloadText(($("deckName").value||"deck").replace(/[^a-z0-9_-]/gi,"_")+".ydk",body)};
function downloadText(name,body){const a=document.createElement("a");const u=URL.createObjectURL(new Blob([body],{type:"text/plain"}));a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1000)}
$("importDeck").onchange=async e=>{
 const f=e.target.files[0];if(!f)return;const text=await f.text();let added=0,unknown=[];
 const lines=text.split(/\r?\n/).map(s=>s.trim()).filter(s=>s&&!s.startsWith("#")&&!s.startsWith("!"));
 for(const line of lines){let c=library.find(x=>x.name.toLowerCase()===line.toLowerCase());if(!c&&/^\d+$/.test(line))c=library.find(x=>String(x.id)===line);if(c){activeDeck.set(c.name,(activeDeck.get(c.name)||0)+1);added++}else unknown.push(line)}
 renderDeck();$("deckNotice").textContent=`Imported ${added} recognized card entries.${unknown.length?` ${unknown.length} names/IDs were not found in the loaded library; load online library or check the file format.`:""}`;toast(`Imported ${added} cards`)
};
async function startCamera(){
 if(!navigator.mediaDevices?.getUserMedia){$("scanStatus").textContent="Camera API unavailable. Try HTTPS or a supported mobile browser.";return}
 try{cameraStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:"environment"}},audio:false});$("cameraVideo").srcObject=cameraStream;$("cameraVideo").style.display="block";$("cameraPlaceholder").style.display="none";$("captureBtn").disabled=false;$("stopCameraBtn").disabled=false;$("startCameraBtn").disabled=true;await $("cameraVideo").play();$("scanStatus").textContent="Camera is running. Place one card inside the guide and capture it."}
 catch(e){$("scanStatus").textContent="Could not access camera: "+e.message+". Check browser permissions and use HTTPS/localhost."}
}
function stopCamera(){if(cameraStream){cameraStream.getTracks().forEach(t=>t.stop());cameraStream=null}$("cameraVideo").srcObject=null;$("cameraVideo").style.display="none";$("cameraPlaceholder").style.display="flex";$("captureBtn").disabled=true;$("stopCameraBtn").disabled=true;$("startCameraBtn").disabled=false}
$("startCameraBtn").onclick=startCamera;$("stopCameraBtn").onclick=stopCamera;
$("captureBtn").onclick=()=>{const v=$("cameraVideo"),c=$("captureCanvas");if(!v.videoWidth){toast("Camera frame not ready");return}c.width=v.videoWidth;c.height=v.videoHeight;c.getContext("2d").drawImage(v,0,0);c.toBlob(blob=>{if(!blob)return;const url=URL.createObjectURL(blob);processPhoto(url,blob,"camera-capture.jpg")})};
$("photoInput").onchange=async e=>{for(const f of [...e.target.files])processPhoto(URL.createObjectURL(f),f,f.name);e.target.value=""};
async function processPhoto(url,blob,name){
 const preview=$("photoPreview"),img=document.createElement("img");img.src=url;img.alt=name;preview.prepend(img);
 $("scanStatus").textContent=`Analyzing ${name}…`;
 // Best-effort OCR using browser-loadable Tesseract.js. Network is required; user confirms any match.
 try{
  if(!window.Tesseract){await loadScript("https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js")}
  const result=await window.Tesseract.recognize(url,"eng");const text=result.data.text||"";
  const normalized=text.toLowerCase().replace(/[^a-z0-9 ]/g," ").replace(/\s+/g," ").trim();
  const scored=library.map(c=>({c,score:normalized.includes(c.name.toLowerCase())?100:wordScore(normalized,c.name.toLowerCase())})).sort((a,b)=>b.score-a.score);
  showMatches(name,scored.filter(x=>x.score>0).slice(0,3),text);
 }catch(err){$("scanStatus").textContent=`Photo loaded, but OCR could not run (${err.message}). You can still search the card library and add the match manually.`;showMatches(name,[], "")}
}
function wordScore(text,name){const words=name.split(" ");let n=0;for(const w of words)if(w.length>2&&text.includes(w))n++;return n/words.length*60}
function loadScript(src){return new Promise((resolve,reject)=>{const s=document.createElement("script");s.src=src;s.onload=resolve;s.onerror=()=>reject(new Error("OCR library download failed"));document.head.append(s)})}
function showMatches(filename,matches,ocrText){
 const box=$("recognitionResults");const group=document.createElement("div");group.className="subpanel";group.style.padding="10px";const title=document.createElement("b");title.textContent=filename;title.style.fontSize="11px";group.append(title);
 if(!matches.length){const p=document.createElement("p");p.className="hint";p.textContent="No confident match found. Search the card library by name and add the correct card manually.";group.append(p)}
 else matches.forEach(({c,score})=>{const row=document.createElement("div");row.className="match-row";const span=document.createElement("span");span.textContent=`${c.name} · ${Math.round(score)}% text match`;const btn=document.createElement("button");btn.className="secondary";btn.textContent="Add";btn.onclick=()=>addToDeck(c.name);row.append(span,btn);group.append(row)});
 if(ocrText){const det=document.createElement("details");const sum=document.createElement("summary");sum.textContent="OCR text preview";const pre=document.createElement("p");pre.className="hint";pre.textContent=ocrText.slice(0,600);det.append(sum,pre);group.append(det)}
 box.prepend(group);$("scanStatus").textContent="Review the suggested match before adding it. OCR can misread text, especially on angled, shiny, or low-resolution cards.";
}
$("cardSearch").addEventListener("input",()=>{const q=$("cardSearch").value.trim();if(q.length>=3&&$("libraryNotice").textContent.includes("Showing bundled")){}});
renderLibrary();renderDeck();renderDuel();
