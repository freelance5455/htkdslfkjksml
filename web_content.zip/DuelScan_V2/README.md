# DuelScan V2 — upgraded prototype

This is an improved baseline for the physical-card Yu-Gi-Oh! single-player game idea.

## What's improved
- Multi-section mobile interface: Duel, Deck Builder, Card Library, Scanner
- Duel starts with a demo deck if you have not built one
- Hand, deck count, Life Points, basic low-level summons, and a simple virtual system opponent
- Voice command prototype for draw, summon, battle phase, and end turn
- Deck builder with save-to-browser, import, and `.ydk`-style export
- Deck size and duplicate-count warnings
- Live camera preview using the rear camera by default, capture frame, and photo upload
- Best-effort OCR via Tesseract.js loaded from a CDN; recognized text is matched to cards currently loaded in the library and must be confirmed
- Optional online card lookup using the public YGOPRODeck API
- PWA manifest starter

## Run
Extract the ZIP and open `index.html` in a modern browser. For camera and microphone features, use HTTPS or localhost and grant permissions. Some browser APIs (especially speech recognition) vary by browser. For a phone test, hosting on a secure HTTPS site is usually easier than opening a local file.

## Known limits — important
This is **not yet a complete official Yu-Gi-Oh! game**:
- The duel engine is intentionally simplified and does not implement official chains, priority/timing, every summoning procedure, continuous effects, costs, targets, replacement effects, or all card-specific rulings.
- The AI opponent is a basic demonstration policy, not a competitive deck pilot.
- The included card list is only a starter. The optional API lookup is third-party, internet-dependent, and not a guarantee of an exhaustive or licensed card database.
- OCR reads printed text; it is not robust visual card recognition. It can return wrong matches, especially with glare, sleeves, angled cards, and low resolution. Always confirm a suggested match.
- The scanner currently processes photos one at a time. Automatic real-time tracking of card movements on a table is not implemented.
- Deck legality checks are approximate and do not enforce the current official banlist.
- Images/card text are sourced from third parties only when the user explicitly triggers online lookup. Review provider terms and intellectual-property/licensing requirements before public release.

## Next production milestones
1. Replace browser prototype with native Android Kotlin/Jetpack Compose + CameraX.
2. Build a canonical card database and stable card IDs, card art handling, and format/banlist selection.
3. Implement a deterministic rules engine and per-card effect scripts; test each effect with replayable duel states.
4. Create legal-action generation and strategic search for the opponent. AI proposes moves; the rules engine validates them.
5. Add board calibration and multi-card detection for field zones; include manual confirmation for ambiguous movements.
6. Improve OCR with card-boundary detection, perspective correction, multilingual support, image matching, and confidence thresholds.
7. Add privacy controls and explain microphone/camera processing. Do not keep photos or recordings unless the player explicitly chooses to save them.

## Camera note
The front camera faces the player, so the rear camera is the practical default for seeing cards on a table. Camera access usually needs HTTPS or localhost.

## Rights and attribution
Yu-Gi-Oh! is a trademark and card content belongs to its respective owners. This is an independent fan-made prototype, not affiliated with or endorsed by Konami. Check API terms and rights before distribution.
