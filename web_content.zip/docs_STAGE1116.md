# CPLS / CryptoPulse — Stage 1116

## هدف
رفع ریشه‌ای اتصال Futures و حذف مسیرهای حدسی/غیرداکیومنت‌شده برای K-Line.

## تغییرات
- Futures REST فقط از میزبان رسمی Contract API استفاده می‌کند:
  - `https://lbkperp.lbank.com/`
  - `/cfd/openApi/v1/pub/marketData`
  - `/cfd/openApi/v1/pub/marketOrder`
- گروه Futures به `SwapU` محدود شد تا تلاش‌های پشت‌سرهم برای گروه‌های نامشخص باعث تأخیر طولانی صفحه نشود.
- کش لیست بازار Futures از 10 ثانیه به حدود 1.2 ثانیه کاهش یافت؛ Feed دوره‌ای 1.5 ثانیه‌ای دیگر قیمت 10 ثانیه قدیمی را تکرار نمی‌کند.
- خطاهای Futures دیگر silently swallowed نمی‌شوند؛ به WebView وضعیت `OFFLINE` و متن خطای قابل مشاهده ارسال می‌شود.
- `futuresKlines()` دیگر به endpointهای ساختگی/غیرداکیومنت‌شده مثل `/v2/futures/kline.do` و `/v2/future/kline.do` درخواست نمی‌زند.
- نمودار Futures همچنان از نمونه‌های واقعی قیمت Futures که از Feed دریافت می‌شوند، کندل‌های session/live می‌سازد؛ هیچ تاریخچه ساختگی به آن اضافه نشده است.
- در شروع صفحه، وضعیت اتصال به‌صورت `CONNECTING` نمایش داده می‌شود و فقط بعد از دریافت قیمت واقعی `FUTURES LIVE` می‌شود.
- Browser fallback موازی حذف شد تا هنگام مشکل Native دو مسیر همزمان به Contract API فشار وارد نکنند.

## مرجع فنی
مستند رسمی LBank Contract API در نسخه فعلی، REST را روی `https://lbkperp.lbank.com/` و WebSocket را روی `wss://lbkperpws.lbank.com/ws` اعلام می‌کند. مستند عمومی فعلی endpoint عمومی K-Line برای Futures را ارائه نمی‌کند؛ بنابراین Stage 1116 عمداً endpoint K-Line حدسی ایجاد نمی‌کند.

## محدودیت فعلی
Feed Futures این Stage هنوز REST polling سبک با فاصله حدود 1.5 ثانیه است، نه WebSocket Futures. علت این تصمیم این است که فرمت subscribe پیام WebSocket Futures در مستند عمومی فعلی به‌صورت قابل اتکا ارائه نشده و نباید JSON اشتباه وارد برنامه شود. مرحله بعدی، فقط پس از تأیید فرمت واقعی WS، می‌تواند Feed را به WebSocket رسمی `lbkperpws.lbank.com/ws` ارتقا دهد.

## وضعیت ساخت
این Stage به‌صورت Source ZIP آماده است. در محیط فعلی Gradle Wrapper وجود ندارد و ابزار `gradle` نیز نصب نیست؛ بنابراین APK در این محیط ساخته نشده است.
