AUTO-SCOOTER BLAST 3.8 – Android Studio Projekt

Dieses Projekt verpackt die HTML-Spielversion 3.8 in eine Android-WebView-App.
Voraussetzungen:
- Android Studio
- Android SDK Platform 35
- JDK 17

APK erstellen:
1. ZIP entpacken.
2. Ordner AUTO_SCOOTER_BLAST_3_8_Android in Android Studio öffnen.
3. Warten, bis Gradle-Synchronisierung abgeschlossen ist.
4. Menü Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Die APK liegt anschließend unter app/build/outputs/apk/debug/app-debug.apk.

Hinweis:
Das Spiel lädt Three.js derzeit über jsDelivr (Internetverbindung erforderlich).
Die App benötigt daher Internetzugriff. Für eine vollständig offlinefähige Version
muss Three.js zusätzlich lokal eingebunden werden.
