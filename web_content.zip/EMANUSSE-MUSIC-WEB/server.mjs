import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { URL } from 'node:url';

const ROOT = process.cwd();
const PUBLIC = path.join(ROOT, 'public');
const DATA = path.join(ROOT, 'data');
const LIB = path.join(DATA, 'library.json');
const SECRETS = path.join(DATA, 'secrets.json');
fs.mkdirSync(DATA, { recursive: true });
if (!fs.existsSync(LIB)) fs.writeFileSync(LIB, '[]');
if (!fs.existsSync(SECRETS)) fs.writeFileSync(SECRETS, '{}');

function json(res, status, body) { const out=JSON.stringify(body); res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}); res.end(out); }
function readBody(req) { return new Promise((resolve,reject)=>{ let s=''; req.on('data',c=>{s+=c; if(s.length>2e6){req.destroy();reject(new Error('Body too large'));}}); req.on('end',()=>{try{resolve(s?JSON.parse(s):{});}catch(e){reject(e);}}); req.on('error',reject); }); }
function load(file, fallback){ try{return JSON.parse(fs.readFileSync(file,'utf8'));}catch{return fallback;} }
function save(file, data){ fs.writeFileSync(file, JSON.stringify(data,null,2)); }
function keyFrom(req, body){ return String(req.headers['x-soundgen-key'] || body?.apiKey || load(SECRETS,{}).soundgen || '').trim(); }
async function soundgen(pathname, method, body, apiKey){
  if(!apiKey) throw new Error('Falta la API Key de SoundGen. Abre Secretos y guárdala.');
  const base=(body.baseUrl || 'https://api.soundgen.io').replace(/\/$/,'');
  const r=await fetch(base+pathname,{method,headers:{Authorization:`Bearer ${apiKey}`,'Content-Type':'application/json'},body:method==='GET'?undefined:JSON.stringify(body.payload||{})});
  const text=await r.text(); let data=text; try{data=JSON.parse(text);}catch{}
  if(!r.ok) throw new Error(`SoundGen ${r.status}: ${typeof data==='string'?data:(data.message||data.error||data.detail||JSON.stringify(data))}`.slice(0,700));
  return data;
}

async function api(req,res,url){
  if(url.pathname==='/api/health') return json(res,200,{ok:true,app:'EMANÜSSE MUSIC'});
  if(url.pathname==='/api/secrets' && req.method==='GET') return json(res,200,{soundgen:Boolean(load(SECRETS,{}).soundgen)});
  if(url.pathname==='/api/secrets' && req.method==='POST') { const b=await readBody(req); const current=load(SECRETS,{}); if(b.soundgen!==undefined) current.soundgen=String(b.soundgen||'').trim(); save(SECRETS,current); return json(res,200,{ok:true,soundgen:Boolean(current.soundgen)}); }
  if(url.pathname==='/api/library' && req.method==='GET') return json(res,200,load(LIB,[]));
  if(url.pathname==='/api/library' && req.method==='DELETE') { const id=url.searchParams.get('id'); const items=load(LIB,[]).filter(x=>x.id!==id); save(LIB,items); return json(res,200,{ok:true}); }
  if(url.pathname==='/api/generate' && req.method==='POST') {
    const b=await readBody(req); const apiKey=keyFrom(req,b); const prompt=String(b.prompt||'').trim(); if(!prompt) return json(res,400,{error:'Escribe una idea para la canción.'});
    const payload={input:{duration:Number(b.duration||180),textPrompt:[prompt,b.styles?.length?`Estilos: ${b.styles.join(', ')}.`:'',b.lyrics?`Letras originales:\n${b.lyrics}`:'',b.negativeTags?`Evitar: ${b.negativeTags}.`:'' ].filter(Boolean).join('\n\n'),projectName:'EMANÜSSE MUSIC',type:'TEXT_PROMPT_TO_MUSIC',generateCover:false}};
    try { const created=await soundgen('/api/v1/music/create','POST',{baseUrl:b.baseUrl,payload},apiKey); const musicId=created?.data?.musicId||created?.data?.id||created?.musicId||created?.id; const item={id:crypto.randomUUID(),provider:'SoundGen',title:String(b.title||'Nueva canción'),prompt,styles:b.styles||[],duration:Number(b.duration||180),status:String(created?.data?.status||created?.status||'GENERATING').toUpperCase(),musicId:musicId||null,audioUrl:(created?.data?.audioUrl||created?.data?.audio_url||created?.audioUrl||created?.audio_url||created?.url||null),createdAt:new Date().toISOString(),raw:created}; const items=load(LIB,[]); items.unshift(item); save(LIB,items); return json(res,200,item); }
    catch(e){ return json(res,502,{error:e.message}); }
  }
  if(url.pathname.startsWith('/api/music/') && req.method==='GET') {
    const id=decodeURIComponent(url.pathname.slice('/api/music/'.length)); const b=await readBody(req); const apiKey=keyFrom(req,b);
    try {
      const data=await soundgen(`/api/v1/music/${encodeURIComponent(id)}`,'GET',{baseUrl:b.baseUrl},apiKey);
      const d=data?.data && typeof data.data==='object'?data.data:data;
      const items=load(LIB,[]); const idx=items.findIndex(x=>x.musicId===id);
      const audio=d?.audioUrl||d?.audio_url||d?.url||d?.downloadUrl||d?.download_url||null;
      const status=String(d?.status||data?.status||'GENERATING').toUpperCase();
      if(idx>=0){items[idx]={...items[idx],status,audioUrl:audio||items[idx].audioUrl||null,raw:data,lastCheckedAt:new Date().toISOString()};save(LIB,items);}
      return json(res,200,{...data,status,audioUrl:audio});
    }catch(e){return json(res,502,{error:e.message});}
  }
  if(url.pathname.startsWith('/api/library/') && url.pathname.endsWith('/audio') && req.method==='GET') {
    const id=decodeURIComponent(url.pathname.split('/')[3]); const item=load(LIB,[]).find(x=>x.id===id);
    if(!item?.audioUrl) return json(res,404,{error:'El audio todavía no está disponible. Actualiza el estado primero.'});
    try {
      const r=await fetch(item.audioUrl); if(!r.ok) throw new Error(`Audio ${r.status}`);
      const buf=Buffer.from(await r.arrayBuffer());
      res.writeHead(200,{'Content-Type':r.headers.get('content-type')||'audio/mpeg','Content-Disposition':`attachment; filename="${(item.title||'emanusse').replace(/[^a-z0-9 _-]/gi,'').trim()||'emanusse'}.mp3"`});
      return res.end(buf);
    }catch(e){return json(res,502,{error:`No se pudo descargar el audio: ${e.message}`});}
  }
  return json(res,404,{error:'Not found'});
}

const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json'};
const server=http.createServer(async(req,res)=>{try{const u=new URL(req.url,'http://localhost'); if(u.pathname.startsWith('/api/')) return await api(req,res,u); let p=path.normalize(path.join(PUBLIC,u.pathname==='/'?'index.html':u.pathname)); if(!p.startsWith(PUBLIC)) return json(res,403,{error:'Forbidden'}); if(!fs.existsSync(p)||fs.statSync(p).isDirectory()) p=path.join(PUBLIC,'index.html'); res.writeHead(200,{'Content-Type':MIME[path.extname(p)]||'application/octet-stream'}); fs.createReadStream(p).pipe(res);}catch(e){json(res,500,{error:e.message});}});
const port=Number(process.env.PORT||3000); server.listen(port,'0.0.0.0',()=>console.log(`EMANÜSSE MUSIC: http://localhost:${port}`));
