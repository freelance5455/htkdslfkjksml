package com.nettricks.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.security.MessageDigest

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var pending: PermissionRequest? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var camUri: Uri? = null
    private val channel = "https://t.me/nettricks1"
    private val prefs by lazy { getSharedPreferences("nt", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#1A0709")
        window.navigationBarColor = Color.parseColor("#1A0709")

        // Integrity checks: official signature (when pinned) and untouched page content.
        val bytes = assets.open("index.html").use { it.readBytes() }
        if (!certOk() || sha256(bytes) != BuildConfig.PAGE_HASH) {
            tampered()
            return
        }

        WebView.setWebContentsDebuggingEnabled(false)
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#1A0709"))
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        web.addJavascriptInterface(Bridge(), "NT")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == "nettricks.app") return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url))
                } catch (e: Exception) {
                }
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(request.resources)
                    } else {
                        pending = request
                        requestPermissions(arrayOf(Manifest.permission.CAMERA), 7)
                    }
                }
            }

            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: WebChromeClient.FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = callback
                if (params.isCaptureEnabled) {
                    if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(arrayOf(Manifest.permission.CAMERA), 10)
                        return true
                    }
                    if (launchCapture()) return true
                }
                pickFromGallery()
                return true
            }
        }
        // Served from an https base URL so the camera (secure context) and storage work.
        web.loadDataWithBaseURL("https://nettricks.app/", String(bytes, Charsets.UTF_8), "text/html", "UTF-8", null)
        setContentView(web)
        showChannelDialog()
    }

    private fun sha256(b: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    private fun certOk(): Boolean {
        val pin = BuildConfig.CERT_SHA256.replace(":", "").lowercase()
        if (pin.isEmpty()) return true
        return try {
            val sigs = if (Build.VERSION.SDK_INT >= 28) {
                packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                    .signingInfo.apkContentsSigners
            } else {
                @Suppress("DEPRECATION")
                packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES).signatures
            }
            sha256(sigs[0].toByteArray()) == pin
        } catch (e: Exception) {
            false
        }
    }

    private fun openChannel() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(channel)))
        } catch (e: Exception) {
        }
    }

    // Native dialog: it lives in compiled code, so it cannot be removed by editing the page.
    private fun showChannelDialog() {
        AlertDialog.Builder(this)
            .setTitle("Join Net Tricks on Telegram")
            .setMessage("Get updates and new features in our channel.")
            .setCancelable(false)
            .setPositiveButton("Join channel") { _, _ -> openChannel() }
            .setNegativeButton("Later", null)
            .show()
    }

    private fun tampered() {
        AlertDialog.Builder(this)
            .setTitle("Unofficial copy")
            .setMessage("This app was modified or repackaged. Please install the official Net Tricks app from our Telegram channel.")
            .setCancelable(false)
            .setPositiveButton("Open channel") { _, _ -> openChannel(); finish() }
            .setNegativeButton("Close") { _, _ -> finish() }
            .show()
    }

    private fun launchCapture(): Boolean {
        return try {
            val v = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "NetTricks_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/NetTricks")
            }
            val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return false
            camUri = u
            val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            i.putExtra(MediaStore.EXTRA_OUTPUT, u)
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivityForResult(i, 8)
            true
        } catch (e: Exception) {
            camUri = null
            false
        }
    }

    private fun pickFromGallery() {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        startActivityForResult(Intent.createChooser(i, "Choose a photo"), 8)
    }

    inner class Bridge {
        @JavascriptInterface
        fun get(key: String): String = prefs.getString(key, "") ?: ""

        @JavascriptInterface
        fun put(key: String, value: String) {
            if (key.length < 64 && value.length < 2_000_000) prefs.edit().putString(key, value).apply()
        }

        @JavascriptInterface
        fun save(data: String) {
            if (Build.VERSION.SDK_INT < 29 &&
                checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
            ) {
                runOnUiThread {
                    requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 9)
                    Toast.makeText(this@MainActivity, "Allow storage, then tap Save again", Toast.LENGTH_LONG).show()
                }
                return
            }
            try {
                val mime = data.substringAfter("data:").substringBefore(";")
                val ext = if (mime.contains("png")) "png" else "jpg"
                val bytes = Base64.decode(data.substringAfter(","), Base64.DEFAULT)
                val v = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "NetTricks_${System.currentTimeMillis()}.$ext")
                    put(MediaStore.Images.Media.MIME_TYPE, mime)
                    if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/NetTricks")
                }
                val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
                if (u != null) contentResolver.openOutputStream(u)?.use { it.write(bytes) }
                runOnUiThread { Toast.makeText(this@MainActivity, "Saved to Pictures", Toast.LENGTH_SHORT).show() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, "Could not save", Toast.LENGTH_SHORT).show() }
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        if (requestCode == 7) {
            val r = pending
            pending = null
            if (ok) r?.grant(r.resources) else r?.deny()
        } else if (requestCode == 10) {
            if (ok) {
                if (!launchCapture()) pickFromGallery()
            } else {
                fileCb?.onReceiveValue(null)
                fileCb = null
            }
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 8) {
            val cu = camUri
            camUri = null
            val u = data?.data ?: cu
            if (resultCode == RESULT_OK && u != null) {
                fileCb?.onReceiveValue(arrayOf(u))
            } else {
                fileCb?.onReceiveValue(null)
                if (cu != null) {
                    try {
                        contentResolver.delete(cu, null, null)
                    } catch (e: Exception) {
                    }
                }
            }
            fileCb = null
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (!::web.isInitialized) {
            finish()
            return
        }
        web.evaluateJavascript("back()") {
            if (it == "0") finish()
        }
    }
}
