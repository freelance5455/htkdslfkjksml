# BombeLite — menu e jogo para Android

O pacote agora inclui **duas versões**:

- **Android Studio com HTML/WebView:** abra a pasta `android/` no Android Studio. O app abre em paisagem com uma tela inicial inspirada no estilo do Samsung A07/One UI, ícones de aplicativos e o jogo Bombe Lite.
- **Godot:** abra `project.godot` na pasta principal com Godot 4.3+. A cena principal é `Main.tscn`.

## Usar no Android Studio
1. Abra a pasta `android/` no Android Studio.
2. Aguarde o Gradle sincronizar e instale o JDK 17 e Android SDK 35 quando solicitado.
3. Rode em um celular ou emulador. A orientação paisagem já está configurada.

O HTML usado pelo app fica em `android/app/src/main/assets/index.html`; a cópia independente fica em `index.html` na raiz. Não precisa de internet. O menu oferece categorias, busca, botões voltar/início/sair e um mini jogo jogável com teclado ou controles de toque.

## Versão Godot
Abra o arquivo `project.godot` na pasta `BombeLite/` pelo Godot 4.3+. No menu, toque em **JOGAR BOMBE LITE**; use as setas/WASD e Espaço, ou os controles na tela do jogo.

## Imagem e ícones
A referência enviada está em `referencia_menu.jpg`; o projeto também mantém a arte em `arte/logo_bombe_elite.png`. Os ícones individuais de WhatsApp, YouTube, Minecraft, Play Store e Google não vieram como anexos separados, então o HTML usa símbolos temporários. Os arquivos podem ser colocados em `icones/` para uma personalização posterior.
