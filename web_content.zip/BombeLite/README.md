# Bombe Lite — menu horizontal e jogo

O pacote contém a versão **Android Studio (HTML/WebView)** e a versão **Godot**. O menu segue a referência Bombe Lite enviada, com orientação paisagem.

## Android Studio
Abra a pasta `android/`, aguarde o Gradle sincronizar e rode em um aparelho Android. O HTML inicial fica em `android/app/src/main/assets/index.html`. A versão independente está em `index.html`.

Os atalhos do menu chamam a camada nativa Kotlin para abrir Minecraft, WhatsApp, Roblox, Free Fire, YouTube, Google, Play Store, Gmail, Configurações, Bluetooth ou uma página no navegador. O botão Bluetooth abre uma tela própria inspirada na imagem enviada, permite filtrar fones/caixas/outros, procurar aparelhos, selecionar e solicitar pareamento; o Android mostra a confirmação do sistema. A opção Desconectar encaminha ao painel Bluetooth do Android, pois a API pública não permite desconectar genericamente qualquer perfil. Apps sem fallback web precisam estar instalados; o próprio Bombe Lite mostra um aviso se não encontrar o pacote. O botão Bombe Lite abre o minijogo embutido.

Para usar o HTML independente, mantenha `index.html` junto com `bombe-logo.png`.

## Godot
Abra `project.godot` com Godot 4.3 ou superior. A cena inicial está definida no projeto (`cenas/Menu.tscn`); os atalhos Bluetooth e Configurações abrem suas cenas. O GDScript procura o singleton `BluetoothManager` (ou o antigo `BluetoothPlugin`) para ativar, procurar, parear por nome e desconectar. Sem esse plugin Android nativo, informa que o plugin não está instalado e oferece as configurações Bluetooth do sistema como alternativa.

## Ícones
O emblema foi recortado da imagem de referência enviada. Os ícones individuais dos apps foram representados com símbolos; os pacotes Android e ações nativas ficam mapeados em `android/app/src/main/java/com/bombelite/app/MainActivity.kt`.


## Baixar jogos
Minecraft, Roblox e Free Fire abrem o app se estiver instalado; caso contrário, levam à página do jogo na Play Store. Na categoria Jogos, toque em **Baixar mais jogos** para pesquisar outros títulos. A instalação é concluída pelo usuário na Play Store.


## Imagens enviadas
As imagens enviadas ficam nos assets Android e na raiz do projeto. Abra **Todos os apps → Sobre** para consultar as referências de Bluetooth e configurações; as imagens são ilustrativas.

## Bluetooth e configurações adicionados
As duas imagens enviadas nesta conversa foram incluídas na raiz do projeto e nos assets Android como `referencia_bluetooth_enviada.jpg` e `referencia_configuracoes_enviada.jpg`. No Android, elas podem ser abertas em **Todos os apps → Sobre**; a imagem de configurações também aparece na tela **Configurações do Bombe Lite**. A tela Bluetooth agora tem filtros por tipo, seleção do dispositivo e os botões **Parear** e **Desconectar**.

A tela Configurações do Bombe Lite inclui ativação/desativação de notificações (estado visual), seleção entre **Só ícone** e **Detalhes**, controle de transparência da prévia, reversão de cor do texto e campo de pesquisa. Essas opções alteram a prévia do Bombe Lite; não mudam as notificações globais do Android.

No app Android Studio, **Procurar dispositivos** pede a permissão necessária e inicia a descoberta Bluetooth; tocar em um dispositivo encontrado solicita o pareamento ao Android. O sistema exibe a confirmação de pareamento. Em aparelhos Android 11 ou anteriores, a permissão de localização pode ser necessária para a descoberta Bluetooth. A tela Godot chama `BluetoothManager` (ou `BluetoothPlugin`) quando o plugin nativo estiver instalado; sem ele, abre as configurações Bluetooth do Android como alternativa segura.
