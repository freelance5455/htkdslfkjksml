# Bombe Lite — menu horizontal e jogo

O pacote contém a versão **Android Studio (HTML/WebView)** e a versão **Godot**. O menu segue a referência Bombe Lite enviada, com orientação paisagem.

## Android Studio
Abra a pasta `android/`, aguarde o Gradle sincronizar e rode em um aparelho Android. O HTML inicial fica em `android/app/src/main/assets/index.html`. A versão independente está em `index.html`.

Os atalhos do menu chamam a camada nativa Kotlin para abrir Minecraft, WhatsApp, Roblox, Free Fire, YouTube, Google, Play Store, Gmail, Configurações, Bluetooth ou uma página no navegador. O botão Bluetooth abre uma tela própria inspirada na imagem enviada; ela mostra o estado do adaptador e dispositivos já pareados. Ativar, procurar e parear novos aparelhos abre a tela oficial do Android, onde o sistema conclui o pareamento com segurança. Apps sem fallback web precisam estar instalados; o próprio Bombe Lite mostra um aviso se não encontrar o pacote. O botão Bombe Lite abre o minijogo embutido.

Para usar o HTML independente, mantenha `index.html` junto com `bombe-logo.png`.

## Godot
Abra `project.godot` com Godot 4.3 ou superior. A cena inicial está definida no projeto (`cenas/Menu.tscn`); o atalho Bluetooth abre `cenas/Bluetooth.tscn`. Na versão Godot, os controles Ativar/Procurar encaminham para as configurações do Android: a busca e o pareamento são realizados pelo sistema, não por uma conexão BLE própria do GDScript.

## Ícones
O emblema foi recortado da imagem de referência enviada. Os ícones individuais dos apps foram representados com símbolos; os pacotes Android e ações nativas ficam mapeados em `android/app/src/main/java/com/bombelite/app/MainActivity.kt`.


## Baixar jogos
Minecraft, Roblox e Free Fire abrem o app se estiver instalado; caso contrário, levam à página do jogo na Play Store. Na categoria Jogos, toque em **Baixar mais jogos** para pesquisar outros títulos. A instalação é concluída pelo usuário na Play Store.


## Imagens enviadas
As duas imagens recebidas foram incluídas nos assets do Android e na pasta raiz do projeto. No app, abra **Todos os apps → Sobre** para ver a referência do menu e a imagem de ajuda sobre notificações da tela bloqueada. A imagem de notificações é ilustrativa; as opções podem variar por aparelho.

## Bluetooth e configurações adicionados
As duas imagens enviadas nesta conversa foram incluídas na raiz do projeto e nos assets Android como `referencia_bluetooth_enviada.jpg` e `referencia_configuracoes_enviada.jpg`. No Android, elas podem ser abertas em **Todos os apps → Sobre**; a imagem de configurações também aparece na tela **Configurações do Bombe Lite**.

A tela Configurações do Bombe Lite inclui ativação/desativação de notificações (estado visual), seleção entre **Só ícone** e **Detalhes**, controle de transparência da prévia, reversão de cor do texto e campo de pesquisa. Essas opções alteram a prévia do Bombe Lite; não mudam as notificações globais do Android.

No app Android Studio, **Procurar dispositivos** pede a permissão necessária e inicia a descoberta Bluetooth; tocar em um dispositivo encontrado solicita o pareamento ao Android. O sistema exibe a confirmação de pareamento. Em aparelhos Android 11 ou anteriores, a permissão de localização pode ser necessária para a descoberta Bluetooth. A tela Godot chama os métodos de `BluetoothPlugin` quando esse plugin nativo estiver instalado; sem ele, abre as configurações Bluetooth do Android como alternativa segura.
