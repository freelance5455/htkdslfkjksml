extends Control

const BG := Color("#050b14")
const PANEL := Color("#101a28")
const PANEL_HOVER := Color("#17263a")
const BORDER := Color("#22354b")
const WHITE := Color("#f4f8ff")
const MUTED := Color("#9aabc0")
const CYAN := Color("#12c9f4")

const SECTIONS := [
	{"name": "Aplicativos essenciais", "short": "Apps", "icon": "▦", "color": Color("#1677ff"), "description": "WhatsApp, YouTube, Play Store e Google", "items": ["WhatsApp", "YouTube", "Play Store", "Google"]},
	{"name": "Jogos", "short": "Jogos", "icon": "◆", "color": Color("#922fff"), "description": "Minecraft, Roblox, Free Fire e mais", "items": ["Minecraft", "Roblox", "Free Fire", "Stumble Guys", "GTA San Andreas"]},
	{"name": "Emuladores", "short": "Emuladores", "icon": "▣", "color": Color("#14b96a"), "description": "Seus emuladores e jogos retrô", "items": ["Super Nintendo", "Mega Drive", "PlayStation"]},
	{"name": "Navegador", "short": "Navegador", "icon": "◎", "color": Color("#ff9f18"), "description": "Acesse seus sites favoritos", "items": ["Sites favoritos", "Pesquisar na internet"]},
	{"name": "Mídia", "short": "Mídia", "icon": "♫", "color": Color("#f32978"), "description": "Músicas, vídeos e galeria", "items": ["Músicas", "Vídeos", "Galeria"]},
	{"name": "Utilitários", "short": "Utilitários", "icon": "⚙", "color": Color("#10b8c8"), "description": "Ferramentas e configurações úteis", "items": ["Configurações", "Arquivos", "Limpeza"]},
	{"name": "Sobre", "short": "Sobre", "icon": "ⓘ", "color": Color("#718096"), "description": "Informações do BombeLite", "items": ["BombeLite", "Seu mundo em um só lugar"]}
]

var page_content: VBoxContainer
var nav_buttons: Array[Button] = []
var current_section: Dictionary = {}

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_build_shell()
	_show_home()

func _build_shell() -> void:
	var bg := ColorRect.new()
	bg.color = BG
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)

	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 24)
	margin.add_theme_constant_override("margin_top", 18)
	margin.add_theme_constant_override("margin_right", 24)
	margin.add_theme_constant_override("margin_bottom", 16)
	add_child(margin)

	var shell := HBoxContainer.new()
	shell.add_theme_constant_override("separation", 16)
	margin.add_child(shell)

	var main_column := VBoxContainer.new()
	main_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main_column.size_flags_vertical = Control.SIZE_EXPAND_FILL
	main_column.add_theme_constant_override("separation", 12)
	shell.add_child(main_column)

	main_column.add_child(_build_header())
	page_content = VBoxContainer.new()
	page_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	page_content.size_flags_vertical = Control.SIZE_EXPAND_FILL
	page_content.add_theme_constant_override("separation", 12)
	main_column.add_child(page_content)
	main_column.add_child(_build_footer())
	shell.add_child(_build_sidebar())

func _build_header() -> Control:
	var row := HBoxContainer.new()
	row.custom_minimum_size.y = 76
	row.add_theme_constant_override("separation", 16)

	var emblem := PanelContainer.new()
	emblem.custom_minimum_size = Vector2(58, 58)
	emblem.add_theme_stylebox_override("panel", _panel_style(Color("#102840"), 18, Color("#0879c5")))
	var bomb := Label.new()
	bomb.text = "✹"
	bomb.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	bomb.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	bomb.add_theme_font_size_override("font_size", 28)
	emblem.add_child(bomb)
	row.add_child(emblem)

	var brand := VBoxContainer.new()
	brand.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	brand.alignment = BoxContainer.ALIGNMENT_CENTER
	brand.add_theme_constant_override("separation", 0)
	var title := Label.new()
	title.text = "BOMBA LEITE"
	title.add_theme_font_size_override("font_size", 24)
	title.add_theme_color_override("font_color", WHITE)
	brand.add_child(title)
	var tagline := Label.new()
	tagline.text = "JOGUE  •  ASSISTA  •  CONECTE-SE"
	tagline.add_theme_font_size_override("font_size", 11)
	tagline.add_theme_color_override("font_color", CYAN)
	brand.add_child(tagline)
	row.add_child(brand)

	var search := LineEdit.new()
	search.placeholder_text = "⌕   Pesquisar..."
	search.custom_minimum_size = Vector2(240, 46)
	search.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	search.add_theme_font_size_override("font_size", 15)
	search.add_theme_color_override("font_color", WHITE)
	search.add_theme_color_override("font_placeholder_color", MUTED)
	search.add_theme_stylebox_override("normal", _panel_style(Color("#111c2b"), 22, BORDER))
	search.add_theme_stylebox_override("focus", _panel_style(Color("#111c2b"), 22, CYAN))
	row.add_child(search)

	var menu_btn := Button.new()
	menu_btn.text = "☰\nMENU"
	menu_btn.custom_minimum_size = Vector2(76, 60)
	menu_btn.add_theme_font_size_override("font_size", 15)
	menu_btn.add_theme_color_override("font_color", WHITE)
	menu_btn.add_theme_stylebox_override("normal", _panel_style(PANEL, 16, BORDER))
	menu_btn.add_theme_stylebox_override("hover", _panel_style(PANEL_HOVER, 16, CYAN))
	menu_btn.pressed.connect(_show_home)
	row.add_child(menu_btn)
	return row

func _build_sidebar() -> Control:
	var frame := PanelContainer.new()
	frame.custom_minimum_size.x = 116
	frame.add_theme_stylebox_override("panel", _panel_style(Color("#08111d"), 22, BORDER))
	var nav := VBoxContainer.new()
	nav.add_theme_constant_override("separation", 7)
	nav.add_theme_constant_override("margin_left", 8)
	nav.add_theme_constant_override("margin_right", 8)
	nav.add_theme_constant_override("margin_top", 10)
	nav.add_theme_constant_override("margin_bottom", 10)
	frame.add_child(nav)

	var home := _nav_button("⌂", "Início", -1)
	nav.add_child(home)
	for i in range(SECTIONS.size()):
		var data: Dictionary = SECTIONS[i]
		var b := _nav_button(str(data.icon), str(data.short), i)
		nav_buttons.append(b)
		nav.add_child(b)

	var exit_btn := _nav_button("⏻", "Sair", -2)
	exit_btn.pressed.connect(_on_sair_pressed)
	nav.add_child(exit_btn)
	return frame

func _nav_button(icon: String, caption: String, section_index: int) -> Button:
	var b := Button.new()
	b.text = icon + "\n" + caption
	b.custom_minimum_size = Vector2(94, 68)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.add_theme_font_size_override("font_size", 13)
	b.add_theme_color_override("font_color", WHITE)
	b.add_theme_stylebox_override("normal", _panel_style(PANEL, 15, BORDER))
	b.add_theme_stylebox_override("hover", _panel_style(PANEL_HOVER, 15, CYAN))
	b.add_theme_stylebox_override("pressed", _panel_style(Color("#0d3151"), 15, CYAN))
	if section_index == -1:
		b.pressed.connect(_show_home)
	elif section_index >= 0:
		b.pressed.connect(_open_section.bind(SECTIONS[section_index]))
	return b

func _build_footer() -> Control:
	var row := HBoxContainer.new()
	row.custom_minimum_size.y = 30
	var slogan := Label.new()
	slogan.text = "BOMBA LEITE     SEU MUNDO EM UM SÓ LUGAR!"
	slogan.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	slogan.add_theme_font_size_override("font_size", 13)
	slogan.add_theme_color_override("font_color", CYAN)
	row.add_child(slogan)
	return row

func _show_home() -> void:
	current_section = {}
	_clear_page()
	var intro := HBoxContainer.new()
	intro.custom_minimum_size.y = 52
	var heading := VBoxContainer.new()
	heading.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var h := Label.new()
	h.text = "Seu mundo, em um só lugar"
	h.add_theme_font_size_override("font_size", 23)
	h.add_theme_color_override("font_color", WHITE)
	heading.add_child(h)
	var sub := Label.new()
	sub.text = "Escolha uma categoria para começar"
	sub.add_theme_font_size_override("font_size", 13)
	sub.add_theme_color_override("font_color", MUTED)
	heading.add_child(sub)
	intro.add_child(heading)
	page_content.add_child(intro)

	var grid := GridContainer.new()
	grid.columns = 2
	grid.size_flags_vertical = Control.SIZE_EXPAND_FILL
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 10)
	page_content.add_child(grid)
	for data in SECTIONS:
		grid.add_child(_category_card(data))

	var play := Button.new()
	play.text = "▶   JOGAR BOMBE LITE"
	play.custom_minimum_size.y = 52
	play.add_theme_font_size_override("font_size", 18)
	play.add_theme_color_override("font_color", WHITE)
	play.add_theme_stylebox_override("normal", _panel_style(Color("#075d83"), 16, CYAN))
	play.add_theme_stylebox_override("hover", _panel_style(Color("#0879a8"), 16, Color("#7cecff")))
	play.pressed.connect(_start_game)
	page_content.add_child(play)
	_update_nav(-1)

func _category_card(data: Dictionary) -> Button:
	var b := Button.new()
	b.custom_minimum_size = Vector2(0, 84)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.add_theme_stylebox_override("normal", _panel_style(PANEL, 18, BORDER))
	b.add_theme_stylebox_override("hover", _panel_style(PANEL_HOVER, 18, data.color))
	b.add_theme_stylebox_override("pressed", _panel_style(Color("#0d3151"), 18, data.color))
	b.pressed.connect(_open_section.bind(data))

	var pad := MarginContainer.new()
	pad.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	pad.add_theme_constant_override("margin_left", 12)
	pad.add_theme_constant_override("margin_right", 12)
	pad.add_theme_constant_override("margin_top", 8)
	pad.add_theme_constant_override("margin_bottom", 8)
	pad.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(pad)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 13)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pad.add_child(row)

	var icon_panel := PanelContainer.new()
	icon_panel.custom_minimum_size = Vector2(58, 58)
	icon_panel.add_theme_stylebox_override("panel", _panel_style(data.color, 15, data.color))
	icon_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var icon := Label.new()
	icon.text = str(data.icon)
	icon.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	icon.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	icon.add_theme_font_size_override("font_size", 24)
	icon.add_theme_color_override("font_color", WHITE)
	icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	icon_panel.add_child(icon)
	row.add_child(icon_panel)

	var text_box := VBoxContainer.new()
	text_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	text_box.alignment = BoxContainer.ALIGNMENT_CENTER
	text_box.add_theme_constant_override("separation", 3)
	text_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var name := Label.new()
	name.text = str(data.name)
	name.add_theme_font_size_override("font_size", 16)
	name.add_theme_color_override("font_color", WHITE)
	name.mouse_filter = Control.MOUSE_FILTER_IGNORE
	text_box.add_child(name)
	var desc := Label.new()
	desc.text = str(data.description)
	desc.add_theme_font_size_override("font_size", 11)
	desc.add_theme_color_override("font_color", MUTED)
	desc.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	desc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	text_box.add_child(desc)
	row.add_child(text_box)

	var arrow := Label.new()
	arrow.text = "›"
	arrow.add_theme_font_size_override("font_size", 30)
	arrow.add_theme_color_override("font_color", WHITE)
	arrow.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	arrow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(arrow)
	return b

func _open_section(data: Dictionary) -> void:
	current_section = data
	_clear_page()
	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	page_content.add_child(spacer)

	var card := PanelContainer.new()
	card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	card.add_theme_stylebox_override("panel", _panel_style(PANEL, 24, data.color))
	page_content.add_child(card)
	var content := VBoxContainer.new()
	content.alignment = BoxContainer.ALIGNMENT_CENTER
	content.add_theme_constant_override("separation", 12)
	card.add_child(content)

	var icon := Label.new()
	icon.text = str(data.icon)
	icon.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	icon.add_theme_font_size_override("font_size", 40)
	content.add_child(icon)
	var title := Label.new()
	title.text = str(data.name)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 29)
	title.add_theme_color_override("font_color", WHITE)
	content.add_child(title)
	var desc := Label.new()
	desc.text = str(data.description)
	desc.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	desc.add_theme_font_size_override("font_size", 16)
	desc.add_theme_color_override("font_color", MUTED)
	content.add_child(desc)

	var item_list := Label.new()
	item_list.text = "  •  ".join(PackedStringArray(data.items))
	item_list.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	item_list.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	item_list.add_theme_font_size_override("font_size", 15)
	item_list.add_theme_color_override("font_color", CYAN)
	content.add_child(item_list)

	var note := Label.new()
	note.text = "Adicione seus ícones e destinos para ativar cada atalho."
	note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	note.add_theme_font_size_override("font_size", 12)
	note.add_theme_color_override("font_color", MUTED)
	content.add_child(note)

	var controls := HBoxContainer.new()
	controls.alignment = BoxContainer.ALIGNMENT_CENTER
	controls.add_theme_constant_override("separation", 12)
	content.add_child(controls)
	var back := _action_button("VOLTAR")
	back.pressed.connect(_on_voltar_pressed)
	controls.add_child(back)
	var home := _action_button("INÍCIO")
	home.pressed.connect(_on_inicio_pressed)
	controls.add_child(home)
	var quit := _action_button("SAIR")
	quit.pressed.connect(_on_sair_pressed)
	controls.add_child(quit)

	var bottom_space := Control.new()
	bottom_space.size_flags_vertical = Control.SIZE_EXPAND_FILL
	page_content.add_child(bottom_space)
	_update_nav(SECTIONS.find(data))

func _start_game() -> void:
	get_tree().change_scene_to_file("res://cenas/Jogo.tscn")

func _action_button(caption: String) -> Button:
	var b := Button.new()
	b.text = caption
	b.custom_minimum_size = Vector2(126, 44)
	b.add_theme_font_size_override("font_size", 14)
	b.add_theme_color_override("font_color", WHITE)
	b.add_theme_stylebox_override("normal", _panel_style(Color("#14273a"), 13, BORDER))
	b.add_theme_stylebox_override("hover", _panel_style(Color("#0d3151"), 13, CYAN))
	return b

func _clear_page() -> void:
	for child in page_content.get_children():
		page_content.remove_child(child)
		child.queue_free()

func _update_nav(active: int) -> void:
	for i in range(nav_buttons.size()):
		var b := nav_buttons[i]
		var style_color := Color("#0d3151") if i == active else PANEL
		var edge := CYAN if i == active else BORDER
		b.add_theme_stylebox_override("normal", _panel_style(style_color, 15, edge))

func _panel_style(fill: Color, radius: int, outline: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = fill
	style.border_color = outline
	style.set_border_width_all(1)
	style.set_corner_radius_all(radius)
	style.content_margin_left = 10
	style.content_margin_right = 10
	style.content_margin_top = 6
	style.content_margin_bottom = 6
	return style

# Botões VOLTAR e INÍCIO retornam ao menu principal.
func _on_voltar_pressed() -> void:
	_show_home()

func _on_inicio_pressed() -> void:
	_show_home()

# Botão SAIR fecha o aplicativo.
func _on_sair_pressed() -> void:
	get_tree().quit()

# Tecla voltar / gesto do Android (ui_cancel) retorna ao menu.
func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		if not current_section.is_empty():
			_show_home()
			get_viewport().set_input_as_handled()
