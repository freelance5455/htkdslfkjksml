extends Control

const BG := Color("#050a13")
const PANEL := Color("#08182a")
const BLUE := Color("#087cff")
const CYAN := Color("#00d5ff")
const MUTED := Color("#b5c6dc")

var _status: Label
var _device_status: Label
var _device_name_input: LineEdit
var _selected_device_name := ""

func _ready() -> void:
	_build_interface()
	_refresh_status()

func _build_interface() -> void:
	var background := ColorRect.new()
	background.color = BG
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(background)

	var scroll := ScrollContainer.new()
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(scroll)

	var margin := MarginContainer.new()
	margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin.add_theme_constant_override("margin_left", 20)
	margin.add_theme_constant_override("margin_right", 20)
	margin.add_theme_constant_override("margin_top", 12)
	margin.add_theme_constant_override("margin_bottom", 12)
	scroll.add_child(margin)

	var column := VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 10)
	margin.add_child(column)

	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 12)
	column.add_child(header)

	var back_top := _button("←", false)
	back_top.custom_minimum_size = Vector2(48, 46)
	back_top.pressed.connect(_go_home)
	header.add_child(back_top)

	var title_box := VBoxContainer.new()
	title_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_box.alignment = BoxContainer.ALIGNMENT_CENTER
	header.add_child(title_box)
	var title := Label.new()
	title.text = "BLUETOOTH"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 24)
	title.add_theme_color_override("font_color", Color.WHITE)
	title_box.add_child(title)
	var subtitle := Label.new()
	subtitle.text = "Conecte seus dispositivos"
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_font_size_override("font_size", 13)
	subtitle.add_theme_color_override("font_color", MUTED)
	title_box.add_child(subtitle)

	var settings := _button("⚙", false)
	settings.custom_minimum_size = Vector2(48, 46)
	settings.pressed.connect(_on_configuracoes_pressed)
	header.add_child(settings)

	var hero := TextureRect.new()
	hero.texture = load("res://bluetooth-hero.jpg")
	hero.custom_minimum_size = Vector2(0, 170)
	hero.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	hero.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	column.add_child(hero)

	var status_panel := PanelContainer.new()
	status_panel.add_theme_stylebox_override("panel", _panel_style(PANEL, BLUE))
	column.add_child(status_panel)
	var status_row := HBoxContainer.new()
	status_row.add_theme_constant_override("separation", 14)
	status_panel.add_child(status_row)
	var bluetooth_icon := Label.new()
	bluetooth_icon.text = "ᛒ"
	bluetooth_icon.add_theme_font_size_override("font_size", 38)
	bluetooth_icon.add_theme_color_override("font_color", BLUE)
	status_row.add_child(bluetooth_icon)
	var status_text := VBoxContainer.new()
	status_text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	status_text.alignment = BoxContainer.ALIGNMENT_CENTER
	status_row.add_child(status_text)
	_status = Label.new()
	_status.add_theme_font_size_override("font_size", 18)
	_status.add_theme_color_override("font_color", Color.WHITE)
	status_text.add_child(_status)
	var detail := Label.new()
	detail.text = "Ative e pareie dispositivos nas configurações do Android."
	detail.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	detail.add_theme_font_size_override("font_size", 13)
	detail.add_theme_color_override("font_color", MUTED)
	status_text.add_child(detail)

	var activate := _button("⏻    ATIVAR", true)
	activate.custom_minimum_size = Vector2(0, 58)
	activate.pressed.connect(_on_ativar_pressed)
	column.add_child(activate)

	var search := _button("ᛒ⌕    PROCURAR DISPOSITIVOS    ›", false)
	search.custom_minimum_size = Vector2(0, 56)
	search.pressed.connect(_on_procurar_dispositivos_pressed)
	column.add_child(search)

	var found_title := Label.new()
	found_title.text = "DISPOSITIVOS ENCONTRADOS"
	found_title.add_theme_font_size_override("font_size", 16)
	found_title.add_theme_color_override("font_color", CYAN)
	column.add_child(found_title)

	_device_name_input = LineEdit.new()
	_device_name_input.placeholder_text = "Nome do dispositivo encontrado"
	_device_name_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_child(_device_name_input)

	var device_actions := HBoxContainer.new()
	device_actions.add_theme_constant_override("separation", 10)
	column.add_child(device_actions)
	var pair_button := _button("🔗  PAREAR", true)
	pair_button.pressed.connect(_on_parear_pressed)
	device_actions.add_child(pair_button)
	var disconnect_button := _button("❌  DESCONECTAR", false)
	disconnect_button.pressed.connect(_on_desconectar_pressed)
	device_actions.add_child(disconnect_button)

	_device_status = Label.new()
	_device_status.text = "Use Procurar dispositivos; o Android pedirá a permissão necessária."
	_device_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_device_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_device_status.add_theme_font_size_override("font_size", 12)
	_device_status.add_theme_color_override("font_color", MUTED)
	column.add_child(_device_status)

	var footer := HBoxContainer.new()
	footer.add_theme_constant_override("separation", 12)
	column.add_child(footer)
	var home := _button("⌂    INÍCIO", false)
	home.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	home.custom_minimum_size = Vector2(0, 48)
	home.pressed.connect(_go_home)
	footer.add_child(home)
	var back := _button("↶    VOLTAR", false)
	back.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	back.custom_minimum_size = Vector2(0, 48)
	back.pressed.connect(_go_home)
	footer.add_child(back)

func _button(text: String, primary: bool) -> Button:
	var button := Button.new()
	button.text = text
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.add_theme_font_size_override("font_size", 16)
	button.add_theme_color_override("font_color", Color.WHITE)
	var normal_color := Color("#087cff") if primary else PANEL
	var border_color := Color("#35aaff") if primary else BLUE
	button.add_theme_stylebox_override("normal", _panel_style(normal_color, border_color))
	button.add_theme_stylebox_override("hover", _panel_style(Color("#12304f"), CYAN))
	button.add_theme_stylebox_override("pressed", _panel_style(Color("#0b3763"), CYAN))
	button.add_theme_stylebox_override("focus", _panel_style(Color("#12304f"), CYAN))
	return button

func _panel_style(fill: Color, border: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = fill
	style.border_color = border
	style.set_border_width_all(1)
	style.set_corner_radius_all(16)
	style.content_margin_left = 12
	style.content_margin_right = 12
	style.content_margin_top = 8
	style.content_margin_bottom = 8
	return style

func _refresh_status() -> void:
	if _status == null:
		return
	if OS.get_name() == "Android":
		_status.text = "Bluetooth do aparelho"
		_device_status.text = "Toque em procurar para abrir a tela oficial do Android."
	else:
		_status.text = "Disponível no Android"
		_device_status.text = "Abra o app Bombe Lite em um aparelho Android para usar o Bluetooth."

func _get_bluetooth_manager() -> Object:
	if Engine.has_singleton("BluetoothManager"):
		return Engine.get_singleton("BluetoothManager")
	if Engine.has_singleton("BluetoothPlugin"):
		return Engine.get_singleton("BluetoothPlugin")
	return null

func _call_manager_method(manager: Object, primary: String, alternate: String = "") -> bool:
	if manager == null:
		return false
	if manager.has_method(primary):
		manager.call(primary)
		return true
	if not alternate.is_empty() and manager.has_method(alternate):
		manager.call(alternate)
		return true
	return false

func procurar_bluetooth() -> void:
	_status.text = "Procurando dispositivos..."
	var bluetooth := _get_bluetooth_manager()
	if bluetooth == null:
		_device_status.text = "Plugin Bluetooth não instalado. Use Configurações Bluetooth para procurar manualmente."
		return
	if _call_manager_method(bluetooth, "start_scan", "startScan"):
		_device_status.text = "Busca iniciada. Permita o acesso a dispositivos próximos, se solicitado."
	else:
		_device_status.text = "O plugin Bluetooth não oferece start_scan."

func parear_dispositivo(nome: String) -> void:
	var nome_limpo := nome.strip_edges()
	if nome_limpo.is_empty():
		_device_status.text = "Digite ou selecione o nome de um dispositivo."
		return
	var bluetooth := _get_bluetooth_manager()
	if bluetooth == null:
		_device_status.text = "Plugin Bluetooth não instalado. Abra Configurações Bluetooth para parear."
		return
	if bluetooth.has_method("pair_device"):
		bluetooth.call("pair_device", nome_limpo)
	elif bluetooth.has_method("pairDevice"):
		bluetooth.call("pairDevice", nome_limpo)
	else:
		_device_status.text = "O plugin Bluetooth não oferece pair_device."
		return
	_selected_device_name = nome_limpo
	_device_status.text = "Confirme o pareamento na janela do Android."

func desconectar() -> void:
	var bluetooth := _get_bluetooth_manager()
	if bluetooth != null and _call_manager_method(bluetooth, "disconnect_device", "disconnectDevice"):
		_device_status.text = "Solicitação de desconexão enviada."
		return
	_device_status.text = "Para desconectar, selecione o aparelho nas Configurações Bluetooth do Android."
	_on_configuracoes_pressed()

func _on_ativar_pressed() -> void:
	var bluetooth := _get_bluetooth_manager()
	if bluetooth != null and _call_manager_method(bluetooth, "enable_bluetooth", "enableBluetooth"):
		_status.text = "Solicitação enviada ao Android"
		_device_status.text = "Confirme a ativação na janela do sistema."
		return
	_on_configuracoes_pressed()

func _on_procurar_dispositivos_pressed() -> void:
	procurar_bluetooth()

func _on_parear_pressed() -> void:
	parear_dispositivo(_device_name_input.text)

func _on_desconectar_pressed() -> void:
	desconectar()

func _on_configuracoes_pressed() -> void:
	var bluetooth := _get_bluetooth_manager()
	if bluetooth != null and _call_manager_method(bluetooth, "open_bluetooth_settings", "openBluetoothSettings"):
		return
	if OS.get_name() != "Android":
		_status.text = "Use um aparelho Android para gerenciar o Bluetooth."
		_device_status.text = "A busca, o pareamento e a desconexão são controlados pelo sistema Android."
		return
	var error := OS.shell_open("intent:#Intent;action=android.settings.BLUETOOTH_SETTINGS;end")
	if error != OK:
		_status.text = "Não foi possível abrir as configurações"
		_device_status.text = "Abra Bluetooth nas configurações do aparelho."
	else:
		_status.text = "Bluetooth nas configurações do Android"
		_device_status.text = "Gerencie a conexão e o pareamento na tela oficial do Android."

func _go_home() -> void:
	get_tree().change_scene_to_file("res://cenas/Menu.tscn")

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		get_viewport().set_input_as_handled()
		_go_home()
