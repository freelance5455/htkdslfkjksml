extends Control

const LOGO := preload("res://arte/logo_bombe_elite.png")

func _ready() -> void:
	var bg := ColorRect.new()
	bg.color = Color("#ecf3fd")
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var logo := TextureRect.new()
	logo.texture = LOGO
	logo.custom_minimum_size = Vector2(420, 400)
	logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	center.add_child(logo)
	await get_tree().create_timer(1.25).timeout
	if is_inside_tree():
		get_tree().change_scene_to_file("res://cenas/Menu.tscn")
