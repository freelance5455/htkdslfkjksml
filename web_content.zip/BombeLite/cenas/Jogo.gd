extends Node2D

const COLS := 11
const ROWS := 9
const TILE := 56
const BOARD_X := 172.0
const BOARD_Y := 108.0
const PLAYER_START := Vector2i(1, 1)
const ENEMY_STARTS := [Vector2i(9, 7), Vector2i(9, 1), Vector2i(1, 7)]

var walls: Dictionary = {}
var crates: Dictionary = {}
var bombs: Array[Dictionary] = []
var blasts: Array[Dictionary] = []
var enemies: Array[Vector2i] = []
var player := PLAYER_START
var game_state := "playing"
var enemy_clock := 0.0
var score := 0

func _ready() -> void:
	# Centraliza o tabuleiro 960×720 na tela horizontal de 1280×720.
	position.x = maxf(0.0, (get_viewport_rect().size.x - 960.0) / 2.0)
	_reset_game()
	set_process(true)

func _reset_game() -> void:
	walls.clear()
	crates.clear()
	bombs.clear()
	blasts.clear()
	enemies = ENEMY_STARTS.duplicate()
	player = PLAYER_START
	game_state = "playing"
	enemy_clock = 0.0
	score = 0
	for y in range(ROWS):
		for x in range(COLS):
			var cell := Vector2i(x, y)
			if x == 0 or y == 0 or x == COLS - 1 or y == ROWS - 1:
				walls[cell] = true
			elif x % 2 == 0 and y % 2 == 0:
				walls[cell] = true
				continue
			if _reserved(cell):
				continue
			if (x * 7 + y * 11) % 5 == 0 or (x * 3 + y * 2) % 11 == 0:
				crates[cell] = true
	queue_redraw()

func _reserved(cell: Vector2i) -> bool:
	if absi(cell.x - PLAYER_START.x) + absi(cell.y - PLAYER_START.y) <= 2:
		return true
	for spawn in ENEMY_STARTS:
		if absi(cell.x - spawn.x) + absi(cell.y - spawn.y) <= 1:
			return true
	return false

func _process(delta: float) -> void:
	if game_state == "playing":
		for i in range(bombs.size() - 1, -1, -1):
			bombs[i]["time"] = float(bombs[i]["time"]) - delta
			if float(bombs[i]["time"]) <= 0.0:
				_explode_bomb(i)
		enemy_clock += delta
		if enemy_clock >= 0.72:
			enemy_clock = 0.0
			_move_enemies()
	for i in range(blasts.size() - 1, -1, -1):
		blasts[i]["time"] = float(blasts[i]["time"]) - delta
		if float(blasts[i]["time"]) <= 0.0:
			blasts.remove_at(i)
	queue_redraw()

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		get_tree().change_scene_to_file("res://cenas/Menu.tscn")
		get_viewport().set_input_as_handled()
	elif event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_R and game_state != "playing":
			_reset_game()
		elif game_state == "playing":
			match event.keycode:
				KEY_UP, KEY_W: _move_player(Vector2i.UP)
				KEY_DOWN, KEY_S: _move_player(Vector2i.DOWN)
				KEY_LEFT, KEY_A: _move_player(Vector2i.LEFT)
				KEY_RIGHT, KEY_D: _move_player(Vector2i.RIGHT)
				KEY_SPACE, KEY_ENTER: _place_bomb()
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_handle_touch(to_local(event.position))
	elif event is InputEventScreenTouch and event.pressed:
		_handle_touch(to_local(event.position))

func _handle_touch(pos: Vector2) -> void:
	if game_state != "playing":
		if Rect2(340, 420, 280, 70).has_point(pos):
			_reset_game()
		return
	if Rect2(272, 616, 48, 42).has_point(pos): _move_player(Vector2i.UP)
	elif Rect2(272, 660, 48, 42).has_point(pos): _move_player(Vector2i.DOWN)
	elif Rect2(220, 660, 48, 42).has_point(pos): _move_player(Vector2i.LEFT)
	elif Rect2(324, 660, 48, 42).has_point(pos): _move_player(Vector2i.RIGHT)
	elif Rect2(700, 632, 150, 68).has_point(pos): _place_bomb()

func _move_player(direction: Vector2i) -> void:
	var target := player + direction
	if _blocked(target):
		return
	player = target
	if enemies.has(player):
		game_state = "lost"
		queue_redraw()

func _blocked(cell: Vector2i) -> bool:
	if walls.has(cell) or crates.has(cell):
		return true
	for bomb in bombs:
		if bomb["cell"] == cell:
			return true
	return false

func _place_bomb() -> void:
	for bomb in bombs:
		if bomb["cell"] == player:
			return
	bombs.append({"cell": player, "time": 1.35})
	queue_redraw()

func _explode_bomb(index: int) -> void:
	var bomb: Dictionary = bombs[index]
	bombs.remove_at(index)
	var origin: Vector2i = bomb["cell"]
	var hit_cells: Array[Vector2i] = [origin]
	var directions: Array[Vector2i] = [Vector2i.UP, Vector2i.DOWN, Vector2i.LEFT, Vector2i.RIGHT]
	for direction in directions:
		for step in range(1, 3):
			var cell := origin + direction * step
			if walls.has(cell):
				break
			hit_cells.append(cell)
			if crates.has(cell):
				crates.erase(cell)
				score += 10
				break
	blasts.append({"cells": hit_cells, "time": 0.30})
	if hit_cells.has(player):
		game_state = "lost"
	for enemy in enemies.duplicate():
		if hit_cells.has(enemy):
			enemies.erase(enemy)
			score += 100
	if enemies.is_empty() and game_state == "playing":
		game_state = "won"

func _move_enemies() -> void:
	for i in range(enemies.size()):
		var options: Array[Vector2i] = [Vector2i.UP, Vector2i.DOWN, Vector2i.LEFT, Vector2i.RIGHT]
		options.shuffle()
		for direction in options:
			var target := enemies[i] + direction
			if target == player:
				game_state = "lost"
				break
			if not _blocked(target) and not enemies.has(target):
				enemies[i] = target
				break

func _cell_rect(cell: Vector2i, inset: float = 2.0) -> Rect2:
	return Rect2(BOARD_X + cell.x * TILE + inset, BOARD_Y + cell.y * TILE + inset, TILE - inset * 2.0, TILE - inset * 2.0)

func _draw() -> void:
	draw_rect(Rect2(0, 0, 960, 720), Color("#101a2d"))
	draw_string(ThemeDB.fallback_font, Vector2(172, 47), "BOMBE LITE", HORIZONTAL_ALIGNMENT_LEFT, -1, 30, Color("#edf4ff"))
	draw_string(ThemeDB.fallback_font, Vector2(174, 78), "Derrote os 3 rivais com suas bombas", HORIZONTAL_ALIGNMENT_LEFT, -1, 17, Color("#b9c8df"))
	draw_string(ThemeDB.fallback_font, Vector2(650, 54), "Pontos: %d" % score, HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color("#f2b84b"))
	draw_rect(Rect2(BOARD_X - 5, BOARD_Y - 5, COLS * TILE + 10, ROWS * TILE + 10), Color("#314260"), true, 2.0)
	for y in range(ROWS):
		for x in range(COLS):
			var cell := Vector2i(x, y)
			draw_rect(_cell_rect(cell, 1), Color("#263650"))
			if walls.has(cell):
				draw_rect(_cell_rect(cell, 3), Color("#60728e"))
				draw_rect(Rect2(BOARD_X + x * TILE + 9, BOARD_Y + y * TILE + 9, TILE - 18, 8), Color("#8292aa"))
			elif crates.has(cell):
				draw_rect(_cell_rect(cell, 4), Color("#9a5e37"))
				draw_rect(Rect2(BOARD_X + x * TILE + 8, BOARD_Y + y * TILE + 8, TILE - 16, 7), Color("#c58451"))
	for blast in blasts:
		for cell in blast["cells"]:
			draw_rect(_cell_rect(cell, 5), Color(1.0, 0.60, 0.16, 0.85))
	for bomb in bombs:
		var cell: Vector2i = bomb["cell"]
		draw_circle(Vector2(BOARD_X + cell.x * TILE + TILE / 2.0, BOARD_Y + cell.y * TILE + TILE / 2.0), 18, Color("#151820"))
		draw_circle(Vector2(BOARD_X + cell.x * TILE + TILE / 2.0 - 5, BOARD_Y + cell.y * TILE + TILE / 2.0 - 6), 5, Color("#aab4c1"))
	for enemy in enemies:
		draw_circle(Vector2(BOARD_X + enemy.x * TILE + TILE / 2.0, BOARD_Y + enemy.y * TILE + TILE / 2.0), 18, Color("#e85d63"))
		draw_circle(Vector2(BOARD_X + enemy.x * TILE + TILE / 2.0 - 6, BOARD_Y + enemy.y * TILE + TILE / 2.0 - 4), 3, Color.WHITE)
		draw_circle(Vector2(BOARD_X + enemy.x * TILE + TILE / 2.0 + 6, BOARD_Y + enemy.y * TILE + TILE / 2.0 - 4), 3, Color.WHITE)
	draw_circle(Vector2(BOARD_X + player.x * TILE + TILE / 2.0, BOARD_Y + player.y * TILE + TILE / 2.0), 18, Color("#57d3a1"))
	draw_circle(Vector2(BOARD_X + player.x * TILE + TILE / 2.0 - 6, BOARD_Y + player.y * TILE + TILE / 2.0 - 4), 3, Color("#102a2a"))
	draw_circle(Vector2(BOARD_X + player.x * TILE + TILE / 2.0 + 6, BOARD_Y + player.y * TILE + TILE / 2.0 - 4), 3, Color("#102a2a"))
	_draw_touch_controls()
	if game_state != "playing":
		_draw_end_screen()

func _draw_touch_controls() -> void:
	_draw_control(Rect2(220, 660, 48, 42), "◀")
	_draw_control(Rect2(272, 616, 48, 42), "▲")
	_draw_control(Rect2(272, 660, 48, 42), "▼")
	_draw_control(Rect2(324, 660, 48, 42), "▶")
	_draw_control(Rect2(700, 632, 150, 68), "BOMBA")
	draw_string(ThemeDB.fallback_font, Vector2(390, 682), "Toque nos controles ou use WASD / setas e Espaço", HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color("#b9c8df"))

func _draw_control(rect: Rect2, label: String) -> void:
	draw_rect(rect, Color("#314260"), true, 10.0)
	draw_string(ThemeDB.fallback_font, rect.position + Vector2(11, 29), label, HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color("#edf4ff"))

func _draw_end_screen() -> void:
	draw_rect(Rect2(0, 0, 960, 720), Color(0.03, 0.06, 0.12, 0.78))
	var headline := "VOCÊ VENCEU!" if game_state == "won" else "FIM DE JOGO"
	var color := Color("#f2b84b") if game_state == "won" else Color("#ff7777")
	draw_string(ThemeDB.fallback_font, Vector2(345, 320), headline, HORIZONTAL_ALIGNMENT_LEFT, -1, 42, color)
	draw_string(ThemeDB.fallback_font, Vector2(356, 365), "Pontuação: %d" % score, HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color.WHITE)
	draw_rect(Rect2(340, 405, 280, 64), Color("#f2b84b"), true, 12.0)
	draw_string(ThemeDB.fallback_font, Vector2(405, 445), "JOGAR DE NOVO  (R)", HORIZONTAL_ALIGNMENT_LEFT, -1, 19, Color("#101a2d"))
	draw_string(ThemeDB.fallback_font, Vector2(385, 492), "ESC volta ao menu", HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color("#edf4ff"))
