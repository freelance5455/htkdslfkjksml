# Bombe Lite para Android Studio

Projeto Android nativo com uma interface HTML local dentro de um WebView, em orientação paisagem. O menu foi adaptado da imagem de referência enviada e usa o emblema Bombe Lite recortado dela.

## Abrir e executar
1. Abra a pasta `android/` no Android Studio.
2. Aguarde a sincronização do Gradle; use JDK 17 e Android SDK 35.
3. Conecte um Android ou inicie um emulador e pressione **Run**.

O HTML e o emblema carregados pelo app ficam em `app/src/main/assets/`. A cópia independente está em `../index.html` com `../bombe-logo.png`.

## Atalhos Android
Os botões chamam os intents nativos do Android, implementados em `MainActivity.kt`: Minecraft (`com.mojang.minecraftpe`), WhatsApp (`com.whatsapp`), Roblox (`com.roblox.client`), Free Fire (`com.dts.freefireth`), YouTube, Google e Play Store. Minecraft, Roblox e Free Fire abrem o jogo se já estiver instalado; se não, abrem a página oficial desse jogo na Play Store. Na categoria **Jogos**, **Baixar mais jogos** abre uma busca de jogos na loja. Se a Play Store não estiver disponível, o app tenta abrir a versão web.

A instalação sempre é confirmada pelo usuário na Play Store; o Bombe Lite não baixa nem instala jogos silenciosamente. Os demais apps mantêm seus atalhos existentes. Quando YouTube, Google, Gmail ou Play Store não está instalado, abre o site oficial. **Sites** e **Navegador** abrem Google no navegador padrão. **Configurações** abre as configurações do aparelho; **Conexões** abre a tela de conexões sem fio do Android (`ACTION_WIRELESS_SETTINGS`). **Bluetooth** abre uma tela própria, inicia descoberta após a permissão, mostra dispositivos encontrados e pareados e permite filtrar por fones, caixas de som e outros. Ao parear, o Android apresenta sua confirmação. **Desconectar** abre o painel do sistema, pois não há uma API pública Android genérica para desconectar qualquer perfil Bluetooth. O mini jogo Bombe Lite roda dentro do próprio app.

## Bluetooth e preferências visuais
A tela Bluetooth solicita a permissão **Dispositivos próximos** (Android 12+), inicia a busca e permite filtrar fones, caixas de som e outros aparelhos. Selecione um dispositivo e toque em **Parear** para abrir a confirmação do Android. Android 11 e anteriores podem pedir localização para a busca. A tela **Configurações do Bombe Lite** implementa os controles de notificações visuais, modo de exibição, transparência, reversão de cor e pesquisa. Eles alteram apenas a prévia dentro do Bombe Lite, não as configurações globais do Android. **Desconectar** encaminha para as configurações Bluetooth do Android, já que o Android não oferece uma API pública genérica para desconectar qualquer perfil.
