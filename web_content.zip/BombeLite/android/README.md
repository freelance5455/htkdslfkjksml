# Bombe Lite para Android Studio

Projeto Android nativo com uma interface HTML local dentro de um WebView, em orientação paisagem. O menu foi adaptado da imagem de referência enviada e usa o emblema Bombe Lite recortado dela.

## Abrir e executar
1. Abra a pasta `android/` no Android Studio.
2. Aguarde a sincronização do Gradle; use JDK 17 e Android SDK 35.
3. Conecte um Android ou inicie um emulador e pressione **Run**.

O HTML e o emblema carregados pelo app ficam em `app/src/main/assets/`. A cópia independente está em `../index.html` com `../bombe-logo.png`.

## Atalhos Android
Os botões chamam os intents nativos do Android, implementados em `MainActivity.kt`: Minecraft (`com.mojang.minecraftpe`), WhatsApp (`com.whatsapp`), Roblox (`com.roblox.client`), Free Fire (`com.dts.freefireth`), YouTube, Google e Play Store. Minecraft e Roblox tentam primeiro abrir o app instalado pelo pacote Android (equivalente ao `MAIN` + pacote do script Godot); como alternativa, tentam os links `minecraft://` e `roblox://`. Os demais apps mantêm seus atalhos existentes. Quando YouTube, Google, Gmail ou Play Store não está instalado, abre o site oficial. **Sites** e **Navegador** abrem Google no navegador padrão. Configurações abre as configurações do aparelho. O mini jogo Bombe Lite roda dentro do próprio app.

Os jogos e apps nativos precisam estar instalados no celular. Se Minecraft, WhatsApp, Roblox ou Free Fire não estiverem disponíveis, o Bombe Lite mostra um aviso; não instala apps por conta própria.
