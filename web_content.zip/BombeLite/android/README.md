# BombeLite HTML para Android Studio

Este é um projeto Android Studio mínimo que abre o HTML local dentro de um WebView em paisagem. A tela inicial é inspirada no visual de um Samsung A07/One UI.

## Abrir
1. Instale o Android Studio e o JDK 17.
2. Abra a pasta `android/` no Android Studio (não apenas o arquivo HTML).
3. Aguarde a sincronização Gradle e instale o Android SDK 35, se solicitado.
4. Conecte um celular Android ou inicie um emulador e pressione **Run**.

A página está em `app/src/main/assets/index.html`. Ela funciona sem internet e inclui status, tela inicial com ícones, gaveta de apps e o jogo Bombe Lite. A ação de voltar do Android retorna à tela inicial; nela, fecha o app.

O HTML independente também fica na raiz do projeto como `index.html`, para abrir/testar num navegador.
