package com.bombelite.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        window.statusBarColor = Color.rgb(5, 11, 20)
        window.navigationBarColor = Color.rgb(5, 11, 20)

        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(5, 11, 20))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(AndroidBridge(), "AndroidApp")
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun launchFromMenu(id: String) {
        when (id) {
            "whatsapp" -> launchPackage("com.whatsapp", "WhatsApp")
            "roblox" -> launchPackage(
                "com.roblox.client", "Roblox", storePackage = "com.roblox.client"
            )
            "freefire" -> launchPackage(
                "com.dts.freefireth", "Free Fire", storePackage = "com.dts.freefireth"
            )
            "minecraft" -> launchPackage(
                "com.mojang.minecraftpe", "Minecraft", storePackage = "com.mojang.minecraftpe"
            )
            "game_search" -> openPlayStoreSearch("jogos")
            "youtube" -> launchPackage(
                "com.google.android.youtube", "YouTube", "https://www.youtube.com"
            )
            "playstore" -> launchPackage(
                "com.android.vending", "Play Store", "https://play.google.com/store"
            )
            "google" -> launchPackage(
                "com.google.android.googlequicksearchbox", "Google", "https://www.google.com"
            )
            "gmail" -> launchPackage(
                "com.google.android.gm", "Gmail", "https://mail.google.com"
            )
            "sites", "browser" -> openWebPage("https://www.google.com")
            "settings" -> openSettings()
            "bluetooth" -> openBluetoothSettings()
            else -> Toast.makeText(this, "Atalho desconhecido.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launchPackage(
        packageName: String,
        appName: String,
        fallbackUrl: String? = null,
        fallbackScheme: String? = null,
        storePackage: String? = null
    ) {
        try {
            val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                startActivity(launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            }
        } catch (_: ActivityNotFoundException) {
            // O pacote pode ter sido removido depois da leitura do menu.
        } catch (_: SecurityException) {
            // Tenta a alternativa web, quando houver.
        }

        if (storePackage != null) {
            openPlayStoreDetails(storePackage)
        } else if (fallbackUrl != null) {
            openWebPage(fallbackUrl)
        } else if (fallbackScheme != null) {
            openDeepLink(fallbackScheme, appName)
        } else {
            Toast.makeText(this, "$appName não está instalado.", Toast.LENGTH_LONG).show()
        }
    }

    private fun openPlayStoreDetails(packageId: String) {
        val marketUri = Uri.parse("market://details?id=$packageId")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, marketUri))
        } catch (_: ActivityNotFoundException) {
            openWebPage("https://play.google.com/store/apps/details?id=$packageId")
        } catch (_: SecurityException) {
            openWebPage("https://play.google.com/store/apps/details?id=$packageId")
        }
    }

    private fun openPlayStoreSearch(query: String) {
        val encodedQuery = Uri.encode(query)
        val marketUri = Uri.parse("market://search?q=$encodedQuery&c=apps")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, marketUri))
        } catch (_: ActivityNotFoundException) {
            openWebPage("https://play.google.com/store/search?q=$encodedQuery&c=apps")
        } catch (_: SecurityException) {
            openWebPage("https://play.google.com/store/search?q=$encodedQuery&c=apps")
        }
    }

    private fun openDeepLink(uri: String, appName: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "$appName não está disponível neste aparelho.", Toast.LENGTH_LONG).show()
        } catch (_: SecurityException) {
            Toast.makeText(this, "Não foi possível abrir $appName.", Toast.LENGTH_LONG).show()
        }
    }

    private fun openWebPage(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Nenhum navegador está disponível.", Toast.LENGTH_LONG).show()
        }
    }

    private fun openSettings() {
        try {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Não foi possível abrir as configurações.", Toast.LENGTH_LONG).show()
        }
    }

    private fun openBluetoothSettings() {
        try {
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        } catch (_: ActivityNotFoundException) {
            openSettings()
        } catch (_: SecurityException) {
            openSettings()
        }
    }

    @Deprecated("Use the in-page navigation for the Android back action")
    override fun onBackPressed() {
        if (::webView.isInitialized) {
            webView.evaluateJavascript("window.handleAndroidBack && window.handleAndroidBack();", null)
        } else {
            super.onBackPressed()
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun openApp(id: String) {
            runOnUiThread { launchFromMenu(id) }
        }

        @JavascriptInterface
        fun searchPlayStore(query: String) {
            runOnUiThread { openPlayStoreSearch(query) }
        }

        @JavascriptInterface
        fun exitApp() {
            runOnUiThread { finish() }
        }
    }
}
