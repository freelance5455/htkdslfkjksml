# Ponto de entrada principal do BombeLite.
# Herda o menu, incluindo VOLTAR, INÍCIO, SAIR e o retorno do Android.
extends "res://BombeLiteMenu.gd"
