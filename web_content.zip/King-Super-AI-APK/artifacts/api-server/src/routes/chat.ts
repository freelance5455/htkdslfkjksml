import { Router, type IRouter } from "express";
import {
  CreateChatCompletionBody,
  CreateChatCompletionResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();
const GEMINI_URL =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent";
const MAX_TOTAL_IMAGE_CHARS = 5_500_000;
const SYSTEM_PROMPT = [
  "You are YT.AI, a helpful assistant for people in Tunisia.",
  "Reply in the language the user uses. When they write in Tunisian Arabic, answer naturally in Tunisian Arabic; also support Modern Standard Arabic, French, and English.",
  "Help with writing, messages, summaries, programming, and questions about attached images.",
  "Be clear and accurate. If you cannot determine something from an image, say so. Never claim to have seen an image unless one was attached.",
].join(" ");

router.post("/chat/completions", async (req, res): Promise<void> => {
  const parsed = CreateChatCompletionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({
      error: "The message could not be sent. Check its length and try again.",
    });
    return;
  }

  const { messages } = parsed.data;
  const lastMessage = messages[messages.length - 1];
  if (
    !lastMessage ||
    lastMessage.role !== "user" ||
    (!lastMessage.content.trim() && !lastMessage.imageDataUrl)
  ) {
    res.status(400).json({
      error: "Add a message or image before sending.",
    });
    return;
  }

  let totalImageChars = 0;
  const contents = [];

  for (const message of messages) {
    if (!message.content.trim() && !message.imageDataUrl) {
      res.status(400).json({ error: "Messages cannot be empty." });
      return;
    }

    const parts: Array<
      | { text: string }
      | { inlineData: { mimeType: string; data: string } }
    > = [];

    if (message.content.trim()) {
      parts.push({ text: message.content });
    }

    if (message.imageDataUrl) {
      if (message.role !== "user") {
        res
          .status(400)
          .json({ error: "Images can only be attached to your messages." });
        return;
      }

      const match = message.imageDataUrl.match(
        /^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/,
      );
      if (!match) {
        res.status(400).json({
          error: "Use a PNG, JPEG, or WebP image and try again.",
        });
        return;
      }

      totalImageChars += message.imageDataUrl.length;
      parts.push({
        inlineData: {
          mimeType: `image/${match[1]}`,
          data: match[2],
        },
      });
    }

    contents.push({
      role: message.role === "assistant" ? "model" : "user",
      parts,
    });
  }

  if (totalImageChars > MAX_TOTAL_IMAGE_CHARS) {
    res.status(413).json({
      error:
        "Those images are too large to send together. Start a new chat or remove an older image.",
    });
    return;
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    res.status(503).json({
      error: "Gemini is not configured. Add GEMINI_API_KEY to Replit Secrets.",
    });
    return;
  }

  try {
    const providerResponse = await fetch(GEMINI_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": apiKey,
      },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
        contents,
        generationConfig: { maxOutputTokens: 8192 },
      }),
      signal: AbortSignal.timeout(60_000),
    });

    const payload = (await providerResponse.json().catch(() => null)) as
      | {
          candidates?: Array<{
            content?: { parts?: Array<{ text?: unknown }> };
          }>;
          modelVersion?: unknown;
        }
      | null;

    if (!providerResponse.ok) {
      req.log.warn(
        { providerStatus: providerResponse.status },
        "Gemini chat request failed",
      );

      if (providerResponse.status === 429) {
        res.status(429).json({
          error:
            "The Gemini free-tier limit is busy or reached. Wait a little and try again.",
        });
        return;
      }
      if (providerResponse.status === 401 || providerResponse.status === 403) {
        res.status(502).json({
          error:
            "Gemini could not authorize this request. Check the server's Gemini key and free-tier access.",
        });
        return;
      }
      if (providerResponse.status === 400 || providerResponse.status === 413) {
        res.status(502).json({
          error:
            "Gemini could not process that request. Try a shorter message or a smaller image.",
        });
        return;
      }

      res.status(502).json({
        error: "Gemini could not complete the request. Please try again shortly.",
      });
      return;
    }

    const assistantMessage = (payload?.candidates?.[0]?.content?.parts ?? [])
      .map((part) => (typeof part.text === "string" ? part.text : ""))
      .join("")
      .trim();

    if (!assistantMessage) {
      req.log.warn("Gemini returned an empty assistant message");
      res.status(502).json({
        error: "The AI returned an empty reply. Please try again.",
      });
      return;
    }

    res.json(
      CreateChatCompletionResponse.parse({
        message: assistantMessage,
        model:
          typeof payload?.modelVersion === "string"
            ? payload.modelVersion
            : "gemini-2.5-flash",
      }),
    );
  } catch (error) {
    const timedOut = error instanceof Error && error.name === "TimeoutError";
    req.log.warn({ timedOut }, "Gemini chat request did not complete");

    if (timedOut) {
      res.status(504).json({
        error: "The AI is taking too long to respond. Please try again.",
      });
      return;
    }

    res.status(502).json({
      error: "Could not reach Gemini. Check your connection and try again.",
    });
  }
});

export default router;
