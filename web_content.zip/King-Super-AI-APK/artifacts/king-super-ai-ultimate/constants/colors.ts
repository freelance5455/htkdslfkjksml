/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    text: '#0a0a0a',
    tint: '#b58a20',
    background: '#fbf8ef',
    foreground: '#1c190f',
    card: '#f4eedc',
    cardForeground: '#1c190f',
    primary: '#b58a20',
    primaryForeground: '#0b0904',
    secondary: '#eee6cf',
    secondaryForeground: '#1c190f',
    muted: '#eee8d9',
    mutedForeground: '#736748',
    accent: '#f5e9bf',
    accentForeground: '#604915',
    destructive: '#b4232b',
    destructiveForeground: '#ffffff',
    border: '#d9c98b',
    input: '#fffdf8',
    goldLight: '#f0d878',
    goldDeep: '#a77b16',
  },
  dark: {
    text: '#f5f2e8',
    tint: '#d4af37',
    background: '#050505',
    foreground: '#f5f2e8',
    card: '#10100e',
    cardForeground: '#f5f2e8',
    primary: '#d4af37',
    primaryForeground: '#080704',
    secondary: '#1a1915',
    secondaryForeground: '#f5f2e8',
    muted: '#171613',
    mutedForeground: '#aaa69a',
    accent: '#272111',
    accentForeground: '#e6c75e',
    destructive: '#d75f62',
    destructiveForeground: '#ffffff',
    border: '#332d1a',
    input: '#11110f',
    goldLight: '#f0d878',
    goldDeep: '#a77b16',
  },

  radius: 14,
};

export default colors;
