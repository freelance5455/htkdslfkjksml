export type Language = "ar" | "en" | "fr";

export type Suggestion = {
  title: string;
  subtitle: string;
  prompt: string;
};

export type ChatStrings = {
  appDescriptor: string;
  personalAssistant: string;
  ready: string;
  checking: string;
  offline: string;
  menu: string;
  close: string;
  newChat: string;
  conversations: string;
  emptyHistory: string;
  clearAll: string;
  clearConfirmTitle: string;
  clearConfirmMessage: string;
  cancel: string;
  clearAction: string;
  deleteChat: string;
  language: string;
  themeDark: string;
  themeLight: string;
  welcomeTitle: string;
  welcomeBody: string;
  suggestions: Suggestion[];
  placeholder: string;
  send: string;
  attachImage: string;
  askAboutImage: string;
  preparingImage: string;
  imageReady: string;
  removeImage: string;
  imageTooLarge: string;
  imageReadError: string;
  imagePermission: string;
  imagePermissionSettings: string;
  storageError: string;
  storageSaveError: string;
  userAvatar: string;
  assistantAvatar: string;
  generating: string;
  connectionErrorTitle: string;
  genericError: string;
  retry: string;
  disclaimer: string;
};

const strings: Record<Language, ChatStrings> = {
  ar: {
    appDescriptor: "مساعدك الذكي، بالتونسي",
    personalAssistant: "مساعدك الشخصي",
    ready: "جاهز يسمعك",
    checking: "نتأكّد من الاتصال…",
    offline: "الاتصال غير متاح",
    menu: "القائمة",
    close: "إغلاق",
    newChat: "محادثة جديدة",
    conversations: "محادثاتك",
    emptyHistory: "محادثاتك الجديدة تلقاهم لهنا",
    clearAll: "مسح كل المحادثات",
    clearConfirmTitle: "تمسح المحادثات الكل؟",
    clearConfirmMessage: "باش تتمسح من جهازك وما عادش تنجم ترجعهم.",
    cancel: "إلغاء",
    clearAction: "إي، امسح الكل",
    deleteChat: "حذف المحادثة",
    language: "اللغة",
    themeDark: "الوضع الداكن",
    themeLight: "الوضع الفاتح",
    welcomeTitle: "أهلا بيك، شنوّة نعاونك؟",
    welcomeBody:
      "اكتبلي بالتونسي ولا بالعربي، ونعاونك في الكتابة، التلخيص، البرمجة وحتى فهم الصور.",
    suggestions: [
      { title: "عاونّي نكتب موضوع", subtitle: "مقال، رسالة ولا فكرة", prompt: "عاونّي نكتب موضوع على " },
      { title: "اكتبلي مساج بالتونسي", subtitle: "باللهجة اللي تحب عليها", prompt: "اكتبلي مساج بالتونسي على " },
      { title: "فسّرلي حاجة ببساطة", subtitle: "ملخّص ولا سؤال عام", prompt: "فسّرلي ببساطة " },
      { title: "عاونّي في البرمجة", subtitle: "نحلّوا المشكلة خطوة بخطوة", prompt: "عندي سؤال في البرمجة: " },
    ],
    placeholder: "اكتب سؤالك بالتونسي ولا بالعربي…",
    send: "إرسال الرسالة",
    attachImage: "إرفاق صورة",
    askAboutImage: "تنجم تسأل على صورة",
    preparingImage: "جاري تجهيز الصورة…",
    imageReady: "الصورة جاهزة للسؤال",
    removeImage: "إزالة الصورة",
    imageTooLarge: "حجم الصورة كبير. جرّب صورة أصغر.",
    imageReadError: "ما نجّمش نقرى الصورة. جرّب صورة أخرى.",
    imagePermission: "اسمح للتطبيق بالوصول إلى الصور لاختيار صورة.",
    imagePermissionSettings: "افتح إعدادات الهاتف واسمح بالوصول إلى الصور.",
    storageError: "تعذّر قراءة المحادثات المحفوظة.",
    storageSaveError: "تعذّر حفظ المحادثات على هذا الجهاز.",
    userAvatar: "أنت",
    assistantAvatar: "YT",
    generating: "المساعد يكتب",
    connectionErrorTitle: "ما نجّمش نكمّل توا",
    genericError: "تعذّر الاتصال بالمساعد. تحقق من اتصالك وحاول مرة أخرى.",
    retry: "إعادة المحاولة",
    disclaimer: "YT.AI ينجم يغلط أحيانًا — راجع المعلومات المهمّة.",
  },
  en: {
    appDescriptor: "Your smart assistant, in Tunisian Arabic",
    personalAssistant: "Your personal assistant",
    ready: "Ready when you are",
    checking: "Checking connection…",
    offline: "Connection unavailable",
    menu: "Menu",
    close: "Close",
    newChat: "New chat",
    conversations: "Your chats",
    emptyHistory: "New conversations will appear here",
    clearAll: "Clear all chats",
    clearConfirmTitle: "Clear all conversations?",
    clearConfirmMessage: "They will be removed from this device and cannot be restored.",
    cancel: "Cancel",
    clearAction: "Clear all",
    deleteChat: "Delete conversation",
    language: "Language",
    themeDark: "Dark appearance",
    themeLight: "Light appearance",
    welcomeTitle: "Welcome. How can I help?",
    welcomeBody:
      "Ask in Tunisian Arabic, Arabic, English, or French. Get help with writing, summaries, programming, and images.",
    suggestions: [
      { title: "Help me write", subtitle: "An essay, message, or idea", prompt: "Help me write about " },
      { title: "Write a message", subtitle: "Choose the tone you want", prompt: "Write a message about " },
      { title: "Explain something", subtitle: "A simple summary or answer", prompt: "Explain this simply: " },
      { title: "Help with coding", subtitle: "Solve it step by step", prompt: "I have a coding question: " },
    ],
    placeholder: "Write your question…",
    send: "Send message",
    attachImage: "Attach an image",
    askAboutImage: "Ask a question about an image",
    preparingImage: "Preparing image…",
    imageReady: "Image ready to send",
    removeImage: "Remove image",
    imageTooLarge: "This image is too large. Try a smaller one.",
    imageReadError: "Could not read this image. Try another one.",
    imagePermission: "Allow photo access to choose an image.",
    imagePermissionSettings: "Open your phone settings and allow photo access.",
    storageError: "Could not read saved conversations.",
    storageSaveError: "Could not save conversations on this device.",
    userAvatar: "You",
    assistantAvatar: "YT",
    generating: "The assistant is typing",
    connectionErrorTitle: "The reply could not be completed",
    genericError: "Could not reach the assistant. Check your connection and try again.",
    retry: "Try again",
    disclaimer: "YT.AI can make mistakes. Check important information.",
  },
  fr: {
    appDescriptor: "Votre assistant intelligent, en tunisien",
    personalAssistant: "Votre assistant personnel",
    ready: "À votre écoute",
    checking: "Vérification de la connexion…",
    offline: "Connexion indisponible",
    menu: "Menu",
    close: "Fermer",
    newChat: "Nouvelle conversation",
    conversations: "Vos conversations",
    emptyHistory: "Vos nouvelles conversations apparaîtront ici",
    clearAll: "Effacer toutes les conversations",
    clearConfirmTitle: "Effacer toutes les conversations ?",
    clearConfirmMessage: "Elles seront supprimées de cet appareil et ne pourront pas être restaurées.",
    cancel: "Annuler",
    clearAction: "Tout effacer",
    deleteChat: "Supprimer la conversation",
    language: "Langue",
    themeDark: "Mode sombre",
    themeLight: "Mode clair",
    welcomeTitle: "Bienvenue. Comment puis-je vous aider ?",
    welcomeBody:
      "Écrivez en tunisien, en arabe, en anglais ou en français. Aide à la rédaction, aux résumés, au code et aux images.",
    suggestions: [
      { title: "Aidez-moi à écrire", subtitle: "Un texte, un message ou une idée", prompt: "Aidez-moi à écrire sur " },
      { title: "Rédiger un message", subtitle: "Choisissez le ton souhaité", prompt: "Rédigez un message sur " },
      { title: "Expliquer simplement", subtitle: "Un résumé ou une réponse", prompt: "Expliquez simplement : " },
      { title: "Aide au code", subtitle: "Résolvons le problème ensemble", prompt: "J’ai une question sur le code : " },
    ],
    placeholder: "Écrivez votre question…",
    send: "Envoyer le message",
    attachImage: "Joindre une image",
    askAboutImage: "Poser une question sur une image",
    preparingImage: "Préparation de l’image…",
    imageReady: "Image prête à être envoyée",
    removeImage: "Retirer l’image",
    imageTooLarge: "Cette image est trop volumineuse. Essayez-en une plus petite.",
    imageReadError: "Impossible de lire cette image. Essayez-en une autre.",
    imagePermission: "Autorisez l’accès aux photos pour choisir une image.",
    imagePermissionSettings: "Ouvrez les réglages du téléphone et autorisez l’accès aux photos.",
    storageError: "Impossible de lire les conversations enregistrées.",
    storageSaveError: "Impossible d’enregistrer les conversations sur cet appareil.",
    userAvatar: "Vous",
    assistantAvatar: "YT",
    generating: "L’assistant écrit",
    connectionErrorTitle: "La réponse n’a pas pu être terminée",
    genericError: "Impossible de joindre l’assistant. Vérifiez votre connexion et réessayez.",
    retry: "Réessayer",
    disclaimer: "YT.AI peut se tromper. Vérifiez les informations importantes.",
  },
};

export function getChatStrings(language: Language): ChatStrings {
  return strings[language];
}
