import AsyncStorage from "@react-native-async-storage/async-storage";
import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as ImageManipulator from "expo-image-manipulator";
import * as ImagePicker from "expo-image-picker";
import { LinearGradient } from "expo-linear-gradient";
import { StatusBar } from "expo-status-bar";
import {
  useCreateChatCompletion,
  useHealthCheck,
} from "@workspace/api-client-react";
import { useColors } from "@/hooks/useColors";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Image,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  useWindowDimensions,
  View,
} from "react-native";
import { KeyboardAvoidingView } from "react-native-keyboard-controller";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  getChatStrings,
  type ChatStrings,
  type Language,
  type Suggestion,
} from "@/constants/translations";

type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
  imageDataUrl?: string;
};

type Conversation = {
  id: string;
  messages: ChatMessage[];
  updatedAt: number;
};

type Palette = ReturnType<typeof useColors>;

const HISTORY_KEY = "king-ai-conversations-v1";
const LANGUAGE_KEY = "king-ai-language";
const THEME_KEY = "king-ai-theme";
const MAX_IMAGE_CHARS = 5_500_000;

function makeId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

function getTitle(conversation: Conversation, fallback: string): string {
  const firstUserMessage = conversation.messages.find(
    (message) => message.role === "user",
  );
  const title = firstUserMessage?.content.trim() || fallback;
  return title.length > 34 ? `${title.slice(0, 34)}…` : title;
}

function getErrorMessage(error: unknown, fallback: string): string {
  if (error && typeof error === "object") {
    const data = "data" in error ? error.data : undefined;
    if (data && typeof data === "object" && "error" in data && typeof data.error === "string") {
      return data.error;
    }
    if ("message" in error && typeof error.message === "string") {
      return error.message;
    }
  }
  return fallback;
}

function getValidConversations(value: unknown): Conversation[] {
  if (!Array.isArray(value)) return [];
  return value.filter(
    (item): item is Conversation =>
      !!item &&
      typeof item === "object" &&
      typeof item.id === "string" &&
      Array.isArray(item.messages) &&
      typeof item.updatedAt === "number",
  );
}

function tap(): void {
  if (Platform.OS !== "web") {
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
  }
}

function createStyles(palette: Palette) {
  return StyleSheet.create({
    screen: { flex: 1, backgroundColor: palette.background },
    topbar: {
      minHeight: 66,
      paddingHorizontal: 16,
      paddingVertical: 10,
      borderBottomWidth: StyleSheet.hairlineWidth,
      borderBottomColor: palette.border,
      alignItems: "center",
      justifyContent: "space-between",
      backgroundColor: palette.background,
    },
    topbarStart: { alignItems: "center", gap: 11 },
    brand: { alignItems: "center", gap: 10 },
    brandMark: {
      width: 42,
      height: 42,
      borderRadius: 15,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: palette.card,
      borderWidth: 1,
      borderColor: palette.border,
    },
    brandText: { color: palette.primary, fontSize: 13, fontWeight: "800", letterSpacing: 1.2 },
    brandSub: { color: palette.mutedForeground, fontSize: 10, marginTop: 2 },
    iconButton: {
      width: 42,
      height: 42,
      alignItems: "center",
      justifyContent: "center",
      borderWidth: 1,
      borderColor: palette.border,
      borderRadius: 14,
      backgroundColor: palette.card,
    },
    connection: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: 2 },
    connectionDot: { width: 7, height: 7, borderRadius: 4 },
    connectionText: { color: palette.mutedForeground, fontSize: 10 },
    keyboardArea: { flex: 1 },
    conversationArea: { flex: 1, paddingHorizontal: 14 },
    welcomeScroll: { flexGrow: 1, justifyContent: "center", paddingVertical: 20 },
    welcome: { alignItems: "center", paddingHorizontal: 7 },
    welcomeEmblem: {
      width: 68,
      height: 68,
      borderRadius: 24,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: palette.card,
      borderWidth: 1,
      borderColor: palette.border,
      marginBottom: 19,
    },
    welcomeTitle: {
      color: palette.primary,
      fontSize: 27,
      lineHeight: 37,
      fontWeight: "800",
      textAlign: "center",
      marginBottom: 7,
    },
    welcomeBody: {
      color: palette.mutedForeground,
      fontSize: 13,
      lineHeight: 22,
      textAlign: "center",
      maxWidth: 340,
      marginBottom: 20,
    },
    suggestions: {
      width: "100%",
      maxWidth: 440,
      flexDirection: "row",
      flexWrap: "wrap",
      justifyContent: "center",
      gap: 9,
    },
    suggestion: {
      width: "48%",
      minHeight: 68,
      paddingHorizontal: 10,
      paddingVertical: 10,
      flexDirection: "row",
      alignItems: "center",
      gap: 9,
      backgroundColor: palette.card,
      borderWidth: 1,
      borderColor: palette.border,
      borderRadius: 15,
    },
    suggestionIcon: {
      width: 32,
      height: 32,
      borderRadius: 11,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: palette.accent,
    },
    suggestionTextWrap: { flex: 1, minWidth: 0 },
    suggestionTitle: { color: palette.foreground, fontSize: 11, fontWeight: "700", lineHeight: 16 },
    suggestionSub: { color: palette.mutedForeground, fontSize: 9, marginTop: 3, lineHeight: 13 },
    messageList: { flexGrow: 1, paddingTop: 18, paddingBottom: 20, gap: 13 },
    messageRow: { maxWidth: "94%", alignItems: "flex-end", gap: 8 },
    messageAvatar: {
      width: 29,
      height: 29,
      borderRadius: 11,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: palette.primary,
    },
    userAvatar: { backgroundColor: palette.secondary, borderWidth: 1, borderColor: palette.border },
    avatarText: { color: palette.primaryForeground, fontSize: 9, fontWeight: "800" },
    userAvatarText: { color: palette.foreground },
    messageBubble: {
      maxWidth: "88%",
      borderRadius: 16,
      borderWidth: 1,
      borderColor: palette.border,
      paddingHorizontal: 14,
      paddingVertical: 10,
      backgroundColor: palette.card,
    },
    userBubble: { borderColor: palette.accentForeground, backgroundColor: palette.secondary },
    assistantBubble: { borderStartWidth: 2, borderStartColor: palette.primary },
    messageText: { color: palette.foreground, fontSize: 14, lineHeight: 22 },
    messageImage: {
      width: 218,
      height: 170,
      borderRadius: 12,
      marginBottom: 7,
      backgroundColor: palette.secondary,
    },
    typingBubble: { flexDirection: "row", alignItems: "center", gap: 9, padding: 12 },
    errorBox: {
      marginHorizontal: 12,
      marginBottom: 8,
      padding: 12,
      borderWidth: 1,
      borderColor: palette.destructive,
      borderRadius: 13,
      backgroundColor: palette.card,
    },
    errorTitle: { color: palette.destructive, fontSize: 12, fontWeight: "700", marginBottom: 3 },
    errorText: { color: palette.foreground, fontSize: 12, lineHeight: 18 },
    retryButton: { alignSelf: "flex-start", marginTop: 8, paddingVertical: 4 },
    retryText: { color: palette.primary, fontSize: 12, fontWeight: "700" },
    composerWrap: { paddingHorizontal: 12, paddingTop: 8 },
    composer: {
      borderWidth: 1,
      borderColor: palette.primary,
      borderRadius: 20,
      paddingHorizontal: 12,
      paddingTop: 9,
      paddingBottom: 8,
      backgroundColor: palette.input,
    },
    attachmentPreview: {
      flexDirection: "row",
      alignItems: "center",
      gap: 9,
      paddingBottom: 8,
    },
    attachmentImage: { width: 42, height: 42, borderRadius: 9 },
    attachmentText: { flex: 1, color: palette.mutedForeground, fontSize: 11 },
    textInput: {
      minHeight: 44,
      maxHeight: 132,
      color: palette.foreground,
      fontSize: 14,
      lineHeight: 21,
      paddingHorizontal: 3,
      paddingVertical: 7,
    },
    composerTools: {
      minHeight: 39,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 10,
    },
    attachGroup: { flexDirection: "row", alignItems: "center", gap: 6, flex: 1 },
    attachHint: { color: palette.mutedForeground, fontSize: 10, flexShrink: 1 },
    sendButton: {
      width: 40,
      height: 40,
      borderRadius: 14,
      alignItems: "center",
      justifyContent: "center",
    },
    sendDisabled: { opacity: 0.4 },
    disclaimer: {
      color: palette.mutedForeground,
      textAlign: "center",
      fontSize: 9,
      lineHeight: 15,
      paddingHorizontal: 12,
      paddingTop: 8,
      paddingBottom: 9,
    },
    modalBackdrop: {
      flex: 1,
      justifyContent: "flex-end",
      backgroundColor: "rgba(0,0,0,0.62)",
    },
    modalDismiss: { ...StyleSheet.absoluteFillObject },
    sheet: {
      maxHeight: "86%",
      minHeight: "56%",
      borderTopLeftRadius: 25,
      borderTopRightRadius: 25,
      paddingHorizontal: 18,
      paddingTop: 12,
      borderWidth: 1,
      borderColor: palette.border,
      backgroundColor: palette.background,
    },
    sheetHandle: {
      width: 38,
      height: 4,
      alignSelf: "center",
      borderRadius: 4,
      backgroundColor: palette.mutedForeground,
      opacity: 0.5,
      marginBottom: 13,
    },
    sheetHeading: { color: palette.foreground, fontSize: 17, fontWeight: "800" },
    sheetSubheading: { color: palette.mutedForeground, fontSize: 11, marginTop: 3 },
    sheetHeader: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      paddingBottom: 14,
    },
    sheetSectionTitle: {
      color: palette.mutedForeground,
      fontSize: 11,
      fontWeight: "700",
      marginTop: 15,
      marginBottom: 8,
    },
    newChatSheet: {
      minHeight: 46,
      borderRadius: 13,
      overflow: "hidden",
      alignItems: "center",
      justifyContent: "center",
      flexDirection: "row",
      gap: 8,
    },
    newChatSheetText: { color: palette.primaryForeground, fontSize: 13, fontWeight: "800" },
    historyList: { flexGrow: 0, maxHeight: 190 },
    historyRow: {
      minHeight: 48,
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      paddingHorizontal: 10,
      borderRadius: 11,
      backgroundColor: palette.card,
      marginBottom: 6,
    },
    historyTitle: { color: palette.foreground, fontSize: 12, flex: 1 },
    emptyHistory: { color: palette.mutedForeground, fontSize: 12, textAlign: "center", padding: 14 },
    languageRow: { flexDirection: "row", gap: 8 },
    languageButton: {
      flex: 1,
      minHeight: 39,
      alignItems: "center",
      justifyContent: "center",
      borderWidth: 1,
      borderColor: palette.border,
      borderRadius: 11,
      backgroundColor: palette.card,
    },
    languageSelected: { borderColor: palette.primary, backgroundColor: palette.accent },
    languageText: { color: palette.foreground, fontSize: 11, fontWeight: "600" },
    languageSelectedText: { color: palette.primary, fontWeight: "800" },
    settingRow: {
      minHeight: 45,
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      paddingHorizontal: 3,
    },
    settingText: { color: palette.foreground, fontSize: 12, flex: 1 },
    clearButton: {
      minHeight: 43,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      gap: 8,
      borderRadius: 12,
      borderWidth: 1,
      borderColor: palette.destructive,
      marginTop: 12,
      marginBottom: 14,
    },
    clearText: { color: palette.destructive, fontSize: 12, fontWeight: "700" },
    screenLoading: { flex: 1, alignItems: "center", justifyContent: "center", gap: 10 },
    loadingText: { color: palette.mutedForeground, fontSize: 12 },
  });
}

function SuggestionCard({
  item,
  index,
  styles,
  palette,
  compact,
  onPress,
}: {
  item: Suggestion;
  index: number;
  styles: ReturnType<typeof createStyles>;
  palette: Palette;
  compact: boolean;
  onPress: () => void;
}) {
  const iconNames: Array<keyof typeof Ionicons.glyphMap> = [
    "document-text-outline",
    "language-outline",
    "bulb-outline",
    "code-slash-outline",
  ];

  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => [
        styles.suggestion,
        compact && { width: "100%" },
        pressed && { borderColor: palette.primary, opacity: 0.84 },
      ]}
      testID={`suggestion-${index + 1}`}
    >
      <View style={styles.suggestionIcon}>
        <Ionicons name={iconNames[index]} size={17} color={palette.primary} />
      </View>
      <View style={styles.suggestionTextWrap}>
        <Text style={styles.suggestionTitle} numberOfLines={2}>{item.title}</Text>
        <Text style={styles.suggestionSub} numberOfLines={2}>{item.subtitle}</Text>
      </View>
    </Pressable>
  );
}

export default function ChatScreen() {
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const [dark, setDark] = useState(true);
  const [language, setLanguage] = useState<Language>("ar");
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState("");
  const [draft, setDraft] = useState("");
  const [attachment, setAttachment] = useState("");
  const [preparingImage, setPreparingImage] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [error, setError] = useState("");
  const [errorConversationId, setErrorConversationId] = useState("");
  const [storageError, setStorageError] = useState("");
  const [hydrated, setHydrated] = useState(false);
  const inputRef = useRef<TextInput>(null);
  const [permission, requestPermission] = ImagePicker.useMediaLibraryPermissions();
  const colors = useColors(dark ? "dark" : "light");
  const styles = useMemo(() => createStyles(colors), [dark]);
  const copy = getChatStrings(language);
  const isRTL = language === "ar";
  const compact = width < 365;
  const health = useHealthCheck({
    query: { refetchInterval: 60_000, retry: 1 },
  });
  const completion = useCreateChatCompletion();
  const activeConversation = conversations.find((item) => item.id === activeId);
  const messages = activeConversation?.messages ?? [];
  const topInset = Platform.OS === "web" ? 67 : insets.top;
  const bottomInset = Platform.OS === "web" ? 34 : insets.bottom;

  useEffect(() => {
    let mounted = true;
    void (async () => {
      try {
        const [savedConversations, savedLanguage, savedTheme] = await Promise.all([
          AsyncStorage.getItem(HISTORY_KEY),
          AsyncStorage.getItem(LANGUAGE_KEY),
          AsyncStorage.getItem(THEME_KEY),
        ]);
        if (!mounted) return;
        if (savedConversations) {
          setConversations(getValidConversations(JSON.parse(savedConversations)));
        }
        if (savedLanguage === "ar" || savedLanguage === "en" || savedLanguage === "fr") {
          setLanguage(savedLanguage);
        }
        if (savedTheme === "light") setDark(false);
        const firstChat = savedConversations
          ? getValidConversations(JSON.parse(savedConversations))[0]
          : undefined;
        if (firstChat) setActiveId(firstChat.id);
      } catch {
        if (mounted) setStorageError(getChatStrings("ar").storageError);
      } finally {
        if (mounted) setHydrated(true);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    void AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(conversations)).catch(() => {
      setStorageError(copy.storageSaveError);
    });
  }, [conversations, hydrated, copy.storageSaveError]);

  useEffect(() => {
    if (!hydrated) return;
    void AsyncStorage.setItem(LANGUAGE_KEY, language).catch(() => {
      setStorageError(copy.storageSaveError);
    });
  }, [language, hydrated, copy.storageSaveError]);

  useEffect(() => {
    if (!hydrated) return;
    void AsyncStorage.setItem(THEME_KEY, dark ? "dark" : "light").catch(() => {
      setStorageError(copy.storageSaveError);
    });
  }, [dark, hydrated, copy.storageSaveError]);

  function saveConversation(chatId: string, nextMessages: ChatMessage[]) {
    setConversations((previous) => {
      const current = previous.find((conversation) => conversation.id === chatId);
      const updated: Conversation = {
        ...(current ?? { id: chatId, messages: [], updatedAt: Date.now() }),
        messages: nextMessages,
        updatedAt: Date.now(),
      };
      return [updated, ...previous.filter((conversation) => conversation.id !== chatId)];
    });
  }

  function beginNewChat() {
    tap();
    const nextId = makeId();
    setConversations((previous) => [
      { id: nextId, messages: [], updatedAt: Date.now() },
      ...previous,
    ]);
    setActiveId(nextId);
    setDraft("");
    setAttachment("");
    setError("");
    setErrorConversationId("");
    setMenuOpen(false);
    setTimeout(() => inputRef.current?.focus(), 120);
  }

  function selectChat(chatId: string) {
    setActiveId(chatId);
    setDraft("");
    setAttachment("");
    setError("");
    setErrorConversationId("");
    setMenuOpen(false);
  }

  function removeChat(chatId: string) {
    const remaining = conversations.filter((conversation) => conversation.id !== chatId);
    setConversations(remaining);
    if (activeId === chatId) setActiveId(remaining[0]?.id ?? "");
    if (errorConversationId === chatId) {
      setError("");
      setErrorConversationId("");
    }
  }

  function clearAllChats() {
    Alert.alert(copy.clearConfirmTitle, copy.clearConfirmMessage, [
      { text: copy.cancel, style: "cancel" },
      {
        text: copy.clearAction,
        style: "destructive",
        onPress: () => {
          setConversations([]);
          setActiveId("");
          setError("");
          setErrorConversationId("");
        },
      },
    ]);
  }

  function sendToAssistant(chatId: string, nextMessages: ChatMessage[]) {
    setError("");
    setErrorConversationId("");
    const apiMessages = nextMessages.slice(-24).map((message) => ({
      role: message.role,
      content: message.content,
      ...(message.imageDataUrl ? { imageDataUrl: message.imageDataUrl } : {}),
    }));

    completion.mutate(
      { data: { messages: apiMessages } },
      {
        onSuccess: (response) => {
          const reply: ChatMessage = {
            id: makeId(),
            role: "assistant",
            content: response.message,
          };
          saveConversation(chatId, [...nextMessages, reply]);
        },
        onError: (reason) => {
          setError(getErrorMessage(reason, copy.genericError));
          setErrorConversationId(chatId);
        },
      },
    );
  }

  function submitMessage() {
    const content = draft.trim();
    if ((!content && !attachment) || completion.isPending || preparingImage) return;
    tap();
    const chatId = activeConversation?.id ?? makeId();
    const previousMessages = activeConversation?.messages ?? [];
    const userMessage: ChatMessage = {
      id: makeId(),
      role: "user",
      content,
      ...(attachment ? { imageDataUrl: attachment } : {}),
    };
    const nextMessages = [...previousMessages, userMessage];
    if (!activeConversation) setActiveId(chatId);
    saveConversation(chatId, nextMessages);
    setDraft("");
    setAttachment("");
    sendToAssistant(chatId, nextMessages);
  }

  function retryLastMessage() {
    if (!activeConversation || completion.isPending) return;
    const lastMessage = activeConversation.messages.at(-1);
    if (!lastMessage || lastMessage.role !== "user") return;
    sendToAssistant(activeConversation.id, activeConversation.messages);
  }

  async function chooseImage() {
    if (preparingImage || completion.isPending) return;
    try {
      let permissionResult = permission;
      if (!permissionResult?.granted) {
        permissionResult = await requestPermission();
      }
      if (!permissionResult.granted) {
        if (permissionResult.canAskAgain === false) {
          Alert.alert(copy.imagePermission, copy.imagePermissionSettings, [
            { text: copy.cancel, style: "cancel" },
            {
              text: copy.close,
              onPress: () => {
                if (Platform.OS !== "web") void Linking.openSettings();
              },
            },
          ]);
        } else {
          setError(copy.imagePermission);
          setErrorConversationId(activeId);
        }
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ["images"],
        allowsEditing: false,
        quality: 1,
      });
      if (result.canceled || !result.assets[0]) return;

      setPreparingImage(true);
      setError("");
      const asset = result.assets[0];
      const maxDimension = 1280;
      const scale = Math.min(1, maxDimension / Math.max(asset.width, asset.height));
      const actions =
        scale < 1
          ? [
              {
                resize: {
                  width: Math.max(1, Math.round(asset.width * scale)),
                  height: Math.max(1, Math.round(asset.height * scale)),
                },
              },
            ]
          : [];
      const compressed = await ImageManipulator.manipulateAsync(asset.uri, actions, {
        compress: 0.76,
        format: ImageManipulator.SaveFormat.JPEG,
        base64: true,
      });
      if (!compressed.base64) throw new Error("Image conversion failed");
      const dataUrl = `data:image/jpeg;base64,${compressed.base64}`;
      if (dataUrl.length > MAX_IMAGE_CHARS) {
        setError(copy.imageTooLarge);
        setErrorConversationId(activeId);
        return;
      }
      setAttachment(dataUrl);
    } catch {
      setError(copy.imageReadError);
      setErrorConversationId(activeId);
    } finally {
      setPreparingImage(false);
    }
  }

  function useSuggestion(item: Suggestion) {
    setDraft(item.prompt);
    setTimeout(() => inputRef.current?.focus(), 100);
  }

  if (!hydrated) {
    return (
      <View style={[styles.screen, styles.screenLoading, { paddingTop: topInset }]}>
        <StatusBar style={dark ? "light" : "dark"} />
        <ActivityIndicator color={colors.primary} />
        <Text style={styles.loadingText}>{copy.checking}</Text>
      </View>
    );
  }

  return (
    <View style={[styles.screen, { paddingTop: topInset }]}>
      <StatusBar style={dark ? "light" : "dark"} />

      <View style={[styles.topbar, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
        <View style={[styles.topbarStart, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
          <Pressable
            accessibilityLabel={copy.menu}
            accessibilityRole="button"
            onPress={() => setMenuOpen(true)}
            style={({ pressed }) => [styles.iconButton, pressed && { opacity: 0.72 }]}
            testID="open-history"
          >
            <Ionicons name="menu-outline" size={22} color={colors.primary} />
          </Pressable>
          <View style={[styles.brand, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
            <LinearGradient
              colors={[colors.goldLight, colors.primary, colors.goldDeep]}
              style={styles.brandMark}
            >
              <MaterialCommunityIcons name="crown" size={21} color={colors.primaryForeground} />
            </LinearGradient>
            <View>
              <Text style={[styles.brandText, { textAlign: isRTL ? "right" : "left" }]}>KING SUPER AI</Text>
              <View style={[styles.connection, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
                <View
                  style={[
                    styles.connectionDot,
                    {
                      backgroundColor: health.isError
                        ? colors.destructive
                        : health.isLoading
                          ? colors.goldDeep
                          : "#55ad89",
                    },
                  ]}
                />
                <Text style={styles.connectionText}>
                  {health.isLoading ? copy.checking : health.isError ? copy.offline : copy.ready}
                </Text>
              </View>
            </View>
          </View>
        </View>

        <Pressable
          accessibilityLabel={copy.newChat}
          accessibilityRole="button"
          onPress={beginNewChat}
          style={({ pressed }) => [styles.iconButton, pressed && { opacity: 0.72 }]}
          testID="new-chat"
        >
          <Ionicons name="add" size={22} color={colors.primary} />
        </Pressable>
      </View>

      <KeyboardAvoidingView style={styles.keyboardArea} behavior="padding" keyboardVerticalOffset={0}>
        <View style={styles.conversationArea}>
          {messages.length === 0 ? (
            <ScrollView
              contentContainerStyle={styles.welcomeScroll}
              keyboardShouldPersistTaps="handled"
              showsVerticalScrollIndicator={false}
            >
              <View style={styles.welcome}>
                <View style={styles.welcomeEmblem}>
                  <Ionicons name="chatbubble-ellipses-outline" size={29} color={colors.primary} />
                </View>
                <Text style={styles.welcomeTitle}>{copy.welcomeTitle}</Text>
                <Text style={styles.welcomeBody}>{copy.welcomeBody}</Text>
                <View style={styles.suggestions}>
                  {copy.suggestions.map((item, index) => (
                    <SuggestionCard
                      key={`${language}-${index}`}
                      item={item}
                      index={index}
                      styles={styles}
                      palette={colors}
                      compact={compact}
                      onPress={() => useSuggestion(item)}
                    />
                  ))}
                </View>
              </View>
            </ScrollView>
          ) : (
            <FlatList
              inverted
              data={[...messages].reverse()}
              keyExtractor={(item) => item.id}
              keyboardDismissMode="interactive"
              keyboardShouldPersistTaps="handled"
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.messageList}
              renderItem={({ item }) => {
                const isUser = item.role === "user";
                return (
                  <View
                    style={[
                      styles.messageRow,
                      {
                        flexDirection: isUser ? "row-reverse" : "row",
                        alignSelf: isUser ? "flex-end" : "flex-start",
                        transform: [{ scaleY: -1 }],
                      },
                    ]}
                  >
                    <View style={[styles.messageAvatar, isUser && styles.userAvatar]}>
                      <Text style={[styles.avatarText, isUser && styles.userAvatarText]}>
                        {isUser ? copy.userAvatar : copy.assistantAvatar}
                      </Text>
                    </View>
                    <View
                      style={[
                        styles.messageBubble,
                        isUser ? styles.userBubble : styles.assistantBubble,
                      ]}
                    >
                      {item.imageDataUrl ? (
                        <Image
                          source={{ uri: item.imageDataUrl }}
                          style={styles.messageImage}
                          resizeMode="contain"
                        />
                      ) : null}
                      {item.content ? (
                        <Text
                          selectable
                          style={[
                            styles.messageText,
                            { textAlign: isRTL ? "right" : "left" },
                          ]}
                        >
                          {item.content}
                        </Text>
                      ) : null}
                    </View>
                  </View>
                );
              }}
              ListHeaderComponent={
                completion.isPending ? (
                  <View
                    accessibilityLabel={copy.generating}
                    style={[
                      styles.messageRow,
                      {
                        flexDirection: isRTL ? "row-reverse" : "row",
                        alignSelf: "flex-start",
                        transform: [{ scaleY: -1 }],
                      },
                    ]}
                    testID="assistant-typing"
                  >
                    <View style={styles.messageAvatar}>
                      <Text style={styles.avatarText}>{copy.assistantAvatar}</Text>
                    </View>
                    <View style={[styles.messageBubble, styles.assistantBubble, styles.typingBubble]}>
                      <ActivityIndicator size="small" color={colors.primary} />
                      <Text style={styles.messageText}>{copy.generating}</Text>
                    </View>
                  </View>
                ) : null
              }
              scrollEnabled={messages.length > 0}
              testID="chat-messages"
            />
          )}
        </View>

        {error && errorConversationId === activeId ? (
          <View style={styles.errorBox} accessibilityRole="alert" testID="chat-error">
            <Text style={styles.errorTitle}>{copy.connectionErrorTitle}</Text>
            <Text style={styles.errorText}>{error}</Text>
            <Pressable onPress={retryLastMessage} style={styles.retryButton} testID="retry-chat">
              <Text style={styles.retryText}>{copy.retry}</Text>
            </Pressable>
          </View>
        ) : null}

        {storageError ? (
          <View style={styles.errorBox} accessibilityRole="alert">
            <Text style={styles.errorText}>{storageError}</Text>
          </View>
        ) : null}

        <View style={[styles.composerWrap, { paddingBottom: Math.max(bottomInset, 10) }]}>
          <View style={styles.composer}>
            {attachment ? (
              <View style={[styles.attachmentPreview, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
                <Image source={{ uri: attachment }} style={styles.attachmentImage} />
                <Text style={styles.attachmentText}>{copy.imageReady}</Text>
                <Pressable
                  accessibilityLabel={copy.removeImage}
                  onPress={() => setAttachment("")}
                  testID="remove-image"
                >
                  <Ionicons name="close-circle" size={21} color={colors.mutedForeground} />
                </Pressable>
              </View>
            ) : null}
            <TextInput
              ref={inputRef}
              value={draft}
              onChangeText={setDraft}
              placeholder={copy.placeholder}
              placeholderTextColor={colors.mutedForeground}
              multiline
              maxLength={12_000}
              editable={!completion.isPending && !preparingImage}
              returnKeyType="default"
              textAlign={isRTL ? "right" : "left"}
              style={styles.textInput}
              accessibilityLabel={copy.placeholder}
              testID="chat-input"
            />
            <View style={[styles.composerTools, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
              <View style={[styles.attachGroup, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
                <Pressable
                  accessibilityLabel={copy.attachImage}
                  accessibilityRole="button"
                  onPress={chooseImage}
                  disabled={preparingImage || completion.isPending}
                  style={({ pressed }) => [{ opacity: pressed ? 0.68 : 1 }]}
                  testID="attach-image"
                >
                  {preparingImage ? (
                    <ActivityIndicator size="small" color={colors.primary} />
                  ) : (
                    <Ionicons name="image-outline" size={22} color={colors.primary} />
                  )}
                </Pressable>
                <Text style={styles.attachHint} numberOfLines={1}>
                  {preparingImage ? copy.preparingImage : copy.askAboutImage}
                </Text>
              </View>
              <Pressable
                accessibilityLabel={copy.send}
                accessibilityRole="button"
                onPress={submitMessage}
                disabled={completion.isPending || preparingImage || (!draft.trim() && !attachment)}
                style={({ pressed }) => [
                  styles.sendButton,
                  pressed && { opacity: 0.78 },
                  (completion.isPending || preparingImage || (!draft.trim() && !attachment)) &&
                    styles.sendDisabled,
                ]}
                testID="send-message"
              >
                <LinearGradient
                  colors={[colors.goldLight, colors.primary, colors.goldDeep]}
                  style={StyleSheet.absoluteFill}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                />
                {completion.isPending ? (
                  <ActivityIndicator size="small" color={colors.primaryForeground} />
                ) : (
                  <Ionicons name="arrow-up" size={21} color={colors.primaryForeground} />
                )}
              </Pressable>
            </View>
          </View>
          <Text style={styles.disclaimer}>{copy.disclaimer}</Text>
        </View>
      </KeyboardAvoidingView>

      <Modal
        visible={menuOpen}
        transparent
        animationType="slide"
        statusBarTranslucent
        onRequestClose={() => setMenuOpen(false)}
      >
        <View style={styles.modalBackdrop}>
          <Pressable
            accessibilityLabel={copy.close}
            onPress={() => setMenuOpen(false)}
            style={styles.modalDismiss}
          />
          <View
            style={[
              styles.sheet,
              {
                paddingBottom: Math.max(bottomInset, 16),
                alignSelf: "stretch",
              },
            ]}
          >
            <View style={styles.sheetHandle} />
            <View style={[styles.sheetHeader, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
              <View>
                <Text style={styles.sheetHeading}>{copy.conversations}</Text>
                <Text style={styles.sheetSubheading}>{copy.appDescriptor}</Text>
              </View>
              <Pressable
                accessibilityLabel={copy.close}
                onPress={() => setMenuOpen(false)}
                style={styles.iconButton}
              >
                <Ionicons name="close" size={21} color={colors.primary} />
              </Pressable>
            </View>

            <Pressable
              onPress={beginNewChat}
              style={({ pressed }) => [pressed && { opacity: 0.82 }]}
              testID="new-chat-from-menu"
            >
              <LinearGradient
                colors={[colors.goldLight, colors.primary, colors.goldDeep]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={[styles.newChatSheet, { flexDirection: isRTL ? "row-reverse" : "row" }]}
              >
                <Ionicons name="add" size={20} color={colors.primaryForeground} />
                <Text style={styles.newChatSheetText}>{copy.newChat}</Text>
              </LinearGradient>
            </Pressable>

            <Text style={[styles.sheetSectionTitle, { textAlign: isRTL ? "right" : "left" }]}>
              {copy.conversations}
            </Text>
            <ScrollView
              style={styles.historyList}
              contentContainerStyle={{ paddingBottom: 2 }}
              showsVerticalScrollIndicator={false}
            >
              {conversations.filter((item) => item.messages.length > 0).length === 0 ? (
                <Text style={styles.emptyHistory}>{copy.emptyHistory}</Text>
              ) : (
                conversations
                  .filter((item) => item.messages.length > 0)
                  .map((conversation) => (
                    <View
                      key={conversation.id}
                      style={[
                        styles.historyRow,
                        {
                          flexDirection: isRTL ? "row-reverse" : "row",
                          borderWidth: activeId === conversation.id ? 1 : 0,
                          borderColor: colors.primary,
                        },
                      ]}
                    >
                      <Pressable
                        onPress={() => selectChat(conversation.id)}
                        style={[
                          { flex: 1, minWidth: 0, flexDirection: isRTL ? "row-reverse" : "row", alignItems: "center", gap: 9 },
                        ]}
                        testID={`history-${conversation.id}`}
                      >
                        <Ionicons name="chatbubble-outline" size={16} color={colors.primary} />
                        <Text
                          numberOfLines={1}
                          style={[styles.historyTitle, { textAlign: isRTL ? "right" : "left" }]}
                        >
                          {getTitle(conversation, copy.newChat)}
                        </Text>
                      </Pressable>
                      <Pressable
                        accessibilityLabel={copy.deleteChat}
                        onPress={() => removeChat(conversation.id)}
                        testID={`delete-history-${conversation.id}`}
                      >
                        <Ionicons name="close" size={18} color={colors.mutedForeground} />
                      </Pressable>
                    </View>
                  ))
              )}
            </ScrollView>

            <Text style={[styles.sheetSectionTitle, { textAlign: isRTL ? "right" : "left" }]}>
              {copy.language}
            </Text>
            <View style={[styles.languageRow, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
              {([
                ["ar", "العربية"],
                ["en", "English"],
                ["fr", "Français"],
              ] as const).map(([value, label]) => (
                <Pressable
                  key={value}
                  onPress={() => {
                    tap();
                    setLanguage(value);
                  }}
                  style={[
                    styles.languageButton,
                    language === value && styles.languageSelected,
                  ]}
                  testID={`language-${value}`}
                >
                  <Text
                    style={[
                      styles.languageText,
                      language === value && styles.languageSelectedText,
                    ]}
                  >
                    {label}
                  </Text>
                </Pressable>
              ))}
            </View>

            <Pressable
              onPress={() => setDark((value) => !value)}
              style={[styles.settingRow, { flexDirection: isRTL ? "row-reverse" : "row" }]}
              testID="toggle-theme"
            >
              <Ionicons
                name={dark ? "sunny-outline" : "moon-outline"}
                size={18}
                color={colors.primary}
              />
              <Text style={styles.settingText}>{dark ? copy.themeLight : copy.themeDark}</Text>
              <Ionicons name={dark ? "toggle" : "toggle-outline"} size={24} color={colors.primary} />
            </Pressable>

            <Pressable
              onPress={clearAllChats}
              style={styles.clearButton}
              testID="clear-history"
            >
              <Ionicons name="trash-outline" size={17} color={colors.destructive} />
              <Text style={styles.clearText}>{copy.clearAll}</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </View>
  );
}
