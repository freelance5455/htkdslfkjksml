# AI Duty Manager

A bilingual Hindi + English, offline-first duty roster prototype.

## Included (Version 2.0)
- Configurable staff count, duty areas, headcount per area
- Excluded staff numbers
- Minimum rest gap between assignments
- Fair / oldest-waiting / sequential rotation modes
- Avoids assigning the same person to the same duty area as their latest recorded assignment when possible
- Daily roster, history, staff names, CSV export, print-to-PDF, JSON backup
- Data stored locally in the browser on the device
- Local admin PIN lock (default 1234, change after first login)
- Generate a 30-day duty plan
- Staff-wise duty count report
- Manual duty edits with duplicate/excluded checks
- WhatsApp roster sharing

## Run as a mobile web app
Serve the `www` folder over HTTPS, open it in Chrome on Android, then use Chrome menu > Add to Home screen / Install app.

## Build Android APK (requires Android Studio + Android SDK + Node.js)
1. Install Node.js LTS and Android Studio.
2. In this project folder run: `npm install`
3. Run: `npx cap add android`
4. Run: `npx cap sync android`
5. Run: `npx cap open android`
6. In Android Studio choose Build > Build Bundle(s) / APK(s) > Build APK(s).

The current ChatGPT build environment does not include Android SDK or Gradle, so a signed APK cannot be compiled here. This project includes the web app and Capacitor configuration needed to generate the Android wrapper on a machine with the Android toolchain.

## Important scheduling note
The scheduler is a deterministic fair-rotation engine, not a cloud AI model. It enforces hard constraints and flags when a valid roster cannot be produced. For real AI/cloud sync, user accounts, multi-device shared history, admin roles, and notifications, a backend and deployment are needed.

## Admin PIN
First local PIN is `1234`. Change it immediately from Admin / Reports. This is a device-local convenience lock, not enterprise-grade authentication.

## Version 2.1 additions
- Requested uppercase roster heading: DAILY MORNING DUTY PLAN OF A SQUAD ROBC SL NO. 322
- WhatsApp share includes roster and exemption reasons
- Print-to-PDF workflow (browser print dialog: Save as PDF)
- PNG photo export generated locally in the browser
- Exemption staff numbers with written reasons; automatically excluded from duty

## Version 2.2 addition
- Each duty area now has an editable 'Work to be done' description.
- Work instructions are shown in the daily roster and included in WhatsApp text, printable PDF view, and generated PNG roster photo.
