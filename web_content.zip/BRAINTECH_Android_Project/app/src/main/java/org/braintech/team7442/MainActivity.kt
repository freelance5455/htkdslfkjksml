package org.braintech.team7442

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private var tts: TextToSpeech? = null
    private val audioPermissionCode = 7442
    private val speechRequestCode = 7443

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(AndroidSpeechBridge(), "AndroidSpeech")
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class AndroidSpeechBridge {
        @JavascriptInterface
        fun startListening() {
            runOnUiThread {
                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@MainActivity,
                        arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionCode)
                } else launchSpeechRecognizer()
            }
        }

        @JavascriptInterface
        fun speak(message: String) {
            runOnUiThread {
                if (tts == null) tts = TextToSpeech(this@MainActivity, this@MainActivity)
                tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "braintech-utterance")
            }
        }
    }

    private fun launchSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendJsError("Speech recognition is not available on this device. You can type your message instead.")
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your BRAINTECH request")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try { startActivityForResult(intent, speechRequestCode) }
        catch (_: Exception) { sendJsError("Could not open Android speech recognition. You can type your message instead.") }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionCode) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchSpeechRecognizer()
            else sendJsError("Microphone permission was denied. Allow microphone access in Android settings, or type your message.")
        }
    }

    @Deprecated("Deprecated API retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequestCode) {
            if (resultCode == RESULT_OK) {
                val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
                val quoted = org.json.JSONObject.quote(spoken)
                webView.evaluateJavascript("window.onNativeSpeechResult && window.onNativeSpeechResult($quoted);", null)
            } else sendJsError("Speech input was cancelled or not recognised. Please try again or type your message.")
        }
    }

    private fun sendJsError(message: String) {
        val quoted = org.json.JSONObject.quote(message)
        webView.post { webView.evaluateJavascript("window.onNativeSpeechError && window.onNativeSpeechError($quoted);", null) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("en", "IN")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
