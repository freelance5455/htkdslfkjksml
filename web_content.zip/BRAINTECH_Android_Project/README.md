# BRAINTECH Android project — latest uploaded HTML

This project wraps the newly uploaded BRAINTECH Assistive Communication HTML prototype in an Android WebView.

- Preserves the uploaded interface and interactive sections.
- Uses Android native speech recognition and text-to-speech through a bridge.
- Requests microphone permission at runtime.
- SOS is demo-only; it does not contact emergency services or caregivers.
- No EEG hardware, sensors, or mobility equipment are connected.

## Build on your Android phone using MobileStudio
1. Extract this ZIP.
2. In MobileStudio, choose Open/Import Existing Project.
3. Select the extracted `BRAINTECH_Android_Project` folder (the one containing `settings.gradle`).
4. Allow JDK/Gradle installation to finish. First setup may take time and data.
5. Select the `app` build target if prompted and tap Build.
6. When successful, use the APK/output option to locate the debug APK and install it.

This ZIP is Android source code, not an APK. A compiled APK requires an Android build environment. The current execution environment does not have Android SDK/Gradle available to compile it here.
