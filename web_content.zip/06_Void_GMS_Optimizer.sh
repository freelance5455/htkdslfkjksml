#!/bin/bash
# Void GMS Optimizer v6.0 - Comandos limpos com 2>/dev/null || true
echo "Aplicando Void GMS Optimizer..."

setprop ro.voidgms.installed true 2>/dev/null || true
setprop persist.sys.voidgms.enabled true 2>/dev/null || true
# Desativa serviços Google pesados (comum em GMS optimizers)
pm disable-user --user 0 com.google.android.gms/.chimera.GmsIntentOperationService 2>/dev/null || true
pm disable-user --user 0 com.google.android.gms/.nearby.discovery.service.DiscoveryService 2>/dev/null || true
settings put global adaptive_battery_management_enabled 0 2>/dev/null || true
settings put global app_standby_enabled 0 2>/dev/null || true

echo "Void GMS Optimizer aplicado!"
