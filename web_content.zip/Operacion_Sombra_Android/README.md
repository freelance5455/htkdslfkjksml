# Operación Sombra — prototipo Android

Prototipo de shooter 3D estilo retro (raycasting 2.5D) con controles táctiles. Está empaquetado en una aplicación Android que carga el juego desde assets locales; no necesita internet al jugar.

## Qué incluye
- Vista en primera persona con paredes, pasillo, luces y enemigos.
- Movimiento táctil: joystick izquierdo para moverse; deslizar la zona derecha para girar.
- Botón DISPARAR, munición, salud, puntuación y reinicio.
- Proyecto Android con WebView local y flujo de GitHub Actions para crear una APK de depuración.

## Limitaciones honestas
Esta es una primera versión jugable de estilo 2.5D, no un shooter 3D realista de alta fidelidad. Los personajes y escenarios son formas dibujadas por raycasting, sin modelos 3D detallados, animaciones avanzadas, IA compleja ni físicas realistas. Sirve como base para iterar.

## Compilar APK desde Android sin computadora
1. Descarga y extrae el ZIP en el teléfono.
2. En el navegador, inicia sesión en GitHub y crea un repositorio vacío, por ejemplo `operacion-sombra`.
3. Sube el contenido de esta carpeta al repositorio manteniendo la estructura de archivos.
4. Abre la pestaña **Actions**, elige **Build Operacion Sombra APK** y toca **Run workflow**.
5. Cuando termine en verde, abre la ejecución y descarga el artefacto `operacion-sombra-debug-apk`.
6. Extrae el ZIP del artefacto e instala el APK. Android podría pedir permiso para instalar aplicaciones de esa fuente.

## Sobre Gradle
El flujo de GitHub Actions instala Gradle 8.9 en el servidor y ejecuta `gradle assembleDebug`, así que no hace falta incluir el archivo binario `gradle-wrapper.jar` en este ZIP. El proyecto usa Android Gradle Plugin 8.7.3 y Java 17.

## Controles
- Joystick izquierdo: caminar.
- Zona derecha: arrastrar para mirar.
- DISPARAR: disparo hacia el centro de la pantalla.
- RECARGAR: recarga el cargador.
- PAUSA: detener/reanudar.
\n\n## Actualización visual\n- Orientación horizontal forzada en Android (landscape).\n- HUD y controles táctiles compactos para pantalla apaisada.\n- Menú adaptado a dos columnas en horizontal.\n- Líneas de perspectiva y detalles de desgaste para dar más profundidad al escenario.\n- Sigue siendo un shooter 2.5D por raycasting, no gráficos 3D realistas completos.\n