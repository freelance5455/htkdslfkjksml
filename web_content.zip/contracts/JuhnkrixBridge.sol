// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import "@openzeppelin/contracts/access/Ownable.sol";

contract JuhnkrixBridge is Ownable {
    struct Lock {
        uint256 amount;
        uint256 timestamp;
        bool unlocked;
        address user;
    }

    mapping(bytes32 => Lock) public locks;

    event TokensLocked(bytes32 indexed lockId, address indexed user, uint256 amount, uint256 timestamp);
    event TokensUnlocked(bytes32 indexed lockId, address indexed user, uint256 amount);

    modifier onlyAfter7Days(bytes32 lockId) {
        require(block.timestamp >= locks[lockId].timestamp + 7 days, "Challenge window active: cannot unlock before 7 days");
        require(!locks[lockId].unlocked, "Already unlocked");
        _;
    }

    function lockTokens(uint256 amount, address destinationAddress) external {
        // Assume ERC20 token transfer logic here
        bytes32 lockId = keccak256(abi.encodePacked(msg.sender, amount, block.timestamp));
        locks[lockId] = Lock(amount, block.timestamp, false, msg.sender);
        emit TokensLocked(lockId, msg.sender, amount, block.timestamp);
    }

    function unlockTokens(bytes32 lockId) external onlyAfter7Days(lockId) {
        locks[lockId].unlocked = true;
        // Assume ERC20 token transfer logic to msg.sender here
        emit TokensUnlocked(lockId, msg.sender, locks[lockId].amount);
    }
}
