// =====================================
// NetEarn Pro
// Tasks Management System
// V3
// Cloudinary Image Upload
// Old + New Task Compatibility
// =====================================

import {
    auth,
    db
} from "../js/firebase.js";

import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

import {
    collection,
    getDocs,
    addDoc,
    deleteDoc,
    doc,
    getDoc,
    updateDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =====================================
// CLOUDINARY CONFIG
// =====================================

const CLOUDINARY_CLOUD_NAME =
    "jqwnows8";

const CLOUDINARY_UPLOAD_PRESET =
    "neteearn_upload";

const CLOUDINARY_UPLOAD_URL =
    `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/image/upload`;


// =====================================
// ADMIN AUTH
// =====================================

onAuthStateChanged(auth, (user) => {

    if (!user) {

        window.location.href =
            "login.html";

        return;

    }

    loadTasks();

});


// =====================================
// SAFE TEXT
// =====================================

function safeText(value) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }

    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


// =====================================
// TASK TITLE COMPATIBILITY
// =====================================

function getTaskTitle(task) {

    return (
        task.title ||
        task.name ||
        task.taskName ||
        "No Title"
    );

}


// =====================================
// TASK STATUS COMPATIBILITY
// =====================================

function getTaskStatus(task) {

    if (
        task.status !== undefined
    ) {

        return task.status === "Active"
            ? "Active"
            : "Off";

    }

    if (
        task.active !== undefined
    ) {

        return task.active === true
            ? "Active"
            : "Off";

    }

    return "Active";

}


// =====================================
// LOAD TASKS
// =====================================

async function loadTasks() {

    const table =
        document.getElementById(
            "tasksTable"
        );


    if (!table) {

        return;

    }


    try {

        const snapshot =
            await getDocs(
                collection(
                    db,
                    "tasks"
                )
            );


        table.innerHTML = "";


        if (snapshot.empty) {

            table.innerHTML = `

                <tr>

                    <td
                        colspan="5"
                        class="text-center">

                        No Tasks Found

                    </td>

                </tr>

            `;

            return;

        }


        snapshot.forEach((taskDoc) => {

            const task =
                taskDoc.data();


            const id =
                taskDoc.id;


            const title =
                getTaskTitle(task);


            const category =
                task.category ||
                "General";


            const reward =
                Number(
                    task.reward || 0
                );


            const status =
                getTaskStatus(task);


            const statusHTML =
                status === "Active"

                    ?

                `
                    <span class="task-active">
                        Active
                    </span>
                `

                    :

                `
                    <span class="task-off">
                        Off
                    </span>
                `;


            const imageHTML =
                task.taskImage

                    ?

                `
                    <span
                        title="Assigned image available"
                        style="font-size:20px;">
                        🖼️
                    </span>
                `

                    :

                `
                    <span
                        title="No assigned image">
                        —
                    </span>
                `;


            table.innerHTML += `

                <tr>

                    <td>
                        ${safeText(title)}
                    </td>


                    <td>
                        ${safeText(category)}
                    </td>


                    <td>
                        ৳${reward}
                    </td>


                    <td>
                        ${statusHTML}
                    </td>


                    <td>

                        ${imageHTML}


                        <button
                            class="action-btn edit-btn"
                            onclick="editTask('${id}')">

                            Edit

                        </button>


                        <button
                            class="action-btn delete-btn"
                            onclick="deleteTask('${id}')">

                            Delete

                        </button>


                        <button
                            class="action-btn toggle-btn"
                            onclick="toggleTask('${id}','${status}')">

                            Toggle

                        </button>

                    </td>

                </tr>

            `;

        });


    }

    catch (error) {

        console.error(
            "Task Load Error:",
            error
        );


        table.innerHTML = `

            <tr>

                <td
                    colspan="5"
                    class="text-center text-danger">

                    ❌ Error Loading Tasks

                </td>

            </tr>

        `;

    }

}


// =====================================
// CLOUDINARY IMAGE UPLOAD
// =====================================

async function uploadTaskImage(
    file,
    onProgress = null
) {

    if (!file) {

        return "";

    }


    // ---------------------------------
    // IMAGE VALIDATION
    // ---------------------------------

    if (
        !file.type ||
        !file.type.startsWith("image/")
    ) {

        throw new Error(
            "INVALID_IMAGE"
        );

    }


    // ---------------------------------
    // FILE SIZE CHECK
    // Cloudinary Free plan allows
    // much larger than this, but keeping
    // 10MB client-side limit is safer.
    // ---------------------------------

    const maxSize =
        10 * 1024 * 1024;


    if (
        file.size > maxSize
    ) {

        throw new Error(
            "IMAGE_TOO_LARGE"
        );

    }


    // ---------------------------------
    // FORM DATA
    // ---------------------------------

    const formData =
        new FormData();


    formData.append(
        "file",
        file
    );


    formData.append(
        "upload_preset",
        CLOUDINARY_UPLOAD_PRESET
    );


    // ---------------------------------
    // XMLHttpRequest
    // Allows upload progress.
    // ---------------------------------

    return new Promise(
        (resolve, reject) => {

            const xhr =
                new XMLHttpRequest();


            xhr.open(
                "POST",
                CLOUDINARY_UPLOAD_URL,
                true
            );


            // -------------------------
            // UPLOAD PROGRESS
            // -------------------------

            xhr.upload.onprogress =
                function (event) {

                    if (
                        event.lengthComputable
                    ) {

                        const percent =
                            Math.round(
                                (
                                    event.loaded /
                                    event.total
                                ) * 100
                            );


                        console.log(
                            `Cloudinary Upload: ${percent}%`
                        );


                        if (
                            typeof onProgress ===
                            "function"
                        ) {

                            onProgress(
                                percent
                            );

                        }

                    }

                };


            // -------------------------
            // SUCCESS / ERROR
            // -------------------------

            xhr.onload =
                function () {

                    if (
                        xhr.status >= 200 &&
                        xhr.status < 300
                    ) {

                        try {

                            const result =
                                JSON.parse(
                                    xhr.responseText
                                );


                            if (
                                !result.secure_url
                            ) {

                                reject(
                                    new Error(
                                        "CLOUDINARY_URL_MISSING"
                                    )
                                );

                                return;

                            }


                            console.log(
                                "Cloudinary Upload Success:",
                                result.secure_url
                            );


                            resolve(
                                result.secure_url
                            );

                        }

                        catch (error) {

                            reject(
                                new Error(
                                    "INVALID_CLOUDINARY_RESPONSE"
                                )
                            );

                        }

                    }

                    else {

                        console.error(
                            "Cloudinary HTTP Error:",
                            xhr.status,
                            xhr.responseText
                        );


                        let message =
                            "CLOUDINARY_UPLOAD_FAILED";


                        try {

                            const errorData =
                                JSON.parse(
                                    xhr.responseText
                                );


                            if (
                                errorData.error &&
                                errorData.error.message
                            ) {

                                message =
                                    errorData
                                    .error
                                    .message;

                            }

                        }

                        catch (e) {

                            // Ignore JSON parse error

                        }


                        reject(
                            new Error(
                                message
                            )
                        );

                    }

                };


            // -------------------------
            // NETWORK ERROR
            // -------------------------

            xhr.onerror =
                function () {

                    reject(
                        new Error(
                            "CLOUDINARY_NETWORK_ERROR"
                        )
                    );

                };


            // -------------------------
            // ABORT
            // -------------------------

            xhr.onabort =
                function () {

                    reject(
                        new Error(
                            "CLOUDINARY_UPLOAD_ABORTED"
                        )
                    );

                };


            // -------------------------
            // SEND
            // -------------------------

            xhr.send(
                formData
            );

        }
    );

}


// =====================================
// CREATE NEW TASK
// =====================================

window.createTask =
    async function () {

        const createButton =
            document.querySelector(
                '#taskModal button[onclick="createTask()"]'
            );


        try {

            // ---------------------------------
            // GET FORM VALUES
            // ---------------------------------

            const title =
                document
                .getElementById(
                    "taskTitle"
                )
                .value
                .trim();


            const category =
                document
                .getElementById(
                    "taskCategory"
                )
                .value
                .trim();


            const description =
                document
                .getElementById(
                    "taskDescription"
                )
                .value
                .trim();


            const reward =
                Number(
                    document
                    .getElementById(
                        "taskReward"
                    )
                    .value
                );


            const timeInput =
                document.getElementById(
                    "taskTime"
                );


            const time =
                timeInput
                    ? Number(
                        timeInput.value
                    )
                    : 30;


            const linkInput =
                document.getElementById(
                    "taskLink"
                );


            const link =
                linkInput
                    ? linkInput.value.trim()
                    : "";


            const imageInput =
                document.getElementById(
                    "taskImage"
                );


            const imageFile =
                imageInput &&
                imageInput.files
                    ? imageInput.files[0]
                    : null;


            const status =
                document
                .getElementById(
                    "taskStatus"
                )
                .value;


            // ---------------------------------
            // VALIDATION
            // ---------------------------------

            if (
                !title ||
                !category ||
                !reward ||
                !time
            ) {

                alert(
                    "❌ Please fill all required fields."
                );

                return;

            }


            if (
                time < 1
            ) {

                alert(
                    "❌ Time must be at least 1 minute."
                );

                return;

            }


            // ---------------------------------
            // BUTTON STATE
            // ---------------------------------

            if (createButton) {

                createButton.disabled =
                    true;

                createButton.textContent =
                    "⏳ Creating...";

            }


            // ---------------------------------
            // CLOUDINARY IMAGE UPLOAD
            // ---------------------------------

            let taskImage = "";


            if (imageFile) {

                if (createButton) {

                    createButton.textContent =
                        "☁️ Uploading 0%...";

                }


                taskImage =
                    await uploadTaskImage(
                        imageFile,
                        (percent) => {

                            if (createButton) {

                                createButton.textContent =
                                    `☁️ Uploading ${percent}%...`;

                            }

                        }
                    );

            }


            // ---------------------------------
            // FIRESTORE
            // ---------------------------------

            await addDoc(

                collection(
                    db,
                    "tasks"
                ),

                {

                    title: title,

                    category: category,

                    description: description,

                    reward: reward,

                    timeLimit: time,

                    link: link,

                    taskImage:
                        taskImage,

                    status: status,

                    // Old system compatibility

                    name: title,

                    active:
                        status === "Active",

                    createdAt:
                        serverTimestamp()

                }

            );


            // ---------------------------------
            // SUCCESS
            // ---------------------------------

            alert(
                "✅ Task Created Successfully!"
            );


            // ---------------------------------
            // CLEAR FORM
            // ---------------------------------

            document
            .getElementById(
                "taskTitle"
            )
            .value = "";


            document
            .getElementById(
                "taskCategory"
            )
            .value = "";


            document
            .getElementById(
                "taskDescription"
            )
            .value = "";


            document
            .getElementById(
                "taskReward"
            )
            .value = "";


            if (timeInput) {

                timeInput.value = "";

            }


            if (linkInput) {

                linkInput.value = "";

            }


            if (imageInput) {

                imageInput.value = "";

            }


            document
            .getElementById(
                "taskStatus"
            )
            .value = "Active";


// ---------------------------------
            // RELOAD
            // ---------------------------------

            await loadTasks();

        }

        catch (error) {

            console.error(
                "Create Task Error:",
                error
            );


            if (
                error.message ===
                "INVALID_IMAGE"
            ) {

                alert(
                    "❌ Please select a valid image file."
                );

            }

            else if (
                error.message ===
                "IMAGE_TOO_LARGE"
            ) {

                alert(
                    "❌ Image is too large. Please select an image under 10MB."
                );

            }

            else if (
                error.message ===
                "CLOUDINARY_NETWORK_ERROR"
            ) {

                alert(
                    "❌ Cloudinary network error. Check your internet connection."
                );

            }

            else if (
                error.message ===
                "CLOUDINARY_UPLOAD_ABORTED"
            ) {

                alert(
                    "❌ Image upload was cancelled."
                );

            }

            else {

                alert(
                    "❌ Task Create Failed: " +
                    error.message
                );

            }

        }

        finally {

            if (createButton) {

                createButton.disabled =
                    false;

                createButton.textContent =
                    "Create Task";

            }

        }

    };


// =====================================
// DELETE TASK
// =====================================

window.deleteTask =
    async function (id) {

        try {

            const confirmDelete =
                await NetEarnDialog.confirm(
                    "Are you sure you want to delete this task?"
                );


            if (!confirmDelete) {

                return;

            }


            await deleteDoc(

                doc(
                    db,
                    "tasks",
                    id
                )

            );


            alert(
                "🗑️ Task Deleted Successfully!"
            );


            await loadTasks();

        }

        catch (error) {

            console.error(
                "Delete Task Error:",
                error
            );


            alert(
                "❌ Delete Failed: " +
                error.message
            );

        }

    };


// =====================================
// EDIT TASK
// =====================================

window.editTask =
    async function (id) {

        try {

            const taskRef =
                doc(
                    db,
                    "tasks",
                    id
                );


            const taskSnap =
                await getDoc(
                    taskRef
                );


            if (
                !taskSnap.exists()
            ) {

                alert(
                    "❌ Task not found"
                );

                return;

            }


            const task =
                taskSnap.data();


            // ---------------------------------
            // BASIC DATA
            // ---------------------------------

            document
            .getElementById(
                "editTaskId"
            )
            .value = id;


            document
            .getElementById(
                "editTaskTitle"
            )
            .value =
                getTaskTitle(task);


            document
            .getElementById(
                "editTaskCategory"
            )
            .value =
                task.category || "";


            document
            .getElementById(
                "editTaskDescription"
            )
            .value =
                task.description || "";


            document
            .getElementById(
                "editTaskReward"
            )
            .value =
                task.reward || 0;


            document
            .getElementById(
                "editTaskStatus"
            )
            .value =
                getTaskStatus(task);


            // ---------------------------------
            // OPTIONAL TIME
            // ---------------------------------

            const editTime =
                document.getElementById(
                    "editTaskTime"
                );


            if (editTime) {

                editTime.value =
                    task.timeLimit || 30;

            }


            // ---------------------------------
            // OPTIONAL LINK
            // ---------------------------------

            const editLink =
                document.getElementById(
                    "editTaskLink"
                );


            if (editLink) {

                editLink.value =
                    task.link || "";

            }


            // ---------------------------------
            // EDIT IMAGE
            // ---------------------------------

            const editImage =
                document.getElementById(
                    "editTaskImage"
                );


            const editImagePreview =
                document.getElementById(
                    "editTaskImagePreview"
                );


            if (editImage) {

                editImage.value =
                    "";

            }


            if (editImagePreview) {

                if (
                    task.taskImage
                ) {

                    editImagePreview.src =
                        task.taskImage;

                    editImagePreview.style.display =
                        "block";

                }

                else {

                    editImagePreview.src =
                        "";

                    editImagePreview.style.display =
                        "none";

                }

            }


            // ---------------------------------
            // SHOW MODAL
            // ---------------------------------

            const modal =
                new bootstrap.Modal(
                    document.getElementById(
                        "editTaskModal"
                    )
                );


            modal.show();

        }

        catch (error) {

            console.error(
                "Edit Load Error:",
                error
            );


            alert(
                "❌ Edit Load Failed: " +
                error.message
            );

        }

    };


// =====================================
// UPDATE TASK
// =====================================

window.updateTask =
    async function () {

        const updateButton =
            document.querySelector(
                '#editTaskModal button[onclick="updateTask()"]'
            );


        try {

            // ---------------------------------
            // GET ID
            // ---------------------------------

            const id =
                document
                .getElementById(
                    "editTaskId"
                )
                .value;


            if (!id) {

                alert(
                    "❌ Task ID Missing"
                );

                return;

            }


            // ---------------------------------
            // GET VALUES
            // ---------------------------------

            const title =
                document
                .getElementById(
                    "editTaskTitle"
                )
                .value
                .trim();


            const category =
                document
                .getElementById(
                    "editTaskCategory"
                )
                .value
                .trim();


            const description =
                document
                .getElementById(
                    "editTaskDescription"
                )
                .value
                .trim();


            const reward =
                Number(
                    document
                    .getElementById(
                        "editTaskReward"
                    )
                    .value
                );


            const status =
                document
                .getElementById(
                    "editTaskStatus"
                )
                .value;


            const editTime =
                document.getElementById(
                    "editTaskTime"
                );


            const editLink =
                document.getElementById(
                    "editTaskLink"
                );


            const time =
                editTime
                    ? Number(
                        editTime.value
                    )
                    : undefined;


            const link =
                editLink
                    ? editLink.value.trim()
                    : undefined;


            // ---------------------------------
            // IMAGE
            // ---------------------------------

            const editImage =
                document.getElementById(
                    "editTaskImage"
                );


            const newImageFile =
                editImage &&
                editImage.files
                    ? editImage.files[0]
                    : null;


            // ---------------------------------
            // VALIDATION
            // ---------------------------------

            if (
                !title ||
                !category ||
                !reward
            ) {

                alert(
                    "❌ Please fill all required fields."
                );

                return;

            }


            // ---------------------------------
            // BUTTON
            // ---------------------------------

            if (updateButton) {

                updateButton.disabled =
                    true;

                updateButton.textContent =
                    "⏳ Updating...";

            }


            // ---------------------------------
            // TASK REFERENCE
            // ---------------------------------

            const taskRef =
                doc(
                    db,
                    "tasks",
                    id
                );


            // ---------------------------------
            // UPDATE DATA
            // ---------------------------------

            const updateData = {

                title: title,

                name: title,

                category: category,

                description:
                    description,

                reward: reward,

                status: status,

                active:
                    status === "Active",

                updatedAt:
                    serverTimestamp()

            };


            // ---------------------------------
            // UPDATE IMAGE
            // ---------------------------------

            if (newImageFile) {

                if (updateButton) {

                    updateButton.textContent =
                        "☁️ Uploading 0%...";

                }


                const newImageURL =
                    await uploadTaskImage(
                        newImageFile,
                        (percent) => {

                            if (updateButton) {

                                updateButton.textContent =
                                    `☁️ Uploading ${percent}%...`;

                            }

                        }
                    );


                updateData.taskImage =
                    newImageURL;

            }


            // ---------------------------------
            // TIME
            // ---------------------------------

            if (
                editTime &&
                time &&
                time > 0
            ) {

                updateData.timeLimit =
                    time;

            }


            // ---------------------------------
            // LINK
            // ---------------------------------

            if (editLink) {

                updateData.link =
                    link || "";

            }


            // ---------------------------------
            // FIRESTORE UPDATE
            // ---------------------------------

            await updateDoc(

                taskRef,

                updateData

            );


            // ---------------------------------
            // SUCCESS
            // ---------------------------------

            alert(
                "✅ Task Updated Successfully!"
            );


            await loadTasks();

        }

        catch (error) {

            console.error(
                "Update Task Error:",
                error
            );


            if (
                error.message ===
                "INVALID_IMAGE"
            ) {

                alert(
                    "❌ Please select a valid image file."
                );

            }

            else if (
                error.message ===
                "IMAGE_TOO_LARGE"
            ) {

                alert(
                    "❌ Image is too large. Please select an image under 10MB."
                );

            }

            else {

                alert(
                    "❌ Update Failed: " +
                    error.message
                );

            }

        }

        finally {

            if (updateButton) {

                updateButton.disabled =
                    false;

                updateButton.textContent =
                    "Update Task";

            }

        }

    };


// =====================================
// TOGGLE TASK
// =====================================

window.toggleTask =
    async function (
        id,
        currentStatus
    ) {

        try {

            const taskRef =
                doc(
                    db,
                    "tasks",
                    id
                );


            const newStatus =
                currentStatus ===
                "Active"

                    ?

                "Off"

                    :

                "Active";


            await updateDoc(

                taskRef,

                {

                    status:
                        newStatus,

                    active:
                        newStatus ===
                        "Active",

                    updatedAt:
                        serverTimestamp()

                }

            );


            alert(
                "✅ Task Status Changed To " +
                newStatus
            );


            await loadTasks();

        }

        catch (error) {

            console.error(
                "Toggle Task Error:",
                error
            );


            alert(
                "❌ Status Update Failed: " +
                error.message
            );

        }

    };

// =====================================
// READY
// =====================================

console.log(
    "✅ NetEarn Pro Tasks Management V3 Loaded - Cloudinary"
);

console.log(
    "☁️ Cloudinary Cloud:",
    CLOUDINARY_CLOUD_NAME
);

console.log(
    "☁️ Cloudinary Preset:",
    CLOUDINARY_UPLOAD_PRESET
);