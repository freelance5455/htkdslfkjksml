// =======================================
// NetEarn Pro
// Admin Create / Edit Task
// Firebase Auth + Firestore
// Direct Image URL
// Form Fill Field Builder
// =======================================

import { auth, db } from "../js/firebase.js";
import { getBusinessSettings, getConfiguredTaskReward } from "../js/business-settings.js";

import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

import {
    collection,
    addDoc,
    getDoc,
    updateDoc,
    doc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =======================================
// ELEMENTS
// =======================================

const saveBtn =
    document.getElementById("saveTaskBtn");

const taskNameInput =
    document.getElementById("taskName");

const taskCategoryInput =
    document.getElementById("taskCategory");

const taskRewardInput =
    document.getElementById("taskReward");

const taskLinkInput =
    document.getElementById("taskLink");

const taskImageInput =
    document.getElementById("taskImage");

const taskDescriptionInput =
    document.getElementById("taskDescription");

const typingTextInput =
    document.getElementById("typingText");

const taskReferralInput =
    document.getElementById("taskReferral");

const taskImagePreviewBox =
    document.getElementById("taskImagePreviewBox");

const formFillFieldsGroup =
    document.getElementById("formFillFieldsGroup");

const formFieldsContainer =
    document.getElementById("formFieldsContainer");

const addFormFieldBtn =
    document.getElementById("addFormFieldBtn");

const taskImagePreview =
    document.getElementById("taskImagePreview");


// =======================================
// EDIT MODE
// =======================================

const urlParams =
    new URLSearchParams(
        window.location.search
    );

const editTaskId =
    urlParams.get("edit");

const isEditMode =
    Boolean(editTaskId);


// =======================================
// STATE
// =======================================

let currentUser = null;

let formFillFields = [];

let originalTaskData = null;

let isLoadingTask = false;


// =======================================
// DEFAULT TASK TIME
// =======================================

const DEFAULT_TIME_LIMIT = 300;


// =======================================
// CENTRAL TASK REWARD
// =======================================

async function syncCentralRewardToInput() {
    if (!taskCategoryInput || !taskRewardInput) return;

    const category = normalizeCategory(taskCategoryInput.value || "");
    if (!category) return;

    if (["Typing", "Photo Editing", "Form Fill"].includes(category)) {
        const settings = await getBusinessSettings({ force: true });
        taskRewardInput.value = String(getConfiguredTaskReward({ category }, settings));
    }
}

// =======================================
// AUTH
// =======================================


if (taskCategoryInput) {
    taskCategoryInput.addEventListener("change", () => {
        syncCentralRewardToInput().catch(error =>
            console.warn("Central task reward sync failed:", error)
        );
    });
}

onAuthStateChanged(
    auth,
    async (user) => {

        if (!user) {

            await alert(
                "🔒 Admin login পাওয়া যায়নি।"
            );

            window.location.href =
                "login.html";

            return;

        }

        currentUser =
            user;

        console.log(
            "✅ Admin authenticated:",
            user.uid
        );


        // ===================================
        // LOAD EDIT TASK
        // ===================================

        if (isEditMode) {

            await loadTaskForEdit(
                editTaskId
            );

        }

    }
);


// =======================================
// PAGE MODE UI
// =======================================

function updatePageModeUI() {

    if (!isEditMode) {

        if (saveBtn) {

            saveBtn.textContent =
                "💾 Save Task";

        }

        return;

    }


    if (saveBtn) {

        saveBtn.textContent =
            "💾 Update Task";

    }


    // Optional page title updates

    const pageTitle =
        document.querySelector(
            ".page-title-card h2"
        );


    if (pageTitle) {

        pageTitle.textContent =
            "Edit Task";

    }


    const pageDescription =
        document.querySelector(
            ".page-title-card p"
        );


    if (pageDescription) {

        pageDescription.textContent =
            "Update and manage this existing task.";

    }


    const mainTitle =
        document.querySelector(
            ".admin-header h1"
        );


    if (mainTitle) {

        mainTitle.textContent =
            "Edit Task";

    }

}


// =======================================
// LOAD TASK FOR EDIT
// =======================================

async function loadTaskForEdit(id) {

    if (!id) {

        return;

    }


    if (isLoadingTask) {

        return;

    }


    isLoadingTask = true;


    if (saveBtn) {

        saveBtn.disabled =
            true;

        saveBtn.textContent =
            "⏳ Loading Task...";

    }


    try {

        console.log(
            "🔎 Loading task for edit:",
            id
        );


        const taskRef =
            doc(
                db,
                "tasks",
                id
            );


        const taskSnap =
            await getDoc(
                taskRef
            );


        if (!taskSnap.exists()) {

            await alert(
                "❌ এই Task পাওয়া যায়নি।"
            );

            window.location.href =
                "admin-tasks.html";

            return;

        }


        originalTaskData =
            taskSnap.data();


        console.log(
            "📦 Existing Task:",
            originalTaskData
        );


        // =================================
        // LOAD BASIC VALUES
        // =================================

        if (taskNameInput) {

            taskNameInput.value =
                originalTaskData.title ||
                originalTaskData.name ||
                originalTaskData.taskName ||
                "";

        }


        // =================================
        // CATEGORY
        // =================================

        const savedCategory =
            normalizeCategory(
                originalTaskData.category ||
                originalTaskData.taskType ||
                ""
            );


        if (taskCategoryInput) {

            taskCategoryInput.value =
                savedCategory;

        }


        // =================================
        // REWARD
        // =================================

        if (taskRewardInput) {
            if (["Typing", "Photo Editing", "Form Fill"].includes(savedCategory)) {
                await syncCentralRewardToInput();
            } else {
                taskRewardInput.value = originalTaskData.reward ?? "";
            }
        }


        // =================================
        // TASK LINK
        // =================================

        if (taskLinkInput) {

            taskLinkInput.value =
                originalTaskData.link ||
                "";

        }


        // =================================
        // IMAGE URL
        // =================================

        if (taskImageInput) {

            taskImageInput.value =
                originalTaskData.taskImage ||
                originalTaskData.imageUrl ||
                originalTaskData.sourceImage ||
                originalTaskData.image ||
                "";

        }


        // =================================
        // DESCRIPTION
        // =================================

        if (taskDescriptionInput) {

            taskDescriptionInput.value =
                originalTaskData.description ||
                "";

        }


        // =================================
        // TYPING TEXT
        // =================================

        if (typingTextInput) {

            typingTextInput.value =
                originalTaskData.typingText ||
                originalTaskData.textToType ||
                "";

        }


        // =================================
        // REFERRAL
        // =================================

        if (taskReferralInput) {

            taskReferralInput.value =
                originalTaskData.referralNeed ??
                0;

        }


        // =================================
        // FORM FILL FIELDS
        // =================================

        const savedFields =
            Array.isArray(
                originalTaskData.formFields
            )

            ?

            originalTaskData.formFields

            :

            [];


        formFillFields =
            savedFields.map(
                field => ({

                    label:
                        field?.label ||
                        "",

                    type:
                        field?.type ||
                        "text",

                    required:
                        field?.required !== false

                })
            );


        // =================================
        // DISPLAY CATEGORY-SPECIFIC UI
        // =================================

        updateCategoryUI();


        // =================================
        // RENDER FORM FIELDS
        // =================================

        renderFormFields();


        // =================================
        // IMAGE PREVIEW
        // =================================

        updateImagePreview();


        // =================================
        // PAGE UI
        // =================================

        updatePageModeUI();


        console.log(
            "✅ Task loaded for editing"
        );

    }

    catch (error) {

        console.error(
            "❌ Load Edit Task Error:",
            error
        );


        alert(
            "❌ Task edit data load করা যায়নি।\n\n" +
            error.message
        );

    }

    finally {

        isLoadingTask =
            false;


        if (saveBtn) {

            saveBtn.disabled =
                false;

            saveBtn.textContent =
                isEditMode
                    ? "💾 Update Task"
                    : "💾 Save Task";

        }

    }

}


// =======================================
// NORMALIZE CATEGORY
// =======================================

function normalizeCategory(category) {

    const value =
        String(
            category ||
            ""
        ).trim();


    // Form Fill compatibility

    if (
        value.toLowerCase() ===
        "form filling"
    ) {

        return "Form Fill";

    }


    if (
        value.toLowerCase() ===
        "form_fill"
    ) {

        return "Form Fill";

    }


    if (
        value.toLowerCase() ===
        "form-fill"
    ) {

        return "Form Fill";

    }


    if (
        value.toLowerCase() ===
        "photo_editing"
    ) {

        return "Photo Editing";

    }


    return value;

}


// =======================================
// IMAGE PREVIEW
// =======================================

function updateImagePreview() {

    const url =
        taskImageInput?.value.trim() ||
        "";


    if (!url) {

        if (taskImagePreviewBox) {

            taskImagePreviewBox.style.display =
                "none";

        }

        if (taskImagePreview) {

            taskImagePreview.src =
                "";

        }

        return;

    }


    if (!taskImagePreview) {

        return;

    }


    taskImagePreview.src =
        url;


    taskImagePreview.onload =
        () => {

            if (taskImagePreviewBox) {

                taskImagePreviewBox.style.display =
                    "block";

            }

        };


    taskImagePreview.onerror =
        () => {

            if (taskImagePreviewBox) {

                taskImagePreviewBox.style.display =
                    "none";

            }

        };

}


// =======================================
// IMAGE INPUT PREVIEW
// =======================================

taskImageInput?.addEventListener(
    "input",
    () => {

        updateImagePreview();

    }
);


// =======================================
// CATEGORY UI
// =======================================

function updateCategoryUI() {

    const category =
        normalizeCategory(
            taskCategoryInput?.value ||
            ""
        );


    // ===================================
    // TYPING
    // ===================================

    const isTyping =
        category === "Typing";


    const typingTextGroup =
        document.getElementById(
            "typingTextGroup"
        );


    if (typingTextGroup) {

        typingTextGroup.style.display =
            isTyping
                ? "block"
                : "none";

    }


    // ===================================
    // FORM FILL
    // ===================================

    const isFormFill =
        category === "Form Fill";


    if (formFillFieldsGroup) {

        formFillFieldsGroup.style.display =
            isFormFill
                ? "block"
                : "none";

    }


    // ===================================
    // RENDER FORM FIELDS
    // ===================================

    if (isFormFill) {

        renderFormFields();

    }

}


// =======================================
// CATEGORY CHANGE
// =======================================

taskCategoryInput?.addEventListener(
    "change",
    () => {

        const category =
            normalizeCategory(
                taskCategoryInput.value
            );


        // =================================
        // TYPING
        // =================================

        const typingTextGroup =
            document.getElementById(
                "typingTextGroup"
            );


        if (typingTextGroup) {

            typingTextGroup.style.display =
                category === "Typing"
                    ? "block"
                    : "none";

        }


        // =================================
        // FORM FILL
        // =================================

        if (category === "Form Fill") {

            if (formFillFieldsGroup) {

                formFillFieldsGroup.style.display =
                    "block";

            }


            renderFormFields();

        }

        else {

            if (formFillFieldsGroup) {

                formFillFieldsGroup.style.display =
                    "none";

            }


            // IMPORTANT:
            // Do NOT clear formFillFields here.
            //
            // This allows admin to switch category
            // temporarily while editing and return
            // to Form Fill without losing fields.

        }


        // =================================
        // IMAGE
        // =================================

        updateImagePreview();

    }
);


// =======================================
// FORM FILL FIELD BUILDER
// =======================================

function renderFormFields() {

    if (!formFieldsContainer) {

        return;

    }


    formFieldsContainer.innerHTML =
        "";


    if (!formFillFields.length) {

        const emptyMessage =
            document.createElement(
                "div"
            );


        emptyMessage.className =
            "text-muted small py-2";


        emptyMessage.textContent =
            "No form fields added yet. Click “Add Form Field” to create one.";


        formFieldsContainer.appendChild(
            emptyMessage
        );


        return;

    }


    formFillFields.forEach(
        (field, index) => {

            const wrapper =
                document.createElement(
                    "div"
                );


            wrapper.className =
                "dynamic-form-field";


            // =================================
            // CREATE LABEL INPUT
            // =================================

            const labelInput =
                document.createElement(
                    "input"
                );


            labelInput.type =
                "text";

            labelInput.placeholder =
                "Field label";

            labelInput.value =
                field.label || "";

            labelInput.className =
                "form-field-label";

            labelInput.dataset.index =
                String(index);


            // =================================
            // CREATE TYPE SELECT
            // =================================

            const typeSelect =
                document.createElement(
                    "select"
                );


            typeSelect.className =
                "form-field-type";

            typeSelect.dataset.index =
                String(index);


            const types = [

                {
                    value: "text",
                    label: "Text"
                },

                {
                    value: "email",
                    label: "Email"
                },

                {
                    value: "number",
                    label: "Number"
                },

                {
                    value: "tel",
                    label: "Phone"
                },

                {
                    value: "date",
                    label: "Date"
                }

            ];


            types.forEach(
                optionData => {

                    const option =
                        document.createElement(
                            "option"
                        );


                    option.value =
                        optionData.value;


                    option.textContent =
                        optionData.label;


                    if (
                        field.type ===
                        optionData.value
                    ) {

                        option.selected =
                            true;

                    }


                    typeSelect.appendChild(
                        option
                    );

                }
            );


            // =================================
            // REQUIRED LABEL
            // =================================

            const requiredLabel =
                document.createElement(
                    "label"
                );


            requiredLabel.className =
                "form-field-required";


            const requiredCheck =
                document.createElement(
                    "input"
                );


            requiredCheck.type =
                "checkbox";

            requiredCheck.className =
                "form-field-required-check";

            requiredCheck.dataset.index =
                String(index);

            requiredCheck.checked =
                field.required !== false;


            requiredLabel.appendChild(
                requiredCheck
            );


            requiredLabel.appendChild(
                document.createTextNode(
                    " Required"
                )
            );


            // =================================
            // REMOVE BUTTON
            // =================================

            const removeButton =
                document.createElement(
                    "button"
                );


            removeButton.type =
                "button";

            removeButton.className =
                "remove-form-field";

            removeButton.dataset.index =
                String(index);

            removeButton.textContent =
                "❌";


            // =================================
            // APPEND
            // =================================

            wrapper.appendChild(
                labelInput
            );

            wrapper.appendChild(
                typeSelect
            );

            wrapper.appendChild(
                requiredLabel
            );

            wrapper.appendChild(
                removeButton
            );


            formFieldsContainer.appendChild(
                wrapper
            );

        }
    );


// =======================================
    // FIELD LABEL EVENTS
    // =======================================

    document
        .querySelectorAll(
            ".form-field-label"
        )
        .forEach(
            input => {

                input.addEventListener(
                    "input",
                    function () {

                        const index =
                            Number(
                                this.dataset.index
                            );


                        if (
                            formFillFields[index]
                        ) {

                            formFillFields[index].label =
                                this.value;

                        }

                    }
                );

            }
        );


    // =======================================
    // FIELD TYPE EVENTS
    // =======================================

    document
        .querySelectorAll(
            ".form-field-type"
        )
        .forEach(
            select => {

                select.addEventListener(
                    "change",
                    function () {

                        const index =
                            Number(
                                this.dataset.index
                            );


                        if (
                            formFillFields[index]
                        ) {

                            formFillFields[index].type =
                                this.value;

                        }

                    }
                );

            }
        );


    // =======================================
    // REQUIRED EVENTS
    // =======================================

    document
        .querySelectorAll(
            ".form-field-required-check"
        )
        .forEach(
            checkbox => {

                checkbox.addEventListener(
                    "change",
                    function () {

                        const index =
                            Number(
                                this.dataset.index
                            );


                        if (
                            formFillFields[index]
                        ) {

                            formFillFields[index].required =
                                this.checked;

                        }

                    }
                );

            }
        );


    // =======================================
    // REMOVE FIELD EVENTS
    // =======================================

    document
        .querySelectorAll(
            ".remove-form-field"
        )
        .forEach(
            button => {

                button.addEventListener(
                    "click",
                    function () {

                        const index =
                            Number(
                                this.dataset.index
                            );


                        if (
                            Number.isInteger(
                                index
                            )
                        ) {

                            formFillFields.splice(
                                index,
                                1
                            );

                        }


                        renderFormFields();

                    }
                );

            }
        );

}


// =======================================
// ADD FORM FIELD
// =======================================

addFormFieldBtn?.addEventListener(
    "click",
    () => {

        formFillFields.push({

            label:
                "",

            type:
                "text",

            required:
                true

        });


        renderFormFields();

    }
);


// =======================================
// SAVE / UPDATE BUTTON
// =======================================

saveBtn?.addEventListener(
    "click",
    saveTask
);


// =======================================
// SAVE TASK
// =======================================

async function saveTask() {

    console.log(
        "🟢 SAVE / UPDATE BUTTON CLICKED"
    );


    // ===================================
    // AUTH CHECK
    // ===================================

    if (!currentUser) {

        alert(
            "⚠️ Admin authentication পাওয়া যায়নি।\n\nকিছুক্ষণ অপেক্ষা করে আবার চেষ্টা করুন।"
        );

        return;

    }


    // ===================================
    // GET VALUES
    // ===================================

    const name =
        taskNameInput?.value.trim() ||
        "";


    const category =
        normalizeCategory(
            taskCategoryInput?.value ||
            ""
        );


    const reward =
        Number(
            taskRewardInput?.value
        );


    const link =
        taskLinkInput?.value.trim() ||
        "";


    const imageUrl =
        taskImageInput?.value.trim() ||
        "";


    const description =
        taskDescriptionInput?.value.trim() ||
        "";


    const typingText =
        typingTextInput?.value.trim() ||
        "";


    const referralNeed =
        Number(
            taskReferralInput?.value || 0
        );


    // ===================================
    // VALIDATION
    // ===================================

    if (!name) {

        alert(
            "📝 Task Name দিন।"
        );

        taskNameInput?.focus();

        return;

    }


    if (!category) {

        alert(
            "📂 Task Category নির্বাচন করুন।"
        );

        taskCategoryInput?.focus();

        return;

    }


    if (
        !reward ||
        reward <= 0
    ) {

        alert(
            "💰 সঠিক Task Reward দিন।"
        );

        taskRewardInput?.focus();

        return;

    }


    if (!description) {

        alert(
            "📄 Task Description / Instructions দিন।"
        );

        taskDescriptionInput?.focus();

        return;

    }


    // ===================================
    // TYPING VALIDATION
    // ===================================

    if (
        category === "Typing" &&
        !typingText
    ) {

        alert(
            "⌨️ Typing Task-এর জন্য Typing Text দিন।"
        );

        typingTextInput?.focus();

        return;

    }


    // ===================================
    // FORM FILL VALIDATION
    // ===================================

    if (
        category === "Form Fill"
    ) {

        if (
            !formFillFields.length
        ) {

            alert(
                "📝 Form Fill Task-এর জন্য অন্তত একটি Form Field যোগ করুন।"
            );

            addFormFieldBtn?.focus();

            return;

        }


        // Clean fields

        const cleanedFields =
            formFillFields.map(
                field => ({

                    label:
                        String(
                            field?.label ||
                            ""
                        ).trim(),

                    type:
                        field?.type ||
                        "text",

                    required:
                        field?.required !== false

                })
            );


        // Check empty labels

        const invalidField =
            cleanedFields.find(
                field =>
                    !field.label
            );


        if (invalidField) {

            alert(
                "⚠️ প্রতিটি Form Field-এর Label দিন।"
            );

            return;

        }


        // Allowed types

        const allowedTypes = [

            "text",
            "email",
            "number",
            "tel",
            "date"

        ];


        const invalidType =
            cleanedFields.find(
                field =>
                    !allowedTypes.includes(
                        field.type
                    )
            );


        if (invalidType) {

            alert(
                "❌ Form Field type সঠিক নয়।"
            );

            return;

        }


        formFillFields =
            cleanedFields;

    }


    // ===================================
    // PHOTO EDITING IMAGE
    // ===================================

    if (
        category ===
        "Photo Editing"
    ) {

        if (!imageUrl) {

            alert(
                "🖼️ Photo Editing Task-এর জন্য Task Image Link দিন।"
            );

            taskImageInput?.focus();

            return;

        }


        try {

            new URL(
                imageUrl
            );

        }

        catch {

            alert(
                "❌ Task Image Link সঠিক URL নয়।"
            );

            taskImageInput?.focus();

            return;

        }

    }


    // ===================================
    // OPTIONAL TASK LINK
    // ===================================

    if (link) {

        try {

            new URL(
                link
            );

        }

        catch {

            alert(
                "❌ Task Link সঠিক URL নয়।"
            );

            taskLinkInput?.focus();

            return;

        }

    }


    // ===================================
    // REFERRAL
    // ===================================

    const safeReferralNeed =
        Number.isFinite(
            referralNeed
        ) && referralNeed >= 0

            ?

            referralNeed

            :

            0;


    // ===================================
    // BUTTON LOADING
    // ===================================

    if (saveBtn) {

        saveBtn.disabled =
            true;

        saveBtn.textContent =
            isEditMode
                ? "⏳ Updating Task..."
                : "⏳ Saving Task...";

    }


    try {

        // =================================
        // COMMON TASK DATA
        // =================================

        const taskData = {

            title:
                name,

            name:
                name,

            category:
                category,

            description:
                description,

            reward:
                reward,

            link:
                link,

            referralNeed:
                safeReferralNeed

        };


        // =================================
        // TYPING DATA
        // =================================

        taskData.textToType =
            category === "Typing"
                ? typingText
                : "";

        taskData.typingText =
            category === "Typing"
                ? typingText
                : "";


        // =================================
        // FORM FILL DATA
        // =================================

        taskData.formFields =
            category === "Form Fill"
                ? formFillFields
                : [];


// =================================
// TASK IMAGE DATA
// =================================
//
// IMPORTANT:
// Image URL এখন সব Category-এর জন্য
// taskImage field-এ save হবে।
//
// Social / Micro Job / Photo Editing
// সব Task-এর Image এখান থেকে save হবে.
// =================================

if (imageUrl) {

    taskData.taskImage =
        imageUrl;

    taskData.imageType =
        "direct_url";

}

else if (
    isEditMode &&
    originalTaskData
) {

    // Edit করার সময় নতুন Image URL
    // না দিলে পুরোনো Image রেখে দেবে।

    if (
        originalTaskData.taskImage
    ) {

        taskData.taskImage =
            originalTaskData.taskImage;

    }

    else if (
        originalTaskData.imageUrl
    ) {

        taskData.taskImage =
            originalTaskData.imageUrl;

    }

    else if (
        originalTaskData.sourceImage
    ) {

        taskData.taskImage =
            originalTaskData.sourceImage;

    }


    if (
        originalTaskData.imageType
    ) {

        taskData.imageType =
            originalTaskData.imageType;

    }

}


// =================================
        // TIME LIMIT
        // =================================

        if (
            isEditMode &&
            originalTaskData
        ) {

            taskData.timeLimit =
                Number(
                    originalTaskData.timeLimit ||
                    originalTaskData.time ||
                    DEFAULT_TIME_LIMIT
                );

            taskData.time =
                Number(
                    originalTaskData.time ||
                    originalTaskData.timeLimit ||
                    DEFAULT_TIME_LIMIT
                );

        }

        else {

            taskData.timeLimit =
                DEFAULT_TIME_LIMIT;

            taskData.time =
                DEFAULT_TIME_LIMIT;

        }


        // =================================
        // STATUS
        // =================================

        if (
            isEditMode &&
            originalTaskData
        ) {

            // Preserve existing status

            if (
                typeof originalTaskData.status ===
                "string"
            ) {

                taskData.status =
                    originalTaskData.status;

            }

            else {

                taskData.status =
                    originalTaskData.active === false
                        ? "Inactive"
                        : "Active";

            }


            // Preserve old active flag

            if (
                typeof originalTaskData.active ===
                "boolean"
            ) {

                taskData.active =
                    originalTaskData.active;

            }

            else {

                taskData.active =
                    taskData.status ===
                    "Active";

            }

        }

        else {

            taskData.status =
                "Active";

            taskData.active =
                true;

        }


        // =================================
        // CREATED BY
        // =================================

        if (
            isEditMode &&
            originalTaskData?.createdBy
        ) {

            // Keep original creator

            taskData.createdBy =
                originalTaskData.createdBy;

        }

        else {

            taskData.createdBy =
                currentUser.uid;

        }


        // =================================
        // CREATED AT
        // =================================

        if (
            isEditMode &&
            originalTaskData?.createdAt
        ) {

            // IMPORTANT:
            // Do not change original creation time.

            taskData.createdAt =
                originalTaskData.createdAt;

        }

        else {

            taskData.createdAt =
                serverTimestamp();

        }


        console.log(
            "📦 Task data:",
            taskData
        );


        // =================================
        // CREATE NEW TASK
        // =================================

        if (!isEditMode) {

            const taskRef =
                await addDoc(

                    collection(
                        db,
                        "tasks"
                    ),

                    taskData

                );


            console.log(
                "✅ Task Created:",
                taskRef.id
            );


            alert(
                "🎉 Task Successfully Created!\n\n" +
                "Task ID: " +
                taskRef.id +
                "\n\n" +
                "Status: Active"
            );


            clearForm();


            return;

        }


        // =================================
        // UPDATE EXISTING TASK
        // =================================

        const taskRef =
            doc(
                db,
                "tasks",
                editTaskId
            );


        await updateDoc(
            taskRef,
            taskData
        );


        console.log(
            "✅ Task Updated:",
            editTaskId
        );


        await alert(
            "✅ Task Successfully Updated!\n\n" +
            "Task ID: " +
            editTaskId
        );


        // =================================
        // AFTER UPDATE
        // =================================

        window.location.href =
            "admin-tasks.html";

    }

    catch (error) {

        console.error(
            "❌ SAVE / UPDATE TASK ERROR:",
            error
        );


        alert(
            "❌ Task save/update করা যায়নি!\n\n" +
            error.message
        );

    }

    finally {

        if (saveBtn) {

            saveBtn.disabled =
                false;

            saveBtn.textContent =
                isEditMode
                    ? "💾 Update Task"
                    : "💾 Save Task";

        }

    }

}


// =======================================
// CLEAR FORM
// =======================================

function clearForm() {

    if (taskNameInput) {

        taskNameInput.value =
            "";

    }


    if (taskCategoryInput) {

        taskCategoryInput.value =
            "";

    }


    if (taskRewardInput) {

        taskRewardInput.value =
            "";

    }


    if (taskLinkInput) {

        taskLinkInput.value =
            "";

    }


    if (taskImageInput) {

        taskImageInput.value =
            "";

    }


    if (taskDescriptionInput) {

        taskDescriptionInput.value =
            "";

    }


    if (typingTextInput) {

        typingTextInput.value =
            "";

    }


    if (taskReferralInput) {

        taskReferralInput.value =
            "0";

    }


    if (taskImagePreview) {

        taskImagePreview.src =
            "";

    }


    if (taskImagePreviewBox) {

        taskImagePreviewBox.style.display =
            "none";

    }


    formFillFields =
        [];


    if (formFieldsContainer) {

        formFieldsContainer.innerHTML =
            "";

    }


    if (formFillFieldsGroup) {

        formFillFieldsGroup.style.display =
            "none";

    }


    const typingTextGroup =
        document.getElementById(
            "typingTextGroup"
        );


    if (typingTextGroup) {

        typingTextGroup.style.display =
            "none";

    }

}


// =======================================
// INITIAL UI
// =======================================

updatePageModeUI();


// =======================================
// READY
// =======================================

console.log(
    "✅ NetEarn Pro Admin Create / Edit Task JS Loaded"
);


console.log(
    isEditMode
        ? `✏️ EDIT MODE: ${editTaskId}`
        : "➕ CREATE MODE"
);


console.log(
    "🖼️ Direct Image URL System Ready"
);


console.log(
    "📝 Form Fill Management Ready"
);