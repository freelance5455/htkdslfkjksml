// =======================================
// NetEarn Pro
// Premium Subscription Management
// FINAL STABLE VERSION
//
// Premium Approval:
//
// users/{uid}
//   verified: true
//   premium: true
//   plan: "Lifetime Premium"
//   withdrawEnabled: true
//
// Request:
//
// subscriptionRequests/{uid}
//   status: "Approved"
//
// =======================================

import { auth, db } from "../js/firebase.js";

import { DEFAULT_BUSINESS_SETTINGS, getBusinessSettings } from "../js/business-settings.js";


import {
    onAuthStateChanged,
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

import {
    collection,
    getDocs,
    doc,
    getDoc,
    updateDoc,
    addDoc,
    serverTimestamp,
    query,
    where,
    increment,
    runTransaction,
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =======================================
// APP STATE
// =======================================

let allRequests = [];

let currentFilter =
    "all";


// =======================================
// AUTH
// =======================================

onAuthStateChanged(
    auth,
    async (user) => {

        if (!user) {

            window.location.href =
                "../login.html";

            return;

        }


        await loadPremiumData();

    }
);


// =======================================
// LOAD PREMIUM DATA
// =======================================

async function loadPremiumData() {

    try {

        const requestSnap =
            await getDocs(
                collection(
                    db,
                    "subscriptionRequests"
                )
            );


        allRequests =
            requestSnap.docs.map(
                requestDoc => ({

                    id:
                        requestDoc.id,

                    ...requestDoc.data()

                })
            );


        updateStats();

        applyCurrentFilter();

    }

    catch (error) {

        console.error(
            "❌ Premium Data Load Error:",
            error
        );

    }

}


// =======================================
// STATISTICS
// =======================================

async function updateStats() {

    let pending = 0;

    let approved = 0;

    let rejected = 0;


    allRequests.forEach(
        item => {

            const status =
                String(
                    item.status ||
                    "Pending"
                )
                .trim()
                .toLowerCase();


            if (
                status === "pending"
            ) {

                pending++;

            }

            else if (
                status === "approved"
            ) {

                approved++;

            }

            else if (
                status === "rejected"
            ) {

                rejected++;

            }

        }
    );


    const totalRequests =
        document.getElementById(
            "totalRequests"
        );

    const pendingRequests =
        document.getElementById(
            "pendingRequests"
        );

    const approvedRequests =
        document.getElementById(
            "approvedRequests"
        );

    const rejectedRequests =
        document.getElementById(
            "rejectedRequests"
        );


    if (totalRequests) {

        totalRequests.innerText =
            allRequests.length;

    }


    if (pendingRequests) {

        pendingRequests.innerText =
            pending;

    }


    if (approvedRequests) {

        approvedRequests.innerText =
            approved;

    }


    if (rejectedRequests) {

        rejectedRequests.innerText =
            rejected;

    }


    // ===================================
    // PREMIUM USERS
    // ===================================

    try {

        const usersSnap =
            await getDocs(
                collection(
                    db,
                    "users"
                )
            );


        let premiumUsers = 0;


        usersSnap.forEach(
            userDoc => {

                const userData =
                    userDoc.data();


                if (
                    userData.premium === true
                ) {

                    premiumUsers++;

                }

            }
        );


        const premiumUsersElement =
            document.getElementById(
                "premiumUsers"
            );


        if (premiumUsersElement) {

            premiumUsersElement.innerText =
                premiumUsers;

        }

    }

    catch (error) {

        console.error(
            "❌ Premium Users Count Error:",
            error
        );

    }

}


// =======================================
// FILTER
// =======================================

function applyCurrentFilter() {

    let filtered =
        [...allRequests];


    if (
        currentFilter !==
        "all"
    ) {

        filtered =
            allRequests.filter(
                item => {

                    const status =
                        String(
                            item.status ||
                            "Pending"
                        )
                        .trim()
                        .toLowerCase();


                    return (
                        status ===
                        currentFilter
                            .toLowerCase()
                    );

                }
            );

    }


    displayRequests(
        filtered
    );

}


// =======================================
// DISPLAY
// =======================================

function displayRequests(data) {

    const table =
        document.getElementById(
            "premiumTable"
        );


    if (!table) {

        return;

    }


    table.innerHTML =
        "";


    if (!data.length) {

        table.innerHTML = `

            <tr>

                <td
                    colspan="10"
                    class="text-center"
                >
                    No Request Found
                </td>

            </tr>

        `;

        return;

    }


    data.forEach(
        item => {

            const status =
                String(
                    item.status ||
                    "Pending"
                );


            const statusLower =
                status
                    .trim()
                    .toLowerCase();


            let action = "";


            // =================================
            // PENDING
            // =================================

            if (
                statusLower ===
                "pending"
            ) {

                action = `

                    <div class="action-btn">

                        <button
                            class="view-btn"
                            onclick="viewPremium('${escapeHtml(item.id)}')"
                        >
                            👁
                        </button>

                        <button
                            class="approve-btn"
                            onclick="approvePremium('${escapeHtml(item.id)}')"
                        >
                            ✅
                        </button>

                        <button
                            class="reject-btn"
                            onclick="rejectPremium('${escapeHtml(item.id)}')"
                        >
                            ❌
                        </button>

                    </div>

                `;

            }


            // =================================
            // APPROVED
            // =================================

            else if (
                statusLower ===
                "approved"
            ) {

                action = `

                    <span class="status approved">
                        👑 Premium Active
                    </span>

                `;

            }


            // =================================
            // REJECTED
            // =================================

            else {

                action = `

                    <span class="status rejected">
                        ❌ Rejected
                    </span>

                `;

            }


            table.innerHTML += `

                <tr>

                    <td>
                        ${escapeHtml(
                            item.name ||
                            "N/A"
                        )}
                    </td>

                    <td>
                        ${escapeHtml(
                            item.username ||
                            "N/A"
                        )}
                    </td>

                    <td>
                        ${escapeHtml(
                            item.email ||
                            "N/A"
                        )}
                    </td>

                    <td>
                        ${escapeHtml(
                            item.plan ||
                            "Lifetime Premium"
                        )}
                    </td>

                    <td>
                        ৳${Number(
                            item.amount ??
                            DEFAULT_BUSINESS_SETTINGS.premiumFee
                        ).toLocaleString("en-US")}
                    </td>

                    <td>
                        ${escapeHtml(
                            item.paymentMethod ||
                            "N/A"
                        )}
                    </td>

                    <td>
                        ${escapeHtml(
                            item.senderNumber ||
                            "N/A"
                        )}
                    </td>

                    <td>
                        ${escapeHtml(
                            item.transactionId ||
                            "N/A"
                        )}
                    </td>

                    <td>

                        <span
                            class="status ${escapeHtml(statusLower)}"
                        >
                            ${escapeHtml(status)}
                        </span>

                    </td>

                    <td>
                        ${action}
                    </td>

                </tr>

            `;

        }
    );

}


// =======================================
// ESCAPE HTML
// =======================================

function escapeHtml(value) {

    return String(value)

        .replaceAll(
            "&",
            "&amp;"
        )

        .replaceAll(
            "<",
            "&lt;"
        )

        .replaceAll(
            ">",
            "&gt;"
        )

        .replaceAll(
            '"',
            "&quot;"
        )

        .replaceAll(
            "'",
            "&#039;"
        );

}


// =======================================
// SEARCH
// =======================================

document
    .getElementById(
        "searchInput"
    )
    ?.addEventListener(
        "input",
        (event) => {

            const value =
                event.target.value
                    .toLowerCase()
                    .trim();


            let filtered =
                allRequests.filter(
                    item => {

                        return (

                            String(
                                item.name ||
                                ""
                            )
                            .toLowerCase()
                            .includes(value)

                            ||

                            String(
                                item.username ||
                                ""
                            )
                            .toLowerCase()
                            .includes(value)

                            ||

                            String(
                                item.email ||
                                ""
                            )
                            .toLowerCase()
                            .includes(value)

                            ||

                            String(
                                item.transactionId ||
                                ""
                            )
                            .toLowerCase()
                            .includes(value)

                            ||

                            String(
                                item.senderNumber ||
                                ""
                            )
                            .toLowerCase()
                            .includes(value)

                        );

                    }
                );


            if (
                currentFilter !==
                "all"
            ) {

                filtered =
                    filtered.filter(
                        item => {

                            return (

                                String(
                                    item.status ||
                                    "Pending"
                                )
                                .toLowerCase()
                                ===
                                currentFilter
                                    .toLowerCase()

                            );

                        }
                    );

            }


            displayRequests(
                filtered
            );

        }
    );


// =======================================
// FILTER STATUS
// =======================================

window.filterStatus =
function(status) {

    currentFilter =
        status;


    applyCurrentFilter();

};


// =======================================
// APPROVE PREMIUM
// =======================================

window.approvePremium =
async function(id) {

    try {

        // =================================
        // REQUEST
        // =================================

        const requestRef =
            doc(
                db,
                "subscriptionRequests",
                id
            );


        const snap =
            await getDoc(
                requestRef
            );


        if (!snap.exists()) {

            alert(
                "❌ Premium request পাওয়া যায়নি।"
            );

            return;

        }


        const data =
            snap.data();


        const userUid =
            data.uid;


        if (!userUid) {

            alert(
                "❌ User UID পাওয়া যায়নি।"
            );

            return;

        }


        // =================================
        // STATUS
        // =================================

        const currentStatus =
            String(
                data.status ||
                "Pending"
            )
            .trim()
            .toLowerCase();


        if (
            currentStatus !==
            "pending"
        ) {

            alert(
                "⚠️ এই request ইতিমধ্যে process করা হয়েছে।"
            );

            return;

        }


        // =================================
        // USER
        // =================================

        const userRef =
            doc(
                db,
                "users",
                userUid
            );


        const userSnap =
            await getDoc(
                userRef
            );


        if (!userSnap.exists()) {

            alert(
                "❌ User account পাওয়া যায়নি।"
            );

            return;

        }


        const userData =
            userSnap.data();


        // =================================
        // CONFIRM
        // =================================

        const confirmed =
            await NetEarnDialog.confirm(
                "👑 এই Premium request Approve করবেন?"
            );


        if (!confirmed) {

            return;

        }


        // =================================
        // CENTRAL BUSINESS SETTINGS
        // =================================

        const businessSettings =
            await getBusinessSettings();

        const referralBonus =
            Number(businessSettings.referralBonus || 0);


        // =================================
        // RESOLVE REFERRER ONCE
        // =================================

        let referrerUid =
            userData.referrerUid || "";

        if (!referrerUid && userData.referredBy) {
            const referralCode =
                String(userData.referredBy)
                    .trim()
                    .toUpperCase();

            const refQuery = query(
                collection(db, "users"),
                where("referralCode", "==", referralCode)
            );

            const refSnap = await getDocs(refQuery);
            if (!refSnap.empty) {
                referrerUid = refSnap.docs[0].id;
            }
        }

        if (referrerUid === userUid) {
            referrerUid = "";
        }


        // =================================
        // ATOMIC PREMIUM APPROVAL + REFERRAL
        //
        // The request document itself is the idempotency
        // guard. A second click cannot reward twice.
        // =================================

        await runTransaction(db, async transaction => {

            const latestRequestSnap =
                await transaction.get(requestRef);

            if (!latestRequestSnap.exists()) {
                throw new Error("Premium request পাওয়া যায়নি।");
            }

            const latestRequest = latestRequestSnap.data() || {};

            const alreadyApproved =
                String(latestRequest.status || "").toLowerCase() === "approved";

            if (alreadyApproved) {
                throw new Error("এই Premium request ইতিমধ্যে Approved হয়েছে।");
            }

            const alreadyRewarded =
                latestRequest.referralRewardGranted === true;

            const latestUserSnap =
                await transaction.get(userRef);

            if (!latestUserSnap.exists()) {
                throw new Error("User account পাওয়া যায়নি।");
            }

            const latestUserData = latestUserSnap.data() || {};
            let latestReferrerUid =
                latestUserData.referrerUid || referrerUid || "";

            let referrerSnap = null;
            if (latestReferrerUid && latestReferrerUid !== userUid) {
                const referrerRef = doc(db, "users", latestReferrerUid);
                referrerSnap = await transaction.get(referrerRef);
                if (!referrerSnap.exists()) {
                    latestReferrerUid = "";
                }
            }

            const approvedAt = serverTimestamp();

            transaction.update(userRef, {
                verified: true,
                premium: true,
                plan: "Lifetime Premium",
                withdrawEnabled: true,
                premiumActivatedAt: approvedAt
            });

            transaction.update(requestRef, {
                status: "Approved",
                approvedAt: approvedAt,
                referralRewardGranted:
                    alreadyRewarded || Boolean(
                        !alreadyRewarded &&
                        latestReferrerUid &&
                        referralBonus > 0
                    ),
                referralRewardAmount:
                    alreadyRewarded
                        ? Number(latestRequest.referralRewardAmount || referralBonus || 0)
                        : (latestReferrerUid ? referralBonus : 0)
            });

            const notificationRef = doc(collection(db, "notifications"));
            transaction.set(notificationRef, {
                uid: userUid,
                userId: userUid,
                userUid: userUid,
                title: "✅ Account Verified",
                message: "আপনার Account Verification সফল হয়েছে। আপনার Premium features এখন unlocked হয়েছে।",
                type: "verification",
                read: false,
                createdAt: approvedAt
            });

            if (
                !alreadyRewarded &&
                latestReferrerUid &&
                referralBonus > 0 &&
                referrerSnap?.exists()
            ) {
                const referrerRef = doc(db, "users", latestReferrerUid);
                const referrerData = referrerSnap.data() || {};

                transaction.update(referrerRef, {
                    balance: increment(referralBonus),
                    referralCommission: increment(referralBonus),
                    taskChance: increment(1)
                });

                const referralNotificationRef = doc(collection(db, "notifications"));
                transaction.set(referralNotificationRef, {
                    uid: latestReferrerUid,
                    userId: latestReferrerUid,
                    userUid: latestReferrerUid,
                    title: "🎉 Referral Reward",
                    message: `অভিনন্দন! আপনার referral member verification সম্পন্ন করেছে। আপনার Wallet-এ ৳${referralBonus} যোগ হয়েছে এবং ১টি Task Chance পাওয়া গেছে।`,
                    type: "referral_reward",
                    read: false,
                    createdAt: approvedAt
                });

                const transactionRef = doc(collection(db, "transactions"));
                transaction.set(transactionRef, {
                    uid: latestReferrerUid,
                    userId: referrerData.userId || null,
                    username: referrerData.username || referrerData.name || "User",
                    userName: referrerData.username || referrerData.name || "User",
                    title: "Referral Commission",
                    reason: "Member Verified Successfully",
                    amount: referralBonus,
                    type: "credit",
                    source: "referral",
                    status: "completed",
                    income: true,
                    createdAt: approvedAt
                });

                const incomeHistoryRef = doc(collection(db, "incomeHistory"));
                transaction.set(incomeHistoryRef, {
                    userUid: latestReferrerUid,
                    userId: referrerData.userId || null,
                    username: referrerData.username || referrerData.name || "User",
                    amount: referralBonus,
                    type: "credit",
                    source: "referral",
                    title: "Referral Commission",
                    reason: "Member Verified Successfully",
                    status: "approved",
                    createdAt: approvedAt
                });
            }
        });

        // =================================
        // SUCCESS
        // =================================

        alert(
            "✅ Premium Approved এবং Account Verified হয়েছে।"
        );


        await loadPremiumData();

    }

    catch (error) {

        console.error(
            "❌ Premium Approve Error:",
            error
        );


        alert(
            "❌ Premium Approve Failed:\n" +
            (
                error?.message ||
                "Unknown error"
            )
        );

    }

};


// =======================================
// REJECT PREMIUM
// =======================================

window.rejectPremium =
async function(id) {

    try {

        const requestRef =
            doc(
                db,
                "subscriptionRequests",
                id
            );


        const snap =
            await getDoc(
                requestRef
            );


        if (!snap.exists()) {

            alert(
                "❌ Premium request পাওয়া যায়নি।"
            );

            return;

        }


        const data =
            snap.data();


        const userUid =
            data.uid;


        if (!userUid) {

            alert(
                "❌ User UID পাওয়া যায়নি।"
            );

            return;

        }


        const currentStatus =
            String(
                data.status ||
                "Pending"
            )
            .trim()
            .toLowerCase();


        if (
            currentStatus !==
            "pending"
        ) {

            alert(
                "⚠️ এই request ইতিমধ্যে process করা হয়েছে।"
            );

            return;

        }


        const confirmed =
            await NetEarnDialog.confirm(
                "❌ এই Premium request Reject করবেন?"
            );


        if (!confirmed) {

            return;

        }


        // =================================
        // REJECT REQUEST
        // =================================

        await updateDoc(
            requestRef,
            {

                status:
                    "Rejected",

                rejectedAt:
                    serverTimestamp()

            }
        );


        // =================================
        // REJECTION NOTIFICATION
        // =================================

        await addDoc(
            collection(
                db,
                "notifications"
            ),
            {

                uid:
                    userUid,

                userId:
                    userUid,

                userUid:
                    userUid,

                title:
                    "❌ Premium Request Rejected",

                message:
                    "আপনার Premium Verification request অনুমোদিত হয়নি।",

                type:
                    "verification",

                read:
                    false,

                createdAt:
                    serverTimestamp()

            }
        );


        // =================================
        // SUCCESS
        // =================================

        alert(
            "❌ Premium request rejected হয়েছে।"
        );


        await loadPremiumData();

    }

    catch (error) {

        console.error(
            "❌ Premium Reject Error:",
            error
        );


        alert(
            "❌ Premium Reject Failed:\n" +
            (
                error?.message ||
                "Unknown error"
            )
        );

    }

};


// =======================================
// VIEW PREMIUM
// =======================================

window.viewPremium =
function(id) {

    const data =
        allRequests.find(
            item =>
                item.id === id
        );


    if (!data) {

        alert(
            "❌ Request পাওয়া যায়নি।"
        );

        return;

    }


    const mName =
        document.getElementById(
            "mName"
        );

    const mUsername =
        document.getElementById(
            "mUsername"
        );

    const mEmail =
        document.getElementById(
            "mEmail"
        );

    const mMethod =
        document.getElementById(
            "mMethod"
        );

    const mNumber =
        document.getElementById(
            "mNumber"
        );

    const mTransaction =
        document.getElementById(
            "mTransaction"
        );

    const mStatus =
        document.getElementById(
            "mStatus"
        );

    const mDate =
        document.getElementById(
            "mDate"
        );


    if (mName) {

        mName.innerText =
            data.name ||
            "N/A";

    }


    if (mUsername) {

        mUsername.innerText =
            data.username ||
            "N/A";

    }


    if (mEmail) {

        mEmail.innerText =
            data.email ||
            "N/A";

    }


    if (mMethod) {

        mMethod.innerText =
            data.paymentMethod ||
            "N/A";

    }


    if (mNumber) {

        mNumber.innerText =
            data.senderNumber ||
            "N/A";

    }


    if (mTransaction) {

        mTransaction.innerText =
            data.transactionId ||
            "N/A";

    }


    if (mStatus) {

        mStatus.innerText =
            data.status ||
            "Pending";

    }


    if (mDate) {

        if (data.createdAt?.toDate) {

            mDate.innerText =
                data.createdAt
                    .toDate()
                    .toLocaleString(
                        "en-BD",
                        {
                            dateStyle:
                                "medium",

                            timeStyle:
                                "short"
                        }
                    );

        }

        else {

            mDate.innerText =
                "Date not available";

        }

    }


    // =================================
    // OPEN MODAL
    // =================================

    const modal =
        document.getElementById(
            "premiumModal"
        );


    if (modal) {

        modal.style.display =
            "flex";

    }


    // =================================
    // MODAL APPROVE
    // =================================

    const modalApprove =
        document.getElementById(
            "modalApprove"
        );


    if (modalApprove) {

        modalApprove.onclick =
            () => {

                approvePremium(id);

            };

    }


    // =================================
    // MODAL REJECT
    // =================================

    const modalReject =
        document.getElementById(
            "modalReject"
        );


    if (modalReject) {

        modalReject.onclick =
            () => {

                rejectPremium(id);

            };

    }

};


// =======================================
// CLOSE MODAL
// =======================================

window.closeModal =
function() {

    const modal =
        document.getElementById(
            "premiumModal"
        );


    if (modal) {

        modal.style.display =
            "none";

    }

};


// =======================================
// INITIAL LOG
// =======================================

console.log(
    "✅ NetEarn Pro Premium Management — FINAL STABLE"
);