window.ADMIN_CONFIG={
  SUPABASE_URL:'https://whkwdlbmugodedanphwj.supabase.co',
  SUPABASE_ANON_KEY:'sb_publishable_qeRPnj5BHm2PO4Wr8Hb-Mw_wIRGmhzI'
};
