// =====================================================
// NetEarn Pro
// Admin Task Management
// FINAL CLEAN VERSION
// PART 1 / 3
//
// Task Management
// Tracking
// Firebase Firestore
// =====================================================


// =====================================================
// FIREBASE
// =====================================================

import {
    auth,
    db
} from "../js/firebase.js";

import {
    collection,
    getDocs,
    getDoc,
    deleteDoc,
    doc,
    updateDoc,
    query,
    where,
    addDoc,
    runTransaction,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

// =====================================================
// ADMIN CONFIG
// =====================================================




// =====================================================
// STATE
// =====================================================

let allTasks = [];

let currentSubmissionFilter =
    "pending";

let currentSubmissions = [];

let adminReady =
    false;


// =====================================================
// ELEMENTS
// =====================================================

const taskList =
    document.getElementById(
        "taskList"
    );


const taskSearch =
    document.getElementById(
        "taskSearch"
    );


const categoryFilter =
    document.getElementById(
        "categoryFilter"
    );


const statusFilter =
    document.getElementById(
        "statusFilter"
    );


const resetFilter =
    document.getElementById(
        "resetFilter"
    );


const totalTasks =
    document.getElementById(
        "totalTasks"
    );


const activeTasks =
    document.getElementById(
        "activeTasks"
    );


const inactiveTasks =
    document.getElementById(
        "inactiveTasks"
    );


const pendingSubmissions =
    document.getElementById(
        "pendingSubmissions"
    );


const taskDetailsContent =
    document.getElementById(
        "taskDetailsContent"
    );


const submissionList =
    document.getElementById(
        "submissionList"
    );


const submissionSummary =
    document.getElementById(
        "submissionSummary"
    );


const submissionTaskName =
    document.getElementById(
        "submissionTaskName"
    );


// =====================================================
// MODALS
// =====================================================

const taskDetailsModalElement =
    document.getElementById(
        "taskDetailsModal"
    );


const submissionModalElement =
    document.getElementById(
        "submissionModal"
    );


const taskDetailsModal =
    taskDetailsModalElement &&
    typeof bootstrap !== "undefined"

        ? new bootstrap.Modal(
            taskDetailsModalElement
        )

        : null;


const submissionModal =
    submissionModalElement &&
    typeof bootstrap !== "undefined"

        ? new bootstrap.Modal(
            submissionModalElement
        )

        : null;


// =====================================================
// ADMIN CHECK
// =====================================================

function isAdmin() {

    const user =
        auth.currentUser;


    return Boolean(user && adminReady);

}


// =====================================================
// AUTH READY
// =====================================================

function requireAdmin() {

    if (!auth.currentUser) {

        console.error(
            "❌ Firebase user not authenticated."
        );

        return false;

    }


    if (!adminReady) {
        console.error("❌ Unauthorized admin account:", auth.currentUser.email);
        return false;
    }


    return true;

}


// =====================================================
// AUTH DEBUG
// =====================================================

console.log(
    "🔥 Admin Tasks JS Loaded"
);


console.log("🔥 Admin identity: central admins/superadmin document");


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHTML(value) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// =====================================================
// TASK ACTIVE CHECK
// =====================================================

function isTaskActive(task) {

    if (!task) {

        return false;

    }


    if (
        typeof task.status ===
        "string"
    ) {

        const status =
            task.status
                .trim()
                .toLowerCase();


        if (
            status === "active"
        ) {

            return true;

        }


        if (
            status === "inactive"
        ) {

            return false;

        }

    }


    if (
        typeof task.active ===
        "boolean"
    ) {

        return task.active;

    }


    return false;

}


// =====================================================
// CATEGORY
// =====================================================

function getCategory(task) {

    if (!task) {

        return "Unknown";

    }


    const raw =
        task.category ||
        task.taskType ||
        "Unknown";


    const normalized =
        String(raw)
            .trim()
            .toLowerCase();


    if (
        normalized === "form filling" ||
        normalized === "form fill-up" ||
        normalized === "form fill up" ||
        normalized === "formfill"
    ) {

        return "Form Fill";

    }


    if (
        normalized === "typing work"
    ) {

        return "Typing";

    }


    if (
        normalized === "photo edit"
    ) {

        return "Photo Editing";

    }


    return String(raw).trim();

}


// =====================================================
// TASK NAME
// =====================================================

function getTaskName(task) {

    if (!task) {

        return "Untitled Task";

    }


    return (

        task.title ||
        task.name ||
        task.taskName ||
        "Untitled Task"

    );

}


// =====================================================
// IMAGE URL
// =====================================================

function getImageURL(task) {

    if (!task) {

        return "";

    }


    return (

        task.taskImage ||
        task.imageUrl ||
        task.sourceImage ||
        task.image ||
        ""

    );

}


// =====================================================
// REWARD
// =====================================================

function getTaskReward(task) {

    const reward =
        Number(
            task?.reward ||
            task?.taskReward ||
            0
        );


    return Number.isFinite(
        reward
    )
        ? reward
        : 0;

}


// =====================================================
// TIME
// DEFAULT TASK TIME = 5 MINUTES
// =====================================================

function getTaskTime(task) {

    const time =
        Number(
            task?.timeLimit ||
            task?.time ||
            5
        );


    return (
        Number.isFinite(time) &&
        time > 0
    )
        ? time
        : 5;

}


// =====================================================
// DATE FORMAT
// =====================================================

function formatDate(timestamp) {

    if (!timestamp) {

        return "—";

    }


    try {

        if (
            typeof timestamp.toDate ===
            "function"
        ) {

            return timestamp
                .toDate()
                .toLocaleString();

        }


        if (
            timestamp instanceof Date
        ) {

            return timestamp
                .toLocaleString();

        }


        if (
            timestamp.seconds !==
            undefined
        ) {

            return new Date(
                timestamp.seconds * 1000
            ).toLocaleString();

        }


        const date =
            new Date(timestamp);


        if (
            Number.isNaN(
                date.getTime()
            )
        ) {

            return "—";

        }


        return date.toLocaleString();

    }

    catch {

        return "—";

    }

}


// =====================================================
// LOAD TASKS
// =====================================================

async function loadTasks() {

    if (!requireAdmin()) {

        return;

    }


    if (!taskList) {

        console.error(
            "❌ #taskList পাওয়া যায়নি।"
        );

        return;

    }


    taskList.innerHTML = `

        <div class="empty-box">

            <div
                class="spinner-border text-primary mb-3"
            ></div>

            <h5>
                Loading Tasks...
            </h5>

            <p class="mb-0">
                Please wait...
            </p>

        </div>

    `;


    try {

        const snapshot =
            await getDocs(
                collection(
                    db,
                    "tasks"
                )
            );


        allTasks = [];


        snapshot.forEach(
            taskDoc => {

                allTasks.push({

                    id:
                        taskDoc.id,

                    ...taskDoc.data()

                });

            }
        );


        allTasks.sort(
            (a, b) => {

                const aTime =
                    a.createdAt?.seconds ||
                    0;


                const bTime =
                    b.createdAt?.seconds ||
                    0;


                return (
                    bTime -
                    aTime
                );

            }
        );


        updateStatistics();

        renderTasks();

    }

    catch (error) {

        console.error(
            "❌ Task Load Error:",
            error
        );


        taskList.innerHTML = `

            <div class="alert alert-danger">

                <strong>
                    ❌ Tasks load করা যায়নি।
                </strong>

                <br>

                <small>
                    ${escapeHTML(
                        error.message
                    )}
                </small>

            </div>

        `;

    }

}


// =====================================================
// STATISTICS
// =====================================================

function updateStatistics() {

    const total =
        allTasks.length;


    let active = 0;

    let inactive = 0;


    allTasks.forEach(
        task => {

            if (
                isTaskActive(task)
            ) {

                active++;

            }

            else {

                inactive++;

            }

        }
    );


    if (totalTasks) {

        totalTasks.textContent =
            String(total);

    }


    if (activeTasks) {

        activeTasks.textContent =
            String(active);

    }


    if (inactiveTasks) {

        inactiveTasks.textContent =
            String(inactive);

    }


    loadPendingSubmissionCount();

}


// =====================================================
// PENDING COUNT
// =====================================================

async function loadPendingSubmissionCount() {

    if (!pendingSubmissions) {

        return;

    }


    if (!requireAdmin()) {

        return;

    }


    try {

        const snapshot =
            await getDocs(

                query(

                    collection(
                        db,
                        "taskSubmissions"
                    ),

                    where(
                        "status",
                        "==",
                        "pending"
                    )

                )

            );


        pendingSubmissions.textContent =
            String(
                snapshot.size
            );

    }

    catch (error) {

        console.error(
            "❌ Pending Count Error:",
            error
        );


        pendingSubmissions.textContent =
            "0";

    }

}


// =====================================================
// FILTER
// =====================================================

function getFilteredTasks() {

    const search =
        (
            taskSearch?.value ||
            ""
        )
        .trim()
        .toLowerCase();


    const selectedCategory =
        (
            categoryFilter?.value ||
            "all"
        )
        .trim()
        .toLowerCase();


    const selectedStatus =
        (
            statusFilter?.value ||
            "all"
        )
        .trim()
        .toLowerCase();


    return allTasks.filter(
        task => {

            const name =
                getTaskName(task)
                    .toLowerCase();


            const category =
                getCategory(task)
                    .toLowerCase();


            const matchesSearch =

                !search ||

                name.includes(search) ||

                category.includes(search);


            const matchesCategory =

                selectedCategory ===
                "all"

                ||

                category ===
                selectedCategory;


            const active =
                isTaskActive(task);


            const matchesStatus =

                selectedStatus ===
                "all"

                ||

                (
                    selectedStatus ===
                    "active" &&
                    active
                )

                ||

                (
                    selectedStatus ===
                    "inactive" &&
                    !active
                );


            return (

                matchesSearch &&
                matchesCategory &&
                matchesStatus

            );

        }
    );

}


// =====================================================
// RENDER TASKS
// =====================================================

function renderTasks() {

    if (!taskList) {

        return;

    }


    const tasks =
        getFilteredTasks();


    if (!tasks.length) {

        taskList.innerHTML = `

            <div class="empty-box">

                <div
                    style="font-size:45px;"
                >
                    📭
                </div>

                <h5 class="mt-3">
                    No Task Found
                </h5>

                <p class="mb-0">
                    Search/filter পরিবর্তন করে আবার চেষ্টা করুন।
                </p>

            </div>

        `;

        return;

    }


    taskList.innerHTML =
        tasks
            .map(createTaskCard)
            .join("");

}


// =====================================================
// CREATE TASK CARD
// =====================================================

function createTaskCard(task) {

    const id =
        task.id;

    const name =
        getTaskName(task);

    const category =
        getCategory(task);

    const reward =
        getTaskReward(task);

    const time =
        getTaskTime(task);

    const active =
        isTaskActive(task);

    const imageURL =
        getImageURL(task);


    const imageHTML =

        imageURL

        ?

        `
        <img
            src="${escapeHTML(imageURL)}"
            class="task-image"
            alt="Task Image"
            loading="lazy"
            onerror="this.style.display='none'"
        >
        `

        :

        `
        <div
            class="
                task-image
                d-flex
                align-items-center
                justify-content-center
            "
        >
            🖼️
        </div>
        `;


    const statusBadge =

        active

        ?

        `
        <span class="badge-soft badge-active">
            🟢 ACTIVE
        </span>
        `

        :

        `
        <span class="badge-soft badge-inactive">
            🔴 INACTIVE
        </span>
        `;


    const toggleText =
        active
            ? "⏸ Disable"
            : "▶ Activate";


    const toggleClass =
        active
            ? "btn-outline-warning"
            : "btn-outline-success";


    return `

        <div class="task-card">

            <div class="row g-4 align-items-center">

                <div class="col-md-2">

                    ${imageHTML}

                </div>


                <div class="col-md-5">

                    <div class="task-title">
                        ${escapeHTML(name)}
                    </div>


                    <div class="task-meta mb-2">

                        <strong>
                            Category:
                        </strong>

                        ${escapeHTML(category)}

                    </div>


                    <div
                        class="
                            d-flex
                            flex-wrap
                            gap-2
                            mb-2
                        "
                    >

                        <span
                            class="badge bg-light text-dark"
                        >
                            💰 ৳${reward}
                        </span>


                        <span
                            class="badge bg-light text-dark"
                        >
                            ⏱️ ${time} Min
                        </span>


                        <span
                            class="badge bg-light text-dark"
                        >
                            🆔 ${escapeHTML(id)}
                        </span>

                    </div>


                    ${statusBadge}

                </div>


                <div class="col-md-2">

                    <div class="detail-label">
                        Created
                    </div>

                    <div class="detail-value">

                        ${escapeHTML(
                            formatDate(
                                task.createdAt
                            )
                        )}

                    </div>

                </div>


                <div class="col-md-3">

                    <div class="d-grid gap-2">

                        <button
                            type="button"
                            class="btn btn-primary"
                            onclick="viewTask('${escapeHTML(id)}')"
                        >
                            👁️ View Details
                        </button>


                        <button
                            type="button"
                            class="btn btn-info text-white"
                            onclick="viewSubmissions('${escapeHTML(id)}')"
                        >
                            📊 Tracking
                        </button>


                        <button
                            type="button"
                            class="btn ${toggleClass}"
                            onclick="toggleTask('${escapeHTML(id)}', ${active})"
                        >
                            ${toggleText}
                        </button>


                        <button
                            type="button"
                            class="btn btn-outline-primary"
                            onclick="editTask('${escapeHTML(id)}')"
                        >
                            ✏️ Edit Task
                        </button>


                        <button
                            type="button"
                            class="btn btn-outline-danger"
                            onclick="deleteTask('${escapeHTML(id)}')"
                        >
                            🗑️ Delete
                        </button>

                    </div>

                </div>

            </div>

        </div>

    `;

}


// =====================================================
// PART 1 READY
// =====================================================

console.log(
    "🟢 Admin Tasks Final - Part 1 loaded"
);

// =====================================================
// VIEW TASK DETAILS
// =====================================================

window.viewTask =
async function(id) {

    const task =
        allTasks.find(
            item =>
                item.id === id
        );


    if (!task) {

        alert(
            "❌ Task পাওয়া যায়নি।"
        );

        return;

    }


    const name =
        getTaskName(task);

    const category =
        getCategory(task);

    const reward =
        getTaskReward(task);

    const time =
        getTaskTime(task);

    const active =
        isTaskActive(task);

    const imageURL =
        getImageURL(task);


    const imageHTML =

        imageURL

        ?

        `
        <img
            src="${escapeHTML(imageURL)}"
            class="img-fluid rounded-4"
            style="
                max-height:350px;
                width:100%;
                object-fit:contain;
                background:#f8fafc;
            "
            alt="Task Image"
        >
        `

        :

        `
        <div
            class="
                d-flex
                align-items-center
                justify-content-center
                rounded-4
            "
            style="
                height:250px;
                background:#f1f5f9;
                font-size:60px;
            "
        >
            🖼️
        </div>
        `;


    let formFieldsHTML = "";


    if (
        category === "Form Fill"
    ) {

        const fields =
            Array.isArray(
                task.formFields
            )
                ? task.formFields
                : [];


        if (fields.length) {

            formFieldsHTML = `

                <div class="col-12">

                    <div class="detail-label">
                        Form Fields
                    </div>

                    <div class="mt-2">

                        ${
                            fields
                                .map(
                                    (field, index) => {

                                        const label =
                                            field?.label ||
                                            `Field ${index + 1}`;

                                        const type =
                                            field?.type ||
                                            "text";

                                        const required =
                                            field?.required !== false;


                                        return `

                                            <div
                                                class="
                                                    border
                                                    rounded-3
                                                    p-3
                                                    mb-2
                                                "
                                            >

                                                <div
                                                    class="fw-semibold"
                                                >
                                                    ${escapeHTML(label)}
                                                </div>

                                                <div
                                                    class="
                                                        small
                                                        text-muted
                                                    "
                                                >
                                                    Type:
                                                    ${escapeHTML(type)}

                                                    &nbsp; • &nbsp;

                                                    ${
                                                        required
                                                            ? "Required"
                                                            : "Optional"
                                                    }
                                                </div>

                                            </div>

                                        `;

                                    }
                                )
                                .join("")
                        }

                    </div>

                </div>

            `;

        }

    }


    let typingHTML = "";


    if (
        category === "Typing"
    ) {

        const typingText =
            task.textToType ||
            task.typingText ||
            "";


        typingHTML = `

            <div class="col-12">

                <div class="detail-label">
                    Typing Text
                </div>

                <div
                    class="
                        detail-value
                        border
                        rounded-3
                        p-3
                        mt-1
                    "
                    style="
                        white-space:pre-wrap;
                        word-break:break-word;
                    "
                >

                    ${escapeHTML(
                        typingText ||
                        "No typing text"
                    )}

                </div>

            </div>

        `;

    }


    const referralNeed =
        Number(
            task.referralNeed ||
            0
        );


    if (!taskDetailsContent) {

        return;

    }


    taskDetailsContent.innerHTML = `

        <div class="row g-4">

            <div class="col-md-5">

                ${imageHTML}

            </div>


            <div class="col-md-7">

                <h4 class="fw-bold mb-3">

                    ${escapeHTML(name)}

                </h4>


                <div class="row g-3">


                    <div class="col-6">

                        <div class="detail-label">
                            Category
                        </div>

                        <div class="detail-value">
                            ${escapeHTML(category)}
                        </div>

                    </div>


                    <div class="col-6">

                        <div class="detail-label">
                            Reward
                        </div>

                        <div class="detail-value">
                            ৳${reward}
                        </div>

                    </div>


                    <div class="col-6">

                        <div class="detail-label">
                            Time Limit
                        </div>

                        <div class="detail-value">
                            ${time} Min
                        </div>

                    </div>


                    <div class="col-6">

                        <div class="detail-label">
                            Status
                        </div>

                        <div class="detail-value">

                            ${
                                active
                                    ? "🟢 Active"
                                    : "🔴 Inactive"
                            }

                        </div>

                    </div>


                    <div class="col-6">

                        <div class="detail-label">
                            Referral Requirement
                        </div>

                        <div class="detail-value">
                            ${referralNeed}
                        </div>

                    </div>


                    <div class="col-6">

                        <div class="detail-label">
                            Image Type
                        </div>

                        <div class="detail-value">

                            ${escapeHTML(
                                task.imageType ||
                                "—"
                            )}

                        </div>

                    </div>


                    <div class="col-12">

                        <div class="detail-label">
                            Task ID
                        </div>

                        <div class="detail-value">
                            ${escapeHTML(id)}
                        </div>

                    </div>


                    <div class="col-12">

                        <div class="detail-label">
                            Description / Instructions
                        </div>

                        <div
                            class="
                                detail-value
                                border
                                rounded-3
                                p-3
                                mt-1
                            "
                            style="
                                white-space:pre-wrap;
                                word-break:break-word;
                            "
                        >

                            ${escapeHTML(
                                task.description ||
                                "No description"
                            )}

                        </div>

                    </div>


                    ${typingHTML}

                    ${formFieldsHTML}


                    ${
                        task.link

                        ?

                        `
                        <div class="col-12">

                            <div class="detail-label">
                                Task Link
                            </div>

                            <div class="detail-value">

                                <a
                                    href="${escapeHTML(task.link)}"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    ${escapeHTML(task.link)}
                                </a>

                            </div>

                        </div>
                        `

                        :

                        ""
                    }


                    <div class="col-12">

                        <div class="detail-label">
                            Created At
                        </div>

                        <div class="detail-value">

                            ${escapeHTML(
                                formatDate(
                                    task.createdAt
                                )
                            )}

                        </div>

                    </div>

                </div>

            </div>

        </div>

    `;


    if (taskDetailsModal) {

        taskDetailsModal.show();

    }

};


// =====================================================
// EDIT TASK
// =====================================================

window.editTask =
async function(id) {

    if (!id) {

        await alert(
            "❌ Task ID পাওয়া যায়নি।"
        );

        return;

    }


    window.location.href =
        `admin-create-task.html?edit=${encodeURIComponent(id)}`;

};


// =====================================================
// TOGGLE TASK
// =====================================================

window.toggleTask =
async function(
    id,
    currentStatus
) {

    if (!requireAdmin()) {

        alert(
            "❌ Admin authentication পাওয়া যায়নি।"
        );

        return;

    }


    const task =
        allTasks.find(
            item =>
                item.id === id
        );


    if (!task) {

        alert(
            "❌ Task পাওয়া যায়নি।"
        );

        return;

    }


    const confirmed =
        await NetEarnDialog.confirm(

            currentStatus

                ?

                "⏸️ আপনি কি এই Task Disable করতে চান?"

                :

                "▶️ আপনি কি এই Task Activate করতে চান?"

        );


    if (!confirmed) {

        return;

    }


    try {

        const taskRef =
            doc(
                db,
                "tasks",
                id
            );


        const newStatus =
            !currentStatus;


        await updateDoc(

            taskRef,

            {

                status:
                    newStatus
                        ? "Active"
                        : "Inactive",

                active:
                    newStatus

            }

        );


        alert(

            newStatus

                ?

                "✅ Task Activated Successfully!"

                :

                "⏸️ Task Disabled Successfully!"

        );


        await loadTasks();

    }

    catch (error) {

        console.error(
            "❌ Toggle Task Error:",
            error
        );


        alert(
            "❌ Task status update করা যায়নি।\n\n" +
            error.message
        );

    }

};


// =====================================================
// DELETE TASK
// =====================================================

window.deleteTask =
async function(id) {

    if (!requireAdmin()) {

        alert(
            "❌ Admin authentication পাওয়া যায়নি।"
        );

        return;

    }


    const task =
        allTasks.find(
            item =>
                item.id === id
        );


    if (!task) {

        alert(
            "❌ Task পাওয়া যায়নি।"
        );

        return;

    }


    const name =
        getTaskName(task);


    const confirmed =
        await NetEarnDialog.confirm(

            `⚠️ আপনি কি "${name}" Task delete করতে চান?\n\n` +

            "Task delete করলে এটি Task list থেকে চলে যাবে।\n\n" +

            "Existing taskSubmissions automatically delete হবে না।"

        );


    if (!confirmed) {

        return;

    }


    try {

        await deleteDoc(

            doc(
                db,
                "tasks",
                id
            )

        );


        alert(
            "🗑️ Task Deleted Successfully!"
        );


        await loadTasks();

    }

    catch (error) {

        console.error(
            "❌ Delete Task Error:",
            error
        );


        alert(
            "❌ Task delete করা যায়নি।\n\n" +
            error.message
        );

    }

};


// =====================================================
// VIEW SUBMISSIONS / TRACKING
// =====================================================

window.viewSubmissions =
async function(taskId) {

    if (!requireAdmin()) {

        alert(
            "❌ Admin authentication পাওয়া যায়নি।"
        );

        return;

    }


    const task =
        allTasks.find(
            item =>
                item.id === taskId
        );


    if (!task) {

        alert(
            "❌ Task পাওয়া যায়নি।"
        );

        return;

    }


    currentSubmissionFilter =
        "pending";


    currentSubmissions =
        [];


    if (submissionTaskName) {

        submissionTaskName.textContent =
            getTaskName(task);

    }


    if (submissionSummary) {

        submissionSummary.innerHTML =
            "";

    }


    if (submissionList) {

        submissionList.innerHTML = `

            <div class="text-center py-5">

                <div
                    class="
                        spinner-border
                        text-primary
                    "
                ></div>

                <p class="mt-2">
                    Loading submissions...
                </p>

            </div>

        `;

    }


    if (submissionModal) {

        submissionModal.show();

    }


    try {

        // =============================================
        // LOAD SUBMISSIONS
        // =============================================

        const snapshot =
            await getDocs(

                query(

                    collection(
                        db,
                        "taskSubmissions"
                    ),

                    where(
                        "taskId",
                        "==",
                        taskId
                    )

                )

            );


        const submissions = [];


        // =============================================
        // PROCESS EACH SUBMISSION
        // =============================================

        for (
            const submissionDoc
            of snapshot.docs
        ) {

            const data =
                submissionDoc.data();


            // =========================================
            // USER UID
            // Supports OLD + NEW structure
            // =========================================

            const uid =
                data.uid ||
                data.userUid ||
                "";


            // =========================================
            // SUBMISSION USER ID
            // =========================================

            let userId =
                String(
                    data.userId ||
                    ""
                ).trim();


            // =========================================
            // SUBMISSION USERNAME
            // =========================================

            let username =
                String(

                    data.username ||
                    data.userName ||
                    data.name ||
                    ""

                ).trim();


            // =========================================
            // LOAD USER DOCUMENT
            // If ID / Name missing
            // =========================================

            if (
                uid &&
                (
                    !userId ||
                    !username
                )
            ) {

                try {

                    const userRef =
                        doc(
                            db,
                            "users",
                            uid
                        );


                    const userSnap =
                        await getDoc(
                            userRef
                        );


                    if (
                        userSnap.exists()
                    ) {

                        const userData =
                            userSnap.data();


                        // -----------------------------
                        // NETEARN USER ID
                        // -----------------------------

                        if (!userId) {

                            userId =
                                String(

                                    userData.userId ||
                                    ""

                                ).trim();

                        }


                        // -----------------------------
                        // USERNAME
                        // -----------------------------

                        if (!username) {

                            username =
                                String(

                                    userData.username ||
                                    userData.name ||
                                    ""

                                ).trim();

                        }

                    }

                }

                catch (userError) {

                    console.warn(

                        "⚠️ User data load failed:",

                        uid,

                        userError

                    );

                }

            }


            // =========================================
            // FINAL FALLBACK
            // =========================================

            if (!username) {

                username =
                    "Unknown User";

            }


            if (!userId) {

                userId =
                    "—";

            }


            // =========================================
            // FINAL SUBMISSION OBJECT
            // =========================================

            submissions.push({

                id:
                    submissionDoc.id,

                ...data,

                uid:
                    uid,

                userUid:
                    uid,

                userId:
                    userId,

                username:
                    username

            });

        }


        // =============================================
        // SORT BY SUBMITTED TIME
        // =============================================

        submissions.sort(
            (a, b) => {

                const aTime =
                    a.submittedAt?.seconds ||
                    a.createdAt?.seconds ||
                    0;


                const bTime =
                    b.submittedAt?.seconds ||
                    b.createdAt?.seconds ||
                    0;


                return (
                    bTime -
                    aTime
                );

            }
        );


        // =============================================
        // SAVE CURRENT SUBMISSIONS
        // =============================================

        currentSubmissions =
            submissions;


        // =============================================
        // RENDER SUMMARY
        // =============================================

        renderSubmissionSummary(
            submissions
        );


        // =============================================
        // RENDER SUBMISSIONS
        // =============================================

        renderSubmissions(
            submissions
        );

    }


    catch (error) {

        console.error(
            "❌ Submission Load Error:",
            error
        );


        if (submissionList) {

            submissionList.innerHTML = `

                <div class="alert alert-danger">

                    <strong>
                        ❌ Submission load করা যায়নি।
                    </strong>

                    <br>

                    <small>
                        ${escapeHTML(
                            error.message
                        )}
                    </small>

                </div>

            `;

        }

    }

};


// =====================================================
// SUBMISSION SUMMARY
// =====================================================

function renderSubmissionSummary(
    submissions
) {

    let pending = 0;

    let approved = 0;

    let rejected = 0;


    submissions.forEach(
        submission => {

            const status =
                String(
                    submission.status ||
                    "pending"
                )
                .trim()
                .toLowerCase();


            if (
                status === "approved"
            ) {

                approved++;

            }

            else if (
                status === "rejected"
            ) {

                rejected++;

            }

            else {

                pending++;

            }

        }
    );


    if (!submissionSummary) {

        return;

    }


    submissionSummary.innerHTML = `

        <div class="col-md-3">

            <div class="task-stat">

                <small>
                    📋 TOTAL
                </small>

                <h3>
                    ${submissions.length}
                </h3>

            </div>

        </div>


        <div class="col-md-3">

            <div class="task-stat">

                <small>
                    ⏳ PENDING
                </small>

                <h3 class="text-warning">
                    ${pending}
                </h3>

            </div>

        </div>


        <div class="col-md-3">

            <div class="task-stat">

                <small>
                    ✅ APPROVED
                </small>

                <h3 class="text-success">
                    ${approved}
                </h3>

            </div>

        </div>


        <div class="col-md-3">

            <div class="task-stat">

                <small>
                    ❌ REJECTED
                </small>

                <h3 class="text-danger">
                    ${rejected}
                </h3>

            </div>

        </div>

    `;

}


// =====================================================
// RENDER SUBMISSIONS
// =====================================================

function renderSubmissions(
    submissions
) {

    currentSubmissions =
        Array.isArray(submissions)
            ? submissions
            : [];


    const filtered =
        currentSubmissions.filter(
            submission => {

                const status =
                    String(
                        submission.status ||
                        "pending"
                    )
                    .trim()
                    .toLowerCase();


                if (
                    currentSubmissionFilter ===
                    "all"
                ) {

                    return true;

                }


                return (
                    status ===
                    currentSubmissionFilter
                );

            }
        );


    if (!submissionList) {

        return;

    }


    if (!filtered.length) {

        const filterName =
            currentSubmissionFilter ===
            "all"
                ? ""
                : currentSubmissionFilter;


        submissionList.innerHTML = `

            <div class="empty-box">

                <div
                    style="font-size:45px;"
                >
                    📭
                </div>

                <h5 class="mt-3">

                    No
                    ${escapeHTML(filterName)}
                    Submission Found

                </h5>

                <p class="mb-0">

                    এই category-তে কোনো
                    submission নেই।

                </p>

            </div>

        `;

        return;

    }


    filtered.sort(
        (a, b) => {

            const aTime =
                a.submittedAt?.seconds ||
                0;

            const bTime =
                b.submittedAt?.seconds ||
                0;


            return (
                bTime -
                aTime
            );

        }
    );


    submissionList.innerHTML =
        filtered
            .map(
                createSubmissionHTML
            )
            .join("");

}


// =====================================================
// PART 2 READY
// =====================================================

console.log(
    "🟢 Admin Tasks Final - Part 2 loaded"
);

// =====================================================
// CREATE USER NOTIFICATION
// =====================================================

async function createUserNotification({

    userUid,
    type,
    title,
    message,
    taskId = null,
    submissionId = null

}) {

    if (!userUid) {

        console.warn(
            "⚠️ Notification skipped: UID missing"
        );

        return;

    }


    try {

        await addDoc(

            collection(
                db,
                "notifications"
            ),

            {

                userUid:
                    userUid,

                type:
                    type,

                title:
                    title,

                message:
                    message,

                taskId:
                    taskId,

                submissionId:
                    submissionId,

                read:
                    false,

                createdAt:
                    serverTimestamp()

            }

        );


        console.log(
            "✅ Notification created:",
            type
        );

    }

    catch (error) {

        console.error(
            "❌ Notification Error:",
            error
        );

    }

}


// =====================================================
// CREATE SUBMISSION HTML
// =====================================================

function createSubmissionHTML(
    submission
) {

    const status =
        String(
            submission.status ||
            "pending"
        )
        .trim()
        .toLowerCase();


    let statusHTML = "";


    if (
        status === "approved"
    ) {

        statusHTML = `
            <span class="badge-soft badge-approved">
                ✅ APPROVED
            </span>
        `;

    }

    else if (
        status === "rejected"
    ) {

        statusHTML = `
            <span class="badge-soft badge-rejected">
                ❌ REJECTED
            </span>
        `;

    }

    else {

        statusHTML = `
            <span class="badge-soft badge-pending">
                ⏳ PENDING
            </span>
        `;

    }


    const imageURL =
    submission.proofImageUrl ||
    submission.editedImage ||
    submission.submittedImage ||
    submission.imageUrl ||
    submission.image ||
    "";


    const imageHTML =

        imageURL

        ?

        `
        <a
            href="${escapeHTML(imageURL)}"
            target="_blank"
            rel="noopener noreferrer"
        >

            <img
                src="${escapeHTML(imageURL)}"
                style="
                    width:90px;
                    height:70px;
                    object-fit:cover;
                    border-radius:10px;
                "
                alt="Submission"
                onerror="this.style.display='none'"
            >

        </a>
        `

        :

        `
        <div
            style="
                width:90px;
                height:70px;
                border-radius:10px;
                background:#f1f5f9;
                display:flex;
                align-items:center;
                justify-content:center;
            "
        >
            📄
        </div>
        `;


    const username =
    submission.username ||
    submission.userName ||
    submission.name ||
    "Unknown User";


const userId =
    submission.userId ||
    "—";

    const reward =
        Number(
            submission.reward ||
            0
        );


    const actionButtons =

        status === "pending"

        ?

        `
        <button
            type="button"
            class="btn btn-sm btn-outline-primary"
            onclick="viewSubmission('${escapeHTML(submission.id)}')"
        >
            👁 View
        </button>


        <button
            type="button"
            class="btn btn-sm btn-success"
            onclick="approveSubmission('${escapeHTML(submission.id)}')"
        >
            ✅ Approve
        </button>


        <button
            type="button"
            class="btn btn-sm btn-danger"
            onclick="rejectSubmission('${escapeHTML(submission.id)}')"
        >
            ❌ Reject
        </button>
        `

        :

        `
        <button
            type="button"
            class="btn btn-sm btn-outline-primary"
            onclick="viewSubmission('${escapeHTML(submission.id)}')"
        >
            👁 View
        </button>
        `;


    return `

        <div class="submission-row">

            <div class="row g-3 align-items-center">


                <div class="col-md-1">

                    ${imageHTML}

                </div>


                <div class="col-md-3">

                    <strong>
                        ${escapeHTML(username)}
                    </strong>

                    <div class="small text-muted">

                        ID:
                        ${escapeHTML(userId)}

                    </div>

                </div>


                <div class="col-md-2">

                    ${statusHTML}

                </div>


                <div class="col-md-2">

                    <div class="small text-muted">
                        Reward
                    </div>

                    <strong>
                        ৳${reward}
                    </strong>

                </div>


                <div class="col-md-2">

                    <div class="small text-muted">
                        Submitted
                    </div>

                    <strong>

                        ${escapeHTML(
                            formatDate(
                                submission.submittedAt
                            )
                        )}

                    </strong>

                </div>


                <div class="col-md-2">

                    <div class="d-grid gap-2">

                        ${actionButtons}

                    </div>

                </div>


            </div>

        </div>

    `;

}


// =====================================================
// VIEW SUBMISSION
// =====================================================

window.viewSubmission =
async function(id) {

    if (!requireAdmin()) {

        alert(
            "❌ Admin authentication পাওয়া যায়নি।"
        );

        return;

    }


    try {

        const submissionRef =
            doc(
                db,
                "taskSubmissions",
                id
            );


        const snap =
            await getDoc(
                submissionRef
            );


        if (!snap.exists()) {

            alert(
                "❌ Submission পাওয়া যায়নি।"
            );

            return;

        }


        const data =
            snap.data();


        const imageURL =
    data.proofImageUrl ||
    data.editedImage ||
    data.submittedImage ||
    data.imageUrl ||
    data.image ||
    "";


        const imageHTML =

            imageURL

            ?

            `
            <div class="mb-3">

                <img
                    src="${escapeHTML(imageURL)}"
                    class="img-fluid rounded-4"
                    style="
                        max-height:500px;
                        width:100%;
                        object-fit:contain;
                        background:#f8fafc;
                    "
                    alt="Submitted Image"
                >

            </div>


            <a
                href="${escapeHTML(imageURL)}"
                target="_blank"
                rel="noopener noreferrer"
                class="btn btn-outline-primary btn-sm"
            >
                🔗 Open Full Image
            </a>
            `

            :

            `
            <div class="text-center py-5">

                <div style="font-size:55px;">
                    📄
                </div>

                <p class="text-muted mb-0">
                    No preview available
                </p>

            </div>
            `;


        const status =
            String(
                data.status ||
                "pending"
            )
            .trim()
            .toLowerCase();


        const statusText =

            status === "approved"

                ? "🟢 APPROVED"

                :

            status === "rejected"

                ? "🔴 REJECTED"

                :

                "🟡 PENDING";


        const username =
    data.userName ||
    data.username ||
    data.name ||
    "Unknown";


        const userId =
            data.userId ||
            "—";


        const taskName =
            data.taskName ||
            data.taskTitle ||
            "—";


        const reward =
            Number(
                data.reward ||
                0
            );


        const rejectionReason =
            data.rejectionReason ||
            "";


        const proofText =
    data.proofNote ||
    data.proof ||
    data.answer ||
    data.submissionText ||
    data.text ||
    "";


        if (!taskDetailsContent) {

            return;

        }


        taskDetailsContent.innerHTML = `

            <div class="row g-4">


                <div class="col-lg-6">

                    ${imageHTML}


                    ${
                        proofText

                        ?

                        `
                        <div class="mt-4">

                            <div class="detail-label">
                                Submission / Proof
                            </div>

                            <div
                                class="detail-value"
                                style="
                                    white-space:pre-wrap;
                                    background:#f8fafc;
                                    padding:15px;
                                    border-radius:12px;
                                "
                            >

                                ${escapeHTML(proofText)}

                            </div>

                        </div>
                        `

                        :

                        ""
                    }

                </div>


                <div class="col-lg-6">

                    <h5 class="fw-bold mb-3">
                        📋 Submission Details
                    </h5>


                    <div class="row g-3">


                        <div class="col-6">

                            <div class="detail-label">
                                User
                            </div>

                            <div class="detail-value">
                                ${escapeHTML(username)}
                            </div>

                        </div>


                        <div class="col-6">

                            <div class="detail-label">
                                User ID
                            </div>

                            <div class="detail-value">
                                ${escapeHTML(userId)}
                            </div>

                        </div>


                        <div class="col-12">

                            <div class="detail-label">
                                Task
                            </div>

                            <div class="detail-value">
                                ${escapeHTML(taskName)}
                            </div>

                        </div>


                        <div class="col-6">

                            <div class="detail-label">
                                Reward
                            </div>

                            <div class="detail-value">
                                ৳${reward}
                            </div>

                        </div>


                        <div class="col-6">

                            <div class="detail-label">
                                Status
                            </div>

                            <div class="detail-value">
                                ${statusText}
                            </div>

                        </div>


                        <div class="col-6">

                            <div class="detail-label">
                                Submitted
                            </div>

                            <div class="detail-value">

                                ${escapeHTML(
                                    formatDate(
                                        data.submittedAt
                                    )
                                )}

                            </div>

                        </div>


                        ${
                            data.approvedAt

                            ?

                            `
                            <div class="col-6">

                                <div class="detail-label">
                                    Approved At
                                </div>

                                <div class="detail-value">

                                    ${escapeHTML(
                                        formatDate(
                                            data.approvedAt
                                        )
                                    )}

                                </div>

                            </div>
                            `

                            :

                            ""
                        }


                        ${
                            data.rejectedAt

                            ?

                            `
                            <div class="col-6">

                                <div class="detail-label">
                                    Rejected At
                                </div>

                                <div class="detail-value">

                                    ${escapeHTML(
                                        formatDate(
                                            data.rejectedAt
                                        )
                                    )}

                                </div>

                            </div>
                            `

                            :

                            ""
                        }


                        ${
                            rejectionReason

                            ?

                            `
                            <div class="col-12">

                                <div class="detail-label">
                                    Rejection Reason
                                </div>

                                <div
                                    class="detail-value"
                                    style="
                                        background:#fef2f2;
                                        padding:12px;
                                        border-radius:12px;
                                    "
                                >

                                    ${escapeHTML(
                                        rejectionReason
                                    )}

                                </div>

                            </div>
                            `

                            :

                            ""
                        }


                        <div class="col-12">

                            <div class="detail-label">
                                Submission ID
                            </div>

                            <div class="detail-value">
                                ${escapeHTML(id)}
                            </div>

                        </div>

                    </div>

                </div>

            </div>

        `;


        if (taskDetailsModal) {

            taskDetailsModal.show();

        }

    }

    catch (error) {

        console.error(
            "❌ View Submission Error:",
            error
        );


        alert(
            "❌ Submission details load করা যায়নি।"
        );

    }

};


// =====================================================
// APPROVE SUBMISSION
// REWARD + BALANCE + REWARD HISTORY + TRANSACTION
// =====================================================

window.approveSubmission =
async function (id) {

    // ================================================
    // ADMIN CHECK
    // ================================================

    if (!requireAdmin()) {

        alert(
            "❌ Admin authentication পাওয়া যায়নি।"
        );

        return;
    }


    // ================================================
    // VALIDATION
    // ================================================

    if (!id) {

        alert(
            "❌ Submission ID পাওয়া যায়নি।"
        );

        return;
    }


    // ================================================
    // CONFIRM
    // ================================================

    const confirmed =
        await NetEarnDialog.confirm(
            "আপনি কি এই submission Approve করতে চান?\n\n" +
            "Approve করলে user-এর Wallet Balance-এ reward যোগ হবে।"
        );


    if (!confirmed) {

        return;
    }


    // ================================================
    // REFERENCES / VARIABLES
    // ================================================

    const submissionRef =
        doc(
            db,
            "taskSubmissions",
            id
        );


    let approvedUserUid = null;

    let approvedTaskId = null;

    let approvedTaskName = "Task";

    let approvedReward = 0;


    try {

        // Current Admin Settings are the single source of truth
        // for Typing / Photo Editing / Form Fill rewards.
        const { getBusinessSettings, getConfiguredTaskReward } = await import("../js/business-settings.js");
        const businessSettings = await getBusinessSettings({ force: true });

        // ============================================
        // FIRESTORE TRANSACTION
        // ============================================

        await runTransaction(

            db,

            async transaction => {

                // ========================================
                // READ SUBMISSION
                // ========================================

                const submissionSnap =
                    await transaction.get(
                        submissionRef
                    );


                if (
                    !submissionSnap.exists()
                ) {

                    throw new Error(
                        "SUBMISSION_NOT_FOUND"
                    );

                }


                const submission =
                    submissionSnap.data();


                // ========================================
                // STATUS CHECK
                // ========================================

                const status =
                    String(
                        submission.status ||
                        "pending"
                    )
                    .trim()
                    .toLowerCase();


                if (
                    status !== "pending"
                ) {

                    throw new Error(
                        "ALREADY_PROCESSED"
                    );

                }


                // ========================================
                // USER UID
                // ========================================

                const userUid =
                    submission.userUid ||
                    submission.uid ||
                    null;


                if (!userUid) {

                    throw new Error(
                        "USER_UID_NOT_FOUND"
                    );

                }


                // ========================================
                // USER REFERENCE
                // ========================================

                const userRef =
                    doc(
                        db,
                        "users",
                        userUid
                    );


                // ========================================
                // READ USER
                // ========================================

                const userSnap =
                    await transaction.get(
                        userRef
                    );


                if (
                    !userSnap.exists()
                ) {

                    throw new Error(
                        "USER_NOT_FOUND"
                    );

                }


                const user =
                    userSnap.data();


                // ========================================
                // REWARD
                // ========================================

                const reward =
                    getConfiguredTaskReward(submission, businessSettings);


                if (
                    !Number.isFinite(reward) ||
                    reward <= 0
                ) {

                    throw new Error(
                        "INVALID_REWARD"
                    );

                }


                // ========================================
                // TASK INFORMATION
                // ========================================

                const taskId =
                    submission.taskId ||
                    null;


                const taskName =
                    submission.taskName ||
                    submission.taskTitle ||
                    "Task";


                // ========================================
                // CURRENT BALANCE
                //
                // IMPORTANT:
                // Firestore user document uses "balance"
                // NOT "mainBalance"
                // ========================================

                const currentBalance =
                    Number(
                        user.balance || 0
                    );


                if (
                    !Number.isFinite(
                        currentBalance
                    )
                ) {

                    throw new Error(
                        "INVALID_USER_BALANCE"
                    );

                }


                // ========================================
                // NEW BALANCE
                // ========================================

                const newBalance =
                    currentBalance +
                    reward;


                // ========================================
                // SAVE VARIABLES
                // ========================================

                approvedUserUid =
                    userUid;


                approvedTaskId =
                    taskId;


                approvedTaskName =
                    taskName;


                approvedReward =
                    reward;


                // ========================================
                // REWARD HISTORY REF
                // ========================================

                const rewardHistoryRef =
                    doc(
                        collection(
                            db,
                            "rewardHistory"
                        )
                    );


                // ========================================
                // TRANSACTION HISTORY REF
                // ========================================

                const transactionHistoryRef =
                    doc(
                        collection(
                            db,
                            "transactions"
                        )
                    );


                // ========================================
                // UPDATE SUBMISSION
                // ========================================

                transaction.update(

                    submissionRef,

                    {

                        status:
                            "approved",

                        approvedAt:
                            serverTimestamp(),

                        rewardPaid:
                            reward,

                        rewardPaidAt:
                            serverTimestamp()

                    }

                );


                // ========================================
                // UPDATE USER WALLET BALANCE
                //
                // IMPORTANT:
                // Use "balance"
                // ========================================

                transaction.update(

                    userRef,

                    {

                        balance:
                            newBalance,

                        totalEarnings:
                            Number(
                                user.totalEarnings || 0
                            ) + reward,

                        completedTasks:
                            Number(
                                user.completedTasks || 0
                            ) + 1

                    }

                );


                // ========================================
                // CREATE REWARD HISTORY
                // ========================================

                transaction.set(

                    rewardHistoryRef,

                    {

                        // -------------------------------
                        // USER
                        // -------------------------------

                        userUid:
                            userUid,

                        userId:
                            user.userId ||
                            null,

                        username:
                            user.username ||
                            null,


                        // -------------------------------
                        // TASK
                        // -------------------------------

                        taskId:
                            taskId,

                        submissionId:
                            id,

                        taskName:
                            taskName,


                        // -------------------------------
                        // REWARD
                        // -------------------------------

                        type:
                            "task_reward",

                        reward:
                            reward,


                        // -------------------------------
                        // BALANCE TRACKING
                        // -------------------------------

                        previousBalance:
                            currentBalance,

                        newBalance:
                            newBalance,


                        // -------------------------------
                        // STATUS
                        // -------------------------------

                        status:
                            "approved",


                        // -------------------------------
                        // DATE
                        // -------------------------------

                        createdAt:
                            serverTimestamp()

                    }

                );


                // ========================================
                // CREATE WALLET TRANSACTION
                // ========================================

                transaction.set(

                    transactionHistoryRef,

                    {

                        // -------------------------------
                        // USER
                        // -------------------------------

                        uid:
                            userUid,

                        userId:
                            user.userId ||
                            null,

                        username:
                            user.username ||
                            null,


                        // -------------------------------
                        // MONEY
                        // -------------------------------

                        amount:
                            reward,

                        type:
                            "credit",


                        // -------------------------------
                        // DESCRIPTION
                        // -------------------------------

                        reason:
                            `Task Reward - ${taskName}`,


                        // -------------------------------
                        // STATUS
                        // -------------------------------

                        status:
                            "Completed",


                        // -------------------------------
                        // TASK REFERENCE
                        // -------------------------------

                        taskId:
                            taskId,

                        submissionId:
                            id,


                        // -------------------------------
                        // BALANCE TRACKING
                        // -------------------------------

                        previousBalance:
                            currentBalance,

                        newBalance:
                            newBalance,


                        // -------------------------------
                        // DATE
                        // -------------------------------

                        createdAt:
                            serverTimestamp()

                    }

                );

            }

        );


        // ================================================
        // SUCCESS
        // ================================================

        alert(

            "🎉 Submission Approved Successfully!\n\n" +

            `💰 Reward: ৳${approvedReward}\n` +

            "💳 Wallet Balance Updated\n" +

            "📊 Reward History Added\n" +

            "📜 Transaction History Added"

        );


        // ================================================
        // USER NOTIFICATION
        // ================================================

        try {

            if (
                approvedUserUid &&
                typeof createUserNotification ===
                "function"
            ) {

                await createUserNotification({

                    userUid:
                        approvedUserUid,

                    type:
                        "task_approved",

                    title:
                        "🎉 Task Approved!",

                    message:
                        `অভিনন্দন! আপনার "${approvedTaskName}" Task Approve হয়েছে। ৳${approvedReward} Reward আপনার Wallet Balance-এ যোগ হয়েছে।`,

                    taskId:
                        approvedTaskId,

                    submissionId:
                        id

                });

            }

        } catch (
            notificationError
        ) {

            console.error(
                "⚠️ Notification Error:",
                notificationError
            );

        }


        // ================================================
        // REFRESH TRACKING
        // ================================================

        if (
            approvedTaskId
        ) {

            await refreshTracking(
                approvedTaskId
            );

        }


        // ================================================
        // REFRESH PENDING COUNT
        // ================================================

        if (
            typeof loadPendingSubmissionCount ===
            "function"
        ) {

            await loadPendingSubmissionCount();

        }

    }

    catch (error) {

        console.error(
            "❌ Approve Submission Error:",
            error
        );


        // ============================================
        // ERROR HANDLING
        // ============================================

        switch (
            error.message
        ) {

            case "SUBMISSION_NOT_FOUND":

                alert(
                    "❌ Submission পাওয়া যায়নি।"
                );

                break;


            case "ALREADY_PROCESSED":

                alert(
                    "⚠️ এই submission ইতিমধ্যে Approve/Reject করা হয়েছে।\n\n" +
                    "দ্বিতীয়বার reward দেওয়া হবে না।"
                );

                break;


            case "USER_UID_NOT_FOUND":

                alert(
                    "❌ Submission-এর User UID পাওয়া যায়নি।"
                );

                break;


            case "USER_NOT_FOUND":

                alert(
                    "❌ User data পাওয়া যায়নি।"
                );

                break;


            case "INVALID_REWARD":

                alert(
                    "❌ এই submission-এর reward সঠিক নয়।"
                );

                break;


            case "INVALID_USER_BALANCE":

                alert(
                    "❌ User-এর বর্তমান balance সঠিক নয়।"
                );

                break;


            default:

                alert(

                    "❌ Submission approve করা যায়নি।\n\n" +

                    error.message

                );

        }

    }

};



// =====================================================
// REJECT SUBMISSION
// =====================================================

window.rejectSubmission =
async function (id) {

    // ================================================
    // ADMIN CHECK
    // ================================================

    if (!requireAdmin()) {

        alert(
            "❌ Admin authentication পাওয়া যায়নি।"
        );

        return;
    }


    // ================================================
    // VALIDATION
    // ================================================

    if (!id) {

        alert(
            "❌ Submission ID পাওয়া যায়নি।"
        );

        return;
    }


    // ================================================
    // REJECTION REASON
    // ================================================

    const reason =
        await NetEarnDialog.prompt(
            "Reject করার কারণ লিখুন:"
        );


    if (
        reason === null
    ) {

        return;
    }


    const rejectionReason =
        String(
            reason
        ).trim();


    if (!rejectionReason) {

        alert(
            "⚠️ Reject করার কারণ লিখুন।"
        );

        return;
    }


    // ================================================
    // CONFIRM
    // ================================================

    const confirmed =
        await NetEarnDialog.confirm(

            "আপনি কি এই submission Reject করতে চান?\n\n" +

            "❌ Reject করলে কোনো reward দেওয়া হবে না।"

        );


    if (!confirmed) {

        return;
    }


    // ================================================
    // REFERENCES
    // ================================================

    const submissionRef =
        doc(
            db,
            "taskSubmissions",
            id
        );


    let rejectedUserUid =
        null;

    let rejectedTaskId =
        null;

    let rejectedTaskName =
        "Task";


    try {

        // ============================================
        // FIRESTORE TRANSACTION
        // ============================================

        await runTransaction(

            db,

            async transaction => {

                // ========================================
                // READ SUBMISSION
                // ========================================

                const submissionSnap =
                    await transaction.get(
                        submissionRef
                    );


                if (
                    !submissionSnap.exists()
                ) {

                    throw new Error(
                        "SUBMISSION_NOT_FOUND"
                    );

                }


                const submission =
                    submissionSnap.data();

                // ========================================
                // STATUS CHECK
                // ========================================

                const status =
                    String(
                        submission.status ||
                        "pending"
                    )
                    .trim()
                    .toLowerCase();


                if (
                    status !== "pending"
                ) {

                    throw new Error(
                        "ALREADY_PROCESSED"
                    );

                }


                // ========================================
                // USER / TASK DATA
                // ========================================

                rejectedUserUid =
                    submission.userUid ||
                    submission.uid ||
                    null;


                rejectedTaskId =
                    submission.taskId ||
                    null;


                rejectedTaskName =
                    submission.taskName ||
                    submission.taskTitle ||
                    "Task";


                // ========================================
                // UPDATE SUBMISSION
                // ========================================

                transaction.update(

                    submissionRef,

                    {

                        status:
                            "rejected",

                        rejectionReason:
                            rejectionReason,

                        rejectedAt:
                            serverTimestamp()

                    }

                );

            }

        );


        // ================================================
        // SUCCESS
        // ================================================

        alert(
            "❌ Submission Rejected Successfully."
        );


        // ================================================
        // USER NOTIFICATION
        // ================================================

        try {

            if (
                rejectedUserUid &&
                typeof createUserNotification ===
                "function"
            ) {

                await createUserNotification({

                    userUid:
                        rejectedUserUid,

                    type:
                        "task_rejected",

                    title:
                        "❌ Task Rejected",

                    message:
                        `আপনার "${rejectedTaskName}" Task Reject করা হয়েছে। কারণ: ${rejectionReason}`,

                    taskId:
                        rejectedTaskId,

                    submissionId:
                        id

                });

            }

        } catch (
            notificationError
        ) {

            console.error(
                "⚠️ Notification Error:",
                notificationError
            );

        }


        // ================================================
        // REFRESH TRACKING
        // ================================================

        if (
            rejectedTaskId
        ) {

            await refreshTracking(
                rejectedTaskId
            );

        }


        // ================================================
        // REFRESH PENDING COUNT
        // ================================================

        if (
            typeof loadPendingSubmissionCount ===
            "function"
        ) {

            await loadPendingSubmissionCount();

        }

    }

    catch (error) {

        console.error(
            "❌ Reject Submission Error:",
            error
        );


        switch (
            error.message
        ) {

            case "SUBMISSION_NOT_FOUND":

                alert(
                    "❌ Submission পাওয়া যায়নি।"
                );

                break;


            case "ALREADY_PROCESSED":

                alert(
                    "⚠️ এই submission ইতিমধ্যে process করা হয়েছে।"
                );

                break;


            default:

                alert(

                    "❌ Submission reject করা যায়নি।\n\n" +

                    error.message

                );

        }

    }

};



// =====================================================
// REFRESH TRACKING
// =====================================================

async function refreshTracking(
    taskId
) {

    if (!taskId) {

        return;
    }


    if (
        typeof viewSubmissions ===
        "function"
    ) {

        await viewSubmissions(
            taskId
        );

    }

}



// =====================================================
// TASK FILTER EVENTS
// =====================================================

if (taskSearch) {

    taskSearch.addEventListener(
        "input",
        renderTasks
    );

}


if (categoryFilter) {

    categoryFilter.addEventListener(
        "change",
        renderTasks
    );

}


if (statusFilter) {

    statusFilter.addEventListener(
        "change",
        renderTasks
    );

}


if (resetFilter) {

    resetFilter.addEventListener(
        "click",
        () => {

            if (taskSearch) {

                taskSearch.value =
                    "";

            }


            if (categoryFilter) {

                categoryFilter.value =
                    "all";

            }


            if (statusFilter) {

                statusFilter.value =
                    "all";

            }


            renderTasks();

        }
    );

}



// =====================================================
// SUBMISSION FILTER BUTTONS
// =====================================================

document
    .getElementById(
        "showPendingBtn"
    )
    ?.addEventListener(
        "click",
        () => {

            currentSubmissionFilter =
                "pending";


            renderSubmissions(
                currentSubmissions
            );

        }
    );



document
    .getElementById(
        "showApprovedBtn"
    )
    ?.addEventListener(
        "click",
        () => {

            currentSubmissionFilter =
                "approved";


            renderSubmissions(
                currentSubmissions
            );

        }
    );



document
    .getElementById(
        "showRejectedBtn"
    )
    ?.addEventListener(
        "click",
        () => {

            currentSubmissionFilter =
                "rejected";


            renderSubmissions(
                currentSubmissions
            );

        }
    );



document
    .getElementById(
        "showAllBtn"
    )
    ?.addEventListener(
        "click",
        () => {

            currentSubmissionFilter =
                "all";


            renderSubmissions(
                currentSubmissions
            );

        }
    );



// =====================================================
// AUTH STATE
// =====================================================

onAuthStateChanged(

    auth,

    async user => {

        console.log(
            "🔥 Auth State:",
            user?.uid ||
            "SIGNED OUT"
        );


        // ==============================================
        // SIGNED OUT
        // ==============================================

        if (!user) {

            adminReady =
                false;


            console.error(
                "❌ Admin not logged in."
            );


            return;

        }


        // ==============================================
        // CENTRAL ADMIN CHECK
        // ==============================================
        // Use the same Super Admin record/verification flow as the
        // working Admin Dashboard and Users page. Do not gate this page
        // on a separate admins/{currentUid} lookup.
        try {
            const adminSnap = await getDoc(
                doc(db, "admins", "superadmin")
            );

            const admin =
                adminSnap.exists()
                    ? adminSnap.data()
                    : null;

            const allowed =
                admin &&
                admin.active === true &&
                String(admin.role || "")
                    .trim()
                    .toLowerCase() === "super_admin" &&
                String(admin.email || "")
                    .trim()
                    .toLowerCase() ===
                String(user.email || "")
                    .trim()
                    .toLowerCase();

            if (!allowed) {
                adminReady = false;
                console.error(
                    "❌ This account is not the NetEarn Pro Super Admin."
                );

                if (taskList) {
                    taskList.innerHTML = `
                        <div class="alert alert-danger">
                            <strong>❌ Admin access could not be verified.</strong>
                            <br>
                            <small>Please sign in with the configured Super Admin account.</small>
                        </div>
                    `;
                }

                return;
            }
        } catch (error) {
            adminReady = false;
            console.error(
                "❌ Admin verification failed:",
                error
            );

            if (taskList) {
                taskList.innerHTML = `
                    <div class="alert alert-danger">
                        <strong>❌ Admin verification failed.</strong>
                        <br>
                        <small>${escapeHTML(error?.message || "Unable to verify admin access.")}</small>
                    </div>
                `;
            }

            return;
        }


        // ==============================================
        // ADMIN READY
        // ==============================================

        adminReady =
            true;


        console.log(
            "🟢 NetEarn Pro Admin authenticated."
        );


        // ==============================================
        // LOAD TASKS
        // ==============================================

        try {

            await loadTasks();

        }

        catch (error) {

            console.error(
                "❌ Task Loading Error:",
                error
            );

        }


        // ==============================================
        // LOAD PENDING COUNT
        // ==============================================

        try {

            await loadPendingSubmissionCount();

        }

        catch (error) {

            console.error(
                "❌ Pending Count Error:",
                error
            );

        }

    }

);



// =====================================================
// FINAL READY
// =====================================================

console.log(
    "======================================="
);

console.log(
    "✅ NetEarn Pro Admin Tasks"
);

console.log(
    "✅ FINAL CLEAN VERSION"
);

console.log(
    "📋 Task Management Ready"
);

console.log(
    "📊 Submission Tracking Ready"
);

console.log(
    "⏳ Pending / Approved / Rejected Ready"
);

console.log(
    "💰 Wallet Balance Reward System Ready"
);

console.log(
    "📜 Transaction History Ready"
);

console.log(
    "📊 Reward History Ready"
);

console.log(
    "🔔 Notification System Ready"
);

console.log(
    "======================================="
);