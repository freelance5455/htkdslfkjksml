# Admin panel (next stage)

This folder is reserved for the secure admin dashboard.

Required server-enforced roles:
- super_admin
- moderator
- room_host

The browser must never decide who is an admin. Use backend authorization and Firestore/Cloud Functions rules before enabling moderation actions.
