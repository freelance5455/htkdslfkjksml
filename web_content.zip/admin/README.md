# لوحة التحكم

ارفع هذا المجلد على استضافة HTTPS، ثم ضع بيانات Supabase العامة فقط في `config.js`.

الرابط بعد النشر يكون مثل:
`https://YOUR-DOMAIN/admin/`

الدخول يتم بحساب Supabase له `role='admin'` في جدول `profiles`.
