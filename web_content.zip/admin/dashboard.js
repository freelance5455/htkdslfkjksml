// =======================================
// NetEarn Pro — Admin Dashboard
// Safe / Optimized build
// =======================================

import { auth, db } from "../js/firebase.js";
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";
import { collection, getDocs, getDoc, doc, query, where, orderBy, limit } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";

// Keep the same Super Admin identity already used by the existing Admin modules.
async function verifyAdmin(user) {
    if (!user) {
        window.location.href = "login.html";
        return false;
    }

    try {
        const snap = await getDoc(doc(db, "admins", "superadmin"));
        const admin = snap.exists() ? snap.data() : null;
        const emailMatches = String(admin?.email || "").trim().toLowerCase() === String(user.email || "").trim().toLowerCase();
        const roleMatches = String(admin?.role || "").trim().toLowerCase() === "super_admin";
        const active = admin?.active === true;
        if (!emailMatches || !roleMatches || !active) {
            try { await signOut(auth); } catch (_) {}
            window.location.href = "login.html";
            return false;
        }
        return true;
    } catch (error) {
        console.error("❌ Admin verification error:", error);
        try { await signOut(auth); } catch (_) {}
        window.location.href = "login.html";
        return false;
    }
}

function setText(id, value) {
    const el = document.getElementById(id);
    if (el) el.innerText = String(value);
}

async function loadUsers() {
    try {
        const snapshot = await getDocs(collection(db, "users"));
        setText("totalUsers", snapshot.size);

        // Reuse the same users snapshot for the Premium statistic.
        // This avoids a second full users collection read on every admin dashboard load.
        let premiumCount = 0;
        snapshot.forEach(userDoc => {
            if (userDoc.data()?.premium === true) premiumCount++;
        });
        setText("premiumUsers", premiumCount);

        return snapshot;
    } catch (error) {
        console.error("❌ Total Users Error:", error);
        return null;
    }
}

async function loadPendingPremium() {
    try {
        const snapshot = await getDocs(query(collection(db, "subscriptionRequests"), where("status", "==", "Pending")));
        setText("pendingPremium", snapshot.size);
    } catch (error) {
        console.error("❌ Pending Premium Error:", error);
    }
}

async function loadPendingWithdraw() {
    try {
        const snapshot = await getDocs(query(collection(db, "withdrawRequests"), where("status", "==", "Pending")));
        setText("pendingWithdraw", snapshot.size);
    } catch (error) {
        console.error("❌ Pending Withdraw Error:", error);
    }
}

async function loadTotalWithdraw() {
    try {
        // Only approved withdrawals are needed for this statistic.
        const snapshot = await getDocs(query(collection(db, "withdrawRequests"), where("status", "==", "Approved")));
        let total = 0;
        snapshot.forEach(docItem => {
            total += Number(docItem.data()?.amount || 0);
        });
        setText("totalWithdraw", "৳" + total);
    } catch (error) {
        console.error("❌ Total Withdraw Error:", error);
    }
}

async function loadPendingTasks() {
    try {
        const snapshot = await getDocs(query(collection(db, "taskSubmissions"), where("status", "==", "pending")));
        setText("pendingTasks", snapshot.size);
    } catch (error) {
        // Preserve compatibility with deployments that use capitalized status values.
        try {
            const fallback = await getDocs(query(collection(db, "taskSubmissions"), where("status", "==", "Pending")));
            setText("pendingTasks", fallback.size);
        } catch (fallbackError) {
            console.error("❌ Pending Tasks Error:", error, fallbackError);
            setText("pendingTasks", 0);
        }
    }
}

async function loadPendingSupport() {
    try {
        const snapshot = await getDocs(query(
            collection(db, "supportTickets"),
            where("status", "in", ["Open", "Pending", "Under Review"])
        ));
        const count = snapshot.size;
        setText("pendingSupport", count);
        const badge = document.getElementById("supportBadge");
        if (badge) {
            badge.innerText = String(count);
            badge.style.display = count > 0 ? "inline-flex" : "none";
        }
    } catch (error) {
        console.error("❌ Pending Support Error:", error);
        setText("pendingSupport", 0);
    }
}

async function loadNotifications() {
    try {
        const snapshot = await getDocs(query(
            collection(db, "notifications"),
            orderBy("createdAt", "desc"),
            limit(5)
        ));
        renderNotifications(snapshot);
    } catch (error) {
        // If some legacy notification records lack createdAt, do not break the dashboard.
        console.error("❌ Notifications Error:", error);
        const box = document.getElementById("recentActivity");
        if (box) box.innerHTML = '<div class="activity-item">No Activity Found</div>';
    }
}

function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function renderNotifications(snapshot) {
    const box = document.getElementById("recentActivity");
    if (!box) return;
    box.innerHTML = "";
    if (snapshot.empty) {
        box.innerHTML = '<div class="activity-item">No Activity Found</div>';
        return;
    }
    snapshot.forEach(notificationDoc => {
        const data = notificationDoc.data() || {};
        const item = document.createElement("div");
        item.className = "activity-item";
        item.innerHTML = `<b>${escapeHtml(data.title || "Notification")}</b><br>${escapeHtml(data.message || "")}`;
        box.appendChild(item);
    });
}

function setupNavigation() {
    const supportBtn = document.getElementById("supportBtn");
    if (supportBtn) supportBtn.addEventListener("click", () => { window.location.href = "admin-support.html"; });

    const supportQuickBtn = document.getElementById("supportQuickBtn");
    if (supportQuickBtn) supportQuickBtn.addEventListener("click", () => { window.location.href = "admin-support.html"; });

    const logoutBtn = document.getElementById("logoutBtn");
    if (logoutBtn) logoutBtn.addEventListener("click", async () => {
        try {
            await signOut(auth);
            window.location.href = "login.html";
        } catch (error) {
            console.error("❌ Logout Error:", error);
            await alert("❌ Logout করা যায়নি।");
        }
    });

    const rewardBtn = document.getElementById("rewardBtn");
    if (rewardBtn) rewardBtn.addEventListener("click", () => { window.location.href = "admin-rewards.html"; });

    const settingBtn = document.getElementById("settingBtn");
    if (settingBtn) settingBtn.addEventListener("click", () => { window.location.href = "admin-settings.html"; });
}

onAuthStateChanged(auth, async user => {
    if (!await verifyAdmin(user)) return;

    // Independent reads run in parallel to reduce dashboard wait time.
    await Promise.allSettled([
        loadUsers(),
        loadPendingPremium(),
        loadPendingWithdraw(),
        loadPendingTasks(),
        loadTotalWithdraw(),
        loadNotifications(),
        loadPendingSupport()
    ]);
});

setupNavigation();
console.log("✅ NetEarn Pro Admin Dashboard Loaded");
