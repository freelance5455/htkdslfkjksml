// =====================================
// NetEarn Pro
// Admin Pending Tasks Review System
// =====================================


import { db } from "../js/firebase.js";
import { getBusinessSettings, getConfiguredTaskReward } from "../js/business-settings.js";

import {
    collection,
    query,
    where,
    getDocs,
    doc,
    increment,
    serverTimestamp,
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";



const pendingList = document.getElementById("pendingList");



// ===============================
// Load Pending Tasks
// ===============================

async function loadPendingTasks(){

try{


const q = query(
collection(db,"taskSubmissions"),
where("status","==","pending")
);


const snap = await getDocs(q);



pendingList.innerHTML="";



if(snap.empty){

pendingList.innerHTML=`

<div class="history-card">

📭 No Pending Tasks

</div>

`;

return;

}



snap.forEach((item)=>{


const data = item.data();



pendingList.innerHTML += `


<div class="history-card">


<h3>

${data.taskName || data.taskType}

</h3>


<p>
User UID:
${data.uid}
</p>


<p>
Reward:
<b>
৳${data.reward || 0}
</b>
</p>



<p>
Status:
⏳ Pending
</p>



<button class="approve"
onclick="approveTask('${item.id}','${data.uid}',${data.reward || 0})">
✅ Approve
</button>

<button class="reject"
onclick="rejectTask('${item.id}')">
❌ Reject
</button>


</div>


`;



});



}catch(error){

console.log(error);

pendingList.innerHTML="❌ Loading Error";

}


}





// ===============================
// Approve Task + Update User Earnings
// ===============================

window.approveTask = async (submissionId, uid) => {

    try {

        const businessSettings = await getBusinessSettings({ force: true });
        const submissionRef = doc(db, "taskSubmissions", submissionId);
        const userRef = doc(db, "users", uid);

        let finalReward = 0;

        await runTransaction(db, async (transaction) => {
            const submissionSnap = await transaction.get(submissionRef);
            if (!submissionSnap.exists()) throw new Error("SUBMISSION_NOT_FOUND");

            const submission = submissionSnap.data();
            const status = String(submission.status || "pending").trim().toLowerCase();

            // Idempotency: an already-approved submission must never pay again.
            if (status === "approved" || submission.rewardCredited === true) {
                throw new Error("ALREADY_APPROVED");
            }

            const userSnap = await transaction.get(userRef);
            if (!userSnap.exists()) throw new Error("USER_NOT_FOUND");

            finalReward = getConfiguredTaskReward(submission, businessSettings);
            if (!Number.isFinite(finalReward) || finalReward <= 0) {
                throw new Error("INVALID_REWARD");
            }

            const user = userSnap.data() || {};
            const currentBalance = Number(user.balance || 0);
            const currentTotal = Number(user.totalEarnings || user.totalIncome || 0);

            transaction.update(submissionRef, {
                status: "approved",
                approvedAt: serverTimestamp(),
                reward: finalReward,
                rewardCredited: true
            });

            transaction.update(userRef, {
                balance: currentBalance + finalReward,
                totalEarnings: currentTotal + finalReward,
                completedTasks: increment(1)
            });
        });

        alert(`✅ Task Approved & ৳${finalReward} User Wallet-এ যোগ হয়েছে!`);
        loadPendingTasks();

    } catch (error) {

        console.error(error);

        if (error.message === "ALREADY_APPROVED") {
            alert("ℹ️ এই Task আগেই Approve করা হয়েছে। Double payment করা হয়নি।");
        } else {
            alert("❌ " + error.message);
        }
    }

};
loadPendingTasks();