// =====================================================
// NetEarn Pro
// ADMIN SETTINGS SYSTEM
// FINAL CLEAN VERSION
// Firebase Firestore
// =====================================================
//
// Collections:
// settings/{main}
// paymentSettings/{main}
//
// IMPORTANT:
// Existing earning/task systems are NOT modified
// automatically by this page.
// =====================================================


import {
    auth,
    db
}
from "../js/firebase.js";


import {
    onAuthStateChanged
}
from
"https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";


import {
    doc,
    getDoc,
    setDoc
}
from
"https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =====================================================
// CONFIG
// =====================================================

const SETTINGS_DOC =
    "main";

const PAYMENT_SETTINGS_DOC =
    "main";


// =====================================================
// DEFAULT SETTINGS
// =====================================================
//
// These defaults only populate the Settings page.
// They do NOT change existing Firestore data until
// the Admin presses Save Settings.
// =====================================================

const DEFAULT_SETTINGS = {

    siteName:
        "NetEarn Pro",

    supportContact:
        "",

    siteNotice:
        "",

    referralBonus:
        50,

    taskReward:
        0,

    typingReward:
        30,

    editingReward:
        40,

    formReward:
        30,

    minimumWithdraw:
        100,

    withdrawFee:
        0,

    premiumFee:
        299,

    premiumEnabled:
        true,

    taskSystemEnabled:
        true,

    socialTaskEnabled:
        true,

    microJobEnabled:
        false,

    typingEnabled:
        true,

    photoEditingEnabled:
        true,

    formFillingEnabled:
        true,

    registrationEnabled:
        true,

    maintenanceMode:
        false

};


const DEFAULT_PAYMENT_SETTINGS = {

    bkashNumber:
        "",

    nagadNumber:
        "",

    paymentInstructions:
        ""

};


// =====================================================
// ELEMENTS
// =====================================================

const saveBtn =
    document.getElementById(
        "saveSettingsBtn"
    );


const resetBtn =
    document.getElementById(
        "resetSettingsBtn"
    );


const saveStatus =
    document.getElementById(
        "saveStatus"
    );


const toast =
    document.getElementById(
        "settingsToast"
    );


// =====================================================
// FIELD MAP
// =====================================================

const fields = {

    siteName:
        "siteName",

    supportContact:
        "supportContact",

    siteNotice:
        "siteNotice",

    referralBonus:
        "referralBonus",

    taskReward:
        "taskReward",

    typingReward:
        "typingReward",

    editingReward:
        "editingReward",

    formReward:
        "formReward",

    minimumWithdraw:
        "minimumWithdraw",

    withdrawFee:
        "withdrawFee",

    premiumFee:
        "premiumFee",

    premiumEnabled:
        "premiumEnabled",

    taskSystemEnabled:
        "taskSystemEnabled",

    socialTaskEnabled:
        "socialTaskEnabled",

    microJobEnabled:
        "microJobEnabled",

    typingEnabled:
        "typingEnabled",

    photoEditingEnabled:
        "photoEditingEnabled",

    formFillingEnabled:
        "formFillingEnabled",

    registrationEnabled:
        "registrationEnabled",

    maintenanceMode:
        "maintenanceMode"

};


const paymentFields = {

    bkashNumber:
        "bkashNumber",

    nagadNumber:
        "nagadNumber",

    paymentInstructions:
        "paymentInstructions"

};


// =====================================================
// AUTH CHECK
// =====================================================

onAuthStateChanged(
    auth,
    async user => {

        if (!user) {

            window.location.href =
                "login.html";

            return;

        }


        try {

            await loadSettings();

            setStatus(
                "Loaded"
            );

        }

        catch (error) {

            console.error(
                "❌ Settings Load Error:",
                error
            );

            setStatus(
                "Load Error"
            );

            showToast(
                "Settings load করা যায়নি।",
                "error"
            );

        }

    }
);


// =====================================================
// LOAD SETTINGS
// =====================================================

async function loadSettings() {

    // ---------------------------------------------
    // MAIN SETTINGS
    // ---------------------------------------------

    const settingsRef =
        doc(
            db,
            "settings",
            SETTINGS_DOC
        );


    const settingsSnap =
        await getDoc(
            settingsRef
        );


    let settings =
        {
            ...DEFAULT_SETTINGS
        };


    if (
        settingsSnap.exists()
    ) {

        settings =
            {
                ...settings,
                ...settingsSnap.data()
            };

    }


    // ---------------------------------------------
    // PAYMENT SETTINGS
    // ---------------------------------------------

    const paymentRef =
        doc(
            db,
            "paymentSettings",
            PAYMENT_SETTINGS_DOC
        );


    const paymentSnap =
        await getDoc(
            paymentRef
        );


    let paymentSettings =
        {
            ...DEFAULT_PAYMENT_SETTINGS
        };


    if (
        paymentSnap.exists()
    ) {

        paymentSettings =
            {
                ...paymentSettings,
                ...paymentSnap.data()
            };

    }


    // ---------------------------------------------
    // PUT VALUES INTO UI
    // ---------------------------------------------

    setFormValues(
        settings,
        paymentSettings
    );

}


// =====================================================
// SET FORM VALUES
// =====================================================

function setFormValues(
    settings,
    paymentSettings
) {

    Object.entries(fields)
        .forEach(
            ([key, id]) => {

                const element =
                    document.getElementById(
                        id
                    );


                if (!element) {
                    return;
                }


                if (
                    element.type ===
                    "checkbox"
                ) {

                    element.checked =
                        Boolean(
                            settings[key]
                        );

                }

                else {

                    element.value =
                        settings[key] ??
                        "";

                }

            }
        );


    Object.entries(paymentFields)
        .forEach(
            ([key, id]) => {

                const element =
                    document.getElementById(
                        id
                    );


                if (!element) {
                    return;
                }


                element.value =
                    paymentSettings[key] ??
                    "";

            }
        );

}


// =====================================================
// GET MAIN SETTINGS
// =====================================================

function getMainSettings() {

    return {

        siteName:
            getValue(
                "siteName"
            ),

        supportContact:
            getValue(
                "supportContact"
            ),

        siteNotice:
            getValue(
                "siteNotice"
            ),

        referralBonus:
            getNumber(
                "referralBonus"
            ),

        taskReward:
            getNumber(
                "taskReward"
            ),

        typingReward:
            getNumber(
                "typingReward"
            ),

        editingReward:
            getNumber(
                "editingReward"
            ),

        formReward:
            getNumber(
                "formReward"
            ),

        minimumWithdraw:
            getNumber(
                "minimumWithdraw"
            ),

        withdrawFee:
            getNumber(
                "withdrawFee"
            ),

        premiumFee:
            getNumber(
                "premiumFee"
            ),

        premiumEnabled:
            getChecked(
                "premiumEnabled"
            ),

        taskSystemEnabled:
            getChecked(
                "taskSystemEnabled"
            ),

        socialTaskEnabled:
            getChecked(
                "socialTaskEnabled"
            ),

        microJobEnabled:
            getChecked(
                "microJobEnabled"
            ),

        typingEnabled:
            getChecked(
                "typingEnabled"
            ),

        photoEditingEnabled:
            getChecked(
                "photoEditingEnabled"
            ),

        formFillingEnabled:
            getChecked(
                "formFillingEnabled"
            ),

        registrationEnabled:
            getChecked(
                "registrationEnabled"
            ),

        maintenanceMode:
            getChecked(
                "maintenanceMode"
            )

    };

}


// =====================================================
// GET PAYMENT SETTINGS
// =====================================================

function getPaymentSettings() {

    return {

        bkashNumber:
            getValue(
                "bkashNumber"
            ),

        nagadNumber:
            getValue(
                "nagadNumber"
            ),

        paymentInstructions:
            getValue(
                "paymentInstructions"
            )

    };

}


// =====================================================
// SAVE SETTINGS
// =====================================================

if (saveBtn) {

    saveBtn.addEventListener(
        "click",
        saveSettings
    );

}


async function saveSettings() {

    const user =
        auth.currentUser;


    if (!user) {

        showToast(
            "❌ Admin login পাওয়া যায়নি।",
            "error"
        );

        return;

    }


    try {

        setSavingState(
            true
        );


        const mainSettings =
            getMainSettings();


        const paymentSettings =
            getPaymentSettings();


        // -----------------------------------------
        // VALIDATION
        // -----------------------------------------

        if (
            mainSettings.referralBonus <
            0
        ) {

            throw new Error(
                "Referral Bonus সঠিক নয়।"
            );

        }


        if (
            mainSettings.minimumWithdraw <
            0
        ) {

            throw new Error(
                "Minimum Withdraw সঠিক নয়।"
            );

        }


        if (
            mainSettings.premiumFee <
            0
        ) {

            throw new Error(
                "Premium Fee সঠিক নয়।"
            );

        }


        // -----------------------------------------
        // SAVE MAIN SETTINGS
        // -----------------------------------------

        await setDoc(

            doc(
                db,
                "settings",
                SETTINGS_DOC
            ),

            {

                ...mainSettings,

                updatedAt:
                    new Date(),

                updatedBy:
                    user.uid

            },

            {
                merge:
                    true
            }

        );


        // -----------------------------------------
        // SAVE PAYMENT SETTINGS
        // -----------------------------------------

        await setDoc(

            doc(
                db,
                "paymentSettings",
                PAYMENT_SETTINGS_DOC
            ),

            {

                ...paymentSettings,

                updatedAt:
                    new Date(),

                updatedBy:
                    user.uid

            },

            {
                merge:
                    true
            }

        );


        setStatus(
            "Saved"
        );


        showToast(
            "✅ Settings সফলভাবে Save হয়েছে।",
            "success"
        );

    }

    catch (error) {

        console.error(
            "❌ Save Settings Error:",
            error
        );


        setStatus(
            "Save Error"
        );


        showToast(
            "❌ " +
            (
                error.message ||
                "Settings save করা যায়নি।"
            ),
            "error"
        );

    }

    finally {

        setSavingState(
            false
        );

    }

}


// =====================================================
// RESET BUTTON
// =====================================================

if (resetBtn) {

    resetBtn.addEventListener(
        "click",
        async () => {

            const confirmed =
                await NetEarnDialog.confirm(
                    "বর্তমান Settings আবার Firestore থেকে Load করবেন?"
                );


            if (!confirmed) {
                return;
            }


            try {

                setStatus(
                    "Loading..."
                );


                await loadSettings();


                setStatus(
                    "Loaded"
                );


                showToast(
                    "↩️ Settings reset করা হয়েছে।",
                    "success"
                );

            }

            catch (error) {

                console.error(
                    "Reset Error:",
                    error
                );


                showToast(
                    "❌ Reset করা যায়নি।",
                    "error"
                );

            }

        }
    );

}


// =====================================================
// HELPERS
// =====================================================

function getValue(
    id
) {

    const element =
        document.getElementById(
            id
        );


    return element
        ? element.value.trim()
        : "";

}


function getNumber(
    id
) {

    const element =
        document.getElementById(
            id
        );


    if (!element) {
        return 0;
    }


    const value =
        Number(
            element.value
        );


    return Number.isFinite(value)
        ? value
        : 0;

}


function getChecked(
    id
) {

    const element =
        document.getElementById(
            id
        );


    return Boolean(
        element?.checked
    );

}


// =====================================================
// SAVE STATE
// =====================================================

function setSavingState(
    saving
) {

    if (!saveBtn) {
        return;
    }


    saveBtn.disabled =
        saving;


    if (saving) {

        saveBtn.innerHTML = `

            <i class="bi bi-arrow-repeat"></i>

            Saving...

        `;

    }

    else {

        saveBtn.innerHTML = `

            <i class="bi bi-check2-circle"></i>

            Save Settings

        `;

    }

}


// =====================================================
// STATUS
// =====================================================

function setStatus(
    text
) {

    if (saveStatus) {

        saveStatus.textContent =
            text;

    }

}


// =====================================================
// TOAST
// =====================================================

let toastTimer =
    null;


function showToast(
    message,
    type = ""
) {

    if (!toast) {
        return;
    }


    toast.textContent =
        message;


    toast.className =
        "settings-toast";


    if (type) {

        toast.classList.add(
            type
        );

    }


    toast.classList.add(
        "show"
    );


    clearTimeout(
        toastTimer
    );


    toastTimer =
        setTimeout(
            () => {

                toast.classList.remove(
                    "show"
                );

            },
            3000
        );

}


// =====================================================
// FINAL READY
// =====================================================

console.log(
    "======================================"
);

console.log(
    "⚙ NetEarn Pro Admin Settings"
);

console.log(
    "🔥 Firebase Settings Connected"
);

console.log(
    "💳 Payment Settings Connected"
);

console.log(
    "📋 Task Settings Ready"
);

console.log(
    "👑 Premium Settings Ready"
);

console.log(
    "🔐 Security Settings Ready"
);

console.log(
    "======================================"
);