// =======================================
// NetEarn Pro Admin Panel V8
// Withdraw Management
// Part 1
// =======================================

import { db } from "../js/firebase.js";
import { addTransaction } from "../js/transaction.js";

import {
collection,
query,
orderBy,
getDocs,
doc,
getDoc,
updateDoc,
addDoc,
serverTimestamp
}
from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =========================
// GLOBAL
// =========================

let withdrawData = [];
let selectedWithdraw = null;


// =========================
// HTML ELEMENTS
// =========================

const withdrawTable =
document.getElementById("withdrawTable");

const totalWithdraw =
document.getElementById("totalWithdraw");

const pendingWithdraw =
document.getElementById("pendingWithdraw");

const approvedWithdraw =
document.getElementById("approvedWithdraw");

const rejectedWithdraw =
document.getElementById("rejectedWithdraw");

const totalAmount =
document.getElementById("totalAmount");


// =========================
// LOAD WITHDRAW REQUESTS
// =========================

async function loadWithdrawRequests(){

try{

withdrawTable.innerHTML=`

<tr>

<td colspan="9"
class="text-center">

Loading...

</td>

</tr>

`;

withdrawData=[];

const q=query(

collection(db,"withdrawRequests"),

orderBy("createdAt","desc")

);

const snap=await getDocs(q);

snap.forEach((docItem)=>{

withdrawData.push({

id:docItem.id,

...docItem.data()

});

});

renderWithdrawTable(withdrawData);

updateStats();

}

catch(error){

console.error(error);

withdrawTable.innerHTML=`

<tr>

<td colspan="9"
class="text-danger text-center">

Failed To Load Data

</td>

</tr>

`;

}

}


// =========================
// RENDER TABLE
// =========================

function renderWithdrawTable(data){

withdrawTable.innerHTML="";

if(data.length===0){

withdrawTable.innerHTML=`

<tr>

<td colspan="9"
class="text-center">

No Withdraw Request Found

</td>

</tr>

`;

return;

}

data.forEach(item=>{

let badge="bg-warning";

if(item.status==="Approved") badge="bg-success";

if(item.status==="Rejected") badge="bg-danger";

withdrawTable.innerHTML+=`

<tr>

<td>${item.name||"-"}</td>

<td>${item.username||"-"}</td>

<td>${item.email||"-"}</td>

<td>৳${item.amount||0}</td>

<td>${item.method||"-"}</td>

<td>${item.number||"-"}</td>

<td>${item.transaction||"-"}</td>

<td>

<span class="badge ${badge}">

${item.status||"Pending"}

</span>

</td>

<td>

<button

class="btn btn-primary btn-sm viewBtn"

data-id="${item.id}"

>

View

</button>

</td>

</tr>

`;

});


// View Button

document.querySelectorAll(".viewBtn")

.forEach(btn=>{

btn.onclick=()=>{

const id=btn.dataset.id;

selectedWithdraw=

withdrawData.find(

x=>x.id===id

);

openWithdrawModal(selectedWithdraw);

};

});

}


// =========================
// UPDATE STATS
// =========================

function updateStats(){

let total=0;

let pending=0;

let approved=0;

let rejected=0;

let amount=0;

withdrawData.forEach(item=>{

total++;

amount+=Number(item.amount||0);

if(item.status==="Pending") pending++;

if(item.status==="Approved") approved++;

if(item.status==="Rejected") rejected++;

});

totalWithdraw.innerText=total;

pendingWithdraw.innerText=pending;

approvedWithdraw.innerText=approved;

rejectedWithdraw.innerText=rejected;

totalAmount.innerText="৳"+amount;

}


// =========================
// START
// =========================

loadWithdrawRequests();

// =======================================
// PART 2
// View Modal + Search + Filter
// =======================================


// ===============================
// MODAL ELEMENTS
// ===============================

const approveBtn = document.getElementById("approveBtn");
const rejectBtn = document.getElementById("rejectBtn");


// ===============================
// OPEN MODAL
// ===============================

function openWithdrawModal(data){

if(!data) return;

document.getElementById("viewName").innerText =
data.name || "-";

document.getElementById("viewUsername").innerText =
data.username || "-";

document.getElementById("viewEmail").innerText =
data.email || "-";

document.getElementById("viewUserId").innerText =
data.uid || "-";

document.getElementById("viewMethod").innerText =
data.method || "-";

document.getElementById("viewNumber").innerText =
data.number || "-";

document.getElementById("viewTransaction").innerText =
data.transaction || "-";

document.getElementById("viewAmount").innerText =
data.amount || 0;

document.getElementById("viewStatus").innerText =
data.status || "Pending";

document.getElementById("viewDate").innerText =
data.createdAt?.toDate
? data.createdAt.toDate().toLocaleString()
: "-";


new bootstrap.Modal(
document.getElementById("withdrawModal")
).show();

}



// ===============================
// SEARCH
// ===============================

const searchWithdraw =
document.getElementById("searchWithdraw");

if(searchWithdraw){

searchWithdraw.addEventListener("input",()=>{

const value =
searchWithdraw.value
.toLowerCase()
.trim();

const filtered =
withdrawData.filter(item=>{

return (

(item.name||"")
.toLowerCase()
.includes(value)

||

(item.username||"")
.toLowerCase()
.includes(value)

||

(item.email||"")
.toLowerCase()
.includes(value)

||

(item.transaction||"")
.toLowerCase()
.includes(value)

);

});

renderWithdrawTable(filtered);

});

}



// ===============================
// FILTER
// ===============================

document
.querySelectorAll(".filter-buttons button")

.forEach(btn=>{

btn.onclick=()=>{

document
.querySelectorAll(".filter-buttons button")

.forEach(x=>x.classList.remove("active"));

btn.classList.add("active");

const filter=
btn.dataset.filter;

if(filter==="all"){

renderWithdrawTable(withdrawData);

return;

}

const filtered=
withdrawData.filter(item=>

item.status===filter

);

renderWithdrawTable(filtered);

};

});

// =======================================
// PART 3
// APPROVE WITHDRAW
// =======================================

if (approveBtn) {

approveBtn.onclick = async () => {

if (!selectedWithdraw) return;

try {

if (selectedWithdraw.status !== "Pending") {

alert("Already Processed");

return;

}

// Withdraw Approved

await updateDoc(

doc(db, "withdrawRequests", selectedWithdraw.id),

{

status: "Approved",

approvedAt: serverTimestamp()

}

);

// User Info

const userRef =
doc(db, "users", selectedWithdraw.uid);

const userSnap =
await getDoc(userRef);

if (userSnap.exists()) {

const user =
userSnap.data();

// Transaction

await addTransaction({

uid: selectedWithdraw.uid,

userName:

user.username ||

user.name ||

"User",

title: "Withdraw Approved",

reason: "Money Sent Successfully",

amount: Number(selectedWithdraw.amount),

type: "debit"

});

}

// Notification

await addDoc(

collection(db, "notifications"),

{

userUid:
selectedWithdraw.uid,

title:
"✅ Withdraw Approved",

message:
`আপনার ৳${selectedWithdraw.amount} Withdraw Approved হয়েছে।`,

read: false,

createdAt:
serverTimestamp()

}

);

alert("✅ Withdraw Approved");

loadWithdrawRequests();

bootstrap.Modal
.getInstance(

document.getElementById("withdrawModal")

).hide();

}

catch (error) {

console.log(error);

alert("Approve Failed");

}

};

}

// =======================================
// PART 4
// REJECT + REFUND + NOTIFICATION
// =======================================

if (rejectBtn) {

rejectBtn.onclick = async () => {

if (!selectedWithdraw) return;

const confirmReject = await NetEarnDialog.confirm(
"Reject this Withdraw?\nMoney will return to Wallet."
);

if (!confirmReject) return;

try {

const userRef = doc(db, "users", selectedWithdraw.uid);

const userSnap = await getDoc(userRef);

if (!userSnap.exists()) {

alert("User Not Found");

return;

}

const userData = userSnap.data();

const refundAmount =
Number(selectedWithdraw.amount || 0);

const oldBalance =
Number(userData.balance || 0);

// Refund Wallet

await updateDoc(userRef, {

balance: oldBalance + refundAmount

});

// Transaction

await addTransaction({

uid: selectedWithdraw.uid,

userName:
userData.username ||
userData.name ||
"User",

title: "Withdraw Refund",

reason: "Withdraw Rejected",

amount: refundAmount,

type: "credit"

});

// Withdraw Status

await updateDoc(

doc(db, "withdrawRequests", selectedWithdraw.id),

{

status: "Rejected",

rejectedAt: serverTimestamp()

}

);

// Notification

await addDoc(

collection(db, "notifications"),

{

userUid: selectedWithdraw.uid,

title: "❌ Withdraw Rejected",

message:
`আপনার ৳${refundAmount} Wallet-এ ফেরত দেওয়া হয়েছে।`,

read: false,

createdAt: serverTimestamp()

}

);

alert("❌ Withdraw Rejected");

loadWithdrawRequests();

bootstrap.Modal
.getInstance(
document.getElementById("withdrawModal")
)
.hide();

}

catch(error){

console.log(error);

alert("Reject Failed");

}

};

}

// =======================================
// AUTO REFRESH
// =======================================

setInterval(()=>{

loadWithdrawRequests();

},30000);

// =======================================
// CLEANUP
// =======================================

window.addEventListener("beforeunload",()=>{

selectedWithdraw=null;

});