// =====================================
// NetEarn Pro Admin Login
// =====================================

import { auth, db } from "../js/firebase.js";

import {
  signInWithEmailAndPassword
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

import {
  doc,
  getDoc
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


const form = document.getElementById("adminLoginForm");
const message = document.getElementById("loginMessage");


form.addEventListener("submit", async (e) => {

    e.preventDefault();

    const email =
    document.getElementById("email").value.trim();

    const password =
    document.getElementById("password").value;

    message.innerHTML = "⏳ Logging in...";

    try {

        // Firebase Authentication Login
        await signInWithEmailAndPassword(auth, email, password);

        // Firestore Admin Check
        const adminDoc =
    await getDoc(doc(db, "admins", "superadmin"));

        if (!adminDoc.exists()) {

            message.innerHTML = "❌ Admin Record Not Found";
            return;

        }

        const admin = adminDoc.data();

        if (
            admin.email === email &&
            admin.role === "super_admin" &&
            admin.active === true
        ) {

            message.style.color = "green";
            message.innerHTML = "✅ Login Successful";

            setTimeout(() => {

                window.location.href = "dashboard.html";

            }, 1000);

        } else {

            message.style.color = "red";
            message.innerHTML = "❌ Access Denied";

        }

    }

    catch (error) {

        console.log(error);

        message.style.color = "red";

        message.innerHTML = error.message;

    }

});