<?php
declare(strict_types=1);
// Friendly directory URL: /admin/ .
$platformBaseHref = rtrim(dirname(dirname(str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? '/')))), '/') . '/';
require dirname(__DIR__) . '/admin.php';
