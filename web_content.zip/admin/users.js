// =========================================================
// NetEarn Pro
// USERS MANAGEMENT SYSTEM
// FINAL CLEAN VERSION
// =========================================================


// =========================================================
// FIREBASE IMPORT
// =========================================================

import { auth, db } from "../js/firebase.js";

import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

import {
    collection,
    getDocs,
    doc,
    getDoc,
    updateDoc,
    addDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =========================================================
// SUPER ADMIN
// =========================================================




// =========================================================
// APP STATE
// =========================================================

let allUsers = [];

let selectedUser = null;

let userModal = null;


// =========================================================
// DOM READY
// =========================================================

document.addEventListener("DOMContentLoaded", () => {

    initializeUsersPage();

});


// =========================================================
// INITIALIZE
// =========================================================

function initializeUsersPage() {

    // Bootstrap modal
    const modalElement =
        document.getElementById("userModal");

    if (
        modalElement &&
        typeof bootstrap !== "undefined"
    ) {

        userModal =
            new bootstrap.Modal(modalElement);

    }


    // Search
    const searchInput =
        document.getElementById("searchUser");

    if (searchInput) {

        searchInput.addEventListener(
            "input",
            handleSearch
        );

    }


    // Status filter
    const statusFilter =
        document.getElementById("statusFilter");

    if (statusFilter) {

        statusFilter.addEventListener(
            "change",
            handleStatusFilter
        );

    }


    // Action buttons
    setupActionButtons();

}


// =========================================================
// ADMIN AUTH CHECK
// =========================================================

onAuthStateChanged(auth, async (user) => {

    if (!user) {

        window.location.href =
            "login.html";

        return;

    }


    // -----------------------------------------
    // CENTRAL SUPER ADMIN CHECK
    // -----------------------------------------
    try {
        const adminSnap = await getDoc(doc(db, "admins", "superadmin"));
        const admin = adminSnap.exists() ? adminSnap.data() : null;
        const allowed = admin && admin.active === true &&
            String(admin.role || "").trim().toLowerCase() === "super_admin" &&
            String(admin.email || "").trim().toLowerCase() === String(user.email || "").trim().toLowerCase();

        if (!allowed) {
            console.error("Access denied for admin account:", user.email);
            alert("🚫 Access denied.\n\nএই পেজটি শুধুমাত্র Super Admin-এর জন্য।");

        return;

    }


    // -----------------------------------------
    // LOAD USERS
    // -----------------------------------------

    await loadUsers();

    } catch (error) {

        console.error(
            "ADMIN AUTH CHECK ERROR:",
            error
        );

        const table =
            document.getElementById("usersTable");

        if (table) {
            table.innerHTML = `
                <tr>
                    <td colspan="7" class="text-center text-danger">
                        🚫 Failed to initialize Users Management.
                    </td>
                </tr>
            `;
        }

        if (error?.code === "permission-denied") {
            alert(
                "🚫 Firestore Permission Denied.\n\n" +
                "Super Admin access এবং Firestore Rules check করুন।"
            );
        }

    }

});


// =========================================================
// LOAD USERS
// =========================================================

async function loadUsers() {

    const table =
        document.getElementById("usersTable");


    if (table) {

        table.innerHTML = `
            <tr>
                <td colspan="6"
                    class="text-center">
                    ⏳ Loading Users...
                </td>
            </tr>
        `;

    }


    try {

        const snapshot =
            await getDocs(
                collection(db, "users")
            );


        allUsers = [];


        snapshot.forEach((docSnap) => {

            allUsers.push({

                id: docSnap.id,

                ...docSnap.data()

            });

        });


        // Display
        displayUsers(allUsers);


        // Statistics
        updateUserStats();


    } catch (error) {

        console.error(
            "LOAD USERS ERROR:",
            error
        );


        if (table) {

            table.innerHTML = `
                <tr>
                    <td colspan="6"
                        class="text-center text-danger">

                        🚫 Failed to load users.

                        <br><br>

                        <small>
                            ${escapeHtml(
                                getFirebaseError(error)
                            )}
                        </small>

                    </td>
                </tr>
            `;

        }


        // Important:
        // Do not show generic "Access denied"
        // unless Firebase actually returned permission-denied.

        if (
            error?.code ===
            "permission-denied"
        ) {

            alert(
                "🚫 Firestore Permission Denied.\n\n" +
                "Super Admin UID এবং Firestore Rules check করুন।"
            );

        } else {

            console.error(error);

        }

    }

}


window.loadUsers = loadUsers;


// =========================================================
// DISPLAY USERS
// =========================================================

function displayUsers(users) {

    const table =
        document.getElementById("usersTable");


    if (!table) return;


    table.innerHTML = "";


    if (!users.length) {

        table.innerHTML = `
            <tr>
                <td colspan="6"
                    class="text-center">

                    No Users Found

                </td>
            </tr>
        `;

        return;

    }


    users.forEach((user) => {

        const name =
            user.name ||
            user.username ||
            "No Name";


        const email =
            user.email ||
            "";


        const premium =
            user.premium === true;


        const balance =
            Number(
                user.balance ??
                user.mainBalance ??
                0
            );


        const status =
            user.blocked === true
                ? "Blocked"
                : (
                    user.status ||
                    "Active"
                );


        table.innerHTML += `

            <tr>

                <td>
                    ${escapeHtml(name)}
                </td>


                <td>
                    ${escapeHtml(email)}
                </td>


                <td>

                    ${
                        premium

                        ? `
                            <span class="badge-premium">
                                Premium
                            </span>
                          `

                        : `
                            <span class="badge-normal">
                                Normal
                            </span>
                          `
                    }

                </td>


                <td>
                    ৳${balance}
                </td>


                <td>

                    ${
                        status === "Blocked"

                        ? `
                            <span class="text-danger">
                                🚫 Blocked
                            </span>
                          `

                        : user.verified === true

                        ? `
                            <span class="text-success">
                                ✅ Verified
                            </span>
                          `

                        : `
                            <span class="text-warning">
                                ⏳ Pending
                            </span>
                          `
                    }

                </td>


                <td>

                    <button
                        type="button"
                        class="action-btn view-btn"
                        onclick="viewUser('${user.id}')">

                        👁 View

                    </button>

                </td>

            </tr>

        `;

    });

}


// =========================================================
// USER STATISTICS
// =========================================================

function updateUserStats() {

    const totalUsers =
        allUsers.length;


    const premiumUsers =
        allUsers.filter(
            user =>
                user.premium === true
        ).length;


    const pendingUsers =
        allUsers.filter(
            user =>
                user.verified !== true &&
                user.blocked !== true
        ).length;


    const blockedUsers =
        allUsers.filter(
            user =>
                user.blocked === true ||
                user.status === "Blocked"
        ).length;


    setText(
        "totalUsers",
        totalUsers
    );


    setText(
        "premiumUsers",
        premiumUsers
    );


    setText(
        "pendingUsers",
        pendingUsers
    );


    setText(
        "blockedUsers",
        blockedUsers
    );

}


// =========================================================
// SEARCH
// =========================================================

function handleSearch(event) {

    const value =
        event.target.value
            .trim()
            .toLowerCase();


    if (!value) {

        displayUsers(allUsers);

        return;

    }


    const filtered =
        allUsers.filter((user) => {

            const name =
                String(
                    user.name ||
                    ""
                ).toLowerCase();


            const username =
                String(
                    user.username ||
                    ""
                ).toLowerCase();


            const email =
                String(
                    user.email ||
                    ""
                ).toLowerCase();


            const userId =
                String(
                    user.userId ||
                    ""
                ).toLowerCase();


            const uid =
                String(
                    user.id ||
                    ""
                ).toLowerCase();


            return (
                name.includes(value) ||
                username.includes(value) ||
                email.includes(value) ||
                userId.includes(value) ||
                uid.includes(value)
            );

        });


    displayUsers(filtered);

}


// =========================================================
// STATUS FILTER
// =========================================================

function handleStatusFilter(event) {

    const value =
        event.target.value;


    let filtered =
        allUsers;


    if (value === "verified") {

        filtered =
            allUsers.filter(
                user =>
                    user.verified === true &&
                    user.blocked !== true
            );

    }


    if (value === "pending") {

        filtered =
            allUsers.filter(
                user =>
                    user.verified !== true &&
                    user.blocked !== true
            );

    }


    if (value === "blocked") {

        filtered =
            allUsers.filter(
                user =>
                    user.blocked === true ||
                    user.status === "Blocked"
            );

    }


    displayUsers(filtered);

}


// =========================================================
// VIEW USER
// =========================================================

window.viewUser = async function (id) {

    try {

        const snap =
            await getDoc(
                doc(db, "users", id)
            );


        if (!snap.exists()) {

            alert(
                "❌ User Not Found"
            );

            return;

        }


        selectedUser = {

            id: id,

            ...snap.data()

        };


        fillUserModal(
            selectedUser
        );


        if (userModal) {

            userModal.show();

        }


    } catch (error) {

        console.error(
            "VIEW USER ERROR:",
            error
        );


        alert(
            "❌ User details load failed.\n\n" +
            getFirebaseError(error)
        );

    }

};

// =========================================================
// FILL USER MODAL
// =========================================================

function fillUserModal(data) {

    // -----------------------------------------------------
    // NAME
    // -----------------------------------------------------

    setText(
        "viewName",
        data.name ||
        data.username ||
        "No Name"
    );


    // -----------------------------------------------------
    // NETEARN ID
    // -----------------------------------------------------

    setText(
        "viewUserId",
        data.userId ||
        data.netEarnId ||
        data.neteEarnId ||
        data.netearnId ||
        "-"
    );


    // -----------------------------------------------------
    // EMAIL
    // -----------------------------------------------------

    setText(
        "viewEmail",
        data.email ||
        ""
    );


    // -----------------------------------------------------
    // PHONE
    // -----------------------------------------------------

    setText(
        "viewPhone",
        data.phone ||
        data.mobile ||
        data.phoneNumber ||
        "-"
    );


    // -----------------------------------------------------
    // MAIN BALANCE
    // -----------------------------------------------------

    const mainBalance =
        Number(
            data.mainBalance ??
            data.balance ??
            0
        );


    setText(
        "viewBalance",
        "৳" + mainBalance
    );


    // -----------------------------------------------------
    // CREDIT BALANCE
    // -----------------------------------------------------

    const creditBalance =
        Number(
            data.creditBalance ??
            data.credit ??
            0
        );


    setText(
        "viewCreditBalance",
        "৳" + creditBalance
    );


    // -----------------------------------------------------
    // PREMIUM
    // -----------------------------------------------------

    setText(
        "viewPremium",
        data.premium === true
            ? "ON ✅"
            : "OFF ❌"
    );


    // -----------------------------------------------------
    // VIP
    // -----------------------------------------------------

    setText(
        "viewVip",
        data.vip === true
            ? "ON ✅"
            : "OFF ❌"
    );


    // -----------------------------------------------------
    // VERIFIED
    // -----------------------------------------------------

    setText(
        "viewVerified",
        data.verified === true
            ? "Verified ✅"
            : "Pending ⏳"
    );


    // -----------------------------------------------------
    // BLOCKED
    // -----------------------------------------------------

    setText(
        "viewBlocked",
        data.blocked === true
            ? "Blocked 🚫"
            : "Active ✅"
    );


    // -----------------------------------------------------
    // WITHDRAW
    // -----------------------------------------------------

    setText(
        "viewWithdraw",
        data.withdrawEnabled === true
            ? "ON ✅"
            : "OFF ❌"
    );


    // -----------------------------------------------------
    // TYPING
    // -----------------------------------------------------

    setText(
        "viewTyping",
        data.typingEnabled === true
            ? "ON ✅"
            : "OFF ❌"
    );


    // -----------------------------------------------------
    // PHOTO EDITING
    // -----------------------------------------------------

    setText(
        "viewPhoto",
        data.photoEditingEnabled === true
            ? "ON ✅"
            : "OFF ❌"
    );


    // -----------------------------------------------------
    // FORM FILLING
    // -----------------------------------------------------

    setText(
        "viewForm",
        data.formFillingEnabled === true
            ? "ON ✅"
            : "OFF ❌"
    );


    // -----------------------------------------------------
    // REFERRAL
    // -----------------------------------------------------

    setText(
        "viewReferral",
        data.referralEnabled === true
            ? "ON ✅"
            : "OFF ❌"
    );


    // -----------------------------------------------------
    // MICROSOFT
    // -----------------------------------------------------

    setText(
        "viewMicrosoft",
        data.microsoftEnabled === true
            ? "ON ✅"
            : "OFF ❌"
    );


    // -----------------------------------------------------
    // BONUS
    // -----------------------------------------------------

    const bonus =
        Number(
            data.bonus ??
            data.welcomeBonus ??
            0
        );


    setText(
        "viewBonus",
        "৳" + bonus
    );


    // -----------------------------------------------------
    // ADMIN NOTE
    // -----------------------------------------------------

    const adminNote =
        document.getElementById(
            "adminNote"
        );


    if (adminNote) {

        adminNote.value =
            data.adminNote || "";

    }


    // -----------------------------------------------------
    // BLOCK REASON
    // -----------------------------------------------------

    const blockReason =
        document.getElementById(
            "blockReason"
        );


    if (blockReason) {

        blockReason.value =
            data.blockReason || "";

    }

}
 

// =========================================================
// SETUP ACTION BUTTONS
// =========================================================

function setupActionButtons() {

    const verifyButton =
        document.getElementById(
            "toggleVerify"
        );


    if (verifyButton) {

        verifyButton.onclick =
            toggleVerify;

    }


    const premiumButton =
        document.getElementById(
            "togglePremium"
        );


    if (premiumButton) {

        premiumButton.onclick =
            togglePremium;

    }


    const vipButton =
        document.getElementById(
            "toggleVip"
        );


    if (vipButton) {

        vipButton.onclick =
            toggleVip;

    }


    const withdrawButton =
        document.getElementById(
            "toggleWithdraw"
        );


    if (withdrawButton) {

        withdrawButton.onclick =
            toggleWithdraw;

    }


    const blockButton =
        document.getElementById(
            "toggleBlock"
        );


    if (blockButton) {

        blockButton.onclick =
            toggleBlock;

    }


    const noteButton =
        document.getElementById(
            "saveNote"
        );


    if (noteButton) {

        noteButton.onclick =
            saveAdminNote;

    }


    const notificationButton =
        document.getElementById(
            "sendNotification"
        );


    if (notificationButton) {

        notificationButton.onclick =
            sendSingleNotification;

    }


    const allNotificationButton =
        document.getElementById(
            "sendAllNotification"
        );


    if (allNotificationButton) {

        allNotificationButton.onclick =
            sendAllNotification;

    }

}


// =========================================================
// VERIFY
// =========================================================

async function toggleVerify() {

    if (!selectedUser) return;


    const verify =
        selectedUser.verified !== true;


    try {

        await updateDoc(
            doc(
                db,
                "users",
                selectedUser.id
            ),
            {
                verified: verify
            }
        );


        await sendNotification(

            selectedUser.id,

            verify
                ? "✅ Account Verified"
                : "❌ Verification Removed",

            verify
                ? "Congratulations! Your account has been verified."
                : "Your verification has been removed."

        );


        alert(
            verify
                ? "✅ User Verified"
                : "❌ Verification Removed"
        );


        await reloadAll();

    } catch (error) {

        handleActionError(
            "Verification update",
            error
        );

    }

}


// =========================================================
// PREMIUM
// =========================================================

async function togglePremium() {

    if (!selectedUser) return;


    const premium =
        selectedUser.premium !== true;


    try {

        await updateDoc(
            doc(
                db,
                "users",
                selectedUser.id
            ),
            {
                premium: premium
            }
        );


        await sendNotification(

            selectedUser.id,

            premium
                ? "👑 Premium Activated"
                : "👑 Premium Disabled",

            premium
                ? "Your account has been upgraded to Premium."
                : "Your Premium access has been removed."

        );


        alert(
            premium
                ? "👑 Premium Enabled"
                : "👑 Premium Disabled"
        );


        await reloadAll();

    } catch (error) {

        handleActionError(
            "Premium update",
            error
        );

    }

}


// =========================================================
// VIP
// =========================================================

async function toggleVip() {

    if (!selectedUser) return;


    const vip =
        selectedUser.vip !== true;


    try {

        await updateDoc(
            doc(
                db,
                "users",
                selectedUser.id
            ),
            {
                vip: vip
            }
        );


        await sendNotification(

            selectedUser.id,

            vip
                ? "⭐ VIP Activated"
                : "⭐ VIP Disabled",

            vip
                ? "Your account has been upgraded to VIP."
                : "Your VIP access has been removed."

        );


        alert(
            vip
                ? "⭐ VIP Enabled"
                : "⭐ VIP Disabled"
        );


        await reloadAll();

    } catch (error) {

        handleActionError(
            "VIP update",
            error
        );

    }

}

// =========================================================
// WITHDRAW
// =========================================================

async function toggleWithdraw() {

    if (!selectedUser) return;


    const withdraw =
        selectedUser.withdrawEnabled !== true;


    try {

        await updateDoc(
            doc(
                db,
                "users",
                selectedUser.id
            ),
            {
                withdrawEnabled: withdraw
            }
        );


        await sendNotification(

            selectedUser.id,

            withdraw
                ? "💸 Withdraw Enabled"
                : "🚫 Withdraw Disabled",

            withdraw
                ? "You can now submit withdraw requests."
                : "Withdraw has been disabled by Admin."

        );


        alert(
            withdraw
                ? "💸 Withdraw Enabled"
                : "🚫 Withdraw Disabled"
        );


        await reloadAll();

    } catch (error) {

        handleActionError(
            "Withdraw update",
            error
        );

    }

}


// =========================================================
// BLOCK / UNBLOCK
// =========================================================

async function toggleBlock() {

    if (!selectedUser) return;


    try {

        // -----------------------------------------
        // BLOCK
        // -----------------------------------------

        if (
            selectedUser.blocked !== true
        ) {

            const reasonElement =
                document.getElementById(
                    "blockReason"
                );


            const reason =
                reasonElement
                    ?.value
                    .trim();


            if (!reason) {

                alert(
                    "⚠️ Please enter block reason."
                );

                return;

            }


            await updateDoc(
                doc(
                    db,
                    "users",
                    selectedUser.id
                ),
                {

                    blocked: true,

                    status: "Blocked",

                    blockReason: reason,

                    blockedAt:
                        serverTimestamp()

                }
            );


            await sendNotification(

                selectedUser.id,

                "🚫 Account Blocked",

                "Reason: " + reason

            );


            alert(
                "🚫 User Blocked Successfully"
            );

        }


        // -----------------------------------------
        // UNBLOCK
        // -----------------------------------------

        else {

            await updateDoc(
                doc(
                    db,
                    "users",
                    selectedUser.id
                ),
                {

                    blocked: false,

                    status: "Active",

                    blockReason: ""

                }
            );


            await sendNotification(

                selectedUser.id,

                "✅ Account Unblocked",

                "Your account has been activated."

            );


            alert(
                "🔓 User Unblocked Successfully"
            );

        }


        await reloadAll();


    } catch (error) {

        handleActionError(
            "Block / Unblock",
            error
        );

    }

}


// =========================================================
// SAVE ADMIN NOTE
// =========================================================

async function saveAdminNote() {

    if (!selectedUser) return;


    const noteElement =
        document.getElementById(
            "adminNote"
        );


    const note =
        noteElement
            ?.value || "";


    try {

        await updateDoc(
            doc(
                db,
                "users",
                selectedUser.id
            ),
            {
                adminNote: note
            }
        );


        await refreshSelectedUser();


        alert(
            "📝 Admin Note Saved"
        );


    } catch (error) {

        handleActionError(
            "Admin Note",
            error
        );

    }

}


// =========================================================
// SEND SINGLE NOTIFICATION
// =========================================================

async function sendSingleNotification() {

    if (!selectedUser) return;


    const titleElement =
        document.getElementById(
            "notifyTitle"
        );


    const messageElement =
        document.getElementById(
            "notifyMessage"
        );


    const title =
        titleElement
            ?.value
            .trim();


    const message =
        messageElement
            ?.value
            .trim();


    if (!title || !message) {

        alert(
            "⚠️ Enter Title & Message"
        );

        return;

    }


    try {

        await sendNotification(

            selectedUser.id,

            title,

            message

        );


        alert(
            "📢 Notification Sent"
        );


        if (titleElement) {

            titleElement.value = "";

        }


        if (messageElement) {

            messageElement.value = "";

        }


    } catch (error) {

        handleActionError(
            "Notification",
            error
        );

    }

}


// =========================================================
// SEND NOTIFICATION
// =========================================================

async function sendNotification(
    userUid,
    title,
    message
) {

    await addDoc(
        collection(
            db,
            "notifications"
        ),
        {

            userUid: userUid,

            title: title,

            message: message,

            read: false,

            createdAt:
                serverTimestamp()

        }
    );

}


// =========================================================
// SEND TO ALL USERS
// =========================================================

async function sendAllNotification() {

    const titleElement =
        document.getElementById(
            "notifyTitle"
        );


    const messageElement =
        document.getElementById(
            "notifyMessage"
        );


    const title =
        titleElement
            ?.value
            .trim();


    const message =
        messageElement
            ?.value
            .trim();


    if (!title || !message) {

        alert(
            "⚠️ Enter Title & Message"
        );

        return;

    }


    try {

        const usersSnapshot =
            await getDocs(
                collection(
                    db,
                    "users"
                )
            );


        if (
            usersSnapshot.empty
        ) {

            alert(
                "⚠️ No users found."
            );

            return;

        }


        let sentCount = 0;


        for (
            const userDoc
            of usersSnapshot.docs
        ) {

            await addDoc(
                collection(
                    db,
                    "notifications"
                ),
                {

                    userUid:
                        userDoc.id,

                    title:
                        title,

                    message:
                        message,

                    read: false,

                    createdAt:
                        serverTimestamp()

                }
            );


            sentCount++;

        }


        alert(
            `📢 Notification Sent To ${sentCount} Users`
        );


        if (titleElement) {

            titleElement.value = "";

        }


        if (messageElement) {

            messageElement.value = "";

        }


    } catch (error) {

        handleActionError(
            "Send All Notification",
            error
        );

    }

}

// =========================================================
// REFRESH SELECTED USER
// =========================================================

async function refreshSelectedUser() {

    if (!selectedUser) return;


    const snap =
        await getDoc(
            doc(
                db,
                "users",
                selectedUser.id
            )
        );


    if (!snap.exists()) {

        selectedUser = null;

        return;

    }


    selectedUser = {

        id:
            selectedUser.id,

        ...snap.data()

    };


    fillUserModal(
        selectedUser
    );

}


// =========================================================
// RELOAD EVERYTHING
// =========================================================

async function reloadAll() {

    await refreshSelectedUser();

    await loadUsers();

}


// =========================================================
// FIREBASE ERROR
// =========================================================

function getFirebaseError(error) {

    if (!error) {

        return "Unknown error";

    }


    if (
        error.code ===
        "permission-denied"
    ) {

        return "Firestore permission denied.";

    }


    if (
        error.code ===
        "unauthenticated"
    ) {

        return "User is not authenticated.";

    }


    return (
        error.message ||
        "Unknown Firebase error"
    );

}


// =========================================================
// ACTION ERROR
// =========================================================

function handleActionError(
    action,
    error
) {

    console.error(
        `${action} ERROR:`,
        error
    );


    alert(
        `❌ ${action} failed.\n\n` +
        getFirebaseError(error)
    );

}


// =========================================================
// SET TEXT
// =========================================================

function setText(
    elementId,
    value
) {

    const element =
        document.getElementById(
            elementId
        );


    if (element) {

        element.textContent =
            String(value);

    }

}


// =========================================================
// HTML ESCAPE
// =========================================================

function escapeHtml(value) {

    return String(value ?? "")
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );

}


// =========================================================
// END
// =========================================================