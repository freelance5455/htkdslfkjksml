import { escapeHtml } from "../../js/shared-utils.js";
/* =========================================================
   NetEarn Pro
   Admin Support Center
   FINAL CLEAN VERSION

   File:
   admin/js/admin-support.js

   Firebase:
   ../../js/firebase.js
========================================================= */


/* =========================================================
   FIREBASE
========================================================= */

import {
    auth,
    db
} from "../../js/firebase.js";


import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";


import {
    collection,
    addDoc,
    getDocs,
    getDoc,
    doc,
    query,
    orderBy,
    updateDoc,
    serverTimestamp,
    arrayUnion
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


/* =========================================================
   CONFIG
========================================================= */

const SUPPORT_COLLECTION =
    "supportTickets";


const USERS_COLLECTION =
    "users";


const NOTIFICATIONS_COLLECTION =
    "notifications";


/* =========================================================
   APP STATE
========================================================= */

const App = {

    currentAdmin:
        null,

    tickets:
        [],

    filteredTickets:
        [],

    selectedTicket:
        null,

    memberCache:
        new Map(),

    loading:
        false

};


/* =========================================================
   ELEMENTS
========================================================= */

const elements = {

    /* -----------------------------------------
       Statistics
    ----------------------------------------- */

    totalTickets:
        document.getElementById(
            "totalTickets"
        ),

    openTickets:
        document.getElementById(
            "openTickets"
        ),

    reviewTickets:
        document.getElementById(
            "reviewTickets"
        ),

    answeredTickets:
        document.getElementById(
            "answeredTickets"
        ),

    resolvedTickets:
        document.getElementById(
            "resolvedTickets"
        ),


    /* -----------------------------------------
       Search / Filters
    ----------------------------------------- */

    ticketSearch:
        document.getElementById(
            "ticketSearch"
        ),

    statusFilter:
        document.getElementById(
            "statusFilter"
        ),

    categoryFilter:
        document.getElementById(
            "categoryFilter"
        ),


    /* -----------------------------------------
       Buttons
    ----------------------------------------- */

    refreshTicketsBtn:
        document.getElementById(
            "refreshTicketsBtn"
        ),

    retryTicketsBtn:
        document.getElementById(
            "retryTicketsBtn"
        ),


    /* -----------------------------------------
       Ticket State
    ----------------------------------------- */

    ticketLoading:
        document.getElementById(
            "ticketLoading"
        ),

    ticketEmpty:
        document.getElementById(
            "ticketEmpty"
        ),

    ticketError:
        document.getElementById(
            "ticketError"
        ),

    ticketErrorMessage:
        document.getElementById(
            "ticketErrorMessage"
        ),

    ticketList:
        document.getElementById(
            "ticketList"
        ),

    ticketResultText:
        document.getElementById(
            "ticketResultText"
        ),


    /* -----------------------------------------
       Ticket Modal
    ----------------------------------------- */

    ticketModal:
        document.getElementById(
            "ticketModal"
        ),

    closeModalBtn:
        document.getElementById(
            "closeModalBtn"
        ),


    /* -----------------------------------------
       Modal Member Information
    ----------------------------------------- */

    modalTicketId:
        document.getElementById(
            "modalTicketId"
        ),

    modalMemberName:
        document.getElementById(
            "modalMemberName"
        ),

    modalMemberId:
        document.getElementById(
            "modalMemberId"
        ),

    modalMemberEmail:
        document.getElementById(
            "modalMemberEmail"
        ),


    /* -----------------------------------------
       Modal Ticket Information
    ----------------------------------------- */

    modalCategory:
        document.getElementById(
            "modalCategory"
        ),

    modalStatus:
        document.getElementById(
            "modalStatus"
        ),

    modalCreatedAt:
        document.getElementById(
            "modalCreatedAt"
        ),

    modalTransactionId:
        document.getElementById(
            "modalTransactionId"
        ),

    modalSubject:
        document.getElementById(
            "modalSubject"
        ),

    modalMessage:
        document.getElementById(
            "modalMessage"
        ),


    /* -----------------------------------------
       Admin Reply
    ----------------------------------------- */

    adminReply:
        document.getElementById(
            "adminReply"
        ),

    replyCount:
        document.getElementById(
            "replyCount"
        ),

    sendReplyBtn:
        document.getElementById(
            "sendReplyBtn"
        ),


    /* -----------------------------------------
       Status Update
    ----------------------------------------- */

    updateStatusBtn:
        document.getElementById(
            "updateStatusBtn"
        ),


    /* -----------------------------------------
       Toast
    ----------------------------------------- */

    adminToast:
        document.getElementById(
            "adminToast"
        ),

    toastIcon:
        document.getElementById(
            "toastIcon"
        ),

    toastMessage:
        document.getElementById(
            "toastMessage"
        ),


    /* -----------------------------------------
       Conversation
    ----------------------------------------- */

    adminConversationList:
        document.getElementById(
            "adminConversationList"
        )

};


/* =========================================================
   INITIALIZATION
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        initializeEvents();

    }
);


/* =========================================================
   AUTHENTICATION
========================================================= */

onAuthStateChanged(
    auth,
    async (user) => {

        if (!user) {

            window.location.href =
                "../login.html";

            return;

        }


        try {

            App.currentAdmin =
                user;


            console.log(
                "========== ADMIN DEBUG =========="
            );


            console.log(
                "Logged-in UID:",
                user.uid
            );


            console.log(
                "Logged-in Email:",
                user.email
            );


            console.log(
                "================================="
            );


            const isAdmin =
                await verifyAdmin(
                    user
                );


            if (!isAdmin) {

                await alert(
                    "❌ আপনার Admin access নেই।"
                );


                window.location.href =
                    "../dashboard.html";


                return;

            }


            /*
             * IMPORTANT:
             * এখানে loadTickets()
             * শুধুমাত্র একবার।
             */

            await loadTickets();

        }
        catch (error) {

            console.error(
                "❌ Admin initialization error:",
                error
            );


            showError(
                error.message
            );

        }

    }
);


/* =========================================================
   VERIFY ADMIN
========================================================= */

async function verifyAdmin(currentUser) {

    try {

        console.log(
            "🔐 Admin Check UID:",
            currentUser.uid
        );


        /* =====================================
           CENTRAL SUPER ADMIN ACCESS
        ===================================== */
        const adminSnap = await getDoc(doc(db, "admins", "superadmin"));
        const admin = adminSnap.exists() ? adminSnap.data() : null;
        const centralAdmin = admin && admin.active === true &&
            String(admin.role || "").trim().toLowerCase() === "super_admin" &&
            String(admin.email || "").trim().toLowerCase() === String(currentUser.email || "").trim().toLowerCase();

        if (centralAdmin) {
            console.log("👑 Super Admin Access Granted");
            return true;
        }


        /* =====================================
           FIRESTORE USER CHECK
        ===================================== */

        const userRef =
            doc(
                db,
                USERS_COLLECTION,
                currentUser.uid
            );


        const userSnap =
            await getDoc(
                userRef
            );


        console.log(
            "📄 User Document Exists:",
            userSnap.exists()
        );


        if (!userSnap.exists()) {

            return false;

        }


        const data =
            userSnap.data();


        console.log(
            "👤 Admin User Data:",
            data
        );


        const role =
            String(
                data.role || ""
            )
            .trim()
            .toLowerCase();


        console.log(
            "🔑 Detected Role:",
            role
        );


        const allowedRoles = [

            "admin",

            "superadmin",

            "super admin",

            "super_admin"

        ];


        const isAdmin =
            allowedRoles.includes(
                role
            );


        console.log(
            "✅ Admin Access:",
            isAdmin
        );


        return isAdmin;

    }
    catch (error) {

        console.error(
            "❌ Admin Verification Error:",
            error
        );

        return false;

    }

}


/* =========================================================
   EVENT LISTENERS
========================================================= */

function initializeEvents() {


    /* -----------------------------------------
       Search
    ----------------------------------------- */

    if (elements.ticketSearch) {

        elements.ticketSearch.addEventListener(
            "input",
            () => {

                applyFilters();

            }
        );

    }


    /* -----------------------------------------
       Status Filter
    ----------------------------------------- */

    if (elements.statusFilter) {

        elements.statusFilter.addEventListener(
            "change",
            () => {

                applyFilters();

            }
        );

    }


    /* -----------------------------------------
       Category Filter
    ----------------------------------------- */

    if (elements.categoryFilter) {

        elements.categoryFilter.addEventListener(
            "change",
            () => {

                applyFilters();

            }
        );

    }


    /* -----------------------------------------
       Refresh
    ----------------------------------------- */

    if (elements.refreshTicketsBtn) {

        elements.refreshTicketsBtn.addEventListener(
            "click",
            async () => {

                await loadTickets();

            }
        );

    }


    /* -----------------------------------------
       Retry
    ----------------------------------------- */

    if (elements.retryTicketsBtn) {

        elements.retryTicketsBtn.addEventListener(
            "click",
            async () => {

                await loadTickets();

            }
        );

    }


    /* -----------------------------------------
       Close Modal
    ----------------------------------------- */

    if (elements.closeModalBtn) {

        elements.closeModalBtn.addEventListener(
            "click",
            closeTicketModal
        );

    }


    /* -----------------------------------------
       Modal Background
    ----------------------------------------- */

    if (elements.ticketModal) {

        elements.ticketModal.addEventListener(
            "click",
            (event) => {

                if (
                    event.target ===
                    elements.ticketModal
                ) {

                    closeTicketModal();

                }

            }
        );

    }


    /* -----------------------------------------
       Escape Key
    ----------------------------------------- */

    document.addEventListener(
        "keydown",
        (event) => {

            if (
                event.key === "Escape"
            ) {

                closeTicketModal();

            }

        }
    );


    /* -----------------------------------------
       Reply Character Count
    ----------------------------------------- */

    if (elements.adminReply) {

        elements.adminReply.addEventListener(
            "input",
            updateReplyCount
        );

    }


    /* -----------------------------------------
       Send Reply
    ----------------------------------------- */

    if (elements.sendReplyBtn) {

        elements.sendReplyBtn.addEventListener(
            "click",
            sendAdminReply
        );

    }


    /* -----------------------------------------
       Update Status
    ----------------------------------------- */

    if (elements.updateStatusBtn) {

        elements.updateStatusBtn.addEventListener(
            "click",
            updateTicketStatus
        );

    }

}


/* =========================================================
   LOAD ALL TICKETS
========================================================= */

async function loadTickets() {

    if (App.loading) {

        return;

    }


    App.loading =
        true;


    showLoading();


    try {

        const ticketsRef =
            collection(
                db,
                SUPPORT_COLLECTION
            );


        const ticketsQuery =
            query(
                ticketsRef,
                orderBy(
                    "createdAt",
                    "desc"
                )
            );


        const snapshot =
            await getDocs(
                ticketsQuery
            );


        App.tickets =
            [];


        snapshot.forEach(
            (ticketDoc) => {

                App.tickets.push({

                    id:
                        ticketDoc.id,

                    ...ticketDoc.data()

                });

            }
        );


        App.filteredTickets =
            [
                ...App.tickets
            ];


        updateStatistics();


        applyFilters();


        hideLoading();

    }
    catch (error) {

        console.error(
            "❌ Support ticket load error:",
            error
        );


        showError(
            error.message
        );

    }
    finally {

        App.loading =
            false;

    }

}


/* =========================================================
   FILTER SYSTEM
========================================================= */

function applyFilters() {

    const search =
        String(
            elements.ticketSearch?.value ||
            ""
        )
        .trim()
        .toLowerCase();


    const status =
        String(
            elements.statusFilter?.value ||
            "all"
        );


    const category =
        String(
            elements.categoryFilter?.value ||
            "all"
        );


    App.filteredTickets =
        App.tickets.filter(
            (ticket) => {


                /* ---------------------------------
                   SEARCH
                --------------------------------- */

                const searchableText = [

                    ticket.ticketId,

                    ticket.uid,

                    ticket.userId,

                    ticket.customUserId,

                    ticket.email,

                    ticket.subject,

                    ticket.message,

                    ticket.category,

                    ticket.transactionId

                ]
                .map(
                    value =>
                        String(
                            value || ""
                        )
                        .toLowerCase()
                )
                .join(" ");


                const matchesSearch =
                    !search ||
                    searchableText.includes(
                        search
                    );


                /* ---------------------------------
                   STATUS
                --------------------------------- */

                const ticketStatus =
                    normalizeStatus(
                        ticket.status
                    );


                const matchesStatus =
                    status === "all" ||
                    ticketStatus ===
                        normalizeStatus(
                            status
                        );


                /* ---------------------------------
                   CATEGORY
                --------------------------------- */

                const ticketCategory =
                    String(
                        ticket.category ||
                        ""
                    )
                    .trim()
                    .toLowerCase();


                const matchesCategory =
                    category === "all" ||
                    ticketCategory ===
                        category
                            .trim()
                            .toLowerCase();


                return (
                    matchesSearch &&
                    matchesStatus &&
                    matchesCategory
                );

            }
        );


    renderTickets();


    updateResultText();

}


/* =========================================================
   UPDATE STATISTICS
========================================================= */

function updateStatistics() {

    const tickets =
        App.tickets;


    const total =
        tickets.length;


    const open =
        tickets.filter(
            ticket =>
                normalizeStatus(
                    ticket.status
                ) === "open"
        ).length;


    const review =
        tickets.filter(
            ticket =>
                normalizeStatus(
                    ticket.status
                ) === "under review"
        ).length;


    const answered =
        tickets.filter(
            ticket =>
                normalizeStatus(
                    ticket.status
                ) === "answered"
        ).length;


    const resolved =
        tickets.filter(
            ticket =>
                normalizeStatus(
                    ticket.status
                ) === "resolved"
        ).length;


    setText(
        elements.totalTickets,
        total
    );


    setText(
        elements.openTickets,
        open
    );


    setText(
        elements.reviewTickets,
        review
    );


    setText(
        elements.answeredTickets,
        answered
    );


    setText(
        elements.resolvedTickets,
        resolved
    );

}


/* =========================================================
   END OF PART 1 / 3
========================================================= */

/* =========================================================
   RENDER TICKETS
========================================================= */

function renderTickets() {

    if (!elements.ticketList) {
        return;
    }


    elements.ticketList.innerHTML =
        "";


    if (
        !App.filteredTickets.length
    ) {

        showEmpty();

        return;

    }


    hideEmpty();


    App.filteredTickets.forEach(
        (ticket) => {

            const card =
                createTicketCard(
                    ticket
                );


            elements.ticketList.appendChild(
                card
            );

        }
    );

}


/* =========================================================
   CREATE TICKET CARD
========================================================= */

function createTicketCard(
    ticket
) {

    const card =
        document.createElement(
            "div"
        );


    card.className =
        "ticket-card";


    /* -----------------------------------------
       STATUS
    ----------------------------------------- */

    const status =
        normalizeStatus(
            ticket.status
        );


    const statusClass =
        getStatusClass(
            status
        );


    const statusText =
        formatStatus(
            status
        );


    /* -----------------------------------------
       DATE
    ----------------------------------------- */

    const created =
        formatDate(
            ticket.createdAt
        );


    /* -----------------------------------------
       BASIC DATA
    ----------------------------------------- */

    const subject =
        ticket.subject ||
        "Support Request";


    const category =
        ticket.category ||
        "Other";


    const ticketId =
        ticket.ticketId ||
        ticket.id ||
        "N/A";


    const preview =
        ticket.message ||
        "No message";


    /*
     * IMPORTANT:
     *
     * Firebase UID কখনোই এখানে
     * NetEarn ID হিসেবে দেখানো হবে না।
     *
     * আগে customUserId,
     * তারপর valid custom userId।
     */

    const memberId =
        getDisplayMemberId(
            ticket
        );


    /* -----------------------------------------
       CARD HTML
    ----------------------------------------- */

    card.innerHTML = `

        <div class="ticket-top">

            <div class="ticket-main">

                <div class="ticket-subject">

                    ${escapeHtml(
                        subject
                    )}

                </div>


                <div class="ticket-meta">

                    <span class="ticket-id">

                        ${escapeHtml(
                            ticketId
                        )}

                    </span>


                    <span class="dot">
                        •
                    </span>


                    <span>

                        ${escapeHtml(
                            category
                        )}

                    </span>


                    <span class="dot">
                        •
                    </span>


                    <span>

                        ${escapeHtml(
                            memberId
                        )}

                    </span>


                    <span class="dot">
                        •
                    </span>


                    <span>

                        ${escapeHtml(
                            created
                        )}

                    </span>

                </div>


                <div class="ticket-preview">

                    ${escapeHtml(
                        preview
                    )}

                </div>

            </div>


            <div class="ticket-actions">

                <span
                    class="ticket-status ${statusClass}"
                >

                    ${escapeHtml(
                        statusText
                    )}

                </span>


                <button
                    type="button"
                    class="view-ticket-btn"
                >

                    <i class="bi bi-eye"></i>

                    View

                </button>

            </div>

        </div>

    `;


    /* -----------------------------------------
       OPEN MODAL
    ----------------------------------------- */

    card.addEventListener(
        "click",
        () => {

            openTicketModal(
                ticket
            );

        }
    );


    return card;

}


/* =========================================================
   OPEN TICKET MODAL
========================================================= */

async function openTicketModal(
    ticket
) {

    if (!ticket) {
        return;
    }


    App.selectedTicket =
        ticket;


    if (!elements.ticketModal) {
        return;
    }


    /* -----------------------------------------
       TICKET ID
    ----------------------------------------- */

    setModalValue(
        elements.modalTicketId,
        ticket.ticketId ||
        ticket.id ||
        "N/A"
    );


    /* -----------------------------------------
       CATEGORY
    ----------------------------------------- */

    setModalValue(
        elements.modalCategory,
        ticket.category ||
        "Other"
    );


    /* -----------------------------------------
       CREATED DATE
    ----------------------------------------- */

    setModalValue(
        elements.modalCreatedAt,
        formatDate(
            ticket.createdAt
        )
    );


    /* -----------------------------------------
       TRANSACTION ID
    ----------------------------------------- */

    setModalValue(
        elements.modalTransactionId,
        ticket.transactionId ||
        "Not Provided"
    );


    /* -----------------------------------------
       SUBJECT
    ----------------------------------------- */

    setModalValue(
        elements.modalSubject,
        ticket.subject ||
        "Support Request"
    );


    /* -----------------------------------------
       MESSAGE
    ----------------------------------------- */

    setModalValue(
        elements.modalMessage,
        ticket.message ||
        "No message"
    );


    /* -----------------------------------------
       STATUS
    ----------------------------------------- */

    if (
        elements.modalStatus
    ) {

        elements.modalStatus.value =
            normalizeStatus(
                ticket.status
            );

    }


    /* -----------------------------------------
       EXISTING ADMIN REPLY
    ----------------------------------------- */

    if (
        elements.adminReply
    ) {

        elements.adminReply.value =
            ticket.adminReply ||
            "";


        updateReplyCount();

    }


    /* -----------------------------------------
       MEMBER DEFAULT INFO
    ----------------------------------------- */

    setModalValue(
        elements.modalMemberName,
        "Loading member..."
    );


    setModalValue(
        elements.modalMemberId,
        getDisplayMemberId(
            ticket
        )
    );


    setModalValue(
        elements.modalMemberEmail,
        ticket.email ||
        "-"
    );


    /* -----------------------------------------
       SHOW MODAL
    ----------------------------------------- */

    elements.ticketModal.classList.remove(
        "hidden"
    );


    document.body.style.overflow =
        "hidden";


    /* -----------------------------------------
       LOAD MEMBER PROFILE
    ----------------------------------------- */

    await loadMemberInformation(
        ticket
    );


    /* -----------------------------------------
       RENDER CONVERSATION
    ----------------------------------------- */

    renderAdminConversation(
        ticket
    );

}


/* =========================================================
   LOAD MEMBER INFORMATION
========================================================= */

async function loadMemberInformation(
    ticket
) {

    if (!ticket) {
        return;
    }


    const uid =
        ticket.uid ||
        ticket.userUid;


    /* -----------------------------------------
       NO UID
    ----------------------------------------- */

    if (!uid) {

        setModalValue(
            elements.modalMemberName,
            ticket.username ||
            "Member"
        );


        setModalValue(
            elements.modalMemberId,
            getDisplayMemberId(
                ticket
            )
        );


        setModalValue(
            elements.modalMemberEmail,
            ticket.email ||
            "-"
        );


        return;

    }


    try {

        /* -----------------------------------------
           CACHE CHECK
        ----------------------------------------- */

        let memberData =
            App.memberCache.get(
                uid
            );


        /* -----------------------------------------
           FIRESTORE USER LOAD
        ----------------------------------------- */

        if (!memberData) {

            const userSnap =
                await getDoc(
                    doc(
                        db,
                        USERS_COLLECTION,
                        uid
                    )
                );


            memberData =
                userSnap.exists()
                    ? userSnap.data()
                    : {};


            App.memberCache.set(
                uid,
                memberData
            );

        }


        /* -----------------------------------------
           MEMBER NAME
        ----------------------------------------- */

        const name =
            memberData.username ||
            memberData.name ||
            ticket.username ||
            "Member";


        /* -----------------------------------------
           CUSTOM NETEARN ID
           NEVER FIREBASE UID
        ----------------------------------------- */

        const customUserId =
            memberData.userId ||
            ticket.customUserId ||
            (
                ticket.userId &&
                !isFirebaseUid(
                    ticket.userId
                )
                    ? ticket.userId
                    : ""
            ) ||
            "N/A";


        /* -----------------------------------------
           EMAIL
        ----------------------------------------- */

        const email =
            memberData.email ||
            ticket.email ||
            "-";


        /* -----------------------------------------
           UPDATE MODAL
        ----------------------------------------- */

        setModalValue(
            elements.modalMemberName,
            name
        );


        setModalValue(
            elements.modalMemberId,
            customUserId
        );


        setModalValue(
            elements.modalMemberEmail,
            email
        );

    }
    catch (error) {

        console.error(
            "❌ Member information error:",
            error
        );


        /*
         * Error হলেও ticket modal বন্ধ হবে না।
         */

        setModalValue(
            elements.modalMemberName,
            ticket.username ||
            "Member"
        );


        setModalValue(
            elements.modalMemberId,
            getDisplayMemberId(
                ticket
            )
        );


        setModalValue(
            elements.modalMemberEmail,
            ticket.email ||
            "-"
        );

    }

}


/* =========================================================
   DISPLAY MEMBER ID
========================================================= */

function getDisplayMemberId(
    ticket
) {

    if (!ticket) {
        return "N/A";
    }


    /* -----------------------------------------
       PRIMARY CUSTOM ID
    ----------------------------------------- */

    if (
        ticket.customUserId
    ) {

        const customId =
            String(
                ticket.customUserId
            ).trim();


        if (
            customId &&
            !isFirebaseUid(
                customId
            )
        ) {

            return customId;

        }

    }


    /* -----------------------------------------
       USER ID
    ----------------------------------------- */

    if (
        ticket.userId &&
        !isFirebaseUid(
            ticket.userId
        )
    ) {

        return String(
            ticket.userId
        );

    }


    /*
     * IMPORTANT:
     *
     * Firebase UID কখনো fallback হবে না।
     */

    return "N/A";

}


/* =========================================================
   CHECK FIREBASE UID
========================================================= */

function isFirebaseUid(
    value
) {

    const text =
        String(
            value || ""
        ).trim();


    if (!text) {

        return true;

    }


    /* -----------------------------------------
       Explicit Firebase Prefix
    ----------------------------------------- */

    if (
        text.startsWith(
            "firebase:"
        )
    ) {

        return true;

    }


    /* -----------------------------------------
       NetEarn Custom ID
    ----------------------------------------- */

    if (
        text.startsWith(
            "NEP"
        )
    ) {

        return false;

    }


    /*
     * Firebase UID সাধারণত
     * দীর্ঘ alphanumeric string।
     */

    return (
        text.length >= 20 &&
        /^[A-Za-z0-9_-]+$/.test(
            text
        )
    );

}


/* =========================================================
   END OF PART 2 / 3
========================================================= */

/* =========================================================
   SEND ADMIN REPLY
========================================================= */

async function sendAdminReply() {

    if (!App.selectedTicket) {

        showToast(
            "⚠️ কোনো Ticket নির্বাচন করা হয়নি।",
            "error"
        );

        return;

    }


    const reply =
        String(
            elements.adminReply?.value ||
            ""
        )
        .trim();


    /* -----------------------------------------
       VALIDATION
    ----------------------------------------- */

    if (!reply) {

        showToast(
            "⚠️ Admin Reply লিখুন।",
            "error"
        );

        elements.adminReply?.focus();

        return;

    }


    if (reply.length < 3) {

        showToast(
            "⚠️ Reply একটু বিস্তারিত লিখুন।",
            "error"
        );

        return;

    }


    if (reply.length > 2000) {

        showToast(
            "⚠️ Reply সর্বোচ্চ 2000 অক্ষর হতে পারবে।",
            "error"
        );

        return;

    }


    /* -----------------------------------------
       ADMIN SESSION
    ----------------------------------------- */

    if (!App.currentAdmin?.uid) {

        showToast(
            "❌ Admin session পাওয়া যায়নি।",
            "error"
        );

        return;

    }


    const ticket =
        App.selectedTicket;


    if (!ticket.id) {

        showToast(
            "❌ Ticket Document ID পাওয়া যায়নি।",
            "error"
        );

        return;

    }


    /* -----------------------------------------
       CONFIRM
    ----------------------------------------- */

    const confirmed =
        await NetEarnDialog.confirm(
            "💬 এই Member-কে Reply পাঠাবেন?"
        );


    if (!confirmed) {
        return;
    }


    /* -----------------------------------------
       BUTTON LOADING
    ----------------------------------------- */

    setButtonLoading(
        elements.sendReplyBtn,
        true,
        "Sending..."
    );


    try {

        /* ---------------------------------------
           TICKET REFERENCE
        --------------------------------------- */

        const ticketRef =
            doc(
                db,
                SUPPORT_COLLECTION,
                ticket.id
            );


        /* ---------------------------------------
           CONVERSATION MESSAGE
        --------------------------------------- */

        const conversationMessage = {

            sender:
                "admin",

            uid:
                App.currentAdmin.uid,

            email:
                App.currentAdmin.email ||
                "",

            message:
                reply,

            createdAt:
                new Date()

        };


        /* ---------------------------------------
           UPDATE SUPPORT TICKET
        --------------------------------------- */

        await updateDoc(
            ticketRef,
            {

                adminReply:
                    reply,

                conversation:
                    arrayUnion(
                        conversationMessage
                    ),

                status:
                    "Answered",

                repliedBy:
                    App.currentAdmin.uid,

                repliedAt:
                    serverTimestamp(),

                updatedAt:
                    serverTimestamp()

            }
        );


        /* =================================================
           CREATE USER NOTIFICATION
           Admin Reply → User Dashboard 🔔
        ================================================= */

        const notificationUid =
            ticket.uid ||
            ticket.userUid;


        if (notificationUid) {

            await addDoc(
                collection(
                    db,
                    "notifications"
                ),
                {

                    userUid:
                        notificationUid,

                    type:
                        "support_reply",

                    title:
                        "💬 Support Reply",

                    message:
                        "আপনার Support Ticket-এর জন্য Admin একটি Reply দিয়েছেন।",

                    ticketId:
                        ticket.ticketId ||
                        ticket.id ||
                        "",

                    supportTicketId:
                        ticket.id,

                    read:
                        false,

                    createdAt:
                        serverTimestamp(),

                    createdBy:
                        App.currentAdmin.uid,

                    createdByEmail:
                        App.currentAdmin.email ||
                        ""

                }
            );

        }


        /* ---------------------------------------
           UPDATE LOCAL TICKET
        --------------------------------------- */

        updateLocalTicket(
            ticket.id,
            {

                adminReply:
                    reply,

                status:
                    "Answered",

                repliedBy:
                    App.currentAdmin.uid,

                conversation:
                    addConversationLocally(
                        ticket.conversation,
                        conversationMessage
                    )

            }
        );


        /* ---------------------------------------
           REFRESH SELECTED TICKET
        --------------------------------------- */

        App.selectedTicket =
            findTicketById(
                ticket.id
            );


        /* ---------------------------------------
           UPDATE MODAL STATUS
        --------------------------------------- */

        if (
            elements.modalStatus
        ) {

            /*
             * NormalizeStatus "answered"
             * হিসেবে value নেবে।
             */

            elements.modalStatus.value =
                normalizeStatus(
                    "Answered"
                );

        }


        /* ---------------------------------------
           CLEAR REPLY BOX
        --------------------------------------- */

        if (
            elements.adminReply
        ) {

            elements.adminReply.value =
                "";

            updateReplyCount();

        }


        /* ---------------------------------------
           RENDER CONVERSATION AGAIN
        --------------------------------------- */

        renderAdminConversation(
            App.selectedTicket
        );


        /* ---------------------------------------
           UPDATE DASHBOARD
        --------------------------------------- */

        updateStatistics();

        applyFilters();


        /* ---------------------------------------
           SUCCESS
        --------------------------------------- */

        showToast(
            "✅ Reply সফলভাবে পাঠানো হয়েছে।"
        );

    }
    catch (error) {

        console.error(
            "❌ Admin Reply Error:",
            error
        );


        console.error(
            "Error Code:",
            error.code
        );


        console.error(
            "Error Message:",
            error.message
        );


        showToast(
            "❌ Reply পাঠানো যায়নি।",
            "error"
        );

    }
    finally {

        setButtonLoading(
            elements.sendReplyBtn,
            false,
            "Send Reply"
        );

    }

}


/* =========================================================
   ADD CONVERSATION LOCALLY
========================================================= */

function addConversationLocally(
    existingConversation,
    newMessage
) {

    const list =
        Array.isArray(
            existingConversation
        )
            ? [...existingConversation]
            : [];


    list.push(
        newMessage
    );


    return list;

}


/* =========================================================
   RENDER ADMIN CONVERSATION
========================================================= */

function renderAdminConversation(
    ticket
) {

    const container =
        elements.adminConversationList;


    if (!container) {
        return;
    }


    container.innerHTML =
        "";


    let conversation =
        Array.isArray(
            ticket?.conversation
        )
            ? [...ticket.conversation]
            : [];


    /* -----------------------------------------
       OLD TICKET COMPATIBILITY
    ----------------------------------------- */

    if (
        !conversation.length
    ) {

        /*
         * Original User Message
         */

        if (
            ticket?.message
        ) {

            conversation.push({

                sender:
                    "user",

                uid:
                    ticket.uid ||
                    ticket.userUid ||
                    "",

                email:
                    ticket.email ||
                    "",

                message:
                    ticket.message,

                createdAt:
                    ticket.createdAt ||
                    null

            });

        }


        /*
         * Existing Admin Reply
         */

        if (
            ticket?.adminReply
        ) {

            conversation.push({

                sender:
                    "admin",

                uid:
                    ticket.repliedBy ||
                    "",

                email:
                    "",

                message:
                    ticket.adminReply,

                createdAt:
                    ticket.repliedAt ||
                    ticket.updatedAt ||
                    null

            });

        }

    }
    else {

        /* -------------------------------------
           MAKE SURE ORIGINAL USER MESSAGE
           EXISTS IN CONVERSATION
        ------------------------------------- */

        const initialMessage =
            String(
                ticket?.message ||
                ""
            )
            .trim();


        const hasInitialUserMessage =
            !!initialMessage &&
            conversation.some(
                item =>

                    normalizeConversationSender(
                        item?.sender
                    ) === "user"

                    &&

                    String(
                        item?.message ||
                        ""
                    )
                    .trim() ===
                    initialMessage
            );


        if (
            initialMessage &&
            !hasInitialUserMessage
        ) {

            conversation.unshift({

                sender:
                    "user",

                uid:
                    ticket.uid ||
                    ticket.userUid ||
                    "",

                email:
                    ticket.email ||
                    "",

                message:
                    initialMessage,

                createdAt:
                    ticket.createdAt ||
                    null

            });

        }

    }


    /* -----------------------------------------
       REMOVE EMPTY MESSAGES
    ----------------------------------------- */

    conversation =
        conversation.filter(
            item =>

                item &&

                String(
                    item.message ||
                    ""
                ).trim()
        );


    /* -----------------------------------------
       SORT OLDEST → NEWEST
    ----------------------------------------- */

    conversation.sort(
        (a, b) =>

            getTimestampMillis(
                a.createdAt
            )

            -

            getTimestampMillis(
                b.createdAt
            )
    );


    /* -----------------------------------------
       EMPTY CONVERSATION
    ----------------------------------------- */

    if (
        !conversation.length
    ) {

        container.innerHTML = `

            <div class="conversation-empty">

                <div class="conversation-empty-icon">

                    💬

                </div>


                <strong>

                    No Conversation Yet

                </strong>


                <p>

                    এই Ticket-এ এখনো কোনো
                    message নেই।

                </p>

            </div>

        `;

        return;

    }


    /* -----------------------------------------
       RENDER EACH MESSAGE
    ----------------------------------------- */

    conversation.forEach(
        (item) => {

            const sender =
                normalizeConversationSender(
                    item.sender
                );


            const message =
                String(
                    item.message ||
                    ""
                )
                .trim();


            if (!message) {
                return;
            }


            const row =
                document.createElement(
                    "div"
                );


            row.className =
                `conversation-message ${sender}`;


            const label =
                sender === "admin"
                    ? "👨‍💼 Admin"
                    : "👤 User";


            const date =
                formatDate(
                    item.createdAt
                );


            row.innerHTML = `

                <span
                    class="conversation-message-label"
                >

                    ${escapeHtml(
                        label
                    )}

                </span>


                <div
                    class="conversation-message-text"
                >

                    ${escapeHtml(
                        message
                    )}

                </div>


                <span
                    class="conversation-message-date"
                >

                    ${escapeHtml(
                        date
                    )}

                </span>

            `;


            container.appendChild(
                row
            );

        }
    );


    /* -----------------------------------------
       AUTO SCROLL TO BOTTOM
    ----------------------------------------- */

    requestAnimationFrame(
        () => {

            container.scrollTop =
                container.scrollHeight;

        }
    );

}


/* =========================================================
   NORMALIZE CONVERSATION SENDER
========================================================= */

function normalizeConversationSender(
    sender
) {

    const value =
        String(
            sender ||
            "user"
        )
        .trim()
        .toLowerCase();


    if (
        value === "admin" ||
        value === "support" ||
        value === "staff"
    ) {

        return "admin";

    }


    return "user";

}


/* =========================================================
   UPDATE TICKET STATUS
========================================================= */

async function updateTicketStatus() {

    if (
        !App.selectedTicket
    ) {

        showToast(
            "⚠️ কোনো Ticket নির্বাচন করা হয়নি।",
            "error"
        );

        return;

    }


    const newStatus =
        elements.modalStatus?.value ||
        "open";


    const currentStatus =
        normalizeStatus(
            App.selectedTicket.status
        );


    const normalizedNewStatus =
        normalizeStatus(
            newStatus
        );


    /* -----------------------------------------
       NO CHANGE
    ----------------------------------------- */

    if (
        currentStatus ===
        normalizedNewStatus
    ) {

        showToast(
            "ℹ️ কোনো Status পরিবর্তন করা হয়নি।"
        );

        return;

    }


    setButtonLoading(
        elements.updateStatusBtn,
        true,
        "Updating..."
    );


    try {

        const ticket =
            App.selectedTicket;


        const ticketRef =
            doc(
                db,
                SUPPORT_COLLECTION,
                ticket.id
            );


        /*
         * Keep the user's selected status.
         * "Answered" / "Closed" etc.
         */

        await updateDoc(
            ticketRef,
            {

                status:
                    formatStatus(
                        normalizedNewStatus
                    ),

                updatedAt:
                    serverTimestamp(),

                statusUpdatedBy:
                    App.currentAdmin?.uid ||
                    ""

            }
        );


        /* -----------------------------------------
           LOCAL UPDATE
        ----------------------------------------- */

        updateLocalTicket(
            ticket.id,
            {

                status:
                    formatStatus(
                        normalizedNewStatus
                    )

            }
        );


        App.selectedTicket =
            findTicketById(
                ticket.id
            );


        /* -----------------------------------------
           UPDATE MODAL STATUS
        ----------------------------------------- */

        if (
            elements.modalStatus
        ) {

            elements.modalStatus.value =
                normalizeStatus(
                    normalizedNewStatus
                );

        }


        /* -----------------------------------------
           REFRESH UI
        ----------------------------------------- */

        updateStatistics();

        applyFilters();


        showToast(
            "✅ Ticket Status updated হয়েছে।"
        );

    }
    catch (error) {

        console.error(
            "❌ Status update error:",
            error
        );


        console.error(
            "Error Code:",
            error.code
        );


        console.error(
            "Error Message:",
            error.message
        );


        showToast(
            "❌ Status update করা যায়নি।",
            "error"
        );

    }
    finally {

        setButtonLoading(
            elements.updateStatusBtn,
            false,
            "Update Ticket"
        );

    }

}


/* =========================================================
   UPDATE LOCAL TICKET
========================================================= */

function updateLocalTicket(
    ticketId,
    changes
) {

    const index =
        App.tickets.findIndex(
            ticket =>
                ticket.id ===
                ticketId
        );


    if (
        index === -1
    ) {

        return;

    }


    App.tickets[index] = {

        ...App.tickets[index],

        ...changes

    };

}


/* =========================================================
   FIND TICKET
========================================================= */

function findTicketById(
    ticketId
) {

    return (

        App.tickets.find(
            ticket =>
                ticket.id ===
                ticketId
        )

        ||

        null

    );

}


/* =========================================================
   CLOSE TICKET MODAL
========================================================= */

function closeTicketModal() {

    if (
        !elements.ticketModal
    ) {

        return;

    }


    elements.ticketModal.classList.add(
        "hidden"
    );


    document.body.style.overflow =
        "";


    App.selectedTicket =
        null;

}


/* =========================================================
   REPLY CHARACTER COUNT
========================================================= */

function updateReplyCount() {

    if (
        !elements.adminReply ||
        !elements.replyCount
    ) {

        return;

    }


    elements.replyCount.textContent =
        String(
            elements.adminReply.value.length
        );

}

/* =========================================================
   NORMALIZE STATUS
========================================================= */

function normalizeStatus(
    status
) {

    const value =
        String(
            status ||
            "Open"
        )
        .trim()
        .toLowerCase();


    if (
        value === "pending" ||
        value === "open"
    ) {

        return "open";

    }


    if (
        value === "review" ||
        value === "under review" ||
        value === "under_review"
    ) {

        return "under review";

    }


    if (
        value === "replied" ||
        value === "answered"
    ) {

        return "answered";

    }


    if (
        value === "closed"
    ) {

        return "closed";

    }


    if (
        value === "resolved"
    ) {

        return "resolved";

    }


    return "open";

}


/* =========================================================
   FORMAT STATUS
========================================================= */

function formatStatus(
    status
) {

    switch (
        normalizeStatus(
            status
        )
    ) {

        case "under review":

            return "Under Review";


        case "answered":

            return "Answered";


        case "resolved":

            return "Resolved";


        case "closed":

            return "Closed";


        default:

            return "Open";

    }

}


/* =========================================================
   STATUS CSS CLASS
========================================================= */

function getStatusClass(
    status
) {

    switch (
        normalizeStatus(
            status
        )
    ) {

        case "under review":

            return "status-review";


        case "answered":

            return "status-answered";


        case "resolved":

            return "status-resolved";


        case "closed":

            return "status-closed";


        default:

            return "status-open";

    }

}


/* =========================================================
   DATE FORMAT
========================================================= */

function formatDate(
    timestamp
) {

    if (!timestamp) {

        return "Just now";

    }


    try {

        const date =

            typeof timestamp.toDate ===
            "function"

                ?

            timestamp.toDate()

                :

            timestamp instanceof Date

                ?

            timestamp

                :

            new Date(
                timestamp
            );


        if (
            Number.isNaN(
                date.getTime()
            )
        ) {

            return "Unknown date";

        }


        return date.toLocaleString(
            "en-BD",
            {

                day:
                    "2-digit",

                month:
                    "short",

                year:
                    "numeric",

                hour:
                    "2-digit",

                minute:
                    "2-digit"

            }
        );

    }
    catch {

        return "Unknown date";

    }

}


/* =========================================================
   TIMESTAMP → MILLISECONDS
========================================================= */

function getTimestampMillis(
    timestamp
) {

    if (!timestamp) {

        return 0;

    }


    try {

        if (
            typeof timestamp.toMillis ===
            "function"
        ) {

            return timestamp.toMillis();

        }


        if (
            typeof timestamp.toDate ===
            "function"
        ) {

            return timestamp
                .toDate()
                .getTime();

        }


        if (
            timestamp instanceof Date
        ) {

            return timestamp.getTime();

        }


        const date =
            new Date(
                timestamp
            );


        const millis =
            date.getTime();


        return Number.isFinite(
            millis
        )
            ? millis
            : 0;

    }
    catch {

        return 0;

    }

}


/* =========================================================
   RESULT TEXT
========================================================= */

function updateResultText() {

    if (
        !elements.ticketResultText
    ) {

        return;

    }


    const count =
        App.filteredTickets.length;


    elements.ticketResultText.textContent =
        `${count} support ticket${count === 1 ? "" : "s"} found`;

}


/* =========================================================
   SHOW LOADING
========================================================= */

function showLoading() {

    elements.ticketLoading
        ?.classList
        .remove(
            "hidden"
        );


    elements.ticketEmpty
        ?.classList
        .add(
            "hidden"
        );


    elements.ticketError
        ?.classList
        .add(
            "hidden"
        );


    if (
        elements.ticketList
    ) {

        elements.ticketList.innerHTML =
            "";

    }

}


/* =========================================================
   HIDE LOADING
========================================================= */

function hideLoading() {

    elements.ticketLoading
        ?.classList
        .add(
            "hidden"
        );

}


/* =========================================================
   SHOW EMPTY
========================================================= */

function showEmpty() {

    elements.ticketEmpty
        ?.classList
        .remove(
            "hidden"
        );

}


/* =========================================================
   HIDE EMPTY
========================================================= */

function hideEmpty() {

    elements.ticketEmpty
        ?.classList
        .add(
            "hidden"
        );

}


/* =========================================================
   SHOW ERROR
========================================================= */

function showError(
    message
) {

    elements.ticketLoading
        ?.classList
        .add(
            "hidden"
        );


    elements.ticketEmpty
        ?.classList
        .add(
            "hidden"
        );


    elements.ticketError
        ?.classList
        .remove(
            "hidden"
        );


    if (
        elements.ticketErrorMessage
    ) {

        elements.ticketErrorMessage.textContent =
            message ||
            "Support tickets load করা যায়নি।";

    }

}


/* =========================================================
   SET TEXT SAFELY
========================================================= */

function setText(
    element,
    value
) {

    if (element) {

        element.textContent =
            String(
                value ?? ""
            );

    }

}


/* =========================================================
   SET MODAL VALUE
========================================================= */

function setModalValue(
    element,
    value
) {

    if (element) {

        element.textContent =
            String(
                value ?? "-"
            );

    }

}


/* =========================================================
   BUTTON LOADING
========================================================= */

function setButtonLoading(
    button,
    loading,
    text
) {

    if (!button) {

        return;

    }


    if (loading) {

        if (
            !button.dataset.originalHtml
        ) {

            button.dataset.originalHtml =
                button.innerHTML;

        }


        button.disabled =
            true;


        button.innerHTML = `

            <i class="bi bi-arrow-repeat"></i>

            ${escapeHtml(
                text
            )}

        `;

    }
    else {

        button.disabled =
            false;


        if (
            button.dataset.originalHtml
        ) {

            button.innerHTML =
                button.dataset.originalHtml;


            delete button.dataset.originalHtml;

        }

    }

}


/* =========================================================
   TOAST
========================================================= */

let toastTimer =
    null;


function showToast(
    message,
    type = "success"
) {

    if (
        !elements.adminToast
    ) {

        return;

    }


    if (toastTimer) {

        clearTimeout(
            toastTimer
        );

    }


    if (
        elements.toastMessage
    ) {

        elements.toastMessage.textContent =
            message;

    }


    if (
        elements.toastIcon
    ) {

        if (
            type === "error"
        ) {

            elements.toastIcon.className =
                "bi bi-exclamation-circle-fill";

            elements.toastIcon.style.color =
                "#f87171";

        }
        else {

            elements.toastIcon.className =
                "bi bi-check-circle-fill";

            elements.toastIcon.style.color =
                "#4ade80";

        }

    }


    elements.adminToast.classList.add(
        "show"
    );


    toastTimer =
        setTimeout(
            () => {

                elements.adminToast.classList.remove(
                    "show"
                );

            },
            3000
        );

}


/* =========================================================
   HTML ESCAPE
========================================================= */
/* =========================================================
   INITIAL LOG
========================================================= */

console.log(
    "✅ NetEarn Pro Admin Support Center Loaded"
);

console.log(
    "🎫 Ticket System Enabled"
);

console.log(
    "👤 Member Information Enabled"
);

console.log(
    "💬 Admin Conversation UI Enabled"
);

console.log(
    "👨‍💼 Admin Reply Conversation Enabled"
);

console.log(
    "🔔 User Notification System Enabled"
);


/* =========================================================
   END OF admin-support.js
========================================================= */