import { escapeHtml } from "../../js/shared-utils.js";
// =======================================
// NetEarn Pro
// Admin Welcome Bonus Management
// FINAL CLEAN VERSION
// =======================================

import { db } from "../../js/firebase.js";

import {
    collection,
    getDocs,
    getDoc,
    doc,
    setDoc,
    runTransaction,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =======================================
// APP STATE
// =======================================

let currentFilter = "all";
let requests = [];


// =======================================
// LOAD REQUESTS
// =======================================

async function loadRequests() {

    const list =
        document.getElementById("requestList");

    if (!list) return;

    list.innerHTML = `
        <div class="empty">
            ⏳ Loading requests...
        </div>
    `;

    try {

        const snapshot =
            await getDocs(
                collection(
                    db,
                    "welcomeBonusRequests"
                )
            );

        requests =
            snapshot.docs.map(
                requestDoc => ({

                    id:
                        requestDoc.id,

                    ...requestDoc.data()

                })
            );

        renderRequests();

    }

    catch (error) {

        console.error(
            "❌ Welcome Bonus Load Error:",
            error
        );

        list.innerHTML = `
            <div class="empty">

                ❌ Failed to load requests.

                <br><br>

                Please check Firebase connection.

            </div>
        `;

    }

}


// =======================================
// NORMALIZE STATUS
// =======================================

function getStatus(item) {

    return String(
        item?.status || "pending"
    )
        .toLowerCase()
        .trim();

}


// =======================================
// GET USERNAME
// =======================================

function getUsername(item) {

    return (
        item?.username ||
        item?.name ||
        "Unknown User"
    );

}


// =======================================
// GET USER UID
// =======================================

function getUid(item) {

    return (
        item?.uid ||
        item?.firebaseUid ||
        item?.userId ||
        ""
    );

}


// =======================================
// GET USER ID
// =======================================

function getUserId(item) {

    return (
        item?.userId ||
        item?.uid ||
        item?.firebaseUid ||
        ""
    );

}


// =======================================
// GET BONUS AMOUNT
// =======================================

function getAmount(item) {

    const amount =
        Number(
            item?.amount ??
            item?.bonusAmount ??
            0
        );

    return Number.isFinite(amount)
        ? amount
        : 0;

}


// =======================================
// GET REQUEST DATE
// =======================================

function getRequestDate(item) {

    if (item?.date) {

        return String(
            item.date
        );

    }

    if (
        item?.createdAt &&
        typeof item.createdAt.toDate ===
        "function"
    ) {

        return item.createdAt
            .toDate()
            .toLocaleString();

    }

    if (item?.createdAt) {

        const date =
            new Date(
                item.createdAt
            );

        if (
            !Number.isNaN(
                date.getTime()
            )
        ) {

            return date.toLocaleString();

        }

    }

    return "—";

}


// =======================================
// RENDER REQUESTS
// =======================================

function renderRequests() {

    const list =
        document.getElementById(
            "requestList"
        );

    if (!list) return;


    const search =
        document.getElementById(
            "searchInput"
        )
        ?.value
        ?.toLowerCase()
        ?.trim() || "";


    const filtered =
        requests.filter(item => {

            const status =
                getStatus(item);

            const username =
                String(
                    getUsername(item)
                )
                    .toLowerCase();

            const uid =
                String(
                    getUid(item)
                )
                    .toLowerCase();

            const userId =
                String(
                    getUserId(item)
                )
                    .toLowerCase();


            const filterMatch =

                currentFilter === "all"

                ||

                status === currentFilter;


            const searchMatch =

                !search

                ||

                username.includes(
                    search
                )

                ||

                uid.includes(
                    search
                )

                ||

                userId.includes(
                    search
                );


            return (
                filterMatch &&
                searchMatch
            );

        });


    updateStats();


    if (!filtered.length) {

        list.innerHTML = `

            <div class="empty">

                📭 No requests found.

            </div>

        `;

        return;

    }


    list.innerHTML =
        filtered
            .map(item => {

                const status =
                    getStatus(item);

                const username =
                    getUsername(item);

                const uid =
                    getUid(item);

                const amount =
                    getAmount(item);

                const date =
                    getRequestDate(item);


                return `

                    <div
                        class="request-card"
                    >

                        <div
                            class="request-top"
                        >

                            <div>

                                <div
                                    class="user-name"
                                >

                                    ${escapeHtml(
                                        username
                                    )}

                                </div>


                                <div
                                    class="user-id"
                                >

                                    User ID:
                                    ${escapeHtml(
                                        getUserId(item) ||
                                        uid ||
                                        "Unknown"
                                    )}

                                </div>

                            </div>


                            <span
                                class="status ${escapeHtml(
                                    status
                                )}"
                            >

                                ${escapeHtml(
                                    status.toUpperCase()
                                )}

                            </span>

                        </div>


                        <div
                            class="request-details"
                        >

                            <div class="detail">

                                <small>
                                    🎁 Reward
                                </small>

                                <strong>
                                    Welcome Bonus
                                </strong>

                            </div>


                            <div class="detail">

                                <small>
                                    💰 Amount
                                </small>

                                <strong>
                                    ৳${amount}
                                </strong>

                            </div>


                            <div class="detail">

                                <small>
                                    📅 Request Date
                                </small>

                                <strong>
                                    ${escapeHtml(
                                        date
                                    )}
                                </strong>

                            </div>


                            <div class="detail">

                                <small>
                                    🆔 Request ID
                                </small>

                                <strong>
                                    ${escapeHtml(
                                        item.id
                                    )}
                                </strong>

                            </div>

                        </div>


                        <div class="actions">

                            <button
                                class="action-btn view-btn"
                                data-action="view"
                                data-id="${escapeHtml(
                                    item.id
                                )}"
                            >

                                👁️ View

                            </button>


                            ${
                                status === "pending"

                                ?

                                `

                                <button
                                    class="action-btn approve-btn"
                                    data-action="approve"
                                    data-id="${escapeHtml(
                                        item.id
                                    )}"
                                >

                                    ✅ Approve

                                </button>


                                <button
                                    class="action-btn reject-btn"
                                    data-action="reject"
                                    data-id="${escapeHtml(
                                        item.id
                                    )}"
                                >

                                    ❌ Reject

                                </button>

                                `

                                :

                                ""

                            }

                        </div>

                    </div>

                `;

            })
            .join("");

}


// =======================================
// HTML ESCAPE
// =======================================
// =======================================
// STATISTICS
// =======================================

function updateStats() {

    const allCount =
        document.getElementById(
            "allCount"
        );

    const pendingCount =
        document.getElementById(
            "pendingCount"
        );

    const approvedCount =
        document.getElementById(
            "approvedCount"
        );

    const rejectedCount =
        document.getElementById(
            "rejectedCount"
        );


    if (allCount) {

        allCount.textContent =
            requests.length;

    }


    if (pendingCount) {

        pendingCount.textContent =
            requests.filter(
                item =>
                    getStatus(item) ===
                    "pending"
            ).length;

    }


    if (approvedCount) {

        approvedCount.textContent =
            requests.filter(
                item =>
                    getStatus(item) ===
                    "approved"
            ).length;

    }


    if (rejectedCount) {

        rejectedCount.textContent =
            requests.filter(
                item =>
                    getStatus(item) ===
                    "rejected"
            ).length;

    }

}


// =======================================
// FILTER BUTTONS
// =======================================

document
    .querySelectorAll(
        ".filter-btn"
    )
    .forEach(button => {

        button.addEventListener(
            "click",
            () => {

                document
                    .querySelectorAll(
                        ".filter-btn"
                    )
                    .forEach(btn => {

                        btn.classList.remove(
                            "active"
                        );

                    });


                button.classList.add(
                    "active"
                );


                currentFilter =
                    button.dataset.filter ||
                    "all";


                renderRequests();

            }
        );

    });


// =======================================
// SEARCH
// =======================================

document
    .getElementById(
        "searchInput"
    )
    ?.addEventListener(
        "input",
        renderRequests
    );


// =======================================
// VIEW REQUEST
// =======================================

function viewRequest(id) {

    const item =
        requests.find(
            request =>
                request.id === id
        );


    if (!item) {

        alert(
            "❌ Request পাওয়া যায়নি।"
        );

        return;

    }


    alert(

        "🎁 Welcome Bonus Request\n\n" +

        "Username: " +
        getUsername(item) +

        "\nUser ID: " +
        (
            getUserId(item) ||
            "Unknown"
        ) +

        "\nFirebase UID: " +
        (
            getUid(item) ||
            "Unknown"
        ) +

        "\nAmount: ৳" +
        getAmount(item) +

        "\nStatus: " +
        getStatus(item).toUpperCase()

    );

}


// =======================================
// APPROVE WELCOME BONUS
// =======================================

async function approveRequest(id) {

    const item =
        requests.find(
            request =>
                request.id === id
        );


    if (!item) {

        alert(
            "❌ Request পাওয়া যায়নি।"
        );

        return;

    }


    const uid =
        getUid(item);


    if (!uid) {

        alert(
            "❌ User UID পাওয়া যায়নি।"
        );

        return;

    }


    const amount =
        getAmount(item);


    if (
        !Number.isFinite(amount) ||
        amount <= 0
    ) {

        alert(
            "❌ Invalid bonus amount."
        );

        return;

    }


    const confirmed =
        await NetEarnDialog.confirm(
            `🎁 Welcome Bonus ৳${amount} Approve করবেন?`
        );


    if (!confirmed) return;


    try {

        // =================================
        // FIRESTORE REFERENCES
        // =================================

        const requestRef =
            doc(
                db,
                "welcomeBonusRequests",
                id
            );


        const userRef =
            doc(
                db,
                "users",
                uid
            );


        const transactionRef =
            doc(
                collection(
                    db,
                    "transactions"
                )
            );


        const notificationRef =
            doc(
                collection(
                    db,
                    "notifications"
                )
            );


        // =================================
        // ATOMIC TRANSACTION
        // =================================

        await runTransaction(
            db,
            async transaction => {

                // -----------------------------
                // READ REQUEST
                // -----------------------------

                const requestSnap =
                    await transaction.get(
                        requestRef
                    );


                if (
                    !requestSnap.exists()
                ) {

                    throw new Error(
                        "REQUEST_NOT_FOUND"
                    );

                }


                const requestData =
                    requestSnap.data();


                const currentStatus =
                    String(
                        requestData.status ||
                        "pending"
                    )
                        .toLowerCase()
                        .trim();


                if (
                    currentStatus !==
                    "pending"
                ) {

                    throw new Error(
                        "REQUEST_ALREADY_PROCESSED"
                    );

                }


                // -----------------------------
                // READ USER
                // -----------------------------

                const userSnap =
                    await transaction.get(
                        userRef
                    );


                if (
                    !userSnap.exists()
                ) {

                    throw new Error(
                        "USER_NOT_FOUND"
                    );

                }


                const userData =
                    userSnap.data();


                // =================================
                // ACCOUNT VERIFICATION CHECK
                // =================================
                //
                // Welcome Bonus শুধুমাত্র verified
                // account-এর জন্য অনুমোদিত হবে।
                //
                // verified === true অথবা
                // verificationPaid === true হলে
                // verified হিসেবে গণ্য হবে।
                // =================================

                const isVerified =
                    userData.verified === true ||
                    userData.verificationPaid === true;


                if (!isVerified) {

                    throw new Error(
                        "USER_NOT_VERIFIED"
                    );

                }


// -----------------------------
// MAIN WALLET BALANCE
// -----------------------------

const currentBalance =
    Number(
        userData.balance || 0
    );


if (
    !Number.isFinite(
        currentBalance
    )
) {

    throw new Error(
        "INVALID_USER_BALANCE"
    );

}


const newBalance =
    currentBalance +
    amount;


// -----------------------------
// PROFIT BALANCE
// Welcome Bonus → totalEarnings
// -----------------------------

const currentProfit =
    Number(
        userData.totalEarnings || 0
    );


if (
    !Number.isFinite(
        currentProfit
    )
) {

    throw new Error(
        "INVALID_PROFIT_BALANCE"
    );

}


const newProfit =
    currentProfit +
    amount;


// -----------------------------
// UPDATE USER BALANCES
// -----------------------------

transaction.update(
    userRef,
    {

        // আগের Wallet Balance
        balance:
            newBalance,

        // নতুন: Profit Balance
        totalEarnings:
            newProfit

    }
);

// -----------------------------
                // UPDATE BONUS REQUEST
                // -----------------------------

                transaction.update(
                    requestRef,
                    {

                        status:
                            "approved",

                        approvedAmount:
                            amount,

                        approvedAt:
                            serverTimestamp()

                    }
                );


                // -----------------------------
                // CREATE TRANSACTION
                // -----------------------------

                transaction.set(
                    transactionRef,
                    {

                        uid:
                            uid,

                        userId:
                            getUserId(
                                requestData
                            ) || uid,

                        amount:
                            amount,

                        type:
                            "credit",

                        reason:
                            "Welcome Bonus",

                        status:
                            "Completed",

                        source:
                            "welcome_bonus",

                        createdAt:
                            serverTimestamp()

                    }
                );


// CREATE NOTIFICATION

transaction.set(
notificationRef,
{

uid: uid,

userId: uid,

userUid: uid,

title:
"🎉 Welcome Bonus Approved",

message:
`আপনার Welcome Bonus ৳${amount} Wallet-এ যোগ হয়েছে।`,

type:
"welcome_bonus",

read:false,

createdAt:
serverTimestamp()

}
);


            }
        );


        // =================================
        // SUCCESS
        // =================================

        alert(
            `✅ Welcome Bonus ৳${amount} সফলভাবে Approved হয়েছে।`
        );


        await loadRequests();

    }


    catch (error) {

        console.error(
            "❌ Welcome Bonus Approve Error:",
            error
        );


        if (
            error.message ===
            "REQUEST_ALREADY_PROCESSED"
        ) {

            alert(
                "⚠️ এই request ইতিমধ্যে Approved বা Rejected হয়েছে।"
            );

        }

        else if (
            error.message ===
            "REQUEST_NOT_FOUND"
        ) {

            alert(
                "❌ Welcome Bonus request পাওয়া যায়নি।"
            );

        }

        else if (
            error.message ===
            "USER_NOT_FOUND"
        ) {

            alert(
                "❌ User account পাওয়া যায়নি।"
            );

        }

        else if (
            error.message ===
            "USER_NOT_VERIFIED"
        ) {

            alert(
                "⚠️ এই account এখনো verified নয়। Account Verification সম্পন্ন করার পর Welcome Bonus approve করা যাবে।"
            );

        }

        else if (
            error.message ===
            "INVALID_USER_BALANCE"
        ) {

            alert(
                "❌ User wallet balance invalid."
            );

        }

        else {

            alert(
                "❌ Bonus approve করতে সমস্যা হয়েছে। Console দেখুন।"
            );

        }

    }

}


// =======================================
// REJECT WELCOME BONUS
// =======================================

async function rejectRequest(id) {

    const item =
        requests.find(
            request =>
                request.id === id
        );


    if (!item) {

        alert(
            "❌ Request পাওয়া যায়নি।"
        );

        return;

    }


    const confirmed =
        await NetEarnDialog.confirm(
            "❌ এই Welcome Bonus request Reject করবেন?"
        );


    if (!confirmed) return;


    try {

        // =================================
        // REFERENCES
        // =================================

        const requestRef =
            doc(
                db,
                "welcomeBonusRequests",
                id
            );


        const notificationRef =
            doc(
                collection(
                    db,
                    "notifications"
                )
            );


        // =================================
        // ATOMIC TRANSACTION
        // =================================

        await runTransaction(
            db,
            async transaction => {

                // -----------------------------
                // READ REQUEST
                // -----------------------------

                const requestSnap =
                    await transaction.get(
                        requestRef
                    );


                if (
                    !requestSnap.exists()
                ) {

                    throw new Error(
                        "REQUEST_NOT_FOUND"
                    );

                }


                const requestData =
                    requestSnap.data();


                const currentStatus =
                    String(
                        requestData.status ||
                        "pending"
                    )
                        .toLowerCase()
                        .trim();


                if (
                    currentStatus !==
                    "pending"
                ) {

                    throw new Error(
                        "REQUEST_ALREADY_PROCESSED"
                    );

                }


                // -----------------------------
                // UPDATE REQUEST
                // -----------------------------

                transaction.update(
                    requestRef,
                    {

                        status:
                            "rejected",

                        rejectedAt:
                            serverTimestamp()

                    }
                );


                // -----------------------------
                // CREATE NOTIFICATION
                // -----------------------------

                const uid =
                    getUid(
                        requestData
                    );


                if (uid) {

                    transaction.set(
                        notificationRef,
                        {

                            uid:
                                uid,

                            userId:
                                getUserId(
                                    requestData
                                ) || uid,

                            title:
                                "⚠️ Welcome Bonus Rejected",

                            message:
                                "আপনার Welcome Bonus request অনুমোদিত হয়নি।",

                            type:
                                "welcome_bonus",

                            read:
                                false,

                            createdAt:
                                serverTimestamp()

                        }
                    );

                }

            }
        );


        // =================================
        // SUCCESS
        // =================================

        alert(
            "❌ Welcome Bonus request rejected হয়েছে।"
        );


        await loadRequests();

    }


    catch (error) {

        console.error(
            "❌ Welcome Bonus Reject Error:",
            error
        );


        if (
            error.message ===
            "REQUEST_ALREADY_PROCESSED"
        ) {

            alert(
                "⚠️ এই request ইতিমধ্যে process করা হয়েছে।"
            );

        }

        else if (
            error.message ===
            "REQUEST_NOT_FOUND"
        ) {

            alert(
                "❌ Welcome Bonus request পাওয়া যায়নি।"
            );

        }

        else {

            alert(
                "❌ Request reject করতে সমস্যা হয়েছে। Console দেখুন।"
            );

        }

    }

}


// =======================================
// ACTION BUTTONS
// =======================================

document
    .getElementById(
        "requestList"
    )
    ?.addEventListener(
        "click",
        event => {

            const button =
                event.target.closest(
                    "[data-action]"
                );


            if (!button) return;


            const action =
                button.dataset.action;


            const id =
                button.dataset.id;


            if (!id) return;


            if (
                action === "view"
            ) {

                viewRequest(id);

            }

            else if (
                action === "approve"
            ) {

                approveRequest(id);

            }

            else if (
                action === "reject"
            ) {

                rejectRequest(id);

            }

        }
    );


// =======================================
// SETTINGS
// =======================================

async function loadWelcomeBonusSettings() {

    try {
        const snap = await getDoc(
            doc(db, "settings", "main")
        );

        const amountInput = document.getElementById("bonusAmount");

        if (amountInput && snap.exists()) {
            const amount = Number(snap.data()?.welcomeBonus);
            if (Number.isFinite(amount) && amount >= 0) {
                amountInput.value = amount;
            }
        }

    } catch (error) {
        console.warn(
            "⚠️ Welcome Bonus Settings Load Error:",
            error
        );
    }
}

loadWelcomeBonusSettings();

document
    .getElementById(
        "saveSettingsBtn"
    )
    ?.addEventListener(
        "click",
        async () => {

            const input =
                document.getElementById(
                    "bonusAmount"
                );


            if (!input) {

                alert(
                    "⚠️ Bonus amount field পাওয়া যায়নি।"
                );

                return;

            }


            const amount =
                Number(
                    input.value
                );


            if (
                !Number.isFinite(amount) ||
                amount < 0
            ) {

                alert(
                    "❌ Invalid bonus amount."
                );

                return;

            }


            try {

                await setDoc(
                    doc(db, "settings", "main"),
                    {
                        welcomeBonus: amount
                    },
                    { merge: true }
                );

                alert(
                    `✅ Welcome Bonus ৳${amount} successfully saved.`
                );

            } catch (error) {

                console.error(
                    "❌ Welcome Bonus Settings Save Error:",
                    error
                );

                alert(
                    "❌ Settings save হয়নি। Firebase permission/connection check করুন।"
                );

            }

        }
    );


// =======================================
// INITIAL LOAD
// =======================================

loadRequests();


console.log(
    "✅ NetEarn Pro Admin Welcome Bonus Loaded"
);