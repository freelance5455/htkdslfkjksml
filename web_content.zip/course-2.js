/* JOSTECH — MANUEL 02 : PROGRAMMATION INFORMATIQUE */
registerDisciplineLevels(2, {
  1: {
    label: "Niveau 1 — Fondamental",
    subtitle: "Algorithmique rigoureuse, typage des données, structures de contrôle et modularité.",
    chapters: [{
      id: "prog-1-1",
      title: "Chapitre 1 : Algorithmique et Programmation Structurée",
      lessons: [
        {
          id: "prog-1-1-1",
          title: "Leçon 1 : Algorithmes, Variables et Structures de Contrôle",
          duration: "25 min",
          objectives: [
            "Définir les propriétés mathématiques d'un algorithme (finitude, précision, effectivité).",
            "Comprendre comment une variable réserve une zone typée en mémoire RAM.",
            "Maîtriser les trois structures du théorème de Böhm-Jacopini : séquence, sélection et itération."
          ],
          prerequisites: ["Notions de base d'Informatique générale (RAM et binaire)."],
          sections: [
            {
              type: "definition",
              term: "Algorithme (du nom du savant Al-Khwârizmî)",
              text: "Un algorithme est une suite finie, ordonnée et non ambiguë d'opérations élémentaires permettant de transformer des données d'entrée en un résultat attendu.\n\nPour être valide scientifiquement, un algorithme doit respecter trois critères :\n• Finitude : il doit obligatoirement s'arrêter après un nombre fini d'étapes (pas de boucle infinie).\n• Déterminisme : avec les mêmes données en entrée, il produit toujours exactement le même résultat.\n• Effectivité : chaque instruction doit être suffisamment simple pour être exécutée par une machine."
            },
            {
              type: "theory",
              title: "1. Variables, types et piège de l'affectation",
              text: "Dans un programme, une variable est une étiquette humaine collée sur une adresse mémoire RAM pour y stocker une information modifiable. Chaque donnée possède un type qui indique à l'ordinateur combien d'octets réserver et comment interpréter les 0 et les 1.",
              bullets: [
                "Entier (int) : nombres sans virgule (ex: 18, -5).",
                "Flottant (float) : nombres réels à virgule (ex: 15.75).",
                "Chaîne de caractères (str) : texte entre guillemets (ex: 'JOSTECH').",
                "Booléen (bool) : uniquement Vrai (True) ou Faux (False)."
              ]
            },
            {
              type: "theory",
              title: "2. Affectation (=) versus Comparaison (==)",
              text: "C'est l'erreur numéro 1 des débutants : en programmation (Python, C, Java, JS), le signe égal simple (=) ne signifie PAS l'égalité mathématique ! C'est un ordre d'affectation : « prends la valeur de droite et range-la dans la case de gauche ». Ainsi, écrire x = x + 1 signifie : lis l'ancien x, ajoute 1, et écrase l'ancien x par le nouveau résultat.\n\nPour tester si deux valeurs sont égales, on utilise le double égal (==)."
            },
            {
              type: "code",
              lang: "Python — Programme complet commenté",
              code: [
                "# Gestion des notes universitaires (sur 20)",
                "etudiant = 'Amina'",
                "notes = [14.5, 16.0, 11.5, 18.0]",
                "somme = 0.0",
                "",
                "# 1) Itération : parcourir chaque note",
                "for note in notes:",
                "    somme = somme + note",
                "",
                "moyenne = somme / len(notes)",
                "print(f'Étudiante : {etudiant} | Moyenne : {moyenne:.2f}/20')",
                "",
                "# 2) Sélection : orientation conditionnelle",
                "if moyenne >= 16:",
                "    print('Mention : Très Bien')",
                "elif moyenne >= 10:",
                "    print('Statut : Admis en année supérieure')",
                "else:",
                "    print('Statut : Session de rattrapage')"
              ].join("\n")
            },
            {
              type: "example",
              title: "Quand utiliser FOR versus WHILE ?",
              text: "Utilisez la boucle FOR (Pour) lorsque vous connaissez d'avance le nombre de répétitions ou parcourez une liste (ex: les 10 disciplines). Utilisez la boucle WHILE (Tant que) lorsque l'arrêt dépend d'un événement imprévisible (ex: tant que l'utilisateur n'a pas saisi le bon mot de passe)."
            }
          ],
          exercise: {
            question: "1) Tracez à la main les valeurs successives de s et i dans ce code :\ns = 0\nfor i in range(1, 5):\n    s = s + i\n\n2) Écrivez en Python une boucle affichant tous les multiples de 3 compris entre 3 et 30.",
            solution: "1) range(1, 5) génère 1, 2, 3, 4 (5 est exclu) :\n   - i=1 → s = 0+1 = 1\n   - i=2 → s = 1+2 = 3\n   - i=3 → s = 3+3 = 6\n   - i=4 → s = 6+4 = 10. Valeur finale de s = 10.\n\n2) Code Python :\nfor n in range(3, 31, 3):\n    print(n)"
          },
          summary: "Selon le théorème de Böhm-Jacopini, tout algorithme peut s'écrire avec trois briques : la séquence, la condition (if/else) et la boucle (for/while). Bien distinguer l'affectation (=) du test d'égalité (==) évite de nombreux bugs.",
          references: [
            "Cormen, T. et al. — Algorithmique (3e éd.), Dunod.",
            "Swinnen, G. — Apprendre à programmer avec Python 3, Eyrolles."
          ]
        },
        {
          id: "prog-1-1-2",
          title: "Leçon 2 : Fonctions, Paramètres et Modularité",
          duration: "20 min",
          objectives: [
            "Découper un grand problème en sous-programmes réutilisables (Principe DRY).",
            "Distinguer clairement afficher un résultat (print) et le renvoyer (return).",
            "Comprendre la portée locale d'une variable dans une fonction."
          ],
          prerequisites: ["Leçon 1 — Variables et boucles."],
          sections: [
            {
              type: "theory",
              title: "1. Pourquoi écrire des fonctions ?",
              text: "Imaginez devoir calculer la moyenne de 500 étudiants en recopiant 500 fois les mêmes lignes de boucle. Ce serait illisible et impossible à corriger. En génie logiciel, on applique la règle DRY (Don't Repeat Yourself) : on isole une logique dans une fonction nommée, puis on l'appelle autant de fois que nécessaire avec des données différentes."
            },
            {
              type: "definition",
              term: "return vs print (Différence cruciale)",
              text: "print() affiche simplement du texte sur l'écran pour l'humain, mais le programme ne peut pas réutiliser ce texte dans un calcul suivant.\nreturn termine immédiatement la fonction et livre une vraie valeur calculée au reste du programme pour qu'elle soit stockée ou comparée."
            },
            {
              type: "code",
              lang: "Python — Fonction universitaire réutilisable",
              code: [
                "def calculer_moyenne(liste_notes):",
                "    if len(liste_notes) == 0:",
                "        return 0.0",
                "    return sum(liste_notes) / len(liste_notes)",
                "",
                "moy_algo = calculer_moyenne([15, 17, 13])",
                "moy_web  = calculer_moyenne([18, 16, 19])",
                "moy_globale = (moy_algo + moy_web) / 2",
                "print('Moyenne semestrielle :', moy_globale)"
              ].join("\n")
            }
          ],
          exercise: {
            question: "Écrivez une fonction Python est_admis(note) qui renvoie True si la note est supérieure ou égale à 10, et False sinon.",
            solution: "def est_admis(note):\n    return note >= 10\n\n# Exemple : est_admis(12.5) renvoie True."
          },
          summary: "Les fonctions rendent le code modulaire, lisible et testable. Une variable créée à l'intérieur d'une fonction est locale et disparaît dès que return est exécuté.",
          references: ["Downey, A. — Think Python: How to Think Like a Computer Scientist."]
        }
      ]
    }]
  },
  2: {
    label: "Niveau 2 — Intermédiaire",
    subtitle: "Gestion bas niveau de la mémoire, pointeurs en langage C et structures de données.",
    chapters: [{
      id: "prog-2-1",
      title: "Chapitre 2 : Mémoire, Pointeurs et Tableaux en Langage C",
      lessons: [{
        id: "prog-2-1-1",
        title: "Leçon 1 : Pile, Tas, Adresses Mémoire et Pointeurs en C",
        duration: "30 min",
        objectives: [
          "Comprendre pourquoi le langage C reste le socle des systèmes d'exploitation.",
          "Distinguer la Pile (Stack) du Tas (Heap) en mémoire RAM.",
          "Maîtriser les opérateurs & (adresse) et * (déréférencement) sans erreur."
        ],
        prerequisites: ["Niveau 1 — Programmation structurée et notions de RAM."],
        sections: [
          {
            type: "theory",
            title: "1. Pourquoi étudier le langage C à l'université ?",
            text: "Bien que Python ou JavaScript soient très pratiques, le noyau Linux, Windows, Android (en partie basse) et les interpréteurs Python eux-mêmes sont écrits en langage C. Le C donne un contrôle direct sur la mémoire RAM et le processeur, sans filets de sécurité."
          },
          {
            type: "definition",
            term: "Adresse mémoire et Pointeur",
            text: "Chaque octet de votre RAM possède un numéro unique appelé adresse (souvent écrite en hexadécimal, ex: 0x7ffe4a10).\nUn pointeur est tout simplement une variable qui stocke cette adresse mémoire au lieu de stocker un entier ordinaire.\n• L'opérateur &x signifie : « donne-moi l'adresse de la variable x ».\n• L'opérateur *p signifie : « va lire ou modifier la valeur située à l'adresse contenue dans p »."
          },
          {
            type: "table",
            title: "Organisation de la mémoire d'un programme",
            headers: ["Zone RAM", "Rôle", "Durée de vie"],
            rows: [
              ["Pile (Stack)", "Stocke les variables locales des fonctions appelées.", "Automatique (libérée à la fin de la fonction)."],
              ["Tas (Heap)", "Mémoire dynamique demandée manuellement via malloc().", "Manuelle (jusqu'à l'appel à free() ou fin du programme)."]
            ]
          },
          {
            type: "code",
            lang: "Langage C — Passage par adresse complet",
            code: [
              "#include <stdio.h>",
              "",
              "void echanger(int *a, int *b) {",
              "    int temp = *a; // Lit la valeur pointée par a",
              "    *a = *b;       // Écrit la valeur de b dans la case de a",
              "    *b = temp;",
              "}",
              "",
              "int main() {",
              "    int x = 10, y = 20;",
              "    printf(\"Avant : x=%d, y=%d\\n\", x, y);",
              "    echanger(&x, &y); // On passe les adresses !",
              "    printf(\"Après : x=%d, y=%d\\n\", x, y);",
              "    return 0;",
              "}"
            ].join("\n")
          }
        ],
        exercise: {
          question: "1) Que se passerait-il si la fonction echanger(int a, int b) ne prenait pas de pointeurs ?\n2) Quel risque court un programmeur qui utilise malloc() dans une boucle sans jamais appeler free() ?",
          solution: "1) En C, les arguments sont passés par copie (valeur). Sans pointeurs, echanger modifierait uniquement ses copies locales sur la Pile, laissant x=10 et y=20 intacts dans main().\n2) Il provoque une fuite mémoire (Memory Leak) : le Tas se remplit jusqu'à saturer la RAM et faire planter le programme."
        },
        summary: "Les pointeurs (& et *) permettent de manipuler directement les adresses RAM, d'éviter des copies lourdes de données et de construire des structures dynamiques (listes chaînées, arbres, graphes).",
        references: [
          "Kernighan, B. & Ritchie, D. — Le Langage C (norme ANSI), Dunod.",
          "Delannoy, C. — Programmer en langage C, Eyrolles."
        ]
      }]
    }]
  },
  3: {
    label: "Niveau 3 — Avancé & Universitaire",
    subtitle: "Programmation Orientée Objet (POO), architecture logicielle et complexité asymptotique.",
    chapters: [{
      id: "prog-3-1",
      title: "Chapitre 3 : Paradigme Objet et Complexité Algorithmique",
      lessons: [{
        id: "prog-3-1-1",
        title: "Leçon 1 : Piliers de la POO et Analyse Asymptotique Big-O",
        duration: "30 min",
        objectives: [
          "Modéliser un domaine métier par classes, encapsulation, héritage et polymorphisme.",
          "Évaluer mathématiquement la croissance du temps d'exécution en notation Grand O.",
          "Comparer concrètement O(n) et O(log n) sur de grands volumes de données."
        ],
        prerequisites: ["Niveaux 1 et 2 de Programmation."],
        sections: [
          {
            type: "theory",
            title: "1. Pourquoi la Programmation Orientée Objet (POO) ?",
            text: "Lorsque un logiciel dépasse plusieurs dizaines de milliers de lignes (comme une université numérique complète), séparer les données d'un côté et des centaines de fonctions indépendantes de l'autre devient ingérable. La POO regroupe au sein d'une même entité — l'Objet — ses données (attributs) et les actions qui la concernent (méthodes).",
            bullets: [
              "Classe vs Objet : la Classe est le plan architectural (moule) ; l'Objet est la maison construite à partir du plan (instance).",
              "Encapsulation : cacher les détails sensibles internes pour protéger l'intégrité des données.",
              "Héritage : créer une classe spécialisée (Etudiant) réutilisant les bases d'une classe mère (Utilisateur).",
              "Polymorphisme : permettre à une même méthode d'agir différemment selon le type d'objet."
            ]
          },
          {
            type: "code",
            lang: "Python — Modélisation POO avec Héritage",
            code: [
              "class Utilisateur:",
              "    def __init__(self, nom, email):",
              "        self.nom = nom",
              "        self.email = email",
              "",
              "class Etudiant(Utilisateur):",
              "    def __init__(self, nom, email, moyenne):",
              "        super().__init__(nom, email) # Appelle le constructeur parent",
              "        self._moyenne = moyenne      # Attribut protégé",
              "",
              "    def est_admis(self):",
              "        return self._moyenne >= 10.0",
              "",
              "etu = Etudiant('Mivumbi', 'etu@jostech.edu', 16.5)",
              "print(etu.nom, 'Admis ?', etu.est_admis())"
            ].join("\n")
          },
          {
            type: "theory",
            title: "2. Mesurer l'efficacité : la notation Big-O",
            text: "Mesurer un algorithme en secondes n'est pas scientifique : un même code sera rapide sur un serveur puissant et lent sur un vieux téléphone. On mesure donc comment évolue le nombre d'opérations élémentaires lorsque la taille n des données devient très grande."
          },
          {
            type: "table",
            title: "Hiérarchie des complexités temporelles",
            headers: ["Complexité", "Qualification", "Opérations pour n = 1 000 000"],
            rows: [
              ["O(1)", "Constante (Idéale)", "1 opération (accès index tableau)"],
              ["O(log n)", "Logarithmique (Excellente)", "~20 opérations (recherche dichotomique)"],
              ["O(n)", "Linéaire (Correcte)", "1 000 000 opérations (boucle simple)"],
              ["O(n log n)", "Quasi-linéaire", "~20 000 000 opérations (tri rapide / fusion)"],
              ["O(n²)", "Quadratique (À éviter sur gros volumes)", "1 000 milliards d'opérations !"]
            ]
          }
        ],
        exercise: {
          question: "Votre base JOSTECH contient 1 024 000 étudiants triés par numéro matricule.\n1) Dans le pire cas, combien de comparaisons exige une recherche linéaire O(n) ?\n2) Combien de comparaisons au maximum exige une recherche dichotomique O(log₂ n) (qui divise la zone de recherche par 2 à chaque étape) ?",
          solution: "1) Recherche linéaire : jusqu'à 1 024 000 comparaisons (si l'étudiant est tout à la fin ou absent).\n2) Recherche dichotomique : 2²⁰ = 1 048 576, donc log₂(1 024 000) ≈ 20 comparaisons maximum !\nPasser de 1 million d'étapes à 20 étapes montre pourquoi l'algorithmique prime souvent sur la puissance brute du matériel."
        },
        summary: "La POO structure l'architecture des grands systèmes logiciels par encapsulation, héritage et polymorphisme, tandis que la notation Big-O permet de prouver mathématiquement qu'un algorithme restera rapide à grande échelle.",
        references: [
          "Meyer, B. — Conception et programmation orientées objet, Eyrolles.",
          "Cormen, T. et al. — Introduction to Algorithms (MIT Press)."
        ]
      }]
    }]
  }
});