LOVE GALLERY - Android app (Android 10+)

APK kaise banayein:
1. Android Studio (free) install karo: developer.android.com/studio
2. File > Open > is LoveGalleryApp folder ko chuno. Gradle sync hone do (internet chahiye).
3. Phone me USB debugging on karke connect karo, phir upar green Run ▶ dabao.
   Ya: Build > Build APK(s) -> APK phone me install karo.

Kaam kaise karta hai:
- Pehli baar password banao, phir Allow dabao -> phone ki saari photos/videos dikhengi.
- Photos/videos copy nahi hoti, seedhe phone se padhi jaati hain. Nayi photo aaye to ⟳ dabao.
- Screenshot band hai aur app se bahar jaate hi lock ho jata hai.
- Android 14+: permission dialog me "Allow all" chuno, "Select photos" nahi.
- Original photos normal gallery me bhi dikhengi (is app se hide nahi hoti).
