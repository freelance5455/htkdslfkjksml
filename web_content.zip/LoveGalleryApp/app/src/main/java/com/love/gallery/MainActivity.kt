package com.love.gallery

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentUris
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.provider.MediaStore.Files.FileColumns as F
import android.util.Size
import android.view.WindowManager
import android.webkit.*
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONArray
import org.json.JSONObject
import java.io.*

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView

    private val wanted: Array<String>
        get() = when {
            Build.VERSION.SDK_INT >= 34 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
            Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
            else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

    private val launcher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        web.evaluateJavascript("window.onPerm&&onPerm()", null)
    }

    private fun granted() = wanted.any { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    inner class Bridge {
        @JavascriptInterface fun hasPerm() = granted()
        @JavascriptInterface fun ask() = runOnUiThread { launcher.launch(wanted) }
        @JavascriptInterface fun list(): String {
            val arr = JSONArray()
            contentResolver.query(
                MediaStore.Files.getContentUri("external"),
                arrayOf(F._ID, F.DISPLAY_NAME, F.MEDIA_TYPE, F.DATE_ADDED),
                "${F.MEDIA_TYPE}=? OR ${F.MEDIA_TYPE}=?",
                arrayOf(F.MEDIA_TYPE_IMAGE.toString(), F.MEDIA_TYPE_VIDEO.toString()),
                "${F.DATE_ADDED} DESC"
            )?.use { c ->
                while (c.moveToNext()) arr.put(JSONObject()
                    .put("i", c.getLong(0)).put("n", c.getString(1) ?: "")
                    .put("v", if (c.getInt(2) == F.MEDIA_TYPE_VIDEO) 1 else 0).put("d", c.getLong(3)))
            }
            return arr.toString()
        }
    }

    private class Limited(val s: FileInputStream, var left: Long, val pfd: ParcelFileDescriptor) : InputStream() {
        override fun read(): Int { if (left <= 0) return -1; left--; return s.read() }
        override fun read(b: ByteArray, o: Int, l: Int): Int {
            if (left <= 0) return -1
            val n = s.read(b, o, minOf(l.toLong(), left).toInt()); if (n > 0) left -= n; return n
        }
        override fun close() { pfd.close() }
    }

    private fun media(path: String, range: String?): WebResourceResponse {
        val p = path.split("/") // "", m|t, i|v, id
        val video = p[2] == "v"
        val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val uri = ContentUris.withAppendedId(base, p[3].toLong())
        if (p[1] == "t") {
            val bmp = contentResolver.loadThumbnail(uri, Size(360, 360), null)
            val out = ByteArrayOutputStream(); bmp.compress(Bitmap.CompressFormat.JPEG, 80, out)
            return WebResourceResponse("image/jpeg", null, ByteArrayInputStream(out.toByteArray()))
        }
        val mime = contentResolver.getType(uri) ?: if (video) "video/mp4" else "image/jpeg"
        val pfd = contentResolver.openFileDescriptor(uri, "r")!!
        val len = pfd.statSize
        var start = 0L; var end = len - 1; var code = 200
        if (range != null && range.startsWith("bytes=")) {
            val r = range.substring(6).split("-")
            start = r[0].toLongOrNull() ?: 0L
            end = r.getOrNull(1)?.toLongOrNull() ?: (len - 1)
            code = 206
        }
        val fis = FileInputStream(pfd.fileDescriptor); fis.channel.position(start)
        val h = mutableMapOf("Accept-Ranges" to "bytes", "Content-Length" to (end - start + 1).toString())
        if (code == 206) h["Content-Range"] = "bytes $start-$end/$len"
        return WebResourceResponse(mime, null, code, if (code == 206) "Partial Content" else "OK", h, Limited(fis, end - start + 1, pfd))
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Screenshot / recent-apps preview block
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            addJavascriptInterface(Bridge(), "Native")
            setBackgroundColor(0xFF2B0F20.toInt())
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                    if (r.url.host != "app.local") return null
                    val path = r.url.path ?: "/"
                    return try {
                        if (path.startsWith("/m/") || path.startsWith("/t/")) media(path, r.requestHeaders["Range"])
                        else WebResourceResponse("text/html", "utf-8", assets.open("index.html"))
                    } catch (e: Exception) {
                        WebResourceResponse("text/plain", "utf-8", 404, "Not found", null, ByteArrayInputStream(ByteArray(0)))
                    }
                }
            }
        }
        setContentView(web)
        web.loadUrl("https://app.local/index.html")
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.onBack?onBack():false") { if (it != "true") finish() }
            }
        })
    }

    override fun onStop() { super.onStop(); web.evaluateJavascript("window.lock&&lock()", null) }
}
