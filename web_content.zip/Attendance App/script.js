const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

const KEY = "dutyflow_premium_data_v2";

const todayISO = () => {
  const d = new Date();

  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

const monthISO = () => todayISO().slice(0, 7);

let data = load();
let currentPage = "dashboard";
let currentDay = todayISO();
let monthFilter = "All";


function load() {

  try {

    return JSON.parse(localStorage.getItem(KEY)) || {
      attendance: {},
      pm: {
        weekly: {},
        monthly: {}
      },
      settings: {
        shift: "first",
        theme: "dark"
      }
    };

  } catch {

    return {
      attendance: {},
      pm: {
        weekly: {},
        monthly: {}
      },
      settings: {
        shift: "first",
        theme: "dark"
      }
    };

  }

}


function save() {
  localStorage.setItem(KEY, JSON.stringify(data));
}


function esc(s) {

  return String(s).replace(
    /[&<>"']/g,
    m => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#039;"
    }[m])
  );

}


function fmtDate(v) {

  if (!v) return "";

  return new Date(v + "T00:00:00")
    .toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric"
    });

}


function dayName(v) {

  return new Date(v + "T00:00:00")
    .toLocaleDateString("en-IN", {
      weekday: "long"
    });

}


function daysInMonth(m) {

  const [y, mo] = m.split("-").map(Number);

  const n = new Date(y, mo, 0).getDate();

  return Array.from(
    { length: n },
    (_, i) =>
      `${m}-${String(i + 1).padStart(2, "0")}`
  );

}


function shiftText(s) {

  return s === "second"
    ? "Second · 3 PM–11 PM"
    : "First · 7 AM–3 PM";

}


function isoWeek(v) {

  const d = new Date(v + "T00:00:00");

  d.setHours(0, 0, 0, 0);

  d.setDate(
    d.getDate() + 3 - (d.getDay() + 6) % 7
  );

  const week1 = new Date(
    d.getFullYear(),
    0,
    4
  );

  const week =
    1 +
    Math.round(
      (
        (d - week1) / 86400000 -
        3 +
        (week1.getDay() + 6) % 7
      ) / 7
    );

  return `${d.getFullYear()}-W${String(week).padStart(2, "0")}`;

}


function showToast(msg) {

  const t = $("#toast");

  t.textContent = msg;

  t.classList.add("show");

  clearTimeout(showToast.t);

  showToast.t = setTimeout(
    () => t.classList.remove("show"),
    2200
  );

}


function go(page) {

  currentPage = page;

  $$(".page").forEach(
    p =>
      p.classList.toggle(
        "active",
        p.id === "page-" + page
      )
  );

  $$(".nav-item").forEach(
    b =>
      b.classList.toggle(
        "active",
        b.dataset.page === page
      )
  );

  const titles = {
    dashboard: "Dashboard",
    day: "Mark Today",
    monthly: "Monthly Overview",
    pm: "PM Tracking",
    reports: "Reports"
  };

  $("#pageTitle").textContent =
    titles[page] || "Dashboard";

  if (page === "dashboard") dashboardUI();
  if (page === "day") dayUI();
  if (page === "monthly") monthlyUI();
  if (page === "pm") pmUI();
  if (page === "reports") reportUI();

  $("#sidebar").classList.remove("open");
  $("#backdrop").classList.remove("show");

  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });

}


$$(".nav-item").forEach(
  b =>
    b.addEventListener(
      "click",
      () => go(b.dataset.page)
    )
);


$$("[data-page-jump]").forEach(
  b =>
    b.addEventListener(
      "click",
      () => go(b.dataset.pageJump)
    )
);


$("#menuBtn").addEventListener(
  "click",
  () => {

    $("#sidebar").classList.toggle("open");

    $("#backdrop").classList.toggle("show");

  }
);


$("#backdrop").addEventListener(
  "click",
  () => {

    $("#sidebar").classList.remove("open");

    $("#backdrop").classList.remove("show");

  }
);


$("#quickToday").addEventListener(
  "click",
  () => {

    currentDay = todayISO();

    go("day");

  }
);


$("#heroToday").addEventListener(
  "click",
  () => {

    currentDay = todayISO();

    go("day");

  }
);


$("#themeBtn").addEventListener(
  "click",
  () => {

    data.settings.theme =
      document.body.classList.contains("light")
        ? "dark"
        : "light";

    save();

    applyTheme();

    showToast(
      `${data.settings.theme === "light" ? "Light" : "Dark"} theme enabled`
    );

  }
);


function applyTheme() {

  document.body.classList.toggle(
    "light",
    data.settings.theme === "light"
  );

  $("#themeBtn").innerHTML =
    data.settings.theme === "light"
      ? "☀ <span>Dark Theme</span>"
      : "☾ <span>Light Theme</span>";

}


function dashboardUI() {

  const now = new Date();

  const h = now.getHours();

  const g =
    h < 12
      ? "Good morning"
      : h < 17
        ? "Good afternoon"
        : "Good evening";

  $("#greeting").textContent =
    `${g} 👋`;

  $("#topDate").textContent =
    now.toLocaleDateString(
      "en-IN",
      {
        weekday: "long",
        day: "numeric",
        month: "long"
      }
    );

  const m =
    $("#dashMonth").value ||
    monthISO();

  $("#dashMonth").value = m;

  const entries =
    daysInMonth(m)
      .map(d => data.attendance[d])
      .filter(Boolean);

  $("#statPresent").textContent =
    entries.filter(
      x => x.status === "Present"
    ).length;

  $("#statAbsent").textContent =
    entries.filter(
      x => x.status === "Absent"
    ).length;

  $("#statLeave").textContent =
    entries.filter(
      x => x.status === "Leave"
    ).length;

  $("#statOT").textContent =
    entries.filter(
      x => x.ot
    ).length;

  const total = entries.length;

  const p =
    entries.filter(
      x => x.status === "Present"
    ).length;

  $("#insightText").textContent =
    total
      ? `${p} present day${p === 1 ? "" : "s"} recorded in ${new Date(m + "-01T00:00:00").toLocaleDateString("en-IN", { month: "long", year: "numeric" })}. Keep your PM records updated too.`
      : "Start by marking today's duty. Your monthly summary will build automatically.";

  $("#defaultShift").value =
    data.settings.shift || "first";

}


$("#dashMonth").addEventListener(
  "change",
  dashboardUI
);


$("#defaultShift").addEventListener(
  "change",
  e => {

    data.settings.shift =
      e.target.value;

    save();

    showToast(
      "Default shift updated"
    );

  }
);


function dayUI() {

  $("#dayDate").value =
    currentDay;

  $("#dayLabel").textContent =
    `${dayName(currentDay)} · ${fmtDate(currentDay)}`;

  const r =
    data.attendance[currentDay] || {
      status: "Present",
      shift: data.settings.shift || "first",
      ot: false
    };

  $$(".status-choice").forEach(
    b =>
      b.classList.toggle(
        "selected",
        b.dataset.status === r.status
      )
  );

  $$(".shift-choice").forEach(
    b =>
      b.classList.toggle(
        "selected",
        b.dataset.shift === r.shift
      )
  );

  $("#otToggle").checked =
    !!r.ot;

  $("#daySaved").textContent =
    data.attendance[currentDay]
      ? "Saved"
      : "Not saved";

  $("#snapshotTitle").textContent =
    data.attendance[currentDay]
      ? `${r.status} · ${shiftText(r.shift)}`
      : "Today's snapshot";

  $("#snapshotText").textContent =
    data.attendance[currentDay]
      ? (
          r.ot
            ? "OT enabled · 8 hours"
            : "No OT recorded"
        )
      : "Choose a status and shift, then save.";

}


$("#dayDate").addEventListener(
  "change",
  e => {

    currentDay =
      e.target.value ||
      todayISO();

    dayUI();

  }
);


$("#prevDay").addEventListener(
  "click",
  () => {

    const d =
      new Date(
        currentDay + "T00:00:00"
      );

    d.setDate(
      d.getDate() - 1
    );

    currentDay =
      d.toISOString().slice(0, 10);

    dayUI();

  }
);


$("#nextDay").addEventListener(
  "click",
  () => {

    const d =
      new Date(
        currentDay + "T00:00:00"
      );

    d.setDate(
      d.getDate() + 1
    );

    currentDay =
      d.toISOString().slice(0, 10);

    dayUI();

  }
);


$$(".status-choice").forEach(
  b =>
    b.addEventListener(
      "click",
      () => {

        $$(".status-choice").forEach(
          x =>
            x.classList.remove(
              "selected"
            )
        );

        b.classList.add(
          "selected"
        );

      }
    )
);


$$(".shift-choice").forEach(
  b =>
    b.addEventListener(
      "click",
      () => {

        $$(".shift-choice").forEach(
          x =>
            x.classList.remove(
              "selected"
            )
        );

        b.classList.add(
          "selected"
        );

      }
    )
);


$("#saveDay").addEventListener(
  "click",
  () => {

    const status =
      $(".status-choice.selected")
        ?.dataset.status ||
      "Present";

    const shift =
      $(".shift-choice.selected")
        ?.dataset.shift ||
      data.settings.shift ||
      "first";

    const ot =
      $("#otToggle").checked;

    data.attendance[currentDay] = {
      status,
      shift,
      ot
    };

    save();

    dayUI();

    showToast(
      `${fmtDate(currentDay)} saved successfully ✓`
    );

  }
);


function monthlyUI() {

  const m =
    $("#monthlyMonth").value ||
    monthISO();

  $("#monthlyMonth").value = m;

  const rows =
    daysInMonth(m)
      .map(
        date => ({
          date,
          ...(data.attendance[date] || {})
        })
      )
      .filter(
        r =>
          monthFilter === "All" ||
          (
            monthFilter === "OT"
              ? r.ot
              : r.status === monthFilter
          )
      );

  $("#monthBody").innerHTML =
    rows
      .map(
        r =>
          `<tr>
            <td>${fmtDate(r.date)}</td>
            <td>${dayName(r.date).slice(0, 3)}</td>
            <td>
              ${
                r.status
                  ? `<span class="status-badge status-${r.status}">
                      ${r.status}
                    </span>`
                  : "—"
              }
            </td>
            <td>
              ${r.status ? shiftText(r.shift) : "—"}
            </td>
            <td>
              ${r.ot ? "8 hrs" : "—"}
            </td>
            <td>
              <button
                class="edit-btn"
                data-edit="${r.date}"
              >
                Edit
              </button>
            </td>
          </tr>`
      )
      .join("");


  $("#monthMobile").innerHTML =
    rows
      .map(
        r =>
          `<div class="mobile-entry">

            <div class="line">
              <b>${fmtDate(r.date)}</b>

              <span>
                ${
                  r.status
                    ? `<span class="status-badge status-${r.status}">
                        ${r.status}
                      </span>`
                    : "Not marked"
                }
              </span>
            </div>

            <div class="line">

              <small>
                ${
                  r.status
                    ? shiftText(r.shift)
                    : "No duty entry"
                }

                ${
                  r.ot
                    ? " · OT 8 hrs"
                    : ""
                }
              </small>

              <button
                class="edit-btn"
                data-edit="${r.date}"
              >
                Edit
              </button>

            </div>

          </div>`
      )
      .join("");


  $$("[data-edit]").forEach(
    b =>
      b.addEventListener(
        "click",
        () => {

          currentDay =
            b.dataset.edit;

          go("day");

        }
      )
  );

}


$("#monthlyMonth").addEventListener(
  "change",
  monthlyUI
);


$$(".filter").forEach(
  b =>
    b.addEventListener(
      "click",
      () => {

        $$(".filter").forEach(
          x =>
            x.classList.remove(
              "active"
            )
        );

        b.classList.add(
          "active"
        );

        monthFilter =
          b.dataset.filter;

        monthlyUI();

      }
    )
);


function pmUI() {

  const wk =
    isoWeek(todayISO());

  const m =
    $("#monthlyMonth").value ||
    monthISO();

  const w =
    data.pm.weekly[wk] || {
      status: "None",
      date: ""
    };

  const mm =
    data.pm.monthly[m] || {
      status: "None",
      date: ""
    };

  $("#weekKeyLabel").textContent =
    wk;

  $("#monthPmLabel").textContent =
    m;

  $("#weeklyStatus").value =
    w.status;

  $("#weeklyDate").value =
    w.date;

  $("#monthlyPmStatus").value =
    mm.status;

  $("#monthlyPmDate").value =
    mm.date;

}


$("#saveWeekly").addEventListener(
  "click",
  () => {

    const k =
      isoWeek(todayISO());

    data.pm.weekly[k] = {
      status:
        $("#weeklyStatus").value,

      date:
        $("#weeklyDate").value
    };

    save();

    pmUI();

    showToast(
      "Weekly PM saved ✓"
    );

  }
);


$("#saveMonthlyPm").addEventListener(
  "click",
  () => {

    const m =
      $("#reportMonth").value ||
      monthISO();

    data.pm.monthly[m] = {
      status:
        $("#monthlyPmStatus").value,

      date:
        $("#monthlyPmDate").value
    };

    save();

    pmUI();

    reportUI();

    showToast(
      "Monthly PM saved ✓"
    );

  }
);


function reportUI() {

  const m =
    $("#reportMonth").value ||
    monthISO();

  $("#reportMonth").value =
    m;

  const rows =
    daysInMonth(m)
      .map(
        date => ({
          date,
          ...(data.attendance[date] || {})
        })
      )
      .filter(
        r => r.status
      );

  const p =
    rows.filter(
      r => r.status === "Present"
    ).length;

  const a =
    rows.filter(
      r => r.status === "Absent"
    ).length;

  const l =
    rows.filter(
      r => r.status === "Leave"
    ).length;

  const ot =
    rows.filter(
      r => r.ot
    ).length;

  const pm =
    data.pm.monthly[m] || {
      status: "None",
      date: ""
    };

  const wk =
    data.pm.weekly[
      isoWeek(todayISO())
    ] || {
      status: "None",
      date: ""
    };


  $("#reportPreview").innerHTML = `

    <h2 class="report-title">
      VX Monthly Report
    </h2>

    <div class="report-meta">
      ${
        new Date(
          m + "-01T00:00:00"
        ).toLocaleDateString(
          "en-IN",
          {
            month: "long",
            year: "numeric"
          }
        )
      }
    </div>

    <div class="report-stats">

      <div class="report-stat">
        <b>${p}</b>
        <small>Present</small>
      </div>

      <div class="report-stat">
        <b>${a}</b>
        <small>Absent</small>
      </div>

      <div class="report-stat">
        <b>${l}</b>
        <small>Leave</small>
      </div>

      <div class="report-stat">
        <b>${ot}</b>
        <small>OT Days</small>
      </div>

    </div>

    <div class="report-section">

      <h4>PM Status</h4>

      <p>
        Monthly PM:
        <b>${esc(pm.status)}</b>

        ${
          pm.date
            ? ` · ${fmtDate(pm.date)}`
            : ""
        }
      </p>

      <p>
        Current Weekly PM:
        <b>${esc(wk.status)}</b>

        ${
          wk.date
            ? ` · ${fmtDate(wk.date)}`
            : ""
        }
      </p>

    </div>


    <div class="report-section">

      <h4>Attendance</h4>

      <table class="report-table">

        <thead>

          <tr>
            <th>Date</th>
            <th>Status</th>
            <th>Shift</th>
            <th>OT</th>
          </tr>

        </thead>

        <tbody>

          ${
            rows.length
              ? rows
                  .map(
                    r =>
                      `<tr>
                        <td>${fmtDate(r.date)}</td>
                        <td>${r.status}</td>
                        <td>${shiftText(r.shift)}</td>
                        <td>${r.ot ? "8 hrs" : "—"}</td>
                      </tr>`
                  )
                  .join("")
              : `
                <tr>
                  <td colspan="4">
                    No attendance records for this month.
                  </td>
                </tr>
              `
          }

        </tbody>

      </table>

    </div>

  `;

}


$("#reportMonth").addEventListener(
  "change",
  reportUI
);


$("#downloadPdf").addEventListener(
  "click",
  () => {

    if (!window.jspdf) {

      showToast(
        "PDF library not loaded. Check internet once."
      );

      return;
    }


    const { jsPDF } =
      window.jspdf;

    const m =
      $("#reportMonth").value ||
      monthISO();

    const rows =
      daysInMonth(m)
        .map(
          date => ({
            date,
            ...(data.attendance[date] || {})
          })
        )
        .filter(
          r => r.status
        );


    const doc =
      new jsPDF();

    let y = 18;


    doc.setFontSize(20);

    doc.text(
      "VX Monthly Report",
      14,
      y
    );

    y += 9;


    doc.setFontSize(10);

    doc.text(
      new Date(
        m + "-01T00:00:00"
      ).toLocaleDateString(
        "en-IN",
        {
          month: "long",
          year: "numeric"
        }
      ),
      14,
      y
    );

    y += 12;


    const p =
      rows.filter(
        r => r.status === "Present"
      ).length;

    const a =
      rows.filter(
        r => r.status === "Absent"
      ).length;

    const l =
      rows.filter(
        r => r.status === "Leave"
      ).length;

    const ot =
      rows.filter(
        r => r.ot
      ).length;


    doc.setFontSize(11);

    doc.text(
      `Present: ${p}    Absent: ${a}    Leave: ${l}    OT Days: ${ot} (8 hours each)`,
      14,
      y
    );

    y += 10;


    const pm =
      data.pm.monthly[m] || {
        status: "None",
        date: ""
      };

    const wk =
      data.pm.weekly[
        isoWeek(todayISO())
      ] || {
        status: "None",
        date: ""
      };


    doc.text(
      `Monthly PM: ${pm.status}${pm.date ? " - " + fmtDate(pm.date) : ""}`,
      14,
      y
    );

    y += 7;


    doc.text(
      `Current Weekly PM: ${wk.status}${wk.date ? " - " + fmtDate(wk.date) : ""}`,
      14,
      y
    );

    y += 11;


    doc.setFontSize(9);

    doc.text(
      "Date",
      14,
      y
    );

    doc.text(
      "Status",
      48,
      y
    );

    doc.text(
      "Shift",
      85,
      y
    );

    doc.text(
      "OT",
      160,
      y
    );

    y += 6;


    rows.forEach(
      r => {

        if (y > 278) {

          doc.addPage();

          y = 18;

        }

        doc.text(
          fmtDate(r.date),
          14,
          y
        );

        doc.text(
          r.status,
          48,
          y
        );

        doc.text(
          shiftText(r.shift),
          85,
          y
        );

        doc.text(
          r.ot ? "8 hrs" : "—",
          160,
          y
        );

        y += 6;

      }
    );


    doc.save(
      `VX_${m}.pdf`
    );

    showToast(
      "PDF downloaded ✓"
    );

  }
);


$("#topDate").textContent =
  new Date().toLocaleDateString(
    "en-IN",
    {
      weekday: "long",
      day: "numeric",
      month: "long"
    }
  );


applyTheme();

dashboardUI();

dayUI();