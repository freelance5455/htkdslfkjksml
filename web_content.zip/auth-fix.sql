-- Prevent Auth signup failures when two users choose the same username.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  base_name text;
  candidate text;
  suffix text;
begin
  base_name := left(trim(coalesce(new.raw_user_meta_data->>'username', split_part(new.email,'@',1))), 18);
  if length(base_name) < 3 then base_name := 'player'; end if;
  candidate := base_name;
  suffix := substr(replace(new.id::text,'-',''),1,4);
  begin
    insert into public.profiles (id, username) values (new.id, candidate);
  exception when unique_violation then
    candidate := left(base_name, 13) || '_' || suffix;
    insert into public.profiles (id, username) values (new.id, candidate);
  end;
  insert into public.player_progress (user_id, stars, scores)
  values (new.id, to_jsonb(array_fill(0, ARRAY[50])), to_jsonb(array_fill(0, ARRAY[50])))
  on conflict (user_id) do nothing;
  return new;
end; $$;

-- Keep the trigger attached after replacing the function.
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();
