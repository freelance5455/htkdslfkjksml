const client = window.supabase.createClient(
  SUPABASE_URL,
  SUPABASE_KEY
);

const state = {
  user: localStorage.getItem("chat_user"),
  active: null,
  channel: null
};

const screen = document.getElementById("screen");

function escapeHtml(text) {
  return String(text)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function renderLogin() {
  screen.innerHTML = `
    <div class="card">
      <h2>Masuk ChatIOS</h2>
      <p style="margin:8px 0 18px;color:#777">
        Masukkan username kamu
      </p>

      <input id="username"
             placeholder="Contoh: widya"
             autocomplete="off">

      <button class="primary" id="loginBtn">
        Masuk
      </button>
    </div>
  `;

  document.getElementById("loginBtn").onclick = login;
}

async function login() {
  const input = document.getElementById("username");
  const username = input.value.trim().toLowerCase();

  if (!username) {
    alert("Masukkan username dulu.");
    return;
  }

  const { error } = await client
    .from("profiles")
    .upsert(
      {
        username: username,
        display_name: username
      },
      {
        onConflict: "username"
      }
    );

  if (error) {
    alert("Gagal terhubung ke Supabase: " + error.message);
    return;
  }

  state.user = username;
  localStorage.setItem("chat_user", username);

  renderChats();
}

async function renderChats() {
  screen.innerHTML = `
    <div class="card">
      <h2>Chats</h2>
      <p style="color:#777;margin:8px 0 15px">
        Login sebagai <b>${escapeHtml(state.user)}</b>
      </p>

      <input id="searchUser"
             placeholder="Cari username..."
             autocomplete="off">

      <div id="userResults"></div>
    </div>
  `;

  document.getElementById("searchUser").addEventListener(
    "input",
    searchUsers
  );

  loadExistingChats();
}

async function searchUsers() {
  const q = document.getElementById("searchUser").value.trim();

  const results = document.getElementById("userResults");

  if (!q) {
    results.innerHTML = `
      <p style="color:#999">Ketik username untuk mencari.</p>
    `;
    return;
  }

  const { data, error } = await client
    .from("profiles")
    .select("username,display_name,photo_url")
    .ilike("username", `%${q}%`)
    .neq("username", state.user)
    .limit(20);

  if (error) {
    results.innerHTML = `<p>Gagal mencari pengguna.</p>`;
    return;
  }

  if (!data.length) {
    results.innerHTML = `
      <p style="color:#999">Pengguna tidak ditemukan.</p>
    `;
    return;
  }

  results.innerHTML = data.map(user => `
    <div class="card" style="cursor:pointer"
         data-user="${escapeHtml(user.username)}">
      <b>${escapeHtml(user.display_name || user.username)}</b>
      <p style="color:#777">@${escapeHtml(user.username)}</p>
    </div>
  `).join("");

  results.querySelectorAll("[data-user]").forEach(el => {
    el.onclick = () => openChat(el.dataset.user);
  });
}

async function loadExistingChats() {
  const { data } = await client
    .from("messages")
    .select("sender_username,receiver_username")
    .or(
      `sender_username.eq.${state.user},receiver_username.eq.${state.user}`
    )
    .limit(100);

  if (!data || !data.length) return;

  const users = new Set();

  data.forEach(message => {
    if (message.sender_username !== state.user) {
      users.add(message.sender_username);
    }

    if (message.receiver_username !== state.user) {
      users.add(message.receiver_username);
    }
  });

  const results = document.getElementById("userResults");

  if (!results || users.size === 0) return;

  results.innerHTML = `
    <p style="margin:15px 0 8px;font-weight:bold">
      Percakapan
    </p>
    ${[...users].map(username => `
      <div class="card"
           style="cursor:pointer"
           data-user="${escapeHtml(username)}">
        <b>${escapeHtml(username)}</b>
      </div>
    `).join("")}
  `;

  results.querySelectorAll("[data-user]").forEach(el => {
    el.onclick = () => openChat(el.dataset.user);
  });
}

async function openChat(username) {
  state.active = username;

  if (state.channel) {
    await client.removeChannel(state.channel);
  }

  screen.innerHTML = `
    <div class="card">
      <button id="backBtn"
              style="border:0;background:none;padding:0 0 12px">
        ← Kembali
      </button>

      <h2>${escapeHtml(username)}</h2>
    </div>

    <div id="messages"></div>

    <div style="
      position:sticky;
      bottom:0;
      display:flex;
      gap:8px;
      padding:10px 0;
      background:#f2f2f7;
    ">
      <input id="messageInput"
             placeholder="Tulis pesan..."
             autocomplete="off"
             style="margin:0">

      <button id="sendBtn"
              style="
                border:0;
                border-radius:14px;
                padding:0 18px;
                background:#007aff;
                color:white;
              ">
        Kirim
      </button>
    </div>
  `;

  document.getElementById("backBtn").onclick = renderChats;
  document.getElementById("sendBtn").onclick = sendMessage;

  document
    .getElementById("messageInput")
    .addEventListener("keydown", e => {
      if (e.key === "Enter") {
        sendMessage();
      }
    });

  await loadMessages();
  subscribeMessages();
}

async function loadMessages() {
  const { data, error } = await client
    .from("messages")
    .select("*")
    .or(
      `and(sender_username.eq.${state.user},receiver_username.eq.${state.active}),and(sender_username.eq.${state.active},receiver_username.eq.${state.user})`
    )
    .order("created_at", { ascending: true });

  if (error) {
    document.getElementById("messages").innerHTML =
      `<div class="card">Gagal memuat pesan.</div>`;
    return;
  }

  renderMessages(data || []);
}

function renderMessages(messages) {
  const container = document.getElementById("messages");

  if (!container) return;

  if (!messages.length) {
    container.innerHTML = `
      <div class="card">
        Belum ada pesan. Kirim pesan pertama 👋
      </div>
    `;
    return;
  }

  container.innerHTML = messages.map(message => `
    <div class="message ${
      message.sender_username === state.user
        ? "mine"
        : "theirs"
    }">
      ${escapeHtml(message.message)}
    </div>
  `).join("");

  container.scrollTop = container.scrollHeight;
}

async function sendMessage() {
  const input = document.getElementById("messageInput");

  if (!input) return;

  const text = input.value.trim();

  if (!text || !state.active) return;

  input.value = "";

  const { error } = await client
    .from("messages")
    .insert({
      sender_username: state.user,
      receiver_username: state.active,
      message: text
    });

  if (error) {
    alert("Pesan gagal dikirim: " + error.message);
  }
}

function subscribeMessages() {
  state.channel = client
    .channel(
      "chat-" +
      [state.user, state.active].sort().join("-")
    )
    .on(
      "postgres_changes",
      {
        event: "INSERT",
        schema: "public",
        table: "messages"
      },
      payload => {
        const message = payload.new;

        const relevant =
          (
            message.sender_username === state.user &&
            message.receiver_username === state.active
          ) ||
          (
            message.sender_username === state.active &&
            message.receiver_username === state.user
          );

        if (relevant) {
          loadMessages();
        }
      }
    )
    .subscribe();
}

function renderSettings() {
  screen.innerHTML = `
    <div class="card">
      <h2>Pengaturan</h2>

      <p style="margin:12px 0">
        Username:
        <b>${escapeHtml(state.user || "-")}</b>
      </p>

      <button class="primary" id="logoutBtn">
        Keluar
      </button>
    </div>
  `;

  document.getElementById("logoutBtn").onclick = () => {
    localStorage.removeItem("chat_user");
    state.user = null;
    state.active = null;

    if (state.channel) {
      client.removeChannel(state.channel);
      state.channel = null;
    }

    renderLogin();
  };
}

function renderContacts() {
  screen.innerHTML = `
    <div class="card">
      <h2>Kontak</h2>
      <p style="color:#777">
        Cari pengguna dari halaman Chats.
      </p>
    </div>
  `;
}

document.querySelectorAll("nav button").forEach(button => {
  button.addEventListener("click", () => {
    document
      .querySelectorAll("nav button")
      .forEach(btn => btn.classList.remove("active"));

    button.classList.add("active");

    const tab = button.dataset.tab;

    if (!state.user) {
      renderLogin();
      return;
    }

    if (tab === "chats") renderChats();
    if (tab === "contacts") renderContacts();
    if (tab === "settings") renderSettings();
  });
});

if (state.user) {
  renderChats();
} else {
  renderLogin();
}