const SUPABASE_URL = 'https://ufhajqvdgzytosxklnqj.supabase.co';
const SUPABASE_KEY = 'sb_publishable_3Et9swLfhDBxtyIU3cAiLg_g9D0xqJP';