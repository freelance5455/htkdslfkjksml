using UnityEngine;
using MinecraftVR.Voxels;

namespace MinecraftVR
{
    public class WorldBootstrap : MonoBehaviour
    {
        public Material worldMaterial;
        public void Start()
        {
            var worldObject = new GameObject("VoxelWorld");
            var world = worldObject.AddComponent<VoxelWorld>();
            world.voxelMaterial = worldMaterial != null ? worldMaterial : CreateMaterial();
            world.Generate();
        }

        private Material CreateMaterial()
        {
            Shader shader = Shader.Find("Universal Render Pipeline/Lit");
            if (shader == null) shader = Shader.Find("Standard");
            var m = new Material(shader);
            m.enableInstancing = true;
            return m;
        }
    }
}
