using UnityEngine;
using MinecraftVR.Voxels;

namespace MinecraftVR.VR
{
    // Attach to the right-hand controller. Trigger mines; Grip places a block.
    public class BlockInteractor : MonoBehaviour
    {
        public VoxelWorld world;
        public float reach = 5f;
        public BlockType placeType = BlockType.Dirt;
        public Transform rayOrigin;

        private void Update()
        {
            if (world == null) return;
            Transform origin = rayOrigin != null ? rayOrigin : transform;
            if (Input.GetMouseButtonDown(0)) Mine(origin);
            if (Input.GetMouseButtonDown(1)) Place(origin);
        }

        public void Mine(Transform origin)
        {
            if (Physics.Raycast(origin.position, origin.forward, out var hit, reach))
            {
                var chunk = hit.collider.GetComponent<VoxelChunk>();
                if (chunk == null) return;
                Vector3 local = chunk.transform.InverseTransformPoint(hit.point - hit.normal * .02f);
                Vector3Int cell = Vector3Int.FloorToInt(local);
                Vector3 worldPos = chunk.transform.TransformPoint(cell);
                Vector3Int p = Vector3Int.RoundToInt(worldPos);
                world.SetBlock(p, BlockType.Air);
            }
        }

        public void Place(Transform origin)
        {
            if (Physics.Raycast(origin.position, origin.forward, out var hit, reach))
            {
                Vector3 p3 = hit.point + hit.normal * .51f;
                Vector3Int p = Vector3Int.RoundToInt(p3);
                world.SetBlock(p, placeType);
            }
        }
    }
}
