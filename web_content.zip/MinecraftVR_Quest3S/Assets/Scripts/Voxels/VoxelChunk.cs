using System.Collections.Generic;
using UnityEngine;

namespace MinecraftVR.Voxels
{
    [RequireComponent(typeof(MeshFilter), typeof(MeshRenderer), typeof(MeshCollider))]
    public class VoxelChunk : MonoBehaviour
    {
        private static readonly Vector3Int[] Dirs = {
            Vector3Int.forward, Vector3Int.back, Vector3Int.left,
            Vector3Int.right, Vector3Int.up, Vector3Int.down
        };
        private static readonly Vector3[,] Face = {
            { new Vector3(0,0,1), new Vector3(1,0,1), new Vector3(1,1,1), new Vector3(0,1,1) },
            { new Vector3(1,0,0), new Vector3(0,0,0), new Vector3(0,1,0), new Vector3(1,1,0) },
            { new Vector3(0,0,0), new Vector3(0,0,1), new Vector3(0,1,1), new Vector3(0,1,0) },
            { new Vector3(1,0,1), new Vector3(1,0,0), new Vector3(1,1,0), new Vector3(1,1,1) },
            { new Vector3(0,1,1), new Vector3(1,1,1), new Vector3(1,1,0), new Vector3(0,1,0) },
            { new Vector3(0,0,0), new Vector3(1,0,0), new Vector3(1,0,1), new Vector3(0,0,1) }
        };

        private VoxelWorld world;
        private Vector2Int coord;
        private int size;
        private Material material;
        private MeshFilter filter;
        private MeshCollider meshCollider;

        public void Initialize(VoxelWorld owner, Vector2Int chunkCoord, int chunkSize, Material mat)
        {
            world = owner; coord = chunkCoord; size = chunkSize; material = mat;
            filter = GetComponent<MeshFilter>();
            meshCollider = GetComponent<MeshCollider>();
            GetComponent<MeshRenderer>().sharedMaterial = material;
            transform.localPosition = new Vector3(coord.x * size, 0, coord.y * size);
        }

        public void Rebuild()
        {
            if (world == null) return;
            var vertices = new List<Vector3>();
            var triangles = new List<int>();
            var colors = new List<Color>();
            for (int x=0; x<size; x++)
            for (int z=0; z<size; z++)
            for (int y=0; y<world.maxHeight; y++)
            {
                int wx = coord.x * size + x, wz = coord.y * size + z;
                var block = world.GetBlock(wx,y,wz);
                if (block == BlockType.Air) continue;
                for (int f=0; f<6; f++)
                {
                    var d = Dirs[f];
                    if (world.GetBlock(wx+d.x,y+d.y,wz+d.z) != BlockType.Air) continue;
                    int start = vertices.Count;
                    for (int i=0;i<4;i++) vertices.Add(new Vector3(x,y,z) + Face[f,i]);
                    triangles.AddRange(new [] { start, start+1, start+2, start, start+2, start+3 });
                    Color c = BlockColor(block);
                    for (int i=0;i<4;i++) colors.Add(c);
                }
            }
            var mesh = new Mesh { indexFormat = vertices.Count > 65000 ?
                UnityEngine.Rendering.IndexFormat.UInt32 : UnityEngine.Rendering.IndexFormat.UInt16 };
            mesh.SetVertices(vertices); mesh.SetTriangles(triangles,0); mesh.SetColors(colors); mesh.RecalculateNormals();
            filter.sharedMesh = null; meshCollider.sharedMesh = null;
            filter.sharedMesh = mesh; meshCollider.sharedMesh = mesh;
        }

        private Color BlockColor(BlockType b)
        {
            switch (b)
            {
                case BlockType.Grass: return new Color(.28f,.62f,.22f);
                case BlockType.Dirt: return new Color(.43f,.27f,.15f);
                case BlockType.Stone: return new Color(.48f,.49f,.51f);
                case BlockType.Sand: return new Color(.82f,.73f,.48f);
                case BlockType.Wood: return new Color(.38f,.22f,.10f);
                case BlockType.Leaves: return new Color(.12f,.42f,.16f);
                default: return Color.magenta;
            }
        }
    }
}
