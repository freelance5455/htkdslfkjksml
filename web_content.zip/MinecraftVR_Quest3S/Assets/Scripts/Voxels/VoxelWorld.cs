using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace MinecraftVR.Voxels
{
    public class VoxelWorld : MonoBehaviour
    {
        [Header("World")]
        public int chunkSize = 16;
        public int chunksX = 4;
        public int chunksZ = 4;
        public int maxHeight = 24;
        public int seed = 12345;
        public Material voxelMaterial;

        private readonly Dictionary<Vector3Int, BlockType> edits = new Dictionary<Vector3Int, BlockType>();
        private readonly Dictionary<Vector2Int, VoxelChunk> chunks = new Dictionary<Vector2Int, VoxelChunk>();

        private string SavePath => Path.Combine(Application.persistentDataPath, "world_stage1.json");

        public void Generate()
        {
            UnityEngine.Random.InitState(seed);
            for (int x = 0; x < chunksX; x++)
            for (int z = 0; z < chunksZ; z++)
            {
                var go = new GameObject($"Chunk_{x}_{z}");
                go.transform.SetParent(transform, false);
                var chunk = go.AddComponent<VoxelChunk>();
                chunk.Initialize(this, new Vector2Int(x, z), chunkSize, voxelMaterial);
                chunks[new Vector2Int(x, z)] = chunk;
            }
            LoadEdits();
            RebuildAll();
        }

        public BlockType GetBlock(int x, int y, int z)
        {
            var p = new Vector3Int(x, y, z);
            if (edits.TryGetValue(p, out var changed)) return changed;
            if (y < 0) return BlockType.Stone;
            if (y >= maxHeight) return BlockType.Air;

            float n = Mathf.PerlinNoise((x + seed) * .035f, (z + seed) * .035f);
            int surface = 4 + Mathf.FloorToInt(n * 7f);
            if (y > surface) return BlockType.Air;
            if (y == surface) return n < .28f ? BlockType.Sand : BlockType.Grass;
            if (y >= surface - 3) return n < .28f ? BlockType.Sand : BlockType.Dirt;
            return BlockType.Stone;
        }

        public void SetBlock(Vector3Int p, BlockType type)
        {
            edits[p] = type;
            RebuildAt(p);
            SaveEdits();
        }

        public void RebuildAt(Vector3Int p)
        {
            int cx = Mathf.FloorToInt((float)p.x / chunkSize);
            int cz = Mathf.FloorToInt((float)p.z / chunkSize);
            for (int dx = -1; dx <= 1; dx++)
            for (int dz = -1; dz <= 1; dz++)
                if (chunks.TryGetValue(new Vector2Int(cx + dx, cz + dz), out var c))
                    c.Rebuild();
        }

        public void RebuildAll()
        {
            foreach (var c in chunks.Values) c.Rebuild();
        }

        [Serializable] private class EditRecord { public int x,y,z,t; }
        [Serializable] private class EditList { public List<EditRecord> items = new List<EditRecord>(); }

        public void SaveEdits()
        {
            var data = new EditList();
            foreach (var kv in edits)
                data.items.Add(new EditRecord { x=kv.Key.x, y=kv.Key.y, z=kv.Key.z, t=(int)kv.Value });
            File.WriteAllText(SavePath, JsonUtility.ToJson(data));
        }

        private void LoadEdits()
        {
            if (!File.Exists(SavePath)) return;
            try
            {
                var data = JsonUtility.FromJson<EditList>(File.ReadAllText(SavePath));
                if (data?.items == null) return;
                foreach (var e in data.items)
                    edits[new Vector3Int(e.x,e.y,e.z)] = (BlockType)e.t;
            }
            catch (Exception ex) { Debug.LogWarning("World save could not be loaded: " + ex.Message); }
        }
    }
}
