#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.XR;
using UnityEngine.XR.Management;
using UnityEngine.XR.Interaction.Toolkit;
using MinecraftVR;

public static class MinecraftVRSetup
{
    [MenuItem("Tools/MinecraftVR/Create Starter Scene")]
    public static void CreateScene()
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        var root = new GameObject("MinecraftVR_Runtime");
        root.AddComponent<WorldBootstrap>();

        var xrOrigin = new GameObject("XR Origin (configure with XR Interaction Toolkit)");
        xrOrigin.transform.position = new Vector3(8, 12, 8);
        var cameraOffset = new GameObject("Camera Offset");
        cameraOffset.transform.SetParent(xrOrigin.transform, false);
        var camera = new GameObject("Main Camera");
        camera.tag = "MainCamera";
        camera.transform.SetParent(cameraOffset.transform, false);
        camera.AddComponent<Camera>();
        camera.AddComponent<AudioListener>();

        CreateHand(cameraOffset.transform, "Left Hand", new Vector3(-.25f,-.2f,.45f));
        CreateHand(cameraOffset.transform, "Right Hand", new Vector3(.25f,-.2f,.45f));

        var light = Object.FindObjectOfType<Light>();
        if (light != null) light.intensity = 1.2f;

        EditorSceneManager.SaveScene(scene, "Assets/Scenes/Main.unity");
        AssetDatabase.Refresh();
        Debug.Log("Starter scene created. Configure XR Plug-in Management/OpenXR and controller tracking before device build.");
    }

    private static void CreateHand(Transform parent, string name, Vector3 pos)
    {
        var hand = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        hand.name = name;
        hand.transform.SetParent(parent, false);
        hand.transform.localPosition = pos;
        hand.transform.localScale = Vector3.one * .12f;
    }
}
#endif
