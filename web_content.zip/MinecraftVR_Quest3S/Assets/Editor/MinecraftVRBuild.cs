#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

public static class MinecraftVRBuild
{
    public static void BuildAndroid()
    {
        EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);
        PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
        PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
        PlayerSettings.productName = "MinecraftVR";
        PlayerSettings.companyName = "IndieVoxelStudio";
        string[] scenes = { "Assets/Scenes/Main.unity" };
        var report = BuildPipeline.BuildPlayer(scenes, "Build/MinecraftVR_Quest3S.apk",
            BuildTarget.Android, BuildOptions.None);
        if (report.summary.result != BuildResult.Succeeded)
            throw new System.Exception("Android build failed: " + report.summary.result);
    }
}
#endif
