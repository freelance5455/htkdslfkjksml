Сцена Main.unity создаётся в Unity через Tools → MinecraftVR → Create Starter Scene.
