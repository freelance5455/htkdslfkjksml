package com.omarwaki.hesabaltajer;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private WebView printWebView;
    private FrameLayout root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        root = new FrameLayout(this);
        setContentView(root);
        printWebView = new WebView(this);
        printWebView.setAlpha(0f);
        printWebView.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        root.addView(printWebView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        webView = new WebView(this);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(true);
        webView.setHorizontalScrollBarEnabled(false);
        root.addView(webView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setDefaultTextEncodingName("UTF-8");
        webView.getSettings().setSupportZoom(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface public void printHtml(String content) { runOnUiThread(() -> startHtmlPrint(content)); }
            @JavascriptInterface public void savePaperImage() { runOnUiThread(() -> capturePaperImage()); }
        }, "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void capturePaperImage() {
        try {
            String html = (String) null;
            webView.evaluateJavascript("(function(){var p=document.querySelector('#ledgerPaperContent .ledger-paper');return p?p.outerHTML:''})()", value -> {
                String content = value;
                if (content == null || content.equals("\"\"")) { toast("لا توجد ورقة لحفظها"); return; }
                // JavaScript returns a quoted string; decode it safely through a temporary JS container.
                webView.evaluateJavascript("JSON.stringify(document.querySelector('#ledgerPaperContent .ledger-paper').outerHTML)", encoded -> {
                    String paperHtml = unquoteJs(encoded);
                    if (paperHtml == null || paperHtml.isEmpty()) { toast("تعذر تجهيز الورقة"); return; }
                    renderAndSaveImage(paperHtml);
                });
            });
        } catch (Exception e) { toast("تعذر حفظ الصورة"); }
    }

    private String unquoteJs(String value) {
        if (value == null || value.length() < 2) return "";
        String s = value.substring(1, value.length() - 1);
        return s.replace("\\u003C", "<").replace("\\u003E", ">").replace("\\u0026", "&")
                .replace("\\n", "\n").replace("\\r", "\r").replace("\\t", "\t")
                .replace("\\\"", "\"").replace("\\\\", "\\");
    }

    private void renderAndSaveImage(String paperHtml) {
        WebView imageView = new WebView(this);
        imageView.setBackgroundColor(android.graphics.Color.WHITE);
        imageView.getSettings().setJavaScriptEnabled(false);
        imageView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript("Math.max(document.body.scrollHeight,document.documentElement.scrollHeight)", result -> {
                    try {
                        int height = Math.max(900, Math.min(12000, (int) Double.parseDouble(result)));
                        int width = Math.max(320, webView.getWidth());
                        view.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY));
                        view.layout(0, 0, width, height);
                        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                        Canvas canvas = new Canvas(bitmap);
                        canvas.drawColor(android.graphics.Color.WHITE);
                        view.draw(canvas);
                        saveBitmap(bitmap);
                        bitmap.recycle();
                    } catch (Exception e) { toast("تعذر إنشاء الصورة"); }
                    finally { view.destroy(); }
                });
            }
        });
        String html = "<!doctype html><html lang='ar' dir='rtl'><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'><style>*{box-sizing:border-box}html,body{margin:0;padding:0;background:#fff;color:#111;font-family:Tahoma,Arial,sans-serif}.ledger-paper{width:100%;min-height:900px;padding:24px 18px;background:#fff}.ledger-paper h2{text-align:center;margin:0 0 18px;font-size:21px}.ledger-meta{display:flex;flex-wrap:wrap;justify-content:space-between;gap:8px;border:1px solid #333;padding:10px;margin-bottom:16px;font-size:13px}.ledger-paper table{width:100%;border-collapse:collapse;table-layout:fixed}.ledger-paper th,.ledger-paper td{border:1px solid #222;padding:8px 4px;text-align:center;font-size:12px;overflow-wrap:anywhere}.ledger-paper th{background:#eee}.ledger-totals{margin-top:18px;border:1px solid #222;padding:12px;display:flex;justify-content:space-around;flex-wrap:wrap;gap:10px;font-weight:bold;font-size:13px}.ledger-footer{text-align:center;border-top:1px solid #aaa;margin-top:40px;padding-top:8px;font-size:11px}</style></head><body>" + paperHtml + "</body></html>";
        imageView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
    }

    private void saveBitmap(Bitmap bitmap) {
        OutputStream out = null;
        try {
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            String name = "كشف_حساب_" + stamp + ".png";
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/حساب التاجر");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
                Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("MediaStore unavailable");
                out = getContentResolver().openOutputStream(uri);
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                if (out != null) out.close();
                values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0);
                getContentResolver().update(uri, values, null, null);
                toast("تم حفظ ورقة الحساب في المعرض داخل مجلد حساب التاجر");
            } else {
                toast("حفظ الصورة يحتاج Android 10 أو أحدث");
            }
        } catch (Exception e) { try { if (out != null) out.close(); } catch (Exception ignored) {} toast("فشل حفظ الصورة، حاول مرة أخرى"); }
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }

    private void startHtmlPrint(String content) {
        try {
            if (content == null || content.trim().isEmpty()) { toast("لا توجد بيانات لتصديرها"); return; }
            printWebView.stopLoading();
            printWebView.getSettings().setJavaScriptEnabled(false);
            printWebView.getSettings().setDefaultTextEncodingName("UTF-8");
            printWebView.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView view, String url) { view.post(() -> { view.requestLayout(); view.postDelayed(() -> openPrintDialog(view), 700); }); }
            });
            String printable = "<!doctype html><html lang='ar' dir='rtl'><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1'><style>@page{size:A4 portrait;margin:12mm}*{box-sizing:border-box}body{margin:0;color:#111;background:#fff;font-family:Tahoma,Arial,sans-serif;direction:rtl}.paper{page-break-after:always;break-after:page;min-height:270mm;position:relative;padding-bottom:15mm}.paper:last-child{page-break-after:auto;break-after:auto}.paper h2{text-align:center;margin:0 0 5mm;font-size:19px}.meta{display:flex;justify-content:space-between;flex-wrap:wrap;gap:6px;border:1px solid #333;padding:7px;margin-bottom:5mm;font-size:12px}table{width:100%;border-collapse:collapse;table-layout:fixed;font-size:11px}th,td{border:1px solid #222;padding:7px 4px;text-align:center;overflow-wrap:anywhere;word-break:break-word}th{background:#eee!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}.totals{margin-top:8mm;border:1px solid #222;padding:8px;display:flex;justify-content:space-around;flex-wrap:wrap;gap:8px;font-weight:bold;font-size:12px}.foot{position:absolute;bottom:0;left:0;right:0;text-align:center;font-size:10px;border-top:1px solid #999;padding-top:4px}.empty{padding:20px;text-align:center}</style></head><body>" + content + "</body></html>";
            printWebView.loadDataWithBaseURL("file:///android_asset/", printable, "text/html", "UTF-8", null);
        } catch (Exception e) { toast("تعذر تجهيز ملف PDF"); }
    }

    private void openPrintDialog(WebView source) {
        try {
            android.print.PrintManager manager = (android.print.PrintManager) getSystemService(Context.PRINT_SERVICE);
            if (manager == null) { toast("خدمة الطباعة غير متاحة على الجهاز"); return; }
            android.print.PrintAttributes attributes = new android.print.PrintAttributes.Builder().setMediaSize(android.print.PrintAttributes.MediaSize.ISO_A4).setResolution(new android.print.PrintAttributes.Resolution("pdf", "PDF", 300, 300)).setMinMargins(android.print.PrintAttributes.Margins.NO_MARGINS).build();
            manager.print("كشف حساب التاجر", source.createPrintDocumentAdapter("حساب التاجر"), attributes);
        } catch (Exception e) { toast("تعذر فتح نافذة حفظ PDF"); }
    }

    @Override protected void onDestroy() { if (printWebView != null) { printWebView.destroy(); printWebView = null; } if (webView != null) { webView.destroy(); webView = null; } root = null; super.onDestroy(); }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
