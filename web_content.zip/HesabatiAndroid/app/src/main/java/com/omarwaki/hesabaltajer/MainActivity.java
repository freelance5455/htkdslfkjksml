package com.omarwaki.hesabaltajer;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private WebView printWebView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(true);
        webView.setHorizontalScrollBarEnabled(false);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setDefaultTextEncodingName("UTF-8");
        webView.getSettings().setSupportZoom(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void printHtml(String content) {
                runOnUiThread(() -> startHtmlPrint(content));
            }
        }, "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void startHtmlPrint(String content) {
        try {
            if (content == null || content.trim().isEmpty()) {
                Toast.makeText(this, "لا توجد بيانات لتصديرها", Toast.LENGTH_LONG).show();
                return;
            }
            if (printWebView != null) {
                try { printWebView.destroy(); } catch (Exception ignored) {}
            }
            printWebView = new WebView(this);
            printWebView.getSettings().setJavaScriptEnabled(false);
            printWebView.getSettings().setDefaultTextEncodingName("UTF-8");
            printWebView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    view.postDelayed(() -> openPrintDialog(view), 350);
                }
            });
            String printable = "<!doctype html><html lang='ar' dir='rtl'><head>"
                + "<meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1'>"
                + "<style>@page{size:A4 portrait;margin:12mm}*{box-sizing:border-box}"
                + "body{margin:0;color:#111;background:#fff;font-family:Tahoma,Arial,sans-serif;direction:rtl}"
                + ".paper{page-break-after:always;break-after:page;min-height:270mm;position:relative;padding-bottom:15mm}"
                + ".paper:last-child{page-break-after:auto;break-after:auto}.paper h2{text-align:center;margin:0 0 5mm;font-size:19px}"
                + ".meta{display:flex;justify-content:space-between;flex-wrap:wrap;gap:6px;border:1px solid #333;padding:7px;margin-bottom:5mm;font-size:12px}"
                + "table{width:100%;border-collapse:collapse;table-layout:fixed;font-size:11px}"
                + "th,td{border:1px solid #222;padding:7px 4px;text-align:center;overflow-wrap:anywhere;word-break:break-word}"
                + "th{background:#eee!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}"
                + ".totals{margin-top:8mm;border:1px solid #222;padding:8px;display:flex;justify-content:space-around;flex-wrap:wrap;gap:8px;font-weight:bold;font-size:12px}"
                + ".foot{position:absolute;bottom:0;left:0;right:0;text-align:center;font-size:10px;border-top:1px solid #999;padding-top:4px}"
                + ".empty{padding:20px;text-align:center}</style></head><body>" + content + "</body></html>";
            printWebView.loadDataWithBaseURL("file:///android_asset/", printable, "text/html", "UTF-8", null);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر تجهيز ملف PDF", Toast.LENGTH_LONG).show();
        }
    }

    private void openPrintDialog(WebView source) {
        try {
            PrintManager manager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
            if (manager == null) {
                Toast.makeText(this, "خدمة الطباعة غير متاحة على الجهاز", Toast.LENGTH_LONG).show();
                return;
            }
            PrintAttributes attributes = new PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setResolution(new PrintAttributes.Resolution("pdf", "PDF", 300, 300))
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .build();
            manager.print("كشف حساب التاجر", source.createPrintDocumentAdapter("حساب التاجر"), attributes);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر فتح نافذة حفظ PDF", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        if (printWebView != null) { printWebView.destroy(); printWebView = null; }
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
