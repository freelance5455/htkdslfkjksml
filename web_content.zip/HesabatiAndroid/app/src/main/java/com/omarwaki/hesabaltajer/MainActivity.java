package com.omarwaki.hesabaltajer;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(true);
        webView.setHorizontalScrollBarEnabled(false);
        setContentView(webView);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setDefaultTextEncodingName("UTF-8");
        webView.getSettings().setSupportZoom(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void printPage() {
                runOnUiThread(() -> {
                    // Let the WebView finish applying the print stylesheet and laying out pages.
                    webView.postDelayed(() -> {
                        try {
                            PrintManager manager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                            if (manager == null) {
                                Toast.makeText(MainActivity.this, "خدمة الطباعة غير متاحة على الجهاز", Toast.LENGTH_LONG).show();
                                return;
                            }
                            PrintAttributes attributes = new PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                .setResolution(new PrintAttributes.Resolution("pdf", "PDF", 300, 300))
                                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                .build();
                            manager.print("كشف حساب التاجر", webView.createPrintDocumentAdapter("حساب التاجر"), attributes);
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "تعذر فتح حفظ PDF. حدّث التطبيق وحاول مجدداً", Toast.LENGTH_LONG).show();
                        }
                    }, 500);
                });
            }
        }, "Android");

        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
