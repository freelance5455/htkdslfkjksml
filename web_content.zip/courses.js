/* JOSTECH — CATALOGUE DES 10 DISCIPLINES & INDEX COMPLET DES MANUELS */
const DISCIPLINES = [
  { id: 1, num: "01", title: "Informatique générale", status: "pilot", shortDesc: "Architecture des ordinateurs, logique binaire, codage des données et fondements des sciences informatiques.", topics: ["Introduction à l'informatique", "Histoire de l'informatique", "Architecture des ordinateurs", "Systèmes de numération", "Codage des données", "Logique informatique", "Culture numérique"], levels: {} },
  { id: 2, num: "02", title: "Programmation informatique", status: "pilot", shortDesc: "Algorithmique, structures de données, POO et langages C, C++, Python, Java et JavaScript.", topics: ["Algorithmique", "Organigrammes", "Logique de programmation", "Langage C", "C++", "Python", "Java", "JavaScript", "Structures de données", "POO"], levels: {} },
  { id: 3, num: "03", title: "Développement Web et mobile", status: "pilot", shortDesc: "HTML, CSS, JavaScript, PHP, API REST, développement Android/iOS et applications PWA.", topics: ["HTML", "CSS", "JavaScript", "PHP", "Front-end", "Back-end", "Android", "iOS", "API REST", "PWA"], levels: {} },
  { id: 4, num: "04", title: "Cybersécurité", status: "active", shortDesc: "Cryptographie, sécurité des réseaux et applications, tests autorisés et éthique.", topics: ["Fondements", "Cryptographie", "Sécurité réseaux", "Sécurité applis", "Gestion des risques", "Vulnérabilités", "Investigation numérique", "Éthique"], levels: {} },
  { id: 5, num: "05", title: "Intelligence artificielle", status: "active", shortDesc: "Machine Learning, Deep Learning, réseaux de neurones, NLP, vision et IA générative.", topics: ["Fondements IA", "IA symbolique", "Machine Learning", "Deep Learning", "Réseaux de neurones", "NLP", "Vision par ordinateur", "IA générative", "Prompts"], levels: {} },
  { id: 6, num: "06", title: "Réseaux, architecture et maintenance", status: "active", shortDesc: "Matériel, maintenance préventive/corrective, modèles OSI & TCP/IP, routage et virtualisation.", topics: ["Architecture matérielle", "Électronique", "Assemblage", "Maintenance", "Modèles OSI & TCP/IP", "Routage", "Administration systèmes", "Virtualisation"], levels: {} },
  { id: 7, num: "07", title: "Bases de données et SI", status: "active", shortDesc: "Modélisation relationnelle, SQL, MySQL, PostgreSQL, sécurité et systèmes d'information.", topics: ["Bases de données", "Modélisation", "Modèle relationnel", "SQL", "MySQL", "PostgreSQL", "Transactions", "Sauvegarde", "Systèmes d'information"], levels: {} },
  { id: 8, num: "08", title: "Robotique", status: "active", shortDesc: "Électronique, capteurs, actionneurs, microcontrôleurs Arduino et systèmes embarqués.", topics: ["Introduction", "Mathématiques appliquées", "Électronique", "Capteurs et actionneurs", "Microcontrôleurs", "Arduino", "Automatisation", "Systèmes embarqués"], levels: {} },
  { id: 9, num: "09", title: "Génie informatique et logiciel", status: "active", shortDesc: "Conception, architecture logicielle, méthodes agiles, gestion de projet, tests et qualité.", topics: ["Génie informatique", "Architecture logicielle", "Méthodes agiles", "Gestion de projets", "Tests et validation", "Qualité logicielle", "Maintenance"], levels: {} },
  { id: 10, num: "10", title: "Anglais informatique", status: "active", shortDesc: "Vocabulaire technique, lecture de documentations et communication professionnelle IT.", topics: ["Anglais appliqué", "Vocabulaire programmation", "Anglais réseaux", "Anglais cybersécurité", "Anglais IA", "Documentations", "Rédaction technique"], levels: {} }
];

const BOOK_FILES = {
  "ig-1-1-1": "book-ig-1.js", "ig-1-1-2": "book-ig-2.js", "ig-2-1-1": "book-ig-3.js", "ig-3-1-1": "book-ig-4.js",
  "prog-1-1-1": "book-prog-1.js", "prog-1-1-2": "book-prog-2.js", "prog-2-1-1": "book-prog-3.js", "prog-3-1-1": "book-prog-4.js",
  "web-1-1-1": "book-web-1.js", "web-1-1-2": "book-web-2.js", "web-2-1-1": "book-web-3.js", "web-3-1-1": "book-web-4.js",
  "sec-1-1-1": "book-sec-1.js", "sec-2-1-1": "book-sec-2.js", "sec-3-1-1": "book-sec-3.js",
  "ia-1-1-1": "book-ia-1.js", "ia-2-1-1": "book-ia-2.js", "ia-3-1-1": "book-ia-3.js",
  "res-1-1-1": "book-res-1.js", "res-2-1-1": "book-res-2.js", "res-3-1-1": "book-res-3.js",
  "bdd-1-1-1": "book-bdd-1.js", "bdd-2-1-1": "book-bdd-2.js", "bdd-3-1-1": "book-bdd-3.js",
  "rob-1-1-1": "book-rob-1.js", "rob-2-1-1": "book-rob-2.js", "rob-3-1-1": "book-rob-3.js",
  "gl-1-1-1": "book-gl-1.js", "gl-2-1-1": "book-gl-2.js", "gl-3-1-1": "book-gl-3.js",
  "eng-1-1-1": "book-eng-1.js", "eng-2-1-1": "book-eng-2.js", "eng-3-1-1": "book-eng-3.js"
};

function registerDisciplineLevels(discId, levelsObj) {
  const d = DISCIPLINES.find(x => x.id === discId);
  if (d) d.levels = levelsObj;
}

function registerLessonDetail(discId, lvl, lessonId, fullLesson) {
  const d = DISCIPLINES.find(x => x.id === discId);
  if (!d || !d.levels || !d.levels[lvl]) return;
  d.levels[lvl].chapters.forEach(c => {
    const target = c.lessons.find(l => l.id === lessonId);
    if (target) { Object.assign(target, fullLesson); target._bookLoaded = true; }
  });
}