/* Core logic for Inventory & Sales Tracker (no DOM code). */
(function (root) {
  "use strict";
  const Core = {};
  const ITEM_TEXT = ["sku", "barcode", "name", "category", "supplier", "location"];
  const ITEM_NUM = ["purchase_price", "selling_price", "cash_disc", "bulk_disc", "bulk_min", "commission", "reorder_level", "reorder_qty"];
  Core.ITEM_TEXT = ITEM_TEXT; Core.ITEM_NUM = ITEM_NUM;

  const r2 = (v) => { const a = Number(Math.round(Number(Math.abs(v).toFixed(8) + "e2")) + "e-2"); return v < 0 ? -a : a; };
  Core.r2 = r2;
  // Discounts and commission are either a percentage ("pct", stored as a fraction) or a fixed dollar amount per unit ("amt").
  const TYPE_FIELDS = { cash_disc: "cash_disc_type", bulk_disc: "bulk_disc_type", commission: "commission_type" };
  Core.TYPE_FIELDS = TYPE_FIELDS;
  const kindOf = (item, key) => (item && item[key] === "amt" ? "amt" : "pct");
  Core.defaultSettings = () => ({ business: "", address: "", phone: "", tax_rate: 0, footer: "Thank you for your business!", next_invoice: 1, next_return: 1 });
  Core.newOv = () => ({ price: { v: "", k: "unit" }, cash: { v: "", k: "pct" }, bulk: { v: "", k: "pct" }, commission: { v: "", k: "pct" } });
  Core.newCart = () => ({ lines: [], customer: "", payment: "Cash", agent: "", note: "", ov: Core.newOv() });
  Core.ensureState = (s) => {
    s.items = s.items || []; s.log = s.log || []; s.invoices = s.invoices || []; s.returns = s.returns || []; s.agents = s.agents || []; s.nextId = s.nextId || 1;
    s.settings = Object.assign(Core.defaultSettings(), s.settings || {});
    s.cart = Object.assign(Core.newCart(), s.cart || {}); s.cart.ov = Object.assign(Core.newOv(), s.cart.ov || {});
    for (const i of s.items) for (const t of Object.values(TYPE_FIELDS)) if (i[t] !== "amt") i[t] = "pct";
    for (const inv of s.invoices) for (const l of inv.lines) if (l.returned == null) l.returned = 0;
    return s;
  };
  Core.newState = () => Core.ensureState({ items: [], log: [], nextId: 1 });

  Core.checkDigit = (d12) => {
    let s = 0;
    for (let i = 0; i < 12; i++) s += Number(d12[i]) * (i % 2 === 0 ? 1 : 3);
    return String((10 - (s % 10)) % 10);
  };
  Core.isValidEAN13 = (c) => /^\d{13}$/.test(c) && Core.checkDigit(c.slice(0, 12)) === c[12];

  const L = ["0001101", "0011001", "0010011", "0111101", "0100011", "0110001", "0101111", "0111011", "0110111", "0001011"];
  const G = ["0100111", "0110011", "0011011", "0100001", "0011101", "0111001", "0000101", "0010001", "0001001", "0010111"];
  const R = ["1110010", "1100110", "1101100", "1000010", "1011100", "1001110", "1010000", "1000100", "1001000", "1110100"];
  const PAR = ["LLLLLL", "LLGLGG", "LLGGLG", "LLGGGL", "LGLLGG", "LGGLLG", "LGGGLL", "LGLGLG", "LGLGGL", "LGGLGL"];
  Core.ean13Bits = (code) => {
    if (!Core.isValidEAN13(code)) return null;
    const first = Number(code[0]);
    let bits = "101";
    for (let i = 1; i <= 6; i++) bits += (PAR[first][i - 1] === "L" ? L : G)[Number(code[i])];
    bits += "01010";
    for (let i = 7; i <= 12; i++) bits += R[Number(code[i])];
    return bits + "101";
  };

  Core.nextInternalBarcode = (items) => {
    let max = 0;
    for (const it of items) {
      if (/^200\d{10}$/.test(it.barcode)) max = Math.max(max, Number(it.barcode.slice(3, 12)));
    }
    const d12 = "200" + String(max + 1).padStart(9, "0");
    return d12 + Core.checkDigit(d12);
  };

  // Finds an item, tolerating UPC-A vs EAN-13 leading-zero differences.
  Core.findItem = (state, code) => {
    code = (code || "").trim();
    if (!code) return null;
    const variants = [code, "0" + code, code.replace(/^0/, "")];
    for (const v of variants) {
      const it = state.items.find((i) => i.barcode === v);
      if (it) return it;
    }
    return null;
  };

  const amountOf = (value, kind, base) => (kind === "amt" ? value : base * value);
  const defaultCashUnit = (it, pay) => Math.min(pay === "Cash" ? amountOf(it.cash_disc, kindOf(it, "cash_disc_type"), it.selling_price) : 0, it.selling_price);
  const defaultBulkUnit = (it, q) => (q >= it.bulk_min ? amountOf(it.bulk_disc, kindOf(it, "bulk_disc_type"), it.selling_price) : 0);
  const fmtMoney = (v) => (v < 0 ? "-$" : "$") + Math.abs(v).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  // round half to even, like the laptop app, so both apps split amounts identically
  const rhe = (x) => { const f = Math.floor(x), d = x - f; if (d > 0.5) return f + 1; if (d < 0.5) return f; return f % 2 === 0 ? f : f + 1; };

  Core.calcSale = (item, qty, payment) => {
    const cost = item.purchase_price, list = item.selling_price;
    const cash = defaultCashUnit(item, payment), bulk = Math.min(defaultBulkUnit(item, qty), list - cash);
    const net = list - cash - bulk, commission = amountOf(item.commission, kindOf(item, "commission_type"), net), profit = net - commission - cost;
    const unit = { cost, list, cash, bulk, net, commission, profit };
    const total = {};
    for (const k in unit) total[k] = unit[k] * qty;
    return { unit, total, margin: net ? profit / net : 0, cashApplied: payment === "Cash", bulkApplied: qty >= item.bulk_min };
  };

  const normOverride = (ov) => {
    if (ov == null) return null;
    const val = Number(ov[0]), kind = ov[1];
    if (!(val >= 0)) throw new Error("Discounts and commission can't be negative.");
    if (kind !== "pct" && kind !== "amt") throw new Error("Choose % or $ for the manual discount / commission.");
    if (kind === "pct" && val > 100) throw new Error("A percentage can't be more than 100.");
    return [val, kind];
  };
  const normPrice = (ov) => {
    if (ov == null) return null;
    const val = Number(ov[0]), kind = ov[1];
    if (kind !== "unit" && kind !== "total") throw new Error("Choose '$ per unit' or '$ for the whole sale' for the selling price.");
    if (!(val > 0)) throw new Error("The selling price must be more than 0. Leave the box empty to use each item's own price.");
    return [val, kind];
  };
  // Split `total` dollars across lines in proportion to `weights`, in whole cents (the last line takes the remainder).
  const allocate = (total, weights) => {
    const n = weights.length; let sw = weights.reduce((a, b) => a + b, 0), w = weights;
    if (sw <= 0) { w = weights.map(() => 1); sw = n; }
    const totalC = rhe(total * 100); let used = 0; const out = [];
    w.forEach((x, i) => { const cents = i === n - 1 ? totalC - used : rhe((totalC * x) / sw); out.push(cents / 100); used += cents; });
    return out;
  };
  const sum = (a) => a.reduce((x, y) => x + y, 0);

  // Sale-level calculation. entries = [[item, qty]]. overrides: {price:[v,'unit'|'total'], cash/bulk/commission:[v,'pct'|'amt']}
  // (null = the item's own setting; 'amt' = a TOTAL for the whole sale shared between the lines). The selling price is what the
  // customer pays: the difference from the imported price is recorded as CASH discount and no other discount is added on top.
  Core.calcLines = (entries, payment, overrides) => {
    const o = overrides || {}, ov = { cash: normOverride(o.cash), bulk: normOverride(o.bulk), commission: normOverride(o.commission) }, price = normPrice(o.price);
    const n = entries.length, gross = entries.map(([it, q]) => it.selling_price * q);
    let cash, bulk;
    if (price) {
      if (ov.cash || ov.bulk) throw new Error("The selling price you typed already sets the discount. Empty the Cash discount and Bulk discount boxes.");
      if (price[1] === "unit") {
        for (const [it] of entries) if (price[0] > it.selling_price + 1e-9) throw new Error("The selling price (" + fmtMoney(price[0]) + ") is higher than the price of " + it.name + " (" + fmtMoney(it.selling_price) + ").");
        cash = entries.map(([it, q]) => (it.selling_price - price[0]) * q);
      } else {
        const grs = gross.map(r2), totalGross = r2(sum(grs));
        if (price[0] > totalGross + 1e-9) throw new Error("The selling price (" + fmtMoney(price[0]) + ") is higher than the value of the sale (" + fmtMoney(totalGross) + ").");
        cash = allocate(r2(totalGross - price[0]), grs);
      }
      cash = cash.map((x, i) => Math.min(x, gross[i])); bulk = new Array(n).fill(0);
    } else {
      if (!ov.cash) cash = entries.map(([it, q]) => defaultCashUnit(it, payment) * q);
      else if (ov.cash[1] === "pct") cash = gross.map((g) => (g * ov.cash[0]) / 100);
      else {
        if (ov.cash[0] > sum(gross) + 1e-9) throw new Error("The cash discount (" + fmtMoney(ov.cash[0]) + ") is more than the value of the sale (" + fmtMoney(sum(gross)) + ").");
        cash = allocate(ov.cash[0], gross);
      }
      cash = cash.map((x, i) => Math.min(x, gross[i]));
      const room = gross.map((g, i) => g - cash[i]);
      if (!ov.bulk) bulk = entries.map(([it, q]) => defaultBulkUnit(it, q) * q);
      else if (ov.bulk[1] === "pct") bulk = gross.map((g) => (g * ov.bulk[0]) / 100);
      else {
        if (ov.bulk[0] > sum(room) + 1e-9) throw new Error("The bulk discount (" + fmtMoney(ov.bulk[0]) + ") is more than what is left of the sale after the cash discount (" + fmtMoney(sum(room)) + ").");
        bulk = allocate(ov.bulk[0], room);
      }
      bulk = bulk.map((x, i) => Math.min(x, room[i]));
    }
    const net = gross.map((g, i) => g - cash[i] - bulk[i]);
    let comm;
    if (!ov.commission) comm = entries.map(([it, q], i) => amountOf(it.commission, kindOf(it, "commission_type"), q ? net[i] / q : 0) * q);
    else if (ov.commission[1] === "pct") comm = net.map((x) => (x * ov.commission[0]) / 100);
    else comm = allocate(ov.commission[0], net);
    return entries.map(([it, q], i) => { const cogs = it.purchase_price * q; return { gross: gross[i], cash: cash[i], bulk: bulk[i], net: net[i], commission: comm[i], cogs, profit: net[i] - comm[i] - cogs }; });
  };

  // Reads the boxes on the Sales screen ({price:{v,k}, ...}) into overrides; throws a clear message for bad input.
  Core.parseOverrides = (ov) => {
    ov = ov || Core.newOv(); const out = {};
    const ps = String((ov.price || {}).v == null ? "" : ov.price.v).trim().replace(/,/g, "");
    if (!ps) out.price = null;
    else {
      if (ps.endsWith("%")) throw new Error("Selling price: please type an amount in dollars, not a percentage.");
      const pv = Number(ps.replace(/^\$/, "").trim());
      if (!isFinite(pv) || ps.replace(/^\$/, "").trim() === "") throw new Error("Selling price: please type a number (for example 9.50).");
      if (pv <= 0) throw new Error("Selling price must be more than 0. Leave it empty to use the item's own price.");
      out.price = [pv, ov.price.k === "total" ? "total" : "unit"];
    }
    const names = { cash: "Cash discount", bulk: "Bulk discount", commission: "Commission to sales agent" };
    for (const k in names) {
      let s = String((ov[k] || {}).v == null ? "" : ov[k].v).trim().replace(/,/g, "");
      if (!s) { out[k] = null; continue; }
      let kind = ov[k].k === "amt" ? "amt" : "pct";
      if (s.endsWith("%")) { kind = "pct"; s = s.slice(0, -1).trim(); } else if (s.startsWith("$")) { kind = "amt"; s = s.slice(1).trim(); }
      const val = s === "" ? NaN : Number(s);
      if (!isFinite(val)) throw new Error(names[k] + ": please type a number (for example 5 or 10%).");
      if (val < 0) throw new Error(names[k] + " can't be negative.");
      if (kind === "pct" && val > 100) throw new Error(names[k] + " can't be more than 100%.");
      out[k] = [val, kind];
    }
    return out;
  };

  // ---------- agents: remembered the first time a name is used ----------
  Core.agentNames = (state) => {
    const seen = {};
    const add = (n) => { n = (n || "").trim(); if (n && !seen[n.toLowerCase()]) seen[n.toLowerCase()] = n; };
    (state.agents || []).forEach(add); state.invoices.forEach((i) => add(i.agent)); state.log.forEach((e) => add(e.agent));
    return Object.values(seen).sort((a, b) => a.toLowerCase().localeCompare(b.toLowerCase()));
  };
  Core.canonicalAgent = (state, name) => { name = (name || "").trim(); const f = Core.agentNames(state).find((a) => a.toLowerCase() === name.toLowerCase()); return f || name; };
  Core.rememberAgent = (state, name) => { name = (name || "").trim(); if (name && !(state.agents || []).some((a) => a.toLowerCase() === name.toLowerCase())) (state.agents = state.agents || []).push(name); };

  Core.onHand = (state, barcode) =>
    state.log.reduce((s, e) => (e.barcode === barcode ? s + (e.type === "IN" ? e.qty : -e.qty) : s), 0);

  Core.stockRows = (state, search) => {
    const words = (search || "").trim().toLowerCase().split(/\s+/).filter(Boolean);
    const inMap = {}, outMap = {};
    for (const e of state.log) (e.type === "IN" ? inMap : outMap)[e.barcode] = ((e.type === "IN" ? inMap : outMap)[e.barcode] || 0) + e.qty;
    return state.items
      .filter((i) => words.every((w) => [i.name, i.sku, i.barcode, i.category, i.supplier].some((v) => String(v == null ? "" : v).toLowerCase().includes(w))))
      .map((i) => {
        const qty_in = inMap[i.barcode] || 0, qty_out = outMap[i.barcode] || 0, on_hand = qty_in - qty_out;
        const status = on_hand <= 0 ? "Out of Stock" : on_hand <= i.reorder_level ? "Reorder" : "OK";
        return Object.assign({}, i, { qty_in, qty_out, on_hand, value: on_hand * i.purchase_price, status });
      })
      .sort((a, b) => a.sku.localeCompare(b.sku));
  };

  Core.searchItems = (state, query) => Core.stockRows(state, query);

  Core.totals = (state) => {
    const rows = Core.stockRows(state, "");
    const t = { skus: rows.length, units: 0, stock_value: 0, reorder: 0, out: 0, gross: 0, cash: 0, bulk: 0, net: 0, commission: 0, cogs: 0, profit: 0 };
    for (const r of rows) {
      t.units += r.on_hand; t.stock_value += r.value;
      if (r.status === "Reorder") t.reorder++;
      if (r.status === "Out of Stock") t.out++;
    }
    for (const e of state.log) {
      if (e.type !== "OUT") continue;
      t.gross += e.gross; t.cash += e.cash_disc; t.bulk += e.bulk_disc; t.net += e.net;
      t.commission += e.commission; t.cogs += e.cogs; t.profit += e.profit;
    }
    t.margin = t.net ? t.profit / t.net : 0;
    return t;
  };

  Core.saveItem = (state, data, id) => {
    const d = {};
    for (const k of ITEM_TEXT) d[k] = String(data[k] == null ? "" : data[k]).trim();
    for (const k of ITEM_NUM) {
      const v = Number(data[k] == null || data[k] === "" ? (k === "bulk_min" ? 1 : 0) : data[k]);
      if (!isFinite(v) || v < 0) throw new Error("Please enter valid, non-negative numbers.");
      d[k] = v;
    }
    if (!d.sku || !d.barcode || !d.name) throw new Error("SKU, Barcode and Item name are required.");
    const clash = state.items.find((i) => i.id !== id && (i.sku === d.sku || i.barcode === d.barcode));
    if (clash) throw new Error("That SKU or barcode already exists.");
    const prev = id == null ? null : state.items.find((i) => i.id === id);
    for (const t of Object.values(TYPE_FIELDS)) {
      let v = data[t]; if (v == null || v === "") v = prev && prev[t] ? prev[t] : "pct";
      if (v !== "pct" && v !== "amt") throw new Error("Discount and commission type must be % or fixed amount.");
      d[t] = v;
    }
    if (id == null) {
      d.id = state.nextId++;
      state.items.push(d);
      return d;
    }
    const old = state.items.find((i) => i.id === id);
    if (!old) throw new Error("Item not found.");
    if (old.barcode !== d.barcode) for (const e of state.log) if (e.barcode === old.barcode) e.barcode = d.barcode;
    Object.assign(old, d);
    return old;
  };

  Core.deleteItem = (state, id) => {
    const it = state.items.find((i) => i.id === id);
    if (!it) return;
    const n = state.log.filter((e) => e.barcode === it.barcode).length;
    if (n) throw new Error("This item has " + n + " stock-log entries, so it can't be deleted.");
    state.items = state.items.filter((i) => i.id !== id);
  };

  Core.record = (state, e) => {
    const item = Core.findItem(state, e.barcode);
    if (!item) throw new Error("Barcode not found in inventory.");
    if (e.type !== "IN" && e.type !== "OUT") throw new Error("Type must be IN or OUT.");
    const qty = Number(e.qty);
    if (!isFinite(qty) || qty <= 0) throw new Error("Quantity must be greater than zero.");
    const agent = Core.canonicalAgent(state, e.agent);
    const entry = { id: state.nextId++, date: e.date, barcode: item.barcode, type: e.type,
      payment: e.type === "OUT" ? e.payment : "", agent, note: e.note || "", qty, invoice_id: e.invoice_id || null,
      gross: 0, cash_disc: 0, bulk_disc: 0, net: 0, commission: 0, cogs: 0, profit: 0 };
    if (e.type === "OUT") {
      if (e.vals) Object.assign(entry, e.vals);   // already worked out (manual price / discount / commission)
      else {
        const t = Core.calcSale(item, qty, e.payment).total;
        Object.assign(entry, { gross: t.list, cash_disc: t.cash, bulk_disc: t.bulk, net: t.net, commission: t.commission, cogs: t.cost, profit: t.profit });
      }
    }
    Core.rememberAgent(state, agent);
    state.log.push(entry);
    return entry;
  };

  // ---------- invoices (multi-item sales) ----------
  Core.priceLines = (state, lines, payment, taxRate, overrides) => {
    const items = [];
    for (const l of lines) {
      const item = Core.findItem(state, l.barcode); if (!item) throw new Error("Barcode not found: " + l.barcode);
      const qty = Number(l.qty); if (!(qty > 0)) throw new Error("Quantity must be greater than zero for " + item.name + ".");
      items.push([item, qty]);
    }
    const calc = Core.calcLines(items, payment, overrides);
    const out = []; let sub = 0, disc = 0, net = 0;
    items.forEach(([item, qty], i) => {
      const k = calc[i], gross = r2(k.gross), d = r2(k.cash + k.bulk), amount = r2(gross - d);
      out.push({ barcode: item.barcode, sku: item.sku, name: item.name, qty, unit: item.selling_price, gross, disc: d, amount, onHand: Core.onHand(state, item.barcode),
        raw: { gross: k.gross, cash_disc: k.cash, bulk_disc: k.bulk, net: k.net, commission: k.commission, cogs: k.cogs, profit: k.profit }, commission: k.commission });
      sub += gross; disc += d; net += amount;
    });
    sub = r2(sub); disc = r2(disc); net = r2(net);
    const tax = r2((net * (taxRate || 0)) / 100);
    return { lines: out, subtotal: sub, discounts: disc, net, tax, total: r2(net + tax), commission: sum(calc.map((k) => k.commission)) };
  };
  Core.invoiceNumber = (state) => "INV-" + String(state.settings.next_invoice).padStart(4, "0");

  Core.createInvoice = (state, d) => {
    if (!d.lines || !d.lines.length) throw new Error("Add at least one item to the sale.");
    if (d.payment !== "Cash" && d.payment !== "Credit") throw new Error("Payment must be Cash or Credit.");
    const taxRate = Number(state.settings.tax_rate) || 0, agent = Core.canonicalAgent(state, d.agent);
    const p = Core.priceLines(state, d.lines, d.payment, taxRate, d.overrides);
    const number = Core.invoiceNumber(state);
    const inv = { id: state.nextId++, number, date: d.date, customer: (d.customer || "").trim(), payment: d.payment, agent,
      note: (d.note || "").trim(), status: "ok", tax_rate: taxRate, lines: [], subtotal: p.subtotal, discounts: p.discounts, net: p.net, tax: p.tax, total: p.total };
    for (const l of p.lines) {
      const e = Core.record(state, { date: d.date, barcode: l.barcode, type: "OUT", payment: d.payment, agent, note: number, qty: l.qty, invoice_id: inv.id, vals: l.raw });
      inv.lines.push({ barcode: l.barcode, sku: l.sku, name: l.name, qty: l.qty, unit: l.unit, disc: l.disc, amount: l.amount, log_id: e.id, returned: 0 });
    }
    state.invoices.push(inv); state.settings.next_invoice = (Number(state.settings.next_invoice) || 1) + 1;
    return inv;
  };

  Core.voidInvoice = (state, id) => {
    const inv = state.invoices.find((i) => i.id === id); if (!inv) throw new Error("Invoice not found.");
    if (inv.status === "void") return inv;
    state.log = state.log.filter((e) => e.invoice_id !== id);          // also removes the return entries of this sale
    state.returns.forEach((r) => { if (r.invoice_id === id) r.status = "void"; });
    inv.status = "void"; return inv;
  };

  // ---------- sales returns ----------
  Core.returnedTotal = (state, invId) => r2(sum(state.returns.filter((r) => r.invoice_id === invId && r.status === "ok").map((r) => r.total)));
  Core.returnCandidates = (state, invId) => {
    const inv = state.invoices.find((i) => i.id === invId); if (!inv) return [];
    return inv.lines.map((l, idx) => ({ idx, sku: l.sku, name: l.name, sold: l.qty, returned: l.returned || 0, remaining: Math.round((l.qty - (l.returned || 0)) * 1e6) / 1e6, unit: l.unit, amount: l.amount }));
  };
  // lines: [[lineIndex, qty]]. Goods go back into stock; sales, commission and profit drop by exactly what the sale added.
  Core.createReturn = (state, invId, lines, reason, date) => {
    const inv = state.invoices.find((i) => i.id === invId);
    if (!inv || inv.status === "void") throw new Error("This invoice can't take a return (it is missing or void).");
    lines = lines.map(([i, q]) => [Number(i), Number(q)]).filter(([, q]) => q > 0);
    if (!lines.length) throw new Error("Enter a quantity to return for at least one item.");
    const number = "RET-" + String(state.settings.next_return || 1).padStart(4, "0");
    const ret = { id: state.nextId++, number, date: date || new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10), invoice_id: invId,
      reason: (reason || "").trim(), status: "ok", subtotal: 0, tax: 0, total: 0, lines: [] };
    const newLog = []; let netTotal = 0; const bump = [];
    for (const [idx, qty] of lines) {
      const l = inv.lines[idx]; if (!l) throw new Error("That item is not on this invoice.");
      const remaining = l.qty - (l.returned || 0);
      if (qty > remaining + 1e-9) throw new Error("You can return at most " + (Math.round(remaining * 1e6) / 1e6) + " of " + l.name + ".");
      const prev = state.returns.filter((r) => r.invoice_id === invId && r.status === "ok").flatMap((r) => r.lines).filter((x) => x.line_idx === idx);
      const prevAmt = sum(prev.map((x) => x.amount)), prevDisc = sum(prev.map((x) => x.disc));
      let amount, disc;
      if (Math.abs(qty - remaining) < 1e-9) { amount = r2(l.amount - prevAmt); disc = r2(l.disc - prevDisc); }
      else { amount = r2((l.amount * qty) / l.qty); disc = r2((l.disc * qty) / l.qty); }
      const o = state.log.find((e) => e.id === l.log_id); if (!o) throw new Error("The original sale entry for " + l.name + " is missing.");
      const k = qty / o.qty;
      const entry = { id: state.nextId++, date: ret.date, barcode: o.barcode, type: "OUT", payment: inv.payment, agent: inv.agent, note: "RETURN " + number + " of " + inv.number, qty: -qty,
        invoice_id: invId, gross: -o.gross * k, cash_disc: -o.cash_disc * k, bulk_disc: -o.bulk_disc * k, net: -o.net * k, commission: -o.commission * k, cogs: -o.cogs * k, profit: -o.profit * k };
      newLog.push(entry);
      ret.lines.push({ line_idx: idx, barcode: l.barcode, sku: l.sku, name: l.name, qty, unit: l.unit, disc, amount, log_id: entry.id });
      bump.push([l, qty]); netTotal += amount;
    }
    netTotal = r2(netTotal); ret.subtotal = netTotal; ret.tax = r2((netTotal * (inv.tax_rate || 0)) / 100); ret.total = r2(netTotal + ret.tax);
    state.log.push(...newLog); for (const [l, q] of bump) l.returned = (l.returned || 0) + q;
    state.returns.push(ret); state.settings.next_return = (Number(state.settings.next_return) || 1) + 1;
    return ret;
  };
  Core.voidReturn = (state, retId) => {
    const ret = state.returns.find((r) => r.id === retId); if (!ret) throw new Error("Return not found.");
    if (ret.status === "void") return ret;
    const inv = state.invoices.find((i) => i.id === ret.invoice_id), ids = new Set(ret.lines.map((l) => l.log_id));
    state.log = state.log.filter((e) => !ids.has(e.id));
    for (const l of ret.lines) { const il = inv && inv.lines[l.line_idx]; if (il) il.returned = Math.max(0, (il.returned || 0) - l.qty); }
    ret.status = "void"; return ret;
  };

  // Everything a PDF needs (customer-facing: no cost, commission or profit).
  Core.invoiceDoc = (state, inv) => ({
    title: inv.payment === "Cash" ? "RECEIPT" : "INVOICE", number: inv.number, date: inv.date, customer: inv.customer || "Walk-in customer",
    payment: inv.payment, agent: inv.agent, note: inv.note, status: inv.status, tax_rate: inv.tax_rate, lines: inv.lines,
    subtotal: inv.subtotal, discounts: inv.discounts, tax: inv.tax, total: inv.total,
    business: { name: state.settings.business, address: state.settings.address, phone: state.settings.phone, footer: state.settings.footer },
  });

  Core.returnDoc = (state, ret) => {
    const inv = state.invoices.find((i) => i.id === ret.invoice_id) || {}, disc = r2(sum(ret.lines.map((l) => l.disc)));
    return { title: "SALES RETURN", number: ret.number, date: ret.date, customer: inv.customer || "Walk-in customer", payment: inv.payment, agent: inv.agent, note: ret.reason,
      status: ret.status, tax_rate: inv.tax_rate || 0, lines: ret.lines, subtotal: r2(ret.subtotal + disc), discounts: disc, tax: ret.tax, total: ret.total,
      ref: "Original invoice: " + (inv.number || ""), total_label: "REFUND TOTAL", banner: "REFUND: " + fmtMoney(ret.total), banner_kind: "refund",
      business: { name: state.settings.business, address: state.settings.address, phone: state.settings.phone, footer: state.settings.footer } };
  };

  Core.deleteLog = (state, id) => { state.log = state.log.filter((e) => e.id !== id); };

  // ---------- CSV ----------
  Core.parseCSV = (text, delim) => {
    text = text.replace(/^\uFEFF/, "");
    if (!delim) { const first = text.split(/\r?\n/)[0] || ""; const sc = (first.match(/;/g) || []).length, tc = (first.match(/\t/g) || []).length, cc = (first.match(/,/g) || []).length; delim = sc > cc ? ";" : tc > cc ? "\t" : ","; }
    const rows = []; let row = [], cell = "", q = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (q) {
        if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c;
      } else if (c === '"') q = true;
      else if (c === delim) { row.push(cell); cell = ""; }
      else if (c === "\n" || c === "\r") {
        if (c === "\r" && text[i + 1] === "\n") i++;
        row.push(cell); cell = ""; rows.push(row); row = [];
      } else cell += c;
    }
    if (cell !== "" || row.length) { row.push(cell); rows.push(row); }
    return rows.filter((r) => r.some((x) => x !== ""));
  };
  Core.toCSV = (rows) =>
    "\uFEFF" + rows.map((r) => r.map((v) => { v = v == null ? "" : String(v); return /[",\n\r]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }).join(",")).join("\r\n");

  // Imports CSV files exported by the desktop app (inventory or stock-log).
  Core.importCSV = (state, text) => {
    const rows = Core.parseCSV(text);
    if (rows.length < 2) throw new Error("The file is empty.");
    const head = rows[0].map((h) => h.trim().toLowerCase());
    const get = (r, k) => (r[head.indexOf(k)] || "").trim();
    const n = (r, k, d) => { const v = parseFloat(get(r, k)); return isFinite(v) ? v : d; };
    let added = 0, updated = 0, skipped = 0;
    if (head.includes("purchase_price") && head.includes("barcode")) {
      for (const r of rows.slice(1)) {
        const data = { sku: get(r, "sku"), barcode: get(r, "barcode"), name: get(r, "name"), category: get(r, "category"),
          supplier: get(r, "supplier"), location: get(r, "location"), purchase_price: n(r, "purchase_price", 0),
          selling_price: n(r, "selling_price", 0), cash_disc: n(r, "cash_disc", 0), bulk_disc: n(r, "bulk_disc", 0),
          bulk_min: n(r, "bulk_min", 1), commission: n(r, "commission", 0), reorder_level: n(r, "reorder_level", 0), reorder_qty: n(r, "reorder_qty", 0) };
        for (const t of Object.values(TYPE_FIELDS)) if (head.includes(t)) data[t] = get(r, t) === "amt" ? "amt" : "pct";
        const ex = state.items.find((i) => i.barcode === data.barcode);
        try { Core.saveItem(state, data, ex ? ex.id : null); ex ? updated++ : added++; } catch (e) { skipped++; }
      }
      return { kind: "inventory", added, updated, skipped };
    }
    if (head.includes("type") && head.includes("qty") && head.includes("date") && head.includes("barcode")) {
      for (const r of rows.slice(1)) {
        const item = Core.findItem(state, get(r, "barcode")), type = get(r, "type").toUpperCase(), qty = n(r, "qty", 0);
        if (!item || (type !== "IN" && type !== "OUT") || qty <= 0) { skipped++; continue; }
        state.log.push({ id: state.nextId++, date: get(r, "date").slice(0, 10), barcode: item.barcode, type, payment: get(r, "payment"),
          agent: get(r, "agent"), note: get(r, "note"), qty, gross: n(r, "gross", 0), cash_disc: n(r, "cash_disc", 0),
          bulk_disc: n(r, "bulk_disc", 0), net: n(r, "net", 0), commission: n(r, "commission", 0), cogs: n(r, "cogs", 0), profit: n(r, "profit", 0) });
        added++;
      }
      return { kind: "log", added, updated: 0, skipped };
    }
    return Core.importItemsTable(state, rows);
  };

  // ---------- tolerant item-list import (any CSV with an item name column) ----------
  const ALIASES = {
    sku: ["sku", "itemcode", "code", "itemno", "itemnumber", "productcode", "partno", "partnumber"],
    barcode: ["barcode", "barcodeean13", "ean", "ean13", "upc", "gtin", "barcodenumber"],
    name: ["itemname", "name", "description", "item", "product", "productname", "itemdescription"],
    category: ["category", "group", "itemcategory", "department"],
    supplier: ["supplier", "vendor", "suppliername"],
    location: ["location", "bin", "shelf", "warehouse"],
    purchase_price: ["purchaseprice", "purchase", "cost", "costprice", "unitcost", "buyprice", "buyingprice"],
    selling_price: ["sellingprice", "selling", "price", "saleprice", "retailprice", "unitprice", "sellprice"],
    cash_disc: ["cashdiscount", "cashdisc", "cashdiscountpct", "cashdiscountpercent"],
    bulk_disc: ["bulkdiscount", "bulkdisc", "bulkdiscountpct", "bulkdiscountpercent"],
    bulk_min: ["bulkminqty", "bulkminquantity", "bulkmin", "bulkqty"],
    commission: ["agentcommission", "commission", "commissionrate", "agentcommissionpct"],
    reorder_level: ["reorderlevel", "reorderpoint", "minstock", "minqty", "minimumstock"],
    reorder_qty: ["reorderqty", "reorderquantity", "orderqty"],
    cash_disc_type: ["cashdiscounttype", "cashdisctype"], bulk_disc_type: ["bulkdiscounttype", "bulkdisctype"], commission_type: ["commissiontype", "agentcommissiontype"],
  };
  const kindFrom = (v) => (["amt", "amount", "fixed", "fixed amount", "$", "value"].includes(String(v == null ? "" : v).trim().toLowerCase()) ? "amt" : "pct");
  const norm = (h) => String(h == null ? "" : h).toLowerCase().replace(/[^a-z0-9]/g, "");
  const dec = (s) => String(s == null ? "" : s).trim().replace(/^(\d+),(\d{1,2})$/, "$1.$2");
  const num = (v, d) => { const x = parseFloat(dec(v).replace(/[$,]/g, "")); return isFinite(x) ? x : d; };
  const pctv = (v) => { const s = String(v == null ? "" : v).trim(); if (!s) return 0; if (s.endsWith("%")) { const x = parseFloat(s.slice(0, -1)); return isFinite(x) ? x / 100 : 0; } const x = parseFloat(dec(s).replace(/,/g, "")); if (!isFinite(x)) return 0; return x >= 1 ? x / 100 : x; };

  Core.importItemsTable = (state, rows) => {
    const head = rows[0].map(norm), lookup = {};
    for (const f in ALIASES) { const i = head.findIndex((h) => ALIASES[f].includes(h)); if (i >= 0) lookup[f] = i; }
    if (lookup.name == null) throw new Error("Couldn't find an item name column. Use a heading such as Item Name, Name or Description.");
    const get = (r, f) => (lookup[f] == null ? "" : (r[lookup[f]] || "").trim());
    let added = 0, updated = 0, skipped = 0, auto = 0;
    for (const r of rows.slice(1)) {
      const name = get(r, "name"); if (!name) continue;
      let sku = get(r, "sku"), bc = get(r, "barcode");
      let ex = bc ? state.items.find((i) => i.barcode === bc) : null;
      if (!ex && sku) ex = state.items.find((i) => i.sku === sku) || null;
      if (!bc) { if (ex) bc = ex.barcode; else { bc = Core.nextInternalBarcode(state.items); auto++; } }
      if (!sku) { if (ex) sku = ex.sku; else { let n = state.items.length + 1; while (state.items.some((i) => i.sku === "ITEM-" + String(n).padStart(4, "0"))) n++; sku = "ITEM-" + String(n).padStart(4, "0"); } }
      const kinds = {};
      for (const t of Object.values(TYPE_FIELDS)) kinds[t] = lookup[t] != null ? kindFrom(get(r, t)) : (ex && ex[t]) || "pct";
      const rate = (f) => (kinds[TYPE_FIELDS[f]] === "pct" ? pctv(get(r, f)) : num(get(r, f), 0));
      const data = { sku, barcode: bc, name, category: get(r, "category"), supplier: get(r, "supplier"), location: get(r, "location"),
        purchase_price: num(get(r, "purchase_price"), 0), selling_price: num(get(r, "selling_price"), 0), cash_disc: rate("cash_disc"),
        bulk_disc: rate("bulk_disc"), bulk_min: num(get(r, "bulk_min"), 1) || 1, commission: rate("commission"),
        reorder_level: num(get(r, "reorder_level"), 0), reorder_qty: num(get(r, "reorder_qty"), 0), ...kinds };
      try { Core.saveItem(state, data, ex ? ex.id : null); ex ? updated++ : added++; } catch (e) { skipped++; }
    }
    return { kind: "inventory", added, updated, skipped, auto };
  };

  root.Core = Core;
  if (typeof module !== "undefined" && module.exports) module.exports = Core;
})(typeof window !== "undefined" ? window : globalThis);
