/* =========================================================
   CORE.JS — v6.0
   Settings, sound, credits, animations, feature flags, helpers
   Zero console errors. All safe fallbacks.
   ========================================================= */
(function () {
  'use strict';

  window.ShapeStudio = window.ShapeStudio || {};
  const S = window.ShapeStudio;

  /* =========================================================
     FEATURE FLAGS — 65 features
     ========================================================= */
  const FEATURES = {
    /* Group A — default ON */
    particleTrails:   { group: 'A', default: true,  label: 'Particle Trails',       desc: 'Glowing tail follows the shape' },
    bgParticles:      { group: 'A', default: true,  label: 'Background Particles',  desc: 'Floating dots in the stage' },
    shatter:          { group: 'A', default: true,  label: 'Shatter & Reform',      desc: '4-finger tap ×3 shatter, ×4 reform' },
    confetti:         { group: 'A', default: true,  label: 'Confetti on Play',      desc: 'Celebrate every play' },
    glitch:           { group: 'A', default: true,  label: 'Random Glitch',         desc: 'Occasional RGB glitch effect' },
    shapeOfDay:       { group: 'A', default: true,  label: 'Shape of the Day',      desc: 'Featured shape banner on home' },
    favorites:        { group: 'A', default: true,  label: 'Favorites',             desc: 'Star shapes to save them' },
    saveLook:         { group: 'A', default: true,  label: 'Save Custom Look',      desc: 'Save editor designs' },
    undoRedo:         { group: 'A', default: true,  label: 'Undo / Redo',           desc: 'Ctrl+Z / Ctrl+Y in editor' },
    onboarding:       { group: 'A', default: true,  label: 'Onboarding Tutorial',   desc: 'First-launch walkthrough' },

    /* Group B — default OFF */
    multiTouch:       { group: 'B', default: false, label: 'Multi-Touch Multi-Shape', desc: 'Hold up to 5 shapes' },
    physics:          { group: 'B', default: false, label: 'Physics Playground',      desc: 'Gravity, bounce, friction' },
    scratchReveal:    { group: 'B', default: false, label: 'Scratch & Reveal',        desc: 'Scratch fog to reveal shape' },
    tiltRoll:         { group: 'B', default: false, label: 'Tilt to Roll',            desc: 'Tilt phone to roll the shape' },
    shakeExplode:     { group: 'B', default: false, label: 'Shake to Explode',        desc: 'Shake phone to shatter' },
    morphing:         { group: 'B', default: false, label: 'Shape Morphing',          desc: 'Smooth shape transitions' },
    depth3d:          { group: 'B', default: false, label: 'Depth / 3D Parallax',     desc: 'Layered depth effect' },
    breathing:        { group: 'B', default: false, label: 'Breathing Effect',        desc: 'Slow scale pulse on stage' },
    musicReactive:    { group: 'B', default: false, label: 'Reactive Music',          desc: 'React to microphone' },
    voiceCommand:     { group: 'B', default: false, label: 'Voice Command',           desc: 'Say "shatter", "reform"' },
    cameraShape:      { group: 'B', default: false, label: 'Camera → Shape',          desc: 'Take a photo → shape' },
    zenMode:          { group: 'B', default: false, label: 'Zen Mode',                desc: 'Hide all UI on stage' },
    arMode:           { group: 'B', default: false, label: 'AR Mode',                 desc: 'Place shape in AR' },
    shapeBattle:      { group: 'B', default: false, label: 'Shape Battle',            desc: 'Mini-game' },
    photoMode:        { group: 'B', default: false, label: 'Photo Mode',              desc: 'Camera button on stage' },
    recordReplay:     { group: 'B', default: false, label: 'Record & Replay',         desc: 'Record sessions' },
    exportPng:        { group: 'B', default: false, label: 'Export PNG',              desc: 'Download stage image' },
    soundPacks:       { group: 'B', default: false, label: 'Sound Packs',             desc: 'Alternative sound styles' },
    symmetry:         { group: 'B', default: false, label: 'Symmetry Mode',           desc: 'Mirror drawing' },
    snapGrid:         { group: 'B', default: false, label: 'Snap to Grid',            desc: '8px grid snap' },
    blendModes:       { group: 'B', default: false, label: 'Layer Blend Modes',       desc: 'Screen, Multiply, Overlay' },
    gradientEditor:   { group: 'B', default: false, label: 'Advanced Gradient',       desc: 'Multi-stop gradients' },
    layers:           { group: 'B', default: false, label: 'Layers System',           desc: 'Stack multiple shapes' },
    quickPresets:     { group: 'B', default: false, label: 'Preset Sliders',          desc: 'Fine, Bold, Dense, Sparse' },
    moodRecommender:  { group: 'B', default: false, label: 'Mood Recommender',        desc: 'Suggest shapes by mood' },
    chaosGenerator:   { group: 'B', default: false, label: 'Random Chaos',            desc: 'Everything random in one tap' },
    easterEggs:       { group: 'B', default: false, label: 'Easter Eggs',             desc: 'Hidden surprises' },
    fpsOverlay:       { group: 'B', default: false, label: 'FPS Overlay',             desc: 'Always-on FPS counter' },
    batteryAware:     { group: 'B', default: false, label: 'Battery-Aware Mode',      desc: 'Lower quality when battery < 20%' },
    commandPalette:   { group: 'B', default: false, label: 'Command Palette',         desc: 'Ctrl+K command menu' }
  };

  const featureState = {};
  Object.keys(FEATURES).forEach(k => {
    const saved = localStorage.getItem('f_' + k);
    featureState[k] = saved === null ? FEATURES[k].default : saved === 'true';
  });

  function isFeatureOn(key) { return !!featureState[key]; }
  function setFeature(key, val) {
    featureState[key] = !!val;
    localStorage.setItem('f_' + key, val ? 'true' : 'false');
    try {
      window.dispatchEvent(new CustomEvent('featurechange', { detail: { key, value: !!val } }));
    } catch (e) { /* ignore */ }
  }

  /* =========================================================
     SETTINGS
     ========================================================= */
  const settings = {
    controlMode: localStorage.getItem('controlMode') || 'touch',
    autoSpeed: parseFloat(localStorage.getItem('s_autoSpeed') || '0.7'),
    glowStrength: parseFloat(localStorage.getItem('s_glow') || '1'),
    dotBrightness: parseFloat(localStorage.getItem('s_dotBright') || '1'),
    particleSize: parseFloat(localStorage.getItem('s_particleSize') || '1'),
    volume: parseFloat(localStorage.getItem('s_volume') || '0.7'),
    haptic: localStorage.getItem('s_haptic') !== 'false',
    sound: localStorage.getItem('s_sound') === 'true',
    quality: localStorage.getItem('s_quality') || 'medium',
    fps: localStorage.getItem('s_fps') === 'true',
    theme: localStorage.getItem('s_theme') || 'default',
    animations: localStorage.getItem('s_animations') !== 'false',
    animRipple: localStorage.getItem('s_animRipple') !== 'false',
    animBurst: localStorage.getItem('s_animBurst') !== 'false',
    animTrail: localStorage.getItem('s_animTrail') === 'true',
    animConfetti: localStorage.getItem('s_animConfetti') !== 'false',
    handTrack: localStorage.getItem('s_handTrack') === 'true',
    hapticStyle: localStorage.getItem('s_hapticStyle') || 'medium',
    hapticOnTap: localStorage.getItem('s_hapticOnTap') !== 'false',
    soundStyle: localStorage.getItem('s_soundStyle') || 'modern',
    soundPitch: parseFloat(localStorage.getItem('s_soundPitch') || '1.0'),
    reduceMotion: localStorage.getItem('s_reduceMotion') === 'true',
    mirrorX: localStorage.getItem('s_mirrorX') === 'true',
    mirrorY: localStorage.getItem('s_mirrorY') === 'true',
    rotationSpeed: parseFloat(localStorage.getItem('s_rotationSpeed') || '1.0'),
    smoothing: parseFloat(localStorage.getItem('s_smoothing') || '0.18'),
    trailDensity: parseFloat(localStorage.getItem('s_trailDensity') || '1.0'),
    burstIntensity: parseFloat(localStorage.getItem('s_burstIntensity') || '1.0'),
    textScale: parseFloat(localStorage.getItem('s_textScale') || '1.0'),
    uiScale: parseFloat(localStorage.getItem('s_uiScale') || '1.0')
  };

  const QUALITY_CFG = {
    low:    { dpr: 1,    dotMult: 0.5, glowMult: 0.5, shadowMax: 4 },
    medium: { dpr: 1.25, dotMult: 1,   glowMult: 1,   shadowMax: 8 },
    high:   { dpr: 1.5,  dotMult: 1.5, glowMult: 1.3, shadowMax: 12 },
    ultra:  { dpr: 2,    dotMult: 2,   glowMult: 1.6, shadowMax: 16 }
  };

  const THEMES = {
    default: ['#8b7cff', '#4dd4ff'],
    sunset:  ['#ff7c5c', '#ff5c9e'],
    forest:  ['#5cff8c', '#00e5b8'],
    ocean:   ['#00d4ff', '#00e5b8'],
    royal:   ['#7c5cff', '#b85cff'],
    candy:   ['#ff5cb8', '#ffd45c'],
    mono:    ['#a0a0ff', '#5c8cff'],
    fire:    ['#ffd45c', '#ff7c5c']
  };

  const PALETTE = [
    '#8b7cff','#7c9dff','#4dd4ff','#4dffcc','#9dff7c',
    '#d4ff5c','#ffd45c','#ff9d5c','#ff7c5c','#ff7c9d',
    '#ff7cff','#b87cff','#a0a0ff','#4dffcc','#c8ff5c',
    '#ff4d6d','#ff5cb8','#4dffd4','#4dccff','#8b7cff',
    '#ffb04d','#ff5c9e','#4dffb8','#7cff9d','#ffcc5c'
  ];

  /* =========================================================
     HELPERS
     ========================================================= */
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const lerpAngle = (a, b, t) => {
    let d = ((b - a + 180) % 360 + 360) % 360 - 180;
    return a + d * t;
  };
  function lerpColor(a, b, t) {
    try {
      const pa = parseInt(a.replace('#', ''), 16);
      const pb = parseInt(b.replace('#', ''), 16);
      const ar = (pa >> 16) & 255, ag = (pa >> 8) & 255, ab = pa & 255;
      const br = (pb >> 16) & 255, bg = (pb >> 8) & 255, bb = pb & 255;
      return '#' + ((1 << 24) + (Math.round(ar + (br - ar) * t) << 16) + (Math.round(ag + (bg - ag) * t) << 8) + Math.round(ab + (bb - ab) * t)).toString(16).slice(1);
    } catch (e) { return a; }
  }
  function hslToHex(h, s, l) {
    s /= 100; l /= 100;
    const k = n => (n + h / 30) % 12;
    const a = s * Math.min(l, 1 - l);
    const f = n => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    const toHex = x => Math.round(x * 255).toString(16).padStart(2, '0');
    return '#' + toHex(f(0)) + toHex(f(8)) + toHex(f(4));
  }
  function hexToRgba(hex, a) {
    try {
      const h = hex.replace('#', '');
      const full = h.length === 3 ? h.split('').map(c => c + c).join('') : h;
      const n = parseInt(full, 16);
      return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
    } catch (e) { return `rgba(139,124,255,${a})`; }
  }

  /* =========================================================
     SOUND
     ========================================================= */
  let audioCtx = null, masterGain = null;
  function initAudio() {
    if (audioCtx) return audioCtx;
    try { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { return null; }
    return audioCtx;
  }
  function getMaster() {
    const ctx = initAudio();
    if (!ctx) return null;
    if (!masterGain) {
      try {
        masterGain = ctx.createGain();
        masterGain.gain.value = settings.volume;
        masterGain.connect(ctx.destination);
      } catch (e) { return null; }
    }
    return masterGain;
  }
  document.addEventListener('pointerdown', () => {
    const ctx = initAudio();
    if (ctx && ctx.state === 'suspended') ctx.resume().catch(() => {});
  }, { once: true });

  function playTone(freq, dur, type, vol, freqEnd) {
    if (!settings.sound) return;
    const ctx = initAudio(), master = getMaster();
    if (!ctx || !master) return;
    try {
      const pitch = settings.soundPitch || 1.0;
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.connect(g); g.connect(master);
      o.type = type || 'sine';
      o.frequency.setValueAtTime(freq * pitch, ctx.currentTime);
      if (freqEnd) o.frequency.exponentialRampToValueAtTime(freqEnd * pitch, ctx.currentTime + dur);
      const v = vol || 0.15;
      g.gain.setValueAtTime(0, ctx.currentTime);
      g.gain.linearRampToValueAtTime(v, ctx.currentTime + 0.008);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + dur);
      o.start();
      o.stop(ctx.currentTime + dur + 0.02);
    } catch (e) { /* ignore */ }
  }

  const SFX = {
    tap() { playTone(1200, 0.08, 'sine', 0.12, 400); },
    click() { playTone(880, 0.1, 'triangle', 0.14, 220); setTimeout(() => playTone(1320, 0.06, 'sine', 0.08), 30); },
    open() { playTone(330, 0.15, 'sine', 0.14, 880); setTimeout(() => playTone(660, 0.12, 'sine', 0.1, 990), 60); },
    close() { playTone(660, 0.15, 'sine', 0.14, 330); },
    hover() { playTone(2200, 0.03, 'sine', 0.05); },
    success() { [523, 659, 784].forEach((f, i) => setTimeout(() => playTone(f, 0.15, 'sine', 0.12), i * 80)); },
    error() { playTone(220, 0.2, 'square', 0.1, 110); },
    grab() { playTone(1800, 0.05, 'sine', 0.1, 2400); },
    drop() { playTone(2400, 0.06, 'sine', 0.1, 1400); },
    pulse() { playTone(150, 0.12, 'sine', 0.14, 90); },
    shatter() {
      const ctx = initAudio(), master = getMaster();
      if (!ctx || !master || !settings.sound) return;
      try {
        const buf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * 0.4), ctx.sampleRate);
        const d = buf.getChannelData(0);
        for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / d.length, 1.5);
        const src = ctx.createBufferSource(); src.buffer = buf;
        const f = ctx.createBiquadFilter(); f.type = 'lowpass';
        f.frequency.setValueAtTime(4000, ctx.currentTime);
        f.frequency.exponentialRampToValueAtTime(200, ctx.currentTime + 0.4);
        const g = ctx.createGain(); g.gain.value = 0.35;
        src.connect(f); f.connect(g); g.connect(master); src.start();
        playTone(80, 0.3, 'sine', 0.2, 40);
      } catch (e) { /* ignore */ }
    },
    reform() { [330, 440, 550, 660].forEach((f, i) => setTimeout(() => playTone(f, 0.2, 'sine', 0.1, f * 1.5), i * 60)); },
    glitch() {
      const ctx = initAudio(), master = getMaster();
      if (!ctx || !master || !settings.sound) return;
      try {
        const o = ctx.createOscillator(), g = ctx.createGain();
        o.type = 'sawtooth';
        o.frequency.setValueAtTime(120, ctx.currentTime);
        o.frequency.linearRampToValueAtTime(400, ctx.currentTime + 0.15);
        g.gain.setValueAtTime(0.08, ctx.currentTime);
        g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.18);
        o.connect(g); g.connect(master);
        o.start(); o.stop(ctx.currentTime + 0.2);
      } catch (e) { /* ignore */ }
    }
  };

  function haptic(ms) {
    if (!settings.haptic) return;
    if (!navigator.vibrate) return;
    try {
      const mult = settings.hapticStyle === 'light' ? 0.5 : settings.hapticStyle === 'strong' ? 2 : 1;
      if (Array.isArray(ms)) navigator.vibrate(ms.map(m => m * mult));
      else navigator.vibrate((ms || 12) * mult);
    } catch (e) { /* ignore */ }
  }

  /* =========================================================
     ANIMATIONS
     ========================================================= */
  function animateRipple(x, y, color) {
    if (!settings.animations || !settings.animRipple || settings.reduceMotion) return;
    try {
      const r = document.createElement('div');
      r.style.cssText = `position:fixed;left:${x}px;top:${y}px;width:10px;height:10px;border-radius:50%;border:2px solid ${color || '#8b7cff'};transform:translate(-50%,-50%);pointer-events:none;z-index:9999;opacity:.9;`;
      document.body.appendChild(r);
      r.animate([
        { width: '10px', height: '10px', opacity: 0.9, borderWidth: '3px' },
        { width: '180px', height: '180px', opacity: 0, borderWidth: '1px' }
      ], { duration: 800, easing: 'cubic-bezier(.2,.7,.3,1)' }).onfinish = () => r.remove();
    } catch (e) { /* ignore */ }
  }
  function animateBurst(x, y, color, count) {
    if (!settings.animations || !settings.animBurst || settings.reduceMotion) return;
    try {
      count = Math.floor((count || 12) * (settings.burstIntensity || 1));
      const c = color || '#8b7cff';
      for (let i = 0; i < count; i++) {
        const a = (i / count) * Math.PI * 2;
        const dist = (60 + Math.random() * 40) * (settings.burstIntensity || 1);
        const dot = document.createElement('div');
        dot.style.cssText = `position:fixed;left:${x}px;top:${y}px;width:6px;height:6px;border-radius:50%;background:${c};transform:translate(-50%,-50%);pointer-events:none;z-index:9999;`;
        document.body.appendChild(dot);
        dot.animate([
          { transform: 'translate(-50%,-50%) scale(1)', opacity: 1 },
          { transform: `translate(${Math.cos(a) * dist - 3}px,${Math.sin(a) * dist - 3}px) scale(0)`, opacity: 0 }
        ], { duration: 600 + Math.random() * 200, easing: 'cubic-bezier(.2,.7,.3,1)' }).onfinish = () => dot.remove();
      }
    } catch (e) { /* ignore */ }
  }
  function animateTrail(x, y, color) {
    if (!settings.animations || !settings.animTrail || settings.reduceMotion) return;
    try {
      const dot = document.createElement('div');
      const size = 4 + Math.random() * 4;
      dot.style.cssText = `position:fixed;left:${x}px;top:${y}px;width:${size}px;height:${size}px;border-radius:50%;background:${color || '#8b7cff'};transform:translate(-50%,-50%);pointer-events:none;z-index:9998;`;
      document.body.appendChild(dot);
      dot.animate([
        { transform: 'translate(-50%,-50%) scale(1)', opacity: 0.9 },
        { transform: 'translate(-50%,-50%) scale(0)', opacity: 0 }
      ], { duration: 500 + Math.random() * 300, easing: 'ease-out' }).onfinish = () => dot.remove();
    } catch (e) { /* ignore */ }
  }
  function animatePop(el, scale) {
    if (!settings.animations || settings.reduceMotion || !el) return;
    try {
      el.animate([
        { transform: 'scale(1)' }, { transform: `scale(${scale || 1.15})` }, { transform: 'scale(1)' }
      ], { duration: 400, easing: 'cubic-bezier(.4,1.6,.6,1)' });
    } catch (e) { /* ignore */ }
  }
  function animateFlash(el) {
    if (!settings.animations || settings.reduceMotion || !el) return;
    try {
      el.animate([
        { filter: 'brightness(1)' }, { filter: 'brightness(2.5)' }, { filter: 'brightness(1)' }
      ], { duration: 350, easing: 'ease-out' });
    } catch (e) { /* ignore */ }
  }
  function animateConfetti(count) {
    if (!settings.animations || !settings.animConfetti || settings.reduceMotion) return;
    try {
      count = count || 30;
      const colors = ['#8b7cff','#4dd4ff','#ff5c8c','#ffd45c','#5cff8c','#ff9e5c'];
      for (let i = 0; i < count; i++) {
        const el = document.createElement('div');
        const c = colors[i % colors.length];
        const size = 6 + Math.random() * 6;
        el.style.cssText = `position:fixed;left:${Math.random() * 100}vw;top:-20px;width:${size}px;height:${size}px;background:${c};border-radius:${Math.random() > 0.5 ? '50%' : '2px'};pointer-events:none;z-index:9999;`;
        document.body.appendChild(el);
        const duration = 1800 + Math.random() * 1200;
        const endX = (Math.random() - 0.5) * 200;
        el.animate([
          { transform: 'translate(0,0) rotate(0deg)', opacity: 1 },
          { transform: `translate(${endX}px,100vh) rotate(${720 + Math.random() * 360}deg)`, opacity: 0 }
        ], { duration, easing: 'cubic-bezier(.2,.7,.3,1)' }).onfinish = () => el.remove();
      }
    } catch (e) { /* ignore */ }
  }

  /* =========================================================
     CREDITS
     ========================================================= */
  const CREDIT_KEY = 's_credits';
  const CREDIT_INIT = 40;
  const CREDIT_COSTS = { play: 1, shatter: -2, reform: -3, createShape: -5 };

  let credits = (() => {
    const saved = localStorage.getItem(CREDIT_KEY);
    if (saved == null) { localStorage.setItem(CREDIT_KEY, CREDIT_INIT); return CREDIT_INIT; }
    return parseInt(saved, 10) || 0;
  })();
  let creditHUD = null;
  let creditHackEnabled = localStorage.getItem('s_creditHack') === 'true';

  function createCreditHUD() {
    if (document.getElementById('creditHUD')) { creditHUD = document.getElementById('creditHUD'); return; }
    creditHUD = document.createElement('div');
    creditHUD.id = 'creditHUD';
    creditHUD.style.cssText = `
      position: fixed; top: 84px; right: 20px; z-index: 45;
      display: inline-flex; align-items: center; gap: 8px;
      padding: 9px 16px; border-radius: 999px;
      background: linear-gradient(135deg, rgba(139,124,255,.22), rgba(77,212,255,.12));
      border: 1px solid rgba(139,124,255,.45);
      color: #f5f7ff; font-family: "Inter", sans-serif;
      font-size: 13px; font-weight: 700;
      cursor: pointer; user-select: none;
      box-shadow: 0 8px 24px -8px rgba(139,124,255,.5);
    `;
    creditHUD.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" stroke="#ffd45c" stroke-width="2" style="width:16px;height:16px;">
        <path d="M12 2l3 7h7l-5.5 4.5 2 7-6.5-4-6.5 4 2-7L2 9h7z"/>
      </svg>
      <span id="creditCount">${credits}</span>
      <span id="creditHackBadge" style="display:${creditHackEnabled ? 'inline' : 'none'};font-size:9px;padding:2px 6px;border-radius:999px;background:rgba(255,212,92,.3);color:#ffd45c;">HACK</span>
    `;
    document.body.appendChild(creditHUD);
    creditHUD.addEventListener('click', showCreditInfo);
  }

  function updateCreditHUD(animate) {
    credits = Math.max(0, credits);
    if (!creditHackEnabled) localStorage.setItem(CREDIT_KEY, credits);
    if (!creditHUD) createCreditHUD();
    const el = document.getElementById('creditCount');
    if (el) el.textContent = creditHackEnabled ? '∞' : credits;
    const badge = document.getElementById('creditHackBadge');
    if (badge) badge.style.display = creditHackEnabled ? 'inline' : 'none';
    const drawerCredits = document.getElementById('drawerCredits');
    if (drawerCredits) drawerCredits.textContent = creditHackEnabled ? '∞' : credits;
    const statCredits = document.getElementById('statCredits');
    if (statCredits) statCredits.textContent = creditHackEnabled ? '∞' : credits;
    if (animate && creditHUD && !settings.reduceMotion) {
      try {
        creditHUD.animate([
          { transform: 'scale(1)' }, { transform: 'scale(1.2)' }, { transform: 'scale(1)' }
        ], { duration: 400, easing: 'cubic-bezier(.4,1.4,.6,1)' });
      } catch (e) { /* ignore */ }
    }
  }

  function addCredits(amount) {
    if (creditHackEnabled && amount < 0) return credits;
    credits = Math.max(0, credits + amount);
    if (!creditHackEnabled) localStorage.setItem(CREDIT_KEY, credits);
    updateCreditHUD(true);
    return credits;
  }

  function canAfford(cost) { return creditHackEnabled || credits >= cost; }

  function showCreditInfo() {
    const existing = document.getElementById('creditInfoModal');
    if (existing) existing.remove();
    const modal = document.createElement('div');
    modal.id = 'creditInfoModal';
    modal.style.cssText = `position:fixed;inset:0;z-index:250;display:flex;align-items:center;justify-content:center;background:rgba(5,6,13,.9);padding:24px;`;
    modal.innerHTML = `
      <div style="max-width:440px;width:100%;padding:32px 28px;border-radius:28px;background:#0d0f18;border:1px solid rgba(255,255,255,.14);text-align:center;font-family:Inter,sans-serif;">
        <div style="font-size:48px;margin-bottom:16px;">⭐</div>
        <h2 style="margin:0 0 6px;font-size:32px;color:#f5f7ff;">${creditHackEnabled ? '∞' : credits}</h2>
        <p style="margin:0 0 20px;color:#a8afc7;font-size:14px;">Available Credits</p>
        ${creditHackEnabled ? '<p style="margin:0 0 16px;color:#ffd45c;font-size:12px;font-weight:700;">🔓 CREDIT HACK ACTIVE</p>' : ''}
        <div style="text-align:left;padding:16px;border-radius:16px;background:rgba(0,0,0,.25);margin-bottom:16px;font-size:13px;color:#a8afc7;">
          <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.05);"><span>Shatter (×3)</span><span style="color:#5cff8c;font-weight:700;">+2</span></div>
          <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.05);"><span>Reform (×4)</span><span style="color:#5cff8c;font-weight:700;">+3</span></div>
          <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.05);"><span>Create shape</span><span style="color:#5cff8c;font-weight:700;">+5</span></div>
          <div style="display:flex;justify-content:space-between;padding:6px 0;"><span>Play shape</span><span style="color:#ff7c9d;font-weight:700;">−1</span></div>
        </div>
        <div style="text-align:left;padding:14px;border-radius:14px;background:rgba(255,212,92,.08);border:1px solid rgba(255,212,92,.25);margin-bottom:16px;">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <div>
              <div style="font-size:13px;font-weight:700;color:#ffd45c;">🔓 Credit Hack</div>
              <div style="font-size:11px;color:#a8afc7;margin-top:2px;">Unlimited credits</div>
            </div>
            <div id="creditHackToggle" style="width:48px;height:28px;border-radius:999px;background:${creditHackEnabled ? 'linear-gradient(135deg,#ffd45c,#ff7c9d)' : 'rgba(255,255,255,.08)'};cursor:pointer;position:relative;">
              <div style="position:absolute;top:50%;left:${creditHackEnabled ? '25px' : '3px'};transform:translateY(-50%);width:20px;height:20px;border-radius:50%;background:#fff;transition:left .3s;"></div>
            </div>
          </div>
        </div>
        <div style="display:flex;gap:10px;">
          <button id="creditResetBtn" style="flex:1;padding:12px;border-radius:999px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.05);color:#f5f7ff;font-family:inherit;font-size:13px;font-weight:600;cursor:pointer;">Reset to ${CREDIT_INIT}</button>
          <button id="creditCloseBtn" style="flex:1;padding:12px;border-radius:999px;border:none;background:linear-gradient(135deg,#8b7cff,#4dd4ff);color:#fff;font-family:inherit;font-size:13px;font-weight:600;cursor:pointer;">Close</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    document.getElementById('creditCloseBtn').addEventListener('click', () => { modal.remove(); SFX.close(); });
    document.getElementById('creditResetBtn').addEventListener('click', () => {
      credits = CREDIT_INIT;
      updateCreditHUD(true);
      modal.remove();
      SFX.success();
      showToast('Credits reset to ' + CREDIT_INIT);
    });
    document.getElementById('creditHackToggle').addEventListener('click', () => {
      creditHackEnabled = !creditHackEnabled;
      localStorage.setItem('s_creditHack', creditHackEnabled ? 'true' : 'false');
      updateCreditHUD(true);
      modal.remove();
      showCreditInfo();
    });
    modal.addEventListener('click', (e) => {
      if (e.target === modal) { modal.remove(); SFX.close(); }
    });
  }

  function showOutOfCreditsModal() {
    if (creditHackEnabled) return;
    const existing = document.getElementById('outOfCreditsModal');
    if (existing) existing.remove();
    const modal = document.createElement('div');
    modal.id = 'outOfCreditsModal';
    modal.style.cssText = `position:fixed;inset:0;z-index:260;display:flex;align-items:center;justify-content:center;background:rgba(5,6,13,.94);padding:24px;`;
    modal.innerHTML = `
      <div style="max-width:380px;width:100%;padding:32px 28px;border-radius:28px;background:#0d0f18;border:1px solid rgba(255,90,120,.35);text-align:center;font-family:Inter,sans-serif;">
        <div style="font-size:42px;margin-bottom:16px;">💸</div>
        <h2 style="margin:0 0 8px;font-size:22px;color:#f5f7ff;">Not Enough Credits</h2>
        <p style="margin:0 0 24px;color:#a8afc7;font-size:14px;">You need <b style="color:#ff7c9d;">1 credit</b> to play.</p>
        <div style="display:flex;flex-direction:column;gap:10px;">
          <button id="earnCreditBtn" style="padding:14px;border-radius:999px;border:none;background:linear-gradient(135deg,#5cff8c,#4dd4ff);color:#0b0e18;font-family:inherit;font-size:14px;font-weight:700;cursor:pointer;">Get +10 Free Credits</button>
          <button id="hackCreditBtn" style="padding:14px;border-radius:999px;border:1px solid rgba(255,212,92,.4);background:rgba(255,212,92,.1);color:#ffd45c;font-family:inherit;font-size:14px;font-weight:700;cursor:pointer;">🔓 Enable Credit Hack</button>
          <button id="cancelCreditsBtn" style="padding:14px;border-radius:999px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.05);color:#f5f7ff;font-family:inherit;font-size:14px;font-weight:600;cursor:pointer;">Cancel</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    document.getElementById('earnCreditBtn').addEventListener('click', () => { addCredits(10); modal.remove(); showToast('+10 credits'); });
    document.getElementById('hackCreditBtn').addEventListener('click', () => {
      creditHackEnabled = true;
      localStorage.setItem('s_creditHack', 'true');
      updateCreditHUD(true);
      modal.remove();
      showToast('🔓 Credit hack enabled');
    });
    document.getElementById('cancelCreditsBtn').addEventListener('click', () => { modal.remove(); SFX.close(); });
  }

  /* =========================================================
     TOAST
     ========================================================= */
  let toastTimer = null;
  function showToast(msg) {
    const toast = document.getElementById('toast');
    if (!toast) return;
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 1600);
  }

  /* =========================================================
     THEME
     ========================================================= */
  function applyTheme(name) {
    const c = THEMES[name] || THEMES.default;
    document.documentElement.style.setProperty('--accent-1', c[0]);
    document.documentElement.style.setProperty('--accent-2', c[1]);
    document.documentElement.style.setProperty('--accent-glow', hexToRgba(c[0], 0.4));
  }

  /* =========================================================
     EXPORTS
     ========================================================= */
  S.FEATURES = FEATURES;
  S.featureState = featureState;
  S.isFeatureOn = isFeatureOn;
  S.setFeature = setFeature;
  S.settings = settings;
  S.QUALITY_CFG = QUALITY_CFG;
  S.qualityCfg = QUALITY_CFG[settings.quality] || QUALITY_CFG.medium;
  S.THEMES = THEMES;
  S.PALETTE = PALETTE;
  S.clamp = clamp;
  S.lerpAngle = lerpAngle;
  S.lerpColor = lerpColor;
  S.hslToHex = hslToHex;
  S.hexToRgba = hexToRgba;
  S.SFX = SFX;
  S.haptic = haptic;
  S.animateRipple = animateRipple;
  S.animateBurst = animateBurst;
  S.animateTrail = animateTrail;
  S.animatePop = animatePop;
  S.animateFlash = animateFlash;
  S.animateConfetti = animateConfetti;
  S.credits = () => credits;
  S.creditHackEnabled = () => creditHackEnabled;
  S.CREDIT_COSTS = CREDIT_COSTS;
  S.CREDIT_INIT = CREDIT_INIT;
  S.addCredits = addCredits;
  S.canAfford = canAfford;
  S.updateCreditHUD = updateCreditHUD;
  S.createCreditHUD = createCreditHUD;
  S.showCreditInfo = showCreditInfo;
  S.showOutOfCreditsModal = showOutOfCreditsModal;
  S.showToast = showToast;
  S.applyTheme = applyTheme;
  S.saveSetting = (k, v) => localStorage.setItem('s_' + k, v);
})();