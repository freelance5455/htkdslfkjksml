/* J.A.R.V.I.S BR 2.4 — APP (HTML/APK)
   core.js: o que todas as telas usam — dados no aparelho, tema do HUD, Gemini, voz (falar e ouvir).
   Roda sem servidor: abre direto do arquivo (file://), num WebView de APK ou num site (https).
   Fork PT-BR do Mark LVI (FatihMakes), CC BY-NC 4.0. */
"use strict";
const J = (() => {
  const $ = s => document.querySelector(s);
  const $$ = s => Array.from(document.querySelectorAll(s));

  // ── dados no aparelho ─────────────────────────────────────────────────────
  const mem = {};                              // reserva quando o localStorage está bloqueado
  function ler(k, p = "") { try { const v = localStorage.getItem(k); return v === null ? p : v; } catch (e) { return k in mem ? mem[k] : p; } }
  function guardar(k, v) { const s = typeof v === "string" ? v : JSON.stringify(v); try { localStorage.setItem(k, s); } catch (e) { mem[k] = s; } }
  function lerJSON(k, p) { try { const v = JSON.parse(ler(k, "")); return v === null || v === undefined ? p : v; } catch (e) { return p; } }
  const esc = t => String(t ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const linkar = t => esc(t).replace(/(https?:\/\/[^\s)<]+)/g, '<a href="$1" target="_blank" rel="noopener">$1</a>');
  const dobrar = t => String(t || "").normalize("NFKD").replace(/[̀-ͯ]/g, "").toLowerCase();

  // ── tema: a mesma paleta do HUD do PC (ui.py → classe C), girando o tom pela cor escolhida ──
  const BASE = { BG: "#00060a", PANEL: "#010d14", PANEL2: "#010f18", BORDER: "#0d3347", BORDER_B: "#1a5c7a", BORDER_A: "#0f4060",
    PRI: "#00d4ff", PRI_DIM: "#007a99", PRI_GHO: "#001f2e", TEXT: "#8ffcff", TEXT_DIM: "#3a8a9a", TEXT_MED: "#5ab8cc",
    WHITE: "#d8f8ff", DARK: "#000d14", BAR_BG: "#011520" };
  const FIXO = { ACC: "#ff6b00", ACC2: "#ffcc00", GREEN: "#00ff88", GREEN_D: "#00aa55", RED: "#ff3355", MUTED_C: "#ff3366" };
  function hex2rgb(h) { return [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16) / 255); }
  function rgb2hsv([r, g, b]) {
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn; let h = 0;
    if (d) h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
    return [((h / 6) + 1) % 1, mx ? d / mx : 0, mx];
  }
  function hsv2hex(h, s, v) {
    const i = Math.floor(h * 6), f = h * 6 - i, p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
    const [r, g, b] = [[v, t, p], [q, v, p], [p, v, t], [p, q, v], [t, p, v], [v, p, q]][((i % 6) + 6) % 6];
    return "#" + [r, g, b].map(x => Math.round(x * 255).toString(16).padStart(2, "0")).join("");
  }
  function paleta(acento) {
    const C = { ...BASE, ...FIXO };
    if (!/^#[0-9a-f]{6}$/i.test(acento || "") || acento.toLowerCase() === BASE.PRI) return C;
    const h0 = rgb2hsv(hex2rgb(BASE.PRI))[0], [ha, sa] = rgb2hsv(hex2rgb(acento)), dh = ha - h0, cinza = sa < 0.08;
    for (const [k, v] of Object.entries(BASE)) { let [h, s, vv] = rgb2hsv(hex2rgb(v)); if (cinza) s *= 0.15; C[k] = hsv2hex(((h + dh) % 1 + 1) % 1, s, vv); }
    return C;
  }
  let C = paleta(ler("j_cor", BASE.PRI));
  function aplicarTema() {
    C = paleta(ler("j_cor", BASE.PRI));
    const r = document.documentElement.style;
    for (const [k, v] of Object.entries(C)) r.setProperty("--" + k.toLowerCase().replace("_", "-"), v);
    const [a, b, c] = hex2rgb(C.PRI).map(x => Math.round(x * 255)); r.setProperty("--pri-rgb", `${a},${b},${c}`);
    const m = document.querySelector('meta[name="theme-color"]'); if (m) m.content = C.BG;
    return C;
  }
  const nomeAssistente = () => ler("j_assist", "J.A.R.V.I.S") || "J.A.R.V.I.S";
  const nomeDono = () => ler("j_nome", "") || "senhor";

  // ── Gemini (direto do aparelho, com a chave do usuário) ────────────────────
  // Os modelos 2.5 só continuam para contas que já usavam; o padrão é o Flash atual. Se o modelo escolhido
  // não existir para a sua chave, o app pergunta ao Google quais existem e troca sozinho (uma vez).
  const PADRAO = "gemini-3.8-flash";
  const modelo = () => ler("j_modelo", "") || PADRAO;
  const API = "https://generativelanguage.googleapis.com/v1beta/";
  const semModelo = (st, m) => st === 404 || (st !== 429 && /model/i.test(m) && /not found|not supported|no longer|unavailable|not available|deprecated|does not have access|permission|new users/i.test(m));
  async function listarModelos() {
    const chave = ler("j_chave"); if (!chave) return [];
    const r = await fetch(API + "models?pageSize=200", { headers: { "x-goog-api-key": chave } });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error((j.error && j.error.message) || "não deu para listar os modelos");
    return (j.models || []).filter(m => (m.supportedGenerationMethods || []).includes("generateContent")).map(m => m.name.replace(/^models\//, ""));
  }
  function melhorDe(nomes, tipo) {
    const ver = n => +((n.match(/gemini-(\d+(?:\.\d+)?)/) || [0, 0])[1]);
    const ok = tipo === "tts" ? nomes.filter(n => /tts/.test(n)) : nomes.filter(n => /^gemini-/.test(n) && !/tts|image|live|embed|audio|transcribe|robotics|computer|native/.test(n));
    const nota = n => ver(n) * 10 + (tipo === "tts" ? (/lite/.test(n) ? 0 : 2) : (/flash$/.test(n) ? 5 : /flash/.test(n) && !/lite/.test(n) ? 3 : /lite/.test(n) ? 1 : 0)) - (/preview|exp/.test(n) ? 0.5 : 0);
    return ok.sort((a, b) => nota(b) - nota(a))[0] || null;
  }
  async function gemini(corpo, mod, jaTrocou) {
    const chave = ler("j_chave");
    if (!chave) throw new Error("falta a chave do Gemini — abra ⚙ → MOTOR & PROVEDORES");
    if (navigator.onLine === false) throw new Error("sem internet agora");
    const nome = mod || modelo();
    const r = await fetch(`${API}models/${encodeURIComponent(nome)}:generateContent`,
      { method: "POST", headers: { "Content-Type": "application/json", "x-goog-api-key": chave }, body: JSON.stringify(corpo) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) {
      const m = (j.error && j.error.message) || ("Gemini " + r.status);
      const falha = (texto) => Object.assign(new Error(texto), { status: r.status });
      if (r.status === 429) throw falha("o limite grátis do Gemini acabou por agora; tente mais tarde (" + m.slice(0, 80) + ")");
      if (r.status === 400 && /api key not valid|api_key_invalid/i.test(m)) throw falha("a chave do Gemini não é válida — confira em ⚙ → MOTOR & PROVEDORES");
      if (!mod && !jaTrocou && semModelo(r.status, m)) {
        const novo = melhorDe(await listarModelos().catch(() => []), "texto");
        if (novo && novo !== nome) { guardar("j_modelo", novo); return gemini(corpo, undefined, true); }
      }
      throw falha(m);
    }
    return j;
  }
  const partesDe = j => ((((j || {}).candidates || [])[0] || {}).content || {}).parts || [];
  const textoDe = j => partesDe(j).map(p => p.text || "").join("").trim();

  // ── áudio: um AudioContext só, e o nível (0–1) que o HUD desenha ──────────
  let ctxA = null, nivel = 0;
  function audio() {
    if (!ctxA) { const A = window.AudioContext || window.webkitAudioContext; if (!A) return null; ctxA = new A(); }
    if (ctxA.state === "suspended") ctxA.resume().catch(() => {});
    return ctxA;
  }
  const nivelAudio = () => nivel;
  function bip(f = 660, d = 0.08, vol = 0.05, tipo = "sine") {
    const c = audio(); if (!c) return;
    try { const o = c.createOscillator(), g = c.createGain(); o.type = tipo; o.frequency.value = f; g.gain.value = vol;
      o.connect(g); g.connect(c.destination); o.start(); g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + d); o.stop(c.currentTime + d); } catch (e) {}
  }
  function vibrar(p = [120, 60, 120]) { try { navigator.vibrate && navigator.vibrate(p); } catch (e) {} }

  // ── falar ─────────────────────────────────────────────────────────────────
  // modo: auto (voz do aparelho; se ele não tiver, a do Gemini) | sistema | gemini | mudo
  let vozes = [], fonteAtual = null, falando = false, simulador = null;
  function carregarVozes() { try { vozes = (speechSynthesis.getVoices() || []).filter(v => (v.lang || "").toLowerCase().startsWith("pt")); } catch (e) { vozes = []; } return vozes; }
  if ("speechSynthesis" in window) { carregarVozes(); try { speechSynthesis.onvoiceschanged = carregarVozes; } catch (e) {} }
  const limparFala = t => String(t || "").replace(/https?:\/\/\S+/g, "link").replace(/[*_#`>|~]/g, "").replace(/\s+/g, " ").trim();
  function parar() {
    falando = false; clearInterval(simulador); nivel = 0;
    try { speechSynthesis.cancel(); } catch (e) {}
    try { if (fonteAtual) fonteAtual.stop(); } catch (e) {}
    fonteAtual = null;
  }
  const TTS = ["gemini-3.8-flash-tts", "gemini-3.8-flash-lite-tts", "gemini-2.5-flash-preview-tts"];
  async function falarGemini(texto) {
    const voz = ler("j_vozgem", "") || (ler("j_persona") === "friday" ? "Kore" : "Charon");
    const corpo = { contents: [{ parts: [{ text: "Fale em português do Brasil, num tom calmo e confiante: " + texto }] }],
      generationConfig: { responseModalities: ["AUDIO"], speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: voz } } } } };
    // o modelo de voz que funcionou da última vez vem primeiro; se nenhum da lista existir para a chave, pergunta ao Google
    let lista = [ler("j_tts_ok", ""), ...TTS].filter((x, i, a) => x && a.indexOf(x) === i), j = null, erro = null;
    for (let tent = 0; tent < 2 && !j; tent++) {
      for (const m of lista) {
        try { j = await gemini(corpo, m); guardar("j_tts_ok", m); break; }
        catch (e) { erro = e; if (!e.status || e.status === 429 || !semModelo(e.status, e.message)) throw e; }
      }
      if (!j && tent === 0) { const achado = melhorDe(await listarModelos().catch(() => []), "tts"); if (!achado || lista.includes(achado)) break; lista = [achado]; }
    }
    if (!j) throw erro || new Error("sem voz do Gemini para esta chave");
    const parte = partesDe(j).find(p => p.inlineData);
    if (!parte) throw new Error("sem áudio");
    const mime = parte.inlineData.mimeType || "", bin = atob(parte.inlineData.data), c = audio();
    if (!c) throw new Error("sem áudio");
    let buf;
    if (/l16|pcm/i.test(mime) || !mime) {             // PCM 16 bits cru (o normal do Gemini)
      const taxa = +((mime.match(/rate=(\d+)/) || [0, 24000])[1]), n = bin.length >> 1;
      buf = c.createBuffer(1, n, taxa); const d = buf.getChannelData(0);
      for (let i = 0; i < n; i++) { let v = bin.charCodeAt(2 * i) | (bin.charCodeAt(2 * i + 1) << 8); if (v >= 32768) v -= 65536; d[i] = v / 32768; }
    } else {                                           // wav/mp3/ogg: o próprio navegador decodifica
      const bytes = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      buf = await new Promise((ok, falha) => c.decodeAudioData(bytes.buffer, ok, falha));
    }
    return new Promise(res => {
      const src = c.createBufferSource(), an = c.createAnalyser(); an.fftSize = 512; src.buffer = buf;
      src.connect(an); an.connect(c.destination); fonteAtual = src;
      const arr = new Uint8Array(an.fftSize);
      const med = () => { if (!falando) return; an.getByteTimeDomainData(arr); let s = 0; for (const x of arr) s += (x - 128) ** 2; nivel = Math.min(1, Math.sqrt(s / arr.length) / 40); requestAnimationFrame(med); };
      src.onended = () => { nivel = 0; fonteAtual = null; res(); };
      src.start(); med();
    });
  }
  function falarSistema(texto) {
    return new Promise((res, rej) => {
      if (!("speechSynthesis" in window)) return rej(new Error("sem voz"));
      const u = new SpeechSynthesisUtterance(texto); u.lang = "pt-BR";
      const v = vozes[+ler("j_voz", "0")] || vozes[0]; if (v) u.voice = v;
      u.rate = +ler("j_vel", "1") || 1; u.pitch = ler("j_persona") === "friday" ? 1.15 : 0.92;
      let comecou = false;
      u.onstart = () => { comecou = true; simulador = setInterval(() => { nivel = 0.25 + Math.random() * 0.6; }, 90); };
      u.onboundary = () => { nivel = 0.9; };
      u.onend = () => { clearInterval(simulador); nivel = 0; res(); };
      u.onerror = e => { clearInterval(simulador); nivel = 0; comecou ? res() : rej(e); };
      try { speechSynthesis.cancel(); speechSynthesis.speak(u); } catch (e) { rej(e); }
      setTimeout(() => { if (!comecou && falando) { try { speechSynthesis.cancel(); } catch (e) {} rej(new Error("voz do sistema não respondeu")); } }, 2500);
    });
  }
  async function falar(texto, ev = {}) {
    const modo = ler("j_falar", "auto"), t = limparFala(texto);
    if (modo === "mudo" || !t) { ev.fim && ev.fim(); return; }
    parar(); falando = true; ev.inicio && ev.inicio();
    try {
      if (modo === "gemini") await falarGemini(t);
      else if (modo === "sistema") await falarSistema(t);
      else { carregarVozes(); try { if (!vozes.length) throw 0; await falarSistema(t); } catch (e) { if (falando) await falarGemini(t); } }
    } catch (e) { ev.erro && ev.erro(e); }
    falando = false; nivel = 0; ev.fim && ev.fim();
  }
  const estaFalando = () => falando;

  // ── ouvir ─────────────────────────────────────────────────────────────────
  // 1º: reconhecimento de voz do navegador (Chrome). 2º (WebView de APK não tem): grava o microfone
  //     em WAV e o Gemini transcreve. Para de gravar sozinho quando você para de falar.
  const Reconhecer = window.SpeechRecognition || window.webkitSpeechRecognition;
  let gravando = null;
  function pararOuvir() { if (gravando) gravando.parar(); }
  const ouvindo = () => !!gravando;
  function ouvir(ev = {}) {
    if (gravando) return Promise.resolve("");
    parar();
    if (Reconhecer && ler("j_stt", "auto") !== "gemini") {
      return new Promise(res => {
        let r; try { r = new Reconhecer(); } catch (e) { return res(ouvirGravando(ev)); }
        r.lang = "pt-BR"; r.interimResults = true; r.maxAlternatives = 1;
        let final = "", falhou = false;
        gravando = { parar: () => { try { r.stop(); } catch (e) {} } };
        r.onresult = e => { let t = ""; for (const x of e.results) t += x[0].transcript; final = t; nivel = 0.5; ev.parcial && ev.parcial(t); };
        r.onerror = e => { if (["not-allowed", "service-not-allowed", "network", "audio-capture"].includes(e.error)) falhou = e.error; };
        r.onend = () => { gravando = null; nivel = 0; if (falhou && !final) { ev.aviso && ev.aviso("Reconhecimento do aparelho falhou (" + falhou + "); usando o Gemini."); res(ouvirGravando(ev)); } else res(final.trim()); };
        try { r.start(); ev.inicio && ev.inicio(); } catch (e) { gravando = null; res(ouvirGravando(ev)); }
      });
    }
    return ouvirGravando(ev);
  }
  async function ouvirGravando(ev = {}) {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw new Error("este app não liberou o microfone; use o 🎤 do teclado e digite");
    const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
    const c = audio(), src = c.createMediaStreamSource(stream), proc = c.createScriptProcessor(4096, 1, 1), pedacos = [];
    let falou = false, silencio = 0, fim = null; const t0 = performance.now();
    ev.inicio && ev.inicio();
    await new Promise(res => {
      fim = res;
      gravando = { parar: () => res() };
      proc.onaudioprocess = e => {
        const d = e.inputBuffer.getChannelData(0); pedacos.push(new Float32Array(d));
        let s = 0; for (let i = 0; i < d.length; i += 4) s += d[i] * d[i]; const rms = Math.sqrt(s / (d.length / 4));
        nivel = Math.min(1, rms * 8);
        const dt = d.length / c.sampleRate;
        if (rms > 0.03) { falou = true; silencio = 0; } else silencio += dt;
        const tempo = (performance.now() - t0) / 1000;
        if ((falou && silencio > 1.4) || tempo > 15 || (!falou && tempo > 7)) res();
      };
      src.connect(proc); proc.connect(c.destination);
    });
    try { proc.disconnect(); src.disconnect(); } catch (e) {}
    stream.getTracks().forEach(t => t.stop()); gravando = null; nivel = 0;
    if (!falou) return "";
    ev.processando && ev.processando();
    const wav = paraWav(pedacos, c.sampleRate, 16000);
    const j = await gemini({ contents: [{ parts: [{ inlineData: { mimeType: "audio/wav", data: wav } },
      { text: "Transcreva exatamente o que a pessoa disse (português do Brasil). Responda só com a transcrição, sem aspas. Se não houver fala, responda com nada." }] }] });
    return textoDe(j).replace(/^["“]|["”]$/g, "").trim();
  }
  function paraWav(pedacos, taxaIn, taxaOut) {
    const total = pedacos.reduce((a, p) => a + p.length, 0), passo = taxaIn / taxaOut, n = Math.floor(total / passo);
    const tudo = new Float32Array(total); let o = 0; for (const p of pedacos) { tudo.set(p, o); o += p.length; }
    const buf = new ArrayBuffer(44 + n * 2), v = new DataView(buf), w = (i, s) => { for (let k = 0; k < s.length; k++) v.setUint8(i + k, s.charCodeAt(k)); };
    w(0, "RIFF"); v.setUint32(4, 36 + n * 2, true); w(8, "WAVE"); w(12, "fmt "); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
    v.setUint32(24, taxaOut, true); v.setUint32(28, taxaOut * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, "data"); v.setUint32(40, n * 2, true);
    for (let i = 0; i < n; i++) { const s = Math.max(-1, Math.min(1, tudo[Math.floor(i * passo)])); v.setInt16(44 + i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true); }
    return b64(new Uint8Array(buf));
  }
  function b64(bytes) { let s = ""; for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000)); return btoa(s); }
  function arquivoB64(arq) { return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(",")[1] || ""); r.onerror = rej; r.readAsDataURL(arq); }); }

  // ── abrir coisas fora do app (WhatsApp, discador, Spotify, mapas) ─────────
  function abrirExterno(url) {
    let w = null; try { w = window.open(url, "_blank"); } catch (e) {}
    if (!w) { try { location.href = url; } catch (e) {} }
    return { ok: true, link: url };
  }

  // ── persona e "o que eu sei de você" (usado pelas telas que conversam) ─────
  function persona() {
    const p = ler("j_persona", "jarvis");
    return p === "friday"
      ? "Você é a F.R.I.D.A.Y, a assistente que substituiu o JARVIS: irlandesa no jeito, direta, calorosa e com humor rápido."
      : `Você é o ${nomeAssistente()}, o assistente do Homem de Ferro: britânico no jeito, calmo, preciso, com humor seco.`;
  }
  async function perguntaRapida(texto, extra = []) {
    const memorias = lerJSON("j_memorias", []).slice(-40).map(m => m.texto).join("; ");
    const j = await gemini({ systemInstruction: { parts: [{ text: persona() + ` Português do Brasil. Chame o usuário de "${nomeDono()}" às vezes. Respostas CURTAS (1 a 3 frases), faladas. ` + (memorias ? "Você sabe dele: " + memorias : "") }] },
      contents: [{ role: "user", parts: [...extra, { text: texto }] }] });
    return textoDe(j) || "…";
  }

  // ── telas: trocar de tela (também na versão de arquivo único, onde cada tela roda num quadro) ──
  function ir(url) {
    try { if (window.parent !== window && typeof window.parent.irPara === "function") return window.parent.irPara(url); } catch (e) {}
    location.href = url;
  }
  function query() {
    if (location.search) return location.search;
    try { if (window.parent !== window && window.parent.__query) return window.parent.__query; } catch (e) {}
    return "";
  }
  function voltar() { ir("index.html"); }
  // caixa de texto própria: prompt()/confirm() não funcionam em muitos apps gerados de HTML
  function caixa({ titulo = "J.A.R.V.I.S", texto = "", valor = "", editavel = false, ok = "▸ OK", cancelar = "FECHAR" } = {}) {
    return new Promise(res => {
      const fundo = document.createElement("div");
      fundo.style.cssText = "position:fixed;inset:0;z-index:90;background:rgba(0,4,8,.85);display:flex;align-items:center;justify-content:center;padding:14px";
      fundo.innerHTML = `<div style="width:min(520px,100%);background:var(--panel,#010d14);border:1px solid var(--pri-dim,#007a99);border-radius:6px;padding:16px;font-family:'Courier New',monospace">
        <div style="color:var(--pri,#00d4ff);letter-spacing:3px;font-weight:700;font-size:13px;margin-bottom:8px">◈ ${esc(titulo)}</div>
        <div style="color:var(--text-med,#5ab8cc);font-size:12px;line-height:1.5;margin-bottom:8px">${esc(texto)}</div>
        ${editavel || valor ? `<textarea style="width:100%;height:140px;font:12px 'Courier New',monospace;color:#d8f8ff;background:#000d14;border:1px solid #0f4060;border-radius:4px;padding:8px" ${editavel ? "" : "readonly"}></textarea>` : ""}
        <div style="display:flex;gap:8px;margin-top:10px"><button data-r="1" style="flex:1">${esc(ok)}</button><button data-r="0" style="flex:1">${esc(cancelar)}</button></div></div>`;
      const ta = fundo.querySelector("textarea"); if (ta) { ta.value = valor; setTimeout(() => { ta.focus(); if (!editavel) ta.select(); }, 50); }
      fundo.querySelectorAll("button").forEach(b => b.onclick = () => { fundo.remove(); res(b.dataset.r === "1" ? (ta ? ta.value : true) : null); });
      document.body.appendChild(fundo);
    });
  }
  async function copiar(texto, titulo = "COPIAR") {
    try { await navigator.clipboard.writeText(texto); return true; } catch (e) {}
    await caixa({ titulo, texto: "Selecione tudo e copie (segure o dedo no texto → Copiar):", valor: texto, ok: "PRONTO", cancelar: "FECHAR" });
    return false;
  }
  function registrarSW() {
    if ("serviceWorker" in navigator && /^https?:$/.test(location.protocol)) navigator.serviceWorker.register("sw.js").catch(() => {});
  }
  document.addEventListener("pointerdown", () => audio(), { once: true });

  // canal entre telas abertas ao mesmo tempo (o holograma mexe a boca quando o JARVIS fala)
  let canal = null; try { canal = new BroadcastChannel("jarvis"); } catch (e) {}
  const avisarTelas = m => { try { canal && canal.postMessage(m); } catch (e) {} };
  const ouvirTelas = fn => { try { canal && (canal.onmessage = e => fn(e.data)); } catch (e) {} };

  return { $, $$, ler, guardar, lerJSON, esc, linkar, dobrar, paleta, aplicarTema, get C() { return C; }, nomeAssistente, nomeDono,
    gemini, partesDe, textoDe, modelo, PADRAO, listarModelos, melhorDe, audio, bip, vibrar, nivelAudio, falar, parar, estaFalando, carregarVozes, get vozes() { return vozes; },
    ouvir, pararOuvir, ouvindo, temReconhecimento: !!Reconhecer, arquivoB64, b64, abrirExterno, persona, perguntaRapida, ir, query, voltar, caixa, copiar, registrarSW,
    avisarTelas, ouvirTelas };
})();
