/* Core logic for Inventory & Sales Tracker (no DOM code). */
(function (root) {
  "use strict";
  const Core = {};
  const ITEM_TEXT = ["sku", "barcode", "name", "category", "supplier", "location"];
  const ITEM_NUM = ["purchase_price", "selling_price", "cash_disc", "bulk_disc", "bulk_min", "commission", "reorder_level", "reorder_qty"];
  Core.ITEM_TEXT = ITEM_TEXT; Core.ITEM_NUM = ITEM_NUM;

  const r2 = (v) => { const a = Number(Math.round(Number(Math.abs(v).toFixed(8) + "e2")) + "e-2"); return v < 0 ? -a : a; };
  Core.r2 = r2;
  Core.defaultSettings = () => ({ business: "", address: "", phone: "", tax_rate: 0, footer: "Thank you for your business!", next_invoice: 1 });
  Core.newCart = () => ({ lines: [], customer: "", payment: "Cash", agent: "", note: "" });
  Core.ensureState = (s) => {
    s.items = s.items || []; s.log = s.log || []; s.invoices = s.invoices || []; s.nextId = s.nextId || 1;
    s.settings = Object.assign(Core.defaultSettings(), s.settings || {}); s.cart = Object.assign(Core.newCart(), s.cart || {});
    return s;
  };
  Core.newState = () => Core.ensureState({ items: [], log: [], nextId: 1 });

  Core.checkDigit = (d12) => {
    let s = 0;
    for (let i = 0; i < 12; i++) s += Number(d12[i]) * (i % 2 === 0 ? 1 : 3);
    return String((10 - (s % 10)) % 10);
  };
  Core.isValidEAN13 = (c) => /^\d{13}$/.test(c) && Core.checkDigit(c.slice(0, 12)) === c[12];

  const L = ["0001101", "0011001", "0010011", "0111101", "0100011", "0110001", "0101111", "0111011", "0110111", "0001011"];
  const G = ["0100111", "0110011", "0011011", "0100001", "0011101", "0111001", "0000101", "0010001", "0001001", "0010111"];
  const R = ["1110010", "1100110", "1101100", "1000010", "1011100", "1001110", "1010000", "1000100", "1001000", "1110100"];
  const PAR = ["LLLLLL", "LLGLGG", "LLGGLG", "LLGGGL", "LGLLGG", "LGGLLG", "LGGGLL", "LGLGLG", "LGLGGL", "LGGLGL"];
  Core.ean13Bits = (code) => {
    if (!Core.isValidEAN13(code)) return null;
    const first = Number(code[0]);
    let bits = "101";
    for (let i = 1; i <= 6; i++) bits += (PAR[first][i - 1] === "L" ? L : G)[Number(code[i])];
    bits += "01010";
    for (let i = 7; i <= 12; i++) bits += R[Number(code[i])];
    return bits + "101";
  };

  Core.nextInternalBarcode = (items) => {
    let max = 0;
    for (const it of items) {
      if (/^200\d{10}$/.test(it.barcode)) max = Math.max(max, Number(it.barcode.slice(3, 12)));
    }
    const d12 = "200" + String(max + 1).padStart(9, "0");
    return d12 + Core.checkDigit(d12);
  };

  // Finds an item, tolerating UPC-A vs EAN-13 leading-zero differences.
  Core.findItem = (state, code) => {
    code = (code || "").trim();
    if (!code) return null;
    const variants = [code, "0" + code, code.replace(/^0/, "")];
    for (const v of variants) {
      const it = state.items.find((i) => i.barcode === v);
      if (it) return it;
    }
    return null;
  };

  Core.calcSale = (item, qty, payment) => {
    const cost = item.purchase_price, list = item.selling_price;
    const cash = payment === "Cash" ? list * item.cash_disc : 0;
    const bulk = qty >= item.bulk_min ? list * item.bulk_disc : 0;
    const net = list - cash - bulk;
    const commission = net * item.commission;
    const profit = net - commission - cost;
    const unit = { cost, list, cash, bulk, net, commission, profit };
    const total = {};
    for (const k in unit) total[k] = unit[k] * qty;
    return { unit, total, margin: net ? profit / net : 0, cashApplied: payment === "Cash", bulkApplied: qty >= item.bulk_min };
  };

  Core.onHand = (state, barcode) =>
    state.log.reduce((s, e) => (e.barcode === barcode ? s + (e.type === "IN" ? e.qty : -e.qty) : s), 0);

  Core.stockRows = (state, search) => {
    const q = (search || "").trim().toLowerCase();
    const inMap = {}, outMap = {};
    for (const e of state.log) (e.type === "IN" ? inMap : outMap)[e.barcode] = ((e.type === "IN" ? inMap : outMap)[e.barcode] || 0) + e.qty;
    return state.items
      .filter((i) => !q || [i.name, i.sku, i.barcode, i.category].some((v) => String(v).toLowerCase().includes(q)))
      .map((i) => {
        const qty_in = inMap[i.barcode] || 0, qty_out = outMap[i.barcode] || 0, on_hand = qty_in - qty_out;
        const status = on_hand <= 0 ? "Out of Stock" : on_hand <= i.reorder_level ? "Reorder" : "OK";
        return Object.assign({}, i, { qty_in, qty_out, on_hand, value: on_hand * i.purchase_price, status });
      })
      .sort((a, b) => a.sku.localeCompare(b.sku));
  };

  Core.totals = (state) => {
    const rows = Core.stockRows(state, "");
    const t = { skus: rows.length, units: 0, stock_value: 0, reorder: 0, out: 0, gross: 0, cash: 0, bulk: 0, net: 0, commission: 0, cogs: 0, profit: 0 };
    for (const r of rows) {
      t.units += r.on_hand; t.stock_value += r.value;
      if (r.status === "Reorder") t.reorder++;
      if (r.status === "Out of Stock") t.out++;
    }
    for (const e of state.log) {
      if (e.type !== "OUT") continue;
      t.gross += e.gross; t.cash += e.cash_disc; t.bulk += e.bulk_disc; t.net += e.net;
      t.commission += e.commission; t.cogs += e.cogs; t.profit += e.profit;
    }
    t.margin = t.net ? t.profit / t.net : 0;
    return t;
  };

  Core.saveItem = (state, data, id) => {
    const d = {};
    for (const k of ITEM_TEXT) d[k] = String(data[k] == null ? "" : data[k]).trim();
    for (const k of ITEM_NUM) {
      const v = Number(data[k] == null || data[k] === "" ? (k === "bulk_min" ? 1 : 0) : data[k]);
      if (!isFinite(v) || v < 0) throw new Error("Please enter valid, non-negative numbers.");
      d[k] = v;
    }
    if (!d.sku || !d.barcode || !d.name) throw new Error("SKU, Barcode and Item name are required.");
    const clash = state.items.find((i) => i.id !== id && (i.sku === d.sku || i.barcode === d.barcode));
    if (clash) throw new Error("That SKU or barcode already exists.");
    if (id == null) {
      d.id = state.nextId++;
      state.items.push(d);
      return d;
    }
    const old = state.items.find((i) => i.id === id);
    if (!old) throw new Error("Item not found.");
    if (old.barcode !== d.barcode) for (const e of state.log) if (e.barcode === old.barcode) e.barcode = d.barcode;
    Object.assign(old, d);
    return old;
  };

  Core.deleteItem = (state, id) => {
    const it = state.items.find((i) => i.id === id);
    if (!it) return;
    const n = state.log.filter((e) => e.barcode === it.barcode).length;
    if (n) throw new Error("This item has " + n + " stock-log entries, so it can't be deleted.");
    state.items = state.items.filter((i) => i.id !== id);
  };

  Core.record = (state, e) => {
    const item = Core.findItem(state, e.barcode);
    if (!item) throw new Error("Barcode not found in inventory.");
    if (e.type !== "IN" && e.type !== "OUT") throw new Error("Type must be IN or OUT.");
    const qty = Number(e.qty);
    if (!isFinite(qty) || qty <= 0) throw new Error("Quantity must be greater than zero.");
    const entry = { id: state.nextId++, date: e.date, barcode: item.barcode, type: e.type,
      payment: e.type === "OUT" ? e.payment : "", agent: e.agent || "", note: e.note || "", qty, invoice_id: e.invoice_id || null,
      gross: 0, cash_disc: 0, bulk_disc: 0, net: 0, commission: 0, cogs: 0, profit: 0 };
    if (e.type === "OUT") {
      const t = Core.calcSale(item, qty, e.payment).total;
      Object.assign(entry, { gross: t.list, cash_disc: t.cash, bulk_disc: t.bulk, net: t.net, commission: t.commission, cogs: t.cost, profit: t.profit });
    }
    state.log.push(entry);
    return entry;
  };

  // ---------- invoices (multi-item sales) ----------
  Core.priceLines = (state, lines, payment, taxRate) => {
    const out = []; let sub = 0, disc = 0, net = 0;
    for (const l of lines) {
      const item = Core.findItem(state, l.barcode); if (!item) throw new Error("Barcode not found: " + l.barcode);
      const qty = Number(l.qty); if (!(qty > 0)) throw new Error("Quantity must be greater than zero for " + item.name + ".");
      const c = Core.calcSale(item, qty, payment);
      const gross = r2(c.unit.list * qty), d = r2(c.total.cash + c.total.bulk), amount = r2(gross - d);
      out.push({ barcode: item.barcode, sku: item.sku, name: item.name, qty, unit: c.unit.list, gross, disc: d, amount, onHand: Core.onHand(state, item.barcode) });
      sub += gross; disc += d; net += amount;
    }
    sub = r2(sub); disc = r2(disc); net = r2(net);
    const tax = r2((net * (taxRate || 0)) / 100);
    return { lines: out, subtotal: sub, discounts: disc, net, tax, total: r2(net + tax) };
  };
  Core.invoiceNumber = (state) => "INV-" + String(state.settings.next_invoice).padStart(4, "0");

  Core.createInvoice = (state, d) => {
    if (!d.lines || !d.lines.length) throw new Error("Add at least one item to the invoice.");
    if (d.payment !== "Cash" && d.payment !== "Credit") throw new Error("Payment must be Cash or Credit.");
    const taxRate = Number(state.settings.tax_rate) || 0;
    const p = Core.priceLines(state, d.lines, d.payment, taxRate);
    const number = Core.invoiceNumber(state);
    const inv = { id: state.nextId++, number, date: d.date, customer: (d.customer || "").trim(), payment: d.payment, agent: (d.agent || "").trim(),
      note: (d.note || "").trim(), status: "ok", tax_rate: taxRate, lines: [], subtotal: p.subtotal, discounts: p.discounts, net: p.net, tax: p.tax, total: p.total };
    for (const l of p.lines) {
      const e = Core.record(state, { date: d.date, barcode: l.barcode, type: "OUT", payment: d.payment, agent: inv.agent, note: number, qty: l.qty, invoice_id: inv.id });
      inv.lines.push({ barcode: l.barcode, sku: l.sku, name: l.name, qty: l.qty, unit: l.unit, disc: l.disc, amount: l.amount, log_id: e.id });
    }
    state.invoices.push(inv); state.settings.next_invoice = (Number(state.settings.next_invoice) || 1) + 1;
    return inv;
  };

  Core.voidInvoice = (state, id) => {
    const inv = state.invoices.find((i) => i.id === id); if (!inv) throw new Error("Invoice not found.");
    if (inv.status === "void") return inv;
    state.log = state.log.filter((e) => e.invoice_id !== id); inv.status = "void"; return inv;
  };

  // Everything a PDF needs (customer-facing: no cost, commission or profit).
  Core.invoiceDoc = (state, inv) => ({
    title: inv.payment === "Cash" ? "RECEIPT" : "INVOICE", number: inv.number, date: inv.date, customer: inv.customer || "Walk-in customer",
    payment: inv.payment, agent: inv.agent, note: inv.note, status: inv.status, tax_rate: inv.tax_rate, lines: inv.lines,
    subtotal: inv.subtotal, discounts: inv.discounts, tax: inv.tax, total: inv.total,
    business: { name: state.settings.business, address: state.settings.address, phone: state.settings.phone, footer: state.settings.footer },
  });

  Core.deleteLog = (state, id) => { state.log = state.log.filter((e) => e.id !== id); };

  // ---------- CSV ----------
  Core.parseCSV = (text, delim) => {
    text = text.replace(/^\uFEFF/, "");
    if (!delim) { const first = text.split(/\r?\n/)[0] || ""; const sc = (first.match(/;/g) || []).length, tc = (first.match(/\t/g) || []).length, cc = (first.match(/,/g) || []).length; delim = sc > cc ? ";" : tc > cc ? "\t" : ","; }
    const rows = []; let row = [], cell = "", q = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (q) {
        if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c;
      } else if (c === '"') q = true;
      else if (c === delim) { row.push(cell); cell = ""; }
      else if (c === "\n" || c === "\r") {
        if (c === "\r" && text[i + 1] === "\n") i++;
        row.push(cell); cell = ""; rows.push(row); row = [];
      } else cell += c;
    }
    if (cell !== "" || row.length) { row.push(cell); rows.push(row); }
    return rows.filter((r) => r.some((x) => x !== ""));
  };
  Core.toCSV = (rows) =>
    "\uFEFF" + rows.map((r) => r.map((v) => { v = v == null ? "" : String(v); return /[",\n\r]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }).join(",")).join("\r\n");

  // Imports CSV files exported by the desktop app (inventory or stock-log).
  Core.importCSV = (state, text) => {
    const rows = Core.parseCSV(text);
    if (rows.length < 2) throw new Error("The file is empty.");
    const head = rows[0].map((h) => h.trim().toLowerCase());
    const get = (r, k) => (r[head.indexOf(k)] || "").trim();
    const n = (r, k, d) => { const v = parseFloat(get(r, k)); return isFinite(v) ? v : d; };
    let added = 0, updated = 0, skipped = 0;
    if (head.includes("purchase_price") && head.includes("barcode")) {
      for (const r of rows.slice(1)) {
        const data = { sku: get(r, "sku"), barcode: get(r, "barcode"), name: get(r, "name"), category: get(r, "category"),
          supplier: get(r, "supplier"), location: get(r, "location"), purchase_price: n(r, "purchase_price", 0),
          selling_price: n(r, "selling_price", 0), cash_disc: n(r, "cash_disc", 0), bulk_disc: n(r, "bulk_disc", 0),
          bulk_min: n(r, "bulk_min", 1), commission: n(r, "commission", 0), reorder_level: n(r, "reorder_level", 0), reorder_qty: n(r, "reorder_qty", 0) };
        const ex = state.items.find((i) => i.barcode === data.barcode);
        try { Core.saveItem(state, data, ex ? ex.id : null); ex ? updated++ : added++; } catch (e) { skipped++; }
      }
      return { kind: "inventory", added, updated, skipped };
    }
    if (head.includes("type") && head.includes("qty") && head.includes("date") && head.includes("barcode")) {
      for (const r of rows.slice(1)) {
        const item = Core.findItem(state, get(r, "barcode")), type = get(r, "type").toUpperCase(), qty = n(r, "qty", 0);
        if (!item || (type !== "IN" && type !== "OUT") || qty <= 0) { skipped++; continue; }
        state.log.push({ id: state.nextId++, date: get(r, "date").slice(0, 10), barcode: item.barcode, type, payment: get(r, "payment"),
          agent: get(r, "agent"), note: get(r, "note"), qty, gross: n(r, "gross", 0), cash_disc: n(r, "cash_disc", 0),
          bulk_disc: n(r, "bulk_disc", 0), net: n(r, "net", 0), commission: n(r, "commission", 0), cogs: n(r, "cogs", 0), profit: n(r, "profit", 0) });
        added++;
      }
      return { kind: "log", added, updated: 0, skipped };
    }
    return Core.importItemsTable(state, rows);
  };

  // ---------- tolerant item-list import (any CSV with an item name column) ----------
  const ALIASES = {
    sku: ["sku", "itemcode", "code", "itemno", "itemnumber", "productcode", "partno", "partnumber"],
    barcode: ["barcode", "barcodeean13", "ean", "ean13", "upc", "gtin", "barcodenumber"],
    name: ["itemname", "name", "description", "item", "product", "productname", "itemdescription"],
    category: ["category", "group", "itemcategory", "department"],
    supplier: ["supplier", "vendor", "suppliername"],
    location: ["location", "bin", "shelf", "warehouse"],
    purchase_price: ["purchaseprice", "purchase", "cost", "costprice", "unitcost", "buyprice", "buyingprice"],
    selling_price: ["sellingprice", "selling", "price", "saleprice", "retailprice", "unitprice", "sellprice"],
    cash_disc: ["cashdiscount", "cashdisc", "cashdiscountpct", "cashdiscountpercent"],
    bulk_disc: ["bulkdiscount", "bulkdisc", "bulkdiscountpct", "bulkdiscountpercent"],
    bulk_min: ["bulkminqty", "bulkminquantity", "bulkmin", "bulkqty"],
    commission: ["agentcommission", "commission", "commissionrate", "agentcommissionpct"],
    reorder_level: ["reorderlevel", "reorderpoint", "minstock", "minqty", "minimumstock"],
    reorder_qty: ["reorderqty", "reorderquantity", "orderqty"],
  };
  const norm = (h) => String(h == null ? "" : h).toLowerCase().replace(/[^a-z0-9]/g, "");
  const dec = (s) => String(s == null ? "" : s).trim().replace(/^(\d+),(\d{1,2})$/, "$1.$2");
  const num = (v, d) => { const x = parseFloat(dec(v).replace(/[$,]/g, "")); return isFinite(x) ? x : d; };
  const pctv = (v) => { const s = String(v == null ? "" : v).trim(); if (!s) return 0; if (s.endsWith("%")) { const x = parseFloat(s.slice(0, -1)); return isFinite(x) ? x / 100 : 0; } const x = parseFloat(dec(s).replace(/,/g, "")); if (!isFinite(x)) return 0; return x >= 1 ? x / 100 : x; };

  Core.importItemsTable = (state, rows) => {
    const head = rows[0].map(norm), lookup = {};
    for (const f in ALIASES) { const i = head.findIndex((h) => ALIASES[f].includes(h)); if (i >= 0) lookup[f] = i; }
    if (lookup.name == null) throw new Error("Couldn't find an item name column. Use a heading such as Item Name, Name or Description.");
    const get = (r, f) => (lookup[f] == null ? "" : (r[lookup[f]] || "").trim());
    let added = 0, updated = 0, skipped = 0, auto = 0;
    for (const r of rows.slice(1)) {
      const name = get(r, "name"); if (!name) continue;
      let sku = get(r, "sku"), bc = get(r, "barcode");
      let ex = bc ? state.items.find((i) => i.barcode === bc) : null;
      if (!ex && sku) ex = state.items.find((i) => i.sku === sku) || null;
      if (!bc) { if (ex) bc = ex.barcode; else { bc = Core.nextInternalBarcode(state.items); auto++; } }
      if (!sku) { if (ex) sku = ex.sku; else { let n = state.items.length + 1; while (state.items.some((i) => i.sku === "ITEM-" + String(n).padStart(4, "0"))) n++; sku = "ITEM-" + String(n).padStart(4, "0"); } }
      const data = { sku, barcode: bc, name, category: get(r, "category"), supplier: get(r, "supplier"), location: get(r, "location"),
        purchase_price: num(get(r, "purchase_price"), 0), selling_price: num(get(r, "selling_price"), 0), cash_disc: pctv(get(r, "cash_disc")),
        bulk_disc: pctv(get(r, "bulk_disc")), bulk_min: num(get(r, "bulk_min"), 1) || 1, commission: pctv(get(r, "commission")),
        reorder_level: num(get(r, "reorder_level"), 0), reorder_qty: num(get(r, "reorder_qty"), 0) };
      try { Core.saveItem(state, data, ex ? ex.id : null); ex ? updated++ : added++; } catch (e) { skipped++; }
    }
    return { kind: "inventory", added, updated, skipped, auto };
  };

  root.Core = Core;
  if (typeof module !== "undefined" && module.exports) module.exports = Core;
})(typeof window !== "undefined" ? window : globalThis);
