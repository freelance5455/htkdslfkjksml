(function (root) {
  "use strict";
  const LAT = 33.46306, LON = 49.92806, ELEV = 2050;
  const ALL_MODELS = [
    { id: "ecmwf_ifs025", name: "ECMWF" },
    { id: "gfs_seamless", name: "GFS" },
    { id: "icon_seamless", name: "ICON" },
    { id: "gem_seamless", name: "GEM" },
    { id: "ukmo_seamless", name: "UKMO" },
    { id: "meteofrance_seamless", name: "ARPEGE" }
  ];
  const DEFAULTS = { rainMm: 2, snowCm: 0.5, windKmh: 30, gustKmh: 45, frostC: 0, sprayWindKmh: 15, notify: true };
  const DAY_LABELS = ["امروز", "فردا", "پس‌فردا"];
  const DIRS = ["شمال", "شمال‌شرق", "شرق", "جنوب‌شرق", "جنوب", "جنوب‌غرب", "غرب", "شمال‌غرب"];
  const CODE_TEXT = {0:"صاف",1:"عمدتاً صاف",2:"نیمه‌ابری",3:"ابری",45:"مه",48:"مه یخی",51:"نم‌نم خفیف",53:"نم‌نم",55:"نم‌نم شدید",56:"نم‌نم یخ‌زده",57:"نم‌نم یخ‌زده",61:"باران خفیف",63:"باران",65:"باران شدید",66:"باران یخ‌زده",67:"باران یخ‌زده",71:"برف خفیف",73:"برف",75:"برف شدید",77:"دانه برف",80:"رگبار خفیف",81:"رگبار",82:"رگبار شدید",85:"رگبار برف",86:"رگبار برف شدید",95:"رعدوبرق",96:"رعدوبرق و تگرگ",99:"رعدوبرق و تگرگ"};

  const num = v => typeof v === "number" && !isNaN(v);
  function stats(vals) {
    const a = vals.filter(num);
    if (!a.length) return { avg: null, min: null, max: null, n: 0 };
    return { avg: a.reduce((x, y) => x + y, 0) / a.length, min: Math.min(...a), max: Math.max(...a), n: a.length };
  }
  function circMean(degs) {
    const a = degs.filter(num); if (!a.length) return null;
    let x = 0, y = 0;
    a.forEach(d => { x += Math.cos(d * Math.PI / 180); y += Math.sin(d * Math.PI / 180); });
    return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
  }
  const dirName = d => num(d) ? DIRS[Math.round(d / 45) % 8] : "—";
  function codeIcon(c) {
    if (!num(c)) return "❔";
    if (c === 0) return "☀️"; if (c === 1) return "🌤"; if (c === 2) return "⛅"; if (c === 3) return "☁️";
    if (c === 45 || c === 48) return "🌫"; if (c >= 51 && c <= 57) return "🌦";
    if (c >= 61 && c <= 67) return "🌧"; if (c >= 71 && c <= 77) return "❄️";
    if (c >= 80 && c <= 82) return "🌦"; if (c === 85 || c === 86) return "🌨"; return "⛈";
  }

  // ---------- storage (Cache API: works in page and service worker) ----------
  const hasCaches = typeof caches !== "undefined";
  async function putJson(cacheName, key, obj) {
    const text = JSON.stringify(obj);
    if (hasCaches) {
      try { const c = await caches.open(cacheName); await c.put("https://store.local/" + key, new Response(text)); return; } catch (e) {}
    }
    try { localStorage.setItem(cacheName + ":" + key, text); } catch (e) {}
  }
  async function getJsonStore(cacheName, key) {
    if (hasCaches) {
      try { const c = await caches.open(cacheName); const r = await c.match("https://store.local/" + key); if (r) return await r.json(); } catch (e) {}
    }
    try { const t = localStorage.getItem(cacheName + ":" + key); return t ? JSON.parse(t) : null; } catch (e) { return null; }
  }
  async function getSettings() {
    const s = await getJsonStore("ashnakhor-settings", "s");
    return Object.assign({}, DEFAULTS, s || {});
  }
  const saveSettings = s => putJson("ashnakhor-settings", "s", s);
  const saveData = r => putJson("ashnakhor-data", "last", r);
  const loadData = () => getJsonStore("ashnakhor-data", "last");

  // ---------- fetch ----------
  function buildUrl(models) {
    const hourly = "temperature_2m,precipitation,snowfall,wind_speed_10m,wind_gusts_10m,wind_direction_10m,weather_code";
    const daily = "weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,snowfall_sum,wind_speed_10m_max,wind_gusts_10m_max,et0_fao_evapotranspiration,precipitation_probability_max";
    const current = "temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m,wind_gusts_10m,wind_direction_10m";
    return "https://api.open-meteo.com/v1/forecast?latitude=" + LAT + "&longitude=" + LON + "&elevation=" + ELEV +
      "&current=" + current + "&hourly=" + hourly + "&daily=" + daily +
      "&timezone=Asia%2FTehran&forecast_days=7&past_days=1&wind_speed_unit=kmh&models=" + models.map(m => m.id).join(",");
  }
  async function getJson(url, ms) {
    let t;
    const timeout = new Promise((_, rej) => { t = setTimeout(() => rej(new Error("timeout")), ms || 20000); });
    try {
      const res = await Promise.race([fetch(url), timeout]);
      if (!res.ok) {
        let reason = "";
        try { const j = await res.json(); reason = j.reason || ""; } catch (x) {}
        const e = new Error("HTTP " + res.status + " " + reason); e.retry = true; throw e;
      }
      return await Promise.race([res.json(), timeout]);
    } finally { clearTimeout(t); }
  }
  async function fetchData() {
    let models = ALL_MODELS.slice();
    let lastErr;
    for (let attempt = 0; attempt < 5 && models.length; attempt++) {
      try {
        const data = await getJson(buildUrl(models));
        if (data.error) { const e = new Error(data.reason || "API error"); e.retry = true; throw e; }
        const res = { data, models, t: Date.now() };
        await saveData(res);
        try { await recordDayAhead(res); } catch (x) {}
        return res;
      } catch (e) {
        lastErr = e;
        if (!e.retry) break;
        const msg = (e.message || "").toLowerCase();
        const bad = models.filter(m => msg.includes(m.id));
        if (bad.length) models = models.filter(m => !bad.includes(m));
        else if (models.length > 3) models = models.slice(0, 3);
        else if (models.length > 1) models = models.slice(1, 2);
        else break;
      }
    }
    throw lastErr;
  }

  // ---------- analysis ----------
  function series(block, name, models) {
    const out = models.map(m => block[name + "_" + m.id] || null);
    if (out.every(x => !x) && block[name]) out[0] = block[name];
    return out;
  }
  function scalars(block, name, models) {
    const out = models.map(m => { const v = block[name + "_" + m.id]; return num(v) ? v : null; });
    if (out.every(v => v === null) && num(block[name])) out[0] = block[name];
    return out;
  }
  const at = (arrs, i) => arrs.map(a => (a && num(a[i])) ? a[i] : null);

  function analyze(data, models) {
    const H = data.hourly, D = data.daily, Cu = data.current;
    const hs = k => series(H, k, models);
    const T = hs("temperature_2m"), P = hs("precipitation"), S = hs("snowfall"),
          W = hs("wind_speed_10m"), G = hs("wind_gusts_10m"), WD = hs("wind_direction_10m"), WC = hs("weather_code");
    const curHour = Cu.time.slice(0, 13) + ":00";
    let nowIdx = H.time.findIndex(x => x >= curHour); if (nowIdx < 0) nowIdx = 0;

    const hours = [];
    for (let i = nowIdx; i < H.time.length; i++) {
      const p = at(P, i), s = at(S, i);
      const liq = p.map((v, k) => v === null ? null : Math.max(0, v - (s[k] === null ? 0 : s[k] / 7.7)));
      const wc = at(WC, i).find(num);
      hours.push({ i, time: H.time[i], temp: stats(at(T, i)), liqM: liq, liq: stats(liq), snowM: s, snow: stats(s),
        wind: stats(at(W, i)), gust: stats(at(G, i)), dir: circMean(at(WD, i)), code: wc === undefined ? null : wc });
    }

    const sc = k => stats(scalars(Cu, k, models));
    const cw = scalars(Cu, "weather_code", models).find(num);
    const current = { time: Cu.time, temp: sc("temperature_2m"), feels: sc("apparent_temperature"), hum: sc("relative_humidity_2m"),
      wind: sc("wind_speed_10m"), gust: sc("wind_gusts_10m"), dir: circMean(scalars(Cu, "wind_direction_10m", models)),
      precip: sc("precipitation"), code: cw === undefined ? null : cw };

    const todayStr = Cu.time.slice(0, 10);
    let d0 = D.time.indexOf(todayStr); if (d0 < 0) d0 = 0;
    const dv = k => series(D, k, models);
    const dTmax = dv("temperature_2m_max"), dTmin = dv("temperature_2m_min"), dP = dv("precipitation_sum"), dS = dv("snowfall_sum"),
          dG = dv("wind_gusts_10m_max"), dW = dv("wind_speed_10m_max"), dE = dv("et0_fao_evapotranspiration"),
          dPr = dv("precipitation_probability_max"), dC = dv("weather_code");
    const days = [];
    for (let j = d0; j < D.time.length; j++) {
      const c = at(dC, j).find(num);
      days.push({ date: D.time[j], idx: j - d0, tmax: stats(at(dTmax, j)), tmin: stats(at(dTmin, j)), precipM: at(dP, j),
        tminM: at(dTmin, j), precip: stats(at(dP, j)), snow: stats(at(dS, j)), gust: stats(at(dG, j)), wind: stats(at(dW, j)),
        et0: stats(at(dE, j)), prob: stats(at(dPr, j)), code: c === undefined ? null : c });
    }
    const yesterday = d0 > 0 ? { date: D.time[d0 - 1], precip: stats(at(dP, d0 - 1)), snow: stats(at(dS, d0 - 1)) } : null;
    return { current, hours, days, yesterday, models, todayStr };
  }

  // ---------- farm rain log & model skill ----------
  const loadLog = async () => (await getJsonStore("ashnakhor-data", "raingauge")) || {};
  const saveLog = l => putJson("ashnakhor-data", "raingauge", l);
  const loadFc1 = async () => (await getJsonStore("ashnakhor-data", "fc1")) || {};
  const saveFc1 = f => putJson("ashnakhor-data", "fc1", f);
  async function fetchHistFc(start, end) {
    const url = "https://historical-forecast-api.open-meteo.com/v1/forecast?latitude=" + LAT + "&longitude=" + LON + "&elevation=" + ELEV + "&start_date=" + start + "&end_date=" + end + "&daily=precipitation_sum&timezone=Asia%2FTehran&models=" + ALL_MODELS.map(m => m.id).join(",");
    const j = await getJson(url, 25000);
    const out = {};
    ((j.daily && j.daily.time) || []).forEach((d, i) => {
      const v = {};
      ALL_MODELS.forEach(m => { const a = j.daily["precipitation_sum_" + m.id]; if (a && num(a[i])) v[m.id] = a[i]; });
      out[d] = v;
    });
    return out;
  }
  async function recordDayAhead(res) {
    // remember what each model predicted for TOMORROW (the last day-ahead value is kept once the day arrives)
    const A = analyze(res.data, res.models);
    const d = A.days[1];
    if (!d) return;
    const fc = await loadFc1();
    const v = {};
    res.models.forEach((m, k) => { if (num(d.precipM[k])) v[m.id] = d.precipM[k]; });
    fc[d.date] = v;
    const keys = Object.keys(fc).sort();
    while (keys.length > 90) delete fc[keys.shift()];
    await putJson("ashnakhor-data", "fc1", fc);
  }
  function modelSkill(log, fc, models) {
    return models.map(m => {
      let n = 0, ae = 0, bias = 0;
      Object.keys(log).forEach(date => {
        const f = fc[date] && fc[date][m.id];
        if (num(f) && num(log[date])) { n++; ae += Math.abs(f - log[date]); bias += f - log[date]; }
      });
      return { id: m.id, name: m.name, n, mae: n ? ae / n : null, bias: n ? bias / n : null };
    });
  }

  // ---------- alerts ----------
  function computeAlerts(A, S) {
    const out = [];
    for (const day of A.days.slice(0, 3)) {
      const hrs = A.hours.filter(h => h.time.startsWith(day.date));
      if (!hrs.length) continue;
      const label = DAY_LABELS[day.idx];
      const mk = (type, level, icon, title, body) => out.push({ key: type + "-" + day.date + "-" + level, type, level, icon, title, body, date: day.date, dayIdx: day.idx, dayLabel: label });
      const sumM = key => A.models.map((_, k) => { let s = 0, any = false; hrs.forEach(h => { const v = h[key][k]; if (num(v)) { s += v; any = true; } }); return any ? s : null; });

      const rt = sumM("liqM"), rs = stats(rt);
      if (rs.n && rs.avg >= S.rainMm) {
        const first = hrs.find(h => num(h.liq.avg) && h.liq.avg >= 0.2);
        const agree = rt.filter(v => num(v) && v >= S.rainMm).length;
        mk("rain", rs.avg >= S.rainMm * 3 ? "danger" : "warn", "🌧", "باران",
          "حدود " + rs.avg.toFixed(1) + " mm (" + rs.min.toFixed(1) + " تا " + rs.max.toFixed(1) + ") • " + agree + " از " + rs.n + " مدل موافق" +
          (first ? " • شروع حدود " + first.time.slice(11, 16) : ""));
      }
      const st = sumM("snowM"), ss = stats(st);
      if (ss.n && ss.avg >= S.snowCm) {
        const first = hrs.find(h => num(h.snow.avg) && h.snow.avg >= 0.1);
        const agree = st.filter(v => num(v) && v >= S.snowCm).length;
        mk("snow", ss.avg >= S.snowCm * 3 ? "danger" : "warn", "❄️", "برف",
          "حدود " + ss.avg.toFixed(1) + " cm (" + ss.min.toFixed(1) + " تا " + ss.max.toFixed(1) + ") • " + agree + " از " + ss.n + " مدل موافق" +
          (first ? " • شروع حدود " + first.time.slice(11, 16) : ""));
      }
      const pk = hrs.reduce((a, h) => (num(h.gust.avg) && (!a || h.gust.avg > a.gust.avg)) ? h : a, null);
      const wa = hrs.map(h => h.wind.avg).filter(num);
      const wmax = wa.length ? Math.max(...wa) : null;
      if ((pk && pk.gust.avg >= S.gustKmh) || (wmax !== null && wmax >= S.windKmh)) {
        const g = pk ? pk.gust.avg : 0;
        mk("wind", g >= S.gustKmh * 1.3 ? "danger" : "warn", "💨", "باد شدید",
          "باد تا " + (wmax !== null ? Math.round(wmax) : "—") + " km/h، تندباد تا " + Math.round(g) + " km/h" +
          (pk ? " از " + dirName(pk.dir) + " • اوج حدود " + pk.time.slice(11, 16) : ""));
      }
      const ta = hrs.map(h => h.temp.avg).filter(num), tm = hrs.map(h => h.temp.min).filter(num);
      if (ta.length) {
        const tmin = Math.min(...ta), tlow = tm.length ? Math.min(...tm) : tmin;
        if (tmin <= S.frostC) {
          const cold = hrs.reduce((a, h) => (num(h.temp.avg) && (!a || h.temp.avg < a.temp.avg)) ? h : a, null);
          mk("frost", tmin <= S.frostC - 3 ? "danger" : "warn", "🥶", "یخبندان",
            "کمینه دما حدود " + tmin.toFixed(1) + "°C (کم‌ترین مدل " + tlow.toFixed(1) + "°)" + (cold ? " • سردترین ساعت " + cold.time.slice(11, 16) : ""));
        }
      }
    }
    return out;
  }

  function sprayWindows(A, S) {
    const hrs = A.hours.slice(0, 48);
    const ok = hrs.map((h, idx) => {
      const hh = +h.time.slice(11, 13);
      if (hh < 6 || hh > 19) return false;
      if (!num(h.wind.avg) || h.wind.avg > S.sprayWindKmh) return false;
      if (num(h.gust.avg) && h.gust.avg > S.sprayWindKmh * 1.7) return false;
      if (num(h.temp.avg) && (h.temp.avg < 5 || h.temp.avg > 30)) return false;
      for (let k = 0; k < 4; k++) { const x = hrs[idx + k]; if (x && num(x.liq.max) && x.liq.max >= 0.1) return false; }
      return true;
    });
    const ranges = [];
    let start = null;
    for (let i = 0; i <= hrs.length; i++) {
      const good = i < hrs.length && ok[i] && (start === null || hrs[i].time.slice(0, 10) === hrs[start].time.slice(0, 10));
      if (good && start === null) start = i;
      else if (!good && start !== null) {
        const len = i - start;
        if (len >= 2) {
          const end = +hrs[i - 1].time.slice(11, 13) + 1;
          ranges.push({ date: hrs[start].time.slice(0, 10), from: hrs[start].time.slice(11, 16), to: String(end).padStart(2, "0") + ":00" });
        }
        start = (i < hrs.length && ok[i]) ? i : null;
      }
    }
    return ranges;
  }

  // ---------- notifications ----------
  async function notifyNew(alerts, reg, settings) {
    if (!settings.notify || !reg || !hasCaches) return 0;
    const cache = await caches.open("ashnakhor-notified");
    let sent = 0;
    for (const a of alerts) {
      if (a.dayIdx > 1) continue;
      const key = "https://notified.local/" + encodeURIComponent(a.key);
      if (await cache.match(key)) continue;
      await cache.put(key, new Response("1"));
      await reg.showNotification(a.icon + " " + a.title + " — " + a.dayLabel, {
        body: a.body, tag: a.key, lang: "fa", dir: "rtl", icon: "icon-192.png", badge: "icon-192.png",
        requireInteraction: a.level === "danger"
      });
      sent++;
    }
    return sent;
  }
  async function checkAndNotify(reg) {
    const s = await getSettings();
    const res = await fetchData();
    const A = analyze(res.data, res.models);
    return notifyNew(computeAlerts(A, s), reg, s);
  }

  const API = { LAT, LON, ELEV, ALL_MODELS, DEFAULTS, DAY_LABELS, CODE_TEXT, num, stats, dirName, codeIcon, putJson, getJsonStore, getJson,
    getSettings, saveSettings, loadData, loadLog, saveLog, loadFc1, saveFc1, fetchHistFc, modelSkill, fetchData, buildUrl, analyze, computeAlerts, sprayWindows, notifyNew, checkAndNotify };
  root.AshnakhorCore = API;
  if (typeof module !== "undefined" && module.exports) module.exports = API;
})(typeof self !== "undefined" ? self : globalThis);
