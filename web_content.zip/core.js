/* স্বরপাঠ — core.js : বিশুদ্ধ ফাংশন (DOM ছাড়া) */
(function(root){
var SPELL={"উজ্জল":"উজ্জ্বল","সন্মান":"সম্মান","শুন্য":"শূন্য","ভুমিকা":"ভূমিকা","মুল্য":"মূল্য","মুল":"মূল","প্রতিযোগীতা":"প্রতিযোগিতা","সহযোগীতা":"সহযোগিতা","মন্ত্রীসভা":"মন্ত্রিসভা","দূর্বল":"দুর্বল","দূর্ঘটনা":"দুর্ঘটনা","দূর্নীতি":"দুর্নীতি","ব্যাবহার":"ব্যবহার","অতিথী":"অতিথি","পরিস্কার":"পরিষ্কার","আর্শীবাদ":"আশীর্বাদ","আর্শিবাদ":"আশীর্বাদ","অন্তর্ভূক্ত":"অন্তর্ভুক্ত","পদ্ধতী":"পদ্ধতি","শারীরীক":"শারীরিক","কিংবদন্তী":"কিংবদন্তি","মুহুর্ত":"মুহূর্ত","পুর্ব":"পূর্ব","সুর্য":"সূর্য","নিশ্চই":"নিশ্চয়ই","প্রয়োজনিয়":"প্রয়োজনীয়","দায়ীত্ব":"দায়িত্ব","শ্রদ্ধাঞ্জলী":"শ্রদ্ধাঞ্জলি","অধ্যাবসায়":"অধ্যবসায়","ধৈর্য্য":"ধৈর্য","সৌন্দর্য্য":"সৌন্দর্য","বৈশিষ্ঠ্য":"বৈশিষ্ট্য","সমপ্রতি":"সম্প্রতি","অনুভুতি":"অনুভূতি","পরিক্ষা":"পরীক্ষা","আবিস্কার":"আবিষ্কার","নমষ্কার":"নমস্কার","স্বাস্থ":"স্বাস্থ্য","উচ্চারন":"উচ্চারণ","বর্ননা":"বর্ণনা","কারন":"কারণ","প্রনাম":"প্রণাম","সরকারী":"সরকারি","বাংলাদেশী":"বাংলাদেশি","ইংরেজী":"ইংরেজি","গুনগত":"গুণগত","মনযোগ":"মনোযোগ","সমীকরন":"সমীকরণ"};
var SUF=["","ের","কে","ে","র","টি","টা","টির","গুলো","গুলি","ও","ই","তে","দের","রা","য়","য়ের","কেই","েও","েই","ীয়","বান","বানের"];
function normBn(t){
 return String(t).replace(/\u09A1\u09BC/g,"\u09DC").replace(/\u09A2\u09BC/g,"\u09DD").replace(/\u09AF\u09BC/g,"\u09DF")
  .replace(/\u09C7\u09BE/g,"\u09CB").replace(/\u09C7\u09D7/g,"\u09CC");
}
function parseDict(txt){
 var d={},lines=String(txt||"").split(/\n/);
 for(var i=0;i<lines.length;i++){var p=lines[i].split("=");if(p.length>=2){var a=normBn(p[0].trim()),b=normBn(p.slice(1).join("=").trim());if(a&&b)d[a]=b}}
 return d;
}
function mergeDict(extra){var o={},k;for(k in SPELL)o[k]=SPELL[k];for(k in (extra||{}))o[k]=extra[k];return o}
function spellFix(text,extra){
 var D=mergeDict(extra),keys=Object.keys(D).sort(function(a,b){return b.length-a.length}),ch={},n=0;
 function note(a,b){var key=a+"→"+b;ch[key]=(ch[key]||0)+1;n++}
 var out=normBn(text).replace(/[\u0980-\u09FF\u200C\u200D]+/g,function(w){
  if(D.hasOwnProperty(w)){note(w,D[w]);return D[w]}
  for(var i=0;i<keys.length;i++){var k=keys[i];if(w.length>k.length&&w.indexOf(k)===0){var rest=w.slice(k.length);if(SUF.indexOf(rest)>=0){var r=D[k]+rest;note(w,r);return r}}}
  return w;
 });
 var list=[];for(var k2 in ch){var p=k2.split("→");list.push({from:p[0],to:p[1],count:ch[k2]})}
 return {text:out,count:n,changes:list};
}
function lev(a,b){
 var n=a.length,m=b.length;if(!n)return m;if(!m)return n;
 var p=[],c=[],i,j;for(j=0;j<=m;j++)p[j]=j;
 for(i=1;i<=n;i++){c[0]=i;for(j=1;j<=m;j++){c[j]=Math.min(p[j]+1,c[j-1]+1,p[j-1]+(a.charAt(i-1)===b.charAt(j-1)?0:1))}var t=p;p=c;c=t}
 return p[m];
}
function splitTok(tok){var m=/^([^\u0980-\u09FFA-Za-z0-9]*)([\s\S]*?)([^\u0980-\u09FFA-Za-z0-9]*)$/.exec(tok);return [m[1],m[2],m[3]]}
function alignFix(trans,ref){
 var A=normBn(trans).split(/\s+/).filter(Boolean),B=normBn(ref).split(/\s+/).filter(Boolean);
 var n=A.length,m=B.length;
 if(!n||!m)return {text:normBn(trans),count:0,changes:[],err:"ট্রান্সক্রিপ্ট ও মূল লেখা — দুটোই দরকার।"};
 if(n>1500||m>5000)return {text:trans,count:0,changes:[],err:"লেখা বেশি বড়; অংশে ভাগ করে মেলাও।"};
 var a=A.map(splitTok),b=B.map(splitTok);
 var W=m+1,D=new Float32Array((n+1)*W),T=new Uint8Array((n+1)*W);
 var GA=.8,GB=.7,i,j;
 for(i=1;i<=n;i++){D[i*W]=i*GA;T[i*W]=2}
 function cost(x,y){if(x===y)return 0;var r=lev(x,y)/Math.max(x.length,y.length);return r<=.6?r:1.2}
 for(i=1;i<=n;i++){for(j=1;j<=m;j++){
  var s=D[(i-1)*W+j-1]+cost(a[i-1][1],b[j-1][1]),da=D[(i-1)*W+j]+GA,db=D[i*W+j-1]+GB,v=s,t=0;
  if(da<v){v=da;t=2}if(db<v){v=db;t=3}D[i*W+j]=v;T[i*W+j]=t}}
 var bj=0,bv=Infinity;for(j=0;j<=m;j++){if(D[n*W+j]<bv){bv=D[n*W+j];bj=j}}
 i=n;j=bj;var fix=[],cnt=0,ch=[];
 while(i>0){
  var t2=T[i*W+j];
  if(j>0&&t2===0){var x=a[i-1][1],y=b[j-1][1];if(x!==y&&lev(x,y)/Math.max(x.length,y.length)<=.6){fix[i-1]=y;cnt++;ch.push({from:x,to:y,count:1})}i--;j--}
  else if(t2===2||j===0){i--}
  else{j--}
 }
 var out=[];for(i=0;i<n;i++){out.push(a[i][0]+(fix[i]!==undefined?fix[i]:a[i][1])+a[i][2])}
 return {text:out.join(" "),count:cnt,changes:ch};
}
function wordCount(t){var m=String(t||"").trim().split(/\s+/);return (m.length===1&&m[0]==="")?0:m.length}

/* বাক্যে ভাগ (পড়ে শোনানোর জন্য) */
function splitSentences(t,max){
 max=max||220;
 var parts=String(t||"").replace(/\r/g,"").replace(/([।?!॥])\s*/g,"$1\n").split(/\n+/),out=[],cur="";
 function push(s){s=s.trim();if(s)out.push(s)}
 parts.forEach(function(p){
  p=p.trim();if(!p)return;
  while(p.length>max){
   var cut=p.lastIndexOf(",",max);if(cut<max*.4)cut=p.lastIndexOf("،",max);if(cut<max*.4)cut=p.lastIndexOf(" ",max);if(cut<=0)cut=max;
   push(cur);cur="";push(p.slice(0,cut+1));p=p.slice(cut+1).trim();
  }
  if((cur+" "+p).trim().length<=max&&cur&&cur.length<60){cur=(cur+" "+p).trim()}else{push(cur);cur=p}
 });
 push(cur);return out;
}
/* PDF টেক্সট আইটেম থেকে লাইন সাজানো */
function itemsToText(items){
 var rows=[],i;
 for(i=0;i<items.length;i++){var it=items[i];if(!it.str&&it.str!==" ")continue;var y=it.transform[5],x=it.transform[4];
  var r=null;for(var k=rows.length-1;k>=0&&k>=rows.length-6;k--){if(Math.abs(rows[k].y-y)<3){r=rows[k];break}}
  if(!r){r={y:y,its:[]};rows.push(r)}r.its.push({x:x,w:it.width||0,s:it.str})}
 rows.sort(function(a,b){return b.y-a.y});
 return rows.map(function(r){r.its.sort(function(a,b){return a.x-b.x});var o="",end=null;
  r.its.forEach(function(t){if(end!==null&&t.x-end>1.2&&o.slice(-1)!==" "&&t.s.charAt(0)!==" ")o+=" ";o+=t.s;end=t.x+t.w});return o.trim()}).filter(Boolean).join("\n");
}

/* অডিও */
function removeRanges(x,sr,ranges,fadeMs){
 if(!ranges||!ranges.length)return x;
 var r=ranges.map(function(p){return [Math.max(0,Math.floor(p[0]*sr)),Math.min(x.length,Math.floor(p[1]*sr))]}).filter(function(p){return p[1]>p[0]}).sort(function(a,b){return a[0]-b[0]});
 var mg=[];for(var i=0;i<r.length;i++){if(mg.length&&r[i][0]<=mg[mg.length-1][1])mg[mg.length-1][1]=Math.max(mg[mg.length-1][1],r[i][1]);else mg.push(r[i].slice())}
 var keep=[],pos=0;for(var k=0;k<mg.length;k++){if(mg[k][0]>pos)keep.push([pos,mg[k][0]]);pos=mg[k][1]}
 if(pos<x.length)keep.push([pos,x.length]);
 var tot=0;keep.forEach(function(p){tot+=p[1]-p[0]});
 var o=new Float32Array(tot),w=0,f=Math.max(1,Math.floor(sr*(fadeMs||15)/1000));
 keep.forEach(function(p,idx){
  for(var s=p[0];s<p[1];s++){
   var g=1,a=s-p[0],b=p[1]-1-s;
   if(idx>0&&a<f)g*=a/f;
   if(idx<keep.length-1&&b<f)g*=b/f;
   o[w++]=x[s]*g}
 });
 return o;
}
function denoiseGate(x,sr,level){
 var P={low:{k:1.8,att:.35},mid:{k:2.6,att:.2},high:{k:3.6,att:.1}}[level]||{k:2.6,att:.2};
 var fl=Math.max(1,Math.round(sr*.02)),nf=Math.floor(x.length/fl);
 if(nf<5)return {floor:0,thr:0,gated:0};
 var rms=new Float32Array(nf),i,j;
 for(i=0;i<nf;i++){var s=0;for(j=0;j<fl;j++){var v=x[i*fl+j];s+=v*v}rms[i]=Math.sqrt(s/fl)}
 var sorted=Array.prototype.slice.call(rms).sort(function(a,b){return a-b});
 var floor=sorted[Math.floor(nf*.2)]+1e-5,thr=floor*P.k;
 var tg=new Float32Array(nf),hold=0,gated=0;
 for(i=0;i<nf;i++){if(rms[i]>=thr){hold=5;tg[i]=1}else if(hold>0){hold--;tg[i]=1}else{tg[i]=P.att;gated++}}
 var g=1,ac=1-Math.exp(-1/(sr*.005)),rc=1-Math.exp(-1/(sr*.08));
 for(i=0;i<nf*fl;i++){var t=tg[Math.floor(i/fl)];g+=(t-g)*(t>g?ac:rc);x[i]*=g}
 return {floor:floor,thr:thr,gated:gated/nf};
}
function normalize(x,peak){var m=0,i;for(i=0;i<x.length;i++){var a=Math.abs(x[i]);if(a>m)m=a}if(m<1e-6)return;var g=(peak||.89)/m;for(i=0;i<x.length;i++)x[i]*=g}
function peaksOf(x,n){var o=[],step=Math.max(1,Math.floor(x.length/n));for(var i=0;i<n;i++){var m=0,s=i*step,e=Math.min(x.length,s+step);for(var j=s;j<e;j++){var a=Math.abs(x[j]);if(a>m)m=a}o.push(Math.round(m*1000)/1000)}return o}
function encodeWav(x,sr){
 var n=x.length,buf=new ArrayBuffer(44+n*2),v=new DataView(buf);
 function ws(o,s){for(var i=0;i<s.length;i++)v.setUint8(o+i,s.charCodeAt(i))}
 ws(0,"RIFF");v.setUint32(4,36+n*2,true);ws(8,"WAVE");ws(12,"fmt ");v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,1,true);
 v.setUint32(24,sr,true);v.setUint32(28,sr*2,true);v.setUint16(32,2,true);v.setUint16(34,16,true);ws(36,"data");v.setUint32(40,n*2,true);
 for(var i=0;i<n;i++){var s=Math.max(-1,Math.min(1,x[i]));v.setInt16(44+i*2,s<0?s*32768:s*32767,true)}
 return buf;
}
var API={SPELL:SPELL,normBn:normBn,parseDict:parseDict,spellFix:spellFix,alignFix:alignFix,lev:lev,wordCount:wordCount,splitSentences:splitSentences,itemsToText:itemsToText,removeRanges:removeRanges,denoiseGate:denoiseGate,normalize:normalize,peaksOf:peaksOf,encodeWav:encodeWav};
if(typeof module!=="undefined"&&module.exports)module.exports=API;else root.Core=API;
})(typeof window!=="undefined"?window:this);
