# Neon Arena Tic Tac Toe — AdMob integration

This project adds an Android native Banner ad and Interstitial ad bridge to the existing bundled HTML game.

## Important IDs note

The Android App ID supplied and formatted by the developer is `ca-app-pub-5189608370433826~9544631680`, now set in `AndroidManifest.xml`. Verify it matches the Android app entry in your AdMob account before release.

Provided production Ad Unit IDs are stored in `MainActivity.java`:
- Banner: `ca-app-pub-5189608370433826/6569490694`
- Interstitial: `ca-app-pub-5189608370433826/4100733317`

`USE_TEST_ADS = true` by default, so only Google's test ad units are requested during development. After the correct App ID is inserted and the integration is tested, set `USE_TEST_ADS = false` for a release build. Never click live ads while testing.

## What was added
- Google Mobile Ads SDK dependency.
- Bottom anchored adaptive Banner AdView.
- Interstitial ad loading/reloading and a JavaScript bridge (`NeonAds.showInterstitial()`).
- HTML calls the bridge only when a completed round is followed by `NEW ROUND`, or when the player advances/retries a completed Level Mode round.
- If an interstitial is not ready, gameplay continues without an ad.

## Build
1. Open this folder (`tictactoe_android`) in Android Studio.
2. Ensure Android SDK Platform 35 and a compatible JDK/Gradle setup are installed.
3. Sync Gradle and build a debug APK.
4. Test with the default test ads first.

## iOS status
No iOS AdMob IDs were provided, so this project does not include a configured iOS build. iOS requires a separate Xcode project, a valid iOS App ID and iOS Banner/Interstitial Ad Unit IDs, plus a WKWebView-to-Swift bridge.

## Verification status
Source files were edited, but this environment has no Android SDK/Gradle executable available, so the project has **not been compiled or run-tested** here. Treat this as an integration project, not a verified APK.
