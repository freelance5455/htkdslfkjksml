# Build the APK using only your Android phone

1. Download and extract this ZIP on your phone.
2. Open https://github.com and create a new repository.
3. Upload the contents of this extracted project folder to the repository root (including the `.github` folder). The repository root should contain `tictactoe_android/` and its subfolders.
4. Open the repository's Actions tab. Select **Build Neon Arena APK** and tap **Run workflow**.
5. Wait for the run to finish. If it succeeds, open the run and download the `Neon-Arena-debug-APK` artifact. Extract the downloaded artifact ZIP to get the APK.
6. Install the APK on your Android phone. Android may ask permission to install apps from your browser/files app. Only proceed if you trust the APK and understand the source.

## AdMob settings
- Android App ID is configured in `app/src/main/AndroidManifest.xml`.
- Banner and interstitial IDs are in `app/src/main/java/com/rakib/neonarena/MainActivity.java`.
- `USE_TEST_ADS = true` is deliberately enabled for testing. Do not click test or live ads to manipulate ad metrics. After verifying the app works, you may set it to `false` for production ad units.

## Honest status
This repository workflow has not been run from this environment. It may fail if there are source/build errors or dependency issues. The ZIP is source code and a cloud-build workflow, not a compiled APK.
