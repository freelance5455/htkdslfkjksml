package com.rakib.neonarena;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.util.DisplayMetrics;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.AdError;

public class MainActivity extends Activity {
    private WebView webView;
    private AdView bannerView;
    private InterstitialAd interstitialAd;
    private boolean adLoading = false;

    // Keep test ads enabled while developing. Change to false only after testing.
    private static final boolean USE_TEST_ADS = true;

    // User-provided production Ad Unit IDs:
    private static final String LIVE_BANNER_ID = "ca-app-pub-5189608370433826/6569490694";
    private static final String LIVE_INTERSTITIAL_ID = "ca-app-pub-5189608370433826/4100733317";

    // Google's official Android test Ad Unit IDs:
    private static final String TEST_BANNER_ID = "ca-app-pub-3940256099942544/9214589741";
    private static final String TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712";

    private String bannerId() { return USE_TEST_ADS ? TEST_BANNER_ID : LIVE_BANNER_ID; }
    private String interstitialId() { return USE_TEST_ADS ? TEST_INTERSTITIAL_ID : LIVE_INTERSTITIAL_ID; }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(5, 7, 41));
        window.setNavigationBarColor(Color.rgb(5, 7, 41));
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        MobileAds.initialize(this, status -> {});

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(5, 7, 41));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(5, 7, 41));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AdsBridge(), "NeonAds");
        root.addView(webView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        bannerView = new AdView(this);
        bannerView.setAdUnitId(bannerId());
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        int widthDp = (int) (metrics.widthPixels / metrics.density);
        bannerView.setAdSize(AdSize.getLargeAnchoredAdaptiveBannerAdSize(this, widthDp));
        root.addView(bannerView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl("file:///android_asset/index.html");
        }
        bannerView.loadAd(new AdRequest.Builder().build());
        loadInterstitial();
    }

    private void loadInterstitial() {
        if (adLoading || isFinishing()) return;
        adLoading = true;
        InterstitialAd.load(this, interstitialId(), new AdRequest.Builder().build(),
                new InterstitialAdLoadCallback() {
                    @Override public void onAdLoaded(InterstitialAd ad) {
                        adLoading = false;
                        interstitialAd = ad;
                        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                            @Override public void onAdDismissedFullScreenContent() {
                                interstitialAd = null;
                                loadInterstitial();
                            }
                            @Override public void onAdFailedToShowFullScreenContent(AdError error) {
                                interstitialAd = null;
                                loadInterstitial();
                            }
                        });
                    }
                    @Override public void onAdFailedToLoad(LoadAdError error) {
                        adLoading = false;
                        interstitialAd = null;
                    }
                });
    }

    private void showInterstitial() {
        if (interstitialAd != null && !isFinishing()) {
            InterstitialAd readyAd = interstitialAd;
            interstitialAd = null;
            readyAd.show(this);
        }
        // If an ad isn't ready, continue the game without interrupting it.
    }

    private class AdsBridge {
        @JavascriptInterface public void showInterstitial() {
            runOnUiThread(() -> showInterstitial());
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override protected void onResume() {
        super.onResume();
        if (bannerView != null) bannerView.resume();
    }

    @Override protected void onPause() {
        if (bannerView != null) bannerView.pause();
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (bannerView != null) bannerView.destroy();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
