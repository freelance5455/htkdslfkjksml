/* =========================================================
   admin.js — لوحة إدارة مطعم ومشويات اللهب
   وضع عرض تجريبي: المصادقة والمخزن محليان للعرض فقط.
   الإنتاج الحقيقي: Firebase Auth + Firestore / Supabase + RLS
   مع إعادة حساب الإجماليات وتفويض كل عملية على الخادم.
   ========================================================= */
"use strict";

const $ = sel => document.querySelector(sel);
const $$ = sel => Array.from(document.querySelectorAll(sel));
const SESSION_KEY = "grill_admin_session";

/* صورة بديلة عند فشل التحميل (نفس الموجود في app.js) */
const PLACEHOLDER_IMG = "data:image/svg+xml," + encodeURIComponent(
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300"><rect width="400" height="300" fill="#2C241E"/><path d="M200 60c14 38-28 52-28 90a49 49 0 0 0 98 0c0-19-9-33-19-42 1 14-8 22-16 23 10-19-8-56-35-71z" fill="#F07824"/><text x="200" y="255" font-size="20" fill="#8B8175" text-anchor="middle" font-family="sans-serif">صورة الطبق</text></svg>`
);

let ordFilters = { q: "", status: "", date: "" };
let prodFilter = { q: "", cat: "" };
let selectedOrderId = null;

/* =========================================================
   المصادقة (عرض تجريبي — استبدلها بمصادقة خادمية في الإنتاج)
   ========================================================= */
const DEFAULT_ADMIN_HASH_FALLBACK = null; /* يُحسب أدناه عند أول تشغيل */

async function login(user, pass){
  const s = getSettings();
  if (user.trim().toLowerCase() !== String(s.adminUser || "admin").toLowerCase()) return false;
  const hash = await sha256Hex(pass);
  let expected = s.adminPassHash;
  if (!expected) expected = await sha256Hex("admin123"); /* الافتراضية */
  return hash === expected;
}

function setSession(on){
  try{
    if (on) sessionStorage.setItem(SESSION_KEY, JSON.stringify({ at: Date.now() }));
    else sessionStorage.removeItem(SESSION_KEY);
  }catch(e){}
}
function hasSession(){
  try{
    const raw = sessionStorage.getItem(SESSION_KEY);
    if (!raw) return false;
    const s = JSON.parse(raw);
    /* انتهاء بعد ٨ ساعات */
    return Date.now() - s.at < 8 * 3600 * 1000;
  }catch(e){ return false; }
}

function showLogin(show){
  $("#loginScreen").classList.toggle("hidden", !show);
  $("#shell").classList.toggle("hidden", show);
}

$("#loginForm").addEventListener("submit", async e => {
  e.preventDefault();
  const btn = $("#lgBtn");
  const user = $("#lgUser").value, pass = $("#lgPass").value;
  $("#lgErr").textContent = "";
  btn.classList.add("loading"); btn.disabled = true;
  const ok = await login(user, pass);
  btn.classList.remove("loading"); btn.disabled = false;
  if (ok){
    setSession(true);
    showLogin(false);
    bootShell();
    admToast("أهلاً بك في لوحة الإدارة 👋", "ok");
  } else {
    $("#lgErr").textContent = "بيانات الدخول غير صحيحة.";
  }
});

$("#logoutBtn").addEventListener("click", () => {
  setSession(false);
  showLogin(true);
});

/* =========================================================
   التبويبات
   ========================================================= */
$$(".adm-tab").forEach(t => t.addEventListener("click", () => {
  $$(".adm-tab").forEach(x => x.classList.remove("active"));
  t.classList.add("active");
  $$(".adm-panel").forEach(p => p.classList.add("hidden"));
  $("#panel-" + t.dataset.tab).classList.remove("hidden");
  if (t.dataset.tab === "dashboard") renderDashboard();
  if (t.dataset.tab === "orders") renderOrdersAdmin();
  if (t.dataset.tab === "products") renderProductsAdmin();
  if (t.dataset.tab === "categories") renderCatsAdmin();
  if (t.dataset.tab === "coupons") renderCouponsAdmin();
  if (t.dataset.tab === "inventory") renderInventory();
  if (t.dataset.tab === "settings") renderSettings();
}));

function bootShell(){
  $("#admRestName").textContent = getSettings().restaurantName;
  renderDashboard();
  renderAlerts();
}

/* =========================================================
   لوحة التحكم
   ========================================================= */
function rangeStart(){
  const v = $("#statRange").value;
  if (v === "all") return 0;
  if (v === "today"){ const d = new Date(); d.setHours(0,0,0,0); return d.getTime(); }
  return Date.now() - Number(v) * 86400000;
}

function renderDashboard(){
  const from = rangeStart();
  const orders = getOrders().filter(o => o.createdAt >= from);
  const by = st => orders.filter(o => o.status === st).length;
  const revenue = orders.filter(o => o.status !== "cancelled")
    .reduce((n, o) => n + o.pricing.total, 0);

  $("#statGrid").innerHTML = `
    <div class="stat-card"><div class="stat-num">${orders.length}</div><div class="stat-lbl">إجمالي الطلبات</div></div>
    <div class="stat-card warn"><div class="stat-num">${by("received")}</div><div class="stat-lbl">طلبات جديدة</div></div>
    <div class="stat-card"><div class="stat-num">${by("confirmed") + by("preparing")}</div><div class="stat-lbl">قيد التأكيد والتحضير</div></div>
    <div class="stat-card ok"><div class="stat-num">${by("delivered")}</div><div class="stat-lbl">تم تسليمها</div></div>
    <div class="stat-card warn"><div class="stat-num">${by("cancelled")}</div><div class="stat-lbl">ملغاة</div></div>
    <div class="stat-card"><div class="stat-num">${fmtMoney(revenue)}</div><div class="stat-lbl">إجمالي المبيعات</div></div>`;

  /* الأكثر مبيعاً — محسوبة من الطلبات الفعلية */
  const counts = {};
  orders.filter(o => o.status !== "cancelled").forEach(o =>
    o.items.forEach(i => { counts[i.name] = (counts[i.name] || 0) + i.qty; }));
  const top = Object.entries(counts).sort((a,b) => b[1] - a[1]).slice(0, 6);
  $("#bestSellers").innerHTML = top.length
    ? top.map(([name, qty], i) => `
      <div class="best-row">
        <span class="best-rank">${i + 1}</span>
        <span class="n">${escapeHtml(name)}</span>
        <span class="c">${qty} طلب صنف</span>
      </div>`).join("")
    : `<p class="empty-note">لا توجد بيانات مبيعات في هذه الفترة بعد.</p>`;

  /* آخر الطلبات */
  const recent = getOrders().slice(0, 6);
  $("#recentOrdersMini").innerHTML = recent.length
    ? recent.map(o => {
        const st = statusInfo(o.status);
        return `
        <div class="mini-order">
          <div><span class="ref">${o.ref}</span><span class="t"> · ${fmtDate(o.createdAt)}</span></div>
          <div style="display:flex;gap:8px;align-items:center">
            <b>${fmtMoney(o.pricing.total)}</b>
            <span class="status-pill st-${st.id}">${st.label}</span>
          </div>
        </div>`;
      }).join("")
    : `<p class="empty-note">لا توجد طلبات بعد.</p>`;

  renderCancelRequests();
}

function renderCancelRequests(){
  const reqs = getOrders().filter(o => o.cancellationRequested && o.status !== "cancelled");
  $("#cancelReqCard").hidden = reqs.length === 0;
  $("#cancelReqList").innerHTML = reqs.map(o => `
    <div class="mini-order">
      <div><span class="ref">${o.ref}</span><span class="t"> · ${escapeHtml(o.customer.name)}</span></div>
      <div class="ord-actions">
        <button class="btn btn-sm btn-success" data-adm="cancel-approve" data-id="${o.id}">موافقة على الإلغاء</button>
        <button class="btn btn-sm btn-outline" data-adm="cancel-reject" data-id="${o.id}">رفض الطلب ومتابعة التحضير</button>
      </div>
    </div>`).join("");
}

function renderAlerts(){
  const newOrders = getOrders().filter(o => o.status === "received" && !o.seenByAdmin).length;
  const cancelReq = getOrders().filter(o => o.cancellationRequested && o.status !== "cancelled").length;
  const lowStock = getProducts().filter(p => p.trackStock && p.stock !== null && p.stock <= (p.lowStock || 5)).length;
  const set = (id, n) => { const el = $(id); el.textContent = n; el.classList.toggle("hidden", !n); };
  set("#ordersAlert", newOrders + cancelReq);
  set("#invAlert", lowStock);
}

/* =========================================================
   الطلبات — إدارة
   ========================================================= */
function filteredOrders(){
  return getOrders().filter(o => {
    if (ordFilters.status && o.status !== ordFilters.status) return false;
    if (ordFilters.date){
      const d = new Date(o.createdAt);
      const iso = d.getFullYear() + "-" + String(d.getMonth()+1).padStart(2,"0") + "-" + String(d.getDate()).padStart(2,"0");
      if (iso !== ordFilters.date) return false;
    }
    if (ordFilters.q){
      const q = ordFilters.q.toLowerCase();
      const hay = (o.ref + " " + o.customer.name + " " + o.customer.phone).toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });
}

function renderOrdersAdmin(){
  const list = filteredOrders();
  const box = $("#ordersTable");
  if (!list.length){
    box.innerHTML = `<p class="empty-note">لا توجد طلبات مطابقة للفلاتر.</p>`;
    return;
  }
  box.innerHTML = list.map(o => {
    const st = statusInfo(o.status);
    const nextId = nextStatusId(o.status);
    return `
    <div class="ord-row ${o.cancellationRequested && o.status !== "cancelled" ? "cancel-requested" : ""}">
      <span class="ord-ref">${o.ref}</span>
      <div class="ord-meta">
        <b>${escapeHtml(o.customer.name)}</b> · ${escapeHtml(o.customer.phone)}
        <span class="t" style="display:block">${o.type === "delivery" ? "🛵 توصيل" : "🏪 استلام"} · ${fmtDate(o.createdAt)} · ${o.items.reduce((n,i)=>n+i.qty,0)} صنف</span>
        ${o.cancellationRequested && o.status !== "cancelled" ? '<span style="color:#ff8589;font-weight:700">⏳ طلب إلغاء من العميل</span>' : ""}
      </div>
      <span class="status-pill st-${st.id}">${st.label}</span>
      <span class="ord-total">${fmtMoney(o.pricing.total)}</span>
      <div class="ord-actions">
        <button class="btn btn-sm btn-outline" data-adm="order-details" data-id="${o.id}">تفاصيل</button>
        ${nextId ? `<button class="btn btn-sm btn-primary" data-adm="order-advance" data-id="${o.id}">${statusInfo(nextId).icon} ${statusInfo(nextId).label}</button>` : ""}
        ${!["delivered","cancelled"].includes(o.status) ? `<button class="btn btn-sm btn-danger" data-adm="order-cancel" data-id="${o.id}">إلغاء</button>` : ""}
        <button class="btn btn-sm btn-outline" data-adm="kitchen-ticket" data-id="${o.id}">🖨️</button>
      </div>
    </div>`;
  }).join("");
}

function nextStatusId(cur){
  const i = statusIndex(cur);
  if (i < 0 || i >= ORDER_STATUSES.length - 1) return null;
  return ORDER_STATUSES[i + 1].id;
}

function advanceOrder(id){
  const orders = getOrders();
  const o = orders.find(x => x.id === id);
  if (!o) return;
  let next = nextStatusId(o.status);
  if (!next) return;
  /* طلبات الاستلام تتجاوز مرحلة «خرج للتوصيل» */
  if (o.type === "pickup" && next === "out") next = "delivered";
  o.status = next;
  o.statusHistory.push({ status: o.status, at: Date.now() });
  o.seenByAdmin = true;
  saveOrders(orders);
  admToast(`تم تحديث الطلب ${o.ref} إلى: ${statusInfo(o.status).label}`, "ok");
  renderOrdersAdmin(); renderAlerts(); renderDashboard();
}

function cancelOrderAdmin(id){
  const reason = prompt("سبب الإلغاء (سيظهر للعميل):", "");
  if (reason === null) return;
  const orders = getOrders();
  const o = orders.find(x => x.id === id);
  if (!o) return;
  o.status = "cancelled";
  o.cancelReason = reason || "بدون سبب محدد";
  o.statusHistory.push({ status: "cancelled", at: Date.now() });
  saveOrders(orders);
  admToast(`تم إلغاء الطلب ${o.ref}`, "ok");
  renderOrdersAdmin(); renderAlerts(); renderDashboard();
}

function showOrderDetails(id){
  const orders = getOrders();
  const o = orders.find(x => x.id === id);
  if (!o) return;
  o.seenByAdmin = true;
  saveOrders(orders);
  const st = statusInfo(o.status);
  openAdmModal("تفاصيل الطلب " + o.ref, `
    <div class="ord-detail">
      <div class="grid2">
        <span>👤 <b>${escapeHtml(o.customer.name)}</b></span>
        <span dir="ltr">📞 ${escapeHtml(o.customer.phone)}</span>
        <span>${o.type === "delivery" ? "🛵 توصيل" : "🏪 استلام من المطعم"}</span>
        <span>💵 ${paymentLabel(o.payment)}</span>
        <span>🕒 ${fmtDate(o.createdAt)}</span>
        <span><span class="status-pill st-${st.id}">${st.label}</span></span>
      </div>
      ${o.type === "delivery" ? `<p style="margin:10px 0 0;font-size:.86rem">📍 <b>${escapeHtml(o.customer.address)}</b> — ${escapeHtml(o.customer.zoneName || "")}</p>` : ""}
      ${o.customer.notes ? `<p style="margin:8px 0 0;font-size:.86rem">📝 ${escapeHtml(o.customer.notes)}</p>` : ""}
      ${o.cancellationRequested && o.status !== "cancelled" ? `<p style="margin:8px 0 0;color:#ff8589;font-weight:700">⏳ العميل طلب إلغاء هذا الطلب</p>` : ""}
      ${o.cancelReason ? `<p style="margin:8px 0 0;color:#ff8589">سبب الإلغاء: ${escapeHtml(o.cancelReason)}</p>` : ""}
    </div>
    <div class="ord-detail">
      <h4>الأصناف</h4>
      <ul class="detail-items">
        ${o.items.map(i => `<li>${i.qty}× ${escapeHtml(i.name)}${i.sizeName ? ` — ${escapeHtml(i.sizeName)}` : ""}${i.extras && i.extras.length ? ` <span style="color:var(--muted)">(+ ${escapeHtml(i.extras.map(e=>e.name).join(" + "))})</span>` : ""}${i.notes ? ` <span style="color:var(--orange-soft)">📝 ${escapeHtml(i.notes)}</span>` : ""} — <b>${fmtMoney(i.unitPrice * i.qty)}</b></li>`).join("")}
      </ul>
      <div class="grid2" style="margin-top:10px">
        <span>المجموع الفرعي: <b>${fmtMoney(o.pricing.subtotal)}</b></span>
        ${o.pricing.discount ? `<span style="color:#8fe69c">الخصم${o.couponCode ? " (" + escapeHtml(o.couponCode) + ")" : ""}: <b>− ${fmtMoney(o.pricing.discount)}</b></span>` : ""}
        <span>التوصيل: <b>${o.type === "delivery" ? fmtMoney(o.pricing.deliveryFee) : "مجاني"}</b></span>
        <span>الإجمالي: <b style="color:var(--orange-soft)">${fmtMoney(o.pricing.total)}</b></span>
      </div>
    </div>
    <div class="ord-detail">
      <h4>سجل الحالة</h4>
      <ul>${o.statusHistory.map(h => `<li>${statusInfo(h.status).label} — ${fmtDate(h.at)}</li>`).join("")}</ul>
    </div>`,
    [{ label: "طباعة تذكرة المطبخ", cls: "btn-outline", fn: () => kitchenTicket(o.id) },
     { label: "إغلاق", cls: "btn-primary", fn: null }]
  );
}

function paymentLabel(p){
  return { cod: "كاش عند التوصيل", pickupCash: "كاش عند الاستلام", electronic: "دفع إلكتروني" }[p] || p;
}

/* تذكرة المطبخ */
function kitchenTicket(id){
  const o = getOrders().find(x => x.id === id);
  if (!o) return;
  const s = getSettings();
  const w = window.open("", "_blank", "width=380,height=600");
  if (!w){ admToast("متصفحك منع النوافذ المنبثقة", "err"); return; }
  w.document.write(`<html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>تذكرة ${o.ref}</title>
  <style>body{font-family:'Tajawal',Arial,sans-serif;padding:14px;color:#000}
  h1{font-size:19px;margin:0;text-align:center}h2{font-size:16px;text-align:center;margin:6px 0}
  .meta{text-align:center;font-size:13px;margin-bottom:8px}
  table{width:100%;border-collapse:collapse;font-size:15px}
  td{padding:7px 4px;border-bottom:1px solid #999;vertical-align:top}
  .qty{font-weight:900;width:34px;font-size:17px}
  .notes{color:#b33000;font-size:12px}.small{font-size:12px;color:#444}
  @media print{body{font-size:14px}}</style></head><body>
  <h1>${escapeHtml(s.restaurantName)}</h1>
  <h2>تذكرة مطبخ</h2>
  <div class="meta"><b>${o.ref}</b> — ${fmtDate(o.createdAt)}<br>
  ${o.type === "delivery" ? "🛵 توصيل: " + escapeHtml(o.customer.address) : "🏪 استلام"}<br>
  ${o.customer.notes ? "📝 " + escapeHtml(o.customer.notes) : ""}</div>
  <table>${o.items.map(i => `
    <tr><td class="qty">${i.qty}×</td><td>
      <b>${escapeHtml(i.name)}</b>${i.sizeName ? `<div class="small">الحجم: ${escapeHtml(i.sizeName)}</div>` : ""}
      ${i.extras && i.extras.length ? `<div class="small">إضافات: ${escapeHtml(i.extras.map(e=>e.name).join(" + "))}</div>` : ""}
      ${i.notes ? `<div class="notes">ملاحظة: ${escapeHtml(i.notes)}</div>` : ""}
    </td></tr>`).join("")}
  </table>
  <p class="meta" style="margin-top:10px">الإجمالي: <b>${fmtMoney(o.pricing.total)}</b> · ${paymentLabel(o.payment)}</p>
  </body></html>`);
  w.document.close();
  setTimeout(() => w.print(), 350);
}

/* تصدير CSV */
function exportCsv(){
  const orders = filteredOrders();
  if (!orders.length){ admToast("لا توجد طلبات للتصدير", "err"); return; }
  const rows = [["رقم الطلب","التاريخ","الحالة","النوع","العميل","الموبايل","العنوان","الأصناف","المجموع الفرعي","الخصم","التوصيل","الإجمالي","طريقة الدفع"]];
  orders.forEach(o => rows.push([
    o.ref, fmtDate(o.createdAt), statusInfo(o.status).label,
    o.type === "delivery" ? "توصيل" : "استلام",
    o.customer.name, o.customer.phone, o.customer.address || "",
    o.items.map(i => `${i.qty}x ${i.name}${i.sizeName ? " (" + i.sizeName + ")" : ""}`).join(" | "),
    o.pricing.subtotal, o.pricing.discount, o.pricing.deliveryFee, o.pricing.total, paymentLabel(o.payment)
  ]));
  const csv = "\uFEFF" + rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
  a.download = "orders-" + new Date().toISOString().slice(0, 10) + ".csv";
  a.click();
  URL.revokeObjectURL(a.href);
  admToast(`تم تصدير ${orders.length} طلب`, "ok");
}

/* =========================================================
   المنتجات — إدارة
   ========================================================= */
function renderProductsAdmin(){
  const cats = getCategories();
  const sel = $("#prodCatFilter");
  if (sel.options.length <= 1)
    sel.innerHTML = `<option value="">كل الأقسام</option>` + cats.map(c => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join("");

  let prods = getProducts();
  if (prodFilter.cat) prods = prods.filter(p => p.cat === prodFilter.cat);
  if (prodFilter.q){
    const q = prodFilter.q.toLowerCase();
    prods = prods.filter(p => p.name.toLowerCase().includes(q));
  }

  const box = $("#productsTable");
  if (!prods.length){ box.innerHTML = `<p class="empty-note">لا توجد أصناف مطابقة.</p>`; return; }
  box.innerHTML = prods.map(p => {
    const c = cats.find(c => c.id === p.cat);
    return `
    <div class="tbl-row ${p.available ? "" : "dim"}">
      <img class="tbl-img" src="${p.img || PLACEHOLDER_IMG}" alt="" onerror="this.src='${PLACEHOLDER_IMG}'">
      <div class="tbl-main">
        <div class="t-name">${escapeHtml(p.name)}</div>
        <div class="t-sub">${c ? escapeHtml(c.name) : "؟"} · ${p.prepTime || ""}</div>
        <div class="badge-flags">
          ${p.featured ? '<span class="flag">مميز</span>' : ""}
          ${p.bestSeller ? '<span class="flag gold">الأكثر مبيعاً</span>' : ""}
          ${p.trackStock ? `<span class="flag ${p.stock <= (p.lowStock || 5) ? "gold" : ""}">مخزون: ${p.stock}</span>` : ""}
        </div>
      </div>
      <span class="tbl-price">${fmtMoney(p.price)}${p.oldPrice ? `<s style="font-size:.72rem;color:var(--muted);margin-inline-start:5px">${fmtMoney(p.oldPrice)}</s>` : ""}</span>
      <label class="switch" title="متاح / غير متاح">
        <input type="checkbox" data-adm="prod-avail" data-id="${p.id}" ${p.available ? "checked" : ""}>
        <span class="sl"></span>
      </label>
      <div class="tbl-actions">
        <button class="btn btn-sm btn-outline" data-adm="prod-edit" data-id="${p.id}">تعديل</button>
        <button class="btn btn-sm btn-danger" data-adm="prod-del" data-id="${p.id}">حذف</button>
      </div>
    </div>`;
  }).join("");
}

function productForm(p){
  const cats = getCategories();
  p = p || { id: null, cat: cats[0]?.id, name: "", desc: "", price: 0, oldPrice: null, img: "", available: true, sizes: [], extras: [], prepTime: "٢٥ د", featured: false, bestSeller: false, trackStock: false, stock: null, lowStock: 5 };
  openAdmModal(p.id ? "تعديل صنف" : "إضافة صنف جديد", `
    <div class="field"><label>اسم الصنف <b>*</b></label><input id="fName" value="${escapeHtml(p.name)}"></div>
    <div class="field"><label>الوصف</label><textarea id="fDesc" rows="2">${escapeHtml(p.desc || "")}</textarea></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="field"><label>القسم</label>
        <select id="fCat">${cats.map(c => `<option value="${c.id}" ${c.id === p.cat ? "selected" : ""}>${escapeHtml(c.name)}</option>`).join("")}</select>
      </div>
      <div class="field"><label>وقت التحضير</label><input id="fPrep" value="${escapeHtml(p.prepTime || "")}" placeholder="٢٥ د"></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="field"><label>السعر (ج.م) <b>*</b></label><input id="fPrice" type="number" min="0" step="0.5" value="${p.price ?? ""}"></div>
      <div class="field"><label>السعر قبل الخصم (اختياري)</label><input id="fOld" type="number" min="0" step="0.5" value="${p.oldPrice ?? ""}"></div>
    </div>
    <div class="field"><label>رابط صورة الصنف</label>
      <img class="img-preview" id="fImgPrev" src="${p.img || PLACEHOLDER_IMG}" onerror="this.src='${PLACEHOLDER_IMG}'">
      <input id="fImg" value="${escapeHtml(p.img || "")}" placeholder="https://… أو ارفع صورة" dir="ltr">
      <label class="btn btn-outline btn-sm" style="margin-top:8px;cursor:pointer">📁 رفع صورة من الجهاز
        <input type="file" id="fImgFile" accept="image/*" hidden>
      </label>
    </div>
    <div class="field"><label>الأحجام / المقاسات (اختياري)</label>
      <div id="fSizes"></div>
      <button type="button" class="btn btn-outline btn-sm" data-adm="add-size">+ حجم</button>
    </div>
    <div class="field"><label>الإضافات (اختياري)</label>
      <div id="fExtras"></div>
      <button type="button" class="btn btn-outline btn-sm" data-adm="add-extra">+ إضافة</button>
    </div>
    <div class="set-row"><span class="lbl">متاح للطلب<span class="sub">عند الإيقاف لا يظهر للعملاء كمتاح</span></span>
      <label class="switch"><input type="checkbox" id="fAvail" ${p.available ? "checked" : ""}><span class="sl"></span></label></div>
    <div class="set-row"><span class="lbl">صنف مميز</span>
      <label class="switch"><input type="checkbox" id="fFeat" ${p.featured ? "checked" : ""}><span class="sl"></span></label></div>
    <div class="set-row"><span class="lbl">الأكثر مبيعاً</span>
      <label class="switch"><input type="checkbox" id="fBest" ${p.bestSeller ? "checked" : ""}><span class="sl"></span></label></div>
    <div class="set-row"><span class="lbl">تتبع المخزون<span class="sub">خصم تلقائي مع الطلبات المؤكدة + تعليم تلقائي عند الصفر</span></span>
      <label class="switch"><input type="checkbox" id="fTrack" ${p.trackStock ? "checked" : ""}><span class="sl"></span></label></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="field"><label>الكمية الحالية</label><input id="fStock" type="number" min="0" value="${p.stock ?? ""}"></div>
      <div class="field"><label>حد التنبيه</label><input id="fLow" type="number" min="0" value="${p.lowStock ?? 5}"></div>
    </div>
    <span class="field-err" id="fErr"></span>
  `, [
    { label: "إلغاء", cls: "btn-outline", fn: null },
    { label: p.id ? "حفظ التعديلات" : "إضافة الصنف", cls: "btn-primary", fn: () => saveProductForm(p.id) }
  ]);

  /* repeaters */
  const sizesBox = $("#fSizes"), extrasBox = $("#fExtras");
  const sizeRow = s => `
    <div class="rep-row">
      <input placeholder="اسم الحجم (نص كيلو)" value="${escapeHtml(s.name || "")}" data-f="size-name">
      <input class="delta" type="number" step="1" placeholder="فرق السعر" value="${s.delta ?? 0}" data-f="size-delta">
      <button type="button" class="btn btn-sm btn-danger" data-adm="rep-del">✕</button>
    </div>`;
  const extraRow = e => `
    <div class="rep-row">
      <input placeholder="اسم الإضافة" value="${escapeHtml(e.name || "")}" data-f="ex-name">
      <input class="delta" type="number" step="0.5" placeholder="السعر" value="${e.price ?? 0}" data-f="ex-price">
      <button type="button" class="btn btn-sm btn-danger" data-adm="rep-del">✕</button>
    </div>`;
  (p.sizes || []).forEach(s => sizesBox.insertAdjacentHTML("beforeend", sizeRow(s)));
  (p.extras || []).forEach(e => extrasBox.insertAdjacentHTML("beforeend", extraRow(e)));
  $("#admModal").dataset.mode = p.id ? "edit" : "new";
  $("#admModal").dataset.pid = p.id || "";

  $("#fImg").addEventListener("input", () => { $("#fImgPrev").src = $("#fImg").value || PLACEHOLDER_IMG; });
  $("#fImgFile").addEventListener("change", e => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 250 * 1024){ $("#fErr").textContent = "الصورة أكبر من 250KB — اختر صورة أصغر أو استخدم رابطاً."; return; }
    const reader = new FileReader();
    reader.onload = () => { $("#fImg").value = reader.result; $("#fImgPrev").src = reader.result; };
    reader.readAsDataURL(file);
  });
}

function collectRepeater(boxId, nameAttr, priceAttr){
  return $$(boxId + " .rep-row").map(row => ({
    name: row.querySelector(`[data-f="${nameAttr}"]`).value.trim(),
    price: Number(row.querySelector(`[data-f="${priceAttr}"]`).value) || 0,
    delta: Number(row.querySelector(`[data-f="${priceAttr}"]`).value) || 0
  })).filter(x => x.name);
}

function saveProductForm(pid){
  const name = $("#fName").value.trim();
  const price = Number($("#fPrice").value);
  if (name.length < 2){ $("#fErr").textContent = "اكتب اسم الصنف."; return; }
  if (!(price > 0)){ $("#fErr").textContent = "اكتب سعراً صحيحاً أكبر من صفر."; return; }

  const sizesRaw = $$("#fSizes .rep-row").map(row => ({
    id: uid(), name: row.querySelector('[data-f="size-name"]').value.trim(),
    delta: Number(row.querySelector('[data-f="size-delta"]').value) || 0
  })).filter(s => s.name);
  const extrasRaw = $$("#fExtras .rep-row").map(row => ({
    id: uid(), name: row.querySelector('[data-f="ex-name"]').value.trim(),
    price: Number(row.querySelector('[data-f="ex-price"]').value) || 0
  })).filter(x => x.name);

  const prods = getProducts();
  const stockVal = $("#fStock").value === "" ? null : Math.max(0, Number($("#fStock").value));
  const data = {
    cat: $("#fCat").value, name, desc: $("#fDesc").value.trim(),
    price, oldPrice: $("#fOld").value ? Number($("#fOld").value) : null,
    img: $("#fImg").value.trim(), prepTime: $("#fPrep").value.trim() || "٢٥ د",
    available: $("#fAvail").checked, featured: $("#fFeat").checked, bestSeller: $("#fBest").checked,
    trackStock: $("#fTrack").checked, stock: stockVal, lowStock: Number($("#fLow").value) || 5,
    sizes: sizesRaw, extras: extrasRaw
  };

  if (pid){
    const i = prods.findIndex(x => x.id === pid);
    if (i > -1) prods[i] = Object.assign({}, prods[i], data);
    admToast("تم حفظ التعديلات ✓", "ok");
  } else {
    prods.unshift(Object.assign({ id: "p" + uid() }, data));
    admToast("تمت إضافة الصنف ✓", "ok");
  }
  DB.set(DB.K.products, prods);
  closeAdmModal();
  renderProductsAdmin(); renderAlerts();
}

function deleteProduct(id){
  const p = getProducts().find(x => x.id === id);
  admConfirm("حذف الصنف", `هل تريد حذف «${p ? p.name : ""}» نهائياً؟`, () => {
    DB.set(DB.K.products, getProducts().filter(x => x.id !== id));
    admToast("تم حذف الصنف", "ok");
    renderProductsAdmin();
  });
}

function toggleProductAvail(id, checked){
  const prods = getProducts();
  const p = prods.find(x => x.id === id);
  if (p){ p.available = checked; DB.set(DB.K.products, prods); }
  admToast(checked ? "الصنف متاح الآن" : "الصنف غير متاح مؤقتاً", "ok");
}

/* =========================================================
   الأقسام — إدارة
   ========================================================= */
function renderCatsAdmin(){
  const cats = getCategories().slice().sort((a,b) => (a.sort||0)-(b.sort||0));
  $("#catsTable").innerHTML = cats.map(c => `
    <div class="tbl-row">
      <span style="font-size:1.4rem">${c.emoji || "🍽️"}</span>
      <div class="tbl-main">
        <div class="t-name">${escapeHtml(c.name)}</div>
        <div class="t-sub">${getProducts().filter(p => p.cat === c.id).length} صنف</div>
      </div>
      <div class="tbl-actions">
        <button class="btn btn-sm btn-outline" data-adm="cat-edit" data-id="${c.id}">تعديل</button>
        <button class="btn btn-sm btn-danger" data-adm="cat-del" data-id="${c.id}">حذف</button>
      </div>
    </div>`).join("");
}

function catForm(c){
  c = c || { id: null, name: "", emoji: "🍽️", sort: getCategories().length + 1 };
  openAdmModal(c.id ? "تعديل قسم" : "إضافة قسم", `
    <div class="field"><label>اسم القسم <b>*</b></label><input id="cName" value="${escapeHtml(c.name)}"></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="field"><label>أيقونة (إيموجي)</label><input id="cEmoji" value="${escapeHtml(c.emoji || "")}" maxlength="4"></div>
      <div class="field"><label>الترتيب</label><input id="cSort" type="number" value="${c.sort || 1}"></div>
    </div>
    <span class="field-err" id="cErr"></span>
  `, [
    { label: "إلغاء", cls: "btn-outline", fn: null },
    { label: "حفظ", cls: "btn-primary", fn: () => {
      const name = $("#cName").value.trim();
      if (name.length < 2){ $("#cErr").textContent = "اكتب اسم القسم."; return; }
      const cats = getCategories();
      const data = { name, emoji: $("#cEmoji").value.trim() || "🍽️", sort: Number($("#cSort").value) || 99 };
      if (c.id){
        const i = cats.findIndex(x => x.id === c.id);
        if (i > -1) cats[i] = Object.assign(cats[i], data);
      } else cats.push(Object.assign({ id: "g" + uid() }, data));
      DB.set(DB.K.categories, cats);
      closeAdmModal(); renderCatsAdmin();
      admToast("تم الحفظ ✓", "ok");
    }}
  ]);
}

function deleteCat(id){
  const count = getProducts().filter(p => p.cat === id).length;
  if (count){
    admToast(`لا يمكن حذف القسم — يحتوي ${count} صنف. انقل الأصناف أولاً.`, "err");
    return;
  }
  admConfirm("حذف القسم", "هل تريد حذف هذا القسم؟", () => {
    DB.set(DB.K.categories, getCategories().filter(c => c.id !== id));
    renderCatsAdmin(); admToast("تم حذف القسم", "ok");
  });
}

/* =========================================================
   الكوبونات — إدارة
   ========================================================= */
function renderCouponsAdmin(){
  $("#couponsTable").innerHTML = getCoupons().map(c => `
    <div class="tbl-row ${c.active ? "" : "dim"}">
      <div class="tbl-main">
        <div class="t-name" dir="ltr" style="text-align:right">${escapeHtml(c.code)}</div>
        <div class="t-sub">${c.type === "percent" ? `خصم ${c.value}٪` : c.type === "fixed" ? `خصم ${fmtMoney(c.value)}` : "توصيل مجاني"} · الحد الأدنى ${fmtMoney(c.minOrder)}</div>
      </div>
      <label class="switch" title="نشط / متوقف">
        <input type="checkbox" data-adm="coupon-toggle" data-id="${c.id}" ${c.active ? "checked" : ""}>
        <span class="sl"></span>
      </label>
      <div class="tbl-actions">
        <button class="btn btn-sm btn-outline" data-adm="coupon-edit" data-id="${c.id}">تعديل</button>
        <button class="btn btn-sm btn-danger" data-adm="coupon-del" data-id="${c.id}">حذف</button>
      </div>
    </div>`).join("") || `<p class="empty-note">لا توجد أكواد.</p>`;
}

function couponForm(c){
  c = c || { id: null, code: "", type: "percent", value: 10, minOrder: 100, active: true, note: "" };
  openAdmModal(c.id ? "تعديل كود" : "إضافة كود خصم", `
    <div class="field"><label>الكود (حروف إنجليزية وأرقام) <b>*</b></label>
      <input id="kCode" value="${escapeHtml(c.code)}" dir="ltr" style="text-transform:uppercase"></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="field"><label>النوع</label>
        <select id="kType">
          <option value="percent" ${c.type === "percent" ? "selected" : ""}>نسبة مئوية ٪</option>
          <option value="fixed" ${c.type === "fixed" ? "selected" : ""}>مبلغ ثابت ج.م</option>
          <option value="free_delivery" ${c.type === "free_delivery" ? "selected" : ""}>توصيل مجاني</option>
        </select></div>
      <div class="field"><label>القيمة (٪ أو ج.م)</label><input id="kValue" type="number" min="0" value="${c.value}"></div>
    </div>
    <div class="field"><label>الحد الأدنى للطلب (ج.م)</label><input id="kMin" type="number" min="0" value="${c.minOrder}"></div>
    <div class="field"><label>وصف يظهر للعملاء</label><input id="kNote" value="${escapeHtml(c.note || "")}"></div>
    <div class="set-row"><span class="lbl">نشط</span>
      <label class="switch"><input type="checkbox" id="kActive" ${c.active ? "checked" : ""}><span class="sl"></span></label></div>
    <span class="field-err" id="kErr"></span>
  `, [
    { label: "إلغاء", cls: "btn-outline", fn: null },
    { label: "حفظ", cls: "btn-primary", fn: () => {
      const code = $("#kCode").value.trim().toUpperCase();
      if (!/^[A-Z0-9]{3,15}$/.test(code)){ $("#kErr").textContent = "الكود يجب أن يكون ٣-١٥ حرف/رقم إنجليزي."; return; }
      const cps = getCoupons();
      if (cps.some(x => x.code === code && x.id !== c.id)){ $("#kErr").textContent = "هذا الكود موجود بالفعل."; return; }
      const data = {
        code, type: $("#kType").value,
        value: Number($("#kValue").value) || 0,
        minOrder: Number($("#kMin").value) || 0,
        note: $("#kNote").value.trim(), active: $("#kActive").checked
      };
      if (c.id){
        const i = cps.findIndex(x => x.id === c.id);
        if (i > -1) cps[i] = Object.assign(cps[i], data);
      } else cps.push(Object.assign({ id: "c" + uid() }, data));
      DB.set(DB.K.coupons, cps);
      closeAdmModal(); renderCouponsAdmin();
      admToast("تم حفظ الكود ✓", "ok");
    }}
  ]);
}

/* =========================================================
   المخزون
   ========================================================= */
function renderInventory(){
  const prods = getProducts();
  const tracked = prods.filter(p => p.trackStock);
  const untracked = prods.filter(p => !p.trackStock);
  const box = $("#inventoryTable");

  box.innerHTML = (tracked.length ? tracked.map(p => {
    const low = p.stock <= (p.lowStock || 5);
    const out = p.stock === 0;
    return `
    <div class="tbl-row ${out ? "dim" : ""}">
      <img class="tbl-img" src="${p.img || PLACEHOLDER_IMG}" alt="" onerror="this.src='${PLACEHOLDER_IMG}'">
      <div class="tbl-main">
        <div class="t-name">${escapeHtml(p.name)}</div>
        <div class="t-sub">${out ? '<span class="low-warn" style="color:#ff8589">نفد — معلّم غير متاح تلقائياً</span>' : low ? `<span class="low-warn">⚠️ مخزون منخفض</span>` : "متوفر"}</div>
      </div>
      <input class="input-inline stock-input" type="number" min="0" value="${p.stock ?? 0}" data-adm="stock-input" data-id="${p.id}" aria-label="الكمية">
      <div class="tbl-actions">
        <button class="btn btn-sm btn-success" data-adm="stock-plus" data-id="${p.id}">+١٠</button>
        <button class="btn btn-sm btn-outline" data-adm="stock-minus" data-id="${p.id}">−١٠</button>
      </div>
    </div>`;
  }).join("") : `<p class="empty-note">لا توجد أصناف بتتبع مخزون — فعّل «تتبع المخزون» من تعديل الصنف.</p>`)
  + (untracked.length ? `
    <div class="adm-card" style="margin-top:14px">
      <h3>أصناف بدون تتبع كميات (توفر فقط)</h3>
      ${untracked.map(p => `
        <div class="set-row">
          <span class="lbl">${escapeHtml(p.name)}</span>
          <label class="switch"><input type="checkbox" data-adm="prod-avail" data-id="${p.id}" ${p.available ? "checked" : ""}><span class="sl"></span></label>
        </div>`).join("")}
    </div>` : "");
}

function adjustStock(id, delta, note){
  const prods = getProducts();
  const p = prods.find(x => x.id === id);
  if (!p) return;
  p.stock = Math.max(0, (p.stock ?? 0) + delta);
  const wasAvailable = p.available;
  if (p.stock === 0 && p.trackStock) p.available = false;
  if (p.stock > 0 && p.trackStock && !wasAvailable && delta > 0) p.available = true;
  DB.set(DB.K.products, prods);
  const log = DB.get(DB.K.invlog, []);
  log.unshift({ id: uid(), at: Date.now(), product: p.name, delta, stock: p.stock, note: note || (delta > 0 ? "توريد يدوي" : "خصم يدوي") });
  DB.set(DB.K.invlog, log.slice(0, 50));
  renderInventory(); renderAlerts();
  admToast(`${p.name}: المخزون الآن ${p.stock}`, "ok");
}

function renderInvLog(){
  const log = DB.get(DB.K.invlog, []);
  $("#invLog").innerHTML = log.length ? log.map(l => `
    <div class="inv-log-row">
      <span>${l.delta > 0 ? "▲ +" : "▼ "}${l.delta} — ${escapeHtml(l.product)} <span class="when">(${escapeHtml(l.note)})</span></span>
      <span class="when">${fmtDate(l.at)} · المتبقي ${l.stock}</span>
    </div>`).join("") : `<p class="empty-note">لا توجد حركات بعد.</p>`;
}

function stockInputCommit(id, value){
  const prods = getProducts();
  const p = prods.find(x => x.id === id);
  if (!p) return;
  const nv = Math.max(0, Number(value) || 0);
  const diff = nv - (p.stock ?? 0);
  p.stock = nv;
  if (p.trackStock) p.available = nv > 0;
  DB.set(DB.K.products, prods);
  if (diff !== 0){
    const log = DB.get(DB.K.invlog, []);
    log.unshift({ id: uid(), at: Date.now(), product: p.name, delta: diff, stock: nv, note: "تعديل يدوي" });
    DB.set(DB.K.invlog, log.slice(0, 50));
  }
  renderInventory(); renderAlerts();
}

/* =========================================================
   الإعدادات
   ========================================================= */
function renderSettings(){
  const s = getSettings();
  $("#settingsForm").innerHTML = `
    <fieldset>
      <legend>هوية المطعم</legend>
      <div class="field"><label>اسم المطعم</label><input id="stName" value="${escapeHtml(s.restaurantName)}"></div>
      <div class="field"><label>الوصف القصير (يظهر في الهيدر)</label><input id="stTagline" value="${escapeHtml(s.tagline)}"></div>
      <div class="field"><label>شريط العروض (يدعم كود HTML بسيط)</label><input id="stBanner" value="${escapeHtml(s.promoBanner.text || "")}"></div>
      <div class="set-row"><span class="lbl">تشغيل شريط العروض</span>
        <label class="switch"><input type="checkbox" id="stBannerOn" ${s.promoBanner.enabled ? "checked" : ""}><span class="sl"></span></label></div>
    </fieldset>

    <fieldset>
      <legend>التواصل والموقع</legend>
      <div class="field"><label>رقم الهاتف</label><input id="stPhone" value="${escapeHtml(s.phone)}" dir="ltr"></div>
      <div class="field"><label>رقم واتساب (بمفتاح الدولة بدون +)</label><input id="stWa" value="${escapeHtml(s.whatsapp)}" dir="ltr" placeholder="201001234567"></div>
      <div class="field"><label>العنوان</label><input id="stAddr" value="${escapeHtml(s.address)}"></div>
      <div class="field"><label>رابط الخريطة</label><input id="stMap" value="${escapeHtml(s.mapUrl)}" dir="ltr"></div>
    </fieldset>

    <fieldset>
      <legend>أوقات العمل والتشغيل</legend>
      <div class="field"><label>وصف المواعيد (يظهر للعملاء)</label><input id="stHoursLabel" value="${escapeHtml(s.hoursLabel)}"></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div class="field"><label>ساعة الفتح (٠-٢٣)</label><input id="stOpen" type="number" min="0" max="23" value="${s.openHour}"></div>
        <div class="field"><label>ساعة الإغلاق (٠-٢٣)</label><input id="stClose" type="number" min="0" max="23" value="${s.closeHour}"></div>
      </div>
      <div class="field"><label>متوسط وقت التحضير</label><input id="stPrep" value="${escapeHtml(s.prepTimeLabel)}"></div>
      <div class="set-row"><span class="lbl">إغلاق مؤقت للمطعم<span class="sub">يوقف الطلبات ويظهر «مغلق مؤقتاً» للعملاء</span></span>
        <label class="switch"><input type="checkbox" id="stClosed" ${s.temporarilyClosed ? "checked" : ""}><span class="sl"></span></label></div>
    </fieldset>

    <fieldset>
      <legend>الأسعار والتوصيل</legend>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div class="field"><label>أقل قيمة طلب (توصيل)</label><input id="stMinDel" type="number" min="0" value="${s.minOrderDelivery}"></div>
        <div class="field"><label>أقل قيمة طلب (استلام)</label><input id="stMinPick" type="number" min="0" value="${s.minOrderPickup}"></div>
      </div>
      <div class="field"><label>مناطق التوصيل والرسوم</label><div id="stZones"></div>
        <button type="button" class="btn btn-outline btn-sm" id="stAddZone">+ منطقة</button></div>
      <div class="field"><label>سياسة الإلغاء</label>
        <select id="stCancelPolicy">
          <option value="before_prep" ${s.cancellationPolicy === "before_prep" ? "selected" : ""}>السماح بطلب الإلغاء قبل بدء التحضير</option>
          <option value="always" ${s.cancellationPolicy === "always" ? "selected" : ""}>السماح في أي وقت قبل التسليم</option>
          <option value="never" ${s.cancellationPolicy === "never" ? "selected" : ""}>عدم السماح بالإلغاء</option>
        </select></div>
    </fieldset>

    <fieldset>
      <legend>طرق الدفع</legend>
      <div class="set-row"><span class="lbl">كاش عند التوصيل</span>
        <label class="switch"><input type="checkbox" id="stCod" ${s.payments.cod ? "checked" : ""}><span class="sl"></span></label></div>
      <div class="set-row"><span class="lbl">كاش عند الاستلام</span>
        <label class="switch"><input type="checkbox" id="stPickCash" ${s.payments.pickupCash ? "checked" : ""}><span class="sl"></span></label></div>
      <div class="set-row"><span class="lbl">دفع إلكتروني<span class="sub">يفعّل فقط عند ربط بوابة دفع حقيقية</span></span>
        <label class="switch"><input type="checkbox" id="stEpay" ${s.payments.electronic ? "checked" : ""}><span class="sl"></span></label></div>
    </fieldset>

    <fieldset>
      <legend>الأمان</legend>
      <div class="field"><label>اسم المستخدم للإدارة</label><input id="stAdmUser" value="${escapeHtml(s.adminUser)}" dir="ltr"></div>
      <div class="field"><label>كلمة مرور جديدة (اتركها فارغة لعدم التغيير)</label><input id="stAdmPass" type="password" placeholder="••••••••"></div>
      <p class="section-hint">⚠️ تخزين الاعتمادات في المتصفح للعرض التجريبي فقط. في الإنتاج استخدم Firebase Auth أو Supabase Auth مع صلاحيات خادمية.</p>
    </fieldset>

    <fieldset class="danger-zone">
      <legend>منطقة الخطر</legend>
      <div class="set-row"><span class="lbl">إعادة ضبط كل البيانات التجريبية<span class="sub">تحذف الطلبات والتعديلات وتعيد البيانات الافتراضية</span></span>
        <button type="button" class="btn btn-danger btn-sm" id="stReset">إعادة الضبط</button></div>
    </fieldset>

    <div style="grid-column:1/-1;display:flex;gap:10px;justify-content:flex-end">
      <button type="submit" class="btn btn-primary btn-lg">💾 حفظ الإعدادات</button>
    </div>`;

  /* مناطق التوصيل repeater */
  const zonesBox = $("#stZones");
  const zoneRow = z => `
    <div class="zone-row">
      <input placeholder="اسم المنطقة" value="${escapeHtml(z.name || "")}" data-z="name">
      <input class="fee" type="number" min="0" placeholder="رسوم" value="${z.fee ?? 0}" data-z="fee">
      <input placeholder="المدة (٤٥–٦٠ د)" value="${escapeHtml(z.eta || "")}" data-z="eta">
      <button type="button" class="btn btn-sm btn-danger" data-adm="zone-del">✕</button>
    </div>`;
  (s.deliveryZones || []).forEach(z => zonesBox.insertAdjacentHTML("beforeend", zoneRow(z)));
  $("#stAddZone").addEventListener("click", () => zonesBox.insertAdjacentHTML("beforeend", zoneRow({})));

  $("#settingsForm").addEventListener("submit", e => {
    e.preventDefault();
    saveSettings();
  });
  $("#stReset").addEventListener("click", () => {
    admConfirm("إعادة ضبط البيانات", "سيتم حذف كل الطلبات والتعديلات واستعادة البيانات الافتراضية. متأكد؟", () => {
      DB.resetAll();
      bootShell();
      admToast("تمت إعادة الضبط ✓", "ok");
      renderSettings();
    });
  });
}

async function saveSettings(){
  const s = getSettings();
  const zones = $$("#stZones .zone-row").map(row => ({
    id: uid(),
    name: row.querySelector('[data-z="name"]').value.trim(),
    fee: Number(row.querySelector('[data-z="fee"]').value) || 0,
    eta: row.querySelector('[data-z="eta"]').value.trim()
  })).filter(z => z.name);

  const pass = $("#stAdmPass").value;
  const updated = Object.assign({}, s, {
    restaurantName: $("#stName").value.trim() || s.restaurantName,
    tagline: $("#stTagline").value.trim(),
    phone: $("#stPhone").value.trim(),
    whatsapp: $("#stWa").value.replace(/\D/g, ""),
    address: $("#stAddr").value.trim(),
    mapUrl: $("#stMap").value.trim(),
    hoursLabel: $("#stHoursLabel").value.trim(),
    openHour: Math.min(23, Math.max(0, Number($("#stOpen").value))),
    closeHour: Math.min(23, Math.max(0, Number($("#stClose").value))),
    prepTimeLabel: $("#stPrep").value.trim(),
    temporarilyClosed: $("#stClosed").checked,
    minOrderDelivery: Number($("#stMinDel").value) || 0,
    minOrderPickup: Number($("#stMinPick").value) || 0,
    deliveryZones: zones,
    cancellationPolicy: $("#stCancelPolicy").value,
    payments: {
      cod: $("#stCod").checked,
      pickupCash: $("#stPickCash").checked,
      electronic: $("#stEpay").checked
    },
    promoBanner: { enabled: $("#stBannerOn").checked, text: $("#stBanner").value.trim() },
    adminUser: $("#stAdmUser").value.trim() || "admin"
  });
  if (pass){
    if (pass.length < 6){ admToast("كلمة المرور قصيرة (٦ أحرف على الأقل)", "err"); return; }
    updated.adminPassHash = await sha256Hex(pass);
  }
  DB.set(DB.K.settings, updated);
  $("#admRestName").textContent = updated.restaurantName;
  admToast("تم حفظ الإعدادات ✓", "ok");
}

/* =========================================================
   نوافذ وتنبيهات الإدارة
   ========================================================= */
function openAdmModal(title, bodyHTML, buttons){
  const m = $("#admModal");
  m.innerHTML = `
  <div class="modal-sheet">
    <div class="modal-head"><h3>${escapeHtml(title)}</h3>
      <button class="icon-btn" data-adm="close-modal" aria-label="إغلاق">✕</button></div>
    <div class="modal-body">${bodyHTML}</div>
    ${buttons && buttons.length ? `<div class="modal-foot">${buttons.map((b, i) =>
      `<button class="btn ${b.cls}" data-adm-btn="${i}">${escapeHtml(b.label)}</button>`).join("")}</div>` : ""}
  </div>`;
  m.hidden = false;
  requestAnimationFrame(() => m.classList.add("show"));
  document.body.style.overflow = "hidden";
  if (buttons) buttons.forEach((b, i) => {
    m.querySelector(`[data-adm-btn="${i}"]`).onclick = () => {
      if (b.fn){ const r = b.fn(); if (r === false) return; }
      else closeAdmModal();
    };
  });
}
function closeAdmModal(){
  const m = $("#admModal");
  m.classList.remove("show");
  document.body.style.overflow = "";
  setTimeout(() => { m.hidden = true; m.innerHTML = ""; }, 200);
}
function admConfirm(title, body, onOk){
  openAdmModal(title, `<p style="color:#D9D0C3">${escapeHtml(body)}</p>`, [
    { label: "إلغاء", cls: "btn-outline", fn: null },
    { label: "تأكيد", cls: "btn-danger", fn: () => { onOk && onOk(); } }
  ]);
}
function admToast(msg, type){
  const box = $("#admToasts");
  const el = document.createElement("div");
  el.className = "toast " + (type || "");
  el.textContent = msg;
  box.appendChild(el);
  setTimeout(() => { el.classList.add("out"); setTimeout(() => el.remove(), 320); }, 2600);
}

/* =========================================================
   ربط أحداث الإدارة (Event Delegation)
   ========================================================= */
document.addEventListener("click", e => {
  const el = e.target.closest("[data-adm]");
  if (!el) return;
  const act = el.dataset.adm;
  const id = el.dataset.id;
  const actions = {
    "close-modal": closeAdmModal,
    "rep-del": () => el.closest(".rep-row").remove(),
    "zone-del": () => el.closest(".zone-row").remove(),
    "add-size": () => $("#fSizes").insertAdjacentHTML("beforeend",
      `<div class="rep-row"><input placeholder="اسم الحجم" data-f="size-name"><input class="delta" type="number" placeholder="فرق السعر" data-f="size-delta" value="0"><button type="button" class="btn btn-sm btn-danger" data-adm="rep-del">✕</button></div>`),
    "add-extra": () => $("#fExtras").insertAdjacentHTML("beforeend",
      `<div class="rep-row"><input placeholder="اسم الإضافة" data-f="ex-name"><input class="delta" type="number" placeholder="السعر" data-f="ex-price" value="0"><button type="button" class="btn btn-sm btn-danger" data-adm="rep-del">✕</button></div>`),
    "prod-edit": () => productForm(getProducts().find(p => p.id === id)),
    "prod-del": () => deleteProduct(id),
    "prod-avail": () => toggleProductAvail(id, el.checked),
    "cat-edit": () => catForm(getCategories().find(c => c.id === id)),
    "cat-del": () => deleteCat(id),
    "coupon-edit": () => couponForm(getCoupons().find(c => c.id === id)),
    "coupon-del": () => admConfirm("حذف الكود", "متأكد من حذف كود الخصم؟", () => {
      DB.set(DB.K.coupons, getCoupons().filter(c => c.id !== id));
      renderCouponsAdmin(); admToast("تم حذف الكود", "ok");
    }),
    "coupon-toggle": () => {
      const cps = getCoupons();
      const c = cps.find(x => x.id === id);
      if (c){ c.active = el.checked; DB.set(DB.K.coupons, cps); admToast(el.checked ? "الكود نشط" : "تم إيقاف الكود", "ok"); }
    },
    "stock-plus": () => adjustStock(id, 10),
    "stock-minus": () => adjustStock(id, -10),
    "order-details": () => showOrderDetails(id),
    "order-advance": () => advanceOrder(id),
    "order-cancel": () => cancelOrderAdmin(id),
    "kitchen-ticket": () => kitchenTicket(id),
    "cancel-approve": () => {
      const orders = getOrders();
      const o = orders.find(x => x.id === id);
      if (o){
        o.status = "cancelled";
        o.cancelReason = "تمت الموافقة على طلب إلغاء العميل";
        o.statusHistory.push({ status: "cancelled", at: Date.now() });
        o.cancellationRequested = false;
        saveOrders(orders);
        admToast(`تم إلغاء الطلب ${o.ref}`, "ok");
        renderDashboard(); renderOrdersAdmin(); renderAlerts();
      }
    },
    "cancel-reject": () => {
      const orders = getOrders();
      const o = orders.find(x => x.id === id);
      if (o){
        o.cancellationRequested = false;
        saveOrders(orders);
        admToast(`تم رفض طلب الإلغاء ومتابعة الطلب ${o.ref}`, "ok");
        renderDashboard(); renderOrdersAdmin(); renderAlerts();
      }
    }
  };
  if (actions[act]) actions[act]();
});

/* تغيير كميات المخزون */
document.addEventListener("change", e => {
  const el = e.target.closest('[data-adm="stock-input"]');
  if (el) stockInputCommit(el.dataset.id, el.value);
});

/* فلاتر الطلبات والمنتجات */
$("#ordSearch").addEventListener("input", e => { ordFilters.q = e.target.value; renderOrdersAdmin(); });
$("#ordStatus").addEventListener("change", e => { ordFilters.status = e.target.value; renderOrdersAdmin(); });
$("#ordDate").addEventListener("change", e => { ordFilters.date = e.target.value; renderOrdersAdmin(); });
$("#prodSearch").addEventListener("input", e => { prodFilter.q = e.target.value; renderProductsAdmin(); });
$("#prodCatFilter").addEventListener("change", e => { prodFilter.cat = e.target.value; renderProductsAdmin(); });
$("#statRange").addEventListener("change", renderDashboard);
$("#exportCsvBtn").addEventListener("click", exportCsv);
$("#printKitchenBtn").addEventListener("click", () => {
  /* طباعة تذاكر كل الطلبات الجديدة */
  const fresh = getOrders().filter(o => o.status === "received");
  if (!fresh.length){ admToast("لا توجد طلبات جديدة", "err"); return; }
  fresh.forEach((o, i) => setTimeout(() => kitchenTicket(o.id), i * 500));
});
$("#addProductBtn").addEventListener("click", () => productForm(null));
$("#addCatBtn").addEventListener("click", () => catForm(null));
$("#addCouponBtn").addEventListener("click", () => couponForm(null));
$("#admModal").addEventListener("click", e => { if (e.target === e.currentTarget) closeAdmModal(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") closeAdmModal(); });

/* مزامنة حية: طلبات جديدة من تبويب العميل */
window.addEventListener("storage", e => {
  if (!e.key || !e.key.startsWith(DB.PREFIX)) return;
  const k = e.key.slice(DB.PREFIX.length);
  if (k === DB.K.orders){
    renderAlerts();
    if (!$("#panel-orders").classList.contains("hidden")) renderOrdersAdmin();
    if (!$("#panel-dashboard").classList.contains("hidden")) renderDashboard();
    admToast("📥 طلب جديد أو تحديث في الطلبات!", "ok");
  }
  if (k === DB.K.products && !$("#panel-products").classList.contains("hidden")) renderProductsAdmin();
});
/* فحص دوري احتياطي */
setInterval(() => {
  if (!hasSession()) return;
  renderAlerts();
}, 20000);

/* =========================================================
   الإقلاع
   ========================================================= */
DB.seedIfEmpty();
showLogin(!hasSession());
if (hasSession()) bootShell();


