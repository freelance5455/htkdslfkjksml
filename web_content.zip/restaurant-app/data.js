/* =========================================================
   data.js — بيانات المطعم الافتراضية + طبقة التخزين المشتركة
   مطعم ومشويات اللهب — تطبيق طلبات (وضع عرض تجريبي محلي)
   ---------------------------------------------------------
   ملاحظة مهمة: كل البيانات هنا "بيانات نموذجية قابلة للتعديل"
   من لوحة الإدارة أو من هذا الملف مباشرة.
   عند ربط Firebase / Supabase تُستبدل طبقة DB أدناه فقط.
   ========================================================= */

"use strict";

/* ---------- صور الأصناف (روابط قابلة للاستبدال من الإدارة) ---------- */
const IMG = {
  hero:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/1f59185da8df.jpg",
  p1:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/6fbd25425f9b.jpg",
  p2:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/275cab96a20b.jpeg",
  p3:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/1bef080c82c3.jpg",
  p4:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/29b0c050e3a4.jpg",
  p5:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/991514fc37e0.jpg",
  p6:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/1a4c944f79da.jpg",
  p7:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/ac271a15267d.png",
  p8:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/07ce4fc4b499.jpg",
  p9:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/c84ac8350350.jpg",
  p10:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/f27225bed1eb.jpg",
  p11:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/aa3ef55c346b.jpg",
  p12:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/80391175a6a7.jpg",
  p13:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/b9b6f4103986.jpg",
  p14:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/7680094e25a1.jpeg",
  p15:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/2157c147d4ed.jpg",
  p16:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/bb566efaa1d6.jpg",
  p17:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/9c5c633ca8f6.jpg",
  p18:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/45564bb90ea4.jpg",
  p19:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/fef0f7e8b793.jpg",
  p20:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/eb3d69866cc8.png",
  p21:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/8dfb58f5d85d.jpg",
  p22:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/5c8eaf5f8378.jpg",
  p23:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/b71a3e98f04f.jpg",
  p24:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/3c679688b426.jpg",
  p25:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/7c95347cf60c.jpg",
  p26:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/2d759d71931e.png",
  p27:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/1c344254e5f9.jpeg",
  p29:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/48c41d29e82c.jpg",
  p30:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/1ffd7b09cb7f.jpg",
  p31:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/c8a1a0e67e93.jpg",
  p32:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/14a779db492c.jpg",
  p33:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/a7c802e56474.jpg",
  p34:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/e9ef78ac4081.jpg",
  p35:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/f41993971b69.png",
  p36:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/39d6cef7f3f6.jpg",
  p37:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/f95ff5083fc7.jpg",
  p39:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/0127a5e2fd60.jpg",
  p40:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/910d9c127954.jpg",
  p41:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/dd5e7498e393.jpg",
  p42:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/02f676350a02.png",
  p43:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/d35e6e872798.jpg",
  p44:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/d117b55d105d.jpg",
  p45:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/b7b3ce42b7b1.jpg",
  p46:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/74211133c4fc.webp",
  p47:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/74c3696fa84b.webp",
  p48:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/7ca8be51b44b.jpg",
  p49:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/badf75f16083.jpg",
  p50:"https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/daa4ce2b29d5.jpg",
};

/* ---------- إعدادات المطعم الافتراضية ---------- */
const DEFAULT_SETTINGS = {
  restaurantName: "مطعم ومشويات اللهب",
  tagline: "كباب وكفتة وفراخ على الفحم · وصفات مصرية أصيلة",
  phone: "01001234567",
  whatsapp: "201001234567",
  address: "٢٧ شارع التحرير، وسط البلد، القاهرة",
  mapUrl: "https://maps.google.com/?q=Tahrir+Square+Cairo",
  currency: "ج.م",
  hoursLabel: "يومياً: ١٢ ظهراً – ٢ صباحاً",
  openHour: 12,          // 12 ظهراً
  closeHour: 2,          // 2 بعد منتصف الليل (تُفسَّر كـ 26)
  temporarilyClosed: false,
  minOrderDelivery: 150,
  minOrderPickup: 100,
  prepTimeLabel: "٣٠ – ٤٥ دقيقة",
  deliveryZones: [
    { id: "z1", name: "وسط البلد والدور الاول", fee: 20, eta: "٣٠–٤٥ د" },
    { id: "z2", name: "مدينة نصر ومصر الجديدة", fee: 35, eta: "٤٥–٦٠ د" },
    { id: "z3", name: "المعادي والحلوان", fee: 50, eta: "٦٠–٩٠ د" }
  ],
  payments: { cod: true, pickupCash: true, electronic: false },
  promoBanner: {
    enabled: true,
    text: "خصم ١٥٪ على طلبك الأول بكود <b>FLAME15</b> — وخصم ٥٠ ج.م على الطلبات فوق ٣٠٠ ج.م بكود <b>WELCOME50</b>"
  },
  cancellationPolicy: "before_prep", // before_prep | never | always
  demoMode: true,
  adminUser: "admin",
  adminPassHash: ""      // SHA-256 لكلمة المرور — إن كانت فارغة تُستخدم كلمة المرور الافتراضية admin123
};

/* ---------- الأقسام (12 قسم قابل للتعديل) ---------- */
const DEFAULT_CATEGORIES = [
  { id: "g1",  name: "مشويات مشكلة",  emoji: "🔥", sort: 1 },
  { id: "g2",  name: "كباب وكفتة",    emoji: "🍢", sort: 2 },
  { id: "g3",  name: "فراخ مشوية",    emoji: "🍗", sort: 3 },
  { id: "g4",  name: "طرب وقطعيات",   emoji: "🍛", sort: 4 },
  { id: "g5",  name: "وجبات فردية",   emoji: "🍽️", sort: 5 },
  { id: "g6",  name: "وجبات عائلية",  emoji: "👨‍👩‍👧‍👦", sort: 6 },
  { id: "g7",  name: "سندوتشات",      emoji: "🌯", sort: 7 },
  { id: "g8",  name: "أرز ومكرونة",   emoji: "🍚", sort: 8 },
  { id: "g9",  name: "مقبلات وسلطات", emoji: "🥗", sort: 9 },
  { id: "g10", name: "طواجن",         emoji: "🫕", sort: 10 },
  { id: "g11", name: "مشروبات",       emoji: "🥤", sort: 11 },
  { id: "g12", name: "عروض وخصومات",  emoji: "🎁", sort: 12 }
];

/* ---------- إضافات مشتركة ---------- */
const EXTRA_BREAD   = { id: "ex-bread", name: "خبز بلدي إضافي", price: 5 };
const EXTRA_RICE    = { id: "ex-rice",  name: "أرز إضافي",      price: 20 };
const EXTRA_TAHINI  = { id: "ex-tahini",name: "صوص طحينة إضافي", price: 8 };
const EXTRA_SPICY   = { id: "ex-spicy", name: "شطة حارة",        price: 3 };
const EXTRA_MEAT    = { id: "ex-meat",  name: "قطعة لحمة إضافية", price: 45 };
const EXTRA_CHEESE  = { id: "ex-cheese",name: "جبنة رومي إضافية", price: 15 };
const EXTRA_POTATO  = { id: "ex-potato",name: "بطاطس مقلية",     price: 18 };
const EXTRA_SALAD   = { id: "ex-salad", name: "سلطة بلدي إضافية", price: 12 };

/* ---------- المنتجات (48 صنف نموذجي) ----------
   كل منتج: id, cat, name, desc, price, oldPrice?, img, available,
   sizes?[{id,name,delta}], extras?, prepTime, featured?, bestSeller?,
   trackStock?, stock?, lowStock?                                      */
const DEFAULT_PRODUCTS = [
  /* ===== مشويات مشكلة ===== */
  { id:"p1", cat:"g1", name:"مشكل مشويات فردي", price:265, img:IMG.p1, prepTime:"٣٠ د", featured:true, bestSeller:true,
    desc:"تشكيلة من الكباب والكفتة وريش الفراخ على الفحم، تقدم مع الأرز والخبز البلدي والمخللات والطحينة.",
    sizes:[{id:"s1a",name:"عادي",delta:0},{id:"s1b",name:"دبل لحمة",delta:85}],
    extras:[EXTRA_BREAD,EXTRA_RICE,EXTRA_TAHINI,EXTRA_SPICY] },
  { id:"p2", cat:"g1", name:"مشكل مشويات لشخصين", price:520, img:IMG.p2, prepTime:"٣٥ د", bestSeller:true,
    desc:"طبق مشويات ضخم يكفي شخصين: كباب لحم، كفتة، ريش فراخ وضلوع مع كل الأصول والسلطات.",
    sizes:[{id:"s2a",name:"عادي",delta:0},{id:"s2b",name:"فاخر (يضاف ضلوع وريش ضاني)",delta:140}],
    extras:[EXTRA_BREAD,EXTRA_RICE,EXTRA_TAHINI] },
  { id:"p3", cat:"g1", name:"طبق المشويات الملكي", price:790, img:IMG.p3, prepTime:"٤٠ د", featured:true,
    desc:"أجود قطع اللحم البلدي والضاني مع الكباب والكفتة وريش الفراخ — تجربة المشويات الكاملة للمحترفين.",
    extras:[EXTRA_BREAD,EXTRA_RICE,EXTRA_TAHINI,EXTRA_MEAT] },

  /* ===== كباب وكفتة ===== */
  { id:"p4", cat:"g2", name:"كباب لحم بلدي", price:240, img:IMG.p4, prepTime:"٢٥ د", bestSeller:true,
    desc:"قطع لحم بلدي متتبلة على الطريقة المصرية، مشوية على الفحم وتقدم مع البصل السماق والطحينة.",
    sizes:[{id:"s4a",name:"نص كيلو",delta:0},{id:"s4b",name:"كيلو كامل",delta:230}],
    extras:[EXTRA_BREAD,EXTRA_TAHINI,EXTRA_SPICY] },
  { id:"p5", cat:"g2", name:"كفتة لحم مشوية", price:230, img:IMG.p5, prepTime:"٢٥ د",
    desc:"كفتة مفرومة طازجة بالبقدونس والبصل، مشوية على الفحم حتى تتدبل بالماصة.",
    sizes:[{id:"s5a",name:"نص كيلو",delta:0},{id:"s5b",name:"كيلو كامل",delta:220}],
    extras:[EXTRA_BREAD,EXTRA_TAHINI,EXTRA_SPICY] },
  { id:"p6", cat:"g2", name:"كباب وكفتة مشكل", price:255, img:IMG.p6, prepTime:"٢٥ د", featured:true,
    desc:"مشكل من الكباب والكفتة لأصحاب القرار الصعب — نص نص على الفحم.",
    sizes:[{id:"s6a",name:"نص كيلو",delta:0},{id:"s6b",name:"كيلو كامل",delta:235}],
    extras:[EXTRA_BREAD,EXTRA_TAHINI] },
  { id:"p7", cat:"g2", name:"كفتة بالصينية بالصوص", price:195, img:IMG.p7, prepTime:"٣٠ د",
    desc:"كفتة بلدية في صينية مع صوص الطماطم الخاص والفلفل، تقدم ساخنة من الفرن مع الأرز.",
    extras:[EXTRA_RICE,EXTRA_BREAD] },

  /* ===== فراخ مشوية ===== */
  { id:"p8", cat:"g3", name:"نصف فرخة مشوية", price:165, img:IMG.p8, prepTime:"٢٥ د", bestSeller:true,
    desc:"نصف فرخة بلدي متتبلة بالبهارات المصرية ومشوية على الفحم، مع الخبز والطحينة والمخللات.",
    extras:[EXTRA_BREAD,EXTRA_RICE,EXTRA_TAHINI,EXTRA_SPICY] },
  { id:"p9", cat:"g3", name:"فرخة مشوية كاملة", price:320, img:IMG.p9, prepTime:"٣٠ د",
    desc:"فرخة كاملة على الفحم بتتبيلة اللهب السرية — تكفي شخصين بجد.",
    extras:[EXTRA_BREAD,EXTRA_RICE,EXTRA_TAHINI] },
  { id:"p10", cat:"g3", name:"ريش فراخ مشوية", price:190, img:IMG.p10, prepTime:"٢٥ د", featured:true,
    desc:"ريش فراخ طازجة متبلة ومشوية على الفحم، مقرمشة من بره وطرية من جوه.",
    extras:[EXTRA_BREAD,EXTRA_POTATO,EXTRA_SPICY] },
  { id:"p11", cat:"g3", name:"شيش طاووق", price:175, img:IMG.p11, prepTime:"٢٥ د",
    desc:"قطع صدور فراخ متتبلة بالزبادي والليمون، مشوية على السيخ مع الفلفل والبصل.",
    extras:[EXTRA_BREAD,EXTRA_RICE,EXTRA_TAHINI] },

  /* ===== طرب وقطعيات ===== */
  { id:"p12", cat:"g4", name:"طوبة فتة باللحمة", price:230, img:IMG.p12, prepTime:"٣٠ د", bestSeller:true,
    desc:"أرز بالخلطة والخبز المحمر مع قطع اللحمة البلدي والصلصة الحارة — فتة الأعياد كل يوم.",
    extras:[EXTRA_RICE,EXTRA_BREAD] },
  { id:"p13", cat:"g4", name:"طوبة فتة بالضاني والسجق", price:245, img:IMG.p13, prepTime:"٣٠ د",
    desc:"فتة مصرية بالضاني الطري والسجق البلدي المحمر مع الصلصة والدقة.",
    extras:[EXTRA_RICE,EXTRA_BREAD] },
  { id:"p14", cat:"g4", name:"ريش ضاني مشوية", price:335, img:IMG.p14, prepTime:"٣٥ د", featured:true,
    desc:"ريش ضاني طازجة على الفحم بلمسة روزماري وليمون — للذوق الرفيع.",
    extras:[EXTRA_BREAD,EXTRA_RICE] },
  { id:"p15", cat:"g4", name:"ضلوع مشوية بالفحم", price:350, img:IMG.p15, prepTime:"٣٥ د",
    desc:"ضلوع لحم متتبلة لمدة ١٢ ساعة ومشوية ببطء على الفحم حتى تفصل عن العضم.",
    extras:[EXTRA_BREAD,EXTRA_POTATO] },
  { id:"p16", cat:"g4", name:"كفتة بالطحينة بالفرن", price:185, img:IMG.p16, prepTime:"٣٠ د",
    desc:"أقراص كفتة في صوص الطحينة الكريمي بالفرن، مع الخبز البلدي لتغمس وتدلع.",
    extras:[EXTRA_BREAD,EXTRA_RICE] },

  /* ===== وجبات فردية ===== */
  { id:"p17", cat:"g5", name:"وجبة فراخ مشوية", price:150, img:IMG.p17, prepTime:"٢٥ د", bestSeller:true,
    desc:"نصف فرخة مشوية + أرز + سلطة بلدي + خبز — وجبة كاملة تشبع وتطول.",
    extras:[EXTRA_TAHINI,EXTRA_SPICY,EXTRA_POTATO] },
  { id:"p18", cat:"g5", name:"وجبة كباب", price:175, img:IMG.p18, prepTime:"٢٥ د",
    desc:"ربع كيلو كباب لحم + أرز + سلطة + خبز + طحينة.",
    extras:[EXTRA_RICE,EXTRA_TAHINI,EXTRA_SPICY] },
  { id:"p19", cat:"g5", name:"وجبة كفتة", price:170, img:IMG.p19, prepTime:"٢٥ د",
    desc:"ربع كيلو كفتة مشوية + أرز + سلطة + خبز.",
    extras:[EXTRA_RICE,EXTRA_TAHINI,EXTRA_SPICY] },
  { id:"p20", cat:"g5", name:"وجبة شيش طاووق", price:165, img:IMG.p20, prepTime:"٢٥ د",
    desc:"سيخين شيش طاووق + أرز بالشعرية + سلطة + خبز.",
    extras:[EXTRA_RICE,EXTRA_TAHINI] },

  /* ===== وجبات عائلية ===== */
  { id:"p21", cat:"g6", name:"وجبة عائلية مشكلة (٤ أفراد)", price:980, img:IMG.p21, prepTime:"٤٥ د", featured:true,
    desc:"مشكل مشويات كبير + ٤ سلطات + أرز + خبز + مشروبات — سفرة العيلة كاملة.",
    extras:[EXTRA_RICE,EXTRA_TAHINI] },
  { id:"p22", cat:"g6", name:"العرض العائلي الكبير (٦ أفراد)", price:1450, img:IMG.p22, prepTime:"٥٠ د",
    desc:"كل حاجة: مشويات مشكلة ضخمة + فتة + طواجن + سلطات ومقبلات + مشروبات.",
    extras:[EXTRA_RICE,EXTRA_TAHINI] },
  { id:"p23", cat:"g6", name:"وجبة عائلية فراخ (٤ أفراد)", price:660, img:IMG.p23, prepTime:"٤٠ د",
    desc:"فرختين مشويتين + أرز كبير + ٤ سلطات + خبز بلدي.",
    extras:[EXTRA_RICE,EXTRA_TAHINI,EXTRA_SPICY] },

  /* ===== سندوتشات ===== */
  { id:"p24", cat:"g7", name:"ساندويتش كفتة", price:78, img:IMG.p24, prepTime:"١٥ د",
    desc:"كفتة مشوية طازجة في خبز صاج مع الطحينة والسلطة والمخلل.",
    extras:[EXTRA_CHEESE,EXTRA_SPICY,EXTRA_POTATO] },
  { id:"p25", cat:"g7", name:"ساندويتش كباب", price:82, img:IMG.p25, prepTime:"١٥ د",
    desc:"قطع كباب لحم على الفحم في خبز بلدي مع البصل والطحينة.",
    extras:[EXTRA_CHEESE,EXTRA_SPICY,EXTRA_POTATO] },
  { id:"p26", cat:"g7", name:"ساندويتش شاورما فراخ", price:68, img:IMG.p26, prepTime:"١٠ د", bestSeller:true,
    desc:"شاورما فراخ مقطعة رقيق مع الطحينة والمخلل — الأسرع مبيعاً في المطعم.",
    extras:[EXTRA_CHEESE,EXTRA_SPICY,EXTRA_POTATO] },
  { id:"p27", cat:"g7", name:"ساندويتش شاورما لحم", price:88, img:IMG.p27, prepTime:"١٠ د",
    desc:"شاورما لحم بلدي بالسمنة البلدية مع الطحينة والطماطم.",
    extras:[EXTRA_CHEESE,EXTRA_SPICY,EXTRA_POTATO] },

  /* ===== أرز ومكرونة ===== */
  { id:"p29", cat:"g8", name:"أرز بالشعرية", price:22, img:IMG.p29, prepTime:"١٠ د",
    desc:"أرز مصري بالشعرية المحمرة والسمنة — طبق جانبي كلاسيكي.",
    extras:[EXTRA_BREAD] },
  { id:"p30", cat:"g8", name:"أرز معمر باللحمة", price:55, img:IMG.p30, prepTime:"٢٠ د", featured:true,
    desc:"أرز معمر كريمي بالحليب والقشطة مع قطع اللحمة — فرن ودلع.",
    extras:[EXTRA_BREAD] },
  { id:"p31", cat:"g8", name:"مكرونة بشاميل", price:60, img:IMG.p31, prepTime:"٢٠ د",
    desc:"مكرونة بشاميل بالحمصة المفرومة والصلصة — طبق البيت المصري الأشهر.",
    extras:[EXTRA_BREAD] },

  /* ===== مقبلات وسلطات ===== */
  { id:"p32", cat:"g9", name:"سلطة بلدي", price:15, img:IMG.p32, prepTime:"٥ د",
    desc:"طماطم وخيار وفلفل وبصل طازج بزيت الزيتون والليمون.",
    extras:[] },
  { id:"p33", cat:"g9", name:"طحينة بالخلطة", price:20, img:IMG.p33, prepTime:"٥ د",
    desc:"طحينة سمسم مصريّة بالخلطة الحارة والليمون.",
    extras:[EXTRA_BREAD] },
  { id:"p34", cat:"g9", name:"بابا غنوج", price:32, img:IMG.p34, prepTime:"٥ د",
    desc:"باذنجان مشوي على الفحم مع الطحينة والزبادي والرمان.",
    extras:[EXTRA_BREAD] },
  { id:"p35", cat:"g9", name:"حمص الشام بالطحينة", price:28, img:IMG.p35, prepTime:"٥ د",
    desc:"حمص كريمي بزيت الزيتون والكمون مع حبات الحمص المسلوقة.",
    extras:[EXTRA_BREAD] },
  { id:"p36", cat:"g9", name:"محشي ورق عنب", price:38, img:IMG.p36, prepTime:"١٠ د",
    desc:"ورق عنب محشي بالأرز والأعشاب — بارد أو ساخن حسب طلبك.",
    extras:[] },
  { id:"p37", cat:"g9", name:"شوربة عدس", price:35, img:IMG.p37, prepTime:"١٠ د",
    desc:"شوربة عدس حمراء دافئة بالكمون والليمون مع خبز محمر.",
    extras:[EXTRA_BREAD] },

  /* ===== طواجن ===== */
  { id:"p39", cat:"g10", name:"طاجن بامية باللحمة", price:98, img:IMG.p39, prepTime:"٢٥ د", bestSeller:true,
    desc:"بامية بلدي باللحمة والصلصة في طاجن فخار — تدوب في البق.",
    extras:[EXTRA_RICE,EXTRA_BREAD] },
  { id:"p40", cat:"g10", name:"طاجن ملوخية بالفراخ", price:90, img:IMG.p40, prepTime:"٢٥ د",
    desc:"ملوخية مصرية بالتقلقلعة مع قطع الفراخ — صح وسخن زي بيت ماما.",
    extras:[EXTRA_RICE,EXTRA_BREAD] },
  { id:"p41", cat:"g10", name:"مسقعة بالصلصة", price:72, img:IMG.p41, prepTime:"٢٥ د",
    desc:"باذنجان وبطاطس وفلفل في الصلصة الحارة — طبق جانبي يرقى لأصلي.",
    extras:[EXTRA_BREAD] },
  { id:"p42", cat:"g10", name:"طاجن بطاطس باللحمة", price:85, img:IMG.p42, prepTime:"٢٥ د",
    desc:"بطاطس باللحمة المفرومة والصلصة في الطاجن — كلاسيك لا يخيب.",
    extras:[EXTRA_BREAD] },

  /* ===== مشروبات ===== */
  { id:"p43", cat:"g11", name:"عصير ليمون بالنعناع", price:30, img:IMG.p43, prepTime:"٥ د", bestSeller:true,
    desc:"ليمون طازج بالنعناع والسكر — منعش ولازم مع المشويات.",
    extras:[] },
  { id:"p44", cat:"g11", name:"كركديه مثلج", price:25, img:IMG.p44, prepTime:"٥ د",
    desc:"كركديه أحمر بارد محلى باعتدال — النبيت المصري.",
    extras:[] },
  { id:"p45", cat:"g11", name:"ليموناضة بالزنجبيل", price:32, img:IMG.p45, prepTime:"٥ د",
    desc:"ليموناضة منعشة بلمسة زنجبيل طازج.",
    extras:[] },
  { id:"p46", cat:"g11", name:"مشروب غازي مثلج", price:20, img:IMG.p46, prepTime:"دقيقة",
    desc:"كانز مشروب غازي مثلج من الثلاجة (حدد النوع في الملاحظات).",
    extras:[] },
  { id:"p47", cat:"g11", name:"مياه معدنية", price:10, img:IMG.p47, prepTime:"دقيقة",
    desc:"زجاجة مياه معدنية باردة ٦٠٠ مل.",
    extras:[] },

  /* ===== عروض وخصومات ===== */
  { id:"p48", cat:"g12", name:"عرض الفتة الكامل", price:199, oldPrice:265, img:IMG.p48, prepTime:"٣٥ د", featured:true, bestSeller:true,
    desc:"طوبة فتة باللحمة + شوربة عدس + ٢ مياه معدنية — وفّر ٦٦ ج.م.",
    extras:[EXTRA_BREAD] },
  { id:"p49", cat:"g12", name:"عرض مشويات لشخصين + مشروبين", price:470, oldPrice:560, img:IMG.p49, prepTime:"٣٥ د", featured:true,
    desc:"مشكل مشويات + ٢ سلطة + أرز + ٢ عصير ليمون — وفّر ٩٠ ج.م.",
    extras:[EXTRA_RICE,EXTRA_TAHINI] },
  { id:"p50", cat:"g12", name:"عرض السندوتشات", price:95, oldPrice:118, img:IMG.p50, prepTime:"١٥ د",
    desc:"ساندويتش شاورما + بطاطس + مشروب غازي — وفّر ٢٣ ج.م.",
    extras:[EXTRA_CHEESE,EXTRA_SPICY] }
];

/* ---------- كوبونات افتراضية ---------- */
const DEFAULT_COUPONS = [
  { id:"c-flame15",  code:"FLAME15",   type:"percent", value:15, minOrder:200, active:true,
    note:"خصم ١٥٪ على الطلبات من ٢٠٠ ج.م" },
  { id:"c-welcome50",code:"WELCOME50", type:"fixed",   value:50, minOrder:300, active:true,
    note:"خصم ٥٠ ج.م على الطلبات من ٣٠٠ ج.م" },
  { id:"c-freedel",  code:"FREEDEL",   type:"free_delivery", value:0, minOrder:150, active:true,
    note:"توصيل مجاني على الطلبات من ١٥٠ ج.م" }
];

/* ---------- آراء عملاء نموذجية (بيانات قابلة للتعديل — ليست إحصائيات حقيقية) ---------- */
const DEFAULT_REVIEWS = [
  { id:"r1", name:"محمود السيد",   rating:5, daysAgo:2,  sample:true,
    text:"الكفتة لذيذة جدًا وواصلة سخنة لحد البيت. التوصيل كان أسرع من الوقت المحدد، وتغليف محترم ومتظبط." },
  { id:"r2", name:"منى عبد الرحمن", rating:5, daysAgo:5, sample:true,
    text:"أحسن فتة آكلها برة البيت. الطلب وصل مرتب والأسعار مناسبة مقارنة بالكمية. هكرر الطلب أكيد." },
  { id:"r3", name:"أحمد فتحي",     rating:4, daysAgo:7, sample:true,
    text:"الشيش طاووق ممتاز والسلطات طازجة. المكان نظيف والتعامل راقي. بس أتمنى يزيدوا اختيارات المقبلات." },
  { id:"r4", name:"سارة ماهر",     rating:5, daysAgo:10, sample:true,
    text:"طلبت وجبة عائلية لخمس أفراد وكلهم مدلعين. العصاير طبيعية والفراخ مشوية زي الفل. شكرًا للهيب!" },
  { id:"r5", name:"كريم مصطفى",    rating:4, daysAgo:14, sample:true,
    text:"ساندويتش الشاورما بحاله يستاهل. المكان مظبوط والخدمة سريعة في غير أوقات الذروة." }
];

/* ---------- أسئلة شائعة ---------- */
const DEFAULT_FAQ = [
  { q:"إزاي أطلب؟", a:"اختار الطلبات من القائمة وضيفها للسلة، ثم اضغط «إتمام الطلب» واملأ بياناتك. هتوصلك رسالة تأكيد برقم الطلب فورًا." },
  { q:"بتوصلوا لحد فين؟ وبتاخدوا قد إيه؟", a:"نوصل لمعظم مناطق القاهرة الكبرى — تظهر المناطق والرسوم في صفحة إتمام الطلب. مدة التحضير ٣٠–٤٥ دقيقة تقريبًا حسب الطلب والذروة." },
  { q:"إيه طرق الدفع المتاحة؟", a:"الكاش عند التوصيل أو الكاش عند الاستلام من المطعم. الدفع الإلكتروني يُفعَّل عند ربط بوابة دفع حقيقية." },
  { q:"ممكن ألغي الطلب بعد إرساله؟", a:"تقدر تطلب إلغاء من صفحة «طلباتي» قبل بدء التحضير حسب سياسة المطعم، وهيتم الرد على طلبك من الإدارة." },
  { q:"فيه عروض أو أكواد خصم؟", a:"أيوه! الأكواد النشطة بتظهر في قسم «عروض وخصومات» وبتتطبق من السلة أو من صفحة إتمام الطلب." },
  { q:"الأسعار شاملة الضريبة؟", a:"الأسعار المعروضة بالجنيه المصري شاملة كل الرسوم، ورسوم التوصيل تظهر بوضوح قبل التأكيد." }
];

/* =========================================================
   طبقة التخزين DB — تجريد فوق localStorage
   عند ربط backend حقيقي (Firebase/Supabase) تُستبدل هذه الدوال
   بنفس التوقيعات مع استدعاءات API — باقي الكود لا يتغير.
   مفتاح الأمان: لا كلمات مرور أو مفاتيح حساسة في الكلاينت
   في الإنتاج — هذا التطبيق وضع عرض محلي فقط.
   ========================================================= */
const DB = (() => {
  const PREFIX = "grill_v1_";
  const K = {
    settings:"settings", categories:"categories", products:"products",
    coupons:"coupons", orders:"orders", cart:"cart", favs:"favs",
    recent:"recent", reviews:"reviews", invlog:"invlog", seeded:"seeded"
  };
  function get(key, fallback){
    try{
      const raw = localStorage.getItem(PREFIX + key);
      return raw === null ? fallback : JSON.parse(raw);
    }catch(e){ console.warn("DB.get", key, e); return fallback; }
  }
  function set(key, val){
    try{ localStorage.setItem(PREFIX + key, JSON.stringify(val)); return true; }
    catch(e){ console.warn("DB.set", key, e); return false; }
  }
  function del(key){ localStorage.removeItem(PREFIX + key); }
  function seedIfEmpty(){
    if (get(K.seeded)) return;
    set(K.settings, DEFAULT_SETTINGS);
    set(K.categories, DEFAULT_CATEGORIES);
    set(K.products, DEFAULT_PRODUCTS);
    set(K.coupons, DEFAULT_COUPONS);
    set(K.reviews, DEFAULT_REVIEWS);
    set(K.orders, []);
    set(K.invlog, []);
    set(K.seeded, { at: Date.now(), version: 1 });
  }
  function resetAll(){
    Object.values(K).forEach(del);
    seedIfEmpty();
  }
  return { K, get, set, del, seedIfEmpty, resetAll, PREFIX };
})();

/* ---------- قراءة بيانات مدموجة مع الافتراضي ---------- */
function getSettings(){
  const s = DB.get(DB.K.settings, null) || {};
  return Object.assign({}, DEFAULT_SETTINGS, s, {
    payments: Object.assign({}, DEFAULT_SETTINGS.payments, s.payments || {}),
    promoBanner: Object.assign({}, DEFAULT_SETTINGS.promoBanner, s.promoBanner || {})
  });
}
function getCategories(){ return DB.get(DB.K.categories, DEFAULT_CATEGORIES); }
function getProducts(){
  /* توحيد القيم الافتراضية للنماذج القديمة: الصنف متاح ما لم يُعلَّم صراحة كغير متاح */
  return DB.get(DB.K.products, DEFAULT_PRODUCTS).map(p => Object.assign({ available: true }, p));
}
function getCoupons(){ return DB.get(DB.K.coupons, DEFAULT_COUPONS); }
function getOrders(){ return DB.get(DB.K.orders, []); }
function saveOrders(o){ return DB.set(DB.K.orders, o); }
function getReviews(){ return DB.get(DB.K.reviews, DEFAULT_REVIEWS); }

/* ---------- حالات الطلب ---------- */
const ORDER_STATUSES = [
  { id:"received",  label:"تم استلام الطلب",  icon:"📥" },
  { id:"confirmed", label:"جاري تأكيد الطلب", icon:"✅" },
  { id:"preparing", label:"جاري التحضير",     icon:"👨‍🍳" },
  { id:"ready",     label:"الطلب جاهز",       icon:"🔔" },
  { id:"out",       label:"خرج للتوصيل",      icon:"🛵" },
  { id:"delivered", label:"تم التسليم",       icon:"🎉" }
];
const STATUS_CANCELLED = { id:"cancelled", label:"ملغي", icon:"✕" };
function statusInfo(id){
  if (id === "cancelled") return STATUS_CANCELLED;
  return ORDER_STATUSES.find(s => s.id === id) || ORDER_STATUSES[0];
}
function statusIndex(id){
  if (id === "cancelled") return -1;
  return ORDER_STATUSES.findIndex(s => s.id === id);
}

/* ---------- أدوات عامة ---------- */
function fmtMoney(n){
  const v = Math.round(Number(n) || 0);
  return v.toLocaleString("en-US") + " " + (getSettings().currency || "ج.م");
}
function fmtDate(ts){
  try{
    return new Date(ts).toLocaleString("ar-EG", {
      day:"numeric", month:"long", hour:"numeric", minute:"2-digit"
    });
  }catch(e){ return new Date(ts).toLocaleString(); }
}
function genOrderRef(){
  const t = Date.now().toString(36).toUpperCase().slice(-4);
  const r = Math.random().toString(36).toUpperCase().slice(2, 5);
  return "LHB-" + t + r;
}
function uid(){ return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
function escapeHtml(s){
  return String(s == null ? "" : s)
    .replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;").replace(/'/g,"&#39;");
}
function isValidEgyptPhone(p){
  return /^01[0125][0-9]{8}$/.test(String(p || "").trim());
}
async function sha256Hex(text){
  try{
    if (crypto && crypto.subtle){
      const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
      return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("");
    }
  }catch(e){ /* غير متاح في سياق غير آمن */ }
  /* بديل بسيط للعرض فقط (FNV) — يُستبدل بمصادقة حقيقية في الإنتاج */
  let h = 0x811c9dc5;
  for (let i = 0; i < text.length; i++){ h ^= text.charCodeAt(i); h = (h * 0x01000193) >>> 0; }
  return "fnv_" + h.toString(16).padStart(8, "0");
}
function computeOpenNow(s){
  if (s.temporarilyClosed) return false;
  const now = new Date();
  const h = now.getHours();
  const open = s.openHour ?? 12, close = s.closeHour ?? 2;
  if (open === close) return true;
  if (open < close) return h >= open && h < close;
  return h >= open || h < close; // يعبر منتصف الليل
}

/* ---------- الخصم والتسعير (نفس القواعد تُعاد حسابها في الخادم عند الربط) ---------- */
function computePricing({ items, orderType, zoneId, couponCode }){
  const s = getSettings();
  let subtotal = 0;
  (items || []).forEach(it => { subtotal += it.unitPrice * it.qty; });
  const base = orderType === "pickup" ? s.minOrderPickup : s.minOrderDelivery;
  let deliveryFee = 0;
  if (orderType === "delivery"){
    const z = (s.deliveryZones || []).find(z => z.id === zoneId);
    deliveryFee = z ? z.fee : (s.deliveryZones || [])[0]?.fee || 0;
  }
  let discount = 0, freeDelivery = false, appliedCoupon = null;
  const code = String(couponCode || "").trim().toUpperCase();
  if (code){
    const c = getCoupons().find(c => c.code.toUpperCase() === code && c.active);
    if (c && subtotal >= c.minOrder){
      appliedCoupon = c.code;
      if (c.type === "percent") discount = Math.round(subtotal * c.value / 100);
      else if (c.type === "fixed") discount = Math.min(c.value, subtotal);
      else if (c.type === "free_delivery"){ freeDelivery = true; }
    }
  }
  if (freeDelivery) deliveryFee = 0;
  const total = Math.max(0, subtotal - discount) + deliveryFee;
  return { subtotal, discount, deliveryFee, total, appliedCoupon, minOrder: base };
}
