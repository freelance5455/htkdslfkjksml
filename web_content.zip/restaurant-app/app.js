/* =========================================================
   app.js — منطق واجهة العميل (تطبيق مطعم ومشويات اللهب)
   Vanilla JS — يعمل بالكامل في وضع العرض المحلي (localStorage)
   عند ربط backend حقيقي: استبدل دوال الحفظ/القراءة فقط.
   ========================================================= */
"use strict";

/* ===== الحالة العامة ===== */
const state = {
  cart: [], favs: [], recent: [],
  activeCat: "all", search: "", sort: "pop",
  pd: null,          // حالة نافذة المنتج
  couponCode: "",
  editingUid: null,  // تعديل عنصر موجود في السلة
  booted: false
};

const $ = sel => document.querySelector(sel);
const $$ = sel => Array.from(document.querySelectorAll(sel));

/* =========================================================
   الإقلاع
   ========================================================= */
document.addEventListener("DOMContentLoaded", () => {
  DB.seedIfEmpty();
  state.cart = DB.get(DB.K.cart, []);
  state.favs = DB.get(DB.K.favs, []);
  state.recent = DB.get(DB.K.recent, []);
  state.couponCode = DB.get("coupon", "");

  applySettingsToUI();
  renderAll();
  bindGlobalEvents();
  router();
  window.addEventListener("hashchange", router);
  window.addEventListener("storage", onStorage);
  setInterval(updateOpenBadge, 60000);
  state.booted = true;
});

/* مزامنة بين التبويبات (مثلاً الإدارة تعدّل من تبويب آخر) */
function onStorage(e){
  if (!e.key || !e.key.startsWith(DB.PREFIX)) return;
  const k = e.key.slice(DB.PREFIX.length);
  if (k === DB.K.orders){
    if (currentView() === "orders") renderOrdersView();
    if (currentView() === "track") renderTrackView();
  }
  if (k === DB.K.products || k === DB.K.categories || k === DB.K.settings){
    applySettingsToUI(); renderMenu(); renderBest(); renderCatChips();
  }
}

/* =========================================================
   الإعدادات → واجهة الصفحة
   ========================================================= */
function applySettingsToUI(){
  const s = getSettings();
  document.title = s.restaurantName + " | اطلب أونلاين";
  $("#brandName").textContent = s.restaurantName;
  $("#footerName").textContent = s.restaurantName;
  $("#heroKicker").textContent = "مشويات مصرية أصيلة · على الفحم";
  $("#heroSub").textContent = s.tagline;
  $("#heroHoursText").textContent = s.hoursLabel;
  $("#heroPrepText").textContent = "التحضير " + s.prepTimeLabel;
  $("#infoAddress").textContent = s.address;
  $("#infoHours").textContent = s.hoursLabel;
  $("#infoPrep").textContent = "متوسط وقت التحضير: " + s.prepTimeLabel;
  $("#infoPhone").textContent = s.phone;
  $("#pickupAddr").textContent = s.address;
  $("#mapLink").href = s.mapUrl || "#";
  const waBase = "https://wa.me/" + String(s.whatsapp || "").replace(/\D/g, "");
  const waMsg = encodeURIComponent("أهلاً " + s.restaurantName + "، عندي استفسار بخصوص الطلب");
  $("#waHeroBtn").href = waBase + "?text=" + waMsg;
  $("#waInfoLink").href = waBase + "?text=" + waMsg;
  $("#topCallBtn").href = "tel:" + s.phone;
  $("#heroImg").src = IMG.hero;
  $("#heroImg").onerror = function(){ this.style.display = "none"; };

  /* شريط العروض */
  const strip = $("#promoStrip");
  if (s.promoBanner && s.promoBanner.enabled && s.promoBanner.text){
    strip.hidden = false;
    $("#promoText").innerHTML = s.promoBanner.text;
  } else strip.hidden = true;

  /* المناطق في قسم المعلومات */
  $("#zonesList").innerHTML = (s.deliveryZones || []).map(z =>
    `<li><span>${escapeHtml(z.name)}</span><b>${fmtMoney(z.fee)}</b></li>`).join("")
    || "<li>حدد الإدارة مناطق التوصيل من لوحة التحكم.</li>";

  updateOpenBadge();
}

function updateOpenBadge(){
  const s = getSettings();
  const open = computeOpenNow(s);
  const badge = $("#openBadge");
  badge.classList.toggle("closed", !open);
  $("#openText").textContent = s.temporarilyClosed
    ? "مغلق مؤقتاً"
    : (open ? "مفتوح الآن" : "مغلق حالياً");
}

/* =========================================================
   التنقل (Hash Router)
   ========================================================= */
const VIEWS = ["home","checkout","confirm","orders","track","favorites"];
function currentView(){
  const h = (location.hash || "#/home").replace(/^#\//, "");
  return h.split("/")[0] || "home";
}
function hashParam(){
  const h = (location.hash || "").replace(/^#\//, "");
  const parts = h.split("/");
  return decodeURIComponent(parts[1] || "");
}
function go(path){ location.hash = "#/" + path; }

function router(){
  const view = currentView();
  VIEWS.forEach(v => {
    const el = $("#view" + v.charAt(0).toUpperCase() + v.slice(1));
    if (el) el.classList.toggle("hidden", v !== view);
  });
  $$(".bn-item").forEach(b => {
    const n = b.dataset.nav;
    b.classList.toggle("active", n === view || (n === "menu" && view === "home"));
  });
  closeCart();

  if (view === "checkout") renderCheckout();
  else if (view === "orders") renderOrdersView();
  else if (view === "favorites") renderFavoritesView();
  else if (view === "track"){
    renderTrackView(hashParam().toUpperCase());
  }
  else if (view === "confirm"){
    renderConfirmView(hashParam().toUpperCase());
  }
  else if (view === "menu"){
    /* زر القائمة → الصفحة الرئيسية مع التمرير لقائمة الطعام */
    go("home");
    setTimeout(() => $("#menuSection").scrollIntoView({ behavior:"smooth" }), 60);
  }
  if (view === "home") window.scrollTo({ top: 0 });
}

/* =========================================================
   الأقسام (chips)
   ========================================================= */
function renderCatChips(){
  const cats = getCategories().slice().sort((a,b) => (a.sort||0) - (b.sort||0));
  $("#catChips").innerHTML =
    `<button class="chip ${state.activeCat==="all"?"active":""}" data-action="cat" data-cat="all">🍽️ الكل</button>` +
    cats.map(c =>
      `<button class="chip ${state.activeCat===c.id?"active":""}" data-action="cat" data-cat="${c.id}">${c.emoji||""} ${escapeHtml(c.name)}</button>`
    ).join("");
}

/* =========================================================
   بطاقات المنتجات + القائمة
   ========================================================= */
function cardHTML(p){
  const cats = getCategories();
  const unavailable = !p.available || isStockOut(p);
  const off = p.oldPrice && p.oldPrice > p.price ? Math.round((1 - p.price / p.oldPrice) * 100) : 0;
  const fav = state.favs.includes(p.id);
  return `
  <article class="prod-card ${unavailable ? "unavailable" : ""}" data-id="${p.id}">
    <div class="prod-img-wrap">
      <img class="prod-img lazy" data-src="${p.img || ""}" alt="${escapeHtml(p.name)}"
           loading="lazy" onerror="this.src='${PLACEHOLDER_IMG}'">
      <div class="badges">
        ${p.bestSeller ? '<span class="badge best">🔥 الأكثر مبيعاً</span>' : ""}
        ${off ? `<span class="badge off">خصم ${off}٪</span>` : ""}
        ${unavailable ? '<span class="badge out">غير متاح حالياً</span>' : ""}
      </div>
      <button class="fav-btn ${fav ? "active" : ""}" data-action="fav" data-id="${p.id}" aria-label="إضافة للمفضلة">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M19 14c1.5-1.5 2.3-3.2 2.3-5A5.3 5.3 0 0 0 16 3.7c-1.6 0-3.1.9-4 2.2-.9-1.3-2.4-2.2-4-2.2A5.3 5.3 0 0 0 2.7 9c0 1.8.8 3.5 2.3 5l7 7.2z"/></svg>
      </button>
    </div>
    <div class="prod-body">
      <h3 class="prod-name">${escapeHtml(p.name)}</h3>
      <p class="prod-desc">${escapeHtml(p.desc || "")}</p>
      <div class="prod-foot">
        <div class="price-row">
          <span class="price">${fmtMoney(p.price)}${p.oldPrice ? `<span class="price-old" style="margin-inline-start:6px">${fmtMoney(p.oldPrice)}</span>` : ""}</span>
        </div>
        <button class="add-mini" data-action="open-product" data-id="${p.id}"
                ${unavailable ? "disabled" : ""} aria-label="إضافة ${escapeHtml(p.name)} للسلة">+</button>
      </div>
    </div>
  </article>`;
}

/* صورة بديلة عند فشل التحميل (SVG مضمّن: لهب) */
const PLACEHOLDER_IMG = "data:image/svg+xml," + encodeURIComponent(
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300"><rect width="400" height="300" fill="#2C241E"/><path d="M200 60c14 38-28 52-28 90a49 49 0 0 0 98 0c0-19-9-33-19-42 1 14-8 22-16 23 10-19-8-56-35-71z" fill="#F07824"/><text x="200" y="255" font-size="20" fill="#8B8175" text-anchor="middle" font-family="sans-serif">صورة الطبق</text></svg>`
);

function lazyLoadImgs(root){
  (root || document).querySelectorAll("img.lazy[data-src]").forEach(img => {
    img.src = img.dataset.src;
    img.removeAttribute("data-src");
    img.classList.remove("lazy");
    img.addEventListener("load", () => img.classList.add("loaded"), { once:true });
  });
}

function filteredProducts(){
  const prods = getProducts();
  const q = state.search.trim().toLowerCase();
  let list = prods.filter(p => {
    const catOk = state.activeCat === "all" || p.cat === state.activeCat;
    if (!catOk) return false;
    if (!q) return true;
    return (p.name + " " + (p.desc || "")).toLowerCase().includes(q);
  });
  if (state.sort === "priceAsc") list = list.slice().sort((a,b) => a.price - b.price);
  else if (state.sort === "priceDesc") list = list.slice().sort((a,b) => b.price - a.price);
  else if (state.sort === "name") list = list.slice().sort((a,b) => a.name.localeCompare(b.name, "ar"));
  else { /* pop: الأكثر مبيعاً أولاً */
    list = list.slice().sort((a,b) => (b.bestSeller?2:0) + (b.featured?1:0) - (a.bestSeller?2:0) - (a.featured?1:0));
  }
  return list;
}

function renderMenu(){
  const cats = getCategories().slice().sort((a,b) => (a.sort||0) - (b.sort||0));
  const list = filteredProducts();
  const grid = $("#menuGrid");
  $("#menuCountHint").textContent = list.length ? (list.length + " صنف") : "";
  $("#menuEmpty").classList.toggle("hidden", list.length > 0);

  /* التجميع بالأقسام يظهر فقط مع الترتيب الافتراضي وبلا بحث؛
     أي ترتيب أو بحث أو فلتر يعرض شبكة واحدة مرتبة عالمياً */
  if (state.activeCat === "all" && !state.search && state.sort === "pop"){
    grid.innerHTML = cats.map(c => {
      const items = list.filter(p => p.cat === c.id);
      if (!items.length) return "";
      return `
      <div class="cat-block" id="cat-${c.id}">
        <h3 class="cat-title"><span class="cat-emoji">${c.emoji || ""}</span> ${escapeHtml(c.name)}</h3>
        <div class="prod-grid">${items.map(cardHTML).join("")}</div>
      </div>`;
    }).join("");
  } else {
    grid.innerHTML = `<div class="prod-grid" style="margin-top:6px">${list.map(cardHTML).join("")}</div>`;
  }
  lazyLoadImgs(grid);
}

function renderBest(){
  const prods = getProducts().filter(p => p.bestSeller && p.available && !isStockOut(p));
  const sec = $("#bestSection");
  sec.hidden = prods.length === 0;
  $("#bestRow").innerHTML = prods.map(cardHTML).join("");
  lazyLoadImgs($("#bestRow"));
}

function renderRecent(){
  const sec = $("#recentSection");
  const items = state.recent.map(id => getProducts().find(p => p.id === id)).filter(Boolean);
  sec.hidden = items.length === 0;
  $("#recentRow").innerHTML = items.map(cardHTML).join("");
  lazyLoadImgs($("#recentRow"));
}

function renderCouponsSection(){
  const actives = getCoupons().filter(c => c.active);
  const sec = $("#couponsSection");
  sec.hidden = actives.length === 0;
  $("#couponRow").innerHTML = actives.map(c => {
    const val = c.type === "percent" ? `${c.value}٪ خصم`
      : c.type === "fixed" ? `${fmtMoney(c.value)} خصم` : "توصيل مجاني";
    return `
    <div class="coupon-card">
      <div class="coupon-val">${val}</div>
      <p class="coupon-cond">${escapeHtml(c.note || "")} — الحد الأدنى ${fmtMoney(c.minOrder)}</p>
      <button class="coupon-code-btn" data-action="copy-coupon" data-code="${escapeHtml(c.code)}">${escapeHtml(c.code)}</button>
    </div>`;
  }).join("");
}

/* =========================================================
   نافذة تفاصيل المنتج والتخصيص
   ========================================================= */
function openProductModal(id, editUid){
  const p = getProducts().find(x => x.id === id);
  if (!p) return;
  const unavailable = !p.available || isStockOut(p);

  /* تعبئة الحالة */
  let sizeId = p.sizes && p.sizes.length ? p.sizes[0].id : null;
  let extras = [];
  let qty = 1, notes = "";
  if (editUid){
    const it = state.cart.find(c => c.uid === editUid);
    if (it){
      sizeId = it.sizeId; extras = (it.extras || []).map(e => e.id);
      qty = it.qty; notes = it.notes || "";
    }
  }
  state.pd = { product: p, sizeId, extras: new Set(extras), qty, notes };

  const off = p.oldPrice && p.oldPrice > p.price ? Math.round((1 - p.price / p.oldPrice) * 100) : 0;
  const modal = $("#productModal");
  modal.innerHTML = `
  <div class="pd-sheet">
    <div class="pd-hero">
      <img src="${p.img || PLACEHOLDER_IMG}" alt="${escapeHtml(p.name)}" onerror="this.src='${PLACEHOLDER_IMG}'">
      <div class="pd-hero-shade"></div>
      <button class="pd-close" data-action="close-modal" aria-label="إغلاق">✕</button>
      <div class="pd-hero-badges">
        ${p.bestSeller ? '<span class="badge best">🔥 الأكثر مبيعاً</span>' : ""}
        ${off ? `<span class="badge off">خصم ${off}٪</span>` : ""}
        ${unavailable ? '<span class="badge out">غير متاح حالياً</span>' : ""}
      </div>
    </div>
    <div class="pd-body">
      <h2 class="pd-title">${escapeHtml(p.name)}</h2>
      <div class="pd-meta">
        <span class="meta-chip">⏱️ ${escapeHtml(p.prepTime || "٢٥ دقيقة")}</span>
        <span class="meta-chip">💰 ${fmtMoney(p.price)}</span>
      </div>
      <p class="pd-desc">${escapeHtml(p.desc || "")}</p>
      <div id="pdOptions">
        ${p.sizes && p.sizes.length ? `
        <div class="opt-group">
          <div class="opt-title">الحجم / الكمية <span class="req">اختر واحداً</span></div>
          <div class="opt-cards" id="sizeCards">
            ${p.sizes.map(s => `
            <div class="opt-card ${s.id === sizeId ? "selected" : ""}" data-action="pd-size" data-id="${s.id}" role="radio" aria-checked="${s.id === sizeId}">
              <span class="opt-name">${escapeHtml(s.name)}</span>
              <span class="opt-price">${s.delta ? (s.delta > 0 ? "+ " : "") + fmtMoney(Math.abs(s.delta)) : "بدون إضافة"}</span>
              <span class="opt-check">✓</span>
            </div>`).join("")}
          </div>
        </div>` : ""}
        ${p.extras && p.extras.length ? `
        <div class="opt-group">
          <div class="opt-title">إضافات اختيارية <span class="req">اختياري</span></div>
          <div class="opt-cards" id="extraCards">
            ${p.extras.map(e => `
            <div class="opt-card ${extras.includes(e.id) ? "selected" : ""}" data-action="pd-extra" data-id="${e.id}" role="checkbox" aria-checked="${extras.includes(e.id)}">
              <span class="opt-name">${escapeHtml(e.name)}</span>
              <span class="opt-price">+ ${fmtMoney(e.price)}</span>
              <span class="opt-check">✓</span>
            </div>`).join("")}
          </div>
        </div>` : ""}
        <div class="opt-group">
          <div class="opt-title">ملاحظات للمطبخ <span class="req">اختياري</span></div>
          <div class="field"><textarea id="pdNotes" rows="2" maxlength="200"
            placeholder="مثال: من غير بصل، شطة زيادة على الجمبري…">${escapeHtml(notes)}</textarea></div>
        </div>
      </div>
    </div>
    <div class="pd-foot">
      <div class="pd-qty">
        <button class="qty-btn" data-action="pd-qty" data-d="1" aria-label="زيادة الكمية">+</button>
        <span class="qty-num" id="pdQtyNum">${qty}</span>
        <button class="qty-btn" data-action="pd-qty" data-d="-1" aria-label="تقليل الكمية">−</button>
      </div>
      <button class="btn btn-primary btn-lg pd-add" data-action="pd-add" ${unavailable ? "disabled" : ""}>
        <span class="pd-add-price">
          <span class="lbl">${editUid ? "حفظ التعديل" : "أضف للسلة"}</span>
          <span class="val" id="pdTotal">${fmtMoney(pdUnitPrice() * qty)}</span>
        </span>
      </button>
    </div>
  </div>`;
  modal.hidden = false;
  requestAnimationFrame(() => modal.classList.add("show"));
  document.body.style.overflow = "hidden";
  if (editUid) state.editingUid = editUid;
}

function pdUnitPrice(){
  const { product: p, sizeId, extras } = state.pd;
  let unit = p.price;
  const size = (p.sizes || []).find(s => s.id === sizeId);
  if (size) unit += size.delta || 0;
  (p.extras || []).forEach(e => { if (extras.has(e.id)) unit += e.price; });
  return unit;
}
function pdUpdateTotal(){
  const el = $("#pdTotal");
  if (el && state.pd) el.textContent = fmtMoney(pdUnitPrice() * state.pd.qty);
}
function closeModal(){
  const m = $("#productModal");
  m.classList.remove("show");
  document.body.style.overflow = "";
  setTimeout(() => { m.hidden = true; m.innerHTML = ""; }, 220);
  state.pd = null; state.editingUid = null;
}

function pushRecent(id){
  state.recent = [id, ...state.recent.filter(x => x !== id)].slice(0, 8);
  DB.set(DB.K.recent, state.recent);
}

/* =========================================================
   السلة
   ========================================================= */
function saveCart(){
  DB.set(DB.K.cart, state.cart);
  DB.set("coupon", state.couponCode);
  updateCartBadge();
}
function cartQtyTotal(){ return state.cart.reduce((n, it) => n + it.qty, 0); }
function updateCartBadge(){
  const n = cartQtyTotal();
  [$("#cartCount"), $("#bnCartBadge")].forEach(el => {
    el.textContent = n;
    el.classList.toggle("hidden", n === 0);
  });
}
function sameConfig(a, b){
  const ex = x => (x.extras || []).map(e => e.id).sort().join(",");
  return a.productId === b.productId && a.sizeId === b.sizeId && ex(a) === ex(b)
    && (a.notes || "") === (b.notes || "");
}
function addToCart(entry){
  const existing = state.cart.find(c => sameConfig(c, entry));
  if (existing){
    existing.qty += entry.qty;
    if (state.editingUid) existing.uid = existing.uid; /* دمج عند التعديل */
    return existing;
  }
  state.cart.push(entry);
  return entry;
}
function itemFromModal(){
  const { product: p, sizeId } = state.pd;
  const size = (p.sizes || []).find(s => s.id === sizeId);
  const extras = (p.extras || []).filter(e => state.pd.extras.has(e.id)).map(e => ({ id:e.id, name:e.name, price:e.price }));
  const notes = ($("#pdNotes") && $("#pdNotes").value.trim()) || "";
  return {
    uid: uid(), productId: p.id, name: p.name, img: p.img,
    sizeId: sizeId || null, sizeName: size ? size.name : null,
    extras, qty: state.pd.qty, notes,
    unitPrice: pdUnitPrice()
  };
}

function openCart(){
  renderCart();
  $("#cartOverlay").hidden = false;
  requestAnimationFrame(() => {
    $("#cartOverlay").classList.add("show");
    $("#cartDrawer").classList.add("open");
  });
  $("#cartDrawer").setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
}
function closeCart(){
  const ov = $("#cartOverlay"), dr = $("#cartDrawer");
  if (!dr || !dr.classList.contains("open")) return;
  ov.classList.remove("show");
  dr.classList.remove("open");
  dr.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
  setTimeout(() => { if (ov) ov.hidden = true; }, 280);
}

function renderCart(){
  const body = $("#cartBody"), foot = $("#cartFoot");
  updateCartBadge();
  if (!state.cart.length){
    body.innerHTML = `
      <div class="cart-empty">
        <div class="empty-ic">🛒</div>
        <h3>سلتك فاضية</h3>
        <p>ابدأ بإضافة أطباقك المفضلة من القائمة.</p>
        <button class="btn btn-primary" data-action="go-menu">تصفح القائمة</button>
      </div>`;
    foot.innerHTML = "";
    return;
  }
  body.innerHTML = state.cart.map(it => `
    <div class="cart-item">
      <img class="cart-img" src="${it.img || PLACEHOLDER_IMG}" alt="" onerror="this.src='${PLACEHOLDER_IMG}'">
      <div class="cart-info">
        <p class="cart-name">${escapeHtml(it.name)}</p>
        <p class="cart-opts">${escapeHtml([it.sizeName, (it.extras||[]).map(e=>e.name).join(" + ")].filter(Boolean).join(" · ") || "بدون إضافات")}</p>
        ${it.notes ? `<p class="cart-notes">📝 ${escapeHtml(it.notes)}</p>` : ""}
        <div class="cart-qty">
          <button class="qty-btn" data-action="cart-inc" data-uid="${it.uid}" aria-label="زيادة">+</button>
          <span class="qty-num">${it.qty}</span>
          <button class="qty-btn" data-action="cart-dec" data-uid="${it.uid}" aria-label="تقليل">−</button>
          <span style="flex:1"></span>
          <button class="cart-edit-btn" data-action="cart-edit" data-uid="${it.uid}">تعديل</button>
          <button class="cart-del-btn" data-action="cart-remove" data-uid="${it.uid}">حذف</button>
        </div>
      </div>
      <span class="cart-line-price">${fmtMoney(it.unitPrice * it.qty)}</span>
    </div>`).join("") +
    `<div class="cart-actions-row">
       <button class="cart-del-btn" data-action="cart-clear">🗑️ تفريغ السلة</button>
     </div>`;

  const pr = computePricing({ items: state.cart, orderType: "delivery", zoneId: null, couponCode: state.couponCode });
  const s = getSettings();
  const minOrder = s.minOrderDelivery;
  const below = pr.subtotal < minOrder;

  foot.innerHTML = `
    <div class="coupon-inline">
      <input type="text" id="cartCoupon" value="${escapeHtml(state.couponCode)}" placeholder="كود الخصم" aria-label="كود الخصم">
      <button class="btn btn-outline btn-sm" data-action="cart-coupon">تطبيق</button>
    </div>
    <div class="totals">
      <div class="t-row"><span>المجموع الفرعي</span><b>${fmtMoney(pr.subtotal)}</b></div>
      ${pr.discount ? `<div class="t-row t-discount"><span>الخصم (${escapeHtml(pr.appliedCoupon)})</span><b>− ${fmtMoney(pr.discount)}</b></div>` : ""}
      ${!pr.appliedCoupon && state.couponCode ? `<div class="t-row" style="color:#ff8589;font-size:.78rem"><span>الكود غير صالح أو الحد الأدنى غير مستوفى</span></div>` : ""}
      <div class="t-row"><span>رسوم التوصيل</span><b>تُحدد حسب المنطقة</b></div>
      <div class="t-row t-grand"><span>الإجمالي التقديري</span><b>${fmtMoney(pr.subtotal - pr.discount)}</b></div>
    </div>
    ${below ? `<div class="min-order-warn">⚠️ الحد الأدنى لطلبات التوصيل ${fmtMoney(minOrder)} — أضف ${fmtMoney(minOrder - pr.subtotal)} للمتابعة.</div>` : ""}
    <button class="btn btn-primary btn-lg btn-block" style="margin-top:12px" data-action="go-checkout" ${below ? "disabled" : ""}>
      إتمام الطلب
    </button>
    <p class="cart-hint">💡 الأسعار بالجنيه المصري · رسوم التوصيل حسب المنطقة</p>`;
}

function applyCouponFrom(inputEl){
  const code = inputEl.value.trim().toUpperCase();
  if (!code){
    state.couponCode = "";
    saveCart(); renderCart();
    toast("تم مسح كود الخصم", "ok");
    return;
  }
  const c = getCoupons().find(c => c.code.toUpperCase() === code && c.active);
  const pr = computePricing({ items: state.cart, orderType: "delivery", zoneId: null, couponCode: code });
  if (c && pr.appliedCoupon){
    state.couponCode = code;
    toast(`تم تطبيق الكود ${code} 🎉`, "ok");
  } else if (c && !pr.appliedCoupon){
    toast(`الحد الأدنى لهذا الكود ${fmtMoney(c.minOrder)}`, "err");
  } else {
    toast("كود الخصم غير صالح", "err");
  }
  saveCart(); renderCart();
  syncCheckoutCoupon();
}
function syncCheckoutCoupon(){
  const el = $("#ckCoupon");
  if (el) el.value = state.couponCode;
}

/* =========================================================
   إتمام الطلب
   ========================================================= */
function renderCheckout(){
  const s = getSettings();
  /* مناطق التوصيل */
  const zoneSel = $("#ckZone");
  zoneSel.innerHTML = `<option value="">— اختر المنطقة —</option>` +
    (s.deliveryZones || []).map(z =>
      `<option value="${z.id}">${escapeHtml(z.name)} — ${fmtMoney(z.fee)} (${escapeHtml(z.eta || "")})</option>`).join("");
  if (state.zoneId) zoneSel.value = state.zoneId;

  /* طرق الدفع */
  const type = checkoutType();
  const pays = [];
  if (type === "delivery" && s.payments.cod)
    pays.push({ id:"cod", label:"كاش عند التوصيل", ic:"💵", ok:true });
  if (type === "pickup" && s.payments.pickupCash)
    pays.push({ id:"pickupCash", label:"كاش عند الاستلام", ic:"🏪", ok:true });
  if (s.payments.electronic)
    pays.push({ id:"electronic", label:"دفع إلكتروني", ic:"💳", ok:true });
  else
    pays.push({ id:"electronic", label:"دفع إلكتروني (غير متاح بعد — يتطلب بوابة دفع)", ic:"💳", ok:false });

  $("#payGroup").innerHTML = pays.map(p => `
    <label class="opt-card ${p.ok ? "" : "unavailable"}" style="cursor:${p.ok ? "pointer" : "not-allowed"};opacity:${p.ok ? 1 : .55}">
      <span class="opt-name">${p.ic} ${escapeHtml(p.label)}</span>
      <input type="radio" name="payment" value="${p.id}" ${p.ok ? "" : "disabled"} style="accent-color:var(--orange);width:19px;height:19px">
    </label>`).join("");

  $("#deliveryFields").hidden = type !== "delivery";
  $("#pickupNote").hidden = type !== "pickup";
  $("#ckDemoNote").textContent = s.demoMode
    ? "⚙️ وضع العرض التجريبي: الطلب سيُحفظ محلياً في هذا المتصفح فقط حتى ربط الخادم الحقيقي."
    : "";
  updateCheckoutSummary();
}

function checkoutType(){
  const r = document.querySelector('input[name="orderType"]:checked');
  return r ? r.value : "delivery";
}

function updateCheckoutSummary(){
  const type = checkoutType();
  const zoneId = $("#ckZone") ? $("#ckZone").value : "";
  const items = $("#ckItems");
  items.innerHTML = state.cart.map(it => `
    <div class="ck-item">
      <span><span class="n">${it.qty}×</span> ${escapeHtml(it.name)}
        ${it.sizeName ? `<span class="opts">${escapeHtml(it.sizeName)}</span>` : ""}
        ${(it.extras||[]).length ? `<span class="opts">${escapeHtml(it.extras.map(e=>e.name).join(" + "))}</span>` : ""}
      </span>
      <b style="white-space:nowrap">${fmtMoney(it.unitPrice * it.qty)}</b>
    </div>`).join("");

  const pr = computePricing({ items: state.cart, orderType: type, zoneId, couponCode: state.couponCode });
  $("#ckTotals").innerHTML = `
    <div class="totals">
      <div class="t-row"><span>المجموع الفرعي</span><b>${fmtMoney(pr.subtotal)}</b></div>
      ${pr.discount ? `<div class="t-row t-discount"><span>الخصم (${escapeHtml(pr.appliedCoupon)})</span><b>− ${fmtMoney(pr.discount)}</b></div>` : ""}
      <div class="t-row"><span>${type === "delivery" ? "رسوم التوصيل" : "الاستلام من المطعم"}</span><b>${type === "delivery" ? fmtMoney(pr.deliveryFee) : "مجاناً"}</b></div>
      <div class="t-row t-grand"><span>الإجمالي</span><b>${fmtMoney(pr.total)}</b></div>
    </div>`;
  return pr;
}

function validateCheckout(){
  let ok = true;
  const type = checkoutType();
  const name = $("#ckName"), phone = $("#ckPhone"), addr = $("#ckAddress"), zone = $("#ckZone");
  const err = (el, id, msg) => {
    $("#" + id).textContent = msg || "";
    el.classList.toggle("invalid", !!msg);
    if (msg) ok = false;
  };
  err(name, "errName", name.value.trim().length >= 3 ? "" : "اكتب الاسم بالكامل (٣ أحرف على الأقل)");
  err(phone, "errPhone", isValidEgyptPhone(phone.value.trim()) ? "" : "رقم موبايل مصري غير صحيح — مثال: 01012345678");
  if (type === "delivery"){
    err(addr, "errAddress", addr.value.trim().length >= 10 ? "" : "اكتب عنواناً واضحاً (١٠ أحرف على الأقل)");
    err(zone, "errZone", zone.value ? "" : "اختر منطقة التوصيل");
  } else {
    err(addr, "errAddress", ""); err(zone, "errZone", "");
  }
  const pay = document.querySelector('input[name="payment"]:checked');
  $("#errPay").textContent = pay ? "" : "اختر طريقة الدفع";
  if (!pay) ok = false;
  return ok;
}

function submitOrder(btn){
  if (!state.cart.length){ toast("السلة فاضية", "err"); return; }
  if (!validateCheckout()){ toast("راجع الحقول المطلوبة", "err"); return; }

  const type = checkoutType();
  const zone = $("#ckZone");
  const pr = computePricing({ items: state.cart, orderType: type, zoneId: zone.value, couponCode: state.couponCode });

  const order = {
    id: uid(),
    ref: genOrderRef(),
    createdAt: Date.now(),
    type,                                   // delivery | pickup
    customer: {
      name: $("#ckName").value.trim(),
      phone: $("#ckPhone").value.trim(),
      address: type === "delivery" ? $("#ckAddress").value.trim() : "",
      zoneName: type === "delivery" ? zone.options[zone.selectedIndex].text : "",
      notes: $("#ckNotes").value.trim()
    },
    payment: document.querySelector('input[name="payment"]:checked').value,
    items: state.cart.map(it => ({
      productId: it.productId, name: it.name, sizeId: it.sizeId, sizeName: it.sizeName,
      extras: it.extras, qty: it.qty, unitPrice: it.unitPrice, notes: it.notes
    })),
    pricing: { subtotal: pr.subtotal, discount: pr.discount, deliveryFee: pr.deliveryFee, total: pr.total },
    couponCode: pr.appliedCoupon || "",
    status: "received",
    statusHistory: [{ status: "received", at: Date.now() }],
    cancellationRequested: false,
    cancelReason: null,
    demo: true
  };

  /* محاكاة إرسال للخادم — عند الربط الحقيقي: POST /orders ثم انتظار الاستجابة */
  btn.classList.add("loading");
  btn.disabled = true;
  setTimeout(() => {
    try{
      const orders = getOrders();
      orders.unshift(order);
      if (!saveOrders(orders)) throw new Error("storage full");
      state.cart = [];
      state.couponCode = "";
      saveCart();
      btn.classList.remove("loading");
      btn.disabled = false;
      go("confirm/" + order.ref);
    }catch(e){
      btn.classList.remove("loading");
      btn.disabled = false;
      toast("تعذر حفظ الطلب — مساحة التخزين ممتلئة", "err");
    }
  }, 900);
}

/* =========================================================
   شاشة التأكيد
   ========================================================= */
function renderConfirmView(ref){
  const order = getOrders().find(o => o.ref === ref);
  const box = $("#viewConfirm");
  if (!order){
    box.innerHTML = `
    <div class="confirm-wrap">
      <div class="empty-state">
        <div class="empty-ic">🔍</div>
        <h3>لم نجد هذا الطلب</h3>
        <p>قد يكون الطلب أُنشئ على جهاز آخر. استخدم «تتبع طلب بدون حساب» برقم الطلب والموبايل.</p>
        <button class="btn btn-primary" data-action="go-home">العودة للرئيسية</button>
      </div>
    </div>`;
    return;
  }
  box.innerHTML = `
  <div class="confirm-wrap">
    <div class="confirm-ic">✅</div>
    <h1>تم استلام طلبك بنجاح!</h1>
    <p class="confirm-sub">احفظ رقم الطلب للمتابعة والتواصل:</p>
    <div class="confirm-ref">${order.ref}</div>
    <p class="confirm-sub">الإجمالي: <b style="color:var(--orange-soft)">${fmtMoney(order.pricing.total)}</b> · ${order.type === "delivery" ? "🛵 توصيل" : "🏪 استلام من المطعم"}</p>
    <div class="confirm-actions">
      <button class="btn btn-primary btn-lg" data-action="track" data-ref="${order.ref}">تتبع الطلب</button>
      <button class="btn btn-outline btn-lg" data-action="go-home">العودة للقائمة</button>
    </div>
    ${order.demo ? `<p class="demo-note" style="margin-top:20px">⚙️ هذا وضع عرض تجريبي — الطلب محفوظ محلياً ولم يُرسل لخادم حقيقي بعد.</p>` : ""}
  </div>`;
}

/* =========================================================
   طلباتي
   ========================================================= */
function renderOrdersView(){
  const list = $("#ordersList");
  const orders = getOrders();
  if (!orders.length){
    list.innerHTML = `
    <div class="empty-state">
      <div class="empty-ic">🧾</div>
      <h3>لا توجد طلبات بعد</h3>
      <p>أول طلب ليك هيظهر هنا مع حالته لحظة بلحظة.</p>
      <button class="btn btn-primary" data-action="go-menu">اطلب دلوقتي</button>
    </div>`;
    return;
  }
  list.innerHTML = orders.map(orderCardHTML).join("");
}

function orderCardHTML(o){
  const st = statusInfo(o.status);
  const itemsText = o.items.map(i => `${i.qty}× ${i.name}`).join(" · ");
  return `
  <div class="order-card">
    <div class="oc-head">
      <div>
        <span class="oc-ref">${o.ref}</span>
        <span class="oc-date"> · ${fmtDate(o.createdAt)}</span>
      </div>
      <span class="status-pill st-${st.id}">${st.icon} ${st.label}</span>
    </div>
    <p class="oc-items">${escapeHtml(itemsText)}</p>
    <div class="oc-total">
      <span>${o.type === "delivery" ? "🛵 توصيل" : "🏪 استلام"}${o.cancellationRequested ? ' · <b style="color:#ff8589">طلب إلغاء قيد المراجعة</b>' : ""}</span>
      <b>${fmtMoney(o.pricing.total)}</b>
    </div>
    <div class="oc-actions">
      <button class="btn btn-sm btn-primary" data-action="track" data-ref="${o.ref}">تتبع</button>
      <button class="btn btn-sm btn-outline" data-action="reorder" data-id="${o.id}">أعد الطلب</button>
      ${canRequestCancel(o) ? `<button class="btn btn-sm btn-danger" data-action="cancel-request" data-id="${o.id}">طلب إلغاء</button>` : ""}
    </div>
  </div>`;
}

function canRequestCancel(o){
  const s = getSettings();
  if (s.cancellationPolicy === "never") return false;
  if (["delivered","cancelled"].includes(o.status)) return false;
  if (o.cancellationRequested) return false;
  if (s.cancellationPolicy === "always") return true;
  return statusIndex(o.status) <= 1; /* قبل بدء التحضير */
}

function requestCancel(o){
  confirmDialog("طلب إلغاء الطلب", "هل تريد إرسال طلب إلغاء لهذا الطلب؟ سيتم مراجعته من إدارة المطعم حسب سياسة الإلغاء.", () => {
    const orders = getOrders();
    const t = orders.find(x => x.id === o.id);
    if (t){ t.cancellationRequested = true; saveOrders(orders); }
    toast("تم إرسال طلب الإلغاء للإدارة ✉️", "ok");
    renderOrdersView();
    if (currentView() === "track") renderTrackView();
  });
}

function reorder(orderId){
  const o = getOrders().find(x => x.id === orderId);
  if (!o) return;
  let added = 0;
  o.items.forEach(src => {
    const p = getProducts().find(x => x.id === src.productId);
    if (!p || !p.available || isStockOut(p)) return;
    const entry = {
      uid: uid(), productId: p.id, name: p.name, img: p.img,
      sizeId: src.sizeId, sizeName: src.sizeName,
      extras: (src.extras || []).filter(e => (p.extras || []).some(pe => pe.id === e.id)),
      qty: src.qty, notes: src.notes || "", unitPrice: 0
    };
    entry.unitPrice = p.price
      + ((p.sizes || []).find(s => s.id === entry.sizeId)?.delta || 0)
      + entry.extras.reduce((n, e) => n + (e.price || 0), 0);
    addToCart(entry);
    added++;
  });
  saveCart();
  if (added){ toast(`تمت إضافة ${added} صنف من طلبك السابق للسلة`, "ok"); openCart(); }
  else toast("الأصناف غير متاحة حالياً", "err");
}

/* =========================================================
   تتبع الطلب
   ========================================================= */
function renderTrackView(refArg){
  const body = $("#trackBody");
  let ref = refArg || hashParam().toUpperCase();
  const order = getOrders().find(o => o.ref === ref);
  if (!order){
    body.innerHTML = `
    <div class="empty-state">
      <div class="empty-ic">🔍</div>
      <h3>لم نجد طلباً بهذا الرقم</h3>
      <p>تأكد من رقم الطلب، أو استخدم البحث من صفحة «طلباتي» برقم الموبايل.</p>
      <button class="btn btn-outline" data-action="go-orders">طلباتي</button>
    </div>`;
    return;
  }
  const cur = statusIndex(order.status);
  const st = statusInfo(order.status);
  const timeline = order.status === "cancelled"
    ? `<div class="min-order-warn" style="background:rgba(229,72,77,.08)">✕ تم إلغاء هذا الطلب${order.cancelReason ? ` — السبب: ${escapeHtml(order.cancelReason)}` : ""} بتاريخ ${fmtDate(order.statusHistory[order.statusHistory.length-1].at)}</div>`
    : `<div class="timeline">${ORDER_STATUSES.map((s, i) => `
        <div class="tl-item ${i < cur ? "done" : ""} ${i === cur ? "current" : ""}">
          <div class="tl-dot">${s.icon}</div>
          <div class="tl-label">${s.label}
            ${i <= cur ? (() => {
              const h = order.statusHistory.find(h => h.status === s.id);
              return h ? `<span class="tl-time">${fmtDate(h.at)}</span>` : "";
            })() : ""}
          </div>
        </div>`).join("")}
      </div>`;

  body.innerHTML = `
  <div class="track-wrap">
    <div class="track-card">
      <div class="oc-head">
        <div><span class="oc-ref">${order.ref}</span><span class="oc-date"> · ${fmtDate(order.createdAt)}</span></div>
        <span class="status-pill st-${st.id}">${st.icon} ${st.label}</span>
      </div>
      ${timeline}
      ${order.cancellationRequested && order.status !== "cancelled" ? `<div class="min-order-warn" style="background:rgba(240,120,36,.08);border-color:rgba(240,120,36,.4);color:var(--orange-soft)">⏳ لديك طلب إلغاء قيد المراجعة من الإدارة</div>` : ""}
      <div class="oc-actions">
        ${canRequestCancel(order) ? `<button class="btn btn-sm btn-danger" data-action="cancel-request" data-id="${order.id}">طلب إلغاء</button>` : ""}
        <button class="btn btn-sm btn-outline" data-action="print-receipt" data-id="${order.id}">🖨️ طباعة الإيصال</button>
        <a class="btn btn-sm btn-wa" href="https://wa.me/${getSettings().whatsapp}?text=${encodeURIComponent("استفسار عن الطلب رقم " + order.ref)}" target="_blank" rel="noopener">استفسار واتساب</a>
      </div>
    </div>
    <div class="track-card">
      <h3 style="font-size:1rem;margin-bottom:10px;color:var(--cream)">تفاصيل الطلب</h3>
      <ul class="track-items">
        ${order.items.map(i => `
        <li><span>${i.qty}× ${escapeHtml(i.name)}${i.sizeName ? ` <small style="color:var(--muted)">(${escapeHtml(i.sizeName)})</small>` : ""}${(i.extras && i.extras.length) ? ` <small style="color:var(--muted)">+ ${escapeHtml(i.extras.map(e=>e.name).join(" + "))}</small>` : ""}</span><b>${fmtMoney(i.unitPrice * i.qty)}</b></li>`).join("")}
        <li><span>المجموع الفرعي</span><b>${fmtMoney(order.pricing.subtotal)}</b></li>
        ${order.pricing.discount ? `<li style="color:#7edc8e"><span>الخصم</span><b>− ${fmtMoney(order.pricing.discount)}</b></li>` : ""}
        <li><span>${order.type === "delivery" ? "رسوم التوصيل" : "استلام من المطعم"}</span><b>${order.type === "delivery" ? fmtMoney(order.pricing.deliveryFee) : "مجاناً"}</b></li>
        <li style="font-size:1.05rem"><span style="color:var(--cream);font-weight:700">الإجمالي</span><b style="color:var(--orange-soft)">${fmtMoney(order.pricing.total)}</b></li>
      </ul>
      ${order.type === "delivery" ? `<p style="font-size:.82rem;color:var(--muted);margin:10px 0 0">📍 ${escapeHtml(order.customer.address)} — ${escapeHtml(order.customer.zoneName || "")}</p>` : `<p style="font-size:.82rem;color:var(--muted);margin:10px 0 0">🏪 الاستلام من: ${escapeHtml(getSettings().address)}</p>`}
    </div>
  </div>`;
}

/* طباعة إيصال */
function printReceipt(orderId){
  const o = getOrders().find(x => x.id === orderId);
  if (!o) return;
  const s = getSettings();
  const w = window.open("", "_blank", "width=420,height=640");
  if (!w){ toast("متصفحك منع النوافذ المنبثقة", "err"); return; }
  w.document.write(`<html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>إيصال ${o.ref}</title>
  <style>body{font-family:'Tajawal',sans-serif;padding:18px;color:#111}h1{font-size:18px;margin:0 0 4px;text-align:center}
  .ref{font-size:16px;font-weight:800;text-align:center;margin:8px 0}table{width:100%;border-collapse:collapse;margin-top:10px;font-size:13px}
  td,th{padding:6px 4px;border-bottom:1px dashed #bbb;text-align:right}tfoot td{font-weight:800;border:none}
  .muted{color:#666;font-size:12px}.center{text-align:center}</style></head><body>
  <h1>${escapeHtml(s.restaurantName)}</h1>
  <p class="center muted">${escapeHtml(s.address)} · ${escapeHtml(s.phone)}</p>
  <div class="ref">إيصال طلب ${o.ref}</div>
  <p class="center muted">${fmtDate(o.createdAt)} · ${o.type === "delivery" ? "توصيل" : "استلام"}</p>
  <table><thead><tr><th>الصنف</th><th>الكمية</th><th>الإجمالي</th></tr></thead><tbody>
  ${o.items.map(i => `<tr><td>${escapeHtml(i.name)}${i.sizeName ? `<br><span class="muted">${escapeHtml(i.sizeName)}${i.extras && i.extras.length ? " + " + escapeHtml(i.extras.map(e=>e.name).join(" + ")) : ""}</span>` : ""}</td><td>${i.qty}</td><td>${fmtMoney(i.unitPrice * i.qty)}</td></tr>`).join("")}
  </tbody><tfoot>
  <tr><td>المجموع الفرعي</td><td></td><td>${fmtMoney(o.pricing.subtotal)}</td></tr>
  ${o.pricing.discount ? `<tr><td>الخصم</td><td></td><td>-${fmtMoney(o.pricing.discount)}</td></tr>` : ""}
  <tr><td>${o.type === "delivery" ? "التوصيل" : "استلام"}</td><td></td><td>${o.type === "delivery" ? fmtMoney(o.pricing.deliveryFee) : "مجاني"}</td></tr>
  <tr><td>الإجمالي</td><td></td><td>${fmtMoney(o.pricing.total)}</td></tr>
  </tfoot></table>
  <p class="center muted" style="margin-top:14px">شكرًا لطلبك 🧡</p>
  </body></html>`);
  w.document.close();
  setTimeout(() => w.print(), 350);
}

/* =========================================================
   المفضلة
   ========================================================= */
function renderFavoritesView(){
  const box = $("#favoritesList");
  const items = state.favs.map(id => getProducts().find(p => p.id === id)).filter(Boolean);
  if (!items.length){
    box.innerHTML = `
    <div class="empty-state">
      <div class="empty-ic">💛</div>
      <h3>مفيش أصناف في المفضلة</h3>
      <p>اضغط على القلب ❤️ فوق أي طبق عشان تلاقيه هنا بسرعة.</p>
      <button class="btn btn-primary" data-action="go-menu">تصفح القائمة</button>
    </div>`;
    return;
  }
  box.innerHTML = `<div class="prod-grid">${items.map(cardHTML).join("")}</div>`;
  lazyLoadImgs(box);
}

function toggleFav(id){
  if (state.favs.includes(id)){
    state.favs = state.favs.filter(x => x !== id);
    toast("تمت الإزالة من المفضلة");
  } else {
    state.favs.unshift(id);
    toast("تمت الإضافة للمفضلة ❤️", "ok");
  }
  DB.set(DB.K.favs, state.favs);
  document.querySelectorAll(`.fav-btn[data-id="${id}"]`).forEach(b => b.classList.toggle("active", state.favs.includes(id)));
}

/* =========================================================
   التقييمات
   ========================================================= */
function renderReviews(){
  const list = getReviews();
  const grid = $("#reviewsGrid"), sum = $("#reviewsSummary");
  if (!list.length){
    sum.innerHTML = `<p class="section-hint">كن أول من يشارك رأيه بعد أول طلب!</p>`;
    grid.innerHTML = "";
    return;
  }
  const avg = (list.reduce((n, r) => n + (r.rating || 0), 0) / list.length).toFixed(1);
  const stars = "★".repeat(Math.round(avg)) + "☆".repeat(5 - Math.round(avg));
  sum.innerHTML = `
    <div class="reviews-avg">${avg}</div>
    <div>
      <div class="reviews-stars">${stars}</div>
      <div class="reviews-count">متوسط تقييم ${list.length} ${list.length === 1 ? "رأي" : "آراء"} (بيانات نموذجية قابلة للتعديل)</div>
    </div>`;
  grid.innerHTML = list.map(r => `
    <div class="review-card">
      <div class="review-head">
        <div class="review-avatar">${escapeHtml((r.name || "؟").trim().charAt(0))}</div>
        <div>
          <div class="review-name">${escapeHtml(r.name || "عميل")}</div>
          <div class="review-date">${r.daysAgo ? `قبل ${r.daysAgo} يوم` : fmtDate(r.at || Date.now())}</div>
        </div>
      </div>
      <div class="review-stars">${"★".repeat(r.rating)}${"☆".repeat(5 - r.rating)}</div>
      <p class="review-text">${escapeHtml(r.text)}</p>
    </div>`).join("");
}

function openReviewModal(){
  const m = $("#reviewModal");
  m.innerHTML = `
  <div class="pd-sheet" style="max-width:460px">
    <div class="pd-body" style="padding-top:22px">
      <h2 class="pd-title" style="font-size:1.15rem">شاركنا رأيك ⭐</h2>
      <p style="color:var(--muted);font-size:.85rem;margin:4px 0 14px">رأيك بيساعدنا نتحسن ويساعد غيرك يختار.</p>
      <div class="field"><label>اسمك</label><input id="rvName" type="text" maxlength="40" placeholder="مثال: أحمد محمود"></div>
      <div class="field"><label>تقييمك</label>
        <div id="rvStars" style="display:flex;gap:6px;font-size:1.7rem;direction:ltr;justify-content:flex-end;cursor:pointer">
          ${[1,2,3,4,5].map(i => `<span data-action="rv-star" data-v="${i}" style="color:#FFC24B">☆</span>`).join("")}
        </div>
      </div>
      <div class="field"><label>رأيك</label>
        <textarea id="rvText" rows="3" maxlength="300" placeholder="اكتب تجربتك مع الطعام والخدمة…"></textarea></div>
      <span class="field-err" id="rvErr"></span>
    </div>
    <div class="pd-foot">
      <button class="btn btn-outline" data-action="close-modal" style="flex:1">إلغاء</button>
      <button class="btn btn-primary pd-add" data-action="rv-submit">إرسال التقييم</button>
    </div>
  </div>`;
  m.hidden = false;
  requestAnimationFrame(() => m.classList.add("show"));
  document.body.style.overflow = "hidden";
}

function submitReview(){
  const name = $("#rvName").value.trim();
  const text = $("#rvText").value.trim();
  const stars = $("#rvStars").dataset.value;
  if (name.length < 2 || !text || !stars){
    $("#rvErr").textContent = "اكتب اسمك ورأيك واختر عدد النجوم.";
    return;
  }
  const list = getReviews();
  list.unshift({ id: uid(), name, rating: Number(stars), text, at: Date.now(), mine: true });
  DB.set(DB.K.reviews, list);
  renderReviews();
  closeModal();
  toast("شكراً على رأيك 🧡", "ok");
}

/* =========================================================
   الأسئلة الشائعة + كوبونات الرئيسية
   ========================================================= */
function renderFAQ(){
  $("#faqList").innerHTML = DEFAULT_FAQ.map(f => `
    <details class="faq-item">
      <summary>${escapeHtml(f.q)}</summary>
      <p class="faq-body">${escapeHtml(f.a)}</p>
    </details>`).join("");
}

/* =========================================================
   حوارات التأكيد + التنبيهات
   ========================================================= */
function confirmDialog(title, body, onOk){
  const m = $("#confirmModal");
  m.innerHTML = `
  <div class="pd-sheet" style="max-width:400px">
    <div class="pd-body" style="padding-top:24px;text-align:center">
      <h2 class="pd-title" style="font-size:1.15rem">${escapeHtml(title)}</h2>
      <p style="color:var(--muted);font-size:.9rem">${escapeHtml(body)}</p>
    </div>
    <div class="pd-foot" style="gap:10px">
      <button class="btn btn-outline" data-action="close-modal" style="flex:1">إلغاء</button>
      <button class="btn btn-danger" id="confirmOk" style="flex:1">تأكيد</button>
    </div>
  </div>`;
  m.hidden = false;
  requestAnimationFrame(() => m.classList.add("show"));
  $("#confirmOk").onclick = () => { closeModal(); onOk && onOk(); };
  document.body.style.overflow = "hidden";
}

function toast(msg, type){
  const box = $("#toasts");
  const el = document.createElement("div");
  el.className = "toast " + (type || "");
  el.textContent = msg;
  box.appendChild(el);
  setTimeout(() => { el.classList.add("out"); setTimeout(() => el.remove(), 320); }, 2600);
}

function loader(on){
  $("#loader").hidden = !on;
}

/* =========================================================
   المخزون: هل الصنف نفد؟
   ========================================================= */
function isStockOut(p){
  return !!(p.trackStock && (p.stock === 0));
}

/* =========================================================
   ربط الأحداث العامة (Event Delegation)
   ========================================================= */
function bindGlobalEvents(){
  /* نقرة موحدة على كل data-action */
  document.addEventListener("click", e => {
    const el = e.target.closest("[data-action]");
    if (!el) return;
    const act = el.dataset.action;
    const actions = {
      "cat": () => {
        state.activeCat = el.dataset.cat;
        renderCatChips(); renderMenu();
        if (state.activeCat !== "all"){
          setTimeout(() => {
            const t = document.getElementById("cat-" + state.activeCat);
            if (t) t.scrollIntoView({ behavior:"smooth", block:"start" });
          }, 60);
        } else $("#menuSection").scrollIntoView({ behavior:"smooth" });
      },
      "open-product": () => {
        if (el.disabled) return;
        openProductModal(el.dataset.id);
        pushRecent(el.dataset.id);
        renderRecent();
      },
      "fav": () => toggleFav(el.dataset.id),
      "pd-size": () => {
        state.pd.sizeId = el.dataset.id;
        el.parentElement.querySelectorAll(".opt-card").forEach(c => {
          c.classList.toggle("selected", c === el);
          c.setAttribute("aria-checked", c === el);
        });
        pdUpdateTotal();
      },
      "pd-extra": () => {
        const id = el.dataset.id;
        const on = !state.pd.extras.has(id);
        on ? state.pd.extras.add(id) : state.pd.extras.delete(id);
        el.classList.toggle("selected", on);
        el.setAttribute("aria-checked", on);
        pdUpdateTotal();
      },
      "pd-qty": () => {
        const d = Number(el.dataset.d);
        state.pd.qty = Math.max(1, Math.min(30, state.pd.qty + d));
        $("#pdQtyNum").textContent = state.pd.qty;
        pdUpdateTotal();
      },
      "pd-add": () => {
        if (el.disabled) return;
        const wasEditing = state.editingUid;
        const item = itemFromModal();
        if (wasEditing){
          const idx = state.cart.findIndex(c => c.uid === wasEditing);
          if (idx > -1) state.cart[idx] = item;
        } else addToCart(item);
        saveCart();
        closeModal();
        toast(wasEditing ? "تم تحديث الصنف في السلة ✓" : "تمت الإضافة للسلة ✓", "ok");
        if ($("#cartDrawer").classList.contains("open")) renderCart();
      },
      "close-modal": () => { closeModal(); },
      "cart-open": openCart,
      "cart-close": closeCart,
      "go-menu": () => { closeCart(); go("home"); setTimeout(() => $("#menuSection").scrollIntoView({ behavior:"smooth" }), 80); },
      "go-home": () => { closeCart(); go("home"); },
      "go-orders": () => go("orders"),
      "go-checkout": () => {
        if (el.disabled || !state.cart.length) return;
        closeCart(); go("checkout");
      },
      "cart-inc": () => { const it = state.cart.find(c => c.uid === el.dataset.uid); if (it){ it.qty = Math.min(30, it.qty + 1); saveCart(); renderCart(); } },
      "cart-dec": () => {
        const it = state.cart.find(c => c.uid === el.dataset.uid);
        if (it){ it.qty--; if (it.qty <= 0) state.cart = state.cart.filter(c => c.uid !== it.uid); saveCart(); renderCart(); }
      },
      "cart-remove": () => { state.cart = state.cart.filter(c => c.uid !== el.dataset.uid); saveCart(); renderCart(); toast("تم حذف الصنف"); },
      "cart-edit": () => {
        const it = state.cart.find(c => c.uid === el.dataset.uid);
        if (it) openProductModal(it.productId, it.uid);
      },
      "cart-clear": () => confirmDialog("تفريغ السلة", "هتحذف كل الأصناف من السلة. متأكد؟", () => {
        state.cart = []; state.couponCode = ""; saveCart(); renderCart();
      }),
      "cart-coupon": () => applyCouponFrom($("#cartCoupon")),
      "copy-coupon": () => {
        const code = el.dataset.code;
        (navigator.clipboard ? navigator.clipboard.writeText(code) : Promise.reject())
          .then(() => toast("تم نسخ الكود " + code + " ✓", "ok"))
          .catch(() => { toast("الكود: " + code, "ok"); });
      },
      "promo-copy": () => {
        const c = getCoupons().find(x => x.active);
        if (c) (navigator.clipboard ? navigator.clipboard.writeText(c.code) : Promise.reject())
          .then(() => toast("تم نسخ الكود " + c.code + " ✓", "ok")).catch(() => toast("الكود: " + c.code, "ok"));
      },
      "track": () => go("track/" + el.dataset.ref),
      "print-receipt": () => printReceipt(el.dataset.id),
      "reorder": () => reorder(el.dataset.id),
      "cancel-request": () => { const o = getOrders().find(x => x.id === el.dataset.id); if (o) requestCancel(o); },
      "add-review": openReviewModal,
      "rv-star": () => { $("#rvStars").dataset.value = el.dataset.v; $$("#rvStars span").forEach(s => s.textContent = Number(s.dataset.v) <= Number(el.dataset.v) ? "★" : "☆"); },
      "rv-submit": submitReview,
      "lookup": () => {
        const ref = $("#lookupRef").value.trim().toUpperCase();
        const phone = $("#lookupPhone").value.trim();
        const err = $("#lookupErr");
        err.textContent = "";
        if (!ref || !isValidEgyptPhone(phone)){ err.textContent = "اكتب رقم الطلب ورقم الموبايل الصحيح."; return; }
        const o = getOrders().find(x => x.ref.toUpperCase() === ref && x.customer.phone === phone);
        if (!o){ err.textContent = "لا يوجد طلب مطابق لهذه البيانات."; return; }
        go("track/" + o.ref);
      }
    };
    if (actions[act]){ e.preventDefault(); actions[act](); }
  });

  /* أزرار علوية */
  $("#cartBtn").addEventListener("click", openCart);
  $("#cartClose").addEventListener("click", closeCart);
  $("#cartOverlay").addEventListener("click", closeCart);
  $("#brandBtn").addEventListener("click", () => go("home"));
  $("#checkoutBack").addEventListener("click", () => go("home"));
  $("#trackBack").addEventListener("click", () => go("orders"));
  $("#clearFiltersBtn").addEventListener("click", () => {
    state.search = ""; state.activeCat = "all"; $("#searchInput").value = "";
    $("#searchClear").classList.add("hidden");
    renderCatChips(); renderMenu();
  });
  $("#addReviewBtn").addEventListener("click", openReviewModal);
  $("#promoCopyBtn").addEventListener("click", () => {
    const c = getCoupons().find(x => x.active);
    if (c) (navigator.clipboard ? navigator.clipboard.writeText(c.code) : Promise.reject())
      .then(() => toast("تم نسخ الكود " + c.code + " ✓", "ok")).catch(() => toast("الكود: " + c.code, "ok"));
  });
  $("#promoStrip").addEventListener("click", e => {
    if (!e.target.closest("#promoCopyBtn")){
      const first = $("#couponRow");
      if (first){ $("#couponsSection").scrollIntoView({ behavior:"smooth" }); }
    }
  });

  /* بحث وترتيب */
  $("#searchInput").addEventListener("input", e => {
    state.search = e.target.value;
    $("#searchClear").classList.toggle("hidden", !state.search);
    renderMenu();
  });
  $("#searchClear").addEventListener("click", () => {
    state.search = ""; $("#searchInput").value = "";
    $("#searchClear").classList.add("hidden");
    renderMenu();
  });
  $("#sortSelect").addEventListener("change", e => { state.sort = e.target.value; renderMenu(); });

  /* نموذج إتمام الطلب */
  $("#checkoutForm").addEventListener("submit", e => { e.preventDefault(); submitOrder(e.submitter || $("#submitOrderBtn")); });
  document.querySelectorAll('input[name="orderType"]').forEach(r =>
    r.addEventListener("change", () => renderCheckout()));
  $("#ckZone").addEventListener("change", () => { state.zoneId = $("#ckZone").value; updateCheckoutSummary(); });
  $("#ckCouponApply").addEventListener("click", () => applyCouponFrom($("#ckCoupon")));

  /* التنقل السفلي */
  $$(".bn-item").forEach(b => b.addEventListener("click", () => {
    const n = b.dataset.nav;
    if (n === "cart") openCart();
    else if (n === "menu"){ go("home"); setTimeout(() => $("#menuSection").scrollIntoView({ behavior:"smooth" }), 80); }
    else go(n);
  }));

  /* Esc يغلق النوافذ */
  document.addEventListener("keydown", e => {
    if (e.key === "Escape"){
      if (!$("#productModal").hidden || !$("#reviewModal").hidden || !$("#confirmModal").hidden) closeModal();
      else closeCart();
    }
  });
  /* خلفية نافذة المنتج تُغلقه */
  $("#productModal").addEventListener("click", e => { if (e.target === e.currentTarget) closeModal(); });
  $("#reviewModal").addEventListener("click", e => { if (e.target === e.currentTarget) closeModal(); });
  $("#confirmModal").addEventListener("click", e => { if (e.target === e.currentTarget) closeModal(); });
}

/* =========================================================
   الرندر الشامل
   ========================================================= */
function renderAll(){
  renderCatChips();
  renderMenu();
  renderBest();
  renderRecent();
  renderCouponsSection();
  renderReviews();
  renderFAQ();
  updateCartBadge();
}


