# Arquitectura del Backend - La Conquista Medieval

## 1. Persistencia y Base de Datos (Cloud Firestore)
- **Base de datos**: `ai-studio-laconquista-691713e1-8729-4e81-8c02-6fba08f2df26`
- **Colecciones clave**:
  - `users/{userId}`: Perfil soberano, correo y registro de actividad.
  - `kingdoms/{userId}`: Estado completo del feudo (edificios, investigaciones, tropas, reservas, gloria, coordenadas en el mapa).
  - `pvp_challenges/{challengeId}`: Desafíos militares y pactos parlamentarios entre reinos.

## 2. Lógica Autoritativa de Servidor (Paso 1)
- Las batallas PvP acordadas en el Parlamento (Punto 38-40) son dirimidas mediante la tarea programada `resolveDuePvPChallenges`.
- Los resultados de combates se firman en el documento del desafío, garantizando sincronía entre ambos jugadores.
- El cliente web detecta las actualizaciones en tiempo real mediante `onSnapshot` de Firestore.

## 3. Seguridad y Reglas de Acceso
- Archivo `firestore.rules` configurado con permisos de lectura y escritura para reinos, perfiles y desafíos PvP.
