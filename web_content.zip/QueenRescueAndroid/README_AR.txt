مشروع أندرويد للعبة إنقاذ الملكة

1. فك ضغط ZIP على الكمبيوتر.
2. افتح Android Studio ثم Open واختر مجلد QueenRescueAndroid.
3. انتظر مزامنة Gradle وتنزيل المتطلبات (يحتاج الإنترنت أول مرة).
4. من القائمة Build > Build Bundle(s) / APK(s) > Build APK(s).
5. ستجد ملف APK في app/build/outputs/apk/debug/app-debug.apk.
6. لإنشاء AAB استخدم Build > Generate Signed Bundle / APK واختر Android App Bundle وأنشئ مفتاح توقيع واحفظه بأمان.

اللعبة مضمنة في assets وتعمل دون اتصال. زر مشاركة ملف HTML الأصلي قد يعتمد على دعم WebView للمشاركة. زر الإعلان المكافئ تجريبي وغير مرتبط بخدمة إعلانات.


طريقة بناء AAB عبر GitHub (يتطلب حساب GitHub):
1. ارفع مجلد المشروع إلى مستودع GitHub جديد.
2. افتح Actions ثم شغّل Build Android App Bundle (AAB) عبر Run workflow.
3. بعد انتهاء العملية نزّل Artifact باسم QueenRescue-release-aab-UNSIGNED.
مهم: هذا الناتج غير موقّع ولا يصلح للرفع المباشر إلى Google Play. يجب توقيعه بمفتاح رفع خاص بك من خلال Android Studio أو إعداد توقيع آمن في بيئة البناء. لا تشارك ملف المفتاح أو كلمة مروره مع أي شخص.
