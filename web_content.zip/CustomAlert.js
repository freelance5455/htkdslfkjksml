function Alert1(message){const o=document.getElementById('custom-alert-overlay');if(!o)return;document.getElementById('alert-message').textContent=message;o.classList.add('show')}
function closeAlert(){document.getElementById('custom-alert-overlay')?.classList.remove('show')}
