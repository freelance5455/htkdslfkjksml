BLUETOOTH JAMMER PRANK SIMULATOR

1. Extract the ZIP file.
2. Open the bluetooth_prank_app folder in Acode.
3. Open index.html.
4. Preview it in your browser.

This is a visual prank simulator only. It does not access Bluetooth, jam signals,
scan real devices, or disconnect anyone's devices.
