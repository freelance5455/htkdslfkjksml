package com.pokercallfold.app
import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.View
import android.graphics.Color

class MainActivity : Activity() {
 private lateinit var webView: WebView
 @Suppress("SetJavaScriptEnabled")
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  window.statusBarColor = Color.rgb(7,27,24)
  window.navigationBarColor = Color.rgb(7,27,24)
  webView = WebView(this)
  webView.setBackgroundColor(Color.rgb(7,27,24))
  webView.settings.javaScriptEnabled = true
  webView.settings.domStorageEnabled = false
  webView.settings.allowFileAccess = true
  webView.settings.allowContentAccess = false
  webView.webChromeClient = WebChromeClient()
  webView.webViewClient = WebViewClient()
  webView.overScrollMode = View.OVER_SCROLL_NEVER
  setContentView(webView)
  webView.loadUrl("file:///android_asset/index.html")
 }
 override fun onDestroy() { if (::webView.isInitialized) webView.destroy(); super.onDestroy() }
}
