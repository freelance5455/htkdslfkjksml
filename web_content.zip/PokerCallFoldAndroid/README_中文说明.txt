牌桌裁决 Call or Fold — Android 测试项目

功能：
- 点击按钮随机揭晓 CALL 或 FOLD（各 50%）。
- 扑克牌翻动动画、牌桌闪光、彩色粒子爆发。
- 统计总抽取、CALL、FOLD，并显示最近 12 次结果。
- 重置前有确认提示。
- 完全离线，不需要网络权限。

构建：
1. 解压 ZIP。
2. 用兼容 Android Gradle 项目的 IDE 打开包含 settings.gradle 的项目根目录。
3. 使用兼容 JDK（通常 JDK 17）和 Android SDK 同步项目。
4. 构建 APK。调试包通常在 app/build/outputs/apk/debug/app-debug.apk。

注意：这是 Android 项目 ZIP，不是已编译 APK。CALL/FOLD 是纯随机娱乐结果，不是 GTO 建议。
