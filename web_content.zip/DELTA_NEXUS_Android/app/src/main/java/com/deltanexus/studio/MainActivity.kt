package com.deltanexus.studio

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Background = Color(0xFF080B13)
private val Panel = Color(0xFF111827)
private val PanelRaised = Color(0xFF172235)
private val TextMain = Color(0xFFF3F6FF)
private val TextMuted = Color(0xFF9AA8BE)
private val Cyan = Color(0xFF55E5E2)
private val Violet = Color(0xFFA78BFA)
private const val MAX_DECODE_PIXELS = 6_000_000L
private const val MAX_OUTPUT_PIXELS = 32_000_000L

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DeltaNexusApp() }
    }
}

private enum class MainTab { STUDIO, SETTINGS }

@Composable
private fun DeltaNexusApp() {
    val context = LocalContext.current
    var tab by remember { mutableStateOf(MainTab.STUDIO) }
    var source by remember { mutableStateOf<Bitmap?>(null) }
    var result by remember { mutableStateOf<Bitmap?>(null) }
    var fileLabel by remember { mutableStateOf("Henüz fotoğraf seçilmedi") }
    var isBusy by remember { mutableStateOf(false) }
    var showOriginal by remember { mutableStateOf(false) }
    var denoise by remember { mutableStateOf(false) }
    var monochrome by remember { mutableStateOf(false) }
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var saturation by remember { mutableFloatStateOf(1f) }
    var sharpness by remember { mutableFloatStateOf(0f) }
    var useViolet by remember { mutableStateOf(false) }
    var exportPng by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }
    val accent = if (useViolet) Violet else Cyan

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            isBusy = true
            fileLabel = "Fotoğraf yükleniyor…"
            Thread {
                val loaded = runCatching { decodeBitmap(context, uri) }.getOrNull()
                context.mainExecutor.execute {
                    source = loaded
                    result = loaded
                    fileLabel = if (loaded == null) "Fotoğraf açılamadı" else "Fotoğraf hazır • ${loaded.width} × ${loaded.height}"
                    isBusy = false
                    showOriginal = false
                    if (loaded == null) message = "Bu görsel biçimi açılamadı. Başka bir fotoğraf deneyebilirsin."
                    resetControls({ brightness = 0f }, { contrast = 1f }, { saturation = 1f }, { sharpness = 0f }, { denoise = false }, { monochrome = false })
                }
            }.start()
        }
    }

    fun process(custom: Boolean = false) {
        val input = source ?: run { message = "Önce bir fotoğraf seç."; return }
        if (isBusy) return
        val b = if (custom) 4f else brightness
        val c = if (custom) 1.16f else contrast
        val s = if (custom) 1.10f else saturation
        val sh = if (custom) 0.35f else sharpness
        val dn = if (custom) false else denoise
        val mono = if (custom) false else monochrome
        isBusy = true
        Thread {
            val edited = runCatching { processBitmap(input, b, c, s, sh, dn, mono) }.getOrNull()
            context.mainExecutor.execute {
                if (edited != null) {
                    result = edited
                    showOriginal = false
                    message = if (custom) "Otomatik ton ve renk iyileştirmesi uygulandı." else "Düzenlemeler uygulandı."
                } else message = "İşlem tamamlanamadı. Daha küçük bir görsel deneyebilirsin."
                isBusy = false
            }
        }.start()
    }

    fun transform(rotate: Float = 0f, mirror: Boolean = false) {
        val input = result ?: run { message = "Önce bir fotoğraf seç."; return }
        if (isBusy) return
        isBusy = true
        Thread {
            val edited = runCatching {
                val matrix = Matrix().apply { postRotate(rotate); if (mirror) postScale(-1f, 1f) }
                Bitmap.createBitmap(input, 0, 0, input.width, input.height, matrix, true)
            }.getOrNull()
            context.mainExecutor.execute {
                if (edited != null) { result = edited; message = if (mirror) "Aynalama tamamlandı." else "Döndürme tamamlandı." }
                else message = "Görsel dönüştürülemedi."
                isBusy = false
            }
        }.start()
    }

    fun upscale(factor: Int) {
        val input = result ?: run { message = "Önce bir fotoğraf seç."; return }
        val pixels = input.width.toLong() * input.height.toLong() * factor.toLong() * factor.toLong()
        if (pixels > MAX_OUTPUT_PIXELS) {
            message = "$factor× çıktı bu görsel için çok büyük. Bellek sınırı nedeniyle ölçekleme durduruldu. Daha küçük bir kaynak görselde deneyebilirsin."
            return
        }
        if (isBusy) return
        isBusy = true
        Thread {
            val edited = runCatching { Bitmap.createScaledBitmap(input, input.width * factor, input.height * factor, true) }.getOrNull()
            context.mainExecutor.execute {
                if (edited != null) { result = edited; message = "$factor× yeniden boyutlandırma tamamlandı. Bu işlem klasik ölçeklemedir; AI detay üretimi değildir." }
                else message = "Bellek yetersiz. Daha küçük bir görselle dene."
                isBusy = false
            }
        }.start()
    }

    fun saveImage() {
        val bitmap = result ?: run { message = "Kaydetmek için önce bir fotoğraf seç."; return }
        if (isBusy) return
        isBusy = true
        val png = exportPng
        Thread {
            val savedUri = runCatching {
                val name = "DELTA_NEXUS_${System.currentTimeMillis()}.${if (png) "png" else "jpg"}"
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, if (png) "image/png" else "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Delta Nexus")
                }
                val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: error("Galeri kaydı başlatılamadı")
                context.contentResolver.openOutputStream(uri)?.use { stream ->
                    val ok = bitmap.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 96, stream)
                    if (!ok) error("Dosya yazılamadı")
                } ?: error("Dosya akışı açılamadı")
                uri
            }.getOrNull()
            context.mainExecutor.execute {
                isBusy = false
                message = if (savedUri != null) "Görsel galeriye kaydedildi: Pictures/Delta Nexus" else "Kaydetme başarısız oldu. Depolama alanını kontrol et."
                if (savedUri != null) Toast.makeText(context, "DELTA NEXUS • Galeriye kaydedildi", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = accent, secondary = Violet, background = Background, surface = Panel)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Background) {
            androidx.compose.material3.Scaffold(
                containerColor = Background,
                bottomBar = {
                    NavigationBar(containerColor = Color(0xFF0D1320), contentColor = TextMain) {
                        NavigationBarItem(
                            selected = tab == MainTab.STUDIO,
                            onClick = { tab = MainTab.STUDIO },
                            icon = { Text("✦", fontSize = 20.sp) },
                            label = { Text("Stüdyo", fontSize = 11.sp) }
                        )
                        NavigationBarItem(
                            selected = tab == MainTab.SETTINGS,
                            onClick = { tab = MainTab.SETTINGS },
                            icon = { Text("⚙", fontSize = 18.sp) },
                            label = { Text("Ayarlar", fontSize = 11.sp) }
                        )
                    }
                }
            ) { padding ->
                if (tab == MainTab.STUDIO) {
                    StudioScreen(
                        modifier = Modifier.padding(padding), accent = accent, source = source,
                        result = result, fileLabel = fileLabel, busy = isBusy, showOriginal = showOriginal,
                        brightness = brightness, onBrightness = { brightness = it },
                        contrast = contrast, onContrast = { contrast = it },
                        saturation = saturation, onSaturation = { saturation = it },
                        sharpness = sharpness, onSharpness = { sharpness = it },
                        denoise = denoise, onDenoise = { denoise = it },
                        monochrome = monochrome, onMonochrome = { monochrome = it },
                        exportPng = exportPng, onExportPng = { exportPng = it },
                        onPick = { picker.launch("image/*") },
                        onAuto = { process(true) }, onApply = { process(false) },
                        onReset = { result = source; showOriginal = false; resetControls({ brightness = 0f }, { contrast = 1f }, { saturation = 1f }, { sharpness = 0f }, { denoise = false }, { monochrome = false }); message = "Düzenlemeler sıfırlandı." },
                        onCompare = { showOriginal = !showOriginal }, onRotate = { transform(90f) },
                        onMirror = { transform(mirror = true) }, onUpscale = { upscale(it) }, onSave = { saveImage() }
                    )
                } else {
                    SettingsScreen(modifier = Modifier.padding(padding), accent = accent,
                        useViolet = useViolet, onTheme = { useViolet = it })
                }
            }
        }
    }

    if (message != null) {
        AlertDialog(
            onDismissRequest = { message = null },
            containerColor = Panel,
            titleContentColor = TextMain,
            textContentColor = TextMuted,
            title = { Text("DELTA NEXUS") },
            text = { Text(message!!) },
            confirmButton = { TextButton(onClick = { message = null }) { Text("TAMAM", color = accent) } }
        )
    }
}

private fun resetControls(
    brightness: () -> Unit, contrast: () -> Unit, saturation: () -> Unit,
    sharpness: () -> Unit, denoise: () -> Unit, monochrome: () -> Unit
) { brightness(); contrast(); saturation(); sharpness(); denoise(); monochrome() }

@Composable
private fun StudioScreen(
    modifier: Modifier, accent: Color, source: Bitmap?, result: Bitmap?, fileLabel: String, busy: Boolean,
    showOriginal: Boolean, brightness: Float, onBrightness: (Float) -> Unit,
    contrast: Float, onContrast: (Float) -> Unit, saturation: Float, onSaturation: (Float) -> Unit,
    sharpness: Float, onSharpness: (Float) -> Unit, denoise: Boolean, onDenoise: (Boolean) -> Unit,
    monochrome: Boolean, onMonochrome: (Boolean) -> Unit,
    exportPng: Boolean, onExportPng: (Boolean) -> Unit,
    onPick: () -> Unit, onAuto: () -> Unit, onApply: () -> Unit, onReset: () -> Unit,
    onCompare: () -> Unit, onRotate: () -> Unit, onMirror: () -> Unit,
    onUpscale: (Int) -> Unit, onSave: () -> Unit
) {
    Column(
        modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp)
    ) {
        BrandHeader(accent)
        HeroPanel(accent)
        Button(
            onClick = onPick, modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Background)
        ) { Text("＋  FOTOĞRAF SEÇ", fontWeight = FontWeight.Black, letterSpacing = 0.8.sp) }
        Text(fileLabel, color = TextMuted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        PreviewCard(result = result, source = source, showOriginal = showOriginal, busy = busy, accent = accent, onCompare = onCompare)
        SectionTitle("HIZLI ARAÇLAR", "TEK DOKUNUŞ")
        Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            ActionTile("✧", "Otomatik", "Ton & renk", accent, Modifier.weight(1f), onAuto)
            ActionTile("↶", "Sola çevir", "90° döndür", accent, Modifier.weight(1f), onRotate)
            ActionTile("⇋", "Aynala", "Yatay çevir", accent, Modifier.weight(1f), onMirror)
        }
        SectionTitle("İNCE AYAR", "MANUEL KONTROL")
        ControlsCard(
            accent, brightness, onBrightness, contrast, onContrast, saturation, onSaturation,
            sharpness, onSharpness, denoise, onDenoise, monochrome, onMonochrome
        )
        SectionTitle("ÇÖZÜNÜRLÜK", "KLASİK ÖLÇEKLEME")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = { onUpscale(2) }, modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(14.dp)) { Text("2× BÜYÜT", color = accent, fontWeight = FontWeight.Bold) }
            OutlinedButton(onClick = { onUpscale(4) }, modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(14.dp)) { Text("4× BÜYÜT", color = accent, fontWeight = FontWeight.Bold) }
        }
        Text("Bilgi: Ölçekleme piksel boyutunu artırır; kayıp ayrıntıları yapay zekâ ile geri üretmez. Büyük çıktılar cihaz belleğine bağlıdır.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            OutlinedButton(onClick = onReset, modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(14.dp)) { Text("SIFIRLA", color = TextMain) }
            Button(onClick = onApply, enabled = source != null && !busy, modifier = Modifier.weight(1.4f).height(48.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Background)) {
                Text("DÜZENLEMEYİ UYGULA", fontSize = 11.sp, fontWeight = FontWeight.Black)
            }
        }
        SectionTitle("DIŞA AKTAR", "CİHAZINA KAYDET")
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Dosya biçimi", color = TextMain, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    FilterChip(selected = exportPng, onClick = { onExportPng(true) }, label = { Text("PNG") })
                    FilterChip(selected = !exportPng, onClick = { onExportPng(false) }, label = { Text("JPEG") })
                }
                Button(onClick = onSave, enabled = result != null && !busy, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Background)) {
                    Text("↓  GALERİYE KAYDET", fontWeight = FontWeight.Black)
                }
            }
        }
        Text("Tüm temel düzenleme işlemleri cihazda yapılır. Ağ izni veya bulut hesabı kullanılmaz.", color = TextMuted, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp))
    }
}

@Composable
private fun BrandHeader(accent: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Box(Modifier.size(45.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(accent, Violet))), contentAlignment = Alignment.Center) {
            Text("Δ", color = Background, fontSize = 30.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text("DELTA NEXUS", color = TextMain, fontSize = 19.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp)
            Text("LOCAL IMAGE STUDIO  •  V1.0", color = TextMuted, fontSize = 9.sp, letterSpacing = 1.1.sp)
        }
        Box(Modifier.clip(CircleShape).background(Color(0xFF102E2D)).border(1.dp, Color(0xFF236B65), CircleShape).padding(horizontal = 10.dp, vertical = 7.dp)) {
            Text("OFFLINE", color = accent, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
        }
    }
}

@Composable
private fun HeroPanel(accent: Color) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Color(0xFF172E43), Color(0xFF262044), Color(0xFF102B32)))).border(1.dp, Color(0xFF344C67), RoundedCornerShape(24.dp)).padding(20.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("PRECISION • CONTROL • DETAIL", color = accent, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Text("Her karede\nkendi imzan.", color = TextMain, fontSize = 30.sp, lineHeight = 34.sp, fontWeight = FontWeight.ExtraBold)
            Text("Fotoğraflarını internet bağlantısı olmadan düzenle. Kontrol sende, dosyaların cihazında.", color = Color(0xFFC0CCDE), fontSize = 12.sp, lineHeight = 18.sp)
        }
    }
}

@Composable
private fun PreviewCard(result: Bitmap?, source: Bitmap?, showOriginal: Boolean, busy: Boolean, accent: Color, onCompare: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, Color(0xFF26354B))) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("ÖNİZLEME", color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(Modifier.weight(1f))
                Text(if (showOriginal) "ORİJİNAL" else "SONUÇ", color = accent, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
            Box(Modifier.fillMaxWidth().aspectRatio(1.48f).clip(RoundedCornerShape(14.dp)).background(Color(0xFF090E18)), contentAlignment = Alignment.Center) {
                val preview = if (showOriginal) source else result
                if (preview != null) Image(bitmap = preview.asImageBitmap(), contentDescription = "Fotoğraf önizlemesi", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                else Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("▧", color = accent, fontSize = 38.sp)
                    Text("Fotoğrafın burada görünecek", color = TextMuted, fontSize = 11.sp)
                }
                if (busy) Box(Modifier.fillMaxSize().background(Color(0x99080B13)), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = accent) }
            }
            OutlinedButton(onClick = onCompare, enabled = source != null && !busy, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                Text(if (showOriginal) "SONUCU GÖSTER" else "ORİJİNALİ KARŞILAŞTIR", color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, hint: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text(title, color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
        Spacer(Modifier.weight(1f))
        Text(hint, color = TextMuted, fontSize = 8.sp, letterSpacing = 0.8.sp)
    }
}

@Composable
private fun ActionTile(symbol: String, title: String, subtitle: String, accent: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(Panel).border(1.dp, Color(0xFF26354B), RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(vertical = 13.dp, horizontal = 7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(symbol, color = accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(title, color = TextMain, fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text(subtitle, color = TextMuted, fontSize = 8.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun ControlsCard(
    accent: Color, brightness: Float, onBrightness: (Float) -> Unit,
    contrast: Float, onContrast: (Float) -> Unit, saturation: Float, onSaturation: (Float) -> Unit,
    sharpness: Float, onSharpness: (Float) -> Unit, denoise: Boolean, onDenoise: (Boolean) -> Unit,
    monochrome: Boolean, onMonochrome: (Boolean) -> Unit
) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SliderControl("Parlaklık", brightness, -50f..50f, onBrightness, "${brightness.toInt()}", accent)
            SliderControl("Kontrast", contrast, 0.5f..1.8f, onContrast, String.format(Locale.US, "%.2f×", contrast), accent)
            SliderControl("Doygunluk", saturation, 0f..2f, onSaturation, String.format(Locale.US, "%.2f×", saturation), accent)
            SliderControl("Keskinlik", sharpness, 0f..1.5f, onSharpness, String.format(Locale.US, "%.2f", sharpness), accent)
            SettingSwitch("Yumuşak gürültü azaltma", "Hafif renk/parazit yumuşatma", denoise, onDenoise, accent)
            SettingSwitch("Siyah-beyaz", "Monokrom görünüm", monochrome, onMonochrome, accent)
        }
    }
}

@Composable
private fun SliderControl(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onValue: (Float) -> Unit, valueText: String, accent: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Text(valueText, color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Slider(value = value, onValueChange = onValue, valueRange = range)
    }
}

@Composable
private fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit, accent: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = TextMuted, fontSize = 9.sp)
        }
        Switch(checked = checked, onCheckedChange = onChecked, thumbContent = null)
    }
}

@Composable
private fun SettingsScreen(modifier: Modifier, accent: Color, useViolet: Boolean, onTheme: (Boolean) -> Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        BrandHeader(accent)
        Text("AYARLAR", color = TextMain, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("GÖRÜNÜM", color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text("Vurgu rengi", color = TextMain, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FilterChip(selected = !useViolet, onClick = { onTheme(false) }, label = { Text("Nexus Cyan") })
                    FilterChip(selected = useViolet, onClick = { onTheme(true) }, label = { Text("Nebula Violet") })
                }
                Text("Koyu arayüz her zaman açık. Tema seçimi yalnızca vurgu rengini değiştirir.", color = TextMuted, fontSize = 10.sp)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).clip(RoundedCornerShape(15.dp)).background(Brush.linearGradient(listOf(accent, Violet))), contentAlignment = Alignment.Center) {
                        Text("Δ", color = Background, fontSize = 31.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("DELTA NEXUS", color = TextMain, fontWeight = FontWeight.Black, fontSize = 18.sp, letterSpacing = 1.sp)
                        Text("GÖRÜNTÜ STÜDYOSU", color = TextMuted, fontSize = 9.sp, letterSpacing = 1.sp)
                    }
                }
                Spacer(Modifier.height(4.dp))
                InfoLine("Geliştiren", "ABDULLAH ÖZDEMİR", accent)
                InfoLine("Sürüm", "1.0.0", accent)
                InfoLine("Android hedefi", "Android 16 • API 36", accent)
                InfoLine("İşleme", "Cihaz üzerinde • çevrimdışı", accent)
                InfoLine("İzinler", "İnternet izni yok", accent)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = PanelRaised), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("UYGULAMA HAKKINDA", color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text("DELTA NEXUS, fotoğrafları cihaz üzerinde düzenlemek için tasarlanmış yerel bir görüntü stüdyosudur. Dosyalar bir sunucuya yüklenmez.", color = TextMain, fontSize = 11.sp, lineHeight = 17.sp)
                Text("Not: Bu sürümde otomatik iyileştirme ve klasik görüntü filtreleri bulunur. Eğitilmiş AI süper çözünürlük veya AI video restorasyonu içermez.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
            }
        }
        Text("DELTA NEXUS  •  CRAFTED FOR DETAIL", color = TextMuted, fontSize = 9.sp, letterSpacing = 1.2.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    }
}

@Composable
private fun InfoLine(label: String, value: String, accent: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TextMuted, fontSize = 11.sp, modifier = Modifier.weight(1f))
        Text(value, color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
    }
}

private fun decodeBitmap(context: android.content.Context, uri: Uri): Bitmap {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    context.contentResolver.openInputStream(uri).use { stream -> BitmapFactory.decodeStream(stream, null, bounds) }
    require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Geçersiz görsel" }
    var sample = 1
    while ((bounds.outWidth.toLong() / sample) * (bounds.outHeight.toLong() / sample) > MAX_DECODE_PIXELS) sample *= 2
    val options = BitmapFactory.Options().apply {
        inSampleSize = sample
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    return context.contentResolver.openInputStream(uri).use { stream ->
        BitmapFactory.decodeStream(stream, null, options) ?: error("Görsel çözümlenemedi")
    }
}

private fun processBitmap(
    source: Bitmap, brightness: Float, contrast: Float, saturation: Float,
    sharpness: Float, denoise: Boolean, monochrome: Boolean
): Bitmap {
    val width = source.width
    val height = source.height
    val pixels = IntArray(width * height)
    source.getPixels(pixels, 0, width, 0, 0, width, height)
    val output = IntArray(pixels.size)
    for (y in 0 until height) {
        for (x in 0 until width) {
            val i = y * width + x
            val center = pixels[i]
            var r = (center shr 16) and 255
            var g = (center shr 8) and 255
            var b = center and 255
            if (denoise) {
                val left = pixels[y * width + (x - 1).coerceAtLeast(0)]
                val right = pixels[y * width + (x + 1).coerceAtMost(width - 1)]
                val up = pixels[(y - 1).coerceAtLeast(0) * width + x]
                val down = pixels[(y + 1).coerceAtMost(height - 1) * width + x]
                val rr = (((center shr 16) and 255) * 2 + ((left shr 16) and 255) + ((right shr 16) and 255) + ((up shr 16) and 255) + ((down shr 16) and 255)) / 6f
                val gg = (((center shr 8) and 255) * 2 + ((left shr 8) and 255) + ((right shr 8) and 255) + ((up shr 8) and 255) + ((down shr 8) and 255)) / 6f
                val bb = ((center and 255) * 2 + (left and 255) + (right and 255) + (up and 255) + (down and 255)) / 6f
                r = (r * 0.72f + rr * 0.28f).toInt()
                g = (g * 0.72f + gg * 0.28f).toInt()
                b = (b * 0.72f + bb * 0.28f).toInt()
            }
            if (sharpness > 0f && x > 0 && x < width - 1 && y > 0 && y < height - 1) {
                val l = pixels[i - 1]; val rt = pixels[i + 1]; val u = pixels[i - width]; val d = pixels[i + width]
                val avgR = ((((l shr 16) and 255) + ((rt shr 16) and 255) + ((u shr 16) and 255) + ((d shr 16) and 255)) / 4f)
                val avgG = ((((l shr 8) and 255) + ((rt shr 8) and 255) + ((u shr 8) and 255) + ((d shr 8) and 255)) / 4f)
                val avgB = (((l and 255) + (rt and 255) + (u and 255) + (d and 255)) / 4f)
                r = (r + (r - avgR) * sharpness).toInt()
                g = (g + (g - avgG) * sharpness).toInt()
                b = (b + (b - avgB) * sharpness).toInt()
            }
            r = (((r - 128f) * contrast) + 128f + brightness).toInt().coerceIn(0, 255)
            g = (((g - 128f) * contrast) + 128f + brightness).toInt().coerceIn(0, 255)
            b = (((b - 128f) * contrast) + 128f + brightness).toInt().coerceIn(0, 255)
            val luminance = 0.299f * r + 0.587f * g + 0.114f * b
            r = (luminance + (r - luminance) * saturation).toInt().coerceIn(0, 255)
            g = (luminance + (g - luminance) * saturation).toInt().coerceIn(0, 255)
            b = (luminance + (b - luminance) * saturation).toInt().coerceIn(0, 255)
            if (monochrome) {
                val gray = (0.299f * r + 0.587f * g + 0.114f * b).toInt().coerceIn(0, 255)
                r = gray; g = gray; b = gray
            }
            output[i] = (center and -0x1000000) or (r shl 16) or (g shl 8) or b
        }
    }
    return Bitmap.createBitmap(output, width, height, Bitmap.Config.ARGB_8888)
}
