# DELTA NEXUS — Android source project

Premium, offline-first Android photo editor concept branded **DELTA NEXUS**.

## Included in this build

- Photo import using Android's system content picker
- Automatic tone/colour enhancement (classic pixel processing; not a trained AI model)
- Brightness, contrast, saturation and sharpness controls
- Soft 5-point noise smoothing
- Monochrome filter
- Rotate 90° and horizontal mirror
- 2× / 4× bitmap scaling with a 32-megapixel output guard
- Original/result preview toggle
- PNG and JPEG export to `Pictures/Delta Nexus`
- Cyan / violet accent themes
- About screen with developer credit: **ABDULLAH ÖZDEMİR**
- No internet permission; image processing is local

## Android compatibility

- `compileSdk = 36`, `targetSdk = 36` (Android 16)
- `minSdk = 29` (Android 10+)
- Requires Android Studio with Android SDK Platform 36 and JDK 17.

## Build an APK

1. Open this folder (`DELTA_NEXUS_Android`) in Android Studio.
2. Allow Gradle sync and install Android SDK Platform 36 if prompted.
3. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Android Studio writes the debug APK under `app/build/outputs/apk/debug/`.

This delivered folder is source code, not a prebuilt or device-tested APK. The environment where it was prepared did not contain Android SDK / Gradle, so APK compilation and on-device validation were not possible here.

## Important capability note

This version contains deterministic, on-device image filters and conventional bitmap resizing. It does **not** bundle pretrained AI model weights, AI super-resolution, face restoration, or video restoration. A 2×/4× scale-up increases pixel dimensions but does not recover details absent from the source image. Very large images are downsampled to a memory-safe working size before editing; large exports depend on device RAM.
