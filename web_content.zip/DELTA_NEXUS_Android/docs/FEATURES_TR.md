# DELTA NEXUS — Özellikler

**Fotoğraf stüdyosu:** Fotoğraf içe aktarma, otomatik ton/renk düzenleme, parlaklık, kontrast, doygunluk, keskinlik, hafif gürültü yumuşatma, siyah-beyaz, 90° döndürme, yatay aynalama, 2×/4× klasik ölçekleme, orijinal/sonuç karşılaştırması ve PNG/JPEG dışa aktarma.

**Ayarlar ve kimlik:** Nexus Cyan / Nebula Violet vurgu teması, Hakkında alanı, Geliştiren: ABDULLAH ÖZDEMİR, sürüm 1.0.0, Android 16 hedefi.

**Gizlilik:** Manifestte INTERNET izni yoktur. Görüntüler uygulama içinde yerel olarak işlenir; galeriye kaydetme Android MediaStore üzerinden yapılır.

**Sınırlar:** Bu sürüm bir AI modeli içermez. Video iyileştirme ve gerçek AI süper çözünürlük bu pakette uygulanmış değildir. 2×/4× büyütme klasik bitmap ölçeklemesidir. Kaynak görsel, bellek sınırlarını korumak için içe aktarım sırasında küçültülebilir.
